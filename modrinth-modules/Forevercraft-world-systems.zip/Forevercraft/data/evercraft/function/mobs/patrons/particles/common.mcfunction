# Common Patron crown particles — wax_off (subtle gray sparkles)
execute if predicate evercraft:mobs/percentages/75 run particle wax_off ^0 ^0.4 ^-0.5 0 0 0 0 1
execute if predicate evercraft:mobs/percentages/75 run particle wax_off ^0.29389 ^0.4 ^-0.40451 0 0 0 0 1
execute if predicate evercraft:mobs/percentages/75 run particle wax_off ^0.47553 ^0.4 ^-0.15451 0 0 0 0 1
execute if predicate evercraft:mobs/percentages/75 run particle wax_off ^0.47553 ^0.4 ^0.15451 0 0 0 0 1
execute if predicate evercraft:mobs/percentages/75 run particle wax_off ^0.29389 ^0.4 ^0.40451 0 0 0 0 1
execute if predicate evercraft:mobs/percentages/75 run particle wax_off ^0 ^0.4 ^0.5 0 0 0 0 1
execute if predicate evercraft:mobs/percentages/75 run particle wax_off ^-0.29389 ^0.4 ^0.40451 0 0 0 0 1
execute if predicate evercraft:mobs/percentages/75 run particle wax_off ^-0.47553 ^0.4 ^0.15451 0 0 0 0 1
execute if predicate evercraft:mobs/percentages/75 run particle wax_off ^-0.47553 ^0.4 ^-0.15451 0 0 0 0 1
execute if predicate evercraft:mobs/percentages/75 run particle wax_off ^-0.29389 ^0.4 ^-0.40451 0 0 0 0 1
