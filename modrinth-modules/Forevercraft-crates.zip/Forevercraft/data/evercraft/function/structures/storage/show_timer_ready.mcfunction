# Display a single ready-to-loot entry to the player
# Run as player. Scores available: #timer_struct, #timer_x/y/z

# Ornate tier structures
execute if score #timer_struct cf.temp matches 1 run tellraw @s [{text:"  ⊳ ",color:"gold"},{text:"Ancient City",color:"dark_aqua"},{text:" (",color:"gray"},{score:{name:"#timer_x",objective:"cf.temp"},color:"white"},{text:", ",color:"gray"},{score:{name:"#timer_y",objective:"cf.temp"},color:"white"},{text:", ",color:"gray"},{score:{name:"#timer_z",objective:"cf.temp"},color:"white"},{text:") — ",color:"gray"},{text:"Ready!",color:"green",bold:true}]

execute if score #timer_struct cf.temp matches 2 run tellraw @s [{text:"  ⊳ ",color:"gold"},{text:"End City",color:"dark_purple"},{text:" (",color:"gray"},{score:{name:"#timer_x",objective:"cf.temp"},color:"white"},{text:", ",color:"gray"},{score:{name:"#timer_y",objective:"cf.temp"},color:"white"},{text:", ",color:"gray"},{score:{name:"#timer_z",objective:"cf.temp"},color:"white"},{text:") — ",color:"gray"},{text:"Ready!",color:"green",bold:true}]

execute if score #timer_struct cf.temp matches 6 run tellraw @s [{text:"  ⊳ ",color:"gold"},{text:"Bastion Remnant",color:"red"},{text:" (",color:"gray"},{score:{name:"#timer_x",objective:"cf.temp"},color:"white"},{text:", ",color:"gray"},{score:{name:"#timer_y",objective:"cf.temp"},color:"white"},{text:", ",color:"gray"},{score:{name:"#timer_z",objective:"cf.temp"},color:"white"},{text:") — ",color:"gray"},{text:"Ready!",color:"green",bold:true}]

# Rare tier structures
execute if score #timer_struct cf.temp matches 3 run tellraw @s [{text:"  ⊳ ",color:"gold"},{text:"Trial Chambers",color:"blue"},{text:" (",color:"gray"},{score:{name:"#timer_x",objective:"cf.temp"},color:"white"},{text:", ",color:"gray"},{score:{name:"#timer_y",objective:"cf.temp"},color:"white"},{text:", ",color:"gray"},{score:{name:"#timer_z",objective:"cf.temp"},color:"white"},{text:") — ",color:"gray"},{text:"Ready!",color:"green",bold:true}]

execute if score #timer_struct cf.temp matches 4 run tellraw @s [{text:"  ⊳ ",color:"gold"},{text:"Stronghold",color:"dark_green"},{text:" (",color:"gray"},{score:{name:"#timer_x",objective:"cf.temp"},color:"white"},{text:", ",color:"gray"},{score:{name:"#timer_y",objective:"cf.temp"},color:"white"},{text:", ",color:"gray"},{score:{name:"#timer_z",objective:"cf.temp"},color:"white"},{text:") — ",color:"gray"},{text:"Ready!",color:"green",bold:true}]

execute if score #timer_struct cf.temp matches 5 run tellraw @s [{text:"  ⊳ ",color:"gold"},{text:"Woodland Mansion",color:"dark_gray"},{text:" (",color:"gray"},{score:{name:"#timer_x",objective:"cf.temp"},color:"white"},{text:", ",color:"gray"},{score:{name:"#timer_y",objective:"cf.temp"},color:"white"},{text:", ",color:"gray"},{score:{name:"#timer_z",objective:"cf.temp"},color:"white"},{text:") — ",color:"gray"},{text:"Ready!",color:"green",bold:true}]

execute if score #timer_struct cf.temp matches 7 run tellraw @s [{text:"  ⊳ ",color:"gold"},{text:"Nether Fortress",color:"dark_red"},{text:" (",color:"gray"},{score:{name:"#timer_x",objective:"cf.temp"},color:"white"},{text:", ",color:"gray"},{score:{name:"#timer_y",objective:"cf.temp"},color:"white"},{text:", ",color:"gray"},{score:{name:"#timer_z",objective:"cf.temp"},color:"white"},{text:") — ",color:"gray"},{text:"Ready!",color:"green",bold:true}]

execute if score #timer_struct cf.temp matches 8 run tellraw @s [{text:"  ⊳ ",color:"gold"},{text:"Ocean Monument",color:"dark_aqua"},{text:" (",color:"gray"},{score:{name:"#timer_x",objective:"cf.temp"},color:"white"},{text:", ",color:"gray"},{score:{name:"#timer_y",objective:"cf.temp"},color:"white"},{text:", ",color:"gray"},{score:{name:"#timer_z",objective:"cf.temp"},color:"white"},{text:") — ",color:"gray"},{text:"Ready!",color:"green",bold:true}]

# Uncommon tier structures
execute if score #timer_struct cf.temp matches 9 run tellraw @s [{text:"  ⊳ ",color:"gold"},{text:"Desert Pyramid",color:"yellow"},{text:" (",color:"gray"},{score:{name:"#timer_x",objective:"cf.temp"},color:"white"},{text:", ",color:"gray"},{score:{name:"#timer_y",objective:"cf.temp"},color:"white"},{text:", ",color:"gray"},{score:{name:"#timer_z",objective:"cf.temp"},color:"white"},{text:") — ",color:"gray"},{text:"Ready!",color:"green",bold:true}]

execute if score #timer_struct cf.temp matches 10 run tellraw @s [{text:"  ⊳ ",color:"gold"},{text:"Jungle Pyramid",color:"green"},{text:" (",color:"gray"},{score:{name:"#timer_x",objective:"cf.temp"},color:"white"},{text:", ",color:"gray"},{score:{name:"#timer_y",objective:"cf.temp"},color:"white"},{text:", ",color:"gray"},{score:{name:"#timer_z",objective:"cf.temp"},color:"white"},{text:") — ",color:"gray"},{text:"Ready!",color:"green",bold:true}]

execute if score #timer_struct cf.temp matches 17 run tellraw @s [{text:"  ⊳ ",color:"gold"},{text:"Mineshaft",color:"gray"},{text:" (",color:"gray"},{score:{name:"#timer_x",objective:"cf.temp"},color:"white"},{text:", ",color:"gray"},{score:{name:"#timer_y",objective:"cf.temp"},color:"white"},{text:", ",color:"gray"},{score:{name:"#timer_z",objective:"cf.temp"},color:"white"},{text:") — ",color:"gray"},{text:"Ready!",color:"green",bold:true}]

# Common tier structures
execute if score #timer_struct cf.temp matches 11 run tellraw @s [{text:"  ⊳ ",color:"gold"},{text:"Shipwreck",color:"aqua"},{text:" (",color:"gray"},{score:{name:"#timer_x",objective:"cf.temp"},color:"white"},{text:", ",color:"gray"},{score:{name:"#timer_y",objective:"cf.temp"},color:"white"},{text:", ",color:"gray"},{score:{name:"#timer_z",objective:"cf.temp"},color:"white"},{text:") — ",color:"gray"},{text:"Ready!",color:"green",bold:true}]

execute if score #timer_struct cf.temp matches 12 run tellraw @s [{text:"  ⊳ ",color:"gold"},{text:"Ocean Ruin",color:"aqua"},{text:" (",color:"gray"},{score:{name:"#timer_x",objective:"cf.temp"},color:"white"},{text:", ",color:"gray"},{score:{name:"#timer_y",objective:"cf.temp"},color:"white"},{text:", ",color:"gray"},{score:{name:"#timer_z",objective:"cf.temp"},color:"white"},{text:") — ",color:"gray"},{text:"Ready!",color:"green",bold:true}]

execute if score #timer_struct cf.temp matches 13 run tellraw @s [{text:"  ⊳ ",color:"gold"},{text:"Igloo",color:"white"},{text:" (",color:"gray"},{score:{name:"#timer_x",objective:"cf.temp"},color:"white"},{text:", ",color:"gray"},{score:{name:"#timer_y",objective:"cf.temp"},color:"white"},{text:", ",color:"gray"},{score:{name:"#timer_z",objective:"cf.temp"},color:"white"},{text:") — ",color:"gray"},{text:"Ready!",color:"green",bold:true}]

execute if score #timer_struct cf.temp matches 14 run tellraw @s [{text:"  ⊳ ",color:"gold"},{text:"Pillager Outpost",color:"dark_gray"},{text:" (",color:"gray"},{score:{name:"#timer_x",objective:"cf.temp"},color:"white"},{text:", ",color:"gray"},{score:{name:"#timer_y",objective:"cf.temp"},color:"white"},{text:", ",color:"gray"},{score:{name:"#timer_z",objective:"cf.temp"},color:"white"},{text:") — ",color:"gray"},{text:"Ready!",color:"green",bold:true}]

execute if score #timer_struct cf.temp matches 15 run tellraw @s [{text:"  ⊳ ",color:"gold"},{text:"Trail Ruins",color:"yellow"},{text:" (",color:"gray"},{score:{name:"#timer_x",objective:"cf.temp"},color:"white"},{text:", ",color:"gray"},{score:{name:"#timer_y",objective:"cf.temp"},color:"white"},{text:", ",color:"gray"},{score:{name:"#timer_z",objective:"cf.temp"},color:"white"},{text:") — ",color:"gray"},{text:"Ready!",color:"green",bold:true}]

execute if score #timer_struct cf.temp matches 16 run tellraw @s [{text:"  ⊳ ",color:"gold"},{text:"Village",color:"green"},{text:" (",color:"gray"},{score:{name:"#timer_x",objective:"cf.temp"},color:"white"},{text:", ",color:"gray"},{score:{name:"#timer_y",objective:"cf.temp"},color:"white"},{text:", ",color:"gray"},{score:{name:"#timer_z",objective:"cf.temp"},color:"white"},{text:") — ",color:"gray"},{text:"Ready!",color:"green",bold:true}]

execute if score #timer_struct cf.temp matches 18 run tellraw @s [{text:"  ⊳ ",color:"gold"},{text:"Ruined Portal",color:"dark_purple"},{text:" (",color:"gray"},{score:{name:"#timer_x",objective:"cf.temp"},color:"white"},{text:", ",color:"gray"},{score:{name:"#timer_y",objective:"cf.temp"},color:"white"},{text:", ",color:"gray"},{score:{name:"#timer_z",objective:"cf.temp"},color:"white"},{text:") — ",color:"gray"},{text:"Ready!",color:"green",bold:true}]

execute if score #timer_struct cf.temp matches 19 run tellraw @s [{text:"  ⊳ ",color:"gold"},{text:"Dungeon",color:"gray"},{text:" (",color:"gray"},{score:{name:"#timer_x",objective:"cf.temp"},color:"white"},{text:", ",color:"gray"},{score:{name:"#timer_y",objective:"cf.temp"},color:"white"},{text:", ",color:"gray"},{score:{name:"#timer_z",objective:"cf.temp"},color:"white"},{text:") — ",color:"gray"},{text:"Ready!",color:"green",bold:true}]

# Unknown / catch-all
execute if score #timer_struct cf.temp matches 20 run tellraw @s [{text:"  ⊳ ",color:"gold"},{text:"Unknown Structure",color:"gray",italic:true},{text:" (",color:"gray"},{score:{name:"#timer_x",objective:"cf.temp"},color:"white"},{text:", ",color:"gray"},{score:{name:"#timer_y",objective:"cf.temp"},color:"white"},{text:", ",color:"gray"},{score:{name:"#timer_z",objective:"cf.temp"},color:"white"},{text:") — ",color:"gray"},{text:"Ready!",color:"green",bold:true}]

execute unless score #timer_struct cf.temp matches 1..20 run tellraw @s [{text:"  ⊳ ",color:"gold"},{text:"Structure",color:"gray",italic:true},{text:" (",color:"gray"},{score:{name:"#timer_x",objective:"cf.temp"},color:"white"},{text:", ",color:"gray"},{score:{name:"#timer_y",objective:"cf.temp"},color:"white"},{text:", ",color:"gray"},{score:{name:"#timer_z",objective:"cf.temp"},color:"white"},{text:") — ",color:"gray"},{text:"Ready!",color:"green",bold:true}]
