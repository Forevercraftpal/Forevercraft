execute at @s run summon area_effect_cloud ~ ~ ~ {Tags:["trim_ward_xp"],Duration:3,wait_time:2,custom_particle:{type:"block",block_state:"minecraft:air"}}
schedule function evercraft:trim/single/ward/xp2 1t append
