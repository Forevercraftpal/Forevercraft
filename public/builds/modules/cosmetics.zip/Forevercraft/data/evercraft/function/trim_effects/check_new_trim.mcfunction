# Trim Effects — Check if untagged player has any trimmed armor
# OPT: Quick 4-slot scan, calls check_all_player only if a trim is found
# This avoids running 10 material check functions for non-trim players
execute if items entity @s armor.head *[trim~{}] run return run function evercraft:trim_effects/check_all_player
execute if items entity @s armor.chest *[trim~{}] run return run function evercraft:trim_effects/check_all_player
execute if items entity @s armor.legs *[trim~{}] run return run function evercraft:trim_effects/check_all_player
execute if items entity @s armor.feet *[trim~{}] run return run function evercraft:trim_effects/check_all_player
