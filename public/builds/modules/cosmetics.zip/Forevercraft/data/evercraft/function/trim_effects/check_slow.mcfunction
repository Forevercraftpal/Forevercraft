# Trim Effects — Attribute-based materials (1s schedule)
# Netherite and Quartz stay per-tick (float mechanics + XP orb processing)
# OPT: Single @a scan dispatches all 10 trim checks per player (was 10 separate @a scans)

# Early exit if no players
execute unless entity @a run return run schedule function evercraft:trim_effects/check_slow 1s

# All trim checks consolidated into one per-player call
# OPT: Tagged players (had trim last tick) get priority — fast path
execute as @a[tag=ec.has_any_trim] at @s run function evercraft:trim_effects/check_all_player
# Untagged players: only call if they actually have trim equipped (4 quick item checks)
# This avoids calling check_all_player (10 material functions) for most players
execute as @a[tag=!ec.has_any_trim] at @s run function evercraft:trim_effects/check_new_trim

# Reschedule
schedule function evercraft:trim_effects/check_slow 1s
