# Daylight Advance Finish — macro helper
# $(ticks) = number of DayTime ticks to add
$time add $(ticks)
scoreboard players set #daylight_counter ec.var 0
