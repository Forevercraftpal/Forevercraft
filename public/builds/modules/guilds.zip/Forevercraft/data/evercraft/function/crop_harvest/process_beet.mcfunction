# Crop Harvest — Process beetroot break (consolidated: replant + ingredient + stat + reset)
# Run as player at position
function evercraft:crop_harvest/on_break {crop:"beetroots"}
execute unless entity @s[tag=ec.crop_rolled] run function evercraft:crop_harvest/try_ingredient_drop
tag @s add ec.crop_rolled
scoreboard players operation @s adv.stat_harvest += @s ec.rh_beet
scoreboard players set @s ec.rh_beet 0
