# Crop Auto-Replant — Detect crop breaks while holding a hoe
# Uses minecraft.mined stats per crop type; raycasts to find the empty spot and replants
# OPT: Consolidated replant + ingredient + stat + reset into 1 @a scan per crop (was 3)

# Per-crop: single dispatch handles replant, ingredient drop, stat tracking, and reset
execute as @a[scores={ec.rh_wheat=1..}] at @s run function evercraft:crop_harvest/process_wheat
execute as @a[scores={ec.rh_carrot=1..}] at @s run function evercraft:crop_harvest/process_carrot
execute as @a[scores={ec.rh_potato=1..}] at @s run function evercraft:crop_harvest/process_potato
execute as @a[scores={ec.rh_beet=1..}] at @s run function evercraft:crop_harvest/process_beet
execute as @a[scores={ec.rh_nwart=1..}] at @s run function evercraft:crop_harvest/process_nwart

# Clear ingredient drop dedup tag (prevents double-rolling when multiple crop types broken in same tick)
tag @a[tag=ec.crop_rolled] remove ec.crop_rolled

# 3% chance to drop a forging ingredient on ore mining (checked every 4 ticks)
# OPT: Gated to players who actually mined ore (was all players)
scoreboard players add #ore_poll ec.var 1
execute if score #ore_poll ec.var matches 4.. run scoreboard players set #ore_poll ec.var 0
# OPT: Only scan players who have broken at least 1 ore ever (ec.ore_prev set in first run)
# Players who never mine ore never enter ore_ingredient_check (saves 16 score ops/player/4t)
execute if score #ore_poll ec.var matches 0 as @a[scores={ec.ore_prev=0..}] at @s run function evercraft:crop_harvest/ore_ingredient_check
