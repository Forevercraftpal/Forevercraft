# Tab page previous — runs as interaction entity
data remove entity @s interaction
scoreboard players set #ck_clicked ec.temp 1

# Switch to page 0 if on page 1
execute as @a[tag=CK.InMenu,distance=..5,limit=1] if score @s ec.ck_tab_page matches 1 run scoreboard players set @s ec.ck_tab_page 0
execute as @a[tag=CK.InMenu,distance=..5,limit=1] if score @s ec.ck_tab_page matches 0 run function evercraft:cooking/gui/refresh_tabs

playsound minecraft:ui.button.click master @a[tag=CK.InMenu,distance=..5,limit=1] ~ ~ ~ 0.5 1.0
