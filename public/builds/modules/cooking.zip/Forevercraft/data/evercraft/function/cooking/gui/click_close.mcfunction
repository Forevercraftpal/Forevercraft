# ============================================================
# Campfire Kitchen GUI — Close Button Click Handler
# Runs as the interaction entity, at its position
# ============================================================

# Clear click data + flag click handled
data remove entity @s interaction
scoreboard players set #ck_clicked ec.temp 1

# Close the GUI (runs as the player)
execute as @a[tag=CK.InMenu,distance=..5,limit=1] run function evercraft:cooking/gui/close
