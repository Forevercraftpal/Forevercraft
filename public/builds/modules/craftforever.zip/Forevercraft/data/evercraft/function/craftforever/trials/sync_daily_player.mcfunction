# Sync global daily challenge data to individual player
# OPT: Called once per player instead of 4 separate @a scans
scoreboard players operation @s ec.tt_daily_type = #tt_daily_type ec.var
scoreboard players operation @s ec.tt_daily_tier = #tt_daily_tier ec.var
scoreboard players set @s ec.tt_daily_done 0
scoreboard players operation @s ec.tt_daily_day = #tt_today ec.var
