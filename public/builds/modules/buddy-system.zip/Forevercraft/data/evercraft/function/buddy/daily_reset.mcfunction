# Buddy System — Daily reset (fires once when day changes)
# Resets daily feed and summon counters, then updates day tracker
# OPT: Only reset players who have buddies (was @a — unnecessarily touched all players)
scoreboard players set @a[scores={ec.bd_tier=0..}] ec.bd_feed_today 0
scoreboard players set @a[scores={ec.bd_tier=0..}] ec.bd_summon_ct 0
scoreboard players operation #bd_last_day ec.var = #visual_day ec.var
