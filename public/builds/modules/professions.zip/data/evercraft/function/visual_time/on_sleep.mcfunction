# Visual Time — On Sleep (advancement reward, fires when player enters bed)
# Revoke immediately so it re-triggers next sleep
advancement revoke @s only evercraft:visual_time/on_sleep

# === SLEEP FADE ===
# Blindness gives a smooth blackout transition while waiting for vanilla sleep to complete
effect give @s blindness 3 0 true

# === DREAMING REALM ENTRY ===
# Check while player is still in bed (before vanilla completes the skip)
function evercraft:dreaming_realm/check_entry
