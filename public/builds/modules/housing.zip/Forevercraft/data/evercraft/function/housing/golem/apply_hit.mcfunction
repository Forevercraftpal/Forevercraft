# Housing — Apply snow golem snowball damage
# Run as: snowball (hs.snowball), at snowball position
# A valid target is within 1.5 blocks — deal 3 damage and consume the snowball

damage @e[type=#evercraft:aoe_targets,type=!snow_golem,distance=..1.5,limit=1,sort=nearest] 3 minecraft:mob_attack
kill @s
