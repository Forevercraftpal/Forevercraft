# Stash Label Visibility — Tick (called from housing/tick, gated by StashDisplay existence)
# Shows stash labels when a homeowner holds the labeler item, hides otherwise

# Tag displays near players holding labelers
execute as @a[scores={hs.tier=1..}] at @s if items entity @s weapon.mainhand *[custom_data~{stash_label:true}] run tag @e[type=text_display,tag=HS.StashDisplay,distance=..32] add HS.ShowLabel

# OPT: Only write view_range when state changes (avoids redundant NBT writes)
execute as @e[type=text_display,tag=HS.StashDisplay,tag=HS.ShowLabel,tag=!HS.LabelVisible] run function evercraft:housing/stash/label_show
execute as @e[type=text_display,tag=HS.StashDisplay,tag=!HS.ShowLabel,tag=HS.LabelVisible] run function evercraft:housing/stash/label_hide
tag @e[type=text_display,tag=HS.ShowLabel] remove HS.ShowLabel
