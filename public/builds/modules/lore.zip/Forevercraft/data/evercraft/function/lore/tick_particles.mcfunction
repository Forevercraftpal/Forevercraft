# Lore Discovery: Render sparkle particles (10-tick schedule)
schedule function evercraft:lore/tick_particles 10t

# Gate: skip if no players online
execute unless entity @a run return 0

# Only render for sparkles near players (performance optimization)
# OPT: Capped at 50 to prevent worst-case in heavily-explored worlds
execute as @e[type=marker,tag=ec.lore_data,limit=50] at @s if entity @a[distance=..48] run function evercraft:lore/render_sparkle
