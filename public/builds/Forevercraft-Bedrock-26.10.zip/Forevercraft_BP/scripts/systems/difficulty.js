/**
 * Per-Player Difficulty System — Newcomer & Adventurer modes.
 * Newcomer: reduced mob damage, lower patron spawn rates, better drop rates.
 * Adventurer: standard difficulty (default).
 * Persistent per-player setting.
 */
import { world, system } from "@minecraft/server";
import { StorageManager } from "../utils/storage.js";
import { ActionFormData } from "@minecraft/server-ui";

const DIFFICULTY_MODES = {
  newcomer: {
    id: "newcomer",
    name: "Newcomer",
    color: "§a",
    icon: "🌱",
    description: "Gentler experience for new players",
    mobDamageMult: 0.6,     // mobs deal 40% less damage
    patronSpawnMult: 0.5,    // 50% fewer patron spawns
    dropRateMult: 1.3,       // 30% better drops
    xpMult: 1.5,             // 50% more XP
    deathPenaltyMult: 0.5,   // 50% less death penalty
  },
  adventurer: {
    id: "adventurer",
    name: "Adventurer",
    color: "§e",
    icon: "⚔",
    description: "Standard Forevercraft experience",
    mobDamageMult: 1.0,
    patronSpawnMult: 1.0,
    dropRateMult: 1.0,
    xpMult: 1.0,
    deathPenaltyMult: 1.0,
  },
};

export class DifficultySystem {
  constructor(eventBridge) {
    this.eventBridge = eventBridge;

    // Set default difficulty for new players
    eventBridge.on("player_first_join", (player) => {
      const storage = StorageManager.forPlayer(player);
      if (!storage.getString("difficulty_mode")) {
        this.promptDifficulty(player);
      }
    });
  }

  /**
   * Get a player's current difficulty mode config.
   */
  getMode(player) {
    const storage = StorageManager.forPlayer(player);
    const mode = storage.getString("difficulty_mode") || "adventurer";
    return DIFFICULTY_MODES[mode] || DIFFICULTY_MODES.adventurer;
  }

  /**
   * Get a specific multiplier for a player.
   */
  getMobDamageMult(player) { return this.getMode(player).mobDamageMult; }
  getPatronSpawnMult(player) { return this.getMode(player).patronSpawnMult; }
  getDropRateMult(player) { return this.getMode(player).dropRateMult; }
  getXpMult(player) { return this.getMode(player).xpMult; }
  getDeathPenaltyMult(player) { return this.getMode(player).deathPenaltyMult; }

  /**
   * Prompt a new player to choose difficulty.
   */
  promptDifficulty(player) {
    system.runTimeout(() => {
      const form = new ActionFormData()
        .title("§eWelcome to Forevercraft!")
        .body(
          "§7Choose your play style:\n\n" +
          "§a🌱 Newcomer\n" +
          "§7Mobs deal less damage, better drops, more XP.\n" +
          "§7Perfect for learning the systems.\n\n" +
          "§e⚔ Adventurer\n" +
          "§7Standard difficulty — the intended experience.\n" +
          "§7Full challenge, full rewards.\n\n" +
          "§8You can change this anytime via /scriptevent forevercraft:difficulty"
        )
        .button("§a🌱 Newcomer")
        .button("§e⚔ Adventurer");

      form.show(player).then((r) => {
        if (r.canceled) {
          // Default to adventurer if they close
          this.setMode(player, "adventurer");
          return;
        }
        this.setMode(player, r.selection === 0 ? "newcomer" : "adventurer");
      });
    }, 100); // 5 second delay after join
  }

  /**
   * Set a player's difficulty mode.
   */
  setMode(player, modeId) {
    const mode = DIFFICULTY_MODES[modeId];
    if (!mode) return;

    const storage = StorageManager.forPlayer(player);
    storage.set("difficulty_mode", modeId);

    player.sendMessage(`${mode.color}§l${mode.icon} Difficulty set to ${mode.name}!`);

    if (modeId === "newcomer") {
      player.sendMessage("§7Mob damage: §a-40%§7 | Drops: §a+30%§7 | XP: §a+50%");
    } else {
      player.sendMessage("§7Standard difficulty — full challenge, full rewards.");
    }

    this.eventBridge.emit("difficulty_changed", player, modeId);
  }

  /**
   * Open difficulty settings menu.
   */
  openMenu(player) {
    const currentMode = this.getMode(player);

    const form = new ActionFormData()
      .title("§eDifficulty Settings")
      .body(
        `§7Current: ${currentMode.color}${currentMode.icon} ${currentMode.name}\n\n` +
        `§7Damage taken: §f${Math.round(currentMode.mobDamageMult * 100)}%\n` +
        `§7Patron spawns: §f${Math.round(currentMode.patronSpawnMult * 100)}%\n` +
        `§7Drop rate bonus: §f${Math.round((currentMode.dropRateMult - 1) * 100)}%\n` +
        `§7XP bonus: §f${Math.round((currentMode.xpMult - 1) * 100)}%\n` +
        `§7Death penalty: §f${Math.round(currentMode.deathPenaltyMult * 100)}%`
      )
      .button("§a🌱 Switch to Newcomer")
      .button("§e⚔ Switch to Adventurer")
      .button("§7Cancel");

    form.show(player).then((r) => {
      if (r.canceled || r.selection === 2) return;
      const newMode = r.selection === 0 ? "newcomer" : "adventurer";
      if (newMode === currentMode.id) {
        player.sendMessage("§7You're already on that difficulty.");
        return;
      }
      this.setMode(player, newMode);
    });
  }
}
