/**
 * Artifact Transmutation System — Deposit N artifacts of same tier → 1 of next tier.
 * GUI-based with Artificer NPC discount. Mythical reroll with exclusion.
 * Replaces Java transmute/ folder (28 files).
 */
import { world, system } from "@minecraft/server";
import { StorageManager } from "../utils/storage.js";
import { ActionFormData } from "@minecraft/server-ui";

// Tier definitions
const TIERS = [
  { id: 1, name: "Common", color: "§f", cost: 5 },
  { id: 2, name: "Uncommon", color: "§9", cost: 5 },
  { id: 3, name: "Rare", color: "§b", cost: 4 },
  { id: 4, name: "Ornate", color: "§5", cost: 4 },
  { id: 5, name: "Exquisite", color: "§d", cost: 3 },
  { id: 6, name: "Mythical", color: "§6", cost: 2 },
];

function getTierInfo(tierId) {
  return TIERS.find((t) => t.id === tierId) || TIERS[0];
}

function getNextTierInfo(tierId) {
  if (tierId >= 6) return getTierInfo(6); // Mythical rerolls into Mythical
  return getTierInfo(tierId + 1);
}

export class TransmuteSystem {
  constructor(eventBridge) {
    this.eventBridge = eventBridge;

    // Per-player transmutation state
    this.sessions = new Map(); // playerId → { tier, count, required, deposited[] }
  }

  /**
   * Open the transmutation menu.
   */
  openMenu(player) {
    const session = this.getOrCreateSession(player);
    const tier = getTierInfo(session.tier || 1);
    const nextTier = getNextTierInfo(session.tier || 1);
    const s = StorageManager.forPlayer(player);

    // Check Artificer discount
    const hasDiscount = this.checkArtificerDiscount(player);
    let required = tier.cost;
    if (hasDiscount && session.tier < 6) required = Math.max(1, required - 1);
    session.required = required;

    let body = "§6§lArtifact Transmutation\n\n";

    if (session.tier > 0) {
      body += `§7Tier: ${tier.color}${tier.name}\n`;
      body += `§7Deposited: §f${session.count}/${required}\n`;
      body += `§7Result: ${tier.color}${tier.name} §7→ ${nextTier.color}${nextTier.name}\n\n`;
    } else {
      body += "§7Deposit artifacts of the same tier to transmute.\n";
      body += "§7The first deposit sets the tier.\n\n";
    }

    if (hasDiscount && session.tier < 6) {
      body += "§a✦ Artificer nearby! Cost reduced by 1.\n\n";
    }

    body += "§7Hold an artifact and press Deposit.\n";
    body += `§7Need: ${session.tier > 0 ? required - session.count : "?"} more artifacts.\n`;

    const form = new ActionFormData()
      .title("§6⚗ Transmutation Stand")
      .body(body);

    // Deposit button
    if (session.count < (session.required || 5)) {
      form.button("§eDeposit Held Artifact");
    } else {
      form.button("§8Slots Full");
    }

    // Transmute button
    if (session.count >= (session.required || 999)) {
      form.button("§a§lTransmute!");
    } else {
      form.button("§8Transmute (need more)");
    }

    form.button("§cReset")
      .button("§7Close");

    form.show(player).then((r) => {
      if (r.canceled || r.selection === 3) return;
      switch (r.selection) {
        case 0: this.deposit(player); break;
        case 1: this.transmute(player); break;
        case 2: this.resetSession(player); break;
      }
    });
  }

  getOrCreateSession(player) {
    if (!this.sessions.has(player.id)) {
      this.sessions.set(player.id, {
        tier: 0,
        count: 0,
        required: 5,
        deposited: [],
      });
    }
    return this.sessions.get(player.id);
  }

  resetSession(player) {
    this.sessions.delete(player.id);
    player.sendMessage("§7Transmutation stand reset.");
    this.openMenu(player);
  }

  /**
   * Deposit the held artifact.
   */
  deposit(player) {
    const session = this.getOrCreateSession(player);

    if (session.count >= session.required) {
      player.sendMessage("§cSlots are full! Transmute or reset.");
      this.openMenu(player);
      return;
    }

    // Check held item
    const equip = player.getComponent("minecraft:equippable");
    const mainhand = equip?.getEquipment("Mainhand");

    if (!mainhand) {
      player.sendMessage("§cHold an artifact to deposit!");
      this.openMenu(player);
      return;
    }

    // Determine artifact tier from item tags or typeId
    const tier = this.getItemTier(mainhand);
    if (tier === 0) {
      player.sendMessage("§cThis item is not a transmutable artifact!");
      this.openMenu(player);
      return;
    }

    // First deposit sets the tier
    if (session.tier === 0) {
      session.tier = tier;
      const hasDiscount = this.checkArtificerDiscount(player);
      const tierInfo = getTierInfo(tier);
      session.required = tierInfo.cost;
      if (hasDiscount && tier < 6) session.required = Math.max(1, session.required - 1);
    }

    // Must match tier
    if (tier !== session.tier) {
      const expected = getTierInfo(session.tier);
      player.sendMessage(`§cMust deposit ${expected.color}${expected.name} §cartifacts!`);
      this.openMenu(player);
      return;
    }

    // Consume the item
    session.deposited.push(mainhand.typeId);
    session.count++;
    equip.setEquipment("Mainhand", undefined);

    player.sendMessage(`§7Deposited! §f(${session.count}/${session.required})`);
    try { player.playSound("block.anvil.use", { volume: 0.3, pitch: 1.2 }); } catch {}

    this.openMenu(player);
  }

  /**
   * Perform the transmutation.
   */
  transmute(player) {
    const session = this.getOrCreateSession(player);

    if (session.count < session.required || session.tier === 0) {
      player.sendMessage("§cNot enough artifacts deposited!");
      this.openMenu(player);
      return;
    }

    const nextTier = getNextTierInfo(session.tier);

    // Roll result from next tier loot pool
    // For simplicity, emit an event that crate/artifact systems can handle
    this.eventBridge.emit("transmute_roll", player, session.tier, nextTier.id, session.deposited);

    // Track stats
    const s = StorageManager.forPlayer(player);
    s.set("transmutes_done", (s.getNumber("transmutes_done", 0)) + 1);

    // Effects
    player.sendMessage(`§6§l✦ Transmutation Complete! §7Received a ${nextTier.color}${nextTier.name} §7artifact!`);
    try {
      player.playSound("block.anvil.land", { volume: 0.5, pitch: 1.0 });
      player.playSound("random.levelup", { volume: 0.5, pitch: 1.2 });
    } catch {}

    // Reset session
    this.sessions.delete(player.id);
    this.openMenu(player);
  }

  /**
   * Get artifact tier from item.
   */
  getItemTier(item) {
    if (!item) return 0;
    const typeId = item.typeId || "";

    // Check tags
    if (item.hasTag?.("forevercraft:mythical")) return 6;
    if (item.hasTag?.("forevercraft:exquisite")) return 5;
    if (item.hasTag?.("forevercraft:ornate")) return 4;
    if (item.hasTag?.("forevercraft:rare")) return 3;
    if (item.hasTag?.("forevercraft:uncommon")) return 2;
    if (item.hasTag?.("forevercraft:common") || item.hasTag?.("forevercraft:artifact")) return 1;

    // Check name patterns
    if (typeId.includes("mythical")) return 6;
    if (typeId.includes("exquisite")) return 5;
    if (typeId.includes("ornate")) return 4;

    return 0;
  }

  /**
   * Check if an Artificer NPC is nearby (within 12 blocks) and discount not used today.
   */
  checkArtificerDiscount(player) {
    const s = StorageManager.forPlayer(player);
    const today = (globalThis._fc_daylight?.getDay?.() ?? 0);
    const lastDiscount = s.getNumber("tx_disc_day", -1);

    if (lastDiscount === today) return false; // Already used today

    // Check for Artificer NPC nearby
    try {
      const nearby = player.dimension.getEntities({
        location: player.location,
        maxDistance: 12,
        tags: ["ec.artificer"],
      });
      return nearby.length > 0;
    } catch {
      return false;
    }
  }

  // ─── AWAKENING STONE DEPOSIT (half-value artifact) ────────
  // Awakening Stones count as half an artifact deposit (0.5 value).
  // Two Awakening Stones = 1 artifact slot.

  /** Deposit an awakening stone (half-value) */
  depositAwakeningStone(player) {
    const session = this.getOrCreateSession(player);

    if (session.count >= session.required) {
      player.sendMessage("§cSlots are full! Transmute or reset.");
      this.openMenu(player);
      return;
    }

    // Check held item
    const equip = player.getComponent("minecraft:equippable");
    const mainhand = equip?.getEquipment("Mainhand");
    if (!mainhand) {
      player.sendMessage("§cHold an Awakening Stone to deposit!");
      this.openMenu(player);
      return;
    }

    const tags = mainhand.getTags?.() || [];
    const isAwakening = tags.some(t => t.includes("awakening_stone")) ||
                        mainhand.typeId?.includes("awakening_stone");
    if (!isAwakening) {
      player.sendMessage("§cThis is not an Awakening Stone!");
      this.openMenu(player);
      return;
    }

    // First deposit: set tier from the stone's tier
    if (session.tier === 0) {
      // Awakening stones match the tier they were for
      const stoneTier = this.getAwakeningTier(mainhand);
      if (stoneTier === 0) {
        player.sendMessage("§cCouldn't determine stone tier.");
        return;
      }
      session.tier = stoneTier;
      const hasDiscount = this.checkArtificerDiscount(player);
      const tierInfo = getTierInfo(stoneTier);
      session.required = tierInfo.cost;
      if (hasDiscount && stoneTier < 6) session.required = Math.max(1, session.required - 1);
    }

    // Track half deposits
    if (!session.halfDeposit) session.halfDeposit = 0;
    session.halfDeposit++;

    // Consume the stone
    if (mainhand.amount > 1) {
      mainhand.amount -= 1;
      equip.setEquipment("Mainhand", mainhand);
    } else {
      equip.setEquipment("Mainhand", undefined);
    }

    // Every 2 halves = 1 full deposit
    if (session.halfDeposit >= 2) {
      session.halfDeposit = 0;
      session.count++;
      session.deposited.push("awakening_stone_pair");
      player.sendMessage(`§7Deposited! §f(${session.count}/${session.required})`);
    } else {
      player.sendMessage(`§7Half deposit! §f(${session.count}.5/${session.required})`);
    }

    try { player.playSound("block.anvil.use", { volume: 0.3, pitch: 1.4 }); } catch {}
    this.openMenu(player);
  }

  /** Get tier of an awakening stone */
  getAwakeningTier(item) {
    const tags = item.getTags?.() || [];
    for (const tag of tags) {
      if (tag.includes("mythical")) return 6;
      if (tag.includes("exquisite")) return 5;
      if (tag.includes("ornate")) return 4;
      if (tag.includes("rare")) return 3;
      if (tag.includes("uncommon")) return 2;
      if (tag.includes("common")) return 1;
    }
    // Default to common
    return 1;
  }
}
