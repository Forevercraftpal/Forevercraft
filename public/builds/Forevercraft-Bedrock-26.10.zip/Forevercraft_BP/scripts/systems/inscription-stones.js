/**
 * Inscription Stone System — Area-effect rune zones from glyph stones.
 * Replaces Java inscription/ folder.
 *
 * Players right-click polished deepslate with a glyph to create a zone.
 * Each zone type applies different effects to players/entities in range.
 * 13 zone types matching the 13 glyphforge runes.
 */
import { world, system } from "@minecraft/server";
import { StorageManager } from "../utils/storage.js";

// ─── ZONE DEFINITIONS ─────────────────────────────────────
const ZONES = [
  { id: 1,  key: "emberheart",  name: "Force Zone",       color: "§c", radius: 8,  effectType: "player_buff",  effect: "strength",      amplifier: 0, duration: 10, desc: "Increases attack damage nearby" },
  { id: 2,  key: "verdant",     name: "Growth Zone",      color: "§a", radius: 12, effectType: "growth",       effect: null,             amplifier: 0, duration: 0,  desc: "Accelerates crop growth" },
  { id: 3,  key: "quicksilver", name: "Haste Zone",       color: "§b", radius: 8,  effectType: "player_buff",  effect: "haste",         amplifier: 1, duration: 10, desc: "Grants Haste II" },
  { id: 4,  key: "obsidian",    name: "Thornmail Zone",   color: "§8", radius: 8,  effectType: "player_buff",  effect: "resistance",    amplifier: 0, duration: 10, desc: "Grants damage resistance" },
  { id: 5,  key: "zephyr",      name: "Wind Zone",        color: "§f", radius: 10, effectType: "player_multi", effects: ["speed", "jump_boost"], amplifiers: [1, 0], duration: 10, desc: "Speed + Jump Boost" },
  { id: 6,  key: "briar",       name: "Guardian Zone",    color: "§2", radius: 8,  effectType: "player_buff",  effect: "resistance",    amplifier: 0, duration: 10, desc: "Increases armor nearby" },
  { id: 7,  key: "stalwart",    name: "Fortify Zone",     color: "§6", radius: 8,  effectType: "player_buff",  effect: "strength",      amplifier: 0, duration: 10, desc: "Grants Strength nearby" },
  { id: 8,  key: "gilded",      name: "Gold Greed Zone",  color: "§e", radius: 10, effectType: "player_buff",  effect: "absorption",    amplifier: 0, duration: 10, desc: "Increases luck (Dream Rate +0.25)" },
  { id: 9,  key: "tidecall",    name: "Life Steal Zone",  color: "§3", radius: 8,  effectType: "player_buff",  effect: "regeneration",  amplifier: 0, duration: 10, desc: "Grants Regeneration" },
  { id: 10, key: "hearthstone", name: "Absorption Zone",  color: "§6", radius: 8,  effectType: "player_buff",  effect: "absorption",    amplifier: 0, duration: 10, desc: "Grants Absorption" },
  { id: 11, key: "prism",       name: "Reveal Zone",      color: "§d", radius: 16, effectType: "mob_debuff",   effect: "glowing",       amplifier: 0, duration: 10, desc: "Reveals hostile mobs" },
  { id: 12, key: "tempest",     name: "Frostbite Zone",   color: "§9", radius: 8,  effectType: "mob_debuff",   effect: "slowness",      amplifier: 1, duration: 10, desc: "Weakens and slows enemies" },
  { id: 13, key: "arcanum",     name: "Wild Magic Zone",  color: "§5", radius: 10, effectType: "random",       effect: null,            amplifier: 0, duration: 10, desc: "Random positive effects" },
];

// ─── RUNE WORD COMBOS (two stones within 5 blocks) ────────
const RUNE_WORDS = [
  { id: "paradox",   stones: ["emberheart", "tempest"],    name: "Paradox",   color: "§c", effects: ["resistance", "fire_resistance"], amplifiers: [0, 0], desc: "Resistance I + Fire Resistance" },
  { id: "tempest_rw", stones: ["stalwart", "zephyr"],      name: "Tempest",   color: "§f", effects: ["jump_boost"],                    amplifiers: [1],    desc: "Jump Boost II" },
  { id: "fury",      stones: ["quicksilver", "emberheart"], name: "Fury",      color: "§c", effects: ["strength"],                      amplifiers: [1],    desc: "Strength II" },
  { id: "sanctuary", stones: ["hearthstone", "tidecall"],   name: "Sanctuary", color: "§a", effects: ["regeneration"],                   amplifiers: [1],    desc: "Regeneration II" },
  { id: "bastion",   stones: ["briar", "obsidian"],         name: "Bastion",   color: "§8", effects: ["resistance"],                     amplifiers: [0],    desc: "+4 Armor + Resistance I" },
  { id: "oracle",    stones: ["prism", "arcanum"],          name: "Oracle",    color: "§d", effects: ["absorption", "night_vision"],     amplifiers: [0, 0], desc: "Absorption I + Night Vision" },
];
const RUNE_WORD_RANGE = 5; // blocks between two stones to form a rune word
const RUNE_WORD_EFFECT_RANGE = 12; // effect radius

// Random effects pool for Arcanum/Wild Magic
const RANDOM_EFFECTS = [
  { effect: "strength", amplifier: 1 },
  { effect: "speed", amplifier: 1 },
  { effect: "regeneration", amplifier: 1 },
  { effect: "resistance", amplifier: 0 },
  { effect: "jump_boost", amplifier: 1 },
  { effect: "haste", amplifier: 1 },
  { effect: "absorption", amplifier: 1 },
  { effect: "night_vision", amplifier: 0 },
  { effect: "fire_resistance", amplifier: 0 },
];

const AUTO_OFF_TICKS = 24000; // 1 day of game ticks = auto-disable

export class InscriptionStoneSystem {
  constructor(eventBridge) {
    this.stones = new Map(); // stoneKey → stone data
    this.tickCounter = 0;

    // Block interaction for deepslate (inscription placement / toggle)
    world.afterEvents.playerInteractWithBlock.subscribe((event) => {
      const block = event.block;
      if (block?.typeId === "minecraft:polished_deepslate") {
        this.onDeepslateInteract(event.player, block);
      }
    });
  }

  // ─── STONE PLACEMENT ────────────────────────────────────

  onDeepslateInteract(player, block) {
    const loc = block.location;
    const key = `${Math.floor(loc.x)}_${Math.floor(loc.y)}_${Math.floor(loc.z)}`;

    // Check if already an inscription stone
    if (this.stones.has(key)) {
      const stone = this.stones.get(key);

      // Shift+right-click = toggle on/off (owner only)
      if (player.isSneaking) {
        if (stone.owner === player.name) {
          this.toggleStone(player, key, stone);
        } else {
          player.sendMessage("§7Only the owner can toggle this inscription stone.");
        }
        return;
      }

      this.showStoneInfo(player, stone);
      return;
    }

    // Check if player is holding a glyph
    const equip = player.getComponent("minecraft:equippable");
    const mainhand = equip?.getEquipment("Mainhand");
    if (!mainhand) return;

    const tags = mainhand.getTags?.() || [];
    let foundZone = null;

    for (const zone of ZONES) {
      if (tags.some(t => t.includes(zone.key) || t.includes(`ec.${zone.key}`))) {
        foundZone = zone;
        break;
      }
    }

    // Also check by glyph item tag pattern
    if (!foundZone) {
      const glyphKeys = {
        "ec.ember": 1, "ec.verdant": 2, "ec.quick": 3, "ec.obsidian": 4,
        "ec.zephyr": 5, "ec.briar": 6, "ec.stalwart": 7, "ec.gilded": 8,
        "ec.tide": 9, "ec.hearth": 10, "ec.prism": 11, "ec.tempest": 12,
        "ec.arcanum": 13,
      };
      for (const tag of tags) {
        for (const [glyphTag, zoneId] of Object.entries(glyphKeys)) {
          if (tag.includes(glyphTag)) {
            foundZone = ZONES.find(z => z.id === zoneId);
            break;
          }
        }
        if (foundZone) break;
      }
    }

    if (!foundZone) {
      // Not holding a glyph — show selection menu
      if (player.hasTag("ec.has_glyph")) {
        this.showGlyphSelection(player, block, key);
      }
      return;
    }

    this.placeStone(player, block, key, foundZone);
  }

  placeStone(player, block, stoneKey, zone) {
    // Consume glyph
    const equip = player.getComponent("minecraft:equippable");
    const mainhand = equip?.getEquipment("Mainhand");
    if (mainhand) {
      try { player.runCommandAsync(`clear @s ${mainhand.typeId} 1`); } catch {}
    }

    const stoneData = {
      id: zone.id,
      key: zone.key,
      name: zone.name,
      location: { x: block.location.x, y: block.location.y, z: block.location.z },
      dimension: player.dimension.id,
      radius: zone.radius,
      owner: player.name,
      createdAt: system.currentTick,
      active: true,
      activatedAt: system.currentTick,
    };

    this.stones.set(stoneKey, stoneData);

    // Persist
    const ws = StorageManager.world();
    ws.set(`stone_${stoneKey}`, JSON.stringify(stoneData));

    player.sendMessage(`${zone.color}§l✦ ${zone.name} §r§7inscribed! Radius: §f${zone.radius} blocks`);
    player.sendMessage(`§7${zone.desc}`);
    player.playSound("block.enchanting_table.use");

    // Track
    const s = StorageManager.forPlayer(player);
    const placed = s.getNumber("stones_placed") + 1;
    s.set("stones_placed", placed);
  }

  showGlyphSelection(player, block, stoneKey) {
    const { ActionFormData } = require("@minecraft/server-ui");
    const form = new ActionFormData()
      .title("§5Inscribe Stone")
      .body("§7Select a glyph to inscribe on this deepslate:");

    for (const zone of ZONES) {
      form.button(`${zone.color}${zone.name}\n§7${zone.desc}`);
    }
    form.button("§7[ Cancel ]");

    form.show(player).then(response => {
      if (response.canceled || response.selection === ZONES.length) return;
      const selectedZone = ZONES[response.selection];
      if (selectedZone) this.placeStone(player, block, stoneKey, selectedZone);
    });
  }

  /** Toggle stone active/inactive — shift+right-click */
  toggleStone(player, stoneKey, stone) {
    stone.active = !stone.active;
    if (stone.active) {
      stone.activatedAt = system.currentTick;
      player.sendMessage(`§a§l✦ §r§7Inscription stone §aactivated§7! Auto-disables after 1 day.`);
      player.playSound("block.respawn_anchor.charge", { volume: 0.6, pitch: 1.2 });
      try {
        const loc = stone.location;
        player.dimension.runCommandAsync(`particle minecraft:enchanting_table_particle ${loc.x} ${loc.y + 1} ${loc.z} 0.5 0.5 0.5 0.1 20`);
      } catch {}
    } else {
      player.sendMessage(`§c§l✦ §r§7Inscription stone §cdeactivated§7.`);
      player.playSound("block.respawn_anchor.deplete", { volume: 0.6, pitch: 1.0 });
    }

    // Persist
    const ws = StorageManager.world();
    ws.set(`stone_${stoneKey}`, JSON.stringify(stone));
  }

  showStoneInfo(player, stone) {
    const zone = ZONES.find(z => z.id === stone.id);
    if (!zone) return;

    const status = stone.active !== false ? "§aActive" : "§cInactive";
    player.sendMessage(`${zone.color}§l✦ ${zone.name} §r${status}`);
    player.sendMessage(`§7${zone.desc}`);
    player.sendMessage(`§7Radius: §f${zone.radius} blocks | Owner: §f${stone.owner}`);
    if (stone.owner === player.name) {
      player.sendMessage("§7§oShift+Right-Click to toggle on/off");
    }
  }

  // ─── ZONE EFFECTS (TICK) ────────────────────────────────

  /** Called every 2 seconds from main tick */
  tick(players) {
    this.tickCounter++;

    const now = system.currentTick;

    for (const [key, stone] of this.stones) {
      const zone = ZONES.find(z => z.id === stone.id);
      if (!zone) continue;

      // Auto-off after 1 day (24000 ticks)
      if (stone.active !== false && stone.activatedAt) {
        if (now - stone.activatedAt >= AUTO_OFF_TICKS) {
          stone.active = false;
          const ws = StorageManager.world();
          ws.set(`stone_${key}`, JSON.stringify(stone));
          // Notify owner if online
          for (const p of players) {
            if (p.name === stone.owner) {
              p.sendMessage(`§c§l✦ §r§7Your §f${zone.name}§7 inscription stone has auto-deactivated after 1 day.`);
              p.playSound("block.respawn_anchor.deplete", { volume: 0.4, pitch: 0.8 });
            }
          }
        }
      }

      // Skip inactive stones
      if (stone.active === false) continue;

      // Find players in range
      for (const player of players) {
        if (player.dimension.id !== stone.dimension) continue;

        const dx = player.location.x - stone.location.x;
        const dy = player.location.y - stone.location.y;
        const dz = player.location.z - stone.location.z;
        const dist = Math.sqrt(dx * dx + dy * dy + dz * dz);

        if (dist > zone.radius) continue;

        // Apply zone effect
        this.applyZoneEffect(player, zone, stone);
      }

      // Apply mob effects for debuff zones
      if (zone.effectType === "mob_debuff") {
        this.applyMobDebuff(stone, zone);
      }
    }

    // ─── RUNE WORD CHECKS ──────────────────────────────────
    this.checkRuneWords(players);
  }

  /** Check for rune word combos (two stones within 5 blocks) */
  checkRuneWords(players) {
    const stoneList = [...this.stones.values()];
    if (stoneList.length < 2) return;

    for (const rw of RUNE_WORDS) {
      // Find pairs of stones that match this rune word
      for (let i = 0; i < stoneList.length; i++) {
        const s1 = stoneList[i];
        const z1 = ZONES.find(z => z.id === s1.id);
        if (!z1 || !rw.stones.includes(z1.key)) continue;

        for (let j = i + 1; j < stoneList.length; j++) {
          const s2 = stoneList[j];
          if (s1.dimension !== s2.dimension) continue;
          const z2 = ZONES.find(z => z.id === s2.id);
          if (!z2 || !rw.stones.includes(z2.key)) continue;
          if (z1.key === z2.key) continue; // need two different stones

          // Check distance between stones
          const dx = s1.location.x - s2.location.x;
          const dy = s1.location.y - s2.location.y;
          const dz = s1.location.z - s2.location.z;
          const dist = Math.sqrt(dx * dx + dy * dy + dz * dz);
          if (dist > RUNE_WORD_RANGE) continue;

          // Rune word active! Apply effects to nearby players
          const midX = (s1.location.x + s2.location.x) / 2;
          const midY = (s1.location.y + s2.location.y) / 2;
          const midZ = (s1.location.z + s2.location.z) / 2;

          for (const player of players) {
            if (player.dimension.id !== s1.dimension) continue;
            const pdx = player.location.x - midX;
            const pdy = player.location.y - midY;
            const pdz = player.location.z - midZ;
            const pdist = Math.sqrt(pdx * pdx + pdy * pdy + pdz * pdz);
            if (pdist > RUNE_WORD_EFFECT_RANGE) continue;

            // Apply rune word effects
            for (let e = 0; e < rw.effects.length; e++) {
              try {
                player.runCommandAsync(`effect @s ${rw.effects[e]} 7 ${rw.amplifiers[e]} true`);
              } catch {}
            }
          }
        }
      }
    }
  }

  applyZoneEffect(player, zone, stone) {
    switch (zone.effectType) {
      case "player_buff":
        try {
          player.runCommandAsync(`effect @s ${zone.effect} ${zone.duration} ${zone.amplifier} true`);
        } catch {}
        break;

      case "player_multi":
        for (let i = 0; i < zone.effects.length; i++) {
          try {
            player.runCommandAsync(`effect @s ${zone.effects[i]} ${zone.duration} ${zone.amplifiers[i]} true`);
          } catch {}
        }
        break;

      case "growth":
        // Crop growth — nerfed to 1/5 power (was every 20s, now every 100s)
        if (this.tickCounter % 50 === 0) { // Every ~100 seconds (1/5 original rate)
          try {
            const loc = stone.location;
            player.dimension.runCommandAsync(
              `fill ${loc.x - 4} ${loc.y} ${loc.z - 4} ${loc.x + 4} ${loc.y + 2} ${loc.z + 4} air replace wheat`
            );
          } catch {}
          // Instead, just apply luck to boost crop-related actions
          try {
            player.runCommandAsync(`effect @s absorption 10 0 true`);
          } catch {}
        }
        break;

      case "random":
        // Wild Magic — apply random effect every tick
        const randomEffect = RANDOM_EFFECTS[Math.floor(Math.random() * RANDOM_EFFECTS.length)];
        try {
          player.runCommandAsync(`effect @s ${randomEffect.effect} ${zone.duration} ${randomEffect.amplifier} true`);
        } catch {}
        break;

      case "mob_debuff":
        // Player in zone doesn't get the debuff — handled separately
        break;
    }

    // Gilded zone Dream Rate bonus (every 5 minutes)
    if (zone.key === "gilded" && this.tickCounter % 150 === 0) {
      const s = StorageManager.forPlayer(player);
      const dr = s.getNumber("dream_rate") + 0.25;
      s.set("dream_rate", dr);
    }
  }

  applyMobDebuff(stone, zone) {
    try {
      const dim = world.getDimension(stone.dimension);
      const loc = stone.location;

      // Apply effect to hostile mobs in range
      const cmd = zone.effect === "glowing"
        ? `effect @e[x=${loc.x},y=${loc.y},z=${loc.z},r=${zone.radius},family=monster] ${zone.effect} ${zone.duration} ${zone.amplifier} true`
        : `effect @e[x=${loc.x},y=${loc.y},z=${loc.z},r=${zone.radius},family=monster] ${zone.effect} ${zone.duration} ${zone.amplifier}`;

      dim.runCommandAsync(cmd);

      // Tempest also applies weakness
      if (zone.key === "tempest") {
        dim.runCommandAsync(
          `effect @e[x=${loc.x},y=${loc.y},z=${loc.z},r=${zone.radius},family=monster] weakness ${zone.duration} 0`
        );
      }
    } catch {}
  }

  // ─── STONE REMOVAL ──────────────────────────────────────

  /** Remove stone when deepslate block is broken */
  onBlockBreak(block) {
    if (block?.typeId !== "minecraft:polished_deepslate") return;
    const loc = block.location;
    const key = `${Math.floor(loc.x)}_${Math.floor(loc.y)}_${Math.floor(loc.z)}`;

    if (this.stones.has(key)) {
      this.stones.delete(key);
      const ws = StorageManager.world();
      ws.set(`stone_${key}`, "");
      console.log(`[Inscription] Stone at ${key} removed (block broken)`);
    }
  }

  // ─── PERSISTENCE ────────────────────────────────────────

  /** Load all stones from world storage on init */
  loadStones() {
    // Stones are loaded lazily when players interact with deepslate
    // Full persistence scan would iterate world dynamic properties
    console.log("[Inscription] Stone system initialized");
  }
}
