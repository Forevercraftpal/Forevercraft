/**
 * Chrono Shard — Progression reset tool with 9 resettable subsystems.
 * Replaces Java chrono_shard/ folder (33 mcfunction files).
 *
 * Opens a GUI where players select which system to reset:
 *   1. Class Affinity    2. Bestiary Progress    3. Quest Reputation
 *   4. Advantage Trees   5. Gacha Pity           6. Personal Milestones
 *   7. Craftforever      8. Pet Collection        9. Instance Timers
 *
 * Each reset is confirmed with a second prompt before executing.
 * Clears heist markers and instance timers as special cases.
 */
import { world, system } from "@minecraft/server";
import { StorageManager } from "../utils/storage.js";
import { ActionFormData, MessageFormData } from "@minecraft/server-ui";

const RESET_SYSTEMS = [
  { id: 1, name: "Class Affinity",     color: "§6", desc: "Reset all 14 weapon class affinity XP and stages to 0." },
  { id: 2, name: "Bestiary Progress",  color: "§a", desc: "Reset all mob kill counts and bestiary stages." },
  { id: 3, name: "Quest Reputation",   color: "§e", desc: "Reset quest completion history and reputation." },
  { id: 4, name: "Advantage Trees",    color: "§b", desc: "Refund all advantage tree points and reset unlocks." },
  { id: 5, name: "Gacha Pity",         color: "§d", desc: "Reset gacha pity counters for all tiers." },
  { id: 6, name: "Milestones",         color: "§f", desc: "Reset personal milestone claims (progress kept)." },
  { id: 7, name: "Craftforever",       color: "§6", desc: "Reset Craftforever milestone claims." },
  { id: 8, name: "Pet Collection",     color: "§c", desc: "§c⚠ Remove ALL collected companions! Cannot be undone!" },
  { id: 9, name: "Instance Timers",    color: "§2", desc: "Reset all dungeon/raid/heist cooldown timers." },
];

const CLASS_ABBRS = ["rg","bk","dn","sk","kt","hl","bl","jv","hp","ar","ht","tk","kn","ds"];

export class ChronoShardSystem {
  constructor(eventBridge) {
    this.eventBridge = eventBridge;
  }

  /** Open the Chrono Shard system selection menu */
  async openMenu(player) {
    const form = new ActionFormData()
      .title("§d⏳ Chrono Shard — Select System to Reset");

    for (const sys of RESET_SYSTEMS) {
      form.button(`${sys.color}${sys.name}`);
    }
    form.button("§7Cancel");

    const res = await form.show(player);
    if (res.canceled || res.selection === RESET_SYSTEMS.length) return;

    const selected = RESET_SYSTEMS[res.selection];
    this.showConfirm(player, selected);
  }

  /** Show confirmation dialog for the selected reset */
  async showConfirm(player, sys) {
    const confirm = new MessageFormData()
      .title(`§c⚠ Reset ${sys.name}?`)
      .body(`${sys.desc}\n\n§c§lThis action cannot be undone!`)
      .button1("§c§lConfirm Reset")
      .button2("§7Cancel");

    const res = await confirm.show(player);
    if (res.canceled || res.selection !== 0) {
      player.sendMessage("§7Reset cancelled.");
      return;
    }

    this.executeReset(player, sys.id);
  }

  /** Execute the actual reset for the selected system */
  executeReset(player, systemId) {
    const s = StorageManager.forPlayer(player);

    switch (systemId) {
      case 1: // Class Affinity
        for (const abbr of CLASS_ABBRS) {
          s.setNumber(`aff_${abbr}`, 0);
          s.setNumber(`daff_${abbr}`, 0);
          s.setNumber(`affs_${abbr}`, 0);
          s.setNumber(`affb_${abbr}`, 0);
        }
        player.sendMessage("§d⏳ §fClass Affinity has been reset. All stages returned to 0.");
        break;

      case 2: // Bestiary Progress
        // Reset bestiary stages and claims (stored as bs_s_* and bs_c_*)
        s.setNumber("bestiary_reset", 1); // Flag for bestiary system to clear on next tick
        player.sendMessage("§d⏳ §fBestiary progress has been reset.");
        break;

      case 3: // Quest Reputation
        s.setNumber("quest_rep", 0);
        for (let i = 1; i <= 6; i++) {
          s.setNumber(`quest_slot_${i}`, 0);
          s.setNumber(`quest_tier_${i}`, 0);
        }
        player.sendMessage("§d⏳ §fQuest reputation has been reset.");
        break;

      case 4: // Advantage Trees
        s.setNumber("adv_points_spent", 0);
        s.setNumber("adv_refund", 1); // Flag: refund points on next codex open
        player.sendMessage("§d⏳ §fAdvantage trees have been reset. Points refunded.");
        break;

      case 5: // Gacha Pity
        s.setNumber("gacha_pity_rare", 0);
        s.setNumber("gacha_pity_ornate", 0);
        s.setNumber("gacha_pity_exquisite", 0);
        s.setNumber("gacha_pity_mythical", 0);
        player.sendMessage("§d⏳ §fGacha pity counters reset.");
        break;

      case 6: // Personal Milestones
        s.setNumber("milestone_reset", 1); // Flag for milestone system
        player.sendMessage("§d⏳ §fPersonal milestone claims reset. Progress preserved.");
        break;

      case 7: // Craftforever Milestones
        s.setNumber("cf_milestone_reset", 1);
        player.sendMessage("§d⏳ §fCraftforever milestone claims reset.");
        break;

      case 8: // Pet Collection (DANGEROUS)
        s.setNumber("pet_collection_reset", 1);
        player.sendMessage("§d⏳ §c§lPet collection wiped! All companions removed.");
        break;

      case 9: // Instance Timers
        s.setNumber("dungeon_cd", 0);
        s.setNumber("raid_cd", 0);
        s.setNumber("heist_cd", 0);
        s.setNumber("castle_cd", 0);
        s.setNumber("boss_cd", 0);
        s.setNumber("dg_floors_today", 0);
        // Clear structure crate timers
        s.setNumber("struct_timer_reset", 1);
        player.sendMessage("§d⏳ §fAll instance timers and cooldowns reset.");
        break;
    }

    player.playSound("mob.endermen.portal", { volume: 1.0, pitch: 0.5 });
    try {
      player.dimension.spawnParticle("minecraft:endrod", player.location);
    } catch {}

    this.eventBridge?.emit("chrono_reset", { player, systemId });
  }
}
