/**
 * Calendar Events System — Scheduled world events (Blood Moon, Meteor Shower, etc.)
 * Replaces Java calendar/load + calendar/check + visual_day based triggers.
 */
import { world, system } from "@minecraft/server";
import { StorageManager } from "../utils/storage.js";

const EVENTS = [
  { name: "Blood Moon", day: 7, moonPhase: 0, color: "§4", description: "Hostile mobs are empowered tonight" },
  { name: "Dream Surge", day: -1, interval: 30, color: "§d", description: "Dream Rate gains doubled" },
  { name: "Meteor Shower", day: -1, interval: 45, color: "§b", description: "Rare materials fall from the sky" },
  { name: "Harvest Festival", day: -1, season: "autumn", dayOfSeason: 45, color: "§6", description: "Crop yields doubled" },
  { name: "Frost Tide", day: -1, season: "winter", dayOfSeason: 30, color: "§b", description: "Ice creatures appear" },
  { name: "Spring Bloom", day: -1, season: "spring", dayOfSeason: 15, color: "§a", description: "Rare flowers bloom" },
  { name: "Solar Eclipse", day: -1, interval: 100, color: "§8", description: "The sky darkens..." },
  { name: "Night of Spirits", day: -1, interval: 60, color: "§5", description: "Ghost entities wander" },
];

export class CalendarSystem {
  constructor() {
    this.storage = StorageManager.world();
    this.activeEvent = null;
    this.eventTimer = 0;
  }

  onDayChange(day, moonPhase, season) {
    // Check Blood Moon (every new moon = moonPhase 0)
    if (moonPhase === 0) {
      this.startEvent("Blood Moon", 24000); // Lasts one night
    }

    // Check interval-based events
    for (const evt of EVENTS) {
      if (evt.interval && day % evt.interval === 0 && day > 0) {
        this.startEvent(evt.name, 24000);
        break; // Only one event per day
      }
      if (evt.season === season) {
        const dayOfYear = day % 365;
        const seasonStart = season === "spring" ? 0 : season === "summer" ? 91 : season === "autumn" ? 182 : 273;
        const dayOfSeason = dayOfYear - seasonStart;
        if (evt.dayOfSeason && dayOfSeason === evt.dayOfSeason) {
          this.startEvent(evt.name, 24000);
          break;
        }
      }
    }
  }

  startEvent(name, duration) {
    const evt = EVENTS.find(e => e.name === name);
    if (!evt) return;

    this.activeEvent = name;
    this.eventTimer = duration;
    this.storage.set("active_event", name);
    this.storage.set("event_timer", duration);

    for (const player of world.getAllPlayers()) {
      player.onScreenDisplay.setTitle(`${evt.color}§l${name}`, {
        subtitle: `§7${evt.description}`,
        fadeInDuration: 20, stayDuration: 100, fadeOutDuration: 20,
      });
      player.sendMessage(`${evt.color}§l⚡ World Event: ${name}§r\n§7${evt.description}`);
    }
    console.log(`[Calendar] Event started: ${name}`);
  }

  tick() {
    if (!this.activeEvent) return;
    this.eventTimer--;
    if (this.eventTimer <= 0) {
      const name = this.activeEvent;
      this.activeEvent = null;
      this.storage.set("active_event", "");
      for (const player of world.getAllPlayers()) {
        player.sendMessage(`§7The §e${name}§7 has ended.`);
      }
    }
  }

  getActiveEvent() { return this.activeEvent; }
}
