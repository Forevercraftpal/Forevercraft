/**
 * Night Terror System — 6 named mini-boss variants at new moon when DR >= 30.
 * Replaces Java night_terrors/ folder (18 files).
 *
 * Variants: The Hollow (wither_skeleton), Dreamreaver (phantom),
 * The Wailing (stray), Rotfather (zombie), Nightfang (spider), The Revenant (vindicator)
 *
 * Each has unique abilities, DR-tiered scaling, warning phase, chase mechanics.
 */
import { world, system } from "@minecraft/server";
import { StorageManager } from "../utils/storage.js";

// ─── 6 NAMED VARIANTS ──────────────────────────────────────
const VARIANTS = [
  {
    id: "hollow", name: "The Hollow", mob: "minecraft:wither_skeleton",
    theme: "§8", desc: "Void blinker — teleports and goes invisible",
  },
  {
    id: "dreamreaver", name: "Dreamreaver", mob: "minecraft:phantom",
    theme: "§5", desc: "Dream predator — inflicts Darkness",
  },
  {
    id: "wailing", name: "The Wailing", mob: "minecraft:stray",
    theme: "§b", desc: "Ice sorrow — summons minions and slows",
  },
  {
    id: "rotfather", name: "Rotfather", mob: "minecraft:zombie",
    theme: "§2", desc: "Plague carrier — poisons relentlessly",
  },
  {
    id: "nightfang", name: "Nightfang", mob: "minecraft:spider",
    theme: "§4", desc: "Swift predator — webs and speeds",
  },
  {
    id: "revenant", name: "The Revenant", mob: "minecraft:vindicator",
    theme: "§c", desc: "Armored vengeance — highly resistant",
  },
];

// ─── DR SCALING TIERS ───────────────────────────────────────
const DR_TIERS = [
  { minDR: 30, label: "§e§lNight",    hpMult: 4.0,  dmgMult: 1.0, shards: 1, loot: "ornate",    chance: 0.15 },
  { minDR: 35, label: "§6§lVeteran",  hpMult: 6.5,  dmgMult: 1.5, shards: 2, loot: "exquisite", chance: 0.25 },
  { minDR: 40, label: "§c§lElite",    hpMult: 9.0,  dmgMult: 2.0, shards: 3, loot: "exquisite", chance: 0.35 },
  { minDR: 45, label: "§4§lApex",     hpMult: 14.0, dmgMult: 3.0, shards: 5, loot: "mythical",  chance: 0.50 },
];

function getDRTier(dr) {
  for (let i = DR_TIERS.length - 1; i >= 0; i--) {
    if (dr >= DR_TIERS[i].minDR) return DR_TIERS[i];
  }
  return DR_TIERS[0];
}

export class NightTerrorSystem {
  constructor(eventBridge) {
    this.checkInterval = 0;
    this.activeEncounters = new Map(); // playerName → { entity, variant, abilityTick, tier }

    // Track kills
    world.afterEvents.entityDie.subscribe((event) => {
      const entity = event.deadEntity;
      if (entity?.hasTag?.("ec.night_terror")) {
        this.onNightTerrorKill(entity, event.damageSource);
      }
    });
  }

  /** Called every 5 seconds from main tick */
  tick(players) {
    this.checkInterval++;

    // Ability ticks for active encounters (every 5 seconds)
    for (const player of players) {
      this.tickAbilities(player);
    }

    // Spawn checks every 60 seconds
    if (this.checkInterval < 12) return;
    this.checkInterval = 0;

    for (const player of players) {
      this.checkSpawnConditions(player);
    }
  }

  checkSpawnConditions(player) {
    const s = StorageManager.forPlayer(player);

    // Cooldown
    let cd = s.getNumber("nt_cd", 0);
    if (cd > 0) { s.set("nt_cd", cd - 1); return; }

    // Already active
    if (this.activeEncounters.has(player.name)) return;

    // Dream Rate threshold
    const dreamRate = s.getNumber("dream_rate", 0);
    if (dreamRate < 30) return;

    // Overworld only
    if (player.dimension.id !== "minecraft:overworld") return;

    // Night check
    const timeOfDay = world.getTimeOfDay();
    if (timeOfDay < 14000 || timeOfDay > 22000) return;

    // New moon (phase 4 in Java = day % 8 === 4)
    const day = (globalThis._fc_daylight?.getDay?.() ?? 0);
    if (day % 8 !== 4) return;

    // Y > 40
    if (player.location.y < 40) return;

    // Probability roll based on DR tier
    const tier = getDRTier(dreamRate);
    if (Math.random() > tier.chance) return;

    this.startEncounter(player, dreamRate, tier);
  }

  // ─── WARNING PHASE (10 seconds) ────────────────────────────

  startEncounter(player, dreamRate, tier) {
    const s = StorageManager.forPlayer(player);
    s.set("nt_cd", 30); // 30 checks = ~30 minutes

    // Pick random variant
    const variant = VARIANTS[Math.floor(Math.random() * VARIANTS.length)];

    // Warning phase
    player.sendMessage(`§4§l⚠ ${variant.theme}${variant.name} §r§4§lapproaches...`);
    player.sendMessage(`§7${variant.desc}`);
    player.onScreenDisplay.setTitle("§4§lNight Terror", {
      subtitle: `${variant.theme}${variant.name}`,
      fadeInDuration: 20, stayDuration: 80, fadeOutDuration: 20,
    });
    player.playSound("entity.wither.spawn");

    // Countdown warnings
    let countdown = 10;
    const warningInterval = system.runInterval(() => {
      countdown--;
      if (countdown > 0) {
        player.onScreenDisplay.setActionBar(`§4§l${countdown}...`);
        player.playSound("block.note_block.bass");
      } else {
        system.clearRun(warningInterval);
        this.doSpawn(player, dreamRate, tier, variant);
      }
    }, 20); // Every second
  }

  doSpawn(player, dreamRate, tier, variant) {
    const loc = player.location;
    const dim = player.dimension;

    // Spawn 30-50 blocks away
    const angle = Math.random() * Math.PI * 2;
    const dist = 30 + Math.random() * 20;
    const spawnLoc = {
      x: loc.x + Math.cos(angle) * dist,
      y: loc.y,
      z: loc.z + Math.sin(angle) * dist,
    };

    try {
      const entity = dim.spawnEntity(variant.mob, spawnLoc);
      entity.addTag("ec.night_terror");
      entity.addTag(`ec.nt_owner_${player.name}`);
      entity.addTag(`ec.nt_type_${variant.id}`);
      entity.nameTag = `${tier.label} ${variant.name}`;

      // Base scaling
      const strengthLvl = Math.min(4, Math.floor(tier.dmgMult));
      const resistLvl = Math.min(2, Math.floor(tier.dmgMult / 2));
      entity.runCommandAsync(`effect @s strength 999999 ${strengthLvl} true`);
      entity.runCommandAsync(`effect @s resistance 999999 ${resistLvl} true`);
      entity.runCommandAsync("effect @s fire_resistance 999999 0 true");
      entity.runCommandAsync("effect @s glowing 999999 0 true");

      // Variant-specific spawn effects
      switch (variant.id) {
        case "dreamreaver":
          // Phantom spawns higher
          entity.teleport({ x: spawnLoc.x, y: spawnLoc.y + 5, z: spawnLoc.z }, { dimension: dim });
          break;
        case "rotfather":
          entity.runCommandAsync("effect @s fire_resistance 999999 0 true");
          break;
        case "nightfang":
          entity.runCommandAsync("effect @s speed 999999 1 true");
          break;
        case "revenant":
          entity.runCommandAsync("effect @s resistance 999999 0 true");
          break;
      }

      // Scale health via health boost
      const hpBoostLvl = Math.min(127, Math.floor(tier.hpMult * 2));
      entity.runCommandAsync(`effect @s health_boost 999999 ${hpBoostLvl} true`);
      // Heal to full after HP boost
      system.runTimeout(() => {
        try { entity.runCommandAsync("effect @s instant_health 1 100 true"); } catch {}
      }, 5);

      this.activeEncounters.set(player.name, {
        entity, variant, tier, abilityTick: 0,
        spawnTime: system.currentTick,
      });

      player.sendMessage(`§4§l⚔ ${tier.label} ${variant.theme}${variant.name} §r§4§lhas appeared!`);
      player.playSound("entity.ender_dragon.growl");

    } catch (e) {
      console.log(`[NightTerrors] Spawn failed: ${e}`);
    }
  }

  // ─── VARIANT ABILITIES (every 5 seconds) ───────────────────

  tickAbilities(player) {
    const encounter = this.activeEncounters.get(player.name);
    if (!encounter) return;

    // Check if entity still alive
    try {
      if (!encounter.entity.isValid()) {
        this.activeEncounters.delete(player.name);
        return;
      }
    } catch {
      this.activeEncounters.delete(player.name);
      return;
    }

    // Chase mechanic: teleport closer if > 50 blocks away
    try {
      const dx = player.location.x - encounter.entity.location.x;
      const dz = player.location.z - encounter.entity.location.z;
      const dist = Math.sqrt(dx * dx + dz * dz);
      if (dist > 50) {
        const angle = Math.random() * Math.PI * 2;
        const newLoc = {
          x: player.location.x + Math.cos(angle) * 15,
          y: player.location.y,
          z: player.location.z + Math.sin(angle) * 15,
        };
        encounter.entity.teleport(newLoc, { dimension: player.dimension });
      }
    } catch {}

    // Apply variant ability
    try {
      switch (encounter.variant.id) {
        case "hollow": // Blink: teleport forward + invisibility
          encounter.entity.runCommandAsync("effect @s invisibility 2 0 true");
          // Teleport toward player
          this.teleportToward(encounter.entity, player.location, 3);
          break;

        case "dreamreaver": // Darkness on player
          player.runCommandAsync("effect @s darkness 5 0 true");
          player.playSound("entity.phantom.flap");
          break;

        case "wailing": // Slowness + summon 2 strays
          player.runCommandAsync("effect @s slowness 5 4 true");
          try {
            const loc = encounter.entity.location;
            player.dimension.spawnEntity("minecraft:stray", {
              x: loc.x + Math.random() * 4 - 2, y: loc.y, z: loc.z + Math.random() * 4 - 2,
            });
            player.dimension.spawnEntity("minecraft:stray", {
              x: loc.x + Math.random() * 4 - 2, y: loc.y, z: loc.z + Math.random() * 4 - 2,
            });
          } catch {}
          break;

        case "rotfather": // Poison player + particles
          player.runCommandAsync("effect @s poison 3 1 true");
          break;

        case "nightfang": // Speed boost + cobweb at player
          encounter.entity.runCommandAsync("effect @s speed 5 3 true");
          try {
            const pLoc = player.location;
            player.dimension.runCommandAsync(
              `setblock ${Math.floor(pLoc.x)} ${Math.floor(pLoc.y)} ${Math.floor(pLoc.z)} web`
            );
          } catch {}
          break;

        case "revenant": // Resistance boost
          encounter.entity.runCommandAsync("effect @s resistance 10 1 true");
          player.playSound("mob.vindicator.ambient");
          break;
      }
    } catch {}
  }

  teleportToward(entity, targetLoc, distance) {
    try {
      const dx = targetLoc.x - entity.location.x;
      const dz = targetLoc.z - entity.location.z;
      const mag = Math.sqrt(dx * dx + dz * dz);
      if (mag < 1) return;
      const nx = dx / mag * distance;
      const nz = dz / mag * distance;
      entity.teleport({
        x: entity.location.x + nx,
        y: entity.location.y,
        z: entity.location.z + nz,
      }, { dimension: entity.dimension });
    } catch {}
  }

  // ─── KILL REWARD ──────────────────────────────────────────

  onNightTerrorKill(entity, damageSource) {
    const killer = damageSource?.damagingEntity;
    if (!killer || killer.typeId !== "minecraft:player") return;

    const s = StorageManager.forPlayer(killer);
    const encounter = this.activeEncounters.get(killer.name);
    this.activeEncounters.delete(killer.name);

    const kills = s.getNumber("nt_kills", 0) + 1;
    s.set("nt_kills", kills);

    const tier = encounter?.tier || getDRTier(s.getNumber("dream_rate", 30));
    const variant = encounter?.variant || VARIANTS[0];

    killer.sendMessage(`§a§l✦ ${variant.theme}${variant.name} §r§a§lDefeated!`);
    killer.sendMessage(`§7The darkness recedes... §d+2 Dream Rate §8| §e+${tier.shards} Nightmare Shards`);
    killer.playSound("random.levelup");

    // Dream Rate bonus
    s.set("dream_rate", s.getNumber("dream_rate", 0) + 2);

    // XP reward
    try { killer.runCommandAsync("xp 200 @s"); } catch {}

    // Loot drop
    const loc = entity.location;
    try {
      entity.dimension.runCommandAsync(
        `loot spawn ${loc.x} ${loc.y} ${loc.z} loot "artifacts/${tier.loot}/main"`
      );
    } catch {}

    // Nightmare Shards
    for (let i = 0; i < tier.shards; i++) {
      try {
        killer.runCommandAsync("give @s forevercraft:nightmare_shard 1");
      } catch {}
    }

    // Global announcement
    for (const p of world.getAllPlayers()) {
      if (p.name !== killer.name) {
        p.sendMessage(`§4[Night Terror] §f${killer.name} §7defeated ${variant.theme}${variant.name}!`);
      }
    }

    // Pet memory: mythical artifact chance at high DR
    if (tier.minDR >= 40) {
      s.increment?.("ach_mythical_found") || s.set("ach_mythical_found", (s.getNumber("ach_mythical_found", 0) + 1));
    }
  }
}
