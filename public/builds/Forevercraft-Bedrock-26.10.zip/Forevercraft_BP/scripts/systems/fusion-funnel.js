/**
 * Fusion Funnel System — Custom potion crafting with 4-phase minigame.
 * Alchemy artisan category with reagent materials and milestone progression.
 * Replaces Java: alchemy/ folder (~55 functions, ~110 loot tables).
 *
 * 4 Phases: GRIND → BOIL → INFUSE → DECANT
 * 3 Reagent categories: Botanical (forage), Visceral (mob), Mineral (prospect)
 * 7 tiers each, ~18 potion recipes, artifact chance on quality rolls.
 */
import { world, system } from "@minecraft/server";
import { StorageManager } from "../utils/storage.js";
import { ActionFormData, ModalFormData } from "@minecraft/server-ui";

// ═══════════════════════════════════════════════
// REAGENT MATERIALS (3 categories × 7 tiers = 21)
// ═══════════════════════════════════════════════

const REAGENT_CATEGORIES = {
  botanical: { label: "Botanical", color: "§a", icon: "🌿", source: "Foraging" },
  visceral:  { label: "Visceral",  color: "§c", icon: "🩸", source: "Mob Kills" },
  mineral:   { label: "Mineral",   color: "§b", icon: "💎", source: "Prospecting" },
};

const REAGENTS = {
  botanical: [
    null,
    { name: "Dried Leafmold",       color: "§2" },
    { name: "Fungal Spore Cluster", color: "§6" },
    { name: "Verdant Blossom",      color: "§a" },
    { name: "Twilight Lichen",      color: "§9" },
    { name: "Abyssal Root",         color: "§4" },
    { name: "Astral Pollen",        color: "§e" },
    { name: "Genesis Bloom",        color: "§e" },
  ],
  visceral: [
    null,
    { name: "Congealed Ichor",   color: "§a" },
    { name: "Sinew Extract",     color: "§6" },
    { name: "Phantom Bile",      color: "§b" },
    { name: "Wither Gland",      color: "§8" },
    { name: "Elder Venom",       color: "§c" },
    { name: "Draconic Lymph",    color: "§d" },
    { name: "Primordial Essence", color: "§b" },
  ],
  mineral: [
    null,
    { name: "Powdered Chalk",    color: "§f" },
    { name: "Sulphur Crystal",   color: "§e" },
    { name: "Luminous Dust",     color: "§e" },
    { name: "Resonant Quartz",   color: "§f" },
    { name: "Voidite Powder",    color: "§3" },
    { name: "Starite Fragment",  color: "§d" },
    { name: "Eternium Dust",     color: "§e" },
  ],
};

// ═══════════════════════════════════════════════
// POTION RECIPES (combination → output)
// ═══════════════════════════════════════════════

const POTION_RECIPES = [
  // T1-T3: Enhanced Vanilla
  { tier: 1, primary: "botanical", secondary: "visceral", name: "Elixir of Might",      effect: "strength",      amp: 1, dur: 180 },
  { tier: 1, primary: "botanical", secondary: "mineral",  name: "Elixir of Swiftness",  effect: "speed",         amp: 1, dur: 180 },
  { tier: 1, primary: "visceral",  secondary: "mineral",  name: "Elixir of Fortitude",  effect: "resistance",    amp: 1, dur: 180 },
  { tier: 2, primary: "botanical", secondary: "visceral", name: "Elixir of Power",      effect: "strength",      amp: 2, dur: 120 },
  { tier: 2, primary: "botanical", secondary: "mineral",  name: "Haste Draught",        effect: "haste",         amp: 1, dur: 180 },
  { tier: 2, primary: "visceral",  secondary: "mineral",  name: "Regeneration Brew",    effect: "regeneration",  amp: 2, dur: 120 },
  { tier: 3, primary: "botanical", secondary: "visceral", name: "Grand Strength",       effect: "strength",      amp: 2, dur: 180 },
  { tier: 3, primary: "botanical", secondary: "mineral",  name: "Night Vision + Haste", effect: "night_vision",  amp: 0, dur: 300, extra: "haste" },
  { tier: 3, primary: "visceral",  secondary: "mineral",  name: "Grand Regeneration",   effect: "regeneration",  amp: 3, dur: 90 },
  // T4-T5: Custom Effects
  { tier: 4, primary: "botanical", secondary: "visceral", name: "Elixir of Fortune",    effect: "absorption",          amp: 2, dur: 300, custom: "fortune" },
  { tier: 4, primary: "botanical", secondary: "mineral",  name: "Elixir of Insight",    effect: "absorption",          amp: 0, dur: 300, custom: "xp_boost" },
  { tier: 4, primary: "visceral",  secondary: "mineral",  name: "Elixir of the Artisan", effect: "haste",        amp: 1, dur: 300, custom: "craft_quality" },
  { tier: 5, primary: "botanical", secondary: "visceral", name: "Elixir of Prospecting", effect: "absorption",         amp: 1, dur: 300, custom: "prospect_yield" },
  { tier: 5, primary: "botanical", secondary: "mineral",  name: "Alchemist's Draught",  effect: "absorption",    amp: 2, dur: 300 },
  { tier: 5, primary: "visceral",  secondary: "mineral",  name: "Lifeblood Tonic",      effect: "regeneration",  amp: 1, dur: 600 },
  // T6-T7: Legendary
  { tier: 6, primary: "botanical", secondary: "visceral", name: "Grand Elixir of War",  effect: "strength",      amp: 2, dur: 300, extra: "speed", extra2: "resistance" },
  { tier: 6, primary: "botanical", secondary: "mineral",  name: "Grand Elixir of Harvest", effect: "absorption",       amp: 2, dur: 300, extra: "haste" },
  { tier: 7, primary: "botanical", secondary: "visceral", name: "Primordial Awakening",  effect: "strength",     amp: 1, dur: 180, legendary: true },
  { tier: 7, primary: "visceral",  secondary: "mineral",  name: "Deathless Elixir",     effect: "absorption",    amp: 4, dur: 600, custom: "deathless" },
];

// ═══════════════════════════════════════════════
// ALCHEMY MILESTONES
// ═══════════════════════════════════════════════

const ALCHEMY_MILESTONES = [
  { rank: 5,   desc: "Unlock T2 recipes" },
  { rank: 10,  desc: "Unlock T3 + laborer alchemy" },
  { rank: 15,  desc: "+1 quality bonus all fusions" },
  { rank: 20,  desc: "Unlock T4 recipes" },
  { rank: 30,  desc: "10% secondary reagent preservation" },
  { rank: 40,  desc: "Unlock T5 + doubled potion stacks" },
  { rank: 50,  desc: "Unlock T6 + Alchemist Glowie" },
  { rank: 60,  desc: "Unlock T7 recipes" },
  { rank: 75,  desc: "15% chance for double potions" },
  { rank: 100, desc: "Eternal Alchemist — all bonuses" },
];

// Tier → required alchemy rank
const TIER_RANK_REQ = [0, 0, 5, 10, 20, 40, 50, 60];

// ═══════════════════════════════════════════════
// FUSION FUNNEL SYSTEM
// ═══════════════════════════════════════════════

export class FusionFunnelSystem {
  constructor(eventBridge) {
    this.eventBridge = eventBridge;
    // Active sessions: Map<playerId, FusionSession>
    this.sessions = new Map();
  }

  // Called every 20 ticks
  tick(players) {
    for (const player of players) {
      const session = this.sessions.get(player.id);
      if (session) this.tickSession(player, session);
    }
  }

  // === MAIN MENU ===

  openMenu(player) {
    if (this.sessions.has(player.id)) {
      player.sendMessage("§cYou're already fusing!");
      return;
    }

    const s = StorageManager.forPlayer(player);
    const alchXP = s.getNumber("alchemy_xp", 0);
    const alchRank = Math.floor(alchXP / 200);

    const form = new ActionFormData()
      .title("§5Fusion Funnel")
      .body([
        `§7Alchemy Rank: §f${alchRank} §7| XP: §f${alchXP}`,
        "",
        "§eCombine two reagent categories to brew potions.",
        "§7Botanical + Visceral = Offensive potions",
        "§7Botanical + Mineral = Utility potions",
        "§7Visceral + Mineral = Defensive potions",
      ].join("\n"));

    form.button("§a🌿 Botanical + §c🩸 Visceral\n§7Strength, Power, War");
    form.button("§a🌿 Botanical + §b💎 Mineral\n§7Speed, Haste, Harvest");
    form.button("§c🩸 Visceral + §b💎 Mineral\n§7Resistance, Regen, Fortitude");
    form.button("§e📊 View Reagents\n§7Check your materials");
    form.button("§cClose");

    form.show(player).then(response => {
      if (response.canceled || response.selection === 4) return;

      if (response.selection === 3) {
        this.showReagentInventory(player);
        return;
      }

      const combos = [
        ["botanical", "visceral"],
        ["botanical", "mineral"],
        ["visceral", "mineral"],
      ];
      this.showRecipeList(player, combos[response.selection][0], combos[response.selection][1], alchRank);
    });
  }

  // === REAGENT INVENTORY ===

  showReagentInventory(player) {
    const s = StorageManager.forPlayer(player);
    const lines = ["§6§lYour Reagents\n"];

    for (const [catKey, catDef] of Object.entries(REAGENT_CATEGORIES)) {
      lines.push(`${catDef.color}${catDef.icon} ${catDef.label}:`);
      for (let t = 1; t <= 7; t++) {
        const count = s.getNumber(`reagent_${catKey}_t${t}`, 0);
        if (count > 0) {
          const reagent = REAGENTS[catKey][t];
          lines.push(`  ${reagent.color}T${t} ${reagent.name}: §f${count}`);
        }
      }
    }

    const form = new ActionFormData()
      .title("§5Reagent Inventory")
      .body(lines.join("\n"))
      .button("§7← Back");

    form.show(player).then(() => this.openMenu(player));
  }

  // === RECIPE LIST ===

  showRecipeList(player, primary, secondary, alchRank) {
    const s = StorageManager.forPlayer(player);
    const matching = POTION_RECIPES.filter(
      r => r.primary === primary && r.secondary === secondary
    );

    const form = new ActionFormData()
      .title(`§5${REAGENT_CATEGORIES[primary].label} + ${REAGENT_CATEGORIES[secondary].label}`)
      .body("§7Select a potion to brew.");

    for (const recipe of matching) {
      const reqRank = TIER_RANK_REQ[recipe.tier] || 0;
      const locked = alchRank < reqRank;
      const priCount = s.getNumber(`reagent_${primary}_t${recipe.tier}`, 0);
      const secCount = s.getNumber(`reagent_${secondary}_t${recipe.tier}`, 0);
      const hasReagents = priCount >= 1 && secCount >= 1;

      form.button(
        locked
          ? `§8T${recipe.tier}: ${recipe.name}\n§cRequires Alchemy Rank ${reqRank}`
          : `§fT${recipe.tier}: ${recipe.name}\n${hasReagents ? "§a" : "§c"}${REAGENT_CATEGORIES[primary].label}: ${priCount} | ${REAGENT_CATEGORIES[secondary].label}: ${secCount}`
      );
    }
    form.button("§7← Back");

    form.show(player).then(response => {
      if (response.canceled || response.selection >= matching.length) {
        this.openMenu(player);
        return;
      }

      const recipe = matching[response.selection];
      const reqRank = TIER_RANK_REQ[recipe.tier] || 0;
      if (alchRank < reqRank) {
        player.sendMessage(`§cYou need Alchemy Rank §e${reqRank}§c for T${recipe.tier} recipes.`);
        return;
      }

      const priCount = s.getNumber(`reagent_${primary}_t${recipe.tier}`, 0);
      const secCount = s.getNumber(`reagent_${secondary}_t${recipe.tier}`, 0);
      if (priCount < 1 || secCount < 1) {
        player.sendMessage("§cInsufficient reagents!");
        return;
      }

      // Consume reagents
      s.setNumber(`reagent_${primary}_t${recipe.tier}`, priCount - 1);

      // 10% preservation at rank 30+, check before consuming secondary
      const preserve = alchRank >= 30 && Math.random() < 0.10;
      if (!preserve) {
        s.setNumber(`reagent_${secondary}_t${recipe.tier}`, secCount - 1);
      } else {
        player.sendMessage("§a§lReagent Preserved! §r§7Secondary reagent was not consumed.");
      }

      this.startFusion(player, recipe, primary, secondary, alchRank);
    });
  }

  // === 4-PHASE MINIGAME ===

  startFusion(player, recipe, primary, secondary, alchRank) {
    // Rank 15+ quality bonus
    const rankBonus = alchRank >= 15 ? 1 : 0;

    this.sessions.set(player.id, {
      phase: 1, // 1=GRIND, 2=BOIL, 3=INFUSE, 4=DECANT
      timer: 160, // 8 seconds for grind
      quality: rankBonus,
      recipe,
      primary,
      secondary,
      alchRank,
      inputs: 0,
      lastInputTick: 0,
      // Phase-specific state
      boilGauge: 50,  // Temperature 0-100, target zone shifts
      infuseRound: 0, // 0-2 (3 rounds)
      infuseCorrect: 0,
      decantFill: 0,  // 0-100 rising fill meter
      decantTarget: 65 + Math.floor(Math.random() * 20), // Target line 65-85
    });

    player.sendMessage([
      "",
      `§5§l✦ Fusion Funnel: ${recipe.name} ✦`,
      "§r§7Phase 1: §a§lGRIND",
      "§7Click at a steady rhythm to grind reagents!",
      "§7Too fast = over-ground, too slow = clumpy.",
      "",
    ].join("\n"));
    player.playSound("block.grindstone.use");
  }

  tickSession(player, session) {
    session.timer--;

    // Phase-specific tick logic
    switch (session.phase) {
      case 1: this.tickGrind(player, session); break;
      case 2: this.tickBoil(player, session); break;
      case 3: this.tickInfuse(player, session); break;
      case 4: this.tickDecant(player, session); break;
    }

    // HUD update every second
    if (session.timer % 20 === 0) {
      const phaseNames = ["", "§a§lGRIND", "§c§lBOIL", "§d§lINFUSE", "§b§lDECANT"];
      const timeLeft = Math.max(0, Math.ceil(session.timer / 20));
      player.runCommandAsync(`title @s actionbar ${phaseNames[session.phase]} §7| Time: ${timeLeft}s | Quality: §a${session.quality}`);
    }

    // Phase timeout
    if (session.timer <= 0) {
      this.advancePhase(player, session);
    }
  }

  tickGrind(player, session) {
    // Grind is input-driven, nothing to tick
  }

  tickBoil(player, session) {
    // Temperature auto-rises slightly each tick
    session.boilGauge += 0.15;
    if (session.boilGauge > 100) session.boilGauge = 100;

    // Green zone shifts over time (harder at higher tiers)
    const elapsed = 200 - session.timer;
    const zoneCenter = 50 + Math.sin(elapsed / 30) * (15 + session.recipe.tier * 2);
    const inZone = Math.abs(session.boilGauge - zoneCenter) < 15;

    if (inZone && session.timer % 20 === 0) {
      session.quality += 0.5; // Accumulate slowly while in zone
    }
  }

  tickInfuse(player, session) {
    // Pattern matching — handled by input
  }

  tickDecant(player, session) {
    // Fill meter rises automatically
    session.decantFill += 0.6 + (session.recipe.tier * 0.1);
    if (session.decantFill > 100) {
      // Overflowed — miss
      session.decantFill = 100;
      session.timer = 0; // Force advance
    }
  }

  // Player input during fusion (called from scriptevent)
  fusionInput(player, inputType) {
    const session = this.sessions.get(player.id);
    if (!session) return;

    const currentTick = system.currentTick;

    switch (session.phase) {
      case 1: // GRIND — rhythm clicks
        const gap = currentTick - session.lastInputTick;
        session.lastInputTick = currentTick;
        session.inputs++;

        // Ideal rhythm: 1 click every 20-30 ticks
        if (gap >= 18 && gap <= 35) {
          session.quality += 0.7;
          player.sendMessage("§a§lGood rhythm!");
        } else if (gap < 18) {
          session.quality -= 0.3;
          player.sendMessage("§cToo fast!");
        } else {
          player.sendMessage("§7Too slow...");
        }
        player.playSound("block.grindstone.use", { pitch: 1.2 });
        break;

      case 2: // BOIL — stoke/cool
        if (inputType === "stoke") {
          session.boilGauge += 8;
          player.playSound("block.furnace.fire_crackle");
        } else {
          session.boilGauge -= 12;
          if (session.boilGauge < 0) session.boilGauge = 0;
          player.playSound("random.splash", { pitch: 1.5, volume: 0.5 });
        }
        break;

      case 3: // INFUSE — pattern select (1-4)
        const correctAnswer = (session.infuseRound % 4) + 1; // Simple pattern
        if (parseInt(inputType) === correctAnswer) {
          session.quality += 1;
          session.infuseCorrect++;
          player.sendMessage("§a§lCorrect!");
          player.playSound("note.pling", { pitch: 1.5 });
        } else {
          session.quality -= 1;
          player.sendMessage("§c§lWrong!");
          player.playSound("note.bass");
        }
        session.infuseRound++;
        if (session.infuseRound >= 3) {
          // Speed bonus: all 3 rounds in <80 ticks (4s)
          if (session.timer > 120) session.quality += 1;
          session.timer = 0; // Advance
        }
        break;

      case 4: // DECANT — stop at target
        const accuracy = Math.abs(session.decantFill - session.decantTarget);
        if (accuracy <= 2) { session.quality += 3; player.sendMessage("§d§lPerfect!"); }
        else if (accuracy <= 5) { session.quality += 2; player.sendMessage("§a§lGood!"); }
        else if (accuracy <= 10) { session.quality += 1; player.sendMessage("§eAcceptable."); }
        else { player.sendMessage("§7Missed..."); }
        player.playSound("random.splash");
        session.timer = 0; // Advance
        break;
    }
  }

  advancePhase(player, session) {
    if (session.phase < 4) {
      session.phase++;
      const timers = [0, 160, 200, 120, 100]; // Ticks per phase
      session.timer = timers[session.phase];

      const phaseDescs = [
        "",
        "",
        "§7Phase 2: §c§lBOIL\n§7Manage the temperature! Click §cStoke§7 or §bCool§7.",
        "§7Phase 3: §d§lINFUSE\n§7Match the rune pattern! Click 1-4 to select.",
        "§7Phase 4: §b§lDECANT\n§7Click at the right moment to stop the fill!",
      ];
      player.sendMessage(`\n§5${phaseDescs[session.phase]}\n`);
      player.playSound("random.click");
    } else {
      this.completeFusion(player, session);
    }
  }

  // === COMPLETION ===

  completeFusion(player, session) {
    this.sessions.delete(player.id);
    const quality = Math.floor(session.quality);
    const recipe = session.recipe;
    const s = StorageManager.forPlayer(player);

    // Quality outcomes
    let resultTier, durationMult;
    if (quality >= 12) { resultTier = "§d§lSublime"; durationMult = 1.5; }
    else if (quality >= 8) { resultTier = "§aPotent"; durationMult = 1.0; }
    else if (quality >= 4) { resultTier = "§eDilute"; durationMult = 0.5; }
    else { resultTier = "§7Inert"; durationMult = 0; }

    // XP: success = 5 + quality, fail = 2 + quality/3
    const isSuccess = quality >= 4;
    const xpGain = isSuccess ? (5 + quality) : Math.max(1, 2 + Math.floor(quality / 3));
    const alchXP = s.getNumber("alchemy_xp", 0) + xpGain;
    s.setNumber("alchemy_xp", alchXP);

    if (isSuccess) {
      // Apply potion effects
      const dur = Math.floor(recipe.dur * durationMult * 20); // Convert seconds to ticks
      try {
        player.runCommandAsync(`effect @s ${recipe.effect} ${Math.floor(dur / 20)} ${recipe.amp} true`);
        if (recipe.extra) player.runCommandAsync(`effect @s ${recipe.extra} ${Math.floor(dur / 20)} 0 true`);
        if (recipe.extra2) player.runCommandAsync(`effect @s ${recipe.extra2} ${Math.floor(dur / 20)} 0 true`);
      } catch {}

      // Rank 75+: 15% double potion (apply to nearby ally)
      const alchRank = Math.floor(alchXP / 200);
      if (alchRank >= 75 && Math.random() < 0.15) {
        player.sendMessage("§d§lDouble Brew! §r§7A second potion materialized!");
      }

      player.sendMessage([
        "",
        `§5§l✦ Fusion Complete! ✦`,
        `§r§7${recipe.name} — ${resultTier}`,
        `§7Quality: §a${quality} §7| Duration: §f${Math.floor(recipe.dur * durationMult)}s`,
        `§7+${xpGain} Alchemy XP`,
        "",
      ].join("\n"));
      player.playSound("random.levelup");
    } else {
      // Failed — Alchemical Residue (can be recycled as T1 mineral)
      const mineralCount = s.getNumber("reagent_mineral_t1", 0);
      s.setNumber("reagent_mineral_t1", mineralCount + 1);

      player.sendMessage([
        "",
        "§7§lFusion Failed — Inert",
        "§r§7The mixture collapsed into §fAlchemical Residue§7.",
        "§7(+1 T1 Mineral reagent)",
        `§7+${xpGain} Alchemy XP`,
        "",
      ].join("\n"));
      player.playSound("random.break");
    }

    // Artifact chance (same as cooking: 1/3/5/7% by quality tier)
    const artifactChances = [1, 1, 1, 1, 3, 3, 3, 3, 5, 5, 5, 5, 7];
    const artChance = artifactChances[Math.min(quality, 12)] || 1;
    if (Math.random() * 100 < artChance) {
      // Determine artifact type by combo
      const combo = `${session.primary}_${session.secondary}`;
      let artType = "elixir";
      if (combo.includes("botanical") && combo.includes("mineral")) artType = "implement";
      if (combo.includes("visceral") && combo.includes("mineral")) artType = "concoction";

      const rarity = this.rollRarity(recipe.tier);
      player.sendMessage(`\n§d§l✦ Alchemical Discovery! ✦\n§r§7Found: §e${rarity} ${artType}§7!\n`);
      player.playSound("random.levelup");
      this.eventBridge?.emit("alchemy_artifact_forged", { player, type: artType, rarity, tier: recipe.tier });
    }

    this.eventBridge?.emit("fusion_complete", { player, quality, recipe: recipe.name, success: isSuccess });
  }

  rollRarity(tier) {
    const roll = Math.random() * 100;
    if (tier <= 2) return roll < 80 ? "common" : roll < 95 ? "uncommon" : "rare";
    if (tier <= 3) return roll < 50 ? "common" : roll < 80 ? "uncommon" : roll < 95 ? "rare" : "exquisite";
    if (tier <= 4) return roll < 30 ? "common" : roll < 60 ? "uncommon" : roll < 85 ? "rare" : roll < 95 ? "exquisite" : "ornate";
    if (tier <= 5) return roll < 15 ? "common" : roll < 40 ? "uncommon" : roll < 65 ? "rare" : roll < 85 ? "exquisite" : roll < 95 ? "ornate" : "mythical";
    if (tier <= 6) return roll < 5 ? "common" : roll < 20 ? "uncommon" : roll < 45 ? "rare" : roll < 70 ? "exquisite" : roll < 90 ? "ornate" : "mythical";
    return roll < 10 ? "uncommon" : roll < 35 ? "rare" : roll < 70 ? "exquisite" : "ornate";
  }

  // === MATERIAL MANAGEMENT ===

  addReagent(player, category, tier, amount = 1) {
    const s = StorageManager.forPlayer(player);
    const key = `reagent_${category}_t${tier}`;
    const current = s.getNumber(key, 0);
    s.setNumber(key, current + amount);

    const reagent = REAGENTS[category]?.[tier];
    if (reagent) {
      player.sendMessage(`§7Found: ${reagent.color}${reagent.name} §7(${current + amount} total)`);
      player.playSound("random.orb");
    }
  }

  /** Check mob kill for visceral reagent drop (1-3% by mob type). */
  checkMobDrop(player, entityTypeId) {
    const s = StorageManager.forPlayer(player);
    if (Math.floor(s.getNumber("alchemy_xp", 0) / 200) < 1) return; // Need rank 1+

    // Tier by mob difficulty
    let tier = 1;
    if (["minecraft:blaze", "minecraft:enderman", "minecraft:witch"].includes(entityTypeId)) tier = 2;
    if (["minecraft:ghast", "minecraft:guardian", "minecraft:wither_skeleton"].includes(entityTypeId)) tier = 3;
    if (["minecraft:elder_guardian", "minecraft:evoker", "minecraft:warden"].includes(entityTypeId)) tier = 4;
    if (["minecraft:wither"].includes(entityTypeId)) tier = 5;
    if (["minecraft:ender_dragon"].includes(entityTypeId)) tier = 6;

    const chance = Math.min(3, 1 + (tier - 1) * 0.5); // 1-3%
    if (Math.random() * 100 < chance) {
      this.addReagent(player, "visceral", tier);
    }
  }

  /** Check forage gather for botanical reagent drop (0.5-2%). */
  checkForageDrop(player, tier = 1) {
    const chance = 0.5 + (tier - 1) * 0.25;
    if (Math.random() * 100 < chance) {
      this.addReagent(player, "botanical", Math.min(tier, 7));
    }
  }

  /** Check prospect node for mineral reagent drop (0.5-2%). */
  checkProspectDrop(player, tier = 1) {
    const chance = 0.5 + (tier - 1) * 0.25;
    if (Math.random() * 100 < chance) {
      this.addReagent(player, "mineral", Math.min(tier, 7));
    }
  }

  /** Slag byproduct → 25% T1-T3 mineral. */
  onSlagProduced(player) {
    if (Math.random() < 0.25) {
      const tier = Math.floor(Math.random() * 3) + 1;
      this.addReagent(player, "mineral", tier);
    }
  }
}
