/**
 * Hero's Satchel System — 11-slot boss artifact container with passive AoE effects.
 * Effects from all stored artifacts apply simultaneously.
 * Replaces Java hero_satchel/ folder.
 */
import { world, system } from "@minecraft/server";
import { StorageManager } from "../utils/storage.js";
import { ActionFormData } from "@minecraft/server-ui";

// 11 boss artifacts and their passive effects
const BOSS_ARTIFACTS = [
  {
    id: "thunderstrike_core", name: "Thunderstrike Core", boss: "Stormforged",
    color: "§b", effects: [
      { effect: "speed", amplifier: 1, duration: 200 },
      { effect: "resistance", amplifier: 0, duration: 200 },
    ], luckBonus: 1.5,
  },
  {
    id: "soul_reaver", name: "Soul Reaver", boss: "Hollow King",
    color: "§8", effects: [], luckBonus: 1.5, aura: "wither",
  },
  {
    id: "earthshaker_core", name: "Earthshaker Core", boss: "Earthshaker",
    color: "§6", effects: [
      { effect: "resistance", amplifier: 1, duration: 200 },
    ], luckBonus: 1.5,
  },
  {
    id: "infernal_heart", name: "Infernal Heart", boss: "Infernal Titan",
    color: "§c", effects: [
      { effect: "fire_resistance", amplifier: 0, duration: 200 },
      { effect: "strength", amplifier: 0, duration: 200 },
    ], luckBonus: 1.5,
  },
  {
    id: "architects_design", name: "Architect's Design", boss: "Ender Architect",
    color: "§d", effects: [
      { effect: "night_vision", amplifier: 0, duration: 400 },
      { effect: "speed", amplifier: 0, duration: 200 },
    ], luckBonus: 2.0,
  },
  {
    id: "void_sovereigns_eye", name: "Void Sovereign's Eye", boss: "Void Sovereign",
    color: "§5", effects: [
      { effect: "night_vision", amplifier: 0, duration: 400 },
      { effect: "slow_falling", amplifier: 0, duration: 200 },
    ], luckBonus: 2.0,
  },
  {
    id: "soulkeepers_ember", name: "Soulkeeper's Ember", boss: "Soul Warden",
    color: "§3", effects: [
      { effect: "strength", amplifier: 0, duration: 200 },
    ], luckBonus: 1.5,
  },
  {
    id: "behemoths_heart", name: "Behemoth's Heart", boss: "Crimson Behemoth",
    color: "§4", effects: [
      { effect: "health_boost", amplifier: 1, duration: 200 },
      { effect: "absorption", amplifier: 0, duration: 200 },
    ], luckBonus: 1.5,
  },
  {
    id: "thornheart_bloom", name: "Thornheart Bloom", boss: "Verdant Warden",
    color: "§2", effects: [
      { effect: "regeneration", amplifier: 0, duration: 200 },
    ], luckBonus: 1.5,
  },
  {
    id: "abyssal_pearl", name: "Abyssal Pearl", boss: "Tidecaller",
    color: "§3", effects: [
      { effect: "water_breathing", amplifier: 0, duration: 400 },
      { effect: "conduit_power", amplifier: 0, duration: 200 },
    ], luckBonus: 1.5,
  },
  {
    id: "nightmare_fragment", name: "Nightmare Fragment", boss: "Nightmare",
    color: "§8", effects: [
      { effect: "speed", amplifier: 0, duration: 200 },
    ], luckBonus: 1.5,
  },
];

const ARTIFACT_MAP = new Map(BOSS_ARTIFACTS.map(a => [a.id, a]));
const MAX_SLOTS = 11;

export class HeroSatchelSystem {
  constructor(eventBridge) {
    this.eventBridge = eventBridge;

    // Item use handler
    world.afterEvents.itemUse.subscribe((event) => {
      if (event.itemStack?.typeId === "forevercraft:hero_satchel") {
        this.openMenu(event.source);
      }
    });
  }

  /**
   * Apply passive effects from all stored artifacts. Runs every 100 ticks (5s).
   */
  tick(players) {
    for (const player of players) {
      if (player.getGameMode() === "creative" || player.getGameMode() === "spectator") continue;

      // Check if player has satchel in inventory
      if (!this.hasSatchel(player)) continue;

      const storage = StorageManager.forPlayer(player);
      let totalLuckBonus = 0;

      // Apply effects from each stored artifact
      for (let i = 0; i < MAX_SLOTS; i++) {
        const artId = storage.getString(`hsatch_s${i}`, "");
        if (!artId) continue;

        const artDef = ARTIFACT_MAP.get(artId);
        if (!artDef) continue;

        totalLuckBonus += artDef.luckBonus;

        for (const eff of artDef.effects) {
          try {
            player.addEffect(eff.effect, eff.duration, {
              amplifier: eff.amplifier,
              showParticles: false,
            });
          } catch {}
        }
      }

      // Store total luck bonus for DR calculation
      if (totalLuckBonus > 0) {
        storage.set("hsatch_luck", totalLuckBonus);
      }
    }
  }

  /**
   * Check if player has hero satchel in inventory.
   */
  hasSatchel(player) {
    // Check via tag (set when satchel given)
    return player.hasTag("ec.has_hero_satchel");
  }

  /**
   * Open the hero satchel menu.
   */
  openMenu(player) {
    const storage = StorageManager.forPlayer(player);

    let body = "§7Boss Artifact Storage (11 slots)\n\n";
    const storedArtifacts = [];

    for (let i = 0; i < MAX_SLOTS; i++) {
      const artId = storage.getString(`hsatch_s${i}`, "");
      if (artId) {
        const artDef = ARTIFACT_MAP.get(artId);
        const name = artDef ? `${artDef.color}${artDef.name}` : `§7${artId}`;
        body += `§7Slot ${i + 1}: ${name}\n`;
        storedArtifacts.push({ slot: i, id: artId, def: artDef });
      } else {
        body += `§7Slot ${i + 1}: §8[Empty]\n`;
      }
    }

    const count = storedArtifacts.length;
    body += `\n§7Stored: §e${count}/${MAX_SLOTS}`;

    const form = new ActionFormData()
      .title("§6✦ Hero's Satchel")
      .body(body)
      .button("§aStore Held Artifact")
      .button("§bRetrieve Artifact")
      .button("§7Close");

    form.show(player).then((r) => {
      if (r.canceled || r.selection === 2) return;

      if (r.selection === 0) {
        this.storeArtifact(player);
      } else if (r.selection === 1) {
        this.retrieveMenu(player, storedArtifacts);
      }
    });
  }

  /**
   * Store the held artifact into the satchel.
   */
  storeArtifact(player) {
    const storage = StorageManager.forPlayer(player);
    const equip = player.getComponent("minecraft:equippable");
    const mainhand = equip?.getEquipment("Mainhand");

    if (!mainhand) {
      player.sendMessage("§cYou must hold a boss artifact to store it.");
      return;
    }

    // Check if it's a boss artifact by matching type ID
    let artId = null;
    for (const art of BOSS_ARTIFACTS) {
      if (mainhand.typeId === `forevercraft:${art.id}`) {
        artId = art.id;
        break;
      }
    }

    if (!artId) {
      player.sendMessage("§cThis item is not a boss artifact.");
      return;
    }

    // Find empty slot
    let emptySlot = -1;
    for (let i = 0; i < MAX_SLOTS; i++) {
      if (!storage.getString(`hsatch_s${i}`, "")) {
        emptySlot = i;
        break;
      }
    }

    if (emptySlot === -1) {
      player.sendMessage("§cSatchel is full!");
      return;
    }

    // Store and remove from hand
    storage.set(`hsatch_s${emptySlot}`, artId);
    equip.setEquipment("Mainhand", undefined);

    const artDef = ARTIFACT_MAP.get(artId);
    player.sendMessage(`§a✦ Stored ${artDef?.color || "§7"}${artDef?.name || artId} §ain slot ${emptySlot + 1}`);
    try { player.playSound("block.chest.close", { volume: 0.5, pitch: 1.2 }); } catch {}
  }

  /**
   * Open retrieve menu for stored artifacts.
   */
  retrieveMenu(player, storedArtifacts) {
    if (storedArtifacts.length === 0) {
      player.sendMessage("§7No artifacts stored.");
      return;
    }

    const form = new ActionFormData()
      .title("§bRetrieve Artifact");

    for (const sa of storedArtifacts) {
      const name = sa.def ? `${sa.def.color}${sa.def.name}` : sa.id;
      form.button(`${name} §7(Slot ${sa.slot + 1})`);
    }
    form.button("§7Cancel");

    form.show(player).then((r) => {
      if (r.canceled || r.selection === storedArtifacts.length) return;

      const selected = storedArtifacts[r.selection];
      this.retrieveArtifact(player, selected.slot, selected.id);
    });
  }

  /**
   * Retrieve an artifact from a slot.
   */
  retrieveArtifact(player, slot, artId) {
    const storage = StorageManager.forPlayer(player);
    storage.set(`hsatch_s${slot}`, "");

    try {
      player.dimension.runCommandAsync(
        `give "${player.name}" forevercraft:${artId} 1`
      );
    } catch {}

    const artDef = ARTIFACT_MAP.get(artId);
    player.sendMessage(`§b✦ Retrieved ${artDef?.color || "§7"}${artDef?.name || artId}`);
    try { player.playSound("block.chest.open", { volume: 0.5, pitch: 1.0 }); } catch {}
  }
}
