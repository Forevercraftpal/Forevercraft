/**
 * Spirit Weapons System — Endgame class weapons (Tier 7 Spirit).
 * 15 weapons, 7-tier progression, soulbound, twin system, per-weapon abilities.
 * Replaces Java spirit/ folder (393 files).
 */
import { world, system } from "@minecraft/server";
import { StorageManager } from "../utils/storage.js";
import { ActionFormData } from "@minecraft/server-ui";

// === 15 Spirit Weapons ===
const SPIRIT_WEAPONS = [
  { id: 1,  name: "Hollow Fangs",       classId: "rogue",     twinId: 1,  twinName: "Snow Blade",      hasTwin: true,  weapon: "netherite_sword",  baseDmg: 9,  baseSpd: -2.0 },
  { id: 2,  name: "Voidpiercer",        classId: "hunter",    twinId: 0,  twinName: null,              hasTwin: false, weapon: "crossbow",         baseDmg: 0,  baseSpd: 0 },
  { id: 3,  name: "Firebrand",          classId: "berserker", twinId: 3,  twinName: "Aqualoch",        hasTwin: true,  weapon: "netherite_axe",    baseDmg: 10, baseSpd: -3.0 },
  { id: 4,  name: "Zephyr Edge",        classId: "dancer",    twinId: 4,  twinName: "Storm Edge",      hasTwin: true,  weapon: "netherite_sword",  baseDmg: 7,  baseSpd: -1.5 },
  { id: 5,  name: "Nite",               classId: "dual_sword",twinId: 5,  twinName: "Deih",            hasTwin: true,  weapon: "netherite_sword",  baseDmg: 8,  baseSpd: -2.0 },
  { id: 6,  name: "Whispering Spear",   classId: "beastlord", twinId: 0,  twinName: null,              hasTwin: false, weapon: "trident",          baseDmg: 9,  baseSpd: -2.5 },
  { id: 7,  name: "Ashcrown Mace",      classId: "sentinel",  twinId: 7,  twinName: "Ashcrown Shield", hasTwin: true,  weapon: "mace",             baseDmg: 7,  baseSpd: -2.5 },
  { id: 8,  name: "Ellegaard's Trident", classId: "javelin",  twinId: 0,  twinName: null,              hasTwin: false, weapon: "trident",          baseDmg: 9,  baseSpd: -2.5 },
  { id: 9,  name: "Pharaoh's Fist",     classId: "striker",   twinId: 0,  twinName: null,              hasTwin: false, weapon: "mace",             baseDmg: 10, baseSpd: -3.0 },
  { id: 10, name: "Lifewoven Branch",   classId: "healer",    twinId: 0,  twinName: null,              hasTwin: false, weapon: "trident",          baseDmg: 5,  baseSpd: -2.0 },
  { id: 11, name: "Sabrewing",          classId: "archer",    twinId: 0,  twinName: null,              hasTwin: false, weapon: "bow",              baseDmg: 0,  baseSpd: 0 },
  { id: 12, name: "Dragonheart Sword",  classId: "knight",    twinId: 12, twinName: "Johan Shield",    hasTwin: true,  weapon: "netherite_sword",  baseDmg: 8,  baseSpd: -2.0 },
  { id: 13, name: "Bulwark Shield",     classId: "tank",      twinId: 0,  twinName: null,              hasTwin: false, weapon: "shield",           baseDmg: 3,  baseSpd: -1.0 },
  { id: 14, name: "Royal Trident",      classId: "hoplite",   twinId: 14, twinName: "Vanguard Shield", hasTwin: true,  weapon: "trident",          baseDmg: 9,  baseSpd: -2.5 },
];

// 7-tier progression
const TIERS = [
  { name: "Common",    color: "§f", xp: 0 },
  { name: "Uncommon",  color: "§a", xp: 1000 },
  { name: "Rare",      color: "§b", xp: 5000 },
  { name: "Ornate",    color: "§5", xp: 15000 },
  { name: "Exquisite", color: "§6", xp: 50000 },
  { name: "Mythical",  color: "§c", xp: 150000 },
  { name: "Spirit",    color: "§d", xp: 500000 },
];

// Universal metamorphosis requirements (3 of 7)
const UNIVERSAL_REQS = [
  { id: 1, desc: "All glyph slots filled at Exquisite stage" },
  { id: 2, desc: "Weapon mastery fully maxed" },
  { id: 3, desc: "Slain all 13 Raid Bosses at least once" },
];

// Per-weapon unique requirements (4 of 7)
const UNIQUE_REQS = {
  1:  [{ id: 4, desc: "50,000 kills", key: "sp_kills", target: 50000 },
       { id: 5, desc: "10,000 stealth kills", key: "sp_stealth_kills", target: 10000 },
       { id: 6, desc: "100 dungeon floors", key: "sp_dg_floors", target: 100 },
       { id: 7, desc: "Solo the Hollow Sovereign", key: "sp_solo_boss_1", target: 1 }],
  3:  [{ id: 4, desc: "50,000 kills", key: "sp_kills", target: 50000 },
       { id: 5, desc: "Take 500,000 damage", key: "sp_dmg_taken", target: 500000 },
       { id: 6, desc: "100 enemies in one run", key: "sp_run_kills", target: 100 },
       { id: 7, desc: "Win 50 guild expeditions", key: "sp_guild_exp", target: 50 }],
  5:  [{ id: 4, desc: "50,000 kills", key: "sp_kills", target: 50000 },
       { id: 5, desc: "1,000 Whirlwind kills", key: "sp_whirl_kills", target: 1000 },
       { id: 6, desc: "Max combat advantage trees", key: "sp_max_trees", target: 1 },
       { id: 7, desc: "Solo 3 Raid Bosses", key: "sp_solo_bosses", target: 3 }],
  10: [{ id: 4, desc: "50,000 HP healed in combat", key: "sp_heals", target: 50000 },
       { id: 5, desc: "250,000 ally healing", key: "sp_ally_heals", target: 250000 },
       { id: 6, desc: "Revive 500 players", key: "sp_revives", target: 500 },
       { id: 7, desc: "Max support advantage trees", key: "sp_max_support", target: 1 }],
};
// Weapons without unique reqs use a generic set
const DEFAULT_UNIQUE_REQS = [
  { id: 4, desc: "50,000 kills", key: "sp_kills", target: 50000 },
  { id: 5, desc: "Complete 50 dungeons", key: "sp_dg_complete", target: 50 },
  { id: 6, desc: "Reach DR 35", key: "sp_dr_35", target: 1 },
  { id: 7, desc: "Win 25 Spirit Raids", key: "sp_raid_wins", target: 25 },
];

// Ability cooldowns in ticks
const ABILITY_COOLDOWNS = {
  1:  { a1: 160, a2: 400 },   // Hollow Fangs: Shadow Step 8s, Thousand Cuts 20s
  2:  { a1: 240, a2: 400 },   // Voidpiercer: Rift Bolt 12s, Phase Shot 20s
  3:  { a1: 200, a2: 600 },   // Firebrand: Earthshatter 10s, Rampage 30s
  4:  { a1: 160, a2: 400 },   // Zephyr Edge: Cyclone 8s, Zephyr Dance 20s
  5:  { a1: 200, a2: 500 },   // Nite: Dimensional Rift 10s, Blade Storm 25s
  6:  { a1: 200, a2: 400 },   // Whispering Spear: Beast Rally 10s, Spirit Call 20s
  7:  { a1: 200, a2: 400 },   // Ashcrown Mace: Ground Pound 10s, Fortress 20s
  8:  { a1: 200, a2: 400 },   // Ellegaard's Trident: Tidal Surge 10s, Leviathan Strike 20s
  9:  { a1: 200, a2: 400 },   // Pharaoh's Fist: Sandstorm 10s, Pharaoh's Wrath 20s
  10: { a1: 200, a2: 400 },   // Lifewoven Branch: Heal Pulse 10s, Nature's Embrace 20s
  11: { a1: 200, a2: 400 },   // Sabrewing: Piercing Shot 10s, Arrow Storm 20s
  12: { a1: 200, a2: 400 },   // Dragonheart: Dragon Slash 10s, Dragon's Fury 20s
  13: { a1: 200, a2: 400 },   // Bulwark Shield: Shield Bash 10s, Fortress Wall 20s
  14: { a1: 200, a2: 400 },   // Royal Trident: Vanguard Charge 10s, Phalanx 20s
};

export class SpiritWeaponSystem {
  constructor(eventBridge, weaponMasterySystem, glyphforgeSystem) {
    this.eventBridge = eventBridge;
    this.weaponMastery = weaponMasterySystem;
    this.glyphforge = glyphforgeSystem;
    // Per-player cooldown tracking: Map<playerId, { a1: ticksRemaining, a2: ticksRemaining }>
    this.cooldowns = new Map();
    // Per-player passive state: Map<playerId, { consecutiveHits, rampageTimer, windCharges, ... }>
    this.passiveState = new Map();

    // Listen for combat events
    this.eventBridge.on("player_killed_entity", (data) => this.onKill(data.player, data.entity));
    this.eventBridge.on("player_hurt", (data) => this.onPlayerHurt(data.player, data.damage));

    // Listen for spirit weapon item use
    world.afterEvents.itemUse.subscribe((event) => {
      const player = event.source;
      if (!player?.typeId === "minecraft:player") return;
      this.onItemUse(player, event.itemStack);
    });
  }

  // === TICK ===
  passiveCounter = 0;

  tick(players) {
    this.passiveCounter++;
    const doPassives = (this.passiveCounter % 5 === 0); // OPT: passives every 5 ticks

    for (const player of players) {
      const s = StorageManager.forPlayer(player); // OPT: use cached forPlayer
      const weaponId = s.getNumber("sp_weapon_id", 0);
      if (weaponId === 0) continue;

      // Decrement cooldowns
      const cd = this.cooldowns.get(player.id);
      if (cd) {
        if (cd.a1 > 0) cd.a1--;
        if (cd.a2 > 0) cd.a2--;
      }

      // Passive effects (weapon-specific) — OPT: only every 5 ticks
      if (doPassives) this.tickPassives(player, weaponId, s);

      // Soulbound enforcement — mark with tag
      if (!player.hasTag("ec.sp_soulbound")) {
        player.addTag("ec.sp_soulbound");
      }
    }
  }

  // === PASSIVE EFFECTS ===
  tickPassives(player, weaponId, s) {
    const weapon = SPIRIT_WEAPONS.find(w => w.id === weaponId);
    if (!weapon) return;

    const tier = s.getNumber("sp_tier", 1);
    const state = this.passiveState.get(player.id) || {};

    switch (weaponId) {
      case 1: // Hollow Fangs — Soul Rend on every 3rd consecutive hit, stealth heal
        // Handled in onKill
        break;
      case 3: // Firebrand — Below 30% HP: Tyrant's Rage (+50% dmg, +30% spd, 15% lifesteal)
        try {
          const health = player.getComponent("minecraft:health");
          if (health) {
            const pct = health.currentValue / health.effectiveMax;
            const threshold = tier >= 7 ? 0.4 : 0.3;
            if (pct <= threshold && !player.hasTag("ec.sp_tyrant_rage")) {
              player.addTag("ec.sp_tyrant_rage");
              player.addEffect("speed", 100, { amplifier: 0, showParticles: false });
              player.addEffect("strength", 100, { amplifier: 1, showParticles: false });
              player.sendMessage("§c§lTyrant's Rage §r§7activated!");
            } else if (pct > threshold && player.hasTag("ec.sp_tyrant_rage")) {
              player.removeTag("ec.sp_tyrant_rage");
            }
          }
        } catch (e) {}
        break;
      case 4: // Zephyr Edge — +20% speed while held, evasion wind slash
        try {
          player.addEffect("speed", 40, { amplifier: 0, showParticles: false });
        } catch (e) {}
        break;
      case 10: // Lifewoven Branch — passive regen aura for nearby allies
        if (tier >= 3) {
          try {
            const nearby = player.dimension.getPlayers({ location: player.location, maxDistance: 8 });
            for (const ally of nearby) {
              if (ally.id !== player.id) {
                ally.addEffect("regeneration", 40, { amplifier: 0, showParticles: false });
              }
            }
          } catch (e) {}
        }
        break;
    }

    this.passiveState.set(player.id, state);
  }

  // === ITEM USE (Ability 1) ===
  onItemUse(player, item) {
    if (!item) return;
    const s = StorageManager.forPlayer(player);
    const weaponId = s.getNumber("sp_weapon_id", 0);
    if (weaponId === 0) return;

    // Check if held item is the spirit weapon
    const lore = item.getLore();
    if (!lore || !lore.some(l => l.includes("Spirit Artifact"))) return;

    const cd = this.cooldowns.get(player.id) || { a1: 0, a2: 0 };
    const isSneaking = player.isSneaking;
    const tier = s.getNumber("sp_tier", 1);

    if (isSneaking) {
      // Ability 2
      if (cd.a2 > 0) {
        const secsLeft = Math.ceil(cd.a2 / 20);
        player.sendMessage(`§7Ability on cooldown (${secsLeft}s)`);
        return;
      }
      this.useAbility2(player, weaponId, tier);
      cd.a2 = (ABILITY_COOLDOWNS[weaponId]?.a2 || 400);
      if (tier >= 7) cd.a2 = Math.floor(cd.a2 * 0.6); // Spirit tier: 40% CD reduction
    } else {
      // Ability 1
      if (cd.a1 > 0) {
        const secsLeft = Math.ceil(cd.a1 / 20);
        player.sendMessage(`§7Ability on cooldown (${secsLeft}s)`);
        return;
      }
      this.useAbility1(player, weaponId, tier);
      cd.a1 = (ABILITY_COOLDOWNS[weaponId]?.a1 || 200);
      if (tier >= 7) cd.a1 = Math.floor(cd.a1 * 0.6);
    }
    this.cooldowns.set(player.id, cd);
  }

  // === ABILITY 1 IMPLEMENTATIONS ===
  useAbility1(player, weaponId, tier) {
    const loc = player.location;
    const dim = player.dimension;

    switch (weaponId) {
      case 1: // Hollow Fangs — Shadow Step: teleport behind nearest hostile
        this.ability_shadowStep(player, tier);
        break;
      case 2: // Voidpiercer — Rift Bolt: void rift at impact
        this.ability_riftBolt(player, tier);
        break;
      case 3: // Firebrand — Earthshatter: AoE shockwave
        this.ability_earthshatter(player, tier);
        break;
      case 4: // Zephyr Edge — Cyclone: spinning tornado pull
        this.ability_cyclone(player, tier);
        break;
      case 5: // Nite — Dimensional Rift: cutting line
        this.ability_dimensionalRift(player, tier);
        break;
      case 6: // Whispering Spear — Beast Rally: buff nearby tamed mobs
        this.ability_beastRally(player, tier);
        break;
      case 7: // Ashcrown Mace — Ground Pound: AoE stun
        this.ability_groundPound(player, tier);
        break;
      case 8: // Ellegaard's Trident — Tidal Surge: water wave AoE
        this.ability_tidalSurge(player, tier);
        break;
      case 9: // Pharaoh's Fist — Sandstorm: blinding AoE
        this.ability_sandstorm(player, tier);
        break;
      case 10: // Lifewoven Branch — Heal Pulse: burst heal allies
        this.ability_healPulse(player, tier);
        break;
      case 11: // Sabrewing — Piercing Shot: penetrating arrow
        this.ability_piercingShot(player, tier);
        break;
      case 12: // Dragonheart — Dragon Slash: fire cone
        this.ability_dragonSlash(player, tier);
        break;
      case 13: // Bulwark Shield — Shield Bash: stun + knockback
        this.ability_shieldBash(player, tier);
        break;
      case 14: // Royal Trident — Vanguard Charge: dash + AoE
        this.ability_vanguardCharge(player, tier);
        break;
    }
  }

  // === ABILITY 2 IMPLEMENTATIONS (Java-matched) ===
  useAbility2(player, weaponId, tier) {
    switch (weaponId) {
      case 1:  this.a2_thousandCuts(player, tier); break;
      case 2:  this.a2_phaseShot(player, tier); break;
      case 3:  this.a2_rampage(player, tier); break;
      case 4:  this.a2_zephyrDance(player, tier); break;
      case 5:  this.a2_bladeStorm(player, tier); break;
      case 6:  this.a2_primalFusion(player, tier); break;
      case 7:  this.a2_judgmentStrike(player, tier); break;
      case 8:  this.a2_poseidonsWrath(player, tier); break;
      case 9:  this.a2_titanBreaker(player, tier); break;
      case 10: this.a2_lifeSurge(player, tier); break;
      case 11: this.a2_singularityArrow(player, tier); break;
      case 12: this.a2_dragonheartStrike(player, tier); break;
      case 13: this.a2_titansGuard(player, tier); break;
      case 14: this.a2_phalanxCharge(player, tier); break;
    }
  }

  // ─── A2-1: Hollow Fangs — Thousand Cuts ─────────────────────
  // 2s channel → 10 rapid strikes in 3-block cone; Bleed stacks
  a2_thousandCuts(player, tier) {
    player.addEffect("slowness", 40, { amplifier: 3, showParticles: false });
    player.sendMessage("§5§lThousand Cuts! §r§7Channeling...");
    const dim = player.dimension;
    const strikes = tier >= 7 ? 15 : 10;
    const bleedDmg = tier >= 7 ? 3 : 2;
    let count = 0;
    const interval = system.runInterval(() => {
      if (count >= strikes) { system.clearRun(interval); return; }
      try {
        const entities = dim.getEntities({ location: player.location, maxDistance: 3, excludeTypes: ["minecraft:player"] });
        for (const e of entities) {
          try {
            e.applyDamage(4, { cause: "entityAttack", damagingEntity: player });
            // Bleed = Wither (simulates DoT stacking)
            e.addEffect("wither", 100, { amplifier: Math.min(count, 4), showParticles: true });
          } catch {}
        }
        dim.spawnParticle("minecraft:critical_hit_emitter", {
          x: player.location.x + (Math.random() - 0.5) * 3,
          y: player.location.y + 1,
          z: player.location.z + (Math.random() - 0.5) * 3
        });
      } catch {}
      count++;
    }, 2);
    player.playSound("mob.wither.shoot", { volume: 0.3, pitch: 2.0 });
  }

  // ─── A2-2: Voidpiercer — Phase Shot ─────────────────────────
  // Invisibility 3s + Resistance V; fire 3-5 homing bolts
  a2_phaseShot(player, tier) {
    const bolts = tier >= 7 ? 5 : 3;
    player.addEffect("invisibility", 60, { amplifier: 0, showParticles: false });
    player.addEffect("resistance", 60, { amplifier: 4, showParticles: false });
    player.sendMessage(`§1§lPhase Shot! §r§7${bolts} homing bolts...`);
    let fired = 0;
    const interval = system.runInterval(() => {
      if (fired >= bolts) { system.clearRun(interval); return; }
      try {
        const dim = player.dimension;
        const entities = dim.getEntities({
          location: player.location, maxDistance: 20,
          excludeTypes: ["minecraft:player"], excludeFamilies: ["inanimate"]
        });
        const target = entities.find(e => e.getComponent("minecraft:health")?.currentValue > 0);
        if (target) {
          target.applyDamage(tier >= 7 ? 8 : 6, { cause: "projectile", damagingEntity: player });
          target.addEffect("glowing", 60, { amplifier: 0, showParticles: false });
          dim.spawnParticle("minecraft:critical_hit_emitter", target.location);
          dim.spawnParticle("minecraft:endrod", target.location);
          player.playSound("random.bow", { volume: 0.5, pitch: 1.5 });
        }
      } catch {}
      fired++;
    }, 10);
  }

  // ─── A2-3: Firebrand — Rampage ──────────────────────────────
  // 8-12s Speed II; kills extend +2s, +10% damage, AoE shockwave on kills
  a2_rampage(player, tier) {
    const duration = tier >= 7 ? 240 : 160;
    player.addEffect("speed", duration, { amplifier: 1, showParticles: false });
    player.addTag("ec.sp_rampage");
    const s = StorageManager.forPlayer(player);
    s.set("sp_rampage_timer", duration);
    s.set("sp_rampage_dmg_bonus", 0);
    player.sendMessage("§c§lRampage! §r§7Every kill: +2s, +10% damage, AoE shockwave!");
    player.playSound("mob.ravager.roar", { volume: 1.0, pitch: 0.8 });
  }

  // ─── A2-4: Zephyr Edge — Zephyr Dance ──────────────────────
  // 5-7 Wind Charges; each attack teleports around target; 5th strike = lightning
  a2_zephyrDance(player, tier) {
    const charges = tier >= 7 ? 7 : 5;
    const s = StorageManager.forPlayer(player);
    s.set("sp_wind_charges", charges);
    s.set("sp_wind_hits", 0);
    player.addTag("ec.sp_wind_dance");
    player.addEffect("speed", charges * 40, { amplifier: 1, showParticles: false });
    player.sendMessage(`§e§lZephyr Dance! §r§7${charges} charges — teleport on hit, 5th = lightning!`);
    player.playSound("mob.phantom.flap", { volume: 0.8, pitch: 1.5 });
  }

  // ─── A2-5: Nite — Blade Storm ──────────────────────────────
  // Orbiting swords 5-7s; damage entities in path; final convergence AoE
  a2_bladeStorm(player, tier) {
    const duration = tier >= 7 ? 140 : 100;
    const radius = tier >= 7 ? 8 : 6;
    const finalDmg = tier >= 7 ? 15 : 10;
    player.sendMessage("§9§lBlade Storm! §r§7Orbiting blades!");
    let ticks = 0;
    const interval = system.runInterval(() => {
      if (ticks >= duration) {
        // Final convergence AoE
        try {
          const entities = player.dimension.getEntities({
            location: player.location, maxDistance: radius, excludeTypes: ["minecraft:player"]
          });
          for (const e of entities) {
            try { e.applyDamage(finalDmg, { cause: "entityAttack", damagingEntity: player }); } catch {}
          }
          player.dimension.spawnParticle("minecraft:huge_explosion_emitter", player.location);
          player.playSound("random.explode", { volume: 0.6, pitch: 1.2 });
        } catch {}
        system.clearRun(interval);
        return;
      }
      try {
        // Two orbiting sword positions (opposite sides)
        for (let offset = 0; offset < 2; offset++) {
          const angle = ((ticks * 18) + offset * 180) * (Math.PI / 180);
          const orbPos = {
            x: player.location.x + Math.cos(angle) * radius,
            y: player.location.y + 1,
            z: player.location.z + Math.sin(angle) * radius,
          };
          const entities = player.dimension.getEntities({
            location: orbPos, maxDistance: 2, excludeTypes: ["minecraft:player"]
          });
          for (const e of entities) {
            try { e.applyDamage(5, { cause: "entityAttack", damagingEntity: player }); } catch {}
          }
          player.dimension.spawnParticle("minecraft:critical_hit_emitter", orbPos);
        }
      } catch {}
      ticks += 2;
    }, 2);
  }

  // ─── A2-6: Whispering Spear — Primal Fusion ────────────────
  // Str II + Speed I + Resistance I for 15-20s; player scale +0.3
  a2_primalFusion(player, tier) {
    const duration = tier >= 7 ? 400 : 300;
    player.addEffect("strength", duration, { amplifier: 1, showParticles: true });
    player.addEffect("speed", duration, { amplifier: 0, showParticles: false });
    player.addEffect("resistance", duration, { amplifier: 0, showParticles: false });
    player.sendMessage("§2§lPrimal Fusion! §r§7Empowered form for " + (tier >= 7 ? "20s" : "15s") + "!");
    player.playSound("mob.wolf.howl", { volume: 1.0, pitch: 0.5 });
    try { player.dimension.spawnParticle("minecraft:totem_particle", player.location); } catch {}
  }

  // ─── A2-7: Ashcrown Mace — Judgment Strike ─────────────────
  // Two-hit combo: (1) Stun nearest; (2) 0.5s delay, 5x if stunned
  a2_judgmentStrike(player, tier) {
    const dim = player.dimension;
    const stunDur = tier >= 7 ? 60 : 40;
    player.sendMessage("§6§lJudgment Strike!");
    try {
      // Phase 1: Stun nearest
      const entities = dim.getEntities({
        location: player.location, maxDistance: 5,
        excludeTypes: ["minecraft:player"], excludeFamilies: ["inanimate"]
      });
      const target = entities[0];
      if (!target) { player.sendMessage("§7No target nearby."); return; }

      target.addEffect("slowness", stunDur, { amplifier: 4, showParticles: true });
      target.addEffect("weakness", stunDur, { amplifier: 4, showParticles: true });
      target.addTag("ec.sp_stunned");
      dim.spawnParticle("minecraft:large_explosion_particle", target.location);
      player.playSound("mob.irongolem.hit", { volume: 1.0, pitch: 0.5 });

      // Phase 2: Delayed follow-up (0.5s)
      system.runTimeout(() => {
        try {
          const isStunned = target.hasTag("ec.sp_stunned");
          const dmgMult = isStunned ? 5 : 2;
          target.applyDamage(8 * dmgMult, { cause: "entityAttack", damagingEntity: player });
          target.removeTag("ec.sp_stunned");
          // Shockwave
          const nearby = dim.getEntities({
            location: target.location, maxDistance: 3, excludeTypes: ["minecraft:player"]
          });
          for (const e of nearby) {
            if (e.id !== target.id) {
              try { e.applyDamage(6, { cause: "entityAttack" }); } catch {}
            }
          }
          dim.spawnParticle("minecraft:huge_explosion_emitter", target.location);
          player.playSound("random.anvil_land", { volume: 0.8, pitch: 0.6 });
        } catch {}
      }, 10);
    } catch {}
  }

  // ─── A2-8: Ellegaard's Trident — Poseidon's Wrath ──────────
  // 2s charge → 10-15 block cone AoE; 20dmg + KB + 3 lightning + Slow III
  a2_poseidonsWrath(player, tier) {
    const range = tier >= 7 ? 15 : 10;
    player.addEffect("slowness", 40, { amplifier: 2, showParticles: false }); // 2s charge
    player.sendMessage("§3§lPoseidon's Wrath! §r§7Charging...");
    player.playSound("mob.guardian.elder.curse", { volume: 1.0, pitch: 0.5 });

    system.runTimeout(() => {
      const dim = player.dimension;
      const viewDir = player.getViewDirection();
      try {
        // Cone AoE along view direction
        for (let i = 2; i <= range; i += 2) {
          const pos = {
            x: player.location.x + viewDir.x * i,
            y: player.location.y + 1 + viewDir.y * i,
            z: player.location.z + viewDir.z * i,
          };
          const entities = dim.getEntities({
            location: pos, maxDistance: 3, excludeTypes: ["minecraft:player"]
          });
          for (const e of entities) {
            try {
              e.applyDamage(20, { cause: "entityAttack", damagingEntity: player });
              e.addEffect("slowness", 160, { amplifier: 2, showParticles: true });
              e.applyKnockback(viewDir.x, viewDir.z, 2, 0.5);
            } catch {}
          }
          dim.spawnParticle("minecraft:large_explosion_particle", pos);
        }
        // 3 lightning strikes
        for (let i = 0; i < 3; i++) {
          const strikePos = {
            x: player.location.x + viewDir.x * (4 + i * 3) + (Math.random() - 0.5) * 4,
            y: player.location.y,
            z: player.location.z + viewDir.z * (4 + i * 3) + (Math.random() - 0.5) * 4,
          };
          try { dim.runCommandAsync(`summon lightning_bolt ${strikePos.x} ${strikePos.y} ${strikePos.z}`); } catch {}
        }
        player.playSound("ambient.weather.thunder", { volume: 1.0, pitch: 1.0 });
      } catch {}
    }, 40); // 2s delay
  }

  // ─── A2-9: Pharaoh's Fist — Titan Breaker ─────────────────
  // 1-1.5s windup + 100 dmg to nearest + launch 15 blocks + Glowing
  a2_titanBreaker(player, tier) {
    const windUp = tier >= 7 ? 20 : 30;
    player.addEffect("slowness", windUp, { amplifier: 2, showParticles: false });
    player.sendMessage("§e§lTitan Breaker! §r§7Winding up...");
    player.playSound("mob.warden.sonic_boom", { volume: 0.5, pitch: 0.3 });

    system.runTimeout(() => {
      const dim = player.dimension;
      try {
        const entities = dim.getEntities({
          location: player.location, maxDistance: 5,
          excludeTypes: ["minecraft:player"], excludeFamilies: ["inanimate"]
        });
        const target = entities[0];
        if (target) {
          target.applyDamage(100, { cause: "entityAttack", damagingEntity: player });
          target.addEffect("glowing", 200, { amplifier: 0, showParticles: false });
          // Launch backward
          const dx = target.location.x - player.location.x;
          const dz = target.location.z - player.location.z;
          const d = Math.sqrt(dx * dx + dz * dz) || 1;
          target.applyKnockback(dx / d, dz / d, 8, 2);
          dim.spawnParticle("minecraft:huge_explosion_emitter", target.location);
          player.playSound("mob.warden.sonic_boom", { volume: 1.0, pitch: 0.8 });
        } else {
          player.sendMessage("§7No target nearby.");
        }
      } catch {}
    }, windUp);
  }

  // ─── A2-10: Lifewoven Branch — Life Surge ──────────────────
  // 2s channel → heal wave: all within 20-25 blocks fully healed + Regen IV + Absorption IV
  a2_lifeSurge(player, tier) {
    const range = tier >= 7 ? 25 : 20;
    player.addEffect("slowness", 40, { amplifier: 2, showParticles: false });
    player.sendMessage("§a§lLife Surge! §r§7Channeling healing wave...");
    player.playSound("block.beacon.power", { volume: 1.0, pitch: 1.5 });

    system.runTimeout(() => {
      try {
        const dim = player.dimension;
        const allies = dim.getPlayers({ location: player.location, maxDistance: range });
        for (const ally of allies) {
          try {
            ally.addEffect("instant_health", 1, { amplifier: 5, showParticles: true }); // Full heal
            ally.addEffect("regeneration", 200, { amplifier: 3, showParticles: false }); // Regen IV 10s
            ally.addEffect("absorption", 200, { amplifier: 3, showParticles: false }); // Absorption IV 10s
            dim.spawnParticle("minecraft:villager_happy", ally.location);
          } catch {}
        }
        dim.spawnParticle("minecraft:totem_particle", player.location);
        player.playSound("random.totem", { volume: 1.0, pitch: 1.2 });
        player.sendMessage(`§a§lLife Surge! §r§7Healed ${allies.length} allies!`);
      } catch {}
    }, 40);
  }

  // ─── A2-11: Sabrewing — Singularity Arrow ──────────────────
  // Black hole at nearest hostile; 8-12 block pull radius; 3s; 25-40 dmg collapse
  a2_singularityArrow(player, tier) {
    const pullRadius = tier >= 7 ? 12 : 8;
    const collapseDmg = tier >= 7 ? 40 : 25;
    const dim = player.dimension;

    // Find target or use view direction
    let blackHoleLoc;
    try {
      const entities = dim.getEntities({
        location: player.location, maxDistance: 30,
        excludeTypes: ["minecraft:player"], excludeFamilies: ["inanimate"]
      });
      const target = entities.find(e => e.getComponent("minecraft:health")?.currentValue > 0);
      blackHoleLoc = target ? { ...target.location } : {
        x: player.location.x + player.getViewDirection().x * 15,
        y: player.location.y + 1,
        z: player.location.z + player.getViewDirection().z * 15,
      };
    } catch {
      blackHoleLoc = player.location;
    }

    player.sendMessage("§5§lSingularity! §r§7Black hole created!");
    player.playSound("mob.endermen.portal", { volume: 1.0, pitch: 0.3 });

    let ticks = 0;
    const interval = system.runInterval(() => {
      if (ticks >= 60) { // 3 seconds
        // Collapse burst
        try {
          const entities = dim.getEntities({
            location: blackHoleLoc, maxDistance: pullRadius, excludeTypes: ["minecraft:player"]
          });
          for (const e of entities) {
            try { e.applyDamage(collapseDmg, { cause: "entityAttack", damagingEntity: player }); } catch {}
          }
          dim.spawnParticle("minecraft:huge_explosion_emitter", blackHoleLoc);
          player.playSound("random.explode", { volume: 1.0, pitch: 0.5 });
        } catch {}
        system.clearRun(interval);
        return;
      }
      // Pull entities toward center
      try {
        const entities = dim.getEntities({
          location: blackHoleLoc, maxDistance: pullRadius, excludeTypes: ["minecraft:player"]
        });
        for (const e of entities) {
          try {
            const dx = blackHoleLoc.x - e.location.x;
            const dz = blackHoleLoc.z - e.location.z;
            const d = Math.sqrt(dx * dx + dz * dz);
            if (d > 1) e.applyKnockback(dx / d, dz / d, 0.8, 0);
            e.applyDamage(2, { cause: "entityAttack" });
          } catch {}
        }
        dim.spawnParticle("minecraft:dragon_breath_trail", blackHoleLoc);
        dim.spawnParticle("minecraft:endrod", blackHoleLoc);
      } catch {}
      ticks += 4;
    }, 4);
  }

  // ─── A2-12: Dragonheart Sword — Dragonheart Strike ─────────
  // Charge forward 8-12 blocks in steps; 10 dmg/step; final slam 15 dmg + ignite
  a2_dragonheartStrike(player, tier) {
    const steps = tier >= 7 ? 6 : 4;
    const totalDist = tier >= 7 ? 12 : 8;
    const stepDist = totalDist / steps;
    const viewDir = player.getViewDirection();
    const dim = player.dimension;
    player.sendMessage("§c§lDragonheart Strike!");
    player.playSound("mob.enderdragon.growl", { volume: 0.8, pitch: 1.2 });

    let step = 0;
    const interval = system.runInterval(() => {
      if (step >= steps) {
        // Final slam
        try {
          const entities = dim.getEntities({
            location: player.location, maxDistance: 4, excludeTypes: ["minecraft:player"]
          });
          for (const e of entities) {
            try {
              e.applyDamage(15, { cause: "entityAttack", damagingEntity: player });
              e.setOnFire(100, true);
            } catch {}
          }
          dim.spawnParticle("minecraft:huge_explosion_emitter", player.location);
          dim.spawnParticle("minecraft:dragon_breath_trail", player.location);
          player.playSound("random.explode", { volume: 0.7, pitch: 0.8 });
        } catch {}
        system.clearRun(interval);
        return;
      }

      // Charge step
      const newPos = {
        x: player.location.x + viewDir.x * stepDist,
        y: player.location.y,
        z: player.location.z + viewDir.z * stepDist,
      };
      try {
        player.teleport(newPos);
        const entities = dim.getEntities({
          location: newPos, maxDistance: 2, excludeTypes: ["minecraft:player"]
        });
        for (const e of entities) {
          try { e.applyDamage(10, { cause: "entityAttack", damagingEntity: player }); } catch {}
        }
        dim.spawnParticle("minecraft:dragon_breath_trail", newPos);
      } catch {}
      step++;
    }, 4);
  }

  // ─── A2-13: Bulwark Shield — Titan's Guard ─────────────────
  // Link with nearest ally for 10s; self: Res III; ally: Res II + Regen I
  a2_titansGuard(player, tier) {
    const duration = tier >= 7 ? 300 : 200; // 15s or 10s
    const dim = player.dimension;

    try {
      const allies = dim.getPlayers({ location: player.location, maxDistance: 8 });
      const ally = allies.find(p => p.id !== player.id);

      // Self buff always
      player.addEffect("resistance", duration, { amplifier: 2, showParticles: false }); // Res III

      if (ally) {
        ally.addEffect("resistance", duration, { amplifier: 1, showParticles: false }); // Res II
        ally.addEffect("regeneration", duration, { amplifier: 0, showParticles: false }); // Regen I
        player.sendMessage(`§7§lTitan's Guard! §r§7Linked with §f${ally.name}§7!`);
        ally.sendMessage(`§7§l${player.name} §r§7activated §lTitan's Guard§r§7! You're protected.`);

        // Visual link particles
        let ticks = 0;
        const linkInterval = system.runInterval(() => {
          if (ticks >= duration) { system.clearRun(linkInterval); return; }
          try {
            dim.spawnParticle("minecraft:endrod", {
              x: (player.location.x + ally.location.x) / 2,
              y: (player.location.y + ally.location.y) / 2 + 1,
              z: (player.location.z + ally.location.z) / 2,
            });
          } catch {}
          ticks += 20;
        }, 20);
      } else {
        player.sendMessage("§7§lTitan's Guard! §r§7No ally nearby — self buff only.");
      }
    } catch {}
    player.playSound("mob.irongolem.repair", { volume: 1.0, pitch: 0.6 });
  }

  // ─── A2-14: Royal Trident — Phalanx Charge ─────────────────
  // Charge forward 10-14 blocks with shield; damage immunity; AoE slam at end
  a2_phalanxCharge(player, tier) {
    const distance = tier >= 7 ? 14 : 10;
    const viewDir = player.getViewDirection();
    const dim = player.dimension;
    player.sendMessage("§b§lPhalanx Charge!");
    player.addEffect("resistance", 40, { amplifier: 4, showParticles: false }); // Near-invulnerable during charge

    const steps = 5;
    const stepDist = distance / steps;
    let step = 0;
    const interval = system.runInterval(() => {
      if (step >= steps) {
        // AoE slam at destination
        try {
          const entities = dim.getEntities({
            location: player.location, maxDistance: 5, excludeTypes: ["minecraft:player"]
          });
          for (const e of entities) {
            try {
              e.applyDamage(12, { cause: "entityAttack", damagingEntity: player });
              e.addEffect("slowness", 60, { amplifier: 1, showParticles: true });
              e.applyKnockback(0, 0, 1, 0.5);
            } catch {}
          }
          dim.spawnParticle("minecraft:huge_explosion_emitter", player.location);
          player.playSound("random.anvil_land", { volume: 0.6, pitch: 0.8 });
        } catch {}
        system.clearRun(interval);
        return;
      }

      const newPos = {
        x: player.location.x + viewDir.x * stepDist,
        y: player.location.y,
        z: player.location.z + viewDir.z * stepDist,
      };
      try {
        player.teleport(newPos);
        // Damage along path
        const entities = dim.getEntities({
          location: newPos, maxDistance: 2, excludeTypes: ["minecraft:player"]
        });
        for (const e of entities) {
          try {
            e.applyDamage(6, { cause: "entityAttack", damagingEntity: player });
            e.applyKnockback(viewDir.x, viewDir.z, 1.5, 0.3);
          } catch {}
        }
        dim.spawnParticle("minecraft:critical_hit_emitter", newPos);
      } catch {}
      step++;
    }, 4);
  }

  // ============ INDIVIDUAL ABILITIES ============

  // --- Hollow Fangs (Rogue) ---
  ability_shadowStep(player, tier) {
    const dim = player.dimension;
    try {
      const entities = dim.getEntities({ location: player.location, maxDistance: 15, excludeTypes: ["minecraft:player"], excludeFamilies: ["inanimate"] });
      const hostile = entities.find(e => e.getComponent("minecraft:health")?.currentValue > 0);
      if (!hostile) { player.sendMessage("§7No target nearby."); return; }

      const hLoc = hostile.location;
      const dx = hLoc.x - player.location.x;
      const dz = hLoc.z - player.location.z;
      const dist = Math.sqrt(dx * dx + dz * dz);
      if (dist < 0.1) return;
      // Teleport 2 blocks behind target
      const behindX = hLoc.x - (dx / dist) * 2;
      const behindZ = hLoc.z - (dz / dist) * 2;
      player.teleport({ x: behindX, y: hLoc.y, z: behindZ });
      player.addEffect("invisibility", 60, { amplifier: 0, showParticles: false }); // 3 seconds
      player.addTag("ec.sp_shadow_dmg"); // Next hit = 3x damage
      player.sendMessage("§5§lShadow Step!");
      dim.spawnParticle("minecraft:large_explosion_particle", player.location);
      player.playSound("mob.endermen.portal");
    } catch (e) {}
  }

  ability_thousandCuts(player, tier) {
    player.addEffect("slowness", 40, { amplifier: 3, showParticles: false }); // 2s channel
    player.sendMessage("§5§lThousand Cuts §r§7— channeling...");
    const loc = { ...player.location };
    const dim = player.dimension;
    const strikes = tier >= 7 ? 15 : 10;
    let count = 0;
    const interval = system.runInterval(() => {
      if (count >= strikes) { system.clearRun(interval); return; }
      try {
        const entities = dim.getEntities({ location: loc, maxDistance: 3, excludeTypes: ["minecraft:player"] });
        for (const e of entities) {
          try { e.applyDamage(4, { cause: "entityAttack" }); } catch (err) {}
        }
        dim.spawnParticle("minecraft:critical_hit_emitter", { x: loc.x + (Math.random() - 0.5) * 3, y: loc.y + 1, z: loc.z + (Math.random() - 0.5) * 3 });
      } catch (e) {}
      count++;
    }, 2); // 1 per 2 ticks
  }

  // --- Firebrand (Berserker) ---
  ability_earthshatter(player, tier) {
    const radius = tier >= 7 ? 10 : 8;
    const dim = player.dimension;
    const loc = player.location;
    try {
      const entities = dim.getEntities({ location: loc, maxDistance: radius, excludeTypes: ["minecraft:player"] });
      for (const e of entities) {
        try {
          e.applyDamage(12, { cause: "entityAttack" });
          e.applyKnockback(0, 0, 0, 1.5); // Launch upward
          e.addEffect("slowness", 100, { amplifier: 1, showParticles: false }); // Slow zone
        } catch (err) {}
      }
      dim.spawnParticle("minecraft:huge_explosion_emitter", loc);
      player.playSound("random.explode");
      player.sendMessage("§c§lEarthshatter!");
    } catch (e) {}
  }

  ability_rampage(player, tier) {
    const duration = tier >= 7 ? 240 : 160; // 12s or 8s
    player.addEffect("speed", duration, { amplifier: 1, showParticles: false });
    player.addTag("ec.sp_rampage");
    player.sendMessage("§c§lRampage! §r§7Every kill extends duration!");
    const s = StorageManager.forPlayer(player);
    s.setNumber("sp_rampage_timer", duration);
    s.setNumber("sp_rampage_dmg_bonus", 0);
    player.playSound("mob.ravager.roar");
  }

  // --- Voidpiercer (Hunter) ---
  ability_riftBolt(player, tier) {
    const radius = tier >= 7 ? 6 : 4;
    const dim = player.dimension;
    // Create void rift at player's look target (use location + view direction)
    const viewDir = player.getViewDirection();
    const riftLoc = {
      x: player.location.x + viewDir.x * 8,
      y: player.location.y + viewDir.y * 8 + 1,
      z: player.location.z + viewDir.z * 8,
    };
    player.sendMessage("§1§lRift Bolt!");
    let ticks = 0;
    const interval = system.runInterval(() => {
      if (ticks >= 60) { // 3 seconds
        // Final burst
        try {
          const entities = dim.getEntities({ location: riftLoc, maxDistance: radius, excludeTypes: ["minecraft:player"] });
          for (const e of entities) {
            try { e.applyDamage(8, { cause: "entityAttack" }); } catch (err) {}
          }
          dim.spawnParticle("minecraft:large_explosion_particle", riftLoc);
        } catch (e) {}
        system.clearRun(interval);
        return;
      }
      // Pull entities toward center
      try {
        const entities = dim.getEntities({ location: riftLoc, maxDistance: radius, excludeTypes: ["minecraft:player"] });
        for (const e of entities) {
          try {
            e.applyDamage(2, { cause: "entityAttack" });
            // Pull toward center via knockback
            const dx = riftLoc.x - e.location.x;
            const dz = riftLoc.z - e.location.z;
            const d = Math.sqrt(dx * dx + dz * dz);
            if (d > 0.5) e.applyKnockback(dx / d, dz / d, 0.5, 0);
          } catch (err) {}
        }
        dim.spawnParticle("minecraft:dragon_breath_trail", riftLoc);
      } catch (e) {}
      ticks += 4;
    }, 4);
  }

  ability_phaseShot(player, tier) {
    const bolts = tier >= 7 ? 5 : 3;
    player.addEffect("invisibility", 60, { amplifier: 0, showParticles: false });
    player.addEffect("resistance", 60, { amplifier: 4, showParticles: false });
    player.sendMessage("§1§lPhase Shot! §r§7Firing ${bolts} homing bolts...");
    let fired = 0;
    const interval = system.runInterval(() => {
      if (fired >= bolts) { system.clearRun(interval); return; }
      try {
        const dim = player.dimension;
        const entities = dim.getEntities({ location: player.location, maxDistance: 16, excludeTypes: ["minecraft:player"] });
        const target = entities.find(e => e.getComponent("minecraft:health")?.currentValue > 0);
        if (target) {
          target.applyDamage(6, { cause: "projectile" });
          dim.spawnParticle("minecraft:critical_hit_emitter", target.location);
          player.playSound("random.bow");
        }
      } catch (e) {}
      fired++;
    }, 10); // 1 bolt per 0.5s
  }

  // --- Zephyr Edge (Dancer) ---
  ability_cyclone(player, tier) {
    const duration = tier >= 7 ? 100 : 60; // 5s or 3s
    const radius = tier >= 7 ? 8 : 6;
    player.sendMessage("§e§lCyclone!");
    player.addEffect("resistance", duration, { amplifier: 2, showParticles: false });
    let ticks = 0;
    const interval = system.runInterval(() => {
      if (ticks >= duration) {
        // Final burst
        try {
          const entities = player.dimension.getEntities({ location: player.location, maxDistance: radius, excludeTypes: ["minecraft:player"] });
          for (const e of entities) {
            try { e.applyDamage(6, { cause: "entityAttack" }); e.applyKnockback(0, 0, 2, 0.5); } catch (err) {}
          }
        } catch (e) {}
        system.clearRun(interval);
        return;
      }
      try {
        const entities = player.dimension.getEntities({ location: player.location, maxDistance: radius, excludeTypes: ["minecraft:player"] });
        for (const e of entities) {
          try {
            e.applyDamage(3, { cause: "entityAttack" });
            const dx = player.location.x - e.location.x;
            const dz = player.location.z - e.location.z;
            const d = Math.sqrt(dx * dx + dz * dz);
            if (d > 0.5) e.applyKnockback(dx / d, dz / d, 0.3, 0);
          } catch (err) {}
        }
        player.dimension.spawnParticle("minecraft:wind_explosion_emitter", player.location);
      } catch (e) {}
      ticks += 4;
    }, 4);
  }

  ability_zephyrDance(player, tier) {
    const charges = tier >= 7 ? 7 : 5;
    const s = StorageManager.forPlayer(player);
    s.setNumber("sp_wind_charges", charges);
    player.addTag("ec.sp_wind_dance");
    player.sendMessage(`§e§lZephyr Dance! §r§7${charges} wind charges active.`);
  }

  // --- Nite (Dual Swordsman) ---
  ability_dimensionalRift(player, tier) {
    const viewDir = player.getViewDirection();
    const dim = player.dimension;
    player.sendMessage("§9§lDimensional Rift!");
    // 5-block line in facing direction
    for (let i = 1; i <= 5; i++) {
      const riftPos = {
        x: player.location.x + viewDir.x * i,
        y: player.location.y + 1,
        z: player.location.z + viewDir.z * i,
      };
      try {
        const entities = dim.getEntities({ location: riftPos, maxDistance: 1.5, excludeTypes: ["minecraft:player"] });
        for (const e of entities) {
          try {
            e.applyDamage(15, { cause: "entityAttack" });
            // Teleport 10 blocks randomly
            const rx = (Math.random() - 0.5) * 20;
            const rz = (Math.random() - 0.5) * 20;
            e.teleport({ x: e.location.x + rx, y: e.location.y, z: e.location.z + rz });
          } catch (err) {}
        }
        dim.spawnParticle("minecraft:endrod", riftPos);
      } catch (e) {}
    }
    player.playSound("mob.shulker.teleport");
  }

  ability_bladeStorm(player, tier) {
    const duration = 100; // 5 seconds
    player.sendMessage("§9§lBlade Storm! §r§7Swords orbit you!");
    let ticks = 0;
    const interval = system.runInterval(() => {
      if (ticks >= duration) { system.clearRun(interval); return; }
      try {
        const angle = (ticks * 18) * (Math.PI / 180); // Rotate
        const radius = 6;
        const orbPos = {
          x: player.location.x + Math.cos(angle) * radius,
          y: player.location.y + 1,
          z: player.location.z + Math.sin(angle) * radius,
        };
        const entities = player.dimension.getEntities({ location: orbPos, maxDistance: 2, excludeTypes: ["minecraft:player"] });
        for (const e of entities) {
          try { e.applyDamage(6, { cause: "entityAttack" }); } catch (err) {}
        }
        player.dimension.spawnParticle("minecraft:critical_hit_emitter", orbPos);
      } catch (e) {}
      ticks += 2;
    }, 2);
  }

  // --- Generic AoE abilities for remaining weapons ---
  ability_beastRally(player, tier) {
    player.sendMessage("§2§lBeast Rally! §r§7Nearby tamed mobs buffed!");
    try {
      const dim = player.dimension;
      const tamed = dim.getEntities({ location: player.location, maxDistance: 16, tags: ["ec.tame_protected"] });
      for (const pet of tamed) {
        try {
          pet.addEffect("strength", 200, { amplifier: 1, showParticles: false });
          pet.addEffect("speed", 200, { amplifier: 1, showParticles: false });
          pet.addEffect("resistance", 200, { amplifier: 0, showParticles: false });
        } catch (err) {}
      }
    } catch (e) {}
    player.playSound("mob.wolf.howl");
  }

  ability_spiritCall(player, tier) {
    player.sendMessage("§2§lSpirit Call! §r§7Summoning spirit wolves!");
    // Spawn temporary wolf allies
    try {
      for (let i = 0; i < 3; i++) {
        const wolf = player.dimension.spawnEntity("minecraft:wolf", {
          x: player.location.x + (Math.random() - 0.5) * 4,
          y: player.location.y,
          z: player.location.z + (Math.random() - 0.5) * 4,
        });
        wolf.addTag("ec.sp_spirit_wolf");
        wolf.addTag("ec.tame_protected");
        wolf.addEffect("strength", 400, { amplifier: 2, showParticles: false });
        wolf.nameTag = "§d§lSpirit Wolf";
        // Auto-despawn after 20 seconds
        system.runTimeout(() => { try { wolf.kill(); } catch (e) {} }, 400);
      }
    } catch (e) {}
    player.playSound("mob.wolf.howl");
  }

  ability_groundPound(player, tier) {
    this.genericAoE(player, "§6§lGround Pound!", 6, 8, "slowness", 1, 60);
  }
  ability_fortress(player, tier) {
    player.addEffect("resistance", 200, { amplifier: 2, showParticles: false });
    player.addEffect("slowness", 200, { amplifier: 1, showParticles: false });
    player.sendMessage("§6§lFortress! §r§7Massive damage reduction for 10s.");
  }
  ability_tidalSurge(player, tier) {
    this.genericAoE(player, "§3§lTidal Surge!", 8, 10, "slowness", 2, 80);
  }
  ability_leviathanStrike(player, tier) {
    this.genericAoE(player, "§3§lLeviathan Strike!", 10, 15, null, 0, 0);
    player.playSound("mob.guardian.elder.curse");
  }
  ability_sandstorm(player, tier) {
    this.genericAoE(player, "§e§lSandstorm!", 6, 6, "blindness", 0, 80);
  }
  ability_pharaohWrath(player, tier) {
    this.genericAoE(player, "§e§lPharaoh's Wrath!", 8, 20, "weakness", 1, 100);
  }
  ability_healPulse(player, tier) {
    player.sendMessage("§a§lHeal Pulse!");
    try {
      const nearby = player.dimension.getPlayers({ location: player.location, maxDistance: 8 });
      for (const ally of nearby) {
        ally.addEffect("instant_health", 1, { amplifier: 2, showParticles: true });
        ally.addEffect("regeneration", 100, { amplifier: 1, showParticles: false });
      }
    } catch (e) {}
    player.playSound("random.levelup");
  }
  ability_naturesEmbrace(player, tier) {
    player.sendMessage("§a§lNature's Embrace! §r§7Healing field for 10s.");
    let ticks = 0;
    const interval = system.runInterval(() => {
      if (ticks >= 200) { system.clearRun(interval); return; }
      try {
        const nearby = player.dimension.getPlayers({ location: player.location, maxDistance: 10 });
        for (const ally of nearby) {
          ally.addEffect("regeneration", 40, { amplifier: 2, showParticles: false });
          ally.addEffect("absorption", 40, { amplifier: 0, showParticles: false });
        }
        player.dimension.spawnParticle("minecraft:villager_happy", player.location);
      } catch (e) {}
      ticks += 20;
    }, 20);
  }
  ability_piercingShot(player, tier) {
    player.sendMessage("§e§lPiercing Shot!");
    const viewDir = player.getViewDirection();
    try {
      for (let i = 2; i <= 20; i += 2) {
        const pos = { x: player.location.x + viewDir.x * i, y: player.location.y + 1 + viewDir.y * i, z: player.location.z + viewDir.z * i };
        const entities = player.dimension.getEntities({ location: pos, maxDistance: 1.5, excludeTypes: ["minecraft:player"] });
        for (const e of entities) {
          try { e.applyDamage(8, { cause: "projectile" }); } catch (err) {}
        }
        player.dimension.spawnParticle("minecraft:critical_hit_emitter", pos);
      }
    } catch (e) {}
    player.playSound("random.bow");
  }
  ability_arrowStorm(player, tier) {
    player.sendMessage("§e§lArrow Storm!");
    let ticks = 0;
    const interval = system.runInterval(() => {
      if (ticks >= 60) { system.clearRun(interval); return; }
      try {
        const dim = player.dimension;
        const entities = dim.getEntities({ location: player.location, maxDistance: 12, excludeTypes: ["minecraft:player"] });
        if (entities.length > 0) {
          const target = entities[Math.floor(Math.random() * entities.length)];
          target.applyDamage(4, { cause: "projectile" });
          dim.spawnParticle("minecraft:critical_hit_emitter", target.location);
        }
      } catch (e) {}
      ticks += 4;
    }, 4);
  }
  ability_dragonSlash(player, tier) {
    this.genericAoE(player, "§c§lDragon Slash!", 5, 12, "wither", 0, 60);
    try { player.dimension.spawnParticle("minecraft:dragon_breath_trail", player.location); } catch (e) {}
  }
  ability_dragonsFury(player, tier) {
    player.sendMessage("§c§lDragon's Fury! §r§7Fire breath for 5s!");
    let ticks = 0;
    const interval = system.runInterval(() => {
      if (ticks >= 100) { system.clearRun(interval); return; }
      const viewDir = player.getViewDirection();
      for (let i = 2; i <= 8; i += 2) {
        const pos = { x: player.location.x + viewDir.x * i, y: player.location.y + 1 + viewDir.y * i, z: player.location.z + viewDir.z * i };
        try {
          const entities = player.dimension.getEntities({ location: pos, maxDistance: 2, excludeTypes: ["minecraft:player"] });
          for (const e of entities) {
            try { e.applyDamage(5, { cause: "fire" }); e.setOnFire(60, false); } catch (err) {}
          }
          player.dimension.spawnParticle("minecraft:dragon_breath_trail", pos);
        } catch (e) {}
      }
      ticks += 5;
    }, 5);
  }
  ability_shieldBash(player, tier) {
    this.genericAoE(player, "§7§lShield Bash!", 3, 6, "slowness", 3, 40);
  }
  ability_fortressWall(player, tier) {
    player.sendMessage("§7§lFortress Wall! §r§7Damage reduction for all allies!");
    try {
      const nearby = player.dimension.getPlayers({ location: player.location, maxDistance: 8 });
      for (const ally of nearby) {
        ally.addEffect("resistance", 200, { amplifier: 1, showParticles: false });
      }
    } catch (e) {}
  }
  ability_vanguardCharge(player, tier) {
    player.sendMessage("§b§lVanguard Charge!");
    const viewDir = player.getViewDirection();
    player.applyKnockback(viewDir.x, viewDir.z, 2, 0.3);
    system.runTimeout(() => {
      this.genericAoE(player, null, 4, 10, "slowness", 1, 60);
    }, 10);
  }
  ability_phalanx(player, tier) {
    player.sendMessage("§b§lPhalanx Formation! §r§7All allies gain Resistance II!");
    try {
      const nearby = player.dimension.getPlayers({ location: player.location, maxDistance: 10 });
      for (const ally of nearby) {
        ally.addEffect("resistance", 200, { amplifier: 1, showParticles: false });
        ally.addEffect("strength", 200, { amplifier: 0, showParticles: false });
      }
    } catch (e) {}
  }

  // --- Generic AoE helper ---
  genericAoE(player, message, radius, damage, effect, amplifier, effectDuration) {
    if (message) player.sendMessage(message);
    try {
      const entities = player.dimension.getEntities({ location: player.location, maxDistance: radius, excludeTypes: ["minecraft:player"] });
      for (const e of entities) {
        try {
          e.applyDamage(damage, { cause: "entityAttack" });
          if (effect) e.addEffect(effect, effectDuration, { amplifier, showParticles: false });
        } catch (err) {}
      }
      player.dimension.spawnParticle("minecraft:huge_explosion_emitter", player.location);
      player.playSound("random.explode");
    } catch (e) {}
  }

  // === KILL TRACKING ===
  onKill(player, entity) {
    const s = StorageManager.forPlayer(player);
    const weaponId = s.getNumber("sp_weapon_id", 0);
    if (weaponId === 0) return;

    // Increment kill counter
    const kills = s.getNumber("sp_kills", 0) + 1;
    s.setNumber("sp_kills", kills);

    // Add mastery XP on kill
    this.addMasteryXP(player, 50);

    // Rampage extension
    if (player.hasTag("ec.sp_rampage")) {
      const timer = s.getNumber("sp_rampage_timer", 0) + 40; // +2 seconds
      s.setNumber("sp_rampage_timer", timer);
      const bonus = s.getNumber("sp_rampage_dmg_bonus", 0) + 10; // +10% per kill
      s.setNumber("sp_rampage_dmg_bonus", bonus);
      // Shockwave on kill during rampage
      try {
        const entities = player.dimension.getEntities({ location: entity.location, maxDistance: 4, excludeTypes: ["minecraft:player"] });
        for (const e of entities) {
          try { e.applyDamage(2, { cause: "entityAttack" }); } catch (err) {}
        }
      } catch (e) {}
    }
  }

  onPlayerHurt(player, damage) {
    const s = StorageManager.forPlayer(player);
    const weaponId = s.getNumber("sp_weapon_id", 0);
    if (weaponId === 0) return;
    // Track damage taken (for Firebrand requirement)
    const dmgTaken = s.getNumber("sp_dmg_taken", 0) + Math.floor(damage);
    s.setNumber("sp_dmg_taken", dmgTaken);
  }

  // === MASTERY XP ===
  addMasteryXP(player, amount) {
    const s = StorageManager.forPlayer(player);
    const currentXP = s.getNumber("sp_mastery_xp", 0);
    const newXP = currentXP + amount;
    s.setNumber("sp_mastery_xp", newXP);

    // Check tier advancement
    const currentTier = s.getNumber("sp_tier", 1);
    let newTier = currentTier;
    for (let i = TIERS.length - 1; i >= 0; i--) {
      if (newXP >= TIERS[i].xp) { newTier = i + 1; break; }
    }

    if (newTier > currentTier) {
      s.setNumber("sp_tier", newTier);
      const tierData = TIERS[newTier - 1];
      const weapon = SPIRIT_WEAPONS.find(w => w.id === s.getNumber("sp_weapon_id", 0));
      player.sendMessage(`\n§6✦ §l${tierData.color}${weapon?.name || "Spirit Weapon"} §r§6reached ${tierData.color}${tierData.name} §6tier! §6✦\n`);
      player.playSound("random.levelup");
      try { player.dimension.spawnParticle("minecraft:villager_happy", player.location); } catch (e) {}

      // Check Spirit tier metamorphosis
      if (newTier >= 7) {
        this.checkMetamorphosis(player);
      }
    }
  }

  // === METAMORPHOSIS ===
  checkMetamorphosis(player) {
    const s = StorageManager.forPlayer(player);
    const weaponId = s.getNumber("sp_weapon_id", 0);
    const reqs = UNIQUE_REQS[weaponId] || DEFAULT_UNIQUE_REQS;
    let allMet = true;

    // Check universal requirements
    // Req 1: All glyph slots filled (simplified check)
    // Req 2: Mastery maxed (simplified check)
    // Req 3: All 13 raid bosses slain
    const bossesSlain = s.getNumber("sp_bosses_slain", 0);
    if (bossesSlain < 13) allMet = false;

    // Check unique requirements
    for (const req of reqs) {
      const val = s.getNumber(req.key, 0);
      if (val < req.target) { allMet = false; break; }
    }

    if (allMet) {
      player.sendMessage("\n§d§l✦ ✦ ✦ SPIRIT METAMORPHOSIS COMPLETE ✦ ✦ ✦\n§r§dYour weapon has transcended!\n");
      player.playSound("ui.toast.challenge_complete");
      try { player.dimension.spawnParticle("minecraft:totem_particle", player.location); } catch (e) {}
    }
  }

  // === DREAM STORM CRYSTAL ===
  useDreamCrystal(player) {
    const s = StorageManager.forPlayer(player);
    const weaponId = s.getNumber("sp_weapon_id", 0);
    if (weaponId === 0) {
      player.sendMessage("§cYou need a Spirit Artifact to use the Dream Storm Crystal.");
      return;
    }

    const weapon = SPIRIT_WEAPONS.find(w => w.id === weaponId);
    if (!weapon) return;

    if (weapon.hasTwin) {
      // Reveal twin weapon
      if (s.getNumber("sp_twin_unlocked", 0) === 1) {
        player.sendMessage("§7You have already unlocked your twin weapon.");
        return;
      }
      s.setNumber("sp_twin_unlocked", 1);
      player.sendMessage(`\n§d§l✦ Dream Storm Crystal ✦\n§r§dThe crystal explodes with energy!\n§6Twin Revealed: §e${weapon.twinName}!\n`);
      player.playSound("random.totem");
      try { player.dimension.spawnParticle("minecraft:totem_particle", player.location); } catch (e) {}
    } else {
      // Grant permanent 25% boost
      if (s.getNumber("sp_solo_boost", 0) === 1) {
        player.sendMessage("§7You have already absorbed the crystal's power.");
        return;
      }
      s.setNumber("sp_solo_boost", 1);
      player.sendMessage(`\n§d§l✦ Dream Storm Crystal ✦\n§r§dThe crystal's power flows through ${weapon.name}!\n§6All abilities permanently empowered by 25%!\n`);
      player.playSound("random.totem");
      try { player.dimension.spawnParticle("minecraft:totem_particle", player.location); } catch (e) {}
    }
  }

  // === GRANT WEAPON ===
  grantWeapon(player, weaponId) {
    const s = StorageManager.forPlayer(player);
    s.setNumber("sp_weapon_id", weaponId);
    s.setNumber("sp_tier", 1);
    s.setNumber("sp_mastery_xp", 0);
    s.setNumber("sp_kills", 0);
    s.setNumber("sp_twin_unlocked", 0);
    s.setNumber("sp_solo_boost", 0);

    const weapon = SPIRIT_WEAPONS.find(w => w.id === weaponId);
    if (!weapon) return;

    player.sendMessage(`\n§d§l✦ Spirit Artifact Obtained ✦\n§r§f${weapon.name} §7(${TIERS[0].name})\n§7This weapon will grow with you.\n`);
    player.playSound("random.totem");
    player.addTag("ec.sp_soulbound");

    // Emit event for Spirit Tome to pick up
    this.eventBridge.emit("spirit_weapon_obtained", { player, weaponId });
  }

  // === STATUS DISPLAY ===
  showStatus(player) {
    const s = StorageManager.forPlayer(player);
    const weaponId = s.getNumber("sp_weapon_id", 0);

    if (weaponId === 0) {
      player.sendMessage("§7You don't have a Spirit Artifact yet. Defeat Raid Bosses to obtain one!");
      return;
    }

    const weapon = SPIRIT_WEAPONS.find(w => w.id === weaponId);
    const tier = s.getNumber("sp_tier", 1);
    const xp = s.getNumber("sp_mastery_xp", 0);
    const kills = s.getNumber("sp_kills", 0);
    const twinUnlocked = s.getNumber("sp_twin_unlocked", 0) === 1;
    const tierData = TIERS[Math.min(tier - 1, TIERS.length - 1)];

    const nextTier = tier < TIERS.length ? TIERS[tier] : null;
    const progressPct = nextTier ? Math.min(100, Math.floor((xp / nextTier.xp) * 100)) : 100;
    const barFilled = Math.floor(progressPct / 5);
    const progressBar = "§a" + "█".repeat(barFilled) + "§8" + "░".repeat(20 - barFilled);

    const form = new ActionFormData()
      .title("Spirit Artifact Status")
      .body([
        `§l${tierData.color}${weapon?.name || "Unknown"}`,
        `§7Tier: ${tierData.color}${tierData.name}`,
        `§7Mastery XP: §f${xp.toLocaleString()}${nextTier ? ` / ${nextTier.xp.toLocaleString()}` : " (MAX)"}`,
        progressBar + ` §f${progressPct}%`,
        `§7Kills: §f${kills.toLocaleString()}`,
        `§7Twin: ${twinUnlocked ? `§a${weapon?.twinName || "Unlocked"}` : "§8Locked"}`,
        `§7Class: §f${weapon?.classId || "Unknown"}`,
      ].join("\n"))
      .button("View Metamorphosis Requirements")
      .button("Close");

    form.show(player).then(response => {
      if (response.selection === 0) this.showRequirements(player);
    });
  }

  showRequirements(player) {
    const s = StorageManager.forPlayer(player);
    const weaponId = s.getNumber("sp_weapon_id", 0);
    const uniqueReqs = UNIQUE_REQS[weaponId] || DEFAULT_UNIQUE_REQS;
    const allReqs = [...UNIVERSAL_REQS.map(r => ({ ...r, key: null })), ...uniqueReqs];

    let body = "§l§dSpirit Metamorphosis Requirements\n\n";
    for (const req of allReqs) {
      const met = req.key ? s.getNumber(req.key, 0) >= (req.target || 1) : false;
      const icon = met ? "§a✔" : "§c✘";
      body += `${icon} §r§7${req.desc}\n`;
    }

    const form = new ActionFormData()
      .title("Metamorphosis")
      .body(body)
      .button("Back");
    form.show(player);
  }

  // === SOULBOUND ENFORCEMENT ===
  enforceSoulbound(player) {
    // Called when player opens container — check if spirit weapon in container
    // Bedrock Script API handles this via itemUse prevention
  }

  onPlayerDeath(player) {
    // Spirit weapons stay in inventory on death (Bedrock handles this differently)
    // Tag ensures the tomb system knows not to drop this item
    const s = StorageManager.forPlayer(player);
    if (s.getNumber("sp_weapon_id", 0) > 0) {
      player.addTag("ec.sp_keep_weapon");
    }
  }
}
