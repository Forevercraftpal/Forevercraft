/**
 * Omens System — Pre-event countdown warnings for Calendar Events and World Events.
 * Calendar omens: 30s countdown at dusk before calendar events fire.
 * World event omens: 60s countdown before world events start.
 * Replaces Java omens/ folder (10 files).
 */
import { world } from "@minecraft/server";

// Calendar event omen definitions (ID → message + particles)
const CALENDAR_OMENS = {
  1: {
    name: "Harvest Festival",
    message: "§7The fields stir with golden energy... §6a harvest is near.",
    particleColor: { r: 1.0, g: 0.85, b: 0.0 }, // Gold
  },
  2: {
    name: "Blood Moon",
    message: "§7A crimson haze creeps across the horizon...",
    particleColor: { r: 0.8, g: 0.1, b: 0.1 }, // Red
  },
  3: {
    name: "Wandering Merchant",
    message: "§7Distant bells echo on the wind... §ea trader approaches.",
    particleColor: null, // Uses enchant particles + bell sounds
  },
  4: {
    name: "Fishing Festival",
    message: "§7The waters ripple with unusual energy...",
    particleColor: { r: 0.2, g: 0.5, b: 1.0 }, // Blue
  },
  5: {
    name: "Meteor Shower",
    message: "§7The stars flicker restlessly overhead...",
    particleColor: null, // Uses end_rod particles
  },
  6: {
    name: "Dimensional Rift",
    message: "§7Reality fractures at the edges of your vision...",
    particleColor: null, // Uses portal particles
  },
  7: {
    name: "Prosperity Wave",
    message: "§7A warm wind carries whispers of fortune...",
    particleColor: { r: 0.2, g: 0.9, b: 0.3 }, // Emerald green
  },
};

// World event omen definitions
const WORLD_EVENT_OMENS = {
  1: {
    name: "Starfall Convergence",
    message: "§7The constellation's alignment draws near... §flook to the sky.",
    cancelMessage: "§7§oThe stars settle... the moment has passed.",
  },
  3: {
    name: "Abyssal Tremor",
    message: "§8The earth groans beneath your feet...",
    cancelMessage: "§7§oThe trembling subsides... for now.",
  },
  4: {
    name: "Aurora Bloom",
    message: "§aDawn's first light carries an otherworldly shimmer...",
    cancelMessage: "§7§oThe shimmer fades with the morning light.",
  },
  5: {
    name: "Rift Echo",
    message: "§5The boundary between worlds grows thin...",
    cancelMessage: "§7§oThe boundary holds... this time.",
  },
};

export class OmenSystem {
  constructor(eventBridge) {
    this.eventBridge = eventBridge;

    // Calendar omen state
    this.calOmenId = 0;       // Active calendar omen event ID (0 = none)
    this.calOmenTimer = 0;    // Countdown in seconds

    // World event omen state
    this.weOmenId = 0;        // Active world event omen ID (0 = none)
    this.weOmenTimer = 0;     // Countdown in seconds

    // Listen for omen trigger events from calendar/world-events systems
    eventBridge.on("calendar_omen_start", (eventId) => {
      this.startCalendarOmen(eventId);
    });

    eventBridge.on("world_event_omen_start", (eventId) => {
      this.startWorldEventOmen(eventId);
    });

    eventBridge.on("world_event_omen_cancel", () => {
      this.cancelWorldEventOmen();
    });
  }

  /**
   * Start a calendar event omen (30s countdown at dusk).
   */
  startCalendarOmen(eventId) {
    if (this.calOmenId !== 0) return; // Already running

    const omen = CALENDAR_OMENS[eventId];
    if (!omen) return;

    this.calOmenId = eventId;
    this.calOmenTimer = 30;

    // Send chat warning to all players
    const players = world.getAllPlayers();
    for (const player of players) {
      player.sendMessage(`§d✦ ${omen.message}`);
      try {
        player.playSound("block.amethyst_block.chime", { volume: 0.4, pitch: 0.8 });
      } catch {}
    }
  }

  /**
   * Start a world event omen (60s countdown).
   */
  startWorldEventOmen(eventId) {
    if (this.weOmenId !== 0) return; // Already running

    const omen = WORLD_EVENT_OMENS[eventId];
    if (!omen) return;

    this.weOmenId = eventId;
    this.weOmenTimer = 60;

    // Send chat warning
    const players = world.getAllPlayers();
    for (const player of players) {
      player.sendMessage(`§d✦ ${omen.message}`);
      try {
        player.playSound("block.amethyst_block.chime", { volume: 0.4, pitch: 0.8 });
      } catch {}
    }
  }

  /**
   * Cancel a world event omen (conditions no longer met).
   */
  cancelWorldEventOmen() {
    if (this.weOmenId === 0) return;

    const omen = WORLD_EVENT_OMENS[this.weOmenId];
    if (omen) {
      const players = world.getAllPlayers();
      for (const player of players) {
        player.sendMessage(omen.cancelMessage);
      }
    }

    this.weOmenId = 0;
    this.weOmenTimer = 0;
  }

  /**
   * Main tick — runs every 20 ticks (1 second).
   * Decrements timers and triggers effects/events.
   */
  tick(players) {
    // === CALENDAR OMEN ===
    if (this.calOmenId !== 0 && this.calOmenTimer > 0) {
      this.calOmenTimer--;

      // Particle effects during countdown
      if (this.calOmenTimer > 0) {
        this.spawnCalendarParticles(players);
      }

      // Timer expired — fire the calendar event
      if (this.calOmenTimer <= 0) {
        const eventId = this.calOmenId;
        this.calOmenId = 0;
        this.calOmenTimer = 0;

        // Emit event to calendar system to start the actual event
        this.eventBridge.emit("calendar_event_fire", eventId);
      }
    }

    // === WORLD EVENT OMEN ===
    if (this.weOmenId !== 0 && this.weOmenTimer > 0) {
      this.weOmenTimer--;

      // Particle effects during last 30 seconds
      if (this.weOmenTimer > 0 && this.weOmenTimer <= 30) {
        this.spawnWorldEventParticles(players);
      }

      // Timer expired — recheck conditions and fire
      if (this.weOmenTimer <= 0) {
        const eventId = this.weOmenId;
        this.weOmenId = 0;
        this.weOmenTimer = 0;

        // Emit recheck event — world-events system will validate conditions
        this.eventBridge.emit("world_event_omen_expired", eventId);
      }
    }
  }

  /**
   * Spawn calendar omen particles around all players.
   */
  spawnCalendarParticles(players) {
    const omen = CALENDAR_OMENS[this.calOmenId];
    if (!omen) return;

    for (const player of players) {
      const loc = player.location;
      const dim = player.dimension;

      try {
        switch (this.calOmenId) {
          case 1: // Harvest — gold dust
            dim.runCommandAsync(
              `particle minecraft:villager_happy ${loc.x} ${loc.y + 1} ${loc.z} 1.5 1 1.5 0 5`
            );
            break;
          case 2: // Blood Moon — red particles
            dim.runCommandAsync(
              `particle minecraft:redstone_ore_dust ${loc.x} ${loc.y + 2} ${loc.z} 2.5 2 2.5 0 8`
            );
            break;
          case 3: // Merchant — enchant sparkles + bells
            dim.runCommandAsync(
              `particle minecraft:enchantingTable ${loc.x} ${loc.y + 1} ${loc.z} 1 0.5 1 0 3`
            );
            if (this.calOmenTimer <= 15) {
              player.playSound("block.bell.hit", { volume: 0.15, pitch: 1.5 });
            }
            break;
          case 4: // Fishing — blue particles
            dim.runCommandAsync(
              `particle minecraft:water_splash ${loc.x} ${loc.y} ${loc.z} 2 0.5 2 0 5`
            );
            break;
          case 5: // Meteor — end rod particles
            dim.runCommandAsync(
              `particle minecraft:endRod ${loc.x} ${loc.y + 5} ${loc.z} 2.5 2 2.5 0 3`
            );
            break;
          case 6: // Rift — portal particles
            dim.runCommandAsync(
              `particle minecraft:portal ${loc.x} ${loc.y + 1} ${loc.z} 1 1 1 0 10`
            );
            break;
          case 7: // Prosperity — green particles
            dim.runCommandAsync(
              `particle minecraft:villager_happy ${loc.x} ${loc.y + 1} ${loc.z} 1 0.5 1 0 5`
            );
            break;
        }
      } catch {}
    }
  }

  /**
   * Spawn world event omen particles around all players.
   */
  spawnWorldEventParticles(players) {
    for (const player of players) {
      const loc = player.location;
      const dim = player.dimension;

      try {
        switch (this.weOmenId) {
          case 1: // Starfall — end rod particles high up
            dim.runCommandAsync(
              `particle minecraft:endRod ${loc.x} ${loc.y + 8} ${loc.z} 4 2 4 0 5`
            );
            break;
          case 3: // Abyssal — brown dust near ground
            dim.runCommandAsync(
              `particle minecraft:falling_dust ${loc.x} ${loc.y} ${loc.z} 2 0.3 2 0 8`
            );
            if (this.weOmenTimer <= 15) {
              player.playSound("entity.warden.heartbeat", { volume: 0.2, pitch: 0.6 });
            }
            break;
          case 4: // Aurora — rainbow particles
            dim.runCommandAsync(
              `particle minecraft:totem ${loc.x} ${loc.y + 2} ${loc.z} 1 1 1 0 5`
            );
            break;
          case 5: // Rift — portal particles
            dim.runCommandAsync(
              `particle minecraft:portal ${loc.x} ${loc.y + 1} ${loc.z} 1 1 1 0 10`
            );
            if (this.weOmenTimer <= 10) {
              player.playSound("block.portal.ambient", { volume: 0.15, pitch: 0.5 });
            }
            break;
        }
      } catch {}
    }
  }

  /**
   * Check if any omen is currently active.
   */
  isActive() {
    return this.calOmenId !== 0 || this.weOmenId !== 0;
  }

  /**
   * Get active omen info for display.
   */
  getActiveInfo() {
    if (this.calOmenId !== 0) {
      const omen = CALENDAR_OMENS[this.calOmenId];
      return { type: "calendar", name: omen?.name, timer: this.calOmenTimer };
    }
    if (this.weOmenId !== 0) {
      const omen = WORLD_EVENT_OMENS[this.weOmenId];
      return { type: "world_event", name: omen?.name, timer: this.weOmenTimer };
    }
    return null;
  }
}
