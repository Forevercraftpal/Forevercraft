/**
 * Fishing Crate System — Custom fishing rewards with tier-based drops.
 * Replaces Java fishing/ folder (24 files).
 * Detects fishing catches and rolls for bonus artifact drops.
 * Features: Rain fishing bonus (+15% catch rarity), crate stat tracking.
 */
import { world, system } from "@minecraft/server";
import { StorageManager } from "../utils/storage.js";

const FISHING_TIERS = [
  { name: "Common", chance: 0.15, loot: "artifacts/common/main", color: "§f" },
  { name: "Uncommon", chance: 0.08, loot: "artifacts/uncommon/main", color: "§e" },
  { name: "Rare", chance: 0.03, loot: "artifacts/rare/main", color: "§b" },
  { name: "Ornate", chance: 0.01, loot: "artifacts/ornate/main", color: "§5" },
  { name: "Exquisite", chance: 0.003, loot: "artifacts/exquisite/main", color: "§6" },
  { name: "Mythical", chance: 0.001, loot: "artifacts/mythical/main", color: "§c" },
];

const RAIN_BONUS = 0.15; // +15% catch rarity during rain

export class FishingCrateSystem {
  constructor(eventBridge) {
    this.eventBridge = eventBridge;

    // Listen for fishing events
    world.afterEvents.itemCompleteUse.subscribe((event) => {
      if (event.itemStack?.typeId === "minecraft:fishing_rod") {
        this.onFishCatch(event.source);
      }
    });
  }

  /** Check if it's currently raining at the player's location */
  isRaining(player) {
    try {
      // Bedrock Script API weather check
      const weather = world.getDimension("overworld");
      // Use command to check — getWeather() not available in all API versions
      return player.dimension.id === "minecraft:overworld" &&
        player.hasTag("ec.in_rain"); // Set by tick-based weather detection
    } catch { return false; }
  }

  onFishCatch(player) {
    if (!player) return;
    const s = StorageManager.forPlayer(player);

    // Track fishing count
    const fishCount = s.getNumber("fish_caught") + 1;
    s.set("fish_caught", fishCount);

    // Dream Rate bonus
    const dreamRate = s.getNumber("dream_rate") || 0;
    let drMultiplier = 1 + dreamRate * 0.01;

    // Rain bonus: +15% catch rarity
    const raining = this.isRaining(player);
    if (raining) {
      drMultiplier *= (1 + RAIN_BONUS);
    }

    // Roll for bonus loot
    for (const tier of FISHING_TIERS) {
      const adjustedChance = tier.chance * drMultiplier;
      if (Math.random() < adjustedChance) {
        this.dropFishingLoot(player, tier, raining);
        return;
      }
    }

    // Show rain hint occasionally
    if (raining && fishCount % 10 === 0) {
      try {
        player.runCommandAsync(`titleraw @s actionbar {"rawtext":[{"text":"§b☔ The fish are biting..."}]}`);
      } catch {}
    }
  }

  dropFishingLoot(player, tier, raining) {
    const loc = player.location;
    try {
      player.dimension.runCommandAsync(
        `loot spawn ${loc.x} ${loc.y + 1} ${loc.z} loot "${tier.loot}"`
      );
    } catch {}

    const rainMsg = raining ? " §b(Rain Bonus!)" : "";
    player.sendMessage(`${tier.color}§l✦ Fishing Crate: §r${tier.color}${tier.name}§r§7 catch!${rainMsg}`);
    player.playSound("random.levelup");

    const s = StorageManager.forPlayer(player);
    // Per-type crate counter
    const count = s.getNumber("crates_fishing") + 1;
    s.set("crates_fishing", count);
    // Total crate counter
    const total = s.getNumber("crates_opened") + 1;
    s.set("crates_opened", total);

    this.eventBridge.emit("crate_opened", player, "fishing", tier.name);
  }
}
