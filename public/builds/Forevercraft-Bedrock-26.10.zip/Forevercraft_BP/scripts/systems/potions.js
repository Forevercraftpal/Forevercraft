/**
 * Growth Serum System — Lingering potion that grows crops in a 4-block radius.
 * Detects area_effect_cloud with instant_health + thick base, advances crops 3 stages.
 * Replaces Java potions/growth_serum/ folder (4 files).
 */
import { world, system } from "@minecraft/server";

// Crop blocks and their max ages
const CROP_AGES = {
  "minecraft:wheat": 7,
  "minecraft:carrots": 7,
  "minecraft:potatoes": 7,
  "minecraft:beetroot": 3,
  "minecraft:melon_stem": 7,
  "minecraft:pumpkin_stem": 7,
  "minecraft:sweet_berry_bush": 3,
  "minecraft:torchflower_crop": 1,
  "minecraft:pitcher_crop": 4,
  "minecraft:nether_wart": 3,
};

export class PotionSystem {
  constructor(eventBridge) {
    this.eventBridge = eventBridge;

    // Listen for item use (throwing potions)
    world.afterEvents.itemUse.subscribe((event) => {
      if (event.itemStack?.typeId === "forevercraft:growth_serum") {
        // Schedule growth effect at player location after short delay
        const player = event.source;
        const pos = { ...player.location };
        const dim = player.dimension;

        system.runTimeout(() => {
          this.applyGrowth(dim, pos, 4, 3);
        }, 40); // 2 second delay for potion to land
      }
    });

    // Also check for splash/lingering potion entities
    this.tickCounter = 0;
  }

  /**
   * Tick — checks for growth serum area effect clouds.
   * Runs every 20 ticks (1 second).
   */
  tick() {
    this.tickCounter++;
    if (this.tickCounter < 20) return;
    this.tickCounter = 0;

    // Check each dimension for area effect clouds tagged as growth serum
    for (const dimId of ["minecraft:overworld", "minecraft:nether"]) {
      try {
        const dim = world.getDimension(dimId);
        const clouds = dim.getEntities({
          type: "minecraft:area_effect_cloud",
          tags: ["!ec.growth_checked"],
        });

        for (const cloud of clouds) {
          cloud.addTag("ec.growth_checked");

          // Check if it's a growth serum cloud
          if (cloud.hasTag("ec.growth_serum")) {
            const loc = cloud.location;
            this.applyGrowth(dim, loc, 4, 3);
            cloud.kill();
          }
        }
      } catch {}
    }
  }

  /**
   * Apply growth to all crops within radius, advancing them by stages.
   */
  applyGrowth(dim, center, radius, stages) {
    const cx = Math.floor(center.x);
    const cy = Math.floor(center.y);
    const cz = Math.floor(center.z);

    // Scan blocks in radius
    for (let dx = -radius; dx <= radius; dx++) {
      for (let dy = -1; dy <= 1; dy++) {
        for (let dz = -radius; dz <= radius; dz++) {
          const x = cx + dx;
          const y = cy + dy;
          const z = cz + dz;

          try {
            const block = dim.getBlock({ x, y, z });
            if (!block) continue;

            const typeId = block.typeId;
            const maxAge = CROP_AGES[typeId];
            if (maxAge === undefined) continue;

            // Get current age from block permutation
            const perm = block.permutation;
            const currentAge = perm.getState("growth") ?? perm.getState("age") ?? 0;

            // Advance by stages, capped at max
            const newAge = Math.min(currentAge + stages, maxAge);
            if (newAge <= currentAge) continue;

            // Set new age
            const stateName = perm.getState("growth") !== undefined ? "growth" : "age";
            try {
              dim.runCommandAsync(
                `setblock ${x} ${y} ${z} ${typeId} ["${stateName}"=${newAge}]`
              );
            } catch {}
          } catch {}
        }
      }
    }

    // Visual effects
    try {
      dim.runCommandAsync(
        `particle minecraft:villager_happy ${cx} ${cy + 1} ${cz} ${radius} 1 ${radius} 0 20`
      );
      dim.playSound("item.bone_meal.use", center, { volume: 0.8, pitch: 1.0 });
    } catch {}
  }
}
