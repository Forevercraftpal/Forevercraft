/**
 * Accessory Tick — Passive effects for 72 accessory/ring artifacts.
 * Replaces Java artifacts/accessories/player_tick.mcfunction (46KB).
 *
 * Checks player inventory + offhand for accessories with custom_data tags.
 * Each accessory grants passive effects (DR bonuses, potion effects, attributes).
 * Runs every 40 ticks (~2 seconds) per player for performance.
 *
 * Effect types: DR bonus (luck attribute), potion effects, conditional triggers
 */
import { world, system, EffectTypes } from "@minecraft/server";
import { StorageManager } from "../utils/storage.js";

// Accessory definitions: { id, effects: [{type, ...params}] }
// type: "dr" = luck modifier, "effect" = potion effect, "conditional_effect" = HP-gated
const ACCESSORIES = [
  // === COMMON ===
  { id: "pebble_of_dreams",    effects: [{ type: "dr", amount: 1 }] },
  { id: "travelers_charm",     effects: [{ type: "effect", effect: "speed", dur: 5, amp: 0 }] },
  { id: "worn_compass",        effects: [{ type: "conditional_effect", effect: "slow_falling", dur: 5, amp: 0, condition: "below_y0" }] },

  // === UNCOMMON ===
  { id: "glowstone_pendant",   effects: [{ type: "effect", effect: "night_vision", dur: 15, amp: 0 }] },
  { id: "iron_talisman",       effects: [{ type: "effect", effect: "resistance", dur: 5, amp: 0 }] },
  { id: "featherweight_stone", effects: [{ type: "effect", effect: "slow_falling", dur: 5, amp: 0 }] },
  { id: "stormcatcher_shard",  effects: [{ type: "effect", effect: "haste", dur: 5, amp: 0 }] },
  { id: "wind_chime",          effects: [{ type: "effect", effect: "speed", dur: 5, amp: 0 }] },

  // === RARE ===
  { id: "aquamarine_ring",     effects: [{ type: "dr", amount: 1 }] },
  { id: "ruin_watch",          effects: [{ type: "dr", amount: 1 }] },
  { id: "heartstone",          effects: [{ type: "conditional_effect", effect: "regeneration", dur: 5, amp: 0, condition: "below_6_hearts" }] },
  { id: "miners_lantern",      effects: [{ type: "effect", effect: "night_vision", dur: 15, amp: 0 }, { type: "dr", amount: 1 }] },
  { id: "seers_compass",       effects: [{ type: "effect", effect: "night_vision", dur: 15, amp: 0 }, { type: "effect", effect: "speed", dur: 5, amp: 0 }] },
  { id: "merchants_coin",      effects: [{ type: "dr", amount: 1 }, { type: "effect", effect: "hero_of_the_village", dur: 5, amp: 0 }] },
  { id: "healers_salve",       effects: [{ type: "conditional_effect", effect: "regeneration", dur: 5, amp: 0, condition: "always" }] },
  { id: "anglers_pearl",       effects: [{ type: "dr", amount: 1 }] },
  { id: "berserkers_fang",     effects: [{ type: "conditional_effect", effect: "strength", dur: 5, amp: 0, condition: "below_50_pct" },
                                         { type: "conditional_effect", effect: "haste", dur: 5, amp: 0, condition: "below_30_pct" }] },
  { id: "cartographers_lens",  effects: [{ type: "effect", effect: "speed", dur: 5, amp: 0 }, { type: "effect", effect: "saturation", dur: 3, amp: 0 }] },
  { id: "enchanted_monocle",   effects: [{ type: "effect", effect: "night_vision", dur: 15, amp: 0 }, { type: "dr", amount: 1 }] },
  { id: "phoenix_feather",     effects: [{ type: "effect", effect: "fire_resistance", dur: 5, amp: 0 }] },
  { id: "soul_lantern_fragment", effects: [{ type: "dr", amount: 0.5 }] },
  { id: "farmers_almanac",     effects: [{ type: "effect", effect: "haste", dur: 5, amp: 0 }] },

  // === ORNATE ===
  { id: "spelunkers_echo",     effects: [{ type: "effect", effect: "night_vision", dur: 15, amp: 0 }, { type: "effect", effect: "haste", dur: 5, amp: 0 }] },
  { id: "blaze_core",          effects: [{ type: "effect", effect: "fire_resistance", dur: 5, amp: 0 }, { type: "effect", effect: "strength", dur: 5, amp: 0 }] },
  { id: "redstone_heart",      effects: [{ type: "effect", effect: "haste", dur: 5, amp: 1 }] },
  { id: "phantom_charm",       effects: [{ type: "effect", effect: "slow_falling", dur: 5, amp: 0 }, { type: "effect", effect: "speed", dur: 5, amp: 0 }] },
  { id: "berserker_totem",     effects: [{ type: "conditional_effect", effect: "strength", dur: 5, amp: 1, condition: "below_50_pct" }] },
  { id: "abyssal_pearl",       effects: [{ type: "dr", amount: 1.5 }, { type: "effect", effect: "water_breathing", dur: 15, amp: 0 }] },
  { id: "architects_design",   effects: [{ type: "dr", amount: 1 }, { type: "effect", effect: "haste", dur: 5, amp: 0 }] },
  { id: "prism_of_light",      effects: [{ type: "effect", effect: "night_vision", dur: 15, amp: 0 }, { type: "dr", amount: 1 }] },
  { id: "sea_heart_relic",     effects: [{ type: "effect", effect: "water_breathing", dur: 15, amp: 0 }, { type: "effect", effect: "dolphins_grace", dur: 5, amp: 0 }] },

  // === EXQUISITE ===
  { id: "infernal_heart",      effects: [{ type: "effect", effect: "fire_resistance", dur: 5, amp: 0 }, { type: "effect", effect: "strength", dur: 5, amp: 0 }, { type: "dr", amount: 1 }] },
  { id: "nether_star_shard",   effects: [{ type: "effect", effect: "regeneration", dur: 5, amp: 0 }, { type: "dr", amount: 2 }] },
  { id: "dragons_tear",        effects: [{ type: "dr", amount: 2 }, { type: "effect", effect: "strength", dur: 5, amp: 0 }] },
  { id: "dream_aegis",         effects: [{ type: "dr", amount: 2 }, { type: "effect", effect: "resistance", dur: 5, amp: 0 }] },
  { id: "soulkeepers_ember",   effects: [{ type: "dr", amount: 1.5 }, { type: "effect", effect: "fire_resistance", dur: 5, amp: 0 }] },
  { id: "earthshaker_core",    effects: [{ type: "effect", effect: "resistance", dur: 5, amp: 0 }, { type: "effect", effect: "haste", dur: 5, amp: 1 }] },
  { id: "behemoths_heart",     effects: [{ type: "effect", effect: "resistance", dur: 5, amp: 0 }, { type: "effect", effect: "absorption", dur: 10, amp: 0 }] },

  // === MYTHICAL ===
  { id: "ender_dragon_scale",  effects: [{ type: "dr", amount: 3 }, { type: "effect", effect: "strength", dur: 5, amp: 0 }, { type: "effect", effect: "resistance", dur: 5, amp: 0 }] },
  { id: "netherite_nexus",     effects: [{ type: "dr", amount: 2 }, { type: "effect", effect: "fire_resistance", dur: 5, amp: 0 }, { type: "effect", effect: "haste", dur: 5, amp: 1 }] },
  { id: "codex_of_everything", effects: [{ type: "dr", amount: 3 }, { type: "effect", effect: "night_vision", dur: 15, amp: 0 }] },
  { id: "nightmare_fragment",  effects: [{ type: "dr", amount: 2 }, { type: "effect", effect: "speed", dur: 5, amp: 1 }] },
  { id: "sculk_heart",         effects: [{ type: "dr", amount: 2 }, { type: "effect", effect: "resistance", dur: 5, amp: 0 }, { type: "effect", effect: "strength", dur: 5, amp: 0 }] },
  { id: "sculk_singularity",   effects: [{ type: "dr", amount: 3 }, { type: "effect", effect: "haste", dur: 5, amp: 1 }, { type: "effect", effect: "speed", dur: 5, amp: 0 }] },
  { id: "beacon_of_ancients",  effects: [{ type: "dr", amount: 3 }, { type: "effect", effect: "regeneration", dur: 5, amp: 0 }, { type: "effect", effect: "resistance", dur: 5, amp: 0 }] },
  { id: "heart_of_the_void",   effects: [{ type: "dr", amount: 3 }, { type: "effect", effect: "absorption", dur: 10, amp: 1 }] },
  { id: "claudes_eye",         effects: [{ type: "dr", amount: 5 }, { type: "effect", effect: "night_vision", dur: 15, amp: 0 }, { type: "effect", effect: "speed", dur: 5, amp: 1 }] },
  { id: "claudes_gift",        effects: [{ type: "dr", amount: 5 }, { type: "effect", effect: "regeneration", dur: 5, amp: 0 }, { type: "effect", effect: "strength", dur: 5, amp: 0 }, { type: "effect", effect: "resistance", dur: 5, amp: 0 }] },

  // === RINGS (13 total) ===
  { id: "ring_amethyst",       effects: [{ type: "dr", amount: 0.5 }] },
  { id: "ring_bone",           effects: [{ type: "dr", amount: 0.5 }] },
  { id: "ring_diamond",        effects: [{ type: "dr", amount: 1 }] },
  { id: "ring_emerald",        effects: [{ type: "dr", amount: 1 }, { type: "effect", effect: "hero_of_the_village", dur: 5, amp: 0 }] },
  { id: "ring_honey",          effects: [{ type: "dr", amount: 0.5 }, { type: "effect", effect: "saturation", dur: 3, amp: 0 }] },
  { id: "ring_lapis",          effects: [{ type: "dr", amount: 1 }] },
  { id: "ring_nether",         effects: [{ type: "dr", amount: 1 }, { type: "effect", effect: "fire_resistance", dur: 5, amp: 0 }] },
  { id: "ring_of_undying",     effects: [{ type: "dr", amount: 1.5 }] },  // + death save
  { id: "ring_ominous",        effects: [{ type: "dr", amount: 1 }] },
  { id: "ring_redstone",       effects: [{ type: "dr", amount: 0.5 }, { type: "effect", effect: "haste", dur: 5, amp: 0 }] },
  { id: "ring_slime",          effects: [{ type: "dr", amount: 0.5 }, { type: "effect", effect: "jump_boost", dur: 5, amp: 0 }] },
  { id: "ring_trial",          effects: [{ type: "dr", amount: 1.5 }] },
  { id: "ring_void",           effects: [{ type: "dr", amount: 2 }] },
  { id: "ring_warden",         effects: [{ type: "dr", amount: 2 }, { type: "effect", effect: "resistance", dur: 5, amp: 0 }] },

  // === BOSS EXCLUSIVES ===
  { id: "soul_protection",     effects: [{ type: "dr", amount: 2 }] },  // + death save (3min cd)
  { id: "soul_reaver",         effects: [{ type: "dr", amount: 2 }, { type: "effect", effect: "strength", dur: 5, amp: 1 }] },
];

// Build lookup map for fast access
const ACCESSORY_MAP = new Map();
for (const acc of ACCESSORIES) ACCESSORY_MAP.set(acc.id, acc);

export class AccessoryTickSystem {
  constructor(eventBridge) {
    this.eventBridge = eventBridge;
    // Track active DR modifiers per player to clean up when accessory removed
    /** @type {Map<string, Set<string>>} */
    this.activeDR = new Map();
  }

  /** Run per player every 40 ticks (called from main tick) */
  tick(player) {
    const found = this.scanInventory(player);
    const playerId = player.id;

    // Get previous active set
    const prev = this.activeDR.get(playerId) || new Set();
    const current = new Set();

    for (const accId of found) {
      const acc = ACCESSORY_MAP.get(accId);
      if (!acc) continue;

      for (const fx of acc.effects) {
        if (fx.type === "dr") {
          current.add(accId);
          if (!prev.has(accId)) {
            // Apply DR modifier via tag + storage (minecraft:luck attribute doesn't exist in Bedrock)
            try {
              player.addTag(`ec.luck_bonus`);
              const s = StorageManager.forPlayer(player);
              s.set(`acc_dr_${accId}`, fx.amount);
            } catch {}
          }
        } else if (fx.type === "effect") {
          this.applyEffect(player, fx);
        } else if (fx.type === "conditional_effect") {
          if (this.checkCondition(player, fx.condition)) {
            this.applyEffect(player, fx);
          }
        }
      }
    }

    // Remove DR modifiers for accessories no longer in inventory
    for (const oldId of prev) {
      if (!current.has(oldId)) {
        try {
          const s = StorageManager.forPlayer(player);
          s.set(`acc_dr_${oldId}`, 0);
        } catch {}
      }
    }
    // Remove luck_bonus tag if no DR accessories remain
    if (current.size === 0 && prev.size > 0) {
      try { player.removeTag("ec.luck_bonus"); } catch {}
    }

    this.activeDR.set(playerId, current);
  }

  /** Scan player inventory for accessory items.
   * OPT: Build a Set of all item lore keywords once, then check against ACCESSORY_MAP.
   * This is O(slots × lore_lines) instead of O(slots × 72_accessories × lore_lines). */
  scanInventory(player) {
    const found = [];
    try {
      const inv = player.getComponent("minecraft:inventory");
      if (!inv?.container) return found;

      for (let i = 0; i < inv.container.size; i++) {
        const item = inv.container.getItem(i);
        if (!item) continue;
        const lore = item.getLore?.() || [];
        if (lore.length === 0) continue; // Skip items with no lore (most items)
        // Check lore lines against accessory ID map (O(1) per ID found)
        for (const line of lore) {
          if (ACCESSORY_MAP.has(line)) { found.push(line); break; }
          // Fallback: check if any known ID is substring of lore line
          for (const [id] of ACCESSORY_MAP) {
            if (line.includes(id)) { found.push(id); break; }
          }
        }
      }

      // Also check offhand
      const equip = player.getComponent("minecraft:equippable");
      if (equip) {
        const offhand = equip.getEquipment("Offhand");
        if (offhand) {
          const lore = offhand.getLore?.() || [];
          for (const acc of ACCESSORIES) {
            if (lore.some(l => l.includes(acc.id)) || offhand.typeId?.includes(acc.id)) {
              if (!found.includes(acc.id)) found.push(acc.id);
              break;
            }
          }
        }
      }
    } catch {}
    return found;
  }

  /** Apply a potion effect — won't overwrite a stronger effect from another system */
  applyEffect(player, fx) {
    try {
      const effectType = EffectTypes.get(fx.effect);
      if (!effectType) return;
      const existing = player.getEffect(effectType);
      if (existing && existing.amplifier > fx.amp) return; // Don't overwrite stronger
      player.addEffect(effectType, fx.dur * 20, { amplifier: fx.amp, showParticles: false });
    } catch {}
  }

  /** Check conditional requirements */
  checkCondition(player, condition) {
    try {
      const hp = player.getComponent("minecraft:health");
      const current = hp?.currentValue || 20;
      const max = hp?.effectiveMax || 20;
      switch (condition) {
        case "below_y0": return player.location.y < 0;
        case "below_6_hearts": return current < 12;
        case "below_50_pct": return current < max * 0.5;
        case "below_30_pct": return current < max * 0.3;
        case "always": return true;
        default: return true;
      }
    } catch { return false; }
  }

  /** Cleanup on player leave */
  onPlayerLeave(playerId) {
    this.activeDR.delete(playerId);
  }

  // === FORTUNE BONUS SYSTEM ===
  // Since Bedrock Script API can't dynamically add Fortune enchantment,
  // we simulate it with bonus item drops on block break.
  // Accessories: miners_lantern (+2 fortune equiv), spelunkers_echo (+1),
  //   soul_lantern_fragment (+1), anglers_pearl (fishing luck +1)
  static FORTUNE_ACCESSORIES = new Set([
    "miners_lantern", "spelunkers_echo", "soul_lantern_fragment",
    "architects_design", "redstone_heart"
  ]);

  static FORTUNE_ORE_DROPS = {
    "minecraft:coal_ore": "minecraft:coal",
    "minecraft:deepslate_coal_ore": "minecraft:coal",
    "minecraft:iron_ore": "minecraft:raw_iron",
    "minecraft:deepslate_iron_ore": "minecraft:raw_iron",
    "minecraft:gold_ore": "minecraft:raw_gold",
    "minecraft:deepslate_gold_ore": "minecraft:raw_gold",
    "minecraft:copper_ore": "minecraft:raw_copper",
    "minecraft:deepslate_copper_ore": "minecraft:raw_copper",
    "minecraft:diamond_ore": "minecraft:diamond",
    "minecraft:deepslate_diamond_ore": "minecraft:diamond",
    "minecraft:lapis_ore": "minecraft:lapis_lazuli",
    "minecraft:deepslate_lapis_ore": "minecraft:lapis_lazuli",
    "minecraft:redstone_ore": "minecraft:redstone",
    "minecraft:deepslate_redstone_ore": "minecraft:redstone",
    "minecraft:emerald_ore": "minecraft:emerald",
    "minecraft:deepslate_emerald_ore": "minecraft:emerald",
    "minecraft:nether_gold_ore": "minecraft:gold_nugget",
    "minecraft:nether_quartz_ore": "minecraft:quartz",
  };

  /** Called from block break event — check for fortune accessory bonus drops */
  onBlockBreak(player, blockTypeId, blockLocation) {
    const dropItem = AccessoryTickSystem.FORTUNE_ORE_DROPS[blockTypeId];
    if (!dropItem) return;

    const activeIds = this.activeDR.get(player.id);
    if (!activeIds) return;

    let fortuneLevel = 0;
    for (const accId of activeIds) {
      if (AccessoryTickSystem.FORTUNE_ACCESSORIES.has(accId)) {
        fortuneLevel += (accId === "miners_lantern") ? 2 : 1;
      }
    }
    if (fortuneLevel <= 0) return;

    // Fortune chance: each level = 33% chance for +1 extra drop
    let bonusDrops = 0;
    for (let i = 0; i < fortuneLevel; i++) {
      if (Math.random() < 0.33) bonusDrops++;
    }

    if (bonusDrops > 0) {
      try {
        const { x, y, z } = blockLocation;
        player.dimension.runCommandAsync(
          `loot spawn ${x} ${y} ${z} loot empty`
        ).catch(() => {});
        // Spawn item entities directly
        for (let i = 0; i < bonusDrops; i++) {
          player.dimension.runCommandAsync(
            `summon item ${x} ${y + 0.5} ${z} ${dropItem}`
          ).catch(() => {});
        }
      } catch {}
    }
  }

  // === FISHING LUCK BONUS ===
  // Anglers Pearl: +1 fishing luck (Lure + Luck of the Sea equivalent)
  // Handled via DR modifier which affects fishing through Dream Rate
  // (Java uses enchantment modification, Bedrock uses DR → fishing rarity)

  // === SOUL LANTERN XP BOOST ===
  // +25% XP from mob kills when soul_lantern_fragment in inventory
  static XP_BOOST_ACCESSORIES = new Set(["soul_lantern_fragment", "codex_of_everything"]);

  getXPMultiplier(player) {
    const activeIds = this.activeDR.get(player.id);
    if (!activeIds) return 1.0;
    let mult = 1.0;
    for (const accId of activeIds) {
      if (AccessoryTickSystem.XP_BOOST_ACCESSORIES.has(accId)) {
        mult += 0.25;
      }
    }
    return mult;
  }

  // === DEATH SAVE ACCESSORIES ===
  // Ring of Undying: prevent death once, 5-minute cooldown
  // Soul Protection: prevent death once, 3-minute cooldown
  // Heart of the Void: prevent death once, 5-minute cooldown
  static DEATH_SAVE_ACCESSORIES = {
    "ring_of_undying":  { cooldownKey: "cd_undying",  cooldownTicks: 6000,  healAmount: 4 },
    "soul_protection":  { cooldownKey: "cd_soul",     cooldownTicks: 3600,  healAmount: 6 },
    "heart_of_the_void": { cooldownKey: "cd_void",    cooldownTicks: 6000,  healAmount: 8 },
  };

  /** Check if player has a death-save accessory off cooldown. Returns heal amount or 0. */
  checkDeathSave(player) {
    const activeIds = this.activeDR.get(player.id);
    if (!activeIds) return 0;

    const s = StorageManager.forPlayer(player);
    for (const [accId, info] of Object.entries(AccessoryTickSystem.DEATH_SAVE_ACCESSORIES)) {
      if (activeIds.has(accId)) {
        const cd = s.getNumber(info.cooldownKey, 0);
        if (cd <= 0) {
          // Trigger death save
          s.setNumber(info.cooldownKey, info.cooldownTicks);
          player.sendMessage(`§d§l✦ ${accId.replace(/_/g, " ")} saved you from death! ✦`);
          player.playSound("item.totem.use");
          try { player.dimension.spawnParticle("minecraft:totem_particle", player.location); } catch {}
          return info.healAmount;
        }
      }
    }
    return 0;
  }

  /** Tick death save cooldowns (called every 20 ticks) */
  tickCooldowns(player) {
    const s = StorageManager.forPlayer(player);
    for (const info of Object.values(AccessoryTickSystem.DEATH_SAVE_ACCESSORIES)) {
      const cd = s.getNumber(info.cooldownKey, 0);
      if (cd > 0) s.setNumber(info.cooldownKey, cd - 20);
    }
  }
}
