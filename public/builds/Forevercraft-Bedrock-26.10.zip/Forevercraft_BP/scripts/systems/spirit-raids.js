/**
 * Spirit Raids System — Endgame raid bosses (13 unique encounters).
 * Extends dungeon system past floor 10 into raid mode.
 * DR 10+ required. Floor voting, 3-phase bosses, 5% spirit artifact drops.
 * Replaces Java raids/ folder (353 files).
 */
import { world, system } from "@minecraft/server";
import { StorageManager } from "../utils/storage.js";
import { ActionFormData } from "@minecraft/server-ui";

// 13 Raid Bosses with structure associations
const RAID_BOSSES = [
  { id: 1,  name: "The Hollow Sovereign",  structure: "ancient_city",       classArtifact: 1,  hp: 2000, mobType: "minecraft:warden",           phases: 3, color: "§5" },
  { id: 2,  name: "The Void Architect",    structure: "end_city",           classArtifact: 2,  hp: 1800, mobType: "minecraft:enderman",          phases: 3, color: "§9" },
  { id: 3,  name: "The Gilded Tyrant",     structure: "bastion_remnant",    classArtifact: 3,  hp: 2200, mobType: "minecraft:piglin_brute",      phases: 3, color: "§6" },
  { id: 4,  name: "The Arbiter",           structure: "trial_chambers",     classArtifact: 4,  hp: 1600, mobType: "minecraft:breeze",            phases: 3, color: "§e" },
  { id: 5,  name: "The Gatekeeper",        structure: "stronghold",         classArtifact: 5,  hp: 2500, mobType: "minecraft:wither_skeleton",   phases: 3, color: "§8" },
  { id: 6,  name: "The Grand Illusionist", structure: "woodland_mansion",   classArtifact: 6,  hp: 1500, mobType: "minecraft:evoker",            phases: 3, color: "§2" },
  { id: 7,  name: "The Ashen Lord",        structure: "nether_fortress",    classArtifact: 7,  hp: 2000, mobType: "minecraft:blaze",             phases: 3, color: "§4" },
  { id: 8,  name: "The Leviathan",         structure: "ocean_monument",     classArtifact: 8,  hp: 2400, mobType: "minecraft:elder_guardian",    phases: 3, color: "§3" },
  { id: 9,  name: "The Eternal Pharaoh",   structure: "desert_pyramid",     classArtifact: 9,  hp: 1800, mobType: "minecraft:husk",              phases: 3, color: "§e" },
  { id: 10, name: "The Venomweaver",       structure: "jungle_pyramid",     classArtifact: 10, hp: 1600, mobType: "minecraft:spider",            phases: 3, color: "§a" },
  { id: 11, name: "The Deepcrawler",       structure: "mineshaft",          classArtifact: 11, hp: 1400, mobType: "minecraft:cave_spider",       phases: 3, color: "§7" },
  { id: 12, name: "The Mossheart Warden",  structure: "dungeon",            classArtifact: 12, hp: 2000, mobType: "minecraft:zombie",            phases: 3, color: "§2" },
  { id: 13, name: "The Crimson Bulwark",   structure: "castle_floor_25",    classArtifact: 13, hp: 3000, mobType: "minecraft:iron_golem",        phases: 3, color: "§c" },
];

// Boss flavor text for floor 10 entry prompt
const BOSS_PROMPTS = {
  1:  "The walls weep sculk. Something ancient stirs below...\nThose who enter the Hollow Throne do not leave unchanged.",
  2:  "Reality fractures at the seams. The Architect watches from between dimensions.",
  3:  "Gold drips from the walls like blood. The Tyrant's treasures are his teeth.",
  4:  "The scales of justice tip toward oblivion. The Arbiter awaits your verdict.",
  5:  "An iron gate older than the world bars your path.\nThe Gatekeeper has never been defeated.",
  6:  "Mirrors line every wall, each showing a different death.\nWhich is the illusion? Which is real?",
  7:  "The fortress burns eternal. The Ashen Lord sits upon a throne of embers.",
  8:  "The water is alive. The Leviathan IS the ocean.",
  9:  "Sand whispers prophecy. The Pharaoh has waited ten thousand years for challengers.",
  10: "Vines pulse with venom. The Venomweaver's web has no escape.",
  11: "Something clicks in the darkness below. It has too many legs.",
  12: "The moss remembers everything. The Warden remembers you.",
  13: "The Crimson Bulwark has never fallen. You will not be the first.",
};

// DR scaling for raid floor mobs
const DR_SCALING = [
  { minDR: 10, hpMult: 1.0, dmgMult: 1.0 },
  { minDR: 15, hpMult: 1.5, dmgMult: 1.25 },
  { minDR: 20, hpMult: 2.0, dmgMult: 1.5 },
  { minDR: 25, hpMult: 3.0, dmgMult: 1.75 },
  { minDR: 30, hpMult: 4.0, dmgMult: 2.0 },
  { minDR: 35, hpMult: 6.0, dmgMult: 2.5 },
];

// Raid floor mob compositions (floors 1-9)
const FLOOR_WAVES = [
  [{ type: "minecraft:zombie", count: 4 }, { type: "minecraft:skeleton", count: 2 }],
  [{ type: "minecraft:husk", count: 5 }, { type: "minecraft:stray", count: 3 }],
  [{ type: "minecraft:spider", count: 4 }, { type: "minecraft:cave_spider", count: 3 }],
  [{ type: "minecraft:creeper", count: 3 }, { type: "minecraft:witch", count: 2 }],
  [{ type: "minecraft:blaze", count: 3 }, { type: "minecraft:wither_skeleton", count: 2 }],
  [{ type: "minecraft:vindicator", count: 4 }, { type: "minecraft:pillager", count: 3 }],
  [{ type: "minecraft:enderman", count: 3 }, { type: "minecraft:shulker", count: 2 }],
  [{ type: "minecraft:evoker", count: 2 }, { type: "minecraft:ravager", count: 1 }],
  [{ type: "minecraft:wither_skeleton", count: 5 }, { type: "minecraft:blaze", count: 4 }],
];

export class SpiritRaidSystem {
  constructor(eventBridge, spiritWeaponSystem) {
    this.eventBridge = eventBridge;
    this.spiritWeapons = spiritWeaponSystem;

    // Active raid instance (only one at a time)
    this.active = null;
    // { bossId, floor, players: Map<id, {x,y,z,dim}>, mobs: Set<entityId>,
    //   bossEntity: entity, bossPhase: 1-3, bossMaxHP: num,
    //   voteTimer: num, voteContinue: num, voteEvacuate: num, voteOpen: bool }

    this.eventBridge.on("player_killed_entity", (data) => {
      if (this.active && this.active.bossEntity) {
        this.onEntityKilled(data.entity);
      }
    });
  }

  // === TICK (called every tick when raid is active) ===
  tick() {
    if (!this.active) return;

    // Vote phase
    if (this.active.voteOpen) {
      this.active.voteTimer--;
      if (this.active.voteTimer <= 0) this.processVotes();
      return;
    }

    // Floor combat phase (floors 1-9)
    if (this.active.floor < 10) {
      this.tickFloorCombat();
      return;
    }

    // Boss phase (floor 10)
    if (this.active.floor === 10 && this.active.bossEntity) {
      this.tickBoss();
    }
  }

  // === RAID ENTRY ===
  tryEnterRaid(player, structureType) {
    if (this.active) {
      player.sendMessage("§cA raid is already in progress.");
      return;
    }

    // DR check
    const s = StorageManager.forPlayer(player);
    const dr = s.getNumber("dream_rate", 0);
    if (dr < 10) {
      player.sendMessage("§cYou need Dream Rate 10+ to enter a Spirit Raid.");
      return;
    }

    // Find boss for this structure
    const boss = RAID_BOSSES.find(b => b.structure === structureType);
    if (!boss) {
      player.sendMessage("§cThis structure doesn't have a raid boss.");
      return;
    }

    // Show entry confirmation
    const form = new ActionFormData()
      .title(`Spirit Raid — ${boss.name}`)
      .body([
        `${boss.color}§l${boss.name}`,
        "",
        "§7This raid has 10 floors of escalating combat.",
        "§7Floor 10 is a unique Raid Boss encounter.",
        "",
        "§cDeath means losing ALL experience levels.",
        "§cYou will be sent home on failure.",
        "",
        `§7Your Dream Rate: §f${dr}`,
      ].join("\n"))
      .button("§2Enter the Raid")
      .button("§cTurn Back");

    form.show(player).then(response => {
      if (response.selection === 0) this.startRaid(player, boss);
    });
  }

  startRaid(player, boss) {
    // Save player position
    const savedPositions = new Map();
    savedPositions.set(player.id, {
      x: player.location.x,
      y: player.location.y,
      z: player.location.z,
      dimension: player.dimension.id,
    });

    this.active = {
      bossId: boss.id,
      bossData: boss,
      floor: 1,
      players: savedPositions,
      playerIds: new Set([player.id]),
      mobs: new Set(),
      bossEntity: null,
      bossPhase: 0,
      bossMaxHP: boss.hp,
      voteTimer: 0,
      voteContinue: 0,
      voteEvacuate: 0,
      voteOpen: false,
      waveCleared: false,
      floorTimer: 0,
    };

    // Add nearby party members
    try {
      const nearby = player.dimension.getPlayers({
        location: player.location,
        maxDistance: 16,
        excludeNames: [player.name],
      });
      for (const ally of nearby) {
        if (ally.hasTag("ec.in_party")) {
          this.active.players.set(ally.id, {
            x: ally.location.x, y: ally.location.y, z: ally.location.z,
            dimension: ally.dimension.id,
          });
          this.active.playerIds.add(ally.id);
          ally.addTag("ec.rd_participant");
        }
      }
    } catch (e) {}

    player.addTag("ec.rd_participant");

    // Teleport to raid area (Y=400+ in overworld)
    const raidY = 400;
    const raidX = 100000 + boss.id * 100;
    const raidZ = 0;

    for (const [pid, _] of this.active.players) {
      try {
        const p = world.getEntity(pid);
        if (p) {
          p.teleport({ x: raidX, y: raidY, z: raidZ });
          p.sendMessage(`\n§d§l✦ Spirit Raid: ${boss.color}${boss.name} §d§l✦\n§7Floor 1 of 10 — Prepare for combat!\n`);
          p.playSound("raid.horn");
        }
      } catch (e) {}
    }

    // Spawn floor 1 mobs
    this.spawnFloorMobs(1, { x: raidX, y: raidY, z: raidZ });
  }

  // === FLOOR COMBAT ===
  spawnFloorMobs(floor, center) {
    const wave = FLOOR_WAVES[Math.min(floor - 1, FLOOR_WAVES.length - 1)];
    const dim = world.getDimension("overworld");
    const s = StorageManager.forPlayer(this.getFirstPlayer());
    const dr = s?.getNumber("dream_rate", 10) || 10;
    const scaling = DR_SCALING.find(s => dr >= s.minDR) || DR_SCALING[0];

    for (const group of wave) {
      const count = group.count + Math.floor(floor / 3); // More mobs on higher floors
      for (let i = 0; i < count; i++) {
        try {
          const mob = dim.spawnEntity(group.type, {
            x: center.x + (Math.random() - 0.5) * 10,
            y: center.y,
            z: center.z + (Math.random() - 0.5) * 10,
          });
          mob.addTag("ec.rd_mob");
          this.active.mobs.add(mob.id);

          // Scale HP
          try {
            const health = mob.getComponent("minecraft:health");
            if (health) {
              const scaledHP = Math.floor(health.effectiveMax * scaling.hpMult * (1 + floor * 0.1));
              health.setCurrentValue(scaledHP);
            }
          } catch (err) {}
        } catch (e) {}
      }
    }
    this.active.waveCleared = false;
    this.active.floorTimer = 0;
  }

  tickFloorCombat() {
    this.active.floorTimer++;

    // Check if all mobs dead
    if (this.active.floorTimer % 20 === 0) {
      let alive = 0;
      for (const mobId of this.active.mobs) {
        try {
          const mob = world.getEntity(mobId);
          if (mob && mob.getComponent("minecraft:health")?.currentValue > 0) alive++;
          else this.active.mobs.delete(mobId);
        } catch (e) { this.active.mobs.delete(mobId); }
      }

      if (alive === 0 && !this.active.waveCleared) {
        this.active.waveCleared = true;
        this.onFloorCleared();
      }
    }

    // Boundary check — teleport players back if too far (every 20 ticks)
    if (this.active.floorTimer % 20 === 0) {
      this.checkBoundary();
    }

    // Update HUD
    if (this.active.floorTimer % 40 === 0) {
      const alive = this.active.mobs.size;
      for (const pid of this.active.playerIds) {
        try {
          const p = world.getEntity(pid);
          if (p) p.runCommandAsync(`title @s actionbar §dRaid Floor ${this.active.floor}/10 §7| §cEnemies: ${alive}`);
        } catch (e) {}
      }
    }
  }

  onFloorCleared() {
    if (this.active.floor >= 9) {
      // Floor 10 = boss fight
      this.showBossPrompt();
      return;
    }

    // Start vote: continue or evacuate
    this.startVote();
  }

  // === VOTING ===
  startVote() {
    this.active.voteOpen = true;
    this.active.voteTimer = 600; // 30 seconds
    this.active.voteContinue = 0;
    this.active.voteEvacuate = 0;

    for (const pid of this.active.playerIds) {
      try {
        const p = world.getEntity(pid);
        if (!p) continue;

        const form = new ActionFormData()
          .title(`Floor ${this.active.floor} Cleared!`)
          .body(`§7Choose to continue deeper or evacuate with your rewards.`)
          .button("§2Continue ▼")
          .button("§cEvacuate ▲");

        form.show(p).then(response => {
          if (!this.active || !this.active.voteOpen) return;
          if (response.selection === 0) this.active.voteContinue++;
          else this.active.voteEvacuate++;

          // If all voted, process immediately
          const totalVotes = this.active.voteContinue + this.active.voteEvacuate;
          if (totalVotes >= this.active.playerIds.size) this.processVotes();
        });
      } catch (e) {}
    }
  }

  processVotes() {
    if (!this.active || !this.active.voteOpen) return;
    this.active.voteOpen = false;

    if (this.active.voteContinue >= this.active.voteEvacuate) {
      // Continue — advance floor
      this.active.floor++;
      this.announceToAll(`§dFloor ${this.active.floor} — Fight!`);

      const center = this.getRaidCenter();
      this.spawnFloorMobs(this.active.floor, center);
    } else {
      // Evacuate — win with reduced rewards
      this.onRaidWin(false);
    }
  }

  // === BOSS FIGHT ===
  showBossPrompt() {
    const boss = this.active.bossData;
    const prompt = BOSS_PROMPTS[boss.id] || "Something terrible awaits...";

    for (const pid of this.active.playerIds) {
      try {
        const p = world.getEntity(pid);
        if (!p) continue;

        const form = new ActionFormData()
          .title(`${boss.color}${boss.name}`)
          .body(`\n${prompt}\n\n§cThis is the final floor. There is no retreat.`)
          .button(`§4Enter the ${boss.name}'s Lair`)
          .button("§7Turn Back");

        form.show(p).then(response => {
          if (response.selection === 0) {
            this.active.floor = 10;
            this.spawnBoss();
          } else {
            this.onRaidWin(false); // Evacuate
          }
        });
      } catch (e) {}
    }
  }

  spawnBoss() {
    const boss = this.active.bossData;
    const center = this.getRaidCenter();
    const dim = world.getDimension("overworld");

    try {
      const bossEntity = dim.spawnEntity(boss.mobType, center);
      bossEntity.addTag("ec.rd_boss");
      bossEntity.nameTag = `${boss.color}§l${boss.name}`;

      // Scale boss HP
      try {
        const health = bossEntity.getComponent("minecraft:health");
        if (health) {
          const s = StorageManager.forPlayer(this.getFirstPlayer());
          const dr = s?.getNumber("dream_rate", 10) || 10;
          const scaling = DR_SCALING.findLast(s => dr >= s.minDR) || DR_SCALING[0];
          const scaledHP = Math.floor(boss.hp * scaling.hpMult);
          health.setCurrentValue(scaledHP);
          this.active.bossMaxHP = scaledHP;
        }
      } catch (err) {}

      this.active.bossEntity = bossEntity;
      this.active.bossPhase = 1;

      this.announceToAll(`\n${boss.color}§l✦ ${boss.name} ✦\n§r§7Phase 1 — The battle begins!\n`);

      for (const pid of this.active.playerIds) {
        try { world.getEntity(pid)?.playSound("mob.wither.spawn"); } catch (e) {}
      }
    } catch (e) {
      this.announceToAll("§cFailed to spawn boss. Raid ending.");
      this.cleanupRaid();
    }
  }

  tickBoss() {
    if (!this.active?.bossEntity) return;

    try {
      const boss = this.active.bossEntity;
      const health = boss.getComponent("minecraft:health");
      if (!health || health.currentValue <= 0) {
        this.onBossDefeated();
        return;
      }

      // Phase transitions at 66% and 33% HP
      const hpPct = health.currentValue / this.active.bossMaxHP;
      const currentPhase = this.active.bossPhase;

      if (hpPct <= 0.33 && currentPhase < 3) {
        this.active.bossPhase = 3;
        this.onBossPhaseChange(3);
      } else if (hpPct <= 0.66 && currentPhase < 2) {
        this.active.bossPhase = 2;
        this.onBossPhaseChange(2);
      }

      // Boss abilities every 5 seconds
      if (this.active.floorTimer % 100 === 0) {
        this.bossAbility();
      }

      this.active.floorTimer++;

      // Update boss HP bar
      if (this.active.floorTimer % 20 === 0) {
        const barPct = Math.floor(hpPct * 20);
        const bar = "§c" + "█".repeat(barPct) + "§8" + "░".repeat(20 - barPct);
        for (const pid of this.active.playerIds) {
          try {
            const p = world.getEntity(pid);
            if (p) p.runCommandAsync(`title @s actionbar ${this.active.bossData.color}${this.active.bossData.name} ${bar} §f${Math.floor(hpPct * 100)}%`);
          } catch (e) {}
        }
      }
    } catch (e) {
      // Boss entity lost
      this.onBossDefeated();
    }
  }

  onBossPhaseChange(phase) {
    const boss = this.active.bossData;
    this.announceToAll(`\n${boss.color}§l✦ Phase ${phase} ✦\n§r§7${boss.name} grows more powerful!\n`);

    // Phase-specific effects
    if (phase === 2) {
      // Spawn adds
      const center = this.getRaidCenter();
      const dim = world.getDimension("overworld");
      for (let i = 0; i < 3; i++) {
        try {
          const add = dim.spawnEntity("minecraft:skeleton", {
            x: center.x + (Math.random() - 0.5) * 8,
            y: center.y,
            z: center.z + (Math.random() - 0.5) * 8,
          });
          add.addTag("ec.rd_mob");
          add.nameTag = "§7§lMinion";
          this.active.mobs.add(add.id);
        } catch (e) {}
      }
    }

    if (phase === 3) {
      // Enrage — boss gets strength + speed
      try {
        this.active.bossEntity.addEffect("strength", 99999, { amplifier: 1, showParticles: true });
        this.active.bossEntity.addEffect("speed", 99999, { amplifier: 1, showParticles: true });
      } catch (e) {}
      this.announceToAll("§c§lThe boss enters a frenzy!");
    }
  }

  bossAbility() {
    const phase = this.active.bossPhase;
    const dim = world.getDimension("overworld");
    const bossLoc = this.active.bossEntity?.location;
    if (!bossLoc) return;

    // AoE damage based on phase
    const radius = 4 + phase * 2;
    const damage = 3 + phase * 2;

    try {
      const players = dim.getPlayers({ location: bossLoc, maxDistance: radius });
      for (const p of players) {
        if (this.active.playerIds.has(p.id)) {
          p.applyDamage(damage, { cause: "entityAttack" });
        }
      }
      dim.spawnParticle("minecraft:huge_explosion_emitter", bossLoc);
    } catch (e) {}
  }

  // === WIN / LOSS ===
  onBossDefeated() {
    this.onRaidWin(true);
  }

  onRaidWin(fullClear) {
    const boss = this.active.bossData;
    const floor = this.active.floor;

    for (const [pid, savedPos] of this.active.players) {
      try {
        const p = world.getEntity(pid);
        if (!p) continue;

        // Teleport back to saved position
        const targetDim = world.getDimension(savedPos.dimension || "overworld");
        p.teleport({ x: savedPos.x, y: savedPos.y, z: savedPos.z }, { dimension: targetDim });

        p.removeTag("ec.rd_participant");

        if (fullClear) {
          // Roll loot: 5% chance for spirit artifact
          const artifactRoll = Math.random();
          if (artifactRoll < 0.05) {
            this.spiritWeapons.grantWeapon(p, boss.classArtifact);
            this.announceToAll(`§d§l✦ ${p.name} obtained ${boss.color}a Spirit Artifact§d§l! ✦`);
          }

          // Always drop 2 artifacts + DR consumable
          const s = StorageManager.forPlayer(p);
          const dr = s.getNumber("dream_rate", 0);
          s.setNumber("dream_rate", dr + 1);
          p.sendMessage(`§a+1 Dream Rate! §7(Now: ${dr + 1})`);

          // Track boss kill for metamorphosis
          const bossKills = s.getNumber("sp_bosses_slain_mask", 0);
          s.setNumber("sp_bosses_slain_mask", bossKills | (1 << boss.id));
          const total = this.countBits(bossKills | (1 << boss.id));
          s.setNumber("sp_bosses_slain", total);

          p.sendMessage(`\n§d§l✦ ✦ ✦ RAID COMPLETE ✦ ✦ ✦\n§r§7${boss.color}${boss.name} §7defeated!\n§7Floor: ${floor}/10\n`);
          p.playSound("ui.toast.challenge_complete");

          // Affinity XP
          this.eventBridge.emit("raid_complete", { player: p, bossId: boss.id });
        } else {
          p.sendMessage(`\n§7Raid evacuated at floor ${floor}.\n`);
        }
      } catch (e) {}
    }

    this.cleanupRaid();
  }

  onAllPlayersDead() {
    for (const [pid, savedPos] of this.active.players) {
      try {
        const p = world.getEntity(pid);
        if (!p) continue;

        // Teleport to bed/spawn
        try { p.runCommandAsync("spreadplayers ~ ~ 0 5 @s"); } catch (e) {}
        p.removeTag("ec.rd_participant");

        // Lose all XP levels
        try { p.runCommandAsync("xp -10000L @s"); } catch (e) {}

        p.sendMessage(`\n§c§l✦ RAID FAILED ✦\n§r§7You have been sent home.\n§cAll experience levels lost.\n`);
      } catch (e) {}
    }

    this.cleanupRaid();
  }

  onEntityKilled(entity) {
    if (!this.active) return;
    if (entity.id === this.active.bossEntity?.id) {
      this.onBossDefeated();
    } else {
      this.active.mobs.delete(entity.id);
    }
  }

  // === CLEANUP ===
  cleanupRaid() {
    if (!this.active) return;

    // Kill all raid mobs
    try {
      const dim = world.getDimension("overworld");
      const entities = dim.getEntities({ tags: ["ec.rd_mob"] });
      for (const e of entities) { try { e.kill(); } catch (err) {} }
      const bosses = dim.getEntities({ tags: ["ec.rd_boss"] });
      for (const e of bosses) { try { e.kill(); } catch (err) {} }
      const spiritWolves = dim.getEntities({ tags: ["ec.sp_spirit_wolf"] });
      for (const e of spiritWolves) { try { e.kill(); } catch (err) {} }
    } catch (e) {}

    this.active = null;
  }

  // === HELPERS ===
  announceToAll(message) {
    if (!this.active) return;
    for (const pid of this.active.playerIds) {
      try { world.getEntity(pid)?.sendMessage(message); } catch (e) {}
    }
  }

  getFirstPlayer() {
    if (!this.active) return null;
    for (const pid of this.active.playerIds) {
      try { return world.getEntity(pid); } catch (e) {}
    }
    return null;
  }

  getRaidCenter() {
    const boss = this.active?.bossData;
    if (!boss) return { x: 100000, y: 400, z: 0 };
    return { x: 100000 + boss.id * 100, y: 400, z: 0 };
  }

  checkBoundary() {
    const center = this.getRaidCenter();
    for (const pid of this.active.playerIds) {
      try {
        const p = world.getEntity(pid);
        if (!p) continue;
        const dx = p.location.x - center.x;
        const dz = p.location.z - center.z;
        if (Math.abs(dx) > 64 || Math.abs(dz) > 64) {
          p.teleport(center);
          p.addEffect("slowness", 60, { amplifier: 2, showParticles: false });
          p.sendMessage("§cStay within the raid arena!");
        }
      } catch (e) {}
    }
  }

  countBits(n) {
    let count = 0;
    while (n) { count += n & 1; n >>= 1; }
    return count;
  }

  // === MENU ENTRY ===
  openMenu(player) {
    if (this.active) {
      player.sendMessage("§cA raid is already in progress.");
      return;
    }

    const s = StorageManager.forPlayer(player);
    const dr = s.getNumber("dream_rate", 0);

    const form = new ActionFormData()
      .title("Spirit Raids")
      .body([
        "§7Select a structure to raid.",
        `§7Your Dream Rate: §f${dr}${dr < 10 ? " §c(Need 10+)" : " §a✔"}`,
        "",
        "§7Each structure has a unique Raid Boss.",
        "§7Defeat the boss for a 5% Spirit Artifact drop.",
      ].join("\n"));

    for (const boss of RAID_BOSSES) {
      const killed = (s.getNumber("sp_bosses_slain_mask", 0) & (1 << boss.id)) !== 0;
      const icon = killed ? "§a✔ " : "";
      form.button(`${icon}${boss.color}${boss.name}\n§7${boss.structure.replace(/_/g, " ")}`);
    }

    form.show(player).then(response => {
      if (response.canceled || response.selection === undefined) return;
      const boss = RAID_BOSSES[response.selection];
      if (boss) this.tryEnterRaid(player, boss.structure);
    });
  }
}
