/**
 * Friends System — Friend relationships, hearts, gifts, marriage, proximity buffs.
 * Replaces Java friends/ folder (81 files across buff, gift, heart, invite, marriage, title).
 *
 * Features: invite/accept/remove, daily heart proximity tracking, gift exchanges,
 * gift streaks (mutual exchange bonuses), best friend teleport (2-day cooldown),
 * marriage (best friend bond), family titles, nearby friend/spouse buffs.
 */
import { world, system } from "@minecraft/server";
import { StorageManager } from "../utils/storage.js";
import { ActionFormData } from "@minecraft/server-ui";

const MAX_FRIENDS = 50;
const HEART_PROXIMITY_RANGE = 48;
const HEART_PROXIMITY_TIME = 60;
const BUFF_RANGE = 48;
const BEST_FRIEND_HEARTS = 90;
const GREAT_FRIEND_HEARTS = 30;
const GOOD_FRIEND_HEARTS = 7;
const BF_TELEPORT_COOLDOWN_DAYS = 2;

// Heart level thresholds
const HEART_LEVELS = [
  { hearts: 0,  name: "Acquaintance", color: "§7" },
  { hearts: 7,  name: "Good Friend",  color: "§a" },
  { hearts: 30, name: "Great Friend", color: "§b" },
  { hearts: 60, name: "Ultra Friend", color: "§d" },
  { hearts: 90, name: "Best Friend",  color: "§6" },
];

// Family title options
const FAMILY_TITLES = [
  "Friend", "Brother", "Sister", "Mother", "Father",
  "Grandmother", "Grandfather", "Cousin", "Uncle", "Aunt", "Spouse",
];

// Title evolution (after 30+ days)
const TITLE_EVOLUTION = {
  "Mother": "Matriarch", "Father": "Patriarch",
  "Brother": "Blood Brother", "Sister": "Blood Sister",
  "Grandmother": "Elder Matriarch", "Grandfather": "Elder Patriarch",
  "Spouse": "Soulmate", "Friend": "Lifelong Friend",
};

const TITLE_EVOLUTION_DAYS = 30;
const GIFT_STREAK_END_THRESHOLD = 3;
const TITLE_NOTIFY_DELAY = 1200;

// Gift streak milestone bonuses (streak count → bonus hearts)
const GIFT_STREAK_MILESTONES = {
  3: { hearts: 1, msg: "§d♥ 3-day gift streak! +1 bonus heart!" },
  7: { hearts: 2, msg: "§d♥♥ 7-day gift streak! +2 bonus hearts!" },
  14: { hearts: 3, msg: "§6♥♥♥ 14-day streak! +3 bonus hearts!" },
  30: { hearts: 5, msg: "§5§l♥♥♥♥♥ 30-day streak! +5 bonus hearts! §r§7Incredible dedication!" },
};

// Gift tiers (roll 1-100)
const GIFT_TIERS = [
  { min: 1,  max: 40, tier: "Common",    cmd: "give @s forevercraft:common_companion_crate 1" },
  { min: 41, max: 65, tier: "Uncommon",  cmd: "give @s forevercraft:uncommon_companion_crate 1" },
  { min: 66, max: 83, tier: "Rare",      cmd: "give @s forevercraft:rare_companion_crate 1" },
  { min: 84, max: 93, tier: "Ornate",    cmd: "give @s forevercraft:ornate_companion_crate 1" },
  { min: 94, max: 98, tier: "Exquisite", cmd: "give @s forevercraft:exquisite_companion_crate 1" },
  { min: 99, max: 100, tier: "Mythical", cmd: "give @s forevercraft:mythical_companion_crate 1" },
];

export class FriendSystem {
  constructor(eventBridge, coinSystem) {
    this.eventBridge = eventBridge;
    this.coinSystem = coinSystem;

    eventBridge.on("friend_invite", (player, targetName) => this.sendInvite(player, targetName));
    eventBridge.on("friend_accept", (player, fromName) => this.acceptInvite(player, fromName));
  }

  // ─── FRIEND DATA ACCESS ────────────────────────────────────

  getFriendList(player) {
    const s = StorageManager.forPlayer(player);
    try {
      const data = s.get("friends_list");
      return data ? JSON.parse(data) : [];
    } catch { return []; }
  }

  setFriendList(player, list) {
    StorageManager.forPlayer(player).set("friends_list", JSON.stringify(list));
  }

  findFriend(player, targetName) {
    return this.getFriendList(player).find(f => f.name === targetName);
  }

  getHeartLevel(hearts) {
    for (let i = HEART_LEVELS.length - 1; i >= 0; i--) {
      if (hearts >= HEART_LEVELS[i].hearts) return HEART_LEVELS[i];
    }
    return HEART_LEVELS[0];
  }

  // ─── INVITE SYSTEM ─────────────────────────────────────────

  sendInvite(player, targetName) {
    if (this.getFriendList(player).length >= MAX_FRIENDS) {
      player.sendMessage("§c§l✗ §r§7Friend list full (max 50).");
      return;
    }
    if (this.findFriend(player, targetName)) {
      player.sendMessage("§c§l✗ §r§7Already friends with that player.");
      return;
    }
    const target = world.getAllPlayers().find(p => p.name === targetName);
    if (!target) { player.sendMessage("§c§l✗ §r§7Player not online."); return; }
    if (target.name === player.name) { player.sendMessage("§c§l✗ §r§7Can't friend yourself!"); return; }

    const ts = StorageManager.forPlayer(target);
    ts.set("fr_pending_from", player.name);

    target.sendMessage(`§d§l♥ §r§d${player.name} §7wants to be friends!`);
    target.sendMessage("§7Use the Friends menu to accept.");
    player.sendMessage(`§a§l✓ §r§7Friend request sent to §f${targetName}§7.`);
  }

  acceptInvite(player, fromName) {
    const s = StorageManager.forPlayer(player);
    const pending = s.get("fr_pending_from");
    if (!pending || (fromName && pending !== fromName)) {
      player.sendMessage("§c§l✗ §r§7No pending friend request.");
      return;
    }

    const from = world.getAllPlayers().find(p => p.name === pending);
    s.set("fr_pending_from", "");

    const newEntry = {
      name: "", hearts: 0, title: "Friend", dailyHeart: false,
      giftsSent: 0, giftsReceived: 0, titleSetDay: (globalThis._fc_daylight?.getDay?.() ?? 0),
      giftStreak: 0, lastGiftDay: 0, lastGiftReceivedDay: 0,
    };

    const myList = this.getFriendList(player);
    myList.push({ ...newEntry, name: pending });
    this.setFriendList(player, myList);

    if (from) {
      const theirList = this.getFriendList(from);
      theirList.push({ ...newEntry, name: player.name });
      this.setFriendList(from, theirList);
      from.sendMessage(`§d§l♥ §r§d${player.name} §7accepted your friend request!`);
    }

    player.sendMessage(`§d§l♥ §r§7You are now friends with §f${pending}§7!`);
    player.playSound("random.levelup");
    this.eventBridge.emit("friend_made", player);
  }

  removeFriend(player, targetName) {
    let myList = this.getFriendList(player);
    myList = myList.filter(f => f.name !== targetName);
    this.setFriendList(player, myList);

    const target = world.getAllPlayers().find(p => p.name === targetName);
    if (target) {
      let theirList = this.getFriendList(target);
      theirList = theirList.filter(f => f.name !== player.name);
      this.setFriendList(target, theirList);
      target.sendMessage(`§7${player.name} removed you from their friends.`);
    }
    player.sendMessage(`§7Removed §f${targetName} §7from friends.`);
  }

  // ─── HEART SYSTEM (Proximity) ──────────────────────────────

  tickHearts(player) {
    const friends = this.getFriendList(player);
    if (friends.length === 0) return;

    const s = StorageManager.forPlayer(player);
    const loc = player.location;
    let anyNearby = false;
    const allPlayers = world.getAllPlayers();

    for (const f of friends) {
      const friendPlayer = allPlayers.find(p => p.name === f.name);
      if (!friendPlayer) continue;
      const fl = friendPlayer.location;
      const dist = Math.sqrt((loc.x - fl.x) ** 2 + (loc.y - fl.y) ** 2 + (loc.z - fl.z) ** 2);
      if (dist <= HEART_PROXIMITY_RANGE) { anyNearby = true; break; }
    }

    if (anyNearby) {
      let timer = s.getNumber("fr_prox_timer", 0) + 1;
      s.set("fr_prox_timer", timer);
      if (timer >= HEART_PROXIMITY_TIME) {
        s.set("fr_prox_timer", 0);
        for (const f of friends) {
          if (f.dailyHeart) continue;
          const fp = allPlayers.find(p => p.name === f.name);
          if (!fp) continue;
          const fl = fp.location;
          const dist = Math.sqrt((loc.x - fl.x) ** 2 + (loc.y - fl.y) ** 2 + (loc.z - fl.z) ** 2);
          if (dist <= HEART_PROXIMITY_RANGE) {
            this.grantHeart(player, f.name);
            break;
          }
        }
      }
    } else {
      s.set("fr_prox_timer", 0);
    }
  }

  grantHeart(player, friendName) {
    const myList = this.getFriendList(player);
    const myF = myList.find(f => f.name === friendName);
    if (myF && !myF.dailyHeart) {
      myF.hearts++;
      myF.dailyHeart = true;
      this.setFriendList(player, myList);
      const lvl = this.getHeartLevel(myF.hearts);
      player.sendMessage(`§d§l♥ §r§7+1 heart with §f${friendName} §7(${lvl.color}${lvl.name}§7, ${myF.hearts} hearts)`);
    }

    const target = world.getAllPlayers().find(p => p.name === friendName);
    if (target) {
      const theirList = this.getFriendList(target);
      const theirF = theirList.find(f => f.name === player.name);
      if (theirF && !theirF.dailyHeart) {
        theirF.hearts++;
        theirF.dailyHeart = true;
        this.setFriendList(target, theirList);
        target.sendMessage(`§d§l♥ §r§7+1 heart with §f${player.name}§7!`);
      }
    }
  }

  /** Grant bonus hearts directly (for streaks) */
  grantBonusHearts(player, friendName, amount) {
    const myList = this.getFriendList(player);
    const myF = myList.find(f => f.name === friendName);
    if (myF) {
      myF.hearts += amount;
      this.setFriendList(player, myList);
    }
    const target = world.getAllPlayers().find(p => p.name === friendName);
    if (target) {
      const theirList = this.getFriendList(target);
      const theirF = theirList.find(f => f.name === player.name);
      if (theirF) {
        theirF.hearts += amount;
        this.setFriendList(target, theirList);
      }
    }
  }

  // ─── DAILY RESET ────────────────────────────────────────────

  resetDailyHearts() {
    for (const p of world.getAllPlayers()) {
      const list = this.getFriendList(p);
      let changed = false;
      for (const f of list) {
        if (f.dailyHeart) { f.dailyHeart = false; changed = true; }
      }
      if (changed) this.setFriendList(p, list);
    }
  }

  // ─── GIFT SYSTEM (with Streaks) ────────────────────────────

  sendGift(player, friendName) {
    // 2-day cooldown (144000 ticks = 2 in-game days at 72000 ticks/day)
    const s = StorageManager.forPlayer(player);
    const lastGift = s.getNumber("gift_cd", 0);
    const now = system.currentTick;
    if (lastGift > 0 && (now - lastGift) < 144000) {
      const remaining = Math.ceil((144000 - (now - lastGift)) / 72000);
      player.sendMessage(`§c§l✗ §r§7Gift cooldown! ~${remaining} day(s) remaining.`);
      return;
    }

    if (!this.coinSystem.removeCoins(player, 1)) {
      player.sendMessage("§c§l✗ §r§7Need 1 Forever Coin to send a gift.");
      return;
    }

    // Set cooldown timestamp
    s.set("gift_cd", now);

    const roll = Math.floor(Math.random() * 100) + 1;
    let giftTier = GIFT_TIERS[0];
    for (const t of GIFT_TIERS) {
      if (roll >= t.min && roll <= t.max) { giftTier = t; break; }
    }

    const target = world.getAllPlayers().find(p => p.name === friendName);
    if (target) {
      try { target.runCommandAsync(giftTier.cmd); } catch {}
      target.sendMessage(`§d§l♥ §r§d${player.name} §7sent you a §e${giftTier.tier} §7gift!`);

      // Track gift received + streak on their side
      const theirList = this.getFriendList(target);
      const theirF = theirList.find(f => f.name === player.name);
      if (theirF) {
        theirF.giftsReceived = (theirF.giftsReceived || 0) + 1;
        theirF.lastGiftReceivedDay = (globalThis._fc_daylight?.getDay?.() ?? 0);
        this.setFriendList(target, theirList);
      }
    }

    // Track gift sent + streak on sender side
    const myList = this.getFriendList(player);
    const myF = myList.find(f => f.name === friendName);
    if (myF) {
      myF.giftsSent = (myF.giftsSent || 0) + 1;
      const today = (globalThis._fc_daylight?.getDay?.() ?? 0);
      myF.lastGiftDay = today;

      // Check mutual gift streak: both sent a gift today or yesterday
      const theirEntry = target ? this.findFriend(target, player.name) : null;
      const theirLastGift = theirEntry?.lastGiftDay || 0;
      const isMutual = theirLastGift >= today - 1; // They gifted today or yesterday

      if (isMutual) {
        // Increment streak
        myF.giftStreak = (myF.giftStreak || 0) + 1;
        const streak = myF.giftStreak;

        // Check milestone
        const milestone = GIFT_STREAK_MILESTONES[streak];
        if (milestone) {
          this.grantBonusHearts(player, friendName, milestone.hearts);
          player.sendMessage(milestone.msg);
          if (target) target.sendMessage(milestone.msg);
          try { player.playSound("random.levelup", { volume: 0.5, pitch: 1.5 }); } catch {}
        }
      } else {
        // Reset streak if no mutual exchange within 2 days
        if (today - (myF.lastGiftDay || 0) > 2) {
          myF.giftStreak = 1;
        }
      }

      this.setFriendList(player, myList);
    }

    // Grant heart to sender
    this.grantHeart(player, friendName);

    player.sendMessage(`§d§l♥ §r§7Sent a §e${giftTier.tier} §7gift to §f${friendName}§7!`);
    if (myF?.giftStreak > 1) {
      player.sendMessage(`§7Gift streak: §e${myF.giftStreak} days`);
    }
    player.playSound("random.orb", { volume: 0.5, pitch: 1.2 });
  }

  getUnreturnedGifts(player, friendName) {
    const f = this.findFriend(player, friendName);
    if (!f) return 0;
    return Math.max(0, (f.giftsSent || 0) - (f.giftsReceived || 0));
  }

  // ─── BEST FRIEND TELEPORT ──────────────────────────────────

  bestFriendTeleport(player, friendName) {
    const friend = this.findFriend(player, friendName);
    if (!friend || friend.hearts < BEST_FRIEND_HEARTS) {
      player.sendMessage("§c§l✗ §r§7Must be Best Friends (90+ hearts) to teleport.");
      return;
    }

    const target = world.getAllPlayers().find(p => p.name === friendName);
    if (!target) {
      player.sendMessage("§c§l✗ §r§7Friend is not online.");
      return;
    }

    // Check cooldown (2-day cooldown)
    const s = StorageManager.forPlayer(player);
    const lastTP = s.getNumber(`bf_tp_${friendName}`, 0);
    const today = (globalThis._fc_daylight?.getDay?.() ?? 0);

    if (lastTP > 0 && today - lastTP < BF_TELEPORT_COOLDOWN_DAYS) {
      const remaining = BF_TELEPORT_COOLDOWN_DAYS - (today - lastTP);
      player.sendMessage(`§c§l✗ §r§7Teleport on cooldown — §e${remaining} day${remaining > 1 ? "s" : ""} §7remaining.`);
      return;
    }

    // Teleport
    const loc = target.location;
    try {
      player.teleport({ x: loc.x, y: loc.y, z: loc.z });
      s.set(`bf_tp_${friendName}`, today);

      player.sendMessage(`§d§l♥ §r§7Teleported to §f${friendName}§7!`);
      target.sendMessage(`§d§l♥ §r§f${player.name} §7teleported to you!`);

      try {
        player.playSound("mob.endermen.portal", { volume: 0.5 });
        target.playSound("mob.endermen.portal", { volume: 0.5 });
      } catch {}
    } catch {
      player.sendMessage("§c§l✗ §r§7Teleport failed.");
    }
  }

  // ─── MARRIAGE ──────────────────────────────────────────────

  proposeMarriage(player, friendName) {
    const friend = this.findFriend(player, friendName);
    if (!friend || friend.hearts < BEST_FRIEND_HEARTS) {
      player.sendMessage("§c§l✗ §r§7Must be Best Friends (90+ hearts) to propose.");
      return;
    }

    const s = StorageManager.forPlayer(player);
    if (s.get("married_to")) {
      player.sendMessage("§c§l✗ §r§7You are already married.");
      return;
    }

    const target = world.getAllPlayers().find(p => p.name === friendName);
    if (!target) { player.sendMessage("§c§l✗ §r§7Player not online."); return; }

    const ts = StorageManager.forPlayer(target);
    if (ts.get("married_to")) { player.sendMessage("§c§l✗ §r§7That player is already married."); return; }

    ts.set("marriage_proposal", player.name);
    target.sendMessage(`§d§l💍 ${player.name} §r§7proposes marriage!`);
    target.sendMessage("§7Open Friends menu to accept.");
    player.sendMessage(`§d§l💍 §r§7Proposal sent to §f${friendName}§7!`);
  }

  acceptMarriage(player) {
    const s = StorageManager.forPlayer(player);
    const proposer = s.get("marriage_proposal");
    if (!proposer) { player.sendMessage("§c§l✗ §r§7No pending proposal."); return; }

    s.set("marriage_proposal", "");
    s.set("married_to", proposer);

    const from = world.getAllPlayers().find(p => p.name === proposer);
    if (from) {
      StorageManager.forPlayer(from).set("married_to", player.name);
      from.sendMessage(`§d§l💍 §r§d${player.name} §7accepted your proposal! You are now married!`);
    }

    player.sendMessage(`§d§l💍 §r§7You married §f${proposer}§7!`);
    player.playSound("random.levelup");

    for (const p of world.getAllPlayers()) {
      if (p.name !== player.name && p.name !== proposer) {
        p.sendMessage(`§d§l💍 §r§f${player.name} §7and §f${proposer} §7got married!`);
      }
    }

    s.set("marriage_day", (globalThis._fc_daylight?.getDay?.() ?? 0));
    if (from) StorageManager.forPlayer(from).set("marriage_day", (globalThis._fc_daylight?.getDay?.() ?? 0));

    this.eventBridge.emit("marriage", player);
  }

  divorce(player) {
    const s = StorageManager.forPlayer(player);
    const spouse = s.get("married_to");
    if (!spouse) { player.sendMessage("§c§l✗ §r§7You are not married."); return; }

    s.set("married_to", "");
    s.set("marriage_day", 0);

    const spousePlayer = world.getAllPlayers().find(p => p.name === spouse);
    if (spousePlayer) {
      const ss = StorageManager.forPlayer(spousePlayer);
      ss.set("married_to", "");
      ss.set("marriage_day", 0);
      spousePlayer.sendMessage(`§c§l💔 §r§f${player.name} §7has ended the marriage.`);
    }

    player.sendMessage(`§c§l💔 §r§7You divorced §f${spouse}§7.`);

    for (const p of world.getAllPlayers()) {
      if (p.name !== player.name && p.name !== spouse) {
        p.sendMessage(`§c§l💔 §r§f${player.name} §7and §f${spouse} §7are no longer married.`);
      }
    }
  }

  // ─── TITLE EVOLUTION ──────────────────────────────────────

  checkTitleEvolution(player) {
    const list = this.getFriendList(player);
    const today = (globalThis._fc_daylight?.getDay?.() ?? 0);
    let changed = false;

    for (const f of list) {
      const titleSetDay = f.titleSetDay || 0;
      if (!titleSetDay || today - titleSetDay < TITLE_EVOLUTION_DAYS) continue;
      const evolved = TITLE_EVOLUTION[f.title];
      if (!evolved) continue;
      f.title = evolved;
      f.titleSetDay = today;
      changed = true;
      system.runTimeout(() => {
        try { player.sendMessage(`§d§l✦ §r§7Your title for §f${f.name} §7evolved to §e${evolved}§7!`); } catch {}
      }, TITLE_NOTIFY_DELAY);
    }
    if (changed) this.setFriendList(player, list);
  }

  // ─── BUFFS (Every 1s) ─────────────────────────────────────

  applyBuffs(player) {
    const friends = this.getFriendList(player);
    if (friends.length === 0) return;

    const loc = player.location;
    let bestFriendsNearby = 0;
    let spouseNearby = false;
    const married = StorageManager.forPlayer(player).get("married_to");

    for (const f of friends) {
      if (f.hearts < BEST_FRIEND_HEARTS) continue;
      const fp = world.getAllPlayers().find(p => p.name === f.name);
      if (!fp) continue;
      const fl = fp.location;
      const dist = Math.sqrt((loc.x - fl.x) ** 2 + (loc.y - fl.y) ** 2 + (loc.z - fl.z) ** 2);
      if (dist <= BUFF_RANGE) {
        bestFriendsNearby++;
        if (f.name === married) spouseNearby = true;
      }
    }

    if (bestFriendsNearby > 0) {
      const level = Math.min(bestFriendsNearby, 10) - 1;
      try { player.runCommandAsync(`effect @s absorption 6 ${Math.min(level, 4)} true`); } catch {}
    }

    if (spouseNearby) {
      try { player.runCommandAsync("effect @s absorption 6 0 true"); } catch {}
    }
  }

  // ─── GUI ──────────────────────────────────────────────────

  openFriendsMenu(player) {
    const friends = this.getFriendList(player);
    const s = StorageManager.forPlayer(player);
    const married = s.get("married_to") || "";
    const pending = s.get("fr_pending_from") || "";
    const proposal = s.get("marriage_proposal") || "";

    let body = `§7Friends: §f${friends.length}/${MAX_FRIENDS}\n`;
    if (married) body += `§d💍 Married to: §f${married}\n`;
    body += "\n";

    const form = new ActionFormData()
      .title("§d♥ Friends")
      .body(body);

    const actions = [];
    if (pending) { form.button(`§aAccept Request\n§7From: ${pending}`); actions.push("accept"); }
    if (proposal) { form.button(`§d💍 Accept Proposal\n§7From: ${proposal}`); actions.push("proposal"); }
    form.button("§eSend Request\n§7Invite a player"); actions.push("send");
    form.button("§bFriend List\n§7View all friends"); actions.push("list");
    form.button("§7Close"); actions.push("close");

    form.show(player).then(response => {
      if (response.canceled) return;
      const action = actions[response.selection];
      switch (action) {
        case "accept": this.acceptInvite(player); break;
        case "proposal": this.acceptMarriage(player); break;
        case "send": this.showSendRequest(player); break;
        case "list": this.showFriendList(player); break;
      }
    });
  }

  showSendRequest(player) {
    const others = world.getAllPlayers().filter(p =>
      p.name !== player.name && !this.findFriend(player, p.name)
    );
    if (others.length === 0) { player.sendMessage("§c§l✗ §r§7No available players."); return; }

    const form = new ActionFormData().title("§eSend Friend Request").body("§7Select a player:");
    for (const p of others) form.button(`§f${p.name}`);
    form.button("§7Cancel");

    form.show(player).then(response => {
      if (response.canceled || response.selection >= others.length) return;
      this.sendInvite(player, others[response.selection].name);
    });
  }

  showFriendList(player) {
    const friends = this.getFriendList(player);
    if (friends.length === 0) { player.sendMessage("§7No friends yet. Send some requests!"); return; }

    const form = new ActionFormData().title("§dFriend List").body("§7Select a friend for options:");
    const sorted = [...friends].sort((a, b) => b.hearts - a.hearts);
    for (const f of sorted) {
      const lvl = this.getHeartLevel(f.hearts);
      const online = world.getAllPlayers().some(p => p.name === f.name);
      const streak = f.giftStreak > 1 ? ` §e🔥${f.giftStreak}` : "";
      form.button(`${online ? "§a●" : "§8●"} §f${f.name}\n${lvl.color}${lvl.name} §7(${f.hearts}♥)${streak}`);
    }
    form.button("§7← Back");

    form.show(player).then(response => {
      if (response.canceled || response.selection >= sorted.length) { this.openFriendsMenu(player); return; }
      this.showFriendActions(player, sorted[response.selection].name);
    });
  }

  showFriendActions(player, friendName) {
    const friend = this.findFriend(player, friendName);
    if (!friend) return;
    const lvl = this.getHeartLevel(friend.hearts);
    const married = StorageManager.forPlayer(player).get("married_to");
    const unreturned = this.getUnreturnedGifts(player, friendName);

    let body = `${lvl.color}${lvl.name} §7— ${friend.hearts} hearts\n§7Title: §e${friend.title}\n`;
    body += `§7Gifts Sent: §f${friend.giftsSent || 0} §7| Received: §f${friend.giftsReceived || 0}`;
    if (friend.giftStreak > 1) body += `\n§eGift Streak: §f${friend.giftStreak} days 🔥`;
    if (unreturned >= GIFT_STREAK_END_THRESHOLD) body += `\n§c${unreturned} unreturned gifts!`;

    const form = new ActionFormData()
      .title(`§d${friendName}`)
      .body(body);

    const actions = [];
    form.button("§eSend Gift\n§71 Forever Coin"); actions.push("gift");
    form.button("§bSet Title\n§7Change family title"); actions.push("title");

    // Best friend teleport
    if (friend.hearts >= BEST_FRIEND_HEARTS) {
      const s = StorageManager.forPlayer(player);
      const lastTP = s.getNumber(`bf_tp_${friendName}`, 0);
      const today = (globalThis._fc_daylight?.getDay?.() ?? 0);
      const onCD = lastTP > 0 && today - lastTP < BF_TELEPORT_COOLDOWN_DAYS;
      const cdText = onCD ? `§c(${BF_TELEPORT_COOLDOWN_DAYS - (today - lastTP)}d CD)` : "§7Ready!";
      form.button(`§aTeleport to Friend\n${cdText}`);
      actions.push("teleport");
    }

    if (friend.hearts >= BEST_FRIEND_HEARTS && !married) {
      form.button("§d💍 Propose Marriage"); actions.push("propose");
    }
    if (married === friendName) {
      form.button("§c💔 Divorce"); actions.push("divorce");
    }
    if (unreturned >= GIFT_STREAK_END_THRESHOLD) {
      form.button("§4End Friendship\n§7Too many unreturned gifts"); actions.push("end");
    }
    form.button("§cRemove Friend"); actions.push("remove");
    form.button("§7← Back"); actions.push("back");

    form.show(player).then(response => {
      if (response.canceled) return;
      const action = actions[response.selection];
      switch (action) {
        case "gift": this.sendGift(player, friendName); break;
        case "title": this.showTitleMenu(player, friendName); break;
        case "teleport": this.bestFriendTeleport(player, friendName); break;
        case "propose": this.proposeMarriage(player, friendName); break;
        case "divorce": this.confirmDivorce(player); break;
        case "end":
        case "remove": this.removeFriend(player, friendName); break;
        case "back": this.showFriendList(player); break;
      }
    });
  }

  confirmDivorce(player) {
    const form = new ActionFormData()
      .title("§c💔 Divorce?")
      .body("§7Are you sure you want to end the marriage?\n§7This cannot be undone.")
      .button("§cYes, Divorce")
      .button("§aNo, Stay Married");
    form.show(player).then(response => {
      if (response.canceled || response.selection === 1) return;
      this.divorce(player);
    });
  }

  showTitleMenu(player, friendName) {
    const form = new ActionFormData().title("§bSet Title").body(`§7What do you call §f${friendName}§7?`);
    for (const title of FAMILY_TITLES) form.button(`§f${title}`);
    form.button("§7Cancel");

    form.show(player).then(response => {
      if (response.canceled || response.selection >= FAMILY_TITLES.length) return;
      const title = FAMILY_TITLES[response.selection];
      const list = this.getFriendList(player);
      const f = list.find(fr => fr.name === friendName);
      if (f) { f.title = title; f.titleSetDay = (globalThis._fc_daylight?.getDay?.() ?? 0); this.setFriendList(player, list); }
      player.sendMessage(`§d§l♥ §r§7Set §f${friendName} §7as your §e${title}§7.`);
    });
  }

  // ─── TICK ────────────────────────────────────────────────────

  tick(players) {
    for (const p of players) {
      this.tickHearts(p);
      this.applyBuffs(p);
    }
  }

  onDayChange() {
    this.resetDailyHearts();
    for (const p of world.getAllPlayers()) {
      this.checkTitleEvolution(p);
    }
  }
}
