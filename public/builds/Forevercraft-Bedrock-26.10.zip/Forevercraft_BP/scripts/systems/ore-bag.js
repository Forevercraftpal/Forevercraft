/**
 * Ore Bag System — Inventory-like storage for forge materials (forge_mat items).
 * Stores up to 100 items total across all material types.
 * ActionFormData menu showing contents by category/tier.
 * Deposit from mainhand, withdraw to inventory.
 * Uses StorageManager keys: orebag_{category}_t{tier}
 */
import { world, system, ItemStack } from "@minecraft/server";
import { StorageManager } from "../utils/storage.js";
import { ActionFormData } from "@minecraft/server-ui";

const MAX_CAPACITY = 100;

const CATEGORIES = ["weapon", "armor", "tool", "accessory"];
const CATEGORY_LABELS = {
  weapon: { label: "Weapon", color: "§c", icon: "⚔" },
  armor: { label: "Armor", color: "§9", icon: "🛡" },
  tool: { label: "Tool", color: "§a", icon: "⛏" },
  accessory: { label: "Accessory", color: "§6", icon: "✦" },
};

const TIER_COLORS = ["", "§7", "§f", "§b", "§a", "§d", "§5", "§e"];

// Material name lookup (mirrors ArtifactForge.MATERIALS in forging.js)
// Updated material names to match Artifact Forge Expansion (March 25 changelog)
const MATERIAL_NAMES = {
  weapon: [null, "Raw Blade Shard", "Honed Edge Steel", "Battleforged Alloy", "Abyssal Weapon Core", "Starfall Blade Ingot", "Epoch Weapon Heart", "Doomforge Core"],
  armor: [null, "Crude Plate Fragment", "Tempered Scale", "Warden Plate", "Dragonscale Mesh", "Celestial Armor Weave", "Timeless Armor Soul", "Worldshield Essence"],
  tool: [null, "Rough Tool Stock", "Refined Tool Rod", "Mastercraft Shaft", "Precision Mechanism", "Astral Tool Matrix", "Genesis Catalyst", "Primal Catalyst"],
  accessory: [null, "Uncut Charm Stone", "Polished Gem Core", "Resonant Aether Shard", "Void-Touched Crystal", "Dreamwoven Talisman", "Eternium Focus", "Infinity Loop Shard"],
};

export class OreBagSystem {
  constructor(eventBridge) {
    this.eventBridge = eventBridge;
  }

  /**
   * Get total items stored in the ore bag.
   */
  getTotal(player) {
    const s = StorageManager.forPlayer(player);
    let total = 0;
    for (const cat of CATEGORIES) {
      for (let tier = 1; tier <= 7; tier++) {
        total += s.getNumber(`orebag_${cat}_t${tier}`, 0);
      }
    }
    return total;
  }

  /**
   * Open the ore bag menu.
   */
  openMenu(player) {
    const s = StorageManager.forPlayer(player);
    const total = this.getTotal(player);

    let body = `§7Forge Material Storage\n§7Capacity: §f${total}/${MAX_CAPACITY}\n\n`;

    // Show contents by category
    for (const cat of CATEGORIES) {
      const catDef = CATEGORY_LABELS[cat];
      let catTotal = 0;
      let catItems = [];
      for (let tier = 1; tier <= 7; tier++) {
        const count = s.getNumber(`orebag_${cat}_t${tier}`, 0);
        if (count > 0) {
          catTotal += count;
          const name = MATERIAL_NAMES[cat][tier] || `T${tier}`;
          catItems.push(`  ${TIER_COLORS[tier]}T${tier} ${name}: §f${count}`);
        }
      }
      if (catTotal > 0) {
        body += `${catDef.color}${catDef.icon} ${catDef.label} §7(${catTotal})\n`;
        body += catItems.join("\n") + "\n\n";
      }
    }

    if (total === 0) {
      body += "§8No materials stored.\n";
    }

    const form = new ActionFormData()
      .title("§6⛏ Ore Bag")
      .body(body)
      .button("§aDeposit Material")
      .button("§bWithdraw Material")
      .button("§7Close");

    form.show(player).then(response => {
      if (response.canceled || response.selection === 2) return;
      if (response.selection === 0) {
        this.depositMenu(player);
      } else {
        this.withdrawCategoryMenu(player);
      }
    });
  }

  /**
   * Deposit forge materials from player's forge_mat storage into the ore bag.
   * Shows a category selection, then tier selection.
   */
  depositMenu(player) {
    const s = StorageManager.forPlayer(player);
    const total = this.getTotal(player);

    if (total >= MAX_CAPACITY) {
      player.sendMessage("§c§l[Ore Bag] §7Bag is full! (100/100)");
      return;
    }

    const form = new ActionFormData()
      .title("§aDeposit Material")
      .body("§7Select a category to deposit from your forge material storage.");

    for (const cat of CATEGORIES) {
      const catDef = CATEGORY_LABELS[cat];
      // Count player's forge_mat for this category
      let available = 0;
      for (let tier = 1; tier <= 7; tier++) {
        available += s.getNumber(`forge_mat_${cat}_t${tier}`, 0);
      }
      form.button(`${catDef.color}${catDef.icon} ${catDef.label}\n§7${available} available`);
    }
    form.button("§7← Back");

    form.show(player).then(response => {
      if (response.canceled || response.selection === 4) {
        this.openMenu(player);
        return;
      }
      this.depositTierMenu(player, CATEGORIES[response.selection]);
    });
  }

  /**
   * Show tier selection for depositing from a specific category.
   */
  depositTierMenu(player, category) {
    const s = StorageManager.forPlayer(player);
    const total = this.getTotal(player);
    const remaining = MAX_CAPACITY - total;
    const catDef = CATEGORY_LABELS[category];

    const form = new ActionFormData()
      .title(`§aDeposit ${catDef.label}`)
      .body(`§7Space remaining: §f${remaining}\n§7Select a tier to deposit.`);

    const availableTiers = [];
    for (let tier = 1; tier <= 7; tier++) {
      const forgeMat = s.getNumber(`forge_mat_${category}_t${tier}`, 0);
      if (forgeMat > 0) {
        const name = MATERIAL_NAMES[category][tier] || `T${tier}`;
        form.button(`${TIER_COLORS[tier]}T${tier} ${name}\n§7Available: §f${forgeMat}`);
        availableTiers.push(tier);
      }
    }

    if (availableTiers.length === 0) {
      player.sendMessage(`§7No ${catDef.label} materials to deposit.`);
      this.depositMenu(player);
      return;
    }

    form.button("§7← Back");

    form.show(player).then(response => {
      if (response.canceled || response.selection === availableTiers.length) {
        this.depositMenu(player);
        return;
      }

      const tier = availableTiers[response.selection];
      const forgeMat = s.getNumber(`forge_mat_${category}_t${tier}`, 0);
      const canDeposit = Math.min(forgeMat, MAX_CAPACITY - this.getTotal(player));

      if (canDeposit <= 0) {
        player.sendMessage("§c§l[Ore Bag] §7No space or no materials!");
        return;
      }

      // Transfer from forge_mat to orebag
      s.setNumber(`forge_mat_${category}_t${tier}`, forgeMat - canDeposit);
      const current = s.getNumber(`orebag_${category}_t${tier}`, 0);
      s.setNumber(`orebag_${category}_t${tier}`, current + canDeposit);

      const name = MATERIAL_NAMES[category][tier] || `T${tier}`;
      player.sendMessage(`§a§l[Ore Bag] §r§7Deposited §f${canDeposit}x §7${name} (${this.getTotal(player)}/${MAX_CAPACITY})`);
      try { player.playSound("random.orb", { volume: 0.5, pitch: 1.2 }); } catch {}
    });
  }

  /**
   * Withdraw category selection.
   */
  withdrawCategoryMenu(player) {
    const s = StorageManager.forPlayer(player);
    const total = this.getTotal(player);

    if (total === 0) {
      player.sendMessage("§7§l[Ore Bag] §7Bag is empty.");
      return;
    }

    const form = new ActionFormData()
      .title("§bWithdraw Material")
      .body("§7Select a category to withdraw.");

    const availableCats = [];
    for (const cat of CATEGORIES) {
      const catDef = CATEGORY_LABELS[cat];
      let catTotal = 0;
      for (let tier = 1; tier <= 7; tier++) {
        catTotal += s.getNumber(`orebag_${cat}_t${tier}`, 0);
      }
      if (catTotal > 0) {
        form.button(`${catDef.color}${catDef.icon} ${catDef.label}\n§7Stored: §f${catTotal}`);
        availableCats.push(cat);
      }
    }
    form.button("§7← Back");

    form.show(player).then(response => {
      if (response.canceled || response.selection === availableCats.length) {
        this.openMenu(player);
        return;
      }
      this.withdrawTierMenu(player, availableCats[response.selection]);
    });
  }

  /**
   * Show tier selection for withdrawing from a specific category.
   */
  withdrawTierMenu(player, category) {
    const s = StorageManager.forPlayer(player);
    const catDef = CATEGORY_LABELS[category];

    const form = new ActionFormData()
      .title(`§bWithdraw ${catDef.label}`)
      .body("§7Select a tier to withdraw.");

    const availableTiers = [];
    for (let tier = 1; tier <= 7; tier++) {
      const count = s.getNumber(`orebag_${category}_t${tier}`, 0);
      if (count > 0) {
        const name = MATERIAL_NAMES[category][tier] || `T${tier}`;
        form.button(`${TIER_COLORS[tier]}T${tier} ${name}\n§7Stored: §f${count}`);
        availableTiers.push(tier);
      }
    }
    form.button("§7← Back");

    form.show(player).then(response => {
      if (response.canceled || response.selection === availableTiers.length) {
        this.withdrawCategoryMenu(player);
        return;
      }

      const tier = availableTiers[response.selection];
      const count = s.getNumber(`orebag_${category}_t${tier}`, 0);

      if (count <= 0) {
        player.sendMessage("§c§l[Ore Bag] §7Nothing to withdraw!");
        return;
      }

      // Withdraw 1 item back to forge_mat storage
      s.setNumber(`orebag_${category}_t${tier}`, count - 1);
      const forgeMat = s.getNumber(`forge_mat_${category}_t${tier}`, 0);
      s.setNumber(`forge_mat_${category}_t${tier}`, forgeMat + 1);

      const name = MATERIAL_NAMES[category][tier] || `T${tier}`;
      player.sendMessage(`§b§l[Ore Bag] §r§7Withdrew §f1x §7${name} → forge storage (${this.getTotal(player)}/${MAX_CAPACITY})`);
      try { player.playSound("random.orb", { volume: 0.5, pitch: 0.8 }); } catch {}
    });
  }
}
