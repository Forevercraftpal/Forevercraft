/**
 * Patina System — Artifact evolution through time-worn stages.
 * Replaces Java patina/ folder (7 files).
 * Stages: Fresh → Worn → Seasoned → Storied → Legendary
 * Time thresholds: 2h, 8h, 24h, 72h cumulative wear time.
 */
import { world, system } from "@minecraft/server";
import { StorageManager } from "../utils/storage.js";

const PATINA_STAGES = [
  { stage: 0, name: "Fresh", hours: 0, color: "§f" },
  { stage: 1, name: "Worn", hours: 2, color: "§7" },
  { stage: 2, name: "Seasoned", hours: 8, color: "§e" },
  { stage: 3, name: "Storied", hours: 24, color: "§b" },
  { stage: 4, name: "Legendary", hours: 72, color: "§6" },
];

const EQUIPMENT_SLOTS = ["Head", "Chest", "Legs", "Feet"];

export class PatinaSystem {
  constructor() {
    this.secondCounter = 0;
  }

  /** Per-second tick: accumulate wear time on equipped artifacts */
  tick(players) {
    this.secondCounter++;
    if (this.secondCounter < 60) return; // Check every 60 seconds
    this.secondCounter = 0;

    for (const player of players) {
      this.processPlayer(player);
    }
  }

  processPlayer(player) {
    const equip = player.getComponent("minecraft:equippable");
    if (!equip) return;

    const s = StorageManager.forPlayer(player);

    for (let i = 0; i < EQUIPMENT_SLOTS.length; i++) {
      const slot = EQUIPMENT_SLOTS[i];
      const item = equip.getEquipment(slot);
      if (!item) continue;

      const tags = item.getTags?.() || [];
      if (!tags.some(t => t.includes("forevercraft:artifact"))) continue;

      // Track wear time per slot using dynamic property key
      const slotKey = `patina_${slot.toLowerCase()}`;
      const wearSeconds = s.getNumber(slotKey) + 60; // Add 60 seconds
      s.set(slotKey, wearSeconds);

      const wearHours = wearSeconds / 3600;

      // Check for stage upgrade
      let currentStage = 0;
      for (const stage of PATINA_STAGES) {
        if (wearHours >= stage.hours) currentStage = stage.stage;
      }

      const prevStage = s.getNumber(`patina_stage_${slot.toLowerCase()}`);
      if (currentStage > prevStage) {
        s.set(`patina_stage_${slot.toLowerCase()}`, currentStage);
        const stageData = PATINA_STAGES[currentStage];
        player.sendMessage(`${stageData.color}§l✦ Patina: §r${stageData.color}${stageData.name} §r§7— ${slot} artifact has aged!`);
        player.playSound("random.orb");
      }
    }
  }
}
