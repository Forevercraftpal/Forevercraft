/**
 * Campfire Stories System — Ambient narrative near campfires.
 * Replaces Java campfire_stories/ folder (21 files).
 * Context-aware stories told when players sit near campfires.
 */
import { world, system } from "@minecraft/server";
import { StorageManager } from "../utils/storage.js";

const STORIES = [
  { id: 1, text: "§7§o\"Long ago, before the first sunrise, the world was nothing but dream...\"" },
  { id: 2, text: "§7§o\"They say the artifacts carry memories of those who wielded them before.\"" },
  { id: 3, text: "§7§o\"The Dreaming Realm wasn't always a separate place. Once, it was everywhere.\"" },
  { id: 4, text: "§7§o\"A blacksmith once forged a blade so perfect, the gods wept with envy.\"" },
  { id: 5, text: "§7§o\"Have you noticed how the seasons change the land? It's the old magic, still working.\"" },
  { id: 6, text: "§7§o\"My grandmother told me about Night Terrors. She said they're attracted to dreamers.\"" },
  { id: 7, text: "§7§o\"The Guardian of the Forest watches from the canopy. Few have seen it and lived.\"" },
  { id: 8, text: "§7§o\"Some say the patina on an old artifact holds more power than the metal itself.\"" },
  { id: 9, text: "§7§o\"The moon controls more than the tides. Watch the creatures under a new moon.\"" },
  { id: 10, text: "§7§o\"Every artifact has a name, a history. Listen closely and you might hear its story.\"" },
  { id: 11, text: "§7§o\"The Expeditionists map paths between worlds. Their compasses point to impossible places.\"" },
  { id: 12, text: "§7§o\"Companions aren't just pets. They're echoes of ancient spirits bound by friendship.\"" },
  { id: 13, text: "§7§o\"The Black Market deals in things that shouldn't exist. Best not to ask where they get them.\"" },
  { id: 14, text: "§7§o\"I once met a wandering merchant who sold me a map to a treasure that doesn't exist... yet.\"" },
  { id: 15, text: "§7§o\"The world bosses are ancient guardians. They test the worthy.\"" },
  { id: 16, text: "§7§o\"When all four seasons align with the right moon phase, something extraordinary happens.\"" },
  { id: 17, text: "§7§o\"Dream Rate isn't just luck. It's the world recognizing your presence.\"" },
  { id: 18, text: "§7§o\"The runes are fragments of a language older than any civilization.\"" },
  { id: 19, text: "§7§o\"Some armor sets resonate together. Wear the full set and feel the power.\"" },
  { id: 20, text: "§7§o\"The bravest explorers venture to coordinates no map shows. What do they find there?\"" },
];

const COOLDOWN_TICKS = 6000; // 5 minutes between stories

export class CampfireStorySystem {
  constructor() {
    this.lastStoryIds = []; // Anti-repeat buffer (last 3)
    this.globalCooldown = 0;
  }

  /** Check proximity to campfires (called every 5 seconds) */
  tick(players) {
    if (this.globalCooldown > 0) {
      this.globalCooldown -= 100; // Decrease by 5 seconds worth
      return;
    }

    for (const player of players) {
      this.checkCampfireProximity(player);
    }
  }

  checkCampfireProximity(player) {
    // Check for campfire blocks nearby
    const loc = player.location;
    const dim = player.dimension;

    try {
      // Check a small area for campfires
      for (let dx = -3; dx <= 3; dx++) {
        for (let dy = -1; dy <= 1; dy++) {
          for (let dz = -3; dz <= 3; dz++) {
            const block = dim.getBlock({
              x: Math.floor(loc.x) + dx,
              y: Math.floor(loc.y) + dy,
              z: Math.floor(loc.z) + dz,
            });
            if (block?.typeId === "minecraft:campfire" || block?.typeId === "minecraft:soul_campfire") {
              // Player must be sneaking (sitting) or standing still
              if (player.isSneaking) {
                this.tellStory(player);
                return;
              }
            }
          }
        }
      }
    } catch {}
  }

  tellStory(player) {
    // Pick a random story not in recent history
    let available = STORIES.filter(s => !this.lastStoryIds.includes(s.id));
    if (available.length === 0) available = STORIES;

    const story = available[Math.floor(Math.random() * available.length)];

    // Update history
    this.lastStoryIds.push(story.id);
    if (this.lastStoryIds.length > 3) this.lastStoryIds.shift();

    // Tell the story
    player.sendMessage("§6§l🔥 Campfire Story");
    player.sendMessage(story.text);
    player.playSound("note.bass");

    // Set cooldown
    this.globalCooldown = COOLDOWN_TICKS;

    // Dream Rate bonus (small)
    const s = StorageManager.forPlayer(player);
    if (Math.random() < 0.1) { // 10% chance for +1 DR
      const dr = s.getNumber("dream_rate") + 1;
      s.set("dream_rate", dr);
      player.sendMessage("§d§l+1 Dream Rate §r§7from the story's magic");
    }
  }
}
