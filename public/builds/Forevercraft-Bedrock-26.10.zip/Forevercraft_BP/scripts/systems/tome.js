/**
 * Tome System — Tome of Experience (XP banking) + Tome of Lucid Visions (+1 DR).
 * Replaces Java tome/ folder.
 */
import { world, system } from "@minecraft/server";
import { StorageManager } from "../utils/storage.js";
import { ActionFormData } from "@minecraft/server-ui";

export class TomeSystem {
  constructor(eventBridge) {
    this.eventBridge = eventBridge;
    this.cooldowns = new Map(); // playerId → tick

    // Listen for tome item use
    world.afterEvents.itemUse.subscribe((event) => {
      const item = event.itemStack;
      if (!item) return;

      if (item.typeId === "forevercraft:tome_of_experience") {
        this.handleExperienceTome(event.source);
      }
      if (item.typeId === "forevercraft:tome_of_lucid_visions") {
        this.handleLucidVisionsTome(event.source);
      }
    });
  }

  /**
   * Handle Tome of Experience usage — open deposit/withdraw menu.
   */
  handleExperienceTome(player) {
    // Cooldown check (3 seconds)
    const now = system.currentTick;
    const lastUse = this.cooldowns.get(player.id) ?? 0;
    if (now - lastUse < 60) {
      player.sendMessage("§7Tome is recharging...");
      return;
    }

    const storage = StorageManager.forPlayer(player);
    const storedLevels = storage.getNumber("tome_lvl", 0);
    const storedPoints = storage.getNumber("tome_pts", 0);

    const form = new ActionFormData()
      .title("§6Tome of Experience")
      .body(
        `§7Stored: §e${storedLevels} levels §7+ §e${storedPoints} points\n\n` +
        `§7Current XP: §aLevel ${player.level}\n\n` +
        `§7Deposit all your XP into the tome,\n§7or withdraw stored XP back.`
      )
      .button("§aDeposit All XP")
      .button("§bWithdraw All XP")
      .button("§7Close");

    form.show(player).then((r) => {
      if (r.canceled || r.selection === 2) return;

      this.cooldowns.set(player.id, system.currentTick);

      if (r.selection === 0) {
        this.depositXP(player);
      } else if (r.selection === 1) {
        this.withdrawXP(player);
      }
    });
  }

  /**
   * Deposit all player XP into the tome.
   */
  depositXP(player) {
    const storage = StorageManager.forPlayer(player);
    const currentLevel = player.level;
    const currentXP = player.xpEarnedAtCurrentLevel;

    if (currentLevel === 0 && currentXP === 0) {
      player.sendMessage("§7You have no XP to deposit.");
      return;
    }

    // Add to stored
    const prevLevels = storage.getNumber("tome_lvl", 0);
    const prevPoints = storage.getNumber("tome_pts", 0);
    storage.set("tome_lvl", prevLevels + currentLevel);
    storage.set("tome_pts", prevPoints + currentXP);

    // Remove player XP
    try {
      player.resetLevel();
    } catch {}

    const totalLvl = prevLevels + currentLevel;
    const totalPts = prevPoints + currentXP;
    player.sendMessage(`§6§lXP Deposited! §7Stored: §e${totalLvl} levels + ${totalPts} points`);

    try {
      player.playSound("random.orb", { volume: 0.5, pitch: 0.8 });
    } catch {}
  }

  /**
   * Withdraw all stored XP back to the player.
   */
  withdrawXP(player) {
    const storage = StorageManager.forPlayer(player);
    const storedLevels = storage.getNumber("tome_lvl", 0);
    const storedPoints = storage.getNumber("tome_pts", 0);

    if (storedLevels === 0 && storedPoints === 0) {
      player.sendMessage("§7No XP stored in the tome.");
      return;
    }

    // Give XP via commands (most reliable)
    try {
      if (storedLevels > 0) {
        player.dimension.runCommandAsync(
          `xp ${storedLevels}L "${player.name}"`
        );
      }
      if (storedPoints > 0) {
        player.dimension.runCommandAsync(
          `xp ${storedPoints} "${player.name}"`
        );
      }
    } catch {}

    storage.set("tome_lvl", 0);
    storage.set("tome_pts", 0);

    player.sendMessage(`§6§lXP Withdrawn! §7Received: §e${storedLevels} levels + ${storedPoints} points`);

    try {
      player.playSound("random.orb", { volume: 0.5, pitch: 1.2 });
      player.playSound("block.beacon.power_select", { volume: 0.3, pitch: 1.0 });
    } catch {}
  }

  /**
   * Handle Tome of Lucid Visions — permanent +1 Dream Rate.
   */
  handleLucidVisionsTome(player) {
    const storage = StorageManager.forPlayer(player);
    const used = storage.getNumber("tome_count", 0);

    if (used >= 1) {
      player.sendMessage("§7You have already consumed a Tome of Lucid Visions.");
      return;
    }

    storage.set("tome_count", 1);
    storage.increment("dream_rate", 1);

    // Remove the item
    const equip = player.getComponent("minecraft:equippable");
    const mainhand = equip?.getEquipment("Mainhand");
    if (mainhand?.typeId === "forevercraft:tome_of_lucid_visions") {
      if (mainhand.amount > 1) {
        mainhand.amount--;
        equip.setEquipment("Mainhand", mainhand);
      } else {
        equip.setEquipment("Mainhand", undefined);
      }
    }

    const newDR = storage.getNumber("dream_rate", 0);
    player.sendMessage("§d§l✦ Tome of Lucid Visions consumed!");
    player.sendMessage(`§7Your Dream Rate increased by §a+1.0§7. Current: §a${newDR}`);

    try {
      player.playSound("random.levelup", { volume: 0.8, pitch: 1.0 });
      player.playSound("block.amethyst_block.chime", { volume: 0.6, pitch: 0.8 });
      player.dimension.runCommandAsync(
        `particle minecraft:endRod ${player.location.x} ${player.location.y + 1} ${player.location.z} 0.5 1 0.5 0 20`
      );
    } catch {}

    this.eventBridge.emit("dr_changed", player);
  }
}
