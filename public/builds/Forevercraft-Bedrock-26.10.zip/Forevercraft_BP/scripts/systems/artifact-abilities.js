/**
 * Artifact Abilities System — Passive and active abilities for equipped artifacts.
 * Replaces Java artifacts/abilities/ and artifacts/sets/ folders.
 *
 * Handles: set bonuses (including multi-tier), weapon passives, knockback,
 * armor passives, accessory effects, special weapon abilities.
 * Uses Script API equipment checking instead of Java NBT selectors.
 */
import { world, system, EffectTypes } from "@minecraft/server";
import { StorageManager } from "../utils/storage.js";

// Cached EffectTypes for O(1) lookup (avoid string lookups in hot path)
const FX = {};
for (const name of ["speed","resistance","regeneration","absorption","strength",
  "haste","slow_falling","night_vision","fire_resistance","jump_boost",
  "saturation","conduit_power","water_breathing","wither"]) {
  FX[name] = EffectTypes.get(name);
}
/** Apply effect via native API (faster than runCommandAsync).
 * OPT: Won't overwrite a higher-amplifier effect from another system. */
function fx(player, effect, dur, amp) {
  try {
    const effectType = FX[effect] || EffectTypes.get(effect);
    const existing = player.getEffect(effectType);
    // Don't overwrite a stronger effect from another system
    if (existing && existing.amplifier > amp) return;
    player.addEffect(effectType, dur * 20, { amplifier: amp, showParticles: false });
  } catch {}
}
import {
  applyKnockback, applyPull, applyAoEKnockback,
  MELEE_KB_STEPS, RANGED_PUNCH_STEPS
} from "../utils/knockback.js";

// ─── Tiered set bonuses (2pc / 4pc with proper Java parity) ──────
const SET_BONUSES = {
  // RARE SETS — 2pc and 4pc tiers
  dragonslayer: {
    name: "Dragonslayer Set", color: "§c",
    tiers: {
      2: { effects: ["dragon_dmg"], desc: "+20% damage vs Dragons & Endermen" },
      4: { effects: ["fire_immune", "dragon_horn"], desc: "Fire Immunity + Dragon Horn ability" },
    },
  },
  wither: {
    name: "Wither Set", color: "§8",
    tiers: {
      2: { effects: ["wither_immune", "lifesteal"], desc: "Wither Immunity + Lifesteal" },
      4: { effects: ["wither_touch", "wither_aura"], desc: "Attacks apply Wither + Wither aura" },
    },
  },
  phantom: {
    name: "Phantom Set", color: "§f",
    tiers: {
      2: { effects: ["slow_falling", "no_fall"], desc: "Slow Falling + No Fall Damage" },
      4: { effects: ["phantom_shift"], desc: "Phase-dodge on hit" },
    },
  },
  ender: {
    name: "Ender Set", color: "§5",
    tiers: {
      2: { effects: ["ender_dodge", "speed_1"], desc: "Teleport on damage + Speed I" },
      4: { effects: ["ender_warp"], desc: "Enhanced teleport dodge" },
    },
  },
  golem: {
    name: "Golem Set", color: "§7",
    tiers: {
      2: { effects: ["absorption_1", "kb_resist"], desc: "Absorption I + KB Resistance" },
      4: { effects: ["golem_fortify"], desc: "Resistance I when below half HP" },
    },
  },
  celestial: {
    name: "Celestial Set", color: "§e",
    tiers: {
      2: { effects: ["resistance_1"], desc: "Resistance I" },
      4: { effects: ["star_shield", "meteor_strike"], desc: "Star Shield + Meteor Strike ability" },
    },
  },
  blood: {
    name: "Blood Set", color: "§4",
    tiers: {
      2: { effects: ["regen_1"], desc: "Regeneration I" },
      4: { effects: ["blood_frenzy", "crimson_burst"], desc: "Blood Frenzy (Str I + Haste) + Crimson Burst" },
    },
  },
  shadow: {
    name: "Shadow Set", color: "§8",
    tiers: {
      2: { effects: ["speed_1", "stealth"], desc: "Speed I + Invisibility when sneaking" },
      4: { effects: ["speed_2", "assassinate"], desc: "Speed II + Assassinate ability" },
    },
  },
  crystal: {
    name: "Crystal Set", color: "§b",
    tiers: {
      2: { effects: ["absorption_1"], desc: "Absorption I" },
      4: { effects: ["crystal_shield"], desc: "Damage reflection" },
    },
  },
  netherwalker: {
    name: "Netherwalker Set", color: "§c",
    tiers: {
      2: { effects: ["fire_resistance"], desc: "Fire Resistance" },
      4: { effects: ["lava_walk", "nether_horn"], desc: "Lava Walking + Nether Horn ability" },
    },
  },
  frost: {
    name: "Frost Set", color: "§b",
    tiers: {
      2: { effects: ["frost_thorns"], desc: "Attackers get Slowness II" },
      4: { effects: ["frost_aura", "ice_ability"], desc: "Weakness V to enemies + Ice ability" },
    },
  },
  ocean: {
    name: "Ocean Set", color: "§3",
    tiers: {
      2: { effects: ["water_breathing", "dolphins_grace"], desc: "Water Breathing + Dolphin's Grace" },
      4: { effects: ["tidal_aura", "ocean_ability"], desc: "Tidal Horn ability + combat buffs" },
    },
  },
  storm: {
    name: "Storm Set", color: "§e",
    tiers: {
      2: { effects: ["lightning_immune", "speed_1"], desc: "Lightning Immunity + Speed I" },
      4: { effects: ["storm_strike"], desc: "Lightning on critical hits" },
    },
  },
  nature: {
    name: "Nature Set", color: "§a",
    tiers: {
      2: { effects: ["regen_1"], desc: "Regeneration I" },
      4: { effects: ["luck_4", "harvest_bonus"], desc: "Luck IV + Harvest bonuses" },
    },
  },
  sculk: {
    name: "Sculk Set", color: "§1",
    tiers: {
      2: { effects: ["vibration_sense"], desc: "Vibration sensing (Glowing to nearby mobs)" },
      4: { effects: ["warden_might", "sonic_boom"], desc: "Strength I + Sonic Boom ability" },
    },
  },
  // EXQUISITE SETS
  ember: {
    name: "Ember Set", color: "§6",
    tiers: {
      2: { effects: ["fire_aura_light"], desc: "Fire aura (light)" },
      4: { effects: ["fire_aura", "blaze_burst"], desc: "Fire aura + Blaze burst" },
    },
  },
  ninja: {
    name: "Ninja Set", color: "§8",
    tiers: {
      2: { effects: ["speed_1", "stealth"], desc: "Speed I + Stealth when crouching" },
      4: { effects: ["ninja_dodge", "smoke_bomb"], desc: "Dodge chance + Smoke bomb" },
    },
  },
  cloaked_skull: {
    name: "Cloaked Skull Set", color: "§5",
    tiers: {
      2: { effects: ["darkness_aura"], desc: "Darkness to nearby enemies" },
      4: { effects: ["skull_curse"], desc: "Curse aura + Lifesteal" },
    },
  },
  space: {
    name: "Space Set", color: "§d",
    tiers: {
      2: { effects: ["slow_falling"], desc: "Slow Falling" },
      4: { effects: ["gravity_well"], desc: "Pull enemies toward you" },
    },
  },
  fireforged: {
    name: "Fireforged Set", color: "§c",
    tiers: {
      2: { effects: ["fire_resistance"], desc: "Fire Resistance" },
      4: { effects: ["forge_flames"], desc: "Attacks ignite + fire shield" },
    },
  },
};

// ─── Multi-tier mythical set bonuses (2pc / 4pc / 5pc / 6pc) ──
const MYTHICAL_SETS = {
  titan: {
    name: "Titan's Shroud (Tempest)", color: "§3",
    tiers: {
      2: { tag: "titan_2pc", desc: "Conduit Power" },
      4: { tag: "titan_4pc", desc: "Tidal Horn ability" },
      5: { tag: "titan_5pc", desc: "Speed I (Riptide Surge)" },
      6: { tag: "titan_6pc", desc: "Conduit Power + Resistance II" },
    },
  },
  verdant: {
    name: "Verdant Set (Grove)", color: "§a",
    tiers: {
      2: { tag: "verdant_2pc", desc: "Saturation I (Nature's Embrace)" },
      4: { tag: "verdant_4pc", desc: "Harvest Caller ability" },
      5: { tag: "verdant_5pc", desc: "Luck V — Bountiful Harvest" },
    },
  },
  dragonmaster: {
    name: "Dragonmaster Set", color: "§c",
    tiers: {
      2: { tag: "dragonmaster_2pc", desc: "Strength I + class bonuses" },
      4: { tag: "dragonmaster_4pc", desc: "Dragon Horn ability" },
      5: { tag: "dragonmaster_5pc", desc: "Strength II + Fire Resistance" },
      6: { tag: "dragonmaster_6pc", desc: "Strength III + class bonuses" },
    },
  },
  infernal: {
    name: "Infernal Set", color: "§4",
    tiers: {
      2: { tag: "infernal_2pc", desc: "Resistance I + class bonuses" },
      4: { tag: "infernal_4pc", desc: "Fire shield ability" },
      5: { tag: "infernal_5pc", desc: "Fire Resistance + Strength I" },
      6: { tag: "infernal_6pc", desc: "Fire Resistance + Strength II + class bonuses" },
    },
  },
  ender_dragon: {
    name: "Voidscale Set", color: "§5",
    tiers: {
      2: { tag: "enderdrag_2pc", desc: "Void Resistance" },
      4: { tag: "enderdrag_4pc", desc: "Ender Warp ability" },
      5: { tag: "enderdrag_5pc", desc: "Regeneration I + Absorption I" },
      6: { tag: "enderdrag_6pc", desc: "Regeneration II + Absorption III + class bonuses" },
    },
  },
  splendid: {
    name: "Delver's Set (Splendid)", color: "§e",
    tiers: {
      2: { tag: "splendid_2pc", desc: "Night Vision" },
      4: { tag: "splendid_4pc", desc: "Haste I" },
      5: { tag: "splendid_5pc", desc: "Speed I + Night Vision" },
      6: { tag: "splendid_6pc", desc: "Speed II + Night Vision + class bonuses" },
    },
  },
  journey: {
    name: "Journey Set", color: "§6",
    tiers: {
      2: { tag: "journey_2pc", desc: "Speed I" },
      4: { tag: "journey_4pc", desc: "Luck I" },
      5: { tag: "journey_5pc", desc: "Luck II + class bonuses" },
    },
  },
};

// ─── Weapon ability definitions (KB levels, special abilities) ──
const WEAPON_ABILITIES = {
  // On-hit knockback (melee)
  knockback_1: { type: "melee_kb", level: 1, tag: "forevercraft:kb_1" },
  knockback_2: { type: "melee_kb", level: 2, tag: "forevercraft:kb_2" },
  knockback_3: { type: "melee_kb", level: 3, tag: "forevercraft:kb_3" },
  knockback_4: { type: "melee_kb", level: 4, tag: "forevercraft:kb_4" },
  knockback_5: { type: "melee_kb", level: 5, tag: "forevercraft:kb_5" },

  // On-hit knockback (ranged/punch)
  punch_1: { type: "ranged_kb", level: 1, tag: "forevercraft:punch_1" },
  punch_2: { type: "ranged_kb", level: 2, tag: "forevercraft:punch_2" },
  punch_3: { type: "ranged_kb", level: 3, tag: "forevercraft:punch_3" },
  punch_4: { type: "ranged_kb", level: 4, tag: "forevercraft:punch_4" },
  punch_5: { type: "ranged_kb", level: 5, tag: "forevercraft:punch_5" },

  // Special abilities
  aoe_knockback: { type: "aoe_kb", tag: "forevercraft:aoe_knockback" },        // Earthshaker
  gale_sweep: { type: "gale_sweep", tag: "forevercraft:gale_sweep" },            // Whirlwind
  dragon_pierce: { type: "dragon_pierce", tag: "forevercraft:dragon_pierce" },   // Dragonmaster Lance
  tidal_strike: { type: "tidal_strike", tag: "forevercraft:tidal_strike" },      // Prismarine Pickaxe
  legendary_smash: { type: "legendary_smash", tag: "forevercraft:legendary_smash" }, // Mace of Legends
  shield_bash: { type: "shield_bash", tag: "forevercraft:shield_bash" },         // Shield bash impact
};

export class ArtifactAbilitySystem {
  constructor(eventBridge) {
    this.eventBridge = eventBridge;
    this.tickCounter = 0;

    // Damage dealt → check for weapon abilities + knockback
    eventBridge.on("player_dealt_damage", ({ player, target, damage, damageSource }) => {
      this.onPlayerAttack(player, target, damage);
    });

    // Artifact kill tracking: track kills per equipped artifact weapon
    eventBridge.on("player_killed_entity", ({ player, entity }) => {
      this.trackArtifactKill(player);
    });

    // Player hurt → check for armor abilities
    eventBridge.on("player_hurt", ({ player, damage, damageSource }) => {
      this.onPlayerHurt(player, damageSource, damage);
    });

    // Projectile hit → check for ranged knockback
    eventBridge.on("projectile_hit", ({ player, target, projectile }) => {
      this.onProjectileHit(player, target, projectile);
    });
  }

  /** Check equipped set pieces every 20 ticks (1 second) */
  tick(players) {
    this.tickCounter++;
    if (this.tickCounter < 20) return;
    this.tickCounter = 0;

    for (const player of players) {
      this.checkSetBonuses(player);
      this.checkMythicalSets(player);
      this.applyPassiveEffects(player);
      this.tickMythicalCooldowns(player);
    }
  }

  // ═══════════════════════════════════════════════════════
  // SET BONUS CHECKING
  // ═══════════════════════════════════════════════════════

  /** Count equipped pieces for each artifact set and apply tiered bonuses */
  checkSetBonuses(player) {
    const equip = player.getComponent("minecraft:equippable");
    if (!equip) return;

    // Count pieces per set from armor + mainhand + offhand
    const setCounts = {};
    for (const slot of ["Head", "Chest", "Legs", "Feet", "Mainhand", "Offhand"]) {
      const item = equip.getEquipment(slot);
      if (!item) continue;
      const tags = item.getTags?.() || [];
      for (const tag of tags) {
        if (tag.startsWith("forevercraft:set_")) {
          const setName = tag.replace("forevercraft:set_", "");
          setCounts[setName] = (setCounts[setName] || 0) + 1;
        }
      }
    }

    // Apply/remove tiered set bonuses (2pc / 4pc)
    for (const [setName, setDef] of Object.entries(SET_BONUSES)) {
      const count = setCounts[setName] || 0;
      for (const [threshold, tierDef] of Object.entries(setDef.tiers)) {
        const threshNum = parseInt(threshold);
        const tag = `ec.set_${setName}_${threshNum}pc`;
        const hasEnough = count >= threshNum;

        if (hasEnough && !player.hasTag(tag)) {
          player.addTag(tag);
          player.sendMessage(`${setDef.color}§l✦ ${setDef.name} §r§d${threshNum}pc§r\n§7${tierDef.desc}`);
        } else if (!hasEnough && player.hasTag(tag)) {
          player.removeTag(tag);
        }
      }
    }
  }

  /** Check multi-tier mythical set bonuses (2pc/4pc/5pc/6pc) */
  checkMythicalSets(player) {
    const equip = player.getComponent("minecraft:equippable");
    if (!equip) return;

    // Count pieces per mythical set (armor + mainhand + offhand for 6pc max)
    const setCounts = {};
    for (const slot of ["Head", "Chest", "Legs", "Feet", "Mainhand", "Offhand"]) {
      const item = equip.getEquipment(slot);
      if (!item) continue;
      const tags = item.getTags?.() || [];
      for (const tag of tags) {
        if (tag.startsWith("forevercraft:set_")) {
          const setName = tag.replace("forevercraft:set_", "");
          if (MYTHICAL_SETS[setName]) {
            setCounts[setName] = (setCounts[setName] || 0) + 1;
          }
        }
      }
    }

    for (const [setName, setDef] of Object.entries(MYTHICAL_SETS)) {
      const count = setCounts[setName] || 0;

      for (const [threshold, tierDef] of Object.entries(setDef.tiers)) {
        const threshNum = parseInt(threshold);
        const hasEnough = count >= threshNum;

        if (hasEnough && !player.hasTag(tierDef.tag)) {
          player.addTag(tierDef.tag);
          player.sendMessage(`§6§l✦ ${setDef.name} §r§d${tierDef.name}§r\n§7${tierDef.desc}`);
        } else if (!hasEnough && player.hasTag(tierDef.tag)) {
          player.removeTag(tierDef.tag);
          player.sendMessage(`§6§l✦ ${setDef.name} §r§7${tierDef.name} bonus removed`);
        }
      }
    }
  }

  // ═══════════════════════════════════════════════════════
  // PASSIVE EFFECTS
  // ═══════════════════════════════════════════════════════

  applyPassiveEffects(player) {
    // ─── RARE/EXQUISITE 2pc PASSIVES (native addEffect API — no command overhead) ───
    // Uses fx() helper: fx(player, effect, duration_seconds, amplifier)
    if (player.hasTag("ec.set_wither_2pc"))       try { player.removeEffect(FX.wither); } catch {}
    if (player.hasTag("ec.set_phantom_2pc"))      fx(player, "slow_falling", 5, 0);
    if (player.hasTag("ec.set_ender_2pc"))        fx(player, "speed", 5, 0);
    if (player.hasTag("ec.set_golem_2pc"))        fx(player, "absorption", 5, 0);
    if (player.hasTag("ec.set_celestial_2pc"))    fx(player, "resistance", 5, 0);
    if (player.hasTag("ec.set_blood_2pc"))        fx(player, "regeneration", 5, 0);
    if (player.hasTag("ec.set_shadow_2pc"))       { fx(player, "speed", 5, 0); if (player.isSneaking) fx(player, "invisibility", 3, 0); }
    if (player.hasTag("ec.set_crystal_2pc"))      fx(player, "absorption", 5, 0);
    if (player.hasTag("ec.set_netherwalker_2pc")) fx(player, "fire_resistance", 5, 0);
    if (player.hasTag("ec.set_ocean_2pc"))        { fx(player, "water_breathing", 5, 0); fx(player, "conduit_power", 5, 0); }
    if (player.hasTag("ec.set_storm_2pc"))        fx(player, "speed", 5, 0);
    if (player.hasTag("ec.set_nature_2pc"))       fx(player, "regeneration", 5, 0);
    if (player.hasTag("ec.set_sculk_2pc")) {
      try {
        const mobs = player.dimension.getEntities({ location: player.location, maxDistance: 12, excludeTypes: ["minecraft:player"] });
        const glowing = EffectTypes.get("glowing");
        for (const m of mobs) try { m.addEffect(glowing, 100, { amplifier: 0, showParticles: false }); } catch {}
      } catch {}
    }
    if (player.hasTag("ec.set_ninja_2pc"))        { fx(player, "speed", 5, 0); if (player.isSneaking) fx(player, "invisibility", 3, 0); }
    if (player.hasTag("ec.set_space_2pc"))        fx(player, "slow_falling", 5, 0);
    if (player.hasTag("ec.set_fireforged_2pc"))   fx(player, "fire_resistance", 5, 0);

    // ─── RARE/EXQUISITE 4pc PASSIVES ───
    if (player.hasTag("ec.set_blood_4pc"))   { fx(player, "strength", 5, 0); fx(player, "haste", 5, 0); }
    if (player.hasTag("ec.set_shadow_4pc"))  fx(player, "speed", 5, 1);
    if (player.hasTag("ec.set_nature_4pc"))  fx(player, "absorption", 5, 3);
    if (player.hasTag("ec.set_sculk_4pc"))   fx(player, "strength", 5, 0);
    if (player.hasTag("ec.set_golem_4pc")) {
      try { const hp = player.getComponent("minecraft:health"); if (hp && hp.currentValue < hp.effectiveMax * 0.5) fx(player, "resistance", 5, 0); } catch {}
    }

    // ─── MYTHICAL TIER PASSIVES ───
    if (player.hasTag("titan_2pc"))         fx(player, "conduit_power", 5, 0);
    if (player.hasTag("titan_5pc"))         fx(player, "speed", 5, 0);
    if (player.hasTag("titan_6pc"))         fx(player, "resistance", 5, 1);
    if (player.hasTag("verdant_2pc"))       fx(player, "saturation", 5, 0);
    if (player.hasTag("verdant_5pc"))       fx(player, "absorption", 5, 4);
    if (player.hasTag("dragonmaster_2pc"))  fx(player, "strength", 5, 0);
    if (player.hasTag("dragonmaster_5pc"))  { fx(player, "strength", 5, 1); fx(player, "fire_resistance", 5, 0); }
    if (player.hasTag("dragonmaster_6pc"))  fx(player, "strength", 5, 2);
    if (player.hasTag("infernal_2pc"))      fx(player, "resistance", 5, 0);
    if (player.hasTag("infernal_5pc"))      { fx(player, "fire_resistance", 5, 0); fx(player, "strength", 5, 0); }
    if (player.hasTag("infernal_6pc"))      { fx(player, "fire_resistance", 5, 0); fx(player, "strength", 5, 1); }
    if (player.hasTag("enderdrag_5pc"))     { fx(player, "regeneration", 5, 0); fx(player, "absorption", 5, 0); }
    if (player.hasTag("enderdrag_6pc"))     { fx(player, "regeneration", 5, 1); fx(player, "absorption", 5, 2); }
    if (player.hasTag("splendid_2pc"))      fx(player, "night_vision", 5, 0);
    if (player.hasTag("splendid_4pc"))      fx(player, "haste", 5, 0);
    if (player.hasTag("splendid_5pc"))      { fx(player, "speed", 5, 0); fx(player, "night_vision", 5, 0); }
    if (player.hasTag("splendid_6pc"))      { fx(player, "speed", 5, 1); fx(player, "night_vision", 5, 0); }
    if (player.hasTag("journey_2pc"))       fx(player, "speed", 5, 0);
    if (player.hasTag("journey_4pc"))       fx(player, "absorption", 5, 0);
    if (player.hasTag("journey_5pc"))       fx(player, "absorption", 5, 1);
  }

  /** Tick mythical set cooldowns (called per second) */
  tickMythicalCooldowns(player) {
    const s = StorageManager.forPlayer(player);

    // Titan Tidal Horn cooldown
    let tidalCd = s.getNumber("ec_tidal_cd");
    if (tidalCd > 0) {
      tidalCd--;
      s.set("ec_tidal_cd", tidalCd);
      if (tidalCd === 0) player.sendMessage("§b§l✦ Tidal Horn §r§7is ready!");
    }

    // Verdant Harvest Caller cooldown
    let harvestCd = s.getNumber("ec_harvest_cd");
    if (harvestCd > 0) {
      harvestCd--;
      s.set("ec_harvest_cd", harvestCd);
      if (harvestCd === 0) player.sendMessage("§2§l✦ Harvest Caller §r§7is ready!");
    }
  }

  // ═══════════════════════════════════════════════════════
  // MYTHICAL SET ABILITIES
  // ═══════════════════════════════════════════════════════

  /** Titan 4pc: Tidal Horn — Luck V to all nearby players for 3 minutes */
  useTidalHorn(player) {
    if (!player.hasTag("titan_4pc")) {
      player.sendMessage("§c§lTidal Horn §r§7requires Titan's Shroud 4pc!");
      return;
    }
    const s = StorageManager.forPlayer(player);
    if (s.getNumber("ec_tidal_cd") > 0) {
      player.sendMessage(`§b§lTidal Horn §r§7on cooldown: §f${s.getNumber("ec_tidal_cd")}s`);
      return;
    }
    s.set("ec_tidal_cd", 90);

    try {
      const nearby = player.dimension.getEntities({
        type: "minecraft:player",
        location: player.location,
        maxDistance: 16,
      });
      for (const p of nearby) {
        p.runCommandAsync("effect @s absorption 180 4 true");
        p.sendMessage("§b§l✦ Tidal Horn! §r§7Absorption V for 3 minutes");
      }
    } catch {}
    player.playSound("note.didgeridoo");
  }

  /** Verdant 4pc: Harvest Caller — Instantly grow all crops in 16-block radius */
  useHarvestCaller(player) {
    if (!player.hasTag("verdant_4pc")) {
      player.sendMessage("§c§lHarvest Caller §r§7requires Verdant 4pc!");
      return;
    }
    const s = StorageManager.forPlayer(player);
    if (s.getNumber("ec_harvest_cd") > 0) {
      player.sendMessage(`§2§lHarvest Caller §r§7on cooldown: §f${s.getNumber("ec_harvest_cd")}s`);
      return;
    }
    s.set("ec_harvest_cd", 90);

    // Grow all crops in radius via fill commands
    const loc = player.location;
    const x = Math.floor(loc.x);
    const y = Math.floor(loc.y);
    const z = Math.floor(loc.z);
    const r = 16;
    try {
      const dim = player.dimension;
      dim.runCommandAsync(`fill ${x-r} ${y-1} ${z-r} ${x+r} ${y+3} ${z+r} wheat ["growth"=7] replace wheat`);
      dim.runCommandAsync(`fill ${x-r} ${y-1} ${z-r} ${x+r} ${y+3} ${z+r} carrots ["growth"=7] replace carrots`);
      dim.runCommandAsync(`fill ${x-r} ${y-1} ${z-r} ${x+r} ${y+3} ${z+r} potatoes ["growth"=7] replace potatoes`);
      dim.runCommandAsync(`fill ${x-r} ${y-1} ${z-r} ${x+r} ${y+3} ${z+r} beetroot ["growth"=7] replace beetroot`);
      dim.runCommandAsync(`fill ${x-r} ${y-1} ${z-r} ${x+r} ${y+3} ${z+r} nether_wart ["age"=3] replace nether_wart`);
      dim.runCommandAsync(`fill ${x-r} ${y-1} ${z-r} ${x+r} ${y+3} ${z+r} sweet_berry_bush ["growth"=3] replace sweet_berry_bush`);
    } catch {}

    player.sendMessage("§2§l✦ Harvest Caller! §r§7The harvest answers your call!");
    player.playSound("item.bone_meal.use");
  }

  // ═══════════════════════════════════════════════════════
  // COMBAT — ON HIT (MELEE)
  // ═══════════════════════════════════════════════════════

  onPlayerAttack(player, target, damage) {
    // Check weapon tags for knockback abilities
    const equip = player.getComponent("minecraft:equippable");
    const mainhand = equip?.getEquipment("Mainhand");
    if (mainhand) {
      const tags = mainhand.getTags?.() || [];
      this.processWeaponAbilities(player, target, tags);
    }

    // Lifesteal from Blood 2pc
    if (player.hasTag("ec.set_blood_2pc")) {
      const healAmount = Math.max(1, Math.floor(damage * 0.1));
      const health = player.getComponent("minecraft:health");
      if (health) {
        const newHealth = Math.min(health.currentValue + healAmount, health.effectiveMax);
        health.setCurrentValue(newHealth);
      }
    }

    // Wither touch from Wither 4pc
    if (player.hasTag("ec.set_wither_4pc")) {
      try { target.runCommandAsync("effect @s wither 5 0"); } catch {}
    }

    // Frost 2pc: attackers get slowness
    if (player.hasTag("ec.set_frost_2pc")) {
      try { target.runCommandAsync("effect @s slowness 3 1"); } catch {}
    }

    // Frost 4pc: weakness to enemies
    if (player.hasTag("ec.set_frost_4pc")) {
      try { target.runCommandAsync("effect @s weakness 5 4"); } catch {}
    }

    // Dragonslayer 2pc: +20% vs dragons/endermen
    if (player.hasTag("ec.set_dragonslayer_2pc")) {
      const tId = target.typeId || "";
      if (tId.includes("dragon") || tId.includes("enderman") || tId.includes("endermite") || tId.includes("shulker")) {
        try { target.applyDamage(Math.floor(damage * 0.2), { cause: "entityAttack", damagingEntity: player }); } catch {}
      }
    }

    // Ember 4pc: fire aura on hit
    if (player.hasTag("ec.set_ember_4pc")) {
      try { target.setOnFire(3); } catch {}
    }

    // Fireforged 4pc: ignite on hit
    if (player.hasTag("ec.set_fireforged_4pc")) {
      try { target.setOnFire(5); } catch {}
    }

    // Cloaked Skull 4pc: lifesteal
    if (player.hasTag("ec.set_cloaked_skull_4pc")) {
      const healAmount = Math.max(1, Math.floor(damage * 0.15));
      const health = player.getComponent("minecraft:health");
      if (health) {
        const newHealth = Math.min(health.currentValue + healAmount, health.effectiveMax);
        health.setCurrentValue(newHealth);
      }
    }
  }

  /** Process weapon-tag-based abilities */
  processWeaponAbilities(player, target, tags) {
    // Melee knockback levels
    for (let level = 5; level >= 1; level--) {
      if (tags.includes(`forevercraft:kb_${level}`)) {
        const steps = MELEE_KB_STEPS[level] || 2;
        applyKnockback(target, player, steps);
        player.playSound("entity.player.attack.knockback");
        return; // Only apply highest KB level
      }
    }

    // Gale Sweep — 5-step AoE knockback + 2 damage to all in 4 blocks
    if (tags.includes("forevercraft:gale_sweep")) {
      try {
        const nearby = player.dimension.getEntities({
          location: player.location,
          maxDistance: 4,
          excludeTypes: ["minecraft:player", "minecraft:item", "minecraft:xp_orb"],
          excludeFamilies: ["inanimate"],
        });
        for (const entity of nearby) {
          try { entity.applyDamage(2, { cause: "entityAttack", damagingEntity: player }); } catch {}
          applyKnockback(entity, player, 5);
        }
        player.playSound("entity.player.attack.sweep");
        StorageManager.forPlayer(player).increment("ach_weapon_abilities");
      } catch {}
    }

    // Dragon Pierce — fire damage + 5-step AoE knockback + ignite
    if (tags.includes("forevercraft:dragon_pierce")) {
      try {
        const nearest = player.dimension.getEntities({
          location: player.location, maxDistance: 5,
          excludeTypes: ["minecraft:player", "minecraft:item"],
          limit: 1, closest: true,
        });
        for (const entity of nearest) {
          try {
            entity.applyDamage(5, { cause: "entityAttack", damagingEntity: player });
            entity.setOnFire(3);
          } catch {}
        }
        // AoE knockback to nearby unhurt mobs
        const aoe = player.dimension.getEntities({
          location: player.location, maxDistance: 6,
          excludeTypes: ["minecraft:player", "minecraft:item"],
          limit: 5, closest: true,
        });
        for (const entity of aoe) {
          applyKnockback(entity, player, 5);
        }
        player.playSound("mob.enderdragon.growl");
        StorageManager.forPlayer(player).increment("ach_weapon_abilities");
      } catch {}
    }

    // Tidal Strike — 4-step PULL toward player + Slowness
    if (tags.includes("forevercraft:tidal_strike")) {
      try {
        target.runCommandAsync("effect @s slowness 3 1");
        applyPull(target, player, 4);
        player.playSound("entity.player.splash");
        StorageManager.forPlayer(player).increment("ach_weapon_abilities");
      } catch {}
    }

    // AoE Knockback (Earthshaker) — impact-tier scaled
    if (tags.includes("forevercraft:aoe_knockback")) {
      const s = StorageManager.forPlayer(player);
      const impact = s.getNumber("sk_impact") || 0;
      let steps = 4;
      let radius = 5;
      if (impact >= 75) { steps = 8; radius = 8; }
      else if (impact >= 50) { steps = 6; radius = 6; }
      const hit = applyAoEKnockback(player, radius, steps, 10);
      if (hit > 0) player.playSound("entity.player.attack.knockback");
    }
  }

  // ═══════════════════════════════════════════════════════
  // COMBAT — RANGED (PUNCH)
  // ═══════════════════════════════════════════════════════

  /** Called when a player's projectile hits an entity */
  onProjectileHit(player, target, projectile) {
    if (!player || !target) return;

    const equip = player.getComponent("minecraft:equippable");
    const mainhand = equip?.getEquipment("Mainhand");
    if (!mainhand) return;

    const tags = mainhand.getTags?.() || [];

    // Ranged punch knockback
    for (let level = 5; level >= 1; level--) {
      if (tags.includes(`forevercraft:punch_${level}`)) {
        const steps = RANGED_PUNCH_STEPS[level] || 3;
        applyKnockback(target, player, steps);
        player.playSound("entity.player.attack.knockback");
        return;
      }
    }
  }

  // ═══════════════════════════════════════════════════════
  // COMBAT — SPECIAL ABILITIES
  // ═══════════════════════════════════════════════════════

  /** Legendary Smash — Mace of Legends AoE + knockback (impact-tier scaled) */
  legendarySmash(player) {
    const s = StorageManager.forPlayer(player);
    const impact = s.getNumber("sk_impact") || 0;

    let damage, radius, steps, slowLevel, slowDur, label, color;
    if (impact >= 75) {
      damage = 7; radius = 8; steps = 8; slowLevel = 1; slowDur = 4; label = "§4§l⚔ LEGENDARY SMASH!"; color = "dark_red";
    } else if (impact >= 50) {
      damage = 7; radius = 5; steps = 6; slowLevel = 1; slowDur = 4; label = "§5§l⚔ Legendary Smash!"; color = "light_purple";
    } else {
      damage = 4; radius = 4; steps = 4; slowLevel = 0; slowDur = 3; label = "§6§l⚔ Smash!"; color = "gold";
    }

    try {
      const nearby = player.dimension.getEntities({
        location: player.location, maxDistance: radius,
        excludeTypes: ["minecraft:player", "minecraft:item", "minecraft:xp_orb"],
        excludeFamilies: ["inanimate"],
      });
      for (const entity of nearby) {
        try {
          entity.applyDamage(damage, { cause: "entityAttack", damagingEntity: player });
          entity.runCommandAsync(`effect @s slowness ${slowDur} ${slowLevel}`);
        } catch {}
        applyKnockback(entity, player, steps);
      }
      player.playSound("entity.generic.explode");
      player.onScreenDisplay.setActionBar(label);
    } catch {}
  }

  /** Shield Bash Impact — tier-based progressive knockback */
  shieldBashImpact(player, bashKbValue) {
    // bashKbValue: 10=1.0, 13=1.3, 16=1.6, 19=1.9, 22=2.2, 28=2.8 (x10 int)
    let steps = 3; // Base 3 steps = 1.2 blocks
    if (bashKbValue >= 16) steps++;
    if (bashKbValue >= 19) steps++;
    if (bashKbValue >= 22) steps++;
    if (bashKbValue >= 28) steps++;

    applyAoEKnockback(player, 3, steps, 5);
    player.playSound("entity.player.attack.knockback");
  }

  // ═══════════════════════════════════════════════════════
  // DEFENSE
  // ═══════════════════════════════════════════════════════

  onPlayerHurt(player, source, damage) {
    const attacker = source?.damagingEntity;

    // Ember 2pc/4pc: fire retaliation
    if (player.hasTag("ec.set_ember_2pc") && attacker) {
      try { attacker.setOnFire(3); } catch {}
    }

    // Crystal 4pc: damage reflection
    if (player.hasTag("ec.set_crystal_4pc") && attacker) {
      try { attacker.applyDamage(Math.floor(damage * 0.2), { cause: "thorns" }); } catch {}
    }

    // Ender 2pc: teleport dodge
    if (player.hasTag("ec.set_ender_2pc") && Math.random() < 0.15) {
      const loc = player.location;
      const angle = Math.random() * Math.PI * 2;
      try {
        player.teleport({ x: loc.x + Math.cos(angle) * 5, y: loc.y, z: loc.z + Math.sin(angle) * 5 });
        player.playSound("mob.endermen.portal");
      } catch {}
    }

    // Cloaked Skull 2pc: darkness to attacker
    if (player.hasTag("ec.set_cloaked_skull_2pc") && attacker) {
      try { attacker.runCommandAsync("effect @s darkness 5 0 true"); } catch {}
    }

    // Space 4pc: pull enemies toward you
    if (player.hasTag("ec.set_space_4pc") && attacker) {
      try {
        const pl = player.location;
        const al = attacker.location;
        const dx = pl.x - al.x;
        const dz = pl.z - al.z;
        const dist = Math.sqrt(dx * dx + dz * dz);
        if (dist > 2) {
          attacker.teleport({
            x: al.x + (dx / dist) * 2, y: al.y, z: al.z + (dz / dist) * 2,
          });
        }
      } catch {}
    }
  }

  // ─── ARTIFACT KILL TRACKER ──────────────────────────────────

  /** Track kills with equipped artifact weapon */
  trackArtifactKill(player) {
    try {
      const equip = player.getComponent("minecraft:equippable");
      if (!equip) return;
      const mainhand = equip.getEquipment("Mainhand");
      if (!mainhand) return;
      const typeId = mainhand.typeId;
      // Only track custom artifacts (forevercraft: prefix)
      if (!typeId.startsWith("forevercraft:")) return;
      const artifactId = typeId.replace("forevercraft:", "");
      const s = StorageManager.forPlayer(player);
      const key = `art_kills_${artifactId}`;
      s.set(key, s.getNumber(key, 0) + 1);

      // Track discovery (first time using an artifact to kill)
      const discKey = `art_disc_${artifactId}`;
      if (!s.get(discKey)) {
        s.set(discKey, true);
        const count = s.getNumber("artifacts_discovered", 0) + 1;
        s.set("artifacts_discovered", count);
        player.sendMessage(`§d§l✦ §r§7Artifact Discovered: §e${artifactId.replace(/_/g, " ")}`);
        this.eventBridge.emit("artifact_discovered", player, artifactId);
      }
    } catch {}
  }

  // =====================================================
  // HUNTER CROSSBOW SYSTEM
  // =====================================================

  /**
   * Hunter crossbows detected by lore tag: §0§r§0hunter:{id}
   * 6 crossbows with unique precision abilities triggered on projectile hit.
   */
  initHunterSystem() {
    // Track projectile hits for hunter crossbow ability triggers
    world.afterEvents.projectileHitEntity.subscribe((event) => {
      this.onHunterProjectileHit(event);
    });
  }

  /** Hunter crossbow IDs and their abilities */
  static HUNTER_CROSSBOWS = {
    1: { name: "Windrunner",    ability: "quickdraw",  cd: 120,  desc: "Speed III (2s)" },
    2: { name: "Air Strike",    ability: "ignition",   cd: 200,  desc: "Fire AoE (4 blocks)" },
    3: { name: "Acacia Ballista", ability: "pierce",   cd: 300,  desc: "Piercing damage" },
    4: { name: "Venomfang",     ability: "blight",     cd: 400,  desc: "Wither + Poison AoE (5 blocks)" },
    5: { name: "Echo Shot",     ability: "resonance",  cd: 500,  desc: "Damage echo (8 blocks)" },
    6: { name: "Awper Hand",    ability: "rift",       cd: 800,  desc: "Void gravity rift" },
  };

  onHunterProjectileHit(event) {
    const shooter = event.source;
    if (!shooter || shooter.typeId !== "minecraft:player") return;

    const s = StorageManager.forPlayer(shooter);
    const hunterId = s.getNumber("ht_bow_id", 0);
    if (hunterId < 1 || hunterId > 6) return;

    // Check cooldown
    const cdKey = `ht_cd_${hunterId}`;
    const cd = s.getNumber(cdKey, 0);
    if (cd > 0) return;

    const crossbow = ArtifactAbilitySystem.HUNTER_CROSSBOWS[hunterId];
    if (!crossbow) return;

    const target = event.getEntityHit()?.entity;
    const hitLoc = target ? target.location : event.location;

    // Set cooldown
    s.set(cdKey, crossbow.cd);

    // Execute ability
    switch (crossbow.ability) {
      case "quickdraw":
        this.hunterQuickdraw(shooter);
        break;
      case "ignition":
        this.hunterIgnition(shooter, hitLoc);
        break;
      case "pierce":
        this.hunterPierce(shooter, target);
        break;
      case "blight":
        this.hunterBlight(shooter, hitLoc);
        break;
      case "resonance":
        this.hunterResonance(shooter, hitLoc);
        break;
      case "rift":
        this.hunterRift(shooter, hitLoc);
        break;
    }
  }

  /** Windrunner — Speed III for 2 seconds */
  hunterQuickdraw(player) {
    try {
      player.addEffect("speed", 40, { amplifier: 2, showParticles: true });
      player.sendMessage("§b§l⚡ Quickdraw! §r§7Speed III");
    } catch {}
  }

  /** Air Strike — Fire AoE, 4 block radius */
  hunterIgnition(player, location) {
    try {
      const nearby = player.dimension.getEntities({
        location,
        maxDistance: 4,
        excludeTypes: ["minecraft:player"],
      });
      for (const e of nearby) {
        try {
          e.setOnFire(5, true);
          e.applyDamage(3, { cause: "fire" });
        } catch {}
      }
      try { player.dimension.spawnParticle("minecraft:huge_explosion_emitter", location); } catch {}
      player.sendMessage("§6§l🔥 Ignition! §r§7Fire AoE");
    } catch {}
  }

  /** Acacia Ballista — Piercing damage bonus */
  hunterPierce(player, target) {
    if (!target) return;
    try {
      target.applyDamage(6, { cause: "projectile", damagingEntity: player });
      target.addEffect("slowness", 60, { amplifier: 3, showParticles: true });
      player.sendMessage("§e§l⚔ Pierce! §r§7Impaling shot");
    } catch {}
  }

  /** Venomfang — Wither III + Poison II, 5 block radius */
  hunterBlight(player, location) {
    try {
      const nearby = player.dimension.getEntities({
        location,
        maxDistance: 5,
        excludeTypes: ["minecraft:player"],
      });
      for (const e of nearby) {
        try {
          e.addEffect("wither", 100, { amplifier: 2, showParticles: true });
          e.addEffect("poison", 100, { amplifier: 1, showParticles: true });
        } catch {}
      }
      try { player.dimension.spawnParticle("minecraft:dragon_breath_trail", location); } catch {}
      player.sendMessage("§8§l☠ Blight! §r§7Wither + Poison AoE");
    } catch {}
  }

  /** Echo Shot — Instant Damage I + Glowing to 8 block radius */
  hunterResonance(player, location) {
    try {
      const nearby = player.dimension.getEntities({
        location,
        maxDistance: 8,
        excludeTypes: ["minecraft:player"],
      });
      for (const e of nearby) {
        try {
          e.addEffect("instant_damage", 1, { amplifier: 0, showParticles: true });
          e.addEffect("glowing", 60, { amplifier: 0, showParticles: false });
        } catch {}
      }
      player.sendMessage("§d§l◎ Resonance! §r§7Echo damage");
    } catch {}
  }

  /** Awper Hand — Void rift: Levitation + Slowness, 4s delayed Wither burst */
  hunterRift(player, location) {
    try {
      const dim = player.dimension;

      // Initial rift: Levitation + Slowness
      const nearby = dim.getEntities({
        location,
        maxDistance: 6,
        excludeTypes: ["minecraft:player"],
      });
      for (const e of nearby) {
        try {
          e.addEffect("levitation", 80, { amplifier: 3, showParticles: true });
          e.addEffect("slowness", 80, { amplifier: 2, showParticles: true });
        } catch {}
      }

      try { dim.spawnParticle("minecraft:endrod", location); } catch {}
      player.sendMessage("§5§l◈ Rift! §r§7Void gravity well created");

      // Delayed collapse: 80 ticks (4 seconds) later
      system.runTimeout(() => {
        try {
          const burst = dim.getEntities({
            location,
            maxDistance: 6,
            excludeTypes: ["minecraft:player"],
          });
          for (const e of burst) {
            try {
              e.addEffect("wither", 80, { amplifier: 1, showParticles: true });
              e.addEffect("instant_damage", 1, { amplifier: 0, showParticles: true });
            } catch {}
          }
          try { dim.spawnParticle("minecraft:huge_explosion_emitter", location); } catch {}
        } catch {}
      }, 80);
    } catch {}
  }

  /** Tick hunter cooldowns (called from main tick) */
  tickHunterCooldowns(players) {
    for (const player of players) {
      const s = StorageManager.forPlayer(player);
      for (let id = 1; id <= 6; id++) {
        const cdKey = `ht_cd_${id}`;
        const cd = s.getNumber(cdKey, 0);
        if (cd > 0) {
          s.set(cdKey, cd - 1);
        }
      }
    }
  }

  // === DOUBLE JUMP (Cloudstep Boots / Nimble Turtle Boots) ===
  // Runs every 2 ticks for responsive detection.
  // Trigger: sneaking + in air + wearing boots with double_jump ability + no cooldown
  // Effect: Levitation burst (upward launch) + cloud particles + phantom flap sound
  /** @type {Map<string, number>} */
  doubleJumpCooldowns = new Map();

  tickDoubleJump(players) {
    for (const player of players) {
      const cdKey = player.id;
      const cd = this.doubleJumpCooldowns.get(cdKey) || 0;

      // Decrement cooldown
      if (cd > 0) {
        this.doubleJumpCooldowns.set(cdKey, cd - 1);
        continue;
      }

      // Check for double jump boots
      try {
        const equip = player.getComponent("minecraft:equippable");
        if (!equip) continue;
        const feet = equip.getEquipment("Feet");
        if (!feet) continue;
        const lore = feet.getLore?.() || [];
        const hasDoubleJump = lore.some(l => l.includes("double_jump") || l.includes("Cloudstep") || l.includes("Nimble"));
        if (!hasDoubleJump) continue;

        // Reset cooldown when on ground
        if (player.isOnGround) {
          this.doubleJumpCooldowns.set(cdKey, 0);
          continue;
        }

        // Trigger: sneaking + not on ground + no cooldown
        if (player.isSneaking && !player.isOnGround) {
          this.doubleJumpCooldowns.set(cdKey, 10); // 10 × 2 ticks = 1 second cooldown
          try {
            player.addEffect(EffectTypes.get("levitation"), 20, { amplifier: 3, showParticles: false });
            player.dimension.spawnParticle("minecraft:basic_crit_particle", player.location);
            player.playSound("mob.phantom.flap", { volume: 0.5, pitch: 1.5 });
          } catch {}
          // Track for achievements
          const s = StorageManager.forPlayer(player);
          s.setNumber("ach_weapon_abilities", (s.getNumber("ach_weapon_abilities", 0)) + 1);
        }
      } catch {}
    }
  }
}
