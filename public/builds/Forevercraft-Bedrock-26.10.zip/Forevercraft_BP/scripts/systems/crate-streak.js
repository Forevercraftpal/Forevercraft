/**
 * Crate Streak System — Consecutive crate opens within 5 minutes grant bonuses.
 * At streak 3/5/10, bonus XP and improved next-crate luck.
 * Replaces Java cross-system hook.
 */
import { system } from "@minecraft/server";
import { StorageManager } from "../utils/storage.js";

const STREAK_TIMEOUT_TICKS = 6000; // 5 minutes
const STREAK_BONUSES = [
  { count: 3, xp: 50, msg: "§e§l✦ Crate Streak x3! §r§7+50 XP" },
  { count: 5, xp: 150, msg: "§6§l✦ Crate Streak x5! §r§7+150 XP, luck boost!" },
  { count: 10, xp: 500, msg: "§c§l✦ MEGA STREAK x10! §r§7+500 XP, major luck boost!" },
];

export class CrateStreakSystem {
  constructor(eventBridge) {
    /** @type {Map<string, {count: number, lastCrateTick: number}>} */
    this.streaks = new Map();

    eventBridge.on("crate_opened", (player, crateType, tierName) => {
      this.onCrateOpen(player);
    });
  }

  onCrateOpen(player) {
    const now = system.currentTick;
    const key = player.id;
    const data = this.streaks.get(key);

    if (data && (now - data.lastCrateTick) <= STREAK_TIMEOUT_TICKS) {
      data.count++;
      data.lastCrateTick = now;
    } else {
      this.streaks.set(key, { count: 1, lastCrateTick: now });
      return;
    }

    // Check streak milestones
    for (const bonus of STREAK_BONUSES) {
      if (data.count === bonus.count) {
        try {
          player.runCommandAsync(`xp ${bonus.xp} @s`);
          player.sendMessage(bonus.msg);
          player.playSound("random.levelup", { volume: 0.5, pitch: 1.3 });
        } catch {}

        // Apply temporary luck boost for streaks 5+
        if (data.count >= 5) {
          const s = StorageManager.forPlayer(player);
          s.set("streak_luck_bonus", data.count >= 10 ? 3 : 1);
          s.set("streak_luck_expires", now + 1200); // 1 minute
        }
        break;
      }
    }

    // Show streak count on actionbar
    if (data.count >= 2 && !STREAK_BONUSES.some(b => b.count === data.count)) {
      try {
        player.runCommandAsync(`titleraw @s actionbar {"rawtext":[{"text":"§eCrate Streak: x${data.count}"}]}`);
      } catch {}
    }
  }

  /** Get streak luck bonus for a player (used by crate systems) */
  getStreakBonus(player) {
    const s = StorageManager.forPlayer(player);
    const expires = s.getNumber("streak_luck_expires");
    if (expires > 0 && system.currentTick < expires) {
      return s.getNumber("streak_luck_bonus") || 0;
    }
    return 0;
  }

  tick() {
    // Cleanup expired streaks every 30 seconds
    const now = system.currentTick;
    if (now % 600 !== 0) return;
    for (const [key, data] of this.streaks) {
      if (now - data.lastCrateTick > STREAK_TIMEOUT_TICKS) {
        this.streaks.delete(key);
      }
    }
  }
}
