/**
 * Harvest Crate System — Crop harvesting rewards.
 * Replaces Java harvest/ folder (25 files).
 * Detects crop block breaks and grants bonus loot.
 */
import { world, system } from "@minecraft/server";
import { StorageManager } from "../utils/storage.js";

const CROP_BLOCKS = [
  "minecraft:wheat", "minecraft:carrots", "minecraft:potatoes",
  "minecraft:beetroot", "minecraft:melon_block", "minecraft:pumpkin",
  "minecraft:cocoa", "minecraft:nether_wart", "minecraft:sweet_berry_bush",
  "minecraft:cave_vines", "minecraft:cave_vines_body_with_berries",
  "minecraft:cave_vines_head_with_berries",
];

const HARVEST_TIERS = [
  { name: "Common", chance: 0.10, loot: "artifacts/common/main", color: "§f" },
  { name: "Uncommon", chance: 0.04, loot: "artifacts/uncommon/main", color: "§e" },
  { name: "Rare", chance: 0.015, loot: "artifacts/rare/main", color: "§b" },
  { name: "Ornate", chance: 0.005, loot: "artifacts/ornate/main", color: "§5" },
];

export class HarvestCrateSystem {
  constructor(eventBridge) {
    this.eventBridge = eventBridge;
    world.afterEvents.playerBreakBlock.subscribe((event) => {
      const blockType = event.brokenBlockPermutation?.type?.id;
      if (blockType && CROP_BLOCKS.includes(blockType)) {
        this.onHarvest(event.player, event.block);
      }
    });
  }

  onHarvest(player, block) {
    if (!player) return;
    const s = StorageManager.forPlayer(player);

    const harvestCount = s.getNumber("crops_harvested") + 1;
    s.set("crops_harvested", harvestCount);

    const dreamRate = s.getNumber("dream_rate") || 0;
    const drMultiplier = 1 + dreamRate * 0.01;

    for (const tier of HARVEST_TIERS) {
      if (Math.random() < tier.chance * drMultiplier) {
        const loc = block.location || player.location;
        try {
          player.dimension.runCommandAsync(
            `loot spawn ${loc.x} ${loc.y + 1} ${loc.z} loot "${tier.loot}"`
          );
        } catch {}
        player.sendMessage(`${tier.color}§l✦ Harvest Crate: §r${tier.color}${tier.name}§r§7!`);
        player.playSound("random.orb");
        // Track crate stats
        const cs = StorageManager.forPlayer(player);
        cs.set("crates_harvest", cs.getNumber("crates_harvest") + 1);
        cs.set("crates_opened", cs.getNumber("crates_opened") + 1);
        this.eventBridge.emit("crate_opened", player, "harvest", tier.name);
        return;
      }
    }
  }
}
