/**
 * Mob Manager System — Enhanced vanilla mobs with Patron (6-tier) and Furia (3-tier) elites.
 * DR-scaled equipment. Per-type configuration.
 * Mythical gear proximity → mob buff scaling.
 * Replaces Java mobs/ folder (200+ files).
 */
import { world, system } from "@minecraft/server";
import { StorageManager } from "../utils/storage.js";

// Patron rarity tiers (6 tiers, weights sum to 100)
const PATRON_TIERS = [
  { id: 0, name: "Common", weight: 50, color: "§7", symbol: "✣",
    hpMult: 1.5, armor: 2, speedMult: 0.15, dmgMult: 1.7, kbResist: 0 },
  { id: 1, name: "Uncommon", weight: 30, color: "§9", symbol: "✣",
    hpMult: 2.0, armor: 4, speedMult: 0.25, dmgMult: 2.0, kbResist: 0 },
  { id: 2, name: "Rare", weight: 12, color: "§b", symbol: "✲",
    hpMult: 2.5, armor: 6, speedMult: 0.35, dmgMult: 2.5, kbResist: 0.3 },
  { id: 3, name: "Ornate", weight: 5, color: "§5", symbol: "✦",
    hpMult: 3.0, armor: 8, speedMult: 0.5, dmgMult: 3.0, kbResist: 0.5 },
  { id: 4, name: "Exquisite", weight: 2, color: "§d", symbol: "☆",
    hpMult: 3.5, armor: 10, speedMult: 0.65, dmgMult: 3.5, kbResist: 0.7 },
  { id: 5, name: "Mythical", weight: 1, color: "§6", symbol: "☄",
    hpMult: 10.5, armor: 20, speedMult: 0.8, dmgMult: 4.0, kbResist: 1.0 },
];

// Furia tiers (3 tiers)
const FURIA_TIERS = [
  { id: 0, name: "Minor", weight: 60, color: "§8", hpMult: 1.2, dmgMult: 1.1 },
  { id: 1, name: "Standard", weight: 30, color: "§3", hpMult: 1.5, dmgMult: 1.3 },
  { id: 2, name: "Greater", weight: 10, color: "§4", hpMult: 2.0, dmgMult: 1.6 },
];

// Eligible mob types for patron/furia conversion
const PATRON_ELIGIBLE = new Set([
  "minecraft:zombie", "minecraft:skeleton", "minecraft:creeper", "minecraft:spider",
  "minecraft:cave_spider", "minecraft:enderman", "minecraft:witch",
  "minecraft:pillager", "minecraft:vindicator", "minecraft:evoker",
  "minecraft:blaze", "minecraft:wither_skeleton", "minecraft:piglin",
  "minecraft:piglin_brute", "minecraft:hoglin", "minecraft:zoglin",
  "minecraft:drowned", "minecraft:husk", "minecraft:stray",
  "minecraft:phantom", "minecraft:guardian", "minecraft:ravager",
  "minecraft:vex", "minecraft:bogged",
]);

// Mythical gear proximity scaling — mob-type-specific buffs when near mythical-geared players
const MYTHICAL_GEAR_RANGE = 48; // blocks
const MYTHICAL_MOB_BUFFS = {
  "minecraft:creeper": { effect: "blast_radius", mult: 1.5, msg: "§c⚡ Charged by mythical energy!" },
  "minecraft:skeleton": { effect: "arrows", arrowType: "slowness", msg: "§b❄ Frost-tipped arrows!" },
  "minecraft:stray": { effect: "arrows", arrowType: "slowness", msg: "§b❄ Enhanced frost arrows!" },
  "minecraft:spider": { effect: "speed", amplifier: 2, msg: "§a⚡ Mythical agility!" },
  "minecraft:cave_spider": { effect: "poison_boost", amplifier: 1, msg: "§2☠ Enhanced venom!" },
  "minecraft:zombie": { effect: "strength", amplifier: 1, msg: "§4💪 Mythical strength!" },
  "minecraft:husk": { effect: "strength", amplifier: 1, msg: "§4💪 Mythical strength!" },
  "minecraft:drowned": { effect: "strength", amplifier: 1, msg: "§4💪 Mythical strength!" },
  "minecraft:enderman": { effect: "speed", amplifier: 1, msg: "§5⚡ Phase shift!" },
  "minecraft:witch": { effect: "resistance", amplifier: 1, msg: "§d🛡 Arcane barrier!" },
};

// First and last name pools for patrons
const FIRST_NAMES = [
  "Ancient", "Blight", "Crimson", "Dark", "Elder", "Fell", "Grim",
  "Hollow", "Iron", "Jade", "Keen", "Lurking", "Malice", "Night",
  "Obsidian", "Pale", "Quiet", "Raging", "Shadow", "Twisted",
  "Umbral", "Vile", "Wicked", "Xeric", "Yawning", "Zealous",
  "Ashen", "Bleak", "Cursed", "Dread", "Ember", "Frozen",
];
const LAST_NAMES = [
  "Bane", "Claw", "Doom", "Edge", "Fang", "Gore", "Howl",
  "Ire", "Jaw", "Knell", "Lurker", "Maw", "Nail", "Omen",
  "Prowl", "Quake", "Rend", "Scar", "Thorn", "Under",
  "Venom", "Wrath", "Xeno", "Yoke", "Zeal",
  "Bone", "Chain", "Dirge", "Echo", "Fury", "Gloom",
];

const PATRON_SPAWN_CHANCE = 0.075;
const FURIA_SPAWN_CHANCE = 0.30;
const PATRON_COOLDOWN = 6000;
const FURIA_COOLDOWN = 3000;

export class MobManagerSystem {
  constructor(eventBridge) {
    this.eventBridge = eventBridge;
    this.lastPatronSpawn = 0;
    this.lastFuriaSpawn = 0;
    this.processedCount = 0;
    this.lastMythicalScanTick = 0;

    // Listen for entity spawns
    world.afterEvents.entitySpawn.subscribe((event) => {
      const entity = event.entity;
      if (!entity?.isValid()) return;
      if (entity.hasTag("ec.mob_processed")) return;
      entity.addTag("ec.mob_queued");
    });

    // Listen for patron kills
    world.afterEvents.entityDie.subscribe((event) => {
      const entity = event.deadEntity;
      if (!entity) return;
      if (entity.hasTag("ec.patron")) {
        this.onPatronKill(entity, event.damageSource);
      }
    });
  }

  /** Tick — runs every 20 ticks (1 second). */
  tick(players) {
    const now = system.currentTick;

    // OPT: Process queued mobs near active players only (not all 3 dimensions)
    // This avoids querying empty dimensions and limits scan radius
    let processed = 0;
    for (const player of players) {
      if (processed >= 10) break;
      try {
        const queued = player.dimension.getEntities({
          tags: ["ec.mob_queued"],
          location: player.location,
          maxDistance: 128,
        });
        for (const mob of queued) {
          if (processed >= 10) break;
          if (mob.hasTag("ec.mob_processed")) continue;
          this.processMob(mob, now, players);
          processed++;
        }
      } catch {}
    }

    // Mythical gear proximity scan every 5 seconds
    if (now - this.lastMythicalScanTick >= 100) {
      this.lastMythicalScanTick = now;
      this.tickMythicalGearScaling(players);
    }
  }

  /** Process a single mob — apply settings, check for elite conversion. */
  processMob(mob, now, players) {
    if (!mob?.isValid()) return;
    mob.removeTag("ec.mob_queued");
    mob.addTag("ec.mob_processed");

    const typeId = mob.typeId;
    if (!PATRON_ELIGIBLE.has(typeId)) return;

    // Try patron conversion
    if (now - this.lastPatronSpawn >= PATRON_COOLDOWN) {
      if (Math.random() < PATRON_SPAWN_CHANCE) {
        this.convertToPatron(mob);
        this.lastPatronSpawn = now;
        return;
      }
    }

    // Try furia conversion
    if (now - this.lastFuriaSpawn >= FURIA_COOLDOWN) {
      if (Math.random() < FURIA_SPAWN_CHANCE) {
        this.convertToFuria(mob);
        this.lastFuriaSpawn = now;
        return;
      }
    }
  }

  /** Convert a mob to a Patron elite. */
  convertToPatron(mob) {
    const tier = this.rollWeighted(PATRON_TIERS);
    mob.addTag("ec.patron");
    mob.addTag(`ec.patron_${tier.id}`);

    const firstName = FIRST_NAMES[Math.floor(Math.random() * FIRST_NAMES.length)];
    const lastName = LAST_NAMES[Math.floor(Math.random() * LAST_NAMES.length)];
    mob.nameTag = `${tier.color}${tier.symbol} ${firstName} ${lastName}`;

    const health = mob.getComponent("minecraft:health");
    if (health) {
      try {
        const maxHP = Math.floor(health.defaultValue * tier.hpMult);
        health.setCurrentValue(maxHP);
      } catch {}
    }

    try { mob.addEffect("glowing", 999999, { amplifier: 0, showParticles: false }); } catch {}

    if (tier.id === 5) {
      for (const p of world.getAllPlayers()) {
        p.sendMessage(`§6§l☄ A Mythical Patron has appeared! §r§7${firstName} ${lastName}`);
        try { p.playSound("mob.wither.spawn", { volume: 0.3, pitch: 1.5 }); } catch {}
      }
    }

    try {
      const pos = mob.location;
      mob.dimension.runCommandAsync(
        `particle minecraft:endRod ${pos.x} ${pos.y + 1} ${pos.z} 0.3 0.5 0.3 0 10`
      );
    } catch {}
  }

  /** Convert a mob to a Furia scaled mob. */
  convertToFuria(mob) {
    const tier = this.rollWeighted(FURIA_TIERS);
    mob.addTag("ec.furia");
    mob.addTag(`ec.furia_${tier.id}`);
    mob.nameTag = `${tier.color}${mob.typeId.replace("minecraft:", "")}`;

    const health = mob.getComponent("minecraft:health");
    if (health) {
      try {
        const maxHP = Math.floor(health.defaultValue * tier.hpMult);
        health.setCurrentValue(maxHP);
      } catch {}
    }
  }

  /** Roll a weighted random tier. */
  rollWeighted(tiers) {
    const roll = Math.random() * 100;
    let cumulative = 0;
    for (const tier of tiers) {
      cumulative += tier.weight;
      if (roll < cumulative) return tier;
    }
    return tiers[0];
  }

  // ─── MYTHICAL GEAR PROXIMITY SCALING ──────────────────────────

  /**
   * When a player wears mythical gear, nearby mobs get type-specific buffs.
   * Creepers: larger blast. Skeletons: slowness arrows. Spiders: speed. etc.
   */
  tickMythicalGearScaling(players) {
    for (const player of players) {
      const mythicalCount = this.countMythicalGear(player);
      if (mythicalCount === 0) continue;

      // Find nearby hostile mobs
      try {
        const dim = player.dimension;
        const nearbyMobs = dim.getEntities({
          location: player.location,
          maxDistance: MYTHICAL_GEAR_RANGE,
          excludeTypes: ["minecraft:player"],
          tags: ["ec.mob_processed", "!ec.mythical_buffed"],
        });

        for (const mob of nearbyMobs) {
          if (!mob?.isValid()) continue;
          const buff = MYTHICAL_MOB_BUFFS[mob.typeId];
          if (!buff) continue;

          // Apply the buff
          mob.addTag("ec.mythical_buffed");

          if (buff.effect === "strength" || buff.effect === "speed" || buff.effect === "resistance") {
            try {
              mob.addEffect(buff.effect, 120, { amplifier: buff.amplifier, showParticles: true });
            } catch {}
          }
          if (buff.effect === "blast_radius" && mob.typeId === "minecraft:creeper") {
            // Mark creeper for larger blast (handled via tag check on explosion event)
            mob.addTag("ec.mythical_blast");
          }
          if (buff.effect === "arrows") {
            // Mark skeleton for special arrow type
            mob.addTag(`ec.mythical_arrows_${buff.arrowType}`);
          }
          if (buff.effect === "poison_boost") {
            try {
              mob.addEffect("strength", 120, { amplifier: 0, showParticles: true });
            } catch {}
          }
        }
      } catch {}
    }
  }

  /** Count how many mythical-tier items a player has equipped */
  countMythicalGear(player) {
    let count = 0;
    try {
      const equip = player.getComponent("minecraft:equippable");
      if (!equip) return 0;
      for (const slot of ["Head", "Chest", "Legs", "Feet", "Mainhand", "Offhand"]) {
        const item = equip.getEquipment(slot);
        if (!item) continue;
        // Check for mythical tag or typeId
        const tags = item.getTags?.() || [];
        if (tags.some(t => t.includes("mythical")) || item.typeId?.includes("mythical")) {
          count++;
        }
      }
    } catch {}
    return count;
  }

  /** Handle patron kill — track achievement, emit event. */
  onPatronKill(patron, damageSource) {
    const killer = damageSource?.damagingEntity;
    if (!killer || killer.typeId !== "minecraft:player") return;

    const storage = StorageManager.forPlayer(killer);
    storage.increment("patron_kills", 1);

    let tierName = "Common";
    for (const tier of PATRON_TIERS) {
      if (patron.hasTag(`ec.patron_${tier.id}`)) {
        tierName = tier.name;
        break;
      }
    }

    killer.sendMessage(`§6§lPatron Slain! §r§7(${tierName})`);
    this.eventBridge.emit("patron_killed", killer, tierName);
    try { killer.playSound("random.levelup", { volume: 0.3, pitch: 1.5 }); } catch {}
  }
}
