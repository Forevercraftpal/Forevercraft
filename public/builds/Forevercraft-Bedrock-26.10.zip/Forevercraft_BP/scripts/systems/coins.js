/**
 * Coins System — Forever Coins premium currency.
 * Replaces Java coins/ folder (10 files).
 * Coins earned from boss kills, bounties, dungeons, constellations, mob drops, pet milestones.
 * Spent on gacha/Dreamdust exchanges and friend gifts.
 */
import { world, system } from "@minecraft/server";
import { StorageManager } from "../utils/storage.js";

// Coin earning amounts by source
const BOSS_REWARDS = {
  overworld: 15,  // Boss IDs 1-7
  nether: 20,     // Boss IDs 8-10
  ender: 25,      // Boss ID 11 (Ender Dragon)
};

const VANILLA_BOSS_REWARDS = {
  ender_dragon: 25,
  warden: 5,
  wither: 3,
};

const BOUNTY_REWARDS = {
  2: 1,  // Contract
  3: 2,  // Commission
  4: 3,  // Expedition
  5: 4,  // Heroic
};

const DUNGEON_REWARDS = {
  normal: 2,
  hard: 4,
  brutal: 6,
};

const QUEST_REWARDS = { 1: 1, 2: 2, 3: 3, 4: 4, 5: 5, 6: 6 };

const PET_MILESTONE_REWARDS = {
  25: 1,
  50: 2,
  75: 3,
  100: 5,
};

const PET_MILESTONE_GUILD_CONTRIB = {
  25: 5,
  50: 10,
  75: 15,
  100: 25,
};

const CONSTELLATION_REWARD = 10;
const MOB_DROP_CHANCE = 1 / 2500;
const PATRON_DROP_CHANCE = 1 / 500;
const REGION_COMPLETION_REWARD = 5;

export class CoinSystem {
  constructor(eventBridge) {
    this.eventBridge = eventBridge;

    // Listen for coin-earning events
    eventBridge.on("boss_killed", (player, bossId) => this.onBossKill(player, bossId));
    eventBridge.on("vanilla_boss_kill", (player, bossType) => this.onVanillaBossKill(player, bossType));
    eventBridge.on("bounty_completed", (player, tier) => this.onBountyComplete(player, tier));
    eventBridge.on("dungeon_complete", (player, difficulty) => this.onDungeonComplete(player, difficulty));
    eventBridge.on("constellation_complete", (player) => this.onConstellationComplete(player));
    eventBridge.on("quest_complete", (player, tier) => this.onQuestComplete(player, tier));
    eventBridge.on("pet_milestone", (player, level) => this.onPetMilestone(player, level));
    eventBridge.on("region_complete", (player) => this.onRegionComplete(player));
    eventBridge.on("player_killed_entity", (data) => this.onMobKilled(data.player, data.entityTypeId));
    eventBridge.on("patron_killed", (player) => this.onPatronKilled(player));

    // Coin item pickup detection
    eventBridge.on("item_pickup", (player, item) => {
      if (item?.typeId === "forevercraft:forever_coin" || item?.getTags?.()?.some(t => t.includes("forever_coin"))) {
        this.pickupCoin(player, item.amount || 1);
      }
    });
  }

  /** Get player's coin balance */
  getBalance(player) {
    return StorageManager.forPlayer(player).getNumber("coins", 0);
  }

  /** Add coins to player */
  addCoins(player, amount, source) {
    const s = StorageManager.forPlayer(player);
    const current = s.getNumber("coins", 0);
    s.set("coins", current + amount);

    // Lifetime tracking
    const totalEarned = s.getNumber("coins_earned_total", 0);
    s.setNumber("coins_earned_total", totalEarned + amount);

    // First coin check
    if (current === 0 && amount > 0) {
      s.setNumber("first_coin", 1);
      player.sendMessage("§d§l★ First Forever Coin! §r§7The Fountain of Eternal Dreams awaits...");
    }

    player.sendMessage(`§d§l★ §r§d+${amount} Forever Coin${amount > 1 ? "s" : ""} §7(${source})`);
    try { player.playSound("random.orb", { volume: 0.5, pitch: 1.2 }); } catch {}

    // Guild contribution bonus (5x coins as guild contrib)
    this.addGuildContribution(player, amount * 5);
  }

  /** Remove coins from player. Returns true if successful. */
  removeCoins(player, amount) {
    const s = StorageManager.forPlayer(player);
    const current = s.getNumber("coins", 0);
    if (current < amount) return false;
    s.set("coins", current - amount);
    return true;
  }

  /** Add guild contribution if player is in a guild */
  addGuildContribution(player, amount) {
    const s = StorageManager.forPlayer(player);
    const guildId = s.getNumber("guild_id", 0);
    if (guildId > 0) {
      this.eventBridge.emit("guild_contribution", player, amount);
    }
  }

  // ─── EARNING SOURCES ──────────────────────────────────────

  onBossKill(player, bossId) {
    let amount;
    if (bossId >= 1 && bossId <= 7) amount = BOSS_REWARDS.overworld;
    else if (bossId >= 8 && bossId <= 10) amount = BOSS_REWARDS.nether;
    else if (bossId === 11) amount = BOSS_REWARDS.ender;
    else amount = 15;
    this.addCoins(player, amount, "Boss Kill");
  }

  onVanillaBossKill(player, bossType) {
    const amount = VANILLA_BOSS_REWARDS[bossType] || 3;
    this.addCoins(player, amount, `${bossType.replace("_", " ")} defeated`);
  }

  onBountyComplete(player, tier) {
    const amount = BOUNTY_REWARDS[tier] || 1;
    this.addCoins(player, amount, "Bounty Complete");
  }

  onDungeonComplete(player, difficulty) {
    const amount = DUNGEON_REWARDS[difficulty] || 2;
    this.addCoins(player, amount, "Dungeon Clear");
  }

  onConstellationComplete(player) {
    this.addCoins(player, CONSTELLATION_REWARD, "Constellation Complete");
    this.addGuildContribution(player, 50);
    this.eventBridge.emit("guild_xp", player, 200);
  }

  onQuestComplete(player, tier) {
    const amount = QUEST_REWARDS[tier] || 1;
    this.addCoins(player, amount, "Quest Complete");
  }

  onPetMilestone(player, level) {
    const amount = PET_MILESTONE_REWARDS[level];
    if (!amount) return;
    this.addCoins(player, amount, `Pet Level ${level}`);
    const guildContrib = PET_MILESTONE_GUILD_CONTRIB[level] || 5;
    this.addGuildContribution(player, guildContrib);
  }

  onRegionComplete(player) {
    this.addCoins(player, REGION_COMPLETION_REWARD, "Region Complete");
  }

  onMobKilled(player, entity) {
    if (Math.random() < MOB_DROP_CHANCE) {
      this.addCoins(player, 1, "Mob Drop");
      this.addGuildContribution(player, 3);
    }
  }

  onPatronKilled(player) {
    if (Math.random() < PATRON_DROP_CHANCE) {
      this.addCoins(player, 1, "Patron Drop");
      this.addGuildContribution(player, 5);
    }
  }

  pickupCoin(player, amount) {
    this.addCoins(player, amount, "Pickup");
  }

  /** Show coin balance to player */
  showBalance(player) {
    const balance = this.getBalance(player);
    player.sendMessage(`§d§l★ Forever Coins: §r§f${balance}`);
  }
}
