/**
 * Encounters System — Cave biome mini-events with mob spawning and rewards.
 * 3 types: Bloom Surge (Lush), Crystalline Tremor (Dripstone), Void Whisper (Deep Dark).
 * Replaces Java encounters/ folder.
 */
import { world, system } from "@minecraft/server";
import { StorageManager } from "../utils/storage.js";

// Encounter definitions
const ENCOUNTERS = {
  lush: {
    id: 1, name: "Bloom Surge", biomeId: 15,
    color: "§a", duration: 6, // 6 × 10s = 60s
    mobs: [
      { type: "minecraft:zombie", count: 3 },
      { type: "minecraft:spider", count: 1 },
    ],
    replenishMin: 3,
    reward: "uncommon",
    announce: "§aThe cavern stirs... a §l§2Bloom Surge §r§aerupts around you!",
  },
  dripstone: {
    id: 2, name: "Crystalline Tremor", biomeId: 16,
    color: "§e", duration: 6,
    mobs: [
      { type: "minecraft:cave_spider", count: 4 },
    ],
    replenishMin: 4,
    reward: "rare",
    announce: "§eThe stone cracks... a §l§6Crystalline Tremor §r§eshakes the cavern!",
  },
  deep_dark: {
    id: 3, name: "Void Whisper", biomeId: 17,
    color: "§5", duration: 5, // 5 × 10s = 50s
    mobs: [
      { type: "minecraft:phantom", count: 2 },
      { type: "minecraft:skeleton", count: 1 },
    ],
    replenishMin: 3,
    reward: "ornate",
    announce: "§5A chill runs through you... the §l§dVoid Whisper §r§5awakens.",
  },
};

const COOLDOWN_TICKS = 72000; // ~20 min real time
const TRIGGER_CHANCE = 0.0005; // 0.05% per 10s check

export class EncounterSystem {
  constructor(eventBridge, biomeSystem) {
    this.eventBridge = eventBridge;
    this.biomeSystem = biomeSystem;
    this.activeEncounters = new Map(); // playerId → { type, timer, mobs[] }
  }

  /**
   * Tick — runs every 200 ticks (10 seconds).
   */
  tick(players) {
    for (const player of players) {
      if (player.getGameMode() === "creative" || player.getGameMode() === "spectator") continue;

      const enc = this.activeEncounters.get(player.id);
      if (enc) {
        this.tickActive(player, enc);
      } else {
        this.tryTrigger(player);
      }
    }
  }

  /**
   * Try to trigger an encounter for a player.
   */
  tryTrigger(player) {
    const storage = StorageManager.forPlayer(player);
    const biomeId = this.biomeSystem?.getBiomeId(player) ?? -1;

    // Must be in a cave biome
    let encDef = null;
    for (const key in ENCOUNTERS) {
      if (ENCOUNTERS[key].biomeId === biomeId) {
        encDef = ENCOUNTERS[key];
        break;
      }
    }
    if (!encDef) return;

    // Cooldown check
    const lastEncounter = storage.getNumber("ube_cd", 0);
    const now = system.currentTick;
    if (now - lastEncounter < COOLDOWN_TICKS) return;

    // Random roll
    if (Math.random() > TRIGGER_CHANCE) return;

    // Start encounter
    this.startEncounter(player, encDef);
  }

  /**
   * Start an encounter.
   */
  startEncounter(player, encDef) {
    player.sendMessage(encDef.announce);

    const mobEntities = [];
    const pos = player.location;
    const dim = player.dimension;

    // Spawn mobs
    for (const mobDef of encDef.mobs) {
      for (let i = 0; i < mobDef.count; i++) {
        const ox = (Math.random() - 0.5) * 8;
        const oz = (Math.random() - 0.5) * 8;
        try {
          const mob = dim.spawnEntity(mobDef.type, {
            x: pos.x + ox,
            y: pos.y,
            z: pos.z + oz,
          });
          mob.addTag("ec.encounter_mob");
          mob.addTag(`ec.enc_${encDef.id}`);
          mobEntities.push(mob.id);
        } catch {}
      }
    }

    this.activeEncounters.set(player.id, {
      type: encDef,
      timer: encDef.duration,
      mobs: mobEntities,
    });

    try {
      player.playSound("mob.wither.spawn", { volume: 0.3, pitch: 1.5 });
    } catch {}
  }

  /**
   * Tick an active encounter.
   */
  tickActive(player, enc) {
    enc.timer--;

    // Apply biome-specific effects
    if (enc.type.id === 3) {
      // Deep Dark: debuffs
      try {
        player.addEffect("slowness", 300, { amplifier: 1, showParticles: false });
        player.addEffect("weakness", 300, { amplifier: 0, showParticles: false });
        player.addEffect("darkness", 300, { amplifier: 0, showParticles: false });
      } catch {}
    }

    // Replenish mobs
    this.replenishMobs(player, enc);

    // Ambient effects
    this.playAmbient(player, enc.type);

    // Check completion
    if (enc.timer <= 0) {
      this.completeEncounter(player, enc);
    }
  }

  /**
   * Replenish encounter mobs if count is low.
   */
  replenishMobs(player, enc) {
    const dim = player.dimension;
    const pos = player.location;

    // Count alive encounter mobs nearby
    try {
      const nearby = dim.getEntities({
        location: pos,
        maxDistance: 32,
        tags: [`ec.enc_${enc.type.id}`],
      });

      const alive = nearby.length;
      if (alive < enc.type.replenishMin) {
        const toSpawn = enc.type.replenishMin - alive;
        for (let i = 0; i < toSpawn; i++) {
          const ox = (Math.random() - 0.5) * 10;
          const oz = (Math.random() - 0.5) * 10;
          const mobDef = enc.type.mobs[Math.floor(Math.random() * enc.type.mobs.length)];
          try {
            const mob = dim.spawnEntity(mobDef.type, {
              x: pos.x + ox, y: pos.y, z: pos.z + oz,
            });
            mob.addTag("ec.encounter_mob");
            mob.addTag(`ec.enc_${enc.type.id}`);
          } catch {}
        }
      }
    } catch {}
  }

  /**
   * Play ambient effects based on encounter type.
   */
  playAmbient(player, encType) {
    const pos = player.location;
    const dim = player.dimension;
    try {
      if (encType.id === 1) {
        dim.runCommandAsync(
          `particle minecraft:villager_happy ${pos.x} ${pos.y + 1} ${pos.z} 3 1 3 0 5`
        );
      } else if (encType.id === 2) {
        dim.runCommandAsync(
          `particle minecraft:lava_particle ${pos.x} ${pos.y + 1} ${pos.z} 3 1 3 0 3`
        );
      } else if (encType.id === 3) {
        dim.runCommandAsync(
          `particle minecraft:sculk_soul ${pos.x} ${pos.y + 1} ${pos.z} 3 1 3 0 3`
        );
        player.playSound("mob.warden.heartbeat", { volume: 0.2, pitch: 1.0 });
      }
    } catch {}
  }

  /**
   * Complete an encounter — kill mobs, give rewards.
   */
  completeEncounter(player, enc) {
    const dim = player.dimension;
    const pos = player.location;

    // Kill encounter mobs
    try {
      const mobs = dim.getEntities({
        location: pos,
        maxDistance: 48,
        tags: [`ec.enc_${enc.type.id}`],
      });
      for (const mob of mobs) {
        try { mob.kill(); } catch {}
      }
    } catch {}

    // Clear debuffs (Deep Dark)
    if (enc.type.id === 3) {
      try {
        player.removeEffect("slowness");
        player.removeEffect("weakness");
        player.removeEffect("darkness");
      } catch {}
    }

    // Give reward
    const rewardTier = enc.type.reward;
    player.sendMessage(`${enc.type.color}§l${enc.type.name} §r§7complete! §eReward: §6${rewardTier} mob crate`);

    this.eventBridge.emit("encounter_reward", player, rewardTier);
    this.eventBridge.emit("crate_give", player, rewardTier);

    // Track stats
    const storage = StorageManager.forPlayer(player);
    storage.increment("encounters_done", 1);
    storage.set("ube_cd", system.currentTick);

    this.activeEncounters.delete(player.id);

    try {
      player.playSound("random.levelup", { volume: 0.6, pitch: 1.2 });
    } catch {}
  }
}
