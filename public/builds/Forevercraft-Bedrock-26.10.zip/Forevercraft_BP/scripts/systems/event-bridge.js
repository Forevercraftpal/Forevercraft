import { world } from "@minecraft/server";

export class EventBridge {
  constructor() {
    this.handlers = new Map();
  }

  on(event, handler) {
    if (!this.handlers.has(event)) this.handlers.set(event, []);
    this.handlers.get(event).push(handler);
  }

  emit(event, ...args) {
    const handlers = this.handlers.get(event);
    if (!handlers || handlers.length === 0) return; // OPT: skip if no listeners
    for (const handler of handlers) {
      try { handler(...args); } catch (e) { console.error(`[EventBridge] Error in '${event}':`, e); }
    }
  }

  registerAll() {
    // Entity Death — STANDARDIZED: emits data object
    world.afterEvents.entityDie.subscribe((event) => {
      const { deadEntity, damageSource } = event;
      const killer = damageSource?.damagingEntity;
      if (killer?.typeId === "minecraft:player") {
        // All listeners receive { player, entity, damageSource, entityTypeId }
        this.emit("player_killed_entity", {
          player: killer,
          entity: deadEntity,
          entityTypeId: deadEntity.typeId,
          damageSource,
        });
        this.emit(`killed:${deadEntity.typeId}`, { player: killer, entity: deadEntity });
      }
      this.emit("entity_died", { entity: deadEntity, damageSource });
      if (deadEntity.typeId === "minecraft:player") {
        this.emit("player_died", { player: deadEntity, damageSource });
      }
    });

    // Entity Hurt — STANDARDIZED: emits data object
    world.afterEvents.entityHurt.subscribe((event) => {
      const { hurtEntity, damageSource, damage } = event;
      if (hurtEntity.typeId === "minecraft:player") {
        this.emit("player_hurt", { player: hurtEntity, damage, damageSource });
      }
      const attacker = damageSource?.damagingEntity;
      if (attacker?.typeId === "minecraft:player") {
        this.emit("player_dealt_damage", {
          player: attacker,
          target: hurtEntity,
          damage,
          damageSource,
        });
      }
    });

    // Player Spawn — STANDARDIZED: emits data object
    // NOTE: Do NOT emit player_first_join here — main.js handles it
    // to prevent double-fire (Bug #24)
    world.afterEvents.playerSpawn.subscribe((event) => {
      const { player, initialSpawn } = event;
      if (!initialSpawn) {
        this.emit("player_respawn", { player });
      }
      this.emit("player_spawn", { player, initialSpawn });
    });

    // Player Leave
    world.afterEvents.playerLeave.subscribe((event) => {
      this.emit("player_leave", { playerId: event.playerId, playerName: event.playerName });
    });

    // Block Break — STANDARDIZED: emits data object
    world.afterEvents.playerBreakBlock.subscribe((event) => {
      const { player, brokenBlockPermutation, block } = event;
      const blockId = brokenBlockPermutation?.type?.id;
      if (!blockId) return;
      this.emit("block_break", { player, blockId, location: block?.location });
      if (["minecraft:wheat","minecraft:carrots","minecraft:potatoes","minecraft:beetroot","minecraft:nether_wart"].includes(blockId)) {
        this.emit("crop_harvested", { player, blockId, location: block?.location });
      }
      this.emit(`mined:${blockId}`, { player, location: block?.location });
    });

    // Block Place — STANDARDIZED: emits data object
    world.afterEvents.playerPlaceBlock.subscribe((event) => {
      const { player, block } = event;
      this.emit("block_place", { player, blockId: block?.typeId, location: block?.location });
    });

    // Item Use — STANDARDIZED: emits data object
    world.afterEvents.itemUse.subscribe((event) => {
      const { source, itemStack } = event;
      if (source?.typeId === "minecraft:player") {
        this.emit("item_use", { player: source, item: itemStack });
        this.emit(`used:${itemStack?.typeId}`, { player: source, item: itemStack });
      }
    });

    // Item Use On Block
    world.afterEvents.itemUseOn.subscribe((event) => {
      const { source, itemStack, block } = event;
      if (source?.typeId === "minecraft:player") {
        this.emit("item_use_on", { player: source, item: itemStack, block });
      }
    });

    // Item Complete Use (consume)
    world.afterEvents.itemCompleteUse.subscribe((event) => {
      const { source, itemStack } = event;
      if (source?.typeId === "minecraft:player") {
        this.emit("item_consumed", { player: source, item: itemStack });
      }
    });

    // Projectile Hit
    world.afterEvents.projectileHitEntity?.subscribe?.((event) => {
      const { projectile, source, getEntityHit } = event;
      if (source?.typeId === "minecraft:player") {
        try {
          const hitInfo = getEntityHit();
          if (hitInfo?.entity) {
            this.emit("projectile_hit", { player: source, target: hitInfo.entity, projectile });
          }
        } catch {}
      }
    });

    console.log("[EventBridge] All event subscriptions registered.");
  }

  handleInteraction(entity) {
    const tags = entity.getTags?.() || [];
    for (const tag of tags) this.emit(`interact:${tag}`, { entity });
    this.emit("entity_interact", { entity, tags });
  }
}
