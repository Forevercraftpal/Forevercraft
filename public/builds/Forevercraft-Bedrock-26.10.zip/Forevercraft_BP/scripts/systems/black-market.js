/**
 * Black Market System — Dynamic daily trading with barrel merchant.
 * Replaces Java black_market/ folder (100 files).
 * Daily rotating deals, buy/sell mechanics, escrow transactions.
 */
import { world, system } from "@minecraft/server";
import { StorageManager } from "../utils/storage.js";
import { ActionFormData } from "@minecraft/server-ui";

// Pool of items that can appear as deals
const DEAL_POOL = [
  { item: "minecraft:diamond", name: "Diamond", basePrice: 8, tier: "common" },
  { item: "minecraft:emerald", name: "Emerald", basePrice: 4, tier: "common" },
  { item: "minecraft:gold_ingot", name: "Gold Ingot", basePrice: 3, tier: "common" },
  { item: "minecraft:iron_ingot", name: "Iron Ingot", basePrice: 2, tier: "common" },
  { item: "minecraft:netherite_scrap", name: "Netherite Scrap", basePrice: 16, tier: "rare" },
  { item: "minecraft:enchanted_golden_apple", name: "Enchanted Golden Apple", basePrice: 32, tier: "rare" },
  { item: "minecraft:totem_of_undying", name: "Totem of Undying", basePrice: 24, tier: "rare" },
  { item: "minecraft:ender_pearl", name: "Ender Pearl", basePrice: 4, tier: "common" },
  { item: "minecraft:blaze_rod", name: "Blaze Rod", basePrice: 6, tier: "uncommon" },
  { item: "minecraft:ghast_tear", name: "Ghast Tear", basePrice: 8, tier: "uncommon" },
  { item: "minecraft:phantom_membrane", name: "Phantom Membrane", basePrice: 5, tier: "uncommon" },
  { item: "minecraft:shulker_shell", name: "Shulker Shell", basePrice: 12, tier: "rare" },
  { item: "minecraft:nautilus_shell", name: "Nautilus Shell", basePrice: 10, tier: "uncommon" },
  { item: "minecraft:heart_of_the_sea", name: "Heart of the Sea", basePrice: 24, tier: "rare" },
  { item: "minecraft:experience_bottle", name: "Bottle o' Enchanting", basePrice: 3, tier: "common" },
  { item: "minecraft:name_tag", name: "Name Tag", basePrice: 3, tier: "common" }, // 26.10: now craftable, reduced value
  { item: "minecraft:saddle", name: "Saddle", basePrice: 8, tier: "uncommon" },
];

const NUM_DAILY_DEALS = 6;

export class BlackMarketSystem {
  constructor() {
    this.currentDeals = [];
    this.lastDealDay = -1;
  }

  /** Generate daily deals based on world day */
  generateDeals() {
    const day = (globalThis._fc_daylight?.getDay?.() ?? 0);
    if (day === this.lastDealDay) return;
    this.lastDealDay = day;

    this.currentDeals = [];
    const pool = [...DEAL_POOL];

    for (let i = 0; i < Math.min(NUM_DAILY_DEALS, pool.length); i++) {
      const idx = Math.floor(Math.random() * pool.length);
      const deal = pool.splice(idx, 1)[0];
      // Price varies ±30%
      const priceVariation = 0.7 + Math.random() * 0.6;
      this.currentDeals.push({
        ...deal,
        price: Math.max(1, Math.round(deal.basePrice * priceVariation)),
        quantity: 1 + Math.floor(Math.random() * 4),
      });
    }

    console.log(`[BlackMarket] Generated ${this.currentDeals.length} deals for day ${day}`);
  }

  /** Open black market menu */
  openMenu(player) {
    this.generateDeals();

    const form = new ActionFormData()
      .title("§8§lBlack Market")
      .body("§7§oDailings change each day. Buy low, sell high.\n\n§7Today's deals:");

    for (const deal of this.currentDeals) {
      const tierColor = deal.tier === "rare" ? "§b" : deal.tier === "uncommon" ? "§e" : "§f";
      form.button(`${tierColor}${deal.name}\n§7${deal.price} emeralds × ${deal.quantity}`);
    }
    form.button("§eSell Items");

    form.show(player).then(response => {
      if (response.canceled) return;
      if (response.selection === this.currentDeals.length) {
        this.openSellMenu(player);
        return;
      }
      const deal = this.currentDeals[response.selection];
      if (deal) this.confirmPurchase(player, deal);
    });
  }

  confirmPurchase(player, deal) {
    const form = new ActionFormData()
      .title("§8Confirm Purchase")
      .body(`§7Buy §f${deal.quantity}x ${deal.name}§7?\n§7Cost: §f${deal.price * deal.quantity} emeralds`)
      .button("§aConfirm")
      .button("§cCancel");

    form.show(player).then(response => {
      if (response.canceled || response.selection === 1) return;

      const totalCost = deal.price * deal.quantity;
      // Check emerald balance (simplified)
      try {
        player.runCommandAsync(`clear @s emerald 0 ${totalCost}`).then((result) => {
          if (result.successCount > 0) {
            player.runCommandAsync(`clear @s emerald 0 ${totalCost}`);
            player.runCommandAsync(`give @s ${deal.item} ${deal.quantity}`);
            player.sendMessage(`§a§l✦ §r§7Purchased ${deal.quantity}x ${deal.name}!`);
            player.playSound("random.orb");
          } else {
            player.sendMessage("§c§lNot enough emeralds!");
          }
        });
      } catch {
        player.sendMessage("§c§lTransaction failed.");
      }
    });
  }

  openSellMenu(player) {
    const form = new ActionFormData()
      .title("§8Sell Items")
      .body("§7Hold an item and select its sell value.\n§7Sell prices are 40% of buy price.")
      .button("§eSell Held Item")
      .button("§cBack");

    form.show(player).then(response => {
      if (response.canceled || response.selection === 1) return;

      const equip = player.getComponent("minecraft:equippable");
      const mainhand = equip?.getEquipment("Mainhand");
      if (!mainhand) {
        player.sendMessage("§7Hold an item to sell it.");
        return;
      }

      const dealInfo = DEAL_POOL.find(d => d.item === mainhand.typeId);
      if (!dealInfo) {
        player.sendMessage("§c§lThis item cannot be sold here.");
        return;
      }

      const sellPrice = Math.max(1, Math.floor(dealInfo.basePrice * 0.4));
      const count = mainhand.amount || 1;
      const totalEmeralds = sellPrice * count;

      try {
        player.runCommandAsync(`clear @s ${mainhand.typeId} ${count}`);
        player.runCommandAsync(`give @s emerald ${totalEmeralds}`);
        player.sendMessage(`§a§l✦ §r§7Sold ${count}x ${dealInfo.name} for §f${totalEmeralds} emeralds`);
        player.playSound("random.orb");
      } catch {}
    });
  }
}
