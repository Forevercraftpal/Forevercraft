/**
 * Biome Mastery System — Per-biome time tracking with 5 mastery levels.
 * Levels: Visitor → Familiar → Resident → Warden → Master.
 * Grants Dream Rate bonuses at higher levels.
 * Replaces Java biome_mastery/ folder (13 files).
 */
import { world } from "@minecraft/server";
import { StorageManager } from "../utils/storage.js";
import { ActionFormData } from "@minecraft/server-ui";

// Mastery level thresholds (in seconds)
const LEVELS = [
  { seconds: 0, level: 0, name: "", dr: 0 },
  { seconds: 1800, level: 1, name: "Visitor", dr: 0 },      // 0.5 hours
  { seconds: 7200, level: 2, name: "Familiar", dr: 0.1 },   // 2 hours
  { seconds: 21600, level: 3, name: "Resident", dr: 0.1 },   // 6 hours
  { seconds: 54000, level: 4, name: "Warden", dr: 0.35 },    // 15 hours
  { seconds: 108000, level: 5, name: "Master", dr: 0.5 },    // 30 hours
];

// Per-biome Master titles (index by biome ID)
const MASTER_TITLES = [
  "Meadow Keeper", "Forestborn", "Bloomkeeper", "Shadowstrider",
  "Frostpine Warden", "Peakwalker", "Canopy Runner", "Dune Sovereign",
  "Sunwatcher", "Tidecaller", "Riverguard", "Bogstrider",
  "Sporekeeper", "Frostbound", "Mesa Walker", "Verdant Dweller",
  "Stalactite Sage", "Void Warden", "Ashborn", "Crimson Stalker",
  "Warped Walker", "Deltastrider", "Soulbound", "Ender Warden",
  "Stormchaser",
];

const LEVEL_COLORS = ["§f", "§f", "§b", "§3", "§5", "§6"];

export class BiomeMasterySystem {
  constructor(eventBridge, biomeSystem) {
    this.eventBridge = eventBridge;
    this.biomeSystem = biomeSystem;

    // Listen for biome changes to reapply DR
    eventBridge.on("biome_change", (player, newBiome, prevBiome) => {
      this.onBiomeChange(player, newBiome);
    });
  }

  /**
   * Get mastery level from accumulated seconds.
   */
  getLevel(seconds) {
    for (let i = LEVELS.length - 1; i >= 0; i--) {
      if (seconds >= LEVELS[i].seconds) return LEVELS[i];
    }
    return LEVELS[0];
  }

  /**
   * Get time spent in a specific biome (in seconds).
   */
  getBiomeTime(player, biomeId) {
    return StorageManager.forPlayer(player).getNumber(`bm_${biomeId}`, 0);
  }

  /**
   * Called when player changes biome — reapply DR modifier.
   */
  onBiomeChange(player, newBiomeId) {
    const time = this.getBiomeTime(player, newBiomeId);
    const level = this.getLevel(time);

    // Apply DR via luck effect (simplified from attribute modifiers)
    const s = StorageManager.forPlayer(player);
    s.set("bm_current_dr", level.dr);
  }

  /**
   * Tick — runs every 5 seconds (100 ticks).
   * Increments time for current biome, checks for level-ups.
   */
  tick(players) {
    for (const player of players) {
      const gm = player.getGameMode?.() ?? "survival";
      if (gm === "creative" || gm === "spectator") continue;

      const biomeId = this.biomeSystem?.getBiomeId(player) ?? -1;
      if (biomeId < 0 || biomeId > 24) continue;

      const s = StorageManager.forPlayer(player);
      const key = `bm_${biomeId}`;
      const prevTime = s.getNumber(key, 0);
      const newTime = prevTime + 5; // Add 5 seconds (tick interval)
      s.set(key, newTime);

      // Check for level-up
      const prevLevel = this.getLevel(prevTime);
      const newLevel = this.getLevel(newTime);

      if (newLevel.level > prevLevel.level) {
        this.onLevelUp(player, biomeId, newLevel);
      }

      // Update current DR
      s.set("bm_current_dr", newLevel.dr);
    }
  }

  /**
   * Handle level-up notification.
   */
  onLevelUp(player, biomeId, level) {
    const biomeName = this.biomeSystem?.getBiomeName(biomeId) ?? "Unknown";
    const color = LEVEL_COLORS[level.level] || "§f";

    player.sendMessage(`§7[Biome Mastery] ${color}${biomeName} §7— Level ${level.level}: §f${level.name}`);

    if (level.dr > 0) {
      player.sendMessage(`  §7Dream Rate: §a+${level.dr}`);
    }

    // Master title
    if (level.level === 5) {
      const title = MASTER_TITLES[biomeId] || "Master";
      player.sendMessage(`  §6Title earned: §e${title}`);

      // Announce to all players
      const players = world.getAllPlayers();
      for (const p of players) {
        if (p.id !== player.id) {
          p.sendMessage(`§6${player.name} §7earned the title §e${title} §7(${biomeName} Master)!`);
        }
      }
    }

    try {
      player.playSound("random.levelup", { volume: 0.5, pitch: 1.2 });
    } catch {}
  }

  /**
   * Get total mastery levels across all biomes.
   */
  getTotalLevels(player) {
    let total = 0;
    for (let i = 0; i <= 24; i++) {
      const time = this.getBiomeTime(player, i);
      total += this.getLevel(time).level;
    }
    return total;
  }

  /**
   * Open mastery display menu.
   */
  openMenu(player) {
    let body = "§6§lBiome Mastery\n\n";
    let explored = 0;

    for (let i = 0; i <= 24; i++) {
      const time = this.getBiomeTime(player, i);
      if (time <= 0) continue;
      explored++;

      const level = this.getLevel(time);
      const biomeName = this.biomeSystem?.getBiomeName(i) ?? `Biome ${i}`;
      const hours = Math.floor(time / 3600);
      const color = LEVEL_COLORS[level.level] || "§f";

      if (level.level === 0) {
        body += `§8· §7${biomeName} — ${hours}h\n`;
      } else {
        body += `${color}★ §7${biomeName} — ${hours}h §f(${level.name})\n`;
      }
    }

    if (explored === 0) {
      body += "§8No biomes explored yet!\n";
    }

    body += `\n§7Total biomes explored: §f${explored}/25`;

    const form = new ActionFormData()
      .title("§6⊕ Biome Mastery")
      .body(body)
      .button("§7Close");

    form.show(player).then(() => {});
  }
}
