/**
 * Bounty Board — Daily artifact bounties at quest lecterns.
 * Replaces Java bounty_board/ folder (26 mcfunction files).
 *
 * 3 bounty slots per day, rotated daily. Artifact claim tracking per player.
 * Attached to quest board lecterns.
 */
import { world, system } from "@minecraft/server";
import { StorageManager } from "../utils/storage.js";
import { ActionFormData } from "@minecraft/server-ui";

const BOUNTY_POOL = [
  "Bone Slingshot", "Broadsword", "Highland Axe", "Deku Shield", "Scythe",
  "Battle Bow", "Double Axe", "Fantasy Axe", "Chargin' Targe", "Drill",
  "Ember Fishing Rod", "Clockwork Crossbow", "Crystal Shield", "Jade Katana",
  "Obsidian Greatsword", "Prism Bow", "Storm Trident", "Void Dagger",
  "Phoenix Blade", "Frost Hammer", "Thunder Lance", "Shadow Cloak",
  "Radiant Shield", "Venom Fang", "Earth Breaker",
];

const BOUNTY_SLOTS = 3;

export class BountyBoardSystem {
  constructor(eventBridge) {
    this.eventBridge = eventBridge;
    this.dailyBounties = []; // Refreshed daily
    this.lastDay = -1;
  }

  /** Refresh bounties if new day (called from tick) */
  refreshDaily() {
    const day = (globalThis._fc_daylight?.getDay?.() ?? 0);
    if (day === this.lastDay) return;
    this.lastDay = day;

    // Pick 3 random bounties
    const shuffled = [...BOUNTY_POOL].sort(() => Math.random() - 0.5);
    this.dailyBounties = shuffled.slice(0, BOUNTY_SLOTS).map((name, i) => ({
      slot: i,
      name,
      coinReward: 5 + Math.floor(Math.random() * 6), // 5-10 coins
    }));
  }

  /** Open bounty board menu */
  async openBoard(player) {
    this.refreshDaily();

    const s = StorageManager.forPlayer(player);
    const form = new ActionFormData()
      .title("§l§6Bounty Board");

    let body = "§7Daily artifact bounties — claim one per slot!\n\n";
    for (const bounty of this.dailyBounties) {
      const claimed = s.get(`bb_claim_${this.lastDay}_${bounty.slot}`);
      body += claimed
        ? `§8✗ ${bounty.name} §7— §aclaimed\n`
        : `§e✦ ${bounty.name} §7— §f${bounty.coinReward} coins\n`;
    }
    form.body(body);

    for (const bounty of this.dailyBounties) {
      const claimed = s.get(`bb_claim_${this.lastDay}_${bounty.slot}`);
      form.button(claimed ? `§8${bounty.name} (claimed)` : `§e✦ Claim ${bounty.name}`);
    }
    form.button("§7Close");

    const res = await form.show(player);
    if (res.canceled || res.selection >= BOUNTY_SLOTS) return;

    const bounty = this.dailyBounties[res.selection];
    const claimKey = `bb_claim_${this.lastDay}_${bounty.slot}`;

    if (s.get(claimKey)) {
      player.sendMessage("§cAlready claimed this bounty today.");
      return;
    }

    s.set(claimKey, true);
    this.eventBridge.emit("grant_coins", { player, amount: bounty.coinReward, reason: `Bounty: ${bounty.name}` });
    player.sendMessage(`§a✦ Claimed bounty: §f${bounty.name} §7(+${bounty.coinReward} coins)`);
    player.playSound("random.orb", { volume: 0.7, pitch: 1.2 });
  }

  tick() {
    this.refreshDaily();
  }
}
