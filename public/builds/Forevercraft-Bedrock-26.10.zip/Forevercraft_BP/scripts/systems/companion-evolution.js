/**
 * Companion Evolution System — Max-level mythical pets transform into Ascended forms.
 * Replaces Java companion_evolution/ folder (74 mcfunction files).
 *
 * Requirements: Level 100, Bond 4500+, Mythical tier, Spirit Treat consumed.
 * 37 evolved companions with unique passive abilities.
 * 4-phase ceremony: Darkness → Burst → Transform → Announce
 */
import { world, system } from "@minecraft/server";
import { StorageManager } from "../utils/storage.js";

// Evolution requirements
const EVOLVE_LEVEL = 100;
const EVOLVE_BOND = 4500;

// Evolved companions and their abilities
const EVOLVED_COMPANIONS = {
  blue_dragon:    { name: "Endwalker",    ability: "ender_particles", desc: "Portal particles, ender teleport on hit" },
  red_dragon:     { name: "Ashborn",      ability: "inferno_aura",   desc: "1 heart fire damage to hostiles within 8 blocks/3s" },
  phoenix:        { name: "Emberheart",   ability: "rebirth",        desc: "Flame particles, revives on death" },
  reaper:         { name: "Wraith",       ability: "shadow_veil",    desc: "Invisibility at night" },
  warden:         { name: "Monolith",     ability: "seismic_sight",  desc: "Detection boost while sneaking" },
  tiger:          { name: "Sabertooth",   ability: "pack_leader",    desc: "Buffs all nearby tamed animals" },
  arctic_fox:     { name: "Frostweaver",  ability: "freeze_trail",   desc: "Slowness + freeze aura" },
  butterfly:      { name: "Zephyr",       ability: "wind_speed",     desc: "Speed I to owner" },
  claude:         { name: "Oracle",       ability: "deep_scan",      desc: "Ore detection doubled" },
  copper_golem:   { name: "Conductor",    ability: "lightning_rod",  desc: "Redirects lightning to hostiles" },
  cow_of_eden:    { name: "Lifegiver",    ability: "crop_growth",    desc: "Crops grow faster nearby" },
  golden_dragon:  { name: "Midas",        ability: "gold_drops",     desc: "Gold nugget drops on kill" },
  iron_golem:     { name: "Bulwark",      ability: "resistance_gate",desc: "Resistance when owner below 50% HP" },
  leviathan:      { name: "Abyssal",      ability: "water_power",    desc: "Dolphins Grace + Conduit Power near water" },
  moobloom:       { name: "Bloomcaller",  ability: "weakness_aura",  desc: "Weakness to nearby hostiles" },
  panther:        { name: "Shadowstrike", ability: "stealth_boost",  desc: "Invisible in dark areas" },
  red_panda:      { name: "Firecracker",  ability: "lucky_drops",    desc: "+10% drop rate" },
  skeleton_horse: { name: "Bonesteed",    ability: "sprint_boost",   desc: "Speed + no fall damage" },
  spirit_wolf:    { name: "Spiritfang",   ability: "soul_howl",      desc: "Strength aura on howl" },
  time_weaver:    { name: "Chronos",      ability: "time_snap",      desc: "Restore HP to snapshot value" },
  void_walker:    { name: "Voidshade",    ability: "void_cloak",     desc: "Invisibility in dark areas" },
  wither:         { name: "Witherlord",   ability: "wither_aura",    desc: "Wither effect on nearby hostiles" },
  dreamstag:      { name: "Dreamweaver",  ability: "dream_boost",    desc: "+0.5 Dream Rate" },
  starweaver:     { name: "Starlight",    ability: "night_glow",     desc: "Night Vision + glowing items" },
  somnia:         { name: "Lullaby",      ability: "sleep_aura",     desc: "Slowness to hostiles at night" },
  lunar_moth:     { name: "Moonwing",     ability: "slow_fall",      desc: "Slow Falling aura" },
  nebula_kit:     { name: "Cosmic",       ability: "radar",          desc: "All mobs glow within 16 blocks" },
  twilight_hare:  { name: "Duskrunner",   ability: "haste_aura",     desc: "Haste I to owner" },
  grovekeeper:    { name: "Verdant",      ability: "regen_aura",     desc: "Regeneration I to owner" },
  infernus:       { name: "Infernal",     ability: "fire_immune",    desc: "Fire Resistance to owner" },
  crystalheart:   { name: "Prism",        ability: "absorption",     desc: "Absorption I to owner" },
  stormcaller:    { name: "Tempest",      ability: "storm_strike",   desc: "Lightning on nearby hostiles during rain" },
};

// Ability → effect mapping for tick-based passives
const AURA_EFFECTS = {
  wind_speed:     { effect: "speed", amplifier: 0 },
  freeze_trail:   { target: "hostiles", effect: "slowness", amplifier: 1 },
  weakness_aura:  { target: "hostiles", effect: "weakness", amplifier: 0 },
  wither_aura:    { target: "hostiles", effect: "wither", amplifier: 0 },
  sleep_aura:     { target: "hostiles", effect: "slowness", amplifier: 2, nightOnly: true },
  slow_fall:      { effect: "slow_falling", amplifier: 0 },
  haste_aura:     { effect: "haste", amplifier: 0 },
  regen_aura:     { effect: "regeneration", amplifier: 0 },
  fire_immune:    { effect: "fire_resistance", amplifier: 0 },
  absorption:     { effect: "absorption", amplifier: 0 },
  sprint_boost:   { effect: "speed", amplifier: 1 },
};

export class CompanionEvolutionSystem {
  constructor(eventBridge) {
    this.eventBridge = eventBridge;

    // Listen for evolution attempts
    eventBridge.on("try_evolve_companion", (data) => {
      if (data.player) this.tryEvolve(data.player, data.petId);
    });
  }

  /**
   * Attempt to evolve a companion.
   */
  tryEvolve(player, petId) {
    const s = StorageManager.forPlayer(player);

    // Check if already evolved
    const evolvedBits = s.getNumber("ce_evolved", 0);
    const petIndex = Object.keys(EVOLVED_COMPANIONS).indexOf(petId);
    if (petIndex === -1) {
      player.sendMessage("§cThis companion cannot evolve.");
      return;
    }
    if (petIndex < 32 && (evolvedBits & (1 << petIndex))) {
      player.sendMessage("§cThis companion has already been evolved!");
      return;
    }

    // Check level and bond requirements
    const level = s.getNumber(`pet_level_${petId}`, 0);
    const bond = s.getNumber(`pet_bond_${petId}`, 0);

    if (level < EVOLVE_LEVEL) {
      player.sendMessage(`§cRequires Level ${EVOLVE_LEVEL}. Current: ${level}`);
      return;
    }
    if (bond < EVOLVE_BOND) {
      player.sendMessage(`§cRequires Bond ${EVOLVE_BOND}+. Current: ${bond}`);
      return;
    }

    // Begin ceremony
    this.startCeremony(player, petId, petIndex);
  }

  /**
   * 4-phase evolution ceremony with dramatic effects.
   */
  startCeremony(player, petId, petIndex) {
    const evoData = EVOLVED_COMPANIONS[petId];
    const dim = player.dimension;

    // Phase 1: Darkness (2 seconds)
    player.sendMessage("§8§l... darkness descends ...");
    try {
      player.addEffect("darkness", 80, { amplifier: 0, showParticles: false });
      dim.playSound("mob.warden.heartbeat", player.location, { volume: 1.0, pitch: 0.5 });
    } catch {}

    // Phase 2: Burst (after 2s)
    system.runTimeout(() => {
      try {
        dim.spawnParticle("minecraft:totem_particle", player.location);
        dim.playSound("random.totem", player.location, { volume: 1.5, pitch: 0.8 });
      } catch {}
      player.sendMessage("§d§l✦ A surge of energy! ✦§r");
    }, 40);

    // Phase 3: Transform (after 4s)
    system.runTimeout(() => {
      // Mark as evolved
      const s = StorageManager.forPlayer(player);
      if (petIndex < 32) {
        const bits = s.getNumber("ce_evolved", 0) | (1 << petIndex);
        s.set("ce_evolved", bits);
      }
      s.set(`ce_active_${petId}`, true);

      player.addTag("ce.evolved_active");
      player.addTag(`ce.evo_${petId}`);

      player.sendMessage(`\n§d§l✦ EVOLUTION COMPLETE ✦§r`);
      player.sendMessage(`§7Your companion has become §d§l${evoData.name}§r§7!`);
      player.sendMessage(`§7Ability: §e${evoData.desc}`);

      try {
        dim.spawnParticle("minecraft:totem_particle", player.location);
        dim.playSound("ui.toast.challenge_complete", player.location, { volume: 1.5, pitch: 1.0 });
      } catch {}
    }, 80);

    // Phase 4: Announce (after 6s)
    system.runTimeout(() => {
      for (const p of world.getAllPlayers()) {
        p.sendMessage(`§d§l✦ §r§f${player.name}§7's companion evolved into §d§l${evoData.name}§r§7!`);
      }

      player.onScreenDisplay.setTitle("§d§lASCENDED", {
        subtitle: `§7${evoData.name} has awakened!`,
        fadeInDuration: 10, stayDuration: 80, fadeOutDuration: 20,
      });
    }, 120);
  }

  /**
   * Tick evolved companion abilities (called every 20 ticks).
   */
  tick(players) {
    for (const player of players) {
      if (!player.hasTag("ce.evolved_active")) continue;

      const s = StorageManager.forPlayer(player);
      const activePetId = s.get("active_pet") || s.get("bd_active_type");
      if (!activePetId) continue;

      const petKey = activePetId.replace("minecraft:", "");
      const evoData = EVOLVED_COMPANIONS[petKey];
      if (!evoData || !s.get(`ce_active_${petKey}`)) continue;

      // Apply aura effects
      const aura = AURA_EFFECTS[evoData.ability];
      if (aura) {
        // Night-only check
        if (aura.nightOnly) {
          const time = world.getTimeOfDay();
          if (time < 13000 || time > 23000) continue;
        }

        if (aura.target === "hostiles") {
          // Apply to nearby hostiles
          try {
            const hostiles = player.dimension.getEntities({
              location: player.location,
              maxDistance: 8,
              families: ["monster"],
            });
            for (const h of hostiles) {
              try { h.addEffect(aura.effect, 40, { amplifier: aura.amplifier, showParticles: true }); } catch {}
            }
          } catch {}
        } else {
          // Apply to owner
          try { player.addEffect(aura.effect, 40, { amplifier: aura.amplifier, showParticles: false }); } catch {}
        }
      }

      // Special abilities
      switch (evoData.ability) {
        case "inferno_aura":
          try {
            const nearby = player.dimension.getEntities({
              location: player.location, maxDistance: 8, families: ["monster"]
            });
            for (const e of nearby) {
              try { e.setOnFire(3, true); } catch {}
            }
          } catch {}
          break;

        case "resistance_gate":
          try {
            const hp = player.getComponent("minecraft:health");
            if (hp && hp.currentValue < hp.effectiveMax * 0.5) {
              player.addEffect("resistance", 40, { amplifier: 0, showParticles: false });
            }
          } catch {}
          break;

        case "dream_boost":
          // Passive DR handled by storage, applied once on evolution
          break;

        case "radar":
          try {
            const mobs = player.dimension.getEntities({
              location: player.location, maxDistance: 16, excludeTypes: ["minecraft:player"]
            });
            for (const m of mobs) {
              try { m.addEffect("glowing", 40, { amplifier: 0, showParticles: false }); } catch {}
            }
          } catch {}
          break;

        case "storm_strike":
          try {
            if (world.getWeather && Math.random() < 0.1) { // 10% per tick in rain
              const hostiles = player.dimension.getEntities({
                location: player.location, maxDistance: 12, families: ["monster"]
              });
              if (hostiles.length > 0) {
                const target = hostiles[Math.floor(Math.random() * hostiles.length)];
                player.dimension.runCommandAsync(
                  `summon lightning_bolt ${target.location.x} ${target.location.y} ${target.location.z}`
                );
              }
            }
          } catch {}
          break;
      }
    }
  }

  /**
   * Emberheart Rebirth — sacrifices companion to save player on death.
   * Called from tomb system / death listener. Returns true if rebirth triggered.
   * 1-hour cooldown (72000 ticks).
   */
  tryEmberheartRebirth(player) {
    if (!player.hasTag("ce.evo_phoenix")) return false;

    const s = StorageManager.forPlayer(player);
    const lastRebirth = s.getNumber("ce_rebirth_cd", 0);
    const now = system.currentTick;

    // 1-hour cooldown (72000 ticks)
    if (lastRebirth > 0 && (now - lastRebirth) < 72000) return false;

    // Sacrifice the companion
    s.setNumber("ce_rebirth_cd", now);
    player.removeTag("ce.evolved_active");
    player.removeTag("ce.evo_phoenix");
    s.set("ce_active_phoenix", false);

    // Heal player
    try {
      player.addEffect("instant_health", 1, { amplifier: 4, showParticles: true });
      player.addEffect("fire_resistance", 200, { amplifier: 0, showParticles: false });
      player.addEffect("regeneration", 200, { amplifier: 1, showParticles: false });
    } catch {}

    // Visual effects
    try {
      player.dimension.spawnParticle("minecraft:totem_particle", player.location);
      player.dimension.spawnParticle("minecraft:basic_flame_particle", player.location);
      player.playSound("random.totem");
    } catch {}

    player.sendMessage("\n§c§l✦ EMBERHEART REBIRTH ✦\n§r§7Your companion sacrificed itself to save you!\n§7Emberheart will return after 1 hour.\n");

    // Broadcast
    for (const p of world.getAllPlayers()) {
      if (p.name !== player.name) {
        p.sendMessage(`§c§l✦ §r§f${player.name}§7's Emberheart sacrificed itself in a blaze of glory!`);
      }
    }

    // Re-enable after 1 hour
    system.runTimeout(() => {
      try {
        const ps = StorageManager.forPlayer(player);
        ps.set("ce_active_phoenix", true);
        player.addTag("ce.evolved_active");
        player.addTag("ce.evo_phoenix");
        player.sendMessage("§c§l✦ §r§7Your Emberheart has been reborn from the ashes!");
        player.playSound("random.levelup");
      } catch {}
    }, 72000);

    return true;
  }
}
