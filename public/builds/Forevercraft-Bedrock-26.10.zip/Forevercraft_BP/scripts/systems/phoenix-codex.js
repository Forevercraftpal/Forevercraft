/**
 * Phoenix Codex — Master menu item that unifies 4 major subsystems.
 * Tab 1: Forevercraft Codex | Tab 2: Craftforever Codex
 * Tab 3: Companion Catalogue | Tab 4: Guidestone Network (remote)
 * Shift+Use cycles tabs, normal Use opens selected tab.
 * Replaces Java phoenix/ folder (9 files).
 */
import { world, system } from "@minecraft/server";
import { StorageManager } from "../utils/storage.js";

const TABS = [
  { id: 1, name: "§6✦ The Forevercraft Codex ✦",   system: "codex",       guard: "ec.in_codex" },
  { id: 2, name: "§a✦ The Craftforever Codex ✦",    system: "craftforever", guard: "ec.in_cf_codex" },
  { id: 3, name: "§6✦ The Companion Catalogue ✦",   system: "companions",  guard: "ec.in_pet_menu" },
  { id: 4, name: "§d✦ Guidestone Network ✦",        system: "guidestone",  guard: "ec.gs_in_menu" },
];

export class PhoenixCodexSystem {
  constructor(eventBridge, guiManager, guidestoneSystem) {
    this.eventBridge = eventBridge;
    this.guiManager = guiManager;
    this.guidestone = guidestoneSystem;

    // Listen for Phoenix Codex item use
    world.afterEvents.itemUse.subscribe((event) => {
      const player = event.source;
      const item = event.itemStack;
      if (!player || player.typeId !== "minecraft:player") return;
      if (!item) return;

      // Check if it's the Phoenix Codex (written_book with phoenix_codex lore/tag)
      const lore = item.getLore?.() || [];
      const isPhoenix = lore.some(l => l.includes("Phoenix Codex") || l.includes("awakened tome")) ||
                        item.typeId?.includes("phoenix_codex");
      if (!isPhoenix) return;

      this.onUse(player);
    });
  }

  onUse(player) {
    const s = StorageManager.forPlayer(player);

    if (player.isSneaking) {
      // Cycle to next tab
      this.cycleTab(player, s);
    } else {
      // Open current tab
      this.openTab(player, s);
    }
  }

  cycleTab(player, s) {
    let currentTab = s.getNumber("phoenix_tab", 1);
    currentTab = (currentTab % 4) + 1; // 1→2→3→4→1
    s.setNumber("phoenix_tab", currentTab);

    const tab = TABS[currentTab - 1];
    player.onScreenDisplay?.setActionBar?.(tab.name);
    try { player.playSound("random.click", { volume: 0.5, pitch: 1.5 }); } catch {}
  }

  openTab(player, s) {
    const currentTab = s.getNumber("phoenix_tab", 1);
    const tab = TABS[Math.min(currentTab - 1, TABS.length - 1)];

    // Guard: don't open if already in a menu
    if (player.hasTag(tab.guard)) return;

    switch (tab.id) {
      case 1: // Forevercraft Codex
        this.guiManager?.openByName?.(player, "codex");
        break;

      case 2: // Craftforever Codex
        this.guiManager?.openByName?.(player, "craftforever");
        break;

      case 3: // Companion Catalogue
        this.guiManager?.openByName?.(player, "companions");
        break;

      case 4: // Guidestone Network (Remote — no physical stone needed)
        if (this.guidestone) {
          player.addTag("ec.gs_remote_menu");
          this.guidestone.openMenu?.(player);
        } else {
          this.guiManager?.openByName?.(player, "guidestone");
        }
        break;
    }
  }

  // Give Phoenix Codex to a player
  giveCodex(player) {
    const s = StorageManager.forPlayer(player);
    if (s.getNumber("has_phoenix_codex", 0) === 1) {
      player.sendMessage("§7You already have a Phoenix Codex.");
      return;
    }

    try {
      player.runCommandAsync("give @s writable_book 1");
      // In practice, the item would be a custom item with proper components
      // For now, give a writable_book and track via storage
      s.setNumber("has_phoenix_codex", 1);
      s.setNumber("phoenix_tab", 1);
      player.sendMessage("\n§6§l✦ Phoenix Codex Obtained! ✦\n§r§7An awakened tome of boundless knowledge.\n§7§oShift+Use: Cycle tabs | Use: Open selected\n");
      player.playSound("random.levelup");
    } catch {}
  }

  // Recover lost codex (called from tick if player has flag but no item)
  recoverCodex(player) {
    const s = StorageManager.forPlayer(player);
    if (s.getNumber("has_phoenix_codex", 0) !== 1) return;
    // Auto-recovery handled by checking inventory periodically
    // The Phoenix Codex should always be available
  }
}
