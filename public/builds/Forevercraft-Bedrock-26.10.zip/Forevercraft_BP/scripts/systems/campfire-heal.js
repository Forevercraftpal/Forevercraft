/**
 * Campfire Healing System — Heals players near lit campfires.
 * Replaces Java campfire_heal/ folder (5 files).
 *
 * Mechanics (matching Java):
 * - Heals 1 heart (instant_health) every 7 seconds to players within 6 blocks of a lit campfire
 * - If player has Regeneration I, upgrades to Regeneration II for 8 seconds
 * - Applies Saturation for 8 seconds to slow hunger degradation
 * - Heart particle at player position
 * - Both regular campfires and soul campfires count
 */
import { world, system } from "@minecraft/server";

const SCAN_RADIUS = 6;        // Block scan radius around player
const HEAL_INTERVAL = 140;    // 7 seconds in ticks
const CAMPFIRE_BLOCKS = ["minecraft:campfire", "minecraft:soul_campfire"];

export class CampfireHealSystem {
  constructor() {
    this.tickCounter = 0;
  }

  /** Called every tick from main loop — self-gates to 140-tick interval */
  tick(players) {
    this.tickCounter++;
    if (this.tickCounter < HEAL_INTERVAL) return;
    this.tickCounter = 0;

    for (const player of players) {
      this.checkPlayer(player);
    }
  }

  /** Check if player is near a campfire and apply healing */
  checkPlayer(player) {
    try {
      const pos = player.location;
      const dim = player.dimension;

      // Scan nearby blocks for campfires
      for (let dx = -SCAN_RADIUS; dx <= SCAN_RADIUS; dx++) {
        for (let dz = -SCAN_RADIUS; dz <= SCAN_RADIUS; dz++) {
          for (let dy = -1; dy <= 1; dy++) {
            const bx = Math.floor(pos.x) + dx;
            const by = Math.floor(pos.y) + dy;
            const bz = Math.floor(pos.z) + dz;

            try {
              const block = dim.getBlock({ x: bx, y: by, z: bz });
              if (!block) continue;

              if (CAMPFIRE_BLOCKS.includes(block.typeId)) {
                // Check if campfire is lit (extinguished campfires don't heal)
                // In Bedrock, campfires have an "extinguished" block state
                const extinguished = block.permutation.getState("extinguish");
                if (extinguished) continue;

                // Found a lit campfire — apply healing and return
                this.doHeal(player);
                return;
              }
            } catch {
              // Block might be in unloaded chunk, skip
              continue;
            }
          }
        }
      }
    } catch {
      // Player might have left, skip
    }
  }

  /** Apply healing effects matching Java do_heal.mcfunction */
  doHeal(player) {
    try {
      // Heal 1 heart (instant health, amplifier 0)
      player.addEffect("instant_health", 1, { amplifier: 0, showParticles: false });

      // Regen boost: if player has Regen I, upgrade to Regen II for 8 seconds
      const regen = player.getEffect("regeneration");
      if (regen && regen.amplifier === 0) {
        player.addEffect("regeneration", 160, { amplifier: 1, showParticles: false });
      }

      // Saturation for 8 seconds to slow hunger degradation
      player.addEffect("saturation", 160, { amplifier: 0, showParticles: false });

      // Heart particle
      const pos = player.location;
      player.dimension.spawnParticle("minecraft:heart_particle", {
        x: pos.x,
        y: pos.y + 1.5,
        z: pos.z
      });
    } catch {
      // Effect application failed, skip
    }
  }
}
