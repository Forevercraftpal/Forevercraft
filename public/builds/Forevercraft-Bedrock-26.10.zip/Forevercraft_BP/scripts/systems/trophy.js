/**
 * Trophy System — 15 achievement trophies tracked via bitfield.
 * Replaces Java trophy/ folder (3 mcfunction files).
 *
 * Trophies unlock from major milestones across all systems.
 * Bitfield storage: bit 0-14 = trophies 1-15.
 */
import { world } from "@minecraft/server";
import { StorageManager } from "../utils/storage.js";
import { ActionFormData } from "@minecraft/server-ui";

const TROPHIES = [
  { bit: 0, name: "First Steps", desc: "Complete your first quest", check: (s) => s.getNumber("quests_completed", 0) >= 1 },
  { bit: 1, name: "Dragon Slayer", desc: "Defeat the Ender Dragon", check: (s) => s.getNumber("wb_k1", 0) >= 1 || s.getNumber("boss_kills", 0) >= 1 },
  { bit: 2, name: "Dream Walker", desc: "Reach 100 Dream Rate", check: (s) => s.getNumber("dream_rate", 0) >= 100 },
  { bit: 3, name: "Master Explorer", desc: "Discover all 25 biomes", check: (s) => s.getNumber("jn_biome_count", 0) >= 25 },
  { bit: 4, name: "Artifact Collector", desc: "Collect 50 artifacts", check: (s) => s.getNumber("artifacts_collected", 0) >= 50 },
  { bit: 5, name: "Social Butterfly", desc: "Make 10 friends", check: (s) => s.getNumber("friend_count", 0) >= 10 },
  { bit: 6, name: "Guild Leader", desc: "Reach Guild Rank 5", check: (s) => s.getNumber("guild_rank", 0) >= 5 },
  { bit: 7, name: "Spirit Wielder", desc: "Obtain a Spirit Weapon", check: (s) => s.getNumber("sp_weapon_id", 0) > 0 },
  { bit: 8, name: "Raid Victor", desc: "Complete a Spirit Raid", check: (s) => s.getNumber("rd_total_kills", 0) >= 1 },
  { bit: 9, name: "Master Crafter", desc: "Reach Artisan Rank 50", check: (s) => s.getNumber("cf_rank", 0) >= 50 },
  { bit: 10, name: "Buddy Bond", desc: "Reach Spiritbound with a buddy", check: (s) => s.getNumber("bd_tier_max", 0) >= 6 },
  { bit: 11, name: "Pet Reviver", desc: "Perform the Moonbloom Ceremony", check: (s) => s.getNumber("tb_revivals", 0) >= 1 },
  { bit: 12, name: "Lore Scholar", desc: "Collect all 6 anecdotes", check: (s) => s.getNumber("jn_secret_3", 0) === 1 },
  { bit: 13, name: "World Champion", desc: "Defeat all 11 world bosses", check: (s) => !!s.get("wb_champion") },
  { bit: 14, name: "Eternal Legend", desc: "Reach 1000 Dream Rate", check: (s) => s.getNumber("dream_rate", 0) >= 1000 },
];

export class TrophySystem {
  constructor(eventBridge) {
    this.eventBridge = eventBridge;
  }

  /** Check all trophy conditions (called every 60 seconds) */
  tick(players) {
    for (const player of players) {
      const s = StorageManager.forPlayer(player);
      let bits = s.getNumber("trophy_bits", 0);
      let newUnlocks = false;

      for (const trophy of TROPHIES) {
        if (bits & (1 << trophy.bit)) continue; // Already unlocked
        try {
          if (trophy.check(s)) {
            bits |= (1 << trophy.bit);
            newUnlocks = true;
            player.sendMessage(`\n§6§l✦ Trophy Unlocked: ${trophy.name} ✦§r`);
            player.sendMessage(`§8${trophy.desc}`);
            player.playSound("ui.toast.challenge_complete", { volume: 0.8, pitch: 1.0 });
          }
        } catch {}
      }

      if (newUnlocks) {
        s.set("trophy_bits", bits);
        const count = this.countBits(bits);
        s.set("trophy_count", count);
      }
    }
  }

  countBits(n) {
    let count = 0;
    while (n) { count += n & 1; n >>= 1; }
    return count;
  }

  /** Display trophy cabinet */
  async showTrophies(player) {
    const s = StorageManager.forPlayer(player);
    const bits = s.getNumber("trophy_bits", 0);
    const count = this.countBits(bits);

    let body = `§7Trophies: §f${count}/${TROPHIES.length}\n\n`;
    for (const trophy of TROPHIES) {
      const unlocked = bits & (1 << trophy.bit);
      body += unlocked
        ? `§6✦ §f${trophy.name}\n§8  ${trophy.desc}\n\n`
        : `§8✗ ???\n§8  ${trophy.desc}\n\n`;
    }

    const form = new ActionFormData()
      .title("§l§6Trophy Cabinet")
      .body(body)
      .button("§7Close");

    await form.show(player);
  }
}
