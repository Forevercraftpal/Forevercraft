/**
 * Ingredient Binder System — Storage for alchemy/cooking materials (reagent items).
 * Stores up to 100 items total across all reagent types.
 * ActionFormData menu showing contents by category/tier.
 * Deposit and withdraw functions.
 * Uses StorageManager keys: binder_{category}_t{tier}
 */
import { world, system } from "@minecraft/server";
import { StorageManager } from "../utils/storage.js";
import { ActionFormData } from "@minecraft/server-ui";

const MAX_CAPACITY = 100;

const CATEGORIES = ["botanical", "visceral", "mineral"];
const CATEGORY_LABELS = {
  botanical: { label: "Botanical", color: "§a", icon: "🌿" },
  visceral:  { label: "Visceral",  color: "§c", icon: "🩸" },
  mineral:   { label: "Mineral",   color: "§b", icon: "💎" },
};

const TIER_COLORS = ["", "§7", "§f", "§b", "§a", "§d", "§5", "§e"];

// Reagent name lookup (mirrors REAGENTS in fusion-funnel.js)
const REAGENT_NAMES = {
  botanical: [null, "Verdant Leaf", "Moonpetal", "Spiritbloom", "Dreamroot", "Starbloom", "Voidmoss", "Primordial Essence"],
  visceral:  [null, "Fang Dust", "Venom Gland", "Spectral Ichor", "Dragonblood", "Netherheart", "Warp Residue", "Primordial Essence"],
  mineral:   [null, "Powdered Chalk", "Crystal Dust", "Arcane Powder", "Stardust", "Void Salt", "Aether Crystal", "Primordial Essence"],
};

export class IngredientBinderSystem {
  constructor(eventBridge) {
    this.eventBridge = eventBridge;
  }

  /**
   * Get total items stored in the binder.
   */
  getTotal(player) {
    const s = StorageManager.forPlayer(player);
    let total = 0;
    for (const cat of CATEGORIES) {
      for (let tier = 1; tier <= 7; tier++) {
        total += s.getNumber(`binder_${cat}_t${tier}`, 0);
      }
    }
    return total;
  }

  /**
   * Open the ingredient binder menu.
   */
  openMenu(player) {
    const s = StorageManager.forPlayer(player);
    const total = this.getTotal(player);

    let body = `§7Reagent & Ingredient Storage\n§7Capacity: §f${total}/${MAX_CAPACITY}\n\n`;

    // Show contents by category
    for (const cat of CATEGORIES) {
      const catDef = CATEGORY_LABELS[cat];
      let catTotal = 0;
      let catItems = [];
      for (let tier = 1; tier <= 7; tier++) {
        const count = s.getNumber(`binder_${cat}_t${tier}`, 0);
        if (count > 0) {
          catTotal += count;
          const name = REAGENT_NAMES[cat][tier] || `T${tier}`;
          catItems.push(`  ${TIER_COLORS[tier]}T${tier} ${name}: §f${count}`);
        }
      }
      if (catTotal > 0) {
        body += `${catDef.color}${catDef.icon} ${catDef.label} §7(${catTotal})\n`;
        body += catItems.join("\n") + "\n\n";
      }
    }

    if (total === 0) {
      body += "§8No ingredients stored.\n";
    }

    const form = new ActionFormData()
      .title("§5📖 Ingredient Binder")
      .body(body)
      .button("§aDeposit Reagent")
      .button("§bWithdraw Reagent")
      .button("§7Close");

    form.show(player).then(response => {
      if (response.canceled || response.selection === 2) return;
      if (response.selection === 0) {
        this.depositMenu(player);
      } else {
        this.withdrawCategoryMenu(player);
      }
    });
  }

  /**
   * Deposit reagents from player's reagent storage into the binder.
   */
  depositMenu(player) {
    const s = StorageManager.forPlayer(player);
    const total = this.getTotal(player);

    if (total >= MAX_CAPACITY) {
      player.sendMessage("§c§l[Binder] §7Binder is full! (100/100)");
      return;
    }

    const form = new ActionFormData()
      .title("§aDeposit Reagent")
      .body("§7Select a category to deposit from your reagent storage.");

    for (const cat of CATEGORIES) {
      const catDef = CATEGORY_LABELS[cat];
      let available = 0;
      for (let tier = 1; tier <= 7; tier++) {
        available += s.getNumber(`reagent_${cat}_t${tier}`, 0);
      }
      form.button(`${catDef.color}${catDef.icon} ${catDef.label}\n§7${available} available`);
    }
    form.button("§7← Back");

    form.show(player).then(response => {
      if (response.canceled || response.selection === 3) {
        this.openMenu(player);
        return;
      }
      this.depositTierMenu(player, CATEGORIES[response.selection]);
    });
  }

  /**
   * Show tier selection for depositing from a specific category.
   */
  depositTierMenu(player, category) {
    const s = StorageManager.forPlayer(player);
    const total = this.getTotal(player);
    const remaining = MAX_CAPACITY - total;
    const catDef = CATEGORY_LABELS[category];

    const form = new ActionFormData()
      .title(`§aDeposit ${catDef.label}`)
      .body(`§7Space remaining: §f${remaining}\n§7Select a tier to deposit.`);

    const availableTiers = [];
    for (let tier = 1; tier <= 7; tier++) {
      const reagentCount = s.getNumber(`reagent_${category}_t${tier}`, 0);
      if (reagentCount > 0) {
        const name = REAGENT_NAMES[category][tier] || `T${tier}`;
        form.button(`${TIER_COLORS[tier]}T${tier} ${name}\n§7Available: §f${reagentCount}`);
        availableTiers.push(tier);
      }
    }

    if (availableTiers.length === 0) {
      player.sendMessage(`§7No ${catDef.label} reagents to deposit.`);
      this.depositMenu(player);
      return;
    }

    form.button("§7← Back");

    form.show(player).then(response => {
      if (response.canceled || response.selection === availableTiers.length) {
        this.depositMenu(player);
        return;
      }

      const tier = availableTiers[response.selection];
      const reagentCount = s.getNumber(`reagent_${category}_t${tier}`, 0);
      const canDeposit = Math.min(reagentCount, MAX_CAPACITY - this.getTotal(player));

      if (canDeposit <= 0) {
        player.sendMessage("§c§l[Binder] §7No space or no reagents!");
        return;
      }

      // Transfer from reagent storage to binder
      s.setNumber(`reagent_${category}_t${tier}`, reagentCount - canDeposit);
      const current = s.getNumber(`binder_${category}_t${tier}`, 0);
      s.setNumber(`binder_${category}_t${tier}`, current + canDeposit);

      const name = REAGENT_NAMES[category][tier] || `T${tier}`;
      player.sendMessage(`§a§l[Binder] §r§7Deposited §f${canDeposit}x §7${name} (${this.getTotal(player)}/${MAX_CAPACITY})`);
      try { player.playSound("random.orb", { volume: 0.5, pitch: 1.2 }); } catch {}
    });
  }

  /**
   * Withdraw category selection.
   */
  withdrawCategoryMenu(player) {
    const s = StorageManager.forPlayer(player);
    const total = this.getTotal(player);

    if (total === 0) {
      player.sendMessage("§7§l[Binder] §7Binder is empty.");
      return;
    }

    const form = new ActionFormData()
      .title("§bWithdraw Reagent")
      .body("§7Select a category to withdraw.");

    const availableCats = [];
    for (const cat of CATEGORIES) {
      const catDef = CATEGORY_LABELS[cat];
      let catTotal = 0;
      for (let tier = 1; tier <= 7; tier++) {
        catTotal += s.getNumber(`binder_${cat}_t${tier}`, 0);
      }
      if (catTotal > 0) {
        form.button(`${catDef.color}${catDef.icon} ${catDef.label}\n§7Stored: §f${catTotal}`);
        availableCats.push(cat);
      }
    }
    form.button("§7← Back");

    form.show(player).then(response => {
      if (response.canceled || response.selection === availableCats.length) {
        this.openMenu(player);
        return;
      }
      this.withdrawTierMenu(player, availableCats[response.selection]);
    });
  }

  /**
   * Show tier selection for withdrawing from a specific category.
   */
  withdrawTierMenu(player, category) {
    const s = StorageManager.forPlayer(player);
    const catDef = CATEGORY_LABELS[category];

    const form = new ActionFormData()
      .title(`§bWithdraw ${catDef.label}`)
      .body("§7Select a tier to withdraw.");

    const availableTiers = [];
    for (let tier = 1; tier <= 7; tier++) {
      const count = s.getNumber(`binder_${category}_t${tier}`, 0);
      if (count > 0) {
        const name = REAGENT_NAMES[category][tier] || `T${tier}`;
        form.button(`${TIER_COLORS[tier]}T${tier} ${name}\n§7Stored: §f${count}`);
        availableTiers.push(tier);
      }
    }
    form.button("§7← Back");

    form.show(player).then(response => {
      if (response.canceled || response.selection === availableTiers.length) {
        this.withdrawCategoryMenu(player);
        return;
      }

      const tier = availableTiers[response.selection];
      const count = s.getNumber(`binder_${category}_t${tier}`, 0);

      if (count <= 0) {
        player.sendMessage("§c§l[Binder] §7Nothing to withdraw!");
        return;
      }

      // Withdraw 1 item back to reagent storage
      s.setNumber(`binder_${category}_t${tier}`, count - 1);
      const reagentCount = s.getNumber(`reagent_${category}_t${tier}`, 0);
      s.setNumber(`reagent_${category}_t${tier}`, reagentCount + 1);

      const name = REAGENT_NAMES[category][tier] || `T${tier}`;
      player.sendMessage(`§b§l[Binder] §r§7Withdrew §f1x §7${name} → reagent storage (${this.getTotal(player)}/${MAX_CAPACITY})`);
      try { player.playSound("random.orb", { volume: 0.5, pitch: 0.8 }); } catch {}
    });
  }
}
