/**
 * Companion Crates System — 6-tier pet crates with companion spawning.
 * Each crate gives a companion entity + lead + whistle + treats.
 * Replaces Java companion_crates/ folder.
 */
import { world, system } from "@minecraft/server";
import { StorageManager } from "../utils/storage.js";

// Companion pools per rarity tier
const COMPANION_POOLS = {
  common: [
    "ant", "baby_potato", "cat", "chick", "duck", "hamster",
    "mushroom", "rascal", "red_parrot", "spinosaurus", "sporeblossom",
  ],
  uncommon: [
    "chicken", "cow", "dog", "mooshroom", "pig", "silverfish",
    "snail", "squid", "turtle", "worm",
  ],
  rare: [
    "axolotl", "blaze", "camel", "elder_guardian", "giraffe", "goat",
    "llama", "mossy_skeleton", "ocelot", "piglin", "pufferfish",
    "wolf", "wooly_cow", "zoglin",
  ],
  ornate: [
    "alien", "allay", "armadillo", "creeper", "dolphin", "enderman",
    "fox", "frog", "frozen_zombie", "ghast", "hoglin", "knight",
    "koala", "monkey", "mossy_zombie", "mule", "owl", "panda",
    "penguin", "polar_bear", "rabbit", "sniffer", "strider",
  ],
  exquisite: [
    "breeze", "copper_golem", "creaking", "crystalheart", "ender_dragon",
    "evoker", "grovekeeper", "infernus", "iron_golem", "owl",
    "ravager", "stormcaller", "voidshade",
  ],
  mythical: [
    "alien", "butterfly", "claude", "cow_of_eden", "golden_dragon",
    "leviathan", "panther", "phoenix", "reaper", "red_panda",
    "regal_tiger", "snow_fox_spirit", "snowman", "spirit_wolf",
    "time_weaver", "void_walker", "wither",
  ],
};

// Tier colors
const TIER_COLORS = {
  common: "§7", uncommon: "§a", rare: "§b",
  ornate: "§5", exquisite: "§d", mythical: "§6",
};

// Treat counts by tier
const TREAT_COUNTS = {
  common: 2, uncommon: 2, rare: 3, ornate: 3, exquisite: 4, mythical: 4,
};

export class CompanionCrateSystem {
  constructor(eventBridge) {
    this.eventBridge = eventBridge;

    // Listen for companion crate give events
    eventBridge.on("companion_crate_give", (player, tierId) => {
      this.giveCrate(player, tierId);
    });

    // Item use handler
    world.afterEvents.itemUse.subscribe((event) => {
      const item = event.itemStack;
      if (!item) return;
      const tierId = this.getCrateTier(item);
      if (tierId) {
        this.openCrate(event.source, tierId);
      }
    });
  }

  getCrateTier(item) {
    for (const tier of Object.keys(COMPANION_POOLS)) {
      if (item.typeId === `forevercraft:companion_crate_${tier}`) return tier;
    }
    return null;
  }

  giveCrate(player, tierId) {
    const color = TIER_COLORS[tierId] || "§7";
    try {
      player.dimension.runCommandAsync(
        `give "${player.name}" forevercraft:companion_crate_${tierId} 1`
      );
    } catch {}
    player.sendMessage(`${color}§l✦ ${tierId.charAt(0).toUpperCase() + tierId.slice(1)} Companion Crate received!`);
  }

  openCrate(player, tierId) {
    const color = TIER_COLORS[tierId] || "§7";
    const pool = COMPANION_POOLS[tierId];
    if (!pool || pool.length === 0) return;

    // Remove crate from hand
    try {
      const equip = player.getComponent("minecraft:equippable");
      const mainhand = equip?.getEquipment("Mainhand");
      if (mainhand) {
        if (mainhand.amount > 1) {
          mainhand.amount--;
          equip.setEquipment("Mainhand", mainhand);
        } else {
          equip.setEquipment("Mainhand", undefined);
        }
      }
    } catch {}

    // Roll companion
    const companionId = pool[Math.floor(Math.random() * pool.length)];
    const displayName = companionId.replace(/_/g, " ").replace(/\b\w/g, l => l.toUpperCase());

    // Effects
    try {
      const pos = player.location;
      player.dimension.runCommandAsync(
        `particle minecraft:totem_particle ${pos.x} ${pos.y + 1} ${pos.z} 0.5 0.5 0.5 0.1 30`
      );
      player.playSound("firework.blast", { volume: 0.5, pitch: 1.2 });
    } catch {}

    // Give companion item + accessories
    try {
      player.dimension.runCommandAsync(
        `give "${player.name}" forevercraft:companion_${companionId} 1`
      );
      player.dimension.runCommandAsync(
        `give "${player.name}" minecraft:lead 1`
      );
      player.dimension.runCommandAsync(
        `give "${player.name}" forevercraft:companion_whistle 1`
      );
      player.dimension.runCommandAsync(
        `give "${player.name}" forevercraft:companion_menu 1`
      );
      const treats = TREAT_COUNTS[tierId] || 2;
      player.dimension.runCommandAsync(
        `give "${player.name}" forevercraft:companion_treat ${treats}`
      );
    } catch {}

    // Announce
    player.sendMessage(`${color}§l═══════════════════════`);
    player.sendMessage(`${color}§l  ✦ New Companion!`);
    player.sendMessage(`${color}§l  ${displayName}`);
    player.sendMessage(`${color}§l═══════════════════════`);

    // Mythical announcement
    if (tierId === "mythical") {
      for (const p of world.getAllPlayers()) {
        if (p.id !== player.id) {
          p.sendMessage(`§6§l☄ §e${player.name} §7found a §6Mythical §7companion: §6${displayName}§7!`);
        }
      }
    }

    // Stats
    const storage = StorageManager.forPlayer(player);
    storage.increment("companion_crates_opened", 1);

    this.eventBridge.emit("companion_obtained", player, companionId, tierId);
  }
}
