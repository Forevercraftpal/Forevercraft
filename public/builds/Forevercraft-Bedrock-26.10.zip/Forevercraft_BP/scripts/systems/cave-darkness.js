/**
 * Cave Darkness System — Applies darkness effect when deep underground in low light.
 * Conditions: Y ≤ 16, block light ≤ 3, Overworld only, not in water, no night vision.
 * Replaces Java cave_darkness/tick.mcfunction + is_dark_cave predicate.
 */
import { world, EffectTypes } from "@minecraft/server";

export class CaveDarknessSystem {
  constructor() {}

  tick(players) {
    for (const player of players) {
      // Skip creative/spectator
      const gm = player.getGameMode?.() ?? "survival";
      if (gm === "creative" || gm === "spectator") continue;

      // Overworld only
      if (player.dimension.id !== "minecraft:overworld") continue;

      const pos = player.location;

      // Y ≤ 16
      if (pos.y > 16) continue;

      // Not in water
      if (player.isInWater) continue;

      // Skip if has night vision
      try {
        if (player.getEffect(EffectTypes.get("night_vision"))) continue;
      } catch {}

      // Check block light at player feet
      try {
        const block = player.dimension.getBlock({
          x: Math.floor(pos.x),
          y: Math.floor(pos.y),
          z: Math.floor(pos.z),
        });
        if (!block) continue;

        // Block light level (not sky light)
        const light = block.light ?? 15;
        if (light > 3) continue;

        // Apply darkness for 2 seconds (40 ticks), amplifier 0, no particles
        player.addEffect(EffectTypes.get("darkness"), 40, {
          amplifier: 0,
          showParticles: false,
        });
      } catch {}
    }
  }
}
