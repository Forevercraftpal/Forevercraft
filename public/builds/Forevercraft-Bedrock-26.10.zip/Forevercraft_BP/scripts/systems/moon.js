/**
 * Moon Phase System — Tracks moon phase (0-7), provides DR bonuses,
 * triggers Harvest Moon special event, and offers a display menu.
 * Replaces Java moon/check.mcfunction + luck_buffs/tick moon logic.
 */
import { world, EffectTypes } from "@minecraft/server";
import { StorageManager } from "../utils/storage.js";
import { ActionFormData } from "@minecraft/server-ui";

// Moon phase names and descriptions
const MOON_PHASES = [
  { name: "Full Moon", color: "§b", flavor: "The ocean teems with life", effects: "+0.5 Fishing DR, +1 DR" },
  { name: "Waning Gibbous", color: "§f", flavor: "The moon begins to recede", effects: "+5% Mining Speed" },
  { name: "Third Quarter", color: "§f", flavor: "Half light, half shadow", effects: "+1 Armor" },
  { name: "Waning Crescent", color: "§f", flavor: "A sliver of silver remains", effects: "Reduced mob aggro" },
  { name: "New Moon", color: "§5", flavor: "Hostility stirs in the darkness", effects: "2x Patron, +0.5 Mob DR, Night Vision" },
  { name: "Waxing Crescent", color: "§f", flavor: "Light returns to the sky", effects: "+5% Movement Speed" },
  { name: "First Quarter", color: "§f", flavor: "The moon grows stronger", effects: "+1 Attack Damage" },
  { name: "Waxing Gibbous", color: "§f", flavor: "Nearly full and bright", effects: "+10% XP Gain" },
];

export class MoonSystem {
  constructor(eventBridge) {
    this.eventBridge = eventBridge;
    this.currentPhase = 0;
    this.harvestMoonActive = false;
    this.lastDuskNotified = -1;
    this.lastDawnDay = -1;

    // Listen for scriptevent trigger for moon display
    world.afterEvents.scriptEventReceive?.subscribe((event) => {
      if (event.id === "forevercraft:moon_check" && event.sourceEntity) {
        this.openMenu(event.sourceEntity);
      }
    });
  }

  /**
   * Calculate the current moon phase from world day.
   */
  calculatePhase() {
    try {
      const day = (globalThis._fc_daylight?.getDay?.() ?? 0);
      this.currentPhase = day % 8;
    } catch {
      this.currentPhase = 0;
    }
  }

  /**
   * Get current moon phase (0-7).
   */
  getPhase() {
    return this.currentPhase;
  }

  /**
   * Check if it's a new moon (phase 4).
   */
  isNewMoon() {
    return this.currentPhase === 4;
  }

  /**
   * Check if it's a full moon (phase 0).
   */
  isFullMoon() {
    return this.currentPhase === 0;
  }

  /**
   * Check if Harvest Moon is currently active.
   */
  isHarvestMoon() {
    return this.harvestMoonActive;
  }

  /**
   * Main tick — runs every 20 ticks (1 second).
   * Calculates phase, checks for dusk/dawn transitions, applies DR bonuses.
   */
  tick(players) {
    this.calculatePhase();

    const timeOfDay = world.getTimeOfDay();
    const currentDay = (globalThis._fc_daylight?.getDay?.() ?? 0);

    // === DUSK DETECTION (DayTime crosses 13000) ===
    if (timeOfDay >= 13000 && timeOfDay < 13100 && this.lastDuskNotified !== currentDay) {
      this.lastDuskNotified = currentDay;
      this.onDusk(players, currentDay);
    }

    // === DAWN DETECTION (DayTime crosses 0/23500+) ===
    if (timeOfDay < 1000 && this.lastDawnDay !== currentDay) {
      this.lastDawnDay = currentDay;
      this.onDawn(players);
    }

    // === APPLY PHASE BONUSES ===
    const isNight = timeOfDay >= 13000 && timeOfDay <= 23000;

    for (const player of players) {
      const gm = player.getGameMode?.() ?? "survival";
      if (gm === "creative" || gm === "spectator") continue;

      const s = StorageManager.forPlayer(player);

      // Full Moon (0): +0.5 fishing DR, +1 DR at night
      if (this.isFullMoon() && isNight) {
        s.set("moon_fishing_bonus", 0.5);
        s.set("moon_dr_bonus", 1);
      } else {
        s.set("moon_fishing_bonus", 0);
        if (!this.harvestMoonActive) s.set("moon_dr_bonus", 0);
      }

      // Waning Gibbous (1): +5% Mining Speed via haste at night
      if (this.currentPhase === 1 && isNight) {
        try { player.runCommandAsync("effect @s haste 5 0 true"); } catch {}
      }

      // Third Quarter (2): +1 Armor via resistance at night
      if (this.currentPhase === 2 && isNight) {
        try { player.runCommandAsync("effect @s resistance 5 0 true"); } catch {}
      }

      // Waning Crescent (3): Reduced mob aggro — handled by mob spawn system reading phase

      // New Moon (4): +0.5 mob DR, night vision at night
      if (this.isNewMoon() && isNight) {
        s.set("moon_mob_bonus", 0.5);
        try { player.runCommandAsync("effect @s night_vision 15 0 true"); } catch {}
      } else {
        s.set("moon_mob_bonus", 0);
      }

      // Waxing Crescent (5): +5% Movement Speed at night
      if (this.currentPhase === 5 && isNight) {
        try { player.runCommandAsync("effect @s speed 5 0 true"); } catch {}
      }

      // First Quarter (6): +1 Attack Damage via strength at night
      if (this.currentPhase === 6 && isNight) {
        try { player.runCommandAsync("effect @s strength 5 0 true"); } catch {}
      }

      // Waxing Gibbous (7): +10% XP Gain — tracked as storage flag for XP events
      if (this.currentPhase === 7 && isNight) {
        s.set("moon_xp_bonus", 0.1);
      } else {
        s.set("moon_xp_bonus", 0);
      }

      // Harvest Moon: +1.5 all DR
      if (this.harvestMoonActive) {
        s.set("moon_harvest_bonus", 1.5);
      } else {
        s.set("moon_harvest_bonus", 0);
      }
    }
  }

  /**
   * Called at dusk (DayTime ~13000). Rolls for Harvest Moon on full moon nights.
   */
  onDusk(players, currentDay) {
    // Full Moon — roll for Harvest Moon (1 in 8 chance)
    if (this.isFullMoon()) {
      const roll = Math.floor(Math.random() * 8);
      if (roll === 0) {
        this.harvestMoonActive = true;

        // Notify all players
        for (const player of players) {
          player.sendMessage("§6§l✦ §eA Harvest Moon rises! §6§l✦");
          player.sendMessage("§7All Dream Rates increased by §a+1.5 §7tonight!");
          try {
            player.playSound("block.amethyst_block.chime", { volume: 0.6, pitch: 0.7 });
          } catch {}

          // Track achievement
          const s = StorageManager.forPlayer(player);
          const moonsSeen = s.getNumber("ach_moons_seen", 0);
          s.set("ach_moons_seen", moonsSeen | 2); // bit 2 = Harvest Moon
        }
      }

      // Track Full Moon seen (achievement)
      for (const player of players) {
        const s = StorageManager.forPlayer(player);
        const moonsSeen = s.getNumber("ach_moons_seen", 0);
        if (!(moonsSeen & 1)) {
          s.set("ach_moons_seen", moonsSeen | 1); // bit 1 = Full Moon
        }
      }
    }

    // New Moon — track achievement
    if (this.isNewMoon()) {
      for (const player of players) {
        const s = StorageManager.forPlayer(player);
        const moonsSeen = s.getNumber("ach_moons_seen", 0);
        if (!(moonsSeen & 4)) {
          s.set("ach_moons_seen", moonsSeen | 4); // bit 4 = New Moon
        }
      }
    }
  }

  /**
   * Called at dawn. Resets Harvest Moon if active.
   */
  onDawn(players) {
    if (this.harvestMoonActive) {
      this.harvestMoonActive = false;

      for (const player of players) {
        player.sendMessage("§7The Harvest Moon fades with the dawn...");
        const s = StorageManager.forPlayer(player);
        s.set("moon_harvest_bonus", 0);
      }
    }
  }

  /**
   * Get time-of-day classification string.
   */
  getTimeOfDayName() {
    const time = world.getTimeOfDay();
    if (time <= 6000) return "Morning";
    if (time <= 13000) return "Afternoon";
    if (time <= 23000) return "Night";
    return "Dawn";
  }

  /**
   * Get time-of-day lore description.
   */
  getTimeOfDayLore() {
    const name = this.getTimeOfDayName();
    switch (name) {
      case "Morning": return "Fishing is most fruitful at this hour";
      case "Afternoon": return "Harvest and mining thrive under the sun";
      case "Night": return "Creatures of darkness roam freely";
      case "Dawn": return "A new day approaches";
      default: return "";
    }
  }

  /**
   * Open moon info menu for a player.
   */
  openMenu(player) {
    const phase = MOON_PHASES[this.currentPhase];
    const timeOfDay = this.getTimeOfDayName();
    const timeLore = this.getTimeOfDayLore();

    let body = `§6§lMoon & Sky\n\n`;
    body += `§7Current Phase: ${phase.color}§l${phase.name}\n`;
    body += `§7"${phase.flavor}"\n`;
    body += `§7Effects: §f${phase.effects}\n\n`;

    if (this.harvestMoonActive) {
      body += `§6§l✦ HARVEST MOON ACTIVE ✦\n`;
      body += `§7All Dream Rates: §a+1.5\n\n`;
    }

    body += `§7Time of Day: §e${timeOfDay}\n`;
    body += `§8${timeLore}\n\n`;

    // Next notable moon event
    const daysToFull = (8 - this.currentPhase) % 8;
    const daysToNew = (4 - this.currentPhase + 8) % 8;
    if (daysToFull <= daysToNew && daysToFull > 0) {
      body += `§7Next Full Moon: §f${daysToFull} day${daysToFull !== 1 ? "s" : ""}`;
    } else if (daysToNew > 0) {
      body += `§7Next New Moon: §f${daysToNew} day${daysToNew !== 1 ? "s" : ""}`;
    } else {
      body += `§7Next phase change: §f1 day`;
    }

    const form = new ActionFormData()
      .title("§6☽ Moon & Sky")
      .body(body)
      .button("§7Close");

    form.show(player).then(() => {});
  }
}
