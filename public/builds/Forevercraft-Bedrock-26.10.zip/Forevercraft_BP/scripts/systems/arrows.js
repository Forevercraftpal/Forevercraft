/**
 * Arrow System — Lightning Arrow: spectral arrow with lightning_arrow custom data
 * strikes lightning where it lands.
 * Replaces Java arrows/check_new.mcfunction + arrows/lightning_strike.mcfunction.
 */
import { world } from "@minecraft/server";

export class ArrowSystem {
  constructor(eventBridge) {
    // Listen for projectile hit events
    world.afterEvents.projectileHitBlock.subscribe((event) => {
      this.onProjectileHitBlock(event);
    });

    world.afterEvents.projectileHitEntity.subscribe((event) => {
      this.onProjectileHitEntity(event);
    });
  }

  /**
   * Check if a projectile is a lightning arrow by checking its item/tags.
   * In Bedrock, we check for the custom item type or tag.
   */
  isLightningArrow(projectile) {
    if (!projectile || !projectile.isValid()) return false;

    // Check for custom tag on the arrow entity
    if (projectile.hasTag("ec.lightning_arrow")) return true;

    // Check typeId for custom arrow item
    if (projectile.typeId === "forevercraft:lightning_arrow") return true;

    // Check if it's a regular arrow with the lightning tag
    // (arrows fired from items with lightning_arrow custom_data)
    return false;
  }

  onProjectileHitBlock(event) {
    const projectile = event.projectile;
    if (!this.isLightningArrow(projectile)) return;

    try {
      const loc = projectile.location;
      const dim = projectile.dimension;

      // Summon lightning bolt at arrow position
      dim.spawnEntity("minecraft:lightning_bolt", loc);

      // Play teleport sound for extra flair
      dim.playSound("entity.enderman.teleport", loc, { volume: 0.5, pitch: 0.5 });

      // Kill the arrow
      projectile.kill();
    } catch {}
  }

  onProjectileHitEntity(event) {
    const projectile = event.projectile;
    if (!this.isLightningArrow(projectile)) return;

    try {
      const loc = projectile.location;
      const dim = projectile.dimension;

      // Summon lightning at impact point
      dim.spawnEntity("minecraft:lightning_bolt", loc);

      // Kill the arrow
      projectile.kill();
    } catch {}
  }

  /**
   * Tag arrows on spawn. Called from main tick to tag new arrows.
   * Checks arrow entities for custom item data and tags them.
   */
  tagNewArrows() {
    try {
      const arrows = world.getDimension("overworld").getEntities({
        type: "minecraft:arrow",
        tags: ["!ec.arrow_checked"],
      });
      for (const arrow of arrows) {
        arrow.addTag("ec.arrow_checked");
        // Check for lightning arrow custom data via item component
        try {
          const item = arrow.getComponent("minecraft:item");
          if (item) {
            const stack = item.itemStack;
            if (stack?.hasTag("forevercraft:lightning_arrow")) {
              arrow.addTag("ec.lightning_arrow");
            }
          }
        } catch {}
      }
    } catch {}

    // Also check nether and end
    for (const dimId of ["minecraft:nether", "minecraft:the_end"]) {
      try {
        const arrows = world.getDimension(dimId).getEntities({
          type: "minecraft:arrow",
          tags: ["!ec.arrow_checked"],
        });
        for (const arrow of arrows) {
          arrow.addTag("ec.arrow_checked");
          try {
            const item = arrow.getComponent("minecraft:item");
            if (item) {
              const stack = item.itemStack;
              if (stack?.hasTag("forevercraft:lightning_arrow")) {
                arrow.addTag("ec.lightning_arrow");
              }
            }
          } catch {}
        }
      } catch {}
    }
  }
}
