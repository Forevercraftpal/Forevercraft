/**
 * Health Bar System — RPG-style actionbar health display.
 * Replaces Java health_bar/ folder (bossbar + actionbar display).
 * Uses Script API to read health and display via actionbar text.
 */
import { world, system } from "@minecraft/server";
import { getScore, setScore } from "../utils/scoreboard.js";

export class HealthBarSystem {
  constructor() {
    // Update health bars every 2 ticks (same as Java)
    this.tickCounter = 0;
  }

  tick(players) {
    this.tickCounter++;
    if (this.tickCounter < 2) return;
    this.tickCounter = 0;

    for (const player of players) {
      if (!player.hasTag("ec.healthbar_on")) continue;
      this.updateHealthBar(player);
    }
  }

  updateHealthBar(player) {
    try {
      const health = player.getComponent("minecraft:health");
      if (!health) return;

      const current = Math.ceil(health.currentValue);
      const max = Math.ceil(health.effectiveMax);
      const pct = current / max;

      // Color based on health percentage
      let color;
      if (pct > 0.66) color = "§a";
      else if (pct > 0.33) color = "§e";
      else color = "§c";

      // Build heart bar
      const totalHearts = Math.ceil(max / 2);
      const fullHearts = Math.floor(current / 2);
      const halfHeart = current % 2 === 1;

      let bar = "";
      for (let i = 0; i < totalHearts; i++) {
        if (i < fullHearts) bar += `${color}❤`;
        else if (i === fullHearts && halfHeart) bar += `§e❤`;
        else bar += "§8❤";
      }

      // Show absorption hearts
      const absorption = player.getComponent("minecraft:absorption");
      if (absorption) {
        const absVal = Math.ceil(absorption.currentValue || 0);
        if (absVal > 0) bar += ` §6+${absVal / 2}❤`;
      }

      player.onScreenDisplay.setActionBar(`${bar} ${color}${current}§7/§f${max}`);
    } catch {}
  }

  toggle(player) {
    if (player.hasTag("ec.healthbar_on")) {
      player.removeTag("ec.healthbar_on");
      player.sendMessage("§7Health bar §cdisabled§7.");
    } else {
      player.addTag("ec.healthbar_on");
      player.sendMessage("§7Health bar §aenabled§7.");
    }
  }
}
