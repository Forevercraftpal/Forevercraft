/**
 * Knockback Utility — Collision-checked step-based knockback for Bedrock.
 * Replaces Java's tp-with-block-check pattern:
 *   execute as @e at @s facing entity @p feet positioned ^ ^ ^-0.4
 *     if block ~ ~ ~ #minecraft:replaceable if block ~ ~1 ~ #minecraft:replaceable
 *     run tp @s ~ ~ ~
 *
 * Step size: 0.4 blocks (matches Java exactly).
 * Checks both foot and head height for passability before each step.
 */

// Step size in blocks
const STEP_SIZE = 0.4;

// Knockback step counts matching Java files exactly
export const MELEE_KB_STEPS = { 1: 2, 2: 3, 3: 4, 4: 5, 5: 6 };
export const RANGED_PUNCH_STEPS = { 1: 3, 2: 4, 3: 5, 4: 6, 5: 8 };

// Blocks that entities can pass through (equivalent to Java #minecraft:replaceable)
const PASSABLE_TYPES = new Set([
  // Plants
  "minecraft:short_grass", "minecraft:tallgrass", "minecraft:tall_grass",
  "minecraft:fern", "minecraft:large_fern", "minecraft:dead_bush",
  "minecraft:seagrass", "minecraft:vine", "minecraft:hanging_roots",
  "minecraft:glow_lichen", "minecraft:moss_carpet", "minecraft:spore_blossom",
  "minecraft:small_dripleaf_block", "minecraft:cave_vines",
  "minecraft:cave_vines_body_with_berries", "minecraft:cave_vines_head_with_berries",
  // Flowers
  "minecraft:yellow_flower", "minecraft:red_flower", "minecraft:dandelion",
  "minecraft:poppy", "minecraft:blue_orchid", "minecraft:allium",
  "minecraft:azure_bluet", "minecraft:red_tulip", "minecraft:orange_tulip",
  "minecraft:white_tulip", "minecraft:pink_tulip", "minecraft:oxeye_daisy",
  "minecraft:cornflower", "minecraft:lily_of_the_valley", "minecraft:wither_rose",
  "minecraft:torchflower", "minecraft:pitcher_plant",
  // Snow/fire
  "minecraft:snow_layer", "minecraft:fire", "minecraft:soul_fire",
  // Technical
  "minecraft:structure_void", "minecraft:light_block",
  // Crops (passable)
  "minecraft:wheat", "minecraft:carrots", "minecraft:potatoes", "minecraft:beetroot",
  "minecraft:sweet_berry_bush", "minecraft:nether_wart",
  // Misc passable
  "minecraft:torch", "minecraft:soul_torch", "minecraft:redstone_torch",
  "minecraft:wall_torch", "minecraft:soul_wall_torch",
  "minecraft:redstone_wire", "minecraft:rail", "minecraft:powered_rail",
  "minecraft:detector_rail", "minecraft:activator_rail",
]);

/**
 * Check if a block is passable (entity can move through it)
 */
function isBlockPassable(block) {
  if (!block) return false;
  if (block.isAir) return true;
  if (block.isLiquid) return true;
  return PASSABLE_TYPES.has(block.typeId);
}

/**
 * Check if a position is passable at both foot and head height
 */
function isPositionPassable(dimension, x, y, z) {
  try {
    const footBlock = dimension.getBlock({ x: Math.floor(x), y: Math.floor(y), z: Math.floor(z) });
    const headBlock = dimension.getBlock({ x: Math.floor(x), y: Math.floor(y) + 1, z: Math.floor(z) });
    return isBlockPassable(footBlock) && isBlockPassable(headBlock);
  } catch {
    return false;
  }
}

/**
 * Calculate normalized horizontal direction from source to target.
 * Returns {dx, dz} normalized, or null if too close.
 */
function getDirection(fromPos, toPos) {
  const dx = toPos.x - fromPos.x;
  const dz = toPos.z - fromPos.z;
  const dist = Math.sqrt(dx * dx + dz * dz);
  if (dist < 0.001) return null;
  return { dx: dx / dist, dz: dz / dist };
}

/**
 * Apply stepped knockback AWAY from source (standard knockback).
 * Each step is 0.4 blocks. Stops at first solid block.
 *
 * @param {Entity} target - Entity to knock back
 * @param {Entity|{x,y,z}} source - Source position (knock AWAY from this)
 * @param {number} steps - Number of 0.4-block steps
 */
export function applyKnockback(target, source, steps) {
  const sourcePos = source.location || source;
  const targetPos = target.location;

  const dir = getDirection(sourcePos, targetPos);
  if (!dir) return;

  const stepX = dir.dx * STEP_SIZE;
  const stepZ = dir.dz * STEP_SIZE;

  let currentX = targetPos.x;
  let currentY = targetPos.y;
  let currentZ = targetPos.z;

  for (let i = 0; i < steps; i++) {
    const nextX = currentX + stepX;
    const nextZ = currentZ + stepZ;
    if (!isPositionPassable(target.dimension, nextX, currentY, nextZ)) break;
    currentX = nextX;
    currentZ = nextZ;
  }

  if (currentX !== targetPos.x || currentZ !== targetPos.z) {
    try {
      target.teleport({ x: currentX, y: currentY, z: currentZ });
    } catch {}
  }
}

/**
 * Apply stepped PULL toward source (e.g., tidal strike, xp magnet).
 * Each step is 0.4 blocks toward source. Stops at solid blocks.
 *
 * @param {Entity} target - Entity to pull
 * @param {Entity|{x,y,z}} source - Source position (pull TOWARD this)
 * @param {number} steps - Number of 0.4-block steps
 */
export function applyPull(target, source, steps) {
  const sourcePos = source.location || source;
  const targetPos = target.location;

  const dir = getDirection(targetPos, sourcePos);
  if (!dir) return;

  const stepX = dir.dx * STEP_SIZE;
  const stepZ = dir.dz * STEP_SIZE;

  let currentX = targetPos.x;
  let currentY = targetPos.y;
  let currentZ = targetPos.z;

  for (let i = 0; i < steps; i++) {
    const nextX = currentX + stepX;
    const nextZ = currentZ + stepZ;
    if (!isPositionPassable(target.dimension, nextX, currentY, nextZ)) break;
    currentX = nextX;
    currentZ = nextZ;
  }

  if (currentX !== targetPos.x || currentZ !== targetPos.z) {
    try {
      target.teleport({ x: currentX, y: currentY, z: currentZ });
    } catch {}
  }
}

/**
 * Apply custom-distance pull (for XP magnet/mob magnet with non-standard step size).
 * @param {Entity} target - Entity to pull
 * @param {Entity|{x,y,z}} source - Pull toward this
 * @param {number} stepSize - Distance per step in blocks
 * @param {number} steps - Number of steps (default 1)
 */
export function applyCustomPull(target, source, stepSize, steps = 1) {
  const sourcePos = source.location || source;
  const targetPos = target.location;

  const dir = getDirection(targetPos, sourcePos);
  if (!dir) return;

  const stepX = dir.dx * stepSize;
  const stepZ = dir.dz * stepSize;

  let currentX = targetPos.x;
  let currentY = targetPos.y;
  let currentZ = targetPos.z;

  for (let i = 0; i < steps; i++) {
    const nextX = currentX + stepX;
    const nextZ = currentZ + stepZ;
    if (!isPositionPassable(target.dimension, nextX, currentY, nextZ)) break;
    currentX = nextX;
    currentZ = nextZ;
  }

  if (currentX !== targetPos.x || currentZ !== targetPos.z) {
    try {
      target.teleport({ x: currentX, y: currentY, z: currentZ });
    } catch {}
  }
}

/**
 * Apply AoE knockback to all nearby non-player entities.
 * @param {Player} player - Source player (entities knocked away from this)
 * @param {number} radius - AoE radius in blocks
 * @param {number} steps - KB steps per entity
 * @param {number} [maxTargets=10] - Max entities to knock back
 */
export function applyAoEKnockback(player, radius, steps, maxTargets = 10) {
  try {
    const nearby = player.dimension.getEntities({
      location: player.location,
      maxDistance: radius,
      excludeTypes: ["minecraft:player", "minecraft:item", "minecraft:xp_orb"],
      excludeFamilies: ["inanimate"],
    });
    let count = 0;
    for (const entity of nearby) {
      if (count >= maxTargets) break;
      applyKnockback(entity, player, steps);
      count++;
    }
    return count;
  } catch {
    return 0;
  }
}
