import { world } from "@minecraft/server";

export function getOrCreateObjective(id, displayName) {
  let obj = world.scoreboard.getObjective(id);
  if (!obj) { obj = world.scoreboard.addObjective(id, displayName ?? id); }
  return obj;
}

export function getScore(entity, objectiveId, fallback = 0) {
  try {
    const obj = world.scoreboard.getObjective(objectiveId);
    if (!obj || !entity.scoreboardIdentity) return fallback;
    return obj.getScore(entity.scoreboardIdentity) ?? fallback;
  } catch { return fallback; }
}

export function setScore(entity, objectiveId, value) {
  try {
    const obj = getOrCreateObjective(objectiveId);
    if (entity.scoreboardIdentity) { obj.setScore(entity.scoreboardIdentity, value); }
  } catch {}
}

export function addScore(entity, objectiveId, amount) {
  const current = getScore(entity, objectiveId);
  const newVal = current + amount;
  setScore(entity, objectiveId, newVal);
  return newVal;
}

export function getFakePlayerScore(fakePlayer, objectiveId, fallback = 0) {
  try {
    const obj = world.scoreboard.getObjective(objectiveId);
    if (!obj) return fallback;
    for (const p of obj.getParticipants()) {
      if (p.displayName === fakePlayer) return obj.getScore(p) ?? fallback;
    }
    return fallback;
  } catch { return fallback; }
}

export async function setFakePlayerScore(fakePlayer, objectiveId, value) {
  await world.getDimension("overworld").runCommandAsync(`scoreboard players set "${fakePlayer}" "${objectiveId}" ${value}`);
}
