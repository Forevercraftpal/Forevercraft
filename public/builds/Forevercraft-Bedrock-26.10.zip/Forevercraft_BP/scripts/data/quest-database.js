/**
 * Quest Database — All 75 quest definitions with objectives and rewards.
 * Data file loaded by QuestSystem module.
 */

export const QUESTS = [
  // === TIER 1: BEGINNER (15 quests) ===
  { id: "t1_first_hunt", tier: 1, name: "First Hunt", desc: "Kill 10 zombies", type: "kill", target: "minecraft:zombie", count: 10, reward: "common", xp: 50 },
  { id: "t1_skeleton_slayer", tier: 1, name: "Skeleton Slayer", desc: "Kill 10 skeletons", type: "kill", target: "minecraft:skeleton", count: 10, reward: "common", xp: 50 },
  { id: "t1_spider_squasher", tier: 1, name: "Spider Squasher", desc: "Kill 8 spiders", type: "kill", target: "minecraft:spider", count: 8, reward: "common", xp: 50 },
  { id: "t1_miner", tier: 1, name: "Apprentice Miner", desc: "Mine 64 stone", type: "mine", target: "minecraft:stone", count: 64, reward: "common", xp: 40 },
  { id: "t1_lumberjack", tier: 1, name: "Lumberjack", desc: "Mine 32 oak logs", type: "mine", target: "minecraft:oak_log", count: 32, reward: "common", xp: 40 },
  { id: "t1_farmer", tier: 1, name: "Green Thumb", desc: "Harvest 32 wheat", type: "harvest", target: "minecraft:wheat", count: 32, reward: "common", xp: 40 },
  { id: "t1_fisher", tier: 1, name: "Gone Fishin'", desc: "Catch 5 fish", type: "fish", count: 5, reward: "common", xp: 50 },
  { id: "t1_explorer", tier: 1, name: "Wanderer", desc: "Walk 1000 blocks", type: "walk", count: 1000, reward: "common", xp: 60 },
  { id: "t1_builder", tier: 1, name: "Builder's Start", desc: "Place 100 blocks", type: "place", count: 100, reward: "common", xp: 40 },
  { id: "t1_drowned", tier: 1, name: "Tide Turner", desc: "Kill 5 drowned", type: "kill", target: "minecraft:drowned", count: 5, reward: "common", xp: 50 },
  { id: "t1_cave_spider", tier: 1, name: "Web Cutter", desc: "Kill 5 cave spiders", type: "kill", target: "minecraft:cave_spider", count: 5, reward: "common", xp: 60 },
  { id: "t1_iron", tier: 1, name: "Iron Seeker", desc: "Mine 16 iron ore", type: "mine", target: "minecraft:iron_ore", count: 16, reward: "common", xp: 50 },
  { id: "t1_cook", tier: 1, name: "First Meal", desc: "Cook 10 food items", type: "cook", count: 10, reward: "common", xp: 40 },
  { id: "t1_creeper", tier: 1, name: "Boom Stopper", desc: "Kill 5 creepers", type: "kill", target: "minecraft:creeper", count: 5, reward: "common", xp: 60 },
  { id: "t1_night_surv", tier: 1, name: "Night Survivor", desc: "Survive 3 nights", type: "survive_night", count: 3, reward: "common", xp: 70 },

  // === TIER 2: APPRENTICE (15 quests) ===
  { id: "t2_zombie_horde", tier: 2, name: "Zombie Horde", desc: "Kill 30 zombies", type: "kill", target: "minecraft:zombie", count: 30, reward: "uncommon", xp: 100 },
  { id: "t2_deep_miner", tier: 2, name: "Deep Miner", desc: "Mine 32 deepslate", type: "mine", target: "minecraft:deepslate", count: 32, reward: "uncommon", xp: 80 },
  { id: "t2_gold_rush", tier: 2, name: "Gold Rush", desc: "Mine 16 gold ore", type: "mine", target: "minecraft:gold_ore", count: 16, reward: "uncommon", xp: 100 },
  { id: "t2_witch_hunt", tier: 2, name: "Witch Hunt", desc: "Kill 3 witches", type: "kill", target: "minecraft:witch", count: 3, reward: "uncommon", xp: 120 },
  { id: "t2_enderman", tier: 2, name: "Void Gazer", desc: "Kill 5 endermen", type: "kill", target: "minecraft:enderman", count: 5, reward: "uncommon", xp: 120 },
  { id: "t2_mega_harvest", tier: 2, name: "Mega Harvest", desc: "Harvest 100 crops", type: "harvest", count: 100, reward: "uncommon", xp: 80 },
  { id: "t2_angler", tier: 2, name: "Master Angler", desc: "Catch 20 fish", type: "fish", count: 20, reward: "uncommon", xp: 100 },
  { id: "t2_trek", tier: 2, name: "Long Trek", desc: "Walk 5000 blocks", type: "walk", count: 5000, reward: "uncommon", xp: 120 },
  { id: "t2_pillager", tier: 2, name: "Pillager Raid", desc: "Kill 10 pillagers", type: "kill", target: "minecraft:pillager", count: 10, reward: "uncommon", xp: 110 },
  { id: "t2_blaze", tier: 2, name: "Fire Fighter", desc: "Kill 5 blazes", type: "kill", target: "minecraft:blaze", count: 5, reward: "uncommon", xp: 130 },
  { id: "t2_diamond", tier: 2, name: "Diamond Seeker", desc: "Mine 8 diamond ore", type: "mine", target: "minecraft:diamond_ore", count: 8, reward: "uncommon", xp: 150 },
  { id: "t2_phantom", tier: 2, name: "Phantom Menace", desc: "Kill 5 phantoms", type: "kill", target: "minecraft:phantom", count: 5, reward: "uncommon", xp: 110 },
  { id: "t2_vindicator", tier: 2, name: "Vindication", desc: "Kill 3 vindicators", type: "kill", target: "minecraft:vindicator", count: 3, reward: "uncommon", xp: 130 },
  { id: "t2_redstone", tier: 2, name: "Redstone Engineer", desc: "Mine 32 redstone ore", type: "mine", target: "minecraft:redstone_ore", count: 32, reward: "uncommon", xp: 90 },
  { id: "t2_slime", tier: 2, name: "Slime Time", desc: "Kill 10 slimes", type: "kill", target: "minecraft:slime", count: 10, reward: "uncommon", xp: 100 },

  // === TIER 3: JOURNEYMAN (15 quests) ===
  { id: "t3_wither_skel", tier: 3, name: "Skull Collector", desc: "Kill 15 wither skeletons", type: "kill", target: "minecraft:wither_skeleton", count: 15, reward: "rare", xp: 200 },
  { id: "t3_guardian", tier: 3, name: "Temple Guardian", desc: "Kill 10 guardians", type: "kill", target: "minecraft:guardian", count: 10, reward: "rare", xp: 200 },
  { id: "t3_ancient_debris", tier: 3, name: "Ancient Delver", desc: "Mine 4 ancient debris", type: "mine", target: "minecraft:ancient_debris", count: 4, reward: "rare", xp: 250 },
  { id: "t3_ravager", tier: 3, name: "Beast Slayer", desc: "Kill 2 ravagers", type: "kill", target: "minecraft:ravager", count: 2, reward: "rare", xp: 300 },
  { id: "t3_evoker", tier: 3, name: "Mage Hunter", desc: "Kill 3 evokers", type: "kill", target: "minecraft:evoker", count: 3, reward: "rare", xp: 280 },
  { id: "t3_expedition", tier: 3, name: "Grand Expedition", desc: "Walk 20000 blocks", type: "walk", count: 20000, reward: "rare", xp: 250 },
  { id: "t3_nether", tier: 3, name: "Nether Conquest", desc: "Kill 30 nether mobs", type: "kill_family", target: "nether", count: 30, reward: "rare", xp: 250 },
  { id: "t3_emerald", tier: 3, name: "Emerald Baron", desc: "Mine 16 emerald ore", type: "mine", target: "minecraft:emerald_ore", count: 16, reward: "rare", xp: 200 },
  { id: "t3_mega_build", tier: 3, name: "Mega Builder", desc: "Place 1000 blocks", type: "place", count: 1000, reward: "rare", xp: 180 },
  { id: "t3_endermen", tier: 3, name: "Void Hunter", desc: "Kill 20 endermen", type: "kill", target: "minecraft:enderman", count: 20, reward: "rare", xp: 250 },
  { id: "t3_piglin_brute", tier: 3, name: "Bastion Breaker", desc: "Kill 5 piglin brutes", type: "kill", target: "minecraft:piglin_brute", count: 5, reward: "rare", xp: 280 },
  { id: "t3_elder_guard", tier: 3, name: "Monument Clear", desc: "Kill an elder guardian", type: "kill", target: "minecraft:elder_guardian", count: 1, reward: "rare", xp: 350 },
  { id: "t3_mass_kill", tier: 3, name: "War Machine", desc: "Kill 100 hostile mobs", type: "kill_family", target: "monster", count: 100, reward: "rare", xp: 300 },
  { id: "t3_deep_diamond", tier: 3, name: "Diamond Vein", desc: "Mine 32 deepslate diamond ore", type: "mine", target: "minecraft:deepslate_diamond_ore", count: 32, reward: "rare", xp: 300 },
  { id: "t3_patron_hunt", tier: 3, name: "Patron Hunter", desc: "Kill 10 patron mobs", type: "patron_kill", count: 10, reward: "rare", xp: 350 },

  // === TIER 4: EXPERT (15 quests) ===
  { id: "t4_warden", tier: 4, name: "Warden's Bane", desc: "Kill a warden", type: "kill", target: "minecraft:warden", count: 1, reward: "ornate", xp: 500 },
  { id: "t4_ender_dragon", tier: 4, name: "Dragon Slayer", desc: "Kill the Ender Dragon", type: "kill", target: "minecraft:ender_dragon", count: 1, reward: "ornate", xp: 1000 },
  { id: "t4_wither", tier: 4, name: "Wither Storm", desc: "Kill the Wither", type: "kill", target: "minecraft:wither", count: 1, reward: "ornate", xp: 800 },
  { id: "t4_mass_patron", tier: 4, name: "Patron Purge", desc: "Kill 50 patron mobs", type: "patron_kill", count: 50, reward: "ornate", xp: 600 },
  { id: "t4_netherite", tier: 4, name: "Netherite Hoard", desc: "Mine 16 ancient debris", type: "mine", target: "minecraft:ancient_debris", count: 16, reward: "ornate", xp: 500 },
  { id: "t4_mega_fish", tier: 4, name: "Ocean Master", desc: "Catch 100 fish", type: "fish", count: 100, reward: "ornate", xp: 400 },
  { id: "t4_world_tour", tier: 4, name: "World Tour", desc: "Walk 100000 blocks", type: "walk", count: 100000, reward: "ornate", xp: 500 },
  { id: "t4_dr_30", tier: 4, name: "Dream Walker", desc: "Reach Dream Rate 30", type: "dream_rate", count: 30, reward: "ornate", xp: 600 },
  { id: "t4_pet_master", tier: 4, name: "Pet Master", desc: "Collect 20 pets", type: "pets", count: 20, reward: "ornate", xp: 500 },
  { id: "t4_quest_master", tier: 4, name: "Quest Master", desc: "Complete 30 quests", type: "quests_done", count: 30, reward: "ornate", xp: 500 },
  { id: "t4_lore_seeker", tier: 4, name: "Lore Seeker", desc: "Collect 100 lore pieces", type: "lore", count: 100, reward: "ornate", xp: 450 },
  { id: "t4_artifact_hoard", tier: 4, name: "Artifact Hoarder", desc: "Collect 50 artifacts", type: "artifacts", count: 50, reward: "ornate", xp: 500 },
  { id: "t4_bounty_hunter", tier: 4, name: "Bounty Hunter", desc: "Complete 10 bounties", type: "bounties", count: 10, reward: "ornate", xp: 500 },
  { id: "t4_night_terror", tier: 4, name: "Terror Tamer", desc: "Defeat 5 Night Terrors", type: "night_terror_kills", count: 5, reward: "ornate", xp: 600 },
  { id: "t4_boss_slayer", tier: 4, name: "Boss Slayer", desc: "Defeat 3 World Bosses", type: "bosses_defeated", count: 3, reward: "ornate", xp: 800 },

  // === TIER 5: MASTER (15 quests) ===
  { id: "t5_dr_100", tier: 5, name: "Dream Master", desc: "Reach Dream Rate 100", type: "dream_rate", count: 100, reward: "exquisite", xp: 1500 },
  { id: "t5_pet_lord", tier: 5, name: "Pet Lord", desc: "Collect 50 pets", type: "pets", count: 50, reward: "exquisite", xp: 1200 },
  { id: "t5_all_quests", tier: 5, name: "Quest Legend", desc: "Complete all 60 quests", type: "quests_done", count: 60, reward: "exquisite", xp: 2000 },
  { id: "t5_million_walk", tier: 5, name: "Marathon", desc: "Walk 1000000 blocks", type: "walk", count: 1000000, reward: "exquisite", xp: 1500 },
  { id: "t5_all_lore", tier: 5, name: "Lorekeeper", desc: "Collect 500 lore pieces", type: "lore", count: 500, reward: "exquisite", xp: 1500 },
  { id: "t5_mass_kills", tier: 5, name: "Warmonger", desc: "Kill 1000 hostile mobs", type: "kill_family", target: "monster", count: 1000, reward: "exquisite", xp: 1200 },
  { id: "t5_all_artifacts", tier: 5, name: "Collector", desc: "Find 200 artifacts", type: "artifacts", count: 200, reward: "exquisite", xp: 1500 },
  { id: "t5_prestige", tier: 5, name: "Prestige Path", desc: "Prestige any 3 advantage trees", type: "prestige_total", count: 3, reward: "exquisite", xp: 2000 },
  { id: "t5_10_bosses", tier: 5, name: "Champion", desc: "Defeat 10 World Bosses", type: "bosses_defeated", count: 10, reward: "exquisite", xp: 2000 },
  { id: "t5_all_bounties", tier: 5, name: "Bounty Legend", desc: "Complete 50 bounties", type: "bounties", count: 50, reward: "exquisite", xp: 1500 },
  { id: "t5_mining_master", tier: 5, name: "Mining Legend", desc: "Mine 10000 blocks", type: "blocks_mined", count: 10000, reward: "exquisite", xp: 1000 },
  { id: "t5_cooking_master", tier: 5, name: "Master Chef", desc: "Cook 100 meals", type: "meals_cooked", count: 100, reward: "exquisite", xp: 1200 },
  { id: "t5_all_sets", tier: 5, name: "Set Complete", desc: "Activate 5 armor set bonuses", type: "sets_activated", count: 5, reward: "mythical", xp: 2000 },
  { id: "t5_dr_max", tier: 5, name: "Eternal Dreamer", desc: "Reach Dream Rate 200", type: "dream_rate", count: 200, reward: "mythical", xp: 3000 },
  { id: "t5_legend", tier: 5, name: "Living Legend", desc: "Complete all other quests", type: "quests_done", count: 74, reward: "mythical", xp: 5000 },
];

// Tier colors for display
export const TIER_COLORS = {
  1: "§f", 2: "§e", 3: "§b", 4: "§5", 5: "§6",
};

export const TIER_NAMES = {
  1: "Beginner", 2: "Apprentice", 3: "Journeyman", 4: "Expert", 5: "Master",
};
