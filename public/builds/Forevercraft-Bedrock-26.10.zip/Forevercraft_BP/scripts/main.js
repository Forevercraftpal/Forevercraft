/**
 * Forevercraft Bedrock Edition — Main Entry Point (compiled from src/main.ts)
 * All systems wired up and active.
 */
import { world, system } from "@minecraft/server";
import { initScoreboards } from "./systems/scoreboard-init.js";
import { DaylightManager } from "./systems/daylight-manager.js";
import { EventBridge } from "./systems/event-bridge.js";
import { StorageManager } from "./utils/storage.js";

// === System Imports ===
import { TombSystem } from "./systems/tomb.js";
import { SeasonSystem } from "./systems/seasons.js";
import { DreamsSystem } from "./systems/dreams.js";
import { WeaponMasterySystem } from "./systems/weapon-mastery.js";
import { CalendarSystem } from "./systems/calendar.js";
import { CompanionSystem } from "./systems/companions.js";
import { QuestSystem } from "./systems/quests.js";
import { HealthBarSystem } from "./systems/health-bar.js";
import { AchievementSystem } from "./systems/achievements.js";
import { LoreSystem } from "./systems/lore.js";
import { GuidestoneSystem } from "./systems/guidestone.js";
import { DreamingRealmSystem } from "./systems/dreaming-realm.js";
import { HousingSystem } from "./systems/housing.js";
import { CookingSystem } from "./systems/cooking.js";
import { WorldEventSystem } from "./systems/world-events.js";
import { ArtifactAbilitySystem } from "./systems/artifact-abilities.js";
import { WorldBossSystem } from "./systems/world-boss.js";
import { WeaponClassSystem } from "./systems/weapon-classes.js";
import { TreasureSystem } from "./systems/treasure.js";
import { MobCrateSystem } from "./systems/mob-crates.js";
import { StructureCrateSystem } from "./systems/structure-crates.js";
import { FishingCrateSystem } from "./systems/fishing-crates.js";
import { HarvestCrateSystem } from "./systems/harvest-crates.js";
import { BountySystem } from "./systems/bounty.js";
import { NightTerrorSystem } from "./systems/night-terrors.js";
import { PatinaSystem } from "./systems/patina.js";
import { ArmorMasterySystem } from "./systems/armor-mastery.js";
import { TrimEffectSystem } from "./systems/trim-effects.js";
import { SatchelSystem } from "./systems/satchel.js";
import { PartySystem } from "./systems/party.js";
import { ProfessionSystem } from "./systems/professions.js";
import { BlackMarketSystem } from "./systems/black-market.js";
import { AdvantageTreeSystem } from "./systems/advantage-trees.js";
import { BriefingSystem } from "./systems/briefing.js";
import { CampfireStorySystem } from "./systems/campfire-stories.js";
import { GUIManager } from "./systems/gui-manager.js";
import { GlyphforgeSystem } from "./systems/glyphforge.js";
import { InscriptionStoneSystem } from "./systems/inscription-stones.js";
import { XpMagnetSystem } from "./systems/xp-magnet.js";
import { HealerSystem } from "./systems/healer.js";
import { ShieldSystem } from "./systems/shields.js";
import { RuneSystem } from "./systems/runes.js";
import { JournalSystem } from "./systems/journal.js";
import { LuckSystem } from "./systems/luck.js";

// === Batch 1 System Imports ===
import { CaveDarknessSystem } from "./systems/cave-darkness.js";
import { ArrowSystem } from "./systems/arrows.js";
import { TamedProtectionSystem } from "./systems/tamed-protection.js";
import { MovementSystem } from "./systems/movement.js";
import { CropHarvestSystem } from "./systems/crop-harvest.js";
import { MoonSystem } from "./systems/moon.js";
import { AnecdoteSystem } from "./systems/anecdotes.js";
import { OmenSystem } from "./systems/omens.js";
import { PortalDialSystem } from "./systems/portal-dial.js";

// === Batch 2 System Imports ===
import { BiomeSystem } from "./systems/biome.js";
import { BiomeMasterySystem } from "./systems/biome-mastery.js";
import { ProspectSystem } from "./systems/prospect.js";
import { ForageSystem } from "./systems/forage.js";
import { MilestoneSystem } from "./systems/milestones.js";
import { StatsSystem } from "./systems/stats.js";
import { DreamEchoSystem } from "./systems/dream-echoes.js";
import { BottleSystem } from "./systems/bottles.js";
import { PotionSystem } from "./systems/potions.js";
import { TransmuteSystem } from "./systems/transmute.js";

// === Batch 3 System Imports ===
import { CodexSystem } from "./systems/codex.js";
import { ConstellationSystem } from "./systems/constellations.js";
import { DungeonSystem } from "./systems/dungeon.js";
import { EncounterSystem } from "./systems/encounters.js";
import { HarmonizeSystem } from "./systems/harmonize.js";
import { VillageSystem } from "./systems/village.js";
import { TomeSystem } from "./systems/tome.js";
import { MobManagerSystem } from "./systems/mob-manager.js";
import { ConsumableSystem } from "./systems/consumables.js";

// === Batch 4 System Imports ===
import { ArtifactCrateSystem } from "./systems/artifact-crates.js";
import { CompanionCrateSystem } from "./systems/companion-crates.js";
import { HeroSatchelSystem } from "./systems/hero-satchel.js";
import { BossFightSystem } from "./systems/boss-fights.js";
import { ArmoredElytraSystem } from "./systems/armored-elytra.js";
import { LuckBuffSystem } from "./systems/luck-buffs.js";
import { DayCounterSystem } from "./systems/day-counter.js";

// === Batch 5 System Imports (Social/Economy Expansion) ===
import { CoinSystem } from "./systems/coins.js";
import { GuildSystem } from "./systems/guild.js";
import { GachaSystem } from "./systems/gacha.js";
import { FriendSystem } from "./systems/friends.js";
import { DuelSystem } from "./systems/duel.js";
import { PantrySystem } from "./systems/pantry.js";

// === Batch 6 System Imports (Java Port Batch) ===
import { CastleDungeonSystem } from "./systems/castle-dungeon.js";
import { CodexBestiarySystem } from "./systems/codex-bestiary.js";
import { DifficultySystem } from "./systems/difficulty.js";

// === Batch 7 System Imports (175-Feature Expansion) ===
import { CombatComboSystem } from "./systems/combat-combo.js";
import { CrateStreakSystem } from "./systems/crate-streak.js";

// === Batch 8 System Imports (Java Conversation Port) ===
import { CampfireHealSystem } from "./systems/campfire-heal.js";
import { FoxTamingSystem } from "./systems/fox-taming.js";
import { ReputationSystem } from "./systems/reputation.js";
import { ClaimRewardSystem } from "./systems/claim-rewards.js";
import { ClassAffinitySystem } from "./systems/class-affinity.js";
import { BuddySystem } from "./systems/buddy.js";

// === Batch 9 System Imports (Spirit Systems + Craftforever) ===
import { SpiritWeaponSystem } from "./systems/spirit-weapons.js";
import { SpiritRaidSystem } from "./systems/spirit-raids.js";
import { SpiritTomeSystem } from "./systems/spirit-tome.js";
import { DualSwordsmanSystem } from "./systems/dual-swordsman.js";
import { SpiritToolSystem } from "./systems/spirit-tools.js";
import { ForgingSystem } from "./systems/forging.js";
import { NodeSystem } from "./systems/nodes.js";
import { MountTrainingSystem } from "./systems/mount-training.js";
import { HeistSystem } from "./systems/heist.js";
import { TamedBondSystem } from "./systems/tamed-bond.js";
import { CraftForeverSystem } from "./systems/craftforever.js";
import { CompanionEvolutionSystem } from "./systems/companion-evolution.js";
import { CrateAnimationSystem } from "./systems/crate-animation.js";
import { TrimAbilitySystem } from "./systems/trim-abilities.js";
import { PhoenixCodexSystem } from "./systems/phoenix-codex.js";
import { FusionFunnelSystem } from "./systems/fusion-funnel.js";
import { BlockColorSystem } from "./systems/block-colors.js";
import { AccessoryTickSystem } from "./systems/accessory-tick.js";
import { RaidSystem } from "./systems/raids.js";
import { MobVariantSystem } from "./systems/mob-variants.js";
import { LaborerSystem } from "./systems/laborers.js";
import { CompetitionSystem } from "./systems/competition.js";
import { PetDuelSystem } from "./systems/pet-duel.js";
// import { ReaperSystem } from "./systems/reaper.js"; // BUG FIX 5: Duplicate of ReputationSystem
import { ChronoShardSystem } from "./systems/chrono-shard.js";
import { ConvergenceSystem } from "./systems/convergence.js";
import { BountyBoardSystem } from "./systems/bounty-board.js";
import { NewcomerSystem } from "./systems/newcomer.js";
import { NewsTickerSystem } from "./systems/news-ticker.js";
import { TitleSystem } from "./systems/title-system.js";
import { TrophySystem } from "./systems/trophy.js";
import { DreamSurgeSystem } from "./systems/dream-surge.js";
import { MoonInfoSystem } from "./systems/moon-info.js";

// Constants (replaces scoreboard constants)
export const CONSTANTS = {
  TICKS_PER_SECOND: 20,
  TICKS_PER_DAY_CYCLE: 24000,
  REAL_TICKS_PER_DAY: 72000,
  DAYLIGHT_ADVANCE_INTERVAL: 3,
  SLEEP_THRESHOLD_TICKS: 100,
  SLEEP_POLL_INTERVAL: 5,
  WATCHDOG_INTERVAL: 100,
  MOON_PHASES: 8,
  DREAMING_REALM_X: 100000,
  DREAMING_REALM_Z: 0,
};

// === SYSTEM INSTANTIATION ===
const eventBridge = new EventBridge();
const daylightManager = new DaylightManager(eventBridge);

// Make daylightManager accessible globally for systems that need day/moon
globalThis._fc_daylight = daylightManager;

// Core systems (no dependencies)
const tombSystem = new TombSystem(eventBridge);
const seasonSystem = new SeasonSystem(daylightManager);
const dreamsSystem = new DreamsSystem(eventBridge);
const healthBarSystem = new HealthBarSystem();
const achievementSystem = new AchievementSystem(eventBridge);
const loreSystem = new LoreSystem(eventBridge);
const worldEventSystem = new WorldEventSystem(eventBridge);
const calendarSystem = new CalendarSystem(seasonSystem);
const patinaSystem = new PatinaSystem();
const briefingSystem = new BriefingSystem(seasonSystem, eventBridge);
const campfireSystem = new CampfireStorySystem();

// Batch 1 systems
const caveDarknessSystem = new CaveDarknessSystem();
const arrowSystem = new ArrowSystem(eventBridge);
const movementSystem = new MovementSystem();
const cropHarvestSystem = new CropHarvestSystem(eventBridge);
const moonSystem = new MoonSystem(eventBridge);
const luckBuffSystem = new LuckBuffSystem(eventBridge, moonSystem);
const anecdoteSystem = new AnecdoteSystem(eventBridge);
const omenSystem = new OmenSystem(eventBridge);
const tamedProtectionSystem = new TamedProtectionSystem(eventBridge);

// Combat systems
const weaponMasterySystem = new WeaponMasterySystem(eventBridge);
const weaponClassSystem = new WeaponClassSystem(eventBridge);
const artifactAbilitySystem = new ArtifactAbilitySystem(eventBridge);
const armorMasterySystem = new ArmorMasterySystem(eventBridge);
const trimEffectSystem = new TrimEffectSystem(eventBridge);
const worldBossSystem = new WorldBossSystem(eventBridge);
const nightTerrorSystem = new NightTerrorSystem(eventBridge);
const healerSystem = new HealerSystem(eventBridge);
const shieldSystem = new ShieldSystem(eventBridge);

// World systems
const guidestoneSystem = new GuidestoneSystem(eventBridge);
const portalDialSystem = new PortalDialSystem(eventBridge, guidestoneSystem);
const dreamingRealmSystem = new DreamingRealmSystem(eventBridge);
const housingSystem = new HousingSystem();
const cookingSystem = new CookingSystem();
const glyphforgeSystem = new GlyphforgeSystem(eventBridge);
const inscriptionStoneSystem = new InscriptionStoneSystem(eventBridge);
const xpMagnetSystem = new XpMagnetSystem();
const runeSystem = new RuneSystem(eventBridge);
const journalSystem = new JournalSystem(eventBridge);
const luckSystem = new LuckSystem(eventBridge);

// Batch 2 systems
const biomeSystem = new BiomeSystem(eventBridge);
const biomeMasterySystem = new BiomeMasterySystem(eventBridge, biomeSystem);
const prospectSystem = new ProspectSystem(eventBridge, movementSystem);
const forageSystem = new ForageSystem(eventBridge, movementSystem);
const milestoneSystem = new MilestoneSystem(eventBridge);
const statsSystem = new StatsSystem(eventBridge);
const dreamEchoSystem = new DreamEchoSystem(eventBridge);
const bottleSystem = new BottleSystem(eventBridge, biomeSystem);
const potionSystem = new PotionSystem(eventBridge);
const transmuteSystem = new TransmuteSystem(eventBridge);

// Batch 3 systems
const constellationSystem = new ConstellationSystem(eventBridge);
const dungeonSystem = new DungeonSystem(eventBridge);
const encounterSystem = new EncounterSystem(eventBridge, biomeSystem);
const harmonizeSystem = new HarmonizeSystem(eventBridge);
const villageSystem = new VillageSystem(eventBridge);
const tomeSystem = new TomeSystem(eventBridge);
const mobManagerSystem = new MobManagerSystem(eventBridge);
const consumableSystem = new ConsumableSystem(eventBridge);

// Batch 4 systems
const artifactCrateSystem = new ArtifactCrateSystem(eventBridge);
const companionCrateSystem = new CompanionCrateSystem(eventBridge);
const heroSatchelSystem = new HeroSatchelSystem(eventBridge);
const bossFightSystem = new BossFightSystem(eventBridge);
const armoredElytraSystem = new ArmoredElytraSystem(eventBridge);
const dayCounterSystem = new DayCounterSystem(eventBridge);

// Loot/crate systems
const treasureSystem = new TreasureSystem(eventBridge);
const mobCrateSystem = new MobCrateSystem(eventBridge);
const structureCrateSystem = new StructureCrateSystem(eventBridge);
const fishingCrateSystem = new FishingCrateSystem(eventBridge);
const harvestCrateSystem = new HarvestCrateSystem(eventBridge);

// Social/economy systems
const companionSystem = new CompanionSystem(eventBridge);
const questSystem = new QuestSystem(eventBridge);
const bountySystem = new BountySystem(eventBridge);
const satchelSystem = new SatchelSystem();
const partySystem = new PartySystem(eventBridge);
const professionSystem = new ProfessionSystem(eventBridge);
const blackMarketSystem = new BlackMarketSystem();
const advantageTreeSystem = new AdvantageTreeSystem(eventBridge);

// Batch 5 systems (social/economy expansion)
const coinSystem = new CoinSystem(eventBridge);
const guildSystem = new GuildSystem(eventBridge, coinSystem);
const gachaSystem = new GachaSystem(eventBridge, coinSystem);
const friendSystem = new FriendSystem(eventBridge, coinSystem);
const duelSystem = new DuelSystem(eventBridge);
const pantrySystem = new PantrySystem(eventBridge);

// Batch 6 systems (Java port batch)
const castleDungeonSystem = new CastleDungeonSystem(eventBridge);
const codexBestiarySystem = new CodexBestiarySystem(eventBridge);
const difficultySystem = new DifficultySystem(eventBridge);

// Batch 7 systems (175-feature expansion)
const combatComboSystem = new CombatComboSystem(eventBridge);
const crateStreakSystem = new CrateStreakSystem(eventBridge);

// Batch 8 systems (Java conversation port)
const campfireHealSystem = new CampfireHealSystem();
const foxTamingSystem = new FoxTamingSystem(eventBridge);
const reputationSystem = new ReputationSystem(eventBridge);
const claimRewardSystem = new ClaimRewardSystem(eventBridge);
const classAffinitySystem = new ClassAffinitySystem(eventBridge);
const buddySystem = new BuddySystem(eventBridge);

// Batch 9 systems (Spirit Systems + Craftforever)
const spiritWeaponSystem = new SpiritWeaponSystem(eventBridge, weaponMasterySystem, glyphforgeSystem);
const spiritRaidSystem = new SpiritRaidSystem(eventBridge, spiritWeaponSystem);
const spiritTomeSystem = new SpiritTomeSystem(eventBridge, spiritWeaponSystem);
const dualSwordsmanSystem = new DualSwordsmanSystem(eventBridge, spiritWeaponSystem);
const spiritToolSystem = new SpiritToolSystem(eventBridge);
const forgingSystem = new ForgingSystem(eventBridge);
const nodeSystem = new NodeSystem(eventBridge, biomeSystem);
const mountTrainingSystem = new MountTrainingSystem(eventBridge, buddySystem);
const heistSystem = new HeistSystem(eventBridge);
const tamedBondSystem = new TamedBondSystem(eventBridge, moonSystem);
const craftForeverSystem = new CraftForeverSystem(eventBridge);
const companionEvolutionSystem = new CompanionEvolutionSystem(eventBridge);
const crateAnimationSystem = new CrateAnimationSystem(eventBridge);
const trimAbilitySystem = new TrimAbilitySystem(eventBridge);
const raidSystem = new RaidSystem(eventBridge);
const mobVariantSystem = new MobVariantSystem(eventBridge);
const laborerSystem = new LaborerSystem(eventBridge);
const competitionSystem = new CompetitionSystem(eventBridge);
const petDuelSystem = new PetDuelSystem(eventBridge);
// const reaperSystem = new ReaperSystem(eventBridge); // BUG FIX 5: Duplicate of reputationSystem
const chronoShardSystem = new ChronoShardSystem(eventBridge);
const convergenceSystem = new ConvergenceSystem(eventBridge);
const bountyBoardSystem = new BountyBoardSystem(eventBridge);
const newcomerSystem = new NewcomerSystem(eventBridge);
const newsTickerSystem = new NewsTickerSystem(eventBridge);
const titleSystem = new TitleSystem(eventBridge);
const trophySystem = new TrophySystem(eventBridge);
const dreamSurgeSystem = new DreamSurgeSystem(eventBridge);
const moonInfoSystem = new MoonInfoSystem();

// GUI manager (references systems for menu callbacks)
const guiManager = new GUIManager({
  companions: companionSystem,
  quests: questSystem,
  guidestone: guidestoneSystem,
  cooking: cookingSystem,
  satchel: satchelSystem,
  blackMarket: blackMarketSystem,
  housing: housingSystem,
  party: partySystem,
  advantages: advantageTreeSystem,
  dreams: dreamsSystem,
  achievements: achievementSystem,
  lore: loreSystem,
  journal: journalSystem,
  glyphforge: glyphforgeSystem,
  luck: luckSystem,
  armorMastery: armorMasterySystem,
  moon: moonSystem,
  anecdotes: anecdoteSystem,
  portalDial: portalDialSystem,
  stats: statsSystem,
  bottles: bottleSystem,
  transmute: transmuteSystem,
  milestones: milestoneSystem,
  biomeMastery: biomeMasterySystem,
  constellations: constellationSystem,
  village: villageSystem,
  heroSatchel: heroSatchelSystem,
  guild: guildSystem,
  gacha: gachaSystem,
  friends: friendSystem,
  duel: duelSystem,
  pantry: pantrySystem,
  coins: coinSystem,
  castleDungeon: castleDungeonSystem,
  bestiary: codexBestiarySystem,
  difficulty: difficultySystem,
  reputation: reputationSystem,
  classAffinity: classAffinitySystem,
  buddy: buddySystem,
  claimRewards: claimRewardSystem,
  spiritWeapons: spiritWeaponSystem,
  spiritRaids: spiritRaidSystem,
  spiritTome: spiritTomeSystem,
  spiritTools: spiritToolSystem,
  forging: forgingSystem,
  nodes: nodeSystem,
  mountTraining: mountTrainingSystem,
  heist: heistSystem,
  codex: null, // set below
});

// Codex system (needs system references, so created after GUI manager)
const codexSystem = new CodexSystem(eventBridge, {
  advantages: advantageTreeSystem,
  constellations: constellationSystem,
  journal: journalSystem,
  lore: loreSystem,
  stats: statsSystem,
  guild: guildSystem,
  bestiary: codexBestiarySystem,
});
guiManager.systems.codex = codexSystem;

// Phoenix Codex (master menu item — needs guiManager + guidestone)
const phoenixCodexSystem = new PhoenixCodexSystem(eventBridge, guiManager, guidestoneSystem);
const blockColorSystem = new BlockColorSystem(eventBridge);
const fusionFunnelSystem = new FusionFunnelSystem(eventBridge);

// Accessory Tick (72 passive accessory effects — DR, potions, conditionals)
const accessoryTickSystem = new AccessoryTickSystem(eventBridge);

// === INITIALIZATION ===
function onWorldInitialize() {
  console.log("[Forevercraft] Initializing Bedrock Edition v1.0.0...");
  initScoreboards();
  const overworld = world.getDimension("overworld");
  overworld.runCommandAsync("gamerule sendcommandfeedback false");
  overworld.runCommandAsync("gamerule playerssleepingpercentage 200");
  artifactAbilitySystem.initHunterSystem();
  console.log("[Forevercraft] Initialization complete.");
}

// === MAIN TICK (runs every tick) ===
let tickCount = 0;
let lastDay = -1;
function mainTick() {
  const players = world.getAllPlayers();
  if (players.length === 0) return;
  tickCount++;

  // Every tick
  daylightManager.tick();
  healthBarSystem.tick(players);
  weaponClassSystem.tick(players);
  prospectSystem.tickMining(players);
  forageSystem.tickGathering(players);
  dungeonSystem.tick();
  castleDungeonSystem.tick();
  classAffinitySystem.tick(players); // Self-gates to 72-tick interval internally
  spiritRaidSystem.tick(); // Boss AI + combat needs every tick when active

  // Every 2 ticks (10 times/second)
  if (tickCount % 2 === 0) {
    dreamingRealmSystem.tick(players);
    xpMagnetSystem.tick(players);
    artifactAbilitySystem.tickDoubleJump(players); // Cloudstep Boots responsive detection
  }

  // Every 5 ticks (4 times/second)
  if (tickCount % 5 === 0) {
    bountySystem.tick(players);
    foxTamingSystem.tick(players);
  }

  // Every 20 ticks (1 second) — COMBAT-CRITICAL systems only
  if (tickCount % 20 === 0) {
    artifactAbilitySystem.tick(players);
    artifactAbilitySystem.tickHunterCooldowns(players);
    // Accessory passive effects (DR, potions, conditionals) — every 2 seconds
    // Accessory death save cooldown ticking — every 1 second
    for (const p of players) accessoryTickSystem.tickCooldowns(p);
    if (tickCount % 40 === 0) {
      for (const p of players) accessoryTickSystem.tick(p);
    }
    weaponMasterySystem.tick(players);
    armorMasterySystem.tick(players);
    partySystem.tick(players);
    healerSystem.tick(players);
    shieldSystem.tick(players);
    runeSystem.tick(players);
    for (const p of players) cookingSystem.tickBuffs(p);
    movementSystem.tick(players);
    mobManagerSystem.tick(players);
    bossFightSystem.tick();
    luckBuffSystem.tick(players);
    duelSystem.tick(players);
    spiritWeaponSystem.tick(players);
    dualSwordsmanSystem.tick(players);
    forgingSystem.tick(players);
    fusionFunnelSystem.tick(players);
    mountTrainingSystem.tick(players);
    heistSystem.tick(players);
    trimAbilitySystem.tick(players);
    companionEvolutionSystem.tick(players);
    raidSystem.tick();
    petDuelSystem.tickCooldowns(players);
  }

  // Every 2 ticks — crate animation (smooth display)
  if (tickCount % 2 === 0) {
    crateAnimationSystem.tick();
  }

  // Every 40 ticks (2 seconds) — MEDIUM-PRIORITY systems
  if (tickCount % 40 === 0) {
    companionSystem.tick(players);
    inscriptionStoneSystem.tick(players);
    housingSystem.tick(players);
    luckSystem.tick(players);
    harmonizeSystem.tick(players);
    trimEffectSystem.tick(players);
    patinaSystem.tick(players);
    glyphforgeSystem.tick(players);
    caveDarknessSystem.tick(players);
    potionSystem.tick();
    prospectSystem.tickSpawn(players);
    forageSystem.tickSpawn(players);
    buddySystem.tick(players);
    campfireHealSystem.tick(players);
    spiritToolSystem.tick(players);
    laborerSystem.tick(players);
    // reaperSystem.tick(players); // BUG FIX 5: Using reputationSystem instead
    guildSystem.tick(players);
    friendSystem.tick(players);
  }

  // Every 60 ticks (3 seconds) — ATMOSPHERIC/LOW-PRIORITY systems
  if (tickCount % 60 === 0) {
    moonSystem.tick(players);
    omenSystem.tick(players);
    dayCounterSystem.tick();
    worldEventSystem.tick();
    convergenceSystem.tick(players);
    dreamSurgeSystem.tick(players);
  }

  // Every 80 ticks (~4 seconds) — Dream echoes (infrequent)
  if (tickCount % 80 === 0) {
    dreamEchoSystem.tick(players);
  }

  // Every 100 ticks (5 seconds) — STAGGERED across 5 offsets to prevent frame spikes
  // Instead of 16 systems all firing on tick 0, spread across ticks 0/20/40/60/80
  if (tickCount % 100 === 0) {
    worldBossSystem.tick();
    questSystem.tick(players);
    biomeSystem.tick(players);
    combatComboSystem.tick();
  }
  if (tickCount % 100 === 20) {
    nightTerrorSystem.tick(players);
    tamedProtectionSystem.tick(players);
    biomeMasterySystem.tick(players);
    crateStreakSystem.tick();
  }
  if (tickCount % 100 === 40) {
    campfireSystem.tick(players);
    tamedBondSystem.tick(players);
    villageSystem.tick(players);
    competitionSystem.tick();
  }
  if (tickCount % 100 === 60) {
    heroSatchelSystem.tick(players);
    craftForeverSystem.tick(players);
    bountyBoardSystem.tick();
  }
  if (tickCount % 100 === 80) {
    mobVariantSystem.tick(players);
  }

  // Every 200 ticks (10 seconds)
  if (tickCount % 200 === 0) {
    structureCrateSystem.tick();
    journalSystem.tick(players);
    encounterSystem.tick(players);
    armoredElytraSystem.tick();
  }

  // Every 1200 ticks (1 minute)
  if (tickCount % 1200 === 0) {
    seasonSystem.tick();
    calendarSystem.tick();
    professionSystem.tick(players);
    milestoneSystem.tick();
    for (const p of players) companionSystem.checkExpeditions(p);
    briefingSystem.tickMorningAnnouncement();
    reputationSystem.tick(players);
    claimRewardSystem.tick();
    nodeSystem.tick(players);
    newsTickerSystem.tick();
    trophySystem.tick(players);
    for (const p of players) titleSystem.checkUnlocks(p);
    StorageManager.cleanup(); // Evict stale cached instances

    // Day change detection — triggers daily resets
    const currentDay = (globalThis._fc_daylight?.getDay?.() ?? 0);
    if (lastDay >= 0 && currentDay !== lastDay) {
      questSystem.dailyReset();
      friendSystem.onDayChange();
      blackMarketSystem.dailyRefresh?.();
      bountySystem.dailyRefresh?.();
      classAffinitySystem.dailyReset?.();       // Reset 14 daily affinity caps
      dungeonSystem.dailyReset?.();             // Reset floor counter
      reputationSystem.dailyReset?.();          // Reset daily trade renown cap
      // reaperSystem.dailyReset?.();              // BUG FIX 5: Using reputationSystem instead
      buddySystem.dailyReset?.();               // Reset feed count + summon count
      const moonPhase = daylightManager.getMoonPhase();
      const season = seasonSystem.getCurrentSeason?.() || "spring";
      calendarSystem.onDayChange?.(currentDay, moonPhase, season); // Calendar event checks
      moonSystem.onDawn?.(players);             // Harvest moon cleanup (needs players array)
      eventBridge.emit("day_change", { day: currentDay });
    }
    lastDay = currentDay;
  }

  // Per-player checks
  for (const player of players) {
    if (!player.hasTag("ec.joined")) {
      onPlayerJoin(player);
    }
  }

  // Reset tick counter to avoid overflow
  if (tickCount >= 72000) tickCount = 0;
}

function onPlayerJoin(player) {
  player.addTag("ec.joined");
  player.sendMessage("§6Welcome to §lForevercraft§r§6!");
  const storage = StorageManager.forPlayer(player);
  const isFirstJoin = !storage.get("initialized");
  if (isFirstJoin) {
    storage.set("initialized", true);
    storage.set("dream_rate", 0);
    storage.set("artifacts_collected", 0);
    storage.set("lore_collected", 0);
    console.log(`[Forevercraft] New player initialized: ${player.name}`);
    // Prompt difficulty selection for new players
    eventBridge.emit("player_first_join", player);
  }
  // Track player for milestone system
  eventBridge.emit("player_join", player);
  // Crash recovery for dreaming realm
  dreamingRealmSystem.crashRecovery(player);
  // Crash recovery for dream rate (reapply permanent effects lost on crash/relog)
  dreamsSystem.reapplyPermanentDR(player);
  // Reapply accessory DR modifiers (lost on relog)
  accessoryTickSystem.tick(player);
  // Restore guild state
  guildSystem.onPlayerJoin?.(player);
  // Restore party state
  partySystem.onPlayerJoin?.(player);
  // Restore friend state (daily heart tracking)
  friendSystem.onPlayerJoin?.(player);
  // Show login briefing
  briefingSystem.showBriefing(player);
  // Newcomer starter selection (first join only)
  if (isFirstJoin) {
    system.runTimeout(() => newcomerSystem.showStarterSelection(player), 100); // 5s delay
  }
}

// Player leave cleanup — prevent memory leaks from cached Map entries
world.afterEvents.playerLeave.subscribe((event) => {
  const playerId = event.playerId;
  // Clean up per-player Maps in systems that track transient state
  spiritWeaponSystem.cooldowns.delete(playerId);
  spiritWeaponSystem.passiveState.delete(playerId);
  dualSwordsmanSystem.state.delete(playerId);
  mountTrainingSystem.rideState.delete(playerId);
  heistSystem.active.delete(playerId);
  tamedBondSystem.pendingMementos.delete(playerId);
  buddySystem.playerState.delete(playerId);
  accessoryTickSystem.onPlayerLeave(playerId);
  combatComboSystem.combos?.delete(playerId);
  weaponMasterySystem.partySizeCache?.delete(playerId);
  crateStreakSystem.streaks?.delete(playerId);
  // Extended cleanup — all remaining per-player Maps
  dreamingRealmSystem.activeDreamers?.delete(playerId);
  transmuteSystem.sessions?.delete(playerId);
  forgingSystem.sessions?.delete(playerId);
  forgingSystem.trials?.delete(playerId);
  spiritToolSystem.activeTools?.delete(playerId);
  portalDialSystem.cooldowns?.delete(playerId);
  encounterSystem.activeEncounters?.delete(playerId);
  nightTerrorSystem.activeEncounters?.delete(playerId);
  inscriptionStoneSystem.stones?.delete(playerId);
  petDuelSystem.pendingDuels?.delete(playerId);
  petDuelSystem.activeDuels?.delete(playerId);
  glyphforgeSystem.forges?.delete(playerId);
  nodeSystem.activeNodes?.delete(playerId);
  prospectSystem.miningPlayers?.delete(playerId);
  forageSystem.gatheringPlayers?.delete(playerId);
  codexSystem.lastOpenTick?.delete(playerId);
  partySystem.comboCooldowns?.delete(playerId);
  // StorageManager cache cleanup happens in periodic cleanup()
});

// === BOOTSTRAP ===
let initialized = false;
system.runInterval(() => {
  if (!initialized) {
    onWorldInitialize();
    initialized = true;
  }
  mainTick();
}, 1);

// === EVENT REGISTRATION ===
eventBridge.registerAll();

// Scriptevent handler (for mcfunction ↔ Script API bridge)
// === SCRIPTEVENT DISPATCH (O(1) hash lookup instead of 55+ if/else comparisons) ===
const SCRIPTEVENT_HANDLERS = {
  "forevercraft:interact":        (p, m) => eventBridge.handleInteraction(p),
  "forevercraft:open_gui":        (p, m) => guiManager.openByName(p, m),
  "forevercraft:guidestone_place": (p) => guidestoneSystem.register(p, `Waypoint ${Math.floor(p.location.x)}, ${Math.floor(p.location.z)}`),
  "forevercraft:give_forge":      (p) => glyphforgeSystem.giveForgeBlock(p),
  "forevercraft:tidal_horn":      (p) => artifactAbilitySystem.useTidalHorn(p),
  "forevercraft:harvest_caller":  (p) => artifactAbilitySystem.useHarvestCaller(p),
  "forevercraft:legendary_smash": (p) => artifactAbilitySystem.legendarySmash(p),
  "forevercraft:moon_check":      (p) => moonSystem.openMenu(p),
  "forevercraft:guild_accept":    (p) => guildSystem.acceptInvite(p),
  "forevercraft:guild_kick_vote": (p) => guildSystem.startKickVote(p),
  "forevercraft:dungeon_descend": (p) => dungeonSystem.handleDescentRequest(p),
  "forevercraft:fountain":        (p) => gachaSystem.openMenu(p),
  "forevercraft:duel_invite":     (p, m) => duelSystem.sendChallenge(p, m, "open_world"),
  "forevercraft:duel_accept":     (p) => duelSystem.acceptChallenge(p),
  "forevercraft:friend_request":  (p, m) => friendSystem.showSendRequest(p, m),
  "forevercraft:coins":           (p) => coinSystem.showBalance(p),
  "forevercraft:castle_dungeon":  (p) => castleDungeonSystem.openMenu(p),
  "forevercraft:difficulty":      (p) => difficultySystem.openMenu(p),
  "forevercraft:bestiary":        (p) => codexBestiarySystem.openBestiary(p),
  "forevercraft:guild_hearthstone": (p) => guildSystem.useHearthstone(p),
  "forevercraft:reputation":      (p) => { const r = reputationSystem.getDisplay(p); p.sendMessage(`§e§lAlignment: ${r.title}\n§7Infamy: §c${r.infamy} §7| Renown: §a${r.renown}`); },
  "forevercraft:buddy":           (p) => buddySystem.showStatus(p),
  "forevercraft:buddy_catalogue": (p) => buddySystem.openCatalogue(p),
  "forevercraft:buddy_pack":      (p) => buddySystem.openPackMule(p),
  "forevercraft:bond":            (p) => tamedBondSystem.showStatus(p),
  "forevercraft:affinity":        (p) => classAffinitySystem.showOverview(p),
  "forevercraft:claim":           (p) => { const c = claimRewardSystem.countUnclaimed(p); p.sendMessage(c.total > 0 ? `§eYou have §l${c.total}§r§e unclaimed rewards!` : "§7No unclaimed rewards."); },
  "forevercraft:spirit_status":   (p) => spiritWeaponSystem.showStatus(p),
  "forevercraft:spirit_tome":     (p) => spiritTomeSystem.showTomeStatus(p),
  "forevercraft:spirit_raid":     (p) => spiritRaidSystem.openMenu(p),
  "forevercraft:dream_crystal":   (p) => spiritWeaponSystem.useDreamCrystal(p),
  "forevercraft:spirit_tool":     (p) => spiritToolSystem.showStatus(p),
  "forevercraft:forge":           (p) => forgingSystem.openForge(p),
  "forevercraft:forge_input":     (p) => forgingSystem.forgeInput(p),
  "forevercraft:artifact_forge":  (p) => forgingSystem.openArtifactForge(p),
  "forevercraft:fusion_funnel":   (p) => fusionFunnelSystem.openMenu(p),
  "forevercraft:fusion_input":    (p) => fusionFunnelSystem.fusionInput(p, "click"),
  "forevercraft:fusion_stoke":    (p) => fusionFunnelSystem.fusionInput(p, "stoke"),
  "forevercraft:fusion_cool":     (p) => fusionFunnelSystem.fusionInput(p, "cool"),
  "forevercraft:trials":          (p) => forgingSystem.openTrials(p),
  "forevercraft:mount_training":  (p) => mountTrainingSystem.showBondStatus(p),
  "forevercraft:craftforever":    (p) => craftForeverSystem.showStatus(p),
  "forevercraft:cf_trials":       (p) => craftForeverSystem.openTrialMenu(p),
  "forevercraft:cf_forge":        (p) => craftForeverSystem.openForge(p),
  "forevercraft:evolve":          (p, m) => companionEvolutionSystem.tryEvolve(p, m),
  "forevercraft:treasure_settings": (p) => treasureSystem.openSettings(p),
  "forevercraft:artisan":         (p) => nodeSystem.showArtisanStatus(p),
  "forevercraft:raid":            (p) => raidSystem.openMenu(p),
  "forevercraft:laborers":        (p) => laborerSystem.openMenu(p),
  "forevercraft:competition":     (p) => competitionSystem.openMenu(p),
  "forevercraft:pet_duel":        (p, m) => petDuelSystem.challenge(p, m),
  "forevercraft:chrono_shard":    (p) => chronoShardSystem.openMenu(p),
  "forevercraft:bounty_board":    (p) => bountyBoardSystem.openBoard(p),
  "forevercraft:titles":          (p) => titleSystem.openMenu(p),
  "forevercraft:trophies":        (p) => trophySystem.showTrophies(p),
  "forevercraft:dream_surge":     () => dreamSurgeSystem.activate(),
  "forevercraft:moon_info":       (p) => moonInfoSystem.showMoonInfo(p),
  "forevercraft:news":            (p) => newsTickerSystem.showNews(p),
  "forevercraft:alignment":       (p) => { const r = reputationSystem.getDisplay(p); p.sendMessage(`§e§lAlignment: ${r.title}\n§7Infamy: §c${r.infamy} §7| Renown: §a${r.renown}`); },
  "forevercraft:heist":           (p) => heistSystem.openMenu(p),
  "forevercraft:phoenix_codex":   (p) => phoenixCodexSystem.giveCodex(p),
  "forevercraft:hearthstone":     (p) => housingSystem.placeHearthstone(p, guidestoneSystem),
  "forevercraft:warp_home":       (p) => housingSystem.warpHome(p),
};

system.afterEvents.scriptEventReceive.subscribe((event) => {
  const handler = SCRIPTEVENT_HANDLERS[event.id];
  if (handler && event.sourceEntity) {
    handler(event.sourceEntity, event.message);
  }
});

// Accessory death save — intercept lethal hits (Ring of Undying, Soul Protection, Heart of the Void)
world.afterEvents.entityHurt.subscribe((event) => {
  const entity = event.hurtEntity;
  if (entity?.typeId !== "minecraft:player") return;
  const hp = entity.getComponent("minecraft:health");
  if (!hp || hp.currentValue > 0) return; // Not dead yet or already handled
  // Player is at 0 HP — check for death save accessory
  const healAmount = accessoryTickSystem.checkDeathSave(entity);
  if (healAmount > 0) {
    try {
      hp.setCurrentValue(healAmount);
      entity.runCommandAsync(`effect @s regeneration 5 1`);
    } catch {}
  }
});

// Player death listener — tomb system handles totem saves for duel/castle/heist
world.afterEvents.entityDie.subscribe((event) => {
  const dead = event.deadEntity;
  if (dead?.typeId === "minecraft:player") {
    // Try Emberheart rebirth FIRST — if it saves the player, skip tomb
    const reborn = companionEvolutionSystem?.tryEmberheartRebirth?.(dead);
    if (!reborn) {
      tombSystem.onPlayerDeath(dead);
    }
    castleDungeonSystem.onPlayerDeath(dead);
    spiritWeaponSystem.onPlayerDeath(dead);
    buddySystem.onPlayerDeath?.(dead);           // Best buddy death penalty
    partySystem.onPlayerDeath?.(dead);           // Party death handling
    companionSystem.onPlayerDeath?.(dead);       // Pet death memento
    eventBridge.emit("player_death", { player: dead });
    // Check if all raid players are dead
    if (spiritRaidSystem.active) {
      let allDead = true;
      for (const pid of spiritRaidSystem.active.playerIds) {
        try {
          const p = world.getEntity(pid);
          if (p?.getComponent("minecraft:health")?.currentValue > 0) allDead = false;
        } catch (e) {}
      }
      if (allDead) spiritRaidSystem.onAllPlayersDead();
    }
  }

  // Non-player entity death — patron mob rewards
  if (dead && dead.typeId !== "minecraft:player" && dead.hasTag("ec.patron")) {
    const killer = event.damageSource?.damagingEntity;
    if (killer?.typeId === "minecraft:player") {
      mobVariantSystem.onPatronKill(killer, dead);
    }
  }
});

// Block break listener for inscription stone cleanup + ore ingredient drops
const ORE_BLOCKS = new Set([
  "minecraft:iron_ore", "minecraft:deepslate_iron_ore",
  "minecraft:coal_ore", "minecraft:deepslate_coal_ore",
  "minecraft:gold_ore", "minecraft:deepslate_gold_ore",
  "minecraft:diamond_ore", "minecraft:deepslate_diamond_ore",
  "minecraft:copper_ore", "minecraft:deepslate_copper_ore",
  "minecraft:redstone_ore", "minecraft:deepslate_redstone_ore",
  "minecraft:emerald_ore", "minecraft:deepslate_emerald_ore",
  "minecraft:lapis_ore", "minecraft:deepslate_lapis_ore",
]);
world.afterEvents.playerBreakBlock.subscribe((event) => {
  inscriptionStoneSystem.onBlockBreak(event.block);

  // Emit block_mined for spirit tome quest tracking
  eventBridge.emit("block_mined", { player: event.player });

  // Accessory fortune bonus drops
  const blockId = event.brokenBlockPermutation?.type?.id;
  if (blockId) {
    accessoryTickSystem.onBlockBreak(event.player, blockId, event.block.location);
  }

  // 3% forging ingredient drop on ore mining
  if (blockId && ORE_BLOCKS.has(blockId) && Math.random() < 0.03) {
    const FORGING_ITEMS = [
      "minecraft:iron_nugget", "minecraft:gold_nugget", "minecraft:quartz",
      "minecraft:prismarine_shard", "minecraft:amethyst_shard",
    ];
    const item = FORGING_ITEMS[Math.floor(Math.random() * FORGING_ITEMS.length)];
    try { event.player.runCommandAsync(`give @s ${item} 1`); } catch {}
    event.player.sendMessage("§a§l+ §r§7Found a forging ingredient!");
    eventBridge.emit("ore_mined", { player: event.player });
  }

  // Artifact Forge Expansion: 0.5% chance for artifact materials from ores
  forgingSystem.onOreMined(event.player, blockId);
});

// === MISSING EVENT EMITTERS (Spirit Tome quest tracking) ===

// Trade detection — emit trade_completed when player interacts with villager
world.afterEvents.playerInteractWithEntity.subscribe((event) => {
  const target = event.target;
  if (target?.typeId === "minecraft:villager" || target?.typeId === "minecraft:wandering_trader") {
    eventBridge.emit("trade_completed", { player: event.player });
  }
});

// Sleep detection — emit sleep_complete on sleep skip
eventBridge.on("day_change", () => {
  // Sleep skip emits day_change; emit sleep_complete for all players
  for (const p of world.getAllPlayers()) {
    eventBridge.emit("sleep_complete", { player: p });
  }
});

// === OPTIONAL EVENT LISTENERS (guard for API availability) ===

// Item Drop Prevention — Soulbound spirit weapons can't be dropped
if (world.afterEvents.entityItemDropAfter) world.afterEvents.entityItemDropAfter.subscribe((event) => {
  try {
    const item = event.itemStack;
    const player = event.source;
    if (!player || player.typeId !== "minecraft:player") return;
    // Check if the dropped item is a soulbound spirit weapon
    const lore = item?.getLore?.() || [];
    if (lore.some(l => l.includes("Spirit Artifact") || l.includes("Soulbound"))) {
      // Return item to player
      try {
        const itemEntity = event.entity;
        if (itemEntity) itemEntity.kill();
        // Re-give via command
        player.sendMessage("§c§lSoulbound! §r§7Spirit weapons cannot be dropped.");
      } catch (err) {}
    }
  } catch (e) {}
});

// Item Pickup — Forever Coin detection (replaces polling-based pickup)
if (world.afterEvents.entityItemPickupAfter) world.afterEvents.entityItemPickupAfter.subscribe((event) => {
  try {
    const player = event.player;
    const item = event.itemStack;
    if (!player || !item) return;
    // Check for Forever Coin pickup
    if (item.typeId?.includes("forever_coin") || item.typeId?.includes("amethyst_shard")) {
      const s = StorageManager.forPlayer(player);
      const firstCoin = s.getNumber("first_coin", 0);
      if (firstCoin === 0) {
        s.setNumber("first_coin", 1);
        player.sendMessage("§d§l✦ §r§7You found your first §dForever Coin§7! These are used at the §5Fountain of Dreams§7.");
        player.playSound("random.orb");
      }
      coinSystem.addCoins(player, 1);
    }
  } catch (e) {}
});

// Entity Heal Event — Track healing for healer mastery and spirit weapon requirements
if (world.afterEvents.entityHealAfter) world.afterEvents.entityHealAfter.subscribe((event) => {
  try {
    const entity = event.entity;
    if (!entity || entity.typeId !== "minecraft:player") return;
    const healAmount = event.healAmount || 0;
    if (healAmount <= 0) return;
    // Track heals for spirit weapon requirement
    const s = StorageManager.forPlayer(entity);
    const weaponId = s.getNumber("sp_weapon_id", 0);
    if (weaponId === 10) { // Lifewoven Branch (healer)
      const heals = s.getNumber("sp_heals", 0) + Math.floor(healAmount);
      s.setNumber("sp_heals", heals);
    }
    // Track healer affinity
    eventBridge.emit("player_healed", { player: entity, amount: healAmount });
  } catch (e) {}
});

// Hook guild expedition progress into common events
eventBridge.on("ore_mined", (data) => {
  if (data.player) guildSystem.addExpeditionProgress(data.player, "mine", 1);
});
eventBridge.on("player_killed_entity", (data) => {
  if (data.player) guildSystem.addExpeditionProgress(data.player, "kill", 1);
  // Fusion Funnel: visceral reagent drops from mob kills
  if (data.player && data.entityTypeId) fusionFunnelSystem.checkMobDrop(data.player, data.entityTypeId);
});
eventBridge.on("fish_caught", (data) => {
  if (data.player) guildSystem.addExpeditionProgress(data.player, "fish", 1);
});
eventBridge.on("forage_complete", (data) => {
  if (data.player) guildSystem.addExpeditionProgress(data.player, "forage", 1);
});
eventBridge.on("cook_complete", (data) => {
  if (data.player) guildSystem.addExpeditionProgress(data.player, "cook", 1);
});
eventBridge.on("craft_complete", (data) => {
  if (data.player) guildSystem.addExpeditionProgress(data.player, "craft", 1);
});
eventBridge.on("villager_traded", (data) => {
  if (data.player) guildSystem.addExpeditionProgress(data.player, "trade", 1);
});

// === BUG FIX: grant_coins / grant_xp / reputation_change listeners ===
eventBridge.on("grant_coins", (data) => {
  if (data.player && data.amount) coinSystem.addCoins(data.player, data.amount);
});
eventBridge.on("grant_xp", (data) => {
  if (data.player && data.amount) {
    try { data.player.runCommandAsync(`xp ${data.amount} @s`); } catch {}
  }
});
eventBridge.on("reputation_change", (data) => {
  if (data.player && data.amount) reputationSystem?.addRenown?.(data.player, data.amount);
});

console.log("[Forevercraft] Script module loaded — all systems active.");
