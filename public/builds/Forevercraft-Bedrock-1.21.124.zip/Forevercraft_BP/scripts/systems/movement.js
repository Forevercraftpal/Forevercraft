/**
 * Movement Detection System — Tracks player XZ position changes.
 * Provides a shared "moving" flag (decay 5→0) consumed by prospect, forage, and lore systems.
 * Replaces Java movement/tick.mcfunction + movement/detect.mcfunction.
 */
import { StorageManager } from "../utils/storage.js";

export class MovementSystem {
  constructor() {}

  /**
   * Tick runs every 1 second (20 ticks).
   * Detects horizontal movement for each player and sets a decay-based flag.
   */
  tick(players) {
    for (const player of players) {
      const s = StorageManager.forPlayer(player);
      const pos = player.location;

      // Scale position to 0.1 block precision
      const curX = Math.floor(pos.x * 10);
      const curZ = Math.floor(pos.z * 10);

      const lastX = s.getNumber("move_lastx", 0);
      const lastZ = s.getNumber("move_lastz", 0);

      // First-time init: store position but don't flag as moving
      if (!s.get("move_init")) {
        s.set("move_init", true);
        s.set("move_lastx", curX);
        s.set("move_lastz", curZ);
        s.set("moving", 0);
        return;
      }

      // Check for horizontal movement
      if (curX !== lastX || curZ !== lastZ) {
        // Player moved — set flag to 5 (5 seconds of "moving" state)
        s.set("moving", 5);
      } else {
        // Decay by 1 per second
        const current = s.getNumber("moving", 0);
        if (current > 0) {
          s.set("moving", current - 1);
        }
      }

      // Update stored position
      s.set("move_lastx", curX);
      s.set("move_lastz", curZ);
    }
  }

  /**
   * Check if a player is currently moving (flag > 0).
   */
  isMoving(player) {
    return StorageManager.forPlayer(player).getNumber("moving", 0) > 0;
  }

  /**
   * Get raw movement flag value (0-5).
   */
  getMovementFlag(player) {
    return StorageManager.forPlayer(player).getNumber("moving", 0);
  }
}
