/**
 * Gacha System — Fountain of Eternal Dreams.
 * Replaces Java gacha/ folder (114 files).
 * Pull mechanic with tiered rewards, pity system (10/30/50), Dreamdust exchange,
 * Dreamy Star, Dreamdust Crystal, Coin of Lucidity, Convergence mode.
 */
import { world, system } from "@minecraft/server";
import { StorageManager } from "../utils/storage.js";
import { ActionFormData } from "@minecraft/server-ui";

// ─── PULL RATES (out of 1000) ──────────────────────────────

const BASE_RATES = {
  mythical:   { min: 1,   max: 2 },    // 0.2%
  exquisite:  { min: 3,   max: 52 },   // 5%
  ornate:     { min: 53,  max: 132 },  // 8%
  rare:       { min: 133, max: 282 },  // 15%
  uncommon:   { min: 283, max: 532 },  // 25%
  common:     { min: 533, max: 1000 }, // 46.8%
};

const CONVERGENCE_RATES = {
  mythical:   { min: 1,   max: 3 },    // 0.3%
  exquisite:  { min: 4,   max: 53 },
  ornate:     { min: 54,  max: 133 },
  rare:       { min: 134, max: 283 },
  uncommon:   { min: 284, max: 533 },
  common:     { min: 534, max: 1000 },
};

// Soft pity (20+ pulls) boosted rates
const SOFT_PITY_RATES = {
  mythical:   { min: 1,   max: 5 },
  exquisite:  { min: 6,   max: 90 },
  ornate:     { min: 91,  max: 220 },
  rare:       { min: 221, max: 410 },
  uncommon:   { min: 411, max: 650 },
  common:     { min: 651, max: 1000 },
};

// 10-pull pity (guaranteed Rare+)
const PITY_10_RATES = {
  mythical:   { min: 1,   max: 5 },
  exquisite:  { min: 6,   max: 110 },
  ornate:     { min: 111, max: 310 },
  rare:       { min: 311, max: 1000 },
};

// Hard pity (30 pulls, guaranteed Exquisite+)
const HARD_PITY_RATES = {
  mythical:   { min: 1,   max: 20 },
  exquisite:  { min: 21,  max: 1000 },
};

const PULL_COST_NORMAL = 5;
const PULL_COST_CONVERGENCE = 3;
const MAX_FOUNTAIN_USES_PER_DAY = 3; // Daily fountain interaction limit

// Info browser — full catalog of possible items by tier
const INFO_CATALOG = {
  common: ["250 XP", "Awakening Stone", "Random Glyph", "3 Diamonds", "Crumb of Dreams", "8 Emeralds"],
  uncommon: ["Awakening Stone", "Essentials Satchel", "Dungeon Key", "Companion Treat", "Netherite Scrap", "Artifact Crate"],
  rare: ["Rare Artifact Crate", "Tree Token", "Tree Shard", "Potion of Dreams", "Coin of Lucidity", "Rare Companion Crate"],
  ornate: ["Ornate Artifact Crate", "Seed of Forgetting", "Random Particle", "Random Title", "Ornate Companion Crate"],
  exquisite: ["Exquisite Artifact Crate", "Lunar Moth", "Nebula Kit", "Twilight Hare", "Lore Piece", "Netherite Block", "Guidestone"],
  mythical: ["Mythical Artifact Crate", "Dreamstag", "Starweaver", "Somnia", "Dreamdust Crystal", "Dreamy Star"],
};

// Artifact class assignments for info display
const ARTIFACT_CLASSES = {
  warrior: ["Blood Sword", "Infernal Blade", "Storm Cleaver", "Titan's Edge"],
  mage: ["Arcane Staff", "Void Crystal", "Dream Codex", "Astral Wand"],
  ranger: ["Wind Bow", "Shadow Quiver", "Stalker's Crossbow", "Eagle Eye"],
  tank: ["Iron Wall", "Fortress Shield", "Guardian Plate", "Bulwark Helm"],
};

// ─── REWARD POOLS ──────────────────────────────────────────

const COMMON_REWARDS = [
  { name: "250 XP", cmd: "xp 250 @s" },
  { name: "Awakening Stone", cmd: "give @s forevercraft:awakening_stone 1" },
  { name: "Random Glyph", cmd: "give @s forevercraft:random_glyph 1" },
  { name: "3 Diamonds", cmd: "give @s diamond 3" },
  { name: "Crumb of Dreams", cmd: "give @s forevercraft:crumb_of_dreams 1" },
  { name: "8 Emeralds", cmd: "give @s emerald 8" },
];

const UNCOMMON_REWARDS = [
  { name: "Awakening Stone", cmd: "give @s forevercraft:awakening_stone 1" },
  { name: "Essentials Satchel", cmd: "give @s forevercraft:essentials_satchel 1" },
  { name: "Dungeon Key", cmd: "give @s forevercraft:dungeon_key 1" },
  { name: "Companion Treat", cmd: "give @s forevercraft:companion_treat 1" },
  { name: "Netherite Scrap", cmd: "give @s netherite_scrap 1" },
  { name: "Artifact Crate", cmd: "give @s forevercraft:artifact_crate 1" },
];

const RARE_REWARDS = [
  { name: "Rare Artifact Crate", cmd: "give @s forevercraft:rare_artifact_crate 1" },
  { name: "Tree Token", cmd: "give @s forevercraft:tree_token 1" },
  { name: "Tree Shard (50 XP)", cmd: "give @s forevercraft:tree_shard 1" },
  { name: "Potion of Dreams", cmd: "give @s forevercraft:potion_of_dreams 1" },
  { name: "Coin of Lucidity", cmd: "give @s forevercraft:coin_of_lucidity 1" },
  { name: "Rare Companion Crate", cmd: "give @s forevercraft:rare_companion_crate 1" },
];

const ORNATE_REWARDS = [
  { name: "Ornate Artifact Crate", cmd: "give @s forevercraft:ornate_artifact_crate 1" },
  { name: "Seed of Forgetting", cmd: "give @s forevercraft:seed_of_forgetting 1" },
  { name: "Random Particle", cmd: "give @s forevercraft:random_particle 1" },
  { name: "Random Title", cmd: "give @s forevercraft:random_title 1" },
  { name: "Ornate Companion Crate", cmd: "give @s forevercraft:ornate_companion_crate 1" },
];

const EXQUISITE_REWARDS = [
  { name: "Exquisite Artifact Crate", cmd: "give @s forevercraft:exquisite_artifact_crate 1" },
  { name: "Lunar Moth Companion", cmd: "give @s forevercraft:lunar_moth_egg 1" },
  { name: "Nebula Kit Companion", cmd: "give @s forevercraft:nebula_kit_egg 1" },
  { name: "Twilight Hare Companion", cmd: "give @s forevercraft:twilight_hare_egg 1" },
  { name: "Lore Piece", cmd: "give @s forevercraft:random_lore 1" },
  { name: "Netherite Block", cmd: "give @s netherite_block 1" },
  { name: "Guidestone", cmd: "give @s forevercraft:guidestone 1" },
];

const MYTHICAL_REWARDS = [
  { name: "Mythical Artifact", type: "artifact" },
  { name: "Dreamstag Companion", cmd: "give @s forevercraft:dreamstag_egg 1" },
  { name: "Starweaver Companion", cmd: "give @s forevercraft:starweaver_egg 1" },
  { name: "Somnia Companion", cmd: "give @s forevercraft:somnia_egg 1" },
  { name: "Dreamdust Crystal", type: "dreamdust_crystal" },
  { name: "Dreamy Star", cmd: "give @s forevercraft:dreamy_star 1" },
];

const REWARD_POOLS = [null, COMMON_REWARDS, UNCOMMON_REWARDS, RARE_REWARDS, ORNATE_REWARDS, EXQUISITE_REWARDS, MYTHICAL_REWARDS];
const TIER_NAMES = ["", "§fCommon", "§aUncommon", "§bRare", "§dOrnate", "§6Exquisite", "§5§lMythical"];
const TIER_COLORS = ["", "§f", "§a", "§b", "§d", "§6", "§5"];

// Dreamdust per pull by tier
const DREAMDUST_NORMAL = [0, 1, 2, 2, 3, 3, 3];
const DREAMDUST_CONVERGENCE = [0, 2, 4, 4, 6, 6, 6];

// Lucid Claim options (50 spark pity)
const LUCID_CLAIM_ITEMS = [
  "The Starless Night", "Shooting Star", "Dreamcast Compass",
  "Hero's Helmet", "Hero's Chestplate", "Hero's Leggings", "Hero's Boots",
  "Robot Dancer's Sword", "Droid Dancer's Sword",
];

// Exchange shop (Dreamdust costs)
const EXCHANGE_ITEMS = [
  { name: "Forever Coin", cost: 3, cmd: "give @s forevercraft:forever_coin 1" },
  { name: "Companion Treat", cost: 10, cmd: "give @s forevercraft:companion_treat 1" },
  { name: "Awakening Stone", cost: 15, cmd: "give @s forevercraft:awakening_stone 1" },
  { name: "Tree Token", cost: 30, cmd: "give @s forevercraft:tree_token 1" },
  { name: "Random Particle", cost: 100, cmd: "give @s forevercraft:random_particle 1" },
  { name: "Random Title", cost: 100, cmd: "give @s forevercraft:random_title 1" },
  { name: "Guaranteed Exquisite Pull", cost: 200, type: "exquisite_pull" },
  { name: "Guaranteed Mythical Pull", cost: 500, type: "mythical_pull" },
];

export class GachaSystem {
  constructor(eventBridge, coinSystem) {
    this.eventBridge = eventBridge;
    this.coinSystem = coinSystem;
    this.convergence = false; // Global convergence flag

    // Listen for convergence toggle from world events
    eventBridge.on("gacha_convergence", (active) => { this.convergence = active; });

    // Dreamy Star consumption
    eventBridge.on("item_use", (player, item) => {
      if (!item) return;
      const tags = item.getTags?.() || [];
      if (tags.some(t => t.includes("dreamy_star")) || item.typeId?.includes("dreamy_star")) {
        this.useWishingStar(player);
      }
      if (tags.some(t => t.includes("coin_of_lucidity")) || item.typeId?.includes("coin_of_lucidity")) {
        this.useCoinOfLucidity(player);
      }
      if (tags.some(t => t.includes("dreamdust_crystal")) || item.typeId?.includes("dreamdust_crystal")) {
        this.useDreamdustCrystal(player);
      }
    });
  }

  // ─── MAIN MENU ──────────────────────────────────────────────

  openFountainMenu(player) {
    const s = StorageManager.forPlayer(player);
    const coins = this.coinSystem.getBalance(player);
    const dreamdust = s.getNumber("dreamdust", 0);
    const spark = s.getNumber("wish_spark", 0);
    const total = s.getNumber("wish_total", 0);
    const banked = s.getNumber("wish_bonus", 0);
    const cost = this.convergence ? PULL_COST_CONVERGENCE : PULL_COST_NORMAL;

    // Daily use tracking
    const today = world.getDay();
    if (s.getNumber("fountain_last_day", 0) !== today) {
      s.set("fountain_uses_today", 0);
      s.set("fountain_last_day", today);
    }
    const usesToday = s.getNumber("fountain_uses_today", 0);
    const usesLeft = MAX_FOUNTAIN_USES_PER_DAY - usesToday;

    const form = new ActionFormData()
      .title("§d⭐ Fountain of Eternal Dreams")
      .body(
        `§7Forever Coins: §d${coins}\n` +
        `§7Dreamdust: §b${dreamdust}\n` +
        `§7Total Pulls: §f${total}\n` +
        `§7Spark Progress: §e${spark}/50\n` +
        `§7Daily Uses: §f${usesLeft}/${MAX_FOUNTAIN_USES_PER_DAY} remaining\n` +
        (banked > 0 ? `§7Free Pulls Banked: §e${banked}\n` : "") +
        (this.convergence ? "§d§l✦ CONVERGENCE ACTIVE — Half Price!\n" : "") +
        `\n§7Pull Cost: §f${cost} Coins each`
      )
      .button(`§ePull x1\n§7${cost} Coins`)
      .button(`§6Pull x10\n§7${cost * 10} Coins`)
      .button(`§dCheck Balance\n§7View your coins`)
      .button(`§5Lucid Claim\n§7${spark}/50 spark`)
      .button(`§bDreamdust Exchange\n§7Shop with Dreamdust`)
      .button(`§aItem Catalog\n§7Browse possible rewards`)
      .button("§7Close");

    form.show(player).then(response => {
      if (response.canceled || response.selection === 6) return;
      switch (response.selection) {
        case 0: this.tryPull(player, 1); break;
        case 1: this.tryPull(player, 10); break;
        case 2: this.coinSystem.showBalance(player); break;
        case 3: this.openLucidClaim(player); break;
        case 4: this.openExchangeShop(player); break;
        case 5: this.openInfoBrowser(player); break;
      }
    });
  }

  // ─── INFO BROWSER (3-page item catalog) ──────────────────────

  openInfoBrowser(player) {
    const form = new ActionFormData()
      .title("§a✦ Item Catalog")
      .body("§7Browse all possible Fountain rewards by tier:")
      .button("§fCommon & §aUncommon\n§7Tiers 1-2")
      .button("§bRare & §dOrnate\n§7Tiers 3-4")
      .button("§6Exquisite & §5Mythical\n§7Tiers 5-6")
      .button("§7← Back");

    form.show(player).then(response => {
      if (response.canceled || response.selection === 3) { this.openFountainMenu(player); return; }
      this.showCatalogPage(player, response.selection);
    });
  }

  showCatalogPage(player, page) {
    const pages = [
      { title: "§f Common & §a Uncommon", tiers: [
        { name: "§f§lCommon (46.8%)", items: INFO_CATALOG.common },
        { name: "§a§lUncommon (25%)", items: INFO_CATALOG.uncommon },
      ]},
      { title: "§b Rare & §d Ornate", tiers: [
        { name: "§b§lRare (15%)", items: INFO_CATALOG.rare },
        { name: "§d§lOrnate (8%)", items: INFO_CATALOG.ornate },
      ]},
      { title: "§6 Exquisite & §5 Mythical", tiers: [
        { name: "§6§lExquisite (5%)", items: INFO_CATALOG.exquisite },
        { name: "§5§lMythical (0.2%)", items: INFO_CATALOG.mythical },
      ]},
    ];

    const p = pages[page];
    let body = "";
    for (const tier of p.tiers) {
      body += `\n${tier.name}\n`;
      for (const item of tier.items) {
        body += `  §7• §f${item}\n`;
      }
    }
    body += "\n§7Pity: 10-pull (Rare+), 30-pull (Exquisite+), 50 Spark (choose Mythical)";

    const form = new ActionFormData()
      .title(`§a✦ Catalog —${p.title}`)
      .body(body)
      .button("§7← Back to Catalog");

    form.show(player).then(() => {
      this.openInfoBrowser(player);
    });
  }

  // ─── PULL MECHANICS ─────────────────────────────────────────

  tryPull(player, count) {
    const s = StorageManager.forPlayer(player);

    // Daily fountain limit check
    const today = world.getDay();
    if (s.getNumber("fountain_last_day", 0) !== today) {
      s.set("fountain_uses_today", 0);
      s.set("fountain_last_day", today);
    }
    const usesToday = s.getNumber("fountain_uses_today", 0);
    if (usesToday >= MAX_FOUNTAIN_USES_PER_DAY) {
      player.sendMessage(`§c§l✗ §r§7Daily fountain limit reached (${MAX_FOUNTAIN_USES_PER_DAY}/day). Come back tomorrow!`);
      return;
    }
    s.set("fountain_uses_today", usesToday + 1);

    const cost = this.convergence ? PULL_COST_CONVERGENCE : PULL_COST_NORMAL;
    const bonus = s.getNumber("wish_bonus", 0);
    const freePulls = Math.min(bonus, count);
    const paidPulls = count - freePulls;
    const totalCost = paidPulls * cost;

    if (totalCost > 0 && !this.coinSystem.removeCoins(player, totalCost)) {
      player.sendMessage(`§c§l✗ §r§7Need §d${totalCost} Coins §7(have §d${this.coinSystem.getBalance(player)}§7).`);
      return;
    }

    if (freePulls > 0) {
      s.set("wish_bonus", bonus - freePulls);
      player.sendMessage(`§a§l✓ §r§7Used §e${freePulls} §7free pull${freePulls > 1 ? "s" : ""}!`);
    }

    // Execute pulls
    for (let i = 0; i < count; i++) {
      system.runTimeout(() => {
        this.executePull(player, i + 1, count);
      }, i * 40); // 2-second gap between pulls for readability
    }
  }

  executePull(player, pullNum, totalPulls) {
    const s = StorageManager.forPlayer(player);

    // Increment pity counters
    let pity10 = s.getNumber("wish_pity", 0) + 1;
    let softPity = s.getNumber("wish_soft", 0) + 1;
    let spark = s.getNumber("wish_spark", 0) + 1;
    let total = s.getNumber("wish_total", 0) + 1;

    // Determine tier (apply DR scaling: luck / 5 capped at +50)
    const tier = this.rollTier(player, pity10, softPity);

    // Reset pities based on tier
    if (tier >= 3) pity10 = 0; // Rare+ resets 10-pull pity
    if (tier >= 5) softPity = 0; // Exquisite+ resets soft pity

    s.set("wish_pity", pity10);
    s.set("wish_soft", softPity);
    s.set("wish_spark", spark);
    s.set("wish_total", total);

    // Grant reward
    const reward = this.grantReward(player, tier);

    // Grant Dreamdust consolation
    const dd = this.convergence ? DREAMDUST_CONVERGENCE[tier] : DREAMDUST_NORMAL[tier];
    if (dd > 0) {
      const currentDD = s.getNumber("dreamdust", 0);
      s.set("dreamdust", currentDD + dd);
    }

    // Display
    const prefix = totalPulls > 1 ? `§7[${pullNum}/${totalPulls}] ` : "";
    player.sendMessage(`${prefix}${TIER_NAMES[tier]} §r§7— ${reward}`);
    try { player.playSound("random.orb", { volume: 0.5, pitch: 0.8 + tier * 0.1 }); } catch {}

    // Mythical broadcast
    if (tier === 6) {
      for (const p of world.getAllPlayers()) {
        if (p.name !== player.name) {
          p.sendMessage(`§5§l✦ ${player.name} §r§5pulled a §lMythical §r§5from the Fountain!`);
        }
      }
    }

    // Check achievements
    this.checkAchievements(player, total, tier);
  }

  rollTier(player, pity10, softPity) {
    // Apply Dream Rate modifier: DR / 5, capped at +50 (out of 1000)
    let drBonus = 0;
    try {
      const s = StorageManager.forPlayer(player);
      const dr = s.getNumber("dream_rate", 0);
      drBonus = Math.min(Math.floor(dr / 5), 50);
    } catch {}

    // Roll with DR bonus lowering the number (lower = rarer)
    const rawRoll = Math.floor(Math.random() * 1000) + 1;
    const roll = Math.max(1, rawRoll - drBonus);

    // Hard pity: 30+ pulls → guaranteed Exquisite+
    if (softPity >= 30) {
      return this.matchRate(roll, HARD_PITY_RATES);
    }

    // 10-pull pity: guaranteed Rare+
    if (pity10 >= 10) {
      return this.matchRate(roll, PITY_10_RATES);
    }

    // Soft pity: 20+ pulls → boosted rates
    if (softPity >= 20) {
      return this.matchRate(roll, SOFT_PITY_RATES);
    }

    // Normal rates (or convergence rates)
    const rates = this.convergence ? CONVERGENCE_RATES : BASE_RATES;
    return this.matchRate(roll, rates);
  }

  matchRate(roll, rates) {
    if (rates.mythical && roll >= rates.mythical.min && roll <= rates.mythical.max) return 6;
    if (rates.exquisite && roll >= rates.exquisite.min && roll <= rates.exquisite.max) return 5;
    if (rates.ornate && roll >= rates.ornate.min && roll <= rates.ornate.max) return 4;
    if (rates.rare && roll >= rates.rare.min && roll <= rates.rare.max) return 3;
    if (rates.uncommon && roll >= rates.uncommon.min && roll <= rates.uncommon.max) return 2;
    return 1; // Common fallback
  }

  grantReward(player, tier) {
    const pool = REWARD_POOLS[tier];
    if (!pool) return "Nothing";

    const reward = pool[Math.floor(Math.random() * pool.length)];

    // Special handling for typed rewards
    if (reward.type === "artifact") {
      try { player.runCommandAsync("give @s forevercraft:mythical_artifact_crate 1"); } catch {}
      return "§5Mythical Artifact Crate";
    }
    if (reward.type === "dreamdust_crystal") {
      const s = StorageManager.forPlayer(player);
      if (s.get("dreamdust_used")) {
        // Already used, give alternative
        try { player.runCommandAsync("give @s forevercraft:exquisite_artifact_crate 1"); } catch {}
        return "§6Exquisite Artifact Crate (Crystal already consumed)";
      }
      try { player.runCommandAsync("give @s forevercraft:dreamdust_crystal 1"); } catch {}
      return "§5Dreamdust Crystal";
    }

    try { player.runCommandAsync(reward.cmd); } catch {}
    return reward.name;
  }

  // ─── LUCID CLAIM (50 Spark Pity) ───────────────────────────

  openLucidClaim(player) {
    const s = StorageManager.forPlayer(player);
    const spark = s.getNumber("wish_spark", 0);

    if (spark < 50) {
      player.sendMessage(`§c§l✗ §r§7Need §e50 Spark §7(have §e${spark}§7). Keep pulling!`);
      return;
    }

    const form = new ActionFormData()
      .title("§d✦ Lucid Claim")
      .body("§7Choose ANY mythical item as your guaranteed reward!\n§7This resets your Spark counter to 0.");

    for (const item of LUCID_CLAIM_ITEMS) {
      form.button(`§5${item}`);
    }
    form.button("§7Cancel");

    form.show(player).then(response => {
      if (response.canceled || response.selection >= LUCID_CLAIM_ITEMS.length) return;
      const chosen = LUCID_CLAIM_ITEMS[response.selection];
      s.set("wish_spark", 0);

      // Grant the chosen mythical artifact
      const artId = chosen.toLowerCase().replace(/[' ]/g, "_");
      try { player.runCommandAsync(`give @s forevercraft:${artId} 1`); } catch {}

      player.sendMessage(`§5§l✦ Lucid Claim! §r§5${chosen} §7is yours!`);
      player.playSound("random.levelup");

      // Broadcast
      for (const p of world.getAllPlayers()) {
        if (p.name !== player.name) {
          p.sendMessage(`§5§l✦ ${player.name} §r§5claimed §l${chosen} §r§5from the Fountain!`);
        }
      }
    });
  }

  // ─── EXCHANGE SHOP ──────────────────────────────────────────

  openExchangeShop(player) {
    const s = StorageManager.forPlayer(player);
    const dreamdust = s.getNumber("dreamdust", 0);

    const form = new ActionFormData()
      .title("§b✦ Dreamdust Exchange")
      .body(`§7Your Dreamdust: §b${dreamdust}\n\n§7Spend Dreamdust on special items:`);

    for (const item of EXCHANGE_ITEMS) {
      form.button(`§e${item.name}\n§7${item.cost} Dreamdust`);
    }
    form.button("§7← Back");

    form.show(player).then(response => {
      if (response.canceled || response.selection >= EXCHANGE_ITEMS.length) {
        this.openFountainMenu(player);
        return;
      }

      const item = EXCHANGE_ITEMS[response.selection];
      if (dreamdust < item.cost) {
        player.sendMessage(`§c§l✗ §r§7Need §b${item.cost} Dreamdust §7(have §b${dreamdust}§7).`);
        this.openExchangeShop(player);
        return;
      }

      s.set("dreamdust", dreamdust - item.cost);

      if (item.type === "exquisite_pull") {
        this.grantReward(player, 5);
        player.sendMessage(`§6§l✦ §r§7Guaranteed Exquisite reward!`);
      } else if (item.type === "mythical_pull") {
        this.grantReward(player, 6);
        player.sendMessage(`§5§l✦ §r§7Guaranteed Mythical reward!`);
      } else {
        try { player.runCommandAsync(item.cmd); } catch {}
        player.sendMessage(`§b§l✦ §r§7Purchased §e${item.name}§7!`);
      }
      player.playSound("random.orb", { volume: 0.5, pitch: 1.2 });
    });
  }

  // ─── SPECIAL CONSUMABLES ───────────────────────────────────

  useCoinOfLucidity(player) {
    const s = StorageManager.forPlayer(player);
    const bonus = s.getNumber("wish_bonus", 0);
    s.set("wish_bonus", bonus + 1);
    player.sendMessage("§e§l✦ Coin of Lucidity! §r§7+1 free Fountain pull banked.");
    player.playSound("random.orb", { volume: 0.5, pitch: 1.5 });
  }

  useWishingStar(player) {
    player.sendMessage("§5§l✦ Dreamy Star! §r§7Choose any artifact from the full pool!");
    // Open artifact selection codex
    this.eventBridge.emit("dreamy_star_used", player);
  }

  useDreamdustCrystal(player) {
    const s = StorageManager.forPlayer(player);
    if (s.get("dreamdust_used")) {
      player.sendMessage("§c§l✗ §r§7You have already consumed a Dreamdust Crystal.");
      return;
    }
    s.set("dreamdust_used", true);
    // Permanent +25 Dream Rate (stored as consumable bonus for crash-proof reapply)
    const bonus = s.getNumber("dr_consumable_bonus", 0);
    s.set("dr_consumable_bonus", bonus + 25);
    // Also mark for permanent luck effect reapply
    s.set("dreamdust_crystal_active", true);
    try { player.runCommandAsync("effect @s luck 999999 2 true"); } catch {}
    player.sendMessage("§5§l✦ Dreamdust Crystal! §r§7Permanent +25 Dream Rate!");
    player.playSound("random.levelup");
    this.eventBridge.emit("dream_rate_changed", player);
  }

  // ─── ACHIEVEMENTS ──────────────────────────────────────────

  checkAchievements(player, totalPulls, tier) {
    if (totalPulls === 50) {
      this.eventBridge.emit("achievement", player, "dedicated_dreamer");
    }
    if (totalPulls === 100) {
      this.eventBridge.emit("achievement", player, "fortune_favors_bold");
    }
    if (totalPulls === 500) {
      this.eventBridge.emit("achievement", player, "eternal_wisher");
    }
    if (tier === 6) {
      this.eventBridge.emit("achievement", player, "dreamy_star");
    }
  }
}
