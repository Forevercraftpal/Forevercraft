/**
 * World Boss System — 11 boss types with 3-phase mechanics, per-boss abilities,
 * anti-range arena, participant tracking, and tiered rewards.
 * Replaces Java bosses/ folder.
 */
import { world, system } from "@minecraft/server";
import { StorageManager } from "../utils/storage.js";

// ─── BOSS DEFINITIONS ──────────────────────────────────────────────
const BOSSES = [
  null, // index 0 unused
  {
    id: 1, name: "The Hollow King", entity: "minecraft:wither_skeleton", baseHP: 300, color: "§8",
    minionType: "minecraft:zombie", minionCount: 4,
    desc: "Undead curse lord",
  },
  {
    id: 2, name: "The Verdant Warden", entity: "minecraft:vindicator", baseHP: 280, color: "§2",
    minionType: "minecraft:spider", minionCount: 4,
    desc: "Nature's vengeance",
  },
  {
    id: 3, name: "The Stormforged", entity: "minecraft:skeleton", baseHP: 250, color: "§e",
    minionType: "minecraft:skeleton", minionCount: 4,
    desc: "Lightning incarnate",
  },
  {
    id: 4, name: "The Tidecaller", entity: "minecraft:drowned", baseHP: 350, color: "§3",
    minionType: "minecraft:drowned", minionCount: 4,
    desc: "Ocean's wrath",
  },
  {
    id: 5, name: "The Earthshaker", entity: "minecraft:iron_golem", baseHP: 400, color: "§6",
    minionType: "minecraft:zombie", minionCount: 4,
    desc: "Living earthquake",
  },
  {
    id: 6, name: "The Nightmare", entity: "minecraft:wither_skeleton", baseHP: 320, color: "§5",
    minionType: "minecraft:silverfish", minionCount: 4,
    desc: "Terror manifest",
  },
  {
    id: 7, name: "The Infernal Titan", entity: "minecraft:piglin_brute", baseHP: 450, color: "§c",
    minionType: "minecraft:blaze", minionCount: 4,
    desc: "Flame emperor",
  },
  {
    id: 8, name: "The Soul Warden", entity: "minecraft:wither_skeleton", baseHP: 400, color: "§d",
    minionType: "minecraft:skeleton", minionCount: 4,
    desc: "Soul harvester",
  },
  {
    id: 9, name: "The Crimson Behemoth", entity: "minecraft:hoglin", baseHP: 500, color: "§4",
    minionType: "minecraft:hoglin", minionCount: 4,
    desc: "Unstoppable rampage",
  },
  {
    id: 10, name: "The Void Sovereign", entity: "minecraft:vindicator", baseHP: 500, color: "§5",
    minionType: "minecraft:endermite", minionCount: 4,
    desc: "Void commander",
  },
  {
    id: 11, name: "The Ender Architect", entity: "minecraft:blaze", baseHP: 550, color: "§f",
    minionType: "minecraft:endermite", minionCount: 4,
    desc: "End fortress lord",
  },
];

// Phase thresholds (4 phases now)
const P2_THRESHOLD = 0.66;
const P3_THRESHOLD = 0.33;
const P4_THRESHOLD = 0.25; // Phase 4 at 25% HP

// Title system — 4 tiers per boss (10/25/50/100 kills) + Champion
const TITLE_TIERS = [
  { kills: 10,  suffix: "Slayer" },
  { kills: 25,  suffix: "Conqueror" },
  { kills: 50,  suffix: "Vanquisher" },
  { kills: 100, suffix: "Nemesis" },
];
const TITLE_COLORS = ["§7", "§7§l", "§f§l", "§6§l"];

// Fight timeout (seconds)
const MAX_FIGHT_TIME = 900; // 15 minutes
const WARN_TIME_1 = 720;   // 12 min warning
const WARN_TIME_2 = 840;   // 14 min warning

// Anti-range zones
const RANGE_WARNING = 25;
const RANGE_DANGER = 35;
const RANGE_EXTREME = 50;
const MINION_DESPAWN_RANGE = 150;

export class WorldBossSystem {
  constructor(eventBridge) {
    this.storage = StorageManager.world();
    this.activeBossId = 0;
    this.bossEntity = null;
    this.phase = 0;
    this.maxHP = 0;
    this.fightTimer = 0;
    this.abilityCd = 0;
    this.participants = new Set();

    eventBridge.on("entity_died", (entity, source) => {
      if (entity.hasTag?.("wb.boss")) {
        this.onBossDefeated(entity, source);
      }
      // Clean up minions
      if (entity.hasTag?.("wb.minion")) {
        // Minion died, no special handling
      }
    });

    eventBridge.on("player_died", (player) => {
      if (player.hasTag("wb.participant")) {
        player.removeTag("wb.participant");
      }
    });

    eventBridge.on("entity_hurt", (target, source, damage) => {
      if (target.hasTag?.("wb.boss") && source?.typeId === "minecraft:player") {
        if (!source.hasTag("wb.participant")) {
          source.addTag("wb.participant");
          this.participants.add(source.name);
        }
      }
    });
  }

  // ─── SPAWNING ──────────────────────────────────────────────────

  /** Spawn a boss by ID (1-11) near a player */
  spawnBoss(bossId, player) {
    if (this.activeBossId > 0) return;
    const def = BOSSES[bossId];
    if (!def) return;

    const dim = player.dimension;
    const loc = player.location;
    const facing = player.getViewDirection();

    // Spawn 5 blocks ahead
    const spawnLoc = {
      x: loc.x + facing.x * 5,
      y: loc.y,
      z: loc.z + facing.z * 5,
    };

    try {
      const boss = dim.spawnEntity(def.entity, spawnLoc);
      boss.nameTag = `${def.color}§l${def.name}`;
      boss.addTag("wb.boss");
      boss.addTag(`wb.id_${bossId}`);

      // Scale HP with Dream Rate
      const avgDR = this.getAverageDR();
      const hpScale = 1 + (avgDR / 100);
      this.maxHP = Math.floor(def.baseHP * hpScale);

      // Apply HP via health_boost effect (scales beyond vanilla max)
      const bonusHP = this.maxHP - 20; // base mob HP varies, add big buffer
      if (bonusHP > 0) {
        const boostLevel = Math.floor(bonusHP / 4); // each level = +4 max HP
        boss.runCommandAsync(`effect @s health_boost 99999 ${Math.min(boostLevel, 255)} true`);
      }

      // Small delay to let health_boost apply, then heal to full
      system.runTimeout(() => {
        try {
          const hp = boss.getComponent("minecraft:health");
          if (hp) hp.setCurrentValue(hp.effectiveMax);
        } catch {}
      }, 5);

      this.bossEntity = boss;
      this.activeBossId = bossId;
      this.phase = 1;
      this.fightTimer = 0;
      this.abilityCd = 0;
      this.participants.clear();

      this.storage.set("wb_active", 1);
      this.storage.set("wb_boss_id", bossId);

      // Spawn minions
      this.spawnMinions(def, dim, spawnLoc);

      // Announce
      for (const p of world.getAllPlayers()) {
        p.sendMessage(`${def.color}§l⚔ World Boss: ${def.name} §r§7has appeared!`);
        p.onScreenDisplay.setTitle(`${def.color}§l${def.name}`, {
          subtitle: `§7${def.desc}`,
          fadeInDuration: 20, stayDuration: 100, fadeOutDuration: 20,
        });
        p.playSound("mob.wither.spawn");
      }

      console.log(`[WorldBoss] Spawned ${def.name} (HP: ${this.maxHP}, Scale: ${hpScale.toFixed(2)})`);
    } catch (e) {
      console.warn(`[WorldBoss] Failed to spawn: ${e}`);
    }
  }

  /** Spawn minions around boss */
  spawnMinions(def, dim, loc) {
    for (let i = 0; i < def.minionCount; i++) {
      const offset = { x: (Math.random() - 0.5) * 8, z: (Math.random() - 0.5) * 8 };
      try {
        const minion = dim.spawnEntity(def.minionType, {
          x: loc.x + offset.x, y: loc.y, z: loc.z + offset.z,
        });
        minion.addTag("wb.minion");
        minion.addTag(`wb.minion_${def.id}`);
      } catch {}
    }
  }

  /** Spawn random boss near a random player */
  spawnRandom() {
    const players = world.getAllPlayers();
    if (players.length === 0) return;
    const target = players[Math.floor(Math.random() * players.length)];
    const bossId = Math.floor(Math.random() * 11) + 1;
    this.spawnBoss(bossId, target);
  }

  getAverageDR() {
    const players = world.getAllPlayers();
    if (players.length === 0) return 0;
    let total = 0;
    for (const p of players) {
      total += StorageManager.forPlayer(p).getNumber("dream_rate", 0);
    }
    return total / players.length;
  }

  // ─── PHASE TRANSITIONS ────────────────────────────────────────

  checkPhaseTransition() {
    if (!this.bossEntity || this.phase >= 4) return;
    try {
      const hp = this.bossEntity.getComponent("minecraft:health");
      if (!hp) return;
      const pct = hp.currentValue / hp.effectiveMax;

      if (this.phase === 1 && pct <= P2_THRESHOLD) {
        this.transitionToPhase(2, hp);
      } else if (this.phase === 2 && pct <= P3_THRESHOLD) {
        this.transitionToPhase(3, hp);
      } else if (this.phase === 3 && pct <= P4_THRESHOLD) {
        this.transitionToPhase(4, hp);
      }
    } catch {}
  }

  transitionToPhase(newPhase, hpComp) {
    this.phase = newPhase;
    const def = BOSSES[this.activeBossId];
    if (!def) return;

    // Heal 10% of max HP
    try {
      const healAmt = hpComp.effectiveMax * 0.1;
      hpComp.setCurrentValue(Math.min(hpComp.currentValue + healAmt, hpComp.effectiveMax));
    } catch {}

    // Apply phase buffs via effects
    try {
      if (newPhase === 2) {
        this.bossEntity.runCommandAsync("effect @s speed 99999 0 true");
        this.bossEntity.runCommandAsync("effect @s resistance 99999 0 true");
      } else if (newPhase === 3) {
        this.bossEntity.runCommandAsync("effect @s speed 99999 1 true");
        this.bossEntity.runCommandAsync("effect @s resistance 99999 1 true");
        this.bossEntity.runCommandAsync("effect @s strength 99999 0 true");
      }
    } catch {}

    // Phase 4 special buffs
    if (newPhase === 4) {
      try {
        this.bossEntity.runCommandAsync("effect @s speed 99999 2 true");
        this.bossEntity.runCommandAsync("effect @s resistance 99999 2 true");
        this.bossEntity.runCommandAsync("effect @s strength 99999 1 true");
        // Heal 10% extra on phase 4
        const extraHeal = hpComp.effectiveMax * 0.1;
        hpComp.setCurrentValue(Math.min(hpComp.currentValue + extraHeal, hpComp.effectiveMax));
      } catch {}
    }

    // Announce
    let msg;
    if (newPhase === 2) {
      msg = `${def.color}§lPhase 2 §r§7— ${def.name} grows stronger!`;
    } else if (newPhase === 3) {
      msg = `${def.color}§lPhase 3 §r§7— ${def.name} unleashes its full power!`;
    } else if (newPhase === 4) {
      msg = `${def.color}§l✦ RAGE PHASE ✦ §r§7— ${def.name} enters a frenzy!`;
    }

    for (const p of world.getAllPlayers()) {
      p.sendMessage(msg);
      if (newPhase === 4) {
        p.playSound("mob.wither.spawn", { volume: 1.5, pitch: 1.5 });
        p.playSound("ambient.weather.thunder", { volume: 1.0, pitch: 1.5 });
        try { p.dimension.spawnParticle("minecraft:huge_explosion_emitter", this.bossEntity.location); } catch {}
      } else {
        p.playSound(newPhase === 3 ? "mob.wither.break_block" : "mob.enderdragon.growl");
      }
    }
  }

  // ─── PER-BOSS ABILITIES ───────────────────────────────────────

  tickAbilities() {
    if (!this.bossEntity || !this.activeBossId) return;
    this.abilityCd--;
    if (this.abilityCd > 0) return;

    const def = BOSSES[this.activeBossId];
    if (!def) return;
    const boss = this.bossEntity;
    const loc = boss.location;
    const dim = boss.dimension;

    try {
      switch (this.activeBossId) {
        case 1: this.abilityHollowKing(boss, loc, dim); break;
        case 2: this.abilityVerdantWarden(boss, loc, dim); break;
        case 3: this.abilityStormforged(boss, loc, dim); break;
        case 4: this.abilityTidecaller(boss, loc, dim); break;
        case 5: this.abilityEarthshaker(boss, loc, dim); break;
        case 6: this.abilityNightmare(boss, loc, dim); break;
        case 7: this.abilityInfernalTitan(boss, loc, dim); break;
        case 8: this.abilitySoulWarden(boss, loc, dim); break;
        case 9: this.abilityCrimsonBehemoth(boss, loc, dim); break;
        case 10: this.abilityVoidSovereign(boss, loc, dim); break;
        case 11: this.abilityEnderArchitect(boss, loc, dim); break;
      }
    } catch {}
  }

  /** Boss 1: Hollow King — curse auras + darkness */
  abilityHollowKing(boss, loc, dim) {
    const nearby = this.getNearbyPlayers(dim, loc, 10);
    if (this.phase === 1) {
      // Slowness I aura
      for (const p of nearby) {
        try { p.runCommandAsync("effect @s slowness 5 0 true"); } catch {}
      }
      this.abilityCd = 5;
    } else if (this.phase === 2) {
      // Weakness I aura
      for (const p of nearby) {
        try { p.runCommandAsync("effect @s weakness 5 0 true"); } catch {}
      }
      this.abilityCd = 5;
    } else {
      // Weakness + Darkness pulse
      for (const p of nearby) {
        try {
          p.runCommandAsync("effect @s weakness 5 0 true");
          p.runCommandAsync("effect @s darkness 5 0 true");
        } catch {}
      }
      this.abilityCd = 15;
    }
  }

  /** Boss 2: Verdant Warden — poison + nature */
  abilityVerdantWarden(boss, loc, dim) {
    const nearby = this.getNearbyPlayers(dim, loc, 10);
    if (this.phase === 1) {
      for (const p of nearby) {
        try { p.runCommandAsync("effect @s poison 5 0 true"); } catch {}
      }
      this.abilityCd = 5;
    } else if (this.phase === 2) {
      for (const p of nearby) {
        try {
          p.runCommandAsync("effect @s poison 5 0 true");
          p.runCommandAsync("effect @s slowness 5 1 true");
        } catch {}
      }
      this.abilityCd = 10;
    } else {
      for (const p of nearby) {
        try {
          p.runCommandAsync("effect @s poison 5 1 true");
          p.runCommandAsync("effect @s nausea 12 0 true");
        } catch {}
      }
      this.abilityCd = 12;
    }
  }

  /** Boss 3: Stormforged — lightning */
  abilityStormforged(boss, loc, dim) {
    const players = this.getNearbyPlayers(dim, loc, 30);
    if (players.length === 0) { this.abilityCd = 5; return; }

    if (this.phase === 1) {
      const target = players[Math.floor(Math.random() * players.length)];
      try {
        const tl = target.location;
        dim.runCommandAsync(`summon lightning_bolt ${Math.floor(tl.x)} ${Math.floor(tl.y)} ${Math.floor(tl.z)}`);
      } catch {}
      this.abilityCd = 10;
    } else if (this.phase === 2) {
      // Chain lightning — 3 targets
      const shuffled = [...players].sort(() => Math.random() - 0.5).slice(0, 3);
      for (const t of shuffled) {
        try {
          const tl = t.location;
          dim.runCommandAsync(`summon lightning_bolt ${Math.floor(tl.x)} ${Math.floor(tl.y)} ${Math.floor(tl.z)}`);
        } catch {}
      }
      this.abilityCd = 8;
    } else {
      // Storm aura damage + lightning
      for (const p of this.getNearbyPlayers(dim, loc, 8)) {
        try { p.applyDamage(2, { cause: "magic" }); } catch {}
      }
      const target = players[Math.floor(Math.random() * players.length)];
      try {
        const tl = target.location;
        dim.runCommandAsync(`summon lightning_bolt ${Math.floor(tl.x)} ${Math.floor(tl.y)} ${Math.floor(tl.z)}`);
      } catch {}
      this.abilityCd = 5;
    }
  }

  /** Boss 4: Tidecaller — water curses */
  abilityTidecaller(boss, loc, dim) {
    const nearby = this.getNearbyPlayers(dim, loc, 12);
    if (this.phase === 1) {
      for (const p of nearby) {
        try { p.runCommandAsync("effect @s slowness 5 0 true"); } catch {}
      }
      this.abilityCd = 5;
    } else if (this.phase === 2) {
      for (const p of nearby) {
        try {
          p.runCommandAsync("effect @s slowness 5 0 true");
          p.runCommandAsync("effect @s mining_fatigue 15 1 true");
        } catch {}
      }
      this.abilityCd = 15;
    } else {
      // Whirlpool pull — teleport players closer
      for (const p of nearby) {
        try {
          p.runCommandAsync("effect @s slowness 5 1 true");
          const pl = p.location;
          const dx = loc.x - pl.x;
          const dz = loc.z - pl.z;
          const dist = Math.sqrt(dx * dx + dz * dz);
          if (dist > 3) {
            const pullDist = Math.min(3, dist * 0.3);
            p.teleport({
              x: pl.x + (dx / dist) * pullDist,
              y: pl.y,
              z: pl.z + (dz / dist) * pullDist,
            });
          }
        } catch {}
      }
      this.abilityCd = 10;
    }
  }

  /** Boss 5: Earthshaker — knockback + anvils */
  abilityEarthshaker(boss, loc, dim) {
    const nearby = this.getNearbyPlayers(dim, loc, 12);
    if (this.phase === 1) {
      // Ground pound particles (aesthetic only in P1)
      this.abilityCd = 5;
    } else if (this.phase === 2) {
      // Falling anvil barrage
      for (let i = 0; i < 2; i++) {
        if (nearby.length === 0) break;
        const target = nearby[Math.floor(Math.random() * nearby.length)];
        try {
          const tl = target.location;
          dim.runCommandAsync(
            `summon falling_block ${Math.floor(tl.x)} ${Math.floor(tl.y + 12)} ${Math.floor(tl.z)}`
          );
        } catch {}
      }
      this.abilityCd = 8;
    } else {
      // Shockwave pulse
      for (const p of nearby) {
        try {
          p.applyDamage(4, { cause: "entityAttack", damagingEntity: boss });
          p.runCommandAsync("effect @s slowness 3 1 true");
        } catch {}
      }
      try { boss.runCommandAsync("particle minecraft:explosion_particle ~ ~ ~"); } catch {}
      this.abilityCd = 10;
    }
  }

  /** Boss 6: Nightmare — darkness + wither */
  abilityNightmare(boss, loc, dim) {
    const nearby = this.getNearbyPlayers(dim, loc, 12);
    if (this.phase === 1) {
      for (const p of nearby) {
        try { p.runCommandAsync("effect @s darkness 5 0 true"); } catch {}
      }
      this.abilityCd = 5;
    } else if (this.phase === 2) {
      // Speed self-buff + blindness pulse
      try { boss.runCommandAsync("effect @s speed 99999 2 true"); } catch {}
      for (const p of nearby) {
        try {
          p.runCommandAsync("effect @s darkness 5 0 true");
          p.runCommandAsync("effect @s blindness 12 0 true");
        } catch {}
      }
      this.abilityCd = 12;
    } else {
      // Wither aura + sonic boom damage
      for (const p of this.getNearbyPlayers(dim, loc, 10)) {
        try {
          p.runCommandAsync("effect @s darkness 5 0 true");
          p.runCommandAsync("effect @s wither 5 0 true");
          p.applyDamage(8, { cause: "sonicBoom" });
        } catch {}
      }
      this.abilityCd = 15;
    }
  }

  /** Boss 7: Infernal Titan — fire + explosions */
  abilityInfernalTitan(boss, loc, dim) {
    if (this.phase === 1) {
      // Fire damage aura
      for (const p of this.getNearbyPlayers(dim, loc, 5)) {
        try { p.applyDamage(2, { cause: "fire" }); } catch {}
      }
      this.abilityCd = 5;
    } else if (this.phase === 2) {
      // Explosion pulse
      for (const p of this.getNearbyPlayers(dim, loc, 8)) {
        try { p.applyDamage(4, { cause: "entityExplosion" }); } catch {}
      }
      try { dim.runCommandAsync(`particle minecraft:huge_explosion_emitter ${loc.x} ${loc.y} ${loc.z}`); } catch {}
      this.abilityCd = 12;
    } else {
      // Regen self + fire + explosions
      try { boss.runCommandAsync("effect @s regeneration 99999 0 true"); } catch {}
      for (const p of this.getNearbyPlayers(dim, loc, 8)) {
        try {
          p.applyDamage(4, { cause: "entityExplosion" });
        } catch {}
      }
      for (const p of this.getNearbyPlayers(dim, loc, 5)) {
        try { p.applyDamage(2, { cause: "fire" }); } catch {}
      }
      this.abilityCd = 8;
    }
  }

  /** Boss 8: Soul Warden — wither + soul harvest */
  abilitySoulWarden(boss, loc, dim) {
    const nearby = this.getNearbyPlayers(dim, loc, 12);
    if (this.phase === 1) {
      for (const p of nearby) {
        try { p.runCommandAsync("effect @s weakness 5 0 true"); } catch {}
      }
      this.abilityCd = 5;
    } else if (this.phase === 2) {
      for (const p of nearby) {
        try {
          p.runCommandAsync("effect @s weakness 5 0 true");
          p.runCommandAsync("effect @s wither 10 1 true");
        } catch {}
      }
      this.abilityCd = 10;
    } else {
      // Soul harvest — direct wither damage
      for (const p of this.getNearbyPlayers(dim, loc, 8)) {
        try {
          p.runCommandAsync("effect @s weakness 5 0 true");
          p.applyDamage(6, { cause: "magic" });
        } catch {}
      }
      this.abilityCd = 12;
    }
  }

  /** Boss 9: Crimson Behemoth — tremors + rampage */
  abilityCrimsonBehemoth(boss, loc, dim) {
    if (this.phase === 1) {
      this.abilityCd = 5; // Ambient only
    } else if (this.phase === 2) {
      // Tremor pulse
      for (const p of this.getNearbyPlayers(dim, loc, 10)) {
        try {
          p.runCommandAsync("effect @s levitation 1 2 true");
          p.applyDamage(3, { cause: "entityAttack", damagingEntity: boss });
        } catch {}
      }
      this.abilityCd = 8;
    } else {
      // Speed + stronger tremor
      try { boss.runCommandAsync("effect @s speed 99999 2 true"); } catch {}
      for (const p of this.getNearbyPlayers(dim, loc, 10)) {
        try {
          p.runCommandAsync("effect @s levitation 1 2 true");
          p.applyDamage(4, { cause: "entityAttack", damagingEntity: boss });
        } catch {}
      }
      this.abilityCd = 6;
    }
  }

  /** Boss 10: Void Sovereign — teleport + void */
  abilityVoidSovereign(boss, loc, dim) {
    const players = this.getNearbyPlayers(dim, loc, 50);
    if (players.length === 0) { this.abilityCd = 5; return; }

    if (this.phase === 1) {
      // Levitation pulse
      for (const p of this.getNearbyPlayers(dim, loc, 15)) {
        try { p.runCommandAsync("effect @s levitation 2 0 true"); } catch {}
      }
      this.abilityCd = 15;
    } else if (this.phase === 2) {
      // Teleport to random player
      const target = players[Math.floor(Math.random() * players.length)];
      try {
        const tl = target.location;
        boss.teleport({ x: tl.x + 2, y: tl.y, z: tl.z + 2 });
        boss.runCommandAsync("playsound mob.endermen.portal @a ~ ~ ~ 1 1");
      } catch {}
      // Blindness every 3rd teleport tracked via abilityCd reset count
      if (Math.random() < 0.33) {
        for (const p of this.getNearbyPlayers(dim, boss.location, 15)) {
          try { p.runCommandAsync("effect @s blindness 5 0 true"); } catch {}
        }
      }
      this.abilityCd = 5;
    } else {
      // Rapid teleport + self-regen
      const target = players[Math.floor(Math.random() * players.length)];
      try {
        const tl = target.location;
        boss.teleport({ x: tl.x + 2, y: tl.y, z: tl.z + 2 });
        boss.runCommandAsync("playsound mob.endermen.portal @a ~ ~ ~ 1 1");
        boss.runCommandAsync("effect @s regeneration 5 0 true");
      } catch {}
      this.abilityCd = 3;
    }
  }

  /** Boss 11: Ender Architect — shulker summons + levitation */
  abilityEnderArchitect(boss, loc, dim) {
    if (this.phase === 1) {
      // Summon 2 shulkers
      for (let i = 0; i < 2; i++) {
        try {
          const offset = (i === 0 ? 3 : -3);
          dim.spawnEntity("minecraft:shulker", { x: loc.x + offset, y: loc.y, z: loc.z });
        } catch {}
      }
      this.abilityCd = 10;
    } else if (this.phase === 2) {
      // Levitation aura + 1 shulker
      for (const p of this.getNearbyPlayers(dim, loc, 8)) {
        try { p.runCommandAsync("effect @s levitation 3 0 true"); } catch {}
      }
      try {
        dim.spawnEntity("minecraft:shulker", { x: loc.x + 2, y: loc.y, z: loc.z + 2 });
      } catch {}
      this.abilityCd = 8;
    } else {
      // Levitation aura + resistance self + 2 shulkers
      for (const p of this.getNearbyPlayers(dim, loc, 8)) {
        try { p.runCommandAsync("effect @s levitation 3 0 true"); } catch {}
      }
      try { boss.runCommandAsync("effect @s resistance 99999 0 true"); } catch {}
      for (let i = 0; i < 2; i++) {
        const angle = (i * Math.PI) + Math.random();
        try {
          dim.spawnEntity("minecraft:shulker", {
            x: loc.x + Math.cos(angle) * 3,
            y: loc.y,
            z: loc.z + Math.sin(angle) * 3,
          });
        } catch {}
      }
      this.abilityCd = 6;
    }
  }

  // ─── ANTI-RANGE SYSTEM ────────────────────────────────────────

  tickAntiRange() {
    if (!this.bossEntity) return;
    const bossLoc = this.bossEntity.location;
    const dim = this.bossEntity.dimension;

    for (const player of world.getAllPlayers()) {
      if (!player.hasTag("wb.participant")) continue;
      const pl = player.location;
      const dist = Math.sqrt(
        (pl.x - bossLoc.x) ** 2 + (pl.y - bossLoc.y) ** 2 + (pl.z - bossLoc.z) ** 2
      );

      try {
        if (dist >= RANGE_EXTREME) {
          player.runCommandAsync("effect @s slowness 5 3 true");
          player.runCommandAsync("effect @s weakness 5 2 true");
          player.runCommandAsync("effect @s wither 5 1 true");
          player.runCommandAsync("effect @s darkness 5 0 true");
        } else if (dist >= RANGE_DANGER) {
          player.runCommandAsync("effect @s slowness 5 2 true");
          player.runCommandAsync("effect @s weakness 5 1 true");
          player.runCommandAsync("effect @s wither 5 0 true");
        } else if (dist >= RANGE_WARNING) {
          player.runCommandAsync("effect @s slowness 5 1 true");
          player.runCommandAsync("effect @s glowing 5 0 true");
        }
      } catch {}
    }

    // Despawn minions that are too far
    try {
      const minions = dim.getEntities({
        tags: ["wb.minion"],
      });
      for (const m of minions) {
        const ml = m.location;
        const mDist = Math.sqrt(
          (ml.x - bossLoc.x) ** 2 + (ml.y - bossLoc.y) ** 2 + (ml.z - bossLoc.z) ** 2
        );
        if (mDist > MINION_DESPAWN_RANGE) {
          try { m.kill(); } catch {}
        }
      }
    } catch {}
  }

  // ─── BOSS DEFEATED ────────────────────────────────────────────

  onBossDefeated(entity, killer) {
    const bossId = this.activeBossId;
    const def = BOSSES[bossId];
    if (!def) return;

    this.activeBossId = 0;
    this.bossEntity = null;
    this.phase = 0;
    this.storage.set("wb_active", 0);

    // Kill remaining minions
    try {
      const minions = entity.dimension.getEntities({ tags: ["wb.minion"] });
      for (const m of minions) {
        try { m.kill(); } catch {}
      }
    } catch {}

    // Announce victory
    for (const p of world.getAllPlayers()) {
      p.sendMessage(`§a§l✦ ${def.name} §r§7has been defeated!`);
      p.onScreenDisplay.setTitle("§a§lVictory!", {
        subtitle: `§7${def.name} has fallen!`,
        fadeInDuration: 10, stayDuration: 100, fadeOutDuration: 20,
      });
      p.playSound("mob.wither.death");
    }

    // Reward participants
    for (const p of world.getAllPlayers()) {
      if (!p.hasTag("wb.participant") && p !== killer) continue;

      const s = StorageManager.forPlayer(p);
      const kills = s.getNumber(`wb_k${bossId}`, 0) + 1;
      s.set(`wb_k${bossId}`, kills);
      const totalKills = s.getNumber("boss_kills", 0) + 1;
      s.set("boss_kills", totalKills);

      // XP reward
      try { p.runCommandAsync("xp 500 @s"); } catch {}

      // Crate reward based on luck
      const luck = s.getNumber("luck", 0);
      let crateTier = "rare";
      if (luck >= 50) crateTier = "mythical";
      else if (luck >= 40) crateTier = "exquisite";
      else if (luck >= 30) crateTier = "ornate";

      try {
        p.runCommandAsync(`loot give @s loot "crates/${crateTier}"`);
      } catch {}

      // Exclusive artifact: guaranteed for killer, 25% for others
      const isKiller = killer && p.name === killer.name;
      if (isKiller || Math.random() < 0.25) {
        try {
          p.runCommandAsync(`loot give @s loot "bosses/exclusive_${bossId}"`);
          p.sendMessage(`${def.color}§l✦ §r§7You received a boss-exclusive artifact!`);
        } catch {}
      }

      // Dream Rate bonus
      const dr = s.getNumber("dream_rate", 0);
      s.set("dream_rate", dr + 1.5);
      p.sendMessage("§d+1.5 Dream Rate §7(Boss Kill)");

      // Title progression check
      this.checkTitleUnlock(p, bossId, kills, def);

      // Champion check (all 11 bosses killed at least once)
      this.checkChampionTitle(p);

      // Clean up tag
      p.removeTag("wb.participant");
    }

    // Killer announcement
    if (killer) {
      for (const p of world.getAllPlayers()) {
        p.sendMessage(`§6§l${killer.name} §r§7dealt the final blow to §l${def.name}§r§7!`);
      }
    }

    this.participants.clear();
    console.log(`[WorldBoss] ${def.name} defeated by ${killer?.name || "unknown"}`);
  }

  // ─── FIGHT TIMER ──────────────────────────────────────────────

  tickTimer() {
    if (!this.bossEntity) return;
    this.fightTimer++;

    if (this.fightTimer === WARN_TIME_1) {
      const def = BOSSES[this.activeBossId];
      for (const p of world.getAllPlayers()) {
        p.sendMessage(`§e§l⚠ §r§7${def?.name} grows restless... §f3 minutes remaining!`);
      }
    } else if (this.fightTimer === WARN_TIME_2) {
      const def = BOSSES[this.activeBossId];
      for (const p of world.getAllPlayers()) {
        p.sendMessage(`§c§l⚠ §r§7${def?.name} is fading... §f1 minute remaining!`);
      }
    } else if (this.fightTimer >= MAX_FIGHT_TIME) {
      this.despawnBoss();
    }
  }

  despawnBoss() {
    const def = BOSSES[this.activeBossId];
    if (this.bossEntity) {
      try { this.bossEntity.kill(); } catch {}
    }

    // Kill minions
    try {
      const dim = world.getDimension("overworld");
      const minions = dim.getEntities({ tags: ["wb.minion"] });
      for (const m of minions) {
        try { m.kill(); } catch {}
      }
    } catch {}

    for (const p of world.getAllPlayers()) {
      p.sendMessage(`§7§l${def?.name || "The boss"} §r§7has escaped...`);
      p.removeTag("wb.participant");
    }

    this.activeBossId = 0;
    this.bossEntity = null;
    this.phase = 0;
    this.fightTimer = 0;
    this.participants.clear();
    this.storage.set("wb_active", 0);
  }

  // ─── BOSSBAR (actionbar display) ──────────────────────────────

  tickBossbar() {
    if (!this.bossEntity) return;
    try {
      const hp = this.bossEntity.getComponent("minecraft:health");
      if (!hp) return;
      const def = BOSSES[this.activeBossId];
      if (!def) return;

      const pct = Math.floor((hp.currentValue / hp.effectiveMax) * 100);
      const barLen = 20;
      const filled = Math.floor(barLen * (hp.currentValue / hp.effectiveMax));
      const bar = "§a" + "█".repeat(filled) + "§7" + "░".repeat(barLen - filled);

      const nearby = this.bossEntity.dimension.getEntities({
        type: "minecraft:player",
        location: this.bossEntity.location,
        maxDistance: 100,
      });
      for (const p of nearby) {
        p.onScreenDisplay.setActionBar(
          `${def.color}§l${def.name} §r§7P${this.phase} ${bar} §f${pct}%`
        );
      }
    } catch {}
  }

  // ─── HELPERS ──────────────────────────────────────────────────

  getNearbyPlayers(dim, loc, radius) {
    try {
      return [...dim.getEntities({
        type: "minecraft:player",
        location: loc,
        maxDistance: radius,
      })];
    } catch { return []; }
  }

  // ─── MAIN TICK (called every 5 seconds from main.js) ─────────

  tick() {
    if (!this.bossEntity) {
      // Check if we should try to detect a stale boss reference
      if (this.activeBossId > 0) {
        this.activeBossId = 0;
        this.storage.set("wb_active", 0);
      }
      return;
    }

    // Validate boss still alive
    try {
      const hp = this.bossEntity.getComponent("minecraft:health");
      if (!hp || hp.currentValue <= 0) {
        this.activeBossId = 0;
        this.bossEntity = null;
        this.storage.set("wb_active", 0);
        return;
      }
    } catch {
      this.activeBossId = 0;
      this.bossEntity = null;
      this.storage.set("wb_active", 0);
      return;
    }

    // Phase check
    this.checkPhaseTransition();

    // Abilities
    this.tickAbilities();

    // Anti-range
    this.tickAntiRange();

    // Bossbar
    this.tickBossbar();

    // Timer (1 call = 5 seconds from main tick interval)
    this.fightTimer += 5;
    if (this.fightTimer === WARN_TIME_1 || (this.fightTimer > WARN_TIME_1 - 5 && this.fightTimer <= WARN_TIME_1)) {
      const def = BOSSES[this.activeBossId];
      for (const p of world.getAllPlayers()) {
        p.sendMessage(`§e§l⚠ §r§7${def?.name} grows restless... §f3 minutes remaining!`);
      }
    }
    if (this.fightTimer >= WARN_TIME_2 && this.fightTimer < WARN_TIME_2 + 5) {
      const def = BOSSES[this.activeBossId];
      for (const p of world.getAllPlayers()) {
        p.sendMessage(`§c§l⚠ §r§7${def?.name} is fading... §f1 minute remaining!`);
      }
    }
    if (this.fightTimer >= MAX_FIGHT_TIME) {
      this.despawnBoss();
    }
  }

  // ─── TITLE SYSTEM ───────────────────────────────────────────

  /**
   * Check if a player unlocked a new boss title.
   * Titles: 10 kills = Slayer, 25 = Conqueror, 50 = Vanquisher, 100 = Nemesis
   */
  checkTitleUnlock(player, bossId, killCount, bossDef) {
    const s = StorageManager.forPlayer(player);

    for (let i = TITLE_TIERS.length - 1; i >= 0; i--) {
      const tier = TITLE_TIERS[i];
      if (killCount >= tier.kills) {
        const titleId = (bossId - 1) * 4 + (i + 1);
        const currentTitle = s.getNumber("wb_title", 0);

        // Only announce if this is a new title tier for this boss
        const prevTitleForBoss = s.getNumber(`wb_title_${bossId}`, 0);
        if (i + 1 > prevTitleForBoss) {
          s.set(`wb_title_${bossId}`, i + 1);

          const titleName = `${bossDef.name} ${tier.suffix}`;
          const color = TITLE_COLORS[i];

          player.sendMessage(`\n${color}✦ Title Unlocked: ${titleName} ✦§r`);
          player.sendMessage(`§7Defeat ${bossDef.name} ${tier.kills} times — ${color}${tier.suffix}§r`);
          player.playSound("random.levelup", { volume: 0.8, pitch: 1.0 + i * 0.1 });

          // Auto-equip if higher than current
          if (titleId > currentTitle) {
            s.set("wb_title", titleId);
            s.set("wb_title_name", titleName);
            player.sendMessage(`§7Title equipped: ${color}${titleName}`);
          }
        }
        break; // Only award highest qualifying tier
      }
    }
  }

  /**
   * Check if player has killed all 11 bosses at least once → Champion title.
   */
  checkChampionTitle(player) {
    const s = StorageManager.forPlayer(player);
    if (s.get("wb_champion")) return;

    let allKilled = true;
    for (let i = 1; i <= 11; i++) {
      if (s.getNumber(`wb_k${i}`, 0) < 1) {
        allKilled = false;
        break;
      }
    }

    if (allKilled) {
      s.set("wb_champion", true);
      s.set("wb_title", 45); // Champion ID
      s.set("wb_title_name", "World Boss Champion");

      player.sendMessage("\n§6§l✦ ✦ ✦ WORLD BOSS CHAMPION ✦ ✦ ✦§r");
      player.sendMessage("§7You have defeated every world boss at least once!");
      player.sendMessage("§6Title equipped: §l§6World Boss Champion");
      player.playSound("ui.toast.challenge_complete", { volume: 1.5, pitch: 1.0 });

      try { player.dimension.spawnParticle("minecraft:totem_particle", player.location); } catch {}

      // Server announcement
      for (const p of world.getAllPlayers()) {
        p.sendMessage(`§6§l✦ §r§f${player.name} §7has become §6§lWorld Boss Champion§r§7!`);
      }
    }
  }

  /** Get player's current title display name */
  getPlayerTitle(player) {
    const s = StorageManager.forPlayer(player);
    return s.get("wb_title_name") || null;
  }
}
