/**
 * Luck & Accessory System — Luck attribute stacking from accessories,
 * journal progress, cooking buffs, advantage trees, and set bonuses.
 * Affects crate tier rolls, rare drop chances, fishing quality.
 * Replaces Java luck_buffs/ + accessories/ folders.
 */
import { world, system } from "@minecraft/server";
import { StorageManager } from "../utils/storage.js";
import { ActionFormData } from "@minecraft/server-ui";

// ─── ACCESSORY DEFINITIONS ──────────────────────────────────
// Each accessory is a custom item (forevercraft:*) worn in offhand or detected by tag
const ACCESSORIES = {
  // Tier 1: Common (+1 Luck)
  lucky_coin: { name: "Lucky Coin", luck: 1, desc: "A coin that always lands heads" },
  rabbits_foot: { name: "Rabbit's Foot", luck: 1, desc: "Classic good-luck charm" },
  four_leaf_clover: { name: "Four-Leaf Clover", luck: 1, desc: "Found in a meadow" },
  horseshoe: { name: "Horseshoe", luck: 1, desc: "Hung above your doorway" },
  wishbone: { name: "Wishbone", luck: 1, desc: "You got the bigger half" },
  dream_catcher: { name: "Dream Catcher", luck: 1, desc: "Filters bad fortune" },

  // Tier 2: Uncommon (+2 Luck)
  golden_acorn: { name: "Golden Acorn", luck: 2, desc: "Fallen from a gilded oak" },
  jade_pendant: { name: "Jade Pendant", luck: 2, desc: "Cool to the touch" },
  star_fragment: { name: "Star Fragment", luck: 2, desc: "A piece of a fallen star" },
  moonstone_ring: { name: "Moonstone Ring", luck: 2, desc: "Glows faintly at night" },
  charm_bracelet: { name: "Charm Bracelet", luck: 2, desc: "Jingling with tiny charms" },
  fortune_compass: { name: "Fortune Compass", luck: 2, desc: "Always points to treasure" },

  // Tier 3: Rare (+3 Luck)
  amethyst_amulet: { name: "Amethyst Amulet", luck: 3, desc: "Resonates with fortune" },
  dragon_scale_charm: { name: "Dragon Scale Charm", luck: 3, desc: "Warm to the touch" },
  pirates_doubloon: { name: "Pirate's Doubloon", luck: 3, desc: "From a legendary hoard" },
  phoenix_feather: { name: "Phoenix Feather", luck: 3, desc: "Never burns out" },
  wishing_pearl: { name: "Wishing Pearl", luck: 3, desc: "One wish remaining" },
  enchanted_dice: { name: "Enchanted Dice", luck: 3, desc: "Always rolls high" },

  // Tier 4: Epic (+4 Luck)
  crown_of_fortune: { name: "Crown of Fortune", luck: 4, desc: "Worn by a lucky king" },
  golden_scarab: { name: "Golden Scarab", luck: 4, desc: "Ancient pharaoh's blessing" },
  fates_monocle: { name: "Fate's Monocle", luck: 4, desc: "See the threads of destiny" },
  djinn_lamp: { name: "Djinn's Lamp", luck: 4, desc: "Three wishes, all for luck" },
  sovereigns_signet: { name: "Sovereign's Signet", luck: 4, desc: "Royal seal of prosperity" },
  astral_prism: { name: "Astral Prism", luck: 4, desc: "Bends probability" },

  // Tier 5: Legendary (+5 Luck)
  dream_aegis: { name: "Dream Aegis", luck: 5, desc: "Shield woven from dreams" },
  heart_of_fortune: { name: "Heart of Fortune", luck: 5, desc: "Pulses with pure luck" },
  cosmic_talisman: { name: "Cosmic Talisman", luck: 5, desc: "Aligned with the cosmos" },
  eternal_clover: { name: "Eternal Clover", luck: 5, desc: "Never wilts, always lucky" },
  fabled_compass: { name: "Fabled Compass", luck: 5, desc: "Points to your destiny" },
  void_lens: { name: "Void Lens", luck: 5, desc: "Peers beyond probability" },
};

// ─── LUCK SOURCES ───────────────────────────────────────────
// Bonus luck from various systems
const JOURNAL_LUCK_THRESHOLDS = [
  { discoveries: 10, luck: 1 },
  { discoveries: 25, luck: 2 },
  { discoveries: 50, luck: 3 },
  { discoveries: 100, luck: 4 },
  { discoveries: 200, luck: 5 },
];

const COOKING_LUCK_THRESHOLDS = [
  { mastery: 25, luck: 1 },
  { mastery: 50, luck: 2 },
  { mastery: 100, luck: 3 },
];

const ADVANTAGE_LUCK_MAP = {
  // Specific trees that grant luck bonuses at high levels
  gathering: { level: 15, luck: 1 },
  mining: { level: 15, luck: 1 },
  fishing: { level: 10, luck: 2 },
  explorer: { level: 20, luck: 2 },
};

export class LuckSystem {
  constructor(eventBridge) {
    // Listen for accessory equip changes
    eventBridge.on("player_equip_change", (player) => {
      this.recalculateLuck(player);
    });
  }

  // ─── LUCK CALCULATION ───────────────────────────────────

  recalculateLuck(player) {
    const s = StorageManager.forPlayer(player);
    let totalLuck = 0;

    // 1. Accessory luck (offhand item)
    const accessoryLuck = this.getAccessoryLuck(player);
    totalLuck += accessoryLuck;

    // 2. Journal discovery luck
    const discoveries = s.getNumber("jrn_total", 0);
    for (let i = JOURNAL_LUCK_THRESHOLDS.length - 1; i >= 0; i--) {
      if (discoveries >= JOURNAL_LUCK_THRESHOLDS[i].discoveries) {
        totalLuck += JOURNAL_LUCK_THRESHOLDS[i].luck;
        break;
      }
    }

    // 3. Cooking mastery luck
    let totalMastery = 0;
    const categories = ["combat", "mining", "fortune", "wayfarer", "delicacy", "seasonal", "treats"];
    for (const cat of categories) {
      totalMastery += s.getNumber(`ck_mastery_${cat}`, 0);
    }
    for (let i = COOKING_LUCK_THRESHOLDS.length - 1; i >= 0; i--) {
      if (totalMastery >= COOKING_LUCK_THRESHOLDS[i].mastery) {
        totalLuck += COOKING_LUCK_THRESHOLDS[i].luck;
        break;
      }
    }

    // 4. Advantage tree luck
    for (const [tree, config] of Object.entries(ADVANTAGE_LUCK_MAP)) {
      const treeLevel = s.getNumber(`adv_${tree}`, 0);
      if (treeLevel >= config.level) {
        totalLuck += config.luck;
      }
    }

    // 5. Fortune meal active
    if (s.getNumber("ck_fortune", 0) > 0) {
      totalLuck += 3;
    }

    // 6. Dreaming Ember bonus
    if (player.hasTag("ec.dreaming_ember")) {
      totalLuck += 1;
    }

    // 7. Prestige bonus (total armor prestige / 3)
    let totalPrestige = 0;
    for (const slot of ["head", "chest", "legs", "feet"]) {
      totalPrestige += s.getNumber(`am_prestige_${slot}`, 0);
    }
    totalLuck += Math.floor(totalPrestige / 3);

    // Store the final luck value
    s.set("luck", totalLuck);

    // Apply luck effect level (minecraft luck effect for loot table integration)
    try {
      if (totalLuck > 0) {
        const effectLevel = Math.min(totalLuck - 1, 254);
        player.runCommandAsync(`effect @s luck 25 ${effectLevel} true`);
      } else {
        player.runCommandAsync("effect @s luck 0 0 true");
      }
    } catch {}
  }

  getAccessoryLuck(player) {
    const equip = player.getComponent("minecraft:equippable");
    if (!equip) return 0;

    const offhand = equip.getEquipment("Offhand");
    if (!offhand) return 0;

    const typeId = (offhand.typeId || "").replace("forevercraft:", "");
    const accessory = ACCESSORIES[typeId];
    return accessory ? accessory.luck : 0;
  }

  // ─── LUCK UTILITY (for other systems) ─────────────────

  /** Get player's current luck value */
  getLuck(player) {
    return StorageManager.forPlayer(player).getNumber("luck", 0);
  }

  /** Roll with luck bonus: returns true with chance = base + luck * scale */
  luckRoll(player, baseChance, luckScale = 0.01) {
    const luck = this.getLuck(player);
    const chance = Math.min(baseChance + luck * luckScale, 0.95);
    return Math.random() < chance;
  }

  /** Get a tier bonus from luck (0-3 extra tiers for crates) */
  luckTierBonus(player) {
    const luck = this.getLuck(player);
    if (luck >= 20) return 3;
    if (luck >= 12) return 2;
    if (luck >= 5) return 1;
    return 0;
  }

  // ─── GUI ──────────────────────────────────────────────────

  openMenu(player) {
    const s = StorageManager.forPlayer(player);
    const totalLuck = s.getNumber("luck", 0);

    // Break down sources
    const accessoryLuck = this.getAccessoryLuck(player);

    const discoveries = s.getNumber("jrn_total", 0);
    let journalLuck = 0;
    for (let i = JOURNAL_LUCK_THRESHOLDS.length - 1; i >= 0; i--) {
      if (discoveries >= JOURNAL_LUCK_THRESHOLDS[i].discoveries) {
        journalLuck = JOURNAL_LUCK_THRESHOLDS[i].luck;
        break;
      }
    }

    let totalMastery = 0;
    const categories = ["combat", "mining", "fortune", "wayfarer", "delicacy", "seasonal", "treats"];
    for (const cat of categories) totalMastery += s.getNumber(`ck_mastery_${cat}`, 0);
    let cookingLuck = 0;
    for (let i = COOKING_LUCK_THRESHOLDS.length - 1; i >= 0; i--) {
      if (totalMastery >= COOKING_LUCK_THRESHOLDS[i].mastery) {
        cookingLuck = COOKING_LUCK_THRESHOLDS[i].luck;
        break;
      }
    }

    let advLuck = 0;
    for (const [tree, config] of Object.entries(ADVANTAGE_LUCK_MAP)) {
      if (s.getNumber(`adv_${tree}`, 0) >= config.level) advLuck += config.luck;
    }

    const fortuneActive = s.getNumber("ck_fortune", 0) > 0;
    const emberBonus = player.hasTag("ec.dreaming_ember") ? 1 : 0;
    let totalPrestige = 0;
    for (const slot of ["head", "chest", "legs", "feet"]) {
      totalPrestige += s.getNumber(`am_prestige_${slot}`, 0);
    }
    const prestigeLuck = Math.floor(totalPrestige / 3);

    let body = `§6§lTotal Luck: §f${totalLuck}\n\n`;
    body += `§7Sources:\n`;
    body += `  §e⬥ §7Accessory: §f+${accessoryLuck}\n`;
    body += `  §e⬥ §7Journal (${discoveries} discoveries): §f+${journalLuck}\n`;
    body += `  §e⬥ §7Cooking Mastery (${totalMastery}): §f+${cookingLuck}\n`;
    body += `  §e⬥ §7Advantage Trees: §f+${advLuck}\n`;
    if (fortuneActive) body += `  §e⬥ §7Fortune Meal: §f+3\n`;
    if (emberBonus) body += `  §e⬥ §7Dreaming Ember: §f+1\n`;
    if (prestigeLuck) body += `  §e⬥ §7Armor Prestige: §f+${prestigeLuck}\n`;

    body += `\n§7Effects:\n`;
    const tierBonus = this.luckTierBonus(player);
    body += `  §a⬥ §7Crate Tier Bonus: §f+${tierBonus}\n`;
    body += `  §a⬥ §7Rare Drop Bonus: §f+${Math.floor(totalLuck * 1)}%\n`;
    body += `  §a⬥ §7Fishing Quality: §f+${Math.floor(totalLuck * 0.5)}%\n`;

    const form = new ActionFormData()
      .title("§6☘ Luck & Accessories")
      .body(body)
      .button("§eAccessory List")
      .button("§7Close");

    form.show(player).then(response => {
      if (response.canceled || response.selection === 1) return;
      if (response.selection === 0) this.openAccessoryList(player);
    });
  }

  openAccessoryList(player) {
    const equip = player.getComponent("minecraft:equippable");
    const offhand = equip?.getEquipment("Offhand");
    const currentId = offhand ? (offhand.typeId || "").replace("forevercraft:", "") : "";

    let body = "§7Equip an accessory in your offhand for luck bonuses.\n\n";

    // Group by tier
    const tiers = [
      { name: "§7Common (+1)", min: 1, max: 1 },
      { name: "§aUncommon (+2)", min: 2, max: 2 },
      { name: "§bRare (+3)", min: 3, max: 3 },
      { name: "§dEpic (+4)", min: 4, max: 4 },
      { name: "§6Legendary (+5)", min: 5, max: 5 },
    ];

    for (const tier of tiers) {
      body += `${tier.name}\n`;
      for (const [id, acc] of Object.entries(ACCESSORIES)) {
        if (acc.luck >= tier.min && acc.luck <= tier.max) {
          const equipped = id === currentId ? " §a[EQUIPPED]" : "";
          body += `  §7- ${acc.name}${equipped}\n`;
        }
      }
    }

    const form = new ActionFormData()
      .title("§e☘ Accessories")
      .body(body)
      .button("§7← Back");

    form.show(player).then(response => {
      if (response.canceled) return;
      this.openMenu(player);
    });
  }

  // ─── TICK ─────────────────────────────────────────────────

  tick(players) {
    for (const player of players) {
      this.recalculateLuck(player);
    }
  }
}
