/**
 * News Ticker — Daily summary of server activity.
 * Replaces Java news/ folder (7 mcfunction files).
 *
 * Tracks daily: quests completed, bosses killed, crates opened, dungeons cleared.
 * Displays summary on login and at dawn.
 */
import { world } from "@minecraft/server";
import { StorageManager } from "../utils/storage.js";

export class NewsTickerSystem {
  constructor(eventBridge) {
    this.eventBridge = eventBridge;
    this.ws = StorageManager.world();
    this.lastNewsDay = -1;

    eventBridge.on("quest_completed", () => this.increment("news_quests"));
    eventBridge.on("raid_boss_killed", () => this.increment("news_bosses"));
    eventBridge.on("crate_revealed", () => this.increment("news_crates"));
    eventBridge.on("dungeon_cleared", () => this.increment("news_dungeons"));
    eventBridge.on("player_join", (player) => this.showNews(player));
  }

  increment(key) {
    this.ws.set(key, (this.ws.getNumber(key, 0) || 0) + 1);
  }

  /** Reset counters at dawn (called from tick) */
  tick() {
    const day = world.getDay();
    if (day === this.lastNewsDay) return;
    this.lastNewsDay = day;

    // Archive yesterday's stats then reset
    this.ws.set("news_quests_prev", this.ws.getNumber("news_quests", 0));
    this.ws.set("news_bosses_prev", this.ws.getNumber("news_bosses", 0));
    this.ws.set("news_crates_prev", this.ws.getNumber("news_crates", 0));
    this.ws.set("news_dungeons_prev", this.ws.getNumber("news_dungeons", 0));

    this.ws.set("news_quests", 0);
    this.ws.set("news_bosses", 0);
    this.ws.set("news_crates", 0);
    this.ws.set("news_dungeons", 0);

    // Dawn announcement
    for (const p of world.getAllPlayers()) {
      this.showNews(p, true);
    }
  }

  showNews(player, isDawn = false) {
    const quests = this.ws.getNumber(isDawn ? "news_quests_prev" : "news_quests", 0);
    const bosses = this.ws.getNumber(isDawn ? "news_bosses_prev" : "news_bosses", 0);
    const crates = this.ws.getNumber(isDawn ? "news_crates_prev" : "news_crates", 0);
    const dungeons = this.ws.getNumber(isDawn ? "news_dungeons_prev" : "news_dungeons", 0);

    if (quests + bosses + crates + dungeons === 0 && !isDawn) return;

    const label = isDawn ? "Yesterday's" : "Today's";
    player.sendMessage(`\n§e§l✦ ${label} News ✦§r`);
    if (quests > 0) player.sendMessage(`  §7Quests Completed: §f${quests}`);
    if (bosses > 0) player.sendMessage(`  §7Bosses Defeated: §f${bosses}`);
    if (crates > 0) player.sendMessage(`  §7Crates Opened: §f${crates}`);
    if (dungeons > 0) player.sendMessage(`  §7Dungeons Cleared: §f${dungeons}`);
    if (quests + bosses + crates + dungeons === 0) player.sendMessage("  §8No activity recorded.");
    player.sendMessage("");
  }
}
