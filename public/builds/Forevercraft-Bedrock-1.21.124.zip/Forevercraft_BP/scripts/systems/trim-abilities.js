/**
 * Trim Abilities System — Custom armor trim effects (16 patterns).
 * Replaces Java trim/ folder (123 mcfunction files).
 *
 * Full set (4pc): Major ability. Single piece: Minor passive.
 * Detected via custom_data flag: trim_abilities_[pattern]:1b
 */
import { world, system } from "@minecraft/server";
import { StorageManager } from "../utils/storage.js";

// 16 trim patterns with full-set and single-piece abilities
const TRIM_PATTERNS = {
  bolt:      { name: "Bolt",      fullSet: "10% lightning strike on attack",         single: "Lightning aura (visual)" },
  coast:     { name: "Coast",     fullSet: "Dolphins Grace + Luck + Looting on kill", single: "Water dash + swim speed" },
  dune:      { name: "Dune",      fullSet: "Speed V + step height 3 in deserts",     single: "Saturation in hot biomes" },
  eye:       { name: "Eye",       fullSet: "Night Vision + spyglass teleport",       single: "Glowing item indicator" },
  flow:      { name: "Flow",      fullSet: "Wind ball mount (auto-jump parkour)",    single: "Fall damage reduction" },
  rib:       { name: "Rib",       fullSet: "Fire aspect on melee",                   single: "Wither aura (1.5s)" },
  sentry:    { name: "Sentry",    fullSet: "Summon iron golems on pillager sight",   single: "Creeper explosion prevent" },
  silence:   { name: "Silence",   fullSet: "Sonic boom bow (ranged attack)",         single: "Warden prevention" },
  snout:     { name: "Snout",     fullSet: "Fire Resistance + enhanced bartering",   single: "Extra piglin trade items" },
  spire:     { name: "Spire",     fullSet: "Reflect fall damage as weakness",        single: "Weakness on attack" },
  tide:      { name: "Tide",      fullSet: "Guardian ally summon + management",      single: "Water breathing passive" },
  vex:       { name: "Vex",       fullSet: "Vex ally on attack (max 1, 10t cd)",     single: "Evoker fangs on attack" },
  ward:      { name: "Ward",      fullSet: "Permanent Resistance I",                 single: "Extra resistance aura" },
  wayfinder: { name: "Wayfinder", fullSet: "Structure compass",                      single: "Nearest structure path" },
  wild:      { name: "Wild",      fullSet: "Haste II + wolf pack summon",            single: "Speed + tamed pet boost" },
  shaper:    { name: "Shaper",    fullSet: "Create bundles on demand",               single: "Bundle production" },
};

export class TrimAbilitySystem {
  constructor(eventBridge) {
    this.eventBridge = eventBridge;
    /** @type {Map<string, {pattern: string|null, fullSet: boolean, cooldowns: Object}>} */
    this.playerTrimState = new Map();

    // Combat triggers
    eventBridge.on("player_dealt_damage", (data) => {
      if (data.player) this.onAttack(data.player, data.target);
    });
  }

  /**
   * Detect equipped trim pattern (called every 100 ticks).
   */
  detectTrims(player) {
    const s = StorageManager.forPlayer(player);

    // Check for trim patterns in armor tags
    let matchedPattern = null;
    let pieceCount = 0;

    for (const [pattern] of Object.entries(TRIM_PATTERNS)) {
      // Check if player has any armor with this trim
      if (player.hasTag(`ec.trim_${pattern}`)) {
        matchedPattern = pattern;
        // Count pieces
        for (const slot of ["head", "chest", "legs", "feet"]) {
          if (player.hasTag(`ec.trim_${pattern}_${slot}`)) pieceCount++;
        }
        break;
      }
    }

    let state = this.playerTrimState.get(player.id);
    if (!state) {
      state = { pattern: null, fullSet: false, cooldowns: {} };
      this.playerTrimState.set(player.id, state);
    }

    state.pattern = matchedPattern;
    state.fullSet = pieceCount >= 4;

    return state;
  }

  /**
   * Apply passive trim effects (called every 20 ticks).
   */
  tickPassives(players) {
    for (const player of players) {
      const state = this.playerTrimState.get(player.id);
      if (!state || !state.pattern) continue;

      const pattern = state.pattern;
      const full = state.fullSet;

      try {
        switch (pattern) {
          case "ward":
            if (full) player.addEffect("resistance", 40, { amplifier: 0, showParticles: false });
            break;

          case "coast":
            if (full) {
              player.addEffect("dolphins_grace", 40, { amplifier: 0, showParticles: false });
              player.addEffect("luck", 40, { amplifier: 0, showParticles: false });
            } else {
              // Single: swim speed in water
              try {
                const block = player.dimension.getBlock(player.location);
                if (block?.typeId === "minecraft:water") {
                  player.addEffect("dolphins_grace", 40, { amplifier: 0, showParticles: false });
                }
              } catch {}
            }
            break;

          case "dune":
            if (full) {
              // Speed V in desert/badlands biomes (simplified: below y=100 in hot areas)
              player.addEffect("speed", 40, { amplifier: 4, showParticles: false });
            } else {
              player.addEffect("saturation", 40, { amplifier: 0, showParticles: false });
            }
            break;

          case "eye":
            if (full) {
              player.addEffect("night_vision", 40, { amplifier: 0, showParticles: false });
            }
            break;

          case "snout":
            if (full) {
              player.addEffect("fire_resistance", 40, { amplifier: 0, showParticles: false });
            }
            break;

          case "wild":
            if (full) {
              player.addEffect("haste", 40, { amplifier: 1, showParticles: false });
            } else {
              player.addEffect("speed", 40, { amplifier: 0, showParticles: false });
            }
            break;

          case "tide":
            if (!full) {
              player.addEffect("water_breathing", 40, { amplifier: 0, showParticles: false });
            }
            break;

          case "rib":
            if (!full) {
              // Single: Wither aura to nearby hostiles
              const hostiles = player.dimension.getEntities({
                location: player.location, maxDistance: 3, families: ["monster"]
              });
              for (const h of hostiles) {
                try { h.addEffect("wither", 30, { amplifier: 0, showParticles: true }); } catch {}
              }
            }
            break;

          case "flow":
            if (!full) {
              // Single: Fall damage reduction via slow falling at low Y velocity
              player.addEffect("slow_falling", 10, { amplifier: 0, showParticles: false });
            }
            break;
        }
      } catch {}
    }
  }

  /**
   * On-attack triggers for combat trim abilities.
   */
  onAttack(player, target) {
    const state = this.playerTrimState.get(player.id);
    if (!state || !state.pattern || !target) return;

    const pattern = state.pattern;
    const full = state.fullSet;
    const dim = player.dimension;

    try {
      switch (pattern) {
        case "bolt":
          if (full && Math.random() < 0.10) {
            // 10% lightning strike
            dim.runCommandAsync(`summon lightning_bolt ${target.location.x} ${target.location.y} ${target.location.z}`);
            player.sendMessage("§b§l⚡ Bolt Strike!");
          }
          break;

        case "rib":
          if (full) {
            // Fire aspect on melee
            try { target.setOnFire(60, true); } catch {}
          }
          break;

        case "vex":
          if (full) {
            // Spawn vex ally (max 1, cooldown)
            const cd = state.cooldowns.vex || 0;
            if (cd <= 0) {
              try {
                const vex = dim.spawnEntity("minecraft:vex", player.location);
                vex.addTag("ec.trim_vex_ally");
                vex.nameTag = "§d§lVex Ally";
                system.runTimeout(() => { try { vex.kill(); } catch {} }, 200);
              } catch {}
              state.cooldowns.vex = 200; // 10s
            }
          } else {
            // Single: Evoker fangs
            try { dim.runCommandAsync(`execute at @s run summon evocation_fang ~ ~ ~2`); } catch {}
          }
          break;

        case "spire":
          if (full) {
            // Reflect: apply weakness to attacker
            try { target.addEffect("weakness", 40, { amplifier: 0, showParticles: true }); } catch {}
          }
          break;

        case "silence":
          if (!full) {
            try { target.addEffect("slowness", 30, { amplifier: 1, showParticles: true }); } catch {}
          }
          break;
      }
    } catch {}
  }

  /**
   * Tick cooldowns (called every 20 ticks).
   */
  tick(players) {
    this.tickPassives(players);

    // Decrement cooldowns
    for (const [, state] of this.playerTrimState) {
      for (const key of Object.keys(state.cooldowns)) {
        if (state.cooldowns[key] > 0) state.cooldowns[key] -= 20;
      }
    }

    // Detect trims every 5 calls (~100 ticks)
    for (const player of players) {
      this.detectTrims(player);
    }
  }
}
