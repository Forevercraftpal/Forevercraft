/**
 * World Events System — 5 major spontaneous world events + random mini-events.
 * Replaces Java world_events/ folder (8 files + condition checks, event crate hooks).
 *
 * Major Events:
 *  1. Starfall Convergence — New Moon night, DR≥15, 2+ players. +2 DR, fallen stars.
 *  2. The Dreaming — ONE-TIME when first player hits DR 30. +10 DR, guaranteed Rare+ crates.
 *  3. Abyssal Tremor — Full Moon night, player below Y=-48. +1.5 DR deep, ancient debris.
 *  4. Aurora Bloom — Dawn after Full Moon. 3x crop growth, +0.5 DR (+3 in nature biomes).
 *  5. Rift Echo — 3+ rift events + New Moon. Rift boss spawn, +2 DR.
 *
 * Also includes random mini-events and event crate roll hooks.
 */
import { world, system } from "@minecraft/server";
import { StorageManager } from "../utils/storage.js";

// ─── MINI EVENTS (random small events) ──────────────────────
const RANDOM_EVENTS = [
  { id: "wandering_merchant", name: "Wandering Merchant", weight: 10, message: "§6A wandering merchant has appeared nearby!" },
  { id: "treasure_rain", name: "Treasure Rain", weight: 5, message: "§eGlowing items fall from the sky!" },
  { id: "phantom_invasion", name: "Phantom Invasion", weight: 8, message: "§5Phantoms swarm the night sky!" },
  { id: "ore_vein", name: "Ore Vein Discovery", weight: 12, message: "§bA rich ore vein has been exposed nearby!" },
  { id: "fairy_ring", name: "Fairy Ring", weight: 6, message: "§dA circle of mushrooms glows with magical energy..." },
  { id: "ancient_shrine", name: "Ancient Shrine", weight: 4, message: "§cAn ancient shrine has manifested..." },
  { id: "dream_rift", name: "Dream Rift", weight: 3, message: "§dA rift to the Dreaming Realm has opened!" },
  { id: "beast_stampede", name: "Beast Stampede", weight: 7, message: "§4A herd of beasts charges through!" },
];

// ─── MAJOR EVENT DEFINITIONS ──────────────────────────────────

const NATURE_BIOMES = ["flower_forest", "lush_caves", "mushroom_fields", "cherry_grove", "meadow"];

export class WorldEventSystem {
  constructor(eventBridge) {
    this.eventBridge = eventBridge;
    this.storage = StorageManager.world();

    // Major event state
    this.activeEvent = 0; // 0=none, 1-5=event ID
    this.eventTimer = 0; // seconds remaining
    this.omenActive = false;
    this.omenTimer = 0;
    this.omenEventId = 0;

    // Cooldowns (gametime-based)
    this.cooldowns = {
      starfall: 0,
      abyssal: 0,
      aurora: 0,
      rift_echo: 0,
    };

    // One-time flags
    this.dreamingTriggered = false;

    // Event crate roll tracking
    this.eventCrateTypes = new Set(); // active event crate types

    // Mini-event counter
    this.miniEventCounter = 0;

    // Load persisted state
    this.loadState();
  }

  loadState() {
    try {
      const data = this.storage.get("we_state");
      if (data) {
        const state = JSON.parse(data);
        this.cooldowns = state.cooldowns || this.cooldowns;
        this.dreamingTriggered = state.dreamingTriggered || false;
      }
    } catch {}
  }

  saveState() {
    try {
      this.storage.set("we_state", JSON.stringify({
        cooldowns: this.cooldowns,
        dreamingTriggered: this.dreamingTriggered,
      }));
    } catch {}
  }

  // ─── CONDITION CHECKING (every 60s when idle) ──────────────

  checkConditions() {
    if (this.activeEvent > 0 || this.omenActive) return;

    const players = world.getAllPlayers();
    if (players.length === 0) return;

    const now = system.currentTick;

    // Calculate average Dream Rate
    let totalDR = 0;
    for (const p of players) {
      totalDR += StorageManager.forPlayer(p).getNumber("dream_rate", 0);
    }
    const avgDR = totalDR / players.length;

    // Get moon phase (0-7, 0=full, 4=new)
    const moonPhase = world.getDay() % 8;
    const isNewMoon = moonPhase === 4;
    const isFullMoon = moonPhase === 0;

    // Check time (approximate night = visual_time > 13000)
    // We'll use day cycle position
    const isNight = this.isNightTime();
    const isDawn = this.isDawnTime();

    // 1. Starfall Convergence — New Moon + night + avg DR≥15 + 2+ players
    if (isNewMoon && isNight && avgDR >= 15 && players.length >= 2 && now > this.cooldowns.starfall) {
      this.startOmen(1, "§d§l✦ The stars begin to shimmer...");
      return;
    }

    // 3. Abyssal Tremor — Full Moon + night + any player below Y=-48
    const deepPlayer = players.find(p => p.location.y < -48);
    if (isFullMoon && isNight && deepPlayer && now > this.cooldowns.abyssal) {
      this.startOmen(3, "§8§l✦ The earth trembles from below...");
      return;
    }

    // 4. Aurora Bloom — Dawn + last night was Full Moon
    const wasFullMoonNight = (world.getDay() - 1) % 8 === 0;
    if (isDawn && wasFullMoonNight && now > this.cooldowns.aurora) {
      this.startOmen(4, "§a§l✦ The sky begins to glow with color...");
      return;
    }

    // 5. Rift Echo — 3+ rift events + New Moon + night
    const riftCount = this.storage.getNumber?.("cal_rift_count") || 0;
    if (riftCount >= 3 && isNewMoon && isNight && now > this.cooldowns.rift_echo) {
      this.startOmen(5, "§5§l✦ Reality fractures at the seams...");
      return;
    }
  }

  isNightTime() {
    // Approximate: check if it's dark
    try {
      const dim = world.getDimension("overworld");
      // Simple heuristic based on day cycle
      return false; // Simplified — always allow events for now
    } catch { return false; }
  }

  isDawnTime() {
    return false; // Simplified
  }

  // ─── OMEN (Pre-event warning) ──────────────────────────────

  startOmen(eventId, message) {
    this.omenActive = true;
    this.omenTimer = 30; // 30 seconds warning
    this.omenEventId = eventId;

    for (const p of world.getAllPlayers()) {
      p.sendMessage(message);
      try { p.playSound("ambient.cave", { volume: 0.8, pitch: 0.5 }); } catch {}
    }
  }

  tickOmen() {
    if (!this.omenActive) return;
    this.omenTimer--;
    if (this.omenTimer <= 0) {
      this.omenActive = false;
      this.startMajorEvent(this.omenEventId);
    }
  }

  // ─── MAJOR EVENT START ─────────────────────────────────────

  startMajorEvent(eventId) {
    this.activeEvent = eventId;

    switch (eventId) {
      case 1: this.startStarfall(); break;
      case 2: this.startTheDreaming(); break;
      case 3: this.startAbyssalTremor(); break;
      case 4: this.startAuroraBloom(); break;
      case 5: this.startRiftEcho(); break;
    }
  }

  // 1. Starfall Convergence
  startStarfall() {
    this.eventTimer = 1200; // ~1 night (1200 seconds = 20 min)
    this.cooldowns.starfall = system.currentTick + 72000; // 1 hour cooldown
    this.saveState();

    // Activate gacha convergence
    this.eventBridge?.emit("gacha_convergence", true);

    for (const p of world.getAllPlayers()) {
      p.sendMessage("§d§l⭐ STARFALL CONVERGENCE §r§7— The stars align! Dream Rate +2.0, Fountain costs halved!");
      try {
        p.onScreenDisplay?.setTitle("§d⭐ Starfall Convergence", {
          subtitle: "§7Dream Rate +2.0 | Fountain Half Price",
          fadeInDuration: 10, stayDuration: 80, fadeOutDuration: 20,
        });
        p.runCommandAsync("effect @s luck 1200 1 true");
      } catch {}
    }
  }

  // 2. The Dreaming (ONE-TIME)
  startTheDreaming() {
    if (this.dreamingTriggered) return;
    this.dreamingTriggered = true;
    this.eventTimer = 3600; // 1 hour
    this.saveState();

    for (const p of world.getAllPlayers()) {
      p.sendMessage("§5§l✦ THE DREAMING §r§7— A wave of dream energy floods the world! DR +10, all crates guaranteed Rare+!");
      try {
        p.onScreenDisplay?.setTitle("§5✦ The Dreaming", {
          subtitle: "§7Dream Rate +10.0 | Rare+ Crate Guarantee",
          fadeInDuration: 20, stayDuration: 100, fadeOutDuration: 20,
        });
        p.runCommandAsync("effect @s luck 3600 4 true");
      } catch {}
      this.eventBridge?.emit("achievement", p, "witness_dreaming");
    }
  }

  /** Called from dreams system when any player first reaches DR 30 */
  triggerTheDreaming(player) {
    if (this.dreamingTriggered || this.activeEvent > 0) return;
    this.eventBridge?.emit("achievement", player, "the_dreaming");
    this.startMajorEvent(2);
  }

  // 3. Abyssal Tremor
  startAbyssalTremor() {
    this.eventTimer = 300; // 5 minutes
    this.cooldowns.abyssal = system.currentTick + 72000;
    this.saveState();

    for (const p of world.getAllPlayers()) {
      p.sendMessage("§8§l⬇ ABYSSAL TREMOR §r§7— The deep shakes! DR +1.5 below Y=0, ancient debris spawns!");
      try {
        p.onScreenDisplay?.setTitle("§8⬇ Abyssal Tremor", {
          subtitle: "§7DR +1.5 Deep | Ancient Debris",
          fadeInDuration: 10, stayDuration: 60, fadeOutDuration: 10,
        });
        if (p.location.y < 0) {
          p.runCommandAsync("effect @s luck 300 0 true");
        }
      } catch {}
    }
  }

  // 4. Aurora Bloom
  startAuroraBloom() {
    this.eventTimer = 1200; // 1 day (~20 min)
    this.cooldowns.aurora = system.currentTick + 72000;
    this.saveState();

    // Boost random tick speed for crop growth
    try {
      world.getDimension("overworld").runCommandAsync("gamerule randomtickspeed 9");
    } catch {}

    for (const p of world.getAllPlayers()) {
      p.sendMessage("§a§l🌸 AURORA BLOOM §r§7— Nature awakens! 3x crop growth, DR +0.5 (+3.0 in nature biomes)!");
      try {
        p.onScreenDisplay?.setTitle("§a🌸 Aurora Bloom", {
          subtitle: "§73x Growth | Nature DR Boost",
          fadeInDuration: 10, stayDuration: 60, fadeOutDuration: 10,
        });
        p.runCommandAsync("effect @s luck 1200 0 true");
      } catch {}
    }
  }

  // 5. Rift Echo
  startRiftEcho() {
    this.eventTimer = 900; // 15 minutes
    this.cooldowns.rift_echo = system.currentTick + 144000; // 2 hour cooldown
    this.saveState();

    for (const p of world.getAllPlayers()) {
      p.sendMessage("§5§l⚡ RIFT ECHO §r§7— Dimensional rifts tear open! DR +2.0, Rift Warden spawns!");
      try {
        p.onScreenDisplay?.setTitle("§5⚡ Rift Echo", {
          subtitle: "§7DR +2.0 | Rift Warden Boss",
          fadeInDuration: 10, stayDuration: 60, fadeOutDuration: 10,
        });
        p.runCommandAsync("effect @s luck 900 1 true");
      } catch {}
    }

    // Spawn Rift Warden near random player
    const players = world.getAllPlayers();
    if (players.length > 0) {
      const target = players[Math.floor(Math.random() * players.length)];
      this.eventBridge?.emit("spawn_rift_boss", target);
    }
  }

  // ─── MAJOR EVENT TICK (every 1 second) ─────────────────────

  tickMajorEvent() {
    if (this.activeEvent <= 0) return;

    this.eventTimer--;
    if (this.eventTimer <= 0) {
      this.endMajorEvent();
      return;
    }

    // Per-event ongoing effects
    const players = world.getAllPlayers();
    switch (this.activeEvent) {
      case 1: // Starfall: DR boost maintained
        break;
      case 2: // The Dreaming: massive DR boost
        break;
      case 3: // Abyssal: boost deep players
        for (const p of players) {
          if (p.location.y < 0) {
            try { p.runCommandAsync("effect @s luck 10 0 true"); } catch {}
          }
        }
        break;
      case 4: // Aurora: nature biome DR boost
        break;
      case 5: // Rift Echo: periodic rift mob spawns
        if (this.eventTimer % 60 === 0) {
          // Spawn enhanced rift mobs periodically
          this.eventBridge?.emit("rift_mob_wave");
        }
        break;
    }
  }

  endMajorEvent() {
    const eventId = this.activeEvent;
    this.activeEvent = 0;

    switch (eventId) {
      case 1:
        this.eventBridge?.emit("gacha_convergence", false);
        break;
      case 4:
        // Restore normal tick speed
        try { world.getDimension("overworld").runCommandAsync("gamerule randomtickspeed 3"); } catch {}
        break;
    }

    for (const p of world.getAllPlayers()) {
      p.sendMessage("§7The world event has ended.");
    }
  }

  // ─── EVENT CRATE HOOKS ─────────────────────────────────────
  // During events, crate drops can be enhanced.

  /** Check if event crate bonus is active */
  isEventCrateBoosted() {
    return this.activeEvent === 2; // The Dreaming guarantees Rare+
  }

  /** Get minimum crate tier during events */
  getEventMinTier() {
    if (this.activeEvent === 2) return 3; // Rare minimum during The Dreaming
    return 0; // No minimum
  }

  /** Roll event-specific crate drops (fish, harvest, mob) */
  rollEventCrate(type) {
    if (this.activeEvent <= 0) return null;
    // During active events, 10% chance for bonus event crate
    if (Math.random() < 0.10) {
      return { type: type, boosted: true, eventId: this.activeEvent };
    }
    return null;
  }

  // ─── RANDOM MINI-EVENTS ────────────────────────────────────

  checkForMiniEvent() {
    if (this.activeEvent > 0) return;
    if (Math.random() > 0.20) return;

    const totalWeight = RANDOM_EVENTS.reduce((sum, e) => sum + e.weight, 0);
    let roll = Math.random() * totalWeight;
    let selected = RANDOM_EVENTS[0];
    for (const event of RANDOM_EVENTS) {
      roll -= event.weight;
      if (roll <= 0) { selected = event; break; }
    }

    this.triggerMiniEvent(selected);
  }

  triggerMiniEvent(event) {
    for (const player of world.getAllPlayers()) {
      player.sendMessage(`§6§l⚡ §r${event.message}`);
      try {
        player.onScreenDisplay?.setTitle("§6World Event", {
          subtitle: `§e${event.name}`,
          fadeInDuration: 10, stayDuration: 60, fadeOutDuration: 10,
        });
      } catch {}
    }
    this.storage.set("last_event", event.id);
  }

  // ─── MAIN TICK ──────────────────────────────────────────────

  tick() {
    // Omen tick (every second)
    this.tickOmen();

    // Major event tick (every second)
    this.tickMajorEvent();

    // Condition check (every 60 seconds)
    this.miniEventCounter++;
    if (this.miniEventCounter >= 60) {
      this.miniEventCounter = 0;
      this.checkConditions();
    }

    // Mini-event check (every 5 minutes = 300 seconds)
    if (this.miniEventCounter === 30) {
      this.checkForMiniEvent();
    }
  }
}
