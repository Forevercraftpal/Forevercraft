/**
 * Healer Artifact System — 12 healing artifacts with cooldowns, master lockout.
 * Replaces Java artifacts/healer/ folder (load, tick, lockout_tick, use/*).
 *
 * Core mechanics:
 * - 12 healer artifacts with individual cooldowns
 * - Master lockout: Weakness V blocks melee, arrows dealt zero during any CD
 * - AoE healing to nearby players + tamed companions
 * - Tier progression: Common → Mythical with scaling radius/power
 * - Triage healing on Tome/Tears (prioritize low-HP targets)
 */
import { world, system } from "@minecraft/server";
import { StorageManager } from "../utils/storage.js";

const HEALERS = [
  {
    id: "bandages", name: "Medicinal Bandages", tier: "common",
    heal: 2, radius: 8, cooldown: 15, selfOnly: false,
    effects: [],
    cleanse: false,
  },
  {
    id: "poultice", name: "Herbal Poultice", tier: "common",
    heal: 4, radius: 0, cooldown: 12, selfOnly: true,
    effects: [],
    cleanse: false,
  },
  {
    id: "salts", name: "Smelling Salts", tier: "uncommon",
    heal: 2, radius: 12, cooldown: 18, selfOnly: false,
    effects: [],
    cleanse: true,
    cleanseEffects: ["poison", "wither", "slowness", "mining_fatigue", "blindness", "hunger", "nausea", "darkness"],
  },
  {
    id: "balm", name: "Soothing Balm", tier: "uncommon",
    heal: 4, radius: 12, cooldown: 16, selfOnly: false,
    effects: [{ effect: "speed", duration: 5, amplifier: 0 }],
    cleanse: false,
  },
  {
    id: "chalice", name: "Mending Chalice", tier: "rare",
    heal: 4, radius: 16, cooldown: 20, selfOnly: false,
    effects: [{ effect: "regeneration", duration: 5, amplifier: 0 }],
    cleanse: false,
  },
  {
    id: "incense", name: "Warding Incense", tier: "rare",
    heal: 4, radius: 14, cooldown: 22, selfOnly: false,
    effects: [{ effect: "fire_resistance", duration: 10, amplifier: 0 }],
    cleanse: false,
  },
  {
    id: "plume", name: "Phoenix Plume", tier: "ornate",
    heal: 8, radius: 20, cooldown: 25, selfOnly: false,
    effects: [],
    cleanse: true,
    cleanseEffects: ["poison", "wither", "slowness", "mining_fatigue", "blindness", "hunger", "nausea", "darkness", "bad_omen"],
  },
  {
    id: "censer", name: "Radiant Censer", tier: "ornate",
    heal: 4, radius: 18, cooldown: 24, selfOnly: false,
    effects: [{ effect: "regeneration", duration: 8, amplifier: 1 }],
    cleanse: false,
  },
  {
    id: "lotus", name: "Celestial Lotus", tier: "exquisite",
    heal: 8, radius: 24, cooldown: 28, selfOnly: false,
    effects: [{ effect: "absorption", duration: 12, amplifier: 1 }],
    cleanse: false,
  },
  {
    id: "tome", name: "Lifewarden's Tome", tier: "exquisite",
    heal: 4, radius: 24, cooldown: 26, selfOnly: false,
    effects: [],
    cleanse: false,
    triage: true, triageThreshold: 10, triageHeal: 16, // +8 hearts to <50% HP
  },
  {
    id: "ambrosia", name: "Endless Ambrosia", tier: "mythical",
    heal: 20, radius: 32, cooldown: 30, selfOnly: false,
    effects: [{ effect: "resistance", duration: 10, amplifier: 1 }],
    cleanse: false,
    broadcast: true,
  },
  {
    id: "tears", name: "Tears of the World Tree", tier: "mythical",
    heal: 16, radius: 32, cooldown: 30, selfOnly: false,
    effects: [
      { effect: "regeneration", duration: 10, amplifier: 2 },
      { effect: "absorption", duration: 15, amplifier: 2 },
    ],
    cleanse: false,
    emergency: true, emergencyThreshold: 4, emergencyHeal: 8, // +4 hearts to <20% HP
  },
];

// Tier colors for messages
const TIER_COLORS = {
  common: "§f", uncommon: "§e", rare: "§b",
  ornate: "§d", exquisite: "§6", mythical: "§c",
};

export class HealerSystem {
  constructor(eventBridge) {
    // Item consumed → check if healer artifact
    eventBridge.on("item_consumed", (player, item) => {
      this.onItemConsumed(player, item);
    });

    // Item use → check for Tome (book, not consumed)
    eventBridge.on("item_use", (player, item) => {
      this.onItemUse(player, item);
    });

    // Track projectile hits for arrow damage blocking during lockout
    eventBridge.on("player_dealt_damage", (player, target, damage, source) => {
      this.onPlayerDealDamage(player, target, damage, source);
    });
  }

  /** Find healer data by item tags */
  findHealer(item) {
    if (!item) return null;
    const tags = item.getTags?.() || [];
    for (const healer of HEALERS) {
      if (tags.some(t => t.includes(`healer_${healer.id}`))) return healer;
    }
    // Also check typeId for custom items
    const typeId = item.typeId || "";
    for (const healer of HEALERS) {
      if (typeId === `forevercraft:healer_${healer.id}`) return healer;
    }
    return null;
  }

  /** Consumable healer used (all except Tome) */
  onItemConsumed(player, item) {
    const healer = this.findHealer(item);
    if (!healer || healer.id === "tome") return;
    this.useHealer(player, healer);
  }

  /** Book-type healer used (Tome only — uses using_item, not consume) */
  onItemUse(player, item) {
    const healer = this.findHealer(item);
    if (!healer || healer.id !== "tome") return;
    this.useHealer(player, healer);
  }

  /** Core healer use logic */
  useHealer(player, healer) {
    const s = StorageManager.forPlayer(player);
    const cdKey = `hl_cd_${healer.id}`;
    const currentCd = s.getNumber(cdKey);

    // Check cooldown
    if (currentCd > 0) {
      player.sendMessage(`§c${healer.name} §7Recharging... §f${currentCd}s`);
      return;
    }

    // Set cooldown + lockout
    s.set(cdKey, healer.cooldown);
    s.set("hl_locked", 1);

    const color = TIER_COLORS[healer.tier] || "§f";

    // Self healing
    this.healEntity(player, healer.heal);
    this.applyEffects(player, healer);
    if (healer.cleanse) this.cleanseEntity(player, healer.cleanseEffects);

    // AoE healing to nearby players
    if (!healer.selfOnly && healer.radius > 0) {
      try {
        const nearbyPlayers = player.dimension.getEntities({
          type: "minecraft:player",
          location: player.location,
          maxDistance: healer.radius,
          excludeNames: [player.name],
        });
        for (const target of nearbyPlayers) {
          let healAmount = healer.heal;

          // Triage: extra healing to low-HP targets
          if (healer.triage) {
            const health = target.getComponent("minecraft:health");
            if (health && health.currentValue <= healer.triageThreshold) {
              healAmount = healer.triageHeal;
            }
          }

          // Emergency: extra healing to critical targets
          if (healer.emergency) {
            const health = target.getComponent("minecraft:health");
            if (health && health.currentValue <= healer.emergencyThreshold) {
              healAmount += healer.emergencyHeal;
            }
          }

          this.healEntity(target, healAmount);
          this.applyEffects(target, healer);
          if (healer.cleanse) this.cleanseEntity(target, healer.cleanseEffects);
        }
      } catch {}

      // Also heal tamed companions nearby
      try {
        const companions = player.dimension.getEntities({
          location: player.location,
          maxDistance: healer.radius,
          families: ["pet"],
        });
        for (const pet of companions) {
          this.healEntity(pet, healer.heal);
        }
      } catch {}
    }

    // Chat message
    if (healer.selfOnly) {
      player.sendMessage(`${color}§l✦ ${healer.name} §r§7— Healed §c${healer.heal / 2}♥`);
    } else {
      player.sendMessage(`${color}§l✦ ${healer.name} §r§7— Healed nearby allies §c${healer.heal / 2}♥ §7(${healer.radius}b range)`);
    }

    // Broadcast for mythical-tier
    if (healer.broadcast) {
      for (const p of world.getAllPlayers()) {
        if (p.name !== player.name) {
          p.sendMessage(`§6[${healer.name}] §f${player.name} §eunleashed the ${healer.name}!`);
        }
      }
    }

    player.playSound("random.orb");

    // Achievement tracking
    s.increment("ach_heals_used");
  }

  /** Heal an entity by HP amount */
  healEntity(entity, amount) {
    try {
      const health = entity.getComponent("minecraft:health");
      if (health) {
        const newHP = Math.min(health.currentValue + amount, health.effectiveMax);
        health.setCurrentValue(newHP);
      }
    } catch {}
  }

  /** Apply bonus effects from healer */
  applyEffects(entity, healer) {
    for (const eff of healer.effects) {
      try {
        entity.runCommandAsync(`effect @s ${eff.effect} ${eff.duration} ${eff.amplifier} true`);
      } catch {}
    }
  }

  /** Cleanse negative effects */
  cleanseEntity(entity, effectIds) {
    for (const effectId of effectIds) {
      try {
        entity.runCommandAsync(`effect @s ${effectId} 0`);
      } catch {}
    }
  }

  /** Block melee damage during lockout */
  onPlayerDealDamage(player, target, damage, source) {
    const s = StorageManager.forPlayer(player);
    if (s.getNumber("hl_locked") > 0) {
      // During lockout, apply Weakness V to prevent melee damage
      // (Applied in tick, but reinforce here for responsiveness)
    }
  }

  /**
   * Per-second tick: decrement cooldowns, manage lockout state.
   * Called from main tick loop every 20 ticks (1 second).
   */
  tick(players) {
    for (const player of players) {
      const s = StorageManager.forPlayer(player);
      const wasLocked = s.getNumber("hl_locked") > 0;
      let anyActive = false;

      // Decrement all cooldowns
      for (const healer of HEALERS) {
        const cdKey = `hl_cd_${healer.id}`;
        const cd = s.getNumber(cdKey);
        if (cd > 0) {
          s.set(cdKey, cd - 1);
          if (cd - 1 > 0) anyActive = true;
        }
      }

      // Update lockout state
      if (anyActive) {
        s.set("hl_locked", 1);
        // Apply Weakness V to block melee damage
        try {
          player.runCommandAsync("effect @s weakness 3 4 true");
        } catch {}
        // Actionbar warning
        player.onScreenDisplay.setActionBar("§c§lHealer's Oath §r§7— Cannot use weapons");
      } else if (wasLocked) {
        s.set("hl_locked", 0);
        // Remove weakness
        try {
          player.runCommandAsync("effect @s weakness 0");
        } catch {}
        player.sendMessage("§a§lHealer's Oath §r§7has lifted — weapons ready");
      }
    }
  }

  /**
   * Healer Revive — Healers can revive dead players by right-clicking tombs.
   * Called when a healer artifact holder interacts with a tomb marker.
   * Healer gets Slowness + Blindness for 7s, 15s healing lockout.
   */
  attemptTombRevive(player, tomb) {
    const s = StorageManager.forPlayer(player);

    // Check if player has any healer artifact equipped
    const equip = player.getComponent("minecraft:equippable");
    const mainhand = equip?.getEquipment("Mainhand");
    const healer = this.findHealer(mainhand);
    if (!healer) {
      player.sendMessage("§7You need a healer artifact to revive someone.");
      return false;
    }

    // Check revive cooldown
    if (s.getNumber("hl_revive_cd", 0) > 0) {
      player.sendMessage("§cRevive still on cooldown.");
      return false;
    }

    // Get tomb owner name
    const tombStorage = StorageManager.forEntity(tomb);
    const ownerName = tombStorage.get("owner");
    if (!ownerName) return false;

    // Apply healer debuffs
    try {
      player.addEffect("slowness", 140, { amplifier: 2, showParticles: true });  // 7s
      player.addEffect("blindness", 140, { amplifier: 0, showParticles: true }); // 7s
    } catch {}

    // 15s healing lockout
    s.set("hl_revive_cd", 300); // 15 seconds in ticks

    // Visual effects
    try {
      const pos = tomb.location;
      player.dimension.runCommandAsync(
        `particle minecraft:totem_particle ${pos.x} ${pos.y + 1} ${pos.z}`
      );
      player.playSound("random.totem", { volume: 0.7, pitch: 0.8 });
    } catch {}

    player.sendMessage(`§a§lReviving §r§f${ownerName}§a§l... §r§7You feel the strain.`);

    // Notify the dead player if online
    const allPlayers = world.getAllPlayers();
    const target = allPlayers.find(p => p.name === ownerName);
    if (target) {
      target.sendMessage(`§a${player.name} §7is reviving you at your tomb!`);
    }

    // Remove the tomb (items recovered)
    try { tomb.kill(); } catch {}

    return true;
  }
}
