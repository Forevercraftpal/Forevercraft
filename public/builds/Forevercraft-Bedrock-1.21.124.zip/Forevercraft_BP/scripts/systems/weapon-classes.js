/**
 * Weapon Class System — 9 weapon classes with unique combat mechanics.
 * Replaces Java artifacts/knight/, artifacts/rogue/, artifacts/berserker/,
 * artifacts/dancer/, artifacts/archer/, artifacts/hunter/, artifacts/javelin/,
 * artifacts/striker/, artifacts/beastlord/ folders.
 *
 * Each class has: detection, activation, per-tick logic, abilities, deactivation.
 */
import { world, system, EffectTypes } from "@minecraft/server";
import { StorageManager } from "../utils/storage.js";

// OPT: Pre-cached effect types for hot paths (avoid string lookup in tick)
const _FX = {};
for (const n of ["strength","regeneration","haste","speed","resistance","invisibility",
  "slowness","weakness","wither","levitation","glowing","mining_fatigue"]) {
  _FX[n] = EffectTypes.get(n);
}
/** Apply effect via native API — faster than runCommandAsync in tick loops */
function wfx(entity, effect, dur, amp) {
  try { entity.addEffect(_FX[effect] || EffectTypes.get(effect), dur * 20, { amplifier: amp, showParticles: false }); } catch {}
}

// ─── KNIGHT ───────────────────────────────────────────────
class KnightClass {
  /** Fencer Stance: +2 damage, +1 reach when no shield in offhand */
  activate(player) {
    player.addTag("ec.kt_active");
    this.checkFencer(player);
    player.sendMessage("§e§l⚔ Knight §r§7class activated");
  }

  deactivate(player) {
    player.removeTag("ec.kt_active");
    player.removeTag("ec.kt_fencer");
    player.runCommandAsync("effect @s clear");
  }

  checkFencer(player) {
    const equip = player.getComponent("minecraft:equippable");
    if (!equip) return;
    const offhand = equip.getEquipment("Offhand");
    const hasShield = offhand?.typeId === "minecraft:shield";

    if (!hasShield && !player.hasTag("ec.kt_fencer")) {
      player.addTag("ec.kt_fencer");
      wfx(player, "strength", 99999, 0); // OPT: native API
      player.sendMessage("§e§lFencer Stance §r§7— No shield: +2 damage, +1 reach");
    } else if (hasShield && player.hasTag("ec.kt_fencer")) {
      player.removeTag("ec.kt_fencer");
      try { player.removeEffect(_FX.strength); } catch {} // OPT: native API
    }
  }

  tick(player) {
    if (!player.hasTag("ec.kt_active")) return;
    this.checkFencer(player);
  }
}

// ─── ROGUE ────────────────────────────────────────────────
class RogueClass {
  /** Auto-swing dagger combo with tier-scaled intervals */
  static TIER_DATA = [
    { interval: 15, damage: 3 },  // T1
    { interval: 12, damage: 4 },  // T2
    { interval: 9, damage: 5 },   // T3
    { interval: 7, damage: 6 },   // T4
    { interval: 5, damage: 7 },   // T5
    { interval: 4, damage: 8 },   // T6
  ];

  /** Named dagger abilities triggered on each swing */
  static DAGGER_ABILITIES = {
    1: { name: "Heartstealer", type: "crit", chance: 25, bonusDmg: 4 },
    2: { name: "Hidden Blade", type: "lifesteal", heal: 1 },
    3: { name: "Dragon's Edge", type: "debuff", effect: "weakness", dur: 3, amp: 0 },
    4: { name: "Nameless Blade", type: "invis", chance: 20, dur: 1 },
    5: { name: "Void-Touched Blade", type: "levitate", chance: 15, dur: 1 },
    6: { name: "The Beginning and The End", type: "duality" },
  };

  activate(player, tier, weaponId) {
    player.addTag("ec.rg_active");
    const s = StorageManager.forPlayer(player);
    s.set("rg_tier", tier);
    s.set("rg_weapon_id", weaponId || 0);
    s.set("rg_swing", RogueClass.TIER_DATA[tier - 1]?.interval || 15);
    s.set("rg_dual", 0);
    s.set("rg_duality_fire", 1); // For "The Beginning and The End" alternation
    this.checkDual(player, s);
    const ab = RogueClass.DAGGER_ABILITIES[weaponId];
    player.sendMessage(`§c§l🗡 Rogue §r§7class activated${ab ? ` — ${ab.name}` : ""}`);
  }

  deactivate(player) {
    player.removeTag("ec.rg_active");
    player.removeTag("ec.rg_dual");
  }

  checkDual(player, s) {
    const equip = player.getComponent("minecraft:equippable");
    if (!equip) return;
    const offhand = equip.getEquipment("Offhand");
    const hasDagger = offhand?.getTags?.()?.some(t => t.includes("rogue")) || false;
    s.set("rg_dual", hasDagger ? 1 : 0);
  }

  tick(player) {
    if (!player.hasTag("ec.rg_active")) return;
    const s = StorageManager.forPlayer(player);
    let swing = s.getNumber("rg_swing") - 1;

    if (swing <= 0) {
      this.doSwing(player, s);
      const tier = s.getNumber("rg_tier") || 1;
      const data = RogueClass.TIER_DATA[tier - 1] || RogueClass.TIER_DATA[0];
      let interval = data.interval;
      if (s.getNumber("rg_dual") === 1) {
        interval = Math.max(1, Math.floor(interval * 0.7));
      }
      swing = interval;
    }
    s.set("rg_swing", swing);
  }

  doSwing(player, s) {
    const tier = s.getNumber("rg_tier") || 1;
    const data = RogueClass.TIER_DATA[tier - 1] || RogueClass.TIER_DATA[0];
    const weaponId = s.getNumber("rg_weapon_id");
    const ability = RogueClass.DAGGER_ABILITIES[weaponId];

    try {
      const nearby = player.dimension.getEntities({
        location: player.location,
        maxDistance: 2.5,
        excludeTypes: ["minecraft:player"],
        excludeFamilies: ["inanimate"],
      });
      let hits = 0;
      for (const entity of nearby) {
        if (hits >= 2) break;
        try {
          entity.applyDamage(data.damage, { cause: "entityAttack", damagingEntity: player });
          // Apply named weapon ability on hit
          if (ability) this.applyDaggerAbility(player, entity, ability, s);
          hits++;
        } catch {}
      }
      if (hits > 0) {
        player.playSound("entity.player.attack.sweep");
      }
    } catch {}
  }

  applyDaggerAbility(player, target, ab, s) {
    const roll = Math.floor(Math.random() * 100) + 1;
    try {
      switch (ab.type) {
        case "crit": // Heartstealer: 25% chance +4 damage
          if (roll <= ab.chance) {
            target.applyDamage(ab.bonusDmg, { cause: "entityAttack", damagingEntity: player });
            player.onScreenDisplay.setActionBar("§c§lPrecision Strike!");
          }
          break;
        case "lifesteal": { // Hidden Blade: heal 1 HP per swing
          const hp = player.getComponent("minecraft:health");
          if (hp) hp.setCurrentValue(Math.min(hp.currentValue + ab.heal, hp.effectiveMax));
          break;
        }
        case "debuff": // Dragon's Edge: Weakness I on target
          target.runCommandAsync(`effect @s ${ab.effect} ${ab.dur} ${ab.amp} true`);
          break;
        case "invis": // Nameless Blade: 20% invisibility
          if (roll <= ab.chance) {
            player.runCommandAsync(`effect @s invisibility ${ab.dur} 0 true`);
            player.onScreenDisplay.setActionBar("§7§lShadow Strike!");
          }
          break;
        case "levitate": // Void-Touched: 15% levitate target
          if (roll <= ab.chance) {
            target.runCommandAsync(`effect @s levitation ${ab.dur} 0 true`);
            player.onScreenDisplay.setActionBar("§5§lVoid Strike!");
          }
          break;
        case "duality": { // The Beginning and The End: alternating fire/frost
          const isFire = s.getNumber("rg_duality_fire");
          if (isFire) {
            target.setOnFire(3, true);
            player.onScreenDisplay.setActionBar("§6§lFire Strike!");
          } else {
            target.runCommandAsync("effect @s slowness 3 1 true");
            player.onScreenDisplay.setActionBar("§b§lFrost Strike!");
          }
          s.set("rg_duality_fire", isFire ? 0 : 1);
          break;
        }
      }
    } catch {}
  }
}

// ─── BERSERKER ────────────────────────────────────────────
class BerserkerClass {
  /** Dual axe class: rage mode, stat penalties, auto-swing during rage */
  static TIER_DATA = [
    { interval: 24, damage: 5 },
    { interval: 20, damage: 6 },
    { interval: 16, damage: 7 },
    { interval: 14, damage: 8 },
    { interval: 12, damage: 9 },
    { interval: 10, damage: 10 },
  ];

  activate(player, tier) {
    player.addTag("ec.bk_active");
    const s = StorageManager.forPlayer(player);
    s.set("bk_tier", tier);
    s.set("bk_rage", 0);
    s.set("bk_cd", 0);
    s.set("bk_swing", 0);
    // Stat penalties: -7 armor (via weakness effect proxy)
    player.sendMessage("§4§l⚔ Berserker §r§7class activated — §cReduced armor, increased speed");
  }

  deactivate(player) {
    player.removeTag("ec.bk_active");
    player.removeTag("ec.bk_raging");
    try { player.removeEffect(_FX.strength); } catch {} // OPT: native API
    try { player.removeEffect(_FX.regeneration); } catch {}
  }

  activateRage(player) {
    const s = StorageManager.forPlayer(player);
    if (s.getNumber("bk_cd") > 0) {
      player.sendMessage("§c§lRage §r§7on cooldown: §f" + s.getNumber("bk_cd") + "s");
      return;
    }
    player.addTag("ec.bk_raging");
    s.set("bk_rage", 200); // 10 seconds
    s.set("bk_cd", 90);    // 90 second cooldown
    wfx(player, "strength", 12, 1); // OPT: native API
    wfx(player, "regeneration", 12, 0);
    player.sendMessage("§4§l⚔ RAGE ACTIVATED! §r§710 seconds of fury");
    player.playSound("entity.ender_dragon.growl");
  }

  tick(player) {
    if (!player.hasTag("ec.bk_active")) return;
    const s = StorageManager.forPlayer(player);

    // Low HP haste — OPT: native API + check-before-apply
    try {
      const health = player.getComponent("minecraft:health");
      if (health && health.currentValue / health.effectiveMax < 0.5) {
        const hasHaste = player.getEffect(_FX.haste);
        if (!hasHaste || hasHaste.duration < 20) wfx(player, "haste", 3, 2);
      }
    } catch {}

    // Rage tick
    let rage = s.getNumber("bk_rage");
    if (rage > 0) {
      rage--;
      s.set("bk_rage", rage);
      // Auto-swing during rage
      let swing = s.getNumber("bk_swing") - 1;
      if (swing <= 0) {
        this.doRageSwing(player, s);
        const tier = s.getNumber("bk_tier") || 1;
        swing = BerserkerClass.TIER_DATA[tier - 1]?.interval || 24;
      }
      s.set("bk_swing", swing);

      if (rage <= 0) {
        player.removeTag("ec.bk_raging");
        player.sendMessage("§4§lRage §r§7has subsided");
      }
    }

    // Cooldown (per second)
    // Only decrement every 20 ticks
  }

  tickSecond(player) {
    if (!player.hasTag("ec.bk_active")) return;
    const s = StorageManager.forPlayer(player);
    let cd = s.getNumber("bk_cd");
    if (cd > 0) {
      cd--;
      s.set("bk_cd", cd);
      if (cd === 0) {
        player.sendMessage("§4§l⚔ Rage §r§7is ready!");
      }
    }
  }

  doRageSwing(player, s) {
    const tier = s.getNumber("bk_tier") || 1;
    const data = BerserkerClass.TIER_DATA[tier - 1] || BerserkerClass.TIER_DATA[0];
    try {
      const nearby = player.dimension.getEntities({
        location: player.location,
        maxDistance: 3,
        excludeTypes: ["minecraft:player"],
        excludeFamilies: ["inanimate"],
      });
      let hits = 0;
      for (const entity of nearby) {
        if (hits >= 3) break;
        try {
          entity.applyDamage(data.damage, { cause: "entityAttack", damagingEntity: player });
          hits++;
        } catch {}
      }
      if (hits > 0) {
        player.playSound("entity.player.attack.crit");
      }
    } catch {}
  }
}

// ─── DANCER ───────────────────────────────────────────────
class DancerClass {
  /** Gauntlet class: evasion, haste, flurry auto-swing */
  static TIER_DATA = [
    { interval: 20, damage: 3 },
    { interval: 16, damage: 4 },
    { interval: 14, damage: 5 },
    { interval: 12, damage: 6 },
    { interval: 10, damage: 7 },
    { interval: 8, damage: 8 },
  ];

  activate(player, tier) {
    player.addTag("ec.dn_active");
    const s = StorageManager.forPlayer(player);
    s.set("dn_tier", tier);
    s.set("dn_flurry", 0);
    s.set("dn_swing", 0);
    s.set("dn_dual", 0);
    this.checkDual(player, s);
    player.sendMessage("§d§l✦ Dancer §r§7class activated — §dEvasion up, armor reduced");
  }

  deactivate(player) {
    player.removeTag("ec.dn_active");
    player.removeTag("ec.dn_dual");
    player.removeTag("ec.dn_flurry");
  }

  checkDual(player, s) {
    const equip = player.getComponent("minecraft:equippable");
    if (!equip) return;
    const offhand = equip.getEquipment("Offhand");
    const hasDancer = offhand?.getTags?.()?.some(t => t.includes("dancer")) || false;
    const prev = s.getNumber("dn_dual");
    s.set("dn_dual", hasDancer ? 1 : 0);
    if (hasDancer && !prev) {
      player.addTag("ec.dn_dual");
      player.runCommandAsync("effect @s haste 999999 1 true");
      player.sendMessage("§d§lDual Gauntlets! §r§7Haste II active");
    } else if (!hasDancer && prev) {
      player.removeTag("ec.dn_dual");
      player.runCommandAsync("effect @s haste 0 0 true");
    }
  }

  activateFlurry(player, duration = 100) {
    const s = StorageManager.forPlayer(player);
    s.set("dn_flurry", duration);
    player.addTag("ec.dn_flurry");
    player.sendMessage("§d§l✦ Flurry! §r§7Rapid strikes for " + (duration / 20) + "s");
    player.playSound("entity.breeze.wind_burst");
  }

  tick(player) {
    if (!player.hasTag("ec.dn_active")) return;
    const s = StorageManager.forPlayer(player);

    let flurry = s.getNumber("dn_flurry");
    if (flurry > 0) {
      flurry--;
      s.set("dn_flurry", flurry);
      let swing = s.getNumber("dn_swing") - 1;
      if (swing <= 0) {
        this.doFlurrySwing(player, s);
        const tier = s.getNumber("dn_tier") || 1;
        swing = DancerClass.TIER_DATA[tier - 1]?.interval || 20;
      }
      s.set("dn_swing", swing);
      if (flurry <= 0) {
        player.removeTag("ec.dn_flurry");
        player.sendMessage("§d§lFlurry §r§7ended");
      }
    }
  }

  doFlurrySwing(player, s) {
    const tier = s.getNumber("dn_tier") || 1;
    const data = DancerClass.TIER_DATA[tier - 1] || DancerClass.TIER_DATA[0];
    try {
      const nearby = player.dimension.getEntities({
        location: player.location,
        maxDistance: 2,
        excludeTypes: ["minecraft:player"],
        excludeFamilies: ["inanimate"],
      });
      let hits = 0;
      for (const entity of nearby) {
        if (hits >= 2) break;
        try {
          entity.applyDamage(data.damage, { cause: "entityAttack", damagingEntity: player });
          hits++;
        } catch {}
      }
    } catch {}
  }
}

// ─── ARCHER ───────────────────────────────────────────────
class ArcherClass {
  /** Overcharge bow system with per-bow thresholds */
  static BOWS = {
    1: { name: "Hunting Bow", threshold: 30 },
    2: { name: "Mechanical Shortbow", threshold: 40 },
    3: { name: "Battle Bow", threshold: 50 },
    4: { name: "Longbow", threshold: 60 },
    5: { name: "Frostbite Bow", threshold: 60 },
    6: { name: "Stormcaller Bow", threshold: 80 },
    7: { name: "Ancient Bow", threshold: 70 },
    8: { name: "Arm Cannon", threshold: 50 },
    9: { name: "Sabrewing", threshold: 60 },
    10: { name: "Call of the Void", threshold: 90 },
    11: { name: "Hunter's Promise", threshold: 70 },
    12: { name: "Gaster Blaster", threshold: 100 },
  };

  activate(player, bowId) {
    player.addTag("ec.ar_active");
    const s = StorageManager.forPlayer(player);
    s.set("ar_bow_id", bowId);
    s.set("ar_draw", 0);
    s.set("ar_charged", 0);
    s.set("ar_cd", 0);
    const bow = ArcherClass.BOWS[bowId];
    player.sendMessage(`§a§l🏹 Archer §r§7class activated — ${bow?.name || "Unknown Bow"}`);
  }

  deactivate(player) {
    player.removeTag("ec.ar_active");
    player.removeTag("ec.ar_charged");
  }

  /** Called when player is using a bow (drawing) */
  onDrawTick(player) {
    if (!player.hasTag("ec.ar_active")) return;
    const s = StorageManager.forPlayer(player);
    let draw = s.getNumber("ar_draw") + 1;
    s.set("ar_draw", draw);

    const bowId = s.getNumber("ar_bow_id");
    const bow = ArcherClass.BOWS[bowId];
    if (bow && draw >= bow.threshold && !player.hasTag("ec.ar_charged")) {
      player.addTag("ec.ar_charged");
      player.sendMessage("§a§l⚡ OVERCHARGED!");
      player.playSound("random.orb");
    }
  }

  /** Called when player fires arrow */
  onFire(player) {
    if (!player.hasTag("ec.ar_active")) return;
    const s = StorageManager.forPlayer(player);
    const wasCharged = player.hasTag("ec.ar_charged");
    s.set("ar_draw", 0);
    player.removeTag("ec.ar_charged");

    if (wasCharged) {
      // Overcharged shot — bonus damage applied via event
      s.set("ar_overcharge_hit", 1);
      player.sendMessage("§a§l🏹 Overcharged shot fired!");
    }
  }

  /** Apply overcharge bonus on hit — dispatches per-bow ability */
  onHit(player, target) {
    const s = StorageManager.forPlayer(player);
    if (!s.getNumber("ar_overcharge_hit")) return;
    s.set("ar_overcharge_hit", 0);

    const bowId = s.getNumber("ar_bow_id");
    try {
      switch (bowId) {
        case 1: // Hunting Bow — Thorn: Wither I (4s)
          target.applyDamage(5, { cause: "entityAttack", damagingEntity: player });
          target.runCommandAsync("effect @s wither 4 0 true");
          player.onScreenDisplay.setActionBar("§2§lThorn!");
          break;
        case 2: // Mechanical Shortbow — Steady: damage reduction to self
          target.applyDamage(5, { cause: "entityAttack", damagingEntity: player });
          player.runCommandAsync("effect @s resistance 5 0 true");
          player.onScreenDisplay.setActionBar("§7§lSteady Shot!");
          break;
        case 3: // Battle Bow — Flicker: teleport to target
          target.applyDamage(5, { cause: "entityAttack", damagingEntity: player });
          player.teleport(target.location, { dimension: player.dimension });
          player.onScreenDisplay.setActionBar("§e§lFlicker!");
          player.playSound("entity.enderman.teleport");
          break;
        case 4: // Longbow — Predator: mark target + 50% damage buff for 10s
          target.applyDamage(5, { cause: "entityAttack", damagingEntity: player });
          target.runCommandAsync("effect @s glowing 10 0 true");
          player.runCommandAsync("effect @s strength 10 0 true");
          player.onScreenDisplay.setActionBar("§c§lPredator Mark!");
          break;
        case 5: // Frostbite Bow — Frostfang: Slowness IV + Mining Fatigue II (6s)
          target.applyDamage(5, { cause: "entityAttack", damagingEntity: player });
          target.runCommandAsync("effect @s slowness 6 3 true");
          target.runCommandAsync("effect @s mining_fatigue 6 1 true");
          this.frostZone(player, target.location, 5);
          player.onScreenDisplay.setActionBar("§b§lFrostfang!");
          break;
        case 6: // Stormcaller — Uplift: Levitation + KB AoE
          target.applyDamage(5, { cause: "entityAttack", damagingEntity: player });
          target.runCommandAsync("effect @s levitation 2 1 true");
          this.kbAoE(player, target.location, 5, 0.8);
          player.onScreenDisplay.setActionBar("§e§lUplift!");
          break;
        case 7: // Ancient Bow — Kindlestrike: Fire AoE burst
          target.applyDamage(5, { cause: "entityAttack", damagingEntity: player });
          this.fireAoE(player, target.location, 4, 5);
          player.onScreenDisplay.setActionBar("§6§lKindlestrike!");
          break;
        case 8: // Arm Cannon — Deadshot: big single-target damage
          target.applyDamage(12, { cause: "entityAttack", damagingEntity: player });
          player.onScreenDisplay.setActionBar("§c§lDeadshot!");
          player.playSound("entity.firework_rocket.large_blast");
          break;
        case 9: // Sabrewing — Tempest: multi-phase (arrow burst + debuff zone)
          target.applyDamage(8, { cause: "entityAttack", damagingEntity: player });
          this.tempestPhase(player, target.location);
          player.onScreenDisplay.setActionBar("§9§lTempest!");
          break;
        case 10: // Call of the Void — Soulstring: pull target + wither
          target.applyDamage(6, { cause: "entityAttack", damagingEntity: player });
          target.runCommandAsync("effect @s wither 5 1 true");
          target.runCommandAsync("effect @s slowness 5 2 true");
          player.onScreenDisplay.setActionBar("§5§lSoulstring!");
          break;
        case 11: // Hunter's Promise — Whisper: mark + weakness chain
          target.applyDamage(5, { cause: "entityAttack", damagingEntity: player });
          target.runCommandAsync("effect @s glowing 8 0 true");
          target.runCommandAsync("effect @s weakness 8 1 true");
          player.runCommandAsync("effect @s speed 8 1 true");
          player.onScreenDisplay.setActionBar("§a§lWhisper!");
          break;
        case 12: // Gaster Blaster — Oblivion: 7-block void zone
          target.applyDamage(10, { cause: "entityAttack", damagingEntity: player });
          this.oblivionZone(player, target.location, 7, 5);
          player.onScreenDisplay.setActionBar("§5§lOblivion!");
          break;
        default:
          target.applyDamage(5, { cause: "entityAttack", damagingEntity: player });
          break;
      }
      player.playSound("entity.firework_rocket.blast");
    } catch {}
  }

  /** Frostfang: apply slowness to all in radius */
  frostZone(player, loc, radius) {
    try {
      const entities = player.dimension.getEntities({
        location: loc, maxDistance: radius,
        excludeTypes: ["minecraft:player"], excludeFamilies: ["inanimate"],
      });
      for (const e of entities) {
        try { e.runCommandAsync("effect @s slowness 4 2 true"); } catch {}
      }
    } catch {}
  }

  /** Uplift: knockback all nearby mobs */
  kbAoE(player, loc, radius, strength) {
    try {
      const entities = player.dimension.getEntities({
        location: loc, maxDistance: radius,
        excludeTypes: ["minecraft:player"], excludeFamilies: ["inanimate"],
      });
      for (const e of entities) {
        try { e.applyKnockback(0, 0, 0, strength); } catch {}
      }
    } catch {}
  }

  /** Kindlestrike: ignite nearby mobs */
  fireAoE(player, loc, radius, fireTicks) {
    try {
      const entities = player.dimension.getEntities({
        location: loc, maxDistance: radius,
        excludeTypes: ["minecraft:player"], excludeFamilies: ["inanimate"],
      });
      for (const e of entities) {
        try { e.setOnFire(fireTicks, true); } catch {}
      }
    } catch {}
  }

  /** Tempest: burst AoE + poison/wither zone */
  tempestPhase(player, loc) {
    try {
      const entities = player.dimension.getEntities({
        location: loc, maxDistance: 6,
        excludeTypes: ["minecraft:player"], excludeFamilies: ["inanimate"],
      });
      for (const e of entities) {
        try {
          e.applyDamage(4, { cause: "entityAttack", damagingEntity: player });
          e.runCommandAsync("effect @s poison 5 1 true");
          e.runCommandAsync("effect @s wither 5 0 true");
        } catch {}
      }
    } catch {}
  }

  /** Oblivion: void zone with multiple debuffs */
  oblivionZone(player, loc, radius, duration) {
    // Apply immediate debuffs in zone; scheduled re-application via tag
    try {
      const entities = player.dimension.getEntities({
        location: loc, maxDistance: radius,
        excludeTypes: ["minecraft:player"], excludeFamilies: ["inanimate"],
      });
      for (const e of entities) {
        try {
          e.runCommandAsync(`effect @s wither ${duration} 2 true`);
          e.runCommandAsync(`effect @s levitation ${duration} 1 true`);
          e.runCommandAsync(`effect @s slowness ${duration} 3 true`);
          e.runCommandAsync(`effect @s glowing ${duration} 0 true`);
        } catch {}
      }
    } catch {}
  }

  tick(player) {
    // Archer is mostly event-driven, minimal tick work
  }
}

// ─── HUNTER ───────────────────────────────────────────────
class HunterClass {
  /** Precision crossbow with steady aim and fade ability */
  static CROSSBOWS = {
    1: { name: "Windrunner", threshold: 30, cooldown: 6 },
    2: { name: "Air Strike", threshold: 40, cooldown: 10 },
    3: { name: "Acacia Ballista", threshold: 50, cooldown: 15 },
    4: { name: "Venomfang Crossbow", threshold: 60, cooldown: 20 },
    5: { name: "Echo Shot", threshold: 60, cooldown: 25 },
    6: { name: "Awper Hand", threshold: 80, cooldown: 40 },
  };

  activate(player, crossbowId) {
    player.addTag("ec.ht_active");
    const s = StorageManager.forPlayer(player);
    s.set("ht_bow_id", crossbowId);
    s.set("ht_aim", 0);
    s.set("ht_charged", 0);
    s.set("ht_cd", 0);
    s.set("ht_fade", 0);
    const xbow = HunterClass.CROSSBOWS[crossbowId];
    player.sendMessage(`§6§l🎯 Hunter §r§7class activated — ${xbow?.name || "Unknown Crossbow"}`);
  }

  deactivate(player) {
    player.removeTag("ec.ht_active");
    player.removeTag("ec.ht_charged");
  }

  /** Steady aim while sneaking */
  onAimTick(player) {
    if (!player.hasTag("ec.ht_active")) return;
    if (!player.isSneaking) return;
    const s = StorageManager.forPlayer(player);
    let aim = s.getNumber("ht_aim") + 1;
    s.set("ht_aim", aim);

    const bowId = s.getNumber("ht_bow_id");
    const xbow = HunterClass.CROSSBOWS[bowId];
    if (xbow && aim >= xbow.threshold && !player.hasTag("ec.ht_charged")) {
      player.addTag("ec.ht_charged");
      player.sendMessage("§6§l⚡ Precision Ready!");
      player.playSound("random.orb");
    }
  }

  /** Precision shot fired */
  onFire(player) {
    if (!player.hasTag("ec.ht_active")) return;
    const s = StorageManager.forPlayer(player);
    if (player.hasTag("ec.ht_charged")) {
      s.set("ht_precision_hit", 1);
      player.removeTag("ec.ht_charged");
      const bowId = s.getNumber("ht_bow_id");
      const xbow = HunterClass.CROSSBOWS[bowId];
      s.set("ht_cd", xbow?.cooldown || 10);
    }
    s.set("ht_aim", 0);
  }

  /** Fade ability: brief invisibility */
  activateFade(player) {
    const s = StorageManager.forPlayer(player);
    if (s.getNumber("ht_fade") > 0) return;
    player.runCommandAsync("effect @s invisibility 5 0 true");
    s.set("ht_fade", 30);
    player.sendMessage("§6§l🎯 Fade §r§7— Invisible for 5s");
  }

  onHit(player, target) {
    const s = StorageManager.forPlayer(player);
    if (!s.getNumber("ht_precision_hit")) return;
    s.set("ht_precision_hit", 0);

    const bowId = s.getNumber("ht_bow_id");
    try {
      switch (bowId) {
        case 1: // Windrunner — Rapid: speed boost after precision shot
          target.applyDamage(8, { cause: "entityAttack", damagingEntity: player });
          player.runCommandAsync("effect @s speed 5 1 true");
          player.onScreenDisplay.setActionBar("§a§lRapid!");
          break;
        case 2: // Air Strike — knock target airborne
          target.applyDamage(8, { cause: "entityAttack", damagingEntity: player });
          target.runCommandAsync("effect @s levitation 2 1 true");
          player.onScreenDisplay.setActionBar("§e§lAir Strike!");
          break;
        case 3: // Acacia Ballista — Impale: massive single-target + pin
          target.applyDamage(16, { cause: "entityAttack", damagingEntity: player });
          target.runCommandAsync("effect @s slowness 3 4 true");
          target.runCommandAsync("effect @s mining_fatigue 3 3 true");
          player.onScreenDisplay.setActionBar("§6§lImpale!");
          break;
        case 4: // Venomfang — Blight: Wither + Poison AoE (5 blocks)
          target.applyDamage(8, { cause: "entityAttack", damagingEntity: player });
          this.blightAoE(player, target.location, 5);
          player.onScreenDisplay.setActionBar("§2§lBlight!");
          break;
        case 5: // Echo Shot — Resonance: damage echoes to nearby
          target.applyDamage(8, { cause: "entityAttack", damagingEntity: player });
          this.resonanceEcho(player, target.location, 6, 4);
          player.onScreenDisplay.setActionBar("§d§lResonance!");
          break;
        case 6: // Awper Hand — Rift: void gravity well at target
          target.applyDamage(10, { cause: "entityAttack", damagingEntity: player });
          this.createRift(player, target.location);
          player.onScreenDisplay.setActionBar("§5§lRift!");
          break;
        default:
          target.applyDamage(8, { cause: "entityAttack", damagingEntity: player });
          break;
      }
      player.sendMessage("§6§l💥 Precision Hit!");
      player.playSound("entity.firework_rocket.blast");
    } catch {}
  }

  /** Blight AoE: Wither + Poison to mobs in radius */
  blightAoE(player, loc, radius) {
    try {
      const entities = player.dimension.getEntities({
        location: loc, maxDistance: radius,
        excludeTypes: ["minecraft:player"], excludeFamilies: ["inanimate"],
      });
      for (const e of entities) {
        try {
          e.runCommandAsync("effect @s wither 5 1 true");
          e.runCommandAsync("effect @s poison 5 1 true");
        } catch {}
      }
    } catch {}
  }

  /** Resonance: echo damage to nearby mobs */
  resonanceEcho(player, loc, radius, damage) {
    try {
      const entities = player.dimension.getEntities({
        location: loc, maxDistance: radius,
        excludeTypes: ["minecraft:player"], excludeFamilies: ["inanimate"],
      });
      for (const e of entities) {
        try { e.applyDamage(damage, { cause: "entityAttack", damagingEntity: player }); } catch {}
      }
    } catch {}
  }

  /** Rift: void gravity well — pull + wither + slow */
  createRift(player, loc) {
    try {
      const entities = player.dimension.getEntities({
        location: loc, maxDistance: 6,
        excludeTypes: ["minecraft:player"], excludeFamilies: ["inanimate"],
      });
      for (const e of entities) {
        try {
          e.runCommandAsync("effect @s wither 4 2 true");
          e.runCommandAsync("effect @s slowness 4 3 true");
          // Pull toward rift center
          const dx = loc.x - e.location.x;
          const dz = loc.z - e.location.z;
          const dist = Math.sqrt(dx * dx + dz * dz);
          if (dist > 0.5) {
            e.applyKnockback(-(dx / dist), -(dz / dist), 0.6, 0);
          }
        } catch {}
      }
    } catch {}
  }

  tickSecond(player) {
    if (!player.hasTag("ec.ht_active")) return;
    const s = StorageManager.forPlayer(player);
    let cd = s.getNumber("ht_cd");
    if (cd > 0) { cd--; s.set("ht_cd", cd); }
    let fade = s.getNumber("ht_fade");
    if (fade > 0) { fade--; s.set("ht_fade", fade); }
  }
}

// ─── JAVELIN ──────────────────────────────────────────────
class JavelinClass {
  /** Trident momentum system with hoplite sub-class */
  activate(player, tier, javelinId) {
    player.addTag("ec.jv_active");
    const s = StorageManager.forPlayer(player);
    s.set("jv_tier", tier);
    s.set("jv_id", javelinId);
    s.set("jv_thrown", 0);
    s.set("jv_melee", 0);
    s.set("jv_hoplite", 0);
    s.set("jv_aegis", 0);
    s.set("jv_aegis_cd", 0);
    this.checkHoplite(player, s);
    player.sendMessage("§b§l🔱 Javelin §r§7class activated");
  }

  deactivate(player) {
    player.removeTag("ec.jv_active");
    player.removeTag("ec.jv_hoplite");
  }

  checkHoplite(player, s) {
    const equip = player.getComponent("minecraft:equippable");
    if (!equip) return;
    const offhand = equip.getEquipment("Offhand");
    const hasShield = offhand?.typeId === "minecraft:shield";
    const prev = s.getNumber("jv_hoplite");
    s.set("jv_hoplite", hasShield ? 1 : 0);
    if (hasShield && !prev) {
      player.addTag("ec.jv_hoplite");
      player.sendMessage("§b§lHoplite Mode §r§7— Shield defense active");
    } else if (!hasShield && prev) {
      player.removeTag("ec.jv_hoplite");
    }
  }

  /** Named trident abilities */
  static TRIDENT_ABILITIES = {
    1: "ocean",       // Ancient Trident — Ocean's Favor: Water Breathing + Dolphin's Grace
    2: "crucible",    // Crucible — Searing Strike: fire damage + ignite
    3: "fantasy",     // Fantasy Trident — Dreamstrike: levitation + slow
    4: "gungnir",     // Gungnir — True Strike: Glowing + Weakness on target
    5: "master_bolt", // Master Bolt — Chain Lightning: AoE damage
    6: "mjolnir",     // Mjölnir — Thunder: AoE + Slowness
    7: "ninja",       // Ninja Trident — Shadow Thrust: brief invis after hit
    8: "norroen",     // Norroen Trident — Frostbite: Slowness + Mining Fatigue
    9: "royal",       // Royal Trident — Command: Strength + Resistance to self
    10: "shuriken",   // Shuriken — Flurry: rapid multi-hit on thrown
  };

  onMeleeHit(player, target) {
    if (!player.hasTag("ec.jv_active")) return;
    const s = StorageManager.forPlayer(player);
    s.set("jv_melee", 40); // 2s momentum
    let aegis = s.getNumber("jv_aegis") + 1;
    s.set("jv_aegis", aegis);
    s.set("jv_aegis_w", 60); // 3s window

    if (aegis >= 3 && s.getNumber("jv_aegis_cd") <= 0) {
      this.aegisBurst(player, s);
    }

    // Named trident melee ability
    this.applyTridentAbility(player, target, s, "melee");
  }

  onThrownHit(player, target) {
    if (!player.hasTag("ec.jv_active")) return;
    const s = StorageManager.forPlayer(player);
    s.set("jv_thrown", 60); // 3s momentum

    // Named trident thrown ability
    if (target) this.applyTridentAbility(player, target, s, "thrown");
  }

  applyTridentAbility(player, target, s, mode) {
    const jvId = s.getNumber("jv_id");
    const ability = JavelinClass.TRIDENT_ABILITIES[jvId];
    if (!ability) return;

    try {
      switch (ability) {
        case "ocean": // Ancient Trident — Water Breathing + Dolphin's Grace
          player.runCommandAsync("effect @s water_breathing 15 0 true");
          player.runCommandAsync("effect @s conduit_power 8 0 true");
          break;
        case "crucible": // Crucible — fire damage + ignite
          target.setOnFire(5, true);
          target.applyDamage(3, { cause: "entityAttack", damagingEntity: player });
          break;
        case "fantasy": // Fantasy — levitation + slowness
          target.runCommandAsync("effect @s levitation 2 0 true");
          target.runCommandAsync("effect @s slowness 3 1 true");
          break;
        case "gungnir": // Gungnir — True Strike: Glowing + Weakness
          target.runCommandAsync("effect @s glowing 5 0 true");
          target.runCommandAsync("effect @s weakness 3 0 true");
          break;
        case "master_bolt": { // Master Bolt — Chain Lightning AoE
          const nearby = player.dimension.getEntities({
            location: target.location, maxDistance: 5,
            excludeTypes: ["minecraft:player"], excludeFamilies: ["inanimate"],
          });
          const tier = s.getNumber("jv_tier") || 1;
          for (const e of nearby) {
            try { e.applyDamage(2 + tier, { cause: "entityAttack", damagingEntity: player }); } catch {}
          }
          player.onScreenDisplay.setActionBar("§e§lChain Lightning!");
          break;
        }
        case "mjolnir": { // Mjölnir — Thunder AoE + Slowness
          const nearby = player.dimension.getEntities({
            location: target.location, maxDistance: 6,
            excludeTypes: ["minecraft:player"], excludeFamilies: ["inanimate"],
          });
          for (const e of nearby) {
            try {
              e.applyDamage(4, { cause: "entityAttack", damagingEntity: player });
              e.runCommandAsync("effect @s slowness 3 1 true");
            } catch {}
          }
          player.onScreenDisplay.setActionBar("§e§lThunder!");
          player.playSound("entity.lightning_bolt.thunder");
          break;
        }
        case "ninja": // Ninja — Shadow Thrust: brief invis
          player.runCommandAsync("effect @s invisibility 2 0 true");
          player.runCommandAsync("effect @s speed 3 1 true");
          break;
        case "norroen": // Norroen — Frostbite
          target.runCommandAsync("effect @s slowness 4 2 true");
          target.runCommandAsync("effect @s mining_fatigue 4 1 true");
          break;
        case "royal": // Royal — Command: buff self
          player.runCommandAsync("effect @s strength 5 0 true");
          player.runCommandAsync("effect @s resistance 5 0 true");
          break;
        case "shuriken": // Shuriken — Flurry: multi-hit on thrown
          if (mode === "thrown") {
            for (let i = 0; i < 3; i++) {
              try { target.applyDamage(2, { cause: "entityAttack", damagingEntity: player }); } catch {}
            }
            player.onScreenDisplay.setActionBar("§7§lFlurry!");
          }
          break;
      }
    } catch {}
  }

  aegisBurst(player, s) {
    s.set("jv_aegis", 0);
    s.set("jv_aegis_cd", 120); // 6s cooldown
    try {
      const nearby = player.dimension.getEntities({
        location: player.location,
        maxDistance: 4,
        excludeTypes: ["minecraft:player"],
        excludeFamilies: ["inanimate"],
      });
      const tier = s.getNumber("jv_tier") || 1;
      const damage = 3 + tier * 2;
      for (const entity of nearby) {
        try {
          entity.applyDamage(damage, { cause: "entityAttack", damagingEntity: player });
        } catch {}
      }
      player.sendMessage("§b§l⚡ Aegis Burst!");
      player.playSound("entity.warden.sonic_boom");
    } catch {}
  }

  tick(player) {
    if (!player.hasTag("ec.jv_active")) return;
    const s = StorageManager.forPlayer(player);

    // Decrement momentum
    let thrown = s.getNumber("jv_thrown");
    if (thrown > 0) { s.set("jv_thrown", thrown - 1); }
    let melee = s.getNumber("jv_melee");
    if (melee > 0) { s.set("jv_melee", melee - 1); }

    // Resistance while momentum active
    if (thrown > 0 || melee > 0) {
      player.runCommandAsync("effect @s resistance 3 0 true");
    }

    // Aegis window
    let window = s.getNumber("jv_aegis_w");
    if (window > 0) {
      window--;
      s.set("jv_aegis_w", window);
      if (window <= 0) s.set("jv_aegis", 0);
    }

    // Aegis cooldown
    let cd = s.getNumber("jv_aegis_cd");
    if (cd > 0) { s.set("jv_aegis_cd", cd - 1); }

    // Hoplite check (every ~20 ticks handled by parent)
  }
}

// ─── STRIKER ──────────────────────────────────────────────
class StrikerClass {
  /** Mace impact system with ground slam and sentinel mode */
  static KB_RESIST = [0.3, 0.6, 0.9, 1.0, 1.0, 1.0];

  /** Named mace abilities */
  static MACE_ABILITIES = {
    1: { name: "Combat Mace", type: "shield_break" }, // strips Resistance + Weakness II
  };

  activate(player, tier, weaponId) {
    player.addTag("ec.sk_active");
    const s = StorageManager.forPlayer(player);
    s.set("sk_tier", tier);
    s.set("sk_weapon_id", weaponId || 0);
    s.set("sk_impact", 0);
    s.set("sk_cd", 0);
    s.set("sk_sentinel", 0);
    s.set("sk_combat", 0);
    this.checkSentinel(player, s);
    player.sendMessage("§6§l🔨 Striker §r§7class activated");
  }

  deactivate(player) {
    player.removeTag("ec.sk_active");
    player.removeTag("ec.sk_sentinel");
  }

  checkSentinel(player, s) {
    const equip = player.getComponent("minecraft:equippable");
    if (!equip) return;
    const offhand = equip.getEquipment("Offhand");
    const hasShield = offhand?.typeId === "minecraft:shield";
    const prev = s.getNumber("sk_sentinel");
    s.set("sk_sentinel", hasShield ? 1 : 0);
    if (hasShield && !prev) {
      player.addTag("ec.sk_sentinel");
      player.sendMessage("§3§lSentinel Mode §r§7— Fortress defense active");
    } else if (!hasShield && prev) {
      player.removeTag("ec.sk_sentinel");
    }
  }

  onHit(player, target) {
    if (!player.hasTag("ec.sk_active")) return;
    const s = StorageManager.forPlayer(player);
    const tier = s.getNumber("sk_tier") || 1;
    const maxImpact = 3 + tier;
    let impact = s.getNumber("sk_impact");
    if (impact < maxImpact) {
      impact++;
      s.set("sk_impact", impact);
    }
    s.set("sk_combat", 60); // 3s combat timer

    // Named mace ability
    const weaponId = s.getNumber("sk_weapon_id");
    const ab = StrikerClass.MACE_ABILITIES[weaponId];
    if (ab?.type === "shield_break") {
      try {
        target.runCommandAsync("effect @s resistance 0");
        target.runCommandAsync("effect @s weakness 4 1 true");
        player.onScreenDisplay.setActionBar("§c§lShield Break!");
      } catch {}
    }
  }

  /** Ground slam: AoE based on accumulated impact */
  groundSlam(player) {
    const s = StorageManager.forPlayer(player);
    if (s.getNumber("sk_cd") > 0) {
      player.sendMessage("§6§lGround Slam §r§7on cooldown");
      return;
    }
    const impact = s.getNumber("sk_impact");
    if (impact <= 0) {
      player.sendMessage("§6§lGround Slam §r§7— No impact charge");
      return;
    }

    const tier = s.getNumber("sk_tier") || 1;
    const damage = impact * (2 + tier);
    const radius = 3 + Math.floor(impact / 2);

    try {
      const nearby = player.dimension.getEntities({
        location: player.location,
        maxDistance: radius,
        excludeTypes: ["minecraft:player"],
        excludeFamilies: ["inanimate"],
      });
      for (const entity of nearby) {
        try {
          entity.applyDamage(damage, { cause: "entityAttack", damagingEntity: player });
        } catch {}
      }
    } catch {}

    s.set("sk_impact", 0);
    s.set("sk_cd", 15);
    player.sendMessage(`§6§l💥 Ground Slam! §r§7${damage} damage in ${radius}b radius`);
    player.playSound("entity.iron_golem.attack");
  }

  tickSecond(player) {
    if (!player.hasTag("ec.sk_active")) return;
    const s = StorageManager.forPlayer(player);
    let cd = s.getNumber("sk_cd");
    if (cd > 0) { cd--; s.set("sk_cd", cd); }
    // Combat decay
    let combat = s.getNumber("sk_combat");
    if (combat > 0) {
      combat -= 20;
      s.set("sk_combat", Math.max(0, combat));
      if (combat <= 0) {
        // Impact decays out of combat
        let impact = s.getNumber("sk_impact");
        if (impact > 0) s.set("sk_impact", impact - 1);
      }
    }
  }
}

// ─── BEASTLORD ────────────────────────────────────────────
class BeastlordClass {
  /** Spear class: tamed animal buffs + warp strikes */
  activate(player, tier, spearId) {
    player.addTag("ec.bl_active");
    const s = StorageManager.forPlayer(player);
    s.set("bl_tier", tier);
    s.set("bl_spear", spearId);
    s.set("bl_warp_w", 0);
    s.set("bl_warp_c", 0);
    s.set("bl_warp_p", 0);
    s.set("bl_str_tick", 0);
    player.sendMessage("§2§l🐾 Beastlord §r§7class activated");
  }

  deactivate(player) {
    player.removeTag("ec.bl_active");
  }

  /** Apply strength aura to tamed animals every 2 seconds */
  applyStrengthAura(player) {
    try {
      // Wolves
      const wolves = player.dimension.getEntities({
        type: "minecraft:wolf",
        location: player.location,
        maxDistance: 16,
      });
      for (const wolf of wolves) {
        try { wolf.runCommandAsync("effect @s strength 5 0 true"); } catch {}
      }
      // Cats
      const cats = player.dimension.getEntities({
        type: "minecraft:cat",
        location: player.location,
        maxDistance: 16,
      });
      for (const cat of cats) {
        try { cat.runCommandAsync("effect @s strength 5 0 true"); } catch {}
      }
    } catch {}
  }

  /** Warp strike: teleport to animal, AoE damage */
  warpStrike(player, animalType) {
    const s = StorageManager.forPlayer(player);
    const cdKey = `bl_warp_${animalType[0]}`; // w, c, or p
    if (s.getNumber(cdKey) > 0) return;

    try {
      const animals = player.dimension.getEntities({
        type: `minecraft:${animalType}`,
        location: player.location,
        maxDistance: 32,
      });
      if (animals.length === 0) return;
      const target = animals[0];
      player.teleport(target.location, { dimension: player.dimension });

      const tier = s.getNumber("bl_tier") || 1;
      const damage = 3 + tier * 2;
      const nearby = player.dimension.getEntities({
        location: target.location,
        maxDistance: 4,
        excludeTypes: ["minecraft:player", `minecraft:${animalType}`],
        excludeFamilies: ["inanimate"],
      });
      for (const entity of nearby) {
        try {
          entity.applyDamage(damage, { cause: "entityAttack", damagingEntity: player });
        } catch {}
      }

      s.set(cdKey, 15); // 15s cooldown
      player.sendMessage(`§2§l🐾 Warp Strike! §r§7Teleported to ${animalType}`);
      player.playSound("entity.enderman.teleport");
    } catch {}
  }

  tick(player) {
    if (!player.hasTag("ec.bl_active")) return;
    const s = StorageManager.forPlayer(player);

    // Strength aura every 2 seconds (40 ticks)
    let strTick = s.getNumber("bl_str_tick") + 1;
    if (strTick >= 40) {
      strTick = 0;
      this.applyStrengthAura(player);
    }
    s.set("bl_str_tick", strTick);
  }

  tickSecond(player) {
    if (!player.hasTag("ec.bl_active")) return;
    const s = StorageManager.forPlayer(player);
    for (const key of ["bl_warp_w", "bl_warp_c", "bl_warp_p"]) {
      let cd = s.getNumber(key);
      if (cd > 0) { cd--; s.set(key, cd); }
    }
  }
}


// ═══════════════════════════════════════════════════════════
// MAIN WEAPON CLASS SYSTEM (orchestrator)
// ═══════════════════════════════════════════════════════════
export class WeaponClassSystem {
  constructor(eventBridge) {
    this.knight = new KnightClass();
    this.rogue = new RogueClass();
    this.berserker = new BerserkerClass();
    this.dancer = new DancerClass();
    this.archer = new ArcherClass();
    this.hunter = new HunterClass();
    this.javelin = new JavelinClass();
    this.striker = new StrikerClass();
    this.beastlord = new BeastlordClass();

    this.tickCounter = 0;

    // Combat events
    eventBridge.on("player_dealt_damage", (player, target, damage) => {
      this.onPlayerAttack(player, target, damage);
    });

    // Equipment change detection
    eventBridge.on("player_item_use", (player, item) => {
      this.onItemUse(player, item);
    });
  }

  /** Detect active weapon class from equipped mainhand */
  detectClass(player) {
    const equip = player.getComponent("minecraft:equippable");
    if (!equip) return null;
    const mainhand = equip.getEquipment("Mainhand");
    if (!mainhand) return null;

    const tags = mainhand.getTags?.() || [];
    const isAwakened = tags.some(t => t.includes("awakened"));
    if (!isAwakened) return null;

    // Check tags for class identification
    if (tags.some(t => t.includes("forevercraft:knight"))) return "knight";
    if (tags.some(t => t.includes("forevercraft:rogue"))) return "rogue";
    if (tags.some(t => t.includes("forevercraft:dancer"))) return "dancer";
    if (tags.some(t => t.includes("forevercraft:beastlord"))) return "beastlord";
    if (tags.some(t => t.includes("forevercraft:striker"))) return "striker";
    if (tags.some(t => t.includes("forevercraft:archer"))) return "archer";
    if (tags.some(t => t.includes("forevercraft:hunter"))) return "hunter";
    if (tags.some(t => t.includes("forevercraft:javelin"))) return "javelin";

    // Berserker requires dual axes
    if (tags.some(t => t.includes("forevercraft:artifact"))) {
      const typeId = mainhand.typeId || "";
      if (typeId.includes("axe")) {
        const offhand = equip.getEquipment("Offhand");
        if (offhand?.typeId?.includes("axe")) {
          return "berserker";
        }
      }
    }

    return null;
  }

  /** Get weapon tier from tags */
  getTier(item) {
    const tags = item?.getTags?.() || [];
    for (const tag of tags) {
      const match = tag.match(/forevercraft:tier_(\d+)/);
      if (match) return parseInt(match[1]);
    }
    // Default tier from tier name
    if (tags.some(t => t.includes("mythical"))) return 6;
    if (tags.some(t => t.includes("exquisite"))) return 5;
    if (tags.some(t => t.includes("ornate"))) return 4;
    if (tags.some(t => t.includes("rare"))) return 3;
    if (tags.some(t => t.includes("uncommon"))) return 2;
    return 1;
  }

  /** Get weapon-specific ID from tags */
  getWeaponId(item) {
    const tags = item?.getTags?.() || [];
    for (const tag of tags) {
      const match = tag.match(/forevercraft:weapon_id_(\d+)/);
      if (match) return parseInt(match[1]);
    }
    return 1;
  }

  onPlayerAttack(player, target, damage) {
    // Route to active class
    if (player.hasTag("ec.rg_active")) this.rogue.doSwing(player, StorageManager.forPlayer(player));
    if (player.hasTag("ec.jv_active")) this.javelin.onMeleeHit(player, target);
    if (player.hasTag("ec.sk_active")) this.striker.onHit(player, target);
    if (player.hasTag("ec.ar_active")) this.archer.onHit(player, target);
    if (player.hasTag("ec.ht_active")) this.hunter.onHit(player, target);
  }

  onItemUse(player, item) {
    // Berserker rage activation
    if (player.hasTag("ec.bk_active")) {
      this.berserker.activateRage(player);
    }
  }

  /** Per-tick processing for all players */
  tick(players) {
    this.tickCounter++;
    for (const player of players) {
      // Detect and activate/deactivate classes
      if (this.tickCounter % 20 === 0) {
        this.updateActiveClass(player);
      }

      // Per-tick class processing
      if (player.hasTag("ec.rg_active")) this.rogue.tick(player);
      if (player.hasTag("ec.bk_active")) this.berserker.tick(player);
      if (player.hasTag("ec.dn_active")) this.dancer.tick(player);
      if (player.hasTag("ec.jv_active")) this.javelin.tick(player);
      if (player.hasTag("ec.bl_active")) this.beastlord.tick(player);

      // Archer/hunter draw tracking while sneaking
      if (player.hasTag("ec.ar_active")) this.archer.onDrawTick(player);
      if (player.hasTag("ec.ht_active")) this.hunter.onAimTick(player);

      // Per-second processing
      if (this.tickCounter % 20 === 0) {
        if (player.hasTag("ec.kt_active")) this.knight.tick(player);
        if (player.hasTag("ec.bk_active")) this.berserker.tickSecond(player);
        if (player.hasTag("ec.ht_active")) this.hunter.tickSecond(player);
        if (player.hasTag("ec.sk_active")) this.striker.tickSecond(player);
        if (player.hasTag("ec.bl_active")) this.beastlord.tickSecond(player);
      }
    }
  }

  /** Check and update active weapon class for a player */
  updateActiveClass(player) {
    const newClass = this.detectClass(player);
    const currentTags = [
      "ec.kt_active", "ec.rg_active", "ec.bk_active", "ec.dn_active",
      "ec.ar_active", "ec.ht_active", "ec.jv_active", "ec.sk_active", "ec.bl_active"
    ];

    const classMap = {
      knight: "ec.kt_active", rogue: "ec.rg_active", berserker: "ec.bk_active",
      dancer: "ec.dn_active", archer: "ec.ar_active", hunter: "ec.ht_active",
      javelin: "ec.jv_active", striker: "ec.sk_active", beastlord: "ec.bl_active",
    };

    const activeTag = newClass ? classMap[newClass] : null;

    // Deactivate classes that are no longer active
    for (const tag of currentTags) {
      if (player.hasTag(tag) && tag !== activeTag) {
        const className = Object.entries(classMap).find(([, t]) => t === tag)?.[0];
        if (className && this[className]) {
          this[className].deactivate(player);
        }
      }
    }

    // Activate new class if not already active
    if (newClass && activeTag && !player.hasTag(activeTag)) {
      const equip = player.getComponent("minecraft:equippable");
      const mainhand = equip?.getEquipment("Mainhand");
      const tier = this.getTier(mainhand);
      const weaponId = this.getWeaponId(mainhand);

      switch (newClass) {
        case "knight": this.knight.activate(player); break;
        case "rogue": this.rogue.activate(player, tier, weaponId); break;
        case "berserker": this.berserker.activate(player, tier); break;
        case "dancer": this.dancer.activate(player, tier); break;
        case "archer": this.archer.activate(player, weaponId); break;
        case "hunter": this.hunter.activate(player, weaponId); break;
        case "javelin": this.javelin.activate(player, tier, weaponId); break;
        case "striker": this.striker.activate(player, tier, weaponId); break;
        case "beastlord": this.beastlord.activate(player, tier, weaponId); break;
      }
    }
  }
}
