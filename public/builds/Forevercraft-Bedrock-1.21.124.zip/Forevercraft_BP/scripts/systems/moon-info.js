/**
 * Moon Info — Moon phase display command.
 * Replaces Java moon/ folder (1 mcfunction file).
 *
 * Shows current moon phase, next full moon, and phase effects.
 */
import { world } from "@minecraft/server";
import { StorageManager } from "../utils/storage.js";

const MOON_PHASES = [
  { name: "Full Moon", icon: "🌕", effect: "+15% mob spawn, Moonbloom Ceremony available" },
  { name: "Waning Gibbous", icon: "🌖", effect: "+10% mob spawn" },
  { name: "Last Quarter", icon: "🌗", effect: "Normal" },
  { name: "Waning Crescent", icon: "🌘", effect: "-5% mob spawn" },
  { name: "New Moon", icon: "🌑", effect: "-15% mob spawn, +10% rare drops" },
  { name: "Waxing Crescent", icon: "🌒", effect: "-5% mob spawn" },
  { name: "First Quarter", icon: "🌓", effect: "Normal" },
  { name: "Waxing Gibbous", icon: "🌔", effect: "+10% mob spawn" },
];

export class MoonInfoSystem {
  constructor() {}

  /** Show moon info to player */
  showMoonInfo(player) {
    const phase = world.getMoonPhase();
    const moonData = MOON_PHASES[phase] || MOON_PHASES[0];
    const daysToFull = phase === 0 ? 0 : 8 - phase;

    player.sendMessage("\n§e§l✦ Moon Phase ✦§r");
    player.sendMessage(`§7Current: §f${moonData.icon} ${moonData.name}`);
    player.sendMessage(`§7Effect: §f${moonData.effect}`);
    if (daysToFull > 0) {
      player.sendMessage(`§7Next Full Moon: §f${daysToFull} day${daysToFull > 1 ? "s" : ""}`);
    } else {
      player.sendMessage("§a✦ Full Moon tonight! §7Moonbloom Ceremony available.");
    }
    player.sendMessage("");
  }
}
