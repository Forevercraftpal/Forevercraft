/**
 * Convergence System — Rare world events when season/moon/DR align.
 * Replaces Java convergence/ folder (12 mcfunction files).
 *
 * 4 Named Convergences with specific conditions.
 * Effects: Luck +2, ethereal particles, special atmosphere.
 * Duration: ~5-10 minutes. Cooldown prevents spamming.
 */
import { world, system } from "@minecraft/server";
import { StorageManager } from "../utils/storage.js";

const CONVERGENCES = [
  { id: 1, name: "Celestial Tide", season: 1, moonPhase: 0, worldEvent: "starfall", minDR: 150, color: "§b" },
  { id: 2, name: "Veil of Embers", season: 2, moonPhase: 3, worldEvent: "abyssal_tremor", minDR: 200, color: "§4" },
  { id: 3, name: "Frozen Aurora", season: 3, moonPhase: 4, worldEvent: "aurora_bloom", minDR: 150, color: "§f" },
  { id: 4, name: "Bloom of Eternity", season: 0, moonPhase: 2, worldEvent: "rift_echo", minDR: 250, color: "§d" },
];

const CONVERGENCE_DURATION = 6000; // 5 minutes

export class ConvergenceSystem {
  constructor(eventBridge) {
    this.eventBridge = eventBridge;
    this.active = null; // { id, timer, convergence }
    this.cooldown = 0;
  }

  /** Check if conditions align for a convergence (called every 60 seconds) */
  tick(players) {
    if (this.cooldown > 0) { this.cooldown--; return; }

    if (this.active) {
      this.active.timer--;

      // Apply effects to all players
      for (const player of players) {
        try {
          player.addEffect("luck", 80, { amplifier: 1, showParticles: false });
          if (this.active.timer % 5 === 0) {
            player.dimension.spawnParticle("minecraft:endrod", {
              x: player.location.x + (Math.random() - 0.5) * 4,
              y: player.location.y + 2,
              z: player.location.z + (Math.random() - 0.5) * 4,
            });
          }
        } catch {}
      }

      // Countdown warnings
      if (this.active.timer === 100) {
        for (const p of players) p.sendMessage("§e⚠ Convergence fading in 5 minutes...");
      }
      if (this.active.timer === 20) {
        for (const p of players) p.sendMessage("§c⚠ Convergence ending in 1 minute...");
      }

      if (this.active.timer <= 0) {
        for (const p of players) {
          p.sendMessage(`${this.active.convergence.color}§l✦ ${this.active.convergence.name} §r§7has ended.`);
        }
        this.active = null;
        this.cooldown = 1200; // 1 hour cooldown (at 60s tick rate)
      }
      return;
    }

    // Check conditions
    const ws = StorageManager.world();
    const season = ws.getNumber("season_id", 0);
    const moonPhase = world.getMoonPhase();
    const worldEvent = ws.get("active_world_event") || "";

    for (const conv of CONVERGENCES) {
      if (conv.season !== season) continue;
      if (conv.moonPhase !== moonPhase) continue;
      if (conv.worldEvent && worldEvent !== conv.worldEvent) continue;

      // Check if any player meets DR threshold
      let qualified = false;
      for (const player of players) {
        const s = StorageManager.forPlayer(player);
        if (s.getNumber("dream_rate", 0) >= conv.minDR) { qualified = true; break; }
      }
      if (!qualified) continue;

      // Activate convergence!
      this.active = { id: conv.id, timer: CONVERGENCE_DURATION / 60, convergence: conv };

      for (const p of players) {
        p.sendMessage(`\n${conv.color}§l✦ ✦ ✦ ${conv.name.toUpperCase()} ✦ ✦ ✦§r`);
        p.sendMessage("§7The world resonates with ancient energy...");
        p.sendMessage("§7+2 Luck for the duration!");
        p.onScreenDisplay.setTitle(`${conv.color}§l${conv.name}`, {
          subtitle: "§7A convergence has begun!",
          fadeInDuration: 20, stayDuration: 100, fadeOutDuration: 20,
        });
        p.playSound("ui.toast.challenge_complete", { volume: 1.5, pitch: 0.8 });
      }

      this.eventBridge.emit("convergence_started", { id: conv.id, name: conv.name });
      break;
    }
  }
}
