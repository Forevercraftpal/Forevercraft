/**
 * Seasons System (compiled JS)
 */
import { world } from "@minecraft/server";
import { StorageManager } from "../utils/storage.js";

const SEASON_NAMES = { spring: "§aSpring", summer: "§eSummer", autumn: "§6Autumn", winter: "§bWinter" };
const DAYS_PER_YEAR = 365;

export class SeasonSystem {
  constructor() {
    this.storage = StorageManager.world();
    this.currentSeason = this.storage.getString("current_season", "spring");
  }

  getSeason(day) {
    const d = day % DAYS_PER_YEAR;
    if (d < 91) return "spring";
    if (d < 182) return "summer";
    if (d < 273) return "autumn";
    return "winter";
  }

  onDayChange(day) {
    const newSeason = this.getSeason(day);
    if (newSeason !== this.currentSeason) {
      this.currentSeason = newSeason;
      this.storage.set("current_season", newSeason);
      for (const player of world.getAllPlayers()) {
        player.onScreenDisplay.setTitle(`${SEASON_NAMES[newSeason]}§r §7has arrived`, {
          subtitle: "§7The world transforms around you...",
          fadeInDuration: 20, stayDuration: 100, fadeOutDuration: 20,
        });
      }
    }
  }

  getCurrentSeason() { return this.currentSeason; }
  getSeasonName() { return SEASON_NAMES[this.currentSeason]; }
}
