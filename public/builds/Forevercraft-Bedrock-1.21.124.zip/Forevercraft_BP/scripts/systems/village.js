/**
 * Village System — Reputation, specializations, exile, and legend upgrades.
 * Replaces Java village/ folder.
 */
import { world, system } from "@minecraft/server";
import { StorageManager } from "../utils/storage.js";
import { ActionFormData } from "@minecraft/server-ui";

// Village specializations
const SPECIALIZATIONS = [
  { id: 1, name: "Mining", color: "§6", effect: "haste", effectName: "Haste I" },
  { id: 2, name: "Fishing", color: "§b", effect: "luck", effectName: "Luck I" },
  { id: 3, name: "Farming", color: "§a", effect: "regeneration", effectName: "Regeneration I" },
  { id: 4, name: "Combat", color: "§c", effect: "strength", effectName: "Strength I" },
  { id: 5, name: "Exploration", color: "§e", effect: "speed", effectName: "Speed I" },
  { id: 6, name: "Scholarly", color: "§d", effect: "night_vision", effectName: "Night Vision" },
];

// Reputation ranks
const RANKS = [
  { id: 0, name: "Stranger", threshold: 0, color: "§7" },
  { id: 1, name: "Familiar", threshold: 100, color: "§a" },
  { id: 2, name: "Trusted", threshold: 500, color: "§b" },
  { id: 3, name: "Honored", threshold: 1500, color: "§d" },
  { id: 4, name: "Legend", threshold: 5000, color: "§6" },
];

const EXILE_DURATION = 504000; // 7 in-game days in ticks
const EXILE_FORGIVENESS_COST = 64; // emerald blocks

export class VillageSystem {
  constructor(eventBridge) {
    this.eventBridge = eventBridge;

    // Listen for raid victory
    eventBridge.on("raid_victory", (player) => {
      this.onRaidVictory(player);
    });

    // Listen for reputation changes
    eventBridge.on("village_rep_change", (player, amount) => {
      this.changeReputation(player, amount);
    });
  }

  /**
   * Tick — runs every 100 ticks (5 seconds). Applies village buffs.
   */
  tick(players) {
    for (const player of players) {
      if (player.getGameMode() === "creative" || player.getGameMode() === "spectator") continue;

      const storage = StorageManager.forPlayer(player);
      const villageId = storage.getNumber("current_village", 0);
      if (villageId === 0) continue;

      // Check exile
      const exiled = storage.getNumber(`exile_v${villageId}`, 0);
      if (exiled > 0) {
        const now = system.currentTick;
        if (now < exiled) {
          // Still exiled
          const remaining = Math.floor((exiled - now) / 1200); // minutes
          if (system.currentTick % 200 === 0) {
            player.onScreenDisplay?.setActionBar?.(`§cExiled from this village — ${remaining}m remaining`);
          }
          continue;
        } else {
          // Exile expired
          storage.set(`exile_v${villageId}`, 0);
          player.sendMessage("§aYour exile has ended. You may return to the village.");
        }
      }

      // Apply specialization buff
      const specId = this.getVillageSpec(villageId);
      if (specId > 0 && specId <= SPECIALIZATIONS.length) {
        const spec = SPECIALIZATIONS[specId - 1];
        try {
          player.addEffect(spec.effect, 200, { amplifier: 0, showParticles: false });
        } catch {}
      }
    }
  }

  /**
   * Get village specialization (stored in world properties).
   */
  getVillageSpec(villageId) {
    try {
      return Number(world.getDynamicProperty(`village_spec_${villageId}`)) || 0;
    } catch { return 0; }
  }

  /**
   * Set village specialization.
   */
  setVillageSpec(villageId, specId) {
    try {
      world.setDynamicProperty(`village_spec_${villageId}`, specId);
    } catch {}
  }

  /**
   * Change player reputation in their current village.
   */
  changeReputation(player, amount) {
    const storage = StorageManager.forPlayer(player);
    const villageId = storage.getNumber("current_village", 0);
    if (villageId === 0) return;

    const key = `rep_v${villageId}`;
    const oldRep = storage.getNumber(key, 0);
    const newRep = oldRep + amount;
    storage.set(key, newRep);

    // Check rank change
    const oldRank = this.getRankForRep(oldRep);
    const newRank = this.getRankForRep(newRep);

    if (newRank.id > oldRank.id) {
      player.sendMessage(`§6§lRank Up! §r§7You are now §e${newRank.name} §7in this village.`);
      try { player.playSound("random.levelup", { volume: 0.5, pitch: 1.2 }); } catch {}

      // Legend upgrade
      if (newRank.id === 4) {
        this.onLegendReached(player, villageId);
      }
    }

    // Check exile
    if (newRep < 0 && oldRep >= 0) {
      this.exile(player, villageId);
    }
  }

  /**
   * Get rank for a given reputation value.
   */
  getRankForRep(rep) {
    let rank = RANKS[0];
    for (const r of RANKS) {
      if (rep >= r.threshold) rank = r;
    }
    return rank;
  }

  /**
   * Exile player from a village.
   */
  exile(player, villageId) {
    const storage = StorageManager.forPlayer(player);
    const expiresAt = system.currentTick + EXILE_DURATION;
    storage.set(`exile_v${villageId}`, expiresAt);

    // Reset village rep to 0
    storage.set(`rep_v${villageId}`, 0);

    // Deduct 250 renown from reputation system
    this.eventBridge.emit("renown_penalty", { player, amount: 250 });

    // Show exile title
    try {
      player.onScreenDisplay?.setTitle?.("§c§lEXILED", {
        subtitle: "§7Banished for 7 days",
        fadeInDuration: 10, stayDuration: 80, fadeOutDuration: 20,
      });
    } catch {}

    player.sendMessage("\n§c§l✦ EXILED ✦\n§r§7Your actions have made you unwelcome.\n§7You are banished for 7 in-game days.\n§7Seek forgiveness by offering §664 Emerald Blocks §7at the quest board.\n");

    try {
      player.playSound("mob.wither.death", { volume: 0.5, pitch: 0.8 });
      player.playSound("mob.villager.no", { volume: 0.8, pitch: 0.8 });
      player.dimension.spawnParticle("minecraft:villager_angry", player.location);
    } catch {}
  }

  /**
   * Handle raid victory — +150 reputation.
   */
  onRaidVictory(player) {
    const storage = StorageManager.forPlayer(player);
    const villageId = storage.getNumber("current_village", 0);
    if (villageId === 0) return;

    this.changeReputation(player, 150);
    player.sendMessage("§6§l+150 Village Reputation §r§7for defending the village!");
  }

  /**
   * Handle reaching Legend rank.
   */
  onLegendReached(player, villageId) {
    const upgraded = world.getDynamicProperty(`village_upgraded_${villageId}`);
    if (upgraded) return;

    world.setDynamicProperty(`village_upgraded_${villageId}`, true);

    // Spawn iron golem guards
    const pos = player.location;
    const dim = player.dimension;
    try {
      dim.spawnEntity("minecraft:iron_golem", {
        x: pos.x + 5, y: pos.y, z: pos.z + 3,
      });
      dim.spawnEntity("minecraft:iron_golem", {
        x: pos.x - 5, y: pos.y, z: pos.z - 3,
      });
    } catch {}

    player.sendMessage("§6§l✦ Village Upgraded! §r§7Iron Golem guards now protect this village.");

    for (const p of world.getAllPlayers()) {
      if (p.id !== player.id) {
        p.sendMessage(`§6✦ §e${player.name} §7has reached Legend rank! A village has been upgraded!`);
      }
    }
  }

  /**
   * Open village info menu.
   */
  openMenu(player) {
    const storage = StorageManager.forPlayer(player);
    const villageId = storage.getNumber("current_village", 0);

    if (villageId === 0) {
      player.sendMessage("§7You are not in a village.");
      return;
    }

    const rep = storage.getNumber(`rep_v${villageId}`, 0);
    const rank = this.getRankForRep(rep);
    const specId = this.getVillageSpec(villageId);
    const specName = specId > 0 && specId <= SPECIALIZATIONS.length
      ? SPECIALIZATIONS[specId - 1].name
      : "None";

    const exiled = storage.getNumber(`exile_v${villageId}`, 0);
    const isExiled = exiled > 0 && system.currentTick < exiled;

    let body = `§7Village ID: §f${villageId}\n`;
    body += `§7Specialization: §e${specName}\n`;
    body += `§7Reputation: §f${rep}\n`;
    body += `§7Rank: ${rank.color}${rank.name}\n`;
    if (isExiled) {
      const minutes = Math.floor((exiled - system.currentTick) / 1200);
      body += `\n§c§lEXILED §r§7— ${minutes} minutes remaining\n`;
    }

    const form = new ActionFormData()
      .title("§6Village Info")
      .body(body)
      .button("§7Close");

    form.show(player);
  }
}
