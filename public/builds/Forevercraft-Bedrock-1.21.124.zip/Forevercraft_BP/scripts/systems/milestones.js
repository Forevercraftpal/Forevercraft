/**
 * Milestones System — 32 server-wide co-op achievements with global counters.
 * Dynamic player scaling for percentage-based milestones.
 * Permanent realm DR bonuses (up to +4.25 total).
 * Paginated display by category.
 * Replaces Java milestones/ folder.
 */
import { world } from "@minecraft/server";
import { StorageManager } from "../utils/storage.js";
import { ActionFormData } from "@minecraft/server-ui";

// All 32 milestones
const MILESTONES = [
  // ─── Origins (existing 10) ──────────────────────
  { id: 1, name: "First Light", desc: "Defeat your first Patron", threshold: 1, counter: "rm_patrons", reward: "Rare Crate", rewardTier: "rare", category: "origins" },
  { id: 3, name: "Brave New World", desc: "Visit 5 unique biomes", threshold: 5, counter: "rm_biomes", reward: "Rare Crate", rewardTier: "rare", category: "origins" },
  { id: 5, name: "The Hunt Begins", desc: "Defeat 25 Patrons", threshold: 25, counter: "rm_patrons", reward: "Ornate Crate", rewardTier: "ornate", category: "origins" },
  { id: 6, name: "Companion Collectors", desc: "Discover 25 unique pets", threshold: 25, counter: "rm_pets", reward: "Ornate Crate", rewardTier: "ornate", category: "origins" },
  { id: 7, name: "Seasoned Chefs", desc: "Cook 10 unique recipes", threshold: 10, counter: "rm_recipes", reward: "Rare Crate", rewardTier: "rare", category: "origins" },
  { id: 8, name: "Lore Seekers", desc: "Collect 50 lore pieces", threshold: 50, counter: "rm_lore", reward: "Ornate Crate", rewardTier: "ornate", category: "origins" },
  { id: 9, name: "Slayers of the Deep", desc: "Defeat a World Boss", threshold: 1, counter: "rm_boss_kills", reward: "Exquisite Crate", rewardTier: "exquisite", category: "origins" },
  { id: 10, name: "Across All Lands", desc: "Visit all 25 biomes", threshold: 25, counter: "rm_biomes", reward: "Exquisite Crate", rewardTier: "exquisite", category: "origins" },
  { id: 11, name: "Legendary Arsenal", desc: "Find 5 mythical artifacts", threshold: 5, counter: "rm_mythicals", reward: "Exquisite Crate", rewardTier: "exquisite", category: "origins" },
  { id: 12, name: "Quest Masters", desc: "Complete 100 quests", threshold: 100, counter: "rm_quests", reward: "Mythical Crate", rewardTier: "mythical", category: "origins" },

  // ─── Social & Relationships (5 new) ─────────────
  { id: 13, name: "First Friends", desc: "10 friendships formed realm-wide", threshold: 10, counter: "rm_friends", reward: "Ornate Crate", rewardTier: "ornate", category: "social" },
  { id: 14, name: "Bonds of the Heart", desc: "20 friendship level-ups", threshold: 20, counter: "rm_fr_levels", reward: "Exquisite Crate", rewardTier: "exquisite", category: "social", drBonus: 0.5 },
  { id: 15, name: "Eternal Vow", desc: "First marriage in the realm", threshold: 1, counter: "rm_marriages", reward: "Mythical Crate", rewardTier: "mythical", category: "social" },
  { id: 16, name: "Love Conquers All", desc: "2 married couples exist", threshold: 2, counter: "rm_marriages", reward: "Exquisite Crate", rewardTier: "exquisite", category: "social" },
  { id: 17, name: "Found Family", desc: "75% of players have 2+ friends", threshold: 0, counter: "dynamic_friends", reward: "Ornate Crate", rewardTier: "ornate", category: "social", dynamic: true, pctThreshold: 75, playerCheck: "friend_count_2" },

  // ─── Guild & Warfare (5 new) ────────────────────
  { id: 18, name: "Banner Raised", desc: "First guild created", threshold: 1, counter: "rm_guilds", reward: "Rare Crate", rewardTier: "rare", category: "guild" },
  { id: 19, name: "Declaration of War", desc: "First guild war declared", threshold: 1, counter: "rm_guild_wars", reward: "Exquisite Crate", rewardTier: "exquisite", category: "guild" },
  { id: 20, name: "United Front", desc: "First guild alliance formed", threshold: 1, counter: "rm_guild_alliances", reward: "Ornate Crate", rewardTier: "ornate", category: "guild", drBonus: 0.25 },
  { id: 21, name: "Conquest", desc: "A guild wins 3 wars", threshold: 3, counter: "rm_guild_max_wins", reward: "Mythical Crate", rewardTier: "mythical", category: "guild" },
  { id: 22, name: "Guild Dominion", desc: "10,000 total guild contributions", threshold: 10000, counter: "rm_guild_contrib", reward: "Exquisite Crate", rewardTier: "exquisite", category: "guild", drBonus: 1.0 },

  // ─── Exploration & Adventure (4 new) ────────────
  { id: 23, name: "Dream Walkers", desc: "50 Dreaming Realm completions", threshold: 50, counter: "rm_dreams", reward: "Exquisite Crate", rewardTier: "exquisite", category: "adventure" },
  { id: 24, name: "Bounty Board Legends", desc: "100 bounties completed", threshold: 100, counter: "rm_bounties", reward: "Ornate Crate", rewardTier: "ornate", category: "adventure" },
  { id: 25, name: "The Expedition", desc: "50% explored 15+ biomes", threshold: 0, counter: "dynamic_biomes", reward: "Exquisite Crate", rewardTier: "exquisite", category: "adventure", dynamic: true, pctThreshold: 50, playerCheck: "biomes_15" },
  { id: 26, name: "Hearthstone Haven", desc: "75% of players have a home", threshold: 0, counter: "dynamic_homes", reward: "Ornate Crate", rewardTier: "ornate", category: "adventure", dynamic: true, pctThreshold: 75, playerCheck: "has_home" },

  // ─── Combat & Progression (4 new) ───────────────
  { id: 27, name: "The Hundred", desc: "100 patron kills realm-wide", threshold: 100, counter: "rm_patrons", reward: "Exquisite Crate", rewardTier: "exquisite", category: "combat" },
  { id: 28, name: "Ascended", desc: "50% of players reached DR 20+", threshold: 0, counter: "dynamic_dr20", reward: "Mythical Crate", rewardTier: "mythical", category: "combat", dynamic: true, pctThreshold: 50, playerCheck: "dr_20", drBonus: 0.5 },
  { id: 29, name: "Duel of Legends", desc: "50 duels completed realm-wide", threshold: 50, counter: "rm_duels", reward: "Ornate Crate", rewardTier: "ornate", category: "combat" },
  { id: 30, name: "Party of Heroes", desc: "4+ player party defeats a boss", threshold: 1, counter: "rm_party_boss", reward: "Exquisite Crate", rewardTier: "exquisite", category: "combat" },

  // ─── Mastery & Endgame (4 new) ──────────────────
  { id: 31, name: "Full Bestiary", desc: "All 96 companions discovered", threshold: 96, counter: "rm_pets", reward: "Mythical Crate", rewardTier: "mythical", category: "mastery" },
  { id: 32, name: "Campfire Chronicles", desc: "25 campfire stories witnessed", threshold: 25, counter: "rm_stories", reward: "Ornate Crate", rewardTier: "ornate", category: "mastery" },
  { id: 33, name: "The Gilded Realm", desc: "5,000 Forever Coins earned", threshold: 5000, counter: "rm_coins", reward: "Exquisite Crate", rewardTier: "exquisite", category: "mastery" },
  { id: 34, name: "Eternal Legacy", desc: "Complete all other 31 milestones", threshold: 0, counter: "dynamic_all", reward: "Mythical Crate x3", rewardTier: "mythical", category: "mastery", dynamic: true, drBonus: 2.0 },
];

const CATEGORIES = [
  { id: "origins", name: "Origins", color: "§e", icon: "⚑" },
  { id: "social", name: "Social", color: "§d", icon: "❤" },
  { id: "guild", name: "Guild", color: "§2", icon: "⚔" },
  { id: "adventure", name: "Adventure", color: "§b", icon: "🗺" },
  { id: "combat", name: "Combat", color: "§c", icon: "⚔" },
  { id: "mastery", name: "Mastery", color: "§6", icon: "☄" },
];

export class MilestoneSystem {
  constructor(eventBridge) {
    this.eventBridge = eventBridge;

    // Standard counter events
    eventBridge.on("patron_killed", () => this.increment("rm_patrons"));
    eventBridge.on("biome_change", (player, biomeId) => this.onBiomeVisit(biomeId));
    eventBridge.on("companion_found", () => this.increment("rm_pets"));
    eventBridge.on("recipe_cooked", () => this.increment("rm_recipes"));
    eventBridge.on("lore_found", () => this.increment("rm_lore"));
    eventBridge.on("boss_killed", () => this.increment("rm_boss_kills"));
    eventBridge.on("mythical_found", () => this.increment("rm_mythicals"));
    eventBridge.on("quest_completed", () => this.increment("rm_quests"));

    // New counter events
    eventBridge.on("friend_made", () => this.increment("rm_friends"));
    eventBridge.on("friend_levelup", () => this.increment("rm_fr_levels"));
    eventBridge.on("marriage", () => this.increment("rm_marriages"));
    eventBridge.on("guild_created", () => this.increment("rm_guilds"));
    eventBridge.on("guild_war_declared", () => this.increment("rm_guild_wars"));
    eventBridge.on("guild_alliance", () => this.increment("rm_guild_alliances"));
    eventBridge.on("guild_war_won", (player, wins) => {
      const current = this.getCounter("rm_guild_max_wins");
      if (wins > current) this.setCounter("rm_guild_max_wins", wins);
      this.checkMilestones();
    });
    eventBridge.on("guild_contribution", (player, amount) => {
      const current = this.getCounter("rm_guild_contrib") + amount;
      this.setCounter("rm_guild_contrib", current);
      this.checkMilestones();
    });
    eventBridge.on("dream_complete", () => this.increment("rm_dreams"));
    eventBridge.on("bounty_complete", () => this.increment("rm_bounties"));
    eventBridge.on("duel_complete", () => this.increment("rm_duels"));
    eventBridge.on("campfire_story", () => this.increment("rm_stories"));
    eventBridge.on("coins_earned", (player, amount) => {
      const current = this.getCounter("rm_coins") + amount;
      this.setCounter("rm_coins", current);
      this.checkMilestones();
    });
    eventBridge.on("party_boss_kill", () => this.increment("rm_party_boss"));

    // Track unique players for dynamic scaling
    eventBridge.on("player_join", (player) => this.trackPlayer(player));
  }

  // ─── Storage helpers ────────────────────────────

  getCounter(key) {
    try { return Number(world.getDynamicProperty(`ms_${key}`)) || 0; } catch { return 0; }
  }
  setCounter(key, value) {
    try { world.setDynamicProperty(`ms_${key}`, value); } catch {}
  }
  isCompleted(milestoneId) {
    try { return world.getDynamicProperty(`ms_done_${milestoneId}`) === true; } catch { return false; }
  }
  markCompleted(milestoneId) {
    try { world.setDynamicProperty(`ms_done_${milestoneId}`, true); } catch {}
  }

  // ─── Player tracking for dynamic milestones ────

  trackPlayer(player) {
    const storage = StorageManager.forPlayer(player);
    if (storage.getNumber("rm_joined", 0) === 0) {
      storage.set("rm_joined", 1);
      const total = this.getCounter("rm_total_players") + 1;
      this.setCounter("rm_total_players", total);
    }
  }

  // ─── Counter increment ─────────────────────────

  increment(counterKey) {
    const current = this.getCounter(counterKey) + 1;
    this.setCounter(counterKey, current);
    this.checkMilestones();
  }

  onBiomeVisit(biomeId) {
    if (biomeId < 0 || biomeId > 24) return;
    const key = `rm_b${biomeId}`;
    if (this.getCounter(key) >= 1) return;
    this.setCounter(key, 1);
    const total = this.getCounter("rm_biomes") + 1;
    this.setCounter("rm_biomes", total);
    this.checkMilestones();
  }

  // ─── Milestone checking ────────────────────────

  checkMilestones() {
    for (const ms of MILESTONES) {
      if (this.isCompleted(ms.id)) continue;

      if (ms.dynamic) {
        this.checkDynamic(ms);
      } else {
        const value = this.getCounter(ms.counter);
        if (value >= ms.threshold) {
          this.completeMilestone(ms);
        }
      }
    }
  }

  checkDynamic(ms) {
    const players = world.getAllPlayers();
    if (players.length === 0) return;

    // Eternal Legacy — check all other milestones
    if (ms.id === 34) {
      const allDone = MILESTONES.filter(m => m.id !== 34).every(m => this.isCompleted(m.id));
      if (allDone) this.completeMilestone(ms);
      return;
    }

    const totalPlayers = Math.max(this.getCounter("rm_total_players"), players.length);
    const threshold = Math.max(2, Math.floor(totalPlayers * (ms.pctThreshold / 100)));

    let qualifying = 0;
    for (const player of players) {
      const storage = StorageManager.forPlayer(player);
      switch (ms.playerCheck) {
        case "friend_count_2":
          if (storage.getNumber("friend_count", 0) >= 2) qualifying++;
          break;
        case "biomes_15":
          if (storage.getNumber("biomes_visited", 0) >= 15) qualifying++;
          break;
        case "has_home":
          if (storage.getNumber("hs_tier", 0) >= 1) qualifying++;
          break;
        case "dr_20":
          if (storage.getNumber("dream_rate", 0) >= 20) qualifying++;
          break;
      }
    }

    if (qualifying >= threshold) {
      this.completeMilestone(ms);
    }
  }

  // ─── Completion ────────────────────────────────

  completeMilestone(ms) {
    this.markCompleted(ms.id);

    // Apply DR bonus if any
    if (ms.drBonus) {
      const currentBonus = this.getCounter("rm_dr_bonus");
      this.setCounter("rm_dr_bonus", currentBonus + Math.round(ms.drBonus * 10)); // stored as x10
    }

    const players = world.getAllPlayers();
    for (const player of players) {
      player.sendMessage("§6§l═══════════════════════════════════");
      player.sendMessage("§6§l  ✦ WORLD MILESTONE ACHIEVED ✦");
      player.sendMessage(`§e§o  ${ms.name}`);
      player.sendMessage(`§7  ${ms.desc}`);
      player.sendMessage(`§7  Reward: §a${ms.reward}`);
      if (ms.drBonus) {
        player.sendMessage(`§7  Permanent Realm Bonus: §a+${ms.drBonus} Dream Rate`);
      }
      player.sendMessage("§6§l═══════════════════════════════════");

      try {
        player.playSound("random.totem", { volume: 1.0, pitch: 1.0 });
        player.playSound("firework.twinkle", { volume: 0.8, pitch: 1.2 });
        const loc = player.location;
        player.dimension.runCommandAsync(
          `summon minecraft:fireworks_rocket ${loc.x} ${loc.y + 1} ${loc.z}`
        );
      } catch {}

      // Give reward crate(s)
      this.eventBridge.emit("crate_give", player, ms.rewardTier);
      // Floor 100 / Eternal Legacy — give 3 mythical crates
      if (ms.id === 34) {
        this.eventBridge.emit("crate_give", player, "mythical");
        this.eventBridge.emit("crate_give", player, "mythical");
      }

      this.eventBridge.emit("milestone_reward", player, ms.rewardTier);
    }
  }

  /**
   * Get the total DR bonus from completed milestones.
   */
  getDRBonus() {
    return this.getCounter("rm_dr_bonus") / 10;
  }

  // ─── Tick (every 60s) ──────────────────────────

  tick() {
    this.checkMilestones();
  }

  // ─── GUI ───────────────────────────────────────

  openMenu(player) {
    const form = new ActionFormData()
      .title("§6⚑ World Milestones")
      .body(this.buildSummary());

    for (const cat of CATEGORIES) {
      const catMilestones = MILESTONES.filter(m => m.category === cat.id);
      const done = catMilestones.filter(m => this.isCompleted(m.id)).length;
      form.button(`${cat.color}${cat.icon} ${cat.name} §7(${done}/${catMilestones.length})`);
    }
    form.button("§7Close");

    form.show(player).then((r) => {
      if (r.canceled || r.selection === CATEGORIES.length) return;
      this.showCategory(player, CATEGORIES[r.selection].id);
    });
  }

  buildSummary() {
    const totalDone = MILESTONES.filter(m => this.isCompleted(m.id)).length;
    const drBonus = this.getDRBonus();
    return (
      `§7Server-wide cooperative achievements\n` +
      `§7Progress: §f${totalDone}§7/§f${MILESTONES.length}\n` +
      `§7Realm DR Bonus: §a+${drBonus.toFixed(2)}\n\n` +
      `§7Select a category to view details.`
    );
  }

  showCategory(player, categoryId) {
    const cat = CATEGORIES.find(c => c.id === categoryId);
    const catMilestones = MILESTONES.filter(m => m.category === categoryId);

    let body = `${cat.color}§l${cat.icon} ${cat.name}\n\n`;

    for (const ms of catMilestones) {
      const done = this.isCompleted(ms.id);
      if (done) {
        body += `§a✔ §e${ms.name}\n`;
        body += `  §7${ms.desc} §8(Complete)\n`;
      } else {
        if (ms.dynamic) {
          body += `§8☐ §f${ms.name}\n`;
          body += `  §7${ms.desc}\n`;
        } else {
          const value = this.getCounter(ms.counter);
          body += `§8☐ §f${ms.name}\n`;
          body += `  §7${ms.desc} §f(${value}/${ms.threshold})\n`;
        }
      }
      if (ms.drBonus) {
        body += `  §aRealm bonus: +${ms.drBonus} DR\n`;
      }
    }

    const form = new ActionFormData()
      .title(`§6${cat.name} Milestones`)
      .body(body)
      .button("§7← Back");

    form.show(player).then((r) => {
      if (!r.canceled) this.openMenu(player);
    });
  }
}
