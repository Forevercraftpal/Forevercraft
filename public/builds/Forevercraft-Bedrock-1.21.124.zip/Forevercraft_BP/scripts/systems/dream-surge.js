/**
 * Dream Surge — Operator-triggered global event (+25% DR boost).
 * Replaces Java event/ folder (7 mcfunction files).
 *
 * Admin activates via scriptevent. All players get +25% DR multiplier.
 * Duration: configurable (default 10 minutes). Particles + atmosphere.
 */
import { world, system } from "@minecraft/server";
import { StorageManager } from "../utils/storage.js";

const DEFAULT_DURATION = 12000; // 10 min in ticks
const DR_MULTIPLIER = 0.25;    // +25%

export class DreamSurgeSystem {
  constructor(eventBridge) {
    this.eventBridge = eventBridge;
    this.active = false;
    this.timer = 0;
  }

  /** Activate dream surge (operator command) */
  activate(duration = DEFAULT_DURATION) {
    if (this.active) return;
    this.active = true;
    this.timer = duration;

    for (const p of world.getAllPlayers()) {
      p.sendMessage("\n§d§l✦ ✦ ✦ DREAM SURGE ✦ ✦ ✦§r");
      p.sendMessage("§7The dream realm pulses with energy!");
      p.sendMessage("§d+25% Dream Rate §7for all players!");
      p.onScreenDisplay.setTitle("§d§lDREAM SURGE", {
        subtitle: "§7+25% Dream Rate for everyone!",
        fadeInDuration: 10, stayDuration: 80, fadeOutDuration: 20,
      });
      p.playSound("ui.toast.challenge_complete", { volume: 1.5, pitch: 0.6 });
    }

    this.eventBridge.emit("dream_surge_started");
  }

  /** End the surge */
  deactivate() {
    if (!this.active) return;
    this.active = false;
    this.timer = 0;

    for (const p of world.getAllPlayers()) {
      p.sendMessage("§8The Dream Surge has ended.");
    }

    this.eventBridge.emit("dream_surge_ended");
  }

  /** Tick — apply DR boost + particles (called every 60 ticks) */
  tick(players) {
    if (!this.active) return;
    this.timer -= 60;

    if (this.timer <= 0) {
      this.deactivate();
      return;
    }

    for (const player of players) {
      // Apply temporary DR boost via luck effect
      try { player.addEffect("luck", 80, { amplifier: 1, showParticles: false }); } catch {}

      // Ambient particles
      try {
        player.dimension.spawnParticle("minecraft:endrod", {
          x: player.location.x + (Math.random() - 0.5) * 6,
          y: player.location.y + 2 + Math.random() * 2,
          z: player.location.z + (Math.random() - 0.5) * 6,
        });
      } catch {}
    }

    // Time warnings
    const secsLeft = Math.ceil(this.timer / 20);
    if (this.timer === 2400) { // 2 min
      for (const p of players) p.sendMessage("§d§oSurge fading in 2 minutes...");
    }
    if (this.timer === 600) { // 30s
      for (const p of players) p.sendMessage("§d§oSurge ending in 30 seconds...");
    }
  }

  /** Check if surge is active (for DR calculation multiplier) */
  isActive() { return this.active; }
  getMultiplier() { return this.active ? DR_MULTIPLIER : 0; }
}
