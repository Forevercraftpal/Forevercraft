/**
 * Career Stats Display — Shows 7 sections of player statistics on demand.
 * Sections: Time/Distance, Combat, Gathering, Crates, Progress, Companions, Economy.
 * Replaces Java stats/ folder (8 files).
 */
import { StorageManager } from "../utils/storage.js";
import { ActionFormData } from "@minecraft/server-ui";

export class StatsSystem {
  constructor(eventBridge) {
    this.eventBridge = eventBridge;
  }

  openMenu(player) {
    const form = new ActionFormData()
      .title("§6⊞ Career Stats")
      .body("§7Choose a stat category to view.")
      .button("§eTime & Distance")
      .button("§cCombat")
      .button("§aGathering")
      .button("§bCrates")
      .button("§dProgress")
      .button("§5Companions")
      .button("§6Economy")
      .button("§7Close");

    form.show(player).then((r) => {
      if (r.canceled || r.selection === 7) return;
      switch (r.selection) {
        case 0: this.showTimeDistance(player); break;
        case 1: this.showCombat(player); break;
        case 2: this.showGathering(player); break;
        case 3: this.showCrates(player); break;
        case 4: this.showProgress(player); break;
        case 5: this.showCompanions(player); break;
        case 6: this.showEconomy(player); break;
      }
    });
  }

  _show(player, title, body) {
    const form = new ActionFormData()
      .title(title)
      .body(body)
      .button("§7← Back");

    form.show(player).then((r) => {
      if (!r.canceled) this.openMenu(player);
    });
  }

  showTimeDistance(player) {
    const s = StorageManager.forPlayer(player);
    const playTicks = s.getNumber("adj_play", 0);
    const hours = Math.floor(playTicks / 72000);
    const walkUnits = s.getNumber("adj_walk", 0);
    const km = (walkUnits / 100000).toFixed(1);
    const deaths = s.getNumber("deaths", 0);
    const jumps = s.getNumber("adj_jump", 0);
    const biomes = s.getNumber("biomes_visited", 0);
    const structures = s.getNumber("structures_found", 0);

    let body = "§6§lTime & Distance\n\n";
    body += `§7Playtime: §f${hours} hours\n`;
    body += `§7Distance: §f${km} km\n`;
    body += `§7Deaths: §f${deaths}\n`;
    body += `§7Jumps: §f${jumps}\n`;
    body += `§7Biomes: §f${biomes}/25\n`;
    body += `§7Structures: §f${structures}\n`;

    this._show(player, "§e⏱ Time & Distance", body);
  }

  showCombat(player) {
    const s = StorageManager.forPlayer(player);
    let body = "§c§lCombat\n\n";
    body += `§7Mobs Slain: §f${s.getNumber("stat_mobs", 0)}\n`;
    body += `§7Patron Kills: §f${s.getNumber("patron_kills", 0)}\n`;
    body += `§7Weapon Abilities: §f${s.getNumber("weapon_abilities", 0)}\n`;
    body += `§7Dodges: §f${s.getNumber("dodge_count", 0)}\n`;
    body += `§7Dungeons Cleared: §f${s.getNumber("dungeons_done", 0)}\n`;
    const bestTime = s.getNumber("best_dungeon_time", 0);
    body += `§7Best Dungeon Time: §f${bestTime > 0 ? bestTime + "s" : "N/A"}\n`;
    const castleBest = s.getNumber("castle_best_floor", 0);
    body += `§7Castle Best Floor: §f${castleBest > 0 ? castleBest : "N/A"}\n`;
    body += `§7Bounties Done: §f${s.getNumber("bounties_done", 0)}\n`;
    body += `§7Duels Won: §f${s.getNumber("duels_won", 0)}\n`;

    this._show(player, "§c⚔ Combat", body);
  }

  showGathering(player) {
    const s = StorageManager.forPlayer(player);
    let body = "§a§lGathering\n\n";
    body += `§7Blocks Mined: §f${s.getNumber("blocks_mined", 0)}\n`;
    body += `§7Fish Caught: §f${s.getNumber("fish_caught", 0)}\n`;
    body += `§7Crops Harvested: §f${s.getNumber("crops_harvested", 0)}\n`;
    body += `§7Items Smelted: §f${s.getNumber("stat_smelt", 0)}\n`;
    body += `§7Prospects Mined: §f${s.getNumber("prospects_done", 0)}\n`;
    body += `§7Bushes Foraged: §f${s.getNumber("forages_done", 0)}\n`;

    this._show(player, "§a⛏ Gathering", body);
  }

  showCrates(player) {
    const s = StorageManager.forPlayer(player);
    let body = "§b§lCrates\n\n";
    body += `§7Total Opened: §f${s.getNumber("crates_opened", 0)}\n`;
    body += `§7Mining Crates: §f${s.getNumber("crates_mining", 0)}\n`;
    body += `§7Fishing Crates: §f${s.getNumber("crates_fishing", 0)}\n`;
    body += `§7Harvest Crates: §f${s.getNumber("crates_harvest", 0)}\n`;
    body += `§7Mob Crates: §f${s.getNumber("crates_mob", 0)}\n`;
    body += `§7Structure Crates: §f${s.getNumber("crates_structure", 0)}\n`;
    body += `§7Companion Crates: §f${s.getNumber("crates_companion", 0)}\n`;
    body += `§7Artifact Crates: §f${s.getNumber("crates_artifact", 0)}\n`;

    this._show(player, "§b📦 Crates", body);
  }

  showProgress(player) {
    const s = StorageManager.forPlayer(player);
    let body = "§d§lProgress\n\n";
    body += `§7Artifacts: §f${s.getNumber("artifacts_collected", 0)}/408\n`;
    body += `§7Achievements: §f${s.getNumber("achievements_total", 0)}\n`;
    body += `§7Advantage Trees: §f${s.getNumber("trees_unlocked", 0)}/13\n`;
    body += `§7Total Levels: §f${s.getNumber("total_levels", 0)}\n`;
    body += `§7Quests Done: §f${s.getNumber("quests_done", 0)}\n`;
    body += `§7Armor Sets: §f${s.getNumber("sets_equipped", 0)}/27\n`;
    body += `§7Lore Collected: §f${s.getNumber("lore_collected", 0)}\n`;

    this._show(player, "§d📊 Progress", body);
  }

  showCompanions(player) {
    const s = StorageManager.forPlayer(player);
    let body = "§5§lCompanions\n\n";
    body += `§7Pets Adopted: §f${s.getNumber("comp_owned", 0)}\n`;
    body += `§7Pets Bonded: §f${s.getNumber("comp_bonded", 0)}\n`;
    body += `§7Pets Eternal: §f${s.getNumber("comp_eternal", 0)}\n`;
    body += `§7Interactions: §f${s.getNumber("comp_interacts", 0)}\n`;

    this._show(player, "§5🐾 Companions", body);
  }

  showEconomy(player) {
    const s = StorageManager.forPlayer(player);
    let body = "§6§lEconomy\n\n";
    body += `§7Trades: §f${s.getNumber("adj_trade", 0)}\n`;
    body += `§7Meals Cooked: §f${s.getNumber("meals_cooked", 0)}\n`;
    body += `§7Transmutations: §f${s.getNumber("transmutes_done", 0)}\n`;
    body += `§7Forever Coins: §f${s.getNumber("coins", 0)}\n`;
    body += `§7Coins Earned (Total): §f${s.getNumber("coins_earned_total", 0)}\n`;
    body += `§7Guild Donations: §f${s.getNumber("guild_donated", 0)}\n`;

    this._show(player, "§6💰 Economy", body);
  }
}
