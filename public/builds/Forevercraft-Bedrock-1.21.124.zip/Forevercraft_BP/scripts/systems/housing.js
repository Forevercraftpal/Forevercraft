/**
 * Housing System — 5-tier homes with garden growth, comfort/decoration scoring,
 * home zone buffs, and stash storage.
 * Replaces Java housing/ folder.
 */
import { world, system } from "@minecraft/server";
import { StorageManager } from "../utils/storage.js";
import { ActionFormData } from "@minecraft/server-ui";

// ─── TIER DEFINITIONS ───────────────────────────────────────
const TIERS = [
  null, // index 0 unused
  { name: "Settler", cost: 0, buffs: ["regeneration"], gardenAttempts: 0 },
  { name: "Homestead", cost: 16, buffs: ["regeneration", "saturation"], gardenAttempts: 0 },
  { name: "Estate", cost: 32, buffs: ["regeneration", "saturation", "dr_0.5"], gardenAttempts: 2 },
  { name: "Manor", cost: 64, buffs: ["regeneration", "saturation", "dr_0.5", "fire_resistance"], gardenAttempts: 2 },
  { name: "Sanctuary", cost: 128, buffs: ["regeneration", "saturation", "dr_1.0", "fire_resistance", "resistance"], gardenAttempts: 4 },
];

const ZONE_RADIUS = 64;
const HEARTHSTONE_COOLDOWN = 12000; // 10 minutes (600 seconds)

// Comfort milestones
const COMFORT_RANKS = [
  { score: 100, title: "Budding Decorator", color: "§7" },
  { score: 500, title: "Novice Decorator", color: "§a" },
  { score: 1000, title: "Interior Designer", color: "§b" },
  { score: 2500, title: "Master Architect", color: "§6" },
  { score: 5000, title: "Legendary Builder", color: "§d" },
];

// Decorative block types that count for comfort
const DECORATIVE_BLOCKS = new Set([
  "lantern", "soul_lantern", "chain", "bell", "campfire", "soul_campfire",
  "bookshelf", "enchanting_table", "anvil", "cauldron", "barrel",
  "furnace", "blast_furnace", "smoker", "composter", "loom",
  "cartography_table", "smithing_table", "fletching_table", "stonecutter",
  "grindstone", "decorated_pot", "moss_block", "beacon", "conduit",
  "lodestone", "end_rod", "lightning_rod", "shroomlight", "glowstone",
  "sea_lantern", "honey_block", "honeycomb_block", "hay_block",
  "carved_pumpkin", "amethyst_block",
]);

// Block type prefixes that count
const DECORATIVE_PREFIXES = [
  "flower", "potted_", "banner", "candle", "wool", "carpet",
  "terracotta", "glazed_terracotta", "stained_glass", "glass_pane",
  "stairs", "slab", "fence", "wall", "sign", "hanging_sign",
  "leaves", "head", "skull",
];

export class HousingSystem {
  constructor() {
    // No event bridge dependencies
  }

  // ─── HOME ZONE DETECTION ──────────────────────────────────

  isInHomeZone(player) {
    const s = StorageManager.forPlayer(player);
    if (!s.getBool("has_home")) return false;

    const homeX = s.getNumber("home_x", 0);
    const homeY = s.getNumber("home_y", 0);
    const homeZ = s.getNumber("home_z", 0);
    const homeDim = s.getString("home_dim", "");

    if (player.dimension.id !== homeDim) return false;

    const loc = player.location;
    return (
      Math.abs(loc.x - homeX) <= ZONE_RADIUS &&
      Math.abs(loc.y - homeY) <= ZONE_RADIUS &&
      Math.abs(loc.z - homeZ) <= ZONE_RADIUS
    );
  }

  // ─── HOME ZONE BUFFS ─────────────────────────────────────

  applyZoneBuffs(player) {
    const s = StorageManager.forPlayer(player);
    const tier = s.getNumber("home_tier", 1);
    const tierDef = TIERS[tier];
    if (!tierDef) return;

    const inZone = this.isInHomeZone(player);
    const wasInZone = player.hasTag("ec.in_home");

    if (inZone && !wasInZone) {
      player.addTag("ec.in_home");
      player.sendMessage("§6§l🏠 §r§7Home Zone");
    } else if (!inZone && wasInZone) {
      player.removeTag("ec.in_home");
      player.sendMessage("§7🏠 Left Home Zone");
      return;
    }

    if (!inZone) return;

    // Apply tier buffs
    for (const buff of tierDef.buffs) {
      try {
        if (buff === "regeneration") player.runCommandAsync("effect @s regeneration 5 0 true");
        else if (buff === "saturation") player.runCommandAsync("effect @s saturation 5 0 true");
        else if (buff === "fire_resistance") player.runCommandAsync("effect @s fire_resistance 5 0 true");
        else if (buff === "resistance") player.runCommandAsync("effect @s resistance 5 0 true");
        // DR buffs handled via luck effect
        else if (buff.startsWith("dr_")) {
          const drLevel = buff === "dr_1.0" ? 1 : 0;
          player.runCommandAsync(`effect @s luck 5 ${drLevel} true`);
        }
      } catch {}
    }
  }

  // ─── GARDEN GROWTH (Tier 3+) ──────────────────────────────

  tickGarden(player) {
    const s = StorageManager.forPlayer(player);
    const tier = s.getNumber("home_tier", 1);
    if (tier < 3) return;
    if (!s.getBool("has_home")) return;

    const tierDef = TIERS[tier];
    const attempts = tierDef.gardenAttempts;

    const homeX = s.getNumber("home_x", 0);
    const homeY = s.getNumber("home_y", 0);
    const homeZ = s.getNumber("home_z", 0);
    const dim = player.dimension;

    for (let i = 0; i < attempts; i++) {
      const ox = homeX + Math.floor(Math.random() * 128) - 64;
      const oz = homeZ + Math.floor(Math.random() * 128) - 64;

      // Try to grow crops at this position
      try {
        const crops = [
          { block: "wheat", stateKey: "growth", max: 7 },
          { block: "carrots", stateKey: "growth", max: 7 },
          { block: "potatoes", stateKey: "growth", max: 7 },
          { block: "beetroot", stateKey: "growth", max: 3 },
          { block: "nether_wart", stateKey: "age", max: 3 },
          { block: "sweet_berry_bush", stateKey: "growth", max: 3 },
        ];

        for (const crop of crops) {
          // Check a few Y levels around home height
          for (let dy = -3; dy <= 3; dy++) {
            try {
              const block = dim.getBlock({ x: ox, y: homeY + dy, z: oz });
              if (block && block.typeId === `minecraft:${crop.block}`) {
                const states = block.permutation.getAllStates();
                const currentAge = states[crop.stateKey] ?? 0;
                if (currentAge < crop.max) {
                  dim.runCommandAsync(
                    `setblock ${ox} ${homeY + dy} ${oz} ${crop.block} ["${crop.stateKey}"=${currentAge + 1}]`
                  );
                  break; // Only grow one crop per attempt
                }
              }
            } catch {}
          }
        }
      } catch {}
    }
  }

  // ─── COMFORT / DECORATION ────────────────────────────────

  onBlockPlaced(player, block) {
    if (!this.isInHomeZone(player)) return;

    const typeId = (block.typeId || "").replace("minecraft:", "");
    const isDecorative = DECORATIVE_BLOCKS.has(typeId) ||
      DECORATIVE_PREFIXES.some(p => typeId.includes(p));

    if (!isDecorative) return;

    const s = StorageManager.forPlayer(player);
    const score = s.getNumber("hs_decor", 0) + 1;
    s.set("hs_decor", score);

    // Check milestones
    for (const rank of COMFORT_RANKS) {
      if (score === rank.score) {
        player.sendMessage(`${rank.color}§l✦ Comfort Rank: ${rank.title}!`);
        player.playSound("random.orb");
      }
    }

    // Subtle chime every 10 blocks
    if (score % 10 === 0) {
      player.playSound("note.chime");
    }
  }

  getComfortRank(score) {
    for (let i = COMFORT_RANKS.length - 1; i >= 0; i--) {
      if (score >= COMFORT_RANKS[i].score) return COMFORT_RANKS[i];
    }
    return { title: "None", color: "§7" };
  }

  // ─── UPGRADE ──────────────────────────────────────────────

  tryUpgrade(player) {
    const s = StorageManager.forPlayer(player);
    const tier = s.getNumber("home_tier", 1);

    if (tier >= 5) {
      player.sendMessage("§dYour home is at maximum tier!");
      return;
    }

    const nextTier = TIERS[tier + 1];
    const cost = nextTier.cost;

    // Check netherite ingots
    const inv = player.getComponent("minecraft:inventory");
    if (!inv) return;
    const container = inv.container;
    let count = 0;
    for (let i = 0; i < container.size; i++) {
      const item = container.getItem(i);
      if (item && item.typeId === "minecraft:netherite_ingot") {
        count += item.amount;
      }
    }

    if (count < cost) {
      player.sendMessage(`§cNeed §f${cost} §cNetherite Ingots (have §f${count}§c)`);
      return;
    }

    // Consume and upgrade
    try { player.runCommandAsync(`clear @s netherite_ingot 0 ${cost}`); } catch {}
    s.set("home_tier", tier + 1);
    player.sendMessage(`§6§l✦ Home Upgraded: ${nextTier.name}! §r§7(Tier ${tier + 1})`);
    player.playSound("random.levelup");
  }

  // ─── GUI ──────────────────────────────────────────────────

  openMenu(player) {
    const s = StorageManager.forPlayer(player);
    const hasHome = s.getBool("has_home");
    const tier = s.getNumber("home_tier", 1);
    const decor = s.getNumber("hs_decor", 0);
    const comfortRank = this.getComfortRank(decor);

    let body = "";
    if (hasHome) {
      const tierDef = TIERS[tier];
      body = `§7Tier: §f${tier} §7(${tierDef.name})\n`;
      body += `§7Comfort: ${comfortRank.color}${comfortRank.title} §7(${decor} decorations)\n`;
      body += `§7Zone: §f${ZONE_RADIUS}×${ZONE_RADIUS} blocks\n`;
      if (tier >= 3) body += `§7Garden: §aActive §7(${tierDef.gardenAttempts} growth/tick)\n`;
    } else {
      body = "§7Place a Lodestone to establish your home!";
    }

    const form = new ActionFormData()
      .title("§6🏠 Hearthstone")
      .body(body)
      .button(hasHome ? "§aTeleport Home" : "§7(No home set)")
      .button("§6Upgrade Home")
      .button("§eStash")
      .button("§dSet Home Location")
      .button("§7Close");

    form.show(player).then(response => {
      if (response.canceled) return;
      switch (response.selection) {
        case 0:
          if (hasHome) this.teleportHome(player);
          break;
        case 1:
          if (hasHome) this.tryUpgrade(player);
          else player.sendMessage("§7Set a home first!");
          break;
        case 2:
          this.openStash(player);
          break;
        case 3:
          this.setHome(player);
          break;
      }
    });
  }

  setHome(player) {
    const s = StorageManager.forPlayer(player);
    const loc = player.location;
    s.set("home_x", Math.floor(loc.x));
    s.set("home_y", Math.floor(loc.y));
    s.set("home_z", Math.floor(loc.z));
    s.set("home_dim", player.dimension.id);
    s.set("has_home", true);
    if (!s.getNumber("home_tier")) s.set("home_tier", 1);
    player.sendMessage(`§a§l✦ §r§7Home set at §e${Math.floor(loc.x)}, ${Math.floor(loc.y)}, ${Math.floor(loc.z)}`);
  }

  teleportHome(player) {
    const s = StorageManager.forPlayer(player);
    if (!s.getBool("has_home")) return;
    const dimId = s.getString("home_dim", "minecraft:overworld").replace("minecraft:", "");
    try {
      const dim = world.getDimension(dimId);
      player.teleport(
        { x: s.getNumber("home_x"), y: s.getNumber("home_y") + 1, z: s.getNumber("home_z") },
        { dimension: dim }
      );
      player.sendMessage("§a§l✦ §r§7Welcome home!");
      player.playSound("mob.endermen.portal");
    } catch {}
  }

  openStash(player) {
    const s = StorageManager.forPlayer(player);
    const form = new ActionFormData()
      .title("§eStash")
      .body("§7Store items for safekeeping.");

    for (let i = 0; i < 9; i++) {
      const item = s.getString(`stash_${i}`, "");
      form.button(item ? `§eSlot ${i + 1}: §f${item}` : `§7Slot ${i + 1}: Empty`);
    }
    form.button("§7← Back");

    form.show(player).then(response => {
      if (response.canceled || response.selection === 9) return;
    });
  }

  // ─── TICK (called every 2 seconds) ────────────────────────

  tick(players) {
    for (const player of players) {
      this.applyZoneBuffs(player);
      this.tickGarden(player);
    }
  }

  // ─── HEARTHSTONE PLACEMENT ──────────────────────────────────

  /** Place hearthstone at player's current location — claims home */
  placeHearthstone(player, guidestoneSystem) {
    const s = StorageManager.forPlayer(player);

    if (s.getBool("has_home")) {
      player.sendMessage("§cYou already have a Hearthstone! Break it first to relocate.");
      return;
    }

    const loc = player.location;
    s.setBool("has_home", true);
    s.setNumber("home_x", Math.floor(loc.x));
    s.setNumber("home_y", Math.floor(loc.y));
    s.setNumber("home_z", Math.floor(loc.z));
    s.set("home_dim", player.dimension.id);
    s.setNumber("home_tier", 1);

    // Auto-register in guidestone network for fast travel
    if (guidestoneSystem) {
      guidestoneSystem.register(player, "🏠 Home");
      s.setNumber("home_gs_index", JSON.parse(s.getString("guidestones", "[]")).length - 1);
    }

    player.sendMessage("\n§6§l✦ Hearthstone Placed! ✦§r");
    player.sendMessage("§7Your home is now claimed. §eTier 1: Settler");
    player.sendMessage("§7Regeneration I while in your 64-block zone.");
    player.playSound("block.beacon.activate", { volume: 0.5, pitch: 1.2 });
    try { player.dimension.spawnParticle("minecraft:basic_flame_particle", loc); } catch {}
  }

  /** Teleport home (hearthstone warp) — 60s cooldown */
  async warpHome(player) {
    const s = StorageManager.forPlayer(player);
    if (!s.getBool("has_home")) {
      player.sendMessage("§cYou don't have a home! Place a Hearthstone first.");
      return;
    }

    // Cooldown check
    const lastWarp = s.getNumber("home_warp_cd", 0);
    const now = system.currentTick;
    if (now - lastWarp < HEARTHSTONE_COOLDOWN) {
      const remaining = Math.ceil((HEARTHSTONE_COOLDOWN - (now - lastWarp)) / 20);
      player.sendMessage(`§cHearthstone on cooldown! §7${remaining}s remaining.`);
      return;
    }

    const homeX = s.getNumber("home_x", 0);
    const homeY = s.getNumber("home_y", 0);
    const homeZ = s.getNumber("home_z", 0);
    const homeDim = s.getString("home_dim", "");

    // Cross-dimension check
    if (player.dimension.id !== homeDim) {
      player.sendMessage("§cCan't warp home from another dimension!");
      return;
    }

    s.setNumber("home_warp_cd", now);
    player.teleport({ x: homeX + 0.5, y: homeY, z: homeZ + 0.5 });
    player.sendMessage("§6§l🏠 §r§7Welcome home!");
    player.playSound("mob.endermen.portal", { volume: 0.8, pitch: 1.2 });
    try { player.dimension.spawnParticle("minecraft:endrod", player.location); } catch {}
  }

  /** Break hearthstone — removes home claim */
  breakHearthstone(player) {
    const s = StorageManager.forPlayer(player);
    s.setBool("has_home", false);
    s.setNumber("home_tier", 0);
    player.removeTag("ec.in_home");
    player.sendMessage("§c§l✦ §r§7Hearthstone broken. Your home claim is removed.");
  }
}
