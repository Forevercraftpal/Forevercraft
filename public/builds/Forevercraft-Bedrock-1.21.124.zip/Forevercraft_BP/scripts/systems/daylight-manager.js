import { world } from "@minecraft/server";
import { CONSTANTS } from "../main.js";
import { StorageManager } from "../utils/storage.js";

export class DaylightManager {
  constructor() {
    this.counter = 0;
    this.sleepWait = 0;
    this.sleepPoll = 0;
    this.sleepSkipCooldown = 0;
    const storage = StorageManager.world();
    this.currentTime = storage.getNumber("daylight_time", 0);
    this.currentDay = storage.getNumber("daylight_day", 0);
    this.storage = storage;
  }

  tick() {
    this.counter++;
    if (this.counter >= CONSTANTS.DAYLIGHT_ADVANCE_INTERVAL) {
      this.counter = 0;
      this.advanceTime();
    }
    if (this.sleepSkipCooldown > 0) this.sleepSkipCooldown--;
    this.sleepPoll++;
    if (this.sleepPoll >= CONSTANTS.SLEEP_POLL_INTERVAL) {
      this.sleepPoll = 0;
      this.checkSleep();
    }
    if (this.sleepWait >= CONSTANTS.SLEEP_THRESHOLD_TICKS) {
      this.doSleepSkip();
    }
  }

  advanceTime() {
    this.currentTime++;
    if (this.currentTime >= CONSTANTS.TICKS_PER_DAY_CYCLE) {
      this.currentTime = 0;
      this.currentDay++;
      this.onDayChange();
    }
    world.getDimension("overworld").runCommandAsync(`time set ${this.currentTime}`);
    if (this.currentTime % 100 === 0) {
      this.storage.set("daylight_time", this.currentTime);
      this.storage.set("daylight_day", this.currentDay);
    }
  }

  checkSleep() {
    if (this.sleepSkipCooldown > 0) return;
    const players = world.getAllPlayers();
    if (players.length === 0) return;
    const allSleeping = players.every(p => { try { return p.isSleeping; } catch { return false; } });
    if (allSleeping) { this.sleepWait += CONSTANTS.SLEEP_POLL_INTERVAL; } else { this.sleepWait = 0; }
  }

  doSleepSkip() {
    this.sleepWait = 0;
    this.sleepSkipCooldown = 100;
    this.currentTime = 0;
    this.currentDay++;
    this.onDayChange();
    world.getDimension("overworld").runCommandAsync("time set 0");
    this.storage.set("daylight_time", this.currentTime);
    this.storage.set("daylight_day", this.currentDay);
    for (const player of world.getAllPlayers()) { player.sendMessage("§eThe night has passed..."); }
  }

  onDayChange() {
    const moonPhase = this.currentDay % CONSTANTS.MOON_PHASES;
    this.storage.set("moon_phase", moonPhase);
    this.storage.set("daylight_day", this.currentDay);
    console.log(`[Forevercraft] Day ${this.currentDay}, Moon Phase ${moonPhase}`);
  }

  getTime() { return this.currentTime; }
  getDay() { return this.currentDay; }
  getMoonPhase() { return this.currentDay % CONSTANTS.MOON_PHASES; }
}
