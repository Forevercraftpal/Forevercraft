/**
 * Pantry System — Portable cooking ingredient storage.
 * Replaces Java pantry/ folder (26 files).
 *
 * 27-slot personal storage (3 pages × 9 slots) for cooking ingredients,
 * utensils, and prepared meals. Form-based UI.
 */
import { world, system } from "@minecraft/server";
import { StorageManager } from "../utils/storage.js";
import { ActionFormData } from "@minecraft/server-ui";

const TOTAL_SLOTS = 27;
const SLOTS_PER_PAGE = 9;
const TOTAL_PAGES = 3;

// Items accepted by pantry (cooking-related)
const PANTRY_TAGS = ["forevercraft:ingredient", "forevercraft:cooking_utensil", "forevercraft:meal", "ec_meal"];

// Common cooking ingredients by typeId
const COOKING_ITEMS = new Set([
  "minecraft:wheat", "minecraft:sugar", "minecraft:egg", "minecraft:milk_bucket",
  "minecraft:cocoa_beans", "minecraft:apple", "minecraft:melon_slice",
  "minecraft:sweet_berries", "minecraft:glow_berries", "minecraft:honey_bottle",
  "minecraft:pumpkin", "minecraft:carrot", "minecraft:potato", "minecraft:beetroot",
  "minecraft:mushroom_stew", "minecraft:rabbit_stew", "minecraft:suspicious_stew",
  "minecraft:bread", "minecraft:cookie", "minecraft:cake", "minecraft:pumpkin_pie",
  "minecraft:golden_apple", "minecraft:golden_carrot", "minecraft:cooked_beef",
  "minecraft:cooked_porkchop", "minecraft:cooked_chicken", "minecraft:cooked_mutton",
  "minecraft:cooked_rabbit", "minecraft:cooked_cod", "minecraft:cooked_salmon",
  "minecraft:dried_kelp", "minecraft:baked_potato",
  "minecraft:beef", "minecraft:porkchop", "minecraft:chicken", "minecraft:mutton",
  "minecraft:rabbit", "minecraft:cod", "minecraft:salmon",
  "minecraft:brown_mushroom", "minecraft:red_mushroom", "minecraft:sugar_cane",
  "minecraft:kelp", "minecraft:bamboo", "minecraft:chorus_fruit",
]);

export class PantrySystem {
  constructor(eventBridge) {
    this.eventBridge = eventBridge;

    // Detect pantry item use
    eventBridge.on("item_use", (player, item) => {
      if (!item) return;
      const tags = item.getTags?.() || [];
      if (tags.some(t => t.includes("pantry")) || item.typeId?.includes("pantry")) {
        this.openPantryMenu(player);
      }
    });
  }

  // ─── STORAGE ACCESS ────────────────────────────────────────

  getPantryData(player) {
    const s = StorageManager.forPlayer(player);
    try {
      const data = s.get("pantry_data");
      return data ? JSON.parse(data) : {};
    } catch { return {}; }
  }

  setPantryData(player, data) {
    StorageManager.forPlayer(player).set("pantry_data", JSON.stringify(data));
  }

  getSlot(player, slot) {
    const data = this.getPantryData(player);
    return data[slot] || null;
  }

  setSlot(player, slot, item) {
    const data = this.getPantryData(player);
    if (item) data[slot] = item;
    else delete data[slot];
    this.setPantryData(player, data);
  }

  /** Check if an item is pantry-compatible */
  isPantryItem(item) {
    if (!item) return false;
    const tags = item.getTags?.() || [];
    if (tags.some(t => PANTRY_TAGS.some(pt => t.includes(pt)))) return true;
    if (COOKING_ITEMS.has(item.typeId)) return true;
    if (item.typeId?.startsWith("forevercraft:") && (
      item.typeId.includes("ingredient") || item.typeId.includes("meal") || item.typeId.includes("utensil")
    )) return true;
    return false;
  }

  // ─── MENU ──────────────────────────────────────────────────

  openPantryMenu(player, page) {
    if (page === undefined) page = 0;
    page = Math.max(0, Math.min(page, TOTAL_PAGES - 1));

    const startSlot = page * SLOTS_PER_PAGE;
    const data = this.getPantryData(player);

    let body = `§7Pantry Storage §f(Page ${page + 1}/${TOTAL_PAGES})\n`;
    body += "§7Hold a cooking item and select a slot to store.\n";
    body += "§7Select an occupied slot to retrieve.\n\n";

    const form = new ActionFormData()
      .title(`§6🍳 Pantry — Page ${page + 1}`)
      .body(body);

    // Slot buttons
    for (let i = 0; i < SLOTS_PER_PAGE; i++) {
      const slot = startSlot + i;
      const item = data[slot];
      if (item) {
        form.button(`§eSlot ${slot + 1}\n§f${item.name || item.typeId || "Item"}`);
      } else {
        form.button(`§7Slot ${slot + 1}\n§8Empty`);
      }
    }

    // Navigation
    if (page > 0) form.button("§f◀ Previous Page");
    if (page < TOTAL_PAGES - 1) form.button("§f▶ Next Page");
    form.button("§7Close");

    form.show(player).then(response => {
      if (response.canceled) return;
      let idx = response.selection;

      // Slot clicks (0-8)
      if (idx < SLOTS_PER_PAGE) {
        const slot = startSlot + idx;
        this.handleSlotClick(player, slot, page);
        return;
      }
      idx -= SLOTS_PER_PAGE;

      // Navigation buttons
      if (page > 0 && idx === 0) { this.openPantryMenu(player, page - 1); return; }
      if (page > 0) idx--;
      if (page < TOTAL_PAGES - 1 && idx === 0) { this.openPantryMenu(player, page + 1); return; }
    });
  }

  handleSlotClick(player, slot, page) {
    const existing = this.getSlot(player, slot);

    if (existing) {
      // Retrieve item
      this.retrieveItem(player, slot, page);
    } else {
      // Try to store held item
      this.storeItem(player, slot, page);
    }
  }

  storeItem(player, slot, page) {
    const equip = player.getComponent("minecraft:equippable");
    const mainhand = equip?.getEquipment("Mainhand");

    if (!mainhand) {
      player.sendMessage("§c§l✗ §r§7Hold a cooking item to store.");
      this.openPantryMenu(player, page);
      return;
    }

    if (!this.isPantryItem(mainhand)) {
      player.sendMessage("§c§l✗ §r§7This item can't go in the pantry.");
      this.openPantryMenu(player, page);
      return;
    }

    // Store item data
    const itemData = {
      typeId: mainhand.typeId,
      name: mainhand.nameTag || mainhand.typeId.replace("minecraft:", "").replace("forevercraft:", ""),
      amount: 1,
    };

    this.setSlot(player, slot, itemData);

    // Remove one from hand
    if (mainhand.amount > 1) {
      mainhand.amount -= 1;
      equip.setEquipment("Mainhand", mainhand);
    } else {
      equip.setEquipment("Mainhand", undefined);
    }

    player.sendMessage(`§a§l✓ §r§7Stored §e${itemData.name} §7in slot ${slot + 1}.`);
    try { player.playSound("random.pop", { volume: 0.5, pitch: 1.0 }); } catch {}
    this.openPantryMenu(player, page);
  }

  retrieveItem(player, slot, page) {
    const item = this.getSlot(player, slot);
    if (!item) return;

    // Give item to player
    try {
      player.runCommandAsync(`give @s ${item.typeId} 1`);
    } catch {}

    this.setSlot(player, slot, null);
    player.sendMessage(`§a§l✓ §r§7Retrieved §e${item.name} §7from slot ${slot + 1}.`);
    try { player.playSound("random.pop", { volume: 0.5, pitch: 1.2 }); } catch {}
    this.openPantryMenu(player, page);
  }

  // ─── UTILITY ──────────────────────────────────────────────

  /** Get total items stored */
  getItemCount(player) {
    const data = this.getPantryData(player);
    return Object.keys(data).length;
  }
}
