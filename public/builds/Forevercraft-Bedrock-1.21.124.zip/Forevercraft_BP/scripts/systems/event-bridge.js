import { world } from "@minecraft/server";

export class EventBridge {
  constructor() {
    this.handlers = new Map();
  }

  on(event, handler) {
    if (!this.handlers.has(event)) this.handlers.set(event, []);
    this.handlers.get(event).push(handler);
  }

  emit(event, ...args) {
    const handlers = this.handlers.get(event);
    if (handlers) {
      for (const handler of handlers) {
        try { handler(...args); } catch (e) { console.error(`[EventBridge] Error in '${event}':`, e); }
      }
    }
  }

  registerAll() {
    // Entity Death (replaces player_killed_entity advancement)
    world.afterEvents.entityDie.subscribe((event) => {
      const { deadEntity, damageSource } = event;
      const killer = damageSource.damagingEntity;
      if (killer?.typeId === "minecraft:player") {
        this.emit("player_killed_entity", killer, deadEntity, damageSource);
        this.emit(`killed:${deadEntity.typeId}`, killer, deadEntity);
      }
      this.emit("entity_died", deadEntity, damageSource);
      // Player death — clear engagement tags, etc.
      if (deadEntity.typeId === "minecraft:player") {
        this.emit("player_died", deadEntity, damageSource);
      }
    });

    // Entity Hurt
    world.afterEvents.entityHurt.subscribe((event) => {
      const { hurtEntity, damageSource, damage } = event;
      if (hurtEntity.typeId === "minecraft:player") {
        this.emit("player_hurt", hurtEntity, damageSource, damage);
      }
      const attacker = damageSource.damagingEntity;
      if (attacker?.typeId === "minecraft:player") {
        this.emit("player_dealt_damage", attacker, hurtEntity, damage, damageSource);
      }
      this.emit("entity_hurt", hurtEntity, damageSource, damage);
    });

    // Player Spawn
    world.afterEvents.playerSpawn.subscribe((event) => {
      const { player, initialSpawn } = event;
      this.emit(initialSpawn ? "player_first_join" : "player_respawn", player);
      this.emit("player_spawn", player, initialSpawn);
    });

    // Player Leave
    world.afterEvents.playerLeave.subscribe((event) => {
      this.emit("player_leave", event.playerId, event.playerName);
    });

    // Block Break
    world.afterEvents.playerBreakBlock.subscribe((event) => {
      const { player, brokenBlockPermutation, block } = event;
      const blockId = brokenBlockPermutation.type.id;
      this.emit("block_break", player, blockId, block.location);
      if (["minecraft:wheat","minecraft:carrots","minecraft:potatoes","minecraft:beetroot","minecraft:nether_wart"].includes(blockId)) {
        this.emit("crop_harvested", player, blockId, block.location);
      }
      this.emit(`mined:${blockId}`, player, block.location);
    });

    // Block Place
    world.afterEvents.playerPlaceBlock.subscribe((event) => {
      const { player, block } = event;
      this.emit("block_place", player, block.typeId, block.location);
    });

    // Item Use
    world.afterEvents.itemUse.subscribe((event) => {
      const { source, itemStack } = event;
      if (source.typeId === "minecraft:player") {
        this.emit("item_use", source, itemStack);
        this.emit(`used:${itemStack.typeId}`, source, itemStack);
      }
    });

    // Item Use On Block
    world.afterEvents.itemUseOn.subscribe((event) => {
      const { source, itemStack, block } = event;
      if (source.typeId === "minecraft:player") {
        this.emit("item_use_on", source, itemStack, block);
      }
    });

    // Item Complete Use (consume)
    world.afterEvents.itemCompleteUse.subscribe((event) => {
      const { source, itemStack } = event;
      if (source.typeId === "minecraft:player") {
        this.emit("item_consumed", source, itemStack);
      }
    });

    // Projectile Hit — for ranged knockback (punch) abilities
    world.afterEvents.projectileHitEntity.subscribe((event) => {
      const { projectile, source, getEntityHit } = event;
      if (source?.typeId === "minecraft:player") {
        const hitInfo = getEntityHit();
        if (hitInfo?.entity) {
          this.emit("projectile_hit", source, hitInfo.entity, projectile);
        }
      }
    });

    console.log("[EventBridge] All event subscriptions registered.");
  }

  handleInteraction(entity) {
    const tags = entity.getTags();
    for (const tag of tags) this.emit(`interact:${tag}`, entity);
    this.emit("entity_interact", entity, tags);
  }
}
