# Tamed Animal Protection — tag tamed animals for protection + healer systems
# Self-schedules every 5s — new tamed animals are picked up on next cycle
# Tag-gated: only scans NBT on unprocessed entities (zero cost after first pass)

schedule function evercraft:tamed_protection/tick 5s

execute unless entity @a run return 0

# Find untamed-tagged tameable mobs with an Owner (= tamed) and mark them.
# Perf retrofit M4 (2026-06-14): only enumerate tameables within 16b of a player instead of every
# loaded wolf/cat/parrot/horse/llama in the world. A newly-tamed animal is right next to the player
# who tamed it, so it's still caught next cycle; far loaded animals get tagged when a player nears.
execute as @a at @s as @e[type=#evercraft:tameable_companions,tag=!ec.tame_protected,distance=..16] if data entity @s Owner run tag @s add ec.tame_protected

# 2026-06-20: foxes/ocelots carry no real Owner NBT (custom-tamed via the fake-owner system), so
# recognize them by their tamed tag instead. Now they get protection + healer support + are buddy-bondable.
execute as @a at @s as @e[tag=ec.fox_tamed,tag=!ec.tame_protected,distance=..16] run tag @s add ec.tame_protected
execute as @a at @s as @e[tag=ec.ocelot_tamed,tag=!ec.tame_protected,distance=..16] run tag @s add ec.tame_protected
