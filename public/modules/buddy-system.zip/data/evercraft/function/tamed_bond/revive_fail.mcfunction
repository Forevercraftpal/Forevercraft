# Tamed Bond — Revival Failed, Restore Memento
# Called 1 tick after failed revival to restore the consumed item
# Runs as the player with ec.tb_restore tag

# Council #6 (2026-05-27): repopulate single-key `memento` from the per-player keyed mirror.
# Fixes the cross-tick race where two players failing same-tick stomped each other's `memento`.
data modify storage evercraft:tamed_bond temp_args.UUID set from entity @s UUID
function evercraft:tamed_bond/load_memento with storage evercraft:tamed_bond temp_args

# Council #6 (2026-05-27): restore the item to the original slot via restore_to_slot macro.
# `memento` now holds this player's correct item; SelectedItemSlot is where the player
# was holding it when they consumed it.
execute store result storage evercraft:tamed_bond temp_args.SelectedItemSlot int 1 run data get entity @s SelectedItemSlot
function evercraft:tamed_bond/restore_to_slot with storage evercraft:tamed_bond temp_args

# Council #6 (2026-05-27): clear the per-player keyed memento now that the restore is complete.
function evercraft:tamed_bond/clear_memento with storage evercraft:tamed_bond temp_args
data remove storage evercraft:tamed_bond temp_args

# Sound feedback
execute at @s if score @s ec.fx_snd matches 1.. run playsound minecraft:block.amethyst_block.break master @s ~ ~ ~ 0.5 0.5
