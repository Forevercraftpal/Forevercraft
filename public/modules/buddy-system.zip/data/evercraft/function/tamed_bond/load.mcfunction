# Tamed Animal Bond System — Load
# Tracks tamed animals, drops mementos on death via loot tables, enables revival

# === SCOREBOARDS ===
scoreboard objectives add ec.bond trigger "Bond Status"

# === Council #6 (2026-05-27): player-scoped scratch for memento delivery UUID match ===
# Was shared scratch #tb_player_u0/u1 + #tb_owner_u0/u1 ec.temp in check_owner.mcfunction.
scoreboard objectives add ec.tb_player_u0 dummy
scoreboard objectives add ec.tb_player_u1 dummy
scoreboard objectives add ec.tb_owner_u0 dummy
scoreboard objectives add ec.tb_owner_u1 dummy

# === 2026-06-20: Persistent fake-owner UUID for foxes/ocelots ===
# Foxes/ocelots aren't TamableAnimal, so a real Owner NBT key never persists on them. We store the
# owner's UUID (4 ints) on the entity in these objectives instead — entity scoreboards DO survive
# save/reload — so tamed_bond + tamed_protection can treat them like any owned pet.
scoreboard objectives add ec.tb_fown0 dummy
scoreboard objectives add ec.tb_fown1 dummy
scoreboard objectives add ec.tb_fown2 dummy
scoreboard objectives add ec.tb_fown3 dummy

# === BOOTSTRAP ===
scoreboard players enable @a ec.bond
schedule function evercraft:tamed_bond/tick 5s replace
schedule function evercraft:tamed_bond/memento_pickup 10t replace
