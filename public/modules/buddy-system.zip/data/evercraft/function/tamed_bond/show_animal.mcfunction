# Tamed Bond — Show Individual Animal
# Runs as each nearby registered tamed entity

scoreboard players add #tb_count ec.temp 1

# Display: name + type + health
tellraw @a[tag=ec.tb_viewing] [{text:"    "},{text:"- ",color:"gray"},{entity:"@s",nbt:"CustomName",interpret:true},{text:" ",color:"white"},{text:"(healthy)",color:"green"}]
