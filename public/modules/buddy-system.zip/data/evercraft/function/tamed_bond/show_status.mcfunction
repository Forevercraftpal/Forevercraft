# Tamed Bond — Show Bond Status
# /trigger ec.bond — displays nearby tamed animals owned by the player
# Runs as the player

tellraw @s ""
tellraw @s [{text:"  "},{text:"ANIMAL BONDS",color:"light_purple",bold:true}]
tellraw @s ""

# === MOUNT BOND (from mount training system) ===
execute if score @s ec.mt_bond matches 1.. run tellraw @s [{text:"  "},{text:"Mount Bond: ",color:"gold"},{score:{name:"@s",objective:"ec.mt_bond"},color:"white",bold:true},{text:" XP",color:"gray"}]
execute if score @s ec.mt_tier matches 0 if score @s ec.mt_bond matches 1.. run tellraw @s [{text:"    "},{text:"Tier: Unfamiliar",color:"gray"}]
execute if score @s ec.mt_tier matches 1 run tellraw @s [{text:"    "},{text:"Tier: Trusted",color:"green"},{text:" (+10% speed)",color:"dark_green"}]
execute if score @s ec.mt_tier matches 2 run tellraw @s [{text:"    "},{text:"Tier: Bonded",color:"aqua"},{text:" (+20% speed)",color:"dark_aqua"}]
execute if score @s ec.mt_tier matches 3 run tellraw @s [{text:"    "},{text:"Tier: Soulbound",color:"light_purple"},{text:" (+30% speed, recall)",color:"dark_purple"}]
execute if score @s ec.mt_tier matches 4 run tellraw @s [{text:"    "},{text:"Tier: Eternal",color:"gold"},{text:" (+40% speed, derby eligible)",color:"yellow"}]

# === NEARBY NAMED TAMED ANIMALS ===
tellraw @s [{text:"  "},{text:"Nearby Companions:",color:"aqua"}]

# Tag self for targeted tellraw from show_animal
tag @s add ec.tb_viewing

# Count nearby named tamed animals (within 64 blocks)
scoreboard players set #tb_count ec.temp 0
execute at @s as @e[type=wolf,tag=ec.tb_registered,distance=..64] run function evercraft:tamed_bond/show_animal
execute at @s as @e[type=cat,tag=ec.tb_registered,distance=..64] run function evercraft:tamed_bond/show_animal
execute at @s as @e[type=horse,tag=ec.tb_registered,distance=..64] run function evercraft:tamed_bond/show_animal
execute at @s as @e[type=parrot,tag=ec.tb_registered,distance=..64] run function evercraft:tamed_bond/show_animal
execute at @s as @e[type=fox,tag=ec.tb_registered,distance=..64] run function evercraft:tamed_bond/show_animal

execute if score #tb_count ec.temp matches 0 run tellraw @s [{text:"    "},{text:"No named tamed animals nearby.",color:"gray",italic:true}]

tag @s remove ec.tb_viewing

tellraw @s ""

# OPT: enable + reset moved from tick.mcfunction (saves 2 @a scans/tick)
scoreboard players enable @s ec.bond
scoreboard players set @s ec.bond 0
