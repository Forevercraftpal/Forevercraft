# Tamed Bond — Re-tame a revived ocelot to the reviver
# @s = the player who performed the Moonbloom ceremony (the new owner). The revived ocelot is tagged
# ec.tb_retame_ocelot. Mirror of retame_fox, plus the permanent Strength I that ocelots/tame grants.

# Allocate my ocelot owner-id if I don't have one yet (mirror ocelots/assign_owner_id, self).
execute unless score @s ocelot.owner matches 1.. run scoreboard players operation @s ocelot.owner = #ocelot_owner_next ocelot.owner
execute unless score @s ocelot.owner matches 1.. run scoreboard players add #ocelot_owner_next ocelot.owner 1

# Stamp the revived ocelot with my owner-id and my UUID (the fake-owner), then re-establish tamed state.
scoreboard players operation @e[type=ocelot,tag=ec.tb_retame_ocelot,limit=1] ocelot.owner = @s ocelot.owner
execute store result score @e[type=ocelot,tag=ec.tb_retame_ocelot,limit=1] ec.tb_fown0 run data get entity @s UUID[0]
execute store result score @e[type=ocelot,tag=ec.tb_retame_ocelot,limit=1] ec.tb_fown1 run data get entity @s UUID[1]
execute store result score @e[type=ocelot,tag=ec.tb_retame_ocelot,limit=1] ec.tb_fown2 run data get entity @s UUID[2]
execute store result score @e[type=ocelot,tag=ec.tb_retame_ocelot,limit=1] ec.tb_fown3 run data get entity @s UUID[3]
scoreboard players set @e[type=ocelot,tag=ec.tb_retame_ocelot,limit=1] ocelot.sitting 0
tag @e[type=ocelot,tag=ec.tb_retame_ocelot,limit=1] add ec.ocelot_tamed
data modify entity @e[type=ocelot,tag=ec.tb_retame_ocelot,limit=1] PersistenceRequired set value 1b
data modify entity @e[type=ocelot,tag=ec.tb_retame_ocelot,limit=1] InLove set value 0

# Permanent Strength I — ocelots hit harder than other tamed mobs (matches ocelots/tame).
effect give @e[type=ocelot,tag=ec.tb_retame_ocelot,limit=1] strength infinite 0 true

# Re-create the sit/stand interaction entity at the ocelot (the original despawned with the death).
execute at @e[type=ocelot,tag=ec.tb_retame_ocelot,limit=1] run summon interaction ~ ~ ~ {Tags:["ec.ocelot_interact"],width:0.6f,height:0.7f}

# Clear the retame marker.
tag @e[type=ocelot,tag=ec.tb_retame_ocelot] remove ec.tb_retame_ocelot
