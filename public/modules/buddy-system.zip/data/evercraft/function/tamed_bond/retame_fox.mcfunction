# Tamed Bond — Re-tame a revived fox to the reviver
# @s = the player who performed the Moonbloom ceremony (the new owner). The revived fox is tagged
# ec.tb_retame_fox. Restores everything foxes/tame establishes, scoped to this player, so the fox
# follows / sits / is protected again. Foxes carry no Owner NBT, hence the fox.owner int + the
# persistent fake-owner UUID (ec.tb_fown0-3).

# Allocate my fox owner-id if I don't have one yet (mirror foxes/assign_owner_id, self).
execute unless score @s fox.owner matches 1.. run scoreboard players operation @s fox.owner = #fox_owner_next fox.owner
execute unless score @s fox.owner matches 1.. run scoreboard players add #fox_owner_next fox.owner 1

# Stamp the revived fox with my owner-id and my UUID (the fake-owner), then re-establish tamed state.
scoreboard players operation @e[type=fox,tag=ec.tb_retame_fox,limit=1] fox.owner = @s fox.owner
execute store result score @e[type=fox,tag=ec.tb_retame_fox,limit=1] ec.tb_fown0 run data get entity @s UUID[0]
execute store result score @e[type=fox,tag=ec.tb_retame_fox,limit=1] ec.tb_fown1 run data get entity @s UUID[1]
execute store result score @e[type=fox,tag=ec.tb_retame_fox,limit=1] ec.tb_fown2 run data get entity @s UUID[2]
execute store result score @e[type=fox,tag=ec.tb_retame_fox,limit=1] ec.tb_fown3 run data get entity @s UUID[3]
scoreboard players set @e[type=fox,tag=ec.tb_retame_fox,limit=1] fox.sitting 0
tag @e[type=fox,tag=ec.tb_retame_fox,limit=1] add ec.fox_tamed
data modify entity @e[type=fox,tag=ec.tb_retame_fox,limit=1] PersistenceRequired set value 1b
data modify entity @e[type=fox,tag=ec.tb_retame_fox,limit=1] InLove set value 0

# Re-create the sit/stand interaction entity at the fox (the original despawned with the death).
execute at @e[type=fox,tag=ec.tb_retame_fox,limit=1] run summon interaction ~ ~ ~ {Tags:["ec.fox_interact"],width:0.6f,height:0.7f}

# Clear the retame marker.
tag @e[type=fox,tag=ec.tb_retame_fox] remove ec.tb_retame_fox
