# Tamed Bond — Check if this player is the memento owner
# Runs as each online player
# Compares player UUID to the owner UUID stored in storage

# Already delivered? Skip
execute if score #tb_delivered ec.temp matches 1 run return 0

# Compare UUID[0] — Council #6 (2026-05-27): tb_owner_u0/u1 + tb_player_u0/u1 are player-scoped (was shared scratch).
execute store result score @s ec.tb_player_u0 run data get entity @s UUID[0]
execute store result score @s ec.tb_owner_u0 run data get storage evercraft:tamed_bond delivery_owner[0]
execute unless score @s ec.tb_player_u0 = @s ec.tb_owner_u0 run return 0

# UUID[0] matched — verify with UUID[1]
execute store result score @s ec.tb_player_u1 run data get entity @s UUID[1]
execute store result score @s ec.tb_owner_u1 run data get storage evercraft:tamed_bond delivery_owner[1]
execute unless score @s ec.tb_player_u1 = @s ec.tb_owner_u1 run return 0

# MATCH — this player owns the dead pet. Give memento directly to inventory.
scoreboard players set #tb_delivered ec.temp 1

# Give the memento item directly to player inventory
# Summon temp item entity at player, set its Item data, instant pickup
# Council #6 (2026-05-27): distance-gated to avoid cross-pet stomp when 2 pets deliver same-tick.
# 2026-06-20 FIX: the data-modify + tag-clear were running in this function's INHERITED position
# (the pet's death spot, via `as @a` from on_pet_death) while the stone was summoned `at @s` (the
# player). When the pet died >2 blocks from its owner — the normal case for a combat pet that ran
# ahead — the distance=..2 selector matched nothing, so the stone stayed a stone and the memento was
# never delivered (the "death message appears but no memento" report). Anchor the whole give at @s.
execute at @s run summon item ~ ~ ~ {Tags:["ec.tb_give"],PickupDelay:0s,Item:{id:"minecraft:stone",count:1}}
execute at @s run data modify entity @e[tag=ec.tb_give,limit=1,distance=..3] Item set from storage evercraft:tamed_bond new_item
execute at @s run tag @e[tag=ec.tb_give,distance=..3] remove ec.tb_give

# Council #6 (2026-05-27): mirror memento into per-player keyed storage (mementos."<UUID>")
# so the cross-tick restore_check race can be resolved by load_memento on the receiving side.
data modify storage evercraft:tamed_bond temp_memento set from storage evercraft:tamed_bond new_item
data modify storage evercraft:tamed_bond temp_args.UUID set from entity @s UUID
function evercraft:tamed_bond/store_memento with storage evercraft:tamed_bond temp_args
data remove storage evercraft:tamed_bond temp_args

# Notification
data modify storage evercraft:notify stage.c set value [{text:"Your ",color:"red"},{nbt:"pet_name",storage:"evercraft:tamed_bond",interpret:true,color:"red"},{text:" has fallen in battle.",color:"red"}]
scoreboard players set #ndur ec.temp 50
function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Find a Torchflower to perform the Moonbloom Ceremony.",color:"gray"}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit
title @s times 10 60 20
title @s title {"text":" "}
title @s subtitle [{"text":"Your ","color":"red","italic":true},{"nbt":"pet_name","storage":"evercraft:tamed_bond","interpret":true,"color":"red","italic":true},{"text":" has fallen in battle.","color":"red","italic":true}]
