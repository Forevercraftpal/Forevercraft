# Tamed Bond — Restore Memento to Correct Slot (macro)
# Reads stored slot index and restores item there
$item replace entity @s container.$(SelectedItemSlot) from storage evercraft:tamed_bond memento
