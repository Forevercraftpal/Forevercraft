# Tamed Bond — Check if totem was consumed (= pet took fatal damage)
# Runs as each registered entity with ec.tb_has_totem tag
# If offhand is empty, the totem fired and saved the pet at 1HP

# Check if offhand totem is gone (consumed by fatal damage)
execute unless data entity @s equipment.offhand.id at @s run function evercraft:tamed_bond/on_pet_death
