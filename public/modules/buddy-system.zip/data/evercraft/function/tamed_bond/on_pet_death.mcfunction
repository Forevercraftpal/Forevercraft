# Tamed Bond — Pet Totem Triggered
# Runs as the pet that just survived fatal damage via totem, at its position
# The pet is alive at 1HP with totem effects. We create the memento,
# deliver to owner, then kill the entity.

# Mark as processed
tag @s remove ec.tb_has_totem
tag @s add ec.tb_dying

# === Council #5 (D2, 2026-05-27): Buddy death override branches ===
# Reset Last Stand consumed sentinel (shared scratch — safe per-call reset)
scoreboard players set #bd_ls_consumed ec.temp 0
# Set #Search to the dying entity's owner companion.id for ownership predicate use
scoreboard players operation #Search companion.id = @s ec.bd_owner_id

# Tier-3+ Last Stand rescue takes priority (gated on cooldown via owner)
execute if entity @s[tag=ec.bd_buddy] run function evercraft:buddy/abilities/last_stand/on_death_dispatch
# If Last Stand consumed, buddy is rescued (healed+invuln+tp) — skip memento + kill
execute if score #bd_ls_consumed ec.temp matches 1 run tag @s remove ec.tb_dying
execute if score #bd_ls_consumed ec.temp matches 1 run return 0

# === Wave 23 (2026-06-11): Beastlord U11 Mythic Bond — cheat-death intercept ===
# After buddy Last Stand (a buddy rescue is free for the Beastlord cooldown),
# before the memento ceremonies. Runs as the dying pet; the intercept resolves
# the owner itself (on-owner traversal + custom-tame owner-ID match) and gates
# on ec.bl_n_u11 + per-owner ec.bl_cheat_cd. On success it heals the pet to
# 50% max HP and re-arms the bond totem, then sets sentinel #bl_cheat ec.temp 1
# (the #bd_ls_consumed shape) so we skip memento + kill.
function evercraft:bough/beastlord/cheat_death_intercept
execute if score #bl_cheat ec.temp matches 1 run tag @s remove ec.tb_dying
execute if score #bl_cheat ec.temp matches 1 run return 0

# Best Buddy gets the buddy memento ceremony instead of generic
# Set sentinel BEFORE kill so the subsequent return-gate works (kill removes @s reference)
scoreboard players set #bd_best_handled ec.temp 0
execute if entity @s[tag=ec.bd_best] run scoreboard players set #bd_best_handled ec.temp 1
execute if score #bd_best_handled ec.temp matches 1 run function evercraft:buddy/best/revive/on_death_dispatch
execute if score #bd_best_handled ec.temp matches 1 run kill @s
execute if score #bd_best_handled ec.temp matches 1 run return 0

# === BUILD MEMENTO ITEM ===
execute if entity @s[type=wolf] run data modify storage evercraft:tamed_bond new_item set value {id:"minecraft:bone",count:1,components:{"minecraft:enchantment_glint_override":true,"minecraft:max_stack_size":1,"minecraft:custom_data":{pet_memento:true,pet_type:"wolf"},"minecraft:lore":[{"text":"Pet Memento","color":"light_purple","italic":false},"",{"text":"A keepsake of a fallen friend.","color":"gray","italic":true},{"text":"Find a Torchflower and perform the","color":"gray","italic":true},{"text":"Moonbloom Ceremony to bring them back.","color":"gray","italic":true},"",{"text":"Use under a full moon, open sky,","color":"dark_gray","italic":false},{"text":"with a Torchflower in your offhand.","color":"dark_gray","italic":false}],"minecraft:consumable":{"consume_seconds":0,"animation":"brush","sound":"intentionally_empty","has_consume_particles":false}}}
execute if entity @s[type=cat] run data modify storage evercraft:tamed_bond new_item set value {id:"minecraft:cod",count:1,components:{"minecraft:enchantment_glint_override":true,"minecraft:max_stack_size":1,"minecraft:custom_data":{pet_memento:true,pet_type:"cat"},"minecraft:lore":[{"text":"Pet Memento","color":"light_purple","italic":false},"",{"text":"A keepsake of a fallen friend.","color":"gray","italic":true},{"text":"Find a Torchflower and perform the","color":"gray","italic":true},{"text":"Moonbloom Ceremony to bring them back.","color":"gray","italic":true},"",{"text":"Use under a full moon, open sky,","color":"dark_gray","italic":false},{"text":"with a Torchflower in your offhand.","color":"dark_gray","italic":false}],"minecraft:consumable":{"consume_seconds":0,"animation":"brush","sound":"intentionally_empty","has_consume_particles":false}}}
execute if entity @s[type=horse] run data modify storage evercraft:tamed_bond new_item set value {id:"minecraft:golden_carrot",count:1,components:{"minecraft:enchantment_glint_override":true,"minecraft:max_stack_size":1,"minecraft:custom_data":{pet_memento:true,pet_type:"horse"},"minecraft:lore":[{"text":"Pet Memento","color":"light_purple","italic":false},"",{"text":"A keepsake of a fallen friend.","color":"gray","italic":true},{"text":"Find a Torchflower and perform the","color":"gray","italic":true},{"text":"Moonbloom Ceremony to bring them back.","color":"gray","italic":true},"",{"text":"Use under a full moon, open sky,","color":"dark_gray","italic":false},{"text":"with a Torchflower in your offhand.","color":"dark_gray","italic":false}],"minecraft:consumable":{"consume_seconds":0,"animation":"brush","sound":"intentionally_empty","has_consume_particles":false}}}
execute if entity @s[type=parrot] run data modify storage evercraft:tamed_bond new_item set value {id:"minecraft:wheat_seeds",count:1,components:{"minecraft:enchantment_glint_override":true,"minecraft:max_stack_size":1,"minecraft:custom_data":{pet_memento:true,pet_type:"parrot"},"minecraft:lore":[{"text":"Pet Memento","color":"light_purple","italic":false},"",{"text":"A keepsake of a fallen friend.","color":"gray","italic":true},{"text":"Find a Torchflower and perform the","color":"gray","italic":true},{"text":"Moonbloom Ceremony to bring them back.","color":"gray","italic":true},"",{"text":"Use under a full moon, open sky,","color":"dark_gray","italic":false},{"text":"with a Torchflower in your offhand.","color":"dark_gray","italic":false}],"minecraft:consumable":{"consume_seconds":0,"animation":"brush","sound":"intentionally_empty","has_consume_particles":false}}}
execute if entity @s[type=fox] run data modify storage evercraft:tamed_bond new_item set value {id:"minecraft:sweet_berries",count:1,components:{"minecraft:enchantment_glint_override":true,"minecraft:max_stack_size":1,"minecraft:custom_data":{pet_memento:true,pet_type:"fox"},"minecraft:lore":[{"text":"Pet Memento","color":"light_purple","italic":false},"",{"text":"A keepsake of a fallen friend.","color":"gray","italic":true},{"text":"Find a Torchflower and perform the","color":"gray","italic":true},{"text":"Moonbloom Ceremony to bring them back.","color":"gray","italic":true},"",{"text":"Use under a full moon, open sky,","color":"dark_gray","italic":false},{"text":"with a Torchflower in your offhand.","color":"dark_gray","italic":false}],"minecraft:consumable":{"consume_seconds":0,"animation":"brush","sound":"intentionally_empty","has_consume_particles":false}}}
# 2026-06-20: ocelot branch (custom-tamed via the fake-owner system, like foxes — see retame_ocelot).
execute if entity @s[type=ocelot] run data modify storage evercraft:tamed_bond new_item set value {id:"minecraft:salmon",count:1,components:{"minecraft:enchantment_glint_override":true,"minecraft:max_stack_size":1,"minecraft:custom_data":{pet_memento:true,pet_type:"ocelot"},"minecraft:lore":[{"text":"Pet Memento","color":"light_purple","italic":false},"",{"text":"A keepsake of a fallen friend.","color":"gray","italic":true},{"text":"Find a Torchflower and perform the","color":"gray","italic":true},{"text":"Moonbloom Ceremony to bring them back.","color":"gray","italic":true},"",{"text":"Use under a full moon, open sky,","color":"dark_gray","italic":false},{"text":"with a Torchflower in your offhand.","color":"dark_gray","italic":false}],"minecraft:consumable":{"consume_seconds":0,"animation":"brush","sound":"intentionally_empty","has_consume_particles":false}}}
# Council #6 (2026-05-27): split fallback into per-species so revive_spawn can summon the right mob.
execute if entity @s[type=donkey] run data modify storage evercraft:tamed_bond new_item set value {id:"minecraft:lead",count:1,components:{"minecraft:enchantment_glint_override":true,"minecraft:max_stack_size":1,"minecraft:custom_data":{pet_memento:true,pet_type:"donkey"},"minecraft:lore":[{"text":"Pet Memento","color":"light_purple","italic":false},"",{"text":"A keepsake of a fallen friend.","color":"gray","italic":true},{"text":"Find a Torchflower and perform the","color":"gray","italic":true},{"text":"Moonbloom Ceremony to bring them back.","color":"gray","italic":true},"",{"text":"Use under a full moon, open sky,","color":"dark_gray","italic":false},{"text":"with a Torchflower in your offhand.","color":"dark_gray","italic":false}],"minecraft:consumable":{"consume_seconds":0,"animation":"brush","sound":"intentionally_empty","has_consume_particles":false}}}
execute if entity @s[type=mule] run data modify storage evercraft:tamed_bond new_item set value {id:"minecraft:lead",count:1,components:{"minecraft:enchantment_glint_override":true,"minecraft:max_stack_size":1,"minecraft:custom_data":{pet_memento:true,pet_type:"mule"},"minecraft:lore":[{"text":"Pet Memento","color":"light_purple","italic":false},"",{"text":"A keepsake of a fallen friend.","color":"gray","italic":true},{"text":"Find a Torchflower and perform the","color":"gray","italic":true},{"text":"Moonbloom Ceremony to bring them back.","color":"gray","italic":true},"",{"text":"Use under a full moon, open sky,","color":"dark_gray","italic":false},{"text":"with a Torchflower in your offhand.","color":"dark_gray","italic":false}],"minecraft:consumable":{"consume_seconds":0,"animation":"brush","sound":"intentionally_empty","has_consume_particles":false}}}
execute if entity @s[type=llama] run data modify storage evercraft:tamed_bond new_item set value {id:"minecraft:lead",count:1,components:{"minecraft:enchantment_glint_override":true,"minecraft:max_stack_size":1,"minecraft:custom_data":{pet_memento:true,pet_type:"llama"},"minecraft:lore":[{"text":"Pet Memento","color":"light_purple","italic":false},"",{"text":"A keepsake of a fallen friend.","color":"gray","italic":true},{"text":"Find a Torchflower and perform the","color":"gray","italic":true},{"text":"Moonbloom Ceremony to bring them back.","color":"gray","italic":true},"",{"text":"Use under a full moon, open sky,","color":"dark_gray","italic":false},{"text":"with a Torchflower in your offhand.","color":"dark_gray","italic":false}],"minecraft:consumable":{"consume_seconds":0,"animation":"brush","sound":"intentionally_empty","has_consume_particles":false}}}
execute if entity @s[type=camel] run data modify storage evercraft:tamed_bond new_item set value {id:"minecraft:lead",count:1,components:{"minecraft:enchantment_glint_override":true,"minecraft:max_stack_size":1,"minecraft:custom_data":{pet_memento:true,pet_type:"camel"},"minecraft:lore":[{"text":"Pet Memento","color":"light_purple","italic":false},"",{"text":"A keepsake of a fallen friend.","color":"gray","italic":true},{"text":"Find a Torchflower and perform the","color":"gray","italic":true},{"text":"Moonbloom Ceremony to bring them back.","color":"gray","italic":true},"",{"text":"Use under a full moon, open sky,","color":"dark_gray","italic":false},{"text":"with a Torchflower in your offhand.","color":"dark_gray","italic":false}],"minecraft:consumable":{"consume_seconds":0,"animation":"brush","sound":"intentionally_empty","has_consume_particles":false}}}
# Final catchall for any unrecognised tameable companion type.
execute unless entity @s[type=wolf] unless entity @s[type=cat] unless entity @s[type=horse] unless entity @s[type=parrot] unless entity @s[type=fox] unless entity @s[type=ocelot] unless entity @s[type=donkey] unless entity @s[type=mule] unless entity @s[type=llama] unless entity @s[type=camel] run data modify storage evercraft:tamed_bond new_item set value {id:"minecraft:lead",count:1,components:{"minecraft:enchantment_glint_override":true,"minecraft:max_stack_size":1,"minecraft:custom_data":{pet_memento:true,pet_type:"other"},"minecraft:lore":[{"text":"Pet Memento","color":"light_purple","italic":false},"",{"text":"A keepsake of a fallen friend.","color":"gray","italic":true},{"text":"Find a Torchflower and perform the","color":"gray","italic":true},{"text":"Moonbloom Ceremony to bring them back.","color":"gray","italic":true},"",{"text":"Use under a full moon, open sky,","color":"dark_gray","italic":false},{"text":"with a Torchflower in your offhand.","color":"dark_gray","italic":false}],"minecraft:consumable":{"consume_seconds":0,"animation":"brush","sound":"intentionally_empty","has_consume_particles":false}}}

# Copy pet's CustomName to the memento (if named)
execute if data entity @s CustomName run data modify storage evercraft:tamed_bond new_item.components."minecraft:custom_name" set from entity @s CustomName

# Resolve the owner UUID. Wolves/cats/horses/etc carry a real Owner NBT. Foxes/ocelots don't (they
# aren't TamableAnimal — see foxes/tame), so we reconstruct it from their persistent fake-owner
# scoreboards (ec.tb_fown0-3) into storage `fk_uuid`. fk_uuid presence then selects the source below
# (and again for delivery_owner). Clear first so a fox death can't inherit a previous pet's fk_uuid.
data remove storage evercraft:tamed_bond fk_uuid
execute if entity @s[tag=ec.fox_tamed] run function evercraft:tamed_bond/fake_owner_uuid
execute if entity @s[tag=ec.ocelot_tamed] run function evercraft:tamed_bond/fake_owner_uuid

# Store owner UUID in memento for revival system (real Owner, or the fox/ocelot fake-owner)
execute unless data storage evercraft:tamed_bond fk_uuid run data modify storage evercraft:tamed_bond new_item.components."minecraft:custom_data".owner_uuid set from entity @s Owner
execute if data storage evercraft:tamed_bond fk_uuid run data modify storage evercraft:tamed_bond new_item.components."minecraft:custom_data".owner_uuid set from storage evercraft:tamed_bond fk_uuid

# === 2026-06-20: Capture the pet's EXACT appearance so the Moonbloom revival brings back the same
# animal — a black wolf with a purple collar returns a black wolf with a purple collar. This is a
# species-agnostic superset: each `set from` is a silent no-op when the source field is absent on
# this species (a cat has no Strength, a wolf has no Variant, etc.), so the snapshot only carries
# the fields that actually exist on the dying pet. Pure-property fields only — we deliberately skip
# equipment slots (offhand held the now-consumed bond totem; body/saddle are items that `kill @s`
# can also drop, which would dupe on re-equip). Applied back in revive_finalize.
data modify storage evercraft:tamed_bond new_item.components."minecraft:custom_data".appearance set value {}
data modify storage evercraft:tamed_bond new_item.components."minecraft:custom_data".appearance.variant set from entity @s variant
data modify storage evercraft:tamed_bond new_item.components."minecraft:custom_data".appearance.Variant set from entity @s Variant
data modify storage evercraft:tamed_bond new_item.components."minecraft:custom_data".appearance.CollarColor set from entity @s CollarColor
data modify storage evercraft:tamed_bond new_item.components."minecraft:custom_data".appearance.Type set from entity @s Type
data modify storage evercraft:tamed_bond new_item.components."minecraft:custom_data".appearance.Strength set from entity @s Strength
data modify storage evercraft:tamed_bond new_item.components."minecraft:custom_data".appearance.Age set from entity @s Age

# Store pet name for notification (CustomName if named, else generic type)
data modify storage evercraft:tamed_bond pet_name set value {text:"companion"}
execute if entity @s[type=wolf] run data modify storage evercraft:tamed_bond pet_name set value {text:"Wolf"}
execute if entity @s[type=cat] run data modify storage evercraft:tamed_bond pet_name set value {text:"Cat"}
execute if entity @s[type=horse] run data modify storage evercraft:tamed_bond pet_name set value {text:"Horse"}
execute if entity @s[type=parrot] run data modify storage evercraft:tamed_bond pet_name set value {text:"Parrot"}
execute if entity @s[type=donkey] run data modify storage evercraft:tamed_bond pet_name set value {text:"Donkey"}
execute if entity @s[type=mule] run data modify storage evercraft:tamed_bond pet_name set value {text:"Mule"}
execute if entity @s[type=llama] run data modify storage evercraft:tamed_bond pet_name set value {text:"Llama"}
execute if entity @s[type=camel] run data modify storage evercraft:tamed_bond pet_name set value {text:"Camel"}
execute if entity @s[type=fox] run data modify storage evercraft:tamed_bond pet_name set value {text:"Fox"}
execute if entity @s[type=ocelot] run data modify storage evercraft:tamed_bond pet_name set value {text:"Ocelot"}
execute if data entity @s CustomName run data modify storage evercraft:tamed_bond pet_name set from entity @s CustomName

# === DELIVER TO OWNER ===
# Same source resolution as owner_uuid above: real Owner, or the fox/ocelot fake-owner UUID.
execute unless data storage evercraft:tamed_bond fk_uuid run data modify storage evercraft:tamed_bond delivery_owner set from entity @s Owner
execute if data storage evercraft:tamed_bond fk_uuid run data modify storage evercraft:tamed_bond delivery_owner set from storage evercraft:tamed_bond fk_uuid
scoreboard players set #tb_delivered ec.temp 0
execute as @a run function evercraft:tamed_bond/check_owner

# If owner not found/offline, drop at death location
# Council #6 (2026-05-27): distance-gated to avoid cross-pet stomp when 2 offline-owner pets die same-tick.
execute if score #tb_delivered ec.temp matches 0 run summon item ~ ~ ~ {Tags:["ec.tb_dropped"],PickupDelay:0s,Item:{id:"minecraft:stone",count:1}}
execute if score #tb_delivered ec.temp matches 0 run data modify entity @e[tag=ec.tb_dropped,limit=1,distance=..2] Item set from storage evercraft:tamed_bond new_item
execute if score #tb_delivered ec.temp matches 0 run tag @e[tag=ec.tb_dropped] remove ec.tb_dropped

# Effects at death location
playsound minecraft:entity.wolf.whine master @a[distance=..30,scores={ec.fx_snd=1..}] ~ ~ ~ 1.0 0.7
particle minecraft:soul ~ ~0.5 ~ 0.3 0.5 0.3 0.02 15 force

# Kill the pet (totem saved it, but we need it gone now)
kill @s
