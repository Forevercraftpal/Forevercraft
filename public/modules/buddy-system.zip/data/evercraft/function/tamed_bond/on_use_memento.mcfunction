# Tamed Bond — Memento Used (consume_item trigger)
# consume_seconds:0 means item is consumed instantly — must restore if conditions fail
# CRITICAL: consume_item fires BEFORE item removal — tag for 1-tick delay restore
# Runs as the player

# Revoke advancement for reuse
advancement revoke @s only evercraft:tamed_bond/memento_used

# Store memento data in simple storage (used for restore + revival)
data modify storage evercraft:tamed_bond memento set from entity @s SelectedItem
execute store result score #tb_slot ec.temp run data get entity @s SelectedItemSlot

# Council #6 (2026-05-27): ALSO mirror to per-player keyed storage so the 1-tick
# restore_check race (two players failing same-tick stomping each other's `memento`)
# can be resolved by load_memento on the receiving side.
data modify storage evercraft:tamed_bond temp_memento set from entity @s SelectedItem
data modify storage evercraft:tamed_bond temp_args.UUID set from entity @s UUID
function evercraft:tamed_bond/store_memento with storage evercraft:tamed_bond temp_args
data remove storage evercraft:tamed_bond temp_args

# Check all revival conditions
function evercraft:tamed_bond/revive

# Schedule restore check for next tick (consume happens AFTER this function)
schedule function evercraft:tamed_bond/restore_check 1t
