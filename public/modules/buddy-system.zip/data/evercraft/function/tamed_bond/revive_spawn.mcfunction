# Tamed Bond — Spawn Revived Entity
# Reads pet_type from storage, summons the correct entity tamed to the player
# Runs as the player at their position
# memento data is already in storage evercraft:tamed_bond memento (set by on_use_memento)

# Council #6 (2026-05-27): refresh `memento` from the per-player keyed mirror so the read
# is per-player safe even if another player's on_use_memento has stomped the single-key path.
data modify storage evercraft:tamed_bond temp_args.UUID set from entity @s UUID
function evercraft:tamed_bond/load_memento with storage evercraft:tamed_bond temp_args
data remove storage evercraft:tamed_bond temp_args

# Store player UUID for taming
data modify storage evercraft:tamed_bond owner_uuid set from entity @s UUID

# Copy the pet's name for later application.
# 2026-06-20: clear first — a `set from` against a memento with no custom_name is a no-op, which
# previously left the PREVIOUS revive's name in place (an unnamed pet came back wearing the last
# pet's name). Same hazard for the appearance snapshot below.
data remove storage evercraft:tamed_bond revive_name
data modify storage evercraft:tamed_bond revive_name set from storage evercraft:tamed_bond memento.components."minecraft:custom_name"

# Copy the captured appearance snapshot (variant/collar/etc) for revive_finalize to re-apply
data remove storage evercraft:tamed_bond revive_appearance
data modify storage evercraft:tamed_bond revive_appearance set from storage evercraft:tamed_bond memento.components."minecraft:custom_data".appearance

# Summon by type — Owner is set in revive_finalize
# Council #6 (2026-05-27): every pet_type branches to the correct species so a revived
# Camel doesn't come back as a Donkey.
# Wolf
execute if data storage evercraft:tamed_bond {memento:{components:{"minecraft:custom_data":{pet_type:"wolf"}}}} at @s run summon wolf ~ ~ ~ {Tags:["ec.tb_revived"],CollarColor:14b}
# Cat
execute if data storage evercraft:tamed_bond {memento:{components:{"minecraft:custom_data":{pet_type:"cat"}}}} at @s run summon cat ~ ~ ~ {Tags:["ec.tb_revived"]}
# Horse
execute if data storage evercraft:tamed_bond {memento:{components:{"minecraft:custom_data":{pet_type:"horse"}}}} at @s run summon horse ~ ~ ~ {Tags:["ec.tb_revived"],Tame:1b}
# Parrot
execute if data storage evercraft:tamed_bond {memento:{components:{"minecraft:custom_data":{pet_type:"parrot"}}}} at @s run summon parrot ~ ~ ~ {Tags:["ec.tb_revived"]}
# Fox
execute if data storage evercraft:tamed_bond {memento:{components:{"minecraft:custom_data":{pet_type:"fox"}}}} at @s run summon fox ~ ~ ~ {Tags:["ec.tb_revived"]}
# Ocelot (2026-06-20) — custom-tamed; re-tamed to the reviver in retame_ocelot via revive_finalize's flag.
execute if data storage evercraft:tamed_bond {memento:{components:{"minecraft:custom_data":{pet_type:"ocelot"}}}} at @s run summon ocelot ~ ~ ~ {Tags:["ec.tb_revived"]}
# Donkey
execute if data storage evercraft:tamed_bond {memento:{components:{"minecraft:custom_data":{pet_type:"donkey"}}}} at @s run summon donkey ~ ~ ~ {Tags:["ec.tb_revived"],Tame:1b}
# Mule
execute if data storage evercraft:tamed_bond {memento:{components:{"minecraft:custom_data":{pet_type:"mule"}}}} at @s run summon mule ~ ~ ~ {Tags:["ec.tb_revived"],Tame:1b}
# Llama
execute if data storage evercraft:tamed_bond {memento:{components:{"minecraft:custom_data":{pet_type:"llama"}}}} at @s run summon llama ~ ~ ~ {Tags:["ec.tb_revived"],Tame:1b}
# Camel
execute if data storage evercraft:tamed_bond {memento:{components:{"minecraft:custom_data":{pet_type:"camel"}}}} at @s run summon camel ~ ~ ~ {Tags:["ec.tb_revived"],Tame:1b}
# Final catchall — unknown pet_type values (e.g. legacy mementos pre-Council #6) become donkey.
execute if data storage evercraft:tamed_bond {memento:{components:{"minecraft:custom_data":{pet_type:"other"}}}} at @s run summon donkey ~ ~ ~ {Tags:["ec.tb_revived"],Tame:1b}

# Apply owner UUID and name to the revived entity
execute as @e[tag=ec.tb_revived,limit=1,sort=nearest] run function evercraft:tamed_bond/revive_finalize
