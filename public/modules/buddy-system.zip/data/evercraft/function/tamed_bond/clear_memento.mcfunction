# Tamed Bond — Clear Per-Player Memento (macro)
$data remove storage evercraft:tamed_bond mementos."$(UUID)"
$data remove storage evercraft:tamed_bond slots."$(UUID)"
