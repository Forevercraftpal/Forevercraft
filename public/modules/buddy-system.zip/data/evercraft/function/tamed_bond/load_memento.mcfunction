# Tamed Bond — Load Per-Player Memento (macro)
# Copies from per-player keyed storage to working area
$data modify storage evercraft:tamed_bond memento set from storage evercraft:tamed_bond mementos."$(UUID)"
