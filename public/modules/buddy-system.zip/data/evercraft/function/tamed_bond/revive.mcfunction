# Tamed Bond — Moonbloom Revival Ceremony
# Checks all conditions for revival. If any fail, schedule restore.
# Runs as the player

# === CONDITION 1: Full Moon (moon_phase 0) ===
data modify storage evercraft:notify stage.c set value [{text:"The moon isn't full...",color:"red"},{text:" Wait for a full moon to perform the ceremony.",color:"gray"}]
scoreboard players set #ndur ec.temp 45
execute unless score #moon_phase ec.var matches 0 run function evercraft:util/notify/emit
execute unless score #moon_phase ec.var matches 0 run tag @s add ec.tb_restore
execute unless score #moon_phase ec.var matches 0 run return 0

# === CONDITION 2: Night Time (visual_time 13000-23000) ===
data modify storage evercraft:notify stage.c set value [{text:"It must be nighttime...",color:"red"},{text:" The ceremony requires darkness.",color:"gray"}]
scoreboard players set #ndur ec.temp 45
execute unless score #visual_time ec.var matches 13000..23000 run function evercraft:util/notify/emit
execute unless score #visual_time ec.var matches 13000..23000 run tag @s add ec.tb_restore
execute unless score #visual_time ec.var matches 13000..23000 run return 0

# === CONDITION 3: Open Sky ===
data modify storage evercraft:notify stage.c set value [{text:"You need open sky...",color:"red"},{text:" The moonlight must reach you.",color:"gray"}]
scoreboard players set #ndur ec.temp 45
execute at @s unless predicate evercraft:tamed_bond/open_sky run function evercraft:util/notify/emit
execute at @s unless predicate evercraft:tamed_bond/open_sky run tag @s add ec.tb_restore
execute at @s unless predicate evercraft:tamed_bond/open_sky run return 0

# === CONDITION 4: Torchflower in Offhand ===
data modify storage evercraft:notify stage.c set value [{text:"You need a Torchflower in your offhand!",color:"red"},{text:" Find one to complete the ceremony.",color:"gray"}]
scoreboard players set #ndur ec.temp 45
execute unless items entity @s weapon.offhand minecraft:torchflower run function evercraft:util/notify/emit
execute unless items entity @s weapon.offhand minecraft:torchflower run tag @s add ec.tb_restore
execute unless items entity @s weapon.offhand minecraft:torchflower run return 0

# === ALL CONDITIONS MET — PERFORM REVIVAL ===
# Consume the Torchflower from offhand
item replace entity @s weapon.offhand with minecraft:air

# Tag self for the duration of the ceremony (in-flight marker; player-side finalize below
# runs as @s directly, so this no longer needs to be re-found by a subject-flip — Council #54)
tag @s add ec.tb_reviving

# Get pet type from storage and spawn the revived entity
function evercraft:tamed_bond/revive_spawn

# === PLAYER-SIDE finalize (runs as @s = the unambiguous reviver, not a tag subject-flip) ===
# Council #54 (2026-06-06): horse mount-bond reset + memento clear were flipped via
# @a[tag=ec.tb_reviving,limit=1] inside revive_finalize (entity context) — that could pick
# the WRONG reviver if two ceremonies fired the same tick. revive_spawn set the horse flag.
# HORSE-SPECIFIC: reset mount bond UUID so the player rebonds to this horse
execute if data storage evercraft:tamed_bond {revive_was_horse:1b} run scoreboard players set @s ec.mt_uuid0 0
execute if data storage evercraft:tamed_bond {revive_was_horse:1b} run scoreboard players set @s ec.mt_uuid1 0
data modify storage evercraft:notify stage.c set value [{text:"Ride your revived horse for 5 minutes to restore the bond.",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 45
execute if data storage evercraft:tamed_bond {revive_was_horse:1b} run function evercraft:util/notify/emit
data remove storage evercraft:tamed_bond revive_was_horse

# 2026-06-20 FOX/OCELOT-SPECIFIC: these have no Owner NBT, so re-establish ownership to ME (the
# reviver) via the fox/ocelot ownership systems + persistent fake-owner. Runs here, as @s = the
# unambiguous reviver, mirroring the horse mount-bond handling above.
execute if entity @e[type=fox,tag=ec.tb_retame_fox,limit=1] run function evercraft:tamed_bond/retame_fox
execute if entity @e[type=ocelot,tag=ec.tb_retame_ocelot,limit=1] run function evercraft:tamed_bond/retame_ocelot

# Clear the per-player keyed memento for THIS reviver (Council #6 per-UUID hygiene)
data modify storage evercraft:tamed_bond temp_args.UUID set from entity @s UUID
function evercraft:tamed_bond/clear_memento with storage evercraft:tamed_bond temp_args
data remove storage evercraft:tamed_bond temp_args

tag @s remove ec.tb_reviving

# Dramatic effects
execute at @s run playsound minecraft:item.totem.use master @a[distance=..30,scores={ec.fx_snd=1..}] ~ ~ ~ 1.0 0.8
execute at @s run playsound minecraft:block.amethyst_block.chime master @a[distance=..30,scores={ec.fx_snd=1..}] ~ ~ ~ 0.8 0.5
execute at @s run particle minecraft:totem_of_undying ~ ~1 ~ 1 2 1 0.2 50 force
execute at @s run particle minecraft:soul ~ ~0.5 ~ 0.5 0.5 0.5 0.05 20 force
execute at @s run particle minecraft:soul_fire_flame ~ ~1 ~ 1 1 1 0.05 30 force

# Announce
data modify storage evercraft:notify stage.c set value [{text:"MOONBLOOM CEREMONY",color:"light_purple",bold:true}]
scoreboard players set #ndur ec.temp 50
function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Your friend has returned from beyond!",color:"yellow",italic:true}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit

title @s times 10 60 20
title @s title {text:" "}
title @s subtitle [{text:"A soul returns...",color:"light_purple",italic:true}]
