# Tamed Bond — Register Tamed Entity
# Runs as the tamed entity that passed the Owner check
# Gives a totem of undying in offhand — when the pet takes fatal damage,
# the totem fires, saving it at 1HP. We detect the consumed totem and
# create the memento + kill the entity cleanly.

tag @s add ec.tb_registered
tag @s add ec.tb_has_totem

# Give totem to offhand (invisible to players — wolves don't render offhand)
data modify entity @s equipment.offhand set value {id:"minecraft:totem_of_undying",count:1}
