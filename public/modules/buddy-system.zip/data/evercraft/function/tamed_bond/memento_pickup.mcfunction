# Tamed Bond — Totem Detection (10t schedule)
# Checks registered pets for consumed totem (= survived fatal damage)
# Creates memento, delivers to owner, kills entity

schedule function evercraft:tamed_bond/memento_pickup 10t

# Check all registered entities that still have a totem
# If their offhand is empty, the totem fired
execute as @e[tag=ec.tb_has_totem] run function evercraft:tamed_bond/check_death
