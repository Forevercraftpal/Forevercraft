# Tamed Bond — Reconstruct a fox/ocelot's fake-owner UUID
# Runs as the fox/ocelot. Foxes/ocelots aren't TamableAnimal, so a real Owner NBT key is dropped by
# the engine. Their owner UUID is instead kept in four persistent entity scoreboards (ec.tb_fown0-3),
# written at tame time (foxes/tame, ocelots/tame) and at revival (retame_fox/retame_ocelot).
# This rebuilds those four ints into a UUID int-array at `storage evercraft:tamed_bond fk_uuid`, so
# the rest of tamed_bond can treat fox/ocelot ownership exactly like a real Owner UUID.

data modify storage evercraft:tamed_bond fk_uuid set value [I;0,0,0,0]
execute store result storage evercraft:tamed_bond fk_uuid[0] int 1 run scoreboard players get @s ec.tb_fown0
execute store result storage evercraft:tamed_bond fk_uuid[1] int 1 run scoreboard players get @s ec.tb_fown1
execute store result storage evercraft:tamed_bond fk_uuid[2] int 1 run scoreboard players get @s ec.tb_fown2
execute store result storage evercraft:tamed_bond fk_uuid[3] int 1 run scoreboard players get @s ec.tb_fown3
