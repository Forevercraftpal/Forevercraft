# Tamed Bond — Finalize Revived Entity
# Runs as the newly spawned tamed entity
# Applies owner UUID and custom name from storage

# Set owner UUID (tames to the player)
data modify entity @s Owner set from storage evercraft:tamed_bond owner_uuid

# Set custom name from stored memento (if pet was named)
execute if data storage evercraft:tamed_bond revive_name run data modify entity @s CustomName set from storage evercraft:tamed_bond revive_name

# === 2026-06-20: Restore the captured appearance so the revived pet is identical to the one that
# fell — same breed/variant, same collar colour, same gear. Each line is a no-op when that field is
# absent from the snapshot (so a wolf doesn't get a Variant, a cat doesn't get a Strength, etc.).
# These run the same tick as the summon, so there's no default-look flash. CollarColor here overrides
# the placeholder CollarColor:14b that revive_spawn summons wolves with.
data modify entity @s variant set from storage evercraft:tamed_bond revive_appearance.variant
data modify entity @s Variant set from storage evercraft:tamed_bond revive_appearance.Variant
data modify entity @s CollarColor set from storage evercraft:tamed_bond revive_appearance.CollarColor
data modify entity @s Type set from storage evercraft:tamed_bond revive_appearance.Type
data modify entity @s Strength set from storage evercraft:tamed_bond revive_appearance.Strength
data modify entity @s Age set from storage evercraft:tamed_bond revive_appearance.Age

# Mark as registered so tamed_bond system re-arms totem
tag @s add ec.tb_registered

# 2026-06-20: foxes/ocelots have no Owner NBT — flag them so the player-side re-tame (revive.mcfunction,
# where @s is the unambiguous reviver) can restore the fox/ocelot ownership systems + persistent fake-owner.
execute if entity @s[type=fox] run tag @s add ec.tb_retame_fox
execute if entity @s[type=ocelot] run tag @s add ec.tb_retame_ocelot

# Remove temp tag
tag @s remove ec.tb_revived

# === HORSE-SPECIFIC: flag a horse revive so the player-side mount-bond reset can run ===
# Council #54 (2026-06-06): the mount-bond reset + memento clear are PLAYER-side and were
# subject-flipping via @a[tag=ec.tb_reviving,limit=1] (no UUID narrowing) — two simultaneous
# Moonbloom ceremonies could land the flip on the WRONG reviver. The acting player IS the
# unambiguous function-executor back in `revive` (per-invocation), so those branches now run
# there as @s. Here we only record the entity-derived fact (was this a horse?) for that step.
data modify storage evercraft:tamed_bond revive_was_horse set value 0b
execute if entity @s[type=horse] run data modify storage evercraft:tamed_bond revive_was_horse set value 1b

# Visual: particles around revived pet
execute at @s run particle minecraft:heart ~ ~0.5 ~ 0.3 0.3 0.3 0.1 10 force
execute at @s run particle minecraft:soul ~ ~0.5 ~ 0.3 0.5 0.3 0.02 8 force
