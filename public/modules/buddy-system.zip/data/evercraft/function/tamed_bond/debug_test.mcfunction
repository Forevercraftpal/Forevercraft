# Manual debug — run with: /function evercraft:tamed_bond/debug_test

tellraw @s [{text:"[TB DEBUG] ",color:"yellow"},{text:"=== Manual Test ===",color:"white"}]

# Count all tameable companions
execute store result score #tb_total ec.temp if entity @e[type=#evercraft:tameable_companions]
tellraw @s [{text:"[TB DEBUG] ",color:"yellow"},{text:"Total tameable companions found: ",color:"gray"},{"score":{"name":"#tb_total","objective":"ec.temp"},"color":"aqua"}]

# Count wolves specifically
execute store result score #tb_total ec.temp if entity @e[type=wolf]
tellraw @s [{text:"[TB DEBUG] ",color:"yellow"},{text:"Wolves found: ",color:"gray"},{"score":{"name":"#tb_total","objective":"ec.temp"},"color":"aqua"}]

# Check nearest wolf for fields
execute as @e[type=wolf,limit=1,sort=nearest] run tellraw @a [{text:"[TB DEBUG] ",color:"yellow"},{text:"Nearest wolf: ",color:"gray"},{"selector":"@s","color":"white"}]
execute as @e[type=wolf,limit=1,sort=nearest] if data entity @s Owner run tellraw @a [{text:"[TB DEBUG] ",color:"yellow"},{text:"  Owner: EXISTS",color:"green"}]
execute as @e[type=wolf,limit=1,sort=nearest] unless data entity @s Owner run tellraw @a [{text:"[TB DEBUG] ",color:"yellow"},{text:"  Owner: MISSING",color:"red"}]
execute as @e[type=wolf,limit=1,sort=nearest] if data entity @s owner run tellraw @a [{text:"[TB DEBUG] ",color:"yellow"},{text:"  owner (lowercase): EXISTS",color:"green"}]
execute as @e[type=wolf,limit=1,sort=nearest] unless data entity @s owner run tellraw @a [{text:"[TB DEBUG] ",color:"yellow"},{text:"  owner (lowercase): MISSING",color:"red"}]
execute as @e[type=wolf,limit=1,sort=nearest] if data entity @s Tame run tellraw @a [{text:"[TB DEBUG] ",color:"yellow"},{text:"  Tame: EXISTS",color:"green"}]
execute as @e[type=wolf,limit=1,sort=nearest] unless data entity @s Tame run tellraw @a [{text:"[TB DEBUG] ",color:"yellow"},{text:"  Tame: MISSING",color:"red"}]
execute as @e[type=wolf,limit=1,sort=nearest] if data entity @s tame run tellraw @a [{text:"[TB DEBUG] ",color:"yellow"},{text:"  tame (lowercase): EXISTS",color:"green"}]

# Try to dump all NBT keys by reading specific known fields
execute as @e[type=wolf,limit=1,sort=nearest] run data get entity @s
