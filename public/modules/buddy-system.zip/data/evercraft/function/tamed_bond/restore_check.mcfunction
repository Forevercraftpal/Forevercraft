# Tamed Bond — Restore Check (1-tick delay)
# If any player has the restore tag, give back their memento

execute as @a[tag=ec.tb_restore] run function evercraft:tamed_bond/revive_fail
tag @a remove ec.tb_restore
