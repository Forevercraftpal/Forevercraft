# Tamed Bond — Store Memento Per-Player (macro)
# Stores memento data under player's UUID to avoid multiplayer collision
# Called from check_owner (post-delivery, @s = recipient player) AND on_use_memento (@s = consumer).
# Council #6 (2026-05-27): temp_slot dropped — slot is unknown at death-time and only meaningful at consume-time.
# Caller must set: storage evercraft:tamed_bond temp_args.UUID set from entity @s UUID
# Caller must populate: storage evercraft:tamed_bond temp_memento set from <source>
$data modify storage evercraft:tamed_bond mementos."$(UUID)" set from storage evercraft:tamed_bond temp_memento
