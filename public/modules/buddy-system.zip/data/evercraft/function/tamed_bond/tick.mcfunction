# Tamed Bond — Main Tick (5s schedule)
# Registration + totem maintenance

schedule function evercraft:tamed_bond/tick 5s

execute unless entity @a run return 0

# Register new tamed entities (check Owner field existence)
# Perf retrofit M4 (2026-06-14): enumerate only tameables within 16b of a player instead of every
# loaded animal — a freshly-tamed pet is beside its owner, so it's still caught; distant loaded
# animals register when a player approaches. (The re-arm line below is already tag-bounded.)
execute as @a at @s as @e[type=#evercraft:tameable_companions,tag=!ec.tb_registered,distance=..16] if data entity @s Owner run function evercraft:tamed_bond/register

# 2026-06-20: foxes/ocelots have no Owner NBT — register them by their tamed tag (register doesn't
# read Owner). They now arm the bond totem and drop a memento on death like wolves/cats.
execute as @a at @s as @e[tag=ec.fox_tamed,tag=!ec.tb_registered,distance=..16] run function evercraft:tamed_bond/register
execute as @a at @s as @e[tag=ec.ocelot_tamed,tag=!ec.tb_registered,distance=..16] run function evercraft:tamed_bond/register

# Re-arm: give totems to registered entities missing one (e.g. after datapack update)
execute as @e[tag=ec.tb_registered,tag=!ec.tb_has_totem,tag=!ec.tb_dying] run function evercraft:tamed_bond/register
