# Best Buddy Combat — Apply Weapon Bonus (caller-stub)
# @s = player who owns the best buddy (caller: best/combat/attack:17)
# Council #5 (D3, 2026-05-27) moved temp_equip to per-player keying ($(pid)).
# Wiring Audit #4 (2026-05-28 W1.2) fixed dead-storage-path read + actually applied bonus damage.

# Per-player storage key (companion.id)
execute store result storage evercraft:buddy equip_arg.pid int 1 run scoreboard players get @s companion.id

# Gate + apply: only fire if THIS player's best buddy has a weapon stored.
# Flat +4 bonus to nearest hostile being attacked by this best buddy.
function evercraft:buddy/best/combat/apply_weapon_inner with storage evercraft:buddy equip_arg
