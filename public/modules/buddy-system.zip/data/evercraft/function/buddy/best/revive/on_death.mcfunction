# Best Buddy — On Death
# @s = player whose best buddy just died (subject-flipped by on_death_dispatch)
# Creates a memento item in player inventory, starts 30-minute auto-revive timer
# Council #5 (D2-tuning, 2026-05-27): timer raised 600→1800 (30 min); penalty -100→-250

# Mark best buddy as dead
scoreboard players set @s ec.bd_best_dead 1
scoreboard players set @s ec.bd_best_active 0

# Start 30-minute revive timer (1800 seconds)
scoreboard players set @s ec.bd_best_revive 1800

# Give memento item to player (a heart-shaped item they carry)
give @s minecraft:echo_shard[custom_name={text:"Buddy's Spirit",color:"#FFD700",italic:false},custom_data={buddy_memento:1b},enchantment_glint_override=true,lore=[{text:"Your best buddy's spirit lingers...",color:"gray",italic:false},{text:"Keep it close. It will return.",color:"yellow",italic:false}]] 1

# Death penalty
function evercraft:buddy/points/death_penalty

# Clean up entity tags (entity is dead/gone)
# The actual entity cleanup happens via vanilla death

data modify storage evercraft:notify stage.c set value [{text:"Your Best Buddy has fallen!",color:"dark_red",bold:true}]
scoreboard players set #ndur ec.temp 50
function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Keep the ",color:"gray"},{text:"Buddy's Spirit",color:"#FFD700"},{text:" in your inventory or bundle.",color:"gray"}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"It will revive in ",color:"gray"},{text:"30 minutes",color:"green"},{text:".",color:"gray"}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit

# Gated bespoke loss knell — REPLACES the off-palette wolf.death.
execute at @s run function evercraft:fx/companion/buddy_death
