# Best Buddy Revive — on-death dispatcher (subject flip)
# Council #5 (D2, 2026-05-27): called from tamed_bond/on_pet_death.
# @s = the dying Best Buddy entity (totem fired, at 1HP).
# #Search companion.id is already set to @s ec.bd_owner_id by the caller.
#
# Flips subject to the owning player and runs the canonical memento + 30-min timer ceremony.

execute as @a[predicate=evercraft:companions/check_id] run function evercraft:buddy/best/revive/on_death
