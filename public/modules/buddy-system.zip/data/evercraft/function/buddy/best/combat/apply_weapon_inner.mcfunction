# Best Buddy Combat — Apply Weapon Bonus (inner macro)
# @s = owning player. $(pid) = player's companion.id.
# If the per-player weapon slot has data, deal flat +4 bonus to nearest
# hostile being attacked by this best buddy (best buddy within 32b of owner
# per attack:17 gate; hostile within 8b of best buddy per find_target:6,9).
# Wired by Wiring Audit #4 (2026-05-28 W1.2). Tune flat-bonus value below.

$execute unless data storage evercraft:buddy temp_equip.$(pid).weapon run return fail

# Weapon tiers (Phase 5 follow-up): Common=+2, Uncommon=+3, Rare=+4, Ornate=+5, Exquisite=+7, Mythical=+10.
# For v1.0, flat +4 bonus damage on the hostile this best buddy is engaging.
execute at @s as @e[tag=ec.bd_best,type=#evercraft:tameable_companions,distance=..32,limit=1,sort=nearest] at @s as @e[type=#evercraft:hostile,distance=..8,limit=1,sort=nearest] run damage @s 4 minecraft:mob_attack by @e[tag=ec.bd_best,type=#evercraft:tameable_companions,limit=1,sort=nearest]
