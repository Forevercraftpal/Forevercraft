# Best Buddy — Auto Revive
# @s = player whose best buddy revive timer just hit 0

# Remove the memento item
clear @s minecraft:echo_shard[custom_data~{buddy_memento:1b}] 1

# Determine mob type to summon
execute store result storage evercraft:buddy temp.revive_type int 1 run scoreboard players get @s ec.bd_best_type

# Summon the buddy entity at player's location
execute at @s run function evercraft:buddy/best/revive/summon_buddy with storage evercraft:buddy temp

# Mark as alive
scoreboard players set @s ec.bd_best_dead 0
scoreboard players set @s ec.bd_best_active 1
scoreboard players set @s ec.bd_best_revive 0

# Announcement
data modify storage evercraft:notify stage.c set value [{text:"Your Best Buddy has returned!",color:"green",bold:true}]
scoreboard players set #ndur ec.temp 50
function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"The bond between you could not be broken.",color:"yellow"}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit

# Gated bespoke resurrection swell (keeps respawn_anchor.charge on-palette).
execute at @s run function evercraft:fx/companion/revive
