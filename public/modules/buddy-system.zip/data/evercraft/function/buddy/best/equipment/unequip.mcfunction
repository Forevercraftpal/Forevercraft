# Best Buddy Equipment — Unequip (macro: per-player storage)
# @s = player
# $(pid) = player's companion.id (stashed by caller via 'with storage evercraft:buddy equip_arg')
# Slot determined by @s ec.bd_equip_slot (0=weapon, 1=artifact, 2-4=accessory)
# Council #5 (D3, 2026-05-27): wired as GUI button; per-player keyed storage;
# player-scoped ec.bd_equip_slot (was shared #bd_equip_slot ec.temp scratch).

execute unless score @s ec.bd_best_active matches 1 run return fail

# Weapon slot — copy from per-player storage to player via item entity
$execute if score @s ec.bd_equip_slot matches 0 if data storage evercraft:buddy temp_equip.$(pid).weapon run function evercraft:buddy/best/equipment/return_item_weapon with storage evercraft:buddy equip_arg
$execute if score @s ec.bd_equip_slot matches 0 run data remove storage evercraft:buddy temp_equip.$(pid).weapon

# Artifact slot — copy from per-player storage to player via item entity
$execute if score @s ec.bd_equip_slot matches 1 if data storage evercraft:buddy temp_equip.$(pid).artifact run function evercraft:buddy/best/equipment/return_item_artifact with storage evercraft:buddy equip_arg
$execute if score @s ec.bd_equip_slot matches 1 run data remove storage evercraft:buddy temp_equip.$(pid).artifact

# Clear slot sentinel after use
scoreboard players reset @s ec.bd_equip_slot

data modify storage evercraft:notify stage.c set value [{text:"Equipment removed from your Best Buddy.",color:"yellow"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:item.armor.unequip_chain master @s ~ ~ ~ 0.8 1
