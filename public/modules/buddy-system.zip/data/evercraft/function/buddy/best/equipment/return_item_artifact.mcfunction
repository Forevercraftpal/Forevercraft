# Return artifact from buddy equipment storage to player (macro: per-player)
# @s = player
# $(pid) = player's companion.id (stashed by caller)
# Council #5 (D3, 2026-05-27): per-player keyed storage; distance-gate selector
# to avoid cross-fire on the spawned item entity.

execute at @s run summon item ~ ~ ~ {Tags:["ec.temp_return"],Item:{id:"minecraft:stone",count:1},PickupDelay:0}
$execute at @s run data modify entity @e[tag=ec.temp_return,distance=..0.5,sort=nearest,limit=1] Item set from storage evercraft:buddy temp_equip.$(pid).artifact
execute at @s run tag @e[tag=ec.temp_return,distance=..0.5,sort=nearest,limit=1] remove ec.temp_return
