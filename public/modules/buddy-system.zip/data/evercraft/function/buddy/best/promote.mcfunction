# Best Buddy — Promote (Spiritbound buddy → Best Buddy)
# @s = player who wants to promote their buddy
# Called from GUI (Phase 5) or via command for testing

# Verify buddy is Spiritbound (tier 6)
data modify storage evercraft:notify stage.c set value [{text:"Your buddy must reach Spiritbound (10,000 points) first!",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute unless score @s ec.bd_tier matches 6 run function evercraft:util/notify/emit
execute unless score @s ec.bd_tier matches 6 run return fail

# Check if already has a best buddy
data modify storage evercraft:notify stage.c set value [{text:"You already have a Best Buddy! Release your current one first.",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute if score @s ec.bd_best_type matches 1.. run function evercraft:util/notify/emit
execute if score @s ec.bd_best_type matches 1.. run return fail

# Promote: copy buddy data to best buddy slots
scoreboard players operation @s ec.bd_best_uuid0 = @s ec.bd_uuid0
scoreboard players operation @s ec.bd_best_uuid1 = @s ec.bd_uuid1
scoreboard players operation @s ec.bd_best_type = @s ec.bd_type_id
scoreboard players set @s ec.bd_best_active 1
scoreboard players set @s ec.bd_best_dead 0

# Tag the entity as best buddy
execute as @e[tag=ec.bd_buddy,type=#evercraft:tameable_companions,distance=..64,limit=1] run tag @s add ec.bd_best

# Announcement
data modify storage evercraft:notify stage.c set value [{text:"★ ",color:"#FF4500"},{text:"BEST BUDDY",color:"#FF4500",bold:true},{text:" ★",color:"#FF4500"}]
scoreboard players set #ndur ec.temp 50
function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Your buddy has been promoted to your ",color:"yellow"},{text:"Best Buddy",color:"#FF4500",bold:true},{text:"!",color:"yellow"}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"It will now fight by your side, equip artifacts,",color:"gray"}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"and earn double friendship points.",color:"gray"}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit

# Effects (gated bespoke APEX fanfare — REPLACES the off-palette ender_dragon.growl).
execute at @s run function evercraft:fx/companion/promote_best
