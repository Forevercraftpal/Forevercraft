# Best Buddy Equipment — Equip Artifact (macro: per-player storage)
# @s = player
# $(pid) = player's companion.id (stashed by caller in check_tab_clicks)
# Council #5 (D3, 2026-05-27): per-player keyed storage prevents cross-player stomp.

# Verify best buddy exists
execute unless score @s ec.bd_best_active matches 1 run return fail

# Store artifact from player's mainhand to per-player buddy storage
$data modify storage evercraft:buddy temp_equip.$(pid).artifact set from entity @s SelectedItem

# Confirmation
data modify storage evercraft:notify stage.c set value [{text:"Artifact equipped to your Best Buddy!",color:"green"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:item.armor.equip_diamond master @s ~ ~ ~ 0.8 1.2
