# Buddy Designation — Bond Nearest Tamed Animal (one-click, from the Companion Catalogue button)
# @s = player who clicked [Bond Nearest Animal] in the Buddy tab.
#
# Why this exists (2026-06-20): the original designation trigger was "sneak + use the catalogue
# near a tamed mob". That path is dead now for two reasons:
#   1. The catalogue is opened through the Eternal Codex book, whose sneak+use is hard-bound to
#      "cycle tab" (ecodex/process_use), so the catalogue's sneak+use designate-redirect can never
#      fire.
#   2. Even when it did fire, `confirm` zeroed ec.bd_designating but left ec.bd_des_uuid0 set, so
#      buddy/tick's `timeout` stripped ec.bd_designating_target before the player clicked [Yes] —
#      `accept` then always reported "That animal wandered too far away."
# This button does a clean single-click designation of the closest tamed animal the player owns,
# reusing the exact same finalize chain (check_existing -> naming -> set_buddy_data).

# Establish ownership scope for the check_owner predicate AND the naming flow (#bd_owner).
scoreboard players operation #bd_owner ec.temp = @s companion.id
scoreboard players operation #Search companion.id = @s companion.id

# Clear any stale window state for THIS player so buddy/tick's timeout can't strip the fresh target
# mid-naming (the bug that broke the old flow). With ec.bd_des_uuid0 == 0, timeout never fires.
scoreboard players set @s ec.bd_designating 0
scoreboard players set @s ec.bd_des_uuid0 0
scoreboard players set @s ec.bd_des_uuid1 0

# Drop any orphaned designating target left on one of this player's animals by a prior abandoned bond.
tag @e[type=#evercraft:tameable_companions,tag=ec.bd_designating_target,predicate=evercraft:buddy/check_owner] remove ec.bd_designating_target

# Find + tag the nearest owned tamed animal within 8 blocks. ec.tame_protected is stamped every 5s
# on every owned tameable within 16b of a player (tamed_protection/tick), so a pet beside you qualifies.
scoreboard players set #bd_found ec.temp 0
execute at @s as @e[type=#evercraft:tameable_companions,tag=ec.tame_protected,distance=..8,limit=1,sort=nearest] run function evercraft:buddy/designate/bond_nearest_tag

# Nothing nearby -> tell the player and stop.
data modify storage evercraft:notify stage.c set value [{text:"No tamed animal of yours is nearby. Stand within 8 blocks of your pet, then try again.",color:"gray"}]
scoreboard players set #ndur ec.temp 50
execute if score #bd_found ec.temp matches 0 run function evercraft:util/notify/emit
execute if score #bd_found ec.temp matches 0 run return 0

# Duplicate-type guard (identical to the old sneak+click accept path).
function evercraft:buddy/designate/check_existing
execute if score #bd_already ec.temp matches 1 run tag @e[tag=ec.bd_confirm_target] remove ec.bd_confirm_target
execute if score #bd_already ec.temp matches 1 run tag @e[tag=ec.bd_designating_target,predicate=evercraft:buddy/check_owner] remove ec.bd_designating_target
execute if score #bd_already ec.temp matches 1 run return 0

# Hand off to the naming flow, which finalizes via set_buddy_data:
#   named mob  -> [Keep] / [Rename] prompt
#   unnamed    -> Buddy Charter book to write + sign
execute as @e[tag=ec.bd_confirm_target,limit=1] if data entity @s CustomName run function evercraft:buddy/naming/ask_rename
execute as @e[tag=ec.bd_confirm_target,limit=1] unless data entity @s CustomName run function evercraft:buddy/naming/give_charter

# Drop the transient confirm tag; the designating target stays until set_buddy_data consumes it.
tag @e[tag=ec.bd_confirm_target] remove ec.bd_confirm_target
