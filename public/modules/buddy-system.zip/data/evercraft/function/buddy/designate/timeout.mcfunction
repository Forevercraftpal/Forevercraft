# Buddy Designation — Timeout (40-tick window expired)
# @s = player whose designation window expired

# Only act if they HAD a target
execute unless score @s ec.bd_des_uuid0 matches 1.. unless score @s ec.bd_des_uuid0 matches ..-1 run return fail

# Clean up
scoreboard players set @s ec.bd_designating 0
scoreboard players set @s ec.bd_des_uuid0 0
scoreboard players set @s ec.bd_des_uuid1 0

# Wiring Audit #4 (2026-05-28 W3b/Ra16): clean up only this player's designating_target.
# Global-clear was wiping every other concurrent designation in the dimension.
scoreboard players operation #Search companion.id = @s companion.id
tag @e[tag=ec.bd_designating_target,predicate=evercraft:buddy/check_owner] remove ec.bd_designating_target
