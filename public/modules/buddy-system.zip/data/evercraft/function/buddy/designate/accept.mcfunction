# Buddy Designation — Accept ([Yes] clicked)
# @s = player who confirmed buddy designation

# Reset trigger
scoreboard players set @s ec.bd_confirm 0
scoreboard players enable @s ec.bd_confirm

# Wiring Audit #4 (2026-05-28 W3b/Ra16): scope all ec.bd_designating_target
# selectors to @s's own designation via predicate=check_owner (mob is stamped
# with ec.bd_owner_id at start_window:21).
scoreboard players operation #Search companion.id = @s companion.id

# Ra21 (2026-05-28): dropped dead `#bd_target0/1 ec.temp` writes; never read.

# Find the target entity (within 10 blocks — may have moved slightly)
tag @e[type=#evercraft:tameable_companions,tag=ec.bd_designating_target,distance=..10,predicate=evercraft:buddy/check_owner,limit=1] add ec.bd_confirm_target
data modify storage evercraft:notify stage.c set value [{text:"That animal wandered too far away. Try again!",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute unless entity @e[tag=ec.bd_confirm_target,limit=1] run function evercraft:util/notify/emit
execute unless entity @e[tag=ec.bd_confirm_target,limit=1] run return fail

# Check if player already has a buddy of this mob type
function evercraft:buddy/designate/check_existing

# If check_existing set #bd_already to 1, stop — global-clear only this player's tagged mob
execute if score #bd_already ec.temp matches 1 run tag @e[tag=ec.bd_confirm_target] remove ec.bd_confirm_target
execute if score #bd_already ec.temp matches 1 run tag @e[tag=ec.bd_designating_target,predicate=evercraft:buddy/check_owner] remove ec.bd_designating_target
execute if score #bd_already ec.temp matches 1 run return fail

# Check if mob already has a CustomName
execute as @e[tag=ec.bd_confirm_target,limit=1] if data entity @s CustomName run function evercraft:buddy/naming/ask_rename
execute as @e[tag=ec.bd_confirm_target,limit=1] unless data entity @s CustomName run function evercraft:buddy/naming/give_charter

# Clean up temp tags
tag @e[tag=ec.bd_confirm_target] remove ec.bd_confirm_target
