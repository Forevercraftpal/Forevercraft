# Buddy Designation — Tag the chosen animal for one-click bonding
# @s = the nearest owned tamed animal (chosen by bond_nearest).
# #bd_owner ec.temp = the owning player's companion.id (set by the caller).
#
# Stamps the same markers start_window + accept would have: ec.bd_designating_target (consumed by
# set_buddy_data), ec.bd_confirm_target (consumed by check_existing + the naming hand-off), and
# ec.bd_owner_id (so the check_owner predicate scopes selectors to this player).

scoreboard players set #bd_found ec.temp 1
tag @s add ec.bd_designating_target
tag @s add ec.bd_confirm_target
scoreboard players operation @s ec.bd_owner_id = #bd_owner ec.temp
