# Buddy Designation — Start 40-Tick Window
# @s = player who sneak+clicked near a tamed mob
# Sets designation timer and stores target mob UUID

# Store target mob UUID in player scoreboards
scoreboard players operation @s ec.bd_des_uuid0 = #bd_mob_uuid0 ec.temp
scoreboard players operation @s ec.bd_des_uuid1 = #bd_mob_uuid1 ec.temp

# Start 40-tick countdown (2 ticks at 20t schedule = checked ~2 times)
scoreboard players set @s ec.bd_designating 40

# Tag the target entity for visual feedback + stamp ec.bd_owner_id so per-player
# predicate scope works for the 12-site designate cluster.
# Wiring Audit #4 (2026-05-28 W3b/Ra16+Ra20):
# - Stamp ec.bd_owner_id on the designating mob from @s companion.id (was set only at
#   set_buddy_data:31, leaving the entire designate window cross-fire-prone).
# - Dropped the broken `if score @s ec.temp = #bd_mob_uuid0 ec.temp` gate (Ra20 — the
#   mob entity never has ec.temp set; gate fails-open). distance=..10,limit=1,sort=nearest
#   is already narrow.
execute as @e[type=#evercraft:tameable_companions,tag=ec.tame_protected,distance=..10,limit=1,sort=nearest] run tag @s add ec.bd_designating_target
execute store result score @e[type=#evercraft:tameable_companions,tag=ec.bd_designating_target,distance=..10,limit=1] ec.bd_owner_id run scoreboard players get @s companion.id

# Notify player
data modify storage evercraft:notify stage.c set value [{text:"Sneak + use the catalogue again to bond with this animal!",color:"yellow"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
