# Buddy Designation — Decline ([No] clicked)
# @s = player who declined

scoreboard players set @s ec.bd_confirm 0
scoreboard players enable @s ec.bd_confirm
scoreboard players set @s ec.bd_designating 0

# Wiring Audit #4 (2026-05-28 W3b/Ra16): clean up only this player's designating_target.
# Global-clear was wiping every other concurrent designation in the dimension.
scoreboard players operation #Search companion.id = @s companion.id
tag @e[tag=ec.bd_designating_target,predicate=evercraft:buddy/check_owner] remove ec.bd_designating_target

data modify storage evercraft:notify stage.c set value [{text:"Maybe another time!",color:"gray"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
