$data modify storage evercraft:notify stage.c set value [{text:"A bond has been forged! ",color:"yellow"},{text:"$(mob_type)",color:"gold",bold:true},{text:" is now your ",color:"yellow"},{text:"Buddy",color:"#FFD700",bold:true},{text:"!",color:"yellow"}]
scoreboard players set #ndur ec.temp 50
function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Spend time together to grow your friendship.",color:"gray"}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit
