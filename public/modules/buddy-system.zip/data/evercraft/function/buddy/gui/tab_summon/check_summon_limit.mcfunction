# Tab 3: Check Summon Limit
# @s = player attempting to summon
# Sets #bd_summon_ok ec.temp = 1 if allowed, 0 if denied
# Council #5 (D4, 2026-05-27): scoped to @s's OWN best/buddy via predicate=check_owner.
# Caller (do_summon) sets #Search companion.id = @s companion.id before calling.

scoreboard players set #bd_summon_ok ec.temp 1

# Best buddy: unlimited summons — but only if THIS player owns a best buddy
execute if entity @e[type=#evercraft:tameable_companions,tag=ec.bd_best,predicate=evercraft:buddy/check_owner,limit=1] run return 0

# Buddy: 4/day — gated to THIS player's buddy
execute if entity @e[type=#evercraft:tameable_companions,tag=ec.bd_buddy,predicate=evercraft:buddy/check_owner,limit=1] if score @s ec.bd_summon_ct matches 4.. run scoreboard players set #bd_summon_ok ec.temp 0
data modify storage evercraft:notify stage.c set value [{text:"Your buddy has been summoned 4 times today. Try again tomorrow!",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute if entity @e[type=#evercraft:tameable_companions,tag=ec.bd_buddy,predicate=evercraft:buddy/check_owner,limit=1] if score @s ec.bd_summon_ct matches 4.. run function evercraft:util/notify/emit
execute if score #bd_summon_ok ec.temp matches 0 run return fail

# Regular tamed: 1/day (player has NO buddy of their own)
execute unless entity @e[type=#evercraft:tameable_companions,tag=ec.bd_buddy,predicate=evercraft:buddy/check_owner,limit=1] if score @s ec.bd_summon_ct matches 1.. run scoreboard players set #bd_summon_ok ec.temp 0
data modify storage evercraft:notify stage.c set value [{text:"You can only summon regular tamed animals once per day.",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute unless entity @e[type=#evercraft:tameable_companions,tag=ec.bd_buddy,predicate=evercraft:buddy/check_owner,limit=1] if score @s ec.bd_summon_ct matches 1.. run function evercraft:util/notify/emit
