# Tab 3: Try Teleport — Check UUID match then teleport this entity to the clicker
# @s = candidate tamed entity (owned by clicker, filtered via predicate at caller)
# #bd_summon_uuid0/1 ec.temp = target UUID (locally stashed by do_summon)
# #Search companion.id already set to clicker's companion.id
# Council #5 (D4, 2026-05-27): tp THIS @s (not a globally-selected entity).
# Sets #bd_summon_ok = 2 on success so caller can gate side effects.

execute store result score #bd_check_u0 ec.temp run data get entity @s UUID[0]
execute unless score #bd_check_u0 ec.temp = #bd_summon_uuid0 ec.temp run return fail

execute store result score #bd_check_u1 ec.temp run data get entity @s UUID[1]
execute unless score #bd_check_u1 ec.temp = #bd_summon_uuid1 ec.temp run return fail

# Wiring Audit #4 (2026-05-28 W3c/Ra15) — defense-in-depth owner-guard.
# Confirm THIS pet's Owner NBT UUID matches the clicker. Prevents pet-stealing
# via UUID-collision or build_list cross-owner visibility regression. Pets without
# vanilla Owner NBT (fox/ocelot/happy_ghast — use Trusted/Trusting/scoreboard) are
# skipped by this gate; for them, the build_list visibility scope IS the only guard.
execute if data entity @s Owner store result score #bd_check_o0 ec.temp run data get entity @s Owner[0]
execute if data entity @s Owner unless score #bd_check_o0 ec.temp = #bd_clicker_u0 ec.temp run return fail
execute if data entity @s Owner store result score #bd_check_o1 ec.temp run data get entity @s Owner[1]
execute if data entity @s Owner unless score #bd_check_o1 ec.temp = #bd_clicker_u1 ec.temp run return fail

# UUID matches — teleport @s (this entity) to the clicker
# (#Search companion.id is the clicker's companion.id, set by do_summon caller)
execute at @a[predicate=evercraft:companions/check_id,limit=1] run tp @s ~ ~ ~

# Mark success so caller can confirm
scoreboard players set #bd_summon_ok ec.temp 2
