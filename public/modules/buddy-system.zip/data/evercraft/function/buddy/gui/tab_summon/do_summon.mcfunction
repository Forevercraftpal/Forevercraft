# Tab 3: Do Summon — Teleport a tamed animal to the player
# @s = player
# @s ec.bd_summon_uuid0/1 = UUID of animal to summon (player-scoped)
# Council #5 (D4, 2026-05-27): race fixes — predicate=check_owner on selector,
# player-scoped UUID scratch (was shared #bd_summon_uuid0/1 ec.temp), and
# check_summon_limit scoped to @s's own buddies.

# Set #Search for ownership predicate (used by check_owner + check_summon_limit)
scoreboard players operation #Search companion.id = @s companion.id

# Check summon limit (now scoped to @s's own buddies)
function evercraft:buddy/gui/tab_summon/check_summon_limit

# If limit exceeded, check_summon_limit returns fail
execute if score #bd_summon_ok ec.temp matches 0 run return fail

# Stash player-scoped UUIDs into the shared scratch try_tp consumes
# (try_tp is shared infrastructure; we keep the local copy contract here)
scoreboard players operation #bd_summon_uuid0 ec.temp = @s ec.bd_summon_uuid0
scoreboard players operation #bd_summon_uuid1 ec.temp = @s ec.bd_summon_uuid1

# Wiring Audit #4 (2026-05-28 W3c/Ra15) — defense-in-depth owner-guard.
# Stash clicker's UUID so try_tp can compare against the candidate pet's Owner NBT.
# Prevents pet-stealing: even if a click slips through, try_tp refuses to tp pets
# this player does not own (Owner UUID mismatch -> return fail).
execute store result score #bd_clicker_u0 ec.temp run data get entity @s UUID[0]
execute store result score #bd_clicker_u1 ec.temp run data get entity @s UUID[1]

# Find the entity by UUID and teleport.
# No limit=1 — iterate all tame_protected; try_tp UUID-matches + owner-checks; non-matching return fail.
execute as @e[type=#evercraft:tameable_companions,tag=ec.tame_protected] run function evercraft:buddy/gui/tab_summon/try_tp

# Only increment if try_tp actually succeeded (sets #bd_summon_ok ec.temp = 2 on success)
execute if score #bd_summon_ok ec.temp matches 2 run scoreboard players add @s ec.bd_summon_ct 1
data modify storage evercraft:notify stage.c set value [{text:"Your animal has been summoned!",color:"green"}]
scoreboard players set #ndur ec.temp 45
execute if score #bd_summon_ok ec.temp matches 2 run function evercraft:util/notify/emit
execute if score #bd_summon_ok ec.temp matches 2 at @s if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.enderman.teleport master @s ~ ~ ~ 0.8 1.2

# Clear scratch + player-scoped uuids
scoreboard players reset #bd_summon_uuid0 ec.temp
scoreboard players reset #bd_summon_uuid1 ec.temp
scoreboard players reset #bd_clicker_u0 ec.temp
scoreboard players reset #bd_clicker_u1 ec.temp
scoreboard players reset @s ec.bd_summon_uuid0
scoreboard players reset @s ec.bd_summon_uuid1
