# Tab 2: Spawn [Bond Nearest Animal] Button
# @s = player viewing the Buddy tab. Always rendered (the one-click replacement for the dead
# sneak+use designation trigger). Lives on the free ^1.5 row, just under the "Your Buddies" title.
# CONDITIONAL DISPATCH LAW (tab_buddy/open): ^1.5 (text) / ^1.45 (interactions) is clear of every
# other tab_buddy element under every (bd_best_type, bd_tier, bd_type_id) combination — the next
# occupied rows are the title at ^1.7 and the best-buddy section at ^1.35 / interactions <= ^0.625.

execute rotated ~ 0 positioned ^ ^1.5 ^2.26 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["bd.buddy_content","companion.menuelement"],billboard:"center",text:[{text:"[",color:"dark_gray"},{text:"✦ Bond Nearest Animal ✦",color:"#55FF55",bold:true},{text:"]",color:"dark_gray"}],background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.405f,0.405f,0.405f]}}
# Click strip: 0.5w split into 5 x 0.12 cubes (interaction AABBs can't rotate; width is a square X/Z footprint)
execute rotated ~ 0 positioned ^-0.19 ^1.45 ^1.8 run summon interaction ~ ~ ~ {Tags:["bd.buddy_content","bd.bond_click","companion.menuelement"],width:0.12f,height:0.06f,response:1b}
execute rotated ~ 0 positioned ^-0.095 ^1.45 ^1.8 run summon interaction ~ ~ ~ {Tags:["bd.buddy_content","bd.bond_click","companion.menuelement"],width:0.12f,height:0.06f,response:1b}
execute rotated ~ 0 positioned ^0 ^1.45 ^1.8 run summon interaction ~ ~ ~ {Tags:["bd.buddy_content","bd.bond_click","companion.menuelement"],width:0.12f,height:0.06f,response:1b}
execute rotated ~ 0 positioned ^0.095 ^1.45 ^1.8 run summon interaction ~ ~ ~ {Tags:["bd.buddy_content","bd.bond_click","companion.menuelement"],width:0.12f,height:0.06f,response:1b}
execute rotated ~ 0 positioned ^0.19 ^1.45 ^1.8 run summon interaction ~ ~ ~ {Tags:["bd.buddy_content","bd.bond_click","companion.menuelement"],width:0.12f,height:0.06f,response:1b}

scoreboard players operation @e[type=text_display,tag=bd.buddy_content,distance=..5] companion.id = #Search companion.id
scoreboard players operation @e[type=interaction,tag=bd.buddy_content,distance=..5] companion.id = #Search companion.id
