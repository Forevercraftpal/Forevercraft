# Tab 2: Buddy — Open
# @s = player, rotation context set via facing entity anchor from caller
# Shows best buddy stats at top, buddy list below
#
# CONDITIONAL DISPATCH LAW (W2.5 O2, 2026-05-28): Mule/Promote/Equip buttons
# below are spawned conditionally based on ec.bd_best_type + ec.bd_tier. Their
# spawn ^Y values MUST NOT collide at runtime under any combination of these
# scores — runtime tests, not source inspection, are required. The original
# Mule (^Y=1.23) and Unequip (^Y=1.23) literally occupied the same row under
# tier 3+ with a best buddy; fixed in W2.5 O2 by pushing Mule to ^Y=1.09.
# When adding any new conditional button here: hand-walk every (bd_best_type,
# bd_tier) combination and verify no two spawned ^Y values collide.

# #Search already set by caller (click_hub) — do not overwrite

# Title for this tab (use rotated ~ 0 — rotation context flows from caller)
# Ownership-header label (MP-P3.6): foreign viewers see whose menu this is
# 26.1: {selector:} renders blank in text_display — bake @s's name to a $(owner) literal.
function evercraft:util/gui/owner_name
execute rotated ~ 0 positioned ^ ^1.88 ^2.26 run function evercraft:buddy/gui/tab_buddy/open_nm with storage evercraft:scorebake args
execute rotated ~ 0 positioned ^ ^1.7 ^2.26 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["bd.buddy_content","companion.menuelement"],billboard:"center",text:{text:"Your Buddies",color:"#FFD700",bold:true},background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.54f,0.54f,0.54f]}}
scoreboard players operation @e[type=text_display,tag=bd.buddy_content,distance=..5] companion.id = #Search companion.id

# Bond Nearest Animal button (always shown — one-click designation, replaces the dead sneak+use trigger)
function evercraft:buddy/gui/tab_buddy/spawn_bond_button

# Best Buddy section (NO at @s — let rotation flow through)
execute if score @s ec.bd_best_type matches 1.. run function evercraft:buddy/gui/tab_buddy/show_best_buddy
execute unless score @s ec.bd_best_type matches 1.. run function evercraft:buddy/gui/tab_buddy/show_no_best

# Best buddy equipment buttons
execute if score @s ec.bd_best_type matches 1.. run function evercraft:buddy/gui/tab_buddy/spawn_equip_buttons

# Current buddy stats
execute if score @s ec.bd_type_id matches 1.. run function evercraft:buddy/gui/tab_buddy/show_buddy_stats
execute unless score @s ec.bd_type_id matches 1.. run function evercraft:buddy/gui/tab_buddy/show_no_buddy

# Pack Mule button (tier 3+)
execute if score @s ec.bd_tier matches 3.. run function evercraft:buddy/gui/tab_buddy/spawn_mule_button

# Promote button (if Spiritbound and no best buddy yet)
execute if score @s ec.bd_tier matches 6 unless score @s ec.bd_best_type matches 1.. run function evercraft:buddy/gui/tab_buddy/spawn_promote_button
