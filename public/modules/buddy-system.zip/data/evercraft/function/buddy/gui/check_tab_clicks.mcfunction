# Buddy GUI — Check Tab Clicks
# @s = player in menu (set by parent menu_v2/check_clicks.mcfunction)
# Called from companions/handler/menu_v2/check_clicks.mcfunction
# Council #5 (D3/D4, 2026-05-27): equip + unequip pass per-player macro args
# (storage evercraft:buddy equip_arg.pid); summon-entry clicks dispatch to do_summon
# with per-player UUID-stash.

# Check each tab's interaction entity for clicks
execute as @e[type=interaction,tag=bd.tab1_click,predicate=evercraft:companions/check_id,limit=1] if data entity @s interaction on target run function evercraft:buddy/gui/switch_tab_1
execute as @e[type=interaction,tag=bd.tab1_click,predicate=evercraft:companions/check_id,limit=1] if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=bd.tab2_click,predicate=evercraft:companions/check_id,limit=1] if data entity @s interaction on target run function evercraft:buddy/gui/switch_tab_2
execute as @e[type=interaction,tag=bd.tab2_click,predicate=evercraft:companions/check_id,limit=1] if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=bd.tab3_click,predicate=evercraft:companions/check_id,limit=1] if data entity @s interaction on target run function evercraft:buddy/gui/switch_tab_3
execute as @e[type=interaction,tag=bd.tab3_click,predicate=evercraft:companions/check_id,limit=1] if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=bd.tab4_click,predicate=evercraft:companions/check_id,limit=1] if data entity @s interaction on target run function evercraft:buddy/gui/switch_tab_4
execute as @e[type=interaction,tag=bd.tab4_click,predicate=evercraft:companions/check_id,limit=1] if data entity @s interaction run data remove entity @s interaction

# Clear interaction data on all tab clicks
execute as @e[type=interaction,tag=bd.tab_element,predicate=evercraft:companions/check_id] if data entity @s interaction run data remove entity @s interaction

# Summon tab pagination clicks
execute as @e[type=interaction,tag=bd.summon_prev_click,predicate=evercraft:companions/check_id,limit=1] if data entity @s interaction on target run function evercraft:buddy/gui/tab_summon/prev_page
execute as @e[type=interaction,tag=bd.summon_prev_click,predicate=evercraft:companions/check_id,limit=1] if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=bd.summon_next_click,predicate=evercraft:companions/check_id,limit=1] if data entity @s interaction on target run function evercraft:buddy/gui/tab_summon/next_page
execute as @e[type=interaction,tag=bd.summon_next_click,predicate=evercraft:companions/check_id,limit=1] if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=bd.summon_prev_click,predicate=evercraft:companions/check_id] if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=bd.summon_next_click,predicate=evercraft:companions/check_id] if data entity @s interaction run data remove entity @s interaction

# Summon tab per-entry click — copy UUID from the clicked interaction into the player, dispatch
# (Two-line dance: we need to read the interaction's scoreboards while @s = interaction, then call do_summon while @s = player)
scoreboard players set #bd_summon_uuid0_pending ec.temp 0
scoreboard players set #bd_summon_uuid1_pending ec.temp 0
execute as @e[type=interaction,tag=bd.summon_entry_click,predicate=evercraft:companions/check_id,limit=1] if data entity @s interaction run scoreboard players operation #bd_summon_uuid0_pending ec.temp = @s ec.bd_e_uuid0
execute as @e[type=interaction,tag=bd.summon_entry_click,predicate=evercraft:companions/check_id,limit=1] if data entity @s interaction run scoreboard players operation #bd_summon_uuid1_pending ec.temp = @s ec.bd_e_uuid1
execute if entity @e[type=interaction,tag=bd.summon_entry_click,predicate=evercraft:companions/check_id,limit=1,nbt={interaction:{}}] run scoreboard players operation @s ec.bd_summon_uuid0 = #bd_summon_uuid0_pending ec.temp
execute if entity @e[type=interaction,tag=bd.summon_entry_click,predicate=evercraft:companions/check_id,limit=1,nbt={interaction:{}}] run scoreboard players operation @s ec.bd_summon_uuid1 = #bd_summon_uuid1_pending ec.temp
execute if entity @e[type=interaction,tag=bd.summon_entry_click,predicate=evercraft:companions/check_id,limit=1,nbt={interaction:{}}] run function evercraft:buddy/gui/tab_summon/do_summon
execute as @e[type=interaction,tag=bd.summon_entry_click,predicate=evercraft:companions/check_id] if data entity @s interaction run data remove entity @s interaction

# Training tab recall click
execute as @e[type=interaction,tag=bd.training_recall_click,predicate=evercraft:companions/check_id,limit=1] if data entity @s interaction on target run function evercraft:buddy/gui/tab_training/do_recall
execute as @e[type=interaction,tag=bd.training_recall_click,predicate=evercraft:companions/check_id,limit=1] if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=bd.training_recall_click,predicate=evercraft:companions/check_id] if data entity @s interaction run data remove entity @s interaction

# Buddy tab equipment clicks — equip (per-player storage via macro arg)
execute store result storage evercraft:buddy equip_arg.pid int 1 run scoreboard players get @s companion.id
execute if entity @e[type=interaction,tag=bd.equip_weapon_click,predicate=evercraft:companions/check_id,limit=1,nbt={interaction:{}}] run function evercraft:buddy/best/equipment/equip_weapon with storage evercraft:buddy equip_arg
execute if entity @e[type=interaction,tag=bd.equip_artifact_click,predicate=evercraft:companions/check_id,limit=1,nbt={interaction:{}}] run function evercraft:buddy/best/equipment/equip_artifact with storage evercraft:buddy equip_arg
execute if entity @e[type=interaction,tag=bd.equip_accessory_click,predicate=evercraft:companions/check_id,limit=1,nbt={interaction:{}}] run function evercraft:buddy/best/equipment/equip_accessory with storage evercraft:buddy equip_arg
execute as @e[type=interaction,tag=bd.equip_weapon_click,predicate=evercraft:companions/check_id] if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=bd.equip_artifact_click,predicate=evercraft:companions/check_id] if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=bd.equip_accessory_click,predicate=evercraft:companions/check_id] if data entity @s interaction run data remove entity @s interaction

# Buddy tab equipment clicks — unequip (sets @s ec.bd_equip_slot, dispatches unequip)
execute if entity @e[type=interaction,tag=bd.unequip_weapon_click,predicate=evercraft:companions/check_id,limit=1,nbt={interaction:{}}] run scoreboard players set @s ec.bd_equip_slot 0
execute if entity @e[type=interaction,tag=bd.unequip_weapon_click,predicate=evercraft:companions/check_id,limit=1,nbt={interaction:{}}] run function evercraft:buddy/best/equipment/unequip with storage evercraft:buddy equip_arg
execute if entity @e[type=interaction,tag=bd.unequip_artifact_click,predicate=evercraft:companions/check_id,limit=1,nbt={interaction:{}}] run scoreboard players set @s ec.bd_equip_slot 1
execute if entity @e[type=interaction,tag=bd.unequip_artifact_click,predicate=evercraft:companions/check_id,limit=1,nbt={interaction:{}}] run function evercraft:buddy/best/equipment/unequip with storage evercraft:buddy equip_arg
execute as @e[type=interaction,tag=bd.unequip_weapon_click,predicate=evercraft:companions/check_id] if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=bd.unequip_artifact_click,predicate=evercraft:companions/check_id] if data entity @s interaction run data remove entity @s interaction

# Clear equip_arg staging
data remove storage evercraft:buddy equip_arg

# Buddy tab promote click — Council #5 #7 fix: dispatch with @s=player (was as @e[interaction] → broken).
execute if entity @e[type=interaction,tag=bd.promote_click,predicate=evercraft:companions/check_id,limit=1,nbt={interaction:{}}] run function evercraft:buddy/best/promote
execute as @e[type=interaction,tag=bd.promote_click,predicate=evercraft:companions/check_id] if data entity @s interaction run data remove entity @s interaction

# Buddy tab pack mule click — Council #5 #7 fix: dispatch with @s=player at @s position (was as @e[interaction] → broken).
execute if entity @e[type=interaction,tag=bd.mule_open_click,predicate=evercraft:companions/check_id,limit=1,nbt={interaction:{}}] at @s run function evercraft:buddy/abilities/pack_mule/open
execute as @e[type=interaction,tag=bd.mule_open_click,predicate=evercraft:companions/check_id] if data entity @s interaction run data remove entity @s interaction

# Buddy tab bond-nearest click (2026-06-20) — one-click designation of the closest tamed animal,
# dispatched with @s=player at @s position (replaces the dead sneak+use trigger).
execute if entity @e[type=interaction,tag=bd.bond_click,predicate=evercraft:companions/check_id,limit=1,nbt={interaction:{}}] at @s run function evercraft:buddy/designate/bond_nearest
execute as @e[type=interaction,tag=bd.bond_click,predicate=evercraft:companions/check_id] if data entity @s interaction run data remove entity @s interaction

# ===== INSPECT (left-click = what does this button do?) — gui/inspect pattern 2026-06-11 =====
execute as @e[type=interaction,tag=bd.tab1_click,predicate=evercraft:companions/check_id,limit=1] if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Summon Tab",b:"Opens the summon tab — choose which buddy walks with you."}
execute as @e[type=interaction,tag=bd.tab1_click,predicate=evercraft:companions/check_id,limit=1] if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=bd.tab2_click,predicate=evercraft:companions/check_id,limit=1] if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Gear Tab",b:"Opens the gear tab — arm your buddy with weapon, accessory, and artifact."}
execute as @e[type=interaction,tag=bd.tab2_click,predicate=evercraft:companions/check_id,limit=1] if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=bd.tab3_click,predicate=evercraft:companions/check_id,limit=1] if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Skills Tab",b:"Opens the skills tab — what your buddy has learned."}
execute as @e[type=interaction,tag=bd.tab3_click,predicate=evercraft:companions/check_id,limit=1] if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=bd.tab4_click,predicate=evercraft:companions/check_id,limit=1] if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Bond Tab",b:"Opens the bond tab — your buddy's story with you."}
execute as @e[type=interaction,tag=bd.tab4_click,predicate=evercraft:companions/check_id,limit=1] if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=bd.summon_entry_click,predicate=evercraft:companions/check_id,limit=1] if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Summon",b:"Summons this buddy to your side."}
execute as @e[type=interaction,tag=bd.summon_entry_click,predicate=evercraft:companions/check_id,limit=1] if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=bd.summon_prev_click,predicate=evercraft:companions/check_id,limit=1] if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Previous Page",b:"Flips to the previous page of buddies."}
execute as @e[type=interaction,tag=bd.summon_prev_click,predicate=evercraft:companions/check_id,limit=1] if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=bd.summon_next_click,predicate=evercraft:companions/check_id,limit=1] if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Next Page",b:"Flips to the next page of buddies."}
execute as @e[type=interaction,tag=bd.summon_next_click,predicate=evercraft:companions/check_id,limit=1] if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=bd.equip_weapon_click,predicate=evercraft:companions/check_id,limit=1] if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Equip Weapon",b:"Hands your buddy the weapon you are holding."}
execute as @e[type=interaction,tag=bd.equip_weapon_click,predicate=evercraft:companions/check_id,limit=1] if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=bd.unequip_weapon_click,predicate=evercraft:companions/check_id,limit=1] if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Unequip Weapon",b:"Takes the weapon back from your buddy."}
execute as @e[type=interaction,tag=bd.unequip_weapon_click,predicate=evercraft:companions/check_id,limit=1] if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=bd.equip_accessory_click,predicate=evercraft:companions/check_id,limit=1] if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Equip Accessory",b:"Hands your buddy the accessory you are holding."}
execute as @e[type=interaction,tag=bd.equip_accessory_click,predicate=evercraft:companions/check_id,limit=1] if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=bd.equip_artifact_click,predicate=evercraft:companions/check_id,limit=1] if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Equip Artifact",b:"Hands your buddy the artifact you are holding."}
execute as @e[type=interaction,tag=bd.equip_artifact_click,predicate=evercraft:companions/check_id,limit=1] if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=bd.mule_open_click,predicate=evercraft:companions/check_id,limit=1] if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Pack Mule",b:"Opens your buddy's saddlebags."}
execute as @e[type=interaction,tag=bd.mule_open_click,predicate=evercraft:companions/check_id,limit=1] if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=bd.bond_click,predicate=evercraft:companions/check_id,limit=1] if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Bond Nearest Animal",b:"Bonds the closest tamed animal you own (within 8 blocks) as your Buddy. No need to sneak — just stand near your pet and click."}
execute as @e[type=interaction,tag=bd.bond_click,predicate=evercraft:companions/check_id,limit=1] if data entity @s attack run data remove entity @s attack
