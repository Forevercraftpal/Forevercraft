# Tab 3: Spawn a clickable interaction entity per summon entry
# Called as @s = tamed mob (from add_entry), execution position = player's (rotated ~ 0 origin)
# Council #5 (D4, 2026-05-27): wires per-entry click so a player can summon.
# Stores UUID on the interaction entity via ec.bd_e_uuid0/1 (so click dispatch
# can copy them into @s ec.bd_summon_uuid0/1 player-scoped objectives).

# Row 0 at ^2.08, each subsequent row -0.07 (matches spawn_entry rows: 7 visible)
# [strip] ?: 0.6w split into 5 x 0.12 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute if score #bd_summon_row ec.temp matches 0 rotated ~ 0 positioned ^-0.24 ^1.308 ^2.20 run summon interaction ~ ~ ~ {Tags:["bd.summon_content","bd.summon_entry_click","bd.summon_entry_new","companion.menuelement"],width:0.12f,height:0.085f,response:1b}
execute if score #bd_summon_row ec.temp matches 0 rotated ~ 0 positioned ^-0.12 ^1.308 ^2.20 run summon interaction ~ ~ ~ {Tags:["bd.summon_content","bd.summon_entry_click","bd.summon_entry_new","companion.menuelement"],width:0.12f,height:0.085f,response:1b}
execute if score #bd_summon_row ec.temp matches 0 rotated ~ 0 positioned ^0 ^1.308 ^2.20 run summon interaction ~ ~ ~ {Tags:["bd.summon_content","bd.summon_entry_click","bd.summon_entry_new","companion.menuelement"],width:0.12f,height:0.085f,response:1b}
execute if score #bd_summon_row ec.temp matches 0 rotated ~ 0 positioned ^0.12 ^1.308 ^2.20 run summon interaction ~ ~ ~ {Tags:["bd.summon_content","bd.summon_entry_click","bd.summon_entry_new","companion.menuelement"],width:0.12f,height:0.085f,response:1b}
execute if score #bd_summon_row ec.temp matches 0 rotated ~ 0 positioned ^0.24 ^1.308 ^2.20 run summon interaction ~ ~ ~ {Tags:["bd.summon_content","bd.summon_entry_click","bd.summon_entry_new","companion.menuelement"],width:0.12f,height:0.085f,response:1b}
# [strip] ?: 0.6w split into 5 x 0.12 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute if score #bd_summon_row ec.temp matches 1 rotated ~ 0 positioned ^-0.24 ^0.888 ^2.20 run summon interaction ~ ~ ~ {Tags:["bd.summon_content","bd.summon_entry_click","bd.summon_entry_new","companion.menuelement"],width:0.12f,height:0.085f,response:1b}
execute if score #bd_summon_row ec.temp matches 1 rotated ~ 0 positioned ^-0.12 ^0.888 ^2.20 run summon interaction ~ ~ ~ {Tags:["bd.summon_content","bd.summon_entry_click","bd.summon_entry_new","companion.menuelement"],width:0.12f,height:0.085f,response:1b}
execute if score #bd_summon_row ec.temp matches 1 rotated ~ 0 positioned ^0 ^0.888 ^2.20 run summon interaction ~ ~ ~ {Tags:["bd.summon_content","bd.summon_entry_click","bd.summon_entry_new","companion.menuelement"],width:0.12f,height:0.085f,response:1b}
execute if score #bd_summon_row ec.temp matches 1 rotated ~ 0 positioned ^0.12 ^0.888 ^2.20 run summon interaction ~ ~ ~ {Tags:["bd.summon_content","bd.summon_entry_click","bd.summon_entry_new","companion.menuelement"],width:0.12f,height:0.085f,response:1b}
execute if score #bd_summon_row ec.temp matches 1 rotated ~ 0 positioned ^0.24 ^0.888 ^2.20 run summon interaction ~ ~ ~ {Tags:["bd.summon_content","bd.summon_entry_click","bd.summon_entry_new","companion.menuelement"],width:0.12f,height:0.085f,response:1b}
# [strip] ?: 0.6w split into 5 x 0.12 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute if score #bd_summon_row ec.temp matches 2 rotated ~ 0 positioned ^-0.24 ^0.818 ^2.20 run summon interaction ~ ~ ~ {Tags:["bd.summon_content","bd.summon_entry_click","bd.summon_entry_new","companion.menuelement"],width:0.12f,height:0.085f,response:1b}
execute if score #bd_summon_row ec.temp matches 2 rotated ~ 0 positioned ^-0.12 ^0.818 ^2.20 run summon interaction ~ ~ ~ {Tags:["bd.summon_content","bd.summon_entry_click","bd.summon_entry_new","companion.menuelement"],width:0.12f,height:0.085f,response:1b}
execute if score #bd_summon_row ec.temp matches 2 rotated ~ 0 positioned ^0 ^0.818 ^2.20 run summon interaction ~ ~ ~ {Tags:["bd.summon_content","bd.summon_entry_click","bd.summon_entry_new","companion.menuelement"],width:0.12f,height:0.085f,response:1b}
execute if score #bd_summon_row ec.temp matches 2 rotated ~ 0 positioned ^0.12 ^0.818 ^2.20 run summon interaction ~ ~ ~ {Tags:["bd.summon_content","bd.summon_entry_click","bd.summon_entry_new","companion.menuelement"],width:0.12f,height:0.085f,response:1b}
execute if score #bd_summon_row ec.temp matches 2 rotated ~ 0 positioned ^0.24 ^0.818 ^2.20 run summon interaction ~ ~ ~ {Tags:["bd.summon_content","bd.summon_entry_click","bd.summon_entry_new","companion.menuelement"],width:0.12f,height:0.085f,response:1b}
# [strip] ?: 0.6w split into 5 x 0.12 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute if score #bd_summon_row ec.temp matches 3 rotated ~ 0 positioned ^-0.24 ^0.748 ^2.20 run summon interaction ~ ~ ~ {Tags:["bd.summon_content","bd.summon_entry_click","bd.summon_entry_new","companion.menuelement"],width:0.12f,height:0.085f,response:1b}
execute if score #bd_summon_row ec.temp matches 3 rotated ~ 0 positioned ^-0.12 ^0.748 ^2.20 run summon interaction ~ ~ ~ {Tags:["bd.summon_content","bd.summon_entry_click","bd.summon_entry_new","companion.menuelement"],width:0.12f,height:0.085f,response:1b}
execute if score #bd_summon_row ec.temp matches 3 rotated ~ 0 positioned ^0 ^0.748 ^2.20 run summon interaction ~ ~ ~ {Tags:["bd.summon_content","bd.summon_entry_click","bd.summon_entry_new","companion.menuelement"],width:0.12f,height:0.085f,response:1b}
execute if score #bd_summon_row ec.temp matches 3 rotated ~ 0 positioned ^0.12 ^0.748 ^2.20 run summon interaction ~ ~ ~ {Tags:["bd.summon_content","bd.summon_entry_click","bd.summon_entry_new","companion.menuelement"],width:0.12f,height:0.085f,response:1b}
execute if score #bd_summon_row ec.temp matches 3 rotated ~ 0 positioned ^0.24 ^0.748 ^2.20 run summon interaction ~ ~ ~ {Tags:["bd.summon_content","bd.summon_entry_click","bd.summon_entry_new","companion.menuelement"],width:0.12f,height:0.085f,response:1b}
# [strip] ?: 0.6w split into 5 x 0.12 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute if score #bd_summon_row ec.temp matches 4 rotated ~ 0 positioned ^-0.24 ^0.678 ^2.20 run summon interaction ~ ~ ~ {Tags:["bd.summon_content","bd.summon_entry_click","bd.summon_entry_new","companion.menuelement"],width:0.12f,height:0.085f,response:1b}
execute if score #bd_summon_row ec.temp matches 4 rotated ~ 0 positioned ^-0.12 ^0.678 ^2.20 run summon interaction ~ ~ ~ {Tags:["bd.summon_content","bd.summon_entry_click","bd.summon_entry_new","companion.menuelement"],width:0.12f,height:0.085f,response:1b}
execute if score #bd_summon_row ec.temp matches 4 rotated ~ 0 positioned ^0 ^0.678 ^2.20 run summon interaction ~ ~ ~ {Tags:["bd.summon_content","bd.summon_entry_click","bd.summon_entry_new","companion.menuelement"],width:0.12f,height:0.085f,response:1b}
execute if score #bd_summon_row ec.temp matches 4 rotated ~ 0 positioned ^0.12 ^0.678 ^2.20 run summon interaction ~ ~ ~ {Tags:["bd.summon_content","bd.summon_entry_click","bd.summon_entry_new","companion.menuelement"],width:0.12f,height:0.085f,response:1b}
execute if score #bd_summon_row ec.temp matches 4 rotated ~ 0 positioned ^0.24 ^0.678 ^2.20 run summon interaction ~ ~ ~ {Tags:["bd.summon_content","bd.summon_entry_click","bd.summon_entry_new","companion.menuelement"],width:0.12f,height:0.085f,response:1b}
# [strip] ?: 0.6w split into 5 x 0.12 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute if score #bd_summon_row ec.temp matches 5 rotated ~ 0 positioned ^-0.24 ^0.608 ^2.20 run summon interaction ~ ~ ~ {Tags:["bd.summon_content","bd.summon_entry_click","bd.summon_entry_new","companion.menuelement"],width:0.12f,height:0.085f,response:1b}
execute if score #bd_summon_row ec.temp matches 5 rotated ~ 0 positioned ^-0.12 ^0.608 ^2.20 run summon interaction ~ ~ ~ {Tags:["bd.summon_content","bd.summon_entry_click","bd.summon_entry_new","companion.menuelement"],width:0.12f,height:0.085f,response:1b}
execute if score #bd_summon_row ec.temp matches 5 rotated ~ 0 positioned ^0 ^0.608 ^2.20 run summon interaction ~ ~ ~ {Tags:["bd.summon_content","bd.summon_entry_click","bd.summon_entry_new","companion.menuelement"],width:0.12f,height:0.085f,response:1b}
execute if score #bd_summon_row ec.temp matches 5 rotated ~ 0 positioned ^0.12 ^0.608 ^2.20 run summon interaction ~ ~ ~ {Tags:["bd.summon_content","bd.summon_entry_click","bd.summon_entry_new","companion.menuelement"],width:0.12f,height:0.085f,response:1b}
execute if score #bd_summon_row ec.temp matches 5 rotated ~ 0 positioned ^0.24 ^0.608 ^2.20 run summon interaction ~ ~ ~ {Tags:["bd.summon_content","bd.summon_entry_click","bd.summon_entry_new","companion.menuelement"],width:0.12f,height:0.085f,response:1b}
# [strip] ?: 0.6w split into 5 x 0.12 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute if score #bd_summon_row ec.temp matches 6 rotated ~ 0 positioned ^-0.24 ^0.538 ^2.20 run summon interaction ~ ~ ~ {Tags:["bd.summon_content","bd.summon_entry_click","bd.summon_entry_new","companion.menuelement"],width:0.12f,height:0.085f,response:1b}
execute if score #bd_summon_row ec.temp matches 6 rotated ~ 0 positioned ^-0.12 ^0.538 ^2.20 run summon interaction ~ ~ ~ {Tags:["bd.summon_content","bd.summon_entry_click","bd.summon_entry_new","companion.menuelement"],width:0.12f,height:0.085f,response:1b}
execute if score #bd_summon_row ec.temp matches 6 rotated ~ 0 positioned ^0 ^0.538 ^2.20 run summon interaction ~ ~ ~ {Tags:["bd.summon_content","bd.summon_entry_click","bd.summon_entry_new","companion.menuelement"],width:0.12f,height:0.085f,response:1b}
execute if score #bd_summon_row ec.temp matches 6 rotated ~ 0 positioned ^0.12 ^0.538 ^2.20 run summon interaction ~ ~ ~ {Tags:["bd.summon_content","bd.summon_entry_click","bd.summon_entry_new","companion.menuelement"],width:0.12f,height:0.085f,response:1b}
execute if score #bd_summon_row ec.temp matches 6 rotated ~ 0 positioned ^0.24 ^0.538 ^2.20 run summon interaction ~ ~ ~ {Tags:["bd.summon_content","bd.summon_entry_click","bd.summon_entry_new","companion.menuelement"],width:0.12f,height:0.085f,response:1b}

# Stash the entry UUID on the just-spawned interaction (tagged bd.summon_entry_new transiently)
execute store result score @e[type=interaction,tag=bd.summon_entry_new,limit=1] ec.bd_e_uuid0 run data get storage evercraft:buddy temp.entry_uuid0
execute store result score @e[type=interaction,tag=bd.summon_entry_new,limit=1] ec.bd_e_uuid1 run data get storage evercraft:buddy temp.entry_uuid1

# Clear transient tag so the next add_entry call gets a fresh one
tag @e[type=interaction,tag=bd.summon_entry_new] remove bd.summon_entry_new
