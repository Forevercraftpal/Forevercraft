$data modify storage evercraft:notify stage.c set value [{text:"★ ",color:"$(tier_color)"},{text:"BUDDY TIER UP",color:"$(tier_color)",bold:true},{text:" ★",color:"$(tier_color)"}]
scoreboard players set #ndur ec.temp 50
function evercraft:util/notify/emit
$data modify storage evercraft:notify stage.c set value [{text:"Your buddy has reached ",color:"yellow"},{text:"$(tier_name)",color:"$(tier_color)",bold:true},{text:"!",color:"yellow"}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit
