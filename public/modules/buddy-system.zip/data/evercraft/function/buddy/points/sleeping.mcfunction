# Buddy Points — Sleeping (+2 per night slept with buddy nearby)
# Called from daylight/sleep_skip.mcfunction after successful sleep
# Wiring Audit #4 (2026-05-28 W3a/Ra1): split into sleeping_player so each player
# can scope `#Search companion.id` to their own buddy before the proximity check.

execute as @a[scores={ec.bd_tier=0..}] at @s run function evercraft:buddy/points/sleeping_player
