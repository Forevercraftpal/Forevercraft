# Buddy Points — Mining (+1 per deepslate ore mined with buddy nearby)
# @s = player, called from tick_player

# Only process if THIS player's buddy is nearby
# Wiring Audit #4 (2026-05-28 W3a/Ra2): reuse parent tick_player's cached
# ec.bd_nearby tag (already predicate-scoped to @s's own buddy at points/tick_player:9).
execute unless entity @s[tag=ec.bd_nearby] run return fail

# Calculate ore delta since last check (uses adv.stat_ore which tracks all ores)
scoreboard players operation #bd_ore_delta ec.temp = @s adv.stat_ore
scoreboard players operation #bd_ore_delta ec.temp -= @s ec.bd_ore_prev

# Update snapshot
scoreboard players operation @s ec.bd_ore_prev = @s adv.stat_ore

# Award points for each ore mined (skip if 0 or negative)
execute unless score #bd_ore_delta ec.temp matches 1.. run return fail
scoreboard players operation #bd_pts_add ec.temp = #bd_ore_delta ec.temp
function evercraft:buddy/points/add_points
