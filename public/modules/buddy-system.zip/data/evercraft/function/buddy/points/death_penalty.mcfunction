# Buddy Points — Death Penalty (-250 when best buddy dies)
# @s = player whose best buddy died
# Council #5 (D2-tuning, 2026-05-27): penalty raised -100 → -250 (one T3 tier's worth)

scoreboard players remove @s ec.bd_points 250
execute if score @s ec.bd_points matches ..-1 run scoreboard players set @s ec.bd_points 0

# Recheck tier (may drop)
function evercraft:buddy/points/check_tier

data modify storage evercraft:notify stage.c set value [{text:"Your best buddy has fallen... ",color:"red"},{text:"-250 Friendship",color:"dark_red"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
