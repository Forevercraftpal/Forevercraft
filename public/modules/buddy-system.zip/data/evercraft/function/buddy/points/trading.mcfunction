# Buddy Points — Trading (+3 per trade with buddy nearby)
# @s = player who completed a trade
# Called from hook in advantage/track/on_trade.mcfunction

# Only if player has a buddy
execute unless score @s ec.bd_tier matches 0.. run return fail

# Wiring Audit #4 (2026-05-28 W3a/Ra3): scope ownership predicate to @s's own buddy
scoreboard players operation #Search companion.id = @s companion.id

# Only if THIS player's buddy is within 16 blocks
execute at @s unless entity @e[tag=ec.bd_buddy,type=#evercraft:tameable_companions,distance=..16,predicate=evercraft:buddy/check_owner,limit=1] run return fail

scoreboard players set #bd_pts_add ec.temp 3
function evercraft:buddy/points/add_points
