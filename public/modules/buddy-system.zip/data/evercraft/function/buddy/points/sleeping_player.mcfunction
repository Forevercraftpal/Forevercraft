# Buddy Points — Sleeping (per-player branch)
# @s = sleeping player. Wiring Audit #4 (2026-05-28 W3a/Ra1).

# Scope ownership predicate to this player's own buddy
scoreboard players operation #Search companion.id = @s companion.id

# Award only if THIS player's own buddy is within 16 blocks
execute unless entity @e[tag=ec.bd_buddy,type=#evercraft:tameable_companions,distance=..16,predicate=evercraft:buddy/check_owner,limit=1] run return fail

scoreboard players set #bd_pts_add ec.temp 2
function evercraft:buddy/points/add_points
