# Buddy Points — Boss Kill (+25 per boss killed with buddy nearby)
# @s = player who participated in boss kill
# Called from hook in bosses/rewards/give_participant.mcfunction

# Only if player has a buddy
execute unless score @s ec.bd_tier matches 0.. run return fail

# Wiring Audit #4 (2026-05-28 W3a/Ra4): scope ownership predicate to @s's own buddy
scoreboard players operation #Search companion.id = @s companion.id

# Only if THIS player's buddy is within 16 blocks
execute at @s unless entity @e[tag=ec.bd_buddy,type=#evercraft:tameable_companions,distance=..16,predicate=evercraft:buddy/check_owner,limit=1] run return fail

scoreboard players set #bd_pts_add ec.temp 25
function evercraft:buddy/points/add_points
data modify storage evercraft:notify stage.c set value [{text:"Your buddy fought bravely by your side! ",color:"yellow"},{text:"+25 Friendship",color:"green"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
