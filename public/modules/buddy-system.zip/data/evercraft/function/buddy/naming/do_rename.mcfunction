# Buddy Naming — Do Rename (player chose to rename)
# @s = player
# Give them the buddy charter to write a new name

scoreboard players set @s ec.bd_confirm 0
scoreboard players enable @s ec.bd_confirm

# Mark naming flow active
scoreboard players set @s ec.bd_naming 1

# Give charter book
# Wiring Audit #4 (2026-05-28 W2/O1): swapped `item replace ... weapon.mainhand` -> `give @s`
# (matches Guild Charter pattern + give_charter.mcfunction). D5 evercraft_item:1b marker.
give @s minecraft:writable_book[custom_name={text:"Buddy Charter",color:"gold",italic:false},custom_data={buddy_charter:1b,evercraft_item:1b},writable_book_content={pages:["Write your buddy's new name on this page and sign the charter!"]}] 1

data modify storage evercraft:notify stage.c set value [{text:"Write your buddy's new name on page 1 and ",color:"yellow"},{text:"sign it",color:"green",bold:true},{text:"!",color:"yellow"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
# Gated bespoke amethyst rename touch (charter handed over).
scoreboard players set #rename_mode ec.temp 0
execute at @s run function evercraft:fx/companion/rename
