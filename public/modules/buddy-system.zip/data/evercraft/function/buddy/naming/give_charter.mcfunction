# Buddy Naming — Give Charter (writable book)
# @s = the target mob entity (no CustomName)
# Player context available via #bd_owner

# Mark player as in naming flow
execute as @a if score @s companion.id = #bd_owner ec.temp run scoreboard players set @s ec.bd_naming 1

# Give the player a Buddy Charter book
# Wiring Audit #4 (2026-05-28 W2/O1): swapped `item replace ... weapon.mainhand` -> `give @s`
# to stop destroying whatever the player was holding (matches Guild Charter pattern at
# guild/stone/setup_guild_stone:38). D5 adds evercraft_item:1b marker for cross-branch consistency.
execute as @a if score @s companion.id = #bd_owner ec.temp run give @s minecraft:writable_book[custom_name={text:"Buddy Charter",color:"gold",italic:false},custom_data={buddy_charter:1b,evercraft_item:1b},writable_book_content={pages:["Write your buddy's name on this page and sign the charter!"]}] 1

data modify storage evercraft:notify stage.c set value [{text:"Write your buddy's name on page 1 of the charter and ",color:"yellow"},{text:"sign it",color:"green",bold:true},{text:" to complete the bond!",color:"yellow"}]
scoreboard players set #ndur ec.temp 45
execute as @a if score @s companion.id = #bd_owner ec.temp run function evercraft:util/notify/emit

# Play a sound
execute as @a if score @s companion.id = #bd_owner ec.temp if score @s ec.fx_snd matches 1.. at @s run playsound minecraft:entity.experience_orb.pickup master @s ~ ~ ~ 0.5 1.5
