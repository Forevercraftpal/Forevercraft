# Buddy Ability — Last Stand: on-death dispatcher (subject flip)
# Council #5 (D2, 2026-05-27): called from tamed_bond/on_pet_death.
# @s = buddy entity that just took fatal damage (totem fired, now at 1HP).
# #Search companion.id is already set to @s ec.bd_owner_id by the caller.
#
# Finds the owning player, checks Tier-3+ + cooldown. If eligible, calls activate
# (which heals the buddy, makes it invuln, tps to player, sets cooldown).
# Sets #bd_ls_consumed ec.temp = 1 if Last Stand fires so the caller can short-circuit
# the generic memento ceremony and the kill at the end of on_pet_death.

scoreboard players set #bd_ls_consumed ec.temp 0

# Find owner. Activate only if Tier-3+ and Last Stand off cooldown.
execute as @a[predicate=evercraft:companions/check_id] if score @s ec.bd_tier matches 3.. if score @s ec.bd_last_cd matches 0..0 run function evercraft:buddy/abilities/last_stand/on_death
