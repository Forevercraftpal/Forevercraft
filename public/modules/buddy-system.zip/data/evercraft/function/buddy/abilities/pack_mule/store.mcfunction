# Pack Mule — Store Item (macro)
# $(pid) = player ID, $(slot) = s0/s1/s2
# Stores ANY item from mainhand (unlike satchel which only takes artifacts)

# Check mainhand has something
data modify storage evercraft:notify stage.c set value [{text:"Hold an item in your mainhand!",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute unless items entity @s weapon.mainhand * run function evercraft:util/notify/emit
execute unless items entity @s weapon.mainhand * run return fail

# Copy item name and full NBT to storage
$data modify storage evercraft:buddy mule.$(pid).$(slot).name set from entity @s SelectedItem.components."minecraft:custom_name"
# If no custom_name, use item ID as fallback display
$execute unless items entity @s weapon.mainhand *[minecraft:custom_name] run data modify storage evercraft:buddy mule.$(pid).$(slot).name set from entity @s SelectedItem.id
$data modify storage evercraft:buddy mule.$(pid).$(slot).item set from entity @s SelectedItem

# Remove item from mainhand
item replace entity @s weapon.mainhand with air

# Sound + feedback
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:item.bundle.insert master @s ~ ~ ~ 0.8 1.0
data modify storage evercraft:notify stage.c set value [{text:"Item stored in buddy's pack!",color:"green"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
