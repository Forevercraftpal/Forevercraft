# Buddy Ability — Shared Vitality (Tier 4+)
# When player would take lethal damage, split 50/50 with buddy
# This is complex to detect in vanilla — simplified approach:
# If player drops below 2 hearts and buddy is nearby, heal player for 4 HP
# and damage buddy for 4 HP. 60-second cooldown.

# Check cooldown
execute if score @s ec.bd_vitality_cd matches 1.. run return fail

# Check health is critically low (at or below 4 HP = 2 hearts)
execute store result score #bd_vit_hp ec.temp run data get entity @s Health 1
execute unless score #bd_vit_hp ec.temp matches ..4 run return fail

# Must have buddy within 16 blocks
execute unless entity @e[tag=ec.bd_buddy,type=#evercraft:tameable_companions,distance=..16,limit=1] run return fail

# Heal player for 4 HP
effect give @s instant_health 1 0

# Damage buddy for 4 HP
execute as @e[tag=ec.bd_buddy,type=#evercraft:tameable_companions,distance=..16,limit=1] run damage @s 4 minecraft:generic

# Set cooldown (60 seconds)
scoreboard players set @s ec.bd_vitality_cd 60

data modify storage evercraft:notify stage.c set value [{text:"Your buddy shares your pain!",color:"red"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
# Gated on-palette "shares your pain" thud — REPLACES the off-palette wolf.whine (no mob grunts).
execute if score @s ec.fx_snd matches 1.. at @s run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 0.7 0.5
