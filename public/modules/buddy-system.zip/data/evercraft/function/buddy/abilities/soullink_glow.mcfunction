# Buddy Ability — Soullink Glow (Tier 3+)
# Buddy faintly glows (Glowing effect, refreshed every tick)
# Color customization will come in Phase 5 (GUI)

# Wiring Audit #4 (2026-05-28 W3a/Ra12): scope to @s's own buddy
# (#Search companion.id set by parent abilities/tick_player via points/tick_player:6)
execute as @e[tag=ec.bd_buddy,type=#evercraft:tameable_companions,distance=..32,predicate=evercraft:buddy/check_owner,limit=1] run effect give @s glowing 3 0 true
