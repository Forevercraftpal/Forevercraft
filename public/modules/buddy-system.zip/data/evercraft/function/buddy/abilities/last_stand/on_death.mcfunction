# Buddy Ability — Last Stand: on-death entry (Tier 3+ rescue)
# Council #5 (D2, 2026-05-27): rewritten as the activation entry after dispatcher gate.
# @s = the owning player (subject-flipped by on_death_dispatch).
# Dispatcher already verified ec.bd_tier matches 3.. and ec.bd_last_cd matches 0.
#
# Marks Last Stand as consumed so tamed_bond/on_pet_death skips memento + kill,
# then runs the canonical activate ceremony (heal+invuln+tp+cooldown+effects).

scoreboard players set #bd_ls_consumed ec.temp 1
function evercraft:buddy/abilities/last_stand/activate
