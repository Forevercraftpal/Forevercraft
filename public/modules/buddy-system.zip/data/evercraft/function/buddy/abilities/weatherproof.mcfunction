# Buddy Ability — Weatherproof (Tier 1+)
# Buddy is immune to lightning and powder snow damage
# Applied as fire_resistance effect on buddy during rain/thunder

# Wiring Audit #4 (2026-05-28 W3a/Ra11): scope to @s's own buddy
# (#Search companion.id set by parent abilities/tick_player via points/tick_player:6)
execute if predicate evercraft:buddy/is_thundering as @e[tag=ec.bd_buddy,type=#evercraft:tameable_companions,distance=..32,predicate=evercraft:buddy/check_owner,limit=1] run effect give @s fire_resistance 5 0 true
