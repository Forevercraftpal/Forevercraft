# Buddy Ability — Elemental Resistance (Tier 4+)
# Buddy is immune to fire, fall damage, and drowning
# Applied as effects + NBT flags

# Wiring Audit #4 (2026-05-28 W3a/Ra13): scope to @s's own buddy
# (#Search companion.id set by parent abilities/tick_player via points/tick_player:6)
execute as @e[tag=ec.bd_buddy,type=#evercraft:tameable_companions,distance=..32,predicate=evercraft:buddy/check_owner,limit=1] run effect give @s fire_resistance 5 0 true
execute as @e[tag=ec.bd_buddy,type=#evercraft:tameable_companions,distance=..32,predicate=evercraft:buddy/check_owner,limit=1] run effect give @s water_breathing 5 0 true
