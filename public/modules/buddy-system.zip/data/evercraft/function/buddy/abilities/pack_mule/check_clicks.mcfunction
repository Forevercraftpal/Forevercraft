# Pack Mule — Check Clicks
# @s = player in mule menu

# Unified UI-click FX (Joseph 2026-06-05): all mule menu elements carry ec.mule_el. Fire the gated cue ONCE
# (run as the player) before the close/slot consumes below.
execute if entity @e[type=interaction,tag=ec.mule_el,distance=..6,nbt={interaction:{}},limit=1] run function evercraft:fx/ui/click

# Close button
execute as @e[type=interaction,tag=ec.mule_close_btn,distance=..5,limit=1] if data entity @s interaction on target run function evercraft:buddy/abilities/pack_mule/close
execute as @e[type=interaction,tag=ec.mule_close_btn,distance=..5,limit=1] if data entity @s interaction run data remove entity @s interaction

# Slot clicks — determine which slot, then dispatch
execute as @e[type=interaction,tag=ec.mule_s0,distance=..5,limit=1] if data entity @s interaction run data modify storage evercraft:buddy mule_temp.slot set value "s0"
execute as @e[type=interaction,tag=ec.mule_s0,distance=..5,limit=1] if data entity @s interaction on target run function evercraft:buddy/abilities/pack_mule/on_slot_click
execute as @e[type=interaction,tag=ec.mule_s0,distance=..5,limit=1] if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=ec.mule_s0,distance=..5] if data entity @s interaction run data remove entity @s interaction

execute as @e[type=interaction,tag=ec.mule_s1,distance=..5,limit=1] if data entity @s interaction run data modify storage evercraft:buddy mule_temp.slot set value "s1"
execute as @e[type=interaction,tag=ec.mule_s1,distance=..5,limit=1] if data entity @s interaction on target run function evercraft:buddy/abilities/pack_mule/on_slot_click
execute as @e[type=interaction,tag=ec.mule_s1,distance=..5,limit=1] if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=ec.mule_s1,distance=..5] if data entity @s interaction run data remove entity @s interaction

execute as @e[type=interaction,tag=ec.mule_s2,distance=..5,limit=1] if data entity @s interaction run data modify storage evercraft:buddy mule_temp.slot set value "s2"
execute as @e[type=interaction,tag=ec.mule_s2,distance=..5,limit=1] if data entity @s interaction on target run function evercraft:buddy/abilities/pack_mule/on_slot_click
execute as @e[type=interaction,tag=ec.mule_s2,distance=..5,limit=1] if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=ec.mule_s2,distance=..5] if data entity @s interaction run data remove entity @s interaction
