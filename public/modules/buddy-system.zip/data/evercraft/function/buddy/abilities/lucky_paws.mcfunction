# Buddy Ability — Lucky Paws (Tier 2+)
# Luck I while buddy is within 16 blocks
# Applied as effect (refreshed every tick, so 2s duration is sufficient)

# Wiring Audit #4 (2026-05-28 W3a/Ra9): scope to @s's own buddy
# (#Search companion.id set by parent abilities/tick_player via points/tick_player:6)
execute if entity @e[tag=ec.bd_buddy,type=#evercraft:tameable_companions,distance=..16,predicate=evercraft:buddy/check_owner,limit=1] run effect give @s luck 3 0 true
