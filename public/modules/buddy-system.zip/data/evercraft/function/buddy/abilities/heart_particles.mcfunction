# Buddy Ability — Heart Particles (Tier 0+)
# Spawns heart particles near buddy when player is within 5 blocks
# Only triggers every ~5 seconds to avoid spam

# Use prox_timer modulo — trigger at 0 and 5 (reusing existing timer)
execute unless score @s ec.bd_prox_timer matches 0 unless score @s ec.bd_prox_timer matches 5 run return fail

# @s's own buddy must be within 5 blocks
# Wiring Audit #4 (2026-05-28 W3a/Ra10): scope to @s's own buddy
# (#Search companion.id set by parent abilities/tick_player via points/tick_player:6)
execute as @e[tag=ec.bd_buddy,type=#evercraft:tameable_companions,distance=..5,predicate=evercraft:buddy/check_owner,limit=1] at @s run particle minecraft:heart ~ ~0.8 ~ 0.2 0.2 0.2 0 1
