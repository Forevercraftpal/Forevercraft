# Buddy Ability — Dimensional Bond (Tier 5+)
# Buddy auto-teleports when player changes dimensions
# Detected by checking if buddy is in a different dimension than player
# This is checked from the main tick as a special case

# Check if player just changed dimensions (tag-based detection)
execute unless entity @s[tag=ec.bd_dim_changed] run return fail
tag @s remove ec.bd_dim_changed

# Teleport buddy to player's location
# Wiring Audit #4 (W1.1/Ra7): added distance + check_owner to prevent cross-owner buddy-tp
# (#Search companion.id set by parent abilities/tick_player via points/tick_player:6)
execute at @s as @e[tag=ec.bd_buddy,type=#evercraft:tameable_companions,distance=..512,predicate=evercraft:buddy/check_owner,limit=1] run tp @s ~ ~ ~

data modify storage evercraft:notify stage.c set value [{text:"Your buddy followed you across dimensions!",color:"aqua"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute at @s run particle minecraft:portal ~ ~1 ~ 0.5 0.5 0.5 0.5 10
