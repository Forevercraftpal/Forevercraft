# Buddy Ability — Dimension-Change Setter (advancement reward)
# Fires from advancement/buddy/dimension_changed.json on minecraft:changed_dimension
# @s = player who just changed dimensions. Tag drives dimensional_bond.mcfunction
# (T5+ only — abilities/tick_player:31 gates the consumer to Mythic Bond+).
# Wired by Wiring Audit #4 (2026-05-28 W1.1).

advancement revoke @s only evercraft:buddy/dimension_changed
tag @s add ec.bd_dim_changed
