# Happy Ghast — Toggle Sit/Follow
# @s = tamed happy ghast

# Branch on current state using tag to avoid read-after-write issue
tag @s add ec.ghast_check
execute if score @s ghast.sitting matches 1 run tag @s add ec.ghast_was_sitting
execute unless entity @s[tag=ec.ghast_was_sitting] run tag @s add ec.ghast_was_standing
tag @s remove ec.ghast_check

# Was sitting → stand
execute if entity @s[tag=ec.ghast_was_sitting] run scoreboard players set @s ghast.sitting 0
execute if entity @s[tag=ec.ghast_was_sitting] run effect clear @s slowness
data modify storage evercraft:notify stage.c set value [{text:"Your ghast will follow you now.",color:"green"}]
scoreboard players set #ndur ec.temp 45
execute if entity @s[tag=ec.ghast_was_sitting] as @p run function evercraft:util/notify/emit

# Was standing → sit
execute if entity @s[tag=ec.ghast_was_standing] run scoreboard players set @s ghast.sitting 1
execute if entity @s[tag=ec.ghast_was_standing] run effect give @s slowness 99999 127 true
data modify storage evercraft:notify stage.c set value [{text:"Your ghast will stay here.",color:"yellow"}]
scoreboard players set #ndur ec.temp 45
execute if entity @s[tag=ec.ghast_was_standing] as @p run function evercraft:util/notify/emit

# Cleanup
tag @s remove ec.ghast_was_sitting
tag @s remove ec.ghast_was_standing
