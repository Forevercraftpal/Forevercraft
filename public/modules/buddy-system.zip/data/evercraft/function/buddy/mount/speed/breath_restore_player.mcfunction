# Buddy Mount Speed — Restore Speed (per-player branch)
# @s = breathing player (positioned at via caller).
# Wiring Audit #4 (2026-05-28 W3a/Ra14): re-apply speed only on the nearby
# bonus-tagged buddy mount, not every speed-tagged buddy globally.

scoreboard players operation #Search companion.id = @s companion.id
execute as @e[tag=ec.bd_buddy,tag=ec.bd_speed_applied,type=#evercraft:tameable_companions,distance=..16,predicate=evercraft:buddy/check_owner] run function evercraft:buddy/mount/speed/apply_buddy_bonus_force
