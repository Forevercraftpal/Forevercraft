# Buddy Mount Speed — On Start Riding (advancement reward)
# @s = player who just started riding something
# Council #5 (D1, 2026-05-27): wires the missing initial-apply for buddy-mount 2x/3x speed.
# Without this, ec.bd_speed_applied tag is never set, and breath_restore's @e selector
# finds nothing, so the buddy-mount speed feature was silently broken in production.

# Revoke advancement immediately so it can re-fire on next mount
advancement revoke @s only evercraft:buddy/start_riding_buddy

# Flip subject to the buddy mount, apply the bonus (apply_buddy_bonus is tag-idempotent)
execute on vehicle if entity @s[type=#evercraft:tameable_companions,tag=ec.bd_buddy] run function evercraft:buddy/mount/speed/apply_buddy_bonus
