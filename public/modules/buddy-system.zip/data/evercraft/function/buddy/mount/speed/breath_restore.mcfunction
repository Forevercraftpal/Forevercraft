# Buddy Mount Speed — Restore Speed After Breath
# Scheduled 5 seconds after breath slowdown
# Wiring Audit #4 (2026-05-28 W3a/Ra14): per-player branching scopes the
# re-apply to each breathing player's nearby mount instead of every speed-tagged
# buddy globally in the dimension. Observable effect was benign (same-value re-apply)
# but the brief modifier-remove/re-add window was visible across owners.

execute as @a[scores={ec.bd_breath=1}] at @s run function evercraft:buddy/mount/speed/breath_restore_player
execute as @a[scores={ec.bd_breath=1}] run scoreboard players set @s ec.bd_breath 0
