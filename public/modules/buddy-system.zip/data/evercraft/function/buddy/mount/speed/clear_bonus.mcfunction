# Buddy Mount Speed — Clear Bonus on Dismount
# @s = buddy entity with ec.bd_speed_applied tag and no Passengers (no rider)
# Council #5 (D1+, 2026-05-27): per-20t sweep from buddy/tick removes the bonus
# when the buddy is no longer being ridden. Prevents tag-leak + stale modifier.

attribute @s movement_speed modifier remove evercraft:buddy_mount_speed
tag @s remove ec.bd_speed_applied
