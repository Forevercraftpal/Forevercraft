# Buddy Mount Speed — First Breath Notification
# @s = player (first time this ride session)

data modify storage evercraft:notify stage.c set value [{text:"Your mount slows down to catch its breath!",color:"yellow"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.horse.breathe master @s ~ ~ ~ 0.8 0.8
