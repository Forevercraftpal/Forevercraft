# Black Market — Buy Click Row 6
# Reached on target (session-gated dispatch in tick_buy) → @s IS the verified clicker.
# Load deal data based on current page
execute store result score @s ec.bm_select run scoreboard players get @s ec.bm_page
# Page 1: index = 6, Page 2: index = 13
execute if score @s ec.bm_page matches 1 run scoreboard players set @s ec.bm_select 6
execute if score @s ec.bm_page matches 2 run scoreboard players set @s ec.bm_select 13
execute at @s run function evercraft:black_market/buy/confirm_buy
