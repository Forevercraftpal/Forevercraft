# Black Market — Buy Click Row 2
# Reached on target (session-gated dispatch in tick_buy) → @s IS the verified clicker.
# Load deal data based on current page
execute store result score @s ec.bm_select run scoreboard players get @s ec.bm_page
# Page 1: index = 2, Page 2: index = 9
execute if score @s ec.bm_page matches 1 run scoreboard players set @s ec.bm_select 2
execute if score @s ec.bm_page matches 2 run scoreboard players set @s ec.bm_select 9
execute at @s run function evercraft:black_market/buy/confirm_buy
