# Black Market — Load Deal by Index (Macro)
$data modify storage evercraft:database black_market.temp.buy_deal set from storage evercraft:database black_market.deals[$(select)]
