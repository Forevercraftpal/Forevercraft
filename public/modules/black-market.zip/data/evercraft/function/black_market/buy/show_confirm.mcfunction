# Black Market — Show Buy Confirmation (Macro)
$data modify storage evercraft:notify stage.c set value [{text:"Buy ",color:"yellow"},{text:"$(name)",color:"white",bold:true},{text:" for ",color:"yellow"},{text:"$(price) Netherite",color:"aqua",bold:true},{text:"? Right-click ",color:"yellow"},{text:"[Buy]",color:"green",bold:true},{text:" again to confirm.",color:"yellow"}]
scoreboard players set #ndur ec.temp 50
function evercraft:util/notify/emit
