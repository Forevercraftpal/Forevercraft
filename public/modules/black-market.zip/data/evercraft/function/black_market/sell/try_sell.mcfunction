# ============================================================
# Black Market — Try Sell
# Validates, escrows item, removes from inventory
# Player must have appraised first (ec.bm_price > 0)
# ============================================================

# Must have appraised first
data modify storage evercraft:notify stage.c set value [{text:"Click [Appraise] first to value your item!",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute if score @s ec.bm_price matches 0 run return run function evercraft:util/notify/emit

# Check listing limit
data modify storage evercraft:notify stage.c set value [{text:"Escrow full! You can only list 5 items. Reclaim some first.",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute if score @s ec.bm_listings matches 5.. run return run function evercraft:util/notify/emit

# Verify mainhand still has an item
data modify storage evercraft:notify stage.c set value [{text:"Your mainhand is empty!",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute unless items entity @s weapon.mainhand * run return run function evercraft:util/notify/emit

# Re-verify the item hasn't changed since appraisal (player might have swapped
# items after appraising). Re-run the SAME price-compute appraise quoted, into
# #bm_verify, then require it to equal the appraised ec.bm_price. Using the
# single shared table guarantees verify == quote for the un-swapped item.
scoreboard players operation #bm_appraised ec.bm_temp = @s ec.bm_price
function evercraft:black_market/sell/compute_price
scoreboard players operation #bm_verify ec.bm_temp = @s ec.bm_price
# Restore the appraised price (compute_price overwrote ec.bm_price for the verify)
scoreboard players operation @s ec.bm_price = #bm_appraised ec.bm_temp

# If verify doesn't match appraised price, item was swapped — reject
data modify storage evercraft:notify stage.c set value [{text:"Item changed! Click [Appraise] again.",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute unless score #bm_verify ec.bm_temp = #bm_appraised ec.bm_temp run return run function evercraft:util/notify/emit

# === ESCROW THE ITEM ===
# Copy SelectedItem to temp storage
data modify storage evercraft:database black_market.temp.escrow_item set value {}
data modify storage evercraft:database black_market.temp.escrow_item.item set from entity @s SelectedItem
execute store result storage evercraft:database black_market.temp.escrow_item.price int 1 run scoreboard players get @s ec.bm_price
execute store result storage evercraft:database black_market.temp.escrow_item.day int 1 run time query minecraft:day repetition

# Get player UUID for per-player storage
function evercraft:black_market/escrow/save_listing

# Remove item from mainhand (1 count)
item replace entity @s weapon.mainhand with minecraft:air

# Increment listing count
scoreboard players add @s ec.bm_listings 1

# Reset appraised price (force re-appraise for next item)
scoreboard players set @s ec.bm_price 0

# Feedback
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.item.pickup master @s ~ ~ ~ 0.6 0.8
data modify storage evercraft:notify stage.c set value [{text:"Item listed for sale! It may be bought within a few days.",color:"gold"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit

# Refresh sell tab (update listing count + clear appraisal)
function evercraft:black_market/gui/refresh
