# Black Market — Sell Button Click
# Reached on target (session-gated dispatch in tick_sell) → @s IS the verified clicker.
execute at @s run function evercraft:black_market/sell/try_sell
