# ============================================================
# Black Market — Compute Sell Price (single source of truth)
# Sets @s ec.bm_price for the item in mainhand (0 = unsellable).
# Side-effect-free: NO text display, NO sound, NO return.
# Called by both appraise (to quote) and try_sell (to verify) so the
# verify value can never disagree with the quoted value.
# Only ornate+ artifacts can be sold. Accessories pay more.
# ============================================================

# Reset price
scoreboard players set @s ec.bm_price 0

# === ORNATE+ ARTIFACT PRICING ===
# Accessories pay more than non-accessories at each tier.
# Check accessory variant first (higher price), then base tier with unless-accessory.

# Ornate: accessory = 2 NI, non-accessory = 1 NI
execute if items entity @s weapon.mainhand *[custom_data~{is_artifact:true,tier:"ornate",accessory:true}] run scoreboard players set @s ec.bm_price 2
execute if items entity @s weapon.mainhand *[custom_data~{is_artifact:true,tier:"ornate"}] unless items entity @s weapon.mainhand *[custom_data~{accessory:true}] run scoreboard players set @s ec.bm_price 1

# Exquisite: accessory = 6 NI, non-accessory = 4 NI
execute if items entity @s weapon.mainhand *[custom_data~{is_artifact:true,tier:"exquisite",accessory:true}] run scoreboard players set @s ec.bm_price 6
execute if items entity @s weapon.mainhand *[custom_data~{is_artifact:true,tier:"exquisite"}] unless items entity @s weapon.mainhand *[custom_data~{accessory:true}] run scoreboard players set @s ec.bm_price 4

# Mythical: accessory = 12 NI, non-accessory = 8 NI
execute if items entity @s weapon.mainhand *[custom_data~{is_artifact:true,tier:"mythical",accessory:true}] run scoreboard players set @s ec.bm_price 12
execute if items entity @s weapon.mainhand *[custom_data~{is_artifact:true,tier:"mythical"}] unless items entity @s weapon.mainhand *[custom_data~{accessory:true}] run scoreboard players set @s ec.bm_price 8

# === VANILLA ITEM WHITELIST ===
execute if score @s ec.bm_price matches 0 if items entity @s weapon.mainhand conduit run scoreboard players set @s ec.bm_price 1
execute if score @s ec.bm_price matches 0 if items entity @s weapon.mainhand beacon run scoreboard players set @s ec.bm_price 1
execute if score @s ec.bm_price matches 0 if items entity @s weapon.mainhand dragon_egg run scoreboard players set @s ec.bm_price 16
execute if score @s ec.bm_price matches 0 if items entity @s weapon.mainhand elytra run scoreboard players set @s ec.bm_price 3
execute if score @s ec.bm_price matches 0 if items entity @s weapon.mainhand enchanted_golden_apple run scoreboard players set @s ec.bm_price 1
execute if score @s ec.bm_price matches 0 if items entity @s weapon.mainhand heavy_core run scoreboard players set @s ec.bm_price 1
