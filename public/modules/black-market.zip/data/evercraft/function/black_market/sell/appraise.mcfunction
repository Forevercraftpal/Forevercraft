# ============================================================
# Black Market — Appraise Held Item
# Checks mainhand and determines sell price
# Sets ec.bm_price (0 = unsellable)
# Only ornate+ artifacts can be sold. Accessories pay more.
# ============================================================

# Check if holding anything
execute unless items entity @s weapon.mainhand * run return run data modify entity @e[type=text_display,tag=BM.AppraiseTxt,distance=..8,limit=1] text set value {text:"Your mainhand is empty!",color:"red"}

# === PRICE COMPUTE (single source of truth — shared with try_sell verify) ===
# compute_price sets @s ec.bm_price; try_sell re-runs the SAME fn so the verify
# value always equals the quoted value. Do NOT inline a second table here.
function evercraft:black_market/sell/compute_price

# === UPDATE APPRAISAL DISPLAY ===
# If price is 0, item cannot be sold
execute if score @s ec.bm_price matches 0 run data modify entity @e[type=text_display,tag=BM.AppraiseTxt,distance=..8,limit=1] text set value {text:"This item cannot be sold here.",color:"red"}
execute if score @s ec.bm_price matches 0 run return 0

# Price found — show it via macro
execute store result storage evercraft:database black_market.temp.sell_price int 1 run scoreboard players get @s ec.bm_price
function evercraft:black_market/sell/show_appraisal with storage evercraft:database black_market.temp

execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.5 1.5
