# ============================================================
# Black Market — Spawn Buy Row (Macro)
# Spawns a text_display + interaction pair for a deal
# Args: $(name), $(price), $(y_offset), $(row_tag)
# ============================================================
# Row restyle (2026-06-10, Joseph: "make it feel more like a black market") \u2014 parchment name,
# blood-tinted price, netherite-violet ingot glyph, gold [Deal] instead of storefront-green [Buy].
$execute rotated ~ 0 positioned ^ ^$(y_offset) ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["BM.El","BM.SlotEl","BM.BuyRow"],billboard:"center",text:[{text:"  $(name)",color:"#D6D0C7"},{text:"   $(price) ",color:"#C0392B"},{text:"\u25C6",color:"#6B5E73"},{text:"  ",color:"gray"},{text:"[Deal]",color:"gold",bold:true}],background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.473f,0.473f,0.473f]}}
$execute rotated ~ 0 positioned ^-0.63 ^$(y_offset) ^1.78 positioned ^ ^-0.19 ^0 run summon interaction ~ ~ ~ {Tags:["BM.El","BM.SlotEl","$(row_tag)"],width:0.2f,height:0.03f,response:1b}
