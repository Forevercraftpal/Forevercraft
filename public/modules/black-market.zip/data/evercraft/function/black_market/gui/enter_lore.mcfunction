# Black Market — Enter the Lore Sale sub-page (tab 4)
# Run as: player, at player (called via `on target` from tick_sell)

scoreboard players set @s ec.bm_tab 4
scoreboard players set @s ec.bm_confirm -1
scoreboard players set @s ec.bm_idle 0

# Load this player's saved points
function evercraft:black_market/lore_sale/load_points

# Rebuild the menu on the lore-sale page
function evercraft:black_market/gui/refresh
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.4 0.9
