# Black Market — Listings Tab Tick
# Detects reclaim and collect clicks

# Reclaim buttons (5 slots)
scoreboard players operation #gui_check ec.temp = @s adv.gui_session
execute as @e[type=interaction,tag=BM.Reclaim0,distance=..5,limit=1] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction on target run function evercraft:black_market/escrow/on_click_reclaim_0
execute as @e[type=interaction,tag=BM.Reclaim0,distance=..5,limit=1] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=BM.Reclaim1,distance=..5,limit=1] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction on target run function evercraft:black_market/escrow/on_click_reclaim_1
execute as @e[type=interaction,tag=BM.Reclaim1,distance=..5,limit=1] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=BM.Reclaim2,distance=..5,limit=1] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction on target run function evercraft:black_market/escrow/on_click_reclaim_2
execute as @e[type=interaction,tag=BM.Reclaim2,distance=..5,limit=1] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=BM.Reclaim3,distance=..5,limit=1] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction on target run function evercraft:black_market/escrow/on_click_reclaim_3
execute as @e[type=interaction,tag=BM.Reclaim3,distance=..5,limit=1] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=BM.Reclaim4,distance=..5,limit=1] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction on target run function evercraft:black_market/escrow/on_click_reclaim_4
execute as @e[type=interaction,tag=BM.Reclaim4,distance=..5,limit=1] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction run data remove entity @s interaction

# Collect balance button
execute as @e[type=interaction,tag=BM.CollectBtn,distance=..5,limit=1] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction on target run function evercraft:black_market/escrow/on_click_collect
execute as @e[type=interaction,tag=BM.CollectBtn,distance=..5,limit=1] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction run data remove entity @s interaction

# ===== INSPECT (left-click = what does this button do?) — gui/inspect pattern 2026-06-11 =====
execute as @e[type=interaction,tag=BM.CollectBtn,distance=..5,limit=1] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Collect",b:"Collects the coin your sold goods have earned."}
execute as @e[type=interaction,tag=BM.CollectBtn,distance=..5,limit=1] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=BM.Reclaim0,distance=..5,limit=1] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Reclaim Row 1",b:"Right-click to take the unsold listing in row 1 back into your hands."}
execute as @e[type=interaction,tag=BM.Reclaim0,distance=..5,limit=1] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=BM.Reclaim1,distance=..5,limit=1] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Reclaim Row 2",b:"Right-click to take the unsold listing in row 2 back into your hands."}
execute as @e[type=interaction,tag=BM.Reclaim1,distance=..5,limit=1] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=BM.Reclaim2,distance=..5,limit=1] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Reclaim Row 3",b:"Right-click to take the unsold listing in row 3 back into your hands."}
execute as @e[type=interaction,tag=BM.Reclaim2,distance=..5,limit=1] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=BM.Reclaim3,distance=..5,limit=1] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Reclaim Row 4",b:"Right-click to take the unsold listing in row 4 back into your hands."}
execute as @e[type=interaction,tag=BM.Reclaim3,distance=..5,limit=1] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=BM.Reclaim4,distance=..5,limit=1] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Reclaim Row 5",b:"Right-click to take the unsold listing in row 5 back into your hands."}
execute as @e[type=interaction,tag=BM.Reclaim4,distance=..5,limit=1] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack run data remove entity @s attack
