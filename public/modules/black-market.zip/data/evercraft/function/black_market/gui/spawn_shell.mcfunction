# ============================================================
# Black Market — Spawn GUI Shell
# Spawns background, title, tabs, netherite display, and close button
# Must run as player, at player position
# ============================================================

# Background panel (black stained glass pane)
execute unless entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^ ^2.35 ^1.8 run summon item_display ~ ~ ~ {\
  Tags:["BM.El","BM.BG"],\
  billboard:"center",\
  item:{id:"black_stained_glass_pane",count:1},\
  item_display:"fixed",\
  transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,-0.02f],scale:[3.4f,2.8f,0.01f]}\
}
execute if entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^ ^2.15 ^1.8 run summon item_display ~ ~ ~ {\
  Tags:["BM.El","BM.BG"],\
  billboard:"center",\
  item:{id:"black_stained_glass_pane",count:1},\
  item_display:"fixed",\
  transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,-0.02f],scale:[3.4f,2.8f,0.01f]}\
}

# Title
# Ownership-header label (MP-P3.6): foreign viewers see whose menu this is
# 26.1: {selector:} renders blank in text_display — bake @s's name to a $(owner) literal.
function evercraft:util/gui/owner_name
execute rotated ~ 0 positioned ^ ^3.48 ^1.78 run function evercraft:black_market/gui/spawn_shell_nm with storage evercraft:scorebake args
execute unless entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^ ^3.3 ^1.78 run summon text_display ~ ~ ~ {\
  brightness:{block:15,sky:15},shadow_radius:0f,\
  Tags:["BM.El","BM.Title"],\
  billboard:"center",\
  text:{text:"\u2620 Black Market \u2620",color:"dark_red",bold:true},\
  background:1,shadow:1b,\
  transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.55f,0.55f,0.55f]}\
}
execute if entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^ ^3.1 ^1.78 run summon text_display ~ ~ ~ {\
  brightness:{block:15,sky:15},shadow_radius:0f,\
  Tags:["BM.El","BM.Title"],\
  billboard:"center",\
  text:{text:"\u2620 Black Market \u2620",color:"dark_red",bold:true},\
  background:1,shadow:1b,\
  transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.55f,0.55f,0.55f]}\
}

# === TAB BUTTONS ===
# Buy tab
execute unless entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^0.6 ^3.1 ^1.78 run summon text_display ~ ~ ~ {\
  brightness:{block:15,sky:15},shadow_radius:0f,\
  Tags:["BM.El","BM.TabBuyTxt"],\
  billboard:"center",\
  text:{text:"[ Buy ]",color:"gray"},\
  background:1,shadow:1b,\
  transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.4f,0.4f,0.4f]}\
}
execute if entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^0.6 ^2.9 ^1.78 run summon text_display ~ ~ ~ {\
  brightness:{block:15,sky:15},shadow_radius:0f,\
  Tags:["BM.El","BM.TabBuyTxt"],\
  billboard:"center",\
  text:{text:"[ Buy ]",color:"gray"},\
  background:1,shadow:1b,\
  transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.4f,0.4f,0.4f]}\
}
execute unless entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^0.6 ^3.04 ^1.8 run summon interaction ~ ~ ~ {\
  Tags:["BM.El","BM.TabBuyBtn"],width:0.35f,height:0.08f,response:1b\
}
execute if entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^0.6 ^2.84 ^1.8 run summon interaction ~ ~ ~ {\
  Tags:["BM.El","BM.TabBuyBtn"],width:0.35f,height:0.08f,response:1b\
}

# Sell tab
execute unless entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^ ^3.1 ^1.78 run summon text_display ~ ~ ~ {\
  brightness:{block:15,sky:15},shadow_radius:0f,\
  Tags:["BM.El","BM.TabSellTxt"],\
  billboard:"center",\
  text:{text:"[ Sell ]",color:"gray"},\
  background:1,shadow:1b,\
  transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.4f,0.4f,0.4f]}\
}
execute if entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^ ^2.9 ^1.78 run summon text_display ~ ~ ~ {\
  brightness:{block:15,sky:15},shadow_radius:0f,\
  Tags:["BM.El","BM.TabSellTxt"],\
  billboard:"center",\
  text:{text:"[ Sell ]",color:"gray"},\
  background:1,shadow:1b,\
  transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.4f,0.4f,0.4f]}\
}
execute unless entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^ ^3.04 ^1.8 run summon interaction ~ ~ ~ {\
  Tags:["BM.El","BM.TabSellBtn"],width:0.35f,height:0.08f,response:1b\
}
execute if entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^ ^2.84 ^1.8 run summon interaction ~ ~ ~ {\
  Tags:["BM.El","BM.TabSellBtn"],width:0.35f,height:0.08f,response:1b\
}

# Listings tab
execute unless entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^-0.6 ^3.1 ^1.78 run summon text_display ~ ~ ~ {\
  brightness:{block:15,sky:15},shadow_radius:0f,\
  Tags:["BM.El","BM.TabListTxt"],\
  billboard:"center",\
  text:{text:"[ Listings ]",color:"gray"},\
  background:1,shadow:1b,\
  transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.4f,0.4f,0.4f]}\
}
execute if entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^-0.6 ^2.9 ^1.78 run summon text_display ~ ~ ~ {\
  brightness:{block:15,sky:15},shadow_radius:0f,\
  Tags:["BM.El","BM.TabListTxt"],\
  billboard:"center",\
  text:{text:"[ Listings ]",color:"gray"},\
  background:1,shadow:1b,\
  transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.4f,0.4f,0.4f]}\
}
# [strip] 0.45w split into 4 x 0.12 cubes (was a multi-line continuation block that escaped the 2026-06-09 sweep)
execute unless entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^-0.765 ^3.04 ^1.8 run summon interaction ~ ~ ~ {Tags:["BM.El","BM.TabListBtn"],width:0.12f,height:0.08f,response:1b}
execute unless entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^-0.655 ^3.04 ^1.8 run summon interaction ~ ~ ~ {Tags:["BM.El","BM.TabListBtn"],width:0.12f,height:0.08f,response:1b}
execute unless entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^-0.545 ^3.04 ^1.8 run summon interaction ~ ~ ~ {Tags:["BM.El","BM.TabListBtn"],width:0.12f,height:0.08f,response:1b}
execute unless entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^-0.435 ^3.04 ^1.8 run summon interaction ~ ~ ~ {Tags:["BM.El","BM.TabListBtn"],width:0.12f,height:0.08f,response:1b}
# [strip] 0.45w split into 4 x 0.12 cubes (was a multi-line continuation block that escaped the 2026-06-09 sweep)
execute if entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^-0.765 ^2.84 ^1.8 run summon interaction ~ ~ ~ {Tags:["BM.El","BM.TabListBtn"],width:0.12f,height:0.08f,response:1b}
execute if entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^-0.655 ^2.84 ^1.8 run summon interaction ~ ~ ~ {Tags:["BM.El","BM.TabListBtn"],width:0.12f,height:0.08f,response:1b}
execute if entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^-0.545 ^2.84 ^1.8 run summon interaction ~ ~ ~ {Tags:["BM.El","BM.TabListBtn"],width:0.12f,height:0.08f,response:1b}
execute if entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^-0.435 ^2.84 ^1.8 run summon interaction ~ ~ ~ {Tags:["BM.El","BM.TabListBtn"],width:0.12f,height:0.08f,response:1b}

# === NETHERITE DISPLAY (bottom bar) ===
execute unless entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^ ^1.67 ^1.78 run summon text_display ~ ~ ~ {\
  brightness:{block:15,sky:15},shadow_radius:0f,\
  Tags:["BM.El","BM.NethDisplay"],\
  billboard:"center",\
  text:{text:"Netherite: ...",color:"aqua"},\
  background:1,shadow:1b,\
  transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.35f,0.35f,0.35f]}\
}
execute if entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^ ^1.47 ^1.78 run summon text_display ~ ~ ~ {\
  brightness:{block:15,sky:15},shadow_radius:0f,\
  Tags:["BM.El","BM.NethDisplay"],\
  billboard:"center",\
  text:{text:"Netherite: ...",color:"aqua"},\
  background:1,shadow:1b,\
  transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.35f,0.35f,0.35f]}\
}

# === DEAL TIMER DISPLAY ===
execute unless entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^ ^1.57 ^1.78 run summon text_display ~ ~ ~ {\
  brightness:{block:15,sky:15},shadow_radius:0f,\
  Tags:["BM.El","BM.Timer"],\
  billboard:"center",\
  text:{text:"Deals rotate at dawn",color:"dark_gray",italic:true},\
  background:0,shadow:1b,\
  transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.25f,0.25f,0.25f]}\
}
execute if entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^ ^1.37 ^1.78 run summon text_display ~ ~ ~ {\
  brightness:{block:15,sky:15},shadow_radius:0f,\
  Tags:["BM.El","BM.Timer"],\
  billboard:"center",\
  text:{text:"Deals rotate at dawn",color:"dark_gray",italic:true},\
  background:0,shadow:1b,\
  transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.25f,0.25f,0.25f]}\
}

# === CLOSE BUTTON ===
execute unless entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^ ^1.47 ^1.78 run summon text_display ~ ~ ~ {\
  brightness:{block:15,sky:15},shadow_radius:0f,\
  Tags:["BM.El","BM.CloseTxt"],\
  billboard:"center",\
  text:[{text:"[ ",color:"dark_gray"},{text:"Close",color:"gray",bold:true},{text:" ]",color:"dark_gray"}],\
  background:1,shadow:1b,\
  transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.3f,0.3f,0.3f]}\
}
execute if entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^ ^1.27 ^1.78 run summon text_display ~ ~ ~ {\
  brightness:{block:15,sky:15},shadow_radius:0f,\
  Tags:["BM.El","BM.CloseTxt"],\
  billboard:"center",\
  text:[{text:"[ ",color:"dark_gray"},{text:"Close",color:"gray",bold:true},{text:" ]",color:"dark_gray"}],\
  background:1,shadow:1b,\
  transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.3f,0.3f,0.3f]}\
}
# [strip] 0.4w split into 4 x 0.12 cubes (was a multi-line continuation block that escaped the 2026-06-09 sweep)
execute unless entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^-0.14 ^1.37 ^1.8 run summon interaction ~ ~ ~ {Tags:["BM.El","BM.CloseBtn"],width:0.12f,height:0.12f,response:1b}
execute unless entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^-0.0467 ^1.37 ^1.8 run summon interaction ~ ~ ~ {Tags:["BM.El","BM.CloseBtn"],width:0.12f,height:0.12f,response:1b}
execute unless entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^0.0467 ^1.37 ^1.8 run summon interaction ~ ~ ~ {Tags:["BM.El","BM.CloseBtn"],width:0.12f,height:0.12f,response:1b}
execute unless entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^0.14 ^1.37 ^1.8 run summon interaction ~ ~ ~ {Tags:["BM.El","BM.CloseBtn"],width:0.12f,height:0.12f,response:1b}
# [strip] 0.4w split into 4 x 0.12 cubes (was a multi-line continuation block that escaped the 2026-06-09 sweep)
execute if entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^-0.14 ^1.17 ^1.8 run summon interaction ~ ~ ~ {Tags:["BM.El","BM.CloseBtn"],width:0.12f,height:0.12f,response:1b}
execute if entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^-0.0467 ^1.17 ^1.8 run summon interaction ~ ~ ~ {Tags:["BM.El","BM.CloseBtn"],width:0.12f,height:0.12f,response:1b}
execute if entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^0.0467 ^1.17 ^1.8 run summon interaction ~ ~ ~ {Tags:["BM.El","BM.CloseBtn"],width:0.12f,height:0.12f,response:1b}
execute if entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^0.14 ^1.17 ^1.8 run summon interaction ~ ~ ~ {Tags:["BM.El","BM.CloseBtn"],width:0.12f,height:0.12f,response:1b}
