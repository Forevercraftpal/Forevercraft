# ============================================================
# Black Market — Open GUI
# Run as: player who clicked the barrel
# ============================================================

# Already in menu? Close first (toggle behavior)
# Menu Core: Y-displacement close anchor
# One-menu-at-a-time (2026-06-15): close any other open menu before this one claims
# ec.menu_active. Two overlapping menus share the @s adv.gui_session slot; the newer
# open orphans the older menu's session, so it can never consume its click -> stuck
# interaction NBT -> click-sound spam. force_close is idempotent (no-op when nothing open).
execute if entity @s[tag=ec.menu_active] run function evercraft:menu_core/force_close
tag @s add ec.menu_active
execute store result score @s ec.menu_open_y run data get entity @s Pos[1] 100
# Sneak-position polish (MP-P3.5): when crouching, lower spawn anchor by 0.20m so
# menu sits at a comfortable view-angle for the lowered eye height. Tag is read by
# every summon line below (paired unless/if) and removed at end-of-file.
tag @s remove ec.menu_sneak_open
execute if predicate evercraft:player_crouching run tag @s add ec.menu_sneak_open


execute if entity @s[tag=BM.InMenu] run function evercraft:black_market/gui/close
execute if entity @s[tag=BM.InMenu] run return 0

# Kill any orphaned elements from a previous session (crash, relog)
execute at @s run kill @e[type=text_display,tag=BM.El,distance=..5]
execute at @s run kill @e[type=interaction,tag=BM.El,distance=..5]
execute at @s run kill @e[type=item_display,tag=BM.El,distance=..5]
execute at @s run kill @e[type=marker,tag=BM.Anchor,distance=..5]

# Tag player and set defaults
tag @s add BM.InMenu
scoreboard players set @s ec.bm_idle 0
scoreboard players set @s ec.bm_tab 1
scoreboard players set @s ec.bm_page 1
scoreboard players set @s ec.bm_select 0
scoreboard players set @s ec.bm_price 0
scoreboard players set @s ec.bm_confirm -1

# Spawn anchor marker at player's current position + rotation
# All GUI rebuilds will use this anchor so the menu doesn't shift
execute at @s run summon marker ~ ~ ~ {Tags:["BM.Anchor"]}
execute at @s run data modify entity @e[type=marker,tag=BM.Anchor,distance=..1,limit=1,sort=nearest] Rotation set from entity @s Rotation

# Ensure daily deals exist
function evercraft:black_market/generate_deals

# Check for pending sale notification
function evercraft:black_market/escrow/check_pending_sale

# Load player balance + listing count from storage
function evercraft:black_market/escrow/load_player

# Spawn entire GUI (shell + tab content + netherite display)
function evercraft:black_market/gui/refresh

# Actionbar message (also overrides vanilla "Container is locked!" text)
data modify storage evercraft:notify stage.c set value [{text:"\u2620 ",color:"dark_red"},{text:"Welcome to the Black Market",color:"red",bold:true},{text:" \u2620",color:"dark_red"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
# Fence's house rules (2026-06-10 restyle \u2014 the contraband tone, one quiet line).
data modify storage evercraft:notify stage.c set value [{text:"No refunds. No receipts. No questions.",color:"dark_gray",italic:true}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit

# Sound

# Session isolation
scoreboard players add #gui_session ec.var 1
scoreboard players operation @s adv.gui_session = #gui_session ec.var
scoreboard players operation #gui_stamp ec.temp = @s adv.gui_session
execute as @e[type=text_display,tag=BM.El,distance=..5] unless score @s adv.gui_session matches 1.. run scoreboard players operation @s adv.gui_session = #gui_stamp ec.temp
execute as @e[type=item_display,tag=BM.El,distance=..5] unless score @s adv.gui_session matches 1.. run scoreboard players operation @s adv.gui_session = #gui_stamp ec.temp
execute as @e[type=interaction,tag=BM.El,distance=..5] unless score @s adv.gui_session matches 1.. run scoreboard players operation @s adv.gui_session = #gui_stamp ec.temp
execute as @e[type=text_display,tag=BM.Anchor,distance=..5] unless score @s adv.gui_session matches 1.. run scoreboard players operation @s adv.gui_session = #gui_stamp ec.temp
execute as @e[type=item_display,tag=BM.Anchor,distance=..5] unless score @s adv.gui_session matches 1.. run scoreboard players operation @s adv.gui_session = #gui_stamp ec.temp
execute as @e[type=interaction,tag=BM.Anchor,distance=..5] unless score @s adv.gui_session matches 1.. run scoreboard players operation @s adv.gui_session = #gui_stamp ec.temp
execute as @e[type=marker,tag=BM.Anchor,distance=..5] unless score @s adv.gui_session matches 1.. run scoreboard players operation @s adv.gui_session = #gui_stamp ec.temp

execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.barrel.open master @s ~ ~ ~ 0.6 0.7

# Sneak-position polish cleanup
tag @s remove ec.menu_sneak_open
