# Black Market — Load Player Listings to Temp (Macro)
$data modify storage evercraft:database black_market.temp.listings set from storage evercraft:database black_market.escrow.u$(u0)_$(u1)_$(u2)_$(u3).items
