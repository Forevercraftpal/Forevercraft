# ============================================================
# Black Market — Buy Tab Tick
# Detects clicks on buy buttons and page navigation
# ============================================================

# === PAGE NAVIGATION ===
scoreboard players operation #gui_check ec.temp = @s adv.gui_session
execute as @e[type=interaction,tag=BM.NextBtn,distance=..5,limit=1] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction on target run function evercraft:black_market/gui/page_next
execute as @e[type=interaction,tag=BM.NextBtn,distance=..5,limit=1] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=BM.PrevBtn,distance=..5,limit=1] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction on target run function evercraft:black_market/gui/page_prev
execute as @e[type=interaction,tag=BM.PrevBtn,distance=..5,limit=1] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction run data remove entity @s interaction

# === BUY BUTTON CLICKS ===
# Row 0
execute as @e[type=interaction,tag=BM.BuyRow0,distance=..5,limit=1] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction on target run function evercraft:black_market/buy/on_click_row_0
execute as @e[type=interaction,tag=BM.BuyRow0,distance=..5,limit=1] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction run data remove entity @s interaction
# Row 1
execute as @e[type=interaction,tag=BM.BuyRow1,distance=..5,limit=1] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction on target run function evercraft:black_market/buy/on_click_row_1
execute as @e[type=interaction,tag=BM.BuyRow1,distance=..5,limit=1] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction run data remove entity @s interaction
# Row 2
execute as @e[type=interaction,tag=BM.BuyRow2,distance=..5,limit=1] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction on target run function evercraft:black_market/buy/on_click_row_2
execute as @e[type=interaction,tag=BM.BuyRow2,distance=..5,limit=1] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction run data remove entity @s interaction
# Row 3
execute as @e[type=interaction,tag=BM.BuyRow3,distance=..5,limit=1] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction on target run function evercraft:black_market/buy/on_click_row_3
execute as @e[type=interaction,tag=BM.BuyRow3,distance=..5,limit=1] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction run data remove entity @s interaction
# Row 4
execute as @e[type=interaction,tag=BM.BuyRow4,distance=..5,limit=1] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction on target run function evercraft:black_market/buy/on_click_row_4
execute as @e[type=interaction,tag=BM.BuyRow4,distance=..5,limit=1] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction run data remove entity @s interaction
# Row 5
execute as @e[type=interaction,tag=BM.BuyRow5,distance=..5,limit=1] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction on target run function evercraft:black_market/buy/on_click_row_5
execute as @e[type=interaction,tag=BM.BuyRow5,distance=..5,limit=1] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction run data remove entity @s interaction
# Row 6
execute as @e[type=interaction,tag=BM.BuyRow6,distance=..5,limit=1] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction on target run function evercraft:black_market/buy/on_click_row_6
execute as @e[type=interaction,tag=BM.BuyRow6,distance=..5,limit=1] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction run data remove entity @s interaction

# ===== INSPECT (left-click = what does this button do?) — gui/inspect pattern 2026-06-11 =====
execute as @e[type=interaction,tag=BM.BuyRow0,distance=..5,limit=1] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Listing Row 1",b:"Right-click to buy the black-market listing in row 1 at the price shown beside it."}
execute as @e[type=interaction,tag=BM.BuyRow0,distance=..5,limit=1] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=BM.BuyRow1,distance=..5,limit=1] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Listing Row 2",b:"Right-click to buy the black-market listing in row 2 at the price shown beside it."}
execute as @e[type=interaction,tag=BM.BuyRow1,distance=..5,limit=1] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=BM.BuyRow2,distance=..5,limit=1] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Listing Row 3",b:"Right-click to buy the black-market listing in row 3 at the price shown beside it."}
execute as @e[type=interaction,tag=BM.BuyRow2,distance=..5,limit=1] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=BM.BuyRow3,distance=..5,limit=1] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Listing Row 4",b:"Right-click to buy the black-market listing in row 4 at the price shown beside it."}
execute as @e[type=interaction,tag=BM.BuyRow3,distance=..5,limit=1] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=BM.BuyRow4,distance=..5,limit=1] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Listing Row 5",b:"Right-click to buy the black-market listing in row 5 at the price shown beside it."}
execute as @e[type=interaction,tag=BM.BuyRow4,distance=..5,limit=1] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=BM.BuyRow5,distance=..5,limit=1] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Listing Row 6",b:"Right-click to buy the black-market listing in row 6 at the price shown beside it."}
execute as @e[type=interaction,tag=BM.BuyRow5,distance=..5,limit=1] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=BM.BuyRow6,distance=..5,limit=1] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Listing Row 7",b:"Right-click to buy the black-market listing in row 7 at the price shown beside it."}
execute as @e[type=interaction,tag=BM.BuyRow6,distance=..5,limit=1] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=BM.PrevBtn,distance=..5,limit=1] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Previous Page",b:"Flips to the previous page of listings."}
execute as @e[type=interaction,tag=BM.PrevBtn,distance=..5,limit=1] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=BM.NextBtn,distance=..5,limit=1] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Next Page",b:"Flips to the next page of listings."}
execute as @e[type=interaction,tag=BM.NextBtn,distance=..5,limit=1] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack run data remove entity @s attack
