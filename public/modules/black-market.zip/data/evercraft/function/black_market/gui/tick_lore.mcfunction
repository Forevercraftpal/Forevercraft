# ============================================================
# Black Market — Lore Sale Tab Tick (tab 4)
# Detects deposit / fence / back button clicks
# ============================================================

scoreboard players operation #gui_check ec.temp = @s adv.gui_session

# [Deposit Held Fragment]
execute as @e[type=interaction,tag=BM.LoreDepositBtn,distance=..5,limit=1] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction on target run function evercraft:black_market/lore_sale/deposit
execute as @e[type=interaction,tag=BM.LoreDepositBtn,distance=..5,limit=1] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction run data remove entity @s interaction

# [Fence ▸ Scraps]
execute as @e[type=interaction,tag=BM.LoreSellBtn,distance=..5,limit=1] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction on target run function evercraft:black_market/lore_sale/sell
execute as @e[type=interaction,tag=BM.LoreSellBtn,distance=..5,limit=1] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction run data remove entity @s interaction

# [← Back] — return to the Sell tab
execute as @e[type=interaction,tag=BM.LoreBackBtn,distance=..5,limit=1] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction on target run function evercraft:black_market/gui/on_click_tab_sell
execute as @e[type=interaction,tag=BM.LoreBackBtn,distance=..5,limit=1] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction run data remove entity @s interaction
