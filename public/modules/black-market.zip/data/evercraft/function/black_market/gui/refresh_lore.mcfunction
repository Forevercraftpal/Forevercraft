# ============================================================
# Black Market — Lore Sale Sub-Page (tab 4)
# Transmute-style deposit: fence duplicate lore for netherite scraps.
# Each fragment is worth its rarity in points; 25 points -> 2 scraps; remainder persists.
# Run as: player, at the BM.Anchor position (called from rebuild)
# ============================================================

# Title
execute rotated ~ 0 positioned ^ ^2.95 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["BM.El","BM.SlotEl","BM.LoreInstr"],billboard:"center",text:[{text:"⚜ ",color:"gold"},{text:"Fence Duplicate Lore",color:"gold",bold:true}],background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.4f,0.4f,0.4f]}}

# Subtitle
execute rotated ~ 0 positioned ^ ^2.78 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["BM.El","BM.SlotEl"],billboard:"center",text:{text:"Each fragment is worth its rarity (Common 1 → Mythical 6).",color:"gray",italic:true},background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.22f,0.22f,0.22f]}}

# Banked points (live score)
# === 26.1 fix: {score} blank in text_display -> bake via storage macro ===
scoreboard players add @s ec.bm_lore_pts 0
execute store result storage evercraft:scorebake args.v1 int 1 run scoreboard players get @s ec.bm_lore_pts
function evercraft:black_market/gui/refresh_lore_dyn with storage evercraft:scorebake args

# Deposit button
execute rotated ~ 0 positioned ^ ^2.28 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["BM.El","BM.SlotEl","BM.LoreDepTxt"],billboard:"center",text:[{text:"[ ",color:"dark_gray"},{text:"Deposit Held Fragment",color:"yellow",bold:true},{text:" ]",color:"dark_gray"}],background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.4f,0.4f,0.4f]}}
# [strip] ?: 0.6w split into 5 x 0.12 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute rotated ~ 0 positioned ^-0.24 ^2.22 ^1.8 run summon interaction ~ ~ ~ {Tags:["BM.El","BM.SlotEl","BM.LoreDepositBtn"],width:0.12f,height:0.1f,response:1b}
execute rotated ~ 0 positioned ^-0.12 ^2.22 ^1.8 run summon interaction ~ ~ ~ {Tags:["BM.El","BM.SlotEl","BM.LoreDepositBtn"],width:0.12f,height:0.1f,response:1b}
execute rotated ~ 0 positioned ^0 ^2.22 ^1.8 run summon interaction ~ ~ ~ {Tags:["BM.El","BM.SlotEl","BM.LoreDepositBtn"],width:0.12f,height:0.1f,response:1b}
execute rotated ~ 0 positioned ^0.12 ^2.22 ^1.8 run summon interaction ~ ~ ~ {Tags:["BM.El","BM.SlotEl","BM.LoreDepositBtn"],width:0.12f,height:0.1f,response:1b}
execute rotated ~ 0 positioned ^0.24 ^2.22 ^1.8 run summon interaction ~ ~ ~ {Tags:["BM.El","BM.SlotEl","BM.LoreDepositBtn"],width:0.12f,height:0.1f,response:1b}

# Fence button (green when a full batch is banked)
execute if score @s ec.bm_lore_pts matches 25.. rotated ~ 0 positioned ^0.45 ^1.98 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["BM.El","BM.SlotEl","BM.LoreSellTxt"],billboard:"center",text:[{text:"[ ",color:"dark_gray"},{text:"Fence ▸ Scraps",color:"green",bold:true},{text:" ]",color:"dark_gray"}],background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.36f,0.36f,0.36f]}}
execute unless score @s ec.bm_lore_pts matches 25.. rotated ~ 0 positioned ^0.45 ^1.98 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["BM.El","BM.SlotEl","BM.LoreSellTxt"],billboard:"center",text:[{text:"[ ",color:"dark_gray"},{text:"Fence ▸ Scraps",color:"dark_gray"},{text:" ]",color:"dark_gray"}],background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.36f,0.36f,0.36f]}}
# [strip] ?: 0.5w split into 5 x 0.12 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute rotated ~ 0 positioned ^0.26 ^1.92 ^1.8 run summon interaction ~ ~ ~ {Tags:["BM.El","BM.SlotEl","BM.LoreSellBtn"],width:0.12f,height:0.1f,response:1b}
execute rotated ~ 0 positioned ^0.355 ^1.92 ^1.8 run summon interaction ~ ~ ~ {Tags:["BM.El","BM.SlotEl","BM.LoreSellBtn"],width:0.12f,height:0.1f,response:1b}
execute rotated ~ 0 positioned ^0.45 ^1.92 ^1.8 run summon interaction ~ ~ ~ {Tags:["BM.El","BM.SlotEl","BM.LoreSellBtn"],width:0.12f,height:0.1f,response:1b}
execute rotated ~ 0 positioned ^0.545 ^1.92 ^1.8 run summon interaction ~ ~ ~ {Tags:["BM.El","BM.SlotEl","BM.LoreSellBtn"],width:0.12f,height:0.1f,response:1b}
execute rotated ~ 0 positioned ^0.64 ^1.92 ^1.8 run summon interaction ~ ~ ~ {Tags:["BM.El","BM.SlotEl","BM.LoreSellBtn"],width:0.12f,height:0.1f,response:1b}

# Back button (returns to the Sell tab)
execute rotated ~ 0 positioned ^-0.45 ^1.98 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["BM.El","BM.SlotEl","BM.LoreBackTxt"],billboard:"center",text:[{text:"[ ",color:"dark_gray"},{text:"← Back",color:"gray",bold:true},{text:" ]",color:"dark_gray"}],background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.32f,0.32f,0.32f]}}
# [strip] ?: 0.4w split into 4 x 0.12 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute rotated ~ 0 positioned ^-0.59 ^1.92 ^1.8 run summon interaction ~ ~ ~ {Tags:["BM.El","BM.SlotEl","BM.LoreBackBtn"],width:0.12f,height:0.1f,response:1b}
execute rotated ~ 0 positioned ^-0.4967 ^1.92 ^1.8 run summon interaction ~ ~ ~ {Tags:["BM.El","BM.SlotEl","BM.LoreBackBtn"],width:0.12f,height:0.1f,response:1b}
execute rotated ~ 0 positioned ^-0.4033 ^1.92 ^1.8 run summon interaction ~ ~ ~ {Tags:["BM.El","BM.SlotEl","BM.LoreBackBtn"],width:0.12f,height:0.1f,response:1b}
execute rotated ~ 0 positioned ^-0.31 ^1.92 ^1.8 run summon interaction ~ ~ ~ {Tags:["BM.El","BM.SlotEl","BM.LoreBackBtn"],width:0.12f,height:0.1f,response:1b}
