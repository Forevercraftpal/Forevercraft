# Black Market Lore Sale — Resolve lore set rarity into #ls_rarity ec.bm_temp (macro)
# Called: function evercraft:black_market/lore_sale/get_rarity with storage evercraft:database black_market.ls_temp   {set}
scoreboard players set #ls_rarity ec.bm_temp 1
$execute store result score #ls_rarity ec.bm_temp run data get storage evercraft:lore sets.s$(set).rarity
execute if score #ls_rarity ec.bm_temp matches ..0 run scoreboard players set #ls_rarity ec.bm_temp 1
