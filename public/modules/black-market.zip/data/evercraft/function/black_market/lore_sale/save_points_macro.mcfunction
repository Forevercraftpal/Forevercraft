# Black Market Lore Sale — Save points (macro)
# {u0,u1,u2,u3,points}
$execute unless data storage evercraft:database black_market.lore_sale.u$(u0)_$(u1)_$(u2)_$(u3) run data modify storage evercraft:database black_market.lore_sale.u$(u0)_$(u1)_$(u2)_$(u3) set value {points:0}
$data modify storage evercraft:database black_market.lore_sale.u$(u0)_$(u1)_$(u2)_$(u3).points set from storage evercraft:database black_market.ls_temp.points
