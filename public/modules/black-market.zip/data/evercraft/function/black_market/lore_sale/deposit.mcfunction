# Black Market Lore Sale — Deposit held lore fragment (points by rarity)
# Run as: player, at player

# Read held item's lore_set (stays 0 if the held item isn't a lore fragment)
scoreboard players set #ls_set ec.bm_temp 0
execute store result score #ls_set ec.bm_temp run data get entity @s SelectedItem.components."minecraft:custom_data".lore_set
data modify storage evercraft:notify stage.c set value [{text:"Hold a lore fragment in your main hand first.",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute if score #ls_set ec.bm_temp matches 0 run return run function evercraft:util/notify/emit

# Rarity (1-6) -> points (default 1)
execute store result storage evercraft:database black_market.ls_temp.set int 1 run scoreboard players get #ls_set ec.bm_temp
function evercraft:black_market/lore_sale/get_rarity with storage evercraft:database black_market.ls_temp

# Consume exactly the held fragment by UID (reset to 0 first so a missing UID matches nothing)
data modify storage evercraft:database black_market.ls_temp.uid set value 0
execute store result storage evercraft:database black_market.ls_temp.uid int 1 run data get entity @s SelectedItem.components."minecraft:custom_data".lore_uid
execute store success score #ls_consumed ec.bm_temp run function evercraft:black_market/lore_sale/consume with storage evercraft:database black_market.ls_temp
data modify storage evercraft:notify stage.c set value [{text:"That fragment couldn't be fenced.",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute if score #ls_consumed ec.bm_temp matches 0 run return run function evercraft:util/notify/emit

# Credit rarity points + persist
scoreboard players operation @s ec.bm_lore_pts += #ls_rarity ec.bm_temp
function evercraft:black_market/lore_sale/save_points

# Feedback + refresh
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.5 1.0
particle minecraft:enchant ~ ~1 ~ 0.3 0.3 0.3 0.4 6
function evercraft:black_market/gui/refresh
