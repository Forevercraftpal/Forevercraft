# Black Market Lore Sale — Fence banked points for netherite scraps
# 25 points -> 2 netherite scraps. Sells every full batch at once; remainder persists.
# Run as: player, at player

data modify storage evercraft:notify stage.c set value [{text:"You need at least 25 points to fence for netherite scraps.",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute unless score @s ec.bm_lore_pts matches 25.. run return run function evercraft:util/notify/emit

# batches = points / 25 ; remainder stays banked
scoreboard players operation #ls_pay ec.bm_temp = @s ec.bm_lore_pts
scoreboard players operation #ls_pay ec.bm_temp /= #25 ec.const
scoreboard players operation @s ec.bm_lore_pts %= #25 ec.const

# scraps = batches * 2
scoreboard players operation #ls_scrap ec.bm_temp = #ls_pay ec.bm_temp
scoreboard players operation #ls_scrap ec.bm_temp *= #2 ec.const

# Give scraps
execute store result storage evercraft:database black_market.ls_temp.scraps int 1 run scoreboard players get #ls_scrap ec.bm_temp
function evercraft:black_market/lore_sale/give_scrap with storage evercraft:database black_market.ls_temp

# Persist the remainder
function evercraft:black_market/lore_sale/save_points

# Feedback
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.experience_orb.pickup master @s ~ ~ ~ 0.7 1.0
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.amethyst_block.resonate master @s ~ ~ ~ 0.5 1.4
data modify storage evercraft:notify stage.c set value [{text:"Fenced for ",color:"gray"},{score:{name:"#ls_scrap",objective:"ec.bm_temp"},color:"aqua",bold:true},{text:" netherite scrap(s).",color:"gray"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
function evercraft:black_market/gui/refresh
