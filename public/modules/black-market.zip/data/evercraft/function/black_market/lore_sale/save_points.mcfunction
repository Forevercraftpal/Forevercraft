# Black Market Lore Sale — Persist ec.bm_lore_pts to storage
# Run as: player
execute store result storage evercraft:database black_market.ls_temp.u0 int 1 run data get entity @s UUID[0]
execute store result storage evercraft:database black_market.ls_temp.u1 int 1 run data get entity @s UUID[1]
execute store result storage evercraft:database black_market.ls_temp.u2 int 1 run data get entity @s UUID[2]
execute store result storage evercraft:database black_market.ls_temp.u3 int 1 run data get entity @s UUID[3]
execute store result storage evercraft:database black_market.ls_temp.points int 1 run scoreboard players get @s ec.bm_lore_pts
function evercraft:black_market/lore_sale/save_points_macro with storage evercraft:database black_market.ls_temp
