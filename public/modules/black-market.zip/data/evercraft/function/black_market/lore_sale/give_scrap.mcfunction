# Black Market Lore Sale — Give N netherite scraps (macro)
# Called: function evercraft:black_market/lore_sale/give_scrap with storage evercraft:database black_market.ls_temp   {scraps}
# Inv-full guard: drop at the player's feet rather than void on a full inventory.
# (sell deducts the banked points BEFORE this, so a voided give would be unrecoverable.)
execute store result score #inv_full ec.var run function evercraft:util/check_inv_full
$execute if score #inv_full ec.var matches 0 run give @s minecraft:netherite_scrap $(scraps)
$execute if score #inv_full ec.var matches 1 at @s run summon item ~ ~0.5 ~ {PickupDelay:10s,Item:{id:"minecraft:netherite_scrap",count:$(scraps)}}
