# Black Market Lore Sale — Load saved points into ec.bm_lore_pts
# Run as: player
execute store result storage evercraft:database black_market.ls_temp.u0 int 1 run data get entity @s UUID[0]
execute store result storage evercraft:database black_market.ls_temp.u1 int 1 run data get entity @s UUID[1]
execute store result storage evercraft:database black_market.ls_temp.u2 int 1 run data get entity @s UUID[2]
execute store result storage evercraft:database black_market.ls_temp.u3 int 1 run data get entity @s UUID[3]
function evercraft:black_market/lore_sale/load_points_macro with storage evercraft:database black_market.ls_temp
