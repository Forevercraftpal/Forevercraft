# Black Market Lore Sale — Load points (macro)
# {u0,u1,u2,u3} -> ec.bm_lore_pts
$execute unless data storage evercraft:database black_market.lore_sale.u$(u0)_$(u1)_$(u2)_$(u3) run data modify storage evercraft:database black_market.lore_sale.u$(u0)_$(u1)_$(u2)_$(u3) set value {points:0}
$execute store result score @s ec.bm_lore_pts run data get storage evercraft:database black_market.lore_sale.u$(u0)_$(u1)_$(u2)_$(u3).points
