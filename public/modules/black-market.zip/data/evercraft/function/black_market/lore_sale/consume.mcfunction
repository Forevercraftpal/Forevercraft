# Black Market Lore Sale — Clear exactly one held lore fragment by UID (macro)
# Returns the clear's success (1 if a fragment was actually removed) so the caller
# can refuse to credit points when nothing was consumed.
# Called: function evercraft:black_market/lore_sale/consume with storage evercraft:database black_market.ls_temp   {uid}
$return run clear @s *[custom_data~{lore_uid:$(uid)}] 1
