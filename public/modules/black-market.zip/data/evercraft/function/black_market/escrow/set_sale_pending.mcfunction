# Black Market — Set Sale Pending Flag (Macro)
$data modify storage evercraft:database black_market.escrow.u$(u0)_$(u1)_$(u2)_$(u3).sale_pending set value 1b
