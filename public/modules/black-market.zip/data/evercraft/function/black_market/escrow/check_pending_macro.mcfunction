# Black Market — Check Pending Sale (Macro)
data modify storage evercraft:notify stage.c set value [{text:"Someone bought your goods! Check your pending balance.",color:"gold"}]
scoreboard players set #ndur ec.temp 45
$execute if data storage evercraft:database black_market.escrow.u$(u0)_$(u1)_$(u2)_$(u3){sale_pending:1b} run function evercraft:util/notify/emit
$execute if data storage evercraft:database black_market.escrow.u$(u0)_$(u1)_$(u2)_$(u3){sale_pending:1b} if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.player.levelup master @s ~ ~ ~ 0.6 1.5
$data modify storage evercraft:database black_market.escrow.u$(u0)_$(u1)_$(u2)_$(u3).sale_pending set value 0b
