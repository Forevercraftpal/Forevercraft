# Black Market — Give Pending Netherite (Macro)
# Inv-full guard: drop at the player's feet rather than void on a full inventory.
# (collect_balance zeroes the bank AFTER this, so a voided give would be unrecoverable.)
execute store result score #inv_full ec.var run function evercraft:util/check_inv_full
$execute if score #inv_full ec.var matches 0 run give @s minecraft:netherite_ingot $(amount)
$execute if score #inv_full ec.var matches 1 at @s run summon item ~ ~0.5 ~ {PickupDelay:10s,Item:{id:"minecraft:netherite_ingot",count:$(amount)}}
