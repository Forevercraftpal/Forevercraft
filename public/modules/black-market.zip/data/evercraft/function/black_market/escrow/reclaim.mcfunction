# ============================================================
# Black Market — Reclaim Item from Escrow
# ec.bm_select = slot index (0-4) to reclaim
# Restores via a PickupDelay:0 item entity tp'd to the player (inv-full safe;
# never overwrites the held item). Listing removal is gated on a confirmed restore.
# ============================================================

# Build UUID key
execute store result storage evercraft:database black_market.temp.u0 int 1 run data get entity @s UUID[0]
execute store result storage evercraft:database black_market.temp.u1 int 1 run data get entity @s UUID[1]
execute store result storage evercraft:database black_market.temp.u2 int 1 run data get entity @s UUID[2]
execute store result storage evercraft:database black_market.temp.u3 int 1 run data get entity @s UUID[3]

# Load the selected slot index
execute store result storage evercraft:database black_market.temp.slot int 1 run scoreboard players get @s ec.bm_select

# Copy item from escrow to temp
function evercraft:black_market/escrow/load_reclaim_item with storage evercraft:database black_market.temp

# Check if item exists
data modify storage evercraft:notify stage.c set value [{text:"Nothing in that slot!",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute unless data storage evercraft:database black_market.temp.reclaim_item.item run return run function evercraft:util/notify/emit

# Restore the item WITHOUT destroying whatever the player is holding.
# Mirror the storage-retrieve convention (ore_bag/pantry): summon a PickupDelay:0
# item entity, copy the stored item NBT into it, tp to the player. The player
# auto-picks it up if there is room, otherwise it drops at their feet — the held
# mainhand item is never overwritten and the item is never voided on a full inv.
execute at @s run summon item ~ ~1 ~ {Tags:["BM.TempItem"],PickupDelay:0s,Item:{id:"minecraft:stone",count:1}}
# #bm_restored = 1 only if the stored NBT was successfully copied onto the entity
execute store success score #bm_restored ec.bm_temp run data modify entity @e[type=item,tag=BM.TempItem,limit=1] Item set from storage evercraft:database black_market.temp.reclaim_item.item
# If the copy failed (no entity / bad data), kill the placeholder and bail WITHOUT
# touching the listing — atomic: nothing delivered means nothing removed.
data modify storage evercraft:notify stage.c set value [{text:"Reclaim failed — try again.",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute if score #bm_restored ec.bm_temp matches 0 run kill @e[type=item,tag=BM.TempItem]
execute if score #bm_restored ec.bm_temp matches 0 run return run function evercraft:util/notify/emit
# Delivered — bring it to the player and release it
tp @e[type=item,tag=BM.TempItem,limit=1] @s
tag @e[type=item,tag=BM.TempItem,limit=1] remove BM.TempItem

# Remove item from escrow storage (only reached on a confirmed restore — atomic)
function evercraft:black_market/escrow/remove_listing with storage evercraft:database black_market.temp

# Decrement listing count
scoreboard players remove @s ec.bm_listings 1
execute if score @s ec.bm_listings matches ..-1 run scoreboard players set @s ec.bm_listings 0

# Feedback
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.item.pickup master @s ~ ~ ~ 0.6 1.0
data modify storage evercraft:notify stage.c set value [{text:"Item reclaimed!",color:"green"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit

# Refresh GUI
function evercraft:black_market/gui/refresh
