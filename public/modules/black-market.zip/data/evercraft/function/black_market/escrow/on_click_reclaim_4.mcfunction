# Black Market — Reclaim Click Slot 4
# Reached on target (session-gated dispatch in tick_listings) → @s IS the verified clicker.
scoreboard players set @s ec.bm_select 4
execute at @s run function evercraft:black_market/escrow/reclaim
