# Black Market — Collect Balance Click
# Reached on target (session-gated dispatch in tick_listings) → @s IS the verified clicker.
execute at @s run function evercraft:black_market/escrow/collect_balance
