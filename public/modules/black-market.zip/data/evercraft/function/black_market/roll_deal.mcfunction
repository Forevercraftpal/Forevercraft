# ============================================================
# Black Market — Roll Deal (Macro)
# Copies one pool entry at $(index) into the daily deals array
# Called with: function ... with storage evercraft:database black_market.temp
# ============================================================
$data modify storage evercraft:database black_market.deals append from storage evercraft:database black_market.pool[$(index)]
