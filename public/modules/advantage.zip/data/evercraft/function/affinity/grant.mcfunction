# === GRANT AFFINITY XP — MACRO ENTRY POINT ===
# Usage: function evercraft:affinity/grant {class_id:N, delta:N}
# Run as: the player to be credited (@s)
# Used when caller knows the exact class (e.g., class-specific ability triggers).
# Council #22+#23 PRESERVE-AS-ADMIN (5/5 unanimous, 2026-05-28).

$scoreboard players set @s ec.aff_class $(class_id)
$scoreboard players set #delta ec.temp $(delta)
function evercraft:affinity/internal_grant
