# === COMBAT AFFINITY — FIRST-XP AWAKEN (Reachability wave, 2026-05-28) ===
# Run as @s = player. Called from internal_grant ONLY when this class just crossed 0 -> >0 (genuine
# tool use — combat XP only flows from holding & using a class weapon). Mirrors the craft system's
# first_xp_check + first_xp_toast: fires the "✦ <Class> affinity awakened!" toast at most once per
# class via the ec.aff_seen bitmask. (Lore-limbo XP dump removed 2026-06-04 — lore grants per-pickup.)
#   bit per class: rg=1 bk=2 dn=4 sk=8 kt=16 hl=32 bl=64 jv=128 hp=256 ar=512 ht=1024 tk=2048
#                  kn=4096 ds=8192  (sum stored in ec.aff_seen).
# Reset by admin/strip_player_zero (so a wiped player re-awakens each class).

# Bit value for the active class (2^(class-1)).
scoreboard players set #aff_bit ec.temp 0
execute if score @s ec.aff_class matches 1 run scoreboard players set #aff_bit ec.temp 1
execute if score @s ec.aff_class matches 2 run scoreboard players set #aff_bit ec.temp 2
execute if score @s ec.aff_class matches 3 run scoreboard players set #aff_bit ec.temp 4
execute if score @s ec.aff_class matches 4 run scoreboard players set #aff_bit ec.temp 8
execute if score @s ec.aff_class matches 5 run scoreboard players set #aff_bit ec.temp 16
execute if score @s ec.aff_class matches 6 run scoreboard players set #aff_bit ec.temp 32
execute if score @s ec.aff_class matches 7 run scoreboard players set #aff_bit ec.temp 64
execute if score @s ec.aff_class matches 8 run scoreboard players set #aff_bit ec.temp 128
execute if score @s ec.aff_class matches 9 run scoreboard players set #aff_bit ec.temp 256
execute if score @s ec.aff_class matches 10 run scoreboard players set #aff_bit ec.temp 512
execute if score @s ec.aff_class matches 11 run scoreboard players set #aff_bit ec.temp 1024
execute if score @s ec.aff_class matches 12 run scoreboard players set #aff_bit ec.temp 2048
execute if score @s ec.aff_class matches 13 run scoreboard players set #aff_bit ec.temp 4096
execute if score @s ec.aff_class matches 14 run scoreboard players set #aff_bit ec.temp 8192

# Is the bit already set?  (seen / bit) % 2 == 1  ->  already awakened, bail.
# Zero first so an UNSET ec.aff_seen (a player's very first combat awaken) reads as 0 — `operation =`
# leaves the target untouched if the source is unset, so the explicit set guards against stale temp.
scoreboard players set #aff_seen_t ec.temp 0
scoreboard players operation #aff_seen_t ec.temp = @s ec.aff_seen
scoreboard players operation #aff_seen_t ec.temp /= #aff_bit ec.temp
scoreboard players operation #aff_seen_t ec.temp %= #lore_2 ec.var
execute if score #aff_seen_t ec.temp matches 1 run return 0

# First time for this class — set the bit and fire the awaken toast.
scoreboard players operation @s ec.aff_seen += #aff_bit ec.temp

# --- Awaken toast (mirrors craft first_xp_toast style: ✦ + class color + soft chime). ---
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.8 1.4
particle minecraft:happy_villager ~ ~1 ~ 0.4 0.4 0.4 0 6

scoreboard players set #ndur ec.temp 45
execute if score @s ec.aff_class matches 1 run data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"Rogue",color:"gray",bold:true},{text:" affinity awakened!",color:"gray"},{text:" ✦",color:"gold"}]
execute if score @s ec.aff_class matches 1 run function evercraft:util/notify/emit
execute if score @s ec.aff_class matches 2 run data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"Berserker",color:"red",bold:true},{text:" affinity awakened!",color:"gray"},{text:" ✦",color:"gold"}]
execute if score @s ec.aff_class matches 2 run function evercraft:util/notify/emit
execute if score @s ec.aff_class matches 3 run data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"Dancer",color:"light_purple",bold:true},{text:" affinity awakened!",color:"gray"},{text:" ✦",color:"gold"}]
execute if score @s ec.aff_class matches 3 run function evercraft:util/notify/emit
execute if score @s ec.aff_class matches 4 run data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"Striker",color:"yellow",bold:true},{text:" affinity awakened!",color:"gray"},{text:" ✦",color:"gold"}]
execute if score @s ec.aff_class matches 4 run function evercraft:util/notify/emit
execute if score @s ec.aff_class matches 5 run data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"Sentinel",color:"blue",bold:true},{text:" affinity awakened!",color:"gray"},{text:" ✦",color:"gold"}]
execute if score @s ec.aff_class matches 5 run function evercraft:util/notify/emit
execute if score @s ec.aff_class matches 6 run data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"Healer",color:"green",bold:true},{text:" affinity awakened!",color:"gray"},{text:" ✦",color:"gold"}]
execute if score @s ec.aff_class matches 6 run function evercraft:util/notify/emit
execute if score @s ec.aff_class matches 7 run data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"Beastlord",color:"dark_green",bold:true},{text:" affinity awakened!",color:"gray"},{text:" ✦",color:"gold"}]
execute if score @s ec.aff_class matches 7 run function evercraft:util/notify/emit
execute if score @s ec.aff_class matches 8 run data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"Javelin",color:"aqua",bold:true},{text:" affinity awakened!",color:"gray"},{text:" ✦",color:"gold"}]
execute if score @s ec.aff_class matches 8 run function evercraft:util/notify/emit
execute if score @s ec.aff_class matches 9 run data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"Hoplite",color:"dark_aqua",bold:true},{text:" affinity awakened!",color:"gray"},{text:" ✦",color:"gold"}]
execute if score @s ec.aff_class matches 9 run function evercraft:util/notify/emit
execute if score @s ec.aff_class matches 10 run data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"Archer",color:"dark_green",bold:true},{text:" affinity awakened!",color:"gray"},{text:" ✦",color:"gold"}]
execute if score @s ec.aff_class matches 10 run function evercraft:util/notify/emit
execute if score @s ec.aff_class matches 11 run data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"Hunter",color:"dark_green",bold:true},{text:" affinity awakened!",color:"gray"},{text:" ✦",color:"gold"}]
execute if score @s ec.aff_class matches 11 run function evercraft:util/notify/emit
execute if score @s ec.aff_class matches 12 run data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"Tank",color:"dark_gray",bold:true},{text:" affinity awakened!",color:"gray"},{text:" ✦",color:"gold"}]
execute if score @s ec.aff_class matches 12 run function evercraft:util/notify/emit
execute if score @s ec.aff_class matches 13 run data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"Knight",color:"white",bold:true},{text:" affinity awakened!",color:"gray"},{text:" ✦",color:"gold"}]
execute if score @s ec.aff_class matches 13 run function evercraft:util/notify/emit
execute if score @s ec.aff_class matches 14 run data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"Dual Swordsman",color:"dark_red",bold:true},{text:" affinity awakened!",color:"gray"},{text:" ✦",color:"gold"}]
execute if score @s ec.aff_class matches 14 run function evercraft:util/notify/emit
