# === STAGE-UP CELEBRATION ===
# #new_stage ec.temp = the new stage (1-7)
# @s = the player

# Sound + particles
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.player.levelup master @s ~ ~ ~ 1.0 1.0
particle minecraft:happy_villager ~ ~1 ~ 0.5 0.5 0.5 0 10

# Title based on stage
# (AB-1 sticky-times sweep 2026-06-10: explicit stamp — `title times` is sticky per player and this sequence set none, so it inherited whatever ran last.)
execute if score #new_stage ec.temp matches 1 run title @s times 10 60 20
execute if score #new_stage ec.temp matches 1 run title @s title [{text:"✦ ",color:"gold"},{text:"Common",color:"white",bold:true},{text:" ✦",color:"gold"}]
execute if score #new_stage ec.temp matches 2 run title @s title [{text:"✦ ",color:"gold"},{text:"Uncommon",color:"blue",bold:true},{text:" ✦",color:"gold"}]
execute if score #new_stage ec.temp matches 3 run title @s title [{text:"✦ ",color:"gold"},{text:"Rare",color:"aqua",bold:true},{text:" ✦",color:"gold"}]
execute if score #new_stage ec.temp matches 4 run title @s title [{text:"✦ ",color:"gold"},{text:"Ornate",color:"dark_purple",bold:true},{text:" ✦",color:"gold"}]
execute if score #new_stage ec.temp matches 5 run title @s title [{text:"✦ ",color:"gold"},{text:"Exquisite",color:"light_purple",bold:true},{text:" ✦",color:"gold"}]
execute if score #new_stage ec.temp matches 6 run title @s title [{text:"✦ ",color:"gold"},{text:"Mythical",color:"gold",bold:true},{text:" ✦",color:"gold"}]
execute if score #new_stage ec.temp matches 7 run title @s title [{text:"✦ ",color:"yellow"},{text:"SPIRIT",color:"yellow",bold:true},{text:" ✦",color:"yellow"}]

title @s subtitle {text:"Class Affinity Increased",color:"gray"}
