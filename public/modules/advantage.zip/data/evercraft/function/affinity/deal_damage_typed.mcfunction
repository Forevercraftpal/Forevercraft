# === DEAL BOOSTED DAMAGE (TYPED) ===
# Run as target entity. Attacker = @a[tag=ec.aff_attacker]
# Args from storage evercraft:affinity temp:
#   total = boosted damage amount
#   damage_type = damage type (e.g. minecraft:mob_attack, minecraft:freeze)
# Wiring Audit #5 W3a: predicate filter scopes by-attacker to caller's stamped UUID surrogate.
# Callers MUST set #Search aff.id = @s ec.aff_owner_id before invoking (artifacts/* ability sites do).
# Callers without the stamp fall through to engine-default attribution (vanilla nearest-by-engine).
$damage @s $(total) $(damage_type) by @a[tag=ec.aff_attacker,predicate=evercraft:artifacts/check_owner,limit=1]
