# === INTERNAL GRANT — CORE LOGIC ===
# Expects: @s = player, ec.aff_class set (1-14), #delta ec.temp set
# Does: daily cap check → add to total + daily → update stage

# Skip if delta is 0 or negative
execute unless score #delta ec.temp matches 1.. run return 0

# === DIFFICULTY-PACED PROGRESS (Joseph 2026-06-04) ===
# Scale the class-XP delta by the player's chosen difficulty so easier modes climb faster:
#   ec.difficulty 1 Newcomer -> x10, 2 Adventurer -> x5, 3 Pioneer (or unset/0) -> x1 baseline.
# Applied HERE, ONCE, at the sole combat-XP chokepoint — every combat-XP source funnels its #delta
# through us, so this single multiply covers them all (NEVER also in the callers — double-scale).
# Runs BEFORE the daily cap so the cap still bounds a Newcomer's accelerated gains.
execute if score @s ec.aff_class matches 1.. if score @s ec.difficulty matches 1 run scoreboard players operation #delta ec.temp *= #aff_diff10 ec.var
execute if score @s ec.aff_class matches 1.. if score @s ec.difficulty matches 2 run scoreboard players operation #delta ec.temp *= #aff_diff5 ec.var

# Apply daily cap (skipped for spirit weapon holders)
execute unless score @s ec.aff_spirit matches 1 run function evercraft:affinity/daily_cap

# Skip if delta capped to 0
execute unless score #delta ec.temp matches 1.. run return 0

# Snapshot the pre-add class total (for the first-XP 0->>0 awaken toast below). Combat had no
# awaken hook before this was added; mirrors craft_affinity/internal_grant.
scoreboard players set #aff_old ec.temp 0
execute if score @s ec.aff_class matches 1 run scoreboard players operation #aff_old ec.temp = @s ec.aff_rg
execute if score @s ec.aff_class matches 2 run scoreboard players operation #aff_old ec.temp = @s ec.aff_bk
execute if score @s ec.aff_class matches 3 run scoreboard players operation #aff_old ec.temp = @s ec.aff_dn
execute if score @s ec.aff_class matches 4 run scoreboard players operation #aff_old ec.temp = @s ec.aff_sk
execute if score @s ec.aff_class matches 5 run scoreboard players operation #aff_old ec.temp = @s ec.aff_kt
execute if score @s ec.aff_class matches 6 run scoreboard players operation #aff_old ec.temp = @s ec.aff_hl
execute if score @s ec.aff_class matches 7 run scoreboard players operation #aff_old ec.temp = @s ec.aff_bl
execute if score @s ec.aff_class matches 8 run scoreboard players operation #aff_old ec.temp = @s ec.aff_jv
execute if score @s ec.aff_class matches 9 run scoreboard players operation #aff_old ec.temp = @s ec.aff_hp
execute if score @s ec.aff_class matches 10 run scoreboard players operation #aff_old ec.temp = @s ec.aff_ar
execute if score @s ec.aff_class matches 11 run scoreboard players operation #aff_old ec.temp = @s ec.aff_ht
execute if score @s ec.aff_class matches 12 run scoreboard players operation #aff_old ec.temp = @s ec.aff_tk
execute if score @s ec.aff_class matches 13 run scoreboard players operation #aff_old ec.temp = @s ec.aff_kn
execute if score @s ec.aff_class matches 14 run scoreboard players operation #aff_old ec.temp = @s ec.aff_ds

# Add delta to correct class total + daily
execute if score @s ec.aff_class matches 1 run scoreboard players operation @s ec.aff_rg += #delta ec.temp
execute if score @s ec.aff_class matches 1 run scoreboard players operation @s ec.daff_rg += #delta ec.temp
execute if score @s ec.aff_class matches 2 run scoreboard players operation @s ec.aff_bk += #delta ec.temp
execute if score @s ec.aff_class matches 2 run scoreboard players operation @s ec.daff_bk += #delta ec.temp
execute if score @s ec.aff_class matches 3 run scoreboard players operation @s ec.aff_dn += #delta ec.temp
execute if score @s ec.aff_class matches 3 run scoreboard players operation @s ec.daff_dn += #delta ec.temp
execute if score @s ec.aff_class matches 4 run scoreboard players operation @s ec.aff_sk += #delta ec.temp
execute if score @s ec.aff_class matches 4 run scoreboard players operation @s ec.daff_sk += #delta ec.temp
execute if score @s ec.aff_class matches 5 run scoreboard players operation @s ec.aff_kt += #delta ec.temp
execute if score @s ec.aff_class matches 5 run scoreboard players operation @s ec.daff_kt += #delta ec.temp
execute if score @s ec.aff_class matches 6 run scoreboard players operation @s ec.aff_hl += #delta ec.temp
execute if score @s ec.aff_class matches 6 run scoreboard players operation @s ec.daff_hl += #delta ec.temp
execute if score @s ec.aff_class matches 7 run scoreboard players operation @s ec.aff_bl += #delta ec.temp
execute if score @s ec.aff_class matches 7 run scoreboard players operation @s ec.daff_bl += #delta ec.temp
execute if score @s ec.aff_class matches 8 run scoreboard players operation @s ec.aff_jv += #delta ec.temp
execute if score @s ec.aff_class matches 8 run scoreboard players operation @s ec.daff_jv += #delta ec.temp
execute if score @s ec.aff_class matches 9 run scoreboard players operation @s ec.aff_hp += #delta ec.temp
execute if score @s ec.aff_class matches 9 run scoreboard players operation @s ec.daff_hp += #delta ec.temp
execute if score @s ec.aff_class matches 10 run scoreboard players operation @s ec.aff_ar += #delta ec.temp
execute if score @s ec.aff_class matches 10 run scoreboard players operation @s ec.daff_ar += #delta ec.temp
execute if score @s ec.aff_class matches 11 run scoreboard players operation @s ec.aff_ht += #delta ec.temp
execute if score @s ec.aff_class matches 11 run scoreboard players operation @s ec.daff_ht += #delta ec.temp
execute if score @s ec.aff_class matches 12 run scoreboard players operation @s ec.aff_tk += #delta ec.temp
execute if score @s ec.aff_class matches 12 run scoreboard players operation @s ec.daff_tk += #delta ec.temp
execute if score @s ec.aff_class matches 13 run scoreboard players operation @s ec.aff_kn += #delta ec.temp
execute if score @s ec.aff_class matches 13 run scoreboard players operation @s ec.daff_kn += #delta ec.temp
execute if score @s ec.aff_class matches 14 run scoreboard players operation @s ec.aff_ds += #delta ec.temp
execute if score @s ec.aff_class matches 14 run scoreboard players operation @s ec.daff_ds += #delta ec.temp

# Update stage & boost
function evercraft:affinity/update_stage

# First-XP awaken: fire ONCE when this class crosses 0 -> >0 (genuine tool use — combat XP only
# flows from holding & using a class weapon). Sets the ec.aff_seen bit + fires the awaken toast.
# The 0->>0 transition is inherently once-per-class (totals are monotonic; a Pioneer wipe resets
# both the total AND ec.aff_seen).
execute if score #aff_old ec.temp matches 0 if score @s ec.aff_class matches 1.. run function evercraft:affinity/first_xp_check

# === BOUGH MASTERY XP (2026-06-14) — funnel this combat XP into the matching
# bough class's level. #delta is the post-cap, difficulty-scaled amount; the tap
# uses it as-is (no re-scale). Combat internal_grant is not re-entrant, so this
# is safe at the tail. ===
function evercraft:bough/mastery/from_combat
