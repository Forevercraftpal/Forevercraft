# === PASSIVE GRANT — 7 XP per event (14 with Twin) ===
scoreboard players set #delta ec.temp 7
execute if score @s ec.aff_twin matches 1 run scoreboard players set #delta ec.temp 14
# This is the HOLD tick (every 3.6s while merely holding a class weapon), NOT active
# use. Flag it so bough/mastery/from_combat does NOT feed mainhand patina (ec.pd0) —
# otherwise a held weapon hit "Worn" in ~17 min untouched (re-introduced equip-time
# aging the 2026-06-14 usage-driven redesign removed). Cleared right after, even if
# internal_grant early-returns, so the flag never leaks to a real combat grant.
scoreboard players set #pat_nowear ec.temp 1
function evercraft:affinity/internal_grant
scoreboard players set #pat_nowear ec.temp 0
