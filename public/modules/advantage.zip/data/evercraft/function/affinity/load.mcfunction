# === CLASS AFFINITY SYSTEM — LOAD ===
# Called from evercraft:init

# Per-class totals
scoreboard objectives add ec.aff_rg dummy
scoreboard objectives add ec.aff_bk dummy
scoreboard objectives add ec.aff_dn dummy
scoreboard objectives add ec.aff_sk dummy
scoreboard objectives add ec.aff_kt dummy
scoreboard objectives add ec.aff_hl dummy
scoreboard objectives add ec.aff_bl dummy
scoreboard objectives add ec.aff_jv dummy
scoreboard objectives add ec.aff_hp dummy
scoreboard objectives add ec.aff_ar dummy
scoreboard objectives add ec.aff_ht dummy
scoreboard objectives add ec.aff_tk dummy
scoreboard objectives add ec.aff_kn dummy
scoreboard objectives add ec.aff_ds dummy

# Per-class daily caps
scoreboard objectives add ec.daff_rg dummy
scoreboard objectives add ec.daff_bk dummy
scoreboard objectives add ec.daff_dn dummy
scoreboard objectives add ec.daff_sk dummy
scoreboard objectives add ec.daff_kt dummy
scoreboard objectives add ec.daff_hl dummy
scoreboard objectives add ec.daff_bl dummy
scoreboard objectives add ec.daff_jv dummy
scoreboard objectives add ec.daff_hp dummy
scoreboard objectives add ec.daff_ar dummy
scoreboard objectives add ec.daff_ht dummy
scoreboard objectives add ec.daff_tk dummy
scoreboard objectives add ec.daff_kn dummy
scoreboard objectives add ec.daff_ds dummy

# Per-class boost %
scoreboard objectives add ec.affb_rg dummy
scoreboard objectives add ec.affb_bk dummy
scoreboard objectives add ec.affb_dn dummy
scoreboard objectives add ec.affb_sk dummy
scoreboard objectives add ec.affb_kt dummy
scoreboard objectives add ec.affb_hl dummy
scoreboard objectives add ec.affb_bl dummy
scoreboard objectives add ec.affb_jv dummy
scoreboard objectives add ec.affb_hp dummy
scoreboard objectives add ec.affb_ar dummy
scoreboard objectives add ec.affb_ht dummy
scoreboard objectives add ec.affb_tk dummy
scoreboard objectives add ec.affb_kn dummy
scoreboard objectives add ec.affb_ds dummy

# Per-class stage (0-7)
scoreboard objectives add ec.affs_rg dummy
scoreboard objectives add ec.affs_bk dummy
scoreboard objectives add ec.affs_dn dummy
scoreboard objectives add ec.affs_sk dummy
scoreboard objectives add ec.affs_kt dummy
scoreboard objectives add ec.affs_hl dummy
scoreboard objectives add ec.affs_bl dummy
scoreboard objectives add ec.affs_jv dummy
scoreboard objectives add ec.affs_hp dummy
scoreboard objectives add ec.affs_ar dummy
scoreboard objectives add ec.affs_ht dummy
scoreboard objectives add ec.affs_tk dummy
scoreboard objectives add ec.affs_kn dummy
scoreboard objectives add ec.affs_ds dummy

# Shared
scoreboard objectives add ec.aff_class dummy
scoreboard objectives add ec.aff_spirit dummy
scoreboard objectives add ec.aff_twin dummy
scoreboard objectives add ec.aff_boost dummy
scoreboard objectives add ec.aff_prev dummy

# First-XP awaken one-shot guard bitmask (bit per class 1<<0..1<<13) so the "affinity awakened"
# toast + lore-limbo dump fire exactly once per class on the 0->>0 transition (Lore-Limbo feature,
# Joseph 2026-06-03). Combat had no awaken hook before this; mirrors craft's ec.caff_seen.
# One writer: affinity/first_xp_check (+= the active class bit) + admin/strip_player_zero (reset 0).
scoreboard objectives add ec.aff_seen dummy "Combat First-XP Seen Bitmask"
# ec.aff_timer objective removed — timer now uses #aff_timer on ec.var (OPT: 1 fewer objective)

# Per-player attacker UUID surrogate (Wiring Audit #5 W3a — cross-owner credit predicate)
# Stamped at every artifacts/* ec.aff_attacker add-site; mirrored to #Search aff.id before
# `affinity/deal_damage_typed` consumer to scope `by @a[tag=ec.aff_attacker,predicate=evercraft:artifacts/check_owner,limit=1]`
scoreboard objectives add ec.aff_owner_id dummy "ec.aff_owner_id"

# Init timer
scoreboard players set #aff_timer ec.var 0

# Difficulty XP multipliers (the Difficulty-Paced Progress feature, Joseph 2026-06-04). Combat-class
# XP scales by chosen difficulty so easier modes climb faster: ec.difficulty 1 Newcomer = x10,
# 2 Adventurer = x5, 3 Pioneer (or unset/0) = x1 baseline. Read by internal_grant's single
# diff-mult step (applied ONCE, before the daily cap, so every combat-XP source inherits it).
scoreboard players set #aff_diff10 ec.var 10
scoreboard players set #aff_diff5 ec.var 5
