# Ability Display: Shadow Walker Chestplate (Ornate)
tellraw @s ""
tellraw @s {text:"\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550",color:"dark_purple",bold:true}
tellraw @s [{text:"  "},{text:"Shadow Walker Chestplate",color:"dark_purple",bold:true}]
tellraw @s [{text:"  "},{text:"Ornate Armor",color:"white"}]
tellraw @s {text:"\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550",color:"dark_purple",bold:true}
tellraw @s ""
tellraw @s [{text:"  "},{text:"Set: Shadow (0/4)",color:"gold"}]
tellraw @s [{text:"  "},{text:"2pc: Invisibility on sneak",color:"dark_gray"}]
tellraw @s [{text:"  "},{text:"4pc: Shadow Cloak + Assassinate",color:"dark_gray"}]
tellraw @s ""
tellraw @s [{text:"    "},{text:"Woven from shadow itself.",color:"dark_gray",italic:true}]
tellraw @s [{text:"     "},{text:"Invisible when still.",color:"dark_gray",italic:true}]
tellraw @s ""
tellraw @s {text:"\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550",color:"dark_purple",bold:true}
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.hat master @s ~ ~ ~ 0.5 1.8
