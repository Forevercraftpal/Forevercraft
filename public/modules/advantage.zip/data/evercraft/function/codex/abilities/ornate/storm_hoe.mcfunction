# Ability Display: Petra's Hoe (Ornate)
tellraw @s ""
tellraw @s {text:"══════════════════════════════",color:"dark_purple",bold:true}
tellraw @s [{text:"  "},{text:"Petra's Hoe",color:"dark_purple",bold:true}]
tellraw @s [{text:"  "},{text:"Ornate Tool",color:"white"}]
tellraw @s [{text:"  "},{text:"Craft Class: ",color:"gray"},{text:"Growseer",color:"green",bold:true}]
tellraw @s {text:"══════════════════════════════",color:"dark_purple",bold:true}
tellraw @s ""
tellraw @s [{text:"  "},{text:"Set: Storm (0/7)",color:"gold"}]
tellraw @s [{text:"  "},{text:"2pc: Lightning immunity + Charged",color:"dark_gray"}]
tellraw @s [{text:"  "},{text:"4pc: Storm Aura + Thunder Strike",color:"dark_gray"}]
tellraw @s ""
tellraw @s [{text:"  "},{text:"Ability: Storm Sow",color:"dark_purple",bold:true}]
tellraw @s [{text:"  "},{text:"Tilled land auto-waters nearby crops",color:"dark_purple"}]
tellraw @s ""
tellraw @s [{text:"    "},{text:"Storm-tilled land waters itself.",color:"dark_gray",italic:true}]
tellraw @s [{text:"     "},{text:"Nature provides the rain.",color:"dark_gray",italic:true}]
tellraw @s ""
tellraw @s {text:"══════════════════════════════",color:"dark_purple",bold:true}
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.hat master @s ~ ~ ~ 0.5 1.8
