# Ability Display: Royal Leggings (Uncommon)
tellraw @s ""
tellraw @s {text:"\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550",color:"blue",bold:true}
tellraw @s [{text:"  "},{text:"Royal Leggings",color:"blue",bold:true}]
tellraw @s [{text:"  "},{text:"Uncommon Leggings",color:"white"}]
tellraw @s {text:"\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550",color:"blue",bold:true}
tellraw @s ""
tellraw @s [{text:"  "},{text:"Passive: ",color:"white"},{text:"+3 Armor, stealth bonus",color:"blue"}]
tellraw @s ""
tellraw @s [{text:"    "},{text:"Royal-forged greaves.",color:"dark_gray",italic:true}]
tellraw @s [{text:"     "},{text:"Move in silence.",color:"dark_gray",italic:true}]
tellraw @s ""
tellraw @s {text:"\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550",color:"blue",bold:true}
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.hat master @s ~ ~ ~ 0.5 1.8
