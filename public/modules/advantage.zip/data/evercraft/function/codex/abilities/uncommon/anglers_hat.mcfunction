# Ability Display: Angler's Hat (Uncommon)
tellraw @s ""
tellraw @s {text:"\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550",color:"dark_blue",bold:true}
tellraw @s [{text:"  "},{text:"Angler's Hat",color:"dark_blue",bold:true}]
tellraw @s [{text:"  "},{text:"Uncommon Armor",color:"white"}]
tellraw @s {text:"\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550",color:"dark_blue",bold:true}
tellraw @s ""
tellraw @s [{text:"  "},{text:"A wide-brimmed hat stuck through with",color:"gray",italic:true}]
tellraw @s [{text:"  "},{text:"old hooks and the salt of long mornings.",color:"gray",italic:true}]
tellraw @s [{text:"  "},{text:"◆ Worn proudly by those who",color:"white"}]
tellraw @s [{text:"  "},{text:"  have answered the sea's call.",color:"aqua"}]
tellraw @s [{text:"  "},{text:"\"Shade for the eyes, luck for the line.\"",color:"dark_gray",italic:true}]
tellraw @s ""
tellraw @s {text:"\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550",color:"dark_blue",bold:true}
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.hat master @s ~ ~ ~ 0.5 1.8
