# Ability Display: Bone Fishing Rod (Uncommon)
tellraw @s ""
tellraw @s {text:"══════════════════════════════",color:"blue",bold:true}
tellraw @s [{text:"  "},{text:"Bone Fishing Rod",color:"blue",bold:true}]
tellraw @s [{text:"  "},{text:"Uncommon Fishing Rod",color:"blue"}]
tellraw @s [{text:"  "},{text:"Craft Class: ",color:"gray"},{text:"Sirencall",color:"aqua",bold:true}]
tellraw @s {text:"══════════════════════════════",color:"blue",bold:true}
tellraw @s ""
tellraw @s [{text:"  "},{text:"◆ Passive: ",color:"white"},{text:"+2 Dream Rate while held",color:"blue"}]
tellraw @s ""
tellraw @s [{text:"  "},{text:"◆ Awaken: ",color:"white"},{text:"Gain scaling Lure &",color:"yellow"}]
tellraw @s [{text:"    "},{text:"Luck of the Sea enchantments",color:"yellow"}]
tellraw @s ""
tellraw @s [{text:"    "},{text:"Bone rod, strong line.",color:"dark_gray",italic:true}]
tellraw @s [{text:"     "},{text:"Simple and effective.",color:"dark_gray",italic:true}]
tellraw @s ""
tellraw @s {text:"══════════════════════════════",color:"blue",bold:true}
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.hat master @s ~ ~ ~ 0.5 1.8
