# Ability Display: Emerald Chestplate (Ornate)
tellraw @s ""
tellraw @s {text:"\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550",color:"dark_purple",bold:true}
tellraw @s [{text:"  "},{text:"Emerald Chestplate",color:"dark_purple",bold:true}]
tellraw @s [{text:"  "},{text:"Ornate Armor",color:"white"}]
tellraw @s {text:"\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550",color:"dark_purple",bold:true}
tellraw @s ""
tellraw @s [{text:"  "},{text:"Set: Crystal (0/4)",color:"gold"}]
tellraw @s [{text:"  "},{text:"2pc: Damage resistance",color:"dark_gray"}]
tellraw @s [{text:"  "},{text:"4pc: Prism Shield + Crystal Shatter",color:"dark_gray"}]
tellraw @s ""
tellraw @s [{text:"    "},{text:"Emerald-infused crystal armor.",color:"dark_gray",italic:true}]
tellraw @s [{text:"     "},{text:"Light bends around it.",color:"dark_gray",italic:true}]
tellraw @s ""
tellraw @s {text:"\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550",color:"dark_purple",bold:true}
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.hat master @s ~ ~ ~ 0.5 1.8
