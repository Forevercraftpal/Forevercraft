# Ability Display: Enchanted Monocle (Ornate)
tellraw @s ""
tellraw @s {text:"\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550",color:"dark_purple",bold:true}
tellraw @s [{text:"  "},{text:"Enchanted Monocle",color:"dark_purple",bold:true}]
tellraw @s [{text:"  "},{text:"Ornate Accessory",color:"white"}]
tellraw @s {text:"\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550",color:"dark_purple",bold:true}
tellraw @s ""
tellraw @s [{text:"  "},{text:"Right-click: ",color:"white"},{text:"All mobs glow 24 blocks (10s, 30s cd)",color:"gold"}]
tellraw @s [{text:"  "},{text:"Passive: ",color:"white"},{text:"Night Vision + Dream Rate I",color:"green"}]
tellraw @s ""
tellraw @s [{text:"    "},{text:"One eye sees the world.",color:"dark_gray",italic:true}]
tellraw @s [{text:"     "},{text:"The other sees through it.",color:"dark_gray",italic:true}]
tellraw @s ""
tellraw @s {text:"\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550",color:"dark_purple",bold:true}
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.hat master @s ~ ~ ~ 0.5 1.8
