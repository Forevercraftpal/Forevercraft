# Ability Display: Romeo's Boots (Ornate)
tellraw @s ""
tellraw @s {text:"\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550",color:"dark_purple",bold:true}
tellraw @s [{text:"  "},{text:"Romeo's Boots",color:"dark_purple",bold:true}]
tellraw @s [{text:"  "},{text:"Ornate Armor",color:"white"}]
tellraw @s {text:"\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550",color:"dark_purple",bold:true}
tellraw @s ""
tellraw @s [{text:"  "},{text:"Set: Sculk (0/4)",color:"gold"}]
tellraw @s [{text:"  "},{text:"2pc: Darkness immunity + Vibration sense",color:"dark_gray"}]
tellraw @s [{text:"  "},{text:"4pc: Warden's Might + Sonic Boom",color:"dark_gray"}]
tellraw @s ""
tellraw @s [{text:"    "},{text:"Resonates with sculk energy.",color:"dark_gray",italic:true}]
tellraw @s [{text:"     "},{text:"Darkness holds no fear.",color:"dark_gray",italic:true}]
tellraw @s ""
tellraw @s {text:"\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550",color:"dark_purple",bold:true}
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.hat master @s ~ ~ ~ 0.5 1.8
