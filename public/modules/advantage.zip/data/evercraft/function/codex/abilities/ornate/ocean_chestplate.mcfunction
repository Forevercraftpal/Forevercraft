# Ability Display: Prismarine Chestplate (Ornate)
tellraw @s ""
tellraw @s {text:"\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550",color:"dark_purple",bold:true}
tellraw @s [{text:"  "},{text:"Prismarine Chestplate",color:"dark_purple",bold:true}]
tellraw @s [{text:"  "},{text:"Ornate Armor",color:"white"}]
tellraw @s {text:"\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550",color:"dark_purple",bold:true}
tellraw @s ""
tellraw @s [{text:"  "},{text:"Set: Ocean (0/4)",color:"gold"}]
tellraw @s [{text:"  "},{text:"2pc: Water Breathing + Dolphin's Grace",color:"dark_gray"}]
tellraw @s [{text:"  "},{text:"4pc: Conduit Power + Tidal Wave",color:"dark_gray"}]
tellraw @s ""
tellraw @s [{text:"    "},{text:"Prismarine plates that breathe",color:"dark_gray",italic:true}]
tellraw @s [{text:"     "},{text:"with the tide.",color:"dark_gray",italic:true}]
tellraw @s ""
tellraw @s {text:"\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550",color:"dark_purple",bold:true}
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.hat master @s ~ ~ ~ 0.5 1.8
