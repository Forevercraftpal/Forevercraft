# Ability Display: Soul Lantern Fragment (Ornate)
tellraw @s ""
tellraw @s {text:"\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550",color:"dark_purple",bold:true}
tellraw @s [{text:"  "},{text:"Soul Lantern Fragment",color:"dark_purple",bold:true}]
tellraw @s [{text:"  "},{text:"Ornate Accessory",color:"white"}]
tellraw @s {text:"\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550",color:"dark_purple",bold:true}
tellraw @s ""
tellraw @s [{text:"  "},{text:"Soul Siphon: ",color:"white"},{text:"+25% XP from all sources",color:"aqua"}]
tellraw @s [{text:"  "},{text:"Passive: ",color:"white"},{text:"XP orbs magnetize from 12 blocks",color:"blue"}]
tellraw @s ""
tellraw @s [{text:"    "},{text:"A fragment of the soul lantern.",color:"dark_gray",italic:true}]
tellraw @s [{text:"     "},{text:"XP flows toward it like water.",color:"dark_gray",italic:true}]
tellraw @s ""
tellraw @s {text:"\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550",color:"dark_purple",bold:true}
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.hat master @s ~ ~ ~ 0.5 1.8
