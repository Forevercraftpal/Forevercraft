# Ability Display: Hellenic Sword (Common Rogue Dagger)
tellraw @s ""
tellraw @s {text:"\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550",color:"gray",bold:true}
tellraw @s [{text:"  "},{text:"Hellenic Sword",color:"gray",bold:true}]
tellraw @s [{text:"  "},{text:"Common Rogue Dagger",color:"white"}]
tellraw @s {text:"\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550",color:"gray",bold:true}
tellraw @s ""
tellraw @s [{text:"  "},{text:"Auto-Swing: ",color:"white"},{text:"Every 1.5s",color:"yellow"}]
tellraw @s [{text:"  "},{text:"Damage: ",color:"white"},{text:"3 per swing, 1 target",color:"red"}]
tellraw @s [{text:"  "},{text:"Dual Wield: ",color:"white"},{text:"Every 0.7s",color:"gold"}]
tellraw @s [{text:"  "},{text:"Bonus: ",color:"white"},{text:"+5% Movement Speed while held",color:"green"}]
tellraw @s ""
tellraw @s [{text:"  "},{text:"Hold mainhand to auto-attack nearby enemies",color:"gray",italic:true}]
tellraw @s {text:"\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550",color:"gray",bold:true}
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.hat master @s ~ ~ ~ 0.5 1.8
