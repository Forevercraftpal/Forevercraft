# Ability Display: Glass Shovel (Ornate)
tellraw @s ""
tellraw @s {text:"══════════════════════════════",color:"dark_purple",bold:true}
tellraw @s [{text:"  "},{text:"Glass Shovel",color:"dark_purple",bold:true}]
tellraw @s [{text:"  "},{text:"Ornate Tool",color:"white"}]
tellraw @s [{text:"  "},{text:"Craft Class: ",color:"gray"},{text:"Terrawarp",color:"#C2B280",bold:true}]
tellraw @s {text:"══════════════════════════════",color:"dark_purple",bold:true}
tellraw @s ""
tellraw @s [{text:"  "},{text:"Set: Frost (0/7)",color:"gold"}]
tellraw @s [{text:"  "},{text:"2pc: Freeze attackers",color:"dark_gray"}]
tellraw @s [{text:"  "},{text:"4pc: Ice Aura + Blizzard ability",color:"dark_gray"}]
tellraw @s ""
tellraw @s [{text:"  "},{text:"Ability: Avalanche",color:"dark_purple",bold:true}]
tellraw @s [{text:"  "},{text:"Shoveling creates a small snow burst",color:"dark_purple"}]
tellraw @s ""
tellraw @s [{text:"    "},{text:"Snow flies where this shovel",color:"dark_gray",italic:true}]
tellraw @s [{text:"     "},{text:"digs. Avalanche guaranteed.",color:"dark_gray",italic:true}]
tellraw @s ""
tellraw @s {text:"══════════════════════════════",color:"dark_purple",bold:true}
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.hat master @s ~ ~ ~ 0.5 1.8
