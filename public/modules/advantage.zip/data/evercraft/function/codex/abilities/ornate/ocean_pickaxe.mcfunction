# Ability Display: Prismarine Pickaxe (Ornate)
tellraw @s ""
tellraw @s {text:"══════════════════════════════",color:"dark_purple",bold:true}
tellraw @s [{text:"  "},{text:"Prismarine Pickaxe",color:"dark_purple",bold:true}]
tellraw @s [{text:"  "},{text:"Ornate Tool",color:"white"}]
tellraw @s [{text:"  "},{text:"Craft Class: ",color:"gray"},{text:"Stonestrike",color:"gold",bold:true}]
tellraw @s {text:"══════════════════════════════",color:"dark_purple",bold:true}
tellraw @s ""
tellraw @s [{text:"  "},{text:"Set: Ocean (0/7)",color:"gold"}]
tellraw @s [{text:"  "},{text:"2pc: Water Breathing + Dolphin's Grace",color:"dark_gray"}]
tellraw @s [{text:"  "},{text:"4pc: Conduit Power + Tidal Wave",color:"dark_gray"}]
tellraw @s ""
tellraw @s [{text:"  "},{text:"Ability: Tidal Strike",color:"dark_purple",bold:true}]
tellraw @s [{text:"  "},{text:"Mining underwater causes no speed penalty",color:"dark_purple"}]
tellraw @s ""
tellraw @s [{text:"    "},{text:"Water is no obstacle. Mine",color:"dark_gray",italic:true}]
tellraw @s [{text:"     "},{text:"the ocean floor freely.",color:"dark_gray",italic:true}]
tellraw @s ""
tellraw @s {text:"══════════════════════════════",color:"dark_purple",bold:true}
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.hat master @s ~ ~ ~ 0.5 1.8
