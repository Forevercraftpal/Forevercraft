# Ability Display: Glass Pickaxe (Ornate)
tellraw @s ""
tellraw @s {text:"══════════════════════════════",color:"dark_purple",bold:true}
tellraw @s [{text:"  "},{text:"Glass Pickaxe",color:"dark_purple",bold:true}]
tellraw @s [{text:"  "},{text:"Ornate Tool",color:"white"}]
tellraw @s [{text:"  "},{text:"Craft Class: ",color:"gray"},{text:"Stonestrike",color:"gold",bold:true}]
tellraw @s {text:"══════════════════════════════",color:"dark_purple",bold:true}
tellraw @s ""
tellraw @s [{text:"  "},{text:"Set: Frost (0/7)",color:"gold"}]
tellraw @s [{text:"  "},{text:"2pc: Freeze attackers",color:"dark_gray"}]
tellraw @s [{text:"  "},{text:"4pc: Ice Aura + Blizzard ability",color:"dark_gray"}]
tellraw @s ""
tellraw @s [{text:"  "},{text:"Ability: Permafrost",color:"dark_purple",bold:true}]
tellraw @s [{text:"  "},{text:"Mined blocks drop bonus ice",color:"dark_purple"}]
tellraw @s ""
tellraw @s [{text:"    "},{text:"Mining with cold precision.",color:"dark_gray",italic:true}]
tellraw @s [{text:"     "},{text:"Ice preserves the ore.",color:"dark_gray",italic:true}]
tellraw @s ""
tellraw @s {text:"══════════════════════════════",color:"dark_purple",bold:true}
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.hat master @s ~ ~ ~ 0.5 1.8
