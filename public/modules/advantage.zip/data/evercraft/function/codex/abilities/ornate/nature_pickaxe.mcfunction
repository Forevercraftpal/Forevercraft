# Ability Display: Sakura Pickaxe (Ornate)
tellraw @s ""
tellraw @s {text:"══════════════════════════════",color:"dark_purple",bold:true}
tellraw @s [{text:"  "},{text:"Sakura Pickaxe",color:"dark_purple",bold:true}]
tellraw @s [{text:"  "},{text:"Ornate Tool",color:"white"}]
tellraw @s [{text:"  "},{text:"Craft Class: ",color:"gray"},{text:"Stonestrike",color:"gold",bold:true}]
tellraw @s {text:"══════════════════════════════",color:"dark_purple",bold:true}
tellraw @s ""
tellraw @s [{text:"  "},{text:"Set: Nature (0/7)",color:"gold"}]
tellraw @s [{text:"  "},{text:"2pc: Poison immunity + Regen aura",color:"dark_gray"}]
tellraw @s [{text:"  "},{text:"4pc: Living Vines + Nature's Wrath",color:"dark_gray"}]
tellraw @s ""
tellraw @s [{text:"  "},{text:"Ability: Root Strike",color:"dark_purple",bold:true}]
tellraw @s [{text:"  "},{text:"Mining stone occasionally drops saplings",color:"dark_purple"}]
tellraw @s ""
tellraw @s [{text:"    "},{text:"The earth yields saplings",color:"dark_gray",italic:true}]
tellraw @s [{text:"     "},{text:"when struck by nature.",color:"dark_gray",italic:true}]
tellraw @s ""
tellraw @s {text:"══════════════════════════════",color:"dark_purple",bold:true}
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.hat master @s ~ ~ ~ 0.5 1.8
