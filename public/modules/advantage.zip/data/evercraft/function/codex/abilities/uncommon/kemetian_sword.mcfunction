# Ability Display: Kemetian Sword (Uncommon)
tellraw @s ""
tellraw @s {text:"\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550",color:"blue",bold:true}
tellraw @s [{text:"  "},{text:"Kemetian Sword",color:"blue",bold:true}]
tellraw @s [{text:"  "},{text:"Uncommon Weapon",color:"white"}]
tellraw @s {text:"\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550",color:"blue",bold:true}
tellraw @s ""
tellraw @s [{text:"  "},{text:"On Hit: ",color:"white"},{text:"Fire Aspect I",color:"gold"}]
tellraw @s ""
tellraw @s [{text:"    "},{text:"Desert-forged steel that",color:"dark_gray",italic:true}]
tellraw @s [{text:"     "},{text:"burns on contact.",color:"dark_gray",italic:true}]
tellraw @s ""
tellraw @s {text:"\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550",color:"blue",bold:true}
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.hat master @s ~ ~ ~ 0.5 1.8
