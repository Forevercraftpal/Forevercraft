# Ability Display: Berserker Totem (Exquisite)
tellraw @s ""
tellraw @s {"text":"\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550","color":"light_purple","bold":true}
tellraw @s [{"text":"  "},{"text":"Berserker Totem","color":"light_purple","bold":true}]
tellraw @s [{"text":"  "},{"text":"Exquisite Accessory","color":"white"}]
tellraw @s {"text":"\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550","color":"light_purple","bold":true}
tellraw @s ""
tellraw @s [{"text":"  "},{"text":"\u25c6 Berserker Frenzy: ","color":"white"},{"text":"Str II + Speed II for 10s","color":"red"}]
tellraw @s [{"text":"  "},{"text":"\u25c6 : ","color":"white"},{"text":"on kill (stacks)","color":"red"}]
tellraw @s [{"text":"  "},{"text":"\u25c6 Passive: ","color":"white"},{"text":"Strength I, Haste I, +25% atk speed","color":"light_purple"}]
tellraw @s [{"text":"  "},{"text":"\u25c6 Lifesteal: ","color":"white"},{"text":"heal \u00bd heart on hit","color":"dark_red"}]

tellraw @s [{"text":"    "},{"text":"“Drives the holder into an","color":"dark_gray","italic":true}]
tellraw @s [{"text":"     "},{"text":"unstoppable combat frenzy.”","color":"dark_gray","italic":true}]

tellraw @s {"text":"\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550","color":"light_purple","bold":true}
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.hat master @s ~ ~ ~ 0.5 1.8
