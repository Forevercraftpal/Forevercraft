# Tick function for The Forevercraft Codex system
# Detects when players use the codex item → opens hub GUI
# All interactions now go through the entity-based hub (no more shift distinction or triggers)

# (Player existence guaranteed by main tick.mcfunction)

# OPT: Single @a dispatch replaces 4 separate @a scans
execute as @a[scores={ec.codex_use=1..},tag=!Adv.InMenu] at @s run function evercraft:codex/tick_player

# Tag in-menu players as actively right-clicking (using_item fired this tick)
# This is the authoritative held-right-click signal — codex/hub/tick uses it to block clicks
tag @a[scores={ec.codex_use=1..},tag=Adv.InMenu] add ec.codex_using

# Reset use score
scoreboard players set @a[scores={ec.codex_use=1..}] ec.codex_use 0

# ec.codex trigger objective removed 2026-05-26 (v1 text-UI archive — see _council/2026-05-26-dead-code-codex/).
# Prior code zeroed stale trigger values every tick; with the objective gone the zero-scan is unnecessary.
