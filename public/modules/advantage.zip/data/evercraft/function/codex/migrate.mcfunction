# Migrate codex items and ensure all players have a codex
# Runs on every /reload and server start via init.mcfunction

# Defensive migration — Audit #4 2026-05-28: section 14 (Class Affinity) was collapsed into section 20
execute if score @s adv.gui_section matches 14 run scoreboard players set @s adv.gui_section 20

# --- Step 1: Replace old recovery_compass codex items ---
tag @a remove ec.had_old_codex
execute as @a store success score @s ec.temp run clear @s recovery_compass[custom_data~{artifact_codex:true}] 0
execute as @a if score @s ec.temp matches 1.. run tag @s add ec.had_old_codex
execute as @a[tag=ec.had_old_codex] run clear @s recovery_compass[custom_data~{artifact_codex:true}]
execute as @a[tag=ec.had_old_codex] store result score #inv_full ec.var run function evercraft:util/check_inv_full
execute as @a[tag=ec.had_old_codex] if score #inv_full ec.var matches 0 run loot give @s loot evercraft:items/artifact_codex_item
execute as @a[tag=ec.had_old_codex] at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:items/artifact_codex_item
data modify storage evercraft:notify stage.c set value [{text:"Your codex has been upgraded!",color:"yellow"}]
scoreboard players set #ndur ec.temp 45
execute as @a[tag=ec.had_old_codex] run function evercraft:util/notify/emit
tag @a remove ec.had_old_codex

# --- Step 2: Replace old warped_fungus_on_a_stick codex items ---
tag @a remove ec.had_old_codex
execute as @a store success score @s ec.temp run clear @s warped_fungus_on_a_stick[custom_data~{artifact_codex:true}] 0
execute as @a if score @s ec.temp matches 1.. run tag @s add ec.had_old_codex
execute as @a[tag=ec.had_old_codex] run clear @s warped_fungus_on_a_stick[custom_data~{artifact_codex:true}]
execute as @a[tag=ec.had_old_codex] store result score #inv_full ec.var run function evercraft:util/check_inv_full
execute as @a[tag=ec.had_old_codex] if score #inv_full ec.var matches 0 run loot give @s loot evercraft:items/artifact_codex_item
execute as @a[tag=ec.had_old_codex] at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:items/artifact_codex_item
tag @a remove ec.had_old_codex

# --- Step 3: Replace old stick codex items with book ---
tag @a remove ec.had_old_codex
execute as @a store success score @s ec.temp run clear @s stick[custom_data~{artifact_codex:true}] 0
execute as @a if score @s ec.temp matches 1.. run tag @s add ec.had_old_codex
execute as @a[tag=ec.had_old_codex] run clear @s stick[custom_data~{artifact_codex:true}]
execute as @a[tag=ec.had_old_codex] store result score #inv_full ec.var run function evercraft:util/check_inv_full
execute as @a[tag=ec.had_old_codex] if score #inv_full ec.var matches 0 run loot give @s loot evercraft:items/artifact_codex_item
execute as @a[tag=ec.had_old_codex] at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:items/artifact_codex_item
data modify storage evercraft:notify stage.c set value [{text:"Your codex has been upgraded to a book!",color:"yellow"}]
scoreboard players set #ndur ec.temp 45
execute as @a[tag=ec.had_old_codex] run function evercraft:util/notify/emit
tag @a remove ec.had_old_codex

# --- Step 4: Refresh all existing codex items to latest version ---
# Ensures name, lore, and model are always up-to-date after changes
# 4a: Forevercraft Codex
tag @a remove ec.had_old_codex
execute as @a store success score @s ec.temp run clear @s book[custom_data~{artifact_codex:true}] 0
execute as @a if score @s ec.temp matches 1.. run tag @s add ec.had_old_codex
execute as @a[tag=ec.had_old_codex] run clear @s book[custom_data~{artifact_codex:true}]
execute as @a[tag=ec.had_old_codex] store result score #inv_full ec.var run function evercraft:util/check_inv_full
execute as @a[tag=ec.had_old_codex] if score #inv_full ec.var matches 0 run loot give @s loot evercraft:items/artifact_codex_item
execute as @a[tag=ec.had_old_codex] at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:items/artifact_codex_item
tag @a remove ec.had_old_codex
# 4b: Eternal Codex
tag @a remove ec.had_old_codex
execute as @a store success score @s ec.temp run clear @s book[custom_data~{eternal_codex:true}] 0
execute as @a if score @s ec.temp matches 1.. run tag @s add ec.had_old_codex
execute as @a[tag=ec.had_old_codex] run clear @s book[custom_data~{eternal_codex:true}]
execute as @a[tag=ec.had_old_codex] store result score #inv_full ec.var run function evercraft:util/check_inv_full
execute as @a[tag=ec.had_old_codex] if score #inv_full ec.var matches 0 run loot give @s loot evercraft:ecodex/eternal_codex
execute as @a[tag=ec.had_old_codex] at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:ecodex/eternal_codex
tag @a remove ec.had_old_codex
# 4c: Phoenix Codex
tag @a remove ec.had_old_codex
execute as @a store success score @s ec.temp run clear @s book[custom_data~{phoenix_codex:true}] 0
execute as @a if score @s ec.temp matches 1.. run tag @s add ec.had_old_codex
execute as @a[tag=ec.had_old_codex] run clear @s book[custom_data~{phoenix_codex:true}]
execute as @a[tag=ec.had_old_codex] store result score #inv_full ec.var run function evercraft:util/check_inv_full
execute as @a[tag=ec.had_old_codex] if score #inv_full ec.var matches 0 run loot give @s loot evercraft:phoenix/phoenix_codex
execute as @a[tag=ec.had_old_codex] at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:phoenix/phoenix_codex
tag @a remove ec.had_old_codex
# 4d: Craftforever Codex
tag @a remove ec.had_old_codex
execute as @a store success score @s ec.temp run clear @s book[custom_data~{craftforever_codex:true}] 0
execute as @a if score @s ec.temp matches 1.. run tag @s add ec.had_old_codex
execute as @a[tag=ec.had_old_codex] run clear @s book[custom_data~{craftforever_codex:true}]
execute as @a[tag=ec.had_old_codex] store result score #inv_full ec.var run function evercraft:util/check_inv_full
execute as @a[tag=ec.had_old_codex] if score #inv_full ec.var matches 0 run loot give @s loot evercraft:craftforever/codex_item
execute as @a[tag=ec.had_old_codex] at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:craftforever/codex_item
tag @a remove ec.had_old_codex

# --- Step 4: Bootstrap ec.has_artifacts for existing players ---
# Delegates to bootstrap function which checks ALL 265+ artifact advancements
function evercraft:codex/bootstrap_has_artifacts

# --- Step 5: Give codex to ALL online players who don't have one ---
# Tier-aware: give the player their highest unlocked codex variant
# Check if player already has ANY codex variant
tag @a remove ec.has_any_codex
execute as @a if items entity @s container.* book[custom_data~{artifact_codex:true}] run tag @s add ec.has_any_codex
execute as @a if items entity @s weapon.offhand book[custom_data~{artifact_codex:true}] run tag @s add ec.has_any_codex
execute as @a if items entity @s enderchest.* book[custom_data~{artifact_codex:true}] run tag @s add ec.has_any_codex
execute as @a if items entity @s container.* book[custom_data~{eternal_codex:true}] run tag @s add ec.has_any_codex
execute as @a if items entity @s weapon.offhand book[custom_data~{eternal_codex:true}] run tag @s add ec.has_any_codex
execute as @a if items entity @s enderchest.* book[custom_data~{eternal_codex:true}] run tag @s add ec.has_any_codex
execute as @a if items entity @s container.* book[custom_data~{phoenix_codex:true}] run tag @s add ec.has_any_codex
execute as @a if items entity @s weapon.offhand book[custom_data~{phoenix_codex:true}] run tag @s add ec.has_any_codex
execute as @a if items entity @s enderchest.* book[custom_data~{phoenix_codex:true}] run tag @s add ec.has_any_codex

# Give tier-appropriate codex to players missing one (only if they've earned iron pick)
execute as @a[tag=!ec.has_any_codex,advancements={minecraft:story/iron_tools=true}] if score @s ec.codex_tier matches 3.. store result score #inv_full ec.var run function evercraft:util/check_inv_full
execute as @a[tag=!ec.has_any_codex,advancements={minecraft:story/iron_tools=true}] if score @s ec.codex_tier matches 3.. if score #inv_full ec.var matches 0 run loot give @s loot evercraft:phoenix/phoenix_codex
execute as @a[tag=!ec.has_any_codex,advancements={minecraft:story/iron_tools=true}] if score @s ec.codex_tier matches 3.. at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:phoenix/phoenix_codex
execute as @a[tag=!ec.has_any_codex,advancements={minecraft:story/iron_tools=true}] if score @s ec.codex_tier matches 1..2 store result score #inv_full ec.var run function evercraft:util/check_inv_full
execute as @a[tag=!ec.has_any_codex,advancements={minecraft:story/iron_tools=true}] if score @s ec.codex_tier matches 1..2 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:ecodex/eternal_codex
execute as @a[tag=!ec.has_any_codex,advancements={minecraft:story/iron_tools=true}] if score @s ec.codex_tier matches 1..2 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:ecodex/eternal_codex
execute as @a[tag=!ec.has_any_codex,advancements={minecraft:story/iron_tools=true}] if score @s ec.codex_tier matches ..0 store result score #inv_full ec.var run function evercraft:util/check_inv_full
execute as @a[tag=!ec.has_any_codex,advancements={minecraft:story/iron_tools=true}] if score @s ec.codex_tier matches ..0 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:items/artifact_codex_item
execute as @a[tag=!ec.has_any_codex,advancements={minecraft:story/iron_tools=true}] if score @s ec.codex_tier matches ..0 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:items/artifact_codex_item
tag @a remove ec.has_any_codex
