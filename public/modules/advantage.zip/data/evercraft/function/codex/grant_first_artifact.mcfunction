# Grant The Forevercraft Codex item when player gets their first artifact
# This function runs as an advancement reward for every artifact collected
# Updated for Minecraft 1.21.11 syntax

# Mark player as having artifacts (persistent across reloads)
scoreboard players set @s ec.has_artifacts 1

# Real-time artifact discovery counter (never decrements)
scoreboard players add @s ec.artifacts_ever 1

# Check if player already has ANY codex variant (Forevercraft, Phoenix, or Eternal)
# across container, offhand, or enderchest. Combining into Eternal removes the
# artifact_codex tag, so without this widened guard the player gets a fresh
# Forevercraft Codex on every new artifact after combining.
execute unless items entity @s container.* book[custom_data~{artifact_codex:true}] unless items entity @s weapon.offhand book[custom_data~{artifact_codex:true}] unless items entity @s enderchest.* book[custom_data~{artifact_codex:true}] unless items entity @s container.* book[custom_data~{phoenix_codex:true}] unless items entity @s weapon.offhand book[custom_data~{phoenix_codex:true}] unless items entity @s enderchest.* book[custom_data~{phoenix_codex:true}] unless items entity @s container.* book[custom_data~{eternal_codex:true}] unless items entity @s weapon.offhand book[custom_data~{eternal_codex:true}] unless items entity @s enderchest.* book[custom_data~{eternal_codex:true}] run function evercraft:codex/give_codex_item

# Always show collection message
data modify storage evercraft:notify stage.c set value [{text:"📖 ",color:"yellow"},{text:"New Codex Entry!",color:"gold",bold:true}]
scoreboard players set #ndur ec.temp 50
function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"An artifact has been recorded in your ",color:"gray"},{text:"Forevercraft Codex",color:"yellow"},{text:".",color:"gray"}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Right-click your codex to view your collection.",color:"aqua",italic:true}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit

# New Codex Entry reveal — channel-gated (Off/Reduced/Full/Cracked). One-shot.
execute at @s run function evercraft:fx/collect/codex_entry

# Constellation progress check
function evercraft:constellations/check

# Guild XP for artifact discovery (+100)
function evercraft:guild/contribution/add_guild_xp_direct {amount:100}
