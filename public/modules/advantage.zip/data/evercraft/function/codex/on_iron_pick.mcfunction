# Give The Forevercraft Codex when a player crafts their first iron tool or shears
# (any of: iron pickaxe / axe / shovel / hoe, or shears — see advancement evercraft:codex/iron_pick).
# Generic by design: grants the codex to anyone who lacks one, regardless of which item triggered it.
# Triggered by advancement evercraft:codex/iron_pick

# Only give if they don't already have a codex
tag @s remove ec.has_any_codex
execute if items entity @s container.* book[custom_data~{artifact_codex:true}] run tag @s add ec.has_any_codex
execute if items entity @s weapon.offhand book[custom_data~{artifact_codex:true}] run tag @s add ec.has_any_codex
execute if items entity @s enderchest.* book[custom_data~{artifact_codex:true}] run tag @s add ec.has_any_codex
execute if items entity @s container.* book[custom_data~{eternal_codex:true}] run tag @s add ec.has_any_codex
execute if items entity @s weapon.offhand book[custom_data~{eternal_codex:true}] run tag @s add ec.has_any_codex
execute if items entity @s enderchest.* book[custom_data~{eternal_codex:true}] run tag @s add ec.has_any_codex
execute if items entity @s container.* book[custom_data~{phoenix_codex:true}] run tag @s add ec.has_any_codex
execute if items entity @s weapon.offhand book[custom_data~{phoenix_codex:true}] run tag @s add ec.has_any_codex
execute if items entity @s enderchest.* book[custom_data~{phoenix_codex:true}] run tag @s add ec.has_any_codex

execute if entity @s[tag=!ec.has_any_codex] run function evercraft:codex/give_codex_item
data modify storage evercraft:notify stage.c set value [{text:"Your journey into Forevercraft begins!",color:"gold",italic:true}]
scoreboard players set #ndur ec.temp 50
execute if entity @s[tag=!ec.has_any_codex] run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Use the Codex to track artifacts, lore, and more.",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 40
execute if entity @s[tag=!ec.has_any_codex] run function evercraft:util/notify/emit
execute if entity @s[tag=!ec.has_any_codex] if score @s ec.fx_snd matches 1.. run playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 1 1.2

tag @s remove ec.has_any_codex