# Give the player The Forevercraft Codex item
# Only called when they don't have one

# Try to give to inventory
# Inv-full guard: drop at the player's feet rather than void on a full inventory.
execute store result score #inv_full ec.var run function evercraft:util/check_inv_full
execute if score #inv_full ec.var matches 0 run loot give @s loot evercraft:items/artifact_codex_item
execute if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:items/artifact_codex_item

# Check if it actually landed in inventory
tag @s remove ec.codex_check
execute if items entity @s container.* book[custom_data~{artifact_codex:true}] run tag @s add ec.codex_check

# If NOT in inventory (full), drop at feet
execute if entity @s[tag=!ec.codex_check] at @s run loot spawn ~ ~ ~ loot evercraft:items/artifact_codex_item
data modify storage evercraft:notify stage.c set value [{text:"Your inventory was full! The Codex dropped at your feet.",color:"red",italic:true}]
scoreboard players set #ndur ec.temp 45
execute if entity @s[tag=!ec.codex_check] run function evercraft:util/notify/emit

tag @s remove ec.codex_check

data modify storage evercraft:notify stage.c set value [{text:"You received ",color:"yellow"},{text:"The Forevercraft Codex",color:"gold",bold:true},{text:"!",color:"yellow"}]
scoreboard players set #ndur ec.temp 50
function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Hold it and right-click to open.",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit
