# Tokens — Check Milestone Awards (with per-(tree × milestone) dedup)
# AU5-XB.3 (Joseph-locked 2026-05-28): dedup so each (tree, milestone) awards at most once.
#
# Caller sets:
#   #milestone_check adv.temp = new level
#   #milestone_tree  adv.temp = tree index (1=agility, 2=dexterity, 3=evasion, 4=stealth, 5=vitality,
#                                            6=taskmaster, 7=beastmaster, 8=victorian, 9=fishing,
#                                            10=mining, 11=gathering, 12=blacksmith, 13=explorer,
#                                            14=culinary, 15=chemistry)
#
# Dedup state: adv.tok_t1..adv.tok_t5 (5 scoreboards, one per milestone tier).
# Each holds a 15-bit field (bit positions 1..15 = tree indices).

# Only act on milestone levels (5/10/15/20/25)
execute unless score #milestone_check adv.temp matches 5 unless score #milestone_check adv.temp matches 10 unless score #milestone_check adv.temp matches 15 unless score #milestone_check adv.temp matches 20 unless score #milestone_check adv.temp matches 25 run return 0

# Tier (1..5)
scoreboard players set #tok_tier adv.temp 0
execute if score #milestone_check adv.temp matches 5 run scoreboard players set #tok_tier adv.temp 1
execute if score #milestone_check adv.temp matches 10 run scoreboard players set #tok_tier adv.temp 2
execute if score #milestone_check adv.temp matches 15 run scoreboard players set #tok_tier adv.temp 3
execute if score #milestone_check adv.temp matches 20 run scoreboard players set #tok_tier adv.temp 4
execute if score #milestone_check adv.temp matches 25 run scoreboard players set #tok_tier adv.temp 5

# Bit value = 2^(tree-1) for tree indices 1..15
scoreboard players set #tok_bitval adv.temp 0
execute if score #milestone_tree adv.temp matches 1 run scoreboard players set #tok_bitval adv.temp 1
execute if score #milestone_tree adv.temp matches 2 run scoreboard players set #tok_bitval adv.temp 2
execute if score #milestone_tree adv.temp matches 3 run scoreboard players set #tok_bitval adv.temp 4
execute if score #milestone_tree adv.temp matches 4 run scoreboard players set #tok_bitval adv.temp 8
execute if score #milestone_tree adv.temp matches 5 run scoreboard players set #tok_bitval adv.temp 16
execute if score #milestone_tree adv.temp matches 6 run scoreboard players set #tok_bitval adv.temp 32
execute if score #milestone_tree adv.temp matches 7 run scoreboard players set #tok_bitval adv.temp 64
execute if score #milestone_tree adv.temp matches 8 run scoreboard players set #tok_bitval adv.temp 128
execute if score #milestone_tree adv.temp matches 9 run scoreboard players set #tok_bitval adv.temp 256
execute if score #milestone_tree adv.temp matches 10 run scoreboard players set #tok_bitval adv.temp 512
execute if score #milestone_tree adv.temp matches 11 run scoreboard players set #tok_bitval adv.temp 1024
execute if score #milestone_tree adv.temp matches 12 run scoreboard players set #tok_bitval adv.temp 2048
execute if score #milestone_tree adv.temp matches 13 run scoreboard players set #tok_bitval adv.temp 4096
execute if score #milestone_tree adv.temp matches 14 run scoreboard players set #tok_bitval adv.temp 8192
execute if score #milestone_tree adv.temp matches 15 run scoreboard players set #tok_bitval adv.temp 16384
execute unless score #tok_bitval adv.temp matches 1.. run return 0

# Read the relevant per-tier bitfield into scratch
scoreboard players set #tok_field adv.temp 0
execute if score #tok_tier adv.temp matches 1 run scoreboard players operation #tok_field adv.temp = @s adv.tok_t1
execute if score #tok_tier adv.temp matches 2 run scoreboard players operation #tok_field adv.temp = @s adv.tok_t2
execute if score #tok_tier adv.temp matches 3 run scoreboard players operation #tok_field adv.temp = @s adv.tok_t3
execute if score #tok_tier adv.temp matches 4 run scoreboard players operation #tok_field adv.temp = @s adv.tok_t4
execute if score #tok_tier adv.temp matches 5 run scoreboard players operation #tok_field adv.temp = @s adv.tok_t5

# Bit test: (field / bitval) % 2 == 1 means already awarded
scoreboard players operation #tok_test adv.temp = #tok_field adv.temp
scoreboard players operation #tok_test adv.temp /= #tok_bitval adv.temp
scoreboard players operation #tok_test adv.temp %= #2 adv.temp
execute if score #tok_test adv.temp matches 1 run return 0

# Set the bit in the matching per-tier scoreboard
execute if score #tok_tier adv.temp matches 1 run scoreboard players operation @s adv.tok_t1 += #tok_bitval adv.temp
execute if score #tok_tier adv.temp matches 2 run scoreboard players operation @s adv.tok_t2 += #tok_bitval adv.temp
execute if score #tok_tier adv.temp matches 3 run scoreboard players operation @s adv.tok_t3 += #tok_bitval adv.temp
execute if score #tok_tier adv.temp matches 4 run scoreboard players operation @s adv.tok_t4 += #tok_bitval adv.temp
execute if score #tok_tier adv.temp matches 5 run scoreboard players operation @s adv.tok_t5 += #tok_bitval adv.temp

# Award tokens by tier (existing rate ladder: 2/5/10/20/50)
execute if score #tok_tier adv.temp matches 1 run data modify storage evercraft:tokens amount set value 2
execute if score #tok_tier adv.temp matches 1 run function evercraft:advantage/tokens/award with storage evercraft:tokens
execute if score #tok_tier adv.temp matches 2 run data modify storage evercraft:tokens amount set value 5
execute if score #tok_tier adv.temp matches 2 run function evercraft:advantage/tokens/award with storage evercraft:tokens
execute if score #tok_tier adv.temp matches 3 run data modify storage evercraft:tokens amount set value 10
execute if score #tok_tier adv.temp matches 3 run function evercraft:advantage/tokens/award with storage evercraft:tokens
execute if score #tok_tier adv.temp matches 4 run data modify storage evercraft:tokens amount set value 20
execute if score #tok_tier adv.temp matches 4 run function evercraft:advantage/tokens/award with storage evercraft:tokens
execute if score #tok_tier adv.temp matches 5 run data modify storage evercraft:tokens amount set value 50
execute if score #tok_tier adv.temp matches 5 run function evercraft:advantage/tokens/award with storage evercraft:tokens
