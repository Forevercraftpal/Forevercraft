# Fishing Multi-Catch — Roll for extra fish
# 0.12% per level chance to spawn extra fish from vanilla loot table
# Level 1-9: up to 2, 10-19: up to 3, 20-24: up to 4, 25: up to 5

# Calculate chance: level * 12 / 100 (per 10000 roll = 0.12% per level, max 3%)
scoreboard players operation #chance adv.temp = @s adv.fishing
scoreboard players operation #chance adv.temp *= #12 adv.temp
scoreboard players operation #chance adv.temp /= #100 adv.temp

# Gathering synergy bonus: +2.5% (250/10000) when all three gathering trees >= 15
execute if score @s adv.syn_gather matches 1 run scoreboard players add #chance adv.temp 250

# Tempest Lip Ripper — Double Hook: +25% multi-catch chance (2500/10000) when held
execute if items entity @s weapon.mainhand fishing_rod[custom_data~{artifact:"mythical_anglers_lip_ripper"}] run scoreboard players add #chance adv.temp 2500

# Roll 1-10000
execute store result score #roll adv.temp run random value 1..10000
execute unless score #roll adv.temp <= #chance adv.temp run return 0

# Extra catch 1 (always if proc)
# #fq_bonus_catch ec.temp tallies the bonus fish so questline/on_catch_hook can fold
# them into a catch_any quest (reset per-catch in ref/on_catch). Joseph 2026-06-04.
# Inv-full guard: drop at the player's feet rather than void on a full inventory.
execute store result score #inv_full ec.var run function evercraft:util/check_inv_full
execute if score #inv_full ec.var matches 0 run loot give @s loot minecraft:gameplay/fishing
execute if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot minecraft:gameplay/fishing
scoreboard players add #fq_bonus_catch ec.temp 1

# Extra catch 2 (level 10+)
execute if score @s adv.fishing matches 10.. store result score #roll adv.temp run random value 1..2
execute if score @s adv.fishing matches 10.. if score #roll adv.temp matches 1 if score #inv_full ec.var matches 0 run loot give @s loot minecraft:gameplay/fishing
execute if score @s adv.fishing matches 10.. if score #roll adv.temp matches 1 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot minecraft:gameplay/fishing
execute if score @s adv.fishing matches 10.. if score #roll adv.temp matches 1 run scoreboard players add #fq_bonus_catch ec.temp 1

# Extra catch 3 (level 20+)
execute if score @s adv.fishing matches 20.. store result score #roll adv.temp run random value 1..3
execute if score @s adv.fishing matches 20.. if score #roll adv.temp matches 1 if score #inv_full ec.var matches 0 run loot give @s loot minecraft:gameplay/fishing
execute if score @s adv.fishing matches 20.. if score #roll adv.temp matches 1 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot minecraft:gameplay/fishing
execute if score @s adv.fishing matches 20.. if score #roll adv.temp matches 1 run scoreboard players add #fq_bonus_catch ec.temp 1

# Extra catch 4 (level 25 only)
execute if score @s adv.fishing matches 25 store result score #roll adv.temp run random value 1..4
execute if score @s adv.fishing matches 25 if score #roll adv.temp matches 1 if score #inv_full ec.var matches 0 run loot give @s loot minecraft:gameplay/fishing
execute if score @s adv.fishing matches 25 if score #roll adv.temp matches 1 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot minecraft:gameplay/fishing
execute if score @s adv.fishing matches 25 if score #roll adv.temp matches 1 run scoreboard players add #fq_bonus_catch ec.temp 1

# Effects
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.experience_orb.pickup master @s ~ ~ ~ 0.5 1.5
data modify storage evercraft:notify stage.c set value [{text:"🐟 Multi-catch!",color:"aqua"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit

# Achievement tracking
