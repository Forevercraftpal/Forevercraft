# Increment attack-landed stat counter and revoke advancement to re-trigger
scoreboard players add @s adv.stat_attack 1
advancement revoke @s only evercraft:advantage/track_attack

# Companion on-hit roar (Mode 3): 25% chance, tier-scaled cooldown, 1/4 whistle damage.
# Self-gates on companion.activepet, so this is a cheap no-op for petless players.
function evercraft:companions/roar/on_hit

# Wiring Audit #16 W2.3: Marked for Death damage hook
# Self-gates on ec.party_id + adv.victorian + ec.party_marked target tag — cheap no-op otherwise.
function evercraft:party/combos/marked_damage

# Living Bough Wave 20: Hunter Mark of Death hook (sneak-hit mark apply +
# marked-target rider damage + same-tick death resolve). Self-gates: the HIT
# branch on #ht_marks ec.var (recounted 1s in bough/hunter/crown_tick, armed
# at apply), the APPLY branch on ec.ht_active + sneaking — cheap no-op
# otherwise. Rider damage is unattributed evercraft:bonus_strike (no
# player_hurt_entity re-fire → no dispatcher recursion).
function evercraft:bough/hunter/mark/on_attack

# Living Bough Wave 24: Knight Duelist's Eye hook — a U8 owner's landed hit
# stamps a 10s reveal (Glowing-through-walls, sustained in range by
# bough/knight/duel/tick) on the victim. Gated here on ec.kt_n_u8 — one
# score check, cheap no-op for everyone else. The reveal deals no damage →
# no dispatcher recursion.
execute if score @s ec.kt_n_u8 matches 1.. run function evercraft:bough/knight/duel/apply

# Living Bough Wave 25: Berserker Whirlwind hook — a Wrathblood owner's landed
# hit while SNEAKING in dual-axe stance spins a full-circle 3-block AoE (50%
# Rage Swing tier damage, 5s ec.bk_spin_cd). Gated here on ec.bk_b_crown —
# one score check, cheap no-op for everyone else. Spin damage is unattributed
# evercraft:bonus_strike (no player_hurt_entity re-fire → no dispatcher
# recursion).
execute if score @s ec.bk_b_crown matches 1.. run function evercraft:bough/berserker/spin/check
