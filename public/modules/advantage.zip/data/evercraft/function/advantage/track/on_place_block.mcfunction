# Increment blocks placed stat and revoke advancement to re-trigger
scoreboard players add @s adv.stat_place 1
advancement revoke @s only evercraft:advantage/track_place

# === BUILD QUESTS — untyped-incremental tally hook (Wave F1, R7; WA63-PERF gate added) ===
# TWO gate-first scores: a non-Build player stops on the first compare (ec.bq_active);
# a Build player on a NON-placement beat (home_tier / artifact / teach / etc.) stops on
# the second (ec.bq_place_active 0 there). on_place_tally only runs — and only runs
# get_quest twice — when a placement beat (place_any/variety) is actually active.
# on_place_tally handles the place_any/variety +1 (the untyped incremental beats);
# place_palette is detected separately by the tag-filtered palette advancements
# (the generic track_place trigger carries no block type). Cheap-gate-first per R7.
execute if score @s ec.bq_active matches 1 if score @s ec.bq_place_active matches 1 run function evercraft:build_quests/on_place_tally
