# Increment blocks placed stat and revoke advancement to re-trigger
scoreboard players add @s adv.stat_place 1
advancement revoke @s only evercraft:advantage/track_place

# === BUILD QUESTS — untyped-incremental tally hook (Wave F1, R7) ===
# ONE gate-first line: non-Build players pay exactly one score comparison and stop.
# on_place_tally handles the place_any/variety +1 (the untyped incremental beats);
# place_palette is detected separately by the tag-filtered palette advancements
# (the generic track_place trigger carries no block type). Cheap-gate-first per R7.
execute if score @s ec.bq_active matches 1 run function evercraft:build_quests/on_place_tally
