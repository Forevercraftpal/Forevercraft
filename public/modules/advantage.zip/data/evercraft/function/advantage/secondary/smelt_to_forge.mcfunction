# Secondary Stat: Smelting → Blacksmith
# Every 40 items smelted = 1 forge point
scoreboard players add @s adv.stat_vsmelt 1
scoreboard players operation #adv_temp ec.temp = @s adv.stat_vsmelt
scoreboard players operation #adv_temp ec.temp %= #40 adv.temp
execute if score #adv_temp ec.temp matches 0 run scoreboard players add @s adv.stat_forge 1
data modify storage evercraft:notify stage.c set value [{text:"+1 Forge XP (40 smelts)",color:"gray"}]
scoreboard players set #ndur ec.temp 45
execute if score #adv_temp ec.temp matches 0 run function evercraft:util/notify/emit
