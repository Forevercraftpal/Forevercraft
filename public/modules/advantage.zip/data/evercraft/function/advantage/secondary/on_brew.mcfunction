# Brewing detected — increment secondary stat and revoke for re-trigger
function evercraft:advantage/secondary/brew_to_chemistry
advancement revoke @s only evercraft:stat_tracking/brewing
