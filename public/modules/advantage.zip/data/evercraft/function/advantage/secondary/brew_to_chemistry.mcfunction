# Secondary Stat: Vanilla Brewing → Chemistry
# Every 20 vanilla potions brewed = 1 chemistry point
scoreboard players add @s adv.stat_vbrew 1
scoreboard players operation #adv_temp ec.temp = @s adv.stat_vbrew
scoreboard players operation #adv_temp ec.temp %= #20 adv.temp
execute if score #adv_temp ec.temp matches 0 run scoreboard players add @s adv.stat_brew 1
data modify storage evercraft:notify stage.c set value [{text:"+1 Chemistry XP (20 brews)",color:"gray"}]
scoreboard players set #ndur ec.temp 45
execute if score #adv_temp ec.temp matches 0 run function evercraft:util/notify/emit
