# Campfire cooking detected — increment secondary stat and revoke for re-trigger
function evercraft:advantage/secondary/campfire_to_cook
advancement revoke @s only evercraft:stat_tracking/campfire
