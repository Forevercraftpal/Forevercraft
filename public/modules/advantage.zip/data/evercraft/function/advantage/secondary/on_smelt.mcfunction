# Smelting detected — increment secondary stat and revoke for re-trigger
function evercraft:advantage/secondary/smelt_to_forge
advancement revoke @s only evercraft:stat_tracking/smelting
