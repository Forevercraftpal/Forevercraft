# Secondary Stat: Campfire Cooking → Culinary
# Every 20 campfire items = 1 cooking point
scoreboard players add @s adv.stat_campfire 1
scoreboard players operation #adv_temp ec.temp = @s adv.stat_campfire
scoreboard players operation #adv_temp ec.temp %= #20 adv.temp
execute if score #adv_temp ec.temp matches 0 run scoreboard players add @s adv.stat_cook 1
data modify storage evercraft:notify stage.c set value [{text:"+1 Cooking XP (20 campfire cooks)",color:"gray"}]
scoreboard players set #ndur ec.temp 45
execute if score #adv_temp ec.temp matches 0 run function evercraft:util/notify/emit
