# Page 1 click detection — Tree level-ups (0-13)
# Run as the player with menu open
# OPT: Added session filter (if score @s adv.gui_session = #gui_owner ec.temp)
#      to prevent multiplayer cross-click processing

execute as @e[type=interaction,tag=Adv.Click0,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction on target run function evercraft:advantage/gui/click_tree {tree_id:1}
execute as @e[type=interaction,tag=Adv.Click0,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=Adv.Click1,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction on target run function evercraft:advantage/gui/click_tree {tree_id:2}
execute as @e[type=interaction,tag=Adv.Click1,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=Adv.Click2,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction on target run function evercraft:advantage/gui/click_tree {tree_id:3}
execute as @e[type=interaction,tag=Adv.Click2,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=Adv.Click3,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction on target run function evercraft:advantage/gui/click_tree {tree_id:4}
execute as @e[type=interaction,tag=Adv.Click3,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=Adv.Click4,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction on target run function evercraft:advantage/gui/click_tree {tree_id:5}
execute as @e[type=interaction,tag=Adv.Click4,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=Adv.Click5,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction on target run function evercraft:advantage/gui/click_tree {tree_id:6}
execute as @e[type=interaction,tag=Adv.Click5,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=Adv.Click6,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction on target run function evercraft:advantage/gui/click_tree {tree_id:7}
execute as @e[type=interaction,tag=Adv.Click6,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=Adv.Click7,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction on target run function evercraft:advantage/gui/click_tree {tree_id:8}
execute as @e[type=interaction,tag=Adv.Click7,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=Adv.Click8,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction on target run function evercraft:advantage/gui/click_tree {tree_id:9}
execute as @e[type=interaction,tag=Adv.Click8,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=Adv.Click9,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction on target run function evercraft:advantage/gui/click_tree {tree_id:10}
execute as @e[type=interaction,tag=Adv.Click9,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=Adv.Click10,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction on target run function evercraft:advantage/gui/click_tree {tree_id:11}
execute as @e[type=interaction,tag=Adv.Click10,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=Adv.Click11,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction on target run function evercraft:advantage/gui/click_tree {tree_id:12}
execute as @e[type=interaction,tag=Adv.Click11,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=Adv.Click12,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction on target run function evercraft:advantage/gui/click_tree {tree_id:13}
execute as @e[type=interaction,tag=Adv.Click12,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=Adv.Click13,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction on target run function evercraft:advantage/gui/click_tree {tree_id:14}
execute as @e[type=interaction,tag=Adv.Click13,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=Adv.Click14,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction on target run function evercraft:advantage/gui/click_tree {tree_id:15}
execute as @e[type=interaction,tag=Adv.Click14,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction

# Branch [?] info clicks — one per column
execute as @e[type=interaction,tag=Adv.BranchInfoClick0,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction on target run function evercraft:advantage/gui/show_branch_info {branch:"adventure"}
execute as @e[type=interaction,tag=Adv.BranchInfoClick0,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=Adv.BranchInfoClick1,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction on target run function evercraft:advantage/gui/show_branch_info {branch:"progression"}
execute as @e[type=interaction,tag=Adv.BranchInfoClick1,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=Adv.BranchInfoClick2,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction on target run function evercraft:advantage/gui/show_branch_info {branch:"gathering"}
execute as @e[type=interaction,tag=Adv.BranchInfoClick2,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction

# Action buttons
execute as @e[type=interaction,tag=Adv.RespecBtnClick,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction on target run function evercraft:advantage/gui/enter_respec
execute as @e[type=interaction,tag=Adv.RespecBtnClick,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=Adv.StatsBtnClick,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction on target run function evercraft:advantage/gui/click_stats
execute as @e[type=interaction,tag=Adv.StatsBtnClick,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction

# ===== INSPECT (left-click = what does this button do?) — gui/inspect pattern 2026-06-11 =====
execute as @e[type=interaction,tag=Adv.Click0,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Agility Tree",b:"Right-click to spend points and raise the Agility tree — movement speed, dash mobility, fall mitigation."}
execute as @e[type=interaction,tag=Adv.Click0,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=Adv.Click1,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Dexterity Tree",b:"Right-click to spend points and raise the Dexterity tree — accuracy, draw speed, and weapon timing."}
execute as @e[type=interaction,tag=Adv.Click1,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=Adv.Click2,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Evasion Tree",b:"Right-click to spend points and raise the Evasion tree — dodge, knockback resist, and damage redirection."}
execute as @e[type=interaction,tag=Adv.Click2,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=Adv.Click3,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Stealth Tree",b:"Right-click to spend points and raise the Stealth tree — sneak speed, detection radius, backstab payoff."}
execute as @e[type=interaction,tag=Adv.Click3,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=Adv.Click4,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Vitality Tree",b:"Right-click to spend points and raise the Vitality tree — HP pool, regeneration, and revive thresholds."}
execute as @e[type=interaction,tag=Adv.Click4,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=Adv.Click5,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Taskmaster Tree",b:"Right-click to spend points and raise the Taskmaster tree — quest payouts, board-task rerolls, and bounty bonuses."}
execute as @e[type=interaction,tag=Adv.Click5,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=Adv.Click6,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Beastmaster Tree",b:"Right-click to spend points and raise the Beastmaster tree — companion damage, taming odds, and bonded perks."}
execute as @e[type=interaction,tag=Adv.Click6,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=Adv.Click7,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Victorian Tree",b:"Right-click to spend points and raise the Victorian tree — kill XP, killstreak rewards, and trophy yields."}
execute as @e[type=interaction,tag=Adv.Click7,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=Adv.Click8,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Fishing Tree",b:"Right-click to spend points and raise the Fishing tree — catch rate, rare-fish odds, and rod durability."}
execute as @e[type=interaction,tag=Adv.Click8,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=Adv.Click9,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Mining Tree",b:"Right-click to spend points and raise the Mining tree — ore yield, vein detection, and pick durability."}
execute as @e[type=interaction,tag=Adv.Click9,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=Adv.Click10,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Gathering Tree",b:"Right-click to spend points and raise the Gathering tree — node yield, regrowth speed, and tool durability."}
execute as @e[type=interaction,tag=Adv.Click10,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=Adv.Click11,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Blacksmith Tree",b:"Right-click to spend points and raise the Blacksmith tree — forge speed, repair efficiency, and unbreaking odds."}
execute as @e[type=interaction,tag=Adv.Click11,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=Adv.Click12,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Explorer Tree",b:"Right-click to spend points and raise the Explorer tree — map reveal, biome bonuses, and waypoint slots."}
execute as @e[type=interaction,tag=Adv.Click12,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=Adv.Click13,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Culinary Tree",b:"Right-click to spend points and raise the Culinary tree — cook yield, feast power, and recipe unlocks."}
execute as @e[type=interaction,tag=Adv.Click13,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=Adv.Click14,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Chemistry Tree",b:"Right-click to spend points and raise the Chemistry tree — brew yield, potion duration, and reagent pity."}
execute as @e[type=interaction,tag=Adv.Click14,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=Adv.BranchInfoClick0,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Adventure Branch Guide",b:"Right-click to print the Adventure branch's full perk list in chat — movement + survival trees — Agility, Dexterity, Evasion, Stealth, Vitality."}
execute as @e[type=interaction,tag=Adv.BranchInfoClick0,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=Adv.BranchInfoClick1,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Progression Branch Guide",b:"Right-click to print the Progression branch's full perk list in chat — class-progression trees — Taskmaster, Beastmaster, Victorian."}
execute as @e[type=interaction,tag=Adv.BranchInfoClick1,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=Adv.BranchInfoClick2,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Gathering Branch Guide",b:"Right-click to print the Gathering branch's full perk list in chat — gathering & craft trees — Fishing, Mining, Gathering, Blacksmith, Explorer, Culinary, Chemistry."}
execute as @e[type=interaction,tag=Adv.BranchInfoClick2,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=Adv.RespecBtnClick,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Respec",b:"Enters respec mode — reclaim the points you have spent in a tree."}
execute as @e[type=interaction,tag=Adv.RespecBtnClick,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=Adv.StatsBtnClick,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Statistics",b:"Shows your advantage totals — points earned, spent, and where."}
execute as @e[type=interaction,tag=Adv.StatsBtnClick,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack run data remove entity @s attack
