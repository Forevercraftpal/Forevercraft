# Chemistry prestige ability descriptions
tellraw @s {text:""}
tellraw @s [{text:"  ✦ ",color:"#9B59B6"},{text:"Chemistry",color:"#9B59B6",bold:true},{text:" — Prestige Abilities",color:"gray"}]
tellraw @s {text:"  ─────────────────────",color:"dark_gray"}
execute if score @s adv.pres_chem matches 1.. run tellraw @s [{text:"  P1 ",color:"gold"},{text:"Catalyst",color:"white",bold:true},{text:" — +15% chance to not consume brewing ingredients",color:"gray"}]
execute if score @s adv.pres_chem matches 1.. run tellraw @s [{text:"         ► ",color:"dark_gray"},{text:"Passive: brewing ingredients occasionally preserved",color:"dark_gray",italic:true}]
execute unless score @s adv.pres_chem matches 1.. run tellraw @s [{text:"  P1 ",color:"gold"},{text:"???",obfuscated:true,color:"dark_gray"},{text:" — Prestige to unlock",color:"dark_gray"}]
execute if score @s adv.pres_chem matches 2.. run tellraw @s [{text:"  P2 ",color:"gold"},{text:"Concentrated Brew",color:"white",bold:true},{text:" — Potions gain +1 amplifier level",color:"gray"}]
execute if score @s adv.pres_chem matches 2.. run tellraw @s [{text:"         ► ",color:"dark_gray"},{text:"Passive: brewed potions are one tier stronger",color:"dark_gray",italic:true}]
execute unless score @s adv.pres_chem matches 2.. run tellraw @s [{text:"  P2 ",color:"gold"},{text:"???",obfuscated:true,color:"dark_gray"},{text:" — Prestige to unlock",color:"dark_gray"}]
execute if score @s adv.pres_chem matches 3.. run tellraw @s [{text:"  P3 ",color:"gold"},{text:"Philosopher's Touch",color:"white",bold:true},{text:" — 10% chance to double potion output",color:"gray"}]
execute if score @s adv.pres_chem matches 3.. run tellraw @s [{text:"         ► ",color:"dark_gray"},{text:"Passive: brewing sometimes yields two potions",color:"dark_gray",italic:true}]
execute unless score @s adv.pres_chem matches 3.. run tellraw @s [{text:"  P3 ",color:"gold"},{text:"???",obfuscated:true,color:"dark_gray"},{text:" — Prestige to unlock",color:"dark_gray"}]
tellraw @s {text:""}
