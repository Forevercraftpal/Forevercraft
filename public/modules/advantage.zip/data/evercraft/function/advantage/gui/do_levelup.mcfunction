# Route to the correct levelup function and refresh display
# Macro arg: tree_id (1-15)
# Run as the player
# If tree is at Lv.25 with prestige<3, route to prestige instead

$scoreboard players set #tree_id adv.temp $(tree_id)

# Zero scratch FIRST: post-Pioneer-wipe a tree's adv.<skill> / adv.pres_<tree> entry can be
# ABSENT (strip_player_zero only re-sets 6 of 15 skill levels and 0 of the pres scores), so the
# gated `= @s` FAILS and #tree_lv / #tree_pres keep a PRIOR click's value (stale). A stale
# #tree_lv==25 would mis-route a Lv.1 tree into the prestige GUI. Init to 0 so a missing entry
# reads as level 0 → `matches 25` fails → normal level-up routing (correct for a wiped tree).
scoreboard players set #tree_lv adv.temp 0
scoreboard players set #tree_pres adv.temp 0

# Check if at max level (25) — read current tree level into #tree_lv
execute if score #tree_id adv.temp matches 1 run scoreboard players operation #tree_lv adv.temp = @s adv.agility
execute if score #tree_id adv.temp matches 2 run scoreboard players operation #tree_lv adv.temp = @s adv.dexterity
execute if score #tree_id adv.temp matches 3 run scoreboard players operation #tree_lv adv.temp = @s adv.evasion
execute if score #tree_id adv.temp matches 4 run scoreboard players operation #tree_lv adv.temp = @s adv.stealth
execute if score #tree_id adv.temp matches 5 run scoreboard players operation #tree_lv adv.temp = @s adv.vitality
execute if score #tree_id adv.temp matches 6 run scoreboard players operation #tree_lv adv.temp = @s adv.taskmaster
execute if score #tree_id adv.temp matches 7 run scoreboard players operation #tree_lv adv.temp = @s adv.beastmaster
execute if score #tree_id adv.temp matches 8 run scoreboard players operation #tree_lv adv.temp = @s adv.victorian
execute if score #tree_id adv.temp matches 9 run scoreboard players operation #tree_lv adv.temp = @s adv.fishing
execute if score #tree_id adv.temp matches 10 run scoreboard players operation #tree_lv adv.temp = @s adv.mining
execute if score #tree_id adv.temp matches 11 run scoreboard players operation #tree_lv adv.temp = @s adv.gathering
execute if score #tree_id adv.temp matches 12 run scoreboard players operation #tree_lv adv.temp = @s adv.blacksmith
execute if score #tree_id adv.temp matches 13 run scoreboard players operation #tree_lv adv.temp = @s adv.explorer
execute if score #tree_id adv.temp matches 14 run scoreboard players operation #tree_lv adv.temp = @s adv.culinary
execute if score #tree_id adv.temp matches 15 run scoreboard players operation #tree_lv adv.temp = @s adv.chemistry

# Check prestige level for this tree
execute if score #tree_id adv.temp matches 1 run scoreboard players operation #tree_pres adv.temp = @s adv.pres_agil
execute if score #tree_id adv.temp matches 2 run scoreboard players operation #tree_pres adv.temp = @s adv.pres_dext
execute if score #tree_id adv.temp matches 3 run scoreboard players operation #tree_pres adv.temp = @s adv.pres_evas
execute if score #tree_id adv.temp matches 4 run scoreboard players operation #tree_pres adv.temp = @s adv.pres_stea
execute if score #tree_id adv.temp matches 5 run scoreboard players operation #tree_pres adv.temp = @s adv.pres_vita
execute if score #tree_id adv.temp matches 6 run scoreboard players operation #tree_pres adv.temp = @s adv.pres_task
execute if score #tree_id adv.temp matches 7 run scoreboard players operation #tree_pres adv.temp = @s adv.pres_beas
execute if score #tree_id adv.temp matches 8 run scoreboard players operation #tree_pres adv.temp = @s adv.pres_vict
execute if score #tree_id adv.temp matches 9 run scoreboard players operation #tree_pres adv.temp = @s adv.pres_fish
execute if score #tree_id adv.temp matches 10 run scoreboard players operation #tree_pres adv.temp = @s adv.pres_mine
execute if score #tree_id adv.temp matches 11 run scoreboard players operation #tree_pres adv.temp = @s adv.pres_gath
execute if score #tree_id adv.temp matches 12 run scoreboard players operation #tree_pres adv.temp = @s adv.pres_blac
execute if score #tree_id adv.temp matches 13 run scoreboard players operation #tree_pres adv.temp = @s adv.pres_expl
execute if score #tree_id adv.temp matches 14 run scoreboard players operation #tree_pres adv.temp = @s adv.pres_culi
execute if score #tree_id adv.temp matches 15 run scoreboard players operation #tree_pres adv.temp = @s adv.pres_chem

# If at Lv.25 with prestige<3, route to prestige flow instead
$execute if score #tree_lv adv.temp matches 25 if score #tree_pres adv.temp matches ..2 run return run function evercraft:advantage/gui/do_prestige_gui {tree_id:$(tree_id)}

# Normal level-up routing
execute if score #tree_id adv.temp matches 1 run function evercraft:advantage/levelup/agility
execute if score #tree_id adv.temp matches 2 run function evercraft:advantage/levelup/dexterity
execute if score #tree_id adv.temp matches 3 run function evercraft:advantage/levelup/evasion
execute if score #tree_id adv.temp matches 4 run function evercraft:advantage/levelup/stealth
execute if score #tree_id adv.temp matches 5 run function evercraft:advantage/levelup/vitality
execute if score #tree_id adv.temp matches 6 run function evercraft:advantage/levelup/taskmaster
execute if score #tree_id adv.temp matches 7 run function evercraft:advantage/levelup/beastmaster
execute if score #tree_id adv.temp matches 8 run function evercraft:advantage/levelup/victorian
execute if score #tree_id adv.temp matches 9 run function evercraft:advantage/levelup/fishing
execute if score #tree_id adv.temp matches 10 run function evercraft:advantage/levelup/mining
execute if score #tree_id adv.temp matches 11 run function evercraft:advantage/levelup/gathering
execute if score #tree_id adv.temp matches 12 run function evercraft:advantage/levelup/blacksmith
execute if score #tree_id adv.temp matches 13 run function evercraft:advantage/levelup/explorer
execute if score #tree_id adv.temp matches 14 run function evercraft:advantage/levelup/culinary
execute if score #tree_id adv.temp matches 15 run function evercraft:advantage/levelup/chemistry

# NOTE 2026-05-28: max-level celebration is fired by the per-tree levelup file itself
# (every levelup/<tree>.mcfunction line ~39 calls levelup/max_celebration {tree_name:"..."}).
# Calling celebrate_max here would fire a SECOND firework+tellraw round; removed to prevent double-celebrate.
# celebrate_max.mcfunction is preserved as canonical-by-tree-id form for any future caller.

# Refresh all tree displays after levelup attempt
function evercraft:advantage/gui/refresh
