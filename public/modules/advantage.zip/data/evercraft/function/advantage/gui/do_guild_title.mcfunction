# Run as the player — Macro: $(id) = 1-8
# Toggle/equip guild diplomacy title
$scoreboard players set #gd_id adv.temp $(id)

# Guild titles are always unlocked once earned — check ec.gd_title for current
# No bitfield needed — guild titles are granted directly via ec.gd_title

# Toggle: if already active, deactivate
scoreboard players set #cc_did adv.temp 0
execute if score @s ec.gd_title = #gd_id adv.temp run scoreboard players set #cc_did adv.temp 1
execute if score #cc_did adv.temp matches 1 run scoreboard players set @s ec.gd_title 0
execute if score #cc_did adv.temp matches 1 run team leave @s
data modify storage evercraft:notify stage.c set value [{text:"Title removed.",color:"gray"}]
scoreboard players set #ndur ec.temp 45
execute if score #cc_did adv.temp matches 1 run function evercraft:util/notify/emit
execute if score #cc_did adv.temp matches 1 if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.hat master @s ~ ~ ~ 0.5 0.8
execute if score #cc_did adv.temp matches 1 run function evercraft:advantage/gui/refresh_special_titles
execute if score #cc_did adv.temp matches 1 run return 0

# Wiring Audit #31 (Fo1): gate equip on EARNED wins/losses — close the no-check exploit.
# Win titles 1-4 need ec.gd_wins >= 1/5/15/30; loss titles 5-8 need ec.gd_losses >= 1/5/15/30.
# (Thresholds mirror check_win/check_loss; gd_wins/gd_losses are monotonic persisted counters.)
scoreboard players set #gd_ok adv.temp 0
execute if score #gd_id adv.temp matches 1 if score @s ec.gd_wins matches 1.. run scoreboard players set #gd_ok adv.temp 1
execute if score #gd_id adv.temp matches 2 if score @s ec.gd_wins matches 5.. run scoreboard players set #gd_ok adv.temp 1
execute if score #gd_id adv.temp matches 3 if score @s ec.gd_wins matches 15.. run scoreboard players set #gd_ok adv.temp 1
execute if score #gd_id adv.temp matches 4 if score @s ec.gd_wins matches 30.. run scoreboard players set #gd_ok adv.temp 1
execute if score #gd_id adv.temp matches 5 if score @s ec.gd_losses matches 1.. run scoreboard players set #gd_ok adv.temp 1
execute if score #gd_id adv.temp matches 6 if score @s ec.gd_losses matches 5.. run scoreboard players set #gd_ok adv.temp 1
execute if score #gd_id adv.temp matches 7 if score @s ec.gd_losses matches 15.. run scoreboard players set #gd_ok adv.temp 1
execute if score #gd_id adv.temp matches 8 if score @s ec.gd_losses matches 30.. run scoreboard players set #gd_ok adv.temp 1
data modify storage evercraft:notify stage.c set value [{text:"You haven't earned that title yet.",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute if score #gd_ok adv.temp matches 0 run function evercraft:util/notify/emit
execute if score #gd_ok adv.temp matches 0 if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 0.5 0.8
execute if score #gd_ok adv.temp matches 0 run return 0

# Clear all other titles for mutual exclusivity, then activate
function evercraft:titles/clear_all
scoreboard players operation @s ec.gd_title = #gd_id adv.temp
function evercraft:guild/diplomacy/titles/apply
data modify storage evercraft:notify stage.c set value [{text:"Title applied!",color:"green"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.chime master @s ~ ~ ~ 0.5 1.2
function evercraft:advantage/gui/refresh_special_titles
