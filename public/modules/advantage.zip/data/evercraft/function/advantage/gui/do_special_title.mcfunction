# Run as the player — Macro: $(id) = 1-18
# Toggle/equip special title (Dream Journal, Reputation, or Guild-Card guild rank)
# IDs 1-7 = Dream/Reputation (bits 0-6); IDs 8-13 = Merchant/Adventurer guild ranks
# (bits 7-12, v1.1); IDs 14-16 = Handcrafter (Builder) titles (bits 13-15, W3, R4);
# ID 17 = Master Tinkerer (bit 16, pow 65536, Tinkering line capstone, C8);
# ID 18 = Wayfarer (bit 17, pow 131072, Wayfarer's Pass capstone).
$scoreboard players set #sp_id adv.temp $(id)

# Power-of-2 lookup for bit check (bit = id-1)
scoreboard players set #sp_pow adv.temp 0
execute if score #sp_id adv.temp matches 1 run scoreboard players set #sp_pow adv.temp 1
execute if score #sp_id adv.temp matches 2 run scoreboard players set #sp_pow adv.temp 2
execute if score #sp_id adv.temp matches 3 run scoreboard players set #sp_pow adv.temp 4
execute if score #sp_id adv.temp matches 4 run scoreboard players set #sp_pow adv.temp 8
execute if score #sp_id adv.temp matches 5 run scoreboard players set #sp_pow adv.temp 16
execute if score #sp_id adv.temp matches 6 run scoreboard players set #sp_pow adv.temp 32
execute if score #sp_id adv.temp matches 7 run scoreboard players set #sp_pow adv.temp 64
execute if score #sp_id adv.temp matches 8 run scoreboard players set #sp_pow adv.temp 128
execute if score #sp_id adv.temp matches 9 run scoreboard players set #sp_pow adv.temp 256
execute if score #sp_id adv.temp matches 10 run scoreboard players set #sp_pow adv.temp 512
execute if score #sp_id adv.temp matches 11 run scoreboard players set #sp_pow adv.temp 1024
execute if score #sp_id adv.temp matches 12 run scoreboard players set #sp_pow adv.temp 2048
execute if score #sp_id adv.temp matches 13 run scoreboard players set #sp_pow adv.temp 4096
execute if score #sp_id adv.temp matches 14 run scoreboard players set #sp_pow adv.temp 8192
execute if score #sp_id adv.temp matches 15 run scoreboard players set #sp_pow adv.temp 16384
execute if score #sp_id adv.temp matches 16 run scoreboard players set #sp_pow adv.temp 32768
execute if score #sp_id adv.temp matches 17 run scoreboard players set #sp_pow adv.temp 65536
execute if score #sp_id adv.temp matches 18 run scoreboard players set #sp_pow adv.temp 131072

# Check bit: (ec.special_titles / pow) % 2
scoreboard players set #sp_check adv.temp 0
scoreboard players operation #sp_check adv.temp = @s ec.special_titles
scoreboard players operation #sp_check adv.temp /= #sp_pow adv.temp
scoreboard players operation #sp_check adv.temp %= #2 adv.temp

# Reject if locked
data modify storage evercraft:notify stage.c set value [{text:"Title locked!",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute if score #sp_check adv.temp matches 0 run function evercraft:util/notify/emit
execute if score #sp_check adv.temp matches 0 if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 0.5 0.5
execute if score #sp_check adv.temp matches 0 run return 0

# Toggle: if already active, deactivate
scoreboard players set #cc_did adv.temp 0
execute if score @s ec.special_title = #sp_id adv.temp run scoreboard players set #cc_did adv.temp 1
execute if score #cc_did adv.temp matches 1 run scoreboard players set @s ec.special_title 0
execute if score #cc_did adv.temp matches 1 run team leave @s
data modify storage evercraft:notify stage.c set value [{text:"Title removed.",color:"gray"}]
scoreboard players set #ndur ec.temp 45
execute if score #cc_did adv.temp matches 1 run function evercraft:util/notify/emit
execute if score #cc_did adv.temp matches 1 if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.hat master @s ~ ~ ~ 0.5 0.8
execute if score #cc_did adv.temp matches 1 run function evercraft:advantage/gui/refresh_special_titles
execute if score #cc_did adv.temp matches 1 run return 0

# Clear all other titles for mutual exclusivity, then activate
function evercraft:titles/clear_all
scoreboard players operation @s ec.special_title = #sp_id adv.temp
function evercraft:titles/apply_special
data modify storage evercraft:notify stage.c set value [{text:"Title applied!",color:"green"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.chime master @s ~ ~ ~ 0.5 1.2
function evercraft:advantage/gui/refresh_special_titles
