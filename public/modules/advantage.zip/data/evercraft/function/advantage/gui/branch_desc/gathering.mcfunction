# Gathering Branch — all 5 trees
tellraw @s {text:""}
tellraw @s [{text:"  🌿 ",color:"green"},{text:"Gathering Branch",color:"green",bold:true}]
tellraw @s {text:"  ─────────────────────",color:"dark_gray"}

# Fishing: +0.625%/level (fractional — show level only)
tellraw @s [{text:"  Fishing ",color:"blue",bold:true},{text:"— Multi-catch chance (+0.625%/lvl)",color:"white"}]
tellraw @s [{text:"    Lv.",color:"gray"},{score:{name:"@s",objective:"adv.fishing"},color:"blue"},{text:" — chance increases each level",color:"gray"}]
tellraw @s [{text:"    Fish caught: ",color:"gray"},{score:{name:"@s",objective:"adv.stat_fish"},color:"blue"},{text:"  (2k→50k)",color:"dark_gray"}]
execute if score @s adv.lb_tree matches 9 run tellraw @s [{text:"    Live XP bar: ",color:"gray"},{text:"[ ON ]",color:"green",bold:true,click_event:{action:run_command,command:"/trigger adv.lb_track set 9"},hover_event:{action:show_text,value:{text:"Click to stop the live bar",color:"gray"}}}]
execute unless score @s adv.lb_tree matches 9 run tellraw @s [{text:"    Live XP bar: ",color:"gray"},{text:"[ OFF ]",color:"red",bold:true,click_event:{action:run_command,command:"/trigger adv.lb_track set 9"},hover_event:{action:show_text,value:{text:"Click to show a live bar while you fish for Fishing XP",color:"gray"}}}]

# Mining: tiered haste surge (show level only)
tellraw @s [{text:"  Mining ",color:"gold",bold:true},{text:"— Miner's Surge haste chance",color:"white"}]
tellraw @s [{text:"    Lv.",color:"gray"},{score:{name:"@s",objective:"adv.mining"},color:"gold"},{text:" — surge grows stronger each tier",color:"gray"}]
tellraw @s [{text:"    Blocks mined: ",color:"gray"},{score:{name:"@s",objective:"adv.stat_mine"},color:"gold"},{text:"  (40k→1M)",color:"dark_gray"}]
execute if score @s adv.lb_tree matches 10 run tellraw @s [{text:"    Live XP bar: ",color:"gray"},{text:"[ ON ]",color:"green",bold:true,click_event:{action:run_command,command:"/trigger adv.lb_track set 10"},hover_event:{action:show_text,value:{text:"Click to stop the live bar",color:"gray"}}}]
execute unless score @s adv.lb_tree matches 10 run tellraw @s [{text:"    Live XP bar: ",color:"gray"},{text:"[ OFF ]",color:"red",bold:true,click_event:{action:run_command,command:"/trigger adv.lb_track set 10"},hover_event:{action:show_text,value:{text:"Click to show a live bar while you mine for Mining XP",color:"gray"}}}]

# Gathering: +0.625%/level (fractional — show level only)
tellraw @s [{text:"  Gathering ",color:"green",bold:true},{text:"— Extra crop drops (+0.625%/lvl)",color:"white"}]
tellraw @s [{text:"    Lv.",color:"gray"},{score:{name:"@s",objective:"adv.gathering"},color:"green"},{text:" — chance increases each level",color:"gray"}]
tellraw @s [{text:"    Crops harvested: ",color:"gray"},{score:{name:"@s",objective:"adv.stat_harvest"},color:"green"},{text:"  (1k→25k)",color:"dark_gray"}]
execute if score @s adv.lb_tree matches 11 run tellraw @s [{text:"    Live XP bar: ",color:"gray"},{text:"[ ON ]",color:"green",bold:true,click_event:{action:run_command,command:"/trigger adv.lb_track set 11"},hover_event:{action:show_text,value:{text:"Click to stop the live bar",color:"gray"}}}]
execute unless score @s adv.lb_tree matches 11 run tellraw @s [{text:"    Live XP bar: ",color:"gray"},{text:"[ OFF ]",color:"red",bold:true,click_event:{action:run_command,command:"/trigger adv.lb_track set 11"},hover_event:{action:show_text,value:{text:"Click to show a live bar while you harvest for Gathering XP",color:"gray"}}}]

# Blacksmith: furnace smelt speed (non-linear scaling)
tellraw @s [{text:"  Blacksmith ",color:"gray",bold:true},{text:"— Nearby furnaces smelt faster",color:"white"}]
tellraw @s [{text:"    Lv.",color:"gray"},{score:{name:"@s",objective:"adv.blacksmith"},color:"gray"},{text:" — smelt speed grows each level",color:"gray"}]
tellraw @s [{text:"    Items smelted: ",color:"gray"},{score:{name:"@s",objective:"adv.stat_smelt"},color:"gray"},{text:"  (2k→50k)",color:"dark_gray"}]
execute if score @s adv.lb_tree matches 12 run tellraw @s [{text:"    Live XP bar: ",color:"gray"},{text:"[ ON ]",color:"green",bold:true,click_event:{action:run_command,command:"/trigger adv.lb_track set 12"},hover_event:{action:show_text,value:{text:"Click to stop the live bar",color:"gray"}}}]
execute unless score @s adv.lb_tree matches 12 run tellraw @s [{text:"    Live XP bar: ",color:"gray"},{text:"[ OFF ]",color:"red",bold:true,click_event:{action:run_command,command:"/trigger adv.lb_track set 12"},hover_event:{action:show_text,value:{text:"Click to show a live bar while you smelt for Blacksmith XP",color:"gray"}}}]

# Explorer: level*4% cooldown reduction
scoreboard players operation @s adv.temp = @s adv.explorer
scoreboard players operation @s adv.temp *= #4 adv.temp
tellraw @s [{text:"  Explorer ",color:"dark_aqua",bold:true},{text:"— Structure crate cooldown reduced",color:"white"}]
tellraw @s [{text:"    Lv.",color:"gray"},{score:{name:"@s",objective:"adv.explorer"},color:"dark_aqua"},{text:" → -",color:"gray"},{score:{name:"@s",objective:"adv.temp"},color:"dark_aqua"},{text:"% cooldown",color:"gray"}]
tellraw @s [{text:"    Structure crates looted: ",color:"gray"},{score:{name:"@s",objective:"adv.stat_struct"},color:"dark_aqua"},{text:"  (100→2.5k)",color:"dark_gray"}]
execute if score @s adv.lb_tree matches 13 run tellraw @s [{text:"    Live XP bar: ",color:"gray"},{text:"[ ON ]",color:"green",bold:true,click_event:{action:run_command,command:"/trigger adv.lb_track set 13"},hover_event:{action:show_text,value:{text:"Click to stop the live bar",color:"gray"}}}]
execute unless score @s adv.lb_tree matches 13 run tellraw @s [{text:"    Live XP bar: ",color:"gray"},{text:"[ OFF ]",color:"red",bold:true,click_event:{action:run_command,command:"/trigger adv.lb_track set 13"},hover_event:{action:show_text,value:{text:"Click to show a live bar while you loot for Explorer XP",color:"gray"}}}]
tellraw @s {text:""}
