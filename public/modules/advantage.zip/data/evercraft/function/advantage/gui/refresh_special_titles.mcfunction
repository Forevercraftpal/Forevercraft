# Refresh Special Titles page (page 6) — 26 items
# Dream Journal (SPT0-SPT1), Reputation (SPT2-SPT6), Guild Diplomacy (SPT7-SPT14),
# Guild Ranks (SPT15-SPT20), Handcrafter (SPT21-SPT23), Tinkering (SPT24), Wayfarer (SPT25)

# ============================================================
# Dream Journal Titles
# ============================================================

# SPT0: Dreamkeeper (bit 0, pow=1, ec.special_title=1)
scoreboard players operation #gui_stamp ec.temp = @s adv.gui_session

scoreboard players set #sp_check adv.temp 0
scoreboard players operation #sp_check adv.temp = @s ec.special_titles
scoreboard players set #sp_pow adv.temp 1
scoreboard players operation #sp_check adv.temp /= #sp_pow adv.temp
scoreboard players operation #sp_check adv.temp %= #2 adv.temp
execute if score #sp_check adv.temp matches 0 as @e[type=marker,tag=Adv.MenuAnchor,distance=..5] if score @s adv.gui_session = #gui_stamp ec.temp at @s run data modify entity @e[type=text_display,tag=Adv.SPT0,distance=..5,limit=1,sort=nearest] text set value {text:"Dreamkeeper  [Locked]",color:"dark_gray"}
execute if score #sp_check adv.temp matches 1 unless score @s ec.special_title matches 1 as @e[type=marker,tag=Adv.MenuAnchor,distance=..5] if score @s adv.gui_session = #gui_stamp ec.temp at @s run data modify entity @e[type=text_display,tag=Adv.SPT0,distance=..5,limit=1,sort=nearest] text set value {text:"Dreamkeeper",color:"#CE93D8"}
execute if score @s ec.special_title matches 1 as @e[type=marker,tag=Adv.MenuAnchor,distance=..5] if score @s adv.gui_session = #gui_stamp ec.temp at @s run data modify entity @e[type=text_display,tag=Adv.SPT0,distance=..5,limit=1,sort=nearest] text set value [{text:"Dreamkeeper  ",color:"green"},{text:"[ACTIVE]",color:"green",bold:true}]

# SPT1: Dream Chronicler (bit 1, pow=2, ec.special_title=2)
scoreboard players set #sp_check adv.temp 0
scoreboard players operation #sp_check adv.temp = @s ec.special_titles
scoreboard players set #sp_pow adv.temp 2
scoreboard players operation #sp_check adv.temp /= #sp_pow adv.temp
scoreboard players operation #sp_check adv.temp %= #2 adv.temp
execute if score #sp_check adv.temp matches 0 as @e[type=marker,tag=Adv.MenuAnchor,distance=..5] if score @s adv.gui_session = #gui_stamp ec.temp at @s run data modify entity @e[type=text_display,tag=Adv.SPT1,distance=..5,limit=1,sort=nearest] text set value {text:"Dream Chronicler  [Locked]",color:"dark_gray"}
execute if score #sp_check adv.temp matches 1 unless score @s ec.special_title matches 2 as @e[type=marker,tag=Adv.MenuAnchor,distance=..5] if score @s adv.gui_session = #gui_stamp ec.temp at @s run data modify entity @e[type=text_display,tag=Adv.SPT1,distance=..5,limit=1,sort=nearest] text set value {text:"Dream Chronicler",color:"#AB47BC"}
execute if score @s ec.special_title matches 2 as @e[type=marker,tag=Adv.MenuAnchor,distance=..5] if score @s adv.gui_session = #gui_stamp ec.temp at @s run data modify entity @e[type=text_display,tag=Adv.SPT1,distance=..5,limit=1,sort=nearest] text set value [{text:"Dream Chronicler  ",color:"green"},{text:"[ACTIVE]",color:"green",bold:true}]

# ============================================================
# Reputation Titles
# ============================================================

# SPT2: Acquaintance (bit 2, pow=4, ec.special_title=3)
scoreboard players set #sp_check adv.temp 0
scoreboard players operation #sp_check adv.temp = @s ec.special_titles
scoreboard players set #sp_pow adv.temp 4
scoreboard players operation #sp_check adv.temp /= #sp_pow adv.temp
scoreboard players operation #sp_check adv.temp %= #2 adv.temp
execute if score #sp_check adv.temp matches 0 as @e[type=marker,tag=Adv.MenuAnchor,distance=..5] if score @s adv.gui_session = #gui_stamp ec.temp at @s run data modify entity @e[type=text_display,tag=Adv.SPT2,distance=..5,limit=1,sort=nearest] text set value {text:"Acquaintance  [Locked]",color:"dark_gray"}
execute if score #sp_check adv.temp matches 1 unless score @s ec.special_title matches 3 as @e[type=marker,tag=Adv.MenuAnchor,distance=..5] if score @s adv.gui_session = #gui_stamp ec.temp at @s run data modify entity @e[type=text_display,tag=Adv.SPT2,distance=..5,limit=1,sort=nearest] text set value {text:"Acquaintance",color:"yellow"}
execute if score @s ec.special_title matches 3 as @e[type=marker,tag=Adv.MenuAnchor,distance=..5] if score @s adv.gui_session = #gui_stamp ec.temp at @s run data modify entity @e[type=text_display,tag=Adv.SPT2,distance=..5,limit=1,sort=nearest] text set value [{text:"Acquaintance  ",color:"green"},{text:"[ACTIVE]",color:"green",bold:true}]

# SPT3: Friend (bit 3, pow=8, ec.special_title=4)
scoreboard players set #sp_check adv.temp 0
scoreboard players operation #sp_check adv.temp = @s ec.special_titles
scoreboard players set #sp_pow adv.temp 8
scoreboard players operation #sp_check adv.temp /= #sp_pow adv.temp
scoreboard players operation #sp_check adv.temp %= #2 adv.temp
execute if score #sp_check adv.temp matches 0 as @e[type=marker,tag=Adv.MenuAnchor,distance=..5] if score @s adv.gui_session = #gui_stamp ec.temp at @s run data modify entity @e[type=text_display,tag=Adv.SPT3,distance=..5,limit=1,sort=nearest] text set value {text:"Friend  [Locked]",color:"dark_gray"}
execute if score #sp_check adv.temp matches 1 unless score @s ec.special_title matches 4 as @e[type=marker,tag=Adv.MenuAnchor,distance=..5] if score @s adv.gui_session = #gui_stamp ec.temp at @s run data modify entity @e[type=text_display,tag=Adv.SPT3,distance=..5,limit=1,sort=nearest] text set value {text:"Friend",color:"green"}
execute if score @s ec.special_title matches 4 as @e[type=marker,tag=Adv.MenuAnchor,distance=..5] if score @s adv.gui_session = #gui_stamp ec.temp at @s run data modify entity @e[type=text_display,tag=Adv.SPT3,distance=..5,limit=1,sort=nearest] text set value [{text:"Friend  ",color:"green"},{text:"[ACTIVE]",color:"green",bold:true}]

# SPT4: Ally (bit 4, pow=16, ec.special_title=5)
scoreboard players set #sp_check adv.temp 0
scoreboard players operation #sp_check adv.temp = @s ec.special_titles
scoreboard players set #sp_pow adv.temp 16
scoreboard players operation #sp_check adv.temp /= #sp_pow adv.temp
scoreboard players operation #sp_check adv.temp %= #2 adv.temp
execute if score #sp_check adv.temp matches 0 as @e[type=marker,tag=Adv.MenuAnchor,distance=..5] if score @s adv.gui_session = #gui_stamp ec.temp at @s run data modify entity @e[type=text_display,tag=Adv.SPT4,distance=..5,limit=1,sort=nearest] text set value {text:"Ally  [Locked]",color:"dark_gray"}
execute if score #sp_check adv.temp matches 1 unless score @s ec.special_title matches 5 as @e[type=marker,tag=Adv.MenuAnchor,distance=..5] if score @s adv.gui_session = #gui_stamp ec.temp at @s run data modify entity @e[type=text_display,tag=Adv.SPT4,distance=..5,limit=1,sort=nearest] text set value {text:"Ally",color:"aqua"}
execute if score @s ec.special_title matches 5 as @e[type=marker,tag=Adv.MenuAnchor,distance=..5] if score @s adv.gui_session = #gui_stamp ec.temp at @s run data modify entity @e[type=text_display,tag=Adv.SPT4,distance=..5,limit=1,sort=nearest] text set value [{text:"Ally  ",color:"green"},{text:"[ACTIVE]",color:"green",bold:true}]

# SPT5: Hero (bit 5, pow=32, ec.special_title=6)
scoreboard players set #sp_check adv.temp 0
scoreboard players operation #sp_check adv.temp = @s ec.special_titles
scoreboard players set #sp_pow adv.temp 32
scoreboard players operation #sp_check adv.temp /= #sp_pow adv.temp
scoreboard players operation #sp_check adv.temp %= #2 adv.temp
execute if score #sp_check adv.temp matches 0 as @e[type=marker,tag=Adv.MenuAnchor,distance=..5] if score @s adv.gui_session = #gui_stamp ec.temp at @s run data modify entity @e[type=text_display,tag=Adv.SPT5,distance=..5,limit=1,sort=nearest] text set value {text:"Hero  [Locked]",color:"dark_gray"}
execute if score #sp_check adv.temp matches 1 unless score @s ec.special_title matches 6 as @e[type=marker,tag=Adv.MenuAnchor,distance=..5] if score @s adv.gui_session = #gui_stamp ec.temp at @s run data modify entity @e[type=text_display,tag=Adv.SPT5,distance=..5,limit=1,sort=nearest] text set value {text:"Hero",color:"gold"}
execute if score @s ec.special_title matches 6 as @e[type=marker,tag=Adv.MenuAnchor,distance=..5] if score @s adv.gui_session = #gui_stamp ec.temp at @s run data modify entity @e[type=text_display,tag=Adv.SPT5,distance=..5,limit=1,sort=nearest] text set value [{text:"Hero  ",color:"green"},{text:"[ACTIVE]",color:"green",bold:true}]

# SPT6: Legend (bit 6, pow=64, ec.special_title=7)
scoreboard players set #sp_check adv.temp 0
scoreboard players operation #sp_check adv.temp = @s ec.special_titles
scoreboard players set #sp_pow adv.temp 64
scoreboard players operation #sp_check adv.temp /= #sp_pow adv.temp
scoreboard players operation #sp_check adv.temp %= #2 adv.temp
execute if score #sp_check adv.temp matches 0 as @e[type=marker,tag=Adv.MenuAnchor,distance=..5] if score @s adv.gui_session = #gui_stamp ec.temp at @s run data modify entity @e[type=text_display,tag=Adv.SPT6,distance=..5,limit=1,sort=nearest] text set value {text:"Legend  [Locked]",color:"dark_gray"}
execute if score #sp_check adv.temp matches 1 unless score @s ec.special_title matches 7 as @e[type=marker,tag=Adv.MenuAnchor,distance=..5] if score @s adv.gui_session = #gui_stamp ec.temp at @s run data modify entity @e[type=text_display,tag=Adv.SPT6,distance=..5,limit=1,sort=nearest] text set value {text:"Legend",color:"gold",bold:true}
execute if score @s ec.special_title matches 7 as @e[type=marker,tag=Adv.MenuAnchor,distance=..5] if score @s adv.gui_session = #gui_stamp ec.temp at @s run data modify entity @e[type=text_display,tag=Adv.SPT6,distance=..5,limit=1,sort=nearest] text set value [{text:"Legend  ",color:"green"},{text:"[ACTIVE]",color:"green",bold:true}]

# ============================================================
# Guild Diplomacy Titles (earned through guild wars)
# Three states like the boss-title rows: [Locked] (threshold unmet) /
# Available (earned, not equipped — name in themed color, no suffix) /
# [ACTIVE] (ec.gd_title == this ID). Earned thresholds mirror
# guild/diplomacy/titles/check_win + check_loss (gd_wins/gd_losses 1/5/15/30).
# ============================================================

# SPT7: Novice Victor (ec.gd_title = 1, ec.gd_wins >= 1)
execute unless score @s ec.gd_wins matches 1.. as @e[type=marker,tag=Adv.MenuAnchor,distance=..5] if score @s adv.gui_session = #gui_stamp ec.temp at @s run data modify entity @e[type=text_display,tag=Adv.SPT7,distance=..5,limit=1,sort=nearest] text set value {text:"Novice Victor  [Locked]",color:"dark_gray"}
execute if score @s ec.gd_wins matches 1.. unless score @s ec.gd_title matches 1 as @e[type=marker,tag=Adv.MenuAnchor,distance=..5] if score @s adv.gui_session = #gui_stamp ec.temp at @s run data modify entity @e[type=text_display,tag=Adv.SPT7,distance=..5,limit=1,sort=nearest] text set value {text:"Novice Victor",color:"white"}
execute if score @s ec.gd_title matches 1 as @e[type=marker,tag=Adv.MenuAnchor,distance=..5] if score @s adv.gui_session = #gui_stamp ec.temp at @s run data modify entity @e[type=text_display,tag=Adv.SPT7,distance=..5,limit=1,sort=nearest] text set value [{text:"Novice Victor  ",color:"green"},{text:"[ACTIVE]",color:"green",bold:true}]

# SPT8: Proven Victor (ec.gd_title = 2, ec.gd_wins >= 5)
execute unless score @s ec.gd_wins matches 5.. as @e[type=marker,tag=Adv.MenuAnchor,distance=..5] if score @s adv.gui_session = #gui_stamp ec.temp at @s run data modify entity @e[type=text_display,tag=Adv.SPT8,distance=..5,limit=1,sort=nearest] text set value {text:"Proven Victor  [Locked]",color:"dark_gray"}
execute if score @s ec.gd_wins matches 5.. unless score @s ec.gd_title matches 2 as @e[type=marker,tag=Adv.MenuAnchor,distance=..5] if score @s adv.gui_session = #gui_stamp ec.temp at @s run data modify entity @e[type=text_display,tag=Adv.SPT8,distance=..5,limit=1,sort=nearest] text set value {text:"Proven Victor",color:"yellow"}
execute if score @s ec.gd_title matches 2 as @e[type=marker,tag=Adv.MenuAnchor,distance=..5] if score @s adv.gui_session = #gui_stamp ec.temp at @s run data modify entity @e[type=text_display,tag=Adv.SPT8,distance=..5,limit=1,sort=nearest] text set value [{text:"Proven Victor  ",color:"green"},{text:"[ACTIVE]",color:"green",bold:true}]

# SPT9: Veteran Victor (ec.gd_title = 3, ec.gd_wins >= 15)
execute unless score @s ec.gd_wins matches 15.. as @e[type=marker,tag=Adv.MenuAnchor,distance=..5] if score @s adv.gui_session = #gui_stamp ec.temp at @s run data modify entity @e[type=text_display,tag=Adv.SPT9,distance=..5,limit=1,sort=nearest] text set value {text:"Veteran Victor  [Locked]",color:"dark_gray"}
execute if score @s ec.gd_wins matches 15.. unless score @s ec.gd_title matches 3 as @e[type=marker,tag=Adv.MenuAnchor,distance=..5] if score @s adv.gui_session = #gui_stamp ec.temp at @s run data modify entity @e[type=text_display,tag=Adv.SPT9,distance=..5,limit=1,sort=nearest] text set value {text:"Veteran Victor",color:"gold"}
execute if score @s ec.gd_title matches 3 as @e[type=marker,tag=Adv.MenuAnchor,distance=..5] if score @s adv.gui_session = #gui_stamp ec.temp at @s run data modify entity @e[type=text_display,tag=Adv.SPT9,distance=..5,limit=1,sort=nearest] text set value [{text:"Veteran Victor  ",color:"green"},{text:"[ACTIVE]",color:"green",bold:true}]

# SPT10: Legendary Victor (ec.gd_title = 4, ec.gd_wins >= 30)
execute unless score @s ec.gd_wins matches 30.. as @e[type=marker,tag=Adv.MenuAnchor,distance=..5] if score @s adv.gui_session = #gui_stamp ec.temp at @s run data modify entity @e[type=text_display,tag=Adv.SPT10,distance=..5,limit=1,sort=nearest] text set value {text:"Legendary Victor  [Locked]",color:"dark_gray"}
execute if score @s ec.gd_wins matches 30.. unless score @s ec.gd_title matches 4 as @e[type=marker,tag=Adv.MenuAnchor,distance=..5] if score @s adv.gui_session = #gui_stamp ec.temp at @s run data modify entity @e[type=text_display,tag=Adv.SPT10,distance=..5,limit=1,sort=nearest] text set value {text:"Legendary Victor",color:"gold",bold:true}
execute if score @s ec.gd_title matches 4 as @e[type=marker,tag=Adv.MenuAnchor,distance=..5] if score @s adv.gui_session = #gui_stamp ec.temp at @s run data modify entity @e[type=text_display,tag=Adv.SPT10,distance=..5,limit=1,sort=nearest] text set value [{text:"Legendary Victor  ",color:"green"},{text:"[ACTIVE]",color:"green",bold:true}]

# SPT11: Humbled (ec.gd_title = 5, ec.gd_losses >= 1)
execute unless score @s ec.gd_losses matches 1.. as @e[type=marker,tag=Adv.MenuAnchor,distance=..5] if score @s adv.gui_session = #gui_stamp ec.temp at @s run data modify entity @e[type=text_display,tag=Adv.SPT11,distance=..5,limit=1,sort=nearest] text set value {text:"Humbled  [Locked]",color:"dark_gray"}
execute if score @s ec.gd_losses matches 1.. unless score @s ec.gd_title matches 5 as @e[type=marker,tag=Adv.MenuAnchor,distance=..5] if score @s adv.gui_session = #gui_stamp ec.temp at @s run data modify entity @e[type=text_display,tag=Adv.SPT11,distance=..5,limit=1,sort=nearest] text set value {text:"Humbled",color:"gray"}
execute if score @s ec.gd_title matches 5 as @e[type=marker,tag=Adv.MenuAnchor,distance=..5] if score @s adv.gui_session = #gui_stamp ec.temp at @s run data modify entity @e[type=text_display,tag=Adv.SPT11,distance=..5,limit=1,sort=nearest] text set value [{text:"Humbled  ",color:"green"},{text:"[ACTIVE]",color:"green",bold:true}]

# SPT12: Battered (ec.gd_title = 6, ec.gd_losses >= 5)
execute unless score @s ec.gd_losses matches 5.. as @e[type=marker,tag=Adv.MenuAnchor,distance=..5] if score @s adv.gui_session = #gui_stamp ec.temp at @s run data modify entity @e[type=text_display,tag=Adv.SPT12,distance=..5,limit=1,sort=nearest] text set value {text:"Battered  [Locked]",color:"dark_gray"}
execute if score @s ec.gd_losses matches 5.. unless score @s ec.gd_title matches 6 as @e[type=marker,tag=Adv.MenuAnchor,distance=..5] if score @s adv.gui_session = #gui_stamp ec.temp at @s run data modify entity @e[type=text_display,tag=Adv.SPT12,distance=..5,limit=1,sort=nearest] text set value {text:"Battered",color:"gray"}
execute if score @s ec.gd_title matches 6 as @e[type=marker,tag=Adv.MenuAnchor,distance=..5] if score @s adv.gui_session = #gui_stamp ec.temp at @s run data modify entity @e[type=text_display,tag=Adv.SPT12,distance=..5,limit=1,sort=nearest] text set value [{text:"Battered  ",color:"green"},{text:"[ACTIVE]",color:"green",bold:true}]

# SPT13: Weathered (ec.gd_title = 7, ec.gd_losses >= 15)
execute unless score @s ec.gd_losses matches 15.. as @e[type=marker,tag=Adv.MenuAnchor,distance=..5] if score @s adv.gui_session = #gui_stamp ec.temp at @s run data modify entity @e[type=text_display,tag=Adv.SPT13,distance=..5,limit=1,sort=nearest] text set value {text:"Weathered  [Locked]",color:"dark_gray"}
execute if score @s ec.gd_losses matches 15.. unless score @s ec.gd_title matches 7 as @e[type=marker,tag=Adv.MenuAnchor,distance=..5] if score @s adv.gui_session = #gui_stamp ec.temp at @s run data modify entity @e[type=text_display,tag=Adv.SPT13,distance=..5,limit=1,sort=nearest] text set value {text:"Weathered",color:"gray"}
execute if score @s ec.gd_title matches 7 as @e[type=marker,tag=Adv.MenuAnchor,distance=..5] if score @s adv.gui_session = #gui_stamp ec.temp at @s run data modify entity @e[type=text_display,tag=Adv.SPT13,distance=..5,limit=1,sort=nearest] text set value [{text:"Weathered  ",color:"green"},{text:"[ACTIVE]",color:"green",bold:true}]

# SPT14: Unbroken (ec.gd_title = 8, ec.gd_losses >= 30)
execute unless score @s ec.gd_losses matches 30.. as @e[type=marker,tag=Adv.MenuAnchor,distance=..5] if score @s adv.gui_session = #gui_stamp ec.temp at @s run data modify entity @e[type=text_display,tag=Adv.SPT14,distance=..5,limit=1,sort=nearest] text set value {text:"Unbroken  [Locked]",color:"dark_gray"}
execute if score @s ec.gd_losses matches 30.. unless score @s ec.gd_title matches 8 as @e[type=marker,tag=Adv.MenuAnchor,distance=..5] if score @s adv.gui_session = #gui_stamp ec.temp at @s run data modify entity @e[type=text_display,tag=Adv.SPT14,distance=..5,limit=1,sort=nearest] text set value {text:"Unbroken",color:"gray",bold:true}
execute if score @s ec.gd_title matches 8 as @e[type=marker,tag=Adv.MenuAnchor,distance=..5] if score @s adv.gui_session = #gui_stamp ec.temp at @s run data modify entity @e[type=text_display,tag=Adv.SPT14,distance=..5,limit=1,sort=nearest] text set value [{text:"Unbroken  ",color:"green"},{text:"[ACTIVE]",color:"green",bold:true}]

# ============================================================
# Guild-Card Titles (v1.1) — bitfield ec.special_titles bits 7-12 / IDs 8-13
# Owned via guild_cards/rewards/_unlock_special_title; active via ec.special_title.
# ============================================================

# SPT15: Master Artisan (bit 7, pow=128, ec.special_title=8) — Merchant rank 4
scoreboard players set #sp_check adv.temp 0
scoreboard players operation #sp_check adv.temp = @s ec.special_titles
scoreboard players set #sp_pow adv.temp 128
scoreboard players operation #sp_check adv.temp /= #sp_pow adv.temp
scoreboard players operation #sp_check adv.temp %= #2 adv.temp
execute if score #sp_check adv.temp matches 0 as @e[type=marker,tag=Adv.MenuAnchor,distance=..5] if score @s adv.gui_session = #gui_stamp ec.temp at @s run data modify entity @e[type=text_display,tag=Adv.SPT15,distance=..5,limit=1,sort=nearest] text set value {text:"Master Artisan  [Locked]",color:"dark_gray"}
execute if score #sp_check adv.temp matches 1 unless score @s ec.special_title matches 8 as @e[type=marker,tag=Adv.MenuAnchor,distance=..5] if score @s adv.gui_session = #gui_stamp ec.temp at @s run data modify entity @e[type=text_display,tag=Adv.SPT15,distance=..5,limit=1,sort=nearest] text set value {text:"Master Artisan",color:"#DAA520"}
execute if score @s ec.special_title matches 8 as @e[type=marker,tag=Adv.MenuAnchor,distance=..5] if score @s adv.gui_session = #gui_stamp ec.temp at @s run data modify entity @e[type=text_display,tag=Adv.SPT15,distance=..5,limit=1,sort=nearest] text set value [{text:"Master Artisan  ",color:"green"},{text:"[ACTIVE]",color:"green",bold:true}]

# SPT16: Guild Artisan (bit 8, pow=256, ec.special_title=9) — Merchant rank 7
scoreboard players set #sp_check adv.temp 0
scoreboard players operation #sp_check adv.temp = @s ec.special_titles
scoreboard players set #sp_pow adv.temp 256
scoreboard players operation #sp_check adv.temp /= #sp_pow adv.temp
scoreboard players operation #sp_check adv.temp %= #2 adv.temp
execute if score #sp_check adv.temp matches 0 as @e[type=marker,tag=Adv.MenuAnchor,distance=..5] if score @s adv.gui_session = #gui_stamp ec.temp at @s run data modify entity @e[type=text_display,tag=Adv.SPT16,distance=..5,limit=1,sort=nearest] text set value {text:"Guild Artisan  [Locked]",color:"dark_gray"}
execute if score #sp_check adv.temp matches 1 unless score @s ec.special_title matches 9 as @e[type=marker,tag=Adv.MenuAnchor,distance=..5] if score @s adv.gui_session = #gui_stamp ec.temp at @s run data modify entity @e[type=text_display,tag=Adv.SPT16,distance=..5,limit=1,sort=nearest] text set value {text:"Guild Artisan",color:"gold"}
execute if score @s ec.special_title matches 9 as @e[type=marker,tag=Adv.MenuAnchor,distance=..5] if score @s adv.gui_session = #gui_stamp ec.temp at @s run data modify entity @e[type=text_display,tag=Adv.SPT16,distance=..5,limit=1,sort=nearest] text set value [{text:"Guild Artisan  ",color:"green"},{text:"[ACTIVE]",color:"green",bold:true}]

# SPT17: Grandmaster Merchant (bit 9, pow=512, ec.special_title=10) — Merchant rank 10
scoreboard players set #sp_check adv.temp 0
scoreboard players operation #sp_check adv.temp = @s ec.special_titles
scoreboard players set #sp_pow adv.temp 512
scoreboard players operation #sp_check adv.temp /= #sp_pow adv.temp
scoreboard players operation #sp_check adv.temp %= #2 adv.temp
execute if score #sp_check adv.temp matches 0 as @e[type=marker,tag=Adv.MenuAnchor,distance=..5] if score @s adv.gui_session = #gui_stamp ec.temp at @s run data modify entity @e[type=text_display,tag=Adv.SPT17,distance=..5,limit=1,sort=nearest] text set value {text:"Grandmaster Merchant  [Locked]",color:"dark_gray"}
execute if score #sp_check adv.temp matches 1 unless score @s ec.special_title matches 10 as @e[type=marker,tag=Adv.MenuAnchor,distance=..5] if score @s adv.gui_session = #gui_stamp ec.temp at @s run data modify entity @e[type=text_display,tag=Adv.SPT17,distance=..5,limit=1,sort=nearest] text set value {text:"Grandmaster Merchant",color:"gold",bold:true}
execute if score @s ec.special_title matches 10 as @e[type=marker,tag=Adv.MenuAnchor,distance=..5] if score @s adv.gui_session = #gui_stamp ec.temp at @s run data modify entity @e[type=text_display,tag=Adv.SPT17,distance=..5,limit=1,sort=nearest] text set value [{text:"Grandmaster Merchant  ",color:"green"},{text:"[ACTIVE]",color:"green",bold:true}]

# SPT18: Frontier Veteran (bit 10, pow=1024, ec.special_title=11) — Adventurer rank 4
scoreboard players set #sp_check adv.temp 0
scoreboard players operation #sp_check adv.temp = @s ec.special_titles
scoreboard players set #sp_pow adv.temp 1024
scoreboard players operation #sp_check adv.temp /= #sp_pow adv.temp
scoreboard players operation #sp_check adv.temp %= #2 adv.temp
execute if score #sp_check adv.temp matches 0 as @e[type=marker,tag=Adv.MenuAnchor,distance=..5] if score @s adv.gui_session = #gui_stamp ec.temp at @s run data modify entity @e[type=text_display,tag=Adv.SPT18,distance=..5,limit=1,sort=nearest] text set value {text:"Frontier Veteran  [Locked]",color:"dark_gray"}
execute if score #sp_check adv.temp matches 1 unless score @s ec.special_title matches 11 as @e[type=marker,tag=Adv.MenuAnchor,distance=..5] if score @s adv.gui_session = #gui_stamp ec.temp at @s run data modify entity @e[type=text_display,tag=Adv.SPT18,distance=..5,limit=1,sort=nearest] text set value {text:"Frontier Veteran",color:"light_purple"}
execute if score @s ec.special_title matches 11 as @e[type=marker,tag=Adv.MenuAnchor,distance=..5] if score @s adv.gui_session = #gui_stamp ec.temp at @s run data modify entity @e[type=text_display,tag=Adv.SPT18,distance=..5,limit=1,sort=nearest] text set value [{text:"Frontier Veteran  ",color:"green"},{text:"[ACTIVE]",color:"green",bold:true}]

# SPT19: Guild Vanguard (bit 11, pow=2048, ec.special_title=12) — Adventurer rank 7
scoreboard players set #sp_check adv.temp 0
scoreboard players operation #sp_check adv.temp = @s ec.special_titles
scoreboard players set #sp_pow adv.temp 2048
scoreboard players operation #sp_check adv.temp /= #sp_pow adv.temp
scoreboard players operation #sp_check adv.temp %= #2 adv.temp
execute if score #sp_check adv.temp matches 0 as @e[type=marker,tag=Adv.MenuAnchor,distance=..5] if score @s adv.gui_session = #gui_stamp ec.temp at @s run data modify entity @e[type=text_display,tag=Adv.SPT19,distance=..5,limit=1,sort=nearest] text set value {text:"Guild Vanguard  [Locked]",color:"dark_gray"}
execute if score #sp_check adv.temp matches 1 unless score @s ec.special_title matches 12 as @e[type=marker,tag=Adv.MenuAnchor,distance=..5] if score @s adv.gui_session = #gui_stamp ec.temp at @s run data modify entity @e[type=text_display,tag=Adv.SPT19,distance=..5,limit=1,sort=nearest] text set value {text:"Guild Vanguard",color:"dark_purple"}
execute if score @s ec.special_title matches 12 as @e[type=marker,tag=Adv.MenuAnchor,distance=..5] if score @s adv.gui_session = #gui_stamp ec.temp at @s run data modify entity @e[type=text_display,tag=Adv.SPT19,distance=..5,limit=1,sort=nearest] text set value [{text:"Guild Vanguard  ",color:"green"},{text:"[ACTIVE]",color:"green",bold:true}]

# SPT20: Guild Legend (bit 12, pow=4096, ec.special_title=13) — Adventurer rank 10
scoreboard players set #sp_check adv.temp 0
scoreboard players operation #sp_check adv.temp = @s ec.special_titles
scoreboard players set #sp_pow adv.temp 4096
scoreboard players operation #sp_check adv.temp /= #sp_pow adv.temp
scoreboard players operation #sp_check adv.temp %= #2 adv.temp
execute if score #sp_check adv.temp matches 0 as @e[type=marker,tag=Adv.MenuAnchor,distance=..5] if score @s adv.gui_session = #gui_stamp ec.temp at @s run data modify entity @e[type=text_display,tag=Adv.SPT20,distance=..5,limit=1,sort=nearest] text set value {text:"Guild Legend  [Locked]",color:"dark_gray"}
execute if score #sp_check adv.temp matches 1 unless score @s ec.special_title matches 13 as @e[type=marker,tag=Adv.MenuAnchor,distance=..5] if score @s adv.gui_session = #gui_stamp ec.temp at @s run data modify entity @e[type=text_display,tag=Adv.SPT20,distance=..5,limit=1,sort=nearest] text set value {text:"Guild Legend",color:"gold",bold:true}
execute if score @s ec.special_title matches 13 as @e[type=marker,tag=Adv.MenuAnchor,distance=..5] if score @s adv.gui_session = #gui_stamp ec.temp at @s run data modify entity @e[type=text_display,tag=Adv.SPT20,distance=..5,limit=1,sort=nearest] text set value [{text:"Guild Legend  ",color:"green"},{text:"[ACTIVE]",color:"green",bold:true}]

# ============================================================
# Handcrafter (Builder) Titles (W3, R4) — bits 13-15 / IDs 14-16
# Owned via guild_cards/rewards/_unlock_special_title; active via ec.special_title.
#   SPT21 = ID 14 Mastercrafter      (bit 13, pow 8192,  rank X)
#   SPT22 = ID 15 Grand Handcrafter  (bit 14, pow 16384, ranks D..SSS)
#   SPT23 = ID 16 Hand of the Maker  (bit 15, pow 32768, rank V — hidden capstone)
# ============================================================

# SPT21: Mastercrafter (bit 13, pow=8192, ec.special_title=14)
scoreboard players set #sp_check adv.temp 0
scoreboard players operation #sp_check adv.temp = @s ec.special_titles
scoreboard players set #sp_pow adv.temp 8192
scoreboard players operation #sp_check adv.temp /= #sp_pow adv.temp
scoreboard players operation #sp_check adv.temp %= #2 adv.temp
execute if score #sp_check adv.temp matches 0 as @e[type=marker,tag=Adv.MenuAnchor,distance=..5] if score @s adv.gui_session = #gui_stamp ec.temp at @s run data modify entity @e[type=text_display,tag=Adv.SPT21,distance=..5,limit=1,sort=nearest] text set value {text:"Mastercrafter  [Locked]",color:"dark_gray"}
execute if score #sp_check adv.temp matches 1 unless score @s ec.special_title matches 14 as @e[type=marker,tag=Adv.MenuAnchor,distance=..5] if score @s adv.gui_session = #gui_stamp ec.temp at @s run data modify entity @e[type=text_display,tag=Adv.SPT21,distance=..5,limit=1,sort=nearest] text set value {text:"Mastercrafter",color:"gold",bold:true}
execute if score @s ec.special_title matches 14 as @e[type=marker,tag=Adv.MenuAnchor,distance=..5] if score @s adv.gui_session = #gui_stamp ec.temp at @s run data modify entity @e[type=text_display,tag=Adv.SPT21,distance=..5,limit=1,sort=nearest] text set value [{text:"Mastercrafter  ",color:"green"},{text:"[ACTIVE]",color:"green",bold:true}]

# SPT22: Grand Handcrafter (bit 14, pow=16384, ec.special_title=15)
scoreboard players set #sp_check adv.temp 0
scoreboard players operation #sp_check adv.temp = @s ec.special_titles
scoreboard players set #sp_pow adv.temp 16384
scoreboard players operation #sp_check adv.temp /= #sp_pow adv.temp
scoreboard players operation #sp_check adv.temp %= #2 adv.temp
execute if score #sp_check adv.temp matches 0 as @e[type=marker,tag=Adv.MenuAnchor,distance=..5] if score @s adv.gui_session = #gui_stamp ec.temp at @s run data modify entity @e[type=text_display,tag=Adv.SPT22,distance=..5,limit=1,sort=nearest] text set value {text:"Grand Handcrafter  [Locked]",color:"dark_gray"}
execute if score #sp_check adv.temp matches 1 unless score @s ec.special_title matches 15 as @e[type=marker,tag=Adv.MenuAnchor,distance=..5] if score @s adv.gui_session = #gui_stamp ec.temp at @s run data modify entity @e[type=text_display,tag=Adv.SPT22,distance=..5,limit=1,sort=nearest] text set value {text:"Grand Handcrafter",color:"#C49A6C"}
execute if score @s ec.special_title matches 15 as @e[type=marker,tag=Adv.MenuAnchor,distance=..5] if score @s adv.gui_session = #gui_stamp ec.temp at @s run data modify entity @e[type=text_display,tag=Adv.SPT22,distance=..5,limit=1,sort=nearest] text set value [{text:"Grand Handcrafter  ",color:"green"},{text:"[ACTIVE]",color:"green",bold:true}]

# SPT23: Hand of the Maker (bit 15, pow=32768, ec.special_title=16)
scoreboard players set #sp_check adv.temp 0
scoreboard players operation #sp_check adv.temp = @s ec.special_titles
scoreboard players set #sp_pow adv.temp 32768
scoreboard players operation #sp_check adv.temp /= #sp_pow adv.temp
scoreboard players operation #sp_check adv.temp %= #2 adv.temp
execute if score #sp_check adv.temp matches 0 as @e[type=marker,tag=Adv.MenuAnchor,distance=..5] if score @s adv.gui_session = #gui_stamp ec.temp at @s run data modify entity @e[type=text_display,tag=Adv.SPT23,distance=..5,limit=1,sort=nearest] text set value {text:"Hand of the Maker  [Locked]",color:"dark_gray"}
execute if score #sp_check adv.temp matches 1 unless score @s ec.special_title matches 16 as @e[type=marker,tag=Adv.MenuAnchor,distance=..5] if score @s adv.gui_session = #gui_stamp ec.temp at @s run data modify entity @e[type=text_display,tag=Adv.SPT23,distance=..5,limit=1,sort=nearest] text set value {text:"Hand of the Maker",color:"#FFD27F",bold:true}
execute if score @s ec.special_title matches 16 as @e[type=marker,tag=Adv.MenuAnchor,distance=..5] if score @s adv.gui_session = #gui_stamp ec.temp at @s run data modify entity @e[type=text_display,tag=Adv.SPT23,distance=..5,limit=1,sort=nearest] text set value [{text:"Hand of the Maker  ",color:"green"},{text:"[ACTIVE]",color:"green",bold:true}]

# ============================================================
# Tinkering Title (C8) — bit 16 / ID 17 — Master Tinkerer
# Owned via guild_cards/rewards/_unlock_special_title {tid:17} (OR-set by tinkering/finish);
# active via ec.special_title.
#   SPT24 = ID 17 Master Tinkerer (bit 16, pow 65536, Tinkering line capstone)
# ============================================================

# SPT24: Master Tinkerer (bit 16, pow=65536, ec.special_title=17)
scoreboard players set #sp_check adv.temp 0
scoreboard players operation #sp_check adv.temp = @s ec.special_titles
scoreboard players set #sp_pow adv.temp 65536
scoreboard players operation #sp_check adv.temp /= #sp_pow adv.temp
scoreboard players operation #sp_check adv.temp %= #2 adv.temp
execute if score #sp_check adv.temp matches 0 as @e[type=marker,tag=Adv.MenuAnchor,distance=..5] if score @s adv.gui_session = #gui_stamp ec.temp at @s run data modify entity @e[type=text_display,tag=Adv.SPT24,distance=..5,limit=1,sort=nearest] text set value {text:"Master Tinkerer  [Locked]",color:"dark_gray"}
execute if score #sp_check adv.temp matches 1 unless score @s ec.special_title matches 17 as @e[type=marker,tag=Adv.MenuAnchor,distance=..5] if score @s adv.gui_session = #gui_stamp ec.temp at @s run data modify entity @e[type=text_display,tag=Adv.SPT24,distance=..5,limit=1,sort=nearest] text set value {text:"Master Tinkerer",color:"#C792EA",bold:true}
execute if score @s ec.special_title matches 17 as @e[type=marker,tag=Adv.MenuAnchor,distance=..5] if score @s adv.gui_session = #gui_stamp ec.temp at @s run data modify entity @e[type=text_display,tag=Adv.SPT24,distance=..5,limit=1,sort=nearest] text set value [{text:"Master Tinkerer  ",color:"green"},{text:"[ACTIVE]",color:"green",bold:true}]

# ============================================================
# Wayfarer Title — bit 17 / ID 18 — Wayfarer (Wayfarer's Pass capstone)
# Owned via guild_cards/rewards/_unlock_special_title {tid:18} (granted by the Pass);
# active via ec.special_title.
#   SPT25 = ID 18 Wayfarer (bit 17, pow 131072)
# ============================================================

# SPT25: Wayfarer (bit 17, pow=131072, ec.special_title=18)
scoreboard players set #sp_check adv.temp 0
scoreboard players operation #sp_check adv.temp = @s ec.special_titles
scoreboard players set #sp_pow adv.temp 131072
scoreboard players operation #sp_check adv.temp /= #sp_pow adv.temp
scoreboard players operation #sp_check adv.temp %= #2 adv.temp
execute if score #sp_check adv.temp matches 0 as @e[type=marker,tag=Adv.MenuAnchor,distance=..5] if score @s adv.gui_session = #gui_stamp ec.temp at @s run data modify entity @e[type=text_display,tag=Adv.SPT25,distance=..5,limit=1,sort=nearest] text set value {text:"Wayfarer  [Locked]",color:"dark_gray"}
execute if score #sp_check adv.temp matches 1 unless score @s ec.special_title matches 18 as @e[type=marker,tag=Adv.MenuAnchor,distance=..5] if score @s adv.gui_session = #gui_stamp ec.temp at @s run data modify entity @e[type=text_display,tag=Adv.SPT25,distance=..5,limit=1,sort=nearest] text set value {text:"Wayfarer",color:"aqua",bold:true}
execute if score @s ec.special_title matches 18 as @e[type=marker,tag=Adv.MenuAnchor,distance=..5] if score @s adv.gui_session = #gui_stamp ec.temp at @s run data modify entity @e[type=text_display,tag=Adv.SPT25,distance=..5,limit=1,sort=nearest] text set value [{text:"Wayfarer  ",color:"green"},{text:"[ACTIVE]",color:"green",bold:true}]
