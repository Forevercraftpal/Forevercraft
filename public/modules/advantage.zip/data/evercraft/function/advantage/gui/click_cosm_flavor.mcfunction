# Cosmetic Title/particle Flavor picker (Wiring Audit #31 — Joseph: in-menu picker).
# Run as the player (via `on target` from check_clicks). Macro $(op) = "add" (next) / "remove" (prev).
# Cycles adv.cosm_tree across the 15 tree flavors and wraps 1..15. The flavor drives the Title Tag
# prefix/color AND the Particle Aura / Effect Trail / Crown Particles variant.

# Default an unset tree to 1 so the first click lands predictably
execute unless score @s adv.cosm_tree matches 1.. run scoreboard players set @s adv.cosm_tree 1
$scoreboard players $(op) @s adv.cosm_tree 1
execute if score @s adv.cosm_tree matches 16.. run scoreboard players set @s adv.cosm_tree 1
execute if score @s adv.cosm_tree matches ..0 run scoreboard players set @s adv.cosm_tree 15

# If a team-based tier is active (Title Tag / Glow Outline), re-join the new flavor's team so the
# name color follows immediately. The floating title updates on its next fast_tick (change-detected).
execute if score @s adv.cosm_active matches 2 run function evercraft:advantage/cosmetics/title_tag
execute if score @s adv.cosm_active matches 4 run function evercraft:advantage/cosmetics/title_tag

# Update the picker label + feedback
function evercraft:advantage/gui/refresh_cosm_flavor
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.hat master @s ~ ~ ~ 0.5 1.8
