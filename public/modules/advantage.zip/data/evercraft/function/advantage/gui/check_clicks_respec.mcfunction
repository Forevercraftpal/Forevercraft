# Respec mode click detection — 15 tree respec clicks + cancel
# Run as the player in respec mode
# OPT: Added session filter for multiplayer safety

# Tree respec clicks (0-12 → tree_id 1-13)
execute as @e[type=interaction,tag=Adv.RespecClick0,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction on target run function evercraft:advantage/gui/do_respec_tree {tree_id:1}
execute as @e[type=interaction,tag=Adv.RespecClick0,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=Adv.RespecClick1,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction on target run function evercraft:advantage/gui/do_respec_tree {tree_id:2}
execute as @e[type=interaction,tag=Adv.RespecClick1,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=Adv.RespecClick2,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction on target run function evercraft:advantage/gui/do_respec_tree {tree_id:3}
execute as @e[type=interaction,tag=Adv.RespecClick2,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=Adv.RespecClick3,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction on target run function evercraft:advantage/gui/do_respec_tree {tree_id:4}
execute as @e[type=interaction,tag=Adv.RespecClick3,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=Adv.RespecClick4,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction on target run function evercraft:advantage/gui/do_respec_tree {tree_id:5}
execute as @e[type=interaction,tag=Adv.RespecClick4,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=Adv.RespecClick5,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction on target run function evercraft:advantage/gui/do_respec_tree {tree_id:6}
execute as @e[type=interaction,tag=Adv.RespecClick5,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=Adv.RespecClick6,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction on target run function evercraft:advantage/gui/do_respec_tree {tree_id:7}
execute as @e[type=interaction,tag=Adv.RespecClick6,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=Adv.RespecClick7,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction on target run function evercraft:advantage/gui/do_respec_tree {tree_id:8}
execute as @e[type=interaction,tag=Adv.RespecClick7,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=Adv.RespecClick8,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction on target run function evercraft:advantage/gui/do_respec_tree {tree_id:9}
execute as @e[type=interaction,tag=Adv.RespecClick8,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=Adv.RespecClick9,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction on target run function evercraft:advantage/gui/do_respec_tree {tree_id:10}
execute as @e[type=interaction,tag=Adv.RespecClick9,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=Adv.RespecClick10,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction on target run function evercraft:advantage/gui/do_respec_tree {tree_id:11}
execute as @e[type=interaction,tag=Adv.RespecClick10,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=Adv.RespecClick11,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction on target run function evercraft:advantage/gui/do_respec_tree {tree_id:12}
execute as @e[type=interaction,tag=Adv.RespecClick11,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=Adv.RespecClick12,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction on target run function evercraft:advantage/gui/do_respec_tree {tree_id:13}
execute as @e[type=interaction,tag=Adv.RespecClick12,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=Adv.RespecClick13,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction on target run function evercraft:advantage/gui/do_respec_tree {tree_id:14}
execute as @e[type=interaction,tag=Adv.RespecClick13,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=Adv.RespecClick14,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction on target run function evercraft:advantage/gui/do_respec_tree {tree_id:15}
execute as @e[type=interaction,tag=Adv.RespecClick14,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction

# Cancel button
execute as @e[type=interaction,tag=Adv.RespecCancelClick,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction on target run function evercraft:advantage/gui/exit_respec
execute as @e[type=interaction,tag=Adv.RespecCancelClick,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction

# ===== INSPECT (left-click = what does this button do?) — gui/inspect pattern 2026-06-11 =====
execute as @e[type=interaction,tag=Adv.RespecClick0,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Respec Agility",b:"Right-click to refund all points spent in the Agility tree — respec has a cooldown."}
execute as @e[type=interaction,tag=Adv.RespecClick0,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=Adv.RespecClick1,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Respec Dexterity",b:"Right-click to refund all points spent in the Dexterity tree — respec has a cooldown."}
execute as @e[type=interaction,tag=Adv.RespecClick1,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=Adv.RespecClick2,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Respec Evasion",b:"Right-click to refund all points spent in the Evasion tree — respec has a cooldown."}
execute as @e[type=interaction,tag=Adv.RespecClick2,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=Adv.RespecClick3,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Respec Stealth",b:"Right-click to refund all points spent in the Stealth tree — respec has a cooldown."}
execute as @e[type=interaction,tag=Adv.RespecClick3,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=Adv.RespecClick4,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Respec Vitality",b:"Right-click to refund all points spent in the Vitality tree — respec has a cooldown."}
execute as @e[type=interaction,tag=Adv.RespecClick4,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=Adv.RespecClick5,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Respec Taskmaster",b:"Right-click to refund all points spent in the Taskmaster tree — respec has a cooldown."}
execute as @e[type=interaction,tag=Adv.RespecClick5,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=Adv.RespecClick6,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Respec Beastmaster",b:"Right-click to refund all points spent in the Beastmaster tree — respec has a cooldown."}
execute as @e[type=interaction,tag=Adv.RespecClick6,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=Adv.RespecClick7,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Respec Victorian",b:"Right-click to refund all points spent in the Victorian tree — respec has a cooldown."}
execute as @e[type=interaction,tag=Adv.RespecClick7,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=Adv.RespecClick8,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Respec Fishing",b:"Right-click to refund all points spent in the Fishing tree — respec has a cooldown."}
execute as @e[type=interaction,tag=Adv.RespecClick8,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=Adv.RespecClick9,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Respec Mining",b:"Right-click to refund all points spent in the Mining tree — respec has a cooldown."}
execute as @e[type=interaction,tag=Adv.RespecClick9,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=Adv.RespecClick10,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Respec Gathering",b:"Right-click to refund all points spent in the Gathering tree — respec has a cooldown."}
execute as @e[type=interaction,tag=Adv.RespecClick10,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=Adv.RespecClick11,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Respec Blacksmith",b:"Right-click to refund all points spent in the Blacksmith tree — respec has a cooldown."}
execute as @e[type=interaction,tag=Adv.RespecClick11,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=Adv.RespecClick12,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Respec Explorer",b:"Right-click to refund all points spent in the Explorer tree — respec has a cooldown."}
execute as @e[type=interaction,tag=Adv.RespecClick12,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=Adv.RespecClick13,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Respec Culinary",b:"Right-click to refund all points spent in the Culinary tree — respec has a cooldown."}
execute as @e[type=interaction,tag=Adv.RespecClick13,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=Adv.RespecClick14,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Respec Chemistry",b:"Right-click to refund all points spent in the Chemistry tree — respec has a cooldown."}
execute as @e[type=interaction,tag=Adv.RespecClick14,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=Adv.RespecCancelClick,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Cancel",b:"Leaves respec mode without changing anything."}
execute as @e[type=interaction,tag=Adv.RespecCancelClick,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack run data remove entity @s attack
