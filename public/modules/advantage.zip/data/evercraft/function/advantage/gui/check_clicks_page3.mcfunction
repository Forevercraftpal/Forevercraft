# Page 3 click detection — Prestige info [?] button
# Run as the player with menu open

# Single [?] button — opens chat class selector for prestige ability details
execute as @e[type=interaction,tag=Adv.PrestigeInfoClick,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction on target run function evercraft:advantage/gui/show_prestige_selector
execute as @e[type=interaction,tag=Adv.PrestigeInfoClick,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction

# ===== INSPECT (left-click = what does this button do?) — gui/inspect pattern 2026-06-11 =====
execute as @e[type=interaction,tag=Adv.PrestigeInfoClick,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Prestige Guide",b:"Opens the prestige ability guide — pick a class in chat to read its details."}
execute as @e[type=interaction,tag=Adv.PrestigeInfoClick,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack run data remove entity @s attack
