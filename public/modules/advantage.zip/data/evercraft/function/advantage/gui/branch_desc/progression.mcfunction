# Progression Branch — all 5 trees (Taskmaster, Beastmaster, Victorian, Culinary, Chemistry)
tellraw @s {text:""}
tellraw @s [{text:"  📜 ",color:"dark_purple"},{text:"Progression Branch",color:"dark_purple",bold:true}]
tellraw @s {text:"  ─────────────────────",color:"dark_gray"}

# Taskmaster: +4% quest XP & rep/level
scoreboard players operation @s adv.temp = @s adv.taskmaster
scoreboard players operation @s adv.temp *= #4 adv.temp
tellraw @s [{text:"  Taskmaster ",color:"dark_purple",bold:true},{text:"— +4% quest XP & rep/level",color:"white"}]
tellraw @s [{text:"    Lv.",color:"gray"},{score:{name:"@s",objective:"adv.taskmaster"},color:"dark_purple"},{text:" → +",color:"gray"},{score:{name:"@s",objective:"adv.temp"},color:"dark_purple"},{text:"% quest rewards",color:"gray"}]
tellraw @s [{text:"    Quests completed: ",color:"gray"},{score:{name:"@s",objective:"adv.stat_quests"},color:"dark_purple"},{text:"  (100→2.5k)",color:"dark_gray"}]
execute if score @s adv.lb_tree matches 6 run tellraw @s [{text:"    Live XP bar: ",color:"gray"},{text:"[ ON ]",color:"green",bold:true,click_event:{action:run_command,command:"/trigger adv.lb_track set 6"},hover_event:{action:show_text,value:{text:"Click to stop the live bar",color:"gray"}}}]
execute unless score @s adv.lb_tree matches 6 run tellraw @s [{text:"    Live XP bar: ",color:"gray"},{text:"[ OFF ]",color:"red",bold:true,click_event:{action:run_command,command:"/trigger adv.lb_track set 6"},hover_event:{action:show_text,value:{text:"Click to show a live bar while you gain Taskmaster XP",color:"gray"}}}]

# Beastmaster: wolf damage scaling (non-percentage)
tellraw @s [{text:"  Beastmaster ",color:"green",bold:true},{text:"— Wolves deal more damage",color:"white"}]
tellraw @s [{text:"    Lv.",color:"gray"},{score:{name:"@s",objective:"adv.beastmaster"},color:"green"},{text:" — wolves grow stronger each level",color:"gray"}]
tellraw @s [{text:"    Pets at max level: ",color:"gray"},{score:{name:"@s",objective:"adv.stat_pets100"},color:"green"},{text:"  (1→25)",color:"dark_gray"}]
# Partial virtual-pet bar from hunts (dungeon/raid/lore credit): bm_credit % 20 toward the next virtual
# pet. stat_pets100 above stays the PURE maxed-pet count (Council #6, 2026-06-02).
scoreboard players operation #bm_rem adv.temp = @s adv.bm_credit
scoreboard players operation #bm_rem adv.temp %= #20 adv.temp
execute if score @s adv.bm_credit matches 1.. run tellraw @s [{text:"      + ",color:"dark_gray"},{score:{name:"#bm_rem",objective:"adv.temp"},color:"green"},{text:"/20 from hunts (toward a kindred spirit)",color:"dark_gray"}]
execute if score @s adv.lb_tree matches 7 run tellraw @s [{text:"    Live XP bar: ",color:"gray"},{text:"[ ON ]",color:"green",bold:true,click_event:{action:run_command,command:"/trigger adv.lb_track set 7"},hover_event:{action:show_text,value:{text:"Click to stop the live bar",color:"gray"}}}]
execute unless score @s adv.lb_tree matches 7 run tellraw @s [{text:"    Live XP bar: ",color:"gray"},{text:"[ OFF ]",color:"red",bold:true,click_event:{action:run_command,command:"/trigger adv.lb_track set 7"},hover_event:{action:show_text,value:{text:"Click to show a live bar while Beastmaster progresses",color:"gray"}}}]

# Victorian: +4% crate/patron XP/level
scoreboard players operation @s adv.temp = @s adv.victorian
scoreboard players operation @s adv.temp *= #4 adv.temp
tellraw @s [{text:"  Victorian ",color:"dark_red",bold:true},{text:"— +4% crate/patron XP/level",color:"white"}]
tellraw @s [{text:"    Lv.",color:"gray"},{score:{name:"@s",objective:"adv.victorian"},color:"dark_red"},{text:" → +",color:"gray"},{score:{name:"@s",objective:"adv.temp"},color:"dark_red"},{text:"% XP bonus",color:"gray"}]
tellraw @s [{text:"    Mobs slain: ",color:"gray"},{score:{name:"@s",objective:"adv.stat_mobs"},color:"dark_red"},{text:"  (2k→50k)",color:"dark_gray"}]
execute if score @s adv.lb_tree matches 8 run tellraw @s [{text:"    Live XP bar: ",color:"gray"},{text:"[ ON ]",color:"green",bold:true,click_event:{action:run_command,command:"/trigger adv.lb_track set 8"},hover_event:{action:show_text,value:{text:"Click to stop the live bar",color:"gray"}}}]
execute unless score @s adv.lb_tree matches 8 run tellraw @s [{text:"    Live XP bar: ",color:"gray"},{text:"[ OFF ]",color:"red",bold:true,click_event:{action:run_command,command:"/trigger adv.lb_track set 8"},hover_event:{action:show_text,value:{text:"Click to show a live bar while you gain Victorian XP",color:"gray"}}}]

# Culinary: +10% Well-Fed duration per 5 levels
scoreboard players operation @s adv.temp = @s adv.culinary
scoreboard players operation @s adv.temp /= #5 adv.temp
scoreboard players operation @s adv.temp *= #10 adv.temp
tellraw @s [{text:"  Culinary ",color:"green",bold:true},{text:"— +10% Well-Fed duration per 5 levels",color:"white"}]
tellraw @s [{text:"    Lv.",color:"gray"},{score:{name:"@s",objective:"adv.culinary"},color:"green"},{text:" → +",color:"gray"},{score:{name:"@s",objective:"adv.temp"},color:"green"},{text:"% Well-Fed duration",color:"gray"}]
tellraw @s [{text:"    Meals cooked: ",color:"gray"},{score:{name:"@s",objective:"adv.stat_cook"},color:"green"},{text:"  (50→1.25k)",color:"dark_gray"}]
execute if score @s adv.lb_tree matches 14 run tellraw @s [{text:"    Live XP bar: ",color:"gray"},{text:"[ ON ]",color:"green",bold:true,click_event:{action:run_command,command:"/trigger adv.lb_track set 14"},hover_event:{action:show_text,value:{text:"Click to stop the live bar",color:"gray"}}}]
execute unless score @s adv.lb_tree matches 14 run tellraw @s [{text:"    Live XP bar: ",color:"gray"},{text:"[ OFF ]",color:"red",bold:true,click_event:{action:run_command,command:"/trigger adv.lb_track set 14"},hover_event:{action:show_text,value:{text:"Click to show a live bar while you gain Culinary XP",color:"gray"}}}]

# Chemistry: +10% potion duration per 5 levels
scoreboard players operation @s adv.temp = @s adv.chemistry
scoreboard players operation @s adv.temp /= #5 adv.temp
scoreboard players operation @s adv.temp *= #10 adv.temp
tellraw @s [{text:"  Chemistry ",color:"#9B59B6",bold:true},{text:"— +10% potion duration per 5 levels",color:"white"}]
tellraw @s [{text:"    Lv.",color:"gray"},{score:{name:"@s",objective:"adv.chemistry"},color:"#9B59B6"},{text:" → +",color:"gray"},{score:{name:"@s",objective:"adv.temp"},color:"#9B59B6"},{text:"% potion duration",color:"gray"}]
tellraw @s [{text:"    Potions brewed: ",color:"gray"},{score:{name:"@s",objective:"adv.stat_brew"},color:"#9B59B6"},{text:"  (50→1.25k)",color:"dark_gray"}]
execute if score @s adv.lb_tree matches 15 run tellraw @s [{text:"    Live XP bar: ",color:"gray"},{text:"[ ON ]",color:"green",bold:true,click_event:{action:run_command,command:"/trigger adv.lb_track set 15"},hover_event:{action:show_text,value:{text:"Click to stop the live bar",color:"gray"}}}]
execute unless score @s adv.lb_tree matches 15 run tellraw @s [{text:"    Live XP bar: ",color:"gray"},{text:"[ OFF ]",color:"red",bold:true,click_event:{action:run_command,command:"/trigger adv.lb_track set 15"},hover_event:{action:show_text,value:{text:"Click to show a live bar while you gain Chemistry XP",color:"gray"}}}]
tellraw @s {text:""}
