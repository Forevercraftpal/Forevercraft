# Mining Surge Expire — Remove temporary block_break_speed boost
attribute @s block_break_speed modifier remove evercraft:adv_mining_surge
data modify storage evercraft:notify stage.c set value [{text:"⛏ Miner's Surge faded...",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit

# Re-sync mine_prev so blocks mined during surge don't trigger an immediate re-proc
function evercraft:advantage/mining/sum_blocks
scoreboard players operation @s adv.mine_prev = #mine_rt adv.temp
