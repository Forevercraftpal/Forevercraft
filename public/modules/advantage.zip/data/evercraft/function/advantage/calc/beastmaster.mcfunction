# Calculate requirements for Beastmaster level-up
# XP cost: (level + 1) * 4 vanilla levels
# Stat req: (level + 1) * 1 companion at max level

# XP cost
scoreboard players operation @s adv.req_xp = @s adv.beastmaster
scoreboard players add @s adv.req_xp 1
scoreboard players operation @s adv.req_xp *= #4 adv.temp

# Stat requirement
scoreboard players operation @s adv.req_stat = @s adv.beastmaster
scoreboard players add @s adv.req_stat 1
scoreboard players operation @s adv.req_stat *= #mult_beastmaster adv.temp

# Apply difficulty fill-rate scaling (req_stat only)
function evercraft:advantage/calc/apply_difficulty

# Effective pet-stat for the level-gate / GUI / live-bar (Council #6, 2026-06-02):
#   bm_eff = stat_pets100 (raw maxed pets) + floor(adv.bm_credit / 20) (virtual pets from hunts).
# One-writer of adv.bm_eff = HERE. stat_pets100 stays pure: challenges/cosmetics/display read it raw;
# only the LEVELING path compares adv.bm_eff >= adv.req_stat.
scoreboard players operation @s adv.bm_eff = @s adv.bm_credit
scoreboard players operation @s adv.bm_eff /= #20 adv.temp
scoreboard players operation @s adv.bm_eff += @s adv.stat_pets100
