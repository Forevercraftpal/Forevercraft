# Calculate requirements for Chemistry level-up
# XP cost: (level + 1) * 4 vanilla levels
# Stat req: (level + 1) * 50 potions brewed

# XP cost
scoreboard players operation @s adv.req_xp = @s adv.chemistry
scoreboard players add @s adv.req_xp 1
scoreboard players operation @s adv.req_xp *= #4 adv.temp

# Stat requirement
scoreboard players operation @s adv.req_stat = @s adv.chemistry
scoreboard players add @s adv.req_stat 1
scoreboard players operation @s adv.req_stat *= #mult_chemistry adv.temp

# Apply difficulty fill-rate scaling (req_stat only)
function evercraft:advantage/calc/apply_difficulty
