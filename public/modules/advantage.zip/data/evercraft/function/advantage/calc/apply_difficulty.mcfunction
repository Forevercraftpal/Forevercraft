# Difficulty-scaled fill rate — appended to every advantage/calc/<tree> (Joseph 2026-05-29)
# Scales BOTH adv.req_stat (the grind/"progress accumulation") AND adv.req_xp (the vanilla-XP
# cost) so easy modes are cheap end-to-end, not just on the stat grind (Joseph 2026-06-02).
#   ec.difficulty 1 = Journey (Newcomer)    -> 10x easier  (req_stat /= 10, req_xp /= 10)
#   ec.difficulty 2 = Adventure (Adventurer) -> 5x easier   (req_stat /= 5,  req_xp /= 5)
#   ec.difficulty 3 = Pioneer (or 0/unset)   -> unchanged (today's grindy baseline)
execute if score @s ec.difficulty matches 1 run scoreboard players operation @s adv.req_stat /= #10 adv.temp
execute if score @s ec.difficulty matches 2 run scoreboard players operation @s adv.req_stat /= #5 adv.temp
# Floor at 1 so a tiny base mult (Beastmaster = 1) can never produce a 0 requirement (instant level)
execute if score @s adv.req_stat matches ..0 run scoreboard players set @s adv.req_stat 1
execute if score @s ec.difficulty matches 1 run scoreboard players operation @s adv.req_xp /= #10 adv.temp
execute if score @s ec.difficulty matches 2 run scoreboard players operation @s adv.req_xp /= #5 adv.temp
# Floor at 1 so an easy-mode divide can never produce a 0 XP cost (instant level)
execute if score @s adv.req_xp matches ..0 run scoreboard players set @s adv.req_xp 1
