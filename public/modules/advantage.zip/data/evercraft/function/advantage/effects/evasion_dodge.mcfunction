# Evasion Dodge — True pre-hit cancel via HP snapshot restore (Wave G AU33-1 2026-05-31)
# Cancels the triggering hit by restoring HP to the pre-hit snapshot. Idempotent + i-frame guarded.
function evercraft:_shared/dodge_restore_hp

# Visual feedback
particle minecraft:cloud ~ ~1 ~ 0.3 0.5 0.3 0.1 20 force
playsound minecraft:entity.player.attack.sweep master @a[scores={ec.fx_snd=1..}] ~ ~ ~ 0.5 1.5

# Actionbar message
data modify storage evercraft:notify stage.c set value [{text:"Dodged!",color:"aqua",bold:true}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit

# Achievement tracking
scoreboard players add @s ach.dodge_count 1

# Synergy hook: trigger Battle Trance if combat synergy active
function evercraft:advantage/synergies/on_dodge

# Challenge hook: increment dodge counter for Ghost (4) / Shadow Step (22)
execute if score @s adv.chal_id matches 4 run scoreboard players add @s adv.chal_prog 1
execute if score @s adv.chal_id matches 22 run scoreboard players add @s adv.chal_prog 1

# Bough Dancer Crown hook (Cloudstep, Wave 13): perfect dodge → 2 hearts +
# 1.5s flurry. Self-gates on crown ownership + active dancer; cheap no-op
# otherwise. Every active dancer rolls dodges (ec.dn_evasion_add 20/40).
execute if score @s ec.dn_b_crown matches 1.. if entity @s[tag=ec.dn_active] run function evercraft:bough/dancer/crown_dodge

# === PRESTIGE ABILITY HOOKS ===
# Evasion P1: Shadow Counter — teleport behind nearest attacker (with collision checking)
# 4 progressively-closer offsets (-0.4 / -0.8 / -1.2 / -1.6) — first valid landing spot wins.
# 2026-05-28 (side-fix): previously all 4 attempts used -0.4 offset, so 3 were no-ops.
execute if score @s adv.pres_evas matches 1.. at @s as @e[type=!player,type=!item,sort=nearest,limit=1,distance=..5] run tag @s add ec.kb
execute if score @s adv.pres_evas matches 1.. as @e[tag=ec.kb] at @s facing entity @p feet positioned ^ ^ ^-0.4 if block ~ ~ ~ #minecraft:replaceable if block ~ ~1 ~ #minecraft:replaceable run tp @s ~ ~ ~
execute if score @s adv.pres_evas matches 1.. as @e[tag=ec.kb] at @s facing entity @p feet positioned ^ ^ ^-0.8 if block ~ ~ ~ #minecraft:replaceable if block ~ ~1 ~ #minecraft:replaceable run tp @s ~ ~ ~
execute if score @s adv.pres_evas matches 1.. as @e[tag=ec.kb] at @s facing entity @p feet positioned ^ ^ ^-1.2 if block ~ ~ ~ #minecraft:replaceable if block ~ ~1 ~ #minecraft:replaceable run tp @s ~ ~ ~
execute if score @s adv.pres_evas matches 1.. as @e[tag=ec.kb] at @s facing entity @p feet positioned ^ ^ ^-1.6 if block ~ ~ ~ #minecraft:replaceable if block ~ ~1 ~ #minecraft:replaceable run tp @s ~ ~ ~
execute if score @s adv.pres_evas matches 1.. run tag @e[tag=ec.kb] remove ec.kb
execute if score @s adv.pres_evas matches 1.. if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.enderman.teleport master @s ~ ~ ~ 0.5 1.5

# Evasion P2: Vanishing Dodge — 2s invisibility on dodge
execute if score @s adv.pres_evas matches 2.. run effect give @s minecraft:invisibility 2 0 true

# Evasion P3: Perfect Evasion — 1s guaranteed dodge window
execute if score @s adv.pres_evas matches 3 run scoreboard players set @s adv.pa_evas3_tm 20
