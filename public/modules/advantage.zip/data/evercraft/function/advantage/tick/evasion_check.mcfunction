# Evasion — Check for dodge on taking damage
# Fired by advancement trigger, NOT per-tick
# 0.25% dodge chance per level (max 6.25% at level 25)

# Only process if player has evasion levels, dancer bonus, or accessory dodge points
execute unless score @s adv.evasion matches 1.. unless score @s ec.dn_evasion_add matches 1.. unless score @s ec.acc_dodge matches 1.. run return run advancement revoke @s only evercraft:advantage/evasion_trigger

# Calculate chance: (level + dancer bonus) * 25 (per 10000 roll = 0.25% per level)
scoreboard players operation #chance adv.temp = @s adv.evasion
scoreboard players operation #chance adv.temp += @s ec.dn_evasion_add
scoreboard players operation #chance adv.temp *= #25 adv.temp

# Accessory dodge lane (D-DODGE, m1): ec.acc_dodge is in display-points (1% = 4 pts). It needs the SAME
# *25 the level lane uses to reach roll-points (4 pts *25 = 100/10000 = 1%; 40 pts = 10%). Convert via a
# scratch score so the canonical @s ec.acc_dodge store (also read as a >=1 eligibility flag) is untouched.
scoreboard players operation #acc_dodge adv.temp = @s ec.acc_dodge
scoreboard players operation #acc_dodge adv.temp *= #25 adv.temp
scoreboard players operation #chance adv.temp += #acc_dodge adv.temp

# Roll 1-10000
execute store result score #roll adv.temp run random value 1..10000

# Stealth P3: Perfect Stealth — +25% dodge while sneaking (passive). Cut from +50% in Wave G AU33-1 2026-05-31:
# under true-pre-hit-cancel architecture, +50% stacked with max Evasion + 4pc Emerald hit ~56% cancel uptime — oppressive.
execute if score @s adv.pres_stea matches 3.. if predicate evercraft:advantage/is_sneaking run scoreboard players add #chance adv.temp 2500

# Evasion P3: Perfect Evasion — guaranteed dodge if timer active
execute if score @s adv.pa_evas3_tm matches 1.. run scoreboard players set #chance adv.temp 10000

# If roll <= chance, dodge
execute if score #roll adv.temp <= #chance adv.temp run function evercraft:advantage/effects/evasion_dodge

# Revoke advancement to re-trigger on next hit
advancement revoke @s only evercraft:advantage/evasion_trigger
