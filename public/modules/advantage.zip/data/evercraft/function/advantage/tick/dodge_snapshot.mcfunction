# Dodge HP Snapshot — single writer of ec.dodge_hp_snap (Wave G AU33-1 2026-05-31)
# Self-schedules at 1t replace. Runs as advantage system; existence-gated by predicate.
# Per-tick snapshot captures pre-hit HP so the reactive dodge restore (in _shared/dodge_restore_hp)
# can cancel the triggering hit. Also clears the 1-tick i-frame tag.

# Perf retrofit M5 (2026-06-14): this is a 1-tick loop — skip the whole pass when no dodge-capable
# player is online (one predicate existence check vs an unconditional @a tag-remove + @a snapshot
# every tick). Reschedules first so the loop survives. Actual dodgers keep full 1t responsiveness.
# (A stale i-frame tag on a now-ineligible player is harmless and is cleared the next time anyone
# is eligible by the line below.)
execute unless entity @a[predicate=evercraft:advantage/dodge_eligible,limit=1] run return run schedule function evercraft:advantage/tick/dodge_snapshot 1t replace

# Clear i-frame tags from previous tick (housekeeping; harmless on no-op)
tag @a[tag=ec.dodge_iframe] remove ec.dodge_iframe

# Snapshot HP for eligible players only (predicate ORs adv.evasion / te.dodge / dn_evasion_add / pres_stea / pa_evas3_tm / ec.acc_dodge)
execute as @a[predicate=evercraft:advantage/dodge_eligible] store result score @s ec.dodge_hp_snap run data get entity @s Health 1

# Self-schedule
schedule function evercraft:advantage/tick/dodge_snapshot 1t replace
