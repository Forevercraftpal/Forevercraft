# Cosmetics Tick (1 Hz) — persistent-effect tiers + fast-tag maintenance (Wiring Audit #31)
# Called as: execute as @a[scores={adv.cosm_active=1..}] at @s
# Particle tiers (1 Particle Aura / 3 Effect Trail / 5 Crown) moved to advantage/cosmetics/fast_tick
# (10 Hz) so they read as a continuous aura instead of a 1 Hz flicker. Here we keep the two
# PERSISTENT tiers (2 Title Tag team / 4 Glow effect) on 1 Hz, and re-derive the Adv.CosmFast tag
# from the score so the fast driver picks up particle players (self-heals across relog/restart).

# Persistent tiers (not particles) stay on the 1 s path
execute if score @s adv.cosm_active matches 2 run function evercraft:advantage/cosmetics/title_tag
execute if score @s adv.cosm_active matches 4 run function evercraft:advantage/cosmetics/glow_outline

# Fast-particle tag maintenance: tiers 1/3/5 ride the 10 Hz path; 2/4 must NOT
execute if score @s adv.cosm_active matches 1 run tag @s add Adv.CosmFast
execute if score @s adv.cosm_active matches 3 run tag @s add Adv.CosmFast
execute if score @s adv.cosm_active matches 5 run tag @s add Adv.CosmFast
execute unless score @s adv.cosm_active matches 1 unless score @s adv.cosm_active matches 3 unless score @s adv.cosm_active matches 5 run tag @s remove Adv.CosmFast
