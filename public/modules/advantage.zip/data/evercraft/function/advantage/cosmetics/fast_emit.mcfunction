# Cosmetics Fast Emit — route the active PARTICLE tier to its emitter (Wiring Audit #31)
# Run as @s (player tagged Adv.CosmFast), at @s, every 2t from fast_tick.
# Only particle tiers live here: 1 Particle Aura / 3 Effect Trail / 5 Crown Particles.
# Tiers 2 (Title Tag) + 4 (Glow Outline) are persistent and handled on the 1 s path.
execute if score @s adv.cosm_active matches 1 run function evercraft:advantage/cosmetics/particle_aura
execute if score @s adv.cosm_active matches 3 run function evercraft:advantage/cosmetics/effect_trail
execute if score @s adv.cosm_active matches 5 run function evercraft:advantage/cosmetics/crown_particles
