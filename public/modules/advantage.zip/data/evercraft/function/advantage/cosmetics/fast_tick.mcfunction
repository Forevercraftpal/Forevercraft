# Cosmetics Fast Tick — 10 Hz driver (Wiring Audit #31)
# WHY: particle cosmetics used to ride the 1 s advantage/tick/main, so they emitted ~2-3 particles
# ONCE PER SECOND — a near-invisible flicker that read as "doesn't work". Here they emit at 2t (10 Hz)
# so they look like a continuous aura. Title Tag (2) + Glow Outline (4) are persistent (team/effect),
# NOT particles, so they stay on the 1 s path in advantage/cosmetics/tick.
# Kicked once from advantage/load; self-reschedules every 2t. Existence-gated so idle players cost nothing.

schedule function evercraft:advantage/cosmetics/fast_tick 2t

# Particle tiers 1/3/5 — gated by the Adv.CosmFast tag (set in toggle + re-derived in cosmetics/tick)
execute as @a[tag=Adv.CosmFast] at @s run function evercraft:advantage/cosmetics/fast_emit

# Crate cosmetic particles — moved off the 1 s tick/main so they're smooth too
execute as @a[scores={adv.cc_part1=1..}] at @s run function evercraft:advantage/cosmetics/crate_particles_tick

# Floating-title follow + text update (Wiring Audit #31 — titles/float/ owns the renderer).
# Lag audit 2026-06-22: gated to ec.has_float_title (maintained 1 Hz by titles/float/sentinel) so the
# ~20-op title cascade no longer runs 10x/sec for every UNTITLED player. The sentinel owns teardown,
# so untitled players (no tag) are correctly skipped here without leaking their float.
execute as @a[tag=ec.has_float_title] at @s run function evercraft:titles/float/tick
