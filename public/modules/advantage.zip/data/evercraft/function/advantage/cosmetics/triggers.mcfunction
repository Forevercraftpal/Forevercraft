# Cosmetic Triggers — Route /trigger adv.cosmetic
# 0 = disable, 1-5 = tier toggle, 101-115 = select tree variant

scoreboard players operation #cosm_val adv.temp = @s adv.cosmetic

# === TIER TOGGLE (0-5) ===
# Disable all cosmetics
execute if score #cosm_val adv.temp matches 0 run scoreboard players set @s adv.cosm_active 0
execute if score #cosm_val adv.temp matches 0 run effect clear @s minecraft:glowing
execute if score #cosm_val adv.temp matches 0 run function evercraft:advantage/cosmetics/leave_teams
execute if score #cosm_val adv.temp matches 0 run tag @s remove Adv.CosmFast
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"Cosmetics disabled.",color:"gray"},{text:" ✦",color:"gold"}]
scoreboard players set #ndur ec.temp 45
execute if score #cosm_val adv.temp matches 0 run function evercraft:util/notify/emit

# Toggle specific tier
execute if score #cosm_val adv.temp matches 1..5 run function evercraft:advantage/cosmetics/toggle

# === TREE VARIANT SELECTOR (101-115) ===
execute if score #cosm_val adv.temp matches 101 run scoreboard players set @s adv.cosm_tree 1
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"Cosmetic variant: ",color:"gray"},{text:"Agility",color:"aqua"},{text:" ✦",color:"gold"}]
scoreboard players set #ndur ec.temp 45
execute if score #cosm_val adv.temp matches 101 run function evercraft:util/notify/emit
execute if score #cosm_val adv.temp matches 102 run scoreboard players set @s adv.cosm_tree 2
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"Cosmetic variant: ",color:"gray"},{text:"Dexterity",color:"yellow"},{text:" ✦",color:"gold"}]
scoreboard players set #ndur ec.temp 45
execute if score #cosm_val adv.temp matches 102 run function evercraft:util/notify/emit
execute if score #cosm_val adv.temp matches 103 run scoreboard players set @s adv.cosm_tree 3
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"Cosmetic variant: ",color:"gray"},{text:"Evasion",color:"white"},{text:" ✦",color:"gold"}]
scoreboard players set #ndur ec.temp 45
execute if score #cosm_val adv.temp matches 103 run function evercraft:util/notify/emit
execute if score #cosm_val adv.temp matches 104 run scoreboard players set @s adv.cosm_tree 4
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"Cosmetic variant: ",color:"gray"},{text:"Stealth",color:"dark_gray"},{text:" ✦",color:"gold"}]
scoreboard players set #ndur ec.temp 45
execute if score #cosm_val adv.temp matches 104 run function evercraft:util/notify/emit
execute if score #cosm_val adv.temp matches 105 run scoreboard players set @s adv.cosm_tree 5
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"Cosmetic variant: ",color:"gray"},{text:"Vitality",color:"red"},{text:" ✦",color:"gold"}]
scoreboard players set #ndur ec.temp 45
execute if score #cosm_val adv.temp matches 105 run function evercraft:util/notify/emit
execute if score #cosm_val adv.temp matches 106 run scoreboard players set @s adv.cosm_tree 6
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"Cosmetic variant: ",color:"gray"},{text:"Taskmaster",color:"dark_purple"},{text:" ✦",color:"gold"}]
scoreboard players set #ndur ec.temp 45
execute if score #cosm_val adv.temp matches 106 run function evercraft:util/notify/emit
execute if score #cosm_val adv.temp matches 107 run scoreboard players set @s adv.cosm_tree 7
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"Cosmetic variant: ",color:"gray"},{text:"Beastmaster",color:"green"},{text:" ✦",color:"gold"}]
scoreboard players set #ndur ec.temp 45
execute if score #cosm_val adv.temp matches 107 run function evercraft:util/notify/emit
execute if score #cosm_val adv.temp matches 108 run scoreboard players set @s adv.cosm_tree 8
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"Cosmetic variant: ",color:"gray"},{text:"Victorian",color:"dark_red"},{text:" ✦",color:"gold"}]
scoreboard players set #ndur ec.temp 45
execute if score #cosm_val adv.temp matches 108 run function evercraft:util/notify/emit
execute if score #cosm_val adv.temp matches 109 run scoreboard players set @s adv.cosm_tree 9
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"Cosmetic variant: ",color:"gray"},{text:"Fishing",color:"blue"},{text:" ✦",color:"gold"}]
scoreboard players set #ndur ec.temp 45
execute if score #cosm_val adv.temp matches 109 run function evercraft:util/notify/emit
execute if score #cosm_val adv.temp matches 110 run scoreboard players set @s adv.cosm_tree 10
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"Cosmetic variant: ",color:"gray"},{text:"Mining",color:"gold"},{text:" ✦",color:"gold"}]
scoreboard players set #ndur ec.temp 45
execute if score #cosm_val adv.temp matches 110 run function evercraft:util/notify/emit
execute if score #cosm_val adv.temp matches 111 run scoreboard players set @s adv.cosm_tree 11
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"Cosmetic variant: ",color:"gray"},{text:"Gathering",color:"green"},{text:" ✦",color:"gold"}]
scoreboard players set #ndur ec.temp 45
execute if score #cosm_val adv.temp matches 111 run function evercraft:util/notify/emit
execute if score #cosm_val adv.temp matches 112 run scoreboard players set @s adv.cosm_tree 12
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"Cosmetic variant: ",color:"gray"},{text:"Blacksmith",color:"gray"},{text:" ✦",color:"gold"}]
scoreboard players set #ndur ec.temp 45
execute if score #cosm_val adv.temp matches 112 run function evercraft:util/notify/emit
execute if score #cosm_val adv.temp matches 113 run scoreboard players set @s adv.cosm_tree 13
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"Cosmetic variant: ",color:"gray"},{text:"Explorer",color:"dark_aqua"},{text:" ✦",color:"gold"}]
scoreboard players set #ndur ec.temp 45
execute if score #cosm_val adv.temp matches 113 run function evercraft:util/notify/emit
execute if score #cosm_val adv.temp matches 114 run scoreboard players set @s adv.cosm_tree 14
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"Cosmetic variant: ",color:"gray"},{text:"Culinary",color:"green"},{text:" ✦",color:"gold"}]
scoreboard players set #ndur ec.temp 45
execute if score #cosm_val adv.temp matches 114 run function evercraft:util/notify/emit
execute if score #cosm_val adv.temp matches 115 run scoreboard players set @s adv.cosm_tree 15
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"Cosmetic variant: ",color:"gray"},{text:"Chemistry",color:"#9B59B6"},{text:" ✦",color:"gold"}]
scoreboard players set #ndur ec.temp 45
execute if score #cosm_val adv.temp matches 115 run function evercraft:util/notify/emit
