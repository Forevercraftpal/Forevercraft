# Prestige Ability: Wayfinder — launch skyward + locate nearest structure + exploration buffs (24hr cooldown)
scoreboard players set @s adv.pa_expl3 1
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"Wayfinder",color:"green"},{text:" — Launches you skyward + locates the nearest structure + grants exploration buffs (5 min). 24hr cooldown.",color:"gray"},{text:" ✦",color:"gold"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.player.levelup master @s ~ ~ ~ 1 1.2
