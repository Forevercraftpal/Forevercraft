# Prestige Ability: Master Angler — third net + double catches + treasure loot
scoreboard players set @s adv.pa_fish3 1
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"Master Angler",color:"green"},{text:" — Third net + double catches + rare treasure!",color:"gray"},{text:" ✦",color:"gold"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit

# Give a third water net item
# Inv-full guard: drop at the player's feet rather than void on a full inventory.
execute store result score #inv_full ec.var run function evercraft:util/check_inv_full
execute if score #inv_full ec.var matches 0 run loot give @s loot evercraft:advantage/water_net_drop
execute if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:advantage/water_net_drop
data modify storage evercraft:notify stage.c set value [{text:"► ",color:"gray"},{text:"Water Net",color:"aqua"},{text:" added to your inventory!",color:"green"}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit

# Upgrade all existing deployed WaterNet markers to master_angler mode
execute as @e[type=marker,tag=WaterNet] run data modify entity @s data.master_angler set value 1b
data modify storage evercraft:notify stage.c set value [{text:"► ",color:"gray"},{text:"All deployed Water Nets upgraded to Master Angler!",color:"green"}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"► ",color:"gray"},{text:"16 catches per morning + chance for treasure loot.",color:"aqua"}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit

execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.player.levelup master @s ~ ~ ~ 1 1.2
