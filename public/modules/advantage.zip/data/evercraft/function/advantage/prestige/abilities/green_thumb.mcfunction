# Green Thumb — Auto-replant crops on harvest
# Called at player position when a harvest crate triggers
# Scans a 5x5 area (2-block radius) at foot level for farmland with air above and replants.
#
# 2026-05-28 (W5.3): now PRESERVES the player-farmed crop type by inferring it from any
# remaining crops in the same 5x5 area. Fallback is wheat. Caller chain doesn't pass crop
# type — the inference handles mono-cropped fields (the common case).

# Default: wheat
data modify storage evercraft:advantage gt_crop set value "minecraft:wheat"

# Sniff a neighbor (any age) to infer crop type — last-write-wins, so order is:
# wheat (default) → beetroots → potatoes → carrots so carrot fields win.
execute if block ~-1 ~ ~ #minecraft:crops if block ~-1 ~ ~ minecraft:beetroots run data modify storage evercraft:advantage gt_crop set value "minecraft:beetroots"
execute if block ~1 ~ ~ #minecraft:crops if block ~1 ~ ~ minecraft:beetroots run data modify storage evercraft:advantage gt_crop set value "minecraft:beetroots"
execute if block ~ ~ ~-1 #minecraft:crops if block ~ ~ ~-1 minecraft:beetroots run data modify storage evercraft:advantage gt_crop set value "minecraft:beetroots"
execute if block ~ ~ ~1 #minecraft:crops if block ~ ~ ~1 minecraft:beetroots run data modify storage evercraft:advantage gt_crop set value "minecraft:beetroots"

execute if block ~-1 ~ ~ #minecraft:crops if block ~-1 ~ ~ minecraft:potatoes run data modify storage evercraft:advantage gt_crop set value "minecraft:potatoes"
execute if block ~1 ~ ~ #minecraft:crops if block ~1 ~ ~ minecraft:potatoes run data modify storage evercraft:advantage gt_crop set value "minecraft:potatoes"
execute if block ~ ~ ~-1 #minecraft:crops if block ~ ~ ~-1 minecraft:potatoes run data modify storage evercraft:advantage gt_crop set value "minecraft:potatoes"
execute if block ~ ~ ~1 #minecraft:crops if block ~ ~ ~1 minecraft:potatoes run data modify storage evercraft:advantage gt_crop set value "minecraft:potatoes"

execute if block ~-1 ~ ~ #minecraft:crops if block ~-1 ~ ~ minecraft:carrots run data modify storage evercraft:advantage gt_crop set value "minecraft:carrots"
execute if block ~1 ~ ~ #minecraft:crops if block ~1 ~ ~ minecraft:carrots run data modify storage evercraft:advantage gt_crop set value "minecraft:carrots"
execute if block ~ ~ ~-1 #minecraft:crops if block ~ ~ ~-1 minecraft:carrots run data modify storage evercraft:advantage gt_crop set value "minecraft:carrots"
execute if block ~ ~ ~1 #minecraft:crops if block ~ ~ ~1 minecraft:carrots run data modify storage evercraft:advantage gt_crop set value "minecraft:carrots"

# Replant 5x5 grid via macro (2-block radius)
function evercraft:advantage/prestige/abilities/green_thumb_replant with storage evercraft:advantage

# Particles
particle minecraft:happy_villager ~ ~0.5 ~ 1 0.3 1 0.02 3
