# Prestige Ability: Vanishing Dodge — become invisible for 2s on dodge
# Already hooked in evasion_dodge.mcfunction (checks adv.pres_evas matches 2..)
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"Vanishing Dodge",color:"green"},{text:" — Dodging grants 2s invisibility!",color:"gray"},{text:" ✦",color:"gold"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.player.levelup master @s ~ ~ ~ 1 1.2
