# Chemistry P3: Philosopher's Touch — 10% chance to double potion output
# Activated on prestige 3, flag checked during brewing
scoreboard players set @s adv.pa_chem3 1
data modify storage evercraft:notify stage.c set value [{text:"★ ",color:"gold"},{text:"Philosopher's Touch",color:"#9B59B6",bold:true},{text:" unlocked! 10% chance to double potion output.",color:"gray"},{text:" ★",color:"gold"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
