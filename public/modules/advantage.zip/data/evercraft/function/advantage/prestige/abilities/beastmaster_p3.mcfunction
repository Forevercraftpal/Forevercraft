# Prestige Ability: War Cry — buff all wolves with Speed II + Strength II on command
scoreboard players set @s adv.pa_beas3 1
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"War Cry",color:"green"},{text:" — Empower all wolves with Speed II + Strength II for 30s! (5min cooldown)",color:"gray"},{text:" ✦",color:"gold"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"► ",color:"dark_gray"},{text:"Use: /trigger adv.warcry set 1",color:"dark_gray",italic:true}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.player.levelup master @s ~ ~ ~ 1 1.2
