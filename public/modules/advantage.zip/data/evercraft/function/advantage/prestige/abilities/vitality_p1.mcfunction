# Prestige Ability: Vital Regen — passive regen when low HP
# Already handled in tick/main (checks adv.pres_vita matches 1.. + is_low_hp predicate)
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"Vital Regen",color:"green"},{text:" — You regenerate health when below 50% HP!",color:"gray"},{text:" ✦",color:"gold"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.player.levelup master @s ~ ~ ~ 1 1.2
