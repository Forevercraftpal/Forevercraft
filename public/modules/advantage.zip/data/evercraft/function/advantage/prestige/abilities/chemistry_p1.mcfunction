# Chemistry P1: Catalyst — +15% chance to not consume brewing ingredients
# Activated on prestige 1, flag checked during brewing
scoreboard players set @s adv.pa_chem1 1
data modify storage evercraft:notify stage.c set value [{text:"★ ",color:"gold"},{text:"Catalyst",color:"#9B59B6",bold:true},{text:" unlocked! +15% chance to preserve ingredients.",color:"gray"},{text:" ★",color:"gold"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
