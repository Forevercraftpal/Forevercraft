# Prestige Ability: Cartographer — locate nearest structure on command (50hr cooldown)
scoreboard players set @s adv.pa_expl2 1
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"Cartographer",color:"green"},{text:" — Locate nearest structure on command! 50hr cooldown.",color:"gray"},{text:" ✦",color:"gold"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.player.levelup master @s ~ ~ ~ 1 1.2
