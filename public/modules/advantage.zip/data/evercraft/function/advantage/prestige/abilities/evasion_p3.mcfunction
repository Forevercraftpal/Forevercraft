# Prestige Ability: Perfect Evasion — 1s guaranteed dodge window after dodging
# Already hooked in evasion_dodge (sets timer) and evasion_check (guarantees dodge when timer active)
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"Perfect Evasion",color:"green"},{text:" — After dodging, all attacks are dodged for 1s!",color:"gray"},{text:" ✦",color:"gold"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.player.levelup master @s ~ ~ ~ 1 1.2
