# Prestige Ability: Quick Draw — +15% attack speed permanently
scoreboard players set @s adv.pa_dex1 1
attribute @s attack_speed modifier remove evercraft:adv_pres_dex1
attribute @s attack_speed modifier add evercraft:adv_pres_dex1 0.15 add_multiplied_base
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"Quick Draw",color:"green"},{text:" — +15% attack speed permanently!",color:"gray"},{text:" ✦",color:"gold"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.player.levelup master @s ~ ~ ~ 1 1.2
