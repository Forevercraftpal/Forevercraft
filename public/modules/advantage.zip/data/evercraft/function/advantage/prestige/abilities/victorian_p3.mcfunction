# Prestige Ability: Spoils of War — doubled mob crate spawn chance
# Each patron drop file checks adv.pa_vict3 for a second 25% roll
scoreboard players set @s adv.pa_vict3 1
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"Spoils of War",color:"green"},{text:" — Doubled mob crate spawn chance!",color:"gray"},{text:" ✦",color:"gold"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.player.levelup master @s ~ ~ ~ 1 1.2
