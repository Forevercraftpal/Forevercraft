# Prestige Ability: Efficient Fuel — 50% chance to not consume furnace fuel
scoreboard players set @s adv.pa_blac2 1
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"Efficient Fuel",color:"green"},{text:" — 50% chance to not consume furnace fuel!",color:"gray"},{text:" ✦",color:"gold"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.player.levelup master @s ~ ~ ~ 1 1.2
