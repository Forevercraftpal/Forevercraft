# Prestige Ability: Master Alloy — 2x smelt output chance + 50% less anvil XP
scoreboard players set @s adv.pa_blac1 1
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"Master Alloy",color:"green"},{text:" — 2x smelt output chance + 50% less anvil XP!",color:"gray"},{text:" ✦",color:"gold"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.player.levelup master @s ~ ~ ~ 1 1.2
