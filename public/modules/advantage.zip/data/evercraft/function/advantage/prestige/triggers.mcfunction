# Prestige — Trigger Router
# Routes /trigger adv.prestige 1-15 to prestige handler for the corresponding tree
# Checks eligibility (level 25, prestige < 3) before processing

# Store tree ID
scoreboard players operation #pres_tree adv.temp = @s adv.prestige

# Zero scratch FIRST: post-Pioneer-wipe the tree's adv.<skill> / adv.pres_<tree> entry can be
# ABSENT (strip_player_zero's reset @s removes the entry, and these aren't re-set). The gated
# `= @s` then FAILS, leaving #pres_level / #pres_current holding a PRIOR invocation's value
# (stale). check_eligible gates on `#pres_level matches 25` + `#pres_current matches 3..`; a
# stale #pres_level==25 would falsely pass the level gate and let a Lv.1 tree prestige (free
# tokens + ability). Init to 0 so a missing entry reads as level 0 → eligibility correctly fails.
scoreboard players set #pres_level adv.temp 0
scoreboard players set #pres_current adv.temp 0

# Read current tree level into #pres_level
execute if score #pres_tree adv.temp matches 1 run scoreboard players operation #pres_level adv.temp = @s adv.agility
execute if score #pres_tree adv.temp matches 2 run scoreboard players operation #pres_level adv.temp = @s adv.dexterity
execute if score #pres_tree adv.temp matches 3 run scoreboard players operation #pres_level adv.temp = @s adv.evasion
execute if score #pres_tree adv.temp matches 4 run scoreboard players operation #pres_level adv.temp = @s adv.stealth
execute if score #pres_tree adv.temp matches 5 run scoreboard players operation #pres_level adv.temp = @s adv.vitality
execute if score #pres_tree adv.temp matches 6 run scoreboard players operation #pres_level adv.temp = @s adv.taskmaster
execute if score #pres_tree adv.temp matches 7 run scoreboard players operation #pres_level adv.temp = @s adv.beastmaster
execute if score #pres_tree adv.temp matches 8 run scoreboard players operation #pres_level adv.temp = @s adv.victorian
execute if score #pres_tree adv.temp matches 9 run scoreboard players operation #pres_level adv.temp = @s adv.fishing
execute if score #pres_tree adv.temp matches 10 run scoreboard players operation #pres_level adv.temp = @s adv.mining
execute if score #pres_tree adv.temp matches 11 run scoreboard players operation #pres_level adv.temp = @s adv.gathering
execute if score #pres_tree adv.temp matches 12 run scoreboard players operation #pres_level adv.temp = @s adv.blacksmith
execute if score #pres_tree adv.temp matches 13 run scoreboard players operation #pres_level adv.temp = @s adv.explorer
execute if score #pres_tree adv.temp matches 14 run scoreboard players operation #pres_level adv.temp = @s adv.culinary
execute if score #pres_tree adv.temp matches 15 run scoreboard players operation #pres_level adv.temp = @s adv.chemistry

# Read current prestige level into #pres_current
execute if score #pres_tree adv.temp matches 1 run scoreboard players operation #pres_current adv.temp = @s adv.pres_agil
execute if score #pres_tree adv.temp matches 2 run scoreboard players operation #pres_current adv.temp = @s adv.pres_dext
execute if score #pres_tree adv.temp matches 3 run scoreboard players operation #pres_current adv.temp = @s adv.pres_evas
execute if score #pres_tree adv.temp matches 4 run scoreboard players operation #pres_current adv.temp = @s adv.pres_stea
execute if score #pres_tree adv.temp matches 5 run scoreboard players operation #pres_current adv.temp = @s adv.pres_vita
execute if score #pres_tree adv.temp matches 6 run scoreboard players operation #pres_current adv.temp = @s adv.pres_task
execute if score #pres_tree adv.temp matches 7 run scoreboard players operation #pres_current adv.temp = @s adv.pres_beas
execute if score #pres_tree adv.temp matches 8 run scoreboard players operation #pres_current adv.temp = @s adv.pres_vict
execute if score #pres_tree adv.temp matches 9 run scoreboard players operation #pres_current adv.temp = @s adv.pres_fish
execute if score #pres_tree adv.temp matches 10 run scoreboard players operation #pres_current adv.temp = @s adv.pres_mine
execute if score #pres_tree adv.temp matches 11 run scoreboard players operation #pres_current adv.temp = @s adv.pres_gath
execute if score #pres_tree adv.temp matches 12 run scoreboard players operation #pres_current adv.temp = @s adv.pres_blac
execute if score #pres_tree adv.temp matches 13 run scoreboard players operation #pres_current adv.temp = @s adv.pres_expl
execute if score #pres_tree adv.temp matches 14 run scoreboard players operation #pres_current adv.temp = @s adv.pres_culi
execute if score #pres_tree adv.temp matches 15 run scoreboard players operation #pres_current adv.temp = @s adv.pres_chem

# Check eligibility and execute
function evercraft:advantage/prestige/check_eligible
