# Prestige Ability: Water Net — passive morning fish trap
scoreboard players set @s adv.pa_fish1 1
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"Water Net",color:"green"},{text:" — Place in water to auto-catch fish each morning!",color:"gray"},{text:" ✦",color:"gold"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit

# Give the water net item via loot table (consistent components)
# Inv-full guard: drop at the player's feet rather than void on a full inventory.
execute store result score #inv_full ec.var run function evercraft:util/check_inv_full
execute if score #inv_full ec.var matches 0 run loot give @s loot evercraft:advantage/water_net_drop
execute if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:advantage/water_net_drop
data modify storage evercraft:notify stage.c set value [{text:"► ",color:"gray"},{text:"Water Net",color:"aqua"},{text:" added to your inventory!",color:"green"}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"► ",color:"gray"},{text:"Place a barrel with 3+ water source sides to deploy.",color:"gray"}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit
