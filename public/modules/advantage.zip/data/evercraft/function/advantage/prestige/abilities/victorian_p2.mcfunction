# Prestige Ability: Bloodthirst — +50% bonus XP from mob crates and patrons
scoreboard players set @s adv.pa_vict2 1
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"Bloodthirst",color:"green"},{text:" — +50% bonus XP from mob crates and patron kills!",color:"gray"},{text:" ✦",color:"gold"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.player.levelup master @s ~ ~ ~ 1 1.2
