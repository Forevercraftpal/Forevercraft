# Prestige Ability: Harvest Lord — 50% growth speed, 32-block range + crop vein mine
scoreboard players set @s adv.pa_gath3 1
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"Harvest Lord",color:"green"},{text:" — 50% growth speed, 32-block range + crop vein mine!",color:"gray"},{text:" ✦",color:"gold"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.player.levelup master @s ~ ~ ~ 1 1.2
