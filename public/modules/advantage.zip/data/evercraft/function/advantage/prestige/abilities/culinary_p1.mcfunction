# Culinary P1: Hearty Harvest — +10% ingredient drop chance
# Activated on prestige 1, flag checked during ingredient gathering
scoreboard players set @s adv.pa_culi1 1
data modify storage evercraft:notify stage.c set value [{text:"★ ",color:"gold"},{text:"Hearty Harvest",color:"green",bold:true},{text:" unlocked! +10% ingredient drops.",color:"gray"},{text:" ★",color:"gold"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
