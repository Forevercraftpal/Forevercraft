# Prestige Ability: Shadow Cloak — invisibility while sneaking
# Already handled inline in tick/main (checks adv.pres_stea matches 1.. + is_sneaking)
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"Shadow Cloak",color:"green"},{text:" — Become invisible while sneaking!",color:"gray"},{text:" ✦",color:"gold"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.player.levelup master @s ~ ~ ~ 1 1.2
