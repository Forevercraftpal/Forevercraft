# Prestige Ability: Fertile Aura — 25% crop growth speed in 16-block radius
scoreboard players set @s adv.pa_gath2 1
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"Fertile Aura",color:"green"},{text:" — 25% crop growth speed in 16-block radius!",color:"gray"},{text:" ✦",color:"gold"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.player.levelup master @s ~ ~ ~ 1 1.2
