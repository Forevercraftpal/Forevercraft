# Prestige Ability: Veteran's Instinct — +2 Dream Rate + quest completion buff
scoreboard players set @s adv.pa_task3 1
attribute @s luck modifier remove evercraft:adv_pres_task3
attribute @s luck modifier add evercraft:adv_pres_task3 2.0 add_value
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"Veteran's Instinct",color:"green"},{text:" — Permanent +2 Dream Rate + completion buffs!",color:"gray"},{text:" ✦",color:"gold"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.player.levelup master @s ~ ~ ~ 1 1.2
