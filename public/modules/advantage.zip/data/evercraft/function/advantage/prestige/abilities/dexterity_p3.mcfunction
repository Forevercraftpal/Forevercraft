# Prestige Ability: Extended Reach — permanently reach 8+ blocks
# Applied via reapply_all (attribute modifiers evercraft:adv_pres_dex3 already wired)
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"Extended Reach",color:"green"},{text:" — Your reach extends to 8+ blocks permanently!",color:"gray"},{text:" ✦",color:"gold"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.player.levelup master @s ~ ~ ~ 1 1.2
