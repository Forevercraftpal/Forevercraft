# Prestige Ability: Sprint Persist — momentum continues briefly after sprinting
scoreboard players set @s adv.pa_agil1 1
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"Sprint Persist",color:"green"},{text:" — Your momentum carries forward after sprinting!",color:"gray"},{text:" ✦",color:"gold"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.player.levelup master @s ~ ~ ~ 1 1.2
