# Prestige — Execute Prestige
# Reads #pres_tree and #pres_current from triggers.mcfunction
# (1) Reset tree to 1, (2) Increment prestige, (3) Apply retained,
# (4) Unlock ability, (5) Update GUI, (6) Award tokens, (7) Feedback, (8) Milestones

# (0) ENGINE-LEVEL HARD CAP — defensive, RECON-FIX F2 (2026-06-01)
# The MAX prestige per tree is 3 (3 ability tiers p1/p2/p3 per tree = 45 abilities
# total; check_eligible blocks at #pres_current >= 3; retained bonus tops at 50%;
# all-prestige milestones cap at adv.pres_total 45 = 15 trees x 3). This engine
# unconditionally +1's adv.pres_<tree>; the <=3 invariant previously lived ONLY in
# the per-caller capstone clamps (forging already regressed once). Make the engine
# self-protecting: resolve the target tree's CURRENT prestige into #pres_guard and
# SHORT-CIRCUIT before any state change if it is already at the max (3). Legit
# callers stay within the cap, so this never changes their behavior — it only
# blocks over-prestige from any future/buggy caller (the 6th cloned line, etc.).
execute if score #pres_tree adv.temp matches 1 run scoreboard players operation #pres_guard adv.temp = @s adv.pres_agil
execute if score #pres_tree adv.temp matches 2 run scoreboard players operation #pres_guard adv.temp = @s adv.pres_dext
execute if score #pres_tree adv.temp matches 3 run scoreboard players operation #pres_guard adv.temp = @s adv.pres_evas
execute if score #pres_tree adv.temp matches 4 run scoreboard players operation #pres_guard adv.temp = @s adv.pres_stea
execute if score #pres_tree adv.temp matches 5 run scoreboard players operation #pres_guard adv.temp = @s adv.pres_vita
execute if score #pres_tree adv.temp matches 6 run scoreboard players operation #pres_guard adv.temp = @s adv.pres_task
execute if score #pres_tree adv.temp matches 7 run scoreboard players operation #pres_guard adv.temp = @s adv.pres_beas
execute if score #pres_tree adv.temp matches 8 run scoreboard players operation #pres_guard adv.temp = @s adv.pres_vict
execute if score #pres_tree adv.temp matches 9 run scoreboard players operation #pres_guard adv.temp = @s adv.pres_fish
execute if score #pres_tree adv.temp matches 10 run scoreboard players operation #pres_guard adv.temp = @s adv.pres_mine
execute if score #pres_tree adv.temp matches 11 run scoreboard players operation #pres_guard adv.temp = @s adv.pres_gath
execute if score #pres_tree adv.temp matches 12 run scoreboard players operation #pres_guard adv.temp = @s adv.pres_blac
execute if score #pres_tree adv.temp matches 13 run scoreboard players operation #pres_guard adv.temp = @s adv.pres_expl
execute if score #pres_tree adv.temp matches 14 run scoreboard players operation #pres_guard adv.temp = @s adv.pres_culi
execute if score #pres_tree adv.temp matches 15 run scoreboard players operation #pres_guard adv.temp = @s adv.pres_chem
execute if score #pres_guard adv.temp matches 3.. run return 0

# (1) Reset tree level to 1
execute if score #pres_tree adv.temp matches 1 run scoreboard players set @s adv.agility 1
execute if score #pres_tree adv.temp matches 2 run scoreboard players set @s adv.dexterity 1
execute if score #pres_tree adv.temp matches 3 run scoreboard players set @s adv.evasion 1
execute if score #pres_tree adv.temp matches 4 run scoreboard players set @s adv.stealth 1
execute if score #pres_tree adv.temp matches 5 run scoreboard players set @s adv.vitality 1
execute if score #pres_tree adv.temp matches 6 run scoreboard players set @s adv.taskmaster 1
execute if score #pres_tree adv.temp matches 7 run scoreboard players set @s adv.beastmaster 1
# Drain the Beastmaster hunt-credit reservoir + effective-stat cache on prestige, else banked virtual
# pets survive the Lv.1 reset and re-level for free (Council #6, 2026-06-02).
execute if score #pres_tree adv.temp matches 7 run scoreboard players set @s adv.bm_credit 0
execute if score #pres_tree adv.temp matches 7 run scoreboard players set @s adv.bm_eff 0
execute if score #pres_tree adv.temp matches 8 run scoreboard players set @s adv.victorian 1
execute if score #pres_tree adv.temp matches 9 run scoreboard players set @s adv.fishing 1
execute if score #pres_tree adv.temp matches 10 run scoreboard players set @s adv.mining 1
execute if score #pres_tree adv.temp matches 11 run scoreboard players set @s adv.gathering 1
execute if score #pres_tree adv.temp matches 12 run scoreboard players set @s adv.blacksmith 1
execute if score #pres_tree adv.temp matches 13 run scoreboard players set @s adv.explorer 1
execute if score #pres_tree adv.temp matches 14 run scoreboard players set @s adv.culinary 1
execute if score #pres_tree adv.temp matches 15 run scoreboard players set @s adv.chemistry 1

# (2) Increment prestige level
execute if score #pres_tree adv.temp matches 1 run scoreboard players add @s adv.pres_agil 1
execute if score #pres_tree adv.temp matches 2 run scoreboard players add @s adv.pres_dext 1
execute if score #pres_tree adv.temp matches 3 run scoreboard players add @s adv.pres_evas 1
execute if score #pres_tree adv.temp matches 4 run scoreboard players add @s adv.pres_stea 1
execute if score #pres_tree adv.temp matches 5 run scoreboard players add @s adv.pres_vita 1
execute if score #pres_tree adv.temp matches 6 run scoreboard players add @s adv.pres_task 1
execute if score #pres_tree adv.temp matches 7 run scoreboard players add @s adv.pres_beas 1
execute if score #pres_tree adv.temp matches 8 run scoreboard players add @s adv.pres_vict 1
execute if score #pres_tree adv.temp matches 9 run scoreboard players add @s adv.pres_fish 1
execute if score #pres_tree adv.temp matches 10 run scoreboard players add @s adv.pres_mine 1
execute if score #pres_tree adv.temp matches 11 run scoreboard players add @s adv.pres_gath 1
execute if score #pres_tree adv.temp matches 12 run scoreboard players add @s adv.pres_blac 1
execute if score #pres_tree adv.temp matches 13 run scoreboard players add @s adv.pres_expl 1
execute if score #pres_tree adv.temp matches 14 run scoreboard players add @s adv.pres_culi 1
execute if score #pres_tree adv.temp matches 15 run scoreboard players add @s adv.pres_chem 1
scoreboard players add @s adv.pres_total 1

# Spirit progression — track all-prestige flag (15 = all trees prestiged at least once)
execute if score @s adv.pres_total matches 15.. run scoreboard players set @s ec.sp_all_prestige 1

# Re-read new prestige level into #pres_current (now 1/2/3)
execute if score #pres_tree adv.temp matches 1 run scoreboard players operation #pres_current adv.temp = @s adv.pres_agil
execute if score #pres_tree adv.temp matches 2 run scoreboard players operation #pres_current adv.temp = @s adv.pres_dext
execute if score #pres_tree adv.temp matches 3 run scoreboard players operation #pres_current adv.temp = @s adv.pres_evas
execute if score #pres_tree adv.temp matches 4 run scoreboard players operation #pres_current adv.temp = @s adv.pres_stea
execute if score #pres_tree adv.temp matches 5 run scoreboard players operation #pres_current adv.temp = @s adv.pres_vita
execute if score #pres_tree adv.temp matches 6 run scoreboard players operation #pres_current adv.temp = @s adv.pres_task
execute if score #pres_tree adv.temp matches 7 run scoreboard players operation #pres_current adv.temp = @s adv.pres_beas
execute if score #pres_tree adv.temp matches 8 run scoreboard players operation #pres_current adv.temp = @s adv.pres_vict
execute if score #pres_tree adv.temp matches 9 run scoreboard players operation #pres_current adv.temp = @s adv.pres_fish
execute if score #pres_tree adv.temp matches 10 run scoreboard players operation #pres_current adv.temp = @s adv.pres_mine
execute if score #pres_tree adv.temp matches 11 run scoreboard players operation #pres_current adv.temp = @s adv.pres_gath
execute if score #pres_tree adv.temp matches 12 run scoreboard players operation #pres_current adv.temp = @s adv.pres_blac
execute if score #pres_tree adv.temp matches 13 run scoreboard players operation #pres_current adv.temp = @s adv.pres_expl
execute if score #pres_tree adv.temp matches 14 run scoreboard players operation #pres_current adv.temp = @s adv.pres_culi
execute if score #pres_tree adv.temp matches 15 run scoreboard players operation #pres_current adv.temp = @s adv.pres_chem

# (3) Apply retained bonuses (attribute modifiers at prestige %)
function evercraft:advantage/prestige/apply_retained

# (4) Reapply base effects at level 1
function evercraft:advantage/effects/reapply_all

# (5) Unlock prestige ability
function evercraft:advantage/prestige/unlock_ability

# (6) Award 100 tokens
data modify storage evercraft:tokens amount set value 100
function evercraft:advantage/tokens/award with storage evercraft:tokens

# (7) Update GUI if open
function evercraft:advantage/prestige/update_visual

# (8) Feedback
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 1 0.5
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.player.levelup master @s ~ ~ ~ 1 0.5
execute if score @s ec.fx_vis matches 1.. run particle minecraft:totem_of_undying ~ ~1 ~ 0.5 1 0.5 0.5 100 force
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"PRESTIGE ★ ",color:"dark_purple",bold:true},{text:"Tree reset to Lv.1 with 17% retained bonus. New ability unlocked!",color:"green"},{text:" ✦",color:"gold"}]
scoreboard players set #ndur ec.temp 45
execute if score #pres_current adv.temp matches 1 run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"PRESTIGE ★★ ",color:"light_purple",bold:true},{text:"Tree reset to Lv.1 with 34% retained bonus. New ability unlocked!",color:"green"},{text:" ✦",color:"gold"}]
scoreboard players set #ndur ec.temp 45
execute if score #pres_current adv.temp matches 2 run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"PRESTIGE ★★★ ",color:"gold",bold:true},{text:"Tree reset to Lv.1 with 50% retained bonus. New ability unlocked!",color:"green"},{text:" ✦",color:"gold"}]
scoreboard players set #ndur ec.temp 45
execute if score #pres_current adv.temp matches 3 run function evercraft:util/notify/emit

# (9) All-prestige milestones
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"ALL TREES PRESTIGE ★! ",color:"light_purple",bold:true},{text:"Choose 3 Mythical items from the Nymph!",color:"gold"},{text:" ✦",color:"gold"}]
scoreboard players set #ndur ec.temp 45
execute if score @s adv.pres_total matches 15 run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"ALL TREES PRESTIGE ★★! ",color:"light_purple",bold:true},{text:"Choose 5 Mythical items from the Nymph!",color:"gold"},{text:" ✦",color:"gold"}]
scoreboard players set #ndur ec.temp 45
execute if score @s adv.pres_total matches 30 run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"ALL TREES PRESTIGE ★★★! ",color:"gold",bold:true},{text:"Choose 10 Mythical items from the Nymph!",color:"gold"},{text:" ✦",color:"gold"}]
scoreboard players set #ndur ec.temp 45
execute if score @s adv.pres_total matches 45 run function evercraft:util/notify/emit
