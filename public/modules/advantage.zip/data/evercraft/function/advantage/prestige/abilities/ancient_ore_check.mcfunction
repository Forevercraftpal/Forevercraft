# Prestige Mining P3: Ancient Ore — 0.5% chance for ultra-rare ore on block mine
# Called from treasure/tick_player when a block mine is detected and P3 is active

execute store result score #anc_roll adv.temp run random value 1..200
execute unless score #anc_roll adv.temp matches 1 run return 0

# 1/200 = 0.5% — give Ancient Ore (netherite scrap + bonus)
give @s netherite_scrap[custom_name={text:"Ancient Ore",color:"dark_purple",italic:true},lore=[{text:"A primordial mineral from deep below.",color:"gray",italic:false}],enchantment_glint_override=true,custom_data={ancient_ore:1b}] 1

# Bonus tokens — route through tokens/award macro to give the physical Tree Token item +
# increment adv.tok_earned + fire the canonical +tokens tellraw. Previously was a raw
# `scoreboard players add @s adv.tokens 20` which bypassed all three (silent payout). [W5.1 2026-05-28]
data modify storage evercraft:tokens amount set value 20
function evercraft:advantage/tokens/award with storage evercraft:tokens

# Feedback
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 1.0 1.0
# (AB-1 sticky-times sweep 2026-06-10: explicit stamp — `title times` is sticky per player and this sequence set none, so it inherited whatever ran last.)
title @s times 10 60 20
title @s title [{text:"Ancient Ore!",color:"dark_purple"}]
title @s subtitle [{text:"A primordial mineral emerges...",color:"light_purple"}]
data modify storage evercraft:notify stage.c set value [{text:"You unearthed an Ancient Ore! (+20 tokens)",color:"light_purple"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
