# Prestige Ability: XP Siphon — XP orbs worth 25% more
# Already hooked in tick/main (calls xp_boost_tick for players with adv.pres_vict=1+)
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"XP Siphon",color:"green"},{text:" — XP orbs are worth 25% more!",color:"gray"},{text:" ✦",color:"gold"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.player.levelup master @s ~ ~ ~ 1 1.2
