# Prestige Ability: Second Net — deploy a second water net
scoreboard players set @s adv.pa_fish2 1
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"Second Net",color:"green"},{text:" — Deploy a second water net!",color:"gray"},{text:" ✦",color:"gold"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit

# Give another water net item via loot table
# Inv-full guard: drop at the player's feet rather than void on a full inventory.
execute store result score #inv_full ec.var run function evercraft:util/check_inv_full
execute if score #inv_full ec.var matches 0 run loot give @s loot evercraft:advantage/water_net_drop
execute if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:advantage/water_net_drop
data modify storage evercraft:notify stage.c set value [{text:"► ",color:"gray"},{text:"Water Net",color:"aqua"},{text:" added to your inventory!",color:"green"}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.player.levelup master @s ~ ~ ~ 1 1.2
