# Prestige Ability: Renowned — permanent +1 Dream Rate
scoreboard players set @s adv.pa_task2 1
attribute @s luck modifier remove evercraft:adv_pres_task2
attribute @s luck modifier add evercraft:adv_pres_task2 1.0 add_value
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"Renowned",color:"green"},{text:" — Permanent +1 Dream Rate! Your reputation precedes you.",color:"gray"},{text:" ✦",color:"gold"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.player.levelup master @s ~ ~ ~ 1 1.2
