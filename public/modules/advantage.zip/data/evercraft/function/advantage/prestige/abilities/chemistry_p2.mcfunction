# Chemistry P2: Concentrated Brew — Potions gain +1 amplifier level
# Activated on prestige 2, flag checked during potion creation
scoreboard players set @s adv.pa_chem2 1
data modify storage evercraft:notify stage.c set value [{text:"★ ",color:"gold"},{text:"Concentrated Brew",color:"#9B59B6",bold:true},{text:" unlocked! Potions are one tier stronger.",color:"gray"},{text:" ★",color:"gold"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
