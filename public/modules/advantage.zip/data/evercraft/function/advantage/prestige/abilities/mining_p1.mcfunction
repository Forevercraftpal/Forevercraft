# Prestige Ability: Ore Magnet — nearby ore drops are pulled toward you
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"Ore Magnet",color:"green"},{text:" — Dropped items within 8 blocks are pulled toward you!",color:"gray"},{text:" ✦",color:"gold"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
