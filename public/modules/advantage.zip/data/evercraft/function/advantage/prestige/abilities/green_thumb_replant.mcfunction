# Green Thumb — Replant 5x5 grid with the inferred crop type
# Macro arg: gt_crop (e.g. minecraft:wheat / carrots / potatoes / beetroots)
# Called from green_thumb.mcfunction at player position after crop-type inference
# 2026-05-28 (W5.3): preserves player-farmed crop type (was hard-coded wheat)

$execute positioned ~-2 ~-1 ~-2 if block ~ ~ ~ farmland if block ~ ~1 ~ air run setblock ~ ~1 ~ $(gt_crop)[age=0]
$execute positioned ~-1 ~-1 ~-2 if block ~ ~ ~ farmland if block ~ ~1 ~ air run setblock ~ ~1 ~ $(gt_crop)[age=0]
$execute positioned ~ ~-1 ~-2 if block ~ ~ ~ farmland if block ~ ~1 ~ air run setblock ~ ~1 ~ $(gt_crop)[age=0]
$execute positioned ~1 ~-1 ~-2 if block ~ ~ ~ farmland if block ~ ~1 ~ air run setblock ~ ~1 ~ $(gt_crop)[age=0]
$execute positioned ~2 ~-1 ~-2 if block ~ ~ ~ farmland if block ~ ~1 ~ air run setblock ~ ~1 ~ $(gt_crop)[age=0]

$execute positioned ~-2 ~-1 ~-1 if block ~ ~ ~ farmland if block ~ ~1 ~ air run setblock ~ ~1 ~ $(gt_crop)[age=0]
$execute positioned ~-1 ~-1 ~-1 if block ~ ~ ~ farmland if block ~ ~1 ~ air run setblock ~ ~1 ~ $(gt_crop)[age=0]
$execute positioned ~ ~-1 ~-1 if block ~ ~ ~ farmland if block ~ ~1 ~ air run setblock ~ ~1 ~ $(gt_crop)[age=0]
$execute positioned ~1 ~-1 ~-1 if block ~ ~ ~ farmland if block ~ ~1 ~ air run setblock ~ ~1 ~ $(gt_crop)[age=0]
$execute positioned ~2 ~-1 ~-1 if block ~ ~ ~ farmland if block ~ ~1 ~ air run setblock ~ ~1 ~ $(gt_crop)[age=0]

$execute positioned ~-2 ~-1 ~ if block ~ ~ ~ farmland if block ~ ~1 ~ air run setblock ~ ~1 ~ $(gt_crop)[age=0]
$execute positioned ~-1 ~-1 ~ if block ~ ~ ~ farmland if block ~ ~1 ~ air run setblock ~ ~1 ~ $(gt_crop)[age=0]
$execute positioned ~ ~-1 ~ if block ~ ~ ~ farmland if block ~ ~1 ~ air run setblock ~ ~1 ~ $(gt_crop)[age=0]
$execute positioned ~1 ~-1 ~ if block ~ ~ ~ farmland if block ~ ~1 ~ air run setblock ~ ~1 ~ $(gt_crop)[age=0]
$execute positioned ~2 ~-1 ~ if block ~ ~ ~ farmland if block ~ ~1 ~ air run setblock ~ ~1 ~ $(gt_crop)[age=0]

$execute positioned ~-2 ~-1 ~1 if block ~ ~ ~ farmland if block ~ ~1 ~ air run setblock ~ ~1 ~ $(gt_crop)[age=0]
$execute positioned ~-1 ~-1 ~1 if block ~ ~ ~ farmland if block ~ ~1 ~ air run setblock ~ ~1 ~ $(gt_crop)[age=0]
$execute positioned ~ ~-1 ~1 if block ~ ~ ~ farmland if block ~ ~1 ~ air run setblock ~ ~1 ~ $(gt_crop)[age=0]
$execute positioned ~1 ~-1 ~1 if block ~ ~ ~ farmland if block ~ ~1 ~ air run setblock ~ ~1 ~ $(gt_crop)[age=0]
$execute positioned ~2 ~-1 ~1 if block ~ ~ ~ farmland if block ~ ~1 ~ air run setblock ~ ~1 ~ $(gt_crop)[age=0]

$execute positioned ~-2 ~-1 ~2 if block ~ ~ ~ farmland if block ~ ~1 ~ air run setblock ~ ~1 ~ $(gt_crop)[age=0]
$execute positioned ~-1 ~-1 ~2 if block ~ ~ ~ farmland if block ~ ~1 ~ air run setblock ~ ~1 ~ $(gt_crop)[age=0]
$execute positioned ~ ~-1 ~2 if block ~ ~ ~ farmland if block ~ ~1 ~ air run setblock ~ ~1 ~ $(gt_crop)[age=0]
$execute positioned ~1 ~-1 ~2 if block ~ ~ ~ farmland if block ~ ~1 ~ air run setblock ~ ~1 ~ $(gt_crop)[age=0]
$execute positioned ~2 ~-1 ~2 if block ~ ~ ~ farmland if block ~ ~1 ~ air run setblock ~ ~1 ~ $(gt_crop)[age=0]
