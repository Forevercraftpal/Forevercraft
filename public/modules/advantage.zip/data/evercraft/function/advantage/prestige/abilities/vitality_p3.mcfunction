# Prestige Ability: Iron Will — permanent Resistance I
# Applied via reapply_all (effect give resistance infinite)
effect give @s minecraft:resistance infinite 0 true
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"Iron Will",color:"green"},{text:" — You gain permanent Resistance I!",color:"gray"},{text:" ✦",color:"gold"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.player.levelup master @s ~ ~ ~ 1 1.2
