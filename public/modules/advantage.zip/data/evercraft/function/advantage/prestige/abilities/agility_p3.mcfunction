# Prestige Ability: Dash — teleport 10 blocks forward (30s cooldown)
# Already hooked in tick/main (sprint+sneak detection, cooldown adv.pa_agil3_cd)
scoreboard players set @s adv.pa_agil3 1
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"Dash",color:"green"},{text:" — Sprint + sneak to dash 10 blocks forward! 30s cooldown.",color:"gray"},{text:" ✦",color:"gold"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.player.levelup master @s ~ ~ ~ 1 1.2
