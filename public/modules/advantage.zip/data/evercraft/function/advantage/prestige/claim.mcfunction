# Prestige — Claim an EARNED (banked) prestige (Joseph 2026-06-02)
# Run as @s. Routed from advantage/triggers via the [Claim ▸] chat button (/trigger adv.pclaim
# set <tree_id>). A questline capstone banked this prestige (adv.pbank_<tree>); the player chose
# WHEN to claim it. Bypasses the level-25 gate (it was EARNED), but respects the 3-prestige cap
# (do_prestige self-caps). Consumes exactly one bank for the selected tree.

# Tree id the button claimed (2 dext / 9 fish / 12 blac / 14 culi / 15 chem).
scoreboard players operation #pres_tree adv.temp = @s adv.pclaim

# Read this tree's banked count (only the 5 questline trees can bank; others stay 0).
scoreboard players set #pres_bank adv.temp 0
execute if score #pres_tree adv.temp matches 2 run scoreboard players operation #pres_bank adv.temp = @s adv.pbank_dext
execute if score #pres_tree adv.temp matches 9 run scoreboard players operation #pres_bank adv.temp = @s adv.pbank_fish
execute if score #pres_tree adv.temp matches 12 run scoreboard players operation #pres_bank adv.temp = @s adv.pbank_blac
execute if score #pres_tree adv.temp matches 14 run scoreboard players operation #pres_bank adv.temp = @s adv.pbank_culi
execute if score #pres_tree adv.temp matches 15 run scoreboard players operation #pres_bank adv.temp = @s adv.pbank_chem

# Nothing banked for this tree? bail silently (the button only shows when bank >= 1).
execute if score #pres_bank adv.temp matches ..0 run return 0

# Consume one bank for this tree (do this BEFORE do_prestige so a mid-call error can't double-spend).
execute if score #pres_tree adv.temp matches 2 run scoreboard players remove @s adv.pbank_dext 1
execute if score #pres_tree adv.temp matches 9 run scoreboard players remove @s adv.pbank_fish 1
execute if score #pres_tree adv.temp matches 12 run scoreboard players remove @s adv.pbank_blac 1
execute if score #pres_tree adv.temp matches 14 run scoreboard players remove @s adv.pbank_culi 1
execute if score #pres_tree adv.temp matches 15 run scoreboard players remove @s adv.pbank_chem 1

# Seed #pres_current with the tree's CURRENT prestige (do_prestige re-derives it after +1, but the
# feedback path reads it). do_prestige resets the tree to Lv.1, +1 prestige, retained bonus, ability.
# Zero FIRST: post-Pioneer-wipe adv.pres_<tree> can be ABSENT (strip never re-sets pres scores), so
# the gated `= @s` FAILS and #pres_current keeps a PRIOR claim's value (stale) → wrong star-count
# in the prestige feedback toast. Init to 0 so a missing entry reads as prestige 0.
scoreboard players set #pres_current adv.temp 0
execute if score #pres_tree adv.temp matches 2 run scoreboard players operation #pres_current adv.temp = @s adv.pres_dext
execute if score #pres_tree adv.temp matches 9 run scoreboard players operation #pres_current adv.temp = @s adv.pres_fish
execute if score #pres_tree adv.temp matches 12 run scoreboard players operation #pres_current adv.temp = @s adv.pres_blac
execute if score #pres_tree adv.temp matches 14 run scoreboard players operation #pres_current adv.temp = @s adv.pres_culi
execute if score #pres_tree adv.temp matches 15 run scoreboard players operation #pres_current adv.temp = @s adv.pres_chem

function evercraft:advantage/prestige/do_prestige
