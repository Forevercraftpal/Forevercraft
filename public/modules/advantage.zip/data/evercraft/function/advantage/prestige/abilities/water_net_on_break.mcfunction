# Water Net — On Break (barrel block removed)
# Run as: the WaterNet marker at the barrel position
# Barrel contents are already dropped by vanilla when barrel is broken

# Kill any vanilla barrel item drop (prevent plain barrel from dropping)
kill @e[type=item,nbt={Item:{id:"minecraft:barrel"}},distance=..2]

# Drop the Water Net item (with custom name, glint, lore, custom_data)
loot spawn ~ ~0.5 ~ loot evercraft:advantage/water_net_drop

# Notify nearby players
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"A Water Net",color:"aqua"},{text:" was retrieved.",color:"gray"},{text:" ✦",color:"gold"}]
scoreboard players set #ndur ec.temp 45
execute at @s as @a[distance=..32] run function evercraft:util/notify/emit
playsound minecraft:block.note_block.chime master @a[distance=..32,scores={ec.fx_snd=1..}] ~ ~ ~ 0.5 1.5

# Particles
particle minecraft:splash ~ ~0.5 ~ 0.3 0.3 0.3 0.3 8
particle minecraft:bubble ~ ~0.5 ~ 0.3 0.3 0.3 0.02 5

# Kill overlay display entities
kill @e[type=armor_stand,tag=WaterNet.stand,distance=..1]
kill @e[type=item_display,tag=WaterNet.display,distance=..1]

# Kill this marker
kill @s
