# Prestige Ability: Ore Doubling — mining ore has a chance to double drops
scoreboard players set @s adv.pa_mine2 1
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"Ore Doubling",color:"green"},{text:" — Mining ore has a chance to double the drops!",color:"gray"},{text:" ✦",color:"gold"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
