# Prestige Ability: Double Jump — brief vertical boost (15s cooldown)
# Already hooked in tick/main (cooldown decrement for adv.pa_agil2_cd, sneak+airborne detection)
scoreboard players set @s adv.pa_agil2 1
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"Double Jump",color:"green"},{text:" — Sneak while airborne for a vertical boost! 15s cooldown.",color:"gray"},{text:" ✦",color:"gold"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.player.levelup master @s ~ ~ ~ 1 1.2
