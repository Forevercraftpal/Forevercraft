# Prestige Ability: Auto-Smelt — ores drop smelted form when mined
scoreboard players set @s adv.pa_blac3 1
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"Auto-Smelt",color:"green"},{text:" — Ores automatically drop their smelted form!",color:"gray"},{text:" ✦",color:"gold"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
