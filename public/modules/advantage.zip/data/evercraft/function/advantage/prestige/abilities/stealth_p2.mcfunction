# Prestige Ability: Backstab — +50% melee damage while sneaking
# Already hooked in stealth_apply.mcfunction (attribute modifier evercraft:adv_pres_backstab)
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"Backstab",color:"green"},{text:" — Deal 50% more melee damage while sneaking!",color:"gray"},{text:" ✦",color:"gold"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.player.levelup master @s ~ ~ ~ 1 1.2
