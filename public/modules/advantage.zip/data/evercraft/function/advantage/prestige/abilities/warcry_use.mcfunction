# Beastmaster P3: War Cry — buff all wolves in 32 blocks for 30s
# Triggered via /trigger adv.warcry set 1

# Check unlock
data modify storage evercraft:notify stage.c set value [{text:"You haven't unlocked War Cry yet!",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute unless score @s adv.pa_beas3 matches 1 run return run function evercraft:util/notify/emit

# Check cooldown (300s = 15000 ticks at 20t/cycle = 15000 raw ticks)
data modify storage evercraft:notify stage.c set value [{text:"War Cry is on cooldown!",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute if score @s adv.pa_beas3_cd matches 1.. run return run function evercraft:util/notify/emit

# 5-minute cooldown. wolf_tick runs every 20t (=1s) and decrements by 1, so 300 = 300s.
scoreboard players set @s adv.pa_beas3_cd 300

# Apply Speed II + Strength II to all wolves within 32 blocks for 30 seconds
execute at @s run effect give @e[type=wolf,distance=..32] minecraft:speed 30 1 false
execute at @s run effect give @e[type=wolf,distance=..32] minecraft:strength 30 1 false
execute at @s run effect give @e[type=fox,distance=..32,tag=ec.fox_tamed] minecraft:speed 30 1 false
execute at @s run effect give @e[type=fox,distance=..32,tag=ec.fox_tamed] minecraft:strength 30 1 false

# Visual + audio feedback
execute at @s run particle minecraft:angry_villager ~ ~1 ~ 2 1 2 0.1 10
execute at @s run playsound minecraft:entity.wolf.howl master @a[scores={ec.fx_snd=1..}] ~ ~ ~ 2 0.6
execute at @s if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.ender_dragon.growl master @s ~ ~ ~ 0.5 1.8
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"Your wolves surge with power! Speed II + Strength II for 30s",color:"yellow"},{text:" ✦",color:"gold"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
