# Culinary P2: Double Portion — 15% free cook chance
# Activated on prestige 2, flag checked during cooking
scoreboard players set @s adv.pa_culi2 1
data modify storage evercraft:notify stage.c set value [{text:"★★ ",color:"gold"},{text:"Double Portion",color:"green",bold:true},{text:" unlocked! 15% chance to cook for free.",color:"gray"},{text:" ★★",color:"gold"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
