# Prestige Ability: Pack Tactics — nearby wolves get Strength I + Resistance I aura
# Wolf tick checks adv.pres_beas matches 2.. to apply effects within 16 blocks
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"Pack Tactics",color:"green"},{text:" — Your wolves gain Strength I + Resistance I within 16 blocks!",color:"gray"},{text:" ✦",color:"gold"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.player.levelup master @s ~ ~ ~ 1 1.2
