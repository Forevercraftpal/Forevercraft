# Prestige Ability: Quest Mastery — quest rewards +25%
# Flag checked by quest reward system to apply bonus
scoreboard players set @s adv.pa_task1 1
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"Quest Mastery",color:"green"},{text:" — Quest rewards increased by 25%!",color:"gray"},{text:" ✦",color:"gold"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.player.levelup master @s ~ ~ ~ 1 1.2
