# Prestige Ability: Ancient Ore — ultra-rare drop worth netherite or tokens
scoreboard players set @s adv.pa_mine3 1
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"Ancient Ore",color:"green"},{text:" — Ultra-rare drop worth 3 netherite or 20 tokens!",color:"gray"},{text:" ✦",color:"gold"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.player.levelup master @s ~ ~ ~ 1 1.2
