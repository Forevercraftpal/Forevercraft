# Prestige Ability: Perfect Stealth — passive +50% dodge chance vs melee while sneaking
# Passive form (active double-tap form deferred per AU5-XB.1)
# Wiring: pres_stea=3 read by tick/stealth_tick + effects/stealth_apply for passive bonuses
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"Perfect Stealth",color:"green"},{text:" — while sneaking, +25% dodge chance against melee.",color:"gray"},{text:" ✦",color:"gold"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.player.levelup master @s ~ ~ ~ 1 1.2
