# Prestige Ability: Alpha Bond — companions deal +25% damage
# The prestige score adv.pres_beas being 1+ is enough for the companion system to check
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"Alpha Bond",color:"green"},{text:" — Your companions deal 25% more damage!",color:"gray"},{text:" ✦",color:"gold"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.player.levelup master @s ~ ~ ~ 1 1.2
