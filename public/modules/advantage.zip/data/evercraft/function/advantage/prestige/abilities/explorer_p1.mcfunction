# Prestige Ability: Structure Sense — alert when within 100 blocks of a structure
scoreboard players set @s adv.pa_expl1 1
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"Structure Sense",color:"green"},{text:" — Alert when within 100 blocks of a structure!",color:"gray"},{text:" ✦",color:"gold"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.player.levelup master @s ~ ~ ~ 1 1.2
