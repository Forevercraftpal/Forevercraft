# Prestige Ability: Green Thumb — crops auto-replant on harvest
scoreboard players set @s adv.pa_gath1 1
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"Green Thumb",color:"green"},{text:" — Crops auto-replant on harvest!",color:"gray"},{text:" ✦",color:"gold"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.player.levelup master @s ~ ~ ~ 1 1.2
