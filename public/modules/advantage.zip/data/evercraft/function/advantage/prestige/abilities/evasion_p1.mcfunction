# Prestige Ability: Shadow Counter — teleport behind attacker on dodge
# Already hooked in evasion_dodge.mcfunction (checks adv.pres_evas matches 1..)
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"Shadow Counter",color:"green"},{text:" — Dodging teleports you behind the nearest attacker!",color:"gray"},{text:" ✦",color:"gold"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.player.levelup master @s ~ ~ ~ 1 1.2
