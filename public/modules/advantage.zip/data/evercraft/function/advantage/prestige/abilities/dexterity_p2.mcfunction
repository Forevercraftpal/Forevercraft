# Prestige Ability: Dual Wield — +25% attack speed when dual-wielding
attribute @s attack_speed modifier remove evercraft:adv_pres_dex2
attribute @s attack_speed modifier add evercraft:adv_pres_dex2 0.25 add_multiplied_base
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"Dual Wield",color:"green"},{text:" — +25% attack speed when dual-wielding!",color:"gray"},{text:" ✦",color:"gold"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.player.levelup master @s ~ ~ ~ 1 1.2
