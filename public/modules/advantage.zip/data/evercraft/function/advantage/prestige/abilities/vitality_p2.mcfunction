# Prestige Ability: Death Save — auto-heal when critically low HP (30min cooldown)
# Already hooked in tick/main (calls death_save_trigger when adv.pres_vita=2+ and adv.pa_vita2_cd=0)
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"Death Save",color:"green"},{text:" — Automatically heal when below 2 hearts! 30min cooldown.",color:"gray"},{text:" ✦",color:"gold"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.player.levelup master @s ~ ~ ~ 1 1.2
