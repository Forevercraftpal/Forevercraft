# ID 44 (Master Chef): Cook 100 meals (stat_cook delta)
execute if score @s adv.chal_id matches 44 run scoreboard players operation #delta adv.temp = @s adv.stat_cook
execute if score @s adv.chal_id matches 44 run scoreboard players operation #delta adv.temp -= @s adv.chal_prog
execute if score @s adv.chal_id matches 44 if score #delta adv.temp matches 75.. if score @s adv.chal_75 matches 0 run function evercraft:advantage/challenges/notify_75
execute if score @s adv.chal_id matches 44 if score #delta adv.temp matches 100.. run function evercraft:advantage/challenges/complete

# ID 45 (Campfire Sage): Cook 200 campfire items (stat_campfire delta)
execute if score @s adv.chal_id matches 45 run scoreboard players operation #delta adv.temp = @s adv.stat_campfire
execute if score @s adv.chal_id matches 45 run scoreboard players operation #delta adv.temp -= @s adv.chal_prog
execute if score @s adv.chal_id matches 45 if score #delta adv.temp matches 150.. if score @s adv.chal_75 matches 0 run function evercraft:advantage/challenges/notify_75
execute if score @s adv.chal_id matches 45 if score #delta adv.temp matches 200.. run function evercraft:advantage/challenges/complete
