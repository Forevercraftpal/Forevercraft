# Challenge Triggers
# Parent gate in advantage/triggers.mcfunction:47-48 only routes -1 / 1..17, so the
# `matches 0` branch was dead. Removed 2026-05-28 (W5.5). View-menu opens via the GUI.
scoreboard players operation #chal_val adv.temp = @s adv.challenge

# Cancel active challenge
execute if score #chal_val adv.temp matches -1 run function evercraft:advantage/challenges/cancel

# Accept challenge (1-17 base + 44-47 Culinary/Chemistry direct-accept)
execute if score #chal_val adv.temp matches 1..17 run function evercraft:advantage/challenges/accept
execute if score #chal_val adv.temp matches 44..47 run function evercraft:advantage/challenges/accept
