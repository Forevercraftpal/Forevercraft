# Weekly Challenge Announcement Display — Macro
$data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold",bold:true},{text:"Weekly Challenge: ",color:"yellow"},{text:"$(weekly_name)",color:"gold",bold:true},{text:" ✦",color:"gold",bold:true}]
scoreboard players set #ndur ec.temp 50
execute as @a run function evercraft:util/notify/emit
$data modify storage evercraft:notify stage.c set value [{text:"Complete any ",color:"gray"},{text:"$(weekly_name)",color:"gold"},{text:" challenge for bonus rewards!",color:"gray"}]
scoreboard players set #ndur ec.temp 40
execute as @a run function evercraft:util/notify/emit
