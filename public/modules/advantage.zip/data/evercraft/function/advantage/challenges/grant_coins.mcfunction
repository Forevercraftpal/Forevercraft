$scoreboard players add @s ec.coins $(chal_coins)
$scoreboard players add #rm_coins ec.var $(chal_coins)
$data modify storage evercraft:notify stage.c set value [{text:"★ ",color:"#E0B0FF"},{text:"+$(chal_coins) Forever Coins",color:"#E0B0FF"},{text:" ★",color:"#E0B0FF"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
