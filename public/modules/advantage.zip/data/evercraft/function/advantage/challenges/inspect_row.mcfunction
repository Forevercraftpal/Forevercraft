# Challenges — Inspect row (left-click info card; gui/inspect pattern 2026-06-11)
# Joseph: "challenges should tell you what the challenge requires and what progress
# youve made if you choose one, on left click."
# Run as: the PLAYER (via `on attacker`). Macro: row 0-12 (same map as click_challenge).
# Requirements/rewards mirror list_all (the canonical reference the [?] button prints);
# progress reuses show_progress_calc (#progress/#goal adv.temp — dailies AND ★ weeklies).

$scoreboard players set #insp_row adv.temp $(row)

execute if score @s ec.fx_snd matches 1.. at @s run playsound minecraft:block.note_block.hat master @s ~ ~ ~ 0.3 2

execute if score #insp_row adv.temp matches 0 run tellraw @s [{text:"[",color:"dark_gray"},{text:"?",color:"gold"},{text:"] ",color:"dark_gray"},{text:"── ",color:"dark_gray"},{text:"Agility Challenge",color:"gold",bold:true},{text:" ──",color:"dark_gray"}]
execute if score #insp_row adv.temp matches 0 run tellraw @s [{text:"  One of two is assigned at random on accept:",color:"dark_gray",italic:true}]
execute if score #insp_row adv.temp matches 0 run tellraw @s [{text:"  Marathon",color:"white"},{text:" — Walk 10,000 blocks",color:"gray"},{text:" (100 XP + 10 tokens)",color:"dark_gray"}]
execute if score #insp_row adv.temp matches 0 run tellraw @s [{text:"  Speedster",color:"white"},{text:" — Sprint 60s nonstop",color:"gray"},{text:" (15 XP + 1 token)",color:"dark_gray"}]

execute if score #insp_row adv.temp matches 1 run tellraw @s [{text:"[",color:"dark_gray"},{text:"?",color:"gold"},{text:"] ",color:"dark_gray"},{text:"── ",color:"dark_gray"},{text:"Dexterity Challenge",color:"gold",bold:true},{text:" ──",color:"dark_gray"}]
execute if score #insp_row adv.temp matches 1 run tellraw @s [{text:"  Marksman",color:"white"},{text:" — Land 50 attacks on mobs",color:"gray"},{text:" (30 XP + 3 tokens)",color:"dark_gray"}]

execute if score #insp_row adv.temp matches 2 run tellraw @s [{text:"[",color:"dark_gray"},{text:"?",color:"gold"},{text:"] ",color:"dark_gray"},{text:"── ",color:"dark_gray"},{text:"Evasion Challenge",color:"gold",bold:true},{text:" ──",color:"dark_gray"}]
execute if score #insp_row adv.temp matches 2 run tellraw @s [{text:"  One of two is assigned at random on accept:",color:"dark_gray",italic:true}]
execute if score #insp_row adv.temp matches 2 run tellraw @s [{text:"  Ghost",color:"white"},{text:" — Dodge 50 attacks",color:"gray"},{text:" (77 XP + 7 tokens)",color:"dark_gray"}]
execute if score #insp_row adv.temp matches 2 run tellraw @s [{text:"  Untouched",color:"white"},{text:" — No damage for 10 min",color:"gray"},{text:" (30 XP + 3 tokens)",color:"dark_gray"}]

execute if score #insp_row adv.temp matches 3 run tellraw @s [{text:"[",color:"dark_gray"},{text:"?",color:"gold"},{text:"] ",color:"dark_gray"},{text:"── ",color:"dark_gray"},{text:"Stealth Challenge",color:"gold",bold:true},{text:" ──",color:"dark_gray"}]
execute if score #insp_row adv.temp matches 3 run tellraw @s [{text:"  Phantom",color:"white"},{text:" — Sneak 5,000 blocks",color:"gray"},{text:" (50 XP + 5 tokens)",color:"dark_gray"}]

execute if score #insp_row adv.temp matches 4 run tellraw @s [{text:"[",color:"dark_gray"},{text:"?",color:"gold"},{text:"] ",color:"dark_gray"},{text:"── ",color:"dark_gray"},{text:"Vitality Challenge",color:"gold",bold:true},{text:" ──",color:"dark_gray"}]
execute if score #insp_row adv.temp matches 4 run tellraw @s [{text:"  One of two is assigned at random on accept:",color:"dark_gray",italic:true}]
execute if score #insp_row adv.temp matches 4 run tellraw @s [{text:"  Tank",color:"white"},{text:" — Take 200 damage",color:"gray"},{text:" (50 XP + 5 tokens)",color:"dark_gray"}]
execute if score #insp_row adv.temp matches 4 run tellraw @s [{text:"  Deathless",color:"white"},{text:" — Do not die for 7 days",color:"gray"},{text:" (77 XP + 7 tokens)",color:"dark_gray"}]

execute if score #insp_row adv.temp matches 5 run tellraw @s [{text:"[",color:"dark_gray"},{text:"?",color:"gold"},{text:"] ",color:"dark_gray"},{text:"── ",color:"dark_gray"},{text:"Taskmaster Challenge",color:"gold",bold:true},{text:" ──",color:"dark_gray"}]
execute if score #insp_row adv.temp matches 5 run tellraw @s [{text:"  Grinder",color:"white"},{text:" — Complete 25 quests",color:"gray"},{text:" (100 XP + 10 tokens)",color:"dark_gray"}]

execute if score #insp_row adv.temp matches 6 run tellraw @s [{text:"[",color:"dark_gray"},{text:"?",color:"gold"},{text:"] ",color:"dark_gray"},{text:"── ",color:"dark_gray"},{text:"Beastmaster Challenge",color:"gold",bold:true},{text:" ──",color:"dark_gray"}]
execute if score #insp_row adv.temp matches 6 run tellraw @s [{text:"  Pack Alpha",color:"white"},{text:" — Max 3 pets",color:"gray"},{text:" (50 XP + 5 tokens)",color:"dark_gray"}]

execute if score #insp_row adv.temp matches 7 run tellraw @s [{text:"[",color:"dark_gray"},{text:"?",color:"gold"},{text:"] ",color:"dark_gray"},{text:"── ",color:"dark_gray"},{text:"Victorian Challenge",color:"gold",bold:true},{text:" ──",color:"dark_gray"}]
execute if score #insp_row adv.temp matches 7 run tellraw @s [{text:"  Slayer",color:"white"},{text:" — Kill 500 mobs",color:"gray"},{text:" (100 XP + 10 tokens)",color:"dark_gray"}]

execute if score #insp_row adv.temp matches 8 run tellraw @s [{text:"[",color:"dark_gray"},{text:"?",color:"gold"},{text:"] ",color:"dark_gray"},{text:"── ",color:"dark_gray"},{text:"Fishing Challenge",color:"gold",bold:true},{text:" ──",color:"dark_gray"}]
execute if score #insp_row adv.temp matches 8 run tellraw @s [{text:"  Perfect Cast",color:"white"},{text:" — Catch 100 fish",color:"gray"},{text:" (15 XP + 1 token)",color:"dark_gray"}]

execute if score #insp_row adv.temp matches 9 run tellraw @s [{text:"[",color:"dark_gray"},{text:"?",color:"gold"},{text:"] ",color:"dark_gray"},{text:"── ",color:"dark_gray"},{text:"Mining Challenge",color:"gold",bold:true},{text:" ──",color:"dark_gray"}]
execute if score #insp_row adv.temp matches 9 run tellraw @s [{text:"  One of two is assigned at random on accept:",color:"dark_gray",italic:true}]
execute if score #insp_row adv.temp matches 9 run tellraw @s [{text:"  Deep Core",color:"white"},{text:" — Mine 5,000 blocks",color:"gray"},{text:" (100 XP + 10 tokens)",color:"dark_gray"}]
execute if score #insp_row adv.temp matches 9 run tellraw @s [{text:"  Fortunate",color:"white"},{text:" — Mine 500 ores",color:"gray"},{text:" (15 XP + 1 token)",color:"dark_gray"}]

execute if score #insp_row adv.temp matches 10 run tellraw @s [{text:"[",color:"dark_gray"},{text:"?",color:"gold"},{text:"] ",color:"dark_gray"},{text:"── ",color:"dark_gray"},{text:"Gathering Challenge",color:"gold",bold:true},{text:" ──",color:"dark_gray"}]
execute if score #insp_row adv.temp matches 10 run tellraw @s [{text:"  Green Thumb",color:"white"},{text:" — Harvest 1,000 crops",color:"gray"},{text:" (50 XP + 5 tokens)",color:"dark_gray"}]

execute if score #insp_row adv.temp matches 11 run tellraw @s [{text:"[",color:"dark_gray"},{text:"?",color:"gold"},{text:"] ",color:"dark_gray"},{text:"── ",color:"dark_gray"},{text:"Blacksmith Challenge",color:"gold",bold:true},{text:" ──",color:"dark_gray"}]
execute if score #insp_row adv.temp matches 11 run tellraw @s [{text:"  Iron Chef",color:"white"},{text:" — Smelt 500 items",color:"gray"},{text:" (50 XP + 5 tokens)",color:"dark_gray"}]

execute if score #insp_row adv.temp matches 12 run tellraw @s [{text:"[",color:"dark_gray"},{text:"?",color:"gold"},{text:"] ",color:"dark_gray"},{text:"── ",color:"dark_gray"},{text:"Expeditionist Challenge",color:"gold",bold:true},{text:" ──",color:"dark_gray"}]
execute if score #insp_row adv.temp matches 12 run tellraw @s [{text:"  Cartographer",color:"white"},{text:" — Find 10 structure crates",color:"gray"},{text:" (50 XP + 5 tokens)",color:"dark_gray"}]

# Does the active challenge belong to this row? (its daily id(s) + the tree's ★ weekly pair)
scoreboard players set #insp_match adv.temp 0
execute if score #insp_row adv.temp matches 0 if score @s adv.chal_id matches 1..2 run scoreboard players set #insp_match adv.temp 1
execute if score #insp_row adv.temp matches 0 if score @s adv.chal_id matches 18..19 run scoreboard players set #insp_match adv.temp 1
execute if score #insp_row adv.temp matches 1 if score @s adv.chal_id matches 3 run scoreboard players set #insp_match adv.temp 1
execute if score #insp_row adv.temp matches 1 if score @s adv.chal_id matches 20..21 run scoreboard players set #insp_match adv.temp 1
execute if score #insp_row adv.temp matches 2 if score @s adv.chal_id matches 4..5 run scoreboard players set #insp_match adv.temp 1
execute if score #insp_row adv.temp matches 2 if score @s adv.chal_id matches 22..23 run scoreboard players set #insp_match adv.temp 1
execute if score #insp_row adv.temp matches 3 if score @s adv.chal_id matches 6 run scoreboard players set #insp_match adv.temp 1
execute if score #insp_row adv.temp matches 3 if score @s adv.chal_id matches 24..25 run scoreboard players set #insp_match adv.temp 1
execute if score #insp_row adv.temp matches 4 if score @s adv.chal_id matches 7..8 run scoreboard players set #insp_match adv.temp 1
execute if score #insp_row adv.temp matches 4 if score @s adv.chal_id matches 26..27 run scoreboard players set #insp_match adv.temp 1
execute if score #insp_row adv.temp matches 5 if score @s adv.chal_id matches 9 run scoreboard players set #insp_match adv.temp 1
execute if score #insp_row adv.temp matches 5 if score @s adv.chal_id matches 28..29 run scoreboard players set #insp_match adv.temp 1
execute if score #insp_row adv.temp matches 6 if score @s adv.chal_id matches 10 run scoreboard players set #insp_match adv.temp 1
execute if score #insp_row adv.temp matches 6 if score @s adv.chal_id matches 30..31 run scoreboard players set #insp_match adv.temp 1
execute if score #insp_row adv.temp matches 7 if score @s adv.chal_id matches 11 run scoreboard players set #insp_match adv.temp 1
execute if score #insp_row adv.temp matches 7 if score @s adv.chal_id matches 32..33 run scoreboard players set #insp_match adv.temp 1
execute if score #insp_row adv.temp matches 8 if score @s adv.chal_id matches 12 run scoreboard players set #insp_match adv.temp 1
execute if score #insp_row adv.temp matches 8 if score @s adv.chal_id matches 34..35 run scoreboard players set #insp_match adv.temp 1
execute if score #insp_row adv.temp matches 9 if score @s adv.chal_id matches 13..14 run scoreboard players set #insp_match adv.temp 1
execute if score #insp_row adv.temp matches 9 if score @s adv.chal_id matches 36..37 run scoreboard players set #insp_match adv.temp 1
execute if score #insp_row adv.temp matches 10 if score @s adv.chal_id matches 15 run scoreboard players set #insp_match adv.temp 1
execute if score #insp_row adv.temp matches 10 if score @s adv.chal_id matches 38..39 run scoreboard players set #insp_match adv.temp 1
execute if score #insp_row adv.temp matches 11 if score @s adv.chal_id matches 16 run scoreboard players set #insp_match adv.temp 1
execute if score #insp_row adv.temp matches 11 if score @s adv.chal_id matches 40..41 run scoreboard players set #insp_match adv.temp 1
execute if score #insp_row adv.temp matches 12 if score @s adv.chal_id matches 17 run scoreboard players set #insp_match adv.temp 1
execute if score #insp_row adv.temp matches 12 if score @s adv.chal_id matches 42..43 run scoreboard players set #insp_match adv.temp 1

# Live progress when this row's challenge is the active one (★ weeklies included)
execute if score #insp_match adv.temp matches 1 run function evercraft:advantage/challenges/show_progress_calc
execute if score #insp_match adv.temp matches 1 if score @s adv.chal_id matches 1..17 run tellraw @s [{text:"  Your progress: ",color:"gray"},{score:{name:"#progress",objective:"adv.temp"},color:"gold"},{text:"/",color:"gray"},{score:{name:"#goal",objective:"adv.temp"},color:"gold"}]
execute if score #insp_match adv.temp matches 1 if score @s adv.chal_id matches 18.. run tellraw @s [{text:"  Your progress: ",color:"gray"},{score:{name:"#progress",objective:"adv.temp"},color:"gold"},{text:"/",color:"gray"},{score:{name:"#goal",objective:"adv.temp"},color:"gold"},{text:" ★ weekly",color:"gold"}]

# Footers — what a right-click would do from here
execute if score #insp_match adv.temp matches 0 if score @s adv.chal_id matches 1.. run tellraw @s [{text:"  A different challenge is active — finish or cancel it first. Cancelling locks challenges for 1 day.",color:"dark_gray",italic:true}]
execute unless score @s adv.chal_id matches 1.. run tellraw @s [{text:"  Right-click to accept this challenge.",color:"dark_gray",italic:true}]
