# Challenge 75% Milestone Notification — one-time actionbar
scoreboard players set @s adv.chal_75 1
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"Challenge 75% complete!",color:"yellow"},{text:" Almost there!",color:"gray"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.chime master @s ~ ~ ~ 0.5 1.5
