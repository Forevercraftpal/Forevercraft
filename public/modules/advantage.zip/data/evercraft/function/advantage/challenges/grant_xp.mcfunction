$experience add @s $(chal_xp) levels
$data modify storage evercraft:notify stage.c set value [{text:"+$(chal_xp) XP Levels",color:"green"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
