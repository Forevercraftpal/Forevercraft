# ID 46 (Master Brewer): Brew 50 forevercraft potions (stat_brew delta)
execute if score @s adv.chal_id matches 46 run scoreboard players operation #delta adv.temp = @s adv.stat_brew
execute if score @s adv.chal_id matches 46 run scoreboard players operation #delta adv.temp -= @s adv.chal_prog
execute if score @s adv.chal_id matches 46 if score #delta adv.temp matches 37.. if score @s adv.chal_75 matches 0 run function evercraft:advantage/challenges/notify_75
execute if score @s adv.chal_id matches 46 if score #delta adv.temp matches 50.. run function evercraft:advantage/challenges/complete

# ID 47 (Vanilla Alchemist): Brew 100 vanilla potions (stat_vbrew delta)
execute if score @s adv.chal_id matches 47 run scoreboard players operation #delta adv.temp = @s adv.stat_vbrew
execute if score @s adv.chal_id matches 47 run scoreboard players operation #delta adv.temp -= @s adv.chal_prog
execute if score @s adv.chal_id matches 47 if score #delta adv.temp matches 75.. if score @s adv.chal_75 matches 0 run function evercraft:advantage/challenges/notify_75
execute if score @s adv.chal_id matches 47 if score #delta adv.temp matches 100.. run function evercraft:advantage/challenges/complete
