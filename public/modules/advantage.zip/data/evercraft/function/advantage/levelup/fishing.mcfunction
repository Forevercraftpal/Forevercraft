# Level Up — Fishing
# Improved fishing rewards per level

# Max level check
data modify storage evercraft:notify stage.c set value [{text:"Fishing is already at max level!",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute if score @s adv.fishing matches 25.. run return run function evercraft:util/notify/emit

# Calculate requirements
function evercraft:advantage/calc/fishing

# Read current vanilla XP level
execute store result score @s adv.xp_levels run experience query @s levels

# Check XP
data modify storage evercraft:notify stage.c set value [{text:"Need ",color:"red"},{score:{name:"@s",objective:"adv.req_xp"},color:"gold"},{text:" XP levels to upgrade Fishing. You have ",color:"red"},{score:{name:"@s",objective:"adv.xp_levels"},color:"gold"},{text:" levels.",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute unless score @s adv.xp_levels >= @s adv.req_xp run return run function evercraft:util/notify/emit

# Check stat
data modify storage evercraft:notify stage.c set value [{text:"Need ",color:"red"},{score:{name:"@s",objective:"adv.req_stat"},color:"gold"},{text:" fish caught to upgrade Fishing. You have caught ",color:"red"},{score:{name:"@s",objective:"adv.stat_fish"},color:"gold"},{text:" fish.",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute unless score @s adv.stat_fish >= @s adv.req_stat run return run function evercraft:util/notify/emit

# Deduct XP levels via macro
execute store result storage evercraft:advantage xp_cost int 1 run scoreboard players get @s adv.req_xp
function evercraft:advantage/deduct_xp with storage evercraft:advantage

# Increment level
scoreboard players add @s adv.fishing 1

# Milestone check (tokens + cosmetics)
scoreboard players operation #milestone_check adv.temp = @s adv.fishing
scoreboard players set #milestone_tree adv.temp 9
function evercraft:advantage/tokens/check_milestone
function evercraft:advantage/cosmetics/check_milestones

# Effect is passive/proc-based — no attribute to apply on level-up

# Success — per-level fanfare. SILENCED for questline-banked levels (Joseph 2026-06-01): the Fisher's
# Questline auto-banks advantage-tree Fishing levels in-tick, and this line would announce that
# tree-level — which conflicts with the Sirencall caff level the player watches in the live bar.
# Gate on the ec.fq_silent tag (set by grant_credit_level). Normal GUI level-ups still announce.
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"Fishing leveled up to ",color:"blue"},{score:{name:"@s",objective:"adv.fishing"},color:"gold",bold:true},{text:"!",color:"blue"},{text:" ✦",color:"gold"}]
scoreboard players set #ndur ec.temp 45
execute unless entity @s[tag=ec.fq_silent] run function evercraft:util/notify/emit
execute unless entity @s[tag=ec.fq_silent] if score @s ec.fx_snd matches 1.. run playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 1 1.2

# Max level celebration (realm-wide announcement + fireworks)
execute if score @s adv.fishing matches 25 run function evercraft:advantage/levelup/max_celebration {tree_name:"Fishing"}

# Achievement tracking
scoreboard players add @s ach.total_levels 1
# Inv-full guard: drop at the player's feet rather than void on a full inventory.
execute store result score #inv_full ec.var run function evercraft:util/check_inv_full
execute if score @s ach.total_levels matches 50 unless score @s ec.tome_count matches 1.. if score #inv_full ec.var matches 0 run loot give @s loot evercraft:items/tome_of_lucid_visions
execute if score @s ach.total_levels matches 50 unless score @s ec.tome_count matches 1.. at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:items/tome_of_lucid_visions
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"dark_aqua"},{text:"Tome of Lucid Visions",color:"dark_aqua",bold:true},{text:" received! (+1 Dream Rate)",color:"yellow"},{text:" ✦",color:"dark_aqua"}]
scoreboard players set #ndur ec.temp 45
execute if score @s ach.total_levels matches 50 unless score @s ec.tome_count matches 1.. run function evercraft:util/notify/emit
