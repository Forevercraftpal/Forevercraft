# Advantage Tree Credit — flat progress to all 15 trees on dungeon/raid completion (Joseph 2026-05-29)
# Runs: as @s (a participant). Reads #adv_credit_num ec.var = difficulty factor (dungeon #dg_difficulty
# 1/2/3; raid victory 3). Per-tree credit = mult * factor / 20  (= 5% of a LEVEL-1 requirement at
# factor 1). The per-level requirement grows with level, so the same flat grant shrinks to a tiny %
# at high levels — "scales down monumentally" by design.
# NOTE: Beastmaster (#mult_beastmaster = 1) would floor 1*factor/20 to 0 under the shared formula, so it
# is handled specially below: instead of crediting stat_pets100 (which must stay a PURE count of maxed
# pets for challenges/cosmetics), it banks the raw factor into adv.bm_credit. 20 banked = 1 virtual pet
# that counts toward LEVELING only. See the Beastmaster block (Council #6, 2026-06-02). All other 14
# trees keep the honest integer-math /20 grant unchanged.

# Agility
scoreboard players operation #tcred adv.temp = #mult_agility adv.temp
scoreboard players operation #tcred adv.temp *= #adv_credit_num ec.var
scoreboard players operation #tcred adv.temp /= #20 adv.temp
scoreboard players operation @s adv.stat_walk += #tcred adv.temp

# Dexterity
scoreboard players operation #tcred adv.temp = #mult_dexterity adv.temp
scoreboard players operation #tcred adv.temp *= #adv_credit_num ec.var
scoreboard players operation #tcred adv.temp /= #20 adv.temp
scoreboard players operation @s adv.stat_place += #tcred adv.temp
# CREDIT-TRACK (Joseph 2026-06-08): mirror the credit into adv.cr_* so the milestone counter
# (achievements/sync/player_stats) can subtract it and reflect REAL actions only — credit still
# counts toward the tree level. Fixes lore/dungeon/raid credit firing crops/mining/etc milestones.
scoreboard players operation @s adv.cr_place += #tcred adv.temp

# Evasion
scoreboard players operation #tcred adv.temp = #mult_evasion adv.temp
scoreboard players operation #tcred adv.temp *= #adv_credit_num ec.var
scoreboard players operation #tcred adv.temp /= #20 adv.temp
scoreboard players operation @s adv.stat_hit += #tcred adv.temp

# Stealth
scoreboard players operation #tcred adv.temp = #mult_stealth adv.temp
scoreboard players operation #tcred adv.temp *= #adv_credit_num ec.var
scoreboard players operation #tcred adv.temp /= #20 adv.temp
scoreboard players operation @s adv.stat_crouch += #tcred adv.temp

# Vitality
scoreboard players operation #tcred adv.temp = #mult_vitality adv.temp
scoreboard players operation #tcred adv.temp *= #adv_credit_num ec.var
scoreboard players operation #tcred adv.temp /= #20 adv.temp
scoreboard players operation @s adv.stat_food += #tcred adv.temp
scoreboard players operation @s adv.cr_food += #tcred adv.temp

# Taskmaster
scoreboard players operation #tcred adv.temp = #mult_taskmaster adv.temp
scoreboard players operation #tcred adv.temp *= #adv_credit_num ec.var
scoreboard players operation #tcred adv.temp /= #20 adv.temp
scoreboard players operation @s adv.stat_quests += #tcred adv.temp

# Beastmaster — fractional dungeon/raid/lore credit (Council #6, 2026-06-02). The /20 floor would zero
# out a mult=1 tree, so instead bank the RAW factor (1/2/3) into a dedicated sync-immune reservoir
# adv.bm_credit (one-writer = HERE). 20 banked = 1 virtual pet toward LEVELING; calc/beastmaster folds
# floor(bm_credit/20) into the effective pet-stat. stat_pets100 stays PURE (untouched) so virtual pets
# never satisfy pet-count challenges/cosmetics. Dedicated temp #bm_f keeps the other 14 trees byte-identical.
scoreboard players operation #bm_f adv.temp = #adv_credit_num ec.var
# Virtual-pet count BEFORE this grant (floor(bm_credit/20)) — for the conversion-notify crossing check.
scoreboard players operation #bm_before adv.temp = @s adv.bm_credit
scoreboard players operation #bm_before adv.temp /= #20 adv.temp
scoreboard players operation @s adv.bm_credit += #bm_f adv.temp
# Virtual-pet count AFTER — if it advanced, a hunt has honored a kindred spirit (effective-stat gain).
scoreboard players operation #bm_after adv.temp = @s adv.bm_credit
scoreboard players operation #bm_after adv.temp /= #20 adv.temp
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"Beastmaster ",color:"green",bold:true},{text:"stirs — your hunts have honored a kindred spirit.",color:"white"}]
scoreboard players set #ndur ec.temp 45
execute if score #bm_after adv.temp > #bm_before adv.temp run function evercraft:util/notify/emit

# Victorian
scoreboard players operation #tcred adv.temp = #mult_victorian adv.temp
scoreboard players operation #tcred adv.temp *= #adv_credit_num ec.var
scoreboard players operation #tcred adv.temp /= #20 adv.temp
scoreboard players operation @s adv.stat_mobs += #tcred adv.temp

# Fishing
scoreboard players operation #tcred adv.temp = #mult_fishing adv.temp
scoreboard players operation #tcred adv.temp *= #adv_credit_num ec.var
scoreboard players operation #tcred adv.temp /= #20 adv.temp
scoreboard players operation @s adv.stat_fish += #tcred adv.temp
scoreboard players operation @s adv.cr_fish += #tcred adv.temp

# Mining
scoreboard players operation #tcred adv.temp = #mult_mining adv.temp
scoreboard players operation #tcred adv.temp *= #adv_credit_num ec.var
scoreboard players operation #tcred adv.temp /= #20 adv.temp
scoreboard players operation @s adv.stat_mine += #tcred adv.temp
scoreboard players operation @s adv.cr_mine += #tcred adv.temp

# Gathering
scoreboard players operation #tcred adv.temp = #mult_gathering adv.temp
scoreboard players operation #tcred adv.temp *= #adv_credit_num ec.var
scoreboard players operation #tcred adv.temp /= #20 adv.temp
scoreboard players operation @s adv.stat_harvest += #tcred adv.temp
scoreboard players operation @s adv.cr_harvest += #tcred adv.temp

# Blacksmith
scoreboard players operation #tcred adv.temp = #mult_blacksmith adv.temp
scoreboard players operation #tcred adv.temp *= #adv_credit_num ec.var
scoreboard players operation #tcred adv.temp /= #20 adv.temp
scoreboard players operation @s adv.stat_forge += #tcred adv.temp

# Explorer
scoreboard players operation #tcred adv.temp = #mult_explorer adv.temp
scoreboard players operation #tcred adv.temp *= #adv_credit_num ec.var
scoreboard players operation #tcred adv.temp /= #20 adv.temp
scoreboard players operation @s adv.stat_struct += #tcred adv.temp

# Culinary
scoreboard players operation #tcred adv.temp = #mult_culinary adv.temp
scoreboard players operation #tcred adv.temp *= #adv_credit_num ec.var
scoreboard players operation #tcred adv.temp /= #20 adv.temp
scoreboard players operation @s adv.stat_cook += #tcred adv.temp

# Chemistry
scoreboard players operation #tcred adv.temp = #mult_chemistry adv.temp
scoreboard players operation #tcred adv.temp *= #adv_credit_num ec.var
scoreboard players operation #tcred adv.temp /= #20 adv.temp
scoreboard players operation @s adv.stat_brew += #tcred adv.temp
