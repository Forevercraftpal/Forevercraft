# === ONE-TIME MIGRATION (Joseph 2026-06-08): baseline the credit-trackers ===
# Run as @s (one player). Sets adv.cr_* = adv.stat_* so the PRE-existing untracked tree-credit
# (lore/dungeon/raid, accrued before adv.cr_* tracking existed) drops out of the 5 stat-milestone
# counters: ach.{blocks_mined,fish_caught,crops_harvested,blocks_placed,food_eaten} now read 0 and
# count only REAL actions going forward (the sync subtracts adv.cr_*). Already-CLAIMED milestones
# keep their rewards (claim advancements are untouched); unclaimed progress on these 5 resets.
# Gated per-player on ec.ms_cr_migrated so it applies EXACTLY once (idempotent across reloads/joins).
execute if score @s ec.ms_cr_migrated matches 1 run return 0
scoreboard players operation @s adv.cr_mine = @s adv.stat_mine
scoreboard players operation @s adv.cr_fish = @s adv.stat_fish
scoreboard players operation @s adv.cr_harvest = @s adv.stat_harvest
scoreboard players operation @s adv.cr_place = @s adv.stat_place
scoreboard players operation @s adv.cr_food = @s adv.stat_food
scoreboard players set @s ec.ms_cr_migrated 1
