# Respec Triggers — Route /trigger adv.respec (1-15)
scoreboard players operation #respec_tree adv.temp = @s adv.respec

# Validate
data modify storage evercraft:notify stage.c set value [{text:"Invalid tree ID. Use ",color:"red"},{text:"/trigger adv.respec set 1-15",color:"aqua"}]
scoreboard players set #ndur ec.temp 45
execute unless score #respec_tree adv.temp matches 1..15 run return run function evercraft:util/notify/emit

# Check cooldown
function evercraft:advantage/respec/check_cooldown
execute if score #respec_ok adv.temp matches 0 run return 0

# Check cost (Seed of Forgetting)
function evercraft:advantage/respec/check_cost
execute if score #respec_ok adv.temp matches 0 run return 0

# Execute respec
function evercraft:advantage/respec/do_respec
