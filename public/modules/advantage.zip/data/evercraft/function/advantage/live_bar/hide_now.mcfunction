# === ADVANTAGE — LIVE XP BAR: HIDE NOW ===
# Run as @s = player whose live bar should hide (timeout in tick OR they toggled tracking OFF).
# Sets the pooled bossbar invisible + clears the live flag. The pool slot is kept for the
# session (instant re-show), released only on logout (vanilla clears the viewer). Co-writer
# (with update) of adv.lb_live (sets 0).
execute unless score @s adv.lb_slot matches 1.. run return 0
execute store result storage evercraft:adv_livebar barslot int 1 run scoreboard players get @s adv.lb_slot
function evercraft:advantage/live_bar/do_hide with storage evercraft:adv_livebar
scoreboard players set @s adv.lb_live 0
