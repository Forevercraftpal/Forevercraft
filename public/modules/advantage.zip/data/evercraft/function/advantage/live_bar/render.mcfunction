# === ADVANTAGE — LIVE XP BAR: RENDER (MACRO) ===
# Call: function .../render with storage evercraft:adv_livebar
#   storage: {barslot:N, fill:0..100, lv:0..25, name:"...", color:"...", bar_color:"..."}
# Run as @s = the viewing player. Writes value/name/color to the pooled bossbar
# (evercraft:advbar_<barslot>), assigns @s as the sole viewer, and shows it.

$execute store result bossbar evercraft:advbar_$(barslot) value run scoreboard players get #alb_fill adv.temp
$bossbar set evercraft:advbar_$(barslot) color $(bar_color)

# Name: "<Tree>  Lv.N   F%" (or "MAX" at Lv.25).
$execute if score #alb_lv adv.temp matches ..24 run bossbar set evercraft:advbar_$(barslot) name ["",{text:"$(name)",color:"$(color)",bold:true},{text:"  Lv.",color:"gray"},{text:"$(lv)",color:"white"},{text:"   ",color:"gray"},{text:"$(fill)",color:"white"},{text:"%",color:"gray"}]
$execute if score #alb_lv adv.temp matches 25.. run bossbar set evercraft:advbar_$(barslot) name ["",{text:"$(name)",color:"$(color)",bold:true},{text:"  ",color:"gray"},{text:"MAX",color:"gold",bold:true}]

$bossbar set evercraft:advbar_$(barslot) players @s
$bossbar set evercraft:advbar_$(barslot) visible true
