# === ADVANTAGE — LIVE XP BAR: CLAIM POOL SLOT ===
# Run as @s = player needing an advbar slot. Claims the first free slot from the 16-bar pool.
# Mirrors craft_affinity/live_bar/claim_slot + health_bar/join. Pool full -> no bar (stats still
# tracked). Writer of adv.lb_slot (via do_claim); sets the #albslot_N registry.
execute if score #albslot_1 adv.lb_barslot matches 0 run function evercraft:advantage/live_bar/do_claim {slot:1}
execute if score @s adv.lb_slot matches 1.. run return 0
execute if score #albslot_2 adv.lb_barslot matches 0 run function evercraft:advantage/live_bar/do_claim {slot:2}
execute if score @s adv.lb_slot matches 1.. run return 0
execute if score #albslot_3 adv.lb_barslot matches 0 run function evercraft:advantage/live_bar/do_claim {slot:3}
execute if score @s adv.lb_slot matches 1.. run return 0
execute if score #albslot_4 adv.lb_barslot matches 0 run function evercraft:advantage/live_bar/do_claim {slot:4}
execute if score @s adv.lb_slot matches 1.. run return 0
execute if score #albslot_5 adv.lb_barslot matches 0 run function evercraft:advantage/live_bar/do_claim {slot:5}
execute if score @s adv.lb_slot matches 1.. run return 0
execute if score #albslot_6 adv.lb_barslot matches 0 run function evercraft:advantage/live_bar/do_claim {slot:6}
execute if score @s adv.lb_slot matches 1.. run return 0
execute if score #albslot_7 adv.lb_barslot matches 0 run function evercraft:advantage/live_bar/do_claim {slot:7}
execute if score @s adv.lb_slot matches 1.. run return 0
execute if score #albslot_8 adv.lb_barslot matches 0 run function evercraft:advantage/live_bar/do_claim {slot:8}
execute if score @s adv.lb_slot matches 1.. run return 0
execute if score #albslot_9 adv.lb_barslot matches 0 run function evercraft:advantage/live_bar/do_claim {slot:9}
execute if score @s adv.lb_slot matches 1.. run return 0
execute if score #albslot_10 adv.lb_barslot matches 0 run function evercraft:advantage/live_bar/do_claim {slot:10}
execute if score @s adv.lb_slot matches 1.. run return 0
execute if score #albslot_11 adv.lb_barslot matches 0 run function evercraft:advantage/live_bar/do_claim {slot:11}
execute if score @s adv.lb_slot matches 1.. run return 0
execute if score #albslot_12 adv.lb_barslot matches 0 run function evercraft:advantage/live_bar/do_claim {slot:12}
execute if score @s adv.lb_slot matches 1.. run return 0
execute if score #albslot_13 adv.lb_barslot matches 0 run function evercraft:advantage/live_bar/do_claim {slot:13}
execute if score @s adv.lb_slot matches 1.. run return 0
execute if score #albslot_14 adv.lb_barslot matches 0 run function evercraft:advantage/live_bar/do_claim {slot:14}
execute if score @s adv.lb_slot matches 1.. run return 0
execute if score #albslot_15 adv.lb_barslot matches 0 run function evercraft:advantage/live_bar/do_claim {slot:15}
execute if score @s adv.lb_slot matches 1.. run return 0
execute if score #albslot_16 adv.lb_barslot matches 0 run function evercraft:advantage/live_bar/do_claim {slot:16}
