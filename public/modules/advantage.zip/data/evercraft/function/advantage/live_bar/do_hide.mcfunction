# === ADVANTAGE — LIVE XP BAR: DO HIDE (MACRO) ===
# Call: function .../do_hide with storage evercraft:adv_livebar  (storage {barslot:N}).
# Sets the pooled bossbar invisible. Pure bossbar writer.
$bossbar set evercraft:advbar_$(barslot) visible false
