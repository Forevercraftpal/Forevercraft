# === ADVANTAGE — LIVE XP BAR: UPDATE (MACRO, event-driven) ===
# Call: function evercraft:advantage/live_bar/update
#   {tree_id:N, calc:"mining", level:"adv.mining", stat:"adv.stat_mine",
#    name:"Mining", color:"gold", bar_color:"yellow"}
# Run as @s = player whose tracked tree just gained its driving stat (gate passed in on_sync).
#
# Fill = current_stat * 100 / req_stat, where req_stat = the NEXT level's stat requirement,
# produced by the existing calc/<tree> (SAME source the level-up GUI uses — single curve, no
# duplicate threshold table). At Lv.25 (max) there is no next level: show a full MAX bar.
#
# SOLE WRITER of: adv.lb_until, adv.lb_live, adv.lb_slot (claim path). Reads adv.req_stat
# (populated here by calc; calc is the canonical writer of adv.req_stat/adv.req_xp).

# --- Ensure a pool slot (claim lazily; re-assert registry if already held — reload-safe). ---
execute if score @s adv.lb_slot matches 1.. run function evercraft:advantage/live_bar/reassert_slot
execute unless score @s adv.lb_slot matches 1.. run function evercraft:advantage/live_bar/claim_slot
execute unless score @s adv.lb_slot matches 1.. run return 0

# --- Read current level + driving stat into temps (macro objective names). ---
$execute store result score #alb_lv adv.temp run scoreboard players get @s $(level)
$execute store result score #alb_cur adv.temp run scoreboard players get @s $(stat)

# --- Default fill = 0; MAX (100) at Lv.25. Otherwise compute via calc/<tree> req_stat. ---
scoreboard players set #alb_fill adv.temp 0

# Lv.25 max -> pin full.
execute if score #alb_lv adv.temp matches 25.. run scoreboard players set #alb_fill adv.temp 100

# Below max -> run the tree's calc to fill adv.req_stat (next-level stat requirement), then
# fill = stat*100/req_stat clamped 0..100. (calc writes adv.req_xp + adv.req_stat as @s.)
$execute if score #alb_lv adv.temp matches ..24 run function evercraft:advantage/calc/$(calc)
# Re-read the numerator AFTER calc: for Beastmaster, calc/beastmaster is the sole writer of adv.bm_eff,
# so the line-21 read of $(stat)=adv.bm_eff can be one event stale until calc refreshes it here. For all
# other trees $(stat) is a driving stat calc never touches, so this re-read is a no-op (Council #6).
$execute if score #alb_lv adv.temp matches ..24 run scoreboard players operation #alb_cur adv.temp = @s $(stat)
execute if score #alb_lv adv.temp matches ..24 run scoreboard players operation #alb_fill adv.temp = #alb_cur adv.temp
execute if score #alb_lv adv.temp matches ..24 run scoreboard players operation #alb_fill adv.temp *= #adv_lb_100 ec.var
execute if score #alb_lv adv.temp matches ..24 if score @s adv.req_stat matches 1.. run scoreboard players operation #alb_fill adv.temp /= @s adv.req_stat
execute if score #alb_fill adv.temp matches 101.. run scoreboard players set #alb_fill adv.temp 100
execute if score #alb_fill adv.temp matches ..0 run scoreboard players set #alb_fill adv.temp 0

# --- Stamp the 8s auto-hide deadline + mark live. ---
execute store result score @s adv.lb_until run time query gametime
scoreboard players add @s adv.lb_until 160
scoreboard players set @s adv.lb_live 1

# --- Push to the player's pooled bossbar. ---
execute store result storage evercraft:adv_livebar barslot int 1 run scoreboard players get @s adv.lb_slot
execute store result storage evercraft:adv_livebar fill int 1 run scoreboard players get #alb_fill adv.temp
execute store result storage evercraft:adv_livebar lv int 1 run scoreboard players get #alb_lv adv.temp
$data modify storage evercraft:adv_livebar name set value "$(name)"
$data modify storage evercraft:adv_livebar color set value "$(color)"
$data modify storage evercraft:adv_livebar bar_color set value "$(bar_color)"
function evercraft:advantage/live_bar/render with storage evercraft:adv_livebar
