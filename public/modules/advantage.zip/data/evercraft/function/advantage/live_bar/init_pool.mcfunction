# === ADVANTAGE — LIVE XP BAR: INIT POOL (load-time) ===
# Configures the 16-bar advbar pool (max 100, empty name, hidden) and resets the pool registry
# to all-free. Called from advantage/load after the bars are created. Per-player adv.lb_slot is
# NOT cleared (players keep their slot across reload; update/reassert re-stamps the registry).
bossbar set evercraft:advbar_1 max 100
bossbar set evercraft:advbar_1 name ""
bossbar set evercraft:advbar_1 visible false
bossbar set evercraft:advbar_2 max 100
bossbar set evercraft:advbar_2 name ""
bossbar set evercraft:advbar_2 visible false
bossbar set evercraft:advbar_3 max 100
bossbar set evercraft:advbar_3 name ""
bossbar set evercraft:advbar_3 visible false
bossbar set evercraft:advbar_4 max 100
bossbar set evercraft:advbar_4 name ""
bossbar set evercraft:advbar_4 visible false
bossbar set evercraft:advbar_5 max 100
bossbar set evercraft:advbar_5 name ""
bossbar set evercraft:advbar_5 visible false
bossbar set evercraft:advbar_6 max 100
bossbar set evercraft:advbar_6 name ""
bossbar set evercraft:advbar_6 visible false
bossbar set evercraft:advbar_7 max 100
bossbar set evercraft:advbar_7 name ""
bossbar set evercraft:advbar_7 visible false
bossbar set evercraft:advbar_8 max 100
bossbar set evercraft:advbar_8 name ""
bossbar set evercraft:advbar_8 visible false
bossbar set evercraft:advbar_9 max 100
bossbar set evercraft:advbar_9 name ""
bossbar set evercraft:advbar_9 visible false
bossbar set evercraft:advbar_10 max 100
bossbar set evercraft:advbar_10 name ""
bossbar set evercraft:advbar_10 visible false
bossbar set evercraft:advbar_11 max 100
bossbar set evercraft:advbar_11 name ""
bossbar set evercraft:advbar_11 visible false
bossbar set evercraft:advbar_12 max 100
bossbar set evercraft:advbar_12 name ""
bossbar set evercraft:advbar_12 visible false
bossbar set evercraft:advbar_13 max 100
bossbar set evercraft:advbar_13 name ""
bossbar set evercraft:advbar_13 visible false
bossbar set evercraft:advbar_14 max 100
bossbar set evercraft:advbar_14 name ""
bossbar set evercraft:advbar_14 visible false
bossbar set evercraft:advbar_15 max 100
bossbar set evercraft:advbar_15 name ""
bossbar set evercraft:advbar_15 visible false
bossbar set evercraft:advbar_16 max 100
bossbar set evercraft:advbar_16 name ""
bossbar set evercraft:advbar_16 visible false

scoreboard players set #albslot_1 adv.lb_barslot 0
scoreboard players set #albslot_2 adv.lb_barslot 0
scoreboard players set #albslot_3 adv.lb_barslot 0
scoreboard players set #albslot_4 adv.lb_barslot 0
scoreboard players set #albslot_5 adv.lb_barslot 0
scoreboard players set #albslot_6 adv.lb_barslot 0
scoreboard players set #albslot_7 adv.lb_barslot 0
scoreboard players set #albslot_8 adv.lb_barslot 0
scoreboard players set #albslot_9 adv.lb_barslot 0
scoreboard players set #albslot_10 adv.lb_barslot 0
scoreboard players set #albslot_11 adv.lb_barslot 0
scoreboard players set #albslot_12 adv.lb_barslot 0
scoreboard players set #albslot_13 adv.lb_barslot 0
scoreboard players set #albslot_14 adv.lb_barslot 0
scoreboard players set #albslot_15 adv.lb_barslot 0
scoreboard players set #albslot_16 adv.lb_barslot 0

# adv.lb_live intentionally NOT reset here (keeps its writer set to update+hide_now). A player
# who held lb_live=1 across reload triggers ONE harmless hide_now on the first tick.
