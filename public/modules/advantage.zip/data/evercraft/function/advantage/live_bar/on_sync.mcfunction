# === ADVANTAGE — LIVE XP BAR: ON STAT SYNC (event-driven via the 5s sync pass) ===
# Called from advantage/track/sync_stats_player ONLY for players with a tracked tree
# (adv.lb_tree>=1). This is the adventurer "XP gain event": the tracked tree's driving stat has
# just been recomputed; if it INCREASED since adv.lb_snap, the player gathered toward the next
# level -> (re)show the bar with fill = current_stat*100/req_stat (req_stat from calc/<tree>).
# If it did not increase, do nothing (the auto-hide tick fades any showing bar after 8s).
#
# Cheap: one read of the tracked tree's stat into #alb_cur, one compare. Only the dispatch for
# the ONE tracked tree runs calc + update. SOLE writer of adv.lb_snap (steady state).

# --- Read the tracked tree's current driving stat into #alb_cur (id -> stat) ---
execute if score @s adv.lb_tree matches 1 run scoreboard players operation #alb_cur adv.temp = @s adv.stat_walk
execute if score @s adv.lb_tree matches 2 run scoreboard players operation #alb_cur adv.temp = @s adv.stat_place
execute if score @s adv.lb_tree matches 3 run scoreboard players operation #alb_cur adv.temp = @s adv.stat_hit
execute if score @s adv.lb_tree matches 4 run scoreboard players operation #alb_cur adv.temp = @s adv.stat_crouch
execute if score @s adv.lb_tree matches 5 run scoreboard players operation #alb_cur adv.temp = @s adv.stat_food
execute if score @s adv.lb_tree matches 6 run scoreboard players operation #alb_cur adv.temp = @s adv.stat_quests
# Tree 7 (Beastmaster) gains on EFFECTIVE pets = stat_pets100 + floor(bm_credit/20), so a dungeon-credit
# crossing moves the bar too (Council #6, 2026-06-02). stat_pets100 stays pure elsewhere.
execute if score @s adv.lb_tree matches 7 run scoreboard players operation #alb_cur adv.temp = @s adv.bm_credit
execute if score @s adv.lb_tree matches 7 run scoreboard players operation #alb_cur adv.temp /= #20 adv.temp
execute if score @s adv.lb_tree matches 7 run scoreboard players operation #alb_cur adv.temp += @s adv.stat_pets100
execute if score @s adv.lb_tree matches 8 run scoreboard players operation #alb_cur adv.temp = @s adv.stat_mobs
execute if score @s adv.lb_tree matches 9 run scoreboard players operation #alb_cur adv.temp = @s adv.stat_fish
execute if score @s adv.lb_tree matches 10 run scoreboard players operation #alb_cur adv.temp = @s adv.stat_mine
execute if score @s adv.lb_tree matches 11 run scoreboard players operation #alb_cur adv.temp = @s adv.stat_harvest
execute if score @s adv.lb_tree matches 12 run scoreboard players operation #alb_cur adv.temp = @s adv.stat_smelt
execute if score @s adv.lb_tree matches 13 run scoreboard players operation #alb_cur adv.temp = @s adv.stat_struct
execute if score @s adv.lb_tree matches 14 run scoreboard players operation #alb_cur adv.temp = @s adv.stat_cook
execute if score @s adv.lb_tree matches 15 run scoreboard players operation #alb_cur adv.temp = @s adv.stat_brew

# --- No gain this window? snapshot is still current; bail (one compare). ---
execute unless score #alb_cur adv.temp > @s adv.lb_snap run return 0

# --- Gained: refresh snapshot, then dispatch the per-tree update (calc + bossbar). ---
scoreboard players operation @s adv.lb_snap = #alb_cur adv.temp

execute if score @s adv.lb_tree matches 1 run function evercraft:advantage/live_bar/update {tree_id:1,calc:"agility",level:"adv.agility",stat:"adv.stat_walk",name:"Agility",color:"aqua",bar_color:"blue"}
execute if score @s adv.lb_tree matches 2 run function evercraft:advantage/live_bar/update {tree_id:2,calc:"dexterity",level:"adv.dexterity",stat:"adv.stat_place",name:"Dexterity",color:"yellow",bar_color:"yellow"}
execute if score @s adv.lb_tree matches 3 run function evercraft:advantage/live_bar/update {tree_id:3,calc:"evasion",level:"adv.evasion",stat:"adv.stat_hit",name:"Evasion",color:"white",bar_color:"white"}
execute if score @s adv.lb_tree matches 4 run function evercraft:advantage/live_bar/update {tree_id:4,calc:"stealth",level:"adv.stealth",stat:"adv.stat_crouch",name:"Stealth",color:"dark_gray",bar_color:"white"}
execute if score @s adv.lb_tree matches 5 run function evercraft:advantage/live_bar/update {tree_id:5,calc:"vitality",level:"adv.vitality",stat:"adv.stat_food",name:"Vitality",color:"red",bar_color:"red"}
execute if score @s adv.lb_tree matches 6 run function evercraft:advantage/live_bar/update {tree_id:6,calc:"taskmaster",level:"adv.taskmaster",stat:"adv.stat_quests",name:"Taskmaster",color:"dark_purple",bar_color:"purple"}
execute if score @s adv.lb_tree matches 7 run function evercraft:advantage/live_bar/update {tree_id:7,calc:"beastmaster",level:"adv.beastmaster",stat:"adv.bm_eff",name:"Beastmaster",color:"green",bar_color:"green"}
execute if score @s adv.lb_tree matches 8 run function evercraft:advantage/live_bar/update {tree_id:8,calc:"victorian",level:"adv.victorian",stat:"adv.stat_mobs",name:"Victorian",color:"dark_red",bar_color:"red"}
execute if score @s adv.lb_tree matches 9 run function evercraft:advantage/live_bar/update {tree_id:9,calc:"fishing",level:"adv.fishing",stat:"adv.stat_fish",name:"Fishing",color:"blue",bar_color:"blue"}
execute if score @s adv.lb_tree matches 10 run function evercraft:advantage/live_bar/update {tree_id:10,calc:"mining",level:"adv.mining",stat:"adv.stat_mine",name:"Mining",color:"gold",bar_color:"yellow"}
execute if score @s adv.lb_tree matches 11 run function evercraft:advantage/live_bar/update {tree_id:11,calc:"gathering",level:"adv.gathering",stat:"adv.stat_harvest",name:"Gathering",color:"green",bar_color:"green"}
execute if score @s adv.lb_tree matches 12 run function evercraft:advantage/live_bar/update {tree_id:12,calc:"blacksmith",level:"adv.blacksmith",stat:"adv.stat_smelt",name:"Blacksmith",color:"gray",bar_color:"white"}
execute if score @s adv.lb_tree matches 13 run function evercraft:advantage/live_bar/update {tree_id:13,calc:"explorer",level:"adv.explorer",stat:"adv.stat_struct",name:"Explorer",color:"dark_aqua",bar_color:"blue"}
execute if score @s adv.lb_tree matches 14 run function evercraft:advantage/live_bar/update {tree_id:14,calc:"culinary",level:"adv.culinary",stat:"adv.stat_cook",name:"Culinary",color:"green",bar_color:"green"}
execute if score @s adv.lb_tree matches 15 run function evercraft:advantage/live_bar/update {tree_id:15,calc:"chemistry",level:"adv.chemistry",stat:"adv.stat_brew",name:"Chemistry",color:"#9B59B6",bar_color:"purple"}
