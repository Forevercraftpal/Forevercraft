# === ADVANTAGE — LIVE XP BAR: CONSUME TOGGLE TRIGGER ===
# Run as @s = player whose adv.lb_track holds a tree id (1..15) from a GUI [Track XP] click.
# If that id == the already-tracked tree -> turn tracking OFF (and hide the bar). Otherwise set
# it as the new tracked tree + seed the snapshot to its current driving stat (so only FUTURE
# gains light the bar, never a spurious first delta) + confirm in chat.
# SOLE writer (with toggle confirmations) of adv.lb_tree; co-writer of adv.lb_snap (seed only;
# steady-state snapshot writes live in on_sync).

# --- Decide the edge ONCE, before any mutation: #alb_same=1 iff the clicked tree is the one
#     already tracked (so the comparison can't be invalidated by the writes below). ---
scoreboard players set #alb_same adv.temp 0
execute if score @s adv.lb_track = @s adv.lb_tree run scoreboard players set #alb_same adv.temp 1

# --- Same tree clicked again => OFF ---
execute if score #alb_same adv.temp matches 1 run scoreboard players set @s adv.lb_tree 0
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"Live XP bar ",color:"gray"},{text:"OFF",color:"red",bold:true},{text:".",color:"gray"},{text:" ✦",color:"gold"}]
scoreboard players set #ndur ec.temp 50
execute if score #alb_same adv.temp matches 1 run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"↻ ",color:"dark_gray"},{text:"The button above still reads its old state — reopen this page to refresh it.",color:"dark_gray",italic:true}]
scoreboard players set #ndur ec.temp 40
execute if score #alb_same adv.temp matches 1 run function evercraft:util/notify/emit
execute if score #alb_same adv.temp matches 1 if score @s adv.lb_slot matches 1.. run function evercraft:advantage/live_bar/hide_now
execute if score #alb_same adv.temp matches 1 run return 0

# --- Different tree => switch tracking to it, seed snapshot from its driving stat ---
scoreboard players operation @s adv.lb_tree = @s adv.lb_track

# Seed adv.lb_snap = the tracked tree's current driving stat (mapping id -> stat objective).
execute if score @s adv.lb_tree matches 1 run scoreboard players operation @s adv.lb_snap = @s adv.stat_walk
execute if score @s adv.lb_tree matches 2 run scoreboard players operation @s adv.lb_snap = @s adv.stat_place
execute if score @s adv.lb_tree matches 3 run scoreboard players operation @s adv.lb_snap = @s adv.stat_hit
execute if score @s adv.lb_tree matches 4 run scoreboard players operation @s adv.lb_snap = @s adv.stat_crouch
execute if score @s adv.lb_tree matches 5 run scoreboard players operation @s adv.lb_snap = @s adv.stat_food
execute if score @s adv.lb_tree matches 6 run scoreboard players operation @s adv.lb_snap = @s adv.stat_quests
# Tree 7 baseline = EFFECTIVE pets (stat_pets100 + floor(bm_credit/20)) to match on_sync's gain check;
# else a banked-credit crossing would mis-fire vs a raw snapshot (Council #6, 2026-06-02).
execute if score @s adv.lb_tree matches 7 run scoreboard players operation @s adv.lb_snap = @s adv.bm_credit
execute if score @s adv.lb_tree matches 7 run scoreboard players operation @s adv.lb_snap /= #20 adv.temp
execute if score @s adv.lb_tree matches 7 run scoreboard players operation @s adv.lb_snap += @s adv.stat_pets100
execute if score @s adv.lb_tree matches 8 run scoreboard players operation @s adv.lb_snap = @s adv.stat_mobs
execute if score @s adv.lb_tree matches 9 run scoreboard players operation @s adv.lb_snap = @s adv.stat_fish
execute if score @s adv.lb_tree matches 10 run scoreboard players operation @s adv.lb_snap = @s adv.stat_mine
execute if score @s adv.lb_tree matches 11 run scoreboard players operation @s adv.lb_snap = @s adv.stat_harvest
execute if score @s adv.lb_tree matches 12 run scoreboard players operation @s adv.lb_snap = @s adv.stat_smelt
execute if score @s adv.lb_tree matches 13 run scoreboard players operation @s adv.lb_snap = @s adv.stat_struct
execute if score @s adv.lb_tree matches 14 run scoreboard players operation @s adv.lb_snap = @s adv.stat_cook
execute if score @s adv.lb_tree matches 15 run scoreboard players operation @s adv.lb_snap = @s adv.stat_brew

data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"Live XP bar ",color:"gray"},{text:"ON",color:"green",bold:true},{text:". It shows while you gather toward the next level.",color:"gray"},{text:" ✦",color:"gold"}]
scoreboard players set #ndur ec.temp 50
function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"↻ ",color:"dark_gray"},{text:"The button above still reads its old state — reopen this page to refresh it.",color:"dark_gray",italic:true}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.pling master @s ~ ~ ~ 0.5 1.6
