# === ADVANTAGE — LIVE XP BAR: DO CLAIM (MACRO) ===
# Call: function .../do_claim {slot:N}  (N=1..16). Run as @s. SOLE writer of adv.lb_slot;
# sets the #albslot_N registry to 1.
$scoreboard players set @s adv.lb_slot $(slot)
$scoreboard players set #albslot_$(slot) adv.lb_barslot 1
