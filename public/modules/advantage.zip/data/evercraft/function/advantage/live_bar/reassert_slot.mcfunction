# === ADVANTAGE — LIVE XP BAR: RE-ASSERT SLOT OWNERSHIP ===
# Run as @s = player who already holds a persistent adv.lb_slot. Re-stamps the registry to 1 so
# a /reload (which zeroes #albslot_N in load) can't let a second player claim this slot. One of
# the adv.lb_barslot pool-registry writers (multi-writer by design; documented in load).
execute store result storage evercraft:adv_livebar barslot int 1 run scoreboard players get @s adv.lb_slot
function evercraft:advantage/live_bar/do_reassert with storage evercraft:adv_livebar
