# === ADVANTAGE — LIVE XP BAR: TICK (toggle-consume + auto-hide) ===
# Self-scheduled at 1s (20t). Two cheap, separately-gated jobs:
#   1) Consume the adv.lb_track trigger (a click on a GUI [Track XP] button) and set/clear the
#      player's single tracked tree (adv.lb_tree).
#   2) Auto-hide any player whose live bar has passed its adv.lb_until gametime stamp.
#
# COST: the trigger scan only touches players who clicked; the hide scan only touches players
# with a live bar up (adv.lb_live=1). Idle -> two @a existence checks + reschedule.
# Wired from advantage/load.

# === 1) TRIGGER CONSUME ===
# A [Track XP] click ran /trigger adv.lb_track set <tree_id> (1..15) — or set to the SAME tree
# that's already tracked, which toggles it OFF. consume_toggle resolves which.
execute as @a[scores={adv.lb_track=1..15}] run function evercraft:advantage/live_bar/consume_toggle
execute as @a[scores={adv.lb_track=1..}] run scoreboard players set @s adv.lb_track 0
scoreboard players enable @a adv.lb_track

# === 2) AUTO-HIDE ===
execute if entity @a[scores={adv.lb_live=1}] store result score #alb_now adv.temp run time query gametime
execute as @a[scores={adv.lb_live=1}] if score @s adv.lb_until <= #alb_now adv.temp run function evercraft:advantage/live_bar/hide_now

# Self-schedule (1s; never #minecraft:tick).
schedule function evercraft:advantage/live_bar/tick 1s
