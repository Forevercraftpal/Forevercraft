# === ADVANTAGE — LIVE XP BAR: DO RE-ASSERT (MACRO) ===
# Call: function .../do_reassert with storage evercraft:adv_livebar  (storage {barslot:N}).
# Marks the registry slot taken (idempotent). One of the adv.lb_barslot pool-registry writers.
$scoreboard players set #albslot_$(barslot) adv.lb_barslot 1
