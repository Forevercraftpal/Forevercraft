# Advantage Trees — Trigger Router
# Routes /trigger adv.levelup values 1-15 to the correct tree level-up function

execute if score @s adv.levelup matches 1 run function evercraft:advantage/levelup/agility
execute if score @s adv.levelup matches 2 run function evercraft:advantage/levelup/dexterity
execute if score @s adv.levelup matches 3 run function evercraft:advantage/levelup/evasion
execute if score @s adv.levelup matches 4 run function evercraft:advantage/levelup/stealth
execute if score @s adv.levelup matches 5 run function evercraft:advantage/levelup/vitality
execute if score @s adv.levelup matches 6 run function evercraft:advantage/levelup/taskmaster
execute if score @s adv.levelup matches 7 run function evercraft:advantage/levelup/beastmaster
execute if score @s adv.levelup matches 8 run function evercraft:advantage/levelup/victorian
execute if score @s adv.levelup matches 9 run function evercraft:advantage/levelup/fishing
execute if score @s adv.levelup matches 10 run function evercraft:advantage/levelup/mining
execute if score @s adv.levelup matches 11 run function evercraft:advantage/levelup/gathering
execute if score @s adv.levelup matches 12 run function evercraft:advantage/levelup/blacksmith
execute if score @s adv.levelup matches 13 run function evercraft:advantage/levelup/explorer
execute if score @s adv.levelup matches 14 run function evercraft:advantage/levelup/culinary
execute if score @s adv.levelup matches 15 run function evercraft:advantage/levelup/chemistry

# Reset and re-enable levelup trigger
scoreboard players set @s adv.levelup 0
scoreboard players enable @s adv.levelup

# === PRESTIGE TRIGGER ===
# /trigger adv.prestige set <tree_id 1-15>
execute if score @s adv.prestige matches 1..15 run function evercraft:advantage/prestige/triggers
scoreboard players set @s adv.prestige 0
scoreboard players enable @s adv.prestige

# === CLAIM EARNED (BANKED) PRESTIGE TRIGGER ===
# /trigger adv.pclaim set <tree_id> — fired by the [Claim ▸] chat button (questline capstone /
# on-join offer). Claims an earned prestige banked by a questline completion, bypassing the
# level-25 gate (it was EARNED) while respecting the 3-prestige cap. (Joseph 2026-06-02.)
execute if score @s adv.pclaim matches 1..15 run function evercraft:advantage/prestige/claim
scoreboard players set @s adv.pclaim 0
scoreboard players enable @s adv.pclaim

# === RESPEC TRIGGER ===
# /trigger adv.respec set <tree_id 1-15>
execute if score @s adv.respec matches 1..15 run function evercraft:advantage/respec/triggers
scoreboard players set @s adv.respec 0
scoreboard players enable @s adv.respec

# === COSMETIC TRIGGER ===
# /trigger adv.cosmetic set <1-5 OR 101-115> (1-5=tier toggle, 101-115=tree variant)
# Note: 0 (disable) is handled through GUI toggle, not trigger command
# 2026-05-28 (W5.6): split 1..115 into two ranges. Values 6..100 are reserved-future
# (silently consumed before; now ignored at the router). Adding a 6..100 sub-tier later
# requires extending both the range here AND cosmetics/triggers.mcfunction.
execute if score @s adv.cosmetic matches 1..5 run function evercraft:advantage/cosmetics/triggers
execute if score @s adv.cosmetic matches 101..115 run function evercraft:advantage/cosmetics/triggers
scoreboard players set @s adv.cosmetic 0
scoreboard players enable @s adv.cosmetic

# === CHALLENGE TRIGGER ===
# /trigger adv.challenge set <id> (-1=cancel, 1-17=accept base, 44-47=direct-accept Culinary/Chemistry weekly when featured)
# Note: 0 (view menu) removed from trigger — use GUI or /trigger adv.challenge set 0
# Split ranges to avoid matching reset value of 0 from other triggers
execute if score @s adv.challenge matches -1 run function evercraft:advantage/challenges/triggers
execute if score @s adv.challenge matches 1..17 run function evercraft:advantage/challenges/triggers
execute if score @s adv.challenge matches 44..47 run function evercraft:advantage/challenges/triggers
scoreboard players set @s adv.challenge 0
scoreboard players enable @s adv.challenge

# === TREE INFO TRIGGER ===
# /trigger adv.treeinfo set <1-15> — view prestige ability descriptions
execute if score @s adv.treeinfo matches 1 run function evercraft:advantage/gui/ability_desc/agility
execute if score @s adv.treeinfo matches 2 run function evercraft:advantage/gui/ability_desc/dexterity
execute if score @s adv.treeinfo matches 3 run function evercraft:advantage/gui/ability_desc/evasion
execute if score @s adv.treeinfo matches 4 run function evercraft:advantage/gui/ability_desc/stealth
execute if score @s adv.treeinfo matches 5 run function evercraft:advantage/gui/ability_desc/vitality
execute if score @s adv.treeinfo matches 6 run function evercraft:advantage/gui/ability_desc/taskmaster
execute if score @s adv.treeinfo matches 7 run function evercraft:advantage/gui/ability_desc/beastmaster
execute if score @s adv.treeinfo matches 8 run function evercraft:advantage/gui/ability_desc/victorian
execute if score @s adv.treeinfo matches 9 run function evercraft:advantage/gui/ability_desc/fishing
execute if score @s adv.treeinfo matches 10 run function evercraft:advantage/gui/ability_desc/mining
execute if score @s adv.treeinfo matches 11 run function evercraft:advantage/gui/ability_desc/gathering
execute if score @s adv.treeinfo matches 12 run function evercraft:advantage/gui/ability_desc/blacksmith
execute if score @s adv.treeinfo matches 13 run function evercraft:advantage/gui/ability_desc/explorer
execute if score @s adv.treeinfo matches 14 run function evercraft:advantage/gui/ability_desc/culinary
execute if score @s adv.treeinfo matches 15 run function evercraft:advantage/gui/ability_desc/chemistry
execute if score @s adv.treeinfo matches 1..15 at @s if score @s ec.fx_snd matches 1.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.3 1.5
scoreboard players set @s adv.treeinfo 0
scoreboard players enable @s adv.treeinfo

# === EXPLORER ABILITY TRIGGER ===
# /trigger adv.explore set 1 → Cartographer (locate nearest structures)
# /trigger adv.explore set 2 → Wayfinder (skyward launch + locate + exploration buffs)
execute if score @s adv.explore matches 1 run function evercraft:advantage/prestige/abilities/cartographer_use
execute if score @s adv.explore matches 2 run function evercraft:advantage/prestige/abilities/wayfinder_use
scoreboard players set @s adv.explore 0
scoreboard players enable @s adv.explore

# === BEASTMASTER WAR CRY TRIGGER ===
# /trigger adv.warcry set 1 → War Cry (buff all wolves)
execute if score @s adv.warcry matches 1 run function evercraft:advantage/prestige/abilities/warcry_use
scoreboard players set @s adv.warcry 0
scoreboard players enable @s adv.warcry
