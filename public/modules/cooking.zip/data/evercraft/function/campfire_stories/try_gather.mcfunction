# ============================================================
# Campfire Stories — Try Gather
# Run as/at a player near a campfire. Increment timer, check for group.
# ============================================================

# Already tagged this check cycle — skip
execute if entity @s[tag=ec.cf_gathering] run return 0

# Tag and increment near-campfire timer
tag @s add ec.cf_gathering
scoreboard players add @s ec.cf_near 1

# Need 3+ checks (15 seconds near campfire) AND 2+ players gathered AND cooldown expired
execute unless score @s ec.cf_near matches 3.. run return 0
execute unless score #cf_cooldown ec.var matches 0 run return 0

# Soft-lock cooldown IMMEDIATELY so any later same-tick caller's `matches 0` gate fails.
# Belt-and-suspenders for the multi-player race — sequential execution within a tick
# already prevents it, but this makes the invariant explicit and survives any reorder.
scoreboard players set #cf_cooldown ec.var 1

# Count other gathered players within 5 blocks
execute store result score #cf_nearby ec.var run execute if entity @a[distance=..5,tag=ec.cf_gathering]

# If count fails, release the soft-lock so the next tick can try again (no wasted 120s)
execute unless score #cf_nearby ec.var matches 2.. run scoreboard players set #cf_cooldown ec.var 0
execute unless score #cf_nearby ec.var matches 2.. run return 0

# All conditions met — escalate soft-lock to full 120s cooldown + trigger the story
scoreboard players set #cf_cooldown ec.var 120
function evercraft:campfire_stories/trigger_story
