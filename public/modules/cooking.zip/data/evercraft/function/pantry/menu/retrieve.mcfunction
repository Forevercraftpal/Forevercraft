# Pantry Menu — Retrieve item from slot (macro)
# Args: pid, slot

# Summon temp item entity, copy stored item data
# --- Volume stacking (Joseph 2026-06-20): pull up to one stack (64), decrement qty, clear at 0 ---
# Amount to pull: min(qty,64). Legacy slots without qty default to 1.
scoreboard players set #pantry_q ec.temp 1
$execute store result score #pantry_q ec.temp run data get storage evercraft:pantry bags.$(pid).$(slot).qty
scoreboard players operation #pantry_give ec.temp = #pantry_q ec.temp
execute if score #pantry_give ec.temp matches 65.. run scoreboard players set #pantry_give ec.temp 64

# Summon the stack, set its count, hand it to the player
execute at @s run summon item ~ ~1 ~ {Tags:["ec.pantry_tmp"],PickupDelay:0,Item:{id:"minecraft:stone",count:1}}
$data modify entity @e[type=item,tag=ec.pantry_tmp,limit=1] Item set from storage evercraft:pantry bags.$(pid).$(slot).item
execute store result entity @e[type=item,tag=ec.pantry_tmp,limit=1] Item.count int 1 run scoreboard players get #pantry_give ec.temp
tp @e[type=item,tag=ec.pantry_tmp,limit=1] @s
tag @e[type=item,tag=ec.pantry_tmp,limit=1] remove ec.pantry_tmp

# Decrement remaining qty; clear the slot when it hits 0
scoreboard players operation #pantry_q ec.temp -= #pantry_give ec.temp
$execute if score #pantry_q ec.temp matches ..0 run data modify storage evercraft:pantry bags.$(pid).$(slot) set value {}
$execute if score #pantry_q ec.temp matches 1.. store result storage evercraft:pantry bags.$(pid).$(slot).qty int 1 run scoreboard players get #pantry_q ec.temp

# Sound + feedback
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:item.bundle.remove_one master @s ~ ~ ~ 0.8 1.0
data modify storage evercraft:notify stage.c set value [{text:"Item retrieved!",color:"yellow"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit_keyed {key:15}
