# pantry Menu — Build stacking key (macro)
# Args: id (item id string), sub (sub-id string, "" if none)
# Writes temp.held_key = "<id>#<sub>" — same recipe must run at store AND compare time.
$data modify storage evercraft:pantry temp.held_key set value "$(id)#$(sub)"
