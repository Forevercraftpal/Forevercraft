# Pantry Menu — Try Store (macro)
# Args: pid, slot
# Validates mainhand is a cooking item, stores it to the pantry slot

# Check mainhand has a cooking item (ingredient, utensil, or meal)
# Use 'if data' for ingredient_id since it has varying string values
scoreboard players set #pantry_valid ec.temp 0
execute if data entity @s SelectedItem.components."minecraft:custom_data".ingredient_id run scoreboard players set #pantry_valid ec.temp 1
execute if items entity @s weapon.mainhand *[custom_data~{cooking_utensil:true}] run scoreboard players set #pantry_valid ec.temp 1
execute if items entity @s weapon.mainhand *[custom_data~{ec_meal:true}] run scoreboard players set #pantry_valid ec.temp 1

data modify storage evercraft:notify stage.c set value [{text:"Hold a cooking item in your mainhand!",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute if score #pantry_valid ec.temp matches 0 run function evercraft:util/notify/emit_keyed {key:14}
execute if score #pantry_valid ec.temp matches 0 run return 0

# --- Volume stacking (Joseph 2026-06-20): merge same-type items into one growing slot ---
# Held stack count
execute store result score #pantry_count ec.temp run data get entity @s SelectedItem.count

# Build the stacking key: item id + "#" + sub-id (ingredient_id if present, else "")
data modify storage evercraft:pantry temp.kb.id set from entity @s SelectedItem.id
data modify storage evercraft:pantry temp.kb.sub set value ""
execute if data entity @s SelectedItem.components."minecraft:custom_data".ingredient_id run data modify storage evercraft:pantry temp.kb.sub set from entity @s SelectedItem.components."minecraft:custom_data".ingredient_id
function evercraft:pantry/menu/mk_key with storage evercraft:pantry temp.kb

# Find an existing slot holding this key (#fk + temp.tgt) or the lowest empty slot (#fe)
data modify storage evercraft:pantry temp.fa.pid set from storage evercraft:pantry temp.pid
data modify storage evercraft:pantry temp.fa.hk set from storage evercraft:pantry temp.held_key
function evercraft:pantry/menu/find_slot with storage evercraft:pantry temp.fa

# Target slot = matching slot if found, else the clicked (empty) slot
execute if score #fk ec.temp matches 1 run data modify storage evercraft:pantry temp.write_slot set from storage evercraft:pantry temp.tgt
$execute if score #fk ec.temp matches 0 run data modify storage evercraft:pantry temp.write_slot set value "$(slot)"

# qty to add = held stack count
execute store result storage evercraft:pantry temp.qty_add int 1 run scoreboard players get #pantry_count ec.temp

# Commit (merge or fresh) then remove the whole held stack from mainhand
function evercraft:pantry/menu/do_store with storage evercraft:pantry temp
item replace entity @s weapon.mainhand with air

# Craftforever milestone tracking
scoreboard players add @s ec.pantry_stored 1

# Sound + feedback
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:item.bundle.insert master @s ~ ~ ~ 0.8 1.0
data modify storage evercraft:notify stage.c set value [{text:"Item stored!",color:"green"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit_keyed {key:13}
