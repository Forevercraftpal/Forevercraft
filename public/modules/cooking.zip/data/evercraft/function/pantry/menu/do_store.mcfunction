# pantry Menu — Commit a stacking store (macro)
# Args: pid, write_slot (+ storage temp.held_key, temp.qty_add)  |  #fk ec.temp: 1=merge, 0=fresh
# Runs as the player (SelectedItem still held).

# Fresh slot: copy item (count 1), name, key, seed qty
$execute if score #fk ec.temp matches 0 run data modify storage evercraft:pantry bags.$(pid).$(write_slot).item set from entity @s SelectedItem
$execute if score #fk ec.temp matches 0 run data modify storage evercraft:pantry bags.$(pid).$(write_slot).item.count set value 1
$execute if score #fk ec.temp matches 0 run data modify storage evercraft:pantry bags.$(pid).$(write_slot).name set from entity @s SelectedItem.components."minecraft:custom_name"
$execute if score #fk ec.temp matches 0 run data modify storage evercraft:pantry bags.$(pid).$(write_slot).key set from storage evercraft:pantry temp.held_key
$execute if score #fk ec.temp matches 0 run data modify storage evercraft:pantry bags.$(pid).$(write_slot).qty set from storage evercraft:pantry temp.qty_add

# Merge: qty += held stack count (no per-slot limit)
$execute if score #fk ec.temp matches 1 store result score #pantry_qty ec.temp run data get storage evercraft:pantry bags.$(pid).$(write_slot).qty
execute store result score #pantry_add ec.temp run data get storage evercraft:pantry temp.qty_add
execute if score #fk ec.temp matches 1 run scoreboard players operation #pantry_qty ec.temp += #pantry_add ec.temp
$execute if score #fk ec.temp matches 1 store result storage evercraft:pantry bags.$(pid).$(write_slot).qty int 1 run scoreboard players get #pantry_qty ec.temp
