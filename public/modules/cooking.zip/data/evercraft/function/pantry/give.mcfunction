# Pantry — Give pantry item to player
# Inv-full guard: drop at the player's feet rather than void on a full inventory.
execute store result score #inv_full ec.var run function evercraft:util/check_inv_full
execute if score #inv_full ec.var matches 0 run loot give @s loot evercraft:pantry/pantry
execute if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:pantry/pantry
scoreboard players set @s ec.has_pantry 1
data modify storage evercraft:notify stage.c set value [{text:"\u2726 ",color:"gold"},{text:"You received a ",color:"green"},{text:"Pantry",color:"gold",bold:true},{text:"! Store cooking items inside.",color:"green"},{text:" \u2726",color:"gold"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 0.8 1.4
