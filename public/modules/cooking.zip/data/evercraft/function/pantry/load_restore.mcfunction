# Pantry — Load this player's pending restore item into temp.restore_item (macro).
# WA59-P0-RACE (2026-06-22). Caller (restore_item) must set temp.uuid from entity @s UUID.
$data modify storage evercraft:pantry temp.restore_item set from storage evercraft:pantry restore."$(uuid)".item
