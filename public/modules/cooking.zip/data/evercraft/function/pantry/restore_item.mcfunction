# Pantry — Restore item after consume_item removal (1 tick delayed)
tag @s remove ec.pantry_restore

# WA59-P0-RACE (2026-06-22): read the pending item from the per-UUID restore key
# (set in on_use) into temp.restore_item, scoped to THIS player only.
data modify storage evercraft:pantry temp.uuid set from entity @s UUID
function evercraft:pantry/load_restore with storage evercraft:pantry temp

# Restore via hopper minecart intermediary (preserves stamped pantry_id + all NBT).
# WA59-P0-RACE: summon AT the player and grab with distance=..1,sort=nearest so two players
# restoring in the same tick can never grab each other's cart. (Naive distance grabs would miss
# the legacy Y320 cart — this summon is at the player's own feet, so distance scoping is valid.)
kill @e[type=hopper_minecart,tag=ec.pantry_cart,distance=..1]
summon hopper_minecart ~ ~ ~ {Tags:["ec.pantry_cart"],Enabled:0b,Items:[{Slot:0b,id:"minecraft:stone",count:1}]}
data modify entity @e[type=hopper_minecart,tag=ec.pantry_cart,distance=..1,sort=nearest,limit=1] Items[0] merge from storage evercraft:pantry temp.restore_item

# Restore to correct hand
execute if entity @s[tag=ec.pantry_mainhand] run item replace entity @s weapon.mainhand from entity @e[type=hopper_minecart,tag=ec.pantry_cart,distance=..1,sort=nearest,limit=1] container.0
execute unless entity @s[tag=ec.pantry_mainhand] run item replace entity @s weapon.offhand from entity @e[type=hopper_minecart,tag=ec.pantry_cart,distance=..1,sort=nearest,limit=1] container.0
tag @s remove ec.pantry_mainhand

data modify entity @e[type=hopper_minecart,tag=ec.pantry_cart,distance=..1,sort=nearest,limit=1] Items set value []
kill @e[type=hopper_minecart,tag=ec.pantry_cart,distance=..1]

# Clear the consumed per-UUID restore key.
function evercraft:pantry/clear_restore with storage evercraft:pantry temp
