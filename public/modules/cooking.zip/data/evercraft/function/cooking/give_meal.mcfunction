# Cooked-meal drop, inv-full guarded (Wiring Audit #30 P2.5, 2026-06-02).
# Macro arg: $(tbl) = loot table path tail after "evercraft:" (e.g. "cooking/meals/warriors_stew_a").
# #inv_full ec.var must already be computed by the caller this tick (cook_dispatch).
# Mirrors evercraft:cooking/artifacts/give_one — drops at feet when the inventory is full
# so a meal never voids under CK.FreeCook (Double-Portion frees 0 slots).
$execute if score #inv_full ec.var matches 0 run loot give @s loot evercraft:$(tbl)
$execute if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:$(tbl)
