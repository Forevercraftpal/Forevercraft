# Cooking Mastery Milestone (macro)
# Called with {level:"Name",color:"color",count:"N"}
$data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"$(color)"},{text:"COOKING MASTERY: ",color:"$(color)",bold:true},{text:"$(level)",color:"$(color)"},{text:" — $(count) meals prepared!",color:"gray"},{text:" ✦",color:"$(color)"}]
scoreboard players set #ndur ec.temp 50
function evercraft:util/notify/emit
# Mastery FX — the milestone fanfare (reads #ck_mast ec.temp; gated; Wave-3 cooking-fx pass).
execute at @s run function evercraft:fx/cook/mastery

# Bonus: grant XP for reaching mastery milestone
execute if score #ck_mast ec.temp matches 10 run experience add @s 100 points
execute if score #ck_mast ec.temp matches 25 run experience add @s 250 points
execute if score #ck_mast ec.temp matches 50 run experience add @s 500 points
execute if score #ck_mast ec.temp matches 100 run experience add @s 1000 points

# Announce to chat with category name from storage
function evercraft:cooking/mastery/announce with storage evercraft:cooking mastery
