# Cooking Mastery — Realm announcement (macro)
# (Wave 2, 2026-06-10: mastery brag rides the queue — name baked via whoami, protected, 30s TTL.)
function evercraft:util/notify/whoami
$data modify storage evercraft:notify stage.c set value [{text:"",color:"yellow"},{text:" has mastered ",color:"gray"},{text:"$(cat)",color:"yellow",bold:true},{text:"!",color:"gray"}]
data modify storage evercraft:notify stage.c[0].text set from storage evercraft:notify named.who
scoreboard players set #ndur ec.temp 50
execute as @a run scoreboard players set #nttl ec.temp 600
execute as @a run function evercraft:util/notify/emit_keep
