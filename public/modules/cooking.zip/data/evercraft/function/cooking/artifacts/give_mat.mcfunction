# Macro: give one cook_art reagent by type+tier. Args: type, tier.
$loot give @s loot evercraft:cooking/artifacts/materials/$(type)_t$(tier)
