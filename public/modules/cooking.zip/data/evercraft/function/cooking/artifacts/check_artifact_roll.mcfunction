# Chef's Touch — Check Artifact Roll
# Called after cooking quality result when ec.ck_art_cat matches 1..3
# Reads ec.ck_quality to determine artifact chance by quality tier
# Charred (<=3): 1% | Bland (4-7): 3% | Flavorful (8-11): 5% | Masterwork (12+): 7%

# Base find-threshold by quality tier (1/3/5/7). Computed into a score so the Artisan's Blessing relic can
# DOUBLE it for the duration of its window (ec.ck_art_x2 > 0) without duplicating the four roll lines.
scoreboard players set #ck_art_thr ec.cf_temp 0
execute if score @s ec.ck_quality matches ..3 run scoreboard players set #ck_art_thr ec.cf_temp 1
execute if score @s ec.ck_quality matches 4..7 run scoreboard players set #ck_art_thr ec.cf_temp 3
execute if score @s ec.ck_quality matches 8..11 run scoreboard players set #ck_art_thr ec.cf_temp 5
execute if score @s ec.ck_quality matches 12.. run scoreboard players set #ck_art_thr ec.cf_temp 7

# Artisan's Blessing (ornate relic) — doubled artifact-find chance while ec.ck_art_x2 > 0 (x += x = x*2).
execute if score @s ec.ck_art_x2 matches 1.. run scoreboard players operation #ck_art_thr ec.cf_temp += #ck_art_thr ec.cf_temp

execute store result score #ck_art_roll ec.cf_temp run random value 1..100
execute if score #ck_art_roll ec.cf_temp <= #ck_art_thr ec.cf_temp run function evercraft:cooking/artifacts/roll_artifact

# Consolation: when the artifact roll MISSED on a good cook (quality 8+), 20% chance to drop a craftable
# cook_art reagent (tier-scaled). Reagents right-click-forge into the cooking artifact they name — a
# deterministic alternative to this random roll. (Craft-path wiring 2026-06-05.)
execute unless score #ck_art_roll ec.cf_temp <= #ck_art_thr ec.cf_temp if score @s ec.ck_quality matches 8.. store result score #ck_mat_roll ec.cf_temp run random value 1..100
execute unless score #ck_art_roll ec.cf_temp <= #ck_art_thr ec.cf_temp if score @s ec.ck_quality matches 8.. if score #ck_mat_roll ec.cf_temp matches 1..20 run function evercraft:cooking/artifacts/drop_material
