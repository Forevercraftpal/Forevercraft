# Forge Eternal Banquet from a Epicurean reagent (1 reagent -> 1 artifact; the consume already removed it).
advancement revoke @s only evercraft:cooking/artifacts/forge/epicurean_t7
loot give @s loot evercraft:cooking/artifacts/mythical_epicurean
data modify storage evercraft:notify stage.c set value [{text:"Forged ",color:"gray"},{text:"Eternal Banquet",color:"gold"},{text:"!",color:"gray"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
# Forge FX — the "anvil song", tier 7 (gated; Wave-3 cooking-fx pass).
scoreboard players set #ck_forge_t ec.temp 7
execute at @s run function evercraft:fx/cook/forge
