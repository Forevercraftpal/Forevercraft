# Forge Apprentice's Whisk from a Catalyst reagent (1 reagent -> 1 artifact; the consume already removed it).
advancement revoke @s only evercraft:cooking/artifacts/forge/catalyst_t1
loot give @s loot evercraft:cooking/artifacts/common_catalyst
data modify storage evercraft:notify stage.c set value [{text:"Forged ",color:"gray"},{text:"Apprentice's Whisk",color:"white"},{text:"!",color:"gray"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
# Forge FX — the "anvil song", tier 1 (gated; Wave-3 cooking-fx pass).
scoreboard players set #ck_forge_t ec.temp 1
execute at @s run function evercraft:fx/cook/forge
