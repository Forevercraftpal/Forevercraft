# Artisan's Blessing (ornate cooking relic) — On Drink (advancement reward, runs as the player)
# "10 min doubled artifact find chance": sets a 10-minute window (ec.ck_art_x2 = 12000t) that
# cooking/artifacts/check_artifact_roll reads to DOUBLE the per-cook artifact-roll odds. Counted down in
# cooking/buff/tick (-20/s). Re-drinking refreshes (set-not-add).
advancement revoke @s only evercraft:cooking/artifacts/drink_relic_ornate
scoreboard players set @s ec.ck_art_x2 12000
data modify storage evercraft:notify stage.c set value [{text:"Artisan's Blessing — ",color:"gold"},{text:"doubled artifact-find chance for 10 minutes!",color:"yellow"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
# Relic-drink FX — standard shimmer (gated; Wave-3 cooking-fx pass).
scoreboard players set #ck_relic_grace ec.temp 0
execute at @s run function evercraft:fx/cook/relic_drink
