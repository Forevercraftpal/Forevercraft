# Cook-artifact drop, inv-full guarded (Wiring Audit #26 Q1, 2026-05-29).
# Macro arg: $(tbl) = artifact loot table tail (e.g. "common_epicurean", "mythical_relic").
# #inv_full ec.var must already be computed by the caller this tick (roll_artifact).
$execute if score #inv_full ec.var matches 0 run loot give @s loot evercraft:cooking/artifacts/$(tbl)
$execute if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:cooking/artifacts/$(tbl)
