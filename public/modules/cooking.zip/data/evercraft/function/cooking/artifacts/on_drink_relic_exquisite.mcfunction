# Fortune's Goblet (exquisite cooking relic) — On Drink (advancement reward, runs as the player)
# "doubled loot drops" is vanilla-infeasible, so (Joseph 2026-06-05) this reuses the pack's Fortune buff:
# a 5-minute +3 luck ("Dream Rate") window via the shared evercraft:fortune_meal modifier + ec.ck_fortune
# timer (counted down in cooking/buff/tick -> remove_fortune on expiry). Lore reworded to "+3 Dream Rate
# (5 min)". Re-drinking / eating a Fortune meal refreshes via the remove-then-add idiom (last applied wins).
advancement revoke @s only evercraft:cooking/artifacts/drink_relic_exquisite
attribute @s minecraft:luck modifier remove evercraft:fortune_meal
attribute @s minecraft:luck modifier add evercraft:fortune_meal 3.0 add_value
scoreboard players set @s ec.ck_fortune 6000
data modify storage evercraft:notify stage.c set value [{text:"Fortune's Goblet — ",color:"gold"},{text:"+3 Dream Rate for 5 minutes!",color:"light_purple"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
# Relic-drink FX — standard shimmer (gated; Wave-3 cooking-fx pass).
scoreboard players set #ck_relic_grace ec.temp 0
execute at @s run function evercraft:fx/cook/relic_drink
