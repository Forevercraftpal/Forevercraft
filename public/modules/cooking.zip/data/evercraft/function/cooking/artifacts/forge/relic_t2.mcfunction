# Forge Elixir of Satiation from a Relic reagent (1 reagent -> 1 artifact; the consume already removed it).
advancement revoke @s only evercraft:cooking/artifacts/forge/relic_t2
loot give @s loot evercraft:cooking/artifacts/uncommon_relic
data modify storage evercraft:notify stage.c set value [{text:"Forged ",color:"gray"},{text:"Elixir of Satiation",color:"green"},{text:"!",color:"gray"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
# Forge FX — the "anvil song", tier 2 (gated; Wave-3 cooking-fx pass).
scoreboard players set #ck_forge_t ec.temp 2
execute at @s run function evercraft:fx/cook/forge
