# Consolation cook_art material drop (called from check_artifact_roll when the artifact roll MISSED).
# Tier band scales with cook quality; type is random. Gives ONE craftable reagent.
scoreboard players set #mt ec.cf_temp 2
execute if score @s ec.ck_quality matches 12..15 run scoreboard players set #mt ec.cf_temp 4
execute if score @s ec.ck_quality matches 16.. run scoreboard players set #mt ec.cf_temp 6
execute store result score #mtr ec.cf_temp run random value 0..1
scoreboard players operation #mt ec.cf_temp += #mtr ec.cf_temp
execute store result score #mty ec.cf_temp run random value 1..3
data modify storage evercraft:ckmat type set value "catalyst"
execute if score #mty ec.cf_temp matches 2 run data modify storage evercraft:ckmat type set value "epicurean"
execute if score #mty ec.cf_temp matches 3 run data modify storage evercraft:ckmat type set value "relic"
execute store result storage evercraft:ckmat tier int 1 run scoreboard players get #mt ec.cf_temp
function evercraft:cooking/artifacts/give_mat with storage evercraft:ckmat
data modify storage evercraft:notify stage.c set value [{text:"A culinary reagent settles in the ashes...",color:"#FFCC88"}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit
