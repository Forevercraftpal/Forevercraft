# Chef's Eternal Grace (mythical cooking relic) — On Drink (advancement reward, runs as the player)
# Drinking sets a 15-minute doubled-cooking-quality window. 15 min = 18000 ticks; cooking/buff/tick
# counts it down (-20/s) and prints the fade notice; cooking/minigame/resolve doubles ec.ck_quality
# (after all bonuses, before the tier compare) while ec.ck_x2 > 0. Re-drinking refreshes (set-not-add).
advancement revoke @s only evercraft:cooking/artifacts/drink_eternal_grace
scoreboard players set @s ec.ck_x2 18000
data modify storage evercraft:notify stage.c set value [{text:"Chef's Eternal Grace — ",color:"gold"},{text:"doubled cooking quality for 15 minutes!",color:"yellow"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
# Relic-drink FX — the GRACE variant (richer + gold pillar). Gated; Wave-3 cooking-fx pass.
scoreboard players set #ck_relic_grace ec.temp 1
execute at @s run function evercraft:fx/cook/relic_drink
