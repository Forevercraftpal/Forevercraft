# Communal Feast Charm (rare cooking relic) — On Drink (advancement reward, runs as the player)
# "AoE buff to nearby players": shares a hearty Speed I + Resistance I + Regeneration I (30s) with every
# player within 8 blocks (the drinker is at distance 0, so they get it too). A drink potion normally only
# affects the drinker, so the AoE share needs this handler.
advancement revoke @s only evercraft:cooking/artifacts/drink_relic_rare
effect give @a[distance=..8] minecraft:speed 30 0
effect give @a[distance=..8] minecraft:resistance 30 0
effect give @a[distance=..8] minecraft:regeneration 30 0
data modify storage evercraft:notify stage.c set value [{text:"Communal Feast — ",color:"gold"},{text:"a hearty blessing spreads to nearby allies!",color:"yellow"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
# Relic-drink FX — standard shimmer (gated; Wave-3 cooking-fx pass).
scoreboard players set #ck_relic_grace ec.temp 0
execute at @s run function evercraft:fx/cook/relic_drink
# KEEP the sanctioned eating-burp (the food-relic meal identity) — shared to nearby
# allies who receive the buff. Gate it on the DRINKER's sound setting (Wave-3).
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.player.burp master @a[distance=..8] ~ ~ ~ 0.6 1.2
