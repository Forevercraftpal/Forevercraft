# Chef's Touch — Roll Artifact on Cooking
# Uses ec.ck_art_tier (1-7) to determine rarity weights
# Uses ec.ck_art_cat (1-3) to determine category
# Called when artifact chance roll succeeds

# Determine rarity based on tier
# T1-T2: 80 common, 15 uncommon, 5 rare (total 100)
# T3: 50 common, 30 uncommon, 15 rare, 5 exquisite (total 100)
# T4: 30 common, 30 uncommon, 25 rare, 10 exquisite, 5 ornate (total 100)
# T5: 15 common, 25 uncommon, 25 rare, 20 exquisite, 10 ornate, 5 mythical (total 100)
# T6: 5 common, 15 uncommon, 25 rare, 25 exquisite, 20 ornate, 10 mythical (total 100)
# T7: 10 uncommon, 25 rare, 35 exquisite, 30 ornate — NO mythical (total 100)

execute store result score #art_roll ec.cf_temp run random value 1..100

# Default rarity score: 0=common, 1=uncommon, 2=rare, 3=exquisite, 4=ornate, 5=mythical
scoreboard players set #art_rarity ec.cf_temp 0

# === T1-T2 RARITY ===
# 1-80 common, 81-95 uncommon, 96-100 rare
execute if score @s ec.ck_art_tier matches 1..2 if score #art_roll ec.cf_temp matches 81..95 run scoreboard players set #art_rarity ec.cf_temp 1
execute if score @s ec.ck_art_tier matches 1..2 if score #art_roll ec.cf_temp matches 96..100 run scoreboard players set #art_rarity ec.cf_temp 2

# === T3 RARITY ===
# 1-50 common, 51-80 uncommon, 81-95 rare, 96-100 exquisite
execute if score @s ec.ck_art_tier matches 3 if score #art_roll ec.cf_temp matches 51..80 run scoreboard players set #art_rarity ec.cf_temp 1
execute if score @s ec.ck_art_tier matches 3 if score #art_roll ec.cf_temp matches 81..95 run scoreboard players set #art_rarity ec.cf_temp 2
execute if score @s ec.ck_art_tier matches 3 if score #art_roll ec.cf_temp matches 96..100 run scoreboard players set #art_rarity ec.cf_temp 3

# === T4 RARITY ===
# 1-30 common, 31-60 uncommon, 61-85 rare, 86-95 exquisite, 96-100 ornate
execute if score @s ec.ck_art_tier matches 4 if score #art_roll ec.cf_temp matches 31..60 run scoreboard players set #art_rarity ec.cf_temp 1
execute if score @s ec.ck_art_tier matches 4 if score #art_roll ec.cf_temp matches 61..85 run scoreboard players set #art_rarity ec.cf_temp 2
execute if score @s ec.ck_art_tier matches 4 if score #art_roll ec.cf_temp matches 86..95 run scoreboard players set #art_rarity ec.cf_temp 3
execute if score @s ec.ck_art_tier matches 4 if score #art_roll ec.cf_temp matches 96..100 run scoreboard players set #art_rarity ec.cf_temp 4

# === T5 RARITY ===
# 1-15 common, 16-40 uncommon, 41-65 rare, 66-85 exquisite, 86-95 ornate, 96-100 mythical
execute if score @s ec.ck_art_tier matches 5 if score #art_roll ec.cf_temp matches 16..40 run scoreboard players set #art_rarity ec.cf_temp 1
execute if score @s ec.ck_art_tier matches 5 if score #art_roll ec.cf_temp matches 41..65 run scoreboard players set #art_rarity ec.cf_temp 2
execute if score @s ec.ck_art_tier matches 5 if score #art_roll ec.cf_temp matches 66..85 run scoreboard players set #art_rarity ec.cf_temp 3
execute if score @s ec.ck_art_tier matches 5 if score #art_roll ec.cf_temp matches 86..95 run scoreboard players set #art_rarity ec.cf_temp 4
execute if score @s ec.ck_art_tier matches 5 if score #art_roll ec.cf_temp matches 96..100 run scoreboard players set #art_rarity ec.cf_temp 5

# === T6 RARITY ===
# 1-5 common, 6-20 uncommon, 21-45 rare, 46-70 exquisite, 71-90 ornate, 91-100 mythical
execute if score @s ec.ck_art_tier matches 6 if score #art_roll ec.cf_temp matches 6..20 run scoreboard players set #art_rarity ec.cf_temp 1
execute if score @s ec.ck_art_tier matches 6 if score #art_roll ec.cf_temp matches 21..45 run scoreboard players set #art_rarity ec.cf_temp 2
execute if score @s ec.ck_art_tier matches 6 if score #art_roll ec.cf_temp matches 46..70 run scoreboard players set #art_rarity ec.cf_temp 3
execute if score @s ec.ck_art_tier matches 6 if score #art_roll ec.cf_temp matches 71..90 run scoreboard players set #art_rarity ec.cf_temp 4
execute if score @s ec.ck_art_tier matches 6 if score #art_roll ec.cf_temp matches 91..100 run scoreboard players set #art_rarity ec.cf_temp 5

# === T7 RARITY (NO MYTHICAL) ===
# 1-10 uncommon, 11-35 rare, 36-70 exquisite, 71-100 ornate
execute if score @s ec.ck_art_tier matches 7 run scoreboard players set #art_rarity ec.cf_temp 1
execute if score @s ec.ck_art_tier matches 7 if score #art_roll ec.cf_temp matches 11..35 run scoreboard players set #art_rarity ec.cf_temp 2
execute if score @s ec.ck_art_tier matches 7 if score #art_roll ec.cf_temp matches 36..70 run scoreboard players set #art_rarity ec.cf_temp 3
execute if score @s ec.ck_art_tier matches 7 if score #art_roll ec.cf_temp matches 71..100 run scoreboard players set #art_rarity ec.cf_temp 4

# Inv-full guard (Wiring Audit #26 Q1): compute once; give_one drops at feet if full so a rare artifact never voids.
execute store result score #inv_full ec.var run function evercraft:util/check_inv_full

# === GIVE ARTIFACT BY CATEGORY + RARITY ===
# Epicurean artifacts (cat 1)
execute if score @s ec.ck_art_cat matches 1 if score #art_rarity ec.cf_temp matches 0 run function evercraft:cooking/artifacts/give_one {tbl:"common_epicurean"}
execute if score @s ec.ck_art_cat matches 1 if score #art_rarity ec.cf_temp matches 1 run function evercraft:cooking/artifacts/give_one {tbl:"uncommon_epicurean"}
execute if score @s ec.ck_art_cat matches 1 if score #art_rarity ec.cf_temp matches 2 run function evercraft:cooking/artifacts/give_one {tbl:"rare_epicurean"}
execute if score @s ec.ck_art_cat matches 1 if score #art_rarity ec.cf_temp matches 3 run function evercraft:cooking/artifacts/give_one {tbl:"exquisite_epicurean"}
execute if score @s ec.ck_art_cat matches 1 if score #art_rarity ec.cf_temp matches 4 run function evercraft:cooking/artifacts/give_one {tbl:"ornate_epicurean"}
execute if score @s ec.ck_art_cat matches 1 if score #art_rarity ec.cf_temp matches 5 run function evercraft:cooking/artifacts/give_one {tbl:"mythical_epicurean"}

# Catalyst artifacts (cat 2)
execute if score @s ec.ck_art_cat matches 2 if score #art_rarity ec.cf_temp matches 0 run function evercraft:cooking/artifacts/give_one {tbl:"common_catalyst"}
execute if score @s ec.ck_art_cat matches 2 if score #art_rarity ec.cf_temp matches 1 run function evercraft:cooking/artifacts/give_one {tbl:"uncommon_catalyst"}
execute if score @s ec.ck_art_cat matches 2 if score #art_rarity ec.cf_temp matches 2 run function evercraft:cooking/artifacts/give_one {tbl:"rare_catalyst"}
execute if score @s ec.ck_art_cat matches 2 if score #art_rarity ec.cf_temp matches 3 run function evercraft:cooking/artifacts/give_one {tbl:"exquisite_catalyst"}
execute if score @s ec.ck_art_cat matches 2 if score #art_rarity ec.cf_temp matches 4 run function evercraft:cooking/artifacts/give_one {tbl:"ornate_catalyst"}
execute if score @s ec.ck_art_cat matches 2 if score #art_rarity ec.cf_temp matches 5 run function evercraft:cooking/artifacts/give_one {tbl:"mythical_catalyst"}

# Relic artifacts (cat 3)
execute if score @s ec.ck_art_cat matches 3 if score #art_rarity ec.cf_temp matches 0 run function evercraft:cooking/artifacts/give_one {tbl:"common_relic"}
execute if score @s ec.ck_art_cat matches 3 if score #art_rarity ec.cf_temp matches 1 run function evercraft:cooking/artifacts/give_one {tbl:"uncommon_relic"}
execute if score @s ec.ck_art_cat matches 3 if score #art_rarity ec.cf_temp matches 2 run function evercraft:cooking/artifacts/give_one {tbl:"rare_relic"}
execute if score @s ec.ck_art_cat matches 3 if score #art_rarity ec.cf_temp matches 3 run function evercraft:cooking/artifacts/give_one {tbl:"exquisite_relic"}
execute if score @s ec.ck_art_cat matches 3 if score #art_rarity ec.cf_temp matches 4 run function evercraft:cooking/artifacts/give_one {tbl:"ornate_relic"}
execute if score @s ec.ck_art_cat matches 3 if score #art_rarity ec.cf_temp matches 5 run function evercraft:cooking/artifacts/give_one {tbl:"mythical_relic"}

# Rarity name for feedback
data modify storage evercraft:notify stage.c set value [{text:"A culinary artifact manifests! ",color:"yellow"},{text:"Common",color:"white"}]
scoreboard players set #ndur ec.temp 45
execute if score #art_rarity ec.cf_temp matches 0 run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"A culinary artifact manifests! ",color:"yellow"},{text:"Uncommon",color:"blue"}]
scoreboard players set #ndur ec.temp 45
execute if score #art_rarity ec.cf_temp matches 1 run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"A culinary artifact manifests! ",color:"yellow"},{text:"Rare",color:"aqua"}]
scoreboard players set #ndur ec.temp 45
execute if score #art_rarity ec.cf_temp matches 2 run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"A culinary artifact manifests! ",color:"yellow"},{text:"Exquisite",color:"light_purple"}]
scoreboard players set #ndur ec.temp 45
execute if score #art_rarity ec.cf_temp matches 3 run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"A culinary artifact manifests! ",color:"yellow"},{text:"Ornate",color:"dark_purple"}]
scoreboard players set #ndur ec.temp 45
execute if score #art_rarity ec.cf_temp matches 4 run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"A culinary artifact manifests! ",color:"yellow"},{text:"Mythical",color:"gold",bold:true}]
scoreboard players set #ndur ec.temp 45
execute if score #art_rarity ec.cf_temp matches 5 run function evercraft:util/notify/emit

# Effects — the relic-reveal beat (a DISTINCT bell-arpeggio, not a doubled burst).
# Reads #art_rarity ec.cf_temp (set above). Gated per the FX law inside the preset.
# Replaces the crude levelup+totem(+toast/mythical) double-fire (Wave-3 cooking-fx pass).
execute at @s run function evercraft:fx/cook/relic_reveal
