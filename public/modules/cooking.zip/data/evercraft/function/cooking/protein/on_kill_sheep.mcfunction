# Protein drop: Sheep → Cured Mutton
advancement revoke @s only evercraft:cooking/protein/kill_sheep

# ~25% chance to drop protein
execute store result score #ck_roll ec.temp run random value 1..100
# Wiring Audit #26 O-5/H3: inv-full guard — drop at feet instead of voiding the protein.
execute if score #ck_roll ec.temp matches ..25 store result score #inv_full ec.var run function evercraft:util/check_inv_full
execute if score #ck_roll ec.temp matches ..25 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:cooking/ingredients/cured_mutton
execute if score #ck_roll ec.temp matches ..25 if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:cooking/ingredients/cured_mutton
data modify storage evercraft:notify stage.c set value [{text:"You obtained ",color:"gray"},{text:"Cured Mutton",color:"green"},{text:"!",color:"gray"}]
scoreboard players set #ndur ec.temp 45
execute if score #ck_roll ec.temp matches ..25 run function evercraft:util/notify/emit
execute if score #ck_roll ec.temp matches ..25 run scoreboard players add @s adv.stat_cook 1
execute if score #ck_roll ec.temp matches ..25 at @s run function evercraft:fx/cook/ingredient_ping
