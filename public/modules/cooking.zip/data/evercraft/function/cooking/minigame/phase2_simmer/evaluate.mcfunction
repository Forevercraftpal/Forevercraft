# Phase 2: SIMMER — Evaluate zone time
# Runs as the player. Scores quality based on % of time in zone.

# Calculate percentage: (zone_time * 100) / duration
scoreboard players operation #ck_pct ec.temp = @s ec.ck_v3
scoreboard players operation #ck_pct ec.temp *= #100 adv.temp
scoreboard players operation #ck_pct ec.temp /= @s ec.ck_v4

# Award quality by percentage band
# <25% = +0, 25-49% = +1, 50-74% = +2, 75-89% = +3, 90%+ = +4
execute if score #ck_pct ec.temp matches 25..49 run scoreboard players add @s ec.ck_quality 1
execute if score #ck_pct ec.temp matches 50..74 run scoreboard players add @s ec.ck_quality 2
execute if score #ck_pct ec.temp matches 75..89 run scoreboard players add @s ec.ck_quality 3
execute if score #ck_pct ec.temp matches 90.. run scoreboard players add @s ec.ck_quality 4

# Feedback
data modify storage evercraft:notify stage.c set value [{text:"Burnt! ",color:"red"},{text:"(+0 quality)",color:"gray"}]
scoreboard players set #ndur ec.temp 45
execute if score #ck_pct ec.temp matches ..24 run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Uneven heat. ",color:"yellow"},{text:"(+1 quality)",color:"gray"}]
scoreboard players set #ndur ec.temp 45
execute if score #ck_pct ec.temp matches 25..49 run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Good simmer! ",color:"green"},{text:"(+2 quality)",color:"yellow"}]
scoreboard players set #ndur ec.temp 45
execute if score #ck_pct ec.temp matches 50..74 run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Great control! ",color:"aqua"},{text:"(+3 quality)",color:"yellow"}]
scoreboard players set #ndur ec.temp 45
execute if score #ck_pct ec.temp matches 75..89 run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"PERFECT SIMMER! ",color:"gold",bold:true},{text:"(+4 quality)",color:"yellow"}]
scoreboard players set #ndur ec.temp 45
execute if score #ck_pct ec.temp matches 90.. run function evercraft:util/notify/emit

# Kill phase 2 entities
scoreboard players operation #gui_check ec.temp = @s adv.gui_session
execute as @e[type=text_display,tag=CK.MiniEl,distance=..8] if score @s adv.gui_session = #gui_check ec.temp run kill @s
execute as @e[type=interaction,tag=CK.MiniEl,distance=..8] if score @s adv.gui_session = #gui_check ec.temp run kill @s

# Feedback
data modify storage evercraft:notify stage.c set value [{text:"Simmering complete!",color:"#FF6B00"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
# FX — phase-complete "ready" bell (gated, tier-pitched)
execute at @s run function evercraft:fx/cook/phase_advance

# Advance to Phase 3
scoreboard players set @s ec.ck_phase 3
scoreboard players set @s ec.ck_timer 0
function evercraft:cooking/minigame/phase3_plate/start
