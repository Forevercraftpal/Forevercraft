# Phase 1: CHOP — Timeout (25 seconds)
# Force end phase with whatever chops landed

data modify storage evercraft:notify stage.c set value [{text:"Time's up!",color:"red"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit

# Kill phase 1 entities and advance
function evercraft:cooking/minigame/phase1_chop/complete
