# Chef's Touch — Result: MASTERWORK (Quality 12+)
# +50% buff duration + bonus Artisan XP
data modify storage evercraft:notify stage.c set value [{text:"✦ MASTERWORK! ",color:"#FFD700",bold:true},{text:"— +50% buff duration + bonus XP!",color:"gold"},{text:" ✦",color:"#FFD700",bold:true}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
# FX — the showcase: full chord + aroma pillar + firework + gold flash + end_rod rise (gated)
execute at @s run function evercraft:fx/cook/result_masterwork

# Bonus Artisan XP (+4 extra)
scoreboard players set #cf_xp_amount ec.cf_temp 4
scoreboard players set #cf_xp_cat ec.cf_temp 1
function evercraft:craftforever/artisan/add_xp

# Cooking artifact roll
execute if score @s ec.ck_art_cat matches 1..3 run function evercraft:cooking/artifacts/check_artifact_roll
