# Chef's Touch — Result: BLAND (Quality 4-7)
# Standard buff duration (same as Quick Cook)
data modify storage evercraft:notify stage.c set value [{text:"● BLAND ",color:"gray"},{text:"— Standard buff duration",color:"gray"},{text:" ●",color:"gray"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
# FX — plain single note + thin steam (gated)
execute at @s run function evercraft:fx/cook/result_bland

# Cooking artifact roll
execute if score @s ec.ck_art_cat matches 1..3 run function evercraft:cooking/artifacts/check_artifact_roll
