# Chef's Touch — Result: CHARRED (Quality 0-3)
# -50% buff duration
data modify storage evercraft:notify stage.c set value [{text:"✗ CHARRED ",color:"dark_red",bold:true},{text:"— Buff duration halved",color:"red"},{text:" ✗",color:"dark_red",bold:true}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
# FX — lone flat descending bass note + black smoke (gated; no clang, no mob vocal)
execute at @s run function evercraft:fx/cook/result_charred

# Cooking artifact roll
execute if score @s ec.ck_art_cat matches 1..3 run function evercraft:cooking/artifacts/check_artifact_roll

# Byproduct: Charred meal → Botanical reagent (20% chance)
execute store result score #byp_roll ec.cf_temp run random value 1..5
# Inv-full guard: drop at the player's feet rather than void on a full inventory.
execute store result score #inv_full ec.var run function evercraft:util/check_inv_full
execute if score #byp_roll ec.cf_temp matches 1 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:alchemy/reagents/byproduct_botanical
execute if score #byp_roll ec.cf_temp matches 1 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:alchemy/reagents/byproduct_botanical
