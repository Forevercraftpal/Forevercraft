# ============================================================
# Chef's Touch Minigame — Resolve
# Runs as the player after all 3 phases complete.
# Applies bonuses, determines quality tier, runs cook_dispatch.
# ============================================================

# --- Apply bonuses ---
# Home Kitchen bonus
execute if score @s hs.in_zone matches 1 run scoreboard players add @s ec.ck_quality 1
data modify storage evercraft:notify stage.c set value [{text:"Home Kitchen: ",color:"gold"},{text:"+1 quality bonus",color:"yellow"}]
scoreboard players set #ndur ec.temp 40
execute if score @s hs.in_zone matches 1 run function evercraft:util/notify/emit

# Culinary Expertise perk bonus (Advantage tree passive 1)
execute if score @s adv.pa_culi1 matches 1 run scoreboard players add @s ec.ck_quality 1
data modify storage evercraft:notify stage.c set value [{text:"Culinary Expertise: ",color:"gold"},{text:"+1 quality bonus",color:"yellow"}]
scoreboard players set #ndur ec.temp 40
execute if score @s adv.pa_culi1 matches 1 run function evercraft:util/notify/emit

# === Family J — Harvest & Tide cook-quality leaves (art-J) ===
# C24 Hearthhand Cloth, C28 Chef's Searing Charm, C29 Granary Keystone, C30 Cornucopia Crucible
# each grant +1 cook-resolve quality while held — mirrors the Home Kitchen / Culinary Expertise +1
# adds above (ec.ck_quality is a per-cook session accumulator with multiple legit add-sites: 3
# phases + Home Kitchen + Culinary Expertise; these are more, NOT a one-writer violation). Each adds
# independently (holding several stacks) — additive, exactly like Home Kitchen + Culinary Expertise.
# id-presence (one `if items` test -> two copies of the same charm add once = m4 multi-copy-safe).
# C25/C26/C29/C30's CR halves live in craft_rate/calculate; C27/C30's bonus-material roll fires after
# the result dispatch below. DR=0 for these cook levers (no dreams/breakdown line; the conditional-DR
# fishing pieces are the only J leaves with a luck modifier).
# cap-J m4 SUPPRESS-AT-SOURCE: when an absorbing node is held on Adventurer/Pioneer, the loose cook leaf
# is suppressed (the node grants the consolidated +2 below) so a re-acquired loose charm never double-
# counts. C24 Hearthhand Cloth + C28 Chef's Searing are absorbed by the Hearth Pair (leaf-pair) AND the
# Hearthkeeper's Ladle (sub-cap) AND the grand Cornucopia Tide; C29 Granary + C30 Crucible are absorbed
# by the Ladle + grand only. Each loose add carries `unless` its absorbing node(s), Newcomer-exempt
# (`unless ec.difficulty matches 1`). Casual Newcomer players keep the forgiving full +4 stack.
scoreboard players set #ckj_sup ec.cf_temp 0
execute unless score @s ec.difficulty matches 1 if items entity @s container.* *[custom_data~{hearthkeepers_ladle:true}] run scoreboard players set #ckj_sup ec.cf_temp 1
execute unless score @s ec.difficulty matches 1 if items entity @s weapon.offhand *[custom_data~{hearthkeepers_ladle:true}] run scoreboard players set #ckj_sup ec.cf_temp 1
execute unless score @s ec.difficulty matches 1 if items entity @s container.* *[custom_data~{cornucopia_tide:true}] run scoreboard players set #ckj_sup ec.cf_temp 1
execute unless score @s ec.difficulty matches 1 unless items entity @s container.* *[custom_data~{cornucopia_tide:true}] unless items entity @s weapon.offhand *[custom_data~{cornucopia_tide:true}] if entity @s[tag=ec.sat_cornucopia_tide] run scoreboard players set #ckj_sup ec.cf_temp 1
execute unless score @s ec.difficulty matches 1 if items entity @s weapon.offhand *[custom_data~{cornucopia_tide:true}] run scoreboard players set #ckj_sup ec.cf_temp 1
# Hearth-Pair suppression covers ONLY C24 + C28 (the pair's two leaves), Newcomer-exempt.
scoreboard players set #ckj_supp ec.cf_temp 0
execute if score #ckj_sup ec.cf_temp matches 1 run scoreboard players set #ckj_supp ec.cf_temp 1
execute unless score @s ec.difficulty matches 1 if items entity @s container.* *[custom_data~{hearth_pair:true}] run scoreboard players set #ckj_supp ec.cf_temp 1
execute unless score @s ec.difficulty matches 1 if items entity @s weapon.offhand *[custom_data~{hearth_pair:true}] run scoreboard players set #ckj_supp ec.cf_temp 1
# Loose cook-quality leaves (suppressed by their absorbing node; #ckj_supp covers C24/C28, #ckj_sup C29/C30).
execute unless score #ckj_supp ec.cf_temp matches 1 if items entity @s container.* *[custom_data~{artifact:"hearthhand_cloth"}] run scoreboard players add @s ec.ck_quality 1
execute unless score #ckj_supp ec.cf_temp matches 1 unless items entity @s container.* *[custom_data~{artifact:"hearthhand_cloth"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"hearthhand_cloth"}] if entity @s[tag=ec.sat_hearthhand_cloth] run scoreboard players add @s ec.ck_quality 1
execute unless score #ckj_supp ec.cf_temp matches 1 unless items entity @s container.* *[custom_data~{artifact:"hearthhand_cloth"}] if items entity @s weapon.offhand *[custom_data~{artifact:"hearthhand_cloth"}] run scoreboard players add @s ec.ck_quality 1
execute unless score #ckj_supp ec.cf_temp matches 1 if items entity @s container.* *[custom_data~{artifact:"chefs_searing_charm"}] run scoreboard players add @s ec.ck_quality 1
execute unless score #ckj_supp ec.cf_temp matches 1 unless items entity @s container.* *[custom_data~{artifact:"chefs_searing_charm"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"chefs_searing_charm"}] if entity @s[tag=ec.sat_chefs_searing_charm] run scoreboard players add @s ec.ck_quality 1
execute unless score #ckj_supp ec.cf_temp matches 1 unless items entity @s container.* *[custom_data~{artifact:"chefs_searing_charm"}] if items entity @s weapon.offhand *[custom_data~{artifact:"chefs_searing_charm"}] run scoreboard players add @s ec.ck_quality 1
execute unless score #ckj_sup ec.cf_temp matches 1 if items entity @s container.* *[custom_data~{artifact:"granary_keystone"}] run scoreboard players add @s ec.ck_quality 1
execute unless score #ckj_sup ec.cf_temp matches 1 unless items entity @s container.* *[custom_data~{artifact:"granary_keystone"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"granary_keystone"}] if entity @s[tag=ec.sat_granary_keystone] run scoreboard players add @s ec.ck_quality 1
execute unless score #ckj_sup ec.cf_temp matches 1 unless items entity @s container.* *[custom_data~{artifact:"granary_keystone"}] if items entity @s weapon.offhand *[custom_data~{artifact:"granary_keystone"}] run scoreboard players add @s ec.ck_quality 1
execute unless score #ckj_sup ec.cf_temp matches 1 if items entity @s container.* *[custom_data~{artifact:"cornucopia_crucible"}] run scoreboard players add @s ec.ck_quality 1
execute unless score #ckj_sup ec.cf_temp matches 1 unless items entity @s container.* *[custom_data~{artifact:"cornucopia_crucible"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"cornucopia_crucible"}] if entity @s[tag=ec.sat_cornucopia_crucible] run scoreboard players add @s ec.ck_quality 1
execute unless score #ckj_sup ec.cf_temp matches 1 unless items entity @s container.* *[custom_data~{artifact:"cornucopia_crucible"}] if items entity @s weapon.offhand *[custom_data~{artifact:"cornucopia_crucible"}] run scoreboard players add @s ec.ck_quality 1
# cap-J CONSOLIDATED cook quality (+2): the Hearth Pair leaf-pair, the Hearthkeeper's Ladle sub-cap, and
# the grand Cornucopia Tide each grant the consolidated +2 cook quality (the balanced headline — the loose
# C24+C28 are +2, and the Ladle/grand fold all 7 culinary charms into the same +2, like cap-B's +24 grand
# being a deliberate number, NOT the raw sum). id-presence set-not-add: holding one of these grants +2
# once. Supersede: the grand + Ladle each grant +2; if the Hearth Pair is ALSO held with a Ladle/grand,
# the Hearth Pair add is guarded `unless` the Ladle/grand so the cook never gets +4 (only one +2 fires).
execute if items entity @s container.* *[custom_data~{cornucopia_tide:true}] run scoreboard players add @s ec.ck_quality 2
execute unless items entity @s container.* *[custom_data~{cornucopia_tide:true}] unless items entity @s weapon.offhand *[custom_data~{cornucopia_tide:true}] if entity @s[tag=ec.sat_cornucopia_tide] run scoreboard players add @s ec.ck_quality 2
execute unless items entity @s container.* *[custom_data~{cornucopia_tide:true}] if items entity @s weapon.offhand *[custom_data~{cornucopia_tide:true}] run scoreboard players add @s ec.ck_quality 2
execute unless items entity @s container.* *[custom_data~{cornucopia_tide:true}] unless items entity @s weapon.offhand *[custom_data~{cornucopia_tide:true}] unless entity @s[tag=ec.sat_cornucopia_tide] if items entity @s container.* *[custom_data~{hearthkeepers_ladle:true}] run scoreboard players add @s ec.ck_quality 2
execute unless items entity @s container.* *[custom_data~{cornucopia_tide:true}] unless items entity @s weapon.offhand *[custom_data~{cornucopia_tide:true}] unless entity @s[tag=ec.sat_cornucopia_tide] unless items entity @s container.* *[custom_data~{hearthkeepers_ladle:true}] if items entity @s weapon.offhand *[custom_data~{hearthkeepers_ladle:true}] run scoreboard players add @s ec.ck_quality 2
execute unless items entity @s container.* *[custom_data~{cornucopia_tide:true}] unless items entity @s weapon.offhand *[custom_data~{cornucopia_tide:true}] unless entity @s[tag=ec.sat_cornucopia_tide] unless items entity @s container.* *[custom_data~{hearthkeepers_ladle:true}] unless items entity @s weapon.offhand *[custom_data~{hearthkeepers_ladle:true}] if items entity @s container.* *[custom_data~{hearth_pair:true}] run scoreboard players add @s ec.ck_quality 2
execute unless items entity @s container.* *[custom_data~{cornucopia_tide:true}] unless items entity @s weapon.offhand *[custom_data~{cornucopia_tide:true}] unless entity @s[tag=ec.sat_cornucopia_tide] unless items entity @s container.* *[custom_data~{hearthkeepers_ladle:true}] unless items entity @s weapon.offhand *[custom_data~{hearthkeepers_ladle:true}] unless items entity @s container.* *[custom_data~{hearth_pair:true}] if items entity @s weapon.offhand *[custom_data~{hearth_pair:true}] run scoreboard players add @s ec.ck_quality 2
# One cosmetic line if any J cook-quality charm helped (set a flag, print once).
scoreboard players set #ckj_qhelp ec.cf_temp 0
execute if items entity @s container.* *[custom_data~{artifact:"hearthhand_cloth"}] run scoreboard players set #ckj_qhelp ec.cf_temp 1
execute unless items entity @s container.* *[custom_data~{artifact:"hearthhand_cloth"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"hearthhand_cloth"}] if entity @s[tag=ec.sat_hearthhand_cloth] run scoreboard players set #ckj_qhelp ec.cf_temp 1
execute if items entity @s weapon.offhand *[custom_data~{artifact:"hearthhand_cloth"}] run scoreboard players set #ckj_qhelp ec.cf_temp 1
execute if items entity @s container.* *[custom_data~{artifact:"chefs_searing_charm"}] run scoreboard players set #ckj_qhelp ec.cf_temp 1
execute unless items entity @s container.* *[custom_data~{artifact:"chefs_searing_charm"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"chefs_searing_charm"}] if entity @s[tag=ec.sat_chefs_searing_charm] run scoreboard players set #ckj_qhelp ec.cf_temp 1
execute if items entity @s weapon.offhand *[custom_data~{artifact:"chefs_searing_charm"}] run scoreboard players set #ckj_qhelp ec.cf_temp 1
execute if items entity @s container.* *[custom_data~{artifact:"granary_keystone"}] run scoreboard players set #ckj_qhelp ec.cf_temp 1
execute unless items entity @s container.* *[custom_data~{artifact:"granary_keystone"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"granary_keystone"}] if entity @s[tag=ec.sat_granary_keystone] run scoreboard players set #ckj_qhelp ec.cf_temp 1
execute if items entity @s weapon.offhand *[custom_data~{artifact:"granary_keystone"}] run scoreboard players set #ckj_qhelp ec.cf_temp 1
execute if items entity @s container.* *[custom_data~{artifact:"cornucopia_crucible"}] run scoreboard players set #ckj_qhelp ec.cf_temp 1
execute unless items entity @s container.* *[custom_data~{artifact:"cornucopia_crucible"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"cornucopia_crucible"}] if entity @s[tag=ec.sat_cornucopia_crucible] run scoreboard players set #ckj_qhelp ec.cf_temp 1
execute if items entity @s weapon.offhand *[custom_data~{artifact:"cornucopia_crucible"}] run scoreboard players set #ckj_qhelp ec.cf_temp 1
# cap-J fusion nodes also raise the helped-flag (the consolidated +2 above came from a held node).
execute if items entity @s container.* *[custom_data~{hearth_pair:true}] run scoreboard players set #ckj_qhelp ec.cf_temp 1
execute if items entity @s weapon.offhand *[custom_data~{hearth_pair:true}] run scoreboard players set #ckj_qhelp ec.cf_temp 1
execute if items entity @s container.* *[custom_data~{hearthkeepers_ladle:true}] run scoreboard players set #ckj_qhelp ec.cf_temp 1
execute if items entity @s weapon.offhand *[custom_data~{hearthkeepers_ladle:true}] run scoreboard players set #ckj_qhelp ec.cf_temp 1
execute if items entity @s container.* *[custom_data~{cornucopia_tide:true}] run scoreboard players set #ckj_qhelp ec.cf_temp 1
execute unless items entity @s container.* *[custom_data~{cornucopia_tide:true}] unless items entity @s weapon.offhand *[custom_data~{cornucopia_tide:true}] if entity @s[tag=ec.sat_cornucopia_tide] run scoreboard players set #ckj_qhelp ec.cf_temp 1
execute if items entity @s weapon.offhand *[custom_data~{cornucopia_tide:true}] run scoreboard players set #ckj_qhelp ec.cf_temp 1
data modify storage evercraft:notify stage.c set value [{text:"Hearthkeeper: ",color:"gold"},{text:"+ quality (hearth charm)",color:"yellow"}]
scoreboard players set #ndur ec.temp 40
execute if score #ckj_qhelp ec.cf_temp matches 1 run function evercraft:util/notify/emit

# === Cooking Catalysts (generic Cooking-quality tools) — quality_bonus ladder ===
# The 6 catalysts (Apprentice's Whisk..The Eternal Flame) carry custom_data quality_bonus:1b..6b and lore
# "+N Cooking Quality". A SEPARATE ladder from the hearth focus charms (J family) above: a catalyst is a held
# TOOL, so the cook benefits from their single BEST catalyst (highest wins), NOT additive across the set.
# Ascending byte-checks with set-not-add => the largest quality_bonus held lands in #ck_cat; container +
# offhand. byte-suffix mandatory (NBT byte-coercion). artifact_type gate keeps the alchemy implements (which
# also carry quality_bonus) from leaking into the cook funnel.
scoreboard players set #ck_cat ec.cf_temp 0
execute if items entity @s container.* *[custom_data~{artifact_type:"cooking_catalyst",quality_bonus:1b}] run scoreboard players set #ck_cat ec.cf_temp 1
execute if items entity @s weapon.offhand *[custom_data~{artifact_type:"cooking_catalyst",quality_bonus:1b}] run scoreboard players set #ck_cat ec.cf_temp 1
execute if items entity @s container.* *[custom_data~{artifact_type:"cooking_catalyst",quality_bonus:2b}] run scoreboard players set #ck_cat ec.cf_temp 2
execute if items entity @s weapon.offhand *[custom_data~{artifact_type:"cooking_catalyst",quality_bonus:2b}] run scoreboard players set #ck_cat ec.cf_temp 2
execute if items entity @s container.* *[custom_data~{artifact_type:"cooking_catalyst",quality_bonus:3b}] run scoreboard players set #ck_cat ec.cf_temp 3
execute if items entity @s weapon.offhand *[custom_data~{artifact_type:"cooking_catalyst",quality_bonus:3b}] run scoreboard players set #ck_cat ec.cf_temp 3
execute if items entity @s container.* *[custom_data~{artifact_type:"cooking_catalyst",quality_bonus:4b}] run scoreboard players set #ck_cat ec.cf_temp 4
execute if items entity @s weapon.offhand *[custom_data~{artifact_type:"cooking_catalyst",quality_bonus:4b}] run scoreboard players set #ck_cat ec.cf_temp 4
execute if items entity @s container.* *[custom_data~{artifact_type:"cooking_catalyst",quality_bonus:5b}] run scoreboard players set #ck_cat ec.cf_temp 5
execute if items entity @s weapon.offhand *[custom_data~{artifact_type:"cooking_catalyst",quality_bonus:5b}] run scoreboard players set #ck_cat ec.cf_temp 5
execute if items entity @s container.* *[custom_data~{artifact_type:"cooking_catalyst",quality_bonus:6b}] run scoreboard players set #ck_cat ec.cf_temp 6
execute if items entity @s weapon.offhand *[custom_data~{artifact_type:"cooking_catalyst",quality_bonus:6b}] run scoreboard players set #ck_cat ec.cf_temp 6
execute if score #ck_cat ec.cf_temp matches 1.. run scoreboard players operation @s ec.ck_quality += #ck_cat ec.cf_temp
data modify storage evercraft:notify stage.c set value [{text:"Catalyst: ",color:"gold"},{text:"+",color:"yellow"},{score:{name:"#ck_cat",objective:"ec.cf_temp"},color:"yellow"},{text:" quality",color:"yellow"}]
scoreboard players set #ndur ec.temp 40
execute if score #ck_cat ec.cf_temp matches 1.. run function evercraft:util/notify/emit

# === Chef's Eternal Grace relic — doubled-cooking-quality window (ec.ck_x2 timer, set on drink) ===
# Applied AFTER all quality bonuses (catalyst included) so it doubles the full accumulated total, BEFORE the
# threshold/tier compare below. ec.ck_x2 counts down in cooking/buff/tick; >0 = active. set-not-add, so the
# window doubles once regardless of copies.
execute if score @s ec.ck_x2 matches 1.. run scoreboard players set #ck_two ec.cf_temp 2
execute if score @s ec.ck_x2 matches 1.. run scoreboard players operation @s ec.ck_quality *= #ck_two ec.cf_temp
data modify storage evercraft:notify stage.c set value [{text:"Eternal Grace: ",color:"gold"},{text:"quality doubled!",color:"yellow"}]
scoreboard players set #ndur ec.temp 40
execute if score @s ec.ck_x2 matches 1.. run function evercraft:util/notify/emit

# --- Show final quality ---
data modify storage evercraft:notify stage.c set value [{text:"Final Quality: ",color:"gray"},{score:{name:"@s",objective:"ec.ck_quality"},color:"white",bold:true}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit

# --- Determine outcome tier (AU26-Q5 Joseph 2026-05-30: gentle-ramp curve) ---
# Tier-keyed Masterwork threshold: T1=11 (free Masterwork on raw), T2=12 (same), T3=14, T4=16.
# Inverts the pre-2026-05-30 flat 12 that made T1 require both Home Kitchen + Culinary Expertise perks.
scoreboard players set #ck_mw_thresh ec.var 12
execute if score @s ec.ck_tier matches 1 run scoreboard players set #ck_mw_thresh ec.var 11
execute if score @s ec.ck_tier matches 3 run scoreboard players set #ck_mw_thresh ec.var 14
execute if score @s ec.ck_tier matches 4 run scoreboard players set #ck_mw_thresh ec.var 16

# === The Eternal Flame (mythical catalyst) auto_masterwork:10b — 10% chance to force a Masterwork ===
# Held catalyst grants a 10% per-cook chance to auto-promote the result to Masterwork. One roll; on a win,
# raise ck_quality to the (tier-keyed) Masterwork threshold so BOTH the quality_mod block and the >= thresh
# dispatch below land on Masterwork. `if <` guard means it only ever HELPS (never lowers a cook already at/
# above threshold). set-once via container/offhand `unless`-guard (m4 multi-copy-safe). byte-suffix mandatory.
scoreboard players set #ck_automw ec.cf_temp 0
execute if items entity @s container.* *[custom_data~{auto_masterwork:10b}] run scoreboard players set #ck_automw ec.cf_temp 1
execute unless items entity @s container.* *[custom_data~{auto_masterwork:10b}] if items entity @s weapon.offhand *[custom_data~{auto_masterwork:10b}] run scoreboard players set #ck_automw ec.cf_temp 1
execute if score #ck_automw ec.cf_temp matches 1 store result score #ck_automw_roll ec.cf_temp run random value 1..100
scoreboard players set #ck_automw_hit ec.cf_temp 0
execute if score #ck_automw ec.cf_temp matches 1 if score #ck_automw_roll ec.cf_temp matches 1..10 if score @s ec.ck_quality < #ck_mw_thresh ec.var run scoreboard players set #ck_automw_hit ec.cf_temp 1
execute if score #ck_automw_hit ec.cf_temp matches 1 run scoreboard players operation @s ec.ck_quality = #ck_mw_thresh ec.var
data modify storage evercraft:notify stage.c set value [{text:"The Eternal Flame: ",color:"gold"},{text:"Masterwork forged!",color:"yellow",bold:true}]
scoreboard players set #ndur ec.temp 45
execute if score #ck_automw_hit ec.cf_temp matches 1 run function evercraft:util/notify/emit

scoreboard players set @s ec.ck_quality_mod 1
execute if score @s ec.ck_quality matches ..3 run scoreboard players set @s ec.ck_quality_mod 0
execute if score @s ec.ck_quality matches 8.. if score @s ec.ck_quality < #ck_mw_thresh ec.var run scoreboard players set @s ec.ck_quality_mod 2
execute if score @s ec.ck_quality >= #ck_mw_thresh ec.var run scoreboard players set @s ec.ck_quality_mod 3

# --- Wiring Audit #26 Q1 (Joseph): WIRE the cook-artifact roll ---
# The result_* fns gate check_artifact_roll on `ec.ck_art_cat matches 1..3`, which was never set
# (the whole roll was dead). Set category + tier here, before result_* runs, from the saved cook
# state (ck_saved_cat is set in begin; ck_tier 1-4 = meal tier). check_artifact_roll then gates the
# CHANCE by quality (1/3/5/7%); roll_artifact uses art_tier for rarity weights.
# art_cat: 1 Epicurean (delicacy/seasonal/treats/feast/spirit) · 2 Catalyst (combat/mining/fortune/wayfarer) · 3 Relic (rations/preservation)
scoreboard players set @s ec.ck_art_cat 2
execute if score @s ec.ck_saved_cat matches 4 run scoreboard players set @s ec.ck_art_cat 1
execute if score @s ec.ck_saved_cat matches 5 run scoreboard players set @s ec.ck_art_cat 1
execute if score @s ec.ck_saved_cat matches 6 run scoreboard players set @s ec.ck_art_cat 1
execute if score @s ec.ck_saved_cat matches 8 run scoreboard players set @s ec.ck_art_cat 1
execute if score @s ec.ck_saved_cat matches 10 run scoreboard players set @s ec.ck_art_cat 1
execute if score @s ec.ck_saved_cat matches 7 run scoreboard players set @s ec.ck_art_cat 3
execute if score @s ec.ck_saved_cat matches 9 run scoreboard players set @s ec.ck_art_cat 3
# art_tier from meal tier (1-4 → rarity tiers 1-4 = common..ornate; mythical stays exclusive to other sources)
scoreboard players operation @s ec.ck_art_tier = @s ec.ck_tier

# --- Result feedback (AU26-Q5 Joseph 2026-05-30: gentle-ramp Masterwork uses #ck_mw_thresh) ---
execute if score @s ec.ck_quality matches ..3 run function evercraft:cooking/minigame/result_charred
execute if score @s ec.ck_quality matches 4..7 run function evercraft:cooking/minigame/result_bland
execute if score @s ec.ck_quality matches 8.. if score @s ec.ck_quality < #ck_mw_thresh ec.var run function evercraft:cooking/minigame/result_flavorful
execute if score @s ec.ck_quality >= #ck_mw_thresh ec.var run function evercraft:cooking/minigame/result_masterwork

# === Family J — Harvest Censer (C27) + Cornucopia Crucible (C30) bonus-material roll (art-J) ===
# H13 additive extra cook-artifact draw, item-gated, parallel to (NOT a rewrite of) the base
# check_artifact_roll the result_* fns already fired above. The base ck_art_cat/ck_art_tier set
# above (lines ~70-77) drive roll_artifact's category + rarity, so this independent +2% roll uses
# the same tables. ONE extra `random value 1..100` (a `matches 1..2` win = ~2%) per held charm,
# gated on the cook being a real dish (quality 4+ -> a category is meaningful). Holding both fires
# two independent rolls (additive). id-presence -> two copies of the same charm roll once
# (m4 multi-copy-safe). Base odds untouched (ADDITIVE).
# cap-J m4 SUPPRESS-AT-SOURCE: when the Hearthkeeper's Ladle OR the grand Cornucopia Tide is held on
# Adventurer/Pioneer, the loose C27/C30 bonus rolls are suppressed (the node fires the consolidated +2%
# roll below) so a re-acquired loose charm never adds a second bonus roll. #ckj_bsup gates the loose rolls.
scoreboard players set #ckj_bsup ec.cf_temp 0
execute unless score @s ec.difficulty matches 1 if items entity @s container.* *[custom_data~{hearthkeepers_ladle:true}] run scoreboard players set #ckj_bsup ec.cf_temp 1
execute unless score @s ec.difficulty matches 1 if items entity @s weapon.offhand *[custom_data~{hearthkeepers_ladle:true}] run scoreboard players set #ckj_bsup ec.cf_temp 1
execute unless score @s ec.difficulty matches 1 if items entity @s container.* *[custom_data~{cornucopia_tide:true}] run scoreboard players set #ckj_bsup ec.cf_temp 1
execute unless score @s ec.difficulty matches 1 unless items entity @s container.* *[custom_data~{cornucopia_tide:true}] unless items entity @s weapon.offhand *[custom_data~{cornucopia_tide:true}] if entity @s[tag=ec.sat_cornucopia_tide] run scoreboard players set #ckj_bsup ec.cf_temp 1
execute unless score @s ec.difficulty matches 1 if items entity @s weapon.offhand *[custom_data~{cornucopia_tide:true}] run scoreboard players set #ckj_bsup ec.cf_temp 1
execute unless score #ckj_bsup ec.cf_temp matches 1 if score @s ec.ck_quality matches 4.. if score @s ec.ck_art_cat matches 1..3 if items entity @s container.* *[custom_data~{artifact:"harvest_censer"}] store result score #ckj_cen ec.cf_temp run random value 1..100
execute unless score #ckj_bsup ec.cf_temp matches 1 if score @s ec.ck_quality matches 4.. if score @s ec.ck_art_cat matches 1..3 unless items entity @s container.* *[custom_data~{artifact:"harvest_censer"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"harvest_censer"}] if entity @s[tag=ec.sat_harvest_censer] store result score #ckj_cen ec.cf_temp run random value 1..100
execute unless score #ckj_bsup ec.cf_temp matches 1 if score @s ec.ck_quality matches 4.. if score @s ec.ck_art_cat matches 1..3 if items entity @s container.* *[custom_data~{artifact:"harvest_censer"}] if score #ckj_cen ec.cf_temp matches 1..2 run function evercraft:cooking/artifacts/roll_artifact
execute unless score #ckj_bsup ec.cf_temp matches 1 if score @s ec.ck_quality matches 4.. if score @s ec.ck_art_cat matches 1..3 unless items entity @s container.* *[custom_data~{artifact:"harvest_censer"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"harvest_censer"}] if entity @s[tag=ec.sat_harvest_censer] if score #ckj_cen ec.cf_temp matches 1..2 run function evercraft:cooking/artifacts/roll_artifact
execute unless score #ckj_bsup ec.cf_temp matches 1 if score @s ec.ck_quality matches 4.. if score @s ec.ck_art_cat matches 1..3 unless items entity @s container.* *[custom_data~{artifact:"harvest_censer"}] if items entity @s weapon.offhand *[custom_data~{artifact:"harvest_censer"}] store result score #ckj_cen ec.cf_temp run random value 1..100
execute unless score #ckj_bsup ec.cf_temp matches 1 if score @s ec.ck_quality matches 4.. if score @s ec.ck_art_cat matches 1..3 unless items entity @s container.* *[custom_data~{artifact:"harvest_censer"}] if items entity @s weapon.offhand *[custom_data~{artifact:"harvest_censer"}] if score #ckj_cen ec.cf_temp matches 1..2 run function evercraft:cooking/artifacts/roll_artifact
execute unless score #ckj_bsup ec.cf_temp matches 1 if score @s ec.ck_quality matches 4.. if score @s ec.ck_art_cat matches 1..3 if items entity @s container.* *[custom_data~{artifact:"cornucopia_crucible"}] store result score #ckj_cru ec.cf_temp run random value 1..100
execute unless score #ckj_bsup ec.cf_temp matches 1 if score @s ec.ck_quality matches 4.. if score @s ec.ck_art_cat matches 1..3 unless items entity @s container.* *[custom_data~{artifact:"cornucopia_crucible"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"cornucopia_crucible"}] if entity @s[tag=ec.sat_cornucopia_crucible] store result score #ckj_cru ec.cf_temp run random value 1..100
execute unless score #ckj_bsup ec.cf_temp matches 1 if score @s ec.ck_quality matches 4.. if score @s ec.ck_art_cat matches 1..3 if items entity @s container.* *[custom_data~{artifact:"cornucopia_crucible"}] if score #ckj_cru ec.cf_temp matches 1..2 run function evercraft:cooking/artifacts/roll_artifact
execute unless score #ckj_bsup ec.cf_temp matches 1 if score @s ec.ck_quality matches 4.. if score @s ec.ck_art_cat matches 1..3 unless items entity @s container.* *[custom_data~{artifact:"cornucopia_crucible"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"cornucopia_crucible"}] if entity @s[tag=ec.sat_cornucopia_crucible] if score #ckj_cru ec.cf_temp matches 1..2 run function evercraft:cooking/artifacts/roll_artifact
execute unless score #ckj_bsup ec.cf_temp matches 1 if score @s ec.ck_quality matches 4.. if score @s ec.ck_art_cat matches 1..3 unless items entity @s container.* *[custom_data~{artifact:"cornucopia_crucible"}] if items entity @s weapon.offhand *[custom_data~{artifact:"cornucopia_crucible"}] store result score #ckj_cru ec.cf_temp run random value 1..100
execute unless score #ckj_bsup ec.cf_temp matches 1 if score @s ec.ck_quality matches 4.. if score @s ec.ck_art_cat matches 1..3 unless items entity @s container.* *[custom_data~{artifact:"cornucopia_crucible"}] if items entity @s weapon.offhand *[custom_data~{artifact:"cornucopia_crucible"}] if score #ckj_cru ec.cf_temp matches 1..2 run function evercraft:cooking/artifacts/roll_artifact
# cap-J CONSOLIDATED bonus-material roll (+2%): the Hearthkeeper's Ladle + the grand Cornucopia Tide each
# fire ONE consolidated +2% extra cook-artifact draw (the C27 Harvest Censer + C30 Cornucopia Crucible
# bonus rolls folded into one — the loot lore "+2% extra draw on a finished cook"). id-presence -> two
# copies fire one roll. The grand supersedes the Ladle (guarded `unless` the grand) so only one +2% fires.
execute if score @s ec.ck_quality matches 4.. if score @s ec.ck_art_cat matches 1..3 if items entity @s container.* *[custom_data~{cornucopia_tide:true}] store result score #ckj_cap ec.cf_temp run random value 1..100
execute if score @s ec.ck_quality matches 4.. if score @s ec.ck_art_cat matches 1..3 unless items entity @s container.* *[custom_data~{cornucopia_tide:true}] unless items entity @s weapon.offhand *[custom_data~{cornucopia_tide:true}] if entity @s[tag=ec.sat_cornucopia_tide] store result score #ckj_cap ec.cf_temp run random value 1..100
execute if score @s ec.ck_quality matches 4.. if score @s ec.ck_art_cat matches 1..3 unless items entity @s container.* *[custom_data~{cornucopia_tide:true}] if items entity @s weapon.offhand *[custom_data~{cornucopia_tide:true}] store result score #ckj_cap ec.cf_temp run random value 1..100
execute if score @s ec.ck_quality matches 4.. if score @s ec.ck_art_cat matches 1..3 unless items entity @s container.* *[custom_data~{cornucopia_tide:true}] unless items entity @s weapon.offhand *[custom_data~{cornucopia_tide:true}] unless entity @s[tag=ec.sat_cornucopia_tide] if items entity @s container.* *[custom_data~{hearthkeepers_ladle:true}] store result score #ckj_cap ec.cf_temp run random value 1..100
execute if score @s ec.ck_quality matches 4.. if score @s ec.ck_art_cat matches 1..3 unless items entity @s container.* *[custom_data~{cornucopia_tide:true}] unless items entity @s weapon.offhand *[custom_data~{cornucopia_tide:true}] unless entity @s[tag=ec.sat_cornucopia_tide] unless items entity @s container.* *[custom_data~{hearthkeepers_ladle:true}] if items entity @s weapon.offhand *[custom_data~{hearthkeepers_ladle:true}] store result score #ckj_cap ec.cf_temp run random value 1..100
execute if score @s ec.ck_quality matches 4.. if score @s ec.ck_art_cat matches 1..3 if score #ckj_cap ec.cf_temp matches 1..2 if items entity @s container.* *[custom_data~{cornucopia_tide:true}] run function evercraft:cooking/artifacts/roll_artifact
execute if score @s ec.ck_quality matches 4.. if score @s ec.ck_art_cat matches 1..3 if score #ckj_cap ec.cf_temp matches 1..2 unless items entity @s container.* *[custom_data~{cornucopia_tide:true}] unless items entity @s weapon.offhand *[custom_data~{cornucopia_tide:true}] if entity @s[tag=ec.sat_cornucopia_tide] run function evercraft:cooking/artifacts/roll_artifact
execute if score @s ec.ck_quality matches 4.. if score @s ec.ck_art_cat matches 1..3 if score #ckj_cap ec.cf_temp matches 1..2 unless items entity @s container.* *[custom_data~{cornucopia_tide:true}] if items entity @s weapon.offhand *[custom_data~{cornucopia_tide:true}] run function evercraft:cooking/artifacts/roll_artifact
execute if score @s ec.ck_quality matches 4.. if score @s ec.ck_art_cat matches 1..3 if score #ckj_cap ec.cf_temp matches 1..2 unless items entity @s container.* *[custom_data~{cornucopia_tide:true}] unless items entity @s weapon.offhand *[custom_data~{cornucopia_tide:true}] unless entity @s[tag=ec.sat_cornucopia_tide] if items entity @s container.* *[custom_data~{hearthkeepers_ladle:true}] run function evercraft:cooking/artifacts/roll_artifact
execute if score @s ec.ck_quality matches 4.. if score @s ec.ck_art_cat matches 1..3 if score #ckj_cap ec.cf_temp matches 1..2 unless items entity @s container.* *[custom_data~{cornucopia_tide:true}] unless items entity @s weapon.offhand *[custom_data~{cornucopia_tide:true}] unless entity @s[tag=ec.sat_cornucopia_tide] unless items entity @s container.* *[custom_data~{hearthkeepers_ladle:true}] if items entity @s weapon.offhand *[custom_data~{hearthkeepers_ladle:true}] run function evercraft:cooking/artifacts/roll_artifact

# --- Now run the actual cook dispatch (restoring saved slot/cat) ---
scoreboard players operation #ck_slot ec.temp = @s ec.ck_saved_slot
scoreboard players operation @s ec.ck_cat = @s ec.ck_saved_cat
function evercraft:cooking/recipes/cook_dispatch

# --- Cleanup ---
tag @s remove CK.Cooking
scoreboard players set @s ec.ck_phase 0

# --- Close menu ---
function evercraft:cooking/gui/close
