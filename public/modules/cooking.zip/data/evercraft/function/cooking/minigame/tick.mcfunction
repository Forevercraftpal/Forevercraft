# ============================================================
# Chef's Touch Minigame — Phase Dispatcher
# Runs as the player with CK.Cooking tag
# Routes to current phase's tick function
# ============================================================

# Safety: if no minigame entities nearby (disconnect/reload recovery), force-close
execute unless entity @e[type=text_display,tag=CK.MiniEl,distance=..10] unless entity @e[type=interaction,tag=CK.MiniEl,distance=..10] run return run function evercraft:cooking/gui/close

# Safety: if phase is 0 or invalid, clean up stuck state
execute unless score @s ec.ck_phase matches 1..3 run return run function evercraft:cooking/gui/close

# Wiring Audit #26 H4: poll the [Close] button DURING the minigame. check_clicks is bypassed
# while CK.Cooking (gui/tick:15), so the visible [Close] was otherwise dead through phases 1-3.
# @s = the cooking player; stamp #gui_check from them so the session gate matches the button.
scoreboard players operation #gui_check ec.temp = @s adv.gui_session
execute as @e[type=interaction,tag=CK.CloseClick,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction on target run function evercraft:cooking/gui/close
execute as @e[type=interaction,tag=CK.CloseClick,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction run data remove entity @s interaction
# If the close fired, the player no longer has CK.Cooking — bail before dispatching a phase.
execute unless entity @s[tag=CK.Cooking] run return 0

execute if score @s ec.ck_phase matches 1 run function evercraft:cooking/minigame/phase1_chop/tick
execute if score @s ec.ck_phase matches 2 run function evercraft:cooking/minigame/phase2_simmer/tick
execute if score @s ec.ck_phase matches 3 run function evercraft:cooking/minigame/phase3_plate/tick
