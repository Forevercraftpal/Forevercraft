# Chef's Touch — Result: FLAVORFUL (Quality 8-11)
# +25% buff duration
data modify storage evercraft:notify stage.c set value [{text:"★ FLAVORFUL ",color:"green",bold:true},{text:"— +25% buff duration!",color:"yellow"},{text:" ★",color:"green",bold:true}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
# FX — culinary triad chord + green aroma (gated)
execute at @s run function evercraft:fx/cook/result_flavorful

# Cooking artifact roll
execute if score @s ec.ck_art_cat matches 1..3 run function evercraft:cooking/artifacts/check_artifact_roll
