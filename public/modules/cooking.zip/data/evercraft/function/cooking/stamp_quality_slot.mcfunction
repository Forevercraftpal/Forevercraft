# Cooking — stamp cook_quality onto the meal in $(slot) (macro {slot, q}).
# MC 26.2 (1.21.5+): `data modify entity @s Inventory[...]` is read-only, so the quality is merged onto
# the meal ON a hopper-minecart (a writable container) and the item is swapped back via /item. MERGE
# (not set) preserves the meal's existing custom_data (ec_meal / meal_id / etc.).
data modify entity @e[type=hopper_minecart,tag=ec.ck_qcart,limit=1] Items set value []
kill @e[type=hopper_minecart,tag=ec.ck_qcart]
execute at @s run summon hopper_minecart ~ ~ ~ {Tags:["ec.ck_qcart"],Enabled:0b}
$item replace entity @e[type=hopper_minecart,tag=ec.ck_qcart,limit=1,sort=nearest] container.0 from entity @s $(slot)
$data modify entity @e[type=hopper_minecart,tag=ec.ck_qcart,limit=1] Items[0].components."minecraft:custom_data" merge value {cook_quality:$(q),cq_done:true}
$item replace entity @s $(slot) from entity @e[type=hopper_minecart,tag=ec.ck_qcart,limit=1,sort=nearest] container.0
data modify entity @e[type=hopper_minecart,tag=ec.ck_qcart,limit=1] Items set value []
kill @e[type=hopper_minecart,tag=ec.ck_qcart]
