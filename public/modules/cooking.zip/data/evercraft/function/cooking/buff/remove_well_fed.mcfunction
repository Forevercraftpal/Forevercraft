# Remove Well-Fed buff
attribute @s minecraft:luck modifier remove evercraft:well_fed
scoreboard players reset @s ec.ck_wellfed
data modify storage evercraft:notify stage.c set value [{text:"Your Well-Fed buff has worn off.",color:"gray"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
