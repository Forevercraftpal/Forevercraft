# Eat Voidsalt Stew — Night Vision for 120s + Well-Fed
advancement revoke @s only evercraft:cooking/eat_spiced_void

attribute @s minecraft:luck modifier remove evercraft:well_fed
attribute @s minecraft:luck modifier remove evercraft:fortune_meal

effect give @s minecraft:night_vision 120 0 true
execute if score @s adv.pa_culi3 matches 1 run effect give @s minecraft:night_vision 240 0 true

attribute @s minecraft:luck modifier add evercraft:well_fed 0.5 add_value
scoreboard players set @s ec.ck_wellfed 2400

data modify storage evercraft:notify stage.c set value [{text:"Night Vision",color:"dark_purple"},{text:" for 120s! ",color:"gray"},{text:"(+0.5 DR Well-Fed)",color:"gold"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute at @s run function evercraft:fx/cook/eat_basic
scoreboard players set @s ec.meal_ate 97
function evercraft:cooking/buff/adjust_wellfed_bonus
