# Eat Fortune Hearty Meal — +0.5 DR for 60s + Well-Fed
advancement revoke @s only evercraft:cooking/eat_fortune_hearty

attribute @s minecraft:luck modifier remove evercraft:well_fed
attribute @s minecraft:luck modifier remove evercraft:fortune_meal

attribute @s minecraft:luck modifier add evercraft:fortune_meal 0.5 add_value
scoreboard players set @s ec.ck_fortune 1200

attribute @s minecraft:luck modifier add evercraft:well_fed 0.5 add_value
scoreboard players set @s ec.ck_wellfed 1200

data modify storage evercraft:notify stage.c set value [{text:"+0.5 Dream Rate",color:"light_purple"},{text:" for 60s! ",color:"gray"},{text:"(+0.5 DR Well-Fed)",color:"gold"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute at @s run function evercraft:fx/cook/eat_basic
scoreboard players set @s ec.meal_ate 13
function evercraft:cooking/buff/adjust_wellfed_bonus
