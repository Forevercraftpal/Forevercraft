# Cooking Preservation — Handle death with preserve counter
# Called from tick.mcfunction when player dies with ec.ck_preserve >= 1
# Tags player for respawn restoration

# Decrement preserve counter
scoreboard players remove @s ec.ck_preserve 1

# Tag for respawn restoration (effects will be re-applied next tick when alive)
tag @s add CK.PreserveRestore

# Feedback (shown on respawn)
data modify storage evercraft:notify stage.c set value [{text:"Your preserved meal endures beyond death!",color:"aqua"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
