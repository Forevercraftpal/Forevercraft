# Deferred Chef's Touch quality apply — Wiring Audit #26 Q4 (Joseph).
# Runs the tick AFTER an eat, for players tagged CK.JustAte. By now BOTH the meal_id eat_*
# advancement (which set ec.ck_wellfed via apply_<meal> -> adjust_wellfed_bonus) AND the
# cook_quality eat_cqN advancement (which set ec.ck_quality_mod from the ITEM) have fired,
# regardless of their order — so scaling here is ordering-safe. apply_quality_scaling reads
# ec.ck_quality_mod, scales ec.ck_wellfed (0->x0.5, 2->x1.25, 3->x1.5, 1->no-op), and resets
# ec.ck_quality_mod to 1 for the next eat.
# Cooking-FX: the TRUE-quality meal flourish — ec.ck_quality_mod is accurate here (both eat
# advancements resolved), and this runs BEFORE apply_quality_scaling resets it. The apply-time
# eat_* presets play the class identity; this adds the reliable quality escalation.
execute at @s run function evercraft:fx/cook/eat_quality
function evercraft:cooking/buff/apply_quality_scaling
tag @s remove CK.JustAte
