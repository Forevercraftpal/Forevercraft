# Eat Emberglow Confit — Fire Res 300s + Strength I 180s + Absorption II 180s + Well-Fed [PLAN-nest §5]
advancement revoke @s only evercraft:cooking/eat_nest_ember

attribute @s minecraft:luck modifier remove evercraft:well_fed
attribute @s minecraft:luck modifier remove evercraft:fortune_meal

effect give @s minecraft:fire_resistance 300 0 true
effect give @s minecraft:strength 180 0 true
effect give @s minecraft:absorption 180 1 true

attribute @s minecraft:luck modifier add evercraft:well_fed 0.5 add_value
scoreboard players set @s ec.ck_wellfed 3600

data modify storage evercraft:notify stage.c set value [{text:"Fire Res 300s + Strength I + Absorption II",color:"red"},{text:" for 180s! ",color:"gray"},{text:"(+0.5 DR Well-Fed)",color:"gold"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute at @s run function evercraft:fx/cook/eat_basic
scoreboard players set @s ec.meal_ate 81
function evercraft:cooking/buff/adjust_wellfed_bonus
