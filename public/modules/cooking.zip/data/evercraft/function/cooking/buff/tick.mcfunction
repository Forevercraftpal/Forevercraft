# ============================================================
# Cooking Buff Timer — 1s scheduled tick
# Counts down Well-Fed and Fortune buff timers
# ============================================================

# Gate: skip if no players online
execute unless entity @a run return run schedule function evercraft:cooking/buff/tick 1s replace

# Well-Fed timer countdown (20 ticks = 1 second)
execute as @a[scores={ec.ck_wellfed=1..}] run scoreboard players remove @s ec.ck_wellfed 20
execute as @a[scores={ec.ck_wellfed=..0}] run function evercraft:cooking/buff/remove_well_fed

# Fortune meal timer countdown
execute as @a[scores={ec.ck_fortune=1..}] run scoreboard players remove @s ec.ck_fortune 20
execute as @a[scores={ec.ck_fortune=..0}] run function evercraft:cooking/buff/remove_fortune

# Chef's Eternal Grace — doubled-cooking-quality window countdown (read by cooking/minigame/resolve).
# On expiry: one actionbar notice, then park at -100 (outside both gates) so it never re-fires or re-doubles.
execute as @a[scores={ec.ck_x2=1..}] run scoreboard players remove @s ec.ck_x2 20
# (Wave 1, 2026-06-10: expiry notices routed through the notify queue — effectively one-shot.)
# Perf retrofit L4 (2026-06-14): only pre-stage the expiry notice when someone is actually in the
# expiry window (was running the data-modify + #ndur set unconditionally every second).
execute if entity @a[scores={ec.ck_x2=-19..0}] run data modify storage evercraft:notify stage.c set value [{text:"The Eternal Grace fades — cooking quality returns to normal.",color:"gray"}]
execute if entity @a[scores={ec.ck_x2=-19..0}] run scoreboard players set #ndur ec.temp 45
execute as @a[scores={ec.ck_x2=-19..0}] run function evercraft:util/notify/emit
execute as @a[scores={ec.ck_x2=-19..0}] run scoreboard players set @s ec.ck_x2 -100

# Artisan's Blessing — doubled-artifact-find window countdown (read by cooking/artifacts/check_artifact_roll).
execute as @a[scores={ec.ck_art_x2=1..}] run scoreboard players remove @s ec.ck_art_x2 20
execute if entity @a[scores={ec.ck_art_x2=-19..0}] run data modify storage evercraft:notify stage.c set value [{text:"The Artisan's Blessing fades — artifact-find returns to normal.",color:"gray"}]
execute if entity @a[scores={ec.ck_art_x2=-19..0}] run scoreboard players set #ndur ec.temp 45
execute as @a[scores={ec.ck_art_x2=-19..0}] run function evercraft:util/notify/emit
execute as @a[scores={ec.ck_art_x2=-19..0}] run scoreboard players set @s ec.ck_art_x2 -100

# Cooking Utensil discovery flag. Initialize unset players to 0 so the once-per-player gate works,
# then mark anyone already holding/carrying a utensil as found (covers already-crafted owners) so
# crate rolls never hand them a duplicate. Cheap: once flagged (=1) the player drops out of the
# scores gate and the per-player `if items` probe stops running.
execute as @a unless score @s ec.found_utensil matches -2147483648..2147483647 run scoreboard players set @s ec.found_utensil 0
execute as @a[scores={ec.found_utensil=0}] if items entity @s container.* *[custom_data~{cooking_utensil:true}] run scoreboard players set @s ec.found_utensil 1
execute as @a[scores={ec.found_utensil=0}] if items entity @s weapon.offhand *[custom_data~{cooking_utensil:true}] run scoreboard players set @s ec.found_utensil 1

# Re-schedule
schedule function evercraft:cooking/buff/tick 1s replace
