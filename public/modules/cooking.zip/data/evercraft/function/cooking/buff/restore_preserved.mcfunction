# Cooking Preservation — Restore buffs after death
# Called on tick for players with CK.PreserveRestore tag who are alive
# Re-applies Well-Fed attribute modifier (may have been cleared by death)

tag @s remove CK.PreserveRestore

# Re-apply Well-Fed modifier (death may clear attribute modifiers in some cases)
attribute @s minecraft:luck modifier remove evercraft:well_fed
attribute @s minecraft:luck modifier add evercraft:well_fed 0.5 add_value

# Feedback
data modify storage evercraft:notify stage.c set value [{text:"Well-Fed buff restored!",color:"aqua"},{text:" (",color:"gray"},{score:{name:"@s",objective:"ec.ck_preserve"},color:"yellow"},{text:" charges remaining)",color:"gray"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute at @s run function evercraft:fx/cook/eat_revive
