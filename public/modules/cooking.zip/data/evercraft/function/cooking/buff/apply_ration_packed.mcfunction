# Eat Packed Lunch — Well-Fed only (no combat effect)
# Laborer ration: longer duration for laborer feeding
advancement revoke @s only evercraft:cooking/eat_ration_packed

# Clear any existing cooking buffs first
attribute @s minecraft:luck modifier remove evercraft:well_fed
attribute @s minecraft:luck modifier remove evercraft:fortune_meal

# No player combat effect — rations are for laborer feeding

# Apply Well-Fed (+0.5 DR)
attribute @s minecraft:luck modifier add evercraft:well_fed 0.5 add_value
scoreboard players set @s ec.ck_wellfed 1200

# Feedback
data modify storage evercraft:notify stage.c set value [{text:"Well-Fed",color:"yellow"},{text:" for 60s! ",color:"gray"},{text:"(Great for laborers)",color:"#AB47BC"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute at @s run function evercraft:fx/cook/eat_basic
scoreboard players set @s ec.meal_ate 41
function evercraft:cooking/buff/adjust_wellfed_bonus
