# Remove Fortune meal buff
attribute @s minecraft:luck modifier remove evercraft:fortune_meal
scoreboard players reset @s ec.ck_fortune
data modify storage evercraft:notify stage.c set value [{text:"Your Fortune meal buff has worn off.",color:"gray"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
