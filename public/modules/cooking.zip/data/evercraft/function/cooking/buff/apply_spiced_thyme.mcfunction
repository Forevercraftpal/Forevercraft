# Eat Thyme Roast — Regeneration I for 30s + Well-Fed
advancement revoke @s only evercraft:cooking/eat_spiced_thyme

attribute @s minecraft:luck modifier remove evercraft:well_fed
attribute @s minecraft:luck modifier remove evercraft:fortune_meal

effect give @s minecraft:regeneration 30 0 true
execute if score @s adv.pa_culi3 matches 1 run effect give @s minecraft:regeneration 60 0 true

attribute @s minecraft:luck modifier add evercraft:well_fed 0.5 add_value
scoreboard players set @s ec.ck_wellfed 2400

data modify storage evercraft:notify stage.c set value [{text:"Regeneration I",color:"light_purple"},{text:" for 30s! ",color:"gray"},{text:"(+0.5 DR Well-Fed)",color:"gold"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute at @s run function evercraft:fx/cook/eat_basic
scoreboard players set @s ec.meal_ate 92
function evercraft:cooking/buff/adjust_wellfed_bonus
