# Eat Tidal Glaze Cake — Dolphin's Grace + Water Breathing 90s + Well-Fed [PLAN-nest §5]
advancement revoke @s only evercraft:cooking/eat_nest_tidal

attribute @s minecraft:luck modifier remove evercraft:well_fed
attribute @s minecraft:luck modifier remove evercraft:fortune_meal

effect give @s minecraft:dolphins_grace 90 0 true
effect give @s minecraft:water_breathing 90 0 true

attribute @s minecraft:luck modifier add evercraft:well_fed 0.5 add_value
scoreboard players set @s ec.ck_wellfed 3600

data modify storage evercraft:notify stage.c set value [{text:"Dolphin's Grace + Water Breathing",color:"aqua"},{text:" for 90s! ",color:"gray"},{text:"(+0.5 DR Well-Fed)",color:"gold"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute at @s run function evercraft:fx/cook/eat_basic
scoreboard players set @s ec.meal_ate 80
function evercraft:cooking/buff/adjust_wellfed_bonus
