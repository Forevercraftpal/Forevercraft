# Eat a cook_quality:2 meal — Wiring Audit #26 Q4 (Joseph): quality read from the ITEM.
# Fires alongside the meal_id eat_* advancement (any order). Record quality + flag; the
# per-tick deferred hook (apply_deferred_quality) does the well-fed scaling next tick, so it
# is immune to advancement-reward ordering relative to apply_<meal>.
advancement revoke @s only evercraft:cooking/eat_cq2
scoreboard players set @s ec.ck_quality_mod 2
tag @s add CK.JustAte
