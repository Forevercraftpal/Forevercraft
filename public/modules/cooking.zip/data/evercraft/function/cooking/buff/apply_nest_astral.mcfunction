# Eat Astral Honey Ambrosia — Regen IV + Absorption IV 180s + Dream Rate +1.5 / 6 min [PLAN-nest §5]
# R8 (no Dream-Rate stacking): reuses apply_spirit_voidfin's spirit_meal clear-block — the +1.5 DR
# uses the SAME evercraft:spirit_meal modifier slot the spirit-fish meals use, and we remove it
# first, so eating this AFTER a Voidfin Steak (or vice-versa) REPLACES rather than stacks the DR.
advancement revoke @s only evercraft:cooking/eat_nest_astral

# Clear any existing cooking buffs (mirror apply_spirit_voidfin:5-7 — the spirit_meal remove is the
# R8 anti-stack guard).
attribute @s minecraft:luck modifier remove evercraft:well_fed
attribute @s minecraft:luck modifier remove evercraft:fortune_meal
attribute @s minecraft:luck modifier remove evercraft:spirit_meal

# Combat/recovery effects.
effect give @s minecraft:regeneration 180 3 true
effect give @s minecraft:absorption 180 3 true

# Apply Astral DR modifier (+1.5 DR for 6 min via the shared ck_wellfed timer).
attribute @s minecraft:luck modifier add evercraft:spirit_meal 1.5 add_value
scoreboard players set @s ec.ck_wellfed 7200

# Also apply standard Well-Fed (mirror apply_spirit_voidfin).
attribute @s minecraft:luck modifier add evercraft:well_fed 0.5 add_value

# Feedback.
data modify storage evercraft:notify stage.c set value [{text:"Regen IV + Absorption IV",color:"green"},{text:" for 180s ",color:"gray"},{text:"+ ",color:"gray"},{text:"+1.5 Dream Rate",color:"dark_purple",bold:true},{text:" for 6 min!",color:"gray"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute at @s run function evercraft:fx/cook/eat_spirit
scoreboard players set @s ec.meal_ate 82
function evercraft:cooking/buff/adjust_wellfed_bonus
