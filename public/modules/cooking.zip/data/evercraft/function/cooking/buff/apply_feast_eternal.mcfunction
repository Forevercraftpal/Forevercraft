# Eat Eternal Feast — AoE ALL platter buffs combined (10 min)
# Buffs all players within 32 blocks (double radius)
advancement revoke @s only evercraft:cooking/eat_feast_eternal

# Clear any existing cooking buffs first
attribute @s minecraft:luck modifier remove evercraft:well_fed
attribute @s minecraft:luck modifier remove evercraft:fortune_meal

# AoE buff — all nearby players (32 blocks!)
tag @s add CK.FeastSelf
execute at @s run effect give @a[distance=..32,tag=!CK.FeastSelf] minecraft:strength 600 0 true
execute at @s run effect give @a[distance=..32,tag=!CK.FeastSelf] minecraft:resistance 600 0 true
execute at @s run effect give @a[distance=..32,tag=!CK.FeastSelf] minecraft:speed 600 1 true
execute at @s run effect give @a[distance=..32,tag=!CK.FeastSelf] minecraft:night_vision 600 0 true
execute at @s run effect give @a[distance=..32,tag=!CK.FeastSelf] minecraft:haste 600 1 true
execute at @s run effect give @a[distance=..32,tag=!CK.FeastSelf] minecraft:fire_resistance 600 0 true
data modify storage evercraft:notify stage.c set value [{text:"ETERNAL FEAST! ",color:"light_purple",bold:true},{text:"ALL buffs for 10 min!",color:"gray"}]
scoreboard players set #ndur ec.temp 45
execute at @s as @a[distance=..32,tag=!CK.FeastSelf] run function evercraft:util/notify/emit
tag @s remove CK.FeastSelf

# Self buff (all effects)
effect give @s minecraft:strength 600 0 true
effect give @s minecraft:resistance 600 0 true
effect give @s minecraft:speed 600 1 true
effect give @s minecraft:night_vision 600 0 true
effect give @s minecraft:haste 600 1 true
effect give @s minecraft:fire_resistance 600 0 true
execute if score @s adv.pa_culi3 matches 1 run effect give @s minecraft:strength 1200 0 true
execute if score @s adv.pa_culi3 matches 1 run effect give @s minecraft:resistance 1200 0 true
execute if score @s adv.pa_culi3 matches 1 run effect give @s minecraft:speed 1200 1 true
execute if score @s adv.pa_culi3 matches 1 run effect give @s minecraft:night_vision 1200 0 true
execute if score @s adv.pa_culi3 matches 1 run effect give @s minecraft:haste 1200 1 true
execute if score @s adv.pa_culi3 matches 1 run effect give @s minecraft:fire_resistance 1200 0 true

# Apply Well-Fed (+0.5 DR)
attribute @s minecraft:luck modifier add evercraft:well_fed 0.5 add_value
scoreboard players set @s ec.ck_wellfed 1200

# Feedback
data modify storage evercraft:notify stage.c set value [{text:"ETERNAL FEAST! ",color:"light_purple",bold:true},{text:"ALL buffs for 10 min!",color:"gray"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute at @s run function evercraft:fx/cook/eat_feast
scoreboard players set @s ec.meal_ate 53
function evercraft:cooking/buff/adjust_wellfed_bonus
