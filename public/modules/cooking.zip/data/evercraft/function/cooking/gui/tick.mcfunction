# ============================================================
# Campfire Kitchen GUI — Per-Tick
# Runs as each player with CK.InMenu tag (from tick.mcfunction)
# Validates menu state and dispatches click checks
# ============================================================

# Must still have the tag
execute unless entity @s[tag=CK.InMenu] run return 0

# Close-trigger depends on how the menu was opened:
#   utensil session  -> close when the cooking utensil leaves the hand (item-triggered, as before).
#   STATION session  -> opened at a Stove (the oven is the heat); stays open WITHOUT a utensil and
#                       instead closes when the player walks away from the stove (Joseph 2026-06-21).
execute unless entity @s[tag=CK.Station] unless predicate evercraft:cooking/holding_utensil run return run function evercraft:cooking/gui/close
execute if entity @s[tag=CK.Station] unless entity @e[type=marker,tag=ec.dec_anchor,nbt={data:{id:"kitchen_stove"}},distance=..4] run return run function evercraft:cooking/gui/close

# Unified UI-click FX (Joseph 2026-06-05): play the gated cue ONCE on a CK.MenuEl click — only outside the
# minigame (CK.Cooking has its own timing-click feel; we don't blip on those). Fires before check_clicks.
execute unless entity @s[tag=CK.Cooking] if entity @e[type=interaction,tag=CK.MenuEl,distance=..6,nbt={interaction:{}},limit=1] run function evercraft:fx/ui/click

# If in minigame, dispatch to minigame tick instead of normal clicks
execute if entity @s[tag=CK.Cooking] run return run function evercraft:cooking/minigame/tick

# Check for clicks
function evercraft:cooking/gui/check_clicks
