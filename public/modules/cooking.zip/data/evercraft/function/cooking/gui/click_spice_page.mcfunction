# ============================================================
# Campfire Kitchen GUI — Spiced Recipe-Page Toggle Click Handler
# Runs as the interaction entity
# Flips ec.ck_spage 0<->1 (Spiced tab only) and re-renders the recipe rows.
# Only meaningful on cat 11; the if-cat-11 gate makes it inert elsewhere even
# though the interaction entity is always present.
# ============================================================

data remove entity @s interaction
scoreboard players set #ck_clicked ec.temp 1

# Toggle the recipe page on the clicking player (session-gated, Spiced tab only).
execute as @a[tag=CK.InMenu,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if score @s ec.ck_cat matches 11 run function evercraft:cooking/gui/toggle_spice_page
