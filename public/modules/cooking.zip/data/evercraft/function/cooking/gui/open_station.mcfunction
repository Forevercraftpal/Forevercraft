# ============================================================
# Campfire Kitchen GUI — Open from a STATION (a placed Stove)
# Runs as the player, at the player.
# ============================================================
# The Stove furniture's lit oven IS the heat, so a station-opened menu stays open WITHOUT a
# cooking utensil in hand (unlike a utensil-opened session). It closes when the player walks
# away from the stove instead — see cooking/gui/tick. Joseph 2026-06-21 (modular kitchen).
tag @s add CK.Station
function evercraft:cooking/gui/open
