# ============================================================
# Campfire Kitchen GUI — Refresh Recipe Displays
# Runs as the player
# Updates all 6 recipe name + ingredient displays for current category
# ============================================================

# Session handle for menu-entity selectors below (refresh always runs as the menu owner).
scoreboard players operation #gui_check ec.temp = @s adv.gui_session

# Initialize recipe discovery for new players
execute unless score @s ck.disc_init matches 1 run function evercraft:cooking/discovery/init

# Spiced recipe-page state (cat 11 only): reset to page 0 on any non-Spiced tab and
# hide the page-toggle button there. refresh_spiced re-shows + labels it on cat 11.
# #gui_check = the refreshing player's session (set by callers before refresh).
execute unless score @s ec.ck_cat matches 11 run scoreboard players set @s ec.ck_spage 0
execute unless score @s ec.ck_cat matches 11 as @e[type=text_display,tag=CK.SpicePageText,distance=..5] if score @s adv.gui_session = #gui_check ec.temp run data modify entity @s text set value {"text":""}

execute if score @s ec.ck_cat matches 0 run function evercraft:cooking/gui/refresh_combat
execute if score @s ec.ck_cat matches 1 run function evercraft:cooking/gui/refresh_mining
execute if score @s ec.ck_cat matches 2 run function evercraft:cooking/gui/refresh_fortune
execute if score @s ec.ck_cat matches 3 run function evercraft:cooking/gui/refresh_wayfarer
execute if score @s ec.ck_cat matches 4 run function evercraft:cooking/gui/refresh_delicacy
execute if score @s ec.ck_cat matches 5 run function evercraft:cooking/gui/refresh_seasonal
execute if score @s ec.ck_cat matches 6 run function evercraft:cooking/gui/refresh_treats
execute if score @s ec.ck_cat matches 7 run function evercraft:cooking/gui/refresh_rations
execute if score @s ec.ck_cat matches 8 run function evercraft:cooking/gui/refresh_feast_platter
execute if score @s ec.ck_cat matches 9 run function evercraft:cooking/gui/refresh_preservation
execute if score @s ec.ck_cat matches 10 run function evercraft:cooking/gui/refresh_spirit
execute if score @s ec.ck_cat matches 11 run function evercraft:cooking/gui/refresh_spiced
