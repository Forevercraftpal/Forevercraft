# ============================================================
# Campfire Kitchen GUI — Open
# Runs as the player, at the player
# Spawns all GUI entities in front of the player
# ============================================================

# Tag player as in menu
# Menu Core: Y-displacement close anchor
# One-menu-at-a-time (2026-06-15): close any other open menu before this one claims
# ec.menu_active. Two overlapping menus share the @s adv.gui_session slot; the newer
# open orphans the older menu's session, so it can never consume its click -> stuck
# interaction NBT -> click-sound spam. force_close is idempotent (no-op when nothing open).
execute if entity @s[tag=ec.menu_active] run function evercraft:menu_core/force_close
tag @s add ec.menu_active
execute store result score @s ec.menu_open_y run data get entity @s Pos[1] 100

tag @s add CK.InMenu

# Default to Combat category (0)
scoreboard players set @s ec.ck_cat 0

# Initialize mode + tab page if never set
execute unless score @s ec.ck_mode matches 0..1 run scoreboard players set @s ec.ck_mode 0
execute unless score @s ec.ck_tab_page matches 0..1 run scoreboard players set @s ec.ck_tab_page 0

# --- Anchor Marker (tracks menu position) ---
execute at @s rotated ~ 0 positioned ^ ^2.05 ^1.8 run summon marker ~ ~ ~ {Tags:["CK.MenuEl","CK.Anchor"]}

# --- Background Panel ---
execute at @s rotated ~ 0 positioned ^ ^2.05 ^1.8 positioned ^0 ^-0.15 ^0 run summon item_display ~ ~ ~ {Tags:["CK.MenuEl","CK.MenuBG"],billboard:"center",item_display:"fixed",item:{id:"minecraft:black_stained_glass_pane",count:1},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,-0.02f],scale:[5.0f,3.2f,0.01f]}}

# --- Title (clickable — toggles cooking mode) ---
# Ownership-header label (MP-P3.6): foreign viewers see whose menu this is
# 26.1: {selector:} renders blank in text_display — bake @s's name to a $(owner) literal.
function evercraft:util/gui/owner_name
execute at @s rotated ~ 0 positioned ^ ^2.23 ^1.8 run function evercraft:cooking/gui/open_nm with storage evercraft:scorebake args
execute at @s rotated ~ 0 positioned ^ ^2.05 ^1.8 positioned ^0 ^0.70 ^0 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["CK.MenuEl","CK.Title"],billboard:"center",text:[{"text":"✦ ","color":"gold"},{"text":"Campfire Kitchen","color":"gold","bold":true},{"text":" ✦","color":"gold"}],transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.608f,0.608f,0.608f]}}

# --- Mode Subtitle (centered below title, clickable) ---
execute if score @s ec.ck_mode matches 0 at @s rotated ~ 0 positioned ^ ^2.05 ^1.8 positioned ^0 ^0.61 ^0 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["CK.MenuEl","CK.ModeText"],billboard:"center",text:[{"text":"[ ","color":"gray"},{"text":"Quick Cook","color":"green"},{"text":" ]","color":"gray"}],transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.3f,0.3f,0.3f]}}
execute if score @s ec.ck_mode matches 1 at @s rotated ~ 0 positioned ^ ^2.05 ^1.8 positioned ^0 ^0.61 ^0 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["CK.MenuEl","CK.ModeText"],billboard:"center",text:[{"text":"[ ","color":"gray"},{"text":"Chef's Touch","color":"gold","bold":true},{"text":" ]","color":"gray"}],transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.3f,0.3f,0.3f]}}
# Interaction covers title + subtitle area
# [strip] ?: 0.8w split into 7 x 0.12 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute at @s rotated ~ 0 positioned ^-0.34 ^2.07 ^1.8 positioned ^0 ^0.635 ^0 run summon interaction ~ ~ ~ {Tags:["CK.MenuEl","CK.ModeClick"],width:0.12f,height:0.09f,response:1b}
execute at @s rotated ~ 0 positioned ^-0.2267 ^2.07 ^1.8 positioned ^0 ^0.635 ^0 run summon interaction ~ ~ ~ {Tags:["CK.MenuEl","CK.ModeClick"],width:0.12f,height:0.09f,response:1b}
execute at @s rotated ~ 0 positioned ^-0.1133 ^2.07 ^1.8 positioned ^0 ^0.635 ^0 run summon interaction ~ ~ ~ {Tags:["CK.MenuEl","CK.ModeClick"],width:0.12f,height:0.09f,response:1b}
execute at @s rotated ~ 0 positioned ^0 ^2.07 ^1.8 positioned ^0 ^0.635 ^0 run summon interaction ~ ~ ~ {Tags:["CK.MenuEl","CK.ModeClick"],width:0.12f,height:0.09f,response:1b}
execute at @s rotated ~ 0 positioned ^0.1133 ^2.07 ^1.8 positioned ^0 ^0.635 ^0 run summon interaction ~ ~ ~ {Tags:["CK.MenuEl","CK.ModeClick"],width:0.12f,height:0.09f,response:1b}
execute at @s rotated ~ 0 positioned ^0.2267 ^2.07 ^1.8 positioned ^0 ^0.635 ^0 run summon interaction ~ ~ ~ {Tags:["CK.MenuEl","CK.ModeClick"],width:0.12f,height:0.09f,response:1b}
execute at @s rotated ~ 0 positioned ^0.34 ^2.07 ^1.8 positioned ^0 ^0.635 ^0 run summon interaction ~ ~ ~ {Tags:["CK.MenuEl","CK.ModeClick"],width:0.12f,height:0.09f,response:1b}

# --- Tab Navigation Arrows (permanent, page-colored in refresh_tabs) ---
execute at @s rotated ~ 0 positioned ^ ^2.05 ^1.8 positioned ^1.45 ^0.50 ^0 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["CK.MenuEl","CK.TabPrevText"],billboard:"center",text:{"text":"[<]","color":"dark_gray"},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.35f,0.35f,0.35f]}}
execute at @s rotated ~ 0 positioned ^ ^2.07 ^1.8 positioned ^1.45 ^0.44 ^0 run summon interaction ~ ~ ~ {Tags:["CK.MenuEl","CK.TabPrevClick"],width:0.2f,height:0.08f,response:1b}
execute at @s rotated ~ 0 positioned ^ ^2.05 ^1.8 positioned ^-1.45 ^0.50 ^0 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["CK.MenuEl","CK.TabNextText"],billboard:"center",text:{"text":"[>]","color":"gold","bold":true},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.35f,0.35f,0.35f]}}
execute at @s rotated ~ 0 positioned ^ ^2.07 ^1.8 positioned ^-1.45 ^0.44 ^0 run summon interaction ~ ~ ~ {Tags:["CK.MenuEl","CK.TabNextClick"],width:0.2f,height:0.08f,response:1b}

# --- Recipe Rows (6 recipes per category, 0.26 spacing) ---
# Recipe 0 — name + [Cook] button + ingredient line
execute at @s rotated ~ 0 positioned ^ ^2.05 ^1.8 positioned ^0.15 ^0.34 ^0 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["CK.MenuEl","CK.Recipe0"],billboard:"center",text:{"text":"Loading...","color":"gray"},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.338f,0.338f,0.338f]}}
execute at @s rotated ~ 0 positioned ^ ^2.05 ^1.8 positioned ^-0.60 ^0.34 ^0 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["CK.MenuEl","CK.Cook0Text"],billboard:"center",text:{"text":"[Cook]","color":"green","bold":true},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.338f,0.338f,0.338f]}}
execute at @s rotated ~ 0 positioned ^ ^2.07 ^1.8 positioned ^-0.60 ^0.19 ^0 run summon interaction ~ ~ ~ {Tags:["CK.MenuEl","CK.Cook0Click"],width:0.18f,height:0.26f,response:1b}
execute at @s rotated ~ 0 positioned ^ ^2.05 ^1.8 positioned ^0.15 ^0.24 ^0 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["CK.MenuEl","CK.Ingr0"],billboard:"center",text:{"text":"","color":"gray"},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.297f,0.297f,0.297f]}}

# Recipe 1
execute at @s rotated ~ 0 positioned ^ ^2.05 ^1.8 positioned ^0.15 ^0.08 ^0 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["CK.MenuEl","CK.Recipe1"],billboard:"center",text:{"text":"Loading...","color":"gray"},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.338f,0.338f,0.338f]}}
execute at @s rotated ~ 0 positioned ^ ^2.05 ^1.8 positioned ^-0.60 ^0.08 ^0 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["CK.MenuEl","CK.Cook1Text"],billboard:"center",text:{"text":"[Cook]","color":"green","bold":true},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.338f,0.338f,0.338f]}}
execute at @s rotated ~ 0 positioned ^ ^2.07 ^1.8 positioned ^-0.60 ^-0.07 ^0 run summon interaction ~ ~ ~ {Tags:["CK.MenuEl","CK.Cook1Click"],width:0.18f,height:0.26f,response:1b}
execute at @s rotated ~ 0 positioned ^ ^2.05 ^1.8 positioned ^0.15 ^-0.02 ^0 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["CK.MenuEl","CK.Ingr1"],billboard:"center",text:{"text":"","color":"gray"},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.297f,0.297f,0.297f]}}

# Recipe 2
execute at @s rotated ~ 0 positioned ^ ^2.05 ^1.8 positioned ^0.15 ^-0.18 ^0 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["CK.MenuEl","CK.Recipe2"],billboard:"center",text:{"text":"Loading...","color":"gray"},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.338f,0.338f,0.338f]}}
execute at @s rotated ~ 0 positioned ^ ^2.05 ^1.8 positioned ^-0.60 ^-0.18 ^0 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["CK.MenuEl","CK.Cook2Text"],billboard:"center",text:{"text":"[Cook]","color":"green","bold":true},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.338f,0.338f,0.338f]}}
execute at @s rotated ~ 0 positioned ^ ^2.07 ^1.8 positioned ^-0.60 ^-0.33 ^0 run summon interaction ~ ~ ~ {Tags:["CK.MenuEl","CK.Cook2Click"],width:0.18f,height:0.26f,response:1b}
execute at @s rotated ~ 0 positioned ^ ^2.05 ^1.8 positioned ^0.15 ^-0.28 ^0 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["CK.MenuEl","CK.Ingr2"],billboard:"center",text:{"text":"","color":"gray"},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.297f,0.297f,0.297f]}}

# Recipe 3
execute at @s rotated ~ 0 positioned ^ ^2.05 ^1.8 positioned ^0.15 ^-0.44 ^0 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["CK.MenuEl","CK.Recipe3"],billboard:"center",text:{"text":"Loading...","color":"gray"},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.338f,0.338f,0.338f]}}
execute at @s rotated ~ 0 positioned ^ ^2.05 ^1.8 positioned ^-0.60 ^-0.44 ^0 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["CK.MenuEl","CK.Cook3Text"],billboard:"center",text:{"text":"[Cook]","color":"green","bold":true},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.338f,0.338f,0.338f]}}
execute at @s rotated ~ 0 positioned ^ ^2.07 ^1.8 positioned ^-0.60 ^-0.59 ^0 run summon interaction ~ ~ ~ {Tags:["CK.MenuEl","CK.Cook3Click"],width:0.18f,height:0.26f,response:1b}
execute at @s rotated ~ 0 positioned ^ ^2.05 ^1.8 positioned ^0.15 ^-0.54 ^0 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["CK.MenuEl","CK.Ingr3"],billboard:"center",text:{"text":"","color":"gray"},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.297f,0.297f,0.297f]}}

# Recipe 4
execute at @s rotated ~ 0 positioned ^ ^2.05 ^1.8 positioned ^0.15 ^-0.70 ^0 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["CK.MenuEl","CK.Recipe4"],billboard:"center",text:{"text":"Loading...","color":"gray"},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.338f,0.338f,0.338f]}}
execute at @s rotated ~ 0 positioned ^ ^2.05 ^1.8 positioned ^-0.60 ^-0.70 ^0 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["CK.MenuEl","CK.Cook4Text"],billboard:"center",text:{"text":"[Cook]","color":"green","bold":true},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.338f,0.338f,0.338f]}}
execute at @s rotated ~ 0 positioned ^ ^2.07 ^1.8 positioned ^-0.60 ^-0.85 ^0 run summon interaction ~ ~ ~ {Tags:["CK.MenuEl","CK.Cook4Click"],width:0.18f,height:0.26f,response:1b}
execute at @s rotated ~ 0 positioned ^ ^2.05 ^1.8 positioned ^0.15 ^-0.80 ^0 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["CK.MenuEl","CK.Ingr4"],billboard:"center",text:{"text":"","color":"gray"},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.297f,0.297f,0.297f]}}

# Recipe 5
execute at @s rotated ~ 0 positioned ^ ^2.05 ^1.8 positioned ^0.15 ^-0.96 ^0 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["CK.MenuEl","CK.Recipe5"],billboard:"center",text:{"text":"Loading...","color":"gray"},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.338f,0.338f,0.338f]}}
execute at @s rotated ~ 0 positioned ^ ^2.05 ^1.8 positioned ^-0.60 ^-0.96 ^0 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["CK.MenuEl","CK.Cook5Text"],billboard:"center",text:{"text":"[Cook]","color":"green","bold":true},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.338f,0.338f,0.338f]}}
execute at @s rotated ~ 0 positioned ^ ^2.07 ^1.8 positioned ^-0.60 ^-1.11 ^0 run summon interaction ~ ~ ~ {Tags:["CK.MenuEl","CK.Cook5Click"],width:0.18f,height:0.26f,response:1b}
execute at @s rotated ~ 0 positioned ^ ^2.05 ^1.8 positioned ^0.15 ^-1.06 ^0 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["CK.MenuEl","CK.Ingr5"],billboard:"center",text:{"text":"","color":"gray"},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.297f,0.297f,0.297f]}}

# --- Close Button (centered) ---
execute at @s rotated ~ 0 positioned ^ ^2.05 ^1.8 positioned ^0 ^-1.20 ^0 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["CK.MenuEl","CK.CloseText"],billboard:"center",text:{"text":"[Close]","color":"red"},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.405f,0.405f,0.405f]}}
execute at @s rotated ~ 0 positioned ^ ^2.07 ^1.8 positioned ^0 ^-1.26 ^0 run summon interaction ~ ~ ~ {Tags:["CK.MenuEl","CK.CloseClick"],width:0.2f,height:0.06f,response:1b}

# --- Spiced Recipe-Page toggle (Spiced tab only; hidden text on every other tab) ---
# Sits to the right of [Close] on the bottom row. Text starts empty; refresh_spiced
# fills it ("▼ More Spices" / "▲ Back") on cat 11 only. check_clicks gates the click
# to cat 11, so the always-present interaction is inert on other tabs.
execute at @s rotated ~ 0 positioned ^ ^2.05 ^1.8 positioned ^-0.95 ^-1.20 ^0 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["CK.MenuEl","CK.SpicePageText"],billboard:"center",text:{"text":""},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.3f,0.3f,0.3f]}}
# [strip] ?: 0.45w split into 4 x 0.12 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute at @s rotated ~ 0 positioned ^-0.165 ^2.07 ^1.8 positioned ^-0.95 ^-1.26 ^0 run summon interaction ~ ~ ~ {Tags:["CK.MenuEl","CK.SpicePageClick"],width:0.12f,height:0.07f,response:1b}
execute at @s rotated ~ 0 positioned ^-0.055 ^2.07 ^1.8 positioned ^-0.95 ^-1.26 ^0 run summon interaction ~ ~ ~ {Tags:["CK.MenuEl","CK.SpicePageClick"],width:0.12f,height:0.07f,response:1b}
execute at @s rotated ~ 0 positioned ^0.055 ^2.07 ^1.8 positioned ^-0.95 ^-1.26 ^0 run summon interaction ~ ~ ~ {Tags:["CK.MenuEl","CK.SpicePageClick"],width:0.12f,height:0.07f,response:1b}
execute at @s rotated ~ 0 positioned ^0.165 ^2.07 ^1.8 positioned ^-0.95 ^-1.26 ^0 run summon interaction ~ ~ ~ {Tags:["CK.MenuEl","CK.SpicePageClick"],width:0.12f,height:0.07f,response:1b}

# --- Session isolation ---
scoreboard players add #gui_session ec.var 1
scoreboard players operation @s adv.gui_session = #gui_session ec.var
scoreboard players operation #gui_stamp ec.temp = @s adv.gui_session
execute as @e[type=text_display,tag=CK.MenuEl,distance=..5] unless score @s adv.gui_session matches 1.. run scoreboard players operation @s adv.gui_session = #gui_stamp ec.temp
execute as @e[type=item_display,tag=CK.MenuEl,distance=..5] unless score @s adv.gui_session matches 1.. run scoreboard players operation @s adv.gui_session = #gui_stamp ec.temp
execute as @e[type=interaction,tag=CK.MenuEl,distance=..5] unless score @s adv.gui_session matches 1.. run scoreboard players operation @s adv.gui_session = #gui_stamp ec.temp

# Kitchen-identity hearth crackle on menu open — gated (silent at Off)
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.campfire.crackle master @s ~ ~ ~ 0.8 1.2

# --- Spawn paginated tabs ---
function evercraft:cooking/gui/refresh_tabs

# --- Initial refresh to populate recipe displays ---
function evercraft:cooking/gui/refresh
