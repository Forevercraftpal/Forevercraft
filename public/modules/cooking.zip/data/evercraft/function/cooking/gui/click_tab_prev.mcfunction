# Tab page previous — runs as interaction entity
data remove entity @s interaction
scoreboard players set #ck_clicked ec.temp 1

# Go back one page (2->1->0, floored at 0). Session-gate, drop limit=1 (Wiring Audit #26 RC-1).
# Order matters: drop 1->0 BEFORE 2->1 so a single click only goes back one page.
execute as @a[tag=CK.InMenu,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if score @s ec.ck_tab_page matches 1 run scoreboard players set @s ec.ck_tab_page 0
execute as @a[tag=CK.InMenu,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if score @s ec.ck_tab_page matches 2 run scoreboard players set @s ec.ck_tab_page 1
execute as @a[tag=CK.InMenu,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if score @s ec.ck_tab_page matches 0..1 run function evercraft:cooking/gui/refresh_tabs

execute as @a[tag=CK.InMenu,distance=..5] if score @s adv.gui_session = #gui_check ec.temp at @s if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.hat master @s ~ ~ ~ 0.5 1.6
