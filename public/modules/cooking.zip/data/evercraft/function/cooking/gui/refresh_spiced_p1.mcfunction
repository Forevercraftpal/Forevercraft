# ============================================================
# Refresh Spiced — PAGE 1 (runs as player, category 11, ec.ck_spage 1)
# The 3 dimensional/exotic spices share the panel's 6 slots:
#   Slot 0: Ember Steak     — Emberzest  + Cooked Beef
#   Slot 1: Voidsalt Stew   — Void Salt  + Cooked Rabbit
#   Slot 2: Marrow Broth    — Marrow Dust + Cooked Salmon
# Slots 3-5 are blanked (no recipe). Discovery uses ck.disc11b (page-aware in
# check_slot/mark_slot via ec.ck_spage) so these stay independent of page-0 slots.
# ============================================================

# === Slot 0: Ember Steak — Emberzest + Cooked Beef ===
execute store result score #ck_i1 ec.temp run clear @s sugar[custom_data~{ingredient_id:"emberzest"}] 0
execute if score #ck_i1 ec.temp matches 1.. run data modify storage evercraft:cooking i1_color set value "green"
execute if score #ck_i1 ec.temp matches 0 run data modify storage evercraft:cooking i1_color set value "red"
execute store result score #ck_i2 ec.temp run clear @s minecraft:cooked_beef 0
execute if score #ck_i2 ec.temp matches 1.. run data modify storage evercraft:cooking i2_color set value "green"
execute if score #ck_i2 ec.temp matches 0 run data modify storage evercraft:cooking i2_color set value "red"
data modify storage evercraft:cooking r_slot set value "0"
data modify storage evercraft:cooking r_name set value "Ember Steak"
data modify storage evercraft:cooking r_tier_color set value "#E0522A"
data modify storage evercraft:cooking i1_name set value "Emberzest"
data modify storage evercraft:cooking i2_name set value "Cooked Beef"
function evercraft:cooking/gui/render_recipe_2_disc

# === Slot 1: Voidsalt Stew — Void Salt + Cooked Rabbit ===
execute store result score #ck_i1 ec.temp run clear @s sugar[custom_data~{ingredient_id:"void_salt"}] 0
execute if score #ck_i1 ec.temp matches 1.. run data modify storage evercraft:cooking i1_color set value "green"
execute if score #ck_i1 ec.temp matches 0 run data modify storage evercraft:cooking i1_color set value "red"
execute store result score #ck_i2 ec.temp run clear @s minecraft:cooked_rabbit 0
execute if score #ck_i2 ec.temp matches 1.. run data modify storage evercraft:cooking i2_color set value "green"
execute if score #ck_i2 ec.temp matches 0 run data modify storage evercraft:cooking i2_color set value "red"
data modify storage evercraft:cooking r_slot set value "1"
data modify storage evercraft:cooking r_name set value "Voidsalt Stew"
data modify storage evercraft:cooking r_tier_color set value "#9C6ADE"
data modify storage evercraft:cooking i1_name set value "Void Salt"
data modify storage evercraft:cooking i2_name set value "Cooked Rabbit"
function evercraft:cooking/gui/render_recipe_2_disc

# === Slot 2: Marrow Broth — Marrow Dust + Cooked Salmon ===
execute store result score #ck_i1 ec.temp run clear @s sugar[custom_data~{ingredient_id:"marrow_dust"}] 0
execute if score #ck_i1 ec.temp matches 1.. run data modify storage evercraft:cooking i1_color set value "green"
execute if score #ck_i1 ec.temp matches 0 run data modify storage evercraft:cooking i1_color set value "red"
execute store result score #ck_i2 ec.temp run clear @s minecraft:cooked_salmon 0
execute if score #ck_i2 ec.temp matches 1.. run data modify storage evercraft:cooking i2_color set value "green"
execute if score #ck_i2 ec.temp matches 0 run data modify storage evercraft:cooking i2_color set value "red"
data modify storage evercraft:cooking r_slot set value "2"
data modify storage evercraft:cooking r_name set value "Marrow Broth"
data modify storage evercraft:cooking r_tier_color set value "#D8D2BE"
data modify storage evercraft:cooking i1_name set value "Marrow Dust"
data modify storage evercraft:cooking i2_name set value "Cooked Salmon"
function evercraft:cooking/gui/render_recipe_2_disc

# === Slots 3-5: blank (no recipe on page 1) ===
data modify entity @e[type=text_display,tag=CK.Recipe3,distance=..5,limit=1] text set value {"text":""}
data modify entity @e[type=text_display,tag=CK.Ingr3,distance=..5,limit=1] text set value {"text":""}
data modify entity @e[type=text_display,tag=CK.Cook3Text,distance=..5,limit=1] text set value {"text":""}
data modify entity @e[type=text_display,tag=CK.Recipe4,distance=..5,limit=1] text set value {"text":""}
data modify entity @e[type=text_display,tag=CK.Ingr4,distance=..5,limit=1] text set value {"text":""}
data modify entity @e[type=text_display,tag=CK.Cook4Text,distance=..5,limit=1] text set value {"text":""}
data modify entity @e[type=text_display,tag=CK.Recipe5,distance=..5,limit=1] text set value {"text":""}
data modify entity @e[type=text_display,tag=CK.Ingr5,distance=..5,limit=1] text set value {"text":""}
data modify entity @e[type=text_display,tag=CK.Cook5Text,distance=..5,limit=1] text set value {"text":""}
