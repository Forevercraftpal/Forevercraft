# ============================================================
# Campfire Kitchen GUI — Tab Click Handler (Macro)
# Runs as the interaction entity, at its position
# Args: {tab: 0-4, tab_label: "[Combat]" etc}
# ============================================================

# Clear click data + flag click handled (OPT: skip remaining scans)
data remove entity @s interaction
scoreboard players set #ck_clicked ec.temp 1

# Set category on the CLICKING player only.
# Wiring Audit #26 RC-1/RC-2: session-gate every player + menu-entity write (drop limit=1)
# so a click in one player's menu can't mutate a different nearby player's menu.
# #gui_check = clicker's session (set in check_clicks); menu entities carry the owner's session.
$execute as @a[tag=CK.InMenu,distance=..5] if score @s adv.gui_session = #gui_check ec.temp run scoreboard players set @s ec.ck_cat $(tab)

# Every tab switch (incl. re-selecting Spiced) starts on Spiced recipe-page 0.
execute as @a[tag=CK.InMenu,distance=..5] if score @s adv.gui_session = #gui_check ec.temp run scoreboard players set @s ec.ck_spage 0

# Update tab highlights — reset all to gray, then highlight active (clicker's menu only)
execute as @e[type=text_display,tag=CK.Tab0Text,distance=..5] if score @s adv.gui_session = #gui_check ec.temp run data modify entity @s text set value {"text":"[Combat]","color":"gray"}
execute as @e[type=text_display,tag=CK.Tab1Text,distance=..5] if score @s adv.gui_session = #gui_check ec.temp run data modify entity @s text set value {"text":"[Mining]","color":"gray"}
execute as @e[type=text_display,tag=CK.Tab2Text,distance=..5] if score @s adv.gui_session = #gui_check ec.temp run data modify entity @s text set value {"text":"[Fortune]","color":"gray"}
execute as @e[type=text_display,tag=CK.Tab3Text,distance=..5] if score @s adv.gui_session = #gui_check ec.temp run data modify entity @s text set value {"text":"[Wayfarer]","color":"gray"}
execute as @e[type=text_display,tag=CK.Tab4Text,distance=..5] if score @s adv.gui_session = #gui_check ec.temp run data modify entity @s text set value {"text":"[Delicacy]","color":"gray"}
execute as @e[type=text_display,tag=CK.Tab5Text,distance=..5] if score @s adv.gui_session = #gui_check ec.temp run data modify entity @s text set value {"text":"[Seasonal]","color":"gray"}
execute as @e[type=text_display,tag=CK.Tab6Text,distance=..5] if score @s adv.gui_session = #gui_check ec.temp run data modify entity @s text set value {"text":"[Treats]","color":"gray"}
execute as @e[type=text_display,tag=CK.Tab7Text,distance=..5] if score @s adv.gui_session = #gui_check ec.temp run data modify entity @s text set value {"text":"[Rations]","color":"gray"}
execute as @e[type=text_display,tag=CK.Tab8Text,distance=..5] if score @s adv.gui_session = #gui_check ec.temp run data modify entity @s text set value {"text":"[Feast]","color":"gray"}
execute as @e[type=text_display,tag=CK.Tab9Text,distance=..5] if score @s adv.gui_session = #gui_check ec.temp run data modify entity @s text set value {"text":"[Preserve]","color":"gray"}
execute as @e[type=text_display,tag=CK.Tab10Text,distance=..5] if score @s adv.gui_session = #gui_check ec.temp run data modify entity @s text set value {"text":"[Spirit]","color":"gray"}
execute as @e[type=text_display,tag=CK.Tab11Text,distance=..5] if score @s adv.gui_session = #gui_check ec.temp run data modify entity @s text set value {"text":"[Spiced]","color":"gray"}

# Highlight active tab (yellow + bold)
$execute as @e[type=text_display,tag=CK.Tab$(tab)Text,distance=..5] if score @s adv.gui_session = #gui_check ec.temp run data modify entity @s text set value {"text":"$(tab_label)","color":"yellow","bold":true}

# Sound (clicker only)
execute as @a[tag=CK.InMenu,distance=..5] if score @s adv.gui_session = #gui_check ec.temp at @s if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.hat master @s ~ ~ ~ 0.5 1.6

# Refresh recipe displays for new category (clicker only)
execute as @a[tag=CK.InMenu,distance=..5] if score @s adv.gui_session = #gui_check ec.temp run function evercraft:cooking/gui/refresh
