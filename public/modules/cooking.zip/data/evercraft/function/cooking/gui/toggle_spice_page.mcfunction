# Toggle the Spiced recipe page (runs as player, cat 11 only)
# 0 = overworld spices (slots 0-5), 1 = dimensional spices (slots 0-2)

# Flip the page (store old value in temp to avoid double-flip)
scoreboard players operation #ck_old_spage ec.temp = @s ec.ck_spage
execute if score #ck_old_spage ec.temp matches 0 run scoreboard players set @s ec.ck_spage 1
execute if score #ck_old_spage ec.temp matches 1.. run scoreboard players set @s ec.ck_spage 0

# Re-render the recipe rows + page-toggle label for the new page
function evercraft:cooking/gui/refresh

# Click sound
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.hat master @s ~ ~ ~ 0.5 1.8
