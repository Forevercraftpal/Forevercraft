# ============================================================
# Refresh Spiced Category Recipes (runs as player, category 11)
# Two recipe PAGES share the 6 slots (panel can't grow):
#   Page 0 (ec.ck_spage 0): 6 overworld-spice meals, slots 0-5.
#   Page 1 (ec.ck_spage 1): 3 dimensional-spice meals, slots 0-2; slots 3-5 blank.
# A "More Spices" / "Back" toggle (CK.SpicePageText/Click) flips the page; it is
# only shown on this tab (refresh() for other cats never calls this file, and the
# toggle entity is hidden on open + here when page is irrelevant).
# Spices carry custom_data~{ingredient_id:"<id>"}; base foods are vanilla.
# Frostmint/Jungle checks are base-agnostic (*[...]) so the new sugar items AND any
# legacy fern/cocoa ones both satisfy the recipe.
# ============================================================

# Default page to 0 if unset
execute unless score @s ec.ck_spage matches 0..1 run scoreboard players set @s ec.ck_spage 0

# Show + label the page toggle (only meaningful on this tab)
execute if score @s ec.ck_spage matches 0 as @e[type=text_display,tag=CK.SpicePageText,distance=..5] if score @s adv.gui_session = #gui_check ec.temp run data modify entity @s text set value [{"text":"[ ","color":"dark_gray"},{"text":"▼ More Spices","color":"#9C6ADE"},{"text":" ]","color":"dark_gray"}]
execute if score @s ec.ck_spage matches 1 as @e[type=text_display,tag=CK.SpicePageText,distance=..5] if score @s adv.gui_session = #gui_check ec.temp run data modify entity @s text set value [{"text":"[ ","color":"dark_gray"},{"text":"▲ Back","color":"#9C6ADE"},{"text":" ]","color":"dark_gray"}]

# === PAGE 1: Dimensional spices (slots 0-2; 3-5 cleared) ===
execute if score @s ec.ck_spage matches 1 run function evercraft:cooking/gui/refresh_spiced_p1
execute if score @s ec.ck_spage matches 1 run return 0

# === PAGE 0: Overworld spices (slots 0-5) ===

# === Slot 0: Seasoned Loaf — Cinnamon Bark + Bread ===
execute store result score #ck_i1 ec.temp run clear @s sugar[custom_data~{ingredient_id:"cinnamon_bark"}] 0
execute if score #ck_i1 ec.temp matches 1.. run data modify storage evercraft:cooking i1_color set value "green"
execute if score #ck_i1 ec.temp matches 0 run data modify storage evercraft:cooking i1_color set value "red"
execute store result score #ck_i2 ec.temp run clear @s minecraft:bread 0
execute if score #ck_i2 ec.temp matches 1.. run data modify storage evercraft:cooking i2_color set value "green"
execute if score #ck_i2 ec.temp matches 0 run data modify storage evercraft:cooking i2_color set value "red"
data modify storage evercraft:cooking r_slot set value "0"
data modify storage evercraft:cooking r_name set value "Seasoned Loaf"
data modify storage evercraft:cooking r_tier_color set value "#C97A40"
data modify storage evercraft:cooking i1_name set value "Cinnamon Bark"
data modify storage evercraft:cooking i2_name set value "Bread"
function evercraft:cooking/gui/render_recipe_2_disc

# === Slot 1: Frostmint Fillet — Frostmint Spice + Cooked Cod ===
execute store result score #ck_i1 ec.temp run clear @s *[custom_data~{ingredient_id:"frostmint"}] 0
execute if score #ck_i1 ec.temp matches 1.. run data modify storage evercraft:cooking i1_color set value "green"
execute if score #ck_i1 ec.temp matches 0 run data modify storage evercraft:cooking i1_color set value "red"
execute store result score #ck_i2 ec.temp run clear @s minecraft:cooked_cod 0
execute if score #ck_i2 ec.temp matches 1.. run data modify storage evercraft:cooking i2_color set value "green"
execute if score #ck_i2 ec.temp matches 0 run data modify storage evercraft:cooking i2_color set value "red"
data modify storage evercraft:cooking r_slot set value "1"
data modify storage evercraft:cooking r_name set value "Frostmint Fillet"
data modify storage evercraft:cooking r_tier_color set value "#88DDFF"
data modify storage evercraft:cooking i1_name set value "Frostmint"
data modify storage evercraft:cooking i2_name set value "Cooked Cod"
function evercraft:cooking/gui/render_recipe_2_disc

# === Slot 2: Thyme Roast — Wild Thyme + Cooked Chicken ===
execute store result score #ck_i1 ec.temp run clear @s sugar[custom_data~{ingredient_id:"wild_thyme"}] 0
execute if score #ck_i1 ec.temp matches 1.. run data modify storage evercraft:cooking i1_color set value "green"
execute if score #ck_i1 ec.temp matches 0 run data modify storage evercraft:cooking i1_color set value "red"
execute store result score #ck_i2 ec.temp run clear @s minecraft:cooked_chicken 0
execute if score #ck_i2 ec.temp matches 1.. run data modify storage evercraft:cooking i2_color set value "green"
execute if score #ck_i2 ec.temp matches 0 run data modify storage evercraft:cooking i2_color set value "red"
data modify storage evercraft:cooking r_slot set value "2"
data modify storage evercraft:cooking r_name set value "Thyme Roast"
data modify storage evercraft:cooking r_tier_color set value "#7FB05A"
data modify storage evercraft:cooking i1_name set value "Wild Thyme"
data modify storage evercraft:cooking i2_name set value "Cooked Chicken"
function evercraft:cooking/gui/render_recipe_2_disc

# === Slot 3: Peppered Chop — Jungle Pepper + Cooked Porkchop ===
execute store result score #ck_i1 ec.temp run clear @s *[custom_data~{ingredient_id:"jungle_pepper"}] 0
execute if score #ck_i1 ec.temp matches 1.. run data modify storage evercraft:cooking i1_color set value "green"
execute if score #ck_i1 ec.temp matches 0 run data modify storage evercraft:cooking i1_color set value "red"
execute store result score #ck_i2 ec.temp run clear @s minecraft:cooked_porkchop 0
execute if score #ck_i2 ec.temp matches 1.. run data modify storage evercraft:cooking i2_color set value "green"
execute if score #ck_i2 ec.temp matches 0 run data modify storage evercraft:cooking i2_color set value "red"
data modify storage evercraft:cooking r_slot set value "3"
data modify storage evercraft:cooking r_name set value "Peppered Chop"
data modify storage evercraft:cooking r_tier_color set value "#4CAF50"
data modify storage evercraft:cooking i1_name set value "Jungle Pepper"
data modify storage evercraft:cooking i2_name set value "Cooked Porkchop"
function evercraft:cooking/gui/render_recipe_2_disc

# === Slot 4: Blossom Tart — Blossom Sugar + Pumpkin Pie ===
execute store result score #ck_i1 ec.temp run clear @s sugar[custom_data~{ingredient_id:"blossom_sugar"}] 0
execute if score #ck_i1 ec.temp matches 1.. run data modify storage evercraft:cooking i1_color set value "green"
execute if score #ck_i1 ec.temp matches 0 run data modify storage evercraft:cooking i1_color set value "red"
execute store result score #ck_i2 ec.temp run clear @s minecraft:pumpkin_pie 0
execute if score #ck_i2 ec.temp matches 1.. run data modify storage evercraft:cooking i2_color set value "green"
execute if score #ck_i2 ec.temp matches 0 run data modify storage evercraft:cooking i2_color set value "red"
data modify storage evercraft:cooking r_slot set value "4"
data modify storage evercraft:cooking r_name set value "Blossom Tart"
data modify storage evercraft:cooking r_tier_color set value "#F4A6C0"
data modify storage evercraft:cooking i1_name set value "Blossom Sugar"
data modify storage evercraft:cooking i2_name set value "Pumpkin Pie"
function evercraft:cooking/gui/render_recipe_2_disc

# === Slot 5: Bog Stew — Bog Pepper + Cooked Mutton ===
execute store result score #ck_i1 ec.temp run clear @s sugar[custom_data~{ingredient_id:"bog_pepper"}] 0
execute if score #ck_i1 ec.temp matches 1.. run data modify storage evercraft:cooking i1_color set value "green"
execute if score #ck_i1 ec.temp matches 0 run data modify storage evercraft:cooking i1_color set value "red"
execute store result score #ck_i2 ec.temp run clear @s minecraft:cooked_mutton 0
execute if score #ck_i2 ec.temp matches 1.. run data modify storage evercraft:cooking i2_color set value "green"
execute if score #ck_i2 ec.temp matches 0 run data modify storage evercraft:cooking i2_color set value "red"
data modify storage evercraft:cooking r_slot set value "5"
data modify storage evercraft:cooking r_name set value "Bog Stew"
data modify storage evercraft:cooking r_tier_color set value "#6B7A4A"
data modify storage evercraft:cooking i1_name set value "Bog Pepper"
data modify storage evercraft:cooking i2_name set value "Cooked Mutton"
function evercraft:cooking/gui/render_recipe_2_disc
