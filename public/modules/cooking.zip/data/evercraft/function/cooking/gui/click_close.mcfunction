# ============================================================
# Campfire Kitchen GUI — Close Button Click Handler
# Runs as the interaction entity, at its position
# ============================================================

# Clear click data + flag click handled
data remove entity @s interaction
scoreboard players set #ck_clicked ec.temp 1

# Close the GUI (runs as the player)
# Wiring Audit #26 RC-1: session-gate the player re-selection (drop limit=1) so a
# click can't resolve against a different nearby in-menu player. #gui_check = clicker's session.
execute as @a[tag=CK.InMenu,distance=..5] if score @s adv.gui_session = #gui_check ec.temp run function evercraft:cooking/gui/close
