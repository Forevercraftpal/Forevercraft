# ============================================================
# Campfire Kitchen GUI — Cook Button Click Handler (Macro)
# Runs as the interaction entity, at its position
# Args: {slot: 0-5}
# ============================================================

# Clear click data + flag click handled (OPT: skip remaining scans)
data remove entity @s interaction
scoreboard players set #ck_clicked ec.temp 1

# Store which slot was clicked
$scoreboard players set #ck_slot ec.temp $(slot)

# Branch on cooking mode: 0=Quick Cook (instant), 1=Chef's Touch (minigame)
# Wiring Audit #26 RC-1: session-gate the player re-selection (drop limit=1) so the
# cook resolves for the clicker, not an arbitrary nearby in-menu player. #gui_check = clicker's session.
execute as @a[tag=CK.InMenu,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if score @s ec.ck_mode matches 1 run return run function evercraft:cooking/minigame/begin

# Quick Cook: standard instant cook (set quality_mod to 1 = standard)
execute as @a[tag=CK.InMenu,distance=..5] if score @s adv.gui_session = #gui_check ec.temp run scoreboard players set @s ec.ck_quality_mod 1
execute as @a[tag=CK.InMenu,distance=..5] if score @s adv.gui_session = #gui_check ec.temp run function evercraft:cooking/recipes/cook_dispatch
