# ============================================================
# Campfire Kitchen GUI — Mode Toggle Click Handler
# Runs as the interaction entity
# Toggles between Quick Cook (0) and Chef's Touch (1)
# ============================================================

data remove entity @s interaction
scoreboard players set #ck_clicked ec.temp 1

# Toggle mode on the clicking player (Wiring Audit #26 RC-1: session-gate, drop limit=1)
execute as @a[tag=CK.InMenu,distance=..5] if score @s adv.gui_session = #gui_check ec.temp run function evercraft:cooking/gui/toggle_mode

execute as @a[tag=CK.InMenu,distance=..5] if score @s adv.gui_session = #gui_check ec.temp at @s if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.hat master @s ~ ~ ~ 0.5 1.8
