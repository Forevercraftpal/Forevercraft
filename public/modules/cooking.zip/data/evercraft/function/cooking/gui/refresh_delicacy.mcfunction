# ============================================================
# Refresh Delicacy Category Recipes (runs as player)
# 3 recipes: 1 Hearty (2-ingr), 1 Gourmet (3-ingr), 1 Feast (3-ingr)
# Slots 3-5 empty
# ============================================================

# === Slot 0: Saturation Stew — Charred Poultry + Sunbaked Root ===
execute store result score #ck_i1 ec.temp run clear @s cooked_chicken[custom_data~{ingredient_id:"charred_poultry"}] 0
execute if score #ck_i1 ec.temp matches 1.. run data modify storage evercraft:cooking i1_color set value "green"
execute if score #ck_i1 ec.temp matches 0 run data modify storage evercraft:cooking i1_color set value "red"
execute store result score #ck_i2 ec.temp run clear @s beetroot[custom_data~{ingredient_id:"sunbaked_root"}] 0
execute if score #ck_i2 ec.temp matches 1.. run data modify storage evercraft:cooking i2_color set value "green"
execute if score #ck_i2 ec.temp matches 0 run data modify storage evercraft:cooking i2_color set value "red"
data modify storage evercraft:cooking r_slot set value "0"
data modify storage evercraft:cooking r_name set value "Saturation Stew"
data modify storage evercraft:cooking r_tier_color set value "white"
data modify storage evercraft:cooking i1_name set value "C. Poultry"
data modify storage evercraft:cooking i2_name set value "Sunbaked Root"
function evercraft:cooking/gui/render_recipe_2_disc

# === Slot 1: Exquisite Nectar — Seared Rabbit + Desert Saffron + Jungle Pepper ===
execute store result score #ck_i1 ec.temp run clear @s cooked_rabbit[custom_data~{ingredient_id:"seared_rabbit"}] 0
execute if score #ck_i1 ec.temp matches 1.. run data modify storage evercraft:cooking i1_color set value "green"
execute if score #ck_i1 ec.temp matches 0 run data modify storage evercraft:cooking i1_color set value "red"
execute store result score #ck_i2 ec.temp run clear @s orange_tulip[custom_data~{ingredient_id:"desert_saffron"}] 0
execute if score #ck_i2 ec.temp matches 1.. run data modify storage evercraft:cooking i2_color set value "green"
execute if score #ck_i2 ec.temp matches 0 run data modify storage evercraft:cooking i2_color set value "red"
execute store result score #ck_i3 ec.temp run clear @s cocoa_beans[custom_data~{ingredient_id:"jungle_pepper"}] 0
execute if score #ck_i3 ec.temp matches 1.. run data modify storage evercraft:cooking i3_color set value "green"
execute if score #ck_i3 ec.temp matches 0 run data modify storage evercraft:cooking i3_color set value "red"
data modify storage evercraft:cooking r_slot set value "1"
data modify storage evercraft:cooking r_name set value "Exquisite Nectar"
data modify storage evercraft:cooking r_tier_color set value "blue"
data modify storage evercraft:cooking i1_name set value "Seared Rabbit"
data modify storage evercraft:cooking i2_name set value "Desert Saffron"
data modify storage evercraft:cooking i3_name set value "Jungle Pepper"
function evercraft:cooking/gui/render_recipe_3_disc

# === Slot 2: Ambrosia — Aged Venison + Chorus Extract + Nethercap ===
execute store result score #ck_i1 ec.temp run clear @s cooked_beef[custom_data~{ingredient_id:"aged_venison"}] 0
execute if score #ck_i1 ec.temp matches 1.. run data modify storage evercraft:cooking i1_color set value "green"
execute if score #ck_i1 ec.temp matches 0 run data modify storage evercraft:cooking i1_color set value "red"
execute store result score #ck_i2 ec.temp run clear @s chorus_fruit[custom_data~{ingredient_id:"chorus_extract"}] 0
execute if score #ck_i2 ec.temp matches 1.. run data modify storage evercraft:cooking i2_color set value "green"
execute if score #ck_i2 ec.temp matches 0 run data modify storage evercraft:cooking i2_color set value "red"
execute store result score #ck_i3 ec.temp run clear @s nether_wart[custom_data~{ingredient_id:"nethercap"}] 0
execute if score #ck_i3 ec.temp matches 1.. run data modify storage evercraft:cooking i3_color set value "green"
execute if score #ck_i3 ec.temp matches 0 run data modify storage evercraft:cooking i3_color set value "red"
data modify storage evercraft:cooking r_slot set value "2"
data modify storage evercraft:cooking r_name set value "Ambrosia"
data modify storage evercraft:cooking r_tier_color set value "dark_purple"
data modify storage evercraft:cooking i1_name set value "Aged Venison"
data modify storage evercraft:cooking i2_name set value "Chorus Extract"
data modify storage evercraft:cooking i3_name set value "Nethercap"
function evercraft:cooking/gui/render_recipe_3_disc

# === Slot 3: Tidal Glaze Cake — Tidal Comb + Salted Fish [PLAN-nest §5] ===
execute store result score #ck_i1 ec.temp run clear @s honeycomb[custom_data~{ingredient_id:"tidal_comb"}] 0
execute if score #ck_i1 ec.temp matches 1.. run data modify storage evercraft:cooking i1_color set value "green"
execute if score #ck_i1 ec.temp matches 0 run data modify storage evercraft:cooking i1_color set value "red"
execute store result score #ck_i2 ec.temp run clear @s cooked_cod[custom_data~{ingredient_id:"salted_fish"}] 0
execute if score #ck_i2 ec.temp matches 1.. run data modify storage evercraft:cooking i2_color set value "green"
execute if score #ck_i2 ec.temp matches 0 run data modify storage evercraft:cooking i2_color set value "red"
data modify storage evercraft:cooking r_slot set value "3"
data modify storage evercraft:cooking r_name set value "Tidal Glaze Cake"
data modify storage evercraft:cooking r_tier_color set value "aqua"
data modify storage evercraft:cooking i1_name set value "Tidal Comb"
data modify storage evercraft:cooking i2_name set value "Salted Fish"
function evercraft:cooking/gui/render_recipe_2_disc

# === Slot 4: Emberglow Confit — Ember Nectar (honey_bottle) + Magma Salt [PLAN-nest §5 / R9] ===
execute store result score #ck_i1 ec.temp run clear @s honey_bottle[custom_data~{ingredient_id:"ember_nectar"}] 0
execute if score #ck_i1 ec.temp matches 1.. run data modify storage evercraft:cooking i1_color set value "green"
execute if score #ck_i1 ec.temp matches 0 run data modify storage evercraft:cooking i1_color set value "red"
execute store result score #ck_i2 ec.temp run clear @s magma_cream[custom_data~{ingredient_id:"magma_salt"}] 0
execute if score #ck_i2 ec.temp matches 1.. run data modify storage evercraft:cooking i2_color set value "green"
execute if score #ck_i2 ec.temp matches 0 run data modify storage evercraft:cooking i2_color set value "red"
data modify storage evercraft:cooking r_slot set value "4"
data modify storage evercraft:cooking r_name set value "Emberglow Confit"
data modify storage evercraft:cooking r_tier_color set value "red"
data modify storage evercraft:cooking i1_name set value "Ember Nectar"
data modify storage evercraft:cooking i2_name set value "Magma Salt"
function evercraft:cooking/gui/render_recipe_2_disc

# === Slot 5: Astral Honey Ambrosia — Astral Comb + Chorus Extract [PLAN-nest §5] ===
execute store result score #ck_i1 ec.temp run clear @s honeycomb[custom_data~{ingredient_id:"astral_comb"}] 0
execute if score #ck_i1 ec.temp matches 1.. run data modify storage evercraft:cooking i1_color set value "green"
execute if score #ck_i1 ec.temp matches 0 run data modify storage evercraft:cooking i1_color set value "red"
execute store result score #ck_i2 ec.temp run clear @s chorus_fruit[custom_data~{ingredient_id:"chorus_extract"}] 0
execute if score #ck_i2 ec.temp matches 1.. run data modify storage evercraft:cooking i2_color set value "green"
execute if score #ck_i2 ec.temp matches 0 run data modify storage evercraft:cooking i2_color set value "red"
data modify storage evercraft:cooking r_slot set value "5"
data modify storage evercraft:cooking r_name set value "Astral Honey Ambrosia"
data modify storage evercraft:cooking r_tier_color set value "light_purple"
data modify storage evercraft:cooking i1_name set value "Astral Comb"
data modify storage evercraft:cooking i2_name set value "Chorus Extract"
function evercraft:cooking/gui/render_recipe_2_disc
