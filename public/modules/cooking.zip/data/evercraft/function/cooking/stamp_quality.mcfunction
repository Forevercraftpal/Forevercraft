# ============================================================
# Stamp cook_quality onto the just-cooked meal (Wiring Audit #26 Q4, Joseph).
# Quality lives on the meal ITEM (custom_data.cook_quality), read at eat-time by the eat_cqN
# advancements -> deferred apply. Macro arg $(q) = ec.ck_quality_mod (0-3) at cook time.
#
# MC 26.2 (1.21.5+): `data modify entity @s Inventory[...]` is read-only and silently no-op'd, so the
# stamp never landed. Now each un-stamped meal slot is handed to stamp_quality_slot, which merges the
# quality onto the item via a writable hopper-minecart and swaps it back. Scans hotbar + main inventory;
# normally exactly one meal is un-stamped (the freshly-cooked one), but all matches get stamped.
# ============================================================
$execute if items entity @s hotbar.0 *[custom_data~{ec_meal:true}] unless items entity @s hotbar.0 *[custom_data~{cq_done:true}] run function evercraft:cooking/stamp_quality_slot {slot:"hotbar.0",q:$(q)}
$execute if items entity @s hotbar.1 *[custom_data~{ec_meal:true}] unless items entity @s hotbar.1 *[custom_data~{cq_done:true}] run function evercraft:cooking/stamp_quality_slot {slot:"hotbar.1",q:$(q)}
$execute if items entity @s hotbar.2 *[custom_data~{ec_meal:true}] unless items entity @s hotbar.2 *[custom_data~{cq_done:true}] run function evercraft:cooking/stamp_quality_slot {slot:"hotbar.2",q:$(q)}
$execute if items entity @s hotbar.3 *[custom_data~{ec_meal:true}] unless items entity @s hotbar.3 *[custom_data~{cq_done:true}] run function evercraft:cooking/stamp_quality_slot {slot:"hotbar.3",q:$(q)}
$execute if items entity @s hotbar.4 *[custom_data~{ec_meal:true}] unless items entity @s hotbar.4 *[custom_data~{cq_done:true}] run function evercraft:cooking/stamp_quality_slot {slot:"hotbar.4",q:$(q)}
$execute if items entity @s hotbar.5 *[custom_data~{ec_meal:true}] unless items entity @s hotbar.5 *[custom_data~{cq_done:true}] run function evercraft:cooking/stamp_quality_slot {slot:"hotbar.5",q:$(q)}
$execute if items entity @s hotbar.6 *[custom_data~{ec_meal:true}] unless items entity @s hotbar.6 *[custom_data~{cq_done:true}] run function evercraft:cooking/stamp_quality_slot {slot:"hotbar.6",q:$(q)}
$execute if items entity @s hotbar.7 *[custom_data~{ec_meal:true}] unless items entity @s hotbar.7 *[custom_data~{cq_done:true}] run function evercraft:cooking/stamp_quality_slot {slot:"hotbar.7",q:$(q)}
$execute if items entity @s hotbar.8 *[custom_data~{ec_meal:true}] unless items entity @s hotbar.8 *[custom_data~{cq_done:true}] run function evercraft:cooking/stamp_quality_slot {slot:"hotbar.8",q:$(q)}
$execute if items entity @s inventory.0 *[custom_data~{ec_meal:true}] unless items entity @s inventory.0 *[custom_data~{cq_done:true}] run function evercraft:cooking/stamp_quality_slot {slot:"inventory.0",q:$(q)}
$execute if items entity @s inventory.1 *[custom_data~{ec_meal:true}] unless items entity @s inventory.1 *[custom_data~{cq_done:true}] run function evercraft:cooking/stamp_quality_slot {slot:"inventory.1",q:$(q)}
$execute if items entity @s inventory.2 *[custom_data~{ec_meal:true}] unless items entity @s inventory.2 *[custom_data~{cq_done:true}] run function evercraft:cooking/stamp_quality_slot {slot:"inventory.2",q:$(q)}
$execute if items entity @s inventory.3 *[custom_data~{ec_meal:true}] unless items entity @s inventory.3 *[custom_data~{cq_done:true}] run function evercraft:cooking/stamp_quality_slot {slot:"inventory.3",q:$(q)}
$execute if items entity @s inventory.4 *[custom_data~{ec_meal:true}] unless items entity @s inventory.4 *[custom_data~{cq_done:true}] run function evercraft:cooking/stamp_quality_slot {slot:"inventory.4",q:$(q)}
$execute if items entity @s inventory.5 *[custom_data~{ec_meal:true}] unless items entity @s inventory.5 *[custom_data~{cq_done:true}] run function evercraft:cooking/stamp_quality_slot {slot:"inventory.5",q:$(q)}
$execute if items entity @s inventory.6 *[custom_data~{ec_meal:true}] unless items entity @s inventory.6 *[custom_data~{cq_done:true}] run function evercraft:cooking/stamp_quality_slot {slot:"inventory.6",q:$(q)}
$execute if items entity @s inventory.7 *[custom_data~{ec_meal:true}] unless items entity @s inventory.7 *[custom_data~{cq_done:true}] run function evercraft:cooking/stamp_quality_slot {slot:"inventory.7",q:$(q)}
$execute if items entity @s inventory.8 *[custom_data~{ec_meal:true}] unless items entity @s inventory.8 *[custom_data~{cq_done:true}] run function evercraft:cooking/stamp_quality_slot {slot:"inventory.8",q:$(q)}
$execute if items entity @s inventory.9 *[custom_data~{ec_meal:true}] unless items entity @s inventory.9 *[custom_data~{cq_done:true}] run function evercraft:cooking/stamp_quality_slot {slot:"inventory.9",q:$(q)}
$execute if items entity @s inventory.10 *[custom_data~{ec_meal:true}] unless items entity @s inventory.10 *[custom_data~{cq_done:true}] run function evercraft:cooking/stamp_quality_slot {slot:"inventory.10",q:$(q)}
$execute if items entity @s inventory.11 *[custom_data~{ec_meal:true}] unless items entity @s inventory.11 *[custom_data~{cq_done:true}] run function evercraft:cooking/stamp_quality_slot {slot:"inventory.11",q:$(q)}
$execute if items entity @s inventory.12 *[custom_data~{ec_meal:true}] unless items entity @s inventory.12 *[custom_data~{cq_done:true}] run function evercraft:cooking/stamp_quality_slot {slot:"inventory.12",q:$(q)}
$execute if items entity @s inventory.13 *[custom_data~{ec_meal:true}] unless items entity @s inventory.13 *[custom_data~{cq_done:true}] run function evercraft:cooking/stamp_quality_slot {slot:"inventory.13",q:$(q)}
$execute if items entity @s inventory.14 *[custom_data~{ec_meal:true}] unless items entity @s inventory.14 *[custom_data~{cq_done:true}] run function evercraft:cooking/stamp_quality_slot {slot:"inventory.14",q:$(q)}
$execute if items entity @s inventory.15 *[custom_data~{ec_meal:true}] unless items entity @s inventory.15 *[custom_data~{cq_done:true}] run function evercraft:cooking/stamp_quality_slot {slot:"inventory.15",q:$(q)}
$execute if items entity @s inventory.16 *[custom_data~{ec_meal:true}] unless items entity @s inventory.16 *[custom_data~{cq_done:true}] run function evercraft:cooking/stamp_quality_slot {slot:"inventory.16",q:$(q)}
$execute if items entity @s inventory.17 *[custom_data~{ec_meal:true}] unless items entity @s inventory.17 *[custom_data~{cq_done:true}] run function evercraft:cooking/stamp_quality_slot {slot:"inventory.17",q:$(q)}
$execute if items entity @s inventory.18 *[custom_data~{ec_meal:true}] unless items entity @s inventory.18 *[custom_data~{cq_done:true}] run function evercraft:cooking/stamp_quality_slot {slot:"inventory.18",q:$(q)}
$execute if items entity @s inventory.19 *[custom_data~{ec_meal:true}] unless items entity @s inventory.19 *[custom_data~{cq_done:true}] run function evercraft:cooking/stamp_quality_slot {slot:"inventory.19",q:$(q)}
$execute if items entity @s inventory.20 *[custom_data~{ec_meal:true}] unless items entity @s inventory.20 *[custom_data~{cq_done:true}] run function evercraft:cooking/stamp_quality_slot {slot:"inventory.20",q:$(q)}
$execute if items entity @s inventory.21 *[custom_data~{ec_meal:true}] unless items entity @s inventory.21 *[custom_data~{cq_done:true}] run function evercraft:cooking/stamp_quality_slot {slot:"inventory.21",q:$(q)}
$execute if items entity @s inventory.22 *[custom_data~{ec_meal:true}] unless items entity @s inventory.22 *[custom_data~{cq_done:true}] run function evercraft:cooking/stamp_quality_slot {slot:"inventory.22",q:$(q)}
$execute if items entity @s inventory.23 *[custom_data~{ec_meal:true}] unless items entity @s inventory.23 *[custom_data~{cq_done:true}] run function evercraft:cooking/stamp_quality_slot {slot:"inventory.23",q:$(q)}
$execute if items entity @s inventory.24 *[custom_data~{ec_meal:true}] unless items entity @s inventory.24 *[custom_data~{cq_done:true}] run function evercraft:cooking/stamp_quality_slot {slot:"inventory.24",q:$(q)}
$execute if items entity @s inventory.25 *[custom_data~{ec_meal:true}] unless items entity @s inventory.25 *[custom_data~{cq_done:true}] run function evercraft:cooking/stamp_quality_slot {slot:"inventory.25",q:$(q)}
$execute if items entity @s inventory.26 *[custom_data~{ec_meal:true}] unless items entity @s inventory.26 *[custom_data~{cq_done:true}] run function evercraft:cooking/stamp_quality_slot {slot:"inventory.26",q:$(q)}
