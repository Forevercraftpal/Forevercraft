# Forage drop: Shearing a full hive (honey_level 5) with shears → bonus Wild Honeycomb.
# Run as @s = player, from advancement evercraft:cooking/forage/shear_hive
# (minecraft:item_used_on_block on beehive/bee_nest at honey_level 5 with shears).
# This is a BONUS on top of the vanilla honeycomb harvest; sources wild_honeycomb,
# the Honey Cake treat ingredient (cook_treats slot 2). Mirrors on_kill_fish's idiom.
advancement revoke @s only evercraft:cooking/forage/shear_hive

# ~20% bonus chance to drop the wild honeycomb.
execute store result score #ck_roll ec.temp run random value 1..100
# Wiring Audit #26 cooking Q3: inv-full guard — drop at feet instead of voiding the comb.
execute if score #ck_roll ec.temp matches ..20 store result score #inv_full ec.var run function evercraft:util/check_inv_full
execute if score #ck_roll ec.temp matches ..20 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:cooking/ingredients/wild_honeycomb
execute if score #ck_roll ec.temp matches ..20 if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:cooking/ingredients/wild_honeycomb
data modify storage evercraft:notify stage.c set value [{text:"You harvested ",color:"gray"},{text:"Wild Honeycomb",color:"green"},{text:"!",color:"gray"}]
scoreboard players set #ndur ec.temp 45
execute if score #ck_roll ec.temp matches ..20 run function evercraft:util/notify/emit
execute if score #ck_roll ec.temp matches ..20 run scoreboard players add @s adv.stat_cook 1
execute if score #ck_roll ec.temp matches ..20 at @s run function evercraft:fx/cook/ingredient_ping
