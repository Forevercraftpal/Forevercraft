# ============================================================
# Spirit Cuisine — rare Spirit Fish fishing catch (Wiring Audit #26 cooking Q2)
# Called from evercraft:fishing/ref/on_catch on every successful fishing catch.
# Run as the player, at the player (caller does `at @s`).
#
# Scheme: one roll 1..1000 per catch. Each of the 4 Spirit Fish is themed and
# condition/biome-gated, checked rarest-first. At most ONE fish per catch — each
# branch `return`s after granting so buckets never overlap and we never
# double-grant. Total spirit-fish chance per catch is ~2.5% (gates permitting).
#
#   Leviathan's Whisker  3/1000  (~0.3%)  deep ocean only — rarest, the abyssal one
#   Voidfin              6/1000  (~0.6%)  the End, or deep ocean (void/dark theme)
#   Starscale Trout      8/1000  (~0.8%)  night, any water (constellation theme)
#   Deepcurrent Eel      8/1000  (~0.8%)  rivers or oceans (current theme)
#
# Drops use the existing cooking/spirit_fish/<name> loot tables, which emit
# tropical_fish[custom_data~{spirit_fish:true,fish_type:"<name>"}] — exactly the
# predicate cook_spirit's recipes clear. Inv-full guard mirrors on_kill_fish.
# ============================================================

execute store result score #sf_roll ec.temp run random value 1..1000
# Bait — Spirit Brine pre-roll bias (set by evercraft:fishing/bait/set_bias before this
# call). Subtracting from the roll pushes it toward the rarer low-numbered bands, raising
# spirit-fish odds. #sf_bias is 0 when no brine was held, so this is a no-op for non-users
# (the floor clamp below only fires when bias was actually applied).
scoreboard players operation #sf_roll ec.temp -= #sf_bias ec.temp
# Floor biased rolls at 4 (skip the deep-ocean-ONLY Leviathan band 1..3) so the bias
# lands in the more-reachable Voidfin/Starscale/Deepcurrent bands rather than whiffing
# on a band the player's location can't satisfy. Only clamps when brine was actually held.
execute if score #sf_bias ec.temp matches 1.. if score #sf_roll ec.temp matches ..3 run scoreboard players set #sf_roll ec.temp 4
execute store result score #inv_full ec.var run function evercraft:util/check_inv_full

# --- Leviathan's Whisker (rarest): 1..3, deep ocean only ---
execute if score #sf_roll ec.temp matches 1..3 if predicate evercraft:mobs/location/in_deep_blue run function evercraft:cooking/spirit_fish/grant/leviathans_whisker
execute if score #sf_roll ec.temp matches 1..3 if predicate evercraft:mobs/location/in_deep_blue run return 1

# --- Voidfin: 4..9, the End OR deep ocean ---
execute if score #sf_roll ec.temp matches 4..9 if predicate evercraft:in_end run function evercraft:cooking/spirit_fish/grant/voidfin
execute if score #sf_roll ec.temp matches 4..9 if predicate evercraft:in_end run return 1
execute if score #sf_roll ec.temp matches 4..9 if predicate evercraft:mobs/location/in_deep_blue run function evercraft:cooking/spirit_fish/grant/voidfin
execute if score #sf_roll ec.temp matches 4..9 if predicate evercraft:mobs/location/in_deep_blue run return 1

# --- Starscale Trout: 10..17, night (visual_time 13000..23000), any water ---
execute if score #sf_roll ec.temp matches 10..17 if score #visual_time ec.var matches 13000..23000 run function evercraft:cooking/spirit_fish/grant/starscale
execute if score #sf_roll ec.temp matches 10..17 if score #visual_time ec.var matches 13000..23000 run return 1

# --- Deepcurrent Eel: 18..25, rivers OR oceans ---
execute if score #sf_roll ec.temp matches 18..25 if predicate evercraft:biome/is_river run function evercraft:cooking/spirit_fish/grant/deepcurrent
execute if score #sf_roll ec.temp matches 18..25 if predicate evercraft:biome/is_river run return 1
execute if score #sf_roll ec.temp matches 18..25 if predicate evercraft:craftforever/biome/ocean run function evercraft:cooking/spirit_fish/grant/deepcurrent
execute if score #sf_roll ec.temp matches 18..25 if predicate evercraft:craftforever/biome/ocean run return 1

return 0
