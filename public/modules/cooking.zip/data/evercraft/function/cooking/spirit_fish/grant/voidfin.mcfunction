# Spirit Fish catch — Voidfin (dark_purple, void/End theme)
# Run as + at the player. #inv_full already set by try_catch.
execute if score #inv_full ec.var matches 0 run loot give @s loot evercraft:cooking/spirit_fish/voidfin
execute if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:cooking/spirit_fish/voidfin
data modify storage evercraft:notify stage.c set value [{text:"An ancient presence stirs the line— you reeled up a ",color:"gray"},{text:"Voidfin",color:"dark_purple",bold:true},{text:"!",color:"gray"}]
scoreboard players set #ndur ec.temp 50
function evercraft:util/notify/emit
scoreboard players set #ck_sf ec.temp 2
execute at @s run function evercraft:fx/cook/spirit_fish
function evercraft:craft_affinity/grant {class_id:5, delta:97}
data modify storage evercraft:notify stage.c set value [{text:"The catch of a lifetime sharpens your art!",color:"#87CEEB",italic:true}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit
# Fisher's Questline — catch_aquatic hook (gated; no-op unless active questline).
execute if score @s ec.fq_active matches 1 run function evercraft:fishing/questline/on_aquatic_hook {fish_type:"voidfin"}
