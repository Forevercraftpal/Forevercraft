# ============================================================
# Cook Spiced Recipes — Runs as player (category 11)
# #ck_slot = recipe slot, #ck_ok = set to 0 if ingredients missing
# Two recipe PAGES share the 6 slots, gated on @s ec.ck_spage:
#   Page 0 (spage 0): 6 overworld-spice meals, slots 0-5.
#   Page 1 (spage 1): 3 dimensional-spice meals, slots 0-2 (3-5 are blank/no-op).
# Each recipe = one node-tree Spice + a base food -> a buffed "Seasoned..." meal.
# Spices carry custom_data~{ingredient_id:"<id>"}; base foods are vanilla.
# Frostmint/Jungle checks are base-agnostic (*[...]) so the new sugar items AND any
# legacy fern/cocoa ones both satisfy the recipe.
# ============================================================

# ============================================================
# === PAGE 0: Overworld spices ===============================
# ============================================================

# --- Slot 0: Seasoned Loaf — Cinnamon Bark + Bread ---
execute if score @s ec.ck_spage matches 0 if score #ck_slot ec.temp matches 0 store result score #ck_i1 ec.temp run clear @s sugar[custom_data~{ingredient_id:"cinnamon_bark"}] 0
execute if score @s ec.ck_spage matches 0 if score #ck_slot ec.temp matches 0 store result score #ck_i2 ec.temp run clear @s minecraft:bread 0
execute if score @s ec.ck_spage matches 0 if score #ck_slot ec.temp matches 0 if score #ck_i1 ec.temp matches 0 run scoreboard players set #ck_ok ec.temp 0
execute if score @s ec.ck_spage matches 0 if score #ck_slot ec.temp matches 0 if score #ck_i2 ec.temp matches 0 run scoreboard players set #ck_ok ec.temp 0
execute if score @s ec.ck_spage matches 0 if score #ck_slot ec.temp matches 0 if score #ck_ok ec.temp matches 1 unless entity @s[tag=CK.FreeCook] run clear @s sugar[custom_data~{ingredient_id:"cinnamon_bark"}] 1
execute if score @s ec.ck_spage matches 0 if score #ck_slot ec.temp matches 0 if score #ck_ok ec.temp matches 1 unless entity @s[tag=CK.FreeCook] run clear @s minecraft:bread 1
execute if score @s ec.ck_spage matches 0 if score #ck_slot ec.temp matches 0 if score #ck_ok ec.temp matches 1 run function evercraft:cooking/give_meal {tbl:"cooking/meals/seasoned_loaf"}
data modify storage evercraft:notify stage.c set value [{text:"You cooked ",color:"gray"},{text:"Seasoned Loaf",color:"#C97A40"},{text:"!",color:"gray"}]
scoreboard players set #ndur ec.temp 45
execute if score @s ec.ck_spage matches 0 if score #ck_slot ec.temp matches 0 if score #ck_ok ec.temp matches 1 run function evercraft:util/notify/emit

# --- Slot 1: Frostmint Fillet — Frostmint Spice + Cooked Cod ---
execute if score @s ec.ck_spage matches 0 if score #ck_slot ec.temp matches 1 store result score #ck_i1 ec.temp run clear @s *[custom_data~{ingredient_id:"frostmint"}] 0
execute if score @s ec.ck_spage matches 0 if score #ck_slot ec.temp matches 1 store result score #ck_i2 ec.temp run clear @s minecraft:cooked_cod 0
execute if score @s ec.ck_spage matches 0 if score #ck_slot ec.temp matches 1 if score #ck_i1 ec.temp matches 0 run scoreboard players set #ck_ok ec.temp 0
execute if score @s ec.ck_spage matches 0 if score #ck_slot ec.temp matches 1 if score #ck_i2 ec.temp matches 0 run scoreboard players set #ck_ok ec.temp 0
execute if score @s ec.ck_spage matches 0 if score #ck_slot ec.temp matches 1 if score #ck_ok ec.temp matches 1 unless entity @s[tag=CK.FreeCook] run clear @s *[custom_data~{ingredient_id:"frostmint"}] 1
execute if score @s ec.ck_spage matches 0 if score #ck_slot ec.temp matches 1 if score #ck_ok ec.temp matches 1 unless entity @s[tag=CK.FreeCook] run clear @s minecraft:cooked_cod 1
execute if score @s ec.ck_spage matches 0 if score #ck_slot ec.temp matches 1 if score #ck_ok ec.temp matches 1 run function evercraft:cooking/give_meal {tbl:"cooking/meals/frostmint_fillet"}
data modify storage evercraft:notify stage.c set value [{text:"You cooked ",color:"gray"},{text:"Frostmint Fillet",color:"#88DDFF"},{text:"!",color:"gray"}]
scoreboard players set #ndur ec.temp 45
execute if score @s ec.ck_spage matches 0 if score #ck_slot ec.temp matches 1 if score #ck_ok ec.temp matches 1 run function evercraft:util/notify/emit

# --- Slot 2: Thyme Roast — Wild Thyme + Cooked Chicken ---
execute if score @s ec.ck_spage matches 0 if score #ck_slot ec.temp matches 2 store result score #ck_i1 ec.temp run clear @s sugar[custom_data~{ingredient_id:"wild_thyme"}] 0
execute if score @s ec.ck_spage matches 0 if score #ck_slot ec.temp matches 2 store result score #ck_i2 ec.temp run clear @s minecraft:cooked_chicken 0
execute if score @s ec.ck_spage matches 0 if score #ck_slot ec.temp matches 2 if score #ck_i1 ec.temp matches 0 run scoreboard players set #ck_ok ec.temp 0
execute if score @s ec.ck_spage matches 0 if score #ck_slot ec.temp matches 2 if score #ck_i2 ec.temp matches 0 run scoreboard players set #ck_ok ec.temp 0
execute if score @s ec.ck_spage matches 0 if score #ck_slot ec.temp matches 2 if score #ck_ok ec.temp matches 1 unless entity @s[tag=CK.FreeCook] run clear @s sugar[custom_data~{ingredient_id:"wild_thyme"}] 1
execute if score @s ec.ck_spage matches 0 if score #ck_slot ec.temp matches 2 if score #ck_ok ec.temp matches 1 unless entity @s[tag=CK.FreeCook] run clear @s minecraft:cooked_chicken 1
execute if score @s ec.ck_spage matches 0 if score #ck_slot ec.temp matches 2 if score #ck_ok ec.temp matches 1 run function evercraft:cooking/give_meal {tbl:"cooking/meals/thyme_roast"}
data modify storage evercraft:notify stage.c set value [{text:"You cooked ",color:"gray"},{text:"Thyme Roast",color:"#7FB05A"},{text:"!",color:"gray"}]
scoreboard players set #ndur ec.temp 45
execute if score @s ec.ck_spage matches 0 if score #ck_slot ec.temp matches 2 if score #ck_ok ec.temp matches 1 run function evercraft:util/notify/emit

# --- Slot 3: Peppered Chop — Jungle Pepper + Cooked Porkchop ---
execute if score @s ec.ck_spage matches 0 if score #ck_slot ec.temp matches 3 store result score #ck_i1 ec.temp run clear @s *[custom_data~{ingredient_id:"jungle_pepper"}] 0
execute if score @s ec.ck_spage matches 0 if score #ck_slot ec.temp matches 3 store result score #ck_i2 ec.temp run clear @s minecraft:cooked_porkchop 0
execute if score @s ec.ck_spage matches 0 if score #ck_slot ec.temp matches 3 if score #ck_i1 ec.temp matches 0 run scoreboard players set #ck_ok ec.temp 0
execute if score @s ec.ck_spage matches 0 if score #ck_slot ec.temp matches 3 if score #ck_i2 ec.temp matches 0 run scoreboard players set #ck_ok ec.temp 0
execute if score @s ec.ck_spage matches 0 if score #ck_slot ec.temp matches 3 if score #ck_ok ec.temp matches 1 unless entity @s[tag=CK.FreeCook] run clear @s *[custom_data~{ingredient_id:"jungle_pepper"}] 1
execute if score @s ec.ck_spage matches 0 if score #ck_slot ec.temp matches 3 if score #ck_ok ec.temp matches 1 unless entity @s[tag=CK.FreeCook] run clear @s minecraft:cooked_porkchop 1
execute if score @s ec.ck_spage matches 0 if score #ck_slot ec.temp matches 3 if score #ck_ok ec.temp matches 1 run function evercraft:cooking/give_meal {tbl:"cooking/meals/peppered_chop"}
data modify storage evercraft:notify stage.c set value [{text:"You cooked ",color:"gray"},{text:"Peppered Chop",color:"#4CAF50"},{text:"!",color:"gray"}]
scoreboard players set #ndur ec.temp 45
execute if score @s ec.ck_spage matches 0 if score #ck_slot ec.temp matches 3 if score #ck_ok ec.temp matches 1 run function evercraft:util/notify/emit

# --- Slot 4: Blossom Tart — Blossom Sugar + Pumpkin Pie ---
execute if score @s ec.ck_spage matches 0 if score #ck_slot ec.temp matches 4 store result score #ck_i1 ec.temp run clear @s sugar[custom_data~{ingredient_id:"blossom_sugar"}] 0
execute if score @s ec.ck_spage matches 0 if score #ck_slot ec.temp matches 4 store result score #ck_i2 ec.temp run clear @s minecraft:pumpkin_pie 0
execute if score @s ec.ck_spage matches 0 if score #ck_slot ec.temp matches 4 if score #ck_i1 ec.temp matches 0 run scoreboard players set #ck_ok ec.temp 0
execute if score @s ec.ck_spage matches 0 if score #ck_slot ec.temp matches 4 if score #ck_i2 ec.temp matches 0 run scoreboard players set #ck_ok ec.temp 0
execute if score @s ec.ck_spage matches 0 if score #ck_slot ec.temp matches 4 if score #ck_ok ec.temp matches 1 unless entity @s[tag=CK.FreeCook] run clear @s sugar[custom_data~{ingredient_id:"blossom_sugar"}] 1
execute if score @s ec.ck_spage matches 0 if score #ck_slot ec.temp matches 4 if score #ck_ok ec.temp matches 1 unless entity @s[tag=CK.FreeCook] run clear @s minecraft:pumpkin_pie 1
execute if score @s ec.ck_spage matches 0 if score #ck_slot ec.temp matches 4 if score #ck_ok ec.temp matches 1 run function evercraft:cooking/give_meal {tbl:"cooking/meals/blossom_tart"}
data modify storage evercraft:notify stage.c set value [{text:"You cooked ",color:"gray"},{text:"Blossom Tart",color:"#F4A6C0"},{text:"!",color:"gray"}]
scoreboard players set #ndur ec.temp 45
execute if score @s ec.ck_spage matches 0 if score #ck_slot ec.temp matches 4 if score #ck_ok ec.temp matches 1 run function evercraft:util/notify/emit

# --- Slot 5: Bog Stew — Bog Pepper + Cooked Mutton ---
execute if score @s ec.ck_spage matches 0 if score #ck_slot ec.temp matches 5 store result score #ck_i1 ec.temp run clear @s sugar[custom_data~{ingredient_id:"bog_pepper"}] 0
execute if score @s ec.ck_spage matches 0 if score #ck_slot ec.temp matches 5 store result score #ck_i2 ec.temp run clear @s minecraft:cooked_mutton 0
execute if score @s ec.ck_spage matches 0 if score #ck_slot ec.temp matches 5 if score #ck_i1 ec.temp matches 0 run scoreboard players set #ck_ok ec.temp 0
execute if score @s ec.ck_spage matches 0 if score #ck_slot ec.temp matches 5 if score #ck_i2 ec.temp matches 0 run scoreboard players set #ck_ok ec.temp 0
execute if score @s ec.ck_spage matches 0 if score #ck_slot ec.temp matches 5 if score #ck_ok ec.temp matches 1 unless entity @s[tag=CK.FreeCook] run clear @s sugar[custom_data~{ingredient_id:"bog_pepper"}] 1
execute if score @s ec.ck_spage matches 0 if score #ck_slot ec.temp matches 5 if score #ck_ok ec.temp matches 1 unless entity @s[tag=CK.FreeCook] run clear @s minecraft:cooked_mutton 1
execute if score @s ec.ck_spage matches 0 if score #ck_slot ec.temp matches 5 if score #ck_ok ec.temp matches 1 run function evercraft:cooking/give_meal {tbl:"cooking/meals/bog_stew"}
data modify storage evercraft:notify stage.c set value [{text:"You cooked ",color:"gray"},{text:"Bog Stew",color:"#6B7A4A"},{text:"!",color:"gray"}]
scoreboard players set #ndur ec.temp 45
execute if score @s ec.ck_spage matches 0 if score #ck_slot ec.temp matches 5 if score #ck_ok ec.temp matches 1 run function evercraft:util/notify/emit

# ============================================================
# === PAGE 1: Dimensional/exotic spices (slots 0-2) =========
# ============================================================

# --- Slot 0: Ember Steak — Emberzest + Cooked Beef ---
execute if score @s ec.ck_spage matches 1 if score #ck_slot ec.temp matches 0 store result score #ck_i1 ec.temp run clear @s sugar[custom_data~{ingredient_id:"emberzest"}] 0
execute if score @s ec.ck_spage matches 1 if score #ck_slot ec.temp matches 0 store result score #ck_i2 ec.temp run clear @s minecraft:cooked_beef 0
execute if score @s ec.ck_spage matches 1 if score #ck_slot ec.temp matches 0 if score #ck_i1 ec.temp matches 0 run scoreboard players set #ck_ok ec.temp 0
execute if score @s ec.ck_spage matches 1 if score #ck_slot ec.temp matches 0 if score #ck_i2 ec.temp matches 0 run scoreboard players set #ck_ok ec.temp 0
execute if score @s ec.ck_spage matches 1 if score #ck_slot ec.temp matches 0 if score #ck_ok ec.temp matches 1 unless entity @s[tag=CK.FreeCook] run clear @s sugar[custom_data~{ingredient_id:"emberzest"}] 1
execute if score @s ec.ck_spage matches 1 if score #ck_slot ec.temp matches 0 if score #ck_ok ec.temp matches 1 unless entity @s[tag=CK.FreeCook] run clear @s minecraft:cooked_beef 1
execute if score @s ec.ck_spage matches 1 if score #ck_slot ec.temp matches 0 if score #ck_ok ec.temp matches 1 run function evercraft:cooking/give_meal {tbl:"cooking/meals/ember_steak"}
data modify storage evercraft:notify stage.c set value [{text:"You cooked ",color:"gray"},{text:"Ember Steak",color:"#E0522A"},{text:"!",color:"gray"}]
scoreboard players set #ndur ec.temp 45
execute if score @s ec.ck_spage matches 1 if score #ck_slot ec.temp matches 0 if score #ck_ok ec.temp matches 1 run function evercraft:util/notify/emit

# --- Slot 1: Voidsalt Stew — Void Salt + Cooked Rabbit ---
execute if score @s ec.ck_spage matches 1 if score #ck_slot ec.temp matches 1 store result score #ck_i1 ec.temp run clear @s sugar[custom_data~{ingredient_id:"void_salt"}] 0
execute if score @s ec.ck_spage matches 1 if score #ck_slot ec.temp matches 1 store result score #ck_i2 ec.temp run clear @s minecraft:cooked_rabbit 0
execute if score @s ec.ck_spage matches 1 if score #ck_slot ec.temp matches 1 if score #ck_i1 ec.temp matches 0 run scoreboard players set #ck_ok ec.temp 0
execute if score @s ec.ck_spage matches 1 if score #ck_slot ec.temp matches 1 if score #ck_i2 ec.temp matches 0 run scoreboard players set #ck_ok ec.temp 0
execute if score @s ec.ck_spage matches 1 if score #ck_slot ec.temp matches 1 if score #ck_ok ec.temp matches 1 unless entity @s[tag=CK.FreeCook] run clear @s sugar[custom_data~{ingredient_id:"void_salt"}] 1
execute if score @s ec.ck_spage matches 1 if score #ck_slot ec.temp matches 1 if score #ck_ok ec.temp matches 1 unless entity @s[tag=CK.FreeCook] run clear @s minecraft:cooked_rabbit 1
execute if score @s ec.ck_spage matches 1 if score #ck_slot ec.temp matches 1 if score #ck_ok ec.temp matches 1 run function evercraft:cooking/give_meal {tbl:"cooking/meals/voidsalt_stew"}
data modify storage evercraft:notify stage.c set value [{text:"You cooked ",color:"gray"},{text:"Voidsalt Stew",color:"#9C6ADE"},{text:"!",color:"gray"}]
scoreboard players set #ndur ec.temp 45
execute if score @s ec.ck_spage matches 1 if score #ck_slot ec.temp matches 1 if score #ck_ok ec.temp matches 1 run function evercraft:util/notify/emit

# --- Slot 2: Marrow Broth — Marrow Dust + Cooked Salmon ---
execute if score @s ec.ck_spage matches 1 if score #ck_slot ec.temp matches 2 store result score #ck_i1 ec.temp run clear @s sugar[custom_data~{ingredient_id:"marrow_dust"}] 0
execute if score @s ec.ck_spage matches 1 if score #ck_slot ec.temp matches 2 store result score #ck_i2 ec.temp run clear @s minecraft:cooked_salmon 0
execute if score @s ec.ck_spage matches 1 if score #ck_slot ec.temp matches 2 if score #ck_i1 ec.temp matches 0 run scoreboard players set #ck_ok ec.temp 0
execute if score @s ec.ck_spage matches 1 if score #ck_slot ec.temp matches 2 if score #ck_i2 ec.temp matches 0 run scoreboard players set #ck_ok ec.temp 0
execute if score @s ec.ck_spage matches 1 if score #ck_slot ec.temp matches 2 if score #ck_ok ec.temp matches 1 unless entity @s[tag=CK.FreeCook] run clear @s sugar[custom_data~{ingredient_id:"marrow_dust"}] 1
execute if score @s ec.ck_spage matches 1 if score #ck_slot ec.temp matches 2 if score #ck_ok ec.temp matches 1 unless entity @s[tag=CK.FreeCook] run clear @s minecraft:cooked_salmon 1
execute if score @s ec.ck_spage matches 1 if score #ck_slot ec.temp matches 2 if score #ck_ok ec.temp matches 1 run function evercraft:cooking/give_meal {tbl:"cooking/meals/marrow_broth"}
data modify storage evercraft:notify stage.c set value [{text:"You cooked ",color:"gray"},{text:"Marrow Broth",color:"#D8D2BE"},{text:"!",color:"gray"}]
scoreboard players set #ndur ec.temp 45
execute if score @s ec.ck_spage matches 1 if score #ck_slot ec.temp matches 2 if score #ck_ok ec.temp matches 1 run function evercraft:util/notify/emit
