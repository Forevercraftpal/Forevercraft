# ============================================================
# Cook Dispatch — Runs as the player
# #ck_slot ec.temp = which recipe slot (0-5) was clicked
# Verifies ingredients, clears them, gives meal, and refreshes GUI
# ============================================================

# Double Portion (P2): 15% chance to preserve ingredients
tag @s remove CK.FreeCook
execute if score @s adv.pa_culi2 matches 1 store result score #free_roll ec.temp run random value 1..100
execute if score @s adv.pa_culi2 matches 1 if score #free_roll ec.temp matches 1..15 run tag @s add CK.FreeCook

# Pantry auto-pull: withdraw pantry items to inventory for ingredient checks
execute if score @s ec.has_pantry matches 1.. run function evercraft:pantry/pre_cook

# Inv-full guard (Wiring Audit #30 P2.5): compute once; give_meal drops the meal at the
# player's feet instead of voiding it when the inventory is full (CK.FreeCook frees 0 slots).
execute store result score #inv_full ec.var run function evercraft:util/check_inv_full

# Dispatch to category-specific cook function
scoreboard players set #ck_ok ec.temp 1
execute if score @s ec.ck_cat matches 0 run function evercraft:cooking/recipes/cook_combat
execute if score @s ec.ck_cat matches 1 run function evercraft:cooking/recipes/cook_mining
execute if score @s ec.ck_cat matches 2 run function evercraft:cooking/recipes/cook_fortune
execute if score @s ec.ck_cat matches 3 run function evercraft:cooking/recipes/cook_wayfarer
execute if score @s ec.ck_cat matches 4 run function evercraft:cooking/recipes/cook_delicacy
execute if score @s ec.ck_cat matches 5 run function evercraft:cooking/recipes/cook_seasonal
execute if score @s ec.ck_cat matches 6 run function evercraft:cooking/recipes/cook_treats
execute if score @s ec.ck_cat matches 7 run function evercraft:cooking/recipes/cook_rations
execute if score @s ec.ck_cat matches 8 run function evercraft:cooking/recipes/cook_feast_platter
execute if score @s ec.ck_cat matches 9 run function evercraft:cooking/recipes/cook_preservation
execute if score @s ec.ck_cat matches 10 run function evercraft:cooking/recipes/cook_spirit
execute if score @s ec.ck_cat matches 11 run function evercraft:cooking/recipes/cook_spiced

# If cook failed (missing ingredients), stop here
data modify storage evercraft:notify stage.c set value [{text:"You're missing ingredients!",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute if score #ck_ok ec.temp matches 0 run return run function evercraft:util/notify/emit

# Wiring Audit #26 Q4 (Joseph): stamp this cook's quality (0-3) onto the meal item just given,
# so the Chef's Touch bonus follows the actual dish (read at eat-time by the eat_cqN advancements),
# not a transient player score. Quick Cook leaves ck_quality_mod=1 (standard).
execute store result storage evercraft:cooking temp.q int 1 run scoreboard players get @s ec.ck_quality_mod
function evercraft:cooking/stamp_quality with storage evercraft:cooking temp

# Double Portion feedback
data modify storage evercraft:notify stage.c set value [{text:"Ingredients preserved!",color:"yellow"}]
scoreboard players set #ndur ec.temp 45
execute if entity @s[tag=CK.FreeCook] run function evercraft:util/notify/emit
tag @s remove CK.FreeCook

# Common post-cook actions
scoreboard players add @s adv.stat_cook 2
# FX — shared "you cooked a meal" base cue (gated; result ladder layers on top)
execute at @s run function evercraft:fx/cook/cooked_base

# Gathering Pipeline: Cooking at home grants +1 bonus Cooking XP
execute if score @s hs.in_zone matches 1 run scoreboard players add @s adv.stat_cook 1
data modify storage evercraft:notify stage.c set value [{text:"Home Kitchen: ",color:"gold"},{text:"+1 bonus cooking XP",color:"yellow"}]
scoreboard players set #ndur ec.temp 45
execute if score @s hs.in_zone matches 1 run function evercraft:util/notify/emit

# Gathering Pipeline: Harvest Festival doubles cooking XP
execute if score #cal_event_id ec.var matches 1 run scoreboard players add @s adv.stat_cook 2
data modify storage evercraft:notify stage.c set value [{text:"Harvest Festival: ",color:"gold"},{text:"Double cooking XP!",color:"yellow"}]
scoreboard players set #ndur ec.temp 45
execute if score #cal_event_id ec.var matches 1 run function evercraft:util/notify/emit

# Track for achievements
scoreboard players add @s ach.meals_cooked 1
function evercraft:milestones/increment/recipe_cooked

# === COOK'S QUESTLINE (Council #2 Wave C3 — FIRST content slice) ===
# ONE gate-first line: on the player's FIRST meal (line not yet active), auto-give
# the Cook's Codex + start the questline. Placed AFTER the ach.meals_cooked add so
# start's ec.cq_seen cursor snapshot includes this first meal (it does NOT retro-
# credit the first beat). For an ALREADY-active player this is a no-op gate, and
# the meal's progress is picked up by the existence-gated 20t check_progress loop
# (NOT a per-cook check call here — keeps cook_dispatch cheap; cook_xp_at +
# cooked_meal both read lifetime mirrors the loop polls). cooking/questline/* only
# READS public cooking state — it writes none of this file's objectives.
execute unless score @s ec.cq_active matches 1 run function evercraft:cooking/questline/on_first_meal
# Active player: nudge the line to re-check NOW so a satisfying meal advances on the
# same tick (snappier than waiting up to 20t). check() is existence-gated + idempotent.
execute if score @s ec.cq_active matches 1 run function evercraft:cooking/questline/check

# Artisan XP: Cooking (+4 per meal)
scoreboard players set #cf_xp_amount ec.cf_temp 4
scoreboard players set #cf_xp_cat ec.cf_temp 1
function evercraft:craftforever/artisan/add_xp

# Per-category mastery tracking
execute if score @s ec.ck_cat matches 0 run scoreboard players add @s ck.m_combat 1
execute if score @s ec.ck_cat matches 1 run scoreboard players add @s ck.m_mining 1
execute if score @s ec.ck_cat matches 2 run scoreboard players add @s ck.m_fortune 1
execute if score @s ec.ck_cat matches 3 run scoreboard players add @s ck.m_wayfarer 1
execute if score @s ec.ck_cat matches 4 run scoreboard players add @s ck.m_delicacy 1
execute if score @s ec.ck_cat matches 5 run scoreboard players add @s ck.m_seasonal 1
execute if score @s ec.ck_cat matches 6 run scoreboard players add @s ck.m_treats 1
execute if score @s ec.ck_cat matches 7 run scoreboard players add @s ck.m_ration 1
execute if score @s ec.ck_cat matches 8 run scoreboard players add @s ck.m_feast 1
execute if score @s ec.ck_cat matches 9 run scoreboard players add @s ck.m_preserve 1
execute if score @s ec.ck_cat matches 10 run scoreboard players add @s ck.m_spirit 1
execute if score @s ec.ck_cat matches 11 run scoreboard players add @s ck.m_spiced 1
function evercraft:cooking/mastery/check

# Mark recipe as discovered (first-time cook announcement)
function evercraft:cooking/discovery/mark_slot

# Wiring Audit #14 C2: light the Cooking Ingredients almanac category (cat4 #1)
# on the player's first cook. First-fire only; granular per-ingredient discovery
# is a cross-branch (cooking) followup.
function evercraft:craftforever/codex/hub/almanac/mark_found {field:"cf_cook_found",bit:1}

# Guild Expedition: Cooking bonus mastery XP (activity=13)
function evercraft:guild/expedition/bonus_cooking

# Competition: Cooking Contest scoring (type 1 — server-wide or H2H)
execute if score #comp_active ec.var matches 1 run function evercraft:competition/score/cook_item
execute unless score #comp_active ec.var matches 1 if score #h2h_active ec.var matches 1 run function evercraft:competition/score/cook_item

# Refresh GUI to update ingredient availability
function evercraft:cooking/gui/refresh
