# ============================================================
# The Cook's Questline — First-meal trigger (auto-give book + start)
# ============================================================
# Run as @s = the player, from the ONE gate-first line spliced into
# cooking/recipes/cook_dispatch (`if score @s ec.cq_active matches 0 run ...`).
# cook_dispatch is the single funnel every cooked meal passes through (both Quick
# Cook and the Chef's Touch minigame resolve into it), so it is the correct,
# robust "first meal" detector — cooking has no vanilla advancement trigger (it is
# entirely GUI-driven). Mirrors fishing/questline/on_first_rod (first rod -> start),
# but the trigger is the first MEAL rather than first rod.
#
# DUP-GUARDED by the cook_dispatch gate (ec.cq_active matches 0) AND again here, so
# a re-entrant call past activation is a no-op. Gives the Cook's Codex (book/give is
# itself inventory-dup-guarded) then starts the line at quest 1.

# Defensive re-guard (cook_dispatch already gated on ec.cq_active matches 0).
execute if score @s ec.cq_active matches 1 run return 0

# Hand the player their Cook's Codex (book/give dup-guards on inventory contents).
function evercraft:cooking/questline/book/give

# Begin the line at quest 1 (start seeds the ec.cq_seen cursor + shows the intro).
function evercraft:cooking/questline/start
