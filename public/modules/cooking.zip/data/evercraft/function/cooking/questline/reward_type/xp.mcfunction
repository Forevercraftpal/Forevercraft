# CQ reward — xp (category-1 Artisan COOKING XP). @s = player.
# Amount in #cq_reward_amt ec.temp. Paid through the FROZEN add_xp contract: set
# #cf_xp_amount + #cf_xp_cat=1 on ec.cf_temp, run as @s, call add_xp. NOTHING here
# writes ec.cf_xp / ec.cf_axp_cook directly; Cooking XP NEVER routes through
# craft_affinity/internal_grant (that would re-arm the class faucet loop). This is
# the ONE add_xp call per reward — both ec.cf_xp and ec.cf_axp_cook rise inside it.
# (No macro args needed; invoked `with storage ... o` but only reads the temp.)
scoreboard players operation #cf_xp_amount ec.cf_temp = #cq_reward_amt ec.temp
scoreboard players set #cf_xp_cat ec.cf_temp 1
function evercraft:craftforever/artisan/add_xp
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"#FFB347"},{text:"Reward: ",color:"yellow"},{score:{name:"#cq_reward_amt",objective:"ec.temp"},color:"#FFB347"},{text:" Cooking XP",color:"#FFB347"},{text:" ✦",color:"#FFB347"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute at @s run function evercraft:fx/cook/quest_beat
