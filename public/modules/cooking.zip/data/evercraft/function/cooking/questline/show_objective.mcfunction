# ============================================================
# The Cook's Questline — Show current objective
# ============================================================
# Reads the current quest from cq_cur.quest (already loaded by get_quest) and
# prints its title + description as the active objective. Data-driven via macro
# (the quest text lives in the registry, not in per-quest files).
# Run as @s = the player.

# Surface the quest fields the macro needs at the top level of cq_cur.
data modify storage evercraft:cq_cur o set from storage evercraft:cq_cur quest
function evercraft:cooking/questline/show_objective_macro with storage evercraft:cq_cur o
