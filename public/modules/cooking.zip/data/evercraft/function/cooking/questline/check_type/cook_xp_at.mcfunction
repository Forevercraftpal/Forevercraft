# CQ check helper — cook_xp_at (lifetime Cooking artisan XP). Catch-up beat.
# @s = player. Reads ec.cf_axp_cook (the category-1 Cooking XP total) DIRECTLY, so
# a veteran whose Cooking XP already clears the count auto-satisfies on the next
# 20t check_progress tick at full reward (R1). Constant per-quest reward => can't
# be farmed; forward-only ec.cq_quest cursor blocks retro double-credit.
#
# READ-ONLY: reads ec.cf_axp_cook (craftforever-owned, written ONLY by the frozen
# add_xp contract). Writes NO cooking/ engine objective. NOTE: this line's OWN xp
# rewards (paid via add_xp) also raise ec.cf_axp_cook, so a cook_xp_at beat can be
# partly fed by the line's earlier rewards — intended (the line teaches by paying).
scoreboard players set #cq_satisfied ec.temp 0
execute if score @s ec.cf_axp_cook >= #cq_count ec.temp run scoreboard players set #cq_satisfied ec.temp 1
