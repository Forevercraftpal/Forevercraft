# ============================================================
# The Cook's Questline — Registry load (storage init + batch dispatch)
# ============================================================
# Initializes the quest registry storage to an empty list, then calls each
# load_batch_K to append its quests. The storage is volatile across /reload,
# so this MUST run every reload (called from cooking/questline/load).
#
# Registry shape (storage evercraft:cq_registry):
#   {quests:[ {id,title,desc,type,target,count,reward,reward_amt,chapter,
#              [lore],[beat],[skippable]}, ... ]}
#
# Each load_batch_K appends via:
#   data modify storage evercraft:cq_registry quests append value {...}
# Quests are appended in id order so the 0-based list index == (ec.cq_quest - 1).

# Reset to an empty quest list.
data modify storage evercraft:cq_registry quests set value []

# Append the quest batches, in id order (id 1 first => list index 0). Batch 0 is
# the full ~14-beat starter Cooking line: 3 chapters (hearth / discovery / mastery),
# 3:1 lore:objective cadence, with a spirit_fish/protein interlude bridging
# Cooking <-> Fishing. Later batches (load_batch_1+) extend the line; advance reads
# N (list length) dynamically, so appending a batch auto-extends with no engine edit.
function evercraft:cooking/questline/registry/load_batch_0
