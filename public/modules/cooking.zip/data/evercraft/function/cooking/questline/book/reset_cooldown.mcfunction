# The Cook's Codex — Reset cooldown (runs ~1s after a right-click use).
# Revokes the using_item advancement so the book can be used again. Clone of
# tome/reset_cooldown.
execute as @a[tag=ec.cookbook_cd] run advancement revoke @s only evercraft:cooking_book/on_use
tag @a[tag=ec.cookbook_cd] remove ec.cookbook_cd
