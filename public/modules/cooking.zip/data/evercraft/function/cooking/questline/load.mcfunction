# ============================================================
# The Cook's Questline — Load (objective declarations + registry + schedule)
# ============================================================
# A strictly-linear, data-driven quest line (q1..N in order, one active quest at
# a time), structural clone of build_quests/load. Called from init (the pack load
# host) on /reload — see init.mcfunction "COOK'S QUESTLINE" block.
#
# Declarations are guarded by #cq_loaded ec.var so subsequent /reloads skip the
# re-declaration spam, matching questline/load's P6 polish.
#
# After declaring objectives, this fn ALWAYS (re)loads the registry (the quest
# data storage is NOT persisted across /reload) and (re)kicks the 20t catch-up
# scheduler with `replace` (so /reload never stacks duplicate schedules).

# === ONE-TIME OBJECTIVE DECLARATIONS (skipped on subsequent /reloads) ===
execute unless score #cq_loaded ec.var matches 1 run function evercraft:cooking/questline/declare_objectives

# === REGISTRY (re)load — storage is volatile across /reload, must re-run ===
function evercraft:cooking/questline/registry/load

# === 20t CATCH-UP / INTERLUDE SCHEDULER (self-rescheduling, existence-gated) ===
# check_progress only does work for @a[scores={ec.cq_active=1}] — no per-tick @a
# scan when nobody is on the line. It re-schedules itself; kick once here.
schedule function evercraft:cooking/questline/check_progress 20t replace
