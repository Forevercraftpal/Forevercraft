# ============================================================
# The Cook's Questline — Load the current quest object into cq_cur
# ============================================================
# Reads the current quest (by linear pointer ec.cq_quest) out of the registry
# list and writes it to storage evercraft:cq_cur quest, so check/advance/reward
# can read quest.type/target/count/reward/reward_amt without per-quest files.
#
# The registry list is 0-indexed; ec.cq_quest is 1-based. This wrapper computes
# idx = ec.cq_quest - 1, stuffs it into storage, and calls the macro.
# Run as @s = the player.

# Compute 0-based list index from the 1-based linear pointer.
execute store result score #cq_idx ec.temp run scoreboard players get @s ec.cq_quest
scoreboard players remove #cq_idx ec.temp 1
execute store result storage evercraft:cq_cur idx int 1 run scoreboard players get #cq_idx ec.temp

# Macro-copy the quest object at that index into cq_cur.quest.
function evercraft:cooking/questline/get_quest_macro with storage evercraft:cq_cur
