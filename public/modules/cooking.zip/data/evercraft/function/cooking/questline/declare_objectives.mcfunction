# ============================================================
# The Cook's Questline — One-time scoreboard objective declarations.
# (Structural clone of build_quests/declare_objectives, Council #2 Wave C3 —
#  the FIRST content slice of the Chronicles layer, per Joseph "start with
#  cooking".) Split from cooking/questline/load so the per-/reload "Objective
#  already exists" warnings only fire once. Gated by `#cq_loaded ec.var matches 1`
#  — set at the bottom of this file.
# ============================================================
# A paced, always-skippable Cooking quest line: a sibling Fisher's clone that only
# READS public cooking state (ach.meals_cooked, recipe-discovery aggregate, the
# Cooking mastery counters, ec.cf_axp_cook). It WRITES none of cooking/'s engine
# objectives — the no-write proof. It is pacing-aware from the start (lore/beat/
# skippable) — see check.mcfunction (interlude guard), on_advance_notify + overview
# (render_lore), and the registry rows that carry `lore`.
#
# NOTE: ec.ck_* is OCCUPIED by the live Cooking engine (ec.ck_cat, ck.disc*, etc.).
# This line uses the council-locked ec.cq_* family ONLY.

# === CORE LINEAR-POINTER SCOREBOARDS (mirror ec.bq_*; one writer each) ===
# ec.cq_active — 0/1, has this player started the Cook's line?
#   WRITER: cooking/questline/start (sets 1).
scoreboard objectives add ec.cq_active dummy "Cook Questline Active"
# ec.cq_quest — current quest index, 1..N. The ONLY linear pointer.
#   WRITER: cooking/questline/start (sets 1) + cooking/questline/advance (+1, clamped at N).
scoreboard objectives add ec.cq_quest dummy "Cook Quest Index"
# ec.cq_prog — progress within the current quest, surfaced ONLY in the overview
#   progress bar. The Cooking check types are all READ-DERIVED (they compute their
#   satisfied condition from a public mirror + the ec.cq_seen cursor into ec.temp,
#   never persisting a per-cook tally), so the single persistent writer of cq_prog
#   is the reset path — keeping it strictly one-writer.
#   WRITER (reset to 0): cooking/questline/start + cooking/questline/advance.
#   WRITER (live mirror for the bar): cooking/questline/check_progress re-syncs it
#     to the present-beat delta (one writer, on the 20t loop).
scoreboard objectives add ec.cq_prog dummy "Cook Quest Progress"
# ec.cq_done — lifetime completed quest count (overview + the ec.gq_track value).
#   WRITER: cooking/questline/advance (+1) + cooking/questline/start (sets 0 on first start).
scoreboard objectives add ec.cq_done dummy "Cook Quests Done"
# (NO ec.cq_title — per the wave spec the Cooking line rewards only xp/coins/crate.
#  ALL cooking-prestige identity comes from elsewhere; no reward_type/title file
#  exists in this engine.)

# === COMPLETION SENTINEL ===
# ec.cq_complete — 0/1, set once when the player finishes the final quest so the
#   "line complete!" tellraw fires exactly once. WRITER: cooking/questline/advance
#   (via finish) + cooking/questline/start (sets 0 on first start).
scoreboard objectives add ec.cq_complete dummy "Cook Questline Complete"

# === LIFETIME-THRESHOLD CATCH-UP CURSOR (forward-only, no-penalty) ===
# ec.cq_seen — snapshot of ach.meals_cooked taken at start. The present-action
#   `cooked_meal` beat reads (ach.meals_cooked - this) as the count of meals cooked
#   SINCE the line began, so pre-activation meals never retro-credit the present
#   beat (forward cursor). The `cook_xp_at`/`mastery_reached`/`recipe_discovered`
#   catch-up TYPES read their lifetime mirror DIRECTLY, so a veteran auto-passes at
#   full reward. WRITER: cooking/questline/start (seeds it) +
#   cooking/questline/check_progress (re-syncs the live ec.cq_prog delta).
scoreboard objectives add ec.cq_seen dummy "CQ Meals-Cooked Cursor"

# Mark declarations done so re-/reload skips this file.
scoreboard players set #cq_loaded ec.var 1
