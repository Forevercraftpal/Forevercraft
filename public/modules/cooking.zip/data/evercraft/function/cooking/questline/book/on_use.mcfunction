# ============================================================
# The Cook's Questline — Cook's Codex right-click handler
# ============================================================
# Triggered by the using_item advancement (cooking_book/on_use.json) when the
# player right-clicks a minecraft:book carrying custom_data{cooking_book:true}.
# Clone of tome/on_use: the advancement stays granted briefly to prevent spam,
# then is revoked by a scheduled cooldown reset. Opens the Cooking overview page.
# Run as @s = the player.

# Only fire from the mainhand (a book sitting in a container shouldn't trigger).
execute unless items entity @s weapon.mainhand minecraft:book[custom_data~{cooking_book:true}] run return fail

# Cooldown guard: schedule advancement revoke after ~1s (always, regardless of
# outcome) so a single right-click opens the page exactly once.
tag @s add ec.cookbook_cd
schedule function evercraft:cooking/questline/book/reset_cooldown 20t append

# Open the Cook's Path questline panel (#3/D1 floating GUI; was the overview chat wall).
scoreboard players set @s ec.gq_qln_ln 2
function evercraft:codex/hub/grand_quests/qln/book_open
