# CQ reward — coins. @s = player. Amount in #cq_reward_amt ec.temp.
# Adds Forever Coins (ec.coins) and tells the player. (No macro args needed;
# invoked `with storage ... o` but only reads the temp.)
scoreboard players operation @s ec.coins += #cq_reward_amt ec.temp
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"Reward: ",color:"yellow"},{score:{name:"#cq_reward_amt",objective:"ec.temp"},color:"gold"},{text:" Forever Coins",color:"gold"},{text:" ✦",color:"gold"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute at @s run function evercraft:fx/cook/quest_beat
