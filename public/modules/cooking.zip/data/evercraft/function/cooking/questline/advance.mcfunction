# ============================================================
# The Cook's Questline — Advance (complete current quest -> next)
# ============================================================
# Run as @s = the player. Called by cooking/questline/check when the active quest
# is satisfied, OR by quest_pacing/do_skip (the [Skip ▸] button, full reward).
# WRITER of the linear pointer (ec.cq_quest), ec.cq_prog reset, ec.cq_done,
# ec.cq_complete.
#
# Order: show_completed -> reward -> bump pointer (clamped) -> reset prog ->
#        +1 done -> load next quest -> show_objective. Final quest -> a one-shot
#        "line complete!" tellraw, pointer clamped at N.

# --- Idempotency / out-of-range guards (mirror the Build/Fisher upper-bound guard) ---
execute unless score @s ec.cq_active matches 1 run return 0
execute if score @s ec.cq_complete matches 1 run return 0

# Registry length = N (the last valid quest index). Dynamic so the engine never
# hardcodes the quest count — it grows automatically as batches are added.
execute store result score #cq_n ec.temp run data get storage evercraft:cq_registry quests
# Defensive: if the registry failed to load (length 0), do nothing.
execute if score #cq_n ec.temp matches ..0 run return 0
# If the pointer is somehow already past N, clamp + finish (don't run past the end).
execute if score @s ec.cq_quest > #cq_n ec.temp run function evercraft:cooking/questline/finish
execute if score @s ec.cq_quest > #cq_n ec.temp run return 0

# === 1) SHOW WHAT WAS JUST COMPLETED (cq_cur still holds the old quest) ===
function evercraft:cooking/questline/show_completed

# === 2) PAY OUT THE REWARD for the completed quest ===
function evercraft:cooking/questline/reward

# === 2b) ADDITIVE: grant progress toward the CULINARY advantage tree (Joseph 2026-06-01) ===
# On TOP of the existing reward. Feeds the normal level-up grind gate (adv.stat_cook);
# does NOT raw-set adv.culinary. Read while ec.cq_quest still holds the just-completed
# index (the bump below happens after). See tree_credit for sizing rationale.
function evercraft:cooking/questline/tree_credit

# === 3) ADVANCE THE LINEAR POINTER + COUNTERS ===
scoreboard players add @s ec.cq_quest 1
scoreboard players set @s ec.cq_prog 0
scoreboard players add @s ec.cq_done 1

# === 4) FINAL-QUEST HANDLING ===
# If the new pointer exceeds N, the player just finished the LAST quest. Detect
# the overflow FIRST (into a flag), then clamp the pointer back to N (so a future
# check can't index out of range) and run the one-shot completion fanfare.
scoreboard players set #cq_overflow ec.temp 0
execute if score @s ec.cq_quest > #cq_n ec.temp run scoreboard players set #cq_overflow ec.temp 1
execute if score #cq_overflow ec.temp matches 1 run scoreboard players operation @s ec.cq_quest = #cq_n ec.temp
execute if score #cq_overflow ec.temp matches 1 run function evercraft:cooking/questline/finish

# Not finished: load the next quest into cq_cur and show its objective (paced).
execute if score #cq_overflow ec.temp matches 0 run function evercraft:cooking/questline/get_quest
execute if score #cq_overflow ec.temp matches 0 run function evercraft:cooking/questline/on_advance_notify
