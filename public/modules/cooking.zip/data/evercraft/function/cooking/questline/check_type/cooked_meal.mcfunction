# CQ check helper — cooked_meal (meals cooked SINCE the line began). @s = player.
# Present-action beat: reads the FORWARD-only delta (ach.meals_cooked - ec.cq_seen)
# so meals cooked before this beat was active never retro-credit it. Satisfied
# when the delta reaches quest.count (#cq_count ec.temp).
#
# READ-ONLY: reads ach.meals_cooked (achievements-owned) + ec.cq_seen (this line's
# OWN cursor, seeded at start). Writes NO cooking/ engine objective.
#
# Note: a true veteran is NOT auto-passed by cooked_meal (the forward cursor is
# intentional for present-action beats) — but the line never WALLS on it, because
# every cooked_meal beat is `skippable` (default), so a player who would rather not
# cook fresh meals can [Skip ▸] at full reward. The catch-up TYPES (recipe_discovered
# / mastery_reached / cook_xp_at) are the veteran auto-pass path.
scoreboard players set #cq_satisfied ec.temp 0
scoreboard players operation #cq_delta ec.temp = @s ach.meals_cooked
scoreboard players operation #cq_delta ec.temp -= @s ec.cq_seen
execute if score #cq_delta ec.temp >= #cq_count ec.temp run scoreboard players set #cq_satisfied ec.temp 1
