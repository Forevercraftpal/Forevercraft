# ============================================================
# The Cook's Questline — get_quest macro body
# ============================================================
# Called with storage evercraft:cq_cur containing {idx:<0-based index>}.
# Copies registry quest[idx] into evercraft:cq_cur quest.
$data modify storage evercraft:cq_cur quest set from storage evercraft:cq_registry quests[$(idx)]
