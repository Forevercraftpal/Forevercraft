# CQ check helper — mastery_reached (best single-cuisine mastery). Catch-up beat.
# @s = player. Computes the MAX over the 11 per-cuisine mastery counters (ck.m_*,
# written ONLY by cooking/recipes/cook_dispatch). "Within a single cuisine" => the
# beat is satisfied when ANY one cuisine's lifetime count reaches quest.count. A
# veteran who already mastered a cuisine auto-passes on the next 20t tick at full
# reward (R1). The 11 counters are READ-ONLY here — we copy the running max into a
# private temp register, never write any ck.m_* (the no-write proof).
#
# (Cheap: 11 conditional `> run =` ops only for an active player, behind the
#  existence-gated check chain. No per-tick @a scan.)
scoreboard players set #cq_satisfied ec.temp 0

# Start the running max at this cuisine list's first counter, then fold in the rest.
scoreboard players operation #cq_mast_max ec.temp = @s ck.m_combat
execute if score @s ck.m_mining > #cq_mast_max ec.temp run scoreboard players operation #cq_mast_max ec.temp = @s ck.m_mining
execute if score @s ck.m_fortune > #cq_mast_max ec.temp run scoreboard players operation #cq_mast_max ec.temp = @s ck.m_fortune
execute if score @s ck.m_wayfarer > #cq_mast_max ec.temp run scoreboard players operation #cq_mast_max ec.temp = @s ck.m_wayfarer
execute if score @s ck.m_delicacy > #cq_mast_max ec.temp run scoreboard players operation #cq_mast_max ec.temp = @s ck.m_delicacy
execute if score @s ck.m_seasonal > #cq_mast_max ec.temp run scoreboard players operation #cq_mast_max ec.temp = @s ck.m_seasonal
execute if score @s ck.m_treats > #cq_mast_max ec.temp run scoreboard players operation #cq_mast_max ec.temp = @s ck.m_treats
execute if score @s ck.m_ration > #cq_mast_max ec.temp run scoreboard players operation #cq_mast_max ec.temp = @s ck.m_ration
execute if score @s ck.m_feast > #cq_mast_max ec.temp run scoreboard players operation #cq_mast_max ec.temp = @s ck.m_feast
execute if score @s ck.m_preserve > #cq_mast_max ec.temp run scoreboard players operation #cq_mast_max ec.temp = @s ck.m_preserve
execute if score @s ck.m_spirit > #cq_mast_max ec.temp run scoreboard players operation #cq_mast_max ec.temp = @s ck.m_spirit

execute if score #cq_mast_max ec.temp >= #cq_count ec.temp run scoreboard players set #cq_satisfied ec.temp 1
