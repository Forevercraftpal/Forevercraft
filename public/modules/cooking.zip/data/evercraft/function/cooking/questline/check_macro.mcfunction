# ============================================================
# The Cook's Questline — Check (macro body, dispatch on quest.type)
# ============================================================
# Called `with storage evercraft:cq_cur o`, o = current quest
#   {id,title,desc,type,target,count,reward,reward_amt,chapter,...}.
# Sets #cq_satisfied ec.temp to 1 iff the active quest's completion condition is
# met. Run as @s = the player.
#
# A macro can't branch on an int comparison inline, so we expose the threshold to
# ec.temp and route the per-TYPE decision to a tiny helper file:
#   - #cq_count ec.temp     = quest.count
# The helper at check_type/$(type) reads its OWN public mirror (ach.meals_cooked
# minus the ec.cq_seen cursor / ec.recipes_learned_total / summed cooking-mastery /
# ec.cf_axp_cook) and sets #cq_satisfied ec.temp. All helpers are READ-ONLY: they
# never write a cooking/ engine objective (the no-write proof).

# Expose the threshold for the helpers to compare against.
$scoreboard players set #cq_count ec.temp $(count)

# Per-type decision (sets #cq_satisfied ec.temp). $(type) is one of:
#   cooked_meal | recipe_discovered | mastery_reached | cook_xp_at
$function evercraft:cooking/questline/check_type/$(type)
