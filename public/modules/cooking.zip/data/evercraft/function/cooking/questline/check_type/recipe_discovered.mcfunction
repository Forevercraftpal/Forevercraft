# CQ check helper — recipe_discovered (lifetime recipes learned). Catch-up beat.
# @s = player. Reads the LIFETIME cross-craft recipe aggregate directly, so a
# fresh op whose ec.recipes_learned_total already clears the count auto-satisfies
# on the next 20t check_progress tick and pays full reward (R1 veteran catch-up —
# no re-grinding). The reward is a constant per quest, so this can't be farmed; the
# forward-only ec.cq_quest cursor (one advance per satisfied beat) blocks retro
# double-credit.
#
# READ-ONLY: reads ec.recipes_learned_total (cooking-family writer is
# cooking/discovery/mark_slot — achievements-declared aggregate). Writes NO
# cooking/ engine objective.
scoreboard players set #cq_satisfied ec.temp 0
execute if score @s ec.recipes_learned_total >= #cq_count ec.temp run scoreboard players set #cq_satisfied ec.temp 1
