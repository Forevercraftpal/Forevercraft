# ============================================================
# The Cook's Questline — 20t catch-up / interlude scheduler
# ============================================================
# Self-rescheduling, EXISTENCE-GATED 20t loop (kicked from cooking/questline/load
# with `replace`). It does work ONLY for players on the line
# (@a[scores={ec.cq_active=1,ec.cq_complete=0}]), so with no Cooking players it
# iterates over NOTHING — no per-tick @a scan (the datapack's perf law).
#
# Two jobs per active player (both via the existing, idempotent check chain):
#   1. CATCH-UP (R1): a `recipe_discovered`/`mastery_reached`/`cook_xp_at` beat
#      whose lifetime threshold the player's mirror already clears auto-satisfies
#      on this tick and pays full reward — a veteran is never walled. Those helpers
#      read the lifetime mirror directly (no per-cook hook needed for catch-up).
#   2. INTERLUDE auto-pass (C0, SCHEMA_DELTA §3): a beat:"interlude"/count:0 beat is
#      instantly satisfied by check()'s interlude guard, so it advances here on the
#      next tick — delivering its lore once, paying its tiny reward once.
#
# The forward-only ec.cq_quest cursor (one advance per satisfied beat, inside
# advance) makes this no-double-credit and no-penalty.

# === RUN THE CHECK FOR EVERY ACTIVE, NON-COMPLETE PLAYER ===
# (check() is itself existence-gated + idempotent; the outer selector keeps the
#  per-tick cost zero when nobody is on the line.)
execute as @a[scores={ec.cq_active=1,ec.cq_complete=0}] run function evercraft:cooking/questline/check

# === RE-SYNC THE OVERVIEW PROGRESS BAR (cq_prog, one writer) ===
# Keep ec.cq_prog mirroring the present-beat meals-cooked delta for active players,
# so the overview's live progress bar reads true for `cooked_meal` beats. This is
# the ONLY persistent writer of cq_prog besides the reset path — strictly one-writer.
# Computed per active @s: cq_prog = ach.meals_cooked - ec.cq_seen (clamped at 0 via
# the seed, which is always <= ach.meals_cooked). Harmless for non-cooked_meal beats
# (the bar just shows the meals-since-start delta, a meaningful "you're cooking"
# indicator). No-op for non-active players via the selector.
execute as @a[scores={ec.cq_active=1,ec.cq_complete=0}] run scoreboard players operation @s ec.cq_prog = @s ach.meals_cooked
execute as @a[scores={ec.cq_active=1,ec.cq_complete=0}] run scoreboard players operation @s ec.cq_prog -= @s ec.cq_seen

# Re-schedule self.
schedule function evercraft:cooking/questline/check_progress 20t replace
