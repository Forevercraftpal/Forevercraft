# Run as operator (testing). Temp entry to hand yourself the Cook's Codex + start
# the Cook's Questline before C1's Crafter Tier-2 menu row is the canonical entry.
# Usage: /execute as <player> run function evercraft:cooking/questline/admin/give_book_temp
# (debug) — gives the book (dup-guarded) and starts the line if not already active.
function evercraft:cooking/questline/book/give
execute unless score @s ec.cq_active matches 1 run function evercraft:cooking/questline/start
