# ============================================================
# The Cook's Questline — Start (begin the line at quest 1)
# ============================================================
# Run as @s = the player who just cooked their first meal (via the first_meal
# advancement reward fn, which guards on ec.cq_active == 0) OR clicked the temp
# admin entry. Sets the linear pointer to quest 1, loads it, shows the intro +
# first objective. WRITER of the initial pointer state.

# === ACTIVATE + RESET LINEAR STATE ===
scoreboard players set @s ec.cq_active 1
# Auto-track this line for the [Skip ▸] button (Wiring #52): Cooking = slot 4 (do_skip
# value-map). Latest-activated line wins; finish clears it if still pointed here.
scoreboard players set @s ec.gq_track 4
scoreboard players set @s ec.cq_quest 1
scoreboard players set @s ec.cq_prog 0
scoreboard players set @s ec.cq_done 0
scoreboard players set @s ec.cq_complete 0
# Seed the meals-cooked cursor at the player's current lifetime meal count so
# meals cooked BEFORE the line began never retro-credit the present `cooked_meal`
# beat (forward-only). check_progress advances ec.cq_prog off this cursor; the
# `cook_xp_at`/`mastery_reached`/`recipe_discovered` catch-up TYPES read their
# lifetime mirror DIRECTLY (so a veteran still auto-passes at full reward).
scoreboard players operation @s ec.cq_seen = @s ach.meals_cooked

# Load quest 1 into cq_cur for the objective display.
function evercraft:cooking/questline/get_quest

# === INTRO (mirrors the Fisher's start tone) ===
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"The Cook's Questline",color:"gold",bold:true},{text:" ✦",color:"gold"}]
scoreboard players set #ndur ec.temp 50
function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Steam rises from your first pot. A long, warm road of hearths lies ahead, cook — follow it, and feed all of Forevercraft.",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit
# Questline FX — the shared light beat (gated; Wave-3 cooking-fx pass).
execute at @s run function evercraft:fx/cook/quest_beat

# Subtle title flash, then show the first objective.
title @s times 5 40 10
title @s subtitle {text:"Your first task awaits",color:"gray",italic:true}
function evercraft:cooking/questline/show_objective
# Pacing (q1-lore fill 2026-06-10, mirror build_quests/start): deliver quest 1's lore line
# (muted in Quick Mode) + [Skip ▸] button — advances get this via on_advance_notify; the start
# path was the one chat-silent entry.
data modify storage evercraft:qp_cur o set from storage evercraft:cq_cur quest
function evercraft:quest_pacing/render_lore
