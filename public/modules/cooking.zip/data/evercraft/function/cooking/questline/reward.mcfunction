# ============================================================
# The Cook's Questline — Reward (pay out the completed quest)
# ============================================================
# Run as @s = the player. Reads the just-completed quest's reward fields from
# cq_cur.quest and dispatches on reward type. cq_cur still holds the OLD (just-
# completed) quest at this point (reward runs BEFORE advance bumps the pointer).
#
# Reward fields: reward (xp|coins|crate), reward_amt (int), target (crate tier).
# NO `title` reward type exists in this engine (per the wave spec — Cooking pays
# only xp/coins/crate). xp pays category-1 Cooking XP via the FROZEN add_xp
# contract; `internal_grant` is NEVER used. Dispatch -> reward_type/<reward>.

# Flatten the quest fields for the reward macro.
data modify storage evercraft:cq_cur o set from storage evercraft:cq_cur quest
function evercraft:cooking/questline/reward_macro with storage evercraft:cq_cur o

# === ADDITIVE: D-Q10-REWARD artifact (Artifact-Fusion w1) ===
# On TOP of the q10 xp reward above. Fires only when the just-completed quest is
# #10 (ec.cq_quest still holds 10 here — advance bumps the pointer AFTER reward).
# Cooking q10 -> Hearthhand Cloth (C24, Family J culinary leaf). One-shot per the
# pointer-equals-10 gate. Inv-full aware via the shared helper.
execute if score @s ec.cq_quest matches 10 run data modify storage evercraft:q10r args set value {lt:"artifacts/common/hearthhand_cloth",name:"Hearthhand Cloth",color:"white"}
execute if score @s ec.cq_quest matches 10 run function evercraft:artifacts/give/q10_reward with storage evercraft:q10r args
