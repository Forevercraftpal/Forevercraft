# ============================================================
# The Cook's Questline — Advantage-Tree Credit (ADDITIVE layer, Joseph 2026-06-01)
# ============================================================
# Run as @s = the player, called from advance.mcfunction AFTER the existing
# `reward` call and BEFORE the pointer bump. Grants progress toward the CULINARY
# advantage tree (tree id 14, level `adv.culinary`) via the engine's NORMAL
# level-up gate — i.e. by feeding the grind scoreboard `adv.stat_cook` that the
# gate consumes (req_stat = (level+1)*50, difficulty-scaled). This is the spec's
# "award the XP/progress the tree consumes, NOT a raw `scoreboard set adv.culinary`"
# (XP-REWARD-ECONOMY.md "Per-quest contribution"). The player still spends their
# own vanilla XP via the Advantages GUI to realize each level — req_xp / prestige
# / do_prestige stay fully intact.
#
# ADDITIVE: this does NOT touch any existing per-quest reward (cat XP / coins /
# crate via reward_macro). It runs alongside them.
#
# `adv.stat_cook` is an established SHARED stat counter (12+ writers: cook_dispatch,
# protein/on_kill_*, grant_tree_credit, housing buffs, guild expedition, etc.) — NOT
# a one-writer-law objective. Adding the questline as one more writer is consistent
# with the existing pattern. No NEW scoreboard is introduced here.
#
# Sizing — PHASE-3 RE-TUNE (Joseph 2026-06-01, council A2/A3; replaces the
# original +300/+400 ramp that over-fed ~2x and saturated by ~quest 2):
#   The gate is a CUMULATIVE LIFETIME THRESHOLD — adv.stat_cook is a pure `+=`
#   accumulator and the level-up gate NEVER subtracts it. To reach level L total
#   the player needs lifetime stat >= cum(L) = mult * L*(L+1)/2 = 25*L*(L+1)
#   (mult=50). Because nothing is ever spent, every per-quest credit stacks on the
#   lifetime total, so a flat input keeps clearing a SHRINKING fraction of the
#   growing (L+1)*mult per-level wall — the engine produces the "gentle ramp"
#   OUTPUT automatically. No input tiering needed.
#   Authored flat credit = mult/2 = 25/quest, sized against the PIONEER baseline
#   (req_stat unscaled):
#     q12  -> 12*25 = 300 stat = cum(L3) (25*3*4=300) -> EXACTLY 3 levels by q12.
#     14q  -> 350 stat = ~L3.2 (full line ≈ half a prestige).
#     250q -> 6250 stat ≈ cum(L24.5) ≈ 0.96 prestige -> "~250 quests ≈ 1 prestige".
#   Newcomer (÷10) / Adventurer (÷5) divide req_stat, so the same 25/quest goes
#   10x / 5x further — those modes level the tree correspondingly faster, by design.
#   This UNIFIES cooking onto the single mult/2 curve shared with chemistry AND
#   forging (all mult 50 -> all 25/quest); resolves council A2 (over-feed) + A3.
#   adv.stat_cook is NOT in the 5s sync `=` clobber path (only adv.stat_fish is),
#   so the `+=` credit survives — cooking needs NO in-tick realize (unlike fishing).
#
# `ec.cq_quest` still holds the OLD (just-completed) quest index here (advance.mcfunction
# bumps it AFTER this runs) — retained for reference; the credit is now flat.

# Flat per-quest credit = mult/2 = 25 (single authored curve; no ramp tiering).
scoreboard players set #cq_tree_credit adv.temp 25

# Feed the culinary grind gate (shared multi-writer stat counter).
scoreboard players operation @s adv.stat_cook += #cq_tree_credit adv.temp
