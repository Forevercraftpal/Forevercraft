# ============================================================
# The Cook's Questline — Show completed quest (just-finished one)
# ============================================================
# Reads the just-completed quest from cq_cur.quest (still the OLD quest at this
# point in advance, before the pointer is bumped) and prints a green checkmark
# line. Mirrors the Build/Fisher show_completed tone.
# Run as @s = the player.

data modify storage evercraft:cq_cur o set from storage evercraft:cq_cur quest
function evercraft:cooking/questline/show_completed_macro with storage evercraft:cq_cur o
execute at @s run function evercraft:fx/cook/quest_beat
