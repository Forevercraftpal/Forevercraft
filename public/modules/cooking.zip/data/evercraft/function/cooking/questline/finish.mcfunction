# ============================================================
# The Cook's Questline — Finish (one-shot completion fanfare)
# ============================================================
# Run as @s = the player who just completed the final quest. Sets the
# ec.cq_complete sentinel so this fires exactly once, then prints the
# "line complete!" celebration. WRITER of ec.cq_complete (with advance).

# Guard: only ever fire once.
execute if score @s ec.cq_complete matches 1 run return 0
scoreboard players set @s ec.cq_complete 1

# Auto-track repoint (Wiring #52): clear the [Skip ▸] tracker if it was pointed at THIS
# line (Cooking = slot 4) — a completed line must never accept a skip.
execute if score @s ec.gq_track matches 4 run scoreboard players set @s ec.gq_track 0

data modify storage evercraft:notify stage.c set value [{text:"★ ",color:"gold"},{text:"The Cook's Questline — Complete!",color:"gold",bold:true},{text:" ★",color:"gold"}]
scoreboard players set #ndur ec.temp 50
function evercraft:util/notify/emit_keep
data modify storage evercraft:notify stage.c set value [{text:"Every hearth lit, every dish remembered. You are a Grand Cook of Forevercraft, and your table will never want for guests.",color:"yellow",italic:true}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit

title @s times 10 60 20
title @s title {text:"Grand Cook",color:"gold"}
title @s subtitle {text:"The Cook's Questline is complete",color:"yellow"}

# Grand Cook capstone cinematic — the crown moment (gated; Wave-3 cooking-fx pass).
execute at @s run function evercraft:fx/cook/quest_complete

# === ADDITIVE: difficulty-scaled CULINARY-tree prestige capstone (Joseph 2026-06-01) ===
# On TOP of the celebration above. Runs once (inside this ec.cq_complete one-shot guard).
# Drives prestige on adv.culinary via the existing advantage/prestige/do_prestige path:
# Newcomer = max (3) / Adventurer = 2 / Pioneer or unset = 1. See tree_capstone.
function evercraft:cooking/questline/tree_capstone

# === ADDITIVE: exit handoff (Questline Restructure W4, 2026-06-10) ===
# A finished Path never goes dark: name the repeatable continuation (Trade Trials),
# bridge with 1 Trial Pass, and nudge the Grand Chronicle if both branches qualify.
# Runs inside this finish's one-shot complete-sentinel guard.
function evercraft:grand_quests/exit_handoff_craft

# Clear a stale tracked-Path pin if THIS line was pinned (QR-P5, 2026-06-10).
function evercraft:grand_quests/untrack_on_finish {slot:4}
