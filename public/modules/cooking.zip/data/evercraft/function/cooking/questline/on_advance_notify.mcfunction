# ============================================================
# The Cook's Questline — New-objective notification (after advance)
# ============================================================
# Run as @s = the player. Called once from cooking/questline/advance after the
# pointer moves to a new (non-final) quest. cq_cur already holds the new quest.
#
# C0 PACING (this line is pacing-aware from the start): the advance nudge routes
# through TWO shared layers, exactly like the Build engine:
#   1. util/notify/dispatch (key "cq_adv") — the mutable-notification layer, so the
#      "New objective" chime/title respects the player's global ec.notify filter +
#      a per-key [Mute] after a threshold (no /trigger names surfaced; the [Mute]
#      button is the interaction-driven affordance pattern).
#   2. quest_pacing/render_lore — the C0 lore line (gray-italic Seven-voice, muted
#      by ec.qln_mute in Quick Mode) + the law-compliant [Skip ▸] chat button
#      (gated on the beat's `skippable` field). SCHEMA_DELTA §2.

# === 1) MUTABLE "new objective" NUDGE (chatter class) ===
function evercraft:util/notify/dispatch {key:"cq_adv",class:"chatter",mute_at:8}
# Only fire the flash/chime + objective when the dispatcher approved it.
execute if score #notif_show_cq_adv ec.temp matches 1 run title @s times 5 40 10
execute if score #notif_show_cq_adv ec.temp matches 1 run title @s subtitle {text:"New objective available",color:"gray",italic:true}
execute if score #notif_show_cq_adv ec.temp matches 1 at @s run function evercraft:fx/cook/quest_beat
execute if score #notif_show_cq_adv ec.temp matches 1 run function evercraft:cooking/questline/show_objective
# Offer the [Mute] button once the per-key threshold is reached (static trigger
# affordance — the same shape as the Build [Mute]).
execute if score #notif_show_mute_cq_adv ec.temp matches 1 run tellraw @s [{text:"  ",color:"dark_gray"},{text:"[Mute]",color:"dark_gray",hover_event:{action:"show_text",value:{text:"Stop showing new-objective nudges for the Cooking line.",color:"gray"}},click_event:{action:"run_command",command:"/trigger ec.nm_cq_adv set 1"}}]

# === 2) C0 LORE LINE + [Skip ▸] BUTTON (always — independent of the chatter mute) ===
# The lore/skip layer has its OWN mute (ec.qln_mute, Quick Mode) handled inside
# render_lore; it is NOT gated by the chatter dispatch above, so a player who muted
# new-objective chimes still sees the story beat + can still skip.
data modify storage evercraft:qp_cur o set from storage evercraft:cq_cur quest
function evercraft:quest_pacing/render_lore
