# ============================================================
# The Cook's Questline — Registry batch 0 (the starter line, q1..q14)
# ============================================================
# Appends the first 14 quests onto storage evercraft:cq_registry quests.
# Called by registry/load AFTER it sets quests=[]. MUST append in id order
# (id=1 first => list index 0), contiguous, so list-position == ec.cq_quest-1.
# (Structural clone of build_quests/registry/load_batch_0, paced via C0.)
#
# Quest object schema (the engine reads these exact fields):
#   {id:int, title:string, desc:string, type:string, target:string,
#    count:int, reward:string, reward_amt:int, chapter:int,
#    [lore:string], [beat:string], [skippable:int]}      <- C0 fields OPTIONAL
#
# type    -> dispatched by check_type/$(type):
#            cooked_meal | recipe_discovered | mastery_reached | cook_xp_at
#            (beat:"interlude"/count:0 auto-passes BEFORE dispatch — SCHEMA_DELTA §3)
# target  -> the check helpers IGNORE it (each reads a fixed public mirror), so it
#             is "" on most beats. On a `reward:"crate"` beat it names the crate
#             TIER consumed by reward_type/crate (common|uncommon|rare|ornate|
#             exquisite|mythical) — the only consumer of target in this batch.
# count   -> cooked_meal: meals-since-start threshold (delta off ec.cq_seen);
#            recipe_discovered: lifetime ec.recipes_learned_total threshold;
#            mastery_reached: lifetime SUMMED cooking-mastery threshold;
#            cook_xp_at: lifetime ec.cf_axp_cook threshold;
#            interlude: 0 (auto-pass).
# reward  -> xp | coins | crate   (NO title). reward_amt = amount.
#            xp pays category-1 Cooking XP via the FROZEN add_xp contract.
# chapter -> display grouping: 1=hearth, 2=discovery, 3=mastery.
#
# XP TIER TABLE (artisan-locked flat curve, mirrors the Build line so a Cooking
# quest is never a fatter XP source than a meal-of-equal-tier loop):
#   40 / 90 / 180 / 320 / 480 / 700 / 950
#
# C0 CADENCE (SCHEMA_DELTA §1): every objective beat carries `lore`; interludes
# (q4 spirit/protein bridge to Fishing, q9, q13) sit ~3:1 against objective beats;
# the headline teach beats q2 (recipe_discovered) + q6 (mastery_reached) are
# `skippable:0` "see-it-once" — both still auto-pass a veteran via the lifetime
# read in their check helper (Decision #5).
# ------------------------------------------------------------

# --- Chapter 1: The Hearth -------------------------------------------------

# q1 — gentle intro: cook 3 meals. Pure on-ramp. lore + default [Skip ▸].
data modify storage evercraft:cq_registry quests append value {id:1,title:"The First Hearth",desc:"Cook 3 meals at a cooking station.",type:"cooked_meal",target:"",count:3,reward:"xp",reward_amt:40,chapter:1,lore:"Any campfire, smoker or stove answers to a cook's hands. The Pantry keeps your ingredients sorted, the hearth turns them into meals — and every NEW dish you cook writes itself into your recipe book forever."}

# q2 — *** SEE-IT-ONCE teach beat (skippable:0) ***: the headline discovery
#   mechanic. NO [Skip ▸] for a newcomer, but a VETERAN auto-passes via the
#   lifetime ec.recipes_learned_total read in check_type/recipe_discovered.
data modify storage evercraft:cq_registry quests append value {id:2,title:"A Recipe Remembered",desc:"Discover your first new recipe by cooking it.",type:"recipe_discovered",target:"common",count:1,reward:"crate",reward_amt:1,chapter:1,lore:"Discovery is the cook's true wage: each first-time dish pays Cooking XP, and discovered meals begin surfacing in reward crates across the whole world. Chase the dishes you have never made.",skippable:0}

# q3 — cook a few more meals to settle into the rhythm. lore + default [Skip ▸].
data modify storage evercraft:cq_registry quests append value {id:3,title:"Hands That Know the Heat",desc:"Cook 8 meals in all.",type:"cooked_meal",target:"",count:8,reward:"xp",reward_amt:90,chapter:1,lore:"Every meal feeds your Artisan rank as surely as it feeds you — Cooking XP climbs the same ladder the Smith and the Chemist climb, and rank opens trials, tools and trade."}

# q4 — *** INTERLUDE (count:0, beat:interlude) — the Cooking<->Fishing BRIDGE ***:
#   a pure-lore breather that auto-passes on the next 20t check, delivers its lore
#   once, pays coins:1 once. Nods to the spirit_fish / protein crossover (the meal
#   that coincides with the fishing book). Proves the C0 interlude path end-to-end.
data modify storage evercraft:cq_registry quests append value {id:4,title:"What the Net Brings",desc:"",type:"interlude",target:"",count:0,reward:"coins",reward_amt:1,chapter:1,beat:"interlude",lore:"Carry your cooking with you. The right meal outlasts a stack of bread on a long road — adventurers buy from cooks for a reason."}

# --- Chapter 2: Discovery --------------------------------------------------

# q5 — discover more recipes. lore + default [Skip ▸]. Reward Cooking XP (tier 3).
data modify storage evercraft:cq_registry quests append value {id:5,title:"A Wider Pantry",desc:"Discover 5 recipes in all.",type:"recipe_discovered",target:"",count:5,reward:"xp",reward_amt:180,chapter:2,lore:"A pantry is a library, and every recipe a page. The more pages you keep, the longer your table can speak."}

# q6 — *** SEE-IT-ONCE teach beat (skippable:0) ***: the mastery mechanic. NO
#   [Skip ▸] for a newcomer; a VETERAN auto-passes via the summed lifetime mastery
#   read in check_type/mastery_reached. Reward a crate.
data modify storage evercraft:cq_registry quests append value {id:6,title:"The Shape of Mastery",desc:"Cook 10 meals within a single cuisine to taste mastery.",type:"mastery_reached",target:"uncommon",count:10,reward:"crate",reward_amt:1,chapter:2,lore:"Master one cuisine before you chase ten. Depth feeds a village; breadth only feeds a menu.",skippable:0}

# q7 — keep discovering. lore + default [Skip ▸]. Reward Cooking XP (tier 4).
data modify storage evercraft:cq_registry quests append value {id:7,title:"The Curious Cook",desc:"Discover 12 recipes in all.",type:"recipe_discovered",target:"",count:12,reward:"xp",reward_amt:320,chapter:2,lore:"Curiosity is the cook's finest spice. Reach for the dish you have never made — that is where the craft lives."}

# q8 — a meal-count milestone to mark the chapter. lore + default [Skip ▸].
data modify storage evercraft:cq_registry quests append value {id:8,title:"A Table Well Set",desc:"Cook 25 meals in all.",type:"cooked_meal",target:"",count:25,reward:"xp",reward_amt:480,chapter:2,lore:"Count not the meals but the company they kept. A table well set is the quietest kind of wealth."}

# q9 — *** INTERLUDE (count:0) ***: a breather on the meaning of feeding others.
data modify storage evercraft:cq_registry quests append value {id:9,title:"On Feeding Others",desc:"",type:"interlude",target:"",count:0,reward:"coins",reward_amt:1,chapter:2,beat:"interlude",lore:"The oldest power a cook holds is the smallest: to set a warm plate before a tired friend. Forget the artifacts a while — that is the whole of it."}

# --- Chapter 3: Mastery ----------------------------------------------------

# q10 — climb the Cooking artisan XP. lore + default [Skip ▸]. cook_xp_at reads
#   ec.cf_axp_cook directly (lifetime catch-up — a veteran auto-passes at full XP).
data modify storage evercraft:cq_registry quests append value {id:10,title:"The Artisan's Rise",desc:"Earn 400 lifetime Cooking XP.",type:"cook_xp_at",target:"",count:400,reward:"xp",reward_amt:480,chapter:3,lore:"Skill is the slow gift the fire gives back. You have fed it your hours; now it sharpens your hand in return."}

# q11 — deeper mastery in a cuisine. lore + default [Skip ▸]. Reward XP (tier 6).
data modify storage evercraft:cq_registry quests append value {id:11,title:"Deep in the Craft",desc:"Cook 30 meals within a single cuisine.",type:"mastery_reached",target:"",count:30,reward:"xp",reward_amt:700,chapter:3,lore:"To go deep is to disappear into the work — to stop counting, and simply cook. The cuisine becomes a language you no longer translate."}

# q12 — a large lifetime XP capstone-runner. lore + default [Skip ▸].
data modify storage evercraft:cq_registry quests append value {id:12,title:"Name Among Cooks",desc:"Earn 1200 lifetime Cooking XP.",type:"cook_xp_at",target:"",count:1200,reward:"xp",reward_amt:700,chapter:3,lore:"There comes a day the village speaks your name when the smoke rises. You did not seek it. It found you at the hearth, where it always does."}

# q13 — *** INTERLUDE (count:0) ***: a quiet breather before the finale.
data modify storage evercraft:cq_registry quests append value {id:13,title:"The Last Quiet Before the Feast",desc:"",type:"interlude",target:"",count:0,reward:"coins",reward_amt:1,chapter:3,beat:"interlude",lore:"Before the great feast there is always a still hour — the pots scrubbed, the fire banked, the cook alone with what they have become. Sit in it a moment. You have earned the quiet."}

# q14 — FINALE: a wide meal milestone. lore + default [Skip ▸]. Reward XP (tier 7).
#   q14 is a soft finale, not a hard cap: advance reads N (list length) dynamically,
#   so appending load_batch_1 later auto-extends the line — q14's finish() only
#   fires while N == 14. Once a later batch is wired, q14 advances into q15.
data modify storage evercraft:cq_registry quests append value {id:14,title:"The Grand Hearth",desc:"Cook 60 meals in all. Let the great hearth never go cold.",type:"cooked_meal",target:"",count:60,reward:"xp",reward_amt:950,chapter:3,lore:"The grand hearth is not a bigger fire — it is a fire that has never been allowed to die. You are its keeper now, and Forevercraft eats well because of you."}

# ------------------------------------------------------------
# HAND-OFF TO load_batch_1 (future Cooking chapters):
#   - This batch ends at id=14. The next batch's FIRST quest MUST be id=15 (list
#     index 14), appended immediately after q14, contiguously.
#   - registry/load calls load_batch_0; add the load_batch_1 call there when it
#     lands. Do NOT renumber this batch.
# ------------------------------------------------------------
