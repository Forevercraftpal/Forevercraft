# ============================================================
# The Cook's Questline — first_meal advancement reward (self-arming safety net)
# ============================================================
# Fired when a player has the Cook's Codex book in inventory (advancement
# evercraft:cooking_book/first_meal). @s = that player. Mirrors
# fishing/questline/on_first_rod: a self-arming, dup-guarded START net.
#
# In the normal flow the line is ALREADY active by the time this fires (the
# cook_dispatch gate-first line ran on_first_meal -> book/give -> start BEFORE the
# inventory_changed advancement evaluates). So this is almost always a no-op past
# activation — it exists as the resilience net for the edge case where the book
# exists but the line never started (e.g. the book was admin-given, or pre-existed
# this engine). NEVER gives a second book here (only the cook_dispatch path gives).

# Revoke so the criterion re-arms (cheap; mirrors on_first_rod + quests/explore/on_*).
advancement revoke @s only evercraft:cooking_book/first_meal

# Start the line only if it isn't already active (ec.cq_active still 0).
execute unless score @s ec.cq_active matches 1 run function evercraft:cooking/questline/start
