# Mount Training System — Load
# Bond progression for player's primary horse mount
# Bond tiers: 0=Unfamiliar, 1=Trusted, 2=Bonded, 3=Soulbound, 4=Eternal

# === SCOREBOARDS ===
# Bond tracking
scoreboard objectives add ec.mt_bond dummy "Mount Bond XP"
scoreboard objectives add ec.mt_tier dummy "Mount Bond Tier"

# Primary mount UUID storage (2 ints for targeting)
scoreboard objectives add ec.mt_uuid0 dummy "Mount UUID 0"
scoreboard objectives add ec.mt_uuid1 dummy "Mount UUID 1"

# Riding tracking
scoreboard objectives add ec.mt_ride_time dummy "Consecutive Ride Ticks"
scoreboard objectives add ec.mt_biomes dummy "Mount Biomes Visited"

# Skyrift Derby racing
scoreboard objectives add ec.mt_racing dummy "Mount Racing Active"
scoreboard objectives add ec.mt_race_time dummy "Race Timer"
scoreboard objectives add ec.mt_checkpoints dummy "Checkpoints Hit"
scoreboard objectives add ec.mt_laps dummy "Laps Completed"
scoreboard objectives add ec.mt_best_time dummy "Personal Best Race Time"

# Whistle cooldown (seconds)
scoreboard objectives add ec.mt_whistle_cd dummy "Whistle Cooldown"

# Mount assignment tracking (minutes riding current horse)
scoreboard objectives add ec.mt_assign_time dummy "Mount Assignment Timer"

# Mounted challenges (one-time completion flags: 0=not done, 2=done)
scoreboard objectives add ec.mt_ch_speed dummy "Challenge: Speed Run"
scoreboard objectives add ec.mt_ch_night dummy "Challenge: Night Ride"

# === CONSTANTS ===
scoreboard players set #20 ec.const 20
scoreboard players set #60 ec.const 60

# === STATE VARIABLES (fake players on ec.var) ===
# #cal_skyrift_record: World record race time (ticks)
execute unless score #cal_skyrift_record ec.var matches 0.. run scoreboard players set #cal_skyrift_record ec.var 0

# === BOOTSTRAP ===
schedule function evercraft:mount_training/tick 1s replace
