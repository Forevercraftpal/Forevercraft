# Mount Training — Check Tier
# Compares bond XP to tier thresholds, triggers bond_up if tier changed
# Runs as the player

# Calculate new tier from bond XP
scoreboard players set #mt_new_tier ec.temp 0
execute if score @s ec.mt_bond matches 500.. run scoreboard players set #mt_new_tier ec.temp 1
execute if score @s ec.mt_bond matches 1500.. run scoreboard players set #mt_new_tier ec.temp 2
execute if score @s ec.mt_bond matches 3000.. run scoreboard players set #mt_new_tier ec.temp 3
execute if score @s ec.mt_bond matches 5000.. run scoreboard players set #mt_new_tier ec.temp 4

# If tier changed upward, trigger bond_up
execute unless score #mt_new_tier ec.temp = @s ec.mt_tier run function evercraft:mount_training/bond_up

# Always update tier
scoreboard players operation @s ec.mt_tier = #mt_new_tier ec.temp
