# Mount Training — Main Tick (1s schedule)
# Bond accumulation from riding, tier checks

# Early exit if no players
execute unless entity @a run return run schedule function evercraft:mount_training/tick 1s

# === WHISTLE COOLDOWN (DEPRECATED — whistle removed, kept for legacy cleanup) ===
# scoreboard players remove @a[scores={ec.mt_whistle_cd=1..}] ec.mt_whistle_cd 1

# === RIDING DETECTION ===
# Check each player: if riding a horse, increment ride time
# riding = entity has a vehicle that is a horse
# Perf retrofit M3 (2026-06-14): only dispatch check_riding for players actually in a vehicle —
# players on foot used to run it just to early-return. The ride-time reset check_riding did for
# non-riders is preserved below, targeted to only players still holding a stale ride-time.
execute as @a[nbt={RootVehicle:{}}] at @s run function evercraft:mount_training/check_riding
execute as @a[scores={ec.mt_ride_time=1..}] unless entity @s[nbt={RootVehicle:{}}] run scoreboard players set @s ec.mt_ride_time 0

# Reschedule
schedule function evercraft:mount_training/tick 1s
