# Mount Training — Bond Tier Up
# Called when player's bond tier increases
# #mt_new_tier in ec.temp has the new tier value
# Runs as the player

# === TIER ANNOUNCEMENTS ===
execute if score #mt_new_tier ec.temp matches 1 run data modify storage evercraft:notify stage.c set value [{text:"TRUSTED BOND",color:"green",bold:true},{text:" — Your mount trusts you! +10% speed",color:"white"}]
execute if score #mt_new_tier ec.temp matches 2 run data modify storage evercraft:notify stage.c set value [{text:"BONDED",color:"aqua",bold:true},{text:" — A deep bond forms! +20% speed",color:"white"}]
execute if score #mt_new_tier ec.temp matches 3 run data modify storage evercraft:notify stage.c set value [{text:"SOULBOUND",color:"light_purple",bold:true},{text:" — Your souls are linked! +30% speed, Mount Recall unlocked!",color:"white"}]
execute if score #mt_new_tier ec.temp matches 4 run data modify storage evercraft:notify stage.c set value [{text:"ETERNAL BOND",color:"gold",bold:true},{text:" — An unbreakable bond! +40% speed, Derby eligible!",color:"white"}]
scoreboard players set #ndur ec.temp 50
execute if score #mt_new_tier ec.temp matches 1..4 run function evercraft:util/notify/emit

# === APPLY SPEED MODIFIER TO MOUNT ===
# Remove old modifier, apply new one based on tier
# Uses 'on vehicle' relation to target the horse the player is riding
execute on vehicle run attribute @s movement_speed modifier remove evercraft:mount_bond_speed

# Tier 1: +10% speed (0.1 multiplied base)
execute if score #mt_new_tier ec.temp matches 1 on vehicle run attribute @s movement_speed modifier add evercraft:mount_bond_speed 0.1 add_multiplied_base
# Tier 2: +20% speed
execute if score #mt_new_tier ec.temp matches 2 on vehicle run attribute @s movement_speed modifier add evercraft:mount_bond_speed 0.2 add_multiplied_base
# Tier 3: +30% speed
execute if score #mt_new_tier ec.temp matches 3 on vehicle run attribute @s movement_speed modifier add evercraft:mount_bond_speed 0.3 add_multiplied_base
# Tier 4: +40% speed
execute if score #mt_new_tier ec.temp matches 4 on vehicle run attribute @s movement_speed modifier add evercraft:mount_bond_speed 0.4 add_multiplied_base

# === MOUNT RECALL UNLOCKED AT SOULBOUND (TIER 3) ===
# Whistle removed — recall now available via Companion Catalogue → Training tab
data modify storage evercraft:notify stage.c set value [{text:"Mount Recall unlocked! ",color:"green",bold:true},{text:"Use the Companion Catalogue → Training tab.",color:"yellow"}]
scoreboard players set #ndur ec.temp 45
execute if score #mt_new_tier ec.temp matches 3 run function evercraft:util/notify/emit

# === EFFECTS ===
execute at @s if score @s ec.fx_snd matches 1.. run playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 0.8 1.0
execute at @s run particle minecraft:totem_of_undying ~ ~1 ~ 0.5 1 0.5 0.1 30 force
execute on vehicle at @s run particle minecraft:happy_villager ~ ~1 ~ 0.5 0.5 0.5 0.1 20 force

# Title
title @s times 10 60 20
title @s title {text:" "}
execute if score #mt_new_tier ec.temp matches 1 run title @s subtitle [{text:"Mount Bond: ",color:"gray"},{text:"Trusted",color:"green",bold:true}]
execute if score #mt_new_tier ec.temp matches 2 run title @s subtitle [{text:"Mount Bond: ",color:"gray"},{text:"Bonded",color:"aqua",bold:true}]
execute if score #mt_new_tier ec.temp matches 3 run title @s subtitle [{text:"Mount Bond: ",color:"gray"},{text:"Soulbound",color:"light_purple",bold:true}]
execute if score #mt_new_tier ec.temp matches 4 run title @s subtitle [{text:"Mount Bond: ",color:"gray"},{text:"Eternal",color:"gold",bold:true}]
