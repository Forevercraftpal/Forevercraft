# Mount Training — Check Mounted Challenges
# One-time completions for bond XP
# Runs as each player who is riding (called from check_riding every 60s)

# === CHALLENGE 1: Speed Run — Sprint for 60 seconds ===
# ec.mt_ride_time >= 60 means 60+ consecutive seconds riding
execute if score @s ec.mt_ride_time matches 60.. if score @s ec.mt_ch_speed matches 0 run scoreboard players set @s ec.mt_ch_speed 1
execute if score @s ec.mt_ch_speed matches 1 run scoreboard players add @s ec.mt_bond 50
data modify storage evercraft:notify stage.c set value [{text:"CHALLENGE: Speed Run!",color:"gold",bold:true},{text:" +50 Bond XP",color:"green"}]
scoreboard players set #ndur ec.temp 45
execute if score @s ec.mt_ch_speed matches 1 run function evercraft:util/notify/emit
execute if score @s ec.mt_ch_speed matches 1 run scoreboard players set @s ec.mt_ch_speed 2

# === CHALLENGE 2: Night Ride — Ride for 5 minutes at night ===
# Check if night (visual_time 13000-23000) and ride_time >= 300
execute if score #visual_time ec.var matches 13000..23000 if score @s ec.mt_ride_time matches 300.. if score @s ec.mt_ch_night matches 0 run scoreboard players set @s ec.mt_ch_night 1
execute if score @s ec.mt_ch_night matches 1 run scoreboard players add @s ec.mt_bond 50
data modify storage evercraft:notify stage.c set value [{text:"CHALLENGE: Night Ride!",color:"gold",bold:true},{text:" +50 Bond XP",color:"green"}]
scoreboard players set #ndur ec.temp 45
execute if score @s ec.mt_ch_night matches 1 run function evercraft:util/notify/emit
execute if score @s ec.mt_ch_night matches 1 run scoreboard players set @s ec.mt_ch_night 2
