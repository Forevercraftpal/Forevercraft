# Mount Training — Check Riding (runs as each player at their position)
# Detects if player is riding a tamed horse and accumulates bond

# Check if player is riding a horse (RootVehicle exists and is a horse)
execute unless entity @s[nbt={RootVehicle:{}}] run return run scoreboard players set @s ec.mt_ride_time 0
execute unless predicate evercraft:mount_training/riding_horse run return run scoreboard players set @s ec.mt_ride_time 0

# Player IS riding a tamed horse — increment ride time (seconds)
scoreboard players add @s ec.mt_ride_time 1

# Sync speed modifier on first second of riding (applies tier bonus to horse)
execute if score @s ec.mt_ride_time matches 1 if score @s ec.mt_tier matches 1.. run function evercraft:mount_training/sync_speed

# === PRIMARY MOUNT ASSIGNMENT / REBOND ===
# First bond: bond=0, uuid0=0 → assign after 5 min (300s)
# Rebond after death: bond>0, uuid0=0 → assign after 5 min on new horse
execute if score @s ec.mt_uuid0 matches 0 if score @s ec.mt_ride_time matches 300 run function evercraft:mount_training/assign_mount

# === VERIFY BONDED HORSE (skip XP if riding a different horse) ===
# If player has a bond AND a uuid, check the vehicle UUID matches their bonded mount
execute if score @s ec.mt_bond matches 1.. if score @s ec.mt_uuid0 matches ..0 run return 0
execute if score @s ec.mt_bond matches 1.. store result score #mt_veh_uuid0 ec.temp on vehicle run data get entity @s UUID[0]
execute if score @s ec.mt_bond matches 1.. unless score #mt_veh_uuid0 ec.temp = @s ec.mt_uuid0 run return 0

# === BOND XP: +1 per 60 seconds of riding (bonded horse only) ===
scoreboard players add @s ec.mt_assign_time 1
execute if score @s ec.mt_assign_time matches 60.. run scoreboard players add @s ec.mt_bond 1
execute if score @s ec.mt_assign_time matches 60.. run scoreboard players set @s ec.mt_assign_time 0

# === SPRINT BONUS: +5 after 30s consecutive riding ===
# Award once at exactly 30 seconds, then every 60s after
execute if score @s ec.mt_ride_time matches 30 run scoreboard players add @s ec.mt_bond 5
execute if score @s ec.mt_ride_time matches 30 run data modify storage evercraft:notify stage.c set value [{text:"Sprint bonus! +5 Bond XP",color:"green"}]
execute if score @s ec.mt_ride_time matches 30 run scoreboard players set #ndur ec.temp 45
execute if score @s ec.mt_ride_time matches 30 run function evercraft:util/notify/emit

# === TIER CHECK (every 60 seconds to avoid spam) ===
execute if score @s ec.mt_assign_time matches 0 run function evercraft:mount_training/check_tier

# === MOUNTED CHALLENGES (one-time, checked periodically) ===
execute if score @s ec.mt_bond matches 1.. run function evercraft:mount_training/check_challenges

# === BUDDY MOUNT SYSTEM: Charge attack + breath mechanic ===
function evercraft:buddy/mount/tick_rider
