# Mount Recall — DEPRECATED (whistle removed, use Companion Catalogue → Training tab)
# Kept for backwards compatibility — redirects to tellraw instruction

# Revoke advancement
advancement revoke @s only evercraft:mount_training/whistle_used

# Inform player to use the new system
data modify storage evercraft:notify stage.c set value [{text:"The mount whistle has been replaced! ",color:"yellow"},{text:"Use the ",color:"gray"},{text:"Companion Catalogue",color:"gold",bold:true},{text:" → ",color:"gray"},{text:"Training",color:"green"},{text:" tab to recall your mount.",color:"gray"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit

# Remove the whistle item from player
clear @s minecraft:goat_horn[custom_data~{mount_whistle:1b}] 1
