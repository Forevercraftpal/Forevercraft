# Skyrift Derby — Check Checkpoint
# Runs as each racing player at their position
# Checks if player is within 8 blocks of their next checkpoint

# Determine which checkpoint to check based on ec.mt_checkpoints (1-4)
# Checkpoint 1 already hit on join — next is 2
execute if score @s ec.mt_checkpoints matches 1 if entity @e[tag=ec.mt_cp_hit2,distance=..8] run function evercraft:mount_training/skyrift/hit_checkpoint
execute if score @s ec.mt_checkpoints matches 2 if entity @e[tag=ec.mt_cp_hit3,distance=..8] run function evercraft:mount_training/skyrift/hit_checkpoint
execute if score @s ec.mt_checkpoints matches 3 if entity @e[tag=ec.mt_cp_hit4,distance=..8] run function evercraft:mount_training/skyrift/hit_checkpoint
execute if score @s ec.mt_checkpoints matches 4 if entity @e[tag=ec.mt_cp_hit1,distance=..8] run function evercraft:mount_training/skyrift/hit_checkpoint
