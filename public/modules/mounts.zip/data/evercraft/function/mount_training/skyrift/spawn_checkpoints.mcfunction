# Skyrift Derby — Spawn Checkpoint Markers
# Runs as/at the first player (course center)
# 4 checkpoints in a circuit at varying heights and distances

# Store base position for reference
data modify storage evercraft:skyrift base_pos set from entity @s Pos

# === CHECKPOINT 1: Start/Finish (at player position, ground level) ===
summon marker ~ ~ ~ {Tags:["ec.mt_cp","ec.mt_cp1","ec.mt_cp_active"],Glowing:1b}
summon interaction ~ ~ ~ {Tags:["ec.mt_cp_hit","ec.mt_cp_hit1"],width:8.0f,height:8.0f,response:1b,Glowing:1b}

# Ensure CP1 is at Y>=80
execute store result score #cp_y ec.temp run data get entity @e[tag=ec.mt_cp1,limit=1] Pos[1]
execute if score #cp_y ec.temp matches ..79 run tp @e[tag=ec.mt_cp1] ~ 80 ~
execute if score #cp_y ec.temp matches ..79 run tp @e[tag=ec.mt_cp_hit1] ~ 80 ~

# === CHECKPOINT 2: North, 200 blocks, Y+30 ===
summon marker ~ ~30 ~-200 {Tags:["ec.mt_cp","ec.mt_cp2"],Glowing:1b}
summon interaction ~ ~30 ~-200 {Tags:["ec.mt_cp_hit","ec.mt_cp_hit2"],width:8.0f,height:8.0f,response:1b,Glowing:1b}

# === CHECKPOINT 3: East, 200 blocks, Y+60 ===
summon marker ~200 ~60 ~ {Tags:["ec.mt_cp","ec.mt_cp3"],Glowing:1b}
summon interaction ~200 ~60 ~ {Tags:["ec.mt_cp_hit","ec.mt_cp_hit3"],width:8.0f,height:8.0f,response:1b,Glowing:1b}

# === CHECKPOINT 4: South, 200 blocks, Y+15 ===
summon marker ~ ~15 ~200 {Tags:["ec.mt_cp","ec.mt_cp4"],Glowing:1b}
summon interaction ~ ~15 ~200 {Tags:["ec.mt_cp_hit","ec.mt_cp_hit4"],width:8.0f,height:8.0f,response:1b,Glowing:1b}

# Apply glowing effect to interaction hitboxes (markers are invisible so Glowing alone won't render)
effect give @e[tag=ec.mt_cp_hit1] glowing infinite 0 true
effect give @e[tag=ec.mt_cp_hit2] glowing infinite 0 true
effect give @e[tag=ec.mt_cp_hit3] glowing infinite 0 true
effect give @e[tag=ec.mt_cp_hit4] glowing infinite 0 true

# Announce checkpoint locations
# (Wave 2, 2026-06-10: rides the queue — coords baked via stage_text so they never re-resolve per viewer.)
data modify storage evercraft:notify stage.c set value [{text:"Course set near ",color:"gray"},{text:"(",color:"dark_gray"},{text:"",color:"white"},{text:", ",color:"dark_gray"},{text:"",color:"white"},{text:")",color:"dark_gray"}]
execute store result storage evercraft:notify named.v int 1 run scoreboard players get @s ec.move_lastx
data modify storage evercraft:notify named.i set value 2
function evercraft:util/notify/stage_text with storage evercraft:notify named
execute store result storage evercraft:notify named.v int 1 run scoreboard players get @s ec.move_lastz
data modify storage evercraft:notify named.i set value 4
function evercraft:util/notify/stage_text with storage evercraft:notify named
scoreboard players set #ndur ec.temp 45
execute as @a run scoreboard players set #nttl ec.temp 300
execute as @a run function evercraft:util/notify/emit
