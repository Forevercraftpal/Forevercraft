# Skyrift Derby — Hit Checkpoint
# Runs as the racing player who reached their next checkpoint

# Advance checkpoint counter
scoreboard players add @s ec.mt_checkpoints 1

# Sound + particles
execute at @s if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.experience_orb.pickup master @s ~ ~ ~ 1.0 1.5
execute at @s run particle minecraft:firework ~ ~1 ~ 1 1 1 0.1 30 force

# Check if all 4 checkpoints hit → complete a lap
execute if score @s ec.mt_checkpoints matches 5 run function evercraft:mount_training/skyrift/complete_lap

# Show progress (only if not completing a lap, which shows its own message)
execute unless score @s ec.mt_checkpoints matches 5 run data modify storage evercraft:notify stage.c set value [{text:"Checkpoint ",color:"aqua"},{score:{name:"@s",objective:"ec.mt_checkpoints"},color:"white",bold:true},{text:"/4",color:"gray"},{text:" — Lap ",color:"aqua"},{score:{name:"@s",objective:"ec.mt_laps"},color:"white",bold:true},{text:"/3",color:"gray"}]
execute unless score @s ec.mt_checkpoints matches 5 run scoreboard players set #ndur ec.temp 45
execute unless score @s ec.mt_checkpoints matches 5 run function evercraft:util/notify/emit
