# Skyrift Derby — Leaderboard
# Find top finisher(s) and announce

# Find fastest time among finishers
scoreboard players set #mt_top_time ec.var 999999
execute as @a[tag=ec.mt_finished] if score @s ec.mt_best_time < #mt_top_time ec.var run scoreboard players operation #mt_top_time ec.var = @s ec.mt_best_time

# No finishers
data modify storage evercraft:notify stage.c set value [{text:"No one completed the race!",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 45
execute unless entity @a[tag=ec.mt_finished] as @a run function evercraft:util/notify/emit
execute unless entity @a[tag=ec.mt_finished] run return 0

# Announce winner(s) — player(s) matching fastest time
execute as @a[tag=ec.mt_finished] if score @s ec.mt_best_time = #mt_top_time ec.var run function evercraft:mount_training/skyrift/announce_winner

# Announce other finishers
execute as @a[tag=ec.mt_finished] unless score @s ec.mt_best_time = #mt_top_time ec.var run function evercraft:util/notify/whoami
data modify storage evercraft:notify stage.c set value [{text:"",color:"gray"},{text:" — finished",color:"dark_gray"}]
data modify storage evercraft:notify stage.c[0].text set from storage evercraft:notify named.who
scoreboard players set #ndur ec.temp 50
execute as @a[tag=ec.mt_finished] unless score @s ec.mt_best_time = #mt_top_time ec.var run execute as @a run scoreboard players set #nttl ec.temp 600
execute as @a[tag=ec.mt_finished] unless score @s ec.mt_best_time = #mt_top_time ec.var run execute as @a run function evercraft:util/notify/emit_keep
