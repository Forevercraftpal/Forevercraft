# Skyrift Derby — Event Tick (called every 1s by calendar event_dispatch)
# Particle rings at checkpoints, checkpoint detection, timer display

# Sync DR modifier for new joiners
execute as @a[tag=!ec.joined] run attribute @s luck modifier remove ec_cal_skyrift
execute as @a[tag=!ec.joined] run attribute @s luck modifier add ec_cal_skyrift 0.5 add_value

# === CHECKPOINT PARTICLES (end_rod rings) ===
# Only render for players within 100 blocks of each checkpoint
execute as @e[tag=ec.mt_cp] at @s run function evercraft:mount_training/skyrift/checkpoint_particles

# === AUTO-START: Player enters first checkpoint ring without racing tag ===
execute as @a[tag=!ec.mt_racer,tag=!ec.mt_finished] at @s if entity @e[tag=ec.mt_cp_hit1,distance=..5] run function evercraft:mount_training/skyrift/join_race

# === RACING PLAYERS: Increment timer + check checkpoints ===
execute as @a[tag=ec.mt_racer] run scoreboard players add @s ec.mt_race_time 20
execute as @a[tag=ec.mt_racer] at @s run function evercraft:mount_training/skyrift/check_checkpoint

# === TIMER DISPLAY (actionbar for racers) ===
execute as @a[tag=ec.mt_racer] run function evercraft:mount_training/skyrift/show_timer
