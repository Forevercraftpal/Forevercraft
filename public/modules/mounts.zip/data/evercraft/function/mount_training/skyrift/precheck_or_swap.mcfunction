# Skyrift Derby — Pre-start gate (RETIRED — the countdown/swap hack is GONE)
# deprecated — no longer scheduled (kept for revert; flagged for a future council)
# ---------------------------------------------------------------------
# This file used to be the "nobody has wings → announce, clear omen, re-roll a
# different event" work-around, plus a swap-on-expire path. Under the Unified
# Event Director, Skyrift is eligibility-gated AT SELECTION: the calendar only
# picks id 8 when a player currently has elytra equipped
# (event_director/cal_can_skyrift, checked in calendar/pick_event +
# calendar/pick_validate). When chosen, it starts cleanly via
# omens/calendar/start_event -> mount_training/skyrift/start. No countdown, no
# swap, no "winds fall still" notification.
#
# Intentionally a no-op now. Retained (not archived) per CLAUDE.md dead-code
# protocol — flagged for a future council, not deleted. Zero callers.
