# Skyrift Derby — Complete Race
# Runs as the player who completed 3 laps

# Remove racing tag, mark as finished
tag @s remove ec.mt_racer
tag @s add ec.mt_finished

# Calculate time in seconds for display (race_time is in ticks, 20t = 1s)
# But our tick runs every 1s and adds 20 per tick, so race_time is already in ticks-equivalent
# Divide by 20 for seconds
scoreboard players operation #mt_time_sec ec.temp = @s ec.mt_race_time
scoreboard players operation #mt_time_sec ec.temp /= #20 ec.const
# Minutes
scoreboard players operation #mt_time_min ec.temp = #mt_time_sec ec.temp
scoreboard players operation #mt_time_min ec.temp /= #60 ec.const

# Announce to all
function evercraft:util/notify/whoami
data modify storage evercraft:notify stage.c set value [{text:"",color:"gold"},{text:" finished the Skyrift Derby!",color:"light_purple"}]
data modify storage evercraft:notify stage.c[0].text set from storage evercraft:notify named.who
scoreboard players set #ndur ec.temp 50
execute as @a run scoreboard players set #nttl ec.temp 600
execute as @a run function evercraft:util/notify/emit_keep

# Effects
execute at @s run playsound minecraft:ui.toast.challenge_complete master @a[distance=..50,scores={ec.fx_snd=1..}] ~ ~ ~ 1.0 1.0
execute at @s run particle minecraft:totem_of_undying ~ ~1 ~ 1 2 1 0.2 50 force

# Title for finisher
title @s times 10 60 20
title @s title [{text:"RACE COMPLETE!",color:"gold"}]
title @s subtitle [{text:"Time: ",color:"gray"},{score:{name:"#mt_time_min",objective:"ec.temp"},color:"white"},{text:"m ",color:"gray"},{score:{name:"#mt_time_sec",objective:"ec.temp"},color:"white"},{text:"s",color:"gray"}]

# Check for personal best
execute unless score @s ec.mt_best_time matches 1.. run scoreboard players operation @s ec.mt_best_time = @s ec.mt_race_time
execute if score @s ec.mt_race_time < @s ec.mt_best_time run scoreboard players operation @s ec.mt_best_time = @s ec.mt_race_time
data modify storage evercraft:notify stage.c set value [{text:"NEW PERSONAL BEST!",color:"gold",bold:true}]
scoreboard players set #ndur ec.temp 45
execute if score @s ec.mt_race_time < @s ec.mt_best_time run function evercraft:util/notify/emit

# Check for world record
execute if score @s ec.mt_race_time < #cal_skyrift_record ec.var run scoreboard players operation #cal_skyrift_record ec.var = @s ec.mt_race_time
execute if score @s ec.mt_race_time < #cal_skyrift_record ec.var run function evercraft:util/notify/whoami
data modify storage evercraft:notify stage.c set value [{text:"",color:"gold",bold:true},{text:" set a new WORLD RECORD!",color:"yellow"}]
data modify storage evercraft:notify stage.c[0].text set from storage evercraft:notify named.who
scoreboard players set #ndur ec.temp 50
execute if score @s ec.mt_race_time < #cal_skyrift_record ec.var run execute as @a run scoreboard players set #nttl ec.temp 600
execute if score @s ec.mt_race_time < #cal_skyrift_record ec.var run execute as @a run function evercraft:util/notify/emit_keep

# Grant mount bond XP (+200 for completing, extra if on horse)
scoreboard players add @s ec.mt_bond 200
data modify storage evercraft:notify stage.c set value [{text:"+200 Mount Bond XP",color:"green"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit

# Participation reward: +100 Artisan XP (placeholder — scored when artisan system exists)
# +0.5 DR bonus already applied at event start
