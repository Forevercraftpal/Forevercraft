# Skyrift Derby — Checkpoint Particle Ring
# Runs as each checkpoint marker entity, at its position
# Renders a 5-block radius ring of end_rod particles

# Only render if players nearby (OPT: skip if no players within 100 blocks)
execute unless entity @a[distance=..100] run return 0

# Horizontal ring: 12 points around a 5-block radius circle
particle minecraft:end_rod ~5 ~ ~ 0 0 0 0 1 force
particle minecraft:end_rod ~4.33 ~ ~2.5 0 0 0 0 1 force
particle minecraft:end_rod ~2.5 ~ ~4.33 0 0 0 0 1 force
particle minecraft:end_rod ~ ~ ~5 0 0 0 0 1 force
particle minecraft:end_rod ~-2.5 ~ ~4.33 0 0 0 0 1 force
particle minecraft:end_rod ~-4.33 ~ ~2.5 0 0 0 0 1 force
particle minecraft:end_rod ~-5 ~ ~ 0 0 0 0 1 force
particle minecraft:end_rod ~-4.33 ~ ~-2.5 0 0 0 0 1 force
particle minecraft:end_rod ~-2.5 ~ ~-4.33 0 0 0 0 1 force
particle minecraft:end_rod ~ ~ ~-5 0 0 0 0 1 force
particle minecraft:end_rod ~2.5 ~ ~-4.33 0 0 0 0 1 force
particle minecraft:end_rod ~4.33 ~ ~-2.5 0 0 0 0 1 force
