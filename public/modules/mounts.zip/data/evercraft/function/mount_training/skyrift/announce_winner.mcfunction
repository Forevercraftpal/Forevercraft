# Skyrift Derby — Announce Winner
# Runs as each player who tied for fastest time

# Calculate display time
scoreboard players operation #mt_win_sec ec.temp = @s ec.mt_best_time
scoreboard players operation #mt_win_sec ec.temp /= #20 ec.const

# (Wave 2, 2026-06-10: rides the queue — winner name via whoami, time baked via stage_text, protected.)
function evercraft:util/notify/whoami
data modify storage evercraft:notify stage.c set value [{text:"Winner: ",color:"gold"},{text:"",color:"gold"},{text:" — ",color:"gray"},{text:"",color:"white"},{text:"s",color:"gray"}]
data modify storage evercraft:notify stage.c[1].text set from storage evercraft:notify named.who
execute store result storage evercraft:notify named.v int 1 run scoreboard players get #mt_win_sec ec.temp
data modify storage evercraft:notify named.i set value 3
function evercraft:util/notify/stage_text with storage evercraft:notify named
scoreboard players set #ndur ec.temp 50
execute as @a run scoreboard players set #nttl ec.temp 600
execute as @a run function evercraft:util/notify/emit_keep
