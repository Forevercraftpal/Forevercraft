# Skyrift Derby — Join Race
# Called when player walks into checkpoint 1 without racing tag
# Runs as the player at their position

# Initialize racing state
tag @s add ec.mt_racer
scoreboard players set @s ec.mt_race_time 0
scoreboard players set @s ec.mt_checkpoints 1
scoreboard players set @s ec.mt_laps 0

# Announce
data modify storage evercraft:notify stage.c set value [{text:"RACE STARTED!",color:"green",bold:true},{text:" Fly through the checkpoint rings!",color:"white"}]
scoreboard players set #ndur ec.temp 50
function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Checkpoint 1/4 — Lap 0/3",color:"aqua"}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit

# Notify others
function evercraft:util/notify/whoami
data modify storage evercraft:notify stage.c set value [{text:"",color:"yellow"},{text:" has entered the Skyrift Derby!",color:"gray"}]
data modify storage evercraft:notify stage.c[0].text set from storage evercraft:notify named.who
scoreboard players set #ndur ec.temp 50
execute as @a[tag=!ec.mt_racer] run scoreboard players set #nttl ec.temp 600
execute as @a[tag=!ec.mt_racer] run function evercraft:util/notify/emit_keep

# Effects
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.player.levelup master @s ~ ~ ~ 0.8 1.5
title @s times 5 30 10
title @s title {text:" "}
title @s subtitle [{text:"GO!",color:"green"}]

# Detect racing method (elytra vs horse)
scoreboard players set @s ec.mt_racing 1
execute if predicate evercraft:mount_training/riding_horse run scoreboard players set @s ec.mt_racing 2
