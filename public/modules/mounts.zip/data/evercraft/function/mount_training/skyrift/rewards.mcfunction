# Skyrift Derby — Rewards
# Runs as each finisher at their position

# Participation reward: Ornate crate (same as fishing derby pattern)
execute if score #inv_full ec.var matches 0 run loot give @s loot evercraft:artifacts/rare/main
execute if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:artifacts/rare/main
data modify storage evercraft:notify stage.c set value [{text:"You received a rare artifact for finishing!",color:"gold"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit

# Winner gets extra reward (check if fastest)
# Inv-full guard: drop at the player's feet rather than void on a full inventory.
execute store result score #inv_full ec.var run function evercraft:util/check_inv_full
execute if score @s ec.mt_best_time = #mt_top_time ec.var if score #inv_full ec.var matches 0 run loot give @s loot evercraft:artifacts/ornate/main
execute if score @s ec.mt_best_time = #mt_top_time ec.var at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:artifacts/ornate/main
data modify storage evercraft:notify stage.c set value [{text:"BONUS: Ornate artifact for 1st place!",color:"gold",bold:true}]
scoreboard players set #ndur ec.temp 45
execute if score @s ec.mt_best_time = #mt_top_time ec.var run function evercraft:util/notify/emit

# Bond XP already granted in complete_race (+200)

# Coin reward (participation + winner bonus)
function evercraft:coins/race_reward

# Sound
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.player.levelup master @s ~ ~ ~ 0.8 1.0
