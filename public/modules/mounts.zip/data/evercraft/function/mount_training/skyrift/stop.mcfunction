# Skyrift Derby — STOP (called at dawn by calendar dawn_check)

# Restore the fixed server sleep baseline after Skyrift Derby ends (matches init: 33%)
gamerule minecraft:players_sleeping_percentage 33

# Clear calendar state
scoreboard players set #cal_active ec.var 0
scoreboard players set #cal_event_id ec.var 0
scoreboard players set #cal_rest_days ec.var 6

# Remove DR modifier
execute as @a run attribute @s luck modifier remove ec_cal_skyrift

# === ANNOUNCE RESULTS ===
data modify storage evercraft:notify stage.c set value [{text:"SKYRIFT DERBY RESULTS",color:"light_purple",bold:true}]
scoreboard players set #ndur ec.temp 50
execute as @a run function evercraft:util/notify/emit

# Show finishers and their times
function evercraft:mount_training/skyrift/leaderboard

# Show non-finishers
execute as @a[tag=ec.mt_racer] run function evercraft:util/notify/whoami
data modify storage evercraft:notify stage.c set value [{text:"",color:"gray"},{text:" — Did not finish",color:"dark_gray"}]
data modify storage evercraft:notify stage.c[0].text set from storage evercraft:notify named.who
scoreboard players set #ndur ec.temp 50
execute as @a[tag=ec.mt_racer] run execute as @a run scoreboard players set #nttl ec.temp 600
execute as @a[tag=ec.mt_racer] run execute as @a run function evercraft:util/notify/emit_keep

# === REWARDS ===
# Participation: all players get rewards
execute as @a[tag=ec.mt_finished] at @s run function evercraft:mount_training/skyrift/rewards

# === CLEANUP ===
# Kill all checkpoint entities
kill @e[tag=ec.mt_cp]
kill @e[tag=ec.mt_cp_hit]

# Clear racing state
tag @a remove ec.mt_racer
tag @a remove ec.mt_finished
scoreboard players set @a ec.mt_racing 0
scoreboard players set @a ec.mt_race_time 0
scoreboard players set @a ec.mt_checkpoints 0
scoreboard players set @a ec.mt_laps 0

# Sound
execute as @a at @s if score @s ec.fx_snd matches 1.. run playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 0.5 1.2

# Title
title @a times 10 40 20
title @a title {text:" "}
title @a subtitle {text:"Skyrift Derby Ended",color:"gray"}
