# Skyrift Derby — Show Timer on Actionbar
# Runs as each racing player

# Calculate seconds from tick count (race_time counts in 20-tick increments)
scoreboard players operation #mt_disp_sec ec.temp = @s ec.mt_race_time
scoreboard players operation #mt_disp_sec ec.temp /= #20 ec.const

execute unless entity @s[tag=ab_q] run title @s actionbar [{text:"Time: ",color:"light_purple"},{score:{name:"#mt_disp_sec",objective:"ec.temp"},color:"white",bold:true},{text:"s",color:"gray"},{text:" | ",color:"dark_gray"},{text:"CP ",color:"aqua"},{score:{name:"@s",objective:"ec.mt_checkpoints"},color:"white"},{text:"/4",color:"gray"},{text:" Lap ",color:"aqua"},{score:{name:"@s",objective:"ec.mt_laps"},color:"white"},{text:"/3",color:"gray"}]
