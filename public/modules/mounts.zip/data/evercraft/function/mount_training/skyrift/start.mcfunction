# Skyrift Derby — START (1-day calendar event #8)
# Timed elytra/horse race through checkpoint rings

# Block sleep during Skyrift Derby (would end the event early)
gamerule minecraft:players_sleeping_percentage 200

# Block in the Nether (no open sky)
execute in minecraft:the_nether run return 0

# Require elytra equipped
execute unless items entity @s armor.chest minecraft:elytra run tellraw @s [{text:"[Skyrift] ",color:"dark_purple"},{text:"You need an Elytra to participate!",color:"red"}]
execute unless items entity @s armor.chest minecraft:elytra run return 0

# Set calendar state
scoreboard players set #cal_active ec.var 1
scoreboard players set #cal_event_id ec.var 8
scoreboard players set #cal_event_days ec.var 1
function evercraft:briefing/log_event {msg:"Skyrift Derby started!"}

# Reset all racing state
scoreboard players set @a ec.mt_racing 0
scoreboard players set @a ec.mt_race_time 0
scoreboard players set @a ec.mt_checkpoints 0
scoreboard players set @a ec.mt_laps 0

# Spawn checkpoint markers relative to first online player
execute as @a[limit=1,sort=random] at @s run function evercraft:mount_training/skyrift/spawn_checkpoints

# Apply participation DR bonus (+0.5)
execute as @a run attribute @s luck modifier remove ec_cal_skyrift
execute as @a run attribute @s luck modifier add ec_cal_skyrift 0.5 add_value

# Server-wide announcement
data modify storage evercraft:notify stage.c set value [{text:"SKYRIFT DERBY",color:"light_purple",bold:true}]
scoreboard players set #ndur ec.temp 50
execute as @a run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"The race course has been set!",color:"dark_purple",italic:true}]
scoreboard players set #ndur ec.temp 40
execute as @a run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"+ ",color:"light_purple"},{text:"Fly or ride through 4 checkpoints",color:"white"}]
scoreboard players set #ndur ec.temp 40
execute as @a run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"+ ",color:"light_purple"},{text:"Complete 3 laps to finish",color:"white"}]
scoreboard players set #ndur ec.temp 40
execute as @a run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"+ ",color:"light_purple"},{text:"Dream Rate +0.5 for all",color:"green"}]
scoreboard players set #ndur ec.temp 40
execute as @a run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"+ ",color:"light_purple"},{text:"Top 3 win prizes!",color:"gold"}]
scoreboard players set #ndur ec.temp 40
execute as @a run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Duration: 1 day",color:"gray"}]
scoreboard players set #ndur ec.temp 40
execute as @a run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Walk into a checkpoint ring to start racing!",color:"yellow"}]
scoreboard players set #ndur ec.temp 40
execute as @a run function evercraft:util/notify/emit

# Sound
execute as @a at @s if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.ender_dragon.flap master @s ~ ~ ~ 0.6 1.5
execute as @a at @s if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.5 1.5

# Title
title @a times 10 60 20
title @a title {text:" "}
title @a subtitle [{text:"Skyrift Derby",color:"light_purple"}]
