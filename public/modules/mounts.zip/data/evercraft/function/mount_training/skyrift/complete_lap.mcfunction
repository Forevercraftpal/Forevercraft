# Skyrift Derby — Complete Lap
# Runs as the racing player who completed all 4 checkpoints

# Reset checkpoint counter, increment laps
scoreboard players set @s ec.mt_checkpoints 1
scoreboard players add @s ec.mt_laps 1

# Check if race complete (3 laps)
execute if score @s ec.mt_laps matches 3 run function evercraft:mount_training/skyrift/complete_race
execute if score @s ec.mt_laps matches 3 run return 0

# Not done — announce lap completion
execute at @s if score @s ec.fx_snd matches 1.. run playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 0.7 1.2
execute at @s run particle minecraft:totem_of_undying ~ ~1 ~ 0.5 1 0.5 0.1 20 force

title @s times 5 40 10
title @s title {text:" "}
title @s subtitle [{text:"Lap ",color:"aqua"},{score:{name:"@s",objective:"ec.mt_laps"},color:"white"},{text:"/3 Complete!",color:"aqua"}]
