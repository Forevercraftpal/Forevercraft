# Mount Training — Assign Primary Mount
# Called when player has ridden a tamed horse for 5+ minutes with no current bond UUID
# Handles both first bond (bond=0) and rebond after horse death (bond>0, uuid0=0)
# Runs as the player

# Store the horse's UUID for future targeting
execute store result score @s ec.mt_uuid0 on vehicle run data get entity @s UUID[0]
execute store result score @s ec.mt_uuid1 on vehicle run data get entity @s UUID[1]

# First bond: initialize at 1
execute if score @s ec.mt_bond matches 0 run scoreboard players set @s ec.mt_bond 1

# Rebond message (different from first bond)
data modify storage evercraft:notify stage.c set value [{text:"MOUNT REBONDED",color:"gold",bold:true}]
scoreboard players set #ndur ec.temp 50
execute if score @s ec.mt_bond matches 2.. run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"You've bonded with a new horse!",color:"yellow"}]
scoreboard players set #ndur ec.temp 40
execute if score @s ec.mt_bond matches 2.. run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Your bond experience carries over.",color:"gray"}]
scoreboard players set #ndur ec.temp 40
execute if score @s ec.mt_bond matches 2.. run function evercraft:util/notify/emit

# First bond message
data modify storage evercraft:notify stage.c set value [{text:"MOUNT BONDED",color:"gold",bold:true}]
scoreboard players set #ndur ec.temp 50
execute if score @s ec.mt_bond matches 1 run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"You've formed a bond with your horse!",color:"yellow"}]
scoreboard players set #ndur ec.temp 40
execute if score @s ec.mt_bond matches 1 run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Ride, feed, and race to strengthen it.",color:"gray"}]
scoreboard players set #ndur ec.temp 40
execute if score @s ec.mt_bond matches 1 run function evercraft:util/notify/emit

# Effects
execute at @s if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.player.levelup master @s ~ ~ ~ 0.8 1.2
execute at @s run particle minecraft:heart ~ ~2 ~ 1 0.5 1 0.1 10 force
execute on vehicle at @s run particle minecraft:happy_villager ~ ~1 ~ 0.5 0.5 0.5 0.1 15 force

# Sync speed modifier for current tier (rebond case — tier may already be high)
execute if score @s ec.mt_tier matches 1.. run function evercraft:mount_training/sync_speed
