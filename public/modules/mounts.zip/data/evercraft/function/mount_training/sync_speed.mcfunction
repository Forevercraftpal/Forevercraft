# Mount Training — Sync Speed Modifier
# Ensures the bonded horse has the correct speed modifier for the player's tier
# Called when player starts riding (on mount detection)
# Runs as the player, on vehicle targets the horse

# Remove old modifier first
execute on vehicle run attribute @s movement_speed modifier remove evercraft:mount_bond_speed

# Apply modifier based on current tier
execute if score @s ec.mt_tier matches 1 on vehicle run attribute @s movement_speed modifier add evercraft:mount_bond_speed 0.1 add_multiplied_base
execute if score @s ec.mt_tier matches 2 on vehicle run attribute @s movement_speed modifier add evercraft:mount_bond_speed 0.2 add_multiplied_base
execute if score @s ec.mt_tier matches 3 on vehicle run attribute @s movement_speed modifier add evercraft:mount_bond_speed 0.3 add_multiplied_base
execute if score @s ec.mt_tier matches 4 on vehicle run attribute @s movement_speed modifier add evercraft:mount_bond_speed 0.4 add_multiplied_base
