# Wise Wanderer — Buy Common Crate (15 XP levels)
# Dispatched 'on target' from check_clicks → @s = the verified clicking player.

# Check XP level
execute store result score #ww_xp adv.temp run experience query @s levels
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"Not enough XP! Need 15 levels.",color:"red"},{text:" ✦",color:"gold"}]
scoreboard players set #ndur ec.temp 45
execute unless score #ww_xp adv.temp matches 15.. as @s run return run function evercraft:util/notify/emit

# Check inventory space before purchase
execute as @s store result score #inv_full ec.var run function evercraft:util/check_inv_full

# Deduct XP
experience add @s -15 levels

# Give crate
execute if score #inv_full ec.var matches 0 run loot give @s loot evercraft:professions/wise_wanderer/crates/common_crate
execute if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:professions/wise_wanderer/crates/common_crate

# Feedback
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.experience_orb.pickup master @s ~ ~ ~ 1 1.2
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"Purchased ",color:"gray"},{text:"Common Crate",color:"white"},{text:" for 15 levels!",color:"gray"},{text:" ✦",color:"gold"}]
scoreboard players set #ndur ec.temp 45
execute as @s run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Inventory full! Your crate was dropped at your feet.",color:"yellow"}]
scoreboard players set #ndur ec.temp 45
execute if score #inv_full ec.var matches 1 as @s run function evercraft:util/notify/emit
execute if score #inv_full ec.var matches 1 if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 1 0.5
