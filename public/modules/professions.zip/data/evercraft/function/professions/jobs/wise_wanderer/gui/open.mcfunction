# Wise Wanderer — Open Floating GUI
# Spawns text_display + interaction entities in front of the player
# Uses item_display background pane (same technique as Advantage GUI)
# Runs as the player who clicked the Wise Wanderer

# Tag the player
# Menu Core: Y-displacement close anchor
# One-menu-at-a-time (2026-06-15): close any other open menu before this one claims
# ec.menu_active. Two overlapping menus share the @s adv.gui_session slot; the newer
# open orphans the older menu's session, so it can never consume its click -> stuck
# interaction NBT -> click-sound spam. force_close is idempotent (no-op when nothing open).
execute if entity @s[tag=ec.menu_active] run function evercraft:menu_core/force_close
tag @s add ec.menu_active
execute store result score @s ec.menu_open_y run data get entity @s Pos[1] 100
# Sneak-position polish (MP-P3.5): when crouching, lower spawn anchor by 0.20m so
# menu sits at a comfortable view-angle for the lowered eye height. Tag is read by
# every summon line below (paired unless/if) and removed at end-of-file.
tag @s remove ec.menu_sneak_open
execute if predicate evercraft:player_crouching run tag @s add ec.menu_sneak_open


tag @s add WW.InMenu

# Spawn anchor marker (yaw-only, eye level, 1.8 blocks forward)
execute unless entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^ ^2.05 ^1.8 run summon marker ~ ~ ~ {Tags:["WW.MenuElement","WW.MenuAnchor"]}
execute if entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^ ^1.85 ^1.8 run summon marker ~ ~ ~ {Tags:["WW.MenuElement","WW.MenuAnchor"]}

# Background panel (black stained glass pane, scaled to cover all content)
execute unless entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^ ^2.05 ^1.8 run summon item_display ~ ~ ~ {Tags:["WW.MenuElement","WW.MenuBG"],billboard:"center",item:{id:"black_stained_glass_pane",count:1},item_display:"fixed",transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,-0.02f],scale:[2.8f,2.0f,0.01f]}}
execute if entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^ ^1.85 ^1.8 run summon item_display ~ ~ ~ {Tags:["WW.MenuElement","WW.MenuBG"],billboard:"center",item:{id:"black_stained_glass_pane",count:1},item_display:"fixed",transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,-0.02f],scale:[2.8f,2.0f,0.01f]}}

# === Title ===
# Ownership-header label (MP-P3.6): foreign viewers see whose menu this is
# 26.1: {selector:} renders blank in text_display — bake @s's name to a $(owner) literal.
function evercraft:util/gui/owner_name
execute rotated ~ 0 positioned ^ ^3.03 ^1.78 run function evercraft:professions/jobs/wise_wanderer/gui/open_nm with storage evercraft:scorebake args
execute unless entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^ ^2.85 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["WW.MenuElement","WW.MenuTitle"],billboard:"center",text:{text:"\u2726 Wise Wanderer's Wares \u2726",color:"gold",bold:true},background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.743f,0.743f,0.743f]}}
execute if entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^ ^2.65 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["WW.MenuElement","WW.MenuTitle"],billboard:"center",text:{text:"\u2726 Wise Wanderer's Wares \u2726",color:"gold",bold:true},background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.743f,0.743f,0.743f]}}

# === Crate Rows (text_display + interaction pairs) ===
# Rows spaced 0.16 apart; hit = full row (width:1.0, height:0.16) centered on text Y → dead-gap=0

# Common - 15 levels
execute unless entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^ ^2.65 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["WW.MenuElement","WW.RowCommon"],billboard:"center",text:[{text:"  Common Crate",color:"white"},{text:"         15 Lvls  ",color:"gray"},{text:"[Buy]",color:"green",bold:true}],background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.54f,0.54f,0.54f]}}
execute if entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^ ^2.45 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["WW.MenuElement","WW.RowCommon"],billboard:"center",text:[{text:"  Common Crate",color:"white"},{text:"         15 Lvls  ",color:"gray"},{text:"[Buy]",color:"green",bold:true}],background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.54f,0.54f,0.54f]}}
# [strip] ?: 1w split into 7 x 0.16 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute unless entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^-0.42 ^2.57 ^1.8 run summon interaction ~ ~ ~ {Tags:["WW.MenuElement","WW.BuyCommon"],width:0.16f,height:0.16f,response:1b}
execute unless entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^-0.28 ^2.57 ^1.8 run summon interaction ~ ~ ~ {Tags:["WW.MenuElement","WW.BuyCommon"],width:0.16f,height:0.16f,response:1b}
execute unless entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^-0.14 ^2.57 ^1.8 run summon interaction ~ ~ ~ {Tags:["WW.MenuElement","WW.BuyCommon"],width:0.16f,height:0.16f,response:1b}
execute unless entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^0 ^2.57 ^1.8 run summon interaction ~ ~ ~ {Tags:["WW.MenuElement","WW.BuyCommon"],width:0.16f,height:0.16f,response:1b}
execute unless entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^0.14 ^2.57 ^1.8 run summon interaction ~ ~ ~ {Tags:["WW.MenuElement","WW.BuyCommon"],width:0.16f,height:0.16f,response:1b}
execute unless entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^0.28 ^2.57 ^1.8 run summon interaction ~ ~ ~ {Tags:["WW.MenuElement","WW.BuyCommon"],width:0.16f,height:0.16f,response:1b}
execute unless entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^0.42 ^2.57 ^1.8 run summon interaction ~ ~ ~ {Tags:["WW.MenuElement","WW.BuyCommon"],width:0.16f,height:0.16f,response:1b}
# [strip] ?: 1w split into 7 x 0.16 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute if entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^-0.42 ^2.37 ^1.8 run summon interaction ~ ~ ~ {Tags:["WW.MenuElement","WW.BuyCommon"],width:0.16f,height:0.16f,response:1b}
execute if entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^-0.28 ^2.37 ^1.8 run summon interaction ~ ~ ~ {Tags:["WW.MenuElement","WW.BuyCommon"],width:0.16f,height:0.16f,response:1b}
execute if entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^-0.14 ^2.37 ^1.8 run summon interaction ~ ~ ~ {Tags:["WW.MenuElement","WW.BuyCommon"],width:0.16f,height:0.16f,response:1b}
execute if entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^0 ^2.37 ^1.8 run summon interaction ~ ~ ~ {Tags:["WW.MenuElement","WW.BuyCommon"],width:0.16f,height:0.16f,response:1b}
execute if entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^0.14 ^2.37 ^1.8 run summon interaction ~ ~ ~ {Tags:["WW.MenuElement","WW.BuyCommon"],width:0.16f,height:0.16f,response:1b}
execute if entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^0.28 ^2.37 ^1.8 run summon interaction ~ ~ ~ {Tags:["WW.MenuElement","WW.BuyCommon"],width:0.16f,height:0.16f,response:1b}
execute if entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^0.42 ^2.37 ^1.8 run summon interaction ~ ~ ~ {Tags:["WW.MenuElement","WW.BuyCommon"],width:0.16f,height:0.16f,response:1b}

# Uncommon - 30 levels
execute unless entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^ ^2.49 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["WW.MenuElement","WW.RowUncommon"],billboard:"center",text:[{text:"  Uncommon Crate",color:"green"},{text:"      30 Lvls  ",color:"gray"},{text:"[Buy]",color:"green",bold:true}],background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.54f,0.54f,0.54f]}}
execute if entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^ ^2.29 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["WW.MenuElement","WW.RowUncommon"],billboard:"center",text:[{text:"  Uncommon Crate",color:"green"},{text:"      30 Lvls  ",color:"gray"},{text:"[Buy]",color:"green",bold:true}],background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.54f,0.54f,0.54f]}}
# [strip] ?: 1w split into 7 x 0.16 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute unless entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^-0.42 ^2.41 ^1.8 run summon interaction ~ ~ ~ {Tags:["WW.MenuElement","WW.BuyUncommon"],width:0.16f,height:0.16f,response:1b}
execute unless entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^-0.28 ^2.41 ^1.8 run summon interaction ~ ~ ~ {Tags:["WW.MenuElement","WW.BuyUncommon"],width:0.16f,height:0.16f,response:1b}
execute unless entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^-0.14 ^2.41 ^1.8 run summon interaction ~ ~ ~ {Tags:["WW.MenuElement","WW.BuyUncommon"],width:0.16f,height:0.16f,response:1b}
execute unless entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^0 ^2.41 ^1.8 run summon interaction ~ ~ ~ {Tags:["WW.MenuElement","WW.BuyUncommon"],width:0.16f,height:0.16f,response:1b}
execute unless entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^0.14 ^2.41 ^1.8 run summon interaction ~ ~ ~ {Tags:["WW.MenuElement","WW.BuyUncommon"],width:0.16f,height:0.16f,response:1b}
execute unless entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^0.28 ^2.41 ^1.8 run summon interaction ~ ~ ~ {Tags:["WW.MenuElement","WW.BuyUncommon"],width:0.16f,height:0.16f,response:1b}
execute unless entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^0.42 ^2.41 ^1.8 run summon interaction ~ ~ ~ {Tags:["WW.MenuElement","WW.BuyUncommon"],width:0.16f,height:0.16f,response:1b}
# [strip] ?: 1w split into 7 x 0.16 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute if entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^-0.42 ^2.21 ^1.8 run summon interaction ~ ~ ~ {Tags:["WW.MenuElement","WW.BuyUncommon"],width:0.16f,height:0.16f,response:1b}
execute if entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^-0.28 ^2.21 ^1.8 run summon interaction ~ ~ ~ {Tags:["WW.MenuElement","WW.BuyUncommon"],width:0.16f,height:0.16f,response:1b}
execute if entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^-0.14 ^2.21 ^1.8 run summon interaction ~ ~ ~ {Tags:["WW.MenuElement","WW.BuyUncommon"],width:0.16f,height:0.16f,response:1b}
execute if entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^0 ^2.21 ^1.8 run summon interaction ~ ~ ~ {Tags:["WW.MenuElement","WW.BuyUncommon"],width:0.16f,height:0.16f,response:1b}
execute if entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^0.14 ^2.21 ^1.8 run summon interaction ~ ~ ~ {Tags:["WW.MenuElement","WW.BuyUncommon"],width:0.16f,height:0.16f,response:1b}
execute if entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^0.28 ^2.21 ^1.8 run summon interaction ~ ~ ~ {Tags:["WW.MenuElement","WW.BuyUncommon"],width:0.16f,height:0.16f,response:1b}
execute if entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^0.42 ^2.21 ^1.8 run summon interaction ~ ~ ~ {Tags:["WW.MenuElement","WW.BuyUncommon"],width:0.16f,height:0.16f,response:1b}

# Rare - 50 levels
execute unless entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^ ^2.33 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["WW.MenuElement","WW.RowRare"],billboard:"center",text:[{text:"  Rare Crate",color:"aqua"},{text:"            50 Lvls  ",color:"gray"},{text:"[Buy]",color:"green",bold:true}],background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.54f,0.54f,0.54f]}}
execute if entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^ ^2.13 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["WW.MenuElement","WW.RowRare"],billboard:"center",text:[{text:"  Rare Crate",color:"aqua"},{text:"            50 Lvls  ",color:"gray"},{text:"[Buy]",color:"green",bold:true}],background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.54f,0.54f,0.54f]}}
# [strip] ?: 1w split into 7 x 0.16 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute unless entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^-0.42 ^2.25 ^1.8 run summon interaction ~ ~ ~ {Tags:["WW.MenuElement","WW.BuyRare"],width:0.16f,height:0.16f,response:1b}
execute unless entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^-0.28 ^2.25 ^1.8 run summon interaction ~ ~ ~ {Tags:["WW.MenuElement","WW.BuyRare"],width:0.16f,height:0.16f,response:1b}
execute unless entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^-0.14 ^2.25 ^1.8 run summon interaction ~ ~ ~ {Tags:["WW.MenuElement","WW.BuyRare"],width:0.16f,height:0.16f,response:1b}
execute unless entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^0 ^2.25 ^1.8 run summon interaction ~ ~ ~ {Tags:["WW.MenuElement","WW.BuyRare"],width:0.16f,height:0.16f,response:1b}
execute unless entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^0.14 ^2.25 ^1.8 run summon interaction ~ ~ ~ {Tags:["WW.MenuElement","WW.BuyRare"],width:0.16f,height:0.16f,response:1b}
execute unless entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^0.28 ^2.25 ^1.8 run summon interaction ~ ~ ~ {Tags:["WW.MenuElement","WW.BuyRare"],width:0.16f,height:0.16f,response:1b}
execute unless entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^0.42 ^2.25 ^1.8 run summon interaction ~ ~ ~ {Tags:["WW.MenuElement","WW.BuyRare"],width:0.16f,height:0.16f,response:1b}
# [strip] ?: 1w split into 7 x 0.16 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute if entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^-0.42 ^2.05 ^1.8 run summon interaction ~ ~ ~ {Tags:["WW.MenuElement","WW.BuyRare"],width:0.16f,height:0.16f,response:1b}
execute if entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^-0.28 ^2.05 ^1.8 run summon interaction ~ ~ ~ {Tags:["WW.MenuElement","WW.BuyRare"],width:0.16f,height:0.16f,response:1b}
execute if entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^-0.14 ^2.05 ^1.8 run summon interaction ~ ~ ~ {Tags:["WW.MenuElement","WW.BuyRare"],width:0.16f,height:0.16f,response:1b}
execute if entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^0 ^2.05 ^1.8 run summon interaction ~ ~ ~ {Tags:["WW.MenuElement","WW.BuyRare"],width:0.16f,height:0.16f,response:1b}
execute if entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^0.14 ^2.05 ^1.8 run summon interaction ~ ~ ~ {Tags:["WW.MenuElement","WW.BuyRare"],width:0.16f,height:0.16f,response:1b}
execute if entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^0.28 ^2.05 ^1.8 run summon interaction ~ ~ ~ {Tags:["WW.MenuElement","WW.BuyRare"],width:0.16f,height:0.16f,response:1b}
execute if entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^0.42 ^2.05 ^1.8 run summon interaction ~ ~ ~ {Tags:["WW.MenuElement","WW.BuyRare"],width:0.16f,height:0.16f,response:1b}

# Ornate - 75 levels
execute unless entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^ ^2.17 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["WW.MenuElement","WW.RowOrnate"],billboard:"center",text:[{text:"  Ornate Crate",color:"light_purple"},{text:"        75 Lvls  ",color:"gray"},{text:"[Buy]",color:"green",bold:true}],background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.54f,0.54f,0.54f]}}
execute if entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^ ^1.97 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["WW.MenuElement","WW.RowOrnate"],billboard:"center",text:[{text:"  Ornate Crate",color:"light_purple"},{text:"        75 Lvls  ",color:"gray"},{text:"[Buy]",color:"green",bold:true}],background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.54f,0.54f,0.54f]}}
# [strip] ?: 1w split into 7 x 0.16 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute unless entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^-0.42 ^2.09 ^1.8 run summon interaction ~ ~ ~ {Tags:["WW.MenuElement","WW.BuyOrnate"],width:0.16f,height:0.16f,response:1b}
execute unless entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^-0.28 ^2.09 ^1.8 run summon interaction ~ ~ ~ {Tags:["WW.MenuElement","WW.BuyOrnate"],width:0.16f,height:0.16f,response:1b}
execute unless entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^-0.14 ^2.09 ^1.8 run summon interaction ~ ~ ~ {Tags:["WW.MenuElement","WW.BuyOrnate"],width:0.16f,height:0.16f,response:1b}
execute unless entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^0 ^2.09 ^1.8 run summon interaction ~ ~ ~ {Tags:["WW.MenuElement","WW.BuyOrnate"],width:0.16f,height:0.16f,response:1b}
execute unless entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^0.14 ^2.09 ^1.8 run summon interaction ~ ~ ~ {Tags:["WW.MenuElement","WW.BuyOrnate"],width:0.16f,height:0.16f,response:1b}
execute unless entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^0.28 ^2.09 ^1.8 run summon interaction ~ ~ ~ {Tags:["WW.MenuElement","WW.BuyOrnate"],width:0.16f,height:0.16f,response:1b}
execute unless entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^0.42 ^2.09 ^1.8 run summon interaction ~ ~ ~ {Tags:["WW.MenuElement","WW.BuyOrnate"],width:0.16f,height:0.16f,response:1b}
# [strip] ?: 1w split into 7 x 0.16 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute if entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^-0.42 ^1.89 ^1.8 run summon interaction ~ ~ ~ {Tags:["WW.MenuElement","WW.BuyOrnate"],width:0.16f,height:0.16f,response:1b}
execute if entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^-0.28 ^1.89 ^1.8 run summon interaction ~ ~ ~ {Tags:["WW.MenuElement","WW.BuyOrnate"],width:0.16f,height:0.16f,response:1b}
execute if entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^-0.14 ^1.89 ^1.8 run summon interaction ~ ~ ~ {Tags:["WW.MenuElement","WW.BuyOrnate"],width:0.16f,height:0.16f,response:1b}
execute if entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^0 ^1.89 ^1.8 run summon interaction ~ ~ ~ {Tags:["WW.MenuElement","WW.BuyOrnate"],width:0.16f,height:0.16f,response:1b}
execute if entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^0.14 ^1.89 ^1.8 run summon interaction ~ ~ ~ {Tags:["WW.MenuElement","WW.BuyOrnate"],width:0.16f,height:0.16f,response:1b}
execute if entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^0.28 ^1.89 ^1.8 run summon interaction ~ ~ ~ {Tags:["WW.MenuElement","WW.BuyOrnate"],width:0.16f,height:0.16f,response:1b}
execute if entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^0.42 ^1.89 ^1.8 run summon interaction ~ ~ ~ {Tags:["WW.MenuElement","WW.BuyOrnate"],width:0.16f,height:0.16f,response:1b}

# Exquisite - 125 levels
execute unless entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^ ^2.01 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["WW.MenuElement","WW.RowExquisite"],billboard:"center",text:[{text:"  Exquisite Crate",color:"light_purple"},{text:"   125 Lvls  ",color:"gray"},{text:"[Buy]",color:"green",bold:true}],background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.54f,0.54f,0.54f]}}
execute if entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^ ^1.81 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["WW.MenuElement","WW.RowExquisite"],billboard:"center",text:[{text:"  Exquisite Crate",color:"light_purple"},{text:"   125 Lvls  ",color:"gray"},{text:"[Buy]",color:"green",bold:true}],background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.54f,0.54f,0.54f]}}
# [strip] ?: 1w split into 7 x 0.16 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute unless entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^-0.42 ^1.93 ^1.8 run summon interaction ~ ~ ~ {Tags:["WW.MenuElement","WW.BuyExquisite"],width:0.16f,height:0.16f,response:1b}
execute unless entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^-0.28 ^1.93 ^1.8 run summon interaction ~ ~ ~ {Tags:["WW.MenuElement","WW.BuyExquisite"],width:0.16f,height:0.16f,response:1b}
execute unless entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^-0.14 ^1.93 ^1.8 run summon interaction ~ ~ ~ {Tags:["WW.MenuElement","WW.BuyExquisite"],width:0.16f,height:0.16f,response:1b}
execute unless entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^0 ^1.93 ^1.8 run summon interaction ~ ~ ~ {Tags:["WW.MenuElement","WW.BuyExquisite"],width:0.16f,height:0.16f,response:1b}
execute unless entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^0.14 ^1.93 ^1.8 run summon interaction ~ ~ ~ {Tags:["WW.MenuElement","WW.BuyExquisite"],width:0.16f,height:0.16f,response:1b}
execute unless entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^0.28 ^1.93 ^1.8 run summon interaction ~ ~ ~ {Tags:["WW.MenuElement","WW.BuyExquisite"],width:0.16f,height:0.16f,response:1b}
execute unless entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^0.42 ^1.93 ^1.8 run summon interaction ~ ~ ~ {Tags:["WW.MenuElement","WW.BuyExquisite"],width:0.16f,height:0.16f,response:1b}
# [strip] ?: 1w split into 7 x 0.16 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute if entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^-0.42 ^1.73 ^1.8 run summon interaction ~ ~ ~ {Tags:["WW.MenuElement","WW.BuyExquisite"],width:0.16f,height:0.16f,response:1b}
execute if entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^-0.28 ^1.73 ^1.8 run summon interaction ~ ~ ~ {Tags:["WW.MenuElement","WW.BuyExquisite"],width:0.16f,height:0.16f,response:1b}
execute if entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^-0.14 ^1.73 ^1.8 run summon interaction ~ ~ ~ {Tags:["WW.MenuElement","WW.BuyExquisite"],width:0.16f,height:0.16f,response:1b}
execute if entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^0 ^1.73 ^1.8 run summon interaction ~ ~ ~ {Tags:["WW.MenuElement","WW.BuyExquisite"],width:0.16f,height:0.16f,response:1b}
execute if entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^0.14 ^1.73 ^1.8 run summon interaction ~ ~ ~ {Tags:["WW.MenuElement","WW.BuyExquisite"],width:0.16f,height:0.16f,response:1b}
execute if entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^0.28 ^1.73 ^1.8 run summon interaction ~ ~ ~ {Tags:["WW.MenuElement","WW.BuyExquisite"],width:0.16f,height:0.16f,response:1b}
execute if entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^0.42 ^1.73 ^1.8 run summon interaction ~ ~ ~ {Tags:["WW.MenuElement","WW.BuyExquisite"],width:0.16f,height:0.16f,response:1b}

# Mythical - 250 levels
execute unless entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^ ^1.85 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["WW.MenuElement","WW.RowMythical"],billboard:"center",text:[{text:"  Mythical Crate",color:"gold"},{text:"     250 Lvls  ",color:"gray"},{text:"[Buy]",color:"green",bold:true}],background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.54f,0.54f,0.54f]}}
execute if entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^ ^1.65 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["WW.MenuElement","WW.RowMythical"],billboard:"center",text:[{text:"  Mythical Crate",color:"gold"},{text:"     250 Lvls  ",color:"gray"},{text:"[Buy]",color:"green",bold:true}],background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.54f,0.54f,0.54f]}}
# [strip] ?: 1w split into 7 x 0.16 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute unless entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^-0.42 ^1.77 ^1.8 run summon interaction ~ ~ ~ {Tags:["WW.MenuElement","WW.BuyMythical"],width:0.16f,height:0.16f,response:1b}
execute unless entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^-0.28 ^1.77 ^1.8 run summon interaction ~ ~ ~ {Tags:["WW.MenuElement","WW.BuyMythical"],width:0.16f,height:0.16f,response:1b}
execute unless entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^-0.14 ^1.77 ^1.8 run summon interaction ~ ~ ~ {Tags:["WW.MenuElement","WW.BuyMythical"],width:0.16f,height:0.16f,response:1b}
execute unless entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^0 ^1.77 ^1.8 run summon interaction ~ ~ ~ {Tags:["WW.MenuElement","WW.BuyMythical"],width:0.16f,height:0.16f,response:1b}
execute unless entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^0.14 ^1.77 ^1.8 run summon interaction ~ ~ ~ {Tags:["WW.MenuElement","WW.BuyMythical"],width:0.16f,height:0.16f,response:1b}
execute unless entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^0.28 ^1.77 ^1.8 run summon interaction ~ ~ ~ {Tags:["WW.MenuElement","WW.BuyMythical"],width:0.16f,height:0.16f,response:1b}
execute unless entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^0.42 ^1.77 ^1.8 run summon interaction ~ ~ ~ {Tags:["WW.MenuElement","WW.BuyMythical"],width:0.16f,height:0.16f,response:1b}
# [strip] ?: 1w split into 7 x 0.16 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute if entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^-0.42 ^1.57 ^1.8 run summon interaction ~ ~ ~ {Tags:["WW.MenuElement","WW.BuyMythical"],width:0.16f,height:0.16f,response:1b}
execute if entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^-0.28 ^1.57 ^1.8 run summon interaction ~ ~ ~ {Tags:["WW.MenuElement","WW.BuyMythical"],width:0.16f,height:0.16f,response:1b}
execute if entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^-0.14 ^1.57 ^1.8 run summon interaction ~ ~ ~ {Tags:["WW.MenuElement","WW.BuyMythical"],width:0.16f,height:0.16f,response:1b}
execute if entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^0 ^1.57 ^1.8 run summon interaction ~ ~ ~ {Tags:["WW.MenuElement","WW.BuyMythical"],width:0.16f,height:0.16f,response:1b}
execute if entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^0.14 ^1.57 ^1.8 run summon interaction ~ ~ ~ {Tags:["WW.MenuElement","WW.BuyMythical"],width:0.16f,height:0.16f,response:1b}
execute if entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^0.28 ^1.57 ^1.8 run summon interaction ~ ~ ~ {Tags:["WW.MenuElement","WW.BuyMythical"],width:0.16f,height:0.16f,response:1b}
execute if entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^0.42 ^1.57 ^1.8 run summon interaction ~ ~ ~ {Tags:["WW.MenuElement","WW.BuyMythical"],width:0.16f,height:0.16f,response:1b}

# === XP Display ===
execute unless entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^ ^1.63 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["WW.MenuElement","WW.XPDisplay"],billboard:"center",text:{text:"Your XP: ... Levels",color:"green"},background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.54f,0.54f,0.54f]}}
execute if entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^ ^1.43 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["WW.MenuElement","WW.XPDisplay"],billboard:"center",text:{text:"Your XP: ... Levels",color:"green"},background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.54f,0.54f,0.54f]}}

# === Close Button ===
execute unless entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^ ^1.4 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["WW.MenuElement","WW.CloseText"],billboard:"center",text:{text:"[ Close ]",color:"red",bold:true},background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.54f,0.54f,0.54f]}}
execute if entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^ ^1.2 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["WW.MenuElement","WW.CloseText"],billboard:"center",text:{text:"[ Close ]",color:"red",bold:true},background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.54f,0.54f,0.54f]}}
execute unless entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^ ^1.38 ^1.78 run summon interaction ~ ~ ~ {Tags:["WW.MenuElement","WW.CloseClick"],width:0.35f,height:0.04f,response:1b}
execute if entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^ ^1.18 ^1.78 run summon interaction ~ ~ ~ {Tags:["WW.MenuElement","WW.CloseClick"],width:0.35f,height:0.04f,response:1b}

# Sound

# Initialize inactivity timer
scoreboard players set @s ec.ww_idle 0

# Session isolation
scoreboard players add #gui_session ec.var 1
scoreboard players operation @s adv.gui_session = #gui_session ec.var
scoreboard players operation #gui_stamp ec.temp = @s adv.gui_session
execute as @e[type=text_display,tag=WW.MenuElement,distance=..5] unless score @s adv.gui_session matches 1.. run scoreboard players operation @s adv.gui_session = #gui_stamp ec.temp
execute as @e[type=item_display,tag=WW.MenuElement,distance=..5] unless score @s adv.gui_session matches 1.. run scoreboard players operation @s adv.gui_session = #gui_stamp ec.temp
execute as @e[type=interaction,tag=WW.MenuElement,distance=..5] unless score @s adv.gui_session matches 1.. run scoreboard players operation @s adv.gui_session = #gui_stamp ec.temp

execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.8 1.2

# Initial refresh to set XP display and row availability
function evercraft:professions/jobs/wise_wanderer/gui/refresh

# Sneak-position polish cleanup
tag @s remove ec.menu_sneak_open
