# Wise Wanderer — Check Buy Clicks
# Poll each buy interaction entity + close button for click data

# Guard: if menu was closed (e.g. distance check), skip everything
execute unless entity @s[tag=WW.InMenu] run return 0

scoreboard players operation #gui_check ec.temp = @s adv.gui_session

# Common Crate (15 levels)
execute as @e[type=minecraft:interaction,tag=WW.BuyCommon,distance=..5,limit=1] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction on target run function evercraft:professions/jobs/wise_wanderer/gui/buy/common
execute as @e[type=minecraft:interaction,tag=WW.BuyCommon,distance=..5,limit=1] if score @s adv.gui_session = #gui_check ec.temp run data remove entity @s interaction

# Uncommon Crate (30 levels)
execute as @e[type=minecraft:interaction,tag=WW.BuyUncommon,distance=..5,limit=1] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction on target run function evercraft:professions/jobs/wise_wanderer/gui/buy/uncommon
execute as @e[type=minecraft:interaction,tag=WW.BuyUncommon,distance=..5,limit=1] if score @s adv.gui_session = #gui_check ec.temp run data remove entity @s interaction

# Rare Crate (50 levels)
execute as @e[type=minecraft:interaction,tag=WW.BuyRare,distance=..5,limit=1] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction on target run function evercraft:professions/jobs/wise_wanderer/gui/buy/rare
execute as @e[type=minecraft:interaction,tag=WW.BuyRare,distance=..5,limit=1] if score @s adv.gui_session = #gui_check ec.temp run data remove entity @s interaction

# Ornate Crate (75 levels)
execute as @e[type=minecraft:interaction,tag=WW.BuyOrnate,distance=..5,limit=1] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction on target run function evercraft:professions/jobs/wise_wanderer/gui/buy/ornate
execute as @e[type=minecraft:interaction,tag=WW.BuyOrnate,distance=..5,limit=1] if score @s adv.gui_session = #gui_check ec.temp run data remove entity @s interaction

# Exquisite Crate (125 levels)
execute as @e[type=minecraft:interaction,tag=WW.BuyExquisite,distance=..5,limit=1] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction on target run function evercraft:professions/jobs/wise_wanderer/gui/buy/exquisite
execute as @e[type=minecraft:interaction,tag=WW.BuyExquisite,distance=..5,limit=1] if score @s adv.gui_session = #gui_check ec.temp run data remove entity @s interaction

# Mythical Crate (250 levels)
execute as @e[type=minecraft:interaction,tag=WW.BuyMythical,distance=..5,limit=1] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction on target run function evercraft:professions/jobs/wise_wanderer/gui/buy/mythical
execute as @e[type=minecraft:interaction,tag=WW.BuyMythical,distance=..5,limit=1] if score @s adv.gui_session = #gui_check ec.temp run data remove entity @s interaction

# Close button — check click on interaction entity, but run close as the player (@s)
scoreboard players set #ww_close adv.temp 0
execute store success score #ww_close adv.temp as @e[type=minecraft:interaction,tag=WW.CloseClick,distance=..5,limit=1] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction
execute as @e[type=minecraft:interaction,tag=WW.CloseClick,distance=..5,limit=1] if score @s adv.gui_session = #gui_check ec.temp run data remove entity @s interaction
execute if score #ww_close adv.temp matches 1 run function evercraft:professions/jobs/wise_wanderer/gui/close

# ===== INSPECT (left-click = what does this button do?) — gui/inspect pattern 2026-06-11 =====
execute as @e[type=minecraft:interaction,tag=WW.BuyCommon,distance=..5,limit=1] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Common Crate",b:"Buys a common crate — priced in XP levels, listed on the row."}
execute as @e[type=minecraft:interaction,tag=WW.BuyUncommon,distance=..5,limit=1] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Uncommon Crate",b:"Buys an uncommon crate — priced in XP levels, listed on the row."}
execute as @e[type=minecraft:interaction,tag=WW.BuyRare,distance=..5,limit=1] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Rare Crate",b:"Buys a rare crate — priced in XP levels, listed on the row."}
execute as @e[type=minecraft:interaction,tag=WW.BuyOrnate,distance=..5,limit=1] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Ornate Crate",b:"Buys an ornate crate — priced in XP levels, listed on the row."}
execute as @e[type=minecraft:interaction,tag=WW.BuyExquisite,distance=..5,limit=1] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Exquisite Crate",b:"Buys an exquisite crate — priced in XP levels, listed on the row."}
execute as @e[type=minecraft:interaction,tag=WW.BuyMythical,distance=..5,limit=1] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Mythical Crate",b:"Buys a mythical crate — priced in XP levels, listed on the row."}
execute as @e[type=minecraft:interaction,tag=WW.BuyCommon,distance=..5,limit=1] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=minecraft:interaction,tag=WW.BuyUncommon,distance=..5,limit=1] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=minecraft:interaction,tag=WW.BuyRare,distance=..5,limit=1] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=minecraft:interaction,tag=WW.BuyOrnate,distance=..5,limit=1] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=minecraft:interaction,tag=WW.BuyExquisite,distance=..5,limit=1] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=minecraft:interaction,tag=WW.BuyMythical,distance=..5,limit=1] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=minecraft:interaction,tag=WW.CloseClick,distance=..5,limit=1] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Close",b:"Closes the Wise Wanderer."}
execute as @e[type=minecraft:interaction,tag=WW.CloseClick,distance=..5,limit=1] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack run data remove entity @s attack
