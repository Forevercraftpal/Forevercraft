# Wise Wanderer — Owner-scoped nearest-villager check
# Runs as the talking player, at the player's position (dispatched per-player from
# detect_interaction). Tag→check→clear all happen inside THIS one iteration so only
# the iterating player's own nearest villager is ever tagged WW.NearestCheck at a time
# (serial-within-tick) — no cross-fire between two players talking the same 1s cycle.

# Tag this player's nearest villager
tag @e[type=minecraft:villager,sort=nearest,distance=..5,limit=1] add WW.NearestCheck

# If it's a Wise Wanderer, open this player's shop
execute if entity @e[type=minecraft:villager,tag=WW.NearestCheck,tag=more_professions_wise_wanderer,distance=..5,limit=1] run function evercraft:professions/jobs/wise_wanderer/gui/on_click

# Clear the tag immediately so the next player's iteration starts clean
tag @e[type=minecraft:villager,tag=WW.NearestCheck,distance=..5] remove WW.NearestCheck
