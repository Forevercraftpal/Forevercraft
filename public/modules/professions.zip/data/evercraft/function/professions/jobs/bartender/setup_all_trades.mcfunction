# Bartender Trade Setup
# BUYS: Lower tier potions (Common, Uncommon, Rare) from players - must match crate drops exactly
# SELLS: Best potions (Exquisite) + Potion of Dreams VI
# Progressive unlocking based on villager level

# Clear existing trades
data modify entity @s Offers.Recipes set value []

# ===== NOVICE TRADES (Level 1) - Buy Common Negative Potions (joke potions) =====
# Buy Wanderer's Curse (splash) - pays 1 emerald
data modify entity @s Offers.Recipes append value {tier:0,max_uses:24,xp:2,uses:0,priceMultiplier:0.0f,specialPrice:0,demand:0,rewardExp:1b,buy:{id:"minecraft:splash_potion",count:1,components:{"minecraft:custom_name":{text:"Wanderer's Curse",color:"dark_gray",italic:true},"minecraft:potion_contents":{potion:"minecraft:thick",custom_color:3158064,custom_effects:[{id:"minecraft:slowness",amplifier:0,duration:600,show_particles:true},{id:"minecraft:unluck",amplifier:0,duration:600,show_particles:true}]}}},sell:{id:"minecraft:emerald",count:1}}

# Buy Wilted Extract (splash) - pays 1 emerald
data modify entity @s Offers.Recipes append value {tier:0,max_uses:24,xp:2,uses:0,priceMultiplier:0.0f,specialPrice:0,demand:0,rewardExp:1b,buy:{id:"minecraft:splash_potion",count:1,components:{"minecraft:custom_name":{text:"Wilted Extract",color:"dark_green",italic:true},"minecraft:potion_contents":{potion:"minecraft:thick",custom_color:5592405,custom_effects:[{id:"minecraft:hunger",amplifier:0,duration:600,show_particles:true}]}}},sell:{id:"minecraft:emerald",count:1}}

# Buy Coward's Tonic (splash) - pays 1 emerald
data modify entity @s Offers.Recipes append value {tier:0,max_uses:24,xp:2,uses:0,priceMultiplier:0.0f,specialPrice:0,demand:0,rewardExp:1b,buy:{id:"minecraft:splash_potion",count:1,components:{"minecraft:custom_name":{text:"Coward's Tonic",color:"dark_gray",italic:true},"minecraft:potion_contents":{potion:"minecraft:thick",custom_color:4738096,custom_effects:[{id:"minecraft:weakness",amplifier:0,duration:600,show_particles:true}]}}},sell:{id:"minecraft:emerald",count:1}}

# Buy Cave Sludge (splash) - pays 1 emerald
data modify entity @s Offers.Recipes append value {tier:0,max_uses:24,xp:2,uses:0,priceMultiplier:0.0f,specialPrice:0,demand:0,rewardExp:1b,buy:{id:"minecraft:splash_potion",count:1,components:{"minecraft:custom_name":{text:"Cave Sludge",color:"dark_gray",italic:true},"minecraft:potion_contents":{potion:"minecraft:thick",custom_color:5592405,custom_effects:[{id:"minecraft:slowness",amplifier:0,duration:600,show_particles:true},{id:"minecraft:mining_fatigue",amplifier:0,duration:600,show_particles:true}]}}},sell:{id:"minecraft:emerald",count:1}}

# ===== APPRENTICE TRADES (Level 2) - Buy Uncommon Potions =====
# Buy Scout's Sight - pays 4 emeralds
data modify entity @s Offers.Recipes append value {tier:1,max_uses:16,xp:5,uses:0,priceMultiplier:0.0f,specialPrice:0,demand:0,rewardExp:1b,buy:{id:"minecraft:potion",count:1,components:{"minecraft:custom_name":{text:"Scout's Sight",color:"yellow",italic:true},"minecraft:potion_contents":{potion:"minecraft:thick",custom_color:16777045,custom_effects:[{id:"minecraft:night_vision",amplifier:0,duration:3600,show_particles:false}]}}},sell:{id:"minecraft:emerald",count:4}}

# Buy Farmer's Tonic - pays 4 emeralds
data modify entity @s Offers.Recipes append value {tier:1,max_uses:16,xp:5,uses:0,priceMultiplier:0.0f,specialPrice:0,demand:0,rewardExp:1b,buy:{id:"minecraft:potion",count:1,components:{"minecraft:custom_name":{text:"Farmer's Tonic",color:"green",italic:true},"minecraft:potion_contents":{potion:"minecraft:thick",custom_color:16733525,custom_effects:[{id:"minecraft:saturation",amplifier:0,duration:100,show_particles:true}]}}},sell:{id:"minecraft:emerald",count:4}}

# Buy Warrior's Draft - pays 4 emeralds
data modify entity @s Offers.Recipes append value {tier:1,max_uses:16,xp:5,uses:0,priceMultiplier:0.0f,specialPrice:0,demand:0,rewardExp:1b,buy:{id:"minecraft:potion",count:1,components:{"minecraft:custom_name":{text:"Warrior's Draft",color:"red",italic:true},"minecraft:potion_contents":{potion:"minecraft:thick",custom_color:9643043,custom_effects:[{id:"minecraft:strength",amplifier:0,duration:3600,show_particles:true}]}}},sell:{id:"minecraft:emerald",count:4}}

# Buy Spelunker's Brew - pays 4 emeralds
data modify entity @s Offers.Recipes append value {tier:1,max_uses:16,xp:5,uses:0,priceMultiplier:0.0f,specialPrice:0,demand:0,rewardExp:1b,buy:{id:"minecraft:potion",count:1,components:{"minecraft:custom_name":{text:"Spelunker's Brew",color:"yellow",italic:true},"minecraft:potion_contents":{potion:"minecraft:thick",custom_color:16777045,custom_effects:[{id:"minecraft:night_vision",amplifier:0,duration:3600,show_particles:false}]}}},sell:{id:"minecraft:emerald",count:4}}

# Buy Potion of Gills - pays 4 emeralds
data modify entity @s Offers.Recipes append value {tier:1,max_uses:16,xp:5,uses:0,priceMultiplier:0.0f,specialPrice:0,demand:0,rewardExp:1b,buy:{id:"minecraft:potion",count:1,components:{"minecraft:custom_name":{text:"Potion of Gills",color:"aqua",italic:true},"minecraft:potion_contents":{potion:"minecraft:thick",custom_color:3847130,custom_effects:[{id:"minecraft:water_breathing",amplifier:0,duration:3600,show_particles:true}]}}},sell:{id:"minecraft:emerald",count:4}}

# ===== JOURNEYMAN TRADES (Level 3) - Buy/Sell Rare Lingering Potions =====
# Buy Treasure Seeker (lingering) - pays 8 emeralds
data modify entity @s Offers.Recipes append value {tier:2,max_uses:12,xp:10,uses:0,priceMultiplier:0.0f,specialPrice:0,demand:0,rewardExp:1b,buy:{id:"minecraft:lingering_potion",count:1,components:{"minecraft:custom_name":{text:"Treasure Seeker",color:"gold",italic:true},"minecraft:potion_contents":{potion:"minecraft:thick",custom_color:16766720,custom_effects:[{id:"minecraft:luck",amplifier:0,duration:3600,show_particles:true},{id:"minecraft:speed",amplifier:0,duration:3600,show_particles:true}]}}},sell:{id:"minecraft:emerald",count:8}}

# Buy Growth Serum (lingering) - pays 8 emeralds
data modify entity @s Offers.Recipes append value {tier:2,max_uses:12,xp:10,uses:0,priceMultiplier:0.0f,specialPrice:0,demand:0,rewardExp:1b,buy:{id:"minecraft:lingering_potion",count:1,components:{"minecraft:custom_name":{text:"Growth Serum",color:"dark_green",italic:true},"minecraft:potion_contents":{potion:"minecraft:thick",custom_color:5635925,custom_effects:[{id:"minecraft:instant_health",amplifier:0,duration:1,show_particles:true}]}}},sell:{id:"minecraft:emerald",count:8}}

# Buy Hunter's Focus (lingering) - pays 8 emeralds
data modify entity @s Offers.Recipes append value {tier:2,max_uses:12,xp:10,uses:0,priceMultiplier:0.0f,specialPrice:0,demand:0,rewardExp:1b,buy:{id:"minecraft:lingering_potion",count:1,components:{"minecraft:custom_name":{text:"Hunter's Focus",color:"dark_red",italic:true},"minecraft:potion_contents":{potion:"minecraft:thick",custom_color:8339378,custom_effects:[{id:"minecraft:strength",amplifier:0,duration:3600,show_particles:true},{id:"minecraft:speed",amplifier:0,duration:3600,show_particles:true}]}}},sell:{id:"minecraft:emerald",count:8}}

# Buy Miner's Might (lingering) - pays 8 emeralds
data modify entity @s Offers.Recipes append value {tier:2,max_uses:12,xp:10,uses:0,priceMultiplier:0.0f,specialPrice:0,demand:0,rewardExp:1b,buy:{id:"minecraft:lingering_potion",count:1,components:{"minecraft:custom_name":{text:"Miner's Might",color:"gold",italic:true},"minecraft:potion_contents":{potion:"minecraft:thick",custom_color:14329120,custom_effects:[{id:"minecraft:haste",amplifier:0,duration:3600,show_particles:true}]}}},sell:{id:"minecraft:emerald",count:8}}

# Buy Potion of the Angler (lingering) - pays 8 emeralds
data modify entity @s Offers.Recipes append value {tier:2,max_uses:12,xp:10,uses:0,priceMultiplier:0.0f,specialPrice:0,demand:0,rewardExp:1b,buy:{id:"minecraft:lingering_potion",count:1,components:{"minecraft:custom_name":{text:"Potion of the Angler",color:"dark_aqua",italic:true},"minecraft:potion_contents":{potion:"minecraft:thick",custom_color:65535,custom_effects:[{id:"minecraft:luck",amplifier:0,duration:3600,show_particles:true}]}}},sell:{id:"minecraft:emerald",count:8}}

# Sell Treasure Seeker (lingering) - 4 emerald blocks
data modify entity @s Offers.Recipes append value {tier:2,max_uses:12,xp:10,uses:0,priceMultiplier:0.0f,specialPrice:0,demand:0,rewardExp:1b,buy:{id:"minecraft:emerald_block",count:4},sell:{id:"minecraft:lingering_potion",count:1,components:{"minecraft:potion_contents":{potion:"minecraft:thick",custom_color:16766720,custom_effects:[{id:"minecraft:luck",amplifier:0,duration:3600,show_particles:true},{id:"minecraft:speed",amplifier:0,duration:3600,show_particles:true}]},"minecraft:custom_name":{text:"Treasure Seeker",color:"gold",italic:true},"minecraft:lore":[{text:"Rare",color:"aqua",italic:false},{text:""},{text:"Dream Rate I, Speed I (3:00)",color:"blue",italic:false},{text:"Fortune favors the swift",color:"gray",italic:true}],"minecraft:max_stack_size":16}}}

# Sell Growth Serum (lingering) - 4 emerald blocks
data modify entity @s Offers.Recipes append value {tier:2,max_uses:12,xp:10,uses:0,priceMultiplier:0.0f,specialPrice:0,demand:0,rewardExp:1b,buy:{id:"minecraft:emerald_block",count:4},sell:{id:"minecraft:lingering_potion",count:1,components:{"minecraft:potion_contents":{potion:"minecraft:thick",custom_color:5635925,custom_effects:[{id:"minecraft:instant_health",amplifier:0,duration:1,show_particles:true}]},"minecraft:custom_name":{text:"Growth Serum",color:"dark_green",italic:true},"minecraft:lore":[{text:"Rare",color:"aqua",italic:false},{text:""},{text:"Grows crops +3 stages in area",color:"blue",italic:false},{text:"Throw on crops to accelerate growth",color:"gray",italic:true}],"minecraft:max_stack_size":16}}}

# Sell Hunter's Focus (lingering) - 4 emerald blocks
data modify entity @s Offers.Recipes append value {tier:2,max_uses:12,xp:10,uses:0,priceMultiplier:0.0f,specialPrice:0,demand:0,rewardExp:1b,buy:{id:"minecraft:emerald_block",count:4},sell:{id:"minecraft:lingering_potion",count:1,components:{"minecraft:potion_contents":{potion:"minecraft:thick",custom_color:8339378,custom_effects:[{id:"minecraft:strength",amplifier:0,duration:3600,show_particles:true},{id:"minecraft:speed",amplifier:0,duration:3600,show_particles:true}]},"minecraft:custom_name":{text:"Hunter's Focus",color:"dark_red",italic:true},"minecraft:lore":[{text:"Rare",color:"aqua",italic:false},{text:""},{text:"Strength I, Speed I (3:00)",color:"blue",italic:false},{text:"Track. Chase. Strike.",color:"gray",italic:true}],"minecraft:max_stack_size":16}}}

# Sell Miner's Might (lingering) - 4 emerald blocks
data modify entity @s Offers.Recipes append value {tier:2,max_uses:12,xp:10,uses:0,priceMultiplier:0.0f,specialPrice:0,demand:0,rewardExp:1b,buy:{id:"minecraft:emerald_block",count:4},sell:{id:"minecraft:lingering_potion",count:1,components:{"minecraft:potion_contents":{potion:"minecraft:thick",custom_color:14329120,custom_effects:[{id:"minecraft:haste",amplifier:0,duration:3600,show_particles:true}]},"minecraft:custom_name":{text:"Miner's Might",color:"gold",italic:true},"minecraft:lore":[{text:"Rare",color:"aqua",italic:false},{text:""},{text:"Haste I (3:00)",color:"blue",italic:false},{text:"Swing faster, mine harder",color:"gray",italic:true}],"minecraft:max_stack_size":16}}}

# Sell Potion of the Angler (lingering) - 4 emerald blocks
data modify entity @s Offers.Recipes append value {tier:2,max_uses:12,xp:10,uses:0,priceMultiplier:0.0f,specialPrice:0,demand:0,rewardExp:1b,buy:{id:"minecraft:emerald_block",count:4},sell:{id:"minecraft:lingering_potion",count:1,components:{"minecraft:potion_contents":{potion:"minecraft:thick",custom_color:65535,custom_effects:[{id:"minecraft:luck",amplifier:0,duration:3600,show_particles:true}]},"minecraft:custom_name":{text:"Potion of the Angler",color:"dark_aqua",italic:true},"minecraft:lore":[{text:"Rare",color:"aqua",italic:false},{text:""},{text:"+1 Luck of the Sea, +1 Lure (3:00)",color:"blue",italic:false},{text:"Fish are drawn to you",color:"gray",italic:true}],"minecraft:max_stack_size":16}}}

# ===== EXPERT TRADES (Level 4) - Exquisite Nectar + Exquisite Potions =====
# Sell Exquisite Nectar (food item) - 8 emerald blocks
data modify entity @s Offers.Recipes append value {tier:3,max_uses:8,xp:15,uses:0,priceMultiplier:0.0f,specialPrice:0,demand:0,rewardExp:1b,buy:{id:"minecraft:emerald_block",count:8},sell:{id:"minecraft:honey_bottle",count:1,components:{"minecraft:custom_name":{text:"Exquisite Nectar",color:"light_purple",italic:true},"minecraft:lore":[{text:""},{text:"An ancient essence of pure vitality",color:"gray",italic:false},{text:""},{text:"Completely restores hunger and grants",color:"dark_green",italic:false},{text:"10 hearts of absorption",color:"gold",italic:false}],"minecraft:custom_data":{exquisite_nectar:true},"minecraft:food":{nutrition:20,saturation:20,can_always_eat:true},"minecraft:consumable":{consume_seconds:1.6f,animation:"drink",sound:"minecraft:entity.generic.drink",has_consume_particles:true,on_consume_effects:[{type:"minecraft:apply_effects",effects:[{id:"minecraft:absorption",amplifier:3,duration:2400},{id:"minecraft:regeneration",amplifier:1,duration:200}]}]},"minecraft:rarity":"epic","minecraft:enchantment_glint_override":true,"minecraft:max_stack_size":16}}}

# Sell Plunderer's Fortune - 16 emerald blocks
data modify entity @s Offers.Recipes append value {tier:3,max_uses:8,xp:15,uses:0,priceMultiplier:0.0f,specialPrice:0,demand:0,rewardExp:1b,buy:{id:"minecraft:emerald_block",count:16},sell:{id:"minecraft:potion",count:1,components:{"minecraft:potion_contents":{potion:"minecraft:thick",custom_color:16755200,custom_effects:[{id:"minecraft:luck",amplifier:1,duration:6000,show_particles:true},{id:"minecraft:hero_of_the_village",amplifier:0,duration:6000,show_particles:true}]},"minecraft:custom_name":"Plunderer's Fortune","minecraft:lore":[{text:"Exquisite",color:"light_purple",italic:false},{text:""},{text:"Dream Rate II, +1 Looting (5:00)",color:"blue",italic:false},{text:"Riches call to those who seek",color:"gray",italic:true}],"minecraft:max_stack_size":16}}}

# Sell Verdant Blessing - 16 emerald blocks
data modify entity @s Offers.Recipes append value {tier:3,max_uses:8,xp:15,uses:0,priceMultiplier:0.0f,specialPrice:0,demand:0,rewardExp:1b,buy:{id:"minecraft:emerald_block",count:16},sell:{id:"minecraft:potion",count:1,components:{"minecraft:potion_contents":{potion:"minecraft:thick",custom_color:65280,custom_effects:[{id:"minecraft:regeneration",amplifier:0,duration:6000,show_particles:true},{id:"minecraft:luck",amplifier:0,duration:6000,show_particles:true}]},"minecraft:custom_name":"Verdant Blessing","minecraft:lore":[{text:"Exquisite",color:"light_purple",italic:false},{text:""},{text:"+100% Crop Growth radius, Regen I (5:00)",color:"blue",italic:false},{text:"The earth itself blesses you",color:"gray",italic:true}],"minecraft:max_stack_size":16}}}

# Sell Slayer's Elixir - 16 emerald blocks
data modify entity @s Offers.Recipes append value {tier:3,max_uses:8,xp:15,uses:0,priceMultiplier:0.0f,specialPrice:0,demand:0,rewardExp:1b,buy:{id:"minecraft:emerald_block",count:16},sell:{id:"minecraft:potion",count:1,components:{"minecraft:potion_contents":{potion:"minecraft:thick",custom_color:11141120,custom_effects:[{id:"minecraft:strength",amplifier:1,duration:6000,show_particles:true},{id:"minecraft:luck",amplifier:0,duration:6000,show_particles:true}]},"minecraft:custom_name":"Slayer's Elixir","minecraft:lore":[{text:"Exquisite",color:"light_purple",italic:false},{text:""},{text:"Strength II, +1 Looting (5:00)",color:"blue",italic:false},{text:"Blood calls to blood",color:"gray",italic:true}],"minecraft:max_stack_size":16}}}

# Sell Deepslate Elixir - 16 emerald blocks
data modify entity @s Offers.Recipes append value {tier:3,max_uses:8,xp:15,uses:0,priceMultiplier:0.0f,specialPrice:0,demand:0,rewardExp:1b,buy:{id:"minecraft:emerald_block",count:16},sell:{id:"minecraft:potion",count:1,components:{"minecraft:potion_contents":{potion:"minecraft:thick",custom_color:4802889,custom_effects:[{id:"minecraft:haste",amplifier:1,duration:6000,show_particles:true},{id:"minecraft:fire_resistance",amplifier:0,duration:6000,show_particles:true}]},"minecraft:custom_name":"Deepslate Elixir","minecraft:lore":[{text:"Exquisite",color:"light_purple",italic:false},{text:""},{text:"Haste II, Fire Resistance (5:00)",color:"blue",italic:false},{text:"Forged in the deepest depths",color:"gray",italic:true}],"minecraft:max_stack_size":16}}}

# Sell Blind Seaman's Brew - 16 emerald blocks
data modify entity @s Offers.Recipes append value {tier:3,max_uses:8,xp:15,uses:0,priceMultiplier:0.0f,specialPrice:0,demand:0,rewardExp:1b,buy:{id:"minecraft:emerald_block",count:16},sell:{id:"minecraft:potion",count:1,components:{"minecraft:potion_contents":{potion:"minecraft:thick",custom_color:1710618,custom_effects:[{id:"minecraft:luck",amplifier:1,duration:6000,show_particles:true},{id:"minecraft:nausea",amplifier:0,duration:200,show_particles:true},{id:"minecraft:blindness",amplifier:0,duration:6000,show_particles:true},{id:"minecraft:darkness",amplifier:0,duration:6000,show_particles:true}]},"minecraft:custom_name":"Blind Seaman's Brew","minecraft:lore":[{text:"Exquisite",color:"light_purple",italic:false},{text:""},{text:"+2 Luck of the Sea, +1 Lure (5:00)",color:"blue",italic:false},{text:"Nausea (10s), Blindness & Darkness (5:00)",color:"red",italic:false},{text:"I don't need to see to feel the tug.",color:"gray",italic:true}],"minecraft:max_stack_size":16}}}

# ===== MASTER TRADES (Level 5) - Sell Potion of Dreams VI =====
# Sell Potion of Dreams VI (Mythical)
data modify entity @s Offers.Recipes append value {tier:4,max_uses:4,xp:25,uses:0,priceMultiplier:0.0f,specialPrice:0,demand:0,rewardExp:1b,buy:{id:"minecraft:emerald_block",count:32},sell:{id:"minecraft:potion",count:1,components:{"minecraft:potion_contents":{potion:"minecraft:thick",custom_color:9175297,custom_effects:[{id:"minecraft:luck",amplifier:5,duration:8400,show_particles:true}]},"minecraft:custom_name":"Potion of Dreams","minecraft:lore":[{text:"Mythical",color:"gold",italic:false},{text:""},{text:"+6 Dream Rate for 7 minutes",color:"green",italic:false},{text:"Increases items found in chests",color:"gray",italic:false},{text:""},{text:"A dream made real...",color:"dark_purple",italic:true}],"minecraft:max_stack_size":16}}}

# ===== MASTER TRADES - Dream Ingredient Trades (1 use each → Potion of Dreams) =====
# Buy Crystal of Dreams → Sell Mythical Potion of Dreams (+6 Dream Rate, 7min)
data modify entity @s Offers.Recipes append value {tier:4,max_uses:1,xp:30,uses:0,priceMultiplier:0.0f,specialPrice:0,demand:0,rewardExp:1b,buy:{id:"minecraft:amethyst_shard",count:1,components:{"minecraft:custom_name":{text:"Crystal of Dreams",color:"light_purple",italic:true},"minecraft:enchantment_glint_override":true,"minecraft:custom_data":{crystal_of_dreams:true}}},sell:{id:"minecraft:potion",count:1,components:{"minecraft:potion_contents":{potion:"minecraft:thick",custom_color:9175297,custom_effects:[{id:"minecraft:luck",amplifier:5,duration:8400,show_particles:true}]},"minecraft:custom_name":{text:"Potion of Dreams",color:"light_purple",italic:true},"minecraft:lore":[{text:"Mythical",color:"gold",italic:false},{text:""},{text:"+6 Dream Rate for 7 minutes",color:"green",italic:false},{text:"Increases items found in chests",color:"gray",italic:false},{text:""},{text:"A dream made real...",color:"dark_purple",italic:true}],"minecraft:max_stack_size":16}}}

# Rabbit's Dreaming Foot → moved to Zookeeper
# Dream Inducing Mushroom → moved to Retired Adventurer
# Crystalized Dream Droppings → moved to Hunter

# Buy Chorus Dreaming Fruit → Sell Mythical Potion of Dreams (+6 Dream Rate, 7min)
data modify entity @s Offers.Recipes append value {tier:4,max_uses:1,xp:30,uses:0,priceMultiplier:0.0f,specialPrice:0,demand:0,rewardExp:1b,buy:{id:"minecraft:popped_chorus_fruit",count:1,components:{"minecraft:custom_name":{text:"Chorus Dreaming Fruit",color:"light_purple",italic:false},"minecraft:enchantment_glint_override":true,"minecraft:custom_data":{chorus_dreaming_fruit:true}}},sell:{id:"minecraft:potion",count:1,components:{"minecraft:potion_contents":{potion:"minecraft:thick",custom_color:9175297,custom_effects:[{id:"minecraft:luck",amplifier:5,duration:8400,show_particles:true}]},"minecraft:custom_name":{text:"Potion of Dreams",color:"light_purple",italic:true},"minecraft:lore":[{text:"Mythical",color:"gold",italic:false},{text:""},{text:"+6 Dream Rate for 7 minutes",color:"green",italic:false},{text:"Increases items found in chests",color:"gray",italic:false},{text:""},{text:"A dream made real...",color:"dark_purple",italic:true}],"minecraft:max_stack_size":16}}}

# Patron's Dream Essence → moved to Hunter

# Dreamer's Quill → moved to Nymph

# Dreamweaver's Thread → moved to Nymph

# Tome of Lucid Visions → moved to Retired Adventurer

# Astral Codex Page → moved to Explorer

# Fisherman's Dozing Lure → moved to Technician

# Miner's Slumbering Geode → moved to Miner

# Harvester's Dreamy Seed → moved to Beekeeper

# Blacksmith's Dreaming Ember → moved to Technician

# Wanderer's Dream Map → moved to Explorer

# Prospector's Dream Ore → moved to Miner

# Collector's Dream Relic → moved to Zookeeper

# Tiller's Dream Petal → moved to Beekeeper
