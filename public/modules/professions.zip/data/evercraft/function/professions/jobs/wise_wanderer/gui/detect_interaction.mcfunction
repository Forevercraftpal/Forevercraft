# Wise Wanderer — Detect Right-Click on Villager
# Runs every 1s via schedule. Uses talked_to_villager stat to detect clicks.
# We remove+re-add the objective each cycle to reset the counter cleanly.

# Gate: skip the whole detector if no players online (still re-schedules)
execute unless entity @a run return run schedule function evercraft:professions/jobs/wise_wanderer/gui/detect_interaction 1s replace

schedule function evercraft:professions/jobs/wise_wanderer/gui/detect_interaction 1s replace

# Safety: if a player has WW.InMenu but no anchor exists, force-remove the tag
execute as @a[tag=WW.InMenu] at @s unless entity @e[type=minecraft:marker,tag=WW.MenuAnchor,distance=..10] run tag @s remove WW.InMenu

# Detect right-click: any player whose talked stat is 1+ AND nearest villager IS a Wise Wanderer.
# Owner-scoped (MP fix #47-W2): the tag→check→clear runs inside ONE per-player iteration via
# check_nearest, so only the iterating player's own nearest villager is ever WW.NearestCheck-tagged
# at a time (serial-within-tick) — two players talking the same 1s cycle can no longer cross-fire.
execute as @a[scores={ec.ww_talked=1..},tag=!WW.InMenu] at @s run function evercraft:professions/jobs/wise_wanderer/gui/check_nearest

# Reset the stat by removing and re-adding the objective (resets all players to 0)
scoreboard objectives remove ec.ww_talked
scoreboard objectives add ec.ww_talked minecraft.custom:minecraft.talked_to_villager

# Per-tick maintenance for open GUIs
execute as @a[tag=WW.InMenu] at @s run function evercraft:professions/jobs/wise_wanderer/gui/tick
