# Wise Wanderer — Buy Rare Crate (50 XP levels)
execute store result score #ww_xp adv.temp run experience query @s levels
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"Not enough XP! Need 50 levels.",color:"red"},{text:" ✦",color:"gold"}]
scoreboard players set #ndur ec.temp 45
execute unless score #ww_xp adv.temp matches 50.. as @s run return run function evercraft:util/notify/emit
execute as @s store result score #inv_full ec.var run function evercraft:util/check_inv_full
experience add @s -50 levels
execute if score #inv_full ec.var matches 0 run loot give @s loot evercraft:professions/wise_wanderer/crates/rare_crate
execute if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:professions/wise_wanderer/crates/rare_crate
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.experience_orb.pickup master @s ~ ~ ~ 1 1.2
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"Purchased ",color:"gray"},{text:"Rare Crate",color:"aqua"},{text:" for 50 levels!",color:"gray"},{text:" ✦",color:"gold"}]
scoreboard players set #ndur ec.temp 45
execute as @s run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Inventory full! Your crate was dropped at your feet.",color:"yellow"}]
scoreboard players set #ndur ec.temp 45
execute if score #inv_full ec.var matches 1 as @s run function evercraft:util/notify/emit
execute if score #inv_full ec.var matches 1 if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 1 0.5
