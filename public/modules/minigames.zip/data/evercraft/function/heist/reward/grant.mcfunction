# Black Market Heist — Grant Rewards
# Gives guaranteed Contraband Crate + 2-3 bonus gacha-style rolls

# === GUARANTEED: CONTRABAND CRATE ===
# Inv-full guard: drop at the player's feet rather than void on a full inventory.
execute store result score #inv_full ec.var run function evercraft:util/check_inv_full
execute if score #inv_full ec.var matches 0 run loot give @s loot evercraft:heist/contraband_crate
execute if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:heist/contraband_crate

data modify storage evercraft:notify stage.c set value [{text:"\u2726 ",color:"dark_red"},{text:"Contraband Crate",color:"red",bold:true},{text:" obtained!",color:"gray"},{text:" \u2726",color:"dark_red"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit

# === COIN REWARD ===
function evercraft:coins/heist_reward

# === BONUS ROLLS (2-3 random gacha items) ===
execute store result score #heist_bonus_count ec.temp run random value 2..3
function evercraft:heist/reward/roll_bonus
