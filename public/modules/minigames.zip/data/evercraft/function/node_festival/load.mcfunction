# =====================================================================
# Seasonal Node Festival — Load / scoreboard registration (Wave 3c)
# =====================================================================
# THE CAPSTONE of Wave 3: a recurring, multi-day festival that celebrates the 5
# Craft-Affinity nodes (1=lm Lamentor / 2=lf Lumberfell / 3=tw Terrawarp / 4=sc
# Sirencall / 5=gw Gearwright). One featured node per day (default rotation
# lm->lf->tw->sc->gw over 5 days). During the festival the featured node's daily
# COMPETITION (Track A, Wave 3a) and CO-OP EVENT (Track B, Wave 3b) are PINNED to
# fire that day (bypassing their normal cadence/lockout), and both pay a festival
# BONUS. Players who take part across enough days earn a special capstone reward.
#
# ORCHESTRATION ONLY: the festival does NOT fork the competition / co-op / Director
# logic. It runs its day rollover from luck_buffs/dawn_dispatch (node_festival/dawn,
# BEFORE the Track A/B decisions) and claims calendar slot id 9 (Track B / ambient) only
# as a "slot occupied" marker. It reaches into the two dawn decisions + the two reward
# layers with SMALL, clearly-commented hooks that are inert when #nfest_active=0.
# Everything else stays as-is.
#
# ONE-WRITER LAW: every register below is written by exactly one node_festival/* fn
# (noted inline).
# ---------------------------------------------------------------------

# --- Global festival state (fake-player scores on ec.var; preserved across /reload). ---
# #nfest_active  1 while the festival is running. Writers: start (1) + end (0).
# #nfest_day     current festival day 1..N. Writers: start (set 1) + advance_day (+1).
# #nfest_node    today's featured node id 1..5. Writers: start + advance_day.
# #nfest_dur     total festival length in days (default 5). Writer: start. (Read by
#                advance_day to know when the festival is over.)
execute unless score #nfest_active ec.var matches 0.. run scoreboard players set #nfest_active ec.var 0
execute unless score #nfest_day ec.var matches 0.. run scoreboard players set #nfest_day ec.var 0
execute unless score #nfest_node ec.var matches 0.. run scoreboard players set #nfest_node ec.var 0
execute unless score #nfest_dur ec.var matches 0.. run scoreboard players set #nfest_dur ec.var 5

# --- Recurrence guard: the day-index the festival last STARTED, so maybe_start can't
# re-fire it twice in the same season window. Writer: start. ---
execute unless score #nfest_last_day ec.var matches -2147483648.. run scoreboard players set #nfest_last_day ec.var -99

# --- Festival pin choice (2026-06-06): set once/day in node_festival/dawn (1=comp, 2=co-op) so
# the festival pins exactly ONE sub-event. Writer: node_festival/dawn. Default 0 (inert). ---
execute unless score #nfest_pin ec.var matches 0.. run scoreboard players set #nfest_pin ec.var 0

# --- Bossbar visibility cycle (Joseph 2026-06-12): 1 min visible / 15 min hidden, looping.
# Phase counter in seconds (0..960). Writer: node_festival/tick. Reset to 0 by start. ---
execute unless score #nfest_bar_phase ec.var matches 0.. run scoreboard players set #nfest_bar_phase ec.var 0

# --- Per-player festival participation. ---
# ec.nfest_days   count of festival DAYS this player participated in (>=1 node-action on
#                 the featured node that day). The capstone gate reads this. Writers:
#                 advance_day + end (the day-rollover tally) + start (reset to 0 at the
#                 festival's first dawn). Reset on wipe in strip_player_zero.
# ec.nfest_today  1 if the player has already been counted for TODAY (debounce within a
#                 day). Writers: mark_participation (set 1) + the day-rollover (reset 0).
# ec.nfest_base   per-player featured-node count snapshot at the festival day's dawn;
#                 the tick compares the live count against it to detect participation.
#                 Writers: start + advance_day (snapshot) + on_join (mid-day join).
scoreboard objectives add ec.nfest_days dummy "Festival Days Participated"
scoreboard objectives add ec.nfest_today dummy "Festival Participated Today"
scoreboard objectives add ec.nfest_base dummy "Festival Node Baseline"

# --- Festival banner bossbar (purple; shows the day's featured node). Hidden until live. ---
bossbar add evercraft:node_festival {"text":"Node Festival","color":"light_purple"}
bossbar set evercraft:node_festival visible false
bossbar set evercraft:node_festival color purple
bossbar set evercraft:node_festival style notched_6
bossbar set evercraft:node_festival players @a

# --- Stale-state on /reload: if a reload lands mid-festival, re-show the banner + re-arm
# the participation tick. ---
execute if score #nfest_active ec.var matches 1 run bossbar set evercraft:node_festival visible true
execute if score #nfest_active ec.var matches 1 run bossbar set evercraft:node_festival players @a
execute if score #nfest_active ec.var matches 1 run schedule function evercraft:bossbar/autodismiss/clear/node_festival 30s replace

# --- Start the 1s participation tick (existence/active-gated inside tick). replace so a
# reload doesn't stack schedules. ---
schedule function evercraft:node_festival/tick 20s replace
