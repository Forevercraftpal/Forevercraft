# Seasonal Node Festival — Daily featured-node banner (per festival day).
# Sets the festival bossbar name to today's node + a centered title. Bossbar name may be
# bold (it is a bossbar, not a center title/subtitle/notify popup). Center popups NOT bold.

# Bossbar name + value (day N of #nfest_dur shown via the notched-6 segments).
execute if score #nfest_node ec.var matches 1 run bossbar set evercraft:node_festival name [{text:"Node Festival: ",color:"light_purple",bold:true},{text:"Lamentor's Day (shearing)",color:"yellow"}]
execute if score #nfest_node ec.var matches 2 run bossbar set evercraft:node_festival name [{text:"Node Festival: ",color:"light_purple",bold:true},{text:"Lumberfell's Day (felling)",color:"yellow"}]
execute if score #nfest_node ec.var matches 3 run bossbar set evercraft:node_festival name [{text:"Node Festival: ",color:"light_purple",bold:true},{text:"Terrawarp's Day (digging)",color:"yellow"}]
execute if score #nfest_node ec.var matches 4 run bossbar set evercraft:node_festival name [{text:"Node Festival: ",color:"light_purple",bold:true},{text:"Sirencall's Day (fishing)",color:"yellow"}]
execute if score #nfest_node ec.var matches 5 run bossbar set evercraft:node_festival name [{text:"Node Festival: ",color:"light_purple",bold:true},{text:"Gearwright's Day (tinkering)",color:"yellow"}]
# Bossbar fill = festival day progress (max = duration, value = current day).
execute store result bossbar evercraft:node_festival max run scoreboard players get #nfest_dur ec.var
execute store result bossbar evercraft:node_festival value run scoreboard players get #nfest_day ec.var
bossbar set evercraft:node_festival visible true
bossbar set evercraft:node_festival players @a
# Auto-dismiss the festival banner from the HUD after 30s (re-armed on each show).
schedule function evercraft:bossbar/autodismiss/clear/node_festival 30s replace

# Centered daily title (non-bold).
title @a times 10 60 20
execute if score #nfest_node ec.var matches 1 run title @a title {text:"Lamentor's Day",color:"light_purple"}
execute if score #nfest_node ec.var matches 2 run title @a title {text:"Lumberfell's Day",color:"light_purple"}
execute if score #nfest_node ec.var matches 3 run title @a title {text:"Terrawarp's Day",color:"light_purple"}
execute if score #nfest_node ec.var matches 4 run title @a title {text:"Sirencall's Day",color:"light_purple"}
execute if score #nfest_node ec.var matches 5 run title @a title {text:"Gearwright's Day",color:"light_purple"}
title @a subtitle {text:"Today's contest and realm effort are guaranteed — with bonus rewards!",color:"yellow"}

# Daily notify line (the verb to rally around).
execute if score #nfest_node ec.var matches 1 run data modify storage evercraft:notify stage.c set value [{text:"Festival Day — Lamentor: shear for bonus rewards!",color:"light_purple"}]
execute if score #nfest_node ec.var matches 2 run data modify storage evercraft:notify stage.c set value [{text:"Festival Day — Lumberfell: fell trees for bonus rewards!",color:"light_purple"}]
execute if score #nfest_node ec.var matches 3 run data modify storage evercraft:notify stage.c set value [{text:"Festival Day — Terrawarp: excavate for bonus rewards!",color:"light_purple"}]
execute if score #nfest_node ec.var matches 4 run data modify storage evercraft:notify stage.c set value [{text:"Festival Day — Sirencall: fish for bonus rewards!",color:"light_purple"}]
execute if score #nfest_node ec.var matches 5 run data modify storage evercraft:notify stage.c set value [{text:"Festival Day — Gearwright: tinker for bonus rewards!",color:"light_purple"}]
scoreboard players set #ndur ec.temp 50
execute as @a run function evercraft:util/notify/emit

execute as @a at @s if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.6 1.2
