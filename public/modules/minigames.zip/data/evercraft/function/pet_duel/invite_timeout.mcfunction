# Pet Duel invite expired
# Run as the target player whose invite timed out

tag @s remove pd.pending_target
scoreboard players set @s ec.pd_inv 0

data modify storage evercraft:notify stage.c set value [{text:"Challenge expired.",color:"gray"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit

# Notify challenger
data modify storage evercraft:notify stage.c set value [{text:"Your challenge expired.",color:"gray"}]
scoreboard players set #ndur ec.temp 45
execute as @a[tag=companion.activepet,scores={ec.pd_inv=1}] run function evercraft:util/notify/emit
execute as @a[tag=companion.activepet,scores={ec.pd_inv=1}] run scoreboard players set @s ec.pd_inv 0
