# Pet Duel — Role Dispatch (D9: role rock-paper-scissors)
# Reads the snapshotted signature for ONE side into the shared companion_combat slot, then
# macro-keys the species -> a ROLE code in #pd_role ec.var (1=Striker, 2=Guardian, 3=Controller).
# Role = the ability's DOMINANT horn-primitive family (NOT a re-run of the live ability):
#   Striker  = strike/smite/chain/burn/freeze-brand/lifesteal/rally/knock/wither offense
#   Guardian = ward/absorption/thorns/heal/regen/cleanse defense
#   Controller = slow/blind/fear/weaken/stealth/blink control
# Triangle (resolved in active/tick): Striker > Controller > Guardian > Striker.
# Run with the per-side signature already in storage evercraft:companion_combat companion_name
# (set by init_pet_stats from the duelist.<side>.sig snapshot). Mirrors get_tier_stats' shape.
#
# DEFAULT = Striker (1). A tier-keyed fallback in init_pet_stats covers un-rostered species before
# this table is consulted; this table overrides for every authored companion.
scoreboard players set #pd_role ec.var 1

# === STRIKER (36) ===
execute if data storage evercraft:companion_combat {companion_name:"alien"} run scoreboard players set #pd_role ec.var 1
execute if data storage evercraft:companion_combat {companion_name:"allay"} run scoreboard players set #pd_role ec.var 1
execute if data storage evercraft:companion_combat {companion_name:"ashborn"} run scoreboard players set #pd_role ec.var 1
execute if data storage evercraft:companion_combat {companion_name:"blaze"} run scoreboard players set #pd_role ec.var 1
execute if data storage evercraft:companion_combat {companion_name:"breeze"} run scoreboard players set #pd_role ec.var 1
execute if data storage evercraft:companion_combat {companion_name:"camel"} run scoreboard players set #pd_role ec.var 1
execute if data storage evercraft:companion_combat {companion_name:"chick"} run scoreboard players set #pd_role ec.var 1
execute if data storage evercraft:companion_combat {companion_name:"cindershell"} run scoreboard players set #pd_role ec.var 1
execute if data storage evercraft:companion_combat {companion_name:"claude"} run scoreboard players set #pd_role ec.var 1
execute if data storage evercraft:companion_combat {companion_name:"cow"} run scoreboard players set #pd_role ec.var 1
execute if data storage evercraft:companion_combat {companion_name:"cragmite"} run scoreboard players set #pd_role ec.var 1
execute if data storage evercraft:companion_combat {companion_name:"creeper"} run scoreboard players set #pd_role ec.var 1
execute if data storage evercraft:companion_combat {companion_name:"evoker"} run scoreboard players set #pd_role ec.var 1
execute if data storage evercraft:companion_combat {companion_name:"frog"} run scoreboard players set #pd_role ec.var 1
execute if data storage evercraft:companion_combat {companion_name:"giraffe"} run scoreboard players set #pd_role ec.var 1
execute if data storage evercraft:companion_combat {companion_name:"glider"} run scoreboard players set #pd_role ec.var 1
execute if data storage evercraft:companion_combat {companion_name:"golden_dragon"} run scoreboard players set #pd_role ec.var 1
execute if data storage evercraft:companion_combat {companion_name:"hoglin"} run scoreboard players set #pd_role ec.var 1
execute if data storage evercraft:companion_combat {companion_name:"leviathan"} run scoreboard players set #pd_role ec.var 1
execute if data storage evercraft:companion_combat {companion_name:"mossy_skeleton"} run scoreboard players set #pd_role ec.var 1
execute if data storage evercraft:companion_combat {companion_name:"mushroom_pet"} run scoreboard players set #pd_role ec.var 1
execute if data storage evercraft:companion_combat {companion_name:"nebula_kit"} run scoreboard players set #pd_role ec.var 1
execute if data storage evercraft:companion_combat {companion_name:"oracle"} run scoreboard players set #pd_role ec.var 1
execute if data storage evercraft:companion_combat {companion_name:"pixie"} run scoreboard players set #pd_role ec.var 1
execute if data storage evercraft:companion_combat {companion_name:"polar_bear"} run scoreboard players set #pd_role ec.var 1
execute if data storage evercraft:companion_combat {companion_name:"prowler"} run scoreboard players set #pd_role ec.var 1
execute if data storage evercraft:companion_combat {companion_name:"ravager"} run scoreboard players set #pd_role ec.var 1
execute if data storage evercraft:companion_combat {companion_name:"regal_tiger"} run scoreboard players set #pd_role ec.var 1
execute if data storage evercraft:companion_combat {companion_name:"sabertooth"} run scoreboard players set #pd_role ec.var 1
execute if data storage evercraft:companion_combat {companion_name:"sentinel"} run scoreboard players set #pd_role ec.var 1
execute if data storage evercraft:companion_combat {companion_name:"sniffer"} run scoreboard players set #pd_role ec.var 1
execute if data storage evercraft:companion_combat {companion_name:"starweaver"} run scoreboard players set #pd_role ec.var 1
execute if data storage evercraft:companion_combat {companion_name:"stormcaller"} run scoreboard players set #pd_role ec.var 1
execute if data storage evercraft:companion_combat {companion_name:"titan"} run scoreboard players set #pd_role ec.var 1
execute if data storage evercraft:companion_combat {companion_name:"wolf_pet"} run scoreboard players set #pd_role ec.var 1
execute if data storage evercraft:companion_combat {companion_name:"zephyr"} run scoreboard players set #pd_role ec.var 1

# === GUARDIAN (33) ===
execute if data storage evercraft:companion_combat {companion_name:"armadillo"} run scoreboard players set #pd_role ec.var 2
execute if data storage evercraft:companion_combat {companion_name:"baby_potato"} run scoreboard players set #pd_role ec.var 2
execute if data storage evercraft:companion_combat {companion_name:"bee"} run scoreboard players set #pd_role ec.var 2
execute if data storage evercraft:companion_combat {companion_name:"bramble"} run scoreboard players set #pd_role ec.var 2
execute if data storage evercraft:companion_combat {companion_name:"bulwark"} run scoreboard players set #pd_role ec.var 2
execute if data storage evercraft:companion_combat {companion_name:"butterfly"} run scoreboard players set #pd_role ec.var 2
execute if data storage evercraft:companion_combat {companion_name:"copper_golem"} run scoreboard players set #pd_role ec.var 2
execute if data storage evercraft:companion_combat {companion_name:"cow_of_eden"} run scoreboard players set #pd_role ec.var 2
execute if data storage evercraft:companion_combat {companion_name:"crystalheart"} run scoreboard players set #pd_role ec.var 2
execute if data storage evercraft:companion_combat {companion_name:"emberheart"} run scoreboard players set #pd_role ec.var 2
execute if data storage evercraft:companion_combat {companion_name:"ender_dragon"} run scoreboard players set #pd_role ec.var 2
execute if data storage evercraft:companion_combat {companion_name:"endwalker"} run scoreboard players set #pd_role ec.var 2
execute if data storage evercraft:companion_combat {companion_name:"frozen_zombie"} run scoreboard players set #pd_role ec.var 2
execute if data storage evercraft:companion_combat {companion_name:"goat"} run scoreboard players set #pd_role ec.var 2
execute if data storage evercraft:companion_combat {companion_name:"grovekeeper"} run scoreboard players set #pd_role ec.var 2
execute if data storage evercraft:companion_combat {companion_name:"infernus"} run scoreboard players set #pd_role ec.var 2
execute if data storage evercraft:companion_combat {companion_name:"iron_golem"} run scoreboard players set #pd_role ec.var 2
execute if data storage evercraft:companion_combat {companion_name:"juggernaut"} run scoreboard players set #pd_role ec.var 2
execute if data storage evercraft:companion_combat {companion_name:"knight"} run scoreboard players set #pd_role ec.var 2
execute if data storage evercraft:companion_combat {companion_name:"koala"} run scoreboard players set #pd_role ec.var 2
execute if data storage evercraft:companion_combat {companion_name:"monolith"} run scoreboard players set #pd_role ec.var 2
execute if data storage evercraft:companion_combat {companion_name:"moobloom"} run scoreboard players set #pd_role ec.var 2
execute if data storage evercraft:companion_combat {companion_name:"mooshroom"} run scoreboard players set #pd_role ec.var 2
execute if data storage evercraft:companion_combat {companion_name:"mossy_zombie"} run scoreboard players set #pd_role ec.var 2
execute if data storage evercraft:companion_combat {companion_name:"mule"} run scoreboard players set #pd_role ec.var 2
execute if data storage evercraft:companion_combat {companion_name:"piglin"} run scoreboard players set #pd_role ec.var 2
execute if data storage evercraft:companion_combat {companion_name:"skeleton_horse"} run scoreboard players set #pd_role ec.var 2
execute if data storage evercraft:companion_combat {companion_name:"spirit_wolf"} run scoreboard players set #pd_role ec.var 2
execute if data storage evercraft:companion_combat {companion_name:"sporeblossom"} run scoreboard players set #pd_role ec.var 2
execute if data storage evercraft:companion_combat {companion_name:"strider"} run scoreboard players set #pd_role ec.var 2
execute if data storage evercraft:companion_combat {companion_name:"tidecaller"} run scoreboard players set #pd_role ec.var 2
execute if data storage evercraft:companion_combat {companion_name:"wither"} run scoreboard players set #pd_role ec.var 2
execute if data storage evercraft:companion_combat {companion_name:"wooly_cow"} run scoreboard players set #pd_role ec.var 2

# === CONTROLLER (33) ===
execute if data storage evercraft:companion_combat {companion_name:"abyssal"} run scoreboard players set #pd_role ec.var 3
execute if data storage evercraft:companion_combat {companion_name:"arctic_fox"} run scoreboard players set #pd_role ec.var 3
execute if data storage evercraft:companion_combat {companion_name:"creaking"} run scoreboard players set #pd_role ec.var 3
execute if data storage evercraft:companion_combat {companion_name:"deloris"} run scoreboard players set #pd_role ec.var 3
execute if data storage evercraft:companion_combat {companion_name:"dreamstag"} run scoreboard players set #pd_role ec.var 3
execute if data storage evercraft:companion_combat {companion_name:"duck"} run scoreboard players set #pd_role ec.var 3
execute if data storage evercraft:companion_combat {companion_name:"enderman"} run scoreboard players set #pd_role ec.var 3
execute if data storage evercraft:companion_combat {companion_name:"fox"} run scoreboard players set #pd_role ec.var 3
execute if data storage evercraft:companion_combat {companion_name:"frostweaver"} run scoreboard players set #pd_role ec.var 3
execute if data storage evercraft:companion_combat {companion_name:"grasshopper"} run scoreboard players set #pd_role ec.var 3
execute if data storage evercraft:companion_combat {companion_name:"llama"} run scoreboard players set #pd_role ec.var 3
execute if data storage evercraft:companion_combat {companion_name:"lunar_moth"} run scoreboard players set #pd_role ec.var 3
execute if data storage evercraft:companion_combat {companion_name:"moldwarp"} run scoreboard players set #pd_role ec.var 3
execute if data storage evercraft:companion_combat {companion_name:"monkey"} run scoreboard players set #pd_role ec.var 3
execute if data storage evercraft:companion_combat {companion_name:"naiad"} run scoreboard players set #pd_role ec.var 3
execute if data storage evercraft:companion_combat {companion_name:"ocelot"} run scoreboard players set #pd_role ec.var 3
execute if data storage evercraft:companion_combat {companion_name:"panther"} run scoreboard players set #pd_role ec.var 3
execute if data storage evercraft:companion_combat {companion_name:"pig"} run scoreboard players set #pd_role ec.var 3
execute if data storage evercraft:companion_combat {companion_name:"rascal_pet"} run scoreboard players set #pd_role ec.var 3
execute if data storage evercraft:companion_combat {companion_name:"red_panda"} run scoreboard players set #pd_role ec.var 3
execute if data storage evercraft:companion_combat {companion_name:"shade"} run scoreboard players set #pd_role ec.var 3
execute if data storage evercraft:companion_combat {companion_name:"silverfish"} run scoreboard players set #pd_role ec.var 3
execute if data storage evercraft:companion_combat {companion_name:"snow_fox_spirit"} run scoreboard players set #pd_role ec.var 3
execute if data storage evercraft:companion_combat {companion_name:"snowman"} run scoreboard players set #pd_role ec.var 3
execute if data storage evercraft:companion_combat {companion_name:"somnia"} run scoreboard players set #pd_role ec.var 3
execute if data storage evercraft:companion_combat {companion_name:"squid"} run scoreboard players set #pd_role ec.var 3
execute if data storage evercraft:companion_combat {companion_name:"time_weaver"} run scoreboard players set #pd_role ec.var 3
execute if data storage evercraft:companion_combat {companion_name:"twilight_hare"} run scoreboard players set #pd_role ec.var 3
execute if data storage evercraft:companion_combat {companion_name:"vex"} run scoreboard players set #pd_role ec.var 3
execute if data storage evercraft:companion_combat {companion_name:"void_walker"} run scoreboard players set #pd_role ec.var 3
execute if data storage evercraft:companion_combat {companion_name:"voidshade"} run scoreboard players set #pd_role ec.var 3
execute if data storage evercraft:companion_combat {companion_name:"wraith"} run scoreboard players set #pd_role ec.var 3
execute if data storage evercraft:companion_combat {companion_name:"zoglin"} run scoreboard players set #pd_role ec.var 3
