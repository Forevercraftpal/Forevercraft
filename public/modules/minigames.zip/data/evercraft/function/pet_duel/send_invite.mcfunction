# Send pet duel invitation
# Run as the TARGET player (the one being challenged)
# Challenger has pd.challenger tag

# R5 GLOBAL MUTEX (defense in depth) — an invite issued while another duel runs would accept into
# corrupt shared state. Refuse silently here (the challenger already saw the mutex popup upstream).
execute if score #pd_active ec.var matches 1.. run return 0

# Check: target not in duel/dungeon/dreaming/raid
execute if score @s ec.pd_active matches 1 run return 0
execute if entity @s[tag=dr.in_realm] run return 0
execute if entity @s[tag=ec.duel_active_tag] run return 0

# Store challenger and target IDs for matching
scoreboard players operation @s ec.pd_inv = @a[tag=pd.challenger,limit=1] companion.id
scoreboard players set @s ec.pd_inv_cd 400

# Mark both as having pending invite
tag @s add pd.pending_target

# Send challenge message to target
tellraw @s [{text:"[Pet Duel] ",color:"gold"},{"selector":"@a[tag=pd.challenger,limit=1]",color:"yellow"},{text:"'s companion challenges yours!",color:"gray"}]
tellraw @s [{"text":"  "},{"text":"[Accept \u2713]","color":"green","bold":true,"click_event":{"action":"run_command","command":"/trigger ec.pd set 1"},"hover_event":{"action":"show_text","value":"Accept the pet duel"}},{"text":"  "},{"text":"[Decline \u2717]","color":"red","bold":true,"click_event":{"action":"run_command","command":"/trigger ec.pd set 2"},"hover_event":{"action":"show_text","value":"Decline the challenge"}}]

# Notify challenger
data modify storage evercraft:notify stage.c set value [{text:"Challenge sent! Waiting for response...",color:"gray"}]
scoreboard players set #ndur ec.temp 45
execute as @a[tag=pd.challenger] run function evercraft:util/notify/emit
execute as @a[tag=pd.challenger] run scoreboard players set @s ec.pd_inv 1

# Remove challenger tag (used only for targeting)
tag @a[tag=pd.challenger] remove pd.challenger

# Enable trigger for target
scoreboard players enable @s ec.pd
