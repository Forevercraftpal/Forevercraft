# Pet Duel — Orphan Sweep (#50 W3, mirrors dreaming_realm #49)
# Context: server (no @s — both pet-duelists are offline; that is the whole point).
#
# Safety net for the global #pd_active lock. pet_duel/active/tick is SELF-SCHEDULED (10t), so unlike
# the PvP duel there is no per-tick driver guaranteed by #minecraft:tick — if that schedule chain is
# ever interrupted (the documented blueprints-style "schedule does not survive X" hazard), an all-
# offline pet duel would leave #pd_active=1 forever, blocking every future pet duel server-wide.
# Recovery is normally keyed to a participant reconnecting (reconnect/dispatch:23 -> resolve_draw ->
# cleanup) or the still-running tick's disconnect check (active/tick:46-48). This sweep is the reclaim
# for "neither fires": a grace counter advances in tick.mcfunction whenever #pd_active=1 but NO online
# pd.duelist exists; at ~30s (600t at the 1t main-tick cadence the counter runs on — longer than any
# relogin so reconnect recovery wins for a returning player) it releases the lock + tears down state.
# The counter resets every tick an online pd.duelist exists, so a live duel never trips.

# Reset the grace counter so the next duel starts clean.
scoreboard players set #pd_orphan ec.var 0

# Log the reclaim (ops only — quiet for normal players).
execute as @a[tag=ec.admin] run tellraw @s [{text:"[Pet Duel] ",color:"gold"},{text:"Orphaned pet-duel lock reclaimed — both companions' owners disconnected and none returned within 30s. Pet duels are open again.",color:"gray",italic:true}]

# Full teardown: cleanup clears the duelist effects/scores/tags + the bossbar and resets #pd_active +
# #pd_timer to 0. Its @a[tag=pd.duelist] lines no-op with no online duelist; the global flag reset is
# the part that matters. Any pd.duelist tags on the offline players are stripped by pet_duel/load (R5
# watchdog) on next reload or by crash_recovery on reconnect.
function evercraft:pet_duel/cleanup
