# Resolve pet duel — winner determined
# Called when one pet's HP reaches 0

# Announcement
data modify storage evercraft:notify stage.c set value [{text:"\u2550\u2550\u2550 ",color:"gold"},{text:"PET DUEL",color:"yellow",bold:true},{text:" \u2550\u2550\u2550",color:"gold"}]
scoreboard players set #ndur ec.temp 50
execute as @a run function evercraft:util/notify/emit

# Winner announcement (find winner's pet name)
# \u00a75b actor-naming broadcast \u2014 render direct in the winner's context so {selector:@s} resolves once.
execute as @a[tag=pd.winner] run scoreboard players operation #Search companion.id = @s companion.id
execute as @a[tag=pd.winner] run function evercraft:util/notify/whoami
data modify storage evercraft:notify stage.c set value [{text:"",color:"green"},{text:"'s companion ",color:"gray"},{text:"wins!",color:"green",bold:true}]
data modify storage evercraft:notify stage.c[0].text set from storage evercraft:notify named.who
scoreboard players set #ndur ec.temp 45
execute as @a[tag=pd.winner] run execute as @a run scoreboard players set #nttl ec.temp 300
execute as @a[tag=pd.winner] run execute as @a run function evercraft:util/notify/emit

# Loser notification
# \u00a75b actor-naming broadcast \u2014 render direct in the loser's context.
execute as @a[tag=pd.loser] run function evercraft:util/notify/whoami
data modify storage evercraft:notify stage.c set value [{text:"",color:"red"},{text:"'s companion was defeated.",color:"gray"}]
data modify storage evercraft:notify stage.c[0].text set from storage evercraft:notify named.who
scoreboard players set #ndur ec.temp 45
execute as @a[tag=pd.loser] run execute as @a run scoreboard players set #nttl ec.temp 300
execute as @a[tag=pd.loser] run execute as @a run function evercraft:util/notify/emit

# Winner rewards: +200 RP (R7 — now actually PAID via pay_rp), update stats
execute as @a[tag=pd.winner] run scoreboard players add @s ec.pd_wins 1
execute as @a[tag=pd.winner] run scoreboard players add @s ec.pd_streak 1
# Update best streak
execute as @a[tag=pd.winner] if score @s ec.pd_streak > @s ec.pd_best_streak run scoreboard players operation @s ec.pd_best_streak = @s ec.pd_streak
execute as @a[tag=pd.winner] run function evercraft:pet_duel/pay_rp {amount:200}

# Loser: +50 RP participation (R7 — now actually PAID), update stats
execute as @a[tag=pd.loser] run scoreboard players add @s ec.pd_losses 1
execute as @a[tag=pd.loser] run scoreboard players set @s ec.pd_streak 0
execute as @a[tag=pd.loser] run function evercraft:pet_duel/pay_rp {amount:50}

# Both players: Artisan XP (if system exists)
# scoreboard players add @a[tag=pd.duelist] ec.cf_xp 25

# Companion memory: Duelist's Glory
execute as @a[tag=pd.winner] run function evercraft:companions/memories/on_duel_win

# Coin rewards (winner + loser participation)
function evercraft:coins/pet_duel_reward

# Sound effects
playsound minecraft:ui.toast.challenge_complete master @a[tag=pd.winner,scores={ec.fx_snd=1..}] ~ ~ ~ 1 1
playsound minecraft:entity.experience_orb.pickup master @a[tag=pd.loser,scores={ec.fx_snd=1..}] ~ ~ ~ 1 0.5

# Particles at winner's pet
execute as @a[tag=pd.winner] run scoreboard players operation #Search companion.id = @s companion.id
execute as @e[type=item_display, tag=Companion, predicate=evercraft:companions/check_id, limit=1] at @s run particle totem_of_undying ~ ~0.5 ~ 0.3 0.3 0.3 0.5 10

# Cleanup
function evercraft:pet_duel/cleanup
