# Initialize pet stats for duel combat (SP6 rework)
# Run as each duelist player (has pd.challenger or pd.target).
# Sets ec.pd_hp (pet health pool), ec.pd_atk (auto-attack chip), ec.pd_tier, ec.pd_slots, ec.pd_role,
# and snapshots the pet signature into per-side storage so the two pets never collide on the shared
# companion_combat global slot mid-tick (RISK 1 in the design doc).
# ONE-WRITER owner of: ec.pd_tier, ec.pd_slots, ec.pd_role, ec.pd_castclk, ec.pd_castidx, ec.pd_shield,
# ec.pd_stun, ec.pd_dodge, ec.pd_pdmg (all SET to a clean baseline here; active/tick owns the per-cast
# mutations) and the duelist.<side>.sig storage snapshot.

scoreboard players operation #Search companion.id = @s companion.id

# Read pet level (string -> int) for the auto-attack baseline (positional [2] — the live read).
# string_to_int ACCUMULATES into #value (×10 per digit), so reset it first (matches find_target:23).
data modify storage evercraft:companions math.string set string entity @e[type=item_display, tag=Companion, predicate=evercraft:companions/check_id, limit=1] item.components."minecraft:profile".properties[2].value
scoreboard players set #value companion.calc 0
function evercraft:companions/handler/math/string_to_int

# === HEALTH AXIS (D5): seed duel HP from the pet's real maxHP (companion.maxhp = level+20 cap 120,
# health/init) so feeding/leveling/DR visibly out-tanks a fresh pet. DR enters the duel ONLY here
# (the one sanctioned DR->duel path, DATA-MODEL §4-K). Fall back to level+20 if maxhp is unset so a
# duel never breaks. NOTE (D5): the evolved +50% branch below pushes evolved pets ABOVE 120 by design
# (no clamp) — bigger HP is the evolved reward; revisit only if the F10 playtest shows ~180 is swingy.
scoreboard players operation @s ec.pd_hp = #value companion.calc
scoreboard players add @s ec.pd_hp 20
execute if score @s companion.maxhp matches 1.. run scoreboard players operation @s ec.pd_hp = @s companion.maxhp

# Attack = level / 10 (floor 3) — the slow auto-attack metronome; role tilt + bond layer on top.
scoreboard players operation @s ec.pd_atk = #value companion.calc
scoreboard players operation @s ec.pd_atk /= #10 companion.calc
execute if score @s ec.pd_atk matches ..3 run scoreboard players set @s ec.pd_atk 3

# Bond tilt to the auto-attack: relmult 100..200 -> +0..+33% (read-only consume of the SP2 curve that
# load_rp already loaded for this active pet; bond is on-theme "max bond = stronger pet").
execute if score @s companion.relmult matches 101.. run scoreboard players operation #pd_bonus ec.temp = @s ec.pd_atk
execute if score @s companion.relmult matches 101.. run scoreboard players operation #pd_bonus ec.temp *= @s companion.relmult
execute if score @s companion.relmult matches 101.. run scoreboard players operation #pd_bonus ec.temp /= #100 companion.calc
execute if score @s companion.relmult matches 101.. run scoreboard players operation @s ec.pd_atk = #pd_bonus ec.temp

# Evolved bonus: +50% HP, +50% attack (kept from the live duel; D5 = no HP clamp).
execute if entity @s[tag=ce.evolved_active] run scoreboard players operation #pd_bonus ec.temp = @s ec.pd_hp
execute if entity @s[tag=ce.evolved_active] run scoreboard players operation #pd_bonus ec.temp /= #2 companion.calc
execute if entity @s[tag=ce.evolved_active] run scoreboard players operation @s ec.pd_hp += #pd_bonus ec.temp
execute if entity @s[tag=ce.evolved_active] run scoreboard players operation #pd_bonus ec.temp = @s ec.pd_atk
execute if entity @s[tag=ce.evolved_active] run scoreboard players operation #pd_bonus ec.temp /= #2 companion.calc
execute if entity @s[tag=ce.evolved_active] run scoreboard players operation @s ec.pd_atk += #pd_bonus ec.temp

# Snapshot the ENTRY HP pool (post-evolved) so a Guardian heal can clamp to it, NOT to companion.maxhp
# (an evolved pet's pool exceeds maxhp by design — D5 no-clamp; clamping a heal to maxhp would wrongly
# cap it below entry). This is the heal ceiling for the whole duel.
scoreboard players operation @s ec.pd_hpmax = @s ec.pd_hp

# === ABILITY-IDENTITY AXIS: snapshot signature, capture tier, derive role ===
# Snapshot the pet signature into the SHARED companion_combat slot (transient), then immediately into a
# per-SIDE storage key so the opponent's later read can never overwrite this pet's identity.
data modify storage evercraft:companion_combat companion_name set from entity @e[type=item_display,tag=Companion,predicate=evercraft:companions/check_id,limit=1] item.components."minecraft:profile".properties[{name:"name"}].signature
execute if entity @s[tag=pd.challenger] run data modify storage evercraft:pet_duel duelist.challenger.sig set from storage evercraft:companion_combat companion_name
execute if entity @s[tag=pd.target] run data modify storage evercraft:pet_duel duelist.target.sig set from storage evercraft:companion_combat companion_name

# Tier (1-6): get_tier_stats sets #pc_tier ec.var from the signature currently in companion_combat.
# CAPTURE IMMEDIATELY into ec.pd_tier (RISK 2: #pc_tier in ec.var is transient).
function evercraft:companions/combat/get_tier_stats
scoreboard players operation @s ec.pd_tier = #pc_tier ec.var

# Slots = ability breadth. Prefer the SP1 read-cache companion.slots (rarity+dupe+chip, 1-12);
# fall back to tier when unset so the duel works even before SP1's slot cache is populated.
scoreboard players operation @s ec.pd_slots = @s ec.pd_tier
execute if score @s companion.slots matches 1.. run scoreboard players operation @s ec.pd_slots = @s companion.slots

# Role (1=Striker, 2=Guardian, 3=Controller) from the dominant horn-primitive family. role/get reads
# the signature still in companion_combat (this pet's, just snapshotted) and writes #pd_role ec.var.
# Default to a tier-keyed role first (un-rostered species safety net), then let the table override.
scoreboard players set #pd_role ec.var 1
execute if score @s ec.pd_tier matches 2 run scoreboard players set #pd_role ec.var 2
execute if score @s ec.pd_tier matches 4 run scoreboard players set #pd_role ec.var 3
function evercraft:pet_duel/role/get
scoreboard players operation @s ec.pd_role = #pd_role ec.var

# === Clean per-duel cast/control state (this fn is the sole baseline writer) ===
scoreboard players set @s ec.pd_castclk 0
scoreboard players set @s ec.pd_castidx 0
scoreboard players set @s ec.pd_shield 0
scoreboard players set @s ec.pd_stun 0
scoreboard players set @s ec.pd_dodge 0
scoreboard players set @s ec.pd_pdmg 0
