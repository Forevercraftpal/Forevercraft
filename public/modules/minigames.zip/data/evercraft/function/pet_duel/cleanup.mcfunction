# Clean up pet duel state
# Called after win or draw resolution

# Remove all effects from duelists
effect clear @a[tag=pd.duelist] slowness
effect clear @a[tag=pd.duelist] mining_fatigue

# Set cooldown (12000 ticks = 10 minutes)
scoreboard players set @a[tag=pd.duelist] ec.pd_cd 12000

# Reset state scores
scoreboard players set @a[tag=pd.duelist] ec.pd_active 0
scoreboard players set @a[tag=pd.duelist] ec.pd_hp 0
scoreboard players set @a[tag=pd.duelist] ec.pd_atk 0
scoreboard players set @a[tag=pd.duelist] ec.pd_inv 0

# SP6 ability/role state — clear so it never leaks into the next duel.
scoreboard players set @a[tag=pd.duelist] ec.pd_hpmax 0
scoreboard players set @a[tag=pd.duelist] ec.pd_tier 0
scoreboard players set @a[tag=pd.duelist] ec.pd_slots 0
scoreboard players set @a[tag=pd.duelist] ec.pd_role 0
scoreboard players set @a[tag=pd.duelist] ec.pd_shield 0
scoreboard players set @a[tag=pd.duelist] ec.pd_stun 0
scoreboard players set @a[tag=pd.duelist] ec.pd_dodge 0
scoreboard players set @a[tag=pd.duelist] ec.pd_castclk 0
scoreboard players set @a[tag=pd.duelist] ec.pd_castidx 0
scoreboard players set @a[tag=pd.duelist] ec.pd_pdmg 0

# Clear the per-side signature snapshots (transient; rebuilt next init_pet_stats).
data remove storage evercraft:pet_duel duelist.challenger.sig
data remove storage evercraft:pet_duel duelist.target.sig

# Remove all duel tags
tag @a[tag=pd.duelist] remove pd.duelist
tag @a[tag=pd.challenger] remove pd.challenger
tag @a[tag=pd.target] remove pd.target
tag @a[tag=pd.winner] remove pd.winner
tag @a[tag=pd.loser] remove pd.loser
tag @a[tag=pd.attacker] remove pd.attacker
tag @a[tag=pd.caster] remove pd.caster

# Remove bossbar
bossbar remove evercraft:pet_duel

# Reset global flag
scoreboard players set #pd_active ec.var 0
scoreboard players set #pd_timer ec.var 0
# Reset the orphan-sweep grace counter (#50 W3) so the next duel starts clean.
scoreboard players set #pd_orphan ec.var 0
