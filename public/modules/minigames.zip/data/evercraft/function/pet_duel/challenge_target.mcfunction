# Pet Duel — Challenge a specific player whose pet was sneak-right-clicked
# Run as the CHALLENGER player (who clicked the rival's pet)
# #pd_pet_owner ec.temp = companion.id of the pet that was clicked (= target player's id)

# R5 GLOBAL MUTEX — reject if ANY duel is live server-wide (NON-BOLD popup, popup-law).
data modify storage evercraft:notify stage.c set value [{text:"A duel is already underway — try again shortly.",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute if score #pd_active ec.var matches 1.. run return run function evercraft:util/notify/emit

# Already in a pet duel?
execute if score @s ec.pd_active matches 1 run return 0

# Already have a pending invite?
execute if score @s ec.pd_inv matches 1 run return 0

# Cooldown check
data modify storage evercraft:notify stage.c set value [{text:"Pet duel on cooldown.",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute if score @s ec.pd_cd matches 1.. run function evercraft:util/notify/emit
execute if score @s ec.pd_cd matches 1.. run return 0

# Find the target player (owner of the clicked pet)
tag @s add pd.challenger
scoreboard players operation #Search companion.id = #pd_pet_owner ec.temp
execute as @a[tag=companion.activepet,predicate=evercraft:companions/check_id,tag=!pd.challenger] run function evercraft:pet_duel/send_invite

# If no target found (edge case), clean up
execute unless entity @a[tag=pd.pending_target] run tag @s remove pd.challenger
