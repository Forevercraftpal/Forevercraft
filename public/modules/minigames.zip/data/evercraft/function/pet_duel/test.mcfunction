# Test function for pet duels
# /function evercraft:pet_duel/test
# Shows pet duel stats

tellraw @s [{text:"[PD Test] ",color:"gold"},{text:"Pet Duel Stats:",color:"aqua"}]
tellraw @s [{text:"  Wins: ",color:"gray"},{score:{name:"@s",objective:"ec.pd_wins"},color:"green"},{text:"  Losses: ",color:"gray"},{score:{name:"@s",objective:"ec.pd_losses"},color:"red"},{text:"  Draws: ",color:"gray"},{score:{name:"@s",objective:"ec.pd_draws"},color:"yellow"}]
tellraw @s [{text:"  Streak: ",color:"gray"},{score:{name:"@s",objective:"ec.pd_streak"},color:"yellow"},{text:"  Best: ",color:"gray"},{score:{name:"@s",objective:"ec.pd_best_streak"},color:"gold"}]
tellraw @s [{text:"  Cooldown: ",color:"gray"},{score:{name:"@s",objective:"ec.pd_cd"},color:"white"},{text:" ticks",color:"gray"}]
