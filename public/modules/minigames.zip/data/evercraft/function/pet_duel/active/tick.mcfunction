# Pet Duel — Active combat tick (SP6 rework)
# Self-scheduling every 10 ticks (0.5 s) while the duel is active.
# Keeps the slow turn-y exchange feel; layers in (a) a periodic CAST phase where each pet's role-move
# "fires" abstractly (no live ability FX), and (b) a role rock-paper-scissors TILT on every exchange.
# The active/tick CHAIN (tick + cast + pet_attack + deal_damage + apply_shield) owns the per-exchange
# mutations of ec.pd_castclk/castidx/shield/stun/dodge/pdmg across disjoint phases (cadence -> cast ->
# attack -> absorb), the documented disjoint-context pattern; init_pet_stats owns their clean baseline.
# tick itself only advances ec.pd_castclk (+1) here; the rest mutate in the named sub-functions.

execute unless score #pd_active ec.var matches 1 run return 0

# Decrement timer
scoreboard players remove #pd_timer ec.var 10

# Update bossbar
bossbar set evercraft:pet_duel value 0
execute store result bossbar evercraft:pet_duel value run scoreboard players get #pd_timer ec.var

# Check for timer expiry — DRAW
execute if score #pd_timer ec.var matches ..0 run function evercraft:pet_duel/resolve_draw
execute if score #pd_timer ec.var matches ..0 run return 0

# === CAST PHASE (every 6th exchange ~3 s; keeps the deliberate cadence, ~10 casts per 30 s duel) ===
# Advance each duelist's cadence counter; on the 6th the pet's role-move fires (challenger then target
# — fixed order, no simultaneity race). Pending burst accumulates into ec.pd_pdmg for the attack phase.
scoreboard players add @a[tag=pd.duelist] ec.pd_castclk 1
execute as @a[tag=pd.challenger,scores={ec.pd_castclk=6..}] run function evercraft:pet_duel/active/cast
execute as @a[tag=pd.target,scores={ec.pd_castclk=6..}] run function evercraft:pet_duel/active/cast

# === ATTACK PHASE (existing metronome) — each pet swings; role tilt + burst layer on, minus defenses ===
execute as @a[tag=pd.challenger] run function evercraft:pet_duel/active/pet_attack
execute as @a[tag=pd.target] run function evercraft:pet_duel/active/pet_attack

# === WIN CHECK ===
# Same-exchange double-KO -> DRAW (PD-4): if BOTH duelists fell, neither prevails.
execute store result score #pd_dead ec.temp if entity @a[tag=pd.duelist,scores={ec.pd_hp=..0}]
execute if score #pd_dead ec.temp matches 2.. run function evercraft:pet_duel/resolve_draw
execute if score #pd_dead ec.temp matches 2.. run return 0
# Single KO -> the survivor wins.
execute as @a[tag=pd.duelist,scores={ec.pd_hp=..0}] run tag @s add pd.loser
execute if entity @a[tag=pd.loser] as @a[tag=pd.duelist,tag=!pd.loser] run tag @s add pd.winner
execute if entity @a[tag=pd.winner] run function evercraft:pet_duel/resolve_win
execute if entity @a[tag=pd.winner] run return 0

# Check for disconnects
execute store result score #pd_duelist_count ec.temp if entity @a[tag=pd.duelist]
execute if score #pd_duelist_count ec.temp matches ..1 run function evercraft:pet_duel/resolve_draw
execute if score #pd_duelist_count ec.temp matches ..1 run return 0

# Continue ticking
schedule function evercraft:pet_duel/active/tick 10t
