# Pet Duel — cast narration + FX (SP6)
# Run as the CASTING duelist (@s = caster). Macro: {msg,color,p,snd}.
# NON-BOLD centered action-bar to BOTH duelists, plus a distinct particle + sound at the casting pet so
# spectators read the flow. No persistent entity.
#
# ACTOR-NAMING: render the name line DIRECTLY in the caster's context (title @a[..] actionbar) so the
# {selector:"@s"} resolves ONCE to the CASTER and broadcasts to both duelists — same idiom as
# resolve_win:12/16. (The queued notify/emit re-resolves @s per VIEWER, which would wrongly show each
# duelist their OWN name, so it is NOT used for this cross-player named line.) NON-BOLD per popup-law.
# (Wave 2, 2026-06-10: duel cast echo — whoami-baked, 15s TTL.)
function evercraft:util/notify/whoami
$data modify storage evercraft:notify stage.c set value [{text:"",color:"$(color)"},{text:"'s companion $(msg)",color:"gray"}]
data modify storage evercraft:notify stage.c[0].text set from storage evercraft:notify named.who
scoreboard players set #ndur ec.temp 45
execute as @a[tag=pd.duelist] run scoreboard players set #nttl ec.temp 300
execute as @a[tag=pd.duelist] run function evercraft:util/notify/emit

# Particle + sound at the casting pet's display entity.
scoreboard players operation #Search companion.id = @s companion.id
$execute as @e[type=item_display,tag=Companion,predicate=evercraft:companions/check_id,limit=1] at @s run particle $(p) ~ ~0.4 ~ 0.25 0.25 0.25 0.05 8
$playsound $(snd) master @a[tag=pd.duelist,scores={ec.fx_snd=1..}] ~ ~ ~ 0.5 1.1
