# Pet Duel — shield absorb (SP6)
# Run as the DEFENDER (opponent of the attacker). Absorbs #pd_dmg ec.var against this pet's ec.pd_shield.
# Shield >= dmg: shield -= dmg, dmg = 0.  Shield < dmg: dmg -= shield, shield = 0.
# ONE-WRITER of ec.pd_shield mutation here (cast.mcfunction SETs/adds it; this is the consume path,
# both reached only from the active/tick chain — disjoint phases, documented).

# Snapshot the branch decision BEFORE mutating, so the two lines of each case read a stable comparison.
scoreboard players set #pd_shfull ec.var 0
execute if score @s ec.pd_shield >= #pd_dmg ec.var run scoreboard players set #pd_shfull ec.var 1

# Case A: shield fully absorbs the swing.
execute if score #pd_shfull ec.var matches 1 run scoreboard players operation @s ec.pd_shield -= #pd_dmg ec.var
execute if score #pd_shfull ec.var matches 1 run scoreboard players set #pd_dmg ec.var 0

# Case B: swing exceeds the shield — shield is spent, remainder pierces.
execute if score #pd_shfull ec.var matches 0 run scoreboard players operation #pd_dmg ec.var -= @s ec.pd_shield
execute if score #pd_shfull ec.var matches 0 run scoreboard players set @s ec.pd_shield 0
