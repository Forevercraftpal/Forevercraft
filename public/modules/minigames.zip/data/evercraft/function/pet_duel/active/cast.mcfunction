# Pet Duel — CAST a role-move (SP6, D9 smallest slice)
# Run as ONE duelist whose ec.pd_castclk reached 6. Resets the cadence counter, then the pet's ROLE
# "fires" abstractly (NO live ability FX — we resolve the role's duel-verb only, per the translation
# layer in the design doc). Magnitude scales by LEVEL (tier proxy) x BOND (relmult). Narrated NON-BOLD.
# ONE-WRITER (shared with active/tick): ec.pd_castclk reset, ec.pd_pdmg accumulate, ec.pd_shield set,
# ec.pd_stun set on opponent. ec.pd_castidx advances (verb breadth from slots — DEFERRED full kit; the
# single role-move fires here, but the counter is advanced so the deferred multi-verb rotation can hook
# in without a tick-shape change).
#
# v1 = D9 SMALLEST SLICE: each role fires ONE signature verb (Striker=burst, Guardian=heal+shield,
# Controller=stun). The richer status kit (Hype / Fluster / multi-verb rotation, and the DODGE verb —
# ec.pd_dodge is registered + consumed in deal_damage as a reserved forward hook) is DEFERRED.

scoreboard players set @s ec.pd_castclk 0
scoreboard players add @s ec.pd_castidx 1

# --- Cast magnitude = base x (relmult/100) x (tier/3-ish) ---
# base 6 half-hearts; bond multiplies (100..200 -> 1.0..2.0x); higher tier casts a touch harder.
scoreboard players set #pd_mag ec.var 6
scoreboard players operation #pd_mag ec.var *= @s companion.relmult
scoreboard players operation #pd_mag ec.var /= #100 companion.calc
scoreboard players operation #pd_tadd ec.var = @s ec.pd_tier
scoreboard players operation #pd_mag ec.var += #pd_tadd ec.var
# Cap a single cast to a fraction of a fresh pet's pool so duels stay multi-exchange (RISK 5).
execute if score #pd_mag ec.var matches 40.. run scoreboard players set #pd_mag ec.var 40

# === STRIKER (role 1): a burst — accumulate into pending damage for this exchange's attack phase. ===
execute if score @s ec.pd_role matches 1 run scoreboard players operation @s ec.pd_pdmg += #pd_mag ec.var
execute if score @s ec.pd_role matches 1 run function evercraft:pet_duel/active/cast_fx {msg:"strikes with focused fury!",color:"red",p:"crit",snd:"minecraft:entity.player.attack.crit"}

# === GUARDIAN (role 2): mend + raise a shield (next-hit absorb). Heal clamped to entry pool. ===
execute if score @s ec.pd_role matches 2 run scoreboard players operation @s ec.pd_hp += #pd_mag ec.var
execute if score @s ec.pd_role matches 2 if score @s ec.pd_hp > @s ec.pd_hpmax run scoreboard players operation @s ec.pd_hp = @s ec.pd_hpmax
execute if score @s ec.pd_role matches 2 run scoreboard players operation #pd_shadd ec.var = #pd_mag ec.var
execute if score @s ec.pd_role matches 2 run scoreboard players operation #pd_shadd ec.var /= #2 companion.calc
execute if score @s ec.pd_role matches 2 run scoreboard players operation @s ec.pd_shield += #pd_shadd ec.var
execute if score @s ec.pd_role matches 2 run function evercraft:pet_duel/active/cast_fx {msg:"braces behind a steadfast ward!",color:"aqua",p:"happy_villager",snd:"minecraft:block.beacon.activate"}

# === CONTROLLER (role 3): stun the opponent — they skip their next auto-attack (v1 stun scope). ===
execute if score @s ec.pd_role matches 3 run tag @s add pd.caster
execute if score @s ec.pd_role matches 3 run scoreboard players set @a[tag=pd.duelist,tag=!pd.caster] ec.pd_stun 1
execute if score @s ec.pd_role matches 3 run tag @s remove pd.caster
execute if score @s ec.pd_role matches 3 run function evercraft:pet_duel/active/cast_fx {msg:"binds the rival in a sapping field!",color:"light_purple",p:"witch",snd:"minecraft:entity.illusioner.cast_spell"}
