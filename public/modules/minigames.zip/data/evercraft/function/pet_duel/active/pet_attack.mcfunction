# Pet auto-attack — this player's pet swings at the opponent's pet (SP6 rework)
# Run as a duelist. Layers role rock-paper-scissors TILT + pending cast burst onto the auto-attack
# baseline; honors stun (skip) and the opponent's shield/dodge in deal_damage.

# If a winner was already decided this tick, do nothing (cleanup-safe).
execute if entity @a[tag=pd.winner] run return 0

# Snapshot the stun BEFORE consuming it, so the skip-vs-swing branch reads a stable value.
scoreboard players operation #pd_wasstun ec.temp = @s ec.pd_stun

# STUN: a Controller's bind makes this pet skip its next auto-attack (v1 stun scope). Consume the stun
# and drop any burst it had queued this exchange. (Full cast-denial is part of the DEFERRED status kit.)
execute if score #pd_wasstun ec.temp matches 1.. run scoreboard players set @s ec.pd_stun 0
execute if score #pd_wasstun ec.temp matches 1.. run scoreboard players set @s ec.pd_pdmg 0

# Not stunned: swing (auto-attack + pending burst + role tilt, minus opponent shield/dodge).
execute if score #pd_wasstun ec.temp matches 0 run function evercraft:pet_duel/active/deal_damage

# Attack swipe particle on own pet (only when the swing actually landed).
scoreboard players operation #Search companion.id = @s companion.id
execute if score #pd_wasstun ec.temp matches 0 as @e[type=item_display, tag=Companion, predicate=evercraft:companions/check_id, limit=1] at @s run particle sweep_attack ~ ~0.3 ~ 0.2 0.1 0.2 0 1
