# Deal damage from this player's pet to the opponent's pet (SP6 rework)
# Run as the attacking duelist (NOT stunned). Total = auto-attack + pending cast burst + role-RPS tilt,
# then reduced by the opponent's shield, then negated entirely if the opponent has a dodge charge.
# Role triangle: Striker(1) > Controller(3) > Guardian(2) > Striker(1).

tag @s add pd.attacker

# Base swing = auto-attack chip + this exchange's pending cast burst.
scoreboard players operation #pd_dmg ec.var = @s ec.pd_atk
scoreboard players operation #pd_dmg ec.var += @s ec.pd_pdmg
# Pending burst is consumed by this swing.
scoreboard players set @s ec.pd_pdmg 0

# --- Role rock-paper-scissors TILT ---
# If the attacker's role BEATS the opponent's role, add a tilt bonus (= 3 + opponent's-side context).
# Read the opponent's role into scratch.
scoreboard players operation #pd_oprole ec.var = @a[tag=pd.duelist,tag=!pd.attacker,limit=1] ec.pd_role
scoreboard players operation #pd_myrole ec.var = @s ec.pd_role
scoreboard players set #pd_tilt ec.var 0
# Striker(1) > Controller(3)
execute if score #pd_myrole ec.var matches 1 if score #pd_oprole ec.var matches 3 run scoreboard players set #pd_tilt ec.var 1
# Controller(3) > Guardian(2)
execute if score #pd_myrole ec.var matches 3 if score #pd_oprole ec.var matches 2 run scoreboard players set #pd_tilt ec.var 1
# Guardian(2) > Striker(1)
execute if score #pd_myrole ec.var matches 2 if score #pd_oprole ec.var matches 1 run scoreboard players set #pd_tilt ec.var 1
# Advantage bonus = 4 half-hearts + 1 per tier above 1 (a real but non-decisive edge).
execute if score #pd_tilt ec.var matches 1 run scoreboard players operation #pd_tbonus ec.var = @s ec.pd_tier
execute if score #pd_tilt ec.var matches 1 run scoreboard players add #pd_tbonus ec.var 3
execute if score #pd_tilt ec.var matches 1 run scoreboard players operation #pd_dmg ec.var += #pd_tbonus ec.var

# --- Opponent defenses: shield absorbs first, dodge negates the whole swing ---
# Dodge (if any) negates the entire hit and is consumed.
execute if score @a[tag=pd.duelist,tag=!pd.attacker,limit=1] ec.pd_dodge matches 1.. run scoreboard players set #pd_dmg ec.var 0
execute as @a[tag=pd.duelist,tag=!pd.attacker] if score @s ec.pd_dodge matches 1.. run scoreboard players set @s ec.pd_dodge 0
# Shield absorbs up to its pool; remaining shield carries to the next hit.
execute as @a[tag=pd.duelist,tag=!pd.attacker] if score @s ec.pd_shield matches 1.. run function evercraft:pet_duel/active/apply_shield

# Apply the remaining damage to the opponent's HP pool.
execute as @a[tag=pd.duelist,tag=!pd.attacker] run scoreboard players operation @s ec.pd_hp -= #pd_dmg ec.var

# Visual: damage indicator + hit sound at the opponent's pet.
execute as @a[tag=pd.duelist,tag=!pd.attacker] run scoreboard players operation #Search companion.id = @s companion.id
execute as @e[type=item_display, tag=Companion, predicate=evercraft:companions/check_id, limit=1] at @s run particle damage_indicator ~ ~0.3 ~ 0.1 0.1 0.1 0.2 2
execute as @e[type=item_display, tag=Companion, predicate=evercraft:companions/check_id, limit=1] at @s run playsound minecraft:entity.player.attack.strong master @a[tag=pd.duelist,scores={ec.fx_snd=1..}] ~ ~ ~ 0.3 1.2

tag @s remove pd.attacker
