# Pet Duel countdown (3...2...1...FIGHT!)
# Self-scheduling every tick

execute unless score #pd_active ec.var matches 1 run return 0

scoreboard players remove #pd_countdown ec.var 1

data modify storage evercraft:notify stage.c set value [{text:"2...",color:"yellow"}]
scoreboard players set #ndur ec.temp 45
execute if score #pd_countdown ec.var matches 40 as @a[tag=pd.duelist] run function evercraft:util/notify/emit
execute if score #pd_countdown ec.var matches 40 run playsound minecraft:block.note_block.pling master @a[tag=pd.duelist,scores={ec.fx_snd=1..}] ~ ~ ~ 1 0.7

data modify storage evercraft:notify stage.c set value [{text:"1...",color:"yellow"}]
scoreboard players set #ndur ec.temp 45
execute if score #pd_countdown ec.var matches 20 as @a[tag=pd.duelist] run function evercraft:util/notify/emit
execute if score #pd_countdown ec.var matches 20 run playsound minecraft:block.note_block.pling master @a[tag=pd.duelist,scores={ec.fx_snd=1..}] ~ ~ ~ 1 0.9

data modify storage evercraft:notify stage.c set value [{text:"FIGHT!",color:"red",bold:true}]
scoreboard players set #ndur ec.temp 45
execute if score #pd_countdown ec.var matches 0 as @a[tag=pd.duelist] run function evercraft:util/notify/emit
execute if score #pd_countdown ec.var matches 0 run playsound minecraft:entity.ender_dragon.growl master @a[tag=pd.duelist,scores={ec.fx_snd=1..}] ~ ~ ~ 0.5 1.5
# (AB-1 sticky-times sweep 2026-06-10: explicit stamp — `title times` is sticky per player and this sequence set none, so it inherited whatever ran last.)
execute if score #pd_countdown ec.var matches 0 run title @a[tag=pd.duelist] times 10 60 20
execute if score #pd_countdown ec.var matches 0 run title @a[tag=pd.duelist] title {"text":"FIGHT!","color":"red"}

# Start combat tick when countdown reaches 0
execute if score #pd_countdown ec.var matches 0 run schedule function evercraft:pet_duel/active/tick 1t
execute if score #pd_countdown ec.var matches 0 run return 0

# Continue countdown
execute if score #pd_countdown ec.var matches 1.. run schedule function evercraft:pet_duel/countdown 1t
