# Accept pet duel — start the fight!
# Run as the target player (who accepted)

tag @s remove pd.pending_target
scoreboard players set @s ec.pd_inv_cd 0

# Mark both players as active duelists
scoreboard players set @s ec.pd_active 1
tag @s add pd.duelist
tag @s add pd.target

# Find challenger and mark them too
# Safety: verify challenger is still online and has active pet
execute store result score #pd_challenger_found ec.temp if entity @a[tag=companion.activepet,scores={ec.pd_inv=1}]
execute if score #pd_challenger_found ec.temp matches 0 run tag @s remove pd.duelist
execute if score #pd_challenger_found ec.temp matches 0 run tag @s remove pd.target
execute if score #pd_challenger_found ec.temp matches 0 run scoreboard players set @s ec.pd_active 0
execute if score #pd_challenger_found ec.temp matches 0 run scoreboard players set @s ec.pd_inv 0
data modify storage evercraft:notify stage.c set value [{text:"Challenger is no longer available.",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute if score #pd_challenger_found ec.temp matches 0 run function evercraft:util/notify/emit
execute if score #pd_challenger_found ec.temp matches 0 run return 0

execute as @a[tag=companion.activepet,scores={ec.pd_inv=1}] run scoreboard players set @s ec.pd_active 1
execute as @a[tag=companion.activepet,scores={ec.pd_inv=1}] run tag @s add pd.duelist
execute as @a[tag=companion.activepet,scores={ec.pd_inv=1}] run tag @s add pd.challenger
execute as @a[tag=companion.activepet,scores={ec.pd_inv=1}] run scoreboard players set @s ec.pd_inv 0
scoreboard players set @s ec.pd_inv 0

# Set global active flag
scoreboard players set #pd_active ec.var 1

# Initialize pet stats (HP + ATK based on level, evolved bonus)
execute as @a[tag=pd.duelist] run function evercraft:pet_duel/init_pet_stats

# Apply spectator debuffs to both players (can't interfere)
effect give @a[tag=pd.duelist] slowness 35 2 true
effect give @a[tag=pd.duelist] mining_fatigue 35 2 true

# Set duel timer (600 ticks = 30 seconds)
scoreboard players set #pd_timer ec.var 600

# Create bossbar
bossbar add evercraft:pet_duel {"text":"Pet Duel","color":"gold","bold":true}
bossbar set evercraft:pet_duel max 600
bossbar set evercraft:pet_duel value 600
bossbar set evercraft:pet_duel color yellow
bossbar set evercraft:pet_duel style progress
bossbar set evercraft:pet_duel visible true
bossbar set evercraft:pet_duel players @a[tag=pd.duelist]

# 3-second countdown before fight starts
scoreboard players set #pd_countdown ec.var 60
data modify storage evercraft:notify stage.c set value [{text:"Pet Duel starting in 3...",color:"yellow"}]
scoreboard players set #ndur ec.temp 45
execute as @a[tag=pd.duelist] run function evercraft:util/notify/emit
playsound minecraft:block.note_block.pling master @a[tag=pd.duelist,scores={ec.fx_snd=1..}] ~ ~ ~ 1 0.5

# Start the countdown tick
schedule function evercraft:pet_duel/countdown 1t
