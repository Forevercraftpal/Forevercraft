# Decline pet duel
# Run as the target player

tag @s remove pd.pending_target
scoreboard players set @s ec.pd_inv 0
scoreboard players set @s ec.pd_inv_cd 0

# Notify challenger (find by matching companion.id stored in target's ec.pd_inv)
data modify storage evercraft:notify stage.c set value [{text:"Challenge declined.",color:"gray"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit

# Find the challenger and notify them
data modify storage evercraft:notify stage.c set value [{text:"Your challenge was declined.",color:"gray"}]
scoreboard players set #ndur ec.temp 45
execute as @a[tag=companion.activepet,scores={ec.pd_inv=1}] run function evercraft:util/notify/emit
execute as @a[tag=companion.activepet,scores={ec.pd_inv=1}] run scoreboard players set @s ec.pd_inv 0
