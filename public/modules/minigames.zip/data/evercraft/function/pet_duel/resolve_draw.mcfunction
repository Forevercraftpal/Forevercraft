# Resolve pet duel — draw (timer expired or disconnect)

data modify storage evercraft:notify stage.c set value [{text:"\u2550\u2550\u2550 ",color:"gold"},{text:"PET DUEL",color:"yellow",bold:true},{text:" \u2550\u2550\u2550",color:"gold"}]
scoreboard players set #ndur ec.temp 50
execute as @a run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Draw!",color:"yellow"},{text:" Neither companion could prevail.",color:"gray"}]
scoreboard players set #ndur ec.temp 40
execute as @a run function evercraft:util/notify/emit

# Both get participation rewards (D-SP6 draw rule / PD-5: +50 RP each — duels always advance bond a bit)
execute as @a[tag=pd.duelist] run scoreboard players add @s ec.pd_draws 1
execute as @a[tag=pd.duelist] run function evercraft:pet_duel/pay_rp {amount:50}

# Sound
playsound minecraft:block.note_block.pling master @a[tag=pd.duelist,scores={ec.fx_snd=1..}] ~ ~ ~ 1 0.8

# Cleanup
function evercraft:pet_duel/cleanup
