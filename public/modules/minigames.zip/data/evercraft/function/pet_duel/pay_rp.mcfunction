# Pet Duel — RP payout (SP6 / audit R7)
# Run as ONE duelist (winner / loser / draw participant). Macro: {amount:N}.
# Pays the advertised relationship points to the ACTIVE companion, following the EXACT established
# convention (relationship/interact/process:14-26, feed/process:14-29): load -> add -> cap 5000 ->
# save (persists to pet NBT + Pets[] marker) -> reload (recalc rellevel/relmult) -> level_up on change.
#
# ONE-WRITER NOTE (R9): companion.rp is an EXISTING multi-written objective (relationship handlers,
# admin, chrono_shard). This adds the DUEL-RESOLUTION write site — disjoint context (only ever reached
# from resolve_win/resolve_draw, gated by the pd.* tags), routed through the standard add+clamp+save,
# not a raw scattered writer. The duel does NOT own companion.rp; it borrows the convention.

# Resolve THIS duelist's active companion id (id-token resolution, never a blind global score scan).
scoreboard players operation #Search companion.id = @s companion.id

# Load current RP for the active pet; snapshot the bond level for a level-up check.
function evercraft:companions/handler/relationship/load_rp
scoreboard players operation #pd_oldlvl companion.calc = @s companion.rellevel

# Add the payout and clamp to 5000 (the house RP ceiling).
$scoreboard players add @s companion.rp $(amount)
execute if score @s companion.rp > #5000 companion.calc run scoreboard players set @s companion.rp 5000

# Persist to NBT + marker, then reload to recompute rellevel/relmult.
function evercraft:companions/handler/relationship/save_rp
function evercraft:companions/handler/relationship/load_rp

# Celebrate a bond rank-up if the payout crossed a threshold.
execute unless score @s companion.rellevel = #pd_oldlvl companion.calc run function evercraft:companions/handler/relationship/level_up

# Action-bar confirmation (NON-BOLD).
$data modify storage evercraft:notify stage.c set value [{text:"Duel reward: ",color:"gray"},{text:"+$(amount) RP",color:"yellow"}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit
