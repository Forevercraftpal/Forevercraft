# Detect cross-pet click — a player right-clicked another player's companion
# Run as the pet interaction entity that has leftover interaction data
# (Own-pet clicks are already cleared by ai.mcfunction → on_interact)

# Clear the interaction data first (prevent re-triggering)
data remove entity @s interaction

# Store the pet owner's companion.id
scoreboard players operation #pd_pet_owner ec.temp = @s companion.id

# Find the clicking player: nearest sneaking player with active pet within 3 blocks
# Tight range (3 blocks) minimizes wrong-player matches in crowded areas
# Must NOT be the pet's owner (different companion.id)
execute as @a[tag=companion.activepet,distance=..3,predicate=evercraft:is_sneaking,limit=1,sort=nearest] unless score @s companion.id = #pd_pet_owner ec.temp at @s run function evercraft:pet_duel/challenge_target
