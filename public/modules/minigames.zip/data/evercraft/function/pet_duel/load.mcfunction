# === PET DUEL SYSTEM ===
# Companion rivalry duels — 1v1 pet fights between rival companions

# Trigger: accept (1) / decline (2)
scoreboard objectives add ec.pd trigger "Pet Duel"
scoreboard players enable @a ec.pd

# State tracking
scoreboard objectives add ec.pd_inv dummy "PD Invite Pending"
scoreboard objectives add ec.pd_active dummy "PD Active"
scoreboard objectives add ec.pd_timer dummy "PD Timer"
scoreboard objectives add ec.pd_cd dummy "PD Cooldown"
scoreboard objectives add ec.pd_inv_cd dummy "PD Invite Expiry"

# Stats tracking
scoreboard objectives add ec.pd_wins dummy "PD Wins"
scoreboard objectives add ec.pd_losses dummy "PD Losses"
scoreboard objectives add ec.pd_draws dummy "PD Draws"
scoreboard objectives add ec.pd_streak dummy "PD Win Streak"
scoreboard objectives add ec.pd_best_streak dummy "PD Best Streak"
scoreboard objectives add ec.pd_rival_wins dummy "PD Rival Wins"

# Global active flag (0 = no pet duels active, 1 = a duel is in progress).
# R5 watchdog: a duel never survives a reload (its self-schedule is gone + the bossbar is recreated
# fresh), so a load that finds the mutex held means a crash/reload happened MID-DUEL and left the flag
# stuck — which would block ALL future duels server-wide. ALWAYS clear it on load + tear down any
# orphaned duel tags/bossbar so the mutex can never wedge. (Was: only reset when unset.)
execute if score #pd_active ec.var matches 1.. run tag @a[tag=pd.duelist] remove pd.duelist
execute if score #pd_active ec.var matches 1.. run tag @a[tag=pd.challenger] remove pd.challenger
execute if score #pd_active ec.var matches 1.. run tag @a[tag=pd.target] remove pd.target
execute if score #pd_active ec.var matches 1.. run tag @a[tag=pd.winner] remove pd.winner
execute if score #pd_active ec.var matches 1.. run tag @a[tag=pd.loser] remove pd.loser
execute if score #pd_active ec.var matches 1.. run tag @a[tag=pd.attacker] remove pd.attacker
execute if score #pd_active ec.var matches 1.. run tag @a[tag=pd.caster] remove pd.caster
execute if score #pd_active ec.var matches 1.. run bossbar remove evercraft:pet_duel
execute if score #pd_active ec.var matches 1.. run scoreboard players set @a[scores={ec.pd_active=1..}] ec.pd_active 0
scoreboard players set #pd_active ec.var 0
scoreboard players set #pd_timer ec.var 0
# Orphan-sweep grace counter (#50 W3) — written only in tick.mcfunction + orphan_sweep + here.
scoreboard players set #pd_orphan ec.var 0

# Constants
scoreboard players set #pd_duel_time companion.calc 600
scoreboard players set #pd_cooldown companion.calc 12000
scoreboard players set #pd_invite_time companion.calc 400

# Pet HP during duels (per player — represents their pet's remaining HP)
scoreboard objectives add ec.pd_hp dummy "PD Pet HP"
scoreboard objectives add ec.pd_atk dummy "PD Pet Attack"

# SP6 ability/role state (per player — seeded fresh each duel by init_pet_stats / active/tick)
scoreboard objectives add ec.pd_hpmax dummy "PD Entry HP Pool"
scoreboard objectives add ec.pd_tier dummy "PD Pet Tier"
scoreboard objectives add ec.pd_slots dummy "PD Ability Slots"
scoreboard objectives add ec.pd_role dummy "PD Duel Role"
scoreboard objectives add ec.pd_shield dummy "PD Shield Pool"
scoreboard objectives add ec.pd_stun dummy "PD Stun Flag"
scoreboard objectives add ec.pd_dodge dummy "PD Dodge Flag"
scoreboard objectives add ec.pd_castclk dummy "PD Cast Cadence"
scoreboard objectives add ec.pd_castidx dummy "PD Cast Index"
scoreboard objectives add ec.pd_pdmg dummy "PD Pending Burst"

# Bossbar for duel timer
execute unless data storage evercraft:pet_duel {} run data merge storage evercraft:pet_duel {}
