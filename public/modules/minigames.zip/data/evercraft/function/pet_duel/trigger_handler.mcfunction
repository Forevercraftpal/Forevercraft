# Pet Duel trigger handler
# Run as player who triggered ec.pd
# 1 = accept, 2 = decline

# Accept
execute if score @s ec.pd matches 1 if entity @s[tag=pd.pending_target] run function evercraft:pet_duel/accept

# Decline
execute if score @s ec.pd matches 2 if entity @s[tag=pd.pending_target] run function evercraft:pet_duel/decline

# Reset trigger
scoreboard players set @s ec.pd 0
scoreboard players enable @s ec.pd
