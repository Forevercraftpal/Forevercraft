# Pet Duel — Initiate via Raycast (Companion Catalogue + sneak + look at player)
# Runs as challenger, target = duel.ray_target

# R5 GLOBAL MUTEX — only ONE duel server-wide at a time (the shared #pd_timer/bossbar/pd.* tags can't
# safely host two). Reject concurrent challenges with a NON-BOLD popup (popup-law: actionbars not bold).
data modify storage evercraft:notify stage.c set value [{text:"A duel is already underway — try again shortly.",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute if score #pd_active ec.var matches 1.. run return run function evercraft:util/notify/emit

# Check challenger has an active pet
data modify storage evercraft:notify stage.c set value [{text:"You need an active companion to challenge!",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute unless entity @s[tag=companion.activepet] run return run function evercraft:util/notify/emit

# Check not already in pet duel
execute if score @s ec.pd_active matches 1 run return 0

# Check cooldown
data modify storage evercraft:notify stage.c set value [{text:"Pet duel on cooldown.",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute if score @s ec.pd_cd matches 1.. run return run function evercraft:util/notify/emit

# Check already has pending invite
execute if score @s ec.pd_inv matches 1 run return 0

# Check target has active pet
data modify storage evercraft:notify stage.c set value [{text:"That player doesn't have an active companion!",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute unless entity @a[tag=duel.ray_target,tag=companion.activepet] run return run function evercraft:util/notify/emit

# Tag as challenger and send invite
tag @s add pd.challenger
execute as @a[tag=duel.ray_target,limit=1] run function evercraft:pet_duel/send_invite
# If no invite sent (target in restricted state), clean up
execute unless entity @a[tag=pd.pending_target] run tag @s remove pd.challenger
