# =====================================================================
# Seasonal Node Festival — Force the featured node's competition (Track A pin)
# =====================================================================
# Called from event_director/dawn_decision's small festival branch ONLY when #nfest_active.
# If the festival's featured node (1..5 -> competition type 7..11) is eligible (>=1 online
# player has that class unlocked), force-select it as today's competition and commit —
# bypassing the normal pool + per-type lockout + cadence for the featured node only.
#
# Sets #nfest_forced_a ec.var = 1 iff it forced a pick (so the dawn decision returns and
# skips its normal logic). 0 = not forced (no festival node, or the node isn't eligible —
# fall through to the normal Track-A decision).
#
# Node->type: 1 lm->7 · 2 lf->8 · 3 tw->9 · 4 sc->10 · 5 gw->11. Eligibility gate mirrors
# build_comp_pool's per-node caffl_<code> check.
# ---------------------------------------------------------------------
scoreboard players set #nfest_forced_a ec.var 0

# Featured competition type = node + 6.
scoreboard players operation #nfest_ftype ec.var = #nfest_node ec.var
scoreboard players add #nfest_ftype ec.var 6

# Eligibility: is there >=1 online player with the featured node's class unlocked?
scoreboard players set #nfest_elig ec.var 0
execute if score #nfest_node ec.var matches 1 if entity @a[scores={ec.caffl_lm=1..},limit=1] run scoreboard players set #nfest_elig ec.var 1
execute if score #nfest_node ec.var matches 2 if entity @a[scores={ec.caffl_lf=1..},limit=1] run scoreboard players set #nfest_elig ec.var 1
execute if score #nfest_node ec.var matches 3 if entity @a[scores={ec.caffl_tw=1..},limit=1] run scoreboard players set #nfest_elig ec.var 1
execute if score #nfest_node ec.var matches 4 if entity @a[scores={ec.caffl_sc=1..},limit=1] run scoreboard players set #nfest_elig ec.var 1
execute if score #nfest_node ec.var matches 5 if entity @a[scores={ec.caffl_gw=1..},limit=1] run scoreboard players set #nfest_elig ec.var 1

# Not eligible -> don't force (fall through to the normal weighted pick).
execute if score #nfest_elig ec.var matches 0 run return 0

# Force the pick to the featured type, then commit via the Director's own commit (records
# the lockout + cadence stamp + arms #comp_day_type — the normal commit path, unchanged).
scoreboard players operation #evd_pick ec.var = #nfest_ftype ec.var
function evercraft:event_director/commit_comp
scoreboard players set #nfest_forced_a ec.var 1
