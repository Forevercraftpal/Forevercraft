# =====================================================================
# Seasonal Node Festival — Force the featured node's co-op event (Track B pin)
# =====================================================================
# Called from coop_events/dawn_decision's small festival branch ONLY when #nfest_active.
# Force-fires the featured node's CO-OP event (Track B), bypassing the normal cadence AND
# the Track-B spacing gate — the festival IS the day's ambient event (it runs as the
# calendar event, so #cal_active=1 would otherwise make coop_events/spacing_gate block it).
#
# Still respects the co-op system's OWN no-stack (don't start a second co-op event if one is
# already live / already fired today) — those are checked by the CALLER before this runs.
#
# Sets #nfest_forced_b ec.var = 1 iff it fired a co-op event (so the caller returns and skips
# its normal logic). 0 = not forced (featured node not eligible) -> caller falls through to
# the normal Track-B co-op decision.
#
# Node id is the SAME for the festival and the co-op system (1..5 = lm/lf/tw/sc/gw).
# ---------------------------------------------------------------------
scoreboard players set #nfest_forced_b ec.var 0

# Eligibility: >=1 online player with the featured node's class unlocked (mirrors build_pool).
scoreboard players set #nfest_elig_b ec.var 0
execute if score #nfest_node ec.var matches 1 if entity @a[scores={ec.caffl_lm=1..},limit=1] run scoreboard players set #nfest_elig_b ec.var 1
execute if score #nfest_node ec.var matches 2 if entity @a[scores={ec.caffl_lf=1..},limit=1] run scoreboard players set #nfest_elig_b ec.var 1
execute if score #nfest_node ec.var matches 3 if entity @a[scores={ec.caffl_tw=1..},limit=1] run scoreboard players set #nfest_elig_b ec.var 1
execute if score #nfest_node ec.var matches 4 if entity @a[scores={ec.caffl_sc=1..},limit=1] run scoreboard players set #nfest_elig_b ec.var 1
execute if score #nfest_node ec.var matches 5 if entity @a[scores={ec.caffl_gw=1..},limit=1] run scoreboard players set #nfest_elig_b ec.var 1
execute if score #nfest_elig_b ec.var matches 0 run return 0

# Force the pick to the featured node, then fire the co-op event via the system's OWN begin
# (snapshots baselines, scales the goal, stamps Track B, arms the bossbar/tick — unchanged).
scoreboard players operation #coev_pick ec.var = #nfest_node ec.var
function evercraft:coop_events/begin
scoreboard players set #nfest_forced_b ec.var 1
