# =====================================================================
# Seasonal Node Festival — Competition reward bonus (run AS+AT @s)
# =====================================================================
# Called from competition/reward/by_contribution's small festival hook. Grants an ADDITIVE
# festival bonus on top of the normal contribution-scaled reward when the active competition
# is the festival's FEATURED node's contest (#comp_active == #nfest_node + 6 while a festival
# is running). Additive (not a tier rewrite) so by_contribution's disjoint tier branches stay
# untouched. Inert unless the caller already confirmed the festival + featured-node match.
#
# BONUS (parked Q4): one extra Reward Crate + 100 XP + 3 Coins. The crate is now animatable
# and rolled like a chest-node open (the wrapper computes its own inv-full). Non-bold notify.
# ---------------------------------------------------------------------
# Bonus Reward Crate (animatable, rolled like a chest-node open).
function evercraft:util/give_node_crate
# Bonus XP + Coins (+ #rm_coins mirror).
experience add @s 100 points
scoreboard players add @s ec.coins 3
scoreboard players add #rm_coins ec.var 3
# Feedback (non-bold action-bar).
data modify storage evercraft:notify stage.c set value [{text:"Festival bonus! ",color:"light_purple"},{text:"+Reward Crate + 100 XP + 3 Coins",color:"yellow"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
