# =====================================================================
# Seasonal Node Festival — Tick (1s self-schedule)
# =====================================================================
# Existence/active-gated. While the festival is live, marks each player who has contributed
# to TODAY's featured node (current count - today's baseline >= threshold) as having
# participated today (ec.nfest_today = 1). The day-rollover (advance_day / end) folds
# ec.nfest_today into the per-player day count ec.nfest_days.
# ---------------------------------------------------------------------

# Idle gate: no festival -> cheap 20s heartbeat and bail.
execute unless score #nfest_active ec.var matches 1 run schedule function evercraft:node_festival/tick 20s replace
execute unless score #nfest_active ec.var matches 1 run return 0

# Active: 1s tick.
schedule function evercraft:node_festival/tick 20t replace

# Mark participation for players not yet counted today (debounced by ec.nfest_today).
execute as @a[scores={ec.nfest_today=0}] run function evercraft:node_festival/mark_participation

# --- Bossbar visibility cycle (Joseph 2026-06-12) ---
# Phase advances 1 unit/s. 0..60 = visible window (1 min). 61..960 = hidden window
# (15 min). Wraps at 961 to keep the cycle going through the whole festival.
# Competition override: while a sub-event (#comp_active >= 1) is showing its own
# bossbar — prospecting race, etc. — the festival bar hides regardless of phase,
# then resumes the natural cycle the moment the event ends.
scoreboard players add #nfest_bar_phase ec.var 1
execute if score #nfest_bar_phase ec.var matches 961.. run scoreboard players set #nfest_bar_phase ec.var 0
execute if score #nfest_bar_phase ec.var matches ..60 if score #comp_active ec.var matches 0 run bossbar set evercraft:node_festival visible true
execute unless score #nfest_bar_phase ec.var matches ..60 run bossbar set evercraft:node_festival visible false
execute unless score #comp_active ec.var matches 0 run bossbar set evercraft:node_festival visible false
