# =====================================================================
# Seasonal Node Festival — End (final day) + capstone payout
# =====================================================================
# Called from node_festival/advance_day on the dawn AFTER the final festival day (when
# #nfest_day exceeds #nfest_dur). advance_day already tallied the final day's participation
# into ec.nfest_days (it tallies BEFORE advancing the day), so end does NOT re-tally — it only
# pays the capstone and cleans up (releasing the calendar slot it held as a Track-B marker).
#
# CAPSTONE GATE (parked Q5): players who participated in >= 3 of the festival days earn the
# capstone. Genuinely special (above a normal event reward) — see capstone/grant.
# ---------------------------------------------------------------------

# --- Capstone payout to qualifying participants (>= 3 festival days). Run AS+AT @s. ---
execute as @a[scores={ec.nfest_days=3..}] at @s run function evercraft:node_festival/capstone/grant

# --- A consolation note to players who took part but fell short of the capstone gate. ---
data modify storage evercraft:notify stage.c set value [{text:"The Node Festival has ended. ",color:"gray"},{text:"Thanks for taking part!",color:"yellow"}]
scoreboard players set #ndur ec.temp 45
execute as @a[scores={ec.nfest_days=1..2}] run function evercraft:util/notify/emit

# --- Closing announce. ---
title @a times 10 50 25
title @a title {text:"Node Festival Ended",color:"light_purple"}
title @a subtitle {text:"Until next season!",color:"gray"}
data modify storage evercraft:notify stage.c set value [{text:"THE NODE FESTIVAL HAS ENDED",color:"light_purple"}]
scoreboard players set #ndur ec.temp 50
execute as @a run function evercraft:util/notify/emit
execute as @a at @s if score @s ec.fx_snd matches 1.. run playsound minecraft:block.beacon.deactivate master @s ~ ~ ~ 0.5 1.0
function evercraft:briefing/log_event {msg:"The Seasonal Node Festival has ended."}

# --- Release the calendar slot (mirrors the other calendar stops: clear active + reset rest).
# Rest TRIPLED 2026-06-06 (4 -> 12) so the next calendar/ambient event is ~1/3 as soon. ---
scoreboard players set #cal_active ec.var 0
scoreboard players set #cal_event_id ec.var 0
scoreboard players set #cal_rest_days ec.var 6

# --- Festival state teardown. (ec.nfest_days persists across the festival to the next one's
# start, which resets it — harmless; nothing reads it between festivals.) ---
scoreboard players set #nfest_active ec.var 0
scoreboard players set #nfest_day ec.var 0
scoreboard players set #nfest_node ec.var 0
scoreboard players set @a ec.nfest_today 0
scoreboard players set @a ec.nfest_base 0
bossbar set evercraft:node_festival visible false
