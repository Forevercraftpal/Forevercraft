# =====================================================================
# Seasonal Node Festival — Day rollover (called from node_festival/dawn, festival active)
# =====================================================================
# Runs once per festival dawn (from luck_buffs/dawn_dispatch, BEFORE the Track A/B pins).
# Tallies the day that just ended into each player's ec.nfest_days, then either advances to
# the next festival day (new featured node + fresh baselines + re-announce) or, if the final
# day has ended, calls end (capstone payout + teardown).
# ---------------------------------------------------------------------

# --- Tally the day that just ended: any player flagged today -> +1 festival day, then clear
# the per-day flag. (Sole gameplay incrementer of ec.nfest_days.) ---
scoreboard players add @a[scores={ec.nfest_today=1..}] ec.nfest_days 1
scoreboard players set @a ec.nfest_today 0

# --- Advance the festival day. ---
scoreboard players add #nfest_day ec.var 1

# --- Festival over? (day > duration) -> end (capstone + teardown), then stop. ---
execute if score #nfest_day ec.var > #nfest_dur ec.var run function evercraft:node_festival/end
execute if score #nfest_day ec.var > #nfest_dur ec.var run return 0

# --- Still running: feature the next node + re-baseline + re-announce. ---
function evercraft:node_festival/pick_node
execute as @a run function evercraft:node_festival/node_count
execute as @a run scoreboard players operation @s ec.nfest_base = #nfest_cur ec.temp
function evercraft:node_festival/announce_day
