# =====================================================================
# Seasonal Node Festival — Cadence trigger (called from node_festival/dawn)
# =====================================================================
# Fires the festival on its own SEASONAL cadence: once per season, early in the season
# (season-day == 1), so each of the 4 seasons gets one Node Festival. (Cadence parked — Q1;
# this is the default.)
#
# NOTE: this runs from luck_buffs/dawn_dispatch (BEFORE calendar/dawn_check's seasons/update),
# so #season_day is NOT yet refreshed for today. We compute the season-day INLINE from the
# already-fresh #visual_day (same formula as seasons/update: (#visual_day % 64) % 16) to avoid
# the ordering dependency. #64 / #16 are load-time constants on ec.const.
#
# GUARDS (all must pass to fire):
#   - not already in a festival (#nfest_active == 0)
#   - the calendar slot is free (#cal_active == 0) — the festival claims the Track-B slot, so
#     it can't start on top of another calendar event
#   - it's the season's festival dawn (season-day == 1)
#   - it didn't already start today (#nfest_last_day != today) — belt-and-suspenders
#   - >= 1 online player has ANY node unlocked (else the festival has nothing to feature)
# Any miss -> silent return (no festival this dawn).
# ---------------------------------------------------------------------
execute if score #nfest_active ec.var matches 1 run return 0
execute if score #cal_active ec.var matches 1 run return 0
execute if score #nfest_last_day ec.var = #visual_day ec.var run return 0

# Compute today's season-day inline: (#visual_day % 64) % 16. Fire only on season-day 1.
scoreboard players operation #nfest_sday ec.temp = #visual_day ec.var
scoreboard players operation #nfest_sday ec.temp %= #64 ec.const
scoreboard players operation #nfest_sday ec.temp %= #16 ec.const
execute unless score #nfest_sday ec.temp matches 1 run return 0

# Eligibility: at least one online player has at least one craft-affinity node unlocked.
# (Per-day node rotation still skips a featured node with no eligible player at fire time —
# see node_festival/start's pin gates.) If NOBODY has any node, don't start the festival.
execute unless entity @a[scores={ec.caffl_lm=1..}] unless entity @a[scores={ec.caffl_lf=1..}] unless entity @a[scores={ec.caffl_tw=1..}] unless entity @a[scores={ec.caffl_sc=1..}] unless entity @a[scores={ec.caffl_gw=1..}] run return 0

# All guards passed -> start the festival.
function evercraft:node_festival/start
