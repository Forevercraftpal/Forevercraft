# =====================================================================
# Seasonal Node Festival — Dawn entry (THE single festival decision point)
# =====================================================================
# Called once per dawn from luck_buffs/dawn_dispatch, BEFORE event_director/dawn_decision
# (Track A) and coop_events/dawn_decision (Track B). Running FIRST is REQUIRED: it sets
# #nfest_active + #nfest_node for TODAY so the Track-A/B festival pins (which read those) fire
# on EVERY festival day — including day 1. (#visual_day is already fresh here; luck_buffs/tick
# updates it just before calling dawn_dispatch.)
#
# This is the SOLE owner of the festival day rollover. The calendar holds #cal_active=1 /
# #cal_event_id=9 only as a Track-B "slot occupied" marker (so other ambient events don't
# stack); it does NOT drive the festival's day count or end.
#
# Branches:
#   A. Festival ACTIVE  -> roll over to the next day (tally yesterday, advance node) or END.
#   B. Festival IDLE    -> maybe start it (season cadence).
# ---------------------------------------------------------------------

# --- Branch A: an active festival advances its day (or ends). advance_day may END the festival
# (sets #nfest_active=0). We do NOT return here anymore — fall through to the festival-day
# pin/self-count below, which is gated on the POST-resolution #nfest_active (so an ended festival
# correctly skips it). #nfest_was_active latches whether Branch A handled today so Branch B's
# maybe_start is skipped (an active festival never tries to start a second one). ---
scoreboard players set #nfest_was_active ec.var 0
execute if score #nfest_active ec.var matches 1 run scoreboard players set #nfest_was_active ec.var 1
execute if score #nfest_active ec.var matches 1 run function evercraft:node_festival/advance_day

# --- Branch B: idle -> try to start the festival this dawn (self-guarded cadence). Skip if
# Branch A already handled an active festival today. ---
execute if score #nfest_was_active ec.var matches 0 run function evercraft:node_festival/maybe_start

# === FESTIVAL PIN-ONE + SELF-COUNT (2026-06-06) ============================================
# Runs once per dawn, only when a festival is LIVE today (post-resolution #nfest_active==1; an
# advance_day that ENDED the festival cleared it, so an ended day correctly skips this).
#  - The festival bossbar counts toward the 2-bar cap: #evt_today_n += 1.
#  - Pick ONE sub-event to pin for today: #nfest_pin = 1 (competition) or 2 (co-op), set ONCE
#    per day here. event_director/dawn_decision force-pins the comp only if #nfest_pin==1;
#    coop_events/dawn_decision force-pins the co-op only if #nfest_pin==2. So a festival day =
#    festival(1) + exactly one pinned sub-event(1) = 2 bars, never the 3-4 pile-up.
execute if score #nfest_active ec.var matches 1 run scoreboard players add #evt_today_n ec.var 1
execute if score #nfest_active ec.var matches 1 store result score #nfest_pin ec.var run random value 1..2
