# Seasonal Node Festival — capstone dynamic XP grant (MACRO).
# Run as @s with storage evercraft:node_festival. experience add takes no scoreboard arg,
# so capstone/grant stores the computed XP at evercraft:node_festival.xp and calls this.
$experience add @s $(xp) points
