# =====================================================================
# Seasonal Node Festival — Capstone reward (run AS+AT @s from end)
# =====================================================================
# The bow on Wave 3: a genuinely SPECIAL reward, a clear notch above a normal co-op event
# payout (whose peak is a single Mythical Crate + Mythical Artifact + 1800 XP + 24 Coins).
# Granted to players who participated in >= 3 festival days; scales modestly with how many
# of the days they took part in (3..5). (Magnitudes parked — Q5.)
#
# REWARD (reuses the standard give idioms — animatable node-crate wrapper for the crates,
# inv-full guard + artifacts/main loot table, ec.coins + #rm_coins mirror, XP via storage-macro):
#   • 2 × Reward Crate  (animatable, each rolled like a chest-node open; double the co-op peak)
#   • 1 × Mythical Artifact
#   • XP    = 2000 + 250 per day participated  (3 days = 2750 .. 5 days = 3250)
#   • Coins = 40 + 5 per day participated      (3 days = 55  .. 5 days = 65)
# Cosmetic title PARKED (Q6) — the special-title family (ec.special_titles + sp.t_* teams +
# Cosmetics GUI page) would need a new title id/team/GUI row, which is a cross-system add, not
# a small reuse. Ship the material capstone; wire a "Festival Champion" title later.
# ---------------------------------------------------------------------

# --- 2 × Reward Crate (animatable, each rolled like a chest-node open) ---
# Two distinct guaranteed crates; the node roll decides WHICH each one is. Each wrapper
# call computes its own inv-full and drops at feet if needed.
function evercraft:util/give_node_crate
function evercraft:util/give_node_crate

# Inv-full guard (for the Mythical Artifact below): drop at feet rather than void on full.
execute store result score #inv_full ec.var run function evercraft:util/check_inv_full

# --- 1 × Mythical Artifact ---
execute if score #inv_full ec.var matches 0 run loot give @s loot evercraft:artifacts/mythical/main
execute if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:artifacts/mythical/main

# --- XP = 2000 + 250 × days (days clamped 3..5 for the scaling). ---
scoreboard players operation #nfest_d ec.temp = @s ec.nfest_days
execute if score #nfest_d ec.temp matches 6.. run scoreboard players set #nfest_d ec.temp 5
scoreboard players set #nfest_xp ec.temp 250
scoreboard players operation #nfest_xp ec.temp *= #nfest_d ec.temp
scoreboard players add #nfest_xp ec.temp 2000
execute store result storage evercraft:node_festival xp int 1 run scoreboard players get #nfest_xp ec.temp
function evercraft:node_festival/capstone/give_xp with storage evercraft:node_festival

# --- Coins = 5 × days, capped at the 25-coin ceiling (+ #rm_coins mirror). (Rebalanced 2026-06-21.) ---
scoreboard players set #nfest_coins ec.temp 5
scoreboard players operation #nfest_coins ec.temp *= #nfest_d ec.temp
execute if score #nfest_coins ec.temp matches 26.. run scoreboard players set #nfest_coins ec.temp 25
scoreboard players operation @s ec.coins += #nfest_coins ec.temp
scoreboard players operation #rm_coins ec.var += #nfest_coins ec.temp

# --- Feedback (non-bold action-bar; shows the special haul + days). ---
title @a times 10 70 30
title @s title {text:"Festival Champion!",color:"gold"}
title @s subtitle {text:"You earned the Node Festival capstone!",color:"light_purple"}
data modify storage evercraft:notify stage.c set value [{text:"Capstone: ",color:"gold"},{text:"2× Reward Crate + Mythical Artifact + ",color:"light_purple"},{score:{name:"#nfest_xp",objective:"ec.temp"},color:"white"},{text:" XP + ",color:"light_purple"},{score:{name:"#nfest_coins",objective:"ec.temp"},color:"white"},{text:" Coins",color:"light_purple"}]
scoreboard players set #ndur ec.temp 70
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 1 1
execute at @s if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.player.levelup master @s ~ ~ ~ 0.8 1.2
