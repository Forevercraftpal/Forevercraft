# Seasonal Node Festival — per-player featured-node harvest count (run as @s).
# Computes THIS player's current LIFETIME count for the festival's featured node
# (#nfest_node 1..5) into #nfest_cur ec.temp. Same Craft-Affinity count sources as the
# Wave-3a/3b node helpers, keyed off #nfest_node so the festival is independent of any
# live competition (#comp_active) or co-op event (#coev_node).
#   1 Lamentor  = ec.caff_st_wool + ec.cnode_shear   (block + sheep shears)
#   2 Lumberfell= #caff_log_rt    (curated axe family, via sum_verbs)
#   3 Terrawarp = #caff_dirt_rt   (curated shovel family, via sum_verbs)
#   4 Sirencall = ec.caff_st_fish (minecraft.custom:fish_caught)
#   5 Gearwright= ec.cnode_craft  (craft actions, sole writer craft_affinity/gw_grant_t1..t5 (+ on_fuse/on_glyph))
# All vanilla-stat / cnode_* sources are read-only here (never violate one-writer).
scoreboard players set #nfest_cur ec.temp 0
execute if score #nfest_node ec.var matches 1 run scoreboard players operation #nfest_cur ec.temp = @s ec.caff_st_wool
execute if score #nfest_node ec.var matches 1 run scoreboard players operation #nfest_cur ec.temp += @s ec.cnode_shear
execute if score #nfest_node ec.var matches 2..3 run function evercraft:craft_affinity/sum_verbs
execute if score #nfest_node ec.var matches 2 run scoreboard players operation #nfest_cur ec.temp = #caff_log_rt ec.temp
execute if score #nfest_node ec.var matches 3 run scoreboard players operation #nfest_cur ec.temp = #caff_dirt_rt ec.temp
execute if score #nfest_node ec.var matches 4 run scoreboard players operation #nfest_cur ec.temp = @s ec.caff_st_fish
execute if score #nfest_node ec.var matches 5 run scoreboard players operation #nfest_cur ec.temp = @s ec.cnode_craft
