# Seasonal Node Festival — map the current festival day to its featured node.
# Default rotation (parked Q3): day -> node id, identity. So day 1 = Lamentor (1),
# day 2 = Lumberfell (2), day 3 = Terrawarp (3), day 4 = Sirencall (4), day 5 = Gearwright
# (5). Sole writer of #nfest_node (alongside start which calls this). Kept as its own fn so
# changing the rotation is a one-file edit.
scoreboard players set #nfest_node ec.var 0
execute if score #nfest_day ec.var matches 1 run scoreboard players set #nfest_node ec.var 1
execute if score #nfest_day ec.var matches 2 run scoreboard players set #nfest_node ec.var 2
execute if score #nfest_day ec.var matches 3 run scoreboard players set #nfest_node ec.var 3
execute if score #nfest_day ec.var matches 4 run scoreboard players set #nfest_node ec.var 4
execute if score #nfest_day ec.var matches 5 run scoreboard players set #nfest_node ec.var 5
