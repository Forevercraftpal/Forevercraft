# =====================================================================
# Seasonal Node Festival — Start (festival day 1)
# =====================================================================
# Claims the calendar slot as event id 9 (Track B / ambient) and arms festival day 1.
# Called only from maybe_start (all guards already passed).
# ---------------------------------------------------------------------

# --- Claim the calendar slot (event id 9) as a Track-B "slot occupied" marker ONLY, so other
# ambient events (calendar/world/co-op) don't stack during the festival. The festival does NOT
# use #cal_event_days for its duration — it self-manages #nfest_day vs #nfest_dur from
# node_festival/dawn. Park #cal_event_days HIGH so the calendar's generic dawn decrement never
# reaches 0 and never ends the festival (the festival ends itself via node_festival/end, which
# releases the slot). ---
scoreboard players set #cal_active ec.var 1
scoreboard players set #cal_event_id ec.var 9
scoreboard players set #cal_event_days ec.var 999

# --- Festival state: day 1, recurrence guard, reset per-player participation. ---
scoreboard players set #nfest_active ec.var 1
scoreboard players set #nfest_day ec.var 1
scoreboard players operation #nfest_last_day ec.var = #visual_day ec.var
scoreboard players set @a ec.nfest_days 0
scoreboard players set @a ec.nfest_today 0
# Reset the bossbar visibility-cycle phase so the festival opens with the bar
# visible for its first minute, then enters the 15-min hidden window.
scoreboard players set #nfest_bar_phase ec.var 0

# --- Featured node for day 1 (rotation: festival day -> node id; default identity, so
# day 1 = node 1 = Lamentor). pick_node maps #nfest_day -> #nfest_node. ---
function evercraft:node_festival/pick_node

# --- Snapshot every player's featured-node baseline for day-1 participation detection. ---
execute as @a run function evercraft:node_festival/node_count
execute as @a run scoreboard players operation @s ec.nfest_base = #nfest_cur ec.temp

# --- Festival-open announce + the day-1 featured-node banner. ---
function evercraft:node_festival/announce_open
function evercraft:node_festival/announce_day
function evercraft:briefing/log_event {msg:"The Seasonal Node Festival has begun!"}

# --- Re-arm the participation tick immediately. ---
schedule function evercraft:node_festival/tick 20t replace
