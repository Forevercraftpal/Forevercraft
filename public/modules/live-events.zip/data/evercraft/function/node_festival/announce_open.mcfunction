# Seasonal Node Festival — Opening announce (once, at festival start).
title @a times 10 70 25
title @a title {text:"Seasonal Node Festival!",color:"light_purple"}
title @a subtitle {text:"Five days celebrating the crafting nodes!",color:"yellow"}

data modify storage evercraft:notify stage.c set value [{text:"THE NODE FESTIVAL BEGINS",color:"light_purple"}]
scoreboard players set #ndur ec.temp 55
execute as @a run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Each day features one node — its contest and realm effort are guaranteed, with bonus rewards!",color:"yellow"}]
scoreboard players set #ndur ec.temp 50
execute as @a run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Take part across the festival to earn a special capstone reward.",color:"green"}]
scoreboard players set #ndur ec.temp 50
execute as @a run function evercraft:util/notify/emit

execute as @a at @s if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.firework_rocket.twinkle master @s ~ ~ ~ 0.9 1.0
execute as @a at @s if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.chime master @s ~ ~ ~ 0.6 1.4
