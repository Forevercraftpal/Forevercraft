# Seasonal Node Festival — per-player participation mark (run as @s from tick).
# A player participates in today's featured node once their count rises above today's
# baseline by the threshold. PARTICIPATION_THRESHOLD = 1 (any single node-action counts —
# the capstone gate is the across-days threshold, not a high per-day bar). Sets
# ec.nfest_today = 1 (debounce); tick only calls this for players still at 0 today.
# node_count writes #nfest_cur for the featured node #nfest_node.
function evercraft:node_festival/node_count
scoreboard players operation #nfest_cur ec.temp -= @s ec.nfest_base
execute if score #nfest_cur ec.temp matches 1.. run scoreboard players set @s ec.nfest_today 1
# Light feedback on the FIRST contribution of the day (gated by the 0->1 flip above).
data modify storage evercraft:notify stage.c set value [{text:"Festival participation recorded for today! ",color:"green"},{text:"(",color:"gray"},{score:{name:"@s",objective:"ec.nfest_days"},color:"white"},{text:" prior days)",color:"gray"}]
scoreboard players set #ndur ec.temp 45
execute if score @s ec.nfest_today matches 1 run function evercraft:util/notify/emit
execute if score @s ec.nfest_today matches 1 if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.experience_orb.pickup master @s ~ ~ ~ 0.3 1.5
