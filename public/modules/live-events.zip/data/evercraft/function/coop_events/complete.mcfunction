# =====================================================================
# Co-op Node Events — Complete (goal reached!)
# =====================================================================
# Fired from tick when #coev_prog >= #coev_goal. Pays the FULL event reward to every
# contributor (scaled by their performance share AND server Dream Rate), announces the
# realm-wide success, and tears the event down.
# ---------------------------------------------------------------------

# --- Find the top contributor's score (the reference for relative performance bands). ---
scoreboard players set #coev_top ec.temp 0
execute as @a[scores={ec.coev_ctrb=1..}] if score @s ec.coev_ctrb > #coev_top ec.temp run scoreboard players operation #coev_top ec.temp = @s ec.coev_ctrb

# --- Compute the server-average Dream Rate (drives the DR multiplier in the reward). ---
function evercraft:world_events/compute_avg_dr

# --- Success banner (title + notify; non-bold popups). ---
title @a times 10 70 30
title @a title {text:"Realm Effort Complete!",color:"green"}
title @a subtitle {text:"The realm reached its goal together!",color:"gold"}
data modify storage evercraft:notify stage.c set value [{text:"REALM EFFORT COMPLETE",color:"green"}]
scoreboard players set #ndur ec.temp 55
execute as @a run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Every helper is rewarded — scaled by effort and the realm's Dream Rate!",color:"gold"}]
scoreboard players set #ndur ec.temp 50
execute as @a run function evercraft:util/notify/emit
execute as @a at @s if score @s ec.fx_snd matches 1.. run playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 1 1.1
execute as @a at @s if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.player.levelup master @s ~ ~ ~ 0.6 1.2

# --- Pay the FULL reward to every contributor (success tier). by_event runs AS+AT @s and
# reads #coev_top (performance reference) + #we_avg_dr (DR multiplier). #coev_partial 0 =
# full payout. The shim copies each player's contribution into the primitive's input
# inside the per-player context so the shared input can't go stale between players. ---
scoreboard players set #coev_partial ec.temp 0
execute as @a[scores={ec.coev_ctrb=1..}] at @s run function evercraft:coop_events/reward/dispatch

# --- Tear down. ---
function evercraft:coop_events/resolve_cleanup
