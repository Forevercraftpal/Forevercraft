# =====================================================================
# Co-op Node Events — Track-B spacing / no-stack gate
# =====================================================================
# Co-op events are TRACK B (ambient). Before committing one this dawn, check the SHARED
# Track-B markers so two ambient events (calendar / world event / co-op) can't stack on
# the same day. Mirrors event_director/we_spacing_gate + cal_spacing_gate exactly.
#
# This gate consults ONLY Track B (#evd_fired_we + the live #cal_active). It does NOT
# block on competitions (Track A) — a noon competition and a co-op event MAY share a day
# (that is the whole point of the two tracks).
#
# Sets #coev_block ec.var:
#   1 = blocked (another ambient event already fired today, OR a calendar event is live,
#       OR a co-op event is already active) -> dawn_decision returns silently
#   0 = clear to evaluate the co-op event
# ---------------------------------------------------------------------
scoreboard players set #coev_block ec.var 0
# Another ambient (Track B) event already fired today (order-independent marker).
execute if score #evd_fired_we ec.var = #visual_day ec.var run scoreboard players set #coev_block ec.var 1
# A calendar event is currently live -> don't stack a co-op event on top.
execute if score #cal_active ec.var matches 1 run scoreboard players set #coev_block ec.var 1
# A co-op event is already active (belt-and-suspenders; commit also no-stacks via #coev_fired_day).
execute if score #coev_active ec.var matches 1 run scoreboard players set #coev_block ec.var 1
