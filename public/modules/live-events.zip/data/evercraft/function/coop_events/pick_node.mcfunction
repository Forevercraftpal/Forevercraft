# =====================================================================
# Co-op Node Events — Pick one node from the eligible pool
# =====================================================================
# Compacts the candidate slots (#coev_c1..#coev_c5, each a node id or 0) into a dense
# list #coev_s1..#coev_sN, then rolls a uniform index 1..N and writes the winning node
# id to #coev_pick. Mirrors event_director/pick_comp.
#
# Precondition: #coev_pool_n >= 1 (the caller checked the pool is non-empty).
# Output: #coev_pick = chosen node id (1..5).
# ---------------------------------------------------------------------

# Compact: append non-zero candidate ids into #coev_sK.
scoreboard players set #coev_n ec.var 0
execute if score #coev_c1 ec.var matches 1.. run function evercraft:coop_events/pick_push {v:1}
execute if score #coev_c2 ec.var matches 1.. run function evercraft:coop_events/pick_push {v:2}
execute if score #coev_c3 ec.var matches 1.. run function evercraft:coop_events/pick_push {v:3}
execute if score #coev_c4 ec.var matches 1.. run function evercraft:coop_events/pick_push {v:4}
execute if score #coev_c5 ec.var matches 1.. run function evercraft:coop_events/pick_push {v:5}

# Roll a uniform index in 1..N (N = #coev_pool_n). Per-N literal rolls avoid modulo bias.
execute if score #coev_pool_n ec.var matches 1 run scoreboard players set #coev_roll ec.var 1
execute if score #coev_pool_n ec.var matches 2 store result score #coev_roll ec.var run random value 1..2
execute if score #coev_pool_n ec.var matches 3 store result score #coev_roll ec.var run random value 1..3
execute if score #coev_pool_n ec.var matches 4 store result score #coev_roll ec.var run random value 1..4
execute if score #coev_pool_n ec.var matches 5 store result score #coev_roll ec.var run random value 1..5

# Read the chosen slot into #coev_pick.
scoreboard players set #coev_pick ec.var 0
execute if score #coev_roll ec.var matches 1 run scoreboard players operation #coev_pick ec.var = #coev_s1 ec.var
execute if score #coev_roll ec.var matches 2 run scoreboard players operation #coev_pick ec.var = #coev_s2 ec.var
execute if score #coev_roll ec.var matches 3 run scoreboard players operation #coev_pick ec.var = #coev_s3 ec.var
execute if score #coev_roll ec.var matches 4 run scoreboard players operation #coev_pick ec.var = #coev_s4 ec.var
execute if score #coev_roll ec.var matches 5 run scoreboard players operation #coev_pick ec.var = #coev_s5 ec.var
