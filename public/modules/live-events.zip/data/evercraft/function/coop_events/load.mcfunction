# =====================================================================
# Co-op Node Events — Load / scoreboard registration (Wave 3b)
# =====================================================================
# Co-op node events are the SPECIAL, server-wide counterpart to the Wave-3a daily
# node COMPETITIONS: the whole realm works ONE node toward a shared goal, and the
# payout is BIGGER than the top competition reward, scaled by performance AND by the
# server-average Dream Rate.
#
# TWO-TRACK MODEL (Unified Event Director): co-op events are TRACK B (ambient) — they
# may share a day with a Track-A competition, but NOT with another Track-B event
# (calendar / world event / another co-op event). This system consults the shared
# Track-B markers (#evd_fired_we / #evd_since_we) and stamps them on fire, exactly
# like calendar/world_events do. It NEVER touches Track A.
#
# NODE IDS (1..5) -> Craft-Affinity gather class:
#   1 = Lamentor   (lm, shearing)      2 = Lumberfell (lf, tree-felling)
#   3 = Terrawarp  (tw, excavation)    4 = Sirencall  (sc, fishing)
#   5 = Gearwright (gw, tinkering)
#
# ONE-WRITER LAW: every register below is written by exactly one coop_events/* fn
# (noted inline). The two per-player counters live in craft_affinity (cnode_*) /
# vanilla stats — read-only here, never written by this system.
# ---------------------------------------------------------------------

# --- Global event state (fake-player scores on ec.var; preserved across /reload) ---
# #coev_active     1 while an event is live (existence gate for the tick). Writers:
#                  begin (set 1) + cleanup (set 0).
# #coev_node       active node id 1..5. Writer: commit.
# #coev_goal       the scaled collective target. Writer: commit.
# #coev_prog       collective progress so far (sum of all contributions). Writer: tick.
# #coev_timer      ticks remaining. Writers: begin (set), tick (decrement).
execute unless score #coev_active ec.var matches 0.. run scoreboard players set #coev_active ec.var 0
execute unless score #coev_node ec.var matches 0.. run scoreboard players set #coev_node ec.var 0
execute unless score #coev_goal ec.var matches 0.. run scoreboard players set #coev_goal ec.var 0
execute unless score #coev_prog ec.var matches 0.. run scoreboard players set #coev_prog ec.var 0
execute unless score #coev_timer ec.var matches 0.. run scoreboard players set #coev_timer ec.var 0

# --- Own cadence / no-stack registers (mirror the Track-B #evd_since_we pattern, but
# co-op-specific so the 3-day-ish spacing applies to co-op events as a class). ---
# #coev_since      dawns since the last co-op event fired (cadence gate). Writers:
#                  dawn_decision (+1/dawn) + commit (reset 0). Bootstrap high so the
#                  first dawn after a fresh load may fire.
# #coev_fired_day  day index this system last fired (own no-stack). Writer: commit.
execute unless score #coev_since ec.var matches 0.. run scoreboard players set #coev_since ec.var 99
execute unless score #coev_fired_day ec.var matches -2147483648.. run scoreboard players set #coev_fired_day ec.var -99

# --- Per-player contribution tracking (delta-track, mirrors competition node comps). ---
# ec.coev_base  per-player baseline node-count snapshotted at event start (and on a
#               mid-event join). Writers: begin + the join hook (dreams/on_join). The
#               two writers are disjoint in time (start vs. join) — the documented
#               competition baseline pattern (ec.comp_baseline is written the same way).
# ec.coev_ctrb  per-player live contribution = current node-count - ec.coev_base.
#               Writer: tick (recomputed each second while the event is live).
scoreboard objectives add ec.coev_base dummy "Co-op Event Baseline"
scoreboard objectives add ec.coev_ctrb dummy "Co-op Event Contribution"

# --- Collective-progress bossbar (blue; 0..#coev_goal). Hidden until an event fires. ---
bossbar add evercraft:coop_node {text:"Realm Effort",color:"blue"}
bossbar set evercraft:coop_node visible false
bossbar set evercraft:coop_node color blue
bossbar set evercraft:coop_node style progress
bossbar set evercraft:coop_node players @a

# --- Stale-state cleanup on /reload: if a reload lands mid-event, fold it down cleanly
# rather than leaving a half-shown bar. The active flag persists, so re-arm the tick. ---
scoreboard players set @a ec.coev_ctrb 0
execute if score #coev_active ec.var matches 1 run bossbar set evercraft:coop_node visible true
execute if score #coev_active ec.var matches 1 run bossbar set evercraft:coop_node players @a
execute if score #coev_active ec.var matches 1 run schedule function evercraft:bossbar/autodismiss/clear/coop_node 30s replace

# --- Start the 1s tick loop (existence/active-gated inside tick). replace so a reload
# doesn't stack schedules (mirrors world_events/load + craft_affinity live-bar). ---
schedule function evercraft:coop_events/tick 20s replace
