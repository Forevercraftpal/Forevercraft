# Co-op Node Events — set the collective bossbar name per active node (#coev_node 1..5).
# The bossbar TITLE may use bold (it is a bossbar, not a center title/subtitle/actionbar/
# notify popup — those are the surfaces the popup-bold law covers; the competition bossbar
# bolds its name the same way). Shows the realm-effort verb so players know what to do.
execute if score #coev_node ec.var matches 1 run bossbar set evercraft:coop_node name [{text:"Realm Effort: ",color:"aqua",bold:true},{text:"Shear together!",color:"yellow"}]
execute if score #coev_node ec.var matches 2 run bossbar set evercraft:coop_node name [{text:"Realm Effort: ",color:"aqua",bold:true},{text:"Fell trees together!",color:"yellow"}]
execute if score #coev_node ec.var matches 3 run bossbar set evercraft:coop_node name [{text:"Realm Effort: ",color:"aqua",bold:true},{text:"Excavate together!",color:"yellow"}]
execute if score #coev_node ec.var matches 4 run bossbar set evercraft:coop_node name [{text:"Realm Effort: ",color:"aqua",bold:true},{text:"Fish together!",color:"yellow"}]
execute if score #coev_node ec.var matches 5 run bossbar set evercraft:coop_node name [{text:"Realm Effort: ",color:"aqua",bold:true},{text:"Tinker together!",color:"yellow"}]
