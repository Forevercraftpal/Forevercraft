# =====================================================================
# Co-op Node Events — Timeout (timer expired, goal NOT reached)
# =====================================================================
# Fired from tick when the timer hits 0 with #coev_prog < #coev_goal. PARTIAL-CREDIT
# path (parked Q4 — default: pay a reduced reward to contributors rather than nothing, so
# a near-miss group effort still feels worth it). Contributors still get the performance×DR
# scaling, but the reward BASE is the reduced (partial) tier inside by_event.
# ---------------------------------------------------------------------

# Top contributor reference + server DR (same as complete).
scoreboard players set #coev_top ec.temp 0
execute as @a[scores={ec.coev_ctrb=1..}] if score @s ec.coev_ctrb > #coev_top ec.temp run scoreboard players operation #coev_top ec.temp = @s ec.coev_ctrb
function evercraft:world_events/compute_avg_dr

# --- Near-miss banner. If NOBODY contributed, just a quiet fade (no reward dispatch). ---
title @a times 10 60 25
title @a title {text:"Realm Effort Ended",color:"gold"}
execute if score #coev_top ec.temp matches 1.. run title @a subtitle {text:"The realm fell short — but helpers still earn a share.",color:"yellow"}
execute if score #coev_top ec.temp matches 0 run title @a subtitle {text:"The realm effort faded with no helpers.",color:"gray"}
data modify storage evercraft:notify stage.c set value [{text:"REALM EFFORT ENDED",color:"gold"}]
scoreboard players set #ndur ec.temp 50
execute as @a run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Progress: ",color:"gray"},{score:{name:"#coev_prog",objective:"ec.var"},color:"white"},{text:" / ",color:"gray"},{score:{name:"#coev_goal",objective:"ec.var"},color:"white"}]
scoreboard players set #ndur ec.temp 45
execute if score #coev_top ec.temp matches 1.. run execute as @a run function evercraft:util/notify/emit
execute as @a at @s if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 0.6 0.8

# --- Partial payout to contributors (reduced base tier). #coev_partial 1 = partial. ---
scoreboard players set #coev_partial ec.temp 1
execute as @a[scores={ec.coev_ctrb=1..}] at @s run function evercraft:coop_events/reward/dispatch

# --- Tear down. ---
function evercraft:coop_events/resolve_cleanup
