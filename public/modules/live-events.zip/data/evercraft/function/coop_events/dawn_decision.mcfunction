# =====================================================================
# Co-op Node Events — Dawn Decision (THE single co-op selection point)
# =====================================================================
# Called once per dawn from luck_buffs/dawn_dispatch, AFTER event_director/dawn_decision
# (Track A). Co-op events are TRACK B (ambient): this function gates against Track B's
# shared spacing (so it can't stack with a calendar / world event / another co-op event)
# but NEVER against Track A — a noon competition may share the day.
#
# Gate order:
#   1. Advance the co-op cadence counter (#coev_since +1).
#   2. Track-B spacing (spacing_gate: no other ambient event today, no live calendar
#      event, not already active).
#   3. Co-op cadence (rare: fire on a low chance unless it's been a long dry spell).
#   4. Eligibility pool (>=1 online player has a node unlocked).
#   5. Pick a node, then begin (which stamps Track B + arms the bossbar/tick).
#
# Empty pool / blocked / cadence-miss -> silent return, ZERO notifications. (Mirrors
# event_director/dawn_decision's silent-gate philosophy.)
# ---------------------------------------------------------------------

# --- Step 1: cadence advance (single daily incrementer for #coev_since). ---
scoreboard players add #coev_since ec.var 1

# Don't start a second co-op event while one is live (own no-stack; order-independent).
execute if score #coev_active ec.var matches 1 run return 0
execute if score #coev_fired_day ec.var = #visual_day ec.var run return 0

# === NODE FESTIVAL PIN (Wave 3c, contained hook) ===========================================
# When a festival is running AND today's pin choice is CO-OP (#nfest_pin==2), PIN today's
# featured node's co-op event: force-fire it, bypassing the cadence AND the Track-B spacing gate
# (the festival IS the day's ambient event — it runs as the calendar event, so #cal_active=1
# would otherwise block the co-op here). The own-no-stack guards above still apply (checked
# before this). force_coop fires via the co-op system's own begin and sets #nfest_forced_b=1 iff
# it fired. If it fired, count it toward the cap (#evt_today_n += 1) and return — skip the normal
# decision.
#
# Cap interaction (2026-06-06): the festival bar already counted itself (festival/dawn set
# #evt_today_n=1 + #nfest_pin). Only force the co-op if a slot remains (#evt_today_n matches ..1).
# When #nfest_active=0 this whole block is a single score check that falls straight through,
# leaving the existing co-op logic below 100% untouched.
execute if score #nfest_active ec.var matches 1 if score #nfest_pin ec.var matches 2 if score #evt_today_n ec.var matches ..1 run function evercraft:node_festival/force_coop
execute if score #nfest_active ec.var matches 1 if score #nfest_forced_b ec.var matches 1 run scoreboard players add #evt_today_n ec.var 1
execute if score #nfest_active ec.var matches 1 if score #nfest_forced_b ec.var matches 1 run return 0

# --- Festival owns slot 2 (2026-06-06): on a festival day the festival already pinned its ONE
# sub-event. If we reached here on a festival day, the pin was NOT co-op (or force_coop wasn't
# eligible) — either way the normal co-op must NOT fire, or we'd add a 3rd bar (festival + pinned
# comp + this co-op). Stay silent on festival days. ---
execute if score #nfest_active ec.var matches 1 run return 0

# --- Step 2: Track-B spacing (shared ambient no-stack). ---
function evercraft:coop_events/spacing_gate
execute if score #coev_block ec.var matches 1 run return 0

# --- Step 3: co-op cadence (RARE special event). Force a fire if it's been a long dry
# spell (>= 5 days since the last co-op event), else fire on a ~1/3 roll. The Track-B
# no-stack above still caps it to at most one ambient event/day. (Curve parked — Q2.) ---
scoreboard players set #coev_cadence_ok ec.var 0
execute if score #coev_since ec.var matches 5.. run scoreboard players set #coev_cadence_ok ec.var 1
execute if score #coev_since ec.var matches ..4 store result score #coev_coin ec.var run random value 1..3
execute if score #coev_since ec.var matches ..4 if score #coev_coin ec.var matches 1 run scoreboard players set #coev_cadence_ok ec.var 1
execute if score #coev_cadence_ok ec.var matches 0 run return 0

# === CROSS-TRACK CAP GATE (2026-06-06) — applied AFTER cadence says "fire", BEFORE begin ===
# HARD CAP: never a 3rd event. If 2 events already committed today, skip silently.
execute if score #evt_today_n ec.var matches 2.. run return 0
# SUPER-RARE 2nd event: if exactly 1 event already committed today, the 2nd slot opens only on a
# ~1/10 roll. Roll 1..10; fire only on a 1 (else stay silent). 0 committed -> fall straight
# through (normal first event of the day).
execute if score #evt_today_n ec.var matches 1 store result score #evt_2nd ec.var run random value 1..10
execute if score #evt_today_n ec.var matches 1 if score #evt_2nd ec.var matches 2..10 run return 0

# --- Step 4: eligible node pool. ---
function evercraft:coop_events/build_pool
execute if score #coev_pool_n ec.var matches 0 run return 0

# --- Step 5: pick one eligible node, then begin. ---
function evercraft:coop_events/pick_node
execute unless score #coev_pick ec.var matches 1..5 run return 0
function evercraft:coop_events/begin

# --- Cross-track cap: this co-op event began -> count it toward today's 2-bar cap. ---
scoreboard players add #evt_today_n ec.var 1
