# Co-op Node Events — pick helper: push a candidate node id onto the dense list.
# Macro arg: {v:<node id>}. Increments #coev_n and writes the id into #coev_s<n>.
# Called only from pick_node; up to 5 invocations (one per surviving candidate).
# Mirrors event_director/pick_push.
scoreboard players add #coev_n ec.var 1
$execute if score #coev_n ec.var matches 1 run scoreboard players set #coev_s1 ec.var $(v)
$execute if score #coev_n ec.var matches 2 run scoreboard players set #coev_s2 ec.var $(v)
$execute if score #coev_n ec.var matches 3 run scoreboard players set #coev_s3 ec.var $(v)
$execute if score #coev_n ec.var matches 4 run scoreboard players set #coev_s4 ec.var $(v)
$execute if score #coev_n ec.var matches 5 run scoreboard players set #coev_s5 ec.var $(v)
