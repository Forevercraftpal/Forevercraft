# Co-op Node Events — reward notify (run as @s from by_event). Non-bold action-bar.
# Reports the crate tier earned + the computed XP / Coins (#ce_xp / #ce_coins ec.temp,
# still live from by_event's math). The crate/artifact names match give_crate/give_artifact.
#   tier 1..3 ornate · 4..5 exquisite · 6 mythical (crate)
execute if score #ce_tier ec.temp matches ..3 run data modify storage evercraft:notify stage.c set value [{text:"Realm reward: ",color:"green"},{text:"Ornate Crate + Artifact + ",color:"gold"},{score:{name:"#ce_xp",objective:"ec.temp"},color:"white"},{text:" XP + ",color:"gold"},{score:{name:"#ce_coins",objective:"ec.temp"},color:"white"},{text:" Coins",color:"gold"}]
execute if score #ce_tier ec.temp matches 4..5 run data modify storage evercraft:notify stage.c set value [{text:"Realm reward: ",color:"green"},{text:"Exquisite Crate + Artifact + ",color:"gold"},{score:{name:"#ce_xp",objective:"ec.temp"},color:"white"},{text:" XP + ",color:"gold"},{score:{name:"#ce_coins",objective:"ec.temp"},color:"white"},{text:" Coins",color:"gold"}]
execute if score #ce_tier ec.temp matches 6.. run data modify storage evercraft:notify stage.c set value [{text:"Realm reward: ",color:"green"},{text:"Mythical Crate + Artifact + ",color:"gold"},{score:{name:"#ce_xp",objective:"ec.temp"},color:"white"},{text:" XP + ",color:"gold"},{score:{name:"#ce_coins",objective:"ec.temp"},color:"white"},{text:" Coins",color:"gold"}]
scoreboard players set #ndur ec.temp 60
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.player.levelup master @s ~ ~ ~ 0.7 1.3
