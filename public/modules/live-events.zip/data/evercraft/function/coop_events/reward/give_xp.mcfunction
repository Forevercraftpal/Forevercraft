# Co-op Node Events — dynamic XP grant (MACRO). Run as @s with storage evercraft:coop_events.
# experience add takes no scoreboard arg, so by_event stores the computed XP at
# evercraft:coop_events.xp (int) and calls this with that storage.
$experience add @s $(xp) points
