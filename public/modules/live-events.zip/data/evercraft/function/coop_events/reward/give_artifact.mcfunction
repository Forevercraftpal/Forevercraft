# Co-op Node Events — give the tier-keyed artifact (run AS+AT @s from by_event).
# Reward tier #ce_tier ec.temp (1..6) -> artifact rarity. Floored at RARE so it matches/
# beats the top competition reward (1st = Rare Artifact). Inv-full guard pre-computed in
# by_event (#inv_full ec.var).
#   tier 1..2 -> rare   tier 3..4 -> ornate   tier 5 -> exquisite   tier 6 -> mythical
execute if score #ce_tier ec.temp matches ..2 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:artifacts/rare/main
execute if score #ce_tier ec.temp matches ..2 if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:artifacts/rare/main
execute if score #ce_tier ec.temp matches 3..4 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:artifacts/ornate/main
execute if score #ce_tier ec.temp matches 3..4 if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:artifacts/ornate/main
execute if score #ce_tier ec.temp matches 5 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:artifacts/exquisite/main
execute if score #ce_tier ec.temp matches 5 if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:artifacts/exquisite/main
execute if score #ce_tier ec.temp matches 6.. if score #inv_full ec.var matches 0 run loot give @s loot evercraft:artifacts/mythical/main
execute if score #ce_tier ec.temp matches 6.. if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:artifacts/mythical/main
