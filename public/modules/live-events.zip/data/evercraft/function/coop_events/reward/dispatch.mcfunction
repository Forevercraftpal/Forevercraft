# Co-op Node Events — per-player reward shim (run AS+AT @s from complete / timeout).
# Feeds this player's contribution into the reusable event-reward primitive (by_event),
# inside the per-player context so the shared fake-player inputs can't go stale between
# players. Mirrors competition/reward/participant's shim shape.
#
# INPUTS already set by the caller (complete / timeout), live here:
#   #coev_top     ec.temp  — the top contributor's score (performance reference).
#   #we_avg_dr    ec.var   — server-average Dream Rate ×10 (DR multiplier source).
#   #coev_partial ec.temp  — 0 = goal reached (full base), 1 = timeout (reduced base).

# This player's contribution (final at resolve time) -> the primitive's performance input.
scoreboard players operation #contrib ec.temp = @s ec.coev_ctrb
# Reference top score for the relative performance bands.
scoreboard players operation #contrib_max ec.temp = #coev_top ec.temp

# Grant the performance × Dream-Rate scaled event reward (crate + artifact + XP + coins).
function evercraft:coop_events/reward/by_event
