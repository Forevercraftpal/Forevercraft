# =====================================================================
# Co-op Node Events — Event-reward primitive (NEW, reusable)
# =====================================================================
# Reward = BASE (always above the top COMPETITION reward) × PERFORMANCE tier × DREAM-RATE
# multiplier. Run AS+AT @s. Pays a crate + an artifact + XP + Coins + a non-bold notify.
#
# INTERFACE
#   IN  #contrib     ec.temp  — this player's contribution (set by dispatch).
#   IN  #contrib_max ec.temp  — the top contributor's score (relative-band reference).
#   IN  #we_avg_dr   ec.var   — server-average Dream Rate ×10 (DR 15.0 = 150).
#   IN  #coev_partial ec.temp — 0 full (goal reached) / 1 partial (timeout near-miss).
#   RUN as @s at @s          — @s = the player to reward; AT @s for the inv-full drop.
#   OUT a crate + artifact (loot give/spawn), XP, ec.coins (+mirror #rm_coins), notify.
#
# WHY IT EXCEEDS COMPETITIONS: the top competition reward (competition/reward/first) is an
# Ornate Crate + 500 XP + 10 Coins + Rare Artifact. The FLOOR of this primitive (token
# performance, low DR, FULL success) is an Ornate Crate + 600 XP + 5 Coins + Rare Artifact:
# the crate/artifact/XP still beat 1st place, while COINS are now globally capped at 25
# (rebalanced 2026-06-21). It scales UP to a Mythical Crate + Mythical Artifact + 1800 XP +
# up to ~24 Coins at strong performance + peak Dream Rate. (Magnitudes parked — Q3.)
#
# DESIGN: a "reward tier" 1..6 is built from PERFORMANCE band (1 token / 2 solid / 3 strong)
# + DREAM-RATE band (0 low / 1 mid / 2 high / 3 peak) -> tier = perf + drband (range 1..6).
# A partial (timeout) result knocks the tier down by 1 (floor 1) and halves XP/coins. The
# tier picks the crate + artifact loot tables; XP/coins are computed arithmetically so the
# performance×DR scaling is exact and continuous.
# ---------------------------------------------------------------------

# --- Inv-full guard (shared): drop at feet rather than void on a full inventory. ---
execute store result score #inv_full ec.var run function evercraft:util/check_inv_full

# === PERFORMANCE band (1..3), RELATIVE to the top contributor (mirrors by_contribution). ===
#   strong  contrib >= 25% of top -> 3
#   solid   contrib >= 10% of top -> 2
#   token   contrib  >= 1         -> 1
scoreboard players set #c100 ec.temp 100
scoreboard players set #c25 ec.temp 25
scoreboard players set #c10 ec.temp 10
scoreboard players operation #ce_thr_strong ec.temp = #contrib_max ec.temp
scoreboard players operation #ce_thr_strong ec.temp *= #c25 ec.temp
scoreboard players operation #ce_thr_strong ec.temp /= #c100 ec.temp
scoreboard players operation #ce_thr_solid ec.temp = #contrib_max ec.temp
scoreboard players operation #ce_thr_solid ec.temp *= #c10 ec.temp
scoreboard players operation #ce_thr_solid ec.temp /= #c100 ec.temp
scoreboard players set #ce_perf ec.temp 1
execute if score #contrib ec.temp >= #ce_thr_solid ec.temp run scoreboard players set #ce_perf ec.temp 2
execute if score #contrib ec.temp >= #ce_thr_strong ec.temp run scoreboard players set #ce_perf ec.temp 3

# === DREAM-RATE band (0..3) from the server average (#we_avg_dr, ×10). ===
#   low  DR <5  (<50)   -> 0     high DR 15..24.9 (150..249) -> 2
#   mid  DR 5..14.9     -> 1     peak DR 25+      (250..)     -> 3
scoreboard players set #ce_drband ec.temp 0
execute if score #we_avg_dr ec.var matches 50..149 run scoreboard players set #ce_drband ec.temp 1
execute if score #we_avg_dr ec.var matches 150..249 run scoreboard players set #ce_drband ec.temp 2
execute if score #we_avg_dr ec.var matches 250.. run scoreboard players set #ce_drband ec.temp 3

# === Reward tier (1..6) = perf(1..3) + drband(0..3). Partial knocks it down 1 (floor 1). ===
scoreboard players operation #ce_tier ec.temp = #ce_perf ec.temp
scoreboard players operation #ce_tier ec.temp += #ce_drband ec.temp
execute if score #coev_partial ec.temp matches 1 run scoreboard players remove #ce_tier ec.temp 1
execute if score #ce_tier ec.temp matches ..0 run scoreboard players set #ce_tier ec.temp 1

# === NODE FESTIVAL BONUS (Wave 3c, contained hook) =========================================
# +1 reward tier when this co-op event is the festival's FEATURED node (#coev_node ==
# #nfest_node while a festival is running). Inert when #nfest_active=0 (a single score check).
# The XP/coins formulas below already scale off #ce_tier, so the bump flows through to crate +
# artifact + XP + coins automatically. Capped at 6 by give_crate/give_artifact's `6..` rows.
execute if score #nfest_active ec.var matches 1 if score #coev_node ec.var = #nfest_node ec.var run scoreboard players add #ce_tier ec.temp 1

# === XP = base × perf × DR-mult, partial halves. Base 200; perf ×1/2/3; DR-mult ×3..6 (÷2). ===
# (DR-mult stored ×2 so a +50% step is integer-exact: low 3 / mid 4 / high 5 / peak 6, ÷2.)
scoreboard players set #ce_xp ec.temp 200
scoreboard players operation #ce_xp ec.temp *= #ce_perf ec.temp
scoreboard players set #ce_drmul ec.temp 3
execute if score #ce_drband ec.temp matches 1 run scoreboard players set #ce_drmul ec.temp 4
execute if score #ce_drband ec.temp matches 2 run scoreboard players set #ce_drmul ec.temp 5
execute if score #ce_drband ec.temp matches 3 run scoreboard players set #ce_drmul ec.temp 6
scoreboard players operation #ce_xp ec.temp *= #ce_drmul ec.temp
scoreboard players set #ce_half ec.temp 2
scoreboard players operation #ce_xp ec.temp /= #ce_half ec.temp
execute if score #coev_partial ec.temp matches 1 run scoreboard players operation #ce_xp ec.temp /= #ce_half ec.temp
# Floor the FULL-success token/low-DR XP at 600 so it always clears 1st place's 500.
execute if score #coev_partial ec.temp matches 0 if score #ce_xp ec.temp matches ..599 run scoreboard players set #ce_xp ec.temp 600
# Grant the dynamic XP via a storage-macro (experience add takes no scoreboard arg directly).
execute store result storage evercraft:coop_events xp int 1 run scoreboard players get #ce_xp ec.temp
function evercraft:coop_events/reward/give_xp with storage evercraft:coop_events

# === Coins = perf×5 + DR-band×2 + festival, partial halves, hard-capped at 25. ===
# Rebalanced 2026-06-21 (global 25-coin cap). Contribution-driven: a token contributor in a
# normal-DR world earns 5, a solid one 10; only STRONG contribution at peak Dream Rate (plus a
# featured-festival node) climbs toward the 25 ceiling. Replaces the old 4×tier / floor-12 curve,
# which paid 12–28 and was a primary coin-inflation source.
scoreboard players operation #ce_coins ec.temp = #ce_perf ec.temp
scoreboard players set #ce_mul5 ec.temp 5
scoreboard players operation #ce_coins ec.temp *= #ce_mul5 ec.temp
# + DR-band × 2 (computed as drband + drband to avoid a constant).
scoreboard players operation #ce_drbonus ec.temp = #ce_drband ec.temp
scoreboard players operation #ce_drbonus ec.temp += #ce_drband ec.temp
scoreboard players operation #ce_coins ec.temp += #ce_drbonus ec.temp
# + a small bonus when this is the festival's FEATURED node.
execute if score #nfest_active ec.var matches 1 if score #coev_node ec.var = #nfest_node ec.var run scoreboard players add #ce_coins ec.temp 3
# Partial (timeout) result halves the coin payout (#ce_half = 2, set above).
execute if score #coev_partial ec.temp matches 1 run scoreboard players operation #ce_coins ec.temp /= #ce_half ec.temp
# Hard cap at the 25-coin ceiling.
execute if score #ce_coins ec.temp matches 26.. run scoreboard players set #ce_coins ec.temp 25
scoreboard players operation @s ec.coins += #ce_coins ec.temp
scoreboard players operation #rm_coins ec.var += #ce_coins ec.temp

# === CRATE by tier (1..6 -> ornate .. mythical; floor ornate so it beats 1st's ornate). ===
# tier 1..3 ornate · 4..5 exquisite · 6 mythical. (All >= ornate — see give_crate.)
function evercraft:coop_events/reward/give_crate

# === ARTIFACT by tier (rare .. mythical; floor rare so it matches/beats 1st's rare). ===
# tier 1..2 rare · 3..4 ornate · 5 exquisite · 6 mythical.
function evercraft:coop_events/reward/give_artifact

# === Feedback (non-bold action-bar notify; shows the tier + DR scaling). ===
function evercraft:coop_events/reward/notify
