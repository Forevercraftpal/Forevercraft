# Co-op Node Events — give an animatable crate (run AS+AT @s from by_event).
# Guaranteed a crate; the node-chest roll decides WHICH (Accessory/Companion/Artifact/Regular).
# The old #ce_tier rarity keying is intentionally dropped — the give-vs-drop and crate type are
# now both decided inside the node-crate wrapper (Joseph 2026-06-05: "guaranteed still, roll
# based on WHAT crate they receive"). The wrapper computes its own inv-full.
execute at @s run function evercraft:util/give_node_crate
