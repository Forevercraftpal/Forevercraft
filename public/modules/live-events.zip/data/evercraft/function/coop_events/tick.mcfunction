# =====================================================================
# Co-op Node Events — Tick (1s self-schedule)
# =====================================================================
# Existence/active-gated: does real work only while an event is live. Recomputes each
# player's contribution (current node-count - baseline), sums them into the collective
# progress, updates the bossbar, and resolves on goal-reached or timeout.
# ---------------------------------------------------------------------

# --- Idle gate: no live event -> re-arm a cheap 20s heartbeat and bail. The dawn decision
# (luck_buffs/dawn_dispatch) is what actually STARTS an event; this loop only runs it. ---
execute unless score #coev_active ec.var matches 1 run schedule function evercraft:coop_events/tick 20s replace
execute unless score #coev_active ec.var matches 1 run return 0

# --- Active: tick at 1s. ---
schedule function evercraft:coop_events/tick 20t replace

# Decrement the timer (1s = 20 ticks).
scoreboard players remove #coev_timer ec.var 20

# --- Recompute collective progress = sum over all players of (current node-count - base).
# Per-player: ec.coev_ctrb = node_count - ec.coev_base (clamped >=0 so an admin wipe that
# zeroes a counter mid-event can't push the sum negative). Then sum into #coev_prog. ---
execute as @a run function evercraft:coop_events/tick_player
scoreboard players set #coev_prog ec.var 0
execute as @a run scoreboard players operation #coev_prog ec.var += @s ec.coev_ctrb

# --- Update the collective bossbar fill (0..goal). ---
execute store result bossbar evercraft:coop_node value run scoreboard players get #coev_prog ec.var

# --- Resolve: goal reached -> success payout; else timer expired -> timeout resolve. ---
execute if score #coev_prog ec.var >= #coev_goal ec.var run function evercraft:coop_events/complete
execute if score #coev_active ec.var matches 1 if score #coev_timer ec.var matches ..0 run function evercraft:coop_events/timeout
