# =====================================================================
# Co-op Node Events — per-player node harvest-count helper
# =====================================================================
# Run as @s = player. Computes THIS player's current LIFETIME successful-harvest count
# for the ACTIVE co-op node (#coev_node 1..5) into #coev_cur ec.temp.
#
# Uses the SAME count sources as the Wave-3a competition node_count (the shared
# Craft-Affinity verb counters), but keyed off #coev_node — NOT #comp_active — so a
# co-op event and a competition can run on the same day, each with its own baseline.
#
# COUNT SOURCES (node id -> source):
#   1 Lamentor (shearing) = ec.caff_st_wool (block-shears) + ec.cnode_shear (sheep-shears)
#   2 Lumberfell (felling)= #caff_log_rt   (curated axe log/wood/stem family, via sum_verbs)
#   3 Terrawarp (digging) = #caff_dirt_rt  (curated shovel soft-block family, via sum_verbs)
#   4 Sirencall (fishing) = ec.caff_st_fish (minecraft.custom:fish_caught)
#   5 Gearwright (tinker) = ec.cnode_craft  (craft actions, sole writer craft_affinity/gw_grant_t1..t5 (+ on_fuse/on_glyph))
#
# ec.caff_st_wool / ec.caff_st_fish are vanilla-stat objectives (auto-incremented, read-only
# here). ec.cnode_shear / ec.cnode_craft are each written by exactly one craft_affinity handler.
# #caff_log_rt / #caff_dirt_rt are fake-player family sums recomputed per-@s by sum_verbs.

scoreboard players set #coev_cur ec.temp 0

# Node 1 — Lamentor (shearing): block-shears + sheep-shears.
execute if score #coev_node ec.var matches 1 run scoreboard players operation #coev_cur ec.temp = @s ec.caff_st_wool
execute if score #coev_node ec.var matches 1 run scoreboard players operation #coev_cur ec.temp += @s ec.cnode_shear

# Node 2/3 — Lumberfell / Terrawarp: compute the curated family sums for this player.
# sum_verbs sets BOTH #caff_log_rt and #caff_dirt_rt on ec.temp; call it once when needed.
execute if score #coev_node ec.var matches 2..3 run function evercraft:craft_affinity/sum_verbs
execute if score #coev_node ec.var matches 2 run scoreboard players operation #coev_cur ec.temp = #caff_log_rt ec.temp
execute if score #coev_node ec.var matches 3 run scoreboard players operation #coev_cur ec.temp = #caff_dirt_rt ec.temp

# Node 4 — Sirencall (fishing): fish caught (vanilla stat).
execute if score #coev_node ec.var matches 4 run scoreboard players operation #coev_cur ec.temp = @s ec.caff_st_fish

# Node 5 — Gearwright (tinkering): craft actions.
execute if score #coev_node ec.var matches 5 run scoreboard players operation #coev_cur ec.temp = @s ec.cnode_craft
