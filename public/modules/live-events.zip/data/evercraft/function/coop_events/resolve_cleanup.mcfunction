# Co-op Node Events — Resolve cleanup (after complete or timeout).
# Resets live event state + hides the collective bossbar. Does NOT touch the Track-B
# spacing markers (#evd_fired_we etc.) — those were stamped at begin and must persist for
# the rest of the day so no other ambient event stacks. The cadence (#coev_since) was
# reset at begin and keeps advancing each dawn from there.
scoreboard players set #coev_active ec.var 0
scoreboard players set #coev_node ec.var 0
scoreboard players set #coev_goal ec.var 0
scoreboard players set #coev_prog ec.var 0
scoreboard players set #coev_timer ec.var 0
scoreboard players set @a ec.coev_ctrb 0
scoreboard players set @a ec.coev_base 0
bossbar set evercraft:coop_node visible false
