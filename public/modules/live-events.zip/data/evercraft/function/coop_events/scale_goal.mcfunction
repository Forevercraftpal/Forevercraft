# =====================================================================
# Co-op Node Events — Scale the shared goal by online-eligible player count
# =====================================================================
# Computes #coev_goal = (per-player target for the chosen node) × (online players who
# have THAT node unlocked), floored to a minimum so a 1-player realm still gets a real
# (but solo-achievable) goal. Inputs: #coev_pick (node id 1..5) already chosen.
# Output: #coev_goal ec.var + #coev_eligible ec.var (the eligible-player count used).
# Writer of #coev_goal / #coev_eligible: this fn (called only from begin).
#
# PER-PLAYER TARGETS (#coev_per) are tuned to each verb's rough rate over a 10-minute
# window so every node is a real group effort, not trivially solo-completed, and the
# different verb speeds stay comparable (digging/felling fast, fishing/tinkering slow):
#   1 Lamentor  (shear)  120/player   2 Lumberfell (fell) 150/player
#   3 Terrawarp (dig)    200/player   4 Sirencall  (fish)  40/player
#   5 Gearwright (tinker) 60/player
# (Exact per-player targets + the floor are parked — Q1.)
# ---------------------------------------------------------------------

# --- Count online players who have the CHOSEN node's class unlocked (the eligible set). ---
scoreboard players set #coev_eligible ec.var 0
execute if score #coev_pick ec.var matches 1 store result score #coev_eligible ec.var if entity @a[scores={ec.caffl_lm=1..}]
execute if score #coev_pick ec.var matches 2 store result score #coev_eligible ec.var if entity @a[scores={ec.caffl_lf=1..}]
execute if score #coev_pick ec.var matches 3 store result score #coev_eligible ec.var if entity @a[scores={ec.caffl_tw=1..}]
execute if score #coev_pick ec.var matches 4 store result score #coev_eligible ec.var if entity @a[scores={ec.caffl_sc=1..}]
execute if score #coev_pick ec.var matches 5 store result score #coev_eligible ec.var if entity @a[scores={ec.caffl_gw=1..}]
# Safety floor: at least 1 (pick was eligible, so >=1 — defensive against a race).
execute if score #coev_eligible ec.var matches ..0 run scoreboard players set #coev_eligible ec.var 1

# --- Per-player target for the chosen node. ---
scoreboard players set #coev_per ec.var 0
execute if score #coev_pick ec.var matches 1 run scoreboard players set #coev_per ec.var 120
execute if score #coev_pick ec.var matches 2 run scoreboard players set #coev_per ec.var 150
execute if score #coev_pick ec.var matches 3 run scoreboard players set #coev_per ec.var 200
execute if score #coev_pick ec.var matches 4 run scoreboard players set #coev_per ec.var 40
execute if score #coev_pick ec.var matches 5 run scoreboard players set #coev_per ec.var 60

# --- Goal = per-player target × eligible count, floored at the single-player target. ---
scoreboard players operation #coev_goal ec.var = #coev_per ec.var
scoreboard players operation #coev_goal ec.var *= #coev_eligible ec.var
execute if score #coev_goal ec.var < #coev_per ec.var run scoreboard players operation #coev_goal ec.var = #coev_per ec.var
