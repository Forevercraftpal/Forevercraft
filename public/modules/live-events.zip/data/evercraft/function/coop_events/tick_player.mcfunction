# Co-op Node Events — per-player contribution recompute (run as @s from tick).
# ec.coev_ctrb = current node-count - ec.coev_base, clamped >= 0. node_count writes
# #coev_cur for the active node. The clamp guards the rare admin-wipe-mid-event case
# (a zeroed counter could otherwise read negative and corrupt the collective sum).
function evercraft:coop_events/node_count
scoreboard players operation @s ec.coev_ctrb = #coev_cur ec.temp
scoreboard players operation @s ec.coev_ctrb -= @s ec.coev_base
execute if score @s ec.coev_ctrb matches ..-1 run scoreboard players set @s ec.coev_ctrb 0
