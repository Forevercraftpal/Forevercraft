# =====================================================================
# Co-op Node Events — Build eligible node pool
# =====================================================================
# For each of the 5 nodes, mark it a candidate iff >= 1 ONLINE player has that node's
# Craft-Affinity class UNLOCKED (ec.caffl_<code> matches 1.. — the same eligibility gate
# as the Wave-3a node competitions, so a chosen co-op goal is actually achievable).
#
# Unlike the competitions there is NO per-node lockout here (co-op events are RARE — the
# Track-B cadence already spaces them out as a class). A node is a candidate purely on
# eligibility.
#
# Outputs: #coev_c1..#coev_c5 (node id 1..5, or 0) + #coev_pool_n (count). Writer: this fn.
#
# Node-id -> caff code: 1=lm 2=lf 3=tw 4=sc 5=gw.
# ---------------------------------------------------------------------
scoreboard players set #coev_c1 ec.var 0
scoreboard players set #coev_c2 ec.var 0
scoreboard players set #coev_c3 ec.var 0
scoreboard players set #coev_c4 ec.var 0
scoreboard players set #coev_c5 ec.var 0
scoreboard players set #coev_pool_n ec.var 0

# Node 1 — Lamentor (shearing)
execute if entity @a[scores={ec.caffl_lm=1..},limit=1] run scoreboard players set #coev_c1 ec.var 1
execute if score #coev_c1 ec.var matches 1 run scoreboard players add #coev_pool_n ec.var 1
# Node 2 — Lumberfell (tree-felling)
execute if entity @a[scores={ec.caffl_lf=1..},limit=1] run scoreboard players set #coev_c2 ec.var 2
execute if score #coev_c2 ec.var matches 2 run scoreboard players add #coev_pool_n ec.var 1
# Node 3 — Terrawarp (excavation)
execute if entity @a[scores={ec.caffl_tw=1..},limit=1] run scoreboard players set #coev_c3 ec.var 3
execute if score #coev_c3 ec.var matches 3 run scoreboard players add #coev_pool_n ec.var 1
# Node 4 — Sirencall (fishing)
execute if entity @a[scores={ec.caffl_sc=1..},limit=1] run scoreboard players set #coev_c4 ec.var 4
execute if score #coev_c4 ec.var matches 4 run scoreboard players add #coev_pool_n ec.var 1
# Node 5 — Gearwright (tinkering)
execute if entity @a[scores={ec.caffl_gw=1..},limit=1] run scoreboard players set #coev_c5 ec.var 5
execute if score #coev_c5 ec.var matches 5 run scoreboard players add #coev_pool_n ec.var 1
