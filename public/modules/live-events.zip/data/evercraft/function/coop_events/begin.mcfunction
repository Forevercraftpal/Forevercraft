# =====================================================================
# Co-op Node Events — Begin the chosen event (commit + announce)
# =====================================================================
# Input: #coev_pick (1..5) = chosen node. Arms the live event: sets node + scaled goal,
# snapshots per-player baselines, stamps Track B's shared spacing, shows the collective
# bossbar, announces, and lets the 1s tick (coop_events/tick) take over.
# ---------------------------------------------------------------------

# --- Commit: active node + duration. Duration = 12000 ticks of game time (~30 min real
# at the slow day rate — a co-op event runs longer than a 5-min competition). ---
scoreboard players operation #coev_node ec.var = #coev_pick ec.var
scoreboard players set #coev_active ec.var 1
scoreboard players set #coev_prog ec.var 0
scoreboard players set #coev_timer ec.var 12000

# --- Scale the shared goal by online-eligible player count. ---
function evercraft:coop_events/scale_goal

# --- Per-player baseline snapshot: every player's current node-count -> ec.coev_base,
# and clear live contribution. node_count writes #coev_cur for #coev_node. ---
scoreboard players set @a ec.coev_ctrb 0
execute as @a run function evercraft:coop_events/node_count
execute as @a run scoreboard players operation @s ec.coev_base = #coev_cur ec.temp

# --- TRACK-B STAMP: a co-op event (ambient) is firing today. Reset the shared Track-B
# cadence + set the no-stack marker so calendar/world events can't stack today. Also
# reset this system's OWN cadence. Mirrors cal_on_commit / omens/world_events/begin. ---
scoreboard players operation #evd_last_we ec.var = #visual_day ec.var
scoreboard players set #evd_since_we ec.var 0
scoreboard players operation #evd_fired_we ec.var = #visual_day ec.var
scoreboard players set #coev_since ec.var 0
scoreboard players operation #coev_fired_day ec.var = #visual_day ec.var

# --- Arm the collective bossbar (0..goal). ---
execute store result bossbar evercraft:coop_node max run scoreboard players get #coev_goal ec.var
bossbar set evercraft:coop_node value 0
bossbar set evercraft:coop_node visible true
bossbar set evercraft:coop_node players @a
schedule function evercraft:bossbar/autodismiss/clear/coop_node 15s replace
function evercraft:coop_events/set_bossbar_name

# --- Announce (per-node) + the briefing log. ---
function evercraft:coop_events/announce
function evercraft:briefing/log_event {msg:"A Realm Effort has begun!"}

# --- Re-arm the 1s tick immediately so progress shows without waiting for the 20s idle. ---
schedule function evercraft:coop_events/tick 20t replace
