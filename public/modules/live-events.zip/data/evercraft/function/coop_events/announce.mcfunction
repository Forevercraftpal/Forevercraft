# Co-op Node Events — Announce the realm-wide effort (per active node #coev_node).
# Title/subtitle + notify lines are NEVER bold (popup-bold law). The goal number is read
# live from #coev_goal via a {score} component. Mirrors the calendar/competition announce
# cadence (title splash + a few staged notify lines + sound).

title @a times 10 70 20
title @a title {text:"Realm Effort!",color:"aqua"}
# Per-node subtitle (the verb the realm is rallying around).
execute if score #coev_node ec.var matches 1 run title @a subtitle {text:"Shear together for the realm!",color:"yellow"}
execute if score #coev_node ec.var matches 2 run title @a subtitle {text:"Fell trees together for the realm!",color:"yellow"}
execute if score #coev_node ec.var matches 3 run title @a subtitle {text:"Excavate together for the realm!",color:"yellow"}
execute if score #coev_node ec.var matches 4 run title @a subtitle {text:"Fish together for the realm!",color:"yellow"}
execute if score #coev_node ec.var matches 5 run title @a subtitle {text:"Tinker together for the realm!",color:"yellow"}

data modify storage evercraft:notify stage.c set value [{text:"A REALM EFFORT BEGINS",color:"aqua"}]
scoreboard players set #ndur ec.temp 50
execute as @a run function evercraft:util/notify/emit

# Per-node goal line (shows the scaled target).
execute if score #coev_node ec.var matches 1 run data modify storage evercraft:notify stage.c set value [{text:"Goal: shear ",color:"yellow"},{score:{name:"#coev_goal",objective:"ec.var"},color:"white"},{text:" (sheep, leaves, grass) together!",color:"yellow"}]
execute if score #coev_node ec.var matches 2 run data modify storage evercraft:notify stage.c set value [{text:"Goal: fell ",color:"yellow"},{score:{name:"#coev_goal",objective:"ec.var"},color:"white"},{text:" logs together!",color:"yellow"}]
execute if score #coev_node ec.var matches 3 run data modify storage evercraft:notify stage.c set value [{text:"Goal: dig ",color:"yellow"},{score:{name:"#coev_goal",objective:"ec.var"},color:"white"},{text:" soft blocks together!",color:"yellow"}]
execute if score #coev_node ec.var matches 4 run data modify storage evercraft:notify stage.c set value [{text:"Goal: catch ",color:"yellow"},{score:{name:"#coev_goal",objective:"ec.var"},color:"white"},{text:" fish together!",color:"yellow"}]
execute if score #coev_node ec.var matches 5 run data modify storage evercraft:notify stage.c set value [{text:"Goal: craft ",color:"yellow"},{score:{name:"#coev_goal",objective:"ec.var"},color:"white"},{text:" items together!",color:"yellow"}]
scoreboard players set #ndur ec.temp 50
execute as @a run function evercraft:util/notify/emit

data modify storage evercraft:notify stage.c set value [{text:"Everyone who helps shares a reward — bigger the more the realm dreams!",color:"green"}]
scoreboard players set #ndur ec.temp 45
execute as @a run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Watch the Realm Effort bar. Duration: ~30 minutes.",color:"gray"}]
scoreboard players set #ndur ec.temp 40
execute as @a run function evercraft:util/notify/emit

# Sound (rallying chord).
execute as @a at @s if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.firework_rocket.twinkle master @s ~ ~ ~ 0.8 1.2
execute as @a at @s if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.5 1.5
