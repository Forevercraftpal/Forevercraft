# =====================================================================
# Unified Event Director — World-event spacing / no-stack gate (Track B)
# =====================================================================
# World events are ambient (no participation requirement) so they always pass
# ELIGIBILITY, but they must still respect Track B SPACING: don't begin a
# spontaneous world event when another AMBIENT (Track B) event already fired
# today, or while a calendar event is currently running.
#
# TWO-TRACK MODEL: this gate consults ONLY Track B (#evd_fired_we) + the live
# #cal_active guard. It does NOT block on competitions (Track A) — a noon
# competition and a world event MAY share a day.
#
# Sets #evd_we_block ec.var:
#   1 = blocked this evaluation (another ambient event fired today, OR a calendar
#       event is active) -> world_events/check_conditions returns early
#   0 = clear to evaluate world-event conditions
# ---------------------------------------------------------------------
scoreboard players set #evd_we_block ec.var 0
# Another ambient (Track B) event already fired today (order-independent marker).
execute if score #evd_fired_we ec.var = #visual_day ec.var run scoreboard players set #evd_we_block ec.var 1
# A calendar event is currently live -> don't stack a world event on top.
execute if score #cal_active ec.var matches 1 run scoreboard players set #evd_we_block ec.var 1
