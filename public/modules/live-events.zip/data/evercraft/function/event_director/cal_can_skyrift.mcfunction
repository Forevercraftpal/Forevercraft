# =====================================================================
# Unified Event Director — Skyrift live-eligibility check
# =====================================================================
# Sets #evd_skyrift_ok ec.var = 1 iff at least one ONLINE player currently has
# an elytra in their chestplate slot. This replaces the old countdown/swap hack
# (mount_training/skyrift/precheck_or_swap): the Director only SELECTS Skyrift
# when someone already has wings, so it then fires cleanly with no countdown.
# Read by calendar/pick_event to reject a Skyrift roll when no one is eligible.
# ---------------------------------------------------------------------
scoreboard players set #evd_skyrift_ok ec.var 0
execute as @a if items entity @s armor.chest minecraft:elytra run scoreboard players set #evd_skyrift_ok ec.var 1
