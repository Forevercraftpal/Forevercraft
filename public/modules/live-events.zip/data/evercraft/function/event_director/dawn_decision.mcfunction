# =====================================================================
# Unified Event Director — Dawn Decision (THE single decision point)
# =====================================================================
# Called once per dawn from luck_buffs/dawn_dispatch (replaces the old
# competition/schedule 40%-roll). This function owns TRACK A (competitions); it
# also advances the per-dawn day-counter for BOTH tracks (it is the single daily
# incrementer for #evd_since_comp AND #evd_since_we).
#
# TWO-TRACK MODEL (owner decision 2026-06-05): competitions (Track A) and ambient
# world/calendar events (Track B) are INDEPENDENT — a noon competition and an
# ambient event MAY share a day. This function does NOT cross-block against
# Track B; it only gates Track A against itself.
#
# Track A gate order, then arm noon (commit_comp):
#   1. Build eligible pool  (build_comp_pool: iron+/utensil/rank gate + 3-day lockout)
#   2. Per-type 3-day lockout  (applied inside build_comp_pool)
#   3. ~4-day cadence (force at 4 + light off-day coin) (the #evd_since_comp gate, below)
#   4. Pick one survivor       (pick_comp)
#   5. ONLY NOW commit + arm   (commit_comp — records lockout, sets #comp_day_type)
#
# If the eligible pool is empty -> return silently, ZERO notifications.
# NOTHING in this file or its callees announces to players; the competition's
# "Today's Competition" announcement now fires at NOON via competition/start,
# behind this gate.
# ---------------------------------------------------------------------

# Snapshot today's day index (maintained every second by luck_buffs/tick).
scoreboard players operation #evd_today ec.var = #visual_day ec.var

# --- Per-dawn day-counter advance for BOTH tracks (single daily incrementer) ---
# Track B (#evd_since_we) is advanced here too; its resets live in cal_on_commit
# + omens/world_events/begin. This keeps "days since" current for both tracks
# even though only Track A is decided in this function.
scoreboard players add #evd_since_we ec.var 1

# Don't decide a competition if one is already active/queued today (legacy guard).
execute if score #comp_active ec.var matches 1..11 run return 0

# Track A self-no-stack: if a competition already fired/was queued today, don't
# re-commit. Order-independent via #evd_fired_comp. (Does NOT consult Track B —
# competitions and ambient events may coexist.)
execute if score #evd_fired_comp ec.var = #evd_today ec.var run return 0

# === NODE FESTIVAL PIN (Wave 3c, contained hook) ===========================================
# When a festival is running AND today's pin choice is COMPETITION (#nfest_pin==1), PIN today's
# featured node's competition: force-select it and commit, bypassing the normal pool + per-type
# lockout + cadence. force_comp commits via the Director's own commit_comp (lockout/cadence
# stamp + arms #comp_day_type) and sets #nfest_forced_a=1 iff it forced a pick. If it forced,
# count it toward the cap (#evt_today_n += 1) and return — skip the normal decision.
#
# Cap interaction (2026-06-06): the festival bar already counted itself (festival/dawn set
# #evt_today_n=1 + #nfest_pin). Only force the comp if a slot remains (#evt_today_n matches ..1).
# On a festival day this is always true at this point (festival=1, comp not yet fired). When
# #nfest_active=0 this whole block is a single score check that falls straight through, leaving
# the existing weighted logic below 100% untouched.
execute if score #nfest_active ec.var matches 1 if score #nfest_pin ec.var matches 1 if score #evt_today_n ec.var matches ..1 run function evercraft:node_festival/force_comp
execute if score #nfest_active ec.var matches 1 if score #nfest_forced_a ec.var matches 1 run scoreboard players add #evt_today_n ec.var 1
execute if score #nfest_active ec.var matches 1 if score #nfest_forced_a ec.var matches 1 run return 0

# Default: no competition today (clears any stale queued type).
scoreboard players set #comp_day_type ec.var 0
scoreboard players set #evd_pick ec.var 0

# --- Festival owns slot 2 (2026-06-06): on a festival day the festival already pinned its ONE
# sub-event (comp if #nfest_pin==1, co-op if ==2). If we reached here on a festival day, the pin
# was NOT competition (or force_comp wasn't eligible) — either way the normal comp must NOT fire,
# or we'd add a 3rd bar (festival + pinned co-op + this comp). Stay silent on festival days. ---
execute if score #nfest_active ec.var matches 1 run return 0

# --- Cadence bookkeeping: another dawn has passed since the last COMPETITION ---
scoreboard players add #evd_since_comp ec.var 1

# --- Step 3: Track A cadence gate (2026-06-06: ~every 4 days) -------------------
# If it has been >= 4 days since the last competition, force a fire today (caps the
# gap at 4). Otherwise (0..3 days since), fire only on a ~1/4 roll so competitions
# average ~every 4 days.
scoreboard players set #evd_cadence_ok ec.var 0
execute if score #evd_since_comp ec.var matches 4.. run scoreboard players set #evd_cadence_ok ec.var 1
execute if score #evd_since_comp ec.var matches ..3 store result score #evd_coin ec.var run random value 1..4
execute if score #evd_since_comp ec.var matches ..3 if score #evd_coin ec.var matches 1 run scoreboard players set #evd_cadence_ok ec.var 1

# Cadence says "not today" -> stay silent.
execute if score #evd_cadence_ok ec.var matches 0 run return 0

# === CROSS-TRACK CAP GATE (2026-06-06) — applied AFTER cadence says "fire", BEFORE commit ===
# HARD CAP: never a 3rd event. If 2 events already committed today, skip silently.
execute if score #evt_today_n ec.var matches 2.. run return 0
# SUPER-RARE 2nd event: if exactly 1 event already committed today, the 2nd slot opens only on a
# ~1/10 roll. Roll 1..10; fire only on a 1 (else stay silent). 0 committed -> fall straight
# through (normal first event of the day).
execute if score #evt_today_n ec.var matches 1 store result score #evt_2nd ec.var run random value 1..10
execute if score #evt_today_n ec.var matches 1 if score #evt_2nd ec.var matches 2..10 run return 0

# --- Steps 1+2: build the eligible+unlocked competition pool -----------------
function evercraft:event_director/build_comp_pool

# Empty pool -> silent return, ZERO notifications.
execute if score #evd_pool_n ec.var matches 0 run return 0

# --- Step 4: pick one survivor at random ------------------------------------
function evercraft:event_director/pick_comp

# Safety: pick_comp should always yield 1..11 when pool_n>=1; bail silently if not.
execute unless score #evd_pick ec.var matches 1..11 run return 0

# --- Step 5: commit (record lockout + cadence, arm noon competition) ---------
function evercraft:event_director/commit_comp

# --- Cross-track cap: this competition committed -> count it toward today's 2-bar cap. ---
scoreboard players add #evt_today_n ec.var 1
