# Event Director — Tool tag: player obtained an IRON+ hoe (crop harvest eligibility)
# Fired by advancement evercraft:event_director/has_tool/hoe (inventory_changed,
# #evercraft:event_director/iron_hoe = iron/diamond/netherite ONLY — wood/stone/
# gold do NOT qualify). @s = that player. One-shot, never cleared.
scoreboard players set @s ec.has_hoe 1
advancement revoke @s only evercraft:event_director/has_tool/hoe
