# Event Director — Tool tag: player obtained the Cooking Utensil (cooking eligibility)
# Fired by advancement evercraft:event_director/has_tool/utensil (inventory_changed,
# minecraft:wooden_shovel with custom_data {cooking_utensil:true}). @s = that player.
# One-shot, never cleared.
scoreboard players set @s ec.has_utensil 1
advancement revoke @s only evercraft:event_director/has_tool/utensil
