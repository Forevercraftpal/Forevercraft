# Event Director — Tool tag: player obtained an IRON+ pickaxe (mining/prospecting)
# Fired by advancement evercraft:event_director/has_tool/pickaxe (inventory_changed,
# #evercraft:event_director/iron_pickaxe = iron/diamond/netherite ONLY — wood/
# stone/gold do NOT qualify). @s = that player. One-shot: set the persistent flag,
# then revoke so the criterion frees up. The flag is NEVER cleared — it marks
# "this player has ever held an iron-or-better pickaxe".
scoreboard players set @s ec.has_pickaxe 1
advancement revoke @s only evercraft:event_director/has_tool/pickaxe
