# Event Director — Tool tag: player obtained a fishing rod (fishing eligibility)
# Fired by advancement evercraft:event_director/has_tool/rod (inventory_changed,
# minecraft:fishing_rod). @s = that player. One-shot, never cleared.
scoreboard players set @s ec.has_rod 1
advancement revoke @s only evercraft:event_director/has_tool/rod
