# Event Director — Tool tag: player obtained shears (Lamentor eligibility)
# Fired by advancement evercraft:event_director/has_tool/shears (inventory_changed,
# minecraft:shears). @s = that player. One-shot, never cleared.
scoreboard players set @s ec.has_shears 1
advancement revoke @s only evercraft:event_director/has_tool/shears
