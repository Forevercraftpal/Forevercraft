# Event Director — Tool tag: player obtained an IRON+ axe (foraging eligibility)
# Fired by advancement evercraft:event_director/has_tool/axe (inventory_changed,
# #evercraft:event_director/iron_axe = iron/diamond/netherite ONLY — wood/stone/
# gold do NOT qualify). @s = that player. One-shot, never cleared.
scoreboard players set @s ec.has_axe 1
advancement revoke @s only evercraft:event_director/has_tool/axe
