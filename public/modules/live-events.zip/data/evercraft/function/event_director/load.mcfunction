# =====================================================================
# Unified Event Director — Load / scoreboard registration
# =====================================================================
# Called from evercraft:init (after calendar/load + world_events/load so the
# systems it gates are already initialized).
#
# THE PROBLEM THIS SOLVES: three uncoordinated dawn schedulers (competition,
# calendar, world_events) used to roll + NOTIFY players about events they
# could not participate in, with no anti-repeat. The Director gates eligibility
# and spacing BEFORE any notification fires.
#
# ONE-WRITER LAW: every register declared here is written ONLY by the Director
# (event_director/*). The competition/calendar/world_events systems still own
# their own legacy registers; the Director owns these new ones solely.
# ---------------------------------------------------------------------

# --- Per-player tool-acquisition flags (persistent, one-shot, NEVER cleared) ---
# Set the first time a player obtains the matching tool (see event_director/tag/*).
# A player with the flag is eligible for the matching activity forever.
# TIER POLICY: the three TIERED tools (pickaxe/axe/hoe) only set their flag on an
# IRON-or-better tier (iron/diamond/netherite — see the #evercraft:event_director
# /iron_* item tags). The three TIERLESS tools (utensil/shears/rod) have no tier
# progression, so obtaining one at all qualifies.
scoreboard objectives add ec.has_utensil dummy "Has Cooking Utensil"
scoreboard objectives add ec.has_pickaxe dummy "Has Iron+ Pickaxe"
scoreboard objectives add ec.has_axe dummy "Has Iron+ Axe"
scoreboard objectives add ec.has_hoe dummy "Has Iron+ Hoe"
scoreboard objectives add ec.has_shears dummy "Has Shears"
scoreboard objectives add ec.has_rod dummy "Has Fishing Rod"

# --- Director scratch / pool state (global fake-player scores on ec.var) ---
# #evd_pick       chosen competition type this dawn (0 = none picked)
# #evd_pool_n     count of eligible+unlocked competition types this dawn
# #evd_elig       per-iteration eligibility flag (scratch)
# #evd_today      current day index snapshot (= #visual_day) for this decision
scoreboard players set #evd_pick ec.var 0
scoreboard players set #evd_pool_n ec.var 0
scoreboard players set #evd_elig ec.var 0
scoreboard players set #evd_today ec.var 0

# =====================================================================
# TWO-TRACK SPACING (owner decision 2026-06-05): a noon skill COMPETITION and an
# ambient WORLD/CALENDAR event MAY occur on the same day. The two tracks are
# fully INDEPENDENT — neither blocks the other. Within each track there is still
# no stacking and still a 0..2 day cadence.
#
#   Track A = COMPETITIONS (noon skill races, types 1..6)
#       #evd_since_comp  days since the last competition fired (cadence)
#       #evd_fired_comp  day index the last competition fired (no-stack marker)
#   Track B = AMBIENT (world events + calendar events)
#       #evd_since_we    days since the last ambient/calendar event fired
#       #evd_fired_we    day index the last ambient/calendar event fired
#
# SHARED-REGISTER NOTE (one-writer nuance): each #evd_since_* has a single
# INCREMENTER and one-or-more CONSUMERS that RESET it to 0 when an event of that
# track fires (gametime-cooldown pattern). Track A: incremented by dawn_decision,
# reset by commit_comp. Track B: incremented by dawn_decision (one tick/day),
# reset by cal_on_commit + omens/world_events/begin. Do not add a 2nd incrementer
# to either track.
# ---------------------------------------------------------------------

# Track A — competitions (preserve across /reload; bootstrap high so the first
# dawn after a fresh load may fire).
execute unless score #evd_since_comp ec.var matches 0.. run scoreboard players set #evd_since_comp ec.var 99
execute unless score #evd_fired_comp ec.var matches -2147483648.. run scoreboard players set #evd_fired_comp ec.var -99

# Track B — ambient world + calendar events.
execute unless score #evd_since_we ec.var matches 0.. run scoreboard players set #evd_since_we ec.var 99
execute unless score #evd_fired_we ec.var matches -2147483648.. run scoreboard players set #evd_fired_we ec.var -99

# --- Per-type "last ran" day registers (day index; -99 = never ran) ---
# Competitions (type ids mirror #comp_day_type 1..11).
execute unless score #evd_last_cook ec.var matches -2147483648.. run scoreboard players set #evd_last_cook ec.var -99
execute unless score #evd_last_mine ec.var matches -2147483648.. run scoreboard players set #evd_last_mine ec.var -99
execute unless score #evd_last_forge ec.var matches -2147483648.. run scoreboard players set #evd_last_forge ec.var -99
execute unless score #evd_last_prosp ec.var matches -2147483648.. run scoreboard players set #evd_last_prosp ec.var -99
execute unless score #evd_last_forage ec.var matches -2147483648.. run scoreboard players set #evd_last_forage ec.var -99
execute unless score #evd_last_fish ec.var matches -2147483648.. run scoreboard players set #evd_last_fish ec.var -99

# --- Node competitions (Wave 3a, types 7..11 — Craft-Affinity gather classes). ---
# Each is the SIMPLE tier (score = successful-harvest count during the window). Gated
# on the matching class being UNLOCKED (>=1 online player with ec.caffl_<code> matches 1..).
# Type ids mirror #comp_day_type 7..11:
#   7=Lamentor(lm/shearing) 8=Lumberfell(lf/felling) 9=Terrawarp(tw/digging)
#   10=Sirencall(sc/fishing-class) 11=Gearwright(gw/tinkering).
execute unless score #evd_last_lament ec.var matches -2147483648.. run scoreboard players set #evd_last_lament ec.var -99
execute unless score #evd_last_lumber ec.var matches -2147483648.. run scoreboard players set #evd_last_lumber ec.var -99
execute unless score #evd_last_terra ec.var matches -2147483648.. run scoreboard players set #evd_last_terra ec.var -99
execute unless score #evd_last_siren ec.var matches -2147483648.. run scoreboard players set #evd_last_siren ec.var -99
execute unless score #evd_last_tinker ec.var matches -2147483648.. run scoreboard players set #evd_last_tinker ec.var -99

# Calendar daily-pick spacing (one shared "calendar fired" register).
execute unless score #evd_last_cal ec.var matches -2147483648.. run scoreboard players set #evd_last_cal ec.var -99

# World-events (spontaneous) spacing (one shared "world-event fired" register).
execute unless score #evd_last_we ec.var matches -2147483648.. run scoreboard players set #evd_last_we ec.var -99
