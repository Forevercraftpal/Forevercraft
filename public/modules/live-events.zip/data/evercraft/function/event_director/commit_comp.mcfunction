# =====================================================================
# Unified Event Director — Commit the chosen competition
# =====================================================================
# Records the per-type 3-day lockout (this type's lastRun = today), resets the
# global cadence counter, and ARMS the competition for noon by setting
# #comp_day_type. NO player notification here — the "Today's Competition" /
# title / bossbar announcement now fires at NOON inside competition/start (and
# its competition/announce/<type> files), which only runs because this commit
# set #comp_day_type. That is the gate: nobody is notified until a type is
# locked in and eligible.
#
# Input: #evd_pick (1..11) = chosen competition type.
# ---------------------------------------------------------------------

# Arm the legacy noon path. luck_buffs/tick fires competition/start at DayTime
# 6000 when #comp_day_type matches 1..11.
scoreboard players operation #comp_day_type ec.var = #evd_pick ec.var

# Record per-type lockout (lastRun = today's day index).
execute if score #evd_pick ec.var matches 1 run scoreboard players operation #evd_last_cook ec.var = #evd_today ec.var
execute if score #evd_pick ec.var matches 2 run scoreboard players operation #evd_last_mine ec.var = #evd_today ec.var
execute if score #evd_pick ec.var matches 3 run scoreboard players operation #evd_last_forge ec.var = #evd_today ec.var
execute if score #evd_pick ec.var matches 4 run scoreboard players operation #evd_last_prosp ec.var = #evd_today ec.var
execute if score #evd_pick ec.var matches 5 run scoreboard players operation #evd_last_forage ec.var = #evd_today ec.var
execute if score #evd_pick ec.var matches 6 run scoreboard players operation #evd_last_fish ec.var = #evd_today ec.var
# Node comps (Wave 3a, types 7..11).
execute if score #evd_pick ec.var matches 7 run scoreboard players operation #evd_last_lament ec.var = #evd_today ec.var
execute if score #evd_pick ec.var matches 8 run scoreboard players operation #evd_last_lumber ec.var = #evd_today ec.var
execute if score #evd_pick ec.var matches 9 run scoreboard players operation #evd_last_terra ec.var = #evd_today ec.var
execute if score #evd_pick ec.var matches 10 run scoreboard players operation #evd_last_siren ec.var = #evd_today ec.var
execute if score #evd_pick ec.var matches 11 run scoreboard players operation #evd_last_tinker ec.var = #evd_today ec.var

# TRACK A stamp: a competition fired today. Reset Track A cadence + no-stack
# marker. Does NOT touch Track B — an ambient world/calendar event may still fire
# the same day.
scoreboard players set #evd_since_comp ec.var 0
scoreboard players operation #evd_fired_comp ec.var = #evd_today ec.var
