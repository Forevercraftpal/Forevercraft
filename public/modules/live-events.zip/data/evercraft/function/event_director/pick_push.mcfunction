# Event Director — pick helper: push a candidate type id onto the dense list.
# Macro arg: {v:<type id>}. Increments #evd_n and writes the id into #evd_s<n>.
# Called only from pick_comp; up to 11 invocations (one per surviving candidate).
scoreboard players add #evd_n ec.var 1
$execute if score #evd_n ec.var matches 1 run scoreboard players set #evd_s1 ec.var $(v)
$execute if score #evd_n ec.var matches 2 run scoreboard players set #evd_s2 ec.var $(v)
$execute if score #evd_n ec.var matches 3 run scoreboard players set #evd_s3 ec.var $(v)
$execute if score #evd_n ec.var matches 4 run scoreboard players set #evd_s4 ec.var $(v)
$execute if score #evd_n ec.var matches 5 run scoreboard players set #evd_s5 ec.var $(v)
$execute if score #evd_n ec.var matches 6 run scoreboard players set #evd_s6 ec.var $(v)
$execute if score #evd_n ec.var matches 7 run scoreboard players set #evd_s7 ec.var $(v)
$execute if score #evd_n ec.var matches 8 run scoreboard players set #evd_s8 ec.var $(v)
$execute if score #evd_n ec.var matches 9 run scoreboard players set #evd_s9 ec.var $(v)
$execute if score #evd_n ec.var matches 10 run scoreboard players set #evd_s10 ec.var $(v)
$execute if score #evd_n ec.var matches 11 run scoreboard players set #evd_s11 ec.var $(v)
