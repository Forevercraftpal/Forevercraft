# =====================================================================
# Unified Event Director — Calendar commit hook
# =====================================================================
# Called by calendar/pick_event AFTER it has accepted a daily event pick.
# Calendar events are TRACK B (ambient). Stamp Track B's spacing registers so
# Track B re-entries (and world events) know an ambient event fired today and
# don't stack a second one. Does NOT touch Track A — a competition may still
# fire the same day.
#
# Input: #cal_pick cal.temp = the accepted calendar event id (1..8).
# ---------------------------------------------------------------------
scoreboard players operation #evd_last_cal ec.var = #visual_day ec.var
scoreboard players set #evd_since_we ec.var 0
# Track B order-independent no-stack marker (today = an ambient event fired).
scoreboard players operation #evd_fired_we ec.var = #visual_day ec.var
