# =====================================================================
# Unified Event Director — Pick one competition from the eligible pool
# =====================================================================
# Compacts the candidate slots (#evd_c1..#evd_c11, each = its type id or 0) into
# a dense list #evd_s1..#evd_sN, then rolls a uniform random index 1..N and
# writes the winning type id to #evd_pick.
#
# Precondition: #evd_pool_n >= 1 (the caller checked the pool is non-empty).
# Output: #evd_pick = chosen competition type (1..11). NOTHING announced here.
# ---------------------------------------------------------------------

# Compact: walk the 11 candidate slots, appending non-zero ids into #evd_sK.
scoreboard players set #evd_n ec.var 0
execute if score #evd_c1 ec.var matches 1.. run function evercraft:event_director/pick_push {v:1}
execute if score #evd_c2 ec.var matches 1.. run function evercraft:event_director/pick_push {v:2}
execute if score #evd_c3 ec.var matches 1.. run function evercraft:event_director/pick_push {v:3}
execute if score #evd_c4 ec.var matches 1.. run function evercraft:event_director/pick_push {v:4}
execute if score #evd_c5 ec.var matches 1.. run function evercraft:event_director/pick_push {v:5}
execute if score #evd_c6 ec.var matches 1.. run function evercraft:event_director/pick_push {v:6}
execute if score #evd_c7 ec.var matches 1.. run function evercraft:event_director/pick_push {v:7}
execute if score #evd_c8 ec.var matches 1.. run function evercraft:event_director/pick_push {v:8}
execute if score #evd_c9 ec.var matches 1.. run function evercraft:event_director/pick_push {v:9}
execute if score #evd_c10 ec.var matches 1.. run function evercraft:event_director/pick_push {v:10}
execute if score #evd_c11 ec.var matches 1.. run function evercraft:event_director/pick_push {v:11}

# Roll a uniform index in 1..N (N = #evd_pool_n). Per-N literal rolls avoid the
# modulo-bias a single `random value 1..11 %= N` would introduce.
execute if score #evd_pool_n ec.var matches 1 run scoreboard players set #evd_roll ec.var 1
execute if score #evd_pool_n ec.var matches 2 store result score #evd_roll ec.var run random value 1..2
execute if score #evd_pool_n ec.var matches 3 store result score #evd_roll ec.var run random value 1..3
execute if score #evd_pool_n ec.var matches 4 store result score #evd_roll ec.var run random value 1..4
execute if score #evd_pool_n ec.var matches 5 store result score #evd_roll ec.var run random value 1..5
execute if score #evd_pool_n ec.var matches 6 store result score #evd_roll ec.var run random value 1..6
execute if score #evd_pool_n ec.var matches 7 store result score #evd_roll ec.var run random value 1..7
execute if score #evd_pool_n ec.var matches 8 store result score #evd_roll ec.var run random value 1..8
execute if score #evd_pool_n ec.var matches 9 store result score #evd_roll ec.var run random value 1..9
execute if score #evd_pool_n ec.var matches 10 store result score #evd_roll ec.var run random value 1..10
execute if score #evd_pool_n ec.var matches 11 store result score #evd_roll ec.var run random value 1..11

# Read the chosen slot into #evd_pick.
scoreboard players set #evd_pick ec.var 0
execute if score #evd_roll ec.var matches 1 run scoreboard players operation #evd_pick ec.var = #evd_s1 ec.var
execute if score #evd_roll ec.var matches 2 run scoreboard players operation #evd_pick ec.var = #evd_s2 ec.var
execute if score #evd_roll ec.var matches 3 run scoreboard players operation #evd_pick ec.var = #evd_s3 ec.var
execute if score #evd_roll ec.var matches 4 run scoreboard players operation #evd_pick ec.var = #evd_s4 ec.var
execute if score #evd_roll ec.var matches 5 run scoreboard players operation #evd_pick ec.var = #evd_s5 ec.var
execute if score #evd_roll ec.var matches 6 run scoreboard players operation #evd_pick ec.var = #evd_s6 ec.var
execute if score #evd_roll ec.var matches 7 run scoreboard players operation #evd_pick ec.var = #evd_s7 ec.var
execute if score #evd_roll ec.var matches 8 run scoreboard players operation #evd_pick ec.var = #evd_s8 ec.var
execute if score #evd_roll ec.var matches 9 run scoreboard players operation #evd_pick ec.var = #evd_s9 ec.var
execute if score #evd_roll ec.var matches 10 run scoreboard players operation #evd_pick ec.var = #evd_s10 ec.var
execute if score #evd_roll ec.var matches 11 run scoreboard players operation #evd_pick ec.var = #evd_s11 ec.var
