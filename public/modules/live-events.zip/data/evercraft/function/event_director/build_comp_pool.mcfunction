# =====================================================================
# Unified Event Director — Build eligible competition pool
# =====================================================================
# For each of the 11 competition types, mark it a candidate ONLY if BOTH:
#   (A) ELIGIBILITY: >= 1 ONLINE player satisfies the type's tool/rank/class gate, AND
#   (B) SPACING: the per-type 3-day lockout has elapsed
#       (currentDay - lastRun >= 3, i.e. lastRun <= today-3).
#
# Candidate types are written into #evd_c1..#evd_c11 (the type id, or 0 if not a
# candidate) and counted in #evd_pool_n. NOTHING is announced here.
#
# Inputs:  #evd_today (= today's day index, set by the caller)
# Outputs: #evd_c1..#evd_c11, #evd_pool_n
#
# Competition type ids (mirror #comp_day_type):
#   1=cooking  2=mining  3=forging  4=prospecting  5=foraging  6=fishing
#   7=lamentor 8=lumberfell 9=terrawarp 10=sirencall 11=gearwright  (Wave 3a node comps)
#
# NODE-COMP ELIGIBILITY (types 7..11) = the Craft-Affinity class is UNLOCKED for >=1
# online player. The canonical "unlocked" signal is the derived Level register
# ec.caffl_<code> matches 1.. (the codex grants its level-1 unlock on the same gate —
# craftforever/codex/check_level1_unlock). A player reaches Level 1 at ~60 class XP, i.e.
# the moment they have meaningfully used the class. caff class-codes: lm/lf/tw/sc/gw.
# ---------------------------------------------------------------------

# Reset the candidate slots + pool count.
scoreboard players set #evd_c1 ec.var 0
scoreboard players set #evd_c2 ec.var 0
scoreboard players set #evd_c3 ec.var 0
scoreboard players set #evd_c4 ec.var 0
scoreboard players set #evd_c5 ec.var 0
scoreboard players set #evd_c6 ec.var 0
scoreboard players set #evd_c7 ec.var 0
scoreboard players set #evd_c8 ec.var 0
scoreboard players set #evd_c9 ec.var 0
scoreboard players set #evd_c10 ec.var 0
scoreboard players set #evd_c11 ec.var 0
scoreboard players set #evd_pool_n ec.var 0

# "Unlock day" threshold: a type is spacing-OK if its lastRun <= #evd_unlock.
# #evd_unlock = today - 4  (2026-06-06: per-type lockout 4 days, so a given comp type can recur
# only every 4 days — matches the ~every-4-days comp cadence).
scoreboard players operation #evd_unlock ec.var = #evd_today ec.var
scoreboard players remove #evd_unlock ec.var 4

# === Type 1 — Cooking (eligible: any online player has the Cooking Utensil) ===
execute if score #evd_last_cook ec.var <= #evd_unlock ec.var if entity @a[scores={ec.has_utensil=1..},limit=1] run scoreboard players set #evd_c1 ec.var 1
execute if score #evd_c1 ec.var matches 1 run scoreboard players add #evd_pool_n ec.var 1

# === Type 2 — Mining (eligible: any online player has an IRON+ pickaxe) ===
execute if score #evd_last_mine ec.var <= #evd_unlock ec.var if entity @a[scores={ec.has_pickaxe=1..},limit=1] run scoreboard players set #evd_c2 ec.var 2
execute if score #evd_c2 ec.var matches 2 run scoreboard players add #evd_pool_n ec.var 1

# === Type 3 — Forging (eligible: any online player at artisan rank >= 5) ===
execute if score #evd_last_forge ec.var <= #evd_unlock ec.var if entity @a[scores={ec.cf_rank=5..},limit=1] run scoreboard players set #evd_c3 ec.var 3
execute if score #evd_c3 ec.var matches 3 run scoreboard players add #evd_pool_n ec.var 1

# === Type 4 — Prospecting (eligible: any online player has an IRON+ pickaxe) ===
# Prospecting is mining-adjacent (ore digging) — gated on the iron+ pickaxe flag.
execute if score #evd_last_prosp ec.var <= #evd_unlock ec.var if entity @a[scores={ec.has_pickaxe=1..},limit=1] run scoreboard players set #evd_c4 ec.var 4
execute if score #evd_c4 ec.var matches 4 run scoreboard players add #evd_pool_n ec.var 1

# === Type 5 — Foraging (eligible: any online player has an IRON+ axe) ===
execute if score #evd_last_forage ec.var <= #evd_unlock ec.var if entity @a[scores={ec.has_axe=1..},limit=1] run scoreboard players set #evd_c5 ec.var 5
execute if score #evd_c5 ec.var matches 5 run scoreboard players add #evd_pool_n ec.var 1

# === Type 6 — Fishing (eligible: any online player has a fishing rod) ===
execute if score #evd_last_fish ec.var <= #evd_unlock ec.var if entity @a[scores={ec.has_rod=1..},limit=1] run scoreboard players set #evd_c6 ec.var 6
execute if score #evd_c6 ec.var matches 6 run scoreboard players add #evd_pool_n ec.var 1

# === Type 7 — Lamentor / shearing (eligible: any online player has unlocked Lamentor) ===
execute if score #evd_last_lament ec.var <= #evd_unlock ec.var if entity @a[scores={ec.caffl_lm=1..},limit=1] run scoreboard players set #evd_c7 ec.var 7
execute if score #evd_c7 ec.var matches 7 run scoreboard players add #evd_pool_n ec.var 1

# === Type 8 — Lumberfell / tree-felling (eligible: any online player has unlocked Lumberfell) ===
execute if score #evd_last_lumber ec.var <= #evd_unlock ec.var if entity @a[scores={ec.caffl_lf=1..},limit=1] run scoreboard players set #evd_c8 ec.var 8
execute if score #evd_c8 ec.var matches 8 run scoreboard players add #evd_pool_n ec.var 1

# === Type 9 — Terrawarp / excavation (eligible: any online player has unlocked Terrawarp) ===
execute if score #evd_last_terra ec.var <= #evd_unlock ec.var if entity @a[scores={ec.caffl_tw=1..},limit=1] run scoreboard players set #evd_c9 ec.var 9
execute if score #evd_c9 ec.var matches 9 run scoreboard players add #evd_pool_n ec.var 1

# === Type 10 — Sirencall / fishing-class (eligible: any online player has unlocked Sirencall) ===
execute if score #evd_last_siren ec.var <= #evd_unlock ec.var if entity @a[scores={ec.caffl_sc=1..},limit=1] run scoreboard players set #evd_c10 ec.var 10
execute if score #evd_c10 ec.var matches 10 run scoreboard players add #evd_pool_n ec.var 1

# === Type 11 — Gearwright / tinkering (eligible: any online player has unlocked Gearwright) ===
execute if score #evd_last_tinker ec.var <= #evd_unlock ec.var if entity @a[scores={ec.caffl_gw=1..},limit=1] run scoreboard players set #evd_c11 ec.var 11
execute if score #evd_c11 ec.var matches 11 run scoreboard players add #evd_pool_n ec.var 1
