# =====================================================================
# Unified Event Director — Calendar spacing gate (Track B)
# =====================================================================
# Decides whether the calendar is allowed to commit a daily pick this dawn,
# routing the calendar's selection through Track B's no-stack marker so two
# AMBIENT events (calendar + world event) can't stack on the same day.
#
# TWO-TRACK MODEL: the calendar is Track B (ambient). This gate consults ONLY
# Track B (#evd_fired_we). It does NOT block on competitions (Track A) — a noon
# competition and a calendar event MAY share a day.
#
# Sets #evd_cal_block ec.var:
#   1 = an ambient (Track B) event ALREADY fired today -> calendar must defer
#   0 = clear to pick
#
# Detection uses the order-independent marker #evd_fired_we (= the day index an
# ambient event last fired, stamped by cal_on_commit / omens/world_events/begin).
# "Already fired today" == #evd_fired_we == today. Robust to scheduler ordering
# (the calendar tick and the world_events tick are independent loops).
# ---------------------------------------------------------------------
scoreboard players set #evd_cal_block ec.var 0
execute if score #evd_fired_we ec.var = #visual_day ec.var run scoreboard players set #evd_cal_block ec.var 1
