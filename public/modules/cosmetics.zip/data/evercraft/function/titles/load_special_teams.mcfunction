# Special Titles — Dream Journal + Reputation teams

# Floating-title renderer bootstrap (declares ec.tf_* objectives + #Global ec.tf_id counter).
# This load_special_teams runs on every /reload via the chain:
#   minecraft:load -> evercraft:init:325 -> evercraft:bosses/load:114 -> here.
function evercraft:titles/float/load

team add sp.t_1
team modify sp.t_1 prefix {text:""}
team modify sp.t_1 friendlyFire false

team add sp.t_2
team modify sp.t_2 prefix {text:""}
team modify sp.t_2 friendlyFire false

team add sp.t_3
team modify sp.t_3 prefix {text:""}
team modify sp.t_3 friendlyFire false

team add sp.t_4
team modify sp.t_4 prefix {text:""}
team modify sp.t_4 friendlyFire false

team add sp.t_5
team modify sp.t_5 prefix {text:""}
team modify sp.t_5 friendlyFire false

team add sp.t_6
team modify sp.t_6 prefix {text:""}
team modify sp.t_6 friendlyFire false

team add sp.t_7
team modify sp.t_7 prefix {text:""}
team modify sp.t_7 friendlyFire false

# Guild-Card titles (v1.1 2026-05-29) — Merchant + Adventurer guild ranks
# Merchant
team add sp.t_8
team modify sp.t_8 prefix {text:""}
team modify sp.t_8 friendlyFire false

team add sp.t_9
team modify sp.t_9 prefix {text:""}
team modify sp.t_9 friendlyFire false

team add sp.t_10
team modify sp.t_10 prefix {text:""}
team modify sp.t_10 friendlyFire false

# Adventurer
team add sp.t_11
team modify sp.t_11 prefix {text:""}
team modify sp.t_11 friendlyFire false

team add sp.t_12
team modify sp.t_12 prefix {text:""}
team modify sp.t_12 friendlyFire false

team add sp.t_13
team modify sp.t_13 prefix {text:""}
team modify sp.t_13 friendlyFire false

# Handcrafter (Builder) — IDs 14-16 (Grand Convergence W3, R4 sub-task, 2026-06-01)
# ID 14 Mastercrafter (rank X) / ID 15 Grand Handcrafter (rank D..SSS) / ID 16 Hand of the Maker (rank V)
team add sp.t_14
team modify sp.t_14 prefix {text:""}
team modify sp.t_14 friendlyFire false

team add sp.t_15
team modify sp.t_15 prefix {text:""}
team modify sp.t_15 friendlyFire false

team add sp.t_16
team modify sp.t_16 prefix {text:""}
team modify sp.t_16 friendlyFire false

# Master Tinkerer — ID 17 (Grand Convergence C8, Tinkering line capstone, 2026-06-01)
# bit 16, pow 65536. Owned via guild_cards/rewards/_unlock_special_title {tid:17}.
team add sp.t_17
team modify sp.t_17 prefix {text:""}
team modify sp.t_17 friendlyFire false

# Wayfarer — ID 18 (Wayfarer's Pass capstone)
# bit 17, pow 131072. Owned via guild_cards/rewards/_unlock_special_title {tid:18}.
team add sp.t_18
team modify sp.t_18 prefix {text:""}
team modify sp.t_18 friendlyFire false
