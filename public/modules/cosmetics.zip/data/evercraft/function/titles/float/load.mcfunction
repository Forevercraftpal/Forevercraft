# Floating Title — Objective + counter declarations
# Wired into evercraft:titles/load_special_teams (top), which runs on /reload via:
#   minecraft:load -> evercraft:init -> evercraft:bosses/load:114 -> titles/load_special_teams
# So this runs every /reload. Idempotent.

# Per-player unique id, stamped onto the player's float text_display entity so the
# per-tick follow/update targets the right entity in multiplayer. One writer:
#   float/load (init) + float/spawn (allocate). Read in float/spawn + float/tick.
scoreboard objectives add ec.tf_id dummy "Title Float ID"

# Per-player stored signature of the currently-rendered title, for change-detection
# so we only rebuild the float text when the active title actually changed.
# One writer: float/tick (+ float/spawn resets it). Read in float/tick.
scoreboard objectives add ec.tf_last dummy "Title Float Signature"

# Scratch: this-tick computed signature (fake-player #tf_now). One writer: float/tick.
scoreboard objectives add ec.tf_calc dummy "Title Float Scratch"

# Global incrementing counter for ec.tf_id allocation. Init only if unset.
execute unless score #Global ec.tf_id matches 0.. run scoreboard players set #Global ec.tf_id 0

# Reload safety: kill orphaned float entities (their owner's ec.tf_id binding is stale
# after a reload allocated new ids, and tick will re-spawn fresh ones as needed).
kill @e[type=text_display,tag=evercraft.TitleFloat]
execute as @a run scoreboard players reset @s ec.tf_last

# Lag audit 2026-06-22: kick the 1 Hz floating-title sentinel. It maintains ec.has_float_title so the
# 10 Hz cosmetics/fast_tick driver only runs the renderer for titled players (was: all players). A
# fresh start here (floats killed, tf_last reset above) means the sentinel re-derives cleanly.
schedule function evercraft:titles/float/sentinel 1s replace
