# Floating Title — spawn the player's float entity (run as player, at @s)
# Allocates a fresh ec.tf_id, summons a text_display above the head, stamps id + tag.
# Called once by float/tick when a titled player has no float entity yet.

# Allocate a unique id from the global counter
scoreboard players add #Global ec.tf_id 1
scoreboard players operation @s ec.tf_id = #Global ec.tf_id

# Summon the float text_display at the player.
#   The entity is tp'd to the player's FEET each fast-tick (tick.mcfunction), so the translation Y
#   must lift the label clear above the head + the default nametag (which sits ~2.3-2.4 above feet
#   on a 1.8-tall player). translation [0f,2.7f,0f] places it just above the nametag.
#   *** translation Y (2.7) + scale (0.8) are the two tunables — nudge in-game if it sits high/low. ***
#   billboard:center  -> always faces the camera
#   teleport_duration:3 -> smooth interpolation as we tp it each fast-tick
#   text starts blank; float/settext fills it on this same invocation
summon text_display ~ ~ ~ {Tags:[evercraft.TitleFloat,ec.tf_new],teleport_duration:3,billboard:"center",shadow:1b,see_through:0b,brightness:{block:15,sky:15},alignment:"center",text:"",transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,2.7f,0f],scale:[0.8f,0.8f,0.8f]}}

# Stamp the owner id onto the freshly-summoned entity, then drop the temp tag
scoreboard players operation @e[type=text_display,tag=ec.tf_new,limit=1,sort=nearest] ec.tf_id = @s ec.tf_id
tag @e[type=text_display,tag=ec.tf_new] remove ec.tf_new

# Force a text build on first spawn (clear stored signature so settext always runs)
scoreboard players set @s ec.tf_last 0
