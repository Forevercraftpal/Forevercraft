# Floating Title — 1 Hz sentinel (lag audit 2026-06-22)
# Maintains the ec.has_float_title tag so the 10 Hz follow driver (advantage/cosmetics/fast_tick)
# only runs the per-player renderer (titles/float/tick) for players who ACTUALLY have a title —
# instead of pushing the full ~20-op title-source cascade through that renderer 10x/sec for every
# untitled player. This sentinel also OWNS teardown: the moment every title source clears it removes
# the player's float here (untitle), at 1 s latency (imperceptible), so gating the 10 Hz driver can
# never leak a float entity. Self-reschedules at 1 s; kicked from titles/float/load.
schedule function evercraft:titles/float/sentinel 20t replace
execute unless entity @a run return 0

# Recompute the sentinel per player from the SAME 7 title sources titles/float/tick reads. Blanket
# clear then conditionally re-add (idempotent). Cheap: one tag op + a handful of score checks/player.
tag @a remove ec.has_float_title
execute as @a[scores={adv.cosm_active=2}] if score @s adv.cosm_tree matches 1..15 run tag @s add ec.has_float_title
execute as @a[scores={adv.cosm_active=4}] if score @s adv.cosm_tree matches 1..15 run tag @s add ec.has_float_title
tag @a[scores={adv.cc_title=1..}] add ec.has_float_title
tag @a[scores={wb.title=1..}] add ec.has_float_title
tag @a[scores={bm.title=1..}] add ec.has_float_title
tag @a[scores={ec.special_title=1..}] add ec.has_float_title
tag @a[scores={ec.gd_title=1..}] add ec.has_float_title
tag @a[scores={ec.cf_title_active=1..3}] add ec.has_float_title

# Teardown: a player who just lost their last title (no tag now, but a float WAS rendered -> tf_last>0)
# gets their float removed exactly once. untitle resets ec.tf_last to 0, so this can't re-fire next pass.
execute as @a[tag=!ec.has_float_title,scores={ec.tf_last=1..}] run function evercraft:titles/float/untitle
