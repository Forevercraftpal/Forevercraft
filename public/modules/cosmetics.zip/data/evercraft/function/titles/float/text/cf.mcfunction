# Floating Title text — Craftforever Title (ec.cf_title_active 1-3)
# Source: craftforever/titles/load_teams cf.title_1..3. AU35-P2.1 Wave I 2026-05-31.
# Run as player; #tf_search pre-synced by tick.

execute if score @s ec.cf_title_active matches 1 run data modify entity @e[type=text_display,tag=evercraft.TitleFloat,predicate=evercraft:titles/float/owned,limit=1] text set value [{text:"✦ ",color:"#8BC34A"},{text:"Apprentice Artisan",color:"#8BC34A",italic:false},{text:" ✦",color:"#8BC34A"}]
execute if score @s ec.cf_title_active matches 2 run data modify entity @e[type=text_display,tag=evercraft.TitleFloat,predicate=evercraft:titles/float/owned,limit=1] text set value [{text:"✦ ",color:"#43A047"},{text:"Journeyman Artisan",color:"#43A047",italic:false},{text:" ✦",color:"#43A047"}]
execute if score @s ec.cf_title_active matches 3 run data modify entity @e[type=text_display,tag=evercraft.TitleFloat,predicate=evercraft:titles/float/owned,limit=1] text set value [{text:"✦ ",color:"#FFD700"},{text:"Master Artisan",color:"#FFD700",italic:false,bold:true},{text:" ✦",color:"#FFD700"}]
