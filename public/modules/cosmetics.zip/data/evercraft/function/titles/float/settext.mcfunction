# Floating Title — rebuild the float entity's text from the active-title signature.
# Run as the player. Only called by float/tick when the signature CHANGED (rare),
# so a long branch chain here is fine. Dispatches by system band to a per-system file.
#   #tf_now ec.tf_calc = system*1000 + id  (see float/tick header)
#
# #tf_search must already be synced to @s ec.tf_id by float/tick (it is). The per-system
# helpers write to @e[...predicate=evercraft:titles/float/owned] (this player's float only).

execute if score #tf_now ec.tf_calc matches 1001..1999 run function evercraft:titles/float/text/cosm
execute if score #tf_now ec.tf_calc matches 2001..2999 run function evercraft:titles/float/text/crate
execute if score #tf_now ec.tf_calc matches 3001..3999 run function evercraft:titles/float/text/boss
execute if score #tf_now ec.tf_calc matches 4001..4999 run function evercraft:titles/float/text/biome
execute if score #tf_now ec.tf_calc matches 5001..5999 run function evercraft:titles/float/text/special
execute if score #tf_now ec.tf_calc matches 6001..6999 run function evercraft:titles/float/text/guild
execute if score #tf_now ec.tf_calc matches 7001..7999 run function evercraft:titles/float/text/cf
