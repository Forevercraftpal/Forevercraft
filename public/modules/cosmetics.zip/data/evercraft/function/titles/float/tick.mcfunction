# Floating Title — per-player renderer (run as @a at @s by the fast driver)
# Score-driven: derives the active title entirely from scores each call. No hooks.
# Active-title precedence (mutual exclusivity guarantees at most one is set):
#   cosm (cosm_active 2 or 4) -> crate -> boss -> biome -> special -> guild
#
# Signature (#tf_now ec.tf_calc) = system*1000 + id, used for change-detection:
#   1=cosm   id=cosm_tree(1-15)
#   2=crate  id=adv.cc_title(1-18)
#   3=boss   id=wb.title(1-45)
#   4=biome  id=bm.title(1-25)
#   5=special id=ec.special_title(1-13)
#   6=guild  id=ec.gd_title(1-8)

# --- Compute the active-title signature into #tf_now (default 0 = no title) ---
# Each system, gated on #tf_now still 0, copies its id then adds its band offset in the
# SAME conditional pass (a per-system #tf_claim flag prevents a later band re-offsetting
# an already-claimed signature). Mutual exclusivity means at most one system claims.
scoreboard players set #tf_now ec.tf_calc 0
scoreboard players set #tf_claim ec.tf_calc 0

# Cosmetic title tag: cosm_active==2 (Title Tag) OR ==4 (Glowing Outline also shows title),
# AND a tree is selected (1-15). signature = 1000 + cosm_tree.
execute if score #tf_claim ec.tf_calc matches 0 if score @s adv.cosm_active matches 2 if score @s adv.cosm_tree matches 1..15 run scoreboard players set #tf_claim ec.tf_calc 1
execute if score #tf_claim ec.tf_calc matches 0 if score @s adv.cosm_active matches 4 if score @s adv.cosm_tree matches 1..15 run scoreboard players set #tf_claim ec.tf_calc 1
execute if score #tf_claim ec.tf_calc matches 1 run scoreboard players operation #tf_now ec.tf_calc = @s adv.cosm_tree
execute if score #tf_claim ec.tf_calc matches 1 run scoreboard players add #tf_now ec.tf_calc 1000

# Crate title (2000 + cc_title)
execute if score #tf_claim ec.tf_calc matches 0 if score @s adv.cc_title matches 1.. run scoreboard players operation #tf_now ec.tf_calc = @s adv.cc_title
execute if score #tf_claim ec.tf_calc matches 0 if score @s adv.cc_title matches 1.. run scoreboard players add #tf_now ec.tf_calc 2000
execute if score @s adv.cc_title matches 1.. run scoreboard players set #tf_claim ec.tf_calc 1

# Boss title (3000 + wb.title)
execute if score #tf_claim ec.tf_calc matches 0 if score @s wb.title matches 1.. run scoreboard players operation #tf_now ec.tf_calc = @s wb.title
execute if score #tf_claim ec.tf_calc matches 0 if score @s wb.title matches 1.. run scoreboard players add #tf_now ec.tf_calc 3000
execute if score #tf_claim ec.tf_calc matches 0 if score @s wb.title matches 1.. run scoreboard players set #tf_claim ec.tf_calc 1

# Biome title (4000 + bm.title)
execute if score #tf_claim ec.tf_calc matches 0 if score @s bm.title matches 1.. run scoreboard players operation #tf_now ec.tf_calc = @s bm.title
execute if score #tf_claim ec.tf_calc matches 0 if score @s bm.title matches 1.. run scoreboard players add #tf_now ec.tf_calc 4000
execute if score #tf_claim ec.tf_calc matches 0 if score @s bm.title matches 1.. run scoreboard players set #tf_claim ec.tf_calc 1

# Special title (5000 + ec.special_title)
execute if score #tf_claim ec.tf_calc matches 0 if score @s ec.special_title matches 1.. run scoreboard players operation #tf_now ec.tf_calc = @s ec.special_title
execute if score #tf_claim ec.tf_calc matches 0 if score @s ec.special_title matches 1.. run scoreboard players add #tf_now ec.tf_calc 5000
execute if score #tf_claim ec.tf_calc matches 0 if score @s ec.special_title matches 1.. run scoreboard players set #tf_claim ec.tf_calc 1

# Guild diplomacy title (6000 + ec.gd_title)
execute if score #tf_claim ec.tf_calc matches 0 if score @s ec.gd_title matches 1.. run scoreboard players operation #tf_now ec.tf_calc = @s ec.gd_title
execute if score #tf_claim ec.tf_calc matches 0 if score @s ec.gd_title matches 1.. run scoreboard players add #tf_now ec.tf_calc 6000
execute if score @s ec.gd_title matches 1.. run scoreboard players set #tf_claim ec.tf_calc 1

# Craftforever title (7000 + ec.cf_title_active) — AU35-P2.1 Wave I 2026-05-31
execute if score #tf_claim ec.tf_calc matches 0 if score @s ec.cf_title_active matches 1..3 run scoreboard players operation #tf_now ec.tf_calc = @s ec.cf_title_active
execute if score #tf_claim ec.tf_calc matches 0 if score @s ec.cf_title_active matches 1..3 run scoreboard players add #tf_now ec.tf_calc 7000

# --- No title: hide/kill the float, reset, and bail (cheap path for untitled players) ---
execute if score #tf_now ec.tf_calc matches 0 run function evercraft:titles/float/untitle
execute if score #tf_now ec.tf_calc matches 0 run return 0

# --- Titled: ensure the float entity exists (existence-gate by owner id) ---
# Publish THIS player's id to #tf_search so the `owned` predicate matches only our float.
# (On first-ever spawn the player's ec.tf_id is unset, so the predicate fails -> we spawn,
#  and float/spawn allocates the id + republishes nothing; we re-sync #tf_search after.)
# Pre-zero so an unset @s ec.tf_id can't leak the PREVIOUS player's id (which would match
# their float and wrongly skip our spawn). No float is ever allocated id 0 (counter starts at 1).
scoreboard players set #tf_search ec.tf_id 0
scoreboard players operation #tf_search ec.tf_id = @s ec.tf_id
execute unless entity @e[type=text_display,tag=evercraft.TitleFloat,predicate=evercraft:titles/float/owned] run function evercraft:titles/float/spawn
# Re-sync search key in case spawn just allocated a fresh id for this player.
scoreboard players operation #tf_search ec.tf_id = @s ec.tf_id

# --- Follow: tp this player's float onto the player (teleport_duration smooths it) ---
execute at @s as @e[type=text_display,tag=evercraft.TitleFloat,predicate=evercraft:titles/float/owned,limit=1] run tp @s ~ ~ ~

# --- Change-detect: only rebuild text when the signature changed since last render ---
execute unless score #tf_now ec.tf_calc = @s ec.tf_last run function evercraft:titles/float/settext
scoreboard players operation @s ec.tf_last = #tf_now ec.tf_calc
