# Floating Title — player has no active title: remove their float + reset state
# Run as the player. Cheap: only acts if this player actually owns a float entity.

# Publish id so the predicate matches only THIS player's float (if any), then kill it.
scoreboard players operation #tf_search ec.tf_id = @s ec.tf_id
execute if score @s ec.tf_id matches 1.. run kill @e[type=text_display,tag=evercraft.TitleFloat,predicate=evercraft:titles/float/owned]

# Clear stored signature so the next time the player gets a title, settext rebuilds it.
scoreboard players set @s ec.tf_last 0
