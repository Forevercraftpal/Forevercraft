# Special Titles — Apply active special title
# Reads @s ec.special_title (0-7) and joins appropriate team
# Callers handle clear_all before setting the score (team join auto-removes from old team)

execute if score @s ec.special_title matches 0 run return 0

execute if score @s ec.special_title matches 1 run team join sp.t_1 @s
execute if score @s ec.special_title matches 2 run team join sp.t_2 @s
execute if score @s ec.special_title matches 3 run team join sp.t_3 @s
execute if score @s ec.special_title matches 4 run team join sp.t_4 @s
execute if score @s ec.special_title matches 5 run team join sp.t_5 @s
execute if score @s ec.special_title matches 6 run team join sp.t_6 @s
execute if score @s ec.special_title matches 7 run team join sp.t_7 @s

# Guild-Card titles (v1.1) — IDs 8-13
execute if score @s ec.special_title matches 8 run team join sp.t_8 @s
execute if score @s ec.special_title matches 9 run team join sp.t_9 @s
execute if score @s ec.special_title matches 10 run team join sp.t_10 @s
execute if score @s ec.special_title matches 11 run team join sp.t_11 @s
execute if score @s ec.special_title matches 12 run team join sp.t_12 @s
execute if score @s ec.special_title matches 13 run team join sp.t_13 @s

# Handcrafter (Builder) titles (W3) — IDs 14-16
execute if score @s ec.special_title matches 14 run team join sp.t_14 @s
execute if score @s ec.special_title matches 15 run team join sp.t_15 @s
execute if score @s ec.special_title matches 16 run team join sp.t_16 @s

# Master Tinkerer (C8) — ID 17 (Tinkering line capstone)
execute if score @s ec.special_title matches 17 run team join sp.t_17 @s

# Wayfarer — ID 18 (Wayfarer's Pass capstone)
execute if score @s ec.special_title matches 18 run team join sp.t_18 @s
