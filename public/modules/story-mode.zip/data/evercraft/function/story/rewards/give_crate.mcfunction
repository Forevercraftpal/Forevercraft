# Award a crate based on #rw_tier ec.temp (1-5)
# RE-P4 fix (Joseph verdict 2026-06-10): grant the PLACEABLE crate item (crates/items/<tier>)
# instead of inlining contents via `loot give` — `loot give` has no opener context, so the
# difficulty-gated accessory pools silently collapsed to the 5% Pioneer branch for everyone.
# The crate item resolves its container_loot at PLACEMENT, where `this` = the real opener.
# @s = player
# Uses existing quest crate loot tables

# Inv-full guard: drop at the player's feet rather than void on a full inventory.
execute store result score #inv_full ec.var run function evercraft:util/check_inv_full
execute if score #rw_tier ec.temp matches 1 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:crates/items/common
execute if score #rw_tier ec.temp matches 1 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:crates/items/common
execute if score #rw_tier ec.temp matches 1 run tellraw @s [{"text":"  "},{"text":"+1 ","color":"white"},{"text":"Common Crate","color":"white","bold":true}]

execute if score #rw_tier ec.temp matches 2 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:crates/items/uncommon
execute if score #rw_tier ec.temp matches 2 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:crates/items/uncommon
execute if score #rw_tier ec.temp matches 2 run tellraw @s [{"text":"  "},{"text":"+1 ","color":"green"},{"text":"Uncommon Crate","color":"green","bold":true}]

execute if score #rw_tier ec.temp matches 3 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:crates/items/rare
execute if score #rw_tier ec.temp matches 3 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:crates/items/rare
execute if score #rw_tier ec.temp matches 3 run tellraw @s [{"text":"  "},{"text":"+1 ","color":"aqua"},{"text":"Rare Crate","color":"aqua","bold":true}]

execute if score #rw_tier ec.temp matches 4 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:crates/items/ornate
execute if score #rw_tier ec.temp matches 4 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:crates/items/ornate
execute if score #rw_tier ec.temp matches 4 run tellraw @s [{"text":"  "},{"text":"+1 ","color":"light_purple"},{"text":"Ornate Crate","color":"light_purple","bold":true}]

execute if score #rw_tier ec.temp matches 5 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:crates/items/exquisite
execute if score #rw_tier ec.temp matches 5 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:crates/items/exquisite
execute if score #rw_tier ec.temp matches 5 run tellraw @s [{"text":"  "},{"text":"+1 ","color":"gold"},{"text":"Exquisite Crate","color":"gold","bold":true}]

# Warn if inventory was full (items dropped at feet)
execute store result score #inv_check ec.temp run clear @s * 0
execute if score #inv_check ec.temp matches 0 run tellraw @s [{"text":"  "},{"text":"(Inventory full \u2014 crate dropped at your feet)","color":"gray","italic":true}]
