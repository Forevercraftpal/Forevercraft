# Macro tail for dr_story_apply — receives {dr_total:<double>}
$attribute @s minecraft:luck modifier add evercraft:story_dr_bonus $(dr_total) add_value
