# Lore Branch varied reward pool
# @s = player, #rw_pool ec.temp = 0-9 (rotating index)

execute if score #rw_pool ec.temp matches 0 run experience add @s 50 points
execute if score #rw_pool ec.temp matches 0 run tellraw @s [{"text":"  "},{"text":"+50 Bonus XP","color":"blue"}]
# Inv-full guard: drop at the player's feet rather than void on a full inventory.
execute store result score #inv_full ec.var run function evercraft:util/check_inv_full
execute if score #rw_pool ec.temp matches 1 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:treasure/charms/uncommon
execute if score #rw_pool ec.temp matches 1 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:treasure/charms/uncommon
execute if score #rw_pool ec.temp matches 1 run tellraw @s [{"text":"  "},{"text":"+1 Uncommon Charm","color":"green"}]
# Harmonic Essence (T11 catalyst) — 1-in-20 (50% gate on this 1-in-10 slot). Replaced a redundant coin slot.
execute if score #rw_pool ec.temp matches 2 if predicate evercraft:craftforever/harmonic_50pct run function evercraft:story/rewards/give_harmonic
execute if score #rw_pool ec.temp matches 3 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:items/chrono_shard
execute if score #rw_pool ec.temp matches 3 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:items/chrono_shard
execute if score #rw_pool ec.temp matches 3 run tellraw @s [{"text":"  "},{"text":"+1 Chrono Shard","color":"dark_aqua"}]
execute if score #rw_pool ec.temp matches 4 run experience add @s 75 points
execute if score #rw_pool ec.temp matches 4 run tellraw @s [{"text":"  "},{"text":"+75 Bonus XP","color":"blue"}]
execute if score #rw_pool ec.temp matches 5 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:crates/artifact_uncommon
execute if score #rw_pool ec.temp matches 5 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:crates/artifact_uncommon
execute if score #rw_pool ec.temp matches 5 run tellraw @s [{"text":"  "},{"text":"+1 Artifact Crate","color":"#E0B0FF"}]
execute if score #rw_pool ec.temp matches 6 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:potions/structure/pool_rare
execute if score #rw_pool ec.temp matches 6 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:potions/structure/pool_rare
execute if score #rw_pool ec.temp matches 6 run tellraw @s [{"text":"  "},{"text":"+1 Rare Exploration Potion","color":"dark_aqua"}]
execute if score #rw_pool ec.temp matches 7 run experience add @s 100 points
execute if score #rw_pool ec.temp matches 7 run tellraw @s [{"text":"  "},{"text":"+100 Bonus XP","color":"blue"}]
execute if score #rw_pool ec.temp matches 8 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:satchel/uncommon
execute if score #rw_pool ec.temp matches 8 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:satchel/uncommon
execute if score #rw_pool ec.temp matches 8 run tellraw @s [{"text":"  "},{"text":"+1 Uncommon Satchel","color":"green"}]
execute if score #rw_pool ec.temp matches 9 run scoreboard players add @s ec.coins 5
execute if score #rw_pool ec.temp matches 9 run tellraw @s [{"text":"  "},{"text":"+5 Forever Coins","color":"yellow"}]
