# Award XP based on #rw_xp ec.temp
# @s = player

execute store result score #rw_xp_give ec.temp run scoreboard players get #rw_xp ec.temp
execute store result storage evercraft:story temp.xp int 1 run scoreboard players get #rw_xp ec.temp
function evercraft:story/rewards/give_xp_macro with storage evercraft:story temp

tellraw @s [{"text":"  "},{"text":"+","color":"green"},{"score":{"name":"#rw_xp","objective":"ec.temp"},"color":"green","bold":true},{"text":" XP","color":"green"}]
