# Branch Completion Mega-Reward — called when a player finishes all chapters in a side branch
# RE-P4 fix (Joseph verdict 2026-06-10): grant the PLACEABLE crate item (crates/items/<tier>)
# instead of inlining contents via `loot give` — `loot give` has no opener context, so the
# difficulty-gated accessory pools silently collapsed to the 5% Pioneer branch for everyone.
# The crate item resolves its container_loot at PLACEMENT, where `this` = the real opener.
# @s = player, called with {branch:"Name",color:"color"}

# Announcement
tellraw @s {"text":""}
$tellraw @s [{"text":"\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550","color":"$(color)"}]
$tellraw @s [{"text":"  "},{"text":"\u2605 BRANCH MASTERED: $(branch) \u2605","color":"$(color)","bold":true}]
$tellraw @s [{"text":"\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550","color":"$(color)"}]
tellraw @s {"text":""}

# Celebration effects
playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 1.0 1.0
playsound minecraft:entity.firework_rocket.blast master @s ~ ~ ~ 1.0 1.0
playsound minecraft:entity.firework_rocket.twinkle master @s ~ ~ ~ 0.8 1.2
playsound minecraft:entity.ender_dragon.death master @s ~ ~ ~ 0.2 1.6
particle minecraft:totem_of_undying ~ ~2 ~ 1 2 1 0.15 50
particle minecraft:end_rod ~ ~3 ~ 2 2 2 0.05 30

# Rewards (non-Pioneer)
execute unless score @s ec.difficulty matches 3 run scoreboard players add @s ec.coins 20
# Inv-full guard: drop at the player's feet rather than void on a full inventory.
execute store result score #inv_full ec.var run function evercraft:util/check_inv_full
execute unless score @s ec.difficulty matches 3 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:crates/items/exquisite
execute unless score @s ec.difficulty matches 3 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:crates/items/exquisite
execute unless score @s ec.difficulty matches 3 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:artifacts/ornate/main
execute unless score @s ec.difficulty matches 3 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:artifacts/ornate/main
execute unless score @s ec.difficulty matches 3 run tellraw @s [{"text":"  "},{"text":"+20 coins + Exquisite Crate + Ornate Artifact","color":"gold"}]

# Permanent DR bonus for branch mastery (+0.25 per branch, like constellations)
execute unless score @s ec.difficulty matches 3 run scoreboard players add @s ec.dr_story 25
execute unless score @s ec.difficulty matches 3 run function evercraft:story/rewards/dr_story_apply
$execute unless score @s ec.difficulty matches 3 run tellraw @s [{"text":"  "},{"text":"\u2605 ","color":"gold"},{"text":"Permanent +0.25 Dream Rate!","color":"$(color)","bold":true}]

# Journey log
$data modify storage evercraft:journey temp.event set value "\u2605 Branch Mastered: $(branch) \u2014 completed every chapter in the branch."
function evercraft:stats/journey/record

# Server announcement
$tellraw @a [{"text":""},{"text":"\u2605 ","color":"gold"},{"selector":"@s"},{"text":" has mastered the ","color":"yellow"},{"text":"$(branch)","color":"$(color)","bold":true},{"text":" branch!","color":"yellow"}]
