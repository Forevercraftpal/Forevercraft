# Combat Branch varied reward pool
# RE-P4 fix (Joseph verdict 2026-06-10): grant the PLACEABLE crate item (crates/items/<tier>)
# instead of inlining contents via `loot give` — `loot give` has no opener context, so the
# difficulty-gated accessory pools silently collapsed to the 5% Pioneer branch for everyone.
# The crate item resolves its container_loot at PLACEMENT, where `this` = the real opener.
# @s = player, #rw_pool ec.temp = 0-9 (rotating index)

# Inv-full guard: drop at the player's feet rather than void on a full inventory.
execute store result score #inv_full ec.var run function evercraft:util/check_inv_full
execute if score #rw_pool ec.temp matches 0 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:dungeon/key
execute if score #rw_pool ec.temp matches 0 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:dungeon/key
execute if score #rw_pool ec.temp matches 0 run tellraw @s [{"text":"  "},{"text":"+1 Dungeon Key","color":"gray"}]
execute if score #rw_pool ec.temp matches 1 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:crates/items/common
execute if score #rw_pool ec.temp matches 1 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:crates/items/common
execute if score #rw_pool ec.temp matches 1 run tellraw @s [{"text":"  "},{"text":"+1 Common Crate","color":"white"}]
# Harmonic Essence (T11 catalyst) — 1-in-20 (50% gate on this 1-in-10 slot). Replaced a redundant coin slot.
execute if score #rw_pool ec.temp matches 2 if predicate evercraft:craftforever/harmonic_50pct run function evercraft:story/rewards/give_harmonic
execute if score #rw_pool ec.temp matches 3 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:potions/combat/pool_common
execute if score #rw_pool ec.temp matches 3 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:potions/combat/pool_common
execute if score #rw_pool ec.temp matches 3 run tellraw @s [{"text":"  "},{"text":"+1 Combat Potion","color":"red"}]
execute if score #rw_pool ec.temp matches 4 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:crates/artifact_uncommon
execute if score #rw_pool ec.temp matches 4 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:crates/artifact_uncommon
execute if score #rw_pool ec.temp matches 4 run tellraw @s [{"text":"  "},{"text":"+1 Artifact Crate","color":"#E0B0FF"}]
execute if score #rw_pool ec.temp matches 5 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:weapon_mastery/stones/common_stone
execute if score #rw_pool ec.temp matches 5 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:weapon_mastery/stones/common_stone
execute if score #rw_pool ec.temp matches 5 run tellraw @s [{"text":"  "},{"text":"+1 Awakening Stone","color":"aqua"}]
execute if score #rw_pool ec.temp matches 6 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:potions/combat/pool_rare
execute if score #rw_pool ec.temp matches 6 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:potions/combat/pool_rare
execute if score #rw_pool ec.temp matches 6 run tellraw @s [{"text":"  "},{"text":"+1 Rare Combat Potion","color":"dark_red"}]
execute if score #rw_pool ec.temp matches 7 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:treasure/charms/uncommon
execute if score #rw_pool ec.temp matches 7 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:treasure/charms/uncommon
execute if score #rw_pool ec.temp matches 7 run tellraw @s [{"text":"  "},{"text":"+1 Uncommon Charm","color":"green"}]
execute if score #rw_pool ec.temp matches 8 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:weapon_mastery/stones/rare_stone
execute if score #rw_pool ec.temp matches 8 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:weapon_mastery/stones/rare_stone
execute if score #rw_pool ec.temp matches 8 run tellraw @s [{"text":"  "},{"text":"+1 Rare Awakening Stone","color":"aqua"}]
execute if score #rw_pool ec.temp matches 9 run scoreboard players add @s ec.coins 5
execute if score #rw_pool ec.temp matches 9 run tellraw @s [{"text":"  "},{"text":"+5 Forever Coins","color":"yellow"}]
