# Story chapter guild contribution — scaled by reward tier
# @s = player in a guild, #rw_tier ec.temp = 1-5
execute if score #rw_tier ec.temp matches 1 run function evercraft:guild/contribution/add {amount:5}
execute if score #rw_tier ec.temp matches 2 run function evercraft:guild/contribution/add {amount:10}
execute if score #rw_tier ec.temp matches 3 run function evercraft:guild/contribution/add {amount:15}
execute if score #rw_tier ec.temp matches 4 run function evercraft:guild/contribution/add {amount:20}
execute if score #rw_tier ec.temp matches 5 run function evercraft:guild/contribution/add {amount:25}
