# Seasonal Branch varied reward pool
# @s = player, #rw_pool ec.temp = 0-9 (rotating index)

# Inv-full guard: drop at the player's feet rather than void on a full inventory.
execute store result score #inv_full ec.var run function evercraft:util/check_inv_full
execute if score #rw_pool ec.temp matches 0 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:potions/harvest/pool_common
execute if score #rw_pool ec.temp matches 0 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:potions/harvest/pool_common
execute if score #rw_pool ec.temp matches 0 run tellraw @s [{"text":"  "},{"text":"+1 Harvest Potion","color":"#8BC34A"}]
execute if score #rw_pool ec.temp matches 1 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:alchemy/reagents/botanical_t2
execute if score #rw_pool ec.temp matches 1 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:alchemy/reagents/botanical_t2
execute if score #rw_pool ec.temp matches 1 run tellraw @s [{"text":"  "},{"text":"+1 Seasonal Reagent","color":"green"}]
# Harmonic Essence (T11 catalyst) — 1-in-20 (50% gate on this 1-in-10 slot). Replaced a redundant coin slot.
execute if score #rw_pool ec.temp matches 2 if predicate evercraft:craftforever/harmonic_50pct run function evercraft:story/rewards/give_harmonic
execute if score #rw_pool ec.temp matches 3 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:potions/fishing/pool_uncommon
execute if score #rw_pool ec.temp matches 3 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:potions/fishing/pool_uncommon
execute if score #rw_pool ec.temp matches 3 run tellraw @s [{"text":"  "},{"text":"+1 Fishing Potion","color":"blue"}]
execute if score #rw_pool ec.temp matches 4 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:companions/items/companion_treat
execute if score #rw_pool ec.temp matches 4 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:companions/items/companion_treat
execute if score #rw_pool ec.temp matches 4 run tellraw @s [{"text":"  "},{"text":"+1 Companion Treat","color":"light_purple"}]
execute if score #rw_pool ec.temp matches 5 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:potions/mining/pool_uncommon
execute if score #rw_pool ec.temp matches 5 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:potions/mining/pool_uncommon
execute if score #rw_pool ec.temp matches 5 run tellraw @s [{"text":"  "},{"text":"+1 Mining Potion","color":"gold"}]
execute if score #rw_pool ec.temp matches 6 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:treasure/charms/common
execute if score #rw_pool ec.temp matches 6 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:treasure/charms/common
execute if score #rw_pool ec.temp matches 6 run tellraw @s [{"text":"  "},{"text":"+1 Charm","color":"aqua"}]
execute if score #rw_pool ec.temp matches 7 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:ingredients/random_forging
execute if score #rw_pool ec.temp matches 7 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:ingredients/random_forging
execute if score #rw_pool ec.temp matches 7 run tellraw @s [{"text":"  "},{"text":"+1 Forging Material","color":"gold"}]
execute if score #rw_pool ec.temp matches 8 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:crates/artifact_common
execute if score #rw_pool ec.temp matches 8 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:crates/artifact_common
execute if score #rw_pool ec.temp matches 8 run tellraw @s [{"text":"  "},{"text":"+1 Artifact Crate","color":"#E0B0FF"}]
execute if score #rw_pool ec.temp matches 9 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:potions/structure/pool_uncommon
execute if score #rw_pool ec.temp matches 9 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:potions/structure/pool_uncommon
execute if score #rw_pool ec.temp matches 9 run tellraw @s [{"text":"  "},{"text":"+1 Exploration Potion","color":"dark_aqua"}]
