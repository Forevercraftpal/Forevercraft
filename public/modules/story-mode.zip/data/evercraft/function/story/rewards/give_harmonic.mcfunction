# Story reward helper — grant 1 Harmonic Essence (T11 forge catalyst).
# @s = player. Inv-full guarded: gives to inventory if space, spawns at feet if full.
# Mirrors the original inline Artisan block (theme/artisan) as a DRY single-point-of-truth.
# Also lights the "Forge Catalysts → Harmonic Essence" almanac entry (cat2 #7, bit 64) so
# non-Artisan players don't hold the item with a "???" almanac entry. mark_found is an
# idempotent bit-OR, so calling it from all 9 themes is safe.
execute store result score #inv_full ec.var run function evercraft:util/check_inv_full
execute if score #inv_full ec.var matches 0 run loot give @s loot evercraft:craftforever/materials/harmonic_essence
execute if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:craftforever/materials/harmonic_essence
tellraw @s [{"text":"  "},{"text":"+1 Harmonic Essence","color":"light_purple"}]
function evercraft:craftforever/codex/hub/almanac/mark_found {field:"cf_craft_found",bit:64}
