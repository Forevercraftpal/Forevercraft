# Award branch-themed bonus item using rotating pool
# @s = player, #rw_pool ec.temp = 0-9, #rw_tier ec.temp = tier
# Each branch has 10 different reward types that cycle

execute if score @s sm.branch matches 0 run function evercraft:story/rewards/theme/main
execute if score @s sm.branch matches 1 run function evercraft:story/rewards/theme/combat
execute if score @s sm.branch matches 2 run function evercraft:story/rewards/theme/artisan
execute if score @s sm.branch matches 3 run function evercraft:story/rewards/theme/explorer
execute if score @s sm.branch matches 4 run function evercraft:story/rewards/theme/social
execute if score @s sm.branch matches 5 run function evercraft:story/rewards/theme/lore
execute if score @s sm.branch matches 6 run function evercraft:story/rewards/theme/villain
execute if score @s sm.branch matches 7 run function evercraft:story/rewards/theme/seasonal
execute if score @s sm.branch matches 8 run function evercraft:story/rewards/theme/endgame
