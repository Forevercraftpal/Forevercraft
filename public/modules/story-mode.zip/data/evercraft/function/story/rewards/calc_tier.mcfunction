# Calculate reward tier (1-5) based on chapter number and branch
# Stores result in #rw_tier ec.temp (1=Common, 2=Uncommon, 3=Rare, 4=Ornate, 5=Exquisite)
# Also stores #rw_coins, #rw_xp base values
# Also sets #rw_milestone ec.temp = 1 if this is a sub-branch finale

scoreboard players set #rw_tier ec.temp 1
scoreboard players set #rw_coins ec.temp 5
scoreboard players set #rw_xp ec.temp 15
scoreboard players set #rw_milestone ec.temp 0

# === MAIN QUEST (branch 0, ch1-50) ===
execute if score @s sm.branch matches 0 if score @s sm.chapter matches 1..10 run scoreboard players set #rw_tier ec.temp 1
execute if score @s sm.branch matches 0 if score @s sm.chapter matches 1..10 run scoreboard players set #rw_coins ec.temp 5
execute if score @s sm.branch matches 0 if score @s sm.chapter matches 1..10 run scoreboard players set #rw_xp ec.temp 15

execute if score @s sm.branch matches 0 if score @s sm.chapter matches 11..20 run scoreboard players set #rw_tier ec.temp 2
execute if score @s sm.branch matches 0 if score @s sm.chapter matches 11..20 run scoreboard players set #rw_coins ec.temp 10
execute if score @s sm.branch matches 0 if score @s sm.chapter matches 11..20 run scoreboard players set #rw_xp ec.temp 30

execute if score @s sm.branch matches 0 if score @s sm.chapter matches 21..30 run scoreboard players set #rw_tier ec.temp 3
execute if score @s sm.branch matches 0 if score @s sm.chapter matches 21..30 run scoreboard players set #rw_coins ec.temp 20
execute if score @s sm.branch matches 0 if score @s sm.chapter matches 21..30 run scoreboard players set #rw_xp ec.temp 60

execute if score @s sm.branch matches 0 if score @s sm.chapter matches 31..40 run scoreboard players set #rw_tier ec.temp 4
execute if score @s sm.branch matches 0 if score @s sm.chapter matches 31..40 run scoreboard players set #rw_coins ec.temp 35
execute if score @s sm.branch matches 0 if score @s sm.chapter matches 31..40 run scoreboard players set #rw_xp ec.temp 100

execute if score @s sm.branch matches 0 if score @s sm.chapter matches 41..50 run scoreboard players set #rw_tier ec.temp 5
execute if score @s sm.branch matches 0 if score @s sm.chapter matches 41..50 run scoreboard players set #rw_coins ec.temp 50
execute if score @s sm.branch matches 0 if score @s sm.chapter matches 41..50 run scoreboard players set #rw_xp ec.temp 150

# Main quest act finales = milestones
execute if score @s sm.branch matches 0 if score @s sm.chapter matches 10 run scoreboard players set #rw_milestone ec.temp 1
execute if score @s sm.branch matches 0 if score @s sm.chapter matches 20 run scoreboard players set #rw_milestone ec.temp 1
execute if score @s sm.branch matches 0 if score @s sm.chapter matches 30 run scoreboard players set #rw_milestone ec.temp 1
execute if score @s sm.branch matches 0 if score @s sm.chapter matches 40 run scoreboard players set #rw_milestone ec.temp 1
execute if score @s sm.branch matches 0 if score @s sm.chapter matches 50 run scoreboard players set #rw_milestone ec.temp 1

# === SIDE BRANCHES — Calculate progress index, then map to tier ===
# Combat (101-160, 60 chapters): progress = chapter - 101
execute if score @s sm.branch matches 1 run scoreboard players operation #rw_prog ec.temp = @s sm.chapter
execute if score @s sm.branch matches 1 run scoreboard players remove #rw_prog ec.temp 101
execute if score @s sm.branch matches 1 if score #rw_prog ec.temp matches 0..14 run scoreboard players set #rw_tier ec.temp 1
execute if score @s sm.branch matches 1 if score #rw_prog ec.temp matches 15..29 run scoreboard players set #rw_tier ec.temp 2
execute if score @s sm.branch matches 1 if score #rw_prog ec.temp matches 30..44 run scoreboard players set #rw_tier ec.temp 3
execute if score @s sm.branch matches 1 if score #rw_prog ec.temp matches 45..54 run scoreboard players set #rw_tier ec.temp 4
execute if score @s sm.branch matches 1 if score #rw_prog ec.temp matches 55..59 run scoreboard players set #rw_tier ec.temp 5
# Combat milestones: ch115 (weaponmaster), ch130 (boss summary), ch145 (grand champion), ch160 (beyond the throne)
execute if score @s sm.chapter matches 115 run scoreboard players set #rw_milestone ec.temp 1
execute if score @s sm.chapter matches 130 run scoreboard players set #rw_milestone ec.temp 1
execute if score @s sm.chapter matches 145 run scoreboard players set #rw_milestone ec.temp 1
execute if score @s sm.chapter matches 160 run scoreboard players set #rw_milestone ec.temp 1

# Artisan (201-270, 70 chapters): progress = chapter - 201
execute if score @s sm.branch matches 2 run scoreboard players operation #rw_prog ec.temp = @s sm.chapter
execute if score @s sm.branch matches 2 run scoreboard players remove #rw_prog ec.temp 201
execute if score @s sm.branch matches 2 if score #rw_prog ec.temp matches 0..17 run scoreboard players set #rw_tier ec.temp 1
execute if score @s sm.branch matches 2 if score #rw_prog ec.temp matches 18..34 run scoreboard players set #rw_tier ec.temp 2
execute if score @s sm.branch matches 2 if score #rw_prog ec.temp matches 35..52 run scoreboard players set #rw_tier ec.temp 3
execute if score @s sm.branch matches 2 if score #rw_prog ec.temp matches 53..63 run scoreboard players set #rw_tier ec.temp 4
execute if score @s sm.branch matches 2 if score #rw_prog ec.temp matches 64..69 run scoreboard players set #rw_tier ec.temp 5
execute if score @s sm.chapter matches 210 run scoreboard players set #rw_milestone ec.temp 1
execute if score @s sm.chapter matches 220 run scoreboard players set #rw_milestone ec.temp 1
execute if score @s sm.chapter matches 230 run scoreboard players set #rw_milestone ec.temp 1
execute if score @s sm.chapter matches 250 run scoreboard players set #rw_milestone ec.temp 1
execute if score @s sm.chapter matches 270 run scoreboard players set #rw_milestone ec.temp 1

# Explorer (301-370, 70 chapters): progress = chapter - 301
execute if score @s sm.branch matches 3 run scoreboard players operation #rw_prog ec.temp = @s sm.chapter
execute if score @s sm.branch matches 3 run scoreboard players remove #rw_prog ec.temp 301
execute if score @s sm.branch matches 3 if score #rw_prog ec.temp matches 0..17 run scoreboard players set #rw_tier ec.temp 1
execute if score @s sm.branch matches 3 if score #rw_prog ec.temp matches 18..34 run scoreboard players set #rw_tier ec.temp 2
execute if score @s sm.branch matches 3 if score #rw_prog ec.temp matches 35..52 run scoreboard players set #rw_tier ec.temp 3
execute if score @s sm.branch matches 3 if score #rw_prog ec.temp matches 53..63 run scoreboard players set #rw_tier ec.temp 4
execute if score @s sm.branch matches 3 if score #rw_prog ec.temp matches 64..69 run scoreboard players set #rw_tier ec.temp 5
execute if score @s sm.chapter matches 325 run scoreboard players set #rw_milestone ec.temp 1
execute if score @s sm.chapter matches 340 run scoreboard players set #rw_milestone ec.temp 1
execute if score @s sm.chapter matches 350 run scoreboard players set #rw_milestone ec.temp 1
execute if score @s sm.chapter matches 370 run scoreboard players set #rw_milestone ec.temp 1

# Social (401-450, 50 chapters): progress = chapter - 401
execute if score @s sm.branch matches 4 run scoreboard players operation #rw_prog ec.temp = @s sm.chapter
execute if score @s sm.branch matches 4 run scoreboard players remove #rw_prog ec.temp 401
execute if score @s sm.branch matches 4 if score #rw_prog ec.temp matches 0..12 run scoreboard players set #rw_tier ec.temp 1
execute if score @s sm.branch matches 4 if score #rw_prog ec.temp matches 13..24 run scoreboard players set #rw_tier ec.temp 2
execute if score @s sm.branch matches 4 if score #rw_prog ec.temp matches 25..37 run scoreboard players set #rw_tier ec.temp 3
execute if score @s sm.branch matches 4 if score #rw_prog ec.temp matches 38..45 run scoreboard players set #rw_tier ec.temp 4
execute if score @s sm.branch matches 4 if score #rw_prog ec.temp matches 46..49 run scoreboard players set #rw_tier ec.temp 5
execute if score @s sm.chapter matches 410 run scoreboard players set #rw_milestone ec.temp 1
execute if score @s sm.chapter matches 430 run scoreboard players set #rw_milestone ec.temp 1
execute if score @s sm.chapter matches 440 run scoreboard players set #rw_milestone ec.temp 1
execute if score @s sm.chapter matches 450 run scoreboard players set #rw_milestone ec.temp 1

# Lore (501-550, 50 chapters): same ranges as Social
execute if score @s sm.branch matches 5 run scoreboard players operation #rw_prog ec.temp = @s sm.chapter
execute if score @s sm.branch matches 5 run scoreboard players remove #rw_prog ec.temp 501
execute if score @s sm.branch matches 5 if score #rw_prog ec.temp matches 0..12 run scoreboard players set #rw_tier ec.temp 1
execute if score @s sm.branch matches 5 if score #rw_prog ec.temp matches 13..24 run scoreboard players set #rw_tier ec.temp 2
execute if score @s sm.branch matches 5 if score #rw_prog ec.temp matches 25..37 run scoreboard players set #rw_tier ec.temp 3
execute if score @s sm.branch matches 5 if score #rw_prog ec.temp matches 38..45 run scoreboard players set #rw_tier ec.temp 4
execute if score @s sm.branch matches 5 if score #rw_prog ec.temp matches 46..49 run scoreboard players set #rw_tier ec.temp 5
execute if score @s sm.chapter matches 510 run scoreboard players set #rw_milestone ec.temp 1
execute if score @s sm.chapter matches 540 run scoreboard players set #rw_milestone ec.temp 1
execute if score @s sm.chapter matches 550 run scoreboard players set #rw_milestone ec.temp 1

# Villain (601-650, 50 chapters): same ranges as Social, +1 tier baseline (villain loot is better)
execute if score @s sm.branch matches 6 run scoreboard players operation #rw_prog ec.temp = @s sm.chapter
execute if score @s sm.branch matches 6 run scoreboard players remove #rw_prog ec.temp 601
execute if score @s sm.branch matches 6 if score #rw_prog ec.temp matches 0..12 run scoreboard players set #rw_tier ec.temp 2
execute if score @s sm.branch matches 6 if score #rw_prog ec.temp matches 13..24 run scoreboard players set #rw_tier ec.temp 3
execute if score @s sm.branch matches 6 if score #rw_prog ec.temp matches 25..37 run scoreboard players set #rw_tier ec.temp 4
execute if score @s sm.branch matches 6 if score #rw_prog ec.temp matches 38..49 run scoreboard players set #rw_tier ec.temp 5
execute if score @s sm.chapter matches 613 run scoreboard players set #rw_milestone ec.temp 1
execute if score @s sm.chapter matches 625 run scoreboard players set #rw_milestone ec.temp 1
execute if score @s sm.chapter matches 635 run scoreboard players set #rw_milestone ec.temp 1
execute if score @s sm.chapter matches 650 run scoreboard players set #rw_milestone ec.temp 1

# Seasonal (701-730, 30 chapters): progress = chapter - 701
execute if score @s sm.branch matches 7 run scoreboard players operation #rw_prog ec.temp = @s sm.chapter
execute if score @s sm.branch matches 7 run scoreboard players remove #rw_prog ec.temp 701
execute if score @s sm.branch matches 7 if score #rw_prog ec.temp matches 0..7 run scoreboard players set #rw_tier ec.temp 1
execute if score @s sm.branch matches 7 if score #rw_prog ec.temp matches 8..14 run scoreboard players set #rw_tier ec.temp 2
execute if score @s sm.branch matches 7 if score #rw_prog ec.temp matches 15..22 run scoreboard players set #rw_tier ec.temp 3
execute if score @s sm.branch matches 7 if score #rw_prog ec.temp matches 23..27 run scoreboard players set #rw_tier ec.temp 4
execute if score @s sm.branch matches 7 if score #rw_prog ec.temp matches 28..29 run scoreboard players set #rw_tier ec.temp 5
execute if score @s sm.chapter matches 710 run scoreboard players set #rw_milestone ec.temp 1
execute if score @s sm.chapter matches 720 run scoreboard players set #rw_milestone ec.temp 1
execute if score @s sm.chapter matches 730 run scoreboard players set #rw_milestone ec.temp 1

# Endgame (801-850, 50 chapters): +1 tier baseline (endgame loot is best)
execute if score @s sm.branch matches 8 run scoreboard players operation #rw_prog ec.temp = @s sm.chapter
execute if score @s sm.branch matches 8 run scoreboard players remove #rw_prog ec.temp 801
execute if score @s sm.branch matches 8 if score #rw_prog ec.temp matches 0..12 run scoreboard players set #rw_tier ec.temp 2
execute if score @s sm.branch matches 8 if score #rw_prog ec.temp matches 13..24 run scoreboard players set #rw_tier ec.temp 3
execute if score @s sm.branch matches 8 if score #rw_prog ec.temp matches 25..37 run scoreboard players set #rw_tier ec.temp 4
execute if score @s sm.branch matches 8 if score #rw_prog ec.temp matches 38..49 run scoreboard players set #rw_tier ec.temp 5
execute if score @s sm.chapter matches 810 run scoreboard players set #rw_milestone ec.temp 1
execute if score @s sm.chapter matches 830 run scoreboard players set #rw_milestone ec.temp 1
execute if score @s sm.chapter matches 850 run scoreboard players set #rw_milestone ec.temp 1

# === COIN SCALING BY TIER (side branches) ===
execute unless score @s sm.branch matches 0 if score #rw_tier ec.temp matches 1 run scoreboard players set #rw_coins ec.temp 5
execute unless score @s sm.branch matches 0 if score #rw_tier ec.temp matches 2 run scoreboard players set #rw_coins ec.temp 10
execute unless score @s sm.branch matches 0 if score #rw_tier ec.temp matches 3 run scoreboard players set #rw_coins ec.temp 20
execute unless score @s sm.branch matches 0 if score #rw_tier ec.temp matches 4 run scoreboard players set #rw_coins ec.temp 35
execute unless score @s sm.branch matches 0 if score #rw_tier ec.temp matches 5 run scoreboard players set #rw_coins ec.temp 50

# XP scaling by tier (side branches)
execute unless score @s sm.branch matches 0 if score #rw_tier ec.temp matches 1 run scoreboard players set #rw_xp ec.temp 15
execute unless score @s sm.branch matches 0 if score #rw_tier ec.temp matches 2 run scoreboard players set #rw_xp ec.temp 30
execute unless score @s sm.branch matches 0 if score #rw_tier ec.temp matches 3 run scoreboard players set #rw_xp ec.temp 60
execute unless score @s sm.branch matches 0 if score #rw_tier ec.temp matches 4 run scoreboard players set #rw_xp ec.temp 100
execute unless score @s sm.branch matches 0 if score #rw_tier ec.temp matches 5 run scoreboard players set #rw_xp ec.temp 150

# === MILESTONE BONUS: +50% coins, +1 tier (capped at 5) ===
# Add 50% bonus: store half, then add it back
execute if score #rw_milestone ec.temp matches 1 run scoreboard players operation #rw_half ec.temp = #rw_coins ec.temp
execute if score #rw_milestone ec.temp matches 1 run scoreboard players operation #rw_half ec.temp /= #2 ec.const
execute if score #rw_milestone ec.temp matches 1 run scoreboard players operation #rw_coins ec.temp += #rw_half ec.temp
execute if score #rw_milestone ec.temp matches 1 if score #rw_tier ec.temp matches ..4 run scoreboard players add #rw_tier ec.temp 1

# === ADVENTURER SCALING: 50% coins, 50% XP, -1 tier ===
execute if score @s ec.difficulty matches 2 run scoreboard players operation #rw_coins ec.temp /= #2 ec.const
execute if score @s ec.difficulty matches 2 run scoreboard players operation #rw_xp ec.temp /= #2 ec.const
execute if score @s ec.difficulty matches 2 if score #rw_tier ec.temp matches 2.. run scoreboard players remove #rw_tier ec.temp 1

# === BONUS CRATE MILESTONES ===
# Every 5 chapters within a branch = small bonus crate (at current tier)
# Every 10 chapters within a branch = big bonus crate (+1 tier, capped at 5)
scoreboard players set #rw_bonus_crate ec.temp 0
scoreboard players set #rw_bonus_big ec.temp 0

# Calculate progress index for current branch
execute if score @s sm.branch matches 0 run scoreboard players operation #rw_idx ec.temp = @s sm.chapter
execute if score @s sm.branch matches 1 run scoreboard players operation #rw_idx ec.temp = @s sm.chapter
execute if score @s sm.branch matches 1 run scoreboard players remove #rw_idx ec.temp 100
execute if score @s sm.branch matches 2 run scoreboard players operation #rw_idx ec.temp = @s sm.chapter
execute if score @s sm.branch matches 2 run scoreboard players remove #rw_idx ec.temp 200
execute if score @s sm.branch matches 3 run scoreboard players operation #rw_idx ec.temp = @s sm.chapter
execute if score @s sm.branch matches 3 run scoreboard players remove #rw_idx ec.temp 300
execute if score @s sm.branch matches 4 run scoreboard players operation #rw_idx ec.temp = @s sm.chapter
execute if score @s sm.branch matches 4 run scoreboard players remove #rw_idx ec.temp 400
execute if score @s sm.branch matches 5 run scoreboard players operation #rw_idx ec.temp = @s sm.chapter
execute if score @s sm.branch matches 5 run scoreboard players remove #rw_idx ec.temp 500
execute if score @s sm.branch matches 6 run scoreboard players operation #rw_idx ec.temp = @s sm.chapter
execute if score @s sm.branch matches 6 run scoreboard players remove #rw_idx ec.temp 600
execute if score @s sm.branch matches 7 run scoreboard players operation #rw_idx ec.temp = @s sm.chapter
execute if score @s sm.branch matches 7 run scoreboard players remove #rw_idx ec.temp 700
execute if score @s sm.branch matches 8 run scoreboard players operation #rw_idx ec.temp = @s sm.chapter
execute if score @s sm.branch matches 8 run scoreboard players remove #rw_idx ec.temp 800

# Check divisibility by 10 (big bonus) then by 5 (small bonus)
scoreboard players operation #rw_mod ec.temp = #rw_idx ec.temp
scoreboard players operation #rw_mod ec.temp %= #10 ec.const
execute if score #rw_mod ec.temp matches 0 unless score #rw_idx ec.temp matches 0 run scoreboard players set #rw_bonus_big ec.temp 1
execute if score #rw_mod ec.temp matches 0 unless score #rw_idx ec.temp matches 0 run scoreboard players set #rw_bonus_crate ec.temp 1

scoreboard players operation #rw_mod ec.temp = #rw_idx ec.temp
scoreboard players operation #rw_mod ec.temp %= #5 ec.const
execute if score #rw_mod ec.temp matches 0 unless score #rw_idx ec.temp matches 0 unless score #rw_bonus_big ec.temp matches 1 run scoreboard players set #rw_bonus_crate ec.temp 1

# === ENDGAME SPECIAL COIN OVERRIDES ===
execute if score @s sm.chapter matches 825 run scoreboard players set #rw_coins ec.temp 250
execute if score @s sm.chapter matches 850 run scoreboard players set #rw_coins ec.temp 500

# === REWARD POOL INDEX (for varied loot) ===
# Use chapter mod 10 to rotate through 10 different reward types per branch
scoreboard players operation #rw_pool ec.temp = @s sm.chapter
scoreboard players operation #rw_pool ec.temp %= #10 ec.const
