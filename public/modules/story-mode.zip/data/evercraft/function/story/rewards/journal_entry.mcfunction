# Record a journey log entry for chapter completion
# @s = player who completed a chapter

# Build event string based on branch
execute if score @s sm.branch matches 0 run data modify storage evercraft:journey temp.event set value "\u2726 Story: Main quest chapter completed"
execute if score @s sm.branch matches 1 run data modify storage evercraft:journey temp.event set value "\u2726 Story: Combat branch chapter completed"
execute if score @s sm.branch matches 2 run data modify storage evercraft:journey temp.event set value "\u2726 Story: Artisan branch chapter completed"
execute if score @s sm.branch matches 3 run data modify storage evercraft:journey temp.event set value "\u2726 Story: Explorer branch chapter completed"
execute if score @s sm.branch matches 4 run data modify storage evercraft:journey temp.event set value "\u2726 Story: Social branch chapter completed"
execute if score @s sm.branch matches 5 run data modify storage evercraft:journey temp.event set value "\u2726 Story: Lore branch chapter completed"
execute if score @s sm.branch matches 6 run data modify storage evercraft:journey temp.event set value "\u2726 Story: Villain branch chapter completed"
execute if score @s sm.branch matches 7 run data modify storage evercraft:journey temp.event set value "\u2726 Story: Seasonal branch chapter completed"
execute if score @s sm.branch matches 8 run data modify storage evercraft:journey temp.event set value "\u2726 Story: Endgame branch chapter completed"

# Only log every 5th chapter to avoid journal spam (milestone chapters)
scoreboard players operation #rw_jmod ec.temp = @s sm.chapter
execute if score @s sm.branch matches 1 run scoreboard players remove #rw_jmod ec.temp 100
execute if score @s sm.branch matches 2 run scoreboard players remove #rw_jmod ec.temp 200
execute if score @s sm.branch matches 3 run scoreboard players remove #rw_jmod ec.temp 300
execute if score @s sm.branch matches 4 run scoreboard players remove #rw_jmod ec.temp 400
execute if score @s sm.branch matches 5 run scoreboard players remove #rw_jmod ec.temp 500
execute if score @s sm.branch matches 6 run scoreboard players remove #rw_jmod ec.temp 600
execute if score @s sm.branch matches 7 run scoreboard players remove #rw_jmod ec.temp 700
execute if score @s sm.branch matches 8 run scoreboard players remove #rw_jmod ec.temp 800
scoreboard players operation #rw_jmod ec.temp %= #5 ec.const
execute if score #rw_jmod ec.temp matches 0 run function evercraft:stats/journey/record
