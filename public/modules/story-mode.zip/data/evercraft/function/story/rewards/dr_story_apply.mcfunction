# Apply ec.dr_story as a luck attribute modifier (Audit #2 2026-05-28 F1 P0).
# @s = player whose ec.dr_story scoreboard was just incremented OR who just joined.
# Mirrors milestones/complete/apply_dr_modifier.mcfunction.
#
# Scoreboard scale: ec.dr_story is stored as DR × 10 (e.g. +50 = +0.5 DR). We
# write to storage as a double with scale 0.1 so the attribute receives the
# correct floating-point DR value.

# Remove any prior modifier so we don't double-stack on re-apply.
attribute @s minecraft:luck modifier remove evercraft:story_dr_bonus

# Skip apply when score is zero (no bonus yet — nothing to add).
execute if score @s ec.dr_story matches ..0 run return 0

# Store current ec.dr_story as a double-scaled storage value.
execute store result storage evercraft:story temp.dr_total double 0.1 run scoreboard players get @s ec.dr_story

# Apply via macro (mirrors milestones/apply_dr_modifier signature).
function evercraft:story/rewards/_dr_story_apply_macro with storage evercraft:story temp
