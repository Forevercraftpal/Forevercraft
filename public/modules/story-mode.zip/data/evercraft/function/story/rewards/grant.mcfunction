# Story Rewards — Main entry point
# @s = player who just completed a chapter
# Called from on_complete.mcfunction
# Gates on difficulty: Pioneer (3) gets nothing

# Pioneer skip
execute if score @s ec.difficulty matches 3 run return 0

# Calculate reward tier, bonus crate flags, pool index
function evercraft:story/rewards/calc_tier

# Reward header
tellraw @s [{"text":"  "},{"text":"─── Chapter Rewards ───","color":"dark_gray"}]

# Grant base rewards (coins, XP, crate)
function evercraft:story/rewards/give_coins
function evercraft:story/rewards/give_xp
function evercraft:story/rewards/give_crate

# Grant branch-themed bonus items (varied pool — Newcomer gets 2 items, Adventurer gets 1)
function evercraft:story/rewards/give_bonus
execute if score @s ec.difficulty matches 1 run function evercraft:story/rewards/give_bonus_extra

# Bonus milestone crate (every 5/10 chapters)
execute if score #rw_bonus_crate ec.temp matches 1 run function evercraft:story/rewards/give_bonus_crate
