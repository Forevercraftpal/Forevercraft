# Milestone bonus crate — every 5 chapters (small) or every 10 (big)
# RE-P4 fix (Joseph verdict 2026-06-10): grant the PLACEABLE crate item (crates/items/<tier>)
# instead of inlining contents via `loot give` — `loot give` has no opener context, so the
# difficulty-gated accessory pools silently collapsed to the 5% Pioneer branch for everyone.
# The crate item resolves its container_loot at PLACEMENT, where `this` = the real opener.
# @s = player, #rw_bonus_big ec.temp = 1 if every-10 milestone

# Small bonus crate (every 5): same tier as current
# Inv-full guard: drop at the player's feet rather than void on a full inventory.
execute store result score #inv_full ec.var run function evercraft:util/check_inv_full
execute unless score #rw_bonus_big ec.temp matches 1 if score #rw_tier ec.temp matches 1 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:crates/items/common
execute unless score #rw_bonus_big ec.temp matches 1 if score #rw_tier ec.temp matches 1 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:crates/items/common
execute unless score #rw_bonus_big ec.temp matches 1 if score #rw_tier ec.temp matches 2 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:crates/items/uncommon
execute unless score #rw_bonus_big ec.temp matches 1 if score #rw_tier ec.temp matches 2 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:crates/items/uncommon
execute unless score #rw_bonus_big ec.temp matches 1 if score #rw_tier ec.temp matches 3 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:crates/items/rare
execute unless score #rw_bonus_big ec.temp matches 1 if score #rw_tier ec.temp matches 3 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:crates/items/rare
execute unless score #rw_bonus_big ec.temp matches 1 if score #rw_tier ec.temp matches 4 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:crates/items/ornate
execute unless score #rw_bonus_big ec.temp matches 1 if score #rw_tier ec.temp matches 4 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:crates/items/ornate
execute unless score #rw_bonus_big ec.temp matches 1 if score #rw_tier ec.temp matches 5 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:crates/items/exquisite
execute unless score #rw_bonus_big ec.temp matches 1 if score #rw_tier ec.temp matches 5 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:crates/items/exquisite
execute unless score #rw_bonus_big ec.temp matches 1 run tellraw @s [{"text":"  "},{"text":"\u2726 ","color":"gold"},{"text":"Milestone Bonus Crate!","color":"yellow","italic":true}]

# Big bonus crate (every 10): +1 tier (capped at mythical)
execute if score #rw_bonus_big ec.temp matches 1 if score #rw_tier ec.temp matches 1 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:crates/items/uncommon
execute if score #rw_bonus_big ec.temp matches 1 if score #rw_tier ec.temp matches 1 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:crates/items/uncommon
execute if score #rw_bonus_big ec.temp matches 1 if score #rw_tier ec.temp matches 2 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:crates/items/rare
execute if score #rw_bonus_big ec.temp matches 1 if score #rw_tier ec.temp matches 2 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:crates/items/rare
execute if score #rw_bonus_big ec.temp matches 1 if score #rw_tier ec.temp matches 3 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:crates/items/ornate
execute if score #rw_bonus_big ec.temp matches 1 if score #rw_tier ec.temp matches 3 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:crates/items/ornate
execute if score #rw_bonus_big ec.temp matches 1 if score #rw_tier ec.temp matches 4 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:crates/items/exquisite
execute if score #rw_bonus_big ec.temp matches 1 if score #rw_tier ec.temp matches 4 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:crates/items/exquisite
execute if score #rw_bonus_big ec.temp matches 1 if score #rw_tier ec.temp matches 5 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:crates/items/mythical
execute if score #rw_bonus_big ec.temp matches 1 if score #rw_tier ec.temp matches 5 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:crates/items/mythical
execute if score #rw_bonus_big ec.temp matches 1 run tellraw @s [{"text":"  "},{"text":"\u2726\u2726 ","color":"gold"},{"text":"Major Milestone Crate!","color":"gold","bold":true}]

playsound minecraft:entity.player.levelup master @s ~ ~ ~ 0.6 1.4

# Warn if inventory was full (items dropped at feet)
execute store result score #inv_check ec.temp run clear @s * 0
execute if score #inv_check ec.temp matches 0 run tellraw @s [{"text":"  "},{"text":"(Inventory full \u2014 bonus crate dropped at your feet)","color":"gray","italic":true}]
