# Story chapter reaper deed — renown by reward tier
# @s = player, #rw_tier ec.temp = 1-5
execute if score #rw_tier ec.temp matches 1 run scoreboard players set #rp_quest_tier ec.temp 1
execute if score #rw_tier ec.temp matches 2 run scoreboard players set #rp_quest_tier ec.temp 2
execute if score #rw_tier ec.temp matches 3 run scoreboard players set #rp_quest_tier ec.temp 3
execute if score #rw_tier ec.temp matches 4 run scoreboard players set #rp_quest_tier ec.temp 4
execute if score #rw_tier ec.temp matches 5 run scoreboard players set #rp_quest_tier ec.temp 5
function evercraft:reaper/deeds/on_quest_complete
