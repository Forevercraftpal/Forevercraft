# Newcomer extra bonus — a second varied item using pool index +5
# @s = player

# Shift pool by 5 to get a different item type than the first bonus
scoreboard players add #rw_pool ec.temp 5
scoreboard players operation #rw_pool ec.temp %= #10 ec.const
function evercraft:story/rewards/give_bonus
# Restore pool
scoreboard players remove #rw_pool ec.temp 5
