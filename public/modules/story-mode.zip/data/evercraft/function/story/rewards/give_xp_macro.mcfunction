$experience add @s $(xp) points
