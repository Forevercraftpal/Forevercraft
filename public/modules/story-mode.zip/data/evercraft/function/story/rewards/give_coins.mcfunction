# Award Forever Coins based on #rw_coins ec.temp
# @s = player

scoreboard players operation @s ec.coins += #rw_coins ec.temp

# Display
execute if score #rw_milestone ec.temp matches 1 run tellraw @s [{"text":"  "},{"text":"+","color":"yellow"},{"score":{"name":"#rw_coins","objective":"ec.temp"},"color":"yellow","bold":true},{"text":" Forever Coins","color":"yellow"},{"text":" (milestone bonus!)","color":"gold","italic":true}]
execute unless score #rw_milestone ec.temp matches 1 run tellraw @s [{"text":"  "},{"text":"+","color":"yellow"},{"score":{"name":"#rw_coins","objective":"ec.temp"},"color":"yellow","bold":true},{"text":" Forever Coins","color":"yellow"}]
