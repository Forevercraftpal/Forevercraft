# Seasonal Mastery — reader for ec.story.branch7
# D2 (Joseph-locked 2026-05-28): give branch7 a reader.
# Fires once per player on first Seasonal full-mastery (ch730/reward path only).
# Skip path (ch730/skip) sets branch7=1 but does NOT call this reader (partial-completion).
# Sentinel ec.story.branch7_claimed prevents re-fire on admin reset + re-grant.

# Gate: only fire if branch7 lit + not yet claimed.
execute unless score @s ec.story.branch7 matches 1.. run return 0
execute if score @s ec.story.branch7_claimed matches 1.. run return 0

# Mark claimed first so re-entry guards.
scoreboard players set @s ec.story.branch7_claimed 1

# Title grant
tag @s add ec.title_seasonal_master

# Bonus XP (+100 on top of the ch730/reward's +200)
execute store result score @s ec.xp run scoreboard players add @s ec.xp 100

# Tellraw banner
tellraw @s ""
tellraw @s [{text:"=== ",color:"#8BC34A"},{text:"SEASONAL MASTERY",color:"#8BC34A",bold:true},{text:" ===",color:"#8BC34A"}]
tellraw @s [{text:"All seven Seasonal Chronicles complete.",color:"white"}]
tellraw @s [{text:"  Title Unlocked: ",color:"gray"},{text:"Seasonal Master",color:"#8BC34A",bold:true}]
tellraw @s [{text:"  +100 bonus XP",color:"yellow"}]
tellraw @s ""

# Sound + particle
playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 1 1.0
playsound minecraft:block.beacon.power_select master @s ~ ~ ~ 1 1.2
execute at @s run particle minecraft:totem_of_undying ~ ~1 ~ 0.5 0.8 0.5 0.1 30
