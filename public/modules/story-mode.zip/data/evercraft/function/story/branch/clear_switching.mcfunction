# Clear sm.switching sentinel tag (Audit #2 2026-05-28 F3 race sentinel)
# Called 5t after switch_to_branch via schedule. Player-agnostic clear is fine
# here — sm.switching is a per-player tag and gets re-applied per-call.
tag @a remove sm.switching
