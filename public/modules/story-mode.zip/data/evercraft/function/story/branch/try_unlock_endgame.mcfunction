# Unlock The Eternal Path (bit 7, value 128) — triggered by Ch50
scoreboard players operation #bit_check ec.temp = @s sm.branch_unlocked
scoreboard players operation #bit_check ec.temp /= #branch_endgame ec.const
scoreboard players operation #bit_check ec.temp %= #2 ec.const
execute if score #bit_check ec.temp matches 0 run scoreboard players operation @s sm.branch_unlocked += #branch_endgame ec.const
execute if score #bit_check ec.temp matches 0 run tellraw @s [{"text":"\n"},{"text":"  ✦ ","color":"gold"},{"text":"Branch Unlocked: ","color":"yellow"},{"text":"The Eternal Path","color":"#FFD700","bold":true},{"text":"\n  Open the ","color":"gray"},{"text":"World Map","color":"aqua"},{"text":" in your Codex to explore it.","color":"gray"},{"text":"\n"}]
execute if score #bit_check ec.temp matches 0 run playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 0.6 1.4
