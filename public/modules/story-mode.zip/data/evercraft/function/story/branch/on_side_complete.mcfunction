# Side chapter completed — increment counter and return to main quest
# @s = player who just finished a side chapter (step=4, branch != 0)

scoreboard players add @s sm.side_done 1

# Celebration
playsound minecraft:entity.player.levelup master @s ~ ~ ~ 0.8 1.2
tellraw @s [{"text":"\n"},{"text":"  \u2726 ","color":"green"},{"text":"Side Chapter Complete!","color":"yellow","bold":true},{"text":" (","color":"gray"},{"score":{"name":"@s","objective":"sm.side_done"},"color":"white"},{"text":" total)","color":"gray"},{"text":"\n"}]

# === BRANCH COMPLETION DETECTION ===
# Check if this was the final chapter of the branch
# Combat: ch160, Craft: ch270, Explore: ch370, Social: ch450, Lore: ch550, Villain: ch650, Seasonal: ch730, Endgame: ch850
execute if score @s sm.chapter matches 160 run function evercraft:story/rewards/branch_complete {branch:"Combat",color:"red"}
execute if score @s sm.chapter matches 270 run function evercraft:story/rewards/branch_complete {branch:"Artisan",color:"gold"}
execute if score @s sm.chapter matches 370 run function evercraft:story/rewards/branch_complete {branch:"Explorer",color:"green"}
execute if score @s sm.chapter matches 450 run function evercraft:story/rewards/branch_complete {branch:"Social",color:"aqua"}
execute if score @s sm.chapter matches 550 run function evercraft:story/rewards/branch_complete {branch:"Lore",color:"light_purple"}
execute if score @s sm.chapter matches 650 run function evercraft:story/rewards/branch_complete {branch:"Villain",color:"dark_red"}
execute if score @s sm.chapter matches 730 run function evercraft:story/rewards/branch_complete {branch:"Seasonal",color:"yellow"}
execute if score @s sm.chapter matches 850 run function evercraft:story/rewards/branch_complete {branch:"Endgame",color:"dark_purple"}

# Return to main quest
function evercraft:story/branch/return_to_main
