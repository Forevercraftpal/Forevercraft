# Return to Main Quest — restore saved chapter
# @s = player who was on a side branch

# Restore main quest chapter
scoreboard players operation @s sm.chapter = @s sm.main_chapter
scoreboard players set @s sm.branch 0

# Restore step to 4 (chapter complete, waiting for gate)
# The player completed this main chapter before branching — they're still waiting for the gate
scoreboard players set @s sm.step 4

# Notify
tellraw @s [{"text":"\n"},{"text":"  ✦ ","color":"gold"},{"text":"Returned to Main Quest","color":"yellow","bold":true},{"text":" — Chapter ","color":"white"},{"score":{"name":"@s","objective":"sm.chapter"},"color":"yellow"},{"text":"\n"}]
