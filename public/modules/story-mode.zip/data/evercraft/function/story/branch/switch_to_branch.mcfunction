# Switch active chapter to a side branch chapter
# Macro args: {chapter:<int>, branch:<int>}
# @s = player in story mode

# Race sentinel (Audit #2 2026-05-28 F3 P0-on-wire): refuse same-tick re-entry
# (double-click, held interaction, two callers in same tick).
execute if entity @s[tag=sm.switching] run return 0

# Branch-switch refusal: must finish or return from current side branch before
# switching to a new one. Without this, a second switch_to_branch call clobbers
# sm.chapter and silently abandons the in-progress side quest.
execute unless score @s sm.branch matches 0 run return run tellraw @s [{"text":"\n"},{"text":"  ","color":"gray"},{"text":"Finish or return from your current side quest first.","color":"yellow"},{"text":"\n"}]

# Set sentinel + schedule its clear (5t covers the click-handler dispatch window).
tag @s add sm.switching
schedule function evercraft:story/branch/clear_switching 5t replace

# Save main quest progress ONLY if currently on main quest (branch=0)
# If already on a side branch, main_chapter is already saved
execute if score @s sm.branch matches 0 run scoreboard players operation @s sm.main_chapter = @s sm.chapter

# Set new active chapter and branch
$scoreboard players set @s sm.chapter $(chapter)
$scoreboard players set @s sm.branch $(branch)
scoreboard players set @s sm.step 0
scoreboard players set @s sm.quest_prog 0
scoreboard players set @s sm.quest_goal 0
scoreboard players set @s sm.quest_type 0

# Dispatch to chapter start (uses existing macro system)
function evercraft:story/chapter/dispatch_start

# Notify
tellraw @s [{"text":"\n"},{"text":"  ✦ ","color":"gold"},{"text":"Side Quest Started","color":"aqua","bold":true},{"text":"\n  Your main quest progress has been saved.","color":"gray"},{"text":"\n"}]
