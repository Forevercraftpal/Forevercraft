# Unlock Seasonal Chronicles (bit 6, value 64) — triggered by Ch23
scoreboard players operation #bit_check ec.temp = @s sm.branch_unlocked
scoreboard players operation #bit_check ec.temp /= #branch_seasonal ec.const
scoreboard players operation #bit_check ec.temp %= #2 ec.const
execute if score #bit_check ec.temp matches 0 run scoreboard players operation @s sm.branch_unlocked += #branch_seasonal ec.const
# Unlock the seasonal branch entry chapter (ch701) so its check.mcfunction can run
execute if score #bit_check ec.temp matches 0 run scoreboard players set @s ec.story.ch701_unlock 1
execute if score #bit_check ec.temp matches 0 run tellraw @s [{"text":"\n"},{"text":"  ✦ ","color":"gold"},{"text":"Branch Unlocked: ","color":"yellow"},{"text":"Seasonal Chronicles","color":"#8BC34A","bold":true},{"text":"\n  Open the ","color":"gray"},{"text":"World Map","color":"aqua"},{"text":" in your Codex to explore it.","color":"gray"},{"text":"\n"}]
execute if score #bit_check ec.temp matches 0 run playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 0.6 1.4
