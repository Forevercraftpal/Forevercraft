# Unlock Artisan's Journey (bit 1, value 2) — triggered by Ch9
scoreboard players operation #bit_check ec.temp = @s sm.branch_unlocked
scoreboard players operation #bit_check ec.temp /= #branch_craft ec.const
scoreboard players operation #bit_check ec.temp %= #2 ec.const
execute if score #bit_check ec.temp matches 0 run scoreboard players operation @s sm.branch_unlocked += #branch_craft ec.const
execute if score #bit_check ec.temp matches 0 run tellraw @s [{"text":"\n"},{"text":"  ✦ ","color":"gold"},{"text":"Branch Unlocked: ","color":"yellow"},{"text":"Artisan's Journey","color":"green","bold":true},{"text":"\n  Open the ","color":"gray"},{"text":"World Map","color":"aqua"},{"text":" in your Codex to explore it.","color":"gray"},{"text":"\n"}]
execute if score #bit_check ec.temp matches 0 run playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 0.6 1.4
