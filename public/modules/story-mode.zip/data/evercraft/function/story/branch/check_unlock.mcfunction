# Branch Unlock Check — called on every chapter completion
# @s = player who just completed a chapter
# Only fires for the specific milestone chapters (no-op for others)

execute if score @s sm.chapter matches 5 run function evercraft:story/branch/try_unlock_explore
execute if score @s sm.chapter matches 8 run function evercraft:story/branch/try_unlock_combat
execute if score @s sm.chapter matches 9 run function evercraft:story/branch/try_unlock_craft
execute if score @s sm.chapter matches 13 run function evercraft:story/branch/try_unlock_social
execute if score @s sm.chapter matches 23 run function evercraft:story/branch/try_unlock_seasonal
execute if score @s sm.chapter matches 24 run function evercraft:story/branch/try_unlock_lore
execute if score @s sm.chapter matches 27 run function evercraft:story/branch/try_unlock_villain
execute if score @s sm.chapter matches 50 run function evercraft:story/branch/try_unlock_endgame
