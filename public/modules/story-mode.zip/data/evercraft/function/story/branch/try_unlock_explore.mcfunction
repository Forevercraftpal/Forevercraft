# Unlock Explorer's Atlas (bit 2, value 4) — triggered by Ch5
scoreboard players operation #bit_check ec.temp = @s sm.branch_unlocked
scoreboard players operation #bit_check ec.temp /= #branch_explore ec.const
scoreboard players operation #bit_check ec.temp %= #2 ec.const
execute if score #bit_check ec.temp matches 0 run scoreboard players operation @s sm.branch_unlocked += #branch_explore ec.const
execute if score #bit_check ec.temp matches 0 run tellraw @s [{"text":"\n"},{"text":"  ✦ ","color":"gold"},{"text":"Branch Unlocked: ","color":"yellow"},{"text":"Explorer's Atlas","color":"dark_aqua","bold":true},{"text":"\n  Open the ","color":"gray"},{"text":"World Map","color":"aqua"},{"text":" in your Codex to explore it.","color":"gray"},{"text":"\n"}]
execute if score #bit_check ec.temp matches 0 run playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 0.6 1.4
