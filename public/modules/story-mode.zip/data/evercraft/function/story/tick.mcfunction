# Story Mode Tick — Runs every 5 seconds for story mode players
# Checks quest progress and gate unlocks

execute as @a[scores={sm.mode=1..2}] run function evercraft:story/tick_player

# Reschedule
schedule function evercraft:story/tick 100t replace
