# Story Mode — Initialize scoreboards and schedule tick
# Part of "The Legend of Forevercraft" narrative system
#
# Structure (2026-05-28 polish wave P6):
#   - Scoreboard declarations live in story/load/declare_objectives (one-shot, guarded
#     by #story_loaded ec.var to suppress per-/reload "objective already exists" warnings).
#   - Schedule rearms + showcase bootstrap fire every reload (they must, since /reload
#     drops the schedule queue and the showcase teams need re-binding).

# === ONE-TIME OBJECTIVE DECLARATIONS (skipped on subsequent /reloads) ===
execute unless score #story_loaded ec.var matches 1 run function evercraft:story/load/declare_objectives

# === SHOWCASE SYSTEM ===
# Title teams + aura tick bootstrap (must re-run every reload — teams + tick reschedule)
function evercraft:story/showcase/load

# /reload defense-in-depth: clear any orphan next_step schedules from pre-Audit-#2 ticks
# (Audit #2 W3 W5.5 — replaced by sm.conv_wait_until per-player pacing).
schedule clear evercraft:story/convergence/next_step

# Schedule story tick (5 second interval)
schedule function evercraft:story/tick 100t replace

# Schedule convergence fast-ticker (Audit #2 2026-05-28 F1 Option D — existence-gated)
schedule function evercraft:story/convergence/tick_active 1t replace
