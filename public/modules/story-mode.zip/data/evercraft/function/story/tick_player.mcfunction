# Story Mode Per-Player Tick
# @s = player in story mode (sm.mode=1)

# If chapter complete (step=4), check if next chapter can unlock
execute if score @s sm.step matches 4 run function evercraft:story/gate/check_unlock
execute if score @s sm.step matches 4 run return 0

# Check quest progress for current chapter (silent — no auto-reminders)
# Only dispatch for chapters whose check files exist (main quest ch1-50 guaranteed;
# side chapter ch101+ files may not exist yet — skip to avoid log warnings)
execute if score @s sm.step matches 1..3 if score @s sm.branch matches 0 run function evercraft:story/quest/check_progress
execute if score @s sm.step matches 1..3 unless score @s sm.branch matches 0 run function evercraft:story/quest/check_progress_branch
