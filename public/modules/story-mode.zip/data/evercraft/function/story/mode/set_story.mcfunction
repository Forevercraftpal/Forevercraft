# Player Chose Story Mode
# @s = player

scoreboard players set @s sm.mode 1
scoreboard players set @s sm.act 1
scoreboard players set @s sm.chapter 1
scoreboard players set @s sm.step 0

tellraw @s [{"text":"\u2726 ","color":"gold"},{"text":"Story Mode activated!","color":"yellow","bold":true}]
playsound minecraft:entity.player.levelup master @s ~ ~ ~ 0.8 1.2

# Chain to difficulty selection (step 2 of consolidated flow)
# Chronicle path picker comes AFTER difficulty + tutorial
execute unless score @s ec.difficulty matches 1..3 run function evercraft:difficulty/prompt

# Joseph 2026-06-13 (#93): inline chain to step 2 if mid-death-flow. The
# trigger_dispatch sm.pick handler also calls this, but inlining here is
# defensive in case the trigger pipeline drops the score before dispatch.
execute if entity @s[tag=pioneer.step1] run function evercraft:difficulty/pioneer_emit_pioneer_choice
