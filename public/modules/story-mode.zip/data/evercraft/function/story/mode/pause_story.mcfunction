# Pause Story Mode — Progress preserved, tick loop stops
# @s = story mode player (sm.mode=1)
# Sets mode to 3 (paused), NOT 2 (never-started freeplay)

scoreboard players set @s sm.mode 3

tellraw @s [{"text":"[Story] ","color":"gold"},{"text":"Story paused. ","color":"white"},{"text":"Your progress is saved at Chapter ","color":"gray"},{"score":{"name":"@s","objective":"sm.chapter"},"color":"yellow"},{"text":". Come back anytime from the Codex.","color":"gray"}]
playsound minecraft:block.note_block.bass master @s ~ ~ ~ 0.5 0.8
