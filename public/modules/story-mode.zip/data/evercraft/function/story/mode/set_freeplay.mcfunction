# Player Chose Free Play — Story available, no gates
# @s = player

scoreboard players set @s sm.mode 2

# Initialize story state (same as story mode, but no gates)
scoreboard players set @s sm.act 1
scoreboard players set @s sm.chapter 1
scoreboard players set @s sm.step 0
scoreboard players set @s sm.quest_prog 0

# Auto-unlock ALL story branches (8 branches = bits 0-7 = 255)
scoreboard players set @s sm.branch_unlocked 255

tellraw @s [{"text":"\u2726 ","color":"aqua"},{"text":"Free Play activated! ","color":"white","bold":true},{"text":"All systems are available \u2014 no progression gates.","color":"gray"}]
tellraw @s [{"text":"  "},{"text":"Story chapters are available for a guided experience. Follow them or explore freely!","color":"dark_gray","italic":true}]

playsound minecraft:entity.experience_orb.pickup master @s ~ ~ ~ 0.8 1.0

# Chain to difficulty selection (step 2 of consolidated flow)
# Path picker will follow after difficulty + tutorial
execute unless score @s ec.difficulty matches 1..3 run function evercraft:difficulty/prompt

# Joseph 2026-06-13 (#93): inline chain to step 2 if mid-death-flow.
execute if entity @s[tag=pioneer.step1] run function evercraft:difficulty/pioneer_emit_pioneer_choice
