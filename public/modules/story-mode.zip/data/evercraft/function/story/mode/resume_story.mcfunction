# Resume Paused Story — Pick up exactly where they left off
# @s = paused player (sm.mode=3)

scoreboard players set @s sm.mode 1

tellraw @s [{"text":"[Story] ","color":"gold"},{"text":"Welcome back! ","color":"white"},{"text":"Resuming Chapter ","color":"gray"},{"score":{"name":"@s","objective":"sm.chapter"},"color":"yellow"},{"text":", Step ","color":"gray"},{"score":{"name":"@s","objective":"sm.step"},"color":"yellow"},{"text":".","color":"gray"}]

# Show their current objective
execute store result storage evercraft:story temp.chapter int 1 run scoreboard players get @s sm.chapter
execute store result storage evercraft:story temp.step int 1 run scoreboard players get @s sm.step
function evercraft:story/notify/show_objective with storage evercraft:story temp

playsound minecraft:entity.player.levelup master @s ~ ~ ~ 0.8 1.2
