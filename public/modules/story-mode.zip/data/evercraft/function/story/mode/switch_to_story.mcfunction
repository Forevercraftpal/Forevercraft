# Switch from Free-Play to Story Mode — Places player at appropriate chapter
# @s = player switching (currently sm.mode=2 or sm.mode=3)

# If paused (mode=3), resume instead of recalculating
execute if score @s sm.mode matches 3 run function evercraft:story/mode/resume_story
execute if score @s sm.mode matches 1 run return 0

# Calculate appropriate chapter based on DR (luck attribute, scaled x10)
execute store result score #player_dr ec.temp run attribute @s minecraft:luck get 10
scoreboard players operation #player_dr ec.temp /= #10 ec.const

# Clamp to 1-50
execute if score #player_dr ec.temp matches ..0 run scoreboard players set #player_dr ec.temp 1
execute if score #player_dr ec.temp matches 51.. run scoreboard players set #player_dr ec.temp 50

# Set chapter and mark all previous as "done"
scoreboard players operation @s sm.chapter = #player_dr ec.temp
scoreboard players operation @s sm.chapters_done = #player_dr ec.temp
scoreboard players remove @s sm.chapters_done 1

# Calculate act: act = (chapter - 1) / 10 + 1
scoreboard players operation @s sm.act = @s sm.chapter
scoreboard players remove @s sm.act 1
scoreboard players operation @s sm.act /= #10 ec.const
scoreboard players add @s sm.act 1

# Set mode and start at chapter intro
scoreboard players set @s sm.mode 1
scoreboard players set @s sm.step 0
scoreboard players set @s sm.quest_prog 0

# Update showcase to match progress
scoreboard players operation @s sm.showcase_act = @s sm.act
scoreboard players remove @s sm.showcase_act 1
execute if score @s sm.showcase_act matches ..0 run scoreboard players set @s sm.showcase_act 0

# Offer path choice
function evercraft:story/mode/choose_path

tellraw @s [{"text":"[Story] ","color":"gold"},{"text":"Welcome to the story! You've been placed at ","color":"white"},{"text":"Chapter ","color":"yellow"},{"score":{"name":"@s","objective":"sm.chapter"},"color":"gold","bold":true},{"text":" based on your progress.","color":"white"}]
playsound minecraft:entity.player.levelup master @s ~ ~ ~ 0.8 1.2
