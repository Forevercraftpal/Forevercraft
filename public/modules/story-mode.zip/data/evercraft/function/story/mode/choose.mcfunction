# Story vs Free-Play Selection — Shown after difficulty choice
# @s = player

title @s times 10 60 20
title @s title {"text":"Forevercraft","color":"gold"}
title @s subtitle {"text":"Choose your path...","color":"white","italic":true}

tellraw @s ""
tellraw @s {"text":"\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550","color":"dark_gray"}
tellraw @s [{"text":"  "},{"text":"[\u2726 Story Mode]","color":"gold","bold":true,"click_event":{"action":"run_command","command":"/trigger sm.pick set 1"},"hover_event":{"action":"show_text","value":[{"text":"The Legend of Forevercraft","color":"gold","bold":true},{"text":"\n"},{"text":"A guided journey through all systems","color":"gray"},{"text":"\n"},{"text":"Chapter-based progression with narrative","color":"gray"},{"text":"\n\n"},{"text":"Recommended for first-time players.","color":"dark_gray","italic":true}]}}]
tellraw @s [{"text":"  "},{"text":"A guided adventure through the world of Forevercraft","color":"gray","italic":true}]
tellraw @s ""
tellraw @s [{"text":"  "},{"text":"[\u2726 Free Play]","color":"aqua","bold":true,"click_event":{"action":"run_command","command":"/trigger sm.pick set 2"},"hover_event":{"action":"show_text","value":[{"text":"Free Play Mode","color":"aqua","bold":true},{"text":"\n"},{"text":"All systems available immediately","color":"gray"},{"text":"\n"},{"text":"Story chapters available with no gates","color":"gray"},{"text":"\n"},{"text":"Follow the story or explore freely","color":"gray"},{"text":"\n\n"},{"text":"No progression requirements.","color":"dark_gray","italic":true}]}}]
tellraw @s [{"text":"  "},{"text":"Everything unlocked \u2014 story optional, no gates","color":"gray","italic":true}]
tellraw @s {"text":"\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550","color":"dark_gray"}

playsound minecraft:block.amethyst_block.resonate master @s ~ ~ ~ 0.8 1.2
