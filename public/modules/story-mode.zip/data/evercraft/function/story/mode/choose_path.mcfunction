# Dream Path vs Craft Path vs Both — Path selection for Story Mode
# @s = player

tellraw @s ""
tellraw @s [{"text":"  "},{"text":"Which chronicle will you follow?","color":"white"}]
tellraw @s ""
tellraw @s [{"text":"  "},{"text":"\u2694 The Adventurer's Chronicle","color":"red","bold":true,"click_event":{"action":"run_command","command":"/trigger sm.path_pick set 1"},"hover_event":{"action":"show_text","value":[{"text":"The Dream Path","color":"red","bold":true},{"text":"\n"},{"text":"Combat, exploration, bosses, dungeons","color":"gray"},{"text":"\n"},{"text":"Gated by Dream Rate progression","color":"gray"},{"text":"\n\n"},{"text":"For those who live for adventure.","color":"dark_gray","italic":true}]}}]
tellraw @s [{"text":"  "},{"text":"Combat \u2022 Exploration \u2022 Discovery","color":"gray","italic":true}]
tellraw @s ""
tellraw @s [{"text":"  "},{"text":"\u2692 The Artisan's Almanac","color":"green","bold":true,"click_event":{"action":"run_command","command":"/trigger sm.path_pick set 2"},"hover_event":{"action":"show_text","value":[{"text":"The Craft Path","color":"green","bold":true},{"text":"\n"},{"text":"Cooking, forging, fishing, housing","color":"gray"},{"text":"\n"},{"text":"Gated by Craft Rate progression","color":"gray"},{"text":"\n\n"},{"text":"For those who build worlds.","color":"dark_gray","italic":true}]}}]
tellraw @s [{"text":"  "},{"text":"Crafting \u2022 Building \u2022 Trade","color":"gray","italic":true}]
tellraw @s ""
tellraw @s [{"text":"  "},{"text":"\u2605 Both Chronicles","color":"gold","bold":true,"click_event":{"action":"run_command","command":"/trigger sm.path_pick set 3"},"hover_event":{"action":"show_text","value":[{"text":"The Complete Legend","color":"gold","bold":true},{"text":"\n"},{"text":"Follow BOTH paths simultaneously","color":"gray"},{"text":"\n"},{"text":"See the full story from every angle","color":"gray"},{"text":"\n"},{"text":"Requires both DR and CR progression","color":"gray"},{"text":"\n\n"},{"text":"The definitive Forevercraft experience.","color":"dark_gray","italic":true}]}}]
tellraw @s [{"text":"  "},{"text":"The complete Legend of Forevercraft","color":"gray","italic":true}]
