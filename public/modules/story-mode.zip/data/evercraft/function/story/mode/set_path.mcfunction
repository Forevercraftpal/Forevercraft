# Path Selection Handler — Called from trigger dispatch
# @s = player, sm.path_pick = 1 (Dream), 2 (Craft), or 3 (Both)

# Copy trigger value to persistent path score
scoreboard players operation @s sm.path = @s sm.path_pick

# C1/S1 SEED (the ONLY edit to set_path): seed the Chronicle lens ec.chron_view
# from this choice ONCE. sm.path maps 1:1 onto ec.chron_view (1=Adventurer,
# 2=Crafter, 3=Both). Guarded `unless … matches 1..3` so it never overwrites a
# later Settings lens change (chronicle/set_view is the sole writer thereafter;
# the Story branch + the 87 sm.path readers are untouched).
execute unless score @s ec.chron_view matches 1..3 run scoreboard players operation @s ec.chron_view = @s sm.path

# Confirm Dream Path
execute if score @s sm.path matches 1 run tellraw @s [{"text":"\u2726 ","color":"red"},{"text":"The Adventurer's Chronicle ","color":"white","bold":true},{"text":"begins! Your story follows the Dream Path.","color":"gray"}]

# Confirm Craft Path
execute if score @s sm.path matches 2 run tellraw @s [{"text":"\u2726 ","color":"green"},{"text":"The Artisan's Almanac ","color":"white","bold":true},{"text":"begins! Your story follows the Craft Path.","color":"gray"}]

# Confirm Both Paths
execute if score @s sm.path matches 3 run tellraw @s [{"text":"\u2726 ","color":"gold"},{"text":"The Complete Legend ","color":"white","bold":true},{"text":"begins! You follow both chronicles.","color":"gray"}]

# Start Chapter 1 intro
function evercraft:story/chapter/dispatch_start

playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 0.8 1.0
