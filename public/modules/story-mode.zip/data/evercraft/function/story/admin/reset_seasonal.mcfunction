# ══════════════════════════════════════════════════════════════
# Reset all Seasonal Chronicles state (branch 7, ch701-730)
# Called from admin/strip_player_zero.mcfunction during Pioneer wipe.
# Resets: 30 chapter scoreboards + 30 _unlock gates + 30 _replay flags + branch7.
# Explicit lines (not macros) — this is a one-shot reset on a fixed N range.
# ══════════════════════════════════════════════════════════════

# Branch7 finale marker
scoreboard players set @s ec.story.branch7 0

# Chapter state (ec.story.chN, 701..730)
scoreboard players set @s ec.story.ch701 0
scoreboard players set @s ec.story.ch702 0
scoreboard players set @s ec.story.ch703 0
scoreboard players set @s ec.story.ch704 0
scoreboard players set @s ec.story.ch705 0
scoreboard players set @s ec.story.ch706 0
scoreboard players set @s ec.story.ch707 0
scoreboard players set @s ec.story.ch708 0
scoreboard players set @s ec.story.ch709 0
scoreboard players set @s ec.story.ch710 0
scoreboard players set @s ec.story.ch711 0
scoreboard players set @s ec.story.ch712 0
scoreboard players set @s ec.story.ch713 0
scoreboard players set @s ec.story.ch714 0
scoreboard players set @s ec.story.ch715 0
scoreboard players set @s ec.story.ch716 0
scoreboard players set @s ec.story.ch717 0
scoreboard players set @s ec.story.ch718 0
scoreboard players set @s ec.story.ch719 0
scoreboard players set @s ec.story.ch720 0
scoreboard players set @s ec.story.ch721 0
scoreboard players set @s ec.story.ch722 0
scoreboard players set @s ec.story.ch723 0
scoreboard players set @s ec.story.ch724 0
scoreboard players set @s ec.story.ch725 0
scoreboard players set @s ec.story.ch726 0
scoreboard players set @s ec.story.ch727 0
scoreboard players set @s ec.story.ch728 0
scoreboard players set @s ec.story.ch729 0
scoreboard players set @s ec.story.ch730 0

# Unlock gates (ec.story.chN_unlock, 701..730) — reset to 0 (locked).
# ch701 will be re-set to 1 below as the seasonal-branch entry gate.
scoreboard players set @s ec.story.ch701_unlock 0
scoreboard players set @s ec.story.ch702_unlock 0
scoreboard players set @s ec.story.ch703_unlock 0
scoreboard players set @s ec.story.ch704_unlock 0
scoreboard players set @s ec.story.ch705_unlock 0
scoreboard players set @s ec.story.ch706_unlock 0
scoreboard players set @s ec.story.ch707_unlock 0
scoreboard players set @s ec.story.ch708_unlock 0
scoreboard players set @s ec.story.ch709_unlock 0
scoreboard players set @s ec.story.ch710_unlock 0
scoreboard players set @s ec.story.ch711_unlock 0
scoreboard players set @s ec.story.ch712_unlock 0
scoreboard players set @s ec.story.ch713_unlock 0
scoreboard players set @s ec.story.ch714_unlock 0
scoreboard players set @s ec.story.ch715_unlock 0
scoreboard players set @s ec.story.ch716_unlock 0
scoreboard players set @s ec.story.ch717_unlock 0
scoreboard players set @s ec.story.ch718_unlock 0
scoreboard players set @s ec.story.ch719_unlock 0
scoreboard players set @s ec.story.ch720_unlock 0
scoreboard players set @s ec.story.ch721_unlock 0
scoreboard players set @s ec.story.ch722_unlock 0
scoreboard players set @s ec.story.ch723_unlock 0
scoreboard players set @s ec.story.ch724_unlock 0
scoreboard players set @s ec.story.ch725_unlock 0
scoreboard players set @s ec.story.ch726_unlock 0
scoreboard players set @s ec.story.ch727_unlock 0
scoreboard players set @s ec.story.ch728_unlock 0
scoreboard players set @s ec.story.ch729_unlock 0
scoreboard players set @s ec.story.ch730_unlock 0

# Replay flags (ec.story.chN_replay, 701..730) — 1 = chapter completed normally
# at least once; read by skip.mcfunction to decide partial-vs-full reward.
scoreboard players set @s ec.story.ch701_replay 0
scoreboard players set @s ec.story.ch702_replay 0
scoreboard players set @s ec.story.ch703_replay 0
scoreboard players set @s ec.story.ch704_replay 0
scoreboard players set @s ec.story.ch705_replay 0
scoreboard players set @s ec.story.ch706_replay 0
scoreboard players set @s ec.story.ch707_replay 0
scoreboard players set @s ec.story.ch708_replay 0
scoreboard players set @s ec.story.ch709_replay 0
scoreboard players set @s ec.story.ch710_replay 0
scoreboard players set @s ec.story.ch711_replay 0
scoreboard players set @s ec.story.ch712_replay 0
scoreboard players set @s ec.story.ch713_replay 0
scoreboard players set @s ec.story.ch714_replay 0
scoreboard players set @s ec.story.ch715_replay 0
scoreboard players set @s ec.story.ch716_replay 0
scoreboard players set @s ec.story.ch717_replay 0
scoreboard players set @s ec.story.ch718_replay 0
scoreboard players set @s ec.story.ch719_replay 0
scoreboard players set @s ec.story.ch720_replay 0
scoreboard players set @s ec.story.ch721_replay 0
scoreboard players set @s ec.story.ch722_replay 0
scoreboard players set @s ec.story.ch723_replay 0
scoreboard players set @s ec.story.ch724_replay 0
scoreboard players set @s ec.story.ch725_replay 0
scoreboard players set @s ec.story.ch726_replay 0
scoreboard players set @s ec.story.ch727_replay 0
scoreboard players set @s ec.story.ch728_replay 0
scoreboard players set @s ec.story.ch729_replay 0
scoreboard players set @s ec.story.ch730_replay 0
