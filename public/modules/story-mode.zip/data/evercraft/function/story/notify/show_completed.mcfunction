# Show Completed Step — displays what the player just accomplished
# Called with storage: temp.chapter and temp.step (the step that was COMPLETED)

# Show chapter name + step completed
tellraw @s ""
$tellraw @s [{"text":"  "},{"text":"\u2714 ","color":"green"},{"text":"Chapter $(chapter) \u2014 Step $(step) Complete!","color":"green"}]

# Show what the completed objective was (reuses existing objective file)
$function evercraft:story/chapter/ch$(chapter)/objective_$(step)
