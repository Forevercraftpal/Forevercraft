# Show Current Objective — Macro dispatcher
# Used by both on_step_unlock (auto) AND briefing_click (player-initiated)
# Calls chapter-specific objective_N function
$function evercraft:story/chapter/ch$(chapter)/objective_$(step)
