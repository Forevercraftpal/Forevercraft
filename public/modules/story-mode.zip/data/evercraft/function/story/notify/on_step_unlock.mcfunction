# Step Unlock Notification — Called ONCE from quest/advance when a new step activates
# @s = player, new step is already set in sm.step
# This is the ONLY auto-notification. After this, player must click [Story] to see objective again.

# Subtle title flash
title @s times 5 40 10
title @s subtitle {"text":"New objective available","color":"gray","italic":true}

# === STORYTELLING BEAT ===
# Each chapter has narrative_N.mcfunction files — a line or two from The Land
# that reacts to what the player just accomplished and sets up the next step.
# This is what makes the player CARE.
execute store result storage evercraft:story temp.chapter int 1 run scoreboard players get @s sm.chapter
execute store result storage evercraft:story temp.step int 1 run scoreboard players get @s sm.step
function evercraft:story/notify/show_narrative with storage evercraft:story temp

# Then show the objective
function evercraft:story/notify/show_objective with storage evercraft:story temp

playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.6 1.2
