# Player clicked [Need a tip?] — dispatch to chapter-specific tip
# @s = player

execute store result storage evercraft:story temp.chapter int 1 run scoreboard players get @s sm.chapter
execute store result storage evercraft:story temp.step int 1 run scoreboard players get @s sm.step
function evercraft:story/notify/tip_macro with storage evercraft:story temp
