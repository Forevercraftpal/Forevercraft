# Player clicked [Story] in the daily briefing — show current progress
# @s = player

# Show current chapter + step
tellraw @s [{"text":"[Story] ","color":"gold"},{"text":"Chapter ","color":"white"},{"score":{"name":"@s","objective":"sm.chapter"},"color":"yellow"},{"text":" \u2014 Step ","color":"white"},{"score":{"name":"@s","objective":"sm.step"},"color":"yellow"}]

# Show the objective text
execute store result storage evercraft:story temp.chapter int 1 run scoreboard players get @s sm.chapter
execute store result storage evercraft:story temp.step int 1 run scoreboard players get @s sm.step
function evercraft:story/notify/show_objective with storage evercraft:story temp

# Offer tip button (player must click to see)
tellraw @s [{"text":"  "},{"text":"[Need a tip?]","color":"dark_aqua","italic":true,"click_event":{"action":"run_command","command":"/trigger sm.tip_show set 1"},"hover_event":{"action":"show_text","value":{"text":"Get a hint for completing this objective","color":"aqua"}}}]

playsound minecraft:block.note_block.chime master @s ~ ~ ~ 0.5 1.0
