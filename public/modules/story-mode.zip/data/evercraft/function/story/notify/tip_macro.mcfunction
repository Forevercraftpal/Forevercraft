$function evercraft:story/chapter/ch$(chapter)/tip_$(step)
