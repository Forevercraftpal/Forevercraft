# Show Narrative Beat — Macro dispatcher
# Calls chapter-specific narrative_N function (story reaction to completing previous step)
# Falls back silently if the file doesn't exist (chapters without narrative just skip it)
$function evercraft:story/chapter/ch$(chapter)/narrative_$(step)
