# Ch37 Narrative — Player discovered 4+ party combos
data modify storage evercraft:story temp set value {speaker:"The Land",color:"gold",text:"Four combinations unlocked."}
function evercraft:story/narrator/tell with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"Your party does not just fight together — it resonates."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"Each ability feeds the next, a chain of power that multiplies beyond what any one soul could achieve."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
data modify storage evercraft:notify stage.c set value [{text:"  "},{text:"This is what The Hollow fears most. Not a single hero.",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 70
function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"  "},{text:"An army of people who refuse to stand alone.",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 70
function evercraft:util/notify/emit
data modify storage evercraft:story temp set value {speaker:"The Hollow",color:"dark_red",text:"Friends. How quaint."}
function evercraft:story/narrator/tell with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"I have watched friends turn on each other for far less than what I offer."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"We will see how loyal they are when the ground opens beneath them."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
