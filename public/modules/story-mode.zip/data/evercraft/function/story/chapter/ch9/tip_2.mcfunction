# Ch9 Step 2 Tip: Cook a Meal
tellraw @s [{"text":"  "},{"text":"Tip: ","color":"aqua","bold":true},{"text":"Hold raw food and right-click a lit campfire to place it for cooking. Wait for it to finish and pick up the cooked food — it gives better hunger restoration.","color":"gray","italic":true}]
