# Ch707 Objective 3
tellraw @s [{"text":"  "},{"text":"\u2726 Objective: ","color":"yellow","bold":true},{"text":"Understand the cosmic messages written in light","color":"white"}]
