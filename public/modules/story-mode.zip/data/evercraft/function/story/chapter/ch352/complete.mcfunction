# Ch352 Complete

data modify storage evercraft:story temp set value {speaker:"The Wind",color:"dark_aqua",text:"Overworld hostiles documented. Their patterns mapped, their weaknesses catalogued. The night holds fewer surprises for the educated."}
function evercraft:story/narrator/tell with storage evercraft:story temp
