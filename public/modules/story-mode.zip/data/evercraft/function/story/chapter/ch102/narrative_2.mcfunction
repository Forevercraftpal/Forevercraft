# Ch102 Narrative 2
data modify storage evercraft:story temp set value {speaker:"The Blade",color:"red",text:"The Voidpiercer hums in your hands — it senses prey."}
function evercraft:story/narrator/tell with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"A hunter does not chase; a hunter waits, breathes, and ends things from beyond reach. Ten ranged kills."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"Show me you understand distance is a weapon."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
