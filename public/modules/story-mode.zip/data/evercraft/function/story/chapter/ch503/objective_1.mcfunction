tellraw @s [{"text":"  "},{"text":"✦ Objective: ","color":"yellow","bold":true},{"text":"Identify the Artisan constellation at night","color":"white"}]
