# Ch151 Complete — Floor 40: Crimson Depths
data modify storage evercraft:story temp set value {speaker:"The Blade",color:"red",text:"Floor forty. The crimson heart pounds around you. You have pierced deeper than most warriors ever dare — the castle's living walls have accepted you as part of its blood. The true depths lie below, darker and more savage still."}
function evercraft:story/narrator/tell with storage evercraft:story temp
