# Ch31 Step 3 Objective
tellraw @s [{"text":"  "},{"text":"\u2726 Objective: ","color":"yellow","bold":true},{"text":"Earn 500 coins through your reputation","color":"white"}]
