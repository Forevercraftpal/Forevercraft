# Ch38 Step 2 Objective
tellraw @s [{"text":"  "},{"text":"\u2726 Objective: ","color":"yellow","bold":true},{"text":"Complete 3 constellations","color":"white"}]
