# Ch336 Narrative 2

data modify storage evercraft:story temp set value {speaker:"The Wind",color:"dark_aqua",text:"Wool pathways suggest the builders knew about the Warden."}
function evercraft:story/narrator/tell with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"They did not fight it — they WORKED with it."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"The city was built in silence, on purpose."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
