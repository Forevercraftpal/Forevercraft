# Ch37 Progress Check — Hearts & Swords
# Step 1: Win a duel (DR) or get married (CR)
execute if score @s sm.step matches 1 if score @s sm.path matches 1 if score @s ec.sp_duel_wins matches 1.. run function evercraft:story/quest/advance
execute if score @s sm.step matches 1 if score @s sm.path matches 2 if score @s ec.fr_married matches 1 run function evercraft:story/quest/advance
execute if score @s sm.step matches 1 if score @s sm.path matches 3 if score @s ec.sp_duel_wins matches 1.. if score @s ec.fr_married matches 1 run function evercraft:story/quest/advance
# Step 2: Reach Artisan Rank 45
execute if score @s sm.step matches 2 if score @s ec.cf_rank matches 45.. run function evercraft:story/quest/advance
# Step 3: Defeat 200 mobs
execute if score @s sm.step matches 3 if score @s ach.total_kills matches 200.. run function evercraft:story/quest/advance
