# Chapter 301: The World Awaits
# @s = player starting chapter 301

data modify storage evercraft:story temp set value {chapter:"301",color:"dark_aqua",name:"The World Awaits"}
function evercraft:story/narrator/chapter_title with storage evercraft:story temp

tellraw @s ""
data modify storage evercraft:story temp set value {speaker:"The Wind",color:"dark_aqua",text:"Come, wanderer. The horizon has been waiting for you. Every hill hides a story, every valley holds a secret. Let the wind carry you forward."}
function evercraft:story/narrator/tell with storage evercraft:story temp

scoreboard players set @s sm.step 1
scoreboard players set @s sm.quest_prog 0
scoreboard players set @s sm.quest_goal 3
scoreboard players set @s sm.quest_type 1

tellraw @s ""
tellraw @s [{"text":"  "},{"text":"\u2726 Objective: ","color":"yellow","bold":true},{"text":"Visit 3 different biomes","color":"white"}]
playsound minecraft:block.note_block.chime master @s ~ ~ ~ 0.5 1.4
