# Ch104 Narrative 3
data modify storage evercraft:story temp set value {speaker:"The Blade",color:"red",text:"Grace in motion, death in every pirouette."}
function evercraft:story/narrator/tell with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"Now master Tempest Waltz — the Zephyr Edge's signature move."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"Eight times you must become the storm itself, untouchable and devastating."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
