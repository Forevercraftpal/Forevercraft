# Chapter 158: Floor 90: Edge of Oblivion
data modify storage evercraft:story temp set value {chapter:"158",color:"dark_red",name:"Floor 90: Edge of Oblivion"}
function evercraft:story/narrator/chapter_title with storage evercraft:story temp
tellraw @s ""
data modify storage evercraft:story temp set value {speaker:"The Blade",color:"red",text:"Floor ninety. The Edge of Oblivion — where the castle meets the void. The walls thin, reality frays, and you can see the nothingness that waits beyond the infinite. Ten more floors stand between you and the Eternal Throne. Each one will try to erase you from existence."}
function evercraft:story/narrator/tell with storage evercraft:story temp
scoreboard players set @s sm.step 1
scoreboard players set @s sm.quest_prog 0
scoreboard players set @s sm.quest_goal 3
scoreboard players set @s sm.quest_type 1
tellraw @s ""
tellraw @s [{"text":"  "},{"text":"\u2726 Objective: ","color":"yellow","bold":true},{"text":"Reach castle floor 85","color":"white"}]
playsound minecraft:block.note_block.chime master @s ~ ~ ~ 0.5 1.4
