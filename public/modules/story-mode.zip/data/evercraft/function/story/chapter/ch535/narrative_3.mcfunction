# Ch535 Narrative 3

data modify storage evercraft:story temp set value {speaker:"The Stars",color:"blue",text:"The distribution teaches risk assessment."}
function evercraft:story/narrator/tell with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"Surface ores are safe and common."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"Deep ores are dangerous and rare."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"The world grades its lessons by depth."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
