# Ch363 Narrative 1 — intro covered in start.mcfunction
