# Ch1 Step 1 Tip: Craft an Iron Pickaxe
tellraw @s [{"text":"  "},{"text":"Tip: ","color":"aqua","bold":true},{"text":"Mine stone with a wooden pickaxe, smelt iron ore in a furnace, then craft at a crafting table with 3 iron ingots and 2 sticks.","color":"gray","italic":true}]
