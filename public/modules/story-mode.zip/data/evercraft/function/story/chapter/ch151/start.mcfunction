# Chapter 151: Floor 40: Crimson Depths
data modify storage evercraft:story temp set value {chapter:"151",color:"dark_red",name:"Floor 40: Crimson Depths"}
function evercraft:story/narrator/chapter_title with storage evercraft:story temp
tellraw @s ""
data modify storage evercraft:story temp set value {speaker:"The Blade",color:"red",text:"Below floor thirty, the stone turns red. The Crimson Depths — where the castle bleeds. The walls pulse like veins, the floor is warm with something alive beneath it. This is not architecture. This is a living organism, and you are descending into its heart."}
function evercraft:story/narrator/tell with storage evercraft:story temp
scoreboard players set @s sm.step 1
scoreboard players set @s sm.quest_prog 0
scoreboard players set @s sm.quest_goal 3
scoreboard players set @s sm.quest_type 1
tellraw @s ""
tellraw @s [{"text":"  "},{"text":"\u2726 Objective: ","color":"yellow","bold":true},{"text":"Reach castle floor 35","color":"white"}]
playsound minecraft:block.note_block.chime master @s ~ ~ ~ 0.5 1.4
