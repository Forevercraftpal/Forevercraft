# Ch336 Complete — Ancient Cities

data modify storage evercraft:story temp set value {speaker:"The Wind",color:"dark_aqua",text:"The ancient city's secret is not buried treasure — it is the knowledge that some things are best left undisturbed."}
function evercraft:story/narrator/tell with storage evercraft:story temp
