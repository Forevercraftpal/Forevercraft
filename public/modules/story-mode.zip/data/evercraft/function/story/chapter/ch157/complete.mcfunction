# Ch157 Complete — Floor 80: The Furnace
data modify storage evercraft:story temp set value {speaker:"The Blade",color:"red",text:"You walked through the Furnace and emerged unmelted. Eighty floors. One hundred and thirty total. The castle tried to destroy you with its hottest fire and you laughed. The endgame approaches — only twenty more floors to the Eternal Throne."}
function evercraft:story/narrator/tell with storage evercraft:story temp
