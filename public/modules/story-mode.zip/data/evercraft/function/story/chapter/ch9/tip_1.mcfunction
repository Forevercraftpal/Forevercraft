# Ch9 Step 1 Tip: Sit at a Campfire
tellraw @s [{"text":"  "},{"text":"Tip: ","color":"aqua","bold":true},{"text":"Craft a campfire with sticks, coal, and logs, then place it down. Right-click while standing near it to sit and rest — this restores your energy over time.","color":"gray","italic":true}]
