# Ch301 Narrative 3

data modify storage evercraft:story temp set value {speaker:"The Wind",color:"dark_aqua",text:"Five lands now know your footsteps."}
function evercraft:story/narrator/tell with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"The earth remembers everyone who walks upon it, but few walk with such purpose."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
