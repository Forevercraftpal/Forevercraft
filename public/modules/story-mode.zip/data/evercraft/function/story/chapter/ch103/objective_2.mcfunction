tellraw @s [{"text":"  "},{"text":"\u2726 Objective: ","color":"yellow","bold":true},{"text":"Slay 20 enemies in berserker fury","color":"white"}]
