# Chapter 105: Nite
# @s = player starting chapter 105

data modify storage evercraft:story temp set value {chapter:"105",color:"red",name:"Nite"}
function evercraft:story/narrator/chapter_title with storage evercraft:story temp

tellraw @s ""
data modify storage evercraft:story temp set value {speaker:"The Blade",color:"red",text:"Two hands. Two blades. One will. Nite was the name whispered by those who saw twin flashes of steel in the dark and lived to tell no tales. The dual swordsman fights with both halves of their will. Take up Nite — and divide the world."}
function evercraft:story/narrator/tell with storage evercraft:story temp

scoreboard players set @s sm.step 1
scoreboard players set @s sm.quest_prog 0
scoreboard players set @s sm.quest_goal 3
scoreboard players set @s sm.quest_type 1

tellraw @s ""
tellraw @s [{"text":"  "},{"text":"\u2726 Objective: ","color":"yellow","bold":true},{"text":"Equip the Nite spirit weapon","color":"white"}]
playsound minecraft:block.note_block.chime master @s ~ ~ ~ 0.5 1.4
