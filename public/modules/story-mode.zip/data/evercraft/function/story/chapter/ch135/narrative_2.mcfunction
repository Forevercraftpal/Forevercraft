# Ch135 Narrative 2
data modify storage evercraft:story temp set value {speaker:"The Blade",color:"red",text:"Five victories secured."}
function evercraft:story/narrator/tell with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"Now refine your art — fifteen total kills across all duels."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"Every takedown should be deliberate, calculated, a brushstroke on the canvas of combat."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
