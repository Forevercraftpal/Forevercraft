# Ch364 Progress Check — Underground Rivers
# @s = player on chapter 364

execute if score @s sm.step matches 1 if score @s ach.biomes_visited matches 17.. run function evercraft:story/quest/advance
execute if score @s sm.step matches 2 if score @s ach.biomes_visited matches 18.. run function evercraft:story/quest/advance
execute if score @s sm.step matches 3 if score @s ach.biomes_visited matches 19.. run function evercraft:story/quest/advance
