# Ch330 Narrative 1 — intro covered in start.mcfunction
