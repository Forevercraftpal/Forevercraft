# Ch156 Narrative 2
data modify storage evercraft:story temp set value {speaker:"The Blade",color:"red",text:"Floor sixty-five. The abyss deepens."}
function evercraft:story/narrator/tell with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"Push to seventy — the Abyssal Halls guard their secrets behind walls of darkness and endless hordes."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"Only the relentless survive this deep."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
