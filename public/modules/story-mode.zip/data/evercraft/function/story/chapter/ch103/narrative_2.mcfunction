# Ch103 Narrative 2
data modify storage evercraft:story temp set value {speaker:"The Blade",color:"red",text:"The axe blazes in your grip — it feeds on your anger, your adrenaline, your will to destroy."}
function evercraft:story/narrator/tell with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"A berserker does not think. A berserker ACTS."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"Twenty kills with fire in your veins. Unleash the inferno!"}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp

swing @s mainhand
