tellraw @s [{"text":"  "},{"text":"\u2726 Objective: ","color":"yellow","bold":true},{"text":"Use Tempest Waltz 8 times","color":"white"}]
