# Ch103 Narrative 3
data modify storage evercraft:story temp set value {speaker:"The Blade",color:"red",text:"The ground is scorched, the air reeks of ash. Magnificent."}
function evercraft:story/narrator/tell with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"But raw destruction is only half the berserker's creed."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"Master Eruption — the Firebrand's signature ability."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"Ten eruptions that turn the battlefield into a furnace."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
