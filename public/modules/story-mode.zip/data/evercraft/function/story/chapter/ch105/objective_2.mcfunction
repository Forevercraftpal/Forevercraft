tellraw @s [{"text":"  "},{"text":"\u2726 Objective: ","color":"yellow","bold":true},{"text":"Slay 15 enemies with dual blades","color":"white"}]
