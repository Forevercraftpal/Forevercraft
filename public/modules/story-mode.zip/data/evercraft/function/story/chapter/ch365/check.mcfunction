# Ch365 Progress Check — The Warden's Domain
# @s = player on chapter 365

execute if score @s sm.step matches 1 if score @s ach.biomes_visited matches 20.. run function evercraft:story/quest/advance
execute if score @s sm.step matches 2 if score @s ach.biomes_visited matches 21.. run function evercraft:story/quest/advance
execute if score @s sm.step matches 3 if score @s ach.biomes_visited matches 22.. run function evercraft:story/quest/advance
