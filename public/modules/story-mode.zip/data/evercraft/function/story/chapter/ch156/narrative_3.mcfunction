# Ch156 Narrative 3
data modify storage evercraft:story temp set value {speaker:"The Blade",color:"red",text:"Floor seventy achieved."}
function evercraft:story/narrator/tell with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"One hundred and twenty total floors — you have explored more of this castle than any army."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"The deepest reaches are within your grasp."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
