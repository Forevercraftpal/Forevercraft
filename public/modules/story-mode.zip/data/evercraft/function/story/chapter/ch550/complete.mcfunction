# Ch550 Complete

data modify storage evercraft:story temp set value {speaker:"The Stars",color:"blue",text:"Your legend told. Not by the Stars, not by the fire — by you. Every day you play, the legend grows. And it is magnificent."}
function evercraft:story/narrator/tell with storage evercraft:story temp
