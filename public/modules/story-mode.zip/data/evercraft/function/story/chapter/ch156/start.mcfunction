# Chapter 156: Floor 70: Abyssal Halls
data modify storage evercraft:story temp set value {chapter:"156",color:"dark_red",name:"Floor 70: Abyssal Halls"}
function evercraft:story/narrator/chapter_title with storage evercraft:story temp
tellraw @s ""
data modify storage evercraft:story temp set value {speaker:"The Blade",color:"red",text:"Below sixty, the castle stops pretending to be stone. The Abyssal Halls are carved from darkness itself — walls that breathe, floors that shift mid-stride, ceilings that descend when you stop moving. Floor seventy is where warriors become legends or corpses. There is no middle ground this deep."}
function evercraft:story/narrator/tell with storage evercraft:story temp
scoreboard players set @s sm.step 1
scoreboard players set @s sm.quest_prog 0
scoreboard players set @s sm.quest_goal 3
scoreboard players set @s sm.quest_type 1
tellraw @s ""
tellraw @s [{"text":"  "},{"text":"\u2726 Objective: ","color":"yellow","bold":true},{"text":"Reach castle floor 65","color":"white"}]
playsound minecraft:block.note_block.chime master @s ~ ~ ~ 0.5 1.4
