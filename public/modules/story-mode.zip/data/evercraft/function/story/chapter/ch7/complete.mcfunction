# Ch7 Complete — Into the Unknown
# @s = player who finished chapter 7

data modify storage evercraft:story temp set value {speaker:"The Land",color:"gold",text:"You ventured where others feared to tread. The unknown rewarded your courage."}
function evercraft:story/narrator/tell with storage evercraft:story temp
