# Chapter 363: Crystal Geodes
# @s = player starting chapter 363

data modify storage evercraft:story temp set value {chapter:"363",color:"dark_aqua",name:"Crystal Geodes"}
function evercraft:story/narrator/chapter_title with storage evercraft:story temp

tellraw @s ""
data modify storage evercraft:story temp set value {speaker:"The Wind",color:"dark_aqua",text:"Amethyst hums at a frequency that resonates in your teeth. The geodes are not geological accidents — they are nodes in a crystalline network that spans the underground."}
function evercraft:story/narrator/tell with storage evercraft:story temp

scoreboard players set @s sm.step 1
scoreboard players set @s sm.quest_prog 0
scoreboard players set @s sm.quest_goal 3
scoreboard players set @s sm.quest_type 1

tellraw @s ""
tellraw @s [{"text":"  "},{"text":"\u2726 Objective: ","color":"yellow","bold":true},{"text":"Find an amethyst geode","color":"white"}]
playsound minecraft:block.note_block.chime master @s ~ ~ ~ 0.5 1.4
