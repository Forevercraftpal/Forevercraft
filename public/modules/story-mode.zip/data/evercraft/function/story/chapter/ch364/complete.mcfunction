# Ch364 Complete

data modify storage evercraft:story temp set value {speaker:"The Wind",color:"dark_aqua",text:"Underground rivers mapped. The world's hidden circulatory system documented. Water connects what stone divides."}
function evercraft:story/narrator/tell with storage evercraft:story temp
