# Ch104 Complete — Zephyr Edge
data modify storage evercraft:story temp set value {speaker:"The Blade",color:"red",text:"You move like the wind now — no, faster. The Zephyr Edge has found its rhythm in your hand. Each strike a brushstroke, each dodge a verse. The dance of death is yours to choreograph."}
function evercraft:story/narrator/tell with storage evercraft:story temp
