$function evercraft:story/chapter/ch$(chapter)/complete
