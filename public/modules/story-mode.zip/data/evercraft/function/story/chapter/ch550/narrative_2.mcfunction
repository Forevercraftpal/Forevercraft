# Ch550 Narrative 2

data modify storage evercraft:story temp set value {speaker:"The Stars",color:"blue",text:"This story has no narrator. It is yours."}
function evercraft:story/narrator/tell with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"Every block placed, every friend made, every choice that kept you going when the darkness pressed in."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
