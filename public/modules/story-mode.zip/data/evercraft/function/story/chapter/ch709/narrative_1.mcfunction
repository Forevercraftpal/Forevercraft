# Ch709 Narrative 1

data modify storage evercraft:story temp set value {speaker:"The Seasons",color:"#8BC34A",text:"Reality trembles."}
function evercraft:story/narrator/tell with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"The dimensions press close like pages in a book, and where they touch, echoes of other worlds bleed through the cracks."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
