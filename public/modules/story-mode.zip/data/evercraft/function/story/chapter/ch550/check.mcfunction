# Ch550 Progress Check — The Legend of You
# @s = player on chapter 550

execute if score @s sm.step matches 1 if score @s ec.codex_tier matches 1.. run function evercraft:story/quest/advance
execute if score @s sm.step matches 2 if score @s ec.codex_tier matches 3.. run function evercraft:story/quest/advance
execute if score @s sm.step matches 3 if score @s ec.codex_tier matches 5.. run function evercraft:story/quest/advance
