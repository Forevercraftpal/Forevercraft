# Ch104 Narrative 2
data modify storage evercraft:story temp set value {speaker:"The Blade",color:"red",text:"Feel the breeze that follows your swing?"}
function evercraft:story/narrator/tell with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"That is the Zephyr singing."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"A dancer never stands still — motion is armor, momentum is power."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"Fifteen kills while the wind carries your blade between heartbeats."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp

swing @s mainhand
