# Ch532 Narrative 3

data modify storage evercraft:story temp set value {speaker:"The Stars",color:"blue",text:"The world clocks mark the stitches in time's fabric."}
function evercraft:story/narrator/tell with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"Each tick is a reminder that repetition is not natural — it was engineered. By whom?"}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"The fragment does not say."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
