# Ch7 Step 1 Tip: Find a Structure
tellraw @s [{"text":"  "},{"text":"Tip: ","color":"aqua","bold":true},{"text":"Structures like ruins, towers, and shrines dot the landscape. Explore cave entrances, jungle canopies, and desert dunes to discover them.","color":"gray","italic":true}]
