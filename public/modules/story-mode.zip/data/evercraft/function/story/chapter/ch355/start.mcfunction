# Chapter 355: Nether Denizens
# @s = player starting chapter 355

data modify storage evercraft:story temp set value {chapter:"355",color:"dark_aqua",name:"Nether Denizens"}
function evercraft:story/narrator/chapter_title with storage evercraft:story temp

tellraw @s ""
data modify storage evercraft:story temp set value {speaker:"The Wind",color:"dark_aqua",text:"The Nether breeds creatures that should not exist — beings of fire, bone, and fury. Blazes, ghasts, piglins, hoglins — each adapted to an impossible environment."}
function evercraft:story/narrator/tell with storage evercraft:story temp

scoreboard players set @s sm.step 1
scoreboard players set @s sm.quest_prog 0
scoreboard players set @s sm.quest_goal 3
scoreboard players set @s sm.quest_type 1

tellraw @s ""
tellraw @s [{"text":"  "},{"text":"\u2726 Objective: ","color":"yellow","bold":true},{"text":"Observe blaze spawning patterns","color":"white"}]
playsound minecraft:block.note_block.chime master @s ~ ~ ~ 0.5 1.4
