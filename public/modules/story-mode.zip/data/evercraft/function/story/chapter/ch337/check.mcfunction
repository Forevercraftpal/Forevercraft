# Ch337 Progress Check
# @s = player on chapter 337
# Step 1: Learn the lore (auto-advance after narrative)
execute if score @s sm.step matches 1 run function evercraft:story/quest/advance
# Step 2: Explore related content
execute if score @s sm.step matches 2 if score @s ach.biomes_visited matches 16.. run function evercraft:story/quest/advance
# Step 3: Reflect on findings (auto-advance)
execute if score @s sm.step matches 3 run function evercraft:story/quest/advance
