# Ch157 Progress Check
execute if score @s sm.step matches 1 if score @s ic.record matches 75.. run function evercraft:story/quest/advance
execute if score @s sm.step matches 2 if score @s ic.record matches 80.. run function evercraft:story/quest/advance
execute if score @s sm.step matches 3 if score @s ec.sp_total_floors matches 130.. run function evercraft:story/quest/advance
