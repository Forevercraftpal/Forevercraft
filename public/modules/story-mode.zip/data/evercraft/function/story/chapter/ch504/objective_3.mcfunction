tellraw @s [{"text":"  "},{"text":"✦ Objective: ","color":"yellow","bold":true},{"text":"Discover 3 new biomes at night","color":"white"}]
