# Ch504 Narrative 3
data modify storage evercraft:story temp set value {speaker:"The Stars",color:"blue",text:"Three new lands touched by starlight."}
function evercraft:story/narrator/tell with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"The Wanderer's Path grows longer with every step you take — your journey is becoming part of the constellation itself. Walk on, traveler. Walk on."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
