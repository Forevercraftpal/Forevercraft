# Ch9 Step 3 Objective
tellraw @s [{"text":"  "},{"text":"\u2726 Objective: ","color":"yellow","bold":true},{"text":"Sit at a campfire","color":"white"}]
