# Ch132 Progress Check
execute if score @s sm.step matches 1 if score @s ec.sp_duel_wins matches 2.. run function evercraft:story/quest/advance
execute if score @s sm.step matches 2 if score @s ec.sp_duel_wins matches 3.. run function evercraft:story/quest/advance
execute if score @s sm.step matches 3 if score @s ec.duel_kills matches 8.. run function evercraft:story/quest/advance
