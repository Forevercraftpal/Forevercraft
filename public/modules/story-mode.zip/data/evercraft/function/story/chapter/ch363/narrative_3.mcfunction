# Ch363 Narrative 3

data modify storage evercraft:story temp set value {speaker:"The Wind",color:"dark_aqua",text:"The crystal resonance harmonizes with nearby ores."}
function evercraft:story/narrator/tell with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"Amethyst amplifies — it is a natural tuning fork for the earth's hidden frequencies."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
