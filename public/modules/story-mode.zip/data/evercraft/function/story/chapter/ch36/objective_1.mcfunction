# Ch36 Step 1 Objective
tellraw @s [{"text":"  "},{"text":"\u2726 Objective: ","color":"yellow","bold":true},{"text":"Complete a heist at the Black Market","color":"white"}]
