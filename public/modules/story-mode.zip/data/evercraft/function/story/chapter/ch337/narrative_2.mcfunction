# Ch337 Narrative 2

data modify storage evercraft:story temp set value {speaker:"The Wind",color:"dark_aqua",text:"Iron golems patrol without orders."}
function evercraft:story/narrator/tell with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"Villagers trade without currency beyond emeralds."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"The village system is elegantly simple."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
