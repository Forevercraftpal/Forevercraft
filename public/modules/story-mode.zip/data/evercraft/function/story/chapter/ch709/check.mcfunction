# Chapter 709: Rift Echo - Progress Check


# Gate: skip check entirely if chapter not yet unlocked
execute unless score @s ec.story.ch709_unlock matches 1.. run return 0
execute if score @s ec.story.ch709 matches 1 run function evercraft:story/chapter/ch709/step2
execute if score @s ec.story.ch709 matches 2 run function evercraft:story/chapter/ch709/step3
execute if score @s ec.story.ch709 matches 3 run function evercraft:story/chapter/ch709/complete
