# Ch307 Progress Check — The Mushroom Isles
# @s = player on chapter 307

execute if score @s sm.step matches 1 if score @s sm.step matches 1 run function evercraft:story/quest/advance
execute if score @s sm.step matches 2 if score @s ach.biomes_visited matches 6.. run function evercraft:story/quest/advance
execute if score @s sm.step matches 3 if score @s sm.step matches 3 run function evercraft:story/quest/advance
