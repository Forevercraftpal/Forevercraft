# Ch309 Complete — Taiga's Watch

data modify storage evercraft:story temp set value {speaker:"The Wind",color:"dark_aqua",text:"The taiga salutes you, wanderer. You have walked its paths with honor."}
function evercraft:story/narrator/tell with storage evercraft:story temp
