# Ch352 Narrative 1 — intro covered in start.mcfunction
