# Ch339 Narrative 3

data modify storage evercraft:story temp set value {speaker:"The Wind",color:"dark_aqua",text:"The trail ruins are deliberately buried."}
function evercraft:story/narrator/tell with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"Not by nature — by the builders themselves."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"They WANTED to be forgotten."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
