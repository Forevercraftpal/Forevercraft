# Ch504 Progress Check
# Step 1: Identify the Wanderer constellation
execute if score @s sm.step matches 1 if score @s ach.biomes_visited matches 1.. run function evercraft:story/quest/advance
# Step 2: Explore 5 biomes at night
execute if score @s sm.step matches 2 if score @s ach.biomes_visited matches 5.. run function evercraft:story/quest/advance
# Step 3: Discover 3 new biomes at night
execute if score @s sm.step matches 3 if score @s ach.biomes_visited matches 7.. run function evercraft:story/quest/advance
