# Ch156 Complete — Floor 70: Abyssal Halls
data modify storage evercraft:story temp set value {speaker:"The Blade",color:"red",text:"Seventy floors deep. The Abyssal Halls bow to your passage. You walk through living darkness as though it were sunlight. Warriors who reach this depth are spoken of in whispers. Deeper still, the castle holds its greatest horrors."}
function evercraft:story/narrator/tell with storage evercraft:story temp
