# Ch365 Narrative 2

data modify storage evercraft:story temp set value {speaker:"The Wind",color:"dark_aqua",text:"Sculk sensors glow and pulse — biological alarm systems that feed information to the Warden."}
function evercraft:story/narrator/tell with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"Every footstep is a betrayal."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"Every block broken is a scream."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
