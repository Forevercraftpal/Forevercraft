# Ch1 Step 1 Objective
tellraw @s [{"text":"  "},{"text":"\u2726 Objective: ","color":"yellow","bold":true},{"text":"Craft an Iron Pickaxe","color":"white"}]
