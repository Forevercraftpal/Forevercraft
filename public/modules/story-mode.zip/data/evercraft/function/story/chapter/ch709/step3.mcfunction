# Chapter 709: Rift Echo - Step 3

scoreboard players set @s ec.story.ch709 3

data modify storage evercraft:story temp set value {speaker:"The Seasons",color:"#BA68C8",text:"The cracks seal themselves, reality reasserts its boundaries, and the echoes fade to silence. But traces remain — faint scars where the worlds touched."}
function evercraft:story/narrator/tell with storage evercraft:story temp

data modify storage evercraft:story temp set value {speaker:"The Seasons",color:"#8BC34A",text:"The Rift Echo has passed. The calendar turns its page. But the dimensions remember the contact, and they will reach for each other again."}
function evercraft:story/narrator/tell with storage evercraft:story temp

function evercraft:story/chapter/ch709/complete
