# Ch36 Complete — The Heist
data modify storage evercraft:story temp set value {speaker:"The Land",color:"gold",text:"The heist is done. The shadows part for those bold enough to walk through them."}
function evercraft:story/narrator/tell with storage evercraft:story temp

# Reward: 15 coins
execute unless score @s ec.difficulty matches 3 run scoreboard players add @s ec.coins 15
execute unless score @s ec.difficulty matches 3 run tellraw @s [{"text":"  "},{"text":"+15 Forever Coins","color":"yellow"}]

# The Hollow is intrigued
data modify storage evercraft:story temp set value {text:"A thief in my domain. How delightfully desperate."}
function evercraft:story/narrator/hollow with storage evercraft:story temp
