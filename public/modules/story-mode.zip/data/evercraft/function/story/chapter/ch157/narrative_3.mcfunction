# Ch157 Narrative 3
data modify storage evercraft:story temp set value {speaker:"The Blade",color:"red",text:"Floor eighty conquered."}
function evercraft:story/narrator/tell with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"Reach one hundred and thirty total floors."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"The Furnace is behind you — ahead lies only the freezing darkness of the final depths."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
