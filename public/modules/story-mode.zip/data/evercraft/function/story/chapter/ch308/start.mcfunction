# Chapter 308: Swamp Song
# @s = player starting chapter 308

data modify storage evercraft:story temp set value {chapter:"308",color:"dark_aqua",name:"Swamp Song"}
function evercraft:story/narrator/chapter_title with storage evercraft:story temp

tellraw @s ""
data modify storage evercraft:story temp set value {speaker:"The Wind",color:"dark_aqua",text:"Murky waters and twisted trees. The swamp is not beautiful in the way of meadows — its beauty is honest, muddy, real."}
function evercraft:story/narrator/tell with storage evercraft:story temp

scoreboard players set @s sm.step 1
scoreboard players set @s sm.quest_prog 0
scoreboard players set @s sm.quest_goal 3
scoreboard players set @s sm.quest_type 1

tellraw @s ""
tellraw @s [{"text":"  "},{"text":"\u2726 Objective: ","color":"yellow","bold":true},{"text":"Visit a swamp biome","color":"white"}]
playsound minecraft:block.note_block.chime master @s ~ ~ ~ 0.5 1.4
