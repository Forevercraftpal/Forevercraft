# Chapter 9: Hearthfire — DR/CR 8→9
# @s = player starting chapter 9

data modify storage evercraft:story temp set value {chapter:"9",color:"gold",name:"Hearthfire"}
function evercraft:story/narrator/chapter_title with storage evercraft:story temp

tellraw @s ""
data modify storage evercraft:story temp set value {speaker:"The Land",color:"gold",text:"A civilization is not just steel and stone \u2014 it is the stories told around the fire."}
function evercraft:story/narrator/tell with storage evercraft:story temp

execute if score @s sm.path matches 1 run tellraw @s [{"text":"  "},{"text":"The campfire crackles. Music drifts through the night air.","color":"gray","italic":true}]
execute if score @s sm.path matches 2 run tellraw @s [{"text":"  "},{"text":"Build a home. Cook a meal. Make this land yours.","color":"gray","italic":true}]
execute if score @s sm.path matches 3 run tellraw @s [{"text":"  "},{"text":"Rest. Eat. Tomorrow, the real journey begins.","color":"gray","italic":true}]

scoreboard players set @s sm.step 1
scoreboard players set @s sm.quest_prog 0
scoreboard players set @s sm.quest_goal 1
scoreboard players set @s sm.quest_type 1

tellraw @s ""
execute if score @s sm.path matches 1 run tellraw @s [{"text":"  "},{"text":"\u2726 Objective: ","color":"yellow","bold":true},{"text":"Sit by a campfire and listen to a Campfire Story.","color":"white"}]
execute if score @s sm.path matches 2 run tellraw @s [{"text":"  "},{"text":"\u2726 Objective: ","color":"yellow","bold":true},{"text":"Cook your first meal at a campfire.","color":"white"}]
execute if score @s sm.path matches 3 run tellraw @s [{"text":"  "},{"text":"\u2726 Objective: ","color":"yellow","bold":true},{"text":"Sit by a campfire and listen to a Campfire Story.","color":"white"}]
playsound minecraft:block.note_block.chime master @s ~ ~ ~ 0.5 1.4
