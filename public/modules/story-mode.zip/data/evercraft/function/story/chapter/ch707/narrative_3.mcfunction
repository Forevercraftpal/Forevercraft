# Ch707 Narrative 3

data modify storage evercraft:story temp set value {speaker:"The Seasons",color:"#8BC34A",text:"The wheel turns and you turn with it."}
function evercraft:story/narrator/tell with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"Each season teaches patience for the next."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"This understanding — that all things are temporary and all things return — is the deepest wisdom."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
