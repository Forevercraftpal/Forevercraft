# Ch337 Narrative 3

data modify storage evercraft:story temp set value {speaker:"The Wind",color:"dark_aqua",text:"Every village adapts to its biome."}
function evercraft:story/narrator/tell with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"The builders — the villagers themselves — are the only builders still building."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
