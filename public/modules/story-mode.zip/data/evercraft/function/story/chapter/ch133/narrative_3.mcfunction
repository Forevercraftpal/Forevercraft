# Ch133 Narrative 3
data modify storage evercraft:story temp set value {speaker:"The Blade",color:"red",text:"A flawless duel victory — magnificent."}
function evercraft:story/narrator/tell with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"Now cement your tactical mastery with a fourth win."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"You have learned to read your opponents like parchment."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"Now make them fear the reader."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
