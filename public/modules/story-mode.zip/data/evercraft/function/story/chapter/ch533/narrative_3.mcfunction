# Ch533 Narrative 3

data modify storage evercraft:story temp set value {speaker:"The Stars",color:"blue",text:"The mob design document — if such a thing exists — would reveal a mind of extraordinary precision."}
function evercraft:story/narrator/tell with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"Every spawn rate, every drop table, every behavior serves the ecosystem."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
