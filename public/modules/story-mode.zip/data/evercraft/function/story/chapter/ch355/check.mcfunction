# Ch355 Progress Check — Nether Denizens
# @s = player on chapter 355

execute if score @s sm.step matches 1 if score @s ach.total_kills matches 36.. run function evercraft:story/quest/advance
execute if score @s sm.step matches 2 if score @s ach.total_kills matches 38.. run function evercraft:story/quest/advance
execute if score @s sm.step matches 3 if score @s ach.total_kills matches 40.. run function evercraft:story/quest/advance
