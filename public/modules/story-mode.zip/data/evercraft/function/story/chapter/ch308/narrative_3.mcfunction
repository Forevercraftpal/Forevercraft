# Ch308 Narrative 3

data modify storage evercraft:story temp set value {speaker:"The Wind",color:"dark_aqua",text:"A witch's hut rises from the mire."}
function evercraft:story/narrator/tell with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"Even outcasts need homes. The swamp judges no one."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
