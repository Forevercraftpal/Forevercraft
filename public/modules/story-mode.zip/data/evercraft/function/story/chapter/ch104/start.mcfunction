# Chapter 104: Zephyr Edge
# @s = player starting chapter 104

data modify storage evercraft:story temp set value {chapter:"104",color:"red",name:"Zephyr Edge"}
function evercraft:story/narrator/chapter_title with storage evercraft:story temp

tellraw @s ""
data modify storage evercraft:story temp set value {speaker:"The Blade",color:"red",text:"Speed. Grace. The wind itself made steel. The Zephyr Edge belonged to a dancer who dueled hurricanes for sport. Every swing is a step in a lethal waltz. Take up the blade — and never stop moving."}
function evercraft:story/narrator/tell with storage evercraft:story temp

scoreboard players set @s sm.step 1
scoreboard players set @s sm.quest_prog 0
scoreboard players set @s sm.quest_goal 3
scoreboard players set @s sm.quest_type 1

tellraw @s ""
tellraw @s [{"text":"  "},{"text":"\u2726 Objective: ","color":"yellow","bold":true},{"text":"Equip the Zephyr Edge spirit weapon","color":"white"}]
playsound minecraft:block.note_block.chime master @s ~ ~ ~ 0.5 1.4
