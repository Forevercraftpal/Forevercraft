# Chapter 307: The Mushroom Isles
# @s = player starting chapter 307

data modify storage evercraft:story temp set value {chapter:"307",color:"dark_aqua",name:"The Mushroom Isles"}
function evercraft:story/narrator/chapter_title with storage evercraft:story temp

tellraw @s ""
data modify storage evercraft:story temp set value {speaker:"The Wind",color:"dark_aqua",text:"Have you ever walked on a mushroom? The spore islands are dreamlike — no hostility, only strange beauty. Even the cows wear mushrooms here."}
function evercraft:story/narrator/tell with storage evercraft:story temp

scoreboard players set @s sm.step 1
scoreboard players set @s sm.quest_prog 0
scoreboard players set @s sm.quest_goal 3
scoreboard players set @s sm.quest_type 1

tellraw @s ""
tellraw @s [{"text":"  "},{"text":"\u2726 Objective: ","color":"yellow","bold":true},{"text":"Find a mushroom fields biome","color":"white"}]
playsound minecraft:block.note_block.chime master @s ~ ~ ~ 0.5 1.4
