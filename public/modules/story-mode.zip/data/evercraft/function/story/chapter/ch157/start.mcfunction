# Chapter 157: Floor 80: The Furnace
data modify storage evercraft:story temp set value {chapter:"157",color:"dark_red",name:"Floor 80: The Furnace"}
function evercraft:story/narrator/chapter_title with storage evercraft:story temp
tellraw @s ""
data modify storage evercraft:story temp set value {speaker:"The Blade",color:"red",text:"The Furnace. Floor eighty burns with an inner heat that melts lesser weapons and chars weaker armor. The castle is trying to smelt you — to reduce you to slag. Only the purest steel survives the Furnace. Are you pure enough, warrior?"}
function evercraft:story/narrator/tell with storage evercraft:story temp
scoreboard players set @s sm.step 1
scoreboard players set @s sm.quest_prog 0
scoreboard players set @s sm.quest_goal 3
scoreboard players set @s sm.quest_type 1
tellraw @s ""
tellraw @s [{"text":"  "},{"text":"\u2726 Objective: ","color":"yellow","bold":true},{"text":"Reach castle floor 75","color":"white"}]
playsound minecraft:block.note_block.chime master @s ~ ~ ~ 0.5 1.4
