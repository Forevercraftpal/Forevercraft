# Chapter 352: Overworld Hostiles
# @s = player starting chapter 352

data modify storage evercraft:story temp set value {chapter:"352",color:"dark_aqua",name:"Overworld Hostiles"}
function evercraft:story/narrator/chapter_title with storage evercraft:story temp

tellraw @s ""
data modify storage evercraft:story temp set value {speaker:"The Wind",color:"dark_aqua",text:"Zombies pursue with single-minded hunger. Skeletons patrol with mechanical precision. Creepers approach with terrifying silence. Each hostile has a doctrine."}
function evercraft:story/narrator/tell with storage evercraft:story temp

scoreboard players set @s sm.step 1
scoreboard players set @s sm.quest_prog 0
scoreboard players set @s sm.quest_goal 3
scoreboard players set @s sm.quest_type 1

tellraw @s ""
tellraw @s [{"text":"  "},{"text":"\u2726 Objective: ","color":"yellow","bold":true},{"text":"Defeat 10 zombies","color":"white"}]
playsound minecraft:block.note_block.chime master @s ~ ~ ~ 0.5 1.4
