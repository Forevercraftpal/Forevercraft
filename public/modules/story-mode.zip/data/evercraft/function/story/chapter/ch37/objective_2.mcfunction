# Ch37 Step 2 Objective
tellraw @s [{"text":"  "},{"text":"\u2726 Objective: ","color":"yellow","bold":true},{"text":"Reach Artisan Rank 45","color":"white"}]
