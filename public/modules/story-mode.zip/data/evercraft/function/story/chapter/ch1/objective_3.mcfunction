# Ch1 Step 3 Objective
tellraw @s [{"text":"  "},{"text":"\u2726 Objective: ","color":"yellow","bold":true},{"text":"Defeat your first hostile mob","color":"white"}]
