# Ch550 Narrative 3

data modify storage evercraft:story temp set value {speaker:"The Stars",color:"blue",text:"The Stars do not know this story — you are still writing it."}
function evercraft:story/narrator/tell with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"Every session adds a chapter."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"Every login is a declaration: I am not done yet."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
