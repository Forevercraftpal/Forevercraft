# Ch337 Complete — Villages

data modify storage evercraft:story temp set value {speaker:"The Wind",color:"dark_aqua",text:"Villages remind us that civilization is not grand — it is daily. Bread shared, iron traded, beds slept in. That is enough."}
function evercraft:story/narrator/tell with storage evercraft:story temp
