# Chapter 707: Starfall - Reward

tellraw @s ""
tellraw @s [{"text":"[","color":"gray"},{"text":"Chapter Complete","color":"#8BC34A","bold":true},{"text":"]","color":"gray"},{"text":" Starfall","color":"white"}]
tellraw @s [{"text":"  The cosmos shared its treasures with you.","color":"#FFD54F"}]

execute store result score @s ec.xp run scoreboard players add @s ec.xp 50

scoreboard players set @s ec.story.ch708_unlock 1
