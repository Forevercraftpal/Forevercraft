# Ch1 Step 2 Objective
tellraw @s [{"text":"  "},{"text":"\u2726 Objective: ","color":"yellow","bold":true},{"text":"Open the Codex (right-click the book in your inventory)","color":"white"}]
