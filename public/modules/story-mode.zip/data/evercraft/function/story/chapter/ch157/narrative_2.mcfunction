# Ch157 Narrative 2
data modify storage evercraft:story temp set value {speaker:"The Blade",color:"red",text:"Floor seventy-five."}
function evercraft:story/narrator/tell with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"The heat rises with every step."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"Push through to eighty — the Furnace awaits, and it will test your steel to its breaking point. Do not bend."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
