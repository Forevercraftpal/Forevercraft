# Ch7 Progress Check — Into the Unknown
# Step 1: Find a structure
execute if score @s sm.step matches 1 if score @s ach.structures_found matches 1.. run function evercraft:story/quest/advance
# Step 2: Open an activity crate
execute if score @s sm.step matches 2 if score @s ach.crates_opened matches 1.. run function evercraft:story/quest/advance
# Step 3: Identify an artifact
execute if score @s sm.step matches 3 if score @s ec.artifacts_ever matches 1.. run function evercraft:story/quest/advance
