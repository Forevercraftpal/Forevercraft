# Chapter 707: Starfall - Unlock

tellraw @s ""
tellraw @s [{"text":"[","color":"gray"},{"text":"New Chapter","color":"#8BC34A","bold":true},{"text":"]","color":"gray"},{"text":" 707: Starfall","color":"white"}]
tellraw @s [{"text":"  The stars are falling. Look up.","color":"#FFD54F"}]

scoreboard players set @s ec.story.ch707_unlock 2
