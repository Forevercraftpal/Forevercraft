# Ch365 Complete

data modify storage evercraft:story temp set value {speaker:"The Wind",color:"dark_aqua",text:"The Warden's domain survived. Not conquered — survived. The deep dark does not yield. It tolerates. And it remembers."}
function evercraft:story/narrator/tell with storage evercraft:story temp
