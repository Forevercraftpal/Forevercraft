# Ch160 Narrative 2
data modify storage evercraft:story temp set value {speaker:"The Blade",color:"red",text:"One hundred and fifty floors behind you and you still hunger for more."}
function evercraft:story/narrator/tell with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"The floors beyond the throne are uncharted — no patterns, no rules, pure chaos."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"Reach floor one hundred and ten in a single run to prove the throne was a beginning, not an end."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp

swing @s mainhand
