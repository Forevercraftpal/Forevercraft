# Ch103 Complete — Firebrand
data modify storage evercraft:story temp set value {speaker:"The Blade",color:"red",text:"Twenty corpses smolder in your wake. The Firebrand's rage is your rage now — unquenchable, unstoppable. When the berserker's fury flows through you, nothing stands. The fire remembers your name."}
function evercraft:story/narrator/tell with storage evercraft:story temp
