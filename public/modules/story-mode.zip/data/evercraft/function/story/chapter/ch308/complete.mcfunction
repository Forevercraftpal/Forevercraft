# Ch308 Complete — Swamp Song

data modify storage evercraft:story temp set value {speaker:"The Wind",color:"dark_aqua",text:"The swamp song is not melodic, but it is true. You have learned to hear it."}
function evercraft:story/narrator/tell with storage evercraft:story temp
