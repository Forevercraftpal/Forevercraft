# Ch338 Narrative 2

data modify storage evercraft:story temp set value {speaker:"The Wind",color:"dark_aqua",text:"Patrol routes cross the overworld in patterns."}
function evercraft:story/narrator/tell with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"The pillagers are not random — they are organized scouts for a larger force."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
