# Chapter 707: Starfall - Step 2

scoreboard players set @s ec.story.ch707 2

data modify storage evercraft:story temp set value {speaker:"The Seasons",color:"#FFD54F",text:"Where the stars land, strange materials appear. Star-iron, void-glass, celestial dust — treasures that exist nowhere else in the world."}
function evercraft:story/narrator/tell with storage evercraft:story temp

data modify storage evercraft:story temp set value {speaker:"The Seasons",color:"#FFD54F",text:"The wise search for impact sites at first light. The stars are generous, but only to those who seek."}
function evercraft:story/narrator/tell with storage evercraft:story temp
