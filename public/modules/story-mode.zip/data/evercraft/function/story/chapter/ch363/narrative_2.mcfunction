# Ch363 Narrative 2

data modify storage evercraft:story temp set value {speaker:"The Wind",color:"dark_aqua",text:"Budding amethyst grows in stages — small, medium, large, cluster. Patience made crystal."}
function evercraft:story/narrator/tell with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"Each stage takes longer than the last. The geode teaches time."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
