# Ch36 Narrative — Player collected heist reward
data modify storage evercraft:story temp set value {speaker:"The Land",color:"gold",text:"Reward in hand. Resources secured."}
function evercraft:story/narrator/tell with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"Every advantage matters now — the war with The Hollow is not won by purity alone."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"It is won by those willing to use every tool at their disposal."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
data modify storage evercraft:notify stage.c set value [{text:"  "},{text:"The light casts shadows. The shadows hide treasures. And you walk in both.",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 70
function evercraft:util/notify/emit
