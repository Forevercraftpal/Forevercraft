# Ch133 Narrative 2
data modify storage evercraft:story temp set value {speaker:"The Blade",color:"red",text:"Now prove your eyes are sharper than your blade."}
function evercraft:story/narrator/tell with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"Win a duel without taking a single hit."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"Read every attack before it comes."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"Be the ghost they cannot touch."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
