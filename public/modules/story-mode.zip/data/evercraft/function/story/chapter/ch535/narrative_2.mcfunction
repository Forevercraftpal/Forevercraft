# Ch535 Narrative 2

data modify storage evercraft:story temp set value {speaker:"The Stars",color:"blue",text:"Diamond at the bottom. Coal at the top."}
function evercraft:story/narrator/tell with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"The ore distribution is not geological — it is pedagogical."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"The deeper you go, the greater the reward — and the greater the danger."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
