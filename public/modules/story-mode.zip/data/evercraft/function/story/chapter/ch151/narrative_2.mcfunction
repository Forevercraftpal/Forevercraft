# Ch151 Narrative 2
data modify storage evercraft:story temp set value {speaker:"The Blade",color:"red",text:"Floor thirty-five."}
function evercraft:story/narrator/tell with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"The crimson walls pulse faster as you descend."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"Push to floor forty — the heart of the Crimson Depths, where the castle's living blood flows thickest."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
