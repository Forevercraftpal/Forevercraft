# Chapter 331: The Stronghold Secret
# @s = player starting chapter 331

data modify storage evercraft:story temp set value {chapter:"331",color:"dark_aqua",name:"The Stronghold Secret"}
function evercraft:story/narrator/chapter_title with storage evercraft:story temp

tellraw @s ""
data modify storage evercraft:story temp set value {speaker:"The Wind",color:"dark_aqua",text:"Beneath the surface, where no light has ever reached, the strongholds wait. End portals do not grow naturally. Someone BUILT a way out."}
function evercraft:story/narrator/tell with storage evercraft:story temp

scoreboard players set @s sm.step 1
scoreboard players set @s sm.quest_prog 0
scoreboard players set @s sm.quest_goal 3
scoreboard players set @s sm.quest_type 1

tellraw @s ""
tellraw @s [{"text":"  "},{"text":"\u2726 Objective: ","color":"yellow","bold":true},{"text":"Locate a stronghold","color":"white"}]
playsound minecraft:block.note_block.chime master @s ~ ~ ~ 0.5 1.4
