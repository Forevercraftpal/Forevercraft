# Ch37 Step 1 Objective
tellraw @s [{"text":"  "},{"text":"\u2726 Objective: ","color":"yellow","bold":true},{"text":"Win a duel or get married","color":"white"}]
