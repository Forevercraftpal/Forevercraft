# Ch38 Step 2 Tip: Evolve Codex to Phoenix
tellraw @s [{"text":"  "},{"text":"Tip: ","color":"aqua","bold":true},{"text":"The Phoenix evolution requires fire-related bestiary entries — hunt blazes, magma cubes, and fire spirits.","color":"gray","italic":true}]
