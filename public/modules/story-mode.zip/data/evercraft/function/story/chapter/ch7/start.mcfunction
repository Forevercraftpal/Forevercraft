# Chapter 7: Into the Unknown — DR/CR 6→7
# @s = player starting chapter 7

data modify storage evercraft:story temp set value {chapter:"7",color:"gold",name:"Into the Unknown"}
function evercraft:story/narrator/chapter_title with storage evercraft:story temp

tellraw @s ""
data modify storage evercraft:story temp set value {speaker:"The Land",color:"gold",text:"Behind every sealed door lies a dream someone else left behind."}
function evercraft:story/narrator/tell with storage evercraft:story temp

execute if score @s sm.path matches 1 run tellraw @s [{"text":"  "},{"text":"Structures and dream-gated ruins beckon from the horizon.","color":"gray","italic":true}]
execute if score @s sm.path matches 2 run tellraw @s [{"text":"  "},{"text":"Fishing crates and harvest nodes appear along the waterways and fields.","color":"gray","italic":true}]
execute if score @s sm.path matches 3 run tellraw @s [{"text":"  "},{"text":"The unknown hides both treasures to claim and resources to gather.","color":"gray","italic":true}]

scoreboard players set @s sm.step 1
scoreboard players set @s sm.quest_prog 0
scoreboard players set @s sm.quest_goal 1
scoreboard players set @s sm.quest_type 1

tellraw @s ""
execute if score @s sm.path matches 1 run tellraw @s [{"text":"  "},{"text":"\u2726 Objective: ","color":"yellow","bold":true},{"text":"Discover and loot a dream-gated structure.","color":"white"}]
execute if score @s sm.path matches 2 run tellraw @s [{"text":"  "},{"text":"\u2726 Objective: ","color":"yellow","bold":true},{"text":"Catch a fish or harvest a crop in Forevercraft.","color":"white"}]
execute if score @s sm.path matches 3 run tellraw @s [{"text":"  "},{"text":"\u2726 Objective: ","color":"yellow","bold":true},{"text":"Discover and loot a dream-gated structure.","color":"white"}]
playsound minecraft:block.note_block.chime master @s ~ ~ ~ 0.5 1.4
