# Ch105 Narrative 2
data modify storage evercraft:story temp set value {speaker:"The Blade",color:"red",text:"You hold Nite and already the air trembles."}
function evercraft:story/narrator/tell with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"Twin blades demand twin resolve — one for offense, one for defense, both for annihilation."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"Fifteen kills with both edges singing."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"Show me the duelist within."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp

swing @s mainhand
