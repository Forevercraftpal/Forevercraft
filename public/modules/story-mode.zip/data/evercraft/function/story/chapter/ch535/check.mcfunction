# Ch535 Progress Check — Fragment: The Ores
# @s = player on chapter 535

execute if score @s sm.step matches 1 if score @s ach.lore_found matches 10.. run function evercraft:story/quest/advance
execute if score @s sm.step matches 2 if score @s ach.lore_found matches 12.. run function evercraft:story/quest/advance
execute if score @s sm.step matches 3 if score @s ec.inscr_count matches 15.. run function evercraft:story/quest/advance
