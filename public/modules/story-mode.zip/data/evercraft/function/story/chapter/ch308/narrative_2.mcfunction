# Ch308 Narrative 2

data modify storage evercraft:story temp set value {speaker:"The Wind",color:"dark_aqua",text:"Slime bounces through the darkness."}
function evercraft:story/narrator/tell with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"Frogs croak ancient songs."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"The swamp is alive in ways other biomes merely aspire to."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
