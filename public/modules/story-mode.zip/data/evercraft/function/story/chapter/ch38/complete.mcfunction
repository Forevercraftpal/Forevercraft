# Ch38 Complete — The Living World
data modify storage evercraft:story temp set value {speaker:"The Land",color:"gold",text:"The world breathes with life. You have learned its rhythms."}
function evercraft:story/narrator/tell with storage evercraft:story temp

# Reward: 20 coins + extra for this milestone chapter
execute unless score @s ec.difficulty matches 3 run scoreboard players add @s ec.coins 20
execute unless score @s ec.difficulty matches 3 run tellraw @s [{"text":"  "},{"text":"+20 Forever Coins","color":"yellow"}]

# Artisan Rank 50 celebration for CR path
execute if score @s sm.path matches 2 if score @s ec.cf_rank matches 50.. run tellraw @s [{"text":"  "},{"text":"Grand Artisan achieved! Mythical forging unlocked.","color":"light_purple","bold":true}]

# The Hollow whispers about evolution
data modify storage evercraft:story temp set value {text:"You catalog the living. But everything living... eventually dies."}
function evercraft:story/narrator/hollow with storage evercraft:story temp
