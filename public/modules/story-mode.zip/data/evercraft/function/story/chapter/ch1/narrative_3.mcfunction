# Ch1 Narrative — Player just opened the Codex for the first time
data modify storage evercraft:story temp set value {speaker:"The Land",color:"gold",text:"You opened it. Good."}
function evercraft:story/narrator/tell with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"The Codex is not just a book — it is the land's memory of you."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
data modify storage evercraft:notify stage.c set value [{text:"  "},{text:"Everything you do, it remembers.",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 70
function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"  "},{text:"Every mob slain, every meal cooked, every friend made.",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 70
function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"  "},{text:"The higher your rates grow, the richer the world becomes.",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 70
function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"  "},{text:"Better loot. Deeper mysteries. Stronger connections.",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 70
function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"  "},{text:"But first — survive.",color:"white",italic:true}]
scoreboard players set #ndur ec.temp 70
function evercraft:util/notify/emit
