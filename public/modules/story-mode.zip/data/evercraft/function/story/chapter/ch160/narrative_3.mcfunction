# Ch160 Narrative 3
data modify storage evercraft:story temp set value {speaker:"The Blade",color:"red",text:"Floor one hundred and ten in a single descent."}
function evercraft:story/narrator/tell with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"Beyond the Eternal Throne."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"Now reach two hundred total floors — the ultimate milestone."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"When you stand at two hundred, you will have conquered more of the infinite than any warrior in history."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
