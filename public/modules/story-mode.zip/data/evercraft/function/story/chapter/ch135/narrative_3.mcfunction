# Ch135 Narrative 3
data modify storage evercraft:story temp set value {speaker:"The Blade",color:"red",text:"Fifteen strikes, each one a verse in your battle poem."}
function evercraft:story/narrator/tell with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"One more duel victory to prove your art of war has become second nature."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"The sixth win cements your legacy."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
