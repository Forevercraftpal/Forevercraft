# Chapter 134: Steel Resolve
# @s = player starting chapter 134

data modify storage evercraft:story temp set value {chapter:"134",color:"red",name:"Steel Resolve"}
function evercraft:story/narrator/chapter_title with storage evercraft:story temp

tellraw @s ""
data modify storage evercraft:story temp set value {speaker:"The Blade",color:"red",text:"Any warrior can win when they are fresh and full of life. But a true champion wins when broken, bleeding, clinging to the edge of defeat. Steel resolve is forged in desperation — win a duel when death is breathing down your neck. Show me you can pull victory from the jaws of oblivion."}
function evercraft:story/narrator/tell with storage evercraft:story temp

scoreboard players set @s sm.step 1
scoreboard players set @s sm.quest_prog 0
scoreboard players set @s sm.quest_goal 3
scoreboard players set @s sm.quest_type 1

tellraw @s ""
tellraw @s [{"text":"  "},{"text":"\u2726 Objective: ","color":"yellow","bold":true},{"text":"Enter a duel","color":"white"}]
playsound minecraft:block.note_block.chime master @s ~ ~ ~ 0.5 1.4
