# Ch36 Progress Check — The Heist
# Step 1: Complete a heist
execute if score @s sm.step matches 1 if score @s ec.heist_wins matches 1.. run function evercraft:story/quest/advance
# Step 2: Complete 3 heists
execute if score @s sm.step matches 2 if score @s ec.heist_wins matches 3.. run function evercraft:story/quest/advance
# Step 3: Earn 2000 coins
execute if score @s sm.step matches 3 if score @s ec.coins matches 2000.. run function evercraft:story/quest/advance
