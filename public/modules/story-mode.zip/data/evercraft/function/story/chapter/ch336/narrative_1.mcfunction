# Ch336 Narrative 1 — intro covered in start.mcfunction
