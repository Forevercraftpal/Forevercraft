# Ch103 Progress Check
# @s = player on chapter 103

execute if score @s sm.step matches 1 if score @s ec.sp_weapon matches 3 run function evercraft:story/quest/advance
execute if score @s sm.step matches 2 if score @s ec.sp_kills matches 20.. run function evercraft:story/quest/advance
execute if score @s sm.step matches 3 if score @s ec.sp_ability1_uses matches 10.. run function evercraft:story/quest/advance
