# Ch37 Step 3 Objective
tellraw @s [{"text":"  "},{"text":"\u2726 Objective: ","color":"yellow","bold":true},{"text":"Defeat 200 mobs","color":"white"}]
