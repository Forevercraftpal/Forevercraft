# Ch158 Narrative 2
data modify storage evercraft:story temp set value {speaker:"The Blade",color:"red",text:"Floor eighty-five."}
function evercraft:story/narrator/tell with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"Reality warps at this depth."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"Push to ninety — the Edge where the castle's foundations meet absolute nothing."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"Only those who embrace oblivion can pass through it."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
