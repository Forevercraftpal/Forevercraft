# Chapter 31: Morality's Edge — DR/CR 30→31
data modify storage evercraft:story temp set value {chapter:"31",color:"light_purple",name:"Morality's Edge"}
function evercraft:story/narrator/chapter_title with storage evercraft:story temp

tellraw @s ""
data modify storage evercraft:story temp set value {speaker:"The Land",color:"gold",text:"Every action casts a shadow. What shadow do you cast?"}
function evercraft:story/narrator/tell with storage evercraft:story temp

execute if score @s sm.path matches 1 run tellraw @s [{"text":"  "},{"text":"The Reaper watches. Infamy or renown — your deeds are measured.","color":"gray","italic":true}]
execute if score @s sm.path matches 2 run tellraw @s [{"text":"  "},{"text":"Trade reputation shapes how merchants see you. Choose wisely.","color":"gray","italic":true}]
execute if score @s sm.path matches 3 run tellraw @s [{"text":"  "},{"text":"Every choice echoes. The Reaper and the merchant both keep ledgers.","color":"gray","italic":true}]

scoreboard players set @s sm.step 1
scoreboard players set @s sm.quest_prog 0
scoreboard players set @s sm.quest_goal 3
scoreboard players set @s sm.quest_type 1

tellraw @s ""
execute if score @s sm.path matches 1 run tellraw @s [{"text":"  "},{"text":"✦ Objective: ","color":"yellow","bold":true},{"text":"Gain Renown or Infamy through the Reaper system.","color":"white"}]
execute if score @s sm.path matches 2 run tellraw @s [{"text":"  "},{"text":"✦ Objective: ","color":"yellow","bold":true},{"text":"Reach Artisan Rank 35 through crafting mastery.","color":"white"}]
execute if score @s sm.path matches 3 run tellraw @s [{"text":"  "},{"text":"✦ Objective: ","color":"yellow","bold":true},{"text":"Make a Reaper choice (Renown or Infamy).","color":"white"}]
playsound minecraft:block.note_block.chime master @s ~ ~ ~ 0.5 1.4
