# Chapter 339: Trail Ruins
# @s = player starting chapter 339

data modify storage evercraft:story temp set value {chapter:"339",color:"dark_aqua",name:"Trail Ruins"}
function evercraft:story/narrator/chapter_title with storage evercraft:story temp

tellraw @s ""
data modify storage evercraft:story temp set value {speaker:"The Wind",color:"dark_aqua",text:"Buried beneath the sand and gravel, barely visible. The trail ruins are the oldest settlements — from before villages, before temples, before everything."}
function evercraft:story/narrator/tell with storage evercraft:story temp

scoreboard players set @s sm.step 1
scoreboard players set @s sm.quest_prog 0
scoreboard players set @s sm.quest_goal 3
scoreboard players set @s sm.quest_type 1

tellraw @s ""
tellraw @s [{"text":"  "},{"text":"\u2726 Objective: ","color":"yellow","bold":true},{"text":"Find trail ruins","color":"white"}]
playsound minecraft:block.note_block.chime master @s ~ ~ ~ 0.5 1.4
