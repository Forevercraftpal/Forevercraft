# Chapter 336: Ancient Cities
# @s = player starting chapter 336

data modify storage evercraft:story temp set value {chapter:"336",color:"dark_aqua",name:"Ancient Cities"}
function evercraft:story/narrator/chapter_title with storage evercraft:story temp

tellraw @s ""
data modify storage evercraft:story temp set value {speaker:"The Wind",color:"dark_aqua",text:"Deep dark. Sculk. The Warden. The ancient cities are the oldest structures — built before all others. By whom? By whatever the Warden was guarding."}
function evercraft:story/narrator/tell with storage evercraft:story temp

scoreboard players set @s sm.step 1
scoreboard players set @s sm.quest_prog 0
scoreboard players set @s sm.quest_goal 3
scoreboard players set @s sm.quest_type 1

tellraw @s ""
tellraw @s [{"text":"  "},{"text":"\u2726 Objective: ","color":"yellow","bold":true},{"text":"Reach an ancient city","color":"white"}]
playsound minecraft:block.note_block.chime master @s ~ ~ ~ 0.5 1.4
