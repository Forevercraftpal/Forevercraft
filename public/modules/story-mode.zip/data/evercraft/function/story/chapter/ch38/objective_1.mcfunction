# Ch38 Step 1 Objective
tellraw @s [{"text":"  "},{"text":"\u2726 Objective: ","color":"yellow","bold":true},{"text":"Accumulate 500 spirit weapon kills or reach Artisan Rank 50","color":"white"}]
