# Ch504 Complete — The Wanderer's Path
data modify storage evercraft:story temp set value {speaker:"The Stars",color:"blue",text:"The Wanderer nods from across the ages. Your steps have followed the oldest road — the one that has no end, only horizons. Walk far. Walk forever. The stars will mark your path."}
function evercraft:story/narrator/tell with storage evercraft:story temp
