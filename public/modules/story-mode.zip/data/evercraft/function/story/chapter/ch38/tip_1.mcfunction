# Ch38 Step 1 Tip: Discover 30 bestiary entries
tellraw @s [{"text":"  "},{"text":"Tip: ","color":"aqua","bold":true},{"text":"Explore every biome thoroughly — rare mobs spawn in specific conditions like rain, night, or full moon.","color":"gray","italic":true}]
