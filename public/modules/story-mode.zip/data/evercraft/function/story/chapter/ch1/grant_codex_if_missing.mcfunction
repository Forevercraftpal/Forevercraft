# Grant Forevercraft Codex if player doesn't have one
# Falls back to dropping at feet if inventory is full
# @s = player who just crafted iron pickaxe

# Check if they already have any codex variant
tag @s remove ec.has_any_codex
execute if items entity @s container.* book[custom_data~{artifact_codex:true}] run tag @s add ec.has_any_codex
execute if items entity @s weapon.offhand book[custom_data~{artifact_codex:true}] run tag @s add ec.has_any_codex
execute if items entity @s enderchest.* book[custom_data~{artifact_codex:true}] run tag @s add ec.has_any_codex
execute if items entity @s container.* book[custom_data~{eternal_codex:true}] run tag @s add ec.has_any_codex
execute if items entity @s container.* book[custom_data~{phoenix_codex:true}] run tag @s add ec.has_any_codex

# If they already have one, skip
execute if entity @s[tag=ec.has_any_codex] run tag @s remove ec.has_any_codex
execute if entity @s[tag=ec.has_any_codex] run return 0
tag @s remove ec.has_any_codex

# Try to give to inventory first
# Inv-full guard: drop at the player's feet rather than void on a full inventory.
execute store result score #inv_full ec.var run function evercraft:util/check_inv_full
execute if score #inv_full ec.var matches 0 run loot give @s loot evercraft:items/artifact_codex_item
execute if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:items/artifact_codex_item

# Check if it actually landed in inventory (it may not if full)
tag @s remove ec.codex_check
execute if items entity @s container.* book[custom_data~{artifact_codex:true}] run tag @s add ec.codex_check

# If NOT in inventory, drop at feet
execute if entity @s[tag=!ec.codex_check] at @s run loot spawn ~ ~ ~ loot evercraft:items/artifact_codex_item
execute if entity @s[tag=!ec.codex_check] run tellraw @s [{"text":"  "},{"text":"Your inventory was full! The Codex dropped at your feet.","color":"red","italic":true}]

tag @s remove ec.codex_check

# Celebration
playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 1 1.2
