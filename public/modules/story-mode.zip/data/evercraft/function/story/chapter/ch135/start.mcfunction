# Chapter 135: The Art of War
data modify storage evercraft:story temp set value {chapter:"135",color:"red",name:"The Art of War"}
function evercraft:story/narrator/chapter_title with storage evercraft:story temp
tellraw @s ""
data modify storage evercraft:story temp set value {speaker:"The Blade",color:"red",text:"Five duels won through different means — power, patience, desperation. You are developing a style, a philosophy of combat. The art of war is not about winning one way. It is about having a hundred ways and choosing the right one for each opponent."}
function evercraft:story/narrator/tell with storage evercraft:story temp
scoreboard players set @s sm.step 1
scoreboard players set @s sm.quest_prog 0
scoreboard players set @s sm.quest_goal 3
scoreboard players set @s sm.quest_type 1
tellraw @s ""
tellraw @s [{"text":"  "},{"text":"\u2726 Objective: ","color":"yellow","bold":true},{"text":"Win 5 duels total","color":"white"}]
playsound minecraft:block.note_block.chime master @s ~ ~ ~ 0.5 1.4
