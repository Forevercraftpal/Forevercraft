# Ch31 Step 2 Tip: Complete 10 villager trades
tellraw @s [{"text":"  "},{"text":"Tip: ","color":"aqua","bold":true},{"text":"Different villager professions offer unique trades — spread your trades across multiple villagers for variety.","color":"gray","italic":true}]
