# Ch533 Progress Check — Fragment: The Mobs
# @s = player on chapter 533

execute if score @s sm.step matches 1 if score @s ec.inscr_count matches 8.. run function evercraft:story/quest/advance
execute if score @s sm.step matches 2 if score @s ach.lore_found matches 8.. run function evercraft:story/quest/advance
execute if score @s sm.step matches 3 if score @s ach.lore_found matches 10.. run function evercraft:story/quest/advance
