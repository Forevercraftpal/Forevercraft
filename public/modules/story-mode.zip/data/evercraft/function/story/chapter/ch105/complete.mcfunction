# Ch105 Complete — Nite
data modify storage evercraft:story temp set value {speaker:"The Blade",color:"red",text:"Left and right, high and low — you cut through them like a storm of steel. Nite recognizes you as its twin-wielder. When both blades sing together, nothing in this world or the next can stand against you."}
function evercraft:story/narrator/tell with storage evercraft:story temp
