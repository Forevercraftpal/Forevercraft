# Ch336 Narrative 3

data modify storage evercraft:story temp set value {speaker:"The Wind",color:"dark_aqua",text:"The soul lanterns burn with memories."}
function evercraft:story/narrator/tell with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"The ancient cities are not ruins — they are shrines."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"Shrines to silence itself."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
