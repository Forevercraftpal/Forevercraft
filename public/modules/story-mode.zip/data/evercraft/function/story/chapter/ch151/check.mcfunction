# Ch151 Progress Check
execute if score @s sm.step matches 1 if score @s ic.record matches 35.. run function evercraft:story/quest/advance
execute if score @s sm.step matches 2 if score @s ic.record matches 40.. run function evercraft:story/quest/advance
execute if score @s sm.step matches 3 if score @s ec.sp_total_floors matches 65.. run function evercraft:story/quest/advance
