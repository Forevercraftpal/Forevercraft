# Ch133 Complete — Reading the Opponent
data modify storage evercraft:story temp set value {speaker:"The Blade",color:"red",text:"Not a scratch. You read them like an open book — every twitch, every breath betrayed their intent. This is the difference between a fighter and a duelist. You have eyes that see through steel."}
function evercraft:story/narrator/tell with storage evercraft:story temp
