# Ch364 Narrative 3

data modify storage evercraft:story temp set value {speaker:"The Wind",color:"dark_aqua",text:"Swimming through a flooded cave requires trust — trust that air waits on the other side."}
function evercraft:story/narrator/tell with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"The underground river rewards faith in forward motion."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
