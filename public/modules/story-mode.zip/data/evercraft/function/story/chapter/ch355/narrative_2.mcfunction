# Ch355 Narrative 2

data modify storage evercraft:story temp set value {speaker:"The Wind",color:"dark_aqua",text:"Piglins barter."}
function evercraft:story/narrator/tell with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"They are not mindless — they have economy, hierarchy, culture."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"Understanding them begins with respecting their intelligence."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
