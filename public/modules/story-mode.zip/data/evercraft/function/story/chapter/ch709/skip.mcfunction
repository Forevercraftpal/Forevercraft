# Chapter 709: Rift Echo - Skip
# Wedge-fix (2026-05-26 council): runs full on_complete bookkeeping (chapters_done,
# branch check, journal entry, news counter) so skip doesn't leave the quest engine
# out of sync. Reward dispatch is per-policy:
#   - First run: 50% coins + xp via on_skip_partial (no crate, no bonus pool)
#   - Replay (ec.story.ch709_replay == 1): full grant via rewards/grant
# Two sentinels drive this:
#   - sm.skipping  : tells on_complete to NOT call rewards/grant (skip dispatches its own)
#   - sm.completing: tells ch709/complete to return-early (so its reward.mcfunction tail doesn't fire)

# Idempotency: don't double-skip if already at completion state
execute if score @s ec.story.ch709 matches 4 run return 0

# Mark chapter complete + unlock next chapter gate
scoreboard players set @s ec.story.ch709 4
scoreboard players set @s ec.story.ch710_unlock 1

# Player-facing skip notification (lore-validated text, do not change)
tellraw @s [{"text":"[","color":"gray"},{"text":"Skipped","color":"yellow"},{"text":"]","color":"gray"},{"text":" Chapter 709: Rift Echo","color":"white"}]

# Bookkeeping via on_complete, with sm.skipping suppressing the full reward grant
# and sm.completing suppressing the chapter-complete tail (flat XP + next-unlock).
tag @s add sm.skipping
tag @s add sm.completing
scoreboard players set @s sm.step 4
function evercraft:story/chapter/on_complete
tag @s remove sm.completing

# Reward dispatch: full grant on replay, partial otherwise
execute if score @s ec.story.ch709_replay matches 1 run function evercraft:story/rewards/grant
execute unless score @s ec.story.ch709_replay matches 1 run function evercraft:story/chapter/on_skip_partial

tag @s remove sm.skipping
