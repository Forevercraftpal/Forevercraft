# Ch1 Step 2 Tip: Open the Codex
tellraw @s [{"text":"  "},{"text":"Tip: ","color":"aqua","bold":true},{"text":"Hold the Codex book in your hand and right-click to open it.","color":"gray","italic":true}]
