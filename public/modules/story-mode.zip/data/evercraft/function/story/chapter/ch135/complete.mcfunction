# Ch135 Complete — The Art of War
data modify storage evercraft:story temp set value {speaker:"The Blade",color:"red",text:"Six victories, fifteen kills. You fight like a poet writes — with intention, with rhythm, with devastating purpose. The art of war is not destruction. It is expression. And your expression is terrifying."}
function evercraft:story/narrator/tell with storage evercraft:story temp
