# Ch134 Narrative 3
data modify storage evercraft:story temp set value {speaker:"The Blade",color:"red",text:"A clutch victory earned."}
function evercraft:story/narrator/tell with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"Now reach five total duel wins to cement your reputation as a warrior who never, ever gives up. Steel does not break. Steel does not bend. Steel endures."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
