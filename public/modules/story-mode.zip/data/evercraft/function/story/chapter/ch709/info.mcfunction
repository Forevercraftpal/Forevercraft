# Chapter 709: Rift Echo - Info

tellraw @s ""
tellraw @s [{"text":"=== ","color":"gray"},{"text":"Chapter 709","color":"#8BC34A","bold":true},{"text":" ===","color":"gray"}]
tellraw @s [{"text":"Rift Echo","color":"white","bold":true}]
tellraw @s [{"text":"Branch: ","color":"gray"},{"text":"Seasonal Chronicles","color":"#8BC34A"}]
tellraw @s [{"text":"Type: ","color":"gray"},{"text":"Event Story (Auto-advance)","color":"yellow"}]
tellraw @s ""
tellraw @s [{"text":"Dimensions press together and reality echoes. Peer through the cracks between worlds during this strange event.","color":"#BA68C8"}]
