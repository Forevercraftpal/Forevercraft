# Ch307 Narrative 2

data modify storage evercraft:story temp set value {speaker:"The Wind",color:"dark_aqua",text:"Mycelium carpets the ground in purple networks."}
function evercraft:story/narrator/tell with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"Each strand connects to every other."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"The island is one organism."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
