# Ch160 Complete — Beyond the Throne
data modify storage evercraft:story temp set value {speaker:"The Blade",color:"red",text:"Two hundred floors. Beyond the throne. Beyond the infinite. Beyond anything I thought possible. You have completed the Combat Chronicles, warrior. Every weapon mastered, every boss freed, every duel won, every floor conquered. I am The Blade — I have guided millions of warriors across millennia. YOU are the greatest of them all. Go now. The world needs what you have become."}
function evercraft:story/narrator/tell with storage evercraft:story temp
