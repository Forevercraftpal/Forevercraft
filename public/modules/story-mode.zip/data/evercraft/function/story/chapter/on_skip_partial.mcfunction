# Partial reward grant for first-time skip (50% of calc_tier values).
# Full reward (replay) goes through evercraft:story/rewards/grant instead.
# @s = player who just skipped a Seasonal Chronicles chapter (ch701-730).
#
# Mirrors evercraft:story/rewards/grant but halves #rw_coins and #rw_xp after
# calc_tier, and skips bonus-pool grants (crates, bonus items) — those are
# the "earned" portion that should only fire on a real completion.

# Pioneer skip path: same skip-everything policy as grant.mcfunction
execute if score @s ec.difficulty matches 3 run return 0

# Calculate canonical reward tier (uses sm.chapter + sm.branch, same as completion)
function evercraft:story/rewards/calc_tier

# Polish (2026-05-28): skip-path shouldn't get the "milestone bonus!" tellraw that
# calc_tier sets for ch10/20/30/40/50. The milestone is an earned-only ceremony.
scoreboard players set #rw_milestone ec.temp 0

# Halve coins + XP (integer division — ties go down, which is intended for a partial)
scoreboard players operation #rw_coins ec.temp /= #2 ec.const
scoreboard players operation #rw_xp ec.temp /= #2 ec.const

# ec.xp parity for first-time skip (Audit #2 2026-05-28 W5.3 F5)
# The normal-complete path adds +50 ec.xp via chN/reward.mcfunction; the skip path
# bypasses that file. Grant half-rate (+25 ec.xp) so a player who skips all 28 Seasonal
# chapters doesn't accumulate ~1475 ec.xp debt vs the normal-complete path.
execute if score @s sm.branch matches 7 run scoreboard players add @s ec.xp 25

# Reward header — distinct from full-reward header so player knows it's partial
tellraw @s [{"text":"  "},{"text":"─── Partial Reward (Skipped) ───","color":"dark_gray"}]

# Grant base rewards at half rate (no crate, no bonus pool — those are earned-only)
function evercraft:story/rewards/give_coins
function evercraft:story/rewards/give_xp

# Explainer footer — sets the expectation for replay-with-full-reward
tellraw @s [{"text":"  "},{"text":"Complete this chapter normally to earn the full reward on a future replay.","color":"gray","italic":true}]
