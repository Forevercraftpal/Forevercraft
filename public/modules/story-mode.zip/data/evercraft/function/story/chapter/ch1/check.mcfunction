# Ch1 Progress Check — First Light
# @s = player on chapter 1
# Step 1: Craft an Iron Pickaxe (also grants Codex if missing)
# Step 2: Open the Codex (hook in codex/hub/open.mcfunction for instant detection)
# Step 3: Kill your first mob

# Step 1: Has iron pickaxe (or better) in inventory
# Also grant the Codex if they don't have one yet (covers reset/edge cases)
execute if score @s sm.step matches 1 if items entity @s container.* iron_pickaxe run function evercraft:story/chapter/ch1/grant_codex_if_missing
execute if score @s sm.step matches 1 if items entity @s container.* iron_pickaxe run function evercraft:story/quest/advance
execute if score @s sm.step matches 1 if items entity @s container.* diamond_pickaxe run function evercraft:story/chapter/ch1/grant_codex_if_missing
execute if score @s sm.step matches 1 if items entity @s container.* diamond_pickaxe run function evercraft:story/quest/advance
execute if score @s sm.step matches 1 if items entity @s container.* netherite_pickaxe run function evercraft:story/chapter/ch1/grant_codex_if_missing
execute if score @s sm.step matches 1 if items entity @s container.* netherite_pickaxe run function evercraft:story/quest/advance

# Step 2: Codex opened — detected ONLY by hook in codex/hub/open.mcfunction
# No fallback here — player must actually open the Codex after receiving it
# The hook fires instantly when they right-click the book

# Step 3: Kill first mob
execute if score @s sm.step matches 3 if score @s ach.total_kills matches 1.. run function evercraft:story/quest/advance
