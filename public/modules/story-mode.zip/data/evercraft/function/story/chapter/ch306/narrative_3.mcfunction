# Ch306 Narrative 3

data modify storage evercraft:story temp set value {speaker:"The Wind",color:"dark_aqua",text:"The jungle temple stands silent among the roots. Who built it?"}
function evercraft:story/narrator/tell with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"The jungle knows, but it keeps its secrets well."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
