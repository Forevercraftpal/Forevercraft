# Ch709 Objective 2
tellraw @s [{"text":"  "},{"text":"\u2726 Objective: ","color":"yellow","bold":true},{"text":"Witness other worlds bleed through the boundary","color":"white"}]
