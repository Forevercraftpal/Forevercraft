# Ch1 Step 3 Tip: Defeat your first mob
tellraw @s [{"text":"  "},{"text":"Tip: ","color":"aqua","bold":true},{"text":"Hostile mobs spawn at night and in dark caves. Zombies, skeletons, and spiders are common. Craft a sword or use your pickaxe to fight them.","color":"gray","italic":true}]
