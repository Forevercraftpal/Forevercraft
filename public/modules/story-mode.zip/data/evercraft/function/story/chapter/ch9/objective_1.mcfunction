# Ch9 Step 1 Objective
tellraw @s [{"text":"  "},{"text":"\u2726 Objective: ","color":"yellow","bold":true},{"text":"Cook a meal","color":"white"}]
