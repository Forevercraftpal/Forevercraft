# Chapter 535: Fragment: The Ores
# @s = player starting chapter 535

data modify storage evercraft:story temp set value {chapter:"535",color:"blue",name:"Fragment: The Ores"}
function evercraft:story/narrator/chapter_title with storage evercraft:story temp

tellraw @s ""
data modify storage evercraft:story temp set value {speaker:"The Stars",color:"blue",text:"Ores were distributed according to a plan. Diamond at the bottom, coal at the top. The deeper you go, the greater the reward — and the risk."}
function evercraft:story/narrator/tell with storage evercraft:story temp

scoreboard players set @s sm.step 1
scoreboard players set @s sm.quest_prog 0
scoreboard players set @s sm.quest_goal 3
scoreboard players set @s sm.quest_type 1

tellraw @s ""
tellraw @s [{"text":"  "},{"text":"\u2726 Objective: ","color":"yellow","bold":true},{"text":"Discover the Ores","color":"white"}]
playsound minecraft:block.note_block.chime master @s ~ ~ ~ 0.5 1.4
