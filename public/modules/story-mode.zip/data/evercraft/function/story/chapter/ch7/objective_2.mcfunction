# Ch7 Step 2 Objective
tellraw @s [{"text":"  "},{"text":"\u2726 Objective: ","color":"yellow","bold":true},{"text":"Open an activity crate","color":"white"}]
