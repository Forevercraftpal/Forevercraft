# Ch355 Narrative 3

data modify storage evercraft:story temp set value {speaker:"The Wind",color:"dark_aqua",text:"The Nether's ecology is alien but complete."}
function evercraft:story/narrator/tell with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"Warped fungi feed hoglins, which feed piglins, who build bastions."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"A full civilization, burning."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
