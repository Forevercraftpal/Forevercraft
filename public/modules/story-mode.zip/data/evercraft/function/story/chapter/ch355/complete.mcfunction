# Ch355 Complete

data modify storage evercraft:story temp set value {speaker:"The Wind",color:"dark_aqua",text:"Nether denizens documented. An entire alien ecosystem catalogued. The Nether is not chaos — it is order, expressed in fire."}
function evercraft:story/narrator/tell with storage evercraft:story temp
