# Ch306 Narrative 2

data modify storage evercraft:story temp set value {speaker:"The Wind",color:"dark_aqua",text:"Parrots flash like jewels through the canopy."}
function evercraft:story/narrator/tell with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"Every layer of the jungle holds different creatures, different stories."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
