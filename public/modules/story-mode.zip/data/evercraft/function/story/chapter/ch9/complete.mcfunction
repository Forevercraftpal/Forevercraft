# Ch9 Complete — Hearthfire
# @s = player who finished chapter 9

data modify storage evercraft:story temp set value {speaker:"The Land",color:"gold",text:"A home. A meal. A story. These are the things worth fighting for."}
function evercraft:story/narrator/tell with storage evercraft:story temp
