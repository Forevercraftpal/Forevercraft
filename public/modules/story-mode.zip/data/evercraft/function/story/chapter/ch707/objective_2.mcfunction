# Ch707 Objective 2
tellraw @s [{"text":"  "},{"text":"\u2726 Objective: ","color":"yellow","bold":true},{"text":"Witness the sky empty its pockets of fire","color":"white"}]
