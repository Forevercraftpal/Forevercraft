# Ch102 Complete — Voidpiercer
data modify storage evercraft:story temp set value {speaker:"The Blade",color:"red",text:"Fifteen bolts, fifteen wounds torn through the veil. The Voidpiercer has accepted you as its marksman. When you fire, the void itself flinches. No creature can outrun a shot that bends space."}
function evercraft:story/narrator/tell with storage evercraft:story temp
