# Ch7 Step 2 Tip: Open a Dream-Gated Chest
tellraw @s [{"text":"  "},{"text":"Tip: ","color":"aqua","bold":true},{"text":"Dream-gated chests have a purple shimmer and require a minimum Dream Rate to open. Raise your rate by exploring and completing quests before trying again.","color":"gray","italic":true}]
