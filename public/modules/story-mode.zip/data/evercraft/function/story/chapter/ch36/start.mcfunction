# Chapter 36: The Heist — DR/CR 35→36
data modify storage evercraft:story temp set value {chapter:"36",color:"light_purple",name:"The Heist"}
function evercraft:story/narrator/chapter_title with storage evercraft:story temp

tellraw @s ""
data modify storage evercraft:story temp set value {speaker:"The Land",color:"gold",text:"Sometimes the greatest prize requires the lightest touch."}
function evercraft:story/narrator/tell with storage evercraft:story temp

execute if score @s sm.path matches 1 run tellraw @s [{"text":"  "},{"text":"The Black Market Heist demands combat finesse and quick thinking.","color":"gray","italic":true}]
execute if score @s sm.path matches 2 run tellraw @s [{"text":"  "},{"text":"Heist crafting puzzles test your ingenuity under pressure.","color":"gray","italic":true}]
execute if score @s sm.path matches 3 run tellraw @s [{"text":"  "},{"text":"Fight and craft your way through. The heist rewards the versatile.","color":"gray","italic":true}]

scoreboard players set @s sm.step 1
scoreboard players set @s sm.quest_prog 0
scoreboard players set @s sm.quest_goal 3
scoreboard players set @s sm.quest_type 1

tellraw @s ""
tellraw @s [{"text":"  "},{"text":"✦ Objective: ","color":"yellow","bold":true},{"text":"Complete a Black Market Heist.","color":"white"}]
playsound minecraft:block.note_block.chime master @s ~ ~ ~ 0.5 1.4
