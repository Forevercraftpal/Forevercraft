# Chapter 709: Rift Echo - Unlock

tellraw @s ""
tellraw @s [{"text":"[","color":"gray"},{"text":"New Chapter","color":"#8BC34A","bold":true},{"text":"]","color":"gray"},{"text":" 709: Rift Echo","color":"white"}]
tellraw @s [{"text":"  Reality cracks. Other worlds press close.","color":"#BA68C8"}]

scoreboard players set @s ec.story.ch709_unlock 2
