# Ch352 Narrative 2

data modify storage evercraft:story temp set value {speaker:"The Wind",color:"dark_aqua",text:"The zombie's weakness is speed."}
function evercraft:story/narrator/tell with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"The skeleton's weakness is close range."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"The creeper's weakness is awareness."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"Every enemy has a gap in their armor."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
