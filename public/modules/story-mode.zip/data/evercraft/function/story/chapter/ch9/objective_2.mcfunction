# Ch9 Step 2 Objective
tellraw @s [{"text":"  "},{"text":"\u2726 Objective: ","color":"yellow","bold":true},{"text":"Place housing furniture in your home","color":"white"}]
