# Ch364 Narrative 1 — intro covered in start.mcfunction
