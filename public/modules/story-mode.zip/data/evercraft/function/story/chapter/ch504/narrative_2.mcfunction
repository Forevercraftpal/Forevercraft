# Ch504 Narrative 2
data modify storage evercraft:story temp set value {speaker:"The Stars",color:"blue",text:"Five thousand steps beneath the Wanderer's watch."}
function evercraft:story/narrator/tell with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"The constellation shifts as you move — pointing you onward, always onward."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"The ancient explorer knew: the journey IS the destination."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
