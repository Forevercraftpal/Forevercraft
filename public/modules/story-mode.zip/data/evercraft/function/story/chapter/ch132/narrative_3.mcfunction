# Ch132 Narrative 3
data modify storage evercraft:story temp set value {speaker:"The Blade",color:"red",text:"Three wins secured."}
function evercraft:story/narrator/tell with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"Now show the arena your killing instinct — eight total kills across all your duels."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"Every takedown builds the legend of the Challenger."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
