# Ch365 Narrative 3

data modify storage evercraft:story temp set value {speaker:"The Wind",color:"dark_aqua",text:"Sixty seconds of absolute silence in the Warden's domain."}
function evercraft:story/narrator/tell with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"Your heartbeat was the loudest sound."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"You controlled even that."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"The deep dark respects discipline."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
