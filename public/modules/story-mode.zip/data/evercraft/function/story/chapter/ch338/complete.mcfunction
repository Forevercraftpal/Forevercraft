# Ch338 Complete — Outposts and Patrols

data modify storage evercraft:story temp set value {speaker:"The Wind",color:"dark_aqua",text:"The outposts stand as warnings. Whether they warn us or warn something else — that remains to be seen."}
function evercraft:story/narrator/tell with storage evercraft:story temp
