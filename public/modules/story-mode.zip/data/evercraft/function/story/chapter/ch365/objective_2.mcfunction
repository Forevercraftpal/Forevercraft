tellraw @s [{"text":"  "},{"text":"\u2726 Objective: ","color":"yellow","bold":true},{"text":"Avoid the Warden for 60 seconds","color":"white"}]
