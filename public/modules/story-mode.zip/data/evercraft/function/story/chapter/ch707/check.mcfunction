# Chapter 707: Starfall - Progress Check


# Gate: skip check entirely if chapter not yet unlocked
execute unless score @s ec.story.ch707_unlock matches 1.. run return 0
execute if score @s ec.story.ch707 matches 1 run function evercraft:story/chapter/ch707/step2
execute if score @s ec.story.ch707 matches 2 run function evercraft:story/chapter/ch707/step3
execute if score @s ec.story.ch707 matches 3 run function evercraft:story/chapter/ch707/complete
