# Chapter 102: Voidpiercer
# @s = player starting chapter 102

data modify storage evercraft:story temp set value {chapter:"102",color:"red",name:"Voidpiercer"}
function evercraft:story/narrator/chapter_title with storage evercraft:story temp

tellraw @s ""
data modify storage evercraft:story temp set value {speaker:"The Blade",color:"red",text:"Not all battles are won at arm's length, hunter. The Voidpiercer was carved from a rift between worlds — each bolt it fires tears a hole in reality itself. Take aim. Let nothing beyond your sight survive."}
function evercraft:story/narrator/tell with storage evercraft:story temp

scoreboard players set @s sm.step 1
scoreboard players set @s sm.quest_prog 0
scoreboard players set @s sm.quest_goal 3
scoreboard players set @s sm.quest_type 1

tellraw @s ""
tellraw @s [{"text":"  "},{"text":"\u2726 Objective: ","color":"yellow","bold":true},{"text":"Equip the Voidpiercer spirit weapon","color":"white"}]
playsound minecraft:block.note_block.chime master @s ~ ~ ~ 0.5 1.4
