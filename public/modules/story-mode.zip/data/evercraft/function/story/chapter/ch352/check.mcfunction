# Ch352 Progress Check — Overworld Hostiles
# @s = player on chapter 352

execute if score @s sm.step matches 1 if score @s ach.total_kills matches 18.. run function evercraft:story/quest/advance
execute if score @s sm.step matches 2 if score @s ach.total_kills matches 20.. run function evercraft:story/quest/advance
execute if score @s sm.step matches 3 if score @s ach.total_kills matches 22.. run function evercraft:story/quest/advance
