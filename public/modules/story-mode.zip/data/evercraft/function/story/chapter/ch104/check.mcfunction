# Ch104 Progress Check
# @s = player on chapter 104

execute if score @s sm.step matches 1 if score @s ec.sp_weapon matches 4 run function evercraft:story/quest/advance
execute if score @s sm.step matches 2 if score @s ec.sp_kills matches 15.. run function evercraft:story/quest/advance
execute if score @s sm.step matches 3 if score @s ec.sp_ability2_uses matches 8.. run function evercraft:story/quest/advance
