# Ch535 Complete

data modify storage evercraft:story temp set value {speaker:"The Stars",color:"blue",text:"Ore origins preserved. The mineral distribution is a curriculum. The world teaches through reward and risk, layered deliberately from sky to bedrock."}
function evercraft:story/narrator/tell with storage evercraft:story temp
