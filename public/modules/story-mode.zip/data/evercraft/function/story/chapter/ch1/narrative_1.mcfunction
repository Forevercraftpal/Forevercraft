# Ch1 Narrative — Step 1 (chapter just started, first objective given)
# No narrative on step 1 — the start.mcfunction already has the intro
