# Ch1 Narrative — Player just crafted their first iron pickaxe
data modify storage evercraft:story temp set value {speaker:"The Land",color:"gold",text:"Iron."}
function evercraft:story/narrator/tell with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"The first real tool of a civilization."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"The land felt that — a tiny spark of intent."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
data modify storage evercraft:notify stage.c set value [{text:"  "},{text:"Something appeared in your inventory \u2014 the ",color:"gray",italic:true},{text:"Forevercraft Codex",color:"gold",italic:true},{text:".",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 70
function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"  "},{text:"It is your guide, your journal, your connection to the land itself.",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 70
function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"  "},{text:"Inside you'll find your ",color:"gray",italic:true},{text:"Dream Rate",color:"light_purple",italic:true},{text:", ",color:"gray",italic:true},{text:"Craft Rate",color:"aqua",italic:true},{text:", milestones, companions, and more.",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 70
function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"  "},{text:"Hold the book and right-click to open it.",color:"white",italic:true}]
scoreboard players set #ndur ec.temp 70
function evercraft:util/notify/emit
