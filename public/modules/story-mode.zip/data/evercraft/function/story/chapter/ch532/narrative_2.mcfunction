# Ch532 Narrative 2

data modify storage evercraft:story temp set value {speaker:"The Stars",color:"blue",text:"Time was once linear — a single direction, irreversible."}
function evercraft:story/narrator/tell with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"Someone bent it into a circle."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"Seasons are the seams where the ends were joined."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
