# Ch31 Step 1 Tip: Make a moral choice (Reaper)
tellraw @s [{"text":"  "},{"text":"Tip: ","color":"aqua","bold":true},{"text":"The Reaper choice shapes your path forward — consider how it aligns with your playstyle before deciding.","color":"gray","italic":true}]
