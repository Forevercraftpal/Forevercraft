# Ch339 Complete — Trail Ruins

data modify storage evercraft:story temp set value {speaker:"The Wind",color:"dark_aqua",text:"Some civilizations choose to disappear. The trail ruins teach us that not all endings are tragedies — some are choices."}
function evercraft:story/narrator/tell with storage evercraft:story temp
