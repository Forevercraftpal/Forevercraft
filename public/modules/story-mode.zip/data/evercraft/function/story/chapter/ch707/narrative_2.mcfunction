# Ch707 Narrative 2

data modify storage evercraft:story temp set value {speaker:"The Seasons",color:"#8BC34A",text:"The cycle continues."}
function evercraft:story/narrator/tell with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"What was planted grows, what grew is harvested, what was harvested feeds new planting."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"You move with the rhythm now."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
