# Ch535 Narrative 1 — intro covered in start.mcfunction
