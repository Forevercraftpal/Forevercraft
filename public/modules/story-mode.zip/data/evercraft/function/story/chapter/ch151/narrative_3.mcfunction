# Ch151 Narrative 3
data modify storage evercraft:story temp set value {speaker:"The Blade",color:"red",text:"Floor forty breached."}
function evercraft:story/narrator/tell with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"Sixty-five total floors under your boots."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"The castle bleeds and you wade through it. Deeper still, warrior."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"The infinite does not end."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
