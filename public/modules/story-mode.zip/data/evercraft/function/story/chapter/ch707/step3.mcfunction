# Chapter 707: Starfall - Step 3

scoreboard players set @s ec.story.ch707 3

data modify storage evercraft:story temp set value {speaker:"The Seasons",color:"#FFD54F",text:"The last meteor fades into dawn. The sky is whole again, but the earth is richer. Star-gifts litter the landscape like scattered jewels."}
function evercraft:story/narrator/tell with storage evercraft:story temp

data modify storage evercraft:story temp set value {speaker:"The Seasons",color:"#8BC34A",text:"Starfall ends as it began — with wonder. The cosmos has spoken. Were you listening?"}
function evercraft:story/narrator/tell with storage evercraft:story temp

function evercraft:story/chapter/ch707/complete
