$function evercraft:story/chapter/ch$(chapter)/start
