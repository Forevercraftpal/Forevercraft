# Ch102 Progress Check
# @s = player on chapter 102

execute if score @s sm.step matches 1 if score @s ec.sp_weapon matches 2 run function evercraft:story/quest/advance
execute if score @s sm.step matches 2 if score @s ec.sp_range_kills matches 10.. run function evercraft:story/quest/advance
execute if score @s sm.step matches 3 if score @s ec.sp_crits matches 15.. run function evercraft:story/quest/advance
