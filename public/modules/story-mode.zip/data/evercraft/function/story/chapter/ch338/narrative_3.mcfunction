# Ch338 Narrative 3

data modify storage evercraft:story temp set value {speaker:"The Wind",color:"dark_aqua",text:"The banners declare allegiance."}
function evercraft:story/narrator/tell with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"The pillagers see themselves as liberators, not invaders."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"Perspective changes everything."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
