# Ch38 Step 3 Tip: Reach Artisan Rank 50
tellraw @s [{"text":"  "},{"text":"Tip: ","color":"aqua","bold":true},{"text":"Rank 50 unlocks legendary recipes — focus on mastering each crafting discipline to maximize XP gains.","color":"gray","italic":true}]
