tellraw @s [{"text":"  "},{"text":"\u2726 Objective: ","color":"yellow","bold":true},{"text":"Equip the Voidpiercer spirit weapon","color":"white"}]
