# Ch709 Objective 1
tellraw @s [{"text":"  "},{"text":"\u2726 Objective: ","color":"yellow","bold":true},{"text":"Listen as reality begins to crack","color":"white"}]
