# Ch31 Step 3 Tip: Complete a Trade Trial Tier 4+
tellraw @s [{"text":"  "},{"text":"Tip: ","color":"aqua","bold":true},{"text":"Trade Trials at Tier 4 require rare materials — stock up on enchanted items before entering.","color":"gray","italic":true}]
