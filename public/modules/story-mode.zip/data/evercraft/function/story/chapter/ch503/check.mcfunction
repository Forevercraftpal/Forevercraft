# Ch503 Progress Check
# Step 1: Identify the Artisan constellation
execute if score @s sm.step matches 1 if score @s adv.stat_forge matches 1.. run function evercraft:story/quest/advance
# Step 2: Craft 15 items under the Artisan constellation
execute if score @s sm.step matches 2 if score @s adv.stat_forge matches 15.. run function evercraft:story/quest/advance
# Step 3: Craft a rare item at night
execute if score @s sm.step matches 3 if score @s ec.recipes_learned_total matches 1.. run function evercraft:story/quest/advance
