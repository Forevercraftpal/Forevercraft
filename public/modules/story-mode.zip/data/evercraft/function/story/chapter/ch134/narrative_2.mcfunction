# Ch134 Narrative 2
data modify storage evercraft:story temp set value {speaker:"The Blade",color:"red",text:"Win a duel while below twenty percent health."}
function evercraft:story/narrator/tell with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"When your vision blurs and your hands shake — that is when true warriors shine brightest."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"Clutch victory from the edge of death."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
