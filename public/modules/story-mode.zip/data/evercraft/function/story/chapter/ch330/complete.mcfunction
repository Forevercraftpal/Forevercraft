# Ch330 Complete — Jungle Temples

data modify storage evercraft:story temp set value {speaker:"The Wind",color:"dark_aqua",text:"The jungle devoured the temple but could not solve its puzzles. Intelligence outlasts even nature."}
function evercraft:story/narrator/tell with storage evercraft:story temp
