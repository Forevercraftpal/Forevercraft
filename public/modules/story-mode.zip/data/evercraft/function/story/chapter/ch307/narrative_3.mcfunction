# Ch307 Narrative 3

data modify storage evercraft:story temp set value {speaker:"The Wind",color:"dark_aqua",text:"No monsters spawn here."}
function evercraft:story/narrator/tell with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"The mushroom isle is the one place in the world untouched by darkness. How? Why? The wind does not know."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
