# Ch31 Complete — Morality's Edge
data modify storage evercraft:story temp set value {speaker:"The Land",color:"gold",text:"The shadow you cast is yours. Own it."}
function evercraft:story/narrator/tell with storage evercraft:story temp

# Reward: 10 coins
execute unless score @s ec.difficulty matches 3 run scoreboard players add @s ec.coins 10
execute unless score @s ec.difficulty matches 3 run tellraw @s [{"text":"  "},{"text":"+10 Forever Coins","color":"yellow"}]

# The Hollow stirs
data modify storage evercraft:story temp set value {text:"Interesting. You choose a side. I consume both."}
function evercraft:story/narrator/hollow with storage evercraft:story temp
