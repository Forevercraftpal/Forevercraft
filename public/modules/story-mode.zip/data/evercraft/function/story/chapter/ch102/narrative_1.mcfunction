# Ch102 Narrative 1 — chapter intro covered in start.mcfunction
