tellraw @s [{"text":"  "},{"text":"✦ Objective: ","color":"yellow","bold":true},{"text":"Craft a rare item at night","color":"white"}]
