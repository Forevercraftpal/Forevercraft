# Ch503 Narrative 3
data modify storage evercraft:story temp set value {speaker:"The Stars",color:"blue",text:"A rare creation under starlight."}
function evercraft:story/narrator/tell with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"The Artisan's Anvil rings across the cosmos in answer."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"You have forged something worthy of the ancient crafters — something that will outlast the dark."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
