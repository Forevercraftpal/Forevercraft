# Ch1 Complete — First Light
# @s = player who finished chapter 1

data modify storage evercraft:story temp set value {speaker:"The Land",color:"gold",text:"The first step is always the hardest. But you took it. This land remembers."}
function evercraft:story/narrator/tell with storage evercraft:story temp

# Closing tagline — canonical form (matches difficulty/pioneer_death:45).
# Lifted from the retired tutorial/steps/complete:22 ("loot" → "treasure") on 2026-05-28
# as part of Council #15 dead-by-design tutorial archive (Path A).
tellraw @s {text:""}
tellraw @s [{text:"    Every world has treasure. This one has dreams.",color:"gold",italic:true}]
