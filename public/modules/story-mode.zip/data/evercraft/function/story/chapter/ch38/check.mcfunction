# Ch38 Progress Check — The Living World
# Step 1: 500 spirit kills (DR) or Artisan Rank 50 (CR)
execute if score @s sm.step matches 1 if score @s sm.path matches 1 if score @s ec.sp_kills matches 500.. run function evercraft:story/quest/advance
execute if score @s sm.step matches 1 if score @s sm.path matches 2 if score @s ec.cf_rank matches 50.. run function evercraft:story/quest/advance
execute if score @s sm.step matches 1 if score @s sm.path matches 3 if score @s ec.sp_kills matches 500.. if score @s ec.cf_rank matches 50.. run function evercraft:story/quest/advance
# Step 2: Complete 3 constellations
execute if score @s sm.step matches 2 if score @s ec.cn_done matches 3.. run function evercraft:story/quest/advance
# Step 3: Visit 10 biomes
execute if score @s sm.step matches 3 if score @s ach.biomes_visited matches 10.. run function evercraft:story/quest/advance
