# Ch7 Narrative — Player just opened a dream-gated chest
data modify storage evercraft:story temp set value {speaker:"The Land",color:"gold",text:"The chest opened for you."}
function evercraft:story/narrator/tell with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"It would not have opened for just anyone."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"The dream tested you and you passed without even knowing."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
data modify storage evercraft:notify stage.c set value [{text:"  "},{text:"That item in your hands — it has a name. A history. Identify it.",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 70
function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"  "},{text:"Everything in this world wants to be known. Even objects. Especially objects.",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 70
function evercraft:util/notify/emit
