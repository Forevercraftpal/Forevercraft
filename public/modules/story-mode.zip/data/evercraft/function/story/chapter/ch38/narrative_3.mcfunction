# Ch38 Narrative — Player reached Artisan Rank 50
data modify storage evercraft:story temp set value {speaker:"The Land",color:"gold",text:"Artisan Rank 50. Halfway to the peak."}
function evercraft:story/narrator/tell with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"Your hands have shaped more than stone and iron — they have shaped a legacy."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"Every item you craft carries your name in its grain."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
data modify storage evercraft:notify stage.c set value [{text:"  "},{text:"The raids grow fiercer. The Hollow sends more.",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 70
function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"  "},{text:"It is testing you, probing for weakness, searching for the crack in your resolve.",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 70
function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"  "},{text:"Let it search. It will find nothing but steel.",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 70
function evercraft:util/notify/emit
