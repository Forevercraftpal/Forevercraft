tellraw @s [{"text":"  "},{"text":"\u2726 Objective: ","color":"yellow","bold":true},{"text":"Find a pillager outpost","color":"white"}]
