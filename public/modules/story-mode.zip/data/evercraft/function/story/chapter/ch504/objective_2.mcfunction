tellraw @s [{"text":"  "},{"text":"✦ Objective: ","color":"yellow","bold":true},{"text":"Travel 5000 blocks at night","color":"white"}]
