# Ch339 Narrative 2

data modify storage evercraft:story temp set value {speaker:"The Wind",color:"dark_aqua",text:"Brushing away dirt reveals pottery sherds with symbols we cannot read. A language lost to time."}
function evercraft:story/narrator/tell with storage evercraft:story temp
