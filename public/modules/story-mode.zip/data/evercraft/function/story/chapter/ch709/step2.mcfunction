# Chapter 709: Rift Echo - Step 2

scoreboard players set @s ec.story.ch709 2

data modify storage evercraft:story temp set value {speaker:"The Seasons",color:"#BA68C8",text:"Through the rifts, strange materials drift — substances that obey different laws. They shimmer with impossible colors and hum with frequencies that make your teeth ache."}
function evercraft:story/narrator/tell with storage evercraft:story temp

data modify storage evercraft:story temp set value {speaker:"The Seasons",color:"#BA68C8",text:"The Rift Echo is a doorway that opens both ways. Be cautious what you invite through — and what you let escape."}
function evercraft:story/narrator/tell with storage evercraft:story temp
