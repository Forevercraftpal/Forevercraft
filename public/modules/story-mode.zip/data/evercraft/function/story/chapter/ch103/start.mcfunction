# Chapter 103: Firebrand
# @s = player starting chapter 103

data modify storage evercraft:story temp set value {chapter:"103",color:"red",name:"Firebrand"}
function evercraft:story/narrator/chapter_title with storage evercraft:story temp

tellraw @s ""
data modify storage evercraft:story temp set value {speaker:"The Blade",color:"red",text:"BURN. That is all the Firebrand knows. It was forged in the heart of a dying volcano by a berserker who laughed as the lava consumed him. His rage lives on in every swing. Take the axe — and let your fury become fire."}
function evercraft:story/narrator/tell with storage evercraft:story temp

scoreboard players set @s sm.step 1
scoreboard players set @s sm.quest_prog 0
scoreboard players set @s sm.quest_goal 3
scoreboard players set @s sm.quest_type 1

tellraw @s ""
tellraw @s [{"text":"  "},{"text":"\u2726 Objective: ","color":"yellow","bold":true},{"text":"Equip the Firebrand spirit weapon","color":"white"}]
playsound minecraft:block.note_block.chime master @s ~ ~ ~ 0.5 1.4
