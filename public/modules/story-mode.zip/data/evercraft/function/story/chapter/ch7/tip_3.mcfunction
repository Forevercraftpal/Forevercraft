# Ch7 Step 3 Tip: Identify the Loot
tellraw @s [{"text":"  "},{"text":"Tip: ","color":"aqua","bold":true},{"text":"Some items from dream-gated chests are unidentified. Visit a village scholar or use an identification scroll to reveal their true properties.","color":"gray","italic":true}]
