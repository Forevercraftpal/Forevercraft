# Ch9 Progress Check — Hearthfire
# Step 1: Cook a meal
execute if score @s sm.step matches 1 if score @s ach.meals_cooked matches 1.. run function evercraft:story/quest/advance
# Step 2: Place housing furniture
execute if score @s sm.step matches 2 if score @s hs.tier matches 1.. run function evercraft:story/quest/advance
# Step 3: Sit at a campfire
execute if score @s sm.step matches 3 if entity @s[tag=campfire_story] run function evercraft:story/quest/advance
