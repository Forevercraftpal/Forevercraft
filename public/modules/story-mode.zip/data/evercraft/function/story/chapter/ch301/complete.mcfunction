# Ch301 Complete — The World Awaits

data modify storage evercraft:story temp set value {speaker:"The Wind",color:"dark_aqua",text:"The journey has truly begun. The world stretches endlessly before you, and every step reveals something new."}
function evercraft:story/narrator/tell with storage evercraft:story temp
