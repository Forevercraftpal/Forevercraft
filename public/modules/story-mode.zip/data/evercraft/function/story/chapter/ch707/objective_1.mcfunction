# Ch707 Objective 1
tellraw @s [{"text":"  "},{"text":"\u2726 Objective: ","color":"yellow","bold":true},{"text":"Watch the stars begin their descent","color":"white"}]
