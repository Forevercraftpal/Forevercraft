# Ch36 Step 3 Tip: Collect the heist reward
tellraw @s [{"text":"  "},{"text":"Tip: ","color":"aqua","bold":true},{"text":"Heist rewards scale with difficulty — completing bonus objectives during the heist unlocks better loot.","color":"gray","italic":true}]
