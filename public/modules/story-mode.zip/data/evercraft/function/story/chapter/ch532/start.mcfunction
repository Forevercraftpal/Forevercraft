# Chapter 532: Fragment: The Seasons
# @s = player starting chapter 532

data modify storage evercraft:story temp set value {chapter:"532",color:"blue",name:"Fragment: The Seasons"}
function evercraft:story/narrator/chapter_title with storage evercraft:story temp

tellraw @s ""
data modify storage evercraft:story temp set value {speaker:"The Stars",color:"blue",text:"Time was not always cyclical. Someone CHOSE to make it turn. The seasons are a gift — and a cage."}
function evercraft:story/narrator/tell with storage evercraft:story temp

scoreboard players set @s sm.step 1
scoreboard players set @s sm.quest_prog 0
scoreboard players set @s sm.quest_goal 3
scoreboard players set @s sm.quest_type 1

tellraw @s ""
tellraw @s [{"text":"  "},{"text":"\u2726 Objective: ","color":"yellow","bold":true},{"text":"Discover the Seasons","color":"white"}]
playsound minecraft:block.note_block.chime master @s ~ ~ ~ 0.5 1.4
