# Chapter 709: Rift Echo - Reward

tellraw @s ""
tellraw @s [{"text":"[","color":"gray"},{"text":"Chapter Complete","color":"#8BC34A","bold":true},{"text":"]","color":"gray"},{"text":" Rift Echo","color":"white"}]
tellraw @s [{"text":"  You glimpsed the space between worlds.","color":"#BA68C8"}]

execute store result score @s ec.xp run scoreboard players add @s ec.xp 50

scoreboard players set @s ec.story.ch710_unlock 1
