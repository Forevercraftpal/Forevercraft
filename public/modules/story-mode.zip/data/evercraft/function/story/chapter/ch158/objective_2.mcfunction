tellraw @s [{"text":"  "},{"text":"\u2726 Objective: ","color":"yellow","bold":true},{"text":"Reach castle floor 90","color":"white"}]
