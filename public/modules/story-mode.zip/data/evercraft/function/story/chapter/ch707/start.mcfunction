# Chapter 707: Starfall - Start
# Branch 7: Seasonal Chronicles

scoreboard players set @s ec.story.ch707 1

data modify storage evercraft:story temp set value {chapter:"707",color:"#8BC34A",name:"Starfall"}
function evercraft:story/narrator/chapter_title with storage evercraft:story temp

tellraw @s ""
data modify storage evercraft:story temp set value {speaker:"The Seasons",color:"#FFD54F",text:"The stars are falling. Not dying — visiting. They streak across the black like burning wishes, each one carrying a fragment of the cosmos."}
function evercraft:story/narrator/tell with storage evercraft:story temp

data modify storage evercraft:story temp set value {speaker:"The Seasons",color:"#FFD54F",text:"Starfall is the calendar's most spectacular entry. The sky empties its pockets and the earth catches what it can."}
function evercraft:story/narrator/tell with storage evercraft:story temp

data modify storage evercraft:story temp set value {speaker:"The Seasons",color:"#8BC34A",text:"The forevercraft:seasonal_clock counts each streak. Tonight, it counts hundreds."}
function evercraft:story/narrator/tell with storage evercraft:story temp

function evercraft:story/chapter/ch707/step2
