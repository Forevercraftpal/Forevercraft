# Ch7 Narrative — Player just found a structure
data modify storage evercraft:story temp set value {speaker:"The Land",color:"gold",text:"This place is old. Older than the villages."}
function evercraft:story/narrator/tell with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"Older than the trees that grew around it."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"Someone built this with purpose — and then they vanished."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
data modify storage evercraft:notify stage.c set value [{text:"  "},{text:"Inside, there is a chest sealed by the dream itself.",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 70
function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"  "},{text:"Only those the land trusts can open it.",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 70
function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"  "},{text:"You are trusted. Reach inside. Take what was left for you.",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 70
function evercraft:util/notify/emit
