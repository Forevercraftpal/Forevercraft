# Ch503 Narrative 2
data modify storage evercraft:story temp set value {speaker:"The Stars",color:"blue",text:"Fifteen creations shaped beneath the Anvil's light."}
function evercraft:story/narrator/tell with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"Each one carries a sliver of that ancient resonance."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"The constellation hums with satisfaction — your hands remember what your mind has forgotten."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
