# Ch306 Complete — Canopy Secrets

data modify storage evercraft:story temp set value {speaker:"The Wind",color:"dark_aqua",text:"The jungle has accepted you as one of its own. Few receive such an honor."}
function evercraft:story/narrator/tell with storage evercraft:story temp
