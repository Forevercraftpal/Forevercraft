# Ch363 Progress Check — Crystal Geodes
# @s = player on chapter 363

execute if score @s sm.step matches 1 if score @s ach.biomes_visited matches 13.. run function evercraft:story/quest/advance
execute if score @s sm.step matches 2 if score @s ach.biomes_visited matches 15.. run function evercraft:story/quest/advance
execute if score @s sm.step matches 3 if score @s ach.biomes_visited matches 16.. run function evercraft:story/quest/advance
