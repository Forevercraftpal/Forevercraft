# Chapter 132: The Challenger
# @s = player starting chapter 132

data modify storage evercraft:story temp set value {chapter:"132",color:"red",name:"The Challenger"}
function evercraft:story/narrator/chapter_title with storage evercraft:story temp

tellraw @s ""
data modify storage evercraft:story temp set value {speaker:"The Blade",color:"red",text:"One win makes you lucky. Three wins makes you a Challenger. The arena respects persistence — every duel you survive, every opponent you topple, builds your reputation. They will start to know your name. They will start to fear your approach."}
function evercraft:story/narrator/tell with storage evercraft:story temp

scoreboard players set @s sm.step 1
scoreboard players set @s sm.quest_prog 0
scoreboard players set @s sm.quest_goal 3
scoreboard players set @s sm.quest_type 1

tellraw @s ""
tellraw @s [{"text":"  "},{"text":"\u2726 Objective: ","color":"yellow","bold":true},{"text":"Win 2 duels","color":"white"}]
playsound minecraft:block.note_block.chime master @s ~ ~ ~ 0.5 1.4
