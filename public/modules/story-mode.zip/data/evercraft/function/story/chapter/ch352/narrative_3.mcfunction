# Ch352 Narrative 3

data modify storage evercraft:story temp set value {speaker:"The Wind",color:"dark_aqua",text:"Ten hostiles defeated with understanding, not just strength."}
function evercraft:story/narrator/tell with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"The difference between a fighter and a warrior is knowledge."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
