# Chapter 365: The Warden's Domain
# @s = player starting chapter 365

data modify storage evercraft:story temp set value {chapter:"365",color:"dark_aqua",name:"The Warden's Domain"}
function evercraft:story/narrator/chapter_title with storage evercraft:story temp

tellraw @s ""
data modify storage evercraft:story temp set value {speaker:"The Wind",color:"dark_aqua",text:"Silence is survival here. The deep dark answers vibration with destruction. The Warden does not hunt by sight — it hunts by sound. Walk softly. Or do not walk at all."}
function evercraft:story/narrator/tell with storage evercraft:story temp

scoreboard players set @s sm.step 1
scoreboard players set @s sm.quest_prog 0
scoreboard players set @s sm.quest_goal 3
scoreboard players set @s sm.quest_type 1

tellraw @s ""
tellraw @s [{"text":"  "},{"text":"\u2726 Objective: ","color":"yellow","bold":true},{"text":"Enter the deep dark","color":"white"}]
playsound minecraft:block.note_block.chime master @s ~ ~ ~ 0.5 1.4
