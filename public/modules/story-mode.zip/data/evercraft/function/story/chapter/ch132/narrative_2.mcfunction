# Ch132 Narrative 2
data modify storage evercraft:story temp set value {speaker:"The Blade",color:"red",text:"Two down."}
function evercraft:story/narrator/tell with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"The crowd remembers your face now."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"One more duel victory and you earn the Challenger's mark — a reputation that precedes you into every fight."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
