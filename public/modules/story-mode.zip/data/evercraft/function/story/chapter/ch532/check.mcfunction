# Ch532 Progress Check — Fragment: The Seasons
# @s = player on chapter 532

execute if score @s sm.step matches 1 if score @s ach.lore_found matches 7.. run function evercraft:story/quest/advance
execute if score @s sm.step matches 2 if score @s ec.inscr_count matches 3.. run function evercraft:story/quest/advance
execute if score @s sm.step matches 3 if score @s ach.lore_found matches 9.. run function evercraft:story/quest/advance
