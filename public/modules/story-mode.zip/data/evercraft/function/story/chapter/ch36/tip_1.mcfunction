# Ch36 Step 1 Tip: Find the Black Market
tellraw @s [{"text":"  "},{"text":"Tip: ","color":"aqua","bold":true},{"text":"The Black Market is hidden behind a false wall in the underground district — look for redstone dust trails.","color":"gray","italic":true}]
