# Ch37 Step 1 Tip: Win a duel
tellraw @s [{"text":"  "},{"text":"Tip: ","color":"aqua","bold":true},{"text":"Duels test pure combat skill — study your opponent's weapon type and keep distance against heavy hitters.","color":"gray","italic":true}]
