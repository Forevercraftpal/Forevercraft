# Chapter 707: Starfall - Complete


# Recursion guard (2026-05-28 polish): moved to top so skip-path callers — which
# set sm.completing BEFORE invoking on_complete (which dispatches back here via
# complete_macro) — short-circuit before any narrator tellraw or scoreboard write,
# matching the intent that a skipped chapter shows only the [Skipped] notice.
execute if entity @s[tag=sm.completing] run return 0

scoreboard players set @s ec.story.ch707 4
scoreboard players set @s ec.story.ch707_replay 1

data modify storage evercraft:story temp set value {speaker:"The Seasons",color:"#FFD54F",text:"You caught the falling stars in your memory. The sky knows a watcher when it sees one."}
function evercraft:story/narrator/tell with storage evercraft:story temp


# Compatibility shim: integrate with universal completion system.
# (Recursion guard moved to the TOP of this file 2026-05-28 polish wave — fixes skip-path
#  ordering bug where the chapter narrator tellraw fired after the [Skipped] notice.)
tag @s add sm.completing
scoreboard players set @s sm.step 4
function evercraft:story/chapter/on_complete
tag @s remove sm.completing

function evercraft:story/chapter/ch707/reward
