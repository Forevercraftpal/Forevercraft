# Chapter 38: The Living World — DR/CR 37→38
data modify storage evercraft:story temp set value {chapter:"38",color:"light_purple",name:"The Living World"}
function evercraft:story/narrator/chapter_title with storage evercraft:story temp

tellraw @s ""
data modify storage evercraft:story temp set value {speaker:"The Land",color:"gold",text:"To know every creature is to know the world's heartbeat."}
function evercraft:story/narrator/tell with storage evercraft:story temp

execute if score @s sm.path matches 1 run tellraw @s [{"text":"  "},{"text":"The Bestiary catalogs every creature. Shinies shimmer in the tall grass.","color":"gray","italic":true}]
execute if score @s sm.path matches 2 run tellraw @s [{"text":"  "},{"text":"Evolution preparations require rare materials. Gather them.","color":"gray","italic":true}]
execute if score @s sm.path matches 3 run tellraw @s [{"text":"  "},{"text":"Catalog, capture, evolve — the living world rewards the curious.","color":"gray","italic":true}]

scoreboard players set @s sm.step 1
scoreboard players set @s sm.quest_prog 0
scoreboard players set @s sm.quest_goal 3
scoreboard players set @s sm.quest_type 1

tellraw @s ""
execute if score @s sm.path matches 1 run tellraw @s [{"text":"  "},{"text":"✦ Objective: ","color":"yellow","bold":true},{"text":"Reach 500 spirit weapon kills (master the bestiary).","color":"white"}]
execute if score @s sm.path matches 2 run tellraw @s [{"text":"  "},{"text":"✦ Objective: ","color":"yellow","bold":true},{"text":"Reach Artisan Rank 50 — Grand tier (Mythical forging).","color":"white"}]
execute if score @s sm.path matches 3 run tellraw @s [{"text":"  "},{"text":"✦ Objective: ","color":"yellow","bold":true},{"text":"Reach 500 spirit weapon kills (master the bestiary).","color":"white"}]
playsound minecraft:block.note_block.chime master @s ~ ~ ~ 0.5 1.4
