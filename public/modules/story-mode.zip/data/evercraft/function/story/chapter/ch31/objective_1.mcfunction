# Ch31 Step 1 Objective
tellraw @s [{"text":"  "},{"text":"\u2726 Objective: ","color":"yellow","bold":true},{"text":"Make a moral choice through the Reaper system","color":"white"}]
