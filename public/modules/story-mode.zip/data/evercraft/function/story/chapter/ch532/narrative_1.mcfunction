# Ch532 Narrative 1 — intro covered in start.mcfunction
