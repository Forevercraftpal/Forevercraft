# Chapter 707: Starfall - Info

tellraw @s ""
tellraw @s [{"text":"=== ","color":"gray"},{"text":"Chapter 707","color":"#8BC34A","bold":true},{"text":" ===","color":"gray"}]
tellraw @s [{"text":"Starfall","color":"white","bold":true}]
tellraw @s [{"text":"Branch: ","color":"gray"},{"text":"Seasonal Chronicles","color":"#8BC34A"}]
tellraw @s [{"text":"Type: ","color":"gray"},{"text":"Event Story (Auto-advance)","color":"yellow"}]
tellraw @s ""
tellraw @s [{"text":"Meteors rain from the sky, bringing star-iron and celestial dust. The cosmos visits the earth.","color":"#FFD54F"}]
