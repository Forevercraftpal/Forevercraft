# Ch31 Progress Check — Morality's Edge
# Step 1: Make a moral choice (Reaper tier changed)
execute if score @s sm.step matches 1 if score @s sm.path matches 1 unless score @s rp.tier matches 0 run function evercraft:story/quest/advance
execute if score @s sm.step matches 1 if score @s sm.path matches 2 if score @s ec.cf_rank matches 35.. run function evercraft:story/quest/advance
execute if score @s sm.step matches 1 if score @s sm.path matches 3 unless score @s rp.tier matches 0 run function evercraft:story/quest/advance
# Step 2: Reach Artisan Rank 35
execute if score @s sm.step matches 2 if score @s ec.cf_rank matches 35.. run function evercraft:story/quest/advance
# Step 3: Earn 500 coins
execute if score @s sm.step matches 3 if score @s ec.coins matches 500.. run function evercraft:story/quest/advance
