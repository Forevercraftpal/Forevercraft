# Chapter 550: The Legend of You
# @s = player starting chapter 550

data modify storage evercraft:story temp set value {chapter:"550",color:"blue",name:"The Legend of You"}
function evercraft:story/narrator/chapter_title with storage evercraft:story temp

tellraw @s ""
data modify storage evercraft:story temp set value {speaker:"The Stars",color:"blue",text:"This is your legend. Not written in ancient text — written in every block you placed, every friend you made, every darkness you faced. The Stars bow to you."}
function evercraft:story/narrator/tell with storage evercraft:story temp

scoreboard players set @s sm.step 1
scoreboard players set @s sm.quest_prog 0
scoreboard players set @s sm.quest_goal 3
scoreboard players set @s sm.quest_type 1

tellraw @s ""
tellraw @s [{"text":"  "},{"text":"\u2726 Objective: ","color":"yellow","bold":true},{"text":"Listen to The Legend of You","color":"white"}]
playsound minecraft:block.note_block.chime master @s ~ ~ ~ 0.5 1.4
