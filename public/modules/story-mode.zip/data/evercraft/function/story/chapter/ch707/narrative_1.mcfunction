# Ch707 Narrative 1

data modify storage evercraft:story temp set value {speaker:"The Seasons",color:"#8BC34A",text:"Look skyward."}
function evercraft:story/narrator/tell with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"The stars are falling — not dying, but descending."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"Each streak of light carries a fragment of the cosmos down to waiting earth."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
