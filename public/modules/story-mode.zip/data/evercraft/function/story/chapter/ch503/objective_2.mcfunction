tellraw @s [{"text":"  "},{"text":"✦ Objective: ","color":"yellow","bold":true},{"text":"Craft 15 items under the Artisan constellation","color":"white"}]
