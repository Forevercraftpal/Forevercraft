# Ch37 Step 2 Tip: Reach Great Friend with someone
tellraw @s [{"text":"  "},{"text":"Tip: ","color":"aqua","bold":true},{"text":"Friendship grows through shared activities — adventure together, trade gifts, and complete co-op quests.","color":"gray","italic":true}]
