# Ch158 Complete — Floor 90: Edge of Oblivion
data modify storage evercraft:story temp set value {speaker:"The Blade",color:"red",text:"You stand on the Edge of Oblivion and the void blinks first. Ninety floors. One hundred and forty total. The Eternal Throne is ten floors away — the final challenge of the Infinite Castle. Steel yourself for the ultimate descent."}
function evercraft:story/narrator/tell with storage evercraft:story temp
