# Ch38 Narrative — Player logged 30 bestiary entries and evolved Codex to Phoenix
data modify storage evercraft:story temp set value {speaker:"The Land",color:"gold",text:"Thirty creatures documented."}
function evercraft:story/narrator/tell with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"You did not just kill them — you learned them."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"Their patterns, their weaknesses, their place in the world. A warrior destroys. A champion understands."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
data modify storage evercraft:notify stage.c set value [{text:"  "},{text:"And the Codex — it burns now with the Phoenix flame.",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 70
function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"  "},{text:"Reborn from everything you have poured into it.",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 70
function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"  "},{text:"Your knowledge has taken on a life of its own.",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 70
function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"  "},{text:"Artisan Rank 50 calls to you. Halfway to mastery.",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 70
function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"  "},{text:"Halfway to something The Hollow cannot comprehend.",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 70
function evercraft:util/notify/emit
