# Ch37 Complete — Hearts & Swords
data modify storage evercraft:story temp set value {speaker:"The Land",color:"gold",text:"The heart and the sword — both are forged in fire. Both cut deeper than steel."}
function evercraft:story/narrator/tell with storage evercraft:story temp

# Reward: 20 coins
execute unless score @s ec.difficulty matches 3 run scoreboard players add @s ec.coins 20
execute unless score @s ec.difficulty matches 3 run tellraw @s [{"text":"  "},{"text":"+20 Forever Coins","color":"yellow"}]
