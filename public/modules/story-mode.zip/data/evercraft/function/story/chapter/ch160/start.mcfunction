# Chapter 160: Beyond the Throne
data modify storage evercraft:story temp set value {chapter:"160",color:"dark_red",name:"Beyond the Throne"}
function evercraft:story/narrator/chapter_title with storage evercraft:story temp
tellraw @s ""
data modify storage evercraft:story temp set value {speaker:"The Blade",color:"red",text:"You claimed the Eternal Throne. You conquered floor one hundred. But the castle is INFINITE, warrior. Beyond the throne, the floors continue — darker, harder, more twisted than anything above. The castle does not end. It only gets hungrier. Descend beyond the throne. Show infinity that you are endless too."}
function evercraft:story/narrator/tell with storage evercraft:story temp
scoreboard players set @s sm.step 1
scoreboard players set @s sm.quest_prog 0
scoreboard players set @s sm.quest_goal 3
scoreboard players set @s sm.quest_type 1
tellraw @s ""
tellraw @s [{"text":"  "},{"text":"\u2726 Objective: ","color":"yellow","bold":true},{"text":"Clear 150 total castle floors","color":"white"}]
playsound minecraft:block.note_block.chime master @s ~ ~ ~ 0.5 1.4
