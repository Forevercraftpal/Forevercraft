# Ch309 Narrative 3

data modify storage evercraft:story temp set value {speaker:"The Wind",color:"dark_aqua",text:"Snow dusts the spruce tips like sugar."}
function evercraft:story/narrator/tell with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"The taiga is stern but beautiful, like a guardian who has stood watch too long."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
