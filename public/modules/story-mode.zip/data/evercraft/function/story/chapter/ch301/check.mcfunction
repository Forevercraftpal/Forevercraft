# Ch301 Progress Check — The World Awaits
# @s = player on chapter 301

execute if score @s sm.step matches 1 if score @s sm.step matches 1 run function evercraft:story/quest/advance
execute if score @s sm.step matches 2 if score @s ach.biomes_visited matches 3.. run function evercraft:story/quest/advance
execute if score @s sm.step matches 3 if score @s ach.biomes_visited matches 5.. run function evercraft:story/quest/advance
