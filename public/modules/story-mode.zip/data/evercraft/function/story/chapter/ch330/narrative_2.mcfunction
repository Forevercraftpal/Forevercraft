# Ch330 Narrative 2

data modify storage evercraft:story temp set value {speaker:"The Wind",color:"dark_aqua",text:"The dispenser trap fires arrows at the unwary."}
function evercraft:story/narrator/tell with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"But look closer — the mechanism is elegant. Art disguised as danger."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
