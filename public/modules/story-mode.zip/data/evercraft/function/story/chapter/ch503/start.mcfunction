# Chapter 503: The Artisan's Anvil
# @s = player starting chapter 503

data modify storage evercraft:story temp set value {chapter:"503",color:"blue",name:"The Artisan's Anvil"}
function evercraft:story/narrator/chapter_title with storage evercraft:story temp

tellraw @s ""
data modify storage evercraft:story temp set value {speaker:"The Stars",color:"blue",text:"The first crafter shaped starlight into form. Their anvil rang so true that each strike echoed into eternity — and those echoes became stars. Five points of hammered light. The Artisan's Anvil still rings for those who listen."}
function evercraft:story/narrator/tell with storage evercraft:story temp

scoreboard players set @s sm.step 1
scoreboard players set @s sm.quest_prog 0
scoreboard players set @s sm.quest_goal 3
scoreboard players set @s sm.quest_type 1

tellraw @s ""
tellraw @s [{"text":"  "},{"text":"✦ Objective: ","color":"yellow","bold":true},{"text":"Identify the Artisan constellation at night","color":"white"}]
playsound minecraft:block.note_block.chime master @s ~ ~ ~ 0.5 1.4
