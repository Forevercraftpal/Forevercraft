# Ch134 Progress Check
execute if score @s sm.step matches 1 if score @s ec.duel_active matches 1.. run function evercraft:story/quest/advance
execute if score @s sm.step matches 2 if score @s ec.sp_duel_wins matches 1.. run function evercraft:story/quest/advance
execute if score @s sm.step matches 3 if score @s ec.sp_duel_wins matches 5.. run function evercraft:story/quest/advance
