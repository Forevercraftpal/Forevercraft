# Ch37 Step 3 Tip: Discover 4+ party combos
tellraw @s [{"text":"  "},{"text":"Tip: ","color":"aqua","bold":true},{"text":"Try mixing different class abilities in rapid succession — some combos only trigger with specific element pairings.","color":"gray","italic":true}]
