# Ch1 Objective — Called when player clicks [Story] button
# @s = player checking their objective

execute if score @s sm.step matches 1 run tellraw @s [{"text":"  "},{"text":"\u2726 Objective: ","color":"yellow","bold":true},{"text":"Craft an Iron Pickaxe","color":"white"}]
execute if score @s sm.step matches 2 run tellraw @s [{"text":"  "},{"text":"\u2726 Objective: ","color":"yellow","bold":true},{"text":"Open the Codex (right-click the book)","color":"white"}]
execute if score @s sm.step matches 3 run tellraw @s [{"text":"  "},{"text":"\u2726 Objective: ","color":"yellow","bold":true},{"text":"Choose your difficulty","color":"white"}]
