# Ch134 Complete — Steel Resolve
data modify storage evercraft:story temp set value {speaker:"The Blade",color:"red",text:"Bloodied, broken, barely standing — and still you won. THAT is steel resolve. When your body screams to surrender and your blade arm refuses to drop, that is the moment you become truly dangerous. Five duels won. The arena bows to your iron will."}
function evercraft:story/narrator/tell with storage evercraft:story temp
