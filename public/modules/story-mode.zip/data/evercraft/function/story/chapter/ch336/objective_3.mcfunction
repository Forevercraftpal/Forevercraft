tellraw @s [{"text":"  "},{"text":"\u2726 Objective: ","color":"yellow","bold":true},{"text":"Activate a sculk shrieker and survive","color":"white"}]
