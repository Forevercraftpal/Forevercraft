# Ch331 Complete — The Stronghold Secret

data modify storage evercraft:story temp set value {speaker:"The Wind",color:"dark_aqua",text:"The stronghold's secret is not what it contains, but what it connects. A bridge between worlds, built by desperate hands."}
function evercraft:story/narrator/tell with storage evercraft:story temp
