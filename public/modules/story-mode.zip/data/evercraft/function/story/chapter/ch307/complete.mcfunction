# Ch307 Complete — The Mushroom Isles

data modify storage evercraft:story temp set value {speaker:"The Wind",color:"dark_aqua",text:"A place of pure peace. Remember it when the world grows dark."}
function evercraft:story/narrator/tell with storage evercraft:story temp
