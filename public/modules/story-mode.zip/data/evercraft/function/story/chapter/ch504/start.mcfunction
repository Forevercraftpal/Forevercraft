# Chapter 504: The Wanderer's Path
# @s = player starting chapter 504

data modify storage evercraft:story temp set value {chapter:"504",color:"blue",name:"The Wanderer's Path"}
function evercraft:story/narrator/chapter_title with storage evercraft:story temp

tellraw @s ""
data modify storage evercraft:story temp set value {speaker:"The Stars",color:"blue",text:"Some say the Wanderer never stopped walking — that their footsteps became rivers and their breath became wind. When they finally looked up, they found themselves written in stars. A dotted line across infinity, pointing always forward."}
function evercraft:story/narrator/tell with storage evercraft:story temp

scoreboard players set @s sm.step 1
scoreboard players set @s sm.quest_prog 0
scoreboard players set @s sm.quest_goal 3
scoreboard players set @s sm.quest_type 1

tellraw @s ""
tellraw @s [{"text":"  "},{"text":"✦ Objective: ","color":"yellow","bold":true},{"text":"Identify the Wanderer constellation at night","color":"white"}]
playsound minecraft:block.note_block.chime master @s ~ ~ ~ 0.5 1.4
