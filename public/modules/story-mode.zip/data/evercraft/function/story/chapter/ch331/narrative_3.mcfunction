# Ch331 Narrative 3

data modify storage evercraft:story temp set value {speaker:"The Wind",color:"dark_aqua",text:"The portal frames are arranged in a circle, oriented to something beyond our dimension."}
function evercraft:story/narrator/tell with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"The builders did not just study the End — they NEEDED it."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
