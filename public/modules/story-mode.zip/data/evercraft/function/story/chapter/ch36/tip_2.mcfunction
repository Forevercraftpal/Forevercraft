# Ch36 Step 2 Tip: Complete a heist
tellraw @s [{"text":"  "},{"text":"Tip: ","color":"aqua","bold":true},{"text":"Heists require stealth and speed — scout the layout first and plan an escape route before you begin.","color":"gray","italic":true}]
