# Ch330 Narrative 3

data modify storage evercraft:story temp set value {speaker:"The Wind",color:"dark_aqua",text:"A puzzle of levers guards the deepest chamber."}
function evercraft:story/narrator/tell with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"The builders did not want brutes to find their secrets — only the clever."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
