tellraw @s [{"text":"  "},{"text":"✦ Objective: ","color":"yellow","bold":true},{"text":"Identify the Wanderer constellation at night","color":"white"}]
