# Chapter 1: First Light — "A New Beginning"
# @s = player starting chapter 1
# This chapter replaces the old tutorial — teaches core mechanics through story

# Title card
data modify storage evercraft:story temp set value {chapter:"1",color:"gold",name:"First Light"}
function evercraft:story/narrator/chapter_title with storage evercraft:story temp

# Narrator intro
tellraw @s ""
data modify storage evercraft:story temp set value {speaker:"The Land",color:"gold",text:"You step onto unfamiliar ground. The air hums with something ancient \u2014 something waiting."}
function evercraft:story/narrator/tell with storage evercraft:story temp
tellraw @s ""

# Path-specific flavor that teaches DR/CR
execute if score @s sm.path matches 1 run tellraw @s [{"text":"  "},{"text":"Your sword arm itches. Adventure calls.","color":"gray","italic":true}]
execute if score @s sm.path matches 1 run tellraw @s [{"text":"  "},{"text":"As you fight, explore, and discover, your ","color":"gray","italic":true},{"text":"Dream Rate","color":"light_purple","italic":true},{"text":" will grow \u2014 the land's measure of your courage.","color":"gray","italic":true}]

execute if score @s sm.path matches 2 run tellraw @s [{"text":"  "},{"text":"Your hands ache to build something new.","color":"gray","italic":true}]
execute if score @s sm.path matches 2 run tellraw @s [{"text":"  "},{"text":"As you craft, cook, and gather, your ","color":"gray","italic":true},{"text":"Craft Rate","color":"aqua","italic":true},{"text":" will grow \u2014 the land's measure of your skill.","color":"gray","italic":true}]

execute if score @s sm.path matches 3 run tellraw @s [{"text":"  "},{"text":"Both blade and hammer will find their purpose here.","color":"gray","italic":true}]
execute if score @s sm.path matches 3 run tellraw @s [{"text":"  "},{"text":"Your ","color":"gray","italic":true},{"text":"Dream Rate","color":"light_purple","italic":true},{"text":" grows through combat and discovery. Your ","color":"gray","italic":true},{"text":"Craft Rate","color":"aqua","italic":true},{"text":" grows through crafting and gathering.","color":"gray","italic":true}]
execute if score @s sm.path matches 3 run tellraw @s [{"text":"  "},{"text":"Together, they shape how the world responds to you.","color":"gray","italic":true}]

# Quest setup: step 1 = craft an iron pickaxe
scoreboard players set @s sm.step 1
scoreboard players set @s sm.quest_prog 0

# Show objective
tellraw @s ""
tellraw @s [{"text":"  "},{"text":"\u2726 Objective: ","color":"yellow","bold":true},{"text":"Craft an Iron Pickaxe","color":"white"}]
tellraw @s [{"text":"  "},{"text":"This is your first step. Iron unlocks the Codex \u2014 your guide to everything.","color":"dark_gray","italic":true}]
playsound minecraft:block.note_block.chime master @s ~ ~ ~ 0.5 1.4

# Quest description (Audit #2 2026-05-28 W4.1 Cluster A — Council #1 P1-4 wave)
schedule function evercraft:story/chapter/ch1/quest_desc 40t replace
