# Ch7 Step 1 Objective
tellraw @s [{"text":"  "},{"text":"\u2726 Objective: ","color":"yellow","bold":true},{"text":"Find a structure in the wild","color":"white"}]
