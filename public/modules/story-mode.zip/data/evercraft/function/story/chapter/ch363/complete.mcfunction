# Ch363 Complete

data modify storage evercraft:story temp set value {speaker:"The Wind",color:"dark_aqua",text:"The geode documented. Crystal caves are the underground's cathedrals — silent, luminous, humming with frequencies older than stone."}
function evercraft:story/narrator/tell with storage evercraft:story temp
