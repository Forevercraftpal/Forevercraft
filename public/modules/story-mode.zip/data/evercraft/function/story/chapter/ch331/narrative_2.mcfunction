# Ch331 Narrative 2

data modify storage evercraft:story temp set value {speaker:"The Wind",color:"dark_aqua",text:"The library holds books that no one wrote."}
function evercraft:story/narrator/tell with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"The stronghold was not a fortress — it was a research facility."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
