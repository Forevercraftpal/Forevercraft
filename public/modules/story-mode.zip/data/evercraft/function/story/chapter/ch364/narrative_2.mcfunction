# Ch364 Narrative 2

data modify storage evercraft:story temp set value {speaker:"The Wind",color:"dark_aqua",text:"The aquifer system connects caves that surface maps show as separate."}
function evercraft:story/narrator/tell with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"Underground, the world is one continuous, water-linked network."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
