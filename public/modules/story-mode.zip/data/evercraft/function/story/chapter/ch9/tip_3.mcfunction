# Ch9 Step 3 Tip: Place 10 Decorative Blocks
tellraw @s [{"text":"  "},{"text":"Tip: ","color":"aqua","bold":true},{"text":"Decorative blocks include flower pots, paintings, banners, and lanterns. Place them around your camp or home to make it feel lived-in and earn comfort points.","color":"gray","italic":true}]
