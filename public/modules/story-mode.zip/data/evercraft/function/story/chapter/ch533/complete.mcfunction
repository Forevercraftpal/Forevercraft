# Ch533 Complete

data modify storage evercraft:story temp set value {speaker:"The Stars",color:"blue",text:"Mob origins understood. The world's creatures are employees of a grand design — each with a role, a purpose, and a reason for existing exactly as they do."}
function evercraft:story/narrator/tell with storage evercraft:story temp
