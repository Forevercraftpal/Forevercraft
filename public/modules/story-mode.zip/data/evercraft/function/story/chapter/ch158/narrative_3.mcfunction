# Ch158 Narrative 3
data modify storage evercraft:story temp set value {speaker:"The Blade",color:"red",text:"Floor ninety breached."}
function evercraft:story/narrator/tell with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"One hundred and forty total floors conquered."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"The Eternal Throne awaits ten floors below."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"This is the pre-finale — everything has led to what comes next."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
