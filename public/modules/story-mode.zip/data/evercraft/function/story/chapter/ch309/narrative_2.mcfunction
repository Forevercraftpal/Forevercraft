# Ch309 Narrative 2

data modify storage evercraft:story temp set value {speaker:"The Wind",color:"dark_aqua",text:"Wolves roam in packs here."}
function evercraft:story/narrator/tell with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"They are not enemies — they are neighbors."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"Respect their territory and they will respect yours."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
