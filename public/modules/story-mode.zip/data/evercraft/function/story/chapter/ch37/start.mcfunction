# Chapter 37: Hearts & Swords — DR/CR 36→37
data modify storage evercraft:story temp set value {chapter:"37",color:"light_purple",name:"Hearts & Swords"}
function evercraft:story/narrator/chapter_title with storage evercraft:story temp

tellraw @s ""
data modify storage evercraft:story temp set value {speaker:"The Land",color:"gold",text:"Love is a weapon The Hollow cannot wield."}
function evercraft:story/narrator/tell with storage evercraft:story temp

execute if score @s sm.path matches 1 run tellraw @s [{"text":"  "},{"text":"Five duel modes test your combat mastery. Marriage bonds grant shared strength.","color":"gray","italic":true}]
execute if score @s sm.path matches 2 run tellraw @s [{"text":"  "},{"text":"Marriage buffs and diplomatic bonds strengthen the civilization.","color":"gray","italic":true}]
execute if score @s sm.path matches 3 run tellraw @s [{"text":"  "},{"text":"Duel for honor. Bond for love. Both make the realm stronger.","color":"gray","italic":true}]

scoreboard players set @s sm.step 1
scoreboard players set @s sm.quest_prog 0
scoreboard players set @s sm.quest_goal 3
scoreboard players set @s sm.quest_type 1

tellraw @s ""
execute if score @s sm.path matches 1 run tellraw @s [{"text":"  "},{"text":"✦ Objective: ","color":"yellow","bold":true},{"text":"Win a Duel against another player.","color":"white"}]
execute if score @s sm.path matches 2 run tellraw @s [{"text":"  "},{"text":"✦ Objective: ","color":"yellow","bold":true},{"text":"Get married (requires Best Friend — 90+ hearts).","color":"white"}]
execute if score @s sm.path matches 3 run tellraw @s [{"text":"  "},{"text":"✦ Objective: ","color":"yellow","bold":true},{"text":"Win a Duel against another player.","color":"white"}]
playsound minecraft:block.note_block.chime master @s ~ ~ ~ 0.5 1.4
