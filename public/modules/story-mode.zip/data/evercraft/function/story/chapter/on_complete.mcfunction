# Universal Chapter Completion
# @s = player who just completed all quest steps (step=4)

# Main quest: increment chapters_done (side chapters use sm.side_done instead)
execute if score @s sm.branch matches 0 run scoreboard players add @s sm.chapters_done 1

# Update showcase visuals (main quest only — side branches don't affect title/aura)
execute if score @s sm.branch matches 0 run function evercraft:story/showcase/update_title
execute if score @s sm.branch matches 0 run function evercraft:story/showcase/update_aura

# Check if this chapter unlocks a new branch (only main quest milestones unlock branches)
execute if score @s sm.branch matches 0 run function evercraft:story/branch/check_unlock

# Celebration effects
playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 1.0 1.0
playsound minecraft:entity.firework_rocket.twinkle master @s ~ ~ ~ 0.6 1.2

# Dispatch to chapter-specific complete function (ALL chapters — main + side branches)
execute store result storage evercraft:story temp.chapter int 1 run scoreboard players get @s sm.chapter
function evercraft:story/chapter/complete_macro with storage evercraft:story temp

# Completion notification
tellraw @s [{"text":"\u2726 ","color":"gold"},{"text":"Chapter Complete!","color":"yellow","bold":true}]

# === CHAPTER REWARDS (difficulty-scaled) ===
# Pioneer mode gets nothing, Adventurer gets 50%, Newcomer gets 100%
# Skip-flow gate: when sm.skipping tag is present, the calling skip.mcfunction
# dispatches the reward itself (partial on first-run skip, full on replay skip).
# This avoids on_complete double-paying when invoked from the skip path.
execute if score @s ec.difficulty matches 3 run tellraw @s [{"text":"  "},{"text":"Pioneer mode \u2014 rewards skipped. The journey is its own reward.","color":"gray","italic":true}]
execute unless score @s ec.difficulty matches 3 unless entity @s[tag=sm.skipping] run function evercraft:story/rewards/grant

# === CROSS-SYSTEM INTEGRATIONS ===
# News tracking (same pattern as quest completions)
scoreboard players add #news_quests ec.var 1

# Guild contribution (tier-scaled, same as quests — only if in a guild)
execute unless entity @s[tag=sm.skipping] if score @s ec.guild_id matches 1.. unless score @s ec.difficulty matches 3 run function evercraft:story/rewards/guild_contrib

# Reaper deeds (not for Pioneer)
execute unless entity @s[tag=sm.skipping] unless score @s ec.difficulty matches 3 run function evercraft:story/rewards/reaper_deed

# Realm milestone increment removed 2026-05-25 — #rm_story_chapters counter was orphaned (never read)

# Journey log entry
# Skip-path gate (2026-05-28 polish): skipped chapters don't get a journal entry.
execute unless entity @s[tag=sm.skipping] run function evercraft:story/rewards/journal_entry

# Daily first-chapter bonus — +50 XP (story-specific, D3 split 2026-05-28: ec.daily_story is independent from quest system's ec.daily_quest)
execute unless entity @s[tag=sm.skipping] unless score @s ec.difficulty matches 3 if score @s ec.daily_story matches 0 run experience add @s 50 points
execute unless entity @s[tag=sm.skipping] unless score @s ec.difficulty matches 3 if score @s ec.daily_story matches 0 run tellraw @s [{"text":"  \u2605 ","color":"yellow"},{"text":"Daily Bonus! +50 XP","color":"green"}]
execute unless entity @s[tag=sm.skipping] if score @s ec.daily_story matches 0 run scoreboard players set @s ec.daily_story 1

# Live worldmap refresh \u2014 if the player is currently viewing the worldmap (section 22 story-landing
# or section 23 standalone worldmap) AND is on the overview page (gui_page=1), rebuild the overview
# so the new chapter / branch-unlock state is reflected without requiring a menu reopen.
execute if entity @s[tag=Adv.InMenu] if score @s adv.gui_page matches 1 if score @s adv.gui_section matches 22 at @s facing entity @e[type=marker,tag=Adv.MenuAnchor,distance=..5,limit=1,sort=nearest] feet run function evercraft:codex/hub/worldmap/refresh_overview
execute if entity @s[tag=Adv.InMenu] if score @s adv.gui_page matches 1 if score @s adv.gui_section matches 23 at @s facing entity @e[type=marker,tag=Adv.MenuAnchor,distance=..5,limit=1,sort=nearest] feet run function evercraft:codex/hub/worldmap/refresh_overview
