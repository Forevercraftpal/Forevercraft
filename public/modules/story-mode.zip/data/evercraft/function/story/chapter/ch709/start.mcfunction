# Chapter 709: Rift Echo - Start
# Branch 7: Seasonal Chronicles

scoreboard players set @s ec.story.ch709 1

data modify storage evercraft:story temp set value {chapter:"709",color:"#8BC34A",name:"Rift Echo"}
function evercraft:story/narrator/chapter_title with storage evercraft:story temp

tellraw @s ""
data modify storage evercraft:story temp set value {speaker:"The Seasons",color:"#BA68C8",text:"Reality cracks. Not breaking — echoing. The dimensions press against each other like pages in a book, and where they touch, the Rift Echo sounds."}
function evercraft:story/narrator/tell with storage evercraft:story temp

data modify storage evercraft:story temp set value {speaker:"The Seasons",color:"#BA68C8",text:"This is the strangest event on the calendar. For a brief window, other worlds bleed through. You can hear their whispers, see their shadows."}
function evercraft:story/narrator/tell with storage evercraft:story temp

data modify storage evercraft:story temp set value {speaker:"The Seasons",color:"#8BC34A",text:"The forevercraft:seasonal_clock stutters during the Rift Echo. Even time is uncertain which world it belongs to."}
function evercraft:story/narrator/tell with storage evercraft:story temp

function evercraft:story/chapter/ch709/step2
