# Ch102 Narrative 3
data modify storage evercraft:story temp set value {speaker:"The Blade",color:"red",text:"Ten down at range — clean work."}
function evercraft:story/narrator/tell with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"But the Voidpiercer demands more than mere accuracy. It craves perfection."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"Fifteen critical strikes, each one a bolt that finds the seam between armor and flesh. Pierce the void, hunter."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp

swing @s mainhand
