# Ch105 Narrative 3
data modify storage evercraft:story temp set value {speaker:"The Blade",color:"red",text:"Fifteen fall to the twin edge."}
function evercraft:story/narrator/tell with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"But Nite demands more — master Cross Slash, the signature technique."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"Both blades cross in an X that carves through armor like parchment. Ten times, warrior."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"Make them fear the crossing."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
