# Chapter 133: Reading the Opponent
# @s = player starting chapter 133

data modify storage evercraft:story temp set value {chapter:"133",color:"red",name:"Reading the Opponent"}
function evercraft:story/narrator/chapter_title with storage evercraft:story temp

tellraw @s ""
data modify storage evercraft:story temp set value {speaker:"The Blade",color:"red",text:"Brute force wins fights. But reading your opponent — seeing the feint before the strike, the hesitation before the retreat — that wins wars. A true duelist does not merely react. A true duelist predicts. Show me you can win without suffering a single wound."}
function evercraft:story/narrator/tell with storage evercraft:story temp

scoreboard players set @s sm.step 1
scoreboard players set @s sm.quest_prog 0
scoreboard players set @s sm.quest_goal 3
scoreboard players set @s sm.quest_type 1

tellraw @s ""
tellraw @s [{"text":"  "},{"text":"\u2726 Objective: ","color":"yellow","bold":true},{"text":"Enter a duel","color":"white"}]
playsound minecraft:block.note_block.chime master @s ~ ~ ~ 0.5 1.4
