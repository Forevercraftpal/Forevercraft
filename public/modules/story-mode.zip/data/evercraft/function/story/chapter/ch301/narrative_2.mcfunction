# Ch301 Narrative 2

data modify storage evercraft:story temp set value {speaker:"The Wind",color:"dark_aqua",text:"Three biomes explored!"}
function evercraft:story/narrator/tell with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"The world opens like a flower before you."}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
data modify storage evercraft:story temp set value {text:"Each land has its own voice — can you hear them?"}
function evercraft:story/narrator/tell_cont with storage evercraft:story temp
