# Route to correct chapter start function via macro
# @s = player starting a chapter

execute store result storage evercraft:story temp.chapter int 1 run scoreboard players get @s sm.chapter
function evercraft:story/chapter/start_macro with storage evercraft:story temp
