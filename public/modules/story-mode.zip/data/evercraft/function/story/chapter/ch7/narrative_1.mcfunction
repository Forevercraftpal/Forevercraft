# Ch7 Narrative — Chapter just started, first objective
# No extra narrative — start.mcfunction already has the chapter intro
