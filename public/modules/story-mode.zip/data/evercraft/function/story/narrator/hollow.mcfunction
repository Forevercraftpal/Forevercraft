# The Hollow Speaks — Dark narrator with warden heartbeat + particles
# Called with: {text:"Dialog here"}
# Preceded by effects, followed by scheduled delay for dramatic pacing
playsound minecraft:entity.warden.heartbeat master @s ~ ~ ~ 0.6 0.8
particle minecraft:sculk_soul ~ ~1 ~ 0.5 0.5 0.5 0.02 8
$tellraw @s [{"text":"  "},{"text":"\u2726 The Hollow","color":"dark_red","bold":true},{"text":" \u2014 ","color":"dark_gray"},{"text":"$(text)","color":"dark_red","italic":true}]
