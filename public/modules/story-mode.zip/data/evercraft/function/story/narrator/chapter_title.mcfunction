# Chapter Title Card — Displays title + subtitle with fanfare
# Called with: {chapter:"1", color:"gold", name:"First Light"}
title @s times 10 60 20
$title @s title {"text":"Chapter $(chapter)","color":"$(color)"}
$title @s subtitle {"text":"$(name)","color":"white","italic":true}
playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 0.8 1.0
