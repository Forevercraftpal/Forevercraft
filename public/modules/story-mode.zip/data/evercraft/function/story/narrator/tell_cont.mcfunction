# Narrator continuation line — a follow-on frame of a split multi-line story beat (NO speaker prefix).
# The first line of a beat uses narrator/tell (shows "Speaker — text"); subsequent lines use this so
# the prose flows line-by-line on the action bar without repeating the speaker every frame.
# Called with: {text:"..."} on storage evercraft:story temp.
$data modify storage evercraft:notify stage.c set value [{text:"  "},{text:"$(text)",color:"white",italic:true}]
scoreboard players set #ndur ec.temp 70
function evercraft:util/notify/emit
