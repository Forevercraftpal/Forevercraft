# Narrator Utility — Delivers story dialogue to the action-bar queue (sequential, line-by-line)
# Called with: {speaker:"Name", color:"gold", text:"Dialog here"}
# Was a chat tellraw; now stages one action-bar frame and enqueues it via the notify queue.
# For long beats, the narrative_N caller is split into multiple `tell` calls so each line
# becomes its own sequenced frame (the "line-by-line, natural flow" pacing).
$data modify storage evercraft:notify stage.c set value [{text:"  "},{text:"$(speaker)",color:"$(color)",bold:true},{text:" — ",color:"dark_gray"},{text:"$(text)",color:"white",italic:true}]
scoreboard players set #ndur ec.temp 70
# Story dialogue is IMPORTANT/read-once-fully -> protected from backlog compression (Joseph 2026-06-06).
function evercraft:util/notify/emit_keep
