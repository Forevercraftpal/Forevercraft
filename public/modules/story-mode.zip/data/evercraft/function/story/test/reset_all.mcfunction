# Reset ALL first-join state for testing the consolidated flow
# Resets: difficulty, story mode, tutorial, and re-prompts

scoreboard players set @s ec.difficulty 0
scoreboard players set @s sm.mode 0
scoreboard players set @s sm.path 0
scoreboard players set @s sm.act 0
scoreboard players set @s sm.chapter 0
scoreboard players set @s sm.step 0
scoreboard players set @s sm.quest_prog 0
scoreboard players set @s sm.chapters_done 0
scoreboard players set @s sm.conv_done 0
scoreboard players set @s sm.showcase_act 0
# ec.tutorial_path + ec.tutorial_step dropped 2026-05-28 (Council #15) — tutorial UI retired.
scoreboard players set @s ec.tutorial_done 0
tag @s remove ec.spirit_chosen

# Re-enable triggers so buttons work without rejoining
scoreboard players enable @s sm.pick
scoreboard players enable @s ec.diff_trigger
scoreboard players enable @s sm.path_pick

tellraw @s [{"text":"[Story] ","color":"gold"},{"text":"Full reset complete.","color":"white"}]
playsound minecraft:block.note_block.hat master @s ~ ~ ~ 0.5 1.6

# Start the consolidated flow: Story → Difficulty → Chronicle (tutorial retired 2026-05-28)
function evercraft:story/mode/choose
