# Admin Test — Full story mode reset
# Usage: /function evercraft:story/test/reset_story

scoreboard players set @s sm.mode 0
scoreboard players set @s sm.path 0
scoreboard players set @s sm.act 0
scoreboard players set @s sm.chapter 0
scoreboard players set @s sm.step 0
scoreboard players set @s sm.quest_prog 0
scoreboard players set @s sm.quest_goal 0
scoreboard players set @s sm.quest_type 0
scoreboard players set @s sm.chapters_done 0
scoreboard players set @s sm.conv_done 0
scoreboard players set @s sm.showcase_act 0
scoreboard players set @s sm.tip_offered 0

tellraw @s [{"text":"[Test] ","color":"red"},{"text":"Story mode fully reset. Use ","color":"gray"},{"text":"/trigger sm.pick set 1","color":"yellow","click_event":{"action":"suggest_command","command":"/trigger sm.pick set 1"}},{"text":" to restart.","color":"gray"}]
