# Admin Test — Force player to specific chapter
# Usage: /function evercraft:story/test/set_chapter {ch:15}
$scoreboard players set @s sm.chapter $(ch)
scoreboard players set @s sm.step 0
scoreboard players set @s sm.quest_prog 0

# Recalculate act: act = (chapter - 1) / 10 + 1
scoreboard players operation @s sm.act = @s sm.chapter
scoreboard players remove @s sm.act 1
scoreboard players operation @s sm.act /= #10 ec.const
scoreboard players add @s sm.act 1

# Ensure story mode is active
execute unless score @s sm.mode matches 1 run scoreboard players set @s sm.mode 1

# Dispatch chapter start
function evercraft:story/chapter/dispatch_start

tellraw @s [{"text":"[Test] ","color":"red"},{"text":"Set to Chapter ","color":"gray"},{"score":{"name":"@s","objective":"sm.chapter"},"color":"gold"},{"text":" (Act ","color":"gray"},{"score":{"name":"@s","objective":"sm.act"},"color":"gold"},{"text":")","color":"gray"}]
