# Admin Test — Force-complete current chapter
# Usage: /function evercraft:story/test/complete_chapter

tellraw @s [{"text":"[Test] ","color":"red"},{"text":"Force-completing Chapter ","color":"gray"},{"score":{"name":"@s","objective":"sm.chapter"},"color":"gold"}]

scoreboard players set @s sm.step 4
function evercraft:story/chapter/on_complete
