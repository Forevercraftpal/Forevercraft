# Admin Test — Trigger convergence scene for a specific chapter
# Usage: /function evercraft:story/test/test_convergence {ch:10}
$tellraw @s [{"text":"[Test] ","color":"red"},{"text":"Testing convergence for Chapter $(ch)","color":"gray"}]
$function evercraft:story/chapter/ch$(ch)/convergence
