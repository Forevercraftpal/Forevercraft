# ============================================================
# Bait — pre-roll bias staging (offhand consumable)
# Called from evercraft:fishing/ref/on_catch BEFORE the spirit + aquatic rolls.
# Run as @s = the player who just landed a catch.
#
# Stages two bias temps on ec.temp that the respective try_catch rolls subtract
# from their 1..1000 roll (lower roll = lands in the rarer low-numbered bands):
#   #sf_bias  -> Spirit Brine raises spirit-fish odds   (spirit_fish/try_catch)
#   #af_bias  -> Glimmer Roe raises aquatic/better-fish  (aquatic_fish/try_catch)
#
# Because this runs in the on-catch handler, the catch has ALREADY landed — so a
# held bait is consumed here (one per matching bait), matching the consumable
# model: bait present + catch landed -> bias applied + one bait consumed.
#
# Tag-gate-once pattern (mirrors the rod procs in check_crate): probe the offhand a
# single time into a tag, then drive bias + feedback + consume off the tag. This way
# the feedback never gets skipped when consuming the last item empties the offhand.
# Item-gated: a player holding no bait pays only the two `if items` probes.
# ============================================================

# Reset both temps every catch (temps are shared #fakeplayer slots on ec.temp).
scoreboard players set #sf_bias ec.temp 0
scoreboard players set #af_bias ec.temp 0

# --- Spirit Brine: +120 bias on the 1..1000 spirit roll (~doubles the ~2.5% band) ---
execute if items entity @s weapon.offhand *[custom_data~{bait:"spirit_brine"}] run tag @s add ec._brine
execute if entity @s[tag=ec._brine] run scoreboard players set #sf_bias ec.temp 120
data modify storage evercraft:notify stage.c set value [{text:"The spirit brine stirs— the deep listens.",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 45
execute if entity @s[tag=ec._brine] run function evercraft:util/notify/emit
execute if entity @s[tag=ec._brine] if score @s ec.fx_snd matches 1.. run playsound minecraft:block.amethyst_block.resonate master @s ~ ~ ~ 0.5 0.8
execute if entity @s[tag=ec._brine] run function evercraft:fishing/bait/consume_offhand
tag @s remove ec._brine

# --- Glimmer Roe: +120 bias on the 1..1000 aquatic roll (raises the rarer-fish bands) ---
execute if items entity @s weapon.offhand *[custom_data~{bait:"glimmer_roe"}] run tag @s add ec._roe
execute if entity @s[tag=ec._roe] run scoreboard players set #af_bias ec.temp 120
data modify storage evercraft:notify stage.c set value [{text:"The glimmer roe shimmers— brighter scales gather.",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 45
execute if entity @s[tag=ec._roe] run function evercraft:util/notify/emit
execute if entity @s[tag=ec._roe] if score @s ec.fx_snd matches 1.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.5 1.4
execute if entity @s[tag=ec._roe] run function evercraft:fishing/bait/consume_offhand
tag @s remove ec._roe
