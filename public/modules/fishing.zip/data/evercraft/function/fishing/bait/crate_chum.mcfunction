# ============================================================
# Bait — Crate Chum (offhand consumable)
# Called from evercraft:fishing/ref/on_catch in the crate-roll cluster.
# Run as @s = the player who just landed a catch.
#
# Effect: one EXTRA crate roll when Crate Chum is held, exactly mirroring the
# lapis-trim / charm / derby extra-`check_crate` precedents already in on_catch.
# This biases the crate-DROP chance pre-outcome (the roll itself lives inside
# check_crate / roll_crate_direct). Then consume one chum + give feedback.
#
# Item-gated: a non-holder pays only the single `if items` probe.
# ============================================================

# Tag-gate once, then reuse the tag (matches the rod-proc pattern in check_crate).
execute if items entity @s weapon.offhand *[custom_data~{bait:"crate_chum"}] run tag @s add ec._chum

# Extra crate roll (the bias) — same lever as the existing extra-roll bonuses.
execute if entity @s[tag=ec._chum] run function evercraft:fishing/ref/check_crate

# Consume one chum + feedback.
execute if entity @s[tag=ec._chum] run function evercraft:fishing/bait/consume_offhand
data modify storage evercraft:notify stage.c set value [{text:"The chum clouds the water— crates rise from the deep.",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 45
execute if entity @s[tag=ec._chum] run function evercraft:util/notify/emit
execute if entity @s[tag=ec._chum] if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.fishing_bobber.splash master @s ~ ~ ~ 0.7 0.8

tag @s remove ec._chum
