# Give one stack-seed of each Fisher's Path bait (admin / testing fixture).
# Run as: operator, as the target player (e.g. /execute as @p run function ...).
# Player-facing source is the crafting recipes under recipe/fishing/bait/; this is
# only the admin give path.
loot give @s loot evercraft:fishing/bait/glimmer_roe
loot give @s loot evercraft:fishing/bait/crate_chum
loot give @s loot evercraft:fishing/bait/spirit_brine
loot give @s loot evercraft:fishing/bait/magma_roe
loot give @s loot evercraft:fishing/bait/bark_grub
tellraw @s [{text:"[Bait] ",color:"aqua"},{text:"Granted one of each Fisher's Path bait.",color:"gray",italic:true}]
