# ============================================================
# Bait — Magma Roe (offhand consumable, nether lava-node booster)
# Called from evercraft:fishing/splash_nodes/do_catch, ALREADY gated on #spl_dim 2..
# (nether lava node). Run as + at @s = the player who clicked the node.
#
# Effect: a bonus nether-themed catch + an extra splash crate roll when Magma Roe is
# held at a lava node, then consume one roe. The base node catch is already awarded by
# do_catch before this runs, so bait never gates the catch. Item-gated: a non-holder
# pays only the single `if items` probe.
# ============================================================

execute if items entity @s weapon.offhand *[custom_data~{bait:"magma_roe"}] run tag @s add ec._magmaroe

# Re-read inventory space (do_catch's #inv_full may be stale after the base grants).
execute if entity @s[tag=ec._magmaroe] store result score #inv_full ec.var run function evercraft:util/check_inv_full

# Bonus nether catch.
execute if entity @s[tag=ec._magmaroe] if score #inv_full ec.var matches 0 run loot give @s loot evercraft:fishing/splash_nodes/catch_nether
execute if entity @s[tag=ec._magmaroe] if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:fishing/splash_nodes/catch_nether

# Extra splash crate roll (the always-fires splash crate table).
execute if entity @s[tag=ec._magmaroe] if score #inv_full ec.var matches 0 run loot give @s loot evercraft:fishing/splash_nodes/crate
execute if entity @s[tag=ec._magmaroe] if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:fishing/splash_nodes/crate

# Consume one roe + feedback.
execute if entity @s[tag=ec._magmaroe] run function evercraft:fishing/bait/consume_offhand
data modify storage evercraft:notify stage.c set value [{text:"The magma roe smolders— the molten depths churn up more.",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 45
execute if entity @s[tag=ec._magmaroe] run function evercraft:util/notify/emit
execute if entity @s[tag=ec._magmaroe] if score @s ec.fx_snd matches 1.. run playsound minecraft:block.lava.extinguish master @s ~ ~ ~ 0.8 1.0

tag @s remove ec._magmaroe
