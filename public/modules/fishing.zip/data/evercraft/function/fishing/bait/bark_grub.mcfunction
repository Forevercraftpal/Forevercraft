# ============================================================
# Bait — Bark Grub (generic offhand consumable)
# Called from evercraft:fishing/ref/on_catch alongside the other bait hooks.
# Run as + at @s = the player who just landed a catch.
#
# Effect: one EXTRA aquatic-fish roll when Bark Grub is held — a second independent
# chance at a fish catch, mirroring the multi-bonus fishing model (the base aquatic
# roll already fired in on_catch). "Fish strike harder for it." Then consume one grub.
#
# Tag-gate-once pattern (mirrors crate_chum / set_bias): probe the offhand a single
# time into a tag, then drive the bonus + feedback + consume off the tag so the
# feedback never gets skipped when consuming the last grub empties the offhand.
# Item-gated: a non-holder pays only the single `if items` probe.
# ============================================================

execute if items entity @s weapon.offhand *[custom_data~{bait:"bark_grub"}] run tag @s add ec._barkgrub

# Extra aquatic-fish roll (the bias) — a bonus independent fish/reagent chance.
execute if entity @s[tag=ec._barkgrub] at @s run function evercraft:fishing/aquatic_fish/try_catch

# Consume one grub + feedback.
execute if entity @s[tag=ec._barkgrub] run function evercraft:fishing/bait/consume_offhand
data modify storage evercraft:notify stage.c set value [{text:"The bark grub wriggles— fish strike for it.",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 45
execute if entity @s[tag=ec._barkgrub] run function evercraft:util/notify/emit
execute if entity @s[tag=ec._barkgrub] if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.fishing_bobber.splash master @s ~ ~ ~ 0.7 1.1

tag @s remove ec._barkgrub
