# Bait — consume one item from the player's offhand stack.
# Run as @s = the player. Caller must already have confirmed a bait is held.
# Uses the established inline set_count -1 decrement (same as the dye_block /
# laborer consume precedents). Decrement-by-one removes the stack at count 1.
item modify entity @s weapon.offhand {"function":"minecraft:set_count","count":-1,"add":true}
