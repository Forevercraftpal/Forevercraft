# Aquatic Fish catch — Glimmer Trout (T4 reagent, rare, any water)
# Run as + at the player. #inv_full already set by try_catch.
execute if score #inv_full ec.var matches 0 run loot give @s loot evercraft:fishing/aquatic_fish/glimmer_trout
execute if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:fishing/aquatic_fish/glimmer_trout
data modify storage evercraft:notify stage.c set value [{text:"Light scatters off its scales— you reeled up a ",color:"gray"},{text:"Glimmer Trout",color:"#FFD27F",bold:true},{text:"!",color:"gray"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.5 1.4
function evercraft:craft_affinity/grant {class_id:5, delta:15}
# Fisher's Questline — catch_aquatic hook (gated; no-op unless active questline).
execute if score @s ec.fq_active matches 1 run function evercraft:fishing/questline/on_aquatic_hook {fish_type:"glimmer_trout"}
