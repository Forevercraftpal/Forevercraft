# Aquatic Fish catch — Coppergill Bass (T3 reagent, uncommon, any water)
# Run as + at the player. #inv_full already set by try_catch.
execute if score #inv_full ec.var matches 0 run loot give @s loot evercraft:fishing/aquatic_fish/coppergill_bass
execute if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:fishing/aquatic_fish/coppergill_bass
data modify storage evercraft:notify stage.c set value [{text:"Bronze flanks flashing— you reeled up a ",color:"gray"},{text:"Coppergill Bass",color:"#B87333",bold:true},{text:"!",color:"gray"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.fishing_bobber.retrieve master @s ~ ~ ~ 0.6 1.3
function evercraft:craft_affinity/grant {class_id:5, delta:9}
# Fisher's Questline — catch_aquatic hook (gated; no-op unless active questline).
execute if score @s ec.fq_active matches 1 run function evercraft:fishing/questline/on_aquatic_hook {fish_type:"coppergill_bass"}
