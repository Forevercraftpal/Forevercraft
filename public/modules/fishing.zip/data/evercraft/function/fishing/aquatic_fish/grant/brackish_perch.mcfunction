# Aquatic Fish catch — Brackish Perch (T2 reagent, uncommon, any water)
# Run as + at the player. #inv_full already set by try_catch.
execute if score #inv_full ec.var matches 0 run loot give @s loot evercraft:fishing/aquatic_fish/brackish_perch
execute if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:fishing/aquatic_fish/brackish_perch
data modify storage evercraft:notify stage.c set value [{text:"Heavy on the line— you reeled up a ",color:"gray"},{text:"Brackish Perch",color:"#5F9EA0",bold:true},{text:"!",color:"gray"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.fishing_bobber.retrieve master @s ~ ~ ~ 0.6 1.4
function evercraft:craft_affinity/grant {class_id:5, delta:5}
# Fisher's Questline — catch_aquatic hook (gated; no-op unless active questline).
execute if score @s ec.fq_active matches 1 run function evercraft:fishing/questline/on_aquatic_hook {fish_type:"brackish_perch"}
