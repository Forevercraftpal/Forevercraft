# ============================================================
# Aquatic Alchemy — Aquatic Fish fishing catch (Workstream 1)
# Called from evercraft:fishing/ref/on_catch on every successful fishing catch.
# Run as the player, at the player (caller does `at @s`).
#
# Scheme: one roll 1..1000 per catch. Eight Aquatic Fish, checked rarest-first.
# At most ONE fish per catch — each branch `return`s after granting so buckets
# never overlap and we never double-grant. Total aquatic-fish chance per catch
# is 200/1000 = 20% (gates permitting) — a reagent ~every 5 casts.
#
# This roll is INDEPENDENT of the Spirit Fish roll; both may fire on one catch,
# matching the existing multi-bonus fishing model.
#
# Each fish is a tropical_fish carrying custom_data
# {aquatic_fish:true, fish_type:"<id>", alch_mat:"aquatic_t<TIER>"} — the tag
# the later Fusion Funnel alchemy workstream reads. Inv-full guard mirrors
# cooking/spirit_fish/try_catch.
#
#   Emberfin Snapper    1..4    (~0.4%)  warm biomes only (desert/savanna/jungle/badlands) — T6, rarest
#   Frostfin Char       5..12   (~0.8%)  snowy/frozen biomes only — T5
#   Glimmer Trout       13..27  (~1.5%)  any water — T4
#   Mistpike            28..45  (~1.8%)  any water — T3
#   Coppergill Bass     46..70  (~2.5%)  any water — T3
#   Brackish Perch      71..105 (~3.5%)  any water — T2
#   Reedfin Dace        106..145(~4.0%)  any water — T1
#   Silverscale Minnow  146..200(~5.5%)  any water — T1
# ============================================================

execute store result score #af_roll ec.temp run random value 1..1000
# Bait — Glimmer Roe pre-roll bias (set by evercraft:fishing/bait/set_bias before this
# call). Subtracting from the roll pushes it toward the rarer low-numbered bands, raising
# better-fish / aquatic-reagent odds. #af_bias is 0 when no roe was held (no-op).
# Floored at 13 (start of the any-water Glimmer Trout band) so the bias never dumps a
# roll into a biome-locked band (1..12 = warm/frozen only) the player can't satisfy —
# guaranteeing the roe only ever helps, never whiffs a catch in the wrong biome.
scoreboard players operation #af_roll ec.temp -= #af_bias ec.temp
execute if score #af_bias ec.temp matches 1.. if score #af_roll ec.temp matches ..12 run scoreboard players set #af_roll ec.temp 13
execute store result score #inv_full ec.var run function evercraft:util/check_inv_full

# --- Emberfin Snapper (rarest): 1..4, warm biomes (desert OR savanna OR jungle OR badlands) ---
execute if score #af_roll ec.temp matches 1..4 if predicate evercraft:biome/is_desert run function evercraft:fishing/aquatic_fish/grant/emberfin_snapper
execute if score #af_roll ec.temp matches 1..4 if predicate evercraft:biome/is_desert run return 1
execute if score #af_roll ec.temp matches 1..4 if predicate evercraft:biome/is_savanna run function evercraft:fishing/aquatic_fish/grant/emberfin_snapper
execute if score #af_roll ec.temp matches 1..4 if predicate evercraft:biome/is_savanna run return 1
execute if score #af_roll ec.temp matches 1..4 if predicate evercraft:biome/is_jungle run function evercraft:fishing/aquatic_fish/grant/emberfin_snapper
execute if score #af_roll ec.temp matches 1..4 if predicate evercraft:biome/is_jungle run return 1
execute if score #af_roll ec.temp matches 1..4 if predicate evercraft:biome/is_badlands run function evercraft:fishing/aquatic_fish/grant/emberfin_snapper
execute if score #af_roll ec.temp matches 1..4 if predicate evercraft:biome/is_badlands run return 1

# --- Frostfin Char: 5..12, snowy/frozen biomes only ---
execute if score #af_roll ec.temp matches 5..12 if predicate evercraft:craftforever/biome/frozen run function evercraft:fishing/aquatic_fish/grant/frostfin_char
execute if score #af_roll ec.temp matches 5..12 if predicate evercraft:craftforever/biome/frozen run return 1

# --- Glimmer Trout: 13..27, any water ---
execute if score #af_roll ec.temp matches 13..27 run function evercraft:fishing/aquatic_fish/grant/glimmer_trout
execute if score #af_roll ec.temp matches 13..27 run return 1

# --- Mistpike: 28..45, any water ---
execute if score #af_roll ec.temp matches 28..45 run function evercraft:fishing/aquatic_fish/grant/mistpike
execute if score #af_roll ec.temp matches 28..45 run return 1

# --- Coppergill Bass: 46..70, any water ---
execute if score #af_roll ec.temp matches 46..70 run function evercraft:fishing/aquatic_fish/grant/coppergill_bass
execute if score #af_roll ec.temp matches 46..70 run return 1

# --- Brackish Perch: 71..105, any water ---
execute if score #af_roll ec.temp matches 71..105 run function evercraft:fishing/aquatic_fish/grant/brackish_perch
execute if score #af_roll ec.temp matches 71..105 run return 1

# --- Reedfin Dace: 106..145, any water ---
execute if score #af_roll ec.temp matches 106..145 run function evercraft:fishing/aquatic_fish/grant/reedfin_dace
execute if score #af_roll ec.temp matches 106..145 run return 1

# --- Silverscale Minnow: 146..200, any water ---
execute if score #af_roll ec.temp matches 146..200 run function evercraft:fishing/aquatic_fish/grant/silverscale_minnow
execute if score #af_roll ec.temp matches 146..200 run return 1

return 0
