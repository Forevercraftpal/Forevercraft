# Aquatic Fish catch — Emberfin Snapper (T6 reagent, rarest, warm biomes)
# Run as + at the player. #inv_full already set by try_catch. Biome-gated in try_catch.
execute if score #inv_full ec.var matches 0 run loot give @s loot evercraft:fishing/aquatic_fish/emberfin_snapper
execute if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:fishing/aquatic_fish/emberfin_snapper
data modify storage evercraft:notify stage.c set value [{text:"Warm to the touch— you reeled up an ",color:"gray"},{text:"Emberfin Snapper",color:"#FF7043",bold:true},{text:"!",color:"gray"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.6 1.8
function evercraft:craft_affinity/grant {class_id:5, delta:32}
# Fisher's Questline — catch_aquatic hook (gated; no-op unless active questline).
execute if score @s ec.fq_active matches 1 run function evercraft:fishing/questline/on_aquatic_hook {fish_type:"emberfin_snapper"}
