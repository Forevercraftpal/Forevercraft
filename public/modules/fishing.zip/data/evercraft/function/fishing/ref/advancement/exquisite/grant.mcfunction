# Grant Exquisite Fishing Crate (Dream Rate >= 10 verified)
function evercraft:util/notify/whoami
data modify storage evercraft:notify stage.c set value [{text:"⚡ ",color:"gold"},{text:"",color:"yellow"},{text:" has discovered an ",color:"gold"},{text:"EXQUISITE",color:"gold"},{text:" crate! ⚡",color:"gold"}]
data modify storage evercraft:notify stage.c[1].text set from storage evercraft:notify named.who
scoreboard players set #ndur ec.temp 50
execute as @a run scoreboard players set #nttl ec.temp 600
execute as @a run function evercraft:util/notify/emit_keep
# (AB-1 sticky-times sweep 2026-06-10: explicit stamp — `title times` is sticky per player and this sequence set none, so it inherited whatever ran last.)
title @s times 10 60 20
title @s subtitle {text:"You found an EXQUISITE crate!",color:"gold"}
title @s title {text:"⚡",color:"gold"}
execute as @a if score @s ec.fx_snd matches 1.. at @s run playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 2 1 1

scoreboard players add crates_fished fc.global_stats 1
scoreboard players add @s fc.total_crates 1
scoreboard players add exquisite_crates fc.global_stats 1
scoreboard players add @s fc.exquisite 1

# Competition: Fishing Derby+ (type 6) rarity-weighted crate bonus (Wave 3a). exquisite = +8.
# Scored at the GRANT point — a downgrade cascades into ornate/grant|downgrade, which score there.
execute if score #comp_active ec.var matches 6 run function evercraft:competition/score/fish_crate {w:8}

# Check inventory space
execute store result score #inv_full ec.var run function evercraft:util/check_inv_full

execute if score #inv_full ec.var matches 0 run loot give @s loot evercraft:fishing/gameplay/fishing/crates/exquisite/1
execute if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:fishing/gameplay/fishing/crates/exquisite/1
# Luck of the Sea bonus: extra crate roll (+0.5% per level, max +2.5% at LotS 5)
execute if predicate evercraft:fishing/enchantments/luck_of_the_sea_5 if predicate {"condition":"minecraft:random_chance","chance":0.025} if score #inv_full ec.var matches 0 run loot give @s loot evercraft:fishing/gameplay/fishing/crates/exquisite/1
execute if predicate evercraft:fishing/enchantments/luck_of_the_sea_5 if predicate {"condition":"minecraft:random_chance","chance":0.025} if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:fishing/gameplay/fishing/crates/exquisite/1
execute unless predicate evercraft:fishing/enchantments/luck_of_the_sea_5 if predicate evercraft:fishing/enchantments/luck_of_the_sea_4 if predicate {"condition":"minecraft:random_chance","chance":0.02} if score #inv_full ec.var matches 0 run loot give @s loot evercraft:fishing/gameplay/fishing/crates/exquisite/1
execute unless predicate evercraft:fishing/enchantments/luck_of_the_sea_5 if predicate evercraft:fishing/enchantments/luck_of_the_sea_4 if predicate {"condition":"minecraft:random_chance","chance":0.02} if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:fishing/gameplay/fishing/crates/exquisite/1
execute unless predicate evercraft:fishing/enchantments/luck_of_the_sea_4 if predicate evercraft:fishing/enchantments/luck_of_the_sea_3 if predicate {"condition":"minecraft:random_chance","chance":0.015} if score #inv_full ec.var matches 0 run loot give @s loot evercraft:fishing/gameplay/fishing/crates/exquisite/1
execute unless predicate evercraft:fishing/enchantments/luck_of_the_sea_4 if predicate evercraft:fishing/enchantments/luck_of_the_sea_3 if predicate {"condition":"minecraft:random_chance","chance":0.015} if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:fishing/gameplay/fishing/crates/exquisite/1
execute unless predicate evercraft:fishing/enchantments/luck_of_the_sea_3 if predicate evercraft:fishing/enchantments/luck_of_the_sea_2 if predicate {"condition":"minecraft:random_chance","chance":0.01} if score #inv_full ec.var matches 0 run loot give @s loot evercraft:fishing/gameplay/fishing/crates/exquisite/1
execute unless predicate evercraft:fishing/enchantments/luck_of_the_sea_3 if predicate evercraft:fishing/enchantments/luck_of_the_sea_2 if predicate {"condition":"minecraft:random_chance","chance":0.01} if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:fishing/gameplay/fishing/crates/exquisite/1
execute unless predicate evercraft:fishing/enchantments/luck_of_the_sea_2 if predicate evercraft:fishing/enchantments/luck_of_the_sea_1 if predicate {"condition":"minecraft:random_chance","chance":0.005} if score #inv_full ec.var matches 0 run loot give @s loot evercraft:fishing/gameplay/fishing/crates/exquisite/1
execute unless predicate evercraft:fishing/enchantments/luck_of_the_sea_2 if predicate evercraft:fishing/enchantments/luck_of_the_sea_1 if predicate {"condition":"minecraft:random_chance","chance":0.005} if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:fishing/gameplay/fishing/crates/exquisite/1
data modify storage evercraft:notify stage.c set value [{text:"Inventory full! Your fishing crate was dropped at your feet.",color:"yellow"}]
scoreboard players set #ndur ec.temp 45
execute if score #inv_full ec.var matches 1 run function evercraft:util/notify/emit
execute if score #inv_full ec.var matches 1 if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bass player @s ~ ~ ~ 1 0.5
