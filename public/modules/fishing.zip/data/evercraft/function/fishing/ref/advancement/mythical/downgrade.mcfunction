# Downgrade Mythical → cascade through Exquisite gate (Dream Rate < 25)
data modify storage evercraft:notify stage.c set value [{text:"★ ",color:"gold"},{text:"A mythical crate flickered into existence but vanished... your dreams aren't powerful enough.",color:"gray",italic:true},{text:" ★",color:"gold"}]
scoreboard players set #ndur ec.temp 50
function evercraft:util/notify/emit_keep
data modify storage evercraft:notify stage.c set value [{text:"Requires ",color:"gray"},{text:"Dream Rate 25",color:"gold",bold:true},{text:" to receive Mythical crates. Check the Codex for your Dream Rate.",color:"gray"}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.amethyst_block.break master @s ~ ~ ~ 1 0.3

# Cascade: check if player qualifies for Exquisite (Dream Rate >= 15), otherwise Ornate
execute if score @s ec.temp matches 150.. run function evercraft:fishing/ref/advancement/exquisite/grant
execute unless score @s ec.temp matches 150.. run function evercraft:fishing/ref/advancement/exquisite/downgrade
