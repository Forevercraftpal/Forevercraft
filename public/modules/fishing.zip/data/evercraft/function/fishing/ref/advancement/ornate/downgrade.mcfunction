# Downgrade Ornate → Rare Fishing Crate (Dream Rate < 5)
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"dark_purple"},{text:"An ornate crate shimmered but faded... your dreams aren't strong enough yet.",color:"gray",italic:true},{text:" ✦",color:"dark_purple"}]
scoreboard players set #ndur ec.temp 50
function evercraft:util/notify/emit_keep
data modify storage evercraft:notify stage.c set value [{text:"Requires ",color:"gray"},{text:"Dream Rate 5",color:"gold",bold:true},{text:" to receive Ornate crates. Check the Codex for your Dream Rate.",color:"gray"}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.amethyst_block.break master @s ~ ~ ~ 1 0.5

scoreboard players add crates_fished fc.global_stats 1
scoreboard players add @s fc.total_crates 1
scoreboard players add rare_crates fc.global_stats 1
scoreboard players add @s fc.rare 1

# Competition: Fishing Derby+ (type 6) rarity-weighted crate bonus (Wave 3a). Downgraded to
# RARE, so it scores the rare weight (+3), matching the crate actually received.
execute if score #comp_active ec.var matches 6 run function evercraft:competition/score/fish_crate {w:3}

# Check inventory space
execute store result score #inv_full ec.var run function evercraft:util/check_inv_full

execute if score #inv_full ec.var matches 0 run loot give @s loot evercraft:fishing/gameplay/fishing/crates/rare/1
execute if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:fishing/gameplay/fishing/crates/rare/1
data modify storage evercraft:notify stage.c set value [{text:"Inventory full! Your fishing crate was dropped at your feet.",color:"yellow"}]
scoreboard players set #ndur ec.temp 45
execute if score #inv_full ec.var matches 1 run function evercraft:util/notify/emit
execute if score #inv_full ec.var matches 1 if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bass player @s ~ ~ ~ 1 0.5
