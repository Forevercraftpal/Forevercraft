# Downgrade Exquisite → cascade through Ornate gate (Dream Rate < 15)
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"dark_purple"},{text:"An exquisite crate shimmered but faded... your dreams aren't strong enough yet.",color:"gray",italic:true},{text:" ✦",color:"dark_purple"}]
scoreboard players set #ndur ec.temp 50
function evercraft:util/notify/emit_keep
data modify storage evercraft:notify stage.c set value [{text:"Requires ",color:"gray"},{text:"Dream Rate 15",color:"gold",bold:true},{text:" to receive Exquisite crates. Check the Codex for your Dream Rate.",color:"gray"}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.amethyst_block.break master @s ~ ~ ~ 1 0.5

# Cascade: check if player qualifies for Ornate (Dream Rate >= 5), otherwise Rare
execute if score @s ec.temp matches 50.. run function evercraft:fishing/ref/advancement/ornate/grant
execute unless score @s ec.temp matches 50.. run function evercraft:fishing/ref/advancement/ornate/downgrade
