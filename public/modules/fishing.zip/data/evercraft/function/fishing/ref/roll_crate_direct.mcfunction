# Roll crate rarity directly (full-inventory path)
# Replaces crate_direct loot table to enforce dream rate gating
# The normal path uses dummy items → advancements → process functions,
# but advancements don't fire when inventory is full.
# This function replicates the base pool weighted random, then calls
# the existing process functions (clear/revoke lines are harmless no-ops).
# NOTE: LotS bonus loot table pools are not replicated here; the grant
# functions still apply their own LotS bonus crate rolls.

# === BASE POOL (total weight: 100000) — nerfed to 1/7 (Joseph 2026-05-31) ===
# Mirrors fishing/gameplay/fishing/crate.json base pool ÷7. Old non-empty 3966 → 566.
# empty: 99434, common: 250, uncommon: 125, rare: 83,
# ornate: 50, exquisite: 33, mythical: 25
execute store result score #crate_roll ec.var run random value 1..100000

# 1-99434 = empty (no crate) — most rolls land here
execute if score #crate_roll ec.var matches 99435..99684 run function evercraft:fishing/ref/advancement/common/process
execute if score #crate_roll ec.var matches 99685..99809 run function evercraft:fishing/ref/advancement/uncommon/process
execute if score #crate_roll ec.var matches 99810..99892 run function evercraft:fishing/ref/advancement/rare/process
execute if score #crate_roll ec.var matches 99893..99942 run function evercraft:fishing/ref/advancement/ornate/process
execute if score #crate_roll ec.var matches 99943..99975 run function evercraft:fishing/ref/advancement/exquisite/process
execute if score #crate_roll ec.var matches 99976..100000 run function evercraft:fishing/ref/advancement/mythical/process

# Track if any crate was rolled (non-empty result) for the inv_full warning
execute if score #crate_roll ec.var matches 99435.. run scoreboard players set #any_dropped ec.var 1
