# Fishing Crate - On Catch (advancement reward)
# Triggered by fishing_rod_hooked advancement, fires every time player catches something

# Revoke immediately so it triggers again on next catch
advancement revoke @s only evercraft:fishing/core/catch

# Reset the multi-catch bonus-fish tally for THIS catch (accumulated by
# advantage/fishing/multi_catch across every check_crate firing below, then
# folded into the catch_any increment in questline/on_catch_hook). Joseph 2026-06-04.
scoreboard players set #fq_bonus_catch ec.temp 0

# Roll for crate
function evercraft:fishing/ref/check_crate

# Charm 2x: extra crate roll when charm is active
execute if score @s ec.charm_timer matches 1.. run function evercraft:fishing/ref/check_crate

# Lapis Trim Lure: +5% bonus crate-roll chance per lapis piece worn (lapis_trim = 1-4, written
# by evercraft:trim_effects/lapis_trim/apply_lapis_trim). Gated so non-wearers pay nothing.
execute if score @s lapis_trim matches 1.. store result score #lapis_lure_roll adv.temp run random value 1..100
execute if score @s lapis_trim matches 1 if score #lapis_lure_roll adv.temp matches 1..5 run function evercraft:fishing/ref/check_crate
execute if score @s lapis_trim matches 2 if score #lapis_lure_roll adv.temp matches 1..10 run function evercraft:fishing/ref/check_crate
execute if score @s lapis_trim matches 3 if score #lapis_lure_roll adv.temp matches 1..15 run function evercraft:fishing/ref/check_crate
execute if score @s lapis_trim matches 4 if score #lapis_lure_roll adv.temp matches 1..20 run function evercraft:fishing/ref/check_crate

# === Family J — fishing extra-crate leaves (art-J) ===
# C32 Tidecaller's Lure + C36 Deepcurrent Reliquary each grant ONE extra independent crate roll per
# successful catch (a second dreamy-pull draw) — mirrors the Charm 2x / lapis-trim / Crate Chum
# extra-roll precedents above. Item-gated (non-holders pay only the single `if items` probe). ADDITIVE
# on top of the base check_crate (NOT a rarity-table rewrite). id-presence -> two copies of the same
# charm fire one extra roll (m4 multi-copy-safe). C36 ALSO carries a conditional +3.0 DR while in
# water (player_tick) + is consolidated into the fishing sub-cap; this is only its extra-crate half.
# cap-J m4 SUPPRESS-AT-SOURCE: when an absorbing node is held on Adventurer/Pioneer, the loose extra-roll
# is suppressed (the node fires the consolidated rolls below) so a re-acquired loose charm never adds a
# second roll. #fj_nsup covers C32+C36 (Tidewright's Net + grand Cornucopia Tide absorb both). #fj_dsup
# covers C32 only (the Dock Pair absorbs C31+C32 — only C32 is a crate roll). Newcomer-exempt.
scoreboard players set #fj_nsup ec.temp 0
execute unless score @s ec.difficulty matches 1 if items entity @s container.* *[custom_data~{tidewrights_net:true}] run scoreboard players set #fj_nsup ec.temp 1
execute unless score @s ec.difficulty matches 1 unless items entity @s container.* *[custom_data~{tidewrights_net:true}] unless items entity @s weapon.offhand *[custom_data~{tidewrights_net:true}] if entity @s[tag=ec.sat_tidewrights_net] run scoreboard players set #fj_nsup ec.temp 1
execute unless score @s ec.difficulty matches 1 if items entity @s weapon.offhand *[custom_data~{tidewrights_net:true}] run scoreboard players set #fj_nsup ec.temp 1
execute unless score @s ec.difficulty matches 1 if items entity @s container.* *[custom_data~{cornucopia_tide:true}] run scoreboard players set #fj_nsup ec.temp 1
execute unless score @s ec.difficulty matches 1 unless items entity @s container.* *[custom_data~{cornucopia_tide:true}] unless items entity @s weapon.offhand *[custom_data~{cornucopia_tide:true}] if entity @s[tag=ec.sat_cornucopia_tide] run scoreboard players set #fj_nsup ec.temp 1
execute unless score @s ec.difficulty matches 1 if items entity @s weapon.offhand *[custom_data~{cornucopia_tide:true}] run scoreboard players set #fj_nsup ec.temp 1
scoreboard players set #fj_dsup ec.temp 0
execute if score #fj_nsup ec.temp matches 1 run scoreboard players set #fj_dsup ec.temp 1
execute unless score @s ec.difficulty matches 1 if items entity @s container.* *[custom_data~{dock_pair:true}] run scoreboard players set #fj_dsup ec.temp 1
execute unless score @s ec.difficulty matches 1 if items entity @s weapon.offhand *[custom_data~{dock_pair:true}] run scoreboard players set #fj_dsup ec.temp 1
# Loose C32 Tidecaller's Lure (suppressed by Dock Pair / Net / grand via #fj_dsup).
execute unless score #fj_dsup ec.temp matches 1 if items entity @s container.* *[custom_data~{artifact:"tidecallers_lure"}] run function evercraft:fishing/ref/check_crate
execute unless score #fj_dsup ec.temp matches 1 unless items entity @s container.* *[custom_data~{artifact:"tidecallers_lure"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"tidecallers_lure"}] if entity @s[tag=ec.sat_tidecallers_lure] run function evercraft:fishing/ref/check_crate
execute unless score #fj_dsup ec.temp matches 1 unless items entity @s container.* *[custom_data~{artifact:"tidecallers_lure"}] if items entity @s weapon.offhand *[custom_data~{artifact:"tidecallers_lure"}] run function evercraft:fishing/ref/check_crate
# Loose C36 Deepcurrent Reliquary (suppressed by Net / grand via #fj_nsup; NOT by Dock Pair).
execute unless score #fj_nsup ec.temp matches 1 if items entity @s container.* *[custom_data~{artifact:"deepcurrent_reliquary"}] run function evercraft:fishing/ref/check_crate
execute unless score #fj_nsup ec.temp matches 1 unless items entity @s container.* *[custom_data~{artifact:"deepcurrent_reliquary"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"deepcurrent_reliquary"}] if entity @s[tag=ec.sat_deepcurrent_reliquary] run function evercraft:fishing/ref/check_crate
execute unless score #fj_nsup ec.temp matches 1 unless items entity @s container.* *[custom_data~{artifact:"deepcurrent_reliquary"}] if items entity @s weapon.offhand *[custom_data~{artifact:"deepcurrent_reliquary"}] run function evercraft:fishing/ref/check_crate
# cap-J CONSOLIDATED extra crate rolls. Dock Pair = ONE extra roll (the C32 half it absorbs). Tidewright's
# Net + grand Cornucopia Tide = TWO extra rolls (C32 + C36 folded). id-presence -> two copies fire the
# fixed count. The grand supersedes the Net (guarded `unless` grand); the Net/grand supersede the Dock
# Pair (the Dock Pair roll is guarded `unless` a Net/grand is held — its C32 is folded into the 2 rolls).
# Dock Pair — 1 extra roll, unless an absorbing Net/grand is held.
execute unless items entity @s container.* *[custom_data~{tidewrights_net:true}] unless items entity @s weapon.offhand *[custom_data~{tidewrights_net:true}] unless entity @s[tag=ec.sat_tidewrights_net] unless items entity @s container.* *[custom_data~{cornucopia_tide:true}] unless items entity @s weapon.offhand *[custom_data~{cornucopia_tide:true}] unless entity @s[tag=ec.sat_cornucopia_tide] if items entity @s container.* *[custom_data~{dock_pair:true}] run function evercraft:fishing/ref/check_crate
execute unless items entity @s container.* *[custom_data~{tidewrights_net:true}] unless items entity @s weapon.offhand *[custom_data~{tidewrights_net:true}] unless entity @s[tag=ec.sat_tidewrights_net] unless items entity @s container.* *[custom_data~{cornucopia_tide:true}] unless items entity @s weapon.offhand *[custom_data~{cornucopia_tide:true}] unless entity @s[tag=ec.sat_cornucopia_tide] unless items entity @s container.* *[custom_data~{dock_pair:true}] if items entity @s weapon.offhand *[custom_data~{dock_pair:true}] run function evercraft:fishing/ref/check_crate
# Tidewright's Net / grand Cornucopia Tide — TWO extra rolls (grand supersedes Net — guarded `unless` grand).
execute if items entity @s container.* *[custom_data~{cornucopia_tide:true}] run function evercraft:fishing/ref/check_crate
execute unless items entity @s container.* *[custom_data~{cornucopia_tide:true}] unless items entity @s weapon.offhand *[custom_data~{cornucopia_tide:true}] if entity @s[tag=ec.sat_cornucopia_tide] run function evercraft:fishing/ref/check_crate
execute if items entity @s container.* *[custom_data~{cornucopia_tide:true}] run function evercraft:fishing/ref/check_crate
execute unless items entity @s container.* *[custom_data~{cornucopia_tide:true}] unless items entity @s weapon.offhand *[custom_data~{cornucopia_tide:true}] if entity @s[tag=ec.sat_cornucopia_tide] run function evercraft:fishing/ref/check_crate
execute unless items entity @s container.* *[custom_data~{cornucopia_tide:true}] if items entity @s weapon.offhand *[custom_data~{cornucopia_tide:true}] run function evercraft:fishing/ref/check_crate
execute unless items entity @s container.* *[custom_data~{cornucopia_tide:true}] if items entity @s weapon.offhand *[custom_data~{cornucopia_tide:true}] run function evercraft:fishing/ref/check_crate
execute unless items entity @s container.* *[custom_data~{cornucopia_tide:true}] unless items entity @s weapon.offhand *[custom_data~{cornucopia_tide:true}] unless entity @s[tag=ec.sat_cornucopia_tide] if items entity @s container.* *[custom_data~{tidewrights_net:true}] run function evercraft:fishing/ref/check_crate
execute unless items entity @s container.* *[custom_data~{cornucopia_tide:true}] unless items entity @s weapon.offhand *[custom_data~{cornucopia_tide:true}] unless entity @s[tag=ec.sat_cornucopia_tide] unless items entity @s container.* *[custom_data~{tidewrights_net:true}] unless items entity @s weapon.offhand *[custom_data~{tidewrights_net:true}] if entity @s[tag=ec.sat_tidewrights_net] run function evercraft:fishing/ref/check_crate
execute unless items entity @s container.* *[custom_data~{cornucopia_tide:true}] unless items entity @s weapon.offhand *[custom_data~{cornucopia_tide:true}] unless entity @s[tag=ec.sat_cornucopia_tide] if items entity @s container.* *[custom_data~{tidewrights_net:true}] run function evercraft:fishing/ref/check_crate
execute unless items entity @s container.* *[custom_data~{cornucopia_tide:true}] unless items entity @s weapon.offhand *[custom_data~{cornucopia_tide:true}] unless entity @s[tag=ec.sat_cornucopia_tide] unless items entity @s container.* *[custom_data~{tidewrights_net:true}] unless items entity @s weapon.offhand *[custom_data~{tidewrights_net:true}] if entity @s[tag=ec.sat_tidewrights_net] run function evercraft:fishing/ref/check_crate
execute unless items entity @s container.* *[custom_data~{cornucopia_tide:true}] unless items entity @s weapon.offhand *[custom_data~{cornucopia_tide:true}] unless entity @s[tag=ec.sat_cornucopia_tide] unless items entity @s container.* *[custom_data~{tidewrights_net:true}] if items entity @s weapon.offhand *[custom_data~{tidewrights_net:true}] run function evercraft:fishing/ref/check_crate
execute unless items entity @s container.* *[custom_data~{cornucopia_tide:true}] unless items entity @s weapon.offhand *[custom_data~{cornucopia_tide:true}] unless entity @s[tag=ec.sat_cornucopia_tide] unless items entity @s container.* *[custom_data~{tidewrights_net:true}] if items entity @s weapon.offhand *[custom_data~{tidewrights_net:true}] run function evercraft:fishing/ref/check_crate

# === Family K — C43 Resonant Geode Heart "catch" half (art-K) ===
# C43 grants a steady +2% Crafting Crate stream on break/harvest/catch. Its break + harvest surfaces
# ride the m2 harvest_bonus_crate (grant_verb/grant_weighted/gather/resolve_win); this is its CATCH
# surface — a 2% (1..100 -> 1..2) item-gated EXTRA crate roll per successful catch, ADDITIVE on the
# base. The Geode crate is a generic Crafting Crate (give_crafting_crate) — matching its break/harvest
# behavior (the harvest_bonus_crate path gives give_crafting_crate too), distinct from the J leaves'
# fishing check_crate above. id-presence -> two copies fire one roll (m4 multi-copy-safe).
execute if items entity @s container.* *[custom_data~{artifact:"resonant_geode_heart"}] store result score #rgh_catch ec.temp run random value 1..100
execute unless items entity @s container.* *[custom_data~{artifact:"resonant_geode_heart"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"resonant_geode_heart"}] if entity @s[tag=ec.sat_resonant_geode_heart] store result score #rgh_catch ec.temp run random value 1..100
execute unless items entity @s container.* *[custom_data~{artifact:"resonant_geode_heart"}] if items entity @s weapon.offhand *[custom_data~{artifact:"resonant_geode_heart"}] store result score #rgh_catch ec.temp run random value 1..100
execute if items entity @s container.* *[custom_data~{artifact:"resonant_geode_heart"}] if score #rgh_catch ec.temp matches 1..2 run function evercraft:craft_affinity/give_crafting_crate
execute unless items entity @s container.* *[custom_data~{artifact:"resonant_geode_heart"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"resonant_geode_heart"}] if entity @s[tag=ec.sat_resonant_geode_heart] if score #rgh_catch ec.temp matches 1..2 run function evercraft:craft_affinity/give_crafting_crate
execute unless items entity @s container.* *[custom_data~{artifact:"resonant_geode_heart"}] if items entity @s weapon.offhand *[custom_data~{artifact:"resonant_geode_heart"}] if score #rgh_catch ec.temp matches 1..2 run function evercraft:craft_affinity/give_crafting_crate

# Newcomer bonus: 10% extra crate roll
execute if score @s ec.difficulty matches 1 if predicate {"condition":"minecraft:random_chance","chance":0.1} run function evercraft:fishing/ref/check_crate

# Bait — Crate Chum (offhand): one extra crate roll + consume one, mirroring the
# lapis/charm extra-roll precedent above. Objective-free (tag-gated), item-gated so
# non-holders pay only the single `if items` probe.
function evercraft:fishing/bait/crate_chum

# Fishing Derby bonus: 50% chance for extra crate roll (1.5x total crate rate)
execute if score #cal_event_id ec.var matches 4 store result score #cal_derby_roll cal.temp run random value 1..2
execute if score #cal_event_id ec.var matches 4 if score #cal_derby_roll cal.temp matches 1 run function evercraft:fishing/ref/check_crate

# Fishing Derby scoring (if active)
execute if score #cal_event_id ec.var matches 4 run function evercraft:calendar/events/fishing_derby/score_catch

# Seasons + Fishing: Full moon night grants extra crate roll (lunar tides)
execute if score #moon_phase ec.var matches 0 if score #visual_time ec.var matches 13000..23000 run function evercraft:fishing/ref/check_crate
data modify storage evercraft:notify stage.c set value [{text:"The lunar tide favors your catch!",color:"#87CEEB",italic:true}]
scoreboard players set #ndur ec.temp 45
execute if score #moon_phase ec.var matches 0 if score #visual_time ec.var matches 13000..23000 run function evercraft:util/notify/emit

# Fishing + Advantage: Fishing level 10+ grants +2 Fishing tree progress per catch
execute if score @s adv.fishing matches 10.. run scoreboard players add @s adv.stat_fish 2

# Message in a Bottle — 2% chance to catch on any fishing success
function evercraft:bottles/try_catch

# Bait pre-roll setup — read the offhand and stage bias temps BEFORE the spirit/aquatic
# rolls fire. set_bias is item-gated (no objective writes for non-holders). The temps
# #sf_bias / #af_bias on ec.temp are consumed inside the respective try_catch rolls.
function evercraft:fishing/bait/set_bias

# Spirit Cuisine — rare Spirit Fish catch (~2.5%, biome/time-gated). At most one per catch.
# Drops the existing cooking/spirit_fish/<name> tropical_fish that cook_spirit consumes.
execute at @s run function evercraft:cooking/spirit_fish/try_catch

# Aquatic Alchemy — independent roll for Aquatic Fish reagents (~20%, biome-gated for the
# two rarest). Separate from the Spirit Fish roll; both may fire on one catch (multi-bonus model).
execute at @s run function evercraft:fishing/aquatic_fish/try_catch

# Bait — Bark Grub (offhand): one EXTRA aquatic-fish roll + consume one, a generic
# "fish strike harder" bonus. Placed AFTER the base aquatic roll so it's a true extra.
# Objective-free (tag-gated), item-gated so non-holders pay only the single `if items` probe.
execute at @s run function evercraft:fishing/bait/bark_grub

# Crafted-item discovery — independent low-chance rolls for cook-only meals, aquatic Fusion-Funnel
# potions, and offhand bait (water-gated by fishing). Lets players DISCOVER these craftables exist.
# Give-or-drop guarded internally. Joseph 2026-06-04.
execute at @s run function evercraft:fishing/discovery/roll

# Artisan XP: Fishing (+2 per catch)
scoreboard players set #cf_xp_amount ec.cf_temp 2
scoreboard players set #cf_xp_cat ec.cf_temp 2
function evercraft:craftforever/artisan/add_xp

# Guild Diplomacy Event: Fishing scoring
execute if score #gd_event_active ec.var matches 1 if score #gd_event_activity ec.var matches 1 if score @s ec.gd_event_active matches 1 run scoreboard players add @s ec.gd_event_score 1

# Competition: Fishing Derby+ scoring (type 6 — server-wide or H2H)
execute if score #comp_active ec.var matches 6 run function evercraft:competition/score/fish_catch
execute unless score #comp_active ec.var matches 6 if score #h2h_active ec.var matches 6 run function evercraft:competition/score/fish_catch

# The Fisher's Questline — FALLBACK onboarding (Joseph 2026-06-01). The line normally
# starts on the first_rod inventory advancement, but that NEVER fires for a rod the
# player already held before this feature shipped (or when the datapack is added to a
# pre-existing world). So: any catch by a player who has not started AND not finished
# the line starts it right here — and because it runs BEFORE the hook below, THIS catch
# already counts toward quest 1 ("First Cast"). start is gated to un-started players, so
# active/completed anglers never re-run it. (first_rod still handles fresh rod pickups.)
execute unless score @s ec.fq_active matches 1 unless score @s ec.fq_complete matches 1 run function evercraft:fishing/questline/start

# UNIFIED harvest bonus (Part C): the coin + cross-node-custom layer, ADDED at the catch-landed point.
# CRATE CHANNEL OFF (#hb_crate_thresh 0) — fishing already owns a rich crate economy via check_crate
# above (the bonus_crate here would DOUBLE-dip), so harvest_bonus contributes ONLY the Forever-Coin
# (3%) + custom (2%) layer fishing previously lacked. #hb_cfg 1 = caller configures all three.
scoreboard players set #hb_crate_thresh ec.temp 0
scoreboard players set #hb_coin_pct ec.temp 3
scoreboard players set #hb_custom_pct ec.temp 2
scoreboard players set #hb_cfg ec.temp 1
function evercraft:gather/harvest_bonus

# The Fisher's Questline — catch-detection hook (catch_any + catch_crate).
# Score-gated so non-questline players pay ~nothing.
execute if score @s ec.fq_active matches 1 run function evercraft:fishing/questline/on_catch_hook
