# Evercraft Fishing Crates - Load
# Scoreboard-based fishing crate system (no enchantments)

scoreboard objectives add ec.init dummy
scoreboard players add fishing_crates ec.init 0
execute unless score fishing_crates ec.init matches 1 run function evercraft:fishing/ref/init

# Ensure delta-tracking scoreboard exists (added post-migration)
scoreboard objectives add fc.prev_fish dummy

# Fisher's Questline — declare objectives + (re)load the quest registry. Storage is
# volatile across /reload, so this MUST run every load. (Wire was missing — the
# questline could never advance with an empty registry; fixes the Fisher's Path not
# progressing + the Angler's Codex never being granted. Joseph 2026-06-01.)
function evercraft:fishing/questline/load
