# Splash Node: Per-node particle rendering
# Run as node marker, at node position. Routed by data.dim (1=water, 2=lava).

# Lava nodes (nether): a tall sparking lava plume (2026-06-01 intensified)
execute if data entity @s {data:{dim:2}} run particle minecraft:lava ~ ~0.1 ~ 0.2 0.3 0.2 0 4
execute if data entity @s {data:{dim:2}} run particle minecraft:flame ~ ~0.3 ~ 0.12 0.5 0.12 0.02 6
execute if data entity @s {data:{dim:2}} run particle minecraft:flame ~ ~0.6 ~ 0.06 0.5 0.06 0.12 5
execute if data entity @s {data:{dim:2}} run particle minecraft:smoke ~ ~0.6 ~ 0.1 0.4 0.1 0.02 3

# Water nodes (overworld): a tall splash plume + bob (2026-06-01 intensified)
execute unless data entity @s {data:{dim:2}} run particle minecraft:splash ~ ~0.1 ~ 0.22 0.45 0.22 0.05 10
execute unless data entity @s {data:{dim:2}} run particle minecraft:splash ~ ~0.55 ~ 0.07 0.5 0.07 0.14 6
execute unless data entity @s {data:{dim:2}} run particle minecraft:fishing ~ ~0.25 ~ 0.15 0.3 0.15 0 3

# Pulse every ~4 seconds (gametime % 80, pulse when < 10) — a big TALL burst
execute store result score #spl_pulse ec.temp run time query gametime
scoreboard players operation #spl_pulse ec.temp %= #80 ec.const
execute if score #spl_pulse ec.temp matches ..9 if data entity @s {data:{dim:2}} run particle minecraft:flame ~ ~0.4 ~ 0.3 0.8 0.3 0.08 16
execute if score #spl_pulse ec.temp matches ..9 unless data entity @s {data:{dim:2}} run particle minecraft:splash ~ ~0.35 ~ 0.35 0.9 0.35 0.12 22

# Zone-claim highlight (Joseph #73 2026-06-13) — gold for guild, pink for house, both 24b
function evercraft:fx/zone_node_highlight
