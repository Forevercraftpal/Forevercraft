# Splash Node: coord-pinned despawn macro.
# Called with storage evercraft:gth_temp {x:X, y:Y, z:Z} (the click-time coord-pin).
# Positions at the pinned coords and runs despawn_node AS the marker there (despawn_node
# kills the interaction within ~1 block + the marker self). distance=..2 tolerance to
# find the pinned marker; NEVER the racy distance=..4 sort=nearest of the old tail.
$execute positioned $(x) $(y) $(z) as @e[type=marker,tag=ec.splash_data,distance=..2,limit=1,sort=nearest] at @s run function evercraft:fishing/splash_nodes/despawn_node
