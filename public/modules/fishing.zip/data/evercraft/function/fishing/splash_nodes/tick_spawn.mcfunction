# Splash Node: Per-second spawn timer check
# Self-scheduling 1s loop (mirrors prospect/tick_spawn)
schedule function evercraft:fishing/splash_nodes/tick_spawn 1s replace

# Gate: skip if no players online
execute unless entity @a run return 0

# Only survival/adventure players of the Sirencall CLASS run the spawn check.
# 2026-06-01 (Joseph): was gated on ec.caffs_sc>=1 — but caffs_sc is the Sirencall *stage*
# (stage 1 needs 3,000 affinity pts), NOT "L1". That blocked actual Sirencall players (e.g.
# a level-2 angler still at stage 0). Gate on ec.caff_class=5 (the Sirencall class) instead,
# matching the EPIC's "around an L1+ [Sirencall] player". Skip spectators/creative (survival gameplay).
execute as @a[gamemode=!spectator,gamemode=!creative,scores={ec.caff_class=5}] at @s run function evercraft:fishing/splash_nodes/check_spawn
