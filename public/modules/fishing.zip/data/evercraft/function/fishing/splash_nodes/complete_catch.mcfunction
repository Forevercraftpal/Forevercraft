# Splash Node: catch channel filled -> hide the bar, reset, run the harvest (do_catch, UNCHANGED).
# Run as @s = the player. do_catch is positioned AT THE NODE so its distance=..4 coord-pin resolves.
bossbar set evercraft:splash_gather visible false
scoreboard players set @s ec.spl_picking 0
scoreboard players set @s ec.spl_progress 0
execute at @e[type=marker,tag=ec.splash_data,distance=..12,limit=1,sort=nearest] run function evercraft:fishing/splash_nodes/do_catch
