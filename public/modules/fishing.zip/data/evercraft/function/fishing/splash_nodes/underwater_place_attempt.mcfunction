# Splash Node (UNDERWATER): ONE floor-placement candidate (recursive). Run as the player.
# Mirror of place_attempt but uses gather/underwater/scan_floor (water-over-floor = the river/
# ocean bottom) and stamps data.underwater:1b so do_catch routes the DEEP catch/crate tables.
# 2026-06-01 (Joseph): random offset instead of water-shy spreadplayers; recurses until
# #spl_tries runs out. Shared scratch: #spl_tries, #spl_placed, #uw_scan (scan budget).

# Out of tries — give up this cycle (try_spawn's short-retry timer re-searches).
execute if score #spl_tries ec.temp matches ..0 run return 0
scoreboard players remove #spl_tries ec.temp 1

# Player block coords + a random nearby offset (-15..15; oceans/rivers are large), start 2 above.
execute store result score #spl_tx ec.temp run data get entity @s Pos[0] 1
execute store result score #spl_ty ec.temp run data get entity @s Pos[1] 1
execute store result score #spl_tz ec.temp run data get entity @s Pos[2] 1
execute store result score #spl_ox ec.temp run random value -15..15
execute store result score #spl_oz ec.temp run random value -15..15
scoreboard players operation #spl_tx ec.temp += #spl_ox ec.temp
scoreboard players operation #spl_tz ec.temp += #spl_oz ec.temp
scoreboard players add #spl_ty ec.temp 2

# Summon a candidate marker and move it to (offsetX, playerY+2, offsetZ).
summon marker ~ ~ ~ {Tags:["ec.splash_temp"]}
execute store result entity @e[type=marker,tag=ec.splash_temp,limit=1] Pos[0] double 1 run scoreboard players get #spl_tx ec.temp
execute store result entity @e[type=marker,tag=ec.splash_temp,limit=1] Pos[1] double 1 run scoreboard players get #spl_ty ec.temp
execute store result entity @e[type=marker,tag=ec.splash_temp,limit=1] Pos[2] double 1 run scoreboard players get #spl_tz ec.temp

# Scan DOWN (up to 30) for a water-block-over-solid-floor.
scoreboard players set #uw_scan ec.temp 30
execute as @e[type=marker,tag=ec.splash_temp,limit=1] at @s store success score #spl_found ec.temp run function evercraft:gather/underwater/scan_floor

# No floor at this candidate — drop it and try another.
execute if score #spl_found ec.temp matches 0 run kill @e[type=marker,tag=ec.splash_temp]
execute if score #spl_found ec.temp matches 0 run return run function evercraft:fishing/splash_nodes/underwater_place_attempt

# Found a floor — place the node in the water just above it, stamp the deep-loot flag, done.
data modify storage evercraft:spl_temp node_dim set value 1
execute at @e[type=marker,tag=ec.splash_temp,limit=1] run function evercraft:fishing/splash_nodes/place_node
execute at @e[type=marker,tag=ec.splash_temp,limit=1] run data modify entity @e[type=marker,tag=ec.splash_data,limit=1,distance=..1] data.underwater set value 1b
kill @e[type=marker,tag=ec.splash_temp]
scoreboard players set #spl_placed ec.temp 1
