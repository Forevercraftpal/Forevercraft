# Splash Node: Reset spawn timer based on movement state.
# INVERTED per Joseph 2026-06-01: fishing rewards STILLNESS, not movement. The longer
# you stand still by the water the more nodes appear; roaming only turns one up rarely.
# Standing still (ec.spl_moving = 0): 500 ticks (25s) — the productive fishing cadence.
# Moving       (ec.spl_moving > 0): 5000 ticks (~4.2 min) — moving while fishing HURTS your node rate.
execute if score @s ec.spl_moving matches ..0 run scoreboard players set @s ec.spl_timer 500
execute if score @s ec.spl_moving matches 1.. run scoreboard players set @s ec.spl_timer 5000
