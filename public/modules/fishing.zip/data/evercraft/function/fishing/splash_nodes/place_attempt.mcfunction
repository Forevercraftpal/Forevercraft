# Splash Node: ONE placement candidate (recursive). Run as the player, at the player.
# Tries a nearby spot for a water/lava surface; on a miss it recurses until #spl_tries
# runs out. 2026-06-01 (Joseph) rewrite of the spawn mechanic:
#   - NO spreadplayers: it shuns water (always relocates onto dry land) so candidates
#     never landed on a pool. We pick a raw random XZ offset instead, which CAN sit on water.
#   - Start the candidate a few blocks ABOVE the player and scan DOWN, so the scan begins in
#     air over the water (the old start-at-player-Y began at/below the surface and missed it).
# Shared scratch (set by try_spawn): #spl_tries (budget), #spl_dim (1=water/2=lava),
# #spl_placed (success flag), #spl_scan/#spl_liquid (scan state).

# Out of tries — give up this cycle (try_spawn's short-retry timer re-searches).
execute if score #spl_tries ec.temp matches ..0 run return 0
scoreboard players remove #spl_tries ec.temp 1

# Player block coords + a random nearby offset (-7..7 on X/Z), starting 4 blocks above.
execute store result score #spl_tx ec.temp run data get entity @s Pos[0] 1
execute store result score #spl_ty ec.temp run data get entity @s Pos[1] 1
execute store result score #spl_tz ec.temp run data get entity @s Pos[2] 1
execute store result score #spl_ox ec.temp run random value -7..7
execute store result score #spl_oz ec.temp run random value -7..7
scoreboard players operation #spl_tx ec.temp += #spl_ox ec.temp
scoreboard players operation #spl_tz ec.temp += #spl_oz ec.temp
scoreboard players add #spl_ty ec.temp 4

# Summon a candidate marker and move it to (offsetX, playerY+4, offsetZ).
summon marker ~ ~ ~ {Tags:["ec.splash_temp"]}
execute store result entity @e[type=marker,tag=ec.splash_temp,limit=1] Pos[0] double 1 run scoreboard players get #spl_tx ec.temp
execute store result entity @e[type=marker,tag=ec.splash_temp,limit=1] Pos[1] double 1 run scoreboard players get #spl_ty ec.temp
execute store result entity @e[type=marker,tag=ec.splash_temp,limit=1] Pos[2] double 1 run scoreboard players get #spl_tz ec.temp

# Scan DOWN (up to 30) for an air-block-over-liquid surface.
scoreboard players set #spl_scan ec.temp 30
execute store result score #spl_liquid ec.temp run scoreboard players get #spl_dim ec.temp
execute as @e[type=marker,tag=ec.splash_temp,limit=1] at @s store success score #spl_found ec.temp run function evercraft:fishing/splash_nodes/scan_surface

# No surface at this candidate — drop it and try another.
execute if score #spl_found ec.temp matches 0 run kill @e[type=marker,tag=ec.splash_temp]
execute if score #spl_found ec.temp matches 0 run return run function evercraft:fishing/splash_nodes/place_attempt

# Found a surface — place the node here, clean up, flag success.
execute store result storage evercraft:spl_temp node_dim int 1 run scoreboard players get #spl_dim ec.temp
execute at @e[type=marker,tag=ec.splash_temp,limit=1] run function evercraft:fishing/splash_nodes/place_node
kill @e[type=marker,tag=ec.splash_temp]
scoreboard players set #spl_placed ec.temp 1
