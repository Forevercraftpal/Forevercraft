# Splash Node: Scan downward to find a water/lava SURFACE
# Run as: temp marker, at: temp marker
# Uses: #spl_scan ec.temp (decremented each call), #spl_liquid ec.temp (1=water, 2=lava)
# Returns: 1 if found (marker TPed to the air block just above the liquid surface), else 0
# Mirrors evercraft:common/scan_down, but tests for liquid-with-air-above.

scoreboard players remove #spl_scan ec.temp 1
execute if score #spl_scan ec.temp matches ..0 run return 0

# Surface = air here, water directly below (overworld nodes)
execute if score #spl_liquid ec.temp matches 1 if block ~ ~ ~ #evercraft:spawnable_air if block ~ ~-1 ~ minecraft:water run return 1
# Surface = air here, lava directly below (nether nodes)
execute if score #spl_liquid ec.temp matches 2 if block ~ ~ ~ #evercraft:spawnable_air if block ~ ~-1 ~ minecraft:lava run return 1

# Keep scanning down
tp @s ~ ~-1 ~
execute at @s run function evercraft:fishing/splash_nodes/scan_surface
