# Splash Node: Remove node entities with a fadeout effect
# Run as node marker, at node position.

# Fadeout particles (water splash by default; lava fizzle for nether nodes)
execute if data entity @s {data:{dim:2}} run particle minecraft:lava ~ ~0.1 ~ 0.25 0.15 0.25 0 6
execute unless data entity @s {data:{dim:2}} run particle minecraft:splash ~ ~0.1 ~ 0.3 0.2 0.3 0 8

# Kill the interaction entity at this location
kill @e[type=interaction,tag=ec.splash_click,distance=..1]

# Kill self (the data marker)
kill @s
