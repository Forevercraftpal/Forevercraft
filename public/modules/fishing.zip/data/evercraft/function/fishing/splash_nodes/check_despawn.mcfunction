# Splash Node: Check if this node should despawn (stale-node watchdog)
# Run as node marker.

# Calculate elapsed ticks since spawn
execute store result score #spl_now ec.temp run time query gametime
execute store result score #spl_spawn ec.temp run data get entity @s data.spawn_time
scoreboard players operation #spl_elapsed ec.temp = #spl_now ec.temp
scoreboard players operation #spl_elapsed ec.temp -= #spl_spawn ec.temp

# Despawn after 2000 ticks (~100 seconds at 20 tps) — ambient nodes are short-lived
execute if score #spl_elapsed ec.temp matches 2000.. at @s run function evercraft:fishing/splash_nodes/despawn_node
