# Splash Node: Timer management (movement via shared ec.moving)
# Run as each eligible player, at player position

# --- Sync movement from shared detection (OPT: no NBT reads) ---
scoreboard players operation @s ec.spl_moving = @s ec.moving

# --- Decrement timer by 20 ticks (1 second) ---
scoreboard players remove @s ec.spl_timer 20

# --- When timer expires, attempt spawn ---
# Wave E1: in-water, river/ocean-competent players (caffl_sc) also get an underwater FLOOR splash
# node (distinct from the surface node). Tight gate (in_water + unlock level) so dry-land /
# under-unlock players never run the floor scan; underwater_try_spawn shares the same cap + resets
# the timer itself, so the surface branch below is skipped on a successful underwater route. NO new
# tick loop — rides the existing check_spawn call (which already runs only for caffs_sc=1.. players).
# The `matches 30..` literal MUST stay in sync with `#gth_uw_unlock ec.var` (gather/load, the
# canonical tunable; `matches` takes only literals, like tick_spawn's hardcoded caffs_sc gate).
execute if score @s ec.spl_timer matches ..-1 if predicate evercraft:in_water if score @s ec.caffl_sc matches 30.. run return run function evercraft:fishing/splash_nodes/underwater_try_spawn
execute if score @s ec.spl_timer matches ..-1 run function evercraft:fishing/splash_nodes/try_spawn
