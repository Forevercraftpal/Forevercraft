# Splash Node: Despawn the EXACT pinned node (charges-exhausted win OR crumble).
# Run as @s, at the player, from do_catch on the gth_despawn signal.
# Coord-pinned from the gth_temp.x/y/z stored at click time — NOT sort=nearest, so a
# multiplayer crowd never despawns the wrong node. Mirrors the prospect/forage despawn
# pattern (position at the pinned coords, run despawn_node as the marker there).
function evercraft:fishing/splash_nodes/do_catch_despawn_pinned with storage evercraft:gth_temp
