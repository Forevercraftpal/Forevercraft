# Splash Node: rod-click -> run the harvest success-check, then branch.
# Run as the player who clicked, at the player position. (Wave B-wire: spliced through
# evercraft:gather/.) Joseph's locked decision: NO bobber — a splash node is instant.

# ---------- HEAD (always — runs every rod-click on a node, even a dropped claim) ----------
# Read the clicked node's dim (1=overworld water, 2=nether lava). Nearest splash marker
# within ~4 blocks is the node we clicked. Stash dim in gth_temp.dim so it survives the
# resolve() call (which churns ec.temp) for use in _success.
scoreboard players set #spl_dim ec.temp 1
execute store result score #spl_dim ec.temp run data get entity @e[type=marker,tag=ec.splash_data,distance=..4,limit=1,sort=nearest] data.dim
execute store result storage evercraft:gth_temp dim int 1 run scoreboard players get #spl_dim ec.temp

# E1-loot: read the node's data.underwater (1b on river/ocean-floor nodes, absent on surface)
# into gth_temp.underwater so it survives the resolve() call for _success to route the DEEP
# catch/crate tables. Seed 0 FIRST — store result leaves the storage untouched (= 0) when the
# data.underwater path is absent on a surface node, so surface catches never read as underwater.
data modify storage evercraft:gth_temp underwater set value 0
execute store result storage evercraft:gth_temp underwater int 1 run data get entity @e[type=marker,tag=ec.splash_data,distance=..4,limit=1,sort=nearest] data.underwater

# Success-check setup: source + coord-pin (read the clicked marker's Pos — no start phase).
scoreboard players set @s ec.gth_src 3
execute store result storage evercraft:gth_temp x int 1 run data get entity @e[type=marker,tag=ec.splash_data,distance=..4,limit=1,sort=nearest] Pos[0]
execute store result storage evercraft:gth_temp y int 1 run data get entity @e[type=marker,tag=ec.splash_data,distance=..4,limit=1,sort=nearest] Pos[1]
execute store result storage evercraft:gth_temp z int 1 run data get entity @e[type=marker,tag=ec.splash_data,distance=..4,limit=1,sort=nearest] Pos[2]
data modify storage evercraft:gth_temp dtag set value "ec.splash_data"

# ---------- Tidecaller's Vow (Sirencall Crown, Wave 9) — no still-water fishing ----------
# Crown owned (ec.sc_b_crown) + Sirencall active (ec.caff_sc): a node whose liquid is a FULL
# SOURCE water block (water[level=0], not flowing) refuses the catch BEFORE the engine roll —
# no claim, no charge burned, no XP. Checked at the clicked MARKER, not the player's feet:
# surface nodes rest in the air block just above the liquid (scan_surface) -> test ~ ~-1 ~ ;
# underwater nodes rest IN the water column (underwater scan_floor) -> test ~ ~ ~ . Open
# OCEAN is exempt (crown_apply vow contract: "flowing water or open ocean only" — ocean
# surface is all source blocks; the vow targets ponds/lakes/still rivers). Lava nodes never
# match (not water). The biome predicate evaluates at the marker's position.
execute if score @s ec.sc_b_crown matches 1.. if score @s ec.caff_sc matches 1.. if score @s ec.sc_vow_on matches 1 at @e[type=marker,tag=ec.splash_data,distance=..4,limit=1,sort=nearest] unless predicate evercraft:biome/is_ocean if block ~ ~-1 ~ minecraft:water[level=0] run return run function evercraft:bough/sirencall/vow_break
execute if score @s ec.sc_b_crown matches 1.. if score @s ec.caff_sc matches 1.. if score @s ec.sc_vow_on matches 1 at @e[type=marker,tag=ec.splash_data,distance=..4,limit=1,sort=nearest] unless predicate evercraft:biome/is_ocean if block ~ ~ ~ minecraft:water[level=0] run return run function evercraft:bough/sirencall/vow_break

# Roll the harvest (engine: claim -> success% -> win/fail/crumble, grants Craft-Affinity
# XP (full/quarter), plays the success/fail/crumble line, manages charges + per-node fails).
function evercraft:gather/resolve

# Dropped claim (another player won the node this tick) -> award nothing, player re-clicks.
execute if score @s ec.gth_outcome matches 0 run return 0

# (No codex first-grant counter in do_catch today — splash has no onboarding hook to fire.)

# Branch.
execute if score @s ec.gth_outcome matches 1 run function evercraft:fishing/splash_nodes/do_catch_success
execute if score @s ec.gth_outcome matches 2.. run function evercraft:fishing/splash_nodes/do_catch_fail

# Despawn on signal (charges-exhausted win OR crumble) — the marker + interaction.
execute if score @s ec.gth_despawn matches 1 run function evercraft:fishing/splash_nodes/do_catch_despawn
