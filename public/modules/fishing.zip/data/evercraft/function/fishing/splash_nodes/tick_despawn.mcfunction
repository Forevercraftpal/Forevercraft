# Splash Node: Check node lifetimes (every 5 seconds)
schedule function evercraft:fishing/splash_nodes/tick_despawn 100t replace

# Existence-gate: skip the scan entirely when no splash nodes exist
execute if entity @e[type=marker,tag=ec.splash_data,limit=1] as @e[type=marker,tag=ec.splash_data] run function evercraft:fishing/splash_nodes/check_despawn
