# === SPLASH · WAVE E1 — UNDERWATER (RIVER/OCEAN FLOOR) SPLASH NODE BRANCH ===
# Run as the player, at the player position. Called ONLY from splash_nodes/check_spawn under the
# tight gate `if predicate evercraft:in_water if score @s ec.caffl_sc matches <unlock>..`.
# A GATED BRANCH of the surface try_spawn — places a node on the river/ocean FLOOR (water-over-
# floor via gather/underwater/scan_floor) instead of the air-over-water surface.
#
# 2026-06-01 (Joseph): same spawn-mechanic rewrite as the surface path — NO spreadplayers (it
# shuns water, so candidates never landed in the body) and a multi-candidate search, plus the
# real nearby-cap count + a short retry on a whole-cycle miss.

# --- Cap: skip if 5+ active splash nodes already within ~24 blocks (count idiom) ---
execute store result score #spl_count ec.temp if entity @e[type=marker,tag=ec.splash_data,distance=..24]
execute if score #spl_count ec.temp matches 5.. run return run function evercraft:fishing/splash_nodes/reset_timer

# --- Underwater splash is OVERWORLD water only (dim 1). Skip nether/end. ---
execute if predicate evercraft:in_nether run return run function evercraft:fishing/splash_nodes/reset_timer
execute if predicate evercraft:in_end run return run function evercraft:fishing/splash_nodes/reset_timer

# --- Multi-candidate floor search (random offsets; can land IN water). ---
scoreboard players set #spl_placed ec.temp 0
scoreboard players set #spl_tries ec.temp 8
function evercraft:fishing/splash_nodes/underwater_place_attempt

# --- Timer: success -> normal cadence; whole-cycle miss -> 5s "keep searching" retry. ---
execute if score #spl_placed ec.temp matches 1 run function evercraft:fishing/splash_nodes/reset_timer
execute unless score #spl_placed ec.temp matches 1 run scoreboard players set @s ec.spl_timer 100
