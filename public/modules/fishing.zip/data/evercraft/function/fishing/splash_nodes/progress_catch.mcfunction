# Splash Node: per-tick catch progress (mirror forage/progress_step).
# Run as a player with an active catch, at player position.

# --- Range + existence check: cancel if too far from the node or it despawned. ---
execute unless entity @e[type=marker,tag=ec.splash_data,distance=..12] run return run function evercraft:fishing/splash_nodes/cancel_catch

# --- Increment progress + update the bar. ---
scoreboard players add @s ec.spl_progress 1
data modify storage evercraft:chanbar bar set value "splash_gather"
execute store result storage evercraft:chanbar id int 1 run scoreboard players get @s ec.chanbar_id
execute store result storage evercraft:chanbar val int 1 run scoreboard players get @s ec.spl_progress
function evercraft:bossbar/chanbar/op_value with storage evercraft:chanbar

# --- Periodic channeling cue (gated FX preset — flute note + bubble that rises as the reel fills) ---
execute if score @s ec.spl_progress matches 15 run function evercraft:fx/node/channel_fishing
execute if score @s ec.spl_progress matches 30 run function evercraft:fx/node/channel_fishing

# --- Complete at the skill-scaled target -> run the (now-deferred) catch resolve. ---
execute if score @s ec.spl_progress >= @s ec.spl_target run function evercraft:fishing/splash_nodes/complete_catch
