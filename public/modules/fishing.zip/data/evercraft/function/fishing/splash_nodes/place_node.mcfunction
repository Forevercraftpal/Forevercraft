# Splash Node: Summon node entities at the water/lava surface
# Run at the surface position (air block just above water/lava)
# Caller passes node_dim (1=overworld water, 2=nether lava) in evercraft:spl_temp.

# Data marker (stores spawn gametime for despawn calculation + dim/biome state)
summon marker ~ ~ ~ {Tags:["ec.splash","ec.splash_data","ec.splash_new"]}
execute store result entity @e[type=marker,tag=ec.splash_new,limit=1,distance=..1] data.spawn_time long 1 run time query gametime

# --- Biome detection (water-relevant surface biomes; fallback "plains") ---
# Uses splash-isolated storage to prevent multiplayer race conditions.
data modify storage evercraft:spl_temp node_biome set value "plains"
execute if predicate evercraft:biome/is_ocean run data modify storage evercraft:spl_temp node_biome set value "ocean"
execute if predicate evercraft:biome/is_river run data modify storage evercraft:spl_temp node_biome set value "river"
execute if predicate evercraft:biome/is_swamp run data modify storage evercraft:spl_temp node_biome set value "swamp"
execute if predicate evercraft:biome/is_jungle run data modify storage evercraft:spl_temp node_biome set value "jungle"
execute if predicate evercraft:biome/is_ice run data modify storage evercraft:spl_temp node_biome set value "ice"
execute if predicate evercraft:biome/is_desert run data modify storage evercraft:spl_temp node_biome set value "desert"
execute if predicate evercraft:biome/is_savanna run data modify storage evercraft:spl_temp node_biome set value "savanna"
execute if predicate evercraft:biome/is_badlands run data modify storage evercraft:spl_temp node_biome set value "badlands"
# Nether (lava nodes)
execute if predicate evercraft:biome/is_crimson_forest run data modify storage evercraft:spl_temp node_biome set value "crimson_forest"
execute if predicate evercraft:biome/is_warped_forest run data modify storage evercraft:spl_temp node_biome set value "warped_forest"
execute if predicate evercraft:biome/is_basalt_deltas run data modify storage evercraft:spl_temp node_biome set value "basalt_deltas"
execute if predicate evercraft:biome/is_soul_sand_valley run data modify storage evercraft:spl_temp node_biome set value "soul_sand_valley"
execute if predicate evercraft:biome/is_nether_wastes run data modify storage evercraft:spl_temp node_biome set value "nether_wastes"

# Store biome + dim on the marker (macro)
function evercraft:fishing/splash_nodes/apply_data with storage evercraft:spl_temp

# B-rarity: stamp data.rarity (1-6) on the same marker from the dim's catch-pool band.
# Reads spl_temp.node_dim; must run while ec.splash_new is still tagged (before line ~31).
function evercraft:gather/rarity/stamp_splash

# C1-tier: stamp data.reqlv + data.areamult (×100) from the node's AREA difficulty (EQ2 tier).
# dim 2 -> Nether (60/250); dim 1 water -> ocean/river/pond via position predicates. Must run
# while ec.splash_new is still tagged. Orthogonal to data.rarity (area diff vs catch-pool rarity).
function evercraft:gather/tier/stamp_splash

# Clean up marker tag
tag @e[type=marker,tag=ec.splash_new,limit=1,distance=..1] remove ec.splash_new

# Interaction entity (rod-clickable hitbox, slightly above the surface)
summon interaction ~ ~0.1 ~ {Tags:["ec.splash","ec.splash_click"],width:0.9f,height:0.5f,response:1b}

# Spawn particle burst (water splash by default; lava sparks for nether nodes)
execute if data storage evercraft:spl_temp {node_dim:2} run particle minecraft:lava ~ ~0.1 ~ 0.25 0.1 0.25 0 6
execute if data storage evercraft:spl_temp {node_dim:2} run particle minecraft:flame ~ ~0.2 ~ 0.2 0.1 0.2 0.01 4
execute unless data storage evercraft:spl_temp {node_dim:2} run particle minecraft:splash ~ ~0.1 ~ 0.3 0.15 0.3 0 8
execute unless data storage evercraft:spl_temp {node_dim:2} run particle minecraft:fishing ~ ~0.15 ~ 0.2 0.1 0.2 0.02 5
