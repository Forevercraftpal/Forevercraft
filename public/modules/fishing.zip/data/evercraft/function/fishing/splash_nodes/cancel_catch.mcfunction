# Splash Node: cancel an active catch (moved too far / node despawned). Run as @s = the player.
data modify storage evercraft:chanbar bar set value "splash_gather"
execute store result storage evercraft:chanbar id int 1 run scoreboard players get @s ec.chanbar_id
function evercraft:bossbar/chanbar/op_hide with storage evercraft:chanbar
scoreboard players set @s ec.spl_picking 0
scoreboard players set @s ec.spl_progress 0
data modify storage evercraft:notify stage.c set value [{text:"The ripples faded before you could land it...",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.fishing_bobber.retrieve master @s ~ ~ ~ 0.4 0.7
