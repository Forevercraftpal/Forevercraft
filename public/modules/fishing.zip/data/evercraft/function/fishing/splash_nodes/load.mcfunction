# === WATER-SPLASH FISHING NODE SYSTEM ===
# Ambient surface "splash" nodes a player rod-clicks for an instant boosted catch.
# Cloned from the ore-node (prospect) engine. Overworld water nodes + nether lava nodes.
# Initialize scoreboards and start the self-scheduling loops.

# --- Core spawning scoreboards (instant-catch design: no minigame state needed) ---
scoreboard objectives add ec.spl_timer dummy "Splash Spawn Timer"
scoreboard objectives add ec.spl_moving dummy "Splash Moving Flag"

# --- Timed-catch channel (splash is no longer instant; mirrors forage, Joseph 2026-06-03) ---
scoreboard objectives add ec.spl_picking dummy "Splash Catching Active"
scoreboard objectives add ec.spl_progress dummy "Splash Catch Progress"
scoreboard objectives add ec.spl_target dummy "Splash Catch Target"
scoreboard objectives add ec.spl_sx dummy "Splash Node X"
scoreboard objectives add ec.spl_sy dummy "Splash Node Y"
scoreboard objectives add ec.spl_sz dummy "Splash Node Z"
# evercraft:splash_gather is now a PER-PLAYER bar pool (WA62-CHANNEL-BAR, 2026-06-22):
# each channeler drives their own evercraft:splash_gather.<id> (see bossbar/chanbar/), so
# there is no shared global bar to create here. The id is allocated lazily on first open.

# --- Start scheduled loops (mirrors prospect/load) ---
schedule function evercraft:fishing/splash_nodes/tick_spawn 1s replace
schedule function evercraft:fishing/splash_nodes/tick_particles 10t replace
schedule function evercraft:fishing/splash_nodes/tick_despawn 100t replace
