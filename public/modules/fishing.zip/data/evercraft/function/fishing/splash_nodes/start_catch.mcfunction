# Splash Node: begin the TIMED catch (mirror forage/start_gather). Splash is no longer instant
# (Joseph 2026-06-03). Run as @s = the player, at the node. Rod-gate already passed in on_click.

# If already catching another node, ignore.
execute if score @s ec.spl_picking matches 1 run return 0

# Mark player as catching.
scoreboard players set @s ec.spl_picking 1
scoreboard players set @s ec.spl_progress 0

# Store node position for range-checking during the catch (nearest splash marker within ~5).
execute store result score @s ec.spl_sx run data get entity @e[type=marker,tag=ec.splash_data,distance=..12,limit=1,sort=nearest] Pos[0] 1
execute store result score @s ec.spl_sy run data get entity @e[type=marker,tag=ec.splash_data,distance=..12,limit=1,sort=nearest] Pos[1] 1
execute store result score @s ec.spl_sz run data get entity @e[type=marker,tag=ec.splash_data,distance=..12,limit=1,sort=nearest] Pos[2] 1

# Skill-scaled catch duration (5s @ Sirencall L0 -> 1.5s @ L100), stored as the completion target.
scoreboard players operation #gd ec.temp = @s ec.caffl_sc
function evercraft:gather/calc_hdur
scoreboard players operation @s ec.spl_target = #gd ec.temp
# Class fishing bonus: Javelin (ec.jv_active, dual-spear), Hoplite (ec.jv_hoplite=1,
# Javelin sub-mode with shield offhand) and Dual Swordsman (ec.ds_active) splash-
# catch 50% faster: target *= 2/3. Floor of 20t (~1s).
scoreboard players set #cls_boost ec.temp 0
execute if entity @s[tag=ec.jv_active] run scoreboard players set #cls_boost ec.temp 1
execute if score @s ec.jv_hoplite matches 1 run scoreboard players set #cls_boost ec.temp 1
execute if entity @s[tag=ec.ds_active] run scoreboard players set #cls_boost ec.temp 1
execute if score #cls_boost ec.temp matches 1 run scoreboard players operation @s ec.spl_target *= #tf_2 ec.var
execute if score #cls_boost ec.temp matches 1 run scoreboard players operation @s ec.spl_target /= #tf_3 ec.var
execute if score #cls_boost ec.temp matches 1 if score @s ec.spl_target matches ..20 run scoreboard players set @s ec.spl_target 20

# Show boss bar (max = the scaled target, so it fills to 100%).
bossbar set evercraft:splash_gather value 0
execute store result bossbar evercraft:splash_gather max run scoreboard players get @s ec.spl_target
bossbar set evercraft:splash_gather visible true
bossbar set evercraft:splash_gather players @s
# Safety auto-dismiss: clear the bar if it lingers 30s (e.g. interrupted mid-catch by death).
schedule function evercraft:bossbar/autodismiss/clear/splash_gather 30s replace

# Start sound — bobber-splash texture + the splash-node "instrument picks up" note (chime B4; the
# splash-node family voice is B MAJOR, high chime + harp — gather-FX identity pass, 2026-06-09).
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.fishing_bobber.splash master @s ~ ~ ~ 0.6 0.9
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.chime master @s ~ ~ ~ 0.4 1.335
