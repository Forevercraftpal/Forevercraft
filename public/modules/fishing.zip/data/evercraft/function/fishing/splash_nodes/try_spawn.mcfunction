# Splash Node: Attempt to spawn a water/lava-surface node near the player
# Run as player, at player position
# Overworld -> water surface node. Nether -> lava surface node (gated).
# 2026-06-01 (Joseph): multi-candidate close search so small pools land a node, with a
# fast "keep searching" retry when a whole cycle misses (a node should appear within ~15s
# of standing by water). Also fixes the nearby-cap (the old `store result … if entity`
# stored 0/1, never a real count, so `matches 2..` never triggered = no cap at all).

# --- Cap: skip if 5+ active splash nodes already within ~24 blocks of the player ---
# (store result + terminal `if entity` = the match COUNT — the standard count idiom.)
execute store result score #spl_count ec.temp if entity @e[type=marker,tag=ec.splash_data,distance=..24]
execute if score #spl_count ec.temp matches 5.. run return run function evercraft:fishing/splash_nodes/reset_timer

# --- Dimension routing: 1 = overworld (water), 2 = nether (lava), 0 = unsupported ---
scoreboard players set #spl_dim ec.temp 0
execute unless predicate evercraft:in_nether run scoreboard players set #spl_dim ec.temp 1
execute if predicate evercraft:in_nether run scoreboard players set #spl_dim ec.temp 2

# Nether lava nodes only when the unlock gate passes:
#   EITHER Sirencall LEVEL 50+ (just under the nether splash area reqLv 60, mirroring how the
#   underwater unlock sits a bit below its area reqLv — 2026-06-02 fix: was ec.caffs_sc>=4, the
#   *stage*, same level-vs-stage slip as the surface gate)
#   OR a held high-rarity / spirit rod.
execute if score #spl_dim ec.temp matches 2 unless score @s ec.caffl_sc matches 50.. unless items entity @s weapon.mainhand minecraft:fishing_rod[custom_data~{artifact:"exquisite_ember_fishing_rod"}] unless items entity @s weapon.mainhand minecraft:fishing_rod[custom_data~{artifact:"mythical_anglers_lip_ripper"}] unless items entity @s weapon.mainhand minecraft:fishing_rod[custom_data~{spirit_tool:"tidecaller"}] run scoreboard players set #spl_dim ec.temp 0

# Unsupported dimension (the end, or nether without the unlock) — skip.
execute if score #spl_dim ec.temp matches 0 run return run function evercraft:fishing/splash_nodes/reset_timer

# --- Multi-candidate placement: try up to 8 nearby spots (CLOSE range so small pools
#     work), placing at the first water/lava surface found. #spl_placed flags success. ---
scoreboard players set #spl_placed ec.temp 0
scoreboard players set #spl_tries ec.temp 8
function evercraft:fishing/splash_nodes/place_attempt

# --- Timer: success -> normal movement-based cadence; a whole-cycle miss -> short 5s
#     "keep searching" retry so a node reliably lands within ~15s of standing by water. ---
execute if score #spl_placed ec.temp matches 1 run function evercraft:fishing/splash_nodes/reset_timer
execute unless score #spl_placed ec.temp matches 1 run scoreboard players set @s ec.spl_timer 500
