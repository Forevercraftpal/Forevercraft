# Splash Node: Render node particles (10-tick schedule)
schedule function evercraft:fishing/splash_nodes/tick_particles 10t replace

# Gate: skip if no players online
execute unless entity @a run return 0

# Existence-gate on markers, and only render for nodes near players (performance)
execute if entity @e[type=marker,tag=ec.splash_data,limit=1] as @e[type=marker,tag=ec.splash_data] at @s if entity @a[distance=..48] run function evercraft:fishing/splash_nodes/render_node
