# Splash Node: Handle node interaction click
# Run as the interaction entity, at the node position.

# Clear the interaction data (consume the click)
data remove entity @s interaction

# Gate: only proceed if the nearest player within ~3 blocks holds a fishing rod in mainhand.
# (No rod = no catch. No tellraw spam — ambient nodes stay quiet for passers-by.)
execute as @p[distance=..3] if items entity @s weapon.mainhand minecraft:fishing_rod at @s run function evercraft:fishing/splash_nodes/start_catch
