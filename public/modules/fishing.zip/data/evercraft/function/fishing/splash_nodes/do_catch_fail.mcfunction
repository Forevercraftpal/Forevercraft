# Splash Node: catch FAIL (outcome 2) OR CRUMBLE (outcome 3). Run as @s, at the player,
# from do_catch. The engine already granted quarter Craft-Affinity/Sirencall XP + played
# the fail/crumble line. do_catch had NO full/half side feed beyond the engine's XP grant
# (no adv.stat_fish / Artisan feed today), so there is no "half" tier to grant here.
# No catch, no crate, no roe consumed, no questline credit, no Dreamy (crossplay C1).

# A distinct "the line slipped" splash so a fail still feels tactile (the success path
# plays its own catch sound). Quiet + dim-agnostic. Plus the family's gentle B-MINOR "miss" dyad
# in the splash-node chime voice (gather-FX identity pass, 2026-06-09) — got away, no sting.
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.fishing_bobber.retrieve master @s ~ ~ ~ 0.5 0.7
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.chime master @s ~ ~ ~ 0.35 1.335
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.chime master @s ~ ~ ~ 0.28 1.587
