# Splash Node: Store biome + dim on the marker entity
# Macro — called with storage evercraft:spl_temp {node_biome:"...", node_dim:N}
$data modify entity @e[type=marker,tag=ec.splash_new,limit=1,distance=..1] data.biome set value "$(node_biome)"
$data modify entity @e[type=marker,tag=ec.splash_new,limit=1,distance=..1] data.dim set value $(node_dim)
