# Splash Node: catch SUCCESS — all success-only rewards. Run as @s, at the player,
# from do_catch on outcome 1. (Engine already granted FULL Craft-Affinity/Sirencall XP
# + played the success line.) do_catch has no full/half side feed beyond the engine XP,
# so there's no "full" tier to grant here — everything below is pure success-only loot.

# Re-read the clicked node's dim from gth_temp (survives the resolve call; do_catch's
# #spl_dim ec.temp was churned by the gather engine's grant path).
execute store result score #spl_dim ec.temp run data get storage evercraft:gth_temp dim

# E1-loot: re-read the underwater flag from gth_temp (also survives resolve). 1 = river/ocean-
# floor node -> DEEP tables (richer fish + ~2x crates, EPIC §6); 0 = surface node -> the existing
# surface tables, byte-for-byte unchanged. Defaults to 0 (do_catch seeded it), so surface nodes
# never false-positive into the deep branch.
execute store result score #spl_uw ec.temp run data get storage evercraft:gth_temp underwater

# --- a) Boosted Aquatic-fish catch (dim-routed x surface/deep), inv-full aware ---
execute store result score #inv_full ec.var run function evercraft:util/check_inv_full
# SURFACE overworld water node -> boosted overworld catch
execute if score #spl_uw ec.temp matches 0 if score #spl_dim ec.temp matches ..1 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:fishing/splash_nodes/catch_overworld
execute if score #spl_uw ec.temp matches 0 if score #spl_dim ec.temp matches ..1 if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:fishing/splash_nodes/catch_overworld
# SURFACE nether lava node -> nether-themed catch
execute if score #spl_uw ec.temp matches 0 if score #spl_dim ec.temp matches 2.. if score #inv_full ec.var matches 0 run loot give @s loot evercraft:fishing/splash_nodes/catch_nether
execute if score #spl_uw ec.temp matches 0 if score #spl_dim ec.temp matches 2.. if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:fishing/splash_nodes/catch_nether
# DEEP (underwater) overworld water node -> richer overworld catch (rarer fish + T7 spirit chance)
execute if score #spl_uw ec.temp matches 1 if score #spl_dim ec.temp matches ..1 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:fishing/splash_nodes/catch_overworld_deep
execute if score #spl_uw ec.temp matches 1 if score #spl_dim ec.temp matches ..1 if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:fishing/splash_nodes/catch_overworld_deep
# DEEP (underwater) nether lava node -> richer nether catch (rarer fish + T7 spirit chance)
execute if score #spl_uw ec.temp matches 1 if score #spl_dim ec.temp matches 2.. if score #inv_full ec.var matches 0 run loot give @s loot evercraft:fishing/splash_nodes/catch_nether_deep
execute if score #spl_uw ec.temp matches 1 if score #spl_dim ec.temp matches 2.. if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:fishing/splash_nodes/catch_nether_deep

# Warn if inventory full
data modify storage evercraft:notify stage.c set value [{text:"Inventory full! Your catch was dropped at your feet.",color:"yellow"}]
scoreboard players set #ndur ec.temp 45
execute if score #inv_full ec.var matches 1 run function evercraft:util/notify/emit
execute if score #inv_full ec.var matches 1 if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bass player @s ~ ~ ~ 1 0.5

# --- b) Active crate roll at the OLD good rate (compensates the 7x passive nerf) ---
# Always-fires crate table — the loot agent tunes the internal odds to ~the pre-nerf base rate.
# E1-loot: underwater (deep) nodes roll crate_deep ("better odds at better crates" — EPIC §6):
# ~2x the crate drop rate + tier weights shifted up. Surface nodes roll the unchanged crate table.
execute store result score #inv_full ec.var run function evercraft:util/check_inv_full
# SURFACE crate (unchanged)
execute if score #spl_uw ec.temp matches 0 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:fishing/splash_nodes/crate
execute if score #spl_uw ec.temp matches 0 if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:fishing/splash_nodes/crate
# DEEP crate (~2x drop, tier-shifted up)
execute if score #spl_uw ec.temp matches 1 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:fishing/splash_nodes/crate_deep
execute if score #spl_uw ec.temp matches 1 if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:fishing/splash_nodes/crate_deep

# Riverpearl — rare antique material (~5% on a splash catch; saw it into antique furniture).
execute store result score #aq_fr ec.temp run random value 1..100
execute if score #aq_fr ec.temp matches 1..5 run function evercraft:decor/antique/give_mat {id:"riverpearl"}

# --- Bait: Magma Roe (offhand) — nether/lava-node booster only ---
# Meaningful ONLY at a nether lava node (#spl_dim 2..). Adds a bonus nether catch + an
# extra crate roll, then consumes one roe. Gated on dim==lava so it's a no-op at water
# nodes; item-gated so non-holders pay nothing. Success-only: must NOT consume a roe on
# a fail (crossplay — don't punish failure twice).
execute if score #spl_dim ec.temp matches 2.. run function evercraft:fishing/bait/magma_roe

# --- Fisher's Questline: feed this SUCCESSFUL catch into the catch_node quest type. ---
# Moved into _success (crossplay seam #3): catch_node quests count successful catches now.
# on_node_hook self-gates on ec.fq_active + the active quest's type, so it is a cheap
# no-op for players without an active catch_node quest.
function evercraft:fishing/questline/on_node_hook

# --- Set-piece: overworld water node during a thunderstorm -> rare charged creeper. ---
# 1/60 roll, gated on dim==water (..1) + thundering weather. Summons at the node.
execute if score #spl_dim ec.temp matches ..1 if predicate evercraft:fishing/questline/events/is_thunderstorm run function evercraft:fishing/questline/events/charged_creeper

# --- Set-piece: nether lava node while a Lava Tide is active -> fire-immune wave. ---
# Gated on dim==lava (2..) + the lava_tide active flag. Spawns a fishable mob wave.
execute if score #spl_dim ec.temp matches 2.. if score #fq_lava_tide ec.var matches 1 run function evercraft:fishing/questline/events/lava_tide/on_node_catch

# --- Sirencall bough consumer hooks (Wave 9) — Crown token + biome-aware C10/C12. ---
# Lava gate = gth_temp.dim==2, re-read FRESH here (the hook fns above churn ec.temp scratch).
# dim 2 IS the reqlv-60 lava tier by construction (gather/tier/stamp_splash keys 60/250 off
# node_dim:2) — do NOT gate on `ec.gth_reqlv matches 60`: post-resolve that score holds the
# EFFECTIVE reqLv after the Home-Turf shave (gather/compute_reqlv subtracts bm_level*4 in
# place), so a Nether Biome-Master's lava node reads 40-56 and would silently miss.
execute store result score #inv_full ec.var run function evercraft:util/check_inv_full
execute store result score #sc_lava ec.temp run data get storage evercraft:gth_temp dim
# C10 Tideknapper — lava swap: a lava-node catch yields +1 nether quartz (the lava form of
# the ocean +1 prismarine bonus; the ocean-prismarine consumer wires in a later wave).
execute if score @s ec.sc_n_c10 matches 1.. if score #sc_lava ec.temp matches 2.. if score #inv_full ec.var matches 0 run loot give @s loot evercraft:bough/sirencall/lava_quartz_bonus
execute if score @s ec.sc_n_c10 matches 1.. if score #sc_lava ec.temp matches 2.. if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:bough/sirencall/lava_quartz_bonus
# C12 Tide Master — lava Mythril upgrade: a lava-node catch grants +1 Mythril Resonance.
# GAP: no champion-fish predicate exists anywhere in the fishing system yet, so EVERY lava
# catch counts as champion for C12; the +1 Iron (non-lava champion) half stays unwired until
# a champion-fish signal lands.
execute if score @s ec.sc_n_c12 matches 1.. if score #sc_lava ec.temp matches 2.. run function evercraft:bough/mastery/find_xp {cls:"sc",amount:200}
# Tidecaller's Vow (Crown owned + Sirencall active): every successful catch mints a token
# (stockpiles in ec.sc_tide_tokens — the codex redeem GUI lands in a later wave), then the
# once-per-8-token bundle nudge. LAST in this section: the milestone fn churns ec.temp.
execute if score @s ec.sc_b_crown matches 1.. if score @s ec.caff_sc matches 1.. run scoreboard players add @s ec.sc_tide_tokens 1
execute if score @s ec.sc_b_crown matches 1.. if score @s ec.caff_sc matches 1.. run function evercraft:bough/sirencall/tide_token_milestone

# --- d) Satisfying catch sound — the B-MAJOR splash-node "catch lift" (gather-FX identity pass,
#     2026-06-09): the dim-specific foley stays as the material accent (fiery fizzle on lava, wet
#     splash on water, both turned down), then a high chime+harp chord in one of THREE randomized
#     voicings — bright and watery, distinct by ear from every land node. B major: B4 1.335 /
#     D#5 1.682 / F#5 2.0. #fx_voice scratch, local to this file. ---
execute if score #spl_dim ec.temp matches 2.. if score @s ec.fx_snd matches 1.. run playsound minecraft:block.lava.extinguish master @s ~ ~ ~ 0.6 1.1
execute if score #spl_dim ec.temp matches ..1 if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.player.splash master @s ~ ~ ~ 0.6 1.0
execute if score @s ec.fx_snd matches 1.. store result score #fx_voice ec.temp run random value 1..3
execute if score @s ec.fx_snd matches 1.. if score #fx_voice ec.temp matches 1 run playsound minecraft:block.note_block.chime master @s ~ ~ ~ 0.55 1.335
execute if score @s ec.fx_snd matches 1.. if score #fx_voice ec.temp matches 1 run playsound minecraft:block.note_block.harp master @s ~ ~ ~ 0.45 1.682
execute if score @s ec.fx_snd matches 1.. if score #fx_voice ec.temp matches 1 run playsound minecraft:block.note_block.harp master @s ~ ~ ~ 0.35 2.0
execute if score @s ec.fx_snd matches 1.. if score #fx_voice ec.temp matches 2 run playsound minecraft:block.note_block.chime master @s ~ ~ ~ 0.55 1.682
execute if score @s ec.fx_snd matches 1.. if score #fx_voice ec.temp matches 2 run playsound minecraft:block.note_block.harp master @s ~ ~ ~ 0.45 1.335
execute if score @s ec.fx_snd matches 1.. if score #fx_voice ec.temp matches 2 run playsound minecraft:block.note_block.harp master @s ~ ~ ~ 0.35 2.0
execute if score @s ec.fx_snd matches 1.. if score #fx_voice ec.temp matches 3 run playsound minecraft:block.note_block.chime master @s ~ ~ ~ 0.55 1.335
execute if score @s ec.fx_snd matches 1.. if score #fx_voice ec.temp matches 3 run playsound minecraft:block.note_block.harp master @s ~ ~ ~ 0.45 2.0
execute if score @s ec.fx_snd matches 1.. if score #fx_voice ec.temp matches 3 run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.25 1.682
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.experience_orb.pickup master @s ~ ~ ~ 0.5 1.2

# --- c) Launch the Dreamy Pull bonus mini-game (source 3 = fishing/splash) ---
# Base catch already awarded above, so this never gates the catch. Success-only.
scoreboard players set @s ec.dp_source 3
function evercraft:dreamy_pull/maybe_trigger
