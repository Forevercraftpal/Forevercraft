# ============================================================
# Crafted-item discovery — fishing catch roll (meals / aquatic chemistry / bait)
# Called from evercraft:fishing/ref/on_catch on every successful catch.
# Run AS the player, AT the player (caller does `at @s`).
#
# Surfaces cook-only meals, Fusion-Funnel aquatic potions, and offhand bait in
# regular fishing so players DISCOVER these craftables exist. Inherently water-gated
# (a catch only happens over water). Each family rolls independently; all three may
# fire on one catch (multi-bonus fishing model). Give-or-drop guarded so nothing voids
# on a full inventory (mirrors aquatic_fish/try_catch + give_meal).
#
# RARITY-SCALED by the angler's rod tier (ec.fq_rod_tier, 1..10 — the fishing source's
# own progression axis). Higher rod tier => higher per-catch chance AND a rarer pool
# bucket. The bands are mutually exclusive (one band fires per catch) and ordered from
# best rod down so a high-tier angler takes the high band; an unset/low rod (=0/1-2)
# takes the common band. Threshold N on a 1..1000 roll = N/10 %.
#   rod 9-10 -> exquisite bucket : meal 3.5% / aqchem 3.0% / bait 4.0%
#   rod 7-8  -> ornate    bucket : meal 3.0% / aqchem 2.5% / bait 3.5%
#   rod 5-6  -> rare      bucket : meal 2.5% / aqchem 2.0% / bait 3.0%
#   rod 3-4  -> uncommon  bucket : meal 2.0% / aqchem 1.5% / bait 2.5%
#   rod ..2  -> common    bucket : meal 1.5% / aqchem 1.0% / bait 2.0%
# ============================================================

execute store result score #inv_full ec.var run function evercraft:util/check_inv_full

# --- MEAL discovery (chance + bucket scale with rod tier) ---
execute store result score #disc_roll ec.temp run random value 1..1000
execute if score @s ec.fq_rod_tier matches 9.. if score #disc_roll ec.temp matches 1..35 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:cooking/meals/pool/exquisite
execute if score @s ec.fq_rod_tier matches 9.. if score #disc_roll ec.temp matches 1..35 if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:cooking/meals/pool/exquisite
execute if score @s ec.fq_rod_tier matches 7..8 if score #disc_roll ec.temp matches 1..30 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:cooking/meals/pool/ornate
execute if score @s ec.fq_rod_tier matches 7..8 if score #disc_roll ec.temp matches 1..30 if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:cooking/meals/pool/ornate
execute if score @s ec.fq_rod_tier matches 5..6 if score #disc_roll ec.temp matches 1..25 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:cooking/meals/pool/rare
execute if score @s ec.fq_rod_tier matches 5..6 if score #disc_roll ec.temp matches 1..25 if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:cooking/meals/pool/rare
execute if score @s ec.fq_rod_tier matches 3..4 if score #disc_roll ec.temp matches 1..20 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:cooking/meals/pool/uncommon
execute if score @s ec.fq_rod_tier matches 3..4 if score #disc_roll ec.temp matches 1..20 if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:cooking/meals/pool/uncommon
execute unless score @s ec.fq_rod_tier matches 3.. if score #disc_roll ec.temp matches 1..15 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:cooking/meals/pool/common
execute unless score @s ec.fq_rod_tier matches 3.. if score #disc_roll ec.temp matches 1..15 if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:cooking/meals/pool/common

# --- AQUATIC CHEMISTRY discovery (aq_* only; chance + bucket scale with rod tier) ---
execute store result score #disc_roll ec.temp run random value 1..1000
execute if score @s ec.fq_rod_tier matches 9.. if score #disc_roll ec.temp matches 1..30 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:alchemy/potions/pool_aq/exquisite
execute if score @s ec.fq_rod_tier matches 9.. if score #disc_roll ec.temp matches 1..30 if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:alchemy/potions/pool_aq/exquisite
execute if score @s ec.fq_rod_tier matches 7..8 if score #disc_roll ec.temp matches 1..25 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:alchemy/potions/pool_aq/ornate
execute if score @s ec.fq_rod_tier matches 7..8 if score #disc_roll ec.temp matches 1..25 if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:alchemy/potions/pool_aq/ornate
execute if score @s ec.fq_rod_tier matches 5..6 if score #disc_roll ec.temp matches 1..20 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:alchemy/potions/pool_aq/rare
execute if score @s ec.fq_rod_tier matches 5..6 if score #disc_roll ec.temp matches 1..20 if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:alchemy/potions/pool_aq/rare
execute if score @s ec.fq_rod_tier matches 3..4 if score #disc_roll ec.temp matches 1..15 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:alchemy/potions/pool_aq/uncommon
execute if score @s ec.fq_rod_tier matches 3..4 if score #disc_roll ec.temp matches 1..15 if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:alchemy/potions/pool_aq/uncommon
execute unless score @s ec.fq_rod_tier matches 3.. if score #disc_roll ec.temp matches 1..10 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:alchemy/potions/pool_aq/common
execute unless score @s ec.fq_rod_tier matches 3.. if score #disc_roll ec.temp matches 1..10 if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:alchemy/potions/pool_aq/common

# --- BAIT discovery (single rarity-weighted pool; hit-chance scales with rod tier) ---
execute store result score #disc_roll ec.temp run random value 1..1000
execute if score @s ec.fq_rod_tier matches 9.. if score #disc_roll ec.temp matches 1..40 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:fishing/bait/pool
execute if score @s ec.fq_rod_tier matches 9.. if score #disc_roll ec.temp matches 1..40 if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:fishing/bait/pool
execute if score @s ec.fq_rod_tier matches 7..8 if score #disc_roll ec.temp matches 1..35 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:fishing/bait/pool
execute if score @s ec.fq_rod_tier matches 7..8 if score #disc_roll ec.temp matches 1..35 if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:fishing/bait/pool
execute if score @s ec.fq_rod_tier matches 5..6 if score #disc_roll ec.temp matches 1..30 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:fishing/bait/pool
execute if score @s ec.fq_rod_tier matches 5..6 if score #disc_roll ec.temp matches 1..30 if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:fishing/bait/pool
execute if score @s ec.fq_rod_tier matches 3..4 if score #disc_roll ec.temp matches 1..25 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:fishing/bait/pool
execute if score @s ec.fq_rod_tier matches 3..4 if score #disc_roll ec.temp matches 1..25 if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:fishing/bait/pool
execute unless score @s ec.fq_rod_tier matches 3.. if score #disc_roll ec.temp matches 1..20 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:fishing/bait/pool
execute unless score @s ec.fq_rod_tier matches 3.. if score #disc_roll ec.temp matches 1..20 if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:fishing/bait/pool
