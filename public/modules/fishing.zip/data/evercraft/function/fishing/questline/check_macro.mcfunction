# ============================================================
# The Fisher's Questline — Check (macro body, dispatch on quest.type)
# ============================================================
# Called `with storage evercraft:fq_cur o`, o = current quest
#   {id,title,desc,type,target,count,reward,reward_amt,chapter}.
# Sets #fq_satisfied ec.temp to 1 iff the active quest's completion condition is
# met. Run as @s = the player.
#
# A macro can't branch on an int comparison inline, so we expose the comparison
# inputs to ec.temp and route the per-TYPE decision to a tiny helper file:
#   - #fq_count ec.temp     = quest.count
#   - ec.fq_prog (player)   = progress this quest (catch hooks / event flags)
#   - quest.target          = which mirror score the milestone helper reads
# The helper at check_type/$(type) sets #fq_satisfied ec.temp.

# Expose the threshold for the helpers to compare against.
$scoreboard players set #fq_count ec.temp $(count)

# Milestone needs the target mirror score; load it for the milestone helper.
# (Harmless for non-milestone types — the helper ignores it.)
function evercraft:fishing/questline/check_milestone_read with storage evercraft:fq_cur o

# Per-type decision (sets #fq_satisfied ec.temp). $(type) is one of:
#   catch_any catch_crate catch_node catch_aquatic event special milestone
$function evercraft:fishing/questline/check_type/$(type)
