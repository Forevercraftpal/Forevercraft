# ============================================================
# The Fisher's Questline — One-time scoreboard objective declarations.
# Split from questline/load so the per-/reload "Objective already exists"
# warnings only fire once (story/load/declare_objectives pattern, P6).
# Gated by `#fq_loaded ec.var matches 1` — set at the bottom of this file.
# ============================================================

# === CORE LINEAR-POINTER SCOREBOARDS ===
# ec.fq_active — 0/1, has this player started the questline?
scoreboard objectives add ec.fq_active dummy "Fisher Questline Active"
# ec.fq_quest — current quest index, 1..N. The ONLY linear pointer.
#   WRITER: questline/start (sets 1) + questline/advance (+1, clamped at N).
scoreboard objectives add ec.fq_quest dummy "Fisher Quest Index"
# ec.fq_prog — progress within the current quest.
#   WRITER (increment): the catch hooks (on_catch_hook / node / aquatic) — the
#     single incrementer. WRITER (reset to 0): questline/start + questline/advance.
scoreboard objectives add ec.fq_prog dummy "Fisher Quest Progress"
# ec.fq_done — lifetime completed quest count (overview + total_done milestone).
#   WRITER: questline/advance (+1) + questline/start (sets 0 on first start).
scoreboard objectives add ec.fq_done dummy "Fisher Quests Done"
# ec.fq_title — highest Master-Angler title tier earned, 0..N.
#   WRITER: questline/reward (title branch sets it to the reward tier).
scoreboard objectives add ec.fq_title dummy "Master-Angler Title Tier"
# ec.fq_crates_seen — crate-credit cursor: snapshot of fc.total_crates that the
#   catch_crate hook has already credited to ec.fq_prog. The delta
#   (fc.total_crates - this) is the count of newly-received crates to credit.
#   WRITER: questline/on_catch_hook (re-syncs to fc.total_crates each catch) +
#   questline/start (seeds it so pre-questline crates never retro-count).
scoreboard objectives add ec.fq_crates_seen dummy "FQ Crate Credit Cursor"

# === MILESTONE MIRROR SCOREBOARDS (read-only to the tick chain) ===
# The `milestone` quest type reads one of these by quest.target string. They
# are engine-owned mirrors updated by the source systems' event hooks (NOT by
# the questline tick chain — keeps one-writer intact for the linear pointers).
# Objective names are ec.fq_<target> so check_milestone_read can resolve them
# by macro string. WRITER of each mirror = the named source system's hook.
#   target "sirencall_stage" -> ec.fq_sirencall_stage  (Sirencall system hook)
#   target "rod_tier"        -> ec.fq_rod_tier         (rod-tier system hook)
#   target "total_done"      -> ec.fq_done             (lifetime counter; reused)
scoreboard objectives add ec.fq_sirencall_stage dummy "FQ Sirencall Stage Mirror"
scoreboard objectives add ec.fq_rod_tier dummy "FQ Rod Tier Mirror"

# === COMPLETION SENTINEL ===
# ec.fq_complete — 0/1, set once when the player finishes the final quest so the
#   "questline complete!" tellraw fires exactly once. WRITER: questline/advance.
scoreboard objectives add ec.fq_complete dummy "Fisher Questline Complete"

# Mark declarations done so re-/reload skips this file.
scoreboard players set #fq_loaded ec.var 1
