# ============================================================
# The Fisher's Questline — Advantage-Tree Credit (ADDITIVE layer, Joseph 2026-06-01)
# Phase-3 RE-TUNE (Council review 2026-06-01): A1 clobber fix + A2 re-scale.
# ============================================================
# Run as @s = the player, called from advance.mcfunction AFTER the existing `reward` call and
# BEFORE the pointer bump. Grants progress toward the FISHING advantage tree (tree id 9, level
# adv.fishing) via the engine's NORMAL level-up gate — never a raw `scoreboard set adv.fishing`.
# req_xp / prestige / do_prestige stay fully intact. ADDITIVE: does NOT touch any existing
# per-quest reward (craft-affinity / coins / crate / gear / trophy via reward_macro), and does
# NOT inflate item/loot (no extra drops, just tree progress).
#
# ── A1 — WHY THIS REALIZES LEVELS IN-TICK (the load-bearing fix) ───────────────────────────────
# The FIRST shipped version did `adv.stat_fish += <credit>`. That was DEAD ON ARRIVAL: the 5s
# stat sync (advantage/track/sync_stats_player:11-12) hard-`=`-recomputes adv.stat_fish from
# (adv.fish_ct - adv.base_fish), WIPING the `+=` credit within 5s. Cooking/Chemistry/Forging/
# Build are immune (their stats are pure `+=` accumulators, never `=`-reassigned) — only
# adv.stat_fish (and adv.stat_mobs) get clobbered. So we DON'T deposit lifetime stat; we bank
# whole LEVELS in-tick via the normal gate (the Tinkering grant_one precedent). The level
# scoreboard adv.fishing is PERMANENT — only ever +1 (GUI levelup / grant_credit_level) or set 1
# (prestige); the sync chain NEVER touches it — so a banked level is immune to the stat clobber.
#
# ── A2 — RE-SCALED CURVE (flat mult/2 per quest, Pioneer-baseline ──────────────────────────────
# The credit is a FLAT per-quest amount accumulated into a DEDICATED, sync-immune reservoir
# `adv.fq_credit` (one-writer: ONLY this function writes it via add, and grant_credit_level
# subtracts the spent req_stat). Each quest adds the flat credit; drain_credit then realizes as
# many whole levels as the reservoir can afford this quest (each level costs (level+1)*2000 at
# Pioneer baseline, difficulty-scaled by apply_difficulty inside calc/fishing).
#
# The previous header asserted a FALSE "+12000 buys fewer levels as cost climbs" model with
# 12000/3000/1500 ramp tiers — that reasoning never held under a non-subtracted threshold and
# over-fed ~2x (saturating by ~quest 2, esp. on Newcomer ÷10). Phase-3 uses ONE flat credit and
# lets the ENGINE produce the gentle-ramp OUTPUT (a flat reservoir input clears a SHRINKING
# fraction of the growing (level+1)*2000 wall per quest).
#
# Unified pack-wide rule: flat per-quest credit = mult / 2. For fishing mult=2000 -> credit=1000.
#   * Pioneer baseline (req_stat unscaled), cumulative-to-level-L stat = mult * L*(L+1)/2:
#       q12  -> reservoir fed 12000 = cum(L3) = 2000*3*4/2 -> tree rises ~3 levels by quest 12 ✓
#       q250 -> reservoir fed 250000 = cum(L~15.3) ≈ 0.47 of one prestige (cum(L25)=650000) —
#               deliberately UNDER one prestige across the full ~250-quest line: fishing is the
#               longest line, so the "~250 quests ≈ one prestige" modesty anchor binds hardest;
#               the COMPLETION CAPSTONE (finish -> tree_capstone) supplies the actual prestige.
#   * Newcomer (÷10) / Adventurer (÷5): apply_difficulty divides req_stat, so the SAME flat
#     credit realizes levels ~10x / ~5x faster — Newcomers level the tree fast, by design.
#
# `ec.fq_quest` is NOT read here anymore (the ramp is engine-produced, not index-tiered).

# --- 1) Add this quest's flat credit to the sync-immune reservoir (one-writer add). ---
scoreboard players add @s adv.fq_credit 1000

# --- 2) Drain the reservoir into whole Fishing levels (bounded ≤25, terminates on no-progress).
#        Seed the hard step ceiling first (one full climb's worth). ---
scoreboard players set #fq_drain_steps adv.temp 25
function evercraft:fishing/questline/drain_credit
