# FQ check helper — catch_aquatic (a specific Aquatic/spirit fish). Progress quest.
# The grant fns (fishing/aquatic_fish/grant/<type> + cooking/spirit_fish/grant/<type>)
# increment ec.fq_prog ONLY when the quest.target fish_type matches the catch, so
# the engine just compares ec.fq_prog >= quest.count.
scoreboard players set #fq_satisfied ec.temp 0
execute if score @s ec.fq_prog >= #fq_count ec.temp run scoreboard players set #fq_satisfied ec.temp 1
