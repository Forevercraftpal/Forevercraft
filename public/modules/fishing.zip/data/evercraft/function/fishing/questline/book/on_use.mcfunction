# ============================================================
# The Fisher's Questline — Angler's Codex right-click handler
# ============================================================
# Triggered by the using_item advancement (fishing_book/on_use.json) when the
# player right-clicks a minecraft:book carrying custom_data{fishing_book:true}.
# Clone of cooking/questline/book/on_use (which cloned tome/on_use): the
# advancement stays granted briefly to prevent spam, then is revoked by a
# scheduled cooldown reset. Opens the Fisher's Path overview/tab.
# Run as @s = the player.

# Only fire from the mainhand (a book sitting in a container shouldn't trigger).
execute unless items entity @s weapon.mainhand minecraft:book[custom_data~{fishing_book:true}] run return fail

# Cooldown guard: schedule advancement revoke after ~1s (always, regardless of
# outcome) so a single right-click opens the page exactly once.
tag @s add ec.fishbook_cd
schedule function evercraft:fishing/questline/book/reset_cooldown 20t append

# Open the Fisher's Path questline panel (#3/D1 floating GUI; was the overview chat wall).
scoreboard players set @s ec.gq_qln_ln 1
function evercraft:codex/hub/grand_quests/qln/book_open
