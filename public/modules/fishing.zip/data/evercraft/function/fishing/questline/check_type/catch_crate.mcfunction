# FQ check helper — catch_crate (a crate was fished up). Progress quest.
# The on_catch_hook only increments ec.fq_prog for this quest when a crate
# actually dropped, so the engine just compares ec.fq_prog >= quest.count.
scoreboard players set #fq_satisfied ec.temp 0
execute if score @s ec.fq_prog >= #fq_count ec.temp run scoreboard players set #fq_satisfied ec.temp 1
