# ============================================================
# The Fisher's Questline — Load (scoreboard objective declarations)
# ============================================================
# A strictly-linear, data-driven quest line (q1..N in order, one active
# quest at a time). Mirrors story mode's chapter/step flow but as a flat
# 250-quest sequence. Called from fishing/load (or init) on /reload.
#
# Declarations are guarded by #fq_loaded ec.var so subsequent /reloads
# skip the re-declaration spam ("Objective already exists"), matching the
# story/load/declare_objectives polish pattern (2026-05-28 P6).
#
# After declaring objectives, this fn ALWAYS (re)loads the registry, since
# the quest data storage is NOT persisted across /reload.

# === ONE-TIME OBJECTIVE DECLARATIONS (skipped on subsequent /reloads) ===
execute unless score #fq_loaded ec.var matches 1 run function evercraft:fishing/questline/declare_objectives

# === REGISTRY (re)load — storage is volatile across /reload, must re-run ===
function evercraft:fishing/questline/registry/load
