# ============================================================
# The Fisher's Questline — Registry batch 11 (q221..q236)
# ============================================================
# Appends Chapter 13 — "The Void Below" — onto storage
# evercraft:fq_registry quests. Called by registry/load AFTER batch 10,
# in id order (id=221 first => list index 220), contiguous, so list-position
# == ec.fq_quest-1.
#
# Quest object schema (the engine reads these exact fields):
#   {id:int, title:string, desc:string, type:string, target:string,
#    count:int, reward:string, reward_amt:int, chapter:int}
#
# CH13 theme: the hardest deep — the apex Warden. Bleak, void-and-cinder
# tone, apex-difficulty grind. The chapter centers on q230, the Cinderbound
# Warden — a fire-immune Warden risen from a Lava Tide (special set-piece,
# count 1, apex). q235 lands title tier 10, "Voidcaster".
#
# *** SCHEMA CONSTRAINT (the `target` field is SHARED) ***
#   - condition side: catch_aquatic (fish_type), event/special (flag)
#   - reward side:    crate (tier name)
# special / event / catch_aquatic CONSUME target, so they reward coins only.
# Item rewards (crate) ride only catch_any / catch_node here (target free).
# No gear/trophy in this chapter (no artifact assigned to CH13).
# ------------------------------------------------------------

# --- Chapter 13: The Void Below --------------------------------------------

# q221 — open the chapter on a huge splash-node grind. catch_node leaves target
#   free, so target doubles as the crate-reward TIER (exquisite).
data modify storage evercraft:fq_registry quests append value {id:221,title:"The Floor Drops Out",desc:"Catch 65 fish from splash nodes. Below the last current there is only the void, and it is patient.",type:"catch_node",target:"exquisite",count:65,reward:"crate",reward_amt:1,chapter:13,skippable:0}

# q222 — any-catch backbone, the apex climb begins. catch_any leaves target free.
data modify storage evercraft:fq_registry quests append value {id:222,title:"Down Where Nothing Looks Back",desc:"Reel in 150 catches in all. The water here gives nothing freely. Take it anyway.",type:"catch_any",target:"",count:150,reward:"coins",reward_amt:1,chapter:13,skippable:0}

# q223 — voidfin hunt (spirit fish reuse). catch_aquatic uses target -> coins only.
data modify storage evercraft:fq_registry quests append value {id:223,title:"A Fin in the Dark",desc:"Land a Voidfin from the lightless deep. It does not glimmer. It swallows the light around it.",type:"catch_aquatic",target:"voidfin",count:1,reward:"coins",reward_amt:1,chapter:13,skippable:0}

# q224 — splash-node grind, bigger. catch_node target free -> crate tier (exquisite).
data modify storage evercraft:fq_registry quests append value {id:224,title:"Reader of the Empty Deep",desc:"Catch 65 fish from splash nodes. Read the water you cannot see. The void rewards the unflinching.",type:"catch_node",target:"exquisite",count:65,reward:"crate",reward_amt:1,chapter:13,skippable:0}

# q225 — any-catch backbone climb.
data modify storage evercraft:fq_registry quests append value {id:225,title:"The Long Cold Cast",desc:"Reel in 150 catches in all. Your hands go numb before the deep does.",type:"catch_any",target:"",count:150,reward:"coins",reward_amt:1,chapter:13,skippable:0}

# q226 — *** SET-PIECE: a second Lava Tide *** (event flag), cinder flavor before
#   the Warden. event uses target for the flag -> reward coins (count 1 only).
data modify storage evercraft:fq_registry quests append value {id:226,title:"Where the Cinders Rise",desc:"Cast into a Lava Tide once more. Something stirs in the ash now, and it remembers the surface.",type:"event",target:"lava_tide",count:1,reward:"coins",reward_amt:1,chapter:13,skippable:0}

# q227 — splash-node grind. catch_node target free -> crate tier (mythical, for the crate).
data modify storage evercraft:fq_registry quests append value {id:227,title:"The Last Honest Water",desc:"Catch 55 fish from splash nodes. There is no shallow left to retreat to. Only down.",type:"catch_node",target:"mythical",count:55,reward:"crate",reward_amt:1,chapter:13,skippable:0}

# q228 — any-catch backbone, near the spike.
data modify storage evercraft:fq_registry quests append value {id:228,title:"Counting in the Black",desc:"Reel in 140 catches in all. You stopped fishing for supper a long way back.",type:"catch_any",target:"",count:140,reward:"coins",reward_amt:1,chapter:13,skippable:0}

# q229 — splash-node grind, last node climb before the Warden. catch_node target
#   free -> crate tier (mythical).
data modify storage evercraft:fq_registry quests append value {id:229,title:"On the Cinderbound Threshold",desc:"Catch 55 fish from splash nodes. The ash-water hisses where the void meets the fire. Steady the line.",type:"catch_node",target:"mythical",count:55,reward:"crate",reward_amt:1,chapter:13,skippable:0}

# q230 — *** APEX SET-PIECE: The Cinderbound Warden *** (special flag).
#   A fire-immune Warden risen from a Lava Tide. special uses target for the
#   flag -> reward coins (count 1 only; count>1 risks soft-lock at the apex).
data modify storage evercraft:fq_registry quests append value {id:230,title:"The Cinderbound Warden",desc:"From the Lava Tide rises the Cinderbound Warden, which the fire could not unmake. Reel it from the cinders. Do not look at it long.",type:"special",target:"fireproof_warden",count:1,reward:"coins",reward_amt:1,chapter:13,skippable:0}

# q231 — after the apex: a sobered splash-node grind. catch_node target free ->
#   crate tier (mythical).
data modify storage evercraft:fq_registry quests append value {id:231,title:"In the Cinderbound's Wake",desc:"Catch 55 fish from splash nodes. The deep is quieter now. That is not the same as safe.",type:"catch_node",target:"mythical",count:55,reward:"crate",reward_amt:1,chapter:13,skippable:0}

# q232 — any-catch backbone.
data modify storage evercraft:fq_registry quests append value {id:232,title:"Nothing Left to Spook",desc:"Reel in 140 catches in all. You have hauled worse than this up from the dark. Keep hauling.",type:"catch_any",target:"",count:140,reward:"coins",reward_amt:1,chapter:13,skippable:0}

# q233 — voidfin hunt again (spirit fish reuse). catch_aquatic uses target -> coins.
data modify storage evercraft:fq_registry quests append value {id:233,title:"Twin in the Void",desc:"Land another Voidfin. Where one swims unseen, others wait. They are not lonely down here.",type:"catch_aquatic",target:"voidfin",count:1,reward:"coins",reward_amt:1,chapter:13,skippable:0}

# q234 — the deepest splash-node grind in the chapter. catch_node target free ->
#   crate tier (mythical).
data modify storage evercraft:fq_registry quests append value {id:234,title:"The Hardest Hundred",desc:"Catch 60 fish from splash nodes. The void floor. There is nowhere deeper to read. You read it anyway.",type:"catch_node",target:"mythical",count:60,reward:"crate",reward_amt:1,chapter:13,skippable:0}

# q235 — title tier 10: Voidcaster. catch_any leaves target free; reward title
#   reads only reward_amt. target stays "".
data modify storage evercraft:fq_registry quests append value {id:235,title:"Voidcaster",desc:"Reel in 140 catches in all. They name the few who fish the void below: Voidcaster. The title is earned in the dark.",type:"catch_any",target:"",count:140,reward:"title",reward_amt:10,chapter:13,skippable:0}

# q236 — chapter closer: a final huge any-catch backbone. catch_any leaves
#   target free; reward coins.
data modify storage evercraft:fq_registry quests append value {id:236,title:"Past the Void Below",desc:"Reel in 150 catches in all. You have fished the bottom of the world and come back up. Something still waits past it.",type:"catch_any",target:"",count:150,reward:"coins",reward_amt:1,chapter:13,skippable:0}

# ------------------------------------------------------------
# HAND-OFF TO load_batch_12 (q237..):
#   - This batch ends at id=236. The next batch's FIRST quest MUST be id=237
#     (list index 236) and be appended immediately after q236, contiguously.
#   - registry/load calls batches in order; add the load_batch_11 call to
#     registry/load when this batch is wired (main thread owns that). Do NOT
#     renumber this batch.
#
# SET-PIECE WIRING THIS BATCH ASSUMES (other agents own these hooks):
#   - q226 event lava_tide / q230 special fireproof_warden: the event/special
#     set-piece fns increment ec.fq_prog (gated to the matching active quest)
#     then call evercraft:fishing/questline/check, per the catch/event hook
#     contract. fireproof_warden is the apex; count 1 only.
#   - q223/q233 catch_aquatic voidfin: the spirit_fish/grant/voidfin catch hook
#     increments ec.fq_prog (gated to the active quest) then calls questline/check.
# ------------------------------------------------------------
