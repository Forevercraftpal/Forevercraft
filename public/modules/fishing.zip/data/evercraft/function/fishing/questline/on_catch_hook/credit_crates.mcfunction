# ============================================================
# The Fisher's Questline — catch_crate credit (delta of fc.total_crates)
# ============================================================
# Called from on_catch_hook ONLY when the active quest is catch_crate AND the
# crate cursor (ec.fq_crates_seen) lags the lifetime counter (fc.total_crates).
# Adds the number of newly-received crates to ec.fq_prog. Run as @s = player.
#
# fq_prog += (fc.total_crates - ec.fq_crates_seen). The caller re-syncs
# ec.fq_crates_seen = fc.total_crates immediately after, so each crate is
# credited exactly once. #fq_count ec.temp is a reusable global temp (not the
# milestone count here — borrowed as scratch for the delta).
scoreboard players operation #fq_crate_delta ec.temp = @s fc.total_crates
scoreboard players operation #fq_crate_delta ec.temp -= @s ec.fq_crates_seen
scoreboard players operation @s ec.fq_prog += #fq_crate_delta ec.temp
