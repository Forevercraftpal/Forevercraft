# FQ reward — title (Master-Angler title tier). @s = player.
# The tier is in #fq_reward_amt ec.temp. Engine just bumps ec.fq_title to the
# tier (never downgrades) + a generic tellraw. The reward agent owns the title
# NAMES + any cosmetic grant keyed off ec.fq_title.
execute if score #fq_reward_amt ec.temp > @s ec.fq_title run scoreboard players operation @s ec.fq_title = #fq_reward_amt ec.temp
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"light_purple"},{text:"New Master-Angler title earned!",color:"light_purple",bold:true},{text:" ✦",color:"light_purple"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 0.7 1.1
