# Master-Angler title tier 1 — "Bait Novice". @s = player.
title @s times 8 50 12
title @s title [{text:"✦ ",color:"gray"},{text:"Bait Novice",color:"gray"},{text:" ✦",color:"gray"}]
title @s subtitle {text:"Master-Angler title earned",color:"dark_gray",italic:true}
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gray"},{text:"Master-Angler title earned: ",color:"white"},{text:"Bait Novice",color:"gray",bold:true},{text:" ✦",color:"gray"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 0.7 1.0
