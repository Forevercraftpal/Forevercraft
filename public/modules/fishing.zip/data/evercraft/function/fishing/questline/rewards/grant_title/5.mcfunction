# Master-Angler title tier 5 — "Stormhauler". @s = player.
title @s times 10 55 14
title @s title [{text:"✦ ",color:"gold"},{text:"Stormhauler",color:"gold"},{text:" ✦",color:"gold"}]
title @s subtitle {text:"Master-Angler title earned",color:"dark_gray",italic:true}
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"Master-Angler title earned: ",color:"white"},{text:"Stormhauler",color:"gold",bold:true},{text:" ✦",color:"gold"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 0.9 1.2
