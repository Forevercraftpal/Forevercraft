# ============================================================
# The Fisher's Questline — Book OBTAIN trigger (fishing milestone)
# ============================================================
# Run as @s = the player. Called from the ONE gate-first line spliced into
# fishing/questline/advance, fired the moment the player completes their FIRST
# Fisher's quest (ec.fq_done crosses to 1).
#
# WHY a milestone, NOT the first-rod hook (S8): the first-rod hook
# (fishing/questline/on_first_rod) already STARTS the questline — handing the
# book there would couple "start the line" and "obtain the book" into the same
# instant, before the player has done any fishing. The locked design (Wave 5 /
# WAVE-PLAN) says obtain on a fishing MILESTONE OR craft, NOT the first-rod hook.
# Completing the first quest is the cleanest, robust milestone: it proves the
# player is engaged, and ec.fq_done is the engine's own lifetime counter (read
# only — this fn writes none of fishing/'s engine objectives).
#
# DUP-GUARDED: book/give is itself inventory-dup-guarded, AND the caller gates on
# "ec.fq_done crossed to exactly 1" so this only runs at the single milestone.
# book/give also fires the one-time fusion OFFER (gated by the ec.gq_offered
# latch), so obtaining the book is what triggers the convergence prompt.

# Hand the player their Angler's Codex (book/give dup-guards on inventory + fires
# the gq/offer_prompt fusion offer once via the ec.gq_offered latch).
function evercraft:fishing/questline/book/give
