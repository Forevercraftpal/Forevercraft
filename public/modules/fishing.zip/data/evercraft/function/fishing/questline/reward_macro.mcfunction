# ============================================================
# The Fisher's Questline — Reward dispatch (macro body)
# ============================================================
# Called `with storage evercraft:fq_cur o`, o = the completed quest
#   {...,reward,reward_amt,target,...}. Exposes the reward args to ec.temp /
# storage and routes to reward_type/$(reward). Run as @s = the player.
#
# Shared args the helpers consume:
#   #fq_reward_amt ec.temp = quest.reward_amt (coins amount / title tier)
#   storage evercraft:fq_cur o.target = item id (gear/trophy) or crate tier name
$scoreboard players set #fq_reward_amt ec.temp $(reward_amt)

# Dispatch on reward type: coins | crate | title | gear | trophy
$function evercraft:fishing/questline/reward_type/$(reward) with storage evercraft:fq_cur o
