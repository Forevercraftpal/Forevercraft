# ============================================================
# The Fisher's Questline — realize ONE Fishing tree level from the credit reservoir (in-tick)
# ============================================================
# Run as @s = the player, called repeatedly from fishing/questline/tree_credit. Hardcoded to
# the FISHING tree (id 9, adv.fishing) — no macro storage needed since there is exactly one tree.
# Clone of tinkering/tree_sample/grant_one, with TWO fishing-specific differences:
#   (1) It is gated on a DEDICATED, sync-immune reservoir `adv.fq_credit` (the questline's
#       one-writer accumulator) instead of pushing the lifetime stat directly. This is the
#       load-bearing A1 clobber fix: advantage/track/sync_stats_player:11-12 hard-`=`-recomputes
#       adv.stat_fish from (adv.fish_ct - adv.base_fish) every 5s, which would WIPE any `+=`
#       credit on adv.stat_fish within 5s. We instead REALIZE whole LEVELS in-tick (Tinkering
#       precedent). The level scoreboard adv.fishing is PERMANENT — only ever +1 (GUI levelup /
#       this) or set 1 (prestige); the sync chain NEVER touches it — so a banked level survives
#       the stat clobber regardless of what happens to adv.stat_fish afterward.
#   (2) After the levelup it SPENDS the consumed req_stat out of adv.fq_credit, so the reservoir
#       is a real spent-on-purpose budget (the spec's "feed the gate" intent), fully decoupled
#       from the clobbered lifetime adv.stat_fish.
#
# Returns 0 (no level realized) if: at the cap (25), OR the reservoir can't cover this level's
# req_stat. Otherwise realizes exactly ONE level and returns 1. The caller bounds the loop.
#
# How it stays additive / never-reduces (mirrors grant_one):
#   * XP: grant exactly req_xp vanilla levels, which advantage/levelup/fishing deducts right back
#     -> NET ZERO real XP (the player is not charged; the gate is merely satisfied).
#   * Stat: adv.stat_fish is a multi-writer grind counter; we raise it to req_stat ONLY when
#     below (shortfall fill), never reduce — and it is re-derived by the 5s sync anyway, so this
#     fill is only to satisfy the levelup gate in THIS tick. The PERMANENT outcome is the +1 level.
#   * Cap: skip entirely at level 25 (the tree's max) so a near-max veteran is never spammed.

# --- Cap guard: never push past the tree's max level (25). Silent at the cap. ---
execute if score @s adv.fishing matches 25.. run return 0

# --- 1) Compute this level's requirements (sets adv.req_xp + adv.req_stat for the CURRENT level,
#        difficulty-scaled on req_stat by apply_difficulty inside calc). ---
function evercraft:advantage/calc/fishing

# --- 2) Reservoir gate: only realize a level if the credit budget covers this level's req_stat.
#        (At Pioneer baseline a single quest's +1000 is < one level for L>=0, so the reservoir
#        accumulates across quests until it crosses the (level+1)*2000 wall — exactly the spec's
#        gentle ramp.) Returns 0 when short, so the caller's loop stops cleanly. ---
execute unless score @s adv.fq_credit >= @s adv.req_stat run return 0

# --- 3) Top up vanilla XP to cover req_xp (levelup deducts it again -> net zero). ---
execute store result storage evercraft:advantage xp_cost int 1 run scoreboard players get @s adv.req_xp
function evercraft:fishing/questline/topup_xp with storage evercraft:advantage

# --- 4) Fill the grind wall: raise adv.stat_fish to req_stat ONLY if currently below (never
#        reduce). Needed only to satisfy the levelup gate THIS tick; the 5s sync re-derives it. ---
execute if score @s adv.stat_fish < @s adv.req_stat run scoreboard players operation @s adv.stat_fish = @s adv.req_stat

# --- 5) Spend the consumed budget out of the reservoir BEFORE the levelup (calc/fishing inside
#        levelup recomputes req for the SAME current level, so req_stat is still this level's). ---
scoreboard players operation @s adv.fq_credit -= @s adv.req_stat

# --- 6) Run the NORMAL level-up (deducts req_xp, +1 adv.fishing, milestones, cosmetics, caps@25),
#        PERMANENT + sync-immune. SILENT for questline-banked levels (Joseph 2026-06-01): the
#        ec.fq_silent tag suppresses the per-level "Fishing leveled up to N" fanfare in
#        advantage/levelup/fishing — that announces the ADVANTAGE-tree level, which confuses against
#        the Sirencall caff level the player watches. Milestones/tokens/cosmetics still fire. ---
tag @s add ec.fq_silent
function evercraft:advantage/levelup/fishing
tag @s remove ec.fq_silent
return 1
