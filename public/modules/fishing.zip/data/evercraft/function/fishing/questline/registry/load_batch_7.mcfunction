# ============================================================
# The Fisher's Questline — Registry batch 7 (q154..q174)
# ============================================================
# Chapter 9 — "The Long Haul": the heaviest backbone in the line.
# The biggest counts, the slog before the apex. NO artifact, NO title
# (titles are q150 & q190, both outside this chapter).
# Appends quests 154..174 onto storage evercraft:fq_registry quests.
# Called by registry/load AFTER load_batch_6. MUST append in id order
# (id=154 first => list index 153), contiguous, so list-position == ec.fq_quest-1.
#
# Quest object schema (the engine reads these exact fields):
#   {id:int, title:string, desc:string, type:string, target:string,
#    count:int, reward:string, reward_amt:int, chapter:int}
#
# *** SCHEMA CONSTRAINT (the `target` field is SHARED) ***
#   Item rewards (crate) ride ONLY catch_any / catch_crate / catch_node,
#   whose condition leaves target free to carry the reward tier/id.
#   catch_weather / catch_aquatic / milestone consume target for their own
#   condition -> they reward coins only. This chapter has no titles, no gear,
#   no trophies (no artifact).
# ------------------------------------------------------------

# --- Chapter 9: The Long Haul ----------------------------------------------

# q154 — open the slog: a heavy any-catch backbone. catch_any leaves target free.
data modify storage evercraft:fq_registry quests append value {id:154,title:"No End in Sight",desc:"Reel in 110 catches in all. The shore is far behind you and the water stretches on.",type:"catch_any",target:"",count:110,reward:"coins",reward_amt:1,chapter:9,skippable:0}

# q155 — splash-node backbone, exquisite crate reward. catch_node -> target = tier.
data modify storage evercraft:fq_registry quests append value {id:155,title:"Working the Ripples",desc:"Catch 45 fish from splash nodes. Your arms ache, but the water never rests.",type:"catch_node",target:"exquisite",count:45,reward:"crate",reward_amt:1,chapter:9,skippable:0}

# q156 — crate backbone, exquisite. catch_crate leaves target free -> crate tier.
data modify storage evercraft:fq_registry quests append value {id:156,title:"Filling the Hold",desc:"Fish up 14 crates. The hold groans under the weight of your haul.",type:"catch_crate",target:"exquisite",count:14,reward:"crate",reward_amt:1,chapter:9,skippable:0}

# q157 — bigger any-catch grind.
data modify storage evercraft:fq_registry quests append value {id:157,title:"One More Cast",desc:"Reel in 110 catches in all. You tell yourself one more, then ten more follow.",type:"catch_any",target:"",count:110,reward:"coins",reward_amt:1,chapter:9,skippable:0}

# q158 — node backbone climbs, exquisite crate.
data modify storage evercraft:fq_registry quests append value {id:158,title:"Eyes on the Water",desc:"Catch 45 fish from splash nodes. The surface never stops stirring out here.",type:"catch_node",target:"exquisite",count:45,reward:"crate",reward_amt:1,chapter:9,skippable:0}

# q159 — relief beat: themed aquatic hunt. catch_aquatic -> target = fish, reward coins.
data modify storage evercraft:fq_registry quests append value {id:159,title:"Familiar Faces",desc:"Catch 4 Coppergill Bass. Even in the long haul, an old quarry is good company.",type:"catch_aquatic",target:"coppergill_bass",count:4,reward:"coins",reward_amt:1,chapter:9,skippable:0}

# q160 — FIXED: Sirencall-stage milestone gate (reach stage 6). milestone -> coins.
data modify storage evercraft:fq_registry quests append value {id:160,title:"The Deep Still Calls",desc:"Advance the Sirencall path to its sixth stage. The voice in the water grows louder.",type:"milestone",target:"sirencall_stage",count:6,reward:"coins",reward_amt:1,chapter:9,skippable:0}

# q161 — back to the grind: heavy any-catch.
data modify storage evercraft:fq_registry quests append value {id:161,title:"Hauling On",desc:"Reel in 120 catches in all. The Sirencall hums, but the work is still yours alone.",type:"catch_any",target:"",count:120,reward:"coins",reward_amt:1,chapter:9,skippable:0}

# q162 — node backbone, exquisite crate.
data modify storage evercraft:fq_registry quests append value {id:162,title:"Reading the Restless Surface",desc:"Catch 50 fish from splash nodes. You strike each one half-asleep and rarely miss.",type:"catch_node",target:"exquisite",count:50,reward:"crate",reward_amt:1,chapter:9,skippable:0}

# q163 — relief beat: weather. catch_weather night -> overworld, reward coins.
data modify storage evercraft:fq_registry quests append value {id:163,title:"Through the Night",desc:"Reel in 9 catches under a night sky. The dark is quiet, and the quiet helps.",type:"catch_weather",target:"night",count:9,reward:"coins",reward_amt:1,chapter:9,skippable:0}

# q164 — crate backbone climbs, exquisite.
data modify storage evercraft:fq_registry quests append value {id:164,title:"The Weight of It",desc:"Fish up 17 crates. Each one heavier than the last, or so it feels.",type:"catch_crate",target:"exquisite",count:17,reward:"crate",reward_amt:1,chapter:9,skippable:0}

# q165 — heavy any-catch.
data modify storage evercraft:fq_registry quests append value {id:165,title:"Endless Water",desc:"Reel in 130 catches in all. The horizon never moves no matter how hard you pull.",type:"catch_any",target:"",count:130,reward:"coins",reward_amt:1,chapter:9,skippable:0}

# q166 — node backbone, exquisite crate.
data modify storage evercraft:fq_registry quests append value {id:166,title:"Still Watching",desc:"Catch 55 fish from splash nodes. Your patience has worn to a thin, steady thread.",type:"catch_node",target:"exquisite",count:55,reward:"crate",reward_amt:1,chapter:9,skippable:0}

# q167 — relief beat: weather rain -> overworld, reward coins.
data modify storage evercraft:fq_registry quests append value {id:167,title:"In the Rain",desc:"Reel in 10 catches while it rains. Soaked through, you keep the line tight.",type:"catch_weather",target:"rain",count:10,reward:"coins",reward_amt:1,chapter:9,skippable:0}

# q168 — heavy any-catch.
data modify storage evercraft:fq_registry quests append value {id:168,title:"Aching Shoulders",desc:"Reel in 130 catches in all. Every cast costs more than the one before.",type:"catch_any",target:"",count:130,reward:"coins",reward_amt:1,chapter:9,skippable:0}

# q169 — node backbone, exquisite crate.
data modify storage evercraft:fq_registry quests append value {id:169,title:"The Surface Never Rests",desc:"Catch 55 fish from splash nodes. The water churns on whether you do or not.",type:"catch_node",target:"exquisite",count:55,reward:"crate",reward_amt:1,chapter:9,skippable:0}

# q170 — crate backbone climbs, exquisite.
data modify storage evercraft:fq_registry quests append value {id:170,title:"Crate After Crate",desc:"Fish up 19 crates. You stop counting the haul and just keep hauling.",type:"catch_crate",target:"exquisite",count:19,reward:"crate",reward_amt:1,chapter:9,skippable:0}

# q171 — relief beat: themed spirit aquatic. catch_aquatic -> target = fish, coins.
data modify storage evercraft:fq_registry quests append value {id:171,title:"A Glimmer in the Deep",desc:"Land 2 Starscale from the lightless deep. A spirit's light cuts the long grey haul.",type:"catch_aquatic",target:"starscale",count:2,reward:"coins",reward_amt:1,chapter:9,skippable:0}

# q172 — node backbone tops out, exquisite crate.
data modify storage evercraft:fq_registry quests append value {id:172,title:"To the Bone",desc:"Catch 60 fish from splash nodes. You read the ripples now without thinking.",type:"catch_node",target:"exquisite",count:60,reward:"crate",reward_amt:1,chapter:9,skippable:0}

# q173 — crate backbone tops out, exquisite.
data modify storage evercraft:fq_registry quests append value {id:173,title:"The Full Hold",desc:"Fish up 21 crates. The longest haul of your life, and it is nearly done.",type:"catch_crate",target:"exquisite",count:21,reward:"crate",reward_amt:1,chapter:9,skippable:0}

# q174 — chapter closer: the heaviest any-catch of the slog.
data modify storage evercraft:fq_registry quests append value {id:174,title:"The Long Haul's End",desc:"Reel in 140 catches in all. The grind breaks at last, and something greater stirs ahead.",type:"catch_any",target:"",count:140,reward:"coins",reward_amt:1,chapter:9,skippable:0}

# ------------------------------------------------------------
# HAND-OFF TO load_batch_8 (q175..):
#   - This batch ends at id=174. The next batch's FIRST quest MUST be id=175
#     (list index 174) and be appended immediately after q174, contiguously.
#   - registry/load calls load_batch_6 then load_batch_7 then load_batch_8;
#     the main thread wires that call. Do NOT renumber this batch.
#   - No titles, no artifacts here (titles are q150 & q190; CH9 is pure grind).
# ------------------------------------------------------------
