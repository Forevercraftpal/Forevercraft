# ============================================================
# The Fisher's Questline — SET-PIECE EVENTS: objective declarations (one-time)
# ============================================================
# Split from events/load so the per-/reload "Objective already exists" warnings
# fire only once. Gated by `#fq_evt_loaded ec.var matches 1` (set at the bottom).
#
# These are the FLAGS the engine's event/special quest checker reads (lifetime
# "ever cleared" sentinels), PLUS the Lava Tide active/timer state. The progress
# counter for a quest is still ec.fq_prog (engine-owned); these are convenience
# sentinels + world-event state, NOT the linear pointer.

# === LIFETIME SET-PIECE SENTINELS (per-player; 0/1) ===
# "Has this player ever beaten the Stormcharge (charged creeper)?"
scoreboard objectives add ec.fq_evt_charged dummy "FQ Cleared Stormcharge"
# "Has this player ever beaten the fireproof Warden apex of a Lava Tide?"
scoreboard objectives add ec.fq_evt_warden dummy "FQ Cleared Fireproof Warden"
# "Has this player ever cleared a full Lava Tide mob wave?"
scoreboard objectives add ec.fq_evt_lavatide dummy "FQ Cleared Lava Tide Wave"

# === LAVA TIDE WORLD-EVENT STATE (global; fake-players on shared ec.var) ===
# These are GLOBAL (one Lava Tide for the server), so they live as fake-player
# scores on the shared ec.var objective (declared in evercraft:init) — exactly
# like world_events' #we_active / #we_timer. No new objective needed.
#   #fq_lava_tide ec.var — 0/1 active. WRITER: lava_tide/start (1) + lava_tide/stop (0).
#     do_catch reads this to gate nether-node mob spawns.
#   #fq_lt_timer ec.var  — countdown (seconds). WRITER: lava_tide/start + lava_tide/tick.
#   #fq_lt_cd ec.var     — gametime cooldown stamp. WRITER: lava_tide/stop.
#   #fq_lt_wave ec.var   — wave-spawn cadence counter. WRITER: lava_tide/tick.
# Initialize global state (only if unset — preserve across /reload).
execute unless score #fq_lava_tide ec.var matches 0.. run scoreboard players set #fq_lava_tide ec.var 0
execute unless score #fq_lt_timer ec.var matches 0.. run scoreboard players set #fq_lt_timer ec.var 0
execute unless score #fq_lt_cd ec.var matches 0.. run scoreboard players set #fq_lt_cd ec.var 0
execute unless score #fq_lt_wave ec.var matches 0.. run scoreboard players set #fq_lt_wave ec.var 0

# Mark declarations done so re-/reload skips this file.
scoreboard players set #fq_evt_loaded ec.var 1
