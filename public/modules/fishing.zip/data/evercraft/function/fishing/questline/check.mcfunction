# ============================================================
# The Fisher's Questline — Check (is the current quest satisfied?)
# ============================================================
# Reads the current quest's type/target/count and decides whether the active
# quest is complete; if so, calls questline/advance. Idempotency-guarded like
# story/quest/advance (refuses to act when the line is already complete).
# Run as @s = the player. Cheap; called from the catch hooks + milestone events.

# --- Existence gate: do nothing unless this player has an active questline. ---
execute unless score @s ec.fq_active matches 1 run return 0
# --- Already finished the whole line? Nothing left to check. ---
execute if score @s ec.fq_complete matches 1 run return 0

# Make sure fq_cur holds THIS quest (catch hooks may have run get_quest already,
# but re-loading is cheap and keeps check self-contained / caller-order-proof).
function evercraft:fishing/questline/get_quest

# Flatten the quest fields the macro compares against.
data modify storage evercraft:fq_cur o set from storage evercraft:fq_cur quest

# Snapshot the linear pointer BEFORE dispatch, so advance can detect a re-entrant
# same-tick double-call (idempotency guard, mirrors story upper-bound guard).
execute store result score #fq_q_before ec.temp run scoreboard players get @s ec.fq_quest

# Dispatch on quest.type. The macro sets #fq_satisfied ec.temp to 1 when done.
scoreboard players set #fq_satisfied ec.temp 0
function evercraft:fishing/questline/check_macro with storage evercraft:fq_cur o

# If satisfied, advance — but only if the pointer hasn't already moved this tick.
execute if score #fq_satisfied ec.temp matches 1 if score @s ec.fq_quest = #fq_q_before ec.temp run function evercraft:fishing/questline/advance
