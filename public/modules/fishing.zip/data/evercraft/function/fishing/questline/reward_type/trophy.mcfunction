# FQ reward — trophy (a questline trophy/set-piece item). @s = player.
# quest.target is the trophy id; the loot table is owned by the reward agent at
# evercraft:fishing/questline/rewards/trophy/<id>. Inv-full aware
# (prospect/complete_mine pattern). Macro body — the loot lines read $(target).
execute store result score #fq_inv_full ec.var run function evercraft:util/check_inv_full
$execute if score #fq_inv_full ec.var matches 0 run loot give @s loot evercraft:fishing/questline/rewards/trophy/$(target)
$execute if score #fq_inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:fishing/questline/rewards/trophy/$(target)
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"Reward: a Master-Angler trophy!",color:"gold",bold:true},{text:" ✦",color:"gold"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Inventory full! Your trophy was dropped at your feet.",color:"yellow"}]
scoreboard players set #ndur ec.temp 45
execute if score #fq_inv_full ec.var matches 1 run function evercraft:util/notify/emit
execute if score #fq_inv_full ec.var matches 1 if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bass player @s ~ ~ ~ 1 0.5
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 0.8 1.1
