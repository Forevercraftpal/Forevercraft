# FQ check helper — event (a set-piece flag). Progress/flag quest.
# The set-piece event fn sets ec.fq_prog (the flag) before calling questline/check,
# so the engine compares ec.fq_prog >= quest.count (count usually 1).
scoreboard players set #fq_satisfied ec.temp 0
execute if score @s ec.fq_prog >= #fq_count ec.temp run scoreboard players set #fq_satisfied ec.temp 1
