# ============================================================
# The Fisher's Questline — Registry batch 0 (PROOF-OF-CONCEPT, q1..q24)
# ============================================================
# Appends the first 24 quests onto storage evercraft:fq_registry quests.
# Called by registry/load AFTER it sets quests=[]. MUST append in id order
# (id=1 first => list index 0), contiguous, so list-position == ec.fq_quest-1.
#
# Quest object schema (the engine reads these exact fields):
#   {id:int, title:string, desc:string, type:string, target:string,
#    count:int, reward:string, reward_amt:int, chapter:int,
#    [lore:string], skippable:0}
#   lore (Fisher rework 2026-06-10) -> the pacing layer's gray-italic teaching
#     line, delivered by on_advance_notify via quest_pacing/render_lore (ch-1
#     beats teach the systems; absent = no-op). skippable:0 on EVERY fisher row:
#     catches cannot be auto-granted, so [Skip ▸] is withheld line-wide (the
#     set_track fisher caveat stays truthful on every surface).
#
# type    -> dispatched by check_type/$(type):
#            catch_any | catch_crate | catch_node | catch_aquatic
#            | milestone | event | special
# target  -> catch_aquatic: fish_type (aquatic_fish/grant or spirit_fish/grant basename)
#            milestone: "rod_tier" | "sirencall_stage" | "total_done"
#            event:   set-piece flag id ("charged_creeper" / "lava_tide")
#            special: bespoke flag id ("fireproof_warden")
#            crate reward: tier name (common|uncommon|rare|ornate|exquisite|mythical)
#            gear/trophy reward: the reward-table id (anglers_hat / golden_cod_trophy / ...)
#            (for non-targeted catch/reward combos target is "" — engine ignores it)
# count   -> catch_*/event/special: ec.fq_prog threshold; milestone: mirror-score threshold
# reward  -> coins | crate | title | gear | trophy   (reward_amt = amount/tier/—)
# chapter -> display grouping only (PoC batch 0 = chapters 1-2, the early game)
#
# *** SCHEMA CONSTRAINT (the `target` field is SHARED, resolved during PoC) ***
# The engine has ONE `target` field per quest, but BOTH the condition side AND
# the item-reward side consume it:
#   - condition: catch_aquatic (fish_type), event/special (flag), milestone (mirror)
#   - reward:    crate (tier name), gear (item id), trophy (item id)
# A quest whose CONDITION already uses target (catch_aquatic/event/special/
# milestone) therefore CANNOT reward crate/gear/trophy — those need target for
# their own id. Such quests reward `coins` or `title` (which read only
# reward_amt and ignore target). Item rewards (crate/gear/trophy) are placed
# ONLY on catch_any / catch_crate / catch_node quests, whose condition leaves
# target free to carry the reward tier/id. load_batch_1+ MUST honor this.
#
# NOTE the count escalates as a grindy backbone with a few silly/epic spikes;
# the milestone spine tracks the rod ladder (rod_tier, the craftforever fishing
# trials) + a Sirencall-stage gate. q200 arc: batch_0 climbs to rod tier 4 (q22);
# the spirit Tidecaller capstone (rod_tier 10) lives at q200 in a later batch.
# ------------------------------------------------------------

# --- Chapter 1: First Casts -------------------------------------------------

# q1 — gentle intro: catch ANY one fish. Pure on-ramp.
data modify storage evercraft:fq_registry quests append value {id:1,title:"First Cast",desc:"Cast your line and reel in your very first catch.",type:"catch_any",target:"",count:1,reward:"coins",reward_amt:1,chapter:1,lore:"Any rod over any water begins the Fisher's Path. Every catch you ever reel in counts here — this line keeps score for life, and it pays in coins, crates, gear and titles all the way to the Crown.",skippable:0}

# q2 — small grind to teach the loop.
data modify storage evercraft:fq_registry quests append value {id:2,title:"Finding Your Feet",desc:"Reel in 10 catches of any kind. Patience is the angler's first lesson.",type:"catch_any",target:"",count:10,reward:"coins",reward_amt:1,chapter:1,lore:"Catches of any kind feed the any-catch quests — the backbone of the Path. Luck of the Sea on your rod raises what the water offers, and nothing you reel in is ever wasted.",skippable:0}

# q3 — first crate (catch_crate; reward a common crate to open).
#   catch_crate leaves target free, so target doubles as the crate-reward TIER.
data modify storage evercraft:fq_registry quests append value {id:3,title:"Sunken Bounty",desc:"Fish up a crate from the depths. The water keeps what others lose.",type:"catch_crate",target:"common",count:1,reward:"crate",reward_amt:1,chapter:1,lore:"Now and then the line comes up heavy: a sunken crate, the same reward crates the whole world pays in. Place it down to crack it open — finer tiers wait in deeper water.",skippable:0}

# q4 — first named aquatic fish (Silverscale Minnow, the starter aquatic).
data modify storage evercraft:fq_registry quests append value {id:4,title:"A Glint of Silver",desc:"Catch a Silverscale Minnow. Some fish are more than supper.",type:"catch_aquatic",target:"silverscale_minnow",count:1,reward:"coins",reward_amt:1,chapter:1,lore:"Named fish swim among the common haul — rarer, brighter, and worth keeping. A cook's hearth knows what to do with them, and the deepest waters hide spirit fish beyond even these.",skippable:0}

# q5 — first splash-node catch (catch_node). Teaches the node mechanic.
#   catch_node leaves target free -> target doubles as the GEAR-reward item id.
#   First gear payout: the Angler's Hat (reward agent owns the gear loot table).
data modify storage evercraft:fq_registry quests append value {id:5,title:"Where the Water Stirs",desc:"Catch a fish from a splashing surface node. Watch the water and strike true.",type:"catch_node",target:"anglers_hat",count:1,reward:"gear",reward_amt:1,chapter:1,lore:"Where the surface churns and splashes, the water is offering something. Cast into it — node catches run their own quests on the Path, and they pay the angler's finest gear.",skippable:0}

# q6 — gentle night-fishing intro. (The charged-creeper set-piece that used to live
#   here was relocated 2026-06-09 to q107 in the Ch6 storm chapter — at q6 it was a
#   thunderstorm RNG wall sitting BEFORE rod tier 2, blocking the on-ramp on weather the
#   player can't force. Night always comes, so this teaches the weather/time mechanic
#   with zero wall and foreshadows Ch6.) catch_weather consumes target -> reward coins.
data modify storage evercraft:fq_registry quests append value {id:6,title:"By the Light of the Moon",desc:"Reel in 3 catches after nightfall. The water keeps different secrets once the sun is down.",type:"catch_weather",target:"night",count:3,reward:"coins",reward_amt:1,chapter:1,lore:"The sky changes the water. Night, rain and thunder each keep their own catches and their own quests — when a storm rolls in, a fisher does not go inside.",skippable:0}

# q7 — first title milestone: tier 1 Master-Angler. Bigger any-catch grind.
data modify storage evercraft:fq_registry quests append value {id:7,title:"Apprentice of the Line",desc:"Reel in 40 catches in all. Earn your first Master-Angler title.",type:"catch_any",target:"",count:40,reward:"title",reward_amt:1,chapter:1,lore:"Eleven Master-Angler titles stand between a first cast and the Tidecaller's Crown. Each one is earned on the water, never bought — the first is nearly yours.",skippable:0}

# q8 — rod-ladder milestone: reach rod tier 2 (the craftforever fishing trials).
data modify storage evercraft:fq_registry quests append value {id:8,title:"A Better Rod",desc:"Advance your fishing rod to tier 2 through the fishing trials.",type:"milestone",target:"rod_tier",count:2,reward:"coins",reward_amt:1,chapter:1,lore:"Your rod is the gate. Each tier won in the fishing trials opens the rod-trial quests ahead, and the Sirencall path listens only for those who push deeper. Craft, fish, repeat.",skippable:0}

# --- Chapter 2: Deeper Waters ----------------------------------------------

# q9 — crate grind (5 crates). Backbone. Reward tier escalates to 'rare'.
data modify storage evercraft:fq_registry quests append value {id:9,title:"Hoard of the Deep",desc:"Fish up 5 crates. The seabed is generous to the persistent.",type:"catch_crate",target:"rare",count:5,reward:"crate",reward_amt:1,chapter:2,skippable:0}

# q10 — aquatic: Glimmer Trout x3 (rare reagent fish).
data modify storage evercraft:fq_registry quests append value {id:10,title:"Light on the Scales",desc:"Catch 3 Glimmer Trout. Their shimmer marks them as no ordinary fish.",type:"catch_aquatic",target:"glimmer_trout",count:3,reward:"coins",reward_amt:1,chapter:2,skippable:0}

# q11 — splash-node grind (10 nodes). catch_node leaves target free -> crate tier.
data modify storage evercraft:fq_registry quests append value {id:11,title:"Reader of Ripples",desc:"Catch 10 fish from splash nodes. Learn to read the restless water.",type:"catch_node",target:"uncommon",count:10,reward:"crate",reward_amt:1,chapter:2,skippable:0}

# q12 — total_done milestone: 10 quests cleared. Overview pacing gate.
#   milestone uses target for the mirror name -> reward MUST be coins/title.
data modify storage evercraft:fq_registry quests append value {id:12,title:"Halfway Down the Pier",desc:"Complete 10 quests in all. You are an angler in earnest now.",type:"milestone",target:"total_done",count:10,reward:"coins",reward_amt:1,chapter:2,skippable:0}

# q13 — *** SET-PIECE: the Lava Tide *** (event flag). Silly/epic.
#   event uses target for the flag -> reward coins (not crate; schema conflict).
data modify storage evercraft:fq_registry quests append value {id:13,title:"Fishing the Lava Tide",desc:"Cast into a Lava Tide and pull something back. Mind your eyebrows.",type:"event",target:"lava_tide",count:1,reward:"coins",reward_amt:1,chapter:2,skippable:0}

# q14 — Sirencall-stage milestone gate (reach stage 1 of the Sirencall path).
data modify storage evercraft:fq_registry quests append value {id:14,title:"Heeding the Sirencall",desc:"Begin the Sirencall path and reach its first stage. The deep is listening.",type:"milestone",target:"sirencall_stage",count:1,reward:"coins",reward_amt:1,chapter:2,skippable:0}

# q15 — title tier 2. Larger any-catch backbone.
data modify storage evercraft:fq_registry quests append value {id:15,title:"Journeyman of the Tide",desc:"Reel in 100 catches in all. Claim your second Master-Angler title.",type:"catch_any",target:"",count:100,reward:"title",reward_amt:2,chapter:2,skippable:0}

# q16 — aquatic: Emberfin Snapper x2 (warmer-water fish).
data modify storage evercraft:fq_registry quests append value {id:16,title:"Coals Beneath the Surface",desc:"Catch 2 Emberfin Snapper. They run hot in the deeper currents.",type:"catch_aquatic",target:"emberfin_snapper",count:2,reward:"coins",reward_amt:1,chapter:2,skippable:0}

# q17 — rod-ladder milestone: rod tier 3. (q200 arc: rod tiers spread up to t10 @ q200.)
#   milestone uses target for the mirror -> reward coins (not gear).
data modify storage evercraft:fq_registry quests append value {id:17,title:"A Sturdier Line",desc:"Advance your fishing rod to tier 3 through the fishing trials. Each tier is hard-won.",type:"milestone",target:"rod_tier",count:3,reward:"coins",reward_amt:1,chapter:2,skippable:0}

# q18 — crate backbone (15 crates). Big grind, ornate crate reward.
data modify storage evercraft:fq_registry quests append value {id:18,title:"The Collector",desc:"Fish up 15 crates in all. Few have the patience the sea demands.",type:"catch_crate",target:"ornate",count:15,reward:"crate",reward_amt:1,chapter:2,skippable:0}

# q19 — aquatic: Frostfin Char x3 (cold-water fish).
data modify storage evercraft:fq_registry quests append value {id:19,title:"Cold Current",desc:"Catch 3 Frostfin Char from chilled waters. Bundle up, angler.",type:"catch_aquatic",target:"frostfin_char",count:3,reward:"coins",reward_amt:1,chapter:2,skippable:0}

# q20 — splash-node backbone (25 nodes). catch_node leaves target free, so
#   target doubles as the TROPHY-reward item id (reward agent owns the table).
data modify storage evercraft:fq_registry quests append value {id:20,title:"Master of Ripples",desc:"Catch 25 fish from splash nodes. The water hides nothing from you now.",type:"catch_node",target:"golden_cod_trophy",count:25,reward:"trophy",reward_amt:1,chapter:2,skippable:0}

# q21 — first SPIRIT fish: Deepcurrent (cooking/spirit_fish/grant/deepcurrent).
#   catch_aquatic uses target for the fish_type -> reward coins (not gear).
data modify storage evercraft:fq_registry quests append value {id:21,title:"A Whisper from the Abyss",desc:"Land a Deepcurrent — a spirit fish stirred from the lightless deep.",type:"catch_aquatic",target:"deepcurrent",count:1,reward:"coins",reward_amt:1,chapter:2,skippable:0}

# q22 — rod-ladder milestone: rod tier 4. (q200 arc.)
data modify storage evercraft:fq_registry quests append value {id:22,title:"A Trusted Rod",desc:"Advance your fishing rod to tier 4. The trials have more to teach you yet.",type:"milestone",target:"rod_tier",count:4,reward:"title",reward_amt:3,chapter:2,skippable:0}

# q23 — splash-node backbone (30 nodes). catch_node leaves target free -> target
#   doubles as the crate-reward TIER. (The apex fireproof-Warden set-piece moved to the
#   post-spirit coda ~q230 per the q200 arc; its event handler is untouched.)
data modify storage evercraft:fq_registry quests append value {id:23,title:"Reader of the Restless Deep",desc:"Catch 30 fish from splash nodes. The water answers those who watch it closely.",type:"catch_node",target:"rare",count:30,reward:"crate",reward_amt:1,chapter:2,skippable:0}

# q24 — chapter-2 closer: a big any-catch backbone, title tier 4. (q200 arc: the spirit
#   Tidecaller capstone [rod_tier 10] moved to q200; the rod ladder climbs there now. With
#   load_batch_1+ wired, q24 advances into q25 — the engine reads N (list length) dynamically.)
#   catch_any leaves target free; reward title reads only reward_amt.
data modify storage evercraft:fq_registry quests append value {id:24,title:"Seasoned of the Tide",desc:"Reel in 150 catches in all. You have the sea in your blood now — but the deep runs deeper.",type:"catch_any",target:"",count:150,reward:"title",reward_amt:4,chapter:2,skippable:0}

# ------------------------------------------------------------
# HAND-OFF TO load_batch_1 (q25..):
#   - This batch ends at id=24. The next batch's FIRST quest MUST be id=25
#     (list index 24) and be appended immediately after q24, contiguously.
#   - registry/load calls load_batch_0 then will call load_batch_1; add that
#     call to registry/load when batch 1 lands. Do NOT renumber this batch.
#   - q24 is a soft finale, not the line finale: the engine reads N dynamically
#     (list length) in advance, so adding load_batch_1 automatically extends the
#     line — q24's "questline complete!" finish() only fires when N == current
#     batch count. With only batch 0 loaded, finishing q24 triggers finish();
#     once batch 1 is wired, q24 advances into q25 instead. No engine change.
#
# MILESTONE-MIRROR WIRING THIS BATCH ASSUMES (other agents own these hooks):
#   - ec.fq_rod_tier  : written by the craftforever fishing-trial / spirit-tool
#       progression hook = the player's current rod tier 1..10. Tier 10 == owning
#       the spirit Tidecaller (loot t10_reward, custom_data{spirit_tool:"tidecaller"}).
#       Ownership is detectable via predicate evercraft:spirit_tools/holding_any
#       (tidecaller term) or `items entity @s weapon.mainhand
#       *[custom_data~{spirit_tool:"tidecaller"}]` (see craftforever/spirit_tools/detect).
#       That hook MUST call evercraft:fishing/questline/check after writing the mirror.
#   - ec.fq_sirencall_stage : written by the Sirencall progression hook (stage 1..N);
#       also calls questline/check after each stage-up.
#   - Set-piece flags (q13 lava_tide; the first charged_creeper now lives at q107 in the
#       Ch6 storm chapter [relocated from q6 2026-06-09], fireproof_warden at the post-spirit
#       coda ~q230 per the q200 arc): the event/special set-piece fns increment ec.fq_prog
#       (gated to the matching active quest) then call questline/check, per the hook contract.
# ------------------------------------------------------------
