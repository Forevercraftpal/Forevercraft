# ============================================================
# The Fisher's Questline — Registry batch 5 (q111..q132)
# ============================================================
# Appends quests q111..q132 onto storage evercraft:fq_registry quests.
# Called by registry/load AFTER batch_4 (q90..q110). MUST append in id
# order (id=111 first => list index 110), contiguous, so list-position
# == ec.fq_quest-1. Do NOT renumber; do NOT touch other batches.
#
# Quest object schema (the engine reads these exact fields):
#   {id:int, title:string, desc:string, type:string, target:string,
#    count:int, reward:string, reward_amt:int, chapter:int}
#
# *** SCHEMA CONSTRAINT (the `target` field is SHARED) ***
# A quest whose CONDITION consumes target (catch_aquatic/event/special/
# milestone) CANNOT reward crate/gear/trophy — those need target for their
# own id. Such quests reward coins/title. Item rewards (crate/gear/trophy)
# ride ONLY catch_any / catch_crate / catch_node, whose condition leaves
# target free to carry the reward tier/id.
#
# *** CHAPTER 7 — NETHER TIDES (chapter:7) ***
# Lava nodes, cinder bait, the Lava Tide. The nether has no sky: there is
# NO rain, thunder, or night here, so this chapter uses NO catch_weather.
# Set-pieces are limited to event:lava_tide (count 1 — rare apex, coins
# only). Grind backbone is catch_node (lava nodes) + catch_crate + catch_any.
# ------------------------------------------------------------

# --- Chapter 7: Nether Tides ------------------------------------------------

# q111 — descend into the burning dark: lava-node backbone opener (ornate crate).
#   catch_node leaves target free -> target doubles as the crate-reward TIER.
data modify storage evercraft:fq_registry quests append value {id:111,title:"Down Where It Burns",desc:"Catch 30 fish from lava nodes. The fire keeps a deeper sort of fish.",type:"catch_node",target:"ornate",count:30,reward:"crate",reward_amt:1,chapter:7,skippable:0}

# q112 — any-catch backbone in the heat. catch_any leaves target free; reward coins.
data modify storage evercraft:fq_registry quests append value {id:112,title:"Cinder on the Line",desc:"Reel in 90 catches amid the lava flats. Ash settles on everything you pull up.",type:"catch_any",target:"",count:90,reward:"coins",reward_amt:1,chapter:7,skippable:0}

# q113 — crate grind, ornate tier. catch_crate leaves target free -> crate tier.
data modify storage evercraft:fq_registry quests append value {id:113,title:"Smelted Bounty",desc:"Fish up 8 crates from the magma shallows. The heat warps the iron bands but the haul holds.",type:"catch_crate",target:"ornate",count:8,reward:"crate",reward_amt:1,chapter:7,skippable:0}

# q114 — lava-node grind climbs. catch_node -> target carries crate tier.
data modify storage evercraft:fq_registry quests append value {id:114,title:"Where the Magma Stirs",desc:"Catch 35 fish from lava nodes. Watch the bubbling crust and strike before it bursts.",type:"catch_node",target:"ornate",count:35,reward:"crate",reward_amt:1,chapter:7,skippable:0}

# q115 — coins payout on a lava-node haul. catch_node -> target free; reward coins.
data modify storage evercraft:fq_registry quests append value {id:115,title:"Tending the Coals",desc:"Catch 40 fish from lava nodes. Keep your line cool and your nerve cooler.",type:"catch_node",target:"",count:40,reward:"coins",reward_amt:1,chapter:7,skippable:0}

# q116 — *** flavor SET-PIECE: a first Lava Tide *** (event flag, count 1 only).
#   event uses target for the flag -> reward coins (schema: no crate/gear/trophy).
data modify storage evercraft:fq_registry quests append value {id:116,title:"The Tide Runs Hot",desc:"Cast into a rising Lava Tide and pull something back. The molten current gives one chance.",type:"event",target:"lava_tide",count:1,reward:"coins",reward_amt:1,chapter:7,skippable:0}

# q117 — any-catch backbone climbs. reward coins.
data modify storage evercraft:fq_registry quests append value {id:117,title:"Ash and Patience",desc:"Reel in 110 catches across the burning shore. The deep here is darker than any sea.",type:"catch_any",target:"",count:110,reward:"coins",reward_amt:1,chapter:7,skippable:0}

# q118 — crate grind escalates to exquisite. catch_crate -> target = crate tier.
data modify storage evercraft:fq_registry quests append value {id:118,title:"Forge-Touched Hoard",desc:"Fish up 10 crates from the lava flats. What survives the heat is worth the burn.",type:"catch_crate",target:"exquisite",count:10,reward:"crate",reward_amt:1,chapter:7,skippable:0}

# q119 — lava-node grind. catch_node -> target carries crate tier (exquisite).
data modify storage evercraft:fq_registry quests append value {id:119,title:"Reader of Embers",desc:"Catch 45 fish from lava nodes. Learn to read the glow the way you once read ripples.",type:"catch_node",target:"exquisite",count:45,reward:"crate",reward_amt:1,chapter:7,skippable:0}

# q120 — *** FIXED: rod-ladder milestone, rod tier 7 *** (q200 arc).
#   milestone uses target for the mirror -> reward coins (not gear).
data modify storage evercraft:fq_registry quests append value {id:120,title:"A Rod Forged in Fire",desc:"Advance your fishing rod to tier 7 through the fishing trials. Only fire-tempered tackle holds in the nether.",type:"milestone",target:"rod_tier",count:7,reward:"coins",reward_amt:1,chapter:7,skippable:0}

# q121 — lava-node grind continues. catch_node -> target = crate tier.
data modify storage evercraft:fq_registry quests append value {id:121,title:"Deeper Than the Coals",desc:"Catch 48 fish from lava nodes. Below the crust the heat only sharpens.",type:"catch_node",target:"exquisite",count:48,reward:"crate",reward_amt:1,chapter:7,skippable:0}

# q122 — any-catch backbone. reward coins.
data modify storage evercraft:fq_registry quests append value {id:122,title:"Soot on the Reel",desc:"Reel in 130 catches in the burning dark. Your hands are black with ash and you do not stop.",type:"catch_any",target:"",count:130,reward:"coins",reward_amt:1,chapter:7,skippable:0}

# q123 — crate grind, exquisite. catch_crate -> target = crate tier.
data modify storage evercraft:fq_registry quests append value {id:123,title:"Cinderbound Crates",desc:"Fish up 12 crates from the magma shallows. The latches glow but they still open.",type:"catch_crate",target:"exquisite",count:12,reward:"crate",reward_amt:1,chapter:7,skippable:0}

# q124 — lava-node grind. coins payout. catch_node -> target free; reward coins.
data modify storage evercraft:fq_registry quests append value {id:124,title:"Master of the Magma Line",desc:"Catch 50 fish from lava nodes. The fire has nothing left to teach you.",type:"catch_node",target:"",count:50,reward:"coins",reward_amt:1,chapter:7,skippable:0}

# q125 — *** FIXED SET-PIECE: the Greater Lava Tide *** (event flag, count 1).
#   event uses target for the flag -> reward coins (schema: no crate/gear/trophy).
data modify storage evercraft:fq_registry quests append value {id:125,title:"Greater Lava Tide",desc:"Cast into a Greater Lava Tide — the molten apex — and pull its prize from the flood. One cast. Make it count.",type:"event",target:"lava_tide",count:1,reward:"coins",reward_amt:1,chapter:7,skippable:0}

# q126 — any-catch backbone, post-apex grind. reward coins.
data modify storage evercraft:fq_registry quests append value {id:126,title:"Tempered in the Tide",desc:"Reel in 150 catches across the lava flats. You have fished the molten flood and lived.",type:"catch_any",target:"",count:150,reward:"coins",reward_amt:1,chapter:7,skippable:0}

# q127 — lava-node grind climbs. catch_node -> target = crate tier (exquisite).
data modify storage evercraft:fq_registry quests append value {id:127,title:"The Glowing Deep",desc:"Catch 52 fish from lava nodes. The brighter the glow, the rarer the catch.",type:"catch_node",target:"exquisite",count:52,reward:"crate",reward_amt:1,chapter:7,skippable:0}

# q128 — crate grind, exquisite. catch_crate -> target = crate tier.
data modify storage evercraft:fq_registry quests append value {id:128,title:"Ember-Sealed Hoard",desc:"Fish up 14 crates from the burning shore. Each one cools in your hands before it opens.",type:"catch_crate",target:"exquisite",count:14,reward:"crate",reward_amt:1,chapter:7,skippable:0}

# q129 — lava-node grind. coins payout. catch_node -> target free; reward coins.
data modify storage evercraft:fq_registry quests append value {id:129,title:"Walker of the Burning Shore",desc:"Catch 54 fish from lava nodes. The molten coast is yours now, end to end.",type:"catch_node",target:"",count:54,reward:"coins",reward_amt:1,chapter:7,skippable:0}

# q130 — any-catch backbone. reward coins.
data modify storage evercraft:fq_registry quests append value {id:130,title:"What the Fire Keeps",desc:"Reel in 170 catches in the nether dark. The deep gives up its hottest secrets only to the patient.",type:"catch_any",target:"",count:170,reward:"coins",reward_amt:1,chapter:7,skippable:0}

# q131 — final pre-capstone lava-node grind. catch_node -> target = crate tier.
data modify storage evercraft:fq_registry quests append value {id:131,title:"On the Edge of the Magma",desc:"Catch 55 fish from lava nodes. One last haul from the fire before the deepest prize.",type:"catch_node",target:"exquisite",count:55,reward:"crate",reward_amt:1,chapter:7,skippable:0}

# q132 — *** CAPSTONE: the Deepline Boots *** (catch_node; target = gear item id).
#   catch_node leaves target free -> target carries the GEAR-reward item id.
#   The reward agent owns the deepline_boots gear loot table.
data modify storage evercraft:fq_registry quests append value {id:132,title:"The Deepline Boots",desc:"Catch 70 fish from lava nodes and earn the Deepline Boots — forged to walk where the fire runs deepest.",type:"catch_node",target:"deepline_boots",count:70,reward:"gear",reward_amt:1,chapter:7,skippable:0}

# ------------------------------------------------------------
# HAND-OFF TO load_batch_6 (q133..):
#   - This batch ends at id=132. The next batch's FIRST quest MUST be id=133
#     (list index 132), appended immediately after q132, contiguously.
#   - registry/load calls batches in order; the main thread wires this batch's
#     call. Do NOT edit registry/load or any other batch.
#
# MILESTONE-MIRROR / SET-PIECE WIRING THIS BATCH ASSUMES (other agents own these):
#   - ec.fq_rod_tier (q120): written by the craftforever fishing-trial hook;
#       calls evercraft:fishing/questline/check after writing the mirror.
#   - Lava-tide set-piece (q116 flavor, q125 Greater Lava Tide): the lava_tide
#       event fn increments ec.fq_prog (gated to the matching active quest, count
#       1 only) then calls questline/check, per the catch/event hook contract.
#   - deepline_boots gear (q132): reward agent owns the gear loot table.
# ------------------------------------------------------------
