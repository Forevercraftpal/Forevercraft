# ============================================================
# The Fisher's Questline — Registry batch 1 (Chapter 3, q25..q45)
# ============================================================
# Appends quests 25..45 onto storage evercraft:fq_registry quests.
# Called by registry/load AFTER load_batch_0. MUST append in id order
# (id=25 first => list index 24), contiguous with batch_0, so the
# list-position == ec.fq_quest-1 invariant holds across batches.
#
# Quest object schema (the engine reads these exact fields):
#   {id:int, title:string, desc:string, type:string, target:string,
#    count:int, reward:string, reward_amt:int, chapter:int}
#
# *** SCHEMA CONSTRAINT (the `target` field is SHARED) ***
# A quest whose CONDITION consumes target (catch_aquatic / catch_weather /
# milestone) CANNOT reward crate/gear/trophy — those need target for their
# own id/tier. Such quests reward coins or title only. Item rewards
# (crate here) ride ONLY catch_any / catch_crate / catch_node, whose
# condition leaves target free. CH3 places no gear/trophy.
#
# Chapter 3 — "The Open Water": the ocean opens up. Mid-tier aquatics
# (coppergill_bass, mistpike), the first lessons in reading weather, and
# the climb to rod tier 5 / Sirencall stage 2.
# ------------------------------------------------------------

# --- Chapter 3: The Open Water ---------------------------------------------

# q25 — open the chapter: a wide any-catch backbone as the shore drops away.
data modify storage evercraft:fq_registry quests append value {id:25,title:"Out Past the Shallows",desc:"Reel in 20 catches in the open water. The seabed falls away beneath your line.",type:"catch_any",target:"",count:20,reward:"coins",reward_amt:1,chapter:3,skippable:0}

# q26 — first CH3 aquatic: Coppergill Bass (featured mid-tier fish).
data modify storage evercraft:fq_registry quests append value {id:26,title:"Bronze Beneath the Waves",desc:"Catch 2 Coppergill Bass. Their copper flanks flash in the deeper blue.",type:"catch_aquatic",target:"coppergill_bass",count:2,reward:"coins",reward_amt:1,chapter:3,skippable:0}

# q27 — crate grind. catch_crate leaves target free -> target = crate TIER.
data modify storage evercraft:fq_registry quests append value {id:27,title:"Salvage Run",desc:"Fish up 2 crates from the open water. The current carries more than fish.",type:"catch_crate",target:"uncommon",count:2,reward:"crate",reward_amt:1,chapter:3,skippable:0}

# q28 — splash-node backbone. catch_node leaves target free -> target = crate TIER.
data modify storage evercraft:fq_registry quests append value {id:28,title:"Where the Swell Breaks",desc:"Catch 12 fish from splash nodes on the open swell. Read the restless water.",type:"catch_node",target:"uncommon",count:12,reward:"crate",reward_amt:1,chapter:3,skippable:0}

# q29 — second CH3 aquatic: Mistpike (featured mid-tier fish).
data modify storage evercraft:fq_registry quests append value {id:29,title:"Shapes in the Haze",desc:"Catch 2 Mistpike where the fog hangs low. They hunt the grey water.",type:"catch_aquatic",target:"mistpike",count:2,reward:"coins",reward_amt:1,chapter:3,skippable:0}

# q30 — *** SET-PIECE: Midnight Cast *** (catch_weather night). FIXED.
#   catch_weather uses target for the condition flag -> reward coins/title only.
data modify storage evercraft:fq_registry quests append value {id:30,title:"Midnight Cast",desc:"Reel in 5 catches under the night sky. The dark water gives up different prizes.",type:"catch_weather",target:"night",count:5,reward:"coins",reward_amt:1,chapter:3,skippable:0}

# q31 — any-catch climb continues.
data modify storage evercraft:fq_registry quests append value {id:31,title:"Steady Hands",desc:"Reel in 30 catches in all. The open water rewards a patient line.",type:"catch_any",target:"",count:30,reward:"coins",reward_amt:1,chapter:3,skippable:0}

# q32 — splash-node grind, tier climbs to rare. catch_node -> target = crate TIER.
data modify storage evercraft:fq_registry quests append value {id:32,title:"Reading the Open Swell",desc:"Catch 15 fish from splash nodes. The deeper water churns with promise.",type:"catch_node",target:"rare",count:15,reward:"crate",reward_amt:1,chapter:3,skippable:0}

# q33 — aquatic reuse: Glimmer Trout, now schooling in the open.
data modify storage evercraft:fq_registry quests append value {id:33,title:"Shimmer in the Deep Blue",desc:"Catch 4 Glimmer Trout. Their shimmer carries far across open water.",type:"catch_aquatic",target:"glimmer_trout",count:4,reward:"coins",reward_amt:1,chapter:3,skippable:0}

# q34 — crate backbone, tier climbs to rare. catch_crate -> target = crate TIER.
data modify storage evercraft:fq_registry quests append value {id:34,title:"The Tide Provides",desc:"Fish up 4 crates from the deep current. The open water hoards its bounty.",type:"catch_crate",target:"rare",count:4,reward:"crate",reward_amt:1,chapter:3,skippable:0}

# q35 — Sirencall-stage milestone gate: reach stage 2. FIXED.
#   milestone uses target for the mirror -> reward coins only.
data modify storage evercraft:fq_registry quests append value {id:35,title:"The Deep Answers",desc:"Advance the Sirencall path to its second stage. The deep is listening closer now.",type:"milestone",target:"sirencall_stage",count:2,reward:"coins",reward_amt:1,chapter:3,skippable:0}

# q36 — aquatic reuse: Silverscale Minnow, schooling thick in open water.
data modify storage evercraft:fq_registry quests append value {id:36,title:"A Hundred Silver Glints",desc:"Catch 5 Silverscale Minnow. They run in great shoals past the shallows.",type:"catch_aquatic",target:"silverscale_minnow",count:5,reward:"coins",reward_amt:1,chapter:3,skippable:0}

# q37 — any-catch climb.
data modify storage evercraft:fq_registry quests append value {id:37,title:"Far From Shore",desc:"Reel in 45 catches in all. Land is only a smudge on the horizon now.",type:"catch_any",target:"",count:45,reward:"coins",reward_amt:1,chapter:3,skippable:0}

# q38 — splash-node backbone climbs higher. catch_node -> target = crate TIER.
data modify storage evercraft:fq_registry quests append value {id:38,title:"Master of the Open Swell",desc:"Catch 18 fish from splash nodes on the open water. Few read the swell as you do.",type:"catch_node",target:"rare",count:18,reward:"crate",reward_amt:1,chapter:3,skippable:0}

# q39 — more Coppergill Bass (featured fish reused as a bigger hunt).
data modify storage evercraft:fq_registry quests append value {id:39,title:"The Copper Run",desc:"Catch 3 more Coppergill Bass. When the copper run comes in, fill your nets.",type:"catch_aquatic",target:"coppergill_bass",count:3,reward:"coins",reward_amt:1,chapter:3,skippable:0}

# q40 — rod-ladder milestone: reach rod tier 5. FIXED.
#   milestone uses target for the mirror -> reward coins only.
data modify storage evercraft:fq_registry quests append value {id:40,title:"A Rod for Open Water",desc:"Advance your fishing rod to tier 5 through the trials. The deep demands a stronger line.",type:"milestone",target:"rod_tier",count:5,reward:"coins",reward_amt:1,chapter:3,skippable:0}

# q41 — crate grind continues. catch_crate -> target = crate TIER.
data modify storage evercraft:fq_registry quests append value {id:41,title:"Deepwater Salvage",desc:"Fish up 5 crates from the open current. The deeper you go, the richer the haul.",type:"catch_crate",target:"rare",count:5,reward:"crate",reward_amt:1,chapter:3,skippable:0}

# q42 — more Mistpike (featured fish reused as a bigger hunt).
data modify storage evercraft:fq_registry quests append value {id:42,title:"Through the Grey Veil",desc:"Catch 3 more Mistpike from the haze. They are bolder in the open deep.",type:"catch_aquatic",target:"mistpike",count:3,reward:"coins",reward_amt:1,chapter:3,skippable:0}

# q43 — splash-node backbone, top of CH3. catch_node -> target = crate TIER.
data modify storage evercraft:fq_registry quests append value {id:43,title:"Eyes on the Water",desc:"Catch 20 fish from splash nodes. Nothing on the open swell escapes your notice.",type:"catch_node",target:"rare",count:20,reward:"crate",reward_amt:1,chapter:3,skippable:0}

# q44 — crate backbone closer. catch_crate -> target = crate TIER.
data modify storage evercraft:fq_registry quests append value {id:44,title:"The Open Water's Bounty",desc:"Fish up 6 crates in all from the deep current. The open water has been good to you.",type:"catch_crate",target:"rare",count:6,reward:"crate",reward_amt:1,chapter:3,skippable:0}

# q45 — chapter-3 closer: a big any-catch backbone before the crate chapter.
data modify storage evercraft:fq_registry quests append value {id:45,title:"Seasoned by the Swell",desc:"Reel in 60 catches in all. The open water holds no fear for you now — and the deep runs deeper.",type:"catch_any",target:"",count:60,reward:"coins",reward_amt:1,chapter:3,skippable:0}

# ------------------------------------------------------------
# HAND-OFF TO load_batch_2 (q46..):
#   - This batch ends at id=45. The next batch's FIRST quest MUST be id=46
#     (list index 45) and be appended immediately after q45, contiguously.
#   - registry/load calls load_batch_0, then load_batch_1; add the load_batch_2
#     call to registry/load when batch 2 lands. Do NOT renumber this batch.
#
# MILESTONE-MIRROR WIRING THIS BATCH ASSUMES (other agents own these hooks):
#   - ec.fq_rod_tier       : q40 reads rod tier 5 (the craftforever fishing trials).
#   - ec.fq_sirencall_stage: q35 reads Sirencall stage 2.
#   Both mirrors call evercraft:fishing/questline/check after each write,
#   per the catch/event hook contract established in batch_0.
# ------------------------------------------------------------
