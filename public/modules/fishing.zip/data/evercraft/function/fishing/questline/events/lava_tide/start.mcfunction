# ============================================================
# The Fisher's Questline — LAVA TIDE: START (4 minutes)
# ============================================================
# The Nether's lava seethes — fire-immune things can be FISHED UP from lava nodes.
# While active, clicking a nether lava splash node spawns a small fire-immune mob
# wave (skeleton pack / piglin brute), with a rare apex fireproof Warden.
# Set global active state + announce. Switches the cadence loop to 1s.

# --- Global state (fake-players on shared ec.var; single-writer = lava_tide/*). ---
scoreboard players set #fq_lava_tide ec.var 1
scoreboard players set #fq_lt_timer ec.var 240
scoreboard players set #fq_lt_wave ec.var 0

# --- Announce to Nether-dwellers (and a quiet line to everyone). ---
data modify storage evercraft:notify stage.c set value [{text:"LAVA TIDE",color:"red",bold:true}]
scoreboard players set #ndur ec.temp 50
execute as @a[predicate=evercraft:in_nether] run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"The lava seethes — things stir beneath the surface.",color:"gold",italic:true}]
scoreboard players set #ndur ec.temp 40
execute as @a[predicate=evercraft:in_nether] run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"+ ",color:"dark_red"},{text:"Fish a lava node to haul up fire-immune foes",color:"gray"}]
scoreboard players set #ndur ec.temp 40
execute as @a[predicate=evercraft:in_nether] run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"+ ",color:"dark_red"},{text:"An apex Warden may rise from the deepest pools",color:"gray"}]
scoreboard players set #ndur ec.temp 40
execute as @a[predicate=evercraft:in_nether] run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Duration: 4 minutes",color:"gray"}]
scoreboard players set #ndur ec.temp 40
execute as @a[predicate=evercraft:in_nether] run function evercraft:util/notify/emit

# --- Ominous sounds + title for Nether players. ---
execute as @a[predicate=evercraft:in_nether] if score @s ec.fx_snd matches 1.. at @s run playsound minecraft:block.lava.ambient master @s ~ ~ ~ 1.0 0.6
execute as @a[predicate=evercraft:in_nether] if score @s ec.fx_snd matches 1.. at @s run playsound minecraft:entity.warden.heartbeat master @s ~ ~ ~ 0.5 0.7
title @a[predicate=evercraft:in_nether] times 10 70 30
title @a[predicate=evercraft:in_nether] title [{text:"Lava Tide",color:"red"}]
title @a[predicate=evercraft:in_nether] subtitle [{text:"The lava seethes...",color:"gold",italic:true}]

# --- Switch the cadence loop to 1s for the active phase. ---
schedule function evercraft:fishing/questline/events/lava_tide/tick 1s replace
