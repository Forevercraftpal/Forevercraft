# ============================================================
# The Fisher's Questline — New-objective notification (after advance)
# ============================================================
# Run as @s = the player. Called once from questline/advance after the pointer
# moves to a new (non-final) quest. fq_cur already holds the new quest.
#
# PACING HOOKUP (Fisher rework 2026-06-10 — the line predated the pacing program;
# this now routes through the TWO shared layers exactly like the Cook engine):
#   1. util/notify/dispatch (key "fq_adv") — the mutable-notification layer, so the
#      "New objective" chime/title respects the player's global ec.notify filter +
#      a per-key [Mute] after 8 (250 beats = the most frequent adv key in the pack).
#   2. quest_pacing/render_lore — the lore line (gray-italic Seven-voice, muted by
#      ec.qln_mute in Quick Mode). EVERY fisher registry row carries skippable:0
#      (catches cannot be auto-granted), so skip_button_macro withholds [Skip ▸]
#      line-wide — the set_track fisher caveat stays truthful.

# === 1) MUTABLE "new objective" NUDGE (chatter class) ===
function evercraft:util/notify/dispatch {key:"fq_adv",class:"chatter",mute_at:8}
execute if score #notif_show_fq_adv ec.temp matches 1 run title @s times 5 40 10
execute if score #notif_show_fq_adv ec.temp matches 1 run title @s subtitle {text:"New objective available",color:"gray",italic:true}
execute if score #notif_show_fq_adv ec.temp matches 1 if score @s ec.fx_snd matches 1.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.6 1.2
execute if score #notif_show_fq_adv ec.temp matches 1 run function evercraft:fishing/questline/show_objective
execute if score #notif_show_mute_fq_adv ec.temp matches 1 run tellraw @s [{text:"  ",color:"dark_gray"},{text:"[Mute]",color:"dark_gray",hover_event:{action:"show_text",value:{text:"Stop showing new-objective nudges for the Fisher's Path.",color:"gray"}},click_event:{action:"run_command",command:"/trigger ec.nm_fq_adv set 1"}}]

# === 2) LORE LINE (independent of the chatter mute; no [Skip ▸] — skippable:0 rows) ===
data modify storage evercraft:qp_cur o set from storage evercraft:fq_cur quest
function evercraft:quest_pacing/render_lore
