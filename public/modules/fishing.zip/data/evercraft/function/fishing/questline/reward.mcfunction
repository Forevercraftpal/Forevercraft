# ============================================================
# The Fisher's Questline — Reward (pay out the completed quest)
# ============================================================
# Run as @s = the player. Reads the just-completed quest's reward fields from
# fq_cur.quest and dispatches on reward type. fq_cur still holds the OLD (just-
# completed) quest at this point (reward runs BEFORE advance bumps the pointer).
#
# Reward fields: reward (coins|crate|title|gear|trophy), reward_amt (int),
#                target (used as the gear/trophy item id, and crate tier name).
# Dispatch -> reward_type/<reward> macro helper. Item rewards (crate/gear/trophy)
# are inv-full aware via util/check_inv_full (prospect/complete_mine pattern).

# Flatten the quest fields for the reward macro.
data modify storage evercraft:fq_cur o set from storage evercraft:fq_cur quest
function evercraft:fishing/questline/reward_macro with storage evercraft:fq_cur o

# === ADDITIVE: D-Q10-REWARD artifact (Artifact-Fusion w1) ===
# On TOP of the q10 reward above (q10 = "Light on the Scales", coins). Fires only
# when the just-completed quest is #10 (ec.fq_quest still holds 10 here — advance
# bumps the pointer AFTER reward). Fishing q10 -> Dockhand's Knot (C31, Family J
# fishing leaf). One-shot per the pointer-equals-10 gate. Inv-full aware via the
# shared helper. (NOTE: q10's own reward `target` is "glimmer_trout", the catch
# target — NOT a reward field — so the artifact is a SEPARATE additive grant, it
# does not reuse the overloaded fishing `target`.)
execute if score @s ec.fq_quest matches 10 run data modify storage evercraft:q10r args set value {lt:"artifacts/common/dockhands_knot",name:"Dockhand's Knot",color:"white"}
execute if score @s ec.fq_quest matches 10 run function evercraft:artifacts/give/q10_reward with storage evercraft:q10r args
