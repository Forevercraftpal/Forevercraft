# FQ check helper — catch_weather (reel in N catches under a weather/time
# condition). Progress quest, IDENTICAL compare to catch_node.
# on_catch_hook increments ec.fq_prog for this quest ONLY on a normal reel-in
# while the quest.target condition (thunder/rain/night) holds (predicate-gated
# there); the engine just compares ec.fq_prog >= quest.count.
#
# *** SCHEMA: catch_weather consumes quest.target for the CONDITION (thunder|
# rain|night), exactly like catch_aquatic/event/special/milestone do. It can
# therefore reward ONLY coins/title — NOT crate/gear/trophy (those need target
# for their own id). Item rewards stay on catch_any/catch_crate/catch_node. ***
scoreboard players set #fq_satisfied ec.temp 0
execute if score @s ec.fq_prog >= #fq_count ec.temp run scoreboard players set #fq_satisfied ec.temp 1
