# ============================================================
# The Fisher's Questline — splash-node catch hook (catch_node feed)
# ============================================================
# Called from splash_nodes/do_catch every time a player instant-catches a node.
# Run as @s = the catching player, at the node position.
#
# CONTRACT (HOOK side — engine only compares fq_prog >= count):
#   ec.fq_prog is incremented HERE for the active quest, but ONLY when its type is
#   "catch_node" OR "catch_any" — a node catch IS a catch, so it feeds the generic
#   catch count too (Joseph 2026-06-04). It must NOT satisfy catch_crate / catch_aquatic
#   / dreamy_win / catch_weather / event thresholds (all those helpers just compare
#   fq_prog >= count). A quest is exactly one type, so at most ONE branch below fires
#   per node catch (no double-count). Type-gate via an NBT string-match on the quest.
#
# Existence-gated: do nothing unless this player has an active, unfinished line.

# --- Existence gate: no active questline -> bail (cheap, single score read). ---
execute unless score @s ec.fq_active matches 1 run return 0
execute if score @s ec.fq_complete matches 1 run return 0

# --- Load the current quest so we can read its type. ---
function evercraft:fishing/questline/get_quest

# --- Type-gate: credit this node catch toward catch_node OR catch_any. ---
# String NBT-match on the loaded quest object (no macro needed). Mutually exclusive
# (a quest is one type) — catch_node quests stay bound to nodes; catch_any quests
# may now progress via node catches too.
execute if data storage evercraft:fq_cur quest{type:"catch_node"} run scoreboard players add @s ec.fq_prog 1
execute if data storage evercraft:fq_cur quest{type:"catch_any"} run scoreboard players add @s ec.fq_prog 1

# --- Re-evaluate the quest (check re-loads get_quest itself; safe to call). ---
function evercraft:fishing/questline/check
