# ============================================================
# The Fisher's Questline — LAVA TIDE: cadence + active tick (self-scheduling)
# ============================================================
# Bootstrapped once from events/load. Decides: run-active / idle-condition-check,
# and ALWAYS re-schedules itself. Existence-gated: if no players are in the Nether
# there is nothing to do, so we idle at 60s and skip all work (no global scan).
#
# Modeled on world_events/tick: 1s cadence while active, 60s while idle.

# --- Existence gate: nobody in the Nether -> long idle, do nothing. ---
execute unless entity @a[predicate=evercraft:in_nether] run schedule function evercraft:fishing/questline/events/lava_tide/tick 60s
execute unless entity @a[predicate=evercraft:in_nether] run return 0

# === ACTIVE: run the 1s event tick, then re-schedule fast and bail. ===
execute if score #fq_lava_tide ec.var matches 1 run function evercraft:fishing/questline/events/lava_tide/active_tick
execute if score #fq_lava_tide ec.var matches 1 run schedule function evercraft:fishing/questline/events/lava_tide/tick 1s
execute if score #fq_lava_tide ec.var matches 1 run return 0

# === IDLE: roll a chance to begin a tide (cooldown-gated), then long-idle. ===
function evercraft:fishing/questline/events/lava_tide/try_start
schedule function evercraft:fishing/questline/events/lava_tide/tick 60s
