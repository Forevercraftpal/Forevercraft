# ============================================================
# The Fisher's Questline — LAVA TIDE: Active Tick (1s)
# ============================================================
# Runs once per second while #fq_lava_tide==1 (routed from lava_tide/tick under
# the in-Nether existence gate). Counts down the timer + emits ambient FX. The
# actual mob waves spawn ON-DEMAND when a player fishes a lava node (on_node_catch),
# NOT here — so there is no periodic global mob spawn (server-safe).

# --- Countdown. ---
scoreboard players remove #fq_lt_timer ec.var 1

# --- Ambient lava-surge particles for Nether players (cheap, local). ---
execute as @a[predicate=evercraft:in_nether] if score @s ec.fx_vis matches 1.. at @s run particle minecraft:lava ~ ~ ~ 4 1 4 0.0 2 force @s

# --- Warnings. ---
data modify storage evercraft:notify stage.c set value [{text:"1 minute remaining...",color:"gold"}]
scoreboard players set #ndur ec.temp 45
execute if score #fq_lt_timer ec.var matches 60 as @a[predicate=evercraft:in_nether] run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"The lava settles...",color:"gold"}]
scoreboard players set #ndur ec.temp 45
execute if score #fq_lt_timer ec.var matches 10 as @a[predicate=evercraft:in_nether] run function evercraft:util/notify/emit

# --- Timer expired -> stop. ---
execute if score #fq_lt_timer ec.var matches ..0 run function evercraft:fishing/questline/events/lava_tide/stop
