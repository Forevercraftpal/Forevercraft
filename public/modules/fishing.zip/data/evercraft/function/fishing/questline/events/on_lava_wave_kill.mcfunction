# ============================================================
# The Fisher's Questline — Lava Tide wave-mob kill reward
# ============================================================
# Fired by advancement evercraft:fishing/questline/events/lava_wave_kill
# (player_killed_entity on a ec.fq_lava_wave-tagged skeleton/brute — NOT the
# apex Warden, which has its own dedicated kill advancement).
# Run as @s = the killing player.
#
# Sets the lifetime "ever cleared a Lava Tide wave mob" flag, then — ONLY if the
# active quest is an event quest targeting "lava_tide" — bumps ec.fq_prog per
# kill (so a count>1 quest can require felling N tide foes) and re-checks.

# Re-arm.
advancement revoke @s only evercraft:fishing/questline/events/lava_wave_kill

# Lifetime sentinel.
scoreboard players set @s ec.fq_evt_lavatide 1

# --- Existence gate the questline feed. ---
execute unless score @s ec.fq_active matches 1 run return 0
execute if score @s ec.fq_complete matches 1 run return 0

# --- Load + type-gate: only credit an event quest whose target is "lava_tide". ---
function evercraft:fishing/questline/get_quest
execute if data storage evercraft:fq_cur quest{type:"event",target:"lava_tide"} run scoreboard players add @s ec.fq_prog 1

function evercraft:fishing/questline/check
