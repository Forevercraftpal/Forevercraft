# ============================================================
# The Fisher's Questline — Catch hook (the fq_prog incrementer for reel-ins)
# ============================================================
# Called at the END of evercraft:fishing/ref/on_catch, gated there by
# `if score @s ec.fq_active matches 1` so non-questline players pay nothing.
# Run as @s = the catching player.
#
# This file is ONE of the engine's fq_prog incrementer points (the other two are
# on_aquatic_hook + the milestone source-system hooks). It increments ec.fq_prog
# only for the catch types it owns — catch_any and catch_crate — then calls
# questline/check, which re-loads the current quest and advances if satisfied.
#
# WRITER of ec.fq_prog (increment): this file (catch_any/catch_crate), per the
# engine contract. start + advance own the reset-to-0. WRITER of ec.fq_crates_seen
# (the crate-delta cursor): this file ONLY.
#
# WHY a fc.total_crates delta and not #any_dropped ec.var:
#   The task suggested #any_dropped ec.var as the crate-dropped signal, but
#   inspection shows #any_dropped is set ONLY on the inv-full crate path
#   (fishing/ref/roll_crate_direct) — it stays 0 for the DOMINANT normal path,
#   whose crates are rolled via a dummy-item advancement that fires on a LATER
#   tick than on_catch (so no synchronous flag is available here at all).
#   fc.total_crates (fishing/ref/init) is the ONE monotonic per-player counter
#   bumped at every crate-grant endpoint across BOTH paths, ALL six tiers, and
#   the ornate/exquisite/mythical downgrade fns — i.e. exactly once per crate
#   actually received. We track how many we've already credited in
#   ec.fq_crates_seen and credit the difference, so a crate confirmed on the
#   deferred advancement tick is picked up on the next reel-in's hook (the
#   player is still actively fishing). No double-count, no missed crates, and
#   it is robust to the non-uniform process/grant/downgrade chain.

# --- Existence gate: do nothing unless this player has an active questline. ---
execute unless score @s ec.fq_active matches 1 run return 0
# --- Whole line already finished? No quest to progress. ---
execute if score @s ec.fq_complete matches 1 run return 0

# Load the current quest so we can read its type (check re-loads it too, but we
# need the type here to gate the increment to the right quest).
function evercraft:fishing/questline/get_quest

# === catch_any — any reel-in counts. +1 fq_prog. ===
execute if data storage evercraft:fq_cur {quest:{type:"catch_any"}} run scoreboard players add @s ec.fq_prog 1
# Multi-catch bonus fish (advantage/fishing/multi_catch, accumulated this catch into
# #fq_bonus_catch ec.temp; reset per-catch in ref/on_catch) count toward catch_any too,
# so "catch N fish" reflects the extra fish actually pulled. Joseph 2026-06-04.
execute if data storage evercraft:fq_cur {quest:{type:"catch_any"}} run scoreboard players operation @s ec.fq_prog += #fq_bonus_catch ec.temp

# === catch_weather — a reel-in that counts ONLY while a weather/time condition
# holds (set-piece sub-type). quest.target picks the condition; the matching
# predicate gates the increment. One-writer of fq_prog stays here (the reel-in
# path) alongside catch_any/catch_crate. Conditions (all overworld; nether/end
# read false for rain/thunder, which is correct — those tides are lava-side):
#   thunder -> evercraft:fishing/questline/events/is_thunderstorm (thundering)
#   rain    -> evercraft:is_raining (raining; also true during a thunderstorm)
#   night   -> time-of-day 13000..23000 via #visual_time ec.var (the pack's maintained 0-24000
#              time-of-day; the time_check predicate evercraft:mobs/time/night_time was 26.1-unparseable)
execute if data storage evercraft:fq_cur {quest:{type:"catch_weather",target:"thunder"}} if predicate evercraft:fishing/questline/events/is_thunderstorm run scoreboard players add @s ec.fq_prog 1
execute if data storage evercraft:fq_cur {quest:{type:"catch_weather",target:"rain"}} if predicate evercraft:is_raining run scoreboard players add @s ec.fq_prog 1
execute if data storage evercraft:fq_cur {quest:{type:"catch_weather",target:"night"}} if score #visual_time ec.var matches 13000..23000 run scoreboard players add @s ec.fq_prog 1

# === catch_crate — only when a crate was actually received this catch. ===
# Credit every new crate since we last looked (handles the deferred normal-path
# tick: previous catch's crate lands here on this reel-in). One-writer of the
# cursor lives in this file.
execute if data storage evercraft:fq_cur {quest:{type:"catch_crate"}} unless score @s ec.fq_crates_seen = @s fc.total_crates run function evercraft:fishing/questline/on_catch_hook/credit_crates

# Re-sync the cursor to the lifetime counter for non-crate quests too, so a
# catch_crate quest that becomes active mid-game starts counting from "now"
# (crates earned before the quest was active must not retro-complete it).
scoreboard players operation @s ec.fq_crates_seen = @s fc.total_crates

# Fisher's Questline spine: owning the spirit Tidecaller IS rod tier 10 (the q24 capstone).
# Detected on use here (the player fishes with it) — completing the t10 trial alone is not
# enough since the Tidecaller is only a 5% drop. Second writer of ec.fq_rod_tier (range =10,
# disjoint from the trial reward's 1-9 range).
execute if items entity @s weapon.mainhand minecraft:fishing_rod[custom_data~{spirit_tool:"tidecaller"}] if score @s ec.fq_rod_tier matches ..9 run scoreboard players set @s ec.fq_rod_tier 10

# Re-evaluate the active quest (check is existence-gated + idempotent).
function evercraft:fishing/questline/check
