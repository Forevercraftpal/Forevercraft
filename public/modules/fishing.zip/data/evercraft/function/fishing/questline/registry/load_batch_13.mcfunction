# ============================================================
# The Fisher's Questline — Registry batch 13 (THE GRAND FINALE, q249..q250)
# ============================================================
# Appends the final 2 quests onto storage evercraft:fq_registry quests.
# Called by registry/load AFTER load_batch_12. MUST append in id order
# (id=249 first => list index 248), contiguous, so list-position == ec.fq_quest-1.
#
# Quest object schema (the engine reads these exact fields):
#   {id:int, title:string, desc:string, type:string, target:string,
#    count:int, reward:string, reward_amt:int, chapter:int}
#
# *** SCHEMA CONSTRAINT (the `target` field is SHARED) ***
#   - q249 milestone: target carries the mirror name "total_done" -> reward
#       MUST be coins/title (here: title, reads only reward_amt = tier). The
#       final total_done gate (240 <= 248 ✓ at list position 249) AND the
#       highest title — tier 11, Eternal Tidecaller — ride this one milestone.
#   - q250 catch_any: the condition leaves target FREE, so target carries the
#       trophy item id (tidecallers_crown_trophy). The legal item-reward shape:
#       catch_any + reward trophy. This is the only way the crown artifact rides.
#
# This is CH15 — "The Tidecaller's Crown" — chapter:15, the grand finale.
# After a thousand casts the line ends here: the final title, then the Crown.
# ------------------------------------------------------------

# --- Chapter 15: The Tidecaller's Crown ------------------------------------

# q249 — the FINAL milestone: 240 quests cleared, and with it the highest
#   title of all — tier 11, Eternal Tidecaller. (240 <= 248, satisfiable.)
#   milestone uses target for the mirror "total_done" -> reward title (reads
#   only reward_amt = the tier). One step remains after this.
data modify storage evercraft:fq_registry quests append value {id:249,title:"Eternal Tidecaller",desc:"Complete 240 quests in all and take the eleventh and last title: Eternal Tidecaller. The whole of the water knows your name now. One cast remains.",type:"milestone",target:"total_done",count:240,reward:"title",reward_amt:11,chapter:15,skippable:0}

# q250 — THE GRAND FINALE CAPSTONE: the Tidecaller's Crown trophy, the rarest
#   prize the water keeps. 200 catches — still the longest count in the line
#   (RE-P1 tail re-curve 2026-06-10: q151-250 counts continue the front half's
#   ramp instead of tripling it; coins stay flat-1 per the 2026-05-31 lock) —
#   then the Crown is yours and the Fisher's Path is finished.
#   catch_any leaves target free -> target carries the trophy item id
#   (tidecallers_crown_trophy); reward trophy. This is the END of the line:
#   finishing q250 fires finish() / the questline-complete sentinel.
data modify storage evercraft:fq_registry quests append value {id:250,title:"The Tidecaller's Crown",desc:"Reel in 200 catches and at the last raise the Tidecaller's Crown from the water. From first cast to final reel, every storm and every spirit fish led here. The Fisher's Path is complete. Wear the Crown — you have earned all the deep can give.",type:"catch_any",target:"tidecallers_crown_trophy",count:200,reward:"trophy",reward_amt:1,chapter:15,skippable:0}

# ------------------------------------------------------------
# END OF LINE — load_batch_13 is the FINAL batch (q249..q250).
#   - This batch ends at id=250. There is NO load_batch_14 — the line ends here.
#   - registry/load calls load_batch_0 .. load_batch_13 in order; no further
#     batch call follows this one. Do NOT renumber this batch.
#   - q250 is the TRUE line finale (unlike q24's soft finale). The engine reads
#     N dynamically (list length = 250 once all batches are wired); finishing
#     q250 makes ec.fq_quest == N, so finish() / the questline-complete sentinel
#     fires here and nowhere else. The Fisher's Path is whole: q1 First Cast ->
#     q250 The Tidecaller's Crown.
#
# SPINE LANDING (this batch closes both final gates):
#   - total_done spine ends at 240 @ q249 (the last total_done milestone).
#   - title ladder ends at tier 11 @ q249 (Eternal Tidecaller), riding that gate.
#   - artifact capstones end with tidecallers_crown_trophy @ q250 (mythical),
#     the eleventh and last artifact — the Crown.
#
# MILESTONE-MIRROR WIRING THIS BATCH ASSUMES (other agents own these hooks):
#   - ec.fq_total_done : the running count of cleared quests; the milestone hook
#       compares it to count (240) and calls questline/check on each clear.
#   - q250 catch_any increments ec.fq_prog per reel-in (gated to the active
#       quest) then calls questline/check; on the 200th, ec.fq_quest reaches N
#       and finish() / the questline-complete sentinel fires. End of the Path.
# ------------------------------------------------------------
