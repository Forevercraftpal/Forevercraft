# ============================================================
# The Fisher's Questline — Registry load (storage init + batch dispatch)
# ============================================================
# Initializes the quest registry storage to an empty list, then calls each
# load_batch_K to append its quests. The storage is volatile across /reload,
# so this MUST run every reload (called from questline/load).
#
# Registry shape (storage evercraft:fq_registry):
#   {quests:[ {id,title,desc,type,target,count,reward,reward_amt,chapter}, ... ]}
#
# Each load_batch_K appends via:
#   data modify storage evercraft:fq_registry quests append value {...}
# Quests are appended in id order so the 0-based list index == (ec.fq_quest - 1).

# Reset to an empty quest list.
data modify storage evercraft:fq_registry quests set value []

# Append the quest batches, in id order (id 1 first => list index 0). Batch 0 is
# the q1..q24 on-ramp; batches 1..13 are the full Fisher's Path (q25..q250), one
# chapter each, authored against _council/2026-05-31-fishers-path/QUEST_MANIFEST.md.
# The line ends at q250 (load_batch_13); finishing it fires the complete sentinel.
function evercraft:fishing/questline/registry/load_batch_0
function evercraft:fishing/questline/registry/load_batch_1
function evercraft:fishing/questline/registry/load_batch_2
function evercraft:fishing/questline/registry/load_batch_3
function evercraft:fishing/questline/registry/load_batch_4
function evercraft:fishing/questline/registry/load_batch_5
function evercraft:fishing/questline/registry/load_batch_6
function evercraft:fishing/questline/registry/load_batch_7
function evercraft:fishing/questline/registry/load_batch_8
function evercraft:fishing/questline/registry/load_batch_9
function evercraft:fishing/questline/registry/load_batch_10
function evercraft:fishing/questline/registry/load_batch_11
function evercraft:fishing/questline/registry/load_batch_12
function evercraft:fishing/questline/registry/load_batch_13
