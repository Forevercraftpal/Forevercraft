# ============================================================
# The Fisher's Questline — tree-credit XP top-up (clone of tinkering/tree_sample/topup_xp)
# ============================================================
# Called `with storage evercraft:advantage` (the SAME storage advantage/levelup/fishing uses),
# where $(xp_cost) = this level's adv.req_xp (vanilla-XP cost, NOT difficulty-scaled). Grants
# exactly that many vanilla XP levels so the subsequent advantage/levelup/fishing gate passes;
# that level-up immediately deducts the same amount via advantage/deduct_xp -> NET ZERO real XP.
# This is the honest "realize one tree level through the NORMAL gate" move (XP-REWARD-ECONOMY.md
# §"Per-quest contribution": award the progress the tree consumes, NOT a raw `set adv.fishing`).
# Run as @s = the player. Mirrors the shape of tinkering/tree_sample/topup_xp exactly.
$experience add @s $(xp_cost) levels
