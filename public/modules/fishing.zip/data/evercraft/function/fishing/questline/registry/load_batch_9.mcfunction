# ============================================================
# The Fisher's Questline — Registry batch 9 (q193..q200)
# ============================================================
# Appends quests 193..200 onto storage evercraft:fq_registry quests.
# Called by registry/load AFTER load_batch_8. MUST append in id order
# (id=193 first => list index 192), contiguous, so list-position == ec.fq_quest-1.
#
# Quest object schema (the engine reads these exact fields):
#   {id:int, title:string, desc:string, type:string, target:string,
#    count:int, reward:string, reward_amt:int, chapter:int}
#
# *** SCHEMA CONSTRAINT (the `target` field is SHARED) ***
# A quest whose CONDITION uses target (catch_aquatic/event/special/milestone)
# CANNOT reward crate/gear/trophy — those need target for their own id, so they
# reward coins/title. Item rewards (crate/gear/trophy) ride ONLY catch_any /
# catch_crate / catch_node, whose condition leaves target free to carry the id.
#
# CH11 — Approaching the Tidecaller — THE CLIMAX OF ACT I.
# The final climb to the spirit rod. Reverent, rising tension: the deep goes
# quiet before the Tidecaller answers. Grind backbone + the q200 spine climax:
#   - q195 milestone total_done 175 -> coins 2800
#   - q198 catch_node saltwoven_cloak 90 -> gear (CAPSTONE artifact)
#   - q200 milestone rod_tier 10 -> title 9 (Tidecaller; the spirit rod earned)
# ------------------------------------------------------------

# --- Chapter 11: Approaching the Tidecaller ---------------------------------

# q193 — big any-catch backbone. The water stills; the climb begins.
data modify storage evercraft:fq_registry quests append value {id:193,title:"The Stilling Water",desc:"Reel in 120 catches. The deep goes quiet, the way water hushes before it answers.",type:"catch_any",target:"",count:120,reward:"coins",reward_amt:1,chapter:11,skippable:0}

# q194 — big splash-node backbone. catch_node leaves target free; coins reward.
data modify storage evercraft:fq_registry quests append value {id:194,title:"Reading the Hush",desc:"Catch 50 fish from splash nodes. Every ripple matters now, this near the end.",type:"catch_node",target:"",count:50,reward:"coins",reward_amt:1,chapter:11,skippable:0}

# q195 — total_done milestone: 175 quests cleared (satisfiable: 175 <= 194).
#   milestone uses target for the mirror -> reward coins (not item).
data modify storage evercraft:fq_registry quests append value {id:195,title:"The Long Road Behind",desc:"Complete 175 quests in all. Look back once: every cast led you to this shore.",type:"milestone",target:"total_done",count:175,reward:"coins",reward_amt:1,chapter:11,skippable:0}

# q196 — atmosphere set-piece: reel in under night (overworld catch_weather).
#   catch_weather uses target for the condition -> reward coins (not item).
data modify storage evercraft:fq_registry quests append value {id:196,title:"Vigil at the Tideline",desc:"Reel in 5 catches under a moonless night. Keep your vigil; the deep is listening.",type:"catch_weather",target:"night",count:5,reward:"coins",reward_amt:1,chapter:11,skippable:0}

# q197 — big any-catch backbone. The pressure climbs.
data modify storage evercraft:fq_registry quests append value {id:197,title:"Breath Before the Answer",desc:"Reel in 130 catches. Hold steady — the water is gathering itself to reply.",type:"catch_any",target:"",count:130,reward:"coins",reward_amt:1,chapter:11,skippable:0}

# q198 — *** CAPSTONE: the Saltwoven Cloak *** (catch_node leaves target free,
#   so target carries the GEAR-reward item id). 90 splash nodes for the cloak.
data modify storage evercraft:fq_registry quests append value {id:198,title:"The Saltwoven Cloak",desc:"Catch 55 fish from splash nodes to earn the Saltwoven Cloak — woven of brine and patience, worn only by those the deep has begun to trust.",type:"catch_node",target:"saltwoven_cloak",count:55,reward:"gear",reward_amt:1,chapter:11,skippable:0}

# q199 — final grind before the climax: the heaviest splash-node haul yet.
data modify storage evercraft:fq_registry quests append value {id:199,title:"On the Threshold",desc:"Catch 55 fish from splash nodes. One last labor — and then the deep answers.",type:"catch_node",target:"",count:55,reward:"coins",reward_amt:1,chapter:11,skippable:0}

# q200 — *** THE CLIMAX OF ACT I: rod tier 10, the spirit Tidecaller rod ***
#   milestone uses target for the mirror -> reward title (tier 9, "Tidecaller").
#   rod_tier 10 == owning the spirit Tidecaller, a rare drop after maxing the
#   fishing trials. The great climax — reverent, momentous.
data modify storage evercraft:fq_registry quests append value {id:200,title:"The Tidecaller Answers",desc:"Advance your rod to tier 10 and claim the spirit Tidecaller — the rare rod the deep yields only to a master who has finished the trial. Rise now as the Tidecaller. The sea calls you by name.",type:"milestone",target:"rod_tier",count:10,reward:"title",reward_amt:9,chapter:11,skippable:0}

# ------------------------------------------------------------
# HAND-OFF TO load_batch_10 (q201..):
#   - This batch ends at id=200. The next batch's FIRST quest MUST be id=201
#     (list index 200), appended immediately after q200, contiguously.
#   - registry/load calls load_batch_8 then this batch then load_batch_10.
#   - q200 is the Act I climax (spirit rod + title 9), not the line finale; the
#     engine reads N dynamically, so q200 advances into q201 once batch 10 lands.
#
# MILESTONE-MIRROR WIRING THIS BATCH ASSUMES (other agents own these hooks):
#   - ec.fq_rod_tier : tier 10 == owning the spirit Tidecaller (loot t10_reward,
#       custom_data{spirit_tool:"tidecaller"}); detect via predicate
#       evercraft:spirit_tools/holding_any. The trial/spirit-tool hook MUST call
#       evercraft:fishing/questline/check after writing the mirror.
#   - ec.fq_* total_done mirror (q195) updated by the questline completion hook,
#       which then calls questline/check.
# ------------------------------------------------------------
