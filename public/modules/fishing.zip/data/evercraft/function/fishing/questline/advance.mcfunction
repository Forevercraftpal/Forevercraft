# ============================================================
# The Fisher's Questline — Advance (complete current quest -> next)
# ============================================================
# Run as @s = the player. Called by questline/check when the active quest is
# satisfied. WRITER of the linear pointer (ec.fq_quest), ec.fq_prog reset,
# ec.fq_done, ec.fq_complete.
#
# Order: show_completed -> reward -> bump pointer (clamped) -> reset prog ->
#        +1 done -> load next quest -> show_objective. Final quest -> a one-shot
#        "questline complete!" tellraw, pointer clamped at N.

# --- Idempotency / out-of-range guards (mirror story upper-bound guard) ---
execute unless score @s ec.fq_active matches 1 run return 0
execute if score @s ec.fq_complete matches 1 run return 0

# Registry length = N (the last valid quest index). Dynamic so the engine never
# hardcodes the quest count — it grows automatically as batches are added.
execute store result score #fq_n ec.temp run data get storage evercraft:fq_registry quests
# Defensive: if the registry failed to load (length 0), do nothing.
execute if score #fq_n ec.temp matches ..0 run return 0
# If the pointer is somehow already past N, clamp + finish (don't run past the end).
execute if score @s ec.fq_quest > #fq_n ec.temp run function evercraft:fishing/questline/finish
execute if score @s ec.fq_quest > #fq_n ec.temp run return 0

# === 1) SHOW WHAT WAS JUST COMPLETED (fq_cur still holds the old quest) ===
function evercraft:fishing/questline/show_completed

# === 2) PAY OUT THE REWARD for the completed quest ===
function evercraft:fishing/questline/reward

# === 2b) ADDITIVE advantage-tree credit (Joseph 2026-06-01) — ON TOP of the reward
# above, never replacing it. Feeds the FISHING tree's grind gate (adv.stat_fish)
# so each quest advances adv.fishing via the engine's normal level-up gate (no raw
# `set adv.fishing`). Reads ec.fq_quest (still the OLD/just-completed index here).
# See fishing/questline/tree_credit for sizing + the modesty anchor. ===
function evercraft:fishing/questline/tree_credit

# === 3) ADVANCE THE LINEAR POINTER + COUNTERS ===
scoreboard players add @s ec.fq_quest 1
scoreboard players set @s ec.fq_prog 0
scoreboard players add @s ec.fq_done 1

# === BOOK OBTAIN (Grand Convergence Wave 5 / Chronicles W5) — ONE gate-first line ===
# On the FIRST completed Fisher's quest (ec.fq_done just crossed to exactly 1),
# hand the player the Angler's Codex (book/give is inventory-dup-guarded) — a
# fishing MILESTONE, NOT the first-rod hook (which already started the line, S8).
# book/give also fires the one-time Grand-Quests fusion OFFER (gq/offer_prompt,
# latched by ec.gq_offered). Reads ec.fq_done only; writes none of fishing/'s
# engine state. See fishing/questline/book/obtain for the full rationale.
execute if score @s ec.fq_done matches 1 run function evercraft:fishing/questline/book/obtain

# === 4) FINAL-QUEST HANDLING ===
# If the new pointer exceeds N, the player just finished the LAST quest. Detect
# the overflow FIRST (into a flag), then clamp the pointer back to N (so a future
# check can't index out of range) and run the one-shot completion fanfare.
scoreboard players set #fq_overflow ec.temp 0
execute if score @s ec.fq_quest > #fq_n ec.temp run scoreboard players set #fq_overflow ec.temp 1
execute if score #fq_overflow ec.temp matches 1 run scoreboard players operation @s ec.fq_quest = #fq_n ec.temp
execute if score #fq_overflow ec.temp matches 1 run function evercraft:fishing/questline/finish

# Not finished: load the next quest into fq_cur and show its objective.
execute if score #fq_overflow ec.temp matches 0 run function evercraft:fishing/questline/get_quest
execute if score #fq_overflow ec.temp matches 0 run function evercraft:fishing/questline/on_advance_notify

# Rod-gate helper: if the new quest is a rod_tier milestone, clear the player's
# FISHING trial lockout so the gate is never a timing wall (they can advance their
# rod at the Trial Anvil immediately). See rod_gate_unlock for the full rationale.
execute if score #fq_overflow ec.temp matches 0 if data storage evercraft:fq_cur quest{type:"milestone",target:"rod_tier"} run function evercraft:fishing/questline/rod_gate_unlock
