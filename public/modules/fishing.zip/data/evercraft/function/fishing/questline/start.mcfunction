# ============================================================
# The Fisher's Questline — Start (begin the line at quest 1)
# ============================================================
# Run as @s = the player picking up their first fishing rod (via the
# first_rod advancement reward fn, which guards on ec.fq_active == 0).
#
# Sets the linear pointer to quest 1, loads it into fq_cur, and shows the
# intro + first objective. WRITER of the initial pointer state.

# === ACTIVATE + RESET LINEAR STATE ===
scoreboard players set @s ec.fq_active 1
scoreboard players set @s ec.fq_quest 1
scoreboard players set @s ec.fq_prog 0
scoreboard players set @s ec.fq_done 0
scoreboard players set @s ec.fq_complete 0
# Seed the crate-credit cursor at the player's current lifetime crate count so
# crates fished BEFORE the questline began never retro-credit a catch_crate
# quest. on_catch_hook advances this cursor as new crates arrive.
scoreboard players operation @s ec.fq_crates_seen = @s fc.total_crates

# Load quest 1 into fq_cur for the objective display.
function evercraft:fishing/questline/get_quest

# === INTRO TELLRAW (mirrors story notify tone) ===
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"aqua"},{text:"The Fisher's Questline",color:"aqua",bold:true},{text:" ✦",color:"aqua"}]
scoreboard players set #ndur ec.temp 50
function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"An old line tugs at the water. A long road of catches lies ahead, angler — follow it to the end and become a Master Angler.",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.player.levelup master @s ~ ~ ~ 0.4 1.4
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.6 1.2

# Subtle title flash, then show the first objective.
title @s times 5 40 10
title @s subtitle {text:"Your first task awaits",color:"gray",italic:true}
function evercraft:fishing/questline/show_objective
# Pacing (q1-lore fill 2026-06-10, mirror build_quests/start): deliver quest 1's lore line
# (muted in Quick Mode); fisher rows carry skippable:0 so NO [Skip ▸] — advances get this via on_advance_notify; the start
# path was the one chat-silent entry.
data modify storage evercraft:qp_cur o set from storage evercraft:fq_cur quest
function evercraft:quest_pacing/render_lore
