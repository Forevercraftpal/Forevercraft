# ============================================================
# The Fisher's Questline — Fireproof Warden kill reward (apex set-piece cleared)
# ============================================================
# Fired by advancement evercraft:fishing/questline/events/fireproof_warden_kill
# (player_killed_entity on a ec.fq_fireproof_warden-tagged Warden).
# Run as @s = the killing player.
#
# Sets the lifetime "ever beat the fireproof Warden" flag, then — ONLY if the
# active quest is the matching event/special set-piece — bumps ec.fq_prog and
# re-checks the questline.

# Re-arm the advancement for a future quest that requires this apex again.
advancement revoke @s only evercraft:fishing/questline/events/fireproof_warden_kill

# Lifetime sentinel.
scoreboard players set @s ec.fq_evt_warden 1

# Celebratory line (apex kills are momentous).
data modify storage evercraft:notify stage.c set value [{text:"You felled the ",color:"gray"},{text:"Cinderbound Warden",color:"#FF4500",bold:true},{text:"— the lava's apex is yours.",color:"gray"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 1.0 0.8

# --- Existence gate the questline feed. ---
execute unless score @s ec.fq_active matches 1 run return 0
execute if score @s ec.fq_complete matches 1 run return 0

# --- Load + type-gate: only credit a quest awaiting the fireproof_warden apex. ---
function evercraft:fishing/questline/get_quest
execute if data storage evercraft:fq_cur quest{type:"special",target:"fireproof_warden"} run scoreboard players add @s ec.fq_prog 1
execute if data storage evercraft:fq_cur quest{type:"event",target:"fireproof_warden"} run scoreboard players add @s ec.fq_prog 1

function evercraft:fishing/questline/check
