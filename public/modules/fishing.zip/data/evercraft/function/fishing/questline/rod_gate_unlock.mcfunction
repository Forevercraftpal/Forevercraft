# ============================================================
# The Fisher's Questline — Rod-gate trial-lockout reset
# ============================================================
# Run as @s = the player. Called from questline/advance the moment the player
# advances INTO a rod_tier milestone quest (q8 t2 · q17 t3 · q22 t4 · q40 t5 ·
# q72 t6 · q120 t7 · q145 t8 · q180 t9 · q200 t10). fq_cur already holds the new
# quest (advance ran get_quest first).
#
# WHY: the rod ladder is gated on the craftforever FISHING trials, which carry a
# ~7-hour per-type lockout (trials/start checks dg.lo_tt3 via lockout/get). Without
# this, a player who reels through the catch-grind faster than the trial cadence
# would stall at a rod gate purely on the cooldown clock. Resetting the FISHING
# lockout (trial type 3) here means the rod gate is never a *timing* wall — the
# Trial Anvil's next fishing trial is immediately available the instant the Path
# asks for a stronger rod. We ALSO auto-grant one Trial Pass here, so the gate is
# never blocked on cooldown OR pass supply — the player only has to clear the trial.
# The theme "advance your rod through the trials" stays intact: only the wait is gone.
#
# Sets the lockout sentinel to 0 = "no active lockout": trials/start reads it as
# #dg_lockout_val (via lockout/get) and gates on `matches 1..`, so 0 skips the
# cooldown branch entirely. Event-driven write (not in any tick chain), so this
# second writer of dg.lo_tt3 (alongside trials/lockout/set) is one-writer-safe.

scoreboard players set @s dg.lo_tt3 0

# Auto-grant ONE Trial Pass so the gate is never blocked on pass supply either —
# the player can walk straight to the Trial Anvil and start the fishing trial. The
# pass is the trial system's `trial_key` w/ custom_data{trial_pass:true} that
# trials/start consumes. `at @s` so any inventory-overflow drops at the player's
# feet (matches the trials/daily_login_pass grant idiom). One pass per rod gate
# (9 gates total) — paced 1:1 with the rod tiers the Path asks the player to climb.
# Inv-full guard: drop at the player's feet rather than void on a full inventory.
execute store result score #inv_full ec.var run function evercraft:util/check_inv_full
execute at @s if score #inv_full ec.var matches 0 run loot give @s loot evercraft:craftforever/trials/trial_pass
execute at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:craftforever/trials/trial_pass

data modify storage evercraft:notify stage.c set value [{text:"⚓ ",color:"aqua"},{text:"Your line calls for a stronger rod. A ",color:"gray"},{text:"Trial Pass",color:"#FFA500",bold:true},{text:" is yours — the Trial Anvil's fishing trial is ready now.",color:"gray"},{text:" ⚓",color:"aqua"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.5 1.5
