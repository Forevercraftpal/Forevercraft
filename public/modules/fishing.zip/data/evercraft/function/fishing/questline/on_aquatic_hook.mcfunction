# ============================================================
# The Fisher's Questline — Aquatic/Spirit fish catch hook (catch_aquatic)
# ============================================================
# Call:  function evercraft:fishing/questline/on_aquatic_hook {fish_type:"<id>"}
# Appended (score-gated on ec.fq_active) to every per-fish grant fn:
#   fishing/aquatic_fish/grant/<type>  +  cooking/spirit_fish/grant/<type>
# Run as @s = the player who reeled the fish up.
#
# Increments ec.fq_prog by 1 ONLY when the active quest is type "catch_aquatic"
# AND quest.target == the caught fish_type, then calls questline/check. This is
# the engine's catch_aquatic incrementer point (one of the three fq_prog
# incrementers; one-writer of fq_prog increment is split across the hooks).
#
# Macro body: $(fish_type) is interpolated into a data-existence test against
# the flattened current quest so the SNBT match is exact (type + target).

# --- Existence gate: no active questline -> nothing to do. ---
execute unless score @s ec.fq_active matches 1 run return 0
# --- Whole line already complete? ---
execute if score @s ec.fq_complete matches 1 run return 0

# Load the current quest so we can match its type + target.
function evercraft:fishing/questline/get_quest

# +1 fq_prog iff this is a catch_aquatic quest targeting exactly this fish_type.
$execute if data storage evercraft:fq_cur {quest:{type:"catch_aquatic",target:"$(fish_type)"}} run scoreboard players add @s ec.fq_prog 1

# Re-evaluate (check is existence-gated + idempotent; safe even if no increment).
function evercraft:fishing/questline/check
