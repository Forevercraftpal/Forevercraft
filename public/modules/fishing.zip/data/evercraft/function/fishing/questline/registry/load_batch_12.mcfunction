# ============================================================
# The Fisher's Questline — Registry batch 12 (q237..q248)
# ============================================================
# Appends quests 237-248 onto storage evercraft:fq_registry quests.
# Called by registry/load AFTER load_batch_11. MUST append in id order
# (id=237 first => list index 236), contiguous, so list-position == ec.fq_quest-1.
#
# Quest object schema (the engine reads these exact fields):
#   {id:int, title:string, desc:string, type:string, target:string,
#    count:int, reward:string, reward_amt:int, chapter:int}
#
# CH14 — Trials of the Master (chapter:14): a gauntlet recombining EVERY
# palette mechanic at once. The victory-lap variety chapter before the finale.
# One of each set-piece: catch_weather thunder/rain/night, event charged_creeper,
# event lava_tide, a big catch_any, a big catch_node, a themed catch_aquatic.
# Master-tier counts. Rewards coins (+ two mythical crates on schema-legal
# catch_any/catch_node carriers). Triumphant, terse, second-person voice.
#
# *** SCHEMA CONSTRAINT (target is SHARED, per batch_0) ***
# Item rewards (crate) ride ONLY catch_any / catch_crate / catch_node, whose
# condition leaves target free to carry the crate tier. catch_weather / event /
# catch_aquatic consume target for their condition -> those reward coins only.
# NO gear/trophy/title in this chapter (those belong to the finale, ch15).
# ------------------------------------------------------------

# --- Chapter 14: Trials of the Master ---------------------------------------

# q237 — opener: a master-tier any-catch haul. catch_any leaves target free, so
#   target doubles as the crate-reward TIER (mythical). The gauntlet begins.
data modify storage evercraft:fq_registry quests append value {id:237,title:"Everything at Once",desc:"Reel in 130 catches to open the master's gauntlet. You have faced it all before. Face it again.",type:"catch_any",target:"mythical",count:130,reward:"crate",reward_amt:1,chapter:14,skippable:0}

# q238 — SET-PIECE: thunder. catch_weather consumes target -> reward coins.
data modify storage evercraft:fq_registry quests append value {id:238,title:"Into the Thunder",desc:"Land 14 catches while the storm rages overhead. The lightning is an old friend now.",type:"catch_weather",target:"thunder",count:14,reward:"coins",reward_amt:1,chapter:14,skippable:0}

# q239 — a big splash-node backbone. catch_node leaves target free -> target
#   doubles as the crate-reward TIER (ornate). Read the restless water once more.
data modify storage evercraft:fq_registry quests append value {id:239,title:"Master of the Ripple",desc:"Catch 55 fish from splash nodes. No surface stirs that you cannot read.",type:"catch_node",target:"ornate",count:55,reward:"crate",reward_amt:1,chapter:14,skippable:0}

# q240 — SET-PIECE: rain. catch_weather consumes target -> reward coins.
data modify storage evercraft:fq_registry quests append value {id:240,title:"Through the Downpour",desc:"Land 12 catches in the falling rain. Let it fall. You no longer feel it.",type:"catch_weather",target:"rain",count:12,reward:"coins",reward_amt:1,chapter:14,skippable:0}

# q241 — SET-PIECE: charged creeper (count 2, within 1-3). event consumes
#   target for the flag -> reward coins.
data modify storage evercraft:fq_registry quests append value {id:241,title:"Twin Bolts Again",desc:"During a thunderstorm, reel up 2 charged creepers. You have done this. Do it once more.",type:"event",target:"charged_creeper",count:2,reward:"coins",reward_amt:1,chapter:14,skippable:0}

# q242 — themed catch_aquatic: the Voidfin spirit. catch_aquatic consumes
#   target for the fish_type -> reward coins.
data modify storage evercraft:fq_registry quests append value {id:242,title:"The Voidfin Returns",desc:"Land a Voidfin once more. The lightless deep yields to a master's line.",type:"catch_aquatic",target:"voidfin",count:1,reward:"coins",reward_amt:1,chapter:14,skippable:0}

# q243 — SET-PIECE: night. catch_weather consumes target -> reward coins.
data modify storage evercraft:fq_registry quests append value {id:243,title:"Under a Dark Sky",desc:"Land 12 catches after dusk has fallen. The night holds nothing you have not already hauled from it.",type:"catch_weather",target:"night",count:12,reward:"coins",reward_amt:1,chapter:14,skippable:0}

# q244 — second big splash-node backbone. catch_node leaves target free -> the
#   second mythical crate of the gauntlet.
data modify storage evercraft:fq_registry quests append value {id:244,title:"Where the Water Breaks",desc:"Catch 60 fish from splash nodes. Every node, every break, every strike — mastered.",type:"catch_node",target:"mythical",count:60,reward:"crate",reward_amt:1,chapter:14,skippable:0}

# q245 — SET-PIECE: the Lava Tide (count 1 only, rare apex). event consumes
#   target for the flag -> reward coins.
data modify storage evercraft:fq_registry quests append value {id:245,title:"The Tide of Fire, Once More",desc:"Cast into a Lava Tide and pull something back. You know this heat. It does not know you.",type:"event",target:"lava_tide",count:1,reward:"coins",reward_amt:1,chapter:14,skippable:0}

# q246 — themed catch_aquatic: Brackish Perch (a roster aquatic, count 3).
#   catch_aquatic consumes target -> reward coins.
data modify storage evercraft:fq_registry quests append value {id:246,title:"Salt and Patience",desc:"Catch 3 Brackish Perch from the briny shallows. Even the humble catch bows to a master.",type:"catch_aquatic",target:"brackish_perch",count:3,reward:"coins",reward_amt:1,chapter:14,skippable:0}

# q247 — a master-tier any-catch backbone. catch_any leaves target free, but the
#   reward here is coins -> target stays empty.
data modify storage evercraft:fq_registry quests append value {id:247,title:"The Long Gauntlet",desc:"Reel in 140 catches in all. Trial upon trial, and still your line holds.",type:"catch_any",target:"",count:140,reward:"coins",reward_amt:1,chapter:14,skippable:0}

# q248 — chapter closer: the heaviest any-catch of the gauntlet. catch_any, coins.
#   The variety chapter ends here; the finale (ch15) awaits.
data modify storage evercraft:fq_registry quests append value {id:248,title:"You Have Faced It All",desc:"Reel in 160 catches to close the master's gauntlet. Nothing of the sea remains untested. The crown is near.",type:"catch_any",target:"",count:160,reward:"coins",reward_amt:1,chapter:14,skippable:0}

# ------------------------------------------------------------
# HAND-OFF TO load_batch_13 (q249..q250, the finale):
#   - This batch ends at id=248. The next batch's FIRST quest MUST be id=249
#     (list index 248), appended immediately after q248, contiguously.
#   - registry/load calls load_batch_11 then load_batch_12 then load_batch_13;
#     the main thread wires the batch calls. Do NOT renumber this batch.
#
# SET-PIECE FLAGS THIS BATCH ASSUMES (closed palette — other agents own hooks):
#   - event charged_creeper (q241): thunderstorm node set-piece fn increments
#       ec.fq_prog (gated to the active quest) then calls questline/check.
#   - event lava_tide (q245): nether lava-tide catch fn increments ec.fq_prog
#       (gated) then calls questline/check.
#   - catch_weather thunder/rain/night (q238/q240/q243): the reel-in hook reads
#       the overworld weather/time condition and increments ec.fq_prog (gated).
#   - catch_aquatic voidfin/brackish_perch (q242/q246): the fish-grant hook
#       matches the fish_type basename and increments ec.fq_prog (gated).
# ------------------------------------------------------------
