# ============================================================
# The Fisher's Questline — landed Dreamy Pull hook (dreamy_win feed)
# ============================================================
# Called from dreamy_pull/give_good_find (source-3 branch ONLY) every time a player LANDS
# (wins) a Dreamy Pull on a splash node — cross-epic S2 (Gatherer's Path ↔ Fisher's Path).
# Run as @s = the player, at the node position.
#
# CONTRACT (HOOK side — engine only compares fq_prog >= count):
#   ec.fq_prog is incremented HERE for the active quest when its type is "dreamy_win"
#   OR "catch_any" — a landed Dreamy Pull is still fishing, so it feeds the generic
#   catch count too (Joseph 2026-06-04). It must NOT satisfy catch_node / catch_aquatic
#   / catch_crate / catch_weather / event thresholds. A quest is exactly one type, so at
#   most ONE branch below fires. NOTE: a splash Dreamy Pull rides a successful node catch
#   (do_catch_success calls on_node_hook THEN maybe_trigger), so on a catch_any quest a
#   node-catch-that-also-lands-a-dreamy counts twice — intended (the dreamy is a separate
#   bonus "find" / "double harvest"). catch_node + dreamy_win quests stay bound to source.
#
# Existence-gated: do nothing unless this player has an active, unfinished line.

# --- Existence gate: no active questline -> bail (cheap, single score read). ---
execute unless score @s ec.fq_active matches 1 run return 0
execute if score @s ec.fq_complete matches 1 run return 0

# --- Load the current quest so we can read its type. ---
function evercraft:fishing/questline/get_quest

# --- Type-gate: credit this landed Dreamy Pull toward dreamy_win OR catch_any. ---
# String NBT-match on the loaded quest object (no macro needed). Mutually exclusive
# (a quest is one type) — dreamy_win quests stay bound to Dreamy Pulls; catch_any
# quests may now progress via a landed Dreamy Pull too.
execute if data storage evercraft:fq_cur quest{type:"dreamy_win"} run scoreboard players add @s ec.fq_prog 1
execute if data storage evercraft:fq_cur quest{type:"catch_any"} run scoreboard players add @s ec.fq_prog 1

# --- Re-evaluate the quest (check re-loads get_quest itself; safe to call). ---
function evercraft:fishing/questline/check
