# ============================================================
# The Fisher's Questline — SET-PIECE EVENTS: Load
# ============================================================
# Called once from evercraft:init (after splash_nodes/load). Declares the
# event-flag objectives the milestone/event quest checker + set-pieces read,
# and kicks off the self-scheduling Lava Tide world-event cadence loop.
#
# Declarations are guarded by #fq_evt_loaded ec.var so subsequent /reloads skip
# the "Objective already exists" spam (mirrors questline/declare_objectives P6).

# === ONE-TIME OBJECTIVE DECLARATIONS ===
execute unless score #fq_evt_loaded ec.var matches 1 run function evercraft:fishing/questline/events/declare_objectives

# === LAVA TIDE CADENCE LOOP (self-scheduling, existence-gated) ===
# tick decides activate / run-active / idle and re-schedules itself. Kick once.
# 'replace' so a /reload doesn't stack duplicate schedules.
schedule function evercraft:fishing/questline/events/lava_tide/tick 60s replace
