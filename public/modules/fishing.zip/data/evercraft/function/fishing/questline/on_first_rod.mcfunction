# ============================================================
# The Fisher's Questline — first_rod advancement reward
# ============================================================
# Fired the first time a player has a fishing rod in their inventory
# (advancement evercraft:fishing/questline/first_rod). @s = that player.
#
# Self-arming once: always revoke so the advancement can re-grant if the player
# never actually started (e.g. picked one up before the questline existed). Only
# kick off the line if it isn't already active — otherwise this is a no-op past
# the first rod.

# Revoke so the criterion re-arms (cheap; mirrors quests/explore/on_* pattern).
advancement revoke @s only evercraft:fishing/questline/first_rod

# Start the line only on the very first rod (ec.fq_active still 0).
execute unless score @s ec.fq_active matches 1 run function evercraft:fishing/questline/start
