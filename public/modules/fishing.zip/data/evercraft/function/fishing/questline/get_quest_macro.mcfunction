# ============================================================
# The Fisher's Questline — get_quest macro body
# ============================================================
# Called with storage evercraft:fq_cur containing {idx:<0-based index>}.
# Copies registry quest[idx] into evercraft:fq_cur quest.
$data modify storage evercraft:fq_cur quest set from storage evercraft:fq_registry quests[$(idx)]
