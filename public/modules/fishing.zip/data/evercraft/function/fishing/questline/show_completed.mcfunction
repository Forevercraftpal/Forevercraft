# ============================================================
# The Fisher's Questline — Show completed quest (just-finished one)
# ============================================================
# Reads the just-completed quest from fq_cur.quest (still the OLD quest at this
# point in advance, before the pointer is bumped) and prints a green checkmark
# line. Mirrors story/notify/show_completed tone.
# Run as @s = the player.

data modify storage evercraft:fq_cur o set from storage evercraft:fq_cur quest
function evercraft:fishing/questline/show_completed_macro with storage evercraft:fq_cur o
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.player.levelup master @s ~ ~ ~ 0.4 1.8
