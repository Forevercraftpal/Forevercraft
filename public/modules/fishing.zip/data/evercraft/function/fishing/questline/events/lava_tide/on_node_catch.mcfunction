# ============================================================
# The Fisher's Questline — LAVA TIDE: on nether-node catch (spawn a wave)
# ============================================================
# Hooked from splash_nodes/do_catch when a NETHER LAVA node is fished WHILE a
# Lava Tide is active. The do_catch hook already gated on:
#   #spl_dim ec.temp matches 2..        (nether lava node)
#   #fq_lava_tide ec.var matches 1      (tide active)
# Run as @s = the catching player, AT the node position.
#
# Hauls up a MODEST fire-immune wave the player fights. 0.09 chance the apex
# fireproof Warden rises instead of the standard pack (server-safe sizes).

# --- Apex roll: 9/100 -> the fireproof Warden; else the standard pack. ---
execute store result score #fq_apex_roll ec.temp run random value 1..100
execute if score #fq_apex_roll ec.temp matches 1..9 run return run function evercraft:fishing/questline/events/fireproof_warden

# --- Standard wave (no apex). Spawn the pack at/near the node. ---
function evercraft:fishing/questline/events/lava_tide/spawn_wave
