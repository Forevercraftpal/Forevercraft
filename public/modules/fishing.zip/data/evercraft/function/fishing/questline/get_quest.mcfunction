# ============================================================
# The Fisher's Questline — Load the current quest object into fq_cur
# ============================================================
# Reads the current quest (by linear pointer ec.fq_quest) out of the registry
# list and writes it to storage evercraft:fq_cur quest, so check/advance/reward
# can read quest.type/target/count/reward/reward_amt without per-quest files.
#
# The registry list is 0-indexed; ec.fq_quest is 1-based. This wrapper computes
# idx = ec.fq_quest - 1, stuffs it into storage, and calls the macro.
# Run as @s = the player.

# Compute 0-based list index from the 1-based linear pointer.
execute store result score #fq_idx ec.temp run scoreboard players get @s ec.fq_quest
scoreboard players remove #fq_idx ec.temp 1
execute store result storage evercraft:fq_cur idx int 1 run scoreboard players get #fq_idx ec.temp

# Macro-copy the quest object at that index into fq_cur.quest.
function evercraft:fishing/questline/get_quest_macro with storage evercraft:fq_cur
