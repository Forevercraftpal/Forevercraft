# ============================================================
# The Fisher's Questline — credit staged BONUS FISH toward a catch_any quest
# ============================================================
# Run as @s = the player. Credits #fq_bonus_catch ec.temp extra fish toward the
# active quest IFF it is type catch_any, then re-evaluates. Used by bonus-fish
# sources that fire OUTSIDE the ref/on_catch flow and therefore can't fold into
# on_catch_hook like multi_catch does — currently the craft_affinity Sirencall
# proc (craft_affinity/abilities/rod_on_catch, fired from detect_ordinary_tool).
#
# Type-gated to catch_any ONLY: a bonus-fish increment must not satisfy a
# catch_node / dreamy_win / catch_aquatic threshold — the same one-source rule
# the on_*_hook incrementers follow. (multi_catch's in-flow path is credited in
# on_catch_hook; this is the symmetric off-flow credit.)

# Existence gate + nothing-to-credit guard (cheap score reads first).
execute unless score @s ec.fq_active matches 1 run return 0
execute if score @s ec.fq_complete matches 1 run return 0
execute if score #fq_bonus_catch ec.temp matches ..0 run return 0

# Load the current quest, credit the bonus iff catch_any, then re-evaluate.
function evercraft:fishing/questline/get_quest
execute if data storage evercraft:fq_cur {quest:{type:"catch_any"}} run scoreboard players operation @s ec.fq_prog += #fq_bonus_catch ec.temp
function evercraft:fishing/questline/check

# Consume the staged bonus so it can't be re-credited.
scoreboard players set #fq_bonus_catch ec.temp 0
