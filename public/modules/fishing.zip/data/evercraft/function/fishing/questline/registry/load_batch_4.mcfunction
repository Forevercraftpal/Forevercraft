# ============================================================
# The Fisher's Questline — Registry batch 4 (q90..q110)
# ============================================================
# Chapter 6: "Storms & Omens" — weather & time, the catch_weather hub.
# This is the set-piece showcase chapter (OVERWORLD only — rain/thunder/night
# never fire in the nether/end). Appends q90..q110 onto storage
# evercraft:fq_registry quests, in id order (id=90 first => list index 89),
# contiguous, so list-position == ec.fq_quest-1.
#
# Quest object schema (the engine reads these exact fields):
#   {id:int, title:string, desc:string, type:string, target:string,
#    count:int, reward:string, reward_amt:int, chapter:int}
#
# *** SCHEMA CONSTRAINT (the shared `target` field) ***
# catch_weather/event/milestone CONSUME target for the condition, so they reward
# ONLY coins/title — never crate/gear/trophy. Item rewards (crate/gear/trophy)
# ride ONLY catch_any/catch_crate/catch_node, whose condition leaves target free
# to carry the reward tier/id. q110 capstone = catch_node + target:
# "charged_catch_trophy" + reward trophy is the legal pattern.
#
# Set-piece palette (CLOSED): event charged_creeper (count 1-3) · catch_weather
# thunder|rain|night (any count). No new flags — there is no handler and the
# linear line would soft-lock. catch_weather is overworld-only (correct here).
# ------------------------------------------------------------

# --- Chapter 6: Storms & Omens ---------------------------------------------

# q90 — total_done milestone: 50 quests cleared (50 <= 89, satisfiable).
#   milestone uses target for the mirror -> reward coins (not an item).
data modify storage evercraft:fq_registry quests append value {id:90,title:"Halfway to the Horizon",desc:"Complete 50 quests in all. Storm-clouds gather on the line ahead.",type:"milestone",target:"total_done",count:50,reward:"coins",reward_amt:1,chapter:6,skippable:0}

# q91 — grind: night-cast warmup. catch_weather night -> coins only.
data modify storage evercraft:fq_registry quests append value {id:91,title:"Under a Black Sky",desc:"Reel in 5 catches after dark. The night water keeps its own counsel.",type:"catch_weather",target:"night",count:5,reward:"coins",reward_amt:1,chapter:6,skippable:0}

# q92 — grind: rain-cast. catch_weather rain -> coins only.
data modify storage evercraft:fq_registry quests append value {id:92,title:"First Drops",desc:"Reel in 8 catches while rain falls. The clouds open and the fish rise.",type:"catch_weather",target:"rain",count:8,reward:"coins",reward_amt:1,chapter:6,skippable:0}

# q93 — grind: any-catch backbone. target free -> coins.
data modify storage evercraft:fq_registry quests append value {id:93,title:"Weathered Hands",desc:"Reel in 80 catches in all. Rain or shine, the line stays wet.",type:"catch_any",target:"",count:80,reward:"coins",reward_amt:1,chapter:6,skippable:0}

# q94 — grind: thunder-cast. catch_weather thunder -> coins only.
data modify storage evercraft:fq_registry quests append value {id:94,title:"Counting Thunder",desc:"Reel in 6 catches during a thunderstorm. Strike between the flashes.",type:"catch_weather",target:"thunder",count:6,reward:"coins",reward_amt:1,chapter:6,skippable:0}

# q95 — Sirencall-stage milestone gate: reach stage 4.
#   milestone uses target for the mirror -> reward coins (not an item).
data modify storage evercraft:fq_registry quests append value {id:95,title:"The Deep Calls Louder",desc:"Advance the Sirencall path to its fourth stage. The omen grows clearer.",type:"milestone",target:"sirencall_stage",count:4,reward:"coins",reward_amt:1,chapter:6,skippable:0}

# q96 — grind: splash-node backbone. catch_node leaves target free -> crate tier.
data modify storage evercraft:fq_registry quests append value {id:96,title:"Reading the Squall",desc:"Catch 35 fish from splash nodes. The storm churns them to the surface.",type:"catch_node",target:"ornate",count:35,reward:"crate",reward_amt:1,chapter:6,skippable:0}

# q97 — grind: night backbone, longer. catch_weather night -> coins only.
data modify storage evercraft:fq_registry quests append value {id:97,title:"Owl-Light Angler",desc:"Reel in 12 catches after dark. Some omens only show under moonlight.",type:"catch_weather",target:"night",count:12,reward:"coins",reward_amt:1,chapter:6,skippable:0}

# q98 — *** SET-PIECE: Storm Gauntlet *** (catch_weather thunder, FIXED).
#   catch_weather uses target for the condition -> reward coins (never an item).
data modify storage evercraft:fq_registry quests append value {id:98,title:"Storm Gauntlet",desc:"Reel in 10 catches during a thunderstorm. Let the lightning bless your line.",type:"catch_weather",target:"thunder",count:10,reward:"coins",reward_amt:1,chapter:6,skippable:0}

# q99 — grind: any-catch backbone climb. target free -> coins.
data modify storage evercraft:fq_registry quests append value {id:99,title:"Through the Downpour",desc:"Reel in 100 catches in all. The omens favor the stubborn.",type:"catch_any",target:"",count:100,reward:"coins",reward_amt:1,chapter:6,skippable:0}

# q100 — grind: rain backbone. catch_weather rain -> coins only.
data modify storage evercraft:fq_registry quests append value {id:100,title:"Drenched and Steady",desc:"Reel in 10 catches while rain falls. Hold the line through the wet.",type:"catch_weather",target:"rain",count:10,reward:"coins",reward_amt:1,chapter:6,skippable:0}

# q101 — grind: splash-node backbone, bigger. catch_node -> crate tier.
data modify storage evercraft:fq_registry quests append value {id:101,title:"Where Lightning Stirs the Water",desc:"Catch 40 fish from splash nodes. The charged deep gives up its strange catch.",type:"catch_node",target:"exquisite",count:40,reward:"crate",reward_amt:1,chapter:6,skippable:0}

# q102 — grind: night backbone, longer. catch_weather night -> coins only.
data modify storage evercraft:fq_registry quests append value {id:102,title:"Omen of the Dark Tide",desc:"Reel in 15 catches after dark. The deep speaks plainest at midnight.",type:"catch_weather",target:"night",count:15,reward:"coins",reward_amt:1,chapter:6,skippable:0}

# q103 — *** SET-PIECE: Rainfisher *** (catch_weather rain, FIXED).
#   catch_weather uses target for the condition -> reward coins (never an item).
data modify storage evercraft:fq_registry quests append value {id:103,title:"Rainfisher",desc:"Reel in 15 catches while rain falls. The downpour is a calling, not a curse.",type:"catch_weather",target:"rain",count:15,reward:"coins",reward_amt:1,chapter:6,skippable:0}

# q104 — grind: thunder backbone, bigger. catch_weather thunder -> coins only.
data modify storage evercraft:fq_registry quests append value {id:104,title:"Walking the Tempest",desc:"Reel in 18 catches during a thunderstorm. The omens roar; answer them.",type:"catch_weather",target:"thunder",count:18,reward:"coins",reward_amt:1,chapter:6,skippable:0}

# q105 — title tier 6: Stormhauler. catch_any leaves target free -> title.
data modify storage evercraft:fq_registry quests append value {id:105,title:"Stormhauler",desc:"Reel in 150 catches in all. Claim the title of Stormhauler — you fish where others flee.",type:"catch_any",target:"",count:150,reward:"title",reward_amt:6,chapter:6,skippable:0}

# q106 — grind: night backbone, biggest. catch_weather night -> coins only.
data modify storage evercraft:fq_registry quests append value {id:106,title:"Vigil at the Black Water",desc:"Reel in 20 catches after dark. Keep the long vigil; the omen is close.",type:"catch_weather",target:"night",count:20,reward:"coins",reward_amt:1,chapter:6,skippable:0}

# q107 — *** SET-PIECE: the player's FIRST charged-creeper *** (event, count 1).
#   Relocated here 2026-06-09 from q6 (was a thunderstorm RNG wall in the Ch1 tutorial,
#   before rod tier 2). This Ch6 storm chapter already surrounds it with thunder quests
#   (q94/98/104/108), so the 1/60 storm-summon fires organically and it's "hard but fair."
#   The count-2 "twin" reprise stays at q241. event consumes target -> reward coins.
data modify storage evercraft:fq_registry quests append value {id:107,title:"The Storm's Gift",desc:"During a thunderstorm, reel up a charged creeper. Lightning favors the bold.",type:"event",target:"charged_creeper",count:1,reward:"coins",reward_amt:1,chapter:6,skippable:0}

# q108 — grind: thunder backbone, biggest. catch_weather thunder -> coins only.
data modify storage evercraft:fq_registry quests append value {id:108,title:"Heart of the Storm",desc:"Reel in 20 catches during a thunderstorm. Stand in the eye and cast true.",type:"catch_weather",target:"thunder",count:20,reward:"coins",reward_amt:1,chapter:6,skippable:0}

# q109 — grind: any-catch backbone, pre-capstone climb. target free -> coins.
data modify storage evercraft:fq_registry quests append value {id:109,title:"Bearer of Omens",desc:"Reel in 120 catches in all. The signs all point to the charged deep below.",type:"catch_any",target:"",count:120,reward:"coins",reward_amt:1,chapter:6,skippable:0}

# q110 — CAPSTONE: the Charged Catch Trophy. catch_node leaves target free, so
#   target carries the TROPHY-reward item id (reward agent owns the table).
data modify storage evercraft:fq_registry quests append value {id:110,title:"The Charged Catch",desc:"Catch 60 fish from splash nodes under the storm. Claim the Charged Catch Trophy — proof you mastered the tempest.",type:"catch_node",target:"charged_catch_trophy",count:60,reward:"trophy",reward_amt:1,chapter:6,skippable:0}

# ------------------------------------------------------------
# HAND-OFF TO load_batch_5 (q111..):
#   - This batch ends at id=110. The next batch's FIRST quest MUST be id=111
#     (list index 110), appended immediately after q110, contiguously.
#   - registry/load calls the batches in order; the main thread wires this
#     batch's call into registry/load. Do NOT renumber this batch.
#   - CH7 (load_batch_5) is nether/lava — NO catch_weather there (rain/thunder/
#     night never fire in the nether). This chapter is the overworld weather hub.
#
# MIRROR / SET-PIECE WIRING THIS BATCH ASSUMES (other agents own these hooks):
#   - ec.fq_sirencall_stage (q95): written by the Sirencall progression hook;
#       calls questline/check after each stage-up.
#   - total_done (q90): the engine's own completed-quest tally mirror.
#   - catch_weather (rain/thunder/night): the fishing catch hook reads world
#     weather/time, increments ec.fq_prog when it matches the active quest's
#     target, then calls questline/check (overworld only).
#   - event charged_creeper (q107): the thunderstorm charged-creeper set-piece fn
#     increments ec.fq_prog (gated to the matching active quest) then calls
#     questline/check, per the catch/event hook contract.
# ------------------------------------------------------------
