# FQ check helper — catch_any (any reel-in). Progress quest.
# Satisfied when ec.fq_prog >= quest.count (#fq_count ec.temp). @s = player.
scoreboard players set #fq_satisfied ec.temp 0
execute if score @s ec.fq_prog >= #fq_count ec.temp run scoreboard players set #fq_satisfied ec.temp 1
