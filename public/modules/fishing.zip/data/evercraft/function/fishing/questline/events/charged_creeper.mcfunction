# ============================================================
# The Fisher's Questline — SET-PIECE: Stormcharge (charged creeper)
# ============================================================
# Hooked from splash_nodes/do_catch when an OVERWORLD WATER node is clicked
# DURING A THUNDERSTORM. The do_catch hook already gated on:
#   #spl_dim ec.temp matches ..1   (overworld water node)
#   predicate evercraft:fishing/questline/events/is_thunderstorm  (thundering)
# Run as @s = the catching player, AT the node position.
#
# 1/60 chance to summon a charged creeper at the node instead of a calm catch.
# (The calm catch already fired earlier in do_catch — this is an ADDED hazard,
#  so a failed roll simply does nothing and the player keeps the catch.)
#
# DEFEAT FLOW: the creeper is tagged ec.fq_charged_creeper. When a player kills it,
# the advancement evercraft:fishing/questline/events/charged_creeper_kill fires
# evercraft:fishing/questline/events/on_charged_creeper_kill, which advances any
# quest of type event/special awaiting "charged_creeper".

# --- 1/60 roll. Bail on the other 59. ---
execute store result score #fq_cc_roll ec.temp run random value 1..60
execute unless score #fq_cc_roll ec.temp matches 1 run return 0

# --- Summon a charged creeper at the node (powered = charged). ---
# PersistenceRequired so it can't despawn before the player engages it.
# Glowing so it reads clearly as a storm-summoned hazard on the water surface.
summon minecraft:creeper ~ ~ ~ {Tags:["ec.fq_charged_creeper"],powered:1b,PersistenceRequired:1b,Glowing:1b,CustomNameVisible:1b,CustomName:{text:"Storm-Charged Lurker",color:"aqua"}}

# --- Flavor: storm crack + warning. ---
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.lightning_bolt.thunder master @s ~ ~ ~ 1.0 1.2
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.creeper.primed master @s ~ ~ ~ 0.9 0.8
execute if score @s ec.fx_vis matches 1.. run particle minecraft:electric_spark ~ ~1 ~ 0.6 0.6 0.6 0.1 30
data modify storage evercraft:notify stage.c set value [{text:"The thunderhead spits a ",color:"gray"},{text:"Storm-Charged Lurker",color:"aqua",bold:true},{text:" from the deep!",color:"gray"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
