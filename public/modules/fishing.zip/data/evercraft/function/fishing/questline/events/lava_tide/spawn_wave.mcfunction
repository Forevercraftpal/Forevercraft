# ============================================================
# The Fisher's Questline — LAVA TIDE: spawn a fire-immune wave (standard pack)
# ============================================================
# Run as @s = the catching player, AT the node position. Hauls up a MODEST
# fire-immune pack: a small skeleton group + (sometimes) one piglin brute.
# Wave size is deliberately small (server-safe) — the tide spawns these on each
# node catch, so per-spawn counts stay low.
#
# Fire-immunity: skeletons + brutes are NOT naturally lava-proof, so every wave
# mob carries the ec.fq_lava_mob tag (for cleanup on stop) AND a long
# fire_resistance effect applied immediately after summon.

# --- Bump the wave counter (FX/announce cadence; written here only). ---
scoreboard players add #fq_lt_wave ec.var 1

# --- Skeleton pack: 2 base, +1 third on a coin flip (so avg ~2.5). ---
summon minecraft:skeleton ~1 ~ ~1 {Tags:["ec.fq_lava_mob","ec.fq_lava_wave","ec.fq_lava_skel"],PersistenceRequired:1b,CanPickUpLoot:0b,DeathLootTable:"minecraft:empty",CustomName:{text:"Cinder Skeleton",color:"#FF6A3D"},equipment:{mainhand:{id:"minecraft:bow",count:1}},drop_chances:{mainhand:0f}}
summon minecraft:skeleton ~-1 ~ ~-1 {Tags:["ec.fq_lava_mob","ec.fq_lava_wave","ec.fq_lava_skel"],PersistenceRequired:1b,CanPickUpLoot:0b,DeathLootTable:"minecraft:empty",CustomName:{text:"Cinder Skeleton",color:"#FF6A3D"},equipment:{mainhand:{id:"minecraft:bow",count:1}},drop_chances:{mainhand:0f}}
execute store result score #fq_extra ec.temp run random value 1..2
execute if score #fq_extra ec.temp matches 1 run summon minecraft:skeleton ~ ~ ~-1 {Tags:["ec.fq_lava_mob","ec.fq_lava_wave","ec.fq_lava_skel"],PersistenceRequired:1b,CanPickUpLoot:0b,DeathLootTable:"minecraft:empty",CustomName:{text:"Cinder Skeleton",color:"#FF6A3D"},equipment:{mainhand:{id:"minecraft:bow",count:1}},drop_chances:{mainhand:0f}}

# --- Piglin brute: 1 on a ~1/3 roll (the heavy of the pack). ---
execute store result score #fq_brute ec.temp run random value 1..3
execute if score #fq_brute ec.temp matches 1 run summon minecraft:piglin_brute ~ ~ ~1 {Tags:["ec.fq_lava_mob","ec.fq_lava_wave","ec.fq_lava_brute"],PersistenceRequired:1b,IsImmuneToZombification:1b,CanPickUpLoot:0b,DeathLootTable:"minecraft:empty",CustomName:{text:"Emberhide Brute",color:"#D2691E"}}

# --- Make the whole wave fire-immune (8 min covers the 4-min tide + lingering). ---
# Applied to freshly-tagged-but-unstamped mobs; ec.fq_lava_fr marks them done.
effect give @e[tag=ec.fq_lava_mob,tag=!ec.fq_lava_fr,distance=..6] minecraft:fire_resistance 480 0 true
tag @e[tag=ec.fq_lava_mob,tag=!ec.fq_lava_fr,distance=..6] add ec.fq_lava_fr

# --- Haul-up FX. ---
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.hostile.splash master @s ~ ~ ~ 0.9 0.7
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.lava.pop master @s ~ ~ ~ 1.0 0.8
execute if score @s ec.fx_vis matches 1.. run particle minecraft:flame ~ ~1 ~ 0.8 0.8 0.8 0.05 25
data modify storage evercraft:notify stage.c set value [{text:"Your line drags up something burning— ",color:"gray"},{text:"fire-immune foes",color:"gold",bold:true},{text:" climb from the lava!",color:"gray"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
