# Master-Angler title tier 2 — "Linehand". @s = player.
title @s times 8 50 12
title @s title [{text:"✦ ",color:"green"},{text:"Linehand",color:"green"},{text:" ✦",color:"green"}]
title @s subtitle {text:"Master-Angler title earned",color:"dark_gray",italic:true}
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"green"},{text:"Master-Angler title earned: ",color:"white"},{text:"Linehand",color:"green",bold:true},{text:" ✦",color:"green"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 0.7 1.05
