# Master-Angler title tier 4 — "Deepwarden". @s = player.
title @s times 8 50 12
title @s title [{text:"✦ ",color:"dark_aqua"},{text:"Deepwarden",color:"dark_aqua"},{text:" ✦",color:"dark_aqua"}]
title @s subtitle {text:"Master-Angler title earned",color:"dark_gray",italic:true}
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"dark_aqua"},{text:"Master-Angler title earned: ",color:"white"},{text:"Deepwarden",color:"dark_aqua",bold:true},{text:" ✦",color:"dark_aqua"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 0.8 1.15
