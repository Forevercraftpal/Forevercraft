# ============================================================
# The Fisher's Questline — Finish (one-shot completion fanfare)
# ============================================================
# Run as @s = the player who just completed the final quest. Sets the
# ec.fq_complete sentinel so this fires exactly once, then prints the
# "questline complete!" celebration. WRITER of ec.fq_complete (with advance).

# Guard: only ever fire once.
execute if score @s ec.fq_complete matches 1 run return 0
scoreboard players set @s ec.fq_complete 1

data modify storage evercraft:notify stage.c set value [{text:"★ ",color:"gold"},{text:"The Fisher's Questline — Complete!",color:"gold",bold:true},{text:" ★",color:"gold"}]
scoreboard players set #ndur ec.temp 50
function evercraft:util/notify/emit_keep
data modify storage evercraft:notify stage.c set value [{text:"Every line has been cast, every catch landed. You stand among the Master Anglers of Forevercraft.",color:"yellow",italic:true}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit

title @s times 10 60 20
title @s title {text:"Master Angler",color:"gold"}
title @s subtitle {text:"The Fisher's Questline is complete",color:"yellow"}

execute if score @s ec.fx_snd matches 1.. run playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 1.0 1.0
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.player.levelup master @s ~ ~ ~ 0.6 1.2

# === ADDITIVE: difficulty-scaled FISHING-tree prestige capstone (Joseph 2026-06-01) ===
# On TOP of the celebration above. Runs once (inside this ec.fq_complete one-shot guard).
# Drives prestige on adv.fishing via the existing advantage/prestige/do_prestige path:
# Newcomer = 2 / Adventurer = 1 / Pioneer or unset = 1 (Council review 2026-06-01, revised
# down from 3/2/1). See tree_capstone.
function evercraft:fishing/questline/tree_capstone

# === ADDITIVE: exit handoff (Questline Restructure W4, 2026-06-10) ===
# The Path of a quarter-thousand quests ends; the water does not — splash nodes and
# the aquatic depths keep paying, and the Grand Chronicle may now be ready.
function evercraft:grand_quests/exit_handoff_fisher

# Clear a stale tracked-Path pin if THIS line was pinned (QR-P5, 2026-06-10).
function evercraft:grand_quests/untrack_on_finish {slot:1}
