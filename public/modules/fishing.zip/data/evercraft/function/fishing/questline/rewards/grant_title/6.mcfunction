# Master-Angler title tier 6 (capstone) — "Tidecaller". @s = player.
title @s times 12 70 16
title @s title [{text:"✦ ",color:"#3FE0E0"},{text:"Tidecaller",color:"#3FE0E0"},{text:" ✦",color:"#3FE0E0"}]
title @s subtitle {text:"The deep itself knows your name",color:"aqua",italic:true}
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"#3FE0E0"},{text:"Master-Angler title earned: ",color:"white"},{text:"Tidecaller",color:"#3FE0E0",bold:true},{text:" ✦",color:"#3FE0E0"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"The whole ocean answers your cast now.",color:"dark_aqua",italic:true}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 1.0 1.25
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.player.levelup master @s ~ ~ ~ 0.6 0.8
