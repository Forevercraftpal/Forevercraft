# ============================================================
# The Fisher's Questline — Registry batch 8 (q175..q192)
# ============================================================
# Appends Chapter 10 — "Leviathan's Wake" — the apex hunt.
# Called by registry/load AFTER batch 7. MUST append in id order
# (id=175 first => list index 174), contiguous, no gaps.
#
# Quest object schema (the engine reads these exact fields):
#   {id:int, title:string, desc:string, type:string, target:string,
#    count:int, reward:string, reward_amt:int, chapter:int}
#
# *** SCHEMA CONSTRAINT (the shared `target` field) ***
# Item rewards (crate/gear/trophy) ride ONLY catch_any/catch_crate/
# catch_node, whose condition leaves target free to carry the reward
# tier/id. catch_aquatic/milestone consume target for the condition,
# so they reward coins/title only. Honored throughout this batch.
#
# Chapter 10 closes the long haul: the Leviathan surfaces. Counts run
# heavy (node 70->90, any 180->220), tension rising toward the capstone
# leviathan_trophy at q192. Rod ladder reaches t9 (q180); Sirencall hits
# its MAX stage 7 (q185); title tier 8 "Leviathan's Bane" lands at q190.
# ------------------------------------------------------------

# --- Chapter 10: Leviathan's Wake ------------------------------------------

# q175 — the wake opens: a vast shape stirs the water. Big any-catch backbone.
data modify storage evercraft:fq_registry quests append value {id:175,title:"Leviathan's Wake",desc:"Reel in 130 catches in all. Something vast has begun to stir the water beneath you.",type:"catch_any",target:"",count:130,reward:"coins",reward_amt:1,chapter:10,skippable:0}

# q176 — first trace of the apex fish. catch_aquatic, leviathans_whisker reuse.
data modify storage evercraft:fq_registry quests append value {id:176,title:"A Whisker on the Wind",desc:"Land a single Leviathan's Whisker. The first proof the apex is near.",type:"catch_aquatic",target:"leviathans_whisker",count:1,reward:"coins",reward_amt:1,chapter:10,skippable:0}

# q177 — node grind. catch_node leaves target free -> crate tier (exquisite).
data modify storage evercraft:fq_registry quests append value {id:177,title:"The Deep Goes Still",desc:"Catch 40 fish from splash nodes. The water has gone quiet — and quiet means the apex is hunting too.",type:"catch_node",target:"exquisite",count:40,reward:"crate",reward_amt:1,chapter:10,skippable:0}

# q178 — any-catch backbone climbs.
data modify storage evercraft:fq_registry quests append value {id:178,title:"Closing the Distance",desc:"Reel in 110 catches in all. Each cast draws the great shape a little nearer.",type:"catch_any",target:"",count:110,reward:"coins",reward_amt:1,chapter:10,skippable:0}

# q179 — node grind, exquisite crate. The hunt tightens.
data modify storage evercraft:fq_registry quests append value {id:179,title:"Where the Water Boils",desc:"Catch 45 fish from splash nodes. The surface churns wherever the Leviathan passes.",type:"catch_node",target:"exquisite",count:45,reward:"crate",reward_amt:1,chapter:10,skippable:0}

# q180 — FIXED: rod-ladder milestone, rod tier 9. milestone -> coins.
data modify storage evercraft:fq_registry quests append value {id:180,title:"A Rod for the Apex",desc:"Advance your fishing rod to tier 9 through the fishing trials. No lesser line will hold the Leviathan.",type:"milestone",target:"rod_tier",count:9,reward:"coins",reward_amt:1,chapter:10,skippable:0}

# q181 — more whisker traces. catch_aquatic, leviathans_whisker x2.
data modify storage evercraft:fq_registry quests append value {id:181,title:"Trail of Whiskers",desc:"Land 2 Leviathan's Whiskers. The apex circles closer with every one you take.",type:"catch_aquatic",target:"leviathans_whisker",count:2,reward:"coins",reward_amt:1,chapter:10,skippable:0}

# q182 — node grind, mythical crate now. The biggest hauls of the chapter begin.
data modify storage evercraft:fq_registry quests append value {id:182,title:"Hauling the Heavy Water",desc:"Catch 50 fish from splash nodes. Pull until your arms ache — the apex rewards the relentless.",type:"catch_node",target:"mythical",count:50,reward:"crate",reward_amt:1,chapter:10,skippable:0}

# q183 — FIXED: the Leviathan Hunt. catch_aquatic, leviathans_whisker x1 -> coins.
data modify storage evercraft:fq_registry quests append value {id:183,title:"Leviathan Hunt",desc:"Hunt down a Leviathan's Whisker on its own terms. The apex spirit has chosen to answer your line.",type:"catch_aquatic",target:"leviathans_whisker",count:1,reward:"coins",reward_amt:1,chapter:10,skippable:0}

# q184 — any-catch backbone climbs to 200.
data modify storage evercraft:fq_registry quests append value {id:184,title:"The Shape Beneath",desc:"Reel in 120 catches in all. A shadow the size of a longship now follows your every cast.",type:"catch_any",target:"",count:120,reward:"coins",reward_amt:1,chapter:10,skippable:0}

# q185 — FIXED: Sirencall MAX. milestone, sirencall_stage 7 -> coins.
data modify storage evercraft:fq_registry quests append value {id:185,title:"The Sirencall, Answered",desc:"Reach the seventh and final stage of the Sirencall. The deep has spoken its last word to you.",type:"milestone",target:"sirencall_stage",count:7,reward:"coins",reward_amt:1,chapter:10,skippable:0}

# q186 — node grind, mythical crate.
data modify storage evercraft:fq_registry quests append value {id:186,title:"Bracing the Line",desc:"Catch 50 fish from splash nodes. Steady your stance — what comes next will test the rod and the angler both.",type:"catch_node",target:"mythical",count:50,reward:"crate",reward_amt:1,chapter:10,skippable:0}

# q187 — any-catch backbone climbs to 210.
data modify storage evercraft:fq_registry quests append value {id:187,title:"No Turning Back",desc:"Reel in 130 catches in all. You have come too far to leave the water now.",type:"catch_any",target:"",count:130,reward:"coins",reward_amt:1,chapter:10,skippable:0}

# q188 — final whisker reuse before the title. catch_aquatic, leviathans_whisker x2.
data modify storage evercraft:fq_registry quests append value {id:188,title:"Drawing It Up",desc:"Land 2 more Leviathan's Whiskers. The apex is all but yours — hold fast and draw it up.",type:"catch_aquatic",target:"leviathans_whisker",count:2,reward:"coins",reward_amt:1,chapter:10,skippable:0}

# q189 — node grind, mythical crate. The last grind before the title spike.
data modify storage evercraft:fq_registry quests append value {id:189,title:"The Final Reach",desc:"Catch 55 fish from splash nodes. One last haul before the Leviathan breaches.",type:"catch_node",target:"mythical",count:55,reward:"crate",reward_amt:1,chapter:10,skippable:0}

# q190 — FIXED: title tier 8 "Leviathan's Bane". catch_any -> title reads reward_amt.
data modify storage evercraft:fq_registry quests append value {id:190,title:"Leviathan's Bane",desc:"Reel in 120 catches in all and claim the title Leviathan's Bane. The apex has met the angler it feared.",type:"catch_any",target:"",count:120,reward:"title",reward_amt:8,chapter:10,skippable:0}

# q191 — the breach: the largest any-catch backbone of the chapter.
data modify storage evercraft:fq_registry quests append value {id:191,title:"The Breach",desc:"Reel in 130 catches in all. The water erupts — the Leviathan rises, and the wake swallows the horizon.",type:"catch_any",target:"",count:130,reward:"coins",reward_amt:1,chapter:10,skippable:0}

# q192 — FIXED CAPSTONE: leviathan_trophy artifact. catch_any leaves target free
#   so target carries the trophy id; reward trophy (reward agent owns the table).
data modify storage evercraft:fq_registry quests append value {id:192,title:"The Leviathan Lands",desc:"Reel in 150 catches and land the Leviathan itself. Claim the Leviathan Trophy — the apex of the wake is yours.",type:"catch_any",target:"leviathan_trophy",count:150,reward:"trophy",reward_amt:1,chapter:10,skippable:0}

# ------------------------------------------------------------
# HAND-OFF TO load_batch_9 (q193..):
#   - This batch ends at id=192. The next batch's FIRST quest MUST be id=193
#     (list index 192) and be appended immediately after q192, contiguously.
#   - registry/load calls batches in order; add the load_batch_8 call to
#     registry/load when this batch lands (main thread owns that wiring).
#
# MILESTONE-MIRROR WIRING THIS BATCH ASSUMES (other agents own these hooks):
#   - ec.fq_rod_tier      : q180 reads rod tier 9 (the apex-tier rod, t10 spirit
#       Tidecaller still ahead at q200). Hook calls questline/check after writing.
#   - ec.fq_sirencall_stage : q185 reads the MAX stage 7. Hook calls questline/check.
#   - leviathans_whisker  : the apex spirit fish (cooking/spirit_fish/grant/
#       leviathans_whisker); the catch hook increments ec.fq_prog gated to the
#       active catch_aquatic quest, then calls questline/check.
#   - leviathan_trophy    : q192 reward-table id (reward agent owns the trophy
#       loot table); catch_any leaves target free to carry it.
# ------------------------------------------------------------
