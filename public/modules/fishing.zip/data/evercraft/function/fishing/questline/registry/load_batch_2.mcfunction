# ============================================================
# The Fisher's Questline — Registry batch 2 (q46..q66)
# ============================================================
# Appends Chapter 4 — "Hoarder of the Deep" — onto storage
# evercraft:fq_registry quests. Called by registry/load AFTER batch_1,
# in id order (id=46 first => list index 45), contiguous, no gaps.
#
# Quest object schema (the engine reads these exact fields):
#   {id:int, title:string, desc:string, type:string, target:string,
#    count:int, reward:string, reward_amt:int, chapter:int}
#
# CH4 theme: the crate backbone; exquisite hauls. The angler turns
# hoarder — crate after crate hauled from the deep, tier climbing from
# rare through ornate to exquisite, capped by the Hoarder's Trophy.
#
# *** SCHEMA CONSTRAINT (the shared `target` field) ***
# Item rewards (crate/gear/trophy) ride ONLY catch_any/catch_crate/
# catch_node, whose condition leaves target free to carry the reward
# tier/id. A quest whose CONDITION uses target (catch_aquatic / event /
# special / milestone) rewards coins or title ONLY. q66's capstone is a
# catch_crate (condition ignores target) so target carries the trophy id.
#
# Crate tiers (catch_crate target / crate rewards): common|uncommon|rare|
# ornate|exquisite|mythical. CH4 escalates rare -> ornate -> exquisite.
# ------------------------------------------------------------

# --- Chapter 4: Hoarder of the Deep -----------------------------------------

# q46 — crate backbone opener (8 rare crates). The hoard begins.
data modify storage evercraft:fq_registry quests append value {id:46,title:"The Hoard Begins",desc:"Fish up 8 crates. A hoarder is only an angler who never threw one back.",type:"catch_crate",target:"rare",count:8,reward:"crate",reward_amt:1,chapter:4,skippable:0}

# q47 — any-catch backbone to feed the grind.
data modify storage evercraft:fq_registry quests append value {id:47,title:"Filling the Hold",desc:"Reel in 80 catches in all. The hold groans with the weight of your haul.",type:"catch_any",target:"",count:80,reward:"coins",reward_amt:1,chapter:4,skippable:0}

# q48 — *** FIXED: total_done milestone, 25 quests cleared. ***
#   milestone uses target for the mirror name -> reward coins.
data modify storage evercraft:fq_registry quests append value {id:48,title:"Quarter of a Hundred",desc:"Complete 25 quests in all. A quarter-hundred trials behind you, and the deep still calls.",type:"milestone",target:"total_done",count:25,reward:"coins",reward_amt:1,chapter:4,skippable:0}

# q49 — splash-node grind (22 nodes), reward an ornate crate.
data modify storage evercraft:fq_registry quests append value {id:49,title:"Where the Crates Gather",desc:"Catch 22 fish from splash nodes. The restless water hides the richest hauls.",type:"catch_node",target:"ornate",count:22,reward:"crate",reward_amt:1,chapter:4,skippable:0}

# q50 — crate backbone (10 rare crates). Coin payout this time.
data modify storage evercraft:fq_registry quests append value {id:50,title:"Ten Locks, Ten Keys",desc:"Fish up 10 crates. Each one a small mystery dredged from the dark.",type:"catch_crate",target:"rare",count:10,reward:"coins",reward_amt:1,chapter:4,skippable:0}

# q51 — crate backbone climbs to ornate (12 crates).
data modify storage evercraft:fq_registry quests append value {id:51,title:"The Ornate Haul",desc:"Fish up 12 ornate crates. The sea grows generous to the truly greedy.",type:"catch_crate",target:"ornate",count:12,reward:"crate",reward_amt:1,chapter:4,skippable:0}

# q52 — splash-node grind (26 nodes). Coin payout.
data modify storage evercraft:fq_registry quests append value {id:52,title:"Ripples and Riches",desc:"Catch 26 fish from splash nodes. Read the water, and it pays in full.",type:"catch_node",target:"ornate",count:26,reward:"coins",reward_amt:1,chapter:4,skippable:0}

# q53 — any-catch backbone.
data modify storage evercraft:fq_registry quests append value {id:53,title:"Never Throw One Back",desc:"Reel in 95 catches in all. A hoarder keeps everything the deep gives up.",type:"catch_any",target:"",count:95,reward:"coins",reward_amt:1,chapter:4,skippable:0}

# q54 — crate backbone (15 ornate crates), reward an exquisite crate.
data modify storage evercraft:fq_registry quests append value {id:54,title:"The Glutton's Cache",desc:"Fish up 15 crates. Your cache spills over — and still you cast again.",type:"catch_crate",target:"ornate",count:15,reward:"crate",reward_amt:1,chapter:4,skippable:0}

# q55 — *** FIXED: title tier 5 (Tidewalker), big any-catch backbone. ***
#   catch_any leaves target free; reward title reads only reward_amt.
data modify storage evercraft:fq_registry quests append value {id:55,title:"Tidewalker",desc:"Reel in 120 catches in all. Claim the title Tidewalker — you walk the tides as if they were yours.",type:"catch_any",target:"",count:120,reward:"title",reward_amt:5,chapter:4,skippable:0}

# q56 — splash-node grind (30 nodes), reward an exquisite crate.
data modify storage evercraft:fq_registry quests append value {id:56,title:"Reader of Riches",desc:"Catch 30 fish from splash nodes. The deep keeps its finest crates for the patient eye.",type:"catch_node",target:"exquisite",count:30,reward:"crate",reward_amt:1,chapter:4,skippable:0}

# q57 — crate backbone (16 exquisite crates). Coin payout.
data modify storage evercraft:fq_registry quests append value {id:57,title:"Exquisite Plunder",desc:"Fish up 16 exquisite crates. Only the briny deep makes treasure this fine.",type:"catch_crate",target:"exquisite",count:16,reward:"coins",reward_amt:1,chapter:4,skippable:0}

# q58 — any-catch backbone.
data modify storage evercraft:fq_registry quests append value {id:58,title:"The Weight of Plenty",desc:"Reel in 110 catches in all. The hold sits low in the water, heavy with your greed.",type:"catch_any",target:"",count:110,reward:"coins",reward_amt:1,chapter:4,skippable:0}

# q59 — crate backbone (18 exquisite crates).
data modify storage evercraft:fq_registry quests append value {id:59,title:"A Hoard Worth Guarding",desc:"Fish up 18 exquisite crates. A hoard like this draws envious eyes from the deep.",type:"catch_crate",target:"exquisite",count:18,reward:"crate",reward_amt:1,chapter:4,skippable:0}

# q60 — *** FIXED: Sirencall-stage milestone, reach stage 3. ***
#   milestone uses target for the mirror -> reward coins.
data modify storage evercraft:fq_registry quests append value {id:60,title:"Deeper Into the Sirencall",desc:"Advance the Sirencall path to its third stage. The deep hums louder with every crate you steal.",type:"milestone",target:"sirencall_stage",count:3,reward:"coins",reward_amt:1,chapter:4,skippable:0}

# q61 — splash-node grind (32 nodes). Coin payout.
data modify storage evercraft:fq_registry quests append value {id:61,title:"The Restless Surface",desc:"Catch 32 fish from splash nodes. The water never stills for the truly greedy.",type:"catch_node",target:"exquisite",count:32,reward:"coins",reward_amt:1,chapter:4,skippable:0}

# q62 — crate backbone (19 exquisite crates).
data modify storage evercraft:fq_registry quests append value {id:62,title:"Buried in Bounty",desc:"Fish up 19 exquisite crates. You wade through treasure and still want more.",type:"catch_crate",target:"exquisite",count:19,reward:"crate",reward_amt:1,chapter:4,skippable:0}

# q63 — any-catch backbone.
data modify storage evercraft:fq_registry quests append value {id:63,title:"More, Always More",desc:"Reel in 125 catches in all. Enough is a word the deep never taught you.",type:"catch_any",target:"",count:125,reward:"coins",reward_amt:1,chapter:4,skippable:0}

# q64 — splash-node grind (34 nodes), reward an exquisite crate.
data modify storage evercraft:fq_registry quests append value {id:64,title:"The Last Ripples Before the Hoard",desc:"Catch 34 fish from splash nodes. The water churns as if it knows what you are building.",type:"catch_node",target:"exquisite",count:34,reward:"crate",reward_amt:1,chapter:4,skippable:0}

# q65 — penultimate crate backbone (20 exquisite crates), the final stretch.
data modify storage evercraft:fq_registry quests append value {id:65,title:"On the Brink of the Hoard",desc:"Fish up 20 exquisite crates. One trophy now stands between you and a legend's hoard.",type:"catch_crate",target:"exquisite",count:20,reward:"crate",reward_amt:1,chapter:4,skippable:0}

# q66 — *** FIXED CAPSTONE: the Hoarder's Trophy (crate_hoard_trophy). ***
#   catch_crate leaves the condition free of target, so target carries the
#   trophy item id; the condition counts 25 crates hauled from the deep.
data modify storage evercraft:fq_registry quests append value {id:66,title:"Hoarder of the Deep",desc:"Fish up 25 crates in all and claim the Hoarder's Trophy. The deep has no hoard you have not plundered.",type:"catch_crate",target:"crate_hoard_trophy",count:25,reward:"trophy",reward_amt:1,chapter:4,skippable:0}

# ------------------------------------------------------------
# HAND-OFF TO load_batch_3 (q67..):
#   - This batch ends at id=66. The next batch's FIRST quest MUST be id=67
#     (list index 66), appended immediately after q66, contiguously.
#   - registry/load calls batches in order; the main thread wires this
#     batch's call. Do NOT renumber this batch.
#
# MILESTONE-MIRROR WIRING THIS BATCH ASSUMES (other agents own these hooks):
#   - q48  total_done   : ec.fq_total_done mirror (>= 25). 25 <= 47 prior
#       quests, so satisfiable.
#   - q60  sirencall_stage : ec.fq_sirencall_stage mirror (>= 3); the
#       Sirencall progression hook calls questline/check after each stage-up.
#   - q66  crate_hoard_trophy : catch_crate condition increments ec.fq_prog
#       per crate (gated to the active quest) then calls questline/check;
#       target carries the trophy id for the reward agent's loot table.
# ------------------------------------------------------------
