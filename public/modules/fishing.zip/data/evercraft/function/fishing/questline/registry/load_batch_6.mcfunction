# ============================================================
# The Fisher's Questline — Registry batch 6 (Chapter 8, q133..q153)
# ============================================================
# Appends quests 133..153 onto storage evercraft:fq_registry quests.
# Called by registry/load AFTER load_batch_5. MUST append in id order
# (id=133 first => list index 132), contiguous, so list-position == ec.fq_quest-1.
#
# Quest object schema (the engine reads these exact fields):
#   {id:int, title:string, desc:string, type:string, target:string,
#    count:int, reward:string, reward_amt:int, chapter:int}
#
# *** SCHEMA CONSTRAINT (the `target` field is SHARED) ***
# A quest whose CONDITION uses target (catch_aquatic fish_type, milestone mirror)
# CANNOT reward crate/gear/trophy — those need target for their own id, so such
# quests reward coins/title only. Item rewards (crate/gear/trophy) ride ONLY
# catch_any / catch_crate / catch_node, whose condition leaves target free.
#
# CHAPTER 8 — Spirits of the Deep. Spirit fish surface from the lightless deep.
# Reverent, eerie deep-spirit flavor. Featured spirit fish: starscale (fixed q140);
# deepcurrent reused in grind-fill. Fixed spine this batch:
#   q135 sirencall_stage 5 (coins 1300) · q140 catch_aquatic starscale 2 (coins 1500)
#   q145 rod_tier 8 (coins 1600) · q150 total_done 100 -> title 7 "Spiritbinder"
#   q153 catch_node spirit_koi_trophy 80 -> trophy (CAPSTONE artifact).
# ------------------------------------------------------------

# --- Chapter 8: Spirits of the Deep ----------------------------------------

# q133 — the deep stirs: spirit-fish hunt (Deepcurrent reuse) opens the chapter.
data modify storage evercraft:fq_registry quests append value {id:133,title:"The Lightless Deep",desc:"Land a Deepcurrent. Something below has begun to notice your line.",type:"catch_aquatic",target:"deepcurrent",count:1,reward:"coins",reward_amt:1,chapter:8,skippable:0}

# q134 — splash-node backbone (45 nodes). catch_node leaves target free -> exquisite crate tier.
data modify storage evercraft:fq_registry quests append value {id:134,title:"Watching the Still Water",desc:"Catch 45 fish from splash nodes. The surface lies quiet over what waits beneath.",type:"catch_node",target:"exquisite",count:45,reward:"crate",reward_amt:1,chapter:8,skippable:0}

# q135 — FIXED: Sirencall-stage milestone gate (reach stage 5). milestone -> coins.
data modify storage evercraft:fq_registry quests append value {id:135,title:"The Sirencall Answers",desc:"Advance the Sirencall path to its fifth stage. The deep speaks plainer now.",type:"milestone",target:"sirencall_stage",count:5,reward:"coins",reward_amt:1,chapter:8,skippable:0}

# q136 — spirit-fish hunt (Deepcurrent x2). catch_aquatic -> coins.
data modify storage evercraft:fq_registry quests append value {id:136,title:"Two from the Dark",desc:"Land 2 Deepcurrents. They rise more freely to a line the deep has marked.",type:"catch_aquatic",target:"deepcurrent",count:2,reward:"coins",reward_amt:1,chapter:8,skippable:0}

# q137 — any-catch backbone. catch_any leaves target free; reward coins.
data modify storage evercraft:fq_registry quests append value {id:137,title:"Vigil at the Edge",desc:"Reel in 120 catches in all. Hold your post where the light gives out.",type:"catch_any",target:"",count:120,reward:"coins",reward_amt:1,chapter:8,skippable:0}

# q138 — splash-node backbone (50 nodes). target free -> exquisite crate tier.
data modify storage evercraft:fq_registry quests append value {id:138,title:"Ripples Without Wind",desc:"Catch 50 fish from splash nodes. The water stirs though no breath moves it.",type:"catch_node",target:"exquisite",count:50,reward:"crate",reward_amt:1,chapter:8,skippable:0}

# q139 — spirit-fish hunt (Deepcurrent x3) — last warm-up before the Starscale.
data modify storage evercraft:fq_registry quests append value {id:139,title:"Drawn Upward",desc:"Land 3 Deepcurrents. Each one rises slower, heavier, more reluctant to leave the dark.",type:"catch_aquatic",target:"deepcurrent",count:3,reward:"coins",reward_amt:1,chapter:8,skippable:0}

# q140 — FIXED: Starscale spirit-fish hunt (x2). catch_aquatic -> coins.
data modify storage evercraft:fq_registry quests append value {id:140,title:"Light from the Abyss",desc:"Catch 2 Starscale — spirit fish that carry the last gleam of stars down into the lightless deep.",type:"catch_aquatic",target:"starscale",count:2,reward:"coins",reward_amt:1,chapter:8,skippable:0}

# q141 — any-catch backbone. catch_any -> coins.
data modify storage evercraft:fq_registry quests append value {id:141,title:"The Long Watch",desc:"Reel in 140 catches in all. The deep keeps its own count, and so must you.",type:"catch_any",target:"",count:140,reward:"coins",reward_amt:1,chapter:8,skippable:0}

# q142 — splash-node backbone (55 nodes). target free -> exquisite crate tier.
data modify storage evercraft:fq_registry quests append value {id:142,title:"Where the Pale Things Gather",desc:"Catch 55 fish from splash nodes. Where the water pales, the deep has surfaced to meet you.",type:"catch_node",target:"exquisite",count:55,reward:"crate",reward_amt:1,chapter:8,skippable:0}

# q143 — Starscale reuse hunt (x1). catch_aquatic -> coins.
data modify storage evercraft:fq_registry quests append value {id:143,title:"A Second Gleam",desc:"Land another Starscale. Its glow does not warm the hand that holds it.",type:"catch_aquatic",target:"starscale",count:1,reward:"coins",reward_amt:1,chapter:8,skippable:0}

# q144 — splash-node backbone (60 nodes). target free -> exquisite crate tier.
data modify storage evercraft:fq_registry quests append value {id:144,title:"Reader of the Pale Deep",desc:"Catch 60 fish from splash nodes. You read the still water as others read a face.",type:"catch_node",target:"exquisite",count:60,reward:"crate",reward_amt:1,chapter:8,skippable:0}

# q145 — FIXED: rod-ladder milestone (rod tier 8). milestone -> coins.
data modify storage evercraft:fq_registry quests append value {id:145,title:"A Rod for the Deep",desc:"Advance your fishing rod to tier 8 through the fishing trials. The deep tests sterner gear.",type:"milestone",target:"rod_tier",count:8,reward:"coins",reward_amt:1,chapter:8,skippable:0}

# q146 — Deepcurrent reuse hunt (x2). catch_aquatic -> coins.
data modify storage evercraft:fq_registry quests append value {id:146,title:"Old Names in the Water",desc:"Land 2 Deepcurrents. The first spirits you ever raised still answer your line.",type:"catch_aquatic",target:"deepcurrent",count:2,reward:"coins",reward_amt:1,chapter:8,skippable:0}

# q147 — any-catch backbone. catch_any -> coins.
data modify storage evercraft:fq_registry quests append value {id:147,title:"Tireless at the Brink",desc:"Reel in 160 catches in all. The lightless deep gives nothing to the impatient.",type:"catch_any",target:"",count:160,reward:"coins",reward_amt:1,chapter:8,skippable:0}

# q148 — splash-node backbone (65 nodes). target free -> exquisite crate tier.
data modify storage evercraft:fq_registry quests append value {id:148,title:"The Surface Breaks",desc:"Catch 65 fish from splash nodes. The deep rises to your call now, and breaks the still water itself.",type:"catch_node",target:"exquisite",count:65,reward:"crate",reward_amt:1,chapter:8,skippable:0}

# q149 — Starscale reuse hunt (x2). catch_aquatic -> coins.
data modify storage evercraft:fq_registry quests append value {id:149,title:"A Constellation Drowned",desc:"Catch 2 more Starscale. Cup them in your hands and the lost stars look back.",type:"catch_aquatic",target:"starscale",count:2,reward:"coins",reward_amt:1,chapter:8,skippable:0}

# q150 — FIXED: total_done milestone (100 cleared) -> title tier 7 "Spiritbinder".
#   milestone uses target for the mirror; reward title reads only reward_amt.
data modify storage evercraft:fq_registry quests append value {id:150,title:"Spiritbinder",desc:"Complete 100 quests in all. The spirits of the deep heed your line — claim the title of Spiritbinder.",type:"milestone",target:"total_done",count:100,reward:"title",reward_amt:7,chapter:8,skippable:0}

# q151 — any-catch backbone, building toward the capstone. catch_any -> coins.
data modify storage evercraft:fq_registry quests append value {id:151,title:"Bound to the Deep",desc:"Reel in 130 catches in all. What you have bound now answers before you ask.",type:"catch_any",target:"",count:130,reward:"coins",reward_amt:1,chapter:8,skippable:0}

# q152 — splash-node backbone, the run-up to q153. target free -> exquisite crate tier.
data modify storage evercraft:fq_registry quests append value {id:152,title:"The Pale Koi Circles",desc:"Catch 45 fish from splash nodes. A pale shape circles below, patient, waiting to be drawn up.",type:"catch_node",target:"exquisite",count:45,reward:"crate",reward_amt:1,chapter:8,skippable:0}

# q153 — FIXED CAPSTONE: splash-node grind raises the Spirit Koi trophy.
#   catch_node leaves target free -> target carries the TROPHY-reward item id.
data modify storage evercraft:fq_registry quests append value {id:153,title:"The Spirit Koi Ascends",desc:"Catch 55 fish from splash nodes to coax the Spirit Koi from the lightless deep. It rises pale and silent, and is yours.",type:"catch_node",target:"spirit_koi_trophy",count:55,reward:"trophy",reward_amt:1,chapter:8,skippable:0}

# ------------------------------------------------------------
# HAND-OFF TO load_batch_7 (q154..):
#   - This batch ends at id=153. The next batch's FIRST quest MUST be id=154
#     (list index 153) and be appended immediately after q153, contiguously.
#   - registry/load calls load_batch_5 then this batch; the next agent adds the
#     load_batch_7 call. Do NOT renumber this batch.
#
# MILESTONE-MIRROR WIRING THIS BATCH ASSUMES (other agents own these hooks):
#   - ec.fq_sirencall_stage (q135 -> stage 5) and ec.fq_rod_tier (q145 -> tier 8):
#       written by the Sirencall / craftforever fishing-trial progression hooks,
#       which call questline/check after each mirror write.
#   - q150 total_done 100: the questline core mirrors completed-quest count and
#       calls check on each finish; reward title 7 is owned by the reward agent.
#   - q153 catch_node -> spirit_koi_trophy: the trophy loot/reward id is owned by
#       the reward agent; the catch/node hook increments ec.fq_prog then calls check.
# ------------------------------------------------------------
