# ============================================================
# The Fisher's Questline — Registry batch 3 (q67..q89)
# ============================================================
# Appends quests 67..89 onto storage evercraft:fq_registry quests.
# Called by registry/load AFTER batch_2 (so q66 precedes q67). MUST append
# in id order (id=67 first => list index 66), contiguous, no gaps.
#
# Quest object schema (the engine reads these exact fields):
#   {id:int, title:string, desc:string, type:string, target:string,
#    count:int, reward:string, reward_amt:int, chapter:int}
#
# CHAPTER 5 — "Every Scale Counts": the angler's collection. This is the
# "one of each" chapter — every overworld aquatic species gets its hunt:
# reedfin_dace + brackish_perch debut here, and silverscale/glimmer/emberfin/
# frostfin/coppergill/mistpike all return for the full set. catch_node and
# catch_any backbones carry the crate/coin rewards between the species hunts.
#
# *** SCHEMA CONSTRAINT (the shared `target` field) ***
# catch_aquatic uses target for the fish_type and milestone uses it for the
# mirror name, so those quests reward ONLY coins/title. Item rewards
# (crate/gear) ride catch_any/catch_node, whose condition leaves target free
# to carry the crate tier / gear id. q89 capstone = catch_node + target
# current_charm + reward gear is the legal item-reward pattern.
# ------------------------------------------------------------

# --- Chapter 5: Every Scale Counts -----------------------------------------

# q67 — reedfin debut: the marsh-dweller of the reed beds.
data modify storage evercraft:fq_registry quests append value {id:67,title:"Among the Reeds",desc:"Catch 2 Reedfin Dace from the shallow reed beds. Where the water thins, the patient angler thrives.",type:"catch_aquatic",target:"reedfin_dace",count:2,reward:"coins",reward_amt:1,chapter:5,skippable:0}

# q68 — brackish debut: the fish of mingled salt and stream.
data modify storage evercraft:fq_registry quests append value {id:68,title:"Where Salt Meets Stream",desc:"Catch 2 Brackish Perch where river runs to sea. They favor the briny in-between.",type:"catch_aquatic",target:"brackish_perch",count:2,reward:"coins",reward_amt:1,chapter:5,skippable:0}

# q69 — node backbone (25). catch_node leaves target free -> crate tier rare.
data modify storage evercraft:fq_registry quests append value {id:69,title:"Reading the Restless Water",desc:"Catch 25 fish from splash nodes. The collection grows one ripple at a time.",type:"catch_node",target:"rare",count:25,reward:"crate",reward_amt:1,chapter:5,skippable:0}

# q70 — silverscale returns: the starter aquatic, now a routine of the roster.
data modify storage evercraft:fq_registry quests append value {id:70,title:"Silver in the Net",desc:"Catch 3 Silverscale Minnow again. Even the humblest fish belongs in the angler's tally.",type:"catch_aquatic",target:"silverscale_minnow",count:3,reward:"coins",reward_amt:1,chapter:5,skippable:0}

# q71 — any-catch backbone between species hunts.
data modify storage evercraft:fq_registry quests append value {id:71,title:"Steady Hands",desc:"Reel in 80 catches of any kind. The collection rewards the relentless.",type:"catch_any",target:"",count:80,reward:"coins",reward_amt:1,chapter:5,skippable:0}

# q72 — *** FIXED: rod-ladder milestone, rod tier 6 ***
#   milestone uses target for the mirror -> reward coins (not gear).
data modify storage evercraft:fq_registry quests append value {id:72,title:"A Finer Rod",desc:"Advance your fishing rod to tier 6 through the fishing trials. A fuller roster demands a finer line.",type:"milestone",target:"rod_tier",count:6,reward:"coins",reward_amt:1,chapter:5,skippable:0}

# q73 — glimmer returns: the shimmering reagent fish.
data modify storage evercraft:fq_registry quests append value {id:73,title:"Shimmer in the Shallows",desc:"Catch 3 Glimmer Trout for the collection. Their light never dims, and neither does the hunt.",type:"catch_aquatic",target:"glimmer_trout",count:3,reward:"coins",reward_amt:1,chapter:5,skippable:0}

# q74 — node backbone (30). catch_node target free -> crate tier rare.
data modify storage evercraft:fq_registry quests append value {id:74,title:"Watcher of Ripples",desc:"Catch 30 fish from splash nodes. Each node yields a stranger catch than the last.",type:"catch_node",target:"rare",count:30,reward:"crate",reward_amt:1,chapter:5,skippable:0}

# q75 — emberfin returns: the warm-current snapper.
data modify storage evercraft:fq_registry quests append value {id:75,title:"Embers in the Current",desc:"Catch 3 Emberfin Snapper. They run hot where the deeper water turns warm.",type:"catch_aquatic",target:"emberfin_snapper",count:3,reward:"coins",reward_amt:1,chapter:5,skippable:0}

# q76 — frostfin returns: the cold-water char.
data modify storage evercraft:fq_registry quests append value {id:76,title:"Cold Catch",desc:"Catch 3 Frostfin Char from chilled waters. The roster spans every temper of the deep.",type:"catch_aquatic",target:"frostfin_char",count:3,reward:"coins",reward_amt:1,chapter:5,skippable:0}

# q77 — any-catch backbone, climbing.
data modify storage evercraft:fq_registry quests append value {id:77,title:"The Long Tally",desc:"Reel in 100 catches of any kind. A true collector counts every line drawn back.",type:"catch_any",target:"",count:100,reward:"coins",reward_amt:1,chapter:5,skippable:0}

# q78 — coppergill returns: the metallic-scaled bass.
data modify storage evercraft:fq_registry quests append value {id:78,title:"Bright Coppergill",desc:"Catch 3 Coppergill Bass. Their burnished scales mark a prize worth the wait.",type:"catch_aquatic",target:"coppergill_bass",count:3,reward:"coins",reward_amt:1,chapter:5,skippable:0}

# q79 — node backbone (35). catch_node target free -> crate tier ornate.
data modify storage evercraft:fq_registry quests append value {id:79,title:"Keeper of the Nodes",desc:"Catch 35 fish from splash nodes. The water hides fewer secrets from you now.",type:"catch_node",target:"ornate",count:35,reward:"crate",reward_amt:1,chapter:5,skippable:0}

# q80 — mistpike returns: the fog-water predator.
data modify storage evercraft:fq_registry quests append value {id:80,title:"Out of the Mist",desc:"Catch 3 Mistpike where the fog lies thick on the water. They strike from the grey unseen.",type:"catch_aquatic",target:"mistpike",count:3,reward:"coins",reward_amt:1,chapter:5,skippable:0}

# q81 — reedfin again: a heavier haul of the marsh fish.
data modify storage evercraft:fq_registry quests append value {id:81,title:"The Reedbed Haul",desc:"Catch 3 more Reedfin Dace. The reeds give freely to the angler who returns.",type:"catch_aquatic",target:"reedfin_dace",count:3,reward:"coins",reward_amt:1,chapter:5,skippable:0}

# q82 — any-catch backbone, climbing.
data modify storage evercraft:fq_registry quests append value {id:82,title:"Tireless on the Tide",desc:"Reel in 120 catches of any kind. The collection is never quite complete.",type:"catch_any",target:"",count:120,reward:"coins",reward_amt:1,chapter:5,skippable:0}

# q83 — brackish again: a heavier haul of the estuary fish.
data modify storage evercraft:fq_registry quests append value {id:83,title:"The Briny In-Between",desc:"Catch 3 more Brackish Perch from the mingling waters. The estuary keeps its own kind.",type:"catch_aquatic",target:"brackish_perch",count:3,reward:"coins",reward_amt:1,chapter:5,skippable:0}

# q84 — node backbone (40). catch_node target free -> crate tier ornate.
data modify storage evercraft:fq_registry quests append value {id:84,title:"Master of the Stirring Water",desc:"Catch 40 fish from splash nodes. Few read the restless surface as you do.",type:"catch_node",target:"ornate",count:40,reward:"crate",reward_amt:1,chapter:5,skippable:0}

# q85 — silverscale heavier haul, rounding the roster.
data modify storage evercraft:fq_registry quests append value {id:85,title:"A Drift of Silver",desc:"Catch 4 Silverscale Minnow in one sweep. A full net of the familiar is its own reward.",type:"catch_aquatic",target:"silverscale_minnow",count:4,reward:"coins",reward_amt:1,chapter:5,skippable:0}

# q86 — any-catch backbone, the chapter's biggest tally.
data modify storage evercraft:fq_registry quests append value {id:86,title:"Every Scale Counted",desc:"Reel in 140 catches of any kind. No fish is too small for the great collection.",type:"catch_any",target:"",count:140,reward:"coins",reward_amt:1,chapter:5,skippable:0}

# q87 — coppergill heavier haul, the species roster nearly closed.
data modify storage evercraft:fq_registry quests append value {id:87,title:"A Run of Copper",desc:"Catch 4 Coppergill Bass. The roster shines brighter with every burnished catch.",type:"catch_aquatic",target:"coppergill_bass",count:4,reward:"coins",reward_amt:1,chapter:5,skippable:0}

# q88 — node backbone (45). catch_node target free -> crate tier ornate.
data modify storage evercraft:fq_registry quests append value {id:88,title:"The Full Survey",desc:"Catch 45 fish from splash nodes. The deep has shown you nearly all it holds.",type:"catch_node",target:"ornate",count:45,reward:"crate",reward_amt:1,chapter:5,skippable:0}

# q89 — *** CAPSTONE: the Current Charm (catch_node gear). ***
#   catch_node leaves target free -> target carries the GEAR-reward item id.
#   Earned by landing a charm-bearing catch from the node 50 times; the
#   reward agent owns the current_charm gear loot table.
data modify storage evercraft:fq_registry quests append value {id:89,title:"The Current Charm",desc:"Draw 50 catches from the stirring deep until the tidal currents themselves yield a charm. Every scale counted, the deep rewards the complete angler.",type:"catch_node",target:"current_charm",count:50,reward:"gear",reward_amt:1,chapter:5,skippable:0}

# ------------------------------------------------------------
# HAND-OFF TO load_batch_4 (q90..):
#   - This batch ends at id=89. The next batch's FIRST quest MUST be id=90
#     (list index 89), appended immediately after q89, contiguously.
#   - registry/load calls this batch after load_batch_2; the main thread wires
#     the load_batch_3 call into registry/load. Do NOT renumber this batch.
#
# MILESTONE-MIRROR WIRING THIS BATCH ASSUMES (other agents own these hooks):
#   - ec.fq_rod_tier : written by the fishing-trial progression hook; q72 reads
#       tier 6. That hook MUST call evercraft:fishing/questline/check after
#       writing the mirror.
#   - current_charm (q89 capstone gear): the reward agent owns the gear loot
#       table id "current_charm"; the catch_node hook increments ec.fq_prog
#       (gated to the active quest) then calls questline/check.
# ------------------------------------------------------------
