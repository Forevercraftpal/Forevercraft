# Master-Angler title tier 3 — "Tidereader". @s = player.
title @s times 8 50 12
title @s title [{text:"✦ ",color:"aqua"},{text:"Tidereader",color:"aqua"},{text:" ✦",color:"aqua"}]
title @s subtitle {text:"Master-Angler title earned",color:"dark_gray",italic:true}
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"aqua"},{text:"Master-Angler title earned: ",color:"white"},{text:"Tidereader",color:"aqua",bold:true},{text:" ✦",color:"aqua"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 0.7 1.1
