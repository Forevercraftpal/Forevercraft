# FQ check helper — special (bespoke set-piece, e.g. fireproof_warden).
# Handled like event: the bespoke fn sets ec.fq_prog before calling check, so the
# engine compares ec.fq_prog >= quest.count.
scoreboard players set #fq_satisfied ec.temp 0
execute if score @s ec.fq_prog >= #fq_count ec.temp run scoreboard players set #fq_satisfied ec.temp 1
