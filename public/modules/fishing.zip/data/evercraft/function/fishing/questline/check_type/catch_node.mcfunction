# FQ check helper — catch_node (a splash-node catch). Progress quest.
# splash_nodes/do_catch increments ec.fq_prog for this quest when a node is
# caught; the engine just compares ec.fq_prog >= quest.count.
scoreboard players set #fq_satisfied ec.temp 0
execute if score @s ec.fq_prog >= #fq_count ec.temp run scoreboard players set #fq_satisfied ec.temp 1
