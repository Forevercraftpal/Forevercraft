# ============================================================
# The Fisher's Questline — Completion Capstone (ADDITIVE, Joseph 2026-06-01)
# ============================================================
# Run as @s = the player who just finished the WHOLE Fisher's Questline. Called
# from finish.mcfunction INSIDE the one-shot ec.fq_complete guard, so it fires
# exactly once per player. ADDITIVE: this is ON TOP of the existing completion
# fanfare + every per-quest reward; it removes/reduces nothing.
#
# Drives PRESTIGE on the FISHING tree (id 9, prestige counter adv.pres_fish)
# through the engine's existing advantage/prestige/do_prestige path, difficulty-
# scaled by ec.difficulty (XP-REWARD-ECONOMY.md "Completion capstone", revised down
# Council review 2026-06-01 — the 3-prestige Newcomer payload was too generous):
#   1 Newcomer        -> 2 prestiges           (target 2 — the ONLY multi-prestige tier)
#   2 Adventurer      -> 1 prestige            (target 1)
#   3 Pioneer / unset -> 1 prestige            (target 1 = floor; Adventurer & Pioneer match)
# Since adv.req_xp (vanilla-XP per-level cost) is NOT difficulty-scaled, it is the
# CAPSTONE GRANT (prestige COUNT) that varies by mode, never the per-level cost.
#
# do_prestige reads only #pres_tree + #pres_current (no internal XP spend / req
# gate); it resets adv.fishing to 1, +1 adv.pres_fish (+ adv.pres_total), applies
# retained bonus, unlocks the prestige ability (fishing_p1/p2/p3), awards 100
# tokens + fanfare. check_eligible (the normal GUI path) requires level 25 and
# blocks at prestige >= 3 — we BYPASS check_eligible (calling do_prestige direct),
# so we enforce BOTH invariants here: set adv.fishing to 25 before each call
# (the level do_prestige assumes was legitimately reached) and never drive a step
# when adv.pres_fish is already >= 3 (respect the hard 3-prestige cap).

# --- Target prestige count from difficulty (Newcomer = 2, Adventurer/Pioneer/unset = 1) ---
scoreboard players set #fq_pres_target adv.temp 1
execute if score @s ec.difficulty matches 1 run scoreboard players set #fq_pres_target adv.temp 2

# --- BANK the earned prestige on the FISHING tree (id 9) instead of auto-applying it
#     (Joseph 2026-06-02: don't force-reset the tree on completion — the player CLAIMS it from the
#     [Claim ▸] chat button when ready). Clamp so current prestige + banked never exceeds 3. ---
scoreboard players operation @s adv.pbank_fish += #fq_pres_target adv.temp
scoreboard players set #pcap adv.temp 3
scoreboard players operation #pcap adv.temp -= @s adv.pres_fish
execute if score #pcap adv.temp matches ..0 run scoreboard players set @s adv.pbank_fish 0
execute if score @s adv.pbank_fish > #pcap adv.temp run scoreboard players operation @s adv.pbank_fish = #pcap adv.temp

# --- Capstone banner + claim offer (additive, on top of finish.mcfunction's own fanfare) ---
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"Angler's Mastery awakens — you've EARNED a Fishing prestige! Claim it when you're ready.",color:"light_purple",italic:true},{text:" ✦",color:"gold"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
function evercraft:advantage/prestige/show_claim_offers

# === ADDITIVE: 150+-quest questline capstone — Salvation Stone + Wishing Star (Joseph 2026-06-02) ===
# The Fisher's Questline is 250 quests. Per Joseph, completing ANY 150+-quest questline grants a
# Salvation Stone (a death-save charge — consumed on death in Pioneer) + one Wishing Star (choose
# ANY artifact in the pack). One-shot: this fn's ONLY caller is finish.mcfunction, inside its
# ec.fq_complete guard. give/loot give auto-drop at the player's feet if the inventory is full,
# so neither reward can be lost.
tellraw @s [{"text":""}]
tellraw @s [{"text":"  ✦ ","color":"gold"},{"text":"A Master Angler's Reward","color":"light_purple","bold":true},{"text":" ✦","color":"gold"}]
# Inv-full guard: drop at the player's feet rather than void on a full inventory.
execute store result score #inv_full ec.var run function evercraft:util/check_inv_full
execute if score #inv_full ec.var matches 0 run loot give @s loot evercraft:items/salvation_stone
execute if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:items/salvation_stone
tellraw @s [{"text":"  ✦ ","color":"gold"},{"text":"Salvation Stone","color":"gold","bold":true},{"text":" — it will shield you from one death.","color":"yellow"}]
give @s minecraft:nether_star[custom_name={"text":"Dreamy Star","color":"gold","italic":false},custom_data={wishing_star:true},lore=[{"text":"Mythical Item","color":"gold","italic":false},"",{"text":"A star that fell not from the sky, but from","color":"gray","italic":true},{"text":"the Fountain's deepest, most desperate wish.","color":"gray","italic":true},"",{"text":"Right-click to use:","color":"white","italic":false},{"text":"Choose ANY artifact from the entire pack","color":"aqua","italic":false},"",{"text":"\"The rarest gift is the power to choose.\"","color":"dark_gray","italic":true}],enchantment_glint_override=true,consumable={consume_seconds:0,sound:"intentionally_empty",has_consume_particles:false}] 1
tellraw @s [{"text":"  ✦ ","color":"gold"},{"text":"Wishing Star","color":"gold","bold":true},{"text":" — right-click to choose ANY artifact in the pack.","color":"aqua"}]
tellraw @s [{"text":"  (If your inventory was full, your rewards are at your feet.)","color":"dark_gray","italic":true}]
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.ender_dragon.growl master @s ~ ~ ~ 0.3 1.5
