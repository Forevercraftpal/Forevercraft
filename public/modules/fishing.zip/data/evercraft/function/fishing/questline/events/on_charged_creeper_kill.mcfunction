# ============================================================
# The Fisher's Questline — Stormcharge kill reward (set-piece cleared)
# ============================================================
# Fired by advancement evercraft:fishing/questline/events/charged_creeper_kill
# (minecraft:player_killed_entity on a ec.fq_charged_creeper-tagged creeper).
# Run as @s = the killing player.
#
# Sets the lifetime "ever beat the Stormcharge" flag (read by any event/special
# quest whose target is "charged_creeper"), then — ONLY if the active quest is
# that set-piece — bumps ec.fq_prog and re-checks the questline.

# Re-arm the advancement so a future quest can require this set-piece again.
advancement revoke @s only evercraft:fishing/questline/events/charged_creeper_kill

# Lifetime sentinel: "this player has beaten the Stormcharge at least once".
# (Read-only convenience flag for PoC quests / codex; not the progress counter.)
scoreboard players set @s ec.fq_evt_charged 1

# --- Existence gate the questline feed (cheap no-op if line inactive/done). ---
execute unless score @s ec.fq_active matches 1 run return 0
execute if score @s ec.fq_complete matches 1 run return 0

# --- Load the current quest, type-gate, and credit it. ---
# Only event/special quests whose target is "charged_creeper" should count.
# ACCEPTED EDGE (FP-RACE1, council 2026-05-31): this fires off the binary
# player_killed_entity advancement, which grants at most once per tick. For the
# count>1 charged_creeper quests (q107 "Twin Bolt", q241), two tagged creepers
# killed in the SAME tick credit +1, not +2 — a recoverable under-credit (kill one
# more), never an over-credit, never the wrong quest. Two charged creepers alive
# AND killed in one 1/20s tick is essentially impossible in normal play (they spawn
# 1/60 per storm-node catch and are fought seconds apart), so this is accepted as-is
# rather than buffered. Make these quests count:1 if it ever proves observable.
function evercraft:fishing/questline/get_quest
execute if data storage evercraft:fq_cur quest{type:"event",target:"charged_creeper"} run scoreboard players add @s ec.fq_prog 1
execute if data storage evercraft:fq_cur quest{type:"special",target:"charged_creeper"} run scoreboard players add @s ec.fq_prog 1

# Re-evaluate (check re-loads get_quest itself; advances if satisfied).
function evercraft:fishing/questline/check
