# ============================================================
# The Fisher's Questline — Master-Angler title grant (macro by tier)
# ============================================================
# Run as @s = the player. Grants a Master-Angler title TIER.
#
# This is the REWARD-AGENT-owned, NAMED version of a title grant. The engine's
# reward_type/title already bumps ec.fq_title + a generic tellraw; this helper is
# the richer alternative a registry quest (or the engine, if rerouted) may call to
# award a SPECIFIC named tier with its themed celebration.
#
# CALL CONVENTION — macro. Pass the tier via storage:
#   data modify storage evercraft:fq_cur title_tier set value <N>   # 1..6
#   function evercraft:fishing/questline/rewards/grant_title with storage evercraft:fq_cur
# OR call grant_title_macro directly with `{tier:N}`.
#
# ONE-WRITER NOTE: ec.fq_title is written ONLY in the questline reward chain
# (engine reward_type/title + this helper). This helper writes it via the SAME
# only-if-higher rule, so it never downgrades and never conflicts with the engine.
$function evercraft:fishing/questline/rewards/grant_title_macro {tier:$(title_tier)}
