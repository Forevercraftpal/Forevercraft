# ============================================================
# The Fisher's Questline — drain the credit reservoir into whole Fishing levels (bounded loop)
# ============================================================
# Run as @s = the player, called from fishing/questline/tree_credit after the per-quest credit
# is added to adv.fq_credit. Realizes as many whole Fishing levels as the reservoir can afford
# THIS quest, then stops. Each pass:
#   * grant_credit_level returns 1 if it realized a level (and spent its req_stat from the
#     reservoir), 0 if it could not (cap 25 reached, or reservoir < this level's req_stat).
#   * We recurse ONLY while a level was realized AND a hard step-budget remains — so the loop
#     terminates on the FIRST no-progress pass (reservoir short) or the cap, and can never spin.
#
# Bound: #fq_drain_steps adv.temp counts DOWN from 25 (the tree's max level span) — a hard
# ceiling so even a corrupted/huge reservoir realizes at most 25 levels in one tick (one full
# climb). At the Pioneer baseline (+1000/quest) the realistic per-quest realize is <=3.
#
# adv.fishing is the PERMANENT, sync-immune bank (the 5s stat sync never touches it), so every
# level realized here survives the adv.stat_fish = (fish_ct - base_fish) clobber. This is the
# load-bearing A1 fix.

# Decrement the remaining step budget; stop if exhausted (defensive ceiling).
scoreboard players remove #fq_drain_steps adv.temp 1
execute if score #fq_drain_steps adv.temp matches ..0 run return 0

# Try to realize one level. store the helper's return (1 = realized, 0 = nothing) into a flag.
execute store result score #fq_drain_did adv.temp run function evercraft:fishing/questline/grant_credit_level

# Recurse only if a level was actually realized this pass (else the reservoir is short / capped).
execute if score #fq_drain_did adv.temp matches 1 run function evercraft:fishing/questline/drain_credit
