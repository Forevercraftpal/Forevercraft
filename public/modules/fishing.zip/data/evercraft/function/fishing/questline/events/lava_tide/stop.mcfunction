# ============================================================
# The Fisher's Questline — LAVA TIDE: STOP
# ============================================================
# Called when the timer expires (active_tick) or manually. Clears global state,
# stamps the cooldown, despawns any lingering tide mobs, announces the end.

# --- Clear global state. ---
scoreboard players set #fq_lava_tide ec.var 0
scoreboard players set #fq_lt_timer ec.var 0
scoreboard players set #fq_lt_wave ec.var 0

# --- Stamp cooldown: now + 30 in-game hours (2,160,000 ticks). ---
execute store result score #fq_lt_cd ec.var run time query gametime
scoreboard players add #fq_lt_cd ec.var 2160000

# --- Despawn any tide mobs the player never finished off (keep the world clean). ---
# Both the wave mobs and the apex Warden carry ec.fq_lava_mob.
kill @e[tag=ec.fq_lava_mob]

# --- Announce. ---
data modify storage evercraft:notify stage.c set value [{text:"The lava settles... the tide recedes.",color:"gold",italic:true}]
scoreboard players set #ndur ec.temp 45
execute as @a[predicate=evercraft:in_nether] run function evercraft:util/notify/emit
execute as @a[predicate=evercraft:in_nether] if score @s ec.fx_snd matches 1.. at @s run playsound minecraft:block.lava.extinguish master @s ~ ~ ~ 0.8 0.8
title @a[predicate=evercraft:in_nether] times 10 40 20
title @a[predicate=evercraft:in_nether] title {text:" "}
title @a[predicate=evercraft:in_nether] subtitle {text:"Lava Tide Ended",color:"gold"}

# Note: the cadence loop re-schedules itself at 60s from lava_tide/tick once it
# sees #fq_lava_tide==0, so no schedule call is needed here.
