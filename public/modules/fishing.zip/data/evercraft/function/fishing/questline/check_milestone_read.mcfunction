# ============================================================
# The Fisher's Questline — Milestone score reader (macro body)
# ============================================================
# Called `with storage evercraft:fq_cur o`. Loads the milestone mirror score
# selected by quest.target into #fq_ms_val ec.temp for check_type/milestone.
#
# Valid milestone targets and the engine-owned mirror they map to:
#   "sirencall_stage" -> ec.fq_sirencall_stage  (Sirencall system hook writes it)
#   "rod_tier"        -> ec.fq_rod_tier         (rod-tier system hook writes it)
#   "total_done"      -> ec.fq_done             (the lifetime completed counter)
#
# `total_done` is special-cased to ec.fq_done (no separate mirror objective);
# the other two resolve by macro string as ec.fq_<target>. Default 0 so a
# non-milestone quest.target (e.g. a fish_type) leaves the temp at 0 — the
# catch_* helpers ignore it, so this is purely defensive.
scoreboard players set #fq_ms_val ec.temp 0

# total_done reuses the lifetime counter.
execute if data storage evercraft:fq_cur {o:{target:"total_done"}} store result score #fq_ms_val ec.temp run scoreboard players get @s ec.fq_done

# sirencall_stage reads the LIVE craft-affinity Sirencall stage (ec.caffs_sc) directly,
# so no separate mirror writer is needed — the stage IS the source of truth.
execute if data storage evercraft:fq_cur {o:{target:"sirencall_stage"}} store result score #fq_ms_val ec.temp run scoreboard players get @s ec.caffs_sc

# All OTHER milestone targets (rod_tier) resolve to the ec.fq_<target> mirror by macro.
# (rod_tier is written by the fishing-trial reward [tiers 1-9] + the Tidecaller-held
# detect in on_catch_hook [tier 10].) total_done + sirencall_stage are handled above.
$execute unless data storage evercraft:fq_cur {o:{target:"total_done"}} unless data storage evercraft:fq_cur {o:{target:"sirencall_stage"}} store result score #fq_ms_val ec.temp run scoreboard players get @s ec.fq_$(target)
