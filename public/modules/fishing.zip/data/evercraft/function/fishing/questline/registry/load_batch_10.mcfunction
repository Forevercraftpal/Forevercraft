# ============================================================
# The Fisher's Questline — Registry batch 10 (q201..q220)
# ============================================================
# Appends quests 201..220 onto storage evercraft:fq_registry quests.
# Called by registry/load AFTER load_batch_9. MUST append in id order
# (id=201 first => list index 200), contiguous, so list-position == ec.fq_quest-1.
#
# Quest object schema (the engine reads these exact fields):
#   {id:int, title:string, desc:string, type:string, target:string,
#    count:int, reward:string, reward_amt:int, chapter:int}
#
# *** SCHEMA CONSTRAINT (the `target` field is SHARED) ***
# A quest whose CONDITION already uses target (catch_aquatic/event/special/
# milestone/catch_weather) CANNOT reward crate/gear/trophy — those reward coins
# or title only. Item rewards (crate/gear/trophy) ride ONLY catch_any /
# catch_crate / catch_node, whose condition leaves target free for the tier/id.
#
# CHAPTER 12 — Beyond the Tidecaller (ACT II opens). The spirit Tidecaller is
# yours; the void runs deeper. Mastery-tier counts, mythical crates, the first
# voidfin, and the tideworn_lure capstone. Triumphant, terse, second person.
# Fixed (per manifest): q210 catch_aquatic voidfin count 1 coins 3200;
# q220 catch_node tideworn_lure count 100 gear 1 (CAPSTONE).
# ------------------------------------------------------------

# --- Chapter 12: Beyond the Tidecaller -------------------------------------

# q201 — Act II on-ramp: mastery any-catch backbone. The sea is yours now.
data modify storage evercraft:fq_registry quests append value {id:201,title:"The Sea Is Yours",desc:"Reel in 140 catches with the spirit rod in hand. The water knows its master now.",type:"catch_any",target:"",count:140,reward:"coins",reward_amt:1,chapter:12,skippable:0}

# q202 — mythical crate backbone (catch_crate leaves target free -> crate TIER).
data modify storage evercraft:fq_registry quests append value {id:202,title:"Spoils of Mastery",desc:"Fish up 17 mythical crates. The depths surrender their finest to you.",type:"catch_crate",target:"mythical",count:17,reward:"crate",reward_amt:1,chapter:12,skippable:0}

# q203 — splash-node grind (catch_node leaves target free -> crate TIER).
data modify storage evercraft:fq_registry quests append value {id:203,title:"Where the Void Stirs",desc:"Catch 60 fish from splash nodes. Read the water; something darker reads back.",type:"catch_node",target:"mythical",count:60,reward:"crate",reward_amt:1,chapter:12,skippable:0}

# q204 — any-catch backbone climb.
data modify storage evercraft:fq_registry quests append value {id:204,title:"Past the Last Tide",desc:"Reel in 150 catches in all. Beyond the Tidecaller, the line still pulls.",type:"catch_any",target:"",count:150,reward:"coins",reward_amt:1,chapter:12,skippable:0}

# q205 — overworld night cast (catch_weather:night, overworld only -> coins).
data modify storage evercraft:fq_registry quests append value {id:205,title:"A Calmer Shore",desc:"Reel in 5 catches under a clear night sky. Return to still water before the deep calls.",type:"catch_weather",target:"night",count:5,reward:"coins",reward_amt:1,chapter:12,skippable:0}

# q206 — mythical crate grind.
data modify storage evercraft:fq_registry quests append value {id:206,title:"Hoard of the Master",desc:"Fish up 19 mythical crates. Few will ever hold so rich a haul.",type:"catch_crate",target:"mythical",count:19,reward:"crate",reward_amt:1,chapter:12,skippable:0}

# q207 — splash-node backbone.
data modify storage evercraft:fq_registry quests append value {id:207,title:"Reader of Black Water",desc:"Catch 65 fish from splash nodes. The ripples run deeper than they once did.",type:"catch_node",target:"mythical",count:65,reward:"crate",reward_amt:1,chapter:12,skippable:0}

# q208 — any-catch backbone climb.
data modify storage evercraft:fq_registry quests append value {id:208,title:"The Deeper Pull",desc:"Reel in 160 catches in all. The void runs deeper than any tide you have fished.",type:"catch_any",target:"",count:160,reward:"coins",reward_amt:1,chapter:12,skippable:0}

# q209 — mythical crate grind, building to the voidfin.
data modify storage evercraft:fq_registry quests append value {id:209,title:"Beneath the Surface",desc:"Fish up 20 mythical crates. The water grows colder the further down you reach.",type:"catch_crate",target:"mythical",count:20,reward:"crate",reward_amt:1,chapter:12,skippable:0}

# q210 — *** FIXED: first VOIDFIN *** (spirit fish; catch_aquatic uses target for
#   the fish_type -> reward coins, never gear). The void spirit's first appearance.
data modify storage evercraft:fq_registry quests append value {id:210,title:"First Light of the Void",desc:"Land a Voidfin — a spirit fish risen from where no light has ever fallen. Void fishing begins.",type:"catch_aquatic",target:"voidfin",count:1,reward:"coins",reward_amt:1,chapter:12,skippable:0}

# q211 — voidfin reuse hunt (catch_aquatic -> coins).
data modify storage evercraft:fq_registry quests append value {id:211,title:"Drawn to the Dark",desc:"Catch 2 more Voidfin. Once the void has answered, it answers again.",type:"catch_aquatic",target:"voidfin",count:2,reward:"coins",reward_amt:1,chapter:12,skippable:0}

# q212 — any-catch backbone climb.
data modify storage evercraft:fq_registry quests append value {id:212,title:"No Bottom in Sight",desc:"Reel in 160 catches in all. Every haul drops the line a little further into the dark.",type:"catch_any",target:"",count:160,reward:"coins",reward_amt:1,chapter:12,skippable:0}

# q213 — splash-node backbone.
data modify storage evercraft:fq_registry quests append value {id:213,title:"Stirrings in the Deep",desc:"Catch 65 fish from splash nodes. The void leaves ripples where there should be none.",type:"catch_node",target:"mythical",count:65,reward:"crate",reward_amt:1,chapter:12,skippable:0}

# q214 — mythical crate grind.
data modify storage evercraft:fq_registry quests append value {id:214,title:"Treasures of the Lightless",desc:"Fish up 21 mythical crates. The deepest water guards the richest hoard.",type:"catch_crate",target:"mythical",count:21,reward:"crate",reward_amt:1,chapter:12,skippable:0}

# q215 — voidfin reuse hunt (catch_aquatic -> coins).
data modify storage evercraft:fq_registry quests append value {id:215,title:"The Void Answers",desc:"Catch 3 Voidfin. The spirit of the dark deep comes willingly to your line now.",type:"catch_aquatic",target:"voidfin",count:3,reward:"coins",reward_amt:1,chapter:12,skippable:0}

# q216 — any-catch backbone climb.
data modify storage evercraft:fq_registry quests append value {id:216,title:"Master of Open Water",desc:"Reel in 160 catches in all. The sea is yours; you cast now to learn what lies below it.",type:"catch_any",target:"",count:160,reward:"coins",reward_amt:1,chapter:12,skippable:0}

# q217 — splash-node backbone.
data modify storage evercraft:fq_registry quests append value {id:217,title:"Echoes from Below",desc:"Catch 65 fish from splash nodes. Each strike sounds a little hollower than the last.",type:"catch_node",target:"mythical",count:65,reward:"crate",reward_amt:1,chapter:12,skippable:0}

# q218 — mythical crate grind, the penultimate haul before the lure.
data modify storage evercraft:fq_registry quests append value {id:218,title:"The Last Hoard Before the Dark",desc:"Fish up 23 mythical crates. Gather your strength; the void will not give freely.",type:"catch_crate",target:"mythical",count:23,reward:"crate",reward_amt:1,chapter:12,skippable:0}

# q219 — any-catch backbone, setting up the capstone node grind.
data modify storage evercraft:fq_registry quests append value {id:219,title:"On the Edge of the Deep",desc:"Reel in 160 catches in all. One last cast before you set your line for the void itself.",type:"catch_any",target:"",count:160,reward:"coins",reward_amt:1,chapter:12,skippable:0}

# q220 — *** CAPSTONE: the tideworn_lure *** (catch_node leaves target free, so
#   target carries the GEAR-reward item id; reward agent owns the loot table).
#   100 splash-node catches earn the void-worthy artifact lure.
data modify storage evercraft:fq_registry quests append value {id:220,title:"The Tideworn Lure",desc:"Catch 65 fish from splash nodes and claim the Tideworn Lure. With it, you cast where the tide ends and the void begins.",type:"catch_node",target:"tideworn_lure",count:65,reward:"gear",reward_amt:1,chapter:12,skippable:0}

# ------------------------------------------------------------
# HAND-OFF TO load_batch_11 (q221..):
#   - This batch ends at id=220. The next batch's FIRST quest MUST be id=221
#     (list index 220), appended immediately after q220, contiguously.
#   - registry/load calls load_batch_10 then load_batch_11; the main thread
#     wires the batch calls. Do NOT renumber this batch.
#
# MILESTONE-MIRROR / FISH WIRING THIS BATCH ASSUMES (other agents own these):
#   - voidfin (q210/q211/q215): the cooking spirit_fish/grant/voidfin hook
#     increments ec.fq_prog (gated to the matching active quest) then calls
#     evercraft:fishing/questline/check, per the catch hook contract.
#   - catch_weather:night (q205): overworld-only weather hook; nether/end never
#     fire night/rain/thunder. This quest is overworld by design.
#   - tideworn_lure (q220): the reward agent owns the gear loot table for this id.
# ------------------------------------------------------------
