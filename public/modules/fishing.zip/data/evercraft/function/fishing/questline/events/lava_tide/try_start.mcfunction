# ============================================================
# The Fisher's Questline — LAVA TIDE: Try Start (cooldown + roll)
# ============================================================
# Called from lava_tide/tick only when idle and ≥1 player is in the Nether.
# Gated: a long cooldown (gametime stamp) prevents back-to-back tides, and a
# modest per-check roll keeps it a rare, special occurrence.

# --- Cooldown gate: 30 in-game hours = 2,160,000 ticks between tides. ---
execute store result score #fq_now ec.temp run time query gametime
scoreboard players operation #fq_cd_chk ec.temp = #fq_now ec.temp
scoreboard players operation #fq_cd_chk ec.temp -= #fq_lt_cd ec.var
execute if score #fq_lt_cd ec.var matches 1.. if score #fq_cd_chk ec.temp matches ..-1 run return 0

# --- Roll: ~1/40 per idle check (checks fire ~every 60s while players are in Nether). ---
execute store result score #fq_lt_roll ec.temp run random value 1..40
execute unless score #fq_lt_roll ec.temp matches 1 run return 0

# --- Begin the tide. ---
function evercraft:fishing/questline/events/lava_tide/start
