# ============================================================
# The Fisher's Questline — Master-Angler title grant (macro inner)
# ============================================================
# Run as @s = the player, called with {tier:N} (N = 1..6).
# Sets ec.fq_title to N only-if-higher (never downgrades), then plays the themed
# celebration for that tier via grant_title/<N>. Mirrors reward_type/title's
# only-if-higher rule so the one-writer contract on ec.fq_title is preserved.
#
# THE MASTER-ANGLER TITLE TRACK (6 tiers — NAMES owned by this reward agent):
#   1  Bait Novice     (gray)        — first cast answered; the line is wet.
#   2  Linehand        (green)       — steady hands, steady catches.
#   3  Tidereader      (aqua)        — you read the water before you cast.
#   4  Deepwarden       (dark_aqua)  — the deep channels hold no fear for you.
#   5  Stormhauler     (gold,bold)   — you reel even when the sky turns black.
#   6  Tidecaller      (#3FE0E0,bold)— the whole ocean answers your cast.
$scoreboard players set #fq_grant_tier ec.temp $(tier)
execute if score #fq_grant_tier ec.temp > @s ec.fq_title run scoreboard players operation @s ec.fq_title = #fq_grant_tier ec.temp
$function evercraft:fishing/questline/rewards/grant_title/$(tier)
