# FQ check helper — milestone (a score threshold). Threshold quest.
# check_milestone_read already loaded the target mirror score into #fq_ms_val
# ec.temp (sirencall_stage/rod_tier/total_done). Satisfied when the mirror score
# reaches quest.count (#fq_count ec.temp).
scoreboard players set #fq_satisfied ec.temp 0
execute if score #fq_ms_val ec.temp >= #fq_count ec.temp run scoreboard players set #fq_satisfied ec.temp 1
