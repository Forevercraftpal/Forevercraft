# ============================================================
# The Fisher's Questline — SET-PIECE: Fireproof Warden (Lava Tide apex)
# ============================================================
# Called from lava_tide/on_node_catch on the 0.09 apex roll. Run as @s = the
# catching player, AT the lava node. Rises the apex fire-immune Warden — the
# rarest haul of a Lava Tide and the "special"-type set-piece target.
#
# Fire-immunity: the Warden is NOT lava-proof by default, so it gets the
# ec.fq_fireproof tag + a long fire_resistance effect. It also carries
# ec.fq_lava_mob so lava_tide/stop despawns it if the tide ends first, and
# ec.fq_fireproof_warden so its death advancement can credit the set-piece.

# --- Summon the apex Warden 2 blocks from the node. ---
summon minecraft:warden ~ ~ ~2 {Tags:["ec.fq_lava_mob","ec.fq_fireproof","ec.fq_fireproof_warden"],PersistenceRequired:1b,CanPickUpLoot:0b,DeathLootTable:"minecraft:empty",CustomNameVisible:1b,CustomName:{text:"Cinderbound Warden",color:"#FF4500",bold:true}}

# --- Lock in fire-immunity (8 min — outlasts the 4-min tide + the fight). ---
effect give @e[tag=ec.fq_fireproof_warden,distance=..6,limit=1,sort=nearest] minecraft:fire_resistance 480 0 true

# --- Apex FX: the lava roars. ---
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.warden.emerge master @s ~ ~ ~ 1.0 0.8
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.warden.roar master @s ~ ~ ~ 1.0 0.7
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.lava.pop master @s ~ ~ ~ 1.0 0.5
execute if score @s ec.fx_vis matches 1.. run particle minecraft:soul_fire_flame ~ ~1 ~ 1.0 1.0 1.0 0.08 40 force @s
execute if score @s ec.fx_vis matches 1.. run particle minecraft:lava ~ ~1 ~ 1.0 1.0 1.0 0.0 20 force @s
data modify storage evercraft:notify stage.c set value [{text:"A ",color:"gold"},{text:"Cinderbound Warden",color:"#FF4500",bold:true},{text:" rises from the lava!",color:"gold"}]
scoreboard players set #ndur ec.temp 50
execute as @a[predicate=evercraft:in_nether] run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"The apex of the tide— flame cannot touch it.",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 40
execute as @a[predicate=evercraft:in_nether] run function evercraft:util/notify/emit
title @s times 10 50 20
title @s title [{text:"Cinderbound Warden",color:"#FF4500"}]
title @s subtitle [{text:"The lava's apex stirs!",color:"gold",italic:true}]
