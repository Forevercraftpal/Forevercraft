# Milestone claim click detection — Social (page 10)
# Run as the player with menu open

execute as @e[type=interaction,tag=Adv.JnMsClaim13,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction on target run function evercraft:milestones/claim_click {id:"13",tier:"ornate"}
execute as @e[type=interaction,tag=Adv.JnMsClaim13,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=Adv.JnMsClaim14,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction on target run function evercraft:milestones/claim_click {id:"14",tier:"exquisite"}
execute as @e[type=interaction,tag=Adv.JnMsClaim14,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=Adv.JnMsClaim15,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction on target run function evercraft:milestones/claim_click {id:"15",tier:"mythical"}
execute as @e[type=interaction,tag=Adv.JnMsClaim15,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=Adv.JnMsClaim16,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction on target run function evercraft:milestones/claim_click {id:"16",tier:"exquisite"}
execute as @e[type=interaction,tag=Adv.JnMsClaim16,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=Adv.JnMsClaim17,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction on target run function evercraft:milestones/claim_click {id:"17",tier:"ornate"}
execute as @e[type=interaction,tag=Adv.JnMsClaim17,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction

# ===== INSPECT (left-click = what does this button do?) — gui/inspect pattern 2026-06-11 =====
execute as @e[type=interaction,tag=Adv.JnMsClaim13,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Fourteenth Social Milestone",b:"Right-click to claim the fourteenth social milestone reward (row 14) — available once your lifetime total reaches it."}
execute as @e[type=interaction,tag=Adv.JnMsClaim13,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=Adv.JnMsClaim14,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Fifteenth Social Milestone",b:"Right-click to claim the fifteenth social milestone reward (row 15) — available once your lifetime total reaches it."}
execute as @e[type=interaction,tag=Adv.JnMsClaim14,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=Adv.JnMsClaim15,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Slot 16 Social Milestone",b:"Right-click to claim the slot 16 social milestone reward (row 16) — available once your lifetime total reaches it."}
execute as @e[type=interaction,tag=Adv.JnMsClaim15,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=Adv.JnMsClaim16,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Slot 17 Social Milestone",b:"Right-click to claim the slot 17 social milestone reward (row 17) — available once your lifetime total reaches it."}
execute as @e[type=interaction,tag=Adv.JnMsClaim16,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=Adv.JnMsClaim17,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Slot 18 Social Milestone",b:"Right-click to claim the slot 18 social milestone reward (row 18) — available once your lifetime total reaches it."}
execute as @e[type=interaction,tag=Adv.JnMsClaim17,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack run data remove entity @s attack
