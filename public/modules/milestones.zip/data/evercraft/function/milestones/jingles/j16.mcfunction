# Hero's Call — bit full ascending heroic
data modify storage evercraft:jingles seq set value [{instr:"bit",pitch:1.0},{instr:"bit",pitch:1.0},{instr:"bit",pitch:1.189},{instr:"bit",pitch:1.498},{instr:"bit",pitch:2.0}]
function evercraft:milestones/jingles/play_sequence
