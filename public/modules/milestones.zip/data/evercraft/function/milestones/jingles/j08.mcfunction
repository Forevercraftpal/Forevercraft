# Tavern Fanfare — full F# major arpeggio with extension
data modify storage evercraft:jingles seq set value [{instr:"banjo",pitch:1.0},{instr:"banjo",pitch:1.189},{instr:"banjo",pitch:1.498},{instr:"banjo",pitch:1.782},{instr:"banjo",pitch:2.0}]
function evercraft:milestones/jingles/play_sequence
