# Triumph Ascent — harp F# major arpeggio up
data modify storage evercraft:jingles seq set value [{instr:"harp",pitch:1.0},{instr:"harp",pitch:1.189},{instr:"harp",pitch:1.498},{instr:"harp",pitch:2.0}]
function evercraft:milestones/jingles/play_sequence
