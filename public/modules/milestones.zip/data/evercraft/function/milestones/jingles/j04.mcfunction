# Folk Fiddle — banjo ornament
data modify storage evercraft:jingles seq set value [{instr:"banjo",pitch:1.189},{instr:"banjo",pitch:1.335},{instr:"banjo",pitch:1.498},{instr:"banjo",pitch:1.335},{instr:"banjo",pitch:1.189}]
function evercraft:milestones/jingles/play_sequence
