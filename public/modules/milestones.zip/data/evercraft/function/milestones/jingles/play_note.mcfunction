# Milestone Jingle — Macro: play one note for every online player at their position.
# Macro args: instr (e.g. "harp", "flute", "bell"), pitch (0.5–2.0)

$execute as @a at @s if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.$(instr) master @s ~ ~ ~ 0.7 $(pitch)
