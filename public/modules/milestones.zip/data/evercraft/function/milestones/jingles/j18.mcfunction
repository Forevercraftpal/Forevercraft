# Court Bow — elegant flute descent
data modify storage evercraft:jingles seq set value [{instr:"flute",pitch:1.189},{instr:"flute",pitch:1.122},{instr:"flute",pitch:1.0}]
function evercraft:milestones/jingles/play_sequence
