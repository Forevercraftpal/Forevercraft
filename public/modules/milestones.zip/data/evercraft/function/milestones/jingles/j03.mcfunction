# Castle Bells — three ceremonial bells
data modify storage evercraft:jingles seq set value [{instr:"bell",pitch:1.0},{instr:"bell",pitch:1.0},{instr:"bell",pitch:1.498}]
function evercraft:milestones/jingles/play_sequence
