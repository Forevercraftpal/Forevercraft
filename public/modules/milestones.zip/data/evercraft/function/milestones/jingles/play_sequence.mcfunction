# Milestone Jingle — Recursive sequencer.
# Reads storage evercraft:jingles seq[0] = {instr, pitch}, plays it at every online player,
# pops the head, and self-schedules 4 ticks later for the next note. Stops when seq is empty.

execute unless data storage evercraft:jingles seq[0] run return 0

function evercraft:milestones/jingles/play_note with storage evercraft:jingles seq[0]

data remove storage evercraft:jingles seq[0]
execute if data storage evercraft:jingles seq[0] run schedule function evercraft:milestones/jingles/play_sequence 4t replace
