# Dramatic Stinger — bell with rising resolution
data modify storage evercraft:jingles seq set value [{instr:"bell",pitch:1.682},{instr:"bell",pitch:1.682},{instr:"bell",pitch:1.498},{instr:"bell",pitch:2.0}]
function evercraft:milestones/jingles/play_sequence
