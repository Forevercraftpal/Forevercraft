# Royal Trumpet — proclamation rise (bit)
data modify storage evercraft:jingles seq set value [{instr:"bit",pitch:1.682},{instr:"bit",pitch:1.888},{instr:"bit",pitch:2.0}]
function evercraft:milestones/jingles/play_sequence
