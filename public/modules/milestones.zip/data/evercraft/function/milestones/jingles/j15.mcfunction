# Dance Lilt — banjo folk dance
data modify storage evercraft:jingles seq set value [{instr:"banjo",pitch:1.122},{instr:"banjo",pitch:1.189},{instr:"banjo",pitch:1.335},{instr:"banjo",pitch:1.189},{instr:"banjo",pitch:1.122},{instr:"banjo",pitch:1.0}]
function evercraft:milestones/jingles/play_sequence
