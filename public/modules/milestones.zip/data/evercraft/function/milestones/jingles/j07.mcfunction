# Minor Ballad — haunting flute descent
data modify storage evercraft:jingles seq set value [{instr:"flute",pitch:1.0},{instr:"flute",pitch:1.189},{instr:"flute",pitch:1.782},{instr:"flute",pitch:1.682},{instr:"flute",pitch:1.498}]
function evercraft:milestones/jingles/play_sequence
