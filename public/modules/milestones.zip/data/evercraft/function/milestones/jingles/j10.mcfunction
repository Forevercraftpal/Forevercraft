# Mystic Wind — modal flute floating
data modify storage evercraft:jingles seq set value [{instr:"flute",pitch:1.122},{instr:"flute",pitch:1.335},{instr:"flute",pitch:2.0},{instr:"flute",pitch:1.782}]
function evercraft:milestones/jingles/play_sequence
