# Pentatonic Skip — guitar pentatonic ascent
data modify storage evercraft:jingles seq set value [{instr:"guitar",pitch:1.0},{instr:"guitar",pitch:1.189},{instr:"guitar",pitch:1.335},{instr:"guitar",pitch:1.682},{instr:"guitar",pitch:2.0}]
function evercraft:milestones/jingles/play_sequence
