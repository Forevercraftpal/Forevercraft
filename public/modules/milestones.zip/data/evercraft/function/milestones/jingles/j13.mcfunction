# Holy Chime — ascending bell tower
data modify storage evercraft:jingles seq set value [{instr:"chime",pitch:1.498},{instr:"chime",pitch:1.682},{instr:"chime",pitch:1.888},{instr:"chime",pitch:2.0}]
function evercraft:milestones/jingles/play_sequence
