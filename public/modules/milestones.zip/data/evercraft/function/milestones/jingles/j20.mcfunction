# Sacred Tone — chime sacred fifth + octave
data modify storage evercraft:jingles seq set value [{instr:"chime",pitch:1.0},{instr:"chime",pitch:1.498},{instr:"chime",pitch:2.0}]
function evercraft:milestones/jingles/play_sequence
