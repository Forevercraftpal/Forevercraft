# Mystery Bell — descending bell mystery
data modify storage evercraft:jingles seq set value [{instr:"bell",pitch:2.0},{instr:"bell",pitch:1.498},{instr:"bell",pitch:1.122},{instr:"bell",pitch:1.0}]
function evercraft:milestones/jingles/play_sequence
