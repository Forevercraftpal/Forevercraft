# Chime Cascade — descending crystalline chime
data modify storage evercraft:jingles seq set value [{instr:"chime",pitch:2.0},{instr:"chime",pitch:1.682},{instr:"chime",pitch:1.335},{instr:"chime",pitch:1.122}]
function evercraft:milestones/jingles/play_sequence
