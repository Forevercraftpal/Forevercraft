# Heroic Flourish — flute rising heroic
data modify storage evercraft:jingles seq set value [{instr:"flute",pitch:1.0},{instr:"flute",pitch:1.0},{instr:"flute",pitch:1.122},{instr:"flute",pitch:1.189},{instr:"flute",pitch:1.682}]
function evercraft:milestones/jingles/play_sequence
