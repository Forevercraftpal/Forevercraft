# Milestone Jingle — Entry point. Randomly picks 1 of 20 medieval/RPG-themed
# stingers and triggers the sequencer. Called from milestones/announce.mcfunction.
#
# Wiring Audit #7 (2026-05-28): debounce — if a jingle is already playing
# (`storage evercraft:jingles seq[0]` exists), drop the new one rather than clobber
# the in-flight queue. Audible only; no data corruption either way.
execute if data storage evercraft:jingles seq[0] run return 0

execute store result score #jingle_pick ec.temp run random value 1..20

execute if score #jingle_pick ec.temp matches 1 run function evercraft:milestones/jingles/j01
execute if score #jingle_pick ec.temp matches 2 run function evercraft:milestones/jingles/j02
execute if score #jingle_pick ec.temp matches 3 run function evercraft:milestones/jingles/j03
execute if score #jingle_pick ec.temp matches 4 run function evercraft:milestones/jingles/j04
execute if score #jingle_pick ec.temp matches 5 run function evercraft:milestones/jingles/j05
execute if score #jingle_pick ec.temp matches 6 run function evercraft:milestones/jingles/j06
execute if score #jingle_pick ec.temp matches 7 run function evercraft:milestones/jingles/j07
execute if score #jingle_pick ec.temp matches 8 run function evercraft:milestones/jingles/j08
execute if score #jingle_pick ec.temp matches 9 run function evercraft:milestones/jingles/j09
execute if score #jingle_pick ec.temp matches 10 run function evercraft:milestones/jingles/j10
execute if score #jingle_pick ec.temp matches 11 run function evercraft:milestones/jingles/j11
execute if score #jingle_pick ec.temp matches 12 run function evercraft:milestones/jingles/j12
execute if score #jingle_pick ec.temp matches 13 run function evercraft:milestones/jingles/j13
execute if score #jingle_pick ec.temp matches 14 run function evercraft:milestones/jingles/j14
execute if score #jingle_pick ec.temp matches 15 run function evercraft:milestones/jingles/j15
execute if score #jingle_pick ec.temp matches 16 run function evercraft:milestones/jingles/j16
execute if score #jingle_pick ec.temp matches 17 run function evercraft:milestones/jingles/j17
execute if score #jingle_pick ec.temp matches 18 run function evercraft:milestones/jingles/j18
execute if score #jingle_pick ec.temp matches 19 run function evercraft:milestones/jingles/j19
execute if score #jingle_pick ec.temp matches 20 run function evercraft:milestones/jingles/j20
