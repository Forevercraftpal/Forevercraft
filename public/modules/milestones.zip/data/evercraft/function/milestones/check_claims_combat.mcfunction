# Milestone claim click detection — Combat (page 13)
# Run as the player with menu open

execute as @e[type=interaction,tag=Adv.JnMsClaim27,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction on target run function evercraft:milestones/claim_click {id:"27",tier:"exquisite"}
execute as @e[type=interaction,tag=Adv.JnMsClaim27,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=Adv.JnMsClaim28,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction on target run function evercraft:milestones/claim_click {id:"28",tier:"mythical"}
execute as @e[type=interaction,tag=Adv.JnMsClaim28,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=Adv.JnMsClaim29,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction on target run function evercraft:milestones/claim_click {id:"29",tier:"ornate"}
execute as @e[type=interaction,tag=Adv.JnMsClaim29,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=Adv.JnMsClaim30,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction on target run function evercraft:milestones/claim_click {id:"30",tier:"exquisite"}
execute as @e[type=interaction,tag=Adv.JnMsClaim30,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction

# ===== INSPECT (left-click = what does this button do?) — gui/inspect pattern 2026-06-11 =====
execute as @e[type=interaction,tag=Adv.JnMsClaim27,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Slot 28 Combat Milestone",b:"Right-click to claim the slot 28 combat milestone reward (row 28) — available once your lifetime total reaches it."}
execute as @e[type=interaction,tag=Adv.JnMsClaim27,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=Adv.JnMsClaim28,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Slot 29 Combat Milestone",b:"Right-click to claim the slot 29 combat milestone reward (row 29) — available once your lifetime total reaches it."}
execute as @e[type=interaction,tag=Adv.JnMsClaim28,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=Adv.JnMsClaim29,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Slot 30 Combat Milestone",b:"Right-click to claim the slot 30 combat milestone reward (row 30) — available once your lifetime total reaches it."}
execute as @e[type=interaction,tag=Adv.JnMsClaim29,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=Adv.JnMsClaim30,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Slot 31 Combat Milestone",b:"Right-click to claim the slot 31 combat milestone reward (row 31) — available once your lifetime total reaches it."}
execute as @e[type=interaction,tag=Adv.JnMsClaim30,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack run data remove entity @s attack
