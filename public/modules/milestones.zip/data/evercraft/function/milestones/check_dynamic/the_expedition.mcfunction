# Dynamic Milestone Check: The Expedition — 50% of players explored 15+ biomes
# Monotonic qualification: once a player has visited 15+ biomes, ec.exp_qualified=1 forever
# and #rm_exp_ever_qualified gets +1. Avoids the "unreachable" drift.

execute as @a if score @s jn.biome_count matches 15.. unless score @s ec.exp_qualified matches 1 run scoreboard players add #rm_exp_ever_qualified ec.var 1
execute as @a if score @s jn.biome_count matches 15.. unless score @s ec.exp_qualified matches 1 run scoreboard players set @s ec.exp_qualified 1

execute if score #rm_exp_ever_qualified ec.var >= #rm_50pct ec.var run function evercraft:milestones/complete/the_expedition
