# Dynamic Milestone Check: Hearthstone Haven — 75% of players have homes
# Monotonic qualification: once a player has any home (hs.tier >= 1), ec.hh_qualified=1 forever
# and #rm_hh_ever_qualified gets +1. Avoids the "unreachable" drift.

execute as @a if score @s hs.tier matches 1.. unless score @s ec.hh_qualified matches 1 run scoreboard players add #rm_hh_ever_qualified ec.var 1
execute as @a if score @s hs.tier matches 1.. unless score @s ec.hh_qualified matches 1 run scoreboard players set @s ec.hh_qualified 1

execute if score #rm_hh_ever_qualified ec.var >= #rm_75pct ec.var run function evercraft:milestones/complete/hearthstone_haven
