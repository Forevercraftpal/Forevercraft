# Dynamic Milestone Check: Ascended — 50% of players reached DR 20+ (ec.dr_peak_ms >= 4)
# Monotonic qualification: once a player hits DR 20+ (peak), ec.asc_qualified=1 forever
# and #rm_asc_ever_qualified gets +1. Avoids the "unreachable" drift.

execute as @a if score @s ec.dr_peak_ms matches 4.. unless score @s ec.asc_qualified matches 1 run scoreboard players add #rm_asc_ever_qualified ec.var 1
execute as @a if score @s ec.dr_peak_ms matches 4.. unless score @s ec.asc_qualified matches 1 run scoreboard players set @s ec.asc_qualified 1

execute if score #rm_asc_ever_qualified ec.var >= #rm_50pct ec.var run function evercraft:milestones/complete/ascended
