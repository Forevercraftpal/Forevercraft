# Dynamic Milestone Check: Found Family — 75% of players have 2+ friends
# Monotonic qualification: once a player first hits 2+ friends, ec.ff_qualified=1 forever
# and #rm_ff_ever_qualified gets +1. This avoids the "unreachable" drift where new joiners
# grow #rm_75pct but offline qualifiers don't count toward the numerator.

# For each ONLINE player who meets the criterion and isn't yet marked qualified:
#   - set their flag to 1
#   - bump the realm-wide ever-qualified counter by 1
execute as @a if score @s ec.fr_count matches 2.. unless score @s ec.ff_qualified matches 1 run scoreboard players add #rm_ff_ever_qualified ec.var 1
execute as @a if score @s ec.fr_count matches 2.. unless score @s ec.ff_qualified matches 1 run scoreboard players set @s ec.ff_qualified 1

# Compare monotonic ever-qualified count to the 75% threshold
execute if score #rm_ff_ever_qualified ec.var >= #rm_75pct ec.var run function evercraft:milestones/complete/found_family
