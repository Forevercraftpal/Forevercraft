# Rich lore-set completion frame (macro). Input: storage evercraft:milestones msgin
# {name,stage,req,reward,coins,tier,...}. Run as @s.
# Action-bar frames (chat→action-bar migration): called only under the ms_stage dispatch
# gate (notify_lore_set:17, after the #notif_show_ms_stage early-return). Leading "" spacer
# dropped; indents stripped; ★/✓/⚔ ornaments §4-mirrored.
$data modify storage evercraft:notify stage.c set value [{text:"★ ",color:"gold"},{text:"Lore set complete: ",color:"gold",bold:true},{text:"$(name)",color:"yellow",bold:true},{text:" ★",color:"gold"}]
scoreboard players set #ndur ec.temp 50
function evercraft:util/notify/emit_keep
$data modify storage evercraft:notify stage.c set value [{text:"✓ ",color:"dark_aqua"},{text:"$(req)",color:"white"},{text:" ✓",color:"dark_aqua"}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit
$data modify storage evercraft:notify stage.c set value [{text:"⚔ ",color:"#FFB000"},{text:"Reward: ",color:"dark_gray"},{text:"$(reward)",color:"green",bold:true},{text:" ⚔",color:"#FFB000"}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit
