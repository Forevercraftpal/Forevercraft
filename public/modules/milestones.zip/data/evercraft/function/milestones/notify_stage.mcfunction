# Milestone Stage-Cross Notification — Unified (stages 1-4 across all families)
# Args: {family, id, stage_num, name, tier, req}
# Run as @s (player). Fires the FULL completion message — the same name / requirement /
# reward(+coins) copy the bulk-claim screen shows — read from the completion registry at
# storage evercraft:milestones reg.<id>_<stage_num> (generated from claim/bulk_claim_* tables).
# name/tier/req args are now only a fallback if the registry has no entry for this stage.
#
# CRITICAL (race R-2 + C-5): grant the sentinel BEFORE any tellraw.
# CRITICAL (race): msgin is a single shared slot — clear→set→consume runs as one synchronous
#   chain here (no schedule / no function-tag split), so per-player serial dispatch keeps it safe.
#   #ms_next is single-pass; do not read it across schedules.

$advancement grant @s only evercraft:notif/$(family)/$(id)_$(stage_num)

function evercraft:util/notify/dispatch {key:"ms_stage",class:"chatter",mute_at:8}
execute if score #notif_show_ms_stage ec.temp matches 0 run return 0

# Pull the rich entry (name/stage/req/reward/coins/tier) into the macro-input slot.
# Clear first: `set from` a missing path is a no-op, so a stale prior entry must not linger.
data remove storage evercraft:milestones msgin
$data modify storage evercraft:milestones msgin set from storage evercraft:milestones reg.$(id)_$(stage_num)
# RE-P6 (2026-06-10): personal s-singles and lore sets share bare s<N> ids, so their registry
# keys are family-namespaced (reg.ps<N>_1 / reg.ls<N>_1 — the old bare keys collided, lore
# clobbered all 136 personal singles). Family-keyed re-read wins when present; p#/biome/cf
# ids resolve on the generic line above (their prefixed keys don't exist).
$data modify storage evercraft:milestones regsel set value {fam:"$(family)"}
$execute if data storage evercraft:milestones regsel{fam:"personal"} if data storage evercraft:milestones reg.p$(id)_$(stage_num) run data modify storage evercraft:milestones msgin set from storage evercraft:milestones reg.p$(id)_$(stage_num)
$execute if data storage evercraft:milestones regsel{fam:"lore"} if data storage evercraft:milestones reg.l$(id)_$(stage_num) run data modify storage evercraft:milestones msgin set from storage evercraft:milestones reg.l$(id)_$(stage_num)
$data modify storage evercraft:milestones msgin.id set value "$(id)"

# Next-stage number (single-pass temp).
$scoreboard players set #ms_next ec.temp $(stage_num)
scoreboard players add #ms_next ec.temp 1
execute store result storage evercraft:milestones msgin.next int 1 run scoreboard players get #ms_next ec.temp

# Rich path (registry hit): name / requirement / reward(+coins) / next / claim-location.
execute if data storage evercraft:milestones msgin.name run function evercraft:milestones/print_stage with storage evercraft:milestones msgin
$execute if data storage evercraft:milestones msgin.name run function evercraft:milestones/loc_line/$(family)

# Fallback (registry miss): the old terse one-liner — never crashes the macro.
# Action-bar frame (chat→action-bar migration): indent dropped, ★ §4-mirrored, the [$(tier)]
# rarity bracket dropped per §4b (its #E0B0FF color carries the tier). Staged unconditionally,
# emit gated on the registry-miss branch (inert when the rich path took over).
$data modify storage evercraft:notify stage.c set value [{text:"★ ",color:"#E0B0FF"},{text:"$(name)",color:"yellow"},{text:" — Stage $(stage_num) ",color:"white"},{text:"$(tier)",color:"#E0B0FF"},{text:" — ",color:"dark_gray"},{text:"$(req)",color:"gray"},{text:" ★",color:"#E0B0FF"}]
scoreboard players set #ndur ec.temp 45
execute unless data storage evercraft:milestones msgin.name run function evercraft:util/notify/emit_keep

execute if score #notif_show_mute_ms_stage ec.temp matches 1 run tellraw @s [{text:"  ",color:"dark_gray"},{text:"[Mute]",color:"dark_gray",hover_event:{action:"show_text",value:{text:"Stop showing milestone-ready nudges.",color:"gray"}},click_event:{action:"run_command",command:"/trigger ec.nm_ms_stage set 1"}}]
