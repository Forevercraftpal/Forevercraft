# Milestone claim click detection — Guild & Warfare (page 11)
# Run as the player with menu open

execute as @e[type=interaction,tag=Adv.JnMsClaim18,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction on target run function evercraft:milestones/claim_click {id:"18",tier:"rare"}
execute as @e[type=interaction,tag=Adv.JnMsClaim18,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=Adv.JnMsClaim19,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction on target run function evercraft:milestones/claim_click {id:"19",tier:"exquisite"}
execute as @e[type=interaction,tag=Adv.JnMsClaim19,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=Adv.JnMsClaim20,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction on target run function evercraft:milestones/claim_click {id:"20",tier:"ornate"}
execute as @e[type=interaction,tag=Adv.JnMsClaim20,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=Adv.JnMsClaim21,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction on target run function evercraft:milestones/claim_click {id:"21",tier:"mythical"}
execute as @e[type=interaction,tag=Adv.JnMsClaim21,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=Adv.JnMsClaim22,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction on target run function evercraft:milestones/claim_click {id:"22",tier:"exquisite"}
execute as @e[type=interaction,tag=Adv.JnMsClaim22,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction

# ===== INSPECT (left-click = what does this button do?) — gui/inspect pattern 2026-06-11 =====
execute as @e[type=interaction,tag=Adv.JnMsClaim18,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Slot 19 Guild Milestone",b:"Right-click to claim the slot 19 guild milestone reward (row 19) — available once your lifetime total reaches it."}
execute as @e[type=interaction,tag=Adv.JnMsClaim18,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=Adv.JnMsClaim19,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Slot 20 Guild Milestone",b:"Right-click to claim the slot 20 guild milestone reward (row 20) — available once your lifetime total reaches it."}
execute as @e[type=interaction,tag=Adv.JnMsClaim19,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=Adv.JnMsClaim20,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Slot 21 Guild Milestone",b:"Right-click to claim the slot 21 guild milestone reward (row 21) — available once your lifetime total reaches it."}
execute as @e[type=interaction,tag=Adv.JnMsClaim20,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=Adv.JnMsClaim21,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Slot 22 Guild Milestone",b:"Right-click to claim the slot 22 guild milestone reward (row 22) — available once your lifetime total reaches it."}
execute as @e[type=interaction,tag=Adv.JnMsClaim21,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=Adv.JnMsClaim22,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Slot 23 Guild Milestone",b:"Right-click to claim the slot 23 guild milestone reward (row 23) — available once your lifetime total reaches it."}
execute as @e[type=interaction,tag=Adv.JnMsClaim22,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack run data remove entity @s attack
