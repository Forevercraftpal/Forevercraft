# Personal Milestones — Load
# Creates new tracking scoreboards needed by personal milestones

# Total mob kills (incremented in bestiary/track/on_kill)
scoreboard objectives add ach.total_kills dummy "Total Mob Kills"

# Dungeon completions (ach.dungeons_done already defined in achievements/load)
# Boss kills (ach.boss_kills already defined in achievements/load)
# Bounty completions (ec.bounty_done already defined in init)
# Party combos (ach.combos_triggered already defined in achievements/load)

# === LIFETIME ACCUMULATORS (milestone-roster overhaul 2026-06-06) ===
# Five new lifetime counters that back milestones the balance audit found broken
# (previously read bitfields / per-match scores / dead counters). Each has exactly
# one gated +1 writer at the discovery/completion site. ach.dungeon_no_death is
# already declared in achievements/load.
scoreboard objectives add ec.pc_count dummy "Party Combos Discovered"
scoreboard objectives add ec.titles_count dummy "Special Titles Unlocked"
scoreboard objectives add ec.nests_done dummy "Nests Completed"
scoreboard objectives add ec.duel_kills_total dummy "Lifetime Duel Kills"
# ec.dng_deathless = per-run deathless flag (1 at dungeon enter, cleared to 0 on a
# death during the run, read at completion to bump ach.dungeon_no_death).
scoreboard objectives add ec.dng_deathless dummy "Dungeon Deathless Flag"

# === STAGE-CROSS NOTIFICATIONS (Plan C, advancement-sentinel after 2026-05-26 cleanup) ===
# Sentinels live as advancements at evercraft:notif/personal/<id>_<stage>. Granted by
# notify_stage(_5) BEFORE the tellraw fires. Reset via parent revoke in strip_player_zero.
# Schedule the passive 60s stage-check so notifications fire even without codex open.
schedule function evercraft:milestones/personal/check_all_passive 60s replace

# AU7-P3.1 (Wave L, 2026-05-31): the one-time `cleanup_orphan_sentinels` call (250 silent
# `scoreboard objectives remove ach.ps_*` no-ops on every reload) is RETIRED. The orphan
# objectives it cleared came from the pre-2026-05-26 scoreboard-sentinel ship; every world
# loaded since then has already been cleaned, and the Plan-C advancement-sentinel scheme no
# longer creates them. Tombstoned in BIG_BRAIN/20-architecture/dead-code.md.
