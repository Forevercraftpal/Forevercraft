# === PERSONAL FAMILY — NOTIFY_ARGS_5 LOOKUP MACRO ===
# Args: {id:"<p1..s130>"}
# Run as @s (player). Stage 5 is always Mythical-tier.
#
# Wiring Audit #7 (2026-05-28) F5/AU6-MS.4: stage-5 rich notify. Per-id name lookup queued
# as AU7-MS.5 in 10-pending — for now a generic name + req is used.

$function evercraft:milestones/notify_stage_5 {family:"personal",id:"$(id)",name:"Personal $(id)",tier:"Mythical",req:"Final stage threshold reached"}
