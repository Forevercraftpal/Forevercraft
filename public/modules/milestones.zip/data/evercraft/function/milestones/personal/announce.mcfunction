# === PERSONAL MILESTONE CLAIM FEEDBACK ===
# Macro: {name:"...", stage:"...", req:"...", reward:"..."}
# Shows a compact claim line to the player (not broadcast)
# Run as: player

$data modify storage evercraft:notify stage.c set value ["",{"text":"★ ","color":"gold"},{"text":"$(name)","color":"yellow"},{"text":" — ","color":"dark_gray"},{"text":"$(stage)","color":"white"},{"text":" | ","color":"dark_gray"},{"text":"$(req)","color":"gray"},{"text":" → ","color":"dark_gray"},{"text":"$(reward)","color":"green"},{"text":" ★","color":"gold"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
