# === PERSONAL FAMILY — NOTIFY_ARGS LOOKUP MACRO ===
# Args: {id:"<p1..s130>", stage_num:"1..4"}
# Run as @s (player).
#
# Wiring Audit #7 (2026-05-28) F5/AU6-MS.4: routes per-id name/tier/req lookup, then dispatches
# `notify_stage` with the rich-format args. Stage 5 uses `notify_args_5` (separate file).
# Per-id name/req population is queued as AU7-MS.5 in BIG_BRAIN/10-pending.md — for now a
# generic name + req is used so the rich format is at least non-anonymous; tier is mapped
# from stage_num (1=Uncommon / 2=Rare / 3=Ornate / 4=Exquisite).

# Stage-num → tier (uniform ladder for stages 1-4).
$scoreboard players set #ms_stage_num_lookup ec.temp $(stage_num)

$execute if score #ms_stage_num_lookup ec.temp matches 1 run function evercraft:milestones/notify_stage {family:"personal",id:"$(id)",stage_num:"1",name:"Personal $(id)",tier:"Uncommon",req:"Threshold reached"}
$execute if score #ms_stage_num_lookup ec.temp matches 2 run function evercraft:milestones/notify_stage {family:"personal",id:"$(id)",stage_num:"2",name:"Personal $(id)",tier:"Rare",req:"Threshold reached"}
$execute if score #ms_stage_num_lookup ec.temp matches 3 run function evercraft:milestones/notify_stage {family:"personal",id:"$(id)",stage_num:"3",name:"Personal $(id)",tier:"Ornate",req:"Threshold reached"}
$execute if score #ms_stage_num_lookup ec.temp matches 4 run function evercraft:milestones/notify_stage {family:"personal",id:"$(id)",stage_num:"4",name:"Personal $(id)",tier:"Exquisite",req:"Threshold reached"}
