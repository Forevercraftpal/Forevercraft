# Personal Milestone — Passive Stage-Check Scheduler
# Runs every 60s (replace-scheduled) to detect stage crossings even when the player hasn't
# opened the codex. Without this path, stage notifications only fired when the player
# actively browsed their catalogue — which is the bug Joseph flagged.
#
# Reuses existing check_all (which already does the per-milestone gates via check_one).
# check_one now fires notify_stage automatically when a new stage is crossed.

execute unless entity @a run return run schedule function evercraft:milestones/personal/check_all_passive 60s replace

# Wiring Audit #7 (2026-05-28): scan-only mode — check_all skips the zero-write and check_one
# skips the ec.claim_prs accumulator. Only stage-cross notify_stage sentinels fire from here.
# check_unclaimed (called from codex-open + post-bulk) is the canonical single writer of ec.claim_prs.
scoreboard players set #ms_scan_only ec.temp 1
execute as @a[tag=ec.joined] at @s run function evercraft:milestones/personal/check_all
scoreboard players set #ms_scan_only ec.temp 0

schedule function evercraft:milestones/personal/check_all_passive 60s replace
