# === CHECK ONE PERSONAL MILESTONE ===
# Args: {id:"p1", score:"ach.comp_owned", t1:10, t2:25, t3:50, t4:75, t5:96}
# Increments @s ec.claim_prs for each unclaimed stage reached.
#
# Stage-cross notifications fire via the unified milestones/notify_stage helper.
# Sentinel: advancement `evercraft:notif/personal/<id>_<stage>` granted BEFORE tellraw.
#
# PRIME MODE (#ms_prime ec.temp == 1): the one-time silent sentinel backfill (milestones/prime,
# run once per player on first join). When set, each already-crossed-threshold line GRANTS the
# notif sentinel directly (no notify function, no tellraw/sound) so the passive scanner stops
# treating pre-2026-05-26-migration progress as un-announced. The ec.claim_prs accumulator is
# also skipped (prime piggybacks the #ms_scan_only gate). NEVER touches claim/* — claimability
# is unaffected. Idempotent: re-granting an already-held advancement is a no-op.

# Wiring Audit #7 (2026-05-28): F2 perf early-return — end-game players (all 5 stages of this
# milestone claimed) skip the entire 11-op block. Uses stage_5's advancement as the all-done sentinel.
# (A stage-5-claimed player already holds every notif sentinel, so priming them is a no-op anyway.)
$execute if entity @s[advancements={evercraft:claim/personal/$(id)_5=true}] run return 0

# Zero #ms_val FIRST: if the player has no tracked entry for $(score) (e.g. after a Pioneer
# wipe — strip_player_zero's `scoreboard players reset @s` removes the entry, and not every
# milestone score is re-set to 0), `scoreboard players get` FAILS and `store result` leaves
# #ms_val holding the PREVIOUS milestone's value → false stage-cross notifications spray for
# milestones the player never earned. Initializing to 0 makes a missing entry read as 0 progress.
# (Joseph 2026-06-04: "milestones keep auto-giving after Pioneer death, gather-100-crops with 0 crops".)
scoreboard players set #ms_val ec.temp 0
$execute store result score #ms_val ec.temp run scoreboard players get @s $(score)

# Stage 1 — claim counter + stage-cross notification
# The `add ec.claim_prs` is GATED on #ms_scan_only=0 (Wiring Audit #7 race fix — passive scans
# don't accumulate; only check_unclaimed (codex-open / post-bulk) writes the counter).
$execute if score #ms_val ec.temp matches $(t1).. if score @s ec.ms_unlock matches $(u1).. unless score #ms_scan_only ec.temp matches 1 unless entity @s[advancements={evercraft:claim/personal/$(id)_1=true}] run scoreboard players add @s ec.claim_prs 1
$execute if score #ms_val ec.temp matches $(t1).. unless score #ms_prime ec.temp matches 1 unless entity @s[advancements={evercraft:notif/personal/$(id)_1=true}] run function evercraft:milestones/personal/notify_args {id:"$(id)",stage_num:"1"}
$execute if score #ms_val ec.temp matches $(t1).. if score #ms_prime ec.temp matches 1 run advancement grant @s only evercraft:notif/personal/$(id)_1

# Stage 2
$execute if score #ms_val ec.temp matches $(t2).. if score @s ec.ms_unlock matches $(u2).. unless score #ms_scan_only ec.temp matches 1 unless entity @s[advancements={evercraft:claim/personal/$(id)_2=true}] run scoreboard players add @s ec.claim_prs 1
$execute if score #ms_val ec.temp matches $(t2).. unless score #ms_prime ec.temp matches 1 unless entity @s[advancements={evercraft:notif/personal/$(id)_2=true}] run function evercraft:milestones/personal/notify_args {id:"$(id)",stage_num:"2"}
$execute if score #ms_val ec.temp matches $(t2).. if score #ms_prime ec.temp matches 1 run advancement grant @s only evercraft:notif/personal/$(id)_2

# Stage 3
$execute if score #ms_val ec.temp matches $(t3).. if score @s ec.ms_unlock matches $(u3).. unless score #ms_scan_only ec.temp matches 1 unless entity @s[advancements={evercraft:claim/personal/$(id)_3=true}] run scoreboard players add @s ec.claim_prs 1
$execute if score #ms_val ec.temp matches $(t3).. unless score #ms_prime ec.temp matches 1 unless entity @s[advancements={evercraft:notif/personal/$(id)_3=true}] run function evercraft:milestones/personal/notify_args {id:"$(id)",stage_num:"3"}
$execute if score #ms_val ec.temp matches $(t3).. if score #ms_prime ec.temp matches 1 run advancement grant @s only evercraft:notif/personal/$(id)_3

# Stage 4
$execute if score #ms_val ec.temp matches $(t4).. if score @s ec.ms_unlock matches $(u4).. unless score #ms_scan_only ec.temp matches 1 unless entity @s[advancements={evercraft:claim/personal/$(id)_4=true}] run scoreboard players add @s ec.claim_prs 1
$execute if score #ms_val ec.temp matches $(t4).. unless score #ms_prime ec.temp matches 1 unless entity @s[advancements={evercraft:notif/personal/$(id)_4=true}] run function evercraft:milestones/personal/notify_args {id:"$(id)",stage_num:"4"}
$execute if score #ms_val ec.temp matches $(t4).. if score #ms_prime ec.temp matches 1 run advancement grant @s only evercraft:notif/personal/$(id)_4

# Stage 5 (rare/payoff — loud announce regardless of per-key mute)
$execute if score #ms_val ec.temp matches $(t5).. if score @s ec.ms_unlock matches $(u5).. unless score #ms_scan_only ec.temp matches 1 unless entity @s[advancements={evercraft:claim/personal/$(id)_5=true}] run scoreboard players add @s ec.claim_prs 1
$execute if score #ms_val ec.temp matches $(t5).. unless score #ms_prime ec.temp matches 1 unless entity @s[advancements={evercraft:notif/personal/$(id)_5=true}] run function evercraft:milestones/personal/notify_args_5 {id:"$(id)"}
$execute if score #ms_val ec.temp matches $(t5).. if score #ms_prime ec.temp matches 1 run advancement grant @s only evercraft:notif/personal/$(id)_5
