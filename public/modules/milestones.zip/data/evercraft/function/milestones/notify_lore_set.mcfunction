# Lore Set Completion Notification — Loud (lore sets are single-stage; completion is the payoff)
# Args: {id:"s1", set_name:"<lore set display name>"}
# Run as @s. Class:alert so it shows unless ec.notify=2 OFF.
# Rich copy (req + reward + coins) read from the completion registry reg.l<id>_1 (RE-P6 namespacing 2026-06-10), the same
# data the bulk-claim screen shows. set_name kept as a fallback if the registry has no entry.
# CRITICAL: grant sentinel BEFORE tellraw; clear→set→consume msgin in one synchronous chain.

$advancement grant @s only evercraft:notif/lore/$(id)_1

function evercraft:util/notify/dispatch {key:"ms_stage",class:"alert",mute_at:99}
execute if score #notif_show_ms_stage ec.temp matches 0 run return 0

data remove storage evercraft:milestones msgin
$data modify storage evercraft:milestones msgin set from storage evercraft:milestones reg.l$(id)_1

# Rich path (registry hit): name / requirement / reward(+coins) / claim-location.
execute if data storage evercraft:milestones msgin.name run function evercraft:milestones/print_lore with storage evercraft:milestones msgin
execute if data storage evercraft:milestones msgin.name run function evercraft:milestones/loc_line/lore

# Fallback (registry miss): the prior loud line.
# Action-bar frames (chat→action-bar migration): leading/trailing "" spacers + indents dropped,
# ★ §4-mirrored. Staged unconditionally, emit gated on the registry-miss branch (inert when the
# rich path took over).
$data modify storage evercraft:notify stage.c set value [{text:"★ ",color:"gold"},{text:"Lore set complete: ",color:"gold",bold:true},{text:"$(set_name)",color:"yellow",bold:true},{text:" ★",color:"gold"}]
scoreboard players set #ndur ec.temp 50
execute unless data storage evercraft:milestones msgin.name run function evercraft:util/notify/emit_keep
data modify storage evercraft:notify stage.c set value [{text:"Claim its reward in the codex.",color:"green",italic:true}]
scoreboard players set #ndur ec.temp 40
execute unless data storage evercraft:milestones msgin.name run function evercraft:util/notify/emit

execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.6 1.4
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.experience_orb.pickup master @s ~ ~ ~ 0.5 1.6
