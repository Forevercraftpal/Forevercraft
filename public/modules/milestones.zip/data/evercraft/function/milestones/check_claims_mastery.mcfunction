# Milestone claim click detection — Mastery (page 14)
# Run as the player with menu open

execute as @e[type=interaction,tag=Adv.JnMsClaim31,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction on target run function evercraft:milestones/claim_click {id:"31",tier:"mythical"}
execute as @e[type=interaction,tag=Adv.JnMsClaim31,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=Adv.JnMsClaim32,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction on target run function evercraft:milestones/claim_click {id:"32",tier:"ornate"}
execute as @e[type=interaction,tag=Adv.JnMsClaim32,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=Adv.JnMsClaim33,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction on target run function evercraft:milestones/claim_click {id:"33",tier:"exquisite"}
execute as @e[type=interaction,tag=Adv.JnMsClaim33,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=Adv.JnMsClaim34,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction on target run function evercraft:milestones/claim_click_legacy
execute as @e[type=interaction,tag=Adv.JnMsClaim34,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction

# ===== INSPECT (left-click = what does this button do?) — gui/inspect pattern 2026-06-11 =====
execute as @e[type=interaction,tag=Adv.JnMsClaim31,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Slot 32 Mastery Milestone",b:"Right-click to claim the slot 32 mastery milestone reward (row 32) — available once your lifetime total reaches it."}
execute as @e[type=interaction,tag=Adv.JnMsClaim31,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=Adv.JnMsClaim32,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Slot 33 Mastery Milestone",b:"Right-click to claim the slot 33 mastery milestone reward (row 33) — available once your lifetime total reaches it."}
execute as @e[type=interaction,tag=Adv.JnMsClaim32,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=Adv.JnMsClaim33,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Slot 34 Mastery Milestone",b:"Right-click to claim the slot 34 mastery milestone reward (row 34) — available once your lifetime total reaches it."}
execute as @e[type=interaction,tag=Adv.JnMsClaim33,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=Adv.JnMsClaim34,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Slot 35 Mastery Milestone",b:"Right-click to claim the slot 35 mastery milestone reward (row 35) — available once your lifetime total reaches it."}
execute as @e[type=interaction,tag=Adv.JnMsClaim34,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack run data remove entity @s attack
