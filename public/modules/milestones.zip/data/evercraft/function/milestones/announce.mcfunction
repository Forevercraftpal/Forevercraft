# World Milestones — Announce (macro)
# Called with: {name:"...", desc:"...", reward:"...", req:"..."}
# Layout puts the three key facts (NAME, REQUIREMENT, REWARD) on their own lines
# with clear icons + colors so the player can scan in one glance.
#
# INVARIANT (Wiring Audit #7, 2026-05-28): callers MUST inline `data modify storage
# evercraft:milestones temp set value {...}` IMMEDIATELY before calling this function.
# No schedules, no intervening fn calls. `storage evercraft:milestones temp` is a
# single-key shared slot; serial execution within a tick is required for the macro
# args to resolve to the intended values.
# See _council/2026-05-28-wiring-milestones/chat/race.md F2 for the trace.

# Action-bar fan-out (§5 static broadcast): stage each frame once, emit as every player.
# WORLD MILESTONE ACHIEVED headline, then name / desc / requirement / reward / claim-breadcrumb.
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"WORLD MILESTONE ACHIEVED",color:"gold",bold:true},{text:" ✦",color:"gold"}]
scoreboard players set #ndur ec.temp 50
execute as @a run function evercraft:util/notify/emit_keep
$data modify storage evercraft:notify stage.c set value [{text:"$(name)",color:"yellow",bold:true}]
scoreboard players set #ndur ec.temp 40
execute as @a run function evercraft:util/notify/emit
$data modify storage evercraft:notify stage.c set value [{text:"$(desc)",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 40
execute as @a run function evercraft:util/notify/emit
$data modify storage evercraft:notify stage.c set value [{text:"✓ ",color:"dark_aqua"},{text:"Requirement: ",color:"dark_gray"},{text:"$(req)",color:"white"}]
scoreboard players set #ndur ec.temp 40
execute as @a run function evercraft:util/notify/emit
$data modify storage evercraft:notify stage.c set value [{text:"⚔ ",color:"#FFB000"},{text:"Reward: ",color:"dark_gray"},{text:"$(reward)",color:"green",bold:true}]
scoreboard players set #ndur ec.temp 40
execute as @a run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Open ",color:"gray"},{text:"Codex » Journal » Milestones",color:"#E0B0FF",bold:true},{text:" to claim!",color:"gray"}]
scoreboard players set #ndur ec.temp 40
execute as @a run function evercraft:util/notify/emit

# Coin reward (realm-wide)
function evercraft:coins/milestone_reward

# Sound + fireworks for all online players
execute as @a at @s if score @s ec.fx_snd matches 1.. run playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 1.0 1.0
execute as @a at @s if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.firework_rocket.twinkle master @s ~ ~ ~ 0.8 1.2

# Random medieval/RPG jingle (one of 20 variations) — note sequence plays via self-scheduling
schedule function evercraft:milestones/jingles/play 6t replace
execute as @a at @s run summon firework_rocket ~ ~ ~ {LifeTime:0,FireworksItem:{id:"minecraft:firework_rocket",count:1,components:{fireworks:{flight_duration:1b,explosions:[{shape:"large_ball",colors:[16766720,16755200],has_trail:true}]}}}}
execute as @a at @s run summon firework_rocket ~ ~ ~ {LifeTime:5,FireworksItem:{id:"minecraft:firework_rocket",count:1,components:{fireworks:{flight_duration:2b,explosions:[{shape:"star",colors:[16766720],fade_colors:[16777215],has_twinkle:true}]}}}}
