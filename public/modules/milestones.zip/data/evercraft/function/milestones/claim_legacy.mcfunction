# Milestone Claim — Eternal Legacy (milestone 34)
# Awards 3x Mythical Crate
# Run as: player, at player

# Guard: player must still be in menu
execute unless entity @s[tag=Adv.InMenu] unless entity @s[tag=CF.InCodex] run return 0

# Guard: milestone must be complete
execute unless score #rm_done_34 ec.var matches 1 run return 0

# Guard: player must not have already claimed
execute if entity @s[advancements={evercraft:milestones/claimed/ms_34=true}] run return 0

# Guard: Eternal Legacy is Mythical — requires 15.0 DR peak
function evercraft:milestones/unlock/gate {tier:"mythical"}
execute if score #ms_gate ec.temp matches 0 run return run function evercraft:milestones/unlock/locked_msg {tier:"mythical"}

# Grant 3× mythical crates + advancement via shared helper (Wiring Audit #7, 2026-05-28).
# The helper re-runs the same gate check (idempotent); the locked_msg branch above already
# handled the user-facing refusal — if we reach here the gate WILL pass.
function evercraft:claim/_grant_ms34

# Extra celebration
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.player.levelup master @s ~ ~ ~ 0.8 1.2
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.experience_orb.pickup master @s ~ ~ ~ 1.0 0.6
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 1.0 0.8
particle minecraft:happy_villager ~ ~1.5 ~ 0.5 0.5 0.5 0.02 15
data modify storage evercraft:notify stage.c set value [{text:"You claimed ",color:"green"},{text:"3x Mythical Crate",color:"light_purple",bold:true},{text:" from Eternal Legacy!",color:"green"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit

# Reset cooldown to prevent held-right-click from rapid-firing
scoreboard players set @s adv.gui_cd 3

# Refresh current page display
execute if score @s adv.gui_page matches 14 run function evercraft:codex/hub/journal/refresh_ms_mastery
