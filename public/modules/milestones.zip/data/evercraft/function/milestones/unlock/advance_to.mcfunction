# Milestone Rarity Unlock — Celebrate a newly reached tier (macro)
# Args: {tier:"2"|"3"|"4"|"5"} — numeric notify level (2=rare .. 5=mythical)
# Run as @s. Stamps the ec.ms_notif_hi watermark and fires the matching one-time
# notification. Does NOT write ec.ms_unlock — the claim gate is owned by unlock/_apply
# (current stable DR, bidirectional). Tier 6 retired with the DR-15 headroom level.
$scoreboard players set @s ec.ms_notif_hi $(tier)
$function evercraft:milestones/unlock/notify/t$(tier)
