# Milestone Rarity Lock — Refusal feedback (macro)
# Args: {tier:"common"|...|"mythical"}
# Run as @s. Tells the player the milestone is locked behind a DR threshold.
$function evercraft:milestones/unlock/locked_msg_t/$(tier)
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 0.6 0.5
