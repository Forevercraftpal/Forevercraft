# Milestone Rarity Unlock — Resync ec.ms_unlock to CURRENT stable DR (SHARED single source of truth)
# Run as @s. Recomputes the player's current stable Dream Rate (total luck minus temporary
# modifiers) and applies the unlock ladder BOTH directions — claimability re-locks when DR
# drops back below a milestone threshold (Joseph 2026-06-10; previously this synced up-only
# from the ec.dr_peak ratchet, so achieving a DR milestone once left its crates claimable
# forever, even after the Dream Rate fell — e.g. unequipping artifacts or vault enshrines).
# Called by BOTH the claim gate (unlock/gate) AND the pending counter
# (milestones/personal/check_all) AND the journal/overview refreshes, so claimability,
# the displayed count and the gold [Claim] rows all use IDENTICAL eligibility. If these
# ever diverged the count would over-state ("9 pending, only 8 claim" — 2026-06-06).
# The one-time "Codex vibrates" unlock notifications ride the ec.ms_notif_hi watermark
# in unlock/check — re-crossing a threshold via equip churn never re-fires them.
function evercraft:dreams/peak/_compute_stable
function evercraft:milestones/unlock/_apply
