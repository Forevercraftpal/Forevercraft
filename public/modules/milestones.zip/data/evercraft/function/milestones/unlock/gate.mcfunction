# Milestone Rarity Unlock — Gate Check (macro)
# Args: {tier:"common"|"uncommon"|"rare"|"ornate"|"exquisite"|"mythical"}
# Run as @s. Reads @s ec.ms_unlock and sets #ms_gate ec.temp = 1 (open) or 0 (locked).
# Resync ec.ms_unlock to the CURRENT stable Dream Rate (bidirectional — re-locks on DR drop,
# Joseph 2026-06-10). Extracted to a SHARED helper (Joseph 2026-06-06) so the
# pending-count (milestones/personal/check_all) computes eligibility identically — else count > claimable
# ("9 pending, only 8 claim"). See milestones/unlock/resync for the full rationale.
function evercraft:milestones/unlock/resync

$function evercraft:milestones/unlock/tier/$(tier)
