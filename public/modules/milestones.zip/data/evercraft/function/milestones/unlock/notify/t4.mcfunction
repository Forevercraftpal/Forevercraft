data modify storage evercraft:notify stage.c set value [{text:"✴ ",color:"dark_purple"},{text:"The Codex vibrates",color:"#E0B0FF",italic:true},{text:" and a sudden ",color:"gray",italic:true},{text:"\"click\"",color:"yellow",italic:true,bold:true},{text:" is heard from the milestone pages.",color:"gray",italic:true},{text:" ✴",color:"dark_purple"}]
scoreboard players set #ndur ec.temp 50
function evercraft:util/notify/emit_keep
data modify storage evercraft:notify stage.c set value [{text:"Exquisite ",color:"light_purple",bold:true},{text:"milestones are now claimable.",color:"gray"}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 1.0 1.1
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:item.book.page_turn master @s ~ ~ ~ 0.8 1.0
