# uncommon is the always-claimable floor (2026-06-05 fix) — this can never fire;
# the file exists so the locked_msg macro dispatch never errors
