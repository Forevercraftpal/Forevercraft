data modify storage evercraft:notify stage.c set value [{text:"Locked — ",color:"red"},{text:"Mythical",color:"gold",bold:true},{text:" milestones require ",color:"gray"},{text:"10.0 Dream Rate",color:"#E0B0FF",bold:true},{text:".",color:"gray"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
