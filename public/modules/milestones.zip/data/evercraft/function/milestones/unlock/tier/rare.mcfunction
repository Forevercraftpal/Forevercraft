scoreboard players set #ms_gate ec.temp 0
# RARE = unlock-2 (DR 3.0), shifted down one with the uncommon floor fix (Joseph 2026-06-05).
execute if score @s ec.ms_unlock matches 2.. run scoreboard players set #ms_gate ec.temp 1
