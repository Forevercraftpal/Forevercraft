# Milestone rarity gate — UNCOMMON = the FLOOR tier, claimable by EVERYONE (Joseph 2026-06-05).
# Milestones are EARNED by gameplay (harvest/cook/forge/…), so the floor reward must not need DR at all.
# Curve shifted down one: uncommon = default unlock-1 (free); rare 2 (DR 3.0), ornate 3 (5.0),
# exquisite 4 (7.0), mythical 5 (10.0). Previously uncommon sat at unlock-2 (DR 3.0) → a low-DR player
# could claim NOTHING, every claim silently returned 0 at this gate.
scoreboard players set #ms_gate ec.temp 0
execute if score @s ec.ms_unlock matches 1.. run scoreboard players set #ms_gate ec.temp 1
