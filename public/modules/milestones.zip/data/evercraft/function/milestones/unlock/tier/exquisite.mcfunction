scoreboard players set #ms_gate ec.temp 0
# EXQUISITE = unlock-4 (DR 7.0), shifted down one with the uncommon floor fix (Joseph 2026-06-05).
execute if score @s ec.ms_unlock matches 4.. run scoreboard players set #ms_gate ec.temp 1
