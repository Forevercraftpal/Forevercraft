# Milestone Rarity Unlock — Silent watermark initialization
# Run as @s. Sets ec.ms_notif_hi to the tier the player's PEAK DR already reached,
# without firing notifications. Used on first call (post-datapack-install, new player
# join) so existing players don't get 4 "click" celebrations stacked in one tick.
# ec.ms_unlock itself is NOT set here — unlock/_apply owns it (current stable DR).
scoreboard players set @s ec.ms_notif_hi 1
execute if score @s ec.dr_peak matches 30.. run scoreboard players set @s ec.ms_notif_hi 2
execute if score @s ec.dr_peak matches 50.. run scoreboard players set @s ec.ms_notif_hi 3
execute if score @s ec.dr_peak matches 70.. run scoreboard players set @s ec.ms_notif_hi 4
execute if score @s ec.dr_peak matches 100.. run scoreboard players set @s ec.ms_notif_hi 5
