scoreboard players set #ms_gate ec.temp 0
# MYTHICAL = unlock-5 (DR 10.0), shifted down one with the uncommon floor fix (Joseph 2026-06-05).
execute if score @s ec.ms_unlock matches 5.. run scoreboard players set #ms_gate ec.temp 1
