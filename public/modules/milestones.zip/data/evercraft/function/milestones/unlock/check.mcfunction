# Milestone Rarity Unlock — Sync & Notify
# Run as @s (player). Called from dreams/peak/update (dream_rank 5s cadence + on-join +
# dream_entered), immediately after _compute_stable — @s ec.temp still holds the current
# stable DR (x10). Consume it FIRST via _apply, before the notify chain touches anything.
function evercraft:milestones/unlock/_apply

# One-time "Codex vibrates" celebrations — watermarked on ec.ms_notif_hi (highest tier
# ever celebrated) and keyed to ec.dr_peak (first time EVER reaching the tier), so the
# bidirectional gate above can re-lock/re-unlock freely without notification spam.

# Silent watermark init on first call (existing players post-reload don't get 4 stacked notifications)
execute unless score @s ec.ms_notif_hi matches 1.. run function evercraft:milestones/unlock/init

# Compute celebration-eligible tier from ec.dr_peak (highest threshold met wins)
scoreboard players set #ms_target ec.temp 1
execute if score @s ec.dr_peak matches 30.. run scoreboard players set #ms_target ec.temp 2
execute if score @s ec.dr_peak matches 50.. run scoreboard players set #ms_target ec.temp 3
execute if score @s ec.dr_peak matches 70.. run scoreboard players set #ms_target ec.temp 4
execute if score @s ec.dr_peak matches 100.. run scoreboard players set #ms_target ec.temp 5

# Nothing to celebrate if already at or above target (also covers the just-init'd path)
execute if score @s ec.ms_notif_hi >= #ms_target ec.temp run return 0

# Celebrate one tier at a time (organic DR growth path)
execute if score @s ec.ms_notif_hi matches ..1 if score #ms_target ec.temp matches 2.. run function evercraft:milestones/unlock/advance_to {tier:"2"}
execute if score @s ec.ms_notif_hi matches ..2 if score #ms_target ec.temp matches 3.. run function evercraft:milestones/unlock/advance_to {tier:"3"}
execute if score @s ec.ms_notif_hi matches ..3 if score #ms_target ec.temp matches 4.. run function evercraft:milestones/unlock/advance_to {tier:"4"}
execute if score @s ec.ms_notif_hi matches ..4 if score #ms_target ec.temp matches 5.. run function evercraft:milestones/unlock/advance_to {tier:"5"}
