# Milestone Rarity Unlock — Apply ladder from CURRENT stable DR (shared)
# Run as @s. CONTRACT: @s ec.temp must hold the player's current stable Dream Rate
# (x10 scale) — i.e. the caller just ran dreams/peak/_compute_stable (resync does;
# unlock/check rides the fresh value dreams/peak/update leaves behind).
# Sets ec.ms_unlock BOTH directions: crates RE-LOCK when Dream Rate drops back below
# a milestone (Joseph 2026-06-10 — the unlock is a live gate, not a dr_peak ratchet;
# previously a one-time temp-high left every tier claimable forever).
# Ladder (post 2026-06-05 uncommon-floor fix): 1=uncommon floor (common+uncommon always
# claimable), 2=rare (DR 3.0), 3=ornate (5.0), 4=exquisite (7.0), 5=mythical (10.0).
# The legacy DR-15 tier 6 is retired — nothing gates above mythical (old stored 6s
# re-apply to <=5 on first sync here).
scoreboard players set @s ec.ms_unlock 1
execute if score @s ec.temp matches 30.. run scoreboard players set @s ec.ms_unlock 2
execute if score @s ec.temp matches 50.. run scoreboard players set @s ec.ms_unlock 3
execute if score @s ec.temp matches 70.. run scoreboard players set @s ec.ms_unlock 4
execute if score @s ec.temp matches 100.. run scoreboard players set @s ec.ms_unlock 5
