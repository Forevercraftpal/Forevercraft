scoreboard players set #ms_gate ec.temp 1
