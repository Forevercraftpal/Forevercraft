data modify storage evercraft:notify stage.c set value [{text:"Locked — ",color:"red"},{text:"Exquisite",color:"light_purple",bold:true},{text:" milestones require ",color:"gray"},{text:"7.0 Dream Rate",color:"#E0B0FF",bold:true},{text:".",color:"gray"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
