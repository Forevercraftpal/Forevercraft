# Milestone claim click detection — Adventure (page 12)
# Run as the player with menu open

execute as @e[type=interaction,tag=Adv.JnMsClaim23,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction on target run function evercraft:milestones/claim_click {id:"23",tier:"exquisite"}
execute as @e[type=interaction,tag=Adv.JnMsClaim23,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=Adv.JnMsClaim24,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction on target run function evercraft:milestones/claim_click {id:"24",tier:"ornate"}
execute as @e[type=interaction,tag=Adv.JnMsClaim24,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=Adv.JnMsClaim25,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction on target run function evercraft:milestones/claim_click {id:"25",tier:"exquisite"}
execute as @e[type=interaction,tag=Adv.JnMsClaim25,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=Adv.JnMsClaim26,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction on target run function evercraft:milestones/claim_click {id:"26",tier:"ornate"}
execute as @e[type=interaction,tag=Adv.JnMsClaim26,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction

# ===== INSPECT (left-click = what does this button do?) — gui/inspect pattern 2026-06-11 =====
execute as @e[type=interaction,tag=Adv.JnMsClaim23,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Slot 24 Adventure Milestone",b:"Right-click to claim the slot 24 adventure milestone reward (row 24) — available once your lifetime total reaches it."}
execute as @e[type=interaction,tag=Adv.JnMsClaim23,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=Adv.JnMsClaim24,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Slot 25 Adventure Milestone",b:"Right-click to claim the slot 25 adventure milestone reward (row 25) — available once your lifetime total reaches it."}
execute as @e[type=interaction,tag=Adv.JnMsClaim24,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=Adv.JnMsClaim25,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Slot 26 Adventure Milestone",b:"Right-click to claim the slot 26 adventure milestone reward (row 26) — available once your lifetime total reaches it."}
execute as @e[type=interaction,tag=Adv.JnMsClaim25,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=Adv.JnMsClaim26,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Slot 27 Adventure Milestone",b:"Right-click to claim the slot 27 adventure milestone reward (row 27) — available once your lifetime total reaches it."}
execute as @e[type=interaction,tag=Adv.JnMsClaim26,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack run data remove entity @s attack
