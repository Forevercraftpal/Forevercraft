# === LORE FAMILY — NOTIFY_ARGS LOOKUP MACRO ===
# Args: {id:"<s1..s163>"}
# Run as @s (player). Lore sets are single-stage (completion = stage 1 = the payoff).
#
# Wiring Audit #7 (2026-05-28) F5/AU6-MS.4: routes per-id set_name lookup, then dispatches
# `notify_lore_set` with rich-format args. Per-id set-name lookup queued as AU7-MS.5
# in 10-pending — for now the id is shown directly so the player at least knows which lore set.

$function evercraft:milestones/notify_lore_set {id:"$(id)",set_name:"Lore Set $(id)"}
