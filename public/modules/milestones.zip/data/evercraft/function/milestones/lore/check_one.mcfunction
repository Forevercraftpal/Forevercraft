# === CHECK ONE LORE SET COMPLETION ===
# Args: {id:"s1", score:"ec.ls_1", th:6}
# Increments @s ec.claim_lore if set complete and unclaimed.
#
# Stage-cross notification via unified milestones/notify_stage helper.
# Sentinel: advancement `evercraft:notif/lore/<id>_1` granted BEFORE tellraw.
# Lore is single-stage (set complete = stage 1) — use stage_5 helper for the loud announce
# since completing a lore set is the rare/payoff event.
#
# PRIME MODE (#ms_prime ec.temp == 1): one-time silent sentinel backfill (milestones/prime). When
# set, the crossed-threshold line GRANTS notif/lore/<id>_1 directly (no notify, no tellraw/sound).
# ec.claim_lore accumulator skipped via #ms_scan_only. NEVER touches claim/*. Idempotent.

# Wiring Audit #7 (2026-05-28): F1 race fix — `add` gated on #ms_scan_only=0;
# notify uses per-family notify_args lookup for rich-format `{set_name}` thread-through.
$execute if score @s $(score) matches $(th).. unless score #ms_scan_only ec.temp matches 1 unless entity @s[advancements={evercraft:claim/lore/$(id)_1=true}] run scoreboard players add @s ec.claim_lore 1
$execute if score @s $(score) matches $(th).. unless score #ms_prime ec.temp matches 1 unless entity @s[advancements={evercraft:notif/lore/$(id)_1=true}] run function evercraft:milestones/lore/notify_args {id:"$(id)"}
$execute if score @s $(score) matches $(th).. if score #ms_prime ec.temp matches 1 run advancement grant @s only evercraft:notif/lore/$(id)_1
