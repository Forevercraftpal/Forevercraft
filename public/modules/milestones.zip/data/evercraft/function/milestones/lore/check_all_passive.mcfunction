# Lore Set — Passive Completion-Check Scheduler (Plan C extension)
# Mirrors personal/check_all_passive. Runs every 60s with a 30s offset.

execute unless entity @a run return run schedule function evercraft:milestones/lore/check_all_passive 60s replace

# Wiring Audit #7 (2026-05-28): scan-only — check_one skips ec.claim_lore accumulator;
# only notify_lore_set fires from here. check_unclaimed is canonical writer.
scoreboard players set #ms_scan_only ec.temp 1
execute as @a[tag=ec.joined] at @s run function evercraft:milestones/lore/check_all
scoreboard players set #ms_scan_only ec.temp 0

schedule function evercraft:milestones/lore/check_all_passive 60s replace
