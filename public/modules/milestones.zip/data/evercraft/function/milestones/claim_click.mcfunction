# Milestone Claim Click — Bridge from interaction entity to player (macro)
# Args: {id:"X", tier:"Y"}
# Run as: the interaction entity

data remove entity @s interaction
scoreboard players operation #gui_click_sess ec.temp = @s adv.gui_session
$execute as @a[distance=..10] if score @s adv.gui_session = #gui_click_sess ec.temp at @s run function evercraft:milestones/claim {id:"$(id)",tier:"$(tier)"}
