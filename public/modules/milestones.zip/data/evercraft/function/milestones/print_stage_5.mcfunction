# Rich milestone-completion line — Stage 5 / payoff (macro).
# Input: storage evercraft:milestones msgin = {name,stage,req,reward,coins,tier,...}. Run as @s.
# Action-bar frames (chat→action-bar migration): called only under the ms_stage dispatch
# gate (notify_stage_5:17, after the #notif_show_ms_stage early-return). Leading/trailing ""
# spacers dropped; indents stripped; ✦/✓/⚔ ornaments §4-mirrored. Playsounds preserved.
$data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"MILESTONE MASTERED: ",color:"gold",bold:true},{text:"$(name)",color:"yellow",bold:true},{text:" ✦",color:"gold"}]
scoreboard players set #ndur ec.temp 50
function evercraft:util/notify/emit_keep
$data modify storage evercraft:notify stage.c set value [{text:"✓ ",color:"dark_aqua"},{text:"$(req)",color:"white"},{text:" ✓",color:"dark_aqua"}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit
$data modify storage evercraft:notify stage.c set value [{text:"⚔ ",color:"#FFB000"},{text:"Final reward: ",color:"dark_gray"},{text:"$(reward)",color:"green",bold:true},{text:"  — every stage complete!",color:"gold"},{text:" ⚔",color:"#FFB000"}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.player.levelup master @s ~ ~ ~ 0.6 1.3
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.5 1.2
