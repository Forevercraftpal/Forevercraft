# Rich milestone-completion line — stages 1-4 (macro).
# Input: storage evercraft:milestones msgin = {name,stage,req,reward,coins,tier,id,next}. Run as @s.
# Mirrors the bulk-claim copy so completing a milestone reads the same as claiming it.
# Action-bar frames (chat→action-bar migration): called only under the ms_stage dispatch
# gate (notify_stage:30, after the #notif_show_ms_stage early-return), so each emit is
# already approved. Leading "" spacer dropped; indents stripped; ★/✓/⚔ ornaments §4-mirrored;
# the directional → "Next" arrow dropped per §4 (Wave-3 precedent).
$data modify storage evercraft:notify stage.c set value [{text:"★ ",color:"#E0B0FF"},{text:"Milestone reached: ",color:"#E0B0FF",bold:true},{text:"$(name)",color:"yellow",bold:true},{text:"  ($(stage))",color:"white"},{text:" ★",color:"#E0B0FF"}]
scoreboard players set #ndur ec.temp 50
function evercraft:util/notify/emit_keep
$data modify storage evercraft:notify stage.c set value [{text:"✓ ",color:"dark_aqua"},{text:"$(req)",color:"white"},{text:" ✓",color:"dark_aqua"}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit
$data modify storage evercraft:notify stage.c set value [{text:"⚔ ",color:"#FFB000"},{text:"Reward: ",color:"dark_gray"},{text:"$(reward)",color:"green",bold:true},{text:" ⚔",color:"#FFB000"}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit
# "Next" only if the next stage actually exists in the registry (milestones vary in stage count).
# Stage + #ndur set unconditionally (inert until the gated emit fires — Wave-1 precedent).
$data modify storage evercraft:notify stage.c set value [{text:"Next: Stage $(next)",color:"gray"}]
scoreboard players set #ndur ec.temp 40
$execute if data storage evercraft:milestones reg.$(id)_$(next) run function evercraft:util/notify/emit
