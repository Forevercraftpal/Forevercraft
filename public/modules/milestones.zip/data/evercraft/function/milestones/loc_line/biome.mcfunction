# Claim-location breadcrumb for biome-mastery milestones (completion message tail). Run as @s.
# Action-bar frame (chat→action-bar migration): called only under the ms_stage gate (notify_stage:31).
# Leading indent dropped; » are mid-text separators (not leading ornaments), left as-is.
data modify storage evercraft:notify stage.c set value [{text:"Claim at: ",color:"gray"},{text:"Codex » Travel Journal » Biomes",color:"#E0B0FF",bold:true}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit
