# Claim-location breadcrumb for lore-set milestones (completion message tail). Run as @s.
# Action-bar frame (chat→action-bar migration): called only under the ms_stage gate
# (notify_stage:31 / notify_lore_set:18). Leading indent dropped; » mid-text separators left as-is.
data modify storage evercraft:notify stage.c set value [{text:"Claim at: ",color:"gray"},{text:"Codex » Lore Discovery",color:"#E0B0FF",bold:true}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit
