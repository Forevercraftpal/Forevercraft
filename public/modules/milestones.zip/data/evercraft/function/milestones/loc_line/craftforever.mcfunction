# Claim-location breadcrumb for craftforever milestones (completion message tail). Run as @s.
# Craftforever claims live in the separate Craftforever Codex book (cross-book — pointer, not a jump).
# Action-bar frame (chat→action-bar migration): called only under the ms_stage gate (notify_stage:31).
# Leading indent dropped; » are mid-text separators (not leading ornaments), left as-is.
data modify storage evercraft:notify stage.c set value [{text:"Claim in your ",color:"gray"},{text:"Craftforever Codex » Milestones",color:"#E0B0FF",bold:true}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit
