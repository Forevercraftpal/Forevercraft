# === MILESTONE NOTIF RE-PRIME — ALL online players, 1t after every load (2026-06-07/08) ===
# On every /reload, silently re-grant the notif sentinel for every already-crossed milestone for
# every online player, BEFORE the loud passive scanners run (scheduled 15s+; this is 1t). This is
# what stops the "milestones keep announcing old progress" bug: notif sentinels can be cleared on a
# reload (advancement-file change) and the loud scanner would otherwise re-announce everything
# already earned. milestones/prime is now UNCONDITIONAL (no once-ever gate), so calling it per
# online player here re-silences all already-earned milestones each reload. Idempotent + cheap
# (once per reload, not per tick). New mid-session crossings still announce loud.
execute unless entity @a[tag=ec.joined] run return 0
execute as @a[tag=ec.joined] at @s run function evercraft:milestones/prime
