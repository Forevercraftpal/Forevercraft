# === MILESTONE SENTINEL PRIME — one-time silent backfill (2026-06-03) ===
# Run as @s = player, from dreams/on_join (the per-player first-join / reconnect / reload hook).
#
# WHY: the 2026-05-26 migration (scoreboard-sentinels → advancement-sentinels at
# evercraft:notif/<family>/<id>_<stage>) deleted the OLD scoreboard sentinels but did NOT backfill
# the NEW advancement sentinels for thresholds a player had ALREADY crossed. The notif/* sentinel
# is only set as a SIDE EFFECT of announcing (inside notify_stage / notify_stage_5 / notify_lore_set),
# so after the migration every player's notif/* set started empty. The 60s passive scanners
# (milestones/<family>/check_all_passive) then saw every already-crossed threshold as un-announced
# and re-announced one family per scan — Joseph's "random idle milestone toasts for old progress".
#
# FIX: on first join, run check_all for all 4 families in PRIME MODE (#ms_prime=1). In that mode
# check_one GRANTS the notif/<family>/<id>_<stage> sentinel directly (no notify function, no
# tellraw, no sound) for every threshold the player already meets. After this, only genuinely-NEW
# crossings announce. New players (all counters 0) prime nothing and get every future toast.
#
# IDEMPOTENT: gated on the per-player notif/primed advancement (impossible-trigger flag, parented
# to evercraft:notif/root like every other notif sentinel). Runs exactly once per player; survives
# /reload + relog because the flag is a persistent advancement. Re-granting an already-held notif/*
# advancement is a no-op, so even if the gate were somehow bypassed the pass stays safe.
#
# CLAIM-SAFE: prime only ever touches notif/* (the announce-suppression sentinel). It NEVER touches
# claim/* — a player can still CLAIM every reward they earned. The #ms_scan_only=1 flag (also set)
# keeps the ec.claim_* accumulators untouched too (check_unclaimed remains the canonical writer).
#
# RESET ON WIPE: admin/strip_player_zero does `advancement revoke @s from evercraft:notif/root`,
# which revokes notif/primed along with every sentinel — so a wiped/Pioneer player re-primes once.

# UNCONDITIONAL (2026-06-08): runs the silent sentinel-backfill on EVERY call (join via
# dreams/on_join, reload via reprime_online). NO once-ever gate — the old `notif/primed2` gate
# meant a milestone crossed AFTER the first-ever prime (or a sentinel cleared by a reload) never
# got silently re-sentineled, so it re-announced loud on the next scan = the "constant false
# milestone toasts" bug. The silent `advancement grant` is idempotent (re-granting a held sentinel
# is a no-op), so running this every join/reload is safe + cheap. Genuinely-NEW mid-session
# crossings still announce loud (they aren't sentineled yet when crossed); the next join/reload
# silences them.
#
# Enter prime + scan-only mode. scan_only stops the ec.claim_* accumulators (check_unclaimed is
# the canonical writer); prime swaps every notify line for a silent `advancement grant`.
scoreboard players set #ms_scan_only ec.temp 1
scoreboard players set #ms_prime ec.temp 1

function evercraft:milestones/personal/check_all
function evercraft:milestones/lore/check_all
function evercraft:milestones/biome/check_all
function evercraft:milestones/craftforever/check_all

# Leave prime + scan-only mode (same convention the passive scanners use).
scoreboard players set #ms_prime ec.temp 0
scoreboard players set #ms_scan_only ec.temp 0
