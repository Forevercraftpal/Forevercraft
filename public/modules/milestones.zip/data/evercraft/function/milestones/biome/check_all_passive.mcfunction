# Biome Mastery — Passive Stage-Check Scheduler (Plan C extension)
# Mirrors personal/check_all_passive. Runs every 60s with a 15s offset so the four families
# don't all fire on the same tick.

execute unless entity @a run return run schedule function evercraft:milestones/biome/check_all_passive 60s replace

# Wiring Audit #7 (2026-05-28): scan-only mode — check_one skips ec.claim_biome accumulator;
# only stage-cross notify_stage fires. check_unclaimed is canonical writer.
scoreboard players set #ms_scan_only ec.temp 1
execute as @a[tag=ec.joined] at @s run function evercraft:milestones/biome/check_all
scoreboard players set #ms_scan_only ec.temp 0

schedule function evercraft:milestones/biome/check_all_passive 60s replace
