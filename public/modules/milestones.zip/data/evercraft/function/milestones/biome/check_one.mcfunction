# === CHECK ONE BIOME MASTERY ===
# Args: {id:"b0", score:"ec.bm0", t1:1800, t2:7200, t3:21600, t4:54000, t5:108000}
# Increments @s ec.claim_biome for each unclaimed stage reached.
#
# Stage-cross notifications via unified milestones/notify_stage helper.
# Sentinel: advancement `evercraft:notif/biome/<id>_<stage>` granted BEFORE tellraw.
#
# PRIME MODE (#ms_prime ec.temp == 1): one-time silent sentinel backfill (milestones/prime). When
# set, crossed-threshold lines GRANT the notif sentinel directly (no notify, no tellraw/sound).
# ec.claim_biome accumulator skipped via #ms_scan_only. NEVER touches claim/*. Idempotent.

# Wiring Audit #7 (2026-05-28): F2 end-game early-return. (Stage-5-claimed players already hold
# every notif sentinel, so priming them is a no-op anyway.)
$execute if entity @s[advancements={evercraft:claim/biome/$(id)_5=true}] run return 0

# Zero #ms_val FIRST: if the player has no tracked entry for $(score) (e.g. after a Pioneer
# wipe — strip_player_zero's `scoreboard players reset @s` removes the entry, and not every
# milestone score is re-set to 0), `scoreboard players get` FAILS and `store result` leaves
# #ms_val holding the PREVIOUS milestone's value → false stage-cross notifications spray for
# milestones the player never earned. Initializing to 0 makes a missing entry read as 0 progress.
# (Joseph 2026-06-04: false "Mansion's Secrets / Warden's Legacy" biome milestones after Pioneer death.)
scoreboard players set #ms_val ec.temp 0
$execute store result score #ms_val ec.temp run scoreboard players get @s $(score)

# Stage 1 — claim counter + stage-cross notification
# `add ec.claim_biome` gated on #ms_scan_only=0 (Wiring Audit #7 race fix).
$execute if score #ms_val ec.temp matches $(t1).. unless score #ms_scan_only ec.temp matches 1 unless entity @s[advancements={evercraft:claim/biome/$(id)_1=true}] run scoreboard players add @s ec.claim_biome 1
$execute if score #ms_val ec.temp matches $(t1).. unless score #ms_prime ec.temp matches 1 unless entity @s[advancements={evercraft:notif/biome/$(id)_1=true}] run function evercraft:milestones/biome/notify_args {id:"$(id)",stage_num:"1"}
$execute if score #ms_val ec.temp matches $(t1).. if score #ms_prime ec.temp matches 1 run advancement grant @s only evercraft:notif/biome/$(id)_1

# Stage 2
$execute if score #ms_val ec.temp matches $(t2).. unless score #ms_scan_only ec.temp matches 1 unless entity @s[advancements={evercraft:claim/biome/$(id)_2=true}] run scoreboard players add @s ec.claim_biome 1
$execute if score #ms_val ec.temp matches $(t2).. unless score #ms_prime ec.temp matches 1 unless entity @s[advancements={evercraft:notif/biome/$(id)_2=true}] run function evercraft:milestones/biome/notify_args {id:"$(id)",stage_num:"2"}
$execute if score #ms_val ec.temp matches $(t2).. if score #ms_prime ec.temp matches 1 run advancement grant @s only evercraft:notif/biome/$(id)_2

# Stage 3
$execute if score #ms_val ec.temp matches $(t3).. unless score #ms_scan_only ec.temp matches 1 unless entity @s[advancements={evercraft:claim/biome/$(id)_3=true}] run scoreboard players add @s ec.claim_biome 1
$execute if score #ms_val ec.temp matches $(t3).. unless score #ms_prime ec.temp matches 1 unless entity @s[advancements={evercraft:notif/biome/$(id)_3=true}] run function evercraft:milestones/biome/notify_args {id:"$(id)",stage_num:"3"}
$execute if score #ms_val ec.temp matches $(t3).. if score #ms_prime ec.temp matches 1 run advancement grant @s only evercraft:notif/biome/$(id)_3

# Stage 4
$execute if score #ms_val ec.temp matches $(t4).. unless score #ms_scan_only ec.temp matches 1 unless entity @s[advancements={evercraft:claim/biome/$(id)_4=true}] run scoreboard players add @s ec.claim_biome 1
$execute if score #ms_val ec.temp matches $(t4).. unless score #ms_prime ec.temp matches 1 unless entity @s[advancements={evercraft:notif/biome/$(id)_4=true}] run function evercraft:milestones/biome/notify_args {id:"$(id)",stage_num:"4"}
$execute if score #ms_val ec.temp matches $(t4).. if score #ms_prime ec.temp matches 1 run advancement grant @s only evercraft:notif/biome/$(id)_4

# Stage 5 (rare/payoff)
$execute if score #ms_val ec.temp matches $(t5).. unless score #ms_scan_only ec.temp matches 1 unless entity @s[advancements={evercraft:claim/biome/$(id)_5=true}] run scoreboard players add @s ec.claim_biome 1
$execute if score #ms_val ec.temp matches $(t5).. unless score #ms_prime ec.temp matches 1 unless entity @s[advancements={evercraft:notif/biome/$(id)_5=true}] run function evercraft:milestones/biome/notify_args_5 {id:"$(id)"}
$execute if score #ms_val ec.temp matches $(t5).. if score #ms_prime ec.temp matches 1 run advancement grant @s only evercraft:notif/biome/$(id)_5
