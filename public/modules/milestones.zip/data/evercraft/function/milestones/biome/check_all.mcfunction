# === CHECK ALL BIOME MASTERY STAGES ===
# Increments ec.claim_biome for each unclaimed mastery stage

# Plains
function evercraft:milestones/biome/check_one {id:"b0",score:"ec.bm0",t1:1800,t2:5400,t3:14400,t4:28800,t5:54000}
# Forest
function evercraft:milestones/biome/check_one {id:"b1",score:"ec.bm1",t1:1800,t2:5400,t3:14400,t4:28800,t5:54000}
# Flower Forest
function evercraft:milestones/biome/check_one {id:"b2",score:"ec.bm2",t1:1800,t2:5400,t3:14400,t4:28800,t5:54000}
# Dark Forest
function evercraft:milestones/biome/check_one {id:"b3",score:"ec.bm3",t1:1800,t2:5400,t3:14400,t4:28800,t5:54000}
# Taiga
function evercraft:milestones/biome/check_one {id:"b4",score:"ec.bm4",t1:1800,t2:5400,t3:14400,t4:28800,t5:54000}
# Mountain
function evercraft:milestones/biome/check_one {id:"b5",score:"ec.bm5",t1:1800,t2:5400,t3:14400,t4:28800,t5:54000}
# Jungle
function evercraft:milestones/biome/check_one {id:"b6",score:"ec.bm6",t1:1800,t2:5400,t3:14400,t4:28800,t5:54000}
# Desert
function evercraft:milestones/biome/check_one {id:"b7",score:"ec.bm7",t1:1800,t2:5400,t3:14400,t4:28800,t5:54000}
# Savanna
function evercraft:milestones/biome/check_one {id:"b8",score:"ec.bm8",t1:1800,t2:5400,t3:14400,t4:28800,t5:54000}
# Ocean
function evercraft:milestones/biome/check_one {id:"b9",score:"ec.bm9",t1:1800,t2:5400,t3:14400,t4:28800,t5:54000}
# River
function evercraft:milestones/biome/check_one {id:"b10",score:"ec.bm10",t1:1800,t2:5400,t3:14400,t4:28800,t5:54000}
# Swamp
function evercraft:milestones/biome/check_one {id:"b11",score:"ec.bm11",t1:1800,t2:5400,t3:14400,t4:28800,t5:54000}
# Mushroom Island
function evercraft:milestones/biome/check_one {id:"b12",score:"ec.bm12",t1:1800,t2:5400,t3:14400,t4:28800,t5:54000}
# Ice
function evercraft:milestones/biome/check_one {id:"b13",score:"ec.bm13",t1:1800,t2:5400,t3:14400,t4:28800,t5:54000}
# Badlands
function evercraft:milestones/biome/check_one {id:"b14",score:"ec.bm14",t1:1800,t2:5400,t3:14400,t4:28800,t5:54000}
# Lush Caves
function evercraft:milestones/biome/check_one {id:"b15",score:"ec.bm15",t1:1800,t2:5400,t3:14400,t4:28800,t5:54000}
# Dripstone Caves
function evercraft:milestones/biome/check_one {id:"b16",score:"ec.bm16",t1:1800,t2:5400,t3:14400,t4:28800,t5:54000}
# Deep Dark
function evercraft:milestones/biome/check_one {id:"b17",score:"ec.bm17",t1:1800,t2:5400,t3:14400,t4:28800,t5:54000}
# Nether Wastes
function evercraft:milestones/biome/check_one {id:"b18",score:"ec.bm18",t1:1800,t2:5400,t3:14400,t4:28800,t5:54000}
# Crimson Forest
function evercraft:milestones/biome/check_one {id:"b19",score:"ec.bm19",t1:1800,t2:5400,t3:14400,t4:28800,t5:54000}
# Warped Forest
function evercraft:milestones/biome/check_one {id:"b20",score:"ec.bm20",t1:1800,t2:5400,t3:14400,t4:28800,t5:54000}
# Basalt Deltas
function evercraft:milestones/biome/check_one {id:"b21",score:"ec.bm21",t1:1800,t2:5400,t3:14400,t4:28800,t5:54000}
# Soul Sand Valley
function evercraft:milestones/biome/check_one {id:"b22",score:"ec.bm22",t1:1800,t2:5400,t3:14400,t4:28800,t5:54000}
# The End
function evercraft:milestones/biome/check_one {id:"b23",score:"ec.bm23",t1:1800,t2:5400,t3:14400,t4:28800,t5:54000}
# Windswept Hills
function evercraft:milestones/biome/check_one {id:"b24",score:"ec.bm24",t1:1800,t2:5400,t3:14400,t4:28800,t5:54000}
