# === BIOME FAMILY — NOTIFY_ARGS LOOKUP MACRO ===
# Args: {id:"<b0..b24>", stage_num:"1..4"}
# Run as @s (player). Biome stages are uniform 1800/7200/21600/54000/108000 ticks.
#
# Wiring Audit #7 (2026-05-28) F5/AU6-MS.4: routes per-id name/tier/req lookup, then dispatches
# `notify_stage` with rich-format args. Per-id biome-name lookup queued as AU7-MS.5.
# Tier ladder for stages 1-4: Common / Uncommon / Rare / Ornate (biome ladder is 1 lower than personal).

$scoreboard players set #ms_stage_num_lookup ec.temp $(stage_num)

$execute if score #ms_stage_num_lookup ec.temp matches 1 run function evercraft:milestones/notify_stage {family:"biome",id:"$(id)",stage_num:"1",name:"Biome Mastery $(id)",tier:"Common",req:"2.5h in biome"}
$execute if score #ms_stage_num_lookup ec.temp matches 2 run function evercraft:milestones/notify_stage {family:"biome",id:"$(id)",stage_num:"2",name:"Biome Mastery $(id)",tier:"Uncommon",req:"10h in biome"}
$execute if score #ms_stage_num_lookup ec.temp matches 3 run function evercraft:milestones/notify_stage {family:"biome",id:"$(id)",stage_num:"3",name:"Biome Mastery $(id)",tier:"Rare",req:"30h in biome"}
$execute if score #ms_stage_num_lookup ec.temp matches 4 run function evercraft:milestones/notify_stage {family:"biome",id:"$(id)",stage_num:"4",name:"Biome Mastery $(id)",tier:"Ornate",req:"~3 days in biome"}
