# === BIOME FAMILY — NOTIFY_ARGS_5 LOOKUP MACRO ===
# Args: {id:"<b0..b24>"}
# Run as @s (player). Biome stage 5 = Exquisite-tier.
#
# Wiring Audit #7 (2026-05-28) F5/AU6-MS.4: stage-5 rich notify. Per-id biome-name lookup queued
# as AU7-MS.5 in 10-pending.

$function evercraft:milestones/notify_stage_5 {family:"biome",id:"$(id)",name:"Biome Mastery $(id)",tier:"Exquisite",req:"~1 week in biome"}
