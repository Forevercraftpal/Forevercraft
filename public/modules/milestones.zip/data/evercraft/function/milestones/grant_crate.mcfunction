# === MILESTONE CRATE GRANT — mode-gated (Joseph 2026-06-06) ===
# Usage: function evercraft:milestones/grant_crate {tier:"rare"}   (run AS the receiving player)
# Drop-in replacement for util/give_quest_crate on MILESTONE claim paths only.
# Coins are added by the CALLER (not here) — only the CRATE is mode-gated, so coins always land.
#   Adventurer (ec.difficulty 2): no Uncommon crate.
#   Pioneer    (ec.difficulty 3, explicit one-life mode): no Rare crate.
#   Newcomer (1), Unchosen (0), and every other tier: crate granted as normal.
$data modify storage evercraft:milestones gc_tier set value "$(tier)"
# Adventurer: no Uncommon crate — coins only. Action-bar note (self-overwriting, so a bulk Claim-All never spams).
data modify storage evercraft:notify stage.c set value [{text:"No crate on Adventurer mode — coins only",color:"gray"}]
scoreboard players set #ndur ec.temp 45
execute if score @s ec.difficulty matches 2 if data storage evercraft:milestones {gc_tier:"uncommon"} run function evercraft:util/notify/emit
execute if score @s ec.difficulty matches 2 if data storage evercraft:milestones {gc_tier:"uncommon"} run return 0
# Pioneer: no Rare crate — coins only.
data modify storage evercraft:notify stage.c set value [{text:"No crate on Pioneer mode — coins only",color:"gray"}]
scoreboard players set #ndur ec.temp 45
execute if score @s ec.difficulty matches 3 if data storage evercraft:milestones {gc_tier:"rare"} run function evercraft:util/notify/emit
execute if score @s ec.difficulty matches 3 if data storage evercraft:milestones {gc_tier:"rare"} run return 0
$function evercraft:util/give_quest_crate {tier:"$(tier)"}
