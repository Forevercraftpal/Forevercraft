# Milestone Stage 5 (Final / Payoff) — Unified
# Args: {family, id, name, tier, req}
# Run as @s. Fires loudly regardless of per-key mute (class:alert still respects ec.notify=2).
# Rich copy read from the completion registry (storage evercraft:milestones reg.<id>_5),
# the same name / requirement / reward(+coins) the bulk-claim screen shows.
# CRITICAL: grant sentinel BEFORE tellraw; clear→set→consume msgin in one synchronous chain.

$advancement grant @s only evercraft:notif/$(family)/$(id)_5

function evercraft:util/notify/dispatch {key:"ms_stage",class:"alert",mute_at:99}
execute if score #notif_show_ms_stage ec.temp matches 0 run return 0

data remove storage evercraft:milestones msgin
$data modify storage evercraft:milestones msgin set from storage evercraft:milestones reg.$(id)_5

# Rich path (registry hit): full payoff frame + claim-location.
execute if data storage evercraft:milestones msgin.name run function evercraft:milestones/print_stage_5 with storage evercraft:milestones msgin
$execute if data storage evercraft:milestones msgin.name run function evercraft:milestones/loc_line/$(family)

# Fallback (registry miss): terse payoff line — never crashes the macro.
# Action-bar frame (chat→action-bar migration): leading "" spacer + indent dropped, ✦ §4-mirrored,
# the [$(tier)] rarity bracket dropped per §4b (light_purple color carries the tier). Staged
# unconditionally, emit gated on the registry-miss branch (inert when the rich path took over).
$data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"Milestone mastered: ",color:"gold",bold:true},{text:"$(name)",color:"yellow",bold:true},{text:" — Stage 5 ",color:"white"},{text:"$(tier)",color:"light_purple",bold:true},{text:" ✦",color:"gold"}]
scoreboard players set #ndur ec.temp 45
execute unless data storage evercraft:milestones msgin.name run function evercraft:util/notify/emit_keep
