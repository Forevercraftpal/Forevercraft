# === REGISTRY: craftforever (99 stage-entries) — generated, do not hand-edit ===
data modify storage evercraft:milestones reg.c1_1 set value {name:"Master Chef",stage:"1/5",req:"Cook 25 meals",reward:"Uncommon Crate + 5 coins",coins:5,tier:"uncommon"}
data modify storage evercraft:milestones reg.c1_2 set value {name:"Master Chef",stage:"2/5",req:"Cook 75 meals",reward:"Rare Crate + 10 coins",coins:10,tier:"rare"}
data modify storage evercraft:milestones reg.c1_3 set value {name:"Master Chef",stage:"3/5",req:"Cook 200 meals",reward:"Ornate Crate + 20 coins",coins:20,tier:"ornate"}
data modify storage evercraft:milestones reg.c1_4 set value {name:"Master Chef",stage:"4/5",req:"Cook 400 meals",reward:"Exquisite Crate + 35 coins",coins:35,tier:"exquisite"}
data modify storage evercraft:milestones reg.c1_5 set value {name:"Master Chef",stage:"5/5",req:"Cook 750 meals",reward:"Mythical Crate + 50 coins",coins:50,tier:"mythical"}
data modify storage evercraft:milestones reg.c2_1 set value {name:"Combat Chef",stage:"1/5",req:"Cook 10 combat meals",reward:"Uncommon Crate + 5 coins",coins:5,tier:"uncommon"}
data modify storage evercraft:milestones reg.c2_2 set value {name:"Combat Chef",stage:"2/5",req:"Cook 30 combat meals",reward:"Rare Crate + 10 coins",coins:10,tier:"rare"}
data modify storage evercraft:milestones reg.c2_3 set value {name:"Combat Chef",stage:"3/5",req:"Cook 60 combat meals",reward:"Ornate Crate + 20 coins",coins:20,tier:"ornate"}
data modify storage evercraft:milestones reg.c2_4 set value {name:"Combat Chef",stage:"4/5",req:"Cook 100 combat meals",reward:"Exquisite Crate + 35 coins",coins:35,tier:"exquisite"}
data modify storage evercraft:milestones reg.c2_5 set value {name:"Combat Chef",stage:"5/5",req:"Cook 150 combat meals",reward:"Mythical Crate + 50 coins",coins:50,tier:"mythical"}
data modify storage evercraft:milestones reg.c3_1 set value {name:"Mining Chef",stage:"1/5",req:"Cook 10 mining meals",reward:"Uncommon Crate + 5 coins",coins:5,tier:"uncommon"}
data modify storage evercraft:milestones reg.c3_2 set value {name:"Mining Chef",stage:"2/5",req:"Cook 30 mining meals",reward:"Rare Crate + 10 coins",coins:10,tier:"rare"}
data modify storage evercraft:milestones reg.c3_3 set value {name:"Mining Chef",stage:"3/5",req:"Cook 60 mining meals",reward:"Ornate Crate + 20 coins",coins:20,tier:"ornate"}
data modify storage evercraft:milestones reg.c3_4 set value {name:"Mining Chef",stage:"4/5",req:"Cook 100 mining meals",reward:"Exquisite Crate + 35 coins",coins:35,tier:"exquisite"}
data modify storage evercraft:milestones reg.c3_5 set value {name:"Mining Chef",stage:"5/5",req:"Cook 150 mining meals",reward:"Mythical Crate + 50 coins",coins:50,tier:"mythical"}
data modify storage evercraft:milestones reg.c4_1 set value {name:"Fortune Chef",stage:"1/5",req:"Cook 10 fortune meals",reward:"Uncommon Crate + 5 coins",coins:5,tier:"uncommon"}
data modify storage evercraft:milestones reg.c4_2 set value {name:"Fortune Chef",stage:"2/5",req:"Cook 30 fortune meals",reward:"Rare Crate + 10 coins",coins:10,tier:"rare"}
data modify storage evercraft:milestones reg.c4_3 set value {name:"Fortune Chef",stage:"3/5",req:"Cook 60 fortune meals",reward:"Ornate Crate + 20 coins",coins:20,tier:"ornate"}
data modify storage evercraft:milestones reg.c4_4 set value {name:"Fortune Chef",stage:"4/5",req:"Cook 100 fortune meals",reward:"Exquisite Crate + 35 coins",coins:35,tier:"exquisite"}
data modify storage evercraft:milestones reg.c4_5 set value {name:"Fortune Chef",stage:"5/5",req:"Cook 150 fortune meals",reward:"Mythical Crate + 50 coins",coins:50,tier:"mythical"}
data modify storage evercraft:milestones reg.c5_1 set value {name:"Recipe Hunter",stage:"1/5",req:"Learn 10 recipes",reward:"Uncommon Crate + 5 coins",coins:5,tier:"uncommon"}
data modify storage evercraft:milestones reg.c5_2 set value {name:"Recipe Hunter",stage:"2/5",req:"Learn 20 recipes",reward:"Rare Crate + 10 coins",coins:10,tier:"rare"}
data modify storage evercraft:milestones reg.c5_3 set value {name:"Recipe Hunter",stage:"3/5",req:"Learn 30 recipes",reward:"Ornate Crate + 20 coins",coins:20,tier:"ornate"}
data modify storage evercraft:milestones reg.c5_4 set value {name:"Recipe Hunter",stage:"4/5",req:"Learn 35 recipes",reward:"Exquisite Crate + 35 coins",coins:35,tier:"exquisite"}
data modify storage evercraft:milestones reg.c5_5 set value {name:"Recipe Hunter",stage:"5/5",req:"Learn 42 recipes",reward:"Mythical Crate + 50 coins",coins:50,tier:"mythical"}
data modify storage evercraft:milestones reg.c6_1 set value {name:"Trial Champion",stage:"1/5",req:"Complete 10 trials",reward:"Uncommon Crate + 5 coins",coins:5,tier:"uncommon"}
data modify storage evercraft:milestones reg.c6_2 set value {name:"Trial Champion",stage:"2/5",req:"Complete 30 trials",reward:"Rare Crate + 10 coins",coins:10,tier:"rare"}
data modify storage evercraft:milestones reg.c6_3 set value {name:"Trial Champion",stage:"3/5",req:"Complete 60 trials",reward:"Ornate Crate + 20 coins",coins:20,tier:"ornate"}
data modify storage evercraft:milestones reg.c6_4 set value {name:"Trial Champion",stage:"4/5",req:"Complete 100 trials",reward:"Exquisite Crate + 35 coins",coins:35,tier:"exquisite"}
data modify storage evercraft:milestones reg.c6_5 set value {name:"Trial Champion",stage:"5/5",req:"Complete 200 trials",reward:"Mythical Crate + 50 coins",coins:50,tier:"mythical"}
data modify storage evercraft:milestones reg.c7_1 set value {name:"Artisan Rank",stage:"1/5",req:"Reach rank 20",reward:"Uncommon Crate + 5 coins",coins:5,tier:"uncommon"}
data modify storage evercraft:milestones reg.c7_2 set value {name:"Artisan Rank",stage:"2/5",req:"Reach rank 40",reward:"Rare Crate + 10 coins",coins:10,tier:"rare"}
data modify storage evercraft:milestones reg.c7_3 set value {name:"Artisan Rank",stage:"3/5",req:"Reach rank 60",reward:"Ornate Crate + 20 coins",coins:20,tier:"ornate"}
data modify storage evercraft:milestones reg.c7_4 set value {name:"Artisan Rank",stage:"4/5",req:"Reach rank 80",reward:"Exquisite Crate + 35 coins",coins:35,tier:"exquisite"}
data modify storage evercraft:milestones reg.c7_5 set value {name:"Artisan Rank",stage:"5/5",req:"Reach rank 100",reward:"Mythical Crate + 50 coins",coins:50,tier:"mythical"}
data modify storage evercraft:milestones reg.c8_1 set value {name:"Master Forger",stage:"1/5",req:"Forge 25 items",reward:"Uncommon Crate + 5 coins",coins:5,tier:"uncommon"}
data modify storage evercraft:milestones reg.c8_2 set value {name:"Master Forger",stage:"2/5",req:"Forge 75 items",reward:"Rare Crate + 10 coins",coins:10,tier:"rare"}
data modify storage evercraft:milestones reg.c8_3 set value {name:"Master Forger",stage:"3/5",req:"Forge 200 items",reward:"Ornate Crate + 20 coins",coins:20,tier:"ornate"}
data modify storage evercraft:milestones reg.c8_4 set value {name:"Master Forger",stage:"4/5",req:"Forge 400 items",reward:"Exquisite Crate + 35 coins",coins:35,tier:"exquisite"}
data modify storage evercraft:milestones reg.c8_5 set value {name:"Master Forger",stage:"5/5",req:"Forge 750 items",reward:"Mythical Crate + 50 coins",coins:50,tier:"mythical"}
data modify storage evercraft:milestones reg.c9_1 set value {name:"Spirit Toolsmith",stage:"1/4",req:"Craft 1 spirit tools",reward:"Rare Crate + 10 coins",coins:10,tier:"rare"}
data modify storage evercraft:milestones reg.c9_2 set value {name:"Spirit Toolsmith",stage:"2/4",req:"Craft 3 spirit tools",reward:"Ornate Crate + 20 coins",coins:20,tier:"ornate"}
data modify storage evercraft:milestones reg.c9_3 set value {name:"Spirit Toolsmith",stage:"3/4",req:"Craft 5 spirit tools",reward:"Exquisite Crate + 35 coins",coins:35,tier:"exquisite"}
data modify storage evercraft:milestones reg.c9_4 set value {name:"Spirit Toolsmith",stage:"4/4",req:"Craft 6 spirit tools",reward:"Mythical Crate + 50 coins",coins:50,tier:"mythical"}
data modify storage evercraft:milestones reg.c10_1 set value {name:"Material Collector",stage:"1/5",req:"Collect 3 unique materials",reward:"Uncommon Crate + 5 coins",coins:5,tier:"uncommon"}
data modify storage evercraft:milestones reg.c10_2 set value {name:"Material Collector",stage:"2/5",req:"Collect 6 unique materials",reward:"Rare Crate + 10 coins",coins:10,tier:"rare"}
data modify storage evercraft:milestones reg.c10_3 set value {name:"Material Collector",stage:"3/5",req:"Collect 9 unique materials",reward:"Ornate Crate + 20 coins",coins:20,tier:"ornate"}
data modify storage evercraft:milestones reg.c10_4 set value {name:"Material Collector",stage:"4/5",req:"Collect 12 unique materials",reward:"Exquisite Crate + 35 coins",coins:35,tier:"exquisite"}
data modify storage evercraft:milestones reg.c10_5 set value {name:"Material Collector",stage:"5/5",req:"Collect 15 unique materials",reward:"Mythical Crate + 50 coins",coins:50,tier:"mythical"}
data modify storage evercraft:milestones reg.c11_1 set value {name:"Biome Node Hunter",stage:"1/5",req:"Find 3 biome nodes",reward:"Uncommon Crate + 5 coins",coins:5,tier:"uncommon"}
data modify storage evercraft:milestones reg.c11_2 set value {name:"Biome Node Hunter",stage:"2/5",req:"Find 7 biome nodes",reward:"Rare Crate + 10 coins",coins:10,tier:"rare"}
data modify storage evercraft:milestones reg.c11_3 set value {name:"Biome Node Hunter",stage:"3/5",req:"Find 10 biome nodes",reward:"Ornate Crate + 20 coins",coins:20,tier:"ornate"}
data modify storage evercraft:milestones reg.c11_4 set value {name:"Biome Node Hunter",stage:"4/5",req:"Find 13 biome nodes",reward:"Exquisite Crate + 35 coins",coins:35,tier:"exquisite"}
data modify storage evercraft:milestones reg.c11_5 set value {name:"Biome Node Hunter",stage:"5/5",req:"Find 15 biome nodes",reward:"Mythical Crate + 50 coins",coins:50,tier:"mythical"}
data modify storage evercraft:milestones reg.c12_1 set value {name:"Pantry Hoarder",stage:"1/5",req:"Store 50 pantry items",reward:"Uncommon Crate + 5 coins",coins:5,tier:"uncommon"}
data modify storage evercraft:milestones reg.c12_2 set value {name:"Pantry Hoarder",stage:"2/5",req:"Store 200 pantry items",reward:"Rare Crate + 10 coins",coins:10,tier:"rare"}
data modify storage evercraft:milestones reg.c12_3 set value {name:"Pantry Hoarder",stage:"3/5",req:"Store 500 pantry items",reward:"Ornate Crate + 20 coins",coins:20,tier:"ornate"}
data modify storage evercraft:milestones reg.c12_4 set value {name:"Pantry Hoarder",stage:"4/5",req:"Store 1K pantry items",reward:"Exquisite Crate + 35 coins",coins:35,tier:"exquisite"}
data modify storage evercraft:milestones reg.c12_5 set value {name:"Pantry Hoarder",stage:"5/5",req:"Store 2K pantry items",reward:"Mythical Crate + 50 coins",coins:50,tier:"mythical"}
data modify storage evercraft:milestones reg.c13_1 set value {name:"Mining Master",stage:"1/5",req:"Reach mining tier 2",reward:"Uncommon Crate + 5 coins",coins:5,tier:"uncommon"}
data modify storage evercraft:milestones reg.c13_2 set value {name:"Mining Master",stage:"2/5",req:"Reach mining tier 4",reward:"Rare Crate + 10 coins",coins:10,tier:"rare"}
data modify storage evercraft:milestones reg.c13_3 set value {name:"Mining Master",stage:"3/5",req:"Reach mining tier 6",reward:"Ornate Crate + 20 coins",coins:20,tier:"ornate"}
data modify storage evercraft:milestones reg.c13_4 set value {name:"Mining Master",stage:"4/5",req:"Reach mining tier 8",reward:"Exquisite Crate + 35 coins",coins:35,tier:"exquisite"}
data modify storage evercraft:milestones reg.c13_5 set value {name:"Mining Master",stage:"5/5",req:"Reach mining tier 10",reward:"Mythical Crate + 50 coins",coins:50,tier:"mythical"}
data modify storage evercraft:milestones reg.c14_1 set value {name:"Harvest Lord",stage:"1/5",req:"Reach harvest tier 2",reward:"Uncommon Crate + 5 coins",coins:5,tier:"uncommon"}
data modify storage evercraft:milestones reg.c14_2 set value {name:"Harvest Lord",stage:"2/5",req:"Reach harvest tier 4",reward:"Rare Crate + 10 coins",coins:10,tier:"rare"}
data modify storage evercraft:milestones reg.c14_3 set value {name:"Harvest Lord",stage:"3/5",req:"Reach harvest tier 6",reward:"Ornate Crate + 20 coins",coins:20,tier:"ornate"}
data modify storage evercraft:milestones reg.c14_4 set value {name:"Harvest Lord",stage:"4/5",req:"Reach harvest tier 8",reward:"Exquisite Crate + 35 coins",coins:35,tier:"exquisite"}
data modify storage evercraft:milestones reg.c14_5 set value {name:"Harvest Lord",stage:"5/5",req:"Reach harvest tier 10",reward:"Mythical Crate + 50 coins",coins:50,tier:"mythical"}
data modify storage evercraft:milestones reg.c15_1 set value {name:"Master Angler",stage:"1/5",req:"Reach fishing tier 2",reward:"Uncommon Crate + 5 coins",coins:5,tier:"uncommon"}
data modify storage evercraft:milestones reg.c15_2 set value {name:"Master Angler",stage:"2/5",req:"Reach fishing tier 4",reward:"Rare Crate + 10 coins",coins:10,tier:"rare"}
data modify storage evercraft:milestones reg.c15_3 set value {name:"Master Angler",stage:"3/5",req:"Reach fishing tier 6",reward:"Ornate Crate + 20 coins",coins:20,tier:"ornate"}
data modify storage evercraft:milestones reg.c15_4 set value {name:"Master Angler",stage:"4/5",req:"Reach fishing tier 8",reward:"Exquisite Crate + 35 coins",coins:35,tier:"exquisite"}
data modify storage evercraft:milestones reg.c15_5 set value {name:"Master Angler",stage:"5/5",req:"Reach fishing tier 10",reward:"Mythical Crate + 50 coins",coins:50,tier:"mythical"}
data modify storage evercraft:milestones reg.c16_1 set value {name:"Grand Architect",stage:"1/5",req:"Reach building tier 2",reward:"Uncommon Crate + 5 coins",coins:5,tier:"uncommon"}
data modify storage evercraft:milestones reg.c16_2 set value {name:"Grand Architect",stage:"2/5",req:"Reach building tier 4",reward:"Rare Crate + 10 coins",coins:10,tier:"rare"}
data modify storage evercraft:milestones reg.c16_3 set value {name:"Grand Architect",stage:"3/5",req:"Reach building tier 6",reward:"Ornate Crate + 20 coins",coins:20,tier:"ornate"}
data modify storage evercraft:milestones reg.c16_4 set value {name:"Grand Architect",stage:"4/5",req:"Reach building tier 8",reward:"Exquisite Crate + 35 coins",coins:35,tier:"exquisite"}
data modify storage evercraft:milestones reg.c16_5 set value {name:"Grand Architect",stage:"5/5",req:"Reach building tier 10",reward:"Mythical Crate + 50 coins",coins:50,tier:"mythical"}
data modify storage evercraft:milestones reg.c17_1 set value {name:"Lumberjack Legend",stage:"1/5",req:"Reach lumberjack tier 2",reward:"Uncommon Crate + 5 coins",coins:5,tier:"uncommon"}
data modify storage evercraft:milestones reg.c17_2 set value {name:"Lumberjack Legend",stage:"2/5",req:"Reach lumberjack tier 4",reward:"Rare Crate + 10 coins",coins:10,tier:"rare"}
data modify storage evercraft:milestones reg.c17_3 set value {name:"Lumberjack Legend",stage:"3/5",req:"Reach lumberjack tier 6",reward:"Ornate Crate + 20 coins",coins:20,tier:"ornate"}
data modify storage evercraft:milestones reg.c17_4 set value {name:"Lumberjack Legend",stage:"4/5",req:"Reach lumberjack tier 8",reward:"Exquisite Crate + 35 coins",coins:35,tier:"exquisite"}
data modify storage evercraft:milestones reg.c17_5 set value {name:"Lumberjack Legend",stage:"5/5",req:"Reach lumberjack tier 10",reward:"Mythical Crate + 50 coins",coins:50,tier:"mythical"}
data modify storage evercraft:milestones reg.c18_1 set value {name:"Artisan Supreme",stage:"1/5",req:"Reach artisan tier 2",reward:"Uncommon Crate + 5 coins",coins:5,tier:"uncommon"}
data modify storage evercraft:milestones reg.c18_2 set value {name:"Artisan Supreme",stage:"2/5",req:"Reach artisan tier 4",reward:"Rare Crate + 10 coins",coins:10,tier:"rare"}
data modify storage evercraft:milestones reg.c18_3 set value {name:"Artisan Supreme",stage:"3/5",req:"Reach artisan tier 6",reward:"Ornate Crate + 20 coins",coins:20,tier:"ornate"}
data modify storage evercraft:milestones reg.c18_4 set value {name:"Artisan Supreme",stage:"4/5",req:"Reach artisan tier 8",reward:"Exquisite Crate + 35 coins",coins:35,tier:"exquisite"}
data modify storage evercraft:milestones reg.c18_5 set value {name:"Artisan Supreme",stage:"5/5",req:"Reach artisan tier 10",reward:"Mythical Crate + 50 coins",coins:50,tier:"mythical"}
data modify storage evercraft:milestones reg.c19_1 set value {name:"Grand Master",stage:"1/5",req:"Master 1 trial categories",reward:"Uncommon Crate + 5 coins",coins:5,tier:"uncommon"}
data modify storage evercraft:milestones reg.c19_2 set value {name:"Grand Master",stage:"2/5",req:"Master 2 trial categories",reward:"Rare Crate + 10 coins",coins:10,tier:"rare"}
data modify storage evercraft:milestones reg.c19_3 set value {name:"Grand Master",stage:"3/5",req:"Master 4 trial categories",reward:"Ornate Crate + 20 coins",coins:20,tier:"ornate"}
data modify storage evercraft:milestones reg.c19_4 set value {name:"Grand Master",stage:"4/5",req:"Master 5 trial categories",reward:"Exquisite Crate + 35 coins",coins:35,tier:"exquisite"}
data modify storage evercraft:milestones reg.c19_5 set value {name:"Grand Master",stage:"5/5",req:"Master 6 trial categories",reward:"Mythical Crate + 50 coins",coins:50,tier:"mythical"}
data modify storage evercraft:milestones reg.c20_1 set value {name:"Speedy Finish",stage:"1/5",req:"Speed clear 1 trials",reward:"Uncommon Crate + 5 coins",coins:5,tier:"uncommon"}
data modify storage evercraft:milestones reg.c20_2 set value {name:"Speedy Finish",stage:"2/5",req:"Speed clear 5 trials",reward:"Rare Crate + 10 coins",coins:10,tier:"rare"}
data modify storage evercraft:milestones reg.c20_3 set value {name:"Speedy Finish",stage:"3/5",req:"Speed clear 15 trials",reward:"Ornate Crate + 20 coins",coins:20,tier:"ornate"}
data modify storage evercraft:milestones reg.c20_4 set value {name:"Speedy Finish",stage:"4/5",req:"Speed clear 30 trials",reward:"Exquisite Crate + 35 coins",coins:35,tier:"exquisite"}
data modify storage evercraft:milestones reg.c20_5 set value {name:"Speedy Finish",stage:"5/5",req:"Speed clear 60 trials",reward:"Mythical Crate + 50 coins",coins:50,tier:"mythical"}
