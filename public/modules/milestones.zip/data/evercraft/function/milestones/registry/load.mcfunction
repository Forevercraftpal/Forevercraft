# === MILESTONE COMPLETION REGISTRY — LOAD (generated) ===
# Source of truth: claim/bulk_claim_personal_stages, bulk_claim_biome, bulk_claim_lore, bulk_claim_craftforever
# Generated 2026-05-30 by the milestone-claim-nav build. DO NOT hand-edit the load_<family> files;
# regenerate from the bulk tables. Coin values are slated for a per-effort polish pass (see 10-pending).
# Populates storage evercraft:milestones reg.<id> = {name,stage,req,reward,coins,tier}
data modify storage evercraft:milestones reg set value {}
function evercraft:milestones/registry/load_personal
function evercraft:milestones/registry/load_biome
function evercraft:milestones/registry/load_lore
function evercraft:milestones/registry/load_craftforever
