# === REGISTRY: biome (125 stage-entries) — generated, do not hand-edit ===
data modify storage evercraft:milestones reg.b0_1 set value {name:"Plains",stage:"1/5",req:"Explore Plains 2.5h",reward:"5 coins",coins:5,tier:"common"}
data modify storage evercraft:milestones reg.b0_2 set value {name:"Plains",stage:"2/5",req:"Explore Plains 7.5h",reward:"10 coins",coins:10,tier:"uncommon"}
data modify storage evercraft:milestones reg.b0_3 set value {name:"Plains",stage:"3/5",req:"Explore Plains 20h",reward:"20 coins",coins:20,tier:"rare"}
data modify storage evercraft:milestones reg.b0_4 set value {name:"Plains",stage:"4/5",req:"Explore Plains 40h",reward:"Ornate Crate + 35 coins",coins:35,tier:"ornate"}
data modify storage evercraft:milestones reg.b0_5 set value {name:"Plains",stage:"5/5",req:"Explore Plains 75h",reward:"Exquisite Crate + 50 coins",coins:50,tier:"exquisite"}
data modify storage evercraft:milestones reg.b1_1 set value {name:"Forest",stage:"1/5",req:"Explore Forest 2.5h",reward:"5 coins",coins:5,tier:"common"}
data modify storage evercraft:milestones reg.b1_2 set value {name:"Forest",stage:"2/5",req:"Explore Forest 7.5h",reward:"10 coins",coins:10,tier:"uncommon"}
data modify storage evercraft:milestones reg.b1_3 set value {name:"Forest",stage:"3/5",req:"Explore Forest 20h",reward:"20 coins",coins:20,tier:"rare"}
data modify storage evercraft:milestones reg.b1_4 set value {name:"Forest",stage:"4/5",req:"Explore Forest 40h",reward:"Ornate Crate + 35 coins",coins:35,tier:"ornate"}
data modify storage evercraft:milestones reg.b1_5 set value {name:"Forest",stage:"5/5",req:"Explore Forest 75h",reward:"Exquisite Crate + 50 coins",coins:50,tier:"exquisite"}
data modify storage evercraft:milestones reg.b2_1 set value {name:"Flower Forest",stage:"1/5",req:"Explore Flower Forest 2.5h",reward:"5 coins",coins:5,tier:"common"}
data modify storage evercraft:milestones reg.b2_2 set value {name:"Flower Forest",stage:"2/5",req:"Explore Flower Forest 7.5h",reward:"10 coins",coins:10,tier:"uncommon"}
data modify storage evercraft:milestones reg.b2_3 set value {name:"Flower Forest",stage:"3/5",req:"Explore Flower Forest 20h",reward:"20 coins",coins:20,tier:"rare"}
data modify storage evercraft:milestones reg.b2_4 set value {name:"Flower Forest",stage:"4/5",req:"Explore Flower Forest 40h",reward:"Ornate Crate + 35 coins",coins:35,tier:"ornate"}
data modify storage evercraft:milestones reg.b2_5 set value {name:"Flower Forest",stage:"5/5",req:"Explore Flower Forest 75h",reward:"Exquisite Crate + 50 coins",coins:50,tier:"exquisite"}
data modify storage evercraft:milestones reg.b3_1 set value {name:"Dark Forest",stage:"1/5",req:"Explore Dark Forest 2.5h",reward:"5 coins",coins:5,tier:"common"}
data modify storage evercraft:milestones reg.b3_2 set value {name:"Dark Forest",stage:"2/5",req:"Explore Dark Forest 7.5h",reward:"10 coins",coins:10,tier:"uncommon"}
data modify storage evercraft:milestones reg.b3_3 set value {name:"Dark Forest",stage:"3/5",req:"Explore Dark Forest 20h",reward:"20 coins",coins:20,tier:"rare"}
data modify storage evercraft:milestones reg.b3_4 set value {name:"Dark Forest",stage:"4/5",req:"Explore Dark Forest 40h",reward:"Ornate Crate + 35 coins",coins:35,tier:"ornate"}
data modify storage evercraft:milestones reg.b3_5 set value {name:"Dark Forest",stage:"5/5",req:"Explore Dark Forest 75h",reward:"Exquisite Crate + 50 coins",coins:50,tier:"exquisite"}
data modify storage evercraft:milestones reg.b4_1 set value {name:"Taiga",stage:"1/5",req:"Explore Taiga 2.5h",reward:"5 coins",coins:5,tier:"common"}
data modify storage evercraft:milestones reg.b4_2 set value {name:"Taiga",stage:"2/5",req:"Explore Taiga 7.5h",reward:"10 coins",coins:10,tier:"uncommon"}
data modify storage evercraft:milestones reg.b4_3 set value {name:"Taiga",stage:"3/5",req:"Explore Taiga 20h",reward:"20 coins",coins:20,tier:"rare"}
data modify storage evercraft:milestones reg.b4_4 set value {name:"Taiga",stage:"4/5",req:"Explore Taiga 40h",reward:"Ornate Crate + 35 coins",coins:35,tier:"ornate"}
data modify storage evercraft:milestones reg.b4_5 set value {name:"Taiga",stage:"5/5",req:"Explore Taiga 75h",reward:"Exquisite Crate + 50 coins",coins:50,tier:"exquisite"}
data modify storage evercraft:milestones reg.b5_1 set value {name:"Mountain",stage:"1/5",req:"Explore Mountain 2.5h",reward:"5 coins",coins:5,tier:"common"}
data modify storage evercraft:milestones reg.b5_2 set value {name:"Mountain",stage:"2/5",req:"Explore Mountain 7.5h",reward:"10 coins",coins:10,tier:"uncommon"}
data modify storage evercraft:milestones reg.b5_3 set value {name:"Mountain",stage:"3/5",req:"Explore Mountain 20h",reward:"20 coins",coins:20,tier:"rare"}
data modify storage evercraft:milestones reg.b5_4 set value {name:"Mountain",stage:"4/5",req:"Explore Mountain 40h",reward:"Ornate Crate + 35 coins",coins:35,tier:"ornate"}
data modify storage evercraft:milestones reg.b5_5 set value {name:"Mountain",stage:"5/5",req:"Explore Mountain 75h",reward:"Exquisite Crate + 50 coins",coins:50,tier:"exquisite"}
data modify storage evercraft:milestones reg.b6_1 set value {name:"Jungle",stage:"1/5",req:"Explore Jungle 2.5h",reward:"5 coins",coins:5,tier:"common"}
data modify storage evercraft:milestones reg.b6_2 set value {name:"Jungle",stage:"2/5",req:"Explore Jungle 7.5h",reward:"10 coins",coins:10,tier:"uncommon"}
data modify storage evercraft:milestones reg.b6_3 set value {name:"Jungle",stage:"3/5",req:"Explore Jungle 20h",reward:"20 coins",coins:20,tier:"rare"}
data modify storage evercraft:milestones reg.b6_4 set value {name:"Jungle",stage:"4/5",req:"Explore Jungle 40h",reward:"Ornate Crate + 35 coins",coins:35,tier:"ornate"}
data modify storage evercraft:milestones reg.b6_5 set value {name:"Jungle",stage:"5/5",req:"Explore Jungle 75h",reward:"Exquisite Crate + 50 coins",coins:50,tier:"exquisite"}
data modify storage evercraft:milestones reg.b7_1 set value {name:"Desert",stage:"1/5",req:"Explore Desert 2.5h",reward:"5 coins",coins:5,tier:"common"}
data modify storage evercraft:milestones reg.b7_2 set value {name:"Desert",stage:"2/5",req:"Explore Desert 7.5h",reward:"10 coins",coins:10,tier:"uncommon"}
data modify storage evercraft:milestones reg.b7_3 set value {name:"Desert",stage:"3/5",req:"Explore Desert 20h",reward:"20 coins",coins:20,tier:"rare"}
data modify storage evercraft:milestones reg.b7_4 set value {name:"Desert",stage:"4/5",req:"Explore Desert 40h",reward:"Ornate Crate + 35 coins",coins:35,tier:"ornate"}
data modify storage evercraft:milestones reg.b7_5 set value {name:"Desert",stage:"5/5",req:"Explore Desert 75h",reward:"Exquisite Crate + 50 coins",coins:50,tier:"exquisite"}
data modify storage evercraft:milestones reg.b8_1 set value {name:"Savanna",stage:"1/5",req:"Explore Savanna 2.5h",reward:"5 coins",coins:5,tier:"common"}
data modify storage evercraft:milestones reg.b8_2 set value {name:"Savanna",stage:"2/5",req:"Explore Savanna 7.5h",reward:"10 coins",coins:10,tier:"uncommon"}
data modify storage evercraft:milestones reg.b8_3 set value {name:"Savanna",stage:"3/5",req:"Explore Savanna 20h",reward:"20 coins",coins:20,tier:"rare"}
data modify storage evercraft:milestones reg.b8_4 set value {name:"Savanna",stage:"4/5",req:"Explore Savanna 40h",reward:"Ornate Crate + 35 coins",coins:35,tier:"ornate"}
data modify storage evercraft:milestones reg.b8_5 set value {name:"Savanna",stage:"5/5",req:"Explore Savanna 75h",reward:"Exquisite Crate + 50 coins",coins:50,tier:"exquisite"}
data modify storage evercraft:milestones reg.b9_1 set value {name:"Ocean",stage:"1/5",req:"Explore Ocean 2.5h",reward:"5 coins",coins:5,tier:"common"}
data modify storage evercraft:milestones reg.b9_2 set value {name:"Ocean",stage:"2/5",req:"Explore Ocean 7.5h",reward:"10 coins",coins:10,tier:"uncommon"}
data modify storage evercraft:milestones reg.b9_3 set value {name:"Ocean",stage:"3/5",req:"Explore Ocean 20h",reward:"20 coins",coins:20,tier:"rare"}
data modify storage evercraft:milestones reg.b9_4 set value {name:"Ocean",stage:"4/5",req:"Explore Ocean 40h",reward:"Ornate Crate + 35 coins",coins:35,tier:"ornate"}
data modify storage evercraft:milestones reg.b9_5 set value {name:"Ocean",stage:"5/5",req:"Explore Ocean 75h",reward:"Exquisite Crate + 50 coins",coins:50,tier:"exquisite"}
data modify storage evercraft:milestones reg.b10_1 set value {name:"River",stage:"1/5",req:"Explore River 2.5h",reward:"5 coins",coins:5,tier:"common"}
data modify storage evercraft:milestones reg.b10_2 set value {name:"River",stage:"2/5",req:"Explore River 7.5h",reward:"10 coins",coins:10,tier:"uncommon"}
data modify storage evercraft:milestones reg.b10_3 set value {name:"River",stage:"3/5",req:"Explore River 20h",reward:"20 coins",coins:20,tier:"rare"}
data modify storage evercraft:milestones reg.b10_4 set value {name:"River",stage:"4/5",req:"Explore River 40h",reward:"Ornate Crate + 35 coins",coins:35,tier:"ornate"}
data modify storage evercraft:milestones reg.b10_5 set value {name:"River",stage:"5/5",req:"Explore River 75h",reward:"Exquisite Crate + 50 coins",coins:50,tier:"exquisite"}
data modify storage evercraft:milestones reg.b11_1 set value {name:"Swamp",stage:"1/5",req:"Explore Swamp 2.5h",reward:"5 coins",coins:5,tier:"common"}
data modify storage evercraft:milestones reg.b11_2 set value {name:"Swamp",stage:"2/5",req:"Explore Swamp 7.5h",reward:"10 coins",coins:10,tier:"uncommon"}
data modify storage evercraft:milestones reg.b11_3 set value {name:"Swamp",stage:"3/5",req:"Explore Swamp 20h",reward:"20 coins",coins:20,tier:"rare"}
data modify storage evercraft:milestones reg.b11_4 set value {name:"Swamp",stage:"4/5",req:"Explore Swamp 40h",reward:"Ornate Crate + 35 coins",coins:35,tier:"ornate"}
data modify storage evercraft:milestones reg.b11_5 set value {name:"Swamp",stage:"5/5",req:"Explore Swamp 75h",reward:"Exquisite Crate + 50 coins",coins:50,tier:"exquisite"}
data modify storage evercraft:milestones reg.b12_1 set value {name:"Mushroom Island",stage:"1/5",req:"Explore Mushroom Island 2.5h",reward:"5 coins",coins:5,tier:"common"}
data modify storage evercraft:milestones reg.b12_2 set value {name:"Mushroom Island",stage:"2/5",req:"Explore Mushroom Island 7.5h",reward:"10 coins",coins:10,tier:"uncommon"}
data modify storage evercraft:milestones reg.b12_3 set value {name:"Mushroom Island",stage:"3/5",req:"Explore Mushroom Island 20h",reward:"20 coins",coins:20,tier:"rare"}
data modify storage evercraft:milestones reg.b12_4 set value {name:"Mushroom Island",stage:"4/5",req:"Explore Mushroom Island 40h",reward:"Ornate Crate + 35 coins",coins:35,tier:"ornate"}
data modify storage evercraft:milestones reg.b12_5 set value {name:"Mushroom Island",stage:"5/5",req:"Explore Mushroom Island 75h",reward:"Exquisite Crate + 50 coins",coins:50,tier:"exquisite"}
data modify storage evercraft:milestones reg.b13_1 set value {name:"Ice",stage:"1/5",req:"Explore Ice 2.5h",reward:"5 coins",coins:5,tier:"common"}
data modify storage evercraft:milestones reg.b13_2 set value {name:"Ice",stage:"2/5",req:"Explore Ice 7.5h",reward:"10 coins",coins:10,tier:"uncommon"}
data modify storage evercraft:milestones reg.b13_3 set value {name:"Ice",stage:"3/5",req:"Explore Ice 20h",reward:"20 coins",coins:20,tier:"rare"}
data modify storage evercraft:milestones reg.b13_4 set value {name:"Ice",stage:"4/5",req:"Explore Ice 40h",reward:"Ornate Crate + 35 coins",coins:35,tier:"ornate"}
data modify storage evercraft:milestones reg.b13_5 set value {name:"Ice",stage:"5/5",req:"Explore Ice 75h",reward:"Exquisite Crate + 50 coins",coins:50,tier:"exquisite"}
data modify storage evercraft:milestones reg.b14_1 set value {name:"Badlands",stage:"1/5",req:"Explore Badlands 2.5h",reward:"5 coins",coins:5,tier:"common"}
data modify storage evercraft:milestones reg.b14_2 set value {name:"Badlands",stage:"2/5",req:"Explore Badlands 7.5h",reward:"10 coins",coins:10,tier:"uncommon"}
data modify storage evercraft:milestones reg.b14_3 set value {name:"Badlands",stage:"3/5",req:"Explore Badlands 20h",reward:"20 coins",coins:20,tier:"rare"}
data modify storage evercraft:milestones reg.b14_4 set value {name:"Badlands",stage:"4/5",req:"Explore Badlands 40h",reward:"Ornate Crate + 35 coins",coins:35,tier:"ornate"}
data modify storage evercraft:milestones reg.b14_5 set value {name:"Badlands",stage:"5/5",req:"Explore Badlands 75h",reward:"Exquisite Crate + 50 coins",coins:50,tier:"exquisite"}
data modify storage evercraft:milestones reg.b15_1 set value {name:"Lush Caves",stage:"1/5",req:"Explore Lush Caves 2.5h",reward:"5 coins",coins:5,tier:"common"}
data modify storage evercraft:milestones reg.b15_2 set value {name:"Lush Caves",stage:"2/5",req:"Explore Lush Caves 7.5h",reward:"10 coins",coins:10,tier:"uncommon"}
data modify storage evercraft:milestones reg.b15_3 set value {name:"Lush Caves",stage:"3/5",req:"Explore Lush Caves 20h",reward:"20 coins",coins:20,tier:"rare"}
data modify storage evercraft:milestones reg.b15_4 set value {name:"Lush Caves",stage:"4/5",req:"Explore Lush Caves 40h",reward:"Ornate Crate + 35 coins",coins:35,tier:"ornate"}
data modify storage evercraft:milestones reg.b15_5 set value {name:"Lush Caves",stage:"5/5",req:"Explore Lush Caves 75h",reward:"Exquisite Crate + 50 coins",coins:50,tier:"exquisite"}
data modify storage evercraft:milestones reg.b16_1 set value {name:"Dripstone Caves",stage:"1/5",req:"Explore Dripstone Caves 2.5h",reward:"5 coins",coins:5,tier:"common"}
data modify storage evercraft:milestones reg.b16_2 set value {name:"Dripstone Caves",stage:"2/5",req:"Explore Dripstone Caves 7.5h",reward:"10 coins",coins:10,tier:"uncommon"}
data modify storage evercraft:milestones reg.b16_3 set value {name:"Dripstone Caves",stage:"3/5",req:"Explore Dripstone Caves 20h",reward:"20 coins",coins:20,tier:"rare"}
data modify storage evercraft:milestones reg.b16_4 set value {name:"Dripstone Caves",stage:"4/5",req:"Explore Dripstone Caves 40h",reward:"Ornate Crate + 35 coins",coins:35,tier:"ornate"}
data modify storage evercraft:milestones reg.b16_5 set value {name:"Dripstone Caves",stage:"5/5",req:"Explore Dripstone Caves 75h",reward:"Exquisite Crate + 50 coins",coins:50,tier:"exquisite"}
data modify storage evercraft:milestones reg.b17_1 set value {name:"Deep Dark",stage:"1/5",req:"Explore Deep Dark 2.5h",reward:"5 coins",coins:5,tier:"common"}
data modify storage evercraft:milestones reg.b17_2 set value {name:"Deep Dark",stage:"2/5",req:"Explore Deep Dark 7.5h",reward:"10 coins",coins:10,tier:"uncommon"}
data modify storage evercraft:milestones reg.b17_3 set value {name:"Deep Dark",stage:"3/5",req:"Explore Deep Dark 20h",reward:"20 coins",coins:20,tier:"rare"}
data modify storage evercraft:milestones reg.b17_4 set value {name:"Deep Dark",stage:"4/5",req:"Explore Deep Dark 40h",reward:"Ornate Crate + 35 coins",coins:35,tier:"ornate"}
data modify storage evercraft:milestones reg.b17_5 set value {name:"Deep Dark",stage:"5/5",req:"Explore Deep Dark 75h",reward:"Exquisite Crate + 50 coins",coins:50,tier:"exquisite"}
data modify storage evercraft:milestones reg.b18_1 set value {name:"Nether Wastes",stage:"1/5",req:"Explore Nether Wastes 2.5h",reward:"5 coins",coins:5,tier:"common"}
data modify storage evercraft:milestones reg.b18_2 set value {name:"Nether Wastes",stage:"2/5",req:"Explore Nether Wastes 7.5h",reward:"10 coins",coins:10,tier:"uncommon"}
data modify storage evercraft:milestones reg.b18_3 set value {name:"Nether Wastes",stage:"3/5",req:"Explore Nether Wastes 20h",reward:"20 coins",coins:20,tier:"rare"}
data modify storage evercraft:milestones reg.b18_4 set value {name:"Nether Wastes",stage:"4/5",req:"Explore Nether Wastes 40h",reward:"Ornate Crate + 35 coins",coins:35,tier:"ornate"}
data modify storage evercraft:milestones reg.b18_5 set value {name:"Nether Wastes",stage:"5/5",req:"Explore Nether Wastes 75h",reward:"Exquisite Crate + 50 coins",coins:50,tier:"exquisite"}
data modify storage evercraft:milestones reg.b19_1 set value {name:"Crimson Forest",stage:"1/5",req:"Explore Crimson Forest 2.5h",reward:"5 coins",coins:5,tier:"common"}
data modify storage evercraft:milestones reg.b19_2 set value {name:"Crimson Forest",stage:"2/5",req:"Explore Crimson Forest 7.5h",reward:"10 coins",coins:10,tier:"uncommon"}
data modify storage evercraft:milestones reg.b19_3 set value {name:"Crimson Forest",stage:"3/5",req:"Explore Crimson Forest 20h",reward:"20 coins",coins:20,tier:"rare"}
data modify storage evercraft:milestones reg.b19_4 set value {name:"Crimson Forest",stage:"4/5",req:"Explore Crimson Forest 40h",reward:"Ornate Crate + 35 coins",coins:35,tier:"ornate"}
data modify storage evercraft:milestones reg.b19_5 set value {name:"Crimson Forest",stage:"5/5",req:"Explore Crimson Forest 75h",reward:"Exquisite Crate + 50 coins",coins:50,tier:"exquisite"}
data modify storage evercraft:milestones reg.b20_1 set value {name:"Warped Forest",stage:"1/5",req:"Explore Warped Forest 2.5h",reward:"5 coins",coins:5,tier:"common"}
data modify storage evercraft:milestones reg.b20_2 set value {name:"Warped Forest",stage:"2/5",req:"Explore Warped Forest 7.5h",reward:"10 coins",coins:10,tier:"uncommon"}
data modify storage evercraft:milestones reg.b20_3 set value {name:"Warped Forest",stage:"3/5",req:"Explore Warped Forest 20h",reward:"20 coins",coins:20,tier:"rare"}
data modify storage evercraft:milestones reg.b20_4 set value {name:"Warped Forest",stage:"4/5",req:"Explore Warped Forest 40h",reward:"Ornate Crate + 35 coins",coins:35,tier:"ornate"}
data modify storage evercraft:milestones reg.b20_5 set value {name:"Warped Forest",stage:"5/5",req:"Explore Warped Forest 75h",reward:"Exquisite Crate + 50 coins",coins:50,tier:"exquisite"}
data modify storage evercraft:milestones reg.b21_1 set value {name:"Basalt Deltas",stage:"1/5",req:"Explore Basalt Deltas 2.5h",reward:"5 coins",coins:5,tier:"common"}
data modify storage evercraft:milestones reg.b21_2 set value {name:"Basalt Deltas",stage:"2/5",req:"Explore Basalt Deltas 7.5h",reward:"10 coins",coins:10,tier:"uncommon"}
data modify storage evercraft:milestones reg.b21_3 set value {name:"Basalt Deltas",stage:"3/5",req:"Explore Basalt Deltas 20h",reward:"20 coins",coins:20,tier:"rare"}
data modify storage evercraft:milestones reg.b21_4 set value {name:"Basalt Deltas",stage:"4/5",req:"Explore Basalt Deltas 40h",reward:"Ornate Crate + 35 coins",coins:35,tier:"ornate"}
data modify storage evercraft:milestones reg.b21_5 set value {name:"Basalt Deltas",stage:"5/5",req:"Explore Basalt Deltas 75h",reward:"Exquisite Crate + 50 coins",coins:50,tier:"exquisite"}
data modify storage evercraft:milestones reg.b22_1 set value {name:"Soul Sand Valley",stage:"1/5",req:"Explore Soul Sand Valley 2.5h",reward:"5 coins",coins:5,tier:"common"}
data modify storage evercraft:milestones reg.b22_2 set value {name:"Soul Sand Valley",stage:"2/5",req:"Explore Soul Sand Valley 7.5h",reward:"10 coins",coins:10,tier:"uncommon"}
data modify storage evercraft:milestones reg.b22_3 set value {name:"Soul Sand Valley",stage:"3/5",req:"Explore Soul Sand Valley 20h",reward:"20 coins",coins:20,tier:"rare"}
data modify storage evercraft:milestones reg.b22_4 set value {name:"Soul Sand Valley",stage:"4/5",req:"Explore Soul Sand Valley 40h",reward:"Ornate Crate + 35 coins",coins:35,tier:"ornate"}
data modify storage evercraft:milestones reg.b22_5 set value {name:"Soul Sand Valley",stage:"5/5",req:"Explore Soul Sand Valley 75h",reward:"Exquisite Crate + 50 coins",coins:50,tier:"exquisite"}
data modify storage evercraft:milestones reg.b23_1 set value {name:"The End",stage:"1/5",req:"Explore The End 2.5h",reward:"5 coins",coins:5,tier:"common"}
data modify storage evercraft:milestones reg.b23_2 set value {name:"The End",stage:"2/5",req:"Explore The End 7.5h",reward:"10 coins",coins:10,tier:"uncommon"}
data modify storage evercraft:milestones reg.b23_3 set value {name:"The End",stage:"3/5",req:"Explore The End 20h",reward:"20 coins",coins:20,tier:"rare"}
data modify storage evercraft:milestones reg.b23_4 set value {name:"The End",stage:"4/5",req:"Explore The End 40h",reward:"Ornate Crate + 35 coins",coins:35,tier:"ornate"}
data modify storage evercraft:milestones reg.b23_5 set value {name:"The End",stage:"5/5",req:"Explore The End 75h",reward:"Exquisite Crate + 50 coins",coins:50,tier:"exquisite"}
data modify storage evercraft:milestones reg.b24_1 set value {name:"Windswept Hills",stage:"1/5",req:"Explore Windswept Hills 2.5h",reward:"5 coins",coins:5,tier:"common"}
data modify storage evercraft:milestones reg.b24_2 set value {name:"Windswept Hills",stage:"2/5",req:"Explore Windswept Hills 7.5h",reward:"10 coins",coins:10,tier:"uncommon"}
data modify storage evercraft:milestones reg.b24_3 set value {name:"Windswept Hills",stage:"3/5",req:"Explore Windswept Hills 20h",reward:"20 coins",coins:20,tier:"rare"}
data modify storage evercraft:milestones reg.b24_4 set value {name:"Windswept Hills",stage:"4/5",req:"Explore Windswept Hills 40h",reward:"Ornate Crate + 35 coins",coins:35,tier:"ornate"}
data modify storage evercraft:milestones reg.b24_5 set value {name:"Windswept Hills",stage:"5/5",req:"Explore Windswept Hills 75h",reward:"Exquisite Crate + 50 coins",coins:50,tier:"exquisite"}
