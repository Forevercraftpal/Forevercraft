# === CRAFTFOREVER FAMILY — NOTIFY_ARGS_5 LOOKUP MACRO ===
# Args: {id:"<c1..c20>"}
# Run as @s (player). CF stage 5 = Mythical-tier.
#
# Wiring Audit #7 (2026-05-28) F5/AU6-MS.4: stage-5 rich notify. Per-id name lookup queued
# as AU7-MS.5 in 10-pending.

$function evercraft:milestones/notify_stage_5 {family:"craftforever",id:"$(id)",name:"CraftForever $(id)",tier:"Mythical",req:"Final stage threshold reached"}
