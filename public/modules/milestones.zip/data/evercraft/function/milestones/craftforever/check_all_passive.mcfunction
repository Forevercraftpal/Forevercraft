# Craftforever Milestone — Passive Stage-Check Scheduler (Plan C extension)
# Mirrors personal/check_all_passive. Runs every 60s with a 45s offset.

execute unless entity @a run return run schedule function evercraft:milestones/craftforever/check_all_passive 60s replace

# Wiring Audit #7 (2026-05-28): scan-only — check_all skips the zero; check_one + c10/c11 bit-checks
# skip ec.claim_cft accumulator; only notify_stage fires. check_unclaimed is canonical writer.
scoreboard players set #ms_scan_only ec.temp 1
execute as @a[tag=ec.joined] at @s run function evercraft:milestones/craftforever/check_all
scoreboard players set #ms_scan_only ec.temp 0

schedule function evercraft:milestones/craftforever/check_all_passive 60s replace
