# === CRAFTFOREVER FAMILY — NOTIFY_ARGS LOOKUP MACRO ===
# Args: {id:"<c1..c20>", stage_num:"1..4"}
# Run as @s (player).
#
# Wiring Audit #7 (2026-05-28) F5/AU6-MS.4: routes per-id name/tier/req lookup, then dispatches
# `notify_stage`. Per-id name lookup queued as AU7-MS.5. Tier ladder for stages 1-4: Uncommon /
# Rare / Ornate / Exquisite.

$scoreboard players set #ms_stage_num_lookup ec.temp $(stage_num)

$execute if score #ms_stage_num_lookup ec.temp matches 1 run function evercraft:milestones/notify_stage {family:"craftforever",id:"$(id)",stage_num:"1",name:"CraftForever $(id)",tier:"Uncommon",req:"Threshold reached"}
$execute if score #ms_stage_num_lookup ec.temp matches 2 run function evercraft:milestones/notify_stage {family:"craftforever",id:"$(id)",stage_num:"2",name:"CraftForever $(id)",tier:"Rare",req:"Threshold reached"}
$execute if score #ms_stage_num_lookup ec.temp matches 3 run function evercraft:milestones/notify_stage {family:"craftforever",id:"$(id)",stage_num:"3",name:"CraftForever $(id)",tier:"Ornate",req:"Threshold reached"}
$execute if score #ms_stage_num_lookup ec.temp matches 4 run function evercraft:milestones/notify_stage {family:"craftforever",id:"$(id)",stage_num:"4",name:"CraftForever $(id)",tier:"Exquisite",req:"Threshold reached"}
