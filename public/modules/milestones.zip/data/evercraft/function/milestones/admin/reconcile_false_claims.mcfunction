# === MILESTONE FALSE-CLAIM RECONCILIATION (admin, one-time) ===
# Run as operator. Usage: execute as @a run function evercraft:milestones/admin/reconcile_false_claims
# Cleans up the stale-#ms_val false-claim bug (display/claim fixed 2026-06-07): revokes any
# claim/<family>/<id>_<stage> advancement whose backing score is below that stage's threshold.
# Leaves notif/ sentinels intact. Excludes the 6 advantage-tree counters (reset on prestige).
#
# CAVEAT: chrono-shard reset/milestones_personal zeros milestone counters but does NOT revoke
# claims, so a player who used that endgame reset has legit claims with low scores — this pass
# WILL revoke those. Only run if acceptable, or pre-gate to non-chrono-reset players.
# Run AS a single player (@s); the operator fans out with `execute as @a run ...`.

function evercraft:milestones/admin/reconcile/personal
function evercraft:milestones/admin/reconcile/biome
function evercraft:milestones/admin/reconcile/lore
function evercraft:milestones/admin/reconcile/craftforever

tellraw @s [{text:"[Milestones] ",color:"gold"},{text:"Reconciliation complete — false claims revoked.",color:"gray"}]
