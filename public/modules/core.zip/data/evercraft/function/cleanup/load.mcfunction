# Batch Entity Cleanup — Load
# Bootstrap the 5-second cleanup tick for orphaned/leaked entities
schedule function evercraft:cleanup/tick 100t

# Bootstrap the orphaned-GUI-panel sweep (self-reschedules every 10s)
schedule function evercraft:cleanup/gui_auto 10s replace

# Menu idle timer (held-but-dead floaters) — objective + 1s engine
scoreboard objectives add ec.menu_idle dummy "Menu Idle Seconds"
schedule function evercraft:cleanup/menu_idle 20t replace
