# Auto GUI Cleanup — orphaned-panel sweep (10s)
# Kills LEFTOVER menu panels (session-stamped GUI entities) sitting near a player who is
# NOT in any menu. "Orphan-only" by design: a player actively in a menu carries one of the
# menu-open flags below, so they are skipped and their live panel is never touched.
#
# How orphans are identified (see cleanup/gui_auto_player): menu panels are stamped with a
# positive session score (adv.gui_session + 4 variants) by their open routine. Gameplay
# entities (raid bosses, dungeon markers, nameplates, decor, crates) are NEVER session-stamped,
# so the sweep cannot hit them. The only non-menu session-stamper is the dreamy-pull animation
# (tag DP.El), which is excluded in gui_auto_player.

# Re-schedule
schedule function evercraft:cleanup/gui_auto 10s replace

# Skip if no players online
execute unless entity @a run return 0

# For each player NOT in any menu, with NO menu-using player within 30 blocks (cross-player
# safety — never sweep near someone whose live panels could fall in range), and only when an
# interaction entity (a GUI button — almost never a world entity) is actually nearby, run the
# per-player kill. The interaction-existence gate keeps this near-free in normal play.
#
# Menu-open flags = ec.menu_active (the generic flag set by ~30 menus, and inherited by their
# sub-screens) + the few session-viewers that don't set it (bough/questline-book/tome/key-bag/
# showcase) + a handful of belt-and-suspenders flags. Over-listing here is SAFE (it can only
# skip a cleanup), so the list is deliberately generous.
execute as @a[tag=!ec.menu_active,tag=!ec.bough_viewing,tag=!ec.qln_book,tag=!ec.tome_menu,tag=!ec.ksbag_in_menu,tag=!ec.sc_in_showcase,tag=!FF.InMenu,tag=!ec.lb_placeholder,tag=!DEC.Standalone,tag=!HS.InFurnish,tag=!ec.menu_sneak_open,tag=!h2h.pending_target] at @s unless entity @a[distance=0.1..30,tag=ec.menu_active] unless entity @a[distance=0.1..30,tag=ec.bough_viewing] unless entity @a[distance=0.1..30,tag=ec.qln_book] unless entity @a[distance=0.1..30,tag=ec.tome_menu] unless entity @a[distance=0.1..30,tag=ec.ksbag_in_menu] unless entity @a[distance=0.1..30,tag=ec.sc_in_showcase] unless entity @a[distance=0.1..30,tag=FF.InMenu] unless entity @a[distance=0.1..30,tag=DEC.Standalone] unless entity @a[distance=0.1..30,tag=HS.InFurnish] unless entity @a[distance=0.1..30,tag=h2h.pending_target] if entity @e[type=interaction,distance=..15,limit=1] run function evercraft:cleanup/gui_auto_player
