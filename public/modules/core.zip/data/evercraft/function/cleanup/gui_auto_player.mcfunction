# Auto GUI Cleanup — per-player orphan kill
# Runs `as` a player who holds NO menu-open flag, `at @s`, with no menu-using player within
# 30 blocks (both guaranteed by the caller, cleanup/gui_auto). In that situation ANY menu panel
# within range is a genuine orphan — left by a failed close, a relog, or a dead self-scheduled
# tick — so it is safe to remove without ever touching a live menu.
#
# History: this used to kill a curated tag list filtered by `scores={adv.gui_session=..0}`.
# That filter was inverted — a fully-opened menu stamps its panels with the owner's session
# (>=1), so an orphan from that menu still carries >=1 and was SPARED. Result: most real duds
# survived. We now key off the POSITIVE stamp instead (the reliable "this is a menu panel"
# signal — gameplay entities are never session-stamped), and drop the inner-6m exclusion since
# the caller proves the player is not in any menu.
#
# SAFETY GUARDS on every kill:
#   tag=!smithed.entity — custom-block OVERLAY displays (guidestone, hearthstone, etc.) carry
#     the Smithed library tag; NO menu panel does. This hard-guarantees the sweep can never wipe
#     a custom block even if some future code mistakenly stamped one with a session.
#   tag=!DP.El — the dreamy-pull gacha animation is the only NON-menu reuser of adv.gui_session.

# === Session-stamped panels (covers every menu that stamps a session — the vast majority) ===
# --- adv.gui_session (~28 menus + their sub-screens: codex, cooking, satchels, housing, …) ---
execute as @e[type=text_display,distance=..15,tag=!DP.El,tag=!smithed.entity] if score @s adv.gui_session matches 1.. run kill @s
execute as @e[type=interaction,distance=..15,tag=!DP.El,tag=!smithed.entity] if score @s adv.gui_session matches 1.. run kill @s
execute as @e[type=item_display,distance=..15,tag=!DP.El,tag=!smithed.entity] if score @s adv.gui_session matches 1.. run kill @s
execute as @e[type=block_display,distance=..15,tag=!DP.El,tag=!smithed.entity] if score @s adv.gui_session matches 1.. run kill @s

# --- ec.cf_gui_session (Craftforever Codex) ---
execute as @e[type=text_display,distance=..15,tag=!smithed.entity] if score @s ec.cf_gui_session matches 1.. run kill @s
execute as @e[type=interaction,distance=..15,tag=!smithed.entity] if score @s ec.cf_gui_session matches 1.. run kill @s
execute as @e[type=item_display,distance=..15,tag=!smithed.entity] if score @s ec.cf_gui_session matches 1.. run kill @s

# --- ec.bough_sess (Living Bough class viewer) ---
execute as @e[type=text_display,distance=..15,tag=!smithed.entity] if score @s ec.bough_sess matches 1.. run kill @s
execute as @e[type=interaction,distance=..15,tag=!smithed.entity] if score @s ec.bough_sess matches 1.. run kill @s
execute as @e[type=item_display,distance=..15,tag=!smithed.entity] if score @s ec.bough_sess matches 1.. run kill @s

# --- ec.qln_sess (Questline book) ---
execute as @e[type=text_display,distance=..15,tag=!smithed.entity] if score @s ec.qln_sess matches 1.. run kill @s
execute as @e[type=interaction,distance=..15,tag=!smithed.entity] if score @s ec.qln_sess matches 1.. run kill @s
execute as @e[type=item_display,distance=..15,tag=!smithed.entity] if score @s ec.qln_sess matches 1.. run kill @s

# --- ec.tome_sess (Artisan tome) ---
execute as @e[type=text_display,distance=..15,tag=!smithed.entity] if score @s ec.tome_sess matches 1.. run kill @s
execute as @e[type=interaction,distance=..15,tag=!smithed.entity] if score @s ec.tome_sess matches 1.. run kill @s
execute as @e[type=item_display,distance=..15,tag=!smithed.entity] if score @s ec.tome_sess matches 1.. run kill @s

# === Supplemental: unambiguous menu-panel tags ===
# Catches the few menus that don't stamp a session (e.g. the Bestiary pages) and any stray
# anchor markers. These tags are menu-exclusive (never gameplay entities), and the player is
# proven menu-less + isolated, so a flat tag kill in range is safe. tag=!smithed.entity kept for
# uniform protection of overlay blocks.
kill @e[tag=Bs.PageContent,distance=..15,tag=!smithed.entity]
kill @e[tag=Bs.PageHeader,distance=..15,tag=!smithed.entity]
kill @e[tag=Adv.MenuAnchor,distance=..15,tag=!smithed.entity]
kill @e[tag=CF.MenuAnchor,distance=..15,tag=!smithed.entity]
kill @e[tag=companion.menuanchor,distance=..15,tag=!smithed.entity]
