# Menu Idle Sweep — per-player force-close
# Runs `as` a player whose menu has gone 60s with no interaction, `at @s`.
# Kills only THIS player's own panels by matching their session id (adv.gui_session) — so a
# neighbour's live menu is never touched, regardless of distance. Then strips every menu-open
# flag, which (a) stops the dead menu's central-tick dispatch and (b) makes any panel NOT keyed
# to adv.gui_session (the 4 variant-session menus: CF codex / bough / questline / tome) eligible
# for cleanup/gui_auto, which removes it within ~10s.

# --- Kill this player's adv.gui_session-stamped panels (session-matched = surgical) ---
# tag=!smithed.entity also guards custom-block overlays; tag=!DP.El guards the gacha animation.
scoreboard players operation #midle_owner ec.temp = @s adv.gui_session
execute as @e[type=text_display,distance=..24,tag=!DP.El,tag=!smithed.entity] if score @s adv.gui_session = #midle_owner ec.temp run kill @s
execute as @e[type=interaction,distance=..24,tag=!DP.El,tag=!smithed.entity] if score @s adv.gui_session = #midle_owner ec.temp run kill @s
execute as @e[type=item_display,distance=..24,tag=!DP.El,tag=!smithed.entity] if score @s adv.gui_session = #midle_owner ec.temp run kill @s
execute as @e[type=block_display,distance=..24,tag=!DP.El,tag=!smithed.entity] if score @s adv.gui_session = #midle_owner ec.temp run kill @s

# --- Strip every menu-open flag (mirror reconnect/dispatch) ---
tag @s remove ec.menu_active
tag @s remove ec.menu_sneak_open
tag @s remove companion.inmenuv2
tag @s remove CK.InMenu
tag @s remove DG.InMenu
tag @s remove IC.InMenu
tag @s remove TX.InMenu
tag @s remove RF.InMenu
tag @s remove BM.InMenu
tag @s remove WW.InMenu
tag @s remove TT.InMenu
tag @s remove FF.InMenu
tag @s remove TNK.InMenu
tag @s remove HS.InMenu
tag @s remove HS.InSatchel
tag @s remove HS.InFurnish
tag @s remove DEC.Standalone
tag @s remove ec.guild_in_menu
tag @s remove ec.fsack_in_menu
tag @s remove ec.pantry_in_menu
tag @s remove ec.satchel_in_menu
tag @s remove ec.hsatch_in_menu
tag @s remove ec.orebag_in_menu
tag @s remove ec.fhold_in_menu
tag @s remove ec.binder_in_menu
tag @s remove ec.mule_in_menu
tag @s remove ec.dlpack_in_menu
tag @s remove ec.ksbag_in_menu
tag @s remove ec.gs_in_menu
tag @s remove ec.bough_viewing
tag @s remove ec.qln_book
tag @s remove ec.tome_menu
tag @s remove ec.sc_in_showcase
tag @s remove Adv.InMenu
tag @s remove CF.InMenu
tag @s remove CF.InCodex

# --- Reset the idle counter ---
scoreboard players set @s ec.menu_idle 0
