# Auto GUI Cleanup — GLOBAL far-orphan safety net (2026-06-23)
# cleanup/gui_auto (10s) is PLAYER-anchored: it only reaps orphan panels within 15 blocks of a
# menu-less player. Panels orphaned where NO player returns (disconnect / relog / errored close in a
# chunk that stays loaded — near spawn, a forceloaded build, etc.) slip past it and can sit "with tags
# but uninteracted" indefinitely. This sweep is NOT anchored to a player: for every session-stamped
# panel with NO player within 10 blocks, kill it. A LIVE menu always keeps its owner far closer than
# 10 blocks (panels spawn at the player), so only genuine orphans are ever hit.
#
# Called from cleanup/tick (5s) ONLY when an interaction entity exists (menu-exclusive — a GUI button;
# orphaned menus keep theirs), so this whole file is skipped by a single cheap check in normal play.
#
# Identification + guards mirror cleanup/gui_auto_player:
#   scores={<sess>=1..} — the positive menu-panel stamp (gameplay entities are never session-stamped).
#   tag=!smithed.entity — custom-block OVERLAY displays carry the Smithed tag; no menu panel does.
#   tag=!DP.El         — the dreamy-pull gacha animation is the only NON-menu reuser of adv.gui_session.

# --- adv.gui_session (~28 menus + their sub-screens) ---
execute as @e[type=text_display,scores={adv.gui_session=1..},tag=!DP.El,tag=!smithed.entity] at @s unless entity @a[distance=..10] run kill @s
execute as @e[type=interaction,scores={adv.gui_session=1..},tag=!DP.El,tag=!smithed.entity] at @s unless entity @a[distance=..10] run kill @s
execute as @e[type=item_display,scores={adv.gui_session=1..},tag=!DP.El,tag=!smithed.entity] at @s unless entity @a[distance=..10] run kill @s
execute as @e[type=block_display,scores={adv.gui_session=1..},tag=!DP.El,tag=!smithed.entity] at @s unless entity @a[distance=..10] run kill @s

# --- ec.cf_gui_session (Craftforever Codex) ---
execute as @e[type=text_display,scores={ec.cf_gui_session=1..},tag=!smithed.entity] at @s unless entity @a[distance=..10] run kill @s
execute as @e[type=interaction,scores={ec.cf_gui_session=1..},tag=!smithed.entity] at @s unless entity @a[distance=..10] run kill @s
execute as @e[type=item_display,scores={ec.cf_gui_session=1..},tag=!smithed.entity] at @s unless entity @a[distance=..10] run kill @s

# --- ec.bough_sess (Living Bough class viewer) ---
execute as @e[type=text_display,scores={ec.bough_sess=1..},tag=!smithed.entity] at @s unless entity @a[distance=..10] run kill @s
execute as @e[type=interaction,scores={ec.bough_sess=1..},tag=!smithed.entity] at @s unless entity @a[distance=..10] run kill @s
execute as @e[type=item_display,scores={ec.bough_sess=1..},tag=!smithed.entity] at @s unless entity @a[distance=..10] run kill @s

# --- ec.qln_sess (Questline book) ---
execute as @e[type=text_display,scores={ec.qln_sess=1..},tag=!smithed.entity] at @s unless entity @a[distance=..10] run kill @s
execute as @e[type=interaction,scores={ec.qln_sess=1..},tag=!smithed.entity] at @s unless entity @a[distance=..10] run kill @s
execute as @e[type=item_display,scores={ec.qln_sess=1..},tag=!smithed.entity] at @s unless entity @a[distance=..10] run kill @s

# --- ec.tome_sess (Artisan tome) ---
execute as @e[type=text_display,scores={ec.tome_sess=1..},tag=!smithed.entity] at @s unless entity @a[distance=..10] run kill @s
execute as @e[type=interaction,scores={ec.tome_sess=1..},tag=!smithed.entity] at @s unless entity @a[distance=..10] run kill @s
execute as @e[type=item_display,scores={ec.tome_sess=1..},tag=!smithed.entity] at @s unless entity @a[distance=..10] run kill @s

# --- Supplemental: menu-exclusive panel tags that don't stamp a session (Bestiary pages, stray
#     anchors). companion.menuanchor / Adv.GUI are already reaped globally in cleanup/tick. ---
execute as @e[tag=Bs.PageContent,tag=!smithed.entity] at @s unless entity @a[distance=..10] run kill @s
execute as @e[tag=Bs.PageHeader,tag=!smithed.entity] at @s unless entity @a[distance=..10] run kill @s
execute as @e[tag=Adv.MenuAnchor,tag=!smithed.entity] at @s unless entity @a[distance=..10] run kill @s
execute as @e[tag=CF.MenuAnchor,tag=!smithed.entity] at @s unless entity @a[distance=..10] run kill @s

# === PER-MENU ELEMENT TAGS (2026-06-23) — the "fix the legacy tagging" net ===
# Every menu stamps its panels with a system-specific element tag at SUMMON (independent of any
# session score), so this catches orphans from menus that never session-stamped — including ones
# opened by OLD code before the session convention existed. These tags are menu-exclusive (each is
# killed in its menu's close/re-render routine; none appear on a persist-by-design world entity),
# and the no-player-within-10 + !smithed.entity guards mean only true orphans are ever hit.
# EXCLUDED on purpose: rd.vote_panel (a SHARED raid object with its own raids/vote/panel/despawn
# lifecycle — never reap it here) and ec.cs_panel (single unverified use).
execute as @e[tag=DEC.MenuEl,tag=!smithed.entity] at @s unless entity @a[distance=..10] run kill @s
execute as @e[tag=Adv.MenuElement,tag=!smithed.entity] at @s unless entity @a[distance=..10] run kill @s
execute as @e[tag=CF.MenuElement,tag=!smithed.entity] at @s unless entity @a[distance=..10] run kill @s
execute as @e[tag=CF.MenuEl,tag=!smithed.entity] at @s unless entity @a[distance=..10] run kill @s
execute as @e[tag=Ec.LrPageContent,tag=!smithed.entity] at @s unless entity @a[distance=..10] run kill @s
execute as @e[tag=Ec.PMPageContent,tag=!smithed.entity] at @s unless entity @a[distance=..10] run kill @s
execute as @e[tag=Ec.BmPageContent,tag=!smithed.entity] at @s unless entity @a[distance=..10] run kill @s
execute as @e[tag=ec.guild_menu_el,tag=!smithed.entity] at @s unless entity @a[distance=..10] run kill @s
execute as @e[tag=ec.guild_page_el,tag=!smithed.entity] at @s unless entity @a[distance=..10] run kill @s
execute as @e[tag=HS.MenuEl,tag=!smithed.entity] at @s unless entity @a[distance=..10] run kill @s
execute as @e[tag=TT.MenuEl,tag=!smithed.entity] at @s unless entity @a[distance=..10] run kill @s
execute as @e[tag=ec.fr_gui_el,tag=!smithed.entity] at @s unless entity @a[distance=..10] run kill @s
execute as @e[tag=WW.MenuElement,tag=!smithed.entity] at @s unless entity @a[distance=..10] run kill @s
execute as @e[tag=ec.sc_gui_el,tag=!smithed.entity] at @s unless entity @a[distance=..10] run kill @s
execute as @e[tag=CK.MenuEl,tag=!smithed.entity] at @s unless entity @a[distance=..10] run kill @s
execute as @e[tag=DG.MenuEl,tag=!smithed.entity] at @s unless entity @a[distance=..10] run kill @s
execute as @e[tag=IC.MenuEl,tag=!smithed.entity] at @s unless entity @a[distance=..10] run kill @s
execute as @e[tag=TX.MenuEl,tag=!smithed.entity] at @s unless entity @a[distance=..10] run kill @s
execute as @e[tag=FF.MenuEl,tag=!smithed.entity] at @s unless entity @a[distance=..10] run kill @s
execute as @e[tag=TNK.MenuEl,tag=!smithed.entity] at @s unless entity @a[distance=..10] run kill @s
execute as @e[tag=WW.MenuAnchor,tag=!smithed.entity] at @s unless entity @a[distance=..10] run kill @s
