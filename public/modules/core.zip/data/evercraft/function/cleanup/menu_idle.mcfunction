# Menu Idle Sweep — held-but-dead cleanup (1s)
# Catches floating menu panels that slid past cleanup/gui_auto because the player still carries
# a menu-open flag (the panel is "held"), but the menu is actually abandoned or its tick died.
# Discriminator: time since the last interaction. A live menu receives clicks (which reset the
# counter every tick via the reset line in tick.mcfunction); a dead/abandoned one never does, so
# its counter climbs to the close threshold.
#
# Self-reschedule (1 increment == 1 second).
schedule function evercraft:cleanup/menu_idle 20t replace

# Skip if no players online
execute unless entity @a run return 0

# Tick the idle counter for everyone, then zero anyone NOT in a menu — so it only accumulates
# while a menu-open flag is held. One add (no double-count) + one reset; both are cheap.
scoreboard players add @a ec.menu_idle 1
scoreboard players set @a[tag=!ec.menu_active,tag=!ec.bough_viewing,tag=!ec.qln_book,tag=!ec.tome_menu,tag=!ec.ksbag_in_menu,tag=!ec.sc_in_showcase] ec.menu_idle 0

# 45s with no interaction while a menu flag is held -> force-close that player's menu (was 60s;
# trimmed 15s on 2026-06-23 so abandoned panels clear sooner).
execute as @a[scores={ec.menu_idle=45..}] at @s run function evercraft:cleanup/menu_idle_close
