# Dawn Chorus — Third chirp (rising)
execute as @a at @s if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.chime player @s ~ ~ ~ 0.3 1.8
execute as @a at @s if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.flute player @s ~ ~ ~ 0.4 2.0
