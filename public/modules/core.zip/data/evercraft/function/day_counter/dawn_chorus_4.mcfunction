# Dawn Chorus — Final flourish
execute as @a at @s if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.flute player @s ~ ~ ~ 0.3 1.4
execute as @a at @s if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.chime player @s ~ ~ ~ 0.25 1.6
execute as @a at @s if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bell player @s ~ ~ ~ 0.15 2.0
