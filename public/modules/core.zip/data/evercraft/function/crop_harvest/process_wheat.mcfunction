# Crop Harvest — Process wheat break (consolidated: replant + stat + reset)
# Run as player at position
function evercraft:crop_harvest/on_break {crop:"wheat"}
# Growseer (hoe) class XP — crop harvest pays 2x the ordinary verb rate (count x #caff_2,
# then grant_verb's x3). Read from the live count BEFORE the stat reset below clobbers it.
scoreboard players operation #caff_d ec.temp = @s ec.rh_wheat
scoreboard players operation #caff_d ec.temp *= #caff_2 ec.var
execute if score #caff_d ec.temp matches 1.. if items entity @s weapon.mainhand #minecraft:hoes run function evercraft:craft_affinity/grant_verb {class_id:3}
scoreboard players operation @s adv.stat_harvest += @s ec.rh_wheat
# Accessory harvest bonus (D-FORTUNE-REWRITE, m2): item-gated double-harvest + extra-crate roll.
# Read the count BEFORE the reset; early-exits for non-holders. Item id = "wheat".
execute store result score #hb_call ec.temp run scoreboard players get @s ec.rh_wheat
execute if score #hb_call ec.temp matches 1.. run function evercraft:artifacts/accessories/harvest_bonus {drop:"wheat", n:1}
# Growseer bough C7 Farmer's Vow (Wave 10): a river/ocean harvest batch yields +1 crop.
# Node-gated (ec.gs_n_c7), crown-independent (Wave 9 convention). Biome read at the
# player ≈ the crop (right-click-replant range). One +1 per processed batch; live count
# read BEFORE the reset below. /give drops overflow at the feet on a full inventory.
execute if score @s ec.gs_n_c7 matches 1.. if score @s ec.rh_wheat matches 1.. if predicate evercraft:biome/is_river run give @s minecraft:wheat 1
execute if score @s ec.gs_n_c7 matches 1.. if score @s ec.rh_wheat matches 1.. if predicate evercraft:biome/is_ocean run give @s minecraft:wheat 1
scoreboard players set @s ec.rh_wheat 0
