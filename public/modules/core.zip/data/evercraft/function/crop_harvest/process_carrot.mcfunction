# Crop Harvest — Process carrot break (consolidated: replant + stat + reset)
# Run as player at position
function evercraft:crop_harvest/on_break {crop:"carrots"}
# Growseer (hoe) class XP — crop harvest pays 2x the ordinary verb rate.
scoreboard players operation #caff_d ec.temp = @s ec.rh_carrot
scoreboard players operation #caff_d ec.temp *= #caff_2 ec.var
execute if score #caff_d ec.temp matches 1.. if items entity @s weapon.mainhand #minecraft:hoes run function evercraft:craft_affinity/grant_verb {class_id:3}
scoreboard players operation @s adv.stat_harvest += @s ec.rh_carrot
# Accessory harvest bonus (D-FORTUNE-REWRITE, m2): item-gated double-harvest + extra-crate roll.
# Item id = "carrot" (NOT the "carrots" block id). Early-exits for non-holders.
execute store result score #hb_call ec.temp run scoreboard players get @s ec.rh_carrot
execute if score #hb_call ec.temp matches 1.. run function evercraft:artifacts/accessories/harvest_bonus {drop:"carrot", n:1}
# Growseer bough C7 Farmer's Vow (Wave 10): river/ocean harvest batch yields +1 crop
# (node-gated, crown-independent; see process_wheat for the full note).
execute if score @s ec.gs_n_c7 matches 1.. if score @s ec.rh_carrot matches 1.. if predicate evercraft:biome/is_river run give @s minecraft:carrot 1
execute if score @s ec.gs_n_c7 matches 1.. if score @s ec.rh_carrot matches 1.. if predicate evercraft:biome/is_ocean run give @s minecraft:carrot 1
scoreboard players set @s ec.rh_carrot 0
