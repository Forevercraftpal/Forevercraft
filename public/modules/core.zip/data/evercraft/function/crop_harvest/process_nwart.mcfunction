# Crop Harvest — Process nether wart break (consolidated: replant + stat + reset)
# Run as player at position
function evercraft:crop_harvest/on_break {crop:"nether_wart"}
# Growseer (hoe) class XP — crop harvest pays 2x the ordinary verb rate.
scoreboard players operation #caff_d ec.temp = @s ec.rh_nwart
scoreboard players operation #caff_d ec.temp *= #caff_2 ec.var
execute if score #caff_d ec.temp matches 1.. if items entity @s weapon.mainhand #minecraft:hoes run function evercraft:craft_affinity/grant_verb {class_id:3}
scoreboard players operation @s adv.stat_harvest += @s ec.rh_nwart
# Accessory harvest bonus (D-FORTUNE-REWRITE, m2): item-gated double-harvest + extra-crate roll.
# Item id = "nether_wart". Early-exits for non-holders.
execute store result score #hb_call ec.temp run scoreboard players get @s ec.rh_nwart
execute if score #hb_call ec.temp matches 1.. run function evercraft:artifacts/accessories/harvest_bonus {drop:"nether_wart", n:1}
# Growseer bough C7 Farmer's Vow (Wave 10): river/ocean harvest batch yields +1 crop
# (node-gated, crown-independent; see process_wheat for the full note — soul-sand wart
# farms in river/ocean biomes legitimately qualify).
execute if score @s ec.gs_n_c7 matches 1.. if score @s ec.rh_nwart matches 1.. if predicate evercraft:biome/is_river run give @s minecraft:nether_wart 1
execute if score @s ec.gs_n_c7 matches 1.. if score @s ec.rh_nwart matches 1.. if predicate evercraft:biome/is_ocean run give @s minecraft:nether_wart 1
scoreboard players set @s ec.rh_nwart 0
