# Forever Coin — 1/500 flat chance on patron kill (no DR scaling)
execute unless predicate {"condition":"minecraft:random_chance","chance":0.002} run return 0

scoreboard players add @s ec.coins 1
scoreboard players add #rm_coins ec.var 1
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.experience_orb.pickup player @s ~ ~ ~ 0.3 1.8
data modify storage evercraft:notify stage.c set value [{text:"A ",color:"gray"},{text:"Forever Coin",color:"#E0B0FF",bold:true},{text:" dropped from the patron!",color:"gray"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit_keyed {key:2}

# Newcomer bonus: 10% chance +1
execute if score @s ec.difficulty matches 1 if predicate {"condition":"minecraft:random_chance","chance":0.1} run scoreboard players add @s ec.coins 1
execute if score @s ec.difficulty matches 1 if predicate {"condition":"minecraft:random_chance","chance":0.1} run scoreboard players add #rm_coins ec.var 1

# +5 guild contribution (if guilded)
execute if score @s ec.guild_id matches 1.. run function evercraft:guild/contribution/add {amount:5}
