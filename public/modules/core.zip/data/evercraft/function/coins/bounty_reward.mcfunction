# Forever Coins — Bounty completion reward (no DR scaling)
# Contract (tier 2) = 1, Commission (tier 3) = 2, Expedition (tier 4) = 3, Heroic (tier 5) = 4

execute if score @s ec.bnt_tier matches 2 run scoreboard players add @s ec.coins 1
execute if score @s ec.bnt_tier matches 2 run data modify storage evercraft:notify stage.c set value [{text:"★ ",color:"#E0B0FF"},{text:"+1 Forever Coin",color:"#E0B0FF"},{text:" ★",color:"#E0B0FF"}]
execute if score @s ec.bnt_tier matches 2 run scoreboard players set #ndur ec.temp 45
execute if score @s ec.bnt_tier matches 2 run function evercraft:util/notify/emit

execute if score @s ec.bnt_tier matches 3 run scoreboard players add @s ec.coins 2
execute if score @s ec.bnt_tier matches 3 run data modify storage evercraft:notify stage.c set value [{text:"★ ",color:"#E0B0FF"},{text:"+2 Forever Coins",color:"#E0B0FF"},{text:" ★",color:"#E0B0FF"}]
execute if score @s ec.bnt_tier matches 3 run scoreboard players set #ndur ec.temp 45
execute if score @s ec.bnt_tier matches 3 run function evercraft:util/notify/emit

execute if score @s ec.bnt_tier matches 4 run scoreboard players add @s ec.coins 3
execute if score @s ec.bnt_tier matches 4 run data modify storage evercraft:notify stage.c set value [{text:"★ ",color:"#E0B0FF"},{text:"+3 Forever Coins",color:"#E0B0FF"},{text:" ★",color:"#E0B0FF"}]
execute if score @s ec.bnt_tier matches 4 run scoreboard players set #ndur ec.temp 45
execute if score @s ec.bnt_tier matches 4 run function evercraft:util/notify/emit

execute if score @s ec.bnt_tier matches 5 run scoreboard players add @s ec.coins 4
execute if score @s ec.bnt_tier matches 5 run data modify storage evercraft:notify stage.c set value [{text:"★ ",color:"#E0B0FF"},{text:"+4 Forever Coins",color:"#E0B0FF"},{text:" ★",color:"#E0B0FF"}]
execute if score @s ec.bnt_tier matches 5 run scoreboard players set #ndur ec.temp 45
execute if score @s ec.bnt_tier matches 5 run function evercraft:util/notify/emit

# Newcomer bonus: 10% chance +1
execute if score @s ec.difficulty matches 1 if predicate {"condition":"minecraft:random_chance","chance":0.1} run scoreboard players add @s ec.coins 1
execute if score @s ec.difficulty matches 1 if predicate {"condition":"minecraft:random_chance","chance":0.1} run scoreboard players add #rm_coins ec.var 1

# Realm milestone: coin tracking
execute if score @s ec.bnt_tier matches 2 run scoreboard players add #rm_coins ec.var 1
execute if score @s ec.bnt_tier matches 3 run scoreboard players add #rm_coins ec.var 2
execute if score @s ec.bnt_tier matches 4 run scoreboard players add #rm_coins ec.var 3
execute if score @s ec.bnt_tier matches 5 run scoreboard players add #rm_coins ec.var 4

# Guild contribution (5x coins, if guilded)
execute if score @s ec.guild_id matches 1.. if score @s ec.bnt_tier matches 2 run function evercraft:guild/contribution/add {amount:5}
execute if score @s ec.guild_id matches 1.. if score @s ec.bnt_tier matches 3 run function evercraft:guild/contribution/add {amount:10}
execute if score @s ec.guild_id matches 1.. if score @s ec.bnt_tier matches 4 run function evercraft:guild/contribution/add {amount:15}
execute if score @s ec.guild_id matches 1.. if score @s ec.bnt_tier matches 5 run function evercraft:guild/contribution/add {amount:20}
