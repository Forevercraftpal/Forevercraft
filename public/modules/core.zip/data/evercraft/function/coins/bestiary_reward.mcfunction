# Forever Coins — Bestiary mastery completion (no DR scaling)
# 1 coin per new mastery tier completed
scoreboard players add @s ec.coins 1
scoreboard players add #rm_coins ec.var 1
data modify storage evercraft:notify stage.c set value [{text:"★ ",color:"#E0B0FF"},{text:"+1 Forever Coin",color:"#E0B0FF"},{text:" — Bestiary Mastery!",color:"gray"},{text:" ★",color:"#E0B0FF"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.experience_orb.pickup player @s ~ ~ ~ 0.3 1.5

# Guild contribution (5x = 5)
execute if score @s ec.guild_id matches 1.. run function evercraft:guild/contribution/add {amount:5}
