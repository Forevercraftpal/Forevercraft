# Forever Coins — Spirit Tool Tier Up reward
# Tier 2=5, Tier 3=8, Tier 4=12, Tier 5=16, Tier 6=20, Tier 7=25 (rebalanced to the 25-coin cap, 2026-06-21)

execute if score @s ec.st_tier matches 2 run scoreboard players add @s ec.coins 5
execute if score @s ec.st_tier matches 2 run data modify storage evercraft:notify stage.c set value [{text:"★ ",color:"#E0B0FF"},{text:"+5 Forever Coins",color:"#E0B0FF"},{text:" — Tool Tier Up!",color:"green"},{text:" ★",color:"#E0B0FF"}]
execute if score @s ec.st_tier matches 2 run scoreboard players set #ndur ec.temp 45
execute if score @s ec.st_tier matches 2 run function evercraft:util/notify/emit

execute if score @s ec.st_tier matches 3 run scoreboard players add @s ec.coins 8
execute if score @s ec.st_tier matches 3 run data modify storage evercraft:notify stage.c set value [{text:"★ ",color:"#E0B0FF"},{text:"+8 Forever Coins",color:"#E0B0FF",bold:true},{text:" — Tool Tier Up!",color:"green"},{text:" ★",color:"#E0B0FF"}]
execute if score @s ec.st_tier matches 3 run scoreboard players set #ndur ec.temp 45
execute if score @s ec.st_tier matches 3 run function evercraft:util/notify/emit

execute if score @s ec.st_tier matches 4 run scoreboard players add @s ec.coins 12
execute if score @s ec.st_tier matches 4 run data modify storage evercraft:notify stage.c set value [{text:"★ ",color:"#E0B0FF"},{text:"+12 Forever Coins",color:"#E0B0FF",bold:true},{text:" — Tool Tier Up!",color:"green"},{text:" ★",color:"#E0B0FF"}]
execute if score @s ec.st_tier matches 4 run scoreboard players set #ndur ec.temp 45
execute if score @s ec.st_tier matches 4 run function evercraft:util/notify/emit

execute if score @s ec.st_tier matches 5 run scoreboard players add @s ec.coins 16
execute if score @s ec.st_tier matches 5 run data modify storage evercraft:notify stage.c set value [{text:"★ ",color:"#E0B0FF"},{text:"+16 Forever Coins",color:"#E0B0FF",bold:true},{text:" — Tool Tier Up!",color:"green"},{text:" ★",color:"#E0B0FF"}]
execute if score @s ec.st_tier matches 5 run scoreboard players set #ndur ec.temp 45
execute if score @s ec.st_tier matches 5 run function evercraft:util/notify/emit

execute if score @s ec.st_tier matches 6 run scoreboard players add @s ec.coins 20
execute if score @s ec.st_tier matches 6 run data modify storage evercraft:notify stage.c set value [{text:"★ ",color:"#E0B0FF"},{text:"+20 Forever Coins",color:"#E0B0FF",bold:true},{text:" — Tool Tier Up!",color:"green"},{text:" ★",color:"#E0B0FF"}]
execute if score @s ec.st_tier matches 6 run scoreboard players set #ndur ec.temp 45
execute if score @s ec.st_tier matches 6 run function evercraft:util/notify/emit

execute if score @s ec.st_tier matches 7 run scoreboard players add @s ec.coins 25
execute if score @s ec.st_tier matches 7 run data modify storage evercraft:notify stage.c set value [{text:"★ ",color:"#E0B0FF"},{text:"+25 Forever Coins",color:"#E0B0FF",bold:true},{text:" — Spirit Tool Awakened!",color:"gold"},{text:" ★",color:"#E0B0FF"}]
execute if score @s ec.st_tier matches 7 run scoreboard players set #ndur ec.temp 45
execute if score @s ec.st_tier matches 7 run function evercraft:util/notify/emit

# Guild contribution
execute if score @s ec.guild_id matches 1.. run function evercraft:guild/contribution/add {amount:50}

execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.experience_orb.pickup player @s ~ ~ ~ 0.5 1.5
