# Forever Coins — Pet level milestone rewards
# Called after level_up increments #current_level companion.exp
# Only fires on exact threshold crossings

execute if score #current_level companion.exp matches 25 run scoreboard players add @s ec.coins 1
execute if score #current_level companion.exp matches 25 run data modify storage evercraft:notify stage.c set value [{text:"Pet reached level 25! ",color:"green"},{text:"+1 Forever Coin",color:"#E0B0FF"}]
execute if score #current_level companion.exp matches 25 run scoreboard players set #ndur ec.temp 45
execute if score #current_level companion.exp matches 25 run function evercraft:util/notify/emit
execute if score #current_level companion.exp matches 25 if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.player.levelup player @s ~ ~ ~ 0.5 1.5
execute if score #current_level companion.exp matches 25 if score @s ec.guild_id matches 1.. run function evercraft:guild/contribution/add {amount:5}
execute if score #current_level companion.exp matches 25 run scoreboard players add #rm_coins ec.var 1

execute if score #current_level companion.exp matches 50 run scoreboard players add @s ec.coins 2
execute if score #current_level companion.exp matches 50 run data modify storage evercraft:notify stage.c set value [{text:"Pet reached level 50! ",color:"green"},{text:"+2 Forever Coins",color:"#E0B0FF"}]
execute if score #current_level companion.exp matches 50 run scoreboard players set #ndur ec.temp 45
execute if score #current_level companion.exp matches 50 run function evercraft:util/notify/emit
execute if score #current_level companion.exp matches 50 if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.player.levelup player @s ~ ~ ~ 0.5 1.5
execute if score #current_level companion.exp matches 50 if score @s ec.guild_id matches 1.. run function evercraft:guild/contribution/add {amount:10}
execute if score #current_level companion.exp matches 50 run scoreboard players add #rm_coins ec.var 2

execute if score #current_level companion.exp matches 75 run scoreboard players add @s ec.coins 3
execute if score #current_level companion.exp matches 75 run data modify storage evercraft:notify stage.c set value [{text:"Pet reached level 75! ",color:"green"},{text:"+3 Forever Coins",color:"#E0B0FF"}]
execute if score #current_level companion.exp matches 75 run scoreboard players set #ndur ec.temp 45
execute if score #current_level companion.exp matches 75 run function evercraft:util/notify/emit
execute if score #current_level companion.exp matches 75 if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.player.levelup player @s ~ ~ ~ 0.5 1.5
execute if score #current_level companion.exp matches 75 if score @s ec.guild_id matches 1.. run function evercraft:guild/contribution/add {amount:15}
execute if score #current_level companion.exp matches 75 run scoreboard players add #rm_coins ec.var 3

execute if score #current_level companion.exp matches 100 run scoreboard players add @s ec.coins 5
execute if score #current_level companion.exp matches 100 run data modify storage evercraft:notify stage.c set value [{text:"Pet reached level 100! ",color:"gold",bold:true},{text:" +5 Forever Coins",color:"#E0B0FF"}]
execute if score #current_level companion.exp matches 100 run scoreboard players set #ndur ec.temp 45
execute if score #current_level companion.exp matches 100 run function evercraft:util/notify/emit
execute if score #current_level companion.exp matches 100 if score @s ec.fx_snd matches 1.. run playsound minecraft:ui.toast.challenge_complete player @s ~ ~ ~ 0.5 1.0
execute if score #current_level companion.exp matches 100 if score @s ec.guild_id matches 1.. run function evercraft:guild/contribution/add {amount:25}
execute if score #current_level companion.exp matches 100 run scoreboard players add #rm_coins ec.var 5

# Newcomer bonus: 10% chance +1 on any milestone
execute if score @s ec.difficulty matches 1 if score #current_level companion.exp matches 25 if predicate {"condition":"minecraft:random_chance","chance":0.1} run scoreboard players add @s ec.coins 1
execute if score @s ec.difficulty matches 1 if score #current_level companion.exp matches 25 if predicate {"condition":"minecraft:random_chance","chance":0.1} run scoreboard players add #rm_coins ec.var 1
execute if score @s ec.difficulty matches 1 if score #current_level companion.exp matches 50 if predicate {"condition":"minecraft:random_chance","chance":0.1} run scoreboard players add @s ec.coins 1
execute if score @s ec.difficulty matches 1 if score #current_level companion.exp matches 50 if predicate {"condition":"minecraft:random_chance","chance":0.1} run scoreboard players add #rm_coins ec.var 1
execute if score @s ec.difficulty matches 1 if score #current_level companion.exp matches 75 if predicate {"condition":"minecraft:random_chance","chance":0.1} run scoreboard players add @s ec.coins 1
execute if score @s ec.difficulty matches 1 if score #current_level companion.exp matches 75 if predicate {"condition":"minecraft:random_chance","chance":0.1} run scoreboard players add #rm_coins ec.var 1
execute if score @s ec.difficulty matches 1 if score #current_level companion.exp matches 100 if predicate {"condition":"minecraft:random_chance","chance":0.1} run scoreboard players add @s ec.coins 1
execute if score @s ec.difficulty matches 1 if score #current_level companion.exp matches 100 if predicate {"condition":"minecraft:random_chance","chance":0.1} run scoreboard players add #rm_coins ec.var 1
