# Forever Coins — Realm Milestone completion (no DR scaling)
# 15 coins to ALL online players (realm-wide celebration)

execute as @a run scoreboard players add @s ec.coins 15
scoreboard players add #rm_coins ec.var 15
data modify storage evercraft:notify stage.c set value [{text:"★ ",color:"#E0B0FF"},{text:"+15 Forever Coins",color:"#E0B0FF",bold:true},{text:" — Milestone Achieved!",color:"gold"},{text:" ★",color:"#E0B0FF"}]
scoreboard players set #ndur ec.temp 45
execute as @a run function evercraft:util/notify/emit
execute as @a if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.experience_orb.pickup player @s ~ ~ ~ 0.5 1.5

# Guild contribution for all guilded players (5x = 75)
execute as @a if score @s ec.guild_id matches 1.. run function evercraft:guild/contribution/add {amount:75}
