# Forever Coins — Masterwork forge reward
# Grants 5 coins for forging a masterwork quality item

scoreboard players add @s ec.coins 5
scoreboard players add #rm_coins ec.var 5
data modify storage evercraft:notify stage.c set value [{text:"★ ",color:"#E0B0FF"},{text:"+5 Forever Coins",color:"#E0B0FF",bold:true},{text:" — Masterwork Forged!",color:"gold"},{text:" ★",color:"#E0B0FF"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit

# Newcomer bonus: flat +1
execute if score @s ec.difficulty matches 1 run scoreboard players add @s ec.coins 1
execute if score @s ec.difficulty matches 1 run scoreboard players add #rm_coins ec.var 1

# Guild contribution
execute if score @s ec.guild_id matches 1.. run function evercraft:guild/contribution/add {amount:25}

execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.experience_orb.pickup player @s ~ ~ ~ 0.5 1.5
