# Forever Coins — Constellation completion reward (no DR scaling)
# 10 coins per constellation completed
scoreboard players add @s ec.coins 10
scoreboard players add #rm_coins ec.var 10
data modify storage evercraft:notify stage.c set value [{text:"★ ",color:"#E0B0FF"},{text:"+10 Forever Coins",color:"#E0B0FF",bold:true},{text:" — Constellation Complete!",color:"gold"},{text:" ★",color:"#E0B0FF"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.experience_orb.pickup player @s ~ ~ ~ 0.5 1.5

# Newcomer bonus: flat +1
execute if score @s ec.difficulty matches 1 run scoreboard players add @s ec.coins 1
execute if score @s ec.difficulty matches 1 run scoreboard players add #rm_coins ec.var 1

# +50 guild contribution (if guilded)
execute if score @s ec.guild_id matches 1.. run function evercraft:guild/contribution/add {amount:50}

# +200 guild XP for constellation completion
function evercraft:guild/contribution/add_guild_xp_direct {amount:200}
