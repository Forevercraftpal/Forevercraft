# Forever Coins — Laborer expedition return (no DR scaling)
# Meager(0)=1, Decent(1)=2, Bountiful(2)=3, Abundant(3)=5, Legendary(4)=10
# Runs as: laborer entity. Player = @p

execute if score #lb_qtier ec.lb_temp matches 0 run scoreboard players add @p ec.coins 1
execute if score #lb_qtier ec.lb_temp matches 0 run scoreboard players add #rm_coins ec.var 1
execute if score #lb_qtier ec.lb_temp matches 0 run data modify storage evercraft:notify stage.c set value [{text:"★ ",color:"#E0B0FF"},{text:"+1 Forever Coin",color:"#E0B0FF"},{text:" — Expedition Return",color:"gray"},{text:" ★",color:"#E0B0FF"}]
execute if score #lb_qtier ec.lb_temp matches 0 run scoreboard players set #ndur ec.temp 45
execute if score #lb_qtier ec.lb_temp matches 0 as @p run function evercraft:util/notify/emit

execute if score #lb_qtier ec.lb_temp matches 1 run scoreboard players add @p ec.coins 2
execute if score #lb_qtier ec.lb_temp matches 1 run scoreboard players add #rm_coins ec.var 2
execute if score #lb_qtier ec.lb_temp matches 1 run data modify storage evercraft:notify stage.c set value [{text:"★ ",color:"#E0B0FF"},{text:"+2 Forever Coins",color:"#E0B0FF"},{text:" — Expedition Return",color:"gray"},{text:" ★",color:"#E0B0FF"}]
execute if score #lb_qtier ec.lb_temp matches 1 run scoreboard players set #ndur ec.temp 45
execute if score #lb_qtier ec.lb_temp matches 1 as @p run function evercraft:util/notify/emit

execute if score #lb_qtier ec.lb_temp matches 2 run scoreboard players add @p ec.coins 3
execute if score #lb_qtier ec.lb_temp matches 2 run scoreboard players add #rm_coins ec.var 3
execute if score #lb_qtier ec.lb_temp matches 2 run data modify storage evercraft:notify stage.c set value [{text:"★ ",color:"#E0B0FF"},{text:"+3 Forever Coins",color:"#E0B0FF"},{text:" — Expedition Return",color:"gray"},{text:" ★",color:"#E0B0FF"}]
execute if score #lb_qtier ec.lb_temp matches 2 run scoreboard players set #ndur ec.temp 45
execute if score #lb_qtier ec.lb_temp matches 2 as @p run function evercraft:util/notify/emit

execute if score #lb_qtier ec.lb_temp matches 3 run scoreboard players add @p ec.coins 5
execute if score #lb_qtier ec.lb_temp matches 3 run scoreboard players add #rm_coins ec.var 5
execute if score #lb_qtier ec.lb_temp matches 3 run data modify storage evercraft:notify stage.c set value [{text:"★ ",color:"#E0B0FF"},{text:"+5 Forever Coins",color:"#E0B0FF",bold:true},{text:" — Abundant Expedition!",color:"gold"},{text:" ★",color:"#E0B0FF"}]
execute if score #lb_qtier ec.lb_temp matches 3 run scoreboard players set #ndur ec.temp 45
execute if score #lb_qtier ec.lb_temp matches 3 as @p run function evercraft:util/notify/emit

execute if score #lb_qtier ec.lb_temp matches 4 run scoreboard players add @p ec.coins 10
execute if score #lb_qtier ec.lb_temp matches 4 run scoreboard players add #rm_coins ec.var 10
execute if score #lb_qtier ec.lb_temp matches 4 run data modify storage evercraft:notify stage.c set value [{text:"★ ",color:"#E0B0FF"},{text:"+10 Forever Coins",color:"#E0B0FF",bold:true},{text:" — Legendary Expedition!",color:"gold"},{text:" ★",color:"#E0B0FF"}]
execute if score #lb_qtier ec.lb_temp matches 4 run scoreboard players set #ndur ec.temp 45
execute if score #lb_qtier ec.lb_temp matches 4 as @p run function evercraft:util/notify/emit

# Guild contribution (5x coins)
execute as @p if score @s ec.guild_id matches 1.. if score #lb_qtier ec.lb_temp matches 0 run function evercraft:guild/contribution/add {amount:5}
execute as @p if score @s ec.guild_id matches 1.. if score #lb_qtier ec.lb_temp matches 1 run function evercraft:guild/contribution/add {amount:10}
execute as @p if score @s ec.guild_id matches 1.. if score #lb_qtier ec.lb_temp matches 2 run function evercraft:guild/contribution/add {amount:15}
execute as @p if score @s ec.guild_id matches 1.. if score #lb_qtier ec.lb_temp matches 3 run function evercraft:guild/contribution/add {amount:25}
execute as @p if score @s ec.guild_id matches 1.. if score #lb_qtier ec.lb_temp matches 4 run function evercraft:guild/contribution/add {amount:50}

execute as @p if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.experience_orb.pickup player @s ~ ~ ~ 0.3 1.5
