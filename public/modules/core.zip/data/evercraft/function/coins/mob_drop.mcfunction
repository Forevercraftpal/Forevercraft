# Forever Coin — 1/2500 flat chance on any mob kill (no DR scaling)
# Uses random_chance (NOT random_chance_with_enchanted_bonus) to bypass luck
execute unless predicate {"condition":"minecraft:random_chance","chance":0.0004} run return 0

# Grant 1 Forever Coin
scoreboard players add @s ec.coins 1
scoreboard players add #rm_coins ec.var 1
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.experience_orb.pickup player @s ~ ~ ~ 0.3 1.8
data modify storage evercraft:notify stage.c set value [{text:"A ",color:"gray"},{text:"Forever Coin",color:"#E0B0FF",bold:true},{text:" dropped!",color:"gray"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit_keyed {key:1}

# Newcomer bonus: 10% chance +1
execute if score @s ec.difficulty matches 1 if predicate {"condition":"minecraft:random_chance","chance":0.1} run scoreboard players add @s ec.coins 1
execute if score @s ec.difficulty matches 1 if predicate {"condition":"minecraft:random_chance","chance":0.1} run scoreboard players add #rm_coins ec.var 1

# +3 guild contribution (if guilded) — same 1/2500 odds as coin
execute if score @s ec.guild_id matches 1.. run function evercraft:guild/contribution/add {amount:3}
