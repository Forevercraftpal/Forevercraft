# Forever Coins — Artisan Tome quest completion (no DR scaling)
# Part 1-25=2, Part 26-50=5, Part 51-75=10, Part 76-100=20

execute if score @s ec.tq_part matches 1..25 run scoreboard players add @s ec.coins 2
execute if score @s ec.tq_part matches 1..25 run scoreboard players add #rm_coins ec.var 2
execute if score @s ec.tq_part matches 1..25 run data modify storage evercraft:notify stage.c set value [{text:"★ ",color:"#E0B0FF"},{text:"+2 Forever Coins",color:"#E0B0FF"},{text:" — Artisan Quest!",color:"green"},{text:" ★",color:"#E0B0FF"}]
execute if score @s ec.tq_part matches 1..25 run scoreboard players set #ndur ec.temp 45
execute if score @s ec.tq_part matches 1..25 run function evercraft:util/notify/emit

execute if score @s ec.tq_part matches 26..50 run scoreboard players add @s ec.coins 5
execute if score @s ec.tq_part matches 26..50 run scoreboard players add #rm_coins ec.var 5
execute if score @s ec.tq_part matches 26..50 run data modify storage evercraft:notify stage.c set value [{text:"★ ",color:"#E0B0FF"},{text:"+5 Forever Coins",color:"#E0B0FF",bold:true},{text:" — Artisan Quest!",color:"green"},{text:" ★",color:"#E0B0FF"}]
execute if score @s ec.tq_part matches 26..50 run scoreboard players set #ndur ec.temp 45
execute if score @s ec.tq_part matches 26..50 run function evercraft:util/notify/emit

execute if score @s ec.tq_part matches 51..75 run scoreboard players add @s ec.coins 10
execute if score @s ec.tq_part matches 51..75 run scoreboard players add #rm_coins ec.var 10
execute if score @s ec.tq_part matches 51..75 run data modify storage evercraft:notify stage.c set value [{text:"★ ",color:"#E0B0FF"},{text:"+10 Forever Coins",color:"#E0B0FF",bold:true},{text:" — Artisan Quest!",color:"green"},{text:" ★",color:"#E0B0FF"}]
execute if score @s ec.tq_part matches 51..75 run scoreboard players set #ndur ec.temp 45
execute if score @s ec.tq_part matches 51..75 run function evercraft:util/notify/emit

execute if score @s ec.tq_part matches 76..100 run scoreboard players add @s ec.coins 20
execute if score @s ec.tq_part matches 76..100 run scoreboard players add #rm_coins ec.var 20
execute if score @s ec.tq_part matches 76..100 run data modify storage evercraft:notify stage.c set value [{text:"★ ",color:"#E0B0FF"},{text:"+20 Forever Coins",color:"#E0B0FF",bold:true},{text:" — Artisan Quest!",color:"green"},{text:" ★",color:"#E0B0FF"}]
execute if score @s ec.tq_part matches 76..100 run scoreboard players set #ndur ec.temp 45
execute if score @s ec.tq_part matches 76..100 run function evercraft:util/notify/emit

# Newcomer bonus: flat +1
execute if score @s ec.difficulty matches 1 run scoreboard players add @s ec.coins 1
execute if score @s ec.difficulty matches 1 run scoreboard players add #rm_coins ec.var 1

# Guild contribution (5x coins)
execute if score @s ec.guild_id matches 1.. if score @s ec.tq_part matches 1..25 run function evercraft:guild/contribution/add {amount:10}
execute if score @s ec.guild_id matches 1.. if score @s ec.tq_part matches 26..50 run function evercraft:guild/contribution/add {amount:25}
execute if score @s ec.guild_id matches 1.. if score @s ec.tq_part matches 51..75 run function evercraft:guild/contribution/add {amount:50}
execute if score @s ec.guild_id matches 1.. if score @s ec.tq_part matches 76..100 run function evercraft:guild/contribution/add {amount:100}

execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.experience_orb.pickup player @s ~ ~ ~ 0.5 1.5
