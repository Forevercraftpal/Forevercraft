# Forever Coins — Dungeon completion reward (no DR scaling)
# Normal (difficulty 1) = 2, Hard (difficulty 2) = 4, Brutal (difficulty 3) = 6

execute if score #dg_difficulty ec.var matches 1 run scoreboard players add @s ec.coins 2
execute if score #dg_difficulty ec.var matches 1 run data modify storage evercraft:notify stage.c set value [{text:"★ ",color:"#E0B0FF"},{text:"+2 Forever Coins",color:"#E0B0FF"},{text:" ★",color:"#E0B0FF"}]
execute if score #dg_difficulty ec.var matches 1 run scoreboard players set #ndur ec.temp 45
execute if score #dg_difficulty ec.var matches 1 run function evercraft:util/notify/emit

execute if score #dg_difficulty ec.var matches 2 run scoreboard players add @s ec.coins 4
execute if score #dg_difficulty ec.var matches 2 run data modify storage evercraft:notify stage.c set value [{text:"★ ",color:"#E0B0FF"},{text:"+4 Forever Coins",color:"#E0B0FF"},{text:" ★",color:"#E0B0FF"}]
execute if score #dg_difficulty ec.var matches 2 run scoreboard players set #ndur ec.temp 45
execute if score #dg_difficulty ec.var matches 2 run function evercraft:util/notify/emit

execute if score #dg_difficulty ec.var matches 3 run scoreboard players add @s ec.coins 6
execute if score #dg_difficulty ec.var matches 3 run data modify storage evercraft:notify stage.c set value [{text:"★ ",color:"#E0B0FF"},{text:"+6 Forever Coins",color:"#E0B0FF"},{text:" ★",color:"#E0B0FF"}]
execute if score #dg_difficulty ec.var matches 3 run scoreboard players set #ndur ec.temp 45
execute if score #dg_difficulty ec.var matches 3 run function evercraft:util/notify/emit

# Newcomer bonus: 10% chance +1
execute if score @s ec.difficulty matches 1 if predicate {"condition":"minecraft:random_chance","chance":0.1} run scoreboard players add @s ec.coins 1
execute if score @s ec.difficulty matches 1 if predicate {"condition":"minecraft:random_chance","chance":0.1} run scoreboard players add #rm_coins ec.var 1

# Realm milestone: coin tracking
execute if score #dg_difficulty ec.var matches 1 run scoreboard players add #rm_coins ec.var 2
execute if score #dg_difficulty ec.var matches 2 run scoreboard players add #rm_coins ec.var 4
execute if score #dg_difficulty ec.var matches 3 run scoreboard players add #rm_coins ec.var 6

# Guild contribution (5x coins, if guilded)
execute if score @s ec.guild_id matches 1.. if score #dg_difficulty ec.var matches 1 run function evercraft:guild/contribution/add {amount:10}
execute if score @s ec.guild_id matches 1.. if score #dg_difficulty ec.var matches 2 run function evercraft:guild/contribution/add {amount:20}
execute if score @s ec.guild_id matches 1.. if score #dg_difficulty ec.var matches 3 run function evercraft:guild/contribution/add {amount:30}
