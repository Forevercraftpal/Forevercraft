# Forever Coins — Wither kill reward: 3 coins
advancement revoke @s only evercraft:coins/kill_wither
scoreboard players add @s ec.coins 3
scoreboard players add #rm_coins ec.var 3
data modify storage evercraft:notify stage.c set value [{text:"+3 Forever Coins ",color:"#E0B0FF",bold:true},{text:"— Wither destroyed!",color:"gray"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.experience_orb.pickup player @s ~ ~ ~ 0.5 1.5
# Newcomer bonus: 10% chance +1
execute if score @s ec.difficulty matches 1 if predicate {"condition":"minecraft:random_chance","chance":0.1} run scoreboard players add @s ec.coins 1
execute if score @s ec.difficulty matches 1 if predicate {"condition":"minecraft:random_chance","chance":0.1} run scoreboard players add #rm_coins ec.var 1

execute if score @s ec.guild_id matches 1.. run function evercraft:guild/contribution/add {amount:15}
