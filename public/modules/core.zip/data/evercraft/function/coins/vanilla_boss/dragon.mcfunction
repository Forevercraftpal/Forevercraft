# Forever Coins — Ender Dragon kill reward: 25 coins
advancement revoke @s only evercraft:coins/kill_ender_dragon
scoreboard players add @s ec.coins 25
scoreboard players add #rm_coins ec.var 25
data modify storage evercraft:notify stage.c set value [{text:"+25 Forever Coins ",color:"#E0B0FF",bold:true},{text:"— Ender Dragon slain!",color:"gray"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.experience_orb.pickup player @s ~ ~ ~ 0.5 1.5
# Newcomer bonus: flat +3
execute if score @s ec.difficulty matches 1 run scoreboard players add @s ec.coins 3
execute if score @s ec.difficulty matches 1 run scoreboard players add #rm_coins ec.var 3

execute if score @s ec.guild_id matches 1.. run function evercraft:guild/contribution/add {amount:125}
