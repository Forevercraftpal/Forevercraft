# Forever Coins — World Boss kill reward (no DR scaling)
# R4 2026-05-29 (Boss Meta Wave A): coins scale by BOSS DIFFICULTY TIER, not dimension.
#   Tier I (intro)  → 10 coins, guild +75
#   Tier II (mid)   → 18 coins, guild +125
#   Tier III (apex) → 25 coins, guild +200   (coins capped to 25, 2026-06-21)
# #wb_reward_tier is computed once in bosses/rewards/compute_tier (called from give_participant
# before this fn). Guild contribution keeps the existing 5x proportion.

execute if score #wb_reward_tier ec.var matches 1 run scoreboard players add @s ec.coins 10
execute if score #wb_reward_tier ec.var matches 1 run data modify storage evercraft:notify stage.c set value [{text:"★ ",color:"#E0B0FF"},{text:"+10 Forever Coins",color:"#E0B0FF",bold:true},{text:" ★",color:"#E0B0FF"}]
execute if score #wb_reward_tier ec.var matches 1 run scoreboard players set #ndur ec.temp 45
execute if score #wb_reward_tier ec.var matches 1 run function evercraft:util/notify/emit

execute if score #wb_reward_tier ec.var matches 2 run scoreboard players add @s ec.coins 18
execute if score #wb_reward_tier ec.var matches 2 run data modify storage evercraft:notify stage.c set value [{text:"★ ",color:"#E0B0FF"},{text:"+18 Forever Coins",color:"#E0B0FF",bold:true},{text:" ★",color:"#E0B0FF"}]
execute if score #wb_reward_tier ec.var matches 2 run scoreboard players set #ndur ec.temp 45
execute if score #wb_reward_tier ec.var matches 2 run function evercraft:util/notify/emit

execute if score #wb_reward_tier ec.var matches 3 run scoreboard players add @s ec.coins 25
execute if score #wb_reward_tier ec.var matches 3 run data modify storage evercraft:notify stage.c set value [{text:"★ ",color:"#E0B0FF"},{text:"+25 Forever Coins",color:"#E0B0FF",bold:true},{text:" ★",color:"#E0B0FF"}]
execute if score #wb_reward_tier ec.var matches 3 run scoreboard players set #ndur ec.temp 45
execute if score #wb_reward_tier ec.var matches 3 run function evercraft:util/notify/emit

# Realm milestone: coin tracking
execute if score #wb_reward_tier ec.var matches 1 run scoreboard players add #rm_coins ec.var 10
execute if score #wb_reward_tier ec.var matches 2 run scoreboard players add #rm_coins ec.var 18
execute if score #wb_reward_tier ec.var matches 3 run scoreboard players add #rm_coins ec.var 25

# Guild contribution (5x coins, if guilded)
execute if score @s ec.guild_id matches 1.. if score #wb_reward_tier ec.var matches 1 run function evercraft:guild/contribution/add {amount:75}
execute if score @s ec.guild_id matches 1.. if score #wb_reward_tier ec.var matches 2 run function evercraft:guild/contribution/add {amount:125}
execute if score @s ec.guild_id matches 1.. if score #wb_reward_tier ec.var matches 3 run function evercraft:guild/contribution/add {amount:200}
