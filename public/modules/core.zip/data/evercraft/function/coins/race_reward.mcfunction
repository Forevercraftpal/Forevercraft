# Forever Coins — Skyrift Derby race reward (no DR scaling)
# 5 base for finishing, +10 bonus for 1st place

# Participation: 5 coins for all finishers
scoreboard players add @s ec.coins 5
scoreboard players add #rm_coins ec.var 5
data modify storage evercraft:notify stage.c set value [{text:"★ ",color:"#E0B0FF"},{text:"+5 Forever Coins",color:"#E0B0FF",bold:true},{text:" — Race Finished!",color:"gold"},{text:" ★",color:"#E0B0FF"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit

# Winner bonus: +10 for fastest time
execute if score @s ec.mt_best_time = #mt_top_time ec.var run scoreboard players add @s ec.coins 10
execute if score @s ec.mt_best_time = #mt_top_time ec.var run scoreboard players add #rm_coins ec.var 10
execute if score @s ec.mt_best_time = #mt_top_time ec.var run data modify storage evercraft:notify stage.c set value [{text:"★ ",color:"#E0B0FF"},{text:"+10 Forever Coins",color:"#E0B0FF",bold:true},{text:" — 1st Place Bonus!",color:"gold"},{text:" ★",color:"#E0B0FF"}]
execute if score @s ec.mt_best_time = #mt_top_time ec.var run scoreboard players set #ndur ec.temp 45
execute if score @s ec.mt_best_time = #mt_top_time ec.var run function evercraft:util/notify/emit

# Newcomer bonus: flat +1
execute if score @s ec.difficulty matches 1 run scoreboard players add @s ec.coins 1
execute if score @s ec.difficulty matches 1 run scoreboard players add #rm_coins ec.var 1

# Guild contribution (5x base = 25, winner gets extra 50)
execute if score @s ec.guild_id matches 1.. run function evercraft:guild/contribution/add {amount:25}
execute if score @s ec.guild_id matches 1.. if score @s ec.mt_best_time = #mt_top_time ec.var run function evercraft:guild/contribution/add {amount:50}

execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.experience_orb.pickup player @s ~ ~ ~ 0.5 1.5
