# Forever Coins — Trade Trial completion reward (no DR scaling)
# T1=1, T2=2, T3=3, T4=5, T5=8, T6=10, T7=15, T8=20, T9=22, T10=25 (top tiers capped to 25, 2026-06-21)

execute if score @s ec.tt_tier matches 1 run scoreboard players add @s ec.coins 1
execute if score @s ec.tt_tier matches 1 run scoreboard players add #rm_coins ec.var 1
execute if score @s ec.tt_tier matches 1 run data modify storage evercraft:notify stage.c set value [{text:"★ ",color:"#E0B0FF"},{text:"+1 Forever Coin",color:"#E0B0FF"},{text:" — Trial Complete!",color:"gold"},{text:" ★",color:"#E0B0FF"}]
execute if score @s ec.tt_tier matches 1 run scoreboard players set #ndur ec.temp 45
execute if score @s ec.tt_tier matches 1 run function evercraft:util/notify/emit

execute if score @s ec.tt_tier matches 2 run scoreboard players add @s ec.coins 2
execute if score @s ec.tt_tier matches 2 run scoreboard players add #rm_coins ec.var 2
execute if score @s ec.tt_tier matches 2 run data modify storage evercraft:notify stage.c set value [{text:"★ ",color:"#E0B0FF"},{text:"+2 Forever Coins",color:"#E0B0FF"},{text:" — Trial Complete!",color:"gold"},{text:" ★",color:"#E0B0FF"}]
execute if score @s ec.tt_tier matches 2 run scoreboard players set #ndur ec.temp 45
execute if score @s ec.tt_tier matches 2 run function evercraft:util/notify/emit

execute if score @s ec.tt_tier matches 3 run scoreboard players add @s ec.coins 3
execute if score @s ec.tt_tier matches 3 run scoreboard players add #rm_coins ec.var 3
execute if score @s ec.tt_tier matches 3 run data modify storage evercraft:notify stage.c set value [{text:"★ ",color:"#E0B0FF"},{text:"+3 Forever Coins",color:"#E0B0FF"},{text:" — Trial Complete!",color:"gold"},{text:" ★",color:"#E0B0FF"}]
execute if score @s ec.tt_tier matches 3 run scoreboard players set #ndur ec.temp 45
execute if score @s ec.tt_tier matches 3 run function evercraft:util/notify/emit

execute if score @s ec.tt_tier matches 4 run scoreboard players add @s ec.coins 5
execute if score @s ec.tt_tier matches 4 run scoreboard players add #rm_coins ec.var 5
execute if score @s ec.tt_tier matches 4 run data modify storage evercraft:notify stage.c set value [{text:"★ ",color:"#E0B0FF"},{text:"+5 Forever Coins",color:"#E0B0FF",bold:true},{text:" — Trial Complete!",color:"gold"},{text:" ★",color:"#E0B0FF"}]
execute if score @s ec.tt_tier matches 4 run scoreboard players set #ndur ec.temp 45
execute if score @s ec.tt_tier matches 4 run function evercraft:util/notify/emit

execute if score @s ec.tt_tier matches 5 run scoreboard players add @s ec.coins 8
execute if score @s ec.tt_tier matches 5 run scoreboard players add #rm_coins ec.var 8
execute if score @s ec.tt_tier matches 5 run data modify storage evercraft:notify stage.c set value [{text:"★ ",color:"#E0B0FF"},{text:"+8 Forever Coins",color:"#E0B0FF",bold:true},{text:" — Trial Complete!",color:"gold"},{text:" ★",color:"#E0B0FF"}]
execute if score @s ec.tt_tier matches 5 run scoreboard players set #ndur ec.temp 45
execute if score @s ec.tt_tier matches 5 run function evercraft:util/notify/emit

execute if score @s ec.tt_tier matches 6 run scoreboard players add @s ec.coins 10
execute if score @s ec.tt_tier matches 6 run scoreboard players add #rm_coins ec.var 10
execute if score @s ec.tt_tier matches 6 run data modify storage evercraft:notify stage.c set value [{text:"★ ",color:"#E0B0FF"},{text:"+10 Forever Coins",color:"#E0B0FF",bold:true},{text:" — Trial Complete!",color:"gold"},{text:" ★",color:"#E0B0FF"}]
execute if score @s ec.tt_tier matches 6 run scoreboard players set #ndur ec.temp 45
execute if score @s ec.tt_tier matches 6 run function evercraft:util/notify/emit

execute if score @s ec.tt_tier matches 7 run scoreboard players add @s ec.coins 15
execute if score @s ec.tt_tier matches 7 run scoreboard players add #rm_coins ec.var 15
execute if score @s ec.tt_tier matches 7 run data modify storage evercraft:notify stage.c set value [{text:"★ ",color:"#E0B0FF"},{text:"+15 Forever Coins",color:"#E0B0FF",bold:true},{text:" — Trial Complete!",color:"gold"},{text:" ★",color:"#E0B0FF"}]
execute if score @s ec.tt_tier matches 7 run scoreboard players set #ndur ec.temp 45
execute if score @s ec.tt_tier matches 7 run function evercraft:util/notify/emit

execute if score @s ec.tt_tier matches 8 run scoreboard players add @s ec.coins 20
execute if score @s ec.tt_tier matches 8 run scoreboard players add #rm_coins ec.var 20
execute if score @s ec.tt_tier matches 8 run data modify storage evercraft:notify stage.c set value [{text:"★ ",color:"#E0B0FF"},{text:"+20 Forever Coins",color:"#E0B0FF",bold:true},{text:" — Trial Complete!",color:"gold"},{text:" ★",color:"#E0B0FF"}]
execute if score @s ec.tt_tier matches 8 run scoreboard players set #ndur ec.temp 45
execute if score @s ec.tt_tier matches 8 run function evercraft:util/notify/emit

execute if score @s ec.tt_tier matches 9 run scoreboard players add @s ec.coins 22
execute if score @s ec.tt_tier matches 9 run scoreboard players add #rm_coins ec.var 22
execute if score @s ec.tt_tier matches 9 run data modify storage evercraft:notify stage.c set value [{text:"★ ",color:"#E0B0FF"},{text:"+22 Forever Coins",color:"#E0B0FF",bold:true},{text:" — Trial Complete!",color:"gold"},{text:" ★",color:"#E0B0FF"}]
execute if score @s ec.tt_tier matches 9 run scoreboard players set #ndur ec.temp 45
execute if score @s ec.tt_tier matches 9 run function evercraft:util/notify/emit

execute if score @s ec.tt_tier matches 10 run scoreboard players add @s ec.coins 25
execute if score @s ec.tt_tier matches 10 run scoreboard players add #rm_coins ec.var 25
execute if score @s ec.tt_tier matches 10 run data modify storage evercraft:notify stage.c set value [{text:"★ ",color:"#E0B0FF"},{text:"+25 Forever Coins",color:"#E0B0FF",bold:true},{text:" — Grand Trial Complete!",color:"gold"},{text:" ★",color:"#E0B0FF"}]
execute if score @s ec.tt_tier matches 10 run scoreboard players set #ndur ec.temp 45
execute if score @s ec.tt_tier matches 10 run function evercraft:util/notify/emit

# Newcomer bonus: flat +1
execute if score @s ec.difficulty matches 1 run scoreboard players add @s ec.coins 1
execute if score @s ec.difficulty matches 1 run scoreboard players add #rm_coins ec.var 1

# Guild contribution (5x coins)
execute if score @s ec.guild_id matches 1.. if score @s ec.tt_tier matches 1 run function evercraft:guild/contribution/add {amount:5}
execute if score @s ec.guild_id matches 1.. if score @s ec.tt_tier matches 2 run function evercraft:guild/contribution/add {amount:10}
execute if score @s ec.guild_id matches 1.. if score @s ec.tt_tier matches 3 run function evercraft:guild/contribution/add {amount:15}
execute if score @s ec.guild_id matches 1.. if score @s ec.tt_tier matches 4 run function evercraft:guild/contribution/add {amount:25}
execute if score @s ec.guild_id matches 1.. if score @s ec.tt_tier matches 5 run function evercraft:guild/contribution/add {amount:40}
execute if score @s ec.guild_id matches 1.. if score @s ec.tt_tier matches 6 run function evercraft:guild/contribution/add {amount:50}
execute if score @s ec.guild_id matches 1.. if score @s ec.tt_tier matches 7 run function evercraft:guild/contribution/add {amount:75}
execute if score @s ec.guild_id matches 1.. if score @s ec.tt_tier matches 8 run function evercraft:guild/contribution/add {amount:100}
execute if score @s ec.guild_id matches 1.. if score @s ec.tt_tier matches 9 run function evercraft:guild/contribution/add {amount:150}
execute if score @s ec.guild_id matches 1.. if score @s ec.tt_tier matches 10 run function evercraft:guild/contribution/add {amount:250}

execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.experience_orb.pickup player @s ~ ~ ~ 0.5 1.5
