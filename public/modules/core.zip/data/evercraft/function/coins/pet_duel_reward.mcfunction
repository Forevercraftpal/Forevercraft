# Forever Coins — Pet duel reward (no DR scaling)
# Winner = 5 coins, Loser = 2 coins (participation)

# Winner coins
execute as @a[tag=pd.winner] run scoreboard players add @s ec.coins 5
execute as @a[tag=pd.winner] run scoreboard players add #rm_coins ec.var 5
data modify storage evercraft:notify stage.c set value [{text:"★ ",color:"#E0B0FF"},{text:"+5 Forever Coins",color:"#E0B0FF",bold:true},{text:" — Duel Victory!",color:"gold"},{text:" ★",color:"#E0B0FF"}]
scoreboard players set #ndur ec.temp 45
execute as @a[tag=pd.winner] run function evercraft:util/notify/emit
execute as @a[tag=pd.winner] if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.experience_orb.pickup player @s ~ ~ ~ 0.5 1.5

# Loser participation coins
execute as @a[tag=pd.loser] run scoreboard players add @s ec.coins 2
execute as @a[tag=pd.loser] run scoreboard players add #rm_coins ec.var 2
data modify storage evercraft:notify stage.c set value [{text:"★ ",color:"#E0B0FF"},{text:"+2 Forever Coins",color:"#E0B0FF"},{text:" — Participation",color:"gray"},{text:" ★",color:"#E0B0FF"}]
scoreboard players set #ndur ec.temp 45
execute as @a[tag=pd.loser] run function evercraft:util/notify/emit
execute as @a[tag=pd.loser] if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.experience_orb.pickup player @s ~ ~ ~ 0.3 1.5

# Newcomer bonus: flat +1 for winner
execute as @a[tag=pd.winner] if score @s ec.difficulty matches 1 run scoreboard players add @s ec.coins 1
execute as @a[tag=pd.winner] if score @s ec.difficulty matches 1 run scoreboard players add #rm_coins ec.var 1

# Guild contribution (5x winner coins = 25)
execute as @a[tag=pd.winner] if score @s ec.guild_id matches 1.. run function evercraft:guild/contribution/add {amount:25}
