# Dream Surge Event — Fishing Crate Roll (Ornate+ only)
# Replaces normal fishing crate loot table during event
# Distribution: Ornate 70%, Exquisite 28%, Mythical 2%

# Check inventory space before crate roll
execute store result score #inv_full ec.var run function evercraft:util/check_inv_full

# Roll 1-1000
execute store result score #roll ec.temp run random value 1..1000

# INV-FREE path: give the marker nugget. It fires <tier>/process, which DR-gates (grant vs downgrade)
# exactly like a normal fishing crate — so the Dream Rate cap already applies here, no extra gate needed.
# Default: Ornate (1-700)
execute if score #roll ec.temp matches 1..700 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:fishing/gameplay/fishing/crates/ornate/dummy
# Exquisite (701-980)
execute if score #roll ec.temp matches 701..980 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:fishing/gameplay/fishing/crates/exquisite/dummy
# Mythical (981-1000 = 2%)
execute if score #roll ec.temp matches 981.. if score #inv_full ec.var matches 0 run loot give @s loot evercraft:fishing/gameplay/fishing/crates/mythical/dummy

# INV-FULL path (crate DR audit 2026-06-06): the marker nugget can't be given when full, so <tier>/process
# never fires and the real crate would skip the Dream Rate gate. Apply the same cascade here, then spawn the
# capped tier's real crate. Event tiers 4=Ornate/5=Exquisite/6=Mythical; DR cap (luck x10): Myth>=250 /
# Exq>=150 / Ornate>=50, else Rare (3) — identical thresholds to the inv-free process gate.
execute if score #inv_full ec.var matches 1 run scoreboard players set #ev_tier ec.temp 4
execute if score #inv_full ec.var matches 1 if score #roll ec.temp matches 701..980 run scoreboard players set #ev_tier ec.temp 5
execute if score #inv_full ec.var matches 1 if score #roll ec.temp matches 981.. run scoreboard players set #ev_tier ec.temp 6
execute if score #inv_full ec.var matches 1 store result score #ev_dr ec.temp run attribute @s luck get 10
execute if score #inv_full ec.var matches 1 if score #ev_dr ec.temp matches ..249 if score #ev_tier ec.temp matches 6 run scoreboard players set #ev_tier ec.temp 5
execute if score #inv_full ec.var matches 1 if score #ev_dr ec.temp matches ..149 if score #ev_tier ec.temp matches 5.. run scoreboard players set #ev_tier ec.temp 4
execute if score #inv_full ec.var matches 1 if score #ev_dr ec.temp matches ..49 if score #ev_tier ec.temp matches 4.. run scoreboard players set #ev_tier ec.temp 3
execute if score #inv_full ec.var matches 1 if score #ev_tier ec.temp matches 3 at @s run loot spawn ~ ~ ~ loot evercraft:fishing/gameplay/fishing/crates/rare/1
execute if score #inv_full ec.var matches 1 if score #ev_tier ec.temp matches 4 at @s run loot spawn ~ ~ ~ loot evercraft:fishing/gameplay/fishing/crates/ornate/1
execute if score #inv_full ec.var matches 1 if score #ev_tier ec.temp matches 5 at @s run loot spawn ~ ~ ~ loot evercraft:fishing/gameplay/fishing/crates/exquisite/1
execute if score #inv_full ec.var matches 1 if score #ev_tier ec.temp matches 6 at @s run loot spawn ~ ~ ~ loot evercraft:fishing/gameplay/fishing/crates/mythical/1

# Sync prev_fish (delta already handled by check_crate before calling this)

data modify storage evercraft:notify stage.c set value [{text:"Inventory full! Your crate was dropped at your feet.",color:"yellow"}]
scoreboard players set #ndur ec.temp 45
execute if score #inv_full ec.var matches 1 run function evercraft:util/notify/emit
execute if score #inv_full ec.var matches 1 if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bass player @s ~ ~ ~ 1 0.5

# Achievement: Surge Surfer — count crates during surge
scoreboard players add @s ach.surge_crates 1
execute if score @s ach.surge_crates matches 10.. unless entity @s[advancements={evercraft:alternate/secrets/surge_surfer=true}] run advancement grant @s only evercraft:alternate/secrets/surge_surfer
