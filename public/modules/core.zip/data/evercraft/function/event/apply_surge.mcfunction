# Dream Surge — Shared activation logic
# OPT: Extracted from start/start_short/start_medium to eliminate triple duplication
# Consolidates 3x @a scans into 1 per-player dispatch

# Reset surge crate counter + apply modifier (single @a pass)
execute as @a run function evercraft:event/apply_surge_player

# Activation sounds
execute as @a at @s if score @s ec.fx_snd matches 1.. run playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 1 1.0
execute as @a at @s if score @s ec.fx_snd matches 1.. run playsound minecraft:block.end_portal.spawn master @s ~ ~ ~ 0.3 1.5
execute as @a at @s if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.ender_dragon.growl master @s ~ ~ ~ 0.2 1.5

# Title display
title @a times 10 60 20
title @a title {text:" "}
title @a subtitle [{text:"✦ DREAM SURGE ✦",color:"light_purple"}]
