# Dream Surge Event — STOP
# Called automatically when timer expires, or manually via /function evercraft:event/stop

# Deactivate event
scoreboard players set #ec_event_active ec.var 0
scoreboard players set #ec_event_timer ec.var 0

# Remove dream surge modifier from all players
execute as @a run attribute @s luck modifier remove ec_event_dream_surge

# Server-wide end announcement
data modify storage evercraft:notify stage.c set value [{text:"✦ DREAM SURGE ENDED ✦",color:"gray",bold:true},{text:" ✦",color:"gray"}]
scoreboard players set #ndur ec.temp 50
execute as @a run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"The realm's dreams return to normal...",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 40
execute as @a run function evercraft:util/notify/emit

# End sound
execute as @a at @s if score @s ec.fx_snd matches 1.. run playsound minecraft:block.beacon.deactivate master @s ~ ~ ~ 0.8 1.0
execute as @a at @s if score @s ec.fx_snd matches 1.. run playsound minecraft:block.amethyst_block.break master @s ~ ~ ~ 0.5 0.5

# Title display
title @a times 10 40 20
title @a title {text:" "}
title @a subtitle [{text:"Dream Surge Ended",color:"gray"}]
