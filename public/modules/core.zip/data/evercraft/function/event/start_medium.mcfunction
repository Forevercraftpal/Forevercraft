# Dream Surge Event — START (15 Minutes)
# Admin command: /function evercraft:event/start_medium

# Prevent double-activation
data modify storage evercraft:notify stage.c set value [{text:"Event is already active!",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute if score #ec_event_active ec.var matches 1 as @a run function evercraft:util/notify/emit
execute if score #ec_event_active ec.var matches 1 run return 0

# Activate event
scoreboard players set #ec_event_active ec.var 1
scoreboard players set #ec_event_timer ec.var 18000

# Announcement
data modify storage evercraft:notify stage.c set value [{text:"✦ DREAM SURGE ✦",color:"light_purple",bold:true},{text:" ✦",color:"light_purple"}]
scoreboard players set #ndur ec.temp 50
execute as @a run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"The realm's dreams intensify!",color:"dark_purple",italic:true}]
scoreboard players set #ndur ec.temp 40
execute as @a run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"For the next 15 minutes:",color:"gray"}]
scoreboard players set #ndur ec.temp 40
execute as @a run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"✧ ",color:"light_purple"},{text:"All Dreams boosted to 25%",color:"aqua"},{text:" ✧",color:"light_purple"}]
scoreboard players set #ndur ec.temp 40
execute as @a run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"✧ ",color:"light_purple"},{text:"Only Ornate+ crates will appear",color:"aqua"},{text:" ✧",color:"light_purple"}]
scoreboard players set #ndur ec.temp 40
execute as @a run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"✧ ",color:"light_purple"},{text:"Mythical crate chance boosted to 2%",color:"gold"},{text:" ✧",color:"light_purple"}]
scoreboard players set #ndur ec.temp 40
execute as @a run function evercraft:util/notify/emit

# Shared surge activation (modifiers, sounds, title)
function evercraft:event/apply_surge
