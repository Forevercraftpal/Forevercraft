# Dream Surge — Per-player setup (run as @a)
scoreboard players set @s ach.surge_crates 0
attribute @s luck modifier remove ec_event_dream_surge
attribute @s luck modifier add ec_event_dream_surge 25.0 add_value
