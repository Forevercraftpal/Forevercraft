# === FX · BESPOKE — SPIRIT "Voidpiercer" · Phase Shot (ability2) ===
# Run AS+AT the player (caller: spirit/abilities/voidpiercer/ability2 tail). The bearer phases out of
# space: a deep-purple void shroud collapses inward around them, the body half-unmade — over a hollow
# end-tone descending. Channel-gated; one-shot per cast.

# ── SOUND ── a descending phase-out tone (note-block + amethyst, no vocal grunt).
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 0.6 0.595
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.amethyst_block.resonate master @s ~ ~ ~ 0.6 0.5
execute if score @s ec.fx_snd matches 3.. run playsound minecraft:block.amethyst_block.hit master @s ~ ~ ~ 0.5 0.749

# ── VISUAL · REDUCED (1) ── a small purple shroud.
execute if score @s ec.fx_vis matches 1 run particle reverse_portal ~ ~1 ~ 0.3 0.6 0.3 0.05 10

# ── VISUAL · FULL & up (2..) ── the void shroud collapsing inward + the unmade body.
execute if score @s ec.fx_vis matches 2.. run particle reverse_portal ~ ~1 ~ 0.5 0.8 0.5 0.08 26
execute if score @s ec.fx_vis matches 2.. run particle dust{color:[0.42,0.12,0.62],scale:1.0} ~ ~1 ~ 0.5 0.8 0.5 0 18
execute if score @s ec.fx_vis matches 2.. run particle portal ~ ~1 ~ 0.4 0.7 0.4 0.6 14

# ── CRACKED (3..) ── a violet→void implosion bloom.
execute if score @s ec.fx_vis matches 3.. run particle dust_color_transition{from_color:[0.42,0.12,0.62],scale:1.6,to_color:[0.12,0.0,0.25]} ~ ~1.1 ~ 0.5 0.9 0.5 0.04 24
