# === FX · BESPOKE — JAVELIN "Valor's Reach" — thrown comet-gleam (ornate+) ===
# Run AS the player, ANCHORED EYES (caller: artifacts/javelin/on_thrown_hit, for #fx_tier 4..). One-shot when the
# thrown spear lands. A piercing gold comet drawn FORWARD in look-space — a bright gleam-trail along the throw line,
# the spear's valor reaching out. Bronze/gold core. Tier (4 ornate · 5 exquisite · 6 mythical) lengthens the comet;
# channel-gated. (One of four related Valor signatures — thrown reaches, melee thrusts, aegis guards, counter snaps.)

# ── SOUND ── a bright ringing gold note (the strike lands true); Full adds a high glint. Cracked = a clear chime.
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.6 1.498
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.45 1.782
execute if score @s ec.fx_snd matches 3.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.4 1.682

# ── VISUAL · REDUCED (1) ── a small gold gleam ahead.
execute if score @s ec.fx_vis matches 1 positioned ^0 ^0 ^1.2 run particle dust{color:[1.0,0.78,0.3],scale:0.8} ~ ~ ~ 0.1 0.1 0.1 0 4

# ── VISUAL · FULL & up (2..) ── a forward gold comet-gleam: a tight bronze-gold trail receding along the throw line.
execute if score @s ec.fx_vis matches 2.. positioned ^0 ^0 ^0.9 run particle dust{color:[0.85,0.6,0.2],scale:0.7} ~ ~ ~ 0 0 0 0 2
execute if score @s ec.fx_vis matches 2.. positioned ^0 ^0 ^1.3 run particle dust{color:[1.0,0.78,0.3],scale:0.85} ~ ~ ~ 0 0 0 0 2
execute if score @s ec.fx_vis matches 2.. positioned ^0 ^0 ^1.7 run particle dust{color:[1.0,0.85,0.4],scale:0.9} ~ ~ ~ 0 0 0 0 2
execute if score @s ec.fx_vis matches 2.. positioned ^0 ^0 ^2.0 run particle crit ~ ~ ~ 0.1 0.1 0.1 0.2 5
execute if score @s ec.fx_vis matches 2.. positioned ^0 ^0 ^2.0 run particle end_rod ~ ~ ~ 0.05 0.05 0.05 0.04 3

# ── EXQUISITE (5..) ── the comet reaches further with a brighter tip-flare.
execute if score @s ec.fx_vis matches 2.. if score #fx_tier ec.var matches 5.. positioned ^0 ^0 ^2.5 run particle dust{color:[1.0,0.88,0.45],scale:0.9} ~ ~ ~ 0.05 0.05 0.05 0 3

# ── MYTHICAL (6) ── a full piercing lance of light to the horizon + a gold glint-spray at the head.
execute if score @s ec.fx_vis matches 2.. if score #fx_tier ec.var matches 6 positioned ^0 ^0 ^3.0 run particle dust{color:[1.0,0.85,0.4],scale:1.0} ~ ~ ~ 0.08 0.08 0.08 0 4
execute if score @s ec.fx_vis matches 2.. if score #fx_tier ec.var matches 6 positioned ^0 ^0 ^3.0 run particle electric_spark ~ ~ ~ 0.12 0.12 0.12 0.3 4

# ── CRACKED (3..) ── a gold comet-bloom at the strike point (the valor blazes).
execute if score @s ec.fx_vis matches 3.. positioned ^0 ^0 ^2.0 run particle dust_color_transition{from_color:[1.0,0.78,0.3],scale:1.4,to_color:[1.0,0.95,0.6]} ~ ~ ~ 0.2 0.2 0.2 0.05 14
