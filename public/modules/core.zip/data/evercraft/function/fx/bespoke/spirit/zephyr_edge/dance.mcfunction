# === FX · BESPOKE — SPIRIT "Zephyr Edge" · Zephyr Dance (ability2) ===
# Run AS+AT the player (caller: spirit/abilities/zephyr_edge/ability2 tail). Wind charges gather: a swift
# rising spiral of pale-cyan air wraps the bearer, gusts curling up as the blink-strikes load — over an
# ascending wind-flute arpeggio. Channel-gated; one-shot on activation.

# ── SOUND ── an ascending wind-flute arpeggio (note-block, no vocal grunt).
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.flute master @s ~ ~ ~ 0.55 1.0
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.flute master @s ~ ~ ~ 0.55 1.335
execute if score @s ec.fx_snd matches 3.. run playsound minecraft:block.note_block.flute master @s ~ ~ ~ 0.5 1.682

# ── VISUAL · REDUCED (1) ── a small gust + cyan motes lifting.
execute if score @s ec.fx_vis matches 1 run particle gust ~ ~1 ~ 0.4 0.7 0.4 0.03 4
execute if score @s ec.fx_vis matches 1 run particle dust{color:[0.7,0.95,1.0],scale:0.8} ~ ~1 ~ 0.6 0.8 0.6 0 10

# ── VISUAL · FULL & up (2..) ── the rising air-spiral wrapping the bearer + curling gusts.
execute if score @s ec.fx_vis matches 2.. run particle dust{color:[0.7,0.95,1.0],scale:0.9} ~ ~1 ~ 0.7 1.0 0.7 0 30
execute if score @s ec.fx_vis matches 2.. run particle gust ~ ~0.6 ~ 0.5 0.8 0.5 0.04 6
execute if score @s ec.fx_vis matches 2.. run particle dust{color:[0.85,1.0,1.0],scale:0.6} ~ ~1.5 ~ 0.5 1.0 0.5 0 16
execute if score @s ec.fx_vis matches 2.. run particle end_rod ~ ~0.8 ~ 0.4 0.8 0.4 0.02 8

# ── CRACKED (3..) ── a cyan→white wind-bloom column lifting.
execute if score @s ec.fx_vis matches 3.. run particle dust_color_transition{from_color:[0.6,0.9,1.0],scale:1.5,to_color:[1.0,1.0,1.0]} ~ ~1.3 ~ 0.6 1.2 0.6 0.05 30
