# === FX · BESPOKE — HUNTER "Wild Hunt" — precision mark (ornate+) ===
# Run AS + AT the player (caller: artifacts/hunter/precision_hit, for #fx_tier 4..). One-shot when the precision
# shot lands. The predator marks the prey: a green crit/rune flicker at the strike + a LOW hunting-horn note
# (note-block didgeridoo, NOT an animal call) + a slow amber tracking pulse rippling out. Patient, lethal, natural.
# Forest green + amber. Tier (4 ornate · 5 exquisite · 6 mythical) deepens the hunt; channel-gated.

# ── SOUND ── a low hunting-horn (didgeridoo) call; Full adds a settled bass note under it. Cracked = a resonant tail.
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.didgeridoo master @s ~ ~ ~ 0.6 0.595
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 0.5 0.794
execute if score @s ec.fx_snd matches 3.. run playsound minecraft:block.amethyst_block.resonate master @s ~ ~ ~ 0.4 0.7

# ── VISUAL · REDUCED (1) ── a small green mark-flicker.
execute if score @s ec.fx_vis matches 1 run particle crit ~ ~1 ~ 0.25 0.3 0.25 0.2 5

# ── VISUAL · FULL & up (2..) ── a green rune-flicker at the strike + the amber tracking pulse ring on the ground.
execute if score @s ec.fx_vis matches 2.. run particle dust{color:[0.3,0.7,0.25],scale:0.9} ~ ~1 ~ 0.35 0.45 0.35 0 12
execute if score @s ec.fx_vis matches 2.. run particle crit ~ ~1 ~ 0.3 0.4 0.3 0.25 8
execute if score @s ec.fx_vis matches 2.. run particle dust{color:[0.9,0.65,0.25],scale:1.0} ~ ~0.15 ~ 1.2 0.04 1.2 0 14

# ── EXQUISITE (5..) ── a brighter amber mark-glyph hovering at the prey + a second horn tone.
execute if score @s ec.fx_vis matches 2.. if score #fx_tier ec.var matches 5.. run particle dust{color:[0.95,0.7,0.3],scale:0.85} ~ ~1.2 ~ 0.2 0.3 0.2 0 8
execute if score @s ec.fx_snd matches 2.. if score #fx_tier ec.var matches 5.. run playsound minecraft:block.note_block.didgeridoo master @s ~ ~ ~ 0.4 0.794

# ── MYTHICAL (6) ── a wider green-and-amber tracking pulse (the whole hunt closes in) + a few drifting motes.
execute if score @s ec.fx_vis matches 2.. if score #fx_tier ec.var matches 6 run particle dust{color:[0.35,0.75,0.3],scale:1.0} ~ ~0.15 ~ 2.0 0.04 2.0 0 18
execute if score @s ec.fx_vis matches 2.. if score #fx_tier ec.var matches 6 run particle dust{color:[0.9,0.65,0.25],scale:0.8} ~ ~1 ~ 0.5 0.5 0.5 0 8

# ── CRACKED (3..) ── an amber flash + a green→amber hunting-pulse pillar (the mark blazes).
execute if score @s ec.fx_vis matches 3.. run particle flash{color:[0.6,0.85,0.4,1.0]} ~ ~1 ~
execute if score @s ec.fx_vis matches 3.. run particle dust_color_transition{from_color:[0.3,0.7,0.25],scale:1.6,to_color:[0.95,0.7,0.3]} ~ ~1.2 ~ 0.4 0.7 0.4 0.05 26
