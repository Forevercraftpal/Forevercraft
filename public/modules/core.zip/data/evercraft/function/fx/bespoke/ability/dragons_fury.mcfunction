# === FX · BESPOKE — ABILITY "Dragon's Fury" (Dragonmaster Sword · mythical breath cone) ===
# Run AS+AT the player (caller: artifacts/abilities/dragons_fury tail; the ability already burned the cone in
# look-space). A widening wyrmfire breath rolls out front — dragon_breath haze + flame deepening to ember,
# over a draconic growl-note (carve-out) + a low brass swell. Channel-gated. Apex — ladder-gated, no #fx_tier.

# ── SOUND ── a draconic exhale (growl carve-out for the dragon weapon) over a low resonance.
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.didgeridoo master @s ~ ~ ~ 0.5 0.45
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:entity.ender_dragon.growl master @s ~ ~ ~ 0.3 1.4
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 0.4 0.667
execute if score @s ec.fx_snd matches 3.. run playsound minecraft:block.fire.ambient master @s ~ ~ ~ 0.7 0.7

# ── VISUAL · REDUCED (1) ── a short breath puff in front.
execute if score @s ec.fx_vis matches 1 anchored eyes positioned ^0 ^-0.2 ^1.5 run particle dragon_breath ~ ~ ~ 0.3 0.3 0.3 0.01 6

# ── VISUAL · FULL & up (2..) ── a widening breath cone: haze near, flame mid, ember tip.
execute if score @s ec.fx_vis matches 2.. anchored eyes positioned ^0 ^-0.2 ^1.2 run particle dragon_breath ~ ~ ~ 0.25 0.25 0.2 0.005 8
execute if score @s ec.fx_vis matches 2.. anchored eyes positioned ^0 ^-0.2 ^2.0 run particle flame ~ ~ ~ 0.4 0.35 0.4 0.01 10
execute if score @s ec.fx_vis matches 2.. anchored eyes positioned ^0 ^-0.2 ^2.8 run particle dust{color:[1.0,0.45,0.1],scale:1.1} ~ ~ ~ 0.6 0.45 0.6 0 12

# ── CRACKED (3..) ── a roaring ember→crimson bloom at the cone's reach + soul-fire flecks.
execute if score @s ec.fx_vis matches 3.. anchored eyes positioned ^0 ^-0.2 ^3.2 run particle dust_color_transition{from_color:[1.0,0.5,0.12],scale:1.8,to_color:[0.65,0.08,0.04]} ~ ~ ~ 0.7 0.5 0.7 0.05 20
execute if score @s ec.fx_vis matches 3.. anchored eyes positioned ^0 ^-0.2 ^2.4 run particle soul_fire_flame ~ ~ ~ 0.4 0.35 0.5 0.02 10
