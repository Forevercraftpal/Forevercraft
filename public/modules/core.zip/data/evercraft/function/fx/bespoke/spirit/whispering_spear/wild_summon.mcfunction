# === FX · BESPOKE — SPIRIT "Whispering Spear" · Wild Summon (ability1) ===
# Run AS+AT the player (caller: spirit/abilities/whispering_spear/ability1 tail). The spear whispers and the
# wild answers: a ghostly white-blue soul-gust spirals out, ethereal wisps rise where the spectral beasts
# coalesce — over a hollow whispering chord. Channel-gated; one-shot per cast.

# ── SOUND ── a whispering ethereal chord (note-block flute triad, no vocal grunt).
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.flute master @s ~ ~ ~ 0.6 0.794
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.flute master @s ~ ~ ~ 0.6 1.122
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.flute master @s ~ ~ ~ 0.5 0.891
execute if score @s ec.fx_snd matches 3.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.5 1.335

# ── VISUAL · REDUCED (1) ── a small soul puff + ghostly motes.
execute if score @s ec.fx_vis matches 1 run particle soul ~ ~1 ~ 0.6 0.6 0.6 0.02 8
execute if score @s ec.fx_vis matches 1 run particle dust{color:[0.78,0.9,1.0],scale:0.9} ~ ~1 ~ 0.7 0.7 0.7 0 8

# ── VISUAL · FULL & up (2..) ── the ethereal soul-gust + rising wisps where the beasts gather.
execute if score @s ec.fx_vis matches 2.. run particle soul ~ ~1 ~ 1.2 0.8 1.2 0.04 24
execute if score @s ec.fx_vis matches 2.. run particle dust{color:[0.78,0.9,1.0],scale:1.0} ~ ~1 ~ 1.3 0.9 1.3 0 26
execute if score @s ec.fx_vis matches 2.. run particle gust ~ ~0.6 ~ 0.6 0.4 0.6 0.04 6
execute if score @s ec.fx_vis matches 2.. run particle soul_fire_flame ~ ~1.2 ~ 0.8 0.7 0.8 0.02 10

# ── CRACKED (3..) ── a white-blue soul-bloom column rising on the spectral wind.
execute if score @s ec.fx_vis matches 3.. run particle dust_color_transition{from_color:[0.6,0.8,1.0],scale:1.5,to_color:[0.95,0.98,1.0]} ~ ~1.4 ~ 1.0 1.1 1.0 0.05 30
execute if score @s ec.fx_vis matches 3.. run particle soul ~ ~1.6 ~ 0.6 0.9 0.6 0.06 12
