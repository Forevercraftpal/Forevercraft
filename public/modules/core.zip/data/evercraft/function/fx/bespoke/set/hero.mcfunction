# === FX · BESPOKE — SET "Hero/Eternal" · Hero's Dance (active) ===
# Run AS+AT the player (caller: artifacts/sets/hero/on_item_use, past the cooldown gate, after the dash).
# Heroic radiance blazes: a gold-white halo flares around the wearer, end-rod light streaks rise, and a
# triumphant rising chime arpeggio swells (the hero's resolve). Channel-gated; one-shot per 60s cast.

# ── SOUND ── a triumphant rising chime arpeggio (bell triad) + a bright pling.
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.8 0.794
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.8 1.0
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.8 1.189
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.pling master @s ~ ~ ~ 0.5 1.335
execute if score @s ec.fx_snd matches 3.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.6 0.7

# ── VISUAL · REDUCED (1) ── a small gold-white glint + a light mote.
execute if score @s ec.fx_vis matches 1 run particle dust{color:[1.0,0.95,0.7],scale:0.9} ~ ~1 ~ 0.5 0.6 0.5 0 10
execute if score @s ec.fx_vis matches 1 run particle end_rod ~ ~1 ~ 0.4 0.5 0.4 0.02 6

# ── VISUAL · FULL & up (2..) ── a gold-white radiant halo + rising light streaks + a glowing ring.
execute if score @s ec.fx_vis matches 2.. run particle dust{color:[1.0,0.95,0.7],scale:1.1} ~ ~1.2 ~ 0.9 0.9 0.9 0 26
execute if score @s ec.fx_vis matches 2.. run particle end_rod ~ ~1.0 ~ 0.6 1.0 0.6 0.05 22
execute if score @s ec.fx_vis matches 2.. run particle dust{color:[1.0,0.85,0.35],scale:1.0} ~ ~0.2 ~ 2.2 0.12 2.2 0 22
execute if score @s ec.fx_vis matches 2.. run particle glow ~ ~1.2 ~ 1.2 0.8 1.2 0 12

# ── CRACKED (3..) ── a white flash + a gold→radiant-white halo pillar + a firework spark.
execute if score @s ec.fx_vis matches 3.. run particle flash{color:[1.0,0.95,0.7,1.0]} ~ ~1.2 ~
execute if score @s ec.fx_vis matches 3.. run particle dust_color_transition{from_color:[1.0,0.78,0.25],scale:2.0,to_color:[1.0,1.0,0.92]} ~ ~1.4 ~ 0.8 1.2 0.8 0.05 38
execute if score @s ec.fx_vis matches 3.. run particle firework ~ ~1.6 ~ 0.6 0.6 0.6 0.06 24
