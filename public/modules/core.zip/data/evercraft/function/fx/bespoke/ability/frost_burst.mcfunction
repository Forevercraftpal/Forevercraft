# === FX · BESPOKE — ABILITY "Frost Burst" (Leviathan Axe · AoE freeze) ===
# Run AS+AT the player (caller: artifacts/abilities/frost_burst tail; the burst already chilled the radius).
# An icy shatter-ring radiates out: snowflakes + a pale frost-dust web + ice shards, over a crystalline chime
# (high amethyst) + a glassy crack note. Channel-gated; one-shot per hit. Apex — ladder-gated, no #fx_tier.

# ── SOUND ── a crystalline frost chime + a glassy chord (musical, no vocal grunt).
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.4 1.587
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.4 1.335
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.35 1.7
execute if score @s ec.fx_snd matches 3.. run playsound minecraft:block.amethyst_block.resonate master @s ~ ~ ~ 0.5 1.4

# ── VISUAL · REDUCED (1) ── a small frost pop.
execute if score @s ec.fx_vis matches 1 run particle snowflake ~ ~1 ~ 0.6 0.5 0.6 0.02 8

# ── VISUAL · FULL & up (2..) ── an outward shatter-ring: snowflakes + a pale-blue frost web + ice shards.
execute if score @s ec.fx_vis matches 2.. run particle snowflake ~ ~1 ~ 1.8 0.5 1.8 0.02 24
execute if score @s ec.fx_vis matches 2.. run particle dust{color:[0.6,0.85,1.0],scale:0.9} ~ ~1 ~ 1.8 0.5 1.8 0 16
execute if score @s ec.fx_vis matches 2.. run particle block{block_state:"minecraft:blue_ice"} ~ ~1 ~ 1.5 0.4 1.5 0.1 12

# ── CRACKED (3..) ── a white frost-flash + an ice→white shatter bloom (the axe answers).
execute if score @s ec.fx_vis matches 3.. run particle flash{color:[0.7,0.9,1.0,1.0]} ~ ~1 ~
execute if score @s ec.fx_vis matches 3.. run particle dust_color_transition{from_color:[0.55,0.82,1.0],scale:1.7,to_color:[1.0,1.0,1.0]} ~ ~1.1 ~ 2.0 0.6 2.0 0.05 28
