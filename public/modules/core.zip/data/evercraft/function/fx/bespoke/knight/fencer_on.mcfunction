# === FX · BESPOKE — KNIGHT "Steel & Honor" — fencing stance ENGAGES (ornate+) ===
# Run AS + AT the player (caller: artifacts/knight/fencer_on, for #fx_tier 4..). One-shot when the blade is freed
# from the shield. Discipline made visible: a clean white-silver steel gleam-line drawn UPWARD at the player's side
# (a blade brought to guard) + a bright noble bell ring. Restrained — the elegant counterpoint to the flashy classes.
# A single gold accent mote marks the honor of the house. Tier (4 ornate · 5 exquisite · 6 mythical) refines; gated.

# ── SOUND ── a crisp noble bell (the salute); Full adds the fifth = a clean two-note chord. Cracked = an amethyst ring.
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.6 1.335
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.5 2.0
execute if score @s ec.fx_snd matches 3.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.4 1.682

# ── VISUAL · REDUCED (1) ── a small steel glint at the guard.
execute if score @s ec.fx_vis matches 1 run particle dust{color:[0.88,0.9,0.95],scale:0.8} ~ ~1 ~ 0.2 0.4 0.2 0 6

# ── VISUAL · FULL & up (2..) ── a vertical steel gleam-line rising to guard + a crisp white edge-flash + one gold accent.
execute if score @s ec.fx_vis matches 2.. run particle dust{color:[0.85,0.88,0.94],scale:0.9} ~ ~0.6 ~ 0.12 0.5 0.12 0 8
execute if score @s ec.fx_vis matches 2.. run particle dust{color:[0.95,0.97,1.0],scale:0.7} ~ ~1.3 ~ 0.1 0.25 0.1 0 6
execute if score @s ec.fx_vis matches 2.. run particle crit ~ ~1 ~ 0.15 0.5 0.15 0.1 8
execute if score @s ec.fx_vis matches 2.. run particle dust{color:[0.95,0.78,0.25],scale:0.9} ~ ~1.4 ~ 0.05 0.05 0.05 0 1

# ── EXQUISITE (5..) ── a brighter blade-light at the tip + a soft high bell third (the chord fills out).
execute if score @s ec.fx_vis matches 2.. if score #fx_tier ec.var matches 5.. run particle end_rod ~ ~1.5 ~ 0.06 0.15 0.06 0.01 4
execute if score @s ec.fx_snd matches 2.. if score #fx_tier ec.var matches 5.. run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.35 1.682

# ── MYTHICAL (6) ── a gilded gleam — the gold accent blooms into a small honor-ring at the hilt.
execute if score @s ec.fx_vis matches 2.. if score #fx_tier ec.var matches 6 run particle dust{color:[1.0,0.82,0.3],scale:1.0} ~ ~1 ~ 0.45 0.15 0.45 0 12

# ── CRACKED (3..) ── a steel-white flash + a silver→gold gleam pillar (the salute, made cinematic).
execute if score @s ec.fx_vis matches 3.. run particle flash{color:[0.9,0.92,1.0,1.0]} ~ ~1.2 ~
execute if score @s ec.fx_vis matches 3.. run particle dust_color_transition{from_color:[0.88,0.9,0.96],scale:1.6,to_color:[1.0,0.85,0.35]} ~ ~1.2 ~ 0.25 0.7 0.25 0.05 24
