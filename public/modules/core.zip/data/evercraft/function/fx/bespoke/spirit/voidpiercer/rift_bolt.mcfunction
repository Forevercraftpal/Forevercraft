# === FX · BESPOKE — SPIRIT "Voidpiercer" · Rift Bolt (ability1) ===
# Run AS+AT the player (caller: spirit/abilities/voidpiercer/ability1 tail). The weapon tears space: a
# deep-purple rift cracks open at the muzzle and a void bolt pierces forward (look-space), over a piercing
# end-tone. Channel-gated; one-shot per cast.

# ── SOUND ── a piercing void tear (note-block + amethyst, no vocal grunt).
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 0.6 0.5
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.amethyst_block.resonate master @s ~ ~ ~ 0.6 0.794
execute if score @s ec.fx_snd matches 3.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.5 0.5

# ── VISUAL · REDUCED (1) ── a small purple tear at the muzzle.
execute if score @s ec.fx_vis matches 1 anchored eyes positioned ^0 ^-0.1 ^1.0 run particle reverse_portal ~ ~ ~ 0.2 0.2 0.2 0.05 6

# ── VISUAL · FULL & up (2..) ── the rift-tear + a void bolt streaking down the line of sight.
execute if score @s ec.fx_vis matches 2.. anchored eyes positioned ^0 ^-0.1 ^1.0 run particle reverse_portal ~ ~ ~ 0.25 0.3 0.25 0.08 18
execute if score @s ec.fx_vis matches 2.. anchored eyes positioned ^0 ^-0.1 ^1.0 run particle dust{color:[0.42,0.12,0.62],scale:1.0} ~ ~ ~ 0.2 0.25 0.2 0 10
execute if score @s ec.fx_vis matches 2.. anchored eyes positioned ^0 ^-0.1 ^2.5 run particle portal ~ ~ ~ 0.15 0.15 0.6 0.6 14
execute if score @s ec.fx_vis matches 2.. anchored eyes positioned ^0 ^-0.1 ^4.0 run particle dust{color:[0.5,0.18,0.7],scale:0.9} ~ ~ ~ 0.1 0.1 0.4 0 8

# ── CRACKED (3..) ── a violet→void bloom at the tear (space splitting).
execute if score @s ec.fx_vis matches 3.. anchored eyes positioned ^0 ^-0.1 ^1.2 run particle dust_color_transition{from_color:[0.42,0.12,0.62],scale:1.6,to_color:[0.15,0.0,0.3]} ~ ~ ~ 0.35 0.4 0.35 0.05 20
