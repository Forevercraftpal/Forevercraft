# === FX · BESPOKE — HEALER "Endless Ambrosia" (Mythical, full heal) ===
# Run AT the player (caller: artifacts/healer/use/ambrosia tail, for #fx_tier 4..). The food of the gods —
# a radiant full-body bloom of gold-white light washes out, totem petals rising on a warm holy chord.
# #fx_tier is 6 (mythical) here but kept tier-aware for consistency. Channel-gated; one-shot.

# ── SOUND ── a warm uplifting chord (bell triad C·E·G) + a soft holy shimmer at Cracked.
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.6 0.707
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.6 0.891
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.6 1.059
execute if score @s ec.fx_snd matches 3.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.5 1.587

# ── VISUAL · REDUCED (1) ── a small gold light puff.
execute if score @s ec.fx_vis matches 1 run particle dust{color:[1.0,0.9,0.5],scale:1.0} ~ ~1 ~ 0.6 0.8 0.6 0 14

# ── VISUAL · FULL & up (2..) ── a radiant gold-white full-body bloom + rising light + warm motes.
execute if score @s ec.fx_vis matches 2.. run particle dust{color:[1.0,0.92,0.55],scale:1.2} ~ ~1.2 ~ 0.8 1.2 0.8 0 36
execute if score @s ec.fx_vis matches 2.. run particle end_rod ~ ~0.4 ~ 0.6 1.0 0.6 0.04 22
execute if score @s ec.fx_vis matches 2.. run particle glow ~ ~1.4 ~ 0.7 1.0 0.7 0.08 18

# ── MYTHICAL (6) ── a fuller golden corona + a halo lift.
execute if score @s ec.fx_vis matches 2.. if score #fx_tier ec.var matches 6 run particle dust{color:[1.0,0.85,0.4],scale:1.4} ~ ~1.8 ~ 0.9 1.0 0.9 0 26

# ── CRACKED (3..) ── a radiant flash + a gold→white holy pillar + a totem petal spray.
execute if score @s ec.fx_vis matches 3.. run particle flash{color:[1.0,0.95,0.7,1.0]} ~ ~1.2 ~
execute if score @s ec.fx_vis matches 3.. run particle dust_color_transition{from_color:[1.0,0.88,0.45],scale:2.0,to_color:[1.0,1.0,0.95]} ~ ~1.4 ~ 0.7 1.4 0.7 0.05 44
execute if score @s ec.fx_vis matches 3.. run particle totem_of_undying ~ ~1.5 ~ 0.8 1.0 0.8 0.3 30
