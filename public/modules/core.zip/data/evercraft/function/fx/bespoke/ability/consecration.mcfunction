# === FX · BESPOKE — ABILITY "Consecration" (Bone Cudgel · holy aura on undead-kill) ===
# Run AS+AT the player (caller: artifacts/abilities/consecration tail; the holy aura already revealed nearby
# undead). A rising gold light-ring + a choir-like chime swell + an enchant shimmer, over a soft bell triad.
# Channel-gated; one-shot per undead kill (low-frequency). Apex — ladder-gated, no #fx_tier.

# ── SOUND ── a soft consecrating bell chord + a choir chime (musical, no vocal grunt).
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.45 1.059
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.45 1.335
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.chime master @s ~ ~ ~ 0.4 1.587
execute if score @s ec.fx_snd matches 3.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.45 1.7

# ── VISUAL · REDUCED (1) ── a small holy pop.
execute if score @s ec.fx_vis matches 1 run particle end_rod ~ ~1 ~ 0.3 0.4 0.3 0.02 5

# ── VISUAL · FULL & up (2..) ── a rising gold light-ring + a holy enchant shimmer.
execute if score @s ec.fx_vis matches 2.. run particle end_rod ~ ~1 ~ 0.6 0.5 0.6 0.03 12
execute if score @s ec.fx_vis matches 2.. run particle dust{color:[1.0,0.92,0.5],scale:0.9} ~ ~1 ~ 0.6 0.5 0.6 0 12
execute if score @s ec.fx_vis matches 2.. run particle enchant ~ ~1.4 ~ 0.5 0.6 0.5 0.6 10

# ── CRACKED (3..) ── a gold→white sanctifying bloom + a soft radiant flash.
execute if score @s ec.fx_vis matches 3.. run particle flash{color:[1.0,0.95,0.65,1.0]} ~ ~1 ~
execute if score @s ec.fx_vis matches 3.. run particle dust_color_transition{from_color:[1.0,0.9,0.45],scale:1.6,to_color:[1.0,1.0,0.92]} ~ ~1.2 ~ 0.6 0.6 0.6 0.05 22
