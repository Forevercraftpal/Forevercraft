# === FX · BESPOKE — ABILITY "Permafrost" (Frost Pickaxe · deep-freeze single target) ===
# Run AS+AT the player (caller: artifacts/abilities/permafrost tail; the deep-freeze already locked the foe).
# A focused freeze-spike crystallises on the struck foe: rising ice crystals + a tight snowflake column +
# a frost-rime gleam, over a crystalline chime + a deep glassy lock. Channel-gated; one-shot. Apex — ladder.

# ── SOUND ── a crystalline freeze-lock chord (musical, no vocal grunt).
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.4 1.189
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.4 1.059
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.35 1.335
execute if score @s ec.fx_snd matches 3.. run playsound minecraft:block.amethyst_block.resonate master @s ~ ~ ~ 0.5 0.794

# ── VISUAL · REDUCED (1) ── a small frost spike on the foe.
execute if score @s ec.fx_vis matches 1 as @e[type=!player,type=!item,distance=..5,limit=1,sort=nearest,nbt={HurtTime:10s}] at @s run particle snowflake ~ ~0.6 ~ 0.3 0.5 0.3 0.02 6

# ── VISUAL · FULL & up (2..) ── a rising ice-crystal column on the foe + a frost-rime gleam.
execute if score @s ec.fx_vis matches 2.. as @e[type=!player,type=!item,distance=..5,limit=1,sort=nearest,nbt={HurtTime:10s}] at @s run particle snowflake ~ ~0.5 ~ 0.25 0.7 0.25 0.04 14
execute if score @s ec.fx_vis matches 2.. as @e[type=!player,type=!item,distance=..5,limit=1,sort=nearest,nbt={HurtTime:10s}] at @s run particle block{block_state:"minecraft:blue_ice"} ~ ~0.6 ~ 0.3 0.6 0.3 0.05 10
execute if score @s ec.fx_vis matches 2.. as @e[type=!player,type=!item,distance=..5,limit=1,sort=nearest,nbt={HurtTime:10s}] at @s run particle dust{color:[0.65,0.88,1.0],scale:0.9} ~ ~0.7 ~ 0.3 0.6 0.3 0 10

# ── CRACKED (3..) ── an ice→white deep-freeze bloom encasing the foe.
execute if score @s ec.fx_vis matches 3.. as @e[type=!player,type=!item,distance=..5,limit=1,sort=nearest,nbt={HurtTime:10s}] at @s run particle dust_color_transition{from_color:[0.55,0.82,1.0],scale:1.6,to_color:[1.0,1.0,1.0]} ~ ~0.8 ~ 0.4 0.8 0.4 0.05 22
execute if score @s ec.fx_vis matches 3.. as @e[type=!player,type=!item,distance=..5,limit=1,sort=nearest,nbt={HurtTime:10s}] at @s run particle end_rod ~ ~0.8 ~ 0.2 0.7 0.2 0.02 6
