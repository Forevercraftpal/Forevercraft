# === FX · BESPOKE — ABILITY "Dragon Bane" (Dragonslayer · ornate, +10 vs Ender Dragon) ===
# Run AS+AT the player (caller: artifacts/abilities/dragon_bane tail; the blow lands only on the dragon).
# A draconic-bane flare: a purple-violet dragon-breath burst toward the wyrm + a bane-gold edge glint, over a
# resonant low note + a high ring (the slayer's mark). Channel-gated; fires only when the dragon is struck.

# ── SOUND ── a deep slayer's toll + a high ringing edge (musical, draconic resonance carve-out).
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 0.5 0.5
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:entity.ender_dragon.growl master @s ~ ~ ~ 0.25 0.7
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.4 1.587
execute if score @s ec.fx_snd matches 3.. run playsound minecraft:block.amethyst_block.resonate master @s ~ ~ ~ 0.5 0.5

# ── VISUAL · REDUCED (1) ── a small bane-violet puff.
execute if score @s ec.fx_vis matches 1 run particle dragon_breath ~ ~1 ~ 0.4 0.4 0.4 0.01 6

# ── VISUAL · FULL & up (2..) ── a violet dragon-breath flare around the bearer + a bane-gold edge glint.
execute if score @s ec.fx_vis matches 2.. run particle dragon_breath ~ ~1 ~ 0.5 0.5 0.5 0.02 12
execute if score @s ec.fx_vis matches 2.. run particle dust{color:[0.6,0.2,0.85],scale:1.0} ~ ~1 ~ 0.5 0.5 0.5 0 10
execute if score @s ec.fx_vis matches 2.. anchored eyes positioned ^0.4 ^-0.1 ^1.0 run particle dust{color:[1.0,0.85,0.35],scale:0.8} ~ ~ ~ 0.15 0.4 0.15 0 6

# ── CRACKED (3..) ── a violet→gold bane bloom + an end-rod gleam (the dragonslayer's mark blazes).
execute if score @s ec.fx_vis matches 3.. run particle dust_color_transition{from_color:[0.55,0.18,0.82],scale:1.8,to_color:[1.0,0.82,0.3]} ~ ~1.2 ~ 0.6 0.7 0.6 0.05 22
execute if score @s ec.fx_vis matches 3.. run particle end_rod ~ ~1 ~ 0.3 0.6 0.3 0.04 8
