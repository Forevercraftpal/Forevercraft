# === FX · BESPOKE — SPIRIT "Nite" · Dimensional Rift (ability1) ===
# Run AS+AT the player (caller: spirit/abilities/nite/ability1 tail). A silent night-cut: a deep-indigo
# line of severed space is drawn down the line of sight (look-space), dark wisps trailing the seam — over
# a hushed low night-tone. Channel-gated; one-shot per cast.

# ── SOUND ── a hushed cut (note-block low + a soft amethyst seam, no vocal grunt).
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 0.55 0.5
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.amethyst_block.hit master @s ~ ~ ~ 0.45 0.595
execute if score @s ec.fx_snd matches 3.. run playsound minecraft:block.amethyst_block.resonate master @s ~ ~ ~ 0.45 0.5

# ── VISUAL · REDUCED (1) ── a short indigo seam ahead.
execute if score @s ec.fx_vis matches 1 anchored eyes positioned ^0 ^0 ^2.5 run particle dust{color:[0.22,0.14,0.45],scale:1.0} ~ ~ ~ 0.1 0.1 1.2 0 10

# ── VISUAL · FULL & up (2..) ── the severed-space line drawn forward + dark wisps along the seam.
execute if score @s ec.fx_vis matches 2.. anchored eyes positioned ^0 ^0 ^3.0 run particle dust{color:[0.22,0.14,0.45],scale:1.1} ~ ~ ~ 0.1 0.12 2.5 0 30
execute if score @s ec.fx_vis matches 2.. anchored eyes positioned ^0 ^0 ^3.0 run particle reverse_portal ~ ~ ~ 0.1 0.15 2.2 0.04 18
execute if score @s ec.fx_vis matches 2.. anchored eyes positioned ^0 ^0 ^3.0 run particle smoke ~ ~ ~ 0.12 0.12 2.2 0.005 14

# ── CRACKED (3..) ── an indigo→void bloom that lingers in the seam.
execute if score @s ec.fx_vis matches 3.. anchored eyes positioned ^0 ^0 ^3.0 run particle dust_color_transition{from_color:[0.22,0.14,0.45],scale:1.4,to_color:[0.05,0.0,0.12]} ~ ~ ~ 0.12 0.15 2.4 0.03 28
