# === FX · BESPOKE — SPIRIT "Ellegaard's Trident" · Maelstrom (ability1) ===
# Run AS+AT the player (caller: spirit/abilities/ellegaard_trident/ability1 tail). The engineer's craft —
# a redstone-charged vortex: electric red-orange sparks crackle and arc as the spiral spins up, the prongs
# throwing live current — over a bright workshop pling. Channel-gated; one-shot on activation (the per-tick
# pull is the ability's own engine).

# ── SOUND ── a bright redstone-workshop pling rising into a spark-chime (note-block, no vocal grunt).
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.pling master @s ~ ~ ~ 0.6 0.794
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.pling master @s ~ ~ ~ 0.6 1.189
execute if score @s ec.fx_snd matches 3.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.5 1.335

# ── VISUAL · REDUCED (1) ── a few sparks + red-orange motes.
execute if score @s ec.fx_vis matches 1 run particle electric_spark ~ ~1 ~ 0.8 0.6 0.8 0.3 10
execute if score @s ec.fx_vis matches 1 run particle dust{color:[1.0,0.35,0.15],scale:0.9} ~ ~1 ~ 0.8 0.7 0.8 0 8

# ── VISUAL · FULL & up (2..) ── the charged vortex: arcing sparks spiral up, red-orange current rings the spin.
execute if score @s ec.fx_vis matches 2.. run particle electric_spark ~ ~1 ~ 1.3 0.9 1.3 0.5 30
execute if score @s ec.fx_vis matches 2.. run particle dust{color:[1.0,0.35,0.15],scale:1.1} ~ ~1 ~ 1.3 0.9 1.3 0 26
execute if score @s ec.fx_vis matches 2.. run particle dust{color:[1.0,0.6,0.2],scale:0.8} ~ ~1.4 ~ 0.9 0.8 0.9 0 16
execute if score @s ec.fx_vis matches 2.. run particle crit ~ ~0.8 ~ 0.7 0.6 0.7 0.4 10

# ── CRACKED (3..) ── a red→amber spark-bloom column (the engine overcharges).
execute if score @s ec.fx_vis matches 3.. run particle dust_color_transition{from_color:[1.0,0.3,0.1],scale:1.5,to_color:[1.0,0.75,0.25]} ~ ~1.3 ~ 1.0 1.1 1.0 0.05 30
execute if score @s ec.fx_vis matches 3.. run particle electric_spark ~ ~1.6 ~ 0.8 0.9 0.8 0.6 14
