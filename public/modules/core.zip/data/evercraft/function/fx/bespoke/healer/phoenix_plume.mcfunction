# === FX · BESPOKE — HEALER "Phoenix Plume" (Ornate, cleanse) ===
# Run AT the player (caller: artifacts/healer/use/plume tail, for #fx_tier 4..). The phoenix flame cleanses —
# warm embers flare and resolve into rising gold feathers of light, impurity burning away over a soft warm
# chord. #fx_tier is 4 (ornate) here but kept tier-aware. Channel-gated; one-shot.

# ── SOUND ── a warm chord (bell triad C·E·G) + a soft sparkle at Cracked.
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.6 0.707
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.6 0.891
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.6 1.059
execute if score @s ec.fx_snd matches 3.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.5 1.587

# ── VISUAL · REDUCED (1) ── a small warm ember puff.
execute if score @s ec.fx_vis matches 1 run particle dust{color:[1.0,0.7,0.3],scale:1.0} ~ ~1 ~ 0.6 0.8 0.6 0 12

# ── VISUAL · FULL & up (2..) ── warm embers resolving into rising gold feather-light + a cleansing glow.
execute if score @s ec.fx_vis matches 2.. run particle dust{color:[1.0,0.72,0.3],scale:1.0} ~ ~0.8 ~ 0.6 0.8 0.6 0 18
execute if score @s ec.fx_vis matches 2.. run particle dust{color:[1.0,0.9,0.55],scale:1.0} ~ ~1.5 ~ 0.7 1.0 0.7 0 24
execute if score @s ec.fx_vis matches 2.. run particle end_rod ~ ~0.5 ~ 0.6 1.0 0.6 0.04 18
execute if score @s ec.fx_vis matches 2.. run particle glow ~ ~1.3 ~ 0.6 0.9 0.6 0.06 14

# ── ORNATE+ (4..) ── a fuller feather lift (always true here, kept for tier symmetry).
execute if score @s ec.fx_vis matches 2.. if score #fx_tier ec.var matches 4.. run particle dust{color:[1.0,0.82,0.45],scale:1.2} ~ ~1.8 ~ 0.7 1.0 0.7 0 18

# ── CRACKED (3..) ── an ember-gold flash + an ember→gold feather pillar.
execute if score @s ec.fx_vis matches 3.. run particle flash{color:[1.0,0.8,0.4,1.0]} ~ ~1.2 ~
execute if score @s ec.fx_vis matches 3.. run particle dust_color_transition{from_color:[1.0,0.55,0.2],scale:2.0,to_color:[1.0,0.92,0.6]} ~ ~1.4 ~ 0.7 1.4 0.7 0.05 40
execute if score @s ec.fx_vis matches 3.. run particle end_rod ~ ~1.6 ~ 0.7 1.0 0.7 0.06 18
