# === FX · BESPOKE — SPIRIT "Dragonheart Sword" · Dragonfire proc (on-hit, 15%/25%) ===
# Run AS the player (caller: spirit/abilities/dragonheart_sword/dragonfire_proc tail; the proc already
# ignited the target via `on target`). A bite of dragon-breath flares ON the struck foe + a hot hiss at the
# bearer. Kept LIGHT — this is a per-hit proc. Channel-gated.

# ── SOUND ── a short hot hiss (note-block, no vocal grunt).
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.3 1.587

# ── VISUAL · the breath-bite on the struck target (FULL+).
execute if score @s ec.fx_vis matches 2.. on target at @s run particle dragon_breath ~ ~0.8 ~ 0.25 0.4 0.25 0.01 6
execute if score @s ec.fx_vis matches 2.. on target at @s run particle dust{color:[1.0,0.55,0.15],scale:0.9} ~ ~0.8 ~ 0.3 0.4 0.3 0 5

# ── CRACKED (3..) ── a brighter ember flare on the target.
execute if score @s ec.fx_vis matches 3.. on target at @s run particle flame ~ ~0.8 ~ 0.3 0.5 0.3 0.05 6
