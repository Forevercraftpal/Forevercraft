# === FX · BESPOKE — SPIRIT "Pharaoh's Fist" · Titan Breaker windup (ability2) ===
# Run AS+AT the player (caller: spirit/abilities/pharaoh_fist/ability2 tail — the windup BEGINS here; the
# strike itself lands in titan_hit). Power gathers: sun-gold light coils into the fist, desert sand drawn
# inward, the god-king winding up — over a deep gathering tone. Channel-gated; one-shot on windup start.

# ── SOUND ── a deep gathering tone rising (note-block, no vocal grunt).
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 0.6 0.5
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.harp master @s ~ ~ ~ 0.5 0.794
execute if score @s ec.fx_snd matches 3.. run playsound minecraft:block.amethyst_block.resonate master @s ~ ~ ~ 0.5 0.595

# ── VISUAL · REDUCED (1) ── a small gold coil at the fist.
execute if score @s ec.fx_vis matches 1 run particle dust{color:[1.0,0.8,0.25],scale:0.9} ~ ~1 ~ 0.4 0.5 0.4 0 10

# ── VISUAL · FULL & up (2..) ── sun-gold light coiling inward + drawn-in desert sand.
execute if score @s ec.fx_vis matches 2.. run particle dust{color:[1.0,0.8,0.25],scale:1.0} ~ ~1 ~ 0.5 0.6 0.5 0 22
execute if score @s ec.fx_vis matches 2.. run particle dust{color:[0.85,0.72,0.4],scale:0.8} ~ ~1 ~ 0.8 0.7 0.8 0 16
execute if score @s ec.fx_vis matches 2.. run particle wax_on ~ ~1 ~ 0.5 0.6 0.5 0 8
execute if score @s ec.fx_vis matches 2.. run particle enchant ~ ~1.4 ~ 0.6 0.5 0.6 0.3 10

# ── CRACKED (3..) ── a sand→gold bloom drawing inward (the held power glows).
execute if score @s ec.fx_vis matches 3.. run particle dust_color_transition{from_color:[0.85,0.7,0.35],scale:1.6,to_color:[1.0,0.9,0.3]} ~ ~1.1 ~ 0.6 0.7 0.6 0 26
