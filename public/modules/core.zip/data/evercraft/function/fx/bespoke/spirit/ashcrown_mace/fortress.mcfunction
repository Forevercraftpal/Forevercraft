# === FX · BESPOKE — SPIRIT "Ashcrown Mace" · Fortress (ability1) ===
# Run AS+AT the player (caller: spirit/abilities/ashcrown_mace/ability1 tail). A throne raised from ash:
# a heavy ring of smouldering grey ash sweeps out, crown-gold glints rise along the bastion line, the
# ground answers with a deep regal toll. INTIMIDATION CARVE-OUT — this menacing weapon earns a low
# ravager-roar at Cracked. Channel-gated; one-shot per cast.

# ── SOUND ── a deep regal toll (iron + bass), Cracked adds the menacing roar (carve-out).
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.iron_xylophone master @s ~ ~ ~ 0.7 0.5
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 0.7 0.45
execute if score @s ec.fx_snd matches 3.. run playsound minecraft:entity.ravager.roar master @s ~ ~ ~ 0.5 0.7

# ── VISUAL · REDUCED (1) ── a small ash ring + a gold glint.
execute if score @s ec.fx_vis matches 1 run particle ash ~ ~0.3 ~ 1.5 0.2 1.5 0.02 16
execute if score @s ec.fx_vis matches 1 run particle dust{color:[0.95,0.78,0.32],scale:0.8} ~ ~0.4 ~ 1.5 0.2 1.5 0 8

# ── VISUAL · FULL & up (2..) ── the bastion ring: heavy ash sweep + grey-ember dust + a rising gold crown-line.
execute if score @s ec.fx_vis matches 2.. run particle ash ~ ~0.3 ~ 3.0 0.2 3.0 0.03 40
execute if score @s ec.fx_vis matches 2.. run particle dust{color:[0.45,0.42,0.4],scale:1.2} ~ ~0.3 ~ 3.0 0.2 3.0 0 26
execute if score @s ec.fx_vis matches 2.. run particle dust{color:[0.95,0.78,0.32],scale:0.9} ~ ~0.6 ~ 2.0 0.7 2.0 0 18
execute if score @s ec.fx_vis matches 2.. run particle campfire_cosy_smoke ~ ~0.4 ~ 1.2 0.3 1.2 0.01 8

# ── CRACKED (3..) ── an ash→ember flash-bloom + a smouldering pall over the fortress.
execute if score @s ec.fx_vis matches 3.. run particle flash{color:[0.8,0.65,0.3,1.0]} ~ ~0.5 ~
execute if score @s ec.fx_vis matches 3.. run particle dust_color_transition{from_color:[0.5,0.45,0.4],scale:1.8,to_color:[1.0,0.7,0.25]} ~ ~0.4 ~ 3.2 0.3 3.2 0.05 36
execute if score @s ec.fx_vis matches 3.. run particle large_smoke ~ ~0.6 ~ 2.5 0.4 2.5 0.02 18
