# === FX · BESPOKE — SPIRIT "Zephyr Edge" · Cyclone (ability1) ===
# Run AS+AT the player (caller: spirit/abilities/zephyr_edge/ability1 tail). The bearer becomes wind: a
# pale-cyan vortex spins up, gusts curl inward, swift air-slashes ring the body — over an airy rising
# flute. Channel-gated; one-shot on activation (the per-tick spin is the ability's own engine).

# ── SOUND ── a swift rising wind-flute (note-block, no vocal grunt).
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.flute master @s ~ ~ ~ 0.6 0.891
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.flute master @s ~ ~ ~ 0.6 1.122
execute if score @s ec.fx_snd matches 3.. run playsound minecraft:block.note_block.flute master @s ~ ~ ~ 0.5 1.335

# ── VISUAL · REDUCED (1) ── a small gust + cyan motes.
execute if score @s ec.fx_vis matches 1 run particle gust ~ ~1 ~ 0.4 0.6 0.4 0.02 4
execute if score @s ec.fx_vis matches 1 run particle dust{color:[0.7,0.95,1.0],scale:0.9} ~ ~1 ~ 0.6 0.7 0.6 0 10

# ── VISUAL · FULL & up (2..) ── the vortex: gusts curl up, cyan air-slashes spiral, a sweep ring.
execute if score @s ec.fx_vis matches 2.. run particle gust ~ ~0.5 ~ 0.5 0.8 0.5 0.05 8
execute if score @s ec.fx_vis matches 2.. run particle dust{color:[0.7,0.95,1.0],scale:1.0} ~ ~1 ~ 1.0 1.0 1.0 0 30
execute if score @s ec.fx_vis matches 2.. run particle dust{color:[0.85,1.0,1.0],scale:0.7} ~ ~1.5 ~ 0.8 0.9 0.8 0 18
execute if score @s ec.fx_vis matches 2.. run particle sweep_attack ~ ~1 ~ 0.8 0.5 0.8 0 3

# ── CRACKED (3..) ── a cyan→white wind-bloom column + a wider gust burst.
execute if score @s ec.fx_vis matches 3.. run particle gust_emitter_large ~ ~0.8 ~ 0.1 0.1 0.1 0 1
execute if score @s ec.fx_vis matches 3.. run particle dust_color_transition{from_color:[0.6,0.9,1.0],scale:1.5,to_color:[1.0,1.0,1.0]} ~ ~1.3 ~ 0.9 1.1 0.9 0.05 30
