# === FX · BESPOKE — SET "Ender Dragon/Voidscale" · set-complete (4pc apply) ===
# Run AS+AT the player (caller: artifacts/sets/ender_dragon/bonus_4pc, ONE-SHOT on the apply — guarded by
# the same `unless tag ender_dragon_4pc` as the blade-grant above it). NO per-fire active on this set, so
# the flourish marks the moment the Dragon's Fury bonus engages: a violet-black void rift opens, dragon
# breath plumes outward, and a deep void resonance tolls. INTIMIDATION CARVE-OUT — dragon set earns a low
# roar at Cracked. Channel-gated; one-shot.

# ── SOUND ── a deep void toll (bass + didgeridoo) under a portal shimmer; Cracked roars.
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 0.8 0.5
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.didgeridoo master @s ~ ~ ~ 0.7 0.45
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.amethyst_block.resonate master @s ~ ~ ~ 0.6 0.4
execute if score @s ec.fx_snd matches 3.. run playsound minecraft:entity.ender_dragon.growl master @s ~ ~ ~ 0.6 0.6

# ── VISUAL · REDUCED (1) ── a small void wisp + a dragon-breath puff.
execute if score @s ec.fx_vis matches 1 run particle dragon_breath ~ ~1 ~ 0.4 0.5 0.4 0.01 10
execute if score @s ec.fx_vis matches 1 run particle dust{color:[0.4,0.1,0.55],scale:0.9} ~ ~1 ~ 0.5 0.6 0.5 0 8

# ── VISUAL · FULL & up (2..) ── a violet-black void rift: dragon breath + portal wisps + a dark dust ring.
execute if score @s ec.fx_vis matches 2.. run particle dragon_breath ~ ~1.2 ~ 0.6 0.9 0.6 0.02 28
execute if score @s ec.fx_vis matches 2.. run particle reverse_portal ~ ~1.4 ~ 0.7 1.0 0.7 0.04 24
execute if score @s ec.fx_vis matches 2.. run particle dust{color:[0.35,0.08,0.5],scale:1.2} ~ ~0.2 ~ 2.2 0.15 2.2 0 24
execute if score @s ec.fx_vis matches 2.. run particle portal ~ ~1.0 ~ 0.6 0.8 0.6 0.5 16

# ── CRACKED (3..) ── a violet flash + a void-black→violet rift pillar + a breath plume.
execute if score @s ec.fx_vis matches 3.. run particle flash{color:[0.45,0.15,0.6,1.0]} ~ ~1.2 ~
execute if score @s ec.fx_vis matches 3.. run particle dust_color_transition{from_color:[0.12,0.03,0.18],scale:2.0,to_color:[0.65,0.35,0.95]} ~ ~1.4 ~ 0.7 1.2 0.7 0.05 38
execute if score @s ec.fx_vis matches 3.. run particle dragon_breath ~ ~1.8 ~ 0.7 0.6 0.7 0.03 24
