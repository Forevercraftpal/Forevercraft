# === FX · BESPOKE — SPIRIT "Royal Trident" · Aegis Wall (ability1) ===
# Run AS+AT the player (caller: spirit/abilities/royal_trident/ability1 tail — fires when the wall is
# planted). The tide answers the crown: a ring of regal water-crowns rises in aqua and gold, sea-spray
# lifting into a tidal bastion — over a clear regal tide-bell. Channel-gated; one-shot per cast.

# ── SOUND ── a clear regal tide-bell chord (note-block, no vocal grunt).
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.6 0.794
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.6 1.122
execute if score @s ec.fx_snd matches 3.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.55 1.335

# ── VISUAL · REDUCED (1) ── a small aqua ring + a gold glint.
execute if score @s ec.fx_vis matches 1 run particle dust{color:[0.3,0.75,0.95],scale:0.9} ~ ~0.3 ~ 1.5 0.2 1.5 0 14
execute if score @s ec.fx_vis matches 1 run particle dust{color:[1.0,0.85,0.35],scale:0.6} ~ ~0.4 ~ 1.5 0.2 1.5 0 8

# ── VISUAL · FULL & up (2..) ── the water-crown ring: aqua spray rising + gold rim + lifting sea-spray.
execute if score @s ec.fx_vis matches 2.. run particle dust{color:[0.3,0.75,0.95],scale:1.1} ~ ~0.3 ~ 2.5 0.3 2.5 0 36
execute if score @s ec.fx_vis matches 2.. run particle dust{color:[1.0,0.85,0.35],scale:0.7} ~ ~0.7 ~ 2.2 0.6 2.2 0 18
execute if score @s ec.fx_vis matches 2.. run particle splash ~ ~0.5 ~ 1.8 0.5 1.8 0.05 16
execute if score @s ec.fx_vis matches 2.. run particle dust{color:[0.5,0.85,1.0],scale:0.8} ~ ~1 ~ 1.2 0.9 1.2 0 14

# ── CRACKED (3..) ── an aqua→gold crown-bloom flash + a rising tidal column.
execute if score @s ec.fx_vis matches 3.. run particle flash{color:[0.4,0.8,1.0,1.0]} ~ ~0.5 ~
execute if score @s ec.fx_vis matches 3.. run particle dust_color_transition{from_color:[0.25,0.7,0.95],scale:1.7,to_color:[1.0,0.85,0.4]} ~ ~0.7 ~ 2.6 0.7 2.6 0.03 34
execute if score @s ec.fx_vis matches 3.. run particle dripping_dripstone_water ~ ~1.6 ~ 1.2 0.6 1.2 0 10
