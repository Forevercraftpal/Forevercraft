# === FX · BESPOKE — ABILITY "Dimensional Rift" (Portal Staff · sneak+hit portal trap) ===
# Run AS the player but POSITIONED AT the struck target (caller: artifacts/abilities/dimensional_rift tail,
# inside its `at @s at @e[...HurtTime]` context). A violet space-rift cracks open where the trap forms:
# a portal whorl + a reverse-portal core + a deep-violet dust web, over a musical/elemental WARP CUE (amethyst
# resonance + a low note — the in-palette layer alongside the ability's own legacy end_portal cue). One-shot.

# ── SOUND ── a deep void-tear resonance + a high shimmer (musical, no mob grunt).
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 0.5 0.5
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.amethyst_block.resonate master @s ~ ~ ~ 0.55 0.794
execute if score @s ec.fx_snd matches 3.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.5 0.5

# ── VISUAL · REDUCED (1) ── a small violet tear at the trap.
execute if score @s ec.fx_vis matches 1 run particle reverse_portal ~ ~1 ~ 0.4 0.5 0.4 0.08 8

# ── VISUAL · FULL & up (2..) ── the rift whorl: a portal spiral + a reverse-portal core + a violet dust web.
execute if score @s ec.fx_vis matches 2.. run particle portal ~ ~1 ~ 0.5 0.7 0.5 0.6 20
execute if score @s ec.fx_vis matches 2.. run particle reverse_portal ~ ~1 ~ 0.4 0.6 0.4 0.1 16
execute if score @s ec.fx_vis matches 2.. run particle dust{color:[0.5,0.18,0.78],scale:1.0} ~ ~1 ~ 0.5 0.7 0.5 0 14

# ── CRACKED (3..) ── a violet→void space-split bloom (the rift yawns open).
execute if score @s ec.fx_vis matches 3.. run particle dust_color_transition{from_color:[0.5,0.18,0.78],scale:1.8,to_color:[0.15,0.0,0.32]} ~ ~1.2 ~ 0.6 0.8 0.6 0.05 26
execute if score @s ec.fx_vis matches 3.. run particle squid_ink ~ ~1 ~ 0.4 0.5 0.4 0.02 6
