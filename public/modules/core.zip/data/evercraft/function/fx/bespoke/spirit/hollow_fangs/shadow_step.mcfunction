# === FX · BESPOKE — SPIRIT "Hollow Fangs" · Shadow Step (ability1) ===
# Run AS+AT the player (caller: spirit/abilities/hollow_fangs/ability1 tail — fires after the teleport-behind).
# A hollow void-bone bite: a pale-violet implosion at the new spot, bone-white fang-flecks, a whispered
# soul-mist where the bearer reappears, over a low two-note bone motif. Channel-gated; one-shot per cast.

# ── SOUND ── a hollow descending bone motif (note-block, no vocal grunt).
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 0.6 0.595
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.amethyst_block.hit master @s ~ ~ ~ 0.5 0.5
execute if score @s ec.fx_snd matches 3.. run playsound minecraft:block.amethyst_block.resonate master @s ~ ~ ~ 0.5 0.749

# ── VISUAL · REDUCED (1) ── a small violet pop + a single bone fleck.
execute if score @s ec.fx_vis matches 1 run particle dust{color:[0.62,0.45,0.78],scale:0.9} ~ ~1 ~ 0.3 0.5 0.3 0 6
execute if score @s ec.fx_vis matches 1 run particle dust{color:[0.92,0.9,0.82],scale:0.5} ~ ~1 ~ 0.25 0.4 0.25 0 3

# ── VISUAL · FULL & up (2..) ── the void-bone bite: an inward soul-mist + fang flecks + a reverse-portal implosion.
execute if score @s ec.fx_vis matches 2.. run particle reverse_portal ~ ~1 ~ 0.4 0.6 0.4 0.06 24
execute if score @s ec.fx_vis matches 2.. run particle dust{color:[0.62,0.45,0.78],scale:1.0} ~ ~1 ~ 0.5 0.6 0.5 0 16
execute if score @s ec.fx_vis matches 2.. run particle dust{color:[0.92,0.9,0.82],scale:0.55} ~ ~1 ~ 0.45 0.5 0.45 0 10
execute if score @s ec.fx_vis matches 2.. run particle soul ~ ~1 ~ 0.4 0.5 0.4 0.01 8

# ── CRACKED (3..) ── a violet→bone bloom + a drifting soul column (the hollow soul speaks).
execute if score @s ec.fx_vis matches 3.. run particle dust_color_transition{from_color:[0.5,0.35,0.7],scale:1.5,to_color:[0.92,0.9,0.82]} ~ ~1.2 ~ 0.5 0.7 0.5 0.04 22
execute if score @s ec.fx_vis matches 3.. run particle soul_fire_flame ~ ~1 ~ 0.3 0.7 0.3 0.02 8
