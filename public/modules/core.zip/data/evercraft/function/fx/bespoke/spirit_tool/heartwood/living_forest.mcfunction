# === FX · BESPOKE — SPIRIT TOOL "Heartwood" · Living Forest (mastery) ===
# Run AS+AT the player (caller: craftforever/spirit_tools/heartwood/mastery tail). The grove answers — a
# great upward rush of bark chips and green leaves as the whole stand topples and reseeds, over a deep
# resonant wood-fall + a warm growth chord. Apex tool: channel-gated only (no #fx_tier).

# ── SOUND ── a deep woody resonance + a warm chord (didgeridoo + harp E·G·B).
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 0.7 0.5
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.didgeridoo master @s ~ ~ ~ 0.7 0.5
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.harp master @s ~ ~ ~ 0.6 0.891
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.harp master @s ~ ~ ~ 0.6 1.059
execute if score @s ec.fx_snd matches 3.. run playsound minecraft:block.amethyst_block.resonate master @s ~ ~ ~ 0.6 0.794

# ── VISUAL · REDUCED (1) ── a small leaf-and-bark puff.
execute if score @s ec.fx_vis matches 1 run particle dust{color:[0.5,0.32,0.16],scale:1.0} ~ ~1 ~ 1.5 0.6 1.5 0 14

# ── VISUAL · FULL & up (2..) ── a tall column of bark chips + a sweeping leaf-fall + happy growth motes.
execute if score @s ec.fx_vis matches 2.. run particle minecraft:block{block_state:"minecraft:oak_log"} ~ ~1.5 ~ 1.2 2.5 1.2 0.2 40
execute if score @s ec.fx_vis matches 2.. run particle dust{color:[0.4,0.75,0.3],scale:1.0} ~ ~2.0 ~ 4.0 1.5 4.0 0 44
execute if score @s ec.fx_vis matches 2.. run particle happy_villager ~ ~0.8 ~ 3.0 0.6 3.0 0 24
execute if score @s ec.fx_vis matches 2.. run particle happy_villager ~ ~0.4 ~ 2.5 0.3 2.5 0.1 16

# ── CRACKED (3..) ── a verdant flash + a brown→green dust pillar + a wide leaf burst.
execute if score @s ec.fx_vis matches 3.. run particle flash{color:[0.5,0.85,0.4,1.0]} ~ ~1.5 ~
execute if score @s ec.fx_vis matches 3.. run particle dust_color_transition{from_color:[0.5,0.32,0.16],scale:2.0,to_color:[0.4,0.85,0.35]} ~ ~1.5 ~ 1.2 2.0 1.2 0.05 44
execute if score @s ec.fx_vis matches 3.. run particle minecraft:block{block_state:"minecraft:oak_leaves"} ~ ~2.5 ~ 3.5 1.5 3.5 0 30
