# === FX · BESPOKE — SPIRIT "Lifewoven Branch" · Sanctuary (ability1) ===
# Run AS+AT the player (caller: spirit/abilities/lifewoven_branch/ability1 tail). Life blooms from the
# branch: a verdant ring of growth unfurls, cherry petals drift up on a warm breath, healing motes bless
# the ground — over a gentle growth-bell. Channel-gated; one-shot per cast.

# ── SOUND ── a gentle rising growth-bell chord (note-block, no vocal grunt).
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.55 0.891
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.55 1.122
execute if score @s ec.fx_snd matches 3.. run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.5 1.335

# ── VISUAL · REDUCED (1) ── a small green ring + a couple petals.
execute if score @s ec.fx_vis matches 1 run particle dust{color:[0.35,0.95,0.4],scale:0.9} ~ ~0.3 ~ 1.5 0.2 1.5 0 14
execute if score @s ec.fx_vis matches 1 run particle cherry_leaves ~ ~1 ~ 0.8 0.6 0.8 0 4

# ── VISUAL · FULL & up (2..) ── the verdant bloom ring + rising petals + blessing motes.
execute if score @s ec.fx_vis matches 2.. run particle dust{color:[0.35,0.95,0.4],scale:1.0} ~ ~0.3 ~ 3.0 0.2 3.0 0 36
execute if score @s ec.fx_vis matches 2.. run particle happy_villager ~ ~0.6 ~ 2.5 0.5 2.5 0 18
execute if score @s ec.fx_vis matches 2.. run particle cherry_leaves ~ ~1.2 ~ 1.2 0.8 1.2 0 16
execute if score @s ec.fx_vis matches 2.. run particle dust{color:[0.6,1.0,0.55],scale:0.7} ~ ~0.8 ~ 2.0 0.6 2.0 0 14

# ── CRACKED (3..) ── a green→bloom flash + a column of lifting petals.
execute if score @s ec.fx_vis matches 3.. run particle flash{color:[0.5,1.0,0.5,1.0]} ~ ~0.6 ~
execute if score @s ec.fx_vis matches 3.. run particle dust_color_transition{from_color:[0.3,0.9,0.35],scale:1.7,to_color:[0.85,1.0,0.6]} ~ ~0.8 ~ 3.0 0.6 3.0 0.03 32
execute if score @s ec.fx_vis matches 3.. run particle cherry_leaves ~ ~1.5 ~ 1.0 1.0 1.0 0 16
