# === FX · BESPOKE — HEALER "Radiant Censer" (Ornate, regen) ===
# Run AT the player (caller: artifacts/healer/use/censer tail, for #fx_tier 4..). Mending light bathes all —
# fragrant incense-smoke curls up wreathed in a warm gold glow, a soothing mending haze over a soft warm chord.
# #fx_tier is 4 (ornate) here but kept tier-aware. Channel-gated; one-shot.

# ── SOUND ── a soft warm chord (harp C·E·G) + a gentle chime at Cracked.
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.harp master @s ~ ~ ~ 0.6 0.707
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.harp master @s ~ ~ ~ 0.6 0.891
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.harp master @s ~ ~ ~ 0.6 1.059
execute if score @s ec.fx_snd matches 3.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.5 1.335

# ── VISUAL · REDUCED (1) ── a small warm glow puff.
execute if score @s ec.fx_vis matches 1 run particle dust{color:[1.0,0.88,0.55],scale:1.0} ~ ~1 ~ 0.6 0.8 0.6 0 12

# ── VISUAL · FULL & up (2..) ── curling incense-smoke + a warm gold glow + soft mending motes.
execute if score @s ec.fx_vis matches 2.. run particle campfire_cosy_smoke ~ ~1.4 ~ 0.5 0.9 0.5 0.005 10
execute if score @s ec.fx_vis matches 2.. run particle dust{color:[1.0,0.88,0.55],scale:1.0} ~ ~1.2 ~ 0.7 1.0 0.7 0 24
execute if score @s ec.fx_vis matches 2.. run particle glow ~ ~1.0 ~ 0.6 0.9 0.6 0.06 16

# ── ORNATE+ (4..) ── a fuller glow halo (always true here, kept for tier symmetry).
execute if score @s ec.fx_vis matches 2.. if score #fx_tier ec.var matches 4.. run particle dust{color:[1.0,0.82,0.45],scale:1.2} ~ ~1.6 ~ 0.7 0.9 0.7 0 18

# ── CRACKED (3..) ── a warm flash + a gold glow pillar + a fuller incense plume.
execute if score @s ec.fx_vis matches 3.. run particle flash{color:[1.0,0.9,0.6,1.0]} ~ ~1.2 ~
execute if score @s ec.fx_vis matches 3.. run particle dust_color_transition{from_color:[1.0,0.88,0.55],scale:2.0,to_color:[1.0,0.95,0.75]} ~ ~1.4 ~ 0.7 1.3 0.7 0.05 38
execute if score @s ec.fx_vis matches 3.. run particle campfire_cosy_smoke ~ ~1.8 ~ 0.5 1.0 0.5 0.01 12
