# === FX · BESPOKE — SPIRIT TOOL "Tidecaller" · Maelstrom (mastery) ===
# Run AS+AT the player (caller: craftforever/spirit_tools/tidecaller/mastery tail). The sea answers — a
# rising blue water-vortex with bubbles spiralling up and spray flung outward as the whirlpool wakes, over a
# deep tidal swell + a clear flute chord (D·A·D'). Apex tool: channel-gated only (no #fx_tier).

# ── SOUND ── a low tide-swell + a clear ascending flute chord.
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 0.6 0.5
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.flute master @s ~ ~ ~ 0.6 0.794
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.flute master @s ~ ~ ~ 0.6 1.189
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.flute master @s ~ ~ ~ 0.6 1.587
execute if score @s ec.fx_snd matches 3.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.5 1.4

# ── VISUAL · REDUCED (1) ── a small blue water shimmer.
execute if score @s ec.fx_vis matches 1 run particle dust{color:[0.35,0.7,1.0],scale:1.0} ~ ~0.5 ~ 1.2 0.4 1.2 0 12

# ── VISUAL · FULL & up (2..) ── a spiralling bubble vortex + a blue water-disc + spray.
execute if score @s ec.fx_vis matches 2.. run particle dust{color:[0.35,0.7,1.0],scale:1.1} ~ ~0.2 ~ 3.0 0.1 3.0 0 44
execute if score @s ec.fx_vis matches 2.. run particle bubble_column_up ~ ~0.4 ~ 1.4 1.4 1.4 0.1 30
execute if score @s ec.fx_vis matches 2.. run particle splash ~ ~0.6 ~ 2.0 0.5 2.0 0.1 24
execute if score @s ec.fx_vis matches 2.. run particle nautilus ~ ~1.2 ~ 1.5 1.0 1.5 0.2 14

# ── CRACKED (3..) ── a cyan flash + a deep-blue dust vortex pillar + a falling-water curtain.
execute if score @s ec.fx_vis matches 3.. run particle flash{color:[0.4,0.8,1.0,1.0]} ~ ~1 ~
execute if score @s ec.fx_vis matches 3.. run particle dust_color_transition{from_color:[0.35,0.7,1.0],scale:1.9,to_color:[0.15,0.4,0.85]} ~ ~1.0 ~ 1.0 1.5 1.0 0.05 40
execute if score @s ec.fx_vis matches 3.. run particle falling_water ~ ~2.2 ~ 1.8 1.0 1.8 0 24
