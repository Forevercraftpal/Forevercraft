# === FX · BESPOKE — SET "Shadow" · Assassinate (active) ===
# Run AS+AT the player (caller: artifacts/sets/shadow/assassinate_inner, after the strike — fired at the
# player's destination behind the target). The shade strikes: a dark shade-burst folds in around the now-
# unseen wearer, ash and smoke coil, and a hushed low muted note rings (the cut from nowhere).
# Channel-gated; one-shot per assassinate.

# ── SOUND ── a hushed muted toll (bass low + a sharp bit accent) — a silent blade landing.
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 0.6 0.5
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.bit master @s ~ ~ ~ 0.5 1.189
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 0.5 0.595
execute if score @s ec.fx_snd matches 3.. run playsound minecraft:block.amethyst_block.resonate master @s ~ ~ ~ 0.5 0.4

# ── VISUAL · REDUCED (1) ── a small ash puff + a dark glint.
execute if score @s ec.fx_vis matches 1 run particle ash ~ ~1 ~ 0.5 0.6 0.5 0.03 12
execute if score @s ec.fx_vis matches 1 run particle dust{color:[0.18,0.16,0.22],scale:0.9} ~ ~1 ~ 0.5 0.5 0.5 0 6

# ── VISUAL · FULL & up (2..) ── a shade-burst: coiling ash + a dark dust ring + smoke wisps.
execute if score @s ec.fx_vis matches 2.. run particle ash ~ ~1.0 ~ 0.8 0.9 0.8 0.04 28
execute if score @s ec.fx_vis matches 2.. run particle dust{color:[0.15,0.13,0.2],scale:1.2} ~ ~0.2 ~ 1.8 0.12 1.8 0 22
execute if score @s ec.fx_vis matches 2.. run particle smoke ~ ~1.0 ~ 0.6 0.8 0.6 0.02 16
execute if score @s ec.fx_vis matches 2.. run particle squid_ink ~ ~1.0 ~ 0.6 0.6 0.6 0.01 8

# ── CRACKED (3..) ── a dim flash + a black→shade-violet shroud pillar + a smoke pall.
execute if score @s ec.fx_vis matches 3.. run particle flash{color:[0.2,0.15,0.28,1.0]} ~ ~1.0 ~
execute if score @s ec.fx_vis matches 3.. run particle dust_color_transition{from_color:[0.05,0.04,0.08],scale:1.9,to_color:[0.35,0.25,0.5]} ~ ~1.2 ~ 0.7 1.0 0.7 0.05 36
execute if score @s ec.fx_vis matches 3.. run particle large_smoke ~ ~1.0 ~ 0.8 0.6 0.8 0.01 16
