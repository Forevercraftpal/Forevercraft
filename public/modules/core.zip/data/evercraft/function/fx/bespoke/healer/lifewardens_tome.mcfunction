# === FX · BESPOKE — HEALER "Lifewarden's Tome" (Exquisite, triage) ===
# Run AT the player (caller: artifacts/healer/use/tome tail, for #fx_tier 4..). Triage complete — soft
# page-light flutters up, gilded glyph-motes turning in warm white-gold over a gentle page-turn chord. The
# tome is a book (using_item) but the heal-side cooldown gate guards this, so it fires once per cast.
# #fx_tier is 5 (exquisite) here but kept tier-aware. Channel-gated; one-shot.

# ── SOUND ── a gentle chord (chime triad C·E·G) + a soft sparkle at Cracked.
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.chime master @s ~ ~ ~ 0.6 0.707
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.chime master @s ~ ~ ~ 0.6 0.891
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.chime master @s ~ ~ ~ 0.6 1.059
execute if score @s ec.fx_snd matches 3.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.5 1.414

# ── VISUAL · REDUCED (1) ── a small warm light puff.
execute if score @s ec.fx_vis matches 1 run particle dust{color:[1.0,0.95,0.7],scale:1.0} ~ ~1 ~ 0.6 0.8 0.6 0 12

# ── VISUAL · FULL & up (2..) ── soft page-light + turning gilded glyph-motes + a warm enchant swirl.
execute if score @s ec.fx_vis matches 2.. run particle dust{color:[1.0,0.95,0.7],scale:1.1} ~ ~1.3 ~ 0.7 1.0 0.7 0 26
execute if score @s ec.fx_vis matches 2.. run particle enchant ~ ~1.8 ~ 0.7 1.0 0.7 0.3 24
execute if score @s ec.fx_vis matches 2.. run particle end_rod ~ ~0.5 ~ 0.6 0.9 0.6 0.04 14

# ── EXQUISITE (5..) ── a fuller glyph lift + a golden glow.
execute if score @s ec.fx_vis matches 2.. if score #fx_tier ec.var matches 5.. run particle dust{color:[1.0,0.88,0.5],scale:1.2} ~ ~1.6 ~ 0.7 1.0 0.7 0 20

# ── CRACKED (3..) ── a warm flash + a white-gold page pillar + a glyph burst.
execute if score @s ec.fx_vis matches 3.. run particle flash{color:[1.0,0.97,0.8,1.0]} ~ ~1.2 ~
execute if score @s ec.fx_vis matches 3.. run particle dust_color_transition{from_color:[1.0,0.95,0.7],scale:2.0,to_color:[1.0,0.85,0.4]} ~ ~1.4 ~ 0.7 1.3 0.7 0.05 38
execute if score @s ec.fx_vis matches 3.. run particle enchant ~ ~2.0 ~ 0.8 1.0 0.8 0.5 28
