# === FX · BESPOKE — ABILITY "Dimensional Cut" (Zantetsuken · every 10th auto-swing teleport) ===
# Run AS+AT the player (caller: artifacts/abilities/dimensional_cut tail — @s is the rg_swinger after the
# teleport-behind). A violet space-rift slash: a reverse-portal implosion at the new spot + a sharp cyan
# blade-gleam, over a musical/elemental WARP CUE (amethyst + a high note — replaces the mob enderman.teleport
# vocabulary; the ability's own legacy sound stays, this adds the in-palette layer). Channel-gated; one-shot.

# ── SOUND ── a musical warp shimmer (amethyst chime + a clean high note — the in-palette space-cut cue).
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.amethyst_block.hit master @s ~ ~ ~ 0.5 1.4
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.5 1.7
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.bit master @s ~ ~ ~ 0.4 1.8
execute if score @s ec.fx_snd matches 3.. run playsound minecraft:block.amethyst_block.resonate master @s ~ ~ ~ 0.5 1.2

# ── VISUAL · REDUCED (1) ── a small violet tear.
execute if score @s ec.fx_vis matches 1 run particle reverse_portal ~ ~1 ~ 0.3 0.5 0.3 0.05 8

# ── VISUAL · FULL & up (2..) ── a rift implosion at the reappear + a cyan blade-gleam slash.
execute if score @s ec.fx_vis matches 2.. run particle reverse_portal ~ ~1 ~ 0.4 0.6 0.4 0.08 18
execute if score @s ec.fx_vis matches 2.. run particle dust{color:[0.6,0.25,0.9],scale:1.0} ~ ~1 ~ 0.45 0.6 0.45 0 12
execute if score @s ec.fx_vis matches 2.. anchored eyes positioned ^0.5 ^-0.1 ^0.8 run particle dust{color:[0.4,0.95,1.0],scale:0.8} ~ ~ ~ 0.1 0.4 0.1 0 8
execute if score @s ec.fx_vis matches 2.. run particle enchanted_hit ~ ~1 ~ 0.4 0.5 0.4 0.6 8

# ── CRACKED (3..) ── a violet→cyan space-split bloom + a portal column (the cut tears space).
execute if score @s ec.fx_vis matches 3.. run particle dust_color_transition{from_color:[0.55,0.2,0.88],scale:1.6,to_color:[0.4,0.95,1.0]} ~ ~1.2 ~ 0.5 0.7 0.5 0.05 24
execute if score @s ec.fx_vis matches 3.. run particle portal ~ ~1 ~ 0.4 0.6 0.4 0.6 16
