# === FX · BESPOKE — ABILITY "Divine Judgment" (Ban Hammer · smite from above) ===
# Run AS+AT the player (caller: artifacts/abilities/divine_judgment — only on a confirmed smite branch). A
# holy gold light-pillar descends + a choir-like chime swells + an end-rod radiance, over a bright bell triad.
# Channel-gated; one-shot per proc. Apex — ladder-gated, no #fx_tier.

# ── SOUND ── a celestial bell triad rising + a soft choir chime (musical, no vocal grunt).
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.5 1.059
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.5 1.335
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.chime master @s ~ ~ ~ 0.45 1.587
execute if score @s ec.fx_snd matches 3.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.5 2.0

# ── VISUAL · REDUCED (1) ── a small gold light pop overhead.
execute if score @s ec.fx_vis matches 1 run particle end_rod ~ ~1.2 ~ 0.3 0.5 0.3 0.02 6

# ── VISUAL · FULL & up (2..) ── a descending gold light-pillar + a holy enchant shimmer.
execute if score @s ec.fx_vis matches 2.. run particle end_rod ~ ~2.4 ~ 0.12 1.0 0.12 0.04 14
execute if score @s ec.fx_vis matches 2.. run particle dust{color:[1.0,0.9,0.45],scale:1.0} ~ ~1.4 ~ 0.25 0.9 0.25 0 14
execute if score @s ec.fx_vis matches 2.. run particle enchant ~ ~2.0 ~ 0.3 0.8 0.3 0.8 12

# ── CRACKED (3..) ── a radiant flash + a gold→white judgment column (the verdict descends).
execute if score @s ec.fx_vis matches 3.. run particle flash{color:[1.0,0.95,0.6,1.0]} ~ ~1.5 ~
execute if score @s ec.fx_vis matches 3.. run particle dust_color_transition{from_color:[1.0,0.88,0.4],scale:1.7,to_color:[1.0,1.0,0.95]} ~ ~1.6 ~ 0.3 1.1 0.3 0.05 26
execute if score @s ec.fx_vis matches 3.. run particle totem_of_undying ~ ~1.4 ~ 0.3 0.8 0.3 0.1 12
