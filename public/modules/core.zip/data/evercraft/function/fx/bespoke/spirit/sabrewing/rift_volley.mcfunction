# === FX · BESPOKE — SPIRIT "Sabrewing" · Rift Volley (ability1) ===
# Run AS+AT the player (caller: spirit/abilities/sabrewing/ability1 tail). A fan of winged cuts looses
# forward: white and sky-blue feather-slashes streak out in a cone (look-space), end-rod down lifting in
# their wake — over a swift high feather-flute. Channel-gated; one-shot per cast.

# ── SOUND ── a swift rising feather-flute (note-block, no vocal grunt).
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.flute master @s ~ ~ ~ 0.55 1.122
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.flute master @s ~ ~ ~ 0.55 1.587
execute if score @s ec.fx_snd matches 3.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.5 1.682

# ── VISUAL · REDUCED (1) ── a couple feather-cuts straight ahead.
execute if score @s ec.fx_vis matches 1 anchored eyes positioned ^0 ^0 ^2.0 run particle dust{color:[0.95,0.97,1.0],scale:0.9} ~ ~ ~ 0.3 0.2 0.6 0 8

# ── VISUAL · FULL & up (2..) — the fanned volley: center + inner + outer winged cuts loosed forward.
execute if score @s ec.fx_vis matches 2.. anchored eyes positioned ^0 ^0 ^2.5 run particle dust{color:[0.95,0.97,1.0],scale:1.0} ~ ~ ~ 0.2 0.2 1.0 0 14
execute if score @s ec.fx_vis matches 2.. anchored eyes positioned ^-0.9 ^0 ^2.2 run particle dust{color:[0.55,0.78,1.0],scale:0.9} ~ ~ ~ 0.15 0.2 0.8 0 10
execute if score @s ec.fx_vis matches 2.. anchored eyes positioned ^0.9 ^0 ^2.2 run particle dust{color:[0.55,0.78,1.0],scale:0.9} ~ ~ ~ 0.15 0.2 0.8 0 10
execute if score @s ec.fx_vis matches 2.. anchored eyes positioned ^0 ^0 ^2.5 run particle end_rod ~ ~ ~ 0.4 0.25 1.0 0.02 12
execute if score @s ec.fx_vis matches 2.. anchored eyes positioned ^0 ^0 ^2.0 run particle sweep_attack ~ ~ ~ 0.5 0.2 0.3 0 2

# ── EXTRA outer cuts at FULL+ (the wider spirit fan reads here too).
execute if score @s ec.fx_vis matches 2.. anchored eyes positioned ^-1.6 ^0 ^1.8 run particle dust{color:[0.85,0.92,1.0],scale:0.8} ~ ~ ~ 0.12 0.2 0.6 0 6
execute if score @s ec.fx_vis matches 2.. anchored eyes positioned ^1.6 ^0 ^1.8 run particle dust{color:[0.85,0.92,1.0],scale:0.8} ~ ~ ~ 0.12 0.2 0.6 0 6

# ── CRACKED (3..) ── a white→sky bloom + a rising down-feather drift along the fan.
execute if score @s ec.fx_vis matches 3.. anchored eyes positioned ^0 ^0.1 ^2.4 run particle dust_color_transition{from_color:[0.9,0.95,1.0],scale:1.4,to_color:[0.5,0.75,1.0]} ~ ~ ~ 0.5 0.4 1.0 0.03 24
execute if score @s ec.fx_vis matches 3.. anchored eyes positioned ^0 ^0.3 ^2.0 run particle end_rod ~ ~ ~ 0.6 0.3 0.6 0.04 10
