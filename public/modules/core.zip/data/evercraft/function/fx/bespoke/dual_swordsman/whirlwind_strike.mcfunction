# === FX · BESPOKE — DUAL SWORDSMAN "Crossing Fangs" — whirlwind strike (ornate+) ===
# Run AS + AT the player, ANCHORED EYES (caller: dual_swordsman/whirlwind_strike, for #fx_tier 4..). One-shot when
# the 360° Whirlwind procs. Twin blades cut a CROSSING X: two diagonal steel-blue arcs crossing through the player
# (\ and /) drawn in look-space, with a crisp DOUBLE-note cut (the two fangs landing a beat apart). Steel-blue + white.
# Tier 4 ornate / 5 exquisite / 6+ mythical(+spirit) — #fx_tier here is ec.ds_tier (1..7, spirit=7). Channel-gated.

# ── SOUND ── the crisp double-note cut: two clean iron-xylophone strikes a beat apart (the two fangs). Cracked = a high chime.
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.iron_xylophone master @s ~ ~ ~ 0.5 1.335
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.iron_xylophone master @s ~ ~ ~ 0.5 1.682
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:entity.player.attack.sweep master @s ~ ~ ~ 0.35 1.5
execute if score @s ec.fx_snd matches 3.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.45 1.9

# ── VISUAL · REDUCED (1) ── a small steel-blue cross-spark at the center.
execute if score @s ec.fx_vis matches 1 run particle dust{color:[0.45,0.7,1.0],scale:0.8} ~ ~1 ~ 0.4 0.3 0.4 0 8

# ── VISUAL · FULL & up (2..) — the crossing X: arc "\" (high-left → low-right) drawn through look-space.
execute if score @s ec.fx_vis matches 2.. positioned ^-1.0 ^1.0 ^0 run particle dust{color:[0.5,0.72,1.0],scale:0.8} ~ ~ ~ 0 0 0 0 2
execute if score @s ec.fx_vis matches 2.. positioned ^-0.5 ^0.5 ^0 run particle dust{color:[0.6,0.8,1.0],scale:0.85} ~ ~ ~ 0 0 0 0 2
execute if score @s ec.fx_vis matches 2.. positioned ^0.5 ^-0.5 ^0 run particle dust{color:[0.6,0.8,1.0],scale:0.85} ~ ~ ~ 0 0 0 0 2
execute if score @s ec.fx_vis matches 2.. positioned ^1.0 ^-1.0 ^0 run particle dust{color:[0.5,0.72,1.0],scale:0.8} ~ ~ ~ 0 0 0 0 2
# arc "/" (low-left → high-right) — the second fang, crossing the first.
execute if score @s ec.fx_vis matches 2.. positioned ^-1.0 ^-1.0 ^0 run particle dust{color:[0.5,0.72,1.0],scale:0.8} ~ ~ ~ 0 0 0 0 2
execute if score @s ec.fx_vis matches 2.. positioned ^-0.5 ^-0.5 ^0 run particle dust{color:[0.6,0.8,1.0],scale:0.85} ~ ~ ~ 0 0 0 0 2
execute if score @s ec.fx_vis matches 2.. positioned ^0.5 ^0.5 ^0 run particle dust{color:[0.6,0.8,1.0],scale:0.85} ~ ~ ~ 0 0 0 0 2
execute if score @s ec.fx_vis matches 2.. positioned ^1.0 ^1.0 ^0 run particle dust{color:[0.5,0.72,1.0],scale:0.8} ~ ~ ~ 0 0 0 0 2
# the bright cross-point where the fangs meet.
execute if score @s ec.fx_vis matches 2.. run particle dust{color:[0.92,0.96,1.0],scale:0.9} ~ ~1 ~ 0.1 0.1 0.1 0 4
execute if score @s ec.fx_vis matches 2.. run particle crit ~ ~1 ~ 0.3 0.3 0.3 0.3 6

# ── EXQUISITE (5..) ── white edge-glints flung off the arc tips.
execute if score @s ec.fx_vis matches 2.. if score #fx_tier ec.var matches 5.. positioned ^1.2 ^1.2 ^0 run particle end_rod ~ ~ ~ 0.05 0.05 0.05 0.04 2
execute if score @s ec.fx_vis matches 2.. if score #fx_tier ec.var matches 5.. positioned ^-1.2 ^-1.2 ^0 run particle end_rod ~ ~ ~ 0.05 0.05 0.05 0.04 2

# ── MYTHICAL (6..) ── a steel-blue spin-ring at the waist (the twin fangs whirl a full circle).
execute if score @s ec.fx_vis matches 2.. if score #fx_tier ec.var matches 6.. run particle dust{color:[0.5,0.72,1.0],scale:0.95} ~ ~1 ~ 1.6 0.2 1.6 0 18
execute if score @s ec.fx_vis matches 2.. if score #fx_tier ec.var matches 6.. run particle electric_spark ~ ~1 ~ 0.6 0.3 0.6 0.4 8

# ── CRACKED (3..) ── a steel-blue→white cross-bloom at the meeting point (the fangs flash).
execute if score @s ec.fx_vis matches 3.. run particle flash{color:[0.7,0.85,1.0,1.0]} ~ ~1 ~
execute if score @s ec.fx_vis matches 3.. run particle dust_color_transition{from_color:[0.5,0.72,1.0],scale:1.6,to_color:[1.0,1.0,1.0]} ~ ~1 ~ 0.4 0.5 0.4 0.06 24
