# === FX · BESPOKE — ABILITY "Chain Ignition" (Golden Sword of Fire · on-kill flame leap) ===
# Run AS+AT the player (caller: artifacts/abilities/chain_ignition tail). Fire leaps from the slain foe to the
# next: an ember arc outward + a flame flicker on the newly-lit mob, over a crackling fire note + a hot brass
# rise. Channel-gated; one-shot per kill (low-frequency — only on a fiery kill). Apex — ladder-gated.

# ── SOUND ── a crackling ember leap + a rising hot note (musical, no vocal grunt).
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bit master @s ~ ~ ~ 0.35 1.4
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.fire.ambient master @s ~ ~ ~ 0.5 0.9
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.35 1.335
execute if score @s ec.fx_snd matches 3.. run playsound minecraft:block.lava.pop master @s ~ ~ ~ 0.5 1.4

# ── VISUAL · REDUCED (1) ── a small ember pop.
execute if score @s ec.fx_vis matches 1 run particle flame ~ ~1 ~ 0.4 0.4 0.4 0.02 6

# ── VISUAL · FULL & up (2..) ── an ember arc outward + an orange dust web (the fire spreads).
execute if score @s ec.fx_vis matches 2.. run particle flame ~ ~1 ~ 1.2 0.5 1.2 0.04 16
execute if score @s ec.fx_vis matches 2.. run particle dust{color:[1.0,0.55,0.15],scale:0.9} ~ ~1 ~ 1.2 0.5 1.2 0 12
execute if score @s ec.fx_vis matches 2.. run particle small_flame ~ ~0.8 ~ 1.0 0.4 1.0 0.05 10

# ── CRACKED (3..) ── an ember→crimson bloom + a lava flicker (the chain roars).
execute if score @s ec.fx_vis matches 3.. run particle dust_color_transition{from_color:[1.0,0.55,0.15],scale:1.6,to_color:[0.7,0.12,0.05]} ~ ~1 ~ 1.4 0.6 1.4 0.05 22
execute if score @s ec.fx_vis matches 3.. run particle lava ~ ~1 ~ 0.6 0.4 0.6 0 4
