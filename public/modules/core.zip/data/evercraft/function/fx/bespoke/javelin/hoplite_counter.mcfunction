# === FX · BESPOKE — JAVELIN "Valor's Reach" — hoplite counter-flash (ornate+) ===
# Run AS the player, ANCHORED EYES (caller: artifacts/javelin/hoplite_counter, for #fx_tier 4..). One-shot when a
# shield-block opens the counter-thrust window. A sharp bronze counter-FLASH snapping forward off the guard — the
# instant the block turns into a riposte: a crisp bronze gleam-snap ahead + a bright snap-note. The quickest, tightest
# of the four Valor signatures (a reaction, not a swing). Tier (4/5/6) sharpens; channel-gated.

# ── SOUND ── a sharp bronze snap-note (the riposte primed); Full adds a clean ring. Cracked = an amethyst tick.
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.55 1.587
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:entity.player.attack.sweep master @s ~ ~ ~ 0.3 1.6
execute if score @s ec.fx_snd matches 3.. run playsound minecraft:block.amethyst_block.hit master @s ~ ~ ~ 0.4 1.8

# ── VISUAL · REDUCED (1) ── a single bronze snap-mote ahead.
execute if score @s ec.fx_vis matches 1 positioned ^0 ^0 ^1.0 run particle dust{color:[0.9,0.65,0.25],scale:0.8} ~ ~ ~ 0.1 0.1 0.1 0 4

# ── VISUAL · FULL & up (2..) ── a tight forward bronze snap-flash off the guard + a crit spark.
execute if score @s ec.fx_vis matches 2.. positioned ^0 ^0 ^1.0 run particle dust{color:[0.9,0.62,0.22],scale:0.85} ~ ~ ~ 0.12 0.12 0.12 0 6
execute if score @s ec.fx_vis matches 2.. positioned ^0 ^0 ^1.3 run particle dust{color:[1.0,0.75,0.3],scale:0.8} ~ ~ ~ 0.1 0.1 0.1 0 5
execute if score @s ec.fx_vis matches 2.. positioned ^0 ^0 ^1.2 run particle crit ~ ~ ~ 0.15 0.15 0.15 0.25 5

# ── EXQUISITE (5..) ── a brighter snap-glint at the tip.
execute if score @s ec.fx_vis matches 2.. if score #fx_tier ec.var matches 5.. positioned ^0 ^0 ^1.4 run particle electric_spark ~ ~ ~ 0.08 0.08 0.08 0.3 3

# ── MYTHICAL (6) ── a gilded counter-burst — a fuller bronze flare on the riposte.
execute if score @s ec.fx_vis matches 2.. if score #fx_tier ec.var matches 6 positioned ^0 ^0 ^1.2 run particle dust{color:[1.0,0.78,0.3],scale:1.0} ~ ~ ~ 0.2 0.2 0.2 0 8

# ── CRACKED (3..) ── a bronze snap-bloom at the guard-point.
execute if score @s ec.fx_vis matches 3.. positioned ^0 ^0 ^1.2 run particle dust_color_transition{from_color:[0.9,0.62,0.22],scale:1.3,to_color:[1.0,0.9,0.5]} ~ ~ ~ 0.18 0.18 0.18 0.05 12
