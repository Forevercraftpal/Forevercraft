# === FX · BESPOKE — ABILITY "Avalanche" (Frost Shovel · AoE frost + knockback) ===
# Run AS+AT the player (caller: artifacts/abilities/avalanche tail; the frost wave already hit the radius).
# A rolling snow-avalanche cloud sweeps out: a low billow of snow + ice chips + a frost-dust haze, over a
# crystalline chime + a heavy glassy crack. Channel-gated; one-shot per hit. Apex — ladder-gated, no #fx_tier.

# ── SOUND ── a crystalline chime over a heavier glassy break (musical, no vocal grunt).
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.4 1.335
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.4 1.189
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.35 1.587
execute if score @s ec.fx_snd matches 3.. run playsound minecraft:block.amethyst_block.resonate master @s ~ ~ ~ 0.5 1.0

# ── VISUAL · REDUCED (1) ── a small snow billow.
execute if score @s ec.fx_vis matches 1 run particle snowflake ~ ~0.6 ~ 0.7 0.3 0.7 0.02 8

# ── VISUAL · FULL & up (2..) ── a low rolling snow cloud + ice chips + a frost haze.
execute if score @s ec.fx_vis matches 2.. run particle snowflake ~ ~0.4 ~ 2.0 0.25 2.0 0.02 26
execute if score @s ec.fx_vis matches 2.. run particle block{block_state:"minecraft:packed_ice"} ~ ~0.5 ~ 1.8 0.3 1.8 0.15 16
execute if score @s ec.fx_vis matches 2.. run particle dust{color:[0.72,0.9,1.0],scale:1.0} ~ ~0.5 ~ 2.0 0.3 2.0 0 14

# ── CRACKED (3..) ── a sweeping frost-flash + an ice→white avalanche wave.
execute if score @s ec.fx_vis matches 3.. run particle flash{color:[0.75,0.92,1.0,1.0]} ~ ~0.6 ~
execute if score @s ec.fx_vis matches 3.. run particle dust_color_transition{from_color:[0.6,0.85,1.0],scale:1.9,to_color:[1.0,1.0,1.0]} ~ ~0.5 ~ 2.4 0.35 2.4 0.05 32
