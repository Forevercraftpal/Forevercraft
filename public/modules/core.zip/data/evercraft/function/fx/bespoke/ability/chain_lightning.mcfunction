# === FX · BESPOKE — ABILITY "Chain Lightning" (Stormlander · arcing godbolt) ===
# Run AS+AT the player (caller: artifacts/abilities/chain_lightning, on each proc branch — only fires when the
# chain actually triggers). An arc of electric_spark leaps target→target + a white storm-flash, over an electric
# note (high amethyst chime) + a low storm rumble. Channel-gated. Apex — ladder-gated, no #fx_tier.

# ── SOUND ── a crackling electric chord (amethyst chime = the arc, bass = the rumble).
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.4 1.7
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.bit master @s ~ ~ ~ 0.4 1.8
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 0.35 0.595
execute if score @s ec.fx_snd matches 3.. run playsound minecraft:block.amethyst_block.resonate master @s ~ ~ ~ 0.5 1.5

# ── VISUAL · REDUCED (1) ── a small spark pop overhead.
execute if score @s ec.fx_vis matches 1 run particle electric_spark ~ ~1 ~ 0.4 0.5 0.4 0.1 8

# ── VISUAL · FULL & up (2..) ── the arc leaping outward + a pale electric-blue dust web + a white flash spark.
execute if score @s ec.fx_vis matches 2.. run particle electric_spark ~ ~1 ~ 1.5 0.6 1.5 0.3 22
execute if score @s ec.fx_vis matches 2.. run particle dust{color:[0.55,0.8,1.0],scale:0.9} ~ ~1 ~ 1.5 0.6 1.5 0 14
execute if score @s ec.fx_vis matches 2.. run particle end_rod ~ ~1.2 ~ 0.4 0.4 0.4 0.06 6

# ── CRACKED (3..) ── a white storm-flash + a blue→white bolt-arc transition (the godbolt forks).
execute if score @s ec.fx_vis matches 3.. run particle flash{color:[0.85,0.92,1.0,1.0]} ~ ~1 ~
execute if score @s ec.fx_vis matches 3.. run particle dust_color_transition{from_color:[0.5,0.78,1.0],scale:1.6,to_color:[1.0,1.0,1.0]} ~ ~1 ~ 1.8 0.7 1.8 0.06 28
