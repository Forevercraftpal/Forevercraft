# === FX · BESPOKE — STRIKER "Tectonic" ground slam (ornate+) ===
# Run AS + AT the player (caller: artifacts/striker/ground_slam, for #fx_tier 4..).
# The earth answers the mace. MAGNITUDE scales with #sk_stored_impact ec.var (the Impact spent):
#   25-49 = a tremor · 50-74 = a strong quake · 75+ = a fault-line eruption (+ the launch).
# A shockwave dust-disc at the slam radius + a rising debris column + a DEEP musical boom (low
# resonance, no metal clang). Tier (#fx_tier 4/5/6) polishes. Channel-gated; one-shot.

# ── SOUND ── a deep tectonic resonance, heavier with Impact (musical low end).
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 0.8 0.5
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.didgeridoo master @s ~ ~ ~ 0.7 0.45
execute if score @s ec.fx_snd matches 2.. if score #sk_stored_impact ec.var matches 50.. run playsound minecraft:block.amethyst_block.resonate master @s ~ ~ ~ 0.7 0.5
execute if score @s ec.fx_snd matches 3.. if score #sk_stored_impact ec.var matches 75.. run playsound minecraft:entity.generic.explode master @s ~ ~ ~ 0.9 0.4

# ── VISUAL · the shockwave dust-disc on the ground (radius grows with Impact) ──
execute if score @s ec.fx_vis matches 1 run particle dust{color:[0.5,0.42,0.34],scale:1.0} ~ ~0.1 ~ 1.5 0.05 1.5 0 12
execute if score @s ec.fx_vis matches 2.. if score #sk_stored_impact ec.var matches ..49 run particle dust{color:[0.5,0.42,0.34],scale:1.1} ~ ~0.1 ~ 2.5 0.08 2.5 0 30
execute if score @s ec.fx_vis matches 2.. if score #sk_stored_impact ec.var matches 50..74 run particle dust{color:[0.5,0.42,0.34],scale:1.2} ~ ~0.1 ~ 4 0.08 4 0 50
execute if score @s ec.fx_vis matches 2.. if score #sk_stored_impact ec.var matches 75.. run particle dust{color:[0.5,0.42,0.34],scale:1.3} ~ ~0.1 ~ 6 0.1 6 0 80
# Central debris column kicked up by the impact.
execute if score @s ec.fx_vis matches 2.. run particle minecraft:block{block_state:"minecraft:cobblestone"} ~ ~0.3 ~ 0.5 0.6 0.5 0.2 16

# ── EXQUISITE (5..) ── fault-line debris flung outward + a low chord beneath the boom.
execute if score @s ec.fx_vis matches 2.. if score #fx_tier ec.var matches 5.. run particle minecraft:block{block_state:"minecraft:cobblestone"} ~ ~0.2 ~ 2.0 0.1 2.0 0.25 20
execute if score @s ec.fx_snd matches 2.. if score #fx_tier ec.var matches 5.. run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 0.6 0.667

# ── MYTHICAL (6) ── a quaking dust pall over the whole crater.
execute if score @s ec.fx_vis matches 2.. if score #fx_tier ec.var matches 6 run particle large_smoke ~ ~0.5 ~ 1.2 0.3 1.2 0.02 20

# ── 75+ ERUPTION ── a vertical launch column (sells the upward toss).
execute if score @s ec.fx_vis matches 2.. if score #sk_stored_impact ec.var matches 75.. run particle minecraft:block{block_state:"minecraft:cobblestone"} ~ ~0.5 ~ 0.4 0.2 0.4 0.6 24
execute if score @s ec.fx_vis matches 2.. if score #sk_stored_impact ec.var matches 75.. run particle cloud ~ ~0.3 ~ 0.6 0.1 0.6 0.1 16

# ── CRACKED (3..) ── a dust flash + a stone→dark ground wave.
execute if score @s ec.fx_vis matches 3.. run particle flash{color:[0.8,0.7,0.55,1.0]} ~ ~0.4 ~
execute if score @s ec.fx_vis matches 3.. run particle dust_color_transition{from_color:[0.55,0.45,0.35],scale:2.0,to_color:[0.3,0.25,0.2]} ~ ~0.2 ~ 3.0 0.1 3.0 0.05 40
