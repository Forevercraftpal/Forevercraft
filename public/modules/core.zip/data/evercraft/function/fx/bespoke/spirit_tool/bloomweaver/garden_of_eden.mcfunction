# === FX · BESPOKE — SPIRIT TOOL "Bloomweaver" · Garden of Eden (mastery) ===
# Run AS+AT the player (caller: craftforever/spirit_tools/bloomweaver/mastery tail). Life erupts — a wave of
# green growth motes and cherry petals blooms outward across the new garden, crops springing up over a gentle
# rising chime + a warm growth chord. Apex tool: channel-gated only (no #fx_tier).

# ── SOUND ── a soft bloom-pluck + a warm rising chord (harp triad C·E·G).
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 0.6 0.595
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.harp master @s ~ ~ ~ 0.6 0.707
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.harp master @s ~ ~ ~ 0.6 0.891
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.harp master @s ~ ~ ~ 0.6 1.059
execute if score @s ec.fx_snd matches 3.. run playsound minecraft:block.note_block.chime master @s ~ ~ ~ 0.5 1.587

# ── VISUAL · REDUCED (1) ── a small green bloom puff.
execute if score @s ec.fx_vis matches 1 run particle dust{color:[0.45,0.95,0.35],scale:1.0} ~ ~0.5 ~ 1.5 0.4 1.5 0 14

# ── VISUAL · FULL & up (2..) ── a verdant growth wave + a petal flurry + happy bloom motes.
execute if score @s ec.fx_vis matches 2.. run particle dust{color:[0.45,0.95,0.35],scale:1.1} ~ ~0.3 ~ 4.0 0.2 4.0 0 50
execute if score @s ec.fx_vis matches 2.. run particle cherry_leaves ~ ~1.2 ~ 3.5 0.8 3.5 0 36
execute if score @s ec.fx_vis matches 2.. run particle happy_villager ~ ~0.8 ~ 3.0 0.6 3.0 0 24
execute if score @s ec.fx_vis matches 2.. run particle happy_villager ~ ~0.4 ~ 2.5 0.3 2.5 0.1 16

# ── CRACKED (3..) ── a verdant flash + a green→cherry-pink dust bloom pillar + a spore lift.
execute if score @s ec.fx_vis matches 3.. run particle flash{color:[0.6,1.0,0.5,1.0]} ~ ~1 ~
execute if score @s ec.fx_vis matches 3.. run particle dust_color_transition{from_color:[0.45,0.95,0.35],scale:1.9,to_color:[1.0,0.75,0.85]} ~ ~1.0 ~ 1.2 1.4 1.2 0.05 40
execute if score @s ec.fx_vis matches 3.. run particle spore_blossom_air ~ ~1.5 ~ 2.0 1.2 2.0 0 16
