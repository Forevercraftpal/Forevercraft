# === FX · BESPOKE — KNIGHT "Steel & Honor" — fencing stance SETTLES (ornate+) ===
# Run AS + AT the player (caller: artifacts/knight/fencer_off, for #fx_tier 4..). One-shot when the shield is
# raised and the blade lowers to tank guard. The softer half of the salute: a low settling steel note + a brief
# silver-grey dust settle at the feet (the blade rests). Deliberately QUIETER than fencer_on — discipline, not flash.
# Tier (4/5/6) refines lightly; channel-gated.

# ── SOUND ── a low settling bell (the blade lowered); Full adds a soft grounding note. Cracked = a faint resonance.
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.5 0.794
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.4 0.595
execute if score @s ec.fx_snd matches 3.. run playsound minecraft:block.amethyst_block.resonate master @s ~ ~ ~ 0.35 0.6

# ── VISUAL · REDUCED (1) ── a single grey settle mote.
execute if score @s ec.fx_vis matches 1 run particle dust{color:[0.7,0.72,0.78],scale:0.7} ~ ~0.3 ~ 0.2 0.2 0.2 0 4

# ── VISUAL · FULL & up (2..) ── a low silver-grey settle at the feet (the blade rests behind the shield).
execute if score @s ec.fx_vis matches 2.. run particle dust{color:[0.72,0.75,0.82],scale:0.85} ~ ~0.2 ~ 0.4 0.1 0.4 0 8
execute if score @s ec.fx_vis matches 2.. run particle dust{color:[0.9,0.92,0.96],scale:0.6} ~ ~0.5 ~ 0.25 0.15 0.25 0 4

# ── EXQUISITE (5..) ── a faint gold honor-mote at the shield rim.
execute if score @s ec.fx_vis matches 2.. if score #fx_tier ec.var matches 5.. run particle dust{color:[0.95,0.8,0.3],scale:0.8} ~ ~0.8 ~ 0.3 0.1 0.3 0 2

# ── MYTHICAL (6) ── a slow grey-silver ring settling outward (the guard set).
execute if score @s ec.fx_vis matches 2.. if score #fx_tier ec.var matches 6 run particle dust{color:[0.72,0.75,0.82],scale:0.9} ~ ~0.15 ~ 0.9 0.04 0.9 0 12

# ── CRACKED (3..) ── a soft silver settle-cloud (no flash — restraint at rest).
execute if score @s ec.fx_vis matches 3.. run particle dust_color_transition{from_color:[0.78,0.8,0.86],scale:1.4,to_color:[0.5,0.52,0.58]} ~ ~0.3 ~ 0.5 0.2 0.5 0.03 18
