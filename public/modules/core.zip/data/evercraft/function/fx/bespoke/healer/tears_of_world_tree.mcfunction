# === FX · BESPOKE — HEALER "Tears of the World Tree" (Mythical, emergency surge) ===
# Run AT the player (caller: artifacts/healer/use/tears tail, for #fx_tier 4..). The World Tree weeps — an
# emerald wellspring rises, falling-water tears and green life-motes welling up over a gentle ascending chord.
# #fx_tier is 6 (mythical) here but kept tier-aware. Channel-gated; one-shot.

# ── SOUND ── a gentle rising chord (harp E·G·B) + a soft chime at Cracked.
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.harp master @s ~ ~ ~ 0.6 0.891
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.harp master @s ~ ~ ~ 0.6 1.059
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.harp master @s ~ ~ ~ 0.6 1.335
execute if score @s ec.fx_snd matches 3.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.5 1.587

# ── VISUAL · REDUCED (1) ── a small green life puff.
execute if score @s ec.fx_vis matches 1 run particle dust{color:[0.4,0.9,0.45],scale:1.0} ~ ~1 ~ 0.6 0.8 0.6 0 14

# ── VISUAL · FULL & up (2..) ── an emerald wellspring + rising water-tears + green life-motes.
execute if score @s ec.fx_vis matches 2.. run particle dust{color:[0.4,0.9,0.45],scale:1.2} ~ ~1.2 ~ 0.8 1.2 0.8 0 34
execute if score @s ec.fx_vis matches 2.. run particle falling_water ~ ~2.2 ~ 0.8 0.8 0.8 0 24
execute if score @s ec.fx_vis matches 2.. run particle end_rod ~ ~0.4 ~ 0.6 1.0 0.6 0.04 18
execute if score @s ec.fx_vis matches 2.. run particle happy_villager ~ ~1.0 ~ 0.7 0.9 0.7 0 14

# ── MYTHICAL (6) ── a fuller verdant wellspring + a leaf shimmer.
execute if score @s ec.fx_vis matches 2.. if score #fx_tier ec.var matches 6 run particle dust{color:[0.35,0.95,0.4],scale:1.3} ~ ~1.6 ~ 0.9 1.0 0.9 0 24

# ── CRACKED (3..) ── an emerald flash + a green→aqua-water pillar + a leaf burst.
execute if score @s ec.fx_vis matches 3.. run particle flash{color:[0.5,1.0,0.6,1.0]} ~ ~1.2 ~
execute if score @s ec.fx_vis matches 3.. run particle dust_color_transition{from_color:[0.4,0.9,0.45],scale:2.0,to_color:[0.5,0.95,0.85]} ~ ~1.4 ~ 0.7 1.4 0.7 0.05 42
execute if score @s ec.fx_vis matches 3.. run particle minecraft:block{block_state:"minecraft:azalea_leaves"} ~ ~2.0 ~ 0.8 1.0 0.8 0 24
