# === FX · BESPOKE — SPIRIT TOOL "Dustwalker" · Terraform (mastery) ===
# Run AS+AT the player (caller: craftforever/spirit_tools/dustwalker/mastery tail). The land reshapes — a
# rolling tan dust-wave sweeps the flattened ground, sand sifting and settling under a deep settling rumble
# + a warm mellow earth chord. Apex tool: channel-gated only (no #fx_tier).

# ── SOUND ── a low settling rumble + a warm mellow earth chord.
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 0.7 0.5
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.didgeridoo master @s ~ ~ ~ 0.6 0.595
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 0.6 0.794
execute if score @s ec.fx_snd matches 3.. run playsound minecraft:block.amethyst_block.resonate master @s ~ ~ ~ 0.6 0.6

# ── VISUAL · REDUCED (1) ── a small tan dust puff.
execute if score @s ec.fx_vis matches 1 run particle dust{color:[0.82,0.72,0.5],scale:1.0} ~ ~0.4 ~ 1.5 0.3 1.5 0 14

# ── VISUAL · FULL & up (2..) ── a sweeping tan dust-wave + sifting sand + a low settling haze.
execute if score @s ec.fx_vis matches 2.. run particle dust{color:[0.82,0.72,0.5],scale:1.2} ~ ~0.1 ~ 5.0 0.08 5.0 0 56
execute if score @s ec.fx_vis matches 2.. run particle falling_dust{block_state:"minecraft:sand"} ~ ~0.6 ~ 4.0 0.5 4.0 0 30
execute if score @s ec.fx_vis matches 2.. run particle dust{color:[0.5,0.8,0.3],scale:0.8} ~ ~0.3 ~ 4.5 0.2 4.5 0 20

# ── CRACKED (3..) ── a tan flash + a sand→grass-green dust wave + a low dust pall.
execute if score @s ec.fx_vis matches 3.. run particle flash{color:[0.88,0.78,0.55,1.0]} ~ ~0.5 ~
execute if score @s ec.fx_vis matches 3.. run particle dust_color_transition{from_color:[0.82,0.72,0.5],scale:2.0,to_color:[0.5,0.8,0.3]} ~ ~0.3 ~ 4.5 0.15 4.5 0.04 48
execute if score @s ec.fx_vis matches 3.. run particle large_smoke ~ ~0.5 ~ 2.0 0.2 2.0 0.01 14
