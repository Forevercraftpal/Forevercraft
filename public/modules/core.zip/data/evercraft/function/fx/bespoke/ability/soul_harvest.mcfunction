# === FX · BESPOKE — ABILITY "Soul Harvest" (Eyelander · soul drawn on kill) ===
# Run AS+AT the player (caller: artifacts/abilities/soul_harvest tail; ec.eyelander_souls 1..5 is set). A
# soul-blue wisp is drawn up into the bearer + a haunted column that deepens with the soul count, over a
# spectral two-note motif (amethyst + a hollow bass). Channel-gated; one-shot per harvest. Apex — ladder-gated.

# ── SOUND ── a hollow spectral motif (musical/elemental, no vocal grunt).
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 0.45 0.749
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.amethyst_block.hit master @s ~ ~ ~ 0.45 0.5
execute if score @s ec.fx_snd matches 2.. if score @s ec.eyelander_souls matches 5 run playsound minecraft:block.amethyst_block.resonate master @s ~ ~ ~ 0.55 0.5
execute if score @s ec.fx_snd matches 3.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.45 0.749

# ── VISUAL · REDUCED (1) ── a single soul wisp rising.
execute if score @s ec.fx_vis matches 1 run particle soul ~ ~0.8 ~ 0.25 0.5 0.25 0.01 5

# ── VISUAL · FULL & up (2..) ── a soul-blue wisp column drawn up + a spectral dust haze (deepens at 5 souls).
execute if score @s ec.fx_vis matches 2.. run particle soul ~ ~0.8 ~ 0.3 0.6 0.3 0.02 10
execute if score @s ec.fx_vis matches 2.. run particle dust{color:[0.35,0.85,0.8],scale:0.9} ~ ~1 ~ 0.3 0.6 0.3 0 8
execute if score @s ec.fx_vis matches 2.. if score @s ec.eyelander_souls matches 5 run particle soul_fire_flame ~ ~1 ~ 0.35 0.7 0.35 0.02 10

# ── CRACKED (3..) ── a soul-blue → ghost-white wisp bloom (the harvested soul rises).
execute if score @s ec.fx_vis matches 3.. run particle dust_color_transition{from_color:[0.3,0.85,0.82],scale:1.5,to_color:[0.85,1.0,0.95]} ~ ~1.1 ~ 0.35 0.7 0.35 0.04 20
execute if score @s ec.fx_vis matches 3.. run particle end_rod ~ ~0.9 ~ 0.2 0.7 0.2 0.03 6
