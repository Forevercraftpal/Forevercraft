# === FX · BESPOKE — SET "Phantom" · Phantom Form (active) ===
# Run AS+AT the player (caller: artifacts/sets/phantom/phantom_form, past the 4pc gate). The wearer fades:
# a pale translucent drift of wisps swirls in as form thins, reverse-portal motes scatter, and a soft airy
# flute breath rings (the vanishing). Channel-gated; one-shot per cast.

# ── SOUND ── a soft airy breath (flute high triad) — the body thinning to mist.
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.flute master @s ~ ~ ~ 0.7 1.189
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.flute master @s ~ ~ ~ 0.7 1.414
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.flute master @s ~ ~ ~ 0.6 1.587
execute if score @s ec.fx_snd matches 3.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.5 0.8

# ── VISUAL · REDUCED (1) ── a small pale wisp + a glint.
execute if score @s ec.fx_vis matches 1 run particle dust{color:[0.8,0.82,0.88],scale:0.9} ~ ~1 ~ 0.5 0.6 0.5 0 12
execute if score @s ec.fx_vis matches 1 run particle reverse_portal ~ ~1 ~ 0.4 0.5 0.4 0.03 6

# ── VISUAL · FULL & up (2..) ── a translucent drift: pale wisp column + a faint dust ring + scattering motes.
execute if score @s ec.fx_vis matches 2.. run particle dust{color:[0.82,0.84,0.9],scale:1.1} ~ ~1.0 ~ 0.7 0.9 0.7 0 24
execute if score @s ec.fx_vis matches 2.. run particle reverse_portal ~ ~1.0 ~ 0.6 0.8 0.6 0.04 20
execute if score @s ec.fx_vis matches 2.. run particle dust{color:[0.7,0.74,0.85],scale:1.0} ~ ~0.2 ~ 1.8 0.12 1.8 0 18
execute if score @s ec.fx_vis matches 2.. run particle cloud ~ ~1.0 ~ 0.6 0.6 0.6 0.02 10

# ── CRACKED (3..) ── a pale flash + a grey→ghost-white drift pillar + a soft mist.
execute if score @s ec.fx_vis matches 3.. run particle flash{color:[0.82,0.84,0.9,1.0]} ~ ~1.0 ~
execute if score @s ec.fx_vis matches 3.. run particle dust_color_transition{from_color:[0.6,0.62,0.7],scale:1.9,to_color:[0.95,0.96,1.0]} ~ ~1.2 ~ 0.7 1.0 0.7 0.05 36
execute if score @s ec.fx_vis matches 3.. run particle large_smoke ~ ~1.0 ~ 0.8 0.5 0.8 0.01 14
