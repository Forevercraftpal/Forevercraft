# === FX · BESPOKE — SET "Frost" · Blizzard (active) ===
# Run AS+AT the player (caller: artifacts/sets/frost/blizzard, past the 4pc gate). An ice storm whirls out:
# an ice-cyan shatter-ring snaps outward, snowflakes spiral, and a crystalline glassy shiver rings (the
# freeze takes hold). Channel-gated; one-shot per cast.

# ── SOUND ── a crystalline frost shiver (bell + bit high triad) + a brittle ice crack.
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.7 1.189
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.7 1.414
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.bit master @s ~ ~ ~ 0.5 1.587
execute if score @s ec.fx_snd matches 3.. run playsound minecraft:block.glass.break master @s ~ ~ ~ 0.6 1.4

# ── VISUAL · REDUCED (1) ── a small snow puff + a cyan glint.
execute if score @s ec.fx_vis matches 1 run particle snowflake ~ ~1 ~ 0.6 0.6 0.6 0.02 14
execute if score @s ec.fx_vis matches 1 run particle dust{color:[0.55,0.85,1.0],scale:0.9} ~ ~1 ~ 0.5 0.5 0.5 0 6

# ── VISUAL · FULL & up (2..) ── a blizzard whirl: snowflake spiral + an ice-cyan shatter ring + frost dust.
execute if score @s ec.fx_vis matches 2.. run particle snowflake ~ ~1.0 ~ 1.4 1.0 1.4 0.04 36
execute if score @s ec.fx_vis matches 2.. run particle dust{color:[0.5,0.82,1.0],scale:1.2} ~ ~0.2 ~ 2.4 0.15 2.4 0 28
execute if score @s ec.fx_vis matches 2.. run particle dust{color:[0.8,0.95,1.0],scale:1.0} ~ ~1.2 ~ 1.0 0.8 1.0 0 20
execute if score @s ec.fx_vis matches 2.. run particle item_snowball ~ ~1.0 ~ 1.0 0.6 1.0 0.05 10

# ── CRACKED (3..) ── a cyan flash + a deep-blue→frost-white shatter pillar + an ice-shard burst.
execute if score @s ec.fx_vis matches 3.. run particle flash{color:[0.6,0.88,1.0,1.0]} ~ ~1.0 ~
execute if score @s ec.fx_vis matches 3.. run particle dust_color_transition{from_color:[0.2,0.5,0.85],scale:2.0,to_color:[0.92,0.98,1.0]} ~ ~1.2 ~ 0.8 1.0 0.8 0.05 38
execute if score @s ec.fx_vis matches 3.. run particle block{block_state:"minecraft:blue_ice"} ~ ~1.0 ~ 1.4 0.6 1.4 0.1 24
