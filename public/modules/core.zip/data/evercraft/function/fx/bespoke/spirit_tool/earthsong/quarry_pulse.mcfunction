# === FX · BESPOKE — SPIRIT TOOL "Earthsong" · Quarry Pulse (mastery) ===
# Run AS+AT the player (caller: craftforever/spirit_tools/earthsong/mastery tail). The mountain answers —
# an aqua-diamond shockwave rings out as the quarry is carved, crystalline shards glittering up from the
# excavated cube over a deep resonant boom + a bright crystal chord. Apex tool: channel-gated only (no #fx_tier).

# ── SOUND ── a deep stone resonance + a bright aqua-diamond chord (bell triad A·C#·E).
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 0.7 0.5
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.6 0.595
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.6 0.749
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.6 0.891
execute if score @s ec.fx_snd matches 3.. run playsound minecraft:block.amethyst_block.resonate master @s ~ ~ ~ 0.7 1.4

# ── VISUAL · REDUCED (1) ── a small aqua shimmer.
execute if score @s ec.fx_vis matches 1 run particle dust{color:[0.4,0.9,1.0],scale:1.0} ~ ~0.5 ~ 1.0 0.4 1.0 0 12

# ── VISUAL · FULL & up (2..) ── an aqua shockwave disc + a crystal-glint column rising from the cube.
execute if score @s ec.fx_vis matches 2.. run particle dust{color:[0.4,0.9,1.0],scale:1.2} ~ ~0.2 ~ 3.5 0.1 3.5 0 50
execute if score @s ec.fx_vis matches 2.. run particle crit ~ ~0.5 ~ 1.5 1.2 1.5 0.1 24
execute if score @s ec.fx_vis matches 2.. run particle enchant ~ ~2.0 ~ 1.2 1.5 1.2 0.4 24
execute if score @s ec.fx_vis matches 2.. run particle end_rod ~ ~0.3 ~ 0.6 0.2 0.6 0.06 12

# ── CRACKED (3..) ── an aqua flash + a diamond-bright dust pillar + electric sparks.
execute if score @s ec.fx_vis matches 3.. run particle flash{color:[0.5,0.95,1.0,1.0]} ~ ~1 ~
execute if score @s ec.fx_vis matches 3.. run particle dust_color_transition{from_color:[0.4,0.9,1.0],scale:2.0,to_color:[0.85,0.98,1.0]} ~ ~1.0 ~ 1.0 1.4 1.0 0.05 40
execute if score @s ec.fx_vis matches 3.. run particle electric_spark ~ ~0.8 ~ 1.5 0.8 1.5 0.05 20
