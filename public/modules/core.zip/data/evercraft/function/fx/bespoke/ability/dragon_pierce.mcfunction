# === FX · BESPOKE — ABILITY "Dragon Pierce" (Dragonmaster Lance · mythical on-hit) ===
# Run AS+AT the player (caller: artifacts/abilities/dragon_pierce tail). The lance breathes dragonfire down
# the thrust: a draconic-fire lance cone in look-space + an ember bloom on the struck foe, over a draconic
# growl-note (intimidation carve-out OK — this is a named dragon weapon) + a hot brass note. Channel-gated.
# Apex weapon: gated purely on the fx_vis/fx_snd ladder (no #fx_tier). Moderate — fires on every hit.

# ── SOUND ── a low draconic resonance + a hot ember note (musical, growl carve-out for the dragon weapon).
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.didgeridoo master @s ~ ~ ~ 0.5 0.5
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 0.4 0.595
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:entity.ender_dragon.growl master @s ~ ~ ~ 0.22 1.6
execute if score @s ec.fx_snd matches 3.. run playsound minecraft:block.fire.ambient master @s ~ ~ ~ 0.6 0.8

# ── VISUAL · REDUCED (1) ── a small dragon-breath puff down the thrust.
execute if score @s ec.fx_vis matches 1 anchored eyes positioned ^0 ^-0.1 ^1.2 run particle dragon_breath ~ ~ ~ 0.2 0.2 0.2 0.01 5

# ── VISUAL · FULL & up (2..) ── a dragonfire lance-cone down the line of sight + an ember bloom on the foe.
execute if score @s ec.fx_vis matches 2.. anchored eyes positioned ^0 ^-0.1 ^1.2 run particle dragon_breath ~ ~ ~ 0.22 0.25 0.22 0.01 8
execute if score @s ec.fx_vis matches 2.. anchored eyes positioned ^0 ^-0.1 ^2.2 run particle flame ~ ~ ~ 0.25 0.25 0.4 0.01 10
execute if score @s ec.fx_vis matches 2.. anchored eyes positioned ^0 ^-0.1 ^2.2 run particle dust{color:[1.0,0.5,0.12],scale:1.0} ~ ~ ~ 0.2 0.2 0.4 0 8
execute if score @s ec.fx_vis matches 2.. anchored eyes positioned ^0 ^-0.1 ^2.2 run particle lava ~ ~ ~ 0.25 0.25 0.4 0 4

# ── CRACKED (3..) ── a wyrm-flame bloom + a soul-fire ember trail (the dragon's wrath answers).
execute if score @s ec.fx_vis matches 3.. anchored eyes positioned ^0 ^-0.1 ^2.6 run particle dust_color_transition{from_color:[1.0,0.55,0.15],scale:1.6,to_color:[0.7,0.1,0.05]} ~ ~ ~ 0.3 0.3 0.6 0.04 16
execute if score @s ec.fx_vis matches 3.. anchored eyes positioned ^0 ^-0.1 ^1.6 run particle soul_fire_flame ~ ~ ~ 0.2 0.2 0.4 0.02 8
