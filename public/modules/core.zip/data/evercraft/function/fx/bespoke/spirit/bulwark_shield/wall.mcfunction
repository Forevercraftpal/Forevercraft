# === FX · BESPOKE — SPIRIT "Bulwark Shield" · Unbreakable Wall (ability1) ===
# Run AS+AT the player (caller: spirit/abilities/bulwark_shield/ability1 tail — fires when the shield is
# planted). The aegis answers: a steel-blue ward-ring rises with a gold-rimmed bastion glow, the ground
# settling under the bearer — over a deep steel toll. Channel-gated; one-shot per cast.

# ── SOUND ── a deep steel ward-toll (note-block iron + bass, no vocal grunt).
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.iron_xylophone master @s ~ ~ ~ 0.7 0.5
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 0.7 0.595
execute if score @s ec.fx_snd matches 3.. run playsound minecraft:block.amethyst_block.resonate master @s ~ ~ ~ 0.6 0.794

# ── VISUAL · REDUCED (1) ── a small steel ring + a gold glint.
execute if score @s ec.fx_vis matches 1 run particle dust{color:[0.4,0.55,0.8],scale:0.9} ~ ~0.4 ~ 1.5 0.3 1.5 0 14
execute if score @s ec.fx_vis matches 1 run particle dust{color:[1.0,0.85,0.4],scale:0.6} ~ ~0.5 ~ 1.5 0.3 1.5 0 8

# ── VISUAL · FULL & up (2..) ── the rising ward-ring: steel-blue column + a gold-rimmed bastion glow + enchant ward.
execute if score @s ec.fx_vis matches 2.. run particle dust{color:[0.4,0.55,0.8],scale:1.1} ~ ~0.4 ~ 2.5 0.4 2.5 0 36
execute if score @s ec.fx_vis matches 2.. run particle dust{color:[1.0,0.85,0.4],scale:0.7} ~ ~0.8 ~ 2.2 0.7 2.2 0 18
execute if score @s ec.fx_vis matches 2.. run particle enchant ~ ~1.6 ~ 1.4 0.8 1.4 0.1 16
execute if score @s ec.fx_vis matches 2.. run particle dust{color:[0.55,0.7,0.95],scale:0.8} ~ ~1.2 ~ 1.0 1.0 1.0 0 14

# ── CRACKED (3..) ── a steel→gold ward-bloom flash + a standing bastion column.
execute if score @s ec.fx_vis matches 3.. run particle flash{color:[0.5,0.65,0.95,1.0]} ~ ~0.6 ~
execute if score @s ec.fx_vis matches 3.. run particle dust_color_transition{from_color:[0.4,0.55,0.85],scale:1.7,to_color:[1.0,0.85,0.4]} ~ ~0.8 ~ 2.6 0.8 2.6 0.03 34
execute if score @s ec.fx_vis matches 3.. run particle enchant ~ ~2 ~ 1.2 1.0 1.2 0.2 12
