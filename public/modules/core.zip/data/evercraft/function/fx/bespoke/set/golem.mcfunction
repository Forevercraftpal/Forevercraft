# === FX · BESPOKE — SET "Golem" · Golem Smash (active) ===
# Run AS+AT the player (caller: artifacts/sets/golem/golem_smash). An iron-clad ground slam: an iron-grey
# dust shockwave kicks out, debris flies, and a deep sturdy anvil-thud booms (the golem's fist lands).
# Channel-gated; one-shot per cast.

# ── SOUND ── a sturdy thud (bass + basedrum) + an iron clank made musical.
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 0.8 0.5
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.basedrum master @s ~ ~ ~ 0.8 0.45
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.iron_xylophone master @s ~ ~ ~ 0.6 0.5
execute if score @s ec.fx_snd matches 3.. run playsound minecraft:block.anvil.land master @s ~ ~ ~ 0.5 0.5

# ── VISUAL · REDUCED (1) ── a small dust pop + an iron chip.
execute if score @s ec.fx_vis matches 1 run particle dust{color:[0.62,0.64,0.66],scale:1.0} ~ ~0.1 ~ 1.2 0.05 1.2 0 12
execute if score @s ec.fx_vis matches 1 run particle block{block_state:"minecraft:iron_block"} ~ ~0.3 ~ 0.4 0.3 0.4 0.1 4

# ── VISUAL · FULL & up (2..) ── an iron-grey shockwave disc + a debris column + a crit spray.
execute if score @s ec.fx_vis matches 2.. run particle dust{color:[0.6,0.62,0.64],scale:1.2} ~ ~0.1 ~ 2.6 0.08 2.6 0 36
execute if score @s ec.fx_vis matches 2.. run particle block{block_state:"minecraft:iron_block"} ~ ~0.3 ~ 0.6 0.5 0.6 0.2 18
execute if score @s ec.fx_vis matches 2.. run particle crit ~ ~0.5 ~ 1.0 0.4 1.0 0.15 22
execute if score @s ec.fx_vis matches 2.. run particle cloud ~ ~0.2 ~ 1.4 0.1 1.4 0.05 12

# ── CRACKED (3..) ── a steel flash + an iron-grey→dark ground wave + a debris launch.
execute if score @s ec.fx_vis matches 3.. run particle flash{color:[0.7,0.72,0.75,1.0]} ~ ~0.3 ~
execute if score @s ec.fx_vis matches 3.. run particle dust_color_transition{from_color:[0.68,0.7,0.72],scale:2.0,to_color:[0.4,0.41,0.43]} ~ ~0.2 ~ 3.0 0.1 3.0 0.05 40
execute if score @s ec.fx_vis matches 3.. run particle block{block_state:"minecraft:iron_block"} ~ ~0.4 ~ 0.4 0.2 0.4 0.6 20
