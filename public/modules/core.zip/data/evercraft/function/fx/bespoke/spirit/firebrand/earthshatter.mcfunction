# === FX · BESPOKE — SPIRIT "Firebrand" · Earthshatter (ability1) ===
# Run AS+AT the player (caller: spirit/abilities/firebrand/ability1 tail). The brand slams the ground:
# a searing ring of flame erupts outward, orange-red embers fling up, a hot ash pall settles — over a
# deep fire-boom. Channel-gated; one-shot per cast.

# ── SOUND ── a heavy searing boom (note-block low end + a warm bell crackle, no vocal grunt).
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 0.8 0.45
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.5 0.794
execute if score @s ec.fx_snd matches 3.. run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.5 1.059

# ── VISUAL · REDUCED (1) ── a small flame ring + embers.
execute if score @s ec.fx_vis matches 1 run particle flame ~ ~0.2 ~ 1.5 0.1 1.5 0.02 16
execute if score @s ec.fx_vis matches 1 run particle dust{color:[1.0,0.42,0.12],scale:1.0} ~ ~0.2 ~ 1.5 0.1 1.5 0 12

# ── VISUAL · FULL & up (2..) ── the searing shockwave ring + flung embers + a launch flame column.
execute if score @s ec.fx_vis matches 2.. run particle flame ~ ~0.2 ~ 3.0 0.1 3.0 0.03 40
execute if score @s ec.fx_vis matches 2.. run particle dust{color:[1.0,0.4,0.1],scale:1.2} ~ ~0.2 ~ 3.0 0.15 3.0 0 30
execute if score @s ec.fx_vis matches 2.. run particle lava ~ ~0.3 ~ 1.0 0.2 1.0 0.1 12
execute if score @s ec.fx_vis matches 2.. run particle flame ~ ~0.5 ~ 0.4 0.6 0.4 0.12 16

# ── CRACKED (3..) ── an orange→ember flash-bloom + a smouldering ash pall.
execute if score @s ec.fx_vis matches 3.. run particle flash{color:[1.0,0.5,0.15,1.0]} ~ ~0.4 ~
execute if score @s ec.fx_vis matches 3.. run particle dust_color_transition{from_color:[1.0,0.45,0.1],scale:1.8,to_color:[0.4,0.1,0.05]} ~ ~0.3 ~ 3.2 0.2 3.2 0.05 36
execute if score @s ec.fx_vis matches 3.. run particle ash ~ ~0.6 ~ 2.5 0.4 2.5 0.02 24
