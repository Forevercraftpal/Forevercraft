# === FX · BESPOKE — ABILITY "Explosive Impact" (Blastbreaker Mace · 25% burst) ===
# Run AS+AT the player (caller: artifacts/abilities/explosive_impact — only on a confirmed proc branch, NOT
# every hit). A sharp blast ring + a debris kick + a punchy musical boom (bass/basedrum, no metal clang).
# Channel-gated; one-shot per proc. Apex — ladder-gated, no #fx_tier.

# ── SOUND ── a punchy concussive boom (musical low end).
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 0.55 0.5
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.basedrum master @s ~ ~ ~ 0.55 0.7
execute if score @s ec.fx_snd matches 3.. run playsound minecraft:block.note_block.didgeridoo master @s ~ ~ ~ 0.45 0.5

# ── VISUAL · REDUCED (1) ── a small smoke pop.
execute if score @s ec.fx_vis matches 1 run particle smoke ~ ~0.6 ~ 0.4 0.3 0.4 0.02 6

# ── VISUAL · FULL & up (2..) ── a low blast ring + a dust kick.
execute if score @s ec.fx_vis matches 2.. run particle dust{color:[0.6,0.45,0.3],scale:1.0} ~ ~0.2 ~ 1.5 0.08 1.5 0 20
execute if score @s ec.fx_vis matches 2.. run particle cloud ~ ~0.4 ~ 0.5 0.2 0.5 0.05 10
execute if score @s ec.fx_vis matches 2.. run particle lava ~ ~0.5 ~ 0.4 0.3 0.4 0 4

# ── CRACKED (3..) ── a hot flash + an ember→ash blast wave.
execute if score @s ec.fx_vis matches 3.. run particle flash{color:[1.0,0.8,0.45,1.0]} ~ ~0.6 ~
execute if score @s ec.fx_vis matches 3.. run particle dust_color_transition{from_color:[1.0,0.6,0.2],scale:1.8,to_color:[0.35,0.3,0.25]} ~ ~0.3 ~ 2.0 0.1 2.0 0.05 28
