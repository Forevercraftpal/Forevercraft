# === FX · BESPOKE — JAVELIN "Valor's Reach" — aegis shield-wall (ornate+) ===
# Run AS + AT the player (caller: artifacts/javelin/aegis_burst, for #fx_tier 4..). One-shot when the Hoplite's
# Aegis Burst raises (Absorption granted). A cyan shield-wall shimmers up around the lord: a guarding ring at the
# feet + a rising aegis-dome of cyan motes (the bulwark forming) + a steady protective tone. Cyan aegis offsets the
# warm bronze of the offensive signatures. Tier (4 ornate · 5 exquisite · 6 mythical) thickens the wall; gated.
# (One of four related Valor signatures — this is the defensive guard.)

# ── SOUND ── a steady protective bell tone; Full adds a grounding chord. Cracked = a resonant ward.
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.6 1.059
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.5 1.335
execute if score @s ec.fx_snd matches 3.. run playsound minecraft:block.amethyst_block.resonate master @s ~ ~ ~ 0.5 1.0

# ── VISUAL · REDUCED (1) ── a small cyan guard-ring.
execute if score @s ec.fx_vis matches 1 run particle dust{color:[0.35,0.85,0.95],scale:0.8} ~ ~0.2 ~ 1.0 0.05 1.0 0 8

# ── VISUAL · FULL & up (2..) ── the cyan guard-ring at the feet + a rising aegis-dome of cyan motes.
execute if score @s ec.fx_vis matches 2.. run particle dust{color:[0.3,0.8,0.95],scale:0.95} ~ ~0.15 ~ 1.4 0.05 1.4 0 18
execute if score @s ec.fx_vis matches 2.. run particle dust{color:[0.5,0.9,1.0],scale:0.8} ~ ~1.1 ~ 1.0 0.7 1.0 0 16
execute if score @s ec.fx_vis matches 2.. run particle end_rod ~ ~0.5 ~ 0.6 0.5 0.6 0.02 6

# ── EXQUISITE (5..) ── a brighter dome cap + a soft high ward-note.
execute if score @s ec.fx_vis matches 2.. if score #fx_tier ec.var matches 5.. run particle dust{color:[0.6,0.92,1.0],scale:0.85} ~ ~1.8 ~ 0.5 0.3 0.5 0 10
execute if score @s ec.fx_snd matches 2.. if score #fx_tier ec.var matches 5.. run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.35 1.682

# ── MYTHICAL (6) ── a full bulwark — a wider double-ring + an aegis flash-cap at the crown.
execute if score @s ec.fx_vis matches 2.. if score #fx_tier ec.var matches 6 run particle dust{color:[0.3,0.8,0.95],scale:1.0} ~ ~0.1 ~ 2.0 0.04 2.0 0 22
execute if score @s ec.fx_vis matches 2.. if score #fx_tier ec.var matches 6 run particle dust{color:[0.55,0.92,1.0],scale:0.9} ~ ~2.0 ~ 0.4 0.2 0.4 0 8

# ── CRACKED (3..) ── a cyan ward-flash + a cyan→white aegis dome-pillar.
execute if score @s ec.fx_vis matches 3.. run particle flash{color:[0.5,0.9,1.0,1.0]} ~ ~1 ~
execute if score @s ec.fx_vis matches 3.. run particle dust_color_transition{from_color:[0.3,0.8,0.95],scale:1.7,to_color:[0.9,1.0,1.0]} ~ ~1.2 ~ 0.7 0.9 0.7 0.05 30
