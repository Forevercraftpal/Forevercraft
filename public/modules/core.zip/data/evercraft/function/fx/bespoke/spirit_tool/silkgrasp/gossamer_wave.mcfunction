# === FX · BESPOKE — SPIRIT TOOL "Silkgrasp" · Gossamer Wave (mastery) ===
# Run AS+AT the player (caller: craftforever/spirit_tools/silkgrasp/mastery tail). A shimmering gossamer
# pulse rings outward — gold motes, drifting honey and glowing wisps as the wave shears and gathers, over a
# warm hive chord on the iron xylophone (F#·A#·C'). Apex tool: channel-gated only (no #fx_tier).

# ── SOUND ── a soft hive-pluck + a warm gold chord (iron_xylophone triad).
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.harp master @s ~ ~ ~ 0.6 0.595
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.iron_xylophone master @s ~ ~ ~ 0.6 1.0
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.iron_xylophone master @s ~ ~ ~ 0.6 1.26
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.iron_xylophone master @s ~ ~ ~ 0.6 1.414
execute if score @s ec.fx_snd matches 3.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.5 1.587

# ── VISUAL · REDUCED (1) ── a small gold shimmer.
execute if score @s ec.fx_vis matches 1 run particle dust{color:[1.0,0.78,0.25],scale:1.0} ~ ~0.6 ~ 1.5 0.4 1.5 0 14

# ── VISUAL · FULL & up (2..) ── a gold gossamer ring + drifting honey + glowing gather-wisps.
execute if score @s ec.fx_vis matches 2.. run particle dust{color:[1.0,0.78,0.25],scale:1.1} ~ ~0.5 ~ 4.5 0.2 4.5 0 50
execute if score @s ec.fx_vis matches 2.. run particle falling_honey ~ ~1.2 ~ 3.5 0.8 3.5 0 28
execute if score @s ec.fx_vis matches 2.. run particle glow ~ ~1.0 ~ 3.0 0.8 3.0 0.1 24
execute if score @s ec.fx_vis matches 2.. run particle end_rod ~ ~0.6 ~ 0.6 0.2 0.6 0.05 12

# ── CRACKED (3..) ── a gold flash + a honey→pale-gold dust pillar + a glow spark burst.
execute if score @s ec.fx_vis matches 3.. run particle flash{color:[1.0,0.85,0.4,1.0]} ~ ~1 ~
execute if score @s ec.fx_vis matches 3.. run particle dust_color_transition{from_color:[1.0,0.78,0.25],scale:1.9,to_color:[1.0,0.95,0.6]} ~ ~1.0 ~ 1.2 1.4 1.2 0.05 40
execute if score @s ec.fx_vis matches 3.. run particle glow ~ ~1.2 ~ 3.0 1.0 3.0 0.15 20
