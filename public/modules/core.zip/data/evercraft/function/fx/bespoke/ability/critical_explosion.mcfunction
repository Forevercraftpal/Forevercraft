# === FX · BESPOKE — ABILITY "Critical Explosion" (Worldbreaker · aftershock burst) ===
# Run AS+AT the player (caller: artifacts/abilities/critical_explosion tail; the ability already burst at the
# target). A sharp aftershock ring + a debris kick + a flung-up dust spray, over a deep musical boom (bass,
# no metal clang). Channel-gated; one-shot per proc. Apex — ladder-gated, no #fx_tier.

# ── SOUND ── a deep concussive boom (musical low end + a punchy note).
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 0.6 0.45
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.basedrum master @s ~ ~ ~ 0.6 0.6
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.didgeridoo master @s ~ ~ ~ 0.4 0.5
execute if score @s ec.fx_snd matches 3.. run playsound minecraft:block.amethyst_block.resonate master @s ~ ~ ~ 0.5 0.4

# ── VISUAL · REDUCED (1) ── a small smoke pop.
execute if score @s ec.fx_vis matches 1 run particle smoke ~ ~0.6 ~ 0.5 0.3 0.5 0.02 8

# ── VISUAL · FULL & up (2..) ── a low shockwave ring + a kicked-up dust spray.
execute if score @s ec.fx_vis matches 2.. run particle dust{color:[0.55,0.5,0.45],scale:1.1} ~ ~0.2 ~ 2.0 0.08 2.0 0 26
execute if score @s ec.fx_vis matches 2.. run particle cloud ~ ~0.4 ~ 0.6 0.2 0.6 0.06 12
execute if score @s ec.fx_vis matches 2.. run particle large_smoke ~ ~0.6 ~ 0.5 0.3 0.5 0.02 8

# ── CRACKED (3..) ── a hot flash + a grey→dark blast wave (the worldbreaker's aftershock).
execute if score @s ec.fx_vis matches 3.. run particle flash{color:[1.0,0.85,0.55,1.0]} ~ ~0.6 ~
execute if score @s ec.fx_vis matches 3.. run particle dust_color_transition{from_color:[0.7,0.62,0.5],scale:2.0,to_color:[0.3,0.27,0.24]} ~ ~0.3 ~ 2.6 0.1 2.6 0.05 34
