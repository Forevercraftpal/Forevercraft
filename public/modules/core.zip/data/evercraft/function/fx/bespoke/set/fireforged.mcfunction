# === FX · BESPOKE — SET "Fireforged/Phoenix" · set-complete (4pc apply) ===
# Run AS+AT the player (caller: artifacts/sets/fireforged/bonus_4pc, ONE-SHOT — guarded by the same
# `unless tag fireforged_4pc`). NO per-fire active on this set (the rebirth fires in worn_tick), so the
# flourish marks Phoenix Rebirth arming: an ember→gold rebirth bloom blossoms upward with rising sparks,
# over a soaring chime. Channel-gated; one-shot.

# ── SOUND ── a soaring rebirth chime (bell rising triad) + a phoenix ember whoosh.
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.7 0.794
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.7 1.0
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.7 1.335
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:item.firecharge.use master @s ~ ~ ~ 0.5 0.8
execute if score @s ec.fx_snd matches 3.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.6 0.7

# ── VISUAL · REDUCED (1) ── a small ember puff + a gold glint.
execute if score @s ec.fx_vis matches 1 run particle flame ~ ~0.8 ~ 0.4 0.6 0.4 0.02 8
execute if score @s ec.fx_vis matches 1 run particle dust{color:[1.0,0.78,0.25],scale:0.9} ~ ~1.2 ~ 0.5 0.5 0.5 0 6

# ── VISUAL · FULL & up (2..) ── an ember→gold rebirth bloom: rising flame + gold dust + soul-fire wing flecks.
execute if score @s ec.fx_vis matches 2.. run particle flame ~ ~0.8 ~ 0.5 1.0 0.5 0.04 24
execute if score @s ec.fx_vis matches 2.. run particle dust{color:[1.0,0.78,0.25],scale:1.1} ~ ~1.4 ~ 0.7 1.0 0.7 0 22
execute if score @s ec.fx_vis matches 2.. run particle dust{color:[1.0,0.4,0.1],scale:1.0} ~ ~0.2 ~ 2.0 0.12 2.0 0 20
execute if score @s ec.fx_vis matches 2.. run particle small_flame ~ ~1.2 ~ 0.6 0.8 0.6 0.03 14

# ── CRACKED (3..) ── a gold flash + an ember-red→phoenix-gold rebirth pillar + a rising spark plume.
execute if score @s ec.fx_vis matches 3.. run particle flash{color:[1.0,0.72,0.25,1.0]} ~ ~1.2 ~
execute if score @s ec.fx_vis matches 3.. run particle dust_color_transition{from_color:[0.85,0.2,0.05],scale:2.0,to_color:[1.0,0.85,0.35]} ~ ~1.4 ~ 0.7 1.4 0.7 0.06 38
execute if score @s ec.fx_vis matches 3.. run particle firework ~ ~1.6 ~ 0.5 0.8 0.5 0.05 22
