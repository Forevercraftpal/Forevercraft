# === FX · BESPOKE — SPIRIT "Pharaoh's Fist" · Chrono Fist (ability1) ===
# Run AS+AT the player (caller: spirit/abilities/pharaoh_fist/ability1 tail). Time bows to the god-king:
# a ring of suspended desert sand hangs frozen in the air, sun-gold glyph-motes orbit the held instant —
# over a slow, suspended harp tone. Channel-gated; one-shot per cast.

# ── SOUND ── a slow suspended harp + a glassy time-stop chime (note-block, no vocal grunt).
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.harp master @s ~ ~ ~ 0.6 0.595
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.harp master @s ~ ~ ~ 0.6 0.891
execute if score @s ec.fx_snd matches 3.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.5 1.587

# ── VISUAL · REDUCED (1) ── a small suspended sand ring + a gold glint.
execute if score @s ec.fx_vis matches 1 run particle dust{color:[0.85,0.72,0.4],scale:0.9} ~ ~1 ~ 1.2 0.6 1.2 0 14
execute if score @s ec.fx_vis matches 1 run particle dust{color:[1.0,0.85,0.25],scale:0.6} ~ ~1 ~ 1.0 0.5 1.0 0 8

# ── VISUAL · FULL & up (2..) ── the frozen sandstorm ring + orbiting sun-gold glyph-motes (suspended, no spread).
execute if score @s ec.fx_vis matches 2.. run particle dust{color:[0.85,0.72,0.4],scale:1.0} ~ ~1 ~ 2.5 0.8 2.5 0 40
execute if score @s ec.fx_vis matches 2.. run particle dust{color:[1.0,0.85,0.25],scale:0.7} ~ ~1.2 ~ 2.0 0.9 2.0 0 24
execute if score @s ec.fx_vis matches 2.. run particle wax_on ~ ~1.1 ~ 1.5 0.7 1.5 0 12
execute if score @s ec.fx_vis matches 2.. run particle enchant ~ ~1.5 ~ 1.2 0.6 1.2 0.1 12

# ── CRACKED (3..) ── a sand→gold bloom that hangs in the stopped moment + a gold flash.
execute if score @s ec.fx_vis matches 3.. run particle flash{color:[1.0,0.85,0.35,1.0]} ~ ~1 ~
execute if score @s ec.fx_vis matches 3.. run particle dust_color_transition{from_color:[0.85,0.7,0.35],scale:1.7,to_color:[1.0,0.9,0.3]} ~ ~1.1 ~ 2.6 0.9 2.6 0 36
