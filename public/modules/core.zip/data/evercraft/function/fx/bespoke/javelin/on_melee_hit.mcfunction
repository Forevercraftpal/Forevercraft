# === FX · BESPOKE — JAVELIN "Valor's Reach" — melee spear-thrust gleam (ornate+) ===
# Run AS the player, ANCHORED EYES (caller: artifacts/javelin/on_melee_hit, for #fx_tier 4..). One-shot on a melee
# spear strike. A clean bronze-gold thrust: a short, straight gleam-line punched FORWARD in look-space (the spearpoint
# driving in) — disciplined and direct, the close-range sibling of the thrown comet. Tier (4/5/6) sharpens; gated.
# (One of four related Valor signatures — this is the up-close thrust.)

# ── SOUND ── a crisp bronze thrust-note (lower & shorter than the thrown ring); Full adds a clean edge. Cracked = a tap-chime.
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.5 1.122
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:entity.player.attack.sweep master @s ~ ~ ~ 0.3 1.3
execute if score @s ec.fx_snd matches 3.. run playsound minecraft:block.amethyst_block.hit master @s ~ ~ ~ 0.4 1.5

# ── VISUAL · REDUCED (1) ── a single gold thrust mote.
execute if score @s ec.fx_vis matches 1 positioned ^0 ^0 ^1.1 run particle dust{color:[0.95,0.72,0.28],scale:0.8} ~ ~ ~ 0.05 0.05 0.05 0 3

# ── VISUAL · FULL & up (2..) ── a straight forward thrust-line (short, punchy bronze-gold) + a crit at the point.
execute if score @s ec.fx_vis matches 2.. positioned ^0 ^0 ^1.0 run particle dust{color:[0.8,0.58,0.2],scale:0.75} ~ ~ ~ 0 0 0 0 2
execute if score @s ec.fx_vis matches 2.. positioned ^0 ^0 ^1.25 run particle dust{color:[0.95,0.72,0.28],scale:0.85} ~ ~ ~ 0 0 0 0 2
execute if score @s ec.fx_vis matches 2.. positioned ^0 ^0 ^1.5 run particle dust{color:[1.0,0.8,0.35],scale:0.9} ~ ~ ~ 0 0 0 0 2
execute if score @s ec.fx_vis matches 2.. positioned ^0 ^0 ^1.5 run particle crit ~ ~ ~ 0.12 0.12 0.12 0.2 4

# ── EXQUISITE (5..) ── a bright spearpoint glint past the thrust.
execute if score @s ec.fx_vis matches 2.. if score #fx_tier ec.var matches 5.. positioned ^0 ^0 ^1.7 run particle end_rod ~ ~ ~ 0.04 0.04 0.04 0.02 3

# ── MYTHICAL (6) ── a gilded thrust-flare — a wider bronze burst at the point of impact.
execute if score @s ec.fx_vis matches 2.. if score #fx_tier ec.var matches 6 positioned ^0 ^0 ^1.5 run particle dust{color:[1.0,0.8,0.35],scale:1.0} ~ ~ ~ 0.18 0.18 0.18 0 8

# ── CRACKED (3..) ── a gold thrust-bloom at the spearpoint.
execute if score @s ec.fx_vis matches 3.. positioned ^0 ^0 ^1.5 run particle dust_color_transition{from_color:[0.95,0.72,0.28],scale:1.3,to_color:[1.0,0.92,0.5]} ~ ~ ~ 0.18 0.18 0.18 0.05 12
