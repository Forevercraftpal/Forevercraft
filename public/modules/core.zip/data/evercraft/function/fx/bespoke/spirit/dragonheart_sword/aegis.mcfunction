# === FX · BESPOKE — SPIRIT "Dragonheart Sword" · Dragon's Aegis (ability1) ===
# Run AS+AT the player (caller: spirit/abilities/dragonheart_sword/ability1 tail). The wyrm wakes: a ring
# of red-gold dragonfire erupts, breath curls skyward, embers rain — over a deep draconic roar (INTIMIDATION
# CARVE-OUT: dragon-growl allowed for this draconic weapon). Channel-gated; one-shot per cast.

# ── SOUND ── a draconic toll, Cracked wakes the dragon-growl (carve-out).
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.didgeridoo master @s ~ ~ ~ 0.7 0.45
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.5 0.794
execute if score @s ec.fx_snd matches 3.. run playsound minecraft:entity.ender_dragon.growl master @s ~ ~ ~ 0.5 0.9

# ── VISUAL · REDUCED (1) ── a small fire ring + a gold glint.
execute if score @s ec.fx_vis matches 1 run particle flame ~ ~0.3 ~ 1.5 0.2 1.5 0.02 16
execute if score @s ec.fx_vis matches 1 run particle dust{color:[1.0,0.7,0.2],scale:0.8} ~ ~0.4 ~ 1.5 0.2 1.5 0 8

# ── VISUAL · FULL & up (2..) ── the dragonfire ring + a rising breath column + red-gold embers.
execute if score @s ec.fx_vis matches 2.. run particle flame ~ ~0.3 ~ 3.0 0.2 3.0 0.03 40
execute if score @s ec.fx_vis matches 2.. run particle dragon_breath ~ ~1 ~ 0.6 0.8 0.6 0.02 16
execute if score @s ec.fx_vis matches 2.. run particle dust{color:[1.0,0.5,0.1],scale:1.1} ~ ~0.4 ~ 3.0 0.3 3.0 0 26
execute if score @s ec.fx_vis matches 2.. run particle dust{color:[1.0,0.8,0.25],scale:0.8} ~ ~1.2 ~ 1.2 0.9 1.2 0 16
execute if score @s ec.fx_vis matches 2.. run particle lava ~ ~0.5 ~ 1.2 0.3 1.2 0.08 10

# ── CRACKED (3..) ── a red-gold flash-bloom + a gout of dragon-breath rising.
execute if score @s ec.fx_vis matches 3.. run particle flash{color:[1.0,0.55,0.15,1.0]} ~ ~0.5 ~
execute if score @s ec.fx_vis matches 3.. run particle dust_color_transition{from_color:[1.0,0.45,0.1],scale:1.8,to_color:[1.0,0.85,0.3]} ~ ~0.6 ~ 3.2 0.4 3.2 0.05 36
execute if score @s ec.fx_vis matches 3.. run particle dragon_breath ~ ~1.4 ~ 0.7 1.0 0.7 0.04 14
