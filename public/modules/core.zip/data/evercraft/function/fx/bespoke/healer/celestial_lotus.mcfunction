# === FX · BESPOKE — HEALER "Celestial Lotus" (Exquisite, absorption) ===
# Run AT the player (caller: artifacts/healer/use/lotus tail, for #fx_tier 4..). Celestial light shields —
# pink-gold lotus petals drift up on a soft golden shimmer, a serene protective bloom over a gentle chord.
# #fx_tier is 5 (exquisite) here but kept tier-aware. Channel-gated; one-shot.

# ── SOUND ── a serene chord (chime triad D·F#·A) + a soft amethyst sparkle at Cracked.
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.chime master @s ~ ~ ~ 0.6 0.794
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.chime master @s ~ ~ ~ 0.6 1.0
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.chime master @s ~ ~ ~ 0.6 1.189
execute if score @s ec.fx_snd matches 3.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.5 1.587

# ── VISUAL · REDUCED (1) ── a small pink-gold petal puff.
execute if score @s ec.fx_vis matches 1 run particle dust{color:[1.0,0.75,0.85],scale:1.0} ~ ~1 ~ 0.6 0.8 0.6 0 12

# ── VISUAL · FULL & up (2..) ── drifting pink-gold petals + a golden shimmer + a protective light.
execute if score @s ec.fx_vis matches 2.. run particle cherry_leaves ~ ~1.3 ~ 0.7 1.0 0.7 0 22
execute if score @s ec.fx_vis matches 2.. run particle dust{color:[1.0,0.85,0.5],scale:1.0} ~ ~1.2 ~ 0.8 1.0 0.8 0 26
execute if score @s ec.fx_vis matches 2.. run particle end_rod ~ ~0.5 ~ 0.6 0.9 0.6 0.04 16

# ── EXQUISITE (5..) ── a fuller petal lift + a halo glow.
execute if score @s ec.fx_vis matches 2.. if score #fx_tier ec.var matches 5.. run particle dust{color:[1.0,0.7,0.82],scale:1.2} ~ ~1.6 ~ 0.8 1.0 0.8 0 22

# ── CRACKED (3..) ── a rose-gold flash + a pink→gold petal pillar.
execute if score @s ec.fx_vis matches 3.. run particle flash{color:[1.0,0.8,0.85,1.0]} ~ ~1.2 ~
execute if score @s ec.fx_vis matches 3.. run particle dust_color_transition{from_color:[1.0,0.75,0.85],scale:2.0,to_color:[1.0,0.9,0.55]} ~ ~1.4 ~ 0.7 1.3 0.7 0.05 40
execute if score @s ec.fx_vis matches 3.. run particle cherry_leaves ~ ~1.8 ~ 0.8 1.0 0.8 0 22
