# === FX · BESPOKE — SPIRIT "Firebrand" · Rampage (ability2) ===
# Run AS+AT the player (caller: spirit/abilities/firebrand/ability2 tail). The brand ignites the bearer:
# a pillar of flame roars up the body, embers spiralling, the searing fury unleashed — over a rising fire
# motif (INTIMIDATION CARVE-OUT: ravager-roar allowed at Cracked for this rage weapon). Channel-gated.

# ── SOUND ── a rising fury motif, Cracked adds the roar (carve-out for the rage weapon).
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 0.7 0.5
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.5 0.794
execute if score @s ec.fx_snd matches 3.. run playsound minecraft:entity.ravager.roar master @s ~ ~ ~ 0.5 1.2

# ── VISUAL · REDUCED (1) ── a small flame burst up the body.
execute if score @s ec.fx_vis matches 1 run particle flame ~ ~1 ~ 0.4 0.8 0.4 0.05 14

# ── VISUAL · FULL & up (2..) ── the flame pillar up the body + spiralling embers.
execute if score @s ec.fx_vis matches 2.. run particle flame ~ ~1 ~ 0.5 1.0 0.5 0.08 36
execute if score @s ec.fx_vis matches 2.. run particle dust{color:[1.0,0.42,0.12],scale:1.0} ~ ~1.2 ~ 0.6 1.0 0.6 0 22
execute if score @s ec.fx_vis matches 2.. run particle lava ~ ~0.8 ~ 0.5 0.8 0.5 0.06 8
execute if score @s ec.fx_vis matches 2.. run particle dust{color:[1.0,0.65,0.2],scale:0.7} ~ ~1.6 ~ 0.4 1.0 0.4 0 14

# ── CRACKED (3..) ── an orange flash + a roaring fire column.
execute if score @s ec.fx_vis matches 3.. run particle flash{color:[1.0,0.45,0.1,1.0]} ~ ~1 ~
execute if score @s ec.fx_vis matches 3.. run particle dust_color_transition{from_color:[1.0,0.4,0.1],scale:1.7,to_color:[1.0,0.85,0.3]} ~ ~1.3 ~ 0.6 1.2 0.6 0.05 32
