# === FX · BESPOKE — ARCHER "Stormpiercer" — overcharge impact (ornate+) ===
# Run AS + AT the player (caller: artifacts/archer/overcharge_hit, for #fx_tier 4..). One-shot when the
# overcharged shot lands. Caught lightning: the released storm crackles back along the bow — electric_spark
# arcs + a white flash + a taut high note, like a bowstring snapping the sky open. Electric blue + white.
# Tier (4 ornate · 5 exquisite · 6 mythical) deepens the storm; channel-gated.

# ── SOUND ── a taut high bowstring-snap note (bell at the top of its range); Full adds a crackle shimmer.
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.6 1.782
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.amethyst_block.hit master @s ~ ~ ~ 0.6 1.9
execute if score @s ec.fx_snd matches 3.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.5 2.0

# ── VISUAL · REDUCED (1) ── a couple of electric sparks at the impact.
execute if score @s ec.fx_vis matches 1 run particle electric_spark ~ ~1 ~ 0.3 0.4 0.3 0.4 6

# ── VISUAL · FULL & up (2..) ── a white storm flash + crackling spark spray + an electric-blue charge cloud.
execute if score @s ec.fx_vis matches 2.. run particle electric_spark ~ ~1 ~ 0.4 0.5 0.4 0.6 16
execute if score @s ec.fx_vis matches 2.. run particle dust{color:[0.35,0.65,1.0],scale:0.9} ~ ~1 ~ 0.45 0.5 0.45 0 12
execute if score @s ec.fx_vis matches 2.. run particle dust{color:[0.9,0.95,1.0],scale:0.7} ~ ~1.1 ~ 0.3 0.4 0.3 0 8
execute if score @s ec.fx_vis matches 2.. run particle crit ~ ~1 ~ 0.3 0.4 0.3 0.3 6

# ── EXQUISITE (5..) ── a rising bolt-line of end_rod (the lightning rooted to the sky) + a second high note.
execute if score @s ec.fx_vis matches 2.. if score #fx_tier ec.var matches 5.. run particle end_rod ~ ~0.6 ~ 0.08 0.8 0.08 0.05 10
execute if score @s ec.fx_snd matches 2.. if score #fx_tier ec.var matches 5.. run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.4 2.0

# ── MYTHICAL (6) ── a full thunderhead — a wider spark storm + a charged blue ring at the feet.
execute if score @s ec.fx_vis matches 2.. if score #fx_tier ec.var matches 6 run particle electric_spark ~ ~1 ~ 0.7 0.6 0.7 0.8 18
execute if score @s ec.fx_vis matches 2.. if score #fx_tier ec.var matches 6 run particle dust{color:[0.4,0.7,1.0],scale:1.0} ~ ~0.15 ~ 1.4 0.05 1.4 0 16

# ── CRACKED (3..) ── a brilliant white-blue flash + an electric-blue→white storm pillar.
execute if score @s ec.fx_vis matches 3.. run particle flash{color:[0.7,0.85,1.0,1.0]} ~ ~1 ~
execute if score @s ec.fx_vis matches 3.. run particle dust_color_transition{from_color:[0.3,0.6,1.0],scale:1.7,to_color:[1.0,1.0,1.0]} ~ ~1.2 ~ 0.4 0.8 0.4 0.06 28
