# === FX · COOK EAT FEAST — the shared AoE banquet ===
# Run AS the player, POSITIONED at the player, from buff/apply_feast_{warriors,miners,
# explorers,eternal}. The sanctioned eat-burp + a firework blast + a warm aroma cloud, for
# the celebratory banquet feel. (Quality escalation is fired next tick by fx/cook/eat_quality,
# once ec.ck_quality_mod is reliable; the Cracked layer here is tier-based.)
# Ladder: 0=Off · 1=Reduced · 2=Full · 3=Cracked.

# ── SOUND ── the sanctioned eat-burp (KEEP) + a firework blast + a warm bell on a fine feast.
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.player.burp master @s ~ ~ ~ 0.5 1.2
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.firework_rocket.blast master @s ~ ~ ~ 0.8 1.0
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.5 1.059
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.5 1.335
# Cracked — a second, larger blast caps the banquet. (True-quality escalation: fx/cook/eat_quality.)
execute if score @s ec.fx_snd matches 3.. run playsound minecraft:entity.firework_rocket.large_blast master @s ~ ~ ~ 0.8 1.2

# ── VISUAL · REDUCED ── one small firework pop.
execute if score @s ec.fx_vis matches 1 run particle firework ~ ~1 ~ 0.4 0.3 0.4 0.05 6

# ── VISUAL · FULL ── a firework + a warm aroma cloud over the table.
execute if score @s ec.fx_vis matches 2.. run particle firework ~ ~1 ~ 0.5 0.3 0.5 0.06 10
execute if score @s ec.fx_vis matches 2.. run particle campfire_cosy_smoke ~ ~1 ~ 0.5 0.4 0.5 0.02 12
execute if score @s ec.fx_vis matches 2.. run particle happy_villager ~ ~1.1 ~ 0.5 0.4 0.5 0 8

# ── CRACKED (3..) ── a second, higher firework + a fuller aroma cloud.
execute if score @s ec.fx_vis matches 3.. run particle firework ~ ~1.6 ~ 0.6 0.4 0.6 0.08 16
execute if score @s ec.fx_vis matches 3.. run particle campfire_cosy_smoke ~ ~1.2 ~ 0.6 0.6 0.6 0.03 18
