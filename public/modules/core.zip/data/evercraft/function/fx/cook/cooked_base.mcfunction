# === FX · COOK COOKED BASE — the shared "you cooked a meal" cue ===
# Run AS the player, POSITIONED at the player, from cooking/recipes/cook_dispatch.
# Both Quick-Cook and the Chef's Touch minigame funnel through cook_dispatch; the result
# ladder (result_*) layers ON TOP of this. Deliberately LIGHT — a soft hearth crackle, an
# orb pickup, and a few cosy-smoke motes.
# Ladder: 0=Off · 1=Reduced · 2=Full · 3=Cracked.

# ── SOUND ── a soft campfire crackle + a satisfied orb pickup.
execute if score @s ec.fx_snd matches 1 run playsound minecraft:block.campfire.crackle master @s ~ ~ ~ 0.6 1.0
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.campfire.crackle master @s ~ ~ ~ 0.8 1.0
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:entity.experience_orb.pickup master @s ~ ~ ~ 0.45 1.2

# ── VISUAL ── a few cosy-smoke motes.
execute if score @s ec.fx_vis matches 1 run particle campfire_cosy_smoke ~ ~1 ~ 0.2 0.2 0.2 0.01 2
execute if score @s ec.fx_vis matches 2.. run particle campfire_cosy_smoke ~ ~1 ~ 0.3 0.25 0.3 0.01 3
