# === FX · COOK EAT SPIRIT — the otherworldly spirit-fish meal ===
# Run AS the player, POSITIONED at the player, from buff/apply_spirit_{starscale,eel,voidfin,
# whisker} + apply_nest_astral. The sanctioned eat-burp + an amethyst/beacon resonance + a
# constellation of end_rod/enchant motes. (Quality escalation is fired next tick by
# fx/cook/eat_quality, where ec.ck_quality_mod is reliable.)
# Ladder: 0=Off · 1=Reduced · 2=Full · 3=Cracked.

# ── SOUND ── the sanctioned eat-burp (KEEP) + an amethyst resonance + a beacon swell.
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.player.burp master @s ~ ~ ~ 0.5 1.2
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.amethyst_block.resonate master @s ~ ~ ~ 0.6 1.0
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.beacon.activate master @s ~ ~ ~ 0.7 1.2
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.45 1.587
# A higher amethyst shimmer crowns the spirit-meal at Full.
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.45 2.0

# ── VISUAL · REDUCED ── a few star motes.
execute if score @s ec.fx_vis matches 1 run particle end_rod ~ ~1 ~ 0.3 0.4 0.3 0.01 6

# ── VISUAL · FULL ── a constellation of end_rod + enchant motes.
execute if score @s ec.fx_vis matches 2.. run particle end_rod ~ ~1.1 ~ 0.4 0.5 0.4 0.02 12
execute if score @s ec.fx_vis matches 2.. run particle enchant ~ ~1.4 ~ 0.4 0.5 0.4 0.4 16

# ── CRACKED (3..) ── a brighter constellation.
execute if score @s ec.fx_vis matches 3.. run particle end_rod ~ ~1.4 ~ 0.5 0.7 0.5 0.03 18
execute if score @s ec.fx_vis matches 3.. run particle enchant ~ ~1.8 ~ 0.5 0.6 0.5 0.5 24
