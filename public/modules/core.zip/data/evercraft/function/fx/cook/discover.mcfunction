# === FX · COOK DISCOVER — new-recipe "eureka" ===
# Run AS the player, POSITIONED at the player, from cooking/discovery/mark_slot.
# A bright rising note_block.bell 2-note + a recipe-card sparkle. LIGHT (fires on
# every new recipe). Ladder: 0=Off · 1=Reduced · 2=Full · 3=Cracked.

# ── SOUND ── a bright rising bell pair (the "aha"); Full adds a high amethyst sparkle.
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.5 1.059
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.5 1.335
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.4 1.782
execute if score @s ec.fx_snd matches 3.. run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.4 1.587

# ── VISUAL ── a recipe-card sparkle (happy_villager + enchant motes).
execute if score @s ec.fx_vis matches 1 run particle happy_villager ~ ~1.1 ~ 0.3 0.4 0.3 0 6
execute if score @s ec.fx_vis matches 2.. run particle happy_villager ~ ~1.2 ~ 0.35 0.5 0.35 0 10
execute if score @s ec.fx_vis matches 2.. run particle enchant ~ ~1.3 ~ 0.3 0.5 0.3 0.4 12
execute if score @s ec.fx_vis matches 3.. run particle end_rod ~ ~1.1 ~ 0.3 0.7 0.3 0.05 14
