# === FX · COOK FORGE — the "anvil song" (forge a cooking artifact) ===
# Run AS the player, POSITIONED at the player, from cooking/artifacts/forge/* (21 files:
# catalyst/relic/epicurean × t1-t7). The caller sets #ck_forge_t ec.temp = the t-number
# (1-7) before calling. ONE preset (DRY) — pitch RISES t1(low)→t7(high) on an
# iron_xylophone over a soft anvil body + ember crit/flame sparks.
# Ladder: 0=Off · 1=Reduced · 2=Full · 3=Cracked.

# ── SOUND · REDUCED ── a soft anvil tap (the "strike").
execute if score @s ec.fx_snd matches 1 run playsound minecraft:block.anvil.use master @s ~ ~ ~ 0.4 1.4

# ── SOUND · FULL ── anvil body + an iron_xylophone note that climbs with the tier.
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.anvil.use master @s ~ ~ ~ 0.5 1.4
execute if score @s ec.fx_snd matches 2.. if score #ck_forge_t ec.temp matches 1 run playsound minecraft:block.note_block.iron_xylophone master @s ~ ~ ~ 0.55 0.707
execute if score @s ec.fx_snd matches 2.. if score #ck_forge_t ec.temp matches 2 run playsound minecraft:block.note_block.iron_xylophone master @s ~ ~ ~ 0.55 0.794
execute if score @s ec.fx_snd matches 2.. if score #ck_forge_t ec.temp matches 3 run playsound minecraft:block.note_block.iron_xylophone master @s ~ ~ ~ 0.55 0.891
execute if score @s ec.fx_snd matches 2.. if score #ck_forge_t ec.temp matches 4 run playsound minecraft:block.note_block.iron_xylophone master @s ~ ~ ~ 0.55 1.059
execute if score @s ec.fx_snd matches 2.. if score #ck_forge_t ec.temp matches 5 run playsound minecraft:block.note_block.iron_xylophone master @s ~ ~ ~ 0.55 1.189
execute if score @s ec.fx_snd matches 2.. if score #ck_forge_t ec.temp matches 6 run playsound minecraft:block.note_block.iron_xylophone master @s ~ ~ ~ 0.55 1.335
execute if score @s ec.fx_snd matches 2.. if score #ck_forge_t ec.temp matches 7 run playsound minecraft:block.note_block.iron_xylophone master @s ~ ~ ~ 0.55 1.587
# A high octave doubles the top-tier strikes for a brighter "finished" ring (t5+).
execute if score @s ec.fx_snd matches 2.. if score #ck_forge_t ec.temp matches 5.. run playsound minecraft:block.note_block.iron_xylophone master @s ~ ~ ~ 0.45 2.0

# ── SOUND · CRACKED (3..) ── a bell topper crowns the strike.
execute if score @s ec.fx_snd matches 3.. run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.4 2.0

# ── VISUAL · REDUCED ── a small ember spark.
execute if score @s ec.fx_vis matches 1 run particle crit ~ ~1 ~ 0.25 0.35 0.25 0.04 6

# ── VISUAL · FULL ── ember crit/flame sparks + an orange forge-dust pop that grows with tier.
execute if score @s ec.fx_vis matches 2.. run particle crit ~ ~1 ~ 0.35 0.4 0.35 0.05 14
execute if score @s ec.fx_vis matches 2.. run particle flame ~ ~1 ~ 0.3 0.4 0.3 0.02 10
execute if score @s ec.fx_vis matches 2.. if score #ck_forge_t ec.temp matches 1..3 run particle dust{color:[1.0,0.55,0.2],scale:0.9} ~ ~1.05 ~ 0.3 0.4 0.3 0 12
execute if score @s ec.fx_vis matches 2.. if score #ck_forge_t ec.temp matches 4..6 run particle dust{color:[1.0,0.6,0.25],scale:1.0} ~ ~1.1 ~ 0.35 0.5 0.35 0 18
execute if score @s ec.fx_vis matches 2.. if score #ck_forge_t ec.temp matches 7 run particle dust_color_transition{from_color:[1.0,0.5,0.15],scale:1.1,to_color:[1.0,1.0,0.85]} ~ ~1.1 ~ 0.35 0.55 0.35 0.04 22

# ── CRACKED (3..) ── a warm gold flash + a hotter spark fan + a short ember pillar.
execute if score @s ec.fx_vis matches 3.. run particle flash{color:[1.0,0.7,0.25,1.0]} ~ ~1.2 ~
execute if score @s ec.fx_vis matches 3.. run particle electric_spark ~ ~1.1 ~ 0.35 0.45 0.35 0.08 14
execute if score @s ec.fx_vis matches 3.. run particle dust_color_transition{from_color:[1.0,0.5,0.15],scale:1.6,to_color:[1.0,1.0,0.9]} ~ ~1.4 ~ 0.35 0.9 0.35 0.06 28
