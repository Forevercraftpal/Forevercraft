# === FX · COOK QUEST BEAT — the shared light questline chime ===
# Run AS the player, POSITIONED at the player, from cooking/questline/{start,
# show_completed, on_advance_notify, reward_type/*, book/give}. A LIGHT "progress"
# chime (note_block.bell + amethyst chime) — the connective tissue of the Cook's
# Path. Ladder: 0=Off · 1=Reduced · 2=Full · 3=Cracked.

# ── SOUND ── a soft bell; Full adds a high amethyst sparkle.
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.45 1.059
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.4 1.335
execute if score @s ec.fx_snd matches 3.. run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.35 1.587

# ── VISUAL ── a small warm-amber dust pop + a few enchant motes at Full.
execute if score @s ec.fx_vis matches 1 run particle dust{color:[1.0,0.82,0.4],scale:0.7} ~ ~1 ~ 0.2 0.3 0.2 0 5
execute if score @s ec.fx_vis matches 2.. run particle dust{color:[1.0,0.82,0.4],scale:0.8} ~ ~1.05 ~ 0.25 0.35 0.25 0 8
execute if score @s ec.fx_vis matches 2.. run particle enchant ~ ~1.2 ~ 0.2 0.4 0.2 0.3 6
