# === FX · COOK EAT QUALITY — the true-quality meal flourish (deferred, ordering-safe) ===
# Run AS the player, POSITIONED at the player, from cooking/buff/apply_deferred_quality the tick
# AFTER an eat — by which point BOTH the meal_id eat_* AND the cook_quality eat_cqN advancements
# have fired, so ec.ck_quality_mod is the ACCURATE eaten-meal quality. (The apply-time eat_* presets
# read it too early / racily, so ALL quality escalation lives HERE.) Reads ec.ck_quality_mod 0-3:
#   3 = a bright "exceptional!" bell two-tone + gold sparkle + a small firework (Cracked = bigger)
#   2 = a single bright chime + a few aroma motes
#   0 = a subtle low "well, it was filling" note
#   1 = nothing (the everyday meal needs no topper)
# Ladder: 0=Off · 1=Reduced · 2=Full · 3=Cracked.

# ── QUALITY 3 · MASTERWORK MEAL — the exceptional flourish.
execute if score @s ec.fx_snd matches 1 if score @s ec.ck_quality_mod matches 3 run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.5 1.335
execute if score @s ec.fx_snd matches 2.. if score @s ec.ck_quality_mod matches 3 run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.5 1.335
execute if score @s ec.fx_snd matches 2.. if score @s ec.ck_quality_mod matches 3 run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.45 1.682
execute if score @s ec.fx_snd matches 2.. if score @s ec.ck_quality_mod matches 3 run playsound minecraft:entity.firework_rocket.blast master @s ~ ~ ~ 0.4 1.4
execute if score @s ec.fx_vis matches 1.. if score @s ec.ck_quality_mod matches 3 run particle dust{color:[1.0,0.85,0.3],scale:0.9} ~ ~1.1 ~ 0.25 0.35 0.25 0 8
execute if score @s ec.fx_vis matches 2.. if score @s ec.ck_quality_mod matches 3 run particle happy_villager ~ ~1.2 ~ 0.3 0.4 0.3 0 6
execute if score @s ec.fx_vis matches 3.. if score @s ec.ck_quality_mod matches 3 run particle firework ~ ~1.3 ~ 0.3 0.3 0.3 0.05 10

# ── QUALITY 2 · GOOD MEAL — a single bright chime + aroma.
execute if score @s ec.fx_snd matches 1.. if score @s ec.ck_quality_mod matches 2 run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.4 1.335
execute if score @s ec.fx_vis matches 2.. if score @s ec.ck_quality_mod matches 2 run particle happy_villager ~ ~1.1 ~ 0.25 0.35 0.25 0 4

# ── QUALITY 0 · POOR MEAL — a subtle low "filling, at least" note.
execute if score @s ec.fx_snd matches 1.. if score @s ec.ck_quality_mod matches ..0 run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 0.3 0.595
