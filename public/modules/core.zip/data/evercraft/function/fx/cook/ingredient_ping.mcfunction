# === FX · COOK INGREDIENT PING — a small ingredient-salvage harvest note ===
# Run AS the player, POSITIONED at the player, from cooking/protein/on_kill_* + forage/on_shear_hive.
# A soft "you got an ingredient" harp pluck + a tiny herb-green spark. Light/repeatable
# (modelled on fx/crop/harvest — the lightest preset). Ladder: 0=Off · 1=Reduced · 2=Full · 3=Cracked.

# ── SOUND ── a soft harp pluck (a 2nd higher note at Full).
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.harp master @s ~ ~ ~ 0.35 1.189
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.harp master @s ~ ~ ~ 0.3 1.587

# ── VISUAL ── a tiny herb-green spark.
execute if score @s ec.fx_vis matches 1.. run particle happy_villager ~ ~0.8 ~ 0.2 0.2 0.2 0 2
execute if score @s ec.fx_vis matches 2.. run particle crit ~ ~0.8 ~ 0.2 0.2 0.2 0.01 3
