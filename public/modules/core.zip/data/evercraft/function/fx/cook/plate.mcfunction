# === FX · COOK PLATE — the garnish chime (plating precision) ===
# Run AS the player, POSITIONED at the player, from cooking/minigame/phase3_plate/evaluate.
# Reads #ck_dist ec.temp (distance from the golden zone center):
#   0-3  PERFECT = a bright amethyst garnish triad + gold sparkle + happy aroma
#   4-8  GOOD    = a warm 2-note chime
#   9-15 CLOSE   = a single soft note
#   16+  SLOPPY  = a flat off-pitch note_block.hat "plonk" (REPLACES entity.villager.no)
# Ladder: 0=Off · 1=Reduced · 2=Full · 3=Cracked.

# ── PERFECT (0-3) — a bright amethyst garnish chime (C-E-G) + gold sparkle + aroma motes.
execute if score @s ec.fx_snd matches 1 if score #ck_dist ec.temp matches 0..3 run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.5 1.059
execute if score @s ec.fx_snd matches 2.. if score #ck_dist ec.temp matches 0..3 run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.5 0.707
execute if score @s ec.fx_snd matches 2.. if score #ck_dist ec.temp matches 0..3 run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.5 0.891
execute if score @s ec.fx_snd matches 2.. if score #ck_dist ec.temp matches 0..3 run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.5 1.059
execute if score @s ec.fx_snd matches 3.. if score #ck_dist ec.temp matches 0..3 run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.4 1.414

execute if score @s ec.fx_vis matches 1 if score #ck_dist ec.temp matches 0..3 run particle happy_villager ~ ~0.9 ~ 0.2 0.2 0.2 0 3
execute if score @s ec.fx_vis matches 2.. if score #ck_dist ec.temp matches 0..3 run particle dust{color:[1.0,0.85,0.3],scale:0.9} ~ ~0.95 ~ 0.25 0.3 0.25 0 8
execute if score @s ec.fx_vis matches 2.. if score #ck_dist ec.temp matches 0..3 run particle happy_villager ~ ~0.95 ~ 0.25 0.3 0.25 0 4

# ── GOOD (4-8) — a warm 2-note bell chime.
execute if score @s ec.fx_snd matches 1 if score #ck_dist ec.temp matches 4..8 run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.45 0.891
execute if score @s ec.fx_snd matches 2.. if score #ck_dist ec.temp matches 4..8 run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.5 0.891
execute if score @s ec.fx_snd matches 2.. if score #ck_dist ec.temp matches 4..8 run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.45 1.059

execute if score @s ec.fx_vis matches 1.. if score #ck_dist ec.temp matches 4..8 run particle dust{color:[1.0,0.8,0.4],scale:0.7} ~ ~0.9 ~ 0.2 0.25 0.2 0 5

# ── CLOSE (9-15) — a single soft note.
execute if score @s ec.fx_snd matches 1.. if score #ck_dist ec.temp matches 9..15 run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.4 0.794

execute if score @s ec.fx_vis matches 1.. if score #ck_dist ec.temp matches 9..15 run particle dust{color:[0.85,0.75,0.5],scale:0.6} ~ ~0.9 ~ 0.15 0.2 0.15 0 3

# ── SLOPPY (16+) — a flat off-pitch note_block.hat "plonk" (NO villager.no).
execute if score @s ec.fx_snd matches 1 if score #ck_dist ec.temp matches 16.. run playsound minecraft:block.note_block.hat master @s ~ ~ ~ 0.4 0.595
execute if score @s ec.fx_snd matches 2.. if score #ck_dist ec.temp matches 16.. run playsound minecraft:block.note_block.hat master @s ~ ~ ~ 0.5 0.529

execute if score @s ec.fx_vis matches 1.. if score #ck_dist ec.temp matches 16.. run particle smoke ~ ~0.9 ~ 0.15 0.15 0.15 0.01 3
