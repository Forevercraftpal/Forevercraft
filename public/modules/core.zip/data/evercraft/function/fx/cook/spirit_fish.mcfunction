# === FX · COOK SPIRIT FISH — the rare spirit-catch reveal ===
# Run AS the player, POSITIONED at the player, from cooking/spirit_fish/grant/*.
# A shared constellation reveal (all spirit fish) + a per-fish sound tone read from #ck_sf ec.temp:
#   1 starscale   = a bright star-twinkle amethyst triad
#   2 voidfin     = a void beacon swell + a low toll
#   3 deepcurrent = a deep current swell (atmospheric thunder — non-vocal, allowed)
#   4 leviathan   = a deep abyssal amethyst toll (REPLACES entity.elder_guardian.curse)
# Ladder: 0=Off · 1=Reduced · 2=Full · 3=Cracked.

# ── SHARED VISUAL ── the rare-catch constellation (all fish).
execute if score @s ec.fx_vis matches 1 run particle end_rod ~ ~1 ~ 0.3 0.4 0.3 0.01 8
execute if score @s ec.fx_vis matches 2.. run particle end_rod ~ ~1.1 ~ 0.4 0.5 0.4 0.02 16
execute if score @s ec.fx_vis matches 2.. run particle enchant ~ ~1.5 ~ 0.4 0.5 0.4 0.5 20
execute if score @s ec.fx_vis matches 2.. run particle dust{color:[0.5,0.8,1.0],scale:1.0} ~ ~1.1 ~ 0.35 0.45 0.35 0 10
# Cracked topper · a brighter star burst + a soft blue flash.
execute if score @s ec.fx_vis matches 3.. run particle end_rod ~ ~1.4 ~ 0.5 0.7 0.5 0.04 22
execute if score @s ec.fx_vis matches 3.. run particle flash{color:[0.6,0.85,1.0,1.0]} ~ ~1.2 ~

# ── PER-FISH SOUND TONE (reads #ck_sf ec.temp) ──
# 1 · STARSCALE — a bright star-twinkle amethyst triad.
execute if score @s ec.fx_snd matches 1 if score #ck_sf ec.temp matches 1 run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.6 1.587
execute if score @s ec.fx_snd matches 2.. if score #ck_sf ec.temp matches 1 run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.5 1.189
execute if score @s ec.fx_snd matches 2.. if score #ck_sf ec.temp matches 1 run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.5 2.0
# 2 · VOIDFIN — a void beacon swell + a low toll.
execute if score @s ec.fx_snd matches 1.. if score #ck_sf ec.temp matches 2 run playsound minecraft:block.beacon.activate master @s ~ ~ ~ 0.5 0.7
execute if score @s ec.fx_snd matches 2.. if score #ck_sf ec.temp matches 2 run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 0.5 0.595
# 3 · DEEPCURRENT — a deep current swell (atmospheric, non-vocal).
execute if score @s ec.fx_snd matches 1.. if score #ck_sf ec.temp matches 3 run playsound minecraft:entity.lightning_bolt.thunder master @s ~ ~ ~ 0.35 1.8
execute if score @s ec.fx_snd matches 2.. if score #ck_sf ec.temp matches 3 run playsound minecraft:block.amethyst_block.resonate master @s ~ ~ ~ 0.5 0.9
# 4 · LEVIATHAN — a deep abyssal amethyst toll (REPLACES entity.elder_guardian.curse).
execute if score @s ec.fx_snd matches 1.. if score #ck_sf ec.temp matches 4 run playsound minecraft:block.amethyst_block.resonate master @s ~ ~ ~ 0.7 0.5
execute if score @s ec.fx_snd matches 2.. if score #ck_sf ec.temp matches 4 run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 0.6 0.5
execute if score @s ec.fx_snd matches 3.. if score #ck_sf ec.temp matches 4 run playsound minecraft:block.amethyst_block.resonate master @s ~ ~ ~ 0.6 0.749
