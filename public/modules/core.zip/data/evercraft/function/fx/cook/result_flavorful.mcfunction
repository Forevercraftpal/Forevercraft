# === FX · COOK RESULT: FLAVORFUL — a fine dish ===
# Run AS the player, POSITIONED at the player, from cooking/minigame/result_flavorful.
# A culinary triad chord (note_block.bell C-E-G) + a green happy_villager aroma. The chord
# blooms one rung short of masterwork.
# Ladder: 0=Off · 1=Reduced · 2=Full · 3=Cracked.

# ── SOUND ── a bright bell triad (C-E-G).
execute if score @s ec.fx_snd matches 1 run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.5 0.707
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.55 0.707
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.55 0.891
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.5 1.059
execute if score @s ec.fx_snd matches 3.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.4 1.414

# ── VISUAL ── a green aroma + a warm dust pop.
execute if score @s ec.fx_vis matches 1 run particle happy_villager ~ ~1 ~ 0.25 0.3 0.25 0 4
execute if score @s ec.fx_vis matches 2.. run particle happy_villager ~ ~1 ~ 0.3 0.4 0.3 0 7
execute if score @s ec.fx_vis matches 2.. run particle dust{color:[0.6,0.9,0.4],scale:0.8} ~ ~1 ~ 0.3 0.35 0.3 0 8
