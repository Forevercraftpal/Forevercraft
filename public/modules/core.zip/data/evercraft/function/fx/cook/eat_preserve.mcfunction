# === FX · COOK EAT PRESERVE — the death-defying preserved meal ===
# Run AS the player, POSITIONED at the player, from buff/apply_preserve_{deathless,ironbark,
# jerky}. The sanctioned eat-burp + a low iron "fortify" tone + a few crit sparks — the body
# bracing for what's coming. (Quality escalation is fired next tick by fx/cook/eat_quality,
# where ec.ck_quality_mod is reliable.)
# Ladder: 0=Off · 1=Reduced · 2=Full · 3=Cracked.

# ── SOUND ── the sanctioned eat-burp (KEEP) + a soft anvil "fortify" + a low bass body.
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.player.burp master @s ~ ~ ~ 0.5 1.2
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.anvil.use master @s ~ ~ ~ 0.3 1.5
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 0.5 0.707
# A firmer, higher iron tone caps the preserve at Full.
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 0.5 0.891

# ── VISUAL · REDUCED ── a couple of crit sparks.
execute if score @s ec.fx_vis matches 1 run particle crit ~ ~1 ~ 0.3 0.3 0.3 0.1 4

# ── VISUAL · FULL ── a small shower of crit sparks bracing the body.
execute if score @s ec.fx_vis matches 2.. run particle crit ~ ~1 ~ 0.4 0.4 0.4 0.15 8
execute if score @s ec.fx_vis matches 2.. run particle enchanted_hit ~ ~1 ~ 0.3 0.3 0.3 0.05 4

# ── CRACKED (3..) ── a brighter spark burst.
execute if score @s ec.fx_vis matches 3.. run particle crit ~ ~1.2 ~ 0.5 0.5 0.5 0.2 12
