# === FX · COOK PHASE ADVANCE — the "ready" bell between phases ===
# Run AS the player, POSITIONED at the player, from cooking/minigame/begin + each
# phase*/start + phase*/complete + phase2_simmer/evaluate.
# A shared phase start/complete bell, pitch RISING with meal tier (ec.ck_tier 1-4).
# Ladder: 0=Off · 1=Reduced · 2=Full · 3=Cracked.

# ── SOUND ── a "ready" bell whose pitch climbs with meal tier (t1 D · t2 E · t3 G · t4 B).
execute if score @s ec.fx_snd matches 1.. if score @s ec.ck_tier matches 1 run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.45 0.794
execute if score @s ec.fx_snd matches 1.. if score @s ec.ck_tier matches 2 run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.45 0.891
execute if score @s ec.fx_snd matches 1.. if score @s ec.ck_tier matches 3 run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.45 1.059
execute if score @s ec.fx_snd matches 1.. if score @s ec.ck_tier matches 4 run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.45 1.335
# Full+ adds a soft pling octave for body.
execute if score @s ec.fx_snd matches 2.. if score @s ec.ck_tier matches 1 run playsound minecraft:block.note_block.pling master @s ~ ~ ~ 0.35 1.587
execute if score @s ec.fx_snd matches 2.. if score @s ec.ck_tier matches 2 run playsound minecraft:block.note_block.pling master @s ~ ~ ~ 0.35 1.782
execute if score @s ec.fx_snd matches 2.. if score @s ec.ck_tier matches 3 run playsound minecraft:block.note_block.pling master @s ~ ~ ~ 0.35 2.0
execute if score @s ec.fx_snd matches 2.. if score @s ec.ck_tier matches 4 run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.35 2.0

# ── VISUAL ── a brief warm-amber dust pop, a touch bigger for higher tiers.
execute if score @s ec.fx_vis matches 1 run particle dust{color:[1.0,0.82,0.4],scale:0.7} ~ ~0.9 ~ 0.2 0.25 0.2 0 4
execute if score @s ec.fx_vis matches 2.. run particle dust{color:[1.0,0.82,0.4],scale:0.8} ~ ~0.95 ~ 0.25 0.3 0.25 0 7
execute if score @s ec.fx_vis matches 2.. run particle enchant ~ ~1.1 ~ 0.2 0.3 0.2 0.3 6
