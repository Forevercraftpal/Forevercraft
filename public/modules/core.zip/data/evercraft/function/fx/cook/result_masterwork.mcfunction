# === FX · COOK RESULT: MASTERWORK — the showcase dish ===
# Run AS the player, POSITIONED at the player, from cooking/minigame/result_masterwork.
# The culinary chord at full bloom: a bell triad + body, an aroma-steam pillar, one firework,
# a warm gold flash, and an end_rod rise. Cracked (3..) = a taller pillar + a second firework.
# Modeled on fx/gather/win. Ladder: 0=Off · 1=Reduced · 2=Full · 3=Cracked.

# ── SOUND ── a full bell triad + low bass body + a high amethyst shimmer.
execute if score @s ec.fx_snd matches 1 run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.55 0.707
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.6 0.707
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.6 0.891
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.6 1.059
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.55 1.414
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 0.6 0.707
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.5 1.587
execute if score @s ec.fx_snd matches 3.. run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 0.7 0.595
execute if score @s ec.fx_snd matches 3.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.5 2.0

# ── VISUAL · REDUCED ── one warm aroma column.
execute if score @s ec.fx_vis matches 1 run particle campfire_cosy_smoke ~ ~1 ~ 0.2 0.6 0.2 0.02 12

# ── VISUAL · FULL ── a gold flash + an aroma-steam pillar + a firework + an end_rod rise.
execute if score @s ec.fx_vis matches 2.. run particle flash{color:[1.0,0.85,0.4,1.0]} ~ ~1.2 ~
execute if score @s ec.fx_vis matches 2.. run particle campfire_cosy_smoke ~ ~1 ~ 0.3 1.0 0.3 0.03 28
execute if score @s ec.fx_vis matches 2.. run particle happy_villager ~ ~1.1 ~ 0.35 0.5 0.35 0 10
execute if score @s ec.fx_vis matches 2.. run particle end_rod ~ ~1 ~ 0.3 1.0 0.3 0.06 24
execute if score @s ec.fx_vis matches 2.. run particle firework ~ ~1.4 ~ 0.4 0.6 0.4 0.06 16
execute if score @s ec.fx_vis matches 2.. run particle dust{color:[1.0,0.82,0.4],scale:1.0} ~ ~1.1 ~ 0.35 0.5 0.35 0 14

# ── CRACKED (3..) ── a second flash, a taller aroma pillar, an extra firework, a higher rod column.
execute if score @s ec.fx_vis matches 3.. run particle flash{color:[1.0,0.92,0.6,1.0]} ~ ~2 ~
execute if score @s ec.fx_vis matches 3.. run particle campfire_cosy_smoke ~ ~1.4 ~ 0.4 1.8 0.4 0.04 40
execute if score @s ec.fx_vis matches 3.. run particle firework ~ ~2 ~ 0.5 0.8 0.5 0.08 24
execute if score @s ec.fx_vis matches 3.. run particle end_rod ~ ~1.5 ~ 0.35 1.6 0.35 0.08 36
execute if score @s ec.fx_vis matches 3.. run particle dust_color_transition{from_color:[1.0,0.78,0.25],scale:1.6,to_color:[1.0,1.0,0.85]} ~ ~1.6 ~ 0.4 1.0 0.4 0.06 30
