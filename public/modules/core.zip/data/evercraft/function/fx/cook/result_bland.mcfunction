# === FX · COOK RESULT: BLAND — an unremarkable meal ===
# Run AS the player, POSITIONED at the player, from cooking/minigame/result_bland.
# A plain single harp note + a thin wisp of steam. The neutral rung of the ladder.
# Ladder: 0=Off · 1=Reduced · 2=Full · 3=Cracked.

# ── SOUND ── one plain harp note.
execute if score @s ec.fx_snd matches 1 run playsound minecraft:block.note_block.harp master @s ~ ~ ~ 0.45 0.794
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.harp master @s ~ ~ ~ 0.5 0.794

# ── VISUAL ── a thin steam wisp.
execute if score @s ec.fx_vis matches 1 run particle cloud ~ ~1 ~ 0.15 0.2 0.15 0.01 3
execute if score @s ec.fx_vis matches 2.. run particle cloud ~ ~1 ~ 0.2 0.3 0.2 0.01 5
