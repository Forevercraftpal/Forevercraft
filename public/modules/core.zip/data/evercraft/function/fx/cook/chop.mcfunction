# === FX · COOK CHOP — a knife-tap on the cutting board ===
# Run AS the player, POSITIONED at the player, from cooking/minigame/phase1_chop/evaluate.
# Reads #ck_hit ec.temp: 1 = clean hit (pitched note-block "thunk" + slice sparks),
# 0 = miss (dull off-pitch note_block.hat knock + a wisp of smoke). LIGHT — repeats per chop.
# Ladder: 0=Off · 1=Reduced · 2=Full · 3=Cracked.

# ── HIT (clean chop) — a pitched basedrum/bass "thunk" on-beat + a small slice spark.
execute if score @s ec.fx_snd matches 1 if score #ck_hit ec.temp matches 1 run playsound minecraft:block.note_block.basedrum master @s ~ ~ ~ 0.5 0.794
execute if score @s ec.fx_snd matches 2.. if score #ck_hit ec.temp matches 1 run playsound minecraft:block.note_block.basedrum master @s ~ ~ ~ 0.6 0.794
execute if score @s ec.fx_snd matches 2.. if score #ck_hit ec.temp matches 1 run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 0.45 1.059
execute if score @s ec.fx_snd matches 3.. if score #ck_hit ec.temp matches 1 run playsound minecraft:block.note_block.hat master @s ~ ~ ~ 0.3 1.587

execute if score @s ec.fx_vis matches 1 if score #ck_hit ec.temp matches 1 run particle crit ~ ~0.9 ~ 0.2 0.2 0.2 0.1 4
execute if score @s ec.fx_vis matches 2.. if score #ck_hit ec.temp matches 1 run particle crit ~ ~0.9 ~ 0.25 0.25 0.25 0.12 6
execute if score @s ec.fx_vis matches 2.. if score #ck_hit ec.temp matches 1 run particle sweep_attack ~ ~0.9 ~ 0.15 0.15 0.15 0 1

# ── MISS — a dull, off-pitch hat knock + 2 smoke.
execute if score @s ec.fx_snd matches 1 if score #ck_hit ec.temp matches 0 run playsound minecraft:block.note_block.hat master @s ~ ~ ~ 0.4 0.595
execute if score @s ec.fx_snd matches 2.. if score #ck_hit ec.temp matches 0 run playsound minecraft:block.note_block.hat master @s ~ ~ ~ 0.5 0.529

execute if score @s ec.fx_vis matches 1.. if score #ck_hit ec.temp matches 0 run particle smoke ~ ~0.9 ~ 0.15 0.15 0.15 0.01 2
