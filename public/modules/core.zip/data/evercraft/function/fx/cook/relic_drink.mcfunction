# === FX · COOK RELIC DRINK — the brew shimmer (drink a cooking relic) ===
# Run AS the player, POSITIONED at the player, from cooking/artifacts/on_drink_relic_*
# and on_drink_grace. A brewing-stand shimmer + amethyst chime + a luck/gold aura.
# GRACE VARIANT (mythical Eternal Grace): the caller sets #ck_relic_grace ec.temp 1
# before calling — richer chime + a taller gold dust pillar. ONE preset (DRY).
# Default (#ck_relic_grace 0 or unset) = the standard relic shimmer.
# Ladder: 0=Off · 1=Reduced · 2=Full · 3=Cracked.

# ── SOUND · REDUCED ── one soft brew shimmer.
execute if score @s ec.fx_snd matches 1 run playsound minecraft:block.brewing_stand.brew master @s ~ ~ ~ 0.45 1.2

# ── SOUND · FULL ── the brew + a rising amethyst chime + a luck-bright pling.
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.brewing_stand.brew master @s ~ ~ ~ 0.55 1.2
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.55 1.059
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.5 1.335
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.pling master @s ~ ~ ~ 0.4 1.782
# GRACE adds a richer chime cascade + a deep resonate body.
execute if score @s ec.fx_snd matches 2.. if score #ck_relic_grace ec.temp matches 1 run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.55 1.587
execute if score @s ec.fx_snd matches 2.. if score #ck_relic_grace ec.temp matches 1 run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.5 2.0
execute if score @s ec.fx_snd matches 2.. if score #ck_relic_grace ec.temp matches 1 run playsound minecraft:block.amethyst_block.resonate master @s ~ ~ ~ 0.5 0.8

# ── SOUND · CRACKED (3..) ── a high bell topper (grace = a second amethyst crown).
execute if score @s ec.fx_snd matches 3.. run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.4 2.0
execute if score @s ec.fx_snd matches 3.. if score #ck_relic_grace ec.temp matches 1 run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.45 1.498

# ── VISUAL · REDUCED ── a few gold luck motes.
execute if score @s ec.fx_vis matches 1 run particle happy_villager ~ ~1.1 ~ 0.3 0.5 0.3 0 6

# ── VISUAL · FULL ── a gold luck aura (happy_villager + end_rod) + a warm gold dust shimmer.
execute if score @s ec.fx_vis matches 2.. run particle happy_villager ~ ~1.1 ~ 0.35 0.6 0.35 0 12
execute if score @s ec.fx_vis matches 2.. run particle end_rod ~ ~1 ~ 0.3 0.7 0.3 0.04 14
execute if score @s ec.fx_vis matches 2.. run particle dust{color:[1.0,0.85,0.4],scale:0.95} ~ ~1.1 ~ 0.35 0.6 0.35 0 16
# GRACE = a tall gold dust pillar + a richer aura.
execute if score @s ec.fx_vis matches 2.. if score #ck_relic_grace ec.temp matches 1 run particle dust{color:[1.0,0.82,0.3],scale:1.0} ~ ~1.4 ~ 0.3 1.1 0.3 0 30
execute if score @s ec.fx_vis matches 2.. if score #ck_relic_grace ec.temp matches 1 run particle happy_villager ~ ~1.4 ~ 0.3 0.9 0.3 0 14
execute if score @s ec.fx_vis matches 2.. if score #ck_relic_grace ec.temp matches 1 run particle end_rod ~ ~1.2 ~ 0.3 1.0 0.3 0.05 20

# ── CRACKED (3..) ── a warm gold flash + a taller pillar (grace also fires a firework crown).
execute if score @s ec.fx_vis matches 3.. run particle flash{color:[1.0,0.85,0.4,1.0]} ~ ~1.3 ~
execute if score @s ec.fx_vis matches 3.. run particle dust_color_transition{from_color:[1.0,0.78,0.25],scale:1.6,to_color:[1.0,1.0,0.85]} ~ ~1.5 ~ 0.35 1.0 0.35 0.06 28
execute if score @s ec.fx_vis matches 3.. if score #ck_relic_grace ec.temp matches 1 run particle firework ~ ~1.6 ~ 0.4 0.7 0.4 0.06 18
