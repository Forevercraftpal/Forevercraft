# === FX · COOK EAT BASIC — the everyday satisfied meal ===
# Run AS the player, POSITIONED at the player (callers do `execute at @s run function …`),
# from every burp-only buff/apply_* (hearty/gourmet/spiced/ration/mining/fortune/wayfarer/
# delicacy/combat/nest_ember/nest_tidal + all _b variants).
# The sanctioned eat-burp + one satisfied harp note + a couple aroma motes. (The quality
# escalation is fired one tick later by fx/cook/eat_quality, where the score is reliable.)
# Ladder: 0=Off · 1=Reduced · 2=Full · 3=Cracked.

# ── SOUND ── the sanctioned eat-burp (KEEP), then a satisfied harp note pitched by quality.
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.player.burp master @s ~ ~ ~ 0.5 1.2
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.harp master @s ~ ~ ~ 0.5 0.891
# Full adds a soft, higher second note — a little "mmm" two-tone. (True-quality escalation lives
# in fx/cook/eat_quality, fired next tick once ec.ck_quality_mod is accurate.)
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.harp master @s ~ ~ ~ 0.45 1.335

# ── VISUAL ── a couple of warm aroma motes rising off the plate.
execute if score @s ec.fx_vis matches 1 run particle happy_villager ~ ~1 ~ 0.2 0.3 0.2 0 2
execute if score @s ec.fx_vis matches 2.. run particle happy_villager ~ ~1.1 ~ 0.25 0.4 0.25 0 3
