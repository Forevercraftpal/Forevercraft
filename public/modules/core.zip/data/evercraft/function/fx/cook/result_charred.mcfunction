# === FX · COOK RESULT: CHARRED — the bottom of the culinary ladder ===
# Run AS the player, POSITIONED at the player, from cooking/minigame/result_charred.
# A lone flat DESCENDING note_block.bass note over a black smoke puff. NO clang, no mob vocal
# (REPLACES entity.villager.no). The opposite pole of masterwork's blooming chord.
# Ladder: 0=Off · 1=Reduced · 2=Full · 3=Cracked.

# ── SOUND ── a single bass note, then a lower one — a sinking "it's ruined" fall.
execute if score @s ec.fx_snd matches 1 run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 0.6 0.595
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 0.7 0.595
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 0.6 0.5

# ── VISUAL ── a puff of black smoke rising.
execute if score @s ec.fx_vis matches 1 run particle large_smoke ~ ~1 ~ 0.2 0.25 0.2 0.02 4
execute if score @s ec.fx_vis matches 2.. run particle large_smoke ~ ~1 ~ 0.3 0.35 0.3 0.03 8
