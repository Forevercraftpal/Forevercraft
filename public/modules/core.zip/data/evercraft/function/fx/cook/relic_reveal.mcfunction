# === FX · COOK RELIC REVEAL — "a culinary relic manifests" ===
# Run AS the player, POSITIONED at the player, from cooking/artifacts/roll_artifact
# AFTER the dish result chord. Reads #art_rarity ec.cf_temp (0=common .. 5=mythical).
# A DISTINCT SECOND beat: a BELL-ARPEGGIO rising with rarity (musically apart from the
# dish chord, so the dish-then-relic reads as two beats, never a doubled burst) + a
# rarity-colored dust burst (white→green→aqua→purple→magenta→gold) + a firework at 5.
# Ladder: 0=Off · 1=Reduced · 2=Full · 3=Cracked.

# ── SOUND · REDUCED ── one bell tap whose pitch climbs with rarity (the "relic chimes in").
execute if score @s ec.fx_snd matches 1.. if score #art_rarity ec.cf_temp matches 0 run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.5 0.707
execute if score @s ec.fx_snd matches 1.. if score #art_rarity ec.cf_temp matches 1 run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.5 0.794
execute if score @s ec.fx_snd matches 1.. if score #art_rarity ec.cf_temp matches 2 run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.5 0.891
execute if score @s ec.fx_snd matches 1.. if score #art_rarity ec.cf_temp matches 3 run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.5 1.059
execute if score @s ec.fx_snd matches 1.. if score #art_rarity ec.cf_temp matches 4 run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.5 1.189
execute if score @s ec.fx_snd matches 1.. if score #art_rarity ec.cf_temp matches 5 run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.5 1.335

# ── SOUND · FULL ── a rising 3-bell arpeggio that climbs HIGHER the rarer the relic.
# common/uncommon: A-C-E · rare/exquisite: C-E-G · ornate/mythical: E-G-B (the arpeggio "tops out").
execute if score @s ec.fx_snd matches 2.. if score #art_rarity ec.cf_temp matches 0..1 run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.55 0.595
execute if score @s ec.fx_snd matches 2.. if score #art_rarity ec.cf_temp matches 0..1 run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.55 0.707
execute if score @s ec.fx_snd matches 2.. if score #art_rarity ec.cf_temp matches 0..1 run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.55 0.891
execute if score @s ec.fx_snd matches 2.. if score #art_rarity ec.cf_temp matches 2..3 run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.55 0.707
execute if score @s ec.fx_snd matches 2.. if score #art_rarity ec.cf_temp matches 2..3 run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.55 0.891
execute if score @s ec.fx_snd matches 2.. if score #art_rarity ec.cf_temp matches 2..3 run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.55 1.059
execute if score @s ec.fx_snd matches 2.. if score #art_rarity ec.cf_temp matches 4..5 run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.55 0.891
execute if score @s ec.fx_snd matches 2.. if score #art_rarity ec.cf_temp matches 4..5 run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.55 1.059
execute if score @s ec.fx_snd matches 2.. if score #art_rarity ec.cf_temp matches 4..5 run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.55 1.335
# A high amethyst shimmer crowns the higher rarities (rare+).
execute if score @s ec.fx_snd matches 2.. if score #art_rarity ec.cf_temp matches 2.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.45 1.782
# Mythical earns a deep resonate body under the arpeggio.
execute if score @s ec.fx_snd matches 2.. if score #art_rarity ec.cf_temp matches 5 run playsound minecraft:block.amethyst_block.resonate master @s ~ ~ ~ 0.5 0.7

# ── SOUND · CRACKED (3..) ── a top-octave bell + chime topper, scaled to rarity.
execute if score @s ec.fx_snd matches 3.. run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.4 2.0
execute if score @s ec.fx_snd matches 3.. if score #art_rarity ec.cf_temp matches 4.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.4 2.0

# ── VISUAL · REDUCED ── one rarity-colored dust pop.
execute if score @s ec.fx_vis matches 1.. if score #art_rarity ec.cf_temp matches 0 run particle dust{color:[0.95,0.95,0.95],scale:0.9} ~ ~1.1 ~ 0.3 0.4 0.3 0 8
execute if score @s ec.fx_vis matches 1.. if score #art_rarity ec.cf_temp matches 1 run particle dust{color:[0.45,0.9,0.45],scale:0.9} ~ ~1.1 ~ 0.3 0.4 0.3 0 8
execute if score @s ec.fx_vis matches 1.. if score #art_rarity ec.cf_temp matches 2 run particle dust{color:[0.35,0.85,0.95],scale:0.9} ~ ~1.1 ~ 0.3 0.4 0.3 0 8
execute if score @s ec.fx_vis matches 1.. if score #art_rarity ec.cf_temp matches 3 run particle dust{color:[0.75,0.45,0.95],scale:0.9} ~ ~1.1 ~ 0.3 0.4 0.3 0 8
execute if score @s ec.fx_vis matches 1.. if score #art_rarity ec.cf_temp matches 4 run particle dust{color:[0.95,0.4,0.9],scale:0.9} ~ ~1.1 ~ 0.3 0.4 0.3 0 8
execute if score @s ec.fx_vis matches 1.. if score #art_rarity ec.cf_temp matches 5 run particle dust{color:[1.0,0.82,0.3],scale:1.0} ~ ~1.1 ~ 0.3 0.4 0.3 0 8

# ── VISUAL · FULL ── a fuller rarity-colored dust column + an end_rod rise; enchant motes orbit.
execute if score @s ec.fx_vis matches 2.. if score #art_rarity ec.cf_temp matches 0 run particle dust{color:[0.95,0.95,0.95],scale:1.0} ~ ~1.2 ~ 0.35 0.7 0.35 0 22
execute if score @s ec.fx_vis matches 2.. if score #art_rarity ec.cf_temp matches 1 run particle dust{color:[0.45,0.9,0.45],scale:1.0} ~ ~1.2 ~ 0.35 0.7 0.35 0 22
execute if score @s ec.fx_vis matches 2.. if score #art_rarity ec.cf_temp matches 2 run particle dust{color:[0.35,0.85,0.95],scale:1.0} ~ ~1.2 ~ 0.35 0.7 0.35 0 22
execute if score @s ec.fx_vis matches 2.. if score #art_rarity ec.cf_temp matches 3 run particle dust{color:[0.75,0.45,0.95],scale:1.0} ~ ~1.2 ~ 0.35 0.7 0.35 0 22
execute if score @s ec.fx_vis matches 2.. if score #art_rarity ec.cf_temp matches 4 run particle dust{color:[0.95,0.4,0.9],scale:1.0} ~ ~1.2 ~ 0.35 0.7 0.35 0 22
execute if score @s ec.fx_vis matches 2.. if score #art_rarity ec.cf_temp matches 5 run particle dust{color:[1.0,0.82,0.3],scale:1.1} ~ ~1.2 ~ 0.35 0.7 0.35 0 26
execute if score @s ec.fx_vis matches 2.. run particle end_rod ~ ~1 ~ 0.3 0.9 0.3 0.05 18
execute if score @s ec.fx_vis matches 2.. run particle enchant ~ ~1.3 ~ 0.3 0.5 0.3 0.4 12
# A firework crowns a MYTHICAL relic (rarity 5).
execute if score @s ec.fx_vis matches 2.. if score #art_rarity ec.cf_temp matches 5 run particle firework ~ ~1.4 ~ 0.4 0.6 0.4 0.06 16

# ── CRACKED (3..) ── a rarity-tinted flash + a taller rod column + a firework crown.
execute if score @s ec.fx_vis matches 3.. if score #art_rarity ec.cf_temp matches 0..2 run particle flash{color:[0.85,0.95,1.0,1.0]} ~ ~1.4 ~
execute if score @s ec.fx_vis matches 3.. if score #art_rarity ec.cf_temp matches 3..4 run particle flash{color:[0.9,0.55,1.0,1.0]} ~ ~1.4 ~
execute if score @s ec.fx_vis matches 3.. if score #art_rarity ec.cf_temp matches 5 run particle flash{color:[1.0,0.85,0.4,1.0]} ~ ~1.4 ~
execute if score @s ec.fx_vis matches 3.. run particle firework ~ ~1.6 ~ 0.45 0.7 0.45 0.07 20
execute if score @s ec.fx_vis matches 3.. run particle end_rod ~ ~1.4 ~ 0.35 1.5 0.35 0.08 32
