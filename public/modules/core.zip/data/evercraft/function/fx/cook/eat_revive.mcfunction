# === FX · COOK EAT REVIVE — "your meal endures beyond death" ===
# Run AS the player, POSITIONED at the player, from buff/restore_preserved — the moment a
# preserved meal carries the player back through death (confirmed alive on respawn).
# NO burp (the meal was already eaten; this is its echo). An amethyst shimmer + a soft chord
# that says the meal endured. Not quality-scaled (the preserve charge is what matters here).
# Ladder: 0=Off · 1=Reduced · 2=Full · 3=Cracked.

# ── SOUND ── a soft amethyst chime + a low bell — a "you endure" chord.
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.55 1.0
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.5 0.707
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.5 1.335
# Cracked topper — a high amethyst shimmer crowns the survival.
execute if score @s ec.fx_snd matches 3.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.5 2.0

# ── VISUAL · REDUCED ── a small amethyst shimmer.
execute if score @s ec.fx_vis matches 1 run particle enchant ~ ~1 ~ 0.3 0.5 0.3 0.3 8

# ── VISUAL · FULL ── an amethyst shimmer rising around the survivor.
execute if score @s ec.fx_vis matches 2.. run particle enchant ~ ~1.2 ~ 0.4 0.6 0.4 0.4 16
execute if score @s ec.fx_vis matches 2.. run particle end_rod ~ ~1 ~ 0.3 0.5 0.3 0.02 10

# ── CRACKED (3..) ── a brighter, taller shimmer.
execute if score @s ec.fx_vis matches 3.. run particle enchant ~ ~1.6 ~ 0.5 0.8 0.5 0.5 24
execute if score @s ec.fx_vis matches 3.. run particle end_rod ~ ~1.4 ~ 0.4 0.8 0.4 0.03 16
