# === FX · COOK SIMMER COOL — a splash of water (cool down) ===
# Run AS the player, POSITIONED at the player, from cooking/minigame/phase2_simmer/do_cool.
# A soft water-hiss + a FALLING flute note + steam (cloud) motes. The call-and-response
# answer to simmer_stoke. LIGHT.
# Ladder: 0=Off · 1=Reduced · 2=Full · 3=Cracked.

# ── SOUND ── a soft splash + a falling flute note (F#→D).
execute if score @s ec.fx_snd matches 1 run playsound minecraft:block.note_block.flute master @s ~ ~ ~ 0.4 1.0
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:entity.generic.splash master @s ~ ~ ~ 0.3 1.5
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.flute master @s ~ ~ ~ 0.45 0.891
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.flute master @s ~ ~ ~ 0.4 0.794

# ── VISUAL ── a small steam (cloud) puff.
execute if score @s ec.fx_vis matches 1 run particle cloud ~ ~0.8 ~ 0.2 0.2 0.2 0.01 3
execute if score @s ec.fx_vis matches 2.. run particle cloud ~ ~0.8 ~ 0.2 0.3 0.2 0.02 6
