# === FX · COOK SIMMER STOKE — feed the flame (heat up) ===
# Run AS the player, POSITIONED at the player, from cooking/minigame/phase2_simmer/do_stoke.
# A low flame-whoosh + a RISING flute note + flame/smoke motes drifting upward. LIGHT.
# Ladder: 0=Off · 1=Reduced · 2=Full · 3=Cracked.

# ── SOUND ── a low fire whoosh + a rising flute note (D→F#).
execute if score @s ec.fx_snd matches 1 run playsound minecraft:block.note_block.flute master @s ~ ~ ~ 0.4 0.794
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.fire.ambient master @s ~ ~ ~ 0.6 0.9
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.flute master @s ~ ~ ~ 0.45 0.891
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.flute master @s ~ ~ ~ 0.4 1.0

# ── VISUAL ── flame + smoke motes rising.
execute if score @s ec.fx_vis matches 1 run particle flame ~ ~0.7 ~ 0.2 0.2 0.2 0.02 3
execute if score @s ec.fx_vis matches 2.. run particle flame ~ ~0.7 ~ 0.2 0.3 0.2 0.03 6
execute if score @s ec.fx_vis matches 2.. run particle smoke ~ ~0.9 ~ 0.2 0.35 0.2 0.04 6
