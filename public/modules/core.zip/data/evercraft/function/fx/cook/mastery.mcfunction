# === FX · COOK MASTERY — the milestone fanfare ===
# Run AS the player, POSITIONED at the player, from cooking/mastery/celebrate.
# Reads #ck_mast ec.temp (the milestone: 10 / 25 / 50 / 100). A culinary chord +
# aroma-smoke column that GROWS with the milestone; 100 = a firework topper + a warm
# gold flash. Ladder: 0=Off · 1=Reduced · 2=Full · 3=Cracked.

# ── SOUND · REDUCED ── one bell note.
execute if score @s ec.fx_snd matches 1 run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.5 0.707

# ── SOUND · FULL ── a culinary bell triad whose body fills out as the milestone climbs.
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.55 0.707
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.55 0.891
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.55 1.059
# 25+ adds a bass body; 50+ a high amethyst shimmer; 100 the top octave + a resonate swell.
execute if score @s ec.fx_snd matches 2.. if score #ck_mast ec.temp matches 25.. run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 0.55 0.707
execute if score @s ec.fx_snd matches 2.. if score #ck_mast ec.temp matches 50.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.5 1.587
execute if score @s ec.fx_snd matches 2.. if score #ck_mast ec.temp matches 100 run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.5 1.414
execute if score @s ec.fx_snd matches 2.. if score #ck_mast ec.temp matches 100 run playsound minecraft:block.amethyst_block.resonate master @s ~ ~ ~ 0.5 1.2

# ── SOUND · CRACKED (3..) ── a deep bass + a high amethyst crown.
execute if score @s ec.fx_snd matches 3.. run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 0.6 0.595
execute if score @s ec.fx_snd matches 3.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.45 2.0

# ── VISUAL · REDUCED ── a short aroma column.
execute if score @s ec.fx_vis matches 1 run particle campfire_cosy_smoke ~ ~1 ~ 0.25 0.6 0.25 0.02 10

# ── VISUAL · FULL ── an aroma-smoke column + gold aroma motes; the column TALLENS with the milestone.
execute if score @s ec.fx_vis matches 2.. if score #ck_mast ec.temp matches 10..24 run particle campfire_cosy_smoke ~ ~1 ~ 0.3 0.9 0.3 0.03 22
execute if score @s ec.fx_vis matches 2.. if score #ck_mast ec.temp matches 25..49 run particle campfire_cosy_smoke ~ ~1 ~ 0.35 1.2 0.35 0.03 30
execute if score @s ec.fx_vis matches 2.. if score #ck_mast ec.temp matches 50..99 run particle campfire_cosy_smoke ~ ~1.1 ~ 0.4 1.5 0.4 0.04 40
execute if score @s ec.fx_vis matches 2.. if score #ck_mast ec.temp matches 100 run particle campfire_cosy_smoke ~ ~1.2 ~ 0.45 1.9 0.45 0.04 50
execute if score @s ec.fx_vis matches 2.. run particle happy_villager ~ ~1.2 ~ 0.35 0.6 0.35 0 12
execute if score @s ec.fx_vis matches 2.. run particle end_rod ~ ~1 ~ 0.3 0.9 0.3 0.05 16
execute if score @s ec.fx_vis matches 2.. run particle dust{color:[1.0,0.85,0.4],scale:1.0} ~ ~1.1 ~ 0.35 0.6 0.35 0 16
# 100 = a firework topper + a warm gold flash (the Master Chef crown).
execute if score @s ec.fx_vis matches 2.. if score #ck_mast ec.temp matches 100 run particle flash{color:[1.0,0.85,0.4,1.0]} ~ ~1.3 ~
execute if score @s ec.fx_vis matches 2.. if score #ck_mast ec.temp matches 100 run particle firework ~ ~1.5 ~ 0.4 0.7 0.4 0.06 18

# ── CRACKED (3..) ── a second flash + a taller aroma/gold pillar + an extra firework.
execute if score @s ec.fx_vis matches 3.. run particle flash{color:[1.0,0.92,0.6,1.0]} ~ ~2 ~
execute if score @s ec.fx_vis matches 3.. run particle firework ~ ~2 ~ 0.5 0.8 0.5 0.08 22
execute if score @s ec.fx_vis matches 3.. run particle dust_color_transition{from_color:[1.0,0.78,0.25],scale:1.7,to_color:[1.0,1.0,0.85]} ~ ~1.6 ~ 0.4 1.1 0.4 0.07 34
