# === FX · COOK QUEST COMPLETE — the Grand Cook capstone cinematic ===
# Run AS the player, POSITIONED at the player, from cooking/questline/finish.
# The crown moment of the whole cooking system: a full culinary chord (bell triad +
# bass body + amethyst resonate) + an aroma-steam column + one firework + a warm gold
# flash + an end_rod rise. Modeled on result_masterwork + grand_complete.
# Ladder: 0=Off · 1=Reduced · 2=Full · 3=Cracked.

# ── SOUND · REDUCED ── one full bell note.
execute if score @s ec.fx_snd matches 1 run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.6 0.707

# ── SOUND · FULL ── a full culinary chord: bell triad + deep bass body + a resonate swell + chime crown.
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.65 0.707
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.65 0.891
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.65 1.059
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.6 1.414
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 0.65 0.707
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.amethyst_block.resonate master @s ~ ~ ~ 0.55 1.2
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.5 1.587

# ── SOUND · CRACKED (3..) ── a deep bass boom + a top-octave amethyst crown.
execute if score @s ec.fx_snd matches 3.. run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 0.7 0.595
execute if score @s ec.fx_snd matches 3.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.5 2.0

# ── VISUAL · REDUCED ── one warm aroma column.
execute if score @s ec.fx_vis matches 1 run particle campfire_cosy_smoke ~ ~1 ~ 0.3 0.9 0.3 0.03 18

# ── VISUAL · FULL ── a gold flash + an aroma-steam column + a firework + an end_rod rise + a gold pillar.
execute if score @s ec.fx_vis matches 2.. run particle flash{color:[1.0,0.85,0.4,1.0]} ~ ~1.3 ~
execute if score @s ec.fx_vis matches 2.. run particle campfire_cosy_smoke ~ ~1 ~ 0.4 1.4 0.4 0.04 36
execute if score @s ec.fx_vis matches 2.. run particle happy_villager ~ ~1.2 ~ 0.4 0.7 0.4 0 14
execute if score @s ec.fx_vis matches 2.. run particle end_rod ~ ~1 ~ 0.35 1.3 0.35 0.07 32
execute if score @s ec.fx_vis matches 2.. run particle firework ~ ~1.5 ~ 0.45 0.7 0.45 0.07 20
execute if score @s ec.fx_vis matches 2.. run particle dust_color_transition{from_color:[1.0,0.78,0.25],scale:1.4,to_color:[1.0,1.0,0.85]} ~ ~1.4 ~ 0.4 1.0 0.4 0.05 28

# ── CRACKED (3..) ── a second flash, a taller aroma/gold pillar, an extra firework, a higher rod column.
execute if score @s ec.fx_vis matches 3.. run particle flash{color:[1.0,0.92,0.6,1.0]} ~ ~2.2 ~
execute if score @s ec.fx_vis matches 3.. run particle campfire_cosy_smoke ~ ~1.5 ~ 0.45 2.0 0.45 0.05 50
execute if score @s ec.fx_vis matches 3.. run particle firework ~ ~2.2 ~ 0.55 0.9 0.55 0.09 28
execute if score @s ec.fx_vis matches 3.. run particle end_rod ~ ~1.6 ~ 0.4 1.8 0.4 0.09 44
execute if score @s ec.fx_vis matches 3.. run particle dust_color_transition{from_color:[1.0,0.78,0.25],scale:1.9,to_color:[1.0,1.0,0.9]} ~ ~1.8 ~ 0.45 1.4 0.45 0.08 40
