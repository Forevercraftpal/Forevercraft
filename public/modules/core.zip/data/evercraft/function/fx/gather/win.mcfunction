# === FX · GATHER OUTCOME: WIN (shared across every node source) =======================
# Run AS the gathering player, POSITIONED at the node, from gather/resolve_win.
# Source flavour via ec.gth_src (1=prospect 2=forage 3=fishing 4=hive[Lamentor] 5=chest).
# Fires ONCE per successful node — no tick cost.
#
# INTENSITY (ADDITIVE ladder, set per-channel in codex Settings):
#   ec.fx_snd / ec.fx_vis : 0=Off · 1=Reduced · 2=Full · 3=Cracked
#   Reduced-only `if …matches 1` · Full-and-up `if …matches 2..` · Cracked-only `if …matches 3..`
#   (Cracked LAYERS on top of the Full burst — never duplicates it.)
#
# SOUND PALETTE LAW (Joseph 2026-06-04): musical note-block / pitched / elemental cues only —
# NO mob-vocal grunts (villager hums, wolf whines, parrot flaps). Those live only on meme companions.
# Note-block pitch table (in-tune semitones, F#0=0.5 … F#2=2.0):
#   A 0.595 · C 0.707 · C# 0.749 · D 0.794 · E 0.891 · F# 1.0 · G 1.059 · A 1.189 · B 1.335 · C 1.414 · D 1.587
# Source musical signature = a major triad on the source's lead instrument; the TOP voice is
# ALWAYS a high PLING sparkle (Joseph 2026-06-10: "make it like the chest node last note" — the
# chest chord's pling D' 1.587 is the reference; every source now resolves the same way):
#   prospect bell A·C#·E · forage harp C·E·C' (G' top is out of the 0.5-2.0 pitch range — octave root instead) · fishing flute D·A·D' · hive iron_xylophone F#·A#·C' · chest bell+pling G·B·D'

# ───────────────────────── SOUND ─────────────────────────
# REDUCED (1): a single soft root note.
execute if score @s ec.fx_snd matches 1 if score @s ec.gth_src matches 1 run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.4 0.595
execute if score @s ec.fx_snd matches 1 if score @s ec.gth_src matches 2 run playsound minecraft:block.note_block.harp master @s ~ ~ ~ 0.4 0.707
execute if score @s ec.fx_snd matches 1 if score @s ec.gth_src matches 3 run playsound minecraft:block.note_block.flute master @s ~ ~ ~ 0.4 0.794
execute if score @s ec.fx_snd matches 1 if score @s ec.gth_src matches 4 run playsound minecraft:block.note_block.iron_xylophone master @s ~ ~ ~ 0.4 1.0
execute if score @s ec.fx_snd matches 1 if score @s ec.gth_src matches 5 run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.4 1.059

# FULL & up (2..): the source's major triad, stacked into a chord.
execute if score @s ec.fx_snd matches 2.. if score @s ec.gth_src matches 1 run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.5 0.595
execute if score @s ec.fx_snd matches 2.. if score @s ec.gth_src matches 1 run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.5 0.749
execute if score @s ec.fx_snd matches 2.. if score @s ec.gth_src matches 1 run playsound minecraft:block.note_block.pling master @s ~ ~ ~ 0.45 1.782
execute if score @s ec.fx_snd matches 2.. if score @s ec.gth_src matches 2 run playsound minecraft:block.note_block.harp master @s ~ ~ ~ 0.5 0.707
execute if score @s ec.fx_snd matches 2.. if score @s ec.gth_src matches 2 run playsound minecraft:block.note_block.harp master @s ~ ~ ~ 0.5 0.891
execute if score @s ec.fx_snd matches 2.. if score @s ec.gth_src matches 2 run playsound minecraft:block.note_block.pling master @s ~ ~ ~ 0.45 1.414
execute if score @s ec.fx_snd matches 2.. if score @s ec.gth_src matches 3 run playsound minecraft:block.note_block.flute master @s ~ ~ ~ 0.5 0.794
execute if score @s ec.fx_snd matches 2.. if score @s ec.gth_src matches 3 run playsound minecraft:block.note_block.flute master @s ~ ~ ~ 0.5 1.189
execute if score @s ec.fx_snd matches 2.. if score @s ec.gth_src matches 3 run playsound minecraft:block.note_block.pling master @s ~ ~ ~ 0.45 1.587
execute if score @s ec.fx_snd matches 2.. if score @s ec.gth_src matches 4 run playsound minecraft:block.note_block.iron_xylophone master @s ~ ~ ~ 0.5 1.0
execute if score @s ec.fx_snd matches 2.. if score @s ec.gth_src matches 4 run playsound minecraft:block.note_block.iron_xylophone master @s ~ ~ ~ 0.5 1.26
execute if score @s ec.fx_snd matches 2.. if score @s ec.gth_src matches 4 run playsound minecraft:block.note_block.pling master @s ~ ~ ~ 0.45 1.498
execute if score @s ec.fx_snd matches 2.. if score @s ec.gth_src matches 5 run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.5 1.059
execute if score @s ec.fx_snd matches 2.. if score @s ec.gth_src matches 5 run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.5 1.335
execute if score @s ec.fx_snd matches 2.. if score @s ec.gth_src matches 5 run playsound minecraft:block.note_block.pling master @s ~ ~ ~ 0.45 1.587

# CRACKED (3..): low-end body (bass root) + a high octave shimmer over the chord.
execute if score @s ec.fx_snd matches 3.. if score @s ec.gth_src matches 1 run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 0.7 0.595
execute if score @s ec.fx_snd matches 3.. if score @s ec.gth_src matches 2 run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 0.7 0.707
execute if score @s ec.fx_snd matches 3.. if score @s ec.gth_src matches 3 run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 0.7 0.794
execute if score @s ec.fx_snd matches 3.. if score @s ec.gth_src matches 4 run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 0.6 0.5
execute if score @s ec.fx_snd matches 3.. if score @s ec.gth_src matches 5 run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 0.7 0.529
execute if score @s ec.fx_snd matches 3.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.45 1.9
execute if score @s ec.fx_snd matches 3.. run playsound minecraft:block.note_block.pling master @s ~ ~ ~ 0.4 2.0

# ───────────────────────── VISUAL ─────────────────────────
# REDUCED (1): one source-tinted dust pop.
execute if score @s ec.fx_vis matches 1 if score @s ec.gth_src matches 1 run particle dust{color:[0.4,0.9,1.0],scale:0.8} ~ ~0.6 ~ 0.2 0.25 0.2 0 4
execute if score @s ec.fx_vis matches 1 if score @s ec.gth_src matches 2 run particle dust{color:[0.45,0.95,0.35],scale:0.8} ~ ~0.6 ~ 0.2 0.25 0.2 0 4
execute if score @s ec.fx_vis matches 1 if score @s ec.gth_src matches 3 run particle dust{color:[0.35,0.7,1.0],scale:0.8} ~ ~0.5 ~ 0.2 0.2 0.2 0 4
execute if score @s ec.fx_vis matches 1 if score @s ec.gth_src matches 4 run particle dust{color:[1.0,0.78,0.25],scale:0.7} ~ ~0.7 ~ 0.2 0.25 0.2 0 4
execute if score @s ec.fx_vis matches 1 if score @s ec.gth_src matches 5 run particle dust{color:[1.0,0.85,0.3],scale:0.9} ~ ~0.6 ~ 0.2 0.25 0.2 0 4

# FULL & up (2..): the source's signature burst.
execute if score @s ec.fx_vis matches 2.. if score @s ec.gth_src matches 1 run particle dust{color:[0.4,0.9,1.0],scale:0.9} ~ ~0.6 ~ 0.25 0.3 0.25 0 10
execute if score @s ec.fx_vis matches 2.. if score @s ec.gth_src matches 1 run particle crit ~ ~0.6 ~ 0.25 0.35 0.25 0.05 10
execute if score @s ec.fx_vis matches 2.. if score @s ec.gth_src matches 1 run particle enchant ~ ~0.9 ~ 0.2 0.3 0.2 0.4 8
execute if score @s ec.fx_vis matches 2.. if score @s ec.gth_src matches 2 run particle dust{color:[0.45,0.95,0.35],scale:0.9} ~ ~0.6 ~ 0.25 0.3 0.25 0 10
execute if score @s ec.fx_vis matches 2.. if score @s ec.gth_src matches 2 run particle spore_blossom_air ~ ~0.7 ~ 0.3 0.3 0.3 0 8
execute if score @s ec.fx_vis matches 2.. if score @s ec.gth_src matches 2 run particle happy_villager ~ ~0.6 ~ 0.25 0.25 0.25 0 6
execute if score @s ec.fx_vis matches 2.. if score @s ec.gth_src matches 3 run particle dust{color:[0.35,0.7,1.0],scale:0.9} ~ ~0.5 ~ 0.25 0.25 0.25 0 8
execute if score @s ec.fx_vis matches 2.. if score @s ec.gth_src matches 3 run particle splash ~ ~0.5 ~ 0.3 0.2 0.3 0 12
execute if score @s ec.fx_vis matches 2.. if score @s ec.gth_src matches 3 run particle bubble_pop ~ ~0.5 ~ 0.25 0.2 0.25 0 8
execute if score @s ec.fx_vis matches 2.. if score @s ec.gth_src matches 4 run particle dust{color:[1.0,0.78,0.25],scale:0.8} ~ ~0.7 ~ 0.25 0.3 0.25 0 10
execute if score @s ec.fx_vis matches 2.. if score @s ec.gth_src matches 4 run particle falling_nectar ~ ~0.8 ~ 0.3 0.3 0.3 0 8
execute if score @s ec.fx_vis matches 2.. if score @s ec.gth_src matches 4 run particle glow ~ ~0.7 ~ 0.2 0.25 0.2 0.02 5
execute if score @s ec.fx_vis matches 2.. if score @s ec.gth_src matches 5 run particle dust{color:[1.0,0.85,0.3],scale:0.9} ~ ~0.6 ~ 0.25 0.3 0.25 0 10
execute if score @s ec.fx_vis matches 2.. if score @s ec.gth_src matches 5 run particle wax_on ~ ~0.6 ~ 0.25 0.3 0.25 0 8
execute if score @s ec.fx_vis matches 2.. if score @s ec.gth_src matches 5 run particle glow ~ ~0.8 ~ 0.2 0.3 0.2 0.02 6

# CRACKED (3..): the cinematic layer — a tinted flash, a rising rod column, firework sparks,
# and a source→white dust-transition pillar. Layers ON the Full burst. One-shot, opt-in.
execute if score @s ec.fx_vis matches 3.. run particle end_rod ~ ~0.8 ~ 0.3 1.2 0.3 0.08 30
execute if score @s ec.fx_vis matches 3.. run particle firework ~ ~0.9 ~ 0.4 0.6 0.4 0.05 12
execute if score @s ec.fx_vis matches 3.. if score @s ec.gth_src matches 1 run particle flash{color:[0.5,0.9,1.0,1.0]} ~ ~0.9 ~
execute if score @s ec.fx_vis matches 3.. if score @s ec.gth_src matches 1 run particle dust_color_transition{from_color:[0.4,0.9,1.0],scale:1.8,to_color:[1.0,1.0,1.0]} ~ ~1 ~ 0.4 0.7 0.4 0.1 30
execute if score @s ec.fx_vis matches 3.. if score @s ec.gth_src matches 1 run particle electric_spark ~ ~0.8 ~ 0.3 0.6 0.3 0.4 16
execute if score @s ec.fx_vis matches 3.. if score @s ec.gth_src matches 2 run particle flash{color:[0.5,1.0,0.4,1.0]} ~ ~0.9 ~
execute if score @s ec.fx_vis matches 3.. if score @s ec.gth_src matches 2 run particle dust_color_transition{from_color:[0.45,0.95,0.35],scale:1.8,to_color:[1.0,1.0,1.0]} ~ ~1 ~ 0.4 0.7 0.4 0.1 30
execute if score @s ec.fx_vis matches 3.. if score @s ec.gth_src matches 2 run particle spore_blossom_air ~ ~0.9 ~ 0.4 0.6 0.4 0 16
execute if score @s ec.fx_vis matches 3.. if score @s ec.gth_src matches 3 run particle flash{color:[0.4,0.75,1.0,1.0]} ~ ~0.9 ~
execute if score @s ec.fx_vis matches 3.. if score @s ec.gth_src matches 3 run particle dust_color_transition{from_color:[0.35,0.7,1.0],scale:1.8,to_color:[1.0,1.0,1.0]} ~ ~1 ~ 0.4 0.7 0.4 0.1 30
execute if score @s ec.fx_vis matches 3.. if score @s ec.gth_src matches 3 run particle bubble ~ ~0.7 ~ 0.4 0.5 0.4 0 20
execute if score @s ec.fx_vis matches 3.. if score @s ec.gth_src matches 4 run particle flash{color:[1.0,0.82,0.3,1.0]} ~ ~0.9 ~
execute if score @s ec.fx_vis matches 3.. if score @s ec.gth_src matches 4 run particle dust_color_transition{from_color:[1.0,0.78,0.25],scale:1.8,to_color:[1.0,0.95,0.7]} ~ ~1 ~ 0.4 0.7 0.4 0.1 30
execute if score @s ec.fx_vis matches 3.. if score @s ec.gth_src matches 4 run particle falling_nectar ~ ~1 ~ 0.4 0.6 0.4 0 18
execute if score @s ec.fx_vis matches 3.. if score @s ec.gth_src matches 5 run particle flash{color:[1.0,0.85,0.35,1.0]} ~ ~0.9 ~
execute if score @s ec.fx_vis matches 3.. if score @s ec.gth_src matches 5 run particle dust_color_transition{from_color:[1.0,0.85,0.3],scale:1.8,to_color:[1.0,1.0,1.0]} ~ ~1 ~ 0.4 0.7 0.4 0.1 30
execute if score @s ec.fx_vis matches 3.. if score @s ec.gth_src matches 5 run particle wax_on ~ ~0.9 ~ 0.4 0.6 0.4 0 16
