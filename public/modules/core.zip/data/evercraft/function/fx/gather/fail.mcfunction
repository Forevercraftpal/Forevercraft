# === FX · GATHER OUTCOME: FAIL (node survives — 1st/2nd miss) ===
# Run AS the player, POSITIONED at the node, from gather/resolve_fail.
# Deliberately LIGHT at every tier — a miss should read as "not yet", never a punishment.
# Cracked does NOT celebrate a miss; it just gets a slightly fuller dust puff.
# Ladder: 0=Off · 1=Reduced · 2=Full · 3=Cracked.

execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 0.4 0.5
execute if score @s ec.fx_vis matches 1 run particle smoke ~ ~0.6 ~ 0.15 0.15 0.15 0 2
execute if score @s ec.fx_vis matches 2.. run particle smoke ~ ~0.6 ~ 0.2 0.2 0.2 0 6
execute if score @s ec.fx_vis matches 3.. run particle dust{color:[0.5,0.5,0.5],scale:0.8} ~ ~0.6 ~ 0.2 0.2 0.2 0 6
