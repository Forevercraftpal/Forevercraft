# === FX · GATHER OUTCOME: CRUMBLE (3rd consecutive miss — node spent) ===
# Run AS the player, POSITIONED at the node, from gather/resolve_crumble.
# A downward "collapse" — heavier than a fail but clearly NOT a reward (no bright chord,
# no celebratory sparks): gravel break + a descending bass drop + dust/ash settling.
# Ladder: 0=Off · 1=Reduced · 2=Full · 3=Cracked.

# ── SOUND ── descending two-note bass "down" (B♭→F#) under a gravel crack.
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.gravel.break master @s ~ ~ ~ 0.7 0.7
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 0.5 0.667
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 0.5 0.5
execute if score @s ec.fx_snd matches 3.. run playsound minecraft:block.stone.break master @s ~ ~ ~ 0.8 0.6

# ── VISUAL ── smoke + ash settling; Cracked adds a grey dust-transition collapse.
execute if score @s ec.fx_vis matches 1 run particle large_smoke ~ ~0.6 ~ 0.2 0.2 0.2 0 3
execute if score @s ec.fx_vis matches 2.. run particle large_smoke ~ ~0.6 ~ 0.25 0.25 0.25 0 8
execute if score @s ec.fx_vis matches 2.. run particle ash ~ ~0.5 ~ 0.3 0.2 0.3 0.02 16
execute if score @s ec.fx_vis matches 3.. run particle dust_color_transition{from_color:[0.55,0.55,0.55],scale:1.6,to_color:[0.2,0.2,0.2]} ~ ~0.6 ~ 0.3 0.3 0.3 0.05 24
