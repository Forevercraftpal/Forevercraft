# === FX · UI CLICK — feedback for clicking a menu / tellraw option (gated) ===
# Run AS the player. A soft, pleasant UI blip — a note-block pling + a tiny spark at eye level.
# Honours the FX setting: sound plays unless Off; the spark is Full+, an enchant glint at Cracked.
# Callers fire it ONCE per click (the central menu hook fires it when any Adv.MenuElement registers a click).
# Reset the menu idle timer here too: this fires only from a LIVE menu tick handling a real click,
# so it's the robust "player is actively using this menu" signal for cleanup/menu_idle (a dead
# menu's tick never runs, so it never resets — and gets swept at 60s). Bough is the one menu that
# doesn't route clicks through here; it resets ec.menu_idle in bough/codex/tick.
scoreboard players set @s ec.menu_idle 0
execute unless score @s ec.fx_snd matches 0 run playsound minecraft:block.note_block.pling master @s ~ ~ ~ 0.45 1.5
execute if score @s ec.fx_vis matches 2.. at @s run particle dust{color:[0.6,0.85,1.0],scale:0.5} ~ ~1.4 ~ 0.1 0.1 0.1 0 2
execute if score @s ec.fx_vis matches 3.. at @s run particle enchant ~ ~1.5 ~ 0.15 0.15 0.15 0.3 2
