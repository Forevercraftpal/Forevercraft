# Zone Node Highlight — Joseph task #73, 2026-06-13
# Run at: any harvestable node position (chest / forage / prospect / fishing splash / CF / buried-cache).
# Force-particle emit, viewer-targeted to players within 24 blocks who are standing in their own
# guild zone (ec.guild_in_zone=1) or claimed home zone (hs.in_zone=1). FX-vis gated like the
# rest of the bough FX system — Off stays dark. Two distinct colors so a player can read which
# zone the highlight is calling out (gold = guild, soft pink = house).
particle dust{color:[1.0,0.85,0.3],scale:0.8} ~ ~1.0 ~ 0.2 0.5 0.2 0 2 force @a[distance=..24,scores={ec.guild_in_zone=1..,ec.fx_vis=1..}]
particle dust{color:[0.95,0.7,1.0],scale:0.8} ~ ~1.0 ~ 0.2 0.5 0.2 0 2 force @a[distance=..24,scores={hs.in_zone=1..,ec.fx_vis=1..}]
