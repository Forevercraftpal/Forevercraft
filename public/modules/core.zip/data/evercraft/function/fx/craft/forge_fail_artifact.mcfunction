# === FX · CRAFT FORGE FAIL ARTIFACT — a precious material crumbled (Forge Table) ===
# Run as the player, positioned at the table, from forging/minigame/result_fail_artifact (slag branch).
# Heavier than a plain fail — the loss stings: a deeper anvil thunk + a descending sour drop + smoke.
# Ladder: 0=Off · 1=Reduced · 2=Full · 3=Cracked.

# ── SOUND ── a deep failed thunk + a descending sour two-note drop.
execute if score @s ec.fx_snd matches 1 run playsound minecraft:block.anvil.land master @s ~ ~ ~ 0.5 0.45
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.anvil.land master @s ~ ~ ~ 0.6 0.45
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.iron_xylophone master @s ~ ~ ~ 0.45 0.595
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.iron_xylophone master @s ~ ~ ~ 0.45 0.5
execute if score @s ec.fx_snd matches 3.. run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 0.6 0.45

# ── VISUAL ── a thicker smoke pall + dark ash dust. Cracked adds a sinking large_smoke roll.
execute if score @s ec.fx_vis matches 1 run particle smoke ~ ~1 ~ 0.3 0.35 0.3 0.01 10
execute if score @s ec.fx_vis matches 2.. run particle smoke ~ ~1 ~ 0.35 0.4 0.35 0.02 18
execute if score @s ec.fx_vis matches 2.. run particle dust{color:[0.3,0.28,0.26],scale:0.8} ~ ~0.9 ~ 0.3 0.35 0.3 0 12
execute if score @s ec.fx_vis matches 3.. run particle large_smoke ~ ~1 ~ 0.4 0.4 0.4 0.01 18
