# === FX · CRAFT GRAND FORGE FAIL — the flame dies out (Grand Forge failure) ===
# Run as the player, positioned at the Grand Forge, from grand_forge/fail.
# A heavy descending bass + ash + large_smoke. No reward cues — the gauntlet was lost.
# Ladder: 0=Off · 1=Reduced · 2=Full · 3=Cracked.

# ── SOUND ── a heavy descending bass drop (the forge guttering out).
execute if score @s ec.fx_snd matches 1 run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 0.6 0.6
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 0.8 0.6
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 0.8 0.529
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 0.7 0.471
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.fire.extinguish master @s ~ ~ ~ 0.6 0.8
execute if score @s ec.fx_snd matches 3.. run playsound minecraft:block.note_block.didgeridoo master @s ~ ~ ~ 0.6 0.4

# ── VISUAL ── a sinking smoke pall + grey ash dust. Cracked adds a wider large_smoke roll.
execute if score @s ec.fx_vis matches 1 run particle large_smoke ~ ~1 ~ 0.4 0.4 0.4 0.01 12
execute if score @s ec.fx_vis matches 2.. run particle large_smoke ~ ~1 ~ 0.6 0.5 0.6 0.01 24
execute if score @s ec.fx_vis matches 2.. run particle smoke ~ ~1.2 ~ 0.5 0.6 0.5 0.02 24
execute if score @s ec.fx_vis matches 2.. run particle dust{color:[0.3,0.28,0.26],scale:1.0} ~ ~0.8 ~ 0.5 0.4 0.5 0 18
execute if score @s ec.fx_vis matches 3.. run particle large_smoke ~ ~1.5 ~ 0.9 0.7 0.9 0.01 30
execute if score @s ec.fx_vis matches 3.. run particle ash ~ ~1.5 ~ 0.8 0.8 0.8 0.02 30
