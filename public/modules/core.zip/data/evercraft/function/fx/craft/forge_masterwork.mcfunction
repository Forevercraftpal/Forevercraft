# === FX · CRAFT FORGE MASTERWORK — a flawless creation (Forge Table) ===
# Run as the player, positioned at the table, from forging/minigame/result_masterwork.
# The anvil song's triumph: a bright iron_xylophone triad + bell topper over the anvil ring,
# an end_rod rise, and orange→white metal dust. Cracked = a gold flash + a firework crown.
# Ladder: 0=Off · 1=Reduced · 2=Full · 3=Cracked.

# ── SOUND ── anvil ring + a bright iron_xylophone triad (A·C#'·E') + a high bell topper.
execute if score @s ec.fx_snd matches 1 run playsound minecraft:block.anvil.use master @s ~ ~ ~ 0.45 1.2
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.anvil.use master @s ~ ~ ~ 0.55 1.2
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.iron_xylophone master @s ~ ~ ~ 0.55 1.189
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.iron_xylophone master @s ~ ~ ~ 0.55 1.498
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.iron_xylophone master @s ~ ~ ~ 0.5 1.782
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.45 2.0
execute if score @s ec.fx_snd matches 3.. run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 0.6 0.595
execute if score @s ec.fx_snd matches 3.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.45 1.9

# ── VISUAL ── a metal-dust burst (orange→white) + an end_rod rise + spark fan.
execute if score @s ec.fx_vis matches 1 run particle dust{color:[1.0,0.55,0.2],scale:0.9} ~ ~1 ~ 0.3 0.35 0.3 0 8
execute if score @s ec.fx_vis matches 2.. run particle dust_color_transition{from_color:[1.0,0.5,0.15],scale:1.0,to_color:[1.0,1.0,0.9]} ~ ~1 ~ 0.4 0.5 0.4 0.05 24
execute if score @s ec.fx_vis matches 2.. run particle end_rod ~ ~0.9 ~ 0.3 0.9 0.3 0.06 24
execute if score @s ec.fx_vis matches 2.. run particle crit ~ ~1 ~ 0.35 0.4 0.35 0.05 16
execute if score @s ec.fx_vis matches 2.. run particle electric_spark ~ ~1 ~ 0.35 0.4 0.35 0.08 12

# ── CRACKED (3..) ── a gold flash + a firework crown + a taller rod column.
execute if score @s ec.fx_vis matches 3.. run particle flash{color:[1.0,0.85,0.35,1.0]} ~ ~1.1 ~
execute if score @s ec.fx_vis matches 3.. run particle firework ~ ~1.1 ~ 0.4 0.6 0.4 0.06 16
execute if score @s ec.fx_vis matches 3.. run particle end_rod ~ ~1 ~ 0.3 1.4 0.3 0.08 30
execute if score @s ec.fx_vis matches 3.. run particle dust_color_transition{from_color:[1.0,0.5,0.15],scale:1.8,to_color:[1.0,1.0,1.0]} ~ ~1.4 ~ 0.4 1.0 0.4 0.08 30
