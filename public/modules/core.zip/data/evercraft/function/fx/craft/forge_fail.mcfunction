# === FX · CRAFT FORGE FAIL — the material crumbled to slag (Forge Table) ===
# Run as the player, positioned at the table, from forging/minigame/result_fail.
# The anvil song's saddest note: a dull low anvil thunk + one sour iron_xylophone + a smoke puff.
# Ladder: 0=Off · 1=Reduced · 2=Full · 3=Cracked.

# ── SOUND ── a heavy failed thunk + a flat sour note.
execute if score @s ec.fx_snd matches 1 run playsound minecraft:block.anvil.land master @s ~ ~ ~ 0.4 0.5
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.anvil.land master @s ~ ~ ~ 0.5 0.5
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.iron_xylophone master @s ~ ~ ~ 0.4 0.529
execute if score @s ec.fx_snd matches 3.. run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 0.5 0.5

# ── VISUAL ── a grey smoke puff; Cracked adds a brief ash drift.
execute if score @s ec.fx_vis matches 1 run particle smoke ~ ~1 ~ 0.25 0.3 0.25 0.01 6
execute if score @s ec.fx_vis matches 2.. run particle smoke ~ ~1 ~ 0.3 0.35 0.3 0.02 12
execute if score @s ec.fx_vis matches 2.. run particle dust{color:[0.35,0.33,0.3],scale:0.7} ~ ~0.9 ~ 0.25 0.3 0.25 0 6
execute if score @s ec.fx_vis matches 3.. run particle large_smoke ~ ~1 ~ 0.3 0.4 0.3 0.01 10
