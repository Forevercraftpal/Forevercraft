# === FX · CRAFT FUSION INERT — the mixture destabilizes (Fusion Funnel) ===
# Run as the player, positioned at the funnel, from alchemy/minigame/result_inert.
# A flat fizzle: a low amethyst break-thud + a smoke puff. No reward cue — this is the fail.
# Ladder: 0=Off · 1=Reduced · 2=Full · 3=Cracked.

# ── SOUND ── a dull amethyst break + a low flat note.
execute if score @s ec.fx_snd matches 1 run playsound minecraft:block.amethyst_block.break master @s ~ ~ ~ 0.4 0.6
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.amethyst_block.break master @s ~ ~ ~ 0.5 0.6
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 0.4 0.529
execute if score @s ec.fx_snd matches 3.. run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 0.5 0.5

# ── VISUAL ── a dull smoke fizzle + faint purple haze. Cracked adds a sinking smoke roll.
execute if score @s ec.fx_vis matches 1 run particle smoke ~ ~1 ~ 0.25 0.3 0.25 0.01 8
execute if score @s ec.fx_vis matches 2.. run particle smoke ~ ~1 ~ 0.3 0.35 0.3 0.02 14
execute if score @s ec.fx_vis matches 2.. run particle dust{color:[0.45,0.32,0.55],scale:0.7} ~ ~0.9 ~ 0.25 0.3 0.25 0 6
execute if score @s ec.fx_vis matches 3.. run particle large_smoke ~ ~1 ~ 0.3 0.4 0.3 0.01 12
