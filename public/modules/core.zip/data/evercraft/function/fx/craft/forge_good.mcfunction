# === FX · CRAFT FORGE GOOD — a fine creation (Forge Table) ===
# Run as the player, positioned at the table, from forging/minigame/result_good.
# A solid 3-note ascending iron_xylophone forge-chord over the anvil's ring + a spark fan + embers.
# Ladder: 0=Off · 1=Reduced · 2=Full · 3=Cracked.

# ── SOUND ── anvil ring + an ascending iron_xylophone triad (F#·A·C').
execute if score @s ec.fx_snd matches 1 run playsound minecraft:block.anvil.use master @s ~ ~ ~ 0.4 1.0
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.anvil.use master @s ~ ~ ~ 0.5 1.0
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.iron_xylophone master @s ~ ~ ~ 0.5 1.0
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.iron_xylophone master @s ~ ~ ~ 0.5 1.189
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.iron_xylophone master @s ~ ~ ~ 0.45 1.414
execute if score @s ec.fx_snd matches 3.. run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.4 1.587

# ── VISUAL ── a spark fan + an ember dust burst. Cracked adds a rod lift + electric flare.
execute if score @s ec.fx_vis matches 1 run particle crit ~ ~1 ~ 0.3 0.3 0.3 0.03 8
execute if score @s ec.fx_vis matches 2.. run particle crit ~ ~1 ~ 0.35 0.35 0.35 0.05 16
execute if score @s ec.fx_vis matches 2.. run particle dust{color:[1.0,0.55,0.2],scale:0.8} ~ ~1 ~ 0.3 0.35 0.3 0 16
execute if score @s ec.fx_vis matches 2.. run particle electric_spark ~ ~1 ~ 0.3 0.3 0.3 0.06 10
execute if score @s ec.fx_vis matches 3.. run particle end_rod ~ ~0.9 ~ 0.25 0.7 0.25 0.05 16
execute if score @s ec.fx_vis matches 3.. run particle electric_spark ~ ~1 ~ 0.4 0.4 0.4 0.1 16
