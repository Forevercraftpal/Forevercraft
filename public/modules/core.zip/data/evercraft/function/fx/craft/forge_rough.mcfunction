# === FX · CRAFT FORGE ROUGH — it holds together, just barely (Forge Table) ===
# Run as the player, positioned at the table, from forging/minigame/result_rough.
# A modest two-note iron_xylophone rise + the anvil's working "use" + a few sparks.
# Ladder: 0=Off · 1=Reduced · 2=Full · 3=Cracked.

# ── SOUND ── anvil work + a two-note iron_xylophone (a tentative success).
execute if score @s ec.fx_snd matches 1 run playsound minecraft:block.anvil.use master @s ~ ~ ~ 0.4 0.9
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.anvil.use master @s ~ ~ ~ 0.5 0.9
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.iron_xylophone master @s ~ ~ ~ 0.45 0.707
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.iron_xylophone master @s ~ ~ ~ 0.45 0.891
execute if score @s ec.fx_snd matches 3.. run playsound minecraft:block.note_block.iron_xylophone master @s ~ ~ ~ 0.4 1.059

# ── VISUAL ── a small spark scatter + a warm ember dust pop.
execute if score @s ec.fx_vis matches 1 run particle crit ~ ~1 ~ 0.25 0.25 0.25 0.02 5
execute if score @s ec.fx_vis matches 2.. run particle crit ~ ~1 ~ 0.3 0.3 0.3 0.03 10
execute if score @s ec.fx_vis matches 2.. run particle dust{color:[0.95,0.6,0.25],scale:0.7} ~ ~1 ~ 0.25 0.3 0.25 0 8
execute if score @s ec.fx_vis matches 3.. run particle electric_spark ~ ~1 ~ 0.3 0.35 0.3 0.05 12
