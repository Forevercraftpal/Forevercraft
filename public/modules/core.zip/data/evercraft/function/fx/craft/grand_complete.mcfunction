# === FX · CRAFT GRAND FORGE COMPLETE — the cinematic (Grand Forge victory) ===
# Run as the player, positioned at the Grand Forge, from grand_forge/complete.
# The house showcase: a green flash → an end_rod column → a firework/totem spray → a forge-green
# dust pillar → a DEEP musical boom (note-block bass triad + beacon/amethyst resonate).
# Replaces the crude ender_dragon.death + trident.thunder cue (palette violation). Cracked = bigger.
# Ladder: 0=Off · 1=Reduced · 2=Full · 3=Cracked.

# ── SOUND ── a deep forge boom: a bass triad + a beacon swell + an amethyst high resonate.
execute if score @s ec.fx_snd matches 1 run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 0.6 0.5
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 0.8 0.5
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 0.8 0.595
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 0.7 0.749
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.beacon.activate master @s ~ ~ ~ 0.6 1.2
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.amethyst_block.resonate master @s ~ ~ ~ 0.6 1.5
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.iron_xylophone master @s ~ ~ ~ 0.55 1.587
execute if score @s ec.fx_snd matches 3.. run playsound minecraft:block.beacon.power_select master @s ~ ~ ~ 0.7 0.8
execute if score @s ec.fx_snd matches 3.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.5 2.0

# ── VISUAL · the flash + end_rod column ──
execute if score @s ec.fx_vis matches 1 run particle end_rod ~ ~1 ~ 0.6 1.2 0.6 0.1 24
execute if score @s ec.fx_vis matches 2.. run particle flash{color:[0.0,1.0,0.3,1.0]} ~ ~1.5 ~
execute if score @s ec.fx_vis matches 2.. run particle end_rod ~ ~1.5 ~ 0.8 2.0 0.8 0.15 50
# ── the firework / totem spray ──
execute if score @s ec.fx_vis matches 2.. run particle totem_of_undying ~ ~1.5 ~ 1.0 1.2 1.0 0.5 40
execute if score @s ec.fx_vis matches 2.. run particle firework ~ ~1.8 ~ 0.8 1.0 0.8 0.08 24
# ── the forge-green dust pillar ──
execute if score @s ec.fx_vis matches 2.. run particle dust_color_transition{from_color:[0.0,0.9,0.3],scale:2.0,to_color:[0.6,1.0,0.7]} ~ ~2 ~ 0.8 1.8 0.8 0.05 50

# ── CRACKED (3..) ── a taller column, a wider firework crown, and a second flash topper.
execute if score @s ec.fx_vis matches 3.. run particle flash{color:[0.4,1.0,0.5,1.0]} ~ ~3 ~
execute if score @s ec.fx_vis matches 3.. run particle end_rod ~ ~2.5 ~ 1.0 3.0 1.0 0.18 60
execute if score @s ec.fx_vis matches 3.. run particle firework ~ ~2.5 ~ 1.2 1.4 1.2 0.1 30
execute if score @s ec.fx_vis matches 3.. run particle dust_color_transition{from_color:[0.0,1.0,0.4],scale:2.5,to_color:[1.0,1.0,1.0]} ~ ~3 ~ 1.0 2.6 1.0 0.08 50
