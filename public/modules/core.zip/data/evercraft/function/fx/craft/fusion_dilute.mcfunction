# === FX · CRAFT FUSION DILUTE — a thin brew forms (Fusion Funnel) ===
# Run as the player, positioned at the funnel, from alchemy/minigame/result_dilute.
# A single amethyst chime + the brewing-stand bubble + a few rising bubbles. The modest success.
# Ladder: 0=Off · 1=Reduced · 2=Full · 3=Cracked.

# ── SOUND ── a soft brew + a single amethyst chime.
execute if score @s ec.fx_snd matches 1 run playsound minecraft:block.brewing_stand.brew master @s ~ ~ ~ 0.4 1.0
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.brewing_stand.brew master @s ~ ~ ~ 0.5 1.0
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.45 0.794
execute if score @s ec.fx_snd matches 3.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.4 1.059

# ── VISUAL ── a few bubbles + a soft purple dust. Cracked adds a small glow lift.
execute if score @s ec.fx_vis matches 1 run particle bubble_pop ~ ~1 ~ 0.25 0.3 0.25 0 5
execute if score @s ec.fx_vis matches 2.. run particle bubble_pop ~ ~1 ~ 0.3 0.35 0.3 0 10
execute if score @s ec.fx_vis matches 2.. run particle dust{color:[0.6,0.4,0.9],scale:0.7} ~ ~1 ~ 0.25 0.3 0.25 0 8
execute if score @s ec.fx_vis matches 3.. run particle glow ~ ~1 ~ 0.25 0.4 0.25 0.01 8
