# === FX · CRAFT FUSION POTENT — a potent elixir crystallizes (Fusion Funnel) ===
# Run as the player, positioned at the funnel, from alchemy/minigame/result_potent.
# A 3-note amethyst chime (D·A·D') over the brewing bubble + a bubble_pop burst + purple dust.
# Ladder: 0=Off · 1=Reduced · 2=Full · 3=Cracked.

# ── SOUND ── the brew + an ascending amethyst chime triad.
execute if score @s ec.fx_snd matches 1 run playsound minecraft:block.brewing_stand.brew master @s ~ ~ ~ 0.4 1.1
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.brewing_stand.brew master @s ~ ~ ~ 0.5 1.1
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.5 0.794
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.5 1.189
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.45 1.587
execute if score @s ec.fx_snd matches 3.. run playsound minecraft:block.amethyst_block.resonate master @s ~ ~ ~ 0.45 1.0

# ── VISUAL ── a bubble_pop burst + a purple dust cloud. Cracked adds a glow rise + rod motes.
execute if score @s ec.fx_vis matches 1 run particle bubble_pop ~ ~1 ~ 0.3 0.35 0.3 0 8
execute if score @s ec.fx_vis matches 2.. run particle bubble_pop ~ ~1 ~ 0.35 0.4 0.35 0 16
execute if score @s ec.fx_vis matches 2.. run particle dust{color:[0.6,0.4,0.9],scale:0.85} ~ ~1 ~ 0.3 0.4 0.3 0 16
execute if score @s ec.fx_vis matches 2.. run particle glow ~ ~1 ~ 0.25 0.4 0.25 0.02 8
execute if score @s ec.fx_vis matches 3.. run particle end_rod ~ ~0.9 ~ 0.25 0.8 0.25 0.05 16
execute if score @s ec.fx_vis matches 3.. run particle dust_color_transition{from_color:[0.6,0.4,0.9],scale:1.6,to_color:[0.85,0.7,1.0]} ~ ~1.1 ~ 0.35 0.7 0.35 0.06 20
