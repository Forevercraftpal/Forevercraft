# === FX · CRAFT ARTIFACT FORGED — an artifact takes shape (forge / brew / grand-forge bonus roll) ===
# Run as the player, POSITIONED at @s, from the *_artifacts/roll_artifact handlers (forge fail/T7,
# alchemy roll, grand-forge compensation). The bright "an artifact takes shape" reveal that fires ON TOP
# of the station's own result cue — masterwork weight. Replaces the old ungated levelup + ui.toast +
# totem reveal those handlers shared. Ladder: 0=Off · 1=Reduced · 2=Full · 3=Cracked.

# ── SOUND ── a bright amethyst/note-block reveal chord (A·C#'·E') crowned by a bell.
execute if score @s ec.fx_snd matches 1 run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.5 1.189
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.55 1.189
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.5 1.498
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.45 1.782
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.amethyst_block.resonate master @s ~ ~ ~ 0.4 1.4
# CRACKED (3..): a deep body note + a high octave shimmer over the reveal chord.
execute if score @s ec.fx_snd matches 3.. run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 0.6 0.595
execute if score @s ec.fx_snd matches 3.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.45 2.0

# ── VISUAL ── REDUCED (1): one soft gold dust pop.
execute if score @s ec.fx_vis matches 1 run particle dust{color:[1.0,0.82,0.35],scale:0.9} ~ ~1 ~ 0.3 0.35 0.3 0 8
# FULL & up (2..): a gold flash + an end_rod rise + a gold-dust burst (the artifact crystallizing).
execute if score @s ec.fx_vis matches 2.. run particle flash{color:[1.0,0.85,0.4,1.0]} ~ ~1.1 ~
execute if score @s ec.fx_vis matches 2.. run particle end_rod ~ ~0.9 ~ 0.3 0.9 0.3 0.06 24
execute if score @s ec.fx_vis matches 2.. run particle dust{color:[1.0,0.82,0.35],scale:1.0} ~ ~1 ~ 0.4 0.5 0.4 0 18
execute if score @s ec.fx_vis matches 2.. run particle glow ~ ~1.2 ~ 0.3 0.5 0.3 0.02 10

# ── CRACKED (3..) ── a taller rod column + a firework crown + a gold→white dust pillar.
execute if score @s ec.fx_vis matches 3.. run particle firework ~ ~1.1 ~ 0.4 0.6 0.4 0.06 14
execute if score @s ec.fx_vis matches 3.. run particle end_rod ~ ~1 ~ 0.3 1.4 0.3 0.08 30
execute if score @s ec.fx_vis matches 3.. run particle dust_color_transition{from_color:[1.0,0.78,0.3],scale:1.8,to_color:[1.0,1.0,1.0]} ~ ~1.4 ~ 0.4 1.0 0.4 0.08 30
