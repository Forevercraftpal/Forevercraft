# === FX · CRAFT FUSION SUBLIME — a perfect fusion (Fusion Funnel) ===
# Run as the player, positioned at the funnel, from alchemy/minigame/result_sublime.
# The brew's triumph: a full amethyst chime cascade + a chime-triad "bottle clink" over the brew,
# a glow rise, and a soft-purple dust pillar. Cracked = a purple flash + a firework crown.
# Ladder: 0=Off · 1=Reduced · 2=Full · 3=Cracked.

# ── SOUND ── the brew + a rising amethyst chime cascade + a high resonate topper.
execute if score @s ec.fx_snd matches 1 run playsound minecraft:block.brewing_stand.brew master @s ~ ~ ~ 0.45 1.2
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.brewing_stand.brew master @s ~ ~ ~ 0.55 1.2
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.55 1.0
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.55 1.335
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.5 1.587
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.5 2.0
execute if score @s ec.fx_snd matches 3.. run playsound minecraft:block.amethyst_block.resonate master @s ~ ~ ~ 0.5 0.5
execute if score @s ec.fx_snd matches 3.. run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.4 2.0

# ── VISUAL ── a bubble burst + a glow rise + a soft-purple dust pillar.
execute if score @s ec.fx_vis matches 1 run particle dust{color:[0.6,0.4,0.9],scale:0.9} ~ ~1 ~ 0.3 0.35 0.3 0 8
execute if score @s ec.fx_vis matches 2.. run particle dust{color:[0.6,0.4,0.9],scale:0.95} ~ ~1.2 ~ 0.35 0.7 0.35 0 24
execute if score @s ec.fx_vis matches 2.. run particle bubble_pop ~ ~1 ~ 0.35 0.4 0.35 0 16
execute if score @s ec.fx_vis matches 2.. run particle glow ~ ~1 ~ 0.3 0.6 0.3 0.03 14
execute if score @s ec.fx_vis matches 2.. run particle witch ~ ~1 ~ 0.3 0.5 0.3 0 12

# ── CRACKED (3..) ── a purple flash + a firework crown + a taller dust→pale pillar + rods.
execute if score @s ec.fx_vis matches 3.. run particle flash{color:[0.7,0.45,1.0,1.0]} ~ ~1.1 ~
execute if score @s ec.fx_vis matches 3.. run particle firework ~ ~1.1 ~ 0.4 0.6 0.4 0.06 16
execute if score @s ec.fx_vis matches 3.. run particle end_rod ~ ~1 ~ 0.3 1.3 0.3 0.07 28
execute if score @s ec.fx_vis matches 3.. run particle dust_color_transition{from_color:[0.6,0.4,0.9],scale:1.8,to_color:[0.92,0.82,1.0]} ~ ~1.4 ~ 0.4 1.0 0.4 0.08 30
