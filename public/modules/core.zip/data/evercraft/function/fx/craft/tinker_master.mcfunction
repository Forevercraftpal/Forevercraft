# === FX · CRAFT TINKER MASTER — the once-ever Master Tinkerer fanfare (Tinker Table) ===
# Run as the player, positioned at the player, from tinkering/finish (fires exactly once, ever).
# The joining of parts: an ascending pling + bell arpeggio, an end_rod + enchant-mote spiral,
# and a gold flash. A once-ever moment — sits near the Cracked ceiling already at Full.
# Ladder: 0=Off · 1=Reduced · 2=Full · 3=Cracked.

# ── SOUND ── an ascending pling arpeggio crowned by a bell (the parts clicking home).
execute if score @s ec.fx_snd matches 1 run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.45 1.0
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.pling master @s ~ ~ ~ 0.5 0.794
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.pling master @s ~ ~ ~ 0.5 1.0
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.pling master @s ~ ~ ~ 0.5 1.189
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.pling master @s ~ ~ ~ 0.5 1.587
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.55 2.0
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.45 1.587
execute if score @s ec.fx_snd matches 3.. run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 0.55 0.595
execute if score @s ec.fx_snd matches 3.. run playsound minecraft:block.amethyst_block.resonate master @s ~ ~ ~ 0.5 1.5

# ── VISUAL · the gold flash + an end_rod spiral + enchant motes ──
execute if score @s ec.fx_vis matches 1 run particle end_rod ~ ~1 ~ 0.4 1.0 0.4 0.08 20
execute if score @s ec.fx_vis matches 2.. run particle flash{color:[1.0,0.85,0.35,1.0]} ~ ~1.2 ~
execute if score @s ec.fx_vis matches 2.. run particle end_rod ~ ~1.2 ~ 0.5 1.6 0.5 0.12 44
execute if score @s ec.fx_vis matches 2.. run particle enchant ~ ~1.8 ~ 0.6 1.2 0.6 0.6 40
execute if score @s ec.fx_vis matches 2.. run particle dust{color:[1.0,0.82,0.3],scale:1.0} ~ ~1.2 ~ 0.5 1.0 0.5 0 30

# ── CRACKED (3..) ── a wider spiral, a firework crown, and a gold→white dust pillar.
execute if score @s ec.fx_vis matches 3.. run particle firework ~ ~1.4 ~ 0.5 0.8 0.5 0.08 20
execute if score @s ec.fx_vis matches 3.. run particle end_rod ~ ~1.5 ~ 0.6 2.2 0.6 0.15 50
execute if score @s ec.fx_vis matches 3.. run particle dust_color_transition{from_color:[1.0,0.82,0.3],scale:2.0,to_color:[1.0,1.0,1.0]} ~ ~1.8 ~ 0.6 1.6 0.6 0.08 40
