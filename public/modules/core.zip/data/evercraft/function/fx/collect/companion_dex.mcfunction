# === FX · COLLECT: NEW COMPANION CATALOGUED — a new ally recorded ===
# Run as the player, POSITIONED at @s, from companions/handler/database/check_duplicates (the
# genuinely-new-species branch, #own_species matches 0 — fires once per never-before-catalogued species).
# A warm reveal chime + soft motes. Replaces the old un-gated entity.player.levelup cue.
# Ladder: ec.fx_vis/ec.fx_snd 0=Off · 1=Reduced · 2=Full · 3=Cracked.

# ── SOUND ── REDUCED (1): a single warm harp note.
execute if score @s ec.fx_snd matches 1 run playsound minecraft:block.note_block.harp master @s ~ ~ ~ 0.5 1.059
# FULL & up (2..): a warm rising harp triad (G·B·D') with a soft bell topper.
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.harp master @s ~ ~ ~ 0.5 1.059
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.harp master @s ~ ~ ~ 0.5 1.335
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.harp master @s ~ ~ ~ 0.45 1.587
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.4 1.587
# CRACKED (3..): a high chime shimmer topper.
execute if score @s ec.fx_snd matches 3.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.4 1.782

# ── VISUAL ── REDUCED (1): one soft warm-gold dust pop.
execute if score @s ec.fx_vis matches 1 run particle dust{color:[1.0,0.82,0.4],scale:0.8} ~ ~1 ~ 0.2 0.3 0.2 0 5
# FULL & up (2..): a warm dust burst + happy motes + a soft glow rise.
execute if score @s ec.fx_vis matches 2.. run particle dust{color:[1.0,0.82,0.4],scale:0.9} ~ ~1 ~ 0.3 0.4 0.3 0 12
execute if score @s ec.fx_vis matches 2.. run particle happy_villager ~ ~1 ~ 0.3 0.4 0.3 0 8
execute if score @s ec.fx_vis matches 2.. run particle glow ~ ~1.1 ~ 0.25 0.4 0.25 0.02 8
# CRACKED (3..): a warm flash + a rod rise + a gold→white dust transition, layered on the Full burst.
execute if score @s ec.fx_vis matches 3.. run particle flash{color:[1.0,0.85,0.45,1.0]} ~ ~1.1 ~
execute if score @s ec.fx_vis matches 3.. run particle end_rod ~ ~1 ~ 0.3 0.9 0.3 0.06 16
execute if score @s ec.fx_vis matches 3.. run particle dust_color_transition{from_color:[1.0,0.82,0.4],scale:1.6,to_color:[1.0,1.0,1.0]} ~ ~1.2 ~ 0.35 0.6 0.35 0.06 22
