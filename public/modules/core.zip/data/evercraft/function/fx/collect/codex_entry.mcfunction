# === FX · COLLECT: NEW CODEX ENTRY — an artifact recorded in the Codex ===
# Run as the player, POSITIONED at @s, from codex/grant_first_artifact (every artifact collected).
# An inscribing chime + page-glow motes. Channel-scaled only — the triggering artifact's tier is
# NOT readable here (the shared advancement reward passes no id; the item sits unidentified in inv).
# Ladder: ec.fx_vis/ec.fx_snd 0=Off · 1=Reduced · 2=Full · 3=Cracked.

# ── SOUND ── REDUCED (1): a single soft inscribing pling.
execute if score @s ec.fx_snd matches 1 run playsound minecraft:block.note_block.pling master @s ~ ~ ~ 0.5 1.189
# FULL & up (2..): an enchanting-table-style chime (G·B·D') over an amethyst resonate (recorded).
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.pling master @s ~ ~ ~ 0.5 1.059
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.pling master @s ~ ~ ~ 0.5 1.335
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.45 1.587
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.amethyst_block.resonate master @s ~ ~ ~ 0.4 1.4
# CRACKED (3..): a high amethyst shimmer topper.
execute if score @s ec.fx_snd matches 3.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.4 1.9

# ── VISUAL ── REDUCED (1): one soft page-glow pop.
execute if score @s ec.fx_vis matches 1 run particle enchant ~ ~1.2 ~ 0.2 0.3 0.2 0.3 5
# FULL & up (2..): an enchant-mote spiral + a gold page-glow rise + end_rod.
execute if score @s ec.fx_vis matches 2.. run particle enchant ~ ~1.3 ~ 0.3 0.5 0.3 0.5 14
execute if score @s ec.fx_vis matches 2.. run particle end_rod ~ ~1 ~ 0.25 0.5 0.25 0.04 12
execute if score @s ec.fx_vis matches 2.. run particle dust{color:[1.0,0.85,0.35],scale:0.8} ~ ~1 ~ 0.25 0.35 0.25 0 8
# CRACKED (3..): a gold flash + a glow rise + a few more motes, layered on the Full burst.
execute if score @s ec.fx_vis matches 3.. run particle flash{color:[1.0,0.85,0.35,1.0]} ~ ~1.1 ~
execute if score @s ec.fx_vis matches 3.. run particle end_rod ~ ~1 ~ 0.3 0.9 0.3 0.06 18
execute if score @s ec.fx_vis matches 3.. run particle glow ~ ~1.2 ~ 0.3 0.5 0.3 0.02 10
