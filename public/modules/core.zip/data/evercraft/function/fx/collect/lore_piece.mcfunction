# === FX · COLLECT: LORE FRAGMENT ADDED — the reveal of a recorded fragment ===
# Run as the player, POSITIONED at @s, from lore/collect/add_piece_{book,physical}.
# A soft ascending amethyst/chime motif + page-glow motes. Fires once per fragment.
# Ladder: ec.fx_vis/ec.fx_snd 0=Off · 1=Reduced · 2=Full · 3=Cracked.

# ── SOUND ── REDUCED (1): a single soft amethyst chime (the page settles).
execute if score @s ec.fx_snd matches 1 run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.5 1.189
# FULL & up (2..): an ascending amethyst/pling motif (C#·E·A) — fragment recorded.
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.5 0.749
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.chime master @s ~ ~ ~ 0.45 0.891
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.chime master @s ~ ~ ~ 0.45 1.189
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.amethyst_block.resonate master @s ~ ~ ~ 0.4 1.4
# CRACKED (3..): a high shimmer topper layered on the motif.
execute if score @s ec.fx_snd matches 3.. run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.4 1.782

# ── VISUAL ── REDUCED (1): one soft end_rod page-glow pop.
execute if score @s ec.fx_vis matches 1 run particle end_rod ~ ~1 ~ 0.2 0.3 0.2 0.02 4
# FULL & up (2..): a page-glow rise + enchant motes (the words being inscribed).
execute if score @s ec.fx_vis matches 2.. run particle end_rod ~ ~1 ~ 0.25 0.5 0.25 0.04 12
execute if score @s ec.fx_vis matches 2.. run particle enchant ~ ~1.3 ~ 0.25 0.4 0.25 0.4 10
execute if score @s ec.fx_vis matches 2.. run particle dust{color:[0.7,0.55,1.0],scale:0.8} ~ ~1 ~ 0.25 0.35 0.25 0 8
# CRACKED (3..): a small amethyst flash + a glow rise on top of the Full burst.
execute if score @s ec.fx_vis matches 3.. run particle flash{color:[0.72,0.55,1.0,1.0]} ~ ~1.1 ~
execute if score @s ec.fx_vis matches 3.. run particle end_rod ~ ~1 ~ 0.3 0.9 0.3 0.06 18
execute if score @s ec.fx_vis matches 3.. run particle glow ~ ~1.2 ~ 0.3 0.5 0.3 0.02 10
