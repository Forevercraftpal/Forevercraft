# === FX · COLLECT: LORE SET COMPLETE — a whole legend, reassembled ===
# Run as the player, POSITIONED at @s, from lore/collect/set_complete (the set actually completes).
# A fuller fanfare than a single fragment: flash + end_rod column + amethyst chime cascade.
# Ladder: ec.fx_vis/ec.fx_snd 0=Off · 1=Reduced · 2=Full · 3=Cracked.

# ── SOUND ── REDUCED (1): a single bright resolving chime.
execute if score @s ec.fx_snd matches 1 run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.6 1.335
# FULL & up (2..): a rising amethyst cascade (D·F#·A·D') resolving on a bell topper.
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.6 0.794
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.6 1.0
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.55 1.189
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.55 1.587
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.5 1.587
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.beacon.activate master @s ~ ~ ~ 0.35 1.4
# CRACKED (3..): a deep amethyst body + a high octave shimmer over the cascade.
execute if score @s ec.fx_snd matches 3.. run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 0.6 0.794
execute if score @s ec.fx_snd matches 3.. run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.45 2.0

# ── VISUAL ── REDUCED (1): one amethyst-tinted dust pop + a few rod motes.
execute if score @s ec.fx_vis matches 1 run particle dust{color:[0.7,0.55,1.0],scale:0.9} ~ ~1 ~ 0.3 0.4 0.3 0 8
execute if score @s ec.fx_vis matches 1 run particle end_rod ~ ~1 ~ 0.2 0.4 0.2 0.03 6
# FULL & up (2..): an end_rod column + enchant spiral + amethyst dust burst.
execute if score @s ec.fx_vis matches 2.. run particle end_rod ~ ~0.9 ~ 0.3 1.0 0.3 0.07 30
execute if score @s ec.fx_vis matches 2.. run particle enchant ~ ~1.4 ~ 0.3 0.5 0.3 0.5 16
execute if score @s ec.fx_vis matches 2.. run particle dust{color:[0.72,0.55,1.0],scale:1.0} ~ ~1 ~ 0.35 0.5 0.35 0 18
execute if score @s ec.fx_vis matches 2.. run particle glow ~ ~1.2 ~ 0.3 0.5 0.3 0.02 10
# CRACKED (3..): an amethyst flash + a taller column + an amethyst→white dust pillar.
execute if score @s ec.fx_vis matches 3.. run particle flash{color:[0.72,0.55,1.0,1.0]} ~ ~1.1 ~
execute if score @s ec.fx_vis matches 3.. run particle end_rod ~ ~1 ~ 0.3 1.6 0.3 0.09 36
execute if score @s ec.fx_vis matches 3.. run particle dust_color_transition{from_color:[0.6,0.4,0.95],scale:1.8,to_color:[1.0,1.0,1.0]} ~ ~1.4 ~ 0.4 1.0 0.4 0.08 30
execute if score @s ec.fx_vis matches 3.. run particle firework ~ ~1.2 ~ 0.4 0.6 0.4 0.05 14
