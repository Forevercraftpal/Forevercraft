# === FX · COLLECT: ARTISAN TOME FINALE — all 100 quests mastered ===
# Run as the player, POSITIONED at @s, from craftforever/spirit_tools/tome/finale (once-ever).
# An ethereal flute/chime fanfare + end_rod column + enchant spiral. Replaces the ungated
# ui.toast/levelup/ender_dragon.death/trident.thunder cues (PALETTE: no mob vocals).
# Ladder: ec.fx_vis/ec.fx_snd 0=Off · 1=Reduced · 2=Full · 3=Cracked.

# ── SOUND ── REDUCED (1): a single bright flute note.
execute if score @s ec.fx_snd matches 1 run playsound minecraft:block.note_block.flute master @s ~ ~ ~ 0.6 1.189
# FULL & up (2..): a rising ethereal flute fanfare (D·A·D') + amethyst chime + a beacon swell.
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.flute master @s ~ ~ ~ 0.6 0.794
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.flute master @s ~ ~ ~ 0.6 1.189
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.flute master @s ~ ~ ~ 0.55 1.587
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.55 1.0
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.5 1.587
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.beacon.activate master @s ~ ~ ~ 0.4 1.2
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.5 1.587
# CRACKED (3..): a deep bass body + a high octave shimmer over the fanfare.
execute if score @s ec.fx_snd matches 3.. run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 0.6 0.794
execute if score @s ec.fx_snd matches 3.. run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.45 2.0

# ── VISUAL ── REDUCED (1): one ethereal dust pop + a few rod motes.
execute if score @s ec.fx_vis matches 1 run particle dust{color:[0.6,0.95,0.8],scale:0.9} ~ ~1 ~ 0.3 0.4 0.3 0 8
execute if score @s ec.fx_vis matches 1 run particle end_rod ~ ~1 ~ 0.2 0.4 0.2 0.03 6
# FULL & up (2..): an end_rod column + enchant spiral + ethereal dust burst + glow.
execute if score @s ec.fx_vis matches 2.. run particle end_rod ~ ~0.9 ~ 0.35 1.0 0.35 0.07 32
execute if score @s ec.fx_vis matches 2.. run particle enchant ~ ~1.4 ~ 0.35 0.6 0.35 0.5 18
execute if score @s ec.fx_vis matches 2.. run particle dust{color:[0.6,0.95,0.8],scale:1.0} ~ ~1 ~ 0.4 0.5 0.4 0 18
execute if score @s ec.fx_vis matches 2.. run particle glow ~ ~1.2 ~ 0.35 0.5 0.35 0.02 12
# CRACKED (3..): a bright flash + a taller column + an ethereal→white pillar + a firework crown.
execute if score @s ec.fx_vis matches 3.. run particle flash{color:[0.7,1.0,0.85,1.0]} ~ ~1.1 ~
execute if score @s ec.fx_vis matches 3.. run particle end_rod ~ ~1 ~ 0.35 1.7 0.35 0.09 40
execute if score @s ec.fx_vis matches 3.. run particle dust_color_transition{from_color:[0.5,0.95,0.75],scale:1.9,to_color:[1.0,1.0,1.0]} ~ ~1.5 ~ 0.45 1.1 0.45 0.08 32
execute if score @s ec.fx_vis matches 3.. run particle firework ~ ~1.2 ~ 0.45 0.7 0.45 0.05 16
