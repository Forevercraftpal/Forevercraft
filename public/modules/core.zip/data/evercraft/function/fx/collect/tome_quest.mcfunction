# === FX · COLLECT: ARTISAN TOME QUEST COMPLETE — one step toward mastery ===
# Run as the player, POSITIONED at @s, from craftforever/spirit_tools/tome/complete (per quest 1-100).
# A LIGHT per-quest cue (this repeats up to 100×) — a soft pling/bell + a few page-glow motes.
# The grand once-ever payoff is fx/collect/tome_finale at quest 100.
# Ladder: ec.fx_vis/ec.fx_snd 0=Off · 1=Reduced · 2=Full · 3=Cracked.

# ── SOUND ── REDUCED (1): a single soft pling.
execute if score @s ec.fx_snd matches 1 run playsound minecraft:block.note_block.pling master @s ~ ~ ~ 0.4 1.189
# FULL & up (2..): a brief rising pling/bell (D'·F#'·A') — a quest closed.
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.pling master @s ~ ~ ~ 0.45 1.189
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.pling master @s ~ ~ ~ 0.4 1.498
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.4 1.782
# CRACKED (3..): a soft amethyst chime topper.
execute if score @s ec.fx_snd matches 3.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.35 1.587

# ── VISUAL ── REDUCED (1): one small page-glow pop.
execute if score @s ec.fx_vis matches 1 run particle end_rod ~ ~1 ~ 0.2 0.3 0.2 0.02 5
# FULL & up (2..): a small end_rod rise + a few enchant motes.
execute if score @s ec.fx_vis matches 2.. run particle end_rod ~ ~1 ~ 0.25 0.45 0.25 0.03 12
execute if score @s ec.fx_vis matches 2.. run particle enchant ~ ~1.2 ~ 0.25 0.4 0.25 0.4 8
# CRACKED (3..): a soft glow rise layered on the Full burst (no flash — this repeats).
execute if score @s ec.fx_vis matches 3.. run particle glow ~ ~1.1 ~ 0.25 0.4 0.25 0.02 8
