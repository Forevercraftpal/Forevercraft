# === FX · LUMBER CHOP — one log felled (Timberfall per-chop WIN) ===
# Run as the player, positioned at the log, from timberfall/resolve_block + spawn/resolve_disp.
# The CALLER keeps its own (now gated) wood-CHIP particle (wood-typed); this preset adds the
# gated woody SOUND + brown dust + a Cracked leaf-flutter. Chopping repeats fast → kept moderate.
# Ladder: 0=Off · 1=Reduced · 2=Full · 3=Cracked.

# ── SOUND ── woody break + a low didgeridoo "thunk"; Cracked adds a deep bass creak.
execute if score @s ec.fx_snd matches 1 run playsound minecraft:block.wood.break master @s ~ ~ ~ 0.5 0.9
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.wood.break master @s ~ ~ ~ 0.6 0.9
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.didgeridoo master @s ~ ~ ~ 0.4 0.6
execute if score @s ec.fx_snd matches 3.. run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 0.5 0.5

# ── VISUAL ── brown wood dust; Cracked adds drifting leaves + a chip flourish.
execute if score @s ec.fx_vis matches 1 run particle dust{color:[0.45,0.3,0.15],scale:0.7} ~ ~0.5 ~ 0.2 0.3 0.2 0 4
execute if score @s ec.fx_vis matches 2.. run particle dust{color:[0.45,0.3,0.15],scale:0.7} ~ ~0.6 ~ 0.25 0.35 0.25 0 8
execute if score @s ec.fx_vis matches 3.. run particle spore_blossom_air ~ ~1 ~ 0.35 0.4 0.35 0 8
execute if score @s ec.fx_vis matches 3.. run particle crit ~ ~0.6 ~ 0.25 0.3 0.25 0.05 8
