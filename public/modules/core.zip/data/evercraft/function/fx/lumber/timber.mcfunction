# === FX · LUMBER TIMBER — the jackpot: a whole tree comes down (Timberfall Timber proc) ===
# Run as the player, at the tree base, from timberfall/timber_fell + spawn/timber_fell.
# RARE (1–10%) + the big haul → this is the lumber CRACKED showcase. One-shot, opt-in scale.
# Ladder: 0=Off · 1=Reduced · 2=Full · 3=Cracked.

# ── SOUND ── a crashing topple: woody crack + a descending "TIMBER" drop; Cracked = ground impact.
execute if score @s ec.fx_snd matches 1 run playsound minecraft:block.wood.break master @s ~ ~ ~ 0.8 0.7
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.wood.break master @s ~ ~ ~ 1.0 0.7
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.didgeridoo master @s ~ ~ ~ 0.7 0.6
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.didgeridoo master @s ~ ~ ~ 0.7 0.45
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.wood.fall master @s ~ ~ ~ 0.9 0.8
execute if score @s ec.fx_snd matches 3.. run playsound minecraft:entity.generic.explode master @s ~ ~ ~ 0.7 0.5
execute if score @s ec.fx_snd matches 3.. run playsound minecraft:block.grass.break master @s ~ ~ ~ 0.9 0.8
execute if score @s ec.fx_snd matches 3.. run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 0.8 0.5

# ── VISUAL ── a tall topple column: wood chips + leaves over the trunk height, dust at the base.
execute if score @s ec.fx_vis matches 1 run particle minecraft:block{block_state:"minecraft:oak_log"} ~ ~1.5 ~ 0.3 1.0 0.3 0.1 10
execute if score @s ec.fx_vis matches 2.. run particle minecraft:block{block_state:"minecraft:oak_log"} ~ ~2 ~ 0.4 1.6 0.4 0.15 30
execute if score @s ec.fx_vis matches 2.. run particle dust{color:[0.45,0.3,0.15],scale:1.0} ~ ~1.5 ~ 0.5 1.4 0.5 0 24
execute if score @s ec.fx_vis matches 2.. run particle spore_blossom_air ~ ~2.5 ~ 0.6 1.2 0.6 0 24
execute if score @s ec.fx_vis matches 3.. run particle flash{color:[0.5,0.9,0.4,1.0]} ~ ~1.5 ~
execute if score @s ec.fx_vis matches 3.. run particle explosion ~ ~0.4 ~ 0.4 0.1 0.4 0 4
execute if score @s ec.fx_vis matches 3.. run particle dust_color_transition{from_color:[0.45,0.3,0.15],scale:2.0,to_color:[0.45,0.85,0.35]} ~ ~2 ~ 0.6 1.6 0.6 0.05 40
execute if score @s ec.fx_vis matches 3.. run particle spore_blossom_air ~ ~3 ~ 0.8 1.4 0.8 0 30
execute if score @s ec.fx_vis matches 3.. run particle end_rod ~ ~2 ~ 0.3 1.8 0.3 0.06 24
