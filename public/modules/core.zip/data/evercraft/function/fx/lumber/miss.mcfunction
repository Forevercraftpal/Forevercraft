# === FX · LUMBER MISS — a glancing swing (Timberfall fail; the log survives) ===
# Run as the player, at the log, from timberfall/resolve_miss. Light at every tier (a miss is "not yet").
# Ladder: 0=Off · 1=Reduced · 2=Full · 3=Cracked.
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.wood.hit master @s ~ ~ ~ 0.6 0.7
execute if score @s ec.fx_vis matches 1 run particle crit ~ ~0.5 ~ 0.2 0.25 0.2 0.02 3
execute if score @s ec.fx_vis matches 2.. run particle crit ~ ~0.5 ~ 0.25 0.3 0.25 0.02 5
execute if score @s ec.fx_vis matches 3.. run particle dust{color:[0.45,0.3,0.15],scale:0.6} ~ ~0.5 ~ 0.2 0.25 0.2 0 4
