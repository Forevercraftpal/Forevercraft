# === FX · CROP HARVEST — a mature crop was cut + auto-replanted ===
# Run as the player, at their position, from crop_harvest/on_break (gated on #rh_planted=1,
# i.e. a replant actually happened — not an empty hoe swing).
# Farming is RAPID, so this is deliberately the lightest preset — even Cracked stays modest
# (no flash/firework, which would be obnoxious swung across a whole field).
# Ladder: 0=Off · 1=Reduced · 2=Full · 3=Cracked.

# ── SOUND ── soft, wheat-warm banjo note(s); low volume since frequent.
execute if score @s ec.fx_snd matches 1 run playsound minecraft:block.note_block.banjo master @s ~ ~ ~ 0.3 0.891
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.banjo master @s ~ ~ ~ 0.4 0.891
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.banjo master @s ~ ~ ~ 0.4 1.059
execute if score @s ec.fx_snd matches 3.. run playsound minecraft:block.note_block.harp master @s ~ ~ ~ 0.35 1.335

# ── VISUAL ── a small green harvest pop. Cracked adds a brief spore lift + a few rods.
execute if score @s ec.fx_vis matches 1 run particle happy_villager ~ ~0.6 ~ 0.2 0.2 0.2 0 3
execute if score @s ec.fx_vis matches 2.. run particle dust{color:[0.55,0.85,0.3],scale:0.7} ~ ~0.6 ~ 0.25 0.3 0.25 0 8
execute if score @s ec.fx_vis matches 2.. run particle happy_villager ~ ~0.6 ~ 0.25 0.3 0.25 0 6
execute if score @s ec.fx_vis matches 3.. run particle spore_blossom_air ~ ~0.8 ~ 0.3 0.4 0.3 0 10
execute if score @s ec.fx_vis matches 3.. run particle end_rod ~ ~0.7 ~ 0.15 0.4 0.15 0.02 6
