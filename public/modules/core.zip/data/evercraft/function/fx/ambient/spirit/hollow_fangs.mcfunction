# === FX · AMBIENT — SPIRIT "Hollow Fangs" (held signature, 1s cadence) ===
# Run as+at the player by fx/ambient/player (already gated Full+ visual). Void-bone twin fangs:
# pale-violet motes with a bone-white fleck, a hollow whisper of soul-mist at the hip. Cracked deepens
# it with a faint soul drift + a rare low bone-chime (sound channel gated separately).
particle dust{color:[0.62,0.45,0.78],scale:0.6} ~ ~1.1 ~ 0.3 0.4 0.3 0 2
particle dust{color:[0.92,0.9,0.82],scale:0.4} ~ ~1.0 ~ 0.25 0.3 0.25 0 1
execute if score @s ec.fx_vis matches 3.. run particle soul ~ ~1.3 ~ 0.2 0.4 0.2 0.005 1
# Rare hollow bone-chime (Cracked sound only — soft, low).
execute if score @s ec.fx_snd matches 3.. if predicate evercraft:fx/ambient_chime run playsound minecraft:block.amethyst_block.hit master @s ~ ~ ~ 0.18 0.595
