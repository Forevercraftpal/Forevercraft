# === FX · AMBIENT — ACCESSORY "Temporal Hourglass" (held signature, 1s cadence) ===
# Run as+at the player by fx/ambient/player (already gated Full+ visual). Falling golden time-sand: a thin
# trickle of gold motes drifts downward over a slow clock shimmer. Cracked adds a faint enchant ring (time
# bending) + a rare ticking chime (sound gated separately).
particle dust{color:[0.95,0.78,0.3],scale:0.45} ~ ~1.4 ~ 0.12 0.0 0.12 0.02 2
particle dust{color:[1.0,0.88,0.45],scale:0.4} ~ ~1.0 ~ 0.18 0.25 0.18 0 1
execute if score @s ec.fx_vis matches 3.. run particle enchant ~ ~1.3 ~ 0.22 0.25 0.22 0.15 2
# Rare clock-tick chime (Cracked sound only).
execute if score @s ec.fx_snd matches 3.. if predicate evercraft:fx/ambient_chime run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.13 1.0
