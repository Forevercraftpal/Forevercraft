# === FX · AMBIENT — ACCESSORY "Ender Dragon Scale" (held signature, 1s cadence) ===
# Run as+at the player by fx/ambient/player (already gated Full+ visual). Violet dragon-scale glints catch
# the light over a curl of dragon-breath. Cracked adds a hovering portal mote + a rare deep wyrm resonance
# (sound gated separately).
particle dust{color:[0.55,0.2,0.7],scale:0.55} ~ ~1.2 ~ 0.3 0.4 0.3 0 2
particle dragon_breath ~ ~1.25 ~ 0.18 0.25 0.18 0.003 1
execute if score @s ec.fx_vis matches 3.. run particle portal ~ ~1.4 ~ 0.15 0.25 0.15 0.3 2
# Rare deep wyrm resonance (Cracked sound only).
execute if score @s ec.fx_snd matches 3.. if predicate evercraft:fx/ambient_chime run playsound minecraft:block.note_block.didgeridoo master @s ~ ~ ~ 0.15 0.5
