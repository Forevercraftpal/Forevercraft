# === FX · AMBIENT — Mythical (shared baseline, tier 6) ===
# Run as the player, at the player (Full+ visual, 1s cadence). A slow gold mote + (Cracked) a faint glyph.
# This is the FALLBACK for mythical artifacts that don't yet have an individual ambient signature.
particle dust{color:[1.0,0.65,0.15],scale:0.7} ~ ~1.2 ~ 0.35 0.45 0.35 0 2
execute if score @s ec.fx_vis matches 3.. run particle enchant ~ ~1.5 ~ 0.3 0.3 0.3 0.25 2
