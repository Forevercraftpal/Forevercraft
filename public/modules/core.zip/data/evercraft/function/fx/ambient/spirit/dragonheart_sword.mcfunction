# === FX · AMBIENT — SPIRIT "Dragonheart Sword" (held signature, 1s cadence) ===
# Run as+at the player by fx/ambient/player (already gated Full+ visual). Draconic fire: red-gold embers
# breathe off the edge with a curl of dragon-breath. Cracked adds a low gout of breath + a rare deep
# didgeridoo resonance (the slumbering wyrm; sound gated separately).
particle dust{color:[1.0,0.5,0.1],scale:0.6} ~ ~1.2 ~ 0.3 0.4 0.3 0 2
particle flame ~ ~1.1 ~ 0.2 0.3 0.2 0.005 1
execute if score @s ec.fx_vis matches 3.. run particle dragon_breath ~ ~1.3 ~ 0.15 0.25 0.15 0.004 1
# Rare deep wyrm resonance (Cracked sound only — the breathing dragon).
execute if score @s ec.fx_snd matches 3.. if predicate evercraft:fx/ambient_chime run playsound minecraft:block.note_block.didgeridoo master @s ~ ~ ~ 0.16 0.5
