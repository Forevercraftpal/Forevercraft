# === FX · AMBIENT — ACCESSORY "Phoenix Feather" (held signature, 1s cadence) ===
# Run as+at the player by fx/ambient/player (already gated Full+ visual). A smouldering phoenix plume:
# warm amber-red embers drift up like a feather catching fire without burning. Cracked adds a rising
# flame mote + a rare warm rebirth chime (sound gated separately).
particle dust{color:[1.0,0.55,0.18],scale:0.5} ~ ~1.3 ~ 0.22 0.3 0.22 0.02 2
particle dust{color:[1.0,0.78,0.3],scale:0.38} ~ ~1.2 ~ 0.18 0.25 0.18 0.01 1
execute if score @s ec.fx_vis matches 3.. run particle small_flame ~ ~1.4 ~ 0.12 0.25 0.12 0.012 2
# Rare warm rebirth chime (Cracked sound only).
execute if score @s ec.fx_snd matches 3.. if predicate evercraft:fx/ambient_chime run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.13 1.189
