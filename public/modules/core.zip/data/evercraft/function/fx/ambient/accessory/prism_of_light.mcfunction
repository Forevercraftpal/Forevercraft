# === FX · AMBIENT — ACCESSORY "Prism of Light" (held signature, 1s cadence) ===
# Run as+at the player by fx/ambient/player (already gated Full+ visual). Rainbow refractions: the prism
# splits light into shifting colour motes — three hues cast at once over a bright glint. Cracked adds a
# crystalline end-rod spark + a rare clear high chime (sound gated separately).
particle dust{color:[1.0,0.35,0.35],scale:0.42} ~ ~1.2 ~ 0.28 0.35 0.28 0 1
particle dust{color:[0.35,1.0,0.45],scale:0.42} ~ ~1.25 ~ 0.28 0.35 0.28 0 1
particle dust{color:[0.4,0.55,1.0],scale:0.42} ~ ~1.15 ~ 0.28 0.35 0.28 0 1
execute if score @s ec.fx_vis matches 3.. run particle end_rod ~ ~1.3 ~ 0.2 0.25 0.2 0.005 2
# Rare crystalline chime (Cracked sound only).
execute if score @s ec.fx_snd matches 3.. if predicate evercraft:fx/ambient_chime run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.14 1.587
