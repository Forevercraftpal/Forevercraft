# === FX · AMBIENT — accessory + tier scan (run as+at the player; Full+ visual only) ===
# Reached from fx/ambient/player ONLY when ec.has_amb matches 1.. (the player provably carries an
# ambient-eligible accessory/tier item — see fx/ambient/refresh_latch, recomputed every ~5s). A
# Full+ player carrying NOTHING tagged never reaches here, so the worst-case 25-scan-per-second
# cost is gone: empty players pay one cheap int-compare per second + the latch probe 1-in-5s.
# Held/worn only (not satchel-stored — that's a later refinement). One return run per signature,
# ordered mythical accessory → notable exquisite → notable ornate, falling through to the tier
# fallback when no named accessory is carried.
execute if items entity @s container.* *[custom_data~{artifact:"codex_of_everything"}] run return run function evercraft:fx/ambient/accessory/codex_of_everything
execute if items entity @s container.* *[custom_data~{artifact:"temporal_hourglass"}] run return run function evercraft:fx/ambient/accessory/temporal_hourglass
execute if items entity @s container.* *[custom_data~{artifact:"heart_of_the_void"}] run return run function evercraft:fx/ambient/accessory/heart_of_the_void
execute if items entity @s container.* *[custom_data~{artifact:"beacon_of_ancients"}] run return run function evercraft:fx/ambient/accessory/beacon_of_ancients
execute if items entity @s container.* *[custom_data~{artifact:"wither_rose_crown"}] run return run function evercraft:fx/ambient/accessory/wither_rose_crown
execute if items entity @s container.* *[custom_data~{artifact:"ender_dragon_scale"}] run return run function evercraft:fx/ambient/accessory/ender_dragon_scale
execute if items entity @s container.* *[custom_data~{artifact:"sculk_singularity"}] run return run function evercraft:fx/ambient/accessory/sculk_singularity
execute if items entity @s container.* *[custom_data~{artifact:"redstone_heart"}] run return run function evercraft:fx/ambient/accessory/redstone_heart
execute if items entity @s container.* *[custom_data~{artifact:"prism_of_light"}] run return run function evercraft:fx/ambient/accessory/prism_of_light
execute if items entity @s container.* *[custom_data~{artifact:"netherite_nexus"}] run return run function evercraft:fx/ambient/accessory/netherite_nexus
execute if items entity @s container.* *[custom_data~{artifact:"claudes_gift"}] run return run function evercraft:fx/ambient/accessory/claudes_gift
execute if items entity @s container.* *[custom_data~{artifact:"void_heart"}] run return run function evercraft:fx/ambient/accessory/void_heart
execute if items entity @s container.* *[custom_data~{artifact:"dragons_tear"}] run return run function evercraft:fx/ambient/accessory/dragons_tear
execute if items entity @s container.* *[custom_data~{artifact:"sculk_heart"}] run return run function evercraft:fx/ambient/accessory/sculk_heart
execute if items entity @s container.* *[custom_data~{artifact:"blaze_core"}] run return run function evercraft:fx/ambient/accessory/blaze_core
execute if items entity @s container.* *[custom_data~{artifact:"nether_star_shard"}] run return run function evercraft:fx/ambient/accessory/nether_star_shard
execute if items entity @s container.* *[custom_data~{artifact:"phoenix_feather"}] run return run function evercraft:fx/ambient/accessory/phoenix_feather
execute if items entity @s container.* *[custom_data~{artifact:"soul_lantern_fragment"}] run return run function evercraft:fx/ambient/accessory/soul_lantern_fragment
execute if items entity @s container.* *[custom_data~{artifact:"wind_chime"}] run return run function evercraft:fx/ambient/accessory/wind_chime
execute if items entity @s container.* *[custom_data~{tier:"mythical"}] run return run function evercraft:fx/ambient/tier_mythical
execute if items entity @s armor.* *[custom_data~{tier:"mythical"}] run return run function evercraft:fx/ambient/tier_mythical
execute if items entity @s container.* *[custom_data~{tier:"exquisite"}] run return run function evercraft:fx/ambient/tier_exquisite
execute if items entity @s armor.* *[custom_data~{tier:"exquisite"}] run return run function evercraft:fx/ambient/tier_exquisite
execute if items entity @s container.* *[custom_data~{tier:"ornate"}] run return run function evercraft:fx/ambient/tier_ornate
execute if items entity @s armor.* *[custom_data~{tier:"ornate"}] run return run function evercraft:fx/ambient/tier_ornate
