# === FX · AMBIENT — SPIRIT "Whispering Spear" (held signature, 1s cadence) ===
# Run as+at the player by fx/ambient/player (already gated Full+ visual). An ethereal wind-thrust: ghostly
# white-blue motes drift with a faint soul-wisp, like a held breath. Cracked adds a single soul flame +
# a rare whispering flute note (sound gated separately).
particle dust{color:[0.78,0.9,1.0],scale:0.55} ~ ~1.2 ~ 0.3 0.4 0.3 0 2
particle soul ~ ~1.1 ~ 0.2 0.3 0.2 0.004 1
execute if score @s ec.fx_vis matches 3.. run particle soul_fire_flame ~ ~1.3 ~ 0.15 0.25 0.15 0.003 1
# Rare whispering flute note (Cracked sound only).
execute if score @s ec.fx_snd matches 3.. if predicate evercraft:fx/ambient_chime run playsound minecraft:block.note_block.flute master @s ~ ~ ~ 0.15 1.122
