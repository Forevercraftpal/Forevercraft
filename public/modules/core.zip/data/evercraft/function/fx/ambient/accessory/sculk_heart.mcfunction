# === FX · AMBIENT — ACCESSORY "Sculk Heart" (held signature, 1s cadence) ===
# Run as+at the player by fx/ambient/player (already gated Full+ visual). A living sculk catalyst: steady
# teal-green motes drift out with a slow catalyst bloom (distinct from the mythical Singularity's inward
# pull — this one breathes outward). Cracked adds a sculk soul + a rare soft amethyst hit (sound gated).
particle dust{color:[0.15,0.65,0.55],scale:0.5} ~ ~1.2 ~ 0.28 0.35 0.28 0 2
particle dust{color:[0.25,0.8,0.65],scale:0.4} ~ ~1.25 ~ 0.18 0.25 0.18 0.0 1
execute if score @s ec.fx_vis matches 3.. run particle sculk_soul ~ ~1.3 ~ 0.18 0.25 0.18 0.0 1
# Rare soft sculk amethyst tone (Cracked sound only).
execute if score @s ec.fx_snd matches 3.. if predicate evercraft:fx/ambient_chime run playsound minecraft:block.amethyst_block.hit master @s ~ ~ ~ 0.14 0.794
