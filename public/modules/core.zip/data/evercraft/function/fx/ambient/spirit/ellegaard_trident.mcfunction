# === FX · AMBIENT — SPIRIT "Ellegaard's Trident" (held signature, 1s cadence) ===
# Run as+at the player by fx/ambient/player (already gated Full+ visual). The redstone engineer's craft:
# electric red-orange sparks flick off the prongs over a faint glow. Cracked adds a brighter arc-spark +
# a rare bright pling (sound gated separately).
particle electric_spark ~ ~1.2 ~ 0.25 0.35 0.25 0.2 2
particle dust{color:[1.0,0.35,0.15],scale:0.5} ~ ~1.1 ~ 0.25 0.3 0.25 0 2
execute if score @s ec.fx_vis matches 3.. run particle wax_off ~ ~1.3 ~ 0.2 0.25 0.2 0 1
# Rare bright workshop pling (Cracked sound only).
execute if score @s ec.fx_snd matches 3.. if predicate evercraft:fx/ambient_chime run playsound minecraft:block.note_block.pling master @s ~ ~ ~ 0.15 1.189
