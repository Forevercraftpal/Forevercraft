# === FX · AMBIENT — ACCESSORY "Void Heart" (held signature, 1s cadence) ===
# Run as+at the player by fx/ambient/player (already gated Full+ visual). An echo-shard pulse: deep
# indigo-teal motes ripple out with a faint sculk-echo wisp (distinct from the mythical Heart of the Void's
# purple). Cracked adds a sculk-charge pop + a rare hollow echo tone (sound gated separately).
particle dust{color:[0.18,0.3,0.45],scale:0.55} ~ ~1.2 ~ 0.28 0.35 0.28 0 2
particle dust{color:[0.25,0.5,0.55],scale:0.4} ~ ~1.25 ~ 0.18 0.25 0.18 0 1
execute if score @s ec.fx_vis matches 3.. run particle sculk_charge_pop ~ ~1.3 ~ 0.15 0.2 0.15 0.0 2
# Rare hollow echo tone (Cracked sound only).
execute if score @s ec.fx_snd matches 3.. if predicate evercraft:fx/ambient_chime run playsound minecraft:block.amethyst_block.resonate master @s ~ ~ ~ 0.14 0.5
