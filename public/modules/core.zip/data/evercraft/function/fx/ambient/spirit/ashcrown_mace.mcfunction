# === FX · AMBIENT — SPIRIT "Ashcrown Mace" (held signature, 1s cadence) ===
# Run as+at the player by fx/ambient/player (already gated Full+ visual). Smouldering regal ash: grey ash
# drifts off the head with a glint of crown-gold, the weight of a throne. Cracked adds a low ember +
# a rare deep iron-toll (sound gated separately).
particle ash ~ ~1.1 ~ 0.3 0.35 0.3 0.004 2
particle dust{color:[0.95,0.78,0.32],scale:0.5} ~ ~1.2 ~ 0.2 0.3 0.2 0 1
execute if score @s ec.fx_vis matches 3.. run particle dust{color:[0.45,0.42,0.4],scale:0.6} ~ ~1.0 ~ 0.25 0.2 0.25 0 2
# Rare deep iron-toll (Cracked sound only — heavy, regal).
execute if score @s ec.fx_snd matches 3.. if predicate evercraft:fx/ambient_chime run playsound minecraft:block.note_block.iron_xylophone master @s ~ ~ ~ 0.16 0.5
