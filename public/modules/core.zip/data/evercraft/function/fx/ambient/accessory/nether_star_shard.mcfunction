# === FX · AMBIENT — ACCESSORY "Nether Star Shard" (held signature, 1s cadence) ===
# Run as+at the player by fx/ambient/player (already gated Full+ visual). A shard of a fallen star: cold
# white-cyan motes twinkle with a faint enchant glimmer, distant and pure. Cracked adds a bright end-rod
# star-glint + a rare clear high bell (sound gated separately).
particle dust{color:[0.85,0.95,1.0],scale:0.45} ~ ~1.25 ~ 0.28 0.35 0.28 0 2
particle dust{color:[0.6,0.85,0.95],scale:0.35} ~ ~1.2 ~ 0.18 0.25 0.18 0 1
execute if score @s ec.fx_vis matches 3.. run particle end_rod ~ ~1.35 ~ 0.18 0.25 0.18 0.004 2
# Rare clear star bell (Cracked sound only).
execute if score @s ec.fx_snd matches 3.. if predicate evercraft:fx/ambient_chime run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.13 1.587
