# === FX · AMBIENT — SPIRIT TOOL "Silkgrasp" (Lamentor shears, held signature, 1s cadence) ===
# Run as+at the player by fx/ambient/player (already gated Full+ visual). The apex of the hive: warm gold
# motes with a drifting nectar fleck, honeyed light clinging to the blades. Cracked adds a glow spark +
# a rare bright iron-xylophone-pitched bell (sound gated separately).
particle dust{color:[1.0,0.78,0.25],scale:0.55} ~ ~1.2 ~ 0.25 0.35 0.25 0 2
particle falling_honey ~ ~1.3 ~ 0.2 0.2 0.2 0 1
execute if score @s ec.fx_vis matches 3.. run particle glow ~ ~1.1 ~ 0.2 0.3 0.2 0 1
# Rare bright honey-bell (Cracked sound only).
execute if score @s ec.fx_snd matches 3.. if predicate evercraft:fx/ambient_chime run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.13 1.414
