# === FX · AMBIENT — per-player dispatch (run as the player, at the player; Full+ visual only) ===
# Emit ONE ambient for the HIGHEST tier artifact the player carries (container.*) or wears (armor.*) —
# checking mythical → exquisite → ornate and returning on the first match, so a player laden with high-tier
# gear gets a single tasteful mote, never a stack of competing auras. Held/worn only (not satchel-stored —
# that's a later refinement). Individual signatures for notable items will pre-empt these in fx/ambient/player
# once authored (a per-artifact check that `return run`s its own preset before the tier fallback).
# === SPIRIT ARTIFACTS (apex) — individual held signatures, pre-empting the tier fallback ===
# ec.sp_weapon is the cached held-spirit ID (1..14, set in spirit/detect; reset to 0 in spirit/deactivate
# when unequipped → safe to gate on the score). One return run per weapon; falls through to the tier checks
# below when no spirit weapon is held (score 0).
execute if score @s ec.sp_weapon matches 1 run return run function evercraft:fx/ambient/spirit/hollow_fangs
execute if score @s ec.sp_weapon matches 2 run return run function evercraft:fx/ambient/spirit/voidpiercer
execute if score @s ec.sp_weapon matches 3 run return run function evercraft:fx/ambient/spirit/firebrand
execute if score @s ec.sp_weapon matches 4 run return run function evercraft:fx/ambient/spirit/zephyr_edge
execute if score @s ec.sp_weapon matches 5 run return run function evercraft:fx/ambient/spirit/nite
execute if score @s ec.sp_weapon matches 6 run return run function evercraft:fx/ambient/spirit/whispering_spear
execute if score @s ec.sp_weapon matches 7 run return run function evercraft:fx/ambient/spirit/ashcrown_mace
execute if score @s ec.sp_weapon matches 8 run return run function evercraft:fx/ambient/spirit/ellegaard_trident
execute if score @s ec.sp_weapon matches 9 run return run function evercraft:fx/ambient/spirit/pharaoh_fist
execute if score @s ec.sp_weapon matches 10 run return run function evercraft:fx/ambient/spirit/lifewoven_branch
execute if score @s ec.sp_weapon matches 11 run return run function evercraft:fx/ambient/spirit/sabrewing
execute if score @s ec.sp_weapon matches 12 run return run function evercraft:fx/ambient/spirit/dragonheart_sword
execute if score @s ec.sp_weapon matches 13 run return run function evercraft:fx/ambient/spirit/bulwark_shield
execute if score @s ec.sp_weapon matches 14 run return run function evercraft:fx/ambient/spirit/royal_trident
# === SPIRIT TOOLS (gathering apex) — individual held signatures, pre-empting the tier fallback ===
# ec.st_tool is the cached held-spirit-TOOL ID (1..6, set in craftforever/spirit_tools/activate; reset to 0
# in deactivate when switched away → safe to gate on the score). One return run per tool; falls through to
# the tier checks below when no spirit tool is held (score 0). 1=earthsong 2=bloomweaver 3=tidecaller
# 4=dustwalker 5=heartwood 6=silkgrasp (matches detect.mcfunction / try_mastery dispatch).
execute if score @s ec.st_tool matches 1 run return run function evercraft:fx/ambient/spirit_tool/earthsong
execute if score @s ec.st_tool matches 2 run return run function evercraft:fx/ambient/spirit_tool/bloomweaver
execute if score @s ec.st_tool matches 3 run return run function evercraft:fx/ambient/spirit_tool/tidecaller
execute if score @s ec.st_tool matches 4 run return run function evercraft:fx/ambient/spirit_tool/dustwalker
execute if score @s ec.st_tool matches 5 run return run function evercraft:fx/ambient/spirit_tool/heartwood
execute if score @s ec.st_tool matches 6 run return run function evercraft:fx/ambient/spirit_tool/silkgrasp
# === STANDALONE ACCESSORIES + TIER FALLBACK — gated behind the ec.has_amb skip-latch ===
# The ~25 `if items container.*`/`armor.*` accessory+tier scans are the single largest standing cost in
# fx/ — a Full+ player carrying NOTHING tagged used to run all 25 EVERY second. They now live in
# fx/ambient/scan_accessory and only run when ec.has_amb proves the player carries an ambient-eligible
# item. ec.has_amb is recomputed every ~5s by fx/ambient/refresh_latch (NOT a cross-system equip hook —
# self-contained inside fx/ so no scattered writer can leave it stale). Cadence counter ec.amb_tk
# (0..4) drives the refresh: unset/0 → refresh now (covers fresh login + the 1-in-5 slow recheck).
# Trade-off: a newly equipped accessory shows its aura within ~5s — fine for a subtle 1s ambient mote.
execute unless score @s ec.amb_tk = @s ec.amb_tk run scoreboard players set @s ec.amb_tk 0
execute if score @s ec.amb_tk matches 0 run function evercraft:fx/ambient/refresh_latch
scoreboard players add @s ec.amb_tk 1
execute if score @s ec.amb_tk matches 5.. run scoreboard players set @s ec.amb_tk 0
# Empty player (ec.has_amb 0/unset) stops here — one int-compare, no inventory scan. Laden player runs
# the FX scan (which short-circuits on the first match, same as before).
execute if score @s ec.has_amb matches 1.. run return run function evercraft:fx/ambient/scan_accessory
