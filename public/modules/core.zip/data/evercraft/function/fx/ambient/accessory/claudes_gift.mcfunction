# === FX · AMBIENT — ACCESSORY "Claude's Gift" (held signature, 1s cadence) ===
# Run as+at the player by fx/ambient/player (already gated Full+ visual). A warm, kind gift: gentle
# star-gold sparkles twinkle around the bearer like a held wish. Cracked adds a soft firework-spark glint +
# a rare warm welcoming chime (sound gated separately).
particle dust{color:[1.0,0.86,0.4],scale:0.45} ~ ~1.25 ~ 0.3 0.4 0.3 0 2
particle end_rod ~ ~1.3 ~ 0.2 0.3 0.2 0.002 1
execute if score @s ec.fx_vis matches 3.. run particle firework ~ ~1.4 ~ 0.18 0.25 0.18 0.01 2
# Rare warm welcoming chime (Cracked sound only).
execute if score @s ec.fx_snd matches 3.. if predicate evercraft:fx/ambient_chime run playsound minecraft:block.note_block.chime master @s ~ ~ ~ 0.14 1.335
