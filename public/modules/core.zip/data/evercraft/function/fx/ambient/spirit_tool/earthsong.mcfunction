# === FX · AMBIENT — SPIRIT TOOL "Earthsong" (Stonestrike pickaxe, held signature, 1s cadence) ===
# Run as+at the player by fx/ambient/player (already gated Full+ visual). The apex of mining: a faint
# aqua-diamond shimmer drifts off the head, a stray crystal glint catching the light. Cracked adds a tiny
# electric spark + a rare bright bell note (sound gated separately).
particle dust{color:[0.4,0.9,1.0],scale:0.55} ~ ~1.2 ~ 0.25 0.35 0.25 0 2
particle crit ~ ~1.1 ~ 0.2 0.3 0.2 0.02 1
execute if score @s ec.fx_vis matches 3.. run particle electric_spark ~ ~1.0 ~ 0.18 0.25 0.18 0 1
# Rare crystalline bell (Cracked sound only).
execute if score @s ec.fx_snd matches 3.. if predicate evercraft:fx/ambient_chime run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.13 1.189
