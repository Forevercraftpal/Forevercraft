# === FX · AMBIENT — ACCESSORY "Heart of the Void" (held signature, 1s cadence) ===
# Run as+at the player by fx/ambient/player (already gated Full+ visual). A dark heartbeat of the void:
# purple wisps pulse outward over a deep-violet shimmer. Cracked adds a thin reverse-portal pull + a rare
# hollow void resonance (sound gated separately).
particle dust{color:[0.32,0.08,0.45],scale:0.6} ~ ~1.2 ~ 0.3 0.4 0.3 0 2
particle witch ~ ~1.25 ~ 0.22 0.3 0.22 0.0 1
execute if score @s ec.fx_vis matches 3.. run particle reverse_portal ~ ~1.3 ~ 0.18 0.25 0.18 0.04 2
# Rare hollow void tone (Cracked sound only).
execute if score @s ec.fx_snd matches 3.. if predicate evercraft:fx/ambient_chime run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 0.16 0.5
