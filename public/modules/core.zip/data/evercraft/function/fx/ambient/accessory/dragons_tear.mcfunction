# === FX · AMBIENT — ACCESSORY "Dragon's Tear" (held signature, 1s cadence) ===
# Run as+at the player by fx/ambient/player (already gated Full+ visual). A crystallised dragon-tear: pale
# magenta-violet motes well up with a thin wisp of dragon-breath, sorrow given form. Cracked adds a falling
# tear drip + a rare clear crystalline tone (sound gated separately).
particle dust{color:[0.8,0.45,0.85],scale:0.5} ~ ~1.2 ~ 0.25 0.35 0.25 0 2
particle dragon_breath ~ ~1.25 ~ 0.15 0.2 0.15 0.002 1
execute if score @s ec.fx_vis matches 3.. run particle dripping_dripstone_water ~ ~1.4 ~ 0.18 0.15 0.18 0 1
# Rare clear crystalline tone (Cracked sound only).
execute if score @s ec.fx_snd matches 3.. if predicate evercraft:fx/ambient_chime run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.14 1.335
