# === FX · AMBIENT — Ornate (shared baseline, tier 4) ===
# Run as the player, at the player (Full+ visual, 1s cadence). A soft purple mote at the shoulder.
particle dust{color:[0.8,0.45,1.0],scale:0.6} ~ ~1.2 ~ 0.35 0.4 0.35 0 2
execute if score @s ec.fx_vis matches 3.. run particle dust{color:[0.8,0.45,1.0],scale:0.5} ~ ~1.5 ~ 0.3 0.3 0.3 0 2
