# === FX · AMBIENT — ACCESSORY "Wither Rose Crown" (held signature, 1s cadence) ===
# Run as+at the player by fx/ambient/player (already gated Full+ visual). Wilting black roses: dark petal
# motes shed off the crown with a grey wither wisp curling up. Cracked adds a drifting smoke + a rare
# low mournful tone (sound gated separately).
particle dust{color:[0.12,0.1,0.12],scale:0.55} ~ ~1.3 ~ 0.28 0.35 0.28 0 2
particle dust{color:[0.45,0.42,0.42],scale:0.45} ~ ~1.4 ~ 0.18 0.25 0.18 0.0 1
execute if score @s ec.fx_vis matches 3.. run particle smoke ~ ~1.5 ~ 0.15 0.25 0.15 0.005 1
# Rare low mournful tone (Cracked sound only).
execute if score @s ec.fx_snd matches 3.. if predicate evercraft:fx/ambient_chime run playsound minecraft:block.note_block.didgeridoo master @s ~ ~ ~ 0.14 0.595
