# === FX · AMBIENT — ACCESSORY "Redstone Heart" (held signature, 1s cadence) ===
# Run as+at the player by fx/ambient/player (already gated Full+ visual). A faint red heartbeat: a low pulse
# of crimson motes swells outward each second like a beating heart. Cracked adds a brighter inner throb +
# a rare deep heartbeat thud (sound gated separately).
particle dust{color:[0.85,0.12,0.12],scale:0.55} ~ ~1.15 ~ 0.3 0.35 0.3 0 2
particle dust{color:[1.0,0.25,0.2],scale:0.4} ~ ~1.15 ~ 0.15 0.2 0.15 0 1
execute if score @s ec.fx_vis matches 3.. run particle dust{color:[1.0,0.1,0.1],scale:0.9} ~ ~1.15 ~ 0.08 0.1 0.08 0 2
# Rare heartbeat thud (Cracked sound only).
execute if score @s ec.fx_snd matches 3.. if predicate evercraft:fx/ambient_chime run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 0.15 0.595
