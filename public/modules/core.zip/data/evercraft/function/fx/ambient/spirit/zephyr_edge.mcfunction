# === FX · AMBIENT — SPIRIT "Zephyr Edge" (held signature, 1s cadence) ===
# Run as+at the player by fx/ambient/player (already gated Full+ visual). Wind made edge: pale-cyan motes
# whirl with a faint gust curl, the blade always mid-breeze. Cracked adds a wider gust + a rare airy flute
# note (sound gated separately).
particle dust{color:[0.7,0.95,1.0],scale:0.55} ~ ~1.2 ~ 0.35 0.4 0.35 0 2
particle gust_emitter_small ~ ~1.0 ~ 0.1 0.1 0.1 0 1
execute if score @s ec.fx_vis matches 3.. run particle gust ~ ~1.3 ~ 0.25 0.3 0.25 0.02 1
# Rare airy flute note (Cracked sound only).
execute if score @s ec.fx_snd matches 3.. if predicate evercraft:fx/ambient_chime run playsound minecraft:block.note_block.flute master @s ~ ~ ~ 0.15 1.335
