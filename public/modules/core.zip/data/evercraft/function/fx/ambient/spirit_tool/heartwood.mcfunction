# === FX · AMBIENT — SPIRIT TOOL "Heartwood" (Lumberfell axe, held signature, 1s cadence) ===
# Run as+at the player by fx/ambient/player (already gated Full+ visual). The apex of lumber: living wood
# breathes — a brown bark mote with a green leaf shimmer, sawdust drifting off the bit. Cracked adds a
# happy spore + a rare warm wood-toned bell (sound gated separately).
particle dust{color:[0.5,0.32,0.16],scale:0.55} ~ ~1.2 ~ 0.25 0.35 0.25 0 2
particle dust{color:[0.4,0.75,0.3],scale:0.45} ~ ~1.3 ~ 0.2 0.3 0.2 0 1
execute if score @s ec.fx_vis matches 3.. run particle happy_villager ~ ~1.1 ~ 0.2 0.3 0.2 0 1
# Rare warm growth-bell (Cracked sound only).
execute if score @s ec.fx_snd matches 3.. if predicate evercraft:fx/ambient_chime run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.13 0.891
