# === FX · AMBIENT — ACCESSORY "Beacon of the Ancients" (held signature, 1s cadence) ===
# Run as+at the player by fx/ambient/player (already gated Full+ visual). A soft beacon-beam: cyan-white
# motes rise in a thin column over the bearer, a quiet pillar of ancient light. Cracked adds a brighter
# end-rod glint up top + a rare clear high bell (sound gated separately).
particle dust{color:[0.6,0.95,1.0],scale:0.45} ~ ~1.2 ~ 0.1 0.0 0.1 0.06 2
particle dust{color:[0.9,1.0,1.0],scale:0.4} ~ ~1.8 ~ 0.08 0.2 0.08 0.04 1
execute if score @s ec.fx_vis matches 3.. run particle end_rod ~ ~2.0 ~ 0.06 0.2 0.06 0.01 2
# Rare clear beacon bell (Cracked sound only).
execute if score @s ec.fx_snd matches 3.. if predicate evercraft:fx/ambient_chime run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.14 1.587
