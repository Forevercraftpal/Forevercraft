# === FX · AMBIENT — SPIRIT "Nite" (held signature, 1s cadence) ===
# Run as+at the player by fx/ambient/player (already gated Full+ visual). Shadow and night: deep-indigo
# motes with a wisp of dark smoke, a silent night-cut blade. Cracked adds a faint ash drift +
# a rare low night-tone (sound gated separately).
particle dust{color:[0.22,0.14,0.45],scale:0.6} ~ ~1.1 ~ 0.3 0.4 0.3 0 2
particle smoke ~ ~1.0 ~ 0.2 0.25 0.2 0.003 1
execute if score @s ec.fx_vis matches 3.. run particle ash ~ ~1.2 ~ 0.15 0.25 0.15 0.005 1
# Rare low night-tone (Cracked sound only).
execute if score @s ec.fx_snd matches 3.. if predicate evercraft:fx/ambient_chime run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 0.16 0.595
