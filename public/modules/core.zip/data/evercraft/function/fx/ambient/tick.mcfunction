# === FX · AMBIENT TICK — held/worn high-tier artifact ambient (the shared baseline) ===
# Self-schedules every 20t (1s) — subtle, low-frequency, pure flourish.
# Gated to players whose VISUAL channel is FULL+ (ec.fx_vis matches 2..): Reduced/Off players pay nothing
# AND see nothing (ambient is the first thing dropped to save frames). Per player it emits ONE tier-coloured
# mote for the highest-tier artifact carried/worn (see fx/ambient/player). Individual mythical/spirit/notable
# signatures (fx/ambient/individual) layer on top in later waves. Cheap: ~6 slot-predicate checks per Full+ player.
schedule function evercraft:fx/ambient/tick 20t replace

# Skip entirely if nobody is online.
execute unless entity @a run return 0

# Only Full+ visual players get ambient.
execute as @a[scores={ec.fx_vis=2..}] at @s run function evercraft:fx/ambient/player
