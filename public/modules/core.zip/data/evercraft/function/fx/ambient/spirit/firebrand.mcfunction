# === FX · AMBIENT — SPIRIT "Firebrand" (held signature, 1s cadence) ===
# Run as+at the player by fx/ambient/player (already gated Full+ visual). A searing flame brand: a couple
# of small flames lick off the blade with orange-red embers drifting up. Cracked adds a rising ember +
# a rare crackle-warm chime (sound gated separately).
particle flame ~ ~1.1 ~ 0.2 0.3 0.2 0.005 2
particle dust{color:[1.0,0.42,0.12],scale:0.55} ~ ~1.2 ~ 0.25 0.35 0.25 0 2
execute if score @s ec.fx_vis matches 3.. run particle lava ~ ~1.0 ~ 0.15 0.2 0.15 0 1
# Rare warm ember-chime (Cracked sound only).
execute if score @s ec.fx_snd matches 3.. if predicate evercraft:fx/ambient_chime run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.14 1.059
