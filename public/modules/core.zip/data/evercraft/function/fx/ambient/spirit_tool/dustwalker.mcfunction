# === FX · AMBIENT — SPIRIT TOOL "Dustwalker" (Terrawarp shovel, held signature, 1s cadence) ===
# Run as+at the player by fx/ambient/player (already gated Full+ visual). The apex of digging: fine tan
# sand sifts off the blade, a soft desert haze drifting down. Cracked adds a falling dust mote + a rare
# low mellow bell (sound gated separately).
particle dust{color:[0.82,0.72,0.5],scale:0.55} ~ ~1.1 ~ 0.25 0.3 0.25 0 2
particle dust{color:[0.76,0.64,0.42],scale:0.4} ~ ~1.3 ~ 0.2 0.35 0.2 0 1
execute if score @s ec.fx_vis matches 3.. run particle falling_dust{block_state:"minecraft:sand"} ~ ~1.4 ~ 0.18 0.1 0.18 0 1
# Rare mellow earth-bell (Cracked sound only).
execute if score @s ec.fx_snd matches 3.. if predicate evercraft:fx/ambient_chime run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.13 0.794
