# === FX · AMBIENT — ACCESSORY "Wind Chime" (held signature, 1s cadence) ===
# Run as+at the player by fx/ambient/player (already gated Full+ visual). A breeze-stirred chime: pale
# amethyst-white motes scatter on a gentle gust. Cracked adds a small gust swirl + a rare clear amethyst
# chime ringing on the wind (sound gated separately).
particle dust{color:[0.78,0.7,0.9],scale:0.45} ~ ~1.3 ~ 0.3 0.35 0.3 0.01 2
particle dust{color:[0.92,0.92,0.98],scale:0.35} ~ ~1.2 ~ 0.2 0.25 0.2 0 1
execute if score @s ec.fx_vis matches 3.. run particle gust ~ ~1.4 ~ 0.18 0.2 0.18 0.0 1
# Rare clear wind-chime ring (Cracked sound only).
execute if score @s ec.fx_snd matches 3.. if predicate evercraft:fx/ambient_chime run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.14 1.335
