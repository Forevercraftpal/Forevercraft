# === FX · AMBIENT — ACCESSORY "Soul Lantern Fragment" (held signature, 1s cadence) ===
# Run as+at the player by fx/ambient/player (already gated Full+ visual). A fragment of soul-light: cold
# soul-blue flame flickers with a thin wisp of soul-fire. Cracked adds a drifting soul wisp + a rare soft
# low flute tone (sound gated separately).
particle soul_fire_flame ~ ~1.25 ~ 0.15 0.25 0.15 0.004 1
particle dust{color:[0.3,0.7,0.85],scale:0.45} ~ ~1.2 ~ 0.22 0.3 0.22 0 2
execute if score @s ec.fx_vis matches 3.. run particle soul ~ ~1.3 ~ 0.15 0.25 0.15 0.01 2
# Rare soft soul tone (Cracked sound only).
execute if score @s ec.fx_snd matches 3.. if predicate evercraft:fx/ambient_chime run playsound minecraft:block.note_block.flute master @s ~ ~ ~ 0.13 0.794
