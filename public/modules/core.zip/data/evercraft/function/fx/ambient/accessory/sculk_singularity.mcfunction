# === FX · AMBIENT — ACCESSORY "Sculk Singularity" (held signature, 1s cadence) ===
# Run as+at the player by fx/ambient/player (already gated Full+ visual). Sculk-blue soul motes spiral
# INWARD toward the singularity (negative velocity pulls them home) over a faint catalyst glow. Cracked
# adds a sculk soul wisp + a rare resonant amethyst tone (sound gated separately).
particle dust{color:[0.1,0.55,0.6],scale:0.5} ~ ~1.5 ~ 0.4 0.45 0.4 0.0 2
particle dust{color:[0.2,0.75,0.8],scale:0.4} ~ ~1.2 ~ 0.25 0.3 0.25 0 1
execute if score @s ec.fx_vis matches 3.. run particle sculk_soul ~ ~1.4 ~ 0.2 0.25 0.2 0.0 2
# Rare resonant sculk tone (Cracked sound only).
execute if score @s ec.fx_snd matches 3.. if predicate evercraft:fx/ambient_chime run playsound minecraft:block.amethyst_block.resonate master @s ~ ~ ~ 0.15 0.595
