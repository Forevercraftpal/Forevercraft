# === FX · AMBIENT — SPIRIT TOOL "Bloomweaver" (Growseer hoe, held signature, 1s cadence) ===
# Run as+at the player by fx/ambient/player (already gated Full+ visual). The apex of farming: verdant
# growth blooms — green motes rising with a drifting cherry petal, life answering the gardener. Cracked
# adds a green growth pop + a rare gentle high bell (sound gated separately).
particle dust{color:[0.45,0.95,0.35],scale:0.55} ~ ~1.2 ~ 0.3 0.4 0.3 0 2
particle cherry_leaves ~ ~1.3 ~ 0.25 0.3 0.25 0 1
execute if score @s ec.fx_vis matches 3.. run particle happy_villager ~ ~1.1 ~ 0.2 0.3 0.2 0 1
# Rare gentle bloom-bell (Cracked sound only).
execute if score @s ec.fx_snd matches 3.. if predicate evercraft:fx/ambient_chime run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.13 1.335
