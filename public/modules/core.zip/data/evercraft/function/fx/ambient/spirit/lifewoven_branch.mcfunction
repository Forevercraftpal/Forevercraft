# === FX · AMBIENT — SPIRIT "Lifewoven Branch" (held signature, 1s cadence) ===
# Run as+at the player by fx/ambient/player (already gated Full+ visual). Verdant life: green motes and a
# drifting cherry petal, growth blooming off living wood. Cracked adds a happy spore + a rare gentle
# bell note (sound gated separately).
particle dust{color:[0.35,0.95,0.4],scale:0.55} ~ ~1.2 ~ 0.3 0.4 0.3 0 2
particle cherry_leaves ~ ~1.3 ~ 0.25 0.3 0.25 0 1
execute if score @s ec.fx_vis matches 3.. run particle happy_villager ~ ~1.1 ~ 0.2 0.3 0.2 0 1
# Rare gentle growth-bell (Cracked sound only).
execute if score @s ec.fx_snd matches 3.. if predicate evercraft:fx/ambient_chime run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.14 1.335
