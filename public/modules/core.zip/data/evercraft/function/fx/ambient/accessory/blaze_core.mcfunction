# === FX · AMBIENT — ACCESSORY "Blaze Core" (held signature, 1s cadence) ===
# Run as+at the player by fx/ambient/player (already gated Full+ visual). A molten blaze core: a couple of
# small flames lick around it with gold-orange embers rising. Cracked adds a curl of nether spark + a rare
# warm crackle tone (sound gated separately).
particle flame ~ ~1.15 ~ 0.18 0.25 0.18 0.004 2
particle dust{color:[1.0,0.6,0.12],scale:0.5} ~ ~1.2 ~ 0.22 0.3 0.22 0 2
execute if score @s ec.fx_vis matches 3.. run particle small_flame ~ ~1.3 ~ 0.15 0.25 0.15 0.01 2
# Rare warm crackle tone (Cracked sound only).
execute if score @s ec.fx_snd matches 3.. if predicate evercraft:fx/ambient_chime run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.13 1.059
