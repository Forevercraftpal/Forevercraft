# === FX · AMBIENT — has-ambient-accessory latch refresh (slow cadence, run as+at player) ===
# Recomputes ec.has_amb: 1 if the player carries ANY ambient-eligible accessory (one of the 19
# named signatures) OR any mythical/exquisite/ornate-tier item (held container.* or worn armor.*),
# else 0. This is the SAME ~25 `if items` scan set that fx/ambient/scan_accessory emits FX for —
# but here it only sets the latch, so fx/ambient/player can SKIP the per-second scan for players
# who carry nothing tagged (the worst-case standing cost: a Full+ player holding no signature item).
# Called once every ~5s from fx/ambient/player (ec.amb_tk == 0), NOT every second. Each branch
# `return run`s on the first match → a laden player short-circuits; an empty player runs all 25
# but only 1-in-5 seconds. Self-contained inside fx/ — no cross-system equip hook to keep in sync.
#
# Default to "carries nothing"; the checks below flip it to 1 and return on the first match.
scoreboard players set @s ec.has_amb 0
# Named accessory signatures (held anywhere in inventory).
execute if items entity @s container.* *[custom_data~{artifact:"codex_of_everything"}] run return run scoreboard players set @s ec.has_amb 1
execute if items entity @s container.* *[custom_data~{artifact:"temporal_hourglass"}] run return run scoreboard players set @s ec.has_amb 1
execute if items entity @s container.* *[custom_data~{artifact:"heart_of_the_void"}] run return run scoreboard players set @s ec.has_amb 1
execute if items entity @s container.* *[custom_data~{artifact:"beacon_of_ancients"}] run return run scoreboard players set @s ec.has_amb 1
execute if items entity @s container.* *[custom_data~{artifact:"wither_rose_crown"}] run return run scoreboard players set @s ec.has_amb 1
execute if items entity @s container.* *[custom_data~{artifact:"ender_dragon_scale"}] run return run scoreboard players set @s ec.has_amb 1
execute if items entity @s container.* *[custom_data~{artifact:"sculk_singularity"}] run return run scoreboard players set @s ec.has_amb 1
execute if items entity @s container.* *[custom_data~{artifact:"redstone_heart"}] run return run scoreboard players set @s ec.has_amb 1
execute if items entity @s container.* *[custom_data~{artifact:"prism_of_light"}] run return run scoreboard players set @s ec.has_amb 1
execute if items entity @s container.* *[custom_data~{artifact:"netherite_nexus"}] run return run scoreboard players set @s ec.has_amb 1
execute if items entity @s container.* *[custom_data~{artifact:"claudes_gift"}] run return run scoreboard players set @s ec.has_amb 1
execute if items entity @s container.* *[custom_data~{artifact:"void_heart"}] run return run scoreboard players set @s ec.has_amb 1
execute if items entity @s container.* *[custom_data~{artifact:"dragons_tear"}] run return run scoreboard players set @s ec.has_amb 1
execute if items entity @s container.* *[custom_data~{artifact:"sculk_heart"}] run return run scoreboard players set @s ec.has_amb 1
execute if items entity @s container.* *[custom_data~{artifact:"blaze_core"}] run return run scoreboard players set @s ec.has_amb 1
execute if items entity @s container.* *[custom_data~{artifact:"nether_star_shard"}] run return run scoreboard players set @s ec.has_amb 1
execute if items entity @s container.* *[custom_data~{artifact:"phoenix_feather"}] run return run scoreboard players set @s ec.has_amb 1
execute if items entity @s container.* *[custom_data~{artifact:"soul_lantern_fragment"}] run return run scoreboard players set @s ec.has_amb 1
execute if items entity @s container.* *[custom_data~{artifact:"wind_chime"}] run return run scoreboard players set @s ec.has_amb 1
# Tier fallbacks (held OR worn).
execute if items entity @s container.* *[custom_data~{tier:"mythical"}] run return run scoreboard players set @s ec.has_amb 1
execute if items entity @s armor.* *[custom_data~{tier:"mythical"}] run return run scoreboard players set @s ec.has_amb 1
execute if items entity @s container.* *[custom_data~{tier:"exquisite"}] run return run scoreboard players set @s ec.has_amb 1
execute if items entity @s armor.* *[custom_data~{tier:"exquisite"}] run return run scoreboard players set @s ec.has_amb 1
execute if items entity @s container.* *[custom_data~{tier:"ornate"}] run return run scoreboard players set @s ec.has_amb 1
execute if items entity @s armor.* *[custom_data~{tier:"ornate"}] run return run scoreboard players set @s ec.has_amb 1
