# === FX · AMBIENT — SPIRIT "Pharaoh's Fist" (held signature, 1s cadence) ===
# Run as+at the player by fx/ambient/player (already gated Full+ visual). Egyptian sand & gold: fine desert
# dust sifts down with a sun-gold glint, the gauntlet of a god-king. Cracked adds a golden wax glint +
# a rare warm harp note (sound gated separately).
particle dust{color:[0.85,0.72,0.4],scale:0.55} ~ ~1.1 ~ 0.3 0.35 0.3 0 2
particle dust{color:[1.0,0.85,0.25],scale:0.45} ~ ~1.2 ~ 0.2 0.3 0.2 0 1
execute if score @s ec.fx_vis matches 3.. run particle wax_on ~ ~1.0 ~ 0.2 0.2 0.2 0 1
# Rare warm harp note (Cracked sound only).
execute if score @s ec.fx_snd matches 3.. if predicate evercraft:fx/ambient_chime run playsound minecraft:block.note_block.harp master @s ~ ~ ~ 0.15 1.189
