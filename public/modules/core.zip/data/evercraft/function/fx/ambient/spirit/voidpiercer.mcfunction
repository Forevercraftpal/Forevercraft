# === FX · AMBIENT — SPIRIT "Voidpiercer" (held signature, 1s cadence) ===
# Run as+at the player by fx/ambient/player (already gated Full+ visual). End-void rifts: a deep-purple
# portal shimmer with a thin tear of reverse-portal pulling inward. Cracked adds a hovering void mote +
# a rare hollow end-tone (sound gated separately).
particle dust{color:[0.42,0.12,0.62],scale:0.6} ~ ~1.1 ~ 0.3 0.4 0.3 0 2
particle reverse_portal ~ ~1.2 ~ 0.2 0.3 0.2 0.04 1
execute if score @s ec.fx_vis matches 3.. run particle portal ~ ~1.4 ~ 0.15 0.3 0.15 0.5 1
# Rare void end-tone (Cracked sound only).
execute if score @s ec.fx_snd matches 3.. if predicate evercraft:fx/ambient_chime run playsound minecraft:block.amethyst_block.resonate master @s ~ ~ ~ 0.16 0.5
