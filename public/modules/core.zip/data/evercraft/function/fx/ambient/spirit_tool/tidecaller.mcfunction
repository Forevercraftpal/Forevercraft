# === FX · AMBIENT — SPIRIT TOOL "Tidecaller" (Sirencall rod, held signature, 1s cadence) ===
# Run as+at the player by fx/ambient/player (already gated Full+ visual). The apex of fishing: a cool
# blue water-shimmer with a stray bubble rising, the tide answering the line. Cracked adds a drip splash
# + a rare clear flute-pitched bell (sound gated separately).
particle dust{color:[0.35,0.7,1.0],scale:0.55} ~ ~1.2 ~ 0.25 0.35 0.25 0 2
particle bubble ~ ~1.3 ~ 0.2 0.3 0.2 0 1
execute if score @s ec.fx_vis matches 3.. run particle dripping_water ~ ~1.4 ~ 0.18 0.1 0.18 0 1
# Rare clear tide-bell (Cracked sound only).
execute if score @s ec.fx_snd matches 3.. if predicate evercraft:fx/ambient_chime run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.13 0.794
