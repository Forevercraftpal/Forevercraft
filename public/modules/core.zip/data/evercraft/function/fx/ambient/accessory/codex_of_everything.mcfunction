# === FX · AMBIENT — ACCESSORY "Codex of Everything" (held signature, 1s cadence) ===
# Run as+at the player by fx/ambient/player (already gated Full+ visual). An arcane tome: aqua-gold rune
# glyphs drift off the open book, ancient knowledge breathing. Cracked adds a hovering enchant glyph +
# a rare soft page-turn bell (sound gated separately).
particle dust{color:[0.35,0.85,0.95],scale:0.5} ~ ~1.2 ~ 0.28 0.4 0.28 0 2
particle dust{color:[1.0,0.82,0.3],scale:0.4} ~ ~1.15 ~ 0.2 0.3 0.2 0 1
execute if score @s ec.fx_vis matches 3.. run particle enchant ~ ~1.5 ~ 0.25 0.3 0.25 0.3 2
# Rare arcane chime (Cracked sound only).
execute if score @s ec.fx_snd matches 3.. if predicate evercraft:fx/ambient_chime run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.14 1.587
