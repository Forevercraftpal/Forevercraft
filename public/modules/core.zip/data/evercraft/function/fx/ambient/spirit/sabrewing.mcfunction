# === FX · AMBIENT — SPIRIT "Sabrewing" (held signature, 1s cadence) ===
# Run as+at the player by fx/ambient/player (already gated Full+ visual). A feathered blade: white and
# sky-blue motes lift like loosed down on a swift current. Cracked adds a rising end-rod feather +
# a rare high airy note (sound gated separately).
particle dust{color:[0.95,0.97,1.0],scale:0.55} ~ ~1.2 ~ 0.3 0.4 0.3 0 2
particle dust{color:[0.55,0.78,1.0],scale:0.5} ~ ~1.1 ~ 0.25 0.3 0.25 0 1
execute if score @s ec.fx_vis matches 3.. run particle end_rod ~ ~1.3 ~ 0.15 0.3 0.15 0.01 1
# Rare high airy note (Cracked sound only).
execute if score @s ec.fx_snd matches 3.. if predicate evercraft:fx/ambient_chime run playsound minecraft:block.note_block.flute master @s ~ ~ ~ 0.14 1.587
