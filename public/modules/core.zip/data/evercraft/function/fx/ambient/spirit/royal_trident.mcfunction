# === FX · AMBIENT — SPIRIT "Royal Trident" (held signature, 1s cadence) ===
# Run as+at the player by fx/ambient/player (already gated Full+ visual). Regal tidal sea: aqua motes
# fall like spray with a crown-gold glint, the calm before the wave. Cracked adds a drip of falling water +
# a rare clear bell over the tide (sound gated separately).
particle dust{color:[0.3,0.75,0.95],scale:0.55} ~ ~1.2 ~ 0.3 0.4 0.3 0 2
particle dust{color:[1.0,0.85,0.35],scale:0.45} ~ ~1.1 ~ 0.2 0.3 0.2 0 1
execute if score @s ec.fx_vis matches 3.. run particle dripping_water ~ ~1.4 ~ 0.25 0.2 0.25 0 1
# Rare clear tide-bell (Cracked sound only).
execute if score @s ec.fx_snd matches 3.. if predicate evercraft:fx/ambient_chime run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.15 1.122
