# === FX · AMBIENT — Exquisite (shared baseline, tier 5) ===
# Run as the player, at the player (Full+ visual, 1s cadence). A soft magenta mote, a touch brighter than ornate.
particle dust{color:[1.0,0.4,0.85],scale:0.65} ~ ~1.2 ~ 0.35 0.4 0.35 0 2
execute if score @s ec.fx_vis matches 3.. run particle dust{color:[1.0,0.5,0.9],scale:0.55} ~ ~1.5 ~ 0.3 0.35 0.3 0 3
