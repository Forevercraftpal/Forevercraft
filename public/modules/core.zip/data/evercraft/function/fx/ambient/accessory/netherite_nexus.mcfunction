# === FX · AMBIENT — ACCESSORY "Netherite Nexus" (held signature, 1s cadence) ===
# Run as+at the player by fx/ambient/player (already gated Full+ visual). Dark iron sheen: cold metallic
# motes with a faint smouldering ember from the netherite core. Cracked adds a small lick of flame + a rare
# low metallic resonance (sound gated separately).
particle dust{color:[0.28,0.26,0.3],scale:0.55} ~ ~1.2 ~ 0.28 0.35 0.28 0 2
particle dust{color:[0.85,0.4,0.12],scale:0.35} ~ ~1.1 ~ 0.15 0.2 0.15 0 1
execute if score @s ec.fx_vis matches 3.. run particle flame ~ ~1.05 ~ 0.12 0.15 0.12 0.003 1
# Rare low metallic resonance (Cracked sound only).
execute if score @s ec.fx_snd matches 3.. if predicate evercraft:fx/ambient_chime run playsound minecraft:block.amethyst_block.hit master @s ~ ~ ~ 0.15 0.595
