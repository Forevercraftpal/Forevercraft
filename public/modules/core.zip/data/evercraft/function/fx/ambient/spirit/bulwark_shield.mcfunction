# === FX · AMBIENT — SPIRIT "Bulwark Shield" (held signature, 1s cadence) ===
# Run as+at the player by fx/ambient/player (already gated Full+ visual). The aegis guard: steel-blue
# motes ring the bearer with a glint of ward-gold, a standing bulwark. Cracked adds a faint enchant ward +
# a rare low steel-toll (sound gated separately).
particle dust{color:[0.4,0.55,0.8],scale:0.6} ~ ~1.1 ~ 0.35 0.35 0.35 0 2
particle dust{color:[1.0,0.85,0.4],scale:0.45} ~ ~1.2 ~ 0.2 0.25 0.2 0 1
execute if score @s ec.fx_vis matches 3.. run particle enchant ~ ~1.4 ~ 0.3 0.2 0.3 0.15 2
# Rare low steel ward-toll (Cracked sound only).
execute if score @s ec.fx_snd matches 3.. if predicate evercraft:fx/ambient_chime run playsound minecraft:block.note_block.iron_xylophone master @s ~ ~ ~ 0.16 0.595
