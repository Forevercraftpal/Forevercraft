# Sleep Skip — fires when native 26.1 sleep advances clock to dawn
# Called from luck_buffs/tick when night→new day transition detected

# Recompute all time scores after the skip
execute store result score #visual_time ec.var run time query minecraft:day
execute store result score #visual_day ec.var run time query minecraft:day repetition
scoreboard players operation #moon_phase ec.var = #visual_day ec.var
scoreboard players operation #moon_phase ec.var %= #8 ec.const

# Flag that dawn was reached via sleep (prevents Full Moon Madness achievement)
scoreboard players set #slept_through_night ec.var 1

# Clear weather on sleep
weather clear

# Smooth transition effects
effect give @a blindness 3 0 true

# Notify players
data modify storage evercraft:notify stage.c set value [{text:"\u2600 ",color:"yellow"},{text:"The night fades as dawn arrives...",color:"yellow",italic:true},{text:" \u2600",color:"yellow"}]
scoreboard players set #ndur ec.temp 45
execute as @a[gamemode=!spectator,tag=!dr.in_realm] run function evercraft:util/notify/emit
playsound minecraft:block.amethyst_block.chime master @a[gamemode=!spectator,tag=!dr.in_realm,scores={ec.fx_snd=1..}] ~ ~ ~ 0.5 1.2

# Buddy system: +2 friendship for sleeping with buddy nearby
function evercraft:buddy/points/sleeping

# Prevent re-triggering (prev_visual_day is updated by luck_buffs/tick next second)
