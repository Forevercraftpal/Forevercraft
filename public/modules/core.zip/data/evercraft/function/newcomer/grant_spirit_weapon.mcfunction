# Newcomer: Grant chosen spirit weapon based on ec.newcomer_pick trigger value
# @s = player who picked, ec.newcomer_pick = spirit weapon ID (1-14, excluding DS)
#
# Wiring Audit #13 P1-D: idempotency gate at top + reset-after-success.
# Was: tag + reset fired unconditionally even when player already chose, allowing
# `/trigger ec.newcomer_pick <N>` to double-claim. Now: top-gate on ec.spirit_chosen
# returns early; reset happens only after loot give succeeds.

# 1. Idempotency guard — already chosen, refuse silently.
data modify storage evercraft:notify stage.c set value [{text:"You have already claimed your spirit weapon.",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute if entity @s[tag=ec.spirit_chosen] run return run function evercraft:util/notify/emit

# 2. Validate trigger range.
data modify storage evercraft:notify stage.c set value [{text:"Invalid spirit choice.",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute unless score @s ec.newcomer_pick matches 1..14 run return run function evercraft:util/notify/emit

# 3. Success-gated loot give. `loot give` returns success=1 when at least one item placed
# (drops to ground if inventory full — still counts as placed). Track via #grant_ok.
scoreboard players set #grant_ok ec.temp 0
# Inv-full guard: drop at the player's feet rather than void on a full inventory.
execute store result score #inv_full ec.var run function evercraft:util/check_inv_full
execute store success score #grant_ok ec.temp if score @s ec.newcomer_pick matches 1 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:spirit/hollow_fangs
execute store success score #grant_ok ec.temp if score @s ec.newcomer_pick matches 1 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:spirit/hollow_fangs
execute store success score #grant_ok ec.temp if score @s ec.newcomer_pick matches 2 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:spirit/voidpiercer
execute store success score #grant_ok ec.temp if score @s ec.newcomer_pick matches 2 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:spirit/voidpiercer
execute store success score #grant_ok ec.temp if score @s ec.newcomer_pick matches 3 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:spirit/firebrand
execute store success score #grant_ok ec.temp if score @s ec.newcomer_pick matches 3 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:spirit/firebrand
execute store success score #grant_ok ec.temp if score @s ec.newcomer_pick matches 4 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:spirit/zephyr_edge
execute store success score #grant_ok ec.temp if score @s ec.newcomer_pick matches 4 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:spirit/zephyr_edge
execute store success score #grant_ok ec.temp if score @s ec.newcomer_pick matches 5 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:spirit/nite
execute store success score #grant_ok ec.temp if score @s ec.newcomer_pick matches 5 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:spirit/nite
execute store success score #grant_ok ec.temp if score @s ec.newcomer_pick matches 6 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:spirit/whispering_spear
execute store success score #grant_ok ec.temp if score @s ec.newcomer_pick matches 6 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:spirit/whispering_spear
execute store success score #grant_ok ec.temp if score @s ec.newcomer_pick matches 7 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:spirit/ashcrown_mace
execute store success score #grant_ok ec.temp if score @s ec.newcomer_pick matches 7 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:spirit/ashcrown_mace
execute store success score #grant_ok ec.temp if score @s ec.newcomer_pick matches 8 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:spirit/ellegaard_trident
execute store success score #grant_ok ec.temp if score @s ec.newcomer_pick matches 8 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:spirit/ellegaard_trident
execute store success score #grant_ok ec.temp if score @s ec.newcomer_pick matches 9 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:spirit/pharaoh_fist
execute store success score #grant_ok ec.temp if score @s ec.newcomer_pick matches 9 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:spirit/pharaoh_fist
execute store success score #grant_ok ec.temp if score @s ec.newcomer_pick matches 10 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:spirit/lifewoven_branch
execute store success score #grant_ok ec.temp if score @s ec.newcomer_pick matches 10 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:spirit/lifewoven_branch
execute store success score #grant_ok ec.temp if score @s ec.newcomer_pick matches 11 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:spirit/sabrewing
execute store success score #grant_ok ec.temp if score @s ec.newcomer_pick matches 11 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:spirit/sabrewing
execute store success score #grant_ok ec.temp if score @s ec.newcomer_pick matches 12 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:spirit/dragonheart_sword
execute store success score #grant_ok ec.temp if score @s ec.newcomer_pick matches 12 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:spirit/dragonheart_sword
execute store success score #grant_ok ec.temp if score @s ec.newcomer_pick matches 13 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:spirit/bulwark_shield
execute store success score #grant_ok ec.temp if score @s ec.newcomer_pick matches 13 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:spirit/bulwark_shield
execute store success score #grant_ok ec.temp if score @s ec.newcomer_pick matches 14 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:spirit/royal_trident
execute store success score #grant_ok ec.temp if score @s ec.newcomer_pick matches 14 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:spirit/royal_trident

# 4. Mark as claimed + reset trigger ONLY on success.
execute if score #grant_ok ec.temp matches 1 run tag @s add ec.spirit_chosen
execute if score #grant_ok ec.temp matches 1 run scoreboard players set @s ec.newcomer_pick 0
execute if score #grant_ok ec.temp matches 1 run scoreboard players enable @s ec.newcomer_pick

# 5. Success feedback.
execute if score #grant_ok ec.temp matches 1 if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.warden.emerge master @s ~ ~ ~ 0.6 1.5
execute if score #grant_ok ec.temp matches 1 if score @s ec.fx_snd matches 1.. run playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 0.5 1.0
execute if score #grant_ok ec.temp matches 1 at @s run particle totem_of_undying ~ ~1 ~ 0.5 0.5 0.5 0.15 15
data modify storage evercraft:notify stage.c set value [{text:"Your spirit weapon has been bestowed! Equip it to begin your journey.",color:"green"}]
scoreboard players set #ndur ec.temp 45
execute if score #grant_ok ec.temp matches 1 run function evercraft:util/notify/emit

# Wiring Audit #14 W1.2: bootstrap the Spirit Tome 100-quest companion (`give` is idempotent — top-gate on `ec.sq_has_tome matches 1..` returns fail).
execute if score #grant_ok ec.temp matches 1 run function evercraft:spirit_tome/give

# 6. Failure path — warn player to make space and re-trigger (ec.newcomer_pick stays armed).
data modify storage evercraft:notify stage.c set value [{text:"Could not deliver your spirit weapon — make inventory space and pick again.",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute if score #grant_ok ec.temp matches 0 run function evercraft:util/notify/emit
