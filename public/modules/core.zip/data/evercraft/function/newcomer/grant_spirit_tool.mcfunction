# Newcomer: Grant chosen spirit tool based on ec.newcomer_pick trigger value
# @s = player who picked, ec.newcomer_pick = spirit tool path ID (15-20)

# Map trigger value to spirit tool loot table
# Inv-full guard: drop at the player's feet rather than void on a full inventory.
execute store result score #inv_full ec.var run function evercraft:util/check_inv_full
execute if score @s ec.newcomer_pick matches 15 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:spirit_tool/earthsong
execute if score @s ec.newcomer_pick matches 15 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:spirit_tool/earthsong
execute if score @s ec.newcomer_pick matches 16 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:spirit_tool/bloomweaver
execute if score @s ec.newcomer_pick matches 16 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:spirit_tool/bloomweaver
execute if score @s ec.newcomer_pick matches 17 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:spirit_tool/dustwalker
execute if score @s ec.newcomer_pick matches 17 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:spirit_tool/dustwalker
execute if score @s ec.newcomer_pick matches 18 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:spirit_tool/heartwood
execute if score @s ec.newcomer_pick matches 18 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:spirit_tool/heartwood
execute if score @s ec.newcomer_pick matches 19 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:spirit_tool/tidecaller
execute if score @s ec.newcomer_pick matches 19 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:spirit_tool/tidecaller
execute if score @s ec.newcomer_pick matches 20 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:spirit_tool/silkgrasp
execute if score @s ec.newcomer_pick matches 20 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:spirit_tool/silkgrasp

# Mark as claimed so the menu doesn't show again
tag @s add ec.spirit_chosen

# Reset trigger
scoreboard players set @s ec.newcomer_pick 0
scoreboard players enable @s ec.newcomer_pick

# Effects
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.warden.emerge master @s ~ ~ ~ 0.6 1.5
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 0.5 1.0
particle totem_of_undying ~ ~1 ~ 0.5 0.5 0.5 0.15 15

data modify storage evercraft:notify stage.c set value [{text:"Your spirit tool has been bestowed! Equip it to begin your journey.",color:"green"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
