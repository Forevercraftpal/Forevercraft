# Pioneer — Post-respawn choice prompt (Joseph 2026-06-13 fix for #92)
# Joseph reported that the path-choice tellraw + save-one prompt at the tail of
# pioneer_death weren't reaching him. Likely cause: the original tellraws are
# fired the moment deathCount ticks, while the player is still on the vanilla
# "you died" screen — some clients drop chat history across that transition,
# so messages emitted in that ~1s window can be silently lost.
#
# This function is SCHEDULED 30t (~1.5s) after pioneer_death, so by the time
# it runs the player has respawned, chat is live, and the tellraws land in a
# normal chat session that can be scrolled. It re-emits BOTH the path-choice
# row and the save-one pick row for every player still tagged pioneer.choosing
# (i.e. anyone who hasn't already committed to a path). The original inline
# tellraws stay in pioneer_death as a best-effort fast-path — this is the
# guaranteed delivery.

# Per-player dispatch — runs once for each pioneer.choosing player. The choice
# functions (pioneer_continue / to_adventurer / to_newcomer) all clear the tag
# on commit, so a re-emission after one of those runs won't spam.
execute as @a[tag=pioneer.choosing] at @s run function evercraft:difficulty/pioneer_choice_prompt_one
