# Pioneer — Step 2: Continue/Switch difficulty prompt (Joseph 2026-06-13)
# Second of three sequential prompts. Emitted after the player commits to
# step 1 (Story Mode / Free Play) via trigger_dispatch sm.pick handler.
# Player picks Continue Pioneer / Switch to Adventurer / Switch to Newcomer.
# Each click runs pioneer_continue / pioneer_to_adventurer / pioneer_to_newcomer,
# which chain to step 3 (Memento) on commit.
# Run as @s = a Pioneer player tagged pioneer.step1 (about to advance to step 2).

tag @s remove pioneer.step1
tag @s add pioneer.step2

tellraw @s [{text:"\n"},{text:"═══════════════════════════════",color:dark_gray}]
tellraw @s [{text:"Choose your path forward:",color:gold,bold:true}]
tellraw @s [{text:" "},{text:"[Continue as Pioneer]",color:dark_red,bold:true,click_event:{action:run_command,command:"/function evercraft:difficulty/pioneer_continue"},hover_event:{action:show_text,value:{text:"Stay on the hardest path. No mercy.",color:red}}},{text:" — The brave fall and rise again.",color:gray,italic:true}]
tellraw @s [{text:" "},{text:"[Switch to Adventurer]",color:green,bold:true,click_event:{action:run_command,command:"/function evercraft:difficulty/pioneer_to_adventurer"},hover_event:{action:show_text,value:{text:"Standard progression. Earn everything through play.",color:green}}},{text:" — A fresh start with safety nets.",color:gray,italic:true}]
tellraw @s [{text:" "},{text:"[Switch to Newcomer]",color:aqua,bold:true,click_event:{action:run_command,command:"/function evercraft:difficulty/pioneer_to_newcomer"},hover_event:{action:show_text,value:{text:"Guided experience with early class access.",color:aqua}}},{text:" — The gentlest path forward.",color:gray,italic:true}]
tellraw @s [{text:"═══════════════════════════════",color:dark_gray}]
