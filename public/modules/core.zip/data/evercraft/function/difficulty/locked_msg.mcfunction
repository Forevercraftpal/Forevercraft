# Show "difficulty locked" message with remaining days
# Expects #_diff_now ec.temp = days elapsed since last choice

scoreboard players set #_diff_remain ec.temp 14
scoreboard players operation #_diff_remain ec.temp -= #_diff_now ec.temp

data modify storage evercraft:notify stage.c set value [{text:"Difficulty is locked for ",color:"gray"},{score:{name:"#_diff_remain",objective:"ec.temp"},color:"yellow"},{text:" more day(s).",color:"gray"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 0.3 0.5
