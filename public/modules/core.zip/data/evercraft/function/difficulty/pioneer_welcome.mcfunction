# Pioneer Welcome — Brief message, skip tutorial, chain to chronicle
# @s = player who chose Pioneer difficulty

data modify storage evercraft:notify stage.c set value [{text:"You walk the hardest path.",color:"gray"}]
scoreboard players set #ndur ec.temp 50
function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"No tutorial. No safety net. Your journey begins now.",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.wither.ambient master @s ~ ~ ~ 0.3 0.8

# Mark tutorial as done (Pioneer doesn't get one)
scoreboard players set @s ec.tutorial_done 1

# Chain to chronicle path if story mode
execute if score @s sm.mode matches 1..2 run function evercraft:story/mode/choose_path
