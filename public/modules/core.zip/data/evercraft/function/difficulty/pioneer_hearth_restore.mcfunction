# ══════════════════════════════════════════════════════════════
# Pioneer Difficulty — Hearthstone safe space: RESTORE (post-strip)
# Run as @s (the reborn Pioneer), AFTER admin/strip_player_zero.
# Joseph 2026-06-22. Mirror of pioneer_hearth_snapshot.
#
# The strip's nuclear `scoreboard players reset @s` wiped every hs.* score.
# Re-pour the snapshotted home columns + pointers from the fake scratch, then
# rebuild the active-slot mirror (load_active) and re-assert forceload for every
# occupied home (forceload_all). The physical hearthstone + its guidestone
# registry entry survived as WORLD data, so the player simply re-owns their
# home(s) exactly as before death.
# ══════════════════════════════════════════════════════════════

# Active-slot pointer + guest-share setting.
scoreboard players operation @s hs.active = #hsk_active hs.active
scoreboard players operation @s hs.guest_share = #hsk_gshare hs.guest_share

# Per-slot columns — only slots that held a home (snapshot tier >= 1) are
# re-poured, so empty slots stay wiped (unset) as the strip left them.
execute if score #hsk1_tier hs.h1_tier matches 1.. run function evercraft:difficulty/pioneer_hearth_rest_slot {n:1}
execute if score #hsk2_tier hs.h2_tier matches 1.. run function evercraft:difficulty/pioneer_hearth_rest_slot {n:2}
execute if score #hsk3_tier hs.h3_tier matches 1.. run function evercraft:difficulty/pioneer_hearth_rest_slot {n:3}
execute if score #hsk4_tier hs.h4_tier matches 1.. run function evercraft:difficulty/pioneer_hearth_rest_slot {n:4}
execute if score #hsk5_tier hs.h5_tier matches 1.. run function evercraft:difficulty/pioneer_hearth_rest_slot {n:5}

# Rederive the count + slot-cap from the re-poured columns via their own
# one-writers. unlock_check floors at the highest occupied slot (Dream Rank was
# wiped), so no restored home is orphaned in a re-locked slot.
function evercraft:housing/slot/recount
function evercraft:housing/slot/unlock_check

# Rebuild the legacy mirror from the active slot, then re-assert chunk loading
# for every occupied home (both no-op cleanly when the player had no home).
function evercraft:housing/slot/load_active
execute if score @s hs.active matches 1..5 run function evercraft:housing/slot/forceload_all
