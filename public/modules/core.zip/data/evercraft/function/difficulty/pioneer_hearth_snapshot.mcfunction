# ══════════════════════════════════════════════════════════════
# Pioneer Difficulty — Hearthstone safe space: SNAPSHOT (pre-strip)
# Run as @s (the dying Pioneer), BEFORE admin/strip_player_zero.
# Joseph 2026-06-22: a Pioneer should NOT lose their home(s) on death.
#
# The home(s) live purely in per-player scoreboards: the hs.h<N>_* slot
# columns (tier/x/y/z/dim/gs/decor/prot/pmode/dg) + the hs.active/slots/homes
# pointers + the hs.guest_share setting. The nuclear `scoreboard players reset
# @s` inside the strip wipes ALL of them. The physical hearthstone block and
# its guidestone registry entry are WORLD data and survive. So we snapshot the
# home columns + pointers into fake-player scratch (# names survive `reset @s`)
# and restore them right after the strip in pioneer_death — same idiom as the
# Codex Vault / Wayfarer Track safe spaces.
#
# Synchronous snapshot -> strip -> restore within ONE pioneer_death execution
# for this @s (no async gap), so the shared fake scratch is collision-free even
# if two Pioneers die the same tick (each call completes before the next).
# ══════════════════════════════════════════════════════════════

# Per-slot columns for ALL 5 slots (reset-then-copy: empty slots snapshot as 0,
# so a stale value from a prior player's snapshot can never leak into restore).
function evercraft:difficulty/pioneer_hearth_snap_slot {n:1}
function evercraft:difficulty/pioneer_hearth_snap_slot {n:2}
function evercraft:difficulty/pioneer_hearth_snap_slot {n:3}
function evercraft:difficulty/pioneer_hearth_snap_slot {n:4}
function evercraft:difficulty/pioneer_hearth_snap_slot {n:5}

# Active-slot pointer + the guest-comfort sharing setting (reset-then-copy each).
# hs.homes / hs.slots are NOT snapshotted — they're rederived post-restore by
# their own one-writers (recount / unlock_check) from the re-poured columns.
scoreboard players set #hsk_active hs.active 0
scoreboard players operation #hsk_active hs.active = @s hs.active
scoreboard players set #hsk_gshare hs.guest_share 0
scoreboard players operation #hsk_gshare hs.guest_share = @s hs.guest_share
