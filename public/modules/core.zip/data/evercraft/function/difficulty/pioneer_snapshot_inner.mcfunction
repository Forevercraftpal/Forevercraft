# Pioneer Save-One-Item — Snapshot inner (macro: UUID)
# Joseph 2026-06-15 redesign: capture the ENTIRE Inventory list (main slots 0-35,
# armor 100-103, offhand -106) in one copy — every entry keeps its Slot tag, so a
# later `Inventory set from` restores items to exactly where they were. This feeds
# the new Memento "reclaim everything, then keep one" flow (pioneer_reclaim).
# Drops any stale snapshot first. An empty inventory yields an empty list (the
# reclaim offer gates on list presence, so nothing surfaces in that case).

$data remove storage evercraft:pioneer preserved."$(UUID)"
$data modify storage evercraft:pioneer preserved."$(UUID)".full set from entity @s Inventory
