# Pioneer Hearthstone safe space — restore ONE slot's columns from fakes.
# Macro arg: {n:<1-5>}. Run as @s. Mirror of pioneer_hearth_snap_slot.
$scoreboard players operation @s hs.h$(n)_tier = #hsk$(n)_tier hs.h$(n)_tier
$scoreboard players operation @s hs.h$(n)_x = #hsk$(n)_x hs.h$(n)_x
$scoreboard players operation @s hs.h$(n)_y = #hsk$(n)_y hs.h$(n)_y
$scoreboard players operation @s hs.h$(n)_z = #hsk$(n)_z hs.h$(n)_z
$scoreboard players operation @s hs.h$(n)_dim = #hsk$(n)_dim hs.h$(n)_dim
$scoreboard players operation @s hs.h$(n)_gs = #hsk$(n)_gs hs.h$(n)_gs
$scoreboard players operation @s hs.h$(n)_decor = #hsk$(n)_decor hs.h$(n)_decor
$scoreboard players operation @s hs.h$(n)_prot = #hsk$(n)_prot hs.h$(n)_prot
$scoreboard players operation @s hs.h$(n)_pmode = #hsk$(n)_pmode hs.h$(n)_pmode
$scoreboard players operation @s hs.h$(n)_dg = #hsk$(n)_dg hs.h$(n)_dg
