# Pioneer Save-One-Item — Offer inner (macro: UUID)
# Joseph 2026-06-15 redesign: a single [Reclaim] button instead of 9 per-slot
# [Pick] rows. Gated on the full snapshot existing (preserved.<UUID>.full) — if
# the player died empty-handed there's nothing to reclaim, so no button shows.
# Clicking [Reclaim] runs pioneer_reclaim: it pours your entire previous
# inventory back, roots you, and lets you keep the ONE item you hold + sneak.

$execute unless data storage evercraft:pioneer preserved."$(UUID)".full run return 0

tellraw @s [{text:""}]
tellraw @s [{text:"━━━ ",color:"dark_gray"},{text:"Pioneer's Memento",color:"light_purple",bold:true},{text:" ━━━",color:"dark_gray"}]
tellraw @s [{text:" Your past life can return to your hands — but only one keepsake may stay.",color:"gray",italic:true}]
tellraw @s [{text:"  "},{text:"[ Reclaim Your Cache ]",color:"light_purple",bold:true,click_event:{action:"run_command",command:"/function evercraft:difficulty/pioneer_reclaim"},hover_event:{action:"show_text",value:[{text:"Pour everything back, then ",color:"gray"},{text:"hold the one item to keep and sneak",color:"yellow"},{text:" to seal your choice.",color:"gray"}]}}]
tellraw @s [{text:"━━━━━━━━━━━━━━━━━━━━━━━━",color:"dark_gray"}]
