# ══════════════════════════════════════════════════════════════
# Pioneer's Memento — Reclaim (Joseph 2026-06-15 redesign)
# Run as @s = the player who clicked [ Reclaim Your Cache ].
# ──────────────────────────────────────────────────────────────
# Pours the player's ENTIRE previous inventory back (main + armor +
# offhand from the death snapshot), roots them in place, and starts
# the choose-one loop — they keep only the item they HOLD when they
# sneak (pioneer_reclaim_confirm); everything else is wiped.
# ──────────────────────────────────────────────────────────────
# Defence-in-depth: a stale chat click must not reclaim if save-one
# was toggled OFF after death, and a second click while already
# choosing must not re-pour the snapshot (dupe guard).
# ══════════════════════════════════════════════════════════════
execute unless score #disable_pioneer_save_one ec.constant matches 0 run return 0
execute if entity @s[tag=pioneer.reclaiming] run return 0

data modify storage evercraft:pioneer args.UUID set from entity @s UUID
function evercraft:difficulty/pioneer_reclaim_inner with storage evercraft:pioneer args
