# Pioneer's Memento — Reclaim inner (macro: UUID). Run as @s.
# Gate on the full snapshot existing; restore the entire inventory, then begin the rooted choose phase.
# No snapshot => no-op (no freeze).
#
# MC 26.2 (1.21.5+): `data modify entity @s Inventory set from storage` is read-only and silently no-op'd
# — the inventory never came back, so the choose phase had nothing to pick from. Restore is now per-slot
# via /item off a writable hopper-minecart: copy the snapshot to a consumable working list, clear the
# inventory, then walk the list placing each entry back at its ORIGINAL slot. The original snapshot
# (preserved."<UUID>".full) is left intact — we consume the copy — so a re-entry can restore again.
$execute unless data storage evercraft:pioneer preserved."$(UUID)".full run return 0
$data modify storage evercraft:pioneer restore set from storage evercraft:pioneer preserved."$(UUID)".full
clear @s
function evercraft:difficulty/pioneer_restore_step
function evercraft:difficulty/pioneer_reclaim_begin
