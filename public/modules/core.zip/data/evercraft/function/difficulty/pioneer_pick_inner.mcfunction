# Pioneer Save-One-Item — Pick inner  [deprecated 2026-06-15]
# Superseded by pioneer_reclaim_confirm. No callers remain (the per-slot [Pick]
# offer was replaced by the single [Reclaim] button). Left inert as a no-op.
return 0
