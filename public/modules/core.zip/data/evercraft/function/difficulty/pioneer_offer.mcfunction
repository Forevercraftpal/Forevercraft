# ══════════════════════════════════════════════════════════════
# Pioneer Save-One-Item — Offer tellraw (UUID extract + dispatch)
# Run as: respawned Pioneer player. Called from pioneer_death tail
# AFTER the path-choice tellraw, gated on the save-one toggle.
# ══════════════════════════════════════════════════════════════
data modify storage evercraft:pioneer args.UUID set from entity @s UUID
function evercraft:difficulty/pioneer_offer_inner with storage evercraft:pioneer args
