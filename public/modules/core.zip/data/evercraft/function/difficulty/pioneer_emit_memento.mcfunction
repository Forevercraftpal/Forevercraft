# Pioneer — Step 3: Pioneer's Memento prompt (Joseph 2026-06-13)
# Third and final prompt in the sequential death chain. Emitted regardless of
# whether the player stayed Pioneer or switched difficulty. The save-one offer
# rebuilds the [Pick Slot N] rows from the snapshot taken before strip — see
# pioneer_offer / pioneer_offer_inner. Gated on the global toggle so a treasure-
# settings flip between strip and offer can't surface empty rows.
# Run as @s = the dying Pioneer who just answered step 2.

tag @s remove pioneer.step2
tag @s add pioneer.step3

execute if score #disable_pioneer_save_one ec.constant matches 0 run function evercraft:difficulty/pioneer_offer
# If the toggle is OFF, step 3 is a no-op — clear the tag immediately so the
# scheduled re-emit doesn't keep trying to fire an empty offer.
execute unless score #disable_pioneer_save_one ec.constant matches 0 run tag @s remove pioneer.step3
execute unless score #disable_pioneer_save_one ec.constant matches 0 run tag @s remove pioneer.choosing
