# ══════════════════════════════════════════════════════════════
# Pioneer Save-One-Item — Pick  [deprecated 2026-06-15]
# ──────────────────────────────────────────────────────────────
# Superseded by the Memento "reclaim everything, keep one" flow
# (pioneer_reclaim -> pioneer_reclaim_confirm). The old per-slot
# [Pick] tellraw rows are gone, so this has no callers. Left inert
# (returns immediately) in case a very stale chat line is clicked.
# ══════════════════════════════════════════════════════════════
return 0
