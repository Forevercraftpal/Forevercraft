# Pioneer's Memento — place the carted entry into hotbar.$(n) (macro {n}). Called from pioneer_restore_step.
$item replace entity @s hotbar.$(n) from entity @e[type=hopper_minecart,tag=ec.pio_rcart,limit=1] container.0
