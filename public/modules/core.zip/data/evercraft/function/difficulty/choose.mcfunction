# Difficulty Selection Handler — Called from tick trigger
# @s = player, ec.diff_trigger = 1 (Newcomer) or 2 (Adventurer) or 3 (Pioneer)

# If already chosen, check 14-day lock — abort if locked
execute if score @s ec.difficulty matches 1..3 store result score #_diff_now ec.temp run time query minecraft:day repetition
execute if score @s ec.difficulty matches 1..3 run scoreboard players operation #_diff_now ec.temp -= @s ec.diff_day
execute if score @s ec.difficulty matches 1..3 if score #_diff_now ec.temp matches ..13 run function evercraft:difficulty/locked_msg
execute if score @s ec.difficulty matches 1..3 if score #_diff_now ec.temp matches ..13 run scoreboard players set @s ec.diff_trigger 0
execute if score @s ec.difficulty matches 1..3 if score #_diff_now ec.temp matches ..13 run scoreboard players enable @s ec.diff_trigger
execute if score @s ec.difficulty matches 1..3 if score #_diff_now ec.temp matches ..13 run return 0

# Store chosen day
execute store result score @s ec.diff_day run time query minecraft:day repetition

# Apply selection
scoreboard players operation @s ec.difficulty = @s ec.diff_trigger

# Confirmation messages
execute if score @s ec.difficulty matches 1 run data modify storage evercraft:notify stage.c set value [{text:"Difficulty set to ",color:"gray"},{text:"Newcomer",color:"green",bold:true},{text:" \u2014 relaxed mobs, +10% bonus rewards.",color:"gray"}]
execute if score @s ec.difficulty matches 2 run data modify storage evercraft:notify stage.c set value [{text:"Difficulty set to ",color:"gray"},{text:"Adventurer",color:"red",bold:true},{text:" \u2014 full challenge, standard rates.",color:"gray"}]
execute if score @s ec.difficulty matches 3 run data modify storage evercraft:notify stage.c set value [{text:"Difficulty set to ",color:"gray"},{text:"Pioneer",color:"dark_purple",bold:true},{text:" \u2014 one life. Make it count.",color:"gray"}]
scoreboard players set #ndur ec.temp 45
execute if score @s ec.difficulty matches 1..3 run function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.hat master @s ~ ~ ~ 0.5 1.8

# Reset trigger
scoreboard players set @s ec.diff_trigger 0
scoreboard players enable @s ec.diff_trigger

# === FIRST HOUSE / BAUL — difficulty-gated acquisition (additive, one-shot) ===
# Sorting is a time sink, so the first home arrives early — but earned by mode:
#   ec.difficulty 1 Newcomer / 2 Adventurer -> handed (Hearthstone + Baul)
#   ec.difficulty 3 Pioneer                 -> nothing handed; must craft (recipe exists)
# Guarded by ec.house_granted so a difficulty re-selection (after 14-day lock) never double-hands.
execute unless score @s ec.house_granted matches 1 if score @s ec.difficulty matches 1..2 run function evercraft:housing/give
# Inv-full guard: drop at the player's feet rather than void on a full inventory.
execute store result score #inv_full ec.var run function evercraft:util/check_inv_full
execute unless score @s ec.house_granted matches 1 if score @s ec.difficulty matches 1..2 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:bulk_barrel/item
execute unless score @s ec.house_granted matches 1 if score @s ec.difficulty matches 1..2 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:bulk_barrel/item
data modify storage evercraft:notify stage.c set value [{text:"A ",color:"gray"},{text:"Baúl",color:"gold"},{text:" arrives with your Hearthstone — place it, then right-click to deposit.",color:"gray"}]
scoreboard players set #ndur ec.temp 45
execute unless score @s ec.house_granted matches 1 if score @s ec.difficulty matches 1..2 run function evercraft:util/notify/emit
# Mark granted for Newcomer/Adventurer once they have been handed the pair.
execute unless score @s ec.house_granted matches 1 if score @s ec.difficulty matches 1..2 run scoreboard players set @s ec.house_granted 1
# Pioneer: no free hand. Mark the one-shot so a later switch to 1/2 still won't hand it (craft-only commitment).
execute unless score @s ec.house_granted matches 1 if score @s ec.difficulty matches 3 run scoreboard players set @s ec.house_granted 1

# Mark tutorial as done (story chapters replace the tutorial now)
scoreboard players set @s ec.tutorial_done 1

# === CHAIN TO CHRONICLE PATH (Story Mode) OR DONE (Free Play) ===
# Pioneer gets brief welcome, then chronicle if story mode
execute if score @s ec.difficulty matches 3 run function evercraft:difficulty/pioneer_welcome
execute if score @s ec.difficulty matches 3 run return 0

# Newcomer: spirit weapon choice first, then chronicle
execute if score @s ec.difficulty matches 1 unless entity @s[tag=ec.spirit_chosen] run function evercraft:newcomer/spirit_weapon_choice

# All non-Pioneer: go straight to chronicle picker if story mode
execute if score @s sm.mode matches 1..2 run function evercraft:story/mode/choose_path
