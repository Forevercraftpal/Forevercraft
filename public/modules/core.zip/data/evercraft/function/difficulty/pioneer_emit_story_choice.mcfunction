# Pioneer — Step 1: Story Mode prompt (Joseph 2026-06-13)
# First of three sequential prompts emitted after a Pioneer death. Player picks
# Story Mode or Free Play; trigger_dispatch routes the answer through
# story/mode/set_story or set_freeplay, then chains to step 2 if the player is
# still tagged pioneer.step1.
# Run as @s = the dying-then-respawned Pioneer player.

tag @s remove pioneer.step1
tag @s remove pioneer.step2
tag @s remove pioneer.step3
tag @s add pioneer.step1
# Re-enable the sm.pick trigger in case a prior session left it disabled.
scoreboard players enable @s sm.pick

tellraw @s [{text:"\n"},{text:"═══════════════════════════════",color:dark_gray}]
tellraw @s [{text:"How will you experience Forevercraft?",color:gold,bold:true}]
tellraw @s [{text:" "},{text:"[✦ Story Mode]",color:gold,bold:true,click_event:{action:run_command,command:"/trigger sm.pick set 1"},hover_event:{action:show_text,value:[{text:"The Legend of Forevercraft",color:gold,bold:true},{text:"\nA guided journey, chapter by chapter.",color:gray}]}},{text:" — guided chapters, narrative beats.",color:gray,italic:true}]
tellraw @s [{text:" "},{text:"[✦ Free Play]",color:aqua,bold:true,click_event:{action:run_command,command:"/trigger sm.pick set 2"},hover_event:{action:show_text,value:[{text:"Free Play Mode",color:aqua,bold:true},{text:"\nEverything available, no gates.",color:gray}]}},{text:" — every system unlocked, follow your own thread.",color:gray,italic:true}]
tellraw @s [{text:"═══════════════════════════════",color:dark_gray}]
