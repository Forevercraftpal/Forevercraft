# Pioneer Hearthstone safe space — snapshot ONE slot's columns into fakes.
# Macro arg: {n:<1-5>}. Run as @s. Reset-then-copy each column so an empty
# slot (unset source) snapshots as 0 (the operation no-ops on a missing source,
# so the prior `set ... 0` is what survives). See pioneer_hearth_snapshot.
$scoreboard players set #hsk$(n)_tier hs.h$(n)_tier 0
$scoreboard players operation #hsk$(n)_tier hs.h$(n)_tier = @s hs.h$(n)_tier
$scoreboard players set #hsk$(n)_x hs.h$(n)_x 0
$scoreboard players operation #hsk$(n)_x hs.h$(n)_x = @s hs.h$(n)_x
$scoreboard players set #hsk$(n)_y hs.h$(n)_y 0
$scoreboard players operation #hsk$(n)_y hs.h$(n)_y = @s hs.h$(n)_y
$scoreboard players set #hsk$(n)_z hs.h$(n)_z 0
$scoreboard players operation #hsk$(n)_z hs.h$(n)_z = @s hs.h$(n)_z
$scoreboard players set #hsk$(n)_dim hs.h$(n)_dim 0
$scoreboard players operation #hsk$(n)_dim hs.h$(n)_dim = @s hs.h$(n)_dim
$scoreboard players set #hsk$(n)_gs hs.h$(n)_gs 0
$scoreboard players operation #hsk$(n)_gs hs.h$(n)_gs = @s hs.h$(n)_gs
$scoreboard players set #hsk$(n)_decor hs.h$(n)_decor 0
$scoreboard players operation #hsk$(n)_decor hs.h$(n)_decor = @s hs.h$(n)_decor
$scoreboard players set #hsk$(n)_prot hs.h$(n)_prot 0
$scoreboard players operation #hsk$(n)_prot hs.h$(n)_prot = @s hs.h$(n)_prot
$scoreboard players set #hsk$(n)_pmode hs.h$(n)_pmode 0
$scoreboard players operation #hsk$(n)_pmode hs.h$(n)_pmode = @s hs.h$(n)_pmode
$scoreboard players set #hsk$(n)_dg hs.h$(n)_dg 0
$scoreboard players operation #hsk$(n)_dg hs.h$(n)_dg = @s hs.h$(n)_dg
