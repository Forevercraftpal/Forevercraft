# Pioneer's Memento — Begin the rooted choose phase. Run as @s.
# Roots the player via movement + jump attribute modifiers (cleanly removed by
# id at confirm — no effect timers to fight), tags them, and kicks the choose
# loop. Drops pioneer.step3 so the death-flow's re-emit can't re-show the offer.
tag @s remove pioneer.step3
tag @s add pioneer.reclaiming

attribute @s movement_speed modifier add evercraft:pioneer_root -1.0 add_multiplied_total
attribute @s minecraft:jump_strength modifier add evercraft:pioneer_root -1.0 add_multiplied_total

schedule function evercraft:difficulty/pioneer_reclaim_tick 4t replace

title @s title {text:"Your past returns",color:"light_purple"}
title @s subtitle {text:"Keep only what you hold.",color:"gray",italic:true}
tellraw @s [{text:" ✦ ",color:"light_purple"},{text:"Everything you carried is back in your hands. Hold the ONE item to keep, then ",color:"yellow"},{text:"sneak",color:"gold",bold:true},{text:" — the rest will fade.",color:"yellow"}]
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.7 0.9
