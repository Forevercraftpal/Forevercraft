# ══════════════════════════════════════════════════════════════
# Pioneer Difficulty — Death Consequence
# Called when a Pioneer player dies. Strips ALL progression.
# The world survives. The player starts over.
# ══════════════════════════════════════════════════════════════

# Only trigger for Pioneer players (difficulty = 3)
execute unless score @s ec.difficulty matches 3 run return 0

# === DRAMATIC ANNOUNCEMENT ===
title @s times 20 100 40
title @s title {text:"YOU HAVE FALLEN",color:dark_red}
title @s subtitle {text:"Your legacy has been erased.",color:gray,italic:true}

# Server announcement
function evercraft:util/notify/whoami
data modify storage evercraft:notify stage.c set value [{text:"☠ ",color:dark_red},{text:"",color:red},{text:" has fallen as a Pioneer. Their journey begins anew.",color:dark_gray,italic:true},{text:" ☠",color:dark_red}]
data modify storage evercraft:notify stage.c[1].text set from storage evercraft:notify named.who
scoreboard players set #ndur ec.temp 50
execute as @a run scoreboard players set #nttl ec.temp 600
execute as @a run function evercraft:util/notify/emit_keep

# === RECLAIM DROPPED ITEMS + WIPE ENDER CHEST (before strip) ===
# Runs anchored at the death site so the 256-block kill radius is correct.
# Ender chest wipe via EnderItems NBT (26.1 supports the direct write).
# Joseph 2026-06-12: the wipe is now gated on #disable_pioneer_ender_wipe
# (treasure settings panel — default ON = wipe, OFF = keep contents across
# the Pioneer wipe as a vault).
execute at @s run function evercraft:admin/strip_dropped_items
execute if score #disable_pioneer_ender_wipe ec.constant matches 0 run function evercraft:admin/wipe_ender_chest

# === PIONEER SAVE-ONE-ITEM SNAPSHOT (Joseph 2026-06-12) ===
# Capture the hotbar (slots 0-8) into evercraft:pioneer preserved."<UUID>".slot.<N>
# BEFORE strip_player_zero wipes the inventory. Gated on the save-one toggle —
# off by setting #disable_pioneer_save_one in the Treasure Settings panel. The
# matching [Pick N] tellraw offer is emitted near the end of this function.
execute if score #disable_pioneer_save_one ec.constant matches 0 run function evercraft:difficulty/pioneer_snapshot

# === CODEX VAULT IS A PIONEER SAFE SPACE (Joseph 2026-06-15) ===
# The enshrined-artifact vault survives a Pioneer death — another safe space, like the opt-in
# ender vault above. The strip's nuclear score reset would wipe ec.cdxv_pid (the pointer to my
# deposits.p<pid> records) and `advancement revoke @s everything` would drop the deposited advs,
# so: snapshot the pid into a fake on its own objective (untouched by `reset @s`), and tag the
# strip to SKIP the storage purge (admin/strip_player_zero gates wipe_self on ec.cdxv_keep). The
# pid is restored + recompute re-grants the advs and re-sums the points just after the strip.
# The manual [Wipe] button in the Gallery (Pioneer clean-slate) is the opt-out.
scoreboard players set #cdxv_keep_pid ec.cdxv_pid 0
execute if score @s ec.cdxv_pid matches 1.. run scoreboard players operation #cdxv_keep_pid ec.cdxv_pid = @s ec.cdxv_pid
tag @s add ec.cdxv_keep

# === WAYFARER TRACK IS A PIONEER SAFE SPACE (Joseph 2026-06-21) ===
# The Wayfarer Track survives a Pioneer death — another safe space, like the Codex Vault above. The strip
# would zero ec.wf_xp/node/season + revoke all 250 claimed/nN advancements. So: tag the strip to SKIP the
# wayfarer wipes (ec.wf_keep, mirrors ec.cdxv_keep) and snapshot the progress into fakes/storage that the
# nuclear `reset @s` + `advancement revoke @s everything` can't touch.
#   THE FOLD: ec.wf_xp is RECOMPUTED every accrue tick from dr.points ((dr - baseline)*10 + wf_bonus), and
#   Pioneer death CORRECTLY wipes dr.points — so restoring wf_xp directly is futile (it collapses next tick).
#   Instead we MOVE the whole current total into the persistent additive ec.wf_bonus lane (which accrue folds
#   back in), and on restore set baseline=0 so the dr-derived part restarts cleanly from the post-wipe dr=0.
#   The #wf_keep_* fakes live on the real wf objectives but use a FAKE player name (# prefix), so the strip's
#   `scoreboard players reset @s` leaves them untouched (only real-player scores are reset).
tag @s add ec.wf_keep
scoreboard players set #wf_keep_bonus ec.wf_bonus 0
execute if score @s ec.wf_xp matches 1.. run scoreboard players operation #wf_keep_bonus ec.wf_bonus = @s ec.wf_xp
scoreboard players set #wf_keep_node ec.wf_node 0
execute if score @s ec.wf_node matches 1.. run scoreboard players operation #wf_keep_node ec.wf_node = @s ec.wf_node
scoreboard players set #wf_keep_season ec.wf_season 0
execute if score @s ec.wf_season matches 1.. run scoreboard players operation #wf_keep_season ec.wf_season = @s ec.wf_season
function evercraft:companions/track/preserve/snapshot_claimed

# === HEARTHSTONE IS A PIONEER SAFE SPACE (Joseph 2026-06-22) ===
# A Pioneer keeps the home(s) they built/upgraded. The home lives entirely in
# per-player hs.* scoreboards (slot columns + pointers) which the nuclear reset
# wipes; the physical hearthstone + its guidestone registry entry are WORLD data
# and survive. Snapshot the home scores now (into fakes the reset can't touch);
# they're re-poured right after the strip below. Fully synchronous, no pid churn.
function evercraft:difficulty/pioneer_hearth_snapshot

# === GUIDESTONE XP-UNLOCKS ARE A PIONEER SAFE SPACE (Joseph 2026-06-22) ===
# A Pioneer keeps the guidestone links they paid 30 levels each to establish.
# The unlock list is storage keyed by companion.id; the strip zeroes that id and
# new_player re-mints a fresh one next tick, orphaning the list. Stash it under
# the player's stable real UUID NOW (while companion.id is still live); the
# new_player restore hook re-keys it under the new id on the next tick.
execute store result storage evercraft:guidestone gsp.pid int 1 run scoreboard players get @s companion.id
execute store result storage evercraft:guidestone gsp.u0 int 1 run data get entity @s UUID[0]
execute store result storage evercraft:guidestone gsp.u1 int 1 run data get entity @s UUID[1]
execute store result storage evercraft:guidestone gsp.u2 int 1 run data get entity @s UUID[2]
execute store result storage evercraft:guidestone gsp.u3 int 1 run data get entity @s UUID[3]
function evercraft:guidestone/preserve_snapshot with storage evercraft:guidestone gsp
data remove storage evercraft:guidestone gsp

# === FULL STRIP (calls the nuclear reset) ===
function evercraft:admin/strip_player_zero

# === RESET THIS PIONEER'S CHEST LIST ===
# The nuclear strip clears inventory + structure-type discovery, but NOT the
# per-chest looted markers — so without this the reborn Pioneer still couldn't
# re-loot any structure they'd already opened. Wipe this player's looted markers
# so the world's treasure is fresh again. The world survives; the chest list does not.
function evercraft:structures/storage/reset_player

# === RESET DIFFICULTY BACK TO PIONEER (strip resets it to 0) ===
scoreboard players set @s ec.difficulty 3

# === RESTORE THE PRESERVED CODEX VAULT (Joseph 2026-06-15) ===
# The strip skipped the storage purge (ec.cdxv_keep), but the nuclear score reset still wiped
# the pid and `advancement revoke @s everything` dropped the deposited advs. Restore the pid,
# then recompute — which re-sums ec.cdxv_pts/ec.cdxv_cnt AND re-grants every deposited/<art>
# adv from the surviving deposits.p<pid> sub-list (recompute_step does both per record).
tag @s remove ec.cdxv_keep
execute if score #cdxv_keep_pid ec.cdxv_pid matches 1.. run scoreboard players operation @s ec.cdxv_pid = #cdxv_keep_pid ec.cdxv_pid
execute if score @s ec.cdxv_pid matches 1.. run function evercraft:codex_vault/recompute

# === RESTORE THE PRESERVED WAYFARER TRACK (Joseph 2026-06-21) ===
# The strip skipped the wayfarer wipes (ec.wf_keep), but the nuclear score reset still zeroed the real-player
# wf scores and `advancement revoke @s everything` dropped the 250 claimed/nN advs. Restore from the fakes:
# the folded total lands back in ec.wf_bonus, baseline restarts at 0 (so the dr-derived part recomputes from
# the post-wipe dr.points=0), node + season come back, and restore_claimed re-grants every claimed node's
# advancement (no re-claim exploit, no lost rewards). Seed ec.wf_xp now so the GUI is correct THIS tick
# (a one-shot write on the death path; accrue resumes as the sole steady-state writer next tick).
tag @s remove ec.wf_keep
execute if score #wf_keep_bonus ec.wf_bonus matches 1.. run scoreboard players operation @s ec.wf_bonus = #wf_keep_bonus ec.wf_bonus
scoreboard players set @s ec.wf_baseline 0
execute if score #wf_keep_node ec.wf_node matches 1.. run scoreboard players operation @s ec.wf_node = #wf_keep_node ec.wf_node
execute if score #wf_keep_season ec.wf_season matches 1.. run scoreboard players operation @s ec.wf_season = #wf_keep_season ec.wf_season
function evercraft:companions/track/preserve/restore_claimed
scoreboard players operation @s ec.wf_xp = @s ec.wf_bonus

# === RESTORE THE PRESERVED HEARTHSTONE (Joseph 2026-06-22) ===
# The nuclear reset wiped every hs.* score; re-pour the snapshotted home columns
# + pointers, rebuild the active-slot mirror, and re-assert forceload. The home's
# guidestone registry entry survived as WORLD data, so the reborn Pioneer simply
# re-owns the home exactly as before. (The guidestone XP-unlock list is restored
# separately on the next tick from new_player, once companion.id is re-minted.)
function evercraft:difficulty/pioneer_hearth_restore

# === ADDITIONAL PIONEER PENALTIES ===
# Ender chest + death-drop reclaim handled above via the new helpers.
# The strip already clears main inventory + armor + offhand.

# Reset spawn point to world spawn
spawnpoint @s 0 -1 0

# === PIONEER REBIRTH EFFECTS ===
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.wither.spawn master @s ~ ~ ~ 0.5 0.8
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.lightning_bolt.thunder master @s ~ ~ ~ 0.3 0.5
particle minecraft:soul_fire_flame ~ ~1 ~ 1 1 1 0.1 50

# No starter items. You get NOTHING. Punch a tree, Pioneer.

# === WELCOME BACK MESSAGE + DIFFICULTY CHOICE ===
data modify storage evercraft:notify stage.c set value [{text:"The dream fades... but never dies.",color:dark_purple,italic:true}]
scoreboard players set #ndur ec.temp 50
function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"You are rejuvenated. Start again, Pioneer.",color:gold}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Every world has treasure. This one has dreams.",color:yellow,italic:true}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit

# Joseph 2026-06-13 (#93): sequential 3-prompt chain (Story Mode → Pioneer
# choice → Memento) instead of the old one-shot dump. pioneer.choosing is the
# meta-tag for "in the death-flow"; pioneer.step1/2/3 mark which sub-prompt is
# active. Trigger handlers chain forward (sm.pick → step2; pioneer_continue /
# to_adventurer / to_newcomer → step3). Memento fires regardless of stay-vs-
# switch. The scheduled dispatcher (pioneer_choice_prompt) reads the current
# step tag and emits the matching prompt — same path as the post-respawn safety
# re-emit, so a chat-drop in the death-screen window can't lose a step.
tag @s add pioneer.choosing
tag @s add pioneer.step1
schedule function evercraft:difficulty/pioneer_choice_prompt 20t replace
