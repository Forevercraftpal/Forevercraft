# Pioneer's Memento — restore one inventory entry from the consumable `restore` list, then recurse.
# Each entry carries its original Slot tag (0-8 hotbar, 9-35 main inventory, 100-103 armor, -106 offhand);
# we load it onto a hopper-minecart and `item replace` it back into the matching /item slot. This is the
# 26.2-safe replacement for the dead `data modify entity @s Inventory set from ...`. Empty list => done.
execute unless data storage evercraft:pioneer restore[0] run return 0

# Load this entry onto the cart. The cart's container slot 0 needs Slot:0b regardless of the item's
# original inventory slot, so stamp that after the copy (the original Slot stays readable on restore[0]).
# The cart MUST be summoned WITH a slot-0 placeholder: `data modify ... Items[0] set from` on an EMPTY
# list is a silent no-op (does NOT append), which left the cart empty so every restored slot got AIR
# (i.e. the inventory never came back). The stone gives index 0 something for `set from` to overwrite.
data modify entity @e[type=hopper_minecart,tag=ec.pio_rcart,limit=1] Items set value []
kill @e[type=hopper_minecart,tag=ec.pio_rcart]
execute at @s run summon hopper_minecart ~ ~ ~ {Tags:["ec.pio_rcart"],Enabled:0b,Items:[{Slot:0b,id:"minecraft:stone",count:1}]}
data modify entity @e[type=hopper_minecart,tag=ec.pio_rcart,limit=1] Items[0] set from storage evercraft:pioneer restore[0]
data modify entity @e[type=hopper_minecart,tag=ec.pio_rcart,limit=1] Items[0].Slot set value 0b

# Read the entry's ORIGINAL slot and place it back there.
execute store result score #pio_s ec.temp run data get storage evercraft:pioneer restore[0].Slot 1
# Hotbar 0-8 -> hotbar.N
execute if score #pio_s ec.temp matches 0..8 store result storage evercraft:pioneer pl.n int 1 run scoreboard players get #pio_s ec.temp
execute if score #pio_s ec.temp matches 0..8 run function evercraft:difficulty/pioneer_place_hotbar with storage evercraft:pioneer pl
# Main inventory 9-35 -> inventory.(N-9)
execute if score #pio_s ec.temp matches 9..35 run scoreboard players operation #pio_n ec.temp = #pio_s ec.temp
execute if score #pio_s ec.temp matches 9..35 run scoreboard players remove #pio_n ec.temp 9
execute if score #pio_s ec.temp matches 9..35 store result storage evercraft:pioneer pl.n int 1 run scoreboard players get #pio_n ec.temp
execute if score #pio_s ec.temp matches 9..35 run function evercraft:difficulty/pioneer_place_inv with storage evercraft:pioneer pl
# Armor (100=feet,101=legs,102=chest,103=head) + offhand (-106), fixed slot refs
execute if score #pio_s ec.temp matches 100 run item replace entity @s armor.feet from entity @e[type=hopper_minecart,tag=ec.pio_rcart,limit=1] container.0
execute if score #pio_s ec.temp matches 101 run item replace entity @s armor.legs from entity @e[type=hopper_minecart,tag=ec.pio_rcart,limit=1] container.0
execute if score #pio_s ec.temp matches 102 run item replace entity @s armor.chest from entity @e[type=hopper_minecart,tag=ec.pio_rcart,limit=1] container.0
execute if score #pio_s ec.temp matches 103 run item replace entity @s armor.head from entity @e[type=hopper_minecart,tag=ec.pio_rcart,limit=1] container.0
execute if score #pio_s ec.temp matches -106 run item replace entity @s weapon.offhand from entity @e[type=hopper_minecart,tag=ec.pio_rcart,limit=1] container.0

# Cleanup cart, drop this entry, recurse to the next.
data modify entity @e[type=hopper_minecart,tag=ec.pio_rcart,limit=1] Items set value []
kill @e[type=hopper_minecart,tag=ec.pio_rcart]
data remove storage evercraft:pioneer restore[0]
function evercraft:difficulty/pioneer_restore_step
