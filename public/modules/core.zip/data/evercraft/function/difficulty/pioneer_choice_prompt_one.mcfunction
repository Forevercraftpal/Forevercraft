# Pioneer — Per-player choice prompt re-emit (Joseph 2026-06-13)
# Run as @s = a Pioneer player still tagged pioneer.choosing.
# Joseph 2026-06-13 (re-design): the death-flow is now a 3-step CHAIN — Story
# Mode → Pioneer continue/switch → Pioneer's Memento. Each step only emits
# AFTER the previous one is answered. This file dispatches to the CURRENT
# step's emitter based on the per-player pioneer.step1/2/3 sub-tag. The
# 30t-after-death schedule from pioneer_death calls this to recover from any
# original emission that was lost in the death-screen chat-drop window.

# Audible cue — short bell so the player knows to look at chat.
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.8 1.0
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.chime master @s ~ ~ ~ 0.6 1.4

# Dispatch by current step (only one step tag set at a time).
execute if entity @s[tag=pioneer.step1] run function evercraft:difficulty/pioneer_emit_story_choice
execute if entity @s[tag=pioneer.step2] run function evercraft:difficulty/pioneer_emit_pioneer_choice
execute if entity @s[tag=pioneer.step3] run function evercraft:difficulty/pioneer_emit_memento
