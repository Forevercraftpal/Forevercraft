# Pioneer → Adventurer — Player downgrades after Pioneer death
execute unless entity @s[tag=pioneer.choosing] run return 0

# Unified UI-click FX (Joseph 2026-06-05): tellraw-option click — play the gated cue once on a valid pick.
function evercraft:fx/ui/click

scoreboard players set @s ec.difficulty 2
# Joseph 2026-06-13 (#93): chain to step 3 (Memento) on commit if mid-death-flow.
execute if entity @s[tag=pioneer.step2] run function evercraft:difficulty/pioneer_emit_memento
execute unless entity @s[tag=pioneer.step2] run tag @s remove pioneer.choosing

# Re-enable triggers so post-rebirth buttons (path pick, difficulty pick) work
scoreboard players enable @s sm.pick
scoreboard players enable @s sm.path_pick
scoreboard players enable @s ec.diff_trigger

# Joseph 2026-06-17 (#94): re-emit the Chronicle path picker — the strip wiped
# sm.path and the death-flow never re-ran it, wedging the player at chapter 1
# step 0. Mirrors difficulty/choose:60; the pick drives set_path ->
# dispatch_start -> chN/start (sets sm.step=1).
execute if score @s sm.mode matches 1..2 run function evercraft:story/mode/choose_path

data modify storage evercraft:notify stage.c set value [{text:"The journey continues — earn your legacy through play.",color:gray,italic:true}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.player.levelup master @s ~ ~ ~ 0.5 1.0
