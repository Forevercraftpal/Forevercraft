# Pioneer Salvation — Salvation Stone consumed on death
# Keeps ALL stats and scoreboards. Still loses items + XP.
# The stone saved your progress, not your gear.

# Consume one charge
scoreboard players remove @s ec.salvation 1

# === ANNOUNCEMENT ===
title @s times 20 80 40
title @s title {text:"SALVATION",color:gold}
title @s subtitle {text:"Your legacy endures. Your belongings do not.",color:gray,italic:true}

function evercraft:util/notify/whoami
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:gold},{text:"",color:yellow},{text:"'s Salvation Stone shattered on death — their legacy was preserved.",color:gray,italic:true},{text:" ✦",color:gold}]
data modify storage evercraft:notify stage.c[1].text set from storage evercraft:notify named.who
scoreboard players set #ndur ec.temp 50
execute as @a run scoreboard players set #nttl ec.temp 600
execute as @a run function evercraft:util/notify/emit_keep

# === CLEAR ITEMS ONLY (not scoreboards/tags/advancements) ===
clear @s
item replace entity @s armor.head with minecraft:air
item replace entity @s armor.chest with minecraft:air
item replace entity @s armor.legs with minecraft:air
item replace entity @s armor.feet with minecraft:air
item replace entity @s weapon.offhand with minecraft:air

# === CLEAR XP ===
experience set @s 0 points
experience set @s 0 levels

# === EFFECTS ===
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:item.totem.use master @s ~ ~ ~ 1.0 0.8
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.beacon.deactivate master @s ~ ~ ~ 0.5 1.0
particle minecraft:totem_of_undying ~ ~1 ~ 0.5 1 0.5 0.2 40
particle minecraft:end_rod ~ ~1 ~ 0.3 0.8 0.3 0.02 15

# Reset spawn point
spawnpoint @s 0 -1 0

# === MESSAGE ===
data modify storage evercraft:notify stage.c set value [{text:"Your Salvation Stone crumbled to dust.",color:gold,italic:true}]
scoreboard players set #ndur ec.temp 50
function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Stats preserved. Items and XP lost. You live to dream again.",color:gray}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Remaining charges: ",color:dark_gray},{score:{name:"@s",objective:"ec.salvation"},color:yellow,bold:true}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit

# Run boss hook
function evercraft:party/boss/on_death
