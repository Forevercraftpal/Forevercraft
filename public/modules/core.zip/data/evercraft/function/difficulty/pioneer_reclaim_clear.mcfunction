# Pioneer's Memento — Clear the single-use snapshot (macro: UUID).
# Called from pioneer_reclaim_confirm once a keepsake is sealed so the [Reclaim]
# button can never re-pour a past life from a stale chat line.
$data remove storage evercraft:pioneer preserved."$(UUID)"
data remove storage evercraft:pioneer args
