# ══════════════════════════════════════════════════════════════
# Pioneer Save-One-Item — Snapshot (UUID extract + dispatch)
# Run as: dying Pioneer player. Called from pioneer_death BEFORE
# strip_player_zero so the snapshot reads a live Inventory.
# ──────────────────────────────────────────────────────────────
# Stages the player's UUID into storage, then dispatches the macro
# inner that copies the ENTIRE Inventory list into preserved."<UUID>".full
# (Joseph 2026-06-15 redesign — main + armor + offhand, every entry
# keeping its Slot tag for a clean restore by the Memento reclaim flow).
# ══════════════════════════════════════════════════════════════
data modify storage evercraft:pioneer args.UUID set from entity @s UUID
function evercraft:difficulty/pioneer_snapshot_inner with storage evercraft:pioneer args
