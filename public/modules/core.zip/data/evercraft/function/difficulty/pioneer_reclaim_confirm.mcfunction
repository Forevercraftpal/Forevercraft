# ══════════════════════════════════════════════════════════════
# Pioneer's Memento — Confirm the keepsake (Joseph 2026-06-15)
# Run as @s = a sneaking reclaimer (at @s).
# ──────────────────────────────────────────────────────────────
# Captures the HELD (selected) item. If the hand is empty/air, it
# re-prompts and stays rooted ("until they choose"). Otherwise it
# wipes EVERYTHING (inventory + armor + offhand) and restores only
# that one item, unroots, and clears the snapshot so a stale chat
# click can never reclaim twice.
# ══════════════════════════════════════════════════════════════
data remove storage evercraft:pioneer keep
data modify storage evercraft:pioneer keep set from entity @s SelectedItem
execute if data storage evercraft:pioneer keep{id:"minecraft:air"} run data remove storage evercraft:pioneer keep
execute unless data storage evercraft:pioneer keep run return run title @s actionbar [{text:"Hold the item you wish to keep, then sneak.",color:"red"}]

# Re-bind the kept item to hotbar slot 0, wipe all, restore the one keeper.
data modify storage evercraft:pioneer keep.Slot set value 0b
clear @s
# MC 26.2 (1.21.5+): `data modify entity @s Inventory append` is read-only and silently no-op'd — the
# keepsake was being LOST. Restore it via a writable hopper-minecart -> `item replace` into hotbar.0
# (keep already carries Slot:0b for the cart's container slot 0).
# NOTE: the cart MUST be summoned WITH a slot-0 placeholder item. `data modify ... Items[0] set from`
# on an EMPTY list is a silent no-op (index 0 doesn't exist — it does NOT append), which left the
# cart empty and made `item replace ... container.0` write AIR — i.e. the keepsake was deleted. The
# stone placeholder gives index 0 an element for `set from` to overwrite (mirrors spirit/* carts).
data modify entity @e[type=hopper_minecart,tag=ec.pio_cart,limit=1] Items set value []
kill @e[type=hopper_minecart,tag=ec.pio_cart]
execute at @s run summon hopper_minecart ~ ~ ~ {Tags:["ec.pio_cart"],Enabled:0b,Items:[{Slot:0b,id:"minecraft:stone",count:1}]}
data modify entity @e[type=hopper_minecart,tag=ec.pio_cart,limit=1] Items[0] set from storage evercraft:pioneer keep
item replace entity @s hotbar.0 from entity @e[type=hopper_minecart,tag=ec.pio_cart,limit=1] container.0
data modify entity @e[type=hopper_minecart,tag=ec.pio_cart,limit=1] Items set value []
kill @e[type=hopper_minecart,tag=ec.pio_cart]

# Unroot (remove both modifiers by id).
attribute @s movement_speed modifier remove evercraft:pioneer_root
attribute @s minecraft:jump_strength modifier remove evercraft:pioneer_root

# Close the death-flow + single-use snapshot wipe (UUID -> macro clear).
tag @s remove pioneer.reclaiming
tag @s remove pioneer.choosing
data remove storage evercraft:pioneer keep
data modify storage evercraft:pioneer args.UUID set from entity @s UUID
function evercraft:difficulty/pioneer_reclaim_clear with storage evercraft:pioneer args

# Feedback.
title @s title {text:"Kept",color:"gold"}
tellraw @s [{text:" ✦ ",color:"light_purple"},{text:"One keepsake remains. The rest returns to the dream.",color:"yellow",italic:true}]
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.8 1.4
