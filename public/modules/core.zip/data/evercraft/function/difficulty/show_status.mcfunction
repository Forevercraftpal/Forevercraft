# Difficulty — Show Status (locked)
# @s = player, #_diff_now ec.temp = days since last choice (already computed)
# Displays current difficulty mode + days remaining until refresh

# Calculate remaining days
scoreboard players set #_diff_remain ec.temp 14
scoreboard players operation #_diff_remain ec.temp -= #_diff_now ec.temp

execute if score @s ec.difficulty matches 1 run data modify storage evercraft:notify stage.c set value [{text:"\u2726 ",color:"green"},{text:"Current Difficulty: ",color:"gray"},{text:"Newcomer",color:"green",bold:true},{text:" \u2726",color:"green"}]
execute if score @s ec.difficulty matches 2 run data modify storage evercraft:notify stage.c set value [{text:"\u2726 ",color:"red"},{text:"Current Difficulty: ",color:"gray"},{text:"Adventurer",color:"red",bold:true},{text:" \u2726",color:"red"}]
scoreboard players set #ndur ec.temp 50
execute if score @s ec.difficulty matches 1..2 run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Refreshes in ",color:"dark_gray"},{score:{name:"#_diff_remain",objective:"ec.temp"},color:"yellow"},{text:" day(s).",color:"dark_gray"}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit
