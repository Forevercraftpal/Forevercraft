# ══════════════════════════════════════════════════════════════
# Pioneer's Memento — Choose-loop tick (Joseph 2026-06-15)
# Self-scheduling 4t loop, alive ONLY while a player is mid-reclaim.
# Shows the standing instruction and, when a reclaimer sneaks, runs
# the confirm (keep held item, wipe the rest). Stops rescheduling
# once nobody is reclaiming, so it adds no permanent tick cost.
# Re-kicked on rejoin by reconnect/dispatch (relog-safety).
# ══════════════════════════════════════════════════════════════
execute unless entity @a[tag=pioneer.reclaiming] run return 0

title @a[tag=pioneer.reclaiming] actionbar [{text:"Hold the item to keep, then ",color:"gray"},{text:"sneak",color:"gold",bold:true},{text:" to seal it.",color:"gray"}]
execute as @a[tag=pioneer.reclaiming] at @s if predicate evercraft:is_sneaking run function evercraft:difficulty/pioneer_reclaim_confirm

schedule function evercraft:difficulty/pioneer_reclaim_tick 4t replace
