# Pioneer Continue — Player chooses to stay on Pioneer difficulty
execute unless entity @s[tag=pioneer.choosing] run return 0

# Unified UI-click FX (Joseph 2026-06-05): tellraw-option click — play the gated cue once on a valid pick.
function evercraft:fx/ui/click

scoreboard players set @s ec.difficulty 3
# Joseph 2026-06-13 (#93): keep pioneer.choosing through step 3 (Memento). The
# emit_memento function clears both pioneer.step3 and pioneer.choosing when the
# save-one offer is committed (or when the toggle is OFF).
execute if entity @s[tag=pioneer.step2] run function evercraft:difficulty/pioneer_emit_memento
execute unless entity @s[tag=pioneer.step2] run tag @s remove pioneer.choosing

# Re-enable triggers so post-rebirth buttons (path pick, difficulty pick) work
scoreboard players enable @s sm.pick
scoreboard players enable @s sm.path_pick
scoreboard players enable @s ec.diff_trigger

# Joseph 2026-06-17 (#94): re-emit the Chronicle path picker. The strip wiped
# sm.path to 0 and the death-flow never re-ran the picker, so set_path ->
# dispatch_start -> chN/start never fired and the player was wedged at chapter 1
# step 0. Mirrors difficulty/choose:60 (the new-player path prompt). The click
# (sm.path_pick, enabled just above) drives set_path -> dispatch_start, which
# sets sm.step=1 and starts the chapter.
execute if score @s sm.mode matches 1..2 run function evercraft:story/mode/choose_path

data modify storage evercraft:notify stage.c set value [{text:"You walk the hardest path. May the dreams sustain you.",color:gray,italic:true}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.ender_dragon.growl master @s ~ ~ ~ 0.3 1.5
