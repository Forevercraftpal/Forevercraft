# Sapling Auto-Replant — Scheduled every 5 seconds
# Saplings on the ground for 30+ seconds have a 33% chance to plant themselves
# Uses a scoreboard timer on item entities (incremented every 5s, triggers at 6 = 30s)
# Gives up after 3 failed attempts to prevent over-replanting

# Re-schedule
schedule function evercraft:world/sapling_replant/tick 5s

# Track sapling age — OnGround removed since items on partial blocks (farmland, etc.)
# don't reliably register as grounded. try_plant validates position before planting.
# Joseph 2026-06-07 FIX (saplings rest on ground but never plant): all three scans capped at a GLOBAL
# unsorted limit=20/10 — on a live server with >20 loaded item entities the specific sapling almost
# never landed in the sample, so it never aged → never planted (worsened as the server got busier).
# Raised the caps to 256 (covers every realistic loaded-item count; items only exist in loaded chunks)
# so every sapling ages + plants. Existence-gate skips item-free worlds.
execute if entity @e[type=item,limit=1] as @e[type=item,limit=256] if items entity @s contents #evercraft:saplings run scoreboard players add @s ec.sapling_age 1

# At 6 ticks (30 seconds), attempt to plant. The 3-try cap now lives INSIDE try_plant, NOT in this
# selector. Joseph 2026-06-20 FIX (saplings never plant on valid ground): the old gate was
# scores={ec.sapling_age=6..,ec.sapling_try=..2}, but a freshly-dropped sapling has NO ec.sapling_try
# score, and an UNSET score never matches a ranged selector — so every fresh sapling was skipped,
# try_plant (the ONLY writer of ec.sapling_try) never ran, the score stayed unset, and nothing ever
# planted (a permanent deadlock; this is the one gate crops never had, which is why crops worked).
# Gating on ec.sapling_age alone (always set by the add above) lets fresh saplings through; try_plant
# self-bails once ec.sapling_try reaches 3.
execute as @e[type=item,scores={ec.sapling_age=6..},limit=256] at @s run function evercraft:world/sapling_replant/try_plant

# Reset timer so they get another chance in 30s if they didn't plant
scoreboard players set @e[type=item,scores={ec.sapling_age=6..},limit=256] ec.sapling_age 0
