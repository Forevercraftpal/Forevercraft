# Timber (5% Any Axe) — marker arrival hook (lag audit 2026-06-22)
# Fired by the inventory_changed advancement world/timber/has_marker the instant a timber marker
# stick enters inventory (from any source — loot/give). Tags the player so world/timber/tick
# processes them on its next 2t pass WITHOUT the old per-player full-inventory scan, then revokes
# the advancement so it can re-fire for the next marker.
tag @s add ec.timber_pending
advancement revoke @s only evercraft:world/timber/has_marker
