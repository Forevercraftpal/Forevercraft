# Timber (5% Any Axe) — Tick Function
# Runs every 2 ticks via schedule.
# Lag audit 2026-06-22: the old `as @a if items entity @s inventory.*` ran a full 36-slot NBT scan
# on EVERY online player every 2t, hunting a marker that exists ~1 tick after a 5% axe-chop. Now an
# inventory_changed advancement (world/timber/has_marker -> on_marker) tags ec.timber_pending the
# instant a marker arrives, so this tick only scans the rare just-tagged player. Felling timing and
# behaviour are unchanged (activate still clears the marker + fells); idle cost drops to ~zero.

# Re-schedule
schedule function evercraft:world/timber/tick 2t

# Process players a marker just reached (tag-gated). activate clears the marker + fells the tree;
# the tag is one-shot — cleared every pass so a miss (no tree aimed at) can never leave it stuck.
execute as @a[tag=ec.timber_pending] if items entity @s inventory.* *[custom_data~{ec_timber_marker:1b}] run function evercraft:world/timber/activate
tag @a[tag=ec.timber_pending] remove ec.timber_pending
