# Crop Seed Auto-Replant — Scheduled every 2 seconds
# Seeds and plantable crops on farmland/soul_sand auto-plant themselves
# Similar to sapling replant but immediate (no timer) since farming is active gameplay

# Re-schedule
schedule function evercraft:world/crop_replant/tick 2s

# Find seed items near farmland/soul_sand and auto-plant them
# Note: OnGround removed — farmland is a partial block (15/16 height) and items
# resting on it don't reliably register as "on ground". Scan safely handles all positions.
# Joseph 2026-06-07 FIX (seeds rest on farmland but never plant): the cap was limit=20, a GLOBAL
# unsorted pick of 20 arbitrary item entities. On a live server there are routinely >20 items loaded
# (mob loot, other players' drops), so the specific seed almost never landed in the sampled 20 and was
# silently skipped — worsening as the server got busier. Raised to 256 (covers every realistic loaded-
# item count; item entities only exist in loaded chunks anyway) + existence-gate so an item-free world
# does no work. Each @e item is still enumerated exactly once (no double-processing).
execute if entity @e[type=item,limit=1] as @e[type=item,limit=256] if items entity @s contents #evercraft:plantable_crops at @s run function evercraft:world/crop_replant/try_plant
