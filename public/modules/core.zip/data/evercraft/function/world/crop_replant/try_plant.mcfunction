# Crop Seed Auto-Replant — Try to plant this seed item
# Run as item entity at its position
# Direct block checks — no macros/storage (eliminates silent failures)
# Two Y checks per crop: item IN farmland block, or item ABOVE farmland

scoreboard players set #planted ec.temp 0

# === Wheat Seeds ===
execute if score #planted ec.temp matches 0 if items entity @s contents minecraft:wheat_seeds if block ~ ~ ~ minecraft:farmland if block ~ ~1 ~ minecraft:air store success score #planted ec.temp run setblock ~ ~1 ~ minecraft:wheat[age=0]
execute if score #planted ec.temp matches 0 if items entity @s contents minecraft:wheat_seeds if block ~ ~-1 ~ minecraft:farmland if block ~ ~ ~ minecraft:air store success score #planted ec.temp run setblock ~ ~ ~ minecraft:wheat[age=0]

# === Carrots ===
execute if score #planted ec.temp matches 0 if items entity @s contents minecraft:carrot if block ~ ~ ~ minecraft:farmland if block ~ ~1 ~ minecraft:air store success score #planted ec.temp run setblock ~ ~1 ~ minecraft:carrots[age=0]
execute if score #planted ec.temp matches 0 if items entity @s contents minecraft:carrot if block ~ ~-1 ~ minecraft:farmland if block ~ ~ ~ minecraft:air store success score #planted ec.temp run setblock ~ ~ ~ minecraft:carrots[age=0]

# === Potatoes ===
execute if score #planted ec.temp matches 0 if items entity @s contents minecraft:potato if block ~ ~ ~ minecraft:farmland if block ~ ~1 ~ minecraft:air store success score #planted ec.temp run setblock ~ ~1 ~ minecraft:potatoes[age=0]
execute if score #planted ec.temp matches 0 if items entity @s contents minecraft:potato if block ~ ~-1 ~ minecraft:farmland if block ~ ~ ~ minecraft:air store success score #planted ec.temp run setblock ~ ~ ~ minecraft:potatoes[age=0]

# === Beetroot Seeds ===
execute if score #planted ec.temp matches 0 if items entity @s contents minecraft:beetroot_seeds if block ~ ~ ~ minecraft:farmland if block ~ ~1 ~ minecraft:air store success score #planted ec.temp run setblock ~ ~1 ~ minecraft:beetroots[age=0]
execute if score #planted ec.temp matches 0 if items entity @s contents minecraft:beetroot_seeds if block ~ ~-1 ~ minecraft:farmland if block ~ ~ ~ minecraft:air store success score #planted ec.temp run setblock ~ ~ ~ minecraft:beetroots[age=0]

# === Melon Seeds ===
execute if score #planted ec.temp matches 0 if items entity @s contents minecraft:melon_seeds if block ~ ~ ~ minecraft:farmland if block ~ ~1 ~ minecraft:air store success score #planted ec.temp run setblock ~ ~1 ~ minecraft:melon_stem[age=0]
execute if score #planted ec.temp matches 0 if items entity @s contents minecraft:melon_seeds if block ~ ~-1 ~ minecraft:farmland if block ~ ~ ~ minecraft:air store success score #planted ec.temp run setblock ~ ~ ~ minecraft:melon_stem[age=0]

# === Pumpkin Seeds ===
execute if score #planted ec.temp matches 0 if items entity @s contents minecraft:pumpkin_seeds if block ~ ~ ~ minecraft:farmland if block ~ ~1 ~ minecraft:air store success score #planted ec.temp run setblock ~ ~1 ~ minecraft:pumpkin_stem[age=0]
execute if score #planted ec.temp matches 0 if items entity @s contents minecraft:pumpkin_seeds if block ~ ~-1 ~ minecraft:farmland if block ~ ~ ~ minecraft:air store success score #planted ec.temp run setblock ~ ~ ~ minecraft:pumpkin_stem[age=0]

# === Torchflower Seeds ===
execute if score #planted ec.temp matches 0 if items entity @s contents minecraft:torchflower_seeds if block ~ ~ ~ minecraft:farmland if block ~ ~1 ~ minecraft:air store success score #planted ec.temp run setblock ~ ~1 ~ minecraft:torchflower_crop[age=0]
execute if score #planted ec.temp matches 0 if items entity @s contents minecraft:torchflower_seeds if block ~ ~-1 ~ minecraft:farmland if block ~ ~ ~ minecraft:air store success score #planted ec.temp run setblock ~ ~ ~ minecraft:torchflower_crop[age=0]

# === Pitcher Pod ===
execute if score #planted ec.temp matches 0 if items entity @s contents minecraft:pitcher_pod if block ~ ~ ~ minecraft:farmland if block ~ ~1 ~ minecraft:air store success score #planted ec.temp run setblock ~ ~1 ~ minecraft:pitcher_crop[age=0]
execute if score #planted ec.temp matches 0 if items entity @s contents minecraft:pitcher_pod if block ~ ~-1 ~ minecraft:farmland if block ~ ~ ~ minecraft:air store success score #planted ec.temp run setblock ~ ~ ~ minecraft:pitcher_crop[age=0]

# === Nether Wart ===
execute if score #planted ec.temp matches 0 if items entity @s contents minecraft:nether_wart if block ~ ~ ~ minecraft:soul_sand if block ~ ~1 ~ minecraft:air store success score #planted ec.temp run setblock ~ ~1 ~ minecraft:nether_wart[age=0]
execute if score #planted ec.temp matches 0 if items entity @s contents minecraft:nether_wart if block ~ ~-1 ~ minecraft:soul_sand if block ~ ~ ~ minecraft:air store success score #planted ec.temp run setblock ~ ~ ~ minecraft:nether_wart[age=0]

# If planted, consume one seed and show feedback
execute if score #planted ec.temp matches 1 run function evercraft:world/crop_replant/consume_one
