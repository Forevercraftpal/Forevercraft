# Debug: Test crop replant detection
# Run manually: /function evercraft:world/crop_replant/debug

# Count all item entities
execute store result score #debug_all ec.temp if entity @e[type=item,limit=100]
tellraw @a [{text:"[Crop Debug] ",color:"gold"},{text:"Total items: ",color:"white"},{score:{name:"#debug_all",objective:"ec.temp"}}]

# Count items matching plantable_crops tag
scoreboard players set #debug_crops ec.temp 0
execute as @e[type=item,limit=100] if items entity @s contents #evercraft:plantable_crops run scoreboard players add #debug_crops ec.temp 1
tellraw @a [{text:"[Crop Debug] ",color:"gold"},{text:"Plantable items: ",color:"white"},{score:{name:"#debug_crops",objective:"ec.temp"}}]

# Try to plant the nearest one and report
execute as @e[type=item,limit=1,sort=nearest] if items entity @s contents #evercraft:plantable_crops at @s run tellraw @a [{text:"[Crop Debug] ",color:"gold"},{text:"Found seed at: ",color:"white"},{text:""},{"nbt":"Pos","entity":"@s"}]
execute as @e[type=item,limit=1,sort=nearest] if items entity @s contents #evercraft:plantable_crops at @s run tellraw @a [{text:"[Crop Debug] ",color:"gold"},{text:"Block here: ",color:"white"},{text:""},{"nbt":"{}","block":"~ ~ ~","interpret":false}]
execute as @e[type=item,limit=1,sort=nearest] if items entity @s contents #evercraft:plantable_crops at @s run tellraw @a [{text:"[Crop Debug] ",color:"gold"},{text:"Block below: ",color:"white"},{text:""},{"nbt":"{}","block":"~ ~-1 ~","interpret":false}]
execute as @e[type=item,limit=1,sort=nearest] if items entity @s contents #evercraft:plantable_crops at @s run tellraw @a [{text:"[Crop Debug] ",color:"gold"},{text:"Block above: ",color:"white"},{text:""},{"nbt":"{}","block":"~ ~1 ~","interpret":false}]

# Test raw setblock
execute as @e[type=item,limit=1,sort=nearest] if items entity @s contents minecraft:wheat_seeds at @s if block ~ ~ ~ minecraft:farmland if block ~ ~1 ~ minecraft:air run tellraw @a [{text:"[Crop Debug] ",color:"green"},{text:"MATCH: farmland at pos, air above — trying setblock"}]
execute as @e[type=item,limit=1,sort=nearest] if items entity @s contents minecraft:wheat_seeds at @s if block ~ ~-1 ~ minecraft:farmland if block ~ ~ ~ minecraft:air run tellraw @a [{text:"[Crop Debug] ",color:"green"},{text:"MATCH: farmland below, air at pos — trying setblock"}]

# If neither matched
execute as @e[type=item,limit=1,sort=nearest] if items entity @s contents minecraft:wheat_seeds at @s unless block ~ ~ ~ minecraft:farmland unless block ~ ~-1 ~ minecraft:farmland run tellraw @a [{text:"[Crop Debug] ",color:"red"},{text:"NO farmland found at item pos or below!"}]
