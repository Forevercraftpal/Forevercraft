# Allowance of Dreams — Daily Forever Coin grant scaled by Dream Rate
# Run as player
# Base: 5 coins. +1 per 2 DR levels. Cap: 30 coins/day.
# DR 0 = 5, DR 10 = 10, DR 20 = 15, DR 30 = 20, DR 40 = 25, DR 50 = 30

# Get player's Dream Rate (luck attribute, whole number)
execute store result score #ad_dr ec.temp run attribute @s minecraft:luck get

# Calculate bonus: DR / 2 (integer division)
scoreboard players operation #ad_dr ec.temp /= #2 ec.const

# Total = base 5 + bonus
scoreboard players set #coin_amount ec.temp 5
scoreboard players operation #coin_amount ec.temp += #ad_dr ec.temp

# Cap at 30
execute if score #coin_amount ec.temp matches 31.. run scoreboard players set #coin_amount ec.temp 30

# Header announcement (before grant notification)
data modify storage evercraft:notify stage.c set value [{text:"✦ Allowance of Dreams ✦",color:"#E0B0FF",bold:true}]
scoreboard players set #ndur ec.temp 50
function evercraft:util/notify/emit

# Grant coins (prints its own "+X Forever Coin (Total: Y)" line + sound)
function evercraft:gacha/coin/grant

# Details
data modify storage evercraft:notify stage.c set value [{text:"Daily allowance: ",color:"gray"},{score:{name:"#coin_amount",objective:"ec.temp"},color:"gold",bold:true},{text:" coins",color:"gray"}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"(+",color:"dark_gray"},{score:{name:"#ad_dr",objective:"ec.temp"},color:"#E0B0FF"},{text:" bonus from Dream Rate)",color:"dark_gray"}]
scoreboard players set #ndur ec.temp 40
execute if score #ad_dr ec.temp matches 1.. run function evercraft:util/notify/emit

# Extra dreamy chime on top of grant's sound
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.6 1.5

# === DAILY FREE WISH — "a gift that waits" (FOMO-free) ===
# Bank one free fountain pull, accumulating up to a cap of 5 so a week away is
# never punished. No streak, no countdown, no penalty: if the player wasn't here,
# the elapsed-time rail in world/daily_gift simply grants the backlog on return.
scoreboard players add @s ec.free_pulls 1
execute if score @s ec.free_pulls matches 6.. run scoreboard players set @s ec.free_pulls 5
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"#E0B0FF"},{text:"The fountain has saved a wish for you. ",color:"#E0B0FF"},{text:"No rush — it will wait.",color:"gray",italic:true},{text:" ✦",color:"#E0B0FF"}]
scoreboard players set #ndur ec.temp 45
execute if score @s ec.free_pulls matches 1.. run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"(",color:"dark_gray"},{score:{name:"@s",objective:"ec.free_pulls"},color:"#E0B0FF"},{text:" free wishes are waiting at the Fountain)",color:"dark_gray"}]
scoreboard players set #ndur ec.temp 40
execute if score @s ec.free_pulls matches 2.. run function evercraft:util/notify/emit
execute if score @s ec.free_pulls matches 1.. if score @s ec.fx_snd matches 1.. run playsound minecraft:block.amethyst_block.resonate master @s ~ ~ ~ 0.5 1.7
