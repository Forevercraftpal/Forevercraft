# Command Whistle voice — note 3 of 3: do' (F#5, top of range), then clear the marker
# tag @a remove also self-heals any tag left by a player who logged out mid-roll.
execute as @a[tag=ec.whistle_call] at @s if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.flute master @s ~ ~ ~ 0.7 2.0
tag @a remove ec.whistle_call
