# Command Whistle voice — note 2 of 3: sol (C#5)
# Scheduled ~2t after whistle_call; runs detached, so target the tagged player.
execute as @a[tag=ec.whistle_call] at @s if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.flute master @s ~ ~ ~ 0.7 1.498307
schedule function evercraft:util/sfx/whistle_call_3 2t replace
