# Petting flourish — note 2 of 3: mi (A#4)
# Scheduled ~3t after pet_chime; runs detached, so target the tagged player.
execute as @a[tag=ec.pet_chime] at @s if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.harp master @s ~ ~ ~ 0.6 1.259921
schedule function evercraft:util/sfx/pet_chime_3 3t replace
