# Petting flourish — note 3 of 3: sol (C#5), then clear the marker
# tag @a remove also self-heals any tag left by a player who logged out mid-roll.
execute as @a[tag=ec.pet_chime] at @s if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.harp master @s ~ ~ ~ 0.6 1.498307
tag @a remove ec.pet_chime
