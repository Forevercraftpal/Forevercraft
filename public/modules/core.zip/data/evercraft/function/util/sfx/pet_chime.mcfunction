# ============================================================
# Petting flourish — cute 3-note ascending harp arpeggio
# Run as: the petting player, at their position (plays to @s only).
# Replaces the old entity.wolf.whine pet sound across all pet paths.
# Notes roll ~3t apart: do (F#4) -> mi (A#4) -> sol (C#5).
# ============================================================

# Note 1 — do (root), immediately for the petting player
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.harp master @s ~ ~ ~ 0.6 1.0

# Mark this player so the scheduled follow-up notes know who to play to
tag @s add ec.pet_chime
schedule function evercraft:util/sfx/pet_chime_2 3t replace
