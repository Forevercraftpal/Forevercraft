# ============================================================
# Command Whistle voice — bright 3-note flute call
# Run as: the whistling player, at their position (plays to @s only).
# Replaces the vanilla goat-horn blast (silenced via the item's instrument).
# Notes roll ~2t apart, brighter/snappier than the pet flourish:
#   mi (A#4) -> sol (C#5) -> do' (F#5).
# ============================================================

# Note 1 — mi, immediately for the whistling player
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.flute master @s ~ ~ ~ 0.7 1.259921

# Mark this player so the scheduled follow-up notes know who to play to
tag @s add ec.whistle_call
schedule function evercraft:util/sfx/whistle_call_2 2t replace
