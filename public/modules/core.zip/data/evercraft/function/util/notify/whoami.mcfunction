# Bake @s's profile NAME into storage (run as @s = the actor, at any position).
# Writes: storage evercraft:notify named.who = "<PlayerName>" (string).
# The §5b unlock (Wave 2, Joseph 2026-06-10): actor-naming broadcasts could never ride the queue
# because {selector:"@s"} re-resolves as each VIEWER at render time. With the name baked to a
# string, call sites stage their component with an empty name slot and fill it:
#   function evercraft:util/notify/whoami
#   data modify storage evercraft:notify stage.c set value [{text:"",color:"white"},{text:" did a thing!",color:"gray"}]
#   data modify storage evercraft:notify stage.c[0].text set from storage evercraft:notify named.who
#   scoreboard players set #ndur ec.temp 50
#   execute as @a run function evercraft:util/notify/emit_keep
# Idiom: fixed-UUID item_display + fill_player_head + profile.name (proven in
# evercraft:treasure/database/name/check). UUID [I;0,0,0,9] is unique to this helper (1 and 2
# are taken elsewhere). Cost: summon + item modify + data get + kill — fine for one-shot
# announcements; NEVER call from a per-tick loop.
# Defensive: reap a stale display first (a crash between summon and kill would make the next
# summon fail silently — harmless thanks to entity:this, but this keeps the slot clean; race seat).
kill 0-0-0-0-9
summon item_display ~ ~ ~ {UUID:[I;0,0,0,9],view_range:0f,width:0f,height:0f,item:{id:"minecraft:player_head",count:1}}
item modify entity 0-0-0-0-9 container.0 {function:fill_player_head,entity:this}
data modify storage evercraft:notify named.who set from entity 0-0-0-0-9 item.components.minecraft:profile.name
kill 0-0-0-0-9
