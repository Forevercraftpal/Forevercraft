# Trigger handler — player clicked [Mute] on a Tinkering soft-offer (alert)
# Run as @s (player) from tick dispatcher
scoreboard players set @s ec.nm_tnk_offer 0
scoreboard players enable @s ec.nm_tnk_offer
function evercraft:util/notify/mute_set {key:"tnk_offer",label:"Tinkerer's Path begin offer"}
