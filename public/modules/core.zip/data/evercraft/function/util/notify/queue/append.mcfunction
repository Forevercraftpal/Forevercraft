# Append the staged frame to this player's queue (macro; arg: slot)
# Backlog guard: queue holds up to 16 frames; the drain in queue/advance keeps it moving so this
# last-resort drop is hit only under pathological spam. The drop victim is the NEWEST pending
# tail [-1], NOT the front [0] (Wave 0 fix, Joseph 2026-06-10): after an emit_now/emit_crit the
# front holds a PRIORITY frame — the old drop-[0] policy deleted the most important message
# first under flood. Newest chatter dies, the priority front survives; staleness in the rest of
# the queue is the TTL field's job (queue/drop_expired), not this guard's.
scoreboard players set #qlen ec.temp 0
$execute store result score #qlen ec.temp run data get storage evercraft:notify q.s$(slot)
$execute if score #qlen ec.temp matches 16.. run data remove storage evercraft:notify q.s$(slot)[-1]
$data modify storage evercraft:notify q.s$(slot) append from storage evercraft:notify stage
# FADE-CUT (Wave 0, Joseph 2026-06-10): if the bar is only FADING leftover (no solid display —
# abhold has sunk into the fade tail), end the fade now so this frame renders on the next pump
# tick instead of waiting out up to ~50t of tail. Mid-SOLID display is never cut here (that
# privilege is emit_crit's). No-op when idle (abhold already 0).
execute if score @s ec.abhold matches 1.. if score @s ec.abhold <= @s ec.abfade run scoreboard players set @s ec.abhold 0
# Enter DRAIN MODE once 4+ frames are stopped up (this append makes the queue >=4). queue/advance then
# shortens every non-protected frame until the queue empties (cleared in queue/pump). #qlen is the
# PRE-append length, so >=3 means >=4 after this append. (Joseph 2026-06-06: ">3-4 stopped up -> shorten".)
execute if score #qlen ec.temp matches 3.. run scoreboard players set @s ec.abdrain 1
