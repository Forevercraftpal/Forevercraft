# Queue pump core (macro; arg: slot; run as @s)
# A frame's hold spans solid display + a fade tail; ec.abfade is how many of the remaining
# ticks are the (no-resend) fade. Render only while above the fade tail, so the action bar
# fades out on its own at the end. When the hold hits 0, advance to the next queued frame
# or drop the ab_q tag to go idle.
$execute if score @s ec.abhold > @s ec.abfade run function evercraft:util/notify/queue/render with storage evercraft:notify cur.s$(slot)
execute if score @s ec.abhold matches 1.. run scoreboard players remove @s ec.abhold 1
execute if score @s ec.abld matches 1.. run scoreboard players remove @s ec.abld 1
$execute if score @s ec.abhold matches ..0 if data storage evercraft:notify q.s$(slot)[0] run function evercraft:util/notify/queue/advance with storage evercraft:notify args
$execute if score @s ec.abhold matches ..0 unless data storage evercraft:notify q.s$(slot)[0] run tag @s remove ab_q
$execute if score @s ec.abhold matches ..0 unless data storage evercraft:notify q.s$(slot)[0] run scoreboard players set @s ec.abld 0
# Queue fully drained -> leave drain mode (next backlog re-enters it via queue/append).
$execute if score @s ec.abhold matches ..0 unless data storage evercraft:notify q.s$(slot)[0] run scoreboard players set @s ec.abdrain 0
