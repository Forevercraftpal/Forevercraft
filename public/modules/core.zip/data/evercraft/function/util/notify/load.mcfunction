# Mutable Notification System — Load
# All notification keys MUST be registered here at #minecraft:load time, not lazily.
# Compliance (R-1) + Performance (R-1) both require this: lazy in-macro `scoreboard
# objectives add` has no codebase precedent and breaks the first-click race because
# the per-key trigger isn't enabled for new players until the dispatch has fired once.
#
# 16-char scoreboard objective cap is the hard constraint (compliance R-2 / R-6):
#   ec.nm_<key>  → mute trigger    (key max 10 chars)
#   ec.un_<key>  → unmute trigger  (key max 10 chars; used by ecodex Notifications page)
#   ach.mu_<key> → muted flag      (key max 9 chars)
#   ach.nx_<key> → occurrence counter (key max 9 chars)
#   ach.ps_<id>  → personal-milestone seen-stage (id max 9 chars; "s130" fits)
#
# To add a new key: append a `Notify Key: <key>` block below + add a mute_dispatch/<key>.mcfunction
# + an unmute_dispatch/<key>.mcfunction + a row in ecodex/sections/notifications/refresh_page.mcfunction.

# === Notify Key: level_up (Plan A — companion level-ups, class:chatter, mute_at:3) ===
scoreboard objectives add ec.nm_level_up trigger "Mute Level-Up"
scoreboard objectives add ec.un_level_up trigger "Unmute Level-Up"
scoreboard objectives add ach.mu_level_up dummy "Muted: Level-Up"
scoreboard objectives add ach.nx_level_up dummy "Count: Level-Up"
scoreboard players enable @a ec.nm_level_up
scoreboard players enable @a ec.un_level_up

# === Notify Key: ms_stage (Plan C — personal milestone stage crossings, class:chatter, mute_at:8) ===
scoreboard objectives add ec.nm_ms_stage trigger "Mute Milestone Stage"
scoreboard objectives add ec.un_ms_stage trigger "Unmute Milestone Stage"
scoreboard objectives add ach.mu_ms_stage dummy "Muted: MS Stage"
scoreboard objectives add ach.nx_ms_stage dummy "Count: MS Stage"
scoreboard players enable @a ec.nm_ms_stage
scoreboard players enable @a ec.un_ms_stage

# === Notify Key: hearth (House passive proc "Hearth's Blessing", class:chatter, mute_at:3) ===
# Also registered in inscription/procs/load.mcfunction (the system that emits it); both
# registrars are idempotent. The House proc fires every 5 min so it can get repetitive —
# mute_at:3 surfaces the [Mute] button quickly.
scoreboard objectives add ec.nm_hearth trigger "Mute Hearth's Blessing"
scoreboard objectives add ec.un_hearth trigger "Unmute Hearth's Blessing"
scoreboard objectives add ach.mu_hearth dummy "Muted: Hearth"
scoreboard objectives add ach.nx_hearth dummy "Count: Hearth"
scoreboard players enable @a ec.nm_hearth
scoreboard players enable @a ec.un_hearth

# === Notify Key: bq_adv (Build Quests new-objective nudge, class:chatter, mute_at:8) ===
# Registered for the Build Quests engine (Council #2 Wave F1) — the FOUNDATION line
# every later Chronicle line clones. The advance nudge is chatter-class (low priority,
# repetitive), so it honors the global ec.notify filter + offers [Mute] after 8.
scoreboard objectives add ec.nm_bq_adv trigger "Mute Build-Quest Nudge"
scoreboard objectives add ec.un_bq_adv trigger "Unmute Build-Quest Nudge"
scoreboard objectives add ach.mu_bq_adv dummy "Muted: BQ Advance"
scoreboard objectives add ach.nx_bq_adv dummy "Count: BQ Advance"
scoreboard players enable @a ec.nm_bq_adv
scoreboard players enable @a ec.un_bq_adv

# === Notify Key: cq_adv (Cook's Questline new-objective nudge, class:chatter, mute_at:8) ===
# Registered for the Cook's Questline (Council #2 Wave C3 — the FIRST content slice).
# Same shape as bq_adv: chatter-class advance nudge that honors the global ec.notify
# filter + offers [Mute] after 8. (Key name matches the dispatch key in
# cooking/questline/on_advance_notify — "cq_adv" everywhere, no advance/adv split.)
scoreboard objectives add ec.nm_cq_adv trigger "Mute Cook-Quest Nudge"
scoreboard objectives add ec.un_cq_adv trigger "Unmute Cook-Quest Nudge"
scoreboard objectives add ach.mu_cq_adv dummy "Muted: CQ Advance"
scoreboard objectives add ach.nx_cq_adv dummy "Count: CQ Advance"
scoreboard players enable @a ec.nm_cq_adv
scoreboard players enable @a ec.un_cq_adv

# === Notify Key: chq_adv (Chemistry Questline new-objective nudge, class:chatter, mute_at:8) ===
# Registered for the Chemist's Questline (Council #2 Wave C4 — the Chemistry book,
# player-facing name "Chemistry", tied to the Healer class). Same shape as cq_adv:
# chatter-class advance nudge that honors the global ec.notify filter + offers [Mute]
# after 8. (Key name matches the dispatch key in alchemy/questline/on_advance_notify
# — "chq_adv" everywhere.)
scoreboard objectives add ec.nm_chq_adv trigger "Mute Chem-Quest Nudge"
scoreboard objectives add ec.un_chq_adv trigger "Unmute Chem-Quest Nudge"
scoreboard objectives add ach.mu_chq_adv dummy "Muted: CHQ Advance"
scoreboard objectives add ach.nx_chq_adv dummy "Count: CHQ Advance"
scoreboard players enable @a ec.nm_chq_adv
scoreboard players enable @a ec.un_chq_adv

# === Notify Key: fgq_adv (Forging Questline new-objective nudge, class:chatter, mute_at:8) ===
# Registered for the Smith's Questline (Council #2 Wave C4 — the Forging book that
# bridges into Tinkering). Same shape as cq_adv: chatter-class advance nudge that
# honors the global ec.notify filter + offers [Mute] after 8. (Key name matches the
# dispatch key in forging/questline/on_advance_notify — "fgq_adv" everywhere.)
scoreboard objectives add ec.nm_fgq_adv trigger "Mute Forge-Quest Nudge"
scoreboard objectives add ec.un_fgq_adv trigger "Unmute Forge-Quest Nudge"
scoreboard objectives add ach.mu_fgq_adv dummy "Muted: FGQ Advance"
scoreboard objectives add ach.nx_fgq_adv dummy "Count: FGQ Advance"
scoreboard players enable @a ec.nm_fgq_adv
scoreboard players enable @a ec.un_fgq_adv

# === Notify Key: ac_adv (Awakening / Adventure-A new-objective nudge, class:chatter, mute_at:8) ===
# Registered for The Awakening line (Council #2 Wave C5 — the FIRST Adventurer
# chronicle line: Dream / Board / Reputation-via-Reaper). Same shape as cq_adv:
# chatter-class advance nudge that honors the global ec.notify filter + offers [Mute]
# after 8. (Key name matches the dispatch key in adventure/questline/on_advance_notify
# — "ac_adv" everywhere, no advance/adv split.)
scoreboard objectives add ec.nm_ac_adv trigger "Mute Awakening Nudge"
scoreboard objectives add ec.un_ac_adv trigger "Unmute Awakening Nudge"
scoreboard objectives add ach.mu_ac_adv dummy "Muted: AC Advance"
scoreboard objectives add ach.nx_ac_adv dummy "Count: AC Advance"
scoreboard players enable @a ec.nm_ac_adv
scoreboard players enable @a ec.un_ac_adv

# === Notify Key: gq_fuse (Grand-Quests one-time fusion OFFER, class:alert, mute_at:99) ===
# Registered for the fishing quest book's one-shot fusion offer (Grand Convergence
# Wave 5 / Chronicles Wave W5 — the canonical book+offer TEMPLATE). UNLIKE the
# *_adv keys this is ALERT class (medium priority — it's a one-time convergence
# offer, not a repetitive nudge) and mute_at:99, so the [Mute] button effectively
# never appears (there is nothing to mute — the offer fires once per player,
# latched by ec.gq_offered). The key is still registered the standard way so the
# dispatch macro's `enable ec.nm_gq_fuse` + `add ach.nx_gq_fuse` hit real
# objectives, and so a manual Notifications-page mute has a route.
scoreboard objectives add ec.nm_gq_fuse trigger "Mute Fusion Offer"
scoreboard objectives add ec.un_gq_fuse trigger "Unmute Fusion Offer"
scoreboard objectives add ach.mu_gq_fuse dummy "Muted: GQ Fuse"
scoreboard objectives add ach.nx_gq_fuse dummy "Count: GQ Fuse"
scoreboard players enable @a ec.nm_gq_fuse
scoreboard players enable @a ec.un_gq_fuse

# === Notify Key: ac_offer (The Awakening one-time soft-offer, class:alert, mute_at:99) ===
# Registered for the soft "[Begin the Adventure Chronicle ->]" auto-offer (Council #2
# Wave C5, S9) fired by dream_rank/rank_up's +1 gated line on a dream-rank gain,
# gated ec.chron_view 1/3 + ec.ac_active 0, one-shot (latched by ec.ac_offer). Like
# gq_fuse this is ALERT class + mute_at:99 (a one-time offer, not a repetitive nudge
# — the [Mute] button effectively never appears; the offer fires once per player).
# Registered the standard way so the dispatch macro's enable/counter hit real
# objectives and a manual Notifications-page mute has a route.
scoreboard objectives add ec.nm_ac_offer trigger "Mute Awakening Offer"
scoreboard objectives add ec.un_ac_offer trigger "Unmute Awakening Offer"
scoreboard objectives add ach.mu_ac_offer dummy "Muted: AC Offer"
scoreboard objectives add ach.nx_ac_offer dummy "Count: AC Offer"
scoreboard players enable @a ec.nm_ac_offer
scoreboard players enable @a ec.un_ac_offer

# === Notify Key: ak_adv (Build & Conquer / Adventure-B new-objective nudge, class:chatter, mute_at:8) ===
# Registered for the Build & Conquer line (Council #2 Wave C6 — the SECOND Adventurer
# chronicle line: Glyphs / Kingdom / Conquest). Same shape as ac_adv: chatter-class
# advance nudge that honors the global ec.notify filter + offers [Mute] after 8. (Key
# name matches the dispatch key in adventure/kingdom/on_advance_notify — "ak_adv"
# everywhere, no advance/adv split.)
scoreboard objectives add ec.nm_ak_adv trigger "Mute B&C Nudge"
scoreboard objectives add ec.un_ak_adv trigger "Unmute B&C Nudge"
scoreboard objectives add ach.mu_ak_adv dummy "Muted: AK Advance"
scoreboard objectives add ach.nx_ak_adv dummy "Count: AK Advance"
scoreboard players enable @a ec.nm_ak_adv
scoreboard players enable @a ec.un_ak_adv

# === Notify Key: ak_offer (Build & Conquer one-time soft-offer, class:alert, mute_at:99) ===
# Registered for the soft "[Begin Build & Conquer ->]" auto-offer (Council #2 Wave C6,
# S9) fired by guild/announce_create's +1 gated line on a guild creation, gated
# ec.chron_view 1/3 + ec.ak_active 0 + ec.ac_active matches 2 (sequenced AFTER
# Adventure-A), one-shot (latched by ec.ak_offer). Like ac_offer this is ALERT class +
# mute_at:99 (a one-time offer, not a repetitive nudge — the [Mute] button effectively
# never appears; the offer fires once per player). Registered the standard way so the
# dispatch macro's enable/counter hit real objectives and a manual Notifications-page
# mute has a route.
scoreboard objectives add ec.nm_ak_offer trigger "Mute B&C Offer"
scoreboard objectives add ec.un_ak_offer trigger "Unmute B&C Offer"
scoreboard objectives add ach.mu_ak_offer dummy "Muted: AK Offer"
scoreboard objectives add ach.nx_ak_offer dummy "Count: AK Offer"
scoreboard players enable @a ec.nm_ak_offer
scoreboard players enable @a ec.un_ak_offer

# === Notify Key: tnk_adv (Tinkering / the universal mini-line new-objective nudge,
# class:chatter, mute_at:8) ===
# Registered for the Tinkering line (Council #2 Wave C7 — the UNIVERSAL "combining artifacts"
# line shown in BOTH chronicle tiers). Same shape as ak_adv: chatter-class advance nudge that
# honors the global ec.notify filter + offers [Mute] after 8. (Key name matches the dispatch
# key in tinkering/on_advance_notify — "tnk_adv" everywhere.)
scoreboard objectives add ec.nm_tnk_adv trigger "Mute Tinkering Nudge"
scoreboard objectives add ec.un_tnk_adv trigger "Unmute Tinkering Nudge"
scoreboard objectives add ach.mu_tnk_adv dummy "Muted: TNK Advance"
scoreboard objectives add ach.nx_tnk_adv dummy "Count: TNK Advance"
scoreboard players enable @a ec.nm_tnk_adv
scoreboard players enable @a ec.un_tnk_adv

# === Notify Key: tnk_offer (Tinkering one-time soft-offer, class:alert, mute_at:99) ===
# Registered for the soft "[Begin the Tinkerer's Path ->]" auto-offer (Council #2 Wave C7, F)
# fired by artifacts/accessories/player_tick's +1 gated line the first time a player holds >=2
# accessories, one-shot (latched by ec.tnk_offer). UNIVERSAL (no ec.chron_view gate). Like
# ak_offer this is ALERT class + mute_at:99 (a one-time offer, not a repetitive nudge — the
# [Mute] button effectively never appears). Registered the standard way so the dispatch macro's
# enable/counter hit real objectives and a manual Notifications-page mute has a route.
scoreboard objectives add ec.nm_tnk_offer trigger "Mute Tinkering Offer"
scoreboard objectives add ec.un_tnk_offer trigger "Unmute Tinkering Offer"
scoreboard objectives add ach.mu_tnk_offer dummy "Muted: TNK Offer"
scoreboard objectives add ach.nx_tnk_offer dummy "Count: TNK Offer"
scoreboard players enable @a ec.nm_tnk_offer
scoreboard players enable @a ec.un_tnk_offer

# === Notify Key: fq_adv (Fisher's Questline new-objective nudge, class:chatter, mute_at:8) ===
# Registered for the Fisher's Path (Fisher rework 2026-06-10 — the line predated the pacing
# program; its on_advance_notify now routes through the dispatch layer like every sibling).
# Same shape as cq_adv: chatter-class advance nudge that honors the global ec.notify filter +
# offers [Mute] after 8. With 250 beats this is the most frequent adv key in the pack —
# the mute affordance matters most here. (Key name matches the dispatch key in
# fishing/questline/on_advance_notify — "fq_adv" everywhere.)
scoreboard objectives add ec.nm_fq_adv trigger "Mute Fisher-Quest Nudge"
scoreboard objectives add ec.un_fq_adv trigger "Unmute Fisher-Quest Nudge"
scoreboard objectives add ach.mu_fq_adv dummy "Muted: FQ Advance"
scoreboard objectives add ach.nx_fq_adv dummy "Count: FQ Advance"
scoreboard players enable @a ec.nm_fq_adv
scoreboard players enable @a ec.un_fq_adv

# === Add new keys here when registered ===
# Pattern: scoreboard objectives add ec.nm_<key> trigger / ec.un_<key> trigger / ach.mu_<key> dummy / ach.nx_<key> dummy
# Then enable both triggers for @a, add mute_dispatch + unmute_dispatch files, route in tick.mcfunction,
# add row in ecodex/sections/notifications/refresh_page.mcfunction, and zero in admin/strip_player_zero.mcfunction.

# === Action-Bar render queue (sequential notification display — chat→action-bar migration) ===
# The RENDER layer that sits under the policy layer above. dispatch.mcfunction still decides
# WHETHER a notification shows; emit.mcfunction + queue/* decide HOW (action bar, one frame at a
# time). ec.abslot keys each player's frame queue in storage; ec.abhold counts down the current
# frame; ec.abinit latches one-time slot assignment. $next on ec.abslot is the slot high-water mark.
scoreboard objectives add ec.abslot dummy "AB Queue Slot"
scoreboard objectives add ec.abhold dummy "AB Frame Hold"
scoreboard objectives add ec.abinit dummy "AB Slot Assigned"
scoreboard objectives add ec.abgap dummy "AB Fade Gap"
scoreboard objectives add ec.abfade dummy "AB Fade Remaining"
# Drain mode (Joseph 2026-06-06): set to 1 when 4+ frames stop up (queue/append), cleared when the
# queue empties (queue/pump). While 1, queue/advance shortens every NON-protected frame so a backlog
# (and its tail) clears fast; protected frames (stage.p=1, e.g. story dialog) are exempt and stay full.
scoreboard objectives add ec.abdrain dummy "AB Drain Mode"
# Fade-gap length in ticks: the no-refresh tail after each frame's solid display, during
# which the action bar fades out on its own. Live-tunable: /scoreboard players set $gap ec.abgap <ticks>
# Higher = longer, more visible fade + slower cadence. ~50t ≈ a clear ~2.5s fade-out.
scoreboard players set $gap ec.abgap 50
# Metered-backlog divisor (constant 2) used by queue/advance to compress backed-up frames.
scoreboard players set $two ec.abgap 2
# Debounce (emit_keyed): a repeat of the same key within $dwin ticks is suppressed (anti-mash).
scoreboard objectives add ec.ablk dummy "AB Last Key"
scoreboard objectives add ec.abld dummy "AB Debounce Left"
scoreboard players set $dwin ec.abgap 20
# Busy-fade cap (Wave 0, Joseph 2026-06-10): max fade tail while MORE frames wait (queue/advance)
# — the full $gap fade-out plays only on the FINAL frame, so a small backlog flows at ~(d+10)t
# per frame instead of ~(d+50)t. Live-tunable: /scoreboard players set $busy ec.abgap <ticks>
scoreboard players set $busy ec.abgap 10
# Drain-mode beat (Joseph 2026-06-11: "expand the quick scroll by 1.5s per item"): solid ticks for
# each COMPRESSED frame while a 4+ backlog drains. Was a 10t blink — unreadable; 40t (2s) lets each
# scrolled item be read. Protected frames were always exempt and play full duration; a 16-frame
# worst-case flood now takes ~34s to clear (TTL'd frames still die on schedule, emit_crit still
# preempts instantly). Live-tunable: /scoreboard players set $drain ec.abgap <ticks>
scoreboard players set $drain ec.abgap 40
