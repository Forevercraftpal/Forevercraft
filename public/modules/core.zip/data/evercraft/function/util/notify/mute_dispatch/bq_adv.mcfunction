# Trigger handler — player clicked [Mute] on a Build-Quest new-objective nudge
# Run as @s (player) from tick dispatcher
scoreboard players set @s ec.nm_bq_adv 0
scoreboard players enable @s ec.nm_bq_adv
function evercraft:util/notify/mute_set {key:"bq_adv",label:"Build-Quest objective nudge"}
