# Boss/raid attack TELEGRAPH variant (run as @s = each viewer; caller pre-sets stage.c + #ndur).
# Council Upgrade 2026-06-10 (balance MC-1): emit_crit with a baked 40t stale-window — one
# reaction beat. The TTL is set HERE, per viewer, because a bare `#nttl` set before an
# `as @a[...]` fan-out is consumed by the FIRST viewer's emit and viewers 2..N would get
# no-expiry frames (compliance note 2026-06-10). A telegraph that out-queues its reaction
# window dies silently instead of firing after the hit landed. Pair with util/notify/flash
# (subtitle copy) so ec.notify=Off players still see combat-safety warnings.
scoreboard players set #nttl ec.temp 40
function evercraft:util/notify/emit_crit
