# Trigger handler — player clicked [Unmute] on the ecodex Notifications page (hearth)
# Run as @s (player) from tick dispatcher
scoreboard players set @s ec.un_hearth 0
scoreboard players enable @s ec.un_hearth
function evercraft:util/notify/unmute_set {key:"hearth",label:"Hearth's Blessing chime"}
