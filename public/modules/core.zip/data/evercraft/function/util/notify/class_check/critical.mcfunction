# Notify Class — critical (always shown, regardless of ec.notify setting)
# Critical events also bypass the per-key mute (the dispatch macro handles this gate).
scoreboard players set #notif_class_ok ec.temp 1
