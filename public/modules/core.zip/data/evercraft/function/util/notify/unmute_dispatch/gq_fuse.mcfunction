# Trigger handler — player clicked [Unmute] on the ecodex Notifications page (gq_fuse)
# Run as @s (player) from tick dispatcher. Clone of unmute_dispatch/bq_adv.
scoreboard players set @s ec.un_gq_fuse 0
scoreboard players enable @s ec.un_gq_fuse
function evercraft:util/notify/unmute_set {key:"gq_fuse",label:"Grand-Quests fusion offer"}
