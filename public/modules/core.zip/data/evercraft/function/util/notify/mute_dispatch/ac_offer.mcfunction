# Trigger handler — player clicked [Mute] on The Awakening soft-offer (rare; the
# offer is one-shot so this almost never appears). Run as @s (player) from tick dispatcher
scoreboard players set @s ec.nm_ac_offer 0
scoreboard players enable @s ec.nm_ac_offer
function evercraft:util/notify/mute_set {key:"ac_offer",label:"Awakening begin-offer"}
