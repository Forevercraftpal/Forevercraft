# Mutable Notification — Remove Mute (macro)
# Args: {key:"X", label:"<readable name>"}
# Run as @s (player). Clears the per-key mute flag + acks. Resets counter so next mute prompt
# fires fresh, not immediately.
$scoreboard players set @s ach.mu_$(key) 0
$scoreboard players set @s ach.nx_$(key) 0
tellraw @s [{text:""}]
$tellraw @s [{text:"  ",color:"dark_gray"},{text:"★ ",color:"green"},{text:"Re-enabled: ",color:"gray"},{text:"$(label)",color:"yellow"}]
tellraw @s [{text:""}]
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.hat master @s ~ ~ ~ 0.5 2
