# Action-Bar Queue — Tick (registered in #minecraft:tick)
# Existence-gated: only players with the ab_q tag (a non-empty queue or an active frame)
# are processed. Idle players cost a single cheap selector check and nothing more.
execute as @a[tag=ab_q] run function evercraft:util/notify/queue/pump_one
