# Action-Bar Notification — REPEATING critical enqueue (run as @s; caller pre-sets stage.c +
# #ndur ec.temp + #nbeat ec.temp = the re-fire cadence in ticks).
# AB-6 (Joseph 2026-06-10): a critical warning that re-fires on a beat (zone damage, rising
# hazard) MUST carry a TTL shorter than two beats — emit_crit salvages a preempted PROTECTED
# frame's remainder back into the queue, and without the TTL each beat's remainder would stack
# behind the next beat's frame forever. This wrapper bakes the rule in: #nttl = #nbeat + 15
# (long enough to display if the queue is briefly busy, dead before the second beat after it).
# One-shot like the other modifiers: #nbeat is consumed + reset here.
# Reference caller: evercraft:raids/boss/arbiter/abilities/zone_warn (20t beat).
scoreboard players add #nbeat ec.temp 0
scoreboard players operation #nttl ec.temp = #nbeat ec.temp
scoreboard players add #nttl ec.temp 15
scoreboard players set #nbeat ec.temp 0
function evercraft:util/notify/emit_crit
