# Trigger handler — player clicked [Mute] on a Build & Conquer new-objective nudge
# Run as @s (player) from tick dispatcher
scoreboard players set @s ec.nm_ak_adv 0
scoreboard players enable @s ec.nm_ak_adv
function evercraft:util/notify/mute_set {key:"ak_adv",label:"Build & Conquer objective nudge"}
