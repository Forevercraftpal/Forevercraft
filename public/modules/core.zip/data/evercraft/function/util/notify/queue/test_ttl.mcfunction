# Run as operator (testing) — self-test frame TTL (staleness drop, W0-2).
# Usage: stand in-world and run  /execute as <you> run function evercraft:util/notify/queue/test_ttl
# Queues two 60t frames, then a third with #nttl 50 (deadline 2.5s away — long before the first
# two finish displaying). Expected: frames 1 and 2 display normally; "STALE — must NEVER show"
# is silently dropped by queue/drop_expired when its turn comes, and the bar goes idle after
# frame 2's full fade.
data modify storage evercraft:notify stage.c set value [{text:"❖ ",color:"aqua"},{text:"TTL test 1 of 2",color:"white"},{text:" ❖",color:"aqua"}]
scoreboard players set #ndur ec.temp 60
function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"❖ ",color:"green"},{text:"TTL test 2 of 2",color:"white"},{text:" ❖",color:"green"}]
scoreboard players set #ndur ec.temp 60
function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"❖ ",color:"red"},{text:"STALE — must NEVER show",color:"red"},{text:" ❖",color:"red"}]
scoreboard players set #ndur ec.temp 40
scoreboard players set #nttl ec.temp 50
function evercraft:util/notify/emit
