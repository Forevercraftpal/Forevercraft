# Critical SUBTITLE flash (run as @s = the viewer; caller pre-sets storage evercraft:notify
# flash.c = the text component, SNBT list like stage.c). The low-intrusion CRITICAL lane
# (Joseph 2026-06-10): renders on the SUBTITLE line — lower-center, small text, with an EMPTY
# title line — so it reads as "something special" without blocking the crosshair like a full
# title. Reserved for critical, time-sensitive cues a player must not miss (rescue windows,
# "you are about to die", boss zone warnings); pair with emit_crit for the action-bar copy.
# It deliberately bypasses the ec.notify chatter filter — that setting silences flavor, not
# safety (same stance as dispatch's critical class). NEVER bold (locked law — bold centered
# text overflows the screen).
#
# `title times` is STAMPED EVERY CALL: times are sticky per-player and NOTHING in the pack
# resets them (0 resets pack-wide as of 2026-06-10), so without this stamp the flash would
# inherit whatever a finale cinematic left behind (e.g. 20 100 40 = a 5s screen squat).
# 5/40/10 = 0.25s in · 2s hold · 0.5s out — present, then gone.
title @s times 5 40 10
function evercraft:util/notify/flash_render with storage evercraft:notify flash
