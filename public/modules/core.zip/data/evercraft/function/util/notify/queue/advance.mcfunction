# Advance to the next queued frame (macro; arg: slot; run as @s)
# Pops the head into the current slot, sizes this frame's solid display (#d) + fade tail (#fade).
# DRAIN MODE (Joseph 2026-06-06): while ec.abdrain==1 (a backlog of 4+ formed — see queue/append),
# every NON-protected frame is compressed to a brief flash so the flood (and its tail) clears fast;
# the queue still drops nothing. PROTECTED frames (cur.p==1, e.g. story dialog via emit_keep) are
# EXEMPT — they always play their full duration, even mid-flood. Renders now.
# TTL (Wave 0, W0-2): before popping, drop every head whose deadline (frame field e) has already
# passed — a time-sensitive cue that missed its window dies silently. #ttl_now is set ONCE per
# advance pass (drop_expired's contract). If expiry empties the queue, return without touching
# cur/abhold — the caller (queue/pump) re-checks `unless data q[0]` right after this call and
# runs its normal idle exit (ab_q off, abld/abdrain zeroed), so the end state matches a clean drain.
execute store result score #ttl_now ec.temp run time query gametime
function evercraft:util/notify/queue/drop_expired with storage evercraft:notify args
$execute unless data storage evercraft:notify q.s$(slot)[0] run return 0
$data modify storage evercraft:notify cur.s$(slot) set from storage evercraft:notify q.s$(slot)[0]
$data remove storage evercraft:notify q.s$(slot)[0]
$execute store result score #d ec.temp run data get storage evercraft:notify cur.s$(slot).d
scoreboard players operation #fade ec.temp = $gap ec.abgap
# Read this frame's protect flag (default 0 = compressible).
scoreboard players set #prot ec.temp 0
$execute store result score #prot ec.temp run data get storage evercraft:notify cur.s$(slot).p
# #compressed = drain mode AND not protected.
scoreboard players set #compressed ec.temp 0
execute if score @s ec.abdrain matches 1 if score #prot ec.temp matches 0 run scoreboard players set #compressed ec.temp 1
# Compressed: a readable beat — $drain solid (live-tunable; 40t since Joseph 2026-06-11, "expand
# the quick scroll by 1.5s per item" — was a 10t blink) + 2t fade. Uncompressed: full #d + fade,
# floored for readability.
execute if score #compressed ec.temp matches 1 run scoreboard players operation #d ec.temp = $drain ec.abgap
execute if score #compressed ec.temp matches 1 run scoreboard players set #fade ec.temp 2
execute if score #compressed ec.temp matches 0 if score #d ec.temp matches ..29 run scoreboard players set #d ec.temp 30
execute if score #compressed ec.temp matches 0 if score #fade ec.temp matches ..3 run scoreboard players set #fade ec.temp 4
# BUSY-FADE CAP (Wave 0, Joseph 2026-06-10): the full $gap fade tail is a luxury for the LAST
# frame only. While MORE frames still wait behind this one, cap the tail at $busy so the queue
# keeps moving — a 2-frame backlog clears in ~4s instead of ~8s. The final frame keeps the long
# fade-out; true floods are still drain mode's job. (Checked AFTER the pop, so q[0] here = "is
# anything else waiting", and after the floors, so compressed frames' 2t fade is untouched.)
$execute if data storage evercraft:notify q.s$(slot)[0] if score #fade ec.temp > $busy ec.abgap run scoreboard players operation #fade ec.temp = $busy ec.abgap
scoreboard players operation @s ec.abfade = #fade ec.temp
scoreboard players operation @s ec.abhold = #d ec.temp
scoreboard players operation @s ec.abhold += #fade ec.temp
$function evercraft:util/notify/queue/render with storage evercraft:notify cur.s$(slot)
