# Roster name baking — ADD ONE MEMBER (run as the member, after who_begin; AB-3).
# Captures @s's profile name into named.one (same fixed-UUID fill_player_head idiom as whoami,
# see that file for the mechanism), then string-joins it onto named.who via the join macros —
# macro substitution is the only string concat mcfunction has. NEVER call from a per-tick loop.
# Defensive: reap a stale display first (a crash between summon and kill would make the next
# summon fail silently — harmless thanks to entity:this, but this keeps the slot clean; race seat).
kill 0-0-0-0-9
summon item_display ~ ~ ~ {UUID:[I;0,0,0,9],view_range:0f,width:0f,height:0f,item:{id:"minecraft:player_head",count:1}}
item modify entity 0-0-0-0-9 container.0 {function:fill_player_head,entity:this}
data modify storage evercraft:notify named.one set from entity 0-0-0-0-9 item.components.minecraft:profile.name
kill 0-0-0-0-9
execute if score #njoin ec.temp matches 0 run function evercraft:util/notify/who_join_first with storage evercraft:notify named
execute if score #njoin ec.temp matches 1.. run function evercraft:util/notify/who_join_next with storage evercraft:notify named
scoreboard players add #njoin ec.temp 1
