# Trigger handler — player clicked [Unmute] on the ecodex Notifications page (fq_adv)
# Run as @s (player) from tick dispatcher
scoreboard players set @s ec.un_fq_adv 0
scoreboard players enable @s ec.un_fq_adv
function evercraft:util/notify/unmute_set {key:"fq_adv",label:"Fisher-Quest objective nudge"}
