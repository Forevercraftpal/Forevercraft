# Mutable Notification — Trigger Tick
# Detects per-key /trigger pulls and routes to the matching mute_dispatch handler.
# Called from util/trigger_dispatch.mcfunction (synth seat warned not to grow this list
# unbounded — keep dispatched keys here only when truly player-mutable).
#
# Mute triggers: fired by [Mute] chat buttons (dispatch.mcfunction) AND by the
#   ecodex Notifications page [Mute] click.
# Unmute triggers: fired only by the ecodex Notifications page [Unmute] click —
#   no chat button counterpart (re-enabling from chat history would be confusing).
execute as @a[scores={ec.nm_level_up=1..}] run function evercraft:util/notify/mute_dispatch/level_up
execute as @a[scores={ec.nm_ms_stage=1..}] run function evercraft:util/notify/mute_dispatch/ms_stage
execute as @a[scores={ec.nm_hearth=1..}] run function evercraft:util/notify/mute_dispatch/hearth
execute as @a[scores={ec.nm_bq_adv=1..}] run function evercraft:util/notify/mute_dispatch/bq_adv
execute as @a[scores={ec.nm_cq_adv=1..}] run function evercraft:util/notify/mute_dispatch/cq_adv
execute as @a[scores={ec.nm_chq_adv=1..}] run function evercraft:util/notify/mute_dispatch/chq_adv
execute as @a[scores={ec.nm_fgq_adv=1..}] run function evercraft:util/notify/mute_dispatch/fgq_adv
execute as @a[scores={ec.nm_ac_adv=1..}] run function evercraft:util/notify/mute_dispatch/ac_adv
execute as @a[scores={ec.nm_ac_offer=1..}] run function evercraft:util/notify/mute_dispatch/ac_offer
execute as @a[scores={ec.nm_ak_adv=1..}] run function evercraft:util/notify/mute_dispatch/ak_adv
execute as @a[scores={ec.nm_ak_offer=1..}] run function evercraft:util/notify/mute_dispatch/ak_offer
execute as @a[scores={ec.nm_tnk_adv=1..}] run function evercraft:util/notify/mute_dispatch/tnk_adv
execute as @a[scores={ec.nm_fq_adv=1..}] run function evercraft:util/notify/mute_dispatch/fq_adv
execute as @a[scores={ec.nm_tnk_offer=1..}] run function evercraft:util/notify/mute_dispatch/tnk_offer
execute as @a[scores={ec.nm_gq_fuse=1..}] run function evercraft:util/notify/mute_dispatch/gq_fuse
execute as @a[scores={ec.un_level_up=1..}] run function evercraft:util/notify/unmute_dispatch/level_up
execute as @a[scores={ec.un_ms_stage=1..}] run function evercraft:util/notify/unmute_dispatch/ms_stage
execute as @a[scores={ec.un_hearth=1..}] run function evercraft:util/notify/unmute_dispatch/hearth
execute as @a[scores={ec.un_bq_adv=1..}] run function evercraft:util/notify/unmute_dispatch/bq_adv
execute as @a[scores={ec.un_cq_adv=1..}] run function evercraft:util/notify/unmute_dispatch/cq_adv
execute as @a[scores={ec.un_chq_adv=1..}] run function evercraft:util/notify/unmute_dispatch/chq_adv
execute as @a[scores={ec.un_fgq_adv=1..}] run function evercraft:util/notify/unmute_dispatch/fgq_adv
execute as @a[scores={ec.un_ac_adv=1..}] run function evercraft:util/notify/unmute_dispatch/ac_adv
execute as @a[scores={ec.un_ac_offer=1..}] run function evercraft:util/notify/unmute_dispatch/ac_offer
execute as @a[scores={ec.un_ak_adv=1..}] run function evercraft:util/notify/unmute_dispatch/ak_adv
execute as @a[scores={ec.un_ak_offer=1..}] run function evercraft:util/notify/unmute_dispatch/ak_offer
execute as @a[scores={ec.un_tnk_adv=1..}] run function evercraft:util/notify/unmute_dispatch/tnk_adv
execute as @a[scores={ec.un_fq_adv=1..}] run function evercraft:util/notify/unmute_dispatch/fq_adv
execute as @a[scores={ec.un_tnk_offer=1..}] run function evercraft:util/notify/unmute_dispatch/tnk_offer
execute as @a[scores={ec.un_gq_fuse=1..}] run function evercraft:util/notify/unmute_dispatch/gq_fuse
