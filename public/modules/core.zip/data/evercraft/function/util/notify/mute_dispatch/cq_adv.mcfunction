# Trigger handler — player clicked [Mute] on a Cook's-Quest new-objective nudge
# Run as @s (player) from tick dispatcher
scoreboard players set @s ec.nm_cq_adv 0
scoreboard players enable @s ec.nm_cq_adv
function evercraft:util/notify/mute_set {key:"cq_adv",label:"Cook-Quest objective nudge"}
