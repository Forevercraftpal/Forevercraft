# Action-Bar Notification — Public Enqueue (run as @s = the player who should see it)
# THE public API for the chat→action-bar migration. Caller pre-sets:
#   storage evercraft:notify stage.c  = the text component (SNBT list, e.g. [{text:"..",color:".."}])
#   score    #ndur ec.temp            = hold duration in ticks (pings ~30, narration ~55)
# Frames queue per-player and display one at a time via the queue tick (sequential, no stomping).
# For multi-line narration, call this once per line — each call is one sequenced frame.
execute unless score @s ec.abinit matches 1 run function evercraft:util/notify/queue/assign_slot
execute store result storage evercraft:notify stage.d int 1 run scoreboard players get #ndur ec.temp
# Protect flag (Joseph 2026-06-06): stage.p = 1 marks this frame EXEMPT from backlog compression
# (important/story dialog — stays full duration). Default 0 = compressible (the 95% "seen-it-once"
# feed). #nprot is the one-shot opt-in: emit_keep sets it to 1; we consume + reset it to 0 here so
# every plain emit() defaults to compressible. `add … 0` initializes the score if it has never been set.
scoreboard players add #nprot ec.temp 0
execute store result storage evercraft:notify stage.p int 1 run scoreboard players get #nprot ec.temp
scoreboard players set #nprot ec.temp 0
# Frame TTL (Wave 0, W0-2): stage.e = absolute gametime deadline; queue/advance drops a head whose
# deadline has passed BEFORE it is shown (a time-sensitive cue that missed its window dies silently
# instead of showing stale). #nttl is the one-shot opt-in (relative ticks): 0/unset = never expires.
# Mirror the #nprot one-shot dance EXACTLY — `add … 0` inits, we consume + reset to 0 so every plain
# emit() defaults to no-expiry, and stage.e is ALWAYS rewritten so a previous frame's TTL never leaks
# (the `stage` object is reused across emit calls and is never cleared between them).
scoreboard players add #nttl ec.temp 0
execute store result score #nttl_dl ec.temp run time query gametime
scoreboard players operation #nttl_dl ec.temp += #nttl ec.temp
# e = now + nttl only when a TTL was requested; otherwise e = 0 (no expiry).
execute store result storage evercraft:notify stage.e long 1 run scoreboard players get #nttl_dl ec.temp
execute if score #nttl ec.temp matches ..0 run data modify storage evercraft:notify stage.e set value 0L
scoreboard players set #nttl ec.temp 0
# ec.notify OFF respects the bar too (AB-2, Joseph 2026-06-10): a player who set notifications to
# Off (ec.notify=2) gets NO queued frames from the standard tiers — emit_keyed/emit_keep delegate
# here so they inherit this gate; emit_now mirrors it; emit_crit + flash are SAFETY and never
# filtered. Placed AFTER the one-shot consumes so a suppressed call can't leak #nprot/#nttl onto
# the next caller. At Important (1) the bar is unchanged — dispatch-routed chatter is already
# filtered at the policy layer, and bar confirms are gameplay feedback, not chat noise.
execute if score @s ec.notify matches 2.. run return 0
# --- Notification channel routing (2026-06-20, player review: "let notifications go back through
# chat — I miss a lot on the action bar"). ec.nchan picks WHERE a shown frame lands; the ec.notify
# OFF gate above still wins (Off = nothing, anywhere).
#   0 = Action Bar (default) — every frame on the bar.
#   1 = Chat                 — every frame in chat (return before the queue; no bar copy).
#   2 = Both (SPLIT)         — important frames (stage.p=1, set above by emit_keep) → chat; the plain
#                              compressible feed (loot pings etc.) → bar. Each frame lands on exactly
#                              ONE channel, never doubled (Joseph 2026-06-22: "separate items, never
#                              the same item on both — I shouldn't see a lore-fragment ping twice").
#   3 = Smart                — bar for all + chat ALSO for important frames (deliberate mirror).
# chat_render prints stage.c to the chat log. emit_crit/flash are SAFETY lanes and intentionally NOT
# routed (they always paint bar/subtitle).
scoreboard players add @s ec.nchan 0
# Chat copy: mode 1 = every frame; modes 2 & 3 = important frames only.
execute if score @s ec.nchan matches 1 run function evercraft:util/notify/chat_render with storage evercraft:notify stage
execute if score @s ec.nchan matches 2..3 if data storage evercraft:notify stage{p:1} run function evercraft:util/notify/chat_render with storage evercraft:notify stage
# Skip the bar copy: mode 1 always; mode 2 only for the important frames that just went to chat (so
# Both never doubles — the plain feed below still reaches the bar).
execute if score @s ec.nchan matches 1 run return 0
execute if score @s ec.nchan matches 2 if data storage evercraft:notify stage{p:1} run return 0
execute store result storage evercraft:notify args.slot int 1 run scoreboard players get @s ec.abslot
function evercraft:util/notify/queue/append with storage evercraft:notify args
tag @s add ab_q
