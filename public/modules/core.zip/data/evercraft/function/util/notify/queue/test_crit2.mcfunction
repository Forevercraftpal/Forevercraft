# Run as operator (testing) — companion to test_crit: fire emit_crit while a frame is MID-DISPLAY.
# Usage: run test_crit, wait ~2s (while STORY is solid), then run this.
# Expected: the displaying frame cuts INSTANTLY and this frame shows ≤1 tick later. If the cut
# frame was PROTECTED (STORY), its remainder re-appears right after this frame (salvage at q[1]);
# a non-protected frame is simply gone.
data modify storage evercraft:notify stage.c set value [{text:"⚠ ",color:"red"},{text:"PREEMPT — cuts the bar NOW",color:"red"},{text:" ⚠",color:"red"}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit_crit
