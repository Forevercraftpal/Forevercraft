# Trigger handler — player clicked [Unmute] on the ecodex Notifications page (ms_stage)
# Run as @s (player) from tick dispatcher
scoreboard players set @s ec.un_ms_stage 0
scoreboard players enable @s ec.un_ms_stage
function evercraft:util/notify/unmute_set {key:"ms_stage",label:"Milestone stage nudges"}
