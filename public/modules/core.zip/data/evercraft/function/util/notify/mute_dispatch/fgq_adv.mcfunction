# Trigger handler — player clicked [Mute] on a Forging-Quest new-objective nudge
# Run as @s (player) from tick dispatcher
scoreboard players set @s ec.nm_fgq_adv 0
scoreboard players enable @s ec.nm_fgq_adv
function evercraft:util/notify/mute_set {key:"fgq_adv",label:"Forging-Quest objective nudge"}
