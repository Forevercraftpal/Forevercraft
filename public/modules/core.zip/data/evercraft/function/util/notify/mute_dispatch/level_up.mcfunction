# Trigger handler — player clicked [Mute] on a level-up notification
# Run as @s (player) from tick dispatcher
scoreboard players set @s ec.nm_level_up 0
scoreboard players enable @s ec.nm_level_up
function evercraft:util/notify/mute_set {key:"level_up",label:"Companion level-ups"}
