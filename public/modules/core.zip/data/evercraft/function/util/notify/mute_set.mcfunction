# Mutable Notification — Apply Mute (macro)
# Args: {key:"X", label:"<readable name>"}
# Run as @s (player). Sets the per-key mute flag + emits an ACK tellraw + sound.
# ACK is required because `gamerule send_command_feedback false` (init.mcfunction:12)
# suppresses /trigger's native acknowledgement — without our own ack, the [Mute] click
# would feel silently broken.

$scoreboard players set @s ach.mu_$(key) 1
tellraw @s [{text:""}]
$tellraw @s [{text:"  ",color:"dark_gray"},{text:"✓ ",color:"green"},{text:"Muted: ",color:"gray"},{text:"$(label)",color:"yellow"}]
tellraw @s [{text:"  ",color:"dark_gray"},{text:"Re-enable any time via Codex → Settings → Notifications.",color:"gray",italic:true}]
tellraw @s [{text:""}]
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.hat master @s ~ ~ ~ 0.5 1.6
