# Trigger handler — player clicked [Mute] on a Chemistry-Quest new-objective nudge
# Run as @s (player) from tick dispatcher
scoreboard players set @s ec.nm_chq_adv 0
scoreboard players enable @s ec.nm_chq_adv
function evercraft:util/notify/mute_set {key:"chq_adv",label:"Chemistry-Quest objective nudge"}
