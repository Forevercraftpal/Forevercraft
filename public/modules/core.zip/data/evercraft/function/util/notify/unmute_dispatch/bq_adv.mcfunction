# Trigger handler — player clicked [Unmute] on the ecodex Notifications page (bq_adv)
# Run as @s (player) from tick dispatcher
scoreboard players set @s ec.un_bq_adv 0
scoreboard players enable @s ec.un_bq_adv
function evercraft:util/notify/unmute_set {key:"bq_adv",label:"Build-Quest objective nudge"}
