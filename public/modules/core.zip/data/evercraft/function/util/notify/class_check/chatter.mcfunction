# Notify Class — chatter (low-priority, suppressed when ec.notify >= 1)
# Sets #notif_class_ok ec.temp = 1 if global filter permits, else 0.
scoreboard players set #notif_class_ok ec.temp 1
execute if score @s ec.notify matches 1.. run scoreboard players set #notif_class_ok ec.temp 0
