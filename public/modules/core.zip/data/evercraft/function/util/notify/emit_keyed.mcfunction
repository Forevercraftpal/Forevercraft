# Action-Bar Notification — DEBOUNCED enqueue (macro {key}; run as @s; caller pre-sets stage.c + #ndur)
# Suppresses a repeat of the SAME integer `key` while its debounce window (ec.abld ≈ $dwin ticks) is
# open — kills mash/burst spam (ability-locked denials, coin drops, minigame clicks, bag-slot pickups)
# WITHOUT dropping distinct messages (different keys still queue). Pick a small stable key per spammy
# source. Plain `emit` (no debounce) remains the default for everything else.
execute unless score @s ec.abinit matches 1 run function evercraft:util/notify/queue/assign_slot
$execute if score @s ec.ablk matches $(key) if score @s ec.abld matches 1.. run return 0
$scoreboard players set @s ec.ablk $(key)
scoreboard players operation @s ec.abld = $dwin ec.abgap
function evercraft:util/notify/emit
