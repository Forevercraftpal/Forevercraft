# Mirror a staged notify frame to the chat log (macro; payload = the frame {c,...}; run as @s = viewer).
# Used by the ec.nchan channel router in util/notify/emit + emit_now when a player routes their
# notifications to Chat / Both / Smart. $(c) is the stored text component serialized back to SNBT —
# the exact idiom queue/render uses to paint the action bar, only sent to chat (persistent +
# scrollable) so the player can't miss it while their eyes are off the hotbar. Call with:
#   function evercraft:util/notify/chat_render with storage evercraft:notify stage
$tellraw @s $(c)
