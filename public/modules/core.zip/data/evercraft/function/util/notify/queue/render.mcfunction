# Render the current frame to the action bar (macro; payload = the current frame {c,d}; run as @s)
# $(c) is the stored text component, serialized back to SNBT — the native component form in
# this pack (see CLAUDE.md), so it drops straight into the title argument.
$title @s actionbar $(c)
