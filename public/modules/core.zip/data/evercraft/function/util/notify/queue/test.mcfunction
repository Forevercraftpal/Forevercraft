# Run as operator (testing) — self-test the action-bar queue.
# Usage: stand in-world and run  /execute as <you> run function evercraft:util/notify/queue/test
# Verifies: slot assignment, queue ordering, hold timing, fade gap, SNBT render, AND
# (frame 2) that bold survives the storage round-trip + the icon-mirror flanking style.
# Each frame's number = its solid display ticks; the ❖ icon is mirrored on both ends.
data modify storage evercraft:notify stage.c set value [{text:"❖ ",color:"aqua"},{text:"Frame 1 of 3",color:"white"},{text:" — solid, then fade",color:"gray"},{text:" ❖",color:"aqua"}]
scoreboard players set #ndur ec.temp 60
function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"❖ ",color:"gold"},{text:"Frame 2 of 3",color:"white",bold:true},{text:" — bold + mirror check",color:"gray"},{text:" ❖",color:"gold"}]
scoreboard players set #ndur ec.temp 60
function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"❖ ",color:"green"},{text:"Frame 3 of 3",color:"white"},{text:" — done",color:"gray"},{text:" ❖",color:"green"}]
scoreboard players set #ndur ec.temp 60
function evercraft:util/notify/emit
