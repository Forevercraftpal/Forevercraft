# Trigger handler — player clicked [Unmute] on the ecodex Notifications page (chq_adv)
# Run as @s (player) from tick dispatcher
scoreboard players set @s ec.un_chq_adv 0
scoreboard players enable @s ec.un_chq_adv
function evercraft:util/notify/unmute_set {key:"chq_adv",label:"Chemistry-Quest objective nudge"}
