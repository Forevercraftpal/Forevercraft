# Clear this player's queued + current action-bar frames (macro; arg: slot).
# Used on join to drop a STALE backlog that would otherwise replay — e.g. a world-boss fight
# whose queued spawn/phase/kill frames never finished draining before the player logged off
# (the pump only runs for online players, so the per-slot storage queue freezes across logout
# and thaws on rejoin, spamming every phase + the boss type). Safe no-op if the slot is empty.
$data remove storage evercraft:notify q.s$(slot)
$data remove storage evercraft:notify cur.s$(slot)
