# Trigger handler — player clicked [Mute] on an Awakening new-objective nudge
# Run as @s (player) from tick dispatcher
scoreboard players set @s ec.nm_ac_adv 0
scoreboard players enable @s ec.nm_ac_adv
function evercraft:util/notify/mute_set {key:"ac_adv",label:"Awakening objective nudge"}
