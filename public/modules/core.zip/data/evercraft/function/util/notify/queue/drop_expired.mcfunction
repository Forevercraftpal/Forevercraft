# Drop-while-expired head helper (macro; arg: slot; run as @s) — Wave 0, W0-2.
# Recursively removes queue heads whose TTL deadline (frame field `e`) has already passed, so a
# time-sensitive cue that missed its window dies SILENTLY instead of ever being shown stale.
# Frame `e` semantics: e==0 = never expires (the default); e>0 = absolute gametime deadline.
# Called from queue/advance BEFORE the head is popped into cur. #ttl_now is set by the caller
# (queue/advance) once per advance pass so we don't re-query gametime on every recursion step.
#
# Guard: only runs while a head exists. Reads e; if e>0 AND e < now, drop head [0] and recurse.
# A head with e==0 (no TTL) or e>=now stops the drop-while immediately (it is the frame to show).
$execute unless data storage evercraft:notify q.s$(slot)[0] run return 0
scoreboard players set #ttl_e ec.temp 0
$execute store result score #ttl_e ec.temp run data get storage evercraft:notify q.s$(slot)[0].e
# Not expired (e==0 never-expires, or deadline still in the future) -> this head stays; stop.
execute if score #ttl_e ec.temp matches ..0 run return 0
execute unless score #ttl_e ec.temp < #ttl_now ec.temp run return 0
# Expired: drop this head and recurse to test the next one.
$data remove storage evercraft:notify q.s$(slot)[0]
# (no leading $ — this line substitutes nothing; a parameterless macro line is a load error.
# The recursion re-reads slot from the same args storage.)
function evercraft:util/notify/queue/drop_expired with storage evercraft:notify args
