# Run as operator (testing) — self-test emit_crit ordering + the busy-fade cap.
# Usage: stand in-world and run  /execute as <you> run function evercraft:util/notify/queue/test_crit
# All three enqueue in ONE tick. Expected on screen, in this order:
#   1. "CRITICAL — first, ≤1 tick" (red)  — the emit_crit frame, despite being enqueued LAST.
#   2. "STORY — resumes intact" (gold)    — the protected emit_keep frame, full 80t solid.
#   3. "chatter — last" (gray)            — the plain emit frame, ending with the long final fade.
# While more frames wait, each fade tail is capped at $busy (10t); ONLY frame 3 gets the ~50t fade.
# To test MID-DISPLAY preemption + protected salvage: run this, wait ~2s (while STORY is solid),
# then run test_crit2 — STORY must cut instantly, and its remainder must return right after the
# preempting frame, before "chatter".
data modify storage evercraft:notify stage.c set value [{text:"❖ ",color:"gold"},{text:"STORY — resumes intact",color:"white"},{text:" ❖",color:"gold"}]
scoreboard players set #ndur ec.temp 80
function evercraft:util/notify/emit_keep
data modify storage evercraft:notify stage.c set value [{text:"❖ ",color:"gray"},{text:"chatter — last",color:"gray"},{text:" ❖",color:"gray"}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"❖ ",color:"red"},{text:"CRITICAL — first, ≤1 tick",color:"red"},{text:" ❖",color:"red"}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit_crit
