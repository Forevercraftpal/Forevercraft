# Preemptive prepend (macro; arg: slot; run as @s) — emit_crit's engine half.
# 1) Prepend the staged frame to the FRONT of the queue (same cap policy as queue/prepend:
#    at the 16-cap drop the newest pending tail, never the front).
scoreboard players set #qlen ec.temp 0
$execute store result score #qlen ec.temp run data get storage evercraft:notify q.s$(slot)
$execute if score #qlen ec.temp matches 16.. run data remove storage evercraft:notify q.s$(slot)[-1]
$data modify storage evercraft:notify q.s$(slot) prepend from storage evercraft:notify stage
# 2) If a frame is mid-display AND it is PROTECTED (cur.p==1, story dialog), salvage it: write its
#    remaining SOLID ticks back as the frame's d and re-insert it at q[1], right behind the
#    critical frame, so it resumes after the warning instead of dying. Non-protected frames are
#    simply cut — they were compressible chatter by definition. Remainders under 10t aren't worth
#    resuming (sub-half-second flash). Capacity gate: #qlen is the PRE-prepend length, so the
#    salvage (a second insert) only happens at ..14 — keeps the queue ≤16 even on this path.
scoreboard players set #curp ec.temp 0
$execute if score @s ec.abhold matches 1.. store result score #curp ec.temp run data get storage evercraft:notify cur.s$(slot).p
scoreboard players operation #rem ec.temp = @s ec.abhold
scoreboard players operation #rem ec.temp -= @s ec.abfade
$execute if score #curp ec.temp matches 1 if score #rem ec.temp matches 10.. if score #qlen ec.temp matches ..14 store result storage evercraft:notify cur.s$(slot).d int 1 run scoreboard players get #rem ec.temp
$execute if score #curp ec.temp matches 1 if score #rem ec.temp matches 10.. if score #qlen ec.temp matches ..14 run data modify storage evercraft:notify q.s$(slot) insert 1 from storage evercraft:notify cur.s$(slot)
# 3) Cut the current frame: hold→0 ends it immediately; the next queue/pump tick advances into
#    the critical frame (render ≤1 tick away). Harmless when the player is idle (hold already 0).
scoreboard players set @s ec.abhold 0
