# Mutable Notification Dispatch (macro)
# Args: {key:"<short>", class:"chatter|alert|critical", mute_at:N}
# Run as @s = the PLAYER who would see the notification.
# Writes per-key result registers on ec.temp:
#   #notif_show_<key>       = 1 if caller should fire the tellraw
#   #notif_show_mute_<key>  = 1 if caller should append the [Mute] button
# Per-key registers (not shared) so sibling/nested dispatches in one function don't trample.
# Critical class bypasses both the global ec.notify filter AND the per-key mute.

# Default to not show
$scoreboard players set #notif_show_$(key) ec.temp 0
$scoreboard players set #notif_show_mute_$(key) ec.temp 0

# Global filter by class
$function evercraft:util/notify/class_check/$(class)
execute if score #notif_class_ok ec.temp matches 0 run return 0

# Per-key mute check (skipped for critical class — fall through)
$execute if score @s ach.mu_$(key) matches 1.. run return 0

# Counter — increment lifetime occurrences for this player+key
$scoreboard players add @s ach.nx_$(key) 1

# Approved to show
$scoreboard players set #notif_show_$(key) ec.temp 1

# Re-enable the per-key mute trigger unconditionally on every dispatch — without this, clicks
# from older chat history silently fail because /trigger auto-disables after consume.
$scoreboard players enable @s ec.nm_$(key)

# Offer [Mute] button after threshold reached
$execute if score @s ach.nx_$(key) matches $(mute_at).. run scoreboard players set #notif_show_mute_$(key) ec.temp 1
