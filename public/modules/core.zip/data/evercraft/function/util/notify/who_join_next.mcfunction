# Join macro — subsequent roster members (macro; args {who, one}; see who_add).
$data modify storage evercraft:notify named.who set value "$(who), $(one)"
