# Trigger handler — player clicked [Mute] on a Fisher's-Path new-objective nudge
# Run as @s (player) from tick dispatcher
scoreboard players set @s ec.nm_fq_adv 0
scoreboard players enable @s ec.nm_fq_adv
function evercraft:util/notify/mute_set {key:"fq_adv",label:"Fisher-Quest objective nudge"}
