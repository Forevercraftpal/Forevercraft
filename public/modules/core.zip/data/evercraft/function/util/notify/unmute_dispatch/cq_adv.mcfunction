# Trigger handler — player clicked [Unmute] on the ecodex Notifications page (cq_adv)
# Run as @s (player) from tick dispatcher
scoreboard players set @s ec.un_cq_adv 0
scoreboard players enable @s ec.un_cq_adv
function evercraft:util/notify/unmute_set {key:"cq_adv",label:"Cook-Quest objective nudge"}
