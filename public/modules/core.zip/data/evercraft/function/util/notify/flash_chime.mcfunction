# Subtitle flash + one gentle musical cue (run as @s; same contract as util/notify/flash —
# caller pre-sets storage evercraft:notify flash.c). Use when the critical cue deserves an ear
# as well as an eye (rescue windows, zone warnings); plain flash when sound would double up
# with the emitting system's own FX.
# Sound ladder per fx_system: ec.fx_snd 0=Off · 1=Reduced · 2=Full+ — note-block palette only
# (locked law: musical, never mob vocals). Voicing (AB-5, Joseph 2026-06-10): anchored on the
# pack's "last note" — the chest-chord pling D' 1.587 that every gather-win now resolves to —
# so the critical lane speaks the same musical language. Reduced = the pling alone, soft; Full
# layers an amethyst chime under it (the shimmer marks it as a LANE cue, not a gather win).
function evercraft:util/notify/flash
execute if score @s ec.fx_snd matches 1 run playsound minecraft:block.note_block.pling master @s ~ ~ ~ 0.4 1.587
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.pling master @s ~ ~ ~ 0.45 1.587
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.4 1.189
