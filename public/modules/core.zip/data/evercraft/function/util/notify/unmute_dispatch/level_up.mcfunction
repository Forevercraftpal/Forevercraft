# Trigger handler — player clicked [Unmute] on the ecodex Notifications page (level_up)
# Run as @s (player) from tick dispatcher
scoreboard players set @s ec.un_level_up 0
scoreboard players enable @s ec.un_level_up
function evercraft:util/notify/unmute_set {key:"level_up",label:"Companion level-ups"}
