# Join macro — first roster member (macro; args {one}; see who_add).
$data modify storage evercraft:notify named.who set value "$(one)"
