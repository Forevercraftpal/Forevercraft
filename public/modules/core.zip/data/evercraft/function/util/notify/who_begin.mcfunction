# Roster name baking — BEGIN (AB-3, Joseph 2026-06-10). Resets the join accumulator; then run
# evercraft:util/notify/who_add AS each roster member, and `named.who` ends up holding
# "Name1, Name2, …" (", "-joined — the same separator vanilla uses when a multi-player selector
# component renders, so converted broadcasts read identically). Single-actor sites should keep
# using evercraft:util/notify/whoami.
data modify storage evercraft:notify named.who set value ""
scoreboard players set #njoin ec.temp 0
