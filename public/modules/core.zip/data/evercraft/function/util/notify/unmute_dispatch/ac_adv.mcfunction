# Trigger handler — player clicked [Unmute] on the ecodex Notifications page (ac_adv)
# Run as @s (player) from tick dispatcher
scoreboard players set @s ec.un_ac_adv 0
scoreboard players enable @s ec.un_ac_adv
function evercraft:util/notify/unmute_set {key:"ac_adv",label:"Awakening objective nudge"}
