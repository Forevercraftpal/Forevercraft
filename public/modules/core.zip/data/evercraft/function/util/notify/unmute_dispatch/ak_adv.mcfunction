# Trigger handler — player clicked [Unmute] on the ecodex Notifications page (ak_adv)
# Run as @s (player) from tick dispatcher
scoreboard players set @s ec.un_ak_adv 0
scoreboard players enable @s ec.un_ak_adv
function evercraft:util/notify/unmute_set {key:"ak_adv",label:"Build & Conquer objective nudge"}
