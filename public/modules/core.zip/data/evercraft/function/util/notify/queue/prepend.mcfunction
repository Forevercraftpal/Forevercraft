# Prepend the staged frame to the FRONT of this player's queue (macro; arg: slot) — priority path.
# Backlog guard drops the NEWEST pending frame (tail [-1]) at the 16-cap so the prioritized frame survives.
scoreboard players set #qlen ec.temp 0
$execute store result score #qlen ec.temp run data get storage evercraft:notify q.s$(slot)
$execute if score #qlen ec.temp matches 16.. run data remove storage evercraft:notify q.s$(slot)[-1]
$data modify storage evercraft:notify q.s$(slot) prepend from storage evercraft:notify stage
# FADE-CUT (Wave 0, Joseph 2026-06-10): a priority frame should never wait out a leftover fade
# tail — if the bar is only FADING (no solid display), end the fade now so this frame renders on
# the next pump tick. Mid-SOLID display still finishes (full preemption is emit_crit's job).
execute if score @s ec.abhold matches 1.. if score @s ec.abhold <= @s ec.abfade run scoreboard players set @s ec.abhold 0
