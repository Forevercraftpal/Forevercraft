# Trigger handler — player clicked [Mute] on a Tinkering new-objective nudge
# Run as @s (player) from tick dispatcher
scoreboard players set @s ec.nm_tnk_adv 0
scoreboard players enable @s ec.nm_tnk_adv
function evercraft:util/notify/mute_set {key:"tnk_adv",label:"Tinkerer's Path objective nudge"}
