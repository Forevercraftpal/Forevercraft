# Trigger handler — player clicked [Mute] on a Hearth's Blessing notification
# Run as @s (player) from tick dispatcher
scoreboard players set @s ec.nm_hearth 0
scoreboard players enable @s ec.nm_hearth
function evercraft:util/notify/mute_set {key:"hearth",label:"Hearth's Blessing chime"}
