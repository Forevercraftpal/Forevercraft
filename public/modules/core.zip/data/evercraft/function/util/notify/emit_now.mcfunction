# Action-Bar Notification — CRITICAL / priority enqueue (run as @s; caller pre-sets stage.c + #ndur)
# Jumps the queue (prepend) so a load-bearing warning shows NEXT; at the 16-cap the backlog guard
# drops the newest normal frame (tail), never this one. Use sparingly — combat mechanic warnings,
# "you are about to die", etc. — not for flavor pings.
execute unless score @s ec.abinit matches 1 run function evercraft:util/notify/queue/assign_slot
execute store result storage evercraft:notify stage.d int 1 run scoreboard players get #ndur ec.temp
# Protect flag (mirror emit): consume #nprot one-shot + rewrite stage.p every call so a prior frame's
# protect state never leaks onto this prepended frame. Default 0 = compressible.
scoreboard players add #nprot ec.temp 0
execute store result storage evercraft:notify stage.p int 1 run scoreboard players get #nprot ec.temp
scoreboard players set #nprot ec.temp 0
# Frame TTL (Wave 0, W0-2): same one-shot #nttl → absolute stage.e deadline as emit. Always rewritten
# so a previous frame's TTL never leaks onto this prepended frame. 0/unset = never expires.
scoreboard players add #nttl ec.temp 0
execute store result score #nttl_dl ec.temp run time query gametime
scoreboard players operation #nttl_dl ec.temp += #nttl ec.temp
execute store result storage evercraft:notify stage.e long 1 run scoreboard players get #nttl_dl ec.temp
execute if score #nttl ec.temp matches ..0 run data modify storage evercraft:notify stage.e set value 0L
scoreboard players set #nttl ec.temp 0
# ec.notify OFF respects the bar (AB-2 — mirrors emit's gate; emit_crit/flash stay unfiltered).
execute if score @s ec.notify matches 2.. run return 0
# --- Notification channel routing (2026-06-20; "Both" repartitioned 2026-06-22): mirror of emit's
# block. ec.nchan = 0 Action Bar / 1 Chat / 2 Both (SPLIT: important→chat, plain→bar, never doubled) /
# 3 Smart (bar for all + chat for important). Chat-only (1) and the chat-bound half of Both (2) return
# before the prepend so the bar copy is skipped. See util/notify/emit for the full rationale. ---
scoreboard players add @s ec.nchan 0
execute if score @s ec.nchan matches 1 run function evercraft:util/notify/chat_render with storage evercraft:notify stage
execute if score @s ec.nchan matches 2..3 if data storage evercraft:notify stage{p:1} run function evercraft:util/notify/chat_render with storage evercraft:notify stage
execute if score @s ec.nchan matches 1 run return 0
execute if score @s ec.nchan matches 2 if data storage evercraft:notify stage{p:1} run return 0
execute store result storage evercraft:notify args.slot int 1 run scoreboard players get @s ec.abslot
function evercraft:util/notify/queue/prepend with storage evercraft:notify args
tag @s add ab_q
