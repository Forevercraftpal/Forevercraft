# Action-Bar Notification — PROTECTED enqueue (run as @s = the viewer).
# Same contract as util/notify/emit (caller pre-sets storage stage.c + score #ndur), but marks this
# frame EXEMPT from backlog compression: it always plays its full #ndur duration even when the queue
# is flooded. Use for important, read-once-fully messages — story dialog, key alerts, etc.
# Everything else should keep calling util/notify/emit (compressible when 4+ frames stop up).
scoreboard players set #nprot ec.temp 1
function evercraft:util/notify/emit
