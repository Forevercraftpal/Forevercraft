# Render the subtitle flash (macro; payload = flash {c}; run as @s).
# The subtitle must be set BEFORE the title — sending the (empty) title is what triggers the
# display. {text:""} renders nothing on the title line; the subtitle shows alone beneath it.
$title @s subtitle $(c)
title @s title {text:""}
