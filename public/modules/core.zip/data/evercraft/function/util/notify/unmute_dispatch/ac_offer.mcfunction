# Trigger handler — player clicked [Unmute] on the ecodex Notifications page (ac_offer)
# Run as @s (player) from tick dispatcher
scoreboard players set @s ec.un_ac_offer 0
scoreboard players enable @s ec.un_ac_offer
function evercraft:util/notify/unmute_set {key:"ac_offer",label:"Awakening begin-offer"}
