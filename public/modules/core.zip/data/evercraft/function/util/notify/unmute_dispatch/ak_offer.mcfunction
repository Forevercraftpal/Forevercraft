# Trigger handler — player clicked [Unmute] on the ecodex Notifications page (ak_offer)
# Run as @s (player) from tick dispatcher
scoreboard players set @s ec.un_ak_offer 0
scoreboard players enable @s ec.un_ak_offer
function evercraft:util/notify/unmute_set {key:"ak_offer",label:"Build & Conquer begin-offer"}
