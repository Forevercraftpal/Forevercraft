# Notify Class — alert (medium-priority, suppressed only when ec.notify = 2 / OFF)
scoreboard players set #notif_class_ok ec.temp 1
execute if score @s ec.notify matches 2.. run scoreboard players set #notif_class_ok ec.temp 0
