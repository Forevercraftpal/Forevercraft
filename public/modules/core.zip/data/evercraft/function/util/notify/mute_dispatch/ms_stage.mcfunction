# Trigger handler — player clicked [Mute] on a milestone-stage notification
# Run as @s (player) from tick dispatcher
scoreboard players set @s ec.nm_ms_stage 0
scoreboard players enable @s ec.nm_ms_stage
function evercraft:util/notify/mute_set {key:"ms_stage",label:"Milestone stage nudges"}
