# Overwrite stage.c[$(i)].text with the STRING form of $(v) (macro; args {i:<index>, v:<value>}).
# The score-baking half of the §5b unlock (Wave 2, Joseph 2026-06-10): a {score:{...}} component
# stored in the queue would re-resolve in the VIEWER's context at render time, and a raw
# `store result storage ... .text` writes an Int NBT where a component needs a String. Going
# through a macro stringifies it. Usage:
#   execute store result storage evercraft:notify named.v int 1 run scoreboard players get <holder> <obj>
#   data modify storage evercraft:notify named.i set value <element index>
#   function evercraft:util/notify/stage_text with storage evercraft:notify named
$data modify storage evercraft:notify stage.c[$(i)].text set value "$(v)"
