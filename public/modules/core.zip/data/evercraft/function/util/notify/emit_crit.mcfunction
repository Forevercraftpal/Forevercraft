# Action-Bar Notification — PREEMPTIVE CRITICAL enqueue (run as @s; caller pre-sets stage.c + #ndur,
# optional #nttl ec.temp = stale-after ticks). The strongest tier: jumps the queue AND cuts the
# currently-displaying frame, so the message renders on the NEXT pump tick (≤1 tick away) instead
# of waiting out the current frame's hold + fade tail (up to ~80t). If the interrupted frame was
# PROTECTED (story dialog via emit_keep), its remainder is re-inserted behind this frame —
# delayed, not lost (see queue/preempt). Use SPARINGLY: rescue windows (dreamy pull), "you are
# about to die", boss zone warnings. Confirmations/flavor belong in emit / emit_keyed; queue-jump
# WITHOUT preemption is emit_now. Pair with util/notify/flash for the subtitle copy of a truly
# critical cue.
execute unless score @s ec.abinit matches 1 run function evercraft:util/notify/queue/assign_slot
execute store result storage evercraft:notify stage.d int 1 run scoreboard players get #ndur ec.temp
# Critical frames are ALWAYS protected (exempt from drain-mode compression and from being cut by a
# later emit_crit — preempt salvages protected frames). stage.p is rewritten every call, and #nprot
# is consumed defensively so a stray opt-in can't leak onto the NEXT plain emit.
data modify storage evercraft:notify stage.p set value 1
scoreboard players set #nprot ec.temp 0
# Frame TTL (Wave 0, W0-2): same one-shot #nttl → absolute stage.e deadline as emit. Always
# rewritten so a previous frame's TTL never leaks onto this frame. 0/unset = never expires.
scoreboard players add #nttl ec.temp 0
execute store result score #nttl_dl ec.temp run time query gametime
scoreboard players operation #nttl_dl ec.temp += #nttl ec.temp
execute store result storage evercraft:notify stage.e long 1 run scoreboard players get #nttl_dl ec.temp
execute if score #nttl ec.temp matches ..0 run data modify storage evercraft:notify stage.e set value 0L
scoreboard players set #nttl ec.temp 0
execute store result storage evercraft:notify args.slot int 1 run scoreboard players get @s ec.abslot
function evercraft:util/notify/queue/preempt with storage evercraft:notify args
tag @s add ab_q
