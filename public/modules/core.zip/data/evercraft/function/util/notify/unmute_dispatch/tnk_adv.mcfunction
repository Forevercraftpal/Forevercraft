# Trigger handler — player clicked [Unmute] on the ecodex Notifications page (tnk_adv)
# Run as @s (player) from tick dispatcher
scoreboard players set @s ec.un_tnk_adv 0
scoreboard players enable @s ec.un_tnk_adv
function evercraft:util/notify/unmute_set {key:"tnk_adv",label:"Tinkerer's Path objective nudge"}
