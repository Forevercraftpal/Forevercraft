# Assign a stable per-player action-bar queue slot (once per player; persists in scoreboard)
# Slot is a small integer used to key this player's frame queue in storage (q.s<slot>),
# avoiding the impossibility of reading a player's name into a macro at runtime.
scoreboard players add $next ec.abslot 1
scoreboard players operation @s ec.abslot = $next ec.abslot
scoreboard players set @s ec.abhold 0
scoreboard players set @s ec.abfade 0
scoreboard players set @s ec.ablk 0
scoreboard players set @s ec.abld 0
scoreboard players set @s ec.abinit 1
