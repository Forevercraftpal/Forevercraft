# Trigger handler — player clicked [Unmute] on the ecodex Notifications page (tnk_offer)
# Run as @s (player) from tick dispatcher
scoreboard players set @s ec.un_tnk_offer 0
scoreboard players enable @s ec.un_tnk_offer
function evercraft:util/notify/unmute_set {key:"tnk_offer",label:"Tinkerer's Path begin offer"}
