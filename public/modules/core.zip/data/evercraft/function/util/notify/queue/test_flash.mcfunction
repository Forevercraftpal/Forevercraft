# Run as operator (testing) — self-test the subtitle flash lane (W0-3).
# Usage: stand in-world and run  /execute as <you> run function evercraft:util/notify/queue/test_flash
# Expected: lower-center SUBTITLE "Critical lane test — subtitle only" with NO title text above
# it — in ~0.25s, holds ~2s, gone in ~0.5s — and the action bar is untouched. With ec.fx_snd 1
# one soft chime; with 2+ a chime + low bell (flash_chime ladder). Run twice after a cinematic
# set long title times to confirm the stamp overrides sticky times.
data modify storage evercraft:notify flash.c set value [{text:"⚠ ",color:"red"},{text:"Critical lane test — subtitle only",color:"white"},{text:" ⚠",color:"red"}]
function evercraft:util/notify/flash_chime
