# Trigger handler — player clicked [Mute] on a Grand-Quests fusion-offer chime
# Run as @s (player) from tick dispatcher.
# NOTE: gq_fuse is a ONE-SHOT offer dispatched at mute_at:99, so the [Mute] button
# effectively never appears in chat — this handler exists purely so the registered
# trigger has a route (consistency with every other notify key) and so a manual
# Notifications-page mute is honored. Clone of mute_dispatch/bq_adv.
scoreboard players set @s ec.nm_gq_fuse 0
scoreboard players enable @s ec.nm_gq_fuse
function evercraft:util/notify/mute_set {key:"gq_fuse",label:"Grand-Quests fusion offer"}
