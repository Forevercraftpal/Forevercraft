# Per-player queue pump (run as @s). Resolves the slot, then drives the macro pump.
execute unless score @s ec.abinit matches 1 run function evercraft:util/notify/queue/assign_slot
execute store result storage evercraft:notify args.slot int 1 run scoreboard players get @s ec.abslot
function evercraft:util/notify/queue/pump with storage evercraft:notify args
