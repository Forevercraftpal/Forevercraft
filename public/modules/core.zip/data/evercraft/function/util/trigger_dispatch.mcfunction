# === PLAYER TRIGGER DISPATCH ===
# All non-combat /trigger handlers in one function. Called EVERY tick from tick.mcfunction:61 — the
# only gate is the server-wide player-presence check (`unless entity @a run return 0`) at tick.mcfunction:5.
# Each line below is a score-filtered @a scan: a cheap no-op when its trigger isn't set, but it DOES run
# per tick (the older header's "gated by existence check / saves N empty scans" claim was doc-drift).

execute as @a[scores={ec.dreams=1..}] run function evercraft:dreams/check
scoreboard players enable @a[scores={ec.dreams=1..}] ec.dreams
scoreboard players set @a[scores={ec.dreams=1..}] ec.dreams 0
execute as @a[scores={ec.dr_history=1..}] run function evercraft:dreams/history
scoreboard players enable @a[scores={ec.dr_history=1..}] ec.dr_history
scoreboard players set @a[scores={ec.dr_history=1..}] ec.dr_history 0
execute as @a[scores={ec.craft_check=1..}] run function evercraft:craftforever/craft_rate/breakdown
scoreboard players enable @a[scores={ec.craft_check=1..}] ec.craft_check
scoreboard players set @a[scores={ec.craft_check=1..}] ec.craft_check 0
# ec.cr_history poll RETIRED 2026-06-04 (dead-code council): the CR-history chat page was a dark
# trigger (0 writers), superseded by the §18 Artisan Profile Craft-Rate ladder tab. Triad removed
# atomically with craft_rate/history + the init register/enable + dreams/on_join enable.
execute as @a[scores={ec.lore_map=1..}] run function evercraft:lore/map/display
scoreboard players enable @a[scores={ec.lore_map=1..}] ec.lore_map
scoreboard players set @a[scores={ec.lore_map=1..}] ec.lore_map 0
execute as @a[scores={ec.moon=1..}] run function evercraft:moon/check
scoreboard players enable @a[scores={ec.moon=1..}] ec.moon
scoreboard players set @a[scores={ec.moon=1..}] ec.moon 0
execute as @a[scores={ec.loot_timer=1..}] run function evercraft:structures/storage/check_timer
scoreboard players enable @a[scores={ec.loot_timer=1..}] ec.loot_timer
scoreboard players set @a[scores={ec.loot_timer=1..}] ec.loot_timer 0
execute as @a[scores={ec.stats=1..},tag=!Adv.InMenu,tag=!CF.InCodex] run function evercraft:stats/show
scoreboard players enable @a[scores={ec.stats=1..}] ec.stats
scoreboard players set @a[scores={ec.stats=1..}] ec.stats 0
execute as @a[scores={ec.healthbar=1..}] run function evercraft:health_bar/toggle
scoreboard players enable @a[scores={ec.healthbar=1..}] ec.healthbar
scoreboard players set @a[scores={ec.healthbar=1..}] ec.healthbar 0
execute as @a[scores={ec.biome_mastery=1..}] run function evercraft:biome_mastery/display
scoreboard players enable @a[scores={ec.biome_mastery=1..}] ec.biome_mastery
scoreboard players set @a[scores={ec.biome_mastery=1..}] ec.biome_mastery 0
# ec.milestones dispatch RETIRED 2026-06-06 (Joseph-approved): legacy chat World-Milestones
# journal was a GUI-rule violation + codex-redundant. Objective unregistered in milestones/load;
# milestones/display_router + display/page1-6 archived to .archive/milestones_display_legacy/.

# Quest auto-tracker toggle
execute as @a[scores={ec.quest_track=1..}] run function evercraft:quests/tracker/toggle
scoreboard players enable @a[scores={ec.quest_track=1..}] ec.quest_track
scoreboard players set @a[scores={ec.quest_track=1..}] ec.quest_track 0

# Notification volume control (cycles 0→1→2→0)
execute as @a[scores={ec.notify_lvl=1..}] run function evercraft:util/notify_toggle
scoreboard players enable @a[scores={ec.notify_lvl=1..}] ec.notify_lvl
scoreboard players set @a[scores={ec.notify_lvl=1..}] ec.notify_lvl 0

# Quest pacing — [Skip ▸] beat-skip + Quest-Narration toggle (Chronicles Wave C0)
# Both fire law-compliant /trigger chat buttons (no /function discoverability). Skip routes to the
# tracked line's own advance via do_skip (full reward, forward cursor, never double-pays); the toggle
# is the sole-writer apply_mute flip of ec.qln_mute. Gate/enable/reset triad mirrors dreams (lines 5-7).
execute as @a[scores={ec.qskip=1..}] run function evercraft:quest_pacing/do_skip
scoreboard players enable @a[scores={ec.qskip=1..}] ec.qskip
scoreboard players set @a[scores={ec.qskip=1..}] ec.qskip 0
execute as @a[scores={ec.qln_tog=1..}] run function evercraft:quest_pacing/apply_mute
scoreboard players enable @a[scores={ec.qln_tog=1..}] ec.qln_tog
scoreboard players set @a[scores={ec.qln_tog=1..}] ec.qln_tog 0
# ec.gq_trk = the [★ Track] pin buttons (Questline Restructure W1): set_track reads the
# trigger VALUE (1-11 pin / 50 menu / 99 untrack) BEFORE the reset below — triad order matters.
execute as @a[scores={ec.gq_trk=1..}] run function evercraft:grand_quests/set_track
scoreboard players enable @a[scores={ec.gq_trk=1..}] ec.gq_trk
scoreboard players set @a[scores={ec.gq_trk=1..}] ec.gq_trk 0

# Mutable notification per-key mute triggers (one dispatcher routes all keys to keep this file flat)
function evercraft:util/notify/tick

# Dungeon ready-check confirm [RETIRED 2026-05-28 — Wiring Audit #12 W1; objective stripped from init]

# Black market quick-sell
execute as @a[scores={ec.bm_quicksell=1..}] at @s run function evercraft:black_market/quick_sell
scoreboard players enable @a[scores={ec.bm_quicksell=1..}] ec.bm_quicksell
scoreboard players set @a[scores={ec.bm_quicksell=1..}] ec.bm_quicksell 0

# Difficulty selection (Newcomer / Adventurer / Pioneer)
execute as @a[scores={ec.diff_trigger=1..3}] run function evercraft:difficulty/choose

# Newcomer spirit choice — Combatant/Pacifist preference then weapon/tool selection
# OPT: Gate entire block — 12 @a scans → 0 when no newcomer has triggered (most ticks)
execute if entity @a[scores={ec.newcomer_pick=1..},tag=!ec.spirit_chosen,limit=1] run function evercraft:newcomer/dispatch_choice

# === PLAN 5: Profile, Recap, Journey triggers ===
# Suppress chat-heavy triggers while player is in any codex menu (prevents tellraw floods over GUI)
# Show only fires outside menus; score always consumed to prevent deferred firing on menu close
execute as @a[scores={ec.profile=1..},tag=!Adv.InMenu,tag=!CF.InCodex] run function evercraft:stats/profile/show
scoreboard players enable @a[scores={ec.profile=1..}] ec.profile
scoreboard players set @a[scores={ec.profile=1..}] ec.profile 0
execute as @a[scores={ec.recap=1..},tag=!Adv.InMenu,tag=!CF.InCodex] run function evercraft:stats/recap/show
scoreboard players enable @a[scores={ec.recap=1..}] ec.recap
scoreboard players set @a[scores={ec.recap=1..}] ec.recap 0
execute as @a[scores={ec.journey_log=1..},tag=!Adv.InMenu,tag=!CF.InCodex] run function evercraft:stats/journey/show
scoreboard players enable @a[scores={ec.journey_log=1..}] ec.journey_log
scoreboard players set @a[scores={ec.journey_log=1..}] ec.journey_log 0

# === STORY MODE TRIGGERS ===
# Story mode selection (1=story, 2=freeplay) — sm.pick is ephemeral trigger, sm.mode is persistent state
execute as @a[scores={sm.pick=1}] run function evercraft:story/mode/set_story
execute as @a[scores={sm.pick=2}] run function evercraft:story/mode/set_freeplay
# Joseph 2026-06-13 (#93): Pioneer death chain step 1 → step 2. If the player
# answering sm.pick is mid-death-flow (pioneer.step1), advance them to the
# Pioneer Continue/Switch prompt. The emit removes step1 + adds step2 so this
# only fires once per death sequence.
execute as @a[tag=pioneer.step1,scores={sm.pick=1..}] run function evercraft:difficulty/pioneer_emit_pioneer_choice
scoreboard players enable @a[scores={sm.pick=1..}] sm.pick
scoreboard players set @a[scores={sm.pick=1..}] sm.pick 0

# Story path selection (1=dream, 2=craft, 3=both)
execute as @a[scores={sm.path_pick=1..3}] if score @s sm.mode matches 1..2 run function evercraft:story/mode/set_path
scoreboard players enable @a[scores={sm.path_pick=1..}] sm.path_pick
scoreboard players set @a[scores={sm.path_pick=1..}] sm.path_pick 0

# Story tip request — clicked [Need a tip?] in briefing. /trigger bypasses the OP-only /function permission.
execute as @a[scores={sm.tip_show=1..}] run function evercraft:story/notify/show_tip
scoreboard players enable @a[scores={sm.tip_show=1..}] sm.tip_show
scoreboard players set @a[scores={sm.tip_show=1..}] sm.tip_show 0

# TP Join trigger (spectate invites for encounter cam / dreaming realm)
execute as @a[scores={ec.tp_join=1..}] run function evercraft:tp_safety/trigger_handler
