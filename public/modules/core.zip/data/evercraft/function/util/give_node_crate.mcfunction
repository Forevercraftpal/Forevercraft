# Give the player ONE animatable crate, rolled exactly like a chest-node open (Accessory/Companion/
# Artifact/Regular per tinkering/chest_drop/crate_channel) PLUS a rare biome-crate slice. Replaces the
# old mob-crate-item gives, which do NOT animate when a player places them. Guaranteed a crate; the
# roll decides WHICH. Run AS the receiving player, AT @s (positions the give-vs-drop). (Joseph 2026-06-05.)

# RAREST slice (~3%): a crate keyed to the player's CURRENT biome (crates/items/biome_<key>). Only fires
# in a folded biome (key 1..15); if the biome is unknown (key 0) it falls through so a crate is STILL
# guaranteed. Biome's 3% sits below Regular's 10% and the 30% type slices below, so it's the rarest pull.
# (NOTE: NOT roll_local — that's a cooldown-gated scarcity drop that can give nothing; this is a flat give.)
execute store result score #cn_biomeroll ec.var run random value 1..100
execute if score #cn_biomeroll ec.var matches 1..3 run function evercraft:biome/detect
execute if score #cn_biomeroll ec.var matches 1..3 run function evercraft:biome/crate_key
execute if score #cn_biomeroll ec.var matches 1..3 if score #biome_crate_key ec.var matches 1..15 store result storage evercraft:bc_temp gkey int 1 run scoreboard players get #biome_crate_key ec.var
execute if score #cn_biomeroll ec.var matches 1..3 if score #biome_crate_key ec.var matches 1..15 run return run function evercraft:util/give_biome_crate_local with storage evercraft:bc_temp

# Standard node-chest crate roll (Accessory 30 / Companion 30 / Artifact 30 / Regular 10).
execute store result score #cn_invfull ec.var run function evercraft:util/check_inv_full
scoreboard players set #cn_ctype ec.temp 3
function evercraft:tinkering/chest_drop/crate_channel
