# Bake @s's profile NAME into storage evercraft:scorebake args.owner (string), for GUI text_display
# headers/rows where {selector:"@s"/"@p"/"@a[...]"} renders BLANK in 26.1 (a passive display entity
# has no execution context to resolve a selector at render time). Run AS the player whose name you
# want — the menu opener, or a member resolved by score/tag (execute as that player run <this>).
#
# Idiom: fixed-UUID item_display + fill_player_head(entity:this) + profile.name — the SAME proven
# pattern as evercraft:util/notify/whoami and evercraft:treasure/database/name/check, but writing to
# a GUI-dedicated key (args.owner) so it never collides with the notify queue's named.who. UUID
# [I;0,0,0,12] is free (1, 2, 9 are taken elsewhere).
#
# Call sites then bake the name as a frozen macro literal — NOT a live {nbt:...,storage:...} read —
# because a text_display re-reads storage every frame and storage is global, so two open menus would
# clobber each other's name. Macro-baking freezes the correct name into each entity at summon time.
# Cost: summon + item modify + data get + kill. NEVER call from a per-tick loop; one-shot only.
#
# Defensive: reap a stale display first (a crash between summon and kill would leave the slot taken).
kill 0-0-0-0-12
execute at @s run summon item_display ~ ~ ~ {UUID:[I;0,0,0,12],view_range:0f,width:0f,height:0f,item:{id:"minecraft:player_head",count:1}}
item modify entity 0-0-0-0-12 container.0 {function:fill_player_head,entity:this}
data modify storage evercraft:scorebake args.owner set from entity 0-0-0-0-12 item.components.minecraft:profile.name
kill 0-0-0-0-12
