# Util — grant vanilla XP LEVELS, difficulty-scaled (MACRO: n; run as the player)
# Pioneer mode (ec.difficulty 3, or 0/unset) receives 1/3 (floor, min 1) of every
# level reward — Joseph 2026-06-11. Newcomer/Adventurer (1-2) receive the full n.
# Single source for all level rewards (challenges, lore sets, tombs, events, ...).
$scoreboard players set #xpl ec.temp $(n)
scoreboard players set #xpl3 ec.temp 3
execute unless score @s ec.difficulty matches 1..2 run scoreboard players operation #xpl ec.temp /= #xpl3 ec.temp
execute unless score @s ec.difficulty matches 1..2 if score #xpl ec.temp matches ..0 run scoreboard players set #xpl ec.temp 1
execute store result storage evercraft:args xpl.m int 1 run scoreboard players get #xpl ec.temp
function evercraft:util/xp_levels_do with storage evercraft:args xpl
