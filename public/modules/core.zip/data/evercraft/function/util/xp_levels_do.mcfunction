# Util — apply the computed level grant (MACRO: m; run as the player)
$experience add @s $(m) levels
