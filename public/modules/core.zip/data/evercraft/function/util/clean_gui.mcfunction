# Utility — Nuclear cleanup of display + interaction entities
# Run as: /function evercraft:util/clean_gui
# WARNING: Kills text_display, interaction, and item_display entities.
# Permanent ones (fountains, guildstones, forage, etc.) will respawn on next tick/load.
# SPARED (2026-06-23): placed furnishings (ec.dec_disp / ec.dec_click / ec.shelf_name) and custom
# blocks (smithed.entity) — decor does NOT respawn, so nuking it is permanent loss. Excluded here.

kill @e[type=text_display,tag=!ec.shelf_name,tag=!smithed.entity]
kill @e[type=interaction,tag=!ec.dec_click]
kill @e[type=item_display,tag=!ec.dec_disp,tag=!smithed.entity]
kill @e[type=marker,tag=companion.menuanchor]

# Clear all InMenu tags from players
tag @a remove Adv.InMenu
tag @a remove TX.InMenu
tag @a remove RF.InMenu
tag @a remove HS.InMenu
tag @a remove HS.InSatchel
tag @a remove DG.InMenu
tag @a remove CK.InMenu
tag @a remove WW.InMenu
tag @a remove ec.guild_in_menu
tag @a remove companion.inmenuv2

tellraw @s [{text:"[",color:"dark_gray"},{text:"Debug",color:"yellow"},{text:"] ",color:"dark_gray"},{text:"All display & interaction entities nuked.",color:"green"}]
