# Give the player their CURRENT-biome crate ITEM (crates/items/biome_<gkey>) — an animatable barrel
# they place; crate_anim reveals it. Called `with storage evercraft:bc_temp` (gkey = the folded biome
# key 1..15, set by the caller from #biome_crate_key). Inv-full guard: drop at feet rather than void.
# The rarest slice of util/give_node_crate. Run AS the receiving player, AT @s. (Joseph 2026-06-05.)
# Earn-time DR gear-tier stamp + inv-full guard live inside give_item; gkey is on storage evercraft:bc_temp.
function evercraft:biome_crates/give_item
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"aqua"},{text:"A Biome Crate",color:"aqua"},{text:" — the rarest find!",color:"gray",italic:true},{text:" ✦",color:"aqua"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.conduit.activate master @s ~ ~ ~ 0.6 1.3
