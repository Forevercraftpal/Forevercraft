# TP Safety — Float Rescue
# Rescues a player stranded at high Y after an instance ends
# Run as @s at @s

# Priority 1: If we have a saved position, teleport them back exactly
execute if entity @s[tag=ec.tp_saved] run function evercraft:tp_safety/restore

# Priority 2: If still at high Y (no saved position or restore failed), give slow fall
# After restore, player is at ground level so this check naturally fails
execute at @s if entity @s[y=200,dy=200] run effect give @s slow_falling 120 0 true
execute at @s if entity @s[y=200,dy=200] run effect give @s resistance 120 4 true
data modify storage evercraft:notify stage.c set value [{text:"\u2726 ",color:"gold"},{text:"The ground calls you back...",color:"gray",italic:true},{text:" \u2726",color:"gold"}]
scoreboard players set #ndur ec.temp 45
execute at @s if entity @s[y=200,dy=200] run function evercraft:util/notify/emit
execute at @s if entity @s[y=200,dy=200] if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.enderman.teleport master @s ~ ~ ~ 0.5 0.8
