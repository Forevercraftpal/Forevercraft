# TP Safety — Clear Saved Position
scoreboard players set @s ec.tp_ret_x 0
scoreboard players set @s ec.tp_ret_y 0
scoreboard players set @s ec.tp_ret_z 0
scoreboard players set @s ec.tp_ret_dim 0
scoreboard players set @s ec.tp_ret_sys 0
tag @s remove ec.tp_saved
