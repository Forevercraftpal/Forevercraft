# TP Safety — Load
# Shared return-position system for all teleportation features

# Return position scoreboards
scoreboard objectives add ec.tp_ret_x dummy
scoreboard objectives add ec.tp_ret_y dummy
scoreboard objectives add ec.tp_ret_z dummy
scoreboard objectives add ec.tp_ret_dim dummy

# Which system saved (1=castle, 2=dreaming, 3=codex spectator, 4=raids, 5=heist, 6=duel, 7=encounter cam)
scoreboard objectives add ec.tp_ret_sys dummy

# Float safety net countdown (ticks remaining to check for stranded players)
scoreboard players set #tp_float_cd ec.var 0
