# TP Safety — Trigger Handler
# Routes ec.tp_join trigger values to system-specific accept functions

# Value 7 = Encounter cam spectate accept
execute if score @s ec.tp_join matches 7 run function evercraft:spectator/invite/accept

# Value 2 = Dreaming realm spectate accept
execute if score @s ec.tp_join matches 2 run function evercraft:dreaming_realm/invite/accept

# Reset and re-enable trigger
scoreboard players set @s ec.tp_join 0
scoreboard players enable @s ec.tp_join
