# TP Safety — Restore Return Position
# Run as @s. Teleports player back to saved position, then clears data.

# Skip if no saved position
execute unless entity @s[tag=ec.tp_saved] run return 0

# Copy scores to storage for macro teleport
execute store result storage evercraft:tp_safety ret.x int 1 run scoreboard players get @s ec.tp_ret_x
execute store result storage evercraft:tp_safety ret.y int 1 run scoreboard players get @s ec.tp_ret_y
execute store result storage evercraft:tp_safety ret.z int 1 run scoreboard players get @s ec.tp_ret_z

# Dimension-switch + macro teleport
execute if score @s ec.tp_ret_dim matches 0 in minecraft:overworld run function evercraft:tp_safety/restore_macro with storage evercraft:tp_safety ret
execute if score @s ec.tp_ret_dim matches 1 in minecraft:the_nether run function evercraft:tp_safety/restore_macro with storage evercraft:tp_safety ret
execute if score @s ec.tp_ret_dim matches 2 in minecraft:the_end run function evercraft:tp_safety/restore_macro with storage evercraft:tp_safety ret

# Clear saved data
function evercraft:tp_safety/clear
