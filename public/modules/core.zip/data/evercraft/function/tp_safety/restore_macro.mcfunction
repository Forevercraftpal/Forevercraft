# TP Safety — Restore Macro
# Teleport player to stored coordinates (called within dimension context)
$tp @s $(x) $(y) $(z)
