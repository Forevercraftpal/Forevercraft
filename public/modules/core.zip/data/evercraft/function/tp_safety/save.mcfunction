# TP Safety — Save Return Position
# Run as @s at @s. Caller must pre-set ec.tp_ret_sys.

# Store current coordinates
execute store result score @s ec.tp_ret_x run data get entity @s Pos[0]
execute store result score @s ec.tp_ret_y run data get entity @s Pos[1]
execute store result score @s ec.tp_ret_z run data get entity @s Pos[2]

# Store current dimension
execute if predicate evercraft:in_overworld run scoreboard players set @s ec.tp_ret_dim 0
execute if predicate evercraft:in_nether run scoreboard players set @s ec.tp_ret_dim 1
execute if predicate evercraft:in_end run scoreboard players set @s ec.tp_ret_dim 2

# Mark as having a saved position
tag @s add ec.tp_saved
