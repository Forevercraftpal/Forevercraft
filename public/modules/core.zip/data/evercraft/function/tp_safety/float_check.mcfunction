# TP Safety — Float Check
# Runs for 5 seconds after a floating instance cleanup
# Detects players stranded above Y=200 who aren't in any active instance

# Decrement countdown
scoreboard players remove #tp_float_cd ec.var 1

# Rescue stranded players (above Y=200, not in any active instance)
execute as @a[tag=ec.tp_saved,tag=!ic.player,tag=!dr.in_realm,tag=!rd.player,tag=!ec.duel_active_tag,tag=!ec.heist_active_tag,tag=!ec.tt_player] at @s if entity @s[y=200,dy=200] run function evercraft:tp_safety/float_rescue
