# === RECONNECT DISPATCH ===
# OPT: All disconnect recovery in one function, called only when unjoined players exist
# Saves 17 empty @a[tag=!ec.joined] scans on normal ticks (the common case)

# === DREAMING REALM: Crash/disconnect recovery ===
# If player reconnects while dream was active, clean up
execute as @a[tag=!ec.joined,scores={ec.dream_active=1..}] run function evercraft:dreaming_realm/exit/crash_recovery

# === DUEL SYSTEM: Crash/disconnect recovery ===
execute as @a[tag=!ec.joined,scores={ec.duel_active=1..}] run function evercraft:duel/crash_recovery

# === HEIST SYSTEM: Crash/disconnect recovery ===
execute as @a[tag=!ec.joined,scores={ec.heist_active=1..}] run function evercraft:heist/crash_recovery

# === COMPANION EVOLUTION: Disconnect during ceremony recovery ===
execute as @a[tag=!ec.joined,tag=ce.evolving] run function evercraft:companion_evolution/crash_cleanup

# === REAPER: Disconnect recovery — kill orphaned hunt/bandit mobs ===
execute as @a[tag=!ec.joined,scores={rp.hunt_active=1}] run scoreboard players set @s rp.hunt_active 0
execute as @a[tag=!ec.joined,scores={rp.band_active=1}] run scoreboard players set @s rp.band_active 0

# === PET DUEL: Disconnect recovery ===
execute if score #pd_active ec.var matches 1 as @a[tag=pd.duelist,tag=!ec.joined] run function evercraft:pet_duel/resolve_draw

# === CRAFTFOREVER CODEX: Disconnect recovery ===
# If player had codex open when they disconnected, clean up orphaned entities
# close uses distance=..15 which may miss anchors if player respawned far away — global fallback after
execute as @a[tag=!ec.joined,tag=CF.InCodex] at @s run function evercraft:craftforever/codex/hub/close
# Fallback: kill orphaned entities globally if close couldn't reach the anchor
execute as @a[tag=!ec.joined,tag=CF.InCodex] run function evercraft:craftforever/codex/hub/close_orphaned

# === ADVANTAGE CODEX: Disconnect recovery ===
# If player had codex open when they disconnected, clean up orphaned entities
execute as @a[tag=!ec.joined,tag=Adv.InMenu] at @s run function evercraft:advantage/gui/close

# === ETERNAL CODEX: Disconnect recovery ===
# Clear stale use flag to prevent phantom menu open on rejoin
scoreboard players set @a[tag=!ec.joined,scores={ec.ecodex_use=1..}] ec.ecodex_use 0

# === PHOENIX CODEX: Disconnect recovery ===
scoreboard players set @a[tag=!ec.joined,scores={ec.phoenix_use=1..}] ec.phoenix_use 0

# === COMPANION CATALOGUE: Disconnect recovery ===
scoreboard players set @a[tag=!ec.joined,scores={ec.cc_use=1..}] ec.cc_use 0

# === ARTISAN FORGE: Disconnect recovery ===
execute as @a[tag=!ec.joined,tag=CF.InMenu] run function evercraft:craftforever/forging/gui/close

# === RESONANCE STRIKE: Disconnect recovery ===
execute as @a[tag=!ec.joined,scores={ec.cf_reso=1}] run function evercraft:craftforever/nodes/resonance/cleanup

# === TRADE TRIALS: Crash/disconnect recovery ===
execute as @a[tag=!ec.joined,tag=ec.tt_player] run function evercraft:craftforever/trials/crash_recovery

# === SPIRIT RAID PROMPT: Disconnect recovery ===
# If player reconnects while prompted, auto-decline (they lost the chat context)
execute as @a[tag=!ec.joined,tag=sr.prompted] run scoreboard players set @s ec.sr_timer 0
execute as @a[tag=!ec.joined,tag=sr.prompted] run tag @s remove sr.prompted

# === BLUEPRINTS: Disconnect recovery ===
# The preview (tick_preview) and build (tick_dispatch) schedule chains do NOT survive a
# disconnect, so a player who logged out mid-preview/mid-build would otherwise be stranded
# at ec.bp_state=1/2 forever — bailing every blueprint use at the "already building" gate.
# Kill any orphaned owner-bound markers/corners, then hard-reset blueprint state.
execute as @a[tag=!ec.joined,scores={ec.bp_state=1..}] run function evercraft:blueprints/preview/cleanup
scoreboard players set @a[tag=!ec.joined,scores={ec.bp_state=1..}] ec.bp_state 0
scoreboard players set @a[tag=!ec.joined] ec.bp_cancel_at 0
scoreboard players set @a[tag=!ec.joined] ec.bp_layer 0
scoreboard players set @a[tag=!ec.joined] ec.bp_max_layer 0
tag @a[tag=!ec.joined] remove bp.previewing
scoreboard players set @a[tag=!ec.joined] ec.bp_use 0
scoreboard players set @a[tag=!ec.joined] ec.bp_held 0

# Clear quest preview state on rejoin
execute as @a[tag=!ec.joined,scores={ec.qp_active=1}] run scoreboard players set @s ec.qp_active 0

# === TP SAFETY: Rescue players stranded at high Y after disconnect ===
execute as @a[tag=!ec.joined,tag=ec.tp_saved] at @s if entity @s[y=200,dy=200] run function evercraft:tp_safety/float_rescue

# === BOUGH MASTERY: one-time cutover from the old resonance economy (joiners) ===
# Idempotent (guarded by ec.bough_migrated). Must precede the on_join line below,
# which flips ec.joined. Players online at the cutover /reload are handled by the
# post-load sweep bough/mastery/migrate_all.
execute as @a[tag=!ec.joined] unless score @s ec.bough_migrated matches 1 run function evercraft:bough/mastery/migrate

# === PIONEER MEMENTO: re-kick the rooted choose-loop if a reclaimer rejoined ===
# The choose-loop tick self-terminates when nobody is reclaiming; if the lone
# reclaimer relogged it would otherwise never restart, leaving them frozen.
execute if entity @a[tag=!ec.joined,tag=pioneer.reclaiming] run schedule function evercraft:difficulty/pioneer_reclaim_tick 4t replace

# === STALE MENU STATE: clear every menu-open flag on rejoin ===
# Tags persist through logout, but a menu's panels and (for self-scheduled menus) its tick
# chain do NOT. Only Adv/CF were recovered above; the rest would stay "held" — sparing their
# orphaned panels from cleanup/gui_auto forever. Stripping all menu-open flags here makes any
# relog'd menu a sweepable orphan (its leftover panels are then removed by cleanup/gui_auto or
# the no-player sweep in cleanup/tick). Harmless on flags that aren't set. Open routines reset
# the per-menu state scores, so no extra resets are needed.
tag @a[tag=!ec.joined] remove ec.menu_active
tag @a[tag=!ec.joined] remove ec.menu_sneak_open
tag @a[tag=!ec.joined] remove companion.inmenuv2
tag @a[tag=!ec.joined] remove CK.InMenu
tag @a[tag=!ec.joined] remove DG.InMenu
tag @a[tag=!ec.joined] remove IC.InMenu
tag @a[tag=!ec.joined] remove TX.InMenu
tag @a[tag=!ec.joined] remove RF.InMenu
tag @a[tag=!ec.joined] remove BM.InMenu
tag @a[tag=!ec.joined] remove WW.InMenu
tag @a[tag=!ec.joined] remove TT.InMenu
tag @a[tag=!ec.joined] remove FF.InMenu
tag @a[tag=!ec.joined] remove TNK.InMenu
tag @a[tag=!ec.joined] remove HS.InMenu
tag @a[tag=!ec.joined] remove HS.InSatchel
tag @a[tag=!ec.joined] remove HS.InFurnish
tag @a[tag=!ec.joined] remove DEC.Standalone
tag @a[tag=!ec.joined] remove ec.guild_in_menu
tag @a[tag=!ec.joined] remove ec.fsack_in_menu
tag @a[tag=!ec.joined] remove ec.pantry_in_menu
tag @a[tag=!ec.joined] remove ec.satchel_in_menu
tag @a[tag=!ec.joined] remove ec.hsatch_in_menu
tag @a[tag=!ec.joined] remove ec.orebag_in_menu
tag @a[tag=!ec.joined] remove ec.fhold_in_menu
tag @a[tag=!ec.joined] remove ec.binder_in_menu
tag @a[tag=!ec.joined] remove ec.mule_in_menu
tag @a[tag=!ec.joined] remove ec.dlpack_in_menu
tag @a[tag=!ec.joined] remove ec.ksbag_in_menu
tag @a[tag=!ec.joined] remove ec.gs_in_menu
tag @a[tag=!ec.joined] remove ec.bough_viewing
tag @a[tag=!ec.joined] remove ec.qln_book
tag @a[tag=!ec.joined] remove ec.tome_menu
tag @a[tag=!ec.joined] remove ec.sc_in_showcase

# Detect player join (unified briefing + init)
execute as @a[tag=!ec.joined] at @s run function evercraft:dreams/on_join
