# RPG Health Bar — Tick (every 3 ticks)
# Raycasts from each enabled player's eyes to find mobs
# Lag audit 2026-06-22: throttled 2t->3t (6.6Hz). The bar lingers ~2s (hb.linger), so a 0.05s
# slower refresh is imperceptible while the per-player recursive raycast cost drops by a third.

# For each enabled player, do raycast
execute as @a[scores={hb.enabled=1..}] at @s anchored eyes positioned ^ ^ ^0.5 run function evercraft:health_bar/raycast/init

# Linger countdown — decrement and hide when expired
execute as @a[scores={hb.linger=1..}] run scoreboard players remove @s hb.linger 1
execute as @a[scores={hb.linger=0,hb.enabled=1..}] run function evercraft:health_bar/hide

# Boss-bar declutter (N10.1): while a raid boss is active, hide the vanilla raid_boss bossbar for
# any participant currently aiming at the boss (hb.on_boss) — our healthbar already shows that HP —
# and re-show it for everyone else. Existence-gated on #rd_active so it's a no-op outside a raid.
# 2026-06-21: also exclude DEAD participants (predicate=evercraft:player/alive) so the bar drops
# cleanly the tick they die instead of sticking through the death/respawn screen (client desync).
execute if score #rd_active ec.var matches 1 run bossbar set evercraft:raid_boss players @a[tag=ec.rd_participant,tag=!hb.on_boss,predicate=evercraft:player/alive]

# Reschedule
schedule function evercraft:health_bar/tick 3t
