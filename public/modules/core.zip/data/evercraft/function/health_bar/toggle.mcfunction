# RPG Health Bar — Toggle
# Called via /trigger ec.healthbar
# Context: as @a[scores={ec.healthbar=1..}]

# Check current state before modifying
execute if score @s hb.enabled matches 1 run tag @s add hb.was_enabled
execute if score @s hb.enabled matches 1 run function evercraft:health_bar/leave

# If we just disabled it, notify and return
data modify storage evercraft:notify stage.c set value [{text:"◆ ",color:"#D6D0C7"},{text:"Health Bar",color:"gold"},{text:" disabled.",color:"gray"},{text:" ◆",color:"#D6D0C7"}]
scoreboard players set #ndur ec.temp 45
execute if entity @s[tag=hb.was_enabled] run function evercraft:util/notify/emit
execute if entity @s[tag=hb.was_enabled] if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.hat master @s ~ ~ ~ 0.5 1.6
tag @s remove hb.was_enabled
execute if score @s hb.enabled matches 0 run return 0

# Otherwise, enable
function evercraft:health_bar/join
data modify storage evercraft:notify stage.c set value [{text:"◆ ",color:"#D6D0C7"},{text:"Health Bar",color:"gold"},{text:" enabled.",color:"green"},{text:" ◆",color:"#D6D0C7"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.experience_orb.pickup master @s ~ ~ ~ 0.5 1.2
