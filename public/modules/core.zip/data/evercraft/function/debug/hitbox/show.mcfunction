# Debug: visualize EVERY GUI interaction-box near you as a translucent glass box.
# Run as operator / yourself in chat:  /function evercraft:debug/hitbox/show
# Workflow: open any GUI -> run this -> screenshot -> /function evercraft:debug/hitbox/clear
# Each glass box is the literal click hitbox (a minecraft:interaction AABB). Compare it
# against the text_display button it sits on to confirm pixel-perfect placement. (debug)

# Idempotent: wipe any previous overlay so re-running re-snapshots the current GUI.
function evercraft:debug/hitbox/clear

# Mark visualizer active (drives toggle).
scoreboard players set #dbg_hitbox ec.var 1

# Box every interaction entity within 16 blocks (covers the GUI in front of you).
execute as @e[type=minecraft:interaction,distance=..16] at @s run function evercraft:debug/hitbox/spawn_one

# Count what we drew.
scoreboard players set #dbg_n ec.var 0
execute as @e[type=block_display,tag=ec.dbg_hitbox] run scoreboard players add #dbg_n ec.var 1

# Report — distinct message when nothing was found so it's obvious why you see nothing.
execute if score #dbg_n ec.var matches 0 if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 0.8 0.6
execute if score #dbg_n ec.var matches 0 run tellraw @s [{text:"[hitbox] ",color:"red",bold:true},{text:"No interaction entities within 16 blocks. Open a GUI first and stand within ~16 blocks of it, then run show again.",color:"gray"}]
execute if score #dbg_n ec.var matches 1.. if score @s ec.fx_snd matches 1.. run playsound minecraft:block.beacon.activate master @s ~ ~ ~ 0.6 1.6
execute if score #dbg_n ec.var matches 1.. run tellraw @s [{text:"[hitbox] ",color:"light_purple",bold:true},{text:"Showing ",color:"gray"},{score:{name:"#dbg_n",objective:"ec.var"},color:"white",bold:true},{text:" interaction box(es). ",color:"gray"},{text:"Magenta outline = click bounds. ",color:"light_purple"},{text:"Screenshot, then /function evercraft:debug/hitbox/clear",color:"gray"}]
