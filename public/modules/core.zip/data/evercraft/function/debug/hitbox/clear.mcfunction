# Debug: remove all hitbox-visualizer glass boxes.
# Run:  /function evercraft:debug/hitbox/clear   (debug)
kill @e[type=block_display,tag=ec.dbg_hitbox]
scoreboard players set #dbg_hitbox ec.var 0
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.beacon.deactivate master @s ~ ~ ~ 0.5 1.2
tellraw @s [{text:"[hitbox] ",color:"light_purple",bold:true},{text:"Cleared interaction-box overlay.",color:"gray"}]
