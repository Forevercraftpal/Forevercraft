# Debug: flip the hitbox visualizer on/off in one command.
# Run:  /function evercraft:debug/hitbox/toggle   (debug)
# On -> snapshots every interaction box within 16 blocks. Off -> clears them.
execute if score #dbg_hitbox ec.var matches 1.. run function evercraft:debug/hitbox/clear
execute unless score #dbg_hitbox ec.var matches 1.. run function evercraft:debug/hitbox/show
