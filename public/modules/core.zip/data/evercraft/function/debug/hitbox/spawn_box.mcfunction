# Debug: macro — bake one translucent glass box from storage evercraft:debug hb. (debug)
#   $(w) = full width/depth, $(h) = full height, $(nhw) = -width/2, $(zero) = 0.0f.
# Runs at the interaction entity's Pos. Box spans the exact AABB:
#   X/Z [Pos-w/2 .. Pos+w/2], Y [Pos .. Pos+h]. Clear glass (see-through), magenta glow = bounds.
$summon minecraft:block_display ~ ~ ~ {Tags:["ec.dbg_hitbox"],Rotation:[0f,0f],brightness:{block:15,sky:15},glow_color_override:16711935,Glowing:1b,view_range:4.0f,block_state:{Name:"minecraft:glass"},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[$(nhw),$(zero),$(nhw)],scale:[$(w),$(h),$(w)]}}
