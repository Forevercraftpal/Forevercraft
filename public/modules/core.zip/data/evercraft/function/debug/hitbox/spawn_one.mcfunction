# Debug: render ONE glass box matching a single interaction entity's hitbox.
# Run as operator. @s MUST be a minecraft:interaction entity, executed `at @s`
#   (its Pos = the BOTTOM-CENTER of the hitbox AABB; width is symmetric on X/Z,
#    height grows UP from Pos.y — per the 2026-05-28 menu-physics research).
# Called by evercraft:debug/hitbox/show. (debug) — not wired into any tick.

# Read this hitbox's real dimensions into storage as FLOATS (blocks).
#   `data get ... <scale>` yields an int (milli-blocks); the store `<scale>` divides it back.
execute store result storage evercraft:debug hb.w float 0.001 run data get entity @s width 1000
execute store result storage evercraft:debug hb.h float 0.001 run data get entity @s height 1000
# nhw = -width/2 (centers the box on X/Z): read half-width (x500), store negated (x-0.001).
execute store result storage evercraft:debug hb.nhw float -0.001 run data get entity @s width 500
# Y-translation element. MUST be a float tag too so the translation list stays homogeneous
# (SNBT lists can't mix double+float; macro-rendered floats from same-typed tags match).
data modify storage evercraft:debug hb.zero set value 0.0f

# Bake the correctly-sized box at this entity's Pos (summon-time transform = proven pattern).
function evercraft:debug/hitbox/spawn_box with storage evercraft:debug hb
