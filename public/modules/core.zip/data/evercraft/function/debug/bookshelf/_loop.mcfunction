# Debug: spawn a numbered marker at slot #dbg_i (0-11), then recurse (run as the nook anchor).
# Uses the live _slot_offset table so the markers track the real plate/probe positions.
execute if score #dbg_i ec.var matches 12.. run return 0
scoreboard players operation #slot_i ec.temp = #dbg_i ec.var
function evercraft:decor/books/_slot_offset
data modify storage evercraft:books nm.face set from entity @s data.face
execute store result storage evercraft:books nm.slot int 1 run scoreboard players get #dbg_i ec.var
function evercraft:debug/bookshelf/_mark with storage evercraft:books nm
scoreboard players add #dbg_i ec.var 1
function evercraft:debug/bookshelf/_loop
