# Debug: visualize the nearest bookshelf nook's 12 slot positions as numbered glowing markers.
# Run as yourself near a nook:  /function evercraft:debug/bookshelf/show
# Workflow: stand in front of a nook -> run this -> screenshot -> tell me which slot NUMBERS sit on
# the wrong chiseled book -> I fix decor/books/_slot_offset -> /function evercraft:debug/bookshelf/clear
# The markers use the SAME _slot_offset table as the real title plates + gaze probes, so where a
# number sits is exactly where that slot's plate/probe is. Magenta cube = the point; yellow number =
# the slot index. (debug) — not wired into any tick.
function evercraft:debug/bookshelf/clear
scoreboard players set #dbg_shelf ec.var 1
scoreboard players set #dbg_i ec.var 0
execute as @e[type=marker,tag=ec.dec_anchor,nbt={data:{id:"bookshelf_nook"}},distance=..16,limit=1,sort=nearest] at @s run function evercraft:debug/bookshelf/_loop
execute unless entity @e[type=marker,tag=ec.dec_anchor,nbt={data:{id:"bookshelf_nook"}},distance=..16,limit=1] run tellraw @s [{text:"[shelf] ",color:"red",bold:true},{text:"No bookshelf nook within 16 blocks. Stand near one and run show again.",color:"gray"}]
execute if entity @e[type=marker,tag=ec.dec_anchor,nbt={data:{id:"bookshelf_nook"}},distance=..16,limit=1] run tellraw @s [{text:"[shelf] ",color:"light_purple",bold:true},{text:"Showing slot markers 0-11 on the nearest nook. Compare each number to the chiseled book in that slot — tell me which numbers are off and where they should be. Then /function evercraft:debug/bookshelf/clear",color:"gray"}]
