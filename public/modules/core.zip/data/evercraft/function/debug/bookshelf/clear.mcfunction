# Debug: remove the bookshelf slot-position overlay.
# Run:  /function evercraft:debug/bookshelf/clear   (debug)
kill @e[type=block_display,tag=ec.dbg_shelf]
kill @e[type=text_display,tag=ec.dbg_shelf]
scoreboard players set #dbg_shelf ec.var 0
tellraw @s [{text:"[shelf] ",color:"light_purple",bold:true},{text:"Cleared slot overlay.",color:"gray"}]
