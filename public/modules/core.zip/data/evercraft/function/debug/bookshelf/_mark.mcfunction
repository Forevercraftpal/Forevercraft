# Debug: bake one slot marker (MACRO; run as the anchor). Args (storage books nm): face, slot, ox/oy/oz.
# A small magenta-glowing glass cube at the exact slot point + a yellow slot-number label above it,
# placed with the SAME rotated offset as the real plates/probes. Both tagged ec.dbg_shelf for clear.
$execute rotated $(face) 0 positioned ^$(ox) ^$(oy) ^$(oz) run summon block_display ~ ~ ~ {Tags:["ec.dbg_shelf"],brightness:{block:15,sky:15},glow_color_override:16711935,Glowing:1b,view_range:4.0f,block_state:{Name:"minecraft:glass"},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[-0.05f,-0.05f,-0.05f],scale:[0.1f,0.1f,0.1f]}}
$execute rotated $(face) 0 positioned ^$(ox) ^$(oy) ^$(oz) run summon text_display ~ ~ ~ {Tags:["ec.dbg_shelf"],billboard:"center",see_through:true,background:1140850688,text:"$(slot)",transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0.14f,0f],scale:[0.4f,0.4f,0.4f]}}
