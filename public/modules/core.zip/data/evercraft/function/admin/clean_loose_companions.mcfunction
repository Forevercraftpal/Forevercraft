# ══════════════════════════════════════════════════════════════
# Admin (debug): CLEAN LOOSE COMPANION ENTITIES — world-wide sweep
# Usage: /function evercraft:admin/clean_loose_companions
# Kills every VISIBLE companion entity (active pet / placed / home / wild) in all loaded
# chunks. Currently-active pets of online players are caught too — harmless, they re-summon
# from the codex. Repeatable + idempotent (a missing entity is a no-op kill).
#
# SAFE: targets only item_display / text_display / interaction / chicken / wolf / armor_stand
# tagged entities. NEVER touches type=marker — the per-player DATA holders
# (companion.marker = Pets array, companion.menuanchor, companion.new, companion.oreprobe)
# survive, so no player's roster/data is wiped. To scope to an area instead, run it via
# `execute at <player> positioned ...` and add distance=.. to the selectors.
# ══════════════════════════════════════════════════════════════

# --- Active pet cluster (head model + hp label passenger + petting hitbox + combat wolf) ---
kill @e[type=text_display,tag=companion.hp_label]
kill @e[type=item_display,tag=Companion]
kill @e[type=interaction,tag=companion.petinteract]
kill @e[type=wolf,tag=CompanionWolf]
kill @e[type=item_display,tag=companion.newpet]
kill @e[type=text_display,tag=companion.infooverlay]
kill @e[type=armor_stand,tag=companion.oremarker]

# --- Placed companion cluster (house-placed pet: chicken carrier + head + interact) ---
kill @e[type=chicken,tag=PlacedCompanion]
kill @e[type=item_display,tag=PC.Head]
kill @e[type=interaction,tag=PC.Interact]

# --- Home/guild companion cluster ---
kill @e[type=chicken,tag=HomeCompanion]
kill @e[type=item_display,tag=HC.Head]
kill @e[type=interaction,tag=HC.Interact]

# --- Wild companion cluster (encounter carrier + head + labels + battle hitbox) ---
kill @e[type=chicken,tag=wc.carrier]
kill @e[type=item_display,tag=wc.head]
kill @e[type=text_display,tag=wc.wild]
kill @e[type=text_display,tag=wc.shiny_label]
kill @e[type=interaction,tag=wc.in_battle]
