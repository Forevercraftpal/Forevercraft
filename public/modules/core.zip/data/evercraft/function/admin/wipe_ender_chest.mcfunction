# Strip — Force-wipe player's ender chest
# Called from pioneer_death.mcfunction BEFORE strip_player_zero.
#
# 26.1 path: player EnderItems is the player-NBT array backing the ender chest
# inventory. `data modify entity @s EnderItems set value []` directly clears it.
# This replaces the prior "EnderItems not directly accessible in 1.21.11" note in
# pioneer_death — the modern 26.1 entity-NBT surface supports the write.
#
# If a future MC release walls off player-NBT write access to EnderItems, this
# function is the single point to change (e.g., place-ender-chest-and-drain trick).

data modify entity @s EnderItems set value []
