# Admin: reset the structure-crate "limit of discovery" count for a player.
# Run as the TARGET player: execute as <player> run function evercraft:admin/reset_crate_count
# (or just /function evercraft:admin/reset_crate_count while playing as yourself).
#
# ec.struct_crates is the dedicated crates-actually-spawned counter that
# structures/container/check_crate_cap gates the DR-scaled "Your mind has reached its limit of
# discovery" lock on (since 2026-06-05 — previously the cap read adv.stat_struct, which is the
# Explorer tree's exploration stat and was inflated by grant_tree_credit). Zeroing it lifts the
# lock so the player can open crates again from 0. Explorer progress (adv.stat_struct) is untouched.
# (Joseph 2026-06-05.)

scoreboard players set @s ec.struct_crates 0

# Confirmation (white body, not bold — popup law)
data modify storage evercraft:notify stage.c set value [{text:"Structure-crate count reset. ",color:"gray",italic:true},{text:"Your discovery limit is clear.",color:"green",italic:true}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
