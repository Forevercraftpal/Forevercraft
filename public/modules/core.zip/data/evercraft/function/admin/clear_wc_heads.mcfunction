# Admin: Kill all orphaned wild companion battle entities
# Usage: /function evercraft:admin/clear_wc_heads

kill @e[type=item_display,tag=wc.head]
kill @e[type=text_display,tag=wc.wild]
kill @e[type=text_display,tag=wc.shiny_label]
kill @e[type=interaction,tag=wc.in_battle]
kill @e[type=chicken,tag=wc.carrier]

tellraw @a [{text:"[Admin] ",color:"dark_red"},{text:"Cleared all orphaned wild companion entities.",color:"gray"}]
