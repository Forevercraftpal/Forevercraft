# ══════════════════════════════════════════════════════════════
# Admin: Force-break a Hearthstone (run as operator, looking at the stone)
# Usage: Stand near / look at the Hearthstone you want to remove, then run:
#   /function evercraft:admin/housing/force_break
# (admin)
#
# Routes through the NORMAL on_break (KEEPS the recovery snapshot + the
# deferred-reset enqueue), so the owner can still recover the home and the
# cleanup never orphans state. Does NOT raw-setblock-air (that would re-create
# the ghost-home bug AU31-Q2 was built to close). Mirrors admin/strip_target:
# raycast a short distance to the nearest marker, tag it HS.AdminBreak so the
# β break gate treats the removal as authorized, then break it.
# ══════════════════════════════════════════════════════════════

# Find the nearest HS.Marker within ~6 blocks of the operator's crosshair.
execute at @s anchored eyes positioned ^ ^ ^4 as @e[type=marker,tag=HS.Marker,tag=!HS.Pending,distance=..6,sort=nearest,limit=1] at @s run function evercraft:admin/housing/force_break_one

# Confirm to the operator if no stone was found nearby.
execute unless entity @e[type=marker,tag=HS.Marker,tag=!HS.Pending,distance=..8,limit=1] run tellraw @s [{text:"[Admin] ",color:"dark_red"},{text:"No Hearthstone found nearby — stand closer to the stone.",color:"gray"}]
