# ══════════════════════════════════════════════════════════════
# Admin: force-break a single targeted Hearthstone marker
# Run as: @s = the HS.Marker, at the marker (dispatched from force_break).
# (admin)
# Tag HS.AdminBreak (the β break gate reads it as authorized), remove the
# lodestone block ourselves, then run on_break — which snapshots the home to
# recovery, enqueues the deferred reset for the (possibly offline) owner,
# tears down entities/registry/forceload, and kills the marker. The tag dies
# with the marker, so no cleanup is needed.
# ══════════════════════════════════════════════════════════════

tag @s add HS.AdminBreak

# Remove the lodestone block (we are at the marker = the stone's position).
setblock ~ ~ ~ air

# Confiscate any lodestone drop from the setblock so the admin break leaves no
# free stone (on_break also color-drops loot; this kills the vanilla drop).
kill @e[type=item,distance=..3,nbt={Item:{id:"minecraft:lodestone"}}]

# Full teardown (recovery snapshot + deferred-reset enqueue preserved).
function evercraft:housing/on_break
