# ══════════════════════════════════════════════════════════════
# Admin: Strip a targeted player (run as yourself, looking at target)
# Usage: Look at the player you want to reset, then run:
#   /function evercraft:admin/strip_target
# ══════════════════════════════════════════════════════════════

# Raycast to nearest player within 5 blocks of crosshair
execute at @s anchored eyes positioned ^ ^ ^5 as @a[distance=..3,sort=nearest,limit=1] at @s run function evercraft:admin/strip_player_zero

# Confirm to admin
execute at @s anchored eyes positioned ^ ^ ^5 as @a[distance=..3,sort=nearest,limit=1] run tellraw @p [{text:"[Admin] ",color:"dark_red"},{text:"Reset applied to ",color:"gray"},{selector:"@s",color:"red"},{text:".",color:"gray"}]
