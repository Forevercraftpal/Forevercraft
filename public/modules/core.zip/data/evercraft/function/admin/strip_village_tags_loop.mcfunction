# Strip — Iterate the player's snapshotted Tags list and remove any jn.v_* tags
# Recursive loop: pops taglist[0], slices first 5 chars, if "jn.v_" then macro-removes
# Pre-condition: storage evercraft:strip taglist set from entity @s Tags
# @s = the player being stripped

# Base case — list empty
execute unless data storage evercraft:strip taglist[0] run return 0

# Take the head tag value into a scratch path and slice the prefix (first 5 chars)
data modify storage evercraft:strip vt set from storage evercraft:strip taglist[0]
data modify storage evercraft:strip vt_pfx set string storage evercraft:strip vt 0 5

# If the prefix matches "jn.v_", copy the full tag into the macro arg and remove it
execute if data storage evercraft:strip {vt_pfx:"jn.v_"} run data modify storage evercraft:strip vtag_arg.vtag set from storage evercraft:strip vt
execute if data storage evercraft:strip {vt_pfx:"jn.v_"} run function evercraft:admin/strip_village_tag with storage evercraft:strip vtag_arg

# Pop the head and recurse
data remove storage evercraft:strip taglist[0]
function evercraft:admin/strip_village_tags_loop
