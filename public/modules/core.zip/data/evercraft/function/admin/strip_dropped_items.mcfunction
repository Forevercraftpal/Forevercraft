# Strip — Reclaim Dropped Items
# Called from pioneer_death.mcfunction BEFORE strip_player_zero, anchored at @s
# Kills every progression-bearing item entity within 256 blocks of the death site.
# Covers: Forever Coin, 17 dream luck items, all 336 artifacts (is_artifact:1b),
# Ore Bag, Hero Satchel, Pet Memento, Chrono Shard.
#
# Caller MUST run via: execute at @s run function evercraft:admin/strip_dropped_items
# Item entity NBT serializes loot-table booleans as bytes (1b), not "true".

# === Forever Coin ===
kill @e[type=item,distance=..256,nbt={Item:{id:"minecraft:amethyst_shard",components:{"minecraft:custom_data":{forever_coin:1b}}}}]

# === 17 Dream Luck Items (one-time consumables with permanent luck modifiers) ===
kill @e[type=item,distance=..256,nbt={Item:{id:"minecraft:stick",components:{"minecraft:custom_data":{dream_inducing_mushroom:1b}}}}]
kill @e[type=item,distance=..256,nbt={Item:{id:"minecraft:phantom_membrane",components:{"minecraft:custom_data":{crystalized_dream_droppings:1b}}}}]
kill @e[type=item,distance=..256,nbt={Item:{id:"minecraft:amethyst_shard",components:{"minecraft:custom_data":{crystal_of_dreams:1b}}}}]
kill @e[type=item,distance=..256,nbt={Item:{id:"minecraft:popped_chorus_fruit",components:{"minecraft:custom_data":{chorus_dreaming_fruit:1b}}}}]
kill @e[type=item,distance=..256,nbt={Item:{id:"minecraft:feather",components:{"minecraft:custom_data":{dreamers_quill:1b}}}}]
kill @e[type=item,distance=..256,nbt={Item:{id:"minecraft:string",components:{"minecraft:custom_data":{dreamweavers_thread:1b}}}}]
kill @e[type=item,distance=..256,nbt={Item:{id:"minecraft:nether_star",components:{"minecraft:custom_data":{patrons_dream_essence:1b}}}}]
kill @e[type=item,distance=..256,nbt={Item:{id:"minecraft:book",components:{"minecraft:custom_data":{tome_of_lucid_visions:1b}}}}]
kill @e[type=item,distance=..256,nbt={Item:{id:"minecraft:paper",components:{"minecraft:custom_data":{astral_codex_page:1b}}}}]
kill @e[type=item,distance=..256,nbt={Item:{id:"minecraft:tripwire_hook",components:{"minecraft:custom_data":{fishermans_dozing_lure:1b}}}}]
kill @e[type=item,distance=..256,nbt={Item:{id:"minecraft:raw_copper",components:{"minecraft:custom_data":{miners_slumbering_geode:1b}}}}]
kill @e[type=item,distance=..256,nbt={Item:{id:"minecraft:wheat_seeds",components:{"minecraft:custom_data":{harvesters_dreamy_seed:1b}}}}]
kill @e[type=item,distance=..256,nbt={Item:{id:"minecraft:magma_cream",components:{"minecraft:custom_data":{blacksmiths_dreaming_ember:1b}}}}]
kill @e[type=item,distance=..256,nbt={Item:{id:"minecraft:paper",components:{"minecraft:custom_data":{wanderers_dream_map:1b}}}}]
kill @e[type=item,distance=..256,nbt={Item:{id:"minecraft:raw_gold",components:{"minecraft:custom_data":{prospectors_dream_ore:1b}}}}]
kill @e[type=item,distance=..256,nbt={Item:{id:"minecraft:echo_shard",components:{"minecraft:custom_data":{collectors_dream_relic:1b}}}}]
kill @e[type=item,distance=..256,nbt={Item:{id:"minecraft:torchflower_seeds",components:{"minecraft:custom_data":{tillers_dream_petal:1b}}}}]

# === Artifacts (336 — match the shared is_artifact:1b flag, item id varies) ===
kill @e[type=item,distance=..256,nbt={Item:{components:{"minecraft:custom_data":{is_artifact:1b}}}}]

# === Ore Bag (leather base) ===
kill @e[type=item,distance=..256,nbt={Item:{id:"minecraft:leather",components:{"minecraft:custom_data":{ore_bag:1b}}}}]

# === Hero Satchel (leather base) ===
kill @e[type=item,distance=..256,nbt={Item:{id:"minecraft:leather",components:{"minecraft:custom_data":{hero_satchel:1b}}}}]

# === Pet Memento (variable base item per pet_type — match on the custom_data flag only) ===
kill @e[type=item,distance=..256,nbt={Item:{components:{"minecraft:custom_data":{pet_memento:1b}}}}]

# === Chrono Shard (echo_shard base) ===
kill @e[type=item,distance=..256,nbt={Item:{id:"minecraft:echo_shard",components:{"minecraft:custom_data":{chrono_shard:1b}}}}]

tellraw @s [{text:"☠ ",color:"dark_red"},{text:"The dream reclaims what fell with you.",color:"gray",italic:true}]
