# ══════════════════════════════════════════════════════════════
# Admin: COMPLETE player progression reset
# Run as TARGET: execute as <player> run function evercraft:admin/strip_player_zero
# WARNING: This is IRREVERSIBLE! Resets ALL player data.
# ══════════════════════════════════════════════════════════════

# === CLEAR INVENTORY + EQUIPMENT ===
clear @s
item replace entity @s armor.head with minecraft:air
item replace entity @s armor.chest with minecraft:air
item replace entity @s armor.legs with minecraft:air
item replace entity @s armor.feet with minecraft:air
item replace entity @s weapon.offhand with minecraft:air

# === REVOKE ALL ADVANCEMENTS ===
advancement revoke @s everything

# === RESET ALL XP ===
experience set @s 0 points
experience set @s 0 levels

# === PRE-NUKE: clear per-player storage + kill player-keyed entities ===
# Must run BEFORE the nuclear scoreboard reset because we depend on
# companion.id / ec.obid / ec.hbag_id still being set to their live values.

# Companion marker entity (chunk-loader leak fix) — predicate matches @s companion.id
scoreboard players operation #Search companion.id = @s companion.id
kill @e[type=marker,tag=companion.marker,predicate=evercraft:companions/check_id]

# Blueprint preview/origin markers — local-only, distance-anchored at the player
execute at @s run kill @e[type=armor_stand,tag=bp.corner,distance=..64]
execute at @s run kill @e[type=marker,tag=bp.origin,distance=..64]
execute at @s run kill @e[type=marker,tag=bp.building,distance=..64]

# Ore Bag stored contents — snapshot pid, then macro-clear bags.<pid>
execute store result storage evercraft:strip temp.pid int 1 run scoreboard players get @s ec.obid
function evercraft:ore_bag/clear_bag with storage evercraft:strip temp

# Hero Satchel stored contents — snapshot bid, then macro-clear bags.<bid>
execute store result storage evercraft:strip temp.bid int 1 run scoreboard players get @s ec.hbag_id
function evercraft:hero_satchel/clear_bag with storage evercraft:strip temp

# Pet Memento storage — UUID-keyed (mementos."<UUID>" + slots."<UUID>")
data modify storage evercraft:strip temp.UUID set from entity @s UUID
function evercraft:tamed_bond/clear_memento with storage evercraft:strip temp

# Satchel + Hero-Satchel virtually-held marks (Joseph 2026-06-12 fix). MUST run
# pre-nuke: recompute_clear reads ec.satchel_id and recompute_pebble_clear reads
# ec.hsatch_id — both are zeroed by the nuclear scoreboard reset below, which
# made the previously-installed clear calls (~line 2249) silently early-exit and
# left every ec.sat_<id> tag intact. First post-respawn artifact pickup then re-
# entered player_tick's sat-branches and re-applied the dead character's buffs.
# Same shape as the ore_bag / hero_satchel bag clears above: snapshot live ID,
# clear, drop temp.
function evercraft:satchel/recompute_clear
function evercraft:hero_satchel/recompute_pebble_clear

data remove storage evercraft:strip temp

# --- tamed_bond (Council #6, 2026-05-27 — player-scoped scratch added) ---
# Was shared scratch #tb_player_u0/u1 + #tb_owner_u0/u1 ec.temp in check_owner.
# Nuclear reset below covers these, but explicit 0-set keeps the contract obvious.
scoreboard players set @s ec.tb_player_u0 0
scoreboard players set @s ec.tb_player_u1 0
scoreboard players set @s ec.tb_owner_u0 0
scoreboard players set @s ec.tb_owner_u1 0

# === NUCLEAR SCOREBOARD RESET ===
# Resets EVERY scoreboard objective for this player in one command.
# This covers all 500+ player objectives across all systems — no more missed scores.
scoreboard players reset @s

# === STORY: Seasonal Chronicles state (ch701-730) ===
# `scoreboard players reset` clears these, but we set them explicitly to 0 so the
# matches-N gates in chapter/chN/check.mcfunction (and the new _unlock gate from
# the 2026-05-26 council convening) read deterministically post-wipe. Also resets
# the 30 _replay flags (skip partial-vs-full reward gate) and branch7 finale marker.
function evercraft:story/admin/reset_seasonal

# === (Legacy per-objective resets removed — the single reset above handles everything) ===
# --- adv (1) ---
scoreboard players set @s adv.gui_session 0

# --- cf (1) ---
scoreboard players set @s cf.vault_ominous 0

# --- ec (112) ---
scoreboard players set @s ec.affinity_match 0
scoreboard players set @s ec.anec_beast 0
scoreboard players set @s ec.anec_elder 0
scoreboard players set @s ec.anec_fisher 0
scoreboard players set @s ec.anec_miner 0
scoreboard players set @s ec.anec_scholar 0
scoreboard players set @s ec.anec_wanderer 0
scoreboard players set @s ec.artifact_count 0
scoreboard players set @s ec.biome_id 0
scoreboard players set @s ec.biome_last 0
scoreboard players set @s ec.biome_prev 0
scoreboard players set @s ec.block_glow 0
scoreboard players set @s ec.bm_quicksell 0
scoreboard players set @s ec.bounty_done 0
# Wiring Audit #7 (2026-05-28) F7: claim-family Pioneer-wipe coverage (18 scoreboards).
scoreboard players set @s ec.bulk_clm 0
scoreboard players set @s ec.claim_any 0
scoreboard players set @s ec.claim_aff 0
scoreboard players set @s ec.claim_biome 0
scoreboard players set @s ec.claim_bst 0
scoreboard players set @s ec.claim_cft 0
scoreboard players set @s ec.claim_cnt 0
scoreboard players set @s ec.claim_lore 0
scoreboard players set @s ec.claim_prs 0
scoreboard players set @s ec.claim_rm 0
scoreboard players set @s ec.claim_shw -1
scoreboard players set @s ec.curr_scratch 0
scoreboard players set @s ec.prev_claims 0
scoreboard players set @s ec.prev_scratch 0
scoreboard players set @s ec.total_claims 0
scoreboard players set @s ec.auto_clm 0
scoreboard players set @s ec.ff_qualified 0
scoreboard players set @s ec.hh_qualified 0
scoreboard players set @s ec.exp_qualified 0
scoreboard players set @s ec.asc_qualified 0
# ec.codex trigger removed 2026-05-26 (v1 text-UI archive — see _council/2026-05-26-dead-code-codex/)
scoreboard players set @s ec.codex_page_count 0
scoreboard players set @s ec.codex_ret_dim 0
scoreboard players set @s ec.codex_ret_x 0
scoreboard players set @s ec.codex_ret_y 0
scoreboard players set @s ec.codex_ret_z 0
scoreboard players set @s ec.codex_spec_cd 0
scoreboard players set @s ec.codex_spec_time 0
scoreboard players set @s ec.codex_tp 0
scoreboard players set @s ec.codex_use 0
scoreboard players set @s ec.compass_cd 0
scoreboard players set @s ec.crate_ach 0
scoreboard players set @s ec.crate_art 0
scoreboard players set @s ec.crate_comp 0
scoreboard players set @s ec.crate_plot 0
scoreboard players set @s ec.crate_quest 0
scoreboard players set @s ec.crate_tier 0
scoreboard players set @s ec.ddex 0
scoreboard players set @s ec.debug 0
scoreboard players set @s ec.dr_history 0
scoreboard players set @s ec.dr_peak_ms 0
scoreboard players set @s ec.dr_peak 0
scoreboard players set @s ec.dr_peak_migr 0
scoreboard players set @s ec.dream_rank 0
scoreboard players set @s ec.ms_unlock 1
scoreboard players set @s ec.ms_notif_hi 1
advancement revoke @s from evercraft:notif/root
scoreboard players set @s ec.dream_petal_count 0
scoreboard players set @s ec.dream_relic_count 0
scoreboard players set @s ec.dreams 0
scoreboard players set @s ec.echo_cd 0
scoreboard players set @s ec.ember_count 0
scoreboard players set @s ec.geode_count 0
scoreboard players set @s ec.has_artifacts 0
scoreboard players set @s ec.health 0
scoreboard players set @s ec.health_pct 0
scoreboard players set @s ec.healthbar 0
scoreboard players set @s ec.last_day 0
scoreboard players set @s ec.last_scorch 0
scoreboard players set @s ec.leave 0
scoreboard players set @s ec.lightning_cd 0
scoreboard players set @s ec.loot_timer 0
scoreboard players set @s ec.lure_count 0
scoreboard players set @s ec.map_count 0
scoreboard players set @s ec.max_health 0
scoreboard players set @s ec.mob_glow 0
scoreboard players set @s ec.monocle_cd 0
scoreboard players set @s ec.moon 0
scoreboard players set @s ec.move_lastx 0
scoreboard players set @s ec.move_lastz 0
scoreboard players set @s ec.moving 0
scoreboard players set @s ec.ncore 0
scoreboard players set @s evercraft.nc_blocks 0
scoreboard players set @s anc.level 0
scoreboard players set @s anc.primary 0
tag @s remove nc_absorbing
tag @s remove ec.nc_max_warned
scoreboard players set @s ec.newcomer_pick 0
scoreboard players set @s ec.notify 0
scoreboard players set @s ec.notify_lvl 0
scoreboard players set @s ec.nchan 0
scoreboard players set @s ach.mu_level_up 0
scoreboard players set @s ach.nx_level_up 0
scoreboard players set @s ach.mu_ms_stage 0
scoreboard players set @s ach.nx_ms_stage 0
scoreboard players set @s ec.nm_level_up 0
scoreboard players set @s ec.un_level_up 0
scoreboard players set @s ec.nm_ms_stage 0
scoreboard players set @s ec.un_ms_stage 0
scoreboard players set @s ec.ore_prev 0
scoreboard players set @s ec.patron_dream_count 0
scoreboard players set @s ec.pet_bonded 0
scoreboard players set @s ec.pos_x 0
scoreboard players set @s ec.pos_y 0
scoreboard players set @s ec.pos_z 0
scoreboard players set @s ec.quest 0
scoreboard players set @s ec.quest_track 0
scoreboard players set @s ec.quill_count 0
scoreboard players set @s ec.rh_beet 0
scoreboard players set @s ec.rh_carrot 0
scoreboard players set @s ec.rh_nwart 0
scoreboard players set @s ec.rh_potato 0
scoreboard players set @s ec.rh_wheat 0
scoreboard players set @s ec.sapling_age 0
scoreboard players set @s ec.sapling_try 0
scoreboard players set @s ec.seed_count 0
scoreboard players set @s ec.spark 0
scoreboard players set @s ec.spark_claims 0
scoreboard players set @s ec.spark_notified 0
scoreboard players set @s ec.spark_peak_show 0
# WP6 generosity (2026-05-29): daily free-wish accumulator + collection milestone flag.
scoreboard players set @s ec.free_pulls 0
scoreboard players set @s ec.coll_common 0
scoreboard players set @s ec.stats 0
# First-crate grace pass — reset so a reborn Pioneer gets one free above-ground crate again
# (structures/container/check_dream_gate; Joseph 2026-06-04).
scoreboard players set @s ec.first_crate_used 0
scoreboard players set @s ec.struct_1 0
scoreboard players set @s ec.struct_10 0
scoreboard players set @s ec.struct_11 0
scoreboard players set @s ec.struct_12 0
scoreboard players set @s ec.struct_13 0
scoreboard players set @s ec.struct_14 0
scoreboard players set @s ec.struct_15 0
scoreboard players set @s ec.struct_16 0
scoreboard players set @s ec.struct_17 0
scoreboard players set @s ec.struct_18 0
scoreboard players set @s ec.struct_19 0
scoreboard players set @s ec.struct_2 0
scoreboard players set @s ec.struct_20 0
scoreboard players set @s ec.struct_21 0
scoreboard players set @s ec.struct_22 0
scoreboard players set @s ec.struct_3 0
scoreboard players set @s ec.struct_4 0
scoreboard players set @s ec.struct_5 0
scoreboard players set @s ec.struct_6 0
scoreboard players set @s ec.struct_7 0
scoreboard players set @s ec.struct_8 0
scoreboard players set @s ec.struct_9 0
scoreboard players set @s ec.struct_unique 0
scoreboard players set @s ec.temp 0
scoreboard players set @s ec.thread_count 0
scoreboard players set @s ec.tome_count 0
scoreboard players set @s ec.tome_lvl 0
scoreboard players set @s ec.tome_pts 0
scoreboard players set @s ec.var 0

# --- Already covered (included for completeness) ---
scoreboard players set @s ach.prospects_done 0
scoreboard players set @s ach.quests_done 0
scoreboard players set @s ach.total 0
# === ADVANTAGE TREES — full canonical reset (Joseph 2026-06-10) ===
# This block had accumulated a DRIFTED PARTIAL copy of the advantage reset: only 7 of the
# 15 tree LEVELS were zeroed (chemistry/combat/culinary/explorer/fishing/mining/taskmaster),
# so a reborn Pioneer kept Dexterity/Agility/Evasion/Stealth/Vitality/Beastmaster/Victorian/
# Gathering/Blacksmith levels, ALL prestiges, synergies, tokens, banked prestiges and the
# tree attribute modifiers ("advantage player progress rolled over"). Call the canonical
# full reset instead (same pattern as the chrono_shard/reset/bestiary call below): zeroes
# all 15 levels + every stat/credit tracker + re-seeds baselines to the current counters +
# prestiges + banked prestiges + synergies + tokens + challenges + cosmetics + prestige-
# ability states, leaves the cosmetic team, and runs effects/reapply_all so the tree
# attribute modifiers drop with the levels. Earlier piecemeal fixes (stat_place 2026-06-04,
# stat_struct 2026-06-04, cr_* 2026-06-08, activity counters 2026-06-04) are all subsumed.
function evercraft:chrono_shard/reset/advantage
# Strip-only extras the canonical reset doesn't own:
scoreboard players set @s adv.combat 0
scoreboard players set @s adv.stat_combat 0
scoreboard players set @s adv.stat_explore 0
scoreboard players set @s adv.stat_campfire 0
scoreboard players set @s adv.stat_vbrew 0
scoreboard players set @s adv.stat_vsmelt 0
# Transient challenge state beyond the 4 scores the canonical reset covers — a reborn
# player must not inherit a half-done challenge or a pending cancel/reminder.
scoreboard players set @s adv.chal_75 0
scoreboard players set @s adv.chal_aux 0
scoreboard players set @s adv.chal_cancel 0
scoreboard players set @s adv.chal_lprog 0
scoreboard players set @s adv.chal_remind 0
# ach.blocks_placed mirrors adv.stat_place via achievements/sync/player_stats; zero the
# mirror so it's deterministic instead of inheriting a stale/absent value (Joseph 2026-06-04).
scoreboard players set @s ach.blocks_placed 0
# build_quests auto-pass flag (Joseph 2026-06-05): a transient 0/1 set at a quest's
# activation if it was already satisfied with zero effort. Must not survive a wipe —
# a reborn player should never inherit a stale "auto-passed" verdict. (The bq linear
# pointer itself is owned/reset by the line's own start; this is the one transient
# bq flag a Pioneer-wipe needs to clear.)
scoreboard players set @s ec.bq_autopass 0
# Dedicated discovery-cap counter (the one check_crate_cap reads since 2026-06-05) — zero it so a
# reborn Pioneer starts uncapped, independent of the Explorer stat. (stat_struct history: the old
# survived value made the DR-scaled cap fire instantly and locked reborn Pioneers out of all
# structure crates, Joseph 2026-06-04.)
scoreboard players set @s ec.struct_crates 0
# R3: 0 is the "no companion" SENTINEL (not a real id). A fully-stripped player has no
# companions + a nuked marker, so the sentinel is correct; new_player re-mints a fresh id >= 1
# from #Global next time they earn one (its advancement is revoked by the `advancement revoke @s
# everything` at the top of this file).
scoreboard players set @s companion.id 0
scoreboard players set @s companion.level 0
# --- SP1 / KEYSTONE horn ability state (Companion Overhaul Wave 1) ---
# Every NEW per-player companion scoreboard must reset on a full strip, or a stripped player inherits
# phantom horn state (DATA-MODEL §2.1). Per-instance NBT (horn_active/horn_slots) is wiped by the
# existing data.Pets nuke. Reset stance to its Active default (0) so the first-summon prompt re-fires.
scoreboard players set @s companion.horncd 0
scoreboard players set @s companion.stance 0
scoreboard players set @s companion.skillslot 0
scoreboard players set @s companion.slots 0
scoreboard players set @s companion.flaghits 0
# --- SP2 bond & care state (Companion Overhaul Wave 2) ---
# Per-instance NBT (bond_skills/happiness/happydays) is wiped by the data.Pets nuke; these are the
# per-player session mirrors that must reset on a full strip (DATA-MODEL §2.1).
scoreboard players set @s companion.happiness 0
scoreboard players set @s companion.happydays 0
scoreboard players set @s companion.happypass 0
scoreboard players set @s companion.bondskills 0
# --- SP3 abandonment & win-back state (Companion Overhaul Wave 3a) ---
# The per-instance `departed` flag is wiped by the data.Pets nuke (marker killed at :28 above); these
# are the per-player session mirrors (DATA-MODEL §2.1, §2.3). Drop the live win-back offer latch too.
scoreboard players set @s companion.neglect 0
scoreboard players set @s companion.wb_slot 0
scoreboard players set @s companion.wb_timer 0
tag @s remove companion.wb_pending
# --- SP4 sub-companions & journeys state (Companion Overhaul Wave 3b) ---
# Per-instance NBT (the sub's profile data) is wiped by the data.Pets nuke at :28; these are the per-player
# session mirrors that must reset on a full strip (DATA-MODEL §2.1). The three.* loadout storage is rebuilt
# from these zeros (it is transient render state, not persistent).
scoreboard players set @s companion.subA_slot 0
scoreboard players set @s companion.subB_slot 0
scoreboard players set @s companion.jrny_cnt 0
scoreboard players set @s companion.jA_end 0
scoreboard players set @s companion.jB_end 0
scoreboard players set @s companion.jA_type 0
scoreboard players set @s companion.jB_type 0
scoreboard players set @s companion.jA_tier 0
scoreboard players set @s companion.jB_tier 0
scoreboard players set @s companion.jA_slot 0
scoreboard players set @s companion.jB_slot 0
scoreboard players set @s companion.sub_gift 0
scoreboard players set @s companion.sub_turn 0
# --- SP5 new-GUI state (Companion Overhaul Wave 4) ---
# Care focus + rename flow per-player mirrors (DATA-MODEL §2.1). Entity-scored stamps
# (headidx/skillidx/careslot/pc.mode) live on transient menu/placed entities, torn down by
# close/orphan-sweep, never on the player — no line needed. The skillpage pager resets too.
scoreboard players set @s companion.careidx 0
scoreboard players set @s companion.renameidx 0
scoreboard players set @s ec.cc_renaming 0
scoreboard players set @s companion.skillpage 0
scoreboard players set @s companion.jrnyslot 0
scoreboard players set @s ec.cc_petcd 0
# --- SP9 house/guild placed-pet Hearth Comfort (Companion Overhaul Plan Two) ---
# Cached comfort scores (best placed companion's tier+bond). The effect itself is short-refresh and
# lapses on its own; these are the per-player caches that must reset on a full strip (DATA-MODEL §2.1).
scoreboard players set @s companion.hcomfort 0
scoreboard players set @s companion.gcomfort 0
# --- SP7 ascension (dupes→slots) + SP8 Wayfarer Track + chips (Companion Overhaul Wave 5b) ---
# Per-instance NBT (horn_slots / chip_slots, the earned + chip-sourced slots) is wiped by the data.Pets
# nuke; these are the per-player Track + GUI mirrors. The nuclear reset above covers them, but the file's
# convention is explicit 0-sets so the matches-N gates in track/* + wayfarer/* read deterministically.
# GATED 2026-06-21 (Joseph): a Pioneer DEATH tags @s ec.wf_keep before calling this strip, so the
# Wayfarer Track survives as a safe space (mirror of the ec.cdxv_keep precedent below). The total wf_xp
# is folded into the persistent ec.wf_bonus fake + node/season snapshotted, and the 250 claimed/nN advs
# are storage-snapshotted + restored in difficulty/pioneer_death. An ADMIN factory reset carries no such
# tag → every line below runs exactly as before. (companion.wf_page / wf_clicknode are transient GUI
# pager state and stay UNGATED — a reborn player should start on a fresh page.)
execute unless entity @s[tag=ec.wf_keep] run scoreboard players set @s ec.wf_xp 0
execute unless entity @s[tag=ec.wf_keep] run scoreboard players set @s ec.wf_node 0
execute unless entity @s[tag=ec.wf_keep] run advancement revoke @s from evercraft:companions/track/claimed/root
execute unless entity @s[tag=ec.wf_keep] run scoreboard players set @s ec.wf_baseline 0
execute unless entity @s[tag=ec.wf_keep] run scoreboard players set @s ec.wf_bonus 0

# Codex Vault (Enshrine, 2026-06-10): the full self-purge (revoke deposited advs, zero
# live points/count, drop the per-pid records + view pointer) now lives in the shared
# codex_vault/admin/wipe_self so the Gallery's manual [Wipe] button can reuse it. Enshrined
# items are NOT refunded on a factory reset; records must not survive or a later recompute
# would resurrect points.
# GATED 2026-06-15 (Joseph): a Pioneer DEATH tags @s ec.cdxv_keep before calling this strip,
# so the enshrined-artifact vault survives as a safe space (pid is snapshotted + restored and
# recompute re-grants the advs back in difficulty/pioneer_death). An ADMIN factory reset
# carries no such tag → the vault is fully purged exactly as before.
execute unless entity @s[tag=ec.cdxv_keep] run function evercraft:codex_vault/admin/wipe_self
execute unless entity @s[tag=ec.wf_keep] run scoreboard players set @s ec.wf_season 0
scoreboard players set @s companion.wf_page 0
scoreboard players set @s companion.wf_clicknode 0
scoreboard players set @s ec.journey_type 0
scoreboard players set @s ec.chorus_count 0
scoreboard players set @s ec.coins 0
scoreboard players set @s ec.crystal_count 0
scoreboard players set @s ec.rfoot_count 0
scoreboard players set @s ec.daily_quest 0
scoreboard players set @s ec.tp_daily_day 0
scoreboard players set @s ec.daily_story 0
scoreboard players set @s ec.dg_floors_today 0
scoreboard players set @s ec.dng_attempts 0
# Wiring Audit #18 W3.6: Phase 2 per-player dungeon-active flag.
# Nuclear reset above covers this; explicit reset keeps the contract obvious.
scoreboard players reset @s pt.dg_active
# Wiring Audit B (2026-05-29) W10: per-player castle + raid active flags (mirrors of pt.dg_active).
scoreboard players reset @s pt.ic_active
scoreboard players reset @s pt.rd_active
scoreboard players set @s ec.dream_ore_count 0
scoreboard players set @s ec.droppings_count 0
scoreboard players set @s ec.gift_cd 0
scoreboard players set @s ec.last_gift_time 0
scoreboard players set @s ec.mushroom_count 0
scoreboard players set @s ec.quest_done_1 0
scoreboard players set @s ec.quest_done_2 0
scoreboard players set @s ec.quest_done_3 0
scoreboard players set @s ec.quest_done_4 0
scoreboard players set @s ec.quest_done_5 0
scoreboard players set @s ec.quest_done_6 0
scoreboard players set @s ec.quest_id_1 0
scoreboard players set @s ec.quest_id_2 0
scoreboard players set @s ec.quest_id_3 0
scoreboard players set @s ec.quest_id_4 0
scoreboard players set @s ec.quest_id_5 0
scoreboard players set @s ec.quest_id_6 0
scoreboard players set @s ec.quest_prog_1 0
scoreboard players set @s ec.quest_prog_2 0
scoreboard players set @s ec.quest_prog_3 0
scoreboard players set @s ec.quest_prog_4 0
scoreboard players set @s ec.quest_prog_5 0
scoreboard players set @s ec.quest_prog_6 0
# Wiring Audit #30: explore-quest progress counters + nether-kill rollup
scoreboard players set @s ec.exp_prog_3 0
scoreboard players set @s ec.exp_prog_4 0
scoreboard players set @s ec.exp_prog_5 0
scoreboard players set @s ec.exp_prog_6 0
scoreboard players set @s ec.kills_nether 0
# AU34-1 (Joseph 2026-05-30): H04 Grand Harvest per-crop snapshots
scoreboard players set @s ec.q_h04_wheat_s 0
scoreboard players set @s ec.q_h04_carrot_s 0
scoreboard players set @s ec.q_h04_potato_s 0
scoreboard players set @s ec.q_h04_beetrt_s 0
scoreboard players set @s ec.q_h04_melon_s 0
scoreboard players set @s ec.q_h04_pumpkn_s 0
scoreboard players set @s ec.q_h04_nwart_s 0
scoreboard players set @s ec.q_h04_sugar_s 0
scoreboard players set @s ec.q_h04_berries_s 0
scoreboard players set @s ec.rep_rank 0
scoreboard players set @s ec.sp_kills 0
scoreboard players set @s ec.sp_mastery 0
scoreboard players set @s ec.sp_tier 0
scoreboard players set @s ec.sp_weapon 0
# Spirit-weapon progression counters wired 2026-06-13 (previously declared-but-never-written).
# Nuclear reset above covers these, but the file convention is explicit 0-sets so the
# matches-N progression/metamorphosis gates read deterministically post-wipe. ec.sp_abil_seen
# is the ability-variety bitfield; ec.sp_boss_hurt is the per-fight flawless latch.
scoreboard players set @s ec.sp_revives 0
scoreboard players set @s ec.sp_ocean_explore 0
scoreboard players set @s ec.sp_duel_wins 0
scoreboard players set @s ec.sp_flawless 0
scoreboard players set @s ec.sp_ability_variety 0
scoreboard players set @s ec.sp_abil_seen 0
scoreboard players set @s ec.sp_counter_hits 0
scoreboard players set @s ec.sp_boss_hurt 0
scoreboard players set @s ec.village_rep 0
# FX ambient skip-latch + slow-cadence counter (fx/ambient — one-writer; see init.mcfunction).
scoreboard players set @s ec.has_amb 0
scoreboard players set @s ec.amb_tk 0

# Fusion WAVE 1 (Artifact Fusion, 2026-06-01): Tinkering progression + ever-fused latch.
# Declared in tinkering/declare_objectives.mcfunction:24-66. The nuclear reset above clears
# them, but the file's convention is to ALSO set them explicitly so the matches-N gates in
# tinkering/* read deterministically post-wipe. ec.tnk_owned is the documented safe-OR
# ever-fused bitfield (bit1 = Band, bit0 = Knot, bit2 = Hand) — wiping it re-locks the lattice.
scoreboard players set @s ec.tnk_active 0
scoreboard players set @s ec.tnk_quest 0
scoreboard players set @s ec.tnk_prog 0
scoreboard players set @s ec.tnk_done 0
scoreboard players set @s ec.tnk_complete 0
scoreboard players set @s ec.tnk_offer 0
scoreboard players set @s ec.tnk_owned 0

# === REMOVE ALL PERMANENT LUCK/ATTRIBUTE MODIFIERS ===
attribute @s luck modifier remove evercraft:crystal_of_dreams_bonus
attribute @s luck modifier remove evercraft:rabbits_dreaming_foot_luck
attribute @s luck modifier remove evercraft:dream_droppings_bonus
attribute @s luck modifier remove evercraft:dream_mushroom_bonus
attribute @s luck modifier remove evercraft:chorus_dreaming_bonus
attribute @s luck modifier remove evercraft:patrons_dream_essence_bonus
attribute @s luck modifier remove evercraft:dreamers_quill_bonus
attribute @s luck modifier remove evercraft:dreamweavers_thread_bonus
attribute @s luck modifier remove evercraft:tome_of_lucid_visions_bonus
attribute @s luck modifier remove evercraft:astral_codex_page_bonus
attribute @s luck modifier remove evercraft:fishermans_dozing_lure_bonus
attribute @s luck modifier remove evercraft:miners_slumbering_geode_bonus
attribute @s luck modifier remove evercraft:harvesters_dreamy_seed_bonus
attribute @s luck modifier remove evercraft:blacksmiths_dreaming_ember_bonus
attribute @s luck modifier remove evercraft:wanderers_dream_map_bonus
attribute @s luck modifier remove evercraft:prospectors_dream_ore_bonus
attribute @s luck modifier remove evercraft:collectors_dream_relic_bonus
attribute @s luck modifier remove evercraft:tillers_dream_petal_bonus
attribute @s luck modifier remove evercraft:dreamdust_crystal
attribute @s luck modifier remove evercraft:journal_ow_surface_luck
attribute @s luck modifier remove evercraft:journal_ow_caves_luck
attribute @s luck modifier remove evercraft:journal_nether_luck
attribute @s luck modifier remove evercraft:journal_end_luck
attribute @s luck modifier remove evercraft:constellation_bonus
attribute @s luck modifier remove evercraft:biome_mastery_dr
attribute @s luck modifier remove evercraft:adv_pres_task2
attribute @s luck modifier remove evercraft:adv_pres_task3
attribute @s luck modifier remove evercraft:inscr_gold_greed
attribute @s luck modifier remove ec_rf_gilded
attribute @s luck modifier remove evercraft:boss_dr_1
attribute @s luck modifier remove evercraft:boss_dr_2
attribute @s luck modifier remove evercraft:boss_dr_3
attribute @s luck modifier remove evercraft:boss_dr_4
attribute @s luck modifier remove evercraft:boss_dr_5
attribute @s luck modifier remove evercraft:boss_dr_6
attribute @s luck modifier remove evercraft:boss_dr_7
attribute @s luck modifier remove evercraft:boss_dr_8
attribute @s luck modifier remove evercraft:boss_dr_9
attribute @s luck modifier remove evercraft:boss_dr_10
attribute @s luck modifier remove evercraft:boss_dr_11
attribute @s luck modifier remove evercraft:boss_dr_12
attribute @s luck modifier remove evercraft:boss_dr_13

# Artifact Fusion luck modifiers (WAVE 1, 2026-06-01) — Pebble of Creation tree (Family A)
# + Band of All Rings tree (Family E). Consolidated DR folds (Pebble +18.5 / Aegis +9.0 /
# Astral +8.5 / Band +4.0 / Wardband +1.0 / Voidband +3.0). band_dring/undying are the
# RETAINED legacy ring-charm ids (a pre-migration full Band or a Band of Four Rings still
# carries them). Emitted by hero_satchel/consolidate/* + artifacts/accessories/player_tick
# + tinkering/bands/*. (gemband carries 0 DR — emits no modifier, so none to strip.)
attribute @s luck modifier remove evercraft:pebble_of_creation_luck
attribute @s luck modifier remove evercraft:pebble_aegis_luck
attribute @s luck modifier remove evercraft:pebble_astral_luck
attribute @s luck modifier remove evercraft:band_luck
attribute @s luck modifier remove evercraft:wardband_luck
attribute @s luck modifier remove evercraft:voidband_luck
attribute @s luck modifier remove evercraft:band_dring_luck
attribute @s luck modifier remove evercraft:band_undying_luck
# Tinkering Unit-0 (Knot + Hand of Creation, shipped pre-Wave-1 — gaps folded in here).
# tnk_knot luck (knot_apply), hand luck + reach (hand_of_creation/hand_apply).
attribute @s luck modifier remove evercraft:tnk_knot_luck
attribute @s luck modifier remove evercraft:hoc_hand_luck
attribute @s block_interaction_range modifier remove evercraft:hoc_hand_reach
# In-scope strip gap found during the Wave-1 wipe pass: the standalone Pebble of Dreams
# accessory (+1.0 luck, added in artifacts/accessories/player_tick:183-184) was never stripped.
# Its DR is what the Pebble of Creation fold consumes; strip the residual modifier on wipe.
attribute @s luck modifier remove evercraft:pebble_of_dreams_luck
# Artifact Fusion luck modifiers (cap-B, 2026-06-01) — Dreamer's Reliquary tree (Family B). The
# grand Reliquary (+24) + its four sub-bindings (Fortune Coffer +5 / Dream Lens +7 / Astral Core
# +25 / Craft-Luck Sigil +7 conditional) + the Lucky Charm starter (+2). Emitted by
# tinkering/reliquary/*_apply. (The member leaf *_luck — wishing_shard / dreamspun_crown /
# geologist_loupe / cache_eye / worldforge_ember / ruin_watch / etc. — are stripped by the nuclear
# reset + the loose-accessory cleanup; these are the NEW consolidated capstone ids.)
attribute @s luck modifier remove evercraft:dreamers_reliquary_luck
attribute @s luck modifier remove evercraft:fortune_coffer_luck
attribute @s luck modifier remove evercraft:dream_lens_luck
attribute @s luck modifier remove evercraft:astral_core_luck
attribute @s luck modifier remove evercraft:craft_luck_sigil_luck
attribute @s luck modifier remove evercraft:lucky_charm_luck
# Artifact Fusion — Wayfarer's Lens tree (Family C, cap-C). The whole family is BALANCE-NEUTRAL (ZERO
# DR), so it has NO `*_luck` modifier to strip. The only consolidated attribute the tree grants is the
# Voyager's Far-Lens waypoint receive range (shared id, also used by the loose Far-Lens + Surveyor's Kit
# + the grand Wayfarer's Lens). Strip it here so an admin reset clears it cleanly.
attribute @s waypoint_receive_range modifier remove evercraft:voyagers_far_lens_wp
# Artifact Fusion — Soulguard Aegis tree (Family D, cap-D). The whole family is BALANCE-NEUTRAL (ZERO
# DR), so it has NO `*_luck` modifier to strip, AND it grants NO persistent attribute (the apply fns
# emit only potion effects + the shared death-save cooldown). The shared ec.cd_save bucket is a
# scoreboard, already cleared by the nuclear scoreboard reset above — so there is nothing extra to
# strip here for Family D. (Documented for parity with the cap-B / cap-C fusion blocks.)
# Artifact Fusion — Grandforge Regalia tree (Family G, cap-G). The whole family is BALANCE-NEUTRAL (ZERO
# DR), so it has NO `*_luck` modifier to strip. It grants CONSOLIDATED forge attributes via distinct
# capstone-scoped ids (grandforge_bs/eff/band_*, smiths_apron_eff, quench_line_bs/eff) re-added each tick
# in tinkering/grandforge/*_apply. The clear @s at the top removes the items so accessory_cleanup would
# strip these next tick, but strip them explicitly for a clean admin reset (parity with the cap-C
# Far-Lens waypoint strip). The consolidated CR is scoreboard set-not-add in calculate.mcfunction (the
# nuclear reset above zeroes ec.cr_temp — nothing extra to strip there).
attribute @s block_break_speed modifier remove evercraft:grandforge_bs
attribute @s mining_efficiency modifier remove evercraft:grandforge_eff
attribute @s armor modifier remove evercraft:grandforge_band_armor
attribute @s block_break_speed modifier remove evercraft:grandforge_band_bs
attribute @s mining_efficiency modifier remove evercraft:smiths_apron_eff
attribute @s block_break_speed modifier remove evercraft:quench_line_bs
attribute @s mining_efficiency modifier remove evercraft:quench_line_eff
# Artifact Fusion — Alchemist's Magnum Opus tree (Family H, cap-H). The whole family is BALANCE-NEUTRAL
# (ZERO DR), so it has NO `*_luck` modifier to strip, AND it grants NO persistent attribute: its only
# per-tick grant is a Regeneration potion EFFECT (the Sustain Vial / grand apply), and its CR / alchemy-
# quality / reagent-yield / potion-duration levers are scoreboards (ec.cr_temp set-not-add in
# calculate.mcfunction, ec.ff_quality / ec.h_alembic / the #ff_* temp fakes in alchemy/minigame/resolve)
# — all cleared by the nuclear scoreboard reset above. So there is nothing extra to strip here for
# Family H. (Documented for parity with the cap-B / cap-C / cap-D fusion blocks.)
# Artifact Fusion — Cornucopia Tide tree (Family J, cap-J). Carries CONDITIONAL DR (the two fishing
# charms, consolidated +5.0 while fishing/harvesting) + consolidated aquatic attributes via distinct
# capstone-scoped ids re-added each tick in tinkering/cornucopia/*_apply + player_tick. The clear @s at
# the top removes the items so accessory_cleanup would strip these next tick, but strip them explicitly
# for a clean admin reset (parity with the cap-B / cap-G strips). The CR / cook-quality / crop-yield /
# crate levers are scoreboards (ec.cr_temp set-not-add in calculate.mcfunction, ec.ck_quality + the
# #ckj_*/#fj_*/#hb_* temp fakes) — all cleared by the nuclear scoreboard reset above.
attribute @s luck modifier remove evercraft:cornucopia_tide_luck
attribute @s luck modifier remove evercraft:tidewright_luck
attribute @s submerged_mining_speed modifier remove evercraft:cornucopia_tide_smine
attribute @s water_movement_efficiency modifier remove evercraft:cornucopia_tide_wme
attribute @s submerged_mining_speed modifier remove evercraft:tidewrights_net_smine
attribute @s water_movement_efficiency modifier remove evercraft:tidewrights_net_wme
attribute @s submerged_mining_speed modifier remove evercraft:harvest_knot_smine

# Artifact Fusion — Demiurge's Spirit Artifact tree (Family K, cap-K). Carries CONDITIONAL DR (the grand fires
# +3.0 while actively mining) + consolidated break-speed / mining-efficiency / reach / aquatic attributes
# via distinct capstone-scoped ids re-added each tick in tinkering/demiurge/*_apply + player_tick. The
# clear @s at the top removes the items so accessory_cleanup would strip these next tick, but strip them
# explicitly for a clean admin reset (parity with the cap-B / cap-G / cap-J strips). The CR (+8.0) is the
# ec.cr_temp set-not-add in calculate.mcfunction + the yield/crate/access levers are event hooks / temp
# fakes — all cleared by the nuclear scoreboard reset above.
attribute @s luck modifier remove evercraft:demiurges_capstone_luck
attribute @s block_break_speed modifier remove evercraft:demiurge_bs
attribute @s mining_efficiency modifier remove evercraft:demiurge_eff
attribute @s block_interaction_range modifier remove evercraft:demiurge_reach
attribute @s submerged_mining_speed modifier remove evercraft:demiurge_smine
attribute @s water_movement_efficiency modifier remove evercraft:demiurge_wme
attribute @s oxygen_bonus modifier remove evercraft:demiurge_o2
attribute @s submerged_mining_speed modifier remove evercraft:deepdig_smine
attribute @s water_movement_efficiency modifier remove evercraft:deepdig_wme
attribute @s oxygen_bonus modifier remove evercraft:deepdig_o2

# Artifact Fusion — Heart of the Mountain tree (Family L, cap-L). POWER-BUNDLE with ZERO base DR (the only
# luck is the consolidated CONDITIONAL +1.0 node-proximity DR, ascendant_locket_luck). The consolidated
# vanguard attrs (tank armor/health/toughness/KB + combat attack + traversal step/fall/speed) are added via
# distinct sub-cap-scoped ids re-added each tick in tinkering/heart/*_apply + the (a12) dispatch. The clear
# @s at the top removes the items so accessory_cleanup would strip these next tick, but strip them
# explicitly for a clean admin reset (parity with the cap-B / cap-G / cap-J / cap-K strips). The CR (+5.0)
# is the ec.cr_temp set-not-add in calculate.mcfunction; the Titan Core ward effects lapse on their own —
# all cleared by the nuclear scoreboard reset above. This strips BOTH the consolidated sub-cap-scoped ids
# AND the loose art-L leaf ids (which the live accessory_cleanup removes on item-drop, but the admin reset
# strips explicitly for a clean slate — the nuclear reset clears scoreboards, not attribute modifiers).
attribute @s luck modifier remove evercraft:ascendant_locket_luck
attribute @s armor modifier remove evercraft:titan_bulwark_armor
attribute @s armor_toughness modifier remove evercraft:titan_bulwark_tough
attribute @s max_health modifier remove evercraft:titan_bulwark_hp
attribute @s knockback_resistance modifier remove evercraft:titan_bulwark_kb
attribute @s explosion_knockback_resistance modifier remove evercraft:titan_bulwark_ekb
attribute @s attack_damage modifier remove evercraft:ascendant_atk
attribute @s attack_damage modifier remove evercraft:ascendant_atk_hp
attribute @s step_height modifier remove evercraft:stride_step
attribute @s fall_damage_multiplier modifier remove evercraft:stride_fall
attribute @s movement_speed modifier remove evercraft:stride_spd
# Loose art-L leaf ids (parity — clean admin reset).
attribute @s armor modifier remove evercraft:stoneward_pebble_armor
attribute @s max_health modifier remove evercraft:vital_acorn_health
attribute @s movement_speed modifier remove evercraft:sprinters_anklet_spd
attribute @s attack_damage modifier remove evercraft:reavers_knuckle_atk
attribute @s armor_toughness modifier remove evercraft:anvil_heart_tough
attribute @s knockback_resistance modifier remove evercraft:anvil_heart_kb
attribute @s attack_damage modifier remove evercraft:resonant_locket_atk
attribute @s luck modifier remove evercraft:resonant_locket_luck
attribute @s armor modifier remove evercraft:bulwark_plate_armor
attribute @s armor_toughness modifier remove evercraft:bulwark_plate_tough
attribute @s explosion_knockback_resistance modifier remove evercraft:bulwark_plate_ekb
attribute @s attack_damage modifier remove evercraft:ascendant_forgeheart_atk

# Artifact Fusion — Dragonheart tree (Family M, cap-M). MIXED-DR family: each node carries a consolidated
# *_luck (Mantle +4.5 / Grips +5.0 / Pinions +5.0 / Core +6.5 / the grand Dragonheart +21.0 / the final-form
# Wyrmscale Aegis +21.0) re-added each tick in tinkering/dragonheart/*_apply + the (a11) dispatch. The four
# sub-cap applies also add DISTINCT sub-cap-scoped attribute modifiers (toughness/KB/atk/fall). The clear @s
# at the top removes the items so the live (a11) cleanup strips these next tick, but strip them explicitly for
# a clean admin reset (parity with the cap-B / cap-G / cap-J / cap-K / cap-L strips). The Family-M LEAVES carry
# NO loose *_luck (DR is realized only on fusion), so there are no loose leaf luck ids to strip. The +40 (10%)
# Aegis dodge is the ec.acc_dodge re-summed lane (cleared by the nuclear scoreboard reset above).
attribute @s luck modifier remove evercraft:wyrmscale_aegis_luck
attribute @s luck modifier remove evercraft:dragonheart_luck
attribute @s luck modifier remove evercraft:wyrmheart_core_luck
attribute @s luck modifier remove evercraft:wyrmclaw_grips_luck
attribute @s luck modifier remove evercraft:wyrmwing_pinions_luck
attribute @s luck modifier remove evercraft:wyrmscale_mantle_luck
attribute @s armor_toughness modifier remove evercraft:wyrmscale_mantle_tough
attribute @s knockback_resistance modifier remove evercraft:wyrmscale_mantle_kb
attribute @s attack_damage modifier remove evercraft:wyrmclaw_grips_atk
attribute @s fall_damage_multiplier modifier remove evercraft:wyrmwing_pinions_fall

# === REMOVE ALL 940 PLAYER TAGS ===

# --- ABYSS tags (2) ---
tag @s remove ABYSS.Ore
tag @s remove ABYSS.announced

# --- Adv tags (2) ---
tag @s remove Adv.InMenu
tag @s remove Adv.RespecMode

# --- BM tags (1) ---
tag @s remove BM.InMenu

# --- CF tags (6) ---
tag @s remove CF.Forging
tag @s remove CF.GlowActive
tag @s remove CF.InCodex
tag @s remove CF.InMenu
tag @s remove CF.MenuElement
tag @s remove CF.SectionContent

# --- CK tags (6) ---
tag @s remove CK.Cooking
tag @s remove CK.FeastSelf
tag @s remove CK.FreeCook
tag @s remove CK.InMenu
tag @s remove CK.PreserveRestore
tag @s remove CK.Restore

# --- DG tags (1) ---
tag @s remove DG.InMenu

# --- FF tags (2) ---
tag @s remove FF.Fusing
tag @s remove FF.InMenu

# --- GuildNPC tags (4) ---
tag @s remove GuildNPC
tag @s remove GuildNPC.day_reset
tag @s remove GuildNPC.new
tag @s remove GuildNPC.wandered

# --- HS tags (10) ---
tag @s remove HS.BarrelFound
tag @s remove HS.InLaborers
tag @s remove HS.InMenu
tag @s remove HS.InSatchel
tag @s remove HS.InSettings
tag @s remove HS.LabelVisible
tag @s remove HS.Labeling
tag @s remove HS.SatchelRestore
tag @s remove HS.StashTarget
tag @s remove HS.ViewingLB

# --- IC tags (1) ---
tag @s remove IC.InMenu

# --- METEOR tags (1) ---
tag @s remove METEOR.Ore

# --- RF tags (1) ---
tag @s remove RF.InMenu

# --- TT tags (1) ---
tag @s remove TT.InMenu

# --- TX tags (2) ---
tag @s remove TX.DepositConfirmed
tag @s remove TX.InMenu

# --- WW tags (1) ---
tag @s remove WW.InMenu

# --- WaterNet tags (3) ---
tag @s remove WaterNet.active
tag @s remove WaterNet.invalid
tag @s remove WaterNet.placing

# --- ach tags (52) ---
tag @s remove ach_biome_badlands
tag @s remove ach_biome_basalt_deltas
tag @s remove ach_biome_crimson_forest
tag @s remove ach_biome_dark_forest
tag @s remove ach_biome_deep_dark
tag @s remove ach_biome_desert
tag @s remove ach_biome_dripstone_caves
tag @s remove ach_biome_flower_forest
tag @s remove ach_biome_forest
tag @s remove ach_biome_ice
tag @s remove ach_biome_jungle
tag @s remove ach_biome_lush_caves
tag @s remove ach_biome_mountain
tag @s remove ach_biome_mushroom
tag @s remove ach_biome_nether_wastes
tag @s remove ach_biome_ocean
tag @s remove ach_biome_plains
tag @s remove ach_biome_river
tag @s remove ach_biome_savanna
tag @s remove ach_biome_soul_sand_valley
tag @s remove ach_biome_swamp
tag @s remove ach_biome_taiga
tag @s remove ach_biome_the_end
tag @s remove ach_biome_warped_forest
tag @s remove ach_biome_wind
tag @s remove ach_set_blood
tag @s remove ach_set_celestial
tag @s remove ach_set_cloaked_skull
tag @s remove ach_set_crystal
tag @s remove ach_set_dragonmaster
tag @s remove ach_set_dragonslayer
tag @s remove ach_set_ember
tag @s remove ach_set_ender
tag @s remove ach_set_ender_dragon
tag @s remove ach_set_fireforged
tag @s remove ach_set_frost
tag @s remove ach_set_golem
tag @s remove ach_set_infernal
tag @s remove ach_set_journey
tag @s remove ach_set_nature
tag @s remove ach_set_netherwalker
tag @s remove ach_set_ninja
tag @s remove ach_set_ocean
tag @s remove ach_set_phantom
tag @s remove ach_set_sculk
tag @s remove ach_set_shadow
tag @s remove ach_set_space
tag @s remove ach_set_splendid
tag @s remove ach_set_storm
tag @s remove ach_set_titan
tag @s remove ach_set_verdant
tag @s remove ach_set_wither

# --- adv tags (1) ---
tag @s remove adv.wolf_set

# --- amethyst tags (5) ---
tag @s remove amethyst_chest
tag @s remove amethyst_feet
tag @s remove amethyst_head
tag @s remove amethyst_legs
tag @s remove amethyst_notified

# --- artifact tags (1) ---
tag @s remove artifact_got_looting

# --- at tags (1) ---
tag @s remove at_village

# --- bestiary tags (6) ---
tag @s remove bestiary.baby_mount.set
tag @s remove bestiary.settings.applied
tag @s remove bestiary.settings.breed.disabled
tag @s remove bestiary.settings.drown.disabled
tag @s remove bestiary.settings.villagename.applied
tag @s remove bestiary.villager.leader

# --- bl tags (8) ---
tag @s remove bl.marked
tag @s remove bl.owned
tag @s remove bl.owner
tag @s remove bl.pierced
tag @s remove bl.restore
tag @s remove bl.sweep_primary
tag @s remove bl.warp_target
tag @s remove bl.warp_wolf

# --- blood tags (2) ---
tag @s remove blood_2pc
tag @s remove blood_4pc

# --- bolt tags (1) ---
tag @s remove bolt_cooldown

# --- ce tags (41) ---
tag @s remove ce.emberheart_revive
tag @s remove ce.evo_arctic_fox
tag @s remove ce.evo_ashborn
tag @s remove ce.evo_butterfly
tag @s remove ce.evo_claude
tag @s remove ce.evo_copper_golem
tag @s remove ce.evo_cow_of_eden
tag @s remove ce.evo_crystalheart
tag @s remove ce.evo_deloris
tag @s remove ce.evo_dreamstag
tag @s remove ce.evo_emberheart
tag @s remove ce.evo_endwalker
tag @s remove ce.evo_golden_dragon
tag @s remove ce.evo_grovekeeper
tag @s remove ce.evo_infernus
tag @s remove ce.evo_iron_golem
tag @s remove ce.evo_leviathan
tag @s remove ce.evo_lunar_moth
tag @s remove ce.evo_monolith
tag @s remove ce.evo_moobloom
tag @s remove ce.evo_nebula_kit
tag @s remove ce.evo_panther
tag @s remove ce.evo_red_panda
tag @s remove ce.evo_regal_tiger
tag @s remove ce.evo_sabertooth
tag @s remove ce.evo_skeleton_horse
tag @s remove ce.evo_snow_fox_spirit
tag @s remove ce.evo_somnia
tag @s remove ce.evo_spirit_wolf
tag @s remove ce.evo_starweaver
tag @s remove ce.evo_stormcaller
tag @s remove ce.evo_time_weaver
tag @s remove ce.evo_twilight_hare
tag @s remove ce.evo_vex
tag @s remove ce.evo_void_walker
tag @s remove ce.evo_voidshade
tag @s remove ce.evo_wither
tag @s remove ce.evo_wraith
tag @s remove ce.evolved_active
tag @s remove ce.evolving
tag @s remove ce.evolving_pet

# --- celestial tags (2) ---
tag @s remove celestial_2pc
tag @s remove celestial_4pc

# --- cf tags (3) ---
tag @s remove cf.checking_player
tag @s remove cf.refresh_consumed
tag @s remove cf.refresh_marker

# --- challenge tags (3) ---
tag @s remove challenge.mode_comp
tag @s remove challenge.mode_duel
tag @s remove challenge.mode_pet

# --- cloaked tags (2) ---
tag @s remove cloaked_skull_2pc
tag @s remove cloaked_skull_4pc

# --- companion tags (116) ---
tag @s remove companion.abyssal
tag @s remove companion.activemenu
tag @s remove companion.activepet
tag @s remove companion.alien
tag @s remove companion.allay
tag @s remove companion.arctic_fox
tag @s remove companion.armadillo
tag @s remove companion.ashborn
tag @s remove companion.baby_potato
tag @s remove companion.bond_thickhide
tag @s remove companion.bee
tag @s remove companion.blaze
tag @s remove companion.bramble
tag @s remove companion.breeze
tag @s remove companion.bulwark
tag @s remove companion.butterfly
tag @s remove companion.camel
tag @s remove companion.chick
tag @s remove companion.cindershell
tag @s remove companion.claude
tag @s remove companion.copper_golem
tag @s remove companion.cow
tag @s remove companion.cow_of_eden
tag @s remove companion.cragmite
tag @s remove companion.creaking
tag @s remove companion.creeper
tag @s remove companion.crystalheart
tag @s remove companion.deloris
tag @s remove companion.dreamstag
tag @s remove companion.duck
tag @s remove companion.emberheart
tag @s remove companion.ender_dragon
tag @s remove companion.enderman
tag @s remove companion.endwalker
tag @s remove companion.evoker
tag @s remove companion.fox
tag @s remove companion.frog
tag @s remove companion.frostweaver
tag @s remove companion.frozen_zombie
tag @s remove companion.giraffe
tag @s remove companion.glider
tag @s remove companion.goat
tag @s remove companion.golden_dragon
tag @s remove companion.grasshopper
tag @s remove companion.grovekeeper
tag @s remove companion.has_marker
tag @s remove companion.has_whistle
tag @s remove horn.stance_cd
tag @s remove companion.hidden
tag @s remove companion.hoglin
tag @s remove companion.infernus
tag @s remove companion.infoscreen
tag @s remove companion.inmenuv2
tag @s remove companion.iron_golem
tag @s remove companion.juggernaut
tag @s remove companion.knight
tag @s remove companion.koala
tag @s remove companion.leviathan
tag @s remove companion.llama
tag @s remove companion.lunar_moth
tag @s remove companion.marker
tag @s remove companion.moldwarp
tag @s remove companion.monkey
tag @s remove companion.monolith
tag @s remove companion.moobloom
tag @s remove companion.mooshroom
tag @s remove companion.mossy_skeleton
tag @s remove companion.mossy_zombie
tag @s remove companion.mule
tag @s remove companion.mushroom
tag @s remove companion.naiad
tag @s remove companion.nebula_kit
tag @s remove companion.newplayer
tag @s remove companion.ocelot
tag @s remove companion.oracle
tag @s remove companion.owner
tag @s remove companion.panther
tag @s remove companion.pig
tag @s remove companion.piglin
tag @s remove companion.pixie
tag @s remove companion.polar_bear
tag @s remove companion.prowler
tag @s remove companion.rascal
tag @s remove companion.ravager
tag @s remove companion.red_panda
tag @s remove companion.regal_tiger
tag @s remove companion.restore_mainhand
tag @s remove companion.restore_menu
tag @s remove companion.sabertooth
tag @s remove companion.sentinel
tag @s remove companion.shade
tag @s remove companion.silverfish
tag @s remove companion.skeleton_horse
tag @s remove companion.sniffer
tag @s remove companion.snow_fox_spirit
tag @s remove companion.snowman
tag @s remove companion.somnia
tag @s remove companion.spirit_wolf
tag @s remove companion.sporeblossom
tag @s remove companion.squid
tag @s remove companion.starweaver
tag @s remove companion.stormcaller
tag @s remove companion.strider
tag @s remove companion.tidecaller
tag @s remove companion.time_weaver
tag @s remove companion.titan
tag @s remove companion.twilight_hare
tag @s remove companion.vex
tag @s remove companion.void_walker
tag @s remove companion.voidshade
tag @s remove companion.wither
tag @s remove companion.wolf
tag @s remove companion.wooly_cow
tag @s remove companion.wraith
tag @s remove companion.zephyr
tag @s remove companion.zoglin

# --- copper tags (5) ---
tag @s remove copper_chest
tag @s remove copper_feet
tag @s remove copper_head
tag @s remove copper_legs
tag @s remove copper_notified

# --- crystal tags (2) ---
tag @s remove crystal_2pc
tag @s remove crystal_4pc

# --- cs tags (1) ---
tag @s remove cs.heist_clearing

# --- dg tags (4) ---
tag @s remove dg.checking_unknown
tag @s remove dg.player
tag @s remove dg.trim_bonus
tag @s remove dg.unknown_detected

# --- diamond tags (5) ---
tag @s remove diamond_chest
tag @s remove diamond_feet
tag @s remove diamond_head
tag @s remove diamond_legs
tag @s remove diamond_notified

# --- dm tags (6) ---
tag @s remove dm_berserk_2pc
tag @s remove dm_berserk_4pc
tag @s remove dm_berserker_6pc
tag @s remove dm_dancer_4pc
tag @s remove dm_dancer_5pc
tag @s remove dm_dancer_6pc

# --- dr tags (11) ---
tag @s remove dr.all_lore
tag @s remove dr.dream_collector
tag @s remove dr.dreamwalker
tag @s remove dr.dreamwalker_announced
tag @s remove dr.in_realm
tag @s remove dr.lucid_dreamer
tag @s remove dr.lucid_dreamer_announced
tag @s remove dr.master_dreamer
tag @s remove dr.maze_input
tag @s remove dr.maze_on_color
tag @s remove dr.trial_active

# --- dragonmaster tags (4) ---
tag @s remove dragonmaster_2pc
tag @s remove dragonmaster_4pc
tag @s remove dragonmaster_5pc
tag @s remove dragonmaster_6pc

# --- dragonslayer tags (2) ---
tag @s remove dragonslayer_2pc
tag @s remove dragonslayer_4pc

# --- duel tags (13) ---
tag @s remove duel.challenger
tag @s remove duel.challenger_confirmed
tag @s remove duel.eliminated
tag @s remove duel.ftx_respawning
tag @s remove duel.ftx_victim
tag @s remove duel.loser
tag @s remove duel.partner_b
tag @s remove duel.pending_target
tag @s remove duel.ray_target
tag @s remove duel.raycaster
tag @s remove duel.self_marker
tag @s remove duel.team_opponent_confirmed
tag @s remove duel.winner

# --- ec tags (331) ---
tag @s remove ec.Confirming
tag @s remove ec.InExchange
tag @s remove ec.InFountain
tag @s remove ec.InGachaInfo
tag @s remove ec._a
tag @s remove ec._bone
tag @s remove ec._clr
tag @s remove ec._ember
tag @s remove ec._lip
tag @s remove ec._nc
tag @s remove ec._petal
tag @s remove ec.absorb_steal
tag @s remove ec.admin
tag @s remove ec.ae_checked
tag @s remove ec.aff_attacker
tag @s remove ec.anglers_pearl_fishing
tag @s remove ec.ar_marked
tag @s remove ec.ar_tethered
tag @s remove ec.arrow_checked
tag @s remove ec.backstabbed
tag @s remove ec.bd_best
tag @s remove ec.bd_buddy
tag @s remove ec.bd_charge_hit
tag @s remove ec.bd_cozy_applied
tag @s remove ec.bd_designating_target
tag @s remove ec.bd_last_active
tag @s remove ec.bd_neardeath_cd
tag @s remove ec.bd_speed_applied
tag @s remove ec.bd_wc_applied
tag @s remove ec.big
tag @s remove ec.bk_active
tag @s remove ec.bk_swinger
tag @s remove ec.bl_active
tag @s remove ec.bleeding
tag @s remove ec.blossom_rod_luck
tag @s remove ec.bm_forage_bonus
tag @s remove ec.bnt_killer
tag @s remove ec.caff_xfeed
tag @s remove ec.cf_bridge_active
tag @s remove ec.cf_codex_granted
tag @s remove ec.cf_gathering
tag @s remove ec.cf_glow_toggling
tag @s remove ec.cf_r10_granted
tag @s remove ec.cf_r30_announced
tag @s remove ec.cf_r5_granted
tag @s remove ec.cleave_primary
tag @s remove ec.conv_pickup
tag @s remove ec.crate_checked
tag @s remove ec.crate_done
tag @s remove ec.crop_rolled
tag @s remove ec.cs_restore
tag @s remove ec.deto_mine
tag @s remove ec.df_restore
tag @s remove ec.di_active
tag @s remove ec.di_burst
tag @s remove ec.dlpack_in_menu
tag @s remove ec.dn_active
tag @s remove ec.dn_swinger
tag @s remove ec.dr_1
tag @s remove ec.dr_2
tag @s remove ec.dr_3
tag @s remove ec.dragon_fire
tag @s remove ec.dreamdust_used
tag @s remove ec.ds_active
tag @s remove ec.duel_active_tag
tag @s remove ec.duel_spectator
tag @s remove ec.ember_rod_luck
tag @s remove ec.entity
tag @s remove ec.exquisite
tag @s remove ec.fortitude
tag @s remove ec.fountain_searching
tag @s remove ec.fox_click_cd
tag @s remove ec.fox_owner
tag @s remove ec.fox_tamed
tag @s remove ec.fr_detail_view
tag @s remove ec.fr_inviter
tag @s remove ec.fr_marry_pending
tag @s remove ec.fr_pending
tag @s remove ec.fr_ray_target
tag @s remove ec.furia
tag @s remove ec.furia.greater
tag @s remove ec.furia.minor
tag @s remove ec.furia.processed
tag @s remove ec.furia.standard
tag @s remove ec.gacha_free_pull
tag @s remove ec.df_bonus_src
tag @s remove ec.gd_pvp
tag @s remove ec.gd_vote_approved
tag @s remove ec.ge_collector
tag @s remove ec.gear_target
tag @s remove ec.gexp_mvp
tag @s remove ec.gexp_voted
tag @s remove ec.gf_crystal_restore
tag @s remove ec.gf_restore
tag @s remove ec.ghast_check
tag @s remove ec.ghast_click_cd
tag @s remove ec.ghast_owner
tag @s remove ec.ghast_tamed
tag @s remove ec.ghast_was_sitting
tag @s remove ec.ghast_was_standing
tag @s remove ec.gm_detail_view
tag @s remove ec.growth_checked
tag @s remove ec.gs_golem
tag @s remove ec.gs_in_menu
tag @s remove ec.gs_new
tag @s remove ec.gs_registered
tag @s remove ec.gs_remote_menu
tag @s remove ec.guild_arrow_warned
tag @s remove ec.guild_in_menu
tag @s remove ec.guild_inv_target
tag @s remove ec.guild_inviter
tag @s remove ec.guild_node
tag @s remove ec.guild_node_new
tag @s remove ec.guild_remote_menu
tag @s remove ec.guild_strike_notified
tag @s remove ec.guild_supply_select
tag @s remove ec.guild_viewer
tag @s remove ec.guild_xp_bonus
tag @s remove ec.had_old_codex
tag @s remove ec.has_accessory
tag @s remove ec.has_aegis
tag @s remove ec.has_any_codex
tag @s remove ec.has_any_trim
tag @s remove ec.has_time_dr
tag @s remove ec.head_checked
tag @s remove ec.healer_self
tag @s remove ec.heist_active_tag
tag @s remove ec.hero_night_dr
tag @s remove ec.hero_src
tag @s remove ec.hl_restore
tag @s remove ec.holding_fortune_tool
tag @s remove ec.hsatch_in_menu
tag @s remove ec.ht_active
tag @s remove ec.hxp_checked
tag @s remove ec.iai_charging
tag @s remove ec.iai_fired
tag @s remove ec.iai_ready
tag @s remove ec.infernal_dmg
tag @s remove ec.inscr_no_res
tag @s remove ec.inscr_pool_guild
tag @s remove ec.inscr_pool_home
tag @s remove ec.inscr_pool_personal
tag @s remove ec.inscr_res
tag @s remove ec.inscr_restore
tag @s remove ec.inscr_was_res
tag @s remove ec.joined
tag @s remove ec.journey_pick_luck
tag @s remove ec.journey_shov_luck
tag @s remove ec.jv_active
tag @s remove ec.kb
tag @s remove ec.kt_active
tag @s remove ec.lb_owner
tag @s remove ec.lb_restore
tag @s remove ec.light
tag @s remove ec.lightning_arrow
tag @s remove ec.lip_ripper_luck
tag @s remove ec.lodestone_registered
tag @s remove ec.lucid_claim_active
tag @s remove ec.miners_lantern_fortune
tag @s remove ec.mt_finished
tag @s remove ec.mt_racer
tag @s remove ec.mt_recalling
tag @s remove ec.mule_in_menu
tag @s remove ec.myth_chest_luck
tag @s remove ec.myth_feet_luck
tag @s remove ec.myth_head_luck
tag @s remove ec.myth_legs_luck
tag @s remove ec.nt_owner
tag @s remove ec.nt_warned
tag @s remove ec.o_blossom_rod_luck
tag @s remove ec.ocelot_click_cd
tag @s remove ec.ocelot_owner
tag @s remove ec.ocelot_tamed
tag @s remove ec.ornate
tag @s remove ec.pantry_in_menu
tag @s remove ec.pantry_mainhand
tag @s remove ec.pantry_restore
tag @s remove ec.party_marked
tag @s remove ec.patron
tag @s remove ec.patron.common
tag @s remove ec.patron.exquisite
tag @s remove ec.patron.mythical
tag @s remove ec.patron.ornate
tag @s remove ec.patron.processed
tag @s remove ec.patron.rare
tag @s remove ec.patron.uncommon
tag @s remove ec.pet_found
tag @s remove ec.player
tag @s remove ec.playerhead
tag @s remove ec.pty_inv_found
tag @s remove ec.pty_named
tag @s remove ec.quest_tracking
tag @s remove ec.r_bone_rod_luck
tag @s remove ec.rare
tag @s remove ec.rd_al_a_h1
tag @s remove ec.rd_al_a_h2
tag @s remove ec.rd_al_a_h3
tag @s remove ec.rd_al_a_h4
tag @s remove ec.rd_al_a_h5
tag @s remove ec.rd_al_anchor_hit
tag @s remove ec.rd_al_lantern_just_lit
tag @s remove ec.rd_al_lantern_off
tag @s remove ec.rd_al_lantern_on
tag @s remove ec.rd_gi_dead
tag @s remove ec.rd_gi_h1
tag @s remove ec.rd_gi_h2
tag @s remove ec.rd_gi_h3
tag @s remove ec.rd_gi_h4
tag @s remove ec.rd_gi_h5
tag @s remove ec.rd_hs_fake_dead
tag @s remove ec.rd_hs_fake_h1
tag @s remove ec.rd_hs_fake_h2
tag @s remove ec.rd_hs_fake_h3
tag @s remove ec.rd_hs_fake_h4
tag @s remove ec.rd_hs_fake_h5
tag @s remove ec.rd_initializing
tag @s remove ec.rd_lv_sponge_used
tag @s remove ec.rd_lv_sponge_valid_placed
tag @s remove ec.rd_lv_target
tag @s remove ec.rd_mw_ch1
tag @s remove ec.rd_mw_ch2
tag @s remove ec.rd_mw_ch3
tag @s remove ec.rd_mw_ch4
tag @s remove ec.rd_mw_core_active
tag @s remove ec.rd_participant
tag @s remove ec.rd_vw_c1
tag @s remove ec.rd_vw_c2
tag @s remove ec.rd_vw_empty
tag @s remove ec.reach
tag @s remove ec.regen_capped
tag @s remove ec.renegade_luck
tag @s remove ec.rf_active
tag @s remove ec.rg_active
tag @s remove ec.rg_proc
tag @s remove ec.rg_shielded
tag @s remove ec.rg_swinger
tag @s remove ec.rune_activated
tag @s remove ec.rw_active
tag @s remove ec.satchel_in_menu
tag @s remove ec.satchel_owner
tag @s remove ec.sc_in_picker
tag @s remove ec.sc_in_showcase
tag @s remove ec.sc_temp_anchor
tag @s remove ec.sc_view_other
tag @s remove ec.searching
tag @s remove ec.sk_active
tag @s remove ec.sk_sentinel
tag @s remove ec.small
tag @s remove ec.soul_rend
tag @s remove ec.sp_active
tag @s remove ec.sp_aegis_active
tag @s remove ec.sp_beast_active
tag @s remove ec.sp_blade_storm
tag @s remove ec.sp_charging
tag @s remove ec.sp_checking_snipe
tag @s remove ec.sp_chrono_active
tag @s remove ec.sp_chrono_boost
tag @s remove ec.sp_crystal_pending
tag @s remove ec.sp_cyclone_active
tag @s remove ec.sp_death_mainhand
tag @s remove ec.sp_death_offhand
tag @s remove ec.sp_dh_charging
tag @s remove ec.sp_flurry_proc
tag @s remove ec.sp_fortress_active
tag @s remove ec.sp_frozen
tag @s remove ec.sp_fused
tag @s remove ec.sp_golden_glow
tag @s remove ec.sp_guarded
tag @s remove ec.sp_guardian
tag @s remove ec.sp_guarding
tag @s remove ec.sp_judging
tag @s remove ec.sp_maelstrom_active
tag @s remove ec.sp_phase_active
tag @s remove ec.sp_poseidon_charging
tag @s remove ec.sp_rampage_active
tag @s remove ec.sp_restore
tag @s remove ec.sp_restore_offhand
tag @s remove ec.sp_rift_active
tag @s remove ec.sp_sanctuary_active
tag @s remove ec.sp_shadow_bonus
tag @s remove ec.sp_surge_charging
tag @s remove ec.sp_taunted
tag @s remove ec.sp_thousand_cuts
tag @s remove ec.sp_tyrant_rage
tag @s remove ec.sp_wall_active
tag @s remove ec.sp_water_boost
tag @s remove ec.sp_zephyr_dance
tag @s remove ec.spec_wp
tag @s remove ec.spelunker_luck
tag @s remove ec.spirit_chosen
tag @s remove ec.sq_update_tome
tag @s remove ec.sq_lost_tome
# Spirit Tome progression resets (W14 W6.2 — Pioneer-wipe compat per AU14 Reachability F8)
scoreboard players reset @s ec.sq_has_tome
scoreboard players reset @s ec.sq_part
scoreboard players reset @s ec.sq_active
scoreboard players reset @s ec.sq_progress
scoreboard players reset @s ec.sp_quest
scoreboard players reset @s ec.sp_mastery
tag @s remove ec.st_crystal_pending
tag @s remove ec.st_held
tag @s remove ec.st_mining
tag @s remove ec.st_zone_safe
tag @s remove ec.step_height
tag @s remove ec.t_holding
tag @s remove ec.tame_protected
tag @s remove ec.taunted
tag @s remove ec.tb_dying
tag @s remove ec.tb_has_totem
tag @s remove ec.tb_registered
tag @s remove ec.tb_restore
tag @s remove ec.tb_reviving
tag @s remove ec.tb_viewing
tag @s remove ec.te_nth_any
tag @s remove ec.temp_fortress
tag @s remove ec.titans_plate
tag @s remove ec.title_top_contributor
tag @s remove ec.title_seasonal_master
scoreboard players set @s adv.tok_t1 0
scoreboard players set @s adv.tok_t2 0
scoreboard players set @s adv.tok_t3 0
scoreboard players set @s adv.tok_t4 0
scoreboard players set @s adv.tok_t5 0
scoreboard players set @s ec.story.branch7_claimed 0
# Treasure rune timer scoreboards (Audit #3 W7 left these unswept on Pioneer wipe; closing gap).
scoreboard players set @s ec.tide_rune 0
scoreboard players set @s ec.zephyr_rune 0
scoreboard players set @s ec.ember_rune 0
scoreboard players set @s ec.briar_rune 0
scoreboard players set @s ec.obsidian_rune 0
scoreboard players set @s ec.quick_rune_t 0
attribute @s minecraft:attack_damage modifier remove ec.quick_rune
attribute @s minecraft:movement_speed modifier remove ec.quick_rune
tag @s remove ec.tk_puller
tag @s remove ec.tomb_accept_target
tag @s remove ec.tomb_carrier
tag @s remove ec.tomb_collecting
tag @s remove ec.tomb_delivering
tag @s remove ec.tomb_deny_target
tag @s remove ec.tomb_is_owner
tag @s remove ec.tomb_pending
tag @s remove ec.tomb_reviver
tag @s remove ec.tomb_reviving
tag @s remove ec.tomb_shattering
tag @s remove ec.tomb_uuid_set
tag @s remove ec.tome_cooldown
tag @s remove ec.tome_update
tag @s remove ec.tq_update_tome
tag @s remove ec.trades_set
tag @s remove ec.tt_complete
tag @s remove ec.tt_player
tag @s remove ec.uc_bone_rod_luck
tag @s remove ec.warriors_crown
tag @s remove ec.wishing_star_active
tag @s remove ec.wooden_rod_luck
tag @s remove ec.wt_has_companion
tag @s remove ec.xp
tag @s remove ec.zone_owner
tag @s remove ec_axe_broken
tag @s remove ec_pick_broken
tag @s remove ec_shov_broken

# --- ed tags (5) ---
tag @s remove ed_knight_2pc
tag @s remove ed_knight_5pc
tag @s remove ed_knight_6pc
tag @s remove ed_tank_2pc
tag @s remove ed_tank_4pc

# --- ember tags (2) ---
tag @s remove ember_2pc
tag @s remove ember_4pc

# --- emerald tags (5) ---
tag @s remove emerald_chest
tag @s remove emerald_feet
tag @s remove emerald_head
tag @s remove emerald_legs
tag @s remove emerald_notified

# --- ender tags (6) ---
tag @s remove ender_2pc
tag @s remove ender_4pc
tag @s remove ender_dragon_2pc
tag @s remove ender_dragon_4pc
tag @s remove ender_dragon_5pc
tag @s remove ender_dragon_6pc

# --- fireforged tags (2) ---
tag @s remove fireforged_2pc
tag @s remove fireforged_4pc

# --- frost tags (2) ---
tag @s remove frost_2pc
tag @s remove frost_4pc

# --- full tags (16) ---
tag @s remove full_set_ascendant
tag @s remove full_set_bolt
tag @s remove full_set_coast
tag @s remove full_set_coast_got_looting
tag @s remove full_set_dune
tag @s remove full_set_eye
tag @s remove full_set_flow
tag @s remove full_set_rib
tag @s remove full_set_sentry
tag @s remove full_set_silence
tag @s remove full_set_snout
tag @s remove full_set_spire
tag @s remove full_set_tide
tag @s remove full_set_vex
tag @s remove full_set_ward
tag @s remove full_set_wild
tag @s remove full_set_host
tag @s remove full_set_raiser
tag @s remove full_set_shaper
tag @s remove full_set_wayfinder

# --- gc tags (2) ---
tag @s remove gc.placing
tag @s remove gc_deflected

# --- ge tags (1) ---
tag @s remove ge.top_contributor

# --- gold tags (5) ---
tag @s remove gold_chest
tag @s remove gold_feet
tag @s remove gold_head
tag @s remove gold_legs
tag @s remove gold_notified

# --- golem tags (2) ---
tag @s remove golem_2pc
tag @s remove golem_4pc

# --- gs tags (3) ---
tag @s remove gs.ig_no_explode
tag @s remove gs.iron_guard
tag @s remove gs.warp_target

# --- h2h tags (6) ---
tag @s remove h2h.challenger
tag @s remove h2h.loser
tag @s remove h2h.participant
tag @s remove h2h.pending_target
tag @s remove h2h.self
tag @s remove h2h.winner

# --- hb tags (5) ---
tag @s remove hb.accent_furia
tag @s remove hb.accent_patron
tag @s remove hb.accent_pet
tag @s remove hb.found
tag @s remove hb.was_enabled

# --- hc tags (2) ---
tag @s remove hc.placing
tag @s remove hc.target

# --- heist tags (1) ---
tag @s remove heist.cd_checking

# --- hero tags (8) ---
tag @s remove hero_2pc
tag @s remove hero_4pc
tag @s remove hero_5pc
tag @s remove hero_6pc
tag @s remove hero_dancer_2pc
tag @s remove hero_dancer_4pc
tag @s remove hero_dancer_5pc
tag @s remove hero_dancer_6pc

# --- hs tags (13) ---
tag @s remove hs.golem
tag @s remove hs.has_satchel
tag @s remove hs.ig_no_explode
tag @s remove hs.iron_guard
# hs.keep_$(category) is a macro tag — skip (dynamic per-category)
# hs.crate_open: Quick-Stash crate-handling setting (set = open + sort)
tag @s remove hs.crate_open
tag @s remove hs.owner_check
tag @s remove hs.remote_stash
tag @s remove hs.stashing
tag @s remove hs.vis_self
tag @s remove hs.visiting
tag @s remove hs.warp_owner
tag @s remove hs.warp_target

# --- ic tags (8) ---
tag @s remove ic.bearer_setup
tag @s remove ic.boss_setup
tag @s remove ic.fallen
tag @s remove ic.furia
tag @s remove ic.invited
tag @s remove ic.patron
tag @s remove ic.player
tag @s remove ic.starter

# AU-B-FOLLOWUP.10 (2026-05-29): per-party scoping tags p1..p14 (dungeon + castle share these).
# Solo p<10001+> tags are dynamic (adv.gui_session-derived) — dangling solo tags are harmless
# (next castle/dungeon start re-tags with a fresh session pid).
tag @s remove p1
tag @s remove p2
tag @s remove p3
tag @s remove p4
tag @s remove p5
tag @s remove p6
tag @s remove p7
tag @s remove p8
tag @s remove p9
tag @s remove p10
tag @s remove p11
tag @s remove p12
tag @s remove p13
tag @s remove p14

# --- inf tags (6) ---
tag @s remove inf_sentinel_2pc
tag @s remove inf_sentinel_4pc
tag @s remove inf_sentinel_6pc
tag @s remove inf_striker_2pc
tag @s remove inf_striker_4pc
tag @s remove inf_striker_5pc

# --- infernal tags (4) ---
tag @s remove infernal_2pc
tag @s remove infernal_4pc
tag @s remove infernal_5pc
tag @s remove infernal_6pc

# --- iron tags (5) ---
tag @s remove iron_chest
tag @s remove iron_feet
tag @s remove iron_head
tag @s remove iron_legs
tag @s remove iron_notified

# --- jn tags (10) ---
# jn.b$(bid) is a macro tag — skip (dynamic per-biome)
tag @s remove jn.dim_end
tag @s remove jn.dim_neth
tag @s remove jn.dim_ow
tag @s remove jn.s1
tag @s remove jn.s2
tag @s remove jn.s3
tag @s remove jn.s4
tag @s remove jn.s5
# jn.v_$(vid) is a macro tag — skip (dynamic per-village)

# --- join tags (1) ---
tag @s remove join_my_team

# --- journey tags (3) ---
tag @s remove journey_2pc
tag @s remove journey_4pc
tag @s remove journey_5pc

# --- jrn tags (2) ---
tag @s remove jrn_beast_2pc
tag @s remove jrn_heal_2pc

# --- lapis tags (5) ---
tag @s remove lapis_chest
tag @s remove lapis_feet
tag @s remove lapis_head
tag @s remove lapis_legs
tag @s remove lapis_notified

# --- mobs tags (1) ---
tag @s remove mobs.patrons.applied

# --- more tags (13) ---
tag @s remove more_professions_artificer
tag @s remove more_professions_bartender
tag @s remove more_professions_beekeeper
tag @s remove more_professions_circut_board
tag @s remove more_professions_explorer
tag @s remove more_professions_hunter
tag @s remove more_professions_miner
tag @s remove more_professions_nymph
tag @s remove more_professions_retired_adventurer
tag @s remove more_professions_taskmaster
tag @s remove more_professions_verified
tag @s remove more_professions_wise_wanderer
tag @s remove more_professions_zookeeper

# --- mythical tags (3) ---
tag @s remove mythical_spider_t1
tag @s remove mythical_spider_t2
tag @s remove mythical_spider_t3

# --- nature tags (2) ---
tag @s remove nature_2pc
tag @s remove nature_4pc

# --- nc tags (1) ---
tag @s remove nc_absorbing

# --- netherite tags (8) ---
tag @s remove netherite_chest
tag @s remove netherite_falling_fast
tag @s remove netherite_feet
tag @s remove netherite_floating
tag @s remove netherite_head
tag @s remove netherite_legs
tag @s remove netherite_notified
tag @s remove netherite_on_ground

# --- netherwalker tags (2) ---
tag @s remove netherwalker_2pc
tag @s remove netherwalker_4pc

# --- ninja tags (2) ---
tag @s remove ninja_2pc
tag @s remove ninja_4pc

# --- not tags (1) ---
tag @s remove not_at_village

# --- ocean tags (2) ---
tag @s remove ocean_2pc
tag @s remove ocean_4pc

# --- party tags (1) ---
tag @s remove party.boss_death

# --- pc tags (2) ---
tag @s remove pc.target
# pc.pet_fear is a MOB tag (horn fear), set/cleared on hostiles via combat/tick's TTL sweep — never lives
# on a player. Cleared here defensively for parity with pc.target (same convention).
tag @s remove pc.pet_fear

# --- pd tags (7) ---
tag @s remove pd.attacker
tag @s remove pd.challenger
tag @s remove pd.duelist
tag @s remove pd.loser
tag @s remove pd.pending_target
tag @s remove pd.target
tag @s remove pd.winner

# --- phantom tags (2) ---
tag @s remove phantom_2pc
tag @s remove phantom_4pc

# --- quartz tags (6) ---
tag @s remove quartz_chest
tag @s remove quartz_feet
tag @s remove quartz_head
tag @s remove quartz_legs
tag @s remove quartz_notified
tag @s remove quartz_xp_orb

# --- rd tags (1) ---
tag @s remove rd.voted

# --- redstone tags (5) ---
tag @s remove redstone_chest
tag @s remove redstone_feet
tag @s remove redstone_head
tag @s remove redstone_legs
tag @s remove redstone_notified

# --- resin tags (5) ---
tag @s remove resin_chest
tag @s remove resin_feet
tag @s remove resin_head
tag @s remove resin_legs
tag @s remove resin_notified

# --- rp tags (2) ---
tag @s remove rp.has_omen
tag @s remove rp.raiding

# --- sculk tags (2) ---
tag @s remove sculk_2pc
tag @s remove sculk_4pc

# --- sentry tags (2) ---
tag @s remove sentry_no_explode
tag @s remove sentry_target

# --- shadow tags (2) ---
tag @s remove shadow_2pc
tag @s remove shadow_4pc

# --- silence tags (1) ---
tag @s remove silence_banished

# --- single tags (18) ---
tag @s remove single_bolt
tag @s remove single_coast
tag @s remove single_dune
tag @s remove single_eye
tag @s remove single_flow
tag @s remove single_host
tag @s remove single_raiser
tag @s remove single_rib
tag @s remove single_sentry
tag @s remove single_shaper
tag @s remove single_silence
tag @s remove single_snout
tag @s remove single_spire
tag @s remove single_tide
tag @s remove single_vex
tag @s remove single_ward
tag @s remove single_wayfinder
tag @s remove single_wild

# --- snout tags (1) ---
tag @s remove snout_bonus_given

# --- space tags (2) ---
tag @s remove space_2pc
tag @s remove space_4pc

# --- spl tags (4) ---
tag @s remove spl_rogue_2pc
tag @s remove spl_rogue_4pc
tag @s remove spl_rogue_5pc
tag @s remove spl_rogue_6pc

# --- splendid tags (4) ---
tag @s remove splendid_2pc
tag @s remove splendid_4pc
tag @s remove splendid_5pc
tag @s remove splendid_6pc

# --- sr tags (1) ---
tag @s remove sr.prompted

# Wiring Audit B (2026-05-29) W10 (Reachability R10 pre-existing gap): per-player spirit-raid prompt scores.
scoreboard players set @s ec.sr_prompt 0
scoreboard players set @s ec.sr_timer 0

# --- storm tags (2) ---
tag @s remove storm_2pc
tag @s remove storm_4pc

# --- te tags (2) ---
tag @s remove te.quartz_wearing
tag @s remove te.redstone_wearing

# --- trim_effects per-piece score (Wiring Audit #29 W5c — te.diamond → companions/calc_damage) ---
scoreboard players set @s te.diamond 0

# --- AU33-5 redstone trample window (Joseph 2026-05-30) ---
scoreboard players set @s ec.tr_trampled_recently 0

# --- titan tags (4) ---
tag @s remove titan_2pc
tag @s remove titan_4pc
tag @s remove titan_5pc
tag @s remove titan_6pc

# --- trim tags (3) ---
tag @s remove trim_abilities_bolting
tag @s remove trim_boomer
tag @s remove trim_snout

# --- ttn tags (5) ---
tag @s remove ttn_hop_2pc
tag @s remove ttn_hop_4pc
tag @s remove ttn_hoplite_6pc
tag @s remove ttn_jav_2pc
tag @s remove ttn_jav_5pc

# --- verdant tags (3) ---
tag @s remove verdant_2pc
tag @s remove verdant_4pc
tag @s remove verdant_5pc

# --- vex tags (4) ---
tag @s remove vex_ally
tag @s remove vex_attack_cooldown
tag @s remove vex_fangs_cooldown
tag @s remove vex_spawn_cooldown

# --- vrd tags (4) ---
tag @s remove vrd_archer_2pc
tag @s remove vrd_archer_5pc
tag @s remove vrd_hunter_2pc
tag @s remove vrd_hunter_5pc

# --- vs tags (1) ---
tag @s remove vs.just_converted

# --- wb tags (9) ---
tag @s remove wb.enraged
tag @s remove wb.in_water
tag @s remove wb.initializing
tag @s remove wb.last_hit
tag @s remove wb.natural_spawn
tag @s remove wb.participant
tag @s remove wb.summoner
# Soul Warden soul-link + Crimson Behemoth charge-target (R7 Wave B 2026-05-29) — clear on Pioneer wipe.
tag @s remove wb.soul_link
tag @s remove wb.charge_target
# World Boss Champion announce-once flag (Wiring Audit #24 2026-05-29 — Pioneer-wipe compat;
# covered by the nuclear reset above, set explicitly so the champion title can re-unlock).
scoreboard players set @s wb.champ_announced 0
# Boss-exclusive artifact bad-luck-protection dry-streak counter (R5 2026-05-29 refinement wave —
# covered by the nuclear reset above, set explicitly so pity restarts clean after a wipe).
scoreboard players set @s wb.artifact_pity 0

# --- wild tags (1) ---
tag @s remove wild_wolf_cooldown

# --- wither tags (2) ---
tag @s remove wither_2pc
tag @s remove wither_4pc

# === WIPE COMPANION ENTITIES + DATABASE ===
scoreboard players operation #Search companion.id = @s companion.id
kill @e[type=item_display,tag=Companion,predicate=evercraft:companions/check_id]
kill @e[type=interaction,tag=companion.petinteract,predicate=evercraft:companions/check_id]
# hp_label passengers don't auto-die when the head parent is killed — must kill explicitly.
# Forgetting this here is what leaves "❤ 0/0" orphan labels lingering after death cycles.
kill @e[type=text_display,tag=companion.hp_label,predicate=evercraft:companions/check_id]
# SP5 placed-head trio (chicken + PC.Head passenger + standalone PC.Interact). Passengers don't cascade —
# kill each type explicitly so a strip never leaves an orphaned floating head behind.
kill @e[type=item_display,tag=PC.Head,predicate=evercraft:companions/check_id]
kill @e[type=interaction,tag=PC.Interact,predicate=evercraft:companions/check_id]
kill @e[type=chicken,tag=PlacedCompanion,predicate=evercraft:companions/check_id]
execute as @e[type=marker,tag=companion.marker,predicate=evercraft:companions/check_id,limit=1] run data modify entity @s data.Pets set value []
execute as @e[type=marker,tag=companion.marker,predicate=evercraft:companions/check_id,limit=1] run data modify entity @s data.HomePets set value []

# --- companion scoreboards (missing from original list) ---
scoreboard players set @s companion.hp 0
scoreboard players set @s companion.maxhp 0
scoreboard players set @s companion.rp 0
scoreboard players set @s companion.rellevel 0
scoreboard players set @s companion.relmult 0
scoreboard players set @s companion.feedcd 0
scoreboard players set @s companion.interactcd 0
scoreboard players set @s companion.kills 0
scoreboard players set @s companion.count 0
scoreboard players set @s companion.menu 0
scoreboard players set @s companion.menupage 0
scoreboard players set @s companion.exp 0
scoreboard players set @s companion.temp 0
scoreboard players set @s companion.slot 0
scoreboard players reset @s companion.activeslot

# --- SP6 pet-duel state (cleanup normally zeroes these, but a mid-duel strip must too) ---
scoreboard players set @s ec.pd_active 0
scoreboard players set @s ec.pd_inv 0
scoreboard players set @s ec.pd_cd 0
scoreboard players set @s ec.pd_hp 0
scoreboard players set @s ec.pd_atk 0
scoreboard players set @s ec.pd_hpmax 0
scoreboard players set @s ec.pd_tier 0
scoreboard players set @s ec.pd_slots 0
scoreboard players set @s ec.pd_role 0
scoreboard players set @s ec.pd_shield 0
scoreboard players set @s ec.pd_stun 0
scoreboard players set @s ec.pd_dodge 0
scoreboard players set @s ec.pd_castclk 0
scoreboard players set @s ec.pd_castidx 0
scoreboard players set @s ec.pd_pdmg 0

bossbar set evercraft:companion_health visible false

# === MISSING SCOREBOARD RESETS (found via audit 2026-03-27) ===

# --- advancement GUI lore ---
scoreboard players set @s adv.gui_lore_dim 0
scoreboard players set @s adv.gui_lore_pg 0
scoreboard players set @s adv.gui_lore_set 0
scoreboard players set @s adv.gui_lore_subcat 0

# --- affinity system ---
scoreboard players set @s ec.aff_ar 0
scoreboard players set @s ec.aff_bk 0
scoreboard players set @s ec.aff_bl 0
scoreboard players set @s ec.aff_boost 0
scoreboard players set @s ec.aff_class 0
scoreboard players set @s ec.aff_dn 0
scoreboard players set @s ec.aff_ds 0
scoreboard players set @s ec.aff_hl 0
scoreboard players set @s ec.aff_hp 0
scoreboard players set @s ec.aff_ht 0
scoreboard players set @s ec.aff_jv 0
scoreboard players set @s ec.aff_kn 0
scoreboard players set @s ec.aff_kt 0
scoreboard players set @s ec.aff_owner_id 0
scoreboard players set @s ec.aff_prev 0
scoreboard players set @s ec.aff_rg 0
scoreboard players set @s ec.aff_sk 0
# Lore-Limbo (2026-06-03): combat first-XP awaken bitmask — wiped so each class re-awakens.
scoreboard players set @s ec.aff_seen 0
scoreboard players set @s ec.aff_spirit 0
scoreboard players set @s ec.aff_tk 0
scoreboard players set @s ec.aff_twin 0
scoreboard players set @s ec.affb_ar 0
scoreboard players set @s ec.affb_bk 0
scoreboard players set @s ec.affb_bl 0
scoreboard players set @s ec.affb_dn 0
scoreboard players set @s ec.affb_ds 0
scoreboard players set @s ec.affb_hl 0
scoreboard players set @s ec.affb_hp 0
scoreboard players set @s ec.affb_ht 0
scoreboard players set @s ec.affb_jv 0
scoreboard players set @s ec.affb_kn 0
scoreboard players set @s ec.affb_kt 0
scoreboard players set @s ec.affb_rg 0
scoreboard players set @s ec.affb_sk 0
scoreboard players set @s ec.affb_tk 0
scoreboard players set @s ec.affs_ar 0
scoreboard players set @s ec.affs_bk 0
scoreboard players set @s ec.affs_bl 0
scoreboard players set @s ec.affs_dn 0
scoreboard players set @s ec.affs_ds 0
scoreboard players set @s ec.affs_hl 0
scoreboard players set @s ec.affs_hp 0
scoreboard players set @s ec.affs_ht 0
scoreboard players set @s ec.affs_jv 0
scoreboard players set @s ec.affs_kn 0
scoreboard players set @s ec.affs_kt 0
scoreboard players set @s ec.affs_rg 0
scoreboard players set @s ec.affs_sk 0
scoreboard players set @s ec.affs_tk 0
scoreboard players set @s ec.daff_ar 0
scoreboard players set @s ec.daff_bk 0
scoreboard players set @s ec.daff_bl 0
scoreboard players set @s ec.daff_dn 0
scoreboard players set @s ec.daff_ds 0
scoreboard players set @s ec.daff_hl 0
scoreboard players set @s ec.daff_hp 0
scoreboard players set @s ec.daff_ht 0
scoreboard players set @s ec.daff_jv 0
scoreboard players set @s ec.daff_kn 0
scoreboard players set @s ec.daff_kt 0
scoreboard players set @s ec.daff_rg 0
scoreboard players set @s ec.daff_sk 0
scoreboard players set @s ec.daff_tk 0

# --- binder/orebag ---
scoreboard players set @s ec.binder_id 0
scoreboard players set @s ec.binder_page 0
scoreboard players set @s ec.has_binder 0
scoreboard players set @s ec.has_orebag 0
scoreboard players set @s ec.hbag_id 0
scoreboard players set @s ec.orebag_id 0
scoreboard players set @s ec.orebag_page 0

# --- biome mastery ---
scoreboard players set @s ec.biome_mastery 0
scoreboard players set @s ec.bm0 0
scoreboard players set @s ec.bm1 0
scoreboard players set @s ec.bm2 0
scoreboard players set @s ec.bm3 0
scoreboard players set @s ec.bm4 0
scoreboard players set @s ec.bm5 0
scoreboard players set @s ec.bm6 0
scoreboard players set @s ec.bm7 0
scoreboard players set @s ec.bm8 0
scoreboard players set @s ec.bm9 0
scoreboard players set @s ec.bm10 0
scoreboard players set @s ec.bm11 0
scoreboard players set @s ec.bm12 0
scoreboard players set @s ec.bm13 0
scoreboard players set @s ec.bm14 0
scoreboard players set @s ec.bm15 0
scoreboard players set @s ec.bm16 0
scoreboard players set @s ec.bm17 0
scoreboard players set @s ec.bm18 0
scoreboard players set @s ec.bm19 0
scoreboard players set @s ec.bm20 0
scoreboard players set @s ec.bm21 0
scoreboard players set @s ec.bm22 0
scoreboard players set @s ec.bm23 0
scoreboard players set @s ec.bm24 0
scoreboard players set @s ec.bm_level 0
scoreboard players set @s ec.bm_page 0
scoreboard players set @s ec.bm_prev 0
scoreboard players set @s ec.bm_time 0

# --- bounty ---
scoreboard players set @s ec.bnt_biome 0
scoreboard players set @s ec.bnt_dist 0
scoreboard players set @s ec.bnt_kills 0
scoreboard players set @s ec.bnt_owner 0
scoreboard players set @s ec.bnt_spawned 0
scoreboard players set @s ec.bnt_tier 0
scoreboard players set @s ec.bnt_timer 0

# --- buddy (Council #5, 2026-05-27 — player-scoped scratch added) ---
scoreboard players set @s ec.bd_equip_slot 0
scoreboard players set @s ec.bd_summon_uuid0 0
scoreboard players set @s ec.bd_summon_uuid1 0

# --- companion evolution ---
scoreboard players set @s ec.ce_cd 0
scoreboard players set @s ec.ce_death_dim 0
scoreboard players set @s ec.ce_death_x 0
scoreboard players set @s ec.ce_death_y 0
scoreboard players set @s ec.ce_death_z 0
scoreboard players set @s ec.ce_evolved 0
scoreboard players set @s ec.ce_evolved2 0
scoreboard players set @s ec.ce_hit_count 0
scoreboard players set @s ec.ce_idle 0
scoreboard players set @s ec.ce_inferno_cd 0
scoreboard players set @s ec.ce_phase 0
scoreboard players set @s ec.ce_rebirth_timer 0
scoreboard players set @s ec.ce_recall_day 0
scoreboard players set @s ec.ce_seismic_cd 0
scoreboard players set @s ec.ce_stealth 0
scoreboard players set @s ec.ce_stored_hp 0
scoreboard players set @s ec.ce_temp 0
scoreboard players set @s ec.ce_tw_cd 0

# --- craftforever ---
scoreboard players set @s ec.cf_alm_pg 0
scoreboard players set @s ec.cf_art_cat 0
scoreboard players set @s ec.cf_art_check_roll 0
scoreboard players set @s ec.cf_art_thresh 0
scoreboard players set @s ec.cf_art_tier 0
scoreboard players set @s ec.cf_axp_alch 0
scoreboard players set @s ec.cf_axp_build 0
scoreboard players set @s ec.cf_axp_cook 0
scoreboard players set @s ec.cf_axp_fish 0
scoreboard players set @s ec.cf_axp_forage 0
scoreboard players set @s ec.cf_axp_forge 0
scoreboard players set @s ec.cf_axp_mine 0
scoreboard players set @s ec.cf_cat_tier 0
scoreboard players set @s ec.cf_codex 0
scoreboard players set @s ec.cf_codex_cd 0
scoreboard players set @s ec.cf_codex_page 0
scoreboard players set @s ec.cf_codex_section 0
scoreboard players set @s ec.cf_codex_use 0
scoreboard players set @s ec.cf_craft_found 0
scoreboard players set @s ec.cf_gui_session 0
scoreboard players set @s ec.cf_heat 0
scoreboard players set @s ec.cf_info 0
scoreboard players set @s ec.cf_lock_zone 0
scoreboard players set @s ec.cf_mat_tier 0
scoreboard players set @s ec.cf_materials 0
scoreboard players set @s ec.cf_menu_time 0
scoreboard players set @s ec.cf_mine_prog 0
scoreboard players set @s ec.cf_mine_sx 0
scoreboard players set @s ec.cf_mine_sy 0
scoreboard players set @s ec.cf_mine_sz 0
scoreboard players set @s ec.cf_mining 0
scoreboard players set @s ec.cf_node_mined 0
scoreboard players set @s ec.cf_nodes_done 0
scoreboard players set @s ec.cf_nodes_found 0
scoreboard players set @s ec.cf_p1 0
scoreboard players set @s ec.cf_p2 0
scoreboard players set @s ec.cf_p3 0
scoreboard players set @s ec.cf_p4 0
scoreboard players set @s ec.cf_p5 0
scoreboard players set @s ec.cf_p6 0
scoreboard players set @s ec.cf_p7 0
scoreboard players set @s ec.cf_pat_len 0
scoreboard players set @s ec.cf_pat_pos 0
scoreboard players set @s ec.cf_phase 0
scoreboard players set @s ec.cf_quality 0
scoreboard players set @s ec.cf_quench 0
scoreboard players set @s ec.cf_rank 0
scoreboard players set @s ec.cf_title_earned 0
scoreboard players set @s ec.cf_title_active 0
execute if entity @s[team=cf.title_1] run team leave @s
execute if entity @s[team=cf.title_2] run team leave @s
execute if entity @s[team=cf.title_3] run team leave @s
# Dodge HP snapshot + i-frame tag (Wave G AU33-1 2026-05-31 — true pre-hit cancel architecture)
scoreboard players set @s ec.dodge_hp_snap 0
tag @s remove ec.dodge_iframe
# Guild Cards (village-gated claimed-rank mirror — feature 2026-05-29)
scoreboard players set @s ec.mg_rank 0
scoreboard players set @s ec.ag_rank 0
scoreboard players set @s ec.mg_eligible 0
scoreboard players set @s ec.ag_eligible 0
scoreboard players set @s ec.mg_notified 0
scoreboard players set @s ec.ag_notified 0
scoreboard players set @s ec.cr_guild 0
scoreboard players set @s ec.mg_title 0
scoreboard players set @s ec.ag_title 0
scoreboard players set @s ec.mg_cosmetic 0
scoreboard players set @s ec.ag_cosmetic 0
scoreboard players set @s ec.gc_prompt_cd 0
# Builder (Handcrafter) card — ec.bc_* family (Grand Convergence W2, 2026-05-31).
# The nuclear `scoreboard players reset @s` above already clears these; explicit 0-set
# keeps the contract obvious (matches the mg/ag block) and the matches-N gates read clean.
scoreboard players set @s ec.bc_rank 0
scoreboard players set @s ec.bc_credit 0
scoreboard players set @s ec.bc_eligible 0
scoreboard players set @s ec.bc_notified 0
scoreboard players set @s ec.bc_title 0
scoreboard players set @s ec.bc_cosmetic 0
scoreboard players set @s ec.bc_reach 0
scoreboard players set @s ec.bc_snap 0
scoreboard players set @s ec.bc_today 0
scoreboard players set @s ec.bc_day 0
scoreboard players set @s ec.bc_seeded 0
# Grand-Quests fusion-offer latches — ec.gq_offered / ec.gq_fused (Grand Convergence
# W5, 2026-06-01). One-time player-state latches behind the fishing-book fusion
# OFFER; a full strip must clear them so a clean-slate player can re-receive the
# offer on first book obtain. (The gq_fuse *notify* objectives — ec.nm_gq_fuse etc.
# — are intentionally NOT zeroed here, matching the F1/C3/C4 precedent for the
# *_adv notify families; that is a parked cross-wave cleanup, not this wave's scope.)
scoreboard players set @s ec.gq_offered 0
scoreboard players set @s ec.gq_fused 0
# ec.gq_track — the [Skip ▸] tracked-line slot (Wiring #52). A full strip clears it so a
# clean-slate player tracks nothing until they start (auto-track) or pin a line.
scoreboard players set @s ec.gq_track 0
attribute @s max_health modifier remove evercraft:guild_adv_health
attribute @s movement_speed modifier remove evercraft:guild_adv_speed
# W3: also drop the Builder's Reach perk modifier (the ec.bc_reach 0 above stops
# reapply_all re-adding it, but the live modifier would otherwise linger until relog).
attribute @s block_interaction_range modifier remove evercraft:gc_hand_reach
scoreboard players set @s ec.cf_recipe 0
scoreboard players set @s ec.cf_recipes_found 0
scoreboard players set @s ec.cf_art_recipes_found 0
scoreboard players set @s ec.cf_alch_recipes_found 0
scoreboard players set @s ec.cf_alch_aq_recipes_found 0
scoreboard players set @s ec.recipes_learned_total 0
scoreboard players set @s ec.cf_reso 0
scoreboard players set @s ec.cf_reso_dir 0
scoreboard players set @s ec.cf_reso_pos 0
scoreboard players set @s ec.cf_reso_timer 0
scoreboard players set @s ec.cf_reso_zone 0
scoreboard players set @s ec.cf_state 0
scoreboard players set @s ec.cf_temp 0
scoreboard players set @s ec.cf_timer 0
scoreboard players set @s ec.cf_trophies 0
scoreboard players set @s ec.cf_xp 0
scoreboard players set @s ec.cf_xp_next 0
scoreboard players set @s ec.st_owner 0

# --- cooking ---
scoreboard players set @s ec.ck_art_cat 0
scoreboard players set @s ec.ck_art_tier 0
scoreboard players set @s ec.ff_grind_ct 0
scoreboard players set @s ec.ff_heat 0
scoreboard players set @s ec.ff_phase 0
scoreboard players set @s ec.ff_pri_cat 0
scoreboard players set @s ec.ff_pri_tier 0
scoreboard players set @s ec.ff_quality 0
scoreboard players set @s ec.ff_recipe 0
scoreboard players set @s ec.ff_rune_round 0
scoreboard players set @s ec.ff_rune_target 0
scoreboard players set @s ec.ff_sec_cat 0
scoreboard players set @s ec.ff_sec_tier 0
scoreboard players set @s ec.ff_state 0
scoreboard players set @s ec.ff_target 0
scoreboard players set @s ec.ff_timer 0

# --- codex/crafting ---
scoreboard players set @s ec.codex_combine 0
scoreboard players set @s ec.codex_tier 0
scoreboard players set @s ec.cr_artisan 0
scoreboard players set @s ec.cr_base 0
scoreboard players set @s ec.cr_forge_crystal 0
scoreboard players set @s ec.cr_temp 0
scoreboard players set @s ec.cr_tool 0
scoreboard players set @s ec.craft_rate 0

# --- ecodex/phoenix ---
scoreboard players set @s ec.ecodex_tab 0
scoreboard players set @s ec.ecodex_use 0
scoreboard players set @s ec.ecodex_cd 0
scoreboard players set @s ec.tool_tog_cd 0
scoreboard players set @s ec.phoenix_tab 0
scoreboard players set @s ec.phoenix_use 0
scoreboard players set @s ec.phoenix_cd 0

# --- heist ---
scoreboard players set @s ec.heist 0
scoreboard players set @s ec.heist_active 0
scoreboard players set @s ec.heist_timer 0
scoreboard players set @s ec.heist_wins 0

# --- hero satchel ---
# SATCHEL MARK SWEEP (Joseph 2026-06-10, fixed 2026-06-12): the canonical clears
# now run in the pre-nuke block above (line ~47) — they read ec.satchel_id /
# ec.hsatch_id, which the nuclear scoreboard reset below would zero before they
# get a chance to execute. Carry-latches still belong here as a post-nuke seal.
# Carry latches: 0 = "not carrying", matching the satchel items destroyed by the wipe.
scoreboard players set @s ec.sat_carrying 0
scoreboard players set @s ec.peb_carry 0
scoreboard players set @s ec.hsatch_count 0
scoreboard players set @s ec.hsatch_id 0
scoreboard players set @s ec.hsatch_slots 0

# --- lore/excavation ---
scoreboard players set @s ec.lore_add 0
scoreboard players set @s ec.lore_cached 0
scoreboard players set @s ec.lore_cat 0
scoreboard players set @s ec.lore_dim 0
scoreboard players set @s ec.lore_dim0_done 0
scoreboard players set @s ec.lore_dim1_done 0
scoreboard players set @s ec.lore_dim2_done 0
scoreboard players set @s ec.lore_dim3_done 0
scoreboard players set @s ec.lore_lastx 0
scoreboard players set @s ec.lore_lastz 0
scoreboard players set @s ec.lore_map 0
scoreboard players set @s ec.lore_moving 0
scoreboard players set @s ec.lore_picking 0
scoreboard players set @s ec.lore_piece 0
scoreboard players set @s ec.lore_piece_id 0
scoreboard players set @s ec.lore_progress 0
scoreboard players set @s ec.lore_rarity 0
scoreboard players set @s ec.lore_set 0
scoreboard players set @s ec.lore_set_id 0
scoreboard players set @s ec.lore_sets_done 0
scoreboard players set @s ec.lore_struct_id 0
scoreboard players set @s ec.lore_sx 0
scoreboard players set @s ec.lore_sy 0
scoreboard players set @s ec.lore_sz 0
scoreboard players set @s ec.lore_timer 0
scoreboard players set @s ec.lr_page 0

# --- lore slots (162) ---
scoreboard players set @s ec.ls_1 0
scoreboard players set @s ec.ls_2 0
scoreboard players set @s ec.ls_3 0
scoreboard players set @s ec.ls_4 0
scoreboard players set @s ec.ls_5 0
scoreboard players set @s ec.ls_6 0
scoreboard players set @s ec.ls_7 0
scoreboard players set @s ec.ls_8 0
scoreboard players set @s ec.ls_9 0
scoreboard players set @s ec.ls_10 0
scoreboard players set @s ec.ls_11 0
scoreboard players set @s ec.ls_12 0
scoreboard players set @s ec.ls_13 0
scoreboard players set @s ec.ls_14 0
scoreboard players set @s ec.ls_15 0
scoreboard players set @s ec.ls_16 0
scoreboard players set @s ec.ls_17 0
scoreboard players set @s ec.ls_18 0
scoreboard players set @s ec.ls_19 0
scoreboard players set @s ec.ls_20 0
scoreboard players set @s ec.ls_21 0
scoreboard players set @s ec.ls_22 0
scoreboard players set @s ec.ls_23 0
scoreboard players set @s ec.ls_24 0
scoreboard players set @s ec.ls_25 0
scoreboard players set @s ec.ls_26 0
scoreboard players set @s ec.ls_27 0
scoreboard players set @s ec.ls_28 0
scoreboard players set @s ec.ls_29 0
scoreboard players set @s ec.ls_30 0
scoreboard players set @s ec.ls_31 0
scoreboard players set @s ec.ls_32 0
scoreboard players set @s ec.ls_33 0
scoreboard players set @s ec.ls_34 0
scoreboard players set @s ec.ls_35 0
scoreboard players set @s ec.ls_36 0
scoreboard players set @s ec.ls_37 0
scoreboard players set @s ec.ls_38 0
scoreboard players set @s ec.ls_39 0
scoreboard players set @s ec.ls_40 0
scoreboard players set @s ec.ls_41 0
scoreboard players set @s ec.ls_42 0
scoreboard players set @s ec.ls_43 0
scoreboard players set @s ec.ls_44 0
scoreboard players set @s ec.ls_45 0
scoreboard players set @s ec.ls_46 0
scoreboard players set @s ec.ls_47 0
scoreboard players set @s ec.ls_48 0
scoreboard players set @s ec.ls_49 0
scoreboard players set @s ec.ls_50 0
scoreboard players set @s ec.ls_51 0
scoreboard players set @s ec.ls_52 0
scoreboard players set @s ec.ls_53 0
scoreboard players set @s ec.ls_54 0
scoreboard players set @s ec.ls_55 0
scoreboard players set @s ec.ls_56 0
scoreboard players set @s ec.ls_57 0
scoreboard players set @s ec.ls_58 0
scoreboard players set @s ec.ls_59 0
scoreboard players set @s ec.ls_60 0
scoreboard players set @s ec.ls_61 0
scoreboard players set @s ec.ls_62 0
scoreboard players set @s ec.ls_63 0
scoreboard players set @s ec.ls_64 0
scoreboard players set @s ec.ls_65 0
scoreboard players set @s ec.ls_66 0
scoreboard players set @s ec.ls_67 0
scoreboard players set @s ec.ls_68 0
scoreboard players set @s ec.ls_69 0
scoreboard players set @s ec.ls_70 0
scoreboard players set @s ec.ls_71 0
scoreboard players set @s ec.ls_72 0
scoreboard players set @s ec.ls_73 0
scoreboard players set @s ec.ls_74 0
scoreboard players set @s ec.ls_75 0
scoreboard players set @s ec.ls_76 0
scoreboard players set @s ec.ls_77 0
scoreboard players set @s ec.ls_78 0
scoreboard players set @s ec.ls_79 0
scoreboard players set @s ec.ls_80 0
scoreboard players set @s ec.ls_81 0
scoreboard players set @s ec.ls_82 0
scoreboard players set @s ec.ls_83 0
scoreboard players set @s ec.ls_84 0
scoreboard players set @s ec.ls_85 0
scoreboard players set @s ec.ls_86 0
scoreboard players set @s ec.ls_87 0
scoreboard players set @s ec.ls_88 0
scoreboard players set @s ec.ls_89 0
scoreboard players set @s ec.ls_90 0
scoreboard players set @s ec.ls_91 0
scoreboard players set @s ec.ls_92 0
scoreboard players set @s ec.ls_93 0
scoreboard players set @s ec.ls_94 0
scoreboard players set @s ec.ls_95 0
scoreboard players set @s ec.ls_96 0
scoreboard players set @s ec.ls_97 0
scoreboard players set @s ec.ls_98 0
scoreboard players set @s ec.ls_99 0
scoreboard players set @s ec.ls_100 0
scoreboard players set @s ec.ls_101 0
scoreboard players set @s ec.ls_102 0
scoreboard players set @s ec.ls_103 0
scoreboard players set @s ec.ls_104 0
scoreboard players set @s ec.ls_105 0
scoreboard players set @s ec.ls_106 0
scoreboard players set @s ec.ls_107 0
scoreboard players set @s ec.ls_108 0
scoreboard players set @s ec.ls_109 0
scoreboard players set @s ec.ls_110 0
scoreboard players set @s ec.ls_111 0
scoreboard players set @s ec.ls_112 0
scoreboard players set @s ec.ls_113 0
scoreboard players set @s ec.ls_114 0
scoreboard players set @s ec.ls_115 0
scoreboard players set @s ec.ls_116 0
scoreboard players set @s ec.ls_117 0
scoreboard players set @s ec.ls_118 0
scoreboard players set @s ec.ls_119 0
scoreboard players set @s ec.ls_120 0
scoreboard players set @s ec.ls_121 0
scoreboard players set @s ec.ls_122 0
scoreboard players set @s ec.ls_123 0
scoreboard players set @s ec.ls_124 0
scoreboard players set @s ec.ls_125 0
scoreboard players set @s ec.ls_126 0
scoreboard players set @s ec.ls_127 0
scoreboard players set @s ec.ls_128 0
scoreboard players set @s ec.ls_129 0
scoreboard players set @s ec.ls_130 0
scoreboard players set @s ec.ls_131 0
scoreboard players set @s ec.ls_132 0
scoreboard players set @s ec.ls_133 0
scoreboard players set @s ec.ls_134 0
scoreboard players set @s ec.ls_135 0
scoreboard players set @s ec.ls_136 0
scoreboard players set @s ec.ls_137 0
scoreboard players set @s ec.ls_138 0
scoreboard players set @s ec.ls_139 0
scoreboard players set @s ec.ls_140 0
scoreboard players set @s ec.ls_141 0
scoreboard players set @s ec.ls_142 0
scoreboard players set @s ec.ls_143 0
scoreboard players set @s ec.ls_144 0
scoreboard players set @s ec.ls_145 0
scoreboard players set @s ec.ls_146 0
scoreboard players set @s ec.ls_147 0
scoreboard players set @s ec.ls_148 0
scoreboard players set @s ec.ls_149 0
scoreboard players set @s ec.ls_150 0
scoreboard players set @s ec.ls_151 0
scoreboard players set @s ec.ls_152 0
scoreboard players set @s ec.ls_153 0
scoreboard players set @s ec.ls_154 0
scoreboard players set @s ec.ls_155 0
scoreboard players set @s ec.ls_156 0
scoreboard players set @s ec.ls_157 0
scoreboard players set @s ec.ls_158 0
scoreboard players set @s ec.ls_159 0
scoreboard players set @s ec.ls_160 0
scoreboard players set @s ec.ls_161 0
scoreboard players set @s ec.ls_162 0

# --- ore memory ---
scoreboard players set @s ec.obid 0
scoreboard players set @s ec.abid 0
scoreboard players set @s ec.om_debris 0
scoreboard players set @s ec.om_prev_coal 0
scoreboard players set @s ec.om_prev_cop 0
scoreboard players set @s ec.om_prev_dcoal 0
scoreboard players set @s ec.om_prev_dcop 0
scoreboard players set @s ec.om_prev_ddia 0
scoreboard players set @s ec.om_prev_debris 0
scoreboard players set @s ec.om_prev_demer 0
scoreboard players set @s ec.om_prev_dgold 0
scoreboard players set @s ec.om_prev_dia 0
scoreboard players set @s ec.om_prev_diron 0
scoreboard players set @s ec.om_prev_dlapis 0
scoreboard players set @s ec.om_prev_dred 0
scoreboard players set @s ec.om_prev_emer 0
scoreboard players set @s ec.om_prev_gold 0
scoreboard players set @s ec.om_prev_iron 0
scoreboard players set @s ec.om_prev_lapis 0
scoreboard players set @s ec.om_prev_ngold 0
scoreboard players set @s ec.om_prev_red 0

# --- prospect/mining ---
scoreboard players set @s ec.pm_page 0
scoreboard players set @s ec.pr_lastx 0
scoreboard players set @s ec.pr_lastz 0
scoreboard players set @s ec.pr_moving 0
scoreboard players set @s ec.pr_picking 0
scoreboard players set @s ec.pr_progress 0
scoreboard players set @s ec.pr_sx 0
scoreboard players set @s ec.pr_sy 0
scoreboard players set @s ec.pr_sz 0
scoreboard players set @s ec.pr_timer 0

# --- misc ---
scoreboard players set @s ec.tt_active 0
scoreboard players set @s ec.tt_owner 0
scoreboard players set @s ec.tt_mods 0
scoreboard players set @s ec.tt_pid 0
scoreboard players set @s ec.tt_zone 0
scoreboard players set @s ec.tt_haz_t 0
scoreboard players set @s ec.tt_haz_y 0
scoreboard players set @s ec.tt_type 0
# Spirit-Tool Pity (2026-06-06): 6 per-category bad-luck-protection counters. The nuclear
# `scoreboard players reset @s` above already clears these, but per the file convention the
# explicit 0-set keeps the contract obvious — a reborn Pioneer starts with zero accrued pity.
scoreboard players set @s ec.tt_sp_pity1 0
scoreboard players set @s ec.tt_sp_pity2 0
scoreboard players set @s ec.tt_sp_pity3 0
scoreboard players set @s ec.tt_sp_pity4 0
scoreboard players set @s ec.tt_sp_pity5 0
scoreboard players set @s ec.tt_sp_pity6 0
scoreboard players set @s ec.wc_battle 0
scoreboard players set @s ec.ww_idle 0
scoreboard players set @s ec.ww_talked 0
scoreboard players set @s ec.ww_talked_prev 0

# --- legendary/rewards ---
scoreboard players set @s lx.count 0
scoreboard players set @s lx.required 0
scoreboard players set @s lx.reward 0
scoreboard players set @s lx.temp 0
scoreboard players set @s lx.tier 0

# --- more professions ---
scoreboard players set @s more_professions_binary 0
scoreboard players set @s more_professions_offers 0
scoreboard players set @s more_professions_rng 0
scoreboard players set @s more_professions_trade_progress 0
scoreboard players set @s more_professions_visible_trade_progress 0

# --- multiplayer/vault ---
scoreboard players set @s mp.grace 0
scoreboard players set @s vs.exile 0
scoreboard players set @s vs.temp 0

# --- wild companions (player-facing only) ---
scoreboard players set @s wc.daily_count 0
scoreboard players set @s wc.spawn_cd 0
scoreboard players set @s wc.has_catalogue 0
scoreboard players set @s wc.has_charm 0
scoreboard players set @s wc.snare_tier 0
scoreboard players set @s wc.battle_hp 0
scoreboard players set @s wc.battle_atk 0
scoreboard players set @s wc.battle_maxhp 0
scoreboard players set @s wc.battle_tier 0
scoreboard players set @s wc.battle_timer 0
scoreboard players set @s wc.hostile_hp 0
scoreboard players set @s wc.hostile_atk 0
scoreboard players set @s wc.hostile_maxhp 0
scoreboard players set @s wc.dodge_cd 0
scoreboard players set @s wc.power_cd 0
scoreboard players set @s wc.ally_cd 0
scoreboard players set @s wc.enemy_cd 0

# === STORY MODE RESET ===
scoreboard players set @s sm.mode 0
scoreboard players set @s sm.path 0
scoreboard players set @s sm.act 0
scoreboard players set @s sm.chapter 0
scoreboard players set @s sm.step 0
scoreboard players set @s sm.quest_prog 0
scoreboard players set @s sm.quest_goal 0
scoreboard players set @s sm.quest_type 0
scoreboard players set @s sm.chapters_done 0
scoreboard players set @s sm.conv_done 0
scoreboard players set @s sm.showcase_act 0
scoreboard players set @s sm.reward_coins 0
scoreboard players set @s sm.branch 0
scoreboard players set @s sm.main_chapter 0
scoreboard players set @s sm.side_done 0
scoreboard players set @s sm.map_view 0
scoreboard players set @s sm.branch_unlocked 0
scoreboard players set @s sm.conv_step 0
scoreboard players set @s sm.conv_id 0
scoreboard players set @s sm.conv_wait_until 0
scoreboard players set @s sm.tip_offered 0
tag @s remove ec.spirit_chosen

# === DIFFICULTY + TUTORIAL RESET ===
# ec.tutorial_path + ec.tutorial_step dropped 2026-05-28 (Council #15) — scoreboards retired
# alongside the tutorial UI archive. ec.tutorial_done stays: live story gate at ch2/check:8.
scoreboard players set @s ec.difficulty 0
scoreboard players set @s ec.tutorial_done 0

# ══════════════════════════════════════════════════════════════
# === MISSING SYSTEMS ADDED 2026-04-05 ===
# ══════════════════════════════════════════════════════════════

# === CLEAR ALL EFFECTS ===
effect clear @s

# === LEAVE ALL TEAMS (titles, glow, etc.) ===
team leave @s

# === BLUEPRINT SYSTEM (ec.bp_*) ===
scoreboard players set @s ec.bp_use 0
scoreboard players set @s ec.bp_held 0
scoreboard players set @s ec.bp_state 0
scoreboard players set @s ec.bp_selected 0
scoreboard players set @s ec.bp_tier 0
scoreboard players set @s ec.bp_rotation 0
scoreboard players set @s ec.bp_layer 0
scoreboard players set @s ec.bp_max_layer 0
scoreboard players set @s ec.bp_x 0
scoreboard players set @s ec.bp_y 0
scoreboard players set @s ec.bp_z 0
scoreboard players set @s ec.bp_cd 0
scoreboard players set @s ec.bp_uid 0
scoreboard players set @s ec.bp_cancel_at 0
tag @s remove bp.previewing
tag @s remove bp.building

# === SPIRIT WEAPON (ec.sp_*) ===
scoreboard players set @s ec.sp_all_prestige 0
scoreboard players set @s ec.sp_boosted 0
scoreboard players set @s ec.sp_charges 0
scoreboard players set @s ec.sp_combo 0
scoreboard players set @s ec.sp_cur_streak 0
scoreboard players set @s ec.sp_hit_combo 0
scoreboard players set @s ec.sp_kill_streak 0
scoreboard players set @s ec.sp_quest 0
scoreboard players set @s ec.sp_rampage 0
scoreboard players set @s ec.sp_rampage_dmg 0
scoreboard players set @s ec.sp_shield_charge 0
scoreboard players set @s ec.sp_state 0
scoreboard players set @s ec.sp_survive 0
scoreboard players set @s ec.sp_wall_absorb 0
scoreboard players set @s ec.sp_castle_max 0
scoreboard players set @s ec.sp_castle_hoplite 0

# === GUIDESTONE (ec.gs_*) ===
scoreboard players set @s ec.gs_id 0
scoreboard players set @s ec.gs_menu_time 0
scoreboard players set @s ec.gs_my_pets 0
scoreboard players set @s ec.gs_page 0
scoreboard players set @s ec.gs_pet_count 0
scoreboard players set @s ec.gs_temp 0
scoreboard players set @s ec.gs_view 0
scoreboard players set @s ec.gs_warp_cd 0

# === HOUSING (hs.*) ===
scoreboard players set @s hs.decor 0
scoreboard players set @s hs.failed 0
scoreboard players set @s hs.menu_time 0
scoreboard players set @s hs.protect 0
scoreboard players set @s hs.protect_warned 0
scoreboard players set @s hs.stashed 0
scoreboard players set @s hs.temp 0
scoreboard players set @s hs.warp_cd 0
scoreboard players set @s hs.visitors 0
scoreboard players set @s hs.visit_today 0
scoreboard players set @s hs.guest_pass 0

# === HEALTH BAR (hb.*) ===
scoreboard players set @s hb.enabled 0
scoreboard players set @s hb.health 0
scoreboard players set @s hb.linger 0
scoreboard players set @s hb.maxhealth 0
scoreboard players set @s hb.pct 0
scoreboard players set @s hb.ray 0
scoreboard players set @s hb.slot 0
tag @s remove hb.found
tag @s remove hb.was_enabled
tag @s remove hb.accent_furia
tag @s remove hb.accent_patron
tag @s remove hb.accent_pet

# === INFINITE CASTLE (ic.*) ===
scoreboard players set @s ic.claimed 0
scoreboard players set @s ic.coins 0
scoreboard players set @s ic.deaths 0
scoreboard players set @s ic.last_day 0
scoreboard players set @s ic.record 0
scoreboard players set @s ic.today 0

# === BIOME MASTERY (bm.*) ===
scoreboard players set @s bm.title 0
scoreboard players set @s bm.titles 0

# === STATS SHOWCASE (ss.*) ===
scoreboard players set @s ss.artifacts 0
scoreboard players set @s ss.comps 0
scoreboard players set @s ss.crates 0
scoreboard players set @s ss.dungeons 0
scoreboard players set @s ss.journey_count 0
scoreboard players set @s ss.mobs 0
scoreboard players set @s ss.playtime 0
scoreboard players set @s ss.quests 0

# === SPECTATOR (sp.*) ===
scoreboard players set @s sp.active 0
scoreboard players set @s sp.intro_phase 0
scoreboard players set @s sp.intro_timer 0

# === QUEST PREVIEW (ec.qp_*) ===
scoreboard players set @s ec.qp_active 0
scoreboard players set @s ec.qp_locked 0
scoreboard players set @s ec.qp_rerolled 0
scoreboard players set @s ec.qp_tier 0

# === LABORER (ec.lb_*) ===
scoreboard players set @s ec.lb_adventures 0
scoreboard players set @s ec.lb_count 0
scoreboard players set @s ec.lb_exp_dur 0
scoreboard players set @s ec.lb_exp_start 0
scoreboard players set @s ec.lb_expeditions 0
scoreboard players set @s ec.lb_fed 0
scoreboard players set @s ec.lb_food_cat 0
scoreboard players set @s ec.lb_food_tier 0
scoreboard players set @s ec.lb_hire_type 0
scoreboard players set @s ec.lb_max 0
scoreboard players set @s ec.lb_owner_id 0
scoreboard players set @s ec.lb_perm_bonus 0
scoreboard players set @s ec.lb_quality 0
scoreboard players set @s ec.lb_slot 0
scoreboard players set @s ec.lb_state 0
scoreboard players set @s ec.lb_type 0
tag @s remove ec.lb_restore
tag @s remove ec.lb_placeholder

# === CRAFT AFFINITY (ec.caff_*) ===
scoreboard players set @s ec.caff_boost 0
scoreboard players set @s ec.caff_class 0
scoreboard players set @s ec.caff_gs 0
scoreboard players set @s ec.caff_lf 0
scoreboard players set @s ec.caff_lm 0
scoreboard players set @s ec.caff_sc 0
scoreboard players set @s ec.caff_ss 0
scoreboard players set @s ec.caff_tw 0
scoreboard players set @s ec.caff_gw 0
# Node-competition harvest counters (Wave 3a; sole writers on_shear_sheep / gw_grant_t* ).
# Reset so a wiped player re-defaults their shearing/crafting tally to 0.
scoreboard players set @s ec.cnode_shear 0
scoreboard players set @s ec.cnode_craft 0
# Co-op node event per-player baseline + contribution (Wave 3b). Reset so a wipe mid-event
# leaves no stale baseline/contribution. (tick_player clamps a negative delta to 0 anyway.)
scoreboard players set @s ec.coev_base 0
scoreboard players set @s ec.coev_ctrb 0
# Seasonal Node Festival per-player participation (Wave 3c). Reset days/today/baseline so a
# wiped player re-defaults to no festival progress.
scoreboard players set @s ec.nfest_days 0
scoreboard players set @s ec.nfest_today 0
scoreboard players set @s ec.nfest_base 0
# Derived per-class stage + boost (else a wiped player keeps Stage-7 passives/boost)
scoreboard players set @s ec.caffs_ss 0
scoreboard players set @s ec.caffs_lf 0
scoreboard players set @s ec.caffs_gs 0
scoreboard players set @s ec.caffs_tw 0
scoreboard players set @s ec.caffs_sc 0
scoreboard players set @s ec.caffs_lm 0
scoreboard players set @s ec.caffs_gw 0
scoreboard players set @s ec.caffb_ss 0
scoreboard players set @s ec.caffb_lf 0
scoreboard players set @s ec.caffb_gs 0
scoreboard players set @s ec.caffb_tw 0
scoreboard players set @s ec.caffb_sc 0
scoreboard players set @s ec.caffb_lm 0
scoreboard players set @s ec.caffb_gw 0
# Per-class daily counters (Gearwright has NO daily counter — §14.5)
scoreboard players set @s ec.cdaff_ss 0
scoreboard players set @s ec.cdaff_lf 0
scoreboard players set @s ec.cdaff_gs 0
scoreboard players set @s ec.cdaff_tw 0
scoreboard players set @s ec.cdaff_sc 0
scoreboard players set @s ec.cdaff_lm 0
# Per-class mastery flags (Artisan Tome attunement)
scoreboard players set @s ec.caffm_ss 0
scoreboard players set @s ec.caffm_lf 0
scoreboard players set @s ec.caffm_gs 0
scoreboard players set @s ec.caffm_tw 0
scoreboard players set @s ec.caffm_sc 0
scoreboard players set @s ec.caffm_lm 0
scoreboard players set @s ec.caffm_gw 0
# Ordinary-tool entry hook (Reachability wave, 2026-05-28): per-verb stat snapshots,
# combined-activity snapshot, primed flag, artifact tier read, first-XP one-shot bitmask.
# Reset so a wiped player re-primes cleanly and re-discovers each class's first-XP toast.
scoreboard players set @s ec.caff_pv_mine 0
scoreboard players set @s ec.caff_pv_log 0
scoreboard players set @s ec.caff_pv_crop 0
scoreboard players set @s ec.caff_pv_dirt 0
scoreboard players set @s ec.caff_pv_fish 0
scoreboard players set @s ec.caff_pv_wool 0
# Gearwright (class 7) placement-family prevs (Chest-Node feature) — reset so a wiped player re-primes.
scoreboard players set @s ec.caff_pv_rs 0
scoreboard players set @s ec.caff_pv_rail 0
scoreboard players set @s ec.caff_act_prev 0
scoreboard players set @s ec.caff_primed 0
scoreboard players set @s ec.caff_tier 1
scoreboard players set @s ec.caff_seen 0
# Live XP bar default-ON latch + per-class track flags (Joseph 2026-06-01). Clearing the latch
# (ec.caff_dflt 0) makes prime_snapshots re-default all six bars ON for the wiped player on its
# next detector run; the explicit track-flag 0-set keeps the contract obvious (the nuclear reset
# above already covers them). Without this, a wiped player would keep stale ON/OFF toggles.
scoreboard players set @s ec.caff_dflt 0
scoreboard players set @s ec.caff_track_ss 0
scoreboard players set @s ec.caff_track_lf 0
scoreboard players set @s ec.caff_track_gs 0
scoreboard players set @s ec.caff_track_tw 0
scoreboard players set @s ec.caff_track_sc 0
scoreboard players set @s ec.caff_track_lm 0
scoreboard players set @s ec.caff_track_gw 0
# Passive class abilities (Ship 2a): stacking-LAW flag + anti-cascade tag.
scoreboard players set @s ec.caff_mult_fired 0
tag @s remove ec.caff_mining
# Active shift-hold abilities (Ship 2b): sneak debounce + cooldown-ready edge snapshot.
scoreboard players set @s ec.caff_snk 0
scoreboard players set @s ec.caff_snk_t 0
scoreboard players set @s ec.caff_cd_was 0
# Classes Enhancement Ship A (2026-05-28): signature tier read (0=ineligible, 4-8 by tier).
scoreboard players set @s ec.caff_sigtier 0
# Gearwright (class 7) separate omnitool signature tier (§14.2) + the 4 system-accessory summed flags
# (§6, the chest engine reads them) — reset so a wiped player loses any held accessory's effect.
scoreboard players set @s ec.gw_sigtier 0
scoreboard players set @s ec.acc_cratepct 0
scoreboard players set @s ec.acc_spawn 0
scoreboard players set @s ec.acc_openpct 0
scoreboard players set @s ec.acc_ender 0
# Classes Enhancement Ship B (2026-05-28): Stonestrike charges + Lamentor charges + toggle ctr.
scoreboard players set @s ec.caff_smelt_chg 0
scoreboard players set @s ec.caff_smelt_mine 0
scoreboard players set @s ec.used_n_caffpick 0
scoreboard players set @s ec.caff_shear_chg 0
# Classes Enhancement Ship C (2026-05-28): Sirencall ward charges + fish-refresh ctr.
scoreboard players set @s ec.caff_kill_chg 0
scoreboard players set @s ec.caff_kill_fish 0
# Defensive: clear leftover ward-dispatch tag if any (set start, removed end of sc_autokill).
tag @s remove ec.caff_ward_fired
# Classes Enhancement Ship D (2026-05-28): Earthshaper state machine + dig charges + ctr.
scoreboard players set @s ec.caff_es_state 0
scoreboard players set @s ec.caff_es_depth 1
scoreboard players set @s ec.caff_es_chg 0
scoreboard players set @s ec.caff_es_dig 0
scoreboard players set @s ec.used_n_caffshov 0

# === CRAFTFOREVER MISC ===
scoreboard players set @s ec.cf_total_forges 0
scoreboard players set @s ec.cf_info 0
scoreboard players set @s ec.cf_codex_cd 0
scoreboard players set @s ec.cf_alm_pg 0

# === DUELING (ec.duel_*) ===
scoreboard players set @s ec.duel_active 0
scoreboard players set @s ec.duel_class 0
scoreboard players set @s ec.duel_inv 0
scoreboard players set @s ec.duel_inv_cd 0
scoreboard players set @s ec.duel_kills 0
scoreboard players set @s ec.duel_kills_total 0
scoreboard players set @s ec.duel_last_day 0
scoreboard players set @s ec.duel_mode 0
scoreboard players set @s ec.duel_target 0
scoreboard players set @s ec.duel_team 0
scoreboard players set @s ec.duel_team_num 0
scoreboard players set @s ec.duel_today 0
scoreboard players set @s ec.duel_warn 0

# === LIFETIME MILESTONE ACCUMULATORS (overhaul 2026-06-06) ===
# New lifetime counters that back the rebuilt milestone roster (ec.duel_kills_total is reset
# in the DUELING block above). ach.dungeon_no_death (the deathless-clears tally) is also
# zeroed here so a wiped player starts clean — the legacy ach.* milestone counters are NOT
# swept by this file, so the new counter's reset is co-located with its sibling ec.dng_deathless.
scoreboard players set @s ec.pc_count 0
scoreboard players set @s ec.titles_count 0
scoreboard players set @s ec.nests_done 0
scoreboard players set @s ec.dng_deathless 0
scoreboard players set @s ach.dungeon_no_death 0
# 4 new lifetime milestone counters (2026-06-09): evolutions, archaeology brushes, gear awakenings,
# bestiary masteries. Monotonic +1 at their event sites; zeroed here on a full Pioneer wipe.
scoreboard players set @s ec.ce_count 0
scoreboard players set @s ec.arch_finds 0
scoreboard players set @s ec.wm_maxed 0
scoreboard players set @s ec.bst_mastered 0

# === BESTIARY (bs.*) ===
scoreboard players set @s bs.claim 0
scoreboard players set @s bs.page 0
function evercraft:chrono_shard/reset/bestiary

# === ACHIEVEMENT STAT BASELINES (ach.*) ===
scoreboard players set @s ach.base_set 0
scoreboard players set @s ach.adj_blocks_mined 0
scoreboard players set @s ach.adj_fish_caught 0
scoreboard players set @s ach.adj_kills_total 0
scoreboard players set @s ach.adj_play_ticks 0
scoreboard players set @s ach.adj_walk_cm 0
scoreboard players set @s ach.adj_deaths 0

# === MISSING PLAYER TAGS ===

# --- Blueprint ---
tag @s remove bp.previewing
tag @s remove bp.building

# --- Journal: Biomes discovered (25 explicit IDs — see biome_discovered.mcfunction) ---
tag @s remove jn.b0
tag @s remove jn.b1
tag @s remove jn.b2
tag @s remove jn.b3
tag @s remove jn.b4
tag @s remove jn.b5
tag @s remove jn.b6
tag @s remove jn.b7
tag @s remove jn.b8
tag @s remove jn.b9
tag @s remove jn.b10
tag @s remove jn.b11
tag @s remove jn.b12
tag @s remove jn.b13
tag @s remove jn.b14
tag @s remove jn.b15
tag @s remove jn.b16
tag @s remove jn.b17
tag @s remove jn.b18
tag @s remove jn.b19
tag @s remove jn.b20
tag @s remove jn.b21
tag @s remove jn.b22
tag @s remove jn.b23
tag @s remove jn.b24

# --- Journal: Villages discovered (jn.v_<vid>) — unbounded vid space, scrape via Tags iteration ---
# Snapshot the player's Tags into storage, then recursively remove any starting with "jn.v_"
data modify storage evercraft:strip taglist set from entity @s Tags
function evercraft:admin/strip_village_tags_loop
data remove storage evercraft:strip taglist
data remove storage evercraft:strip vt
data remove storage evercraft:strip vt_pfx
data remove storage evercraft:strip vtag_arg

# --- Wild Companions ---
tag @s remove wc.battling
tag @s remove wc.clicked
tag @s remove wc.following
tag @s remove wc.power_next
tag @s remove wc.target_chicken
tag @s remove wc.whistle_cd
tag @s remove wc.style_fire
tag @s remove wc.style_ice
tag @s remove wc.style_electric
tag @s remove wc.style_water
tag @s remove wc.style_poison
tag @s remove wc.style_wind
tag @s remove wc.style_physical
tag @s remove wc.style_holy
tag @s remove wc.style_earth
tag @s remove wc.style_dark

# --- Companion ---
tag @s remove companion.has_marker
tag @s remove companion.hidden
tag @s remove companion.newplayer
tag @s remove companion.weakened

# --- UI/State ---
tag @s remove am.playing
tag @s remove ct.screenshot_mode
tag @s remove dr.invited
tag @s remove dr.spectator
tag @s remove ec.bd_nearby
tag @s remove ec.codex_check
tag @s remove ec.inscr_active
tag @s remove ec.inscr_toggled
tag @s remove ec.orebag_in_menu
tag @s remove ec.orebag_mainhand
tag @s remove ec.orebag_restore
tag @s remove ec.binder_in_menu
tag @s remove ec.binder_mainhand
tag @s remove ec.binder_restore
tag @s remove ec.player
tag @s remove ec.rune_activated
tag @s remove ec.tp_saved
tag @s remove ec.bomb_landed
tag @s remove ec.caff_s7
tag @s remove ec.pet_milestone100
tag @s remove ec.pf_merchant
tag @s remove pioneer.choosing
tag @s remove sm.completing
tag @s remove sp.invited
tag @s remove sp.spectating
tag @s remove hs.in_protected

# === HIDE ALL BOSSBARS FROM PLAYER ===
# (bossbar player lists are set-based; setting to empty or re-assigning is handled
#  by each system's own cleanup. Setting visible=false hides for everyone, so instead
#  we just ensure the player's own systems are in idle state — the score resets above
#  already accomplish this. The systems themselves gate bossbar display on active scores.)

# === REMOVE NON-LUCK ATTRIBUTE MODIFIERS ===
attribute @s max_health modifier remove evercraft:biome_mastery_perk
attribute @s movement_speed modifier remove evercraft:biome_mastery_perk
attribute @s attack_speed modifier remove evercraft:biome_mastery_perk
attribute @s armor modifier remove evercraft:biome_mastery_perk
attribute @s attack_damage modifier remove evercraft:biome_mastery_perk
attribute @s knockback_resistance modifier remove evercraft:biome_mastery_perk

# === RESET GAMEMODE + KILL OWNED ENTITIES ===
gamemode survival @s

# Companion + blueprint marker kills MOVED to the pre-nuke block at the top of
# this file (companion.marker via predicate=evercraft:companions/check_id requires
# @s companion.id to still be live before the nuclear reset zeroes it).
# Companion ore marker — distance-anchored, no player-id dependency
execute at @s run kill @e[type=armor_stand,tag=companion.oremarker,distance=..64]

# === FEEDBACK ===
tellraw @s [{text:"[Admin] ",color:"dark_red"},{text:"Your progression has been FULLY reset to zero. All scoreboards, tags, inventory, advancements, effects, teams, and XP cleared.",color:"red",bold:true}]
tellraw @a [{text:"[Admin] ",color:"dark_red"},{selector:"@s"},{text:" has been completely reset.",color:"gray"}]
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.wither.death master @s ~ ~ ~ 0.3 1.5
