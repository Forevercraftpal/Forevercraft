# Admin — Nuclear Wipe: Companions
# Removes ALL companion data for the executing player
# Usage: /function evercraft:admin/wipe_companions

# Kill active companion entities
scoreboard players operation #Search companion.id = @s companion.id
# R1: full teardown via the shared helper (was missing the hp_label passenger + wolf kills).
function evercraft:companions/health/despawn_active_entities

# Wipe the Pets[] array on the player's marker
execute as @e[type=marker,tag=companion.marker,predicate=evercraft:companions/check_id,limit=1] run data modify entity @s data.Pets set value []
execute as @e[type=marker,tag=companion.marker,predicate=evercraft:companions/check_id,limit=1] run data modify entity @s data.HomePets set value []

# Clear all companion tags
tag @s remove companion.activepet
tag @s remove companion.weakened
tag @s remove companion.has_whistle
tag @s remove companion.inmenuv2
tag @s remove companion.hidden

# Clear evolution tags
function evercraft:companion_evolution/on_unsummon

# Reset scoreboards
scoreboard players set @s companion.hp 0
scoreboard players set @s companion.maxhp 0
scoreboard players set @s companion.kills 0
scoreboard players set @s companion.rp 0
scoreboard players set @s companion.rellevel 0
scoreboard players set @s companion.feedcd 0
scoreboard players set @s companion.interactcd 0
scoreboard players reset @s companion.activeslot
scoreboard players set @s companion.count 0
# Companion Overhaul per-player session scoreboards (DATA-MODEL §2.2 — wipe must zero the same set as
# strip_player_zero). Per-instance NBT (slots/bond_skills/happiness) is cleared by the data.Pets nuke
# at line 11; these are the player-side mirrors.
# --- SP1 / KEYSTONE horn state ---
scoreboard players set @s companion.horncd 0
scoreboard players set @s companion.stance 0
scoreboard players set @s companion.skillslot 0
scoreboard players set @s companion.slots 0
scoreboard players set @s companion.flaghits 0
# --- SP2 bond & care state ---
scoreboard players set @s companion.happiness 0
scoreboard players set @s companion.happydays 0
scoreboard players set @s companion.happypass 0
scoreboard players set @s companion.bondskills 0
# --- SP3 abandonment & win-back state (per-instance `departed` flag cleared by the data.Pets nuke at
# :11; these are the per-player session mirrors — DATA-MODEL §2.2). ---
scoreboard players set @s companion.neglect 0
scoreboard players set @s companion.wb_slot 0
scoreboard players set @s companion.wb_timer 0
tag @s remove companion.wb_pending
# --- SP4 sub-companions & journeys state (Companion Overhaul Wave 3b) ---
# Per-instance NBT cleared by the data.Pets nuke at :11; these are the per-player session mirrors
# (DATA-MODEL §2.2 — wipe zeroes the same set as strip_player_zero).
scoreboard players set @s companion.subA_slot 0
scoreboard players set @s companion.subB_slot 0
scoreboard players set @s companion.jrny_cnt 0
scoreboard players set @s companion.jA_end 0
scoreboard players set @s companion.jB_end 0
scoreboard players set @s companion.jA_type 0
scoreboard players set @s companion.jB_type 0
scoreboard players set @s companion.jA_tier 0
scoreboard players set @s companion.jB_tier 0
scoreboard players set @s companion.jA_slot 0
scoreboard players set @s companion.jB_slot 0
scoreboard players set @s companion.sub_gift 0
scoreboard players set @s companion.sub_turn 0
scoreboard players set @s ec.journey_type 0
# --- SP9 house/guild placed-pet Hearth Comfort (Companion Overhaul Plan Two) ---
# Cached comfort scores; the effect is short-refresh and lapses on its own. Wipe zeroes the same set as
# strip_player_zero (DATA-MODEL §2.2). This player's placed pets are gone after the Pets[]/HomePets[] nuke
# above, so the next in-zone apply recomputes these to 0 anyway — explicit for contract clarity.
scoreboard players set @s companion.hcomfort 0
scoreboard players set @s companion.gcomfort 0
# --- SP6 pet-duel state (Companion Overhaul Wave 5a) ---
scoreboard players set @s ec.pd_active 0
scoreboard players set @s ec.pd_inv 0
scoreboard players set @s ec.pd_cd 0
scoreboard players set @s ec.pd_hp 0
scoreboard players set @s ec.pd_atk 0
scoreboard players set @s ec.pd_hpmax 0
scoreboard players set @s ec.pd_tier 0
scoreboard players set @s ec.pd_slots 0
scoreboard players set @s ec.pd_role 0
scoreboard players set @s ec.pd_shield 0
scoreboard players set @s ec.pd_stun 0
scoreboard players set @s ec.pd_dodge 0
scoreboard players set @s ec.pd_castclk 0
scoreboard players set @s ec.pd_castidx 0
scoreboard players set @s ec.pd_pdmg 0
# --- SP7 ascension (dupes→slots) + SP8 Wayfarer Track + chips (Companion Overhaul Wave 5b) ---
# Per-instance NBT (horn_slots / chip_slots) cleared by the data.Pets nuke at :11; these are the
# per-player Track + GUI session mirrors that must reset on a wipe (DATA-MODEL §2.2).
scoreboard players set @s ec.wf_xp 0
scoreboard players set @s ec.wf_node 0
advancement revoke @s from evercraft:companions/track/claimed/root
scoreboard players set @s ec.wf_baseline 0
scoreboard players set @s ec.wf_season 0
scoreboard players set @s companion.wf_page 0
scoreboard players set @s companion.wf_clicknode 0
# Clear the SP5-facing 3-slot loadout storage so a wiped player renders no heads.
data modify storage evercraft:companions three.main set value -1
data modify storage evercraft:companions three.sub set value [0,0]
# R3 note: companion.id is INTENTIONALLY preserved here. This wipe empties Pets[]/HomePets[]
# but leaves the marker (still id-stamped) paired to the player by the same id, so the player
# keeps a consistent, unique id space. (Only the full strip_player_zero resets id -> 0 sentinel.)

# Hide any boss bars
bossbar set evercraft:companion_health visible false

# Confirm
tellraw @s [{text:"[",color:"dark_gray"},{text:"Admin",color:"red"},{text:"] ",color:"dark_gray"},{text:"All companion data wiped!",color:"yellow"}]
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.wither.death master @s ~ ~ ~ 0.3 2.0
