# Dungeon Key — Give to player (admin/test)
loot give @s loot evercraft:dungeon/key
tellraw @s [{text:"[Dungeon] ",color:"dark_purple"},{text:"Received a Dungeon Key! Right-click to start a dungeon challenge.",color:"light_purple"}]
