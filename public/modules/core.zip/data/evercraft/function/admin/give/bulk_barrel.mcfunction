# Run as operator — give the Baúl block-item for testing.
# Places-anywhere crafted storage block: stores up to 9,999 of one
# item type. Craft: 4 barrels (plus) + 1 oak_shelf (center).
loot give @s loot evercraft:bulk_barrel/item
tellraw @s [{text:"[Admin] ",color:"gray"},{text:"Ba\u00fal",color:"gold"},{text:" given — place it, then right-click to deposit / sneak-right-click to withdraw.",color:"gray"}]
