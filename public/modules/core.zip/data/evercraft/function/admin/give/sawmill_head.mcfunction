# Run as operator — preview the Sawmill custom block texture.
# Gives the custom player-head used by the Sawmill block display (decor/sawmill/build).
# Skin minted via MineSkin 2026-06-21; designed in _council/2026-06-21-sawmill-skin/
# (gen_sawmill_skin.py -> sawmill_default.png + 8 dye variants). CANONICAL home of the default
# value; decor/sawmill/build summons it, dye_block swaps the 8 colour variants.
# Preview in-game: /function evercraft:admin/give/sawmill_head
give @s minecraft:player_head[minecraft:custom_name={text:"Sawmill",color:"#C8CED9",italic:false},minecraft:profile={id:[I;-1974477980,147736616,-1635819972,23806684],properties:[{name:"textures",value:"ewogICJ0aW1lc3RhbXAiIDogMTc4MjA1NDM1ODU1MCwKICAicHJvZmlsZUlkIiA6ICI2NGRiNmMwNTliOTk0OTM2YTY0M2QwODEwODE0ZmJkMyIsCiAgInByb2ZpbGVOYW1lIiA6ICJUaGVTaWx2ZXJEcmVhbXMiLAogICJzaWduYXR1cmVSZXF1aXJlZCIgOiB0cnVlLAogICJ0ZXh0dXJlcyIgOiB7CiAgICAiU0tJTiIgOiB7CiAgICAgICJ1cmwiIDogImh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvYWE5NTU1N2NiYjQ2ODNjYTE3MjQwYzUzMWQ1ZGVlOWQ2MTliNDgxMmY1OWYwOTc2OWE0N2E1NmU5MTcxM2JlZSIsCiAgICAgICJtZXRhZGF0YSIgOiB7CiAgICAgICAgIm1vZGVsIiA6ICJzbGltIgogICAgICB9CiAgICB9CiAgfQp9"}]}] 1
tellraw @s [{text:"[Admin] ",color:"gray"},{text:"Sawmill",color:"#C8CED9"},{text:" head given — place or hold it to preview the texture.",color:"gray"}]
