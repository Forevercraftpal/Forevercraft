# === ADMIN GIVE — ETERNAL CODEX ===
# Relocated from ecodex/give.mcfunction by Council #7 (2026-05-27)
# Give the Eternal Codex item to the executing player
loot give @s loot evercraft:ecodex/eternal_codex
