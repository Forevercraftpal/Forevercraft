# Blueprint T3 — Give to player (admin/test)
# Run as operator
# Usage: /function evercraft:admin/give/blueprint_t3
loot give @s loot evercraft:blueprints/t3_paper
tellraw @s [{text:"[Admin] ",color:"yellow"},{text:"Granted T3 Blueprint",color:"gray"}]
