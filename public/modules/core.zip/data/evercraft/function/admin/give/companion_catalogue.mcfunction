# Give the new book-based Companion Catalogue to the player
# Run: /function evercraft:admin/give/companion_catalogue
loot give @s loot evercraft:companions/menu
