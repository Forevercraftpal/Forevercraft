# Blueprint T6 — Give to player (admin/test)
# Run as operator
# Usage: /function evercraft:admin/give/blueprint_t6
loot give @s loot evercraft:blueprints/t6_paper
tellraw @s [{text:"[Admin] ",color:"yellow"},{text:"Granted T6 Blueprint",color:"gray"}]
