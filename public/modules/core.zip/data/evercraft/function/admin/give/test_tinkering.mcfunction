# === ADMIN (testing) — spawn 3 barrels of ALL 56 Tinkerer combinable/final-form accessories ===
# Run as operator, AT the player. Places barrels 1/2/3 blocks EAST of you, then fills them from
# the evercraft:tinkering/* loot tables so you can smoke-test each accessory's function.
# Usage: /function evercraft:admin/give/test_tinkering   (clears+replaces blocks at ~1..~3 ~ ~)

# --- Barrel 1: Tinkering A (1–27) ---
setblock ~1 ~ ~ minecraft:barrel{CustomName:{text:"Tinkering A (1–27)",color:"#FFAA00",bold:true}}
loot replace block ~1 ~ ~ container.0 loot evercraft:tinkering/aegis_half
loot replace block ~1 ~ ~ container.1 loot evercraft:tinkering/alchemists_magnum_opus
loot replace block ~1 ~ ~ container.2 loot evercraft:tinkering/ascendant_line
loot replace block ~1 ~ ~ container.3 loot evercraft:tinkering/astral_core
loot replace block ~1 ~ ~ container.4 loot evercraft:tinkering/astral_half
loot replace block ~1 ~ ~ container.5 loot evercraft:tinkering/aura_ward
loot replace block ~1 ~ ~ container.6 loot evercraft:tinkering/bulwark_stone
loot replace block ~1 ~ ~ container.7 loot evercraft:tinkering/catalyst_of_the_bounty
loot replace block ~1 ~ ~ container.8 loot evercraft:tinkering/cornucopia_tide
loot replace block ~1 ~ ~ container.9 loot evercraft:tinkering/craft_luck_sigil
loot replace block ~1 ~ ~ container.10 loot evercraft:tinkering/crate_pair
loot replace block ~1 ~ ~ container.11 loot evercraft:tinkering/crucible_line
loot replace block ~1 ~ ~ container.12 loot evercraft:tinkering/deepdig_line
loot replace block ~1 ~ ~ container.13 loot evercraft:tinkering/demiurges_capstone
loot replace block ~1 ~ ~ container.14 loot evercraft:tinkering/dock_pair
loot replace block ~1 ~ ~ container.15 loot evercraft:tinkering/dragonheart
loot replace block ~1 ~ ~ container.16 loot evercraft:tinkering/dream_lens
loot replace block ~1 ~ ~ container.17 loot evercraft:tinkering/dreamers_reliquary
loot replace block ~1 ~ ~ container.18 loot evercraft:tinkering/far_sight_lens
loot replace block ~1 ~ ~ container.19 loot evercraft:tinkering/forge_resolve
loot replace block ~1 ~ ~ container.20 loot evercraft:tinkering/fortune_coffer
loot replace block ~1 ~ ~ container.21 loot evercraft:tinkering/gemband
loot replace block ~1 ~ ~ container.22 loot evercraft:tinkering/grand_totem
loot replace block ~1 ~ ~ container.23 loot evercraft:tinkering/grandforge_regalia
loot replace block ~1 ~ ~ container.24 loot evercraft:tinkering/hand_of_creation
loot replace block ~1 ~ ~ container.25 loot evercraft:tinkering/harvest_knot
loot replace block ~1 ~ ~ container.26 loot evercraft:tinkering/heart_of_the_mountain

# --- Barrel 2: Tinkering B (28–54) ---
setblock ~2 ~ ~ minecraft:barrel{CustomName:{text:"Tinkering B (28–54)",color:"#FFAA00",bold:true}}
loot replace block ~2 ~ ~ container.0 loot evercraft:tinkering/hearth_pair
loot replace block ~2 ~ ~ container.1 loot evercraft:tinkering/hearthkeepers_ladle
loot replace block ~2 ~ ~ container.2 loot evercraft:tinkering/lifewarden
loot replace block ~2 ~ ~ container.3 loot evercraft:tinkering/lucky_charm
loot replace block ~2 ~ ~ container.4 loot evercraft:tinkering/node_mastery
loot replace block ~2 ~ ~ container.5 loot evercraft:tinkering/oracle_lens
loot replace block ~2 ~ ~ container.6 loot evercraft:tinkering/pebble_of_creation
loot replace block ~2 ~ ~ container.7 loot evercraft:tinkering/quench_line
loot replace block ~2 ~ ~ container.8 loot evercraft:tinkering/reliquary_line
loot replace block ~2 ~ ~ container.9 loot evercraft:tinkering/smiths_apron
loot replace block ~2 ~ ~ container.10 loot evercraft:tinkering/soulguard_aegis
loot replace block ~2 ~ ~ container.11 loot evercraft:tinkering/steeping_line
loot replace block ~2 ~ ~ container.12 loot evercraft:tinkering/stride_line
loot replace block ~2 ~ ~ container.13 loot evercraft:tinkering/surveyor_line
loot replace block ~2 ~ ~ container.14 loot evercraft:tinkering/surveyors_kit
loot replace block ~2 ~ ~ container.15 loot evercraft:tinkering/sustain_vial
loot replace block ~2 ~ ~ container.16 loot evercraft:tinkering/tidewrights_net
loot replace block ~2 ~ ~ container.17 loot evercraft:tinkering/titan_bulwark
loot replace block ~2 ~ ~ container.18 loot evercraft:tinkering/titan_core
loot replace block ~2 ~ ~ container.19 loot evercraft:tinkering/trinket_knot
loot replace block ~2 ~ ~ container.20 loot evercraft:tinkering/voidband
loot replace block ~2 ~ ~ container.21 loot evercraft:tinkering/wanderers_token
loot replace block ~2 ~ ~ container.22 loot evercraft:tinkering/wardband
loot replace block ~2 ~ ~ container.23 loot evercraft:tinkering/wayfarers_lens
loot replace block ~2 ~ ~ container.24 loot evercraft:tinkering/wyrmclaw_grips
loot replace block ~2 ~ ~ container.25 loot evercraft:tinkering/wyrmheart_core
loot replace block ~2 ~ ~ container.26 loot evercraft:tinkering/wyrmscale_aegis

# --- Barrel 3: Tinkering C (55–56) ---
setblock ~3 ~ ~ minecraft:barrel{CustomName:{text:"Tinkering C (55–56)",color:"#FFAA00",bold:true}}
loot replace block ~3 ~ ~ container.0 loot evercraft:tinkering/wyrmscale_mantle
loot replace block ~3 ~ ~ container.1 loot evercraft:tinkering/wyrmwing_pinions

tellraw @s [{text:"\u2699 ","color":"#B87333"},{text:"Spawned 3 barrels (56 accessories) east of you.","color":"gray"}]
