# Blueprint T4 — Give to player (admin/test)
# Run as operator
# Usage: /function evercraft:admin/give/blueprint_t4
loot give @s loot evercraft:blueprints/t4_paper
tellraw @s [{text:"[Admin] ",color:"yellow"},{text:"Granted T4 Blueprint",color:"gray"}]
