# Run as operator — preview the Baúl custom texture.
# Gives the custom player-head used by the Baúl block display.
# Skin minted via MineSkin 2026-05-29 (texture hash a7395abaa777...c17fb2); designed in
# _council/2026-05-29-batch2-crate-storage/ (bulk_barrel_skin.png). This is the CANONICAL
# home of the skin `value` — the Baúl block display (Feature A, pending) copies it.
give @s minecraft:player_head[minecraft:custom_name={text:"Ba\u00fal",color:"gold",italic:false},minecraft:profile={id:[I;-1974477980,147736616,-1635819972,23806684],properties:[{name:"textures",value:"ewogICJ0aW1lc3RhbXAiIDogMTc4MDU0OTkzMzgzMCwKICAicHJvZmlsZUlkIiA6ICIwZWQ2MDFlMDhjZTM0YjRkYWUxZmI4MDljZmEwNTM5NiIsCiAgInByb2ZpbGVOYW1lIiA6ICJOZWVkTW9yZUFjY291bnRzIiwKICAic2lnbmF0dXJlUmVxdWlyZWQiIDogdHJ1ZSwKICAidGV4dHVyZXMiIDogewogICAgIlNLSU4iIDogewogICAgICAidXJsIiA6ICJodHRwOi8vdGV4dHVyZXMubWluZWNyYWZ0Lm5ldC90ZXh0dXJlLzgxYWIwOTg0OGQ1MmEzYzUyZDg3NjkzM2UzOWQwNDQ5Nzc0NWJiNWFiNzNjN2EwYWY2OTM5N2JjMzY1YzgzMWEiCiAgICB9CiAgfQp9"}]}]
tellraw @s [{text:"[Admin] ",color:"gray"},{text:"Ba\u00fal",color:"gold"},{text:" head given — place it or hold it to preview the texture.",color:"gray"}]
