# Run as operator — spawn the normalized-tooltip PILOT items for examination (admin/testing).
# Usage: /function evercraft:admin/give/normalized_pilot
# Gives one of each of the 9 items rewritten to the new tooltip standard (one per item class:
# spirit weapon / combat weapon / accessory / armor / tool / potion / food / forging material /
# profession implement). Hover each to compare. Drop them in any barrel if you'd rather lay them out.
loot give @s loot evercraft:spirit/dragonheart_sword
loot give @s loot evercraft:artifacts/mythical/kratos_axe
loot give @s loot evercraft:artifacts/mythical/dream_aegis
loot give @s loot evercraft:artifacts/mythical/infernal_chestplate
loot give @s loot evercraft:artifacts/mythical/journey_pickaxe
loot give @s loot evercraft:alchemy/artifacts/rare_elixir
loot give @s loot evercraft:cooking/artifacts/ornate_epicurean
loot give @s loot evercraft:craftforever/materials/accessory_t1
loot give @s loot evercraft:alchemy/artifacts/mythical_implement
tellraw @s [{text:"[Admin] ",color:"gray"},{text:"9 normalized-tooltip pilot items given",color:"gold"},{text:" — hover each to examine the new standard (spirit weapon · weapon · accessory · armor · tool · potion · food · material · implement).",color:"gray"}]
