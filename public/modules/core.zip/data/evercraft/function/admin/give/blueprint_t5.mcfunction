# Blueprint T5 — Give to player (admin/test)
# Run as operator
# Usage: /function evercraft:admin/give/blueprint_t5
loot give @s loot evercraft:blueprints/t5_paper
tellraw @s [{text:"[Admin] ",color:"yellow"},{text:"Granted T5 Blueprint",color:"gray"}]
