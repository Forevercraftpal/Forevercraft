# Blueprint T2 — Give to player (admin/test)
# Run as operator
# Usage: /function evercraft:admin/give/blueprint_t2
loot give @s loot evercraft:blueprints/t2_paper
tellraw @s [{text:"[Admin] ",color:"yellow"},{text:"Granted T2 Blueprint",color:"gray"}]
