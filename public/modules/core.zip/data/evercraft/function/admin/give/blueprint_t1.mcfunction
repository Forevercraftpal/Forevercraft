# Blueprint T1 — Give to player (admin/test)
# Run as operator
# Usage: /function evercraft:admin/give/blueprint_t1
loot give @s loot evercraft:blueprints/t1_paper
tellraw @s [{text:"[Admin] ",color:"yellow"},{text:"Granted T1 Blueprint",color:"gray"}]
