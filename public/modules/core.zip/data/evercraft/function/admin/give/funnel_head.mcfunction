# Run as operator — preview the Fusion Funnel custom block texture.
# Gives the custom player-head used by the Fusion Funnel (alchemy station) block display.
# Skin minted via MineSkin 2026-06-03; designed in _council/2026-06-03-fusion-funnel-skin/
# (funnel_skin.png + gen_funnel_skin.py). This is the CANONICAL home of the skin `value` —
# craftforever/alchemy/station/on_place embeds the same value inline in its block display
# (it replaced the OMF_BlockBuster "Artisan Forge" placeholder).
# Preview in-game: /function evercraft:admin/give/funnel_head
give @s minecraft:player_head[minecraft:custom_name={text:"Fusion Funnel",color:"#55DDFF",italic:false},minecraft:profile={id:[I;-1974477980,147736616,-1635819972,23806684],properties:[{name:"textures",value:"ewogICJ0aW1lc3RhbXAiIDogMTc4MDUzNTY0MDA5NCwKICAicHJvZmlsZUlkIiA6ICI3NjFjOTZhOTgzNzc0ODUwODc4ZjgwYWY4MzIyMzgxZSIsCiAgInByb2ZpbGVOYW1lIiA6ICJzcGlmZnRvcGlhOCIsCiAgInNpZ25hdHVyZVJlcXVpcmVkIiA6IHRydWUsCiAgInRleHR1cmVzIiA6IHsKICAgICJTS0lOIiA6IHsKICAgICAgInVybCIgOiAiaHR0cDovL3RleHR1cmVzLm1pbmVjcmFmdC5uZXQvdGV4dHVyZS9mNmQ1N2M3ZjIxZTA2MTEwMzUxZjc1OGNhZDM1YzY1OWUzN2RhNjk2OTQwZjFmNmJjNjZlNmY3ZTE0YmZmOTkxIgogICAgfQogIH0KfQ=="}]}] 1
tellraw @s [{text:"[Admin] ",color:"gray"},{text:"Fusion Funnel",color:"#55DDFF"},{text:" head given — place or hold it to preview the texture.",color:"gray"}]
