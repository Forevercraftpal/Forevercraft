# Run as operator — spawn all 21 cook_art reagents to test the forge craft-path (admin/testing).
# Usage: /function evercraft:admin/give/cook_reagents  — then right-click any reagent to forge its artifact.
loot give @s loot evercraft:cooking/artifacts/materials/catalyst_t1
loot give @s loot evercraft:cooking/artifacts/materials/catalyst_t2
loot give @s loot evercraft:cooking/artifacts/materials/catalyst_t3
loot give @s loot evercraft:cooking/artifacts/materials/catalyst_t4
loot give @s loot evercraft:cooking/artifacts/materials/catalyst_t5
loot give @s loot evercraft:cooking/artifacts/materials/catalyst_t6
loot give @s loot evercraft:cooking/artifacts/materials/catalyst_t7
loot give @s loot evercraft:cooking/artifacts/materials/epicurean_t1
loot give @s loot evercraft:cooking/artifacts/materials/epicurean_t2
loot give @s loot evercraft:cooking/artifacts/materials/epicurean_t3
loot give @s loot evercraft:cooking/artifacts/materials/epicurean_t4
loot give @s loot evercraft:cooking/artifacts/materials/epicurean_t5
loot give @s loot evercraft:cooking/artifacts/materials/epicurean_t6
loot give @s loot evercraft:cooking/artifacts/materials/epicurean_t7
loot give @s loot evercraft:cooking/artifacts/materials/relic_t1
loot give @s loot evercraft:cooking/artifacts/materials/relic_t2
loot give @s loot evercraft:cooking/artifacts/materials/relic_t3
loot give @s loot evercraft:cooking/artifacts/materials/relic_t4
loot give @s loot evercraft:cooking/artifacts/materials/relic_t5
loot give @s loot evercraft:cooking/artifacts/materials/relic_t6
loot give @s loot evercraft:cooking/artifacts/materials/relic_t7
tellraw @s [{text:"[Admin] ",color:"gray"},{text:"21 cook_art reagents given",color:"#FFCC88"},{text:" — right-click any to forge its cooking artifact.",color:"gray"}]
