# Run as operator — preview the Tinkerer's Plinth custom block texture.
# Gives the custom player-head used by the Plinth block display (tinkering/plinth/spawn_display).
# Skin minted via MineSkin 2026-06-03; designed in _council/2026-06-03-tinkerer-plinth-skin/
# (plinth_skin.png + gen_plinth_skin.py). This is the CANONICAL home of the skin `value` —
# tinkering/plinth/on_place copies the same value into evercraft:tnk_plinth temp_skin.
# Preview in-game: /function evercraft:admin/give/plinth_head
give @s minecraft:player_head[minecraft:custom_name={text:"Tinkerer's Plinth",color:"#5EC8D8",italic:false},minecraft:profile={id:[I;-1974477980,147736616,-1635819972,23806684],properties:[{name:"textures",value:"ewogICJ0aW1lc3RhbXAiIDogMTc4MDUzNTU5NjMzMywKICAicHJvZmlsZUlkIiA6ICI4OGMyOGYwOTY3MjU0NmNkYTg3ZjVhMTc0ODU0MzExYiIsCiAgInByb2ZpbGVOYW1lIiA6ICJOaXRlQ2F2ZSIsCiAgInNpZ25hdHVyZVJlcXVpcmVkIiA6IHRydWUsCiAgInRleHR1cmVzIiA6IHsKICAgICJTS0lOIiA6IHsKICAgICAgInVybCIgOiAiaHR0cDovL3RleHR1cmVzLm1pbmVjcmFmdC5uZXQvdGV4dHVyZS9lOTY3Y2FlYTQ0MGY0MTQwNzIxNTViNmQwOGY2ZjVjMWZmNGUzMDZhNmZlZGFkNmRiYTg0MzFlY2FhMGQyMjE2IgogICAgfQogIH0KfQ=="}]}] 1
tellraw @s [{text:"[Admin] ",color:"gray"},{text:"Tinkerer's Plinth",color:"#5EC8D8"},{text:" head given — place or hold it to preview the texture.",color:"gray"}]
