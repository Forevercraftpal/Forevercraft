# Blueprint T7 — Give to player (admin/test)
# Run as operator
# Usage: /function evercraft:admin/give/blueprint_t7
loot give @s loot evercraft:blueprints/t7_paper
tellraw @s [{text:"[Admin] ",color:"yellow"},{text:"Granted T7 Blueprint",color:"gray"}]
