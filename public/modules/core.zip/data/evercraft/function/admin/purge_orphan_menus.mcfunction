# ══════════════════════════════════════════════════════════════
# Admin (debug): PURGE ORPHANED MENU "WINDOWS" — one-time legacy sweep
# Usage: /function evercraft:admin/purge_orphan_menus   (run as operator, ideally NOT standing in a menu)
# Run as: @s = the operator. Clears menu panels left stranded by OLD code — opened before a given
# menu started session-stamping its panels, so the live reapers (cleanup/gui_auto, gui_orphan_far via
# session score) never recognized them. This keys off the per-menu ELEMENT TAGS instead, which every
# panel carries from summon regardless of session, so it finds the legacy stragglers.
#
# SAFE: every kill is guarded by "no player within 10 blocks" + tag=!smithed.entity, so a LIVE menu
# (its owner is right there) and custom-block overlays are never touched. Repeatable + idempotent —
# re-run until the reported count is 0. Other online players' open menus are protected by the guard.
# Does NOT touch rd.vote_panel (a shared raid object with its own despawn lifecycle).
# ══════════════════════════════════════════════════════════════

# --- IDENTIFY: count orphaned menu buttons (interaction entities are menu-exclusive — a good proxy
#     for "# of stranded windows") with no player within 10 blocks. ---
scoreboard players set #omc_before ec.temp 0
execute as @e[type=interaction] at @s unless entity @a[distance=..10] run scoreboard players add #omc_before ec.temp 1
tellraw @s [{text:"[Orphan-Menu Purge] ",color:"#B87333"},{text:"Found ",color:"gray"},{score:{name:"#omc_before",objective:"ec.temp"},color:"yellow"},{text:" orphaned menu button(s) with no player nearby. Purging session-stamped + element-tagged panels…",color:"gray"}]

# --- GET RID OF: run the shared far-orphan sweep (session-score scans + per-menu element-tag kills).
#     Same kill set the 5s reaper uses, but invoked on demand so the backlog clears immediately. ---
function evercraft:cleanup/gui_orphan_far

# --- VERIFY: re-count. The delta is what we cleared; any remainder is near a player or non-menu. ---
scoreboard players set #omc_after ec.temp 0
execute as @e[type=interaction] at @s unless entity @a[distance=..10] run scoreboard players add #omc_after ec.temp 1
tellraw @s [{text:"[Orphan-Menu Purge] ",color:"#B87333"},{text:"Done. ",color:"gray"},{score:{name:"#omc_after",objective:"ec.temp"},color:"yellow"},{text:" orphan button(s) remain (near a player or non-menu). Re-run after stepping away if any persist.",color:"gray"}]
