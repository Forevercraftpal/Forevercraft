# Strip — Remove a single village tag (macro)
# Called per-tag from strip_village_tags_loop after prefix filter passes
$tag @s remove $(vtag)
