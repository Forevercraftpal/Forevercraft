# Usage: /execute as <player> run function evercraft:admin/lore_rework/unlock_all   (admin/testing)
# Fast-forwards the lore-glowie rework unlocks for the executing player so all
# three features can be tested immediately:
#   - Auto-Convert unlocked + toggle ON
#   - Loreroll unlocked (toast granted)
#   - Black Market "Fence Lore" tab available
#   - +10 Lore Shards and a netherite-scrap head-start banked

scoreboard players set @s ec.lore_ex_total 10
scoreboard players set @s ec.lore_ac_open 1
scoreboard players set @s ec.lore_autoconv 1
scoreboard players set @s ec.lore_ac_count 50
scoreboard players set @s ec.loreroll 1
advancement grant @s only evercraft:lore/loreroll

# A few shards to play with
give @s minecraft:echo_shard[minecraft:custom_name={text:"Lore Shard",color:"yellow",italic:false},minecraft:enchantment_glint_override=true,minecraft:custom_data={lore_shard:true}] 10

tellraw @s [{text:"[admin] ",color:"red"},{text:"Lore-rework unlocks granted (auto-convert ON, loreroll ON, black-market lore tab open).",color:"gray"}]
