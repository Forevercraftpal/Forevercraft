# Usage: /execute as <player> run function evercraft:admin/lore_rework/reset   (admin/testing)
# Resets the executing player's lore-glowie rework state back to locked/zero
# and clears their banked black-market lore points. Does NOT touch collected lore.

scoreboard players set @s ec.lore_ex_total 0
scoreboard players set @s ec.lore_ac_open 0
scoreboard players set @s ec.lore_autoconv 0
scoreboard players set @s ec.lore_ac_count 0
scoreboard players set @s ec.loreroll 0
scoreboard players set @s ec.bm_lore_pts 0
advancement revoke @s only evercraft:lore/loreroll

# Clear persisted black-market lore points for this player
execute store result storage evercraft:database black_market.ls_temp.u0 int 1 run data get entity @s UUID[0]
execute store result storage evercraft:database black_market.ls_temp.u1 int 1 run data get entity @s UUID[1]
execute store result storage evercraft:database black_market.ls_temp.u2 int 1 run data get entity @s UUID[2]
execute store result storage evercraft:database black_market.ls_temp.u3 int 1 run data get entity @s UUID[3]
function evercraft:admin/lore_rework/reset_storage with storage evercraft:database black_market.ls_temp

tellraw @s [{text:"[admin] ",color:"red"},{text:"Lore-rework state reset to locked.",color:"gray"}]
