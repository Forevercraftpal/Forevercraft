# Usage: /execute as <player> run function evercraft:admin/lore_rework/status   (admin/debug)
# Prints the executing player's lore-glowie rework counters.

tellraw @s [{text:"=== Lore Rework status ===",color:"gold",bold:true}]
tellraw @s [{text:"Exchanged total (>=10 unlocks auto-convert): ",color:"gray"},{score:{name:"@s",objective:"ec.lore_ex_total"},color:"yellow"}]
tellraw @s [{text:"Auto-convert unlocked: ",color:"gray"},{score:{name:"@s",objective:"ec.lore_ac_open"},color:"yellow"},{text:"  toggle: ",color:"gray"},{score:{name:"@s",objective:"ec.lore_autoconv"},color:"yellow"}]
tellraw @s [{text:"Auto-converts (>=50 unlocks loreroll): ",color:"gray"},{score:{name:"@s",objective:"ec.lore_ac_count"},color:"yellow"}]
tellraw @s [{text:"Loreroll unlocked: ",color:"gray"},{score:{name:"@s",objective:"ec.loreroll"},color:"yellow"}]
tellraw @s [{text:"Black-market lore points banked: ",color:"gray"},{score:{name:"@s",objective:"ec.bm_lore_pts"},color:"yellow"}]
