# Usage: internal helper for evercraft:admin/lore_rework/reset   (admin/testing)
# {u0,u1,u2,u3} — wipe this player's persisted black-market lore points
$data remove storage evercraft:database black_market.lore_sale.u$(u0)_$(u1)_$(u2)_$(u3)
