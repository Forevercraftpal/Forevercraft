# Tomb System — carrier died while carrying a soul (run as the dying carrier)
# Remove the bundle so it can't enter the carrier's own grave, revert the carried
# marker to a normal collectible grave at its CURRENT position (it follows the
# carrier, so it dies nearby), and tell both parties.
clear @s bundle[custom_data~{soul_bundle:1b}]
execute store result score #tomb_carry_id ec.temp run scoreboard players get @s ec.tomb_carry
tag @s remove ec.tomb_carrier
execute as @e[type=marker,tag=ec.tomb_data,tag=ec.tomb_bundled] if score @s ec.tomb_id = #tomb_carry_id ec.temp run tag @s remove ec.tomb_bundled
# Restore the rescue interaction at the reverted marker (the original was killed at
# accept; particles + actionbar already re-mark the spot via tick_marker).
execute as @e[type=marker,tag=ec.tomb_data] if score @s ec.tomb_id = #tomb_carry_id ec.temp at @s run summon interaction ~ ~0.4 ~ {Tags:["ec.tomb","ec.tomb_interact","ec.tomb_redo"],width:0.8f,height:1.2f,response:1b}
execute as @e[type=marker,tag=ec.tomb_data] if score @s ec.tomb_id = #tomb_carry_id ec.temp run scoreboard players operation @e[type=interaction,tag=ec.tomb_redo,limit=1] ec.tomb_id = @s ec.tomb_id
execute as @e[type=marker,tag=ec.tomb_data] if score @s ec.tomb_id = #tomb_carry_id ec.temp run scoreboard players operation @e[type=interaction,tag=ec.tomb_redo,limit=1] ec.tomb_uuid0 = @s ec.tomb_uuid0
execute as @e[type=marker,tag=ec.tomb_data] if score @s ec.tomb_id = #tomb_carry_id ec.temp run scoreboard players operation @e[type=interaction,tag=ec.tomb_redo,limit=1] ec.tomb_uuid1 = @s ec.tomb_uuid1
execute as @e[type=marker,tag=ec.tomb_data] if score @s ec.tomb_id = #tomb_carry_id ec.temp run scoreboard players operation @e[type=interaction,tag=ec.tomb_redo,limit=1] ec.tomb_uuid2 = @s ec.tomb_uuid2
execute as @e[type=marker,tag=ec.tomb_data] if score @s ec.tomb_id = #tomb_carry_id ec.temp run scoreboard players operation @e[type=interaction,tag=ec.tomb_redo,limit=1] ec.tomb_uuid3 = @s ec.tomb_uuid3
tag @e[type=interaction,tag=ec.tomb_redo] remove ec.tomb_redo
data modify storage evercraft:notify stage.c set value [{text:"The soul you carried slips free — its grave reforms where you fell.",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 50
function evercraft:util/notify/emit
