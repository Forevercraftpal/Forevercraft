# Tomb System — Notify Finder of Reward (macro)
# @s = finder
# $(delivery_xp) = XP levels awarded

$data modify storage evercraft:notify stage.c set value [{text:"⚔ ",color:"gold"},{text:"You have returned a fallen soul. +",color:"gold"},{text:"$(delivery_xp)",color:"green"},{text:" levels as gratitude. ⚔",color:"gold"}]
scoreboard players set #ndur ec.temp 50
function evercraft:util/notify/emit
