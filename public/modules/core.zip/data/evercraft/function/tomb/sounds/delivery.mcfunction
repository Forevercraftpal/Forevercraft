# Tomb System — Bundle Delivery Sounds (items restored to owner)
# Triumphant but grateful
playsound minecraft:block.beacon.activate ambient @a[distance=..16,scores={ec.fx_snd=1..}] ~ ~ ~ 0.5 1.0
playsound minecraft:block.amethyst_block.chime ambient @a[distance=..16,scores={ec.fx_snd=1..}] ~ ~ ~ 0.5 1.2
# Warm low C-G harp dyad — gentle relief, not a fanfare (FX pass 2, 2026-06-09; was generic levelup).
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.harp ambient @s ~ ~ ~ 0.4 0.707
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.harp ambient @s ~ ~ ~ 0.3 1.059
