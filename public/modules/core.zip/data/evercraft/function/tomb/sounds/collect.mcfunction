# Tomb System — Collection Sounds (soul reclaimed)
# Sword pulled from the ground
playsound minecraft:block.anvil.use ambient @a[distance=..24,scores={ec.fx_snd=1..}] ~ ~ ~ 0.3 1.2
# Soul energy releasing
playsound minecraft:block.beacon.activate ambient @a[distance=..24,scores={ec.fx_snd=1..}] ~ ~ ~ 0.5 1.0
playsound minecraft:block.beacon.power_select ambient @a[distance=..24,scores={ec.fx_snd=1..}] ~ ~ ~ 0.4 1.2
# Crystalline chimes
playsound minecraft:block.amethyst_block.chime ambient @a[distance=..16,scores={ec.fx_snd=1..}] ~ ~ ~ 0.5 1.0
playsound minecraft:block.amethyst_block.chime ambient @a[distance=..16,scores={ec.fx_snd=1..}] ~ ~ ~ 0.4 1.4
# Confirmation
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.player.levelup ambient @s ~ ~ ~ 0.3 0.8
