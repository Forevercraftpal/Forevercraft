# Salvation Stone — Auto-collect tomb (non-Pioneer)
# No tomb spawns, no XP loss, items stay in inventory.
# keepInventory is already ON so everything is safe.

# Consume one charge
scoreboard players remove @s ec.salvation 1

# === ANNOUNCEMENT ===
title @s times 10 60 20
title @s title {text:"SALVATION",color:gold}
title @s subtitle {text:"Death could not claim you.",color:gray,italic:true}

data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:gold},{text:"Your Salvation Stone absorbed the blow. No tomb spawned. No XP lost.",color:yellow},{text:" ✦",color:gold}]
scoreboard players set #ndur ec.temp 50
function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Remaining charges: ",color:gray},{score:{name:"@s",objective:"ec.salvation"},color:yellow,bold:true}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit

# Server notice — actor-named broadcast (§5b direct render in actor context)
execute as @s run function evercraft:util/notify/whoami
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:gold},{text:"",color:yellow},{text:"'s Salvation Stone pulsed with light.",color:gray,italic:true},{text:" ✦",color:gold}]
data modify storage evercraft:notify stage.c[1].text set from storage evercraft:notify named.who
scoreboard players set #ndur ec.temp 50
execute as @s run execute as @a[distance=..48] run scoreboard players set #nttl ec.temp 600
execute as @s run execute as @a[distance=..48] run function evercraft:util/notify/emit_keep

# === EFFECTS ===
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:item.totem.use master @s ~ ~ ~ 0.8 1.0
particle minecraft:totem_of_undying ~ ~1 ~ 0.3 0.5 0.3 0.15 25
particle minecraft:end_rod ~ ~1 ~ 0.2 0.8 0.2 0.02 10

# Run boss hook (for raid/dungeon death tracking)
function evercraft:party/boss/on_death
