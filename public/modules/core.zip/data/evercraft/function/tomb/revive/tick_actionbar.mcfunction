# Tomb Revive — Channel Actionbar (macro)
# @s = healer player, $(seconds) = seconds remaining

$execute unless entity @s[tag=ab_q] run title @s actionbar [{"text":"⚔ Channeling Revival... ","color":"gold"},{"text":"$(seconds)s","color":"yellow"}]
