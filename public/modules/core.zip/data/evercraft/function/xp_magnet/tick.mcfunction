# XP Magnet — pull nearby experience orbs to the player so XP "flies" in.
#
# REWRITE 2026-06-15 (Joseph: "xp fly to the player is broken — they don't move at all").
# The old design tagged each orb NoGravity (init_orb) and then nudged it from the ORB's
# perspective: `facing entity @p feet run tp @s ^ ^ ^0.6`. That caret-nudge is only proven on
# players/mobs in this pack (raid knockbacks); on experience_orb entities in 26.1 it wasn't moving
# them — and because NoGravity ALSO kills the orb's own vanilla drift toward the player, every orb
# ended up frozen in mid-air. Switched to the player-perspective entity-target teleport that EVERY
# working item/orb magnet here uses (artifacts/mythical_tools, craftforever/spirit_tools,
# artifacts/graviton_core): iterate as the player, snap nearby orbs straight onto @s. No NoGravity,
# so vanilla physics is the fallback and any legacy frozen orbs thaw the instant they're pulled in.
#
# OPT: self-schedules at 2t; two cheap existence gates (any player? any orb at all?) skip the
# per-player scan entirely on an idle server.
schedule function evercraft:xp_magnet/tick 2t

execute unless entity @a run return 0
execute unless entity @e[type=experience_orb,limit=1] run return 0

# Snap every experience orb within 8 blocks onto its nearest player (absorbed on the next tick).
# 8 = the original's effective pull radius; kept deliberately BELOW the premium magnets (journey 8 +
# items, spirit_tools 12-16, graviton 16, demiurge capstone 12) so those perks still out-reach the
# free global baseline. Per-player iteration + sort=nearest routes each orb to its closest player;
# limit caps farm spikes.
execute as @a at @s run tp @e[type=experience_orb,distance=..8,limit=64,sort=nearest] @s
