# Morning News — Dungeon Daily Challenge (macro, per-player)
$tellraw @s [{"text":"  \u2600 ","color":"gold"},{"text":"Daily Challenge: ","color":"gold","bold":true},{"text":"$(structure) $(modifier)","color":"yellow","italic":true}]
tellraw @s [{"text":"    Seek it out for ","color":"gray"},{"text":"double rewards","color":"gold","bold":true},{"text":"!","color":"gray"}]
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.7 1.2
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.5 0.8
