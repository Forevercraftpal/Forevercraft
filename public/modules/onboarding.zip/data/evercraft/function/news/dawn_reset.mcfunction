# Forevercraft News — Dawn Reset
# Copy today's counters to yesterday, then zero today

# Copy today → yesterday
scoreboard players operation #news_y_quests ec.var = #news_quests ec.var
scoreboard players operation #news_y_bosses ec.var = #news_bosses ec.var
scoreboard players operation #news_y_crates ec.var = #news_crates ec.var
scoreboard players operation #news_y_dungeons ec.var = #news_dungeons ec.var
scoreboard players operation #news_y_glyphs ec.var = #news_glyphs ec.var
scoreboard players operation #news_y_wishes ec.var = #news_wishes ec.var
scoreboard players operation #news_y_bounties ec.var = #news_bounties ec.var
scoreboard players operation #news_y_duels ec.var = #news_duels ec.var
scoreboard players operation #news_y_conflicts ec.var = #news_conflicts ec.var
scoreboard players operation #news_y_marriages ec.var = #news_marriages ec.var

# Zero today
scoreboard players set #news_quests ec.var 0
scoreboard players set #news_bosses ec.var 0
scoreboard players set #news_crates ec.var 0
scoreboard players set #news_dungeons ec.var 0
scoreboard players set #news_glyphs ec.var 0
scoreboard players set #news_wishes ec.var 0
scoreboard players set #news_bounties ec.var 0
scoreboard players set #news_duels ec.var 0
scoreboard players set #news_conflicts ec.var 0
scoreboard players set #news_marriages ec.var 0

# === WILD COMPANION DAILY RESET (Plan 3) ===
function evercraft:wild_companions/daily_reset

# === D1 (Trial Pass — broaden): every 3rd day is a Trial-Pass drop day.
# Real weekdays aren't queryable in vanilla; in-game day-mod-3 ≈ Mon/Wed/Fri cadence.
# `#cur_day ec.var` is the current world day, kept here so per-player handlers can compare.
execute store result score #cur_day ec.var run time query day
scoreboard players operation #day_mod ec.var = #cur_day ec.var
scoreboard players operation #day_mod ec.var %= #3 ec.const
scoreboard players set #tp_drop_day ec.var 0
execute if score #day_mod ec.var matches 0 run scoreboard players set #tp_drop_day ec.var 1
