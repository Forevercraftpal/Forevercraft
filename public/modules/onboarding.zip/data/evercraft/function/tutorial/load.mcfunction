# Tutorial System — Load
# Retired 2026-05-28 (Council #15): tutorial UI superseded by Story Chapter 1.
# This file kept ONLY to register ec.tutorial_done — a live story gate read by
# `story/chapter/ch2/check.mcfunction:8` and written by difficulty/choose,
# difficulty/pioneer_welcome. See `data/.archive/2026-05-28-dead-tutorial/TOMBSTONE.md`.

# === SCOREBOARDS ===
scoreboard objectives add ec.tutorial_done dummy
