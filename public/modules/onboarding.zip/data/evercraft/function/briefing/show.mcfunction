# Welcome Briefing — Unified join message (replaces old 3-section layout)
# @s = player, at @s context. Dream rate scores already computed by on_join.

# === Announce to other online players (in CHAT — join messages stay in chat, Joseph 2026-06-02) ===
# Broadcast in the joiner's (@s) context so {selector:"@s"} resolves once to the joining player.
# @a[tag=ec.joined] = everyone already online (the joiner isn't tagged ec.joined until on_join ends).
tellraw @a[tag=ec.joined] [{text:"✦ ",color:"gold"},{selector:"@s",color:"gold",bold:true},{text:" has joined Forevercraft!",color:"gold"},{text:" ✦",color:"gold"}]

# === Compute display values ===
function evercraft:briefing/get_time_name
function evercraft:briefing/get_moon_name
function evercraft:briefing/get_season_name

# === Personal briefing (joining player only) ===
tellraw @s {text:""}
tellraw @s [{text:"——————————————————————————————————",color:"dark_gray"}]

# Header: join message (multiplayer) or welcome (singleplayer)
execute if entity @a[tag=ec.joined] run tellraw @s [{text:"✦ ",color:"gold"},{selector:"@s",color:"gold",bold:true},{text:" has joined Forevercraft!",color:"gold"},{text:" ✦",color:"gold"}]
execute unless entity @a[tag=ec.joined] run tellraw @s [{text:"✦ ",color:"gold"},{text:"Welcome to Forevercraft!",color:"gold",bold:true},{text:" ✦",color:"gold"}]

# Time · Moon · Season (compact single line)
tellraw @s [{nbt:"time_name",storage:"evercraft:briefing",color:"white"},{text:" (Day ",color:"gray"},{score:{name:"#visual_day",objective:"ec.var"},color:"white"},{text:") · ",color:"gray"},{nbt:"moon_name",storage:"evercraft:briefing",color:"#B8C4E8"},{text:" · ",color:"gray"},{nbt:"season_name",storage:"evercraft:briefing",color:"#DAA520"}]

# Active Events
execute if score #cal_active ec.var matches 1 run function evercraft:briefing/show_cal_event
execute if score #ec_event_active ec.var matches 1 run tellraw @s [{text:"Dream Surge is active!",color:"#C8A2F8",italic:true}]
execute unless score #cal_active ec.var matches 1 unless score #ec_event_active ec.var matches 1 run tellraw @s [{text:"No active events.",color:"dark_gray",italic:true}]

# Dream Rate (clickable — shows full breakdown)
tellraw @s [{text:"✦ ",color:"gold",click_event:{action:run_command,command:"/trigger ec.dreams set 1"},hover_event:{action:show_text,value:{text:"Click to view breakdown",color:"yellow"}}},{text:"The rate of your dreams coming true today is ",color:"gold"},{score:{name:"@s",objective:"ec.var"},color:"gold",bold:true},{text:".",color:"gold",bold:true},{score:{name:"#dec",objective:"ec.temp"},color:"gold",bold:true},{text:" ✦",color:"gold"}]

# Craft Rate (clickable — shows full breakdown)
tellraw @s [{text:"\u2726 ",color:"dark_aqua",click_event:{action:run_command,command:"/trigger ec.craft_check set 1"},hover_event:{action:show_text,value:{text:"Click to view Craft Rate breakdown",color:"aqua"}}},{text:"Your Craft Rate today is ",color:"dark_aqua"},{score:{name:"@s",objective:"ec.craft_rate"},color:"dark_aqua",bold:true},{text:" \u2726",color:"dark_aqua"}]

# While You Were Away (conditional — only if player was away 1+ days)
function evercraft:briefing/show_missed

# Coaching tip for new players (DR < 5.0)
execute if score @s ec.var matches ..4 run function evercraft:briefing/coaching_tip

# Story Mode button (player-initiated, no auto-nag)
execute if score @s sm.mode matches 1..2 run tellraw @s [{"text":"  "},{"text":"[Story]","color":"gold","bold":true,"click_event":{"action":"run_command","command":"/function evercraft:story/notify/briefing_click"},"hover_event":{"action":"show_text","value":{"text":"Click to see your current story objective","color":"yellow"}}}]
# Paused story — gentle nudge (player must read briefing to see it)
execute if score @s sm.mode matches 3 run tellraw @s [{"text":"  "},{"text":"[Story \u2014 Paused]","color":"dark_gray","italic":true,"click_event":{"action":"run_command","command":"/function evercraft:story/mode/resume_story"},"hover_event":{"action":"show_text","value":{"text":"Click to resume your story","color":"gray"}}}]

# Footer
tellraw @s [{text:"——————————————————————————————————",color:"dark_gray"}]
tellraw @s {text:""}
