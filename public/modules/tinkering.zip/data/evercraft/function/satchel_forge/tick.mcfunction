# Satchel Forge — Ritual Tick (every 1s)
# Merge: throw all 6 Essentials Satchel tiers on a beacon (beacon is sacrificed).
# Ritual detection doesn't need 0.5s precision — 1s is fine for thrown items.

# Reschedule first (guarantees we keep ticking regardless of gate)
schedule function evercraft:satchel_forge/tick 2s

# Gate: skip logic if no players online
execute unless entity @a run return 0

# OPT: Tag-gate — only check NBT on unchecked satchel-tier item entities
# (avoids deep NBT scan on ALL items). Restrict the scan to leather + satchel custom_data.
# Perf retrofit L3 (2026-06-14): prepend the mob_crates existence pre-gate (same filter, limit=1).
execute if entity @e[type=item,tag=!ec.sf_checked,nbt={Item:{id:"minecraft:leather",components:{"minecraft:custom_data":{satchel:true}}}},limit=1] as @e[type=item,tag=!ec.sf_checked,nbt={Item:{id:"minecraft:leather",components:{"minecraft:custom_data":{satchel:true}}}},limit=10] run function evercraft:satchel_forge/check_item
