# Satchel Forge — Check single satchel-tier item entity
# OPT: Tag-gate pattern — each item only gets NBT-checked once.
tag @s add ec.sf_checked

# If this Essentials Satchel is on a beacon (or one block above), look for the
# full set of 6 tiers nearby. Runs detect_merge at the satchel's position.
execute if data entity @s Item{id:"minecraft:leather",components:{"minecraft:custom_data":{satchel:true}}} at @s if block ~ ~ ~ minecraft:beacon run function evercraft:satchel_forge/detect_merge
execute if data entity @s Item{id:"minecraft:leather",components:{"minecraft:custom_data":{satchel:true}}} at @s if block ~ ~-1 ~ minecraft:beacon run function evercraft:satchel_forge/detect_merge
