# Satchel Forge — Forge System
# Ritual: throw all 6 Essentials Satchel tiers onto a beacon to fuse them
# into a single Hero's Satchel (the beacon is sacrificed).
# Modeled on evercraft:armored_elytra.
# Schedule the tick loop on load
schedule function evercraft:satchel_forge/tick 1s replace
