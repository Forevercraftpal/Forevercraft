# Satchel Forge — Detect Merge
# Runs at the triggering Essentials Satchel item entity, which sits on/above a beacon.
# Only fuse when ALL 6 distinct tiers are present as item entities within ~2 blocks.
# A single chained execute: each "if entity" gates the next — all 6 must match
# before do_merge runs. If even one tier is missing, nothing happens and the
# items simply sit there until the set is completed.

execute if entity @e[type=item,distance=..2,nbt={Item:{id:"minecraft:leather",components:{"minecraft:custom_data":{satchel:true,satchel_tier:"common"}}}}] if entity @e[type=item,distance=..2,nbt={Item:{id:"minecraft:leather",components:{"minecraft:custom_data":{satchel:true,satchel_tier:"uncommon"}}}}] if entity @e[type=item,distance=..2,nbt={Item:{id:"minecraft:leather",components:{"minecraft:custom_data":{satchel:true,satchel_tier:"rare"}}}}] if entity @e[type=item,distance=..2,nbt={Item:{id:"minecraft:leather",components:{"minecraft:custom_data":{satchel:true,satchel_tier:"ornate"}}}}] if entity @e[type=item,distance=..2,nbt={Item:{id:"minecraft:leather",components:{"minecraft:custom_data":{satchel:true,satchel_tier:"exquisite"}}}}] if entity @e[type=item,distance=..2,nbt={Item:{id:"minecraft:leather",components:{"minecraft:custom_data":{satchel:true,satchel_tier:"mythical"}}}}] run function evercraft:satchel_forge/do_merge
