# Satchel Forge — Do Merge
# Runs at the triggering Essentials Satchel item entity, on/above a beacon.
# All 6 distinct tiers have been confirmed present within ~2 blocks.
# Consume the 6 tiers, sacrifice the beacon, and spawn one Hero's Satchel.

# Sacrifice the beacon FIRST. This also disarms any other satchel item that was
# queued in the same tick scan: with no beacon left, its check_item block-test
# fails, so the ritual can only fire once. (Matches armored_elytra beacon handling.)
execute if block ~ ~ ~ minecraft:beacon run setblock ~ ~ ~ air
execute if block ~ ~-1 ~ minecraft:beacon run setblock ~ ~-1 ~ air

# Consume the six tier items. distance=..2 with no per-tier limit removes
# duplicates too (if a player tossed two of the same tier, all copies are eaten).
kill @e[type=item,distance=..2,nbt={Item:{id:"minecraft:leather",components:{"minecraft:custom_data":{satchel:true,satchel_tier:"common"}}}}]
kill @e[type=item,distance=..2,nbt={Item:{id:"minecraft:leather",components:{"minecraft:custom_data":{satchel:true,satchel_tier:"uncommon"}}}}]
kill @e[type=item,distance=..2,nbt={Item:{id:"minecraft:leather",components:{"minecraft:custom_data":{satchel:true,satchel_tier:"rare"}}}}]
kill @e[type=item,distance=..2,nbt={Item:{id:"minecraft:leather",components:{"minecraft:custom_data":{satchel:true,satchel_tier:"ornate"}}}}]
kill @e[type=item,distance=..2,nbt={Item:{id:"minecraft:leather",components:{"minecraft:custom_data":{satchel:true,satchel_tier:"exquisite"}}}}]
kill @e[type=item,distance=..2,nbt={Item:{id:"minecraft:leather",components:{"minecraft:custom_data":{satchel:true,satchel_tier:"mythical"}}}}]

# Spawn the fused result. The loot table bakes bag_id:0, so the existing
# hero_satchel/on_open stamp-on-first-open flow assigns a real bag_id later.
loot spawn ~ ~1 ~ loot evercraft:hero_satchel/hero_satchel

# Stonestrike XP for the smith (Joseph 2026-06-11: forging = Stonestrike work).
# The fusing player is the nearest one — they had to deposit at the beacon.
execute as @p[distance=..8] run function evercraft:satchel_forge/grant_stonestrike

# Effects (sound + particle burst, runs at this position)
function evercraft:satchel_forge/effects

# Announcement — flavor uses "ancient power", never the forbidden word.
data modify storage evercraft:notify stage.c set value [{text:"The six Essentials Satchels fuse into a ",color:"gray"},{text:"Hero's Satchel",color:"light_purple",bold:true},{text:"!",color:"gray"}]
scoreboard players set #ndur ec.temp 45
execute as @a[distance=..64] run function evercraft:util/notify/emit
# (AB-1 sticky-times sweep 2026-06-10: explicit stamp — `title times` is sticky per player and this sequence set none, so it inherited whatever ran last.)
title @a[distance=..32] times 10 60 20
title @a[distance=..32] subtitle [{text:"Six tiers fused by ancient power",color:"light_purple"}]
title @a[distance=..32] title [{text:"Hero's Satchel",color:"#FF4500"}]
