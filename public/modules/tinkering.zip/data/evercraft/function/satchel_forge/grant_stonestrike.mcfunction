# Satchel Forge — Stonestrike XP for a successful fusion (run as the smith)
# Forging is hammer-and-anvil work (Joseph 2026-06-11). One chunky grant: 10 events
# x ordinary delta through the standard affinity pipeline (cap + boosts inside).
scoreboard players set @s ec.caff_class 1
scoreboard players set #caff_d ec.temp 10
scoreboard players operation #delta ec.temp = #caff_d ec.temp
scoreboard players operation #delta ec.temp *= #caff_xp3 ec.var
scoreboard players operation @s ec.caff_boost = @s ec.caffb_ss
function evercraft:craft_affinity/internal_grant
