# Satchel Forge — Ritual Effects
# Runs at the beacon position after a successful fusion. Triumphant, celebratory.

# Triumphant beacon activation
playsound minecraft:block.beacon.activate master @a[distance=..64,scores={ec.fx_snd=1..}] ~ ~ ~ 2.0 1.0
playsound minecraft:block.beacon.power_select master @a[distance=..32,scores={ec.fx_snd=1..}] ~ ~ ~ 1.5 1.2
playsound minecraft:ui.toast.challenge_complete master @a[distance=..32,scores={ec.fx_snd=1..}] ~ ~ ~ 1.0 1.0
playsound minecraft:entity.player.levelup master @a[distance=..32,scores={ec.fx_snd=1..}] ~ ~ ~ 1.0 0.9

# Particle burst — bright flash + rising rods
particle flash{color:[1.0,1.0,1.0,1.0]} ~ ~1 ~
particle end_rod ~ ~1 ~ 0.5 1.5 0.5 0.08 60
particle totem_of_undying ~ ~1 ~ 0.6 1.0 0.6 0.2 80

# Royal purple / orange transition to match the Hero's Satchel palette
particle dust_color_transition{from_color:[1.0,0.27,0.0],scale:2.5,to_color:[0.8,0.0,1.0]} ~ ~1 ~ 0.6 0.8 0.6 0.1 60
particle electric_spark ~ ~1 ~ 0.3 1.5 0.3 0.5 25
