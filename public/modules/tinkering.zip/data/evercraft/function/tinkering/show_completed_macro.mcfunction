# ============================================================
# Tinkering (universal mini-line) — Show completed (macro body)
# ============================================================
# Called `with storage evercraft:tnk_cur o`, o = the quest that was just done.
# Mirrors the C6 show_completed: green checkmark + quest title.
$data modify storage evercraft:notify stage.c set value [{text:"✔ ",color:"green"},{text:"Beat $(id) Complete — $(title)",color:"green"},{text:" ✔",color:"green"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
