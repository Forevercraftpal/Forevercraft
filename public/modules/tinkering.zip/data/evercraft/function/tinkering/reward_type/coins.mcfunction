# TNK reward — coins. @s = player. Amount in #tnk_reward_amt ec.temp.
# Adds Forever Coins (ec.coins) and tells the player. (No macro args needed; invoked
# `with storage ... o` but only reads the temp.) Clone of adventure/kingdom reward_type/coins.
scoreboard players operation @s ec.coins += #tnk_reward_amt ec.temp
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"Reward: ",color:"yellow"},{score:{name:"#tnk_reward_amt",objective:"ec.temp"},color:"gold"},{text:" Forever Coins",color:"gold"},{text:" ✦",color:"gold"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.experience_orb.pickup master @s ~ ~ ~ 0.6 1.0
