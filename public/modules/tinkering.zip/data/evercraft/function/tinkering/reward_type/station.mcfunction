# TNK reward — station (hands the player the Tinkerer's Plinth item). @s = player.
# The q3 "Raise the Workshop" (has_station) beat's reward: give ONE Tinkerer's Plinth item
# so a player who completes that beat by holding 2 trinkets (rather than by already owning a
# Funnel) walks away with the altar they need for the q4 "first union" fusion. plinth/give is
# dup-guarded (no second Plinth if they already hold one). NO macro args read here, so this
# is a PLAIN file. A veteran who auto-passes via the ec.cf_r10_granted Funnel tag ALSO gets a
# Plinth here (harmless — the dup-guard skips if they somehow already hold one; the Plinth is
# the primary Knot/Hand altar regardless of the Funnel).
function evercraft:tinkering/plinth/give
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"#5EC8D8"},{text:"Reward: the ",color:"yellow"},{text:"Tinkerer's Plinth",color:"#5EC8D8",bold:true},{text:" — place it on a beacon and toss your trinkets to fuse.",color:"yellow"},{text:" ✦",color:"#5EC8D8"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.beacon.activate master @s ~ ~ ~ 0.6 1.4
