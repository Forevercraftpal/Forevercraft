# TNK reward — trophy (the capstone set-piece). @s = player.
# The Tinkering capstone (q12) pays a trophy via the SHARED Hero's-Satchel loot table
# (evercraft:hero_satchel/hero_satchel) is NOT used here — instead the capstone gives a
# small celebratory crate-equivalent: we reuse the existing ornate fishing crate as the
# "Master Tinkerer's chest" so Tinkering ships without authoring a bespoke trophy item
# tree. (A dedicated Master-Tinkerer trophy item can swap in later with zero engine change;
# the prestige is the special-title ID 17, wired in Wave C8.) Inv-full aware. NO macro args
# read here ($(target) is ignored — the trophy table is fixed), so this is a PLAIN file.
execute store result score #tnk_inv_full ec.var run function evercraft:util/check_inv_full
execute if score #tnk_inv_full ec.var matches 0 run loot give @s loot evercraft:fishing/gameplay/fishing/crates/ornate/1
execute if score #tnk_inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:fishing/gameplay/fishing/crates/ornate/1
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"Reward: the Master Tinkerer's chest!",color:"gold",bold:true},{text:" ✦",color:"gold"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Inventory full! Your reward was dropped at your feet.",color:"yellow"}]
scoreboard players set #ndur ec.temp 45
execute if score #tnk_inv_full ec.var matches 1 run function evercraft:util/notify/emit
execute if score #tnk_inv_full ec.var matches 1 if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bass player @s ~ ~ ~ 1 0.5
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 0.8 1.1
