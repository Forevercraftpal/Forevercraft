# ============================================================
# Dragonheart — GRAND capstone: grant the FULL dragon union, fold DR into ONE modifier (cap-M, Family M)
# ============================================================
# Run as @s = the player, at @s. Called from artifacts/accessories/player_tick's consolidated fusion block
# (the Family-M dispatch, BEHIND the ec.has_accessory early-exit) when the player holds a dragonheart:true
# item. The Dragonheart IS the union of the WHOLE Family-M dragon set by definition (the fusion `do`
# consumed the Wyrmscale Mantle + Wyrmclaw Grips + Wyrmwing Pinions + Wyrmheart Core — and through them all
# 16 members [14 leaves + the two reused seeds] — and spawned the Dragonheart flagged dragonheart; it does
# NOT carry the member items). FULL-POWER ASCENSION (no nerf fence): HERE we re-grant the FULL consolidated
# dragon bundle by calling the four sub-cap applies (idempotent — fixed-id attribute modifiers / Form-2
# effects, so re-running each tick overwrites to ONE value; the Reliquary / Heart-of-the-Mountain idiom).
# This = the full 16-member set:
#   - Wyrmscale Mantle -> +2 toughness / Resistance I / KB-resist / Night Vision + Darkness immunity.
#   - Wyrmclaw Grips   -> +2 melee / Strength I / the crouch breath-cone (ignite-on-hit fires from the
#                         Cinderclaw advancement trigger, gated on the held flag there).
#   - Wyrmwing Pinions -> Slow Falling / airborne Speed I / no fall damage / void immunity.
#   - Wyrmheart Core   -> the damage aura / Strength III (SET, dominates) / Fire Resistance /
#                         Regen-below-6 hearts.
# Then the four sub-cap luck modifiers they just added are STRIPPED and replaced by the ONE consolidated
# dragonheart_luck +21.0 (4.5+5.0+5.0+6.5, the FULL union — the Reliquary idiom: strip the sub-node ids,
# add the grand id, so DR is counted ONCE). The grand SUPERSEDES its four sub-caps + the loose member
# leaves — their dispatch in player_tick is guarded `unless` the grand is held, and the loose member *_luck
# strips live in the Family-M dispatch (Newcomer-gated), so nothing doubles.
#
# FLAGSHIP "Wyrmsoar" (no-resource-pack-safe — vanilla particles/effects only): the consolidated Dragon-Form
# elytra-less glide + the dragon-breath cone. The breath cone is already fired by the wyrmclaw_grips_apply
# call above (sneak-gated, dragon_breath + flame particles). The glide/"soar" half is rendered HERE with
# vanilla effects: while crouching + airborne, a brief Slow Falling keeps the bearer aloft (the steerable
# glide feel), and a brief upward Levitation 1 on crouch-jump gives the "soar" updraft — both vanilla, no RP.
# bit:0 = no ec.tnk_owned latch (completed state = HOLDING dragonheart:true; this apply keys on that flag).
# READ-ONLY on persistent state except the sub-caps' fixed-id attributes (idempotent overwrite) + the
# consolidated luck + the bounded aura/cone/glide effects.

# --- 1) The full dragon union = the four sub-cap applies (idempotent fixed-id grants / Form-2 effects). ---
function evercraft:tinkering/dragonheart/wyrmscale_mantle_apply
function evercraft:tinkering/dragonheart/wyrmclaw_grips_apply
function evercraft:tinkering/dragonheart/wyrmwing_pinions_apply
function evercraft:tinkering/dragonheart/wyrmheart_core_apply

# --- 2) Wyrmsoar glide/"soar" half (vanilla, no RP) — the breath cone is fired by wyrmclaw_grips_apply
#     above. While crouching + airborne: Slow Falling (steerable glide) + a brief Levitation 1 updraft. ---
execute if predicate evercraft:sneaking if predicate evercraft:not_on_ground run effect give @s slow_falling 2 0 true
execute if predicate evercraft:sneaking if predicate evercraft:not_on_ground run effect give @s levitation 1 0 true
execute if predicate evercraft:sneaking if predicate evercraft:not_on_ground run particle dragon_breath ~ ~ ~ 0.3 0.2 0.3 0.01 4

# --- 3) Strip the four sub-cap consolidated luck (the grand supersedes its sub-nodes — one source of DR).
#     The sub-cap applies above re-added these THIS tick; the grand replaces them with the single +21.0.
#     NOT Newcomer-gated: a sub-cap's own consolidate already double-counts vs the loose members the
#     Family-M dispatch strips, so the grand must always remove the sub-node id to keep ONE source. ---
attribute @s luck modifier remove evercraft:wyrmscale_mantle_luck
attribute @s luck modifier remove evercraft:wyrmclaw_grips_luck
attribute @s luck modifier remove evercraft:wyrmwing_pinions_luck
attribute @s luck modifier remove evercraft:wyrmheart_core_luck

# --- 4) Present the single consolidated Dream Rate (ascension headline, D1 full-power, UNCAPPED, +21.0). ---
attribute @s luck modifier add evercraft:dragonheart_luck 21.0 add_value
