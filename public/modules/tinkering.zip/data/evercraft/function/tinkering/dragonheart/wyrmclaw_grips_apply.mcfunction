# ============================================================
# Wyrmclaw Grips — melee/breath sub-binding: grant the consolidated claw union (cap-M, Family M)
# ============================================================
# Run as @s = the player, at @s. Called from artifacts/accessories/player_tick's consolidated fusion
# block (the Family-M dispatch, BEHIND the ec.has_accessory early-exit) when the player holds a
# wyrmclaw_grips:true item AND is NOT holding the grand Dragonheart / Wyrmscale Aegis (the grand
# supersedes — it calls this apply itself). The Wyrmclaw Grips IS the union of Wyrmtooth Fang + Dragonbone
# Talon + Cinderclaw Grip + Breath-Gland Sac by definition (the fusion `do` consumed them and spawned the
# Grips flagged wyrmclaw_grips — it does NOT carry the member items). So HERE we re-grant the consolidated
# melee/breath kit via DISTINCT sub-cap-scoped attribute ids (NOT the loose leaf ids) so the loose
# accessory_cleanup never strips them and the cap-M accessory_cleanup block owns their removal when the
# Grips are not held.
#
# CONSOLIDATED VALUE (the union of the four claw leaves, verbatim from their loose player_tick lines):
#   - Wyrmtooth Fang  -> +2 melee Attack Damage (fixed-id add_value).
#   - Dragonbone Talon-> Strength I (harmonize-gated, folds toward the set Strength III).
#   - Cinderclaw Grip -> attacks ignite hostiles 3s — fires from its own player_hurt_entity advancement
#                        trigger (the blaze_core idiom), gated on the held grips/grand flag at THAT trigger,
#                        NOT a per-tick grant here (no tick-side counterpart exists to re-call).
#   - Breath-Gland Sac-> the crouch-fired breath cone (3 dmg + 3s ignite to hostiles <=3 b in look-dir,
#                        vanilla dragon_breath + flame particles, sneak-gated — the no-resource-pack cone).
# The consolidated +5.0 Dream Rate is the ONE wyrmclaw_grips_luck modifier (fixed-id; idempotent — two
# Grips overwrite to ONE value, m4 Layer-2). Reports ONE line in dreams/breakdown/artifacts. READ-ONLY on
# persistent state except the fixed-id attribute + the bounded breath-cone damage/particles.

# --- Wyrmtooth Fang: +2 melee Attack Damage (distinct sub-cap id) ---
attribute @s attack_damage modifier add evercraft:wyrmclaw_grips_atk 2.0 add_value

# --- Dragonbone Talon: Strength I (harmonize-gated, folds toward the set Strength III) ---
execute if score @s ec.h_str matches ..1 run effect give @s strength 5 0 false

# --- Breath-Gland Sac: crouch-fired breath cone (sneak-gated; 3 dmg + 3s ignite to hostiles <=3 b in
#     the look direction, rendered with vanilla dragon_breath + flame — no resource pack). ---
execute if predicate evercraft:sneaking at @s positioned ^ ^ ^2 as @e[type=#evercraft:hostile_mobs,distance=..3,limit=5] run damage @s 3 minecraft:dragon_breath
execute if predicate evercraft:sneaking at @s positioned ^ ^ ^2 as @e[type=#evercraft:hostile_mobs,distance=..3,limit=5] run data merge entity @s {Fire:60s}
execute if predicate evercraft:sneaking at @s run particle dragon_breath ^ ^1 ^1 0.3 0.3 0.3 0.02 6
execute if predicate evercraft:sneaking at @s run particle flame ^ ^1 ^2 0.5 0.4 0.5 0.02 8

# --- Consolidated Dream Rate +5.0 (the claw union; fixed-id, idempotent) ---
attribute @s luck modifier add evercraft:wyrmclaw_grips_luck 5.0 add_value
