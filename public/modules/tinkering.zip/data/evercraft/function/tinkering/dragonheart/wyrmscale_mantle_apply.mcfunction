# ============================================================
# Wyrmscale Mantle — tank/sense sub-binding: grant the consolidated mantle union (cap-M, Family M)
# ============================================================
# Run as @s = the player, at @s. Called from artifacts/accessories/player_tick's consolidated fusion
# block (the Family-M dispatch, BEHIND the ec.has_accessory early-exit) when the player holds a
# wyrmscale_mantle:true item AND is NOT holding the grand Dragonheart / the final-form Wyrmscale Aegis
# (the grand supersedes — it calls this apply itself). The Wyrmscale Mantle IS the union of Wyrmscale
# Plate + Scaled Carapace + Ridgeback Spur + Enderscale Eye by definition (the fusion `do` consumed them
# and spawned the Mantle flagged wyrmscale_mantle — it does NOT carry the member items). So HERE we
# re-grant the consolidated tank/sense kit via DISTINCT sub-cap-scoped attribute ids (NOT the loose leaf
# ids) so the loose accessory_cleanup never strips them and the cap-M accessory_cleanup block owns their
# removal when the Mantle is not held.
#
# CONSOLIDATED VALUE (the union of the four mantle leaves, verbatim from their loose player_tick lines):
#   - Wyrmscale Plate -> +2 Armor Toughness (fixed-id add_value).
#   - Scaled Carapace -> Resistance I (harmonize-gated, yields to a stronger same-effect).
#   - Ridgeback Spur  -> full Knockback Resistance (fixed-id 1.0 add_value).
#   - Enderscale Eye  -> Night Vision + Darkness immunity (clear darkness, the warden_ring idiom).
# The consolidated +4.5 Dream Rate is the ONE wyrmscale_mantle_luck modifier (fixed-id; idempotent — two
# Mantles overwrite to ONE value, m4 Layer-2). Reports ONE line in dreams/breakdown/artifacts. MIXED-DR
# family: the loose leaves' own *_luck were stripped m4-suppressed when the Mantle is held (handled at the
# Family-M dispatch). READ-ONLY on persistent state except the fixed-id attributes + the Form-2 effects.

# --- Wyrmscale Plate: +2 Armor Toughness (distinct sub-cap id) ---
attribute @s armor_toughness modifier add evercraft:wyrmscale_mantle_tough 2 add_value

# --- Scaled Carapace: Resistance I (harmonize-gated) ---
execute if score @s ec.h_resist matches ..1 run effect give @s resistance 5 0 false

# --- Ridgeback Spur: full Knockback Resistance (distinct sub-cap id) ---
attribute @s knockback_resistance modifier add evercraft:wyrmscale_mantle_kb 1.0 add_value

# --- Enderscale Eye: Night Vision + Darkness immunity ---
effect give @s night_vision 15 0 false
effect clear @s darkness

# --- Consolidated Dream Rate +4.5 (the mantle union; fixed-id, idempotent) ---
attribute @s luck modifier add evercraft:wyrmscale_mantle_luck 4.5 add_value
