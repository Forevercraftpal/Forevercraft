# ============================================================
# Wyrmscale Aegis — FINAL-FORM: grant the full dragon union + (the +40 dodge lives in m1) (cap-M, Family M)
# ============================================================
# Run as @s = the player, at @s. Called from artifacts/accessories/player_tick's consolidated fusion block
# (the Family-M dispatch, BEHIND the ec.has_accessory early-exit) when the player holds a
# wyrmscale_aegis:true item. The Wyrmscale Aegis IS the Dragonheart void-tempered (the fusion `do` consumed
# the Dragonheart + a Voidscale Shard and spawned the Aegis flagged wyrmscale_aegis — it does NOT carry the
# member items). FULL-POWER ASCENSION: HERE we re-grant the SAME full dragon union as the grand by calling
# the four sub-cap applies (idempotent fixed-id attribute modifiers / Form-2 effects — the Reliquary /
# Soulguard Aegis grand idiom), then fire the Wyrmsoar glide/"soar" half, then consolidate DR into the ONE
# wyrmscale_aegis_luck +21.0 (the SAME union as the grand — set-not-double, a DISTINCT id so it never
# clobbers the grand's dragonheart_luck on a sibling).
#
# THE +40 (10%) DODGE: the Aegis is the Dragonheart family's OWN dodge pinnacle. That +40 is added in the
# m1 ec.acc_dodge LEAF block at the TOP of player_tick (one writer = player_tick), keyed on
# wyrmscale_aegis:true — NOT here. This apply grants only the effect/attr/DR union, exactly like the grand.
# bit:0 = no ec.tnk_owned latch (completed state = HOLDING wyrmscale_aegis:true; this apply keys on that
# flag). READ-ONLY on persistent state except the sub-caps' fixed-id attributes (idempotent overwrite) +
# the consolidated luck + the bounded aura/cone/glide effects. Multi-copy: unique (final-form +
# capstone-vs-ingredient block vs dragonheart; Newcomer-exempt per D-MULTICOPY).

# --- 1) The full dragon union = the four sub-cap applies (idempotent fixed-id grants / Form-2 effects). ---
function evercraft:tinkering/dragonheart/wyrmscale_mantle_apply
function evercraft:tinkering/dragonheart/wyrmclaw_grips_apply
function evercraft:tinkering/dragonheart/wyrmwing_pinions_apply
function evercraft:tinkering/dragonheart/wyrmheart_core_apply

# --- 2) Wyrmsoar glide/"soar" half (vanilla, no RP) — same as the grand. The breath cone is fired by
#     wyrmclaw_grips_apply above. While crouching + airborne: Slow Falling + a brief Levitation 1 updraft. ---
execute if predicate evercraft:sneaking if predicate evercraft:not_on_ground run effect give @s slow_falling 2 0 true
execute if predicate evercraft:sneaking if predicate evercraft:not_on_ground run effect give @s levitation 1 0 true
execute if predicate evercraft:sneaking if predicate evercraft:not_on_ground run particle dragon_breath ~ ~ ~ 0.3 0.2 0.3 0.01 4

# --- 3) Strip the four sub-cap consolidated luck + the grand's luck (the Aegis supersedes both — one
#     source of DR). The sub-cap applies above re-added the four sub-cap ids THIS tick; the Aegis replaces
#     them (and any re-acquired dragonheart_luck) with the single +21.0 below. ---
attribute @s luck modifier remove evercraft:wyrmscale_mantle_luck
attribute @s luck modifier remove evercraft:wyrmclaw_grips_luck
attribute @s luck modifier remove evercraft:wyrmwing_pinions_luck
attribute @s luck modifier remove evercraft:wyrmheart_core_luck
attribute @s luck modifier remove evercraft:dragonheart_luck

# --- 4) Present the single consolidated Dream Rate (the same union as the grand, +21.0; DISTINCT id). ---
attribute @s luck modifier add evercraft:wyrmscale_aegis_luck 21.0 add_value
