# ============================================================
# Wyrmheart Core — heart sub-binding: grant the consolidated heart union (cap-M, Family M)
# ============================================================
# Run as @s = the player, at @s. Called from artifacts/accessories/player_tick's consolidated fusion
# block (the Family-M dispatch, BEHIND the ec.has_accessory early-exit) when the player holds a
# wyrmheart_core:true item AND is NOT holding the grand Dragonheart / Wyrmscale Aegis (the grand
# supersedes — it calls this apply itself). The Wyrmheart Core IS the union of Dragon's Tear +
# Dragonheart Ember + Wyrmblood Vial + Ender Dragon Scale by definition (the fusion `do` consumed them —
# INCLUDING the two reused seeds — and spawned the Core flagged wyrmheart_core; it does NOT carry the
# member items). So HERE we re-grant the consolidated heart kit, verbatim from the four members' loose
# player_tick lines (the two seeds' own blocks at :1369 + :1525 are the source of truth).
#
# CONSOLIDATED VALUE (the union of the four heart members):
#   - Dragon's Tear     -> the 2 dmg/s damage aura to hostiles <=4 b (one damage block) + Strength I
#                          (harmonize-gated). [seed perk block player_tick:1369-1375]
#   - Dragonheart Ember -> Fire Resistance (ungated, the blaze_core idiom).
#   - Wyrmblood Vial    -> Regeneration I below 6 hearts (last-stand; regen-cap aware).
#   - Ender Dragon Scale-> Strength III (harmonize-gated, SETs the level — `effect give` never sums, so the
#                          scale's III dominates the tear's I) + Fire Resistance. [seed perk block
#                          player_tick:1525-1529]. The scale's elytra-less Dragon-Form glide is its OWN
#                          ability-item mechanic (NOT a per-tick effect block); the consolidated flagship
#                          glide ("Wyrmsoar") is folded into the GRAND dragonheart_apply, not this sub-cap.
# Strength is consolidated to III (the scale's level dominates via `effect give` SET semantics — one gate,
# never summed). Fire Resistance overlaps (ember + scale) -> ONE grant. The consolidated +6.5 Dream Rate is
# the ONE wyrmheart_core_luck modifier (fixed-id; idempotent — two Cores overwrite to ONE value, m4
# Layer-2). Reports ONE line in dreams/breakdown/artifacts. ec._wh is a LOCAL temp tag (removed at the end)
# for the aura single-scan — distinct from the player_tick ec._a tag (this apply runs mid-tick while ec._a
# is free, but a distinct tag avoids any aliasing). READ-ONLY on persistent state except the bounded aura.

# --- Dragon's Tear: 2 dmg/s damage aura to hostiles <=4 b (single block) + Strength I (harmonize-gated) ---
tag @s add ec._wh
execute if entity @s[tag=ec._wh] as @e[type=#evercraft:hostile_mobs,distance=..4,limit=5] run damage @s 1 evercraft:bonus_strike
execute if entity @s[tag=ec._wh] if score @s ec.h_str matches ..1 run effect give @s strength 5 0 false
tag @s remove ec._wh

# --- Ender Dragon Scale: Strength III (harmonize-gated; SETs the level, dominates the tear's I) ---
execute if score @s ec.h_str matches ..1 run effect give @s strength 5 2 false

# --- Dragonheart Ember + Ender Dragon Scale: Fire Resistance (overlap -> ONE grant) ---
effect give @s fire_resistance 15 0 false

# --- Wyrmblood Vial: Regeneration I below 6 hearts (last-stand; regen-cap aware) ---
execute if predicate evercraft:health_below_6 unless entity @s[tag=ec.regen_capped] run effect give @s regeneration 5 0 false

# --- Consolidated Dream Rate +6.5 (the heart union; fixed-id, idempotent) ---
attribute @s luck modifier add evercraft:wyrmheart_core_luck 6.5 add_value
