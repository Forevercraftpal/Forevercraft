# ============================================================
# Wyrmwing Pinions — mobility sub-binding: grant the consolidated wing union (cap-M, Family M)
# ============================================================
# Run as @s = the player, at @s. Called from artifacts/accessories/player_tick's consolidated fusion
# block (the Family-M dispatch, BEHIND the ec.has_accessory early-exit) when the player holds a
# wyrmwing_pinions:true item AND is NOT holding the grand Dragonheart / Wyrmscale Aegis (the grand
# supersedes — it calls this apply itself). The Wyrmwing Pinions IS the union of Wyrmwing Membrane +
# Stormrider Pinion + Featherscale Down + Voidscale Shard by definition (the fusion `do` consumed them and
# spawned the Pinions flagged wyrmwing_pinions — it does NOT carry the member items). So HERE we re-grant
# the consolidated mobility kit via DISTINCT sub-cap-scoped attribute ids (NOT the loose leaf ids) so the
# loose accessory_cleanup never strips them and the cap-M accessory_cleanup block owns their removal when
# the Pinions are not held.
#
# CONSOLIDATED VALUE (the union of the four wing leaves, verbatim from their loose player_tick lines):
#   - Wyrmwing Membrane -> Slow Falling (set-glide base).
#   - Stormrider Pinion -> Speed I ONLY while airborne (not_on_ground + harmonize-gated; self-expiring).
#   - Featherscale Down -> No fall damage (fixed-id fall_damage_multiplier -1.0 add_multiplied_base).
#   - Voidscale Shard   -> Void immunity (Y<=-70 -> Slow Falling + Resistance V + Fire Res + Levitation 1,
#                          vanilla effects only, NO teleport — additive + bounded, no resource pack).
# The +1% dodge for the three agile wing leaves (Membrane / Pinion / Down) is added in player_tick's m1
# ec.acc_dodge LEAF block (one writer) on the held LEAF ids — NOT re-added here (the Pinions sub-cap does
# not separately re-add it; the spec's "(+1% dodge x3 lanes via leaves)" refers to those m1 leaf adds).
# ec._vy is the player_tick file's writer; this apply reads Pos[1] into a scratch score #wp_vy (NOT ec._vy)
# so it never collides with the one-writer ec._vy. The consolidated +5.0 Dream Rate is the ONE
# wyrmwing_pinions_luck modifier (fixed-id; idempotent — two Pinions overwrite to ONE value, m4 Layer-2).
# Reports ONE line in dreams/breakdown/artifacts. READ-ONLY on persistent state except the fixed-id attrs +
# the Form-2 effects.

# --- Wyrmwing Membrane: Slow Falling ---
effect give @s slow_falling 5 0 false

# --- Stormrider Pinion: Speed I while airborne (harmonize-gated, self-expiring) ---
execute if predicate evercraft:not_on_ground if score @s ec.h_speed matches ..1 run effect give @s speed 2 0 false

# --- Featherscale Down: No fall damage (distinct sub-cap id) ---
attribute @s fall_damage_multiplier modifier add evercraft:wyrmwing_pinions_fall -1.0 add_multiplied_base

# --- Voidscale Shard: Void immunity (Y<=-70 -> arrest the fall with vanilla effects, no teleport) ---
execute store result score #wp_vy ec.temp run data get entity @s Pos[1] 1
execute if score #wp_vy ec.temp matches ..-70 run effect give @s slow_falling 5 0 true
execute if score #wp_vy ec.temp matches ..-70 run effect give @s resistance 5 4 true
execute if score #wp_vy ec.temp matches ..-70 run effect give @s fire_resistance 5 0 true
execute if score #wp_vy ec.temp matches ..-70 run effect give @s levitation 1 4 true

# --- Consolidated Dream Rate +5.0 (the wing union; fixed-id, idempotent) ---
attribute @s luck modifier add evercraft:wyrmwing_pinions_luck 5.0 add_value
