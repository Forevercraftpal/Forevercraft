# ============================================================
# Tinkering — One-time soft BEGIN offer (the accessory-pair hook, F)
# ============================================================
# Run as @s = the player. Called from artifacts/accessories/player_tick's ONE additive gated
# line the first time a player holds >=2 accessories at once. Fires the ONE-TIME Seven-voice
# soft offer to begin the Tinkering line — a natural "you could combine these" in-world
# trigger. The FALLBACK to begin the line is always the Tinkering Tier-2 row (in BOTH
# chronicle tiers — universal), so this is a convenience nudge, not the only door.
#
# UNIVERSAL (NO ec.chron_view gate): unlike the Adventure offers (which gate on lens 1/3),
# Tinkering is for ALL players on ANY path (T10), so the offer fires regardless of chronicle.
# This avoids a third first-login prompt (S15): it arrives in-world on first-pair, not at login.
#
# GATING (the caller's single line gates these; re-guarded here defensively):
#   - ec.tnk_active matches 0 — never offered to someone already on (or past) the line.
#   - ec.tnk_offer matches 0 — one-shot; set to 1 at the END so a mid-fn failure doesn't
#     permanently swallow a never-shown offer. SOLE WRITER of ec.tnk_offer is this function;
#     the strip-reset is the documented exception (like ec.ak_offer / ec.gq_offered).
#
# IMMERSION LAW (no /trigger): the begin affordance is a clickable chat button whose
# click_event runs tinkering/start directly. Declining = simply not clicking; the offer never
# re-fires (ec.tnk_offer latch). Mirrors adventure/kingdom/offer_prompt verbatim.
#
# NOTIFY (alert class, mute_at:99, key "tnk_offer"): the Seven-voice chime/flash routes
# through util/notify/dispatch so it respects the player's global ec.notify filter. mute_at:99
# means the [Mute] button effectively never appears — a one-shot offer. The clickable
# [Begin ->] button is INDEPENDENT of the chatter gate.

# === Re-guard the latches (caller already gated; defensive against re-entry) ===
execute if score @s ec.tnk_offer matches 1 run return 0
execute if score @s ec.tnk_active matches 1.. run return 0

# === 1) MUTABLE Seven-voice OFFER nudge (alert class) ===
function evercraft:util/notify/dispatch {key:"tnk_offer",class:"alert",mute_at:99}
# Only the chime/flash respects the dispatcher's approval (global ec.notify filter).
execute if score #notif_show_tnk_offer ec.temp matches 1 run title @s times 8 50 12
execute if score #notif_show_tnk_offer ec.temp matches 1 run title @s subtitle {text:"Two trinkets — you could join them",color:"#5EC8D8",italic:true}
execute if score #notif_show_tnk_offer ec.temp matches 1 if score @s ec.fx_snd matches 1.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.7 1.5

# === 2) THE OFFER itself (always shown — independent of the chatter chime) ===
# A quiet Seven-voice card. The [Begin Tinkering ->] button is the one interaction-driven
# affordance (function click_event, non-op-safe per the offer_prompt precedent). One-shot.
tellraw @s ""
tellraw @s [{text:"  ⚙ ",color:"#5EC8D8"},{text:"The Tinkerer's Path",color:"#5EC8D8",bold:true,italic:false}]
tellraw @s [{text:"  You are carrying two trinkets now — and two pockets",color:"gray",italic:true}]
tellraw @s [{text:"  where one would do. A Tinkerer can knot them into one,",color:"gray",italic:true}]
tellraw @s [{text:"  losing nothing of what they give you. Shall I teach you?",color:"gray",italic:true}]
tellraw @s ""
tellraw @s [{text:"  ",color:"dark_gray"},{text:"[Begin the Tinkerer's Path →]",color:"#5EC8D8",bold:true,hover_event:{action:"show_text",value:[{text:"Start the Tinkerer's Path — a short, fully skippable, universal line that teaches combining artifacts.",color:"gray"},"",{text:"You can also begin it any time from the Grand Quests hub (Tinkering, in either chronicle).",color:"dark_gray",italic:true}]},click_event:{action:"run_command",command:"/function evercraft:tinkering/start"}}]
tellraw @s [{text:"  ",color:"dark_gray"},{text:"(or simply walk on — the offer will not return)",color:"dark_gray",italic:true}]
tellraw @s ""

# === 3) LATCH the offer (sole writer of ec.tnk_offer) ===
# Set LAST so a failure above doesn't permanently swallow a never-shown offer.
scoreboard players set @s ec.tnk_offer 1
