# ============================================================
# Tinkering (universal mini-line) — ADDITIVE tree-sampler dispatch (per-quest)
# ============================================================
# Run as @s = the player, from tinkering/advance IMMEDIATELY AFTER tinkering/reward (so the
# existing coins/crate/trophy reward is paid UNCHANGED — this only ADDS a tree-level layer).
# At this point ec.tnk_quest still holds the JUST-COMPLETED quest id (advance bumps it AFTER).
#
# SPEC (XP-REWARD-ECONOMY.md §"Tinkering — short universal sampler"): across the 12-quest line,
# grant a FIXED total of +5 LEVELS EACH to THREE trees — adv.victorian (id 8), adv.vitality
# (id 5), adv.explorer (id 13) — spread evenly so by line-completion each has gained exactly 5.
# FLAT across every game mode (do NOT read/scale by ec.difficulty). NO prestige capstone.
# Grant via each tree's NORMAL level-up gate (additive), NOT a raw set.
#
# DISTRIBUTION (12 quests, round-robin one tree per quest; the last pass of each tree gives +2):
#   q1  victorian +1     q5  vitality  +1     q9  explorer  +1
#   q2  vitality  +1     q6  explorer  +1     q10 victorian +2
#   q3  explorer  +1     q7  victorian +1     q11 vitality  +2
#   q4  victorian +1     q8  vitality  +1     q12 explorer  +2
#   Totals: victorian = 1+1+1+2 = 5 ; vitality = 1+1+1+2 = 5 ; explorer = 1+1+1+2 = 5  (=15 total)
#
# If a future load_batch_1 extends the line past id 12, those quests simply grant nothing here
# (the match arms below are id-pinned 1..12), so the +5-each total never inflates — extend this
# table deliberately if/when a new chapter should add more sampler levels.
#
# Per-grant params live on storage evercraft:tnk_sample p = {tree, stat}; grant amount is a count
# of grant_one calls (1 or 2). The grant_one helper is fully cap-guarded + net-zero XP (see there).

# ---- victorian (adv.stat_mobs) : q1, q4, q7 (+1) ; q10 (+2) -------------------------------
execute if score @s ec.tnk_quest matches 1 run data modify storage evercraft:tnk_sample p set value {tree:"victorian",stat:"mobs"}
execute if score @s ec.tnk_quest matches 4 run data modify storage evercraft:tnk_sample p set value {tree:"victorian",stat:"mobs"}
execute if score @s ec.tnk_quest matches 7 run data modify storage evercraft:tnk_sample p set value {tree:"victorian",stat:"mobs"}
execute if score @s ec.tnk_quest matches 10 run data modify storage evercraft:tnk_sample p set value {tree:"victorian",stat:"mobs"}
# ---- vitality (adv.stat_food) : q2, q5, q8 (+1) ; q11 (+2) --------------------------------
execute if score @s ec.tnk_quest matches 2 run data modify storage evercraft:tnk_sample p set value {tree:"vitality",stat:"food"}
execute if score @s ec.tnk_quest matches 5 run data modify storage evercraft:tnk_sample p set value {tree:"vitality",stat:"food"}
execute if score @s ec.tnk_quest matches 8 run data modify storage evercraft:tnk_sample p set value {tree:"vitality",stat:"food"}
execute if score @s ec.tnk_quest matches 11 run data modify storage evercraft:tnk_sample p set value {tree:"vitality",stat:"food"}
# ---- explorer (adv.stat_struct) : q3, q6, q9 (+1) ; q12 (+2) ------------------------------
execute if score @s ec.tnk_quest matches 3 run data modify storage evercraft:tnk_sample p set value {tree:"explorer",stat:"struct"}
execute if score @s ec.tnk_quest matches 6 run data modify storage evercraft:tnk_sample p set value {tree:"explorer",stat:"struct"}
execute if score @s ec.tnk_quest matches 9 run data modify storage evercraft:tnk_sample p set value {tree:"explorer",stat:"struct"}
execute if score @s ec.tnk_quest matches 12 run data modify storage evercraft:tnk_sample p set value {tree:"explorer",stat:"struct"}

# Determine how many levels this quest grants: 1 for the regular passes, 2 for the final pass
# of each tree (q10/q11/q12). Default 1 on any matched quest; 0 on an out-of-table quest.
scoreboard players set #tnk_sample_amt ec.temp 0
execute if score @s ec.tnk_quest matches 1..12 run scoreboard players set #tnk_sample_amt ec.temp 1
execute if score @s ec.tnk_quest matches 10..12 run scoreboard players set #tnk_sample_amt ec.temp 2

# Realize the levels via the NORMAL gate (one grant_one call per level). Cap-guarded inside.
execute if score #tnk_sample_amt ec.temp matches 1.. run function evercraft:tinkering/tree_sample/grant_one with storage evercraft:tnk_sample p
execute if score #tnk_sample_amt ec.temp matches 2.. run function evercraft:tinkering/tree_sample/grant_one with storage evercraft:tnk_sample p
