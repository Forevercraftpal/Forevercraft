# ============================================================
# Tinkering (universal mini-line) — ADDITIVE tree-sampler XP top-up (macro body)
# ============================================================
# Called `with storage evercraft:advantage` (the SAME storage advantage/levelup uses), where
# $(xp_cost) = this level's adv.req_xp (vanilla-XP cost, NOT difficulty-scaled). Grants exactly
# that many vanilla XP levels so the subsequent advantage/levelup/<tree> gate passes; that
# level-up immediately deducts the same amount via advantage/deduct_xp -> NET ZERO real XP.
# This is the honest "realize one tree level through the NORMAL gate" move (XP-REWARD-ECONOMY.md
# §"Per-quest contribution": award the progress the tree consumes, NOT a raw `set adv.<tree>`).
# Run as @s = the player. Mirrors the shape of advantage/challenges/grant_xp.
$experience add @s $(xp_cost) levels
