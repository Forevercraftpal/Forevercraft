# ============================================================
# Tinkering (universal mini-line) — ADDITIVE tree-sampler: grant ONE tree level (macro body)
# ============================================================
# Called `with storage evercraft:tnk_sample p`, where p = {tree:"victorian", stat:"mobs"}
# (tree -> adv.<tree> level + advantage/levelup/<tree> + advantage/calc/<tree>; stat -> the
# tree's grind scoreboard adv.stat_<stat>). Run as @s = the player.
#
# Realizes exactly ONE level of the named tree THROUGH ITS NORMAL LEVEL-UP GATE (additive),
# never `scoreboard set adv.<tree>` — so adv.req_xp / req_stat / prestige / do_prestige logic
# stays fully intact (XP-REWARD-ECONOMY.md §"Tinkering" + §"Per-quest contribution").
#
# FLAT across every game mode: this helper deterministically yields one whole level regardless
# of ec.difficulty (it tops both walls to exactly the requirement), so the +5-each total is
# IDENTICAL on Newcomer / Adventurer / Pioneer. It does NOT read ec.difficulty. (The
# apply_difficulty divisor inside calc only shrinks req_stat; because we fill the stat wall to
# whatever req_stat resolves to, the realized outcome — one level — is the same in all modes.)
#
# How it stays additive / never-reduces:
#   * XP: grant exactly req_xp vanilla levels, which advantage/levelup/<tree> deducts right back
#     -> NET ZERO real XP (the player is not charged; the gate is merely satisfied).
#   * Stat: adv.stat_<stat> is a DOCUMENTED multi-writer grind counter (the one-writer law does
#     not apply to it — see grant_tree_credit / cooking on_kill writers). We raise it to req_stat
#     ONLY when it is below (shortfall fill), so existing natural progress is never reduced.
#   * Cap: skip entirely at level 25 (the tree's max) so a near-max veteran is never spammed with
#     the levelup "already at max" red tellraw.

# --- Cap guard: never push past the tree's max level (25). Silent at the cap. ---
$execute if score @s adv.$(tree) matches 25.. run return 0

# --- 1) Compute this level's requirements (sets adv.req_xp + adv.req_stat for the CURRENT level). ---
$function evercraft:advantage/calc/$(tree)

# --- 2) Top up vanilla XP to cover req_xp (levelup deducts it again -> net zero). ---
execute store result storage evercraft:advantage xp_cost int 1 run scoreboard players get @s adv.req_xp
function evercraft:tinkering/tree_sample/topup_xp with storage evercraft:advantage

# --- 3) Fill the grind wall: raise adv.stat_<stat> to req_stat ONLY if currently below (never reduce). ---
#
# ⚠ F1 — THIS FILL MUST STAY SYNCHRONOUS / IN-TICK. Do NOT defer it to a GUI click,
# a scheduled tick, or any async hook. It survives ONLY because step 4 below
# (advantage/levelup/<tree>) runs in the SAME tick and realizes the level
# immediately — BEFORE the 5s advantage/track/sync_stats_player `=` recompute can
# clobber adv.stat_$(stat). adv.stat_* is an authoritative-recompute objective:
# sync_stats_player OVERWRITES it with `=` (not `+=`) every 5s from the lifetime
# sources, so any stat raise that is NOT consumed by a level-up in the same tick is
# silently wiped on the next sync. This is EXACTLY the Fishing tree-credit clobber
# (build-review A1 / M1): fishing's per-quest `+= adv.stat_fish` was deferred and
# got `=`-overwritten, so its entire ~250-quest reward layer did nothing in-game.
# Tinkering avoids that trap only by realizing the level here-and-now. A future
# "defer to GUI" refactor of grant_one WILL reintroduce the clobber. Keep 3→4
# atomic and in-tick.
$execute if score @s adv.stat_$(stat) < @s adv.req_stat run scoreboard players operation @s adv.stat_$(stat) = @s adv.req_stat

# --- 4) Run the NORMAL level-up (deducts req_xp, +1 level, milestones, cosmetics, fanfare, caps@25). ---
$function evercraft:advantage/levelup/$(tree)
