# Run as operator (testing). Temp/admin entry to start the Tinkerer's Path + hand yourself
# the Tinkerer's Codex + a Plinth, before the canonical entries (the accessory-pair offer and
# the Tier-2 rows) are exercised.
# Usage: /execute as <player> run function evercraft:tinkering/admin/give
# (debug) — starts the line if not already active (start gives the Codex, dup-guarded), and
# (re)hands the Codex + a Plinth in case they were lost.
execute unless score @s ec.tnk_active matches 1.. run function evercraft:tinkering/start
# If already on the line, just (re)hand the Codex + a Plinth.
execute if score @s ec.tnk_active matches 1.. run function evercraft:tinkering/book/give
function evercraft:tinkering/plinth/give
