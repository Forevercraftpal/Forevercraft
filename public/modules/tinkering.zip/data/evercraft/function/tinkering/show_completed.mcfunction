# ============================================================
# Tinkering (universal mini-line) — Show completed quest (just-finished one)
# ============================================================
# Reads the just-completed quest from tnk_cur.quest (still the OLD quest at this point in
# advance, before the pointer is bumped) and prints a green checkmark line. Mirrors the C6
# show_completed tone. Run as @s = the player.

data modify storage evercraft:tnk_cur o set from storage evercraft:tnk_cur quest
function evercraft:tinkering/show_completed_macro with storage evercraft:tnk_cur o
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.player.levelup master @s ~ ~ ~ 0.4 1.8
