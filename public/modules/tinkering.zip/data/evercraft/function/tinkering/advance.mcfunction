# ============================================================
# Tinkering (universal mini-line) — Advance (complete current quest -> next)
# ============================================================
# Run as @s = the player. Called by tinkering/check when the active quest is satisfied,
# OR by quest_pacing/do_skip (the [Skip ▸] button, full reward). WRITER of the linear
# pointer (ec.tnk_quest), ec.tnk_prog reset, ec.tnk_done, ec.tnk_complete (via finish).
#
# Order: show_completed -> reward -> bump pointer (clamped) -> reset prog -> +1 done
#        -> load next quest -> show_objective. Final quest -> a one-shot "line complete!"
#        tellraw + ec.tnk_active bumped to 2, pointer clamped at N.

# --- Idempotency / out-of-range guards (mirror the C6 upper-bound guard) ---
execute unless score @s ec.tnk_active matches 1.. run return 0
execute if score @s ec.tnk_complete matches 1 run return 0

# Registry length = N (the last valid quest index). Dynamic so the engine never hardcodes
# the quest count — it grows automatically as batches are added.
execute store result score #tnk_n ec.temp run data get storage evercraft:tnk_registry quests
# Defensive: if the registry failed to load (length 0), do nothing.
execute if score #tnk_n ec.temp matches ..0 run return 0
# If the pointer is somehow already past N, clamp + finish (don't run past the end).
execute if score @s ec.tnk_quest > #tnk_n ec.temp run function evercraft:tinkering/finish
execute if score @s ec.tnk_quest > #tnk_n ec.temp run return 0

# === 1) SHOW WHAT WAS JUST COMPLETED (tnk_cur still holds the old quest) ===
function evercraft:tinkering/show_completed

# === 2) PAY OUT THE REWARD for the completed quest ===
function evercraft:tinkering/reward

# === 2b) ADDITIVE TREE-SAMPLER LAYER (XP-REWARD-ECONOMY.md §"Tinkering") ===
# ON TOP of the unchanged reward above, grant this quest's share of the FLAT +5-levels-each
# sampler to adv.victorian / adv.vitality / adv.explorer (via each tree's NORMAL level-up gate,
# never a raw set). ec.tnk_quest still holds the just-completed quest id here (bumped in step 3),
# so the dispatcher's per-quest distribution table keys off it. FLAT — no ec.difficulty read,
# no prestige capstone. Adds only; removes/reduces nothing.
function evercraft:tinkering/tree_sample/dispatch

# === 3) ADVANCE THE LINEAR POINTER + COUNTERS ===
scoreboard players add @s ec.tnk_quest 1
scoreboard players set @s ec.tnk_prog 0
scoreboard players add @s ec.tnk_done 1

# === 4) FINAL-QUEST HANDLING ===
# If the new pointer exceeds N, the player just finished the LAST quest. Detect the
# overflow FIRST (into a flag), then clamp the pointer back to N (so a future check can't
# index out of range) and run the one-shot completion fanfare.
scoreboard players set #tnk_overflow ec.temp 0
execute if score @s ec.tnk_quest > #tnk_n ec.temp run scoreboard players set #tnk_overflow ec.temp 1
execute if score #tnk_overflow ec.temp matches 1 run scoreboard players operation @s ec.tnk_quest = #tnk_n ec.temp
execute if score #tnk_overflow ec.temp matches 1 run function evercraft:tinkering/finish

# Not finished: load the next quest into tnk_cur and show its objective (paced).
execute if score #tnk_overflow ec.temp matches 0 run function evercraft:tinkering/get_quest
execute if score #tnk_overflow ec.temp matches 0 run function evercraft:tinkering/on_advance_notify
