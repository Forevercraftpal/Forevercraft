# ============================================================
# Tinkering (universal mini-line) — Load the current quest object into tnk_cur
# ============================================================
# Reads the current quest (by linear pointer ec.tnk_quest) out of the registry list and
# writes it to storage evercraft:tnk_cur quest, so check/advance/reward can read
# quest.type/target/count/reward/reward_amt without per-quest files.
#
# The registry list is 0-indexed; ec.tnk_quest is 1-based. This wrapper computes
# idx = ec.tnk_quest - 1, stuffs it into storage, and calls the macro.
# Run as @s = the player.

# Compute 0-based list index from the 1-based linear pointer.
execute store result score #tnk_idx ec.temp run scoreboard players get @s ec.tnk_quest
scoreboard players remove #tnk_idx ec.temp 1
execute store result storage evercraft:tnk_cur idx int 1 run scoreboard players get #tnk_idx ec.temp

# Macro-copy the quest object at that index into tnk_cur.quest.
function evercraft:tinkering/get_quest_macro with storage evercraft:tnk_cur
