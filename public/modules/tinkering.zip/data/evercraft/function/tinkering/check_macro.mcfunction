# ============================================================
# Tinkering (universal mini-line) — Check (macro body, dispatch on quest.type)
# ============================================================
# Called `with storage evercraft:tnk_cur o`, o = current quest
#   {id,title,desc,type,target,count,reward,reward_amt,chapter,...}.
# Sets #tnk_satisfied ec.temp to 1 iff the active quest's completion condition is met.
# Run as @s = the player.
#
# A macro can't branch on an int comparison inline, so we expose the threshold to ec.temp
# and route the per-TYPE decision to a tiny helper file:
#   - #tnk_count ec.temp     = quest.count
# Each helper at check_type/$(type) reads its OWN public mirror (held items / the
# ec.tnk_owned bitfield / the ec.cf_r10_granted tag) and sets #tnk_satisfied ec.temp. All
# helpers are READ-ONLY: they never write a fusion/funnel/accessory engine objective (the
# no-write proof). The types:
#   own_accessories — hold >=count accessory:true items (chapter intro: gather trinkets)
#   has_station     — own a Fusion Funnel (ec.cf_r10_granted) OR hold a Plinth item
#   fused_any       — any ec.tnk_owned bit set (ever fused anything)
#   fused_band      — ec.tnk_owned bit1 (forged the Band of Rings)
#   fused_hand      — ec.tnk_owned bit2 (forged the Hand of Creation)
#   fused_charm     — ec.tnk_owned bit3 (forged the Band of Charms — deferred sub-wave)
#   interlude       — never dispatched here (the check guard satisfies it first); a no-op
#                     check_type/interlude file exists only as a safety net.

# Expose the threshold for the helpers to compare against.
$scoreboard players set #tnk_count ec.temp $(count)

# Per-type decision (sets #tnk_satisfied ec.temp). $(type) is one of:
#   own_accessories | has_station | fused_any | fused_band | fused_hand | fused_charm
$function evercraft:tinkering/check_type/$(type) with storage evercraft:tnk_cur o
