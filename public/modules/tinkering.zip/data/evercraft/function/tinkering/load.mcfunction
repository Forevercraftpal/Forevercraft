# ============================================================
# Tinkering (universal mini-line) — Load (objective declarations + registry +
# schedule + Plinth tick kick)
# ============================================================
# The UNIVERSAL "combining artifacts" line (Council #2 Wave C7). A strictly-linear,
# data-driven quest line (q1..N in order, one active quest at a time), structural clone
# of adventure/kingdom/load (C6) / the Fisher's-Questline engine. Called from init (the
# pack load host) on /reload — see init.mcfunction "TINKERING (UNIVERSAL LINE)" block.
#
# Unlike the Crafter books (Cooking/Chemistry/Forging) and the Adventure lines, Tinkering
# is UNIVERSAL: it appears in BOTH chronicle tiers (S12) and is offered to EVERY player
# regardless of ec.chron_view. It is a teaching MINI-line (one chapter, ~12 beats) that
# introduces "combining artifacts" + hands the player their first trivial fusion (the
# Trinket Knot on the Tinkerer's Plinth). It is BALANCE-NEUTRAL by construction (DECISIONS
# #9 / R14): accessories apply while merely HELD (verified accessories/player_tick:9), so
# every fusion (Knot / Hand / Band) only frees inventory slots — no new power.
#
# NAMESPACE LOCK (Council #2, T1): ec.tk_* is OCCUPIED by the shields/taunt system (9
# objectives), so this line uses the council-locked ec.tnk_* family ONLY. It is a Fisher's
# clone that only READS public state (held items, ec.cf_r10_granted tag, ec.tnk_owned
# bits, ec.cf_r10... ) and WRITES none of those engines' objectives.
#
# ec.tnk_owned is a SAFE-OR multi-writer bitfield (the documented convention, identical to
# ec.special_titles): bit0 Knot / bit1 Band / bit2 Hand / bit3 Charm. It SUBSUMES round-1's
# optional ec.hand_owned / ec.band_owned singletons (N3) — one latch objective, not three.
# Each fusion's do_merge/confirm checks-the-bit-before-OR-ing (re-grant is a no-op).
#
# Declarations are guarded by #tnk_loaded ec.var so subsequent /reloads skip the
# re-declaration spam, matching the C5/C6 lines' polish.
#
# After declaring objectives, this fn ALWAYS (re)loads the registry (the quest data
# storage is NOT persisted across /reload) and (re)kicks the 20t catch-up scheduler AND
# the Plinth fusion tick with `replace` (so /reload never stacks duplicate schedules).

# === ONE-TIME OBJECTIVE DECLARATIONS (skipped on subsequent /reloads) ===
execute unless score #tnk_loaded ec.var matches 1 run function evercraft:tinkering/declare_objectives

# === REGISTRY (re)load — storage is volatile across /reload, must re-run ===
# The QUEST registry (the teaching mini-line q1..N).
function evercraft:tinkering/registry/load
# The FAMILY-RECIPE registry (the data-driven fusion lattice — Pebble-of-Creation + Band trees,
# read by the generic plinth/detect). Volatile across /reload like the quest registry, so it
# MUST re-run here. Adding a new family = a new row in recipes_batch_*, NO edit to this hook.
function evercraft:tinkering/registry/load_recipes

# === 20t CATCH-UP / INTERLUDE SCHEDULER (self-rescheduling, existence-gated) ===
# check_progress only does work for @a[scores={ec.tnk_active=1,ec.tnk_complete=0}] — no
# per-tick @a scan when nobody is on the line. It re-schedules itself; kick once here.
schedule function evercraft:tinkering/check_progress 20t replace

# === PLINTH FUSION TICK (self-rescheduling, existence-gated) ===
# The Tinkerer's Plinth altar (satchel_forge clone): tick scans for an accessory:true
# item entity sitting on a beacon, then runs the Knot / Hand detect chain. It is
# existence-gated INSIDE plinth/tick (returns immediately unless a beacon + an
# accessory:true item entity coexist), so with no ritual in progress it iterates over
# nothing. Kick once here with `replace`.
schedule function evercraft:tinkering/plinth/tick 1s replace

# === PLINTH DISPLAY TICK (cosmetic head-display break-detection + ambient FX) ===
# Separate from the fusion tick above (that one early-returns when no ritual is in progress,
# so it can't host break-detection). Existence-gated by `as @e[type=marker,tag=ec.tnk_pl_mk]`
# — costs ~nothing when no Plinth is placed. Self-reschedules; kick once with `replace`.
schedule function evercraft:tinkering/plinth/display_tick 1s replace
