# ============================================================
# Tinkering (universal mini-line) — get_quest macro body
# ============================================================
# Called with storage evercraft:tnk_cur containing {idx:<0-based index>}.
# Copies registry quest[idx] into evercraft:tnk_cur quest.
$data modify storage evercraft:tnk_cur quest set from storage evercraft:tnk_registry quests[$(idx)]
