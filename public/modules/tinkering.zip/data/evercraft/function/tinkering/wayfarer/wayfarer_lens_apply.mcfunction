# ============================================================
# Wayfarer's Lens — GRAND capstone: grant the full sense/travel/survey union, ZERO DR
# ============================================================
# Run as @s = the player, at @s. Called from artifacts/accessories/player_tick's consolidated fusion
# block (BEHIND the ec.has_accessory early-exit) when the player holds a wayfarers_lens:true item. The
# Wayfarer's Lens IS the union of all 17 Family-C Wayfarer charms by definition (the fusion `do`
# consumed the three sub-bindings / their leaves and spawned the Lens flagged wayfarers_lens — it does
# NOT carry the member items). So HERE we directly grant the bundle of every absorbed sense / travel /
# survey perk's PASSIVE half (the sneak-triggered survey/mob-vision halves are wired at the player_tick
# sneak block, where the wayfarers_lens id is added as an extra activation gate for every survey fn).
#
# BALANCE-NEUTRAL — ZERO DR (DECISIONS + lattice: the Wayfarer bundle ships NO Dream Rate, the
# lowest-risk capstone; Open-Decision 4: the +40/10% dodge went to Soulguard Aegis, so the Wayfarer's
# Lens gets NO dodge bonus of its own — the +1% from the two agile members is re-added in the m1
# ec.acc_dodge LEAF block in player_tick, one writer). No `*_luck` modifier is added or stripped (the
# whole family has zero DR members — nothing to consolidate or double-dip; m4 strip is a no-op here,
# documented). READ-ONLY on persistent state except the shared light subsystem (light_step is its sole
# writer; called here exactly as the loose Lantern-Lichen / Oracle Lens lines call it).
#
# ABSORBED MEMBERS (17): travelers_charm, worn_compass, glowstone_pendant, featherweight_stone,
# stormcatcher_shard, seers_compass, spelunkers_echo, wind_chime, cartographers_lens, wardens_echo
# (the 10 existing) + wayworn_tally, lantern_lichen_clasp, wanderers_whetcompass, wayfarers_sextant,
# voyagers_far_lens, loremasters_omni_codex, cartographers_astrolabe (the 7 new).

# --- 1) Sense union (effects). Night Vision (Seer/Spelunker/Glowstone/Warden/Monocle-style) at max. ---
effect give @s night_vision 15 0 false

# --- 2) Travel union (effects). Speed (Traveler/Wind Chime/Cartographer's Lens) + Haste (Spelunker/
#     Stormcatcher) + Slow Falling (Featherweight/Worn Compass) + Saturation (Cartographer's Lens). ---
effect give @s speed 5 0 false
effect give @s haste 5 0 false
effect give @s slow_falling 5 0 false
effect give @s saturation 3 0 false

# --- 3) Treasure ping (Spelunker's Echo's chest_ping — bounded sample, no scan). ---
function evercraft:artifacts/accessories/chest_ping

# --- 4) Transient local light (Lantern-Lichen Clasp — the SAME light_step, foot-cell light[level=10]
#     with strict prev-cell cleanup; never block-glow). ---
function evercraft:artifacts/accessories/wayfarer/light_step

# --- 5) Voyager's Far-Lens waypoint receive range (+96, REAL attribute, fixed-id — idempotent;
#     same id as the loose Far-Lens, so the loose accessory_cleanup covers the not-held case). ---
attribute @s waypoint_receive_range modifier add evercraft:voyagers_far_lens_wp 96 add_value

# --- 6) MAX SENSE RANGE mob-vision (the grand's headline): fire the WIDEST mob-vision — Warden's Echo
#     range (24 b, ALL non-player mobs) as the passive max-range reveal each tick the Lens is held,
#     superseding the loose Seer (16 b hostile-only) range. UNCONDITIONAL each tick (no cooldown: the
#     grand is the always-on "max sense range" bundle per the unit spec — a passive 10s glow refresh,
#     not the loose on-demand pulse). Bounded `@e[distance=..24]` selector, no scan. ---
execute at @s run effect give @e[type=!player,distance=..24] glowing 5 0 false
