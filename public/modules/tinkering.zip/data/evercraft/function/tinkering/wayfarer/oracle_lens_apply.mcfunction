# ============================================================
# Wayfarer's Lens tree — Oracle Lens perk re-apply (Fusion / Family C — cap-C)
# ============================================================
# Run as @s = the player, at @s. Called from artifacts/accessories/player_tick's consolidated fusion
# block (BEHIND the ec.has_accessory early-exit) when the player holds an oracle_lens:true item AND no
# superseding grand (Wayfarer's Lens) is held (the guard lives at the call site). The Oracle Lens is
# the SENSE-LADDER sub-binding (✦✦✦): it binds the Far Sight Lens (Seer's Compass + Warden's Echo) +
# Spelunker's Echo + Glowstone Pendant + Lantern-Lichen Clasp. It re-grants exactly their union:
#   - Night Vision (Warden's Echo + Spelunker's Echo + Glowstone Pendant — all grant NV passively)
#   - Haste I (Spelunker's Echo)
#   - Treasure ping (Spelunker's Echo — chest_ping)
#   - Transient local light (Lantern-Lichen Clasp — light_step, at @s)
#   - Seer's Compass + Warden's Echo SNEAK-TRIGGERED mob-vision: wired at the player_tick sneak block
#     (the oracle_lens id is added there as an extra activation gate, same on-demand idiom).
#
# BALANCE-NEUTRAL: NO DR / luck modifier (Wayfarer bundle = zero DR). READ-ONLY on persistent state
# EXCEPT the light subsystem's own ec.wf_l* lane (light_step is the sole writer of those, called here
# exactly as the loose Lantern-Lichen line calls it — so the one-writer law is preserved: light_step
# owns the held path whether the holder is the loose clasp or this consolidated node).

# --- 1) Passive sense union (effects) ---
effect give @s night_vision 15 0 false
effect give @s haste 5 0 false

# --- 2) Treasure ping (Spelunker's Echo's chest_ping — bounded sample, no scan) ---
function evercraft:artifacts/accessories/chest_ping

# --- 3) Transient local light (Lantern-Lichen Clasp — the SAME light_step the loose clasp calls;
#     places one light[level=10] at the foot cell with strict prev-cell cleanup, never block-glow). ---
function evercraft:artifacts/accessories/wayfarer/light_step
