# ============================================================
# Wayfarer's Lens tree — Far Sight Lens perk re-apply (Fusion / Family C — cap-C)
# ============================================================
# Run as @s = the player, at @s. Called from artifacts/accessories/player_tick's consolidated fusion
# block (BEHIND the ec.has_accessory early-exit) when the player holds a far_sight_lens:true item AND
# no superseding node (Oracle Lens / Wayfarer's Lens) is held (the guard lives at the call site).
# The Far Sight Lens is the leaf-pair (✦) — the cheap teach-fusion of the Oracle Lens line. It binds
# the Seer's Compass + Warden's Echo, so it re-grants exactly their union:
#   - Warden's Echo PASSIVE half: Night Vision (while held). [re-granted here]
#   - Seer's Compass + Warden's Echo SNEAK-TRIGGERED halves (mob-vision activate): wired at the
#     player_tick sneak-trigger block (the same `if predicate sneaking if items weapon.mainhand`
#     idiom the loose pieces use — the far_sight_lens id is added there as an extra activation gate).
#
# BALANCE-NEUTRAL: NO DR / luck modifier anywhere in Family C (the Wayfarer bundle ships zero DR, the
# lowest-risk bundle per the lattice + DECISIONS Open-Decision 4: the +40/10% dodge went to Soulguard
# Aegis, NOT the Wayfarer line). READ-ONLY on state: this fn writes no scoreboard.

# --- Grant the bound members' PASSIVE union (verbatim from the loose player_tick lines) ---
# Warden's Echo — Night Vision (passive while held). (Seer's Compass has no passive half; its
# Night Vision + Speed are part of its activate. The Oracle Lens adds those — the Far Sight Lens
# only carries the mob-vision sense, the cheaper rung.)
effect give @s night_vision 15 0 false
