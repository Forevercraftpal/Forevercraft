# ============================================================
# Wayfarer's Lens tree — Surveyor's Kit perk re-apply (Fusion / Family C — cap-C)
# ============================================================
# Run as @s = the player, at @s. Called from artifacts/accessories/player_tick's consolidated fusion
# block (BEHIND the ec.has_accessory early-exit) when the player holds a surveyors_kit:true item AND no
# superseding grand (Wayfarer's Lens) is held (the guard lives at the call site). The Surveyor's Kit is
# the READOUT/SURVEY sub-binding (✦✦✦): it binds the Cartographer's Lens + Wayworn Tally + Wanderer's
# Whetcompass + Wayfarer's Sextant + Voyager's Far-Lens + Loremaster's Omni-Codex + Cartographer's
# Astrolabe. It re-grants exactly their union:
#   - Speed I + Saturation (Cartographer's Lens — passive, here)
#   - Extended waypoint receive range (Voyager's Far-Lens — the REAL +96 waypoint_receive_range attr,
#     fixed-id evercraft:voyagers_far_lens_wp = the SAME id the loose Far-Lens uses, so it is idempotent
#     and the loose cleanup in accessory_cleanup covers the not-held case verbatim, here)
#   - Coord + facing readout (Wayworn Tally / Astrolabe — the PASSIVE half, SNEAK-SUPPRESSED): the
#     coord_readout call is at the player_tick call site (gated `unless predicate sneaking`), NOT here,
#     so it stays sneak-suppressed exactly like the loose tally and frees the sneak key for survey.
#   - Sneak-triggered survey/cycle (Whetcompass / Sextant / Far-Lens / Omni-Codex / Astrolabe):
#     wired at the player_tick sneak block (the surveyors_kit id is added there as an extra gate for
#     the bearing / sextant / structure_ping / codex cycle, same on-demand idiom).
#
# BALANCE-NEUTRAL: NO DR / luck modifier (Wayfarer bundle = zero DR). READ-ONLY on persistent state
# (the only attribute is the Far-Lens waypoint range, fixed-id, idempotent — m4 Layer-2).

# --- 1) Cartographer's Lens passive (effects) ---
effect give @s speed 5 0 false
effect give @s saturation 3 0 false

# --- 2) Voyager's Far-Lens waypoint receive range (+96, REAL attribute, fixed-id — idempotent) ---
# Same id as the loose Far-Lens (voyagers_far_lens_wp); two sources overwrite to one +96. The loose
# accessory_cleanup strips it when no far_lens / surveyors_kit / wayfarers_lens is held (cap-C extends
# that strip's guard at the call site so the Kit / grand re-grant survives the not-held check).
attribute @s waypoint_receive_range modifier add evercraft:voyagers_far_lens_wp 96 add_value
