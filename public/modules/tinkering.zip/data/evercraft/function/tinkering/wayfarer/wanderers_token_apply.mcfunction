# ============================================================
# Wayfarer's Lens tree — Wanderer's Token perk re-apply (Fusion / Family C — cap-C)
# ============================================================
# Run as @s = the player, at @s. Called from artifacts/accessories/player_tick's consolidated fusion
# block (BEHIND the ec.has_accessory early-exit) when the player holds a wanderers_token:true item AND
# no superseding grand (Wayfarer's Lens) is held (the guard lives at the call site). The Wanderer's
# Token is the MOVEMENT sub-binding (✦✦): it binds the Traveler's Charm + Wind Chime +
# Featherweight Stone + Worn Compass + Stormcatcher Shard. It re-grants exactly their union:
#   - Speed I  (Traveler's Charm + Wind Chime)
#   - Haste I  (Stormcatcher Shard)
#   - Slow Falling (Featherweight Stone — always; Worn Compass — only below Y=0, gated below)
# The +1% (+4) dodge the Traveler's Charm + Wind Chime each grant is re-added in the m1 ec.acc_dodge
# LEAF block in player_tick (gated on wanderers_token:true / wayfarers_lens:true), NOT here — dodge is
# a scoreboard lane with a single writer (player_tick), so it must stay in that one writer.
#
# BALANCE-NEUTRAL: NO DR / luck modifier (Wayfarer bundle = zero DR). READ-ONLY on state.

# --- Movement union (effects). All harmonize-neutral level-0/I auras (same as the loose lines). ---
effect give @s speed 5 0 false
effect give @s haste 5 0 false
effect give @s slow_falling 5 0 false
# Worn Compass's slow-fall is the redundant-with-Featherweight half; both members granted it loosely.
# Featherweight grants it always, so the union slow-fall above already covers the Worn Compass case —
# no extra line needed (the Token's slow-fall is the strictly-stronger always-on Featherweight form).
