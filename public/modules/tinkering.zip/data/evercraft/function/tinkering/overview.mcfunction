# ============================================================
# Tinkering (universal mini-line) — Overview page ("The Tinkerer's Workshop" tab)
# ============================================================
# A clean tellraw page reached from BOTH Grand Quests Tier-2 rows (Crafter + Adventurer,
# S12) and from a right-click on the Tinkerer's Codex book (book/on_use). Shows the
# player's current quest (title + desc + progress), lifetime completed count, the active
# beat's lore + [Skip ▸] via render_lore, AND a read-only "Workshop ledger" (the ✓/✗ of
# which fusions the player has unlocked/performed — tinkering/ledger, compute-on-open, T6).
# GUI/interaction-only; no /trigger. Run as @s = the player.
#
# Data-driven fields (current quest title / desc / count) live in the registry, so the
# variable lines go through overview_macro (mirrors show_objective split). Score-driven
# lines (progress, done) stay here.
#
# NOTE: ec.tnk_active == 2 means the line is COMPLETE (finish() bumped it); the completion
# block keys off ec.tnk_complete, which is set in lockstep. "Active" copy uses
# `ec.tnk_active matches 1` (NOT 1..) so a value-2 player sees the celebration, not the
# current-quest panel.

# Frame header.
tellraw @s ""
tellraw @s [{text:"═══════════════════════════════",color:"#5EC8D8"}]
tellraw @s [{text:"  ⚙ ",color:"#5EC8D8"},{text:"The Tinkerer's Workshop",color:"#5EC8D8",bold:true},{text:" ⚙",color:"#5EC8D8"}]
tellraw @s [{text:"  Knot • Bind • Fold — power in fewer slots",color:"gray",italic:true}]
tellraw @s [{text:"═══════════════════════════════",color:"#5EC8D8"}]
tellraw @s ""

# === Not yet started: prompt to begin (offer or menu). ===
execute unless score @s ec.tnk_active matches 1.. run tellraw @s [{text:"  ✦ ",color:"yellow"},{text:"You have not yet taken up the Tinkerer's craft.",color:"white"}]
execute unless score @s ec.tnk_active matches 1.. run tellraw @s [{text:"  Carry two trinkets at once and the Tinkerer will offer",color:"gray"}]
execute unless score @s ec.tnk_active matches 1.. run tellraw @s [{text:"  to teach you — or simply begin from this row.",color:"gray"}]
execute unless score @s ec.tnk_active matches 1.. run tellraw @s [{text:"  ",color:"dark_gray"},{text:"[Begin the Tinkerer's Path →]",color:"#5EC8D8",bold:true,hover_event:{action:"show_text",value:{text:"Start the Tinkerer's Path — a short, fully skippable, universal line.",color:"gray"}},click_event:{action:"run_command",command:"/function evercraft:tinkering/start"}}]
execute unless score @s ec.tnk_active matches 1.. run tellraw @s ""

# === Completed the whole line: celebrate, no current quest. ===
execute if score @s ec.tnk_complete matches 1 run tellraw @s [{text:"  ★ ",color:"gold"},{text:"The Tinkerer's Path Complete!",color:"gold",bold:true}]
execute if score @s ec.tnk_complete matches 1 run tellraw @s [{text:"  You are a Master Tinkerer — Plinth, Stand, and Funnel",color:"yellow"}]
execute if score @s ec.tnk_complete matches 1 run tellraw @s [{text:"  all answer to your hand.",color:"yellow"}]
execute if score @s ec.tnk_complete matches 1 run tellraw @s ""

# === Active + not complete: show the current quest (data-driven). ===
execute if score @s ec.tnk_active matches 1 unless score @s ec.tnk_complete matches 1 run function evercraft:tinkering/get_quest
execute if score @s ec.tnk_active matches 1 unless score @s ec.tnk_complete matches 1 run data modify storage evercraft:tnk_cur o set from storage evercraft:tnk_cur quest
execute if score @s ec.tnk_active matches 1 unless score @s ec.tnk_complete matches 1 run tellraw @s [{text:"  Current Quest",color:"yellow",bold:true}]
execute if score @s ec.tnk_active matches 1 unless score @s ec.tnk_complete matches 1 run function evercraft:tinkering/overview_macro with storage evercraft:tnk_cur o
execute if score @s ec.tnk_active matches 1 unless score @s ec.tnk_complete matches 1 run tellraw @s ""
# C0: re-show the active beat's lore + the [Skip ▸] button on the overview page.
execute if score @s ec.tnk_active matches 1 unless score @s ec.tnk_complete matches 1 run data modify storage evercraft:qp_cur o set from storage evercraft:tnk_cur quest
execute if score @s ec.tnk_active matches 1 unless score @s ec.tnk_complete matches 1 run function evercraft:quest_pacing/render_lore
execute if score @s ec.tnk_active matches 1 unless score @s ec.tnk_complete matches 1 run tellraw @s ""

# === Lifetime tally (always shown once started). ===
execute if score @s ec.tnk_active matches 1.. run tellraw @s [{text:"  Beats Completed: ",color:"gray"},{score:{name:"@s",objective:"ec.tnk_done"},color:"green",bold:true}]
execute if score @s ec.tnk_active matches 1.. run tellraw @s ""

# === WORKSHOP LEDGER (read-only ✓/✗ checklist, compute-on-open — T6) ===
function evercraft:tinkering/ledger

# Frame footer.
tellraw @s [{text:"═══════════════════════════════",color:"#5EC8D8"}]
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:item.book.page_turn master @s ~ ~ ~ 0.7 1.0
