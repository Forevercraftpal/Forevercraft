# ============================================================
# Tinkering (universal mini-line) — Show current objective
# ============================================================
# Reads the current quest from tnk_cur.quest (already loaded by get_quest) and prints its
# title + description as the active objective. Data-driven via macro (the quest text lives
# in the registry, not in per-quest files). Run as @s = the player.

# Surface the quest fields the macro needs at the top level of tnk_cur.
data modify storage evercraft:tnk_cur o set from storage evercraft:tnk_cur quest
function evercraft:tinkering/show_objective_macro with storage evercraft:tnk_cur o
