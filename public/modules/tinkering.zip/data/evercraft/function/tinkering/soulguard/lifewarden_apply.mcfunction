# ============================================================
# Soulguard Aegis tree — Lifewarden perk re-apply (Fusion / Family D — cap-D)
# ============================================================
# Run as @s = the player, at @s. Called from artifacts/accessories/player_tick's consolidated fusion
# block (a7, BEHIND the ec.has_accessory early-exit) when the player holds a lifewarden:true item AND
# no superseding grand (Soulguard Aegis) is held (the guard lives at the call site). The Lifewarden is
# the DEATH-SAVE / REGEN sub-binding (✦✦): it binds void_heart + heartstone + healers_salve. It
# re-grants their PASSIVE union here:
#   - Absorption II (Void Heart's passive ward)
#   - Regeneration I when wounded (Heartstone below 6 hearts + Healer's Salve always) — with the SAME
#     instant-heal fallback the loose pieces use when the player already has Regen II+ (ec.regen_capped,
#     set earlier this tick by the REGEN FALLBACK block).
# The DEATH-SAVE half (Void Heart's Void Recall) is NOT fired here — it routes through the ONE shared
# Soulguard death-save bucket (ec.cd_save / soulguard_save) at the player_tick a7 death-save block,
# where lifewarden is added as an activation gate. G6: one bucket, Absorption SET (max-not-sum).
#
# BALANCE-NEUTRAL: NO DR / luck modifier (Soulguard family = zero DR). READ-ONLY on persistent state
# (effects + the existing regen_fallback fn; no scoreboard write, no attribute). m4 strip is a no-op
# for this family (no member *_luck to double-dip) — documented.

# --- Void Heart: Absorption II (passive ward) ---
effect give @s absorption 5 1 false

# --- Heartstone + Healer's Salve: Regeneration when wounded (instant-heal fallback if Regen II+
#     already active, exactly like the loose Heartstone / Healer's Salve lines). Heartstone gates on
#     below-6-hearts; the Salve is always-on while held. We grant the union: Regen I whenever the
#     player is below 12 (covers both), with the fallback when capped. ---
execute if predicate evercraft:health_below_12 unless entity @s[tag=ec.regen_capped] run effect give @s regeneration 5 0 false
execute if predicate evercraft:health_below_12 if entity @s[tag=ec.regen_capped] run function evercraft:artifacts/accessories/regen_fallback
# Healer's Salve half: always-on Regen I while not capped (covers the full-HP case the Heartstone gate
# misses). When capped, the fallback above already fired if wounded; at full HP a fresh Regen is wasted
# anyway, so no extra fallback call is needed (matches the loose Salve line's behavior).
execute unless entity @s[tag=ec.regen_capped] run effect give @s regeneration 5 0 false
