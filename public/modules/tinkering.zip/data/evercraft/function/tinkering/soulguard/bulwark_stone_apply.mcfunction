# ============================================================
# Soulguard Aegis tree — Bulwark Stone perk re-apply (Fusion / Family D — cap-D)
# ============================================================
# Run as @s = the player, at @s. Called from artifacts/accessories/player_tick's consolidated fusion
# block (a7, BEHIND the ec.has_accessory early-exit) when the player holds a bulwark_stone:true item
# AND no superseding grand (Soulguard Aegis) is held (the guard lives at the call site). The Bulwark
# Stone is the RESIST / ELEMENTAL sub-binding (✦✦): it binds iron_talisman + phoenix_feather +
# blaze_core + sea_heart_relic + phantom_charm. It re-grants their PASSIVE union here:
#   - Resistance I (Iron Talisman)
#   - Fire Resistance (Phoenix Feather + Blaze Core) + a blaze flame trail particle
#   - Water Breathing + Dolphin's Grace + Conduit Power (Sea Heart Relic — the full sea kit)
#   - Slow Falling (Phantom Charm) + elytra durability protection (Phantom Glide)
# The +1% dodge the agile Phantom Charm member carries folds into the grand Soulguard Aegis's +40 (the
# m1 ec.acc_dodge LEAF block at the top of player_tick) — NOT re-added here (this sub-cap grants no
# dodge of its own; Open-Decision 4 routes the big dodge to the grand only).
#
# BALANCE-NEUTRAL: NO DR / luck modifier (Soulguard family = zero DR). READ-ONLY on persistent state
# (effects + particle + an item_modify on a held elytra; no scoreboard write, no attribute). m4 strip
# is a no-op for this family — documented.

# --- Iron Talisman: Resistance I ---
effect give @s resistance 5 0 false

# --- Phoenix Feather + Blaze Core: Fire Resistance + blaze flame trail ---
effect give @s fire_resistance 15 0 false
particle flame ~ ~0.1 ~ 0.2 0 0.2 0.01 1

# --- Sea Heart Relic: the full sea kit ---
effect give @s water_breathing 15 0 false
effect give @s dolphins_grace 5 0 false
effect give @s conduit_power 5 0 false

# --- Phantom Charm: Slow Falling + elytra durability protection (Phantom Glide) ---
effect give @s slow_falling 5 0 false
execute if items entity @s armor.chest minecraft:elytra run item modify entity @s armor.chest evercraft:repair_elytra
