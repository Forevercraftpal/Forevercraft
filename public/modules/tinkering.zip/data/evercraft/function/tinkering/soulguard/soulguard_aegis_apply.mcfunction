# ============================================================
# Soulguard Aegis — GRAND capstone: grant the full defensive ward union, ZERO DR
# ============================================================
# Run as @s = the player, at @s. Called from artifacts/accessories/player_tick's consolidated fusion
# block (a7, BEHIND the ec.has_accessory early-exit) when the player holds a soulguard_aegis:true item.
# The Soulguard Aegis IS the union of all 16 Family-D survival/totem wards by definition (the fusion
# `do` consumed the four sub-bindings / their leaves and spawned the Aegis flagged soulguard_aegis —
# it does NOT carry the member items). So HERE we directly grant the PASSIVE union of every absorbed
# ward by re-calling the four sub-binding applies (each is a pure idempotent effect-grant — no
# scoreboard write, no attribute, no double-apply harm). The DEATH-SAVE half + the +40 (10%) dodge are
# wired separately (see below).
#
# THE ONE BIG DODGE (Open-Decision 4 + D-DODGE 430-432): the Soulguard Aegis is THE one final-form that
# grants +40 (10%) dodge via m1's ec.acc_dodge lane. That +40 is added in the m1 ec.acc_dodge LEAF block
# at the TOP of player_tick (one writer = player_tick), NOT here — this apply grants only the defensive
# effect union. No leaf and no other capstone gets the +40; this is the sole +40 in the pack.
#
# G6 (one death-save bucket, Absorption = max not sum): the Aegis's death-save is NOT fired here — it
# routes through the ONE shared Soulguard bucket (ec.cd_save / soulguard_save) at the player_tick a7
# death-save block, where soulguard_aegis is an activation gate alongside grand_totem + lifewarden. So
# a Soulguard Aegis holder gets exactly ONE revive through one cooldown, never the three independent
# leaf saves (phoenix/soul/void) stacked.
#
# BALANCE-NEUTRAL: NO DR / luck modifier anywhere in this family (the Soulguard ships zero Dream Rate —
# the headline is the consolidated DEFENSE bundle + the +40 dodge, not any luck). No `*_luck` is added
# or stripped (no DR member to consolidate or double-dip; m4 Layer-1 strip targets the loose member
# auto-revive ids, handled at the call site, not a luck strip). READ-ONLY on persistent state (effects
# + particles + the bounded sub-cap auras; no scoreboard write, no attribute add).
#
# ABSORBED MEMBERS (16): iron_talisman, heartstone, healers_salve, berserkers_fang, phoenix_feather,
# void_heart, soul_protection, nether_star_shard, blaze_core, phantom_charm, sea_heart_relic,
# berserker_totem, warden_totem, wither_rose_crown, sculk_singularity, phoenix_totem (#6).

# Re-grant each sub-binding's passive ward union (idempotent effect-grants; the four together = the
# full 16-member defensive bundle). Order is irrelevant (all set/refresh effects).
function evercraft:tinkering/soulguard/grand_totem_apply
function evercraft:tinkering/soulguard/lifewarden_apply
function evercraft:tinkering/soulguard/bulwark_stone_apply
function evercraft:tinkering/soulguard/aura_ward_apply
