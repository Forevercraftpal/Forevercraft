# ============================================================
# Soulguard Aegis tree — Aura Ward perk re-apply (Fusion / Family D — cap-D)
# ============================================================
# Run as @s = the player, at @s. Called from artifacts/accessories/player_tick's consolidated fusion
# block (a7, BEHIND the ec.has_accessory early-exit) when the player holds an aura_ward:true item AND
# no superseding grand (Soulguard Aegis) is held (the guard lives at the call site). The Aura Ward is
# the AURA / CONDITIONAL sub-binding (✦✦): it binds nether_star_shard + wither_rose_crown +
# sculk_singularity + berserkers_fang. It re-grants their PASSIVE / conditional union here:
#   - Nether Star Shard: a beacon aura — Regeneration I + Resistance I to nearby players (16 b),
#     with the same Regen II+ instant-heal fallback the loose shard uses.
#   - Wither Rose Crown: Undead Weakness aura (16 b) + Strength I (harmonize-gated ec.h_str ..1).
#   - Sculk Singularity: a gravity pull on nearby hostiles + sculk_soul particles.
#   - Berserker's Fang: Strength I below 50% HP + Haste I below 30% HP (the low-HP berserk).
# The +1% dodge the agile Berserker's Fang member carries folds into the grand Soulguard Aegis's +40
# (the m1 ec.acc_dodge LEAF block at the top of player_tick) — NOT re-added here.
#
# BALANCE-NEUTRAL: NO DR / luck modifier (Soulguard family = zero DR). READ-ONLY on persistent state
# (effects to nearby + particle + a bounded gravity tp on hostiles + the existing regen_fallback;
# no scoreboard write, no attribute). m4 strip is a no-op for this family — documented.

# --- Nether Star Shard: beacon aura (Regen + Resistance to nearby players, 16 b) + Regen-cap fallback ---
effect give @a[distance=..16] regeneration 5 0 false
effect give @a[distance=..16] resistance 5 0 false
execute as @a[distance=..16] if predicate evercraft:has_regen_above_0 run function evercraft:artifacts/accessories/regen_fallback

# --- Wither Rose Crown: Undead Weakness aura (16 b) + Strength I (harmonize-gated) ---
effect give @e[type=#minecraft:undead,distance=..16] weakness 5 4 false
execute if score @s ec.h_str matches ..1 run effect give @s strength 5 0 false

# --- Sculk Singularity: gravity pull on nearby hostiles + sculk particles ---
execute as @e[type=#evercraft:hostile_mobs,distance=2..8,limit=3] at @s facing entity @p feet run tp @s ^ ^ ^0.3
particle sculk_soul ~ ~1 ~ 1 0.5 1 0.02 2

# --- Berserker's Fang: Strength I below 50% HP + Haste I below 30% HP (low-HP berserk) ---
execute if predicate evercraft:health_below_10 run effect give @s strength 5 0 false
execute if predicate evercraft:health_below_6 run effect give @s haste 5 0 false
