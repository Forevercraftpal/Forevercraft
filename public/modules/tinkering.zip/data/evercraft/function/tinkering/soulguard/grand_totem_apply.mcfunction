# ============================================================
# Soulguard Aegis tree — Grand Totem perk re-apply (Fusion / Family D — cap-D)
# ============================================================
# Run as @s = the player, at @s. Called from artifacts/accessories/player_tick's consolidated fusion
# block (a7, BEHIND the ec.has_accessory early-exit) when the player holds a grand_totem:true item AND
# no superseding grand (Soulguard Aegis) is held (the guard lives at the call site). The Grand Totem is
# the FOUR-TOTEM sub-binding (✦✦✦): it binds berserker_totem + warden_totem + soul_protection +
# Phoenix Totem. It re-grants exactly their PASSIVE union here:
#   - Strength I + Haste I (Berserker Totem)
#   - Night Vision (Warden Totem)
#   - Resistance I + Absorption I (Soul Protection — passive ward)
# The DEATH-SAVE halves (soul_protection's Soul Shield + Phoenix Totem's auto-revive) are NOT fired
# here — they route through the ONE shared Soulguard death-save bucket (ec.cd_save / soulguard_save) at
# the player_tick a7 death-save block, where grand_totem is added as an activation gate. G6: one bucket,
# Absorption SET (max-not-sum) — so a Grand Totem holder gets ONE revive, not four stacked saves.
#
# BALANCE-NEUTRAL: NO DR / luck modifier (Soulguard family = zero DR). READ-ONLY on persistent state
# (effects only; no scoreboard write, no attribute). m4 strip is a no-op for this family (no member
# *_luck to double-dip) — documented; the only multi-copy concern (the death-save) is handled by the
# shared cooldown bucket at the call site.

# --- Berserker Totem: Strength I + Haste I ---
effect give @s strength 5 0 false
effect give @s haste 5 0 false

# --- Warden Totem: Night Vision ---
effect give @s night_vision 15 0 false

# --- Soul Protection (passive ward): Resistance I + Absorption I ---
effect give @s resistance 5 0 false
effect give @s absorption 5 0 false
