# === CHEST-NODE — MATERIALS SUB-CHANNEL (SPEC §5: reuse existing system tables) ===
# Run as @s, at the player (positioned at the node). Picks ONE system's material table and gives a
# small material reward — the "smaller reward layer alongside the big crate channel" (§10). Reuses the
# EXISTING forging/cooking/alchemy/glyph tables (no new material content). Aquatic + sunken-treasure
# mats are BIOME-GATED to beach/river/ocean (in_water / is_ocean / is_river predicates exist, §5).
# #cn_invfull (set by the caller) routes give-vs-drop.

execute store result score #cn_matpick ec.temp run random value 1..100

# --- Aquatic / sunken mats — ONLY at/near water (is_ocean OR is_river OR standing in water). ---
# Checked FIRST so a waterside chest can roll the aquatic flavor; on dry land this whole branch is
# skipped and the pick falls through to the land material tables below.
scoreboard players set #cn_aqua ec.temp 0
execute if predicate evercraft:biome/is_ocean run scoreboard players set #cn_aqua ec.temp 1
execute if predicate evercraft:biome/is_river run scoreboard players set #cn_aqua ec.temp 1
execute if predicate evercraft:in_water run scoreboard players set #cn_aqua ec.temp 1
# Aquatic chest: 35% sunken-treasure (ocean treasure table), else aquatic reagent fish (the splash catch
# pool doubles as the aquatic-mat source). Only reachable when #cn_aqua=1.
execute if score #cn_aqua ec.temp matches 1 if score #cn_matpick ec.temp matches 1..35 if score #cn_invfull ec.var matches 0 run loot give @s loot evercraft:treasure/chests/ocean/common
execute if score #cn_aqua ec.temp matches 1 if score #cn_matpick ec.temp matches 1..35 if score #cn_invfull ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:treasure/chests/ocean/common
execute if score #cn_aqua ec.temp matches 1 if score #cn_matpick ec.temp matches 36..100 if score #cn_invfull ec.var matches 0 run loot give @s loot evercraft:fishing/splash_nodes/catch_overworld
execute if score #cn_aqua ec.temp matches 1 if score #cn_matpick ec.temp matches 36..100 if score #cn_invfull ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:fishing/splash_nodes/catch_overworld
execute if score #cn_aqua ec.temp matches 1 run return 0

# --- Land material tables (forging / cooking / alchemy / glyph), evenly weighted. ---
# Crafting chests (ctype 1) lean toward the crafting-system mats; plain/adventurer are uniform.
execute if score #cn_matpick ec.temp matches 1..30 if score #cn_invfull ec.var matches 0 run loot give @s loot evercraft:prospect/forge_materials
execute if score #cn_matpick ec.temp matches 1..30 if score #cn_invfull ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:prospect/forge_materials
execute if score #cn_matpick ec.temp matches 31..55 if score #cn_invfull ec.var matches 0 run loot give @s loot evercraft:cooking/artifacts/materials/drop_t1
execute if score #cn_matpick ec.temp matches 31..55 if score #cn_invfull ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:cooking/artifacts/materials/drop_t1
execute if score #cn_matpick ec.temp matches 56..80 if score #cn_invfull ec.var matches 0 run loot give @s loot evercraft:alchemy/reagents/botanical_t1
execute if score #cn_matpick ec.temp matches 56..80 if score #cn_invfull ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:alchemy/reagents/botanical_t1
execute if score #cn_matpick ec.temp matches 81..100 if score #cn_invfull ec.var matches 0 run loot give @s loot evercraft:glyphforge/glyphforge_drop
execute if score #cn_matpick ec.temp matches 81..100 if score #cn_invfull ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:glyphforge/glyphforge_drop
