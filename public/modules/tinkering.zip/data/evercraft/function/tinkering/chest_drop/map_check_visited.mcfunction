# === CHEST-NODE — LOCATED-MAP global VISITED check (macro, §14.10) ===
# Called `with storage evercraft:chest_maps temp` -> {struct:<name>}.
# The global visited-set is stored as a compound: visited.<struct> = 1b (server-wide, shared across all
# players). A present key = some player has already been pointed at this struct -> soft HIT (the caller
# re-rolls ONCE, then accepts). Sets #cn_maphit ec.temp 1 on a hit. Read-only — no writes.
$execute if data storage evercraft:chest_maps visited.$(struct) run scoreboard players set #cn_maphit ec.temp 1
