# === CHEST-NODE — 70% GOODIES / PRANKS / TRAPS + MATERIALS CHANNEL (SPEC §5) ===
# Run as @s, at the player. The crate roll missed (70% branch). Hands a designer's-choice assortment:
# a goodies table (fun items + a few harmless pranks), a MATERIALS sub-channel (reuse the existing
# forging/cooking/alchemy/glyph tables, biome-gated aquatic/sunken), and a small chance of an extra
# in-loot prank-trap. #cn_ctype (1=Crafting/2=Adventurer/3=plain) + #cn_invfull are set by the caller.

# --- a) Always a base goodies roll (the "random assortment of goodies and pranks"). ---
execute if score #cn_invfull ec.var matches 0 run loot give @s loot evercraft:tinkering/chest_drop/goodies
execute if score #cn_invfull ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:tinkering/chest_drop/goodies

# --- b) MATERIALS sub-channel (reuse existing system tables; ~60% of goodies chests carry mats). ---
execute store result score #cn_matroll ec.temp run random value 1..100
execute if score #cn_matroll ec.temp matches 1..60 run function evercraft:tinkering/chest_drop/give_materials

# --- c) In-loot prank-trap (§5: the 70% includes traps): a small 8% extra prank via the dispatcher.
#        Honors the same Appraise A4 (L100) full-disarm so a master never gets pranked here either. ---
execute store result score #cn_prankroll ec.temp run random value 1..100
execute unless score @s ec.caffl_gw matches 100.. if score #cn_prankroll ec.temp matches 1..8 run function evercraft:chest_nodes/traps/dispatch
