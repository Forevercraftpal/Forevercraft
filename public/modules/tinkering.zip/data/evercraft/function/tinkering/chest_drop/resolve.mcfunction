# === CHEST-NODE — LOOT RESOLVE (SPEC §5 / PLAN §5 / §10.1 depth<=1) ===
# Run as @s, at the player (positioned at the node), from chest_nodes/do_open_success. Decides the
# chest's contents: a 30%(+boost) CRATE CHANNEL or else the 70% GOODIES-PRANKS-TRAPS channel (which
# folds in the MATERIALS sub-channel). The Dreamy + Appraise crate-threshold boost is in #cn_cratebost
# (set by do_open_success). ⚠️ Crate-nesting depth <=1 (§10.1): a crate from a chest resolves to a
# crate-ITEM the player places, which yields ITEMS — never another chest-crate. The crate-item loot
# tables already contain no chest-crates, so depth<=1 holds structurally.
#
# Reads gth_temp.ctype (1=Crafting/2=Adventurer/3=plain) — still pinned from do_open — to bucket the
# accessory channel + bias the materials channel.

execute store result score #cn_ctype ec.temp run data get storage evercraft:gth_temp ctype
execute store result score #cn_invfull ec.var run function evercraft:util/check_inv_full

# --- Top split: crate channel (<= 30 + boost) vs the 70% goodies channel. ---
scoreboard players set #cn_cratethresh ec.temp 30
execute if score #cn_cratebost ec.temp matches 1.. run scoreboard players operation #cn_cratethresh ec.temp += #cn_cratebost ec.temp
# Never let the boosted threshold swallow the whole roll — cap at 80 so the goodies channel survives.
execute if score #cn_cratethresh ec.temp matches 81.. run scoreboard players set #cn_cratethresh ec.temp 80

execute store result score #cn_lootroll ec.temp run random value 1..100
execute if score #cn_lootroll ec.temp <= #cn_cratethresh ec.temp run return run function evercraft:tinkering/chest_drop/crate_channel
# Else: the 70% goodies-pranks-traps channel (materials folded in).
function evercraft:tinkering/chest_drop/goodies_channel
