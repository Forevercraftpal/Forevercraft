# Chest Node — shared crate-drop flourish (sound + particle + actionbar). Run as @s, at the player.
# Fired by every crate-channel giver so a crate pull always feels like a moment.
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.amethyst_block.resonate master @s ~ ~ ~ 0.9 1.2
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.player.levelup master @s ~ ~ ~ 0.4 1.5
execute if score @s ec.fx_vis matches 1.. run particle minecraft:totem_of_undying ~ ~1 ~ 0.4 0.5 0.4 0.12 14
data modify storage evercraft:notify stage.c set value [{text:"⚙ ",color:"#B87333"},{text:"A crate",color:"#B87333",bold:true},{text:" lay within the chest!",color:"gray"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
