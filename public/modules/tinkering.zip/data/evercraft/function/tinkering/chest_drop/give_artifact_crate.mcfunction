# Chest Node — give an ARTIFACT crate item (tier-weighted barrel the player places). Run as @s.
# Tier weights mirror a chest's "rare-floor with flourishes" shape (common 55 / uncommon 25 / rare 12 /
# ornate 5 / exquisite 2 / mythical 1). The crate ITEM (crates/items/artifact_<tier>) resolves to an
# ARTIFACT when placed — depth<=1 (no chest-crate inside). #cn_invfull routes give-vs-drop.
execute store result score #cn_tier ec.temp run random value 1..100
# DR down-roll (crate DR audit 2026-06-06): cap the rolled tier to the opener's Dream Rate, matching
# mob/fishing/harvest gating (Ornate>=5 / Exquisite>=15 / Mythical>=25; luck x10 = 50/150/250). Clamp the
# 1..100 roll down to the TOP of the highest tier they qualify for (rare ..92 / ornate ..97 / exq ..99).
execute store result score #cn_dr ec.temp run attribute @s luck get 10
execute if score #cn_dr ec.temp matches ..49 if score #cn_tier ec.temp matches 93.. run scoreboard players set #cn_tier ec.temp 92
execute if score #cn_dr ec.temp matches ..149 if score #cn_tier ec.temp matches 98.. run scoreboard players set #cn_tier ec.temp 97
execute if score #cn_dr ec.temp matches ..249 if score #cn_tier ec.temp matches 100 run scoreboard players set #cn_tier ec.temp 99
execute if score #cn_tier ec.temp matches 1..55 if score #cn_invfull ec.var matches 0 run loot give @s loot evercraft:crates/items/artifact_common
execute if score #cn_tier ec.temp matches 1..55 if score #cn_invfull ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:crates/items/artifact_common
execute if score #cn_tier ec.temp matches 56..80 if score #cn_invfull ec.var matches 0 run loot give @s loot evercraft:crates/items/artifact_uncommon
execute if score #cn_tier ec.temp matches 56..80 if score #cn_invfull ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:crates/items/artifact_uncommon
execute if score #cn_tier ec.temp matches 81..92 if score #cn_invfull ec.var matches 0 run loot give @s loot evercraft:crates/items/artifact_rare
execute if score #cn_tier ec.temp matches 81..92 if score #cn_invfull ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:crates/items/artifact_rare
execute if score #cn_tier ec.temp matches 93..97 if score #cn_invfull ec.var matches 0 run loot give @s loot evercraft:crates/items/artifact_ornate
execute if score #cn_tier ec.temp matches 93..97 if score #cn_invfull ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:crates/items/artifact_ornate
execute if score #cn_tier ec.temp matches 98..99 if score #cn_invfull ec.var matches 0 run loot give @s loot evercraft:crates/items/artifact_exquisite
execute if score #cn_tier ec.temp matches 98..99 if score #cn_invfull ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:crates/items/artifact_exquisite
execute if score #cn_tier ec.temp matches 100 if score #cn_invfull ec.var matches 0 run loot give @s loot evercraft:crates/items/artifact_mythical
execute if score #cn_tier ec.temp matches 100 if score #cn_invfull ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:crates/items/artifact_mythical
function evercraft:tinkering/chest_drop/crate_flourish
