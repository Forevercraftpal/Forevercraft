# === CHEST-NODE — LOCATED-MAP per-player GIVEN check (macro, §14.10) ===
# Called `with storage evercraft:chest_maps temp` -> {uuid:<UUID[0] int>, struct:<name>}.
# Per-player no-repeat is stored as a compound: given.u<uuid>.<struct> = 1b (a per-player set of the
# structures already mapped). A present key = this player already has a map to this struct -> HIT.
# Sets #cn_maphit ec.temp 1 on a repeat (the caller re-rolls). Read-only — no writes.
$execute if data storage evercraft:chest_maps given.u$(uuid).$(struct) run scoreboard players set #cn_maphit ec.temp 1
