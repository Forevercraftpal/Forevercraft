# === CHEST-NODE — CRATE CHANNEL (SPEC §5: Accessory 30 / Companion 30 / Artifact 30 / Regular 10) ===
# Run as @s, at the player. The 30%(+boost) crate roll landed. Pick ONE crate type by weight, then
# hand the player that crate ITEM (a barrel they place — the crate_anim system reveals it). Depth<=1:
# the crate item resolves to ITEMS, never another chest-crate. #cn_ctype (1=Crafting/2=Adventurer/
# 3=plain) buckets the accessory channel. #cn_invfull (set by resolve) routes give-vs-drop.

execute store result score #cn_cratepick ec.temp run random value 1..100

# --- Accessory crate (30%) — guaranteed an accessory, bucketed by key/chronicle (§6). The full
#     accessory-crate machinery (3 sets × 6 tiers) lands in P4a; resolve_drop is the resolver entry. ---
execute if score #cn_cratepick ec.temp matches 1..30 run return run function evercraft:accessory_crates/resolve_drop

# --- Companion crate (30%) — give a companion crate item (tier-weighted, mirrors the artifact tiers). ---
execute if score #cn_cratepick ec.temp matches 31..60 run return run function evercraft:tinkering/chest_drop/give_companion_crate

# --- Artifact crate (30%) — give an artifact crate item (tier-weighted). ---
execute if score #cn_cratepick ec.temp matches 61..90 run return run function evercraft:tinkering/chest_drop/give_artifact_crate

# --- Regular achievement crate (10%) — tiers rare 80 / ornate 10 / exquisite 7 / mythical 3 (§5). ---
function evercraft:tinkering/chest_drop/give_regular_crate
