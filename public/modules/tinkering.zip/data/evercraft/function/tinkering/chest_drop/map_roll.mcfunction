# === CHEST-NODE — +5% LOCATED-MAP ROLL (SPEC §5 / §14.10 — SHIPPED, fully functional) ===
# Run as @s, at the player. An INDEPENDENT +5% roll atop all other chest drops (it does NOT consume the
# crate/goodies channel — a chest can yield BOTH a crate AND a map). v1 maps are FUNCTIONAL located maps
# (Joseph): a located map pointing at a thematic structure (Adventurer chest -> ancient_city/mansion/
# monument; Crafting chest -> village/trail_ruins/mineshaft), with per-player NO-REPEAT + a global
# visited-set soft-avoid (§14.10). The map GIVE + the no-repeat bookkeeping are LIVE (map_grant ->
# map_select -> map_award). This file owns the 5% gate + the dispatch hook.
#
# §14.10 no-repeat (P6): hard-exclude per-player repeats via storage evercraft:chest_maps given.<uuid>;
# the global storage evercraft:chest_maps visited set is a one-retry soft-avoid (re-roll once on a hit,
# accept the 2nd). This file owns the 5% gate; chest_drop/map_grant (P6) owns the target selection.

# The independent +5% roll. On a miss, no map this chest.
execute store result score #cn_maproll ec.temp run random value 1..100
execute unless score #cn_maproll ec.temp matches 1..5 run return 0

# Hit: dispatch to the located-map grant (SHIPPED — map_grant selects a structure honoring the
# per-player hard no-repeat + global soft-avoid, then map_award gives the real located map).
function evercraft:tinkering/chest_drop/map_grant
