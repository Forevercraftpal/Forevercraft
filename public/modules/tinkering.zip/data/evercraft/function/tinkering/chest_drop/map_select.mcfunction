# === CHEST-NODE — LOCATED-MAP STRUCTURE SELECT (recursive roll, §14.10) ===
# Run as @s, at the player, from map_grant (and self, on a re-roll). Rolls ONE structure id from the
# ctype pool, resolves it to a struct name in storage, then applies the no-repeat law:
#   HARD per-player exclude (given.u<uuid>.<struct>)  -> re-roll (decrement #cn_maptries, recurse).
#   SOFT global visited (visited.<struct>)            -> re-roll ONCE (#cn_mapsoft), accept the 2nd.
# Falls through to map_award (the give + bookkeeping) once a destination is accepted.
# Pools: Adventurer(2)={1,2,3}  Crafting(1)={4,5,6}  plain(3)={1..6}.

# --- Roll a structure id within the active ctype pool. ---
execute if score #cn_mapctype ec.temp matches 2 store result score #cn_mapid ec.temp run random value 1..3
execute if score #cn_mapctype ec.temp matches 1 store result score #cn_mapid ec.temp run random value 4..6
execute unless score #cn_mapctype ec.temp matches 1..2 store result score #cn_mapid ec.temp run random value 1..6

# --- Resolve the rolled id -> struct name string into storage temp.struct (drives the macro paths). ---
execute if score #cn_mapid ec.temp matches 1 run data modify storage evercraft:chest_maps temp.struct set value "ancient_city"
execute if score #cn_mapid ec.temp matches 2 run data modify storage evercraft:chest_maps temp.struct set value "mansion"
execute if score #cn_mapid ec.temp matches 3 run data modify storage evercraft:chest_maps temp.struct set value "monument"
execute if score #cn_mapid ec.temp matches 4 run data modify storage evercraft:chest_maps temp.struct set value "village"
execute if score #cn_mapid ec.temp matches 5 run data modify storage evercraft:chest_maps temp.struct set value "trail_ruins"
execute if score #cn_mapid ec.temp matches 6 run data modify storage evercraft:chest_maps temp.struct set value "mineshaft"

# --- HARD per-player exclude: if this struct is already in given.u<uuid>, re-roll (while we have tries).
#     The check reads given.u$(uuid).$(struct); a hit sets #cn_maphit=1 via the macro. ---
scoreboard players set #cn_maphit ec.temp 0
function evercraft:tinkering/chest_drop/map_check_given with storage evercraft:chest_maps temp
execute if score #cn_maphit ec.temp matches 1 if score #cn_maptries ec.temp matches 1.. run scoreboard players remove #cn_maptries ec.temp 1
execute if score #cn_maphit ec.temp matches 1 if score #cn_maptries ec.temp matches 1.. run return run function evercraft:tinkering/chest_drop/map_select
# (If tries are exhausted AND it is still a per-player repeat, we fall through and accept it — the bonus
#  map never silently vanishes; the player simply re-gets a structure they already mapped.)

# --- SOFT global visited: re-roll ONCE on a hit, then accept whatever the 2nd roll is (§14.10).
#     Mirrors the hard-exclude decrement-then-recurse guard above. #cn_mapsoft is seeded 2 in map_grant:
#     1st visited hit -> decrement 2->1 -> recurse (1 matches 1.. = true) = the single re-roll;
#     2nd visited hit -> decrement 1->0 -> recurse guard (0) false -> fall through to award (accept the
#     2nd). Terminates even if every pool structure is globally visited (exactly one re-roll, then accept). ---
scoreboard players set #cn_maphit ec.temp 0
function evercraft:tinkering/chest_drop/map_check_visited with storage evercraft:chest_maps temp
execute if score #cn_maphit ec.temp matches 1 if score #cn_mapsoft ec.temp matches 1.. run scoreboard players remove #cn_mapsoft ec.temp 1
execute if score #cn_maphit ec.temp matches 1 if score #cn_mapsoft ec.temp matches 1.. run return run function evercraft:tinkering/chest_drop/map_select

# --- Accepted destination: give the located map + record it (per-player given + global visited). ---
function evercraft:tinkering/chest_drop/map_award with storage evercraft:chest_maps temp
