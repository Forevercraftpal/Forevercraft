# Chest Node — DREAMY good-find crate (the "Dreamy Pull boosts the crate" payoff, §2). Run as @s, at
# the player, from dreamy_pull/give_good_find on a landed source-5 (chest) pull. Hands a crate via the
# crate channel directly (the dreamy win IS the crate). Re-seeds the give-vs-drop + ctype scratch that
# the crate channel reads (the resolve-time scratch may have been churned by the minigame). gth_temp.ctype
# is still pinned from this open, so the accessory bucket stays correct.
execute store result score #cn_invfull ec.var run function evercraft:util/check_inv_full
execute store result score #cn_ctype ec.temp run data get storage evercraft:gth_temp ctype
function evercraft:tinkering/chest_drop/crate_channel
