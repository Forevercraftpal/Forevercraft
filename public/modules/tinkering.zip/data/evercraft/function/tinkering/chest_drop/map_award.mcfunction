# === CHEST-NODE — LOCATED-MAP award + bookkeeping (macro, §5 / §14.10) ===
# Called `with storage evercraft:chest_maps temp` -> {uuid:<UUID[0] int>, struct:<name>}, run as @s at
# the player. Gives the FUNCTIONAL located map for the accepted structure, then records the no-repeat
# bookkeeping: per-player given.u<uuid>.<struct>=1b (hard exclude on future rolls) + global
# visited.<struct>=1b (soft-avoid). Inventory-full safe: drop at feet if the inventory cannot take it.
# The per-structure located-map loot tables live at evercraft:tinkering/chest_drop/maps/<struct>.

# --- Give the located map (drop at feet if the inventory is full). ---
$execute if score #cn_invfull ec.var matches 0 run loot give @s loot evercraft:tinkering/chest_drop/maps/$(struct)
$execute if score #cn_invfull ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:tinkering/chest_drop/maps/$(struct)

# --- Record per-player given (hard no-repeat for THIS player) + global visited (soft-avoid). ---
$data modify storage evercraft:chest_maps given.u$(uuid).$(struct) set value 1b
$data modify storage evercraft:chest_maps visited.$(struct) set value 1b

# --- Discovery cue: a thematic chime + an actionbar so the bonus map reads clearly. ---
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:ui.cartography_table.take_result master @s ~ ~ ~ 0.7 1.1
data modify storage evercraft:notify stage.c set value [{"text":"✧ ","color":"#5BC8B8"},{"text":"A located map surfaced from the chest.","color":"white"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit

# --- Clean the per-call scratch so a later map roll re-reads fresh struct/uuid. ---
data remove storage evercraft:chest_maps temp
