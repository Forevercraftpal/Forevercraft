# === CHEST-NODE — FUNCTIONAL LOCATED-MAP GRANT (P6 — §5 / §14.10) ===
# Run as @s, at the player, from chest_drop/map_roll on a landed +5% map roll. Gives a REAL
# minecraft:exploration_map-style located map pointing at a thematic structure, with the no-repeat law:
#   - destination pool by gth_temp.ctype: Adventurer (2) -> ancient_city/mansion/monument;
#     Crafting (1) -> village/trail_ruins/mineshaft; plain (3) -> the neutral union of both pools.
#   - HARD-exclude per-player repeats: storage evercraft:chest_maps given.u<UUID[0]>.<struct> (re-roll).
#   - SOFT-avoid the global visited-set: storage evercraft:chest_maps visited.<struct> (ONE retry,
#     accept the 2nd roll — §14.10).
# Structure ids (rolled 1..6): 1=ancient_city 2=mansion 3=monument 4=village 5=trail_ruins 6=mineshaft.
# The exploration_map idiom mirrors loot_table/fishing/crate_contents/ornate/1 (the build reference).

# Stash the player's UUID-key part (UUID[0]) for the per-player given.<uuid> storage path (mirrors the
# village-rep u$(uuid) idiom — UUID[0] is unique enough for a per-player no-repeat key).
execute store result storage evercraft:chest_maps temp.uuid int 1 run data get entity @s UUID[0]

# Read the chest's ctype (1=Crafting/2=Adventurer/3=plain), still pinned from do_open.
scoreboard players set #cn_mapctype ec.temp 3
execute store result score #cn_mapctype ec.temp run data get storage evercraft:gth_temp ctype

# Seed the per-player-repeat retry budget (hard exclude: re-roll up to 8 times to find an un-given
# structure; if every structure in the pool is already given, the last roll is accepted so a map still
# drops — the +5% bonus never silently vanishes). #cn_mapsoft is the one global-visited soft retry
# (seeded 2 so map_select's decrement-then-recurse guard yields EXACTLY one re-roll; see map_select).
scoreboard players set #cn_maptries ec.temp 8
scoreboard players set #cn_mapsoft ec.temp 2
function evercraft:tinkering/chest_drop/map_select
