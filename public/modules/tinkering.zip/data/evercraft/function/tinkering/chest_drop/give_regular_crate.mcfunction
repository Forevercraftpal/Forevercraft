# Chest Node — give a REGULAR (achievement) crate item. Run as @s. Regular crate tiers per SPEC §5:
# rare minimum 80% / ornate 10% / exquisite 7% / mythical 3% (use the achievements/crates/<tier>
# barrels). The crate ITEM resolves to items when placed — depth<=1. #cn_invfull routes give-vs-drop.
execute store result score #cn_tier ec.temp run random value 1..100
# DR down-roll (crate DR audit 2026-06-06): cap the rolled tier to the opener's Dream Rate, matching
# mob/fishing/harvest gating (Ornate>=5 / Exquisite>=15 / Mythical>=25; luck x10 = 50/150/250). Regular
# crate shape is rare ..80 / ornate ..90 / exq ..97 / myth 98..; clamp down to the top of the qualifying tier.
execute store result score #cn_dr ec.temp run attribute @s luck get 10
execute if score #cn_dr ec.temp matches ..49 if score #cn_tier ec.temp matches 81.. run scoreboard players set #cn_tier ec.temp 80
execute if score #cn_dr ec.temp matches ..149 if score #cn_tier ec.temp matches 91.. run scoreboard players set #cn_tier ec.temp 90
execute if score #cn_dr ec.temp matches ..249 if score #cn_tier ec.temp matches 98.. run scoreboard players set #cn_tier ec.temp 97
execute if score #cn_tier ec.temp matches 1..80 if score #cn_invfull ec.var matches 0 run loot give @s loot evercraft:achievements/crates/rare
execute if score #cn_tier ec.temp matches 1..80 if score #cn_invfull ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:achievements/crates/rare
execute if score #cn_tier ec.temp matches 81..90 if score #cn_invfull ec.var matches 0 run loot give @s loot evercraft:achievements/crates/ornate
execute if score #cn_tier ec.temp matches 81..90 if score #cn_invfull ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:achievements/crates/ornate
execute if score #cn_tier ec.temp matches 91..97 if score #cn_invfull ec.var matches 0 run loot give @s loot evercraft:achievements/crates/exquisite
execute if score #cn_tier ec.temp matches 91..97 if score #cn_invfull ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:achievements/crates/exquisite
execute if score #cn_tier ec.temp matches 98..100 if score #cn_invfull ec.var matches 0 run loot give @s loot evercraft:achievements/crates/mythical
execute if score #cn_tier ec.temp matches 98..100 if score #cn_invfull ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:achievements/crates/mythical
function evercraft:tinkering/chest_drop/crate_flourish
