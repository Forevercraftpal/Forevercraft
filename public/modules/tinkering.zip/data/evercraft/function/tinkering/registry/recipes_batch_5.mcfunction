# ============================================================
# Tinkering — Family-Recipe REGISTRY batch 5 (Family H — Alchemist's Magnum Opus lattice)
# ============================================================
# Appends the Family H fusion recipe rows onto storage evercraft:tnk_recipes recipes. Called by
# registry/load_recipes AFTER recipes_batch_4. Seeds Family H (Chemistry Trade → Alchemist's Magnum
# Opus, BUNDLE — zero DR, the alchemist trade-guild): the four sub-bindings (Steeping Line / Crucible
# Line / Reliquary Line / Sustain Vial) + the grand Alchemist's Magnum Opus. NO engine edit —
# plinth/detect reads list length N dynamically and gates each row from its own data (same contract as
# batch 0-4). G/H stay SEPARATE guilds with reserved-for-expansion slots (Open-Decision 1a) — H is its
# own family, NOT merged into G.
#
# Schema is documented in recipes_batch_0 (capstone / family / tier / sub_capstone / ingredient_ids /
# cost / consolidated_modifier / dr_sum / flavor / loot / bit / flag / name / color). All ingredient_ids
# are the live `artifact:"<id>"` values verified in craftforever/craft_rate/calculate +
# craftforever/alchemy/minigame/resolve + artifacts/accessories/player_tick (the 7 H leaves from art-H)
# + the sub-binding flags this batch's own loot tables stamp (steeping_line / crucible_line /
# reliquary_line / sustain_vial). Every loot path resolves to a loot_table built in cap-H (no dangling
# table).
#
# BALANCE-NEUTRAL — ZERO DR across the whole family (DECISIONS + lattice §H: "DR consolidated: 0; CR is
# set-not-add; bundle"). Every row carries dr_sum:0.0d and consolidated_modifier:"" — the apply side
# (tinkering/magnum_opus/*_apply) emits NO luck modifier; the CR / quality / yield / duration / sustain
# halves route through their own one-writer files (craft_rate/calculate [the ONE ec.cr_temp writer],
# alchemy/minigame/resolve, the result_* duration steps, artifacts/accessories/player_tick [the sustain
# Regen]), gated on the held capstone flag, with the loose leaf brew levers m4-suppressed (Newcomer-
# exempt) when the absorbing node is held so a re-acquired leaf never doubles the quality/yield/CR.
# CR never stacks (ec.cr_temp is set-not-add — the ONE writer in calculate). bit:0 = no ec.tnk_owned
# latch (the grand Magnum Opus, like the Pebble / Reliquary / Wayfarer's Lens / Soulguard Aegis /
# Grandforge Regalia, has no pre-assigned bit; its completed state is detectable by HOLDING
# alchemists_magnum_opus:true — no new objective).
#
# Varied tier cost per the lattice tree weights + DECISIONS "varied fusion cost" (cheap leaf-pairs ->
# pricier sub-caps -> grand): Steeping Line ✦ leaf-pair = 3 · Crucible Line ✦✦ = 5 · Reliquary Line
# ✦✦✦ = 7 · Sustain Vial ✦ single-leaf = 2 · Alchemist's Magnum Opus grand ✦✦✦✦ = 16.
# "magic" never appears (arcane / ancient / potent / power only).
# ------------------------------------------------------------

# H.t1 — STEEPING LINE (Steeping Vial Pendant + Reagent Satchel Clasp → the CR + yield leaf-pair, ✦).
#   The cheap teach-fusion of the Magnum Opus line. Sub-capstone, no latch, zero DR. Consolidated +0.1 CR
#   + +20% reagent-yield bonus-potion roll.
data modify storage evercraft:tnk_recipes recipes append value {capstone:"steeping_line",family:"H",tier:1,sub_capstone:"steeping_line",ingredient_ids:["steeping_vial_pendant","reagent_satchel_clasp"],cost:3,consolidated_modifier:"",dr_sum:0.0d,flavor:"bundle",loot:"evercraft:tinkering/steeping_line",bit:0,flag:"steeping_line",name:"Steeping Line",color:"#7FC8B0"}

# H.t2 — CRUCIBLE LINE (Crucible Lens + Alembic Heart → the quality + duration node, ✦✦). Sub-capstone,
#   no latch, zero DR. Consolidated +1 alchemy quality + +50% potion duration.
data modify storage evercraft:tnk_recipes recipes append value {capstone:"crucible_line",family:"H",tier:2,sub_capstone:"crucible_line",ingredient_ids:["crucible_lens","alembic_heart"],cost:5,consolidated_modifier:"",dr_sum:0.0d,flavor:"bundle",loot:"evercraft:tinkering/crucible_line",bit:0,flag:"crucible_line",name:"Crucible Line",color:"#C88AD8"}

# H.t3 — RELIQUARY LINE (Alembic Pendant + Catalyst Reliquary → the two-/three-lever sub-cap, ✦✦✦).
#   Sub-capstone, no latch, zero DR. Consolidated +2 alchemy quality (Pendant +1 + Reliquary +1) + +30%
#   reagent-yield (Pendant +10% + Reliquary +20%) + +0.1 CR (Reliquary).
data modify storage evercraft:tnk_recipes recipes append value {capstone:"reliquary_line",family:"H",tier:3,sub_capstone:"reliquary_line",ingredient_ids:["alembic_pendant","catalyst_reliquary"],cost:7,consolidated_modifier:"",dr_sum:0.0d,flavor:"bundle",loot:"evercraft:tinkering/reliquary_line",bit:0,flag:"reliquary_line",name:"Reliquary Line",color:"#E0A0FF"}

# H.t1 — SUSTAIN VIAL (Glacier-Cut Sigil → the conditional sustain leaf, ✦). Sub-capstone, no latch,
#   zero DR. Single-leaf fusion (the lattice's "Sustain Vial = B11 Glacier-Cut Sigil"). Re-grants
#   Regeneration I while below half health (the alchemist brew-bench sustain). Cheapest sub-line (2).
data modify storage evercraft:tnk_recipes recipes append value {capstone:"sustain_vial",family:"H",tier:1,sub_capstone:"sustain_vial",ingredient_ids:["glacier_cut_sigil"],cost:2,consolidated_modifier:"",dr_sum:0.0d,flavor:"bundle",loot:"evercraft:tinkering/sustain_vial",bit:0,flag:"sustain_vial",name:"Sustain Vial",color:"#9BD8E8"}

# H.t4 — ALCHEMIST'S MAGNUM OPUS (Steeping Line + Crucible Line + Reliquary Line + Sustain Vial → the
#   grand flagship, ✦✦✦✦). The Magnum Opus bundle's grand: every absorbed alchemist lever —
#   +3 quality / +50% reagent-yield / +50% potion duration / +0.2 CR / Regen-below-half — consolidated
#   behind one held item, ZERO DR. CR is set-not-add so it NEVER stacks. NO latch bit (bit:0): the Opus,
#   like the Pebble / Reliquary / Wayfarer's Lens / Soulguard Aegis / Grandforge Regalia, has no
#   pre-assigned ec.tnk_owned bit; its completed state is detectable by HOLDING
#   alchemists_magnum_opus:true (the apply keys on that flag). The Opus's loot table is NOT Material
#   (final-form Spirit Artifact). consolidated_modifier:"" / dr_sum:0 (balance-neutral — the headline is
#   the consolidated ALCHEMY bundle, not any Dream Rate).
data modify storage evercraft:tnk_recipes recipes append value {capstone:"alchemists_magnum_opus",family:"H",tier:4,sub_capstone:"",ingredient_ids:["steeping_line","crucible_line","reliquary_line","sustain_vial"],cost:16,consolidated_modifier:"",dr_sum:0.0d,flavor:"bundle",loot:"evercraft:tinkering/alchemists_magnum_opus",bit:0,flag:"alchemists_magnum_opus",name:"Alchemist's Magnum Opus",color:"#C77DFF"}

# ------------------------------------------------------------
# HAND-OFF TO recipes_batch_6 (future families J/K/L + the remaining unbuilt capstones):
#   - This batch ends Family H. recipes_batch_6's rows simply append more; the engine reads list
#     length N dynamically, so a new batch auto-extends the bench with NO engine edit.
#   - registry/load_recipes calls recipes_batch_5 (added there); add the recipes_batch_6 call when
#     it lands. Do NOT renumber or reorder this batch (the Almanac walks it in tree order).
# ------------------------------------------------------------
