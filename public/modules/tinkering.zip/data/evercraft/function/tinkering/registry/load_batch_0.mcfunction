# ============================================================
# Tinkering (universal mini-line) — Registry batch 0 (the teaching line, q1..q12)
# ============================================================
# Appends the 12 quests onto storage evercraft:tnk_registry quests. Called by registry/load
# AFTER it sets quests=[]. MUST append in id order (id=1 first => list index 0), contiguous,
# so list-position == ec.tnk_quest-1. (Structural clone of adventure/kingdom/registry/
# load_batch_0 (C6), paced via C0.)
#
# Quest object schema (the engine reads these exact fields):
#   {id:int, title:string, desc:string, type:string, target:string,
#    count:int, reward:string, reward_amt:int, chapter:int,
#    [lore:string], [beat:string], [skippable:int]}      <- C0 fields OPTIONAL
#
# type    -> dispatched by check_type/$(type):
#            own_accessories | has_station | fused_any | fused_band | fused_hand | fused_charm
#            (beat:"interlude"/count:0 auto-passes BEFORE dispatch — SCHEMA_DELTA §3)
# target  -> IGNORED by own_accessories / has_station / fused_* (each reads a fixed mirror:
#             held items / the ec.cf_r10_granted tag / the ec.tnk_owned bitfield). On a
#             reward:"crate"/"trophy" beat target NAMES the crate tier (common|uncommon|rare|
#             ornate|exquisite|mythical) consumed by reward_type/crate. On a reward:"station"
#             beat target is a label only (the Plinth give is fixed).
# count   -> own_accessories: number of accessories the player must hold at once;
#            has_station / fused_*: IGNORED (flag conditions);
#            interlude: 0 (auto-pass).
# reward  -> coins | crate | trophy | station   (NO xp, NO title — DECISIONS #9: a teaching
#            mini-line, not an XP faucet; the Master-Tinkerer prestige is special-title ID 17,
#            wired in Wave C8). reward_amt = coins amount (ignored by crate/trophy/station).
# chapter -> 1 for the whole line (ONE chapter — the "mini" in mini-line).
#
# BALANCE (DECISIONS #9 / R14): every fusion this line teaches (Trinket Knot / Hand / Band)
# is strictly slot-saving — accessories apply while merely HELD (verified accessories/
# player_tick:9), so fusing only frees inventory slots. No power axis. The rewards are modest
# coins / one starter crate / a capstone chest — a teaching line, never an XP faucet.
#
# C0 CADENCE (SCHEMA_DELTA §1): every objective beat carries `lore`; 3 interludes (q1 intro,
# q5 breather, q8 breather2) sit ~3:1 against the 7 objective beats. The two headline teach
# beats q3 (has_station — "raise the Workshop") + q4 (fused_any — "your first union") are
# `skippable:0` "see-it-once" — both still auto-pass a veteran via the lifetime/held read in
# their check helper (Decision #5). The advanced-fusion beats q6/q7/q9 (Band/Hand/Charm) are
# `skippable:1` so the line NEVER walls on an endgame fusion (the player [Skip ▸]s at full
# reward and still completes the line).
#
# "magic" never appears (arcane/ancient/potent only).
# ------------------------------------------------------------

# --- The Tinkerer's Path (ONE chapter) -------------------------------------

# q1 — *** INTRO INTERLUDE (count:0, beat:interlude) ***: the core idea.
data modify storage evercraft:tnk_registry quests append value {id:1,title:"Two Trinkets, One Pocket",desc:"",type:"interlude",target:"",count:0,reward:"coins",reward_amt:5,chapter:1,beat:"interlude",lore:"Look at all you carry, adventurer. Every charm, ring, and curio takes a pocket of its own — and your pack fills before your power does. A Tinkerer learns the oldest courtesy of craft: that two things that work alike can be JOINED to ride in one slot, losing nothing of what they do. That is the whole of my art. Let me show you the first knot."}

# q2 — gather your trinkets. own_accessories count:2. lore + default [Skip ▸]. A player who
#   already carries 2+ accessories auto-passes via the held-item read (universality on-ramp).
data modify storage evercraft:tnk_registry quests append value {id:2,title:"Gather Your Trinkets",desc:"Carry two accessories at once.",type:"own_accessories",target:"",count:2,reward:"coins",reward_amt:10,chapter:1,lore:"Before you can join trinkets, you must hold them. Carry any two accessories at once — a ring and a charm, two charms, whatever you have earned. It does not matter which: a Tinkerer joins what is at hand. Most adventurers already carry far more than two without thinking; that crowding is exactly the problem we are about to solve."}

# q3 — *** SEE-IT-ONCE teach beat (skippable:0) ***: raise the Workshop. has_station reads
#   the ec.cf_r10_granted Funnel tag OR a held Plinth. The reward HANDS the player a
#   Tinkerer's Plinth (reward_type/station), so a newcomer who reaches q3 receives the altar
#   and the beat satisfies on the next 20t check. A rank-10 Funnel owner auto-passes at once.
data modify storage evercraft:tnk_registry quests append value {id:3,title:"Raise the Workshop",desc:"Obtain a fusion station — a Tinkerer's Plinth or a Fusion Funnel.",type:"has_station",target:"",count:1,reward:"station",reward_amt:0,chapter:1,lore:"A Tinkerer keeps three tables. The PLINTH — a stone set upon a beacon — is where trinkets are joined; toss two upon it and they knot into one. The STAND reshapes what you own, and the FUNNEL brews trinkets anew at the deepest ranks. Take this Plinth: it is your first table, and the simplest. Set it on a beacon, and the Workshop is raised.",skippable:0}

# q4 — *** SEE-IT-ONCE teach beat (skippable:0) ***: your first union. fused_any reads the
#   ec.tnk_owned bitfield (any bit). Satisfied by the trivial Trinket Knot OR ANY other
#   fusion (T10 universality). A veteran who ever fused auto-passes. NO [Skip ▸] for a
#   newcomer, but never walled (a held-pair Knot takes seconds).
data modify storage evercraft:tnk_registry quests append value {id:4,title:"Your First Union",desc:"Perform any fusion — toss two trinkets on the Plinth to knot them.",type:"fused_any",target:"",count:1,reward:"crate",reward_amt:1,chapter:1,lore:"Now the moment the whole craft turns on. Place your Plinth upon a beacon, hold two common trinkets, and TOSS them both onto the stone. The beacon's light folds them together and a Trinket Knot rises in their place — one item, both their gifts, one freed slot. You have not gained power; you have gained ROOM. That, a Tinkerer will tell you, is its own kind of power.",skippable:0}

# q5 — *** INTERLUDE (count:0) ***: slots are sacred.
data modify storage evercraft:tnk_registry quests append value {id:5,title:"Slots Are Sacred",desc:"",type:"interlude",target:"",count:0,reward:"coins",reward_amt:5,chapter:1,beat:"interlude",lore:"Rest a moment and turn the Knot over in your hand. Notice what did NOT change: every effect both trinkets gave you, you still have. What changed is the space around it. An inventory slot is a small thing until you have spent one too many on a charm you could have joined — and then it is the most precious thing you own. A Tinkerer hoards room the way a miser hoards gold, and gives it freely to those who learn the knot."}

# q6 — *** ADVANCED (skippable:1) ***: consolidate your rings. fused_band reads ec.tnk_owned
#   bit1. The Band of Rings is round-1's Transmute [Consolidate] branch (Wave 8 / wired in C8).
#   A player who never wants it [Skip ▸]s at full reward; a veteran with a Band auto-passes.
data modify storage evercraft:tnk_registry quests append value {id:6,title:"Consolidate Your Rings",desc:"Forge the Band of Rings at the Transmutation Stand.",type:"fused_band",target:"",count:1,reward:"coins",reward_amt:25,chapter:1,skippable:1,lore:"When you have gathered a fist of rings, take them to the Transmutation Stand — the second of the Tinkerer's three tables — and bind them into one Band. Four rings, one slot, every gift intact. This is a deeper join than the Knot, and a later one; if your rings are still few, walk on and return when your hand is heavy with them. The Band will wait. (You may skip ahead — the craft does not wall.)"}

# q7 — *** ADVANCED (skippable:1) ***: six parts, one Hand. fused_hand reads ec.tnk_owned
#   bit2. The Hand of Creation is round-1's six-builder-part fusion (Wave 7), re-homed onto
#   the Plinth (tinkering/plinth/do_hand). Skippable so a non-builder never walls.
data modify storage evercraft:tnk_registry quests append value {id:7,title:"Six Parts, One Hand",desc:"Forge the Hand of Creation from the six builder parts.",type:"fused_hand",target:"",count:1,reward:"crate",reward_amt:1,chapter:1,skippable:1,lore:"The builders earn six small parts along their road — a reach, a refund, a level, and three more — each a gift, each a slot. Bring all six to your Plinth and the beacon folds them into one Hand of Creation: the whole builder's kit in a single grip. This is the Build line's reward to join; if that is not your road, skip it freely and the craft is no less complete in your hands. (Skippable — the Hand waits for those who walk the Builder's Path.)"}

# q8 — *** INTERLUDE (count:0) ***: the deeper art.
data modify storage evercraft:tnk_registry quests append value {id:8,title:"The Deeper Art",desc:"",type:"interlude",target:"",count:0,reward:"coins",reward_amt:5,chapter:1,beat:"interlude",lore:"There is a rumor among Tinkerers of a join deeper than any table — of signs that, set near one another, begin to RHYME, until a string of them reads like a word and binds itself into the thing you carry. The old crafters called it a rune-word, and it is the art the Builders' glyphs only hint at. It is not for today, and perhaps not for this Plinth — but remember that the craft of joining runs deeper than slots. Every Tinkerer is, at heart, looking for that word."}

# q9 — *** ADVANCED / DEFERRED (skippable:1) ***: bind your charms. fused_charm reads
#   ec.tnk_owned bit3. The Band of Charms is the DEFERRED sub-wave (no writer yet), so this
#   beat is reached only by a player who walks the line that far and is skippable:1 (they
#   [Skip ▸] at full reward, completing the line). A future veteran with the Charm Band passes.
data modify storage evercraft:tnk_registry quests append value {id:9,title:"Bind Your Charms",desc:"Forge the Band of Charms (a Tinkerer's later art).",type:"fused_charm",target:"",count:1,reward:"coins",reward_amt:15,chapter:1,skippable:1,lore:"The last and newest join: a Band of Charms, gathering your travelers' tokens and merchants' coins and the rest into a single charm that carries them all. It is the Tinkerer's frontier — a craft still being written, arriving in a season ahead. For now, take the knowledge that it is coming and skip on to your mastery; when the Band of Charms is ready, you will already know the hand for it. (Skippable — a coming art.)"}

# q10 — *** INTERLUDE (count:0) ***: the three tables, named.
data modify storage evercraft:tnk_registry quests append value {id:10,title:"Three Tables, One Craft",desc:"",type:"interlude",target:"",count:0,reward:"coins",reward_amt:5,chapter:1,beat:"interlude",lore:"Say them once, so you never forget: the PLINTH joins, the STAND reshapes, the FUNNEL brews. Three tables, one craft — the Tinkerer's Workshop. You came to me crowded, carrying your power in a dozen scattered slots; you leave knowing how to gather it into a few. That is no small graduation. One thing remains: to be named for what you have become."}

# q11 — return to the Knot with intent — hold trinkets again (a closing practice beat).
#   own_accessories count:2 (a gentle final objective the veteran auto-passes). lore + [Skip ▸].
data modify storage evercraft:tnk_registry quests append value {id:11,title:"The Tinkerer's Habit",desc:"Carry two accessories at once once more — the Tinkerer's habit.",type:"own_accessories",target:"",count:2,reward:"coins",reward_amt:15,chapter:1,lore:"One last practice, and it is the simplest: carry two trinkets, and feel how your hand now itches to join them. That itch is the craft settled into you — you will never again look at a crowded pack the same way. Keep the habit. A Tinkerer is not someone who fused once; it is someone who, ever after, sees the knot waiting in everything they carry."}

# q12 — *** CAPSTONE (count:0, beat:interlude) ***: Master Tinkerer. trophy reward.
#   The chapter finale — a pure-lore capstone that pays the Master Tinkerer's chest (trophy).
#   The Master-Tinkerer PRESTIGE TITLE (special-title ID 17) is OR-set by Wave C8 on finish;
#   C7's finish() does NOT touch the title (no unbuilt round-1 dependency). q12 is a soft
#   finale, not a hard cap: advance reads N dynamically, so a load_batch_1 later auto-extends.
data modify storage evercraft:tnk_registry quests append value {id:12,title:"Master Tinkerer",desc:"",type:"interlude",target:"",count:0,reward:"trophy",reward_amt:0,chapter:1,beat:"interlude",lore:"There. You knot trinkets, you bind rings, you fold a builder's parts into one Hand, and you know the three tables by name. You are a Master Tinkerer now — not because you fused the most, but because you understand the courtesy at the heart of the craft: that power is best carried light. Take this chest as your token. And the next time a friend groans under a crowded pack, teach them the knot. That is how the craft survives."}

# ------------------------------------------------------------
# HAND-OFF TO load_batch_1 (future Tinkering chapters):
#   - This batch ends at id=12. The next batch's FIRST quest MUST be id=13 (list index 12),
#     appended immediately after q12, contiguously.
#   - registry/load calls load_batch_0; add the load_batch_1 call there when it lands.
#     Do NOT renumber this batch.
# ------------------------------------------------------------
