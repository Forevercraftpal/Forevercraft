# ============================================================
# Tinkering — Family-Recipe REGISTRY batch 0 (Family A + Family E lattice)
# ============================================================
# Appends the Wave-1 fusion recipe rows onto storage evercraft:tnk_recipes recipes. Called by
# registry/load_recipes AFTER it sets recipes=[]. Seeds the two Wave-1 families:
#   • Family A — Pebble of Creation tree (ascension; boss trinkets + Pebble of Dreams)
#   • Family E — Band of All Rings tree (bundle + consolidated DR; the 15 rings)
# Other families (B Dreamer's Reliquary / C Wayfarer's Lens / D Soulguard Aegis) land later as
# PURE DATA in recipes_batch_1+ — NO engine edit needed, because plinth/detect reads list
# length N dynamically and gates each row from its own data.
#
# ------------------------------------------------------------
# Recipe row schema (the engine — plinth/detect + plinth/do — reads these exact fields):
#
#   capstone              string  the fused-result artifact id (matches do's stamp + the
#                                 apply-unit's union read).
#   family                string  "A".."F" — which fusion family this row belongs to (Almanac
#                                 grouping; the engine does not branch on it).
#   tier                  int     tree depth: 1 leaves (not rows — leaves are raw drops), 2
#                                 sub-binding, 3 mid, 4 grand. Higher tier = pricier (cost).
#   sub_capstone          string  "" for a Spirit Artifact, else the sub-binding label this row
#                                 produces (e.g. "aegis_half"). Informational for the Almanac.
#   ingredient_ids        [string]  the custom_data `artifact:"<id>"` ids that must ALL be
#                                 present as item entities near the beacon for this recipe to
#                                 fire. plinty/detect counts how many of these are present and
#                                 fires `do` only when ALL are (a fixed-set gate, data-driven —
#                                 the same "all-of" contract as detect_hand, but read from data).
#   cost                  int     a varied per-tier fusion cost knob (DECISIONS: cheap low-tier,
#                                 pricier high-tier). RESERVED for a future cost-gate; the engine
#                                 reads it but does not yet charge (Wave-1 fusions are free, like
#                                 the shipped Knot/Hand). Carried now so cost is pure data later.
#   consolidated_modifier string  the SINGLE luck attribute-modifier id the apply-unit emits for
#                                 this capstone ("" if the capstone carries no consolidated DR).
#                                 Built by Unit 2/3 (the apply side); the registry only RECORDS it
#                                 so the Almanac + the strip-law (Unit 4) can enumerate the ids.
#   dr_sum                double  the consolidated dream-rate this capstone grants (the headline
#                                 ascension number; 0.0 for a pure bundle). RECORD only.
#   flavor                string  "bundle" (slot-saver, balance-neutral) or "ascension" (bundle +
#                                 consolidated stat). RECORD only; the engine does not branch.
#   loot                  string  the loot-table path plinth/do `loot spawn`s for the result.
#   bit                   int     the ec.tnk_owned safe-OR latch VALUE to light on fusion
#                                 (1 Knot / 2 Band / 4 Hand / 8 Charm — REUSED, no new bits; a
#                                 family's Spirit Artifact lights its family bit, sub-bindings
#                                 light nothing → bit:0 = no latch).
#   flag                  string  the custom_data boolean key plinth/do stamps `true` on the
#                                 spawned result (so player_tick / the apply-unit detects it).
#   name                  string  display name (announcement only).
#   color                 string  display color (announcement only).
#
# ALL ingredient_ids are the live `artifact:"<id>"` values verified in
# artifacts/accessories/player_tick + hero_satchel/effects/* (the 11 boss ids, Pebble of
# Dreams, the 13 ring_* ids, and the 2 ring-identity DR charms aquamarine_ring/ring_of_undying
# + ring_trial). The two half-bag sub-bindings + Hero Satchel + Pebble + the 3 sub-bands have
# their OWN loot tables (loot_table/tinkering/*.json + the existing hero_satchel / transmute
# tables). No ingredient id is invented; no loot path is dangling (all verified at build).
#
# "magic" never appears (arcane / ancient / potent / power only).
# ------------------------------------------------------------

# ============================================================
# FAMILY A — Pebble of Creation (ascension; boss trinkets + Pebble of Dreams)
# ============================================================

# A.t2 — AEGIS HALF (the 6 bruiser/aura boss trinkets → one half-bag). Sub-capstone, no latch.
#   DR ≈ +9.0 (folded by Unit 2's apply path into pebble_aegis_luck). Equippable mid-reward.
data modify storage evercraft:tnk_recipes recipes append value {capstone:"aegis_half",family:"A",tier:2,sub_capstone:"aegis_half",ingredient_ids:["soul_reaver","earthshaker_core","behemoths_heart","infernal_heart","soulkeepers_ember","thornheart_bloom"],cost:6,consolidated_modifier:"evercraft:pebble_aegis_luck",dr_sum:9.0d,flavor:"ascension",loot:"evercraft:tinkering/aegis_half",bit:0,flag:"aegis_half",name:"Aegis Half",color:"#FF4500"}

# A.t2 — ASTRAL HALF (the 5 mobility/sense boss trinkets → one half-bag). Sub-capstone, no latch.
#   DR ≈ +8.5 (folded by Unit 2's apply path into pebble_astral_luck). Equippable mid-reward.
data modify storage evercraft:tnk_recipes recipes append value {capstone:"astral_half",family:"A",tier:2,sub_capstone:"astral_half",ingredient_ids:["thunderstrike_core","abyssal_pearl","nightmare_fragment","void_sovereigns_eye","architects_design"],cost:6,consolidated_modifier:"evercraft:pebble_astral_luck",dr_sum:8.5d,flavor:"ascension",loot:"evercraft:tinkering/astral_half",bit:0,flag:"astral_half",name:"Astral Half",color:"#55FFFF"}

# A.t3 — HERO SATCHEL (Aegis Half + Astral Half → the full 11-perk bag). The existing
#   hero_satchel item is the result; no latch (the grand Pebble lights the family state). The
#   Hero Satchel is the union of both halves' DR (+17.5) once the apply-unit consolidates.
data modify storage evercraft:tnk_recipes recipes append value {capstone:"hero_satchel",family:"A",tier:3,sub_capstone:"",ingredient_ids:["aegis_half","astral_half"],cost:12,consolidated_modifier:"",dr_sum:17.5d,flavor:"ascension",loot:"evercraft:hero_satchel/hero_satchel",bit:0,flag:"hero_satchel",name:"Hero's Satchel",color:"#FF4500"}

# A.t4 — PEBBLE OF CREATION (Hero Satchel + Pebble of Dreams → the grand flagship). NO latch bit
#   (bit:0): the Pebble has no pre-assigned ec.tnk_owned bit, and hijacking the Knot/Hand/Charm
#   bits would conflate states. Its completed state is detectable by HOLDING the
#   pebble_of_creation:true item itself (the apply-unit keys on that flag — see do's stamp). No
#   new objective is introduced. DR consolidated +18.5 into evercraft:pebble_of_creation_luck by
#   Unit 2. Storage preserved (the result keeps hero_satchel:true so the storage menu works).
data modify storage evercraft:tnk_recipes recipes append value {capstone:"pebble_of_creation",family:"A",tier:4,sub_capstone:"",ingredient_ids:["hero_satchel","pebble_of_dreams"],cost:24,consolidated_modifier:"evercraft:pebble_of_creation_luck",dr_sum:18.5d,flavor:"ascension",loot:"evercraft:tinkering/pebble_of_creation",bit:0,flag:"pebble_of_creation",name:"Pebble of Creation",color:"#FF4500"}

# ============================================================
# FAMILY E — Band of All Rings (bundle + consolidated DR; the 15 rings)
# ============================================================
# Ring-identity DR charms route to the Band per D2: aquamarine_ring → Wardband, ring_of_undying
# + ring_trial → Voidband (matching each sub-band's lore + DR record below).

# E.t2 — GEMBAND (the 5 gem rings → one band). Sub-capstone, no latch, no DR (gem tier carries
#   no dream-rate). Pure bundle.
data modify storage evercraft:tnk_recipes recipes append value {capstone:"gemband",family:"E",tier:2,sub_capstone:"gemband",ingredient_ids:["ring_amethyst","ring_lapis","ring_redstone","ring_diamond","ring_slime"],cost:5,consolidated_modifier:"",dr_sum:0.0d,flavor:"bundle",loot:"evercraft:tinkering/gemband",bit:0,flag:"gemband",name:"Gemband",color:"aqua"}

# E.t2 — WARDBAND (the 4 effect rings + the Aquamarine DR ring → one band). Sub-capstone, no
#   latch. Carries Aquamarine's +1.0 DR (folded into evercraft:wardband_luck by Unit 3).
data modify storage evercraft:tnk_recipes recipes append value {capstone:"wardband",family:"E",tier:2,sub_capstone:"wardband",ingredient_ids:["ring_emerald","ring_bone","ring_honey","ring_nether","aquamarine_ring"],cost:5,consolidated_modifier:"evercraft:wardband_luck",dr_sum:1.0d,flavor:"bundle",loot:"evercraft:tinkering/wardband",bit:0,flag:"wardband",name:"Wardband",color:"green"}

# E.t2 — VOIDBAND (the 3 potent rings + Trial + Ring of Undying → one band). Sub-capstone, no
#   latch. Carries Trial +2.0 + Undying +1.0 = +3.0 DR (into evercraft:voidband_luck by Unit 3).
data modify storage evercraft:tnk_recipes recipes append value {capstone:"voidband",family:"E",tier:2,sub_capstone:"voidband",ingredient_ids:["ring_ominous","ring_warden","ring_void","ring_trial","ring_of_undying"],cost:5,consolidated_modifier:"evercraft:voidband_luck",dr_sum:3.0d,flavor:"bundle",loot:"evercraft:tinkering/voidband",bit:0,flag:"voidband",name:"Voidband",color:"dark_purple"}

# E.t3 — BAND OF ALL RINGS, full 15 (Gemband + Wardband + Voidband → the grand band). Lights the
#   Band latch ec.tnk_owned bit1 (value 2). DR consolidated +4.0 into evercraft:band_luck by
#   Unit 3. The existing transmute/band_of_all_rings loot is the result item.
data modify storage evercraft:tnk_recipes recipes append value {capstone:"band_of_all_rings",family:"E",tier:3,sub_capstone:"",ingredient_ids:["gemband","wardband","voidband"],cost:15,consolidated_modifier:"evercraft:band_luck",dr_sum:4.0d,flavor:"bundle",loot:"evercraft:transmute/band_of_all_rings",bit:2,flag:"band_of_all_rings",name:"Band of All Rings",color:"light_purple"}

# ------------------------------------------------------------
# HAND-OFF TO recipes_batch_1 (future families B/C/D + new artifacts):
#   - This batch ends Family A + E. recipes_batch_1's rows simply append more; the engine reads
#     list length N dynamically, so a new batch auto-extends the bench with NO engine edit.
#   - registry/load_recipes calls recipes_batch_0; add the recipes_batch_1 call there when it
#     lands. Do NOT renumber or reorder this batch (the Almanac walks it in tree order).
# ------------------------------------------------------------
