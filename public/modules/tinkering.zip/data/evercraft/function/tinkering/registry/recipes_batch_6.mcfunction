# ============================================================
# Tinkering — Family-Recipe REGISTRY batch 6 (Family J — Cornucopia Tide lattice)
# ============================================================
# Appends the Family J fusion recipe rows onto storage evercraft:tnk_recipes recipes. Called by
# registry/load_recipes AFTER recipes_batch_5. Seeds Family J (Harvest & Tide → Cornucopia Tide, the
# bounty economy): the two cheap leaf-pairs (Hearth Pair / Dock Pair) + two trade sub-bindings
# (Hearthkeeper's Ladle = culinary · Tidewright's Net = fishing) + the farming/aquatic sub-cap (Harvest
# Knot) + the grand Cornucopia Tide (the PRICIEST grand — eats the two trade sub-caps). NO engine edit —
# plinth/detect reads list length N dynamically and gates each row from its own data (same contract as
# batches 0-5).
#
# Schema is documented in recipes_batch_0 (capstone / family / tier / sub_capstone / ingredient_ids /
# cost / consolidated_modifier / dr_sum / flavor / loot / bit / flag / name / color). All LEAF
# ingredient_ids are the live `artifact:"<id>"` values verified in the art-J wiring (cook leaves in
# cooking/minigame/resolve + craft_rate/calculate; fishing leaves in artifacts/accessories/player_tick +
# fishing/ref/on_catch; farming/aquatic in harvest_bonus_read + player_tick). Intermediate ingredient_ids
# (hearth_pair / dock_pair / hearthkeepers_ladle / tidewrights_net) are the bare flags THIS batch's own
# loot tables stamp. C37 Catalyst of the Bounty = the ASCENSION REAGENT (not a member) — it is an
# ingredient_id of the two trade sub-caps (consumed in the binding, the loot-table lore "spent in the
# binding — not worn"). Every loot path resolves to a loot_table/tinkering/*.json built in cap-J.
#
# DR consolidation (DECISIONS D1 full-power, UNCAPPED — the global DR ceiling rose to 100 in w5). Family J
# carries CONDITIONAL DR only (the two fishing charms fire DR only while fishing / in water — the
# Geologist's Loupe idiom). The dr_sum here RECORDS the consolidated CONDITIONAL value for the Almanac +
# the m4 strip-law to enumerate; the apply side (player_tick) is where the modifier is condition-gated:
#   Hearth Pair        0.0  (cook-quality leaf-pair — no luck)
#   Dock Pair          0.0  (lure + crate leaf-pair — no luck)
#   Hearthkeeper's Ladle 0.0  (culinary sub-cap — cook quality / CR / bonus-roll, no luck)
#   Harvest Knot       0.0  (farming/aquatic sub-cap — crop yield + aquatic attrs, no luck)
#   Tidewright's Net   +5.0 CONDITIONAL (Riverpearl +2 while fishing + Deepcurrent +3 in water → ONE
#                            consolidated tidewright_luck, fires while fishing OR in water)
#   Cornucopia Tide    +5.0 CONDITIONAL (the grand folds the Net's two fishing-DR charms → ONE
#                            consolidated cornucopia_luck, fires while fishing OR harvesting/in water)
# The grand's headline matches the Net's +5 (the only DR in the family lives on the two fishing charms;
# the grand carries the SAME consolidated conditional line, ONE breakdown row). bit:0 = no ec.tnk_owned
# latch (the grand Cornucopia Tide, like the Pebble / Reliquary, has no pre-assigned bit; its completed
# state is detectable by HOLDING cornucopia_tide:true — no new objective).
#
# VARIED tier cost (the lattice §J tree weights): cheap leaf-pairs (2) → farming sub-cap (8) → trade
# sub-caps (10 — they eat 6-7 charms + the Catalyst reagent) → the GRAND Cornucopia Tide flagged the
# PRICIEST grand at cost 26 (above the Dreamer's Reliquary's 24 — DECISIONS "Cornucopia Tide priciest").
# Crate-SOURCED (not crate-free): the leaves wire into crate/quest/mob sources in later wiring units.
# "magic" never appears (arcane / ancient / potent / power only).
# ------------------------------------------------------------

# J.t1 — HEARTH PAIR (Hearthhand Cloth + Chef's Searing Charm → the cheap culinary leaf-pair, ✦). The
#   teach-fusion of the Hearthkeeper's Ladle line (the cook's first apprenticeship knot). Sub-capstone
#   label, no latch, zero DR. +2 cook quality (its two +1 leaves, full).
data modify storage evercraft:tnk_recipes recipes append value {capstone:"hearth_pair",family:"J",tier:1,sub_capstone:"hearth_pair",ingredient_ids:["hearthhand_cloth","chefs_searing_charm"],cost:2,consolidated_modifier:"",dr_sum:0.0d,flavor:"bundle",loot:"evercraft:tinkering/hearth_pair",bit:0,flag:"hearth_pair",name:"Hearth Pair",color:"#E8C07D"}

# J.t1 — DOCK PAIR (Dockhand's Knot + Tidecaller's Lure → the cheap fishing leaf-pair, ✦). The
#   teach-fusion of the Tidewright's Net line (the angler's first apprenticeship knot). Sub-capstone
#   label, no latch, zero DR. Lure I on rod + one extra crate roll per catch.
data modify storage evercraft:tnk_recipes recipes append value {capstone:"dock_pair",family:"J",tier:1,sub_capstone:"dock_pair",ingredient_ids:["dockhands_knot","tidecallers_lure"],cost:2,consolidated_modifier:"",dr_sum:0.0d,flavor:"bundle",loot:"evercraft:tinkering/dock_pair",bit:0,flag:"dock_pair",name:"Dock Pair",color:"#86C5D8"}

# J.t2 — HARVEST KNOT (Tiller's Knot + Gleaner's Twine + Farmer's Almanac + Harvest Totem + Tidefinder's
#   Astrolite → the farming/aquatic sub-cap, ✦✦). Sub-capstone, no latch, zero DR. Consolidates the
#   crop double-harvest + crate odds + bone-meal growth pulse + the aquatic +0.15 submerged-mining +
#   splash-node sense. (NOT eaten by the grand — the grand eats only the two trade sub-caps.)
data modify storage evercraft:tnk_recipes recipes append value {capstone:"harvest_knot",family:"J",tier:2,sub_capstone:"harvest_knot",ingredient_ids:["tillers_knot","gleaners_twine","farmers_almanac","harvest_totem","tidefinders_astrolite"],cost:8,consolidated_modifier:"",dr_sum:0.0d,flavor:"bundle",loot:"evercraft:tinkering/harvest_knot",bit:0,flag:"harvest_knot",name:"Harvest Knot",color:"#9FD065"}

# J.t3 — HEARTHKEEPER'S LADLE (the 7 culinary charms + the Catalyst of the Bounty reagent → the culinary
#   sub-cap, ✦✦✦). Sub-capstone, no latch, zero DR. Consolidates +2 cook quality + +10.0 CR + the +2%
#   bonus-material roll on a finished cook. C37 Catalyst of the Bounty = the ascension reagent consumed
#   in the binding (an ingredient_id — "spent in the binding, not worn").
data modify storage evercraft:tnk_recipes recipes append value {capstone:"hearthkeepers_ladle",family:"J",tier:3,sub_capstone:"hearthkeepers_ladle",ingredient_ids:["hearthhand_cloth","brinewell_ladle","hearthcooks_apron","harvest_censer","chefs_searing_charm","granary_keystone","cornucopia_crucible","catalyst_of_the_bounty"],cost:10,consolidated_modifier:"",dr_sum:0.0d,flavor:"bundle",loot:"evercraft:tinkering/hearthkeepers_ladle",bit:0,flag:"hearthkeepers_ladle",name:"Hearthkeeper's Ladle",color:"#E0A857"}

# J.t3 — TIDEWRIGHT'S NET (the 6 fishing charms + the Catalyst of the Bounty reagent → the fishing
#   sub-cap, ✦✦✦). Sub-capstone, no latch. CONDITIONAL +5.0 DR (Riverpearl +2 while fishing +
#   Deepcurrent +3 in water → ONE consolidated tidewright_luck, fires while fishing OR in water).
#   Consolidates Lure II + LotS III on rod + two extra crate rolls + +30% submerged mining + swim
#   efficiency. C37 Catalyst of the Bounty = the ascension reagent consumed in the binding.
data modify storage evercraft:tnk_recipes recipes append value {capstone:"tidewrights_net",family:"J",tier:3,sub_capstone:"tidewrights_net",ingredient_ids:["dockhands_knot","tidecallers_lure","riverpearl_charm","anglerwardens_sigil","coral_divers_pearl","deepcurrent_reliquary","catalyst_of_the_bounty"],cost:10,consolidated_modifier:"evercraft:tidewright_luck",dr_sum:5.0d,flavor:"ascension",loot:"evercraft:tinkering/tidewrights_net",bit:0,flag:"tidewrights_net",name:"Tidewright's Net",color:"#4FB6C8"}

# J.t4 — CORNUCOPIA TIDE (Hearthkeeper's Ladle + Tidewright's Net → the grand flagship, ✦✦✦✦). The
#   PRICIEST grand fusion (cost 26 — above the Dreamer's Reliquary's 24; DECISIONS "Cornucopia Tide
#   priciest"). Eats the TWO trade sub-caps. NO latch bit (bit:0): the Tide, like the Pebble / Reliquary,
#   has no pre-assigned ec.tnk_owned bit; its completed state is detectable by HOLDING cornucopia_tide:true
#   (the apply keys on that flag). CONDITIONAL +5.0 DR consolidated into evercraft:cornucopia_tide_luck
#   (the Net's two fishing-DR charms folded; fires while fishing OR harvesting/in water — ONE breakdown
#   line). Re-grants the union: +2 cook quality + +10.0 CR + crop/aquatic yield + the full fishing kit.
#   The Tide's loot table is NOT Material (final-form Spirit Artifact).
data modify storage evercraft:tnk_recipes recipes append value {capstone:"cornucopia_tide",family:"J",tier:4,sub_capstone:"",ingredient_ids:["hearthkeepers_ladle","tidewrights_net"],cost:26,consolidated_modifier:"evercraft:cornucopia_tide_luck",dr_sum:5.0d,flavor:"ascension",loot:"evercraft:tinkering/cornucopia_tide",bit:0,flag:"cornucopia_tide",name:"Cornucopia Tide",color:"#FFC04D"}

# ------------------------------------------------------------
# HAND-OFF TO recipes_batch_7 (future families K/L + the remaining unbuilt capstones):
#   - This batch ends Family J. recipes_batch_7's rows simply append more; the engine reads list
#     length N dynamically, so a new batch auto-extends the bench with NO engine edit.
#   - registry/load_recipes calls recipes_batch_6 (added there); add the recipes_batch_7 call when
#     it lands. Do NOT renumber or reorder this batch (the Almanac walks it in tree order).
# ------------------------------------------------------------
