# ============================================================
# Tinkering — Family-Recipe REGISTRY batch 7 (Family K — Demiurge's Spirit Artifact lattice)
# ============================================================
# Appends the Family K fusion recipe rows onto storage evercraft:tnk_recipes recipes. Called by
# registry/load_recipes AFTER recipes_batch_6. Seeds Family K (Prospector — Gathering & Mining ->
# Demiurge's Spirit Artifact, the extraction craft loop): the cheap Crate Pair leaf-pair + three sub-bindings
# (Node Mastery = node-craft · Deepdig Line = aquatic-dig · Surveyor Line = gathering QoL) + the grand
# Demiurge's Spirit Artifact (eats the three sub-caps). NO engine edit — plinth/detect reads list length N
# dynamically and gates each row from its own data (same contract as batches 0-6).
#
# Schema is documented in recipes_batch_0 (capstone / family / tier / sub_capstone / ingredient_ids /
# cost / consolidated_modifier / dr_sum / flavor / loot / bit / flag / name / color). All LEAF
# ingredient_ids are the live `artifact:"<id>"` values verified in the art-K wiring (aquatic in
# artifacts/accessories/player_tick; ore/crate/access/yield in forging/ore_mining/check_drop +
# craft_affinity/detect_ordinary_tool + gather/resolve_win + harvest_bonus_read + nodes/* + resonance).
# Intermediate ingredient_ids (crate_pair / node_mastery / deepdig_line / surveyor_line) are the bare
# flags THIS batch's own loot tables stamp. soul_lantern_fragment (re-homed into K) is the XP/economy
# gathering leaf folded into the Surveyor Line. Every loot path resolves to a loot_table/tinkering/*.json
# built in cap-K.
#
# CROSS-FAMILY NOTE: the lattice §K tree's "C12-node" shorthand in Node Mastery is C12 Quenching Stone,
# which is a Family-G FORGE break-speed leaf already consumed by cap-G's Quench Line sub-binding (see
# recipes_batch_4). An item cannot be eaten by two trees, so Node Mastery does NOT take quenching_stone;
# the three node charms (Dowsing Rod / Writ of Passage / Astrolabe) + the Crate Pair are its members.
# This keeps all 16 Family-K leaves accounted for EXACTLY (Crate Pair 2 + Node Mastery 3 + Deepdig 3 +
# Surveyor 8 = 16) with no cross-family double-claim.
#
# DR consolidation (DECISIONS D1 full-power, UNCAPPED — the global DR ceiling rose to 100 in w5). Family K
# carries CONDITIONAL DR only (the Demiurge's Spirit Artifact fires +3.0 DR only while actively mining — the
# Geologist's Loupe idiom, ec.cf_actwin-gated). The dr_sum here RECORDS the consolidated CONDITIONAL value
# for the Almanac + the m4 strip-law to enumerate; the apply side (player_tick) is where the modifier is
# condition-gated:
#   Crate Pair        0.0  (geode + duplicator leaf-pair — no luck)
#   Node Mastery      0.0  (node-craft sub-cap — sense / access / yield, no luck)
#   Deepdig Line      0.0  (aquatic-dig sub-cap — submerged-mining attrs + ore sample, no luck)
#   Surveyor Line     0.0  (gathering-QoL sub-cap — ore roll / crate / pickup / survey, no luck)
#   Demiurge's Spirit Artifact +3.0 CONDITIONAL (the grand carries the lattice's "conditional +3.0 while mining"
#                            -> ONE consolidated demiurges_capstone_luck, fires while ec.cf_actwin is open)
# The +3.0 DR lives ONLY on the grand (no loose K leaf carries DR — U20 is explicitly "NOT raw DR"; the
# sub-caps are pure attribute/yield bundles). bit:0 = no ec.tnk_owned latch (the grand, like the Pebble /
# Reliquary / Cornucopia Tide, has no pre-assigned bit; its completed state is detectable by HOLDING
# demiurges_capstone:true — no new objective).
#
# VARIED tier cost (the lattice §K tree weights): cheap leaf-pair (2) -> aquatic sub-cap (6) -> node +
# survey sub-caps (8 — they eat 4 + 8 charms) -> the GRAND Demiurge's Spirit Artifact at cost 24 (a steep grand,
# below the Cornucopia Tide's PRICIEST 26 per DECISIONS, on par with the Dreamer's Reliquary's 24).
# Crate-SOURCED (not crate-free): the leaves wire into crate/quest/mob sources in later wiring units.
# "magic" never appears (arcane / ancient / potent / power only).
# ------------------------------------------------------------

# K.t1 — CRATE PAIR (Resonant Geode Heart + Resonance Duplicator Charm -> the cheap yield leaf-pair, ✦).
#   The teach-fusion of the Node Mastery line (the prospector's first apprenticeship knot). Sub-capstone
#   label, no latch, zero DR. +2% crate on break/harvest/catch + an extra Perfect-Strike duplicate.
data modify storage evercraft:tnk_recipes recipes append value {capstone:"crate_pair",family:"K",tier:1,sub_capstone:"crate_pair",ingredient_ids:["resonant_geode_heart","resonance_duplicator_charm"],cost:2,consolidated_modifier:"",dr_sum:0.0d,flavor:"bundle",loot:"evercraft:tinkering/crate_pair",bit:0,flag:"crate_pair",name:"Crate Pair",color:"#9AE0C8"}

# K.t2 — DEEPDIG LINE (Tidewright's Pearl + Driftcurrent Fin + Quartzlight Loupe -> the aquatic-dig
#   sub-cap, ✦✦). Sub-capstone, no latch, zero DR. Consolidates the submerged-mining attrs (+55% while
#   submerged = Pearl +30% + Fin +25%) + +0.75 swim efficiency + breath + the on-demand ore sample ping.
#   (NOT eaten by the grand directly — the grand eats the three sub-caps; this IS one of the three.)
data modify storage evercraft:tnk_recipes recipes append value {capstone:"deepdig_line",family:"K",tier:2,sub_capstone:"deepdig_line",ingredient_ids:["tidewright_pearl","driftcurrent_fin","quartzlight_loupe"],cost:6,consolidated_modifier:"",dr_sum:0.0d,flavor:"bundle",loot:"evercraft:tinkering/deepdig_line",bit:0,flag:"deepdig_line",name:"Deepdig Line",color:"#5CC8E0"}

# K.t3 — NODE MASTERY (Wayfinder's Dowsing Rod + Artisan's Writ of Passage + Pathfinder's Astrolabe +
#   the Crate Pair -> the node-craft sub-cap, ✦✦✦). Sub-capstone, no latch, zero DR. Consolidates the
#   node pip + +50% node despawn + rank-gate bypass + the Crate Pair's +2% crate + Perfect-Strike dup.
#   (Crate Pair flag = the bare flag the K.t1 loot table stamps; eats the Pair as a sub-fusion.)
data modify storage evercraft:tnk_recipes recipes append value {capstone:"node_mastery",family:"K",tier:3,sub_capstone:"node_mastery",ingredient_ids:["wayfinders_dowsing_rod","artisans_writ_of_passage","pathfinders_astrolabe","crate_pair"],cost:8,consolidated_modifier:"",dr_sum:0.0d,flavor:"bundle",loot:"evercraft:tinkering/node_mastery",bit:0,flag:"node_mastery",name:"Node Mastery",color:"#C8A85C"}

# K.t3 — SURVEYOR LINE (Prospector's Doohickey + Brushwright's Mitt + Plumb-Bob Token + Echolocator Shard
#   + Spelunker's Resonator + Prospector's Dice + Loadmaster's Sortstone + Soul Lantern Fragment -> the
#   gathering-QoL sub-cap, ✦✦✦). Sub-capstone, no latch, zero DR. Consolidates +1.5% ore bonus-material +
#   the extra node crate + ore auto-pickup + the whole sneak-survey kit (depth / echolocate / locate /
#   sort) + the soul-lantern XP perk.
data modify storage evercraft:tnk_recipes recipes append value {capstone:"surveyor_line",family:"K",tier:3,sub_capstone:"surveyor_line",ingredient_ids:["prospectors_doohickey","brushwrights_mitt","plumb_bob_token","echolocator_shard","spelunkers_resonator","prospectors_dice","loadmasters_sortstone","soul_lantern_fragment"],cost:8,consolidated_modifier:"",dr_sum:0.0d,flavor:"bundle",loot:"evercraft:tinkering/surveyor_line",bit:0,flag:"surveyor_line",name:"Surveyor Line",color:"#B98CE0"}

# K.t4 — DEMIURGE'S CAPSTONE (Node Mastery + Deepdig Line + Surveyor Line -> the grand flagship, ✦✦✦✦).
#   A steep grand fusion (cost 24 — on par with the Dreamer's Reliquary, below the Cornucopia Tide's
#   PRICIEST 26; DECISIONS varied tier cost). Eats the THREE sub-caps. NO latch bit (bit:0): the Capstone,
#   like the Pebble / Reliquary / Cornucopia Tide, has no pre-assigned ec.tnk_owned bit; its completed
#   state is detectable by HOLDING demiurges_capstone:true (the apply keys on that flag). CONDITIONAL +3.0
#   DR consolidated into evercraft:demiurges_capstone_luck (the lattice's "conditional +3.0 while mining" —
#   ONE breakdown line, ec.cf_actwin-gated; pre-wired by art-K in player_tick + dreams/breakdown). Re-grants
#   the whole craft loop: break-speed + mining efficiency + reach + CR + the aquatic kit + every gathering
#   yield/crate/access/survey lever. The Capstone's loot table is NOT Material (final-form Spirit Artifact).
data modify storage evercraft:tnk_recipes recipes append value {capstone:"demiurges_capstone",family:"K",tier:4,sub_capstone:"",ingredient_ids:["node_mastery","deepdig_line","surveyor_line"],cost:24,consolidated_modifier:"evercraft:demiurges_capstone_luck",dr_sum:3.0d,flavor:"ascension",loot:"evercraft:tinkering/demiurges_capstone",bit:0,flag:"demiurges_capstone",name:"Demiurge's Spirit Artifact",color:"#E0B85C"}

# ------------------------------------------------------------
# HAND-OFF TO recipes_batch_8 (future families L + the remaining unbuilt capstones):
#   - This batch ends Family K. recipes_batch_8's rows simply append more; the engine reads list
#     length N dynamically, so a new batch auto-extends the bench with NO engine edit.
#   - registry/load_recipes calls recipes_batch_7 (added there); add the recipes_batch_8 call when
#     it lands. Do NOT renumber or reorder this batch (the Almanac walks it in tree order).
# ------------------------------------------------------------
