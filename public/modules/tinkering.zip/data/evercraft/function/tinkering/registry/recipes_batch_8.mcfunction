# ============================================================
# Tinkering — Family-Recipe REGISTRY batch 8 (Family L — Heart of the Mountain lattice)
# ============================================================
# Appends the Family L fusion recipe rows onto storage evercraft:tnk_recipes recipes. Called by
# registry/load_recipes AFTER recipes_batch_7. Seeds Family L (Vanguard — Buff & Powerful ->
# Heart of the Mountain, the consolidated defensive titan-stone): four sub-bindings (Bulwark Stone =
# flat tank · Titan Core = the heavy mythical defense wards · Ascendant Line = combat-craft · Stride
# Line = traversal) + the grand Heart of the Mountain (eats the four sub-caps). NO engine edit —
# plinth/detect reads list length N dynamically and gates each row from its own data (same contract
# as batches 0-7).
#
# Schema is documented in recipes_batch_0 (capstone / family / tier / sub_capstone / ingredient_ids /
# cost / consolidated_modifier / dr_sum / flavor / loot / bit / flag / name / color). All LEAF
# ingredient_ids are the live `artifact:"<id>"` values verified in the art-L wiring (the 9 new Vanguard
# leaves' FAMILY L block in artifacts/accessories/player_tick + the 4 re-homed mythical defense stones'
# legacy effect blocks). Intermediate ingredient_ids (titan_bulwark / titan_core / ascendant_line /
# stride_line) are the bare flags THIS batch's own loot tables stamp. Every loot path resolves to a
# loot_table/tinkering/*.json built in cap-L.
#
# NAME-COLLISION NOTE: the L tree's TANK sub-binding is the lattice's "Bulwark Stone" (B1 Stoneward +
# B2 Vital Acorn + B7 Anvil Heart + B12 Bulwark Plate). The id `bulwark_stone` is ALREADY taken by the
# Family-D Soulguard ornate sub-binding (cap-D, recipes_batch_3). To avoid a flag / loot-table / apply
# collision, L's tank sub-cap uses the DISTINCT id `titan_bulwark` (display name still "Bulwark Stone").
# Likewise the LEAF Bulwark Plate keeps its own id `bulwark_plate` (art-L) — three distinct ids, no clash.
#
# MEMBER ACCOUNTING (lattice §L "Confirmed 16" = 15 leaves + the grand P1):
#   Bulwark Stone (4)  = stoneward_pebble + vital_acorn + anvil_heart + bulwark_plate
#   Titan Core (5)     = temporal_hourglass + heart_of_the_void + redstone_heart + prism_of_light + bastion_totem
#   Ascendant Line (3) = reavers_knuckle + resonant_locket + ascendant_forgeheart
#   Stride Line (3)    = sprinters_anklet + wayfarers_greaves + sure_step_pebble
#   Heart of the Mountain = eats the 4 sub-caps. 4+5+3+3 = 15 leaves + P1 grand = 16.
# The Stride pieces (B5 / B9 / U2) were built by art-F/art-L; the 4 mythical defense stones are EXISTING
# items re-homed (Material-tagged, not rebuilt). P2 Ascendant Forgeheart is the combat-craft trophy parked
# in L (Open-Decision 1b: the alt was a merged G+H Crafter's Guild head — DEFAULTED to L per cap-L brief).
#
# DR consolidation (DECISIONS D1 full-power, UNCAPPED — the global DR ceiling rose to 100 in w5). Family L
# is a POWER-BUNDLE with ZERO BASE DR (the lattice §L: "0 base; P3's DR consolidates in B, not here"). The
# ONLY luck in L is B10 Resonant Locket's CONDITIONAL +1.0 node-proximity DR (reports under B's craft-luck
# line per the lattice). That conditional DR consolidates into the Ascendant Line + the grand via ONE
# consolidated modifier (evercraft:ascendant_locket_luck), condition-gated in the apply side (a nearby
# ec.cf_node_data marker) — the dr_sum here RECORDS the consolidated CONDITIONAL value for the Almanac +
# the m4 strip-law:
#   Bulwark Stone   0.0  (flat tank stones — no luck)
#   Titan Core      0.0  (mythical-defense wards — effects, no luck)
#   Ascendant Line +1.0 CONDITIONAL (the B10 node-proximity DR consolidated -> ascendant_locket_luck)
#   Stride Line     0.0  (traversal — no luck)
#   Heart of the Mountain +1.0 CONDITIONAL (re-grants the Ascendant Line's node-DR -> ascendant_locket_luck)
# bit:0 = no ec.tnk_owned latch (the grand, like the Pebble / Reliquary / Cornucopia Tide / Demiurge's
# Capstone, has no pre-assigned bit; its completed state is detectable by HOLDING heart_of_the_mountain:true).
#
# VARIED tier cost (the lattice §L tree weights; "priciest = the mythical-defense sub-cap" per cap-L brief):
# cheap traversal Stride Line (4) -> tank Bulwark Stone + combat Ascendant Line (6) -> the heavy mythical-
# defense Titan Core (12 — the PRICIEST sub-cap, eats 5 mythical/totem wards) -> the GRAND Heart of the
# Mountain at cost 24 (a steep grand, below the Cornucopia Tide's PRICIEST 26 per DECISIONS, on par with
# the Dreamer's Reliquary's 24). Crate-SOURCED: the leaves wire into crate/quest/mob sources in later
# wiring units. "magic" never appears (arcane / ancient / potent / power only).
# ------------------------------------------------------------

# L.t1 — STRIDE LINE (Sprinter's Anklet + Wayfarer's Greaves + Sure-Step Pebble -> the traversal sub-cap,
#   ✦). Sub-capstone, no latch, zero DR. Consolidates +8% sprint speed + +0.9 step height (Greaves +0.5 +
#   Sure-Step +0.4) + -15% fall damage. The cheapest L fuse (the vanguard's first apprenticeship knot).
data modify storage evercraft:tnk_recipes recipes append value {capstone:"stride_line",family:"L",tier:1,sub_capstone:"stride_line",ingredient_ids:["sprinters_anklet","wayfarers_greaves","sure_step_pebble"],cost:4,consolidated_modifier:"",dr_sum:0.0d,flavor:"bundle",loot:"evercraft:tinkering/stride_line",bit:0,flag:"stride_line",name:"Stride Line",color:"#8CD0A0"}

# L.t2 — BULWARK STONE (Stoneward Pebble + Vital Acorn + Anvil Heart + Bulwark Plate -> the flat tank
#   sub-cap, ✦✦). Sub-capstone, no latch, zero DR. Consolidates +5 Armor (Stoneward +2 + Bulwark Plate +3)
#   + +2 Armor Toughness (Anvil +1 + Bulwark Plate +1) + +2 Max Health (Vital Acorn) + 15% KB resist (Anvil)
#   + 10% explosion-KB resist (Bulwark Plate). DISTINCT id `titan_bulwark` (the `bulwark_stone` id is the
#   Family-D Soulguard sub-cap; display name is still "Bulwark Stone").
data modify storage evercraft:tnk_recipes recipes append value {capstone:"titan_bulwark",family:"L",tier:2,sub_capstone:"titan_bulwark",ingredient_ids:["stoneward_pebble","vital_acorn","anvil_heart","bulwark_plate"],cost:6,consolidated_modifier:"",dr_sum:0.0d,flavor:"bundle",loot:"evercraft:tinkering/titan_bulwark",bit:0,flag:"titan_bulwark",name:"Titan Bulwark",color:"#9AA7B5"}

# L.t2 — ASCENDANT LINE (Reaver's Knuckle + Resonant Locket + Ascendant Forgeheart -> the combat-craft
#   sub-cap, ✦✦). Sub-capstone, no latch. Consolidates +3.0 Attack Damage (Locket +1 + Forgeheart +2) +
#   a conditional +1.0 Attack above 80% HP (Reaver) + +5.0 CR (Forgeheart) + the CONDITIONAL +1.0
#   node-proximity DR (Resonant Locket -> the ONE consolidated ascendant_locket_luck, ec.cf_node_data-gated).
data modify storage evercraft:tnk_recipes recipes append value {capstone:"ascendant_line",family:"L",tier:2,sub_capstone:"ascendant_line",ingredient_ids:["reavers_knuckle","resonant_locket","ascendant_forgeheart"],cost:6,consolidated_modifier:"evercraft:ascendant_locket_luck",dr_sum:1.0d,flavor:"bundle",loot:"evercraft:tinkering/ascendant_line",bit:0,flag:"ascendant_line",name:"Ascendant Line",color:"#E0A65C"}

# L.t3 — TITAN CORE (Temporal Hourglass + Heart of the Void + Redstone Heart + Prism of Light + Bastion
#   Totem -> the heavy mythical-defense sub-cap, ✦✦✦). Sub-capstone, no latch, zero DR. Consolidates the
#   ward union (Resistance II, Absorption IV, Haste III, Speed I, Slow Falling, Night Vision) + the Bastion
#   Totem's party-wide Resistance I aura within 16 b. The PRICIEST L sub-cap (cost 12, eats 5 mythical/
#   totem wards) per the cap-L brief.
data modify storage evercraft:tnk_recipes recipes append value {capstone:"titan_core",family:"L",tier:3,sub_capstone:"titan_core",ingredient_ids:["temporal_hourglass","heart_of_the_void","redstone_heart","prism_of_light","bastion_totem"],cost:12,consolidated_modifier:"",dr_sum:0.0d,flavor:"bundle",loot:"evercraft:tinkering/titan_core",bit:0,flag:"titan_core",name:"Titan Core",color:"#7C8AA0"}

# L.t4 — HEART OF THE MOUNTAIN (Bulwark Stone + Titan Core + Ascendant Line + Stride Line -> the grand
#   flagship, ✦✦✦✦). A steep grand fusion (cost 24 — on par with the Dreamer's Reliquary, below the
#   Cornucopia Tide's PRICIEST 26; DECISIONS varied tier cost). Eats the FOUR sub-caps. NO latch bit
#   (bit:0): the Heart, like the Pebble / Reliquary / Cornucopia Tide / Demiurge's Spirit Artifact, has no
#   pre-assigned ec.tnk_owned bit; its completed state is detectable by HOLDING heart_of_the_mountain:true
#   (the apply keys on that flag). CONDITIONAL +1.0 node-proximity DR consolidated into
#   evercraft:ascendant_locket_luck (re-granted from the Ascendant Line half — ONE breakdown line, gated on
#   a nearby ec.cf_node_data marker; reports under B's craft-luck line per the lattice). Re-grants the whole
#   vanguard: +5 armor / +2 toughness / +2 max HP / 15% KB / 10% explosion-KB + the ward union + +3 attack
#   (+1 above 80% HP) + +5 CR + +8% sprint / +0.9 step / -15% fall + the Bastion aura. The Heart's loot
#   table is NOT Material (final-form Spirit Artifact).
data modify storage evercraft:tnk_recipes recipes append value {capstone:"heart_of_the_mountain",family:"L",tier:4,sub_capstone:"",ingredient_ids:["titan_bulwark","titan_core","ascendant_line","stride_line"],cost:24,consolidated_modifier:"evercraft:ascendant_locket_luck",dr_sum:1.0d,flavor:"ascension",loot:"evercraft:tinkering/heart_of_the_mountain",bit:0,flag:"heart_of_the_mountain",name:"Heart of the Mountain",color:"#C8B488"}

# ------------------------------------------------------------
# HAND-OFF TO recipes_batch_9 (future families + the remaining unbuilt capstones):
#   - This batch ends Family L. recipes_batch_9's rows simply append more; the engine reads list
#     length N dynamically, so a new batch auto-extends the bench with NO engine edit.
#   - registry/load_recipes calls recipes_batch_8 (added there); add the recipes_batch_9 call when
#     it lands. Do NOT renumber or reorder this batch (the Almanac walks it in tree order).
# ------------------------------------------------------------
