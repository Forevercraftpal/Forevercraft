# ============================================================
# Tinkering — Family-Recipe REGISTRY batch 2 (Family C — Wayfarer's Lens lattice)
# ============================================================
# Appends the Family C fusion recipe rows onto storage evercraft:tnk_recipes recipes. Called by
# registry/load_recipes AFTER recipes_batch_1. Seeds Family C (Wayfarer Sense & Travel → Wayfarer's
# Lens, BUNDLE — zero DR): the leaf-pair Far Sight Lens + three sub-bindings (Oracle Lens /
# Wanderer's Token / Surveyor's Kit) + the grand Wayfarer's Lens. NO engine edit — plinth/detect reads
# list length N dynamically and gates each row from its own data (same contract as batch 0 / batch 1).
#
# Schema is documented in recipes_batch_0 (capstone / family / tier / sub_capstone / ingredient_ids /
# cost / consolidated_modifier / dr_sum / flavor / loot / bit / flag / name / color). All ingredient_ids
# are the live `artifact:"<id>"` values verified in artifacts/accessories/player_tick (the loose
# C-member lines, both the 10 existing utility + the 7 art-C leaves) + the sub-binding flags this
# batch's own loot tables stamp (far_sight_lens / oracle_lens / wanderers_token / surveyors_kit). Every
# loot path resolves to a loot_table/tinkering/*.json built in cap-C (no dangling table).
#
# BALANCE-NEUTRAL — ZERO DR across the whole family (DECISIONS + lattice §C: "No DR — balance-neutral
# bundle … ships without any DR gate"; Open-Decision 4: the +40/10% dodge went to Soulguard Aegis, NOT
# the Wayfarer line). Every row carries dr_sum:0.0d and consolidated_modifier:"" — the apply side
# (tinkering/wayfarer/*_apply) emits NO luck modifier; it re-grants only sense/travel/survey perks. The
# registry RECORDS the empty modifier so the Almanac + the m4 audit see the family is DR-free.
# bit:0 = no ec.tnk_owned latch (the grand Lens, like the Pebble / Reliquary, has no pre-assigned bit;
# its completed state is detectable by HOLDING wayfarers_lens:true — no new objective).
#
# Varied tier cost per the lattice tree weights (✦ leaf-pair = 2 · ✦✦ = 5 · ✦✦✦ = 5-7 · grand = 16).
# "magic" never appears (arcane / ancient / potent / power only).
# ------------------------------------------------------------

# C.t1 — FAR SIGHT LENS (Seer's Compass + Warden's Echo → the leaf-pair, ✦). The cheap teach-fusion of
#   the Oracle Lens line (mob-vision both-eyes). Sub-capstone label, no latch, zero DR.
data modify storage evercraft:tnk_recipes recipes append value {capstone:"far_sight_lens",family:"C",tier:1,sub_capstone:"far_sight_lens",ingredient_ids:["seers_compass","wardens_echo"],cost:2,consolidated_modifier:"",dr_sum:0.0d,flavor:"bundle",loot:"evercraft:tinkering/far_sight_lens",bit:0,flag:"far_sight_lens",name:"Far Sight Lens",color:"dark_aqua"}

# C.t2 — ORACLE LENS (Far Sight Lens + Spelunker's Echo + Glowstone Pendant + Lantern-Lichen Clasp →
#   the sense ladder, ✦✦✦). Sub-capstone, no latch, zero DR. Folds the Far Sight Lens (seer+warden).
data modify storage evercraft:tnk_recipes recipes append value {capstone:"oracle_lens",family:"C",tier:2,sub_capstone:"oracle_lens",ingredient_ids:["far_sight_lens","spelunkers_echo","glowstone_pendant","lantern_lichen_clasp"],cost:5,consolidated_modifier:"",dr_sum:0.0d,flavor:"bundle",loot:"evercraft:tinkering/oracle_lens",bit:0,flag:"oracle_lens",name:"Oracle Lens",color:"dark_aqua"}

# C.t2 — WANDERER'S TOKEN (Traveler's Charm + Wind Chime + Featherweight Stone + Worn Compass +
#   Stormcatcher Shard → the movement node, ✦✦). Sub-capstone, no latch, zero DR.
data modify storage evercraft:tnk_recipes recipes append value {capstone:"wanderers_token",family:"C",tier:2,sub_capstone:"wanderers_token",ingredient_ids:["travelers_charm","wind_chime","featherweight_stone","worn_compass","stormcatcher_shard"],cost:5,consolidated_modifier:"",dr_sum:0.0d,flavor:"bundle",loot:"evercraft:tinkering/wanderers_token",bit:0,flag:"wanderers_token",name:"Wanderer's Token",color:"aqua"}

# C.t3 — SURVEYOR'S KIT (Cartographer's Lens + Wayworn Tally + Wanderer's Whetcompass + Wayfarer's
#   Sextant + Voyager's Far-Lens + Loremaster's Omni-Codex + Cartographer's Astrolabe → the
#   readout/survey node, ✦✦✦). Sub-capstone, no latch, zero DR. The 7-input mythical survey node.
data modify storage evercraft:tnk_recipes recipes append value {capstone:"surveyors_kit",family:"C",tier:3,sub_capstone:"surveyors_kit",ingredient_ids:["cartographers_lens","wayworn_tally","wanderers_whetcompass","wayfarers_sextant","voyagers_far_lens","loremasters_omni_codex","cartographers_astrolabe"],cost:7,consolidated_modifier:"",dr_sum:0.0d,flavor:"bundle",loot:"evercraft:tinkering/surveyors_kit",bit:0,flag:"surveyors_kit",name:"Surveyor's Kit",color:"gold"}

# C.t4 — WAYFARER'S LENS (Oracle Lens + Wanderer's Token + Surveyor's Kit → the grand flagship, ✦✦✦✦).
#   The Wayfarer bundle's grand: every absorbed sense/travel/survey perk at max sense range, ZERO DR.
#   NO latch bit (bit:0): the Lens, like the Pebble / Reliquary, has no pre-assigned ec.tnk_owned bit;
#   its completed state is detectable by HOLDING wayfarers_lens:true (the apply keys on that flag). The
#   Lens's loot table is NOT Material (final-form Spirit Artifact). consolidated_modifier:"" / dr_sum:0
#   (balance-neutral — the headline is the consolidated UTILITY bundle, not any Dream Rate).
data modify storage evercraft:tnk_recipes recipes append value {capstone:"wayfarers_lens",family:"C",tier:4,sub_capstone:"",ingredient_ids:["oracle_lens","wanderers_token","surveyors_kit"],cost:16,consolidated_modifier:"",dr_sum:0.0d,flavor:"bundle",loot:"evercraft:tinkering/wayfarers_lens",bit:0,flag:"wayfarers_lens",name:"Wayfarer's Lens",color:"#5FE0D0"}

# ------------------------------------------------------------
# HAND-OFF TO recipes_batch_3 (future families D + the remaining unbuilt capstones):
#   - This batch ends Family C. recipes_batch_3's rows simply append more; the engine reads list
#     length N dynamically, so a new batch auto-extends the bench with NO engine edit.
#   - registry/load_recipes calls recipes_batch_2 (added there); add the recipes_batch_3 call when
#     it lands. Do NOT renumber or reorder this batch (the Almanac walks it in tree order).
# ------------------------------------------------------------
