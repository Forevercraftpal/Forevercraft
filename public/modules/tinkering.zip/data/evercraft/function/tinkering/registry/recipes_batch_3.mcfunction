# ============================================================
# Tinkering — Family-Recipe REGISTRY batch 3 (Family D — Soulguard Aegis lattice)
# ============================================================
# Appends the Family D fusion recipe rows onto storage evercraft:tnk_recipes recipes. Called by
# registry/load_recipes AFTER recipes_batch_2. Seeds Family D (Survival & Totem → Soulguard Aegis,
# BUNDLE — zero DR, power-dense): the three/four sub-bindings (Grand Totem / Lifewarden / Bulwark
# Stone / Aura Ward) + the grand Soulguard Aegis. NO engine edit — plinth/detect reads list length N
# dynamically and gates each row from its own data (same contract as batch 0 / 1 / 2).
#
# Schema is documented in recipes_batch_0 (capstone / family / tier / sub_capstone / ingredient_ids /
# cost / consolidated_modifier / dr_sum / flavor / loot / bit / flag / name / color). All ingredient_ids
# are the live `artifact:"<id>"` values verified in artifacts/accessories/player_tick (the 15 existing
# D members + phoenix_totem from art-D) + the sub-binding flags this batch's own loot tables stamp
# (grand_totem / lifewarden / bulwark_stone / aura_ward). Every loot path resolves to a
# loot_table/tinkering/*.json built in cap-D (no dangling table).
#
# BALANCE-NEUTRAL — ZERO DR across the whole family (DECISIONS + lattice §D: "No DR; power-dense (G6
# caps death-saves)"). Every row carries dr_sum:0.0d and consolidated_modifier:"" — the apply side
# (tinkering/soulguard/*_apply) emits NO luck modifier; it re-grants only defensive ward effects. The
# big headline is NOT Dream Rate — it is the consolidated DEFENSE bundle + the ONE +40 (10%) dodge the
# grand Soulguard Aegis adds via m1's ec.acc_dodge lane (Open-Decision 4: Soulguard is THE one
# final-form that gets the big dodge; wired in player_tick's m1 LEAF block, NOT the registry).
# G6 enforced at apply time: every D death-save (Phoenix/Soul/Void) routes through ONE shared cooldown
# bucket (ec.cd_save / soulguard_save); Absorption = max not sum (effect give SETs, never sums).
# bit:0 = no ec.tnk_owned latch (the grand Aegis, like the Pebble / Reliquary / Wayfarer's Lens, has no
# pre-assigned bit; its completed state is detectable by HOLDING soulguard_aegis:true — no new objective).
#
# Varied tier cost per the lattice tree weights (✦✦ = 5 · ✦✦✦ = 7 · grand = 16).
# "magic" never appears (arcane / ancient / potent / power only).
# ------------------------------------------------------------

# D.t1 — GRAND TOTEM (Berserker Totem + Warden Totem + Soul Protection + Phoenix Totem → the 4-totem
#   node, ✦✦✦). Sub-capstone, no latch, zero DR. Holds the consolidated death-save (routes through the
#   shared ec.cd_save bucket at apply time).
data modify storage evercraft:tnk_recipes recipes append value {capstone:"grand_totem",family:"D",tier:1,sub_capstone:"grand_totem",ingredient_ids:["berserker_totem","warden_totem","soul_protection","phoenix_totem"],cost:7,consolidated_modifier:"",dr_sum:0.0d,flavor:"bundle",loot:"evercraft:tinkering/grand_totem",bit:0,flag:"grand_totem",name:"Grand Totem",color:"gold"}

# D.t1 — LIFEWARDEN (Void Heart + Heartstone + Healer's Salve → the death-save/regen node, ✦✦).
#   Sub-capstone, no latch, zero DR. Death-save (Void Recall) routes through the shared ec.cd_save bucket.
data modify storage evercraft:tnk_recipes recipes append value {capstone:"lifewarden",family:"D",tier:1,sub_capstone:"lifewarden",ingredient_ids:["void_heart","heartstone","healers_salve"],cost:5,consolidated_modifier:"",dr_sum:0.0d,flavor:"bundle",loot:"evercraft:tinkering/lifewarden",bit:0,flag:"lifewarden",name:"Lifewarden",color:"red"}

# D.t1 — BULWARK STONE (Iron Talisman + Phoenix Feather + Blaze Core + Sea Heart Relic + Phantom Charm →
#   the resist/elemental node, ✦✦). Sub-capstone, no latch, zero DR.
data modify storage evercraft:tnk_recipes recipes append value {capstone:"bulwark_stone",family:"D",tier:1,sub_capstone:"bulwark_stone",ingredient_ids:["iron_talisman","phoenix_feather","blaze_core","sea_heart_relic","phantom_charm"],cost:5,consolidated_modifier:"",dr_sum:0.0d,flavor:"bundle",loot:"evercraft:tinkering/bulwark_stone",bit:0,flag:"bulwark_stone",name:"Bulwark Stone",color:"gray"}

# D.t1 — AURA WARD (Nether Star Shard + Wither Rose Crown + Sculk Singularity + Berserker's Fang → the
#   auras/conditional node, ✦✦). Sub-capstone, no latch, zero DR.
data modify storage evercraft:tnk_recipes recipes append value {capstone:"aura_ward",family:"D",tier:1,sub_capstone:"aura_ward",ingredient_ids:["nether_star_shard","wither_rose_crown","sculk_singularity","berserkers_fang"],cost:5,consolidated_modifier:"",dr_sum:0.0d,flavor:"bundle",loot:"evercraft:tinkering/aura_ward",bit:0,flag:"aura_ward",name:"Aura Ward",color:"dark_aqua"}

# D.t2 — SOULGUARD AEGIS (Grand Totem + Lifewarden + Bulwark Stone + Aura Ward → the grand flagship,
#   ✦✦✦✦). The Soulguard bundle's grand: every absorbed defensive ward + the ONE consolidated
#   death-save (shared ec.cd_save bucket, Absorption max-not-sum, G6) + the ONE +40 (10%) dodge in the
#   pack (m1 ec.acc_dodge LEAF block, Open-Decision 4). NO latch bit (bit:0): the Aegis, like the
#   Pebble / Reliquary / Wayfarer's Lens, has no pre-assigned ec.tnk_owned bit; its completed state is
#   detectable by HOLDING soulguard_aegis:true (the apply keys on that flag). The Aegis's loot table is
#   NOT Material (final-form Spirit Artifact). consolidated_modifier:"" / dr_sum:0 (balance-neutral —
#   the headline is the consolidated DEFENSE bundle + the dodge, not any Dream Rate).
data modify storage evercraft:tnk_recipes recipes append value {capstone:"soulguard_aegis",family:"D",tier:2,sub_capstone:"",ingredient_ids:["grand_totem","lifewarden","bulwark_stone","aura_ward"],cost:16,consolidated_modifier:"",dr_sum:0.0d,flavor:"bundle",loot:"evercraft:tinkering/soulguard_aegis",bit:0,flag:"soulguard_aegis",name:"Soulguard Aegis",color:"#FFD45A"}

# ------------------------------------------------------------
# HAND-OFF TO recipes_batch_4 (future families G/H/J/K/L + the remaining unbuilt capstones):
#   - This batch ends Family D. recipes_batch_4's rows simply append more; the engine reads list
#     length N dynamically, so a new batch auto-extends the bench with NO engine edit.
#   - registry/load_recipes calls recipes_batch_3 (added there); add the recipes_batch_4 call when
#     it lands. Do NOT renumber or reorder this batch (the Almanac walks it in tree order).
# ------------------------------------------------------------
