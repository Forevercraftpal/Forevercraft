# ============================================================
# Tinkering — Family-Recipe REGISTRY batch 4 (Family G — Grandforge Regalia lattice)
# ============================================================
# Appends the Family G fusion recipe rows onto storage evercraft:tnk_recipes recipes. Called by
# registry/load_recipes AFTER recipes_batch_3. Seeds Family G (Forge Trade → Grandforge Regalia,
# BUNDLE — zero DR, the blacksmith trade-guild): the four sub-bindings (Smith's Apron / Quench Line /
# Forge Resolve / Grand Anvil Heart) + the grand Grandforge Regalia. NO engine edit — plinth/detect
# reads list length N dynamically and gates each row from its own data (same contract as batch 0-3).
#
# Schema is documented in recipes_batch_0 (capstone / family / tier / sub_capstone / ingredient_ids /
# cost / consolidated_modifier / dr_sum / flavor / loot / bit / flag / name / color). All ingredient_ids
# are the live `artifact:"<id>"` values verified in artifacts/accessories/player_tick + craft_rate/
# calculate + forging/minigame/resolve (the 12 G forge leaves from art-G) + the sub-binding flags this
# batch's own loot tables stamp (smiths_apron / quench_line / forge_resolve) + grand_anvil_heart (the
# existing C17 leaf, now flag-stamped). Every loot path resolves to a loot_table built in cap-G (or the
# existing artifacts/exquisite/grand_anvil_heart leaf table — no dangling table).
#
# BALANCE-NEUTRAL — ZERO DR across the whole family (DECISIONS + lattice §G: "DR consolidated: 0; CR is
# set-not-add; bundle"). Every row carries dr_sum:0.0d and consolidated_modifier:"" — the apply side
# (tinkering/grandforge/*_apply) emits NO luck modifier; it re-grants only forge attributes (break-speed
# + mining-efficiency) + the CR/resolve/yield event hooks route through their own one-writer files
# (calculate / resolve / detect_ordinary_tool / check_drop / harvest_bonus_read), gated on the held
# capstone flag, with the loose leaf CR adds m4-suppressed (Newcomer-exempt) so a re-acquired leaf never
# doubles the break-speed/CR. CR never stacks (ec.cr_temp is set-not-add — the ONE writer in calculate).
# bit:0 = no ec.tnk_owned latch (the grand Regalia, like the Pebble / Reliquary / Wayfarer's Lens /
# Soulguard Aegis, has no pre-assigned bit; its completed state is detectable by HOLDING
# grandforge_regalia:true — no new objective).
#
# Varied tier cost per the lattice tree weights + DECISIONS "varied fusion cost" (cheap leaf-pairs ->
# pricier sub-caps -> grand): Smith's Apron leaf-pair ✦ = 3 · Quench Line ✦✦ = 5 · Forge Resolve ✦✦ = 5
# · Grand Anvil Heart ✦✦✦ = 7 · Grandforge Regalia grand ✦✦✦✦ = 16.
# G/H stay SEPARATE guilds with reserved-for-expansion slots (DECISIONS + Open-Decision 1a).
# "magic" never appears (arcane / ancient / potent / power only).
# ------------------------------------------------------------

# G.t1 — SMITH'S APRON (Apprentice's Bellows Charm + Tinsmith's Pocket Hammer → the CR + efficiency
#   leaf-pair, ✦). The cheap teach-fusion of the Grandforge line. Sub-capstone, no latch, zero DR.
data modify storage evercraft:tnk_recipes recipes append value {capstone:"smiths_apron",family:"G",tier:1,sub_capstone:"smiths_apron",ingredient_ids:["apprentices_bellows_charm","tinsmiths_pocket_hammer"],cost:3,consolidated_modifier:"",dr_sum:0.0d,flavor:"bundle",loot:"evercraft:tinkering/smiths_apron",bit:0,flag:"smiths_apron",name:"Smith's Apron",color:"#C8A165"}

# G.t2 — QUENCH LINE (Quarry-Worn Knuckle + Whetstone Charm + Quenching Stone + Quarryman's Grip → the
#   break-speed node, ✦✦). Sub-capstone, no latch, zero DR. Consolidated +28% break + Efficiency +2.
data modify storage evercraft:tnk_recipes recipes append value {capstone:"quench_line",family:"G",tier:2,sub_capstone:"quench_line",ingredient_ids:["quarry_worn_knuckle","whetstone_charm","quenching_stone","quarrymans_grip"],cost:5,consolidated_modifier:"",dr_sum:0.0d,flavor:"bundle",loot:"evercraft:tinkering/quench_line",bit:0,flag:"quench_line",name:"Quench Line",color:"#9AB4C8"}

# G.t2 — FORGE RESOLVE (Smelter's Sigil + Prospector's Loupe + Forgemaster's Tongs → the yield/quality
#   node, ✦✦). Sub-capstone, no latch, zero DR. All three perks are event-gated (auto-smelt / ore-roll /
#   forge-resolve), routed through their own hooks gated on the forge_resolve flag.
data modify storage evercraft:tnk_recipes recipes append value {capstone:"forge_resolve",family:"G",tier:2,sub_capstone:"forge_resolve",ingredient_ids:["smelters_sigil","prospectors_loupe","forgemasters_tongs"],cost:5,consolidated_modifier:"",dr_sum:0.0d,flavor:"bundle",loot:"evercraft:tinkering/forge_resolve",bit:0,flag:"forge_resolve",name:"Forge Resolve",color:"#D88A55"}

# G.t3 — GRAND ANVIL HEART (Master Smith's Crystal + Ember-Forged Band → the existing C17 leaf, ✦✦✦).
#   Sub-capstone, no latch, zero DR. This is the EXISTING grand_anvil_heart leaf (built in art-G): its
#   break +25% / +1 forge-resolve / +0.3 CR perks already fire from player_tick + resolve + calculate
#   (no new apply needed). loot points to the existing artifacts/exquisite/grand_anvil_heart table (now
#   flag-stamped grand_anvil_heart:true so stamp_result can find the spawned result). C17 IS the output,
#   so its inputs are C16 (Master Smith's Crystal) + B8 (Ember-Forged Band) — the lattice's "C16+C17+B8".
data modify storage evercraft:tnk_recipes recipes append value {capstone:"grand_anvil_heart",family:"G",tier:3,sub_capstone:"grand_anvil_heart",ingredient_ids:["master_smiths_crystal","ember_forged_band"],cost:7,consolidated_modifier:"",dr_sum:0.0d,flavor:"bundle",loot:"evercraft:artifacts/exquisite/grand_anvil_heart",bit:0,flag:"grand_anvil_heart",name:"Grand Anvil Heart",color:"light_purple"}

# G.t4 — GRANDFORGE REGALIA (Smith's Apron + Quench Line + Forge Resolve + Grand Anvil Heart → the grand
#   flagship, ✦✦✦✦). The Grandforge bundle's grand: every absorbed forge charm — break +53% / Efficiency
#   +3 / +0.6 CR / auto-smelt / extra ore-roll / double-log / +2 forge quality — consolidated behind one
#   held item, ZERO DR. CR is set-not-add so it NEVER stacks. NO latch bit (bit:0): the Regalia, like the
#   Pebble / Reliquary / Wayfarer's Lens / Soulguard Aegis, has no pre-assigned ec.tnk_owned bit; its
#   completed state is detectable by HOLDING grandforge_regalia:true (the apply keys on that flag). The
#   Regalia's loot table is NOT Material (final-form Spirit Artifact). consolidated_modifier:"" / dr_sum:0
#   (balance-neutral — the headline is the consolidated FORGE bundle, not any Dream Rate).
data modify storage evercraft:tnk_recipes recipes append value {capstone:"grandforge_regalia",family:"G",tier:4,sub_capstone:"",ingredient_ids:["smiths_apron","quench_line","forge_resolve","grand_anvil_heart"],cost:16,consolidated_modifier:"",dr_sum:0.0d,flavor:"bundle",loot:"evercraft:tinkering/grandforge_regalia",bit:0,flag:"grandforge_regalia",name:"Grandforge Regalia",color:"#FFB347"}

# G.t1 — FORGE CHARM (Bellows Ember + Slack-Tub Flint -> the awakened common Forge Charm). The two
#   smith's-leaves fuse into one charm, ✦. (2026-06-11 identity pass: the leaves were placeholder
#   "Forge Charm (Reserved I/II)" blanks — now real artifacts with their own small stats: Bellows Ember
#   +3% break speed, Slack-Tub Flint +10% underwater mining. ids forge_seed_a/_b UNCHANGED, so this
#   recipe row, the collected/* advancements, and chron_pool craft references all hold.)
#   Common leaf, no latch, zero DR (Family G bundle).
#   ingredient_ids are the seeds' existing artifact ids (matched by test_ingredient's artifact:"<id>"
#   clause -> NO item edit on the seeds). flag stamps forge_charm:true so stamp_result finds the spawned
#   result. Its +1 mining_efficiency + 5% break-speed fire from the player_tick attribute idiom (the
#   tinsmiths_pocket_hammer / quarry_worn_knuckle mirror), gated on held forge_charm; clear-on-removal
#   in accessory_cleanup. No CR, no luck. cost 3 = the cheapest Family G leaf-pair (matches Smith's Apron).
data modify storage evercraft:tnk_recipes recipes append value {capstone:"forge_charm",family:"G",tier:1,sub_capstone:"",ingredient_ids:["forge_seed_a","forge_seed_b"],cost:3,consolidated_modifier:"",dr_sum:0.0d,flavor:"bundle",loot:"evercraft:tinkering/forge_charm",bit:0,flag:"forge_charm",name:"Forge Charm",color:"#FFB347"}

# ------------------------------------------------------------
# HAND-OFF TO recipes_batch_5 (future families H/J/K/L + the remaining unbuilt capstones):
#   - This batch ends Family G. recipes_batch_5's rows simply append more; the engine reads list
#     length N dynamically, so a new batch auto-extends the bench with NO engine edit.
#   - registry/load_recipes calls recipes_batch_4 (added there); add the recipes_batch_5 call when
#     it lands. Do NOT renumber or reorder this batch (the Almanac walks it in tree order).
# ------------------------------------------------------------
