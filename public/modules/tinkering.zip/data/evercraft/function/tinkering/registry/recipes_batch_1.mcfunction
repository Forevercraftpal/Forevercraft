# ============================================================
# Tinkering — Family-Recipe REGISTRY batch 1 (Family B — Dreamer's Reliquary lattice)
# ============================================================
# Appends the Family B fusion recipe rows onto storage evercraft:tnk_recipes recipes. Called by
# registry/load_recipes AFTER recipes_batch_0. Seeds Family B (Dream & Luck → Dreamer's Reliquary,
# ascension): the four sub-bindings (Fortune Coffer / Dream Lens / Astral Core / Craft-Luck Sigil)
# + the Lucky Charm common starter + the grand Dreamer's Reliquary. NO engine edit — plinth/detect
# reads list length N dynamically and gates each row from its own data (same contract as batch 0).
#
# Schema is documented in recipes_batch_0 (capstone / family / tier / sub_capstone / ingredient_ids
# / cost / consolidated_modifier / dr_sum / flavor / loot / bit / flag / name / color). All
# ingredient_ids are the live `artifact:"<id>"` values verified in
# artifacts/accessories/player_tick (the loose B-member lines) + the sub-binding flags this batch's
# own loot tables stamp (lucky_charm / fortune_coffer / dream_lens / astral_core / craft_luck_sigil).
# Every loot path resolves to a loot_table/tinkering/*.json built in cap-B (no dangling table).
#
# DR consolidation (DECISIONS D1 full-power, UNCAPPED — the global DR ceiling rose to 100 in w5):
#   Lucky Charm      +2.0  (Wishing Shard +1 + Ruin Watch +1)
#   Fortune Coffer   +5.0  (5 ornate DR charms)
#   Dream Lens       +7.0  (Sculk Heart +2 + Beacon +3 + Dream Aegis +2)
#   Astral Core      +25.0 (Codex +3 + Nexus +4 + Claude's Eye +1 + Claude's Gift +5 + Crown +12)
#   Craft-Luck Sigil +7.0  (conditional — Loupe +2 + Cache-Eye +2 + Worldforge +3, while working)
#   Dreamer's Reliquary +24.0 (LOCKED grand headline per DECISIONS — folds the 4 sub-nodes)
# The apply side (tinkering/reliquary/*_apply) emits each consolidated_modifier; the registry only
# RECORDS it so the Almanac + the m4 strip-law can enumerate the ids. bit:0 = no ec.tnk_owned latch
# (the grand Reliquary, like the Pebble of Creation, has no pre-assigned bit; its completed state is
# detectable by HOLDING dreamers_reliquary:true — no new objective).
#
# "magic" never appears (arcane / ancient / potent / power only).
# ------------------------------------------------------------

# B.t1 — LUCKY CHARM (Wishing Shard + Ruin Watch → the common starter). Cheap leaf-tier fusion (the
#   teach-fusion of the Dreamer's tree). Sub-capstone label, no latch.
data modify storage evercraft:tnk_recipes recipes append value {capstone:"lucky_charm",family:"B",tier:1,sub_capstone:"lucky_charm",ingredient_ids:["wishing_shard","ruin_watch"],cost:2,consolidated_modifier:"evercraft:lucky_charm_luck",dr_sum:2.0d,flavor:"ascension",loot:"evercraft:tinkering/lucky_charm",bit:0,flag:"lucky_charm",name:"Dreamer's Charm",color:"green"}

# B.t2 — FORTUNE COFFER (the 5 ornate DR charms → one coffer). Sub-capstone, no latch. +5.0 DR.
data modify storage evercraft:tnk_recipes recipes append value {capstone:"fortune_coffer",family:"B",tier:2,sub_capstone:"fortune_coffer",ingredient_ids:["ruin_watch","miners_lantern","merchants_coin","anglers_pearl","enchanted_monocle"],cost:5,consolidated_modifier:"evercraft:fortune_coffer_luck",dr_sum:5.0d,flavor:"ascension",loot:"evercraft:tinkering/fortune_coffer",bit:0,flag:"fortune_coffer",name:"Fortune Coffer",color:"yellow"}

# B.t2 — DREAM LENS (Sculk Heart + Beacon of Ancients + Dream Aegis → one lens). Sub-capstone, no
#   latch. +7.0 DR (carries Beacon's full harmonize-gated beacon union too).
data modify storage evercraft:tnk_recipes recipes append value {capstone:"dream_lens",family:"B",tier:2,sub_capstone:"dream_lens",ingredient_ids:["sculk_heart","beacon_of_ancients","dream_aegis"],cost:6,consolidated_modifier:"evercraft:dream_lens_luck",dr_sum:7.0d,flavor:"ascension",loot:"evercraft:tinkering/dream_lens",bit:0,flag:"dream_lens",name:"Dream Lens",color:"aqua"}

# B.t2 — CRAFT-LUCK SIGIL (Geologist's Loupe + Cache-Eye + Worldforge Ember → one sigil). Sub-
#   capstone, no latch. +7.0 CONDITIONAL DR (while the craft/mine window is open) + Worldforge's
#   +2.0 Craft Rate (applied in craft_rate/calculate, keyed on craft_luck_sigil:true).
data modify storage evercraft:tnk_recipes recipes append value {capstone:"craft_luck_sigil",family:"B",tier:2,sub_capstone:"craft_luck_sigil",ingredient_ids:["geologist_loupe","cache_eye","worldforge_ember"],cost:6,consolidated_modifier:"evercraft:craft_luck_sigil_luck",dr_sum:7.0d,flavor:"ascension",loot:"evercraft:tinkering/craft_luck_sigil",bit:0,flag:"craft_luck_sigil",name:"Craft-Dream Sigil",color:"gold"}

# B.t3 — ASTRAL CORE (Codex + Netherite Nexus + Claude's Legacy [claudes_eye + claudes_gift] +
#   Dreamspun Crown → the mythical core). Sub-capstone, no latch. +25.0 DR (the biggest sub-node).
#   Claude's Legacy = the 2-item micro-node (D2) folded here.
data modify storage evercraft:tnk_recipes recipes append value {capstone:"astral_core",family:"B",tier:3,sub_capstone:"astral_core",ingredient_ids:["codex_of_everything","netherite_nexus","claudes_eye","claudes_gift","dreamspun_crown"],cost:14,consolidated_modifier:"evercraft:astral_core_luck",dr_sum:25.0d,flavor:"ascension",loot:"evercraft:tinkering/astral_core",bit:0,flag:"astral_core",name:"Astral Core",color:"light_purple"}

# B.t4 — DREAMER'S RELIQUARY (Fortune Coffer + Dream Lens + Astral Core + Craft-Luck Sigil → the
#   grand flagship). Priciest grand fusion (cost 24). NO latch bit (bit:0): the Reliquary, like the
#   Pebble of Creation, has no pre-assigned ec.tnk_owned bit; its completed state is detectable by
#   HOLDING dreamers_reliquary:true (the apply-unit keys on that flag). DR consolidated +24.0 into
#   evercraft:dreamers_reliquary_luck (LOCKED grand headline, UNCAPPED per DECISIONS D1). The
#   Reliquary's loot table is NOT Material (final-form Spirit Artifact).
data modify storage evercraft:tnk_recipes recipes append value {capstone:"dreamers_reliquary",family:"B",tier:4,sub_capstone:"",ingredient_ids:["fortune_coffer","dream_lens","astral_core","craft_luck_sigil"],cost:24,consolidated_modifier:"evercraft:dreamers_reliquary_luck",dr_sum:24.0d,flavor:"ascension",loot:"evercraft:tinkering/dreamers_reliquary",bit:0,flag:"dreamers_reliquary",name:"Dreamer's Reliquary",color:"#B695E0"}

# ------------------------------------------------------------
# HAND-OFF TO recipes_batch_2 (future families C/D + the remaining unbuilt capstones):
#   - This batch ends Family B. recipes_batch_2's rows simply append more; the engine reads list
#     length N dynamically, so a new batch auto-extends the bench with NO engine edit.
#   - registry/load_recipes calls recipes_batch_1 (added there); add the recipes_batch_2 call when
#     it lands. Do NOT renumber or reorder this batch (the Almanac walks it in tree order).
# ------------------------------------------------------------
