# ============================================================
# Tinkering — Family-Recipe REGISTRY batch 9 (Family M — Dragonheart lattice)
# ============================================================
# Appends the Family M fusion recipe rows onto storage evercraft:tnk_recipes recipes. Called by
# registry/load_recipes AFTER recipes_batch_8. Seeds Family M (dragon/scale "armor-set" accessory family
# -> Dragonheart, the set-bonus pinnacle, + the 10%-dodge final-form Wyrmscale Aegis): four sub-bindings
# (Wyrmscale Mantle = tank/sense · Wyrmclaw Grips = melee/breath · Wyrmwing Pinions = mobility · Wyrmheart
# Core = the heart, eats the two seeds) + the grand Dragonheart (eats the four sub-caps) + the final-form
# Wyrmscale Aegis (the grand + a void-relic catalyst). NO engine edit — plinth/detect reads list length N
# dynamically and gates each row from its own data (same contract as batches 0-8).
#
# Schema is documented in recipes_batch_0 (capstone / family / tier / sub_capstone / ingredient_ids /
# cost / consolidated_modifier / dr_sum / flavor / loot / bit / flag / name / color). All LEAF
# ingredient_ids are the live `artifact:"<id>"` values verified in the art-M FAMILY M block in
# artifacts/accessories/player_tick (the 14 new dragon leaves + the two reused seeds dragons_tear +
# ender_dragon_scale). Intermediate ingredient_ids (wyrmscale_mantle / wyrmclaw_grips / wyrmwing_pinions /
# wyrmheart_core / dragonheart) are the bare flags THIS batch's own loot tables stamp. Every loot path
# resolves to a loot_table/tinkering/*.json built in cap-M.
#
# DR consolidation (DECISIONS D1 full-power, UNCAPPED — the global DR ceiling rose to 100 in w5). Family M
# is MIXED-DR like Family A/B: most dragon leaves carry a small Dream Rate (dragon relics are potent),
# consolidated up the tree into ONE *_luck per node. The set-bonus headline is POWER (full perk union +
# the flagship glide/breath ability + the 10% dodge final-form), not DR; the sub-caps carry partial DR and
# the grand carries the FULL union +21.0 (no nerf fence, full-power ascension):
#   Wyrmscale Mantle  +4.5  (wyrmscale_mantle_luck)
#   Wyrmclaw Grips    +5.0  (wyrmclaw_grips_luck)
#   Wyrmwing Pinions  +5.0  (wyrmwing_pinions_luck)
#   Wyrmheart Core    +6.5  (wyrmheart_core_luck)
#   Dragonheart       +21.0 (dragonheart_luck = 4.5+5.0+5.0+6.5, the FULL union)
#   Wyrmscale Aegis   +21.0 (wyrmscale_aegis_luck = the same union, set-not-double)
# bit:0 = no ec.tnk_owned latch (the grand + final-form, like the Pebble / Reliquary / Soulguard Aegis /
# Heart of the Mountain, have no pre-assigned bit; completed state is detectable by HOLDING
# dragonheart:true / wyrmscale_aegis:true — the apply keys on that flag, NO new objective).
#
# VARIED tier cost (the lattice tree weights): four ✦✦ sub-caps (cost 5) -> the grand Dragonheart at cost 18
# (grands run 16-24; Dragonheart sits mid — power-dense but not the priciest) -> the final-form Wyrmscale
# Aegis at cost 24 (the family's priciest, a true final-form). The 10% (+40) dodge is NOT a registry field —
# it is wired in player_tick's m1 ec.acc_dodge LEAF block (one writer), keyed on wyrmscale_aegis:true.
# "magic" never appears (arcane / ancient / potent / power only). The two seeds' obtainment is UNCHANGED.
# ------------------------------------------------------------

# M.t1 — WYRMSCALE MANTLE (Wyrmscale Plate + Scaled Carapace + Ridgeback Spur + Enderscale Eye -> the
#   tank/sense sub-cap, ✦✦). Sub-capstone, no latch. Consolidates +2 Armor Toughness · Resistance I ·
#   full Knockback-resist · Night Vision + Darkness immunity. DR +4.5 -> wyrmscale_mantle_luck.
data modify storage evercraft:tnk_recipes recipes append value {capstone:"wyrmscale_mantle",family:"M",tier:1,sub_capstone:"wyrmscale_mantle",ingredient_ids:["wyrmscale_plate","scaled_carapace","ridgeback_spur","enderscale_eye"],cost:5,consolidated_modifier:"evercraft:wyrmscale_mantle_luck",dr_sum:4.5d,flavor:"ascension",loot:"evercraft:tinkering/wyrmscale_mantle",bit:0,flag:"wyrmscale_mantle",name:"Wyrmscale Mantle",color:"#7D6FB0"}

# M.t1 — WYRMCLAW GRIPS (Wyrmtooth Fang + Dragonbone Talon + Cinderclaw Grip + Breath-Gland Sac -> the
#   melee/breath sub-cap, ✦✦). Sub-capstone, no latch. Consolidates +2 melee damage · Strength I ·
#   attacks ignite hostiles · the crouch breath-cone. DR +5.0 -> wyrmclaw_grips_luck.
data modify storage evercraft:tnk_recipes recipes append value {capstone:"wyrmclaw_grips",family:"M",tier:1,sub_capstone:"wyrmclaw_grips",ingredient_ids:["wyrmtooth_fang","dragonbone_talon","cinderclaw_grip","breathgland_sac"],cost:5,consolidated_modifier:"evercraft:wyrmclaw_grips_luck",dr_sum:5.0d,flavor:"ascension",loot:"evercraft:tinkering/wyrmclaw_grips",bit:0,flag:"wyrmclaw_grips",name:"Wyrmclaw Grips",color:"#C0392B"}

# M.t1 — WYRMWING PINIONS (Wyrmwing Membrane + Stormrider Pinion + Featherscale Down + Voidscale Shard ->
#   the mobility sub-cap, ✦✦). Sub-capstone, no latch. Consolidates Slow Falling · airborne Speed I ·
#   no fall damage · void immunity (+1% dodge x3 lanes via the leaves, in player_tick m1). DR +5.0 ->
#   wyrmwing_pinions_luck.
data modify storage evercraft:tnk_recipes recipes append value {capstone:"wyrmwing_pinions",family:"M",tier:1,sub_capstone:"wyrmwing_pinions",ingredient_ids:["wyrmwing_membrane","stormrider_pinion","featherscale_down","voidscale_shard"],cost:5,consolidated_modifier:"evercraft:wyrmwing_pinions_luck",dr_sum:5.0d,flavor:"ascension",loot:"evercraft:tinkering/wyrmwing_pinions",bit:0,flag:"wyrmwing_pinions",name:"Wyrmwing Pinions",color:"#5DADE2"}

# M.t1 — WYRMHEART CORE (Dragon's Tear + Dragonheart Ember + Wyrmblood Vial + Ender Dragon Scale -> the
#   heart sub-cap, ✦✦ — eats the TWO seeds). Sub-capstone, no latch. Consolidates dragon-breath immunity +
#   the 2 dmg/s aura + Strength III union · Fire Resistance · Regen-below-6 hearts · the Dragon-Form glide
#   (from the scale seed). DR +6.5 -> wyrmheart_core_luck.
data modify storage evercraft:tnk_recipes recipes append value {capstone:"wyrmheart_core",family:"M",tier:1,sub_capstone:"wyrmheart_core",ingredient_ids:["dragons_tear","dragonheart_ember","wyrmblood_vial","ender_dragon_scale"],cost:5,consolidated_modifier:"evercraft:wyrmheart_core_luck",dr_sum:6.5d,flavor:"ascension",loot:"evercraft:tinkering/wyrmheart_core",bit:0,flag:"wyrmheart_core",name:"Wyrmheart Core",color:"#9B59D0"}

# M.t4 — DRAGONHEART (Wyrmscale Mantle + Wyrmclaw Grips + Wyrmwing Pinions + Wyrmheart Core -> the grand
#   set-bonus pinnacle, ✦✦✦✦). A power-dense grand fusion (cost 18 — grands run 16-24; Dragonheart sits
#   mid). Eats the FOUR sub-caps. NO latch bit (bit:0): the Dragonheart, like the Pebble / Reliquary /
#   Soulguard Aegis / Heart of the Mountain, has no pre-assigned ec.tnk_owned bit; its completed state is
#   detectable by HOLDING dragonheart:true (the apply keys on that flag). FULL-POWER ASCENSION: the
#   consolidated DR is the FULL union +21.0 (4.5+5.0+5.0+6.5, no nerf fence) -> dragonheart_luck. Re-grants
#   the whole dragon: Strength III · Fire Resist · the dmg aura · dragon-breath/void/Darkness immunity ·
#   Armor+2 toughness / Resistance I / KB-resist / Regen-below-6 / Night Vision · Slow Falling / no-fall /
#   airborne Speed I · the flagship Wyrmsoar glide + breath-cone. The grand's apply STRIPS the member
#   pieces' luck + sub-cap modifiers when held (the Reliquary idiom) so DR is counted ONCE. The grand's
#   loot table is NOT Material (it CAN still fuse onward into the final-form, but is the set's terminal piece).
data modify storage evercraft:tnk_recipes recipes append value {capstone:"dragonheart",family:"M",tier:4,sub_capstone:"",ingredient_ids:["wyrmscale_mantle","wyrmclaw_grips","wyrmwing_pinions","wyrmheart_core"],cost:18,consolidated_modifier:"evercraft:dragonheart_luck",dr_sum:21.0d,flavor:"ascension",loot:"evercraft:tinkering/dragonheart",bit:0,flag:"dragonheart",name:"Dragonheart",color:"#9B59D0"}

# M.t5 — WYRMSCALE AEGIS (Dragonheart + Voidscale Shard -> the final-form, ✦✦✦✦✦). The family's priciest
#   fuse (cost 24 — a true final-form). A catalyst-tipped pinnacle: the grand + a void-relic catalyst.
#   NO latch bit (bit:0): completed state detectable by HOLDING wyrmscale_aegis:true. Same FULL union as
#   the grand +21.0 (set-not-double) -> wyrmscale_aegis_luck. EVERYTHING the Dragonheart grants PLUS the
#   +40 (10%) dodge — the family's OWN dodge pinnacle, wired ONLY in player_tick's m1 ec.acc_dodge LEAF
#   block (one writer), keyed on wyrmscale_aegis:true (NOT a registry field). The Aegis's loot table is
#   NOT Material (final-form). multi-copy unique (final-form + capstone-vs-ingredient block vs dragonheart).
data modify storage evercraft:tnk_recipes recipes append value {capstone:"wyrmscale_aegis",family:"M",tier:5,sub_capstone:"",ingredient_ids:["dragonheart","voidscale_shard"],cost:24,consolidated_modifier:"evercraft:wyrmscale_aegis_luck",dr_sum:21.0d,flavor:"ascension",loot:"evercraft:tinkering/wyrmscale_aegis",bit:0,flag:"wyrmscale_aegis",name:"Wyrmscale Aegis",color:"#7FE3FF"}

# ------------------------------------------------------------
# HAND-OFF TO recipes_batch_10 (future families + the remaining unbuilt capstones):
#   - This batch ends Family M. recipes_batch_10's rows simply append more; the engine reads list
#     length N dynamically, so a new batch auto-extends the bench with NO engine edit.
#   - registry/load_recipes calls recipes_batch_9 (added there); add the recipes_batch_10 call when
#     it lands. Do NOT renumber or reorder this batch (the Almanac walks it in tree order).
# ------------------------------------------------------------
