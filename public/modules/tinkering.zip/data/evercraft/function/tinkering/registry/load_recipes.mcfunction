# ============================================================
# Tinkering — Family-Recipe REGISTRY load (storage init + batch dispatch)
# ============================================================
# The DATA-DRIVEN fusion registry (Wave-1 Foundation, Council #2-fusion). Initializes the
# recipe registry storage to an empty list, then calls each recipes_batch_K to append its
# rows. Storage is VOLATILE across /reload, so this MUST run every reload (called from
# tinkering/load alongside registry/load — the quest registry).
#
# This is the FORWARD-COMPATIBLE foundation the whole fusion lattice rides on: every fusion
# family (the Pebble of Creation tree, the Band-of-All-Rings tree, and every future family)
# is expressed as PURE DATA ROWS here. Adding a new family = appending rows to a batch — NO
# engine edit. The generic plinth/detect reads these rows; plinth/do fuses from a row's data.
# (Structural clone of registry/load — the quest registry — with the same volatile-reload
# contract and the same dynamic-N read so a new batch auto-extends with no engine change.)
#
# Recipe row schema (storage evercraft:tnk_recipes, list `recipes`) — see recipes_batch_0
# for the canonical field-by-field spec. The engine reads these exact fields:
#   {capstone, family, tier, sub_capstone, ingredient_ids:[...], cost,
#    consolidated_modifier, dr_sum, flavor, loot, name, color}
#
# Rows are appended in (family, tier) order so the Almanac (Wave 7) can render the tree by
# walking the list; the engine itself reads rows by index and does not rely on order.

# Reset to an empty recipe list.
data modify storage evercraft:tnk_recipes recipes set value []

# Append the recipe batches. Batch 0 seeds Family A (Pebble of Creation) + Family E (Band of
# All Rings) — the Wave-1 build. Later batches (recipes_batch_1+) add families B/C/D as pure
# data; the generic detect reads list length N dynamically, so appending a batch auto-extends
# the bench with no engine edit.
function evercraft:tinkering/registry/recipes_batch_0
# Batch 1 — Family B (Dreamer's Reliquary ascension tree: 4 sub-bindings + Lucky Charm starter +
# the grand Reliquary). Pure data, no engine edit (cap-B).
function evercraft:tinkering/registry/recipes_batch_1
# Batch 2 — Family C (Wayfarer's Lens bundle: Far Sight Lens leaf-pair + 3 sub-bindings [Oracle Lens
# / Wanderer's Token / Surveyor's Kit] + the grand Wayfarer's Lens). Zero-DR bundle. Pure data, no
# engine edit (cap-C).
function evercraft:tinkering/registry/recipes_batch_2
# Batch 3 — Family D (Soulguard Aegis bundle: Grand Totem / Lifewarden / Bulwark Stone / Aura Ward
# sub-bindings + the grand Soulguard Aegis). Zero-DR, power-dense bundle (G6: one death-save bucket;
# the grand carries the ONE +40/10% dodge per Open-Decision 4). Pure data, no engine edit (cap-D).
function evercraft:tinkering/registry/recipes_batch_3
# Batch 4 — Family G (Grandforge Regalia bundle: Smith's Apron / Quench Line / Forge Resolve / Grand
# Anvil Heart sub-bindings + the grand Grandforge Regalia). Zero-DR forge-trade bundle (CR set-not-add
# so it never stacks; consolidated break-speed / efficiency / yield / forge-quality). Pure data, no
# engine edit (cap-G).
function evercraft:tinkering/registry/recipes_batch_4
# Batch 5 — Family H (Alchemist's Magnum Opus bundle: Steeping Line / Crucible Line / Reliquary Line /
# Sustain Vial sub-bindings + the grand Alchemist's Magnum Opus). Zero-DR chemistry-trade bundle (CR
# set-not-add so it never stacks; consolidated alchemy quality / reagent-yield / potion-duration / CR +
# the Regen-below-half sustain). G/H stay SEPARATE guilds (Open-Decision 1a). Pure data, no engine edit
# (cap-H).
function evercraft:tinkering/registry/recipes_batch_5
# Batch 6 — Family J (Cornucopia Tide bundle: Hearth Pair / Dock Pair leaf-pairs + Hearthkeeper's Ladle
# [culinary] / Tidewright's Net [fishing] / Harvest Knot [farming/aquatic] sub-bindings + the grand
# Cornucopia Tide — the PRICIEST grand, eats the two trade sub-caps). CONDITIONAL DR only (the two
# fishing charms; consolidated +5.0 while fishing/harvesting, ONE breakdown line). C37 Catalyst of the
# Bounty = the ascension reagent consumed in the Ladle / Net bindings. Pure data, no engine edit (cap-J).
function evercraft:tinkering/registry/recipes_batch_6
# Batch 7 — Family K (Demiurge's Spirit Artifact bundle: Crate Pair leaf-pair + Node Mastery [node-craft] /
# Deepdig Line [aquatic-dig] / Surveyor Line [gathering QoL] sub-bindings + the Demiurge's Spirit Artifact
# — the extraction craft loop, eats the three sub-caps). CONDITIONAL DR only (the grand fires +3.0 while
# actively mining, ec.cf_actwin-gated, ONE breakdown line). Re-grants break-speed + efficiency + reach + CR
# + aquatic kit + every gathering yield/crate/access/survey lever. Pure data, no engine edit (cap-K).
function evercraft:tinkering/registry/recipes_batch_7
# Batch 8 — Family L (Heart of the Mountain bundle: Stride Line [traversal] / Bulwark Stone [tank] /
# Ascendant Line [combat-craft] / Titan Core [mythical defense] sub-bindings + the grand Heart of the
# Mountain — the consolidated defensive titan-stone, eats the four sub-caps). POWER-BUNDLE, ZERO BASE DR
# (the only luck is B10 Resonant Locket's CONDITIONAL +1.0 node-proximity DR, consolidated into the
# Ascendant Line + grand; reports under B's craft-luck line). Re-grants armor/health/toughness/KB-resist +
# the ward union + +3 attack (+1 above 80% HP) + +5 CR + the full stride. The Titan Core absorbs the 4
# mythical defense stones moved from old-D. Pure data, no engine edit (cap-L).
function evercraft:tinkering/registry/recipes_batch_8
# Batch 9 — Family M (Dragonheart: dragon/scale "armor-set" accessory family -> the set-bonus pinnacle.
# Four sub-bindings [Wyrmscale Mantle = tank/sense · Wyrmclaw Grips = melee/breath · Wyrmwing Pinions =
# mobility · Wyrmheart Core = the heart, eats the two dragon seeds] + the grand Dragonheart [eats the four
# sub-caps; FULL-POWER union +21.0 DR, no nerf fence; the flagship Wyrmsoar glide + breath-cone] + the
# final-form Wyrmscale Aegis [the grand + a void-relic catalyst; same union + the family's OWN +40/10%
# dodge in player_tick's m1 lane]. MIXED DR (like Family A/B), consolidated one *_luck per node; the grand
# strips the member luck when held (the Reliquary idiom). Pure data, no engine edit (cap-M).
function evercraft:tinkering/registry/recipes_batch_9
