# ============================================================
# Cornucopia Tide — GRAND capstone: grant the full bounty union, fold the DR into ONE conditional line
# ============================================================
# Run as @s = the player, at @s. Called from artifacts/accessories/player_tick's consolidated fusion
# block (a10, BEHIND the ec.has_accessory early-exit) when the player holds a cornucopia_tide:true item.
# The Tide IS the union of the WHOLE Family-J bounty by definition (the fusion `do` consumed the
# Hearthkeeper's Ladle + the Tidewright's Net — and through them every culinary + fishing charm + the
# Catalyst of the Bounty reagent — and spawned the Tide flagged cornucopia_tide; it does NOT carry the
# member items). So HERE we re-grant every PER-TICK bounty perk behind one held item:
#   - Lure II + Luck of the Sea III on a held fishing rod (the Anglerwarden's Sigil level — top rung).
#   - +30% submerged_mining_speed + +30% water_movement_efficiency (the Coral Diver's Pearl aquatic kit).
#   - The crop bone-meal growth pulse (the Harvest Totem head, ~15%/sec) + the splash-node action-bar
#     sense (the Tidefinder's Astrolite half) — the farming/aquatic union the grand also folds.
# The CONSOLIDATED-DR half (Riverpearl +2 while fishing + Deepcurrent +3 in water → ONE
# cornucopia_tide_luck) is condition-gated in player_tick directly (remove-then-conditional-add, the
# Geologist's Loupe / Demiurge idiom) — NOT here, so it stays exact every tick. The CR (+10.0) / cook
# quality (+2) / bonus-material roll / crop-yield (double-harvest + crate) / extra fishing crate rolls
# route through their own ONE-writer funnel hooks gated on the cornucopia_tide flag (craft_rate/calculate
# [the ONE ec.cr_temp writer], cooking/minigame/resolve, fishing/ref/on_catch, harvest_bonus_read), with
# the loose leaf + sub-cap levers m4-suppressed when the grand is held (Newcomer-exempt) — NOT here.
# DISTINCT capstone-scoped attribute ids (NOT the loose leaf ids) so the loose accessory_cleanup never
# strips them; the cap-J accessory_cleanup block owns their removal when the grand is not held. Fixed-id
# `modifier add` re-added each tick (idempotent — two Tides overwrite to ONE value, m4 Layer-2). The
# grand SUPERSEDES its two trade sub-caps (Ladle + Net) — their dispatch is guarded `unless` the grand
# is held; the cap-J m4 strips fold the loose pieces' levers so nothing double-counts.
#
# ABSORBED MEMBERS (13 + 1 reagent): cooking — hearthhand_cloth, brinewell_ladle, hearthcooks_apron,
# harvest_censer, chefs_searing_charm, granary_keystone, cornucopia_crucible; fishing — dockhands_knot,
# tidecallers_lure, riverpearl_charm, anglerwardens_sigil, coral_divers_pearl, deepcurrent_reliquary;
# reagent — catalyst_of_the_bounty (consumed in the binding). READ-ONLY on state.

# --- Lure II + LotS III on a held fishing rod (the Anglerwarden's Sigil tier — top rung). Reuse the
#     shared item modifiers; only inject onto a rod lacking each level; tag for per-rod cleanup. ---
execute if items entity @s weapon.mainhand minecraft:fishing_rod unless items entity @s weapon.mainhand *[enchantments~[{enchantment:"minecraft:lure",levels:{min:2}}]] run item modify entity @s weapon.mainhand evercraft:fishing_lure_2
execute if items entity @s weapon.mainhand minecraft:fishing_rod unless items entity @s weapon.mainhand *[enchantments~[{enchantment:"minecraft:luck_of_the_sea",levels:{min:3}}]] run item modify entity @s weapon.mainhand evercraft:fishing_luck_3
execute if items entity @s weapon.mainhand minecraft:fishing_rod run tag @s add ec.cornucopia_tide_fishing

# --- Coral Diver's Pearl aquatic kit (+30% submerged mining + swim efficiency). Distinct grand ids. ---
attribute @s submerged_mining_speed modifier add evercraft:cornucopia_tide_smine 0.30 add_multiplied_base
attribute @s water_movement_efficiency modifier add evercraft:cornucopia_tide_wme 0.30 add_value

# --- Harvest Totem head crop bone-meal growth pulse (~15%/sec) + the Tidefinder splash-node sense. ---
execute store result score @s ec.artifact_roll run random value 1..20
execute if score @s ec.artifact_roll matches 1..3 positioned ~-4 ~-1 ~-4 run function evercraft:artifacts/accessories/try_bone_meal
function evercraft:artifacts/accessories/tidefinder_ping
