# ============================================================
# Tidewright's Net (C38) — fishing sub-binding: re-grant the bound fishing union
# ============================================================
# Run as @s = the player, at @s. Called from artifacts/accessories/player_tick's consolidated fusion
# block (a10, BEHIND the ec.has_accessory early-exit) when the player holds a tidewrights_net:true item
# AND the grand Cornucopia Tide is NOT held (the grand supersedes — see the dispatch). The Net IS the
# union of Family-J's 6 fishing charms by definition (the fusion `do` consumed Dockhand's Knot +
# Tidecaller's Lure + Riverpearl Charm + Anglerwarden's Sigil + Coral Diver's Pearl + Deepcurrent
# Reliquary via the Catalyst of the Bounty — it does NOT carry the member items). So HERE we re-grant
# every PER-TICK fishing perk behind one held item:
#   - Lure II + Luck of the Sea III on a held fishing rod (the Anglerwarden's Sigil level — top rung).
#   - +30% submerged_mining_speed + +30% water_movement_efficiency (the Coral Diver's Pearl aquatic kit).
# The conditional-DR half (Riverpearl +2 while fishing + Deepcurrent +3 in water) is CONSOLIDATED into
# the single tidewright_luck modifier in player_tick directly (remove-then-conditional-add, the Demiurge
# idiom) — NOT here. The two extra fishing crate rolls (Tidecaller + Deepcurrent) route through
# fishing/ref/on_catch gated on the Net flag — NOT here. DISTINCT capstone-scoped attribute ids (NOT the
# loose leaf ids) so the loose accessory_cleanup never strips them; the cap-J accessory_cleanup block owns
# their removal when the Net is not held. Fixed-id `modifier add` re-added each tick (idempotent — two
# Nets overwrite to ONE value, m4 Layer-2 multi-copy-safe).

# Lure II + LotS III on a held fishing rod (the Anglerwarden's Sigil tier). Reuse the shared item
# modifiers; only inject onto a rod lacking each level; tag for the per-rod cleanup on switch/drop.
execute if items entity @s weapon.mainhand minecraft:fishing_rod unless items entity @s weapon.mainhand *[enchantments~[{enchantment:"minecraft:lure",levels:{min:2}}]] run item modify entity @s weapon.mainhand evercraft:fishing_lure_2
execute if items entity @s weapon.mainhand minecraft:fishing_rod unless items entity @s weapon.mainhand *[enchantments~[{enchantment:"minecraft:luck_of_the_sea",levels:{min:3}}]] run item modify entity @s weapon.mainhand evercraft:fishing_luck_3
execute if items entity @s weapon.mainhand minecraft:fishing_rod run tag @s add ec.tidewrights_net_fishing

# Coral Diver's Pearl aquatic kit (+30% submerged mining + swim efficiency). Distinct capstone ids.
attribute @s submerged_mining_speed modifier add evercraft:tidewrights_net_smine 0.30 add_multiplied_base
attribute @s water_movement_efficiency modifier add evercraft:tidewrights_net_wme 0.30 add_value
