# ============================================================
# Harvest Knot — farming/aquatic sub-binding: re-grant the bound farming + aquatic union
# ============================================================
# Run as @s = the player, at @s. Called from artifacts/accessories/player_tick's consolidated fusion
# block (a10, BEHIND the ec.has_accessory early-exit) when the player holds a harvest_knot:true item
# AND no grand Cornucopia Tide is held (the grand supersedes only the two TRADE sub-caps — Ladle + Net;
# the Harvest Knot is the SEPARATE farming/aquatic sub-cap that the grand does NOT eat, so it dispatches
# unconditionally on its own flag — see the dispatch). The Knot IS the union of Family-J's farming +
# aquatic charms by definition (the fusion `do` consumed Tiller's Knot + Gleaner's Twine + Farmer's
# Almanac + Harvest Totem + Tidefinder's Astrolite — it does NOT carry the member items). So HERE we
# re-grant every PER-TICK farming/aquatic perk behind one held item:
#   - The crop bone-meal growth pulse (the Harvest Totem #4 head, ~15%/sec) — re-run the SAME try_bone_
#     meal dispatch the loose Totem uses (positioned at @s by the caller).
#   - The Tidefinder's splash-node action-bar sense + its small +0.15 submerged_mining_speed.
# The CROP-YIELD half (Tiller's double-harvest +20% / crate +3 + Gleaner's +10% / crate +2) routes
# through artifacts/accessories/harvest_bonus_read gated on the harvest_knot flag (a break-event hook,
# NOT a tick perk) — NOT here. DISTINCT capstone-scoped attribute id (harvest_knot_smine, NOT the loose
# tidefinders_astrolite_smine) so the loose accessory_cleanup never strips it; the cap-J accessory_
# cleanup block owns its removal when the Knot is not held. Fixed-id `modifier add` re-added each tick
# (idempotent — two Knots overwrite to ONE value, m4 Layer-2 multi-copy-safe). DR=0 (the farming/aquatic
# charms carry no luck; the only J DR lives on the two fishing charms in the Tidewright's Net line).

# --- Crop bone-meal growth pulse (the Harvest Totem #4 head). Re-run the SAME ~15%/sec try_bone_meal
#     dispatch the loose Totem uses (the apply holder carries no loose Totem, so the Knot pulses itself).
execute store result score @s ec.artifact_roll run random value 1..20
execute if score @s ec.artifact_roll matches 1..3 positioned ~-4 ~-1 ~-4 run function evercraft:artifacts/accessories/try_bone_meal

# --- Tidefinder's Astrolite aquatic kit: +0.15 submerged_mining_speed (distinct capstone id) + the
#     read-only splash-node action-bar sense (no resource pack). ---
attribute @s submerged_mining_speed modifier add evercraft:harvest_knot_smine 0.15 add_value
function evercraft:artifacts/accessories/tidefinder_ping
