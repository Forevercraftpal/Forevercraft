# ============================================================
# Tinkering (universal mini-line) — Show objective (macro body)
# ============================================================
# Called `with storage evercraft:tnk_cur o`, where o = the current quest object
# {id,title,desc,type,target,count,reward,reward_amt,chapter,...}.
# Mirrors the C6 show_objective tone (white-not-gray active line).
#
# F11 (single-chapter suppression): Tinkering is the pack's ONLY single-chapter
# line (all 12 quests are chapter:1 — confirmed against the registry), so the
# sibling macros' trailing "  ·  Chapter $(chapter)" clause would only ever read
# "Chapter 1" here — a redundant label. It is therefore OMITTED on this line, and
# the Chapter clause below is GATED so it only renders for a genuinely multi-chapter
# beat. The guard uses the macro family's existing `execute unless data ... o{...}`
# idiom (cf. quest_pacing/skip_button_macro:25): chapter:1 is suppressed; any
# chapter > 1 (would only exist if Tinkering ever grows past one chapter) prints
# the clause. Net result today: the objective line shows only "Beat $(id)".
$tellraw @s [{text:"➤ ",color:"yellow"},{text:"$(title)",color:"white",bold:true}]
$tellraw @s [{text:"  $(desc)",color:"gray"}]
$tellraw @s [{text:"  Beat $(id)",color:"dark_gray"}]
# Chapter clause — gated: suppressed while the line is single-chapter (chapter:1).
# Matches the sibling macros' "  ·  Chapter $(chapter)" but only fires past chapter 1.
$execute unless data storage evercraft:tnk_cur o{chapter:1} run tellraw @s [{text:"  Chapter $(chapter)",color:"dark_gray"}]
