# ============================================================
# Deepdig Line — sub-binding (aquatic-dig): grant the consolidated submerged-mining kit, ZERO DR
# ============================================================
# Run as @s = the player, at @s. Called from artifacts/accessories/player_tick's consolidated fusion
# block (a11, BEHIND the ec.has_accessory early-exit) when the player holds a deepdig_line:true item AND
# NOT the Demiurge's Spirit Artifact (guarded `unless` the grand in the dispatch). The Deepdig Line IS the
# union of the Tidewright's Pearl + Driftcurrent Fin + Quartzlight Loupe (the fusion `do` consumed them).
# So HERE we re-grant the CONSOLIDATED aquatic kit while submerged:
#   - +55% submerged_mining_speed (Pearl +30 + Fin +25) — add_multiplied_base (% feel, stacks ON Haste).
#   - +0.75 water_movement_efficiency (Pearl +0.5 + Fin +0.25) — add_value (0..1 scalar swim).
#   - +4 oxygen_bonus (Pearl breath) — add_value (the squid/axolotl breath attr).
# CONDITIONAL on in_water (the Pearl gate): remove-then-conditional-add so all three free on dry land or
# on drop. DISTINCT sub-cap ids (evercraft:deepdig_*) so the loose accessory_cleanup never strips them; the
# cap-K accessory_cleanup block strips them `unless` the Deepdig Line is held. Fixed-id, idempotent
# overwrite (two copies -> ONE value, m4 Layer-2). The Quartzlight Loupe's on-demand ore SAMPLE is a
# sneak-triggered survey (not a per-tick perk) — it routes through the sneak-survey block in player_tick
# gated on the deepdig_line flag, NOT here. ZERO DR (no luck modifier — the Deepdig is a pure attr kit).
# ABSORBED MEMBERS (3): tidewright_pearl, driftcurrent_fin, quartzlight_loupe.

attribute @s submerged_mining_speed modifier remove evercraft:deepdig_smine
attribute @s water_movement_efficiency modifier remove evercraft:deepdig_wme
attribute @s oxygen_bonus modifier remove evercraft:deepdig_o2
execute if predicate evercraft:in_water run attribute @s submerged_mining_speed modifier add evercraft:deepdig_smine 0.55 add_multiplied_base
execute if predicate evercraft:in_water run attribute @s water_movement_efficiency modifier add evercraft:deepdig_wme 0.75 add_value
execute if predicate evercraft:in_water run attribute @s oxygen_bonus modifier add evercraft:deepdig_o2 4 add_value
