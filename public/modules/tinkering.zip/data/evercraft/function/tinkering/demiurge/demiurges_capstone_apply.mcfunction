# ============================================================
# Demiurge's Spirit Artifact — GRAND capstone: grant the full craft-loop union, fold the DR into ONE conditional line
# ============================================================
# Run as @s = the player, at @s. Called from artifacts/accessories/player_tick's consolidated fusion
# block (a11, BEHIND the ec.has_accessory early-exit) when the player holds a demiurges_capstone:true item.
# The Capstone IS the union of the WHOLE Family-K gathering trade by definition (the fusion `do` consumed
# the Node Mastery + the Deepdig Line + the Surveyor Line — and through them every gathering charm + the
# Crate Pair + the soul_lantern_fragment — and spawned the Capstone flagged demiurges_capstone; it does
# NOT carry the member items). So HERE we re-grant every PER-TICK craft-loop perk behind one held item:
#   - +25% block_break_speed (the consolidated break-speed lever — stacks ON Haste, not Haste; the
#     adv_mining_surge / grandforge_bs add_multiplied_base precedent).
#   - +3 mining_efficiency (the silent-touch dig-efficiency lever; the grandforge_eff add_value precedent).
#   - +1.0 block_interaction_range (reach — the gc_hand_reach add_value precedent).
#   - The Deepdig aquatic kit while submerged (+55% submerged_mining_speed = Pearl +30 + Fin +25; +0.75
#     water_movement_efficiency = Pearl +0.5 + Fin +0.25; +4 oxygen_bonus = Pearl breath) — distinct grand
#     ids, remove-then-conditional-add on in_water so they free on dry land / on drop.
#   - The Pathfinder's Astrolabe craft-node pip (read-only sense, the Node Mastery half).
# The CONSOLIDATED-DR half (the lattice's conditional +3.0 while actively mining -> ONE
# demiurges_capstone_luck) is condition-gated in player_tick directly (remove-then-conditional-add, the
# Geologist's Loupe / pre-wired art-K idiom, ec.cf_actwin-gated) — NOT here, so it stays exact every tick.
# The CR (+8.0) routes through craft_rate/calculate (the ONE ec.cr_temp writer, m4 HANDOFF #7 — never a
# second cr_temp writer from player_tick). The ore bonus-roll / crate / node-crate / auto-pickup /
# double-log / Perfect-Strike dup / node despawn / rank bypass route through their own ONE-writer event
# hooks (check_drop / harvest_bonus_read / resolve_win / detect_ordinary_tool / resonance/reward_perfect /
# nodes/check_despawn / nodes/try_spawn), gated on the held demiurges_capstone flag, with the loose leaf
# levers `unless` the Capstone is held (Newcomer-exempt) so loose + Capstone never both roll — NOT here.
# DISTINCT capstone-scoped attribute ids (NOT the loose leaf ids) so the loose accessory_cleanup never
# strips them; the cap-K accessory_cleanup block owns their removal when the Capstone is not held. Fixed-id
# `modifier add` re-added each tick (idempotent — two Capstones overwrite to ONE value, m4 Layer-2). The
# grand SUPERSEDES its three sub-caps (Node Mastery + Deepdig Line + Surveyor Line) — their dispatch is
# guarded `unless` the grand is held; the cap-K m4 gates fold the loose pieces' levers so nothing doubles.
#
# ABSORBED MEMBERS (16): aquatic — tidewright_pearl, driftcurrent_fin; survey/ore — prospectors_doohickey,
# brushwrights_mitt, quartzlight_loupe, plumb_bob_token, echolocator_shard, spelunkers_resonator,
# loadmasters_sortstone, soul_lantern_fragment; node — wayfinders_dowsing_rod, artisans_writ_of_passage,
# pathfinders_astrolabe; yield — resonant_geode_heart, resonance_duplicator_charm, prospectors_dice.
# READ-ONLY on state except the consolidated grand attributes (fixed-id, idempotent overwrite).

# --- Consolidated Block Break Speed +25% (the whole-loop break-speed lever) ---
attribute @s block_break_speed modifier add evercraft:demiurge_bs 0.25 add_multiplied_base

# --- Consolidated Mining Efficiency +3 ---
attribute @s mining_efficiency modifier add evercraft:demiurge_eff 3 add_value

# --- Consolidated Reach +1.0 block interaction range ---
attribute @s block_interaction_range modifier add evercraft:demiurge_reach 1.0 add_value

# --- Deepdig aquatic kit (Tidewright's Pearl + Driftcurrent Fin union) — CONDITIONAL on in_water.
#     Remove-then-conditional-add (the band_luck / Pearl idiom) so all three free on dry land or on drop.
#     Distinct grand ids; the cap-K accessory_cleanup strips them `unless` the Capstone is held. ---
attribute @s submerged_mining_speed modifier remove evercraft:demiurge_smine
attribute @s water_movement_efficiency modifier remove evercraft:demiurge_wme
attribute @s oxygen_bonus modifier remove evercraft:demiurge_o2
execute if predicate evercraft:in_water run attribute @s submerged_mining_speed modifier add evercraft:demiurge_smine 0.55 add_multiplied_base
execute if predicate evercraft:in_water run attribute @s water_movement_efficiency modifier add evercraft:demiurge_wme 0.75 add_value
execute if predicate evercraft:in_water run attribute @s oxygen_bonus modifier add evercraft:demiurge_o2 4 add_value

# --- Pathfinder's Astrolabe craft-node proximity pip (read-only sense; the Node Mastery half). ---
function evercraft:artifacts/accessories/astrolabe_ping
