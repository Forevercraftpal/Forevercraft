# ============================================================
# Node Mastery — sub-binding (node-craft): grant the per-tick node pip, ZERO DR
# ============================================================
# Run as @s = the player, at @s. Called from artifacts/accessories/player_tick's consolidated fusion
# block (a11, BEHIND the ec.has_accessory early-exit) when the player holds a node_mastery:true item AND
# NOT the Demiurge's Spirit Artifact (guarded `unless` the grand in the dispatch). The Node Mastery IS the
# union of the Wayfinder's Dowsing Rod + Artisan's Writ of Passage + Pathfinder's Astrolabe + the Crate
# Pair (the fusion `do` consumed them). Most of its levers are EVENT-gated, NOT per-tick, so they route
# through their own ONE-writer hooks gated on the node_mastery flag (the Capstone idiom, `unless` the loose
# leaf is held, Newcomer-exempt):
#   - +50% node despawn  -> craftforever/nodes/check_despawn (the node lingers 50% longer near a holder).
#   - rank-gate bypass    -> craftforever/nodes/try_spawn (rank-gated craft-nodes spawn regardless of rank).
#   - +2% crate           -> artifacts/accessories/harvest_bonus_read LEAF block (the Crate Pair's Geode).
#   - Perfect-Strike dup  -> craftforever/nodes/resonance/reward_perfect (the Crate Pair's Duplicator).
# The ONLY per-tick perk is the Pathfinder's Astrolabe craft-node proximity pip (read-only sense), so
# THAT is all this apply grants. ZERO DR (no luck modifier — Node Mastery is sense / access / yield).
# ABSORBED MEMBERS (4 + the Crate Pair's 2): wayfinders_dowsing_rod, artisans_writ_of_passage,
# pathfinders_astrolabe, crate_pair (-> resonant_geode_heart, resonance_duplicator_charm).

# --- Pathfinder's Astrolabe craft-node proximity pip (the only per-tick Node Mastery perk). ---
function evercraft:artifacts/accessories/astrolabe_ping
