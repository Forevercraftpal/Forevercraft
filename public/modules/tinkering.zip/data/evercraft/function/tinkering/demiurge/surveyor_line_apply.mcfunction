# ============================================================
# Surveyor Line — sub-binding (gathering QoL): documented NO-OP apply (all levers are event/sneak-gated)
# ============================================================
# Run as @s = the player, at @s. Called from artifacts/accessories/player_tick's consolidated fusion
# block (a11, BEHIND the ec.has_accessory early-exit) when the player holds a surveyor_line:true item AND
# NOT the Demiurge's Spirit Artifact (guarded `unless` the grand in the dispatch). The Surveyor Line IS the
# union of the Prospector's Doohickey + Brushwright's Mitt + Plumb-Bob Token + Echolocator Shard +
# Spelunker's Resonator + Prospector's Dice + Loadmaster's Sortstone + soul_lantern_fragment (the fusion
# `do` consumed them). EVERY one of its levers is EVENT-gated or SNEAK-triggered — NONE is a per-tick
# attribute — so they ALL route through their own hooks gated on the surveyor_line flag (the Capstone
# idiom, `unless` the loose leaf is held, Newcomer-exempt):
#   - +1.5% ore bonus-material -> craftforever/forging/ore_mining/check_drop (the Doohickey extra roll).
#   - extra node crate          -> gather/resolve_win (the Dice extra node-crate roll).
#   - ore auto-pickup           -> craft_affinity/detect_ordinary_tool (the Brushwright per-break pickup).
#   - the sneak-survey kit       -> the FAMILY K SNEAK-TRIGGERED block in player_tick (Plumb-Bob depth,
#                                  Echolocator cavity rays, Resonator locate, Sortstone material collapse),
#                                  dispatched on the surveyor_line flag when sneaking with the hand free.
#   - soul_lantern XP perk       -> artifacts/accessories/xp_boost_check (already fires from the loose line;
#                                  the soul_lantern is the only K member with its own pre-existing wiring).
# So this apply is a DELIBERATE NO-OP (parity with cap-G's Forge Resolve apply + cap-J's Hearthkeeper's
# Ladle — sub-caps whose perks are all event-gated). Kept as a real file so the dispatch resolves and the
# Almanac can list a per-node apply uniformly. ZERO DR (no luck modifier anywhere in the Surveyor Line).
# ABSORBED MEMBERS (8): prospectors_doohickey, brushwrights_mitt, plumb_bob_token, echolocator_shard,
# spelunkers_resonator, prospectors_dice, loadmasters_sortstone, soul_lantern_fragment.
