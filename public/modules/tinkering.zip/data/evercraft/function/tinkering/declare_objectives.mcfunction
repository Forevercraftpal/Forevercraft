# ============================================================
# Tinkering (universal mini-line) — One-time scoreboard objective declarations.
# (Structural clone of adventure/kingdom/declare_objectives, Council #2 Wave C7 — the
#  UNIVERSAL "combining artifacts" line.) Split from tinkering/load so the per-/reload
#  "Objective already exists" warnings only fire once. Gated by `#tnk_loaded ec.var
#  matches 1` — set at the bottom of this file.
# ============================================================
# A paced, always-skippable teaching mini-line: a sibling Fisher's clone that only READS
# public state (held accessory items for own_accessories; the ec.cf_r10_granted tag /
# a held Plinth for has_station; the ec.tnk_owned safe-OR bitfield for fused_any/band/
# hand/charm). It WRITES none of those engines' objectives — the no-write proof. It is
# pacing-aware from the start (lore/beat/skippable) — see check.mcfunction (interlude
# guard), on_advance_notify + overview (render_lore), and the registry rows that carry
# `lore`.
#
# NAMESPACE LOCK (T1): ec.tk_* is OCCUPIED by the shields/taunt system. This line uses the
# council-locked ec.tnk_* family ONLY.

# === CORE LINEAR-POINTER SCOREBOARDS (mirror ec.ak_*; one writer each) ===
# ec.tnk_active — 0/1/2, has this player started Tinkering?
#   WRITER: tinkering/start (sets 1). The completion path sets it to 2 (via finish) so a
#   future read could detect "Tinkering complete" — but every gate in THIS line treats it
#   as "1.. = active". (start sets 1; finish bumps to 2 on the final quest.)
scoreboard objectives add ec.tnk_active dummy "Tinkering Active"
# ec.tnk_quest — current quest index, 1..N. The ONLY linear pointer.
#   WRITER: tinkering/start (sets 1) + tinkering/advance (+1, clamped at N).
scoreboard objectives add ec.tnk_quest dummy "Tinkering Quest Idx"
# ec.tnk_prog — progress within the current quest, surfaced ONLY in the overview progress
#   bar. The tinkering check types are all READ-DERIVED (held-item tests / bit reads /
#   tag reads), never persisting a per-deed tally, so the single persistent writer of
#   tnk_prog is the reset path — keeping it strictly one-writer.
#   WRITER (reset to 0): tinkering/start + tinkering/advance.
scoreboard objectives add ec.tnk_prog dummy "Tinkering Progress"
# ec.tnk_done — lifetime completed quest count (overview + the ec.gq_track value).
#   WRITER: tinkering/advance (+1) + tinkering/start (sets 0 on first start).
scoreboard objectives add ec.tnk_done dummy "Tinkering Done"
# (NO ec.tnk_title — the teaching mini-line rewards only coins/crate/trophy by default
#  (DECISIONS #9 — a teaching line, not an XP faucet). The Master-Tinkerer PRESTIGE title
#  is special-title ID 17 (a single ec.special_titles bit), wired in Wave C8 — NOT a
#  reward_type/title file in this engine.)

# === COMPLETION SENTINEL ===
# ec.tnk_complete — 0/1, set once when the player finishes the final quest so the "line
#   complete!" tellraw fires exactly once, and so chronicle/overview reads it for the ✓
#   glyph. WRITER: tinkering/advance (via finish) + tinkering/start (sets 0 on first start).
scoreboard objectives add ec.tnk_complete dummy "Tinkering Complete"

# === ONE-SHOT SOFT-OFFER LATCH (sole writer: tinkering/on_get_accessory_pair) ===
# ec.tnk_offer — 0/1, set to 1 the first time the soft "[Begin Tinkering ->]" auto-offer
#   fires (the player first holds >=2 accessories at once — F), so it never re-fires. The
#   offer is universal (NO ec.chron_view gate — Tinkering is for ALL players). The button
#   itself calls tinkering/start. WRITER: tinkering/on_get_accessory_pair (the detector's
#   sole writer; the strip-reset is the documented exception, like ec.ak_offer / ec.gq_offered).
scoreboard objectives add ec.tnk_offer dummy "Tinkering Offer Latch"

# === EVER-FUSED SAFE-OR BITFIELD (the ONLY shared-write objective in the seat) ===
# ec.tnk_owned — bitfield, the "ever-fused" latch read by the fused_* check helpers so a
#   veteran auto-passes those beats. bit0(1) Knot / bit1(2) Band / bit2(4) Hand /
#   bit3(8) Charm. SAFE-OR multi-writer (the documented convention, like ec.special_titles):
#   WRITERS: tinkering/plinth/do_knot (bit0), round-1's Band confirm (bit1, Wave C8),
#   round-1's Hand do_merge re-homed onto the Plinth — tinkering/plinth/do_hand (bit2),
#   the deferred Band-of-Charms (bit3, future). Each writer checks-the-bit-before-OR-ing
#   so a re-grant is a no-op and disjoint bits never conflict. SUBSUMES round-1's optional
#   ec.hand_owned / ec.band_owned singletons (N3). tinkering/start SEEDS it from current
#   state (held bundle items) so a veteran's prior fusions are recognized (auto-pass).
scoreboard objectives add ec.tnk_owned dummy "Tinkering Ever-Fused Bits"

# === PLINTH DISPLAY RAYCAST SCRATCH (per-player counter for the place-detection raycast) ===
# ec.tnk_ray — short-lived step counter for tinkering/plinth/raycast_place (the cosmetic
#   head-display place-detection, mirroring guidestone's ec.gs_temp). Set 0 at on_place,
#   incremented per ray step, parked at 99 by setup, reset 0 at the end of on_place. Touches
#   only the placing player; never read by the fusion/quest logic.
scoreboard objectives add ec.tnk_ray dummy "Tinkering Plinth Raycast"

# === TINKER TABLE WORKBENCH GUI (deposit-from-hand -> Combine alternative, Joseph 2026-06-04) ===
# ec.tnk_pid — per-player buffer key for the deposit GUI (assigned from #next_tnk_pid on first open;
#   indexes the player's deposited-trinket list at storage evercraft:tnk_gui bufs.<pid>).
# ec.tnk_dep — deposit count shown in the menu status line (derived from the buffer list length).
scoreboard objectives add ec.tnk_pid dummy "Tinker Table Buffer ID"
scoreboard objectives add ec.tnk_dep dummy "Tinker Table Deposit Count"

# === FUSION OWNER STAMP (audit #41 P0 — two-players-one-table dupe fix, 2026-06-06) ===
# ec.tnk_own — the OWNER pid stamped onto each fuse-eligible item ENTITY the moment it becomes a
#   world entity (combine_summon for the GUI path; check_item for the throw path = nearest player's
#   tnk_pid). Every consume/grant in the fusion engine filters to "this fuse's owner" via the
#   transient ec.tnk_mine cohort tag (marked by comparing each nearby item's ec.tnk_own to the
#   trigger's), so two players at ONE shared table only ever fuse their OWN deposits. Single-player:
#   every item carries the lone player's pid -> the whole pool is one cohort -> unchanged behavior.
scoreboard objectives add ec.tnk_own dummy "Tinker Fusion Owner pid"

# Mark declarations done so re-/reload skips this file.
scoreboard players set #tnk_loaded ec.var 1
