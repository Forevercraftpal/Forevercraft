# ============================================================
# Dreamer's Reliquary — Fortune Coffer consolidated-DR add (macro body)
# ============================================================
# Called `with storage evercraft:tnk_apply fc` from fortune_coffer_apply, which computed the exact
# Dream-Rate total (×0.1 of the #fc_dr roll-units) honoring the three DR toggles. This applies the
# single consolidated modifier evercraft:fortune_coffer_luck = $(dr). The caller did the
# remove-first, so this is the add half of the band_luck remove-then-add idiom (value exact every
# tick). Macro-driven add_value mirrors advantage/effects/apply_* (the established variable-DR add).
$attribute @s luck modifier add evercraft:fortune_coffer_luck $(dr) add_value
