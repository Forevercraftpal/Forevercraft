# ============================================================
# Dreamer's Reliquary — Astral Core perk re-apply (Fusion Wave / Family B, mythical sub-binding)
# ============================================================
# Run as @s = the player, at @s. Called from artifacts/accessories/player_tick's consolidated
# fusion block (BEHIND the ec.has_accessory early-exit) when the player holds an astral_core:true
# item. The Astral Core binds the mightiest dreaming relics: codex_of_everything (+3.0 DR),
# netherite_nexus (Resistance III + +4.0 DR), Claude's Legacy [claudes_eye (Night Vision + +1.0 DR)
# + claudes_gift (Str/Haste/Speed III + +5.0 DR)], and Dreamspun Crown (Str I/Speed I + +12.0 DR).
# It re-grants exactly their union (all harmonize-gated effects + the five +3/+4/+1/+5/+12 DR folded
# into ONE modifier evercraft:astral_core_luck = +25.0; dr_sum:25.0 in the registry row).
#
# BALANCE-NEUTRAL (D1 sub-node consolidate): each member already granted its perk while loose, so a
# player holding all five already had the union — the Core keeps it in ONE slot. None of these five
# has a DR toggle, so the +25.0 is unconditional (no remove-then-add needed — a fixed-id modifier
# add is idempotent, m4 Layer-2). Harmonize gates (ec.h_* matches ..1) preserved so the Core never
# double-stacks a harmonizable buff. READ-ONLY on state.
#
# CLAUDE'S LEGACY: claudes_eye + claudes_gift are the 2-item micro-node (D2) folded here. Their
# Night Vision + the Gift's three combat auras + the end_rod particle are all re-granted below.

# --- Member secondary effects (the union — verbatim from the loose player_tick lines) ---
# Netherite Nexus — Resistance III (harmonize-gated)
execute if score @s ec.h_resist matches ..1 run effect give @s resistance 5 2 false
# Claude's Eye — Night Vision
effect give @s night_vision 15 0 false
# Claude's Gift — Strength III + Haste III + Speed III (harmonize-gated) + end_rod particle
execute if score @s ec.h_str matches ..1 run effect give @s strength 5 2 false
execute if score @s ec.h_haste matches ..1 run effect give @s haste 5 2 false
execute if score @s ec.h_speed matches ..1 run effect give @s speed 5 2 false
particle end_rod ~ ~1 ~ 0.3 0.5 0.3 0.02 1
# Dreamspun Crown — Strength I + Speed I (harmonize-gated, yields to the Gift's stronger same-effect)
execute if score @s ec.h_str matches ..1 run effect give @s strength 5 0 false
execute if score @s ec.h_speed matches ..1 run effect give @s speed 5 0 false

# --- Consolidated +25.0 Dream Rate (Codex +3 · Nexus +4 · Eye +1 · Gift +5 · Crown +12) ---
# No member here carries a DR toggle, so the value is unconditional. Fixed-id modifier (idempotent).
attribute @s luck modifier add evercraft:astral_core_luck 25.0 add_value

# --- MULTI-COPY STRIP (D-MULTICOPY / m4, Layer 1: sub-binding supersedes its loose pieces) ---
# The Core folds the five members' DR into astral_core_luck above. Strip each member's loose *_luck
# (added EARLIER this tick by player_tick) so a re-acquired loose copy does NOT double-dip. None of
# these has a DR toggle, so the strips are un-gated (beyond the Newcomer carve-out). NEWCOMER
# CARVE-OUT: casual Newcomer players keep the forgiving double-dip stack.
execute unless score @s ec.difficulty matches 1 run attribute @s luck modifier remove evercraft:codex_of_everything_luck
execute unless score @s ec.difficulty matches 1 run attribute @s luck modifier remove evercraft:netherite_nexus_luck
execute unless score @s ec.difficulty matches 1 run attribute @s luck modifier remove evercraft:claudes_eye_luck
execute unless score @s ec.difficulty matches 1 run attribute @s luck modifier remove evercraft:claudes_gift_luck
execute unless score @s ec.difficulty matches 1 run attribute @s luck modifier remove evercraft:dreamspun_crown_luck
