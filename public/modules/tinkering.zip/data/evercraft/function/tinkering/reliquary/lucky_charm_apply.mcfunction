# ============================================================
# Dreamer's Reliquary — Lucky Charm perk re-apply (Fusion Wave / Family B, common starter)
# ============================================================
# Run as @s = the player, at @s. Called from artifacts/accessories/player_tick's consolidated
# fusion block (BEHIND the ec.has_accessory early-exit) when the player holds a lucky_charm:true
# item. The Lucky Charm is the trivial starter (✦) — the common-tier teach-fusion of the Dreamer's
# tree. It binds the Wishing Shard (#3, +1.0 DR) + Ruin Watch (+1.0 DR), so it re-grants exactly
# their union (both are pure DR leaves — NO secondary effect) folded into ONE modifier
# evercraft:lucky_charm_luck = +2.0 (dr_sum:2.0 in the registry row).
#
# BALANCE-NEUTRAL (D1 sub-node consolidate): both members already granted +1.0 DR while loose, so a
# player holding both already had +2.0 — the Lucky Charm keeps it in ONE slot. Fixed-id modifier
# (idempotent — two copies overwrite to one value, m4 Layer-2). READ-ONLY on state: writes no
# scoreboard; only grants/strips attribute modifiers.

# --- Consolidated +2.0 Dream Rate (Wishing Shard +1 · Ruin Watch +1) — ONE modifier ---
attribute @s luck modifier add evercraft:lucky_charm_luck 2.0 add_value

# --- MULTI-COPY STRIP (D-MULTICOPY / m4, Layer 1: sub-binding supersedes its loose pieces) ---
# The Lucky Charm folds Wishing Shard's +1 + Ruin Watch's +1 into lucky_charm_luck above. If the
# player ALSO re-acquired a loose Wishing Shard / Ruin Watch, player_tick already added their loose
# *_luck EARLIER this tick (loose accessory lines run before this consolidated fusion block — see
# the tick.mcfunction invariant). Strip those loose ids here so the Charm's bound members do NOT
# double-dip. Ruin Watch honors its existing toggle ec.t_rwatch (its loose line is ec.t_rwatch-
# gated, so the strip stays in lockstep). NEWCOMER CARVE-OUT (`unless ... matches 1`): casual
# Newcomer players keep the forgiving double-dip stack (§D-MULTICOPY casual exception).
execute unless score @s ec.difficulty matches 1 run attribute @s luck modifier remove evercraft:wishing_shard_luck
execute unless score @s ec.difficulty matches 1 unless score @s ec.t_rwatch matches 1 run attribute @s luck modifier remove evercraft:ruin_watch_luck
