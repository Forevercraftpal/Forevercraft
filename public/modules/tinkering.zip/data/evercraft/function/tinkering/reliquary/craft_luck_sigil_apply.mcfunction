# ============================================================
# Dreamer's Reliquary — Craft-Luck Sigil perk re-apply (Fusion Wave / Family B, conditional sub-cap)
# ============================================================
# Run as @s = the player, at @s. Called from artifacts/accessories/player_tick's consolidated
# fusion block (BEHIND the ec.has_accessory early-exit) when the player holds a craft_luck_sigil:true
# item. The Sigil binds the THREE conditional-DR craft charms (geologist_loupe +2, cache_eye +2,
# worldforge_ember +3 — all CONDITIONAL on the craft/mine activity window ec.cf_actwin), so it
# re-grants their union folded into ONE modifier evercraft:craft_luck_sigil_luck = +7.0 ONLY while
# the working window is open (dr_sum:7.0 in the registry row — the conditional headline).
#
# BALANCE-NEUTRAL (D1 sub-node consolidate): each member already granted its conditional +DR while
# loose, so a player holding all three already had +7.0 while working — the Sigil keeps it in ONE
# slot. The Worldforge Ember's +2.0 Craft Rate lever is applied SEPARATELY in
# craftforever/craft_rate/calculate.mcfunction (the ONE writer of ec.cr_temp — m4 HANDOFF #7), keyed
# on craft_luck_sigil:true while held. Remove-then-conditional-add (band_luck idiom) gated on
# ec.cf_actwin matches 1.. so the DR drops ~5s after the last qualifying verb. Fixed-id modifier
# (idempotent, m4 Layer-2). READ-ONLY on state.

# --- Consolidated +7.0 Dream Rate ONLY while the working window is open (ec.cf_actwin) ---
attribute @s luck modifier remove evercraft:craft_luck_sigil_luck
execute if score @s ec.cf_actwin matches 1.. run attribute @s luck modifier add evercraft:craft_luck_sigil_luck 7.0 add_value

# --- MULTI-COPY STRIP (D-MULTICOPY / m4, Layer 1: sub-binding supersedes its loose pieces) ---
# The Sigil folds the three members' conditional DR into craft_luck_sigil_luck above. Strip each
# member's loose *_luck (the conditional leaves remove-then-add their own id every tick in
# player_tick) so a re-acquired loose copy does NOT double-dip while working. Un-gated removes (the
# conditional members carry no DR toggle; their loose lines self-strip when idle anyway). NEWCOMER
# CARVE-OUT: casual Newcomer players keep the forgiving double-dip stack.
execute unless score @s ec.difficulty matches 1 run attribute @s luck modifier remove evercraft:geologist_loupe_luck
execute unless score @s ec.difficulty matches 1 run attribute @s luck modifier remove evercraft:cache_eye_luck
execute unless score @s ec.difficulty matches 1 run attribute @s luck modifier remove evercraft:worldforge_ember_luck
