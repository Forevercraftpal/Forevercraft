# ============================================================
# Dreamer's Reliquary — Fortune Coffer perk re-apply (Fusion Wave / Family B, ornate sub-binding)
# ============================================================
# Run as @s = the player, at @s. Called from artifacts/accessories/player_tick's consolidated
# fusion block (BEHIND the ec.has_accessory early-exit) when the player holds a fortune_coffer:true
# item. The Fortune Coffer binds the FIVE ornate DR charms (ruin_watch, miners_lantern,
# merchants_coin, anglers_pearl, enchanted_monocle), so it re-grants exactly their union (each
# member's secondary effect + their five +1.0 DR folded into ONE modifier
# evercraft:fortune_coffer_luck = +5.0; dr_sum:5.0 in the registry row).
#
# BALANCE-NEUTRAL (D1 sub-node consolidate): each member already granted its perk while loose, so a
# player holding all five already had the union — the Coffer keeps it in ONE slot. The DR honors
# each member's existing toggle (ruin_watch -> ec.t_rwatch, merchants_coin -> ec.t_merchant,
# anglers_pearl -> ec.t_angler; miners_lantern + enchanted_monocle have no DR toggle). Remove-then-
# conditional-add so the value is exact every tick and toggles can shrink it. Fixed-id modifier
# (idempotent, m4 Layer-2). READ-ONLY on state: writes no scoreboard; only grants effects/attrs.
#
# THE FIVE MEMBERS (mirror the loose lines verbatim — same effect/level/duration/ambient flag):
#   ruin_watch       -> +1.0 DR                          : unless ec.t_rwatch
#   miners_lantern   -> Night Vision + Ore Ping + +1.0 DR : always (NV/ore-ping); DR always
#   merchants_coin   -> Hero of the Village + +1.0 DR    : DR unless ec.t_merchant; HoV always
#   anglers_pearl    -> +1.0 DR                          : unless ec.t_angler
#   enchanted_monocle-> Night Vision + +1.0 DR           : always

# --- Member secondary effects (the union — verbatim from the loose player_tick lines) ---
effect give @s night_vision 15 0 false
effect give @s hero_of_the_village 5 0 true
function evercraft:artifacts/accessories/ore_ping

# --- Consolidated Dream Rate (5 members; remove-then-conditional-add so toggles shrink it) ---
# Miner's Lantern (+1) + Enchanted Monocle (+1) are always in. Ruin Watch / Merchant's Coin /
# Angler's Pearl each drop their +1 when toggled OFF. Base (all ON) = +5.0.
attribute @s luck modifier remove evercraft:fortune_coffer_luck
scoreboard players set #fc_dr ec.temp 20
execute unless score @s ec.t_rwatch matches 1 run scoreboard players add #fc_dr ec.temp 10
execute unless score @s ec.t_merchant matches 1 run scoreboard players add #fc_dr ec.temp 10
execute unless score @s ec.t_angler matches 1 run scoreboard players add #fc_dr ec.temp 10
execute store result storage evercraft:tnk_apply fc.dr double 0.1 run scoreboard players get #fc_dr ec.temp
function evercraft:tinkering/reliquary/fortune_coffer_dr with storage evercraft:tnk_apply fc

# --- MULTI-COPY STRIP (D-MULTICOPY / m4, Layer 1: sub-binding supersedes its loose pieces) ---
# The Coffer folds the five members' +1.0 DR into fortune_coffer_luck above. Strip each member's
# loose *_luck (added EARLIER this tick by player_tick) so a re-acquired loose copy does NOT
# double-dip. Each strip honors the member's toggle to stay in lockstep with its loose line.
# NEWCOMER CARVE-OUT: casual Newcomer players keep the forgiving double-dip stack.
execute unless score @s ec.difficulty matches 1 unless score @s ec.t_rwatch matches 1 run attribute @s luck modifier remove evercraft:ruin_watch_luck
execute unless score @s ec.difficulty matches 1 run attribute @s luck modifier remove evercraft:miners_lantern_luck
execute unless score @s ec.difficulty matches 1 unless score @s ec.t_merchant matches 1 run attribute @s luck modifier remove evercraft:merchants_coin_luck
execute unless score @s ec.difficulty matches 1 unless score @s ec.t_angler matches 1 run attribute @s luck modifier remove evercraft:anglers_pearl_luck
execute unless score @s ec.difficulty matches 1 run attribute @s luck modifier remove evercraft:enchanted_monocle_luck
