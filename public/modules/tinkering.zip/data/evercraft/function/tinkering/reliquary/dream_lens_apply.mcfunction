# ============================================================
# Dreamer's Reliquary — Dream Lens perk re-apply (Fusion Wave / Family B, exquisite sub-binding)
# ============================================================
# Run as @s = the player, at @s. Called from artifacts/accessories/player_tick's consolidated
# fusion block (BEHIND the ec.has_accessory early-exit) when the player holds a dream_lens:true
# item. The Dream Lens binds the THREE deep-dreaming charms (sculk_heart +2.0 DR, beacon_of_ancients
# full-beacon + +3.0 DR, dream_aegis +2.0 DR), so it re-grants exactly their union (Beacon's full
# harmonize-gated beacon + the three +2/+3/+2 DR folded into ONE modifier
# evercraft:dream_lens_luck = +7.0; dr_sum:7.0 in the registry row).
#
# BALANCE-NEUTRAL (D1 sub-node consolidate): each member already granted its perk while loose, so a
# player holding all three already had the union — the Lens keeps it in ONE slot. The DR honors the
# Sculk Heart's existing toggle ec.t_sculkhrt (its loose line is ec.t_sculkhrt-gated); Beacon +3 and
# Dream Aegis +2 have no DR toggle. Beacon effects keep their harmonize gates (ec.h_* matches ..1) so
# the Lens never double-stacks a harmonizable buff. Remove-then-conditional-add so the value is exact
# every tick. Fixed-id modifier (idempotent, m4 Layer-2). READ-ONLY on state.

# --- Beacon of Ancients full beacon (the union — verbatim from the loose player_tick lines) ---
execute if score @s ec.h_speed matches ..1 run effect give @s speed 5 0 false
execute if score @s ec.h_haste matches ..1 run effect give @s haste 5 0 false
execute if score @s ec.h_resist matches ..1 run effect give @s resistance 5 0 false
execute if score @s ec.h_jump matches ..1 run effect give @s jump_boost 5 0 false
execute if score @s ec.h_str matches ..1 run effect give @s strength 5 0 false
execute if score @s ec.h_regen matches ..1 unless entity @s[tag=ec.regen_capped] run effect give @s regeneration 5 0 false
execute if score @s ec.h_regen matches ..1 if entity @s[tag=ec.regen_capped] run function evercraft:artifacts/accessories/regen_fallback

# --- Consolidated Dream Rate (Sculk Heart +2 unless ec.t_sculkhrt · Beacon +3 · Dream Aegis +2) ---
attribute @s luck modifier remove evercraft:dream_lens_luck
execute unless score @s ec.t_sculkhrt matches 1 run attribute @s luck modifier add evercraft:dream_lens_luck 7.0 add_value
execute if score @s ec.t_sculkhrt matches 1 run attribute @s luck modifier add evercraft:dream_lens_luck 5.0 add_value

# --- MULTI-COPY STRIP (D-MULTICOPY / m4, Layer 1: sub-binding supersedes its loose pieces) ---
# The Lens folds the three members' DR into dream_lens_luck above. Strip each member's loose *_luck
# (added EARLIER this tick by player_tick) so a re-acquired loose copy does NOT double-dip. Sculk
# Heart strip honors ec.t_sculkhrt (lockstep with its loose line). dream_aegis_luck is added in
# player_tick via the ec.has_aegis tag — strip it here so the bound Aegis does not double-count.
# NEWCOMER CARVE-OUT: casual Newcomer players keep the forgiving double-dip stack.
execute unless score @s ec.difficulty matches 1 unless score @s ec.t_sculkhrt matches 1 run attribute @s luck modifier remove evercraft:sculk_heart_luck
execute unless score @s ec.difficulty matches 1 run attribute @s luck modifier remove evercraft:beacon_of_ancients_luck
execute unless score @s ec.difficulty matches 1 run attribute @s luck modifier remove evercraft:dream_aegis_luck
