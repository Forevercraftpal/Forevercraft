# ============================================================
# Dreamer's Reliquary — GRAND capstone: grant the full union, fold DR into ONE modifier
# ============================================================
# Run as @s = the player, at @s. Called from artifacts/accessories/player_tick's consolidated fusion
# block (BEHIND the ec.has_accessory early-exit) when the player holds a dreamers_reliquary:true
# item. The Reliquary IS the union of Family B's dreaming charms by definition (the fusion `do`
# consumed the four sub-bindings / their leaves and spawned the Reliquary flagged dreamers_reliquary
# — it does NOT carry the member items). So HERE we directly grant each absorbed member's secondary
# effect (every aura / status grant — verbatim from the loose player_tick lines), then fold the whole
# family's Dream Rate into the single consolidated modifier.
#
# DR HEADLINE (DECISIONS D1 — full-power ascension, UNCAPPED): the Reliquary's consolidated Dream
# Rate is the LOCKED +24.0 (DECISIONS "Dreamer's Reliquary +24 DR, all in one slot"). This is a
# deliberate design number (the raw always-on member sum is higher; +24 is the balanced grand
# headline). NO soft cap, no one-ascension latch (D1) — the global DR ceiling rose to 100.0
# (store 1000) in the w5 DR-cap unit so this fits. Fixed-id modifier (idempotent, m4 Layer-2: two
# Reliquaries overwrite to one value). Reports as ONE line in dreams/breakdown.
#
# ABSORBED MEMBERS (14): Fortune Coffer set (ruin_watch, miners_lantern, merchants_coin,
# anglers_pearl, enchanted_monocle) · Dream Lens set (sculk_heart, beacon_of_ancients, dream_aegis) ·
# Astral Core set (codex_of_everything, netherite_nexus, claudes_eye, claudes_gift, dreamspun_crown)
# · Lucky Charm starter (wishing_shard) · Craft-Luck Sigil set (geologist_loupe, cache_eye,
# worldforge_ember — conditional, folded into the +24 headline). READ-ONLY on state.

# --- 1) Grant the full member union (auras + status — verbatim from the loose player_tick lines) ---
# Fortune Coffer set: Night Vision (Lantern + Monocle) + Hero of the Village (Merchant) + Ore Ping
effect give @s night_vision 15 0 false
effect give @s hero_of_the_village 5 0 true
function evercraft:artifacts/accessories/ore_ping
# Dream Lens set: Beacon of Ancients full beacon (harmonize-gated)
execute if score @s ec.h_haste matches ..1 run effect give @s haste 5 0 false
execute if score @s ec.h_resist matches ..1 run effect give @s resistance 5 0 false
execute if score @s ec.h_jump matches ..1 run effect give @s jump_boost 5 0 false
execute if score @s ec.h_regen matches ..1 unless entity @s[tag=ec.regen_capped] run effect give @s regeneration 5 0 false
execute if score @s ec.h_regen matches ..1 if entity @s[tag=ec.regen_capped] run function evercraft:artifacts/accessories/regen_fallback
# Astral Core set: Netherite Nexus Resistance III + Claude's Gift Str/Haste/Speed III + Dreamspun
# Crown Str I/Speed I (all harmonize-gated; the III auras dominate the Crown's I via harmonize).
execute if score @s ec.h_resist matches ..1 run effect give @s resistance 5 2 false
execute if score @s ec.h_str matches ..1 run effect give @s strength 5 2 false
execute if score @s ec.h_haste matches ..1 run effect give @s haste 5 2 false
execute if score @s ec.h_speed matches ..1 run effect give @s speed 5 2 false
particle end_rod ~ ~1 ~ 0.3 0.5 0.3 0.02 1

# --- 2) Strip every absorbed member's loose *_luck (folded into the +24 below) ---
# Newcomer-gated (casual keeps the forgiving double-dip stack). These were added EARLIER this tick by
# the loose player_tick lines; the Reliquary supersedes them. DR-toggled members honor their toggle
# to stay in lockstep with the loose line.
execute unless score @s ec.difficulty matches 1 run attribute @s luck modifier remove evercraft:wishing_shard_luck
execute unless score @s ec.difficulty matches 1 unless score @s ec.t_rwatch matches 1 run attribute @s luck modifier remove evercraft:ruin_watch_luck
execute unless score @s ec.difficulty matches 1 run attribute @s luck modifier remove evercraft:miners_lantern_luck
execute unless score @s ec.difficulty matches 1 unless score @s ec.t_merchant matches 1 run attribute @s luck modifier remove evercraft:merchants_coin_luck
execute unless score @s ec.difficulty matches 1 unless score @s ec.t_angler matches 1 run attribute @s luck modifier remove evercraft:anglers_pearl_luck
execute unless score @s ec.difficulty matches 1 run attribute @s luck modifier remove evercraft:enchanted_monocle_luck
execute unless score @s ec.difficulty matches 1 unless score @s ec.t_sculkhrt matches 1 run attribute @s luck modifier remove evercraft:sculk_heart_luck
execute unless score @s ec.difficulty matches 1 run attribute @s luck modifier remove evercraft:beacon_of_ancients_luck
execute unless score @s ec.difficulty matches 1 run attribute @s luck modifier remove evercraft:dream_aegis_luck
execute unless score @s ec.difficulty matches 1 run attribute @s luck modifier remove evercraft:codex_of_everything_luck
execute unless score @s ec.difficulty matches 1 run attribute @s luck modifier remove evercraft:netherite_nexus_luck
execute unless score @s ec.difficulty matches 1 run attribute @s luck modifier remove evercraft:claudes_eye_luck
execute unless score @s ec.difficulty matches 1 run attribute @s luck modifier remove evercraft:claudes_gift_luck
execute unless score @s ec.difficulty matches 1 run attribute @s luck modifier remove evercraft:dreamspun_crown_luck
execute unless score @s ec.difficulty matches 1 run attribute @s luck modifier remove evercraft:geologist_loupe_luck
execute unless score @s ec.difficulty matches 1 run attribute @s luck modifier remove evercraft:cache_eye_luck
execute unless score @s ec.difficulty matches 1 run attribute @s luck modifier remove evercraft:worldforge_ember_luck

# --- 3) Strip the four sub-binding consolidated luck (the Reliquary supersedes its sub-nodes) ---
# If a player somehow holds a sub-binding alongside the grand (re-acquired), the grand wins. These
# are NOT Newcomer-gated: a sub-binding's own consolidate already double-counts vs the loose members
# the grand just stripped, so the grand must always remove the sub-node id to keep ONE source of DR.
attribute @s luck modifier remove evercraft:lucky_charm_luck
attribute @s luck modifier remove evercraft:fortune_coffer_luck
attribute @s luck modifier remove evercraft:dream_lens_luck
attribute @s luck modifier remove evercraft:astral_core_luck
attribute @s luck modifier remove evercraft:craft_luck_sigil_luck

# --- 4) Present the single consolidated Dream Rate (ascension headline, D1 full-power, UNCAPPED) ---
attribute @s luck modifier add evercraft:dreamers_reliquary_luck 24.0 add_value
