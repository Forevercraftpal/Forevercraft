# ============================================================
# Tinkering — Trinket Knot perk re-apply (called from player_tick's additive block)
# ============================================================
# Run as @s = the player, at @s. Called from artifacts/accessories/player_tick's ONE additive
# perk-read block (behind the ec.has_accessory early-exit, T4) when the player holds a
# tinker_knot:true item. The Knot carries its two bound sub-trinket ids in custom_data
# (knot_a / knot_b, stamped by plinth/do_knot). This re-applies the union of those two
# trinkets' effects so the Knot is BALANCE-NEUTRAL (the player keeps exactly the effects the
# two trinkets gave while held; the Knot only freed a slot — DECISIONS #9 / R14).
#
# SCOPE: the Trinket Knot fuses any two COMMON accessories (the trivial starter, §C). The
# common accessory roster (verified against player_tick's "=== COMMON ACCESSORIES ===" block)
# is small — pebble_of_dreams (+1 Dream Rate / luck), travelers_charm (Speed I), worn_compass
# (Slow Falling below Y=0). We re-grant each of those effects when the held Knot's knot_a OR
# knot_b names it. (If a knot bound an id outside the common set — e.g. a future uncommon
# Knot — that effect simply isn't re-applied here; flag for a later sub-wave. The common set
# is what the q4 starter fusion teaches.)
#
# This file is invoked once per Knot-holding player per tick; it tests the held Knot's
# custom_data via `if items entity @s ... *[custom_data~{tinker_knot:true,knot_a:"<id>"}]`.
# Each effect line is a normal effect give (matches the original common-accessory grant).
# READ-ONLY on state: writes no scoreboard; only grants effects/attributes (like the rest of
# player_tick). The luck attribute uses a DISTINCT modifier id so it stacks cleanly + is
# cleaned up by the accessory cleanup pass.

# --- Pebble of Dreams (+1 Dream Rate / luck) — bound as knot_a or knot_b ---
execute if items entity @s container.* *[custom_data~{tinker_knot:true,knot_a:"pebble_of_dreams"}] run attribute @s luck modifier add evercraft:tnk_knot_luck 1.0 add_value
execute if items entity @s container.* *[custom_data~{tinker_knot:true,knot_b:"pebble_of_dreams"}] run attribute @s luck modifier add evercraft:tnk_knot_luck 1.0 add_value
execute if items entity @s weapon.offhand *[custom_data~{tinker_knot:true,knot_a:"pebble_of_dreams"}] run attribute @s luck modifier add evercraft:tnk_knot_luck 1.0 add_value
execute if items entity @s weapon.offhand *[custom_data~{tinker_knot:true,knot_b:"pebble_of_dreams"}] run attribute @s luck modifier add evercraft:tnk_knot_luck 1.0 add_value

# --- Travelers Charm (Speed I) — bound as knot_a or knot_b ---
execute if items entity @s container.* *[custom_data~{tinker_knot:true,knot_a:"travelers_charm"}] run effect give @s speed 5 0 false
execute if items entity @s container.* *[custom_data~{tinker_knot:true,knot_b:"travelers_charm"}] run effect give @s speed 5 0 false
execute if items entity @s weapon.offhand *[custom_data~{tinker_knot:true,knot_a:"travelers_charm"}] run effect give @s speed 5 0 false
execute if items entity @s weapon.offhand *[custom_data~{tinker_knot:true,knot_b:"travelers_charm"}] run effect give @s speed 5 0 false

# --- Worn Compass (Slow Falling below Y=0) — bound as knot_a or knot_b ---
execute if entity @s[y=-64,dy=64] if items entity @s container.* *[custom_data~{tinker_knot:true,knot_a:"worn_compass"}] run effect give @s slow_falling 5 0 false
execute if entity @s[y=-64,dy=64] if items entity @s container.* *[custom_data~{tinker_knot:true,knot_b:"worn_compass"}] run effect give @s slow_falling 5 0 false
execute if entity @s[y=-64,dy=64] if items entity @s weapon.offhand *[custom_data~{tinker_knot:true,knot_a:"worn_compass"}] run effect give @s slow_falling 5 0 false
execute if entity @s[y=-64,dy=64] if items entity @s weapon.offhand *[custom_data~{tinker_knot:true,knot_b:"worn_compass"}] run effect give @s slow_falling 5 0 false

# --- MULTI-COPY STRIP (D-MULTICOPY / m4, Layer 1: capstone supersedes its loose pieces) ---
# A Trinket Knot that bound Pebble of Dreams folds that +1.0 DR into its OWN tnk_knot_luck above.
# If the player ALSO re-acquired a loose Pebble of Dreams, player_tick:201-202 already added the
# loose evercraft:pebble_of_dreams_luck +1.0 EARLIER this tick (loose lines run before this
# consolidate per the tick.mcfunction invariant). Strip that loose id here so the Knot's bound
# Pebble does NOT double-dip (would be +2.0). Only the Pebble-of-Dreams member carries a luck
# modifier; the Knot's other common members (Travelers Charm Speed I, Worn Compass Slow Falling)
# are fixed-level status effects — re-applying them is idempotent (overwrites, never stacks), so
# there is nothing to strip for those. NEWCOMER CARVE-OUT (`unless ... matches 1`): casual
# Newcomer players keep the forgiving double-dip stack (§D-MULTICOPY casual exception).
execute unless score @s ec.difficulty matches 1 if items entity @s container.* *[custom_data~{tinker_knot:true,knot_a:"pebble_of_dreams"}] run attribute @s luck modifier remove evercraft:pebble_of_dreams_luck
execute unless score @s ec.difficulty matches 1 if items entity @s container.* *[custom_data~{tinker_knot:true,knot_b:"pebble_of_dreams"}] run attribute @s luck modifier remove evercraft:pebble_of_dreams_luck
execute unless score @s ec.difficulty matches 1 if items entity @s weapon.offhand *[custom_data~{tinker_knot:true,knot_a:"pebble_of_dreams"}] run attribute @s luck modifier remove evercraft:pebble_of_dreams_luck
execute unless score @s ec.difficulty matches 1 if items entity @s weapon.offhand *[custom_data~{tinker_knot:true,knot_b:"pebble_of_dreams"}] run attribute @s luck modifier remove evercraft:pebble_of_dreams_luck

# Clean up the luck modifier when no Knot is held (mirrors the per-accessory cleanup; the
# generic accessory_cleanup pass also strips stale luck modifiers, but we remove our DISTINCT
# id here defensively so it never lingers a tick after the Knot leaves the inventory).
execute unless items entity @s container.* *[custom_data~{tinker_knot:true}] unless items entity @s weapon.offhand *[custom_data~{tinker_knot:true}] run attribute @s luck modifier remove evercraft:tnk_knot_luck
