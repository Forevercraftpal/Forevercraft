# The Tinkerer's Codex — Reset cooldown (runs ~1s after a right-click use).
# Revokes the using_item advancement so the book can be used again. Clone of
# adventure/kingdom/book/reset_cooldown (C6).
execute as @a[tag=ec.tnkbook_cd] run advancement revoke @s only evercraft:tinkering_questline/on_use
tag @a[tag=ec.tnkbook_cd] remove ec.tnkbook_cd
