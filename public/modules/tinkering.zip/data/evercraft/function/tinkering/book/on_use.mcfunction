# ============================================================
# Tinkering — Tinkerer's Codex right-click handler
# ============================================================
# Triggered by the using_item advancement (tinkering_questline/on_use.json) when the player
# right-clicks a minecraft:book carrying custom_data{tinker_book:true}. Clone of
# adventure/kingdom/book/on_use (C6): the advancement stays granted briefly to prevent spam,
# then is revoked by a scheduled cooldown reset. Opens the Tinkering overview page (the
# Workshop). Run as @s = the player.

# Only fire from the mainhand (a book sitting in a container shouldn't trigger).
execute unless items entity @s weapon.mainhand minecraft:book[custom_data~{tinker_book:true}] run return fail

# Cooldown guard: schedule advancement revoke after ~1s (always, regardless of outcome) so a
# single right-click opens the page exactly once.
tag @s add ec.tnkbook_cd
schedule function evercraft:tinkering/book/reset_cooldown 20t append

# Open the Tinkering overview (the same page the Tier-2 rows open).
function evercraft:tinkering/overview
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:item.book.page_turn master @s ~ ~ ~ 0.8 1.2
