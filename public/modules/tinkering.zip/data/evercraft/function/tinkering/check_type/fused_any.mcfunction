# TNK check helper — fused_any (the player has EVER performed ANY fusion). @s = player.
# Catch-up + see-it-once teach beat (q4 "Your first union", skippable:0). Satisfied when
# ANY bit of the ec.tnk_owned safe-OR bitfield is set (bit0 Knot / bit1 Band / bit2 Hand /
# bit3 Charm) — i.e. ec.tnk_owned matches 1.. . A player who already forged anything (incl.
# a veteran whose start-seed lit a bit from a held bundle item) auto-passes on the next 20t
# check at full reward (R1). This is the universal "do one fusion once" gate — satisfied by
# the trivial Trinket Knot OR any advanced fusion (T10).
#
# Called `with storage evercraft:tnk_cur o` (the check_macro passes it for uniformity); this
# helper ignores the macro args and reads the bitfield, so it is a PLAIN (non-$) file.
#
# READ-ONLY: reads ec.tnk_owned (this line's OWN safe-OR latch — the fusion do_merge/confirm
# fns are its writers). Writes nothing.
scoreboard players set #tnk_satisfied ec.temp 0
execute if score @s ec.tnk_owned matches 1.. run scoreboard players set #tnk_satisfied ec.temp 1
