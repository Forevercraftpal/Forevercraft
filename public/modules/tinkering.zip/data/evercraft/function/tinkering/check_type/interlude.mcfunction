# TNK check helper — interlude (no-op safety net). @s = player.
# An interlude beat (beat:"interlude", count:0) is satisfied BEFORE the per-type dispatch by
# tinkering/check's interlude guard (SCHEMA_DELTA §3), so this file is NEVER reached on the
# normal path. It exists only as a defensive no-op so that a mis-authored row whose `type` is
# literally "interlude" (instead of relying on the beat/count guard) still routes to a real
# file rather than a missing-path load error. It sets #tnk_satisfied to 1 (an interlude is
# always satisfied) for that pathological case.
#
# Called `with storage evercraft:tnk_cur o`; ignores the macro args, so a PLAIN (non-$) file.
# READ-ONLY: writes nothing but the shared #tnk_satisfied ec.temp flag.
scoreboard players set #tnk_satisfied ec.temp 1
