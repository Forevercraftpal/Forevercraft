# TNK check helper — own_accessories (the player HOLDS >=count accessory items). @s =
# player. Catch-up + present-action beat (chapter intro: gather your trinkets). Reads the
# player's held inventory DIRECTLY (a held-item test, not a lifetime score) and satisfies
# when the COUNT of accessory:true / ring:true items the player carries reaches quest.count
# (#tnk_count ec.temp). A player who already carries >=2 accessories auto-passes on the next
# 20t check at full reward (R1) — exactly the universality on-ramp (any 2 trinkets, any path).
#
# Called `with storage evercraft:tnk_cur o` (the check_macro passes it for uniformity); this
# helper ignores the macro's storage args (it reads #tnk_count from ec.temp + scans the
# inventory), so it is a PLAIN (non-$) file.
#
# COUNT: `execute store result ... if items entity @s container.* <predicate>` returns the
# TOTAL stack count of matching items. Accessories are max_stack_size:1 (verified the artifact
# loot tables), so the total item count == the number of DISTINCT accessories held — exactly
# the "carry 2 trinkets" intent. We sum accessory:true + ring:true + boss_exclusive:true (the
# same three families the player_tick early-exit scans) so any mix of trinkets counts.
#
# READ-ONLY: reads held items only. Writes NO accessory/fusion objective (the no-write proof).
scoreboard players set #tnk_satisfied ec.temp 0
scoreboard players set #tnk_acc_n ec.temp 0
execute store result score #tnk_acc_n ec.temp if items entity @s container.* *[custom_data~{accessory:true}]
execute store result score #tnk_acc_ring ec.temp if items entity @s container.* *[custom_data~{ring:true}]
scoreboard players operation #tnk_acc_n ec.temp += #tnk_acc_ring ec.temp
execute store result score #tnk_acc_off ec.var if items entity @s weapon.offhand *[custom_data~{accessory:true}]
scoreboard players operation #tnk_acc_n ec.temp += #tnk_acc_off ec.var
execute if score #tnk_acc_n ec.temp >= #tnk_count ec.temp run scoreboard players set #tnk_satisfied ec.temp 1
