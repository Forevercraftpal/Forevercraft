# TNK check helper — fused_band (the player has forged the Band of Rings). @s = player.
# Catch-up beat (q6 "Consolidate your rings", skippable:1 — an ADVANCED fusion the line
# never walls on). Satisfied when ec.tnk_owned bit1 (value 2) is set — the Band's confirm fn
# (round-1 Wave 8, OR-set in Wave C8) lights this bit. Reads the bit via the canonical
# bitfield idiom: (ec.tnk_owned / 2) % 2 == 1. A veteran who already forged a Band auto-passes
# at full reward (R1); a player who never wants the advanced fusion can [Skip ▸] (skippable:1).
#
# Called `with storage evercraft:tnk_cur o` (the check_macro passes it for uniformity); this
# helper ignores the macro args and reads the bitfield, so it is a PLAIN (non-$) file.
#
# READ-ONLY: reads ec.tnk_owned (this line's OWN safe-OR latch). Writes nothing. Folds the
# bit-test into private temp registers (#tnk_bit, #tnk_two), never writes the field back.
scoreboard players set #tnk_satisfied ec.temp 0
scoreboard players set #tnk_two ec.temp 2
scoreboard players operation #tnk_bit ec.temp = @s ec.tnk_owned
scoreboard players operation #tnk_bit ec.temp /= #tnk_two ec.temp
scoreboard players operation #tnk_bit ec.temp %= #tnk_two ec.temp
execute if score #tnk_bit ec.temp matches 1 run scoreboard players set #tnk_satisfied ec.temp 1
