# TNK check helper — fused_charm (the player has forged the Band of Charms). @s = player.
# Catch-up beat (q9 "Bind your charms", skippable:1 — the DEFERRED sub-wave fusion the line
# never walls on; the Band-of-Charms recipe is a future sub-wave). Satisfied when ec.tnk_owned
# bit3 (value 8) is set — the Charm-Band's confirm fn (future sub-wave) lights this bit. Reads
# the bit via the canonical bitfield idiom: (ec.tnk_owned / 8) % 2 == 1. Until the Band-of-
# Charms ships, NO writer sets bit3, so this beat is reached only by a player who walks the
# line that far — and it is skippable:1 (the player [Skip ▸]s it at full reward, completing the
# line). A future veteran with the Charm Band auto-passes at full reward (R1).
#
# Called `with storage evercraft:tnk_cur o` (the check_macro passes it for uniformity); this
# helper ignores the macro args and reads the bitfield, so it is a PLAIN (non-$) file.
#
# READ-ONLY: reads ec.tnk_owned (this line's OWN safe-OR latch). Writes nothing. Folds the
# bit-test into private temp registers, never writes the field back.
scoreboard players set #tnk_satisfied ec.temp 0
scoreboard players set #tnk_two ec.temp 2
scoreboard players set #tnk_eight ec.temp 8
scoreboard players operation #tnk_bit ec.temp = @s ec.tnk_owned
scoreboard players operation #tnk_bit ec.temp /= #tnk_eight ec.temp
scoreboard players operation #tnk_bit ec.temp %= #tnk_two ec.temp
execute if score #tnk_bit ec.temp matches 1 run scoreboard players set #tnk_satisfied ec.temp 1
