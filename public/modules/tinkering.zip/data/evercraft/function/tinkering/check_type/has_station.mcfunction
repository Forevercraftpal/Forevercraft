# TNK check helper — has_station (the player has a fusion station: a Tinkerer's Plinth OR a
# Fusion Funnel). @s = player. Catch-up + see-it-once teach beat (q3 "Raise the Workshop",
# skippable:0). Satisfied if the player OWNS a Fusion Funnel (the ec.cf_r10_granted tag — a
# rank-10 Artisan already has the Funnel, so the "Workshop" is considered raised; verified
# craftforever/artisan/grant_rank10_fusion_funnel:3) OR holds a Tinkerer's Plinth item
# (custom_data{tinker_station:true}). The q3 reward (reward_type/station) HANDS the player a
# Plinth, so a newcomer who reaches q3 receives the Plinth → the beat satisfies on the next
# 20t check (the reward fires on advance, then the next check sees the held Plinth). A
# rank-10 veteran auto-passes immediately via the Funnel tag (R1).
#
# Called `with storage evercraft:tnk_cur o` (the check_macro passes it for uniformity); this
# helper ignores the macro args and reads a tag + held item, so it is a PLAIN (non-$) file.
#
# READ-ONLY: reads the ec.cf_r10_granted tag (artisan-owned) + held Plinth items. Writes NO
# funnel/artisan objective (the no-write proof). The Plinth give itself happens in the q3
# reward (reward_type/station), not here.
scoreboard players set #tnk_satisfied ec.temp 0
# Funnel owner (rank-10 Artisan) — the Workshop is already raised.
execute if entity @s[tag=ec.cf_r10_granted] run scoreboard players set #tnk_satisfied ec.temp 1
# OR holds a Tinkerer's Plinth item.
execute if items entity @s container.* *[custom_data~{tinker_station:true}] run scoreboard players set #tnk_satisfied ec.temp 1
execute if items entity @s weapon.offhand *[custom_data~{tinker_station:true}] run scoreboard players set #tnk_satisfied ec.temp 1
