# ============================================================
# Bulwark Stone (titan_bulwark) — tank sub-binding: grant the consolidated tank union (B1 + B2 + B7 + B12)
# ============================================================
# Run as @s = the player, at @s. Called from artifacts/accessories/player_tick's consolidated fusion
# block (the Family-L dispatch, BEHIND the ec.has_accessory early-exit) when the player holds a
# titan_bulwark:true item AND is NOT holding the grand Heart of the Mountain (the grand supersedes — it
# calls this apply itself). The Bulwark Stone IS the union of B1 Stoneward Pebble + B2 Vital Acorn + B7
# Anvil Heart + B12 Bulwark Plate by definition (the fusion `do` consumed them and spawned the Bulwark
# Stone flagged titan_bulwark — it does NOT carry the member items). So HERE we re-grant the consolidated
# flat-tank kit via DISTINCT sub-cap-scoped ids (NOT the loose leaf ids) so the loose accessory_cleanup
# never strips them and the cap-L accessory_cleanup block owns their removal when the Bulwark Stone is not
# held.
#
# DISTINCT id `titan_bulwark` (the `bulwark_stone` id is the Family-D Soulguard sub-cap; the LEAF Bulwark
# Plate keeps `bulwark_plate`). No clash.
#
# CONSOLIDATED VALUE (the union of the four tank leaves, all add_value flat modifiers):
#   - armor +5 (Stoneward Pebble +2 + Bulwark Plate +3).
#   - armor_toughness +2 (Anvil Heart +1 + Bulwark Plate +1).
#   - max_health +2 = 1 extra heart (Vital Acorn).
#   - knockback_resistance +0.15 (Anvil Heart — stagger-proof).
#   - explosion_knockback_resistance +0.10 (Bulwark Plate).
# Fixed-id `modifier add` re-added each tick (idempotent — two Bulwark Stones overwrite to ONE value, m4
# Layer-2). Zero DR (flat tank stones have no luck).

# --- Consolidated Armor +5 (Stoneward +2 + Bulwark Plate +3) ---
attribute @s armor modifier add evercraft:titan_bulwark_armor 5 add_value

# --- Consolidated Armor Toughness +2 (Anvil +1 + Bulwark Plate +1) ---
attribute @s armor_toughness modifier add evercraft:titan_bulwark_tough 2 add_value

# --- Consolidated Max Health +2 = 1 extra heart (Vital Acorn) ---
attribute @s max_health modifier add evercraft:titan_bulwark_hp 2 add_value

# --- Consolidated Knockback Resistance +0.15 (Anvil Heart) ---
attribute @s knockback_resistance modifier add evercraft:titan_bulwark_kb 0.15 add_value

# --- Consolidated Explosion Knockback Resistance +0.10 (Bulwark Plate) ---
attribute @s explosion_knockback_resistance modifier add evercraft:titan_bulwark_ekb 0.10 add_value
