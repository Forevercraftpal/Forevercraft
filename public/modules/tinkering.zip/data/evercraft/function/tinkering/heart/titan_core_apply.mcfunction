# ============================================================
# Titan Core — mythical-defense sub-binding: grant the consolidated ward union (the 4 stones + Bastion)
# ============================================================
# Run as @s = the player, at @s. Called from artifacts/accessories/player_tick's consolidated fusion
# block (the Family-L dispatch, BEHIND the ec.has_accessory early-exit) when the player holds a
# titan_core:true item AND is NOT holding the grand Heart of the Mountain (the grand supersedes — it calls
# this apply itself). The Titan Core IS the union of the four re-homed mythical defense stones (Temporal
# Hourglass + Heart of the Void + Redstone Heart + Prism of Light) + #7 Bastion Totem by definition (the
# fusion `do` consumed them and spawned the Titan Core flagged titan_core — it does NOT carry the member
# items). So HERE we re-grant the consolidated ward kit as potion EFFECTS (verbatim from the loose stones'
# legacy player_tick lines — see :1392-1457), at the MAX level of each (Form-2 idempotent — re-applying an
# effect at the same level each tick does not stack). No attribute modifier, no accessory_cleanup strip
# needed; the wards lapse naturally (5t/0.25s decay) when the Titan Core is dropped. Zero DR (wards have no
# luck).
#
# CONSOLIDATED WARD UNION (the max level of each across the five members):
#   - Resistance II      (Temporal Hourglass; > Heart of the Void / Bastion Resistance I).
#   - Speed I            (Temporal Hourglass).
#   - Haste III          (Redstone Heart) — harmonize-gated on ec.h_haste (the legacy redstone_heart gate).
#   - Slow Falling       (Heart of the Void).
#   - Night Vision       (Heart of the Void / Prism of Light).
#   - Absorption IV      (Prism of Light).
#   - Bastion Aura: Resistance I to allies within 16 b (the #7 Bastion Totem party ward; the holder already
#     has Resistance II above, so this only lifts nearby allies).

# --- Temporal Hourglass union — Resistance II + Speed I ---
effect give @s resistance 5 1 false
effect give @s speed 5 0 false

# --- Heart of the Void union — Slow Falling + Night Vision (Resistance I subsumed by Resistance II above) ---
effect give @s slow_falling 5 0 false
effect give @s night_vision 15 0 false

# --- Redstone Heart union — Haste III (harmonize-gated on ec.h_haste, the legacy redstone_heart gate). ---
execute if score @s ec.h_haste matches ..1 run effect give @s haste 5 2 false

# --- Prism of Light union — Absorption IV (Night Vision already granted above). ---
effect give @s absorption 5 3 false

# --- Bastion Totem party aura — Resistance I to allies within 16 b (the #7 totem ward; holder already at
#     Resistance II, so this lifts nearby allies; the nether_star_shard beacon idiom). ---
effect give @a[distance=..16] resistance 5 0 false
