# ============================================================
# Heart of the Mountain — GRAND capstone: grant the full Vanguard union (the four sub-caps), full-power
# ============================================================
# Run as @s = the player, at @s. Called from artifacts/accessories/player_tick's consolidated fusion
# block (the Family-L dispatch, BEHIND the ec.has_accessory early-exit) when the player holds a
# heart_of_the_mountain:true item. The Heart of the Mountain IS the union of the WHOLE Family-L Vanguard
# by definition (the fusion `do` consumed the Bulwark Stone + Titan Core + Ascendant Line + Stride Line —
# and through them all 15 leaves — and spawned the Heart flagged heart_of_the_mountain; it does NOT carry
# the member items). So HERE we re-grant the FULL consolidated vanguard bundle by calling the four sub-cap
# applies (idempotent — they grant fixed-id attribute modifiers / Form-2 effects, so re-running them each
# tick overwrites to ONE value; the Soulguard Aegis grand idiom). This = the full 16-member bundle:
#   - Bulwark Stone  -> +5 armor / +2 toughness / +2 max HP / 15% KB / 10% explosion-KB (distinct titan_bulwark ids).
#   - Titan Core     -> the ward union (Resistance II, Absorption IV, Haste III, Speed I, Slow Falling,
#                       Night Vision) + the Bastion party aura (effects, lapse naturally).
#   - Ascendant Line -> +3 attack always (+1 above 80% HP) + the conditional +1.0 node-proximity DR
#                       (ascendant_locket_luck) — distinct ascendant ids.
#   - Stride Line    -> +8% sprint speed + +0.9 step + -15% fall (distinct stride ids).
# The CR (+5.0 from the Ascendant Forgeheart half) routes through craft_rate/calculate (the ONE ec.cr_temp
# writer, m4 HANDOFF #7), gated on the held heart_of_the_mountain flag — NEVER a 2nd cr_temp writer here.
# DISTINCT sub-cap-scoped attribute ids (NOT the loose leaf ids) so the loose accessory_cleanup never
# strips the Heart's grant; the cap-L accessory_cleanup block strips these `unless` the Heart (or the
# matching sub-cap) is held. ZERO base DR (L = power-bundle; the only luck is the consolidated conditional
# node-proximity +1.0, which reports under B's craft-luck line). The grand SUPERSEDES its four sub-caps —
# their dispatch in player_tick is guarded `unless` the grand is held, so nothing doubles.
#
# ABSORBED MEMBERS (15): tank — stoneward_pebble, vital_acorn, anvil_heart, bulwark_plate; ward —
# temporal_hourglass, heart_of_the_void, redstone_heart, prism_of_light, bastion_totem; combat —
# reavers_knuckle, resonant_locket, ascendant_forgeheart; stride — sprinters_anklet, wayfarers_greaves,
# sure_step_pebble. READ-ONLY on state except the consolidated fixed-id attributes (idempotent overwrite)
# + the Form-2 ward effects.

# --- The full vanguard union = the four sub-cap applies (idempotent fixed-id grants / Form-2 effects). ---
function evercraft:tinkering/heart/titan_bulwark_apply
function evercraft:tinkering/heart/titan_core_apply
function evercraft:tinkering/heart/ascendant_line_apply
function evercraft:tinkering/heart/stride_line_apply
