# ============================================================
# Ascendant Line — combat sub-binding: grant the consolidated combat union (B6 + B10 + P2)
# ============================================================
# Run as @s = the player, at @s. Called from artifacts/accessories/player_tick's consolidated fusion
# block (the Family-L dispatch, BEHIND the ec.has_accessory early-exit) when the player holds an
# ascendant_line:true item AND is NOT holding the grand Heart of the Mountain (the grand supersedes — it
# calls this apply itself). The Ascendant Line IS the union of B6 Reaver's Knuckle + B10 Resonant Locket +
# P2 Ascendant Forgeheart by definition (the fusion `do` consumed them and spawned the Ascendant Line
# flagged ascendant_line — it does NOT carry the member items). So HERE we re-grant the consolidated
# combat kit via DISTINCT sub-cap-scoped ids (NOT the loose leaf ids) so the loose accessory_cleanup never
# strips them and the cap-L accessory_cleanup block owns their removal when the Ascendant Line is not held.
#
# CONSOLIDATED VALUE (the union of the three combat leaves):
#   - attack_damage +3.0 ALWAYS (Resonant Locket +1.0 + Ascendant Forgeheart +2.0) — fixed-id add_value.
#   - attack_damage +1.0 ONLY above 80% health (Reaver's Knuckle; health_above_16 predicate) —
#     remove-then-conditional-add so it drops the moment HP falls below the line OR the node is dropped.
#   - CONDITIONAL +1.0 Dream Rate while a craft-node marker is within 24 b (Resonant Locket -> the ONE
#     consolidated ascendant_locket_luck; remove-then-conditional-add, gated on the ec.cf_node_data marker
#     the Astrolabe/Dowsing pings read). This is L's ONLY luck modifier; it reports one breakdown line in
#     dreams/breakdown/artifacts (under B's craft-luck line per the lattice — the breakdown reads the live
#     modifier value, so it shows only while a node is near).
# The CR (+5.0 from Ascendant Forgeheart) routes through craft_rate/calculate (the ONE ec.cr_temp writer,
# m4 HANDOFF #7 — gated on the held ascendant_line / heart_of_the_mountain flag; NEVER a 2nd cr_temp writer
# here). Fixed-id `modifier add` re-added each tick (idempotent — two Ascendant Lines overwrite to ONE
# value, m4 Layer-2).

# --- Consolidated Attack Damage +3.0 always (Resonant Locket +1.0 + Ascendant Forgeheart +2.0) ---
attribute @s attack_damage modifier add evercraft:ascendant_atk 3.0 add_value

# --- Conditional Attack Damage +1.0 above 80% health (Reaver's Knuckle) — remove-then-conditional-add. ---
attribute @s attack_damage modifier remove evercraft:ascendant_atk_hp
execute if predicate evercraft:health_above_16 run attribute @s attack_damage modifier add evercraft:ascendant_atk_hp 1.0 add_value

# --- Conditional +1.0 Dream Rate while a craft-node marker is within 24 b (Resonant Locket consolidated) —
#     remove-then-conditional-add so it frees when no node is near or the node is dropped. ---
attribute @s luck modifier remove evercraft:ascendant_locket_luck
execute if entity @e[type=marker,tag=ec.cf_node_data,distance=..24,limit=1] run attribute @s luck modifier add evercraft:ascendant_locket_luck 1.0 add_value
