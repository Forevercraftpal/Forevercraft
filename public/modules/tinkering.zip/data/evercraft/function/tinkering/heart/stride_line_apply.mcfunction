# ============================================================
# Stride Line — traversal sub-binding: grant the consolidated stride union (B5 + B9 + U2)
# ============================================================
# Run as @s = the player, at @s. Called from artifacts/accessories/player_tick's consolidated fusion
# block (the Family-L dispatch, BEHIND the ec.has_accessory early-exit) when the player holds a
# stride_line:true item AND is NOT holding the grand Heart of the Mountain (the grand supersedes — it
# calls this apply itself). The Stride Line IS the union of B5 Sprinter's Anklet + B9 Wayfarer's Greaves +
# U2 Sure-Step Pebble by definition (the fusion `do` consumed them and spawned the Stride Line flagged
# stride_line — it does NOT carry the member items). So HERE we re-grant the consolidated traversal kit via
# DISTINCT sub-cap-scoped ids (NOT the loose leaf ids) so the loose accessory_cleanup never strips them and
# the cap-L accessory_cleanup block owns their removal when the Stride Line is not held.
#
# CONSOLIDATED VALUE (the union of the three stride leaves):
#   - movement_speed +8% ONLY while sprinting (B5 Sprinter's Anklet) — remove-then-conditional-add so it
#     strips the moment the player stops sprinting OR drops the node (the band_luck idiom).
#   - step_height +0.9 (B9 Wayfarer's Greaves +0.5 + U2 Sure-Step Pebble +0.4).
#   - fall_damage_multiplier -0.15 (B9 Wayfarer's Greaves; add_multiplied_base = -15% off incoming fall).
# Fixed-id `modifier add` re-added each tick (idempotent — two Stride Lines overwrite to ONE value, m4
# Layer-2). The +1% dodge the loose Anklet/Greaves carry lives in the m1 ec.acc_dodge LEAF block (loose
# only — the Stride Line is one fused item; the dodge stays on the loose pieces, not double-granted here).
# Zero DR (traversal has no luck).

# --- Consolidated step height +0.9 (Greaves +0.5 + Sure-Step +0.4) ---
attribute @s step_height modifier add evercraft:stride_step 0.9 add_value

# --- Consolidated fall damage -15% (Wayfarer's Greaves) ---
attribute @s fall_damage_multiplier modifier add evercraft:stride_fall -0.15 add_multiplied_base

# --- Consolidated +8% movement speed ONLY while sprinting (Sprinter's Anklet) — remove-then-conditional-add
#     so it frees the moment the player stops sprinting or drops the node. ---
attribute @s movement_speed modifier remove evercraft:stride_spd
execute if predicate evercraft:sprinting run attribute @s movement_speed modifier add evercraft:stride_spd 0.08 add_multiplied_base
