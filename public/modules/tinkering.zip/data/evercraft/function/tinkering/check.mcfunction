# ============================================================
# Tinkering (universal mini-line) — Check (is the current quest satisfied?)
# ============================================================
# Reads the current quest's type/target/count/beat and decides whether the active quest
# is complete; if so, calls tinkering/advance. Idempotency-guarded like the C6 check
# (refuses to act when the line is already complete). Run as @s = the player. Cheap;
# called ONLY from the 20t check_progress loop (this line has no per-action engine splice
# — its check types are all READ-DERIVED over held items / bits / tags, so the 20t loop
# catches every satisfied beat with no hot-path edit).
#
# C0 PACING (SCHEMA_DELTA §3): an `interlude` beat (beat:"interlude", count:0) is a
# pure-lore breather that auto-passes. We satisfy it BEFORE the per-type dispatch so the
# macro never has to route a "$(type)" of interlude (no check_type/interlude file needed
# in the dispatch path — a check_type/interlude file exists as a no-op safety net but is
# never reached). A defensive count:0 path also covers a mis-authored interlude.

# --- Existence gate: do nothing unless this player is on the Tinkering line. ---
execute unless score @s ec.tnk_active matches 1.. run return 0
# --- Already finished the whole line? Nothing left to check. ---
execute if score @s ec.tnk_complete matches 1 run return 0

# Make sure tnk_cur holds THIS quest (callers may have run get_quest already, but
# re-loading is cheap and keeps check self-contained / caller-order-proof).
function evercraft:tinkering/get_quest

# Flatten the quest fields the macro compares against.
data modify storage evercraft:tnk_cur o set from storage evercraft:tnk_cur quest

# Snapshot the linear pointer BEFORE dispatch, so advance can detect a re-entrant
# same-tick double-call (idempotency guard, mirrors the C6 upper-bound guard).
execute store result score #tnk_q_before ec.temp run scoreboard players get @s ec.tnk_quest

# Default unsatisfied.
scoreboard players set #tnk_satisfied ec.temp 0

# === C0 INTERLUDE GUARD (BEFORE the per-type dispatch) ===
# A pure-lore beat is instantly satisfied: deliver its lore on advance, pay its tiny
# reward once, step the cursor forward. SCHEMA_DELTA §3.
execute if data storage evercraft:tnk_cur o{beat:"interlude"} run scoreboard players set #tnk_satisfied ec.temp 1
# Defensive: any beat with count:0 is also satisfied (0 >= 0) — covers a non-zero author
# slip where beat was mislabeled but count is 0.
execute if data storage evercraft:tnk_cur o{count:0} run scoreboard players set #tnk_satisfied ec.temp 1

# === PER-TYPE DISPATCH (skipped if the interlude/count:0 guard already fired) ===
execute if score #tnk_satisfied ec.temp matches 0 run function evercraft:tinkering/check_macro with storage evercraft:tnk_cur o

# If satisfied, advance — but only if the pointer hasn't already moved this tick.
execute if score #tnk_satisfied ec.temp matches 1 if score @s ec.tnk_quest = #tnk_q_before ec.temp run function evercraft:tinkering/advance
