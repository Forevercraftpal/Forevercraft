# ============================================================
# Tinkering (universal mini-line) — Reward dispatch (macro body)
# ============================================================
# Called `with storage evercraft:tnk_cur o`, o = the completed quest
#   {...,reward,reward_amt,target,...}. Exposes the reward args to ec.temp / storage and
# routes to reward_type/$(reward). Run as @s = the player.
#
# Shared args the helpers consume:
#   #tnk_reward_amt ec.temp = quest.reward_amt (coins amount / trophy is flag)
#   storage evercraft:tnk_cur o.target = crate tier name (crate) / trophy id (trophy) /
#                                        station id (has_station beat hands the Plinth)
$scoreboard players set #tnk_reward_amt ec.temp $(reward_amt)

# Dispatch on reward type: coins | crate | trophy  (NO xp, NO title — DECISIONS #9).
$function evercraft:tinkering/reward_type/$(reward) with storage evercraft:tnk_cur o
