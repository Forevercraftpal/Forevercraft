# ============================================================
# Tinkering — Workshop Ledger (read-only ✓/✗ checklist, compute-on-open, T6)
# ============================================================
# Run as @s = the player, from tinkering/overview. A pure-reads ✓/✗ card of which fusions
# the player has unlocked/performed — the Tinkering analogue of the housing-hub
# digest_features checklist (round-1 Wave 6). ZERO new objectives, ZERO storage, ZERO writers
# (T6 — mirrors chronicle/overview compute-on-open). Reads the ec.tnk_owned bitfield bits +
# the ec.cf_r10_granted Funnel tag + held station/bundle items. Each ✗ row is honest; no
# clickable link needed (the line beats themselves teach each fusion).
#
# Bit map (ec.tnk_owned): bit0(1) Knot · bit1(2) Band · bit2(4) Hand · bit3(8) Charm.

tellraw @s [{text:"  ⚒ ",color:"#5EC8D8"},{text:"Workshop Ledger",color:"#5EC8D8",bold:true}]

# --- Station: own a Plinth OR a Fusion Funnel ---
scoreboard players set #tnk_l ec.temp 0
execute if entity @s[tag=ec.cf_r10_granted] run scoreboard players set #tnk_l ec.temp 1
execute if items entity @s container.* *[custom_data~{tinker_station:true}] run scoreboard players set #tnk_l ec.temp 1
execute if items entity @s weapon.offhand *[custom_data~{tinker_station:true}] run scoreboard players set #tnk_l ec.temp 1
execute if score #tnk_l ec.temp matches 1 run tellraw @s [{text:"     ✓ ",color:"green",bold:true},{text:"Workshop raised",color:"white"},{text:"  (Plinth or Funnel)",color:"dark_gray"}]
execute if score #tnk_l ec.temp matches 0 run tellraw @s [{text:"     ✗ ",color:"dark_gray",bold:true},{text:"Workshop raised",color:"gray"},{text:"  (get a Plinth or Funnel)",color:"dark_gray"}]

# --- Trinket Knot: ec.tnk_owned bit0 ---
scoreboard players set #tnk_two ec.temp 2
scoreboard players operation #tnk_l ec.temp = @s ec.tnk_owned
scoreboard players operation #tnk_l ec.temp %= #tnk_two ec.temp
execute if score #tnk_l ec.temp matches 1 run tellraw @s [{text:"     ✓ ",color:"green",bold:true},{text:"Trinket Knot",color:"white"},{text:"  (2 trinkets → 1)",color:"dark_gray"}]
execute if score #tnk_l ec.temp matches 0 run tellraw @s [{text:"     ✗ ",color:"dark_gray",bold:true},{text:"Trinket Knot",color:"gray"},{text:"  (toss 2 trinkets on the Plinth)",color:"dark_gray"}]

# --- Band of Rings: ec.tnk_owned bit1 ---
scoreboard players operation #tnk_l ec.temp = @s ec.tnk_owned
scoreboard players operation #tnk_l ec.temp /= #tnk_two ec.temp
scoreboard players operation #tnk_l ec.temp %= #tnk_two ec.temp
execute if score #tnk_l ec.temp matches 1 run tellraw @s [{text:"     ✓ ",color:"green",bold:true},{text:"Band of Rings",color:"white"},{text:"  (Transmute Stand)",color:"dark_gray"}]
execute if score #tnk_l ec.temp matches 0 run tellraw @s [{text:"     ✗ ",color:"dark_gray",bold:true},{text:"Band of Rings",color:"gray"},{text:"  (consolidate rings at the Stand)",color:"dark_gray"}]

# --- Hand of Creation: ec.tnk_owned bit2 ---
scoreboard players set #tnk_four ec.temp 4
scoreboard players operation #tnk_l ec.temp = @s ec.tnk_owned
scoreboard players operation #tnk_l ec.temp /= #tnk_four ec.temp
scoreboard players operation #tnk_l ec.temp %= #tnk_two ec.temp
execute if score #tnk_l ec.temp matches 1 run tellraw @s [{text:"     ✓ ",color:"green",bold:true},{text:"Hand of Creation",color:"white"},{text:"  (6 builder parts)",color:"dark_gray"}]
execute if score #tnk_l ec.temp matches 0 run tellraw @s [{text:"     ✗ ",color:"dark_gray",bold:true},{text:"Hand of Creation",color:"gray"},{text:"  (fold the 6 builder parts)",color:"dark_gray"}]

# --- Band of Charms: ec.tnk_owned bit3 (deferred sub-wave) ---
scoreboard players set #tnk_eight ec.temp 8
scoreboard players operation #tnk_l ec.temp = @s ec.tnk_owned
scoreboard players operation #tnk_l ec.temp /= #tnk_eight ec.temp
scoreboard players operation #tnk_l ec.temp %= #tnk_two ec.temp
execute if score #tnk_l ec.temp matches 1 run tellraw @s [{text:"     ✓ ",color:"green",bold:true},{text:"Band of Charms",color:"white"}]
execute if score #tnk_l ec.temp matches 0 run tellraw @s [{text:"     ◌ ",color:"dark_gray",bold:true},{text:"Band of Charms",color:"gray"},{text:"  (a coming art)",color:"dark_gray"}]
tellraw @s ""
