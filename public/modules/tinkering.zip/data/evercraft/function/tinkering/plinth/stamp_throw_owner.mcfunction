# ============================================================
# Tinkerer's Plinth — Stamp a THROWN item's owner pid (audit #41 P0 fix, 2026-06-06)
# ============================================================
# Run AS + AT an accessory item entity (@s = the item). Resolves the nearest player as the thrower,
# lazily assigns them a tnk_pid if they don't have one yet (same lazy-assign as gui/open:20-22), and
# copies that pid onto the item's ec.tnk_own score. This is the throw-path owner stamp — the GUI path
# stamps ec.tnk_own directly in combine_summon from the known depositor pid.
#
# "Nearest player" is the best throw attribution available (an item rests at the feet of whoever
# tossed it). If NO player is within 8b the stamp is skipped and the item simply never joins a cohort
# until a player is near — it can't be cross-consumed in the meantime.

# Resolve the thrower (nearest player); ensure they have a tnk_pid (lazy assign, mirrors gui/open).
execute unless score #next_tnk_pid ec.var matches 0.. run scoreboard players set #next_tnk_pid ec.var 0
execute as @p[distance=..8] unless score @s ec.tnk_pid matches 1.. run scoreboard players add #next_tnk_pid ec.var 1
execute as @p[distance=..8] unless score @s ec.tnk_pid matches 1.. run scoreboard players operation @s ec.tnk_pid = #next_tnk_pid ec.var

# Copy the thrower's pid onto this item entity's ec.tnk_own (the owner stamp). #tnk_throw_pid stays 0
# if no player is in range (then the stamp is skipped and the item joins no cohort until one is near).
scoreboard players set #tnk_throw_pid ec.temp 0
execute as @p[distance=..8] run scoreboard players operation #tnk_throw_pid ec.temp = @s ec.tnk_pid
execute if score #tnk_throw_pid ec.temp matches 1.. run scoreboard players operation @s ec.tnk_own = #tnk_throw_pid ec.temp
