# ============================================================
# Tinkerer's Plinth — Check single accessory item entity
# ============================================================
# Runs as @s = an accessory:true item entity (selected by tick). OPT: Tag-gate pattern —
# each item only gets NBT-checked once per its lifetime (clone of satchel_forge/check_item:3).
tag @s add ec.tnk_checked

# THE TINKER TABLE IS THE MERGE SURFACE NOW (no beacon — Joseph 2026-06-04). A trinket tossed
# onto (or summoned by the GUI Combine on) the table rests within ~2b of the table's ec.tnk_pl_mk
# marker. Bail unless a table marker is in range; bail if that table already fused THIS tick
# (ec.tnk_busy one-shot latch, set by do_* and cleared at the top of plinth/tick) — that is the
# non-destructive replacement for the old "sacrifice the beacon" guard, so the table is reusable.
execute at @s unless entity @e[type=marker,tag=ec.tnk_pl_mk,distance=..2,limit=1] run return 0
execute at @s if entity @e[type=marker,tag=ec.tnk_pl_mk,tag=ec.tnk_busy,distance=..2,limit=1] run return 0

# === OWNER COHORT (audit #41 P0 fix, 2026-06-06) ===
# Two players can stand at ONE shared table. To stop A's fuse from consuming B's deposits / granting
# to the wrong player, every item is OWNER-stamped (ec.tnk_own = a pid) and the detect/consume chain
# only ever touches the trigger owner's cohort (tagged ec.tnk_mine). The GUI path stamps ec.tnk_own
# in combine_summon (known depositor pid); here we stamp the THROW path's trigger to its nearest
# player, read that pid into #tnk_owner_pid, then mark + (after the chain) clear the cohort. For a
# lone player the whole on-table pool shares one pid -> one cohort -> unchanged behavior.
execute at @s unless score @s ec.tnk_own matches 0.. run function evercraft:tinkering/plinth/stamp_throw_owner
scoreboard players set #tnk_owner_pid ec.temp -1
execute store result score #tnk_owner_pid ec.temp run scoreboard players get @s ec.tnk_own
execute at @s if score #tnk_owner_pid ec.temp matches 0.. run function evercraft:tinkering/plinth/mark_cohort

# Look for a complete ritual set at this position, MOST-SPECIFIC FIRST:
#   • the Hand 6-set (builder parts) FIRST — the most specific fixed set, so a player tossing
#     the six parts gets the Hand, not a Knot or a partial family recipe of them.
#   • the Tinker's Omnitool (Chest-Node §6/A2) — the 4-system-single fuse + the re-attain merge.
#     Fixed multi-id sets, so MORE specific than the generic family rows + the any-2 Knot.
#   • the GENERIC family-recipe registry — the data-driven lattice (Pebble-of-Creation tree,
#     Band-of-All-Rings tree, and every future family). Each row is a fixed multi-id set, so it is
#     MORE specific than the trivial any-2 Knot; LESS specific than the bespoke Hand/Omnitool sets.
#   • the Knot 2-set (any 2 accessories) LAST — the trivial starter.
# Runs the detect chain at the item's position; each detect_* scans ~2b around it for its set.
execute at @s run function evercraft:tinkering/plinth/detect_hand
execute at @s run function evercraft:tinkering/plinth/detect_omnitool
execute at @s run function evercraft:tinkering/plinth/detect
execute at @s run function evercraft:tinkering/plinth/detect_knot

# Clear this fuse's cohort marker (the persistent ec.tnk_own stamps stay) so the next trigger / tick
# starts clean. Safe to run whether or not a fuse fired (no cohort tag survives a no-fuse pass).
execute at @s run function evercraft:tinkering/plinth/clear_cohort

# Clear the transient ec.tnk_actor tag a do_* may have left on the granted player (resolve_actor always
# clears-first, so this is hygiene — no player wears the tag between fusions). Harmless if none is set.
tag @a remove ec.tnk_actor
