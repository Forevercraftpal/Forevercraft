# ============================================================
# Tinkerer's Plinth — Fusion windup: enchantment glyphs gather over the table
# ============================================================
# Run AS/AT the table marker (block corner). Block-center top = ~0.5 ~1 ~0.5. Plays the rising-power
# windup; 10t later fuse_explode detonates the bound power. Aqua/gold Tinkerer palette (#5EC8D8).

# Rising-power chord — enchanting-table glyph hum + conduit charge + beacon select.
playsound minecraft:block.enchantment_table.use master @a[distance=..32,scores={ec.fx_snd=1..}] ~0.5 ~1 ~0.5 1.2 0.8
playsound minecraft:block.conduit.activate master @a[distance=..32,scores={ec.fx_snd=1..}] ~0.5 ~1 ~0.5 0.7 1.5
playsound minecraft:block.beacon.power_select master @a[distance=..32,scores={ec.fx_snd=1..}] ~0.5 ~1 ~0.5 1.0 1.6

# Glyphs fly together from a wide radius onto the table (the enchant particle's gather animation).
particle enchant ~0.5 ~1.4 ~0.5 1.3 0.9 1.3 1.0 120
particle enchant ~0.5 ~1.1 ~0.5 0.9 0.5 0.9 0.6 60
# Aqua->gold focus ring spiralling inward (the Plinth's #5EC8D8 identity warming to gold).
particle dust_color_transition{from_color:[0.37,0.78,0.85],scale:1.7,to_color:[1.0,0.84,0.0]} ~0.5 ~1.15 ~0.5 0.8 0.6 0.8 0.04 40
particle reverse_portal ~0.5 ~1.2 ~0.5 0.5 0.45 0.5 0.06 30

# Latch this table for the scheduled detonation, then BOOM in 10t (gives the glyphs time to gather).
tag @s add ec.tnk_fx
schedule function evercraft:tinkering/plinth/fuse_explode 10t
