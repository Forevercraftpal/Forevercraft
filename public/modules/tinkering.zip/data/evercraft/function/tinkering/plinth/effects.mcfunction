# ============================================================
# Tinkerer's Plinth — Fusion FX dispatcher (glyphs gather -> detonate)
# ============================================================
# Called by every do_* after a successful fusion (run AT the triggering item / GUI combine, which
# sits on the table). Centers the ritual on the Tinker Table itself, then hands off to the windup.
# Joseph 2026-06-04: "enchantment glyphs flying together to combine and make the explode."
#
# Resolve the nearest table marker (block corner) and run the windup AS/AT it, so the glyph-gather
# and the scheduled detonation are perfectly centered on the block — independent of exactly where
# the trinket item came to rest. A placed table always has a marker; if none is in range (defensive)
# the fusion still completed, we just skip the flourish.
execute as @e[type=marker,tag=ec.tnk_pl_mk,distance=..3,limit=1,sort=nearest] at @s run function evercraft:tinkering/plinth/fuse_converge
