# ============================================================
# Tinkerer's Plinth — Resolve the FUSE ACTOR (audit #41 P0 fix, 2026-06-06)
# ============================================================
# Tags the owning player ec.tnk_actor so grants/tp target the player who deposited/threw the inputs,
# NOT @p[distance=..8] (= nearest, which at a shared table can be the WRONG player). The owner pid is
# #tnk_owner_pid ec.temp (set in check_item from the trigger item's ec.tnk_own stamp).
#
# Run from a do_* function (any context). Clears first, then tags the matching player. If no online
# player matches the pid (e.g. the thrower logged off mid-fuse) NO player is tagged and the grant
# blocks simply no-op — the fusion item is still spawned on the ground, so nothing is lost.
tag @a remove ec.tnk_actor
execute as @a if score @s ec.tnk_pid = #tnk_owner_pid ec.temp run tag @s add ec.tnk_actor
