# ============================================================
# Tinkerer's Plinth — GENERIC do: ingredient CONSUME loop (self-recursing)
# ============================================================
# Runs at the triggering accessory item entity, on/above a beacon. Called by plinth/do with
# #tnk_kill_i ec.temp = current ingredient index, #tnk_kill_n = ingredient count. The current
# row is at storage evercraft:tnk_cur recipe. detect_row already confirmed ALL ids are present.
#
# For each ingredient_ids[i]: copy the id into scratch and kill the item entities carrying
# custom_data{artifact:"<id>"} within ~2b (one-way consume, T6 — mirrors do_hand's 6 literal
# kills, parameterized by the row's ids). Then advance + recurse. Bounded by the row's count.

# Stop once every ingredient has been consumed.
execute if score #tnk_kill_i ec.temp >= #tnk_kill_n ec.temp run return 0

# Copy ingredient_ids[i] into scratch (reuse the get-ingredient index-read with the kill index).
execute store result storage evercraft:tnk_cur iidx int 1 run scoreboard players get #tnk_kill_i ec.temp
function evercraft:tinkering/plinth/get_ingredient with storage evercraft:tnk_cur

# Kill the item entities carrying that artifact id within ~2b (macro body — the id is data).
function evercraft:tinkering/plinth/kill_ingredient with storage evercraft:tnk_cur

# Advance + recurse.
scoreboard players add #tnk_kill_i ec.temp 1
function evercraft:tinkering/plinth/consume_loop
