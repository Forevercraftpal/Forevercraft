# Tinker Table — recursively materialise the deposit buffer onto the table as consumable item
# entities. Run AT the table marker (block corner). Macro source = storage evercraft:tnk_gui scratch
# (carries pid). Each summoned item is tagged ec.tnk_deposited (excluded from the passive scan) and
# given a max PickupDelay so it can't be grabbed before the fusion consumes it this same tick.
$execute unless data storage evercraft:tnk_gui bufs.$(pid).items[0] run return 0
$data modify storage evercraft:tnk_gui scratch.item set from storage evercraft:tnk_gui bufs.$(pid).items[0]
summon item ~0.5 ~1.1 ~0.5 {Item:{id:"minecraft:stone",count:1},PickupDelay:32767s,Tags:["ec.tnk_deposited","ec.tnk_dep_new"]}
# Audit #41 P1: scope the just-summoned-entity claim to THIS table (distance=..2 from the marker we
# run AT) so two players' same-tick combines can't stamp each other's stone item server-wide.
data modify entity @e[type=item,tag=ec.tnk_dep_new,distance=..2,limit=1] Item set from storage evercraft:tnk_gui scratch.item
# Audit #41 P0: stamp the OWNER pid onto the materialised entity so the fusion engine's cohort filter
# only ever consumes/grants this depositor's items (mirrors the throw path's ec.tnk_own stamp).
$scoreboard players set @e[type=item,tag=ec.tnk_dep_new,distance=..2,limit=1] ec.tnk_own $(pid)
tag @e[type=item,tag=ec.tnk_dep_new,distance=..2] remove ec.tnk_dep_new
$data remove storage evercraft:tnk_gui bufs.$(pid).items[0]
$execute if data storage evercraft:tnk_gui bufs.$(pid).items[0] run function evercraft:tinkering/plinth/gui/combine_summon with storage evercraft:tnk_gui scratch
