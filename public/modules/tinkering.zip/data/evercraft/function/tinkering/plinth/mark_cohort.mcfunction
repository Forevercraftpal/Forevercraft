# ============================================================
# Tinkerer's Plinth — Mark the OWNER COHORT for this fuse (audit #41 P0 fix, 2026-06-06)
# ============================================================
# Run AT the triggering accessory item entity (@s = the trigger). Caller (check_item) has already
# stamped @s's ec.tnk_own = the owner pid and copied it into #tnk_owner_pid ec.temp.
#
# This marks EVERY fuse-eligible item entity within ~2b that shares the trigger's owner pid with a
# transient ec.tnk_mine tag, so the detect/consume chain only ever sees + eats THIS owner's items.
# Two players at ONE shared table -> two disjoint cohorts; a fuse only consumes its own. The tag is
# cleared by clear_cohort after the detect chain. Single-player: every item carries the lone player's
# pid, so the whole on-table pool is one cohort -> the engine behaves exactly as before.
#
# Items with NO ec.tnk_own yet (never been a trigger this lifetime) are stamped to the nearest player
# here too, so a same-owner sibling that hasn't been individually checked still joins the cohort.

# First clear any stale cohort tag in range (defensive — clear_cohort handles the normal teardown).
tag @e[type=item,tag=ec.tnk_mine,distance=..2] remove ec.tnk_mine

# Lazily stamp any unstamped eligible item in range to its nearest player's pid (best-effort throw
# attribution), so it can be matched into a cohort. Items the GUI summoned already carry ec.tnk_own.
execute as @e[type=item,tag=!ec.tnk_deposited,distance=..2,nbt={Item:{components:{"minecraft:custom_data":{accessory:true}}}}] unless score @s ec.tnk_own matches 0.. at @s run function evercraft:tinkering/plinth/stamp_throw_owner

# Mark the cohort: every eligible item within ..2 whose ec.tnk_own equals the trigger owner's pid.
execute as @e[type=item,distance=..2,nbt={Item:{components:{"minecraft:custom_data":{accessory:true}}}}] if score @s ec.tnk_own = #tnk_owner_pid ec.temp run tag @s add ec.tnk_mine
