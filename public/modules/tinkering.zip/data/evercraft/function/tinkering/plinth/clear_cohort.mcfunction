# ============================================================
# Tinkerer's Plinth — Clear the OWNER COHORT tag after a fuse (audit #41 P0 fix, 2026-06-06)
# ============================================================
# Run AT the triggering accessory item entity (@s). Removes the transient ec.tnk_mine cohort tag from
# every item still in range, so the next trigger (a different owner, or the next tick) starts clean.
# Any surviving cohort item keeps its persistent ec.tnk_own stamp — only the per-fuse marker is wiped.
tag @e[type=item,tag=ec.tnk_mine,distance=..2] remove ec.tnk_mine
