# Tinker Table — recompute the live deposit count + flash it to the player's actionbar.
# Run as: player. (The menu status text stays a static hint; the count lives on the actionbar.)
execute store result storage evercraft:tnk_gui scratch.pid int 1 run scoreboard players get @s ec.tnk_pid
function evercraft:tinkering/plinth/gui/refresh_macro with storage evercraft:tnk_gui scratch
