# ============================================================
# Tinkerer's Plinth — GENERIC do: fusion announcement (macro body)
# ============================================================
# Called `with storage evercraft:tnk_cur recipe` (the current row), AT the altar. Announces the
# fusion with the row's display $(name) + $(color) — the data-driven equivalent of do_knot:60-62
# / do_hand:49-51's hardcoded tellraw + title. "magic" never appears (ancient/potent power only).
$data modify storage evercraft:notify stage.c set value [{text:"Trinkets fold into a ",color:"gray"},{text:"$(name)",color:"$(color)",bold:true},{text:" by ancient power!",color:"gray"}]
scoreboard players set #ndur ec.temp 45
execute as @a[distance=..64] run function evercraft:util/notify/emit
# (AB-1 sticky-times sweep 2026-06-10: explicit stamp — `title times` is sticky per player and this sequence set none, so it inherited whatever ran last.)
title @a[distance=..32] times 10 60 20
$title @a[distance=..32] subtitle [{text:"Power gathered into one slot",color:"$(color)"}]
$title @a[distance=..32] title [{text:"$(name)",color:"$(color)",bold:true}]
