# Tinkerer's Plinth — Raycast forward to find the just-placed lodestone (≤16 blocks, 80 steps@0.2).
# Run anchored eyes, positioned ^ ^ ^offset, as the placing player. Mirrors guidestone/transmute.
scoreboard players add @s ec.tnk_ray 1

# Hit an UNregistered lodestone (no station marker yet) -> set up the Plinth display here.
execute if block ~ ~ ~ minecraft:lodestone unless entity @e[type=marker,tag=ec.lodestone_registered,dx=0,dy=0,dz=0,limit=1] align xyz run function evercraft:tinkering/plinth/setup

# Keep stepping forward while we're in range and haven't hit a lodestone.
execute if score @s ec.tnk_ray matches ..80 unless block ~ ~ ~ minecraft:lodestone positioned ^ ^ ^0.2 run function evercraft:tinkering/plinth/raycast_place

# Step PAST already-registered lodestones (other stations) so we don't stop dead on them.
execute if score @s ec.tnk_ray matches ..80 if block ~ ~ ~ minecraft:lodestone if entity @e[type=marker,tag=ec.lodestone_registered,dx=0,dy=0,dz=0,limit=1] positioned ^ ^ ^0.2 run function evercraft:tinkering/plinth/raycast_place

# Reset the counter when the walk ends without a hit.
execute if score @s ec.tnk_ray matches 81.. run scoreboard players set @s ec.tnk_ray 0
