# Tinker Table — return any of THIS PLAYER's deposited trinkets the fusion left behind (incomplete
# recipe). Run AT the table marker, with #tnk_owner_pid ec.temp = the clicking player's pid (set by
# combine). Each leftover is made collectable and tp'd to its OWNER — lossless, owner-correct (audit
# #41 P0/P1 fix: only the clicker's leftovers, returned to the clicker, never a co-located player's).
execute as @e[type=item,tag=ec.tnk_deposited] if score @s ec.tnk_own = #tnk_owner_pid ec.temp run function evercraft:tinkering/plinth/gui/return_one
