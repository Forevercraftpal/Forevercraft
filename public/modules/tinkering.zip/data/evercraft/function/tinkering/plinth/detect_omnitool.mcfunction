# ============================================================
# Tinkerer's Plinth — TINKER'S OMNITOOL detect (Chest-Node §6 / A2)
# ============================================================
# Runs at the triggering accessory item entity, on/above a beacon. Dispatched from check_item
# AFTER detect_hand and BEFORE the generic family-recipe detect (so the omnitool's fixed sets win
# over the trivial any-2 Knot, and a player tossing the 4 system singles gets the Omnitool — NOT a
# Knot or a partial family row). Handles BOTH omnitool operations:
#
#   (A) MERGE (re-attain): an EXISTING omnitool sits near the beacon AND exactly one system single
#       is also present -> consume that single + increment its per-ability counter on the omnitool
#       (capped 3). This is the §6 "re-attaining a predecessor re-stacks its ability" path.
#   (B) FUSE: all FOUR system singles are present (and NO omnitool) -> consume the 4 + spawn the
#       Omnitool. The first-build path.
#
# MERGE is tested FIRST (more specific: omnitool + a single). One operation per tick (#tnk_omni_hit
# short-circuits). PERF: only reached when an accessory:true item entity already sits on a beacon
# (check_item gated it) — a rare, player-driven event.

# One-operation-per-tick guard.
scoreboard players set #tnk_omni_hit ec.temp 0

# Is an existing Omnitool present near the beacon? (OWNER cohort only — audit #41 P0.)
scoreboard players set #tnk_omni_present ec.temp 0
execute if entity @e[type=item,tag=ec.tnk_mine,distance=..2,nbt={Item:{components:{"minecraft:custom_data":{artifact:"tinkers_omnitool"}}}},limit=1] run scoreboard players set #tnk_omni_present ec.temp 1

# === (A) MERGE — omnitool + exactly one single -> bump that single's counter, consume the single ===
# Each single is checked; the first present single merges (one per tick). Only when an omnitool exists.
# All gates carry tag=ec.tnk_mine so only the trigger owner's omnitool + own single ever merge.
execute if score #tnk_omni_present ec.temp matches 1 if score #tnk_omni_hit ec.temp matches 0 if entity @e[type=item,tag=ec.tnk_mine,distance=..2,nbt={Item:{components:{"minecraft:custom_data":{artifact:"crate_luck_charm"}}}},limit=1] run function evercraft:tinkering/plinth/omni_merge {single:"crate_luck_charm",counter:"crate_lvl"}
execute if score #tnk_omni_present ec.temp matches 1 if score #tnk_omni_hit ec.temp matches 0 if entity @e[type=item,tag=ec.tnk_mine,distance=..2,nbt={Item:{components:{"minecraft:custom_data":{artifact:"prospectors_dowser"}}}},limit=1] run function evercraft:tinkering/plinth/omni_merge {single:"prospectors_dowser",counter:"spawn_lvl"}
execute if score #tnk_omni_present ec.temp matches 1 if score #tnk_omni_hit ec.temp matches 0 if entity @e[type=item,tag=ec.tnk_mine,distance=..2,nbt={Item:{components:{"minecraft:custom_data":{artifact:"master_key_fob"}}}},limit=1] run function evercraft:tinkering/plinth/omni_merge {single:"master_key_fob",counter:"open_lvl"}
execute if score #tnk_omni_present ec.temp matches 1 if score #tnk_omni_hit ec.temp matches 0 if entity @e[type=item,tag=ec.tnk_mine,distance=..2,nbt={Item:{components:{"minecraft:custom_data":{artifact:"pocket_ender_anchor"}}}},limit=1] run function evercraft:tinkering/plinth/omni_merge {single:"pocket_ender_anchor",counter:"ender_lvl"}

# === (B) FUSE — all four singles present (no omnitool, no merge fired) -> build the Omnitool ===
execute if score #tnk_omni_hit ec.temp matches 0 if score #tnk_omni_present ec.temp matches 0 if entity @e[type=item,tag=ec.tnk_mine,distance=..2,nbt={Item:{components:{"minecraft:custom_data":{artifact:"crate_luck_charm"}}}},limit=1] if entity @e[type=item,tag=ec.tnk_mine,distance=..2,nbt={Item:{components:{"minecraft:custom_data":{artifact:"prospectors_dowser"}}}},limit=1] if entity @e[type=item,tag=ec.tnk_mine,distance=..2,nbt={Item:{components:{"minecraft:custom_data":{artifact:"master_key_fob"}}}},limit=1] if entity @e[type=item,tag=ec.tnk_mine,distance=..2,nbt={Item:{components:{"minecraft:custom_data":{artifact:"pocket_ender_anchor"}}}},limit=1] run function evercraft:tinkering/plinth/omni_fuse
