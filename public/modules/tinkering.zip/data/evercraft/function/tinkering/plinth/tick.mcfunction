# ============================================================
# Tinkerer's Plinth — Ritual Tick (every 2s)
# ============================================================
# The Tinker Table altar. Fusions resolve here when a player TOSSES trinkets onto the table
# (no beacon — Joseph 2026-06-04). The detect chain (check_item) covers every set:
#   • Trinket Knot — toss any 2 common accessories on the table -> 1 Knot bundle.
#   • Tinker's Omnitool — the 4 system singles -> the combined spirit-item (+ re-attain merge).
#   • Hand of Creation — the 6 builder parts -> 1 Hand.
#   • the data-driven family lattice (Pebble-of-Creation / Band trees / every future family).
# Ritual detection doesn't need 0.5s precision — 2s is fine for thrown items (they linger ~5min).
# The GUI alternative (right-click the table -> deposit-from-hand -> Combine) funnels into the SAME
# detect chain via gui/combine, so this passive scan and the GUI share one fusion engine.

# Reschedule first (guarantees we keep ticking regardless of gate).
schedule function evercraft:tinkering/plinth/tick 2s

# Clear last cycle's one-shot fusion latch (set by do_* — replaces the beacon sacrifice). Doing it
# BEFORE the gates guarantees the latch never gets stuck if the items/players vanish next tick.
tag @e[type=marker,tag=ec.tnk_busy] remove ec.tnk_busy

# Gate: skip logic if no players online (cheap existence gate).
execute unless entity @a run return 0

# EXISTENCE GATE (perf): no Tinker Table placed -> no ritual possible (a table always carries an
# ec.tnk_pl_mk marker). Mirrors the transmute/tick + bulk_barrel/tick marker-existence gate.
execute unless entity @e[type=marker,tag=ec.tnk_pl_mk,limit=1] run return 0

# EXISTENCE GATE (perf): only do the NBT scan if a thrown accessory OR ring item exists. GUI
# deposits are summoned + consumed atomically inside gui/combine and carry ec.tnk_deposited, so
# they are excluded here — the passive scan only ever sees genuinely-tossed trinkets. Joseph
# 2026-06-13: rings carry ring:true (not accessory:true) so the gate was missing them entirely;
# tossed-ring fusion (Gemband / Wardband / Voidband) silently no-op'd.
execute unless entity @e[type=item,tag=!ec.tnk_deposited,nbt={Item:{components:{"minecraft:custom_data":{accessory:true}}}},limit=1] unless entity @e[type=item,tag=!ec.tnk_deposited,nbt={Item:{components:{"minecraft:custom_data":{ring:true}}}},limit=1] run return 0

# OPT: Tag-gate — only NBT-check unchecked, non-GUI accessory/ring item entities. limit=10 caps
# the per-tick work. check_item resolves the nearest table, gates on its busy latch, then runs
# the most-specific-first detect chain (Hand -> Omnitool -> family registry -> Knot).
execute as @e[type=item,tag=!ec.tnk_checked,tag=!ec.tnk_deposited,nbt={Item:{components:{"minecraft:custom_data":{accessory:true}}}},limit=10] run function evercraft:tinkering/plinth/check_item
execute as @e[type=item,tag=!ec.tnk_checked,tag=!ec.tnk_deposited,nbt={Item:{components:{"minecraft:custom_data":{ring:true}}}},limit=10] run function evercraft:tinkering/plinth/check_item
