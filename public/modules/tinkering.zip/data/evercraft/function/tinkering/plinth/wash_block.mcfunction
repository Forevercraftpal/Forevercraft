# ============================================================
# Tinkerer's Plinth — Wash Block (right-click holding a water bucket)
# Run as: the ec.tnk_int interaction entity, AT the block.
# Called from gui/on_click's recolor intercept (before the workbench opens).
# Removes the persistent data.color and restores the default Tinkerer's Plinth
# head texture (identical byte-for-byte to the temp_skin value in on_place.mcfunction).
# Marker/stand resolved by distance=..2 (per-block, multiplayer-safe).
# ============================================================

# Reset the marker color back to default (clear the stored field).
execute as @e[type=marker,tag=ec.tnk_pl_mk,distance=..2,sort=nearest,limit=1] run data remove entity @s data.color

# Reset the display head to the default Tinkerer's Plinth skin (from on_place.mcfunction).
execute as @e[type=armor_stand,tag=ec.tnk_pl_stand,distance=..2,sort=nearest,limit=1] on passengers run data modify entity @s item.components."minecraft:profile".properties[0].value set value "ewogICJ0aW1lc3RhbXAiIDogMTc4MDUzNTU5NjMzMywKICAicHJvZmlsZUlkIiA6ICI4OGMyOGYwOTY3MjU0NmNkYTg3ZjVhMTc0ODU0MzExYiIsCiAgInByb2ZpbGVOYW1lIiA6ICJOaXRlQ2F2ZSIsCiAgInNpZ25hdHVyZVJlcXVpcmVkIiA6IHRydWUsCiAgInRleHR1cmVzIiA6IHsKICAgICJTS0lOIiA6IHsKICAgICAgInVybCIgOiAiaHR0cDovL3RleHR1cmVzLm1pbmVjcmFmdC5uZXQvdGV4dHVyZS9lOTY3Y2FlYTQ0MGY0MTQwNzIxNTViNmQwOGY2ZjVjMWZmNGUzMDZhNmZlZGFkNmRiYTg0MzFlY2FhMGQyMjE2IgogICAgfQogIH0KfQ=="

# Effects.
playsound minecraft:item.bucket.empty master @a[distance=..16,scores={ec.fx_snd=1..}] ~ ~ ~ 1 1.2
particle minecraft:splash ~0.5 ~1.1 ~0.5 0.3 0.2 0.3 0.05 12

# Feedback.
data modify storage evercraft:notify stage.c set value [{text:"Washed ",color:"gray",italic:true},{text:"Tinkerer's Plinth",color:"#5EC8D8",italic:true},{text:" back to default",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 45
execute as @p[distance=..6] run function evercraft:util/notify/emit
