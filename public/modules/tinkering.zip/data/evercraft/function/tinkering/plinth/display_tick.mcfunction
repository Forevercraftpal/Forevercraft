# Tinkerer's Plinth — Display tick (1s): break-detection + ambient FX for placed Plinths.
# Existence-gated by the `as @e[marker]` selector — costs ~nothing when no Plinth is placed
# (the selector simply matches no entities). Self-reschedules; kicked from tinkering/load
# with `replace` so /reload never stacks duplicate schedules.
schedule function evercraft:tinkering/plinth/display_tick 1s replace
execute as @e[type=marker,tag=ec.tnk_pl_mk] at @s run function evercraft:tinkering/plinth/display_marker

# Drive any open Tinker Table workbench menus — button-click routing + close-on-walk-away. 1s
# cadence matches the transmute stand (interaction click-data lingers, so 1s catches every press).
# Cheap: @a[tag=TNK.InMenu] matches nobody when no menu is open.
execute as @a[tag=TNK.InMenu] at @s run function evercraft:tinkering/plinth/gui/tick
