# Tinker Table — interaction node right-clicked. Run AS/AT the ec.tnk_int interaction entity.
# Consume the click data, then open (toggle) the workbench for the nearest player.
data remove entity @s interaction

# --- Recolor intercept (before the workbench opens) ---
# Resolve the nearest player and read THEIR mainhand (the `as @p` rebinds @s to the
# player, so `entity @s weapon.mainhand` is the player's hand — not the interaction
# entity's). Holding a dye -> recolor; water bucket -> wash. Both `return` so the
# workbench never opens and the dye/bucket flow stops here.
execute as @p[distance=..6] if items entity @s weapon.mainhand #evercraft:dyes run return run function evercraft:tinkering/plinth/dye_block
execute as @p[distance=..6] if items entity @s weapon.mainhand minecraft:water_bucket run return run function evercraft:tinkering/plinth/wash_block

execute as @p[distance=..6] at @s run function evercraft:tinkering/plinth/gui/open
