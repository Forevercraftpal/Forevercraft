# ============================================================
# Tinkerer's Plinth — Do Knot (fuse 2 trinkets -> 1 Trinket Knot)
# ============================================================
# Runs at the triggering accessory item entity, on/above a beacon. detect_knot confirmed >=2
# eligible (non-part, non-bundle, non-station) accessory item entities are present within ~2
# blocks. This consumes EXACTLY TWO of them, captures their artifact ids into the spawned
# Knot's custom_data (so player_tick can re-apply the union of their two effects — T4), and
# spawns one Trinket Knot. BALANCE-NEUTRAL (DECISIONS #9 / R14): the two trinkets already
# both applied while held; the Knot only frees a slot.
#
# ONE-SHOT GUARD (T8, clone of satchel_forge/do_merge:9-10): sacrifice the beacon FIRST so a
# second queued accessory item's check_item block-test fails — the ritual fires once.

# === 1) ONE-SHOT GUARD: latch the table busy for this tick (NO block destroyed — Joseph 2026-06-04) ===
# Tag the nearest Tinker Table marker ec.tnk_busy so a second queued accessory item in this same
# scan loop fails check_item's busy gate. Cleared at the top of plinth/tick next cycle — the table
# stays standing and is reusable (replaces the old "sacrifice the beacon" guard).
tag @e[type=marker,tag=ec.tnk_pl_mk,distance=..2,limit=1,sort=nearest] add ec.tnk_busy

# === 2) CAPTURE the two trinket ids into storage (knot bound sub-trinkets) — BEFORE any kill ===
# Reset the scratch so a stale id never leaks across rituals. knot_a = the triggering item's
# OWN artifact id (@s is an eligible trinket on the table). knot_b = the nearest OTHER eligible
# accessory item entity. We exclude @s by a TEMP TAG (ec.tnk_knot_self), NOT by a distance floor:
# the GUI Combine summons every deposited trinket at the SAME coordinate, so the old distance=0.01..
# floor wrongly excluded the co-located second trinket (it sat at distance 0) and left knot_b
# "unknown" — half the union. The tag-exclusion works whether the items are spread (throw-path) or
# stacked (GUI-path). A held accessory's custom_data carries `artifact:"<id>"`; we copy it so
# player_tick can re-apply the union of the two effects (T4). (A bare ring:true item with no
# `artifact` key copies as a no-op and the default "unknown" stays, which knot_apply safely ignores.)
data modify storage evercraft:tnk_cur knot set value {a:"unknown",b:"unknown"}
data modify storage evercraft:tnk_cur knot.a set from entity @s Item.components."minecraft:custom_data".artifact
tag @s add ec.tnk_knot_self
execute as @e[type=item,tag=ec.tnk_mine,tag=!ec.tnk_knot_self,distance=..2,nbt={Item:{components:{"minecraft:custom_data":{accessory:true}}}},limit=1,sort=nearest] run data modify storage evercraft:tnk_cur knot.b set from entity @s Item.components."minecraft:custom_data".artifact
tag @s remove ec.tnk_knot_self

# === 3) CONSUME exactly the two nearest eligible trinkets ===
# Kill the trigger item (@s) FIRST, then the next-nearest eligible accessory item (now nearest
# after @s is gone). distance=..2; bundles / the station item / builder parts are NOT
# accessory:true-only excluded here — but in practice detect_hand already claims a full
# part-set first, and a lone partial part is harmless to knot. Exactly two items are consumed.
kill @s
kill @e[type=item,tag=ec.tnk_mine,distance=..2,nbt={Item:{components:{"minecraft:custom_data":{accessory:true}}}},limit=1,sort=nearest]

# === 4) SPAWN the Trinket Knot + STAMP its two bound sub-trinket ids ===
loot spawn ~ ~1 ~ loot evercraft:tinkering/trinket_knot
# Stamp knot_a / knot_b onto the freshly-spawned Knot item entity (nearest tinker_knot item).
execute as @e[type=item,distance=..2,nbt={Item:{components:{"minecraft:custom_data":{tinker_knot:true}}}},limit=1,sort=nearest] run data modify entity @s Item.components."minecraft:custom_data".knot_a set from storage evercraft:tnk_cur knot.a
execute as @e[type=item,distance=..2,nbt={Item:{components:{"minecraft:custom_data":{tinker_knot:true}}}},limit=1,sort=nearest] run data modify entity @s Item.components."minecraft:custom_data".knot_b set from storage evercraft:tnk_cur knot.b

# === 5) LIGHT the ever-fused latch (safe-OR bit0) for the FUSE ACTOR ===
# ec.tnk_owned bit0 (value 1) = "has knotted". Safe-OR: only add the bit if it isn't set. Awarded to
# the OWNER (audit #41 P0 fix): the player who deposited/threw the trinkets, resolved by pid via
# resolve_actor — NOT @p[nearest], which at a shared table could credit the wrong player. This is the
# writer that lets the fused_any beat (q4) auto-satisfy. (bit0 set => values 1,3,5,7,9,11,13,15
# already have it — only add when the bit is clear.)
function evercraft:tinkering/plinth/resolve_actor
execute as @a[tag=ec.tnk_actor,distance=..8] if score @s ec.tnk_owned matches 0 run scoreboard players add @s ec.tnk_owned 1
execute as @a[tag=ec.tnk_actor,distance=..8] if score @s ec.tnk_owned matches 2 run scoreboard players add @s ec.tnk_owned 1
execute as @a[tag=ec.tnk_actor,distance=..8] if score @s ec.tnk_owned matches 4 run scoreboard players add @s ec.tnk_owned 1
execute as @a[tag=ec.tnk_actor,distance=..8] if score @s ec.tnk_owned matches 6 run scoreboard players add @s ec.tnk_owned 1
execute as @a[tag=ec.tnk_actor,distance=..8] if score @s ec.tnk_owned matches 8 run scoreboard players add @s ec.tnk_owned 1
execute as @a[tag=ec.tnk_actor,distance=..8] if score @s ec.tnk_owned matches 10 run scoreboard players add @s ec.tnk_owned 1
execute as @a[tag=ec.tnk_actor,distance=..8] if score @s ec.tnk_owned matches 12 run scoreboard players add @s ec.tnk_owned 1
execute as @a[tag=ec.tnk_actor,distance=..8] if score @s ec.tnk_owned matches 14 run scoreboard players add @s ec.tnk_owned 1

# === 6) EFFECTS + ANNOUNCEMENT ===
function evercraft:tinkering/plinth/effects
data modify storage evercraft:notify stage.c set value [{text:"Two trinkets knot into a ",color:"gray"},{text:"Trinket Knot",color:"#5EC8D8",bold:true},{text:" by ancient power!",color:"gray"}]
scoreboard players set #ndur ec.temp 45
execute as @a[distance=..64] run function evercraft:util/notify/emit
# (AB-1 sticky-times sweep 2026-06-10: explicit stamp — `title times` is sticky per player and this sequence set none, so it inherited whatever ran last.)
title @a[distance=..32] times 10 60 20
title @a[distance=..32] subtitle [{text:"Power in fewer slots",color:"#5EC8D8"}]
title @a[distance=..32] title [{text:"Trinket Knot",color:"#5EC8D8"}]
