# ============================================================
# Tinkerer's Plinth — Dye Block (right-click holding a dye)
# Run as: the ec.tnk_int interaction entity, AT the block.
# Called from gui/on_click's recolor intercept (before the workbench opens).
# Detects the held dye via the shared dyeing/detect_color mapper, then sets
# the marker's persistent data.color AND live-swaps the display head's
# texture value. Marker/stand resolved by distance=..2 (per-block, MP-safe).
# Texture values inlined from _council/2026-06-04-station-color-variants.
# ============================================================

# Detect which dye the player is holding (writes evercraft:dyeing color_id/name).
execute as @p[distance=..6] run function evercraft:dyeing/detect_color

# Azure
execute if data storage evercraft:dyeing {color_id:"azure"} as @e[type=marker,tag=ec.tnk_pl_mk,distance=..2,sort=nearest,limit=1] run data modify entity @s data.color set value "azure"
execute if data storage evercraft:dyeing {color_id:"azure"} as @e[type=armor_stand,tag=ec.tnk_pl_stand,distance=..2,sort=nearest,limit=1] on passengers run data modify entity @s item.components."minecraft:profile".properties[0].value set value "ewogICJ0aW1lc3RhbXAiIDogMTc4MDU0OTk0NTM3OCwKICAicHJvZmlsZUlkIiA6ICI1MTAwZGZmZDI0NDI0M2I0OGQxMmVkZTVkMjgxMzk2ZSIsCiAgInByb2ZpbGVOYW1lIiA6ICJFbGVjdHJvbmljU2V4IiwKICAic2lnbmF0dXJlUmVxdWlyZWQiIDogdHJ1ZSwKICAidGV4dHVyZXMiIDogewogICAgIlNLSU4iIDogewogICAgICAidXJsIiA6ICJodHRwOi8vdGV4dHVyZXMubWluZWNyYWZ0Lm5ldC90ZXh0dXJlLzM1ZWQyMGJlYWFhMzNlZjJjNDQ2YzU3ZTBiODVhYTU0ZjY5Y2VmNjMzNGVlODdlNmIwYTE2NjFiZDA4ZDQwZTMiCiAgICB9CiAgfQp9"

# Crimson
execute if data storage evercraft:dyeing {color_id:"crimson"} as @e[type=marker,tag=ec.tnk_pl_mk,distance=..2,sort=nearest,limit=1] run data modify entity @s data.color set value "crimson"
execute if data storage evercraft:dyeing {color_id:"crimson"} as @e[type=armor_stand,tag=ec.tnk_pl_stand,distance=..2,sort=nearest,limit=1] on passengers run data modify entity @s item.components."minecraft:profile".properties[0].value set value "ewogICJ0aW1lc3RhbXAiIDogMTc4MDU0OTk1Njc5NiwKICAicHJvZmlsZUlkIiA6ICI1ODVjOTI5NzY4NDg0N2VlYjk2MDc1MmVhMDJjOTY5ZCIsCiAgInByb2ZpbGVOYW1lIiA6ICJSZWRBSVNreWUiLAogICJzaWduYXR1cmVSZXF1aXJlZCIgOiB0cnVlLAogICJ0ZXh0dXJlcyIgOiB7CiAgICAiU0tJTiIgOiB7CiAgICAgICJ1cmwiIDogImh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvOGI4YmQwMzE5YjNhZmJmZGE0ZDE0NmYzM2M3ZTRmMWE3MjFiOTBjMmVjODQwNTZhOTcwMTI0ZWNhNzkwMWI1NyIKICAgIH0KICB9Cn0="

# Solar
execute if data storage evercraft:dyeing {color_id:"solar"} as @e[type=marker,tag=ec.tnk_pl_mk,distance=..2,sort=nearest,limit=1] run data modify entity @s data.color set value "solar"
execute if data storage evercraft:dyeing {color_id:"solar"} as @e[type=armor_stand,tag=ec.tnk_pl_stand,distance=..2,sort=nearest,limit=1] on passengers run data modify entity @s item.components."minecraft:profile".properties[0].value set value "ewogICJ0aW1lc3RhbXAiIDogMTc4MDU0OTk2ODgxNSwKICAicHJvZmlsZUlkIiA6ICIwNTljODIxYzhhODU0NGJiOWJiODVhOGMxNjVhYTc5YiIsCiAgInByb2ZpbGVOYW1lIiA6ICJoZWxsc3RydWNrZWR6IiwKICAic2lnbmF0dXJlUmVxdWlyZWQiIDogdHJ1ZSwKICAidGV4dHVyZXMiIDogewogICAgIlNLSU4iIDogewogICAgICAidXJsIiA6ICJodHRwOi8vdGV4dHVyZXMubWluZWNyYWZ0Lm5ldC90ZXh0dXJlLzlmMGZiZGVmY2U2YThkY2VmMDBjZmNiMDkyNzBhODE1MjVmMTQyMDYyMmIxZWMzYjFhZGFlNGI0OWQ0Yzk1MGQiCiAgICB9CiAgfQp9"

# Verdant
execute if data storage evercraft:dyeing {color_id:"verdant"} as @e[type=marker,tag=ec.tnk_pl_mk,distance=..2,sort=nearest,limit=1] run data modify entity @s data.color set value "verdant"
execute if data storage evercraft:dyeing {color_id:"verdant"} as @e[type=armor_stand,tag=ec.tnk_pl_stand,distance=..2,sort=nearest,limit=1] on passengers run data modify entity @s item.components."minecraft:profile".properties[0].value set value "ewogICJ0aW1lc3RhbXAiIDogMTc4MDU0OTk3OTg2MCwKICAicHJvZmlsZUlkIiA6ICI5ZjJiY2M1M2U4YzM0OTY4YTc5Yzc0NTExYWQ2NmQyYyIsCiAgInByb2ZpbGVOYW1lIiA6ICJLYWJveWlvIiwKICAic2lnbmF0dXJlUmVxdWlyZWQiIDogdHJ1ZSwKICAidGV4dHVyZXMiIDogewogICAgIlNLSU4iIDogewogICAgICAidXJsIiA6ICJodHRwOi8vdGV4dHVyZXMubWluZWNyYWZ0Lm5ldC90ZXh0dXJlLzU4MTQ0OGNkNDY2YTU0OTczOWJhNmMwZmZjNGZmODBlNjdlOWUyNDg2MzBjNjA0ZjJjZDg2OTFkOTY2N2VlNzYiCiAgICB9CiAgfQp9"

# Ivory
execute if data storage evercraft:dyeing {color_id:"ivory"} as @e[type=marker,tag=ec.tnk_pl_mk,distance=..2,sort=nearest,limit=1] run data modify entity @s data.color set value "ivory"
execute if data storage evercraft:dyeing {color_id:"ivory"} as @e[type=armor_stand,tag=ec.tnk_pl_stand,distance=..2,sort=nearest,limit=1] on passengers run data modify entity @s item.components."minecraft:profile".properties[0].value set value "ewogICJ0aW1lc3RhbXAiIDogMTc4MDU0OTk5MjYyNSwKICAicHJvZmlsZUlkIiA6ICJmNzM0MmExODMxZDA0ZDA5ODc4Y2ViOTVmOTUxYTllMSIsCiAgInByb2ZpbGVOYW1lIiA6ICJOb3RNMWtzIiwKICAic2lnbmF0dXJlUmVxdWlyZWQiIDogdHJ1ZSwKICAidGV4dHVyZXMiIDogewogICAgIlNLSU4iIDogewogICAgICAidXJsIiA6ICJodHRwOi8vdGV4dHVyZXMubWluZWNyYWZ0Lm5ldC90ZXh0dXJlLzgxMGZmNTlmM2JjYzBiOTljZmZlODgwZThkZjU5ZDE2YmM5NzljYzljOTg0OTk5NDhhODNjYmI2MDQyYzJjMDkiCiAgICB9CiAgfQp9"

# Obsidian
execute if data storage evercraft:dyeing {color_id:"obsidian"} as @e[type=marker,tag=ec.tnk_pl_mk,distance=..2,sort=nearest,limit=1] run data modify entity @s data.color set value "obsidian"
execute if data storage evercraft:dyeing {color_id:"obsidian"} as @e[type=armor_stand,tag=ec.tnk_pl_stand,distance=..2,sort=nearest,limit=1] on passengers run data modify entity @s item.components."minecraft:profile".properties[0].value set value "ewogICJ0aW1lc3RhbXAiIDogMTc4MDU1MDAwNDI0NSwKICAicHJvZmlsZUlkIiA6ICI0MjJlMzdiNjc4ZGU0OTA2YWFiMWU5NGY0N2E5NGM0OSIsCiAgInByb2ZpbGVOYW1lIiA6ICJzcGlmZnRvcGlhOSIsCiAgInNpZ25hdHVyZVJlcXVpcmVkIiA6IHRydWUsCiAgInRleHR1cmVzIiA6IHsKICAgICJTS0lOIiA6IHsKICAgICAgInVybCIgOiAiaHR0cDovL3RleHR1cmVzLm1pbmVjcmFmdC5uZXQvdGV4dHVyZS80ZWIzYzAyYTM3NzU2NzJlMTk2ZDJjZDIxOGMzMTI3ODcyMTgzMDAzNmRmMzllOWI5OWU1OTY2NDdhZWY3YmMwIgogICAgfQogIH0KfQ=="

# Rose
execute if data storage evercraft:dyeing {color_id:"rose"} as @e[type=marker,tag=ec.tnk_pl_mk,distance=..2,sort=nearest,limit=1] run data modify entity @s data.color set value "rose"
execute if data storage evercraft:dyeing {color_id:"rose"} as @e[type=armor_stand,tag=ec.tnk_pl_stand,distance=..2,sort=nearest,limit=1] on passengers run data modify entity @s item.components."minecraft:profile".properties[0].value set value "ewogICJ0aW1lc3RhbXAiIDogMTc4MDU1MDAxNjA2MywKICAicHJvZmlsZUlkIiA6ICI0YWU5MTM5MzZhOGU0MWU0YWNlMTYyYjI4YmM0MzMwMyIsCiAgInByb2ZpbGVOYW1lIiA6ICJ6ZXJ2YXRpb24iLAogICJzaWduYXR1cmVSZXF1aXJlZCIgOiB0cnVlLAogICJ0ZXh0dXJlcyIgOiB7CiAgICAiU0tJTiIgOiB7CiAgICAgICJ1cmwiIDogImh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvYmI5NTBhZWJlNjFiNjc2NGNhZGIyN2Q2ZjY0NDYyOWIxODE1MDZmZjZhOGYyZGQxODNhMDRkNThmNDE5Y2MxNCIKICAgIH0KICB9Cn0="

# Noir
execute if data storage evercraft:dyeing {color_id:"noir"} as @e[type=marker,tag=ec.tnk_pl_mk,distance=..2,sort=nearest,limit=1] run data modify entity @s data.color set value "noir"
execute if data storage evercraft:dyeing {color_id:"noir"} as @e[type=armor_stand,tag=ec.tnk_pl_stand,distance=..2,sort=nearest,limit=1] on passengers run data modify entity @s item.components."minecraft:profile".properties[0].value set value "ewogICJ0aW1lc3RhbXAiIDogMTc4MDU1MDAyOTQxNiwKICAicHJvZmlsZUlkIiA6ICJjODVhZTlmOWJkNTU0YzFmYjk1ZTg3ZDI2Zjg2MGFmNiIsCiAgInByb2ZpbGVOYW1lIiA6ICJTdGV2ZW4xNzUzIiwKICAic2lnbmF0dXJlUmVxdWlyZWQiIDogdHJ1ZSwKICAidGV4dHVyZXMiIDogewogICAgIlNLSU4iIDogewogICAgICAidXJsIiA6ICJodHRwOi8vdGV4dHVyZXMubWluZWNyYWZ0Lm5ldC90ZXh0dXJlLzc4OGJmZjk0Njc5ZGE4Yzg5ZWNhZTYxZWQ0YmI0MGZkYmExYTU0MGZiNjljMDgzNDliYjFkM2JmM2I5MTkzNjIiCiAgICB9CiAgfQp9"

# Consume 1 dye from the player's main hand (guidestone idiom).
execute as @p[distance=..6] run item modify entity @s weapon.mainhand {"function":"minecraft:set_count","count":-1,"add":true}

# Effects (sound + dye particles at the block).
function evercraft:dyeing/effects

# Feedback — name the color via the shared color_name field.
data modify storage evercraft:notify stage.c set value [{text:"Dyed ",color:"gray",italic:true},{storage:"evercraft:dyeing",nbt:"color_name",interpret:false,color:"#5EC8D8",italic:true},{text:" Tinkerer's Plinth",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 45
execute as @p[distance=..6] run function evercraft:util/notify/emit
