# Tinker Table — store the buffer length into ec.tnk_dep + actionbar it. Macro: $(pid). @s = player.
$execute store result score @s ec.tnk_dep run data get storage evercraft:tnk_gui bufs.$(pid).items
data modify storage evercraft:notify stage.c set value [{text:"⚙ ",color:"#5EC8D8"},{text:"Trinkets on the table: ",color:"gray"},{score:{name:"@s",objective:"ec.tnk_dep"},color:"#5EC8D8"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
