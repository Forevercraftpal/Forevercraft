# Tinker Table — return the unspent deposit buffer to the player (cancel/close path). Run AS/AT the
# player. Recursively pops each buffered item and drops it AT the player with PickupDelay 0 (instant
# collect). Macro source = storage evercraft:tnk_gui scratch (carries pid).
$execute unless data storage evercraft:tnk_gui bufs.$(pid).items[0] run return 0
$data modify storage evercraft:tnk_gui scratch.item set from storage evercraft:tnk_gui bufs.$(pid).items[0]
summon item ~ ~0.3 ~ {Item:{id:"minecraft:stone",count:1},PickupDelay:0s,Tags:["ec.tnk_gb_new"]}
data modify entity @e[type=item,tag=ec.tnk_gb_new,limit=1] Item set from storage evercraft:tnk_gui scratch.item
tag @e[type=item,tag=ec.tnk_gb_new] remove ec.tnk_gb_new
$data remove storage evercraft:tnk_gui bufs.$(pid).items[0]
$execute if data storage evercraft:tnk_gui bufs.$(pid).items[0] run function evercraft:tinkering/plinth/gui/giveback with storage evercraft:tnk_gui scratch
