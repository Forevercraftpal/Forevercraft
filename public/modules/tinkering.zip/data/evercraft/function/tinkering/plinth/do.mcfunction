# ============================================================
# Tinkerer's Plinth — GENERIC registry-driven do (data-driven fusion, Wave-1 Foundation)
# ============================================================
# Runs at the triggering accessory item entity, on/above a beacon. detect_row confirmed ALL of
# the current row's ingredient_ids are present within ~2b. The current row is at storage
# evercraft:tnk_cur recipe. This consumes the ingredients, spawns the row's capstone loot,
# stamps the result's flag, OR-sets the family latch bit, and announces — ALL FROM ROW DATA.
# (Generic clone of do_hand's consume->spawn->latch->announce shape, parameterized by the row.)
#
# BALANCE: Wave-1 fusions are free (no cost charged — `cost` is recorded for a future gate). The
# consolidated luck (the ascension headline) is applied by the apply-units (Unit 2 Pebble / Unit
# 3 Band) reading the spawned result's flag — this engine only spawns the correctly-flagged item.
#
# ONE-SHOT GUARD (T8, clone of do_knot/do_hand:14-16): sacrifice the beacon FIRST so a second
# queued accessory item's check_item block-test fails — the ritual fires once.

# === 1) ONE-SHOT GUARD: latch the table busy for this tick (NO block destroyed — Joseph 2026-06-04) ===
# Tag the nearest Tinker Table marker ec.tnk_busy so a second queued accessory item in this same
# scan loop fails check_item's busy gate and can't re-fire on this table. Cleared at the top of
# plinth/tick next cycle, so the table stays standing and is reusable (replaces the beacon sacrifice).
tag @e[type=marker,tag=ec.tnk_pl_mk,distance=..2,limit=1,sort=nearest] add ec.tnk_busy

# === 2) CONSUME the row's ingredients (kill each ingredient_ids[i] within ~2b) ===
# Reuse the ingredient list: a self-recursing kill loop, mirroring the consume step but
# parameterized by the row's ids (do_hand kills its 6 literal ids; we kill the row's ids).
execute store result score #tnk_kill_n ec.temp run data get storage evercraft:tnk_cur recipe.ingredient_ids
scoreboard players set #tnk_kill_i ec.temp 0
function evercraft:tinkering/plinth/consume_loop

# === 3) SPAWN the row's capstone loot table (data-driven) ===
# The loot path is row data; spawn it one block above the altar (mirrors do_knot/do_hand:39).
function evercraft:tinkering/plinth/spawn_capstone with storage evercraft:tnk_cur recipe

# === 4) STAMP the result flag + bound ingredient list onto the spawned item ===
# Set custom_data.<flag>=true and bound_ids=<the consumed ids> onto the nearest matching result
# item, so the apply-unit's union read + the Almanac can reconstruct what was fused (T4).
function evercraft:tinkering/plinth/stamp_result with storage evercraft:tnk_cur recipe

# === 5) LIGHT the ever-fused family latch (safe-OR the row's bit VALUE) for the NEAREST player ===
# The row's `bit` field is the ec.tnk_owned VALUE to OR-set (the documented safe-OR bitfield:
# 1 Knot / 2 Band / 4 Hand / 8 Charm — REUSED, no new bit). bit:0 = a sub-binding or a capstone
# with no pre-assigned bit (no latch). The ONLY Wave-1 row that latches is the Band-15 grand
# (bit:2 = the Band slot); the helper safe-ORs value 2 (re-grant is a no-op). Adding a future
# row that latches a different existing bit = add its dispatch line here (still no NEW objective).
execute store result score #tnk_do_bit ec.temp run data get storage evercraft:tnk_cur recipe.bit
execute if score #tnk_do_bit ec.temp matches 2 run function evercraft:tinkering/plinth/latch_band

# === 6) EFFECTS + ANNOUNCEMENT (data-driven name + color) ===
function evercraft:tinkering/plinth/effects
function evercraft:tinkering/plinth/announce with storage evercraft:tnk_cur recipe

# === 7) GEARWRIGHT XP (Joseph 2026-06-06) — a Plinth fusion is a master tinkering act. Credit the
# actual FUSER (resolve_actor tags ec.tnk_actor by pid, like latch_band — never @p[nearest], audit #41):
# T4 craft-XP (+7) every fusion + a first-time-fusing-THIS-artifact bonus (+25). $(flag) = the artifact id.
function evercraft:tinkering/plinth/resolve_actor
execute as @a[tag=ec.tnk_actor,distance=..8] run function evercraft:craft_affinity/on_fuse with storage evercraft:tnk_cur recipe

# === 8) LIVING BOUGH — GEARWRIGHT BOUGH HOOKS (Wave 11) ===
# 8a) Publish the slot-reveal level fresh at every fusion (sole writer = the recompute helper).
#     This is what keeps ec.gw_slot_reveal honest for C2/C7/C9 owners who never wear the Crown
#     (crown_apply reconciles Crown owners each second; everyone else syncs here, at the only
#     moment the value matters). First consumer LIVE (Wave 33): the at-plinth particle cue —
#     bough/gearwright/slot_reveal_visual_tick; per-slot GUI render still future (see crown_apply).
execute as @a[tag=ec.tnk_actor,distance=..8] run function evercraft:bough/gearwright/slot_reveal_recompute
# 8b) C12 Forgemaster (crown-independent node hook, Wave 9 convention): completing a 5+-component
#     fusion grants +1 Iron Resonance — +1 Mythril INSTEAD in End/Nether. Component count re-read
#     from recipe.ingredient_ids (storage tnk_cur is still intact here — announce/on_fuse just used
#     it; #tnk_kill_n from step 2 is NOT trusted across the scratch churn in steps 3-6). Silent
#     grant, the Wave 10 Strikemaster precedent (the fusion announce is the celebration).
execute store result score #gw_c12n ec.temp run data get storage evercraft:tnk_cur recipe.ingredient_ids
execute as @a[tag=ec.tnk_actor,distance=..8,scores={ec.gw_n_c12=1..}] at @s if score #gw_c12n ec.temp matches 5.. unless predicate evercraft:in_nether unless predicate evercraft:in_end run function evercraft:bough/mastery/find_xp {cls:"gw",amount:200}
execute as @a[tag=ec.tnk_actor,distance=..8,scores={ec.gw_n_c12=1..}] at @s if score #gw_c12n ec.temp matches 5.. if predicate evercraft:in_nether run function evercraft:bough/mastery/find_xp {cls:"gw",amount:200}
execute as @a[tag=ec.tnk_actor,distance=..8,scores={ec.gw_n_c12=1..}] at @s if score #gw_c12n ec.temp matches 5.. if predicate evercraft:in_end run function evercraft:bough/mastery/find_xp {cls:"gw",amount:200}
