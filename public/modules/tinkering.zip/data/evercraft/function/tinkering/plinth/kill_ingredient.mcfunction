# ============================================================
# Tinkerer's Plinth — GENERIC do: kill ONE ingredient's item entities (macro body)
# ============================================================
# Called `with storage evercraft:tnk_cur` where tnk_cur = {ing:"<id>"}, AT the triggering
# accessory item entity (on/above the beacon). Consumes (kills) every item entity matching this
# ingredient id within ~2 blocks — the one-way fusion consume (T6). Matches BOTH id forms (the
# bare {<id>:true} flag AND the {artifact:"<id>"} accessory id), mirroring test_ingredient, so a
# bag-base ingredient (hero_satchel, sub-bindings) and a leaf (artifact-only) are both consumed.
# Killing both forms is safe: a leaf has only the artifact form (the flag kill is a no-op), the
# satchel has only the flag form (the artifact kill is a no-op), an intermediate carries both and
# the second kill simply finds nothing left. (Data-driven equivalent of a do_hand kill line.)
# Audit #41 P0: tag=ec.tnk_mine keeps the one-way consume to the TRIGGER OWNER's items only.
$kill @e[type=item,tag=ec.tnk_mine,distance=..2,nbt={Item:{components:{"minecraft:custom_data":{"$(ing)":true}}}}]
$kill @e[type=item,tag=ec.tnk_mine,distance=..2,nbt={Item:{components:{"minecraft:custom_data":{artifact:"$(ing)"}}}}]
