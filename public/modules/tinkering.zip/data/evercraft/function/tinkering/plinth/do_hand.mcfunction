# ============================================================
# Tinkerer's Plinth — Do Hand-of-Creation merge (re-homed from round-1, T2)
# ============================================================
# Runs at the triggering accessory item entity, on/above a beacon. detect_hand confirmed all
# SIX builder parts are present within ~2 blocks. Consume the 6 parts, sacrifice the beacon,
# and spawn one Hand of Creation. BALANCE-NEUTRAL (R14): the six parts already all applied
# while held; the Hand only frees five slots.
#
# OWNERSHIP SPLIT (T2): round-1's fusion seat owns the part contract (custom_data{accessory:
# true, build_part:"<id>"}); THIS seat owns the Plinth station + this detect/do chain (re-homed
# onto the shared altar). NOTE: until round-1 Wave 7 lands, the SIX builder PARTS do NOT exist,
# so detect_hand's 6-gate `if entity` chain NEVER passes — this fn is a safe no-op (no part
# items can be tossed). It is shipped now so the Plinth recognizes the Hand 6-set the moment
# the parts exist. The C8 wiring repoints this to round-1's canonical Hand loot table once it
# ships (evercraft:hand_of_creation/hand_of_creation). Until then we spawn a tinkering-owned
# placeholder Hand bundle (evercraft:tinkering/hand_of_creation) so the loot reference RESOLVES
# at pack load (a `loot spawn` to a missing table is a load error). The bit2 OR-set below is
# live now; the spawn-line repoint is the only C8 change here.
#
# ONE-SHOT GUARD (T8): latch the table busy for this tick — NO block destroyed (Joseph 2026-06-04).

# === 1) ONE-SHOT GUARD: latch the table busy for this tick (replaces the beacon sacrifice) ===
# Tag the nearest Tinker Table marker ec.tnk_busy so a second queued item fails check_item's busy
# gate. Cleared at the top of plinth/tick next cycle — the table stays standing and is reusable.
tag @e[type=marker,tag=ec.tnk_pl_mk,distance=..2,limit=1,sort=nearest] add ec.tnk_busy

# === 2) CONSUME the six parts (distance=..2, all copies of each id, OWNER cohort only — audit #41) ===
kill @e[type=item,tag=ec.tnk_mine,distance=..2,nbt={Item:{components:{"minecraft:custom_data":{build_part:"reach"}}}}]
kill @e[type=item,tag=ec.tnk_mine,distance=..2,nbt={Item:{components:{"minecraft:custom_data":{build_part:"refund"}}}}]
kill @e[type=item,tag=ec.tnk_mine,distance=..2,nbt={Item:{components:{"minecraft:custom_data":{build_part:"scaffold"}}}}]
kill @e[type=item,tag=ec.tnk_mine,distance=..2,nbt={Item:{components:{"minecraft:custom_data":{build_part:"palette"}}}}]
kill @e[type=item,tag=ec.tnk_mine,distance=..2,nbt={Item:{components:{"minecraft:custom_data":{build_part:"steady"}}}}]
kill @e[type=item,tag=ec.tnk_mine,distance=..2,nbt={Item:{components:{"minecraft:custom_data":{build_part:"level"}}}}]

# === 3) SPAWN the Hand of Creation (round-1's canonical W7 loot table; T2) ===
# C8 repointed this from the tinkering-owned placeholder (evercraft:tinkering/hand_of_creation)
# to round-1 Wave 7's canonical Hand table now that it ships. Both tables carry the same
# {accessory:true, hand_of_creation:true} flags the perk-read (hand_of_creation/hand_apply)
# keys on, so the re-point is item-shape-compatible.
loot spawn ~ ~1 ~ loot evercraft:hand_of_creation/hand_of_creation

# === 4) LIGHT the ever-fused latch (safe-OR bit2 = value 4) for the FUSE ACTOR ===
# ec.tnk_owned bit2 = "has forged a Hand". Safe-OR: only add 4 if the bit is clear (values
# without bit2: 0,1,2,3,8,9,10,11). Lets the fused_hand beat (q7) auto-satisfy. Audit #41 P0 fix:
# award to the OWNER (resolved by pid via resolve_actor), NOT @p[nearest].
function evercraft:tinkering/plinth/resolve_actor
execute as @a[tag=ec.tnk_actor,distance=..8] if score @s ec.tnk_owned matches 0..3 run scoreboard players add @s ec.tnk_owned 4
execute as @a[tag=ec.tnk_actor,distance=..8] if score @s ec.tnk_owned matches 8..11 run scoreboard players add @s ec.tnk_owned 4

# === 5) EFFECTS + ANNOUNCEMENT ===
function evercraft:tinkering/plinth/effects
data modify storage evercraft:notify stage.c set value [{text:"Six builder parts fold into a ",color:"gray"},{text:"Hand of Creation",color:"#FFAA00",bold:true},{text:" by ancient power!",color:"gray"}]
scoreboard players set #ndur ec.temp 45
execute as @a[distance=..64] run function evercraft:util/notify/emit
# (AB-1 sticky-times sweep 2026-06-10: explicit stamp — `title times` is sticky per player and this sequence set none, so it inherited whatever ran last.)
title @a[distance=..32] times 10 60 20
title @a[distance=..32] subtitle [{text:"The whole builder's kit in one grip",color:"#FFAA00"}]
title @a[distance=..32] title [{text:"Hand of Creation",color:"#FFAA00"}]
