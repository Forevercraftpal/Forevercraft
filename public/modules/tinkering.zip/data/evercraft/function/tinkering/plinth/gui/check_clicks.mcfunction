# Tinker Table Workbench — Check Clicks. Run as: player with TNK.InMenu (@s stays the player
# throughout, so every routed handler runs as the player — no fragile `on target` hop).
# Session-scoped: only THIS open's elements (matching adv.gui_session) respond.
scoreboard players set #tnk_click ec.temp 0
scoreboard players operation #gui_check ec.temp = @s adv.gui_session

# Detect which button holds fresh click data (1=Deposit, 2=Combine, 3=Close).
execute as @e[type=interaction,tag=TNK.DepositBtn,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction run scoreboard players set #tnk_click ec.temp 1
execute as @e[type=interaction,tag=TNK.CombineBtn,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction run scoreboard players set #tnk_click ec.temp 2
execute as @e[type=interaction,tag=TNK.CloseBtn,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction run scoreboard players set #tnk_click ec.temp 3

# Consume the click data on all of this session's buttons (so it fires once).
execute as @e[type=interaction,tag=TNK.MenuEl,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction run data remove entity @s interaction

# Route AS THE PLAYER.
execute if score #tnk_click ec.temp matches 1 run function evercraft:tinkering/plinth/gui/deposit
execute if score #tnk_click ec.temp matches 2 run function evercraft:tinkering/plinth/gui/combine
execute if score #tnk_click ec.temp matches 3 run function evercraft:tinkering/plinth/gui/close

# ===== INSPECT (left-click = what does this button do?) — gui/inspect pattern 2026-06-11 =====
execute as @e[type=interaction,tag=TNK.DepositBtn,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Deposit",b:"Sets the artifact you are holding onto the table."}
execute as @e[type=interaction,tag=TNK.DepositBtn,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=TNK.CombineBtn,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Combine",b:"Fuses the deposited pieces on the table — the recipe must be complete."}
execute as @e[type=interaction,tag=TNK.CombineBtn,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=TNK.CloseBtn,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Close",b:"Closes the Tinker Table."}
execute as @e[type=interaction,tag=TNK.CloseBtn,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack run data remove entity @s attack
