# ============================================================
# Tinkerer's Plinth — On Place (cosmetic head-display layer)
# ============================================================
# Fired by the place advancement when a player sets down the Plinth lodestone
# (custom_data{tinker_station:true}). Overlays the block-filling textured head on the
# lodestone (Guidestone/Transmute chassis). PURELY COSMETIC: the fusion ritual is
# detected at the BEACON (plinth/tick scans for an accessory:true item on a beacon),
# NEVER at this block — so the display can never affect fusion. Run as: the player.

# Revoke immediately so a re-place re-triggers.
advancement revoke @s only evercraft:tinkering/plinth/place

# Stage the Plinth skin (base64 profile value) for spawn_display to read.
# CANONICAL value lives in evercraft:admin/give/plinth_head — keep the two in sync.
data modify storage evercraft:tnk_plinth temp_skin set value "ewogICJ0aW1lc3RhbXAiIDogMTc4MDUzNTU5NjMzMywKICAicHJvZmlsZUlkIiA6ICI4OGMyOGYwOTY3MjU0NmNkYTg3ZjVhMTc0ODU0MzExYiIsCiAgInByb2ZpbGVOYW1lIiA6ICJOaXRlQ2F2ZSIsCiAgInNpZ25hdHVyZVJlcXVpcmVkIiA6IHRydWUsCiAgInRleHR1cmVzIiA6IHsKICAgICJTS0lOIiA6IHsKICAgICAgInVybCIgOiAiaHR0cDovL3RleHR1cmVzLm1pbmVjcmFmdC5uZXQvdGV4dHVyZS9lOTY3Y2FlYTQ0MGY0MTQwNzIxNTViNmQwOGY2ZjVjMWZmNGUzMDZhNmZlZGFkNmRiYTg0MzFlY2FhMGQyMjE2IgogICAgfQogIH0KfQ=="

# Locate the placed lodestone: raycast from the eyes first, grid-scan fallback (oblique angles).
tag @s add ec.searching
scoreboard players set @s ec.tnk_ray 0
execute at @s anchored eyes run function evercraft:tinkering/plinth/raycast_place
execute if entity @s[tag=ec.searching] at @s align xyz run function evercraft:util/scan_for_lodestone {setup_function:"evercraft:tinkering/plinth/setup"}
tag @s remove ec.searching
scoreboard players set @s ec.tnk_ray 0
