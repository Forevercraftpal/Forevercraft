# Tinkerer's Plinth — On Break (lodestone removed). Run as/at the Plinth marker.
# Remove the head display, suppress the plain-lodestone drop, return the actual Plinth item.

# Kill the display chassis (armor_stand + its item_display passenger) + the GUI click node.
kill @e[type=armor_stand,tag=ec.tnk_pl_stand,distance=..2]
kill @e[type=item_display,tag=ec.tnk_pl_disp,distance=..2]
kill @e[type=interaction,tag=ec.tnk_int,distance=..2]

# Suppress the vanilla lodestone item drop, then spawn the real Tinkerer's Plinth item.
kill @e[type=item,nbt={Item:{id:"minecraft:lodestone"}},distance=..2]
loot spawn ~0.5 ~0.5 ~0.5 loot evercraft:tinkering/plinth/drop

# FX + notify.
particle minecraft:reverse_portal ~0.5 ~0.6 ~0.5 0.3 0.3 0.3 0.03 10
data modify storage evercraft:notify stage.c set value [{text:"The Tinkerer's Plinth was taken up.",color:"gray"}]
scoreboard players set #ndur ec.temp 40
execute as @a[distance=..16] run function evercraft:util/notify/emit
playsound minecraft:block.beacon.deactivate master @a[distance=..16,scores={ec.fx_snd=1..}] ~ ~ ~ 0.6 1.2

# Remove the marker.
kill @s
