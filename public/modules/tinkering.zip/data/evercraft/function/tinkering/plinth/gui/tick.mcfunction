# Tinker Table Workbench — per-player menu tick (called from display_tick for @a[tag=TNK.InMenu]).
# Run as: player, at player position.
execute unless entity @s[tag=TNK.InMenu] run return 0

# Close if the player walked away from any table.
execute unless entity @e[type=marker,tag=ec.tnk_pl_mk,distance=..5] run return run function evercraft:tinkering/plinth/gui/close

# Unified UI-click FX (Joseph 2026-06-05): play the gated cue ONCE if any TNK.MenuEl button registered a
# click this tick, before check_clicks consumes the interaction data.
execute if entity @e[type=interaction,tag=TNK.MenuEl,distance=..6,nbt={interaction:{}},limit=1] run function evercraft:fx/ui/click

# Route button clicks.
function evercraft:tinkering/plinth/gui/check_clicks
