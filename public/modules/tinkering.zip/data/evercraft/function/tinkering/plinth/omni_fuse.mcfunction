# ============================================================
# Tinkerer's Plinth — TINKER'S OMNITOOL fuse (4 singles -> the combined spirit-item)
# ============================================================
# Runs at the triggering accessory item entity, on/above a beacon. detect_omnitool confirmed all
# FOUR system singles are present near the beacon AND no omnitool exists. Consumes the four singles,
# spawns the Omnitool (counters start at 1 each from the loot table), and announces. (Clone of the
# generic plinth/do consume->beacon-sacrifice->spawn->effects shape, but with the four fixed ids.)

# Mark this tick handled (block the generic detect + a second omnitool op).
scoreboard players set #tnk_omni_hit ec.temp 1

# === ONE-SHOT GUARD: latch the table busy for this tick (NO block destroyed — Joseph 2026-06-04) ===
# Tag the nearest Tinker Table marker ec.tnk_busy (replaces the beacon sacrifice); cleared at the
# top of plinth/tick. The #tnk_omni_hit flag above already blocks a second omnitool op this tick.
tag @e[type=marker,tag=ec.tnk_pl_mk,distance=..2,limit=1,sort=nearest] add ec.tnk_busy

# === CONSUME the four system singles (one-way, T6 — OWNER cohort only, audit #41) ===
kill @e[type=item,tag=ec.tnk_mine,distance=..2,nbt={Item:{components:{"minecraft:custom_data":{artifact:"crate_luck_charm"}}}},limit=1]
kill @e[type=item,tag=ec.tnk_mine,distance=..2,nbt={Item:{components:{"minecraft:custom_data":{artifact:"prospectors_dowser"}}}},limit=1]
kill @e[type=item,tag=ec.tnk_mine,distance=..2,nbt={Item:{components:{"minecraft:custom_data":{artifact:"master_key_fob"}}}},limit=1]
kill @e[type=item,tag=ec.tnk_mine,distance=..2,nbt={Item:{components:{"minecraft:custom_data":{artifact:"pocket_ender_anchor"}}}},limit=1]

# === SPAWN the Omnitool one block above the altar (mirrors plinth/do spawn) ===
loot spawn ~ ~1 ~ loot evercraft:artifacts/system/tinkers_omnitool

# === EFFECTS + ANNOUNCEMENT ===
function evercraft:tinkering/plinth/effects
data modify storage evercraft:notify stage.c set value [{text:"⚙ ",color:"#B87333"},{text:"The Tinker's Omnitool",color:"#B87333",bold:true},{text:" takes shape — every copper trinket folded into one.",color:"gray"}]
scoreboard players set #ndur ec.temp 60
function evercraft:tinkering/plinth/resolve_actor
execute as @a[tag=ec.tnk_actor,distance=..8] run function evercraft:util/notify/emit
