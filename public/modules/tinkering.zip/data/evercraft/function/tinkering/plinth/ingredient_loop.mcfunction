# ============================================================
# Tinkerer's Plinth — GENERIC detect: ingredient-presence LOOP (self-recursing)
# ============================================================
# Runs at the triggering accessory item entity, on/above a beacon. Called by detect_row with
# #tnk_ing_i ec.temp = current ingredient index, #tnk_ing_n = ingredient count, #tnk_ing_have =
# running tally. The current row is at storage evercraft:tnk_cur recipe.
#
# For each ingredient_ids[i]: copy the id into scratch, macro-test whether an item entity with
# custom_data{artifact:"<id>"} exists within ~2b, and if so increment the present-tally. Then
# advance and recurse. Bounded by the row's ingredient count (≤6). This is the data-driven
# replacement for detect_hand's six literal `if entity ...{build_part:"<id>"}` clauses.

# Stop once every ingredient slot has been tested.
execute if score #tnk_ing_i ec.temp >= #tnk_ing_n ec.temp run return 0

# Copy ingredient_ids[i] into scratch (macro idiom: index is a macro arg).
execute store result storage evercraft:tnk_cur iidx int 1 run scoreboard players get #tnk_ing_i ec.temp
function evercraft:tinkering/plinth/get_ingredient with storage evercraft:tnk_cur

# Macro-test the id's presence near the beacon; +1 to the tally if an item with that artifact id
# is within ~2b. (The presence test itself is a macro body — the id is data.)
function evercraft:tinkering/plinth/test_ingredient with storage evercraft:tnk_cur

# Advance + recurse.
scoreboard players add #tnk_ing_i ec.temp 1
function evercraft:tinkering/plinth/ingredient_loop
