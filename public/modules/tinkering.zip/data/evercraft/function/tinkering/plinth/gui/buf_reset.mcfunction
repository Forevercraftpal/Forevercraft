# Tinker Table — reset a player's deposit buffer to empty. Macro: $(pid).
$data modify storage evercraft:tnk_gui bufs.$(pid) set value {items:[]}
