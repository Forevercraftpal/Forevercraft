# Tinker Table — Combine the deposited trinkets through the SAME fusion engine as the throw-path.
# Run as: the in-menu player. Joseph 2026-06-04: the GUI is just a no-throw funnel into the ritual.

# Need at least 2 deposits for any recipe (Knot is the 2-trinket minimum).
data modify storage evercraft:notify stage.c set value [{text:"⚠ Deposit at least 2 trinkets to fuse.",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute if score @s ec.tnk_dep matches ..1 run return run function evercraft:util/notify/emit

# Resolve the table; bail if not at one (gui/tick closes on walk-away, so this is defensive).
data modify storage evercraft:notify stage.c set value [{text:"⚠ Stand at the Tinker Table.",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute unless entity @e[type=marker,tag=ec.tnk_pl_mk,distance=..5,limit=1] run return run function evercraft:util/notify/emit

# Audit #41 P0-B fix: RESPECT the one-fuse-per-cycle latch instead of clearing it. If THIS table is
# already busy this 2s cycle (the throw-path or a prior Combine just fused on it), bail — the player
# keeps their deposits (close returns them) and can Combine again next cycle. Previously this cleared
# ec.tnk_busy unconditionally, which defeated the guard for the GUI path and reopened the shared
# tnk_cur storage interleave. The latch CANNOT stick (plinth/tick clears every marker server-wide at
# the top of each 2s tick), so a real stuck table is impossible — at most a ~2s "try again" wait.
data modify storage evercraft:notify stage.c set value [{text:"⚙ The table is still settling — try Combine again in a moment.",color:"yellow"}]
scoreboard players set #ndur ec.temp 45
execute if entity @e[type=marker,tag=ec.tnk_pl_mk,tag=ec.tnk_busy,distance=..5,limit=1] run return run function evercraft:util/notify/emit

# Materialise every buffered trinket onto the table as ec.tnk_deposited item entities — summoned AND
# consumed within this single click, so the passive 2s scan (which excludes ec.tnk_deposited) never
# sees them and can't double-fuse them.
execute store result storage evercraft:tnk_gui scratch.pid int 1 run scoreboard players get @s ec.tnk_pid
execute at @e[type=marker,tag=ec.tnk_pl_mk,distance=..5,limit=1,sort=nearest] run function evercraft:tinkering/plinth/gui/combine_summon with storage evercraft:tnk_gui scratch

# Audit #41 P0: capture the CLICKING player's pid so the dispatch + the leftover return only ever
# touch THIS player's just-summoned deposits — a co-located player's ec.tnk_deposited items (their
# own pending combine) carry a different ec.tnk_own and are skipped (and returned to THEM, not here).
execute store result score #tnk_owner_pid ec.temp run scoreboard players get @s ec.tnk_pid

# Run the throw-path detect chain AS each of THIS PLAYER's deposited items — every recipe type (Knot /
# Omnitool / Hand / family registry) resolves exactly as if the trinkets had been tossed, same animation.
execute at @e[type=marker,tag=ec.tnk_pl_mk,distance=..5,limit=1,sort=nearest] as @e[type=item,tag=ec.tnk_deposited,tag=!ec.tnk_checked,distance=..3,limit=10] if score @s ec.tnk_own = #tnk_owner_pid ec.temp at @s run function evercraft:tinkering/plinth/check_item

# Hand back any of THIS PLAYER's deposited trinkets the fusion didn't consume (incomplete set ->
# nothing is lost); a co-located player's leftovers are returned by THEIR own combine, not here.
# Tag the clicking player ec.tnk_actor so return_one tp's leftovers back to THEM (not @p[nearest]).
tag @a remove ec.tnk_actor
tag @s add ec.tnk_actor
execute at @e[type=marker,tag=ec.tnk_pl_mk,distance=..5,limit=1,sort=nearest] run function evercraft:tinkering/plinth/gui/return_leftovers
tag @s remove ec.tnk_actor

# The buffer is now empty (combine_summon popped every entry); close tears down the menu.
function evercraft:tinkering/plinth/gui/close
