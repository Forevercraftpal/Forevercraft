# Tinkerer's Plinth — Setup at the placed block position.
# Run at: the lodestone block corner (align xyz), as: the placing player (for the facing read).
# Spawns the marker + the block-filling head display. Cosmetic only (fusion is at the beacon).

# Stop the raycast recursion AND the grid-scan fallback from also firing.
scoreboard players set @s ec.tnk_ray 99
tag @s remove ec.searching

# Marker at the block corner — anchors break-cleanup + ambient FX + GUI click-detection.
# ec.lodestone_registered makes every station's lodestone scan skip this block (shared convention).
summon marker ~ ~ ~ {Tags:["ec.tnk_pl_mk","ec.tnk_pl_new","ec.lodestone_registered","smithed.entity"]}

# GUI access node — a clickable interaction on top of the table. Right-clicking it opens the
# deposit-from-hand workbench menu (the alternative to tossing trinkets — Joseph 2026-06-04).
# Detected each second in plinth/display_marker. ec.lodestone_registered keeps lodestone scans off it.
summon interaction ~0.5 ~1.0 ~0.5 {Tags:["ec.tnk_int","ec.lodestone_registered"],width:0.9f,height:0.6f,response:1b}

# Spawn the block-filling head display (reads temp_skin from storage; faces the placer).
function evercraft:tinkering/plinth/spawn_display with storage evercraft:tnk_plinth

# Tidy the spawn-only tag.
tag @e[type=marker,tag=ec.tnk_pl_new] remove ec.tnk_pl_new

# Place FX — cyan focus (the Plinth's #5EC8D8 identity) + beacon-altar tone.
particle minecraft:reverse_portal ~0.5 ~1.2 ~0.5 0.3 0.4 0.3 0.02 14
particle minecraft:enchant ~0.5 ~1.5 ~0.5 0.4 0.4 0.4 0.4 18
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"#5EC8D8"},{text:"The Tinker Table stands ready",color:"#5EC8D8",bold:true},{text:" — toss trinkets onto it, or right-click to open the workbench.",color:"gray"},{text:" ✦",color:"#5EC8D8"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.beacon.activate master @s ~ ~ ~ 0.7 1.4
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.amethyst_block.place master @s ~ ~ ~ 0.8 1.1
