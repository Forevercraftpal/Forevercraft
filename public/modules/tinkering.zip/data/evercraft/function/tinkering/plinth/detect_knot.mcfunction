# ============================================================
# Tinkerer's Plinth — Detect Trinket Knot merge (the trivial starter fusion, C7)
# ============================================================
# Runs at the triggering accessory item entity, on/above a beacon. The Trinket Knot fuses
# ANY TWO common accessories the player tossed → one Knot bundle. Unlike the satchel/Hand
# (fixed id-sets), the Knot fuses ANY two, so we COUNT distinct accessory item entities
# within ~2 blocks rather than gating on fixed ids.
#
# EXCLUSIONS (so the Knot doesn't cannibalize other rituals or re-fuse a bundle):
#   • build_part items are EXCLUDED — those belong to the Hand 6-set (detect_hand runs first
#     anyway, but excluding them keeps a partial part-collection from being knotted).
#   • already-fused bundles (tinker_knot / hand_of_creation / band_of_all_rings) and the
#     Plinth station item (tinker_station) are EXCLUDED — you cannot knot a Knot or an altar.
# So an "eligible" trinket = accessory:true, NOT build_part, NOT a bundle/station.
#
# We need at least 2 eligible item entities present. Count them into #tnk_knot_n; if >=2,
# run do_knot (which captures the first two ids + fuses). (Pattern mirrors satchel_forge/
# detect_merge but with a COUNT gate instead of fixed-id gates — "any 2" is the C7 novelty.)
scoreboard players set #tnk_knot_n ec.temp 0
execute store result score #tnk_knot_n ec.temp if entity @e[type=item,tag=ec.tnk_mine,distance=..2,nbt={Item:{components:{"minecraft:custom_data":{accessory:true}}}}]
# Subtract the ineligible kinds so the count reflects only knot-able trinkets.
execute store result score #tnk_ex ec.temp if entity @e[type=item,tag=ec.tnk_mine,distance=..2,nbt={Item:{components:{"minecraft:custom_data":{tinker_knot:true}}}}]
scoreboard players operation #tnk_knot_n ec.temp -= #tnk_ex ec.temp
execute store result score #tnk_ex ec.temp if entity @e[type=item,tag=ec.tnk_mine,distance=..2,nbt={Item:{components:{"minecraft:custom_data":{hand_of_creation:true}}}}]
scoreboard players operation #tnk_knot_n ec.temp -= #tnk_ex ec.temp
execute store result score #tnk_ex ec.temp if entity @e[type=item,tag=ec.tnk_mine,distance=..2,nbt={Item:{components:{"minecraft:custom_data":{band_of_all_rings:true}}}}]
scoreboard players operation #tnk_knot_n ec.temp -= #tnk_ex ec.temp
# Fusion Wave 1 / Family E intermediates + the legacy 4-ring shortcut are also bundles — exclude
# them so a player can't knot a sub-band (they belong to the ring lattice; the registry detect
# fuses the 3 sub-bands into the full Band, and runs before this).
execute store result score #tnk_ex ec.temp if entity @e[type=item,tag=ec.tnk_mine,distance=..2,nbt={Item:{components:{"minecraft:custom_data":{gemband:true}}}}]
scoreboard players operation #tnk_knot_n ec.temp -= #tnk_ex ec.temp
execute store result score #tnk_ex ec.temp if entity @e[type=item,tag=ec.tnk_mine,distance=..2,nbt={Item:{components:{"minecraft:custom_data":{wardband:true}}}}]
scoreboard players operation #tnk_knot_n ec.temp -= #tnk_ex ec.temp
execute store result score #tnk_ex ec.temp if entity @e[type=item,tag=ec.tnk_mine,distance=..2,nbt={Item:{components:{"minecraft:custom_data":{voidband:true}}}}]
scoreboard players operation #tnk_knot_n ec.temp -= #tnk_ex ec.temp
execute store result score #tnk_ex ec.temp if entity @e[type=item,tag=ec.tnk_mine,distance=..2,nbt={Item:{components:{"minecraft:custom_data":{band_of_four_rings:true}}}}]
scoreboard players operation #tnk_knot_n ec.temp -= #tnk_ex ec.temp
# (build_part items are accessory:true; if a partial part-set is on the altar, exclude it so
#  it isn't knotted — detect_hand handles the full 6-set first.)
execute store result score #tnk_ex ec.temp if entity @e[type=item,tag=ec.tnk_mine,distance=..2,nbt={Item:{components:{"minecraft:custom_data":{build_part:"reach"}}}}]
scoreboard players operation #tnk_knot_n ec.temp -= #tnk_ex ec.temp
execute store result score #tnk_ex ec.temp if entity @e[type=item,tag=ec.tnk_mine,distance=..2,nbt={Item:{components:{"minecraft:custom_data":{build_part:"refund"}}}}]
scoreboard players operation #tnk_knot_n ec.temp -= #tnk_ex ec.temp
execute store result score #tnk_ex ec.temp if entity @e[type=item,tag=ec.tnk_mine,distance=..2,nbt={Item:{components:{"minecraft:custom_data":{build_part:"scaffold"}}}}]
scoreboard players operation #tnk_knot_n ec.temp -= #tnk_ex ec.temp
execute store result score #tnk_ex ec.temp if entity @e[type=item,tag=ec.tnk_mine,distance=..2,nbt={Item:{components:{"minecraft:custom_data":{build_part:"palette"}}}}]
scoreboard players operation #tnk_knot_n ec.temp -= #tnk_ex ec.temp
execute store result score #tnk_ex ec.temp if entity @e[type=item,tag=ec.tnk_mine,distance=..2,nbt={Item:{components:{"minecraft:custom_data":{build_part:"steady"}}}}]
scoreboard players operation #tnk_knot_n ec.temp -= #tnk_ex ec.temp
execute store result score #tnk_ex ec.temp if entity @e[type=item,tag=ec.tnk_mine,distance=..2,nbt={Item:{components:{"minecraft:custom_data":{build_part:"level"}}}}]
scoreboard players operation #tnk_knot_n ec.temp -= #tnk_ex ec.temp

# Two or more eligible trinkets present -> fuse the first two into a Trinket Knot.
execute if score #tnk_knot_n ec.temp matches 2.. run function evercraft:tinkering/plinth/do_knot
