# ============================================================
# Tinkerer's Plinth — GENERIC detect: get-row macro body
# ============================================================
# Called `with storage evercraft:tnk_cur` where tnk_cur = {ridx:<0-based row index>}.
# Copies registry recipes[ridx] into evercraft:tnk_cur recipe. (Structural clone of
# tinkering/get_quest_macro — the quest registry's index-read macro.)
$data modify storage evercraft:tnk_cur recipe set from storage evercraft:tnk_recipes recipes[$(ridx)]
