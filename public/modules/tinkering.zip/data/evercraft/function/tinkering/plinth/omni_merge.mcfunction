# ============================================================
# Tinkerer's Plinth — TINKER'S OMNITOOL merge (re-attain a single -> +1 its counter, capped 3)
# ============================================================
# Macro body — called `{single:"<id>", counter:"<crate_lvl|spawn_lvl|open_lvl|ender_lvl>"}` from
# detect_omnitool when an EXISTING omnitool + exactly this one system single sit near the beacon.
# §6: "re-attaining a predecessor re-stacks its ability" via per-ability counters capped 3. When the
# ability is below the cap this consumes the single + bumps the matching counter on the omnitool item
# entity (no new item spawned — the omnitool persists, its counter just deepens). One-shot guarded by
# #tnk_omni_hit (set here).
#
# Counter math: read the omnitool's current $(counter) into a score, +1, clamp <=3, write back. The
# clamp keeps a re-attain a no-op once the ability is maxed (§14 guard 5: omnitool counters capped 3).
# W1 (audit #41): a maxed (counter==3) re-attain is a TRUE no-op — the single is left intact rather
# than destroyed for zero gain. The consume/writeback/deepen-notice all gate on the pre-bump counter.

# Mark this tick handled (block the generic detect + a second omnitool op).
scoreboard players set #tnk_omni_hit ec.temp 1

# One-shot guard: latch the table busy for this tick — NO block destroyed (Joseph 2026-06-04).
# Tag the nearest Tinker Table marker ec.tnk_busy (replaces the beacon sacrifice); cleared at the
# top of plinth/tick. #tnk_omni_hit above already blocks a second omnitool op this tick.
tag @e[type=marker,tag=ec.tnk_pl_mk,distance=..2,limit=1,sort=nearest] add ec.tnk_busy

# Read the OWNER's omnitool current counter value into a score (defaults to 0 if absent). Audit #41:
# tag=ec.tnk_mine keeps a shared table from reading a co-located player's omnitool.
scoreboard players set #tnk_omni_lvl ec.temp 0
$execute store result score #tnk_omni_lvl ec.temp run data get entity @e[type=item,tag=ec.tnk_mine,distance=..2,nbt={Item:{components:{"minecraft:custom_data":{artifact:"tinkers_omnitool"}}}},limit=1] Item.components."minecraft:custom_data".$(counter)

# Snapshot the pre-increment counter. W1 (audit #41): the single is only consumed when this ability is
# below the 3-cap. At cap (3) the merge is a no-op, so eating the single would destroy it for zero gain;
# gate the writeback + consume on "was below cap" (matches ..2) so a maxed re-attain leaves the single.
scoreboard players operation #tnk_omni_pre ec.temp = #tnk_omni_lvl ec.temp

# Increment + clamp at 3 (re-attain past 3 is a no-op — the single is NOT consumed once maxed).
scoreboard players add #tnk_omni_lvl ec.temp 1
execute if score #tnk_omni_lvl ec.temp matches 4.. run scoreboard players set #tnk_omni_lvl ec.temp 3

# Write the clamped value back onto the OWNER's omnitool custom_data.$(counter) — only when below cap.
$execute if score #tnk_omni_pre ec.temp matches ..2 store result entity @e[type=item,tag=ec.tnk_mine,distance=..2,nbt={Item:{components:{"minecraft:custom_data":{artifact:"tinkers_omnitool"}}}},limit=1] Item.components."minecraft:custom_data".$(counter) int 1 run scoreboard players get #tnk_omni_lvl ec.temp

# Consume the merged single (one-way cost, OWNER cohort only) — ONLY when the ability was below the 3-cap.
$execute if score #tnk_omni_pre ec.temp matches ..2 run kill @e[type=item,tag=ec.tnk_mine,distance=..2,nbt={Item:{components:{"minecraft:custom_data":{artifact:"$(single)"}}}},limit=1]

# Effects + announcement — only when the merge actually deepened an ability (was below cap).
# At cap (#tnk_omni_pre matches 3) the single is left intact (W1); surface a "already maxed" notice
# instead so the no-op is legible rather than a silent or misleading "deepens" message.
execute if score #tnk_omni_pre ec.temp matches ..2 run function evercraft:tinkering/plinth/effects
execute if score #tnk_omni_pre ec.temp matches ..2 run data modify storage evercraft:notify stage.c set value [{text:"⚙ ",color:"#B87333"},{text:"The Omnitool drinks the trinket",color:"#B87333"},{text:" — an ability deepens.",color:"gray"}]
execute if score #tnk_omni_pre ec.temp matches 3.. run data modify storage evercraft:notify stage.c set value [{text:"⚙ ",color:"#B87333"},{text:"That ability is already at its deepest",color:"#B87333"},{text:" — the trinket is left untouched.",color:"gray"}]
scoreboard players set #ndur ec.temp 50
function evercraft:tinkering/plinth/resolve_actor
execute as @a[tag=ec.tnk_actor,distance=..8] run function evercraft:util/notify/emit
