# Tinker Table — return a single unspent deposited trinket to its OWNER (the depositor). Run AS the
# item, with #tnk_owner_pid ec.temp = the depositor's pid (set by combine). Audit #41 P1 fix: tp to
# the player whose ec.tnk_pid matches the item's owner stamp, NOT @p[nearest] — so at a shared table
# a leftover can't be delivered to a co-located player. Falls back harmlessly if the owner is offline
# (the item is already collectable on the table; no one is forced to receive it).
tag @s remove ec.tnk_deposited
data merge entity @s {PickupDelay:0s}
# Tp the ITEM to the DEPOSITOR, who combine tagged ec.tnk_actor before calling return_leftovers (audit
# #41 P1 fix). If the depositor is somehow not tagged (offline), the tp does nothing and the item stays
# collectable on the table — never delivered to a co-located player.
tp @s @a[tag=ec.tnk_actor,limit=1,sort=nearest]
