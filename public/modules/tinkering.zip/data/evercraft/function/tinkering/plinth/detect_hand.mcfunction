# ============================================================
# Tinkerer's Plinth — Detect Hand-of-Creation merge (re-homed from round-1, T2)
# ============================================================
# Runs at the triggering accessory item entity, which sits on/above a beacon. Only fuse the
# Hand when ALL SIX distinct builder parts are present as item entities within ~2 blocks.
# A single chained execute: each "if entity" gates the next — all 6 must match before do_hand
# runs. (Clone of satchel_forge/detect_merge — the 6 fixed ids are the round-1 R13 part
# contract custom_data{accessory:true, build_part:"<id>"}: reach/refund/scaffold/palette/
# steady/level.) Round-1 owns the part loot + the Hand result loot; this seat owns the Plinth
# detect chain that fuses them (T2). If even one part is missing, nothing happens.
# Audit #41 P0: every gate carries tag=ec.tnk_mine so the Hand only fuses when the TRIGGER OWNER's
# own six parts are all present — a co-located player's parts can't complete another player's set.
execute if entity @e[type=item,tag=ec.tnk_mine,distance=..2,nbt={Item:{components:{"minecraft:custom_data":{accessory:true,build_part:"reach"}}}}] if entity @e[type=item,tag=ec.tnk_mine,distance=..2,nbt={Item:{components:{"minecraft:custom_data":{accessory:true,build_part:"refund"}}}}] if entity @e[type=item,tag=ec.tnk_mine,distance=..2,nbt={Item:{components:{"minecraft:custom_data":{accessory:true,build_part:"scaffold"}}}}] if entity @e[type=item,tag=ec.tnk_mine,distance=..2,nbt={Item:{components:{"minecraft:custom_data":{accessory:true,build_part:"palette"}}}}] if entity @e[type=item,tag=ec.tnk_mine,distance=..2,nbt={Item:{components:{"minecraft:custom_data":{accessory:true,build_part:"steady"}}}}] if entity @e[type=item,tag=ec.tnk_mine,distance=..2,nbt={Item:{components:{"minecraft:custom_data":{accessory:true,build_part:"level"}}}}] run function evercraft:tinkering/plinth/do_hand
