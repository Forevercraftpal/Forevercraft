# ============================================================
# Tinkerer's Plinth — GENERIC detect: test ONE ingredient's presence (macro body)
# ============================================================
# Called `with storage evercraft:tnk_cur` where tnk_cur = {ing:"<id>"}, AT the triggering
# accessory item entity (on/above the beacon). If an item entity matching this ingredient id
# exists within ~2 blocks, increment the present-tally #tnk_ing_have by EXACTLY ONE.
#
# An ingredient item is matched by EITHER form, flag-first so the tally is never double-counted:
#   1) custom_data{<id>:true}        — the bare boolean flag (the bag-base ids: hero_satchel, and
#                                      the sub-binding intermediates aegis_half/.../voidband which
#                                      carry both forms — flag wins here, so they tally once);
#   2) custom_data{artifact:"<id>"}  — the canonical accessory id every LEAF held trinket carries
#                                      (the 23 boss/ring/pebble leaves carry ONLY this form).
# The `unless` on the second test guarantees exactly one increment per ingredient regardless of
# which form (or both) is present — the data-driven equivalent of one detect_hand presence clause.
# Audit #41 P0: tag=ec.tnk_mine keeps the count to the TRIGGER OWNER's items, so a co-located
# player's trinkets can't complete (or be consumed by) another player's family recipe.
$execute if entity @e[type=item,tag=ec.tnk_mine,distance=..2,nbt={Item:{components:{"minecraft:custom_data":{"$(ing)":true}}}}] run scoreboard players add #tnk_ing_have ec.temp 1
$execute unless entity @e[type=item,tag=ec.tnk_mine,distance=..2,nbt={Item:{components:{"minecraft:custom_data":{"$(ing)":true}}}}] if entity @e[type=item,tag=ec.tnk_mine,distance=..2,nbt={Item:{components:{"minecraft:custom_data":{artifact:"$(ing)"}}}}] run scoreboard players add #tnk_ing_have ec.temp 1
