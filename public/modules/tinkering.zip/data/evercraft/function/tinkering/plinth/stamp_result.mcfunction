# ============================================================
# Tinkerer's Plinth — GENERIC do: stamp result flag + bound ids (macro body)
# ============================================================
# Called `with storage evercraft:tnk_cur recipe` (the current row), AT the triggering accessory
# item entity (on/above the altar). Stamps the spawned result item entity (nearest item carrying
# the row's $(flag) custom_data — the loot table already set it true) with the BOUND ingredient
# list, so the apply-unit's union read + the Almanac can reconstruct what was fused (T4 — the
# same id-stamp idiom as do_knot:41-42 stamping knot_a/knot_b).
#
# The result item already carries custom_data.$(flag)=true from its loot table; we additionally
# copy the consumed ingredient_ids onto custom_data.bound_ids. We match the freshly-spawned
# result by its $(flag) (set by the loot table) so we stamp the right item and not an input
# (inputs are already killed by consume_loop before this runs).
$execute as @e[type=item,distance=..2,nbt={Item:{components:{"minecraft:custom_data":{$(flag):true}}}},limit=1,sort=nearest] run data modify entity @s Item.components."minecraft:custom_data".bound_ids set from storage evercraft:tnk_cur recipe.ingredient_ids
