# Tinker Table — Deposit the held trinket into the table buffer. Run as: the in-menu player.
# Eligibility: must hold an accessory:true OR ring:true artifact. Joseph 2026-06-13: the
# original gate accepted only accessory:true, which excluded all 15 rings (amethyst, lapis,
# diamond, redstone, slime, ...) — and the Gemband / Wardband / Voidband recipes need rings.
# Rings carry ring:true (not accessory:true), so widen the gate. Station lodestones still
# carry neither flag, so they remain non-depositable.
data modify storage evercraft:notify stage.c set value [{text:"⚠ Hold a trinket or ring to deposit.",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute unless items entity @s weapon.mainhand *[custom_data~{accessory:true}] unless items entity @s weapon.mainhand *[custom_data~{ring:true}] run return run function evercraft:util/notify/emit

# Stage the held item into storage, append it to this player's buffer, then clear the hand.
execute store result storage evercraft:tnk_gui scratch.pid int 1 run scoreboard players get @s ec.tnk_pid
data modify storage evercraft:tnk_gui scratch.item set from entity @s SelectedItem
function evercraft:tinkering/plinth/gui/deposit_do with storage evercraft:tnk_gui scratch
item replace entity @s weapon.mainhand with minecraft:air

# Feedback + live count to the actionbar.
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.amethyst_block.hit master @s ~ ~ ~ 0.7 1.3
particle minecraft:enchant ~ ~1 ~ 0.3 0.4 0.3 0.6 12
function evercraft:tinkering/plinth/gui/refresh
