# ============================================================
# Tinkerer's Plinth — Give the Plinth item (dup-guarded)
# ============================================================
# Run as @s = the player. Gives a single "Tinkerer's Plinth" item — a minecraft:lodestone
# carrying custom_data{tinker_station:true} so the has_station check (q3) recognizes it as a
# fusion station. The Plinth is a marker/decoration the player keeps and sets atop a beacon;
# the actual fusion happens at the BEACON (the satchel_forge altar idiom — toss trinkets on
# the beacon next to the Plinth). The Plinth item is the "you own the Workshop" token.
# (Distinct custom_data flag tinker_station:true — NOT transmute's artificers_anvil:true, T7.)
#
# DUP-GUARD: only give if the player does NOT already hold one (anywhere). Called from the q3
# reward (reward_type/station) and the admin entry. Re-give on loss is the admin entry.
execute if items entity @s container.* *[custom_data~{tinker_station:true}] run return 0
execute if items entity @s weapon.* *[custom_data~{tinker_station:true}] run return 0

# Give the Tinkerer's Plinth (direct give — self-contained, no parallel loot tree).
give @s minecraft:lodestone[minecraft:custom_name={text:"Tinkerer's Plinth",color:"#5EC8D8",italic:false},minecraft:lore=[{text:"The Tinkerer's fusion altar",color:"#5EC8D8",italic:false},{text:"Workshop — Place It Anywhere",color:"dark_gray",italic:false},"",{text:"A focusing stone that folds two",color:"gray",italic:true},{text:"trinkets into one — no beacon needed.",color:"gray",italic:true},"",{text:"◆ Fuse: ",color:"white",italic:false,extra:[{text:"toss trinkets onto it",color:"#5EC8D8"}]},{text:"◆ Or: ",color:"white",italic:false,extra:[{text:"right-click to open the workbench",color:"#5EC8D8"}]},{text:"Every gift kept, the power held",color:"white",italic:false},{text:"in fewer slots.",color:"#5EC8D8",italic:false},"",{text:"The first of the Tinkerer's three tables.",color:"dark_gray",italic:true}],minecraft:custom_data={tinker_station:true,evercraft_item:true},minecraft:rarity="rare",minecraft:enchantment_glint_override=true] 1

data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"#5EC8D8"},{text:"You received the ",color:"gray"},{text:"Tinkerer's Plinth",color:"#5EC8D8",bold:true},{text:" — place it, then toss trinkets on it or right-click to fuse.",color:"gray"},{text:" ✦",color:"#5EC8D8"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.beacon.activate master @s ~ ~ ~ 0.7 1.4
