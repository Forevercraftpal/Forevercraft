# ============================================================
# Tinkerer's Plinth — GENERIC do: spawn the row's capstone loot (macro body)
# ============================================================
# Called `with storage evercraft:tnk_cur recipe` (the current row), AT the triggering accessory
# item entity (on/above the now-air'd altar). Spawns the row's capstone loot table one block
# above the altar — mirrors do_knot:39 / do_hand:39 (`loot spawn ~ ~1 ~ loot <table>`), but the
# table path is row data ($(loot)). Every loot path in recipes_batch_0 is verified to resolve at
# build (no dangling table), so this never load-errors.
$loot spawn ~ ~1 ~ loot $(loot)
