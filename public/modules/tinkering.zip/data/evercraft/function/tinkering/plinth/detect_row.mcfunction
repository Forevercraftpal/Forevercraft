# ============================================================
# Tinkerer's Plinth — GENERIC detect: gate ONE recipe row (all-of ingredient set)
# ============================================================
# Runs at the triggering accessory item entity, on/above a beacon. The current row lives at
# storage evercraft:tnk_cur recipe (copied by detect_loop). This gates the row exactly like
# detect_hand's "all 6 present" chain — but READ FROM DATA: count how many of the row's
# ingredient_ids are present as item entities within ~2b, and fire plinth/do iff the count
# equals the row's ingredient_ids length (ALL present).
#
# This is the data-driven equivalent of detect_hand's hardcoded 6-gate `if entity` chain: the
# ingredient list is per-row data, so we iterate it (ingredient_loop) and tally present ids.

# The row's required ingredient count (the all-of target).
execute store result score #tnk_ing_n ec.temp run data get storage evercraft:tnk_cur recipe.ingredient_ids
# Defensive: a malformed row with no ingredients never fires.
execute if score #tnk_ing_n ec.temp matches ..0 run return 0

# Tally of present ingredient ids; index into the ingredient list.
scoreboard players set #tnk_ing_have ec.temp 0
scoreboard players set #tnk_ing_i ec.temp 0
# Count how many of this row's ingredient_ids are present near the beacon (self-recursing).
function evercraft:tinkering/plinth/ingredient_loop

# ALL ingredients present -> this recipe is satisfied. Fire the generic do for this row and set
# the one-shot hit guard so detect_loop stops walking.
execute if score #tnk_ing_have ec.temp >= #tnk_ing_n ec.temp run scoreboard players set #tnk_recipe_hit ec.temp 1
execute if score #tnk_ing_have ec.temp >= #tnk_ing_n ec.temp run function evercraft:tinkering/plinth/do
