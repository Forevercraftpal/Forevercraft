# ============================================================
# Tinkerer's Plinth — Fusion detonation (scheduled 10t after the glyphs gather)
# ============================================================
# Runs with no context (from schedule). Detonates at EVERY table latched by fuse_converge, then
# clears the latch. Handles concurrent fusions at multiple tables (each tagged marker pops once).
execute as @e[type=marker,tag=ec.tnk_fx] at @s run function evercraft:tinkering/plinth/fuse_explode_one
tag @e[type=marker,tag=ec.tnk_fx] remove ec.tnk_fx
