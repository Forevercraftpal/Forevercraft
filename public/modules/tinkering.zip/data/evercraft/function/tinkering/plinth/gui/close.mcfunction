# Tinker Table Workbench — Close. Run as: player. Reached from the Close button, gui/tick
# (walk-away), open (toggle), and combine (post-fusion teardown).
execute unless entity @s[tag=TNK.InMenu] run return 0

# Menu Core: drop the shared close anchor.
tag @s remove ec.menu_active
scoreboard players reset @s ec.menu_open_y

# Return any unspent deposits to the player (cancel path; no-op when combine already emptied the
# buffer). Then wipe the buffer + count so the next open starts clean.
execute store result storage evercraft:tnk_gui scratch.pid int 1 run scoreboard players get @s ec.tnk_pid
function evercraft:tinkering/plinth/gui/giveback with storage evercraft:tnk_gui scratch
function evercraft:tinkering/plinth/gui/buf_reset with storage evercraft:tnk_gui scratch
scoreboard players set @s ec.tnk_dep 0

# Kill THIS session's menu elements (session-scoped, like transmute/gui/close).
scoreboard players operation #gui_check ec.temp = @s adv.gui_session
execute as @e[type=item_display,tag=TNK.MenuEl,distance=..7] if score @s adv.gui_session = #gui_check ec.temp run kill @s
execute as @e[type=text_display,tag=TNK.MenuEl,distance=..7] if score @s adv.gui_session = #gui_check ec.temp run kill @s
execute as @e[type=interaction,tag=TNK.MenuEl,distance=..7] if score @s adv.gui_session = #gui_check ec.temp run kill @s

tag @s remove TNK.InMenu
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.amethyst_block.break master @s ~ ~ ~ 0.3 0.9
