# ============================================================
# Tinkerer's Plinth — GENERIC do: light the Band ever-fused latch (safe-OR bit1 = value 2)
# ============================================================
# Runs at the triggering accessory item entity, on/above a beacon. Called by plinth/do for the
# Band-15 grand recipe (row bit:2). ec.tnk_owned bit1 (value 2) = "has forged a Band". Safe-OR:
# only add 2 if bit1 is CLEAR (re-grant is a no-op). Awarded to the OWNER (audit #41 P0 fix — the
# player who fused, resolved by pid via resolve_actor), mirroring do_knot / do_hand (which now run
# `as @a[tag=ec.tnk_actor,distance=..8]`).
#
# ec.tnk_owned is the DOCUMENTED safe-OR MULTI-WRITER bitfield (tinkering/load comment): the
# Transmute Band forge (transmute/consolidate/confirm:37-44) also OR-sets this bit. Two safe-OR
# writers of the SAME bit is the sanctioned convention (each checks-the-bit-before-OR-ing), NOT
# a one-writer-law violation. Values WITHOUT bit1: 0,1,4,5,8,9,12,13.
# Audit #41 P0 fix: award to the OWNER (resolved by pid), NOT @p[nearest] — a shared table could
# otherwise credit the wrong player. resolve_actor tags the owning player ec.tnk_actor.
function evercraft:tinkering/plinth/resolve_actor
execute as @a[tag=ec.tnk_actor,distance=..8] if score @s ec.tnk_owned matches 0 run scoreboard players add @s ec.tnk_owned 2
execute as @a[tag=ec.tnk_actor,distance=..8] if score @s ec.tnk_owned matches 1 run scoreboard players add @s ec.tnk_owned 2
execute as @a[tag=ec.tnk_actor,distance=..8] if score @s ec.tnk_owned matches 4 run scoreboard players add @s ec.tnk_owned 2
execute as @a[tag=ec.tnk_actor,distance=..8] if score @s ec.tnk_owned matches 5 run scoreboard players add @s ec.tnk_owned 2
execute as @a[tag=ec.tnk_actor,distance=..8] if score @s ec.tnk_owned matches 8 run scoreboard players add @s ec.tnk_owned 2
execute as @a[tag=ec.tnk_actor,distance=..8] if score @s ec.tnk_owned matches 9 run scoreboard players add @s ec.tnk_owned 2
execute as @a[tag=ec.tnk_actor,distance=..8] if score @s ec.tnk_owned matches 12 run scoreboard players add @s ec.tnk_owned 2
execute as @a[tag=ec.tnk_actor,distance=..8] if score @s ec.tnk_owned matches 13 run scoreboard players add @s ec.tnk_owned 2
