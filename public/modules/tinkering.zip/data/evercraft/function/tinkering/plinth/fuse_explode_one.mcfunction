# ============================================================
# Tinkerer's Plinth — Fusion detonation, per table. Run AS/AT the table marker (block corner).
# ============================================================
# The bound power detonates over the table — COSMETIC ONLY (no block damage, no entity damage).
# Block-center top = ~0.5 ~1 ~0.5. The table itself is never harmed (Joseph 2026-06-04).

# The bang.
playsound minecraft:entity.generic.explode master @a[distance=..48,scores={ec.fx_snd=1..}] ~0.5 ~1 ~0.5 1.3 1.1
playsound minecraft:block.beacon.activate master @a[distance=..48,scores={ec.fx_snd=1..}] ~0.5 ~1 ~0.5 1.6 1.3
playsound minecraft:ui.toast.challenge_complete master @a[distance=..32,scores={ec.fx_snd=1..}] ~0.5 ~1 ~0.5 1.0 1.0
playsound minecraft:block.amethyst_block.chime master @a[distance=..32,scores={ec.fx_snd=1..}] ~0.5 ~1 ~0.5 1.0 1.2

# Bright flash + cosmetic explosion (no damage — particles only).
particle flash{color:[1.0,1.0,1.0,1.0]} ~0.5 ~1.1 ~0.5
particle explosion_emitter ~0.5 ~1.1 ~0.5 0 0 0 0 1
particle explosion ~0.5 ~1.1 ~0.5 0.4 0.4 0.4 0 6
# Rising rods + triumphant motes + the aqua->gold palette burst.
particle end_rod ~0.5 ~1.1 ~0.5 0.45 0.6 0.45 0.12 55
particle totem_of_undying ~0.5 ~1.1 ~0.5 0.5 0.8 0.5 0.25 75
particle dust_color_transition{from_color:[0.37,0.78,0.85],scale:2.6,to_color:[1.0,0.67,0.0]} ~0.5 ~1.2 ~0.5 0.6 0.7 0.6 0.12 60
particle electric_spark ~0.5 ~1.1 ~0.5 0.3 1.2 0.3 0.5 25
