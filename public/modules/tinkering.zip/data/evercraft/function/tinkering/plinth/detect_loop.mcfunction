# ============================================================
# Tinkerer's Plinth — GENERIC detect: recipe-row LOOP (self-recursing, index-driven)
# ============================================================
# Runs at the triggering accessory item entity, on/above a beacon. Called by plinth/detect with
# #tnk_rec_i ec.temp = current row index, #tnk_rec_n = row count (N), #tnk_recipe_hit = 0.
#
# Standard mcfunction loop idiom (no native loops): test the row at #tnk_rec_i, then if no recipe
# has fired AND more rows remain, increment the index and TAIL-CALL itself. Bounded by N (Wave-1:
# 8 rows), and short-circuited the instant a recipe fires (#tnk_recipe_hit -> 1). The index read
# uses the macro get-row helper (mirrors tinkering/get_quest_macro reading quests[idx]).

# Stop if a recipe already fired this tick (one fusion per tick).
execute if score #tnk_recipe_hit ec.temp matches 1 run return 0
# Stop if we have walked past the last row (index >= N).
execute if score #tnk_rec_i ec.temp >= #tnk_rec_n ec.temp run return 0

# Copy the current row recipes[i] into scratch storage evercraft:tnk_cur recipe (macro idiom:
# index is a macro arg, so the read goes through the with-storage get-row helper).
execute store result storage evercraft:tnk_cur ridx int 1 run scoreboard players get #tnk_rec_i ec.temp
function evercraft:tinkering/plinth/get_recipe with storage evercraft:tnk_cur

# Test this row's ingredient set (counts present ids vs the row's ingredient length, fires do if
# ALL present). Sets #tnk_recipe_hit -> 1 if it fired.
function evercraft:tinkering/plinth/detect_row

# Advance to the next row and recurse (the guards at the top stop the recursion on hit or end).
scoreboard players add #tnk_rec_i ec.temp 1
function evercraft:tinkering/plinth/detect_loop
