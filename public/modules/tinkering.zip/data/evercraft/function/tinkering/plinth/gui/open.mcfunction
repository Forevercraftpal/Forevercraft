# Tinker Table Workbench — Open (deposit-from-hand -> Combine alternative to tossing trinkets).
# Run as: player, positioned at the table interaction (mirrors transmute/gui/open's call context).

# Toggle — if already open, close instead.
execute if entity @s[tag=TNK.InMenu] run return run function evercraft:tinkering/plinth/gui/close

# Menu Core: Y-displacement close anchor (shared menu infra).
# One-menu-at-a-time (2026-06-15): close any other open menu before this one claims
# ec.menu_active. Two overlapping menus share the @s adv.gui_session slot; the newer
# open orphans the older menu's session, so it can never consume its click -> stuck
# interaction NBT -> click-sound spam. force_close is idempotent (no-op when nothing open).
execute if entity @s[tag=ec.menu_active] run function evercraft:menu_core/force_close
tag @s add ec.menu_active
execute store result score @s ec.menu_open_y run data get entity @s Pos[1] 100

# Safety: kill orphaned menu elements near us.
execute at @s run kill @e[type=text_display,tag=TNK.MenuEl,distance=..5]
execute at @s run kill @e[type=interaction,tag=TNK.MenuEl,distance=..5]
execute at @s run kill @e[type=item_display,tag=TNK.MenuEl,distance=..5]

# Tag player in-menu.
tag @s add TNK.InMenu

# Assign a per-player buffer id (lazily; indexes storage evercraft:tnk_gui bufs.<pid>).
execute unless score #next_tnk_pid ec.var matches 0.. run scoreboard players set #next_tnk_pid ec.var 0
execute unless score @s ec.tnk_pid matches 1.. run scoreboard players add #next_tnk_pid ec.var 1
execute unless score @s ec.tnk_pid matches 1.. run scoreboard players operation @s ec.tnk_pid = #next_tnk_pid ec.var

# Start this session with an EMPTY deposit buffer (close/cancel always returns trinkets, so a fresh
# open never inherits stale deposits). Reset via macro (pid lives in storage scratch.pid).
execute store result storage evercraft:tnk_gui scratch.pid int 1 run scoreboard players get @s ec.tnk_pid
function evercraft:tinkering/plinth/gui/buf_reset with storage evercraft:tnk_gui scratch
scoreboard players set @s ec.tnk_dep 0

# === BACKGROUND PANEL ===
execute rotated ~ 0 positioned ^ ^2.4 ^1.8 run summon item_display ~ ~ ~ { Tags:["TNK.MenuEl","TNK.BG"], billboard:"center", item:{id:"black_stained_glass_pane",count:1}, item_display:"fixed", transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,-0.02f],scale:[2.8f,1.9f,0.01f]} }

# === OWNER LABEL (foreign viewers see whose menu this is) ===
# 26.1: {selector:} renders blank in text_display — bake @s's name to a $(owner) literal.
function evercraft:util/gui/owner_name
execute rotated ~ 0 positioned ^ ^3.28 ^1.78 run function evercraft:tinkering/plinth/gui/open_nm with storage evercraft:scorebake args

# === TITLE ===
execute rotated ~ 0 positioned ^ ^3.1 ^1.78 run summon text_display ~ ~ ~ { brightness:{block:15,sky:15},shadow_radius:0f, Tags:["TNK.MenuEl","TNK.Title"], billboard:"center", text:[{text:"⚙ ",color:"#3A8C99"},{text:"Tinker Table",color:"#5EC8D8",bold:true},{text:" ⚙",color:"#3A8C99"}], background:1,shadow:1b, transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.608f,0.608f,0.608f]} }

# === INFO LINE ===
execute rotated ~ 0 positioned ^ ^2.85 ^1.78 run summon text_display ~ ~ ~ { brightness:{block:15,sky:15},shadow_radius:0f, Tags:["TNK.MenuEl","TNK.Info"], billboard:"center", text:{text:"Deposit trinkets, then Combine to fold them into one.",color:"gray"}, background:0,shadow:1b, transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.405f,0.405f,0.405f]} }

# === STATUS LINE (static hint; live count is sent to the actionbar on each deposit) ===
execute rotated ~ 0 positioned ^ ^2.6 ^1.78 run summon text_display ~ ~ ~ { brightness:{block:15,sky:15},shadow_radius:0f, Tags:["TNK.MenuEl","TNK.Status"], billboard:"center", text:{text:"Hold a trinket and click [Deposit] below.",color:"dark_gray"}, background:0,shadow:1b, transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.473f,0.473f,0.473f]} }

# === DEPOSIT BUTTON ===
execute rotated ~ 0 positioned ^ ^1.9 ^1.78 run summon text_display ~ ~ ~ { brightness:{block:15,sky:15},shadow_radius:0f, Tags:["TNK.MenuEl","TNK.DepositTxt"], billboard:"center", text:[{text:"[ ",color:"dark_gray"},{text:"Deposit Held Trinket",color:"#5EC8D8",bold:true},{text:" ]",color:"dark_gray"}], background:1,shadow:1b, transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.473f,0.473f,0.473f]} }
# [strip] ?: 0.7w split into 4 x 0.2 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute rotated ~ 0 positioned ^-0.25 ^1.75 ^1.8 run summon interaction ~ ~ ~ { Tags:["TNK.MenuEl","TNK.DepositBtn"], width:0.2f,height:0.15f,response:1b }
execute rotated ~ 0 positioned ^-0.0833 ^1.75 ^1.8 run summon interaction ~ ~ ~ { Tags:["TNK.MenuEl","TNK.DepositBtn"], width:0.2f,height:0.15f,response:1b }
execute rotated ~ 0 positioned ^0.0833 ^1.75 ^1.8 run summon interaction ~ ~ ~ { Tags:["TNK.MenuEl","TNK.DepositBtn"], width:0.2f,height:0.15f,response:1b }
execute rotated ~ 0 positioned ^0.25 ^1.75 ^1.8 run summon interaction ~ ~ ~ { Tags:["TNK.MenuEl","TNK.DepositBtn"], width:0.2f,height:0.15f,response:1b }

# === COMBINE BUTTON ===
# Joseph 2026-06-13: text was at y=0.65 but the hitbox stack is at y=1.55,
# so the visible label was nowhere near the clickable area. Raised to y=1.7
# (Deposit-row pattern: text 0.15 above its hitbox).
execute rotated ~ 0 positioned ^0.45 ^1.7 ^1.78 run summon text_display ~ ~ ~ { brightness:{block:15,sky:15},shadow_radius:0f, Tags:["TNK.MenuEl","TNK.CombineTxt"], billboard:"center", text:[{text:"[ ",color:"dark_gray"},{text:"Combine!",color:"#FFB300",bold:true},{text:" ]",color:"dark_gray"}], background:1,shadow:1b, transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.473f,0.473f,0.473f]} }
# [strip] ?: 0.5w split into 5 x 0.12 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute rotated ~ 0 positioned ^-0.19 ^1.55 ^1.8 positioned ^0.45 ^0 ^0 run summon interaction ~ ~ ~ { Tags:["TNK.MenuEl","TNK.CombineBtn"], width:0.12f,height:0.12f,response:1b }
execute rotated ~ 0 positioned ^-0.095 ^1.55 ^1.8 positioned ^0.45 ^0 ^0 run summon interaction ~ ~ ~ { Tags:["TNK.MenuEl","TNK.CombineBtn"], width:0.12f,height:0.12f,response:1b }
execute rotated ~ 0 positioned ^0 ^1.55 ^1.8 positioned ^0.45 ^0 ^0 run summon interaction ~ ~ ~ { Tags:["TNK.MenuEl","TNK.CombineBtn"], width:0.12f,height:0.12f,response:1b }
execute rotated ~ 0 positioned ^0.095 ^1.55 ^1.8 positioned ^0.45 ^0 ^0 run summon interaction ~ ~ ~ { Tags:["TNK.MenuEl","TNK.CombineBtn"], width:0.12f,height:0.12f,response:1b }
execute rotated ~ 0 positioned ^0.19 ^1.55 ^1.8 positioned ^0.45 ^0 ^0 run summon interaction ~ ~ ~ { Tags:["TNK.MenuEl","TNK.CombineBtn"], width:0.12f,height:0.12f,response:1b }

# === CLOSE BUTTON ===
# Joseph 2026-06-13: raised label from y=0.65 to y=1.7 to match its hitbox row.
execute rotated ~ 0 positioned ^-0.45 ^1.7 ^1.78 run summon text_display ~ ~ ~ { brightness:{block:15,sky:15},shadow_radius:0f, Tags:["TNK.MenuEl","TNK.CloseTxt"], billboard:"center", text:[{text:"[ ",color:"dark_gray"},{text:"Close",color:"gray",bold:true},{text:" ]",color:"dark_gray"}], background:1,shadow:1b, transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.405f,0.405f,0.405f]} }
# [strip] ?: 0.4w split into 4 x 0.12 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute rotated ~ 0 positioned ^-0.14 ^1.55 ^1.8 positioned ^-0.45 ^0 ^0 run summon interaction ~ ~ ~ { Tags:["TNK.MenuEl","TNK.CloseBtn"], width:0.12f,height:0.12f,response:1b }
execute rotated ~ 0 positioned ^-0.0467 ^1.55 ^1.8 positioned ^-0.45 ^0 ^0 run summon interaction ~ ~ ~ { Tags:["TNK.MenuEl","TNK.CloseBtn"], width:0.12f,height:0.12f,response:1b }
execute rotated ~ 0 positioned ^0.0467 ^1.55 ^1.8 positioned ^-0.45 ^0 ^0 run summon interaction ~ ~ ~ { Tags:["TNK.MenuEl","TNK.CloseBtn"], width:0.12f,height:0.12f,response:1b }
execute rotated ~ 0 positioned ^0.14 ^1.55 ^1.8 positioned ^-0.45 ^0 ^0 run summon interaction ~ ~ ~ { Tags:["TNK.MenuEl","TNK.CloseBtn"], width:0.12f,height:0.12f,response:1b }

# Session isolation — stamp every element with a unique session id so check_clicks/close only act
# on THIS open (shared menu infra; identical to transmute/gui/open).
scoreboard players add #gui_session ec.var 1
scoreboard players operation @s adv.gui_session = #gui_session ec.var
scoreboard players operation #gui_stamp ec.temp = @s adv.gui_session
execute as @e[type=text_display,tag=TNK.MenuEl,distance=..5] unless score @s adv.gui_session matches 1.. run scoreboard players operation @s adv.gui_session = #gui_stamp ec.temp
execute as @e[type=item_display,tag=TNK.MenuEl,distance=..5] unless score @s adv.gui_session matches 1.. run scoreboard players operation @s adv.gui_session = #gui_stamp ec.temp
execute as @e[type=interaction,tag=TNK.MenuEl,distance=..5] unless score @s adv.gui_session matches 1.. run scoreboard players operation @s adv.gui_session = #gui_stamp ec.temp

execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.5 1.3
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.beacon.activate master @s ~ ~ ~ 0.4 1.6
