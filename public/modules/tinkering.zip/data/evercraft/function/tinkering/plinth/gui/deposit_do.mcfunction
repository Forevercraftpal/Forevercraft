# Tinker Table — append the staged trinket to the player's deposit buffer. Macro: $(pid).
$data modify storage evercraft:tnk_gui bufs.$(pid).items append from storage evercraft:tnk_gui scratch.item
