# ============================================================
# Tinkerer's Plinth — GENERIC registry-driven detect (data-driven fusion, Wave-1 Foundation)
# ============================================================
# Runs at the triggering accessory item entity, on/above a beacon (dispatched from check_item
# AFTER detect_hand and BEFORE detect_knot — so a specific multi-id family recipe wins over the
# trivial any-2 Trinket Knot, and the fixed-id Hand 6-set still wins over everything).
#
# This is the FORWARD-COMPATIBLE engine: it reads the family-recipe registry (storage
# evercraft:tnk_recipes recipes, loaded by registry/load_recipes) and, for each row, gates on
# ALL of that row's ingredient_ids being present near the beacon. The FIRST row whose full
# ingredient set is present fires plinth/do for that row, then stops (one fusion per tick).
# Adding a new family = appending a recipe row — NO edit to this file (it reads list length N
# dynamically). The existing detect_knot / detect_hand are untouched (this is purely additive).
#
# CONTRACT (mirrors detect_hand's "all 6 present" gate, but read from data instead of hardcoded):
#   • per row, count how many of its ingredient_ids are present as item entities within ~2b;
#   • if the count == the row's ingredient_ids length (ALL present), the recipe is satisfied —
#     run plinth/do with that row's data;
#   • stop after the first satisfied row (#tnk_recipe_hit guards re-firing within this tick).
#
# PERF: only reached when an accessory:true item entity already sits on a beacon (check_item
# gated it). The row loop is bounded by the registry size (56 rows); each row's inner
# ingredient loop is bounded by that row's ingredient count (≤6). With a beacon-on-altar this
# is a rare, player-driven event, not a standing per-tick cost.

# Nothing to do if the registry never loaded (defensive — registry/load_recipes runs on reload).
execute unless data storage evercraft:tnk_recipes recipes[0] run return 0

# How many recipe rows exist (dynamic N — a new batch auto-extends this with no engine edit).
execute store result score #tnk_rec_n ec.temp run data get storage evercraft:tnk_recipes recipes

# Loop bookkeeping: current row index, and a one-shot "a recipe fired this tick" guard.
scoreboard players set #tnk_rec_i ec.temp 0
scoreboard players set #tnk_recipe_hit ec.temp 0

# Walk every row (index 0..N-1). Each pass copies recipes[i] into scratch and tests it. We stop
# early once one fires (the hit guard short-circuits the remaining passes).
function evercraft:tinkering/plinth/detect_loop
