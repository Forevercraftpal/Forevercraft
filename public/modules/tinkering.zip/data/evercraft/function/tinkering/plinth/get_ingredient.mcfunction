# ============================================================
# Tinkerer's Plinth — GENERIC detect: get-ingredient macro body
# ============================================================
# Called `with storage evercraft:tnk_cur` where tnk_cur = {iidx:<0-based ingredient index>,
# recipe:{ingredient_ids:[...]}}. Copies recipe.ingredient_ids[iidx] into tnk_cur ing (a plain
# string the next macro reads). (Index-read macro idiom, mirrors get_recipe / get_quest_macro.)
$data modify storage evercraft:tnk_cur ing set from storage evercraft:tnk_cur recipe.ingredient_ids[$(iidx)]
