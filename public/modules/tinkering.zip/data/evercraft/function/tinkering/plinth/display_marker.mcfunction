# Tinkerer's Plinth — per-marker tick. Run as/at the Plinth marker.
# Break-detection: if the lodestone is gone, clean up the display and return the Plinth item.
execute unless block ~ ~ ~ minecraft:lodestone run return run function evercraft:tinkering/plinth/on_break

# GUI click-detection: a right-click on this table's interaction node opens the deposit workbench
# for the clicking player (the alternative to tossing trinkets — Joseph 2026-06-04). The interaction
# entity holds the click data until we consume it; reading it at 1s is responsive enough (transmute
# uses the same cadence). on_click reads the nearest player + removes the interaction data.
execute as @e[type=interaction,tag=ec.tnk_int,distance=..1.6,limit=1] at @s if data entity @s interaction run function evercraft:tinkering/plinth/gui/on_click

# Ambient cyan focus shimmer — proximity-gated so it costs nothing when nobody is near.
execute unless entity @a[distance=..32] run return 0
particle minecraft:reverse_portal ~0.5 ~1.25 ~0.5 0.18 0.12 0.18 0.005 2
