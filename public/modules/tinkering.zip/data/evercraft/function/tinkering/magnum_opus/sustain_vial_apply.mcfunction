# ============================================================
# Alchemist's Magnum Opus tree — Sustain Vial perk re-apply (Fusion / Family H — cap-H)
# ============================================================
# Run as @s = the player, at @s. Called from artifacts/accessories/player_tick's consolidated fusion
# block (a9, BEHIND the ec.has_accessory early-exit) when the player holds a sustain_vial:true item
# AND no superseding grand (Alchemist's Magnum Opus) is held (the guard lives at the call site). The
# Sustain Vial is the single-leaf sub-binding (it binds B11 Glacier-Cut Sigil). It re-grants the bound
# leaf's per-tick effect:
#   - Regeneration I while below HALF (50%) health.
# This is the EXACT idiom from the loose Glacier-Cut Sigil leaf (player_tick "FAMILY H SUSTAIN LEAF"
# block): below-50% is the firebrand Tyrant's-Rage idiom (read max_health *100, take 50%, read current
# Health *100, compare); the Regen respects the shared regen ceiling (ec.regen_capped) so it never
# over-stacks a stronger same-effect source (the Heartstone / Healer's-Salve idiom). NO attribute
# modifier -> NO accessory_cleanup strip needed; clear-on-removal is the effect's own 5t (0.25s) decay.
# ec._a single-scan tag is set/cleared by the CALLER's scan in player_tick (this fn runs only when the
# scan already matched); we re-read HP directly here (no item re-scan).
#
# DR=0 (H is a bundle: no luck modifier). BALANCE-NEUTRAL: NO DR / luck modifier (Magnum Opus family =
# zero DR). The Steeping / Crucible / Reliquary sub-caps carry NO per-tick perk (their CR / quality /
# yield / duration levers route through craft_rate/calculate + alchemy/minigame/resolve + result_*,
# gated on the sub-cap flag there) — so only the Sustain Vial + the grand have a player_tick apply.

# --- Glacier-Cut Sigil (B11): Regeneration I while below half health ---
execute store result score #h_hpmax ec.temp run attribute @s max_health get 100
scoreboard players operation #h_hpmax ec.temp *= #50 ec.const
scoreboard players operation #h_hpmax ec.temp /= #100 ec.const
execute store result score #h_hpcur ec.temp run data get entity @s Health 100
execute if score #h_hpcur ec.temp <= #h_hpmax ec.temp unless entity @s[tag=ec.regen_capped] run effect give @s regeneration 5 0 false
execute if score #h_hpcur ec.temp <= #h_hpmax ec.temp if entity @s[tag=ec.regen_capped] run function evercraft:artifacts/accessories/regen_fallback
