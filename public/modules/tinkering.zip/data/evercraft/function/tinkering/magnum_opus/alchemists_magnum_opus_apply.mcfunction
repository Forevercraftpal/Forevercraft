# ============================================================
# Alchemist's Magnum Opus — GRAND capstone: grant the full alchemist-trade union, ZERO DR
# ============================================================
# Run as @s = the player, at @s. Called from artifacts/accessories/player_tick's consolidated fusion
# block (a9, BEHIND the ec.has_accessory early-exit) when the player holds an alchemists_magnum_opus:true
# item. The Magnum Opus IS the union of all Family-H alchemist reagents by definition (the fusion `do`
# consumed the four sub-bindings / their leaves and spawned the Opus flagged alchemists_magnum_opus — it
# does NOT carry the member items). So HERE we directly grant the ONLY per-tick perk the bundle carries:
#   - Regeneration I while below HALF (50%) health (the Sustain Vial / Glacier-Cut Sigil leaf).
# The CR / alchemy-quality / reagent-yield / potion-duration halves route through their own brew-funnel
# hooks gated on the alchemists_magnum_opus flag (see below — never a 2nd ec.cr_temp writer per m4
# HANDOFF #7).
#
# THE CR / RESOLVE / YIELD / DURATION HALVES (routed elsewhere, gated on alchemists_magnum_opus, NOT here):
#   - +0.2 CR  -> craft_rate/calculate (the ONE ec.cr_temp writer: the consolidated Steeping +0.1 +
#                 Reliquary +0.1 = +0.2 CR while the Opus is held; loose leaf + sub-cap CR adds are
#                 m4-suppressed when the Opus is held, Newcomer-exempt). set-not-add -> never stacks.
#   - +3 alchemy quality -> alchemy/minigame/resolve (Crucible +1 + Reliquary +2, consolidated).
#   - +50% reagent-yield  -> alchemy/minigame/resolve (Steeping +20% + Reliquary +30%, consolidated).
#   - +50% potion duration -> the ec.h_alembic flag set in alchemy/minigame/resolve (Crucible's Alembic
#                 Heart half) -> read by result_dilute / result_potent / result_sublime.
#
# BALANCE-NEUTRAL: NO DR / luck modifier anywhere in this family (the Magnum Opus ships zero Dream Rate —
# the headline is the consolidated ALCHEMY bundle, not any luck). No `*_luck` is added or stripped (no DR
# member to consolidate; m4 Layer-1 strip targets the loose leaf brew levers, handled in calculate +
# resolve, NOT a luck strip). READ-ONLY on persistent state (the Regen effect is the only grant; no
# attribute modifier -> no accessory_cleanup / strip_player_zero strip needed).
#
# ABSORBED MEMBERS (7): steeping_vial_pendant, reagent_satchel_clasp, crucible_lens, alembic_heart,
# alembic_pendant, catalyst_reliquary, glacier_cut_sigil.

# --- Sustain Vial (Glacier-Cut Sigil B11): Regeneration I while below half health. Re-run the SAME
#     below-50% probe the loose leaf / Sustain Vial apply uses (the Opus holder carries no loose Sigil,
#     so the grand must probe HP itself). NO attribute modifier -> no strip needed. ---
execute store result score #h_hpmax ec.temp run attribute @s max_health get 100
scoreboard players operation #h_hpmax ec.temp *= #50 ec.const
scoreboard players operation #h_hpmax ec.temp /= #100 ec.const
execute store result score #h_hpcur ec.temp run data get entity @s Health 100
execute if score #h_hpcur ec.temp <= #h_hpmax ec.temp unless entity @s[tag=ec.regen_capped] run effect give @s regeneration 5 0 false
execute if score #h_hpcur ec.temp <= #h_hpmax ec.temp if entity @s[tag=ec.regen_capped] run function evercraft:artifacts/accessories/regen_fallback
