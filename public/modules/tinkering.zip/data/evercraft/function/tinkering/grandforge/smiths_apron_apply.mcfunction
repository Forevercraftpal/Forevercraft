# ============================================================
# Grandforge Regalia tree — Smith's Apron perk re-apply (Fusion / Family G — cap-G)
# ============================================================
# Run as @s = the player, at @s. Called from artifacts/accessories/player_tick's consolidated fusion
# block (a8, BEHIND the ec.has_accessory early-exit) when the player holds a smiths_apron:true item
# AND no superseding grand (Grandforge Regalia) is held (the guard lives at the call site). The Smith's
# Apron is the APPRENTICE sub-binding (the CR + efficiency leaf-pair): it binds apprentices_bellows_charm
# (C10) + tinsmiths_pocket_hammer (C11). It re-grants their PASSIVE attribute union here:
#   - Mining Efficiency +1 (Tinsmith's Pocket Hammer)
# The +0.2 CR half (Apprentice's Bellows Charm D-RENAME) is added in craft_rate/calculate (the ONE
# ec.cr_temp writer — gated on smiths_apron there, NOT here; per m4 HANDOFF #7 never a 2nd cr_temp
# writer). This apply touches only the mining_efficiency attribute (one fixed sub-cap id).
#
# DISTINCT sub-cap id (evercraft:smiths_apron_eff) — NOT the loose tinsmiths_pocket_hammer id — so the
# loose accessory_cleanup never strips the apron's grant, and the cap-G accessory_cleanup block strips
# this id `unless` the apron (or the grand) is held. Re-added every tick at a constant value -> two
# copies overwrite to ONE (m4 Layer-2 multi-copy-safe). DR=0 (G is a bundle: no luck modifier).
# BALANCE-NEUTRAL: NO DR / luck modifier (Grandforge family = zero DR).

# --- Tinsmith's Pocket Hammer: Mining Efficiency +1 ---
attribute @s mining_efficiency modifier add evercraft:smiths_apron_eff 1 add_value
