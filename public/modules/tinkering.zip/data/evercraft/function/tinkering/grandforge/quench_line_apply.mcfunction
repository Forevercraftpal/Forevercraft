# ============================================================
# Grandforge Regalia tree — Quench Line perk re-apply (Fusion / Family G — cap-G)
# ============================================================
# Run as @s = the player, at @s. Called from artifacts/accessories/player_tick's consolidated fusion
# block (a8, BEHIND the ec.has_accessory early-exit) when the player holds a quench_line:true item AND
# no superseding grand (Grandforge Regalia) is held (the guard lives at the call site). The Quench Line
# is the BREAK-SPEED sub-binding (✦✦): it binds quarry_worn_knuckle (C1, +8%) + whetstone_charm (C2,
# eff +2) + quenching_stone (C12, +10%) + quarrymans_grip (B3, +10%). It re-grants their PASSIVE
# attribute union here as the consolidated break-speed + efficiency:
#   - Block Break Speed +28% (8% + 10% + 10% — the three break-speed leaves, summed into one id)
#   - Mining Efficiency +2 (Whetstone Charm)
#
# DISTINCT sub-cap ids (evercraft:quench_line_bs / quench_line_eff) — NOT the loose leaf ids — so the
# loose accessory_cleanup never strips the line's grant, and the cap-G accessory_cleanup block strips
# these `unless` the line (or the grand) is held. break_speed uses add_multiplied_base (the
# adv_mining_surge / amethyst_trim precedent -> stacks ON Haste, not Haste); efficiency uses add_value
# (the companion silverfish precedent). Re-added every tick at constant values -> two copies overwrite
# to ONE (m4 Layer-2 multi-copy-safe). DR=0 (G is a bundle: no luck modifier).
# BALANCE-NEUTRAL: NO DR / luck modifier (Grandforge family = zero DR).

# --- Quarry-Worn + Quenching + Quarryman's: consolidated Block Break Speed +28% ---
attribute @s block_break_speed modifier add evercraft:quench_line_bs 0.28 add_multiplied_base
# --- Whetstone Charm: Mining Efficiency +2 ---
attribute @s mining_efficiency modifier add evercraft:quench_line_eff 2 add_value
