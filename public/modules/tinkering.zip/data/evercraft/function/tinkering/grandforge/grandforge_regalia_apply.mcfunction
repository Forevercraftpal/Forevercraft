# ============================================================
# Grandforge Regalia — GRAND capstone: grant the full forge-trade union, ZERO DR
# ============================================================
# Run as @s = the player, at @s. Called from artifacts/accessories/player_tick's consolidated fusion
# block (a8, BEHIND the ec.has_accessory early-exit) when the player holds a grandforge_regalia:true
# item. The Grandforge Regalia IS the union of all Family-G forge charms by definition (the fusion `do`
# consumed the four sub-bindings / their leaves and spawned the Regalia flagged grandforge_regalia — it
# does NOT carry the member items). So HERE we directly grant the consolidated PASSIVE attribute union
# (break-speed + mining-efficiency) via GRAND-scoped fixed ids. The CR / forge-resolve / auto-smelt /
# ore-roll / double-log halves route through their own event hooks gated on the grandforge_regalia flag
# (see below — never a 2nd ec.cr_temp writer per m4 HANDOFF #7).
#
# CONSOLIDATED VALUE (the union of all G attribute leaves, set-not-stacked):
#   - Block Break Speed +53% = Quench Line's +28% (Quarry-Worn +8 / Quenching +10 / Quarryman's +10)
#       + Grand Anvil Heart's +25%. (B8 Ember-Forged Band's conditional +8% is heat-gated and is folded
#       in only near a heat source — see the conditional add below, mirroring the loose band idiom.)
#   - Mining Efficiency +3 = Smith's Apron's +1 (Tinsmith's) + Quench Line's +2 (Whetstone).
#
# DISTINCT grand ids (evercraft:grandforge_bs / grandforge_eff / grandforge_band_*) — NOT the loose leaf
# or sub-cap ids — so the loose / sub-cap accessory_cleanup never strips the Regalia's grant, and the
# cap-G accessory_cleanup block strips these `unless` the Regalia is held. Re-added every tick at a
# constant value -> two copies overwrite to ONE (m4 Layer-2 multi-copy-safe). break_speed uses
# add_multiplied_base (adv_mining_surge / amethyst_trim precedent -> stacks ON Haste, not Haste);
# mining_efficiency uses add_value (companion silverfish precedent).
#
# THE CR / RESOLVE / YIELD HALVES (routed elsewhere, gated on grandforge_regalia, NOT here):
#   - +0.6 CR  -> craft_rate/calculate (the ONE ec.cr_temp writer: +20 [Apron] + +10 [Crystal] + +30
#                 [Grand Anvil] = +60 = +0.6 CR while the Regalia is held; loose leaf CR adds are
#                 m4-suppressed when the Regalia is held, Newcomer-exempt).
#   - +2 forge quality -> forging/minigame/resolve (Forgemaster's Tongs +1 + Grand Anvil Heart +1).
#   - auto-smelt       -> craft_affinity/detect_ordinary_tool (Smelter's Sigil, per pickaxe mine).
#   - +1% ore-roll      -> forging/ore_mining/check_drop (Prospector's Loupe extra roll).
#   - tree-crate + double-log -> harvest_bonus_read + crystal_double_log (Master Smith's Crystal, m2).
#
# BALANCE-NEUTRAL: NO DR / luck modifier anywhere in this family (the Grandforge ships zero Dream Rate —
# the headline is the consolidated FORGE bundle, not any luck). No `*_luck` is added or stripped (no DR
# member to consolidate; m4 Layer-1 strip targets the loose leaf CR adds, handled in calculate.mcfunction,
# not a luck strip). READ-ONLY on persistent state except the consolidated forge attributes (set-not-add).
#
# ABSORBED MEMBERS (12): apprentices_bellows_charm, tinsmiths_pocket_hammer, quarry_worn_knuckle,
# whetstone_charm, quenching_stone, quarrymans_grip, smelters_sigil, prospectors_loupe, forgemasters_tongs,
# master_smiths_crystal, grand_anvil_heart, ember_forged_band.

# --- Consolidated Block Break Speed +53% (Quench Line +28% + Grand Anvil Heart +25%) ---
attribute @s block_break_speed modifier add evercraft:grandforge_bs 0.53 add_multiplied_base

# --- Consolidated Mining Efficiency +3 (Smith's Apron +1 + Quench Line +2) ---
attribute @s mining_efficiency modifier add evercraft:grandforge_eff 3 add_value

# --- Ember-Forged Band (B8): CONDITIONAL +1 Armor + Break Speed +8% ONLY near a heat source. The grand
#     folds the loose band's heat-gated buff. We re-run the SAME ember_band_heat detector here (the loose
#     band line only fires #g_heat when the loose band is held, which the Regalia holder does NOT carry —
#     so the grand must probe heat itself). Zero #g_heat first, probe, then remove-then-conditional-add
#     off it (the band_luck idiom, distinct grand ids). Stripped in accessory_cleanup when not held. ---
scoreboard players set #g_heat ec.temp 0
execute at @s run function evercraft:artifacts/accessories/forge/ember_band_heat
attribute @s armor modifier remove evercraft:grandforge_band_armor
attribute @s block_break_speed modifier remove evercraft:grandforge_band_bs
execute if score #g_heat ec.temp matches 1 run attribute @s armor modifier add evercraft:grandforge_band_armor 1 add_value
execute if score #g_heat ec.temp matches 1 run attribute @s block_break_speed modifier add evercraft:grandforge_band_bs 0.08 add_multiplied_base
