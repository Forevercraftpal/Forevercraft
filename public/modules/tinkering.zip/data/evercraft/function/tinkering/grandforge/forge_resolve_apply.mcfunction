# ============================================================
# Grandforge Regalia tree — Forge Resolve perk re-apply (Fusion / Family G — cap-G)
# ============================================================
# Run as @s = the player, at @s. Called from artifacts/accessories/player_tick's consolidated fusion
# block (a8, BEHIND the ec.has_accessory early-exit) when the player holds a forge_resolve:true item AND
# no superseding grand (Grandforge Regalia) is held (the guard lives at the call site). The Forge Resolve
# is the YIELD / QUALITY sub-binding (✦✦): it binds smelters_sigil (C13, per-break auto-smelt) +
# prospectors_loupe (C14, +1% extra ore-roll) + forgemasters_tongs (C15, +1 forge-resolve quality).
#
# ALL THREE bound perks are EVENT-gated, NOT passive attributes, so this apply grants nothing here —
# each routes through its own event hook gated on the forge_resolve flag (so a re-acquired loose leaf
# never double-fires; the loose hook is m4-suppressed when this node is held, Newcomer-exempt):
#   - C13 auto-smelt   -> craft_affinity/detect_ordinary_tool's STONESTRIKE mining-delta block (forge_resolve
#                         gate added there, fires sigil_smelt on a pickaxe mine).
#   - C14 ore-roll      -> craftforever/forging/ore_mining/check_drop (forge_resolve gate added there, the
#                         +1% extra artifact-material roll).
#   - C15 forge quality -> craftforever/forging/minigame/resolve (forge_resolve gate added there, +1
#                         ec.cf_quality, item-gated like Catalyst / Home Forge).
#
# This file is intentionally a documented no-op (mirrors cap-D's death-save apply pattern: the perks
# route through their established event blocks, not the per-tick apply). DR=0 (G bundle: no luck modifier).
# BALANCE-NEUTRAL: NO DR / luck modifier, NO persistent attribute, NO scoreboard write here.
