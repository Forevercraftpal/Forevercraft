# ============================================================
# Tinkering — Accessory-pair offer gate (called from player_tick's consolidated block)
# ============================================================
# Run as @s = the player. Called from artifacts/accessories/player_tick's ONE additive line
# ONLY when ec.tnk_active==0 AND ec.tnk_offer==0 (the caller's cheap-gate-first; this fn is
# reached only for a player who has neither started nor been offered Tinkering). Counts the
# accessories the player holds; if >=2, fires the one-shot begin-offer.
#
# This split keeps the COUNT logic out of the 46KB hot file (player_tick only carries one
# gated `function` line). The count is the same held-item test the own_accessories check uses:
# accessory:true + ring:true + offhand accessory:true (the families player_tick already cares
# about). Since we are already past player_tick's early-exit, the player holds >=1 accessory;
# this just confirms >=2 before nudging.
#
# READ-ONLY (no scoreboard write except the private count temp); the actual latch
# (ec.tnk_offer) is written by on_get_accessory_pair.
scoreboard players set #tnk_off_n ec.temp 0
execute store result score #tnk_off_n ec.temp if items entity @s container.* *[custom_data~{accessory:true}]
execute store result score #tnk_off_ring ec.temp if items entity @s container.* *[custom_data~{ring:true}]
scoreboard players operation #tnk_off_n ec.temp += #tnk_off_ring ec.temp
execute store result score #tnk_off_off ec.var if items entity @s weapon.offhand *[custom_data~{accessory:true}]
scoreboard players operation #tnk_off_n ec.temp += #tnk_off_off ec.var
# >=2 accessories held -> fire the one-shot offer (it re-guards + latches ec.tnk_offer).
execute if score #tnk_off_n ec.temp matches 2.. run function evercraft:tinkering/on_get_accessory_pair
