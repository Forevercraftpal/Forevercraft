# ============================================================
# Wardband — perk re-apply (Fusion Wave 1 / Family E, effect-tier sub-band)
# ============================================================
# Run as @s = the player, at @s. Called from artifacts/accessories/player_tick's consolidated
# fusion block (the C7/S13 block, BEHIND the ec.has_accessory early-exit at :9) when the player
# holds a wardband:true item.
#
# BALANCE-NEUTRAL (R14 / DECISIONS #9): the Wardband re-grants exactly the UNION of its four
# effect rings' held effects PLUS the Aquamarine Ring's Dream Rate (routed here per DECISIONS D2 —
# the ring-identity DR charms consolidate into the Band lattice). Each member already granted its
# perk while loose (player_tick 589-609 for the rings, :129-130 for Aquamarine), so a player
# holding all five already had the union — the Wardband keeps it in ONE slot. Slot-saver only.
#
# THE FIVE MEMBERS (mirror the loose lines verbatim — same effect/level/duration/ambient flag):
#   ring_emerald   -> Hero of the Village (5s, ambient)   : always
#   ring_bone      -> Weakness aura (2s, ambient, ..5b)   : always (AoE re-emit)
#   ring_honey     -> Slowness aura (2s, ambient, ..5b)   : always (AoE re-emit)
#   ring_nether    -> Resistance II (5s, ambient)         : unless 2+ resist sources (ec.h_resist ..1)
#   aquamarine_ring-> +1.0 Dream Rate                     : unless ec.t_dring (its existing toggle)
#
# DR CONSOLIDATION: the lone DR source here is Aquamarine's +1.0. The Wardband folds it into ONE
# modifier evercraft:wardband_luck = +1.0 (dr_sum:1.0 in the registry row), honoring Aquamarine's
# EXISTING toggle ec.t_dring (no new toggle). Remove-then-add so the value is exact every tick;
# when ec.t_dring is set (the ring's DR turned OFF) the modifier is removed and not re-added.
#
# READ-ONLY on state: writes NO scoreboard; only grants effects/attributes (like player_tick).

effect give @s hero_of_the_village 5 0 true
effect give @e[type=#evercraft:hostile_mobs,distance=..5] weakness 2 0 true
effect give @e[type=#evercraft:hostile_mobs,distance=..5] slowness 2 0 true
execute if score @s ec.h_resist matches ..1 run effect give @s resistance 5 1 true
# --- Consolidated +1.0 Dream Rate (Aquamarine), honoring ec.t_dring ---
attribute @s luck modifier remove evercraft:wardband_luck
execute unless score @s ec.t_dring matches 1 run attribute @s luck modifier add evercraft:wardband_luck 1.0 add_value
# --- MULTI-COPY STRIP (D-MULTICOPY / m4, Layer 1: sub-binding supersedes its loose piece) ---
# The Wardband folds the Aquamarine Ring's +1.0 DR into wardband_luck above. If the player ALSO
# re-acquired a loose Aquamarine Ring, player_tick:233-234 already added the loose
# evercraft:aquamarine_ring_luck +1.0 EARLIER this tick (loose lines run before this consolidate
# per the tick.mcfunction invariant). Strip that loose id here so the Wardband's bound Aquamarine
# does NOT double-dip. The four effect-ring members (Emerald/Bone/Honey/Nether) carry NO luck
# modifier — fixed-level status effects, idempotent — so only Aquamarine needs stripping. Guarded
# `unless ec.t_dring` so we never strip the loose ring's DR when the player has toggled it OFF (the
# Wardband isn't re-adding it either, so leaving the loose +1 in that case would be the player's
# choice — but the loose line is itself ec.t_dring-gated, so it adds nothing when OFF anyway; the
# guard keeps the two in lockstep). NEWCOMER CARVE-OUT: casual players keep the double-dip stack.
execute unless score @s ec.difficulty matches 1 unless score @s ec.t_dring matches 1 run attribute @s luck modifier remove evercraft:aquamarine_ring_luck
