# ============================================================
# Gemband — perk re-apply (Fusion Wave 1 / Family E, gem-tier sub-band)
# ============================================================
# Run as @s = the player, at @s. Called from artifacts/accessories/player_tick's consolidated
# fusion block (the C7/S13 block, BEHIND the ec.has_accessory early-exit at :9 — a player with no
# accessory paid zero and never reaches here) when the player holds a gemband:true item.
#
# BALANCE-NEUTRAL (R14 / DECISIONS #9): the Gemband re-grants exactly the UNION of its five gem
# rings' held effects. Each gem ring already granted its single effect while loose (player_tick
# 565-588), so a player holding all five already had all five effects — the Gemband merely keeps
# that union in ONE slot. No new power; slot-saver only. The gem tier carries NO Dream Rate, so
# this sub-band emits NO luck modifier (dr_sum:0 in the registry row).
#
# THE FIVE GEM-RING EFFECTS (mirror the loose ring lines verbatim — same effect/level/duration/
# ambient flag; the harmonizable buffs keep their ec.h_* gate so the Gemband never double-stacks):
#   ring_amethyst -> Night Vision (13s, ambient)        : always
#   ring_lapis    -> Water Breathing (5s, ambient)      : always
#   ring_redstone -> Haste I (5s, ambient)              : unless 2+ haste sources (ec.h_haste ..1)
#   ring_diamond  -> Speed I (5s, ambient)              : unless 2+ speed sources (ec.h_speed ..1)
#   ring_slime    -> Jump Boost I (5s, ambient)         : unless 2+ jump sources (ec.h_jump ..1)
#
# READ-ONLY on state: writes NO scoreboard; only grants effects (like the rest of player_tick).
# No new toggle objective is introduced (the gem rings have no per-ring toggle when loose, so the
# Gemband binds them unconditionally — matching their loose behavior exactly).

effect give @s night_vision 13 0 true
effect give @s water_breathing 5 0 true
execute if score @s ec.h_haste matches ..1 run effect give @s haste 5 0 true
execute if score @s ec.h_speed matches ..1 run effect give @s speed 5 0 true
execute if score @s ec.h_jump matches ..1 run effect give @s jump_boost 5 0 true

# --- MULTI-COPY (D-MULTICOPY / m4): NO luck strip needed ---
# The Gemband consolidates ONLY fixed-level status effects (NV/WaterBreath/Haste/Speed/Jump). Its
# five gem-ring members carry NO luck modifier (dr_sum:0 in the registry row), so there is no
# loose *_luck id to double-dip — and a re-acquired loose gem ring's effect re-applies idempotently
# (same level overwrites, never stacks). No strip line is required for this sub-band.
