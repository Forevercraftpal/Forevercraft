# ============================================================
# Voidband — perk re-apply (Fusion Wave 1 / Family E, potent-tier sub-band)
# ============================================================
# Run as @s = the player, at @s. Called from artifacts/accessories/player_tick's consolidated
# fusion block (the C7/S13 block, BEHIND the ec.has_accessory early-exit at :9) when the player
# holds a voidband:true item.
#
# BALANCE-NEUTRAL (R14 / DECISIONS #9): the Voidband re-grants exactly the UNION of its three
# potent rings' held effects PLUS the Trial Ring's + Ring of Undying's Dream Rate (both routed
# here per DECISIONS D2). Each member already granted its perk while loose (player_tick 617-637
# for the rings, :611-615 Trial DR, :255-256 Undying DR), so a player holding all five already
# had the union — the Voidband keeps it in ONE slot. Slot-saver only.
#
# THE FIVE MEMBERS (mirror the loose lines verbatim — same effect/level/duration/ambient flag):
#   ring_ominous    -> Health Boost II (5s, ambient)       : always
#   ring_warden     -> Strength II (5s, ambient) + Darkness clear : Str unless 2+ str (ec.h_str ..1)
#   ring_void       -> Resistance II + Fire Res + Slow Fall : Resist unless 2+ resist (ec.h_resist ..1)
#   ring_trial      -> +2.0 Dream Rate                     : always (the loose Trial line is un-gated)
#   ring_of_undying -> +1.0 Dream Rate                     : unless ec.t_undying (its existing toggle)
#
# DR CONSOLIDATION: the two DR sources are Trial (+2.0, no toggle) and Ring of Undying (+1.0,
# gated by its EXISTING toggle ec.t_undying). The Voidband folds them into ONE modifier
# evercraft:voidband_luck (dr_sum:3.0 in the registry row): +3.0 when Undying's DR is ON, +2.0
# (Trial only) when ec.t_undying turns it OFF. Remove-then-add so the value is exact every tick.
# No new toggle objective is introduced.
#
# READ-ONLY on state: writes NO scoreboard; only grants effects/attributes (like player_tick).

effect give @s health_boost 5 1 true
execute if score @s ec.h_str matches ..1 run effect give @s strength 5 1 true
effect clear @s darkness
execute if score @s ec.h_resist matches ..1 run effect give @s resistance 5 1 true
effect give @s fire_resistance 5 0 true
effect give @s slow_falling 5 0 true
# --- Consolidated Dream Rate (Trial +2.0 always · Undying +1.0 unless ec.t_undying) ---
attribute @s luck modifier remove evercraft:voidband_luck
execute if score @s ec.t_undying matches 1 run attribute @s luck modifier add evercraft:voidband_luck 2.0 add_value
execute unless score @s ec.t_undying matches 1 run attribute @s luck modifier add evercraft:voidband_luck 3.0 add_value
# --- MULTI-COPY STRIP (D-MULTICOPY / m4, Layer 1: sub-binding supersedes its loose pieces) ---
# The Voidband folds the Trial Ring's +2.0 and the Ring of Undying's +1.0 DR into voidband_luck
# above. If the player ALSO re-acquired a loose Trial Ring / Ring of Undying, player_tick added the
# loose evercraft:trial_ring_luck +2.0 (:718) and/or evercraft:ring_of_undying_luck +1.0 (:359-360)
# EARLIER this tick (loose lines run before this consolidate per the tick.mcfunction invariant).
# Strip those loose ids here so the bound rings do NOT double-dip. The three effect-ring members
# (Ominous/Warden/Void) carry NO luck modifier — fixed-level status effects, idempotent — so only
# Trial + Undying need stripping. Trial's loose line is un-gated (always strip); Undying's loose
# line is ec.t_undying-gated, so strip it `unless ec.t_undying` to stay in lockstep (when toggled
# OFF the loose line adds nothing, so nothing to strip). NEWCOMER CARVE-OUT: casual players keep
# the forgiving double-dip stack (§D-MULTICOPY casual exception).
execute unless score @s ec.difficulty matches 1 run attribute @s luck modifier remove evercraft:trial_ring_luck
execute unless score @s ec.difficulty matches 1 unless score @s ec.t_undying matches 1 run attribute @s luck modifier remove evercraft:ring_of_undying_luck
