# ============================================================
# Tinkering (universal mini-line) — Overview page (current-quest macro body)
# ============================================================
# Called `with storage evercraft:tnk_cur o`, where o = the current quest object
# {id,title,desc,type,target,count,reward,reward_amt,chapter,...}. Prints the data-driven
# current-quest lines for the overview page; overview.mcfunction prints the score-driven
# progress/done lines around this. Mirrors the show_objective_macro tone (white-not-gray
# title, gray desc).
$tellraw @s [{text:"   ➤ ",color:"yellow"},{text:"$(title)",color:"white",bold:true}]
$tellraw @s [{text:"     $(desc)",color:"gray"}]
$tellraw @s [{text:"     Beat $(id)",color:"dark_gray"},{text:"  ·  Goal: ",color:"dark_gray"},{text:"$(count)",color:"#5EC8D8"}]
