# ============================================================
# Tinkering (universal mini-line) — Start (begin the line at quest 1)
# ============================================================
# Run as @s = the player. Started from the soft "[Begin Tinkering ->]" offer button
# (fired by tinkering/on_get_accessory_pair on first holding >=2 accessories — F), OR
# the Tinkering Tier-2 row (BOTH chronicle tiers — universal), OR the temp admin entry.
# Sets the linear pointer to quest 1, loads it, shows the intro + first objective. WRITER
# of the initial pointer state.
#
# Dup-guard: callers gate on `ec.tnk_active matches 0`, but be defensive here too — a
# re-entrant start must NOT re-seed the bitfield or reset progress.

# === DUP-GUARD: already on (or past) the line? Do nothing. ===
execute if score @s ec.tnk_active matches 1.. run return 0

# Unified UI-click FX (Joseph 2026-06-05): tellraw-option click — play the gated cue once on a real start
# (after the dup-guard, so a stale re-click stays a silent no-op).
function evercraft:fx/ui/click

# === ACTIVATE + RESET LINEAR STATE ===
scoreboard players set @s ec.tnk_active 1
# Auto-track this line for the [Skip ▸] button (Wiring #52): Tinkering = slot 10 (do_skip
# value-map). Latest-activated line wins; finish clears it if still pointed here. (After
# the dup-guard above, so a re-click never re-tracks a line already past.)
scoreboard players set @s ec.gq_track 10
scoreboard players set @s ec.tnk_quest 1
scoreboard players set @s ec.tnk_prog 0
scoreboard players set @s ec.tnk_done 0
scoreboard players set @s ec.tnk_complete 0

# === SEED THE ever-fused BITFIELD from current state (so prior fusions are recognized) ===
# A veteran who already forged a Trinket Knot / Hand / Band holds the bundle item; seed
# the matching ec.tnk_owned bit so the fused_* beats auto-pass at full reward on the next
# 20t check (R1 no-penalty catch-up). This is the held-item source of truth folded into
# the latch at line-start; the live fusion fns (plinth/do_knot, the C8 Hand/Band) OR-set
# the bit going forward. Each set is a safe-OR (check-the-bit-before-OR — here a plain set
# is fine since we only ADD bits and a player holding the item genuinely "has" that bit).
# bit0 (1) Trinket Knot — holds an item flagged tinker_knot:true.
execute if items entity @s container.* *[custom_data~{tinker_knot:true}] unless score @s ec.tnk_owned matches 1.. run scoreboard players add @s ec.tnk_owned 1
execute unless items entity @s container.* *[custom_data~{tinker_knot:true}] if items entity @s weapon.offhand *[custom_data~{tinker_knot:true}] unless score @s ec.tnk_owned matches 1.. run scoreboard players add @s ec.tnk_owned 1
# bit2 (4) Hand of Creation — holds an item flagged hand_of_creation:true (round-1 C8).
execute if items entity @s container.* *[custom_data~{hand_of_creation:true}] if score @s ec.tnk_owned matches 0..3 run scoreboard players add @s ec.tnk_owned 4
execute unless items entity @s container.* *[custom_data~{hand_of_creation:true}] if items entity @s weapon.offhand *[custom_data~{hand_of_creation:true}] if score @s ec.tnk_owned matches 0..3 run scoreboard players add @s ec.tnk_owned 4
# bit1 (2) Band of Rings — holds an item flagged band_of_all_rings:true (the full 15-ring Plinth
#   capstone) OR band_of_four_rings:true (the legacy 4-ring Transmute shortcut). EITHER counts as
#   "has forged a band" for the q6 fused_band beat (Fusion Wave 1 / Family E — both paths light bit1).
execute if items entity @s container.* *[custom_data~{band_of_all_rings:true}] if score @s ec.tnk_owned matches 0 run scoreboard players add @s ec.tnk_owned 2
execute if items entity @s container.* *[custom_data~{band_of_all_rings:true}] if score @s ec.tnk_owned matches 1 run scoreboard players add @s ec.tnk_owned 2
execute if items entity @s container.* *[custom_data~{band_of_all_rings:true}] if score @s ec.tnk_owned matches 4 run scoreboard players add @s ec.tnk_owned 2
execute if items entity @s container.* *[custom_data~{band_of_all_rings:true}] if score @s ec.tnk_owned matches 5 run scoreboard players add @s ec.tnk_owned 2
execute if items entity @s container.* *[custom_data~{band_of_four_rings:true}] if score @s ec.tnk_owned matches 0 run scoreboard players add @s ec.tnk_owned 2
execute if items entity @s container.* *[custom_data~{band_of_four_rings:true}] if score @s ec.tnk_owned matches 1 run scoreboard players add @s ec.tnk_owned 2
execute if items entity @s container.* *[custom_data~{band_of_four_rings:true}] if score @s ec.tnk_owned matches 4 run scoreboard players add @s ec.tnk_owned 2
execute if items entity @s container.* *[custom_data~{band_of_four_rings:true}] if score @s ec.tnk_owned matches 5 run scoreboard players add @s ec.tnk_owned 2

# Load quest 1 into tnk_cur for the objective display.
function evercraft:tinkering/get_quest

# Give the Tinkerer's Codex (dup-guarded) so the player can re-open the Workshop overview at
# will. The Plinth altar itself is HANDED later by the q3 "has_station" beat's reward
# (reward_type/station -> plinth/give), so start only opens the line + gives the book.
function evercraft:tinkering/book/give

# === INTRO ACTION-BAR (mirrors the C6 start tone, Tinkerer-keyed) ===
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"#5EC8D8"},{text:"The Tinkerer's Path",color:"#5EC8D8",bold:true},{text:" ✦",color:"#5EC8D8"}]
scoreboard players set #ndur ec.temp 50
function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Every trinket you carry takes a pocket. A Tinkerer learns to JOIN them — two charms into one, six builder-parts into a single Hand, a fistful of rings into one Band — so your power rides in fewer slots and your pack stays light. Nothing you fuse loses its potency; it only frees the room around it. Come, and I will teach you to knot the first.",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.player.levelup master @s ~ ~ ~ 0.4 1.4
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.6 1.6

# Subtle title flash, then show the first objective.
title @s times 5 40 10
title @s subtitle {text:"Two trinkets, one pocket",color:"gray",italic:true}
function evercraft:tinkering/show_objective
# Pacing (q1-lore fill 2026-06-10, mirror build_quests/start): deliver quest 1's lore line
# (muted in Quick Mode) + [Skip ▸] button — advances get this via on_advance_notify; the start
# path was the one chat-silent entry.
data modify storage evercraft:qp_cur o set from storage evercraft:tnk_cur quest
function evercraft:quest_pacing/render_lore
