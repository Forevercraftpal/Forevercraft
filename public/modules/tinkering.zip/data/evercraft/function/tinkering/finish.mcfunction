# ============================================================
# Tinkering (universal mini-line) — Finish (one-shot completion fanfare)
# ============================================================
# Run as @s = the player who just completed the final quest. Sets the ec.tnk_complete
# sentinel so this fires exactly once, then prints the "line complete!" celebration.
# WRITER of ec.tnk_complete (with advance).
#
# On completion this bumps ec.tnk_active 1 -> 2 (mirroring the C6 sentinel pattern), so a
# finished player is excluded from the active-only check_progress selector and the
# overview shows the celebration, not the current-quest panel. Every gate in THIS line
# uses `ec.tnk_active matches 1..` so the 1->2 bump is transparent to it.
#
# The Master-Tinkerer PRESTIGE title (special-title ID 17, bit 16, pow 65536) is OR-set into
# ec.special_titles here by Wave C8's capstone wiring (round-1 Waves 7-8 + the Cosmetics
# page-6 render now exist). The OR-set reuses the shared safe-bitfield macro
# guild_cards/rewards/_unlock_special_title {tid:17} (re-granting is a safe no-op), exactly
# like the Builder card's titles 14-16. Does NOT auto-equip — the player selects "Master
# Tinkerer" from the Cosmetics GUI page 6 (Tinkering section, SPT24) like every other title.

# Guard: only ever fire once.
execute if score @s ec.tnk_complete matches 1 run return 0
scoreboard players set @s ec.tnk_complete 1

# Mark Tinkering complete (the 1->2 bump excludes a done player from the active-only
# check_progress selector and flips the overview to the celebration).
scoreboard players set @s ec.tnk_active 2

# Auto-track repoint (Wiring #52): clear the [Skip ▸] tracker if it was pointed at THIS
# line (Tinkering = slot 10) — a completed line must never accept a skip.
execute if score @s ec.gq_track matches 10 run scoreboard players set @s ec.gq_track 0

data modify storage evercraft:notify stage.c set value [{text:"★ ",color:"gold"},{text:"The Tinkerer's Path — Complete!",color:"gold",bold:true},{text:" ★",color:"gold"}]
scoreboard players set #ndur ec.temp 50
function evercraft:util/notify/emit_keep
data modify storage evercraft:notify stage.c set value [{text:"You have learned the Tinkerer's whole craft: to knot two trinkets, to bind a fist of rings, to fold six builder-parts into one Hand. Your power rides in fewer slots now, and your pack is the lighter for it. A Tinkerer keeps three tables — the Plinth, the Stand, the Funnel — and you have mastered the joining at all of them.",color:"yellow",italic:true}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit

title @s times 10 60 20
title @s title {text:"Master Tinkerer",color:"gold"}
title @s subtitle {text:"The Tinkerer's Path is complete",color:"yellow"}

# Once-ever Master-Tinkerer fanfare — channel-gated showcase (ascending pling/bell arpeggio,
# end_rod + enchant spiral, gold flash). Replaces the crude ungated ui.toast/levelup/chime cue.
execute at @s run function evercraft:fx/craft/tinker_master

# === C8 capstone: OR-set the Master-Tinkerer special title (ID 17, bit 16, pow 65536). ===
# Safe-OR via the shared macro — re-granting is a no-op. Does NOT auto-equip.
function evercraft:guild_cards/rewards/_unlock_special_title {tid:17}
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"#C792EA"},{text:"New title unlocked: ",color:"yellow"},{text:"Master Tinkerer",color:"#C792EA",bold:true},{text:" ✦",color:"#C792EA"}]
scoreboard players set #ndur ec.temp 50
function evercraft:util/notify/emit_keep
data modify storage evercraft:notify stage.c set value [{text:"Equip it from the ",color:"gray"},{text:"Codex → Cosmetics → Special Titles → Tinkering",color:"#C792EA"},{text:".",color:"gray"}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit

# === ADDITIVE: exit handoff (Questline Restructure W4, 2026-06-10) ===
# A finished Path never goes dark: name the repeatable continuation (Trade Trials),
# bridge with 1 Trial Pass, and nudge the Grand Chronicle if both branches qualify.
# Runs inside this finish's one-shot complete-sentinel guard.
function evercraft:grand_quests/exit_handoff_craft

# Clear a stale tracked-Path pin if THIS line was pinned (QR-P5, 2026-06-10).
function evercraft:grand_quests/untrack_on_finish {slot:10}
