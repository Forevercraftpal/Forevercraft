# ============================================================
# Tinkering (universal mini-line) — 20t catch-up / interlude scheduler
# ============================================================
# Self-rescheduling, EXISTENCE-GATED 20t loop (kicked from tinkering/load with `replace`).
# It does work ONLY for players on the line (@a[scores={ec.tnk_active=1,ec.tnk_complete=0}]),
# so with no Tinkering players it iterates over NOTHING — no per-tick @a scan (the
# datapack's perf law).
#
# IMPORTANT (ec.tnk_active range): the selector uses `ec.tnk_active=1` exactly (NOT 1..)
# because finish() bumps ec.tnk_active to 2 on completion — a value-2 player is DONE and
# must not be re-scanned. A value-1 + complete-0 player is the active set.
#
# This line has NO per-action engine splice. So the 20t loop is the SOLE driver: every
# check type is READ-DERIVED over held items / the ec.tnk_owned bitfield / the
# ec.cf_r10_granted tag, so this loop catches each satisfied beat (2 trinkets held, a
# Funnel owned, a fusion performed) within ~1s. Two jobs per active player (both via check):
#   1. CATCH-UP (R1): an own_accessories / has_station / fused_* beat whose held-item /
#      tag / bit condition the player already clears auto-satisfies on this tick and pays
#      full reward — a veteran is never walled. Those helpers read the live state directly.
#   2. INTERLUDE auto-pass (C0, SCHEMA_DELTA §3): a beat:"interlude"/count:0 beat is
#      instantly satisfied by check()'s interlude guard, so it advances here on the next
#      tick — delivering its lore once, paying its tiny reward once.
#
# The forward-only ec.tnk_quest cursor (one advance per satisfied beat, inside advance)
# makes this no-double-credit and no-penalty.

# === RUN THE CHECK FOR EVERY ACTIVE, NON-COMPLETE PLAYER ===
# (check() is itself existence-gated + idempotent; the outer selector keeps the per-tick
#  cost zero when nobody is on the line.)
execute as @a[scores={ec.tnk_active=1,ec.tnk_complete=0}] run function evercraft:tinkering/check

# Re-schedule self.
schedule function evercraft:tinkering/check_progress 20t replace
