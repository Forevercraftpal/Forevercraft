# ============================================================
# Tinkering (universal mini-line) — Reward (pay out the completed quest)
# ============================================================
# Run as @s = the player. Reads the just-completed quest's reward fields from tnk_cur.quest
# and dispatches on reward type. tnk_cur still holds the OLD (just-completed) quest at this
# point (reward runs BEFORE advance bumps the pointer).
#
# Reward fields: reward (coins|crate|trophy), reward_amt (int), target (crate tier / trophy
# id). This is a TEACHING mini-line, NOT an XP faucet (DECISIONS #9), so the default rewards
# are coins / crate / trophy — there is NO `xp` reward_type file in this engine. (If a future
# beat ever pays artisan XP it must route through the FROZEN add_xp contract — #cf_xp_amount
# + #cf_xp_cat on ec.cf_temp, run as @s — and NEVER internal_grant; but no beat does so now.)
# There is NO `title` reward type: the Master-Tinkerer prestige is special-title ID 17, an
# ec.special_titles bit OR-set by Wave C8's capstone wiring, not a reward_type here.

# Flatten the quest fields for the reward macro.
data modify storage evercraft:tnk_cur o set from storage evercraft:tnk_cur quest
function evercraft:tinkering/reward_macro with storage evercraft:tnk_cur o

# === ADDITIVE: D-Q10-REWARD artifact (Artifact-Fusion w1) ===
# On TOP of the q10 reward above (q10 "Three Tables, One Craft" is an interlude that
# pays coins). Fires only when the just-completed quest is #10 (ec.tnk_quest still
# holds 10 here — advance bumps the pointer AFTER reward). Tinkering q10 ->
# Prospector's Dice (U20, Family K gathering leaf; the optional cross-craft pick).
# One-shot per the pointer-equals-10 gate. Inv-full aware via the shared helper.
execute if score @s ec.tnk_quest matches 10 run data modify storage evercraft:q10r args set value {lt:"artifacts/exquisite/prospectors_dice",name:"Prospector's Dice",color:"light_purple"}
execute if score @s ec.tnk_quest matches 10 run function evercraft:artifacts/give/q10_reward with storage evercraft:q10r args
