# FGQ check helper — forged_item (items forged SINCE the line began). @s = player.
# Present-action beat: reads the FORWARD-only delta (ach.artifacts_forged -
# ec.fgq_seen) so items forged before this beat was active never retro-credit it.
# Satisfied when the delta reaches quest.count (#fgq_count ec.temp).
#
# READ-ONLY: reads ach.artifacts_forged (craftforever-owned lifetime forge counter,
# written ONLY by craftforever/forging/) + ec.fgq_seen (this line's OWN cursor,
# seeded at start). Writes NO craftforever/forging/ engine objective.
#
# Note: a true veteran is NOT auto-passed by forged_item (the forward cursor is
# intentional for present-action beats) — but the line never WALLS on it, because
# every forged_item beat is `skippable` (default), so a player who would rather not
# forge fresh items can [Skip ▸] at full reward. The catch-up TYPES (forge_count_at
# / forge_xp_at) are the veteran auto-pass path.
scoreboard players set #fgq_satisfied ec.temp 0
scoreboard players operation #fgq_delta ec.temp = @s ach.artifacts_forged
scoreboard players operation #fgq_delta ec.temp -= @s ec.fgq_seen
execute if score #fgq_delta ec.temp >= #fgq_count ec.temp run scoreboard players set #fgq_satisfied ec.temp 1
