# ============================================================
# The Smith's Questline — Registry batch 0 (the starter line, q1..q14)
# ============================================================
# Appends the first 14 quests onto storage evercraft:fgq_registry quests.
# Called by registry/load AFTER it sets quests=[]. MUST append in id order
# (id=1 first => list index 0), contiguous, so list-position == ec.fgq_quest-1.
# (Structural clone of cooking/questline/registry/load_batch_0, paced via C0.)
#
# Quest object schema (the engine reads these exact fields):
#   {id:int, title:string, desc:string, type:string, target:string,
#    count:int, reward:string, reward_amt:int, chapter:int,
#    [lore:string], [beat:string], [skippable:int]}      <- C0 fields OPTIONAL
#
# type    -> dispatched by check_type/$(type):
#            forged_item | forge_count_at | forge_xp_at
#            (beat:"interlude"/count:0 auto-passes BEFORE dispatch — SCHEMA_DELTA §3)
# target  -> the check helpers IGNORE it (each reads a fixed public mirror), so it
#             is "" on most beats. On a `reward:"crate"` beat it names the crate
#             TIER consumed by reward_type/crate (common|uncommon|rare|ornate|
#             exquisite|mythical) — the only consumer of target in this batch.
# count   -> forged_item: forges-since-start threshold (delta off ec.fgq_seen);
#            forge_count_at: lifetime ach.artifacts_forged threshold;
#            forge_xp_at: lifetime ec.cf_axp_forge threshold;
#            interlude: 0 (auto-pass).
# reward  -> xp | coins | crate   (NO title). reward_amt = amount.
#            xp pays category-5 Forging XP via the FROZEN add_xp contract.
# chapter -> display grouping: 1=anvil, 2=materials, 3=grandforge.
#
# XP TIER TABLE (artisan-locked flat curve, mirrors the Cooking line so a Forging
# quest is never a fatter XP source than a forge-of-equal-tier loop):
#   40 / 90 / 180 / 320 / 480 / 700 / 950
#
# C0 CADENCE (SCHEMA_DELTA §1): every objective beat carries `lore`; interludes
# (q4 anvil breather, q9 materials/grandforge foreshadow, q13 the quiet before the
# grand forge) sit ~3:1 against objective beats; the headline teach beats q2 (the
# forge produces artifacts) + q11 (the Grand-Forge/Fusion-Funnel teach) are
# `skippable:0` "see-it-once" — both still auto-pass a veteran via the lifetime read
# in their check helper (Decision #5).
#
# ARTIFACT INTEGRATION (SYNTHESIS §7d — Forging = HEAVY): forging IS artifact-forging,
# so the whole line is artifact-themed by nature; the grandforge chapter is the seam
# where the Crafter chronicle hands off to the universal Tinkering identity (S14 —
# the Fusion-Funnel interlude is a PURE-LORE bridge to the Tinkering line, NOT a
# re-teach of any Tinkering mechanic).
# ------------------------------------------------------------

# --- Chapter 1: The Anvil --------------------------------------------------

# q1 — gentle intro: forge 3 items. Pure on-ramp. lore + default [Skip ▸].
data modify storage evercraft:fgq_registry quests append value {id:1,title:"The First Strike",desc:"Forge 3 items at a forge table.",type:"forged_item",target:"",count:3,reward:"xp",reward_amt:40,chapter:1,lore:"A forge table turns ore into intent. Three strikes in, the Smithing XP starts to flow — the same Artisan ladder every craft feeds."}

# q2 — *** SEE-IT-ONCE teach beat (skippable:0) ***: the forge produces ARTIFACTS,
#   not just tools. NO [Skip ▸] for a newcomer, but a VETERAN auto-passes via the
#   lifetime ach.artifacts_forged read in check_type/forge_count_at.
data modify storage evercraft:fgq_registry quests append value {id:2,title:"More Than Metal",desc:"Forge 6 items in all — learn that the anvil yields artifacts, not only tools.",type:"forge_count_at",target:"common",count:6,reward:"crate",reward_amt:1,chapter:1,lore:"The anvil yields more than metal: forged work can come out as artifacts, and even a failed forge can pay one back. Nothing at the forge is wasted.",skippable:0}

# q3 — forge a few more to settle into the rhythm. lore + default [Skip ▸].
data modify storage evercraft:fgq_registry quests append value {id:3,title:"Hands That Know the Hammer",desc:"Forge 12 items in all.",type:"forged_item",target:"",count:12,reward:"xp",reward_amt:90,chapter:1,lore:"Twelve pieces and your hands stop thinking. Smithing rank unlocks the Grand Forge's deeper work — and the hunter's best arms are a Smith's signature."}

# q4 — *** INTERLUDE (count:0, beat:interlude) ***: a pure-lore breather that
#   auto-passes on the next 20t check, delivers its lore once, pays coins:1 once.
#   A quiet meditation on the anvil. Proves the C0 interlude path end-to-end.
data modify storage evercraft:fgq_registry quests append value {id:4,title:"The Honesty of Iron",desc:"",type:"interlude",target:"",count:0,reward:"coins",reward_amt:1,chapter:1,beat:"interlude",lore:"Iron is honest: it pays exactly what you put in. The adventurers who knock at your door know it."}

# --- Chapter 2: Materials --------------------------------------------------

# q5 — climb the Forging XP. lore + default [Skip ▸]. forge_xp_at reads
#   ec.cf_axp_forge directly (lifetime catch-up — a veteran auto-passes at full XP).
data modify storage evercraft:fgq_registry quests append value {id:5,title:"A Fuller Forge",desc:"Earn 200 lifetime Forging XP.",type:"forge_xp_at",target:"",count:200,reward:"xp",reward_amt:180,chapter:2,lore:"Skill at the forge is bought in ore and ash. Every ingot you refine, every bar you draw, is a coin paid toward the day your hands move without thought."}

# q6 — forge more, deeper. lore + default [Skip ▸]. Reward Forging XP (tier 4).
data modify storage evercraft:fgq_registry quests append value {id:6,title:"From Ore to Worth",desc:"Forge 24 items in all — gather and refine what the deep stone gives.",type:"forge_count_at",target:"",count:24,reward:"xp",reward_amt:320,chapter:2,lore:"The mountain hoards its best metals behind hardship — that is the point. What is won easily is spent easily; what is mined and smelted and hammered becomes part of you, and so does the wonder you make of it."}

# q7 — a forge-count milestone to mark the chapter. lore + default [Skip ▸].
data modify storage evercraft:fgq_registry quests append value {id:7,title:"A Rack Well Hung",desc:"Forge 40 items in all.",type:"forge_count_at",target:"",count:40,reward:"xp",reward_amt:480,chapter:2,lore:"Count not the blades but the moments they will turn. A wall of well-forged work is a smith's truest ledger — every piece a promise that someone, someday, will be the stronger for it."}

# q8 — refine rarer materials; reward a crate. lore + default [Skip ▸].
data modify storage evercraft:fgq_registry quests append value {id:8,title:"The Catalyst's Edge",desc:"Forge 30 items in all — learn the catalysts that lift a forge above mere metal.",type:"forge_count_at",target:"uncommon",count:30,reward:"crate",reward_amt:1,chapter:2,lore:"A pinch of the right catalyst, and ordinary steel remembers it was once a star. Learn which reagents wake which metals — that knowing is the line between a smith and a maker of artifacts."}

# q9 — *** INTERLUDE (count:0) ***: foreshadow the Grand Forge.
data modify storage evercraft:fgq_registry quests append value {id:9,title:"Whispers from the Deep Forge",desc:"",type:"interlude",target:"",count:0,reward:"coins",reward_amt:1,chapter:2,beat:"interlude",lore:"The old smiths spoke of a forge beyond the forge — a Grand Forge, where a single Forge Crystal could bind the work of a hundred anvils into one impossible thing. You are nearly ready to hear that whisper as an instruction. The next chapter is where the real making begins."}

# --- Chapter 3: The Grand Forge --------------------------------------------

# q10 — climb the Forging artisan XP higher. lore + default [Skip ▸].
data modify storage evercraft:fgq_registry quests append value {id:10,title:"The Master's Rise",desc:"Earn 500 lifetime Forging XP.",type:"forge_xp_at",target:"",count:500,reward:"xp",reward_amt:480,chapter:3,lore:"Mastery at the forge is not a louder hammer — it is a quieter one, sure of every blow. You have paid the ore and the hours; now the metal yields to you before it is even warm."}

# q11 — *** SEE-IT-ONCE teach beat (skippable:0) — THE GRAND FORGE TEACH ***: the
#   grandforge chapter's headline. NO [Skip ▸] for a newcomer; a VETERAN auto-passes
#   via the lifetime forge read. Teaches the Grand Forge + Forge Crystal + Fusion
#   Funnel (all live craftforever features) — the lore names them; the desc points
#   the player at the Grand Forge to use them.
data modify storage evercraft:fgq_registry quests append value {id:11,title:"The Grand Forge Awakens",desc:"Forge 60 items in all, then seek the Grand Forge — bind your work with a Forge Crystal at the Fusion Funnel.",type:"forge_count_at",target:"",count:60,reward:"xp",reward_amt:700,chapter:3,lore:"At the Grand Forge, a Forge Crystal is the keystone and the Fusion Funnel is the crucible: together they take many forged pieces and resonate them into a single greater artifact. This is the summit of the smith's craft — and the doorway to the next.",skippable:0}

# q12 — a large lifetime XP capstone-runner. lore + default [Skip ▸].
data modify storage evercraft:fgq_registry quests append value {id:12,title:"Name Among Smiths",desc:"Earn 1200 lifetime Forging XP.",type:"forge_xp_at",target:"",count:1200,reward:"xp",reward_amt:700,chapter:3,lore:"There comes a day the realm wears your work without knowing your name — a ring that turned a blow, a blade that ended a long night. You did not seek the credit. It is hammered into every artifact you ever drew from the fire."}

# q13 — *** INTERLUDE (count:0) — the PURE-LORE TINKERING BRIDGE (S14) ***: a
#   breather that hands the Crafter chronicle off to the universal Tinkering identity.
#   Mentions joining forged wonders into greater ones; does NOT re-teach any Tinkering
#   mechanic (that is the Tinkering line's job — C7). Pure lore.
data modify storage evercraft:fgq_registry quests append value {id:13,title:"Where Forging Becomes Tinkering",desc:"",type:"interlude",target:"",count:0,reward:"coins",reward_amt:1,chapter:3,beat:"interlude",lore:"The Fusion Funnel taught you to join metal to metal. But a forged artifact can be joined to ANOTHER forged artifact — and there the smith's road becomes the Tinkerer's. When you are ready, the Tinkering chronicle waits to show you how two wonders become one. The fire here has done its part."}

# q14 — FINALE (artifact capstone): a wide forge milestone framed as the grand
#   masterwork. lore + default [Skip ▸]. XP tier 7. q14 is a soft finale, not a
#   hard cap: advance reads N (list length) dynamically, so appending load_batch_1
#   later auto-extends the line — q14's finish() only fires while N == 14.
data modify storage evercraft:fgq_registry quests append value {id:14,title:"The Grand Masterwork",desc:"Forge 100 items in all. Let your final piece be one the realm remembers.",type:"forge_count_at",target:"",count:100,reward:"xp",reward_amt:950,chapter:3,lore:"The grand masterwork is not a heavier hammer-blow — it is every blow you have ever struck, gathered into one artifact that could only have come from your hands. You are a Grand Smith now, and Forevercraft is armed and adorned and protected because you would not let the fire go cold."}

# ------------------------------------------------------------
# HAND-OFF TO load_batch_1 (future Forging chapters):
#   - This batch ends at id=14. The next batch's FIRST quest MUST be id=15 (list
#     index 14), appended immediately after q14, contiguously.
#   - registry/load calls load_batch_0; add the load_batch_1 call there when it
#     lands. Do NOT renumber this batch.
# ------------------------------------------------------------
