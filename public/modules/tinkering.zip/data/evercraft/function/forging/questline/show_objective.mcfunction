# ============================================================
# The Smith's Questline — Show current objective
# ============================================================
# Reads the current quest from fgq_cur.quest (already loaded by get_quest) and
# prints its title + description as the active objective. Data-driven via macro
# (the quest text lives in the registry, not in per-quest files).
# Run as @s = the player.

# Surface the quest fields the macro needs at the top level of fgq_cur.
data modify storage evercraft:fgq_cur o set from storage evercraft:fgq_cur quest
function evercraft:forging/questline/show_objective_macro with storage evercraft:fgq_cur o
