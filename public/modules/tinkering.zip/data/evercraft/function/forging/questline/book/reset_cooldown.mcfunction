# The Smith's Codex — Reset cooldown (runs ~1s after a right-click use).
# Revokes the using_item advancement so the book can be used again. Clone of
# cooking/questline/book/reset_cooldown.
execute as @a[tag=ec.forgebook_cd] run advancement revoke @s only evercraft:forging_book/on_use
tag @a[tag=ec.forgebook_cd] remove ec.forgebook_cd
