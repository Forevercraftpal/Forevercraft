# ============================================================
# The Smith's Questline — Start (begin the line at quest 1)
# ============================================================
# Run as @s = the player who just forged their first item (via the first_forge
# advancement reward fn, which guards on ec.fgq_active == 0) OR clicked the temp
# admin entry. Sets the linear pointer to quest 1, loads it, shows the intro +
# first objective. WRITER of the initial pointer state.

# === ACTIVATE + RESET LINEAR STATE ===
scoreboard players set @s ec.fgq_active 1
# Auto-track this line for the [Skip ▸] button (Wiring #52): Forging = slot 5 (do_skip
# value-map). Latest-activated line wins; finish clears it if still pointed here.
scoreboard players set @s ec.gq_track 5
scoreboard players set @s ec.fgq_quest 1
scoreboard players set @s ec.fgq_prog 0
scoreboard players set @s ec.fgq_done 0
scoreboard players set @s ec.fgq_complete 0
# Seed the forge-count cursor at the player's current lifetime forge count so items
# forged BEFORE the line began never retro-credit the present `forged_item` beat
# (forward-only). check_progress advances ec.fgq_prog off this cursor; the
# `forge_count_at`/`forge_xp_at` catch-up TYPES read their lifetime mirror DIRECTLY
# (so a veteran still auto-passes at full reward).
scoreboard players operation @s ec.fgq_seen = @s ach.artifacts_forged

# Load quest 1 into fgq_cur for the objective display.
function evercraft:forging/questline/get_quest

# === INTRO ACTION-BAR (mirrors the Cook's start tone, Forging-themed) ===
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"The Smith's Questline",color:"#E67E22",bold:true},{text:" ✦",color:"gold"}]
scoreboard players set #ndur ec.temp 50
function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Sparks leap from your first strike. A long road of anvils and artifacts lies ahead, smith — walk it, and forge the wonders of Forevercraft.",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.player.levelup master @s ~ ~ ~ 0.4 1.4
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.anvil.use master @s ~ ~ ~ 0.6 1.2

# Subtle title flash, then show the first objective.
title @s times 5 40 10
title @s subtitle {text:"Your first task awaits",color:"gray",italic:true}
function evercraft:forging/questline/show_objective
# Pacing (q1-lore fill 2026-06-10, mirror build_quests/start): deliver quest 1's lore line
# (muted in Quick Mode) + [Skip ▸] button — advances get this via on_advance_notify; the start
# path was the one chat-silent entry.
data modify storage evercraft:qp_cur o set from storage evercraft:fgq_cur quest
function evercraft:quest_pacing/render_lore
