# ============================================================
# The Smith's Questline — first_forge advancement reward (self-arming safety net)
# ============================================================
# Fired when a player has the Smith's Codex book in inventory (advancement
# evercraft:forging_book/first_forge). @s = that player. Mirrors
# cooking/questline/on_first_meal_adv: a self-arming, dup-guarded START net.
#
# In the normal flow the line is ALREADY active by the time this fires (the
# forging resolve gate-first line ran on_first_forge -> book/give -> start BEFORE
# the inventory_changed advancement evaluates). So this is almost always a no-op
# past activation — it exists as the resilience net for the edge case where the book
# exists but the line never started (e.g. the book was admin-given, or pre-existed
# this engine). NEVER gives a second book here (only the resolve path gives).

# Revoke so the criterion re-arms (cheap; mirrors on_first_meal_adv).
advancement revoke @s only evercraft:forging_book/first_forge

# Start the line only if it isn't already active (ec.fgq_active still 0).
execute unless score @s ec.fgq_active matches 1 run function evercraft:forging/questline/start
