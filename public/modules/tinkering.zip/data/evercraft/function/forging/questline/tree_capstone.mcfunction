# ============================================================
# The Smith's Questline — Completion Capstone (ADDITIVE, Joseph 2026-06-01)
# ============================================================
# Run as @s = the player who just finished the WHOLE Smith's Questline. Called
# from finish.mcfunction INSIDE the one-shot ec.fgq_complete guard, so it fires
# exactly once per player. ADDITIVE: this is ON TOP of the existing completion
# fanfare + every per-quest reward; it removes/reduces nothing.
#
# Drives PRESTIGE on the BLACKSMITH tree (id 12, prestige counter adv.pres_blac)
# through the engine's existing advantage/prestige/do_prestige path, difficulty-
# scaled by ec.difficulty (XP-REWARD-ECONOMY.md "Completion capstone"):
#   1 Newcomer        -> 2 prestiges  (target 2)  [PHASE-3 council F4: revised
#                                       down from 3; the 3-prestige payload
#                                       (~1,500 tokens + 15 abilities for a
#                                       5-book completionist) was too generous]
#   2 Adventurer      -> 1 prestige   (target 1)  [PHASE-3: revised down from 2]
#   3 Pioneer / unset -> 1 prestige   (target 1)  [floor — Adventurer & Pioneer
#                                       both grant 1; Newcomer is the only
#                                       multi-prestige tier]
# Since adv.req_xp (vanilla-XP per-level cost) is NOT difficulty-scaled, it is the
# CAPSTONE GRANT (prestige COUNT) that varies by mode, never the per-level cost.
#
# do_prestige reads only #pres_tree + #pres_current (no internal XP spend / req
# gate); it resets adv.blacksmith to 1, +1 adv.pres_blac (+ adv.pres_total), applies
# retained bonus, unlocks the prestige ability (blacksmith_p1/p2/p3), awards 100
# tokens + fanfare. check_eligible (the normal GUI path) requires level 25 and
# blocks at prestige >= 3 — we BYPASS check_eligible (calling do_prestige direct),
# so we enforce BOTH invariants here: set adv.blacksmith to 25 before each call
# (the level do_prestige assumes was legitimately reached) and never drive a step
# when adv.pres_blac is already >= 3 (respect the hard 3-prestige cap).

# --- Target prestige count from difficulty (Newcomer = 2, Adventurer/Pioneer/unset = 1) ---
scoreboard players set #fgq_pres_target adv.temp 1
execute if score @s ec.difficulty matches 1 run scoreboard players set #fgq_pres_target adv.temp 2

# --- BANK the earned prestige on the BLACKSMITH tree (id 12) instead of auto-applying it
#     (Joseph 2026-06-02: don't force-reset the tree on completion — the player CLAIMS it from the
#     [Claim ▸] chat button when ready). Clamp so current prestige + banked never exceeds 3. ---
scoreboard players operation @s adv.pbank_blac += #fgq_pres_target adv.temp
scoreboard players set #pcap adv.temp 3
scoreboard players operation #pcap adv.temp -= @s adv.pres_blac
execute if score #pcap adv.temp matches ..0 run scoreboard players set @s adv.pbank_blac 0
execute if score @s adv.pbank_blac > #pcap adv.temp run scoreboard players operation @s adv.pbank_blac = #pcap adv.temp

# --- Capstone banner + claim offer (additive, on top of finish.mcfunction's own fanfare) ---
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"A smith's mastery awakens — you've EARNED a Blacksmith prestige! Claim it when you're ready.",color:"light_purple",italic:true},{text:" ✦",color:"gold"}]
scoreboard players set #ndur ec.temp 50
function evercraft:util/notify/emit
function evercraft:advantage/prestige/show_claim_offers
