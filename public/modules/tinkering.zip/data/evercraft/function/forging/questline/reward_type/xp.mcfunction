# FGQ reward — xp (category-5 Artisan FORGING XP). @s = player.
# Amount in #fgq_reward_amt ec.temp. Paid through the FROZEN add_xp contract: set
# #cf_xp_amount + #cf_xp_cat=5 on ec.cf_temp, run as @s, call add_xp. NOTHING here
# writes ec.cf_xp / ec.cf_axp_forge directly; Forging XP NEVER routes through
# craft_affinity/internal_grant (that would re-arm the class faucet loop). This is
# the ONE add_xp call per reward — both ec.cf_xp and ec.cf_axp_forge rise inside it.
# (No macro args needed; invoked `with storage ... o` but only reads the temp.)
scoreboard players operation #cf_xp_amount ec.cf_temp = #fgq_reward_amt ec.temp
scoreboard players set #cf_xp_cat ec.cf_temp 5
function evercraft:craftforever/artisan/add_xp
# BAKE the amount as a literal $(reward_amt) — NOT a live {score:#fgq_reward_amt} ref, which the queued
# notify resolves at DISPLAY time after a multi-advance cascade overwrote the temp (build_quests bug class).
# (This file is a $-macro body — reward_macro invokes it `with storage ... o`, so $(reward_amt) is in scope.)
$data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"#E67E22"},{text:"Reward: ",color:"yellow"},{text:"$(reward_amt)",color:"#E67E22"},{text:" Forging XP",color:"#E67E22"},{text:" ✦",color:"#E67E22"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.experience_orb.pickup master @s ~ ~ ~ 0.6 1.0
