# FGQ check helper — forge_xp_at (lifetime Forging artisan XP). Catch-up beat.
# @s = player. Reads ec.cf_axp_forge (the category-5 Forging XP total) DIRECTLY, so
# a veteran whose Forging XP already clears the count auto-satisfies on the next
# 20t check_progress tick at full reward (R1). Constant per-quest reward => can't
# be farmed; forward-only ec.fgq_quest cursor blocks retro double-credit.
#
# READ-ONLY: reads ec.cf_axp_forge (craftforever-owned, written ONLY by the frozen
# add_xp contract). Writes NO craftforever/forging/ engine objective. NOTE: this
# line's OWN xp rewards (paid via add_xp cat-5) also raise ec.cf_axp_forge, so a
# forge_xp_at beat can be partly fed by the line's earlier rewards — intended (the
# line teaches by paying).
scoreboard players set #fgq_satisfied ec.temp 0
execute if score @s ec.cf_axp_forge >= #fgq_count ec.temp run scoreboard players set #fgq_satisfied ec.temp 1
