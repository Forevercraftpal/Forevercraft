# ============================================================
# The Smith's Questline — Finish (one-shot completion fanfare)
# ============================================================
# Run as @s = the player who just completed the final quest. Sets the
# ec.fgq_complete sentinel so this fires exactly once, then prints the
# "line complete!" celebration. WRITER of ec.fgq_complete (with advance).

# Guard: only ever fire once.
execute if score @s ec.fgq_complete matches 1 run return 0
scoreboard players set @s ec.fgq_complete 1

# Auto-track repoint (Wiring #52): clear the [Skip ▸] tracker if it was pointed at THIS
# line (Forging = slot 5) — a completed line must never accept a skip.
execute if score @s ec.gq_track matches 5 run scoreboard players set @s ec.gq_track 0

data modify storage evercraft:notify stage.c set value [{text:"★ ",color:"gold"},{text:"The Smith's Questline — Complete!",color:"#E67E22",bold:true},{text:" ★",color:"gold"}]
scoreboard players set #ndur ec.temp 50
function evercraft:util/notify/emit_keep
data modify storage evercraft:notify stage.c set value [{text:"Every anvil rung, every artifact drawn from raw ore. You are a Grand Smith of Forevercraft — and the Tinkerer's road now opens before you, where forged wonders are joined into greater ones.",color:"#F5B041",italic:true}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit

title @s times 10 60 20
title @s title {text:"Grand Smith",color:"#E67E22"}
title @s subtitle {text:"The Smith's Questline is complete",color:"#F5B041"}

execute if score @s ec.fx_snd matches 1.. run playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 1.0 1.0
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.player.levelup master @s ~ ~ ~ 0.6 1.2

# === ADDITIVE: difficulty-scaled Blacksmith-tree prestige capstone ===
# Fires exactly once (gated by the ec.fgq_complete one-shot set above). Drives
# 1/2/3 prestiges on adv.blacksmith via advantage/prestige/do_prestige, scaled by
# ec.difficulty (Pioneer/unset 1, Adventurer 2, Newcomer 3). ADDITIVE only — the
# existing fanfare above is untouched. See tree_capstone header.
function evercraft:forging/questline/tree_capstone

# === ADDITIVE: exit handoff (Questline Restructure W4, 2026-06-10) ===
# A finished Path never goes dark: name the repeatable continuation (Trade Trials),
# bridge with 1 Trial Pass, and nudge the Grand Chronicle if both branches qualify.
# Runs inside this finish's one-shot complete-sentinel guard.
function evercraft:grand_quests/exit_handoff_craft

# Clear a stale tracked-Path pin if THIS line was pinned (QR-P5, 2026-06-10).
function evercraft:grand_quests/untrack_on_finish {slot:5}
