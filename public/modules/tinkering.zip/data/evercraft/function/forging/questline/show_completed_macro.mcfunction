# ============================================================
# The Smith's Questline — Show completed (macro body)
# ============================================================
# Called `with storage evercraft:fgq_cur o`, o = the quest that was just done.
# Mirrors the Cooking/Fisher show_completed: green checkmark + quest title.
$data modify storage evercraft:notify stage.c set value [{text:"✔ ",color:"green"},{text:"Quest $(id) Complete — $(title)",color:"green"},{text:" ✔",color:"green"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
