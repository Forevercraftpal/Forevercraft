# ============================================================
# The Smith's Questline — get_quest macro body
# ============================================================
# Called with storage evercraft:fgq_cur containing {idx:<0-based index>}.
# Copies registry quest[idx] into evercraft:fgq_cur quest.
$data modify storage evercraft:fgq_cur quest set from storage evercraft:fgq_registry quests[$(idx)]
