# ============================================================
# The Smith's Questline — Advance (complete current quest -> next)
# ============================================================
# Run as @s = the player. Called by forging/questline/check when the active quest
# is satisfied, OR by quest_pacing/do_skip (the [Skip ▸] button, full reward).
# WRITER of the linear pointer (ec.fgq_quest), ec.fgq_prog reset, ec.fgq_done,
# ec.fgq_complete.
#
# Order: show_completed -> reward -> bump pointer (clamped) -> reset prog ->
#        +1 done -> load next quest -> show_objective. Final quest -> a one-shot
#        "line complete!" tellraw, pointer clamped at N.

# --- Idempotency / out-of-range guards (mirror the Cooking/Fisher upper-bound guard) ---
execute unless score @s ec.fgq_active matches 1 run return 0
execute if score @s ec.fgq_complete matches 1 run return 0

# Registry length = N (the last valid quest index). Dynamic so the engine never
# hardcodes the quest count — it grows automatically as batches are added.
execute store result score #fgq_n ec.temp run data get storage evercraft:fgq_registry quests
# Defensive: if the registry failed to load (length 0), do nothing.
execute if score #fgq_n ec.temp matches ..0 run return 0
# If the pointer is somehow already past N, clamp + finish (don't run past the end).
execute if score @s ec.fgq_quest > #fgq_n ec.temp run function evercraft:forging/questline/finish
execute if score @s ec.fgq_quest > #fgq_n ec.temp run return 0

# === 1) SHOW WHAT WAS JUST COMPLETED (fgq_cur still holds the old quest) ===
function evercraft:forging/questline/show_completed

# === 2) PAY OUT THE REWARD for the completed quest ===
function evercraft:forging/questline/reward

# === 2b) ADDITIVE: grant per-quest progress toward the Blacksmith advantage tree ===
# On TOP of the reward above (never replacing it). Feeds adv.stat_forge (the
# tree's grind requirement); the player still spends vanilla XP via the GUI to
# realize each level — adv.req_xp / prestige stay intact. See tree_credit header.
function evercraft:forging/questline/tree_credit

# === 3) ADVANCE THE LINEAR POINTER + COUNTERS ===
scoreboard players add @s ec.fgq_quest 1
scoreboard players set @s ec.fgq_prog 0
scoreboard players add @s ec.fgq_done 1

# === 4) FINAL-QUEST HANDLING ===
# If the new pointer exceeds N, the player just finished the LAST quest. Detect
# the overflow FIRST (into a flag), then clamp the pointer back to N (so a future
# check can't index out of range) and run the one-shot completion fanfare.
scoreboard players set #fgq_overflow ec.temp 0
execute if score @s ec.fgq_quest > #fgq_n ec.temp run scoreboard players set #fgq_overflow ec.temp 1
execute if score #fgq_overflow ec.temp matches 1 run scoreboard players operation @s ec.fgq_quest = #fgq_n ec.temp
execute if score #fgq_overflow ec.temp matches 1 run function evercraft:forging/questline/finish

# Not finished: load the next quest into fgq_cur and show its objective (paced).
execute if score #fgq_overflow ec.temp matches 0 run function evercraft:forging/questline/get_quest
execute if score #fgq_overflow ec.temp matches 0 run function evercraft:forging/questline/on_advance_notify
