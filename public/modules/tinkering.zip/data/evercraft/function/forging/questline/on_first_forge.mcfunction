# ============================================================
# The Smith's Questline — First-forge trigger (auto-give book + start)
# ============================================================
# Run as @s = the player, from the ONE gate-first line spliced into
# craftforever/forging/minigame/resolve (`if score @s ec.fgq_active matches 0 run
# ...`). resolve is the single funnel every completed forge passes through (it pays
# the cat-5 add_xp on every result), so it is the correct, robust "first forge"
# detector — the forge is entirely GUI/minigame-driven. Mirrors
# cooking/questline/on_first_meal (first meal -> start), but the trigger is the
# first FORGE rather than first meal.
#
# DUP-GUARDED by the resolve gate (ec.fgq_active matches 0) AND again here, so a
# re-entrant call past activation is a no-op. Gives the Smith's Codex (book/give is
# itself inventory-dup-guarded) then starts the line at quest 1.

# Defensive re-guard (resolve already gated on ec.fgq_active matches 0).
execute if score @s ec.fgq_active matches 1 run return 0

# Hand the player their Smith's Codex (book/give dup-guards on inventory contents).
function evercraft:forging/questline/book/give

# Begin the line at quest 1 (start seeds the ec.fgq_seen cursor + shows the intro).
function evercraft:forging/questline/start
