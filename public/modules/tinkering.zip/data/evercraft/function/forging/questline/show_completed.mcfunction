# ============================================================
# The Smith's Questline — Show completed quest (just-finished one)
# ============================================================
# Reads the just-completed quest from fgq_cur.quest (still the OLD quest at this
# point in advance, before the pointer is bumped) and prints a green checkmark
# line. Mirrors the Cooking/Fisher show_completed tone.
# Run as @s = the player.

data modify storage evercraft:fgq_cur o set from storage evercraft:fgq_cur quest
function evercraft:forging/questline/show_completed_macro with storage evercraft:fgq_cur o
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.player.levelup master @s ~ ~ ~ 0.4 1.8
