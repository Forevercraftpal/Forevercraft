# FGQ check helper — forge_count_at (lifetime items forged). Catch-up beat.
# @s = player. Reads the LIFETIME forge counter ach.artifacts_forged DIRECTLY, so a
# fresh op whose lifetime forges already clear the count auto-satisfies on the next
# 20t check_progress tick and pays full reward (R1 veteran catch-up — no re-grinding).
# The reward is a constant per quest, so this can't be farmed; the forward-only
# ec.fgq_quest cursor (one advance per satisfied beat) blocks retro double-credit.
#
# READ-ONLY: reads ach.artifacts_forged (craftforever-owned). Writes NO craftforever/
# forging/ engine objective.
scoreboard players set #fgq_satisfied ec.temp 0
execute if score @s ach.artifacts_forged >= #fgq_count ec.temp run scoreboard players set #fgq_satisfied ec.temp 1
