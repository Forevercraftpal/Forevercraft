# ============================================================
# The Smith's Questline — One-time scoreboard objective declarations.
# (Structural clone of cooking/questline/declare_objectives, Council #2 Wave C4 —
#  the Forging book line; bridges into the Tinkering line at the grandforge chapter.)
#  Split from forging/questline/load so the per-/reload "Objective already exists"
#  warnings only fire once. Gated by `#fgq_loaded ec.var matches 1` — set at the
#  bottom of this file.
# ============================================================
# A paced, always-skippable Forging quest line: a sibling Fisher's clone that only
# READS public forging state (ach.artifacts_forged, ec.cf_axp_forge). It WRITES none
# of craftforever/forging/'s engine objectives — the no-write proof. It is pacing-
# aware from the start (lore/beat/skippable) — see check.mcfunction (interlude
# guard), on_advance_notify + overview (render_lore), and the registry rows that
# carry `lore`.
#
# NOTE: ec.fg_* is partly OCCUPIED by the live forge engine (ec.fg_lastx/progress/
# timer, etc.). This line uses the council-locked ec.fgq_* family ONLY.

# === CORE LINEAR-POINTER SCOREBOARDS (mirror ec.cq_*; one writer each) ===
# ec.fgq_active — 0/1, has this player started the Smith's line?
#   WRITER: forging/questline/start (sets 1).
scoreboard objectives add ec.fgq_active dummy "Forge Questline Active"
# ec.fgq_quest — current quest index, 1..N. The ONLY linear pointer.
#   WRITER: forging/questline/start (sets 1) + forging/questline/advance (+1, clamped at N).
scoreboard objectives add ec.fgq_quest dummy "Forge Quest Index"
# ec.fgq_prog — progress within the current quest, surfaced ONLY in the overview
#   progress bar. The Forging check types are all READ-DERIVED (they compute their
#   satisfied condition from a public mirror + the ec.fgq_seen cursor into ec.temp,
#   never persisting a per-forge tally), so the single persistent writer of fgq_prog
#   is the reset path — keeping it strictly one-writer.
#   WRITER (reset to 0): forging/questline/start + forging/questline/advance.
#   WRITER (live mirror for the bar): forging/questline/check_progress re-syncs it
#     to the present-beat delta (one writer, on the 20t loop).
scoreboard objectives add ec.fgq_prog dummy "Forge Quest Progress"
# ec.fgq_done — lifetime completed quest count (overview + the ec.gq_track value).
#   WRITER: forging/questline/advance (+1) + forging/questline/start (sets 0 on first start).
scoreboard objectives add ec.fgq_done dummy "Forge Quests Done"
# (NO ec.fgq_title — per the wave spec the Forging line rewards only xp/coins/crate.
#  ALL forge-prestige identity comes from elsewhere; no reward_type/title file
#  exists in this engine.)

# === COMPLETION SENTINEL ===
# ec.fgq_complete — 0/1, set once when the player finishes the final quest so the
#   "line complete!" tellraw fires exactly once. WRITER: forging/questline/advance
#   (via finish) + forging/questline/start (sets 0 on first start).
scoreboard objectives add ec.fgq_complete dummy "Forge Quest Complete"

# === LIFETIME-THRESHOLD CATCH-UP CURSOR (forward-only, no-penalty) ===
# ec.fgq_seen — snapshot of ach.artifacts_forged taken at start. The present-action
#   `forged_item` beat reads (ach.artifacts_forged - this) as the count of items
#   forged SINCE the line began, so pre-activation forges never retro-credit the
#   present beat (forward cursor). The `forge_count_at`/`forge_xp_at` catch-up TYPES
#   read their lifetime mirror DIRECTLY, so a veteran auto-passes at full reward.
#   WRITER: forging/questline/start (seeds it) + forging/questline/check_progress
#   (re-syncs the live ec.fgq_prog delta).
scoreboard objectives add ec.fgq_seen dummy "FGQ Forge-Count Cursor"

# Mark declarations done so re-/reload skips this file.
scoreboard players set #fgq_loaded ec.var 1
