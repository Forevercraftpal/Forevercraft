# The Smith's Tome — CODEX UNLOCK (book retired, Joseph 2026-06-11)
# The seven questline tomes became codex unlocks ("too many books are given").
# This fn keeps every existing caller but no longer hands out an item: it stamps
# ec.qlb_forge once and toasts the catalyzation. Legacy books already in pockets
# still open their overview via the untouched on_use handler. ec.qlb_forge is the
# gating contract for the codex Questlines tab (parked — 10-pending QB-CDX-1).
execute if score @s ec.qlb_forge matches 1 run return 0
scoreboard players set @s ec.qlb_forge 1
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"#E67E22"},{text:"The Smith's Tome",color:"#E67E22"},{text:" has been catalyzed into your Codex.",color:"gray"}]
scoreboard players set #ndur ec.temp 50
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:item.book.page_turn master @s ~ ~ ~ 0.7 1.2
