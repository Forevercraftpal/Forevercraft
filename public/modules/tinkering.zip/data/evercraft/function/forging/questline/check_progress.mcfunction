# ============================================================
# The Smith's Questline — 20t catch-up / interlude scheduler
# ============================================================
# Self-rescheduling, EXISTENCE-GATED 20t loop (kicked from forging/questline/load
# with `replace`). It does work ONLY for players on the line
# (@a[scores={ec.fgq_active=1,ec.fgq_complete=0}]), so with no Forging players it
# iterates over NOTHING — no per-tick @a scan (the datapack's perf law).
#
# Two jobs per active player (both via the existing, idempotent check chain):
#   1. CATCH-UP (R1): a `forge_count_at`/`forge_xp_at` beat whose lifetime threshold
#      the player's mirror already clears auto-satisfies on this tick and pays full
#      reward — a veteran is never walled. Those helpers read the lifetime mirror
#      directly (no per-forge hook needed for catch-up).
#   2. INTERLUDE auto-pass (C0, SCHEMA_DELTA §3): a beat:"interlude"/count:0 beat is
#      instantly satisfied by check()'s interlude guard, so it advances here on the
#      next tick — delivering its lore once, paying its tiny reward once.
#
# The forward-only ec.fgq_quest cursor (one advance per satisfied beat, inside
# advance) makes this no-double-credit and no-penalty.

# === RUN THE CHECK FOR EVERY ACTIVE, NON-COMPLETE PLAYER ===
# (check() is itself existence-gated + idempotent; the outer selector keeps the
#  per-tick cost zero when nobody is on the line.)
execute as @a[scores={ec.fgq_active=1,ec.fgq_complete=0}] run function evercraft:forging/questline/check

# === RE-SYNC THE OVERVIEW PROGRESS BAR (fgq_prog, one writer) ===
# Keep ec.fgq_prog mirroring the present-beat forge-count delta for active players,
# so the overview's live progress bar reads true for `forged_item` beats. This is
# the ONLY persistent writer of fgq_prog besides the reset path — strictly one-writer.
# Computed per active @s: fgq_prog = ach.artifacts_forged - ec.fgq_seen (clamped at 0
# via the seed, which is always <= ach.artifacts_forged). Harmless for non-forged_item
# beats (the bar just shows the forges-since-start delta, a meaningful "you're
# forging" indicator). No-op for non-active players via the selector.
execute as @a[scores={ec.fgq_active=1,ec.fgq_complete=0}] run scoreboard players operation @s ec.fgq_prog = @s ach.artifacts_forged
execute as @a[scores={ec.fgq_active=1,ec.fgq_complete=0}] run scoreboard players operation @s ec.fgq_prog -= @s ec.fgq_seen

# Re-schedule self.
schedule function evercraft:forging/questline/check_progress 20t replace
