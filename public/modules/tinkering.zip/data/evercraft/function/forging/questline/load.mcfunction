# ============================================================
# The Smith's Questline — Load (objective declarations + registry + schedule)
# ============================================================
# A strictly-linear, data-driven quest line (q1..N in order, one active quest at
# a time), structural clone of cooking/questline/load. Called from init (the pack
# load host) on /reload — see init.mcfunction "SMITH'S QUESTLINE" block.
#
# NAMESPACE LOCK (Council #2): the live forge engine objectives are ec.fg_*/ec.cf_*
# (partly OCCUPIED — ec.fg_lastx etc.). This questline uses the council-locked
# ec.fgq_* family ONLY (Forging Questline) — never ec.fg_*.
#
# Declarations are guarded by #fgq_loaded ec.var so subsequent /reloads skip the
# re-declaration spam, matching questline/load's P6 polish.
#
# After declaring objectives, this fn ALWAYS (re)loads the registry (the quest
# data storage is NOT persisted across /reload) and (re)kicks the 20t catch-up
# scheduler with `replace` (so /reload never stacks duplicate schedules).

# === ONE-TIME OBJECTIVE DECLARATIONS (skipped on subsequent /reloads) ===
execute unless score #fgq_loaded ec.var matches 1 run function evercraft:forging/questline/declare_objectives

# === REGISTRY (re)load — storage is volatile across /reload, must re-run ===
function evercraft:forging/questline/registry/load

# === 20t CATCH-UP / INTERLUDE SCHEDULER (self-rescheduling, existence-gated) ===
# check_progress only does work for @a[scores={ec.fgq_active=1}] — no per-tick @a
# scan when nobody is on the line. It re-schedules itself; kick once here.
schedule function evercraft:forging/questline/check_progress 20t replace
