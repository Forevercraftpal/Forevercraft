# ============================================================
# The Smith's Questline — ADDITIVE advantage-tree credit (per-quest)
# ============================================================
# Run as @s = the player, from forging/questline/advance immediately AFTER the
# existing `reward` call. This is the ADDITIVE XP/Reward-Economy layer (Joseph
# 2026-06-01, _council/2026-06-01-chronicles/XP-REWARD-ECONOMY.md): it ADDS a
# second reward — progress toward the BLACKSMITH advantage tree (adv.blacksmith,
# tree id 12, prestige adv.pres_blac) — on TOP of the existing per-quest reward.
# It NEVER removes, reduces, or replaces the existing reward.
#
# HOW it grants (spec: "via the tree's NORMAL level-up gate — award the progress
# the tree consumes, NOT a raw `scoreboard set adv.blacksmith`"): it adds to the
# tree's GRIND-side stat scoreboard `adv.stat_forge` (the same counter the
# blacksmith level-up gate reads via advantage/calc/blacksmith -> adv.req_stat).
# The player still spends their own vanilla XP and clicks the existing GUI to
# realize each level, so adv.req_xp / prestige / do_prestige stay fully intact.
#
# ONE-WRITER NOTE: adv.stat_forge is an ESTABLISHED multi-writer stat counter
# (written by forge engine, grant_tree_credit, etc.) — the one-writer law applies
# to NEW scoreboards, not these shared advantage-stat counters. Feeding it from
# the questline matches the existing grant_tree_credit / cooking pattern.
#
# Sizing — PHASE-3 RE-TUNE (Joseph 2026-06-01, council A2/A3; this UNIFIES forging
# onto the single mult/2 curve shared with chemistry AND cooking — all three trees
# have mult 50 and 14-quest lines, so all three now grant a flat 25/quest on ONE
# curve. Forging's value was ALREADY +25 (correct); chemistry/cooking dropped
# 300->25 to MEET it. No numeric change here — only this rationale block is rewritten
# off the old false "shrinking-fraction" model onto the cumulative-threshold truth):
#   The gate is a CUMULATIVE LIFETIME THRESHOLD — adv.stat_forge is a pure `+=`
#   accumulator and the level-up gate NEVER subtracts it. To reach level L total the
#   player needs lifetime stat >= cum(L) = mult * L*(L+1)/2 = 25*L*(L+1)
#   (mult_blacksmith=50). Because nothing is ever spent, every per-quest credit
#   stacks on the lifetime total, so a flat input keeps clearing a SHRINKING fraction
#   of the growing (L+1)*mult per-level wall — the engine produces the "gentle ramp"
#   OUTPUT automatically. No input tiering needed.
#   Authored flat credit = mult/2 = 25/quest, sized against the PIONEER baseline
#   (req_stat unscaled):
#     q12  -> 12*25 = 300 stat = cum(L3) (25*3*4=300) -> EXACTLY 3 levels by q12.
#     14q  -> 350 stat = ~L3.2 (full line ≈ half a prestige).
#     250q -> 6250 stat ≈ cum(L24.5) ≈ 0.96 prestige -> "~250 quests ≈ 1 prestige".
#   Newcomer (÷10) / Adventurer (÷5) divide req_stat, so the same 25/quest goes
#   10x / 5x further — those modes level the tree correspondingly faster, by design.
#   adv.stat_forge is NOT in the 5s sync `=` clobber path (only adv.stat_fish is),
#   so the `+=` credit survives — forging needs NO in-tick realize (unlike fishing).

# Grant the flat per-quest credit toward the blacksmith grind requirement.
scoreboard players add @s adv.stat_forge 25
