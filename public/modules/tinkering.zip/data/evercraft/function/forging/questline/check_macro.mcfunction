# ============================================================
# The Smith's Questline — Check (macro body, dispatch on quest.type)
# ============================================================
# Called `with storage evercraft:fgq_cur o`, o = current quest
#   {id,title,desc,type,target,count,reward,reward_amt,chapter,...}.
# Sets #fgq_satisfied ec.temp to 1 iff the active quest's completion condition is
# met. Run as @s = the player.
#
# A macro can't branch on an int comparison inline, so we expose the threshold to
# ec.temp and route the per-TYPE decision to a tiny helper file:
#   - #fgq_count ec.temp     = quest.count
# The helper at check_type/$(type) reads its OWN public mirror (ach.artifacts_forged
# minus the ec.fgq_seen cursor / ec.cf_axp_forge) and sets #fgq_satisfied ec.temp.
# All helpers are READ-ONLY: they never write a craftforever/forging/ engine
# objective (the no-write proof).

# Expose the threshold for the helpers to compare against.
$scoreboard players set #fgq_count ec.temp $(count)

# Per-type decision (sets #fgq_satisfied ec.temp). $(type) is one of:
#   forged_item | forge_count_at | forge_xp_at
$function evercraft:forging/questline/check_type/$(type)
