# ============================================================
# Grand Quests — Fusion-Offer Load (scoreboard objective declarations)
# (Grand Convergence Wave 5 / Chronicles Wave W5 — the canonical book+offer
#  TEMPLATE the crafter books clone. L3 "Grand Quests UI" seat owns ec.gq_offered
#  + ec.gq_fused — see SYNTHESIS §1 spine table: owner=codex-ux, sole writers
#  offer_prompt / accept_fusion.)
# ============================================================
# Declares the two one-time fusion-offer flags. Hosted off init (the pack load
# entry). Guarded by #gq_loaded ec.var so subsequent /reloads skip the
# "Objective already exists" spam, matching the declare_objectives P6 polish.
#
# These two objectives are PERSISTENT player state (one-shot latches), so unlike
# a volatile registry there is NO re-load step here — just the guarded declare.

# === ONE-TIME OBJECTIVE DECLARATIONS (skipped on subsequent /reloads) ===
execute if score #gq_loaded ec.var matches 1 run return 0

# ec.gq_offered — 0/1 latch: has the one-time fuse OFFER been dispatched to this
#   player yet? SOLE WRITER: gq/offer_prompt (sets 1 the first time the fishing
#   book is obtained). Once 1, the offer never re-fires — a re-give on book loss
#   does NOT re-prompt, and declining (ignoring) the offer never re-fires either.
scoreboard objectives add ec.gq_offered dummy "Grand-Quest Fuse Offered"

# ec.gq_fused — 0/1 latch: has the player accepted the fusion? SOLE WRITER:
#   gq/accept_fusion (sets 1 when the [Fuse my quest books ->] button is clicked).
#   This is COSMETIC + anti-re-offer ONLY — it is NOT a hub gate (the Grand Quests
#   hub routes to FC section 26 whether or not fused; post-fusion the 2-tier hub
#   merely shows a "fused" banner). Default per round-1 SYNTHESIS L3.
scoreboard objectives add ec.gq_fused dummy "Grand-Quest Fused"

# Mark declarations done so re-/reload skips this file.
scoreboard players set #gq_loaded ec.var 1
