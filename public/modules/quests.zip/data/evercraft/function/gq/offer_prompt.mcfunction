# ============================================================
# Grand Quests — One-time Fusion OFFER prompt
# ============================================================
# Run as @s = the player. Called from fishing/questline/book/give (the moment the
# player first OBTAINS the fishing quest book — the canonical book+offer template
# every crafter book clones). Fires the ONE-TIME Seven-voice offer to fuse all the
# player's quest books into the Grand Quests codex.
#
# LATCH: gated on ec.gq_offered matches 0 by the CALLER (book/give) AND re-guarded
# here, so a re-give on book loss can never re-prompt. We set ec.gq_offered 1 at
# the END so a mid-function failure doesn't permanently swallow the offer.
#
# IMMERSION LAW (no /trigger): the accept affordance is a clickable chat button
# whose click_event runs the gq/accept_fusion function directly (the locked
# "fusion offer surface" default — round-1 DECISIONS: clickable chat prompt with a
# function click_event, lighter than an in-codex banner). Declining = simply not
# clicking; the offer never re-fires (ec.gq_offered latch). Mirrors the
# chronicle/overview + digest_features [tap to view]/[show me] precedent.
#
# NOTIFY (alert class, mute_at:99): the Seven-voice chime/flash routes through the
# shared util/notify/dispatch layer (key "gq_fuse") so it respects the player's
# global ec.notify filter. mute_at:99 means the [Mute] button effectively never
# appears — this is a one-shot offer, not a repeating nudge, so there is nothing
# to mute. The clickable [Fuse ->] button below is INDEPENDENT of the chatter
# gate: a player who has notifications OFF still gets the offer line + can fuse.

# === Re-guard the latch (caller already gated; defensive against re-entry) ===
execute if score @s ec.gq_offered matches 1 run return 0

# === 1) MUTABLE Seven-voice OFFER nudge (alert class) ===
function evercraft:util/notify/dispatch {key:"gq_fuse",class:"alert",mute_at:99}
# Only the chime/flash respects the dispatcher's approval (global ec.notify filter).
execute if score #notif_show_gq_fuse ec.temp matches 1 run title @s times 8 50 12
execute if score #notif_show_gq_fuse ec.temp matches 1 run title @s subtitle {text:"A convergence is possible",color:"gold",italic:true}
execute if score #notif_show_gq_fuse ec.temp matches 1 if score @s ec.fx_snd matches 1.. run playsound minecraft:block.amethyst_block.resonate master @s ~ ~ ~ 0.8 1.2

# === 2) THE OFFER itself (always shown — independent of the chatter chime) ===
# A quiet Seven-voice card. The [Fuse my quest books ->] button is the one
# interaction-driven affordance (function click_event, non-op-safe per the
# chronicle/overview precedent). One-shot: it can be clicked once; clicking it
# runs gq/accept_fusion which sets ec.gq_fused 1 and confirms.
tellraw @s ""
tellraw @s [{text:"  ✦ ",color:"gold"},{text:"The Grand Convergence",color:"gold",bold:true,italic:false}]
tellraw @s [{text:"  Your quest books need not stay scattered.",color:"gray",italic:true}]
tellraw @s [{text:"  I can bind every Path you walk — Fisher,",color:"gray",italic:true}]
tellraw @s [{text:"  Cook, Smith, and the rest — into a single",color:"gray",italic:true}]
tellraw @s [{text:"  Grand Quests codex. One ledger for all.",color:"gray",italic:true}]
tellraw @s ""
tellraw @s [{text:"  ",color:"dark_gray"},{text:"[Fuse my quest books →]",color:"#FFD479",bold:true,hover_event:{action:"show_text",value:[{text:"Bind your quest books into the Grand Quests codex.",color:"gray"},"",{text:"This is cosmetic — it changes nothing about your progress in any line, and only ever happens once.",color:"dark_gray",italic:true}]},click_event:{action:"run_command",command:"/function evercraft:gq/accept_fusion"}}]
tellraw @s [{text:"  ",color:"dark_gray"},{text:"(or simply walk on — the offer will not return)",color:"dark_gray",italic:true}]
tellraw @s ""

# === 3) LATCH the offer (sole writer of ec.gq_offered) ===
# Set LAST so a failure above doesn't permanently swallow a never-shown offer.
scoreboard players set @s ec.gq_offered 1
