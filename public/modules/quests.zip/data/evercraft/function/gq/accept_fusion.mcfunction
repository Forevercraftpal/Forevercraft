# ============================================================
# Grand Quests — Accept the Fusion (click_event target)
# ============================================================
# Run as @s = the player. The function click_event target of the [Fuse my quest
# books ->] button in gq/offer_prompt. SOLE WRITER of ec.gq_fused.
#
# IDEMPOTENT: if already fused, this is a silent no-op (clicking an old chat
# button from history must not re-confirm or re-play the sound). The offer is
# one-time (ec.gq_offered latch in offer_prompt), and the fuse itself is one-time
# (this guard) — so the convergence happens exactly once, ever.
#
# COSMETIC + anti-re-offer ONLY: ec.gq_fused is NOT a hub gate. The Grand Quests
# hub routes to FC section 26 whether or not fused (round-1 SYNTHESIS L3 default);
# post-fusion the 2-tier hub merely renders a "fused" banner. So this function
# writes its one latch + plays the confirmation, and nothing else changes
# mechanically.

# === IDEMPOTENCY GUARD (re-click from chat history = silent no-op) ===
execute if score @s ec.gq_fused matches 1 run return 0

# Unified UI-click FX (Joseph 2026-06-05): tellraw-option click — play the gated cue once on a real fuse
# (after the idempotency guard, so a stale re-click stays a silent no-op).
function evercraft:fx/ui/click

# === SET THE LATCH (sole writer) ===
scoreboard players set @s ec.gq_fused 1

# === CONFIRM (Seven-voice, one-shot) ===
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"Convergence complete.",color:"gold",bold:true,italic:false},{text:" ✦",color:"gold"}]
scoreboard players set #ndur ec.temp 50
function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Every Path you walk is now bound into your",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Grand Quests codex. Open it whenever you",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"wish — one ledger, all your journeys.",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 1.0 1.0
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.beacon.activate master @s ~ ~ ~ 0.5 1.4
