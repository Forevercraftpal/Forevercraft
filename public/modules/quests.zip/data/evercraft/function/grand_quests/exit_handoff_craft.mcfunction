# ============================================================
# Grand Quests — Craft-line exit handoff (Questline Restructure W4, 2026-06-10)
# ============================================================
# Run as @s INSIDE a craft line's one-shot finish (cooking/alchemy/forging/build/
# tinkering — each guarded by its own ec.*_complete sentinel, so this fires once
# per line). The no-dark-lines law: a finished Path hands the player its
# REPEATABLE continuation + 1 Trial Pass bridge gift, and nudges the Grand
# Chronicle the moment both branches qualify. Additive only — touches no
# capstone/prestige/reward logic above it.

# Where the craft keeps paying.
tellraw @s [{text:"  ⚒ ",color:"green"},{text:"The craft keeps paying:",color:"green",bold:true},{text:" the Trade Trials re-open every cycle — repeat clears pay 40% Artisan XP, the daily challenge asks no Pass at all.",color:"gray"}]

# Bridge gift: 1 Trial Pass (inv-full aware, give-or-drop law).
execute store result score #gch_inv_full ec.var run function evercraft:util/check_inv_full
execute if score #gch_inv_full ec.var matches 0 run loot give @s loot evercraft:craftforever/trials/trial_pass
execute if score #gch_inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:craftforever/trials/trial_pass
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"green"},{text:"A Trial Pass rides with the farewell.",color:"green"},{text:" ✦",color:"green"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit

# The Convergence nudge (only when unlocked and unstarted — the interweave moment).
function evercraft:grand_quests/unlock_check
execute unless score @s ec.gch_active matches 1.. if score #gch_unlocked ec.temp matches 1 run tellraw @s [{text:"  ",color:"gray"},{text:"[✦ Begin the Grand Chronicle →]",color:"#FFD479",bold:true,click_event:{action:"run_command",command:"/trigger ec.gq_trk set 60"},hover_event:{action:"show_text",value:{text:"Both chronicles are underway — the seam between them is ready to walk.",color:"gray"}}}]
