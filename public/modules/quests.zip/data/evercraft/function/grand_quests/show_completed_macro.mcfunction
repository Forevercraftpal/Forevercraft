# Grand Chronicle — show_completed macro body. Called with the beat object o.
$tellraw @s [{text:"  ✦ ",color:"gold"},{text:"Chronicle beat complete: ",color:"gray"},{text:"$(title)",color:"gold",bold:true}]
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.chime master @s ~ ~ ~ 0.8 1.4
