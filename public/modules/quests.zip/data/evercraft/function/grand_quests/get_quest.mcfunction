# Grand Chronicle — load the current beat (by 1-based pointer ec.gch_quest) into
# storage evercraft:gch_cur quest. Structural clone of tinkering/get_quest. Run as @s.
execute store result score #gch_idx ec.temp run scoreboard players get @s ec.gch_quest
scoreboard players remove #gch_idx ec.temp 1
execute store result storage evercraft:gch_cur idx int 1 run scoreboard players get #gch_idx ec.temp
function evercraft:grand_quests/get_quest_macro with storage evercraft:gch_cur
