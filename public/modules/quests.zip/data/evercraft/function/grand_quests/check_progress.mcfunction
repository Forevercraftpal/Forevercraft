# Grand Chronicle — 20t catch-up / interlude scheduler (structural clone of
# tinkering/check_progress; kicked from grand_quests/load_line with `replace`).
# Existence-gated: with nobody on the line the selector iterates over NOTHING
# (the datapack perf law). ec.gch_active=1 exactly — 2 = done, never re-scanned.
execute as @a[scores={ec.gch_active=1,ec.gch_complete=0}] run function evercraft:grand_quests/check
schedule function evercraft:grand_quests/check_progress 20t replace
