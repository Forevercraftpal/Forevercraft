# ============================================================
# Grand Chronicle — Finish (the Grand Convergence ceremony; one-shot)
# ============================================================
# Run as @s via advance overflow. WRITER: ec.gch_complete (1), ec.gch_active (2).
# Pays the convergence keepsake + coins, then HANDS OFF into both branches'
# repeatables (the questline-restructure exit law — no line goes dark).

execute if score @s ec.gch_complete matches 1 run return 0
scoreboard players set @s ec.gch_complete 1
scoreboard players set @s ec.gch_active 2

# Ceremony.
tellraw @s ""
tellraw @s [{text:"  ════════════════════════════",color:"gold"}]
tellraw @s [{text:"   ✦ ",color:"gold"},{text:"THE GRAND CONVERGENCE",color:"gold",bold:true},{text:" ✦",color:"gold"}]
tellraw @s [{text:"   Crafter and Adventurer, one cloth.",color:"gray",italic:true}]
tellraw @s [{text:"  ════════════════════════════",color:"gold"}]
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.beacon.activate master @s ~ ~ ~ 0.7 1.2
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 1.0 0.8
execute if score @s ec.fx_vis matches 1.. run particle minecraft:end_rod ~ ~1.2 ~ 0.4 0.6 0.4 0.05 40

# Keepsake: an exquisite Furnishings Crate (the home remembers the journey) + 25 coins.
execute store result score #gch_inv_full ec.var run function evercraft:util/check_inv_full
execute if score #gch_inv_full ec.var matches 0 run loot give @s loot evercraft:decor/crate_item/exquisite
execute if score #gch_inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:decor/crate_item/exquisite
scoreboard players add @s ec.coins 25
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"Convergence Keepsake",color:"gold",bold:true,italic:false},{text:" — an exquisite furnishing, and 25 coins.",color:"gray"},{text:" ✦",color:"gold"}]
scoreboard players set #ndur ec.temp 50
function evercraft:util/notify/emit

# Exit handoffs — where each chronicle keeps paying (the no-dark-lines law).
tellraw @s [{text:"  The seam holds. Where the cloth keeps growing:",color:"gray",italic:true}]
tellraw @s [{text:"   ⚒ ",color:"green"},{text:"Trade Trials",color:"green",bold:true},{text:" — every type re-opens each cycle; repeat clears pay 40% Artisan XP forever.",color:"gray"}]
tellraw @s [{text:"   ⚔ ",color:"red"},{text:"The Heroic board & patron bounties",color:"red",bold:true},{text:" — the village remembers its heroes, hour after hour.",color:"gray"}]
tellraw @s [{text:"   ★ ",color:"gold"},{text:"The Wayfarer's Pass",color:"gold",bold:true},{text:" — 250 nodes of the dreaming, never resetting, always waiting.",color:"gray"}]

# Clear a stale tracked-Path pin if THIS line was pinned (QR-P5, 2026-06-10).
function evercraft:grand_quests/untrack_on_finish {slot:11}
