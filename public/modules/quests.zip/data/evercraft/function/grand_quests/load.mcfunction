# ============================================================
# Grand Quests — Load (tracked-line pointer + the Grand Chronicle line)
# (Questline Restructure W1+W2, 2026-06-10 — builds round-1's deferred set_track
#  AND hosts the convergence line. Called from init beside gq/load.)
# ============================================================
# W1: declares ec.gq_track, the ONE persistent "which Path is pinned" pointer the
# pacing layer fans out on. SOLE WRITER: grand_quests/set_track. Slot map (FINAL):
#   1=Fisher's Path · 4=Cooking · 5=Forging · 6=Chemistry · 7=Build & Conquer ·
#   8=Build · 9=The Awakening · 10=Tinkering · 11=Grand Chronicle · 0=untracked.
#   (2/3 reserved from round-1. Trigger verbs: 50=pin menu · 60=begin Grand
#    Chronicle · 99=untrack — ec.gq_trk is declared in init's trigger block.)
# W2: declares the ec.gch_* family, re-loads the Grand Chronicle registry
# (volatile storage — re-seeded EVERY reload like every line registry), and kicks
# the existence-gated 20t check loop.

# ec.gq_cd = gametime-stamped click debounce shared by set_track + do_skip + do_skip_chapter
# + apply_mute (module-owned co-writers, QR-P4 pass 2026-06-10). Replaces the adv.gui_cd
# guard: adv.gui_cd only decays inside the codex hub tick, so a chat/book-surface click
# anywhere else left it stuck at 4 and silently swallowed every later pin/skip/toggle click
# until a codex open+close. Declared ABOVE the declare-once guard (re-add is a silent no-op)
# so worlds that already latched #gqt_loaded on an older build still get it.
scoreboard objectives add ec.gq_cd dummy "Quest Click Debounce"

# --- W1: tracked-line pointer (declare-once) ---
execute if score #gqt_loaded ec.var matches 1 run return run function evercraft:grand_quests/load_line
scoreboard objectives add ec.gq_track dummy "Tracked Quest Line"
scoreboard players set #gqt_loaded ec.var 1
function evercraft:grand_quests/load_line
