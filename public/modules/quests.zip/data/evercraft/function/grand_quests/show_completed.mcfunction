# Grand Chronicle — announce the just-completed beat (gch_cur still holds it). Run as @s.
data modify storage evercraft:gch_cur o set from storage evercraft:gch_cur quest
function evercraft:grand_quests/show_completed_macro with storage evercraft:gch_cur o
