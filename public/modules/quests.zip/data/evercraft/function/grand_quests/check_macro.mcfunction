# Grand Chronicle — check macro body (dispatch on quest.type). Called with storage
# evercraft:gch_cur o. Types: score_at_least (the only live type — every beat reads an
# existing public counter) | interlude (never reached; safety-net file exists).
$function evercraft:grand_quests/check_type/$(type) with storage evercraft:gch_cur o
