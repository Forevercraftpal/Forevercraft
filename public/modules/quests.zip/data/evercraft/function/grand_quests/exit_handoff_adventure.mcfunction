# ============================================================
# Grand Quests — Adventure-line exit handoff (Questline Restructure W4, 2026-06-10)
# ============================================================
# Run as @s INSIDE an adventure line's one-shot finish (awakening / kingdom — each
# guarded by its own ec.*_complete sentinel). The no-dark-lines law: where the
# adventure keeps paying, + the Grand Chronicle nudge. Additive only.

tellraw @s [{text:"  ⚔ ",color:"red"},{text:"The adventure keeps paying:",color:"red",bold:true},{text:" climb the village board to its Heroic tier, take patron bounties, and the dungeons re-open with every cycle.",color:"gray"}]

# The Convergence nudge (only when unlocked and unstarted — the interweave moment).
function evercraft:grand_quests/unlock_check
execute unless score @s ec.gch_active matches 1.. if score #gch_unlocked ec.temp matches 1 run tellraw @s [{text:"  ",color:"gray"},{text:"[✦ Begin the Grand Chronicle →]",color:"#FFD479",bold:true,click_event:{action:"run_command",command:"/trigger ec.gq_trk set 60"},hover_event:{action:"show_text",value:{text:"Both chronicles are underway — the seam between them is ready to walk.",color:"gray"}}}]
