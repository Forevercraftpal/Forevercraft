# ============================================================
# Grand Quests — Untrack on line completion (QR-P5, Joseph verdict 2026-06-10)
# ============================================================
# Run as @s from a line's one-shot finish with {slot:N}. If the player's pinned
# Path is the line that just COMPLETED, tell them and clear the pin (a finished
# line can't be skipped or re-pinned — leaving the ★ on it was dead weight).
# A writer of ec.gq_track (this file + set_track are the module-preferred writers,
# but the pointer is MULTI-WRITER — 16+ writers: every line's start auto-tracks
# and every line's finish auto-clears). Latest-line-wins; NOT a sole/single owner.
# Silent no-op when the finished line wasn't the pinned one.
data modify storage evercraft:notify stage.c set value [{text:"★ ",color:"gold"},{text:"Your tracked Path is complete.",color:"white"},{text:" Pin another from [★ Track a Path] whenever you wish.",color:"gray"},{text:" ★",color:"gold"}]
scoreboard players set #ndur ec.temp 45
$execute if score @s ec.gq_track matches $(slot) run function evercraft:util/notify/emit
$execute if score @s ec.gq_track matches $(slot) run scoreboard players set @s ec.gq_track 0
