# ============================================================
# Grand Quests — Untrack on line completion (QR-P5, Joseph verdict 2026-06-10)
# ============================================================
# Run as @s from a line's one-shot finish with {slot:N}. If the player's pinned
# Path is the line that just COMPLETED, tell them and clear the pin (a finished
# line can't be skipped or re-pinned — leaving the ★ on it was dead weight).
# MODULE-OWNED co-writer of ec.gq_track (this file + set_track, both in
# grand_quests/ — the pointer's single-owner module; documented exception).
# Silent no-op when the finished line wasn't the pinned one.
data modify storage evercraft:notify stage.c set value [{text:"★ ",color:"gold"},{text:"Your tracked Path is complete.",color:"white"},{text:" Pin another from [★ Track a Path] whenever you wish.",color:"gray"},{text:" ★",color:"gold"}]
scoreboard players set #ndur ec.temp 45
$execute if score @s ec.gq_track matches $(slot) run function evercraft:util/notify/emit
$execute if score @s ec.gq_track matches $(slot) run scoreboard players set @s ec.gq_track 0
