# Grand Chronicle — present the NEW current beat (paced). Run as @s; gch_cur holds it.
# Rides the shared pacing layer: copy the beat into qp_cur o, render_lore delivers the
# teaching lore line (mute-aware) + the law-compliant [Skip ▸] button.
data modify storage evercraft:gch_cur o set from storage evercraft:gch_cur quest
function evercraft:grand_quests/notify_macro with storage evercraft:gch_cur o
data modify storage evercraft:qp_cur o set from storage evercraft:gch_cur quest
function evercraft:quest_pacing/render_lore
