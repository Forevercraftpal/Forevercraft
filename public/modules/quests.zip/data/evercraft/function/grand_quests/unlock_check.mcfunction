# ============================================================
# Grand Chronicle — Unlock check (read-only; sets #gch_unlocked ec.temp)
# ============================================================
# The convergence asks for BOTH chronicles underway: one Crafter line at least 4 beats
# deep (or the Fisher's Path 10 quests deep) AND one Adventurer line begun in earnest
# (Awakening 4 beats / Build & Conquer 1). Pure reads of the per-line lifetime ec.*_done
# counters (declared at init by each line — a never-started player reads as unset, which
# `matches` treats as not-met; clean). Used by: pin_menu/overview [Begin] rows + start.
scoreboard players set #gch_unlocked ec.temp 0
scoreboard players set #gch_craft ec.temp 0
execute if score @s ec.cq_done matches 4.. run scoreboard players set #gch_craft ec.temp 1
execute if score @s ec.chq_done matches 4.. run scoreboard players set #gch_craft ec.temp 1
execute if score @s ec.fgq_done matches 4.. run scoreboard players set #gch_craft ec.temp 1
execute if score @s ec.bq_done matches 4.. run scoreboard players set #gch_craft ec.temp 1
execute if score @s ec.tnk_done matches 4.. run scoreboard players set #gch_craft ec.temp 1
execute if score @s ec.fq_done matches 10.. run scoreboard players set #gch_craft ec.temp 1
scoreboard players set #gch_adv ec.temp 0
execute if score @s ec.ac_done matches 4.. run scoreboard players set #gch_adv ec.temp 1
execute if score @s ec.ak_done matches 1.. run scoreboard players set #gch_adv ec.temp 1
execute if score #gch_craft ec.temp matches 1 if score #gch_adv ec.temp matches 1 run scoreboard players set #gch_unlocked ec.temp 1
