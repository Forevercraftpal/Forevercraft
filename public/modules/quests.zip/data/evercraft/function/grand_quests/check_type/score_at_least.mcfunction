# Grand Chronicle — check_type: score_at_least. Called with the beat object o:
# {target:"<objective>", count:N, ...}. READ-ONLY: satisfied iff @s target >= count.
# (The generic cross-system probe — every Grand Chronicle beat reads a verified live
# counter: ach.* family / dr.points / ec.wf_node. Veterans auto-pass at full reward.)
$execute if score @s $(target) matches $(count).. run scoreboard players set #gch_satisfied ec.temp 1
