# Grand Chronicle — check_type: interlude (safety net; never dispatched — check.mcfunction's
# interlude guard satisfies pure-lore beats before the per-type dispatch). No-op by design.
return 0
