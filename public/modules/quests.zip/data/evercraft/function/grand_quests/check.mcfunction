# ============================================================
# Grand Chronicle — Check (is the current beat satisfied?)
# (Structural clone of tinkering/check — interlude guard + per-type dispatch.)
# ============================================================
# Run as @s = the player, from the 20t check_progress loop ONLY. All check types are
# READ-DERIVED over existing public counters (score_at_least) — no per-action splice.

execute unless score @s ec.gch_active matches 1.. run return 0
execute if score @s ec.gch_complete matches 1 run return 0

function evercraft:grand_quests/get_quest
data modify storage evercraft:gch_cur o set from storage evercraft:gch_cur quest

# Snapshot the pointer (re-entrant same-tick double-call guard).
execute store result score #gch_q_before ec.temp run scoreboard players get @s ec.gch_quest

scoreboard players set #gch_satisfied ec.temp 0

# Interlude / count:0 auto-pass (BEFORE dispatch — pure-lore breathers).
execute if data storage evercraft:gch_cur o{beat:"interlude"} run scoreboard players set #gch_satisfied ec.temp 1
execute if data storage evercraft:gch_cur o{count:0} run scoreboard players set #gch_satisfied ec.temp 1

# Per-type dispatch (sets #gch_satisfied).
execute if score #gch_satisfied ec.temp matches 0 run function evercraft:grand_quests/check_macro with storage evercraft:gch_cur o

execute if score #gch_satisfied ec.temp matches 1 if score @s ec.gch_quest = #gch_q_before ec.temp run function evercraft:grand_quests/advance
