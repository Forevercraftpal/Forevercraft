# ============================================================
# Grand Quests — Fisher's Path exit handoff (QR-P6 flavor variant, 2026-06-10)
# ============================================================
# Run as @s inside fishing/questline/finish's one-shot guard. Same bones as the
# craft handoff (Trial Pass bridge + Convergence nudge) wearing water: the Path
# of a quarter-thousand quests ends, the water never does.

tellraw @s [{text:"  🎣 ",color:"aqua"},{text:"The water keeps paying:",color:"aqua",bold:true},{text:" splash nodes still rise, the depths still take a hook — and the fishing Trade Trial re-opens every cycle, repeat clears at 40% Artisan XP.",color:"gray"}]

# Bridge gift: 1 Trial Pass (inv-full aware, give-or-drop law).
execute store result score #gch_inv_full ec.var run function evercraft:util/check_inv_full
execute if score #gch_inv_full ec.var matches 0 run loot give @s loot evercraft:craftforever/trials/trial_pass
execute if score #gch_inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:craftforever/trials/trial_pass
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"aqua"},{text:"A Trial Pass rides the last tide in.",color:"aqua"},{text:" ✦",color:"aqua"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit

# The Convergence nudge (only when unlocked and unstarted).
function evercraft:grand_quests/unlock_check
execute unless score @s ec.gch_active matches 1.. if score #gch_unlocked ec.temp matches 1 run tellraw @s [{text:"  ",color:"gray"},{text:"[✦ Begin the Grand Chronicle →]",color:"#FFD479",bold:true,click_event:{action:"run_command",command:"/trigger ec.gq_trk set 60"},hover_event:{action:"show_text",value:{text:"Both chronicles are underway — the seam between them is ready to walk.",color:"gray"}}}]
