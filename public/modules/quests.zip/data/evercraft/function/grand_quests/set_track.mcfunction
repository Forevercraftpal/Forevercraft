# ============================================================
# Grand Quests — Set Track (SOLE writer of ec.gq_track)
# (Questline Restructure W1, 2026-06-10 — the round-1 deferred pin writer.)
# ============================================================
# Run as @s = the player, routed from util/trigger_dispatch on ec.gq_trk
# (the law-compliant clickable-button trigger — the [★ ...] buttons in the pin
# menu / chronicle overview; never a typed command). Reads the trigger VALUE:
#   1/4/5/6/7/8/9/10 (+11 once the Grand Chronicle line ships) -> pin that line
#     (only if the line is STARTED and not complete — gate `matches 1` exactly,
#     value 2 = done, a finished line can't be pinned)
#   50 -> open the pin menu (grand_quests/pin_menu)
#   99 -> untrack
# The trigger triad in util/trigger_dispatch resets ec.gq_trk AFTER this runs,
# so the value is readable here. Consumers: quest_pacing/do_skip{,_chapter}
# fan-outs, chronicle/overview ★ rows.

# --- Cooldown guard (prevents double-fire from click_event re-emission) ---
# Gametime-stamped (QR-P4 pass 2026-06-10): the old adv.gui_cd guard only decays inside the
# codex hub tick, but these buttons fire from chat (pin menu / chronicle overview / handoffs)
# and the questline book panel ANYWHERE — outside the codex the 4 never ticked down, so the
# first click swallowed every later pin/untrack/skip click until a codex open+close.
# ec.gq_cd = gametime until which clicks are ignored (shared with do_skip, module co-writer).
execute store result score #gqt_now ec.temp run time query gametime
execute if score @s ec.gq_cd > #gqt_now ec.temp run return 0
scoreboard players operation @s ec.gq_cd = #gqt_now ec.temp
scoreboard players add @s ec.gq_cd 4

# --- Menu / begin / untrack verbs ---
execute if score @s ec.gq_trk matches 50 run return run function evercraft:grand_quests/pin_menu
# 60 = [✦ Begin the Grand Chronicle →] (start re-verifies the unlock; stale buttons safe).
execute if score @s ec.gq_trk matches 60 run return run function evercraft:grand_quests/start
execute if score @s ec.gq_trk matches 99 run scoreboard players set @s ec.gq_track 0
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"aqua"},{text:"Path untracked.",color:"white"},{text:" Pin another whenever you wish — your progress never moves.",color:"gray"},{text:" ✦",color:"aqua"}]
scoreboard players set #ndur ec.temp 45
execute if score @s ec.gq_trk matches 99 run function evercraft:util/notify/emit
execute if score @s ec.gq_trk matches 99 run return 0

# --- Pin verbs: validate the slot's line is underway, then write the pointer ---
scoreboard players set #gqt_ok ec.temp 0
execute if score @s ec.gq_trk matches 1 if score @s ec.fq_active matches 1 run scoreboard players set #gqt_ok ec.temp 1
execute if score @s ec.gq_trk matches 4 if score @s ec.cq_active matches 1 run scoreboard players set #gqt_ok ec.temp 1
execute if score @s ec.gq_trk matches 5 if score @s ec.fgq_active matches 1 run scoreboard players set #gqt_ok ec.temp 1
execute if score @s ec.gq_trk matches 6 if score @s ec.chq_active matches 1 run scoreboard players set #gqt_ok ec.temp 1
execute if score @s ec.gq_trk matches 7 if score @s ec.ak_active matches 1 run scoreboard players set #gqt_ok ec.temp 1
execute if score @s ec.gq_trk matches 8 if score @s ec.bq_active matches 1 run scoreboard players set #gqt_ok ec.temp 1
execute if score @s ec.gq_trk matches 9 if score @s ec.ac_active matches 1 run scoreboard players set #gqt_ok ec.temp 1
execute if score @s ec.gq_trk matches 10 if score @s ec.tnk_active matches 1 run scoreboard players set #gqt_ok ec.temp 1
# (slot 11 = Grand Chronicle — its wave appends `if ec.gch_active matches 1` here when it ships)
execute if score @s ec.gq_trk matches 11 if score @s ec.gch_active matches 1 run scoreboard players set #gqt_ok ec.temp 1

# Not a pinnable slot / line not underway -> explain, offer the menu.
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"aqua"},{text:"That Path is not underway",color:"white"},{text:" — begin it (or finish pinning from the list) first.",color:"gray"},{text:" ✦",color:"aqua"}]
scoreboard players set #ndur ec.temp 45
execute if score #gqt_ok ec.temp matches 0 run function evercraft:util/notify/emit
execute if score #gqt_ok ec.temp matches 0 run return run function evercraft:grand_quests/pin_menu

# Write the pointer (sole writer).
scoreboard players operation @s ec.gq_track = @s ec.gq_trk

# --- Confirm (Seven-voice; names match the pin menu rows) ---
data modify storage evercraft:notify stage.c set value [{text:"★ ",color:"gold"},{text:"Path tracked.",color:"gold",bold:true,italic:false},{text:" [Skip ▸] and your Chronicle star now follow this line.",color:"gray"},{text:" ★",color:"gold"}]
scoreboard players set #ndur ec.temp 50
function evercraft:util/notify/emit
# Fisher caveat: catches can't be auto-granted, so the skip button stays inert there.
data modify storage evercraft:notify stage.c set value [{text:"The Fisher's Path advances by catches — the star marks it, but beats cannot be skipped.",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 45
execute if score @s ec.gq_track matches 1 run function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.7 1.6
