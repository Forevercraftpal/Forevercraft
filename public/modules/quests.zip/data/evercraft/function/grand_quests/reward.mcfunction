# Grand Chronicle — Reward (pay out the just-completed beat). Run as @s.
# gch_cur still holds the OLD beat (reward runs BEFORE advance bumps the pointer).
# Reward types: coins | crate (rtier) | loot (rloot path + reward_amt pulls, cap 3).
# Cross-branch by design: craft beats pay adventure-side and vice versa (registry law).
data modify storage evercraft:gch_cur o set from storage evercraft:gch_cur quest
function evercraft:grand_quests/reward_macro with storage evercraft:gch_cur o
