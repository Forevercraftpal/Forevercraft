# Grand Chronicle — get_quest macro body. Called with {idx:<0-based>}.
$data modify storage evercraft:gch_cur quest set from storage evercraft:gch_registry quests[$(idx)]
