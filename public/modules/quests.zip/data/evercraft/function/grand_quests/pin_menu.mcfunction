# ============================================================
# Grand Quests — Pin Menu (choose the tracked Path)
# (Questline Restructure W1, 2026-06-10.)
# ============================================================
# Run as @s = the player. A clean tellraw page listing every line the player has
# UNDERWAY (ec.<line>_active matches 1 — exactly; 2 = done, not pinnable) as
# law-compliant [★ ...] trigger buttons (trigger ec.gq_trk set <slot> — same
# affordance class as [Skip ▸]). Reached from: do_skip's no-track fallback,
# chronicle/overview's [★ Track a Path] footer button, set_track verb 50.
# READ-ONLY of every line pointer; writes nothing (set_track is the sole writer).

tellraw @s ""
tellraw @s [{text:"  ★ ",color:"gold"},{text:"Track a Path",color:"gold",bold:true},{text:" — [Skip ▸] and your Chronicle star follow the pinned line.",color:"gray",italic:true}]

# --- One row per UNDERWAY line (Crafter, then Adventurer, then universal) ---
execute if score @s ec.cq_active matches 1 run tellraw @s [{text:"   ",color:"gray"},{text:"[★ The Cook's Path]",color:"#7FB3FF",bold:true,click_event:{action:"run_command",command:"/trigger ec.gq_trk set 4"},hover_event:{action:"show_text",value:{text:"Pin the Cook's questline.",color:"gray"}}}]
execute if score @s ec.fgq_active matches 1 run tellraw @s [{text:"   ",color:"gray"},{text:"[★ The Smith's Path]",color:"#7FB3FF",bold:true,click_event:{action:"run_command",command:"/trigger ec.gq_trk set 5"},hover_event:{action:"show_text",value:{text:"Pin the Smith's questline.",color:"gray"}}}]
execute if score @s ec.chq_active matches 1 run tellraw @s [{text:"   ",color:"gray"},{text:"[★ The Chemist's Path]",color:"#7FB3FF",bold:true,click_event:{action:"run_command",command:"/trigger ec.gq_trk set 6"},hover_event:{action:"show_text",value:{text:"Pin the Chemist's questline.",color:"gray"}}}]
execute if score @s ec.bq_active matches 1 run tellraw @s [{text:"   ",color:"gray"},{text:"[★ The Build Quests]",color:"#7FB3FF",bold:true,click_event:{action:"run_command",command:"/trigger ec.gq_trk set 8"},hover_event:{action:"show_text",value:{text:"Pin the Build Quests line.",color:"gray"}}}]
execute if score @s ec.fq_active matches 1 run tellraw @s [{text:"   ",color:"gray"},{text:"[★ The Fisher's Path]",color:"#7FB3FF",bold:true,click_event:{action:"run_command",command:"/trigger ec.gq_trk set 1"},hover_event:{action:"show_text",value:{text:"Pin the Fisher's Path (star only — catches cannot be skipped).",color:"gray"}}}]
execute if score @s ec.ac_active matches 1 run tellraw @s [{text:"   ",color:"gray"},{text:"[★ The Awakening]",color:"#FF9B7F",bold:true,click_event:{action:"run_command",command:"/trigger ec.gq_trk set 9"},hover_event:{action:"show_text",value:{text:"Pin the Awakening (Adventurer).",color:"gray"}}}]
execute if score @s ec.ak_active matches 1 run tellraw @s [{text:"   ",color:"gray"},{text:"[★ Build & Conquer]",color:"#FF9B7F",bold:true,click_event:{action:"run_command",command:"/trigger ec.gq_trk set 7"},hover_event:{action:"show_text",value:{text:"Pin Build & Conquer (Adventurer).",color:"gray"}}}]
execute if score @s ec.tnk_active matches 1 run tellraw @s [{text:"   ",color:"gray"},{text:"[★ The Tinkerer's Path]",color:"#D7BFFF",bold:true,click_event:{action:"run_command",command:"/trigger ec.gq_trk set 10"},hover_event:{action:"show_text",value:{text:"Pin the Tinkerer's mini-line (universal).",color:"gray"}}}]
# Grand Chronicle (slot 11, W2): pin row when underway; BEGIN row when unlocked-but-unstarted.
execute if score @s ec.gch_active matches 1 run tellraw @s [{text:"   ",color:"gray"},{text:"[★ The Grand Chronicle]",color:"#FFD479",bold:true,click_event:{action:"run_command",command:"/trigger ec.gq_trk set 11"},hover_event:{action:"show_text",value:{text:"Pin the Grand Chronicle — the convergence of both chronicles.",color:"gray"}}}]
function evercraft:grand_quests/unlock_check
execute unless score @s ec.gch_active matches 1.. if score #gch_unlocked ec.temp matches 1 run tellraw @s [{text:"   ",color:"gray"},{text:"[✦ Begin the Grand Chronicle →]",color:"#FFD479",bold:true,click_event:{action:"run_command",command:"/trigger ec.gq_trk set 60"},hover_event:{action:"show_text",value:[{text:"Both chronicles are underway — the seam between them is ready to walk.",color:"gray"},"",{text:"16 beats. Always skippable. Rewards cross the branches.",color:"dark_gray",italic:true}]}}]

# --- Nothing underway at all? Point at the ways in. ---
scoreboard players set #gqt_any ec.temp 0
execute if score @s ec.cq_active matches 1 run scoreboard players set #gqt_any ec.temp 1
execute if score @s ec.fgq_active matches 1 run scoreboard players set #gqt_any ec.temp 1
execute if score @s ec.chq_active matches 1 run scoreboard players set #gqt_any ec.temp 1
execute if score @s ec.bq_active matches 1 run scoreboard players set #gqt_any ec.temp 1
execute if score @s ec.fq_active matches 1 run scoreboard players set #gqt_any ec.temp 1
execute if score @s ec.ac_active matches 1 run scoreboard players set #gqt_any ec.temp 1
execute if score @s ec.ak_active matches 1 run scoreboard players set #gqt_any ec.temp 1
execute if score @s ec.tnk_active matches 1 run scoreboard players set #gqt_any ec.temp 1
execute if score @s ec.gch_active matches 1 run scoreboard players set #gqt_any ec.temp 1
execute if score #gqt_any ec.temp matches 0 run tellraw @s [{text:"   No Path is underway yet. ",color:"gray",italic:true},{text:"Cast a rod, open a craft book, or answer the village board — every journey begins somewhere.",color:"dark_gray",italic:true}]

# --- Untrack row (only when something is pinned) ---
execute if score @s ec.gq_track matches 1.. run tellraw @s [{text:"   ",color:"gray"},{text:"[✕ Untrack]",color:"dark_gray",bold:true,click_event:{action:"run_command",command:"/trigger ec.gq_trk set 99"},hover_event:{action:"show_text",value:{text:"Clear the pin. No progress changes.",color:"gray"}}}]
tellraw @s ""
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:item.book.page_turn master @s ~ ~ ~ 0.6 1.2
