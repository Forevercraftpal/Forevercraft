# ============================================================
# Grand Chronicle — Start (begin the convergence line)
# ============================================================
# Run as @s = the player, via set_track verb 60 (the [✦ Begin the Grand Chronicle →]
# button in the pin menu / chronicle overview — law-compliant trigger affordance).
# Guards: not already on/past the line; unlock conditions verified HERE (defense in
# depth — the buttons only render when unlocked, but a stale chat button must not
# bypass the gate).

execute if score @s ec.gch_active matches 1.. run return 0
function evercraft:grand_quests/unlock_check
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"aqua"},{text:"The Convergence is not yet ready",color:"white"},{text:" — walk one Crafter Path (4 beats; Fisher 10) and one Adventurer Path (Awakening 4 / Build & Conquer 1) first.",color:"gray"},{text:" ✦",color:"aqua"}]
scoreboard players set #ndur ec.temp 50
execute if score #gch_unlocked ec.temp matches 0 run function evercraft:util/notify/emit
execute if score #gch_unlocked ec.temp matches 0 run return 0

# Seed the pointer family (one writer each — this file + advance/finish).
scoreboard players set @s ec.gch_active 1
scoreboard players set @s ec.gch_quest 1
scoreboard players set @s ec.gch_prog 0
scoreboard players set @s ec.gch_done 0
scoreboard players set @s ec.gch_complete 0

# Opening fanfare (Seven voice, non-bold body per popup law).
tellraw @s ""
tellraw @s [{text:"  ✦ ",color:"#FFD479"},{text:"The Grand Chronicle opens.",color:"#FFD479",bold:true}]
tellraw @s [{text:"  Two chronicles, one cloth — sixteen beats along the seam.",color:"gray",italic:true}]
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.amethyst_block.resonate master @s ~ ~ ~ 0.9 0.9
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.chime master @s ~ ~ ~ 0.8 1.2

# Present beat 1 (the interlude auto-passes on the next 20t tick, delivering its lore).
function evercraft:grand_quests/get_quest
function evercraft:grand_quests/on_advance_notify
