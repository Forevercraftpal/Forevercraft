# Grand Chronicle — beat-header macro body. Called with the beat object o.
$tellraw @s [{text:"  ✦ ",color:"#FFD479"},{text:"The Grand Chronicle — ",color:"gray"},{text:"$(title)",color:"#FFD479",bold:true}]
$execute unless data storage evercraft:gch_cur o{desc:""} run tellraw @s [{text:"     $(desc)",color:"white"}]
