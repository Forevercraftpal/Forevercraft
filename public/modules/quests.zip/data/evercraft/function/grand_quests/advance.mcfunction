# ============================================================
# Grand Chronicle — Advance (complete current beat -> next)
# (Structural clone of tinkering/advance; no additive tree layer — this is a
#  teaching/convergence line, NOT an XP faucet. XP-REWARD-ECONOMY.md untouched.)
# ============================================================
# Run as @s = the player. Called by check when the beat is satisfied, OR by
# quest_pacing/do_skip (slot 11, full reward). WRITER of ec.gch_quest, ec.gch_prog
# reset, ec.gch_done, ec.gch_complete (via finish).

execute unless score @s ec.gch_active matches 1.. run return 0
execute if score @s ec.gch_complete matches 1 run return 0

execute store result score #gch_n ec.temp run data get storage evercraft:gch_registry quests
execute if score #gch_n ec.temp matches ..0 run return 0
execute if score @s ec.gch_quest > #gch_n ec.temp run function evercraft:grand_quests/finish
execute if score @s ec.gch_quest > #gch_n ec.temp run return 0

# 1) Show what was just completed (gch_cur still holds the old beat).
function evercraft:grand_quests/show_completed

# 2) Pay the completed beat's reward.
function evercraft:grand_quests/reward

# 3) Advance the pointer + counters.
scoreboard players add @s ec.gch_quest 1
scoreboard players set @s ec.gch_prog 0
scoreboard players add @s ec.gch_done 1

# 4) Final-beat handling (overflow -> clamp -> one-shot finish).
scoreboard players set #gch_overflow ec.temp 0
execute if score @s ec.gch_quest > #gch_n ec.temp run scoreboard players set #gch_overflow ec.temp 1
execute if score #gch_overflow ec.temp matches 1 run scoreboard players operation @s ec.gch_quest = #gch_n ec.temp
execute if score #gch_overflow ec.temp matches 1 run function evercraft:grand_quests/finish

# Not finished: load + show the next beat (paced).
execute if score #gch_overflow ec.temp matches 0 run function evercraft:grand_quests/get_quest
execute if score #gch_overflow ec.temp matches 0 run function evercraft:grand_quests/on_advance_notify
