# Grand Chronicle reward — coins. $(reward_amt) Forever Coins (instant scoreboard grant,
# the quest-payout idiom — never touches another system's payout table). @s = player.
$scoreboard players add @s ec.coins $(reward_amt)
$data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"+$(reward_amt) Coins",color:"#E0B0FF"},{text:" ✦",color:"gold"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.experience_orb.pickup master @s ~ ~ ~ 0.6 1.0
