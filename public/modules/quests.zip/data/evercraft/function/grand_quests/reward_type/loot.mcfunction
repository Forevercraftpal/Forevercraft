# Grand Chronicle reward — generic loot gift: $(reward_amt) pulls (1-3) of the table at
# evercraft:$(rloot). The cross-branch gift channel (ingredients for the road, treats for
# the hunt). Inv-full aware per pull via loot-spawn fallback. @s = player.
execute store result score #gch_inv_full ec.var run function evercraft:util/check_inv_full
$scoreboard players set #gch_ramt ec.temp $(reward_amt)
$execute if score #gch_inv_full ec.var matches 0 if score #gch_ramt ec.temp matches 1.. run loot give @s loot evercraft:$(rloot)
$execute if score #gch_inv_full ec.var matches 0 if score #gch_ramt ec.temp matches 2.. run loot give @s loot evercraft:$(rloot)
$execute if score #gch_inv_full ec.var matches 0 if score #gch_ramt ec.temp matches 3.. run loot give @s loot evercraft:$(rloot)
$execute if score #gch_inv_full ec.var matches 1 if score #gch_ramt ec.temp matches 1.. at @s run loot spawn ~ ~ ~ loot evercraft:$(rloot)
$execute if score #gch_inv_full ec.var matches 1 if score #gch_ramt ec.temp matches 2.. at @s run loot spawn ~ ~ ~ loot evercraft:$(rloot)
$execute if score #gch_inv_full ec.var matches 1 if score #gch_ramt ec.temp matches 3.. at @s run loot spawn ~ ~ ~ loot evercraft:$(rloot)
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"green"},{text:"A gift crosses the seam — check your pack.",color:"green"},{text:" ✦",color:"green"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.experience_orb.pickup master @s ~ ~ ~ 0.6 1.2
