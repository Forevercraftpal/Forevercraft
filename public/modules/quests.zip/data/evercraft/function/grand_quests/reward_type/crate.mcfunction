# Grand Chronicle reward — a reward crate of tier $(rtier). Reuses the EXISTING shared
# crate table at evercraft:fishing/gameplay/fishing/crates/<tier>/1 (the build_quests
# precedent — no parallel crate tree). Inv-full aware (give-or-drop law). @s = player.
execute store result score #gch_inv_full ec.var run function evercraft:util/check_inv_full
$execute if score #gch_inv_full ec.var matches 0 run loot give @s loot evercraft:fishing/gameplay/fishing/crates/$(rtier)/1
$execute if score #gch_inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:fishing/gameplay/fishing/crates/$(rtier)/1
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"yellow"},{text:"Reward: a reward crate!",color:"yellow"},{text:" ✦",color:"yellow"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Inventory full! Your crate was dropped at your feet.",color:"yellow"}]
scoreboard players set #ndur ec.temp 45
execute if score #gch_inv_full ec.var matches 1 run function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.experience_orb.pickup master @s ~ ~ ~ 0.6 1.0
