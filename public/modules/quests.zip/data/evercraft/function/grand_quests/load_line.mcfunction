# ============================================================
# Grand Chronicle — line load (declare-once + registry re-seed + scheduler kick)
# (Questline Restructure W2, 2026-06-10. Called from grand_quests/load every reload.)
# ============================================================

# One-time ec.gch_* declarations (internally guarded).
function evercraft:grand_quests/declare_objectives

# Registry is VOLATILE storage — re-seed on every reload (mirror of every line registry).
data modify storage evercraft:gch_registry quests set value []
function evercraft:grand_quests/registry/load_batch_0

# Kick the existence-gated 20t check loop (replace = no double-schedule on reload).
schedule function evercraft:grand_quests/check_progress 20t replace
