# ============================================================
# Grand Chronicle (the convergence line) — One-time objective declarations
# (Questline Restructure W2, 2026-06-10. Structural clone of tinkering/declare_objectives.)
# ============================================================
# NAMESPACE LOCK: ec.gc_* is OCCUPIED (guild cards — ec.gc_prompt_cd). This line uses
# ec.gch_* ONLY. Guarded by #gch_loaded ec.var, set at the bottom.
#
# The Grand Chronicle is the "both chronicles path": a 16-beat teaching line that exists
# only ACROSS the two branches — every objective is a READ-ONLY score_at_least over an
# existing public counter (ach.* / dr.points / ec.wf_node), every reward leans toward the
# OPPOSITE branch, and the finale is the Grand Convergence ceremony. No new detection,
# no engine splices — the 20t check loop reads live counters (veterans auto-pass at full
# reward, the accepted pattern).

execute if score #gch_loaded ec.var matches 1 run return 0

# Core linear-pointer family (mirror ec.tnk_*; one writer each):
# ec.gch_active — 0/1/2. WRITER: grand_quests/start (1), finish via advance (2).
scoreboard objectives add ec.gch_active dummy "Grand Chronicle Active"
# ec.gch_quest — current beat index 1..N. WRITER: start (1) + advance (+1, clamped).
scoreboard objectives add ec.gch_quest dummy "Grand Chronicle Quest Idx"
# ec.gch_prog — overview progress scratch. WRITER (reset): start + advance.
scoreboard objectives add ec.gch_prog dummy "Grand Chronicle Progress"
# ec.gch_done — lifetime completed beats. WRITER: advance (+1) + start (0).
scoreboard objectives add ec.gch_done dummy "Grand Chronicle Done"
# ec.gch_complete — 0/1 one-shot completion sentinel. WRITER: finish + start (0).
scoreboard objectives add ec.gch_complete dummy "Grand Chronicle Complete"

scoreboard players set #gch_loaded ec.var 1
