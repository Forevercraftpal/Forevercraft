# Grand Chronicle — reward macro body (dispatch on quest.reward). Called with o.
$function evercraft:grand_quests/reward_type/$(reward) with storage evercraft:gch_cur o
