# Cancel Tier 5 (Expedition) Quest
# -60 reputation penalty
# Run as player

# Safety check — no quest to cancel
data modify storage evercraft:notify stage.c set value [{text:"You don't have an Expedition to cancel.",color:"gray"}]
scoreboard players set #ndur ec.temp 45
execute unless score @s ec.quest_id_5 matches 1.. run function evercraft:util/notify/emit
execute unless score @s ec.quest_id_5 matches 1.. run return 1

# Clear the quest
scoreboard players set @s ec.quest_id_5 0
scoreboard players set @s ec.quest_prog_5 0
scoreboard players set @s ec.exp_prog_5 0

# Wiring Audit #30 (C-F2): match the tracker direct_cancel re-accept cooldown
scoreboard players set @s ec.qc_cd_5 18000

# Apply reputation penalty
scoreboard players remove @s ec.village_rep 60
function evercraft:quests/reputation/save_village_rep

execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.item.break player @s ~ ~ ~ 0.5 0.8
data modify storage evercraft:notify stage.c set value [{text:"Expedition cancelled. ",color:"yellow"},{text:"-60 reputation.",color:"red"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
