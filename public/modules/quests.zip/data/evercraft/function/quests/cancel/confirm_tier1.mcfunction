# Cancel Tier 1 (Errand) Quest
# No reputation penalty for Errands
# Run as player

# Safety check — no quest to cancel
data modify storage evercraft:notify stage.c set value [{text:"You don't have an Errand to cancel.",color:"gray"}]
scoreboard players set #ndur ec.temp 45
execute unless score @s ec.quest_id_1 matches 1.. run function evercraft:util/notify/emit
execute unless score @s ec.quest_id_1 matches 1.. run return 1

# Clear the quest
scoreboard players set @s ec.quest_id_1 0
scoreboard players set @s ec.quest_prog_1 0

# Wiring Audit #30 (C-F2): set the same re-accept cooldown as the tracker direct_cancel path
# (was missing on the chat-prompt path — a re-accept throttle bypass).
scoreboard players set @s ec.qc_cd_1 6000

execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.item.break player @s ~ ~ ~ 0.5 0.8
data modify storage evercraft:notify stage.c set value [{text:"Errand cancelled.",color:"yellow"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
