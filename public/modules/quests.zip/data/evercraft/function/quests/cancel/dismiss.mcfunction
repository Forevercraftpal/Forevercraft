# Dismiss cancel prompt — keep the quest
# Run as player
data modify storage evercraft:notify stage.c set value [{text:"Quest kept. Good luck!",color:"green"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
