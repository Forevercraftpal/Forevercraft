# Cancel Tier 4 (Commission) Quest
# -40 reputation penalty
# Run as player

# Safety check — no quest to cancel
data modify storage evercraft:notify stage.c set value [{text:"You don't have a Commission to cancel.",color:"gray"}]
scoreboard players set #ndur ec.temp 45
execute unless score @s ec.quest_id_4 matches 1.. run function evercraft:util/notify/emit
execute unless score @s ec.quest_id_4 matches 1.. run return 1

# Clear the quest
scoreboard players set @s ec.quest_id_4 0
scoreboard players set @s ec.quest_prog_4 0
scoreboard players set @s ec.exp_prog_4 0

# Wiring Audit #30 (C-F2): match the tracker direct_cancel re-accept cooldown
scoreboard players set @s ec.qc_cd_4 12000

# Apply reputation penalty
scoreboard players remove @s ec.village_rep 40
function evercraft:quests/reputation/save_village_rep

execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.item.break player @s ~ ~ ~ 0.5 0.8
data modify storage evercraft:notify stage.c set value [{text:"Commission cancelled. ",color:"yellow"},{text:"-40 reputation.",color:"red"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
