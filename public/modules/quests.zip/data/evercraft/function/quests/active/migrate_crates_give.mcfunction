# Migration loop — re-give one canonical crate per cleared legacy item
# Run as: the receiving player (called by migrate_crates; #qcm ec.temp = remaining count)
$loot give @s loot $(table)
scoreboard players remove #qcm ec.temp 1
$execute if score #qcm ec.temp matches 1.. run function evercraft:quests/active/migrate_crates_give {table:"$(table)"}
