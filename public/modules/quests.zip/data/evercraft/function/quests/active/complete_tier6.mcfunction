# ============================================================
# Complete Tier 6 (Heroic) Quest
# ============================================================

scoreboard players set @s ec.quest_id_6 0
scoreboard players set @s ec.quest_prog_6 0
scoreboard players set @s ec.quest_expiry 0
scoreboard players set @s ec.quest_done_6 1
scoreboard players add @s ec.village_rep 500
experience add @s 1000 points
execute if score #cal_prosperity ec.var matches 1 run experience add @s 500 points
scoreboard players add @s adv.stat_quests 1
# Wayfarer Track: cross-source bonus XP (milestone credit on top of dr.points)
scoreboard players add @s ec.wf_bonus 5

# Taskmaster bonus: +4% XP/rep per level
execute if score @s adv.taskmaster matches 1.. run scoreboard players set #base_quest_xp adv.temp 1000
execute if score @s adv.taskmaster matches 1.. run scoreboard players set #base_quest_rep adv.temp 500
execute if score @s adv.taskmaster matches 1.. run function evercraft:advantage/taskmaster/apply_bonus

# Village specialization bonus (+25% rep at specialized villages)
scoreboard players set #vs_base_rep vs.temp 500
function evercraft:village/quest_bonus

# Save updated reputation to village-specific storage
function evercraft:quests/reputation/save_village_rep

# Grant Mythical Quest Crate — canonical crate item via util/give_quest_crate
# (qc_rarity custom_data drives the placed-barrel advancement -> crate_anim
#  skin/lock/auto-open; raw barrels never animate. Inv-full handled inside.)
function evercraft:util/give_quest_crate {tier:"mythical"}

# Check for Legend rank
function evercraft:quests/reputation/check_rank

# Epic celebration effects
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:ui.toast.challenge_complete player @s ~ ~ ~ 1 1
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.lightning_bolt.thunder player @s ~ ~ ~ 0.3 1.5
execute if score @s ec.fx_vis matches 1.. run particle totem_of_undying ~ ~1 ~ 1 1 1 0.3 50
effect give @s minecraft:glowing 10 0 true

# Announce to server (§5b: actor-named broadcast — render directly in the actor's context
# so {selector:"@s"} resolves to the completer, not each recipient; bypasses the queue)
function evercraft:util/notify/whoami
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"dark_purple"},{text:""},{text:" has completed a ",color:"gray"},{text:"HEROIC QUEST",color:"dark_purple"},{text:"! ✦",color:"dark_purple"}]
data modify storage evercraft:notify stage.c[1].text set from storage evercraft:notify named.who
scoreboard players set #ndur ec.temp 50
execute as @a run scoreboard players set #nttl ec.temp 600
execute as @a run function evercraft:util/notify/emit_keep

# Title for player
title @s times 10 70 30
title @s title {text:"HEROIC COMPLETE",color:"dark_purple"}
title @s subtitle {text:"The legends will remember...",color:"light_purple",italic:true}

data modify storage evercraft:notify stage.c set value [{text:"HEROIC Quest Complete! ",color:"dark_purple",bold:true},{text:"+1000 XP ",color:"green"},{text:"+500 REP ",color:"aqua"},{text:"+6 Coins",color:"#E0B0FF"}]
scoreboard players set #ndur ec.temp 50
function evercraft:util/notify/emit

# Campfire Stories — record heroic quest completion
function evercraft:campfire_stories/record/quest_heroic

# Achievement tracking
scoreboard players add @s ach.quests_done 1
scoreboard players add @s ec.sp_quests_done 1
function evercraft:milestones/increment/quest_done
scoreboard players add #news_quests ec.var 1
scoreboard players set #rp_quest_tier rp.temp 6
function evercraft:reaper/deeds/on_quest_complete
scoreboard players add @s ach.quest_rep 500
scoreboard players add @s ach.quest_xp 1000
# Daily first-quest bonus (+50 XP for first quest each day)
execute if score @s ec.daily_quest matches 0 run experience add @s 50 points
data modify storage evercraft:notify stage.c set value [{text:"★ ",color:"yellow"},{text:"Daily Bonus! +50 XP",color:"green"},{text:" ★",color:"yellow"}]
scoreboard players set #ndur ec.temp 40
execute if score @s ec.daily_quest matches 0 run function evercraft:util/notify/emit
scoreboard players set @s ec.daily_quest 1

# Forever Coin reward: Heroic = 15 coins (no DR scaling; re-pacing 2026-06-10, was 6)
scoreboard players add @s ec.coins 15
execute if score @s ec.guild_id matches 1.. run function evercraft:guild/contribution/add {amount:30}

# Guild Expedition: Quest bonus XP (activity=7)
function evercraft:guild/expedition/bonus_xp {base:1000,activity:7}

# Story Mode: notify quest completion
execute if score @s sm.mode matches 1..2 run function evercraft:story/quest/check_progress
