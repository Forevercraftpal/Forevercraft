# ============================================================
# Complete Tier 5 (Expedition) Quest
# ============================================================

scoreboard players set @s ec.quest_id_5 0
scoreboard players set @s ec.quest_prog_5 0
scoreboard players set @s ec.quest_done_5 1
scoreboard players add @s ec.village_rep 400
experience add @s 500 points
execute if score #cal_prosperity ec.var matches 1 run experience add @s 250 points
scoreboard players add @s adv.stat_quests 1
# Wayfarer Track: cross-source bonus XP (milestone credit on top of dr.points)
scoreboard players add @s ec.wf_bonus 5

# Taskmaster bonus: +4% XP/rep per level
execute if score @s adv.taskmaster matches 1.. run scoreboard players set #base_quest_xp adv.temp 500
execute if score @s adv.taskmaster matches 1.. run scoreboard players set #base_quest_rep adv.temp 400
execute if score @s adv.taskmaster matches 1.. run function evercraft:advantage/taskmaster/apply_bonus

# Village specialization bonus (+25% rep at specialized villages)
scoreboard players set #vs_base_rep vs.temp 400
function evercraft:village/quest_bonus

# Save updated reputation to village-specific storage
function evercraft:quests/reputation/save_village_rep

# Grant Exquisite Quest Crate — canonical crate item via util/give_quest_crate
# (qc_rarity custom_data drives the placed-barrel advancement -> crate_anim
#  skin/lock/auto-open; raw barrels never animate. Inv-full handled inside.)
function evercraft:util/give_quest_crate {tier:"exquisite"}

function evercraft:quests/reputation/check_rank

execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.player.levelup player @s ~ ~ ~ 1 1.4
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:ui.toast.challenge_complete player @s ~ ~ ~ 0.5 1
execute if score @s ec.fx_vis matches 1.. run particle totem_of_undying ~ ~1 ~ 0.5 0.5 0.5 0.2 25

data modify storage evercraft:notify stage.c set value [{text:"Expedition Complete! ",color:"gold",bold:true},{text:"+500 XP ",color:"green"},{text:"+400 REP ",color:"aqua"},{text:"+9 Coins",color:"#E0B0FF"}]
scoreboard players set #ndur ec.temp 50
function evercraft:util/notify/emit

# Achievement tracking
scoreboard players add @s ach.quests_done 1
scoreboard players add @s ec.sp_quests_done 1
function evercraft:milestones/increment/quest_done
scoreboard players add #news_quests ec.var 1
scoreboard players set #rp_quest_tier rp.temp 5
function evercraft:reaper/deeds/on_quest_complete
scoreboard players add @s ach.quest_rep 400
scoreboard players add @s ach.quest_xp 500
# Daily first-quest bonus (+50 XP for first quest each day)
execute if score @s ec.daily_quest matches 0 run experience add @s 50 points
data modify storage evercraft:notify stage.c set value [{text:"★ ",color:"yellow"},{text:"Daily Bonus! +50 XP",color:"green"},{text:" ★",color:"yellow"}]
scoreboard players set #ndur ec.temp 40
execute if score @s ec.daily_quest matches 0 run function evercraft:util/notify/emit
scoreboard players set @s ec.daily_quest 1

# Forever Coin reward: Expedition = 9 coins (no DR scaling; re-pacing 2026-06-10, was 5)
scoreboard players add @s ec.coins 9
execute if score @s ec.guild_id matches 1.. run function evercraft:guild/contribution/add {amount:25}

# Guild Expedition: Quest bonus XP (activity=7)
function evercraft:guild/expedition/bonus_xp {base:500,activity:7}

# Story Mode: notify quest completion
execute if score @s sm.mode matches 1..2 run function evercraft:story/quest/check_progress
