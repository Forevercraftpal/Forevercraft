# ============================================================
# Track Active Quest Progress
# Run for each player to update quest progress
# ============================================================
# DUAL-WRITER NOTE (Wiring Audit #30): ec.quest_prog_{1..6} is written here (the track_tier{N}
# branches) AND by evercraft:party/quest/broadcast (party kill-quest sharing). Both run inside
# player_tick as @s, sequentially in the same tick (no schedule between them), so there is no
# race — but any new writer of ec.quest_prog_* must respect that ordering. The explore counters
# ec.exp_prog_{3..6} are owned by the quests/explore/on_* handlers + setup_tier{N} accept-reset.

# Track each active tier
execute if score @s ec.quest_id_1 matches 1.. run function evercraft:quests/active/track_tier1
execute if score @s ec.quest_id_2 matches 1.. run function evercraft:quests/active/track_tier2
execute if score @s ec.quest_id_3 matches 1.. run function evercraft:quests/active/track_tier3
execute if score @s ec.quest_id_4 matches 1.. run function evercraft:quests/active/track_tier4
execute if score @s ec.quest_id_5 matches 1.. run function evercraft:quests/active/track_tier5
execute if score @s ec.quest_id_6 matches 1.. run function evercraft:quests/active/track_tier6
