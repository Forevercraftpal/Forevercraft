# One-time migration — pre-2026-06-10 crates that bypassed the crate_anim pipeline:
#  · Quest Crates given as raw barrels WITHOUT qc_rarity custom_data (never animate)
#  · Furnishings Crates given as consume-to-open BOOKS (missing item_model texture)
# Clears each legacy item and re-gives the same count of canonical pipeline crates.
# Idempotent: quest matching also re-gives canonical barrels 1:1; furnishings matching
# is restricted to the legacy book form, so converted barrels are never touched.
# Run as: operator — execute as @a run function evercraft:quests/active/migrate_crates
# Usage: one-time migration after deploying the 2026-06-10 crate fixes.

execute store result score #qcm ec.temp run clear @s minecraft:barrel[minecraft:container_loot={loot_table:"evercraft:crates/common"}]
execute if score #qcm ec.temp matches 1.. run function evercraft:quests/active/migrate_crates_give {table:"evercraft:crates/items/common"}
execute store result score #qcm ec.temp run clear @s minecraft:barrel[minecraft:container_loot={loot_table:"evercraft:crates/uncommon"}]
execute if score #qcm ec.temp matches 1.. run function evercraft:quests/active/migrate_crates_give {table:"evercraft:crates/items/uncommon"}
execute store result score #qcm ec.temp run clear @s minecraft:barrel[minecraft:container_loot={loot_table:"evercraft:crates/rare"}]
execute if score #qcm ec.temp matches 1.. run function evercraft:quests/active/migrate_crates_give {table:"evercraft:crates/items/rare"}
execute store result score #qcm ec.temp run clear @s minecraft:barrel[minecraft:container_loot={loot_table:"evercraft:crates/ornate"}]
execute if score #qcm ec.temp matches 1.. run function evercraft:quests/active/migrate_crates_give {table:"evercraft:crates/items/ornate"}
execute store result score #qcm ec.temp run clear @s minecraft:barrel[minecraft:container_loot={loot_table:"evercraft:crates/exquisite"}]
execute if score #qcm ec.temp matches 1.. run function evercraft:quests/active/migrate_crates_give {table:"evercraft:crates/items/exquisite"}
execute store result score #qcm ec.temp run clear @s minecraft:barrel[minecraft:container_loot={loot_table:"evercraft:crates/mythical"}]
execute if score #qcm ec.temp matches 1.. run function evercraft:quests/active/migrate_crates_give {table:"evercraft:crates/items/mythical"}

execute store result score #qcm ec.temp run clear @s minecraft:book[minecraft:custom_data~{furnishings_crate:1b,fc_tier:"common"}]
execute if score #qcm ec.temp matches 1.. run function evercraft:quests/active/migrate_crates_give {table:"evercraft:decor/crate_item/common"}
execute store result score #qcm ec.temp run clear @s minecraft:book[minecraft:custom_data~{furnishings_crate:1b,fc_tier:"uncommon"}]
execute if score #qcm ec.temp matches 1.. run function evercraft:quests/active/migrate_crates_give {table:"evercraft:decor/crate_item/uncommon"}
execute store result score #qcm ec.temp run clear @s minecraft:book[minecraft:custom_data~{furnishings_crate:1b,fc_tier:"rare"}]
execute if score #qcm ec.temp matches 1.. run function evercraft:quests/active/migrate_crates_give {table:"evercraft:decor/crate_item/rare"}
execute store result score #qcm ec.temp run clear @s minecraft:book[minecraft:custom_data~{furnishings_crate:1b,fc_tier:"ornate"}]
execute if score #qcm ec.temp matches 1.. run function evercraft:quests/active/migrate_crates_give {table:"evercraft:decor/crate_item/ornate"}
execute store result score #qcm ec.temp run clear @s minecraft:book[minecraft:custom_data~{furnishings_crate:1b,fc_tier:"exquisite"}]
execute if score #qcm ec.temp matches 1.. run function evercraft:quests/active/migrate_crates_give {table:"evercraft:decor/crate_item/exquisite"}
execute store result score #qcm ec.temp run clear @s minecraft:book[minecraft:custom_data~{furnishings_crate:1b,fc_tier:"mythical"}]
execute if score #qcm ec.temp matches 1.. run function evercraft:quests/active/migrate_crates_give {table:"evercraft:decor/crate_item/mythical"}

tellraw @s [{text:"[Migration] ",color:"gold"},{text:"Crates refreshed — place one to see it open properly.",color:"gray"}]
