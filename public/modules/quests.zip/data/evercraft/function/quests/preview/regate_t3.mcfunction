# Re-roll T3 preview options that lock to dimensions the player hasn't entered.
# Nether-restricted IDs: 9,10,22,40. End-restricted: 23,43. Pool size 43.
# OPT1
execute if score @s ec.qp_opt1 matches 9 unless predicate evercraft:quests/has_entered_nether store result score @s ec.qp_opt1 run random value 1..43
execute if score @s ec.qp_opt1 matches 10 unless predicate evercraft:quests/has_entered_nether store result score @s ec.qp_opt1 run random value 1..43
execute if score @s ec.qp_opt1 matches 22 unless predicate evercraft:quests/has_entered_nether store result score @s ec.qp_opt1 run random value 1..43
execute if score @s ec.qp_opt1 matches 40 unless predicate evercraft:quests/has_entered_nether store result score @s ec.qp_opt1 run random value 1..43
execute if score @s ec.qp_opt1 matches 23 unless predicate evercraft:quests/has_entered_end store result score @s ec.qp_opt1 run random value 1..43
execute if score @s ec.qp_opt1 matches 43 unless predicate evercraft:quests/has_entered_end store result score @s ec.qp_opt1 run random value 1..43
# OPT2
execute if score @s ec.qp_opt2 matches 9 unless predicate evercraft:quests/has_entered_nether store result score @s ec.qp_opt2 run random value 1..43
execute if score @s ec.qp_opt2 matches 10 unless predicate evercraft:quests/has_entered_nether store result score @s ec.qp_opt2 run random value 1..43
execute if score @s ec.qp_opt2 matches 22 unless predicate evercraft:quests/has_entered_nether store result score @s ec.qp_opt2 run random value 1..43
execute if score @s ec.qp_opt2 matches 40 unless predicate evercraft:quests/has_entered_nether store result score @s ec.qp_opt2 run random value 1..43
execute if score @s ec.qp_opt2 matches 23 unless predicate evercraft:quests/has_entered_end store result score @s ec.qp_opt2 run random value 1..43
execute if score @s ec.qp_opt2 matches 43 unless predicate evercraft:quests/has_entered_end store result score @s ec.qp_opt2 run random value 1..43
# OPT3
execute if score @s ec.qp_opt3 matches 9 unless predicate evercraft:quests/has_entered_nether store result score @s ec.qp_opt3 run random value 1..43
execute if score @s ec.qp_opt3 matches 10 unless predicate evercraft:quests/has_entered_nether store result score @s ec.qp_opt3 run random value 1..43
execute if score @s ec.qp_opt3 matches 22 unless predicate evercraft:quests/has_entered_nether store result score @s ec.qp_opt3 run random value 1..43
execute if score @s ec.qp_opt3 matches 40 unless predicate evercraft:quests/has_entered_nether store result score @s ec.qp_opt3 run random value 1..43
execute if score @s ec.qp_opt3 matches 23 unless predicate evercraft:quests/has_entered_end store result score @s ec.qp_opt3 run random value 1..43
execute if score @s ec.qp_opt3 matches 43 unless predicate evercraft:quests/has_entered_end store result score @s ec.qp_opt3 run random value 1..43
