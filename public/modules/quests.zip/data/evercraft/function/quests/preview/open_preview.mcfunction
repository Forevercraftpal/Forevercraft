# Quest Preview — Open preview for a tier
# Macro: {tier:N,max:M}
# Run as player

# Set preview state
$scoreboard players set @s ec.qp_tier $(tier)
scoreboard players set @s ec.qp_active 1

# Only roll new options if none are locked for this tier
# (prevents free rerolls by closing and reopening)
$execute unless score @s ec.qp_locked matches $(tier) run function evercraft:quests/preview/roll_options {tier:$(tier),max:$(max)}
$scoreboard players set @s ec.qp_locked $(tier)

# Display the options
$function evercraft:quests/preview/show_options {tier:$(tier)}
