# T1 (Overworld tier) has no dimension-restricted quests; macro entry point only.
