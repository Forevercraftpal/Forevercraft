# Re-roll T4 preview options that lock to dimensions the player hasn't entered.
# Nether-restricted IDs: 1,3,9,35,40. End-restricted: 2. Pool size 42.
# OPT1
execute if score @s ec.qp_opt1 matches 1 unless predicate evercraft:quests/has_entered_nether store result score @s ec.qp_opt1 run random value 1..42
execute if score @s ec.qp_opt1 matches 3 unless predicate evercraft:quests/has_entered_nether store result score @s ec.qp_opt1 run random value 1..42
execute if score @s ec.qp_opt1 matches 9 unless predicate evercraft:quests/has_entered_nether store result score @s ec.qp_opt1 run random value 1..42
execute if score @s ec.qp_opt1 matches 35 unless predicate evercraft:quests/has_entered_nether store result score @s ec.qp_opt1 run random value 1..42
execute if score @s ec.qp_opt1 matches 40 unless predicate evercraft:quests/has_entered_nether store result score @s ec.qp_opt1 run random value 1..42
execute if score @s ec.qp_opt1 matches 2 unless predicate evercraft:quests/has_entered_end store result score @s ec.qp_opt1 run random value 1..42
# OPT2
execute if score @s ec.qp_opt2 matches 1 unless predicate evercraft:quests/has_entered_nether store result score @s ec.qp_opt2 run random value 1..42
execute if score @s ec.qp_opt2 matches 3 unless predicate evercraft:quests/has_entered_nether store result score @s ec.qp_opt2 run random value 1..42
execute if score @s ec.qp_opt2 matches 9 unless predicate evercraft:quests/has_entered_nether store result score @s ec.qp_opt2 run random value 1..42
execute if score @s ec.qp_opt2 matches 35 unless predicate evercraft:quests/has_entered_nether store result score @s ec.qp_opt2 run random value 1..42
execute if score @s ec.qp_opt2 matches 40 unless predicate evercraft:quests/has_entered_nether store result score @s ec.qp_opt2 run random value 1..42
execute if score @s ec.qp_opt2 matches 2 unless predicate evercraft:quests/has_entered_end store result score @s ec.qp_opt2 run random value 1..42
# OPT3
execute if score @s ec.qp_opt3 matches 1 unless predicate evercraft:quests/has_entered_nether store result score @s ec.qp_opt3 run random value 1..42
execute if score @s ec.qp_opt3 matches 3 unless predicate evercraft:quests/has_entered_nether store result score @s ec.qp_opt3 run random value 1..42
execute if score @s ec.qp_opt3 matches 9 unless predicate evercraft:quests/has_entered_nether store result score @s ec.qp_opt3 run random value 1..42
execute if score @s ec.qp_opt3 matches 35 unless predicate evercraft:quests/has_entered_nether store result score @s ec.qp_opt3 run random value 1..42
execute if score @s ec.qp_opt3 matches 40 unless predicate evercraft:quests/has_entered_nether store result score @s ec.qp_opt3 run random value 1..42
execute if score @s ec.qp_opt3 matches 2 unless predicate evercraft:quests/has_entered_end store result score @s ec.qp_opt3 run random value 1..42
