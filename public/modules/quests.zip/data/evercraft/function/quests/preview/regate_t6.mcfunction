# Re-roll T6 (Heroic) preview options that lock to dimensions the player hasn't entered.
# Nether-restricted IDs: 1,5,9. End-restricted: 2,10. Pool size 30.
# OPT1
execute if score @s ec.qp_opt1 matches 1 unless predicate evercraft:quests/has_entered_nether store result score @s ec.qp_opt1 run random value 1..30
execute if score @s ec.qp_opt1 matches 5 unless predicate evercraft:quests/has_entered_nether store result score @s ec.qp_opt1 run random value 1..30
execute if score @s ec.qp_opt1 matches 9 unless predicate evercraft:quests/has_entered_nether store result score @s ec.qp_opt1 run random value 1..30
execute if score @s ec.qp_opt1 matches 2 unless predicate evercraft:quests/has_entered_end store result score @s ec.qp_opt1 run random value 1..30
execute if score @s ec.qp_opt1 matches 10 unless predicate evercraft:quests/has_entered_end store result score @s ec.qp_opt1 run random value 1..30
# OPT2
execute if score @s ec.qp_opt2 matches 1 unless predicate evercraft:quests/has_entered_nether store result score @s ec.qp_opt2 run random value 1..30
execute if score @s ec.qp_opt2 matches 5 unless predicate evercraft:quests/has_entered_nether store result score @s ec.qp_opt2 run random value 1..30
execute if score @s ec.qp_opt2 matches 9 unless predicate evercraft:quests/has_entered_nether store result score @s ec.qp_opt2 run random value 1..30
execute if score @s ec.qp_opt2 matches 2 unless predicate evercraft:quests/has_entered_end store result score @s ec.qp_opt2 run random value 1..30
execute if score @s ec.qp_opt2 matches 10 unless predicate evercraft:quests/has_entered_end store result score @s ec.qp_opt2 run random value 1..30
# OPT3
execute if score @s ec.qp_opt3 matches 1 unless predicate evercraft:quests/has_entered_nether store result score @s ec.qp_opt3 run random value 1..30
execute if score @s ec.qp_opt3 matches 5 unless predicate evercraft:quests/has_entered_nether store result score @s ec.qp_opt3 run random value 1..30
execute if score @s ec.qp_opt3 matches 9 unless predicate evercraft:quests/has_entered_nether store result score @s ec.qp_opt3 run random value 1..30
execute if score @s ec.qp_opt3 matches 2 unless predicate evercraft:quests/has_entered_end store result score @s ec.qp_opt3 run random value 1..30
execute if score @s ec.qp_opt3 matches 10 unless predicate evercraft:quests/has_entered_end store result score @s ec.qp_opt3 run random value 1..30
