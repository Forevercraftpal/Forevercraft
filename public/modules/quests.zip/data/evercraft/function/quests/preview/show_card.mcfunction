# Display one quest preview card
# Macro: called with storage eden:temp preview
# Fields: name, desc, num, trigger
# RACE LAW (Wiring Audit #30): MUST stay synchronous — reads the single-key `eden:temp preview`
# scratch written by the caller in the same tick. No schedule/yield may separate the write from
# this read, or concurrent previews collide. Keep this on the synchronous show_options path.
$tellraw @s [{"text":"  "},{"text":"$(num). ","color":"gold"},{"text":"$(name)","color":"white","bold":true}]
$tellraw @s [{"text":"     ","color":"gray"},{"text":"$(desc)","color":"yellow"}]
$tellraw @s [{"text":"     "},{"text":"[Accept]","color":"green","bold":true,"click_event":{"action":"run_command","command":"/trigger ec.quest set $(trigger)"}}]
