# Quest Pool — Biome-aligned re-roll (macro)
# AU34-5 (Joseph 2026-05-30): one-pass biome-weight check after a random quest roll.
# Args: {tier:N, max:M, opt:"opt1|opt2|opt3"} — which roll-slot to inspect/re-roll.
# Run as @s = player. Requires #q_biome_class ec.var set (call quests/pool/biome_class first).
#
# Mechanism: a small CONFLICT table marks "obvious mismatches" (otherworld player rolled an
# Ocean Monument quest, etc.). If conflict detected, 70% chance to re-roll once into a fresh
# random value 1..max. Re-rolls land natural-biome quests via vanilla random distribution.
#
# The conflict table is INTENTIONALLY SMALL at ship. Tuning happens via expanding this file
# opportunistically when playtest surfaces obvious biome/quest mismatches.
# See BIG_BRAIN/30-systems/quests.md § Biome weighting (Joseph 2026-05-30).

# Snapshot the rolled ID for slot-independent comparison
$execute store result score #q_bw_id ec.var run scoreboard players get @s ec.qp_$(opt)

# Roll the re-roll dice once (1..100, threshold = 70%)
execute store result score #q_bw_dice ec.var run random value 1..100

# === Tier 4 conflicts ===
# K05 = Ocean Monument Run, K37 = Monument Plunder — both unreachable from nether/end biomes
$execute if score @s ec.qp_$(opt) matches 5 if score #q_biome_class ec.var matches 6 if score #q_bw_dice ec.var matches 1..70 store result score @s ec.qp_$(opt) run random value 1..$(max)
$execute if score @s ec.qp_$(opt) matches 37 if score #q_biome_class ec.var matches 6 if score #q_bw_dice ec.var matches 1..70 store result score @s ec.qp_$(opt) run random value 1..$(max)

# === Tier 5 conflicts ===
# X23 = Triple Monument — unreachable from nether/end biomes
$execute if score @s ec.qp_$(opt) matches 23 if score #q_biome_class ec.var matches 6 if score #q_bw_dice ec.var matches 1..70 store result score @s ec.qp_$(opt) run random value 1..$(max)
