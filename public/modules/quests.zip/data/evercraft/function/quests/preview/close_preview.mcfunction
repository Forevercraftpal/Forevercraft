# Close quest preview without accepting
# Run as player
data modify storage evercraft:notify stage.c set value [{text:"No preview active.",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute unless score @s ec.qp_active matches 1 run return run function evercraft:util/notify/emit

scoreboard players set @s ec.qp_active 0
data modify storage evercraft:notify stage.c set value [{text:"Preview closed.",color:"gray"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
