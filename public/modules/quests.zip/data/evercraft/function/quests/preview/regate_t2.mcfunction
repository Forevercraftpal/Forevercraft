# Re-roll T2 preview options that lock to dimensions the player hasn't entered.
# Nether-restricted IDs: 29,30,38,42,43,49. End-restricted: 44. Pool size 50.
# OPT1
execute if score @s ec.qp_opt1 matches 29 unless predicate evercraft:quests/has_entered_nether store result score @s ec.qp_opt1 run random value 1..50
execute if score @s ec.qp_opt1 matches 30 unless predicate evercraft:quests/has_entered_nether store result score @s ec.qp_opt1 run random value 1..50
execute if score @s ec.qp_opt1 matches 38 unless predicate evercraft:quests/has_entered_nether store result score @s ec.qp_opt1 run random value 1..50
execute if score @s ec.qp_opt1 matches 42 unless predicate evercraft:quests/has_entered_nether store result score @s ec.qp_opt1 run random value 1..50
execute if score @s ec.qp_opt1 matches 43 unless predicate evercraft:quests/has_entered_nether store result score @s ec.qp_opt1 run random value 1..50
execute if score @s ec.qp_opt1 matches 49 unless predicate evercraft:quests/has_entered_nether store result score @s ec.qp_opt1 run random value 1..50
execute if score @s ec.qp_opt1 matches 44 unless predicate evercraft:quests/has_entered_end store result score @s ec.qp_opt1 run random value 1..50
# OPT2
execute if score @s ec.qp_opt2 matches 29 unless predicate evercraft:quests/has_entered_nether store result score @s ec.qp_opt2 run random value 1..50
execute if score @s ec.qp_opt2 matches 30 unless predicate evercraft:quests/has_entered_nether store result score @s ec.qp_opt2 run random value 1..50
execute if score @s ec.qp_opt2 matches 38 unless predicate evercraft:quests/has_entered_nether store result score @s ec.qp_opt2 run random value 1..50
execute if score @s ec.qp_opt2 matches 42 unless predicate evercraft:quests/has_entered_nether store result score @s ec.qp_opt2 run random value 1..50
execute if score @s ec.qp_opt2 matches 43 unless predicate evercraft:quests/has_entered_nether store result score @s ec.qp_opt2 run random value 1..50
execute if score @s ec.qp_opt2 matches 49 unless predicate evercraft:quests/has_entered_nether store result score @s ec.qp_opt2 run random value 1..50
execute if score @s ec.qp_opt2 matches 44 unless predicate evercraft:quests/has_entered_end store result score @s ec.qp_opt2 run random value 1..50
# OPT3
execute if score @s ec.qp_opt3 matches 29 unless predicate evercraft:quests/has_entered_nether store result score @s ec.qp_opt3 run random value 1..50
execute if score @s ec.qp_opt3 matches 30 unless predicate evercraft:quests/has_entered_nether store result score @s ec.qp_opt3 run random value 1..50
execute if score @s ec.qp_opt3 matches 38 unless predicate evercraft:quests/has_entered_nether store result score @s ec.qp_opt3 run random value 1..50
execute if score @s ec.qp_opt3 matches 42 unless predicate evercraft:quests/has_entered_nether store result score @s ec.qp_opt3 run random value 1..50
execute if score @s ec.qp_opt3 matches 43 unless predicate evercraft:quests/has_entered_nether store result score @s ec.qp_opt3 run random value 1..50
execute if score @s ec.qp_opt3 matches 49 unless predicate evercraft:quests/has_entered_nether store result score @s ec.qp_opt3 run random value 1..50
execute if score @s ec.qp_opt3 matches 44 unless predicate evercraft:quests/has_entered_end store result score @s ec.qp_opt3 run random value 1..50
