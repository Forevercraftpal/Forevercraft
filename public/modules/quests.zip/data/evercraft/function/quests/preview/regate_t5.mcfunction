# Re-roll T5 preview options that lock to dimensions the player hasn't entered.
# Nether-restricted IDs: 3,7,8,19,24,30. End-restricted: 2,4,29,33. Pool size 35.
# OPT1
execute if score @s ec.qp_opt1 matches 3 unless predicate evercraft:quests/has_entered_nether store result score @s ec.qp_opt1 run random value 1..35
execute if score @s ec.qp_opt1 matches 7 unless predicate evercraft:quests/has_entered_nether store result score @s ec.qp_opt1 run random value 1..35
execute if score @s ec.qp_opt1 matches 8 unless predicate evercraft:quests/has_entered_nether store result score @s ec.qp_opt1 run random value 1..35
execute if score @s ec.qp_opt1 matches 19 unless predicate evercraft:quests/has_entered_nether store result score @s ec.qp_opt1 run random value 1..35
execute if score @s ec.qp_opt1 matches 24 unless predicate evercraft:quests/has_entered_nether store result score @s ec.qp_opt1 run random value 1..35
execute if score @s ec.qp_opt1 matches 30 unless predicate evercraft:quests/has_entered_nether store result score @s ec.qp_opt1 run random value 1..35
execute if score @s ec.qp_opt1 matches 2 unless predicate evercraft:quests/has_entered_end store result score @s ec.qp_opt1 run random value 1..35
execute if score @s ec.qp_opt1 matches 4 unless predicate evercraft:quests/has_entered_end store result score @s ec.qp_opt1 run random value 1..35
execute if score @s ec.qp_opt1 matches 29 unless predicate evercraft:quests/has_entered_end store result score @s ec.qp_opt1 run random value 1..35
execute if score @s ec.qp_opt1 matches 33 unless predicate evercraft:quests/has_entered_end store result score @s ec.qp_opt1 run random value 1..35
# OPT2
execute if score @s ec.qp_opt2 matches 3 unless predicate evercraft:quests/has_entered_nether store result score @s ec.qp_opt2 run random value 1..35
execute if score @s ec.qp_opt2 matches 7 unless predicate evercraft:quests/has_entered_nether store result score @s ec.qp_opt2 run random value 1..35
execute if score @s ec.qp_opt2 matches 8 unless predicate evercraft:quests/has_entered_nether store result score @s ec.qp_opt2 run random value 1..35
execute if score @s ec.qp_opt2 matches 19 unless predicate evercraft:quests/has_entered_nether store result score @s ec.qp_opt2 run random value 1..35
execute if score @s ec.qp_opt2 matches 24 unless predicate evercraft:quests/has_entered_nether store result score @s ec.qp_opt2 run random value 1..35
execute if score @s ec.qp_opt2 matches 30 unless predicate evercraft:quests/has_entered_nether store result score @s ec.qp_opt2 run random value 1..35
execute if score @s ec.qp_opt2 matches 2 unless predicate evercraft:quests/has_entered_end store result score @s ec.qp_opt2 run random value 1..35
execute if score @s ec.qp_opt2 matches 4 unless predicate evercraft:quests/has_entered_end store result score @s ec.qp_opt2 run random value 1..35
execute if score @s ec.qp_opt2 matches 29 unless predicate evercraft:quests/has_entered_end store result score @s ec.qp_opt2 run random value 1..35
execute if score @s ec.qp_opt2 matches 33 unless predicate evercraft:quests/has_entered_end store result score @s ec.qp_opt2 run random value 1..35
# OPT3
execute if score @s ec.qp_opt3 matches 3 unless predicate evercraft:quests/has_entered_nether store result score @s ec.qp_opt3 run random value 1..35
execute if score @s ec.qp_opt3 matches 7 unless predicate evercraft:quests/has_entered_nether store result score @s ec.qp_opt3 run random value 1..35
execute if score @s ec.qp_opt3 matches 8 unless predicate evercraft:quests/has_entered_nether store result score @s ec.qp_opt3 run random value 1..35
execute if score @s ec.qp_opt3 matches 19 unless predicate evercraft:quests/has_entered_nether store result score @s ec.qp_opt3 run random value 1..35
execute if score @s ec.qp_opt3 matches 24 unless predicate evercraft:quests/has_entered_nether store result score @s ec.qp_opt3 run random value 1..35
execute if score @s ec.qp_opt3 matches 30 unless predicate evercraft:quests/has_entered_nether store result score @s ec.qp_opt3 run random value 1..35
execute if score @s ec.qp_opt3 matches 2 unless predicate evercraft:quests/has_entered_end store result score @s ec.qp_opt3 run random value 1..35
execute if score @s ec.qp_opt3 matches 4 unless predicate evercraft:quests/has_entered_end store result score @s ec.qp_opt3 run random value 1..35
execute if score @s ec.qp_opt3 matches 29 unless predicate evercraft:quests/has_entered_end store result score @s ec.qp_opt3 run random value 1..35
execute if score @s ec.qp_opt3 matches 33 unless predicate evercraft:quests/has_entered_end store result score @s ec.qp_opt3 run random value 1..35
