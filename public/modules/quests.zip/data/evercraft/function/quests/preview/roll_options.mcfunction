# Roll distinct quest IDs for preview
# Macro: {tier:N,max:M}

# Roll options
$execute store result score @s ec.qp_opt1 run random value 1..$(max)
$execute store result score @s ec.qp_opt2 run random value 1..$(max)
$execute store result score @s ec.qp_opt3 run random value 1..$(max)

# Re-roll dimension-restricted quests if the player can't reach the dimension yet.
# (D-POST-1 — closes the gap left when Council #20 archived roll_tier{2..6}.)
$function evercraft:quests/preview/regate_t$(tier)

# Biome-weighted re-roll pass (AU34-5, Joseph 2026-05-30).
# Refreshes biome class then runs one-pass conflict re-roll per slot.
function evercraft:biome/detect
function evercraft:quests/pool/biome_class
$function evercraft:quests/preview/biome_reroll {tier:$(tier),max:$(max),opt:"opt1"}
$function evercraft:quests/preview/biome_reroll {tier:$(tier),max:$(max),opt:"opt2"}
$function evercraft:quests/preview/biome_reroll {tier:$(tier),max:$(max),opt:"opt3"}

# De-duplicate opt2 vs opt1 (3 attempts)
$execute if score @s ec.qp_opt2 = @s ec.qp_opt1 store result score @s ec.qp_opt2 run random value 1..$(max)
$execute if score @s ec.qp_opt2 = @s ec.qp_opt1 store result score @s ec.qp_opt2 run random value 1..$(max)
$execute if score @s ec.qp_opt2 = @s ec.qp_opt1 store result score @s ec.qp_opt2 run random value 1..$(max)

# De-duplicate opt3 vs opt1 and opt2 (3 attempts each)
$execute if score @s ec.qp_opt3 = @s ec.qp_opt1 store result score @s ec.qp_opt3 run random value 1..$(max)
$execute if score @s ec.qp_opt3 = @s ec.qp_opt2 store result score @s ec.qp_opt3 run random value 1..$(max)
$execute if score @s ec.qp_opt3 = @s ec.qp_opt1 store result score @s ec.qp_opt3 run random value 1..$(max)
$execute if score @s ec.qp_opt3 = @s ec.qp_opt2 store result score @s ec.qp_opt3 run random value 1..$(max)
$execute if score @s ec.qp_opt3 = @s ec.qp_opt1 store result score @s ec.qp_opt3 run random value 1..$(max)
$execute if score @s ec.qp_opt3 = @s ec.qp_opt2 store result score @s ec.qp_opt3 run random value 1..$(max)
