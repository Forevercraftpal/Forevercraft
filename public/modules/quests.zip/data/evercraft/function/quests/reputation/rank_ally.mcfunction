# ============================================================
# Rank Up: Ally (500+ rep)
# ============================================================

scoreboard players set @s ec.rep_rank 3

# Save updated rank to village-specific storage
function evercraft:quests/reputation/save_village_rep

execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.player.levelup player @s ~ ~ ~ 1 1.4
particle happy_villager ~ ~1 ~ 0.5 0.5 0.5 0.1 20

data modify storage evercraft:notify stage.c set value [{text:"You are now an ",color:"gray"},{text:"Ally",color:"aqua"},{text:" of this village!",color:"gray"}]
scoreboard players set #ndur ec.temp 50
function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Access to Commission quests. Iron Golems will assist you.",color:"dark_gray",italic:true}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit

# Unlock Ally title (bit 4)
scoreboard players add @s ec.special_titles 16
