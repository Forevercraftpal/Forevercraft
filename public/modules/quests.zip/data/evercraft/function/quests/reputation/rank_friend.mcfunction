# ============================================================
# Rank Up: Friend (250+ rep)
# ============================================================

scoreboard players set @s ec.rep_rank 2

# Save updated rank to village-specific storage
function evercraft:quests/reputation/save_village_rep

execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.player.levelup player @s ~ ~ ~ 1 1.3
particle happy_villager ~ ~1 ~ 0.5 0.5 0.5 0.1 15

data modify storage evercraft:notify stage.c set value [{text:"You are now a ",color:"gray"},{text:"Friend",color:"green"},{text:" of this village!",color:"gray"}]
scoreboard players set #ndur ec.temp 50
function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Access to Contract quests. Better trade prices.",color:"dark_gray",italic:true}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit

# Unlock Friend title (bit 3)
scoreboard players add @s ec.special_titles 8
