# ============================================================
# Noon Gift Success — Villager gives a gift
# ============================================================

# Spawn gift item from loot table
# Inv-full guard: drop at the player's feet rather than void on a full inventory.
execute store result score #inv_full ec.var run function evercraft:util/check_inv_full
execute if score #inv_full ec.var matches 0 run loot give @s loot evercraft:quests/gifts/noon_gift
execute if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:quests/gifts/noon_gift

# Find nearest villager and make them wave
execute as @e[type=minecraft:villager,distance=..16,limit=1,sort=nearest] at @s run function evercraft:quests/reputation/villager_wave

# Effects
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.villager.celebrate player @s ~ ~ ~ 1 1
particle heart ~ ~2 ~ 0.3 0.2 0.3 0.1 3

data modify storage evercraft:notify stage.c set value [{text:"A villager has given you a gift!",color:"gray"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
