# ============================================================
# Rank Up: Legend (2500+ rep)
# Maximum reputation tier
# ============================================================

scoreboard players set @s ec.rep_rank 5

# Save updated rank to village-specific storage
function evercraft:quests/reputation/save_village_rep

execute if score @s ec.fx_snd matches 1.. run playsound minecraft:ui.toast.challenge_complete player @s ~ ~ ~ 1 0.8
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.lightning_bolt.thunder player @s ~ ~ ~ 0.3 1.5
execute if score @s ec.fx_vis matches 1.. run particle totem_of_undying ~ ~1 ~ 1 1 1 0.3 50
effect give @s minecraft:hero_of_the_village 600 1 true
effect give @s minecraft:glowing 30 0 true

title @s times 10 80 30
title @s title {text:"✦ LEGEND ✦",color:"gold"}
title @s subtitle {text:"Your name echoes through history!",color:"yellow",italic:true}

# Announce to server (§5b: actor-named broadcast — render directly in the actor's context
# so {selector:"@s"} resolves to the new Legend, not each recipient; bypasses the queue)
function evercraft:util/notify/whoami
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:""},{text:" has become a ",color:"gray"},{text:"LEGEND",color:"gold"},{text:" of the village! ✦",color:"gold"}]
data modify storage evercraft:notify stage.c[1].text set from storage evercraft:notify named.who
scoreboard players set #ndur ec.temp 50
execute as @a run scoreboard players set #nttl ec.temp 600
execute as @a run function evercraft:util/notify/emit_keep

data modify storage evercraft:notify stage.c set value [{text:"You are now a ",color:"gray"},{text:"LEGEND",color:"gold",bold:true},{text:"! ",color:"gray"},{text:"2x noon gifts",color:"yellow"},{text:" | ",color:"dark_gray"},{text:"Villager cheers",color:"yellow"},{text:" | ",color:"dark_gray"},{text:"Hero of Village II",color:"yellow"}]
scoreboard players set #ndur ec.temp 50
function evercraft:util/notify/emit

# Award Dreamer's Quill (+1 permanent DR) if not already owned
# Inv-full guard: drop at the player's feet rather than void on a full inventory.
execute store result score #inv_full ec.var run function evercraft:util/check_inv_full
execute unless score @s ec.quill_count matches 1.. if score #inv_full ec.var matches 0 run loot give @s loot evercraft:items/dreamers_quill
execute unless score @s ec.quill_count matches 1.. at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:items/dreamers_quill
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"Dreamer's Quill",color:"gold",bold:true},{text:" received! (+1 Dream Rate)",color:"yellow"},{text:" ✦",color:"gold"}]
scoreboard players set #ndur ec.temp 40
execute unless score @s ec.quill_count matches 1.. run function evercraft:util/notify/emit

# Village Specialization: Check if this village should be upgraded (iron golem guards)
execute at @s run function evercraft:village/upgrades/check_legend

# Unlock Legend title (bit 6)
scoreboard players add @s ec.special_titles 64
