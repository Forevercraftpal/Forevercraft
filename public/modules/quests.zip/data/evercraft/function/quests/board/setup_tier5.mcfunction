# Setup Tier 5 (Expedition) Quest — Post-selection initialization
# Run as player

scoreboard players set @s ec.quest_prog_5 0
scoreboard players operation @s ec.quest_village = @s ec.current_village

# Wiring Audit #30: reset explore-quest progress on accept
# X02(2) X03(3) X06(6) X08(8) X09(9) X23(23) X28(28) X34(34) X35(35)
execute if score @s ec.quest_id_5 matches 2 run scoreboard players set @s ec.exp_prog_5 0
execute if score @s ec.quest_id_5 matches 3 run scoreboard players set @s ec.exp_prog_5 0
execute if score @s ec.quest_id_5 matches 6 run scoreboard players set @s ec.exp_prog_5 0
execute if score @s ec.quest_id_5 matches 8 run scoreboard players set @s ec.exp_prog_5 0
execute if score @s ec.quest_id_5 matches 9 run scoreboard players set @s ec.exp_prog_5 0
execute if score @s ec.quest_id_5 matches 23 run scoreboard players set @s ec.exp_prog_5 0
execute if score @s ec.quest_id_5 matches 28 run scoreboard players set @s ec.exp_prog_5 0
execute if score @s ec.quest_id_5 matches 34 run scoreboard players set @s ec.exp_prog_5 0
execute if score @s ec.quest_id_5 matches 35 run scoreboard players set @s ec.exp_prog_5 0

# Reset kill counters for hunt quests
execute if score @s ec.quest_id_5 matches 1 run scoreboard players set @s ec.kills_elder_guardian 0
execute if score @s ec.quest_id_5 matches 10 run scoreboard players set @s ec.kills_breeze 0
execute if score @s ec.quest_id_5 matches 22 run scoreboard players set @s ec.kills_warden 0

# Zero the delta baseline FIRST: post-Pioneer-wipe a snapshotted ach.* source can be ABSENT
# (strip_player_zero's reset @s removes the entry, and lifetime ach counters aren't re-set),
# so the gated `= @s` FAILS and ec.stat_snap_5 keeps a PRIOR quest's baseline (stale). The
# tracker then computes prog = current - stale_baseline; a too-low stale baseline = instant /
# false completion. Init to 0 so a missing source snapshots as 0 (correct for a wiped player).
scoreboard players set @s ec.stat_snap_5 0

# Wiring Audit #30: X07 Nether Star Fragment (50 nether-mob kills) — snapshot the summed
# nether-kill rollup so progress counts from accept-time (delta pattern).
execute if score @s ec.quest_id_5 matches 7 run function evercraft:quests/explore/sum_nether_kills
execute if score @s ec.quest_id_5 matches 7 run scoreboard players operation @s ec.stat_snap_5 = @s ec.kills_nether

# Snapshot ach.* values for delta tracking (prevents instant completion from lifetime stats)
execute if score @s ec.quest_id_5 matches 11 run scoreboard players operation @s ec.stat_snap_5 = @s ach.boss_kills
execute if score @s ec.quest_id_5 matches 12 run scoreboard players operation @s ec.stat_snap_5 = @s ach.dungeons_done
execute if score @s ec.quest_id_5 matches 13 run scoreboard players operation @s ec.stat_snap_5 = @s ach.meals_cooked
execute if score @s ec.quest_id_5 matches 14 run scoreboard players operation @s ec.stat_snap_5 = @s ec.lore_sets_done
execute if score @s ec.quest_id_5 matches 15 run scoreboard players operation @s ec.stat_snap_5 = @s ach.boss_kills
execute if score @s ec.quest_id_5 matches 16 run scoreboard players operation @s ec.stat_snap_5 = @s ach.transmutes_done
execute if score @s ec.quest_id_5 matches 17 run scoreboard players operation @s ec.stat_snap_5 = @s ach.runes_forged
execute if score @s ec.quest_id_5 matches 18 run scoreboard players operation @s ec.stat_snap_5 = @s ach.meals_cooked
execute if score @s ec.quest_id_5 matches 19 run scoreboard players operation @s ec.stat_snap_5 = @s ach.boss_kills
execute if score @s ec.quest_id_5 matches 20 run scoreboard players operation @s ec.stat_snap_5 = @s ach.forages_done
execute if score @s ec.quest_id_5 matches 21 run scoreboard players operation @s ec.stat_snap_5 = @s ach.prospects_done
execute if score @s ec.quest_id_5 matches 25 run scoreboard players operation @s ec.stat_snap_5 = @s ach.dungeons_done
execute if score @s ec.quest_id_5 matches 26 run scoreboard players operation @s ec.stat_snap_5 = @s ec.lore_sets_done
execute if score @s ec.quest_id_5 matches 27 run scoreboard players operation @s ec.stat_snap_5 = @s ach.meals_cooked
execute if score @s ec.quest_id_5 matches 30 run scoreboard players operation @s ec.stat_snap_5 = @s ach.boss_kills
execute if score @s ec.quest_id_5 matches 31 run scoreboard players operation @s ec.stat_snap_5 = @s ach.runes_forged
execute if score @s ec.quest_id_5 matches 32 run scoreboard players operation @s ec.stat_snap_5 = @s ach.transmutes_done

execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.player.levelup player @s ~ ~ ~ 0.5 1.5
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.enchantment_table.use player @s ~ ~ ~ 0.5 1.2
execute if score @s ec.fx_vis matches 1.. run particle totem_of_undying ~ ~1 ~ 0.3 0.5 0.3 0.1 10

data modify storage evercraft:notify stage.c set value [{text:"Expedition accepted!",color:"green"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
