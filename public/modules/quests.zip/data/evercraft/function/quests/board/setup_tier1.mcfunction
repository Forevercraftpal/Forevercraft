# Setup Tier 1 (Errand) Quest — Post-selection initialization
# Called after quest ID is set (from preview accept or direct)
# Run as player

scoreboard players set @s ec.quest_prog_1 0
scoreboard players operation @s ec.quest_village = @s ec.current_village

# Reset kill counters for hunt quests (so lifetime kills don't count)
execute if score @s ec.quest_id_1 matches 4 run scoreboard players set @s ec.kills_zombie 0
execute if score @s ec.quest_id_1 matches 5 run scoreboard players set @s ec.kills_spider 0
execute if score @s ec.quest_id_1 matches 19 run scoreboard players set @s ec.kills_zombie 0
execute if score @s ec.quest_id_1 matches 48 run scoreboard players set @s ec.kills_husk 0
execute if score @s ec.quest_id_1 matches 49 run scoreboard players set @s ec.kills_stray 0

# Snapshot system quest counters for delta tracking.
# Zero the baseline FIRST: post-Pioneer-wipe the snapshotted ach.* source can be ABSENT
# (strip_player_zero's reset @s removes the entry, and lifetime ach counters aren't re-set),
# so the gated `= @s` FAILS and ec.stat_snap_1 keeps a PRIOR quest's baseline (stale). The
# tracker then computes prog = current - stale_baseline; a too-low stale baseline = instant /
# false completion. Init to 0 so a missing source snapshots as 0 (correct for a wiped player).
scoreboard players set @s ec.stat_snap_1 0
execute if score @s ec.quest_id_1 matches 16 run scoreboard players operation @s ec.stat_snap_1 = @s ach.forages_done
execute if score @s ec.quest_id_1 matches 17 run scoreboard players operation @s ec.stat_snap_1 = @s ach.prospects_done
execute if score @s ec.quest_id_1 matches 18 run scoreboard players operation @s ec.stat_snap_1 = @s ach.meals_cooked
execute if score @s ec.quest_id_1 matches 35 run scoreboard players operation @s ec.stat_snap_1 = @s ach.lore_found
execute if score @s ec.quest_id_1 matches 36 run scoreboard players operation @s ec.stat_snap_1 = @s ach.meals_cooked
execute if score @s ec.quest_id_1 matches 38 run scoreboard players operation @s ec.stat_snap_1 = @s ach.forages_done
execute if score @s ec.quest_id_1 matches 41 run scoreboard players operation @s ec.stat_snap_1 = @s ach.meals_cooked
execute if score @s ec.quest_id_1 matches 50 run scoreboard players operation @s ec.stat_snap_1 = @s ach.prospects_done

# Effects
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.player.levelup player @s ~ ~ ~ 0.5 1.5
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.enchantment_table.use player @s ~ ~ ~ 0.5 1.2
execute if score @s ec.fx_vis matches 1.. run particle totem_of_undying ~ ~1 ~ 0.3 0.5 0.3 0.1 5

data modify storage evercraft:notify stage.c set value [{text:"Errand accepted!",color:"green"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
