# ============================================================
# Auto-Seed Village Quest Board (2026-06-10)
# Runs AT the village anchor (bestiary.village.name armor stand = the bell /
# meeting point), AS the entering player (@s — create_new's village-id hash
# reads @s Pos, same contract as the manual lectern-placement flow).
# Called from evercraft:mobs/village/message/entering — i.e. the moment a
# player enters a village for the FIRST time (not_at_village -> at_village).
# Villages generated BEFORE this shipped seed on their next first entry: the
# dedup is "does a quests.board marker exist within 96 blocks", so every
# board-less village self-heals the first time a wayfarer walks in.
# Places a lectern BESIDE THE BELL (the village notice-board spot) and puts
# the quest book on it via the existing convert_to_quest_board chain.
# NOTE: coupled to the village-name anchors (eden:settings villagename) —
# if village names are disabled, entering never fires and nothing seeds.
# ============================================================

# Reset BEFORE the dedup return — entering reads #qb_seeded for its notify,
# a stale 1 from a previous village would mis-notify.
scoreboard players set #qb_seeded ec.temp 0

# Dedup: village already has a quest board -> nothing to do
execute if entity @e[type=armor_stand,tag=quests.board,distance=..96] run return 0

# Find a spot beside the bell: replaceable spot + headroom + solid ground.
# Tries 8 candidates (cardinals at 2 blocks, then at 3); first hit wins,
# lectern faces the bell. No valid spot (odd terrain) -> silently retry on a
# future first entry (exit + re-enter flips back through not_at_village).
function evercraft:quests/board/auto_seed_try {dx:"2",dz:"0",facing:"west"}
function evercraft:quests/board/auto_seed_try {dx:"-2",dz:"0",facing:"east"}
function evercraft:quests/board/auto_seed_try {dx:"0",dz:"2",facing:"north"}
function evercraft:quests/board/auto_seed_try {dx:"0",dz:"-2",facing:"south"}
function evercraft:quests/board/auto_seed_try {dx:"3",dz:"0",facing:"west"}
function evercraft:quests/board/auto_seed_try {dx:"-3",dz:"0",facing:"east"}
function evercraft:quests/board/auto_seed_try {dx:"0",dz:"3",facing:"north"}
function evercraft:quests/board/auto_seed_try {dx:"0",dz:"-3",facing:"south"}
