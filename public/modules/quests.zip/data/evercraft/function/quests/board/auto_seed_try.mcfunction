# Try ONE lectern spot beside the bell (helper of auto_seed — see its header).
# Macro args: {dx:"<int>", dz:"<int>", facing:"<lectern facing, toward the bell>"}.
# Valid spot = replaceable block + replaceable headroom + non-replaceable ground.
execute if score #qb_seeded ec.temp matches 1 run return 0
$execute positioned ~$(dx) ~ ~$(dz) if block ~ ~ ~ #minecraft:replaceable if block ~ ~1 ~ #minecraft:replaceable unless block ~ ~-1 ~ #minecraft:replaceable run function evercraft:quests/board/auto_seed_place {facing:"$(facing)"}
