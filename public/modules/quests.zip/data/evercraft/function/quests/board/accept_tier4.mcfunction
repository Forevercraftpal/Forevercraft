# Accept Tier 4 (Commission) Quest — Opens Preview
execute if score @s ec.quest_id_4 matches 1.. run tellraw @s ["",{text:"[Forevercraft] ",color:"gold"},{text:"You already have a Commission active. Cancel it? ",color:"yellow"},{text:"(-40 rep)",color:"red"}]
execute if score @s ec.quest_id_4 matches 1.. run tellraw @s ["",{text:"  "},{text:"[Cancel Quest]",color:"red",bold:true,click_event:{action:"run_command",command:"/trigger ec.quest set 14"}},{text:"  "},{text:"[Keep Quest]",color:"green",bold:true,click_event:{action:"run_command",command:"/trigger ec.quest set 20"}}]
execute if score @s ec.quest_id_4 matches 1.. run return 1
data modify storage evercraft:notify stage.c set value [{text:"You already completed today's Commission. Return tomorrow!",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute if score @s ec.quest_done_4 matches 1 run function evercraft:util/notify/emit
execute if score @s ec.quest_done_4 matches 1 run return 1

# Wiring Audit #30 (D2): Commissions require Ally rank (500+ reputation) — mirrors heroic/accept gate
data modify storage evercraft:notify stage.c set value [{text:"Reach ",color:"red"},{text:"Ally ",color:"aqua"},{text:"rank (500+ reputation) to accept Commissions!",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute unless score @s ec.village_rep matches 500.. run function evercraft:util/notify/emit
execute unless score @s ec.village_rep matches 500.. if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bass player @s ~ ~ ~ 1 0.5
execute unless score @s ec.village_rep matches 500.. run return 1

# Check cooldown from cancel
data modify storage evercraft:notify stage.c set value [{text:"Commissions are on cooldown. Try again shortly!",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute if score @s ec.qc_cd_4 matches 1.. run function evercraft:util/notify/emit
execute if score @s ec.qc_cd_4 matches 1.. run return 1

# Check if preview already open
data modify storage evercraft:notify stage.c set value [{text:"You already have a preview open. Close it first!",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute if score @s ec.qp_active matches 1 run function evercraft:util/notify/emit
execute if score @s ec.qp_active matches 1 run return 1

# Open quest preview with 3 options
function evercraft:quests/preview/open_preview {tier:4,max:42}
return 1
