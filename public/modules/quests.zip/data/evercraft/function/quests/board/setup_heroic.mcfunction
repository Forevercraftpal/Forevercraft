# Setup Heroic (Tier 6) Quest — Post-selection initialization
# Run as player

scoreboard players set @s ec.quest_prog_6 0
scoreboard players operation @s ec.quest_village = @s ec.current_village

# Reset kill counters for hunt quests
execute if score @s ec.quest_id_6 matches 1 run scoreboard players set @s ec.kills_wither 0
execute if score @s ec.quest_id_6 matches 2 run scoreboard players set @s ec.kills_ender_dragon 0
execute if score @s ec.quest_id_6 matches 3 run scoreboard players set @s ec.kills_warden 0
execute if score @s ec.quest_id_6 matches 28 run scoreboard players set @s ec.kills_wither 0

# Snapshot ach.* values for delta tracking (prevents instant completion from lifetime stats).
# Zero the baseline FIRST: post-Pioneer-wipe a snapshotted ach.* source can be ABSENT
# (strip_player_zero's reset @s removes the entry, and lifetime ach counters aren't re-set),
# so the gated `= @s` FAILS and ec.stat_snap_6 keeps a PRIOR quest's baseline (stale) → the
# tracker's prog = current - stale_baseline gives instant / false completion. Init to 0 so a
# missing source snapshots as 0 (correct for a wiped player). Covers the H30 sum + H06/H09 below.
scoreboard players set @s ec.stat_snap_6 0
execute if score @s ec.quest_id_6 matches 11..21 run scoreboard players operation @s ec.stat_snap_6 = @s ach.boss_kills
execute if score @s ec.quest_id_6 matches 22 run scoreboard players operation @s ec.stat_snap_6 = @s ach.meals_cooked
execute if score @s ec.quest_id_6 matches 23 run scoreboard players operation @s ec.stat_snap_6 = @s ach.dungeons_done
execute if score @s ec.quest_id_6 matches 24 run scoreboard players operation @s ec.stat_snap_6 = @s ec.lore_sets_done
execute if score @s ec.quest_id_6 matches 25 run scoreboard players operation @s ec.stat_snap_6 = @s ach.runes_forged
execute if score @s ec.quest_id_6 matches 26 run scoreboard players operation @s ec.stat_snap_6 = @s ach.transmutes_done
execute if score @s ec.quest_id_6 matches 27 run scoreboard players operation @s ec.stat_snap_6 = @s ach.boss_kills
execute if score @s ec.quest_id_6 matches 29 run scoreboard players operation @s ec.stat_snap_6 = @s ach.meals_cooked
# H30 uses combined forages+prospects — snapshot both summed together
execute if score @s ec.quest_id_6 matches 30 run scoreboard players operation @s ec.stat_snap_6 = @s ach.forages_done
execute if score @s ec.quest_id_6 matches 30 run scoreboard players operation @s ec.stat_snap_6 += @s ach.prospects_done

# Wiring Audit #30: reset explore-quest progress on accept — H08(8) shipwrecks, H10(10) end cities
execute if score @s ec.quest_id_6 matches 8 run scoreboard players set @s ec.exp_prog_6 0
execute if score @s ec.quest_id_6 matches 10 run scoreboard players set @s ec.exp_prog_6 0

# Wiring Audit #30: composite/counter heroic snapshots (count from accept-time via delta pattern).
# H04 The Grand Harvest (10 of every crop) — AU34-1 (Joseph 2026-05-30): TRUE per-crop snapshot.
# Pre-2026-05-30 snapshotted ach.crops_harvested as a proxy (90 total ≈ 10×9), which let a
# wheat-only farm complete it. Now snapshots 9 ec.tt_s_<crop> baselines for exact per-crop check.
execute if score @s ec.quest_id_6 matches 4 run function evercraft:quests/h04/snapshot
# H06 Ultimate Explorer (12 unique biomes) — snapshot distinct-biome counter jn.biome_count.
execute if score @s ec.quest_id_6 matches 6 run scoreboard players operation @s ec.stat_snap_6 = @s jn.biome_count
# H07 Raid Champion (complete 1 raid) — use exp_prog_6 as a raid-victory counter, zero on accept.
execute if score @s ec.quest_id_6 matches 7 run scoreboard players set @s ec.exp_prog_6 0
# H09 Nether Domination (100 nether-mob kills) — snapshot the summed nether-kill rollup.
execute if score @s ec.quest_id_6 matches 9 run function evercraft:quests/explore/sum_nether_kills
execute if score @s ec.quest_id_6 matches 9 run scoreboard players operation @s ec.stat_snap_6 = @s ec.kills_nether

# Set 7-day expiry timer (7 in-game days * 3600 seconds/day = 25200, decremented 1/second)
scoreboard players set @s ec.quest_expiry 25200

# Big effects for heroic acceptance
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:ui.toast.challenge_complete player @s ~ ~ ~ 1 1
execute if score @s ec.fx_vis matches 1.. run particle totem_of_undying ~ ~1 ~ 0.5 1 0.5 0.2 25
effect give @s minecraft:glowing 5 0 true

data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"dark_purple"},{text:"HEROIC QUEST ACCEPTED!",color:"dark_purple",bold:true},{text:" ✦",color:"dark_purple"}]
scoreboard players set #ndur ec.temp 50
function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"You have ",color:"gray"},{text:"7 days",color:"gold"},{text:" to complete this legendary challenge!",color:"gray"}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit

# Title announcement
title @s times 10 70 20
title @s title {"text":"HEROIC QUEST","color":"dark_purple"}
title @s subtitle {"text":"The legends will speak of you...","color":"light_purple","italic":true}
