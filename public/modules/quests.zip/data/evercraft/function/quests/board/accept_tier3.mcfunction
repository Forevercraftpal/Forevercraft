# Accept Tier 3 (Contract) Quest — Opens Preview
execute if score @s ec.quest_id_3 matches 1.. run tellraw @s ["",{text:"[Forevercraft] ",color:"gold"},{text:"You already have a Contract active. Cancel it? ",color:"yellow"},{text:"(-25 rep)",color:"red"}]
execute if score @s ec.quest_id_3 matches 1.. run tellraw @s ["",{text:"  "},{text:"[Cancel Quest]",color:"red",bold:true,click_event:{action:"run_command",command:"/trigger ec.quest set 13"}},{text:"  "},{text:"[Keep Quest]",color:"green",bold:true,click_event:{action:"run_command",command:"/trigger ec.quest set 20"}}]
execute if score @s ec.quest_id_3 matches 1.. run return 1
data modify storage evercraft:notify stage.c set value [{text:"You already completed today's Contract. Return tomorrow!",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute if score @s ec.quest_done_3 matches 1 run function evercraft:util/notify/emit
execute if score @s ec.quest_done_3 matches 1 run return 1

# Wiring Audit #30 (D2): Contracts require Friend rank (250+ reputation) — mirrors heroic/accept gate
data modify storage evercraft:notify stage.c set value [{text:"Reach ",color:"red"},{text:"Friend ",color:"green"},{text:"rank (250+ reputation) to accept Contracts!",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute unless score @s ec.village_rep matches 250.. run function evercraft:util/notify/emit
execute unless score @s ec.village_rep matches 250.. if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bass player @s ~ ~ ~ 1 0.5
execute unless score @s ec.village_rep matches 250.. run return 1

# Check cooldown from cancel
data modify storage evercraft:notify stage.c set value [{text:"Contracts are on cooldown. Try again shortly!",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute if score @s ec.qc_cd_3 matches 1.. run function evercraft:util/notify/emit
execute if score @s ec.qc_cd_3 matches 1.. run return 1

# Check if preview already open
data modify storage evercraft:notify stage.c set value [{text:"You already have a preview open. Close it first!",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute if score @s ec.qp_active matches 1 run function evercraft:util/notify/emit
execute if score @s ec.qp_active matches 1 run return 1

# Open quest preview with 3 options
function evercraft:quests/preview/open_preview {tier:3,max:43}
return 1
