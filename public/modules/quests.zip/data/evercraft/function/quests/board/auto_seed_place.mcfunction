# Place the lectern + seed the quest book (helper of auto_seed — see its header).
# Runs positioned at the validated spot, AS the entering player.
# Macro args: {facing:"<direction>"} — lectern front faces the bell.
# has_book=true is REQUIRED: generate_book only data-merges the Book NBT (the manual
# flow's lectern already had a player-placed book; an auto-placed bare lectern would
# hold an invisible book otherwise).
$setblock ~ ~ ~ minecraft:lectern[facing=$(facing),has_book=true]
function evercraft:quests/board/convert_to_quest_board
scoreboard players set #qb_seeded ec.temp 1
