# Setup Tier 4 (Commission) Quest — Post-selection initialization
# Run as player

scoreboard players set @s ec.quest_prog_4 0
scoreboard players operation @s ec.quest_village = @s ec.current_village

# Wiring Audit #30: reset explore-quest progress on accept
# K05(5) K06(6) K08(8) K11(11) K25(25) K28(28) K34(34) K37(37)
execute if score @s ec.quest_id_4 matches 5 run scoreboard players set @s ec.exp_prog_4 0
execute if score @s ec.quest_id_4 matches 6 run scoreboard players set @s ec.exp_prog_4 0
execute if score @s ec.quest_id_4 matches 8 run scoreboard players set @s ec.exp_prog_4 0
execute if score @s ec.quest_id_4 matches 11 run scoreboard players set @s ec.exp_prog_4 0
execute if score @s ec.quest_id_4 matches 25 run scoreboard players set @s ec.exp_prog_4 0
execute if score @s ec.quest_id_4 matches 28 run scoreboard players set @s ec.exp_prog_4 0
execute if score @s ec.quest_id_4 matches 34 run scoreboard players set @s ec.exp_prog_4 0
execute if score @s ec.quest_id_4 matches 37 run scoreboard players set @s ec.exp_prog_4 0

# Reset kill counters for hunt quests
execute if score @s ec.quest_id_4 matches 1 run scoreboard players set @s ec.kills_wither_skeleton 0
execute if score @s ec.quest_id_4 matches 4 run scoreboard players set @s ec.kills_pillager 0
execute if score @s ec.quest_id_4 matches 7 run scoreboard players set @s ec.kills_evoker 0
execute if score @s ec.quest_id_4 matches 9 run scoreboard players set @s ec.kills_piglin_brute 0
execute if score @s ec.quest_id_4 matches 12 run scoreboard players set @s ec.kills_ravager 0
execute if score @s ec.quest_id_4 matches 33 run scoreboard players set @s ec.kills_elder_guardian 0
execute if score @s ec.quest_id_4 matches 41 run scoreboard players set @s ec.kills_evoker 0

# Snapshot system quest counters for delta tracking.
# Zero the baseline FIRST: post-Pioneer-wipe the snapshotted ach.* source can be ABSENT
# (strip_player_zero's reset @s removes the entry, and lifetime ach counters aren't re-set),
# so the gated `= @s` FAILS and ec.stat_snap_4 keeps a PRIOR quest's baseline (stale). The
# tracker then computes prog = current - stale_baseline; a too-low stale baseline = instant /
# false completion. Init to 0 so a missing source snapshots as 0 (correct for a wiped player).
scoreboard players set @s ec.stat_snap_4 0
execute if score @s ec.quest_id_4 matches 13 run scoreboard players operation @s ec.stat_snap_4 = @s ach.boss_kills
execute if score @s ec.quest_id_4 matches 14 run scoreboard players operation @s ec.stat_snap_4 = @s ach.meals_cooked
execute if score @s ec.quest_id_4 matches 15 run scoreboard players operation @s ec.stat_snap_4 = @s ach.runes_forged
execute if score @s ec.quest_id_4 matches 16 run scoreboard players operation @s ec.stat_snap_4 = @s ach.transmutes_done
execute if score @s ec.quest_id_4 matches 17 run scoreboard players operation @s ec.stat_snap_4 = @s ach.dungeons_done
execute if score @s ec.quest_id_4 matches 18 run scoreboard players operation @s ec.stat_snap_4 = @s ec.lore_sets_done
execute if score @s ec.quest_id_4 matches 19 run scoreboard players operation @s ec.stat_snap_4 = @s ach.forages_done
execute if score @s ec.quest_id_4 matches 20 run scoreboard players operation @s ec.stat_snap_4 = @s ach.prospects_done
execute if score @s ec.quest_id_4 matches 21 run scoreboard players operation @s ec.stat_snap_4 = @s ach.meals_cooked
execute if score @s ec.quest_id_4 matches 22 run scoreboard players operation @s ec.stat_snap_4 = @s ach.lore_found
execute if score @s ec.quest_id_4 matches 23 run scoreboard players operation @s ec.stat_snap_4 = @s ach.meals_cooked
execute if score @s ec.quest_id_4 matches 24 run scoreboard players operation @s ec.stat_snap_4 = @s ach.boss_kills
execute if score @s ec.quest_id_4 matches 26 run scoreboard players operation @s ec.stat_snap_4 = @s ach.dungeons_done
execute if score @s ec.quest_id_4 matches 27 run scoreboard players operation @s ec.stat_snap_4 = @s ach.runes_forged
execute if score @s ec.quest_id_4 matches 29 run scoreboard players operation @s ec.stat_snap_4 = @s ach.transmutes_done
execute if score @s ec.quest_id_4 matches 30 run scoreboard players operation @s ec.stat_snap_4 = @s ach.meals_cooked
execute if score @s ec.quest_id_4 matches 31 run scoreboard players operation @s ec.stat_snap_4 = @s ach.prospects_done
execute if score @s ec.quest_id_4 matches 32 run scoreboard players operation @s ec.stat_snap_4 = @s ec.lore_sets_done
execute if score @s ec.quest_id_4 matches 39 run scoreboard players operation @s ec.stat_snap_4 = @s ach.meals_cooked
execute if score @s ec.quest_id_4 matches 42 run scoreboard players operation @s ec.stat_snap_4 = @s ach.runes_forged

execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.player.levelup player @s ~ ~ ~ 0.5 1.5
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.enchantment_table.use player @s ~ ~ ~ 0.5 1.2
execute if score @s ec.fx_vis matches 1.. run particle totem_of_undying ~ ~1 ~ 0.3 0.5 0.3 0.1 8

data modify storage evercraft:notify stage.c set value [{text:"Commission accepted!",color:"green"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
