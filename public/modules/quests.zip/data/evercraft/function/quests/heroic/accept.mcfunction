# ============================================================
# Accept Heroic Quest (Tier 6) — Opens Preview with 2 options
# ============================================================

# Check if already active
execute if score @s ec.quest_id_6 matches 1.. run tellraw @s ["",{text:"[Forevercraft] ",color:"gold"},{text:"You already have a Heroic quest active. Cancel it? ",color:"yellow"},{text:"(-100 rep)",color:"red"}]
execute if score @s ec.quest_id_6 matches 1.. run tellraw @s ["",{text:"  "},{text:"[Cancel Quest]",color:"red",bold:true,click_event:{action:"run_command",command:"/trigger ec.quest set 16"}},{text:"  "},{text:"[Keep Quest]",color:"green",bold:true,click_event:{action:"run_command",command:"/trigger ec.quest set 20"}}]
execute if score @s ec.quest_id_6 matches 1.. run return 1

# Check if already completed
data modify storage evercraft:notify stage.c set value [{text:"You have already completed a Heroic quest. Seek glory elsewhere!",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute if score @s ec.quest_done_6 matches 1 run function evercraft:util/notify/emit
execute if score @s ec.quest_done_6 matches 1 run return 1

# Check prerequisites (requires 1000+ rep with village)
data modify storage evercraft:notify stage.c set value [{text:"You need ",color:"red"},{text:"Hero ",color:"dark_purple"},{text:"rank (1000+ reputation) to accept Heroic quests!",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute unless score @s ec.village_rep matches 1000.. run function evercraft:util/notify/emit
execute unless score @s ec.village_rep matches 1000.. run return 1

# Check cooldown from cancel
data modify storage evercraft:notify stage.c set value [{text:"Heroic quests are on cooldown. Try again later!",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute if score @s ec.qc_cd_6 matches 1.. run function evercraft:util/notify/emit
execute if score @s ec.qc_cd_6 matches 1.. run return 1

# Check if preview already open
data modify storage evercraft:notify stage.c set value [{text:"You already have a preview open. Close it first!",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute if score @s ec.qp_active matches 1 run function evercraft:util/notify/emit
execute if score @s ec.qp_active matches 1 run return 1

# Open quest preview with 2 options (heroic shows 2, no re-roll)
function evercraft:quests/preview/open_preview {tier:6,max:30}

data modify storage evercraft:notify stage.c set value [{text:"⚠ Heroic quests have a 7-day timer!",color:"gold",italic:true}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
return 1
