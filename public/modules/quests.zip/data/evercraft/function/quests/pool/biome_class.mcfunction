# Quest Pool — Biome Class Derivation
# AU34-5 (Joseph 2026-05-30): derive a coarse 6-class biome category from ec.biome_id (25-row table)
# for biome-weighted quest rolling. Writes #q_biome_class ec.var (1-6).
# Run as @s = player (caller must have ec.biome_id current — call biome/detect first).
#
# Classes:
#   1 = farmland     (plains, savanna, flower_forest)
#   2 = forest       (forest, dark_forest, taiga, jungle)
#   3 = aquatic      (ocean, river, swamp, mushroom)
#   4 = arid         (desert, badlands)
#   5 = depths       (mountain, ice, dripstone_caves, deep_dark, lush_caves)
#   6 = otherworld   (nether/end biomes)
# (Default: 1 farmland if unknown — most quests are farmable.)

# BACK-COMPAT ALIAS (2026-06-04): the canonical 6-class map now lives at evercraft:biome/class
# (shared by quests + biome crates + fishing — one biome key, no per-system vocabularies). This file
# stays so existing #q_biome_class readers (quests/preview/biome_reroll) need ZERO edits: call the
# shared map, then mirror its output into #q_biome_class. NOTE: biome/class also FIXES the legacy
# 18..24->otherworld bug here (biome_id 24 = Overworld windswept), so the alias is strictly more correct.
function evercraft:biome/class
scoreboard players operation #q_biome_class ec.var = #biome_class ec.var
