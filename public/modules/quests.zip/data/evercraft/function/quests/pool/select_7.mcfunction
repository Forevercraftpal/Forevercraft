# ============================================================
# Select 7 Quests for Board
# 2 Errand, 2 Task, 1 Contract, 1 Commission/Expedition, 1 Heroic
# AU34-5 (Joseph 2026-05-30): biome-weighted selection now LIVE.
# The actual per-quest random roll happens in `evercraft:quests/preview/roll_options` when a
# player opens a tier preview; this function caches the player's biome class so the
# `biome_reroll` hook in roll_options can re-roll obvious mismatches (e.g. nether biome rolling
# an Ocean Monument quest).
# ============================================================

# Cache current biome + derive coarse biome class for downstream re-roll bias
function evercraft:biome/detect
function evercraft:quests/pool/biome_class

# Note: pre-2026-05-30 this file wrote a static stub `[1,4,1,3,1,7,1]` to
# `storage evercraft:database temp.board_quests` with ZERO readers (verified dead — AU34-5).
# Removed; the real roll lives in `evercraft:quests/preview/roll_options` + biome_reroll macro.
