# Quest Auto-Tracker — Toggle on/off
# Run as player

execute if entity @s[tag=ec.quest_tracking] run tag @s remove ec.quest_tracking
data modify storage evercraft:notify stage.c set value [{text:"Quest Tracker: ",color:"gray"},{text:"OFF",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute if entity @s[tag=ec.quest_tracking] run function evercraft:util/notify/emit
execute if entity @s[tag=ec.quest_tracking] run return 0

tag @s add ec.quest_tracking
scoreboard players set @s ec.qst_remind 0
scoreboard players set @s ec.qst_lprog 0
data modify storage evercraft:notify stage.c set value [{text:"Quest Tracker: ",color:"gray"},{text:"ON",color:"green"},{text:" — quest progress reminders in chat",color:"dark_gray"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.hat master @s ~ ~ ~ 0.5 1.8
