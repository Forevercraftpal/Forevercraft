# ============================================================
# Grant Exquisite Crate from Advancement
# ============================================================

function evercraft:quests/advancement_rewards/check_iron_gate
execute unless score @s ec.iron_gate_passed matches 1 run return fail

# Check inventory space before giving
execute store result score #inv_full ec.var run function evercraft:util/check_inv_full

execute if score #inv_full ec.var matches 0 run loot give @s loot evercraft:achievements/crates/exquisite
execute if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:achievements/crates/exquisite
execute if score #inv_full ec.var matches 1 at @s as @e[type=item,nbt={Item:{id:"minecraft:barrel"},Age:0s},distance=..2,sort=nearest,limit=1] run data merge entity @s {Age:2400s}
experience add @s 200 points

execute if score @s ec.fx_snd matches 1.. run playsound minecraft:ui.toast.challenge_complete player @s ~ ~ ~ 0.5 1
data modify storage evercraft:notify stage.c set value [{text:"You received an ",color:"gray"},{text:"Exquisite Achievement Crate",color:"light_purple"},{text:" + ",color:"gray"},{text:"200 XP",color:"green"},{text:"!",color:"gray"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Inventory full! Your crate was dropped at your feet.",color:"yellow"}]
scoreboard players set #ndur ec.temp 45
execute if score #inv_full ec.var matches 1 run function evercraft:util/notify/emit
execute if score #inv_full ec.var matches 1 if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bass player @s ~ ~ ~ 1 0.5

# Iluminación de Ne candle — rare bonus (~4%) on top of an Exquisite quest reward (Joseph 2026-06-15).
execute store result score #cnd_roll ec.var run random value 1..100
execute if score #cnd_roll ec.var matches 1..4 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:candle/ilum_ne
execute if score #cnd_roll ec.var matches 1..4 if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:candle/ilum_ne
execute if score #cnd_roll ec.var matches 1..4 run function evercraft:decor/candle/reward_note

# Track total achievements earned
scoreboard players add @s ach.total 1
