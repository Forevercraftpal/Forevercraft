# H04 Grand Harvest — Per-crop delta check
# AU34-1 (Joseph 2026-05-30): true per-crop tracking — quest completes only when ALL 9 crops
# have ≥10 picked-up since accept. Replaces the 90-total proxy that let a wheat-farm complete it.
# Run as @s = player. Caller (track_tier6) gates on quest_id_6 matches 4.
#
# Returns: #h04_ok ec.var = 1 if all 9 deltas ≥ 10, else 0.
# Also writes ec.quest_prog_6 = number of crops at ≥10 (for progress display, 0-9).

# Start optimistic (will clear to 0 on any short delta)
scoreboard players set #h04_ok ec.var 1
scoreboard players set @s ec.quest_prog_6 0

# Per-crop check: compute delta into #h04_d ec.var; if < 10, clear #h04_ok; if ≥ 10, bump prog
scoreboard players set #h04_d ec.var 0
scoreboard players operation #h04_d ec.var = @s ec.tt_s_wheat
scoreboard players operation #h04_d ec.var -= @s ec.q_h04_wheat_s
execute if score #h04_d ec.var matches ..9 run scoreboard players set #h04_ok ec.var 0
execute if score #h04_d ec.var matches 10.. run scoreboard players add @s ec.quest_prog_6 1

scoreboard players set #h04_d ec.var 0
scoreboard players operation #h04_d ec.var = @s ec.tt_s_carrot
scoreboard players operation #h04_d ec.var -= @s ec.q_h04_carrot_s
execute if score #h04_d ec.var matches ..9 run scoreboard players set #h04_ok ec.var 0
execute if score #h04_d ec.var matches 10.. run scoreboard players add @s ec.quest_prog_6 1

scoreboard players set #h04_d ec.var 0
scoreboard players operation #h04_d ec.var = @s ec.tt_s_potato
scoreboard players operation #h04_d ec.var -= @s ec.q_h04_potato_s
execute if score #h04_d ec.var matches ..9 run scoreboard players set #h04_ok ec.var 0
execute if score #h04_d ec.var matches 10.. run scoreboard players add @s ec.quest_prog_6 1

scoreboard players set #h04_d ec.var 0
scoreboard players operation #h04_d ec.var = @s ec.tt_s_beetrt
scoreboard players operation #h04_d ec.var -= @s ec.q_h04_beetrt_s
execute if score #h04_d ec.var matches ..9 run scoreboard players set #h04_ok ec.var 0
execute if score #h04_d ec.var matches 10.. run scoreboard players add @s ec.quest_prog_6 1

scoreboard players set #h04_d ec.var 0
scoreboard players operation #h04_d ec.var = @s ec.tt_s_melon
scoreboard players operation #h04_d ec.var -= @s ec.q_h04_melon_s
execute if score #h04_d ec.var matches ..9 run scoreboard players set #h04_ok ec.var 0
execute if score #h04_d ec.var matches 10.. run scoreboard players add @s ec.quest_prog_6 1

scoreboard players set #h04_d ec.var 0
scoreboard players operation #h04_d ec.var = @s ec.tt_s_pumpkn
scoreboard players operation #h04_d ec.var -= @s ec.q_h04_pumpkn_s
execute if score #h04_d ec.var matches ..9 run scoreboard players set #h04_ok ec.var 0
execute if score #h04_d ec.var matches 10.. run scoreboard players add @s ec.quest_prog_6 1

scoreboard players set #h04_d ec.var 0
scoreboard players operation #h04_d ec.var = @s ec.tt_s_nwart
scoreboard players operation #h04_d ec.var -= @s ec.q_h04_nwart_s
execute if score #h04_d ec.var matches ..9 run scoreboard players set #h04_ok ec.var 0
execute if score #h04_d ec.var matches 10.. run scoreboard players add @s ec.quest_prog_6 1

scoreboard players set #h04_d ec.var 0
scoreboard players operation #h04_d ec.var = @s ec.tt_s_sugar
scoreboard players operation #h04_d ec.var -= @s ec.q_h04_sugar_s
execute if score #h04_d ec.var matches ..9 run scoreboard players set #h04_ok ec.var 0
execute if score #h04_d ec.var matches 10.. run scoreboard players add @s ec.quest_prog_6 1

scoreboard players set #h04_d ec.var 0
scoreboard players operation #h04_d ec.var = @s ec.tt_s_berries
scoreboard players operation #h04_d ec.var -= @s ec.q_h04_berries_s
execute if score #h04_d ec.var matches ..9 run scoreboard players set #h04_ok ec.var 0
execute if score #h04_d ec.var matches 10.. run scoreboard players add @s ec.quest_prog_6 1
