# H04 Grand Harvest — Snapshot per-crop counters on accept
# AU34-1 (Joseph 2026-05-30): captures the 9 farmable-crop picked_up baselines so check.mcfunction
# can compute deltas. Replaces the lifetime-crops_harvested proxy snapshot at setup_heroic.
# Run as @s = player accepting the quest.

scoreboard players operation @s ec.q_h04_wheat_s = @s ec.tt_s_wheat
scoreboard players operation @s ec.q_h04_carrot_s = @s ec.tt_s_carrot
scoreboard players operation @s ec.q_h04_potato_s = @s ec.tt_s_potato
scoreboard players operation @s ec.q_h04_beetrt_s = @s ec.tt_s_beetrt
scoreboard players operation @s ec.q_h04_melon_s = @s ec.tt_s_melon
scoreboard players operation @s ec.q_h04_pumpkn_s = @s ec.tt_s_pumpkn
scoreboard players operation @s ec.q_h04_nwart_s = @s ec.tt_s_nwart
scoreboard players operation @s ec.q_h04_sugar_s = @s ec.tt_s_sugar
scoreboard players operation @s ec.q_h04_berries_s = @s ec.tt_s_berries
