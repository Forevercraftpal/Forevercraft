# Wiring Audit #30 (2026-05-29) — Explore handler: End City
# Watched by: K28 (T4 x2, "Explore 2 End Cities"), X02 (T5 x1), H10 (T6 x3, "Explore 3 End Cities").
# Run as @s = player (advancement reward context).
advancement revoke @s only evercraft:quests/explore/end_city

# Chest-node structure batch (§11 / §14.6, P2.5): first-visit player-bound chests INSIDE this structure.
# Runs every entry; its own check_visited handles the per-instance dedupe + 1-MC-day re-spawn cooldown.
function evercraft:chest_nodes/struct/enter/end_city

# AU34-2 (Joseph 2026-05-30): per-instance dedupe — skip credit if player already visited this structure
function evercraft:quests/explore/check_visited
execute if score #qe_visited ec.var matches 1 run return 0
function evercraft:quests/explore/mark_visited

# K28 — End Island Chain (T4, 2 End Cities)
execute if score @s ec.quest_id_4 matches 28 run scoreboard players add @s ec.exp_prog_4 1
execute if score @s ec.quest_id_4 matches 28 run scoreboard players operation @s ec.quest_prog_4 = @s ec.exp_prog_4
execute if score @s ec.quest_id_4 matches 28 if score @s ec.quest_prog_4 matches 2.. run function evercraft:quests/active/complete_tier4

# X02 — End City Raid (T5, 1 End City)
execute if score @s ec.quest_id_5 matches 2 run scoreboard players add @s ec.exp_prog_5 1
execute if score @s ec.quest_id_5 matches 2 run scoreboard players operation @s ec.quest_prog_5 = @s ec.exp_prog_5
execute if score @s ec.quest_id_5 matches 2 if score @s ec.quest_prog_5 matches 1.. run function evercraft:quests/active/complete_tier5

# H10 — The Void Walker (T6, 3 End Cities)
execute if score @s ec.quest_id_6 matches 10 run scoreboard players add @s ec.exp_prog_6 1
execute if score @s ec.quest_id_6 matches 10 run scoreboard players operation @s ec.quest_prog_6 = @s ec.exp_prog_6
execute if score @s ec.quest_id_6 matches 10 if score @s ec.quest_prog_6 matches 3.. run function evercraft:quests/active/complete_tier6
