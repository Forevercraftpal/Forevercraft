# Wiring Audit #30 (2026-05-29) — Explore handler: Deep Dark biome
# Watched by: K11 (T4 x1, "Explore the Deep Dark").
# Run as @s = player (advancement reward context).
advancement revoke @s only evercraft:quests/explore/deep_dark

# AU34-2 (Joseph 2026-05-30): per-instance dedupe — skip credit if player already visited this structure
function evercraft:quests/explore/check_visited
execute if score #qe_visited ec.var matches 1 run return 0
function evercraft:quests/explore/mark_visited

# K11 — Warden's Shadow (T4, enter Deep Dark biome)
execute if score @s ec.quest_id_4 matches 11 run scoreboard players add @s ec.exp_prog_4 1
execute if score @s ec.quest_id_4 matches 11 run scoreboard players operation @s ec.quest_prog_4 = @s ec.exp_prog_4
execute if score @s ec.quest_id_4 matches 11 if score @s ec.quest_prog_4 matches 1.. run function evercraft:quests/active/complete_tier4
