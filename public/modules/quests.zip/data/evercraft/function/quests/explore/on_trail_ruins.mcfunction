# Wiring Audit #30 (2026-05-29) — Explore handler: Trail Ruins
# Fired by advancement evercraft:quests/explore/trail_ruins (minecraft:location trigger).
# Revoke so it can re-fire for future visits, then credit any active quest watching this structure.
# Run as @s = player (advancement reward context).
advancement revoke @s only evercraft:quests/explore/trail_ruins

# Chest-node structure batch (§11 / §14.6, P2.5): first-visit player-bound chests INSIDE this structure.
# Runs every entry; its own check_visited handles the per-instance dedupe + 1-MC-day re-spawn cooldown.
function evercraft:chest_nodes/struct/enter/trail_ruins

# AU34-2 (Joseph 2026-05-30): per-instance dedupe — skip credit if player already visited this structure
function evercraft:quests/explore/check_visited
execute if score #qe_visited ec.var matches 1 run return 0
function evercraft:quests/explore/mark_visited

# C13 — Trail Explorer (T3, find 1 Trail Ruins)
execute if score @s ec.quest_id_3 matches 13 run scoreboard players add @s ec.exp_prog_3 1
execute if score @s ec.quest_id_3 matches 13 run scoreboard players operation @s ec.quest_prog_3 = @s ec.exp_prog_3
execute if score @s ec.quest_id_3 matches 13 if score @s ec.quest_prog_3 matches 1.. run function evercraft:quests/active/complete_tier3
