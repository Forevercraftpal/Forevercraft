# Wiring Audit #30 (2026-05-29) — Explore handler: Trial Chambers
# Watched by: K08 (T4 x1), K34 (T4 x2), X35 (T5 x3).
# Run as @s = player (advancement reward context).
advancement revoke @s only evercraft:quests/explore/trial_chambers

# Chest-node structure batch (§11 / §14.6, P2.5): first-visit player-bound chests INSIDE this structure.
# Runs every entry; its own check_visited handles the per-instance dedupe + 1-MC-day re-spawn cooldown.
function evercraft:chest_nodes/struct/enter/trial_chambers

# AU34-2 (Joseph 2026-05-30): per-instance dedupe — skip credit if player already visited this structure
function evercraft:quests/explore/check_visited
execute if score #qe_visited ec.var matches 1 run return 0
function evercraft:quests/explore/mark_visited

# K08 — Trial Chamber Scout (T4, 1 chamber)
execute if score @s ec.quest_id_4 matches 8 run scoreboard players add @s ec.exp_prog_4 1
execute if score @s ec.quest_id_4 matches 8 run scoreboard players operation @s ec.quest_prog_4 = @s ec.exp_prog_4
execute if score @s ec.quest_id_4 matches 8 if score @s ec.quest_prog_4 matches 1.. run function evercraft:quests/active/complete_tier4

# K34 — Trial Chamber Sweep (T4, 2 chambers)
execute if score @s ec.quest_id_4 matches 34 run scoreboard players add @s ec.exp_prog_4 1
execute if score @s ec.quest_id_4 matches 34 run scoreboard players operation @s ec.quest_prog_4 = @s ec.exp_prog_4
execute if score @s ec.quest_id_4 matches 34 if score @s ec.quest_prog_4 matches 2.. run function evercraft:quests/active/complete_tier4

# X35 — Trial Champion (T5, 3 chambers)
execute if score @s ec.quest_id_5 matches 35 run scoreboard players add @s ec.exp_prog_5 1
execute if score @s ec.quest_id_5 matches 35 run scoreboard players operation @s ec.quest_prog_5 = @s ec.exp_prog_5
execute if score @s ec.quest_id_5 matches 35 if score @s ec.quest_prog_5 matches 3.. run function evercraft:quests/active/complete_tier5
