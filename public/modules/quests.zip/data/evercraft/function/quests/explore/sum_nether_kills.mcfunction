# Wiring Audit #30 (2026-05-29) — Sum nether-mob kills into ec.kills_nether
# Rolls up the vanilla minecraft.killed:* objectives for Nether-native mobs into a single
# lifetime counter. Used by X07 (Nether Star Fragment, 50) + H09 (Nether Domination, 100)
# via the snapshot-delta pattern (snapshot on accept in setup_tier5/setup_heroic, then this
# is re-summed in track and the snapshot subtracted).
# Run as @s = player. SOLE writer of ec.kills_nether.
scoreboard players set @s ec.kills_nether 0
scoreboard players operation @s ec.kills_nether += @s ec.kills_blaze
scoreboard players operation @s ec.kills_nether += @s ec.kills_ghast
scoreboard players operation @s ec.kills_nether += @s ec.kills_piglin
scoreboard players operation @s ec.kills_nether += @s ec.kills_piglin_brute
scoreboard players operation @s ec.kills_nether += @s ec.kills_hoglin
scoreboard players operation @s ec.kills_nether += @s ec.kills_magma_cube
scoreboard players operation @s ec.kills_nether += @s ec.kills_wither_skeleton
