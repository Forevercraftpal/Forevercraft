# Explore Quest — Mark this structure-position as visited by this player
# AU34-2 (Joseph 2026-05-30): summon ec.q_explored marker stamped with player UUID at @s pos.
# Run as @s = player at player position (called from each explore handler after check_visited
# returned fresh).

# Summon marker at player position with transient new-tag for the data-stamp step
summon marker ~ ~ ~ {Tags:["ec.q_explored","ec.q_explored_new","smithed.entity"]}

# Stamp player UUID onto the new marker
data modify entity @e[type=marker,tag=ec.q_explored_new,limit=1] data.player_uuid set from entity @s UUID

# Clear the transient tag — marker stays tagged ec.q_explored for future dedupe scans
tag @e[type=marker,tag=ec.q_explored_new] remove ec.q_explored_new
