# Wiring Audit #30 (2026-05-29) — Explore handler: Shipwreck
# Watched by: H08 (T6 x5, "Find 5 Shipwrecks").
# Run as @s = player (advancement reward context).
advancement revoke @s only evercraft:quests/explore/shipwreck

# Chest-node structure batch (§11 / §14.6, P2.5): first-visit player-bound chests INSIDE this structure.
# Runs every entry; its own check_visited handles the per-instance dedupe + 1-MC-day re-spawn cooldown.
function evercraft:chest_nodes/struct/enter/shipwreck

# AU34-2 (Joseph 2026-05-30): per-instance dedupe — skip credit if player already visited this structure
function evercraft:quests/explore/check_visited
execute if score #qe_visited ec.var matches 1 run return 0
function evercraft:quests/explore/mark_visited

# H08 — Treasure Fleet (T6, 5 shipwrecks)
execute if score @s ec.quest_id_6 matches 8 run scoreboard players add @s ec.exp_prog_6 1
execute if score @s ec.quest_id_6 matches 8 run scoreboard players operation @s ec.quest_prog_6 = @s ec.exp_prog_6
execute if score @s ec.quest_id_6 matches 8 if score @s ec.quest_prog_6 matches 5.. run function evercraft:quests/active/complete_tier6
