# Explore Quest — Per-instance dedupe check
# AU34-2 (Joseph 2026-05-30): mirror evercraft:structures/storage/compare_uuid pattern.
# Run as @s = player, at player position. Writes #qe_visited ec.var = 1 if any ec.q_explored
# marker within 96 blocks matches the player's UUID, else 0.
# Caller (each explore handler) gates credit on #qe_visited matches 0.

scoreboard players set #qe_visited ec.var 0

# Stash player UUID into ec.var scratch for comparison inside `as marker` context
execute store result score #qe_p0 ec.var run data get entity @s UUID[0]
execute store result score #qe_p1 ec.var run data get entity @s UUID[1]
execute store result score #qe_p2 ec.var run data get entity @s UUID[2]
execute store result score #qe_p3 ec.var run data get entity @s UUID[3]

# Scan nearby visited markers; _uuid_match sets #qe_visited=1 on UUID match
execute as @e[type=marker,tag=ec.q_explored,distance=..96] run function evercraft:quests/explore/_uuid_match
