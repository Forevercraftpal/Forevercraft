# Explore Quest — UUID match leaf (run as ec.q_explored marker)
# AU34-2 (Joseph 2026-05-30): compares marker's stored player_uuid against #qe_p0..p3 stash.
# Sets #qe_visited ec.var = 1 if all 4 UUID ints match (player has visited this structure).
# Called from check_visited; player UUID already stashed into #qe_p0..p3 by caller.

execute store result score #qe_m0 ec.var run data get entity @s data.player_uuid[0]
execute store result score #qe_m1 ec.var run data get entity @s data.player_uuid[1]
execute store result score #qe_m2 ec.var run data get entity @s data.player_uuid[2]
execute store result score #qe_m3 ec.var run data get entity @s data.player_uuid[3]

execute if score #qe_m0 ec.var = #qe_p0 ec.var if score #qe_m1 ec.var = #qe_p1 ec.var if score #qe_m2 ec.var = #qe_p2 ec.var if score #qe_m3 ec.var = #qe_p3 ec.var run scoreboard players set #qe_visited ec.var 1
