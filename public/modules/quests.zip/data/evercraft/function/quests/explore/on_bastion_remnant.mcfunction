# Wiring Audit #30 (2026-05-29) — Explore handler: Bastion Remnant
# Watched by: K38 (T4 x2, "Explore 2 Bastion Remnants"), X03 (T5 x1).
# Run as @s = player (advancement reward context).
advancement revoke @s only evercraft:quests/explore/bastion_remnant

# Chest-node structure batch (§11 / §14.6, P2.5): first-visit player-bound chests INSIDE this structure.
# Runs every entry; its own check_visited handles the per-instance dedupe + 1-MC-day re-spawn cooldown.
function evercraft:chest_nodes/struct/enter/bastion_remnant

# AU34-2 (Joseph 2026-05-30): per-instance dedupe — skip credit if player already visited this structure
function evercraft:quests/explore/check_visited
execute if score #qe_visited ec.var matches 1 run return 0
function evercraft:quests/explore/mark_visited

# K38 — Bastion Raid (T4, 2 bastions)
execute if score @s ec.quest_id_4 matches 38 run scoreboard players add @s ec.exp_prog_4 1
execute if score @s ec.quest_id_4 matches 38 run scoreboard players operation @s ec.quest_prog_4 = @s ec.exp_prog_4
execute if score @s ec.quest_id_4 matches 38 if score @s ec.quest_prog_4 matches 2.. run function evercraft:quests/active/complete_tier4

# X03 — Bastion Plunder (T5, 1 bastion)
execute if score @s ec.quest_id_5 matches 3 run scoreboard players add @s ec.exp_prog_5 1
execute if score @s ec.quest_id_5 matches 3 run scoreboard players operation @s ec.quest_prog_5 = @s ec.exp_prog_5
execute if score @s ec.quest_id_5 matches 3 if score @s ec.quest_prog_5 matches 1.. run function evercraft:quests/active/complete_tier5
