# Wiring Audit #30 (2026-05-29) — Explore handler: Stronghold
# Watched by: X06 (T5 x1, "Explore a Stronghold"), X28 (T5 x2, "Explore 2 Strongholds").
# Both are T5; only one T5 quest is active at a time, so the id branches are mutually exclusive.
# Run as @s = player (advancement reward context).
advancement revoke @s only evercraft:quests/explore/stronghold

# Chest-node structure batch (§11 / §14.6, P2.5): first-visit player-bound chests INSIDE this structure.
# Runs every entry; its own check_visited handles the per-instance dedupe + 1-MC-day re-spawn cooldown.
function evercraft:chest_nodes/struct/enter/stronghold

# AU34-2 (Joseph 2026-05-30): per-instance dedupe — skip credit if player already visited this structure
function evercraft:quests/explore/check_visited
execute if score #qe_visited ec.var matches 1 run return 0
function evercraft:quests/explore/mark_visited

# X06 — Stronghold Delve (T5, 1 stronghold)
execute if score @s ec.quest_id_5 matches 6 run scoreboard players add @s ec.exp_prog_5 1
execute if score @s ec.quest_id_5 matches 6 run scoreboard players operation @s ec.quest_prog_5 = @s ec.exp_prog_5
execute if score @s ec.quest_id_5 matches 6 if score @s ec.quest_prog_5 matches 1.. run function evercraft:quests/active/complete_tier5

# X28 — Stronghold Dive (T5, 2 strongholds)
execute if score @s ec.quest_id_5 matches 28 run scoreboard players add @s ec.exp_prog_5 1
execute if score @s ec.quest_id_5 matches 28 run scoreboard players operation @s ec.quest_prog_5 = @s ec.exp_prog_5
execute if score @s ec.quest_id_5 matches 28 if score @s ec.quest_prog_5 matches 2.. run function evercraft:quests/active/complete_tier5
