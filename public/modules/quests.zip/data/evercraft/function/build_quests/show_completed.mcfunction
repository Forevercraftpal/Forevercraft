# ============================================================
# The Build Quests Engine — Show completed quest (just-finished one)
# ============================================================
# Reads the just-completed quest from bq_cur.quest (still the OLD quest at this
# point in advance, before the pointer is bumped) and prints a green checkmark
# line. (Structural clone of fishing/questline/show_completed.)
# Run as @s = the player.
data modify storage evercraft:bq_cur o set from storage evercraft:bq_cur quest
function evercraft:build_quests/show_completed_macro with storage evercraft:bq_cur o
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.player.levelup master @s ~ ~ ~ 0.4 1.8
