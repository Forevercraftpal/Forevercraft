# ============================================================
# The Build Quests Engine — Start (begin the line at quest 1)
# ============================================================
# Run as @s = the player. The PUBLIC entry point (cross-seat contract #1):
# handcrafter/on_first_place (W3) calls this AFTER granting the card baseline +
# book; the temp admin entry build_quests/admin/give_book_temp calls it directly
# (until the real book ships in F4). Guard your caller on `ec.bq_active == 0`.
#
# Sets the linear pointer to quest 1, loads it into bq_cur, and shows the intro +
# first objective + the C0 lore line / [Skip ▸] button for quest 1.
# WRITER of the initial pointer state.

# === ACTIVATE + RESET LINEAR STATE ===
scoreboard players set @s ec.bq_active 1
# Auto-track this line for the [Skip ▸] button (Wiring #52): ec.gq_track follows the
# most-recently-activated line. Build = slot 8 (do_skip value-map). do_skip/do_skip_chapter
# read this; finish clears it if it is still pointed here. Latest-activated wins for a
# veteran on multiple lines (Skip targets the line they most recently began).
scoreboard players set @s ec.gq_track 8
scoreboard players set @s ec.bq_quest 1
scoreboard players set @s ec.bq_prog 0
scoreboard players set @s ec.bq_done 0
scoreboard players set @s ec.bq_complete 0
# Auto-pass flag clear at line start (Joseph 2026-06-05). Quest 1 ("place 10 ANY
# blocks") starts at ec.bq_prog 0 so its activation probe finds it unsatisfied →
# full reward when actually earned; this 0 just guarantees a clean slate.
scoreboard players set @s ec.bq_autopass 0
# Seed the catch-up cursor at the player's current lifetime blocks-placed so
# blocks placed BEFORE the line began never retro-credit an INCREMENTAL quest.
# (lifetime-TYPE quests read ach.blocks_placed directly, so a veteran still
#  auto-passes those at full reward on the next check — R1.)
scoreboard players operation @s ec.bq_place_seen = @s ach.blocks_placed

# Load quest 1 into bq_cur for the objective display.
function evercraft:build_quests/get_quest

# === PLACEMENT-BEAT GATE (WA63-PERF-PLACE-SPLICE) ===
# Set ec.bq_place_active from the freshly-loaded quest type so the per-placement hot path
# only does work when a placement beat is active. Quest 1 is place_any, so this is 1 here.
scoreboard players set @s ec.bq_place_active 0
execute if data storage evercraft:bq_cur {quest:{type:"place_any"}} run scoreboard players set @s ec.bq_place_active 1
execute if data storage evercraft:bq_cur {quest:{type:"variety"}} run scoreboard players set @s ec.bq_place_active 1
execute if data storage evercraft:bq_cur {quest:{type:"place_palette"}} run scoreboard players set @s ec.bq_place_active 1

# === INTRO (mirrors the Fisher intro tone — Seven-voice gray-italic) ===
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"The Builder's Quests",color:"gold",bold:true},{text:" ✦",color:"gold"}]
scoreboard players set #ndur ec.temp 50
function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Every hall begins with one honest stone set true. A long road of building lies ahead, artisan — follow it and master the craft of the made world.",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 70
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.player.levelup master @s ~ ~ ~ 0.4 1.4
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.6 1.2

# Subtle title flash, then show the first objective + its lore line / skip button.
title @s times 5 40 10
title @s subtitle {text:"Your first task awaits",color:"gray",italic:true}
function evercraft:build_quests/show_objective
# C0 pacing: deliver quest 1's lore line (muted in Quick Mode) + [Skip ▸] button.
data modify storage evercraft:qp_cur o set from storage evercraft:bq_cur quest
function evercraft:quest_pacing/render_lore
