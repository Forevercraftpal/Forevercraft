# ============================================================
# The Build Quests Engine — Advance (complete current quest -> next)
# ============================================================
# Run as @s = the player. Called by build_quests/check when the active quest is
# satisfied, AND it is the PUBLIC skip target (quest_pacing/do_skip routes the
# tracked line's advance here at full reward — SCHEMA_DELTA §4). WRITER of the
# linear pointer (ec.bq_quest), ec.bq_prog reset, ec.bq_done, ec.bq_complete.
# (Structural clone of fishing/questline/advance.)
#
# Order: show_completed -> reward -> bump pointer (clamped) -> reset prog ->
#        +1 done -> load next quest -> on_advance_notify (lore + new objective).
#        Final quest -> finish() one-shot fanfare, pointer clamped at N.

# --- Idempotency / out-of-range guards (mirror the Fisher upper-bound guard) ---
execute unless score @s ec.bq_active matches 1 run return 0
execute if score @s ec.bq_complete matches 1 run return 0

# Registry length = N (the last valid quest index). Dynamic so the engine never
# hardcodes the quest count — it grows automatically as batches are added.
execute store result score #bq_n ec.temp run data get storage evercraft:bq_registry quests
# Defensive: if the registry failed to load (length 0), do nothing.
execute if score #bq_n ec.temp matches ..0 run return 0
# If the pointer is somehow already past N, clamp + finish (don't run past the end).
execute if score @s ec.bq_quest > #bq_n ec.temp run function evercraft:build_quests/finish
execute if score @s ec.bq_quest > #bq_n ec.temp run return 0

# === 1) SHOW WHAT WAS JUST COMPLETED (bq_cur still holds the old quest) ===
function evercraft:build_quests/show_completed

# === 2) PAY OUT THE REWARD for the completed quest ===
function evercraft:build_quests/reward

# === 2b) ADDITIVE: credit the DEXTERITY advantage tree (XP-REWARD-ECONOMY.md). ===
# On TOP of the existing reward. Feeds the normal level-up grind gate (adv.stat_place);
# the player still spends their own vanilla XP via the Advantages GUI to level. Runs
# BEFORE the pointer bump so ec.bq_quest still holds the just-completed quest index
# (the ramp key — the bump below happens after). See tree_credit for sizing rationale.
function evercraft:build_quests/tree_credit

# === 3) ADVANCE THE LINEAR POINTER + COUNTERS ===
scoreboard players add @s ec.bq_quest 1
scoreboard players set @s ec.bq_prog 0
scoreboard players add @s ec.bq_done 1

# === 4) FINAL-QUEST HANDLING ===
# Detect the overflow FIRST (into a flag), then clamp the pointer back to N (so a
# future check can't index out of range) and run the one-shot completion fanfare.
scoreboard players set #bq_overflow ec.temp 0
execute if score @s ec.bq_quest > #bq_n ec.temp run scoreboard players set #bq_overflow ec.temp 1
execute if score #bq_overflow ec.temp matches 1 run scoreboard players operation @s ec.bq_quest = #bq_n ec.temp
execute if score #bq_overflow ec.temp matches 1 run function evercraft:build_quests/finish

# Not finished: load the next quest into bq_cur and notify (lore + new objective).
execute if score #bq_overflow ec.temp matches 0 run function evercraft:build_quests/get_quest

# Auto-pass probe (Joseph 2026-06-05): is the NEW quest already satisfied with zero
# effort? If so, reward.mcfunction pays a token instead of the full XP dump. Interludes/
# count:0 are excluded (they auto-pass for everyone by design and keep their coin
# reward). Place quests have ec.bq_prog=0 at activation so the probe finds them
# unsatisfied → full reward when actually earned. ORDERING: reward (step 2) already
# ran for the just-completed quest, reading the flag set by THAT quest's activation
# probe (run at the end of the PREVIOUS advance) — so this probe overwrites the flag
# only for the NEXT quest, never the one just paid.
execute if score #bq_overflow ec.temp matches 0 run scoreboard players set @s ec.bq_autopass 0
execute if score #bq_overflow ec.temp matches 0 run scoreboard players set #bq_satisfied ec.temp 0
execute if score #bq_overflow ec.temp matches 0 run data modify storage evercraft:bq_cur o set from storage evercraft:bq_cur quest
execute if score #bq_overflow ec.temp matches 0 unless data storage evercraft:bq_cur o{beat:"interlude"} unless data storage evercraft:bq_cur o{count:0} run function evercraft:build_quests/check_macro with storage evercraft:bq_cur o
execute if score #bq_overflow ec.temp matches 0 if score #bq_satisfied ec.temp matches 1 run scoreboard players set @s ec.bq_autopass 1

execute if score #bq_overflow ec.temp matches 0 run function evercraft:build_quests/on_advance_notify
