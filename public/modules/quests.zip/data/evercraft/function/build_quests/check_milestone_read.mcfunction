# ============================================================
# The Build Quests Engine — Milestone score reader (macro body)
# ============================================================
# Called `with storage evercraft:bq_cur o`. Loads the milestone mirror score
# selected by quest.target into #bq_ms_val ec.temp for check_type/milestone.
# (Structural clone of fishing/questline/check_milestone_read.)
#
# Valid milestone targets and the engine-owned source they map to:
#   "blocks_placed" -> ach.blocks_placed  (lifetime placement counter; the spine)
#   "total_done"    -> ec.bq_done         (lifetime completed-quest counter)
#   "cf_rank"       -> ec.cf_rank          (Craftforever Artisan rank — read-only)
#
# Default 0 so an unrecognised target leaves the temp at 0 (defensive — the
# milestone helper then simply never satisfies on a typo'd target).
scoreboard players set #bq_ms_val ec.temp 0

# blocks_placed reads the lifetime placement counter (R1: a veteran auto-passes).
execute if data storage evercraft:bq_cur {o:{target:"blocks_placed"}} store result score #bq_ms_val ec.temp run scoreboard players get @s ach.blocks_placed

# total_done reuses the lifetime completed-quest counter.
execute if data storage evercraft:bq_cur {o:{target:"total_done"}} store result score #bq_ms_val ec.temp run scoreboard players get @s ec.bq_done

# cf_rank reads the live Craftforever Artisan rank (read-only mirror, R-table).
execute if data storage evercraft:bq_cur {o:{target:"cf_rank"}} store result score #bq_ms_val ec.temp run scoreboard players get @s ec.cf_rank
