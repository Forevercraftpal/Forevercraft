# BQ check helper — place_any (any block placement). Incremental quest.
# Satisfied when ec.bq_prog >= quest.count (#bq_count ec.temp). @s = player.
# (on_place_tally increments ec.bq_prog on each placement while this quest is active.)
scoreboard players set #bq_satisfied ec.temp 0
execute if score @s ec.bq_prog >= #bq_count ec.temp run scoreboard players set #bq_satisfied ec.temp 1
