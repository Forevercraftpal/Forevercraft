# BQ check helper — home_tier (the player's Hearthstone home reaches a tier).
# Read-only over hs.tier (Home Tier 0-5, sole writer housing/). Satisfied when
# hs.tier >= quest.count (#bq_count ec.temp). @s = player.
# (W6-housing convergence chapter. hs.tier is declared in housing/load, read-only
#  here — this engine writes NO housing objective.)
#
# This is a VETERAN-FRIENDLY threshold read (like lifetime): a player who already
# owns a tier-N home auto-passes on the next 20t check_progress tick at full
# reward. A newcomer satisfies it by genuinely claiming/upgrading their home.
#
# TEACH-GRANT (self-guarded, idempotent): the registry beat names a teach function
# in its `beat` field; check_macro is line-agnostic, so we fire the per-beat teach
# pointer here BEFORE the threshold read. The teach fn is unless-guarded (only
# tellraws/gives when the player still lacks the thing) so calling it each check is
# spam-free. The beat field carries the teach name (h1_claim_home / h6_garden).
function evercraft:build_quests/teach_dispatch
scoreboard players set #bq_satisfied ec.temp 0
execute if score @s hs.tier >= #bq_count ec.temp run scoreboard players set #bq_satisfied ec.temp 1
