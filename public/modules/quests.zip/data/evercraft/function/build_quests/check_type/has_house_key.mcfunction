# BQ check helper — has_house_key (the player owns the House Key). Read-only over
# the hs.has_satchel tag (set by housing/satchel/award — the House Key item grant).
# Satisfied when the player carries that tag. @s = player. (W6-housing H7.)
#
# count is ignored (presence test, not a threshold) — the registry row carries
# count:1 for display only. A veteran who already earned the House Key auto-passes;
# a newcomer reaches Architect comfort + Tier 3 and is awarded one. The teach-grant
# (teach/h7_house_key) calls housing/satchel/award unless-guarded, so a player who
# has met the home requirements but never got the award is handed it here.
function evercraft:build_quests/teach_dispatch
scoreboard players set #bq_satisfied ec.temp 0
execute if entity @s[tag=hs.has_satchel] run scoreboard players set #bq_satisfied ec.temp 1
