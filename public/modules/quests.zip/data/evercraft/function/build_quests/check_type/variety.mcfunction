# BQ check helper — variety (place blocks of any kind, like place_any but framed
# as a "use many block types" teach beat). Incremental quest.
# Satisfied when ec.bq_prog >= quest.count. @s = player.
#
# F1 scope note: the engine treats `variety` as an incremental placement count
# (each placement during a variety quest increments ec.bq_prog via the hot-path
# tally), so it mechanically resolves like place_any. A future wave MAY tighten it
# to count DISTINCT block types (a per-player seen-bitset) without touching this
# threshold compare — the registry row + detector would carry that, not this file.
scoreboard players set #bq_satisfied ec.temp 0
execute if score @s ec.bq_prog >= #bq_count ec.temp run scoreboard players set #bq_satisfied ec.temp 1
