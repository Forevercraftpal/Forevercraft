# BQ check helper — milestone (a mirror-score threshold). Threshold quest.
# Reads the target mirror score (blocks_placed/total_done/cf_rank) into
# #bq_ms_val ec.temp via check_milestone_read, then satisfies when it reaches
# quest.count (#bq_count ec.temp). @s = player.
#
# Unlike the Fisher engine (which loads the mirror inside check_macro), this
# helper loads it itself so check_macro stays a clean per-type dispatch and the
# non-milestone helpers never pay the milestone read.
scoreboard players set #bq_satisfied ec.temp 0
function evercraft:build_quests/check_milestone_read with storage evercraft:bq_cur o
execute if score #bq_ms_val ec.temp >= #bq_count ec.temp run scoreboard players set #bq_satisfied ec.temp 1
