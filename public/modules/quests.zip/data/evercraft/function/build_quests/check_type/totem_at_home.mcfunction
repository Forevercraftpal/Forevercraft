# BQ check helper — totem_at_home (the player has placed a glyph totem AND is/was
# established in a home zone). Read-only over hs.totems (House Totems Placed lifetime,
# sole writer inscription/totem_count_house) + hs.in_zone (In Home Zone, sole writer
# housing/zone/*). Satisfied when hs.totems >= quest.count AND hs.in_zone matches 1.
# @s = player. (W6-housing H4 — "only satisfies inside a home zone, hs.in_zone".)
#
# The home-zone gate is the wave's explicit H4 constraint: a glyph totem teaches the
# HOME inscription network, so the beat only completes while the player stands in
# their zone (hs.in_zone is set on zone-enter, cleared on leave). A veteran with
# totems already placed auto-passes the moment they are home; a newcomer forges a
# totem in their zone. The teach-grant points them at the glyph forge.
function evercraft:build_quests/teach_dispatch
scoreboard players set #bq_satisfied ec.temp 0
execute if score @s hs.totems >= #bq_count ec.temp if score @s hs.in_zone matches 1 run scoreboard players set #bq_satisfied ec.temp 1
