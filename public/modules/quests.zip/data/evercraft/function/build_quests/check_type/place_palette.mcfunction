# BQ check helper — place_palette (place blocks from one colour/material family).
# Incremental quest. Satisfied when ec.bq_prog >= quest.count. @s = player.
#
# The PALETTE FILTER lives in the detector, not here: the tag-filtered placement
# advancements (build_quests/place_palette/{warm,cool,stone_family}) fire
# on_place_tally ONLY for a block in the matching #evercraft:bq_palette/<fam> tag,
# AND on_place_tally additionally gates the increment on quest.target == the fired
# palette. So by the time we read ec.bq_prog here, it already counts ONLY
# palette-matching placements. This helper is a pure threshold compare (identical
# shape to place_any) — the family scoping is upstream.
#
# W6-housing: a place_palette beat MAY carry a `teach` field (the H5 colour-theory
# chapter does, target:"nature"). teach_dispatch is existence-gated on that field, so
# it is a guaranteed no-op for the engine's own warm/stone palette beats (q2/q5, no
# `teach`). It must NOT write ec.bq_prog (the placement tally owns it) — and it does
# not (the place_palette teach only tellraws, gated on ec.bq_prog matches 0). Additive,
# no behaviour change for legacy palette beats.
function evercraft:build_quests/teach_dispatch
scoreboard players set #bq_satisfied ec.temp 0
execute if score @s ec.bq_prog >= #bq_count ec.temp run scoreboard players set #bq_satisfied ec.temp 1
