# BQ check helper — artifact (the player has discovered at least count artifacts).
# Read-only over ec.artifacts_ever (Artifacts Ever Discovered, lifetime, sole writer
# achievements/*). Satisfied when ec.artifacts_ever >= quest.count. @s = player.
# (W6-housing H9.)
#
# ec.artifacts_ever is the LIFETIME discovery counter (never decremented), so this is
# the cleanest veteran-friendly read: anyone who has ever found an artifact auto-passes;
# a newcomer finds/forges one. The teach-grant points them at the artifact codex.
function evercraft:build_quests/teach_dispatch
scoreboard players set #bq_satisfied ec.temp 0
execute if score @s ec.artifacts_ever >= #bq_count ec.temp run scoreboard players set #bq_satisfied ec.temp 1
