# BQ check helper — stash_used (the player has Quick-Stashed at least count items).
# Read-only over hs.stashed (Items Stashed, sole writer housing/stash/*). Satisfied
# when hs.stashed >= quest.count. @s = player. (W6-housing H2.)
#
# Veteran-friendly threshold: a player who has already stashed auto-passes on the
# next 20t check at full reward. A newcomer satisfies it by Quick-Stashing — and the
# teach-grant below hands them the Stash Label that drives the system.
function evercraft:build_quests/teach_dispatch
scoreboard players set #bq_satisfied ec.temp 0
execute if score @s hs.stashed >= #bq_count ec.temp run scoreboard players set #bq_satisfied ec.temp 1
