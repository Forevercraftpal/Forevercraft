# BQ check helper — bb_haul (the player has performed enough Quick-Stash routes to
# have plausibly funnelled a big single-item haul into a Baúl). Read-only over
# hs.stashed (sole writer housing/stash/*, incremented by claim_empty_baul:51 too).
# Satisfied when hs.stashed >= quest.count. @s = player. (W6-housing H3, DECISIONS D2.)
#
# WHY hs.stashed and not a dedicated Baúl-haul counter: claim_empty_baul.mcfunction
# (the >256-haul -> empty-Baúl funnel) increments hs.stashed on a successful big-haul
# claim (its line 51: `scoreboard players add @s hs.stashed 1`), but so do ordinary
# stashes — there is no per-player "big haul claimed" score in the live pack. Rather
# than write a new objective (the wave is ZERO-new-objectives), H3 uses a HIGHER
# hs.stashed threshold than H2 so it reads as "you have stashed enough that a big
# haul has flowed through your system." The honest copy (registry desc/lore) teaches
# the Baúl big-haul mechanic without claiming a counter we do not own. The D2
# build-time smoke-test of the funnel is traced statically in the teammate note +
# flagged as a live followup for Joseph (claim_empty_baul + route_slot:28-38 wiring
# is sound; H3 ships per D2 with honest copy that names the empty-Baúl precondition).
function evercraft:build_quests/teach_dispatch
scoreboard players set #bq_satisfied ec.temp 0
execute if score @s hs.stashed >= #bq_count ec.temp run scoreboard players set #bq_satisfied ec.temp 1
