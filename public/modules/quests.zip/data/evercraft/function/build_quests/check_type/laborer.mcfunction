# BQ check helper — laborer (the player employs at least count laborers). Read-only
# over ec.lb_count (Laborer Count, sole writer laborer/reconcile_count). Satisfied
# when ec.lb_count >= quest.count. @s = player. (W6-housing H8.)
#
# Veteran-friendly: a player who already runs a little estate of laborers auto-passes;
# a newcomer hires one. The teach-grant points them at the laborer hire flow (no item
# is given — laborers are hired at a station, not handed out).
function evercraft:build_quests/teach_dispatch
scoreboard players set #bq_satisfied ec.temp 0
execute if score @s ec.lb_count >= #bq_count ec.temp run scoreboard players set #bq_satisfied ec.temp 1
