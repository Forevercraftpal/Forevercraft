# BQ check helper — protection (the player has enabled home protection). Read-only
# over hs.protect (Home Protection 0=off/1=on, sole writer housing/zone/*). Satisfied
# when hs.protect >= quest.count (count:1). @s = player. (W6-housing H10; R11 honest
# copy "deters mining-griefers in your zone," not "untouchable" — lives in the
# registry desc/lore, not here.)
#
# A veteran who already guards their home auto-passes; a newcomer toggles protection
# on at their Hearthstone. The teach-grant points them at the protection toggle.
function evercraft:build_quests/teach_dispatch
scoreboard players set #bq_satisfied ec.temp 0
execute if score @s hs.protect >= #bq_count ec.temp run scoreboard players set #bq_satisfied ec.temp 1
