# BQ check helper — lifetime (a lifetime blocks-placed threshold). Catch-up quest.
# Satisfied when ach.blocks_placed >= quest.count (#bq_count ec.temp). @s = player.
#
# THIS is the no-penalty veteran catch-up (R1): it reads the LIFETIME counter
# directly (NOT the post-start delta), so a fresh op whose ach.blocks_placed is
# already past a lifetime chapter's count auto-satisfies it on the next 20t
# check_progress tick and pays full reward — no re-grinding. The XP reward is a
# constant per quest, so this can't be farmed; the forward-only ec.bq_quest cursor
# (one advance per satisfied beat) prevents any retro double-credit.
#
# (Pollution/chrono-reset of ach.blocks_placed is tolerable here per SYNTHESIS R1:
#  a reset player re-walking the curriculum is fine; the reward is constant.)
scoreboard players set #bq_satisfied ec.temp 0
execute if score @s ach.blocks_placed >= #bq_count ec.temp run scoreboard players set #bq_satisfied ec.temp 1
