# ============================================================
# The Build Quests Engine — Reward dispatch (macro body)
# ============================================================
# Called `with storage evercraft:bq_cur o`, o = the completed quest
#   {...,reward,reward_amt,target,...}. Exposes the reward args to ec.temp and
# routes to reward_type/$(reward). Run as @s = the player.
#
# Shared args the helpers consume:
#   #bq_reward_amt ec.temp  = quest.reward_amt (coins amount / xp amount)
#   storage evercraft:bq_cur o.target = crate tier name (crate) / gear item id (gear)
$scoreboard players set #bq_reward_amt ec.temp $(reward_amt)

# Auto-pass: a quest satisfied at activation pays only the token (XP rewards only —
# items still pay in full). ec.bq_autopass was set by the activation probe in advance.
# The `return run` short-circuits the normal XP dispatch below; non-xp rewards
# (crate/gear/coins) and non-autopass quests fall through unchanged. (Joseph 2026-06-05.)
execute if score @s ec.bq_autopass matches 1 if data storage evercraft:bq_cur o{reward:"xp"} run return run function evercraft:build_quests/reward_autopass

# Dispatch on reward type: xp | coins | crate | gear  (NO title — R2)
$function evercraft:build_quests/reward_type/$(reward) with storage evercraft:bq_cur o
