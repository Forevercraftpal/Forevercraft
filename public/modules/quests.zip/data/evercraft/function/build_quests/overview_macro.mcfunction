# ============================================================
# The Build Quests Engine — Overview page (current-quest macro body)
# ============================================================
# Called `with storage evercraft:bq_cur o`, o = the current quest object
#   {id,title,desc,type,target,count,reward,reward_amt,chapter,(lore,beat,skippable)}.
# Prints the data-driven current-quest lines for the overview page; overview
# prints the score-driven progress/done lines around this.
# Mirrors the Fisher overview_macro tone (white-not-gray title, gray desc).
$tellraw @s [{text:"   ➤ ",color:"yellow"},{text:"$(title)",color:"white",bold:true}]
$tellraw @s [{text:"     $(desc)",color:"gray"}]
$tellraw @s [{text:"     Quest $(id)",color:"dark_gray"},{text:"  ·  Chapter $(chapter)",color:"dark_gray"},{text:"  ·  Goal: ",color:"dark_gray"},{text:"$(count)",color:"green"}]
