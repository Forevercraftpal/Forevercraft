# ============================================================
# The Build Quests Engine — One-time scoreboard objective declarations.
# (Structural clone of fishing/questline/declare_objectives, Council #1 Wave F1.)
# Split from build_quests/load so the per-/reload "Objective already exists"
# warnings only fire once. Gated by `#bq_loaded ec.var matches 1` — set at the
# bottom of this file.
# ============================================================
# This is the FOUNDATION line of the Grand Convergence: the shared quest-line
# engine every later line clones (Cooking/Chemistry/Forging/...). It is also the
# first adopter of the C0 pacing spec (lore/beat/skippable) — see check.mcfunction
# (interlude guard), on_advance_notify + overview (render_lore), and the registry
# rows that carry `lore`.

# === CORE LINEAR-POINTER SCOREBOARDS (mirror ec.fq_*; one writer each) ===
# ec.bq_active — 0/1, has this player started the Build line?
#   WRITER: build_quests/start (sets 1).
scoreboard objectives add ec.bq_active dummy "Build Quests Active"
# ec.bq_quest — current quest index, 1..N. The ONLY linear pointer.
#   WRITER: build_quests/start (sets 1) + build_quests/advance (+1, clamped at N).
scoreboard objectives add ec.bq_quest dummy "Build Quest Index"
# ec.bq_prog — progress within the current quest.
#   WRITER (increment): build_quests/on_place_tally (the single incrementer).
#   WRITER (reset to 0): build_quests/start + build_quests/advance.
scoreboard objectives add ec.bq_prog dummy "Build Quest Progress"
# ec.bq_done — lifetime completed quest count (overview + total_done milestone).
#   WRITER: build_quests/advance (+1) + build_quests/start (sets 0 on first start).
#   ALSO the ec.gq_track value-map slot for the Build line (do_skip fan-out).
scoreboard objectives add ec.bq_done dummy "Build Quests Done"
# (R2: ec.bq_title is DROPPED — ALL building-prestige titles come from the
#  Builder CARD, not the Build line. The Build line rewards only xp/coins/crate/
#  gear. No reward_type/title file exists in this engine.)

# === COMPLETION SENTINEL ===
# ec.bq_complete — 0/1, set once when the player finishes the final quest so the
#   "line complete!" tellraw fires exactly once. WRITER: build_quests/advance
#   (via finish) + build_quests/start (sets 0 on first start).
scoreboard objectives add ec.bq_complete dummy "Build Quests Complete"

# === LIFETIME-THRESHOLD CATCH-UP CURSOR (R1 — no-penalty forward-only) ===
# ec.bq_place_seen — snapshot of ach.blocks_placed taken at start. The lifetime/
#   milestone catch-up reads (ach.blocks_placed - this) as the count of blocks
#   placed SINCE the line began, so pre-activation blocks never retro-credit an
#   INCREMENTAL (place_any/place_palette/variety) quest. lifetime-TYPE quests read
#   ach.blocks_placed directly (R1: a veteran auto-passes at full reward).
#   WRITER: build_quests/start (seeds it) + build_quests/check_progress (re-syncs
#   so an incremental quest that becomes active mid-game starts counting from now).
scoreboard objectives add ec.bq_place_seen dummy "BQ Blocks-Placed Cursor"

# === AUTO-PASS FLAG (Joseph 2026-06-05 — reduced-reward-on-auto-pass) ===
# ec.bq_autopass — 0/1, set to 1 at a quest's ACTIVATION if the quest is ALREADY
#   satisfied with zero effort this run (e.g. a veteran who already owns the home /
#   key / artifact the new beat asks for). When that quest is later rewarded,
#   reward_macro routes an XP reward to reward_autopass (a token Building XP) instead
#   of the full XP dump — ITEMS (crate/gear/coins) still pay in full. The probe runs
#   in advance after the next quest loads; reward (for the prior quest) reads the flag
#   value set by THAT quest's own activation probe.
#   WRITER: build_quests/advance (probe) + build_quests/start (init 0) +
#   admin/strip_player_zero (reset).
scoreboard objectives add ec.bq_autopass dummy "BQ Auto-Pass Flag"

# === PLACEMENT-BEAT GATE (WA63-PERF-PLACE-SPLICE) ===
# ec.bq_place_active — 0/1, set to 1 ONLY while the active Build quest is a placement
#   beat (place_any / variety / place_palette), 0 otherwise. The per-placement hot path
#   (advantage/track/on_place_block) gates on this AS WELL AS ec.bq_active, so a player
#   on a non-placement beat (home_tier / artifact / teach / etc.) pays exactly one extra
#   score compare and never runs get_quest twice per block.
#   WRITER: build_quests/start + build_quests/advance (set next to the ec.bq_prog reset,
#   off the freshly-loaded quest type) + admin/strip_player_zero (reset).
scoreboard objectives add ec.bq_place_active dummy "BQ Placement Beat Active"

# Mark declarations done so re-/reload skips this file.
scoreboard players set #bq_loaded ec.var 1
