# ============================================================
# The Build Quests Engine — Overview page ("The Builder's Path" tab)
# ============================================================
# A clean tellraw page reached from the Grand Quests hub (W4 routes the "Build"
# category here) and the temp admin entry. Shows the player's current quest
# (title + desc + progress) + lifetime completed count. GUI-only; no /trigger.
# Run as @s = the player. (Structural clone of fishing/questline/overview, minus
# the rod-trial block; the title-tier block is dropped per R2 — building titles
# live on the Builder CARD, not here.)
#
# C0 PACING: the active beat's lore line + [Skip ▸] button render via
# quest_pacing/render_lore (same mute gate as the in-chat advance nudge).

# Frame header.
tellraw @s ""
tellraw @s [{text:"═══════════════════════════════",color:"gold"}]
tellraw @s [{text:"  ❦ ",color:"yellow"},{text:"The Builder's Path",color:"gold",bold:true},{text:" ❦",color:"yellow"}]
tellraw @s [{text:"  Master-Builder Quests",color:"gray",italic:true}]
tellraw @s [{text:"═══════════════════════════════",color:"gold"}]
tellraw @s ""

# === Not yet started: prompt to lay a first block. ===
execute unless score @s ec.bq_active matches 1 run tellraw @s [{text:"  ✦ ",color:"yellow"},{text:"Your path has not yet begun.",color:"white"}]
execute unless score @s ec.bq_active matches 1 run tellraw @s [{text:"  Place your first block to begin the",color:"gray"}]
execute unless score @s ec.bq_active matches 1 run tellraw @s [{text:"  Builder's Quests.",color:"gray"}]
execute unless score @s ec.bq_active matches 1 run tellraw @s ""

# === Completed the whole line: celebrate, no current quest. ===
execute if score @s ec.bq_complete matches 1 run tellraw @s [{text:"  ★ ",color:"gold"},{text:"Quests Complete!",color:"gold",bold:true}]
execute if score @s ec.bq_complete matches 1 run tellraw @s [{text:"  You have mastered the craft of the",color:"yellow"}]
execute if score @s ec.bq_complete matches 1 run tellraw @s [{text:"  made world. Every stone set true.",color:"yellow"}]
execute if score @s ec.bq_complete matches 1 run tellraw @s ""

# === Active + not complete: show the current quest (data-driven). ===
execute if score @s ec.bq_active matches 1 unless score @s ec.bq_complete matches 1 run function evercraft:build_quests/get_quest
execute if score @s ec.bq_active matches 1 unless score @s ec.bq_complete matches 1 run data modify storage evercraft:bq_cur o set from storage evercraft:bq_cur quest
execute if score @s ec.bq_active matches 1 unless score @s ec.bq_complete matches 1 run tellraw @s [{text:"  Current Quest",color:"yellow",bold:true}]
execute if score @s ec.bq_active matches 1 unless score @s ec.bq_complete matches 1 run function evercraft:build_quests/overview_macro with storage evercraft:bq_cur o
# Live progress bar — ec.bq_prog out of the quest's count (macro printed the count line).
execute if score @s ec.bq_active matches 1 unless score @s ec.bq_complete matches 1 run tellraw @s [{text:"   Progress: ",color:"gray"},{score:{name:"@s",objective:"ec.bq_prog"},color:"green",bold:true}]
# C0 lore line for the active beat (muted in Quick Mode) + [Skip ▸] button.
execute if score @s ec.bq_active matches 1 unless score @s ec.bq_complete matches 1 run data modify storage evercraft:qp_cur o set from storage evercraft:bq_cur quest
execute if score @s ec.bq_active matches 1 unless score @s ec.bq_complete matches 1 run function evercraft:quest_pacing/render_lore
execute if score @s ec.bq_active matches 1 unless score @s ec.bq_complete matches 1 run tellraw @s ""

# === Lifetime tally (always shown once started). ===
execute if score @s ec.bq_active matches 1 run tellraw @s [{text:"  Quests Completed: ",color:"gray"},{score:{name:"@s",objective:"ec.bq_done"},color:"green",bold:true}]
execute if score @s ec.bq_active matches 1 run tellraw @s ""

# Frame footer.
tellraw @s [{text:"═══════════════════════════════",color:"gold"}]
