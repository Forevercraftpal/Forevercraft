# ============================================================
# The Build Quests Engine — Auto-pass token reward (Joseph 2026-06-05)
# ============================================================
# Reduced reward for a quest auto-passed at activation (zero effort this run) — token
# Building XP only. Items (crate/gear/coins) are NOT routed here; only XP-reward quests
# (reward_macro short-circuits to this with `return run` ONLY for reward:"xp" + the
# ec.bq_autopass flag set by the activation probe in advance). Run as @s = the player.
#
# WHY: the `lifetime`→`place_any` conversion + the housing "do you already own X" beats
# meant a veteran's whole chain auto-completed at FULL XP (320–950 each) for no effort
# this run. This pays a flat token instead so items still flow but the big XP dump is
# throttled. Routed through the SAME FROZEN add_xp contract as reward_type/xp (R9).
scoreboard players set #cf_xp_amount ec.cf_temp 25
scoreboard players set #cf_xp_cat ec.cf_temp 3
function evercraft:craftforever/artisan/add_xp
# BAKE the literal "25" — do NOT use a live {score:...} ref. util/notify/emit queues the
# frame and renders it later; a live ref shows the wrong value in a multi-quest cascade
# (the known bug fixed in reward_type/coins + reward_type/xp). 25 is a tunable knob.
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"#7FFF7F"},{text:"Already mastered — ",color:"gray",italic:true},{text:"+25 Building XP",color:"#7FFF7F"},{text:" for your experience ✦",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.experience_orb.pickup master @s ~ ~ ~ 0.5 1.2
