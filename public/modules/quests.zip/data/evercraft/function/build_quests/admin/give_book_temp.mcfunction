# ============================================================
# The Build Quests Engine — TEMP entry: start the line (admin)
# ============================================================
# Run as operator
# Usage: /execute as <player> run function evercraft:build_quests/admin/give_book_temp
#   (or /function evercraft:build_quests/admin/give_book_temp while you ARE the player)
#
# SUPERSEDED (W3, 2026-06-01): the REAL obtain path now ships — placing the first block
# fires advancement/handcrafter/first_place → handcrafter/on_first_place, which grants the
# card baseline, the D4 backfill offer, the Handcrafter's Tome, and build_quests/start
# (ordering card→book→start, contract C1). This admin entry is KEPT as an op-only testing
# on-ramp (start the Build line without placing a block / for a player who never will).
# It is a thin wrapper over the PUBLIC build_quests/start, dup-guarded on
# ec.bq_active so re-running it never resets a player mid-line.
#
# (Marked "# Run as operator" + "# Usage:" so the v3 dead-code audit treats it as
#  an admin fixture and never flags it — DA-7 preserved-by-policy.)

execute unless score @s ec.bq_active matches 1 run function evercraft:build_quests/start
execute if score @s ec.bq_active matches 1 run tellraw @s [{text:"✦ ",color:"gold"},{text:"You are already on the Builder's Quests.",color:"gray"}]
