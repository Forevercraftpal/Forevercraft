# ============================================================
# The Build Quests Engine — Show current objective
# ============================================================
# Reads the current quest from bq_cur.quest (already loaded by get_quest) and
# prints its title + description as the active objective. Data-driven via macro
# (the quest text lives in the registry, not in per-quest files).
# Run as @s = the player. (Structural clone of fishing/questline/show_objective.)

# Surface the quest fields the macro needs at the top level of bq_cur.
data modify storage evercraft:bq_cur o set from storage evercraft:bq_cur quest
function evercraft:build_quests/show_objective_macro with storage evercraft:bq_cur o
