# ============================================================
# The Build Quests Engine — Advantage-Tree Credit (ADDITIVE layer, Joseph 2026-06-01)
# ============================================================
# Run as @s = the player, called from advance.mcfunction AFTER the existing
# `reward` call and BEFORE the pointer bump. Grants progress toward the DEXTERITY
# advantage tree (tree id 2, level `adv.dexterity` — the "blocks placed" tree) via
# the engine's NORMAL level-up gate — i.e. by feeding the grind scoreboard
# `adv.stat_place` that the gate consumes (req_stat = (level+1)*4000, difficulty-
# scaled). This is the spec's "award the XP/progress the tree consumes, NOT a raw
# `scoreboard set adv.dexterity`" (XP-REWARD-ECONOMY.md "Per-quest contribution").
# The player still spends their own vanilla XP via the Advantages GUI to realize
# each level — req_xp / prestige / do_prestige stay fully intact.
#
# ADDITIVE: this does NOT touch any existing per-quest reward (xp / coins / crate /
# gear via reward_macro). It runs alongside them.
#
# `adv.stat_place` is an established SHARED stat counter (written by the block-place
# tally, grant_tree_credit dungeon/raid credit, etc.) — NOT a one-writer-law
# objective. Adding the questline as one more writer is consistent with the existing
# pattern. No NEW scoreboard is introduced here.
#
# Sizing — Phase-3 RE-SCALE (Council review 2026-06-01, Joseph chose "re-scale to
# the gentle ramp"). The OLD +24000/+32000 numbers over-fed ~2x and saturated the
# dexterity stat wall by ~quest 2, because the gate is a CUMULATIVE LIFETIME
# THRESHOLD — the stat is NEVER subtracted when a level is taken, so every per-quest
# += stacks on the lifetime total and keeps unlocking further levels. The old header's
# "as cost climbs, +24000 buys fewer levels" reasoning was FALSE under a non-spent
# threshold; the promised "3-level stat ramp" never existed.
#
# CORRECT model (baseline = Pioneer ec.difficulty 3/unset, req_stat unscaled, mult=4000):
#   cumulative stat to reach total level L = mult * L*(L+1)/2 = 2000 * L * (L+1).
#   Author a FLAT per-quest credit c = mult/2 = 2000. The engine produces the
#   "fast early, gentle ramp after" OUTPUT automatically, because a flat stat input
#   clears a shrinking fraction of the growing (L+1)*mult per-level wall.
#   Check: q12 -> 12*2000 = 24000 stat = cum(L3, 2000*3*4=24000) -> EXACTLY 3 levels.
#          18q line -> 36000 stat = ~L3.5 (well under one prestige).
#          250q -> 500000 stat ~= cum(L24.5) ~= 0.96 prestige -> the "~250 quests
#            ~= ONE prestige" modesty anchor (XP-REWARD-ECONOMY.md). The completion
#            capstone (finish) drives the actual prestige(s).
#   On Newcomer (÷10) / Adventurer (÷5) the gate divides req_stat, so the same flat
#   credit goes 10x / 5x further — Newcomers level the tree fast, by design.
#   This unified flat = mult/2 curve is shared across all 5 subject books (cooking/
#   chemistry/forging = 25, build = 2000, fishing = 1000), so same-cost books match.
#
# No input tiering (the q13 ramp override is GONE) — the output ramp is the engine's.

# Flat per-quest dexterity credit = mult/2 = 2000 (single authored curve).
scoreboard players set #bq_tree_credit adv.temp 2000

# Feed the dexterity grind gate (shared multi-writer stat counter).
scoreboard players operation @s adv.stat_place += #bq_tree_credit adv.temp
