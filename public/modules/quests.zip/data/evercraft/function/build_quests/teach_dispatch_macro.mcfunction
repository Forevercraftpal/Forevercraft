# ============================================================
# The Build Quests Engine — Teach dispatch (macro body)
# ============================================================
# Called `with storage evercraft:bq_cur o`, o = the current quest object carrying a
# `teach` field (guaranteed present by teach_dispatch's existence gate). Routes to
# the named self-guarded teach-grant. Run as @s = the player.
#   teach:"h1_claim_home" -> evercraft:build_quests/teach/h1_claim_home
$function evercraft:build_quests/teach/$(teach)
