# ============================================================
# The Build Quests Engine — Check (macro body, dispatch on quest.type)
# ============================================================
# Called `with storage evercraft:bq_cur o`, o = current quest
#   {id,title,desc,type,target,count,reward,reward_amt,chapter,(lore,beat,skippable)}.
# Sets #bq_satisfied ec.temp to 1 iff the active quest's completion condition is
# met. Run as @s = the player. Only reached for NON-interlude beats (the C0
# interlude/count:0 guard in check.mcfunction short-circuits before this).
#
# A macro can't branch on an int comparison inline, so we expose the comparison
# inputs to ec.temp and route the per-TYPE decision to a tiny helper file:
#   - #bq_count ec.temp     = quest.count
#   - ec.bq_prog (player)   = incremental progress (place_any/place_palette/variety)
#   - ach.blocks_placed     = lifetime placement counter (lifetime/milestone read)
#   - ec.bq_place_seen     = catch-up cursor (incremental quests use the delta)
# The helper at check_type/$(type) sets #bq_satisfied ec.temp.

# Expose the threshold for the helpers to compare against.
$scoreboard players set #bq_count ec.temp $(count)

# Per-type decision (sets #bq_satisfied ec.temp). $(type) is one of:
#   place_any place_palette variety lifetime milestone
$function evercraft:build_quests/check_type/$(type)
