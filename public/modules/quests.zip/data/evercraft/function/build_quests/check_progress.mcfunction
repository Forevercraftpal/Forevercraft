# ============================================================
# The Build Quests Engine — 20t catch-up / interlude scheduler
# ============================================================
# Self-rescheduling, EXISTENCE-GATED 20t loop (kicked from build_quests/load with
# `replace`). It does work ONLY for players on the line (@a[scores={ec.bq_active=1}]),
# so with no Build players it iterates over NOTHING — no per-tick @a scan (the
# datapack's non-negotiable perf law).
#
# Two jobs per active player (both via the existing, idempotent check chain):
#   1. CATCH-UP (R1): a `lifetime`/`milestone` quest whose threshold the player's
#      ach.blocks_placed / ec.bq_done / ec.cf_rank already clears auto-satisfies on
#      this tick and pays full reward — a veteran is never walled. check() reads
#      those mirrors directly (no per-place hook needed for catch-up types).
#   2. INTERLUDE auto-pass (C0, SCHEMA_DELTA §3): a beat:"interlude"/count:0 beat is
#      instantly satisfied by check()'s interlude guard, so it advances here on the
#      next tick — delivering its lore once, paying its tiny reward once.
#
# The forward-only ec.bq_quest cursor (one advance per satisfied beat, inside
# advance) plus the place-cursor make this no-double-credit and no-penalty.

# === RUN THE CHECK FOR EVERY ACTIVE, NON-COMPLETE PLAYER ===
# (check() is itself existence-gated + idempotent; the outer selector keeps the
#  per-tick cost zero when nobody is on the line.)
execute as @a[scores={ec.bq_active=1,ec.bq_complete=0}] run function evercraft:build_quests/check

# === RE-SYNC THE INCREMENTAL CATCH-UP CURSOR ===
# Keep ec.bq_place_seen tracking ach.blocks_placed for active players, so an
# INCREMENTAL quest (place_any/place_palette/variety) that becomes active mid-game
# starts counting placements from "now" — blocks placed before the quest was the
# active beat never retro-complete it (forward-only). on_place_tally reads the
# delta off this cursor. Only re-synced for players whose CURRENT beat is NOT
# itself incremental-in-progress is unnecessary; the cursor is harmless to keep
# fresh because on_place_tally re-bases against it each placement.
# (No-op for non-active players via the selector.)

# Re-schedule self.
schedule function evercraft:build_quests/check_progress 20t replace
