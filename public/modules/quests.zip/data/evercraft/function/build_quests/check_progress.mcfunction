# ============================================================
# The Build Quests Engine — 20t catch-up / interlude scheduler
# ============================================================
# Self-rescheduling, EXISTENCE-GATED 20t loop (kicked from build_quests/load with
# `replace`). It does work ONLY for players on the line (@a[scores={ec.bq_active=1}]),
# so with no Build players it iterates over NOTHING — no per-tick @a scan (the
# datapack's non-negotiable perf law).
#
# Two jobs per active player (both via the existing, idempotent check chain):
#   1. CATCH-UP (R1): a `lifetime`/`milestone` quest whose threshold the player's
#      ach.blocks_placed / ec.bq_done / ec.cf_rank already clears auto-satisfies on
#      this tick and pays full reward — a veteran is never walled. check() reads
#      those mirrors directly (no per-place hook needed for catch-up types).
#   2. INTERLUDE auto-pass (C0, SCHEMA_DELTA §3): a beat:"interlude"/count:0 beat is
#      instantly satisfied by check()'s interlude guard, so it advances here on the
#      next tick — delivering its lore once, paying its tiny reward once.
#
# The forward-only ec.bq_quest cursor (one advance per satisfied beat, inside
# advance) plus the place-cursor make this no-double-credit and no-penalty.

# === RUN THE CHECK FOR EVERY ACTIVE, NON-COMPLETE PLAYER ===
# (check() is itself existence-gated + idempotent; the outer selector keeps the
#  per-tick cost zero when nobody is on the line.)
execute as @a[scores={ec.bq_active=1,ec.bq_complete=0}] run function evercraft:build_quests/check

# === NO PLACE-CURSOR RE-SYNC HERE (WA63-COMMENT-DRIFT (e)) ===
# Unlike the questline/kingdom sibling loops (which re-sync their conquest/board
# progress bar), this engine does NOT re-sync ec.bq_place_seen each tick — and
# correctly so. Incremental beats (place_any/place_palette/variety) count via
# ec.bq_prog, which advance.mcfunction RESETS to 0 at each beat activation, so a
# beat that becomes active mid-game already starts from 0 placements (forward-only)
# with no cursor re-base needed. ec.bq_place_seen is a START-ONLY snapshot of
# ach.blocks_placed used by the LIFETIME-type catch-up reads (see declare_objectives),
# not by on_place_tally — which does NOT read a delta off it. (A prior version of this
# header described a per-tick re-sync that was never implemented; removed.)

# Re-schedule self.
schedule function evercraft:build_quests/check_progress 20t replace
