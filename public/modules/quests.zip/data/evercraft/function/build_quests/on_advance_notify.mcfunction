# ============================================================
# The Build Quests Engine — New-objective notification (after advance)
# ============================================================
# Run as @s = the player. Called once from build_quests/advance after the pointer
# moves to a new (non-final) quest. bq_cur already holds the new quest.
#
# C0 PACING PROOF-POINT (this wave is the first adopter of the C0 spec): the
# advance nudge routes through TWO shared layers, exactly as every later line will:
#   1. util/notify/dispatch (key "bq_advance") — the mutable-notification layer, so
#      the "New objective" chime/title respects the player's global ec.notify
#      filter + a per-key [Mute] after a threshold (no /trigger names surfaced; the
#      [Mute] button is the same interaction-driven affordance pattern, R3).
#   2. quest_pacing/render_lore — the C0 lore line (gray-italic Seven-voice, muted
#      by ec.qln_mute in Quick Mode) + the law-compliant [Skip ▸] chat button
#      (gated on the beat's `skippable` field). SCHEMA_DELTA §2.

# === 1) MUTABLE "new objective" NUDGE (chatter class) ===
function evercraft:util/notify/dispatch {key:"bq_advance",class:"chatter",mute_at:8}
# Only fire the flash/chime + objective when the dispatcher approved it.
execute if score #notif_show_bq_advance ec.temp matches 1 run title @s times 5 40 10
execute if score #notif_show_bq_advance ec.temp matches 1 run title @s subtitle {text:"New objective available",color:"gray",italic:true}
execute if score #notif_show_bq_advance ec.temp matches 1 if score @s ec.fx_snd matches 1.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.6 1.2
execute if score #notif_show_bq_advance ec.temp matches 1 run function evercraft:build_quests/show_objective
# Offer the [Mute] button once the per-key threshold is reached.
execute if score #notif_show_mute_bq_advance ec.temp matches 1 run tellraw @s [{text:"  ",color:"dark_gray"},{text:"[Mute]",color:"dark_gray",hover_event:{action:"show_text",value:{text:"Stop showing new-objective nudges for the Build line.",color:"gray"}},click_event:{action:"run_command",command:"/trigger ec.nm_bq_adv set 1"}}]

# === 2) C0 LORE LINE + [Skip ▸] BUTTON (always — independent of the chatter mute) ===
# The lore/skip layer has its OWN mute (ec.qln_mute, Quick Mode) handled inside
# render_lore; it is NOT gated by the chatter dispatch above, so a player who muted
# new-objective chimes still sees the story beat + can still skip.
data modify storage evercraft:qp_cur o set from storage evercraft:bq_cur quest
function evercraft:quest_pacing/render_lore
