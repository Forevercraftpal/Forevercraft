# ============================================================
# The Build Quests Engine — Reward (pay out the completed quest)
# ============================================================
# Run as @s = the player. Reads the just-completed quest's reward fields from
# bq_cur.quest and dispatches on reward type. bq_cur still holds the OLD (just-
# completed) quest at this point (reward runs BEFORE advance bumps the pointer).
# (Structural clone of fishing/questline/reward.)
#
# Reward fields: reward (xp|coins|crate|gear — NO title per R2), reward_amt (int),
#                target (used as the crate tier name / gear item id).
# Dispatch -> reward_type/<reward> macro helper.

# Flatten the quest fields for the reward macro.
data modify storage evercraft:bq_cur o set from storage evercraft:bq_cur quest
function evercraft:build_quests/reward_macro with storage evercraft:bq_cur o

# === ADDITIVE: D-Q10-REWARD artifact (Artifact-Fusion w1) ===
# On TOP of the q10 xp reward above ("The Ancient Network"). Fires only when the
# just-completed quest is #10 (ec.bq_quest still holds 10 here — advance bumps the
# pointer AFTER reward). Build q10 -> Mason's Long-Arm Band (C39, Family C builder-
# adjacent leaf). One-shot per the pointer-equals-10 gate. Inv-full aware via the
# shared helper.
execute if score @s ec.bq_quest matches 10 run data modify storage evercraft:q10r args set value {lt:"artifacts/uncommon/masons_long_arm_band",name:"Mason's Long-Arm Band",color:"yellow"}
execute if score @s ec.bq_quest matches 10 run function evercraft:artifacts/give/q10_reward with storage evercraft:q10r args

# === ADDITIVE: D-HANDPARTS — Hand-of-Creation builder parts (Artifact-Fusion w2) ===
# Wires a REAL obtainment for the 6 Hand-of-Creation parts (admin-only before w2 —
# the Hand was unachievable). You EARN the Hand by BUILDING: one part is granted
# ADDITIVELY at six Build-questline milestones, on TOP of that quest's own reward
# (never replacing it). Fuse all six at the Tinkerer's Plinth into one Hand of
# Creation. Each gate is one-shot (ec.bq_quest equals the milestone id on exactly
# one advance; reward runs in advance step 2 BEFORE the pointer bump in step 3 —
# the same one-shot guarantee the w1 q10 block above relies on). Milestones span
# the line: q5 (end of the starter on-ramp) -> q8 (big-haul) -> q11 (colour theory)
# -> q14 (House Key) -> q16 (first artifact) -> q20 (the sixth/last Hand part, Master
# of the Craft). NOTE: q21 "The Keystone" (batch_g) is the actual LINE-ENDER that fires
# finish; q20 is a normal beat (it just happens to carry the final Hand part).
# Inv-full aware via the shared hand_part helper.
execute if score @s ec.bq_quest matches 5 run data modify storage evercraft:hpart args set value {lt:"hand_of_creation/parts/reach",name:"Part of Reach"}
execute if score @s ec.bq_quest matches 5 run function evercraft:artifacts/give/hand_part with storage evercraft:hpart args
execute if score @s ec.bq_quest matches 8 run data modify storage evercraft:hpart args set value {lt:"hand_of_creation/parts/steady",name:"Part of Steady"}
execute if score @s ec.bq_quest matches 8 run function evercraft:artifacts/give/hand_part with storage evercraft:hpart args
execute if score @s ec.bq_quest matches 11 run data modify storage evercraft:hpart args set value {lt:"hand_of_creation/parts/palette",name:"Part of Palette"}
execute if score @s ec.bq_quest matches 11 run function evercraft:artifacts/give/hand_part with storage evercraft:hpart args
execute if score @s ec.bq_quest matches 14 run data modify storage evercraft:hpart args set value {lt:"hand_of_creation/parts/scaffold",name:"Part of Scaffold"}
execute if score @s ec.bq_quest matches 14 run function evercraft:artifacts/give/hand_part with storage evercraft:hpart args
execute if score @s ec.bq_quest matches 16 run data modify storage evercraft:hpart args set value {lt:"hand_of_creation/parts/refund",name:"Part of Refund"}
execute if score @s ec.bq_quest matches 16 run function evercraft:artifacts/give/hand_part with storage evercraft:hpart args
execute if score @s ec.bq_quest matches 20 run data modify storage evercraft:hpart args set value {lt:"hand_of_creation/parts/level",name:"Part of Level"}
execute if score @s ec.bq_quest matches 20 run function evercraft:artifacts/give/hand_part with storage evercraft:hpart args
