# ============================================================
# The Build Quests Engine — Check (is the current quest satisfied?)
# ============================================================
# Reads the current quest's type/target/count/beat and decides whether the active
# quest is complete; if so, calls build_quests/advance. Idempotency-guarded like
# the Fisher's check (refuses to act when the line is already complete).
# Run as @s = the player. Cheap; called from on_place_tally + check_progress.
#
# C0 PACING (SCHEMA_DELTA §3): an `interlude` beat (beat:"interlude", count:0) is
# a pure-lore breather that auto-passes. We satisfy it BEFORE the per-type dispatch
# so the macro never has to route a "$(type)" of interlude (no check_type/interlude
# file needed). A defensive count:0 path also covers a mis-authored interlude.

# --- Existence gate: do nothing unless this player is on the Build line. ---
execute unless score @s ec.bq_active matches 1 run return 0
# --- Already finished the whole line? Nothing left to check. ---
execute if score @s ec.bq_complete matches 1 run return 0

# Make sure bq_cur holds THIS quest (callers may have run get_quest already, but
# re-loading is cheap and keeps check self-contained / caller-order-proof).
function evercraft:build_quests/get_quest

# Flatten the quest fields the macro compares against.
data modify storage evercraft:bq_cur o set from storage evercraft:bq_cur quest

# Snapshot the linear pointer BEFORE dispatch, so advance can detect a re-entrant
# same-tick double-call (idempotency guard, mirrors the Fisher upper-bound guard).
execute store result score #bq_q_before ec.temp run scoreboard players get @s ec.bq_quest

# Default unsatisfied.
scoreboard players set #bq_satisfied ec.temp 0

# === C0 INTERLUDE GUARD (BEFORE the per-type dispatch) ===
# A pure-lore beat is instantly satisfied: deliver its lore on advance, pay its
# tiny reward once, step the cursor forward. SCHEMA_DELTA §3.
execute if data storage evercraft:bq_cur o{beat:"interlude"} run scoreboard players set #bq_satisfied ec.temp 1
# Defensive: any beat with count:0 is also satisfied (0 >= 0) — covers a non-zero
# author slip where beat was mislabeled but count is 0.
execute if data storage evercraft:bq_cur o{count:0} run scoreboard players set #bq_satisfied ec.temp 1

# === PER-TYPE DISPATCH (skipped if the interlude/count:0 guard already fired) ===
execute if score #bq_satisfied ec.temp matches 0 run function evercraft:build_quests/check_macro with storage evercraft:bq_cur o

# If satisfied, advance — but only if the pointer hasn't already moved this tick.
execute if score #bq_satisfied ec.temp matches 1 if score @s ec.bq_quest = #bq_q_before ec.temp run function evercraft:build_quests/advance
