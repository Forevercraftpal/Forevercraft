# ============================================================
# The Build Quests Engine — Load the current quest object into bq_cur
# ============================================================
# Reads the current quest (by linear pointer ec.bq_quest) out of the registry
# list and writes it to storage evercraft:bq_cur quest, so check/advance/reward
# can read quest.type/target/count/reward/reward_amt/beat/lore without per-quest
# files. (Structural clone of fishing/questline/get_quest.)
#
# The registry list is 0-indexed; ec.bq_quest is 1-based. This wrapper computes
# idx = ec.bq_quest - 1, stuffs it into storage, and calls the macro.
# Run as @s = the player.

# Compute 0-based list index from the 1-based linear pointer.
execute store result score #bq_idx ec.temp run scoreboard players get @s ec.bq_quest
scoreboard players remove #bq_idx ec.temp 1
execute store result storage evercraft:bq_cur idx int 1 run scoreboard players get #bq_idx ec.temp

# Macro-copy the quest object at that index into bq_cur.quest.
function evercraft:build_quests/get_quest_macro with storage evercraft:bq_cur
