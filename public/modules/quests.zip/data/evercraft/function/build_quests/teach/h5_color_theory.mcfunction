# ============================================================
# W6-housing teach beat H5 — Colour theory: build with one harmonious palette.
# Run as @s = the player. Called (idempotently) from check_type/place_palette while
# the H5 beat is active (it is a place_palette beat, target:"nature" — the NEW nature
# family this wave added to #evercraft:bq_palette). POINTER teach: a one-line nudge on
# building with a coherent colour family (the nature greens + woods). No item handed
# out — the lesson is in the placing. Shown once per beat-activation via ec.bq_prog…
# BUT NOTE: place_palette beats USE ec.bq_prog as the live placement counter, so this
# teach must NOT clobber it. We instead gate the one-time pointer on ec.bq_prog matches
# 0 (the count is 0 only at the very start of the beat, before the first matching
# placement) and we do NOT write ec.bq_prog (the placement tally owns it). The pointer
# therefore shows once at beat start and then the placement count takes over naturally.
# ============================================================
execute if score @s ec.bq_prog matches 0 run tellraw @s [{text:"  ⚑ ",color:"gold"},{text:"Speak one hue at a time.",color:"white"},{text:" Build this stretch from the nature palette — greens, woods, mossy stone — and watch how a single colour family makes a wall read as one calm, deliberate work.",color:"gray"}]
