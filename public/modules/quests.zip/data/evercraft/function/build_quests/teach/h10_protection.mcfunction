# ============================================================
# W6-housing teach beat H10 — Guard your home (protection).
# Run as @s = the player. Called (idempotently) from check_type/protection while the
# H10 beat is active. POINTER teach with HONEST copy (R11): toggling home protection at
# your Hearthstone DETERS mining-griefers in your zone — it does NOT make the home
# untouchable. The copy is deliberately honest about what protection does and does not
# do (housing/zone/toggle_protection writes hs.protect). No item granted. Shown once per
# beat-activation via the ec.bq_prog latch; suppressed for a veteran already guarding.
# ============================================================
execute unless score @s hs.protect matches 1.. if score @s ec.bq_prog matches 0 run tellraw @s [{text:"  ⚑ ",color:"gold"},{text:"Set a ward on your home.",color:"white"},{text:" Toggle protection at your Hearthstone — it deters mining-griefers in your zone. A deterrent, not a wall: it discourages, it does not make the home untouchable.",color:"gray"}]
execute unless score @s hs.protect matches 1.. if score @s ec.bq_prog matches 0 run scoreboard players set @s ec.bq_prog 1
