# ============================================================
# W6-housing teach beat H6 — The Garden Plot (Tier-3 Estate home).
# Run as @s = the player. Called (idempotently) from check_type/home_tier (count:3)
# while the H6 beat is active. POINTER teach: at Tier 3 (Estate) a home auto-grants a
# Garden Plot — crops within 64 blocks of the Hearthstone grow faster (housing/garden,
# unlocked by housing/gui/do_upgrade at hs.tier 3). No item handed out; the upgrade IS
# the unlock. Shown once per beat-activation via the ec.bq_prog latch; suppressed for a
# veteran already at Tier 3+ (auto-passes first).
# ============================================================
execute unless score @s hs.tier matches 3.. if score @s ec.bq_prog matches 0 run tellraw @s [{text:"  ⚑ ",color:"gold"},{text:"Grow your home to an Estate.",color:"white"},{text:" Upgrade your Hearthstone to Tier 3 — it unlocks a Garden Plot, so crops near your home ripen on their own.",color:"gray"}]
execute unless score @s hs.tier matches 3.. if score @s ec.bq_prog matches 0 run scoreboard players set @s ec.bq_prog 1
