# ============================================================
# W6-housing teach beat H9 — Discover an Artifact.
# Run as @s = the player. Called (idempotently) from check_type/artifact while the H9
# beat is active. POINTER teach: artifacts are discovered/forged out in the world and
# at the forge (achievements writes ec.artifacts_ever); they are not handed out by this
# beat. No item granted — the beat points the player at the artifact path + its codex.
# Shown once per beat-activation via the ec.bq_prog latch; suppressed for a veteran who
# has ever found an artifact (auto-passes via the lifetime ec.artifacts_ever read).
# ============================================================
execute unless score @s ec.artifacts_ever matches 1.. if score @s ec.bq_prog matches 0 run tellraw @s [{text:"  ⚑ ",color:"gold"},{text:"Seek your first Artifact.",color:"white"},{text:" Forge one at the anvil or unearth it in the deep — artifacts are the heirlooms a great home is built to hold.",color:"gray"}]
execute unless score @s ec.artifacts_ever matches 1.. if score @s ec.bq_prog matches 0 run scoreboard players set @s ec.bq_prog 1
