# ============================================================
# W6-housing teach beat H3 — The Baúl big-haul funnel (DECISIONS D2).
# Run as @s = the player. Called (idempotently) from check_type/bb_haul while the H3
# beat is active. POINTER teach with HONEST copy: a large single-item haul (>256 = >4
# stacks) Quick-Stashed with an EMPTY unlocked Baúl block within 32 blocks funnels the
# whole pile into that Baúl's 9,999 count, locking the Baúl to that item — no Stash
# Label needed (housing/stash/claim_empty_baul, reached via route_slot -> find_barrel:
# 28). The copy names BOTH preconditions (>256 of one item AND a nearby empty Baúl) so
# H3 never promises behaviour that does not fire. (D2: ships now, untested in-game; the
# funnel is statically traced sound — see W6 teammate note. Live confirmation is a
# Joseph followup, NOT faked here.) Shown once per beat-activation via the ec.bq_prog
# latch. There is no item to hand out — a Baúl is a placed block the player crafts.
# ============================================================
execute if score @s ec.bq_prog matches 0 run tellraw @s [{text:"  ⚑ ",color:"gold"},{text:"Big single-item hauls have a home.",color:"white"},{text:" Carry 256+ of one item, keep an empty Baúl within 32 blocks of your stash, then Quick-Stash — the whole pile pours into that Baúl and locks it to the item. No label needed.",color:"gray"}]
execute if score @s ec.bq_prog matches 0 run scoreboard players set @s ec.bq_prog 1
