# ============================================================
# W6-housing teach beat H8 — Hire a Laborer (run a little estate).
# Run as @s = the player. Called (idempotently) from check_type/laborer while the H8
# beat is active. POINTER teach: laborers are hired at the laborer station and sent on
# expeditions; they are not handed out as items (laborer/hire/*). No item granted —
# the beat points the player at the hire flow. Shown once per beat-activation via the
# ec.bq_prog latch; suppressed for a veteran who already employs laborers (auto-passes).
# ============================================================
execute unless score @s ec.lb_count matches 1.. if score @s ec.bq_prog matches 0 run tellraw @s [{text:"  ⚑ ",color:"gold"},{text:"Take on a Laborer.",color:"white"},{text:" Hire one at your estate and send them on expeditions — a home that works for you is a home that grows.",color:"gray"}]
execute unless score @s ec.lb_count matches 1.. if score @s ec.bq_prog matches 0 run scoreboard players set @s ec.bq_prog 1
