# ============================================================
# W6-housing teach beat H7 — The House Key (remote stashing).
# Run as @s = the player. Called (idempotently) from check_type/has_house_key while
# the H7 beat is active. GATED GRANT teach: the House Key is EARNED at Tier-3 home +
# Architect comfort (hs.decor 2500+) — the same gate housing/gui/do_upgrade:52 uses to
# call housing/satchel/award. We REPLICATE that exact earning gate here so the teach
# only awards a key to a player who already qualifies but somehow missed it (an edge
# case), via the existing housing/satchel/award (itself dup-guarded by the
# hs.has_satchel tag). A player who has NOT earned it is POINTED at the requirement —
# never handed a key they did not earn (balance-safe). Shown once per beat-activation
# via the ec.bq_prog latch.
# ============================================================
# Edge-case award: qualifies (Tier 3+ AND Architect comfort) but lacks the key.
execute if score @s hs.tier matches 3.. if score @s hs.decor matches 2500.. unless entity @s[tag=hs.has_satchel] run function evercraft:housing/satchel/award
# Pointer for a player who has not yet met the earning gate (shown once).
execute unless entity @s[tag=hs.has_satchel] if score @s ec.bq_prog matches 0 run tellraw @s [{text:"  ⚑ ",color:"gold"},{text:"Earn a House Key.",color:"white"},{text:" Raise your home to a Tier-3 Estate and decorate it to Architect comfort — the Key lets you Quick-Stash to your labelled containers from anywhere.",color:"gray"}]
execute unless entity @s[tag=hs.has_satchel] if score @s ec.bq_prog matches 0 run scoreboard players set @s ec.bq_prog 1
