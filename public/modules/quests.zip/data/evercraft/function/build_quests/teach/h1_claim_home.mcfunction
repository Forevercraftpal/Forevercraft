# ============================================================
# W6-housing teach beat H1 — Claim a Hearthstone (your first home).
# Run as @s = the player. Called (idempotently) from check_type/home_tier while the
# H1 beat is active. POINTER teach: a Hearthstone is placed in the world (an item the
# player crafts/earns), so there is no item to hand out here — the beat teaches WHERE
# to begin. The honest one-line pointer shows ONCE per beat-activation, gated on
# ec.bq_prog (reset to 0 by advance/start; nothing else writes it for a housing beat,
# so it doubles as a spam-free "pointer shown" latch — ZERO new objectives, W6 law).
# ============================================================
execute unless score @s hs.tier matches 1.. if score @s ec.bq_prog matches 0 run tellraw @s [{text:"  ⚑ ",color:"gold"},{text:"Place a Hearthstone to claim a home.",color:"white"},{text:" Craft one and set it where you'll live — it anchors your zone, stash, and every comfort to come.",color:"gray"}]
execute unless score @s hs.tier matches 1.. if score @s ec.bq_prog matches 0 run scoreboard players set @s ec.bq_prog 1
