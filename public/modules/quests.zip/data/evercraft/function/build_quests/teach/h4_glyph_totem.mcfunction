# ============================================================
# W6-housing teach beat H4 — Forge a glyph totem in your home zone.
# Run as @s = the player. Called (idempotently) from check_type/totem_at_home while
# the H4 beat is active. POINTER teach: a glyph totem is forged at a Glyph Forge and
# placed in your home zone (it powers the home inscription network — +totem slots,
# +radius at milestones). No item handed out (the totem is built/inscribed). Shown
# once per beat-activation via the ec.bq_prog latch; suppressed for a veteran who has
# already set totems and is home (auto-passes first). The beat itself only satisfies
# inside the home zone (hs.in_zone) — the wave's explicit H4 constraint.
# ============================================================
execute unless score @s hs.totems matches 1.. if score @s ec.bq_prog matches 0 run tellraw @s [{text:"  ⚑ ",color:"gold"},{text:"Inscribe a glyph totem at home.",color:"white"},{text:" Forge one at a Glyph Forge and set it inside your zone — totems weave the ancient network that strengthens your whole estate.",color:"gray"}]
execute unless score @s hs.totems matches 1.. if score @s ec.bq_prog matches 0 run scoreboard players set @s ec.bq_prog 1
