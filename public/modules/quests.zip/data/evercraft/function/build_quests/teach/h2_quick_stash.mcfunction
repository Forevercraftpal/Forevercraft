# ============================================================
# W6-housing teach beat H2 — Quick-Stash with a Stash Label.
# Run as @s = the player. Called (idempotently) from check_type/stash_used while the
# H2 beat is active. GRANT teach: hands the player a Stash Label (the affordance that
# drives the whole Quick-Stash system) via the EXISTING give-fn housing/stash/label/
# give — ONCE per beat-activation, gated on ec.bq_prog (reset by advance; nothing else
# writes it for a housing beat). A Stash Label is a cheap consumable paper item, so a
# single extra one is harmless; the gate just keeps the chat pointer + give from
# repeating every 20t check. Skipped for a player who has already stashed (veterans
# auto-pass before the teach fires).
# ============================================================
execute unless score @s hs.stashed matches 1.. if score @s ec.bq_prog matches 0 run function evercraft:housing/stash/label/give
execute unless score @s hs.stashed matches 1.. if score @s ec.bq_prog matches 0 run tellraw @s [{text:"  ⚑ ",color:"gold"},{text:"Take this Stash Label.",color:"white"},{text:" Sneak + use it on a barrel in your home zone to name a category, then Quick-Stash to file your pack in one motion.",color:"gray"}]
execute unless score @s hs.stashed matches 1.. if score @s ec.bq_prog matches 0 run scoreboard players set @s ec.bq_prog 1
