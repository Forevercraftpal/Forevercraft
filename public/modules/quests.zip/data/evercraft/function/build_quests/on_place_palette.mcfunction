# ============================================================
# The Build Quests Engine — Palette placement tally (macro body)
# ============================================================
# Run as @s = the player. Called by the tag-filtered palette advancements:
#   function evercraft:build_quests/on_place_palette {palette:"<fam>"}
# where <fam> is warm | cool | stone_family — the advancement ALREADY guaranteed
# the placed block is in #evercraft:bq_palette/<fam> (block:{blocks:...} filter),
# so this only has to confirm the player's ACTIVE place_palette quest is asking
# for THIS family, then +1 ec.bq_prog and re-check.
#
# WHY a separate detector (and not the hot-path on_place_tally): the generic
# track_place advancement carries no block type, so the palette family can only be
# read from a tag-filtered advancement (canonical pack pattern, see
# housing/place_decoration). This keeps the R7 hot-path edit ONE cheap line for the
# untyped types and pushes the family scoping to a per-family advancement that
# fires only on a matching block — no extra cost on non-palette placements.
#
# WRITER of ec.bq_prog (increment) — the place_palette path. One-writer law: this
# is gated to type:"place_palette" + matching target, disjoint from on_place_tally
# (place_any/variety), so a single placement is counted by at most one path.

# --- Existence gates. ---
execute unless score @s ec.bq_active matches 1 run return 0
execute if score @s ec.bq_complete matches 1 run return 0

# Load the current quest so we can read its type/target.
function evercraft:build_quests/get_quest

# +1 ONLY when the active quest is a place_palette asking for THIS family.
$execute if data storage evercraft:bq_cur {quest:{type:"place_palette",target:"$(palette)"}} run scoreboard players add @s ec.bq_prog 1

# Re-evaluate the active quest (check is existence-gated + idempotent).
function evercraft:build_quests/check
