# BQ palette detector — WARM family placement. @s = player (advancement reward).
# Fired by advancement evercraft:build_quests/place_palette/warm, which is a
# tag-filtered placed_block trigger (block:{blocks:"#evercraft:bq_palette/warm"}),
# so this only runs when a WARM-family block was placed. Revokes to re-arm (cheap,
# mirrors housing/decoration/on_place), early-exits for non-Build players, then
# routes to the shared on_place_palette tally with the literal family.
advancement revoke @s only evercraft:build_quests/place_palette/warm
execute unless score @s ec.bq_active matches 1 run return 0
function evercraft:build_quests/on_place_palette {palette:"warm"}
