# BQ palette detector — STONE family placement. @s = player (advancement reward).
# Fired by advancement evercraft:build_quests/place_palette/stone_family
# (tag-filtered placed_block on #evercraft:bq_palette/stone_family). Revoke to
# re-arm, early-exit for non-Build players, route to on_place_palette with family.
advancement revoke @s only evercraft:build_quests/place_palette/stone_family
execute unless score @s ec.bq_active matches 1 run return 0
function evercraft:build_quests/on_place_palette {palette:"stone_family"}
