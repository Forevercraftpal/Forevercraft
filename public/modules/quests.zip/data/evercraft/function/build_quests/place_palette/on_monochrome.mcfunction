# BQ palette detector — MONOCHROME family placement. @s = player (advancement reward).
# Fired by advancement evercraft:build_quests/place_palette/monochrome (tag-filtered
# placed_block on #evercraft:bq_palette/monochrome). Revoke to re-arm, early-exit for
# non-Build players, route to the shared on_place_palette tally with the family.
# (Added by W6-housing for the colour-theory chapter — clone of on_warm.)
advancement revoke @s only evercraft:build_quests/place_palette/monochrome
execute unless score @s ec.bq_active matches 1 run return 0
function evercraft:build_quests/on_place_palette {palette:"monochrome"}
