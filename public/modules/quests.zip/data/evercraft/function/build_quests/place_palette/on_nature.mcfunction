# BQ palette detector — NATURE family placement. @s = player (advancement reward).
# Fired by advancement evercraft:build_quests/place_palette/nature (tag-filtered
# placed_block on #evercraft:bq_palette/nature). Revoke to re-arm, early-exit for
# non-Build players, route to the shared on_place_palette tally with the family.
# (Added by W6-housing for the H5 colour-theory chapter — clone of on_warm.)
advancement revoke @s only evercraft:build_quests/place_palette/nature
execute unless score @s ec.bq_active matches 1 run return 0
function evercraft:build_quests/on_place_palette {palette:"nature"}
