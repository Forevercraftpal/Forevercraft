# BQ reward — xp (category-3 Artisan BUILDING XP). @s = player.
# Amount in #bq_reward_amt ec.temp. Paid through the FROZEN add_xp contract
# (R9): set #cf_xp_amount + #cf_xp_cat=3 on ec.cf_temp, run as @s, call add_xp.
# NOTHING here writes ec.cf_xp / ec.cf_axp_build directly; Build XP NEVER routes
# through craft_affinity/internal_grant (that would re-arm the class faucet loop).
# (No macro args needed; invoked `with storage ... o` but only reads the temp.)
scoreboard players operation #cf_xp_amount ec.cf_temp = #bq_reward_amt ec.temp
scoreboard players set #cf_xp_cat ec.cf_temp 3
function evercraft:craftforever/artisan/add_xp
# BAKE the amount literal $(reward_amt) — NOT a live {score:#bq_reward_amt} ref, which the queued
# notify renders at DISPLAY time (after a multi-quest cascade overwrote it). See reward_type/coins.
$data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"#7FFF7F"},{text:"Reward: ",color:"yellow"},{text:"$(reward_amt)",color:"#7FFF7F"},{text:" Building XP",color:"#7FFF7F"},{text:" ✦",color:"#7FFF7F"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.experience_orb.pickup master @s ~ ~ ~ 0.6 1.0
