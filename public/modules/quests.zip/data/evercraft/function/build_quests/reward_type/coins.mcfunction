# BQ reward — coins. @s = player. Amount in #bq_reward_amt ec.temp.
# Adds Forever Coins (ec.coins) and tells the player. (No macro args needed;
# invoked `with storage ... o` but only reads the temp.)
scoreboard players operation @s ec.coins += #bq_reward_amt ec.temp
# BAKE the amount as a literal $(reward_amt) — NOT a live {score:#bq_reward_amt} ref. util/notify/emit
# QUEUES the frame and renders it later, resolving any score component at DISPLAY time; when several
# quests complete in a row #bq_reward_amt is already overwritten to the LAST quest's amount, so every
# queued frame showed e.g. "90 Forever Coins" (Joseph 2026-06-05 — got 1 coin, message said 90).
$data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"Reward: ",color:"yellow"},{text:"$(reward_amt)",color:"gold"},{text:" Forever Coins",color:"gold"},{text:" ✦",color:"gold"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.experience_orb.pickup master @s ~ ~ ~ 0.6 1.0
