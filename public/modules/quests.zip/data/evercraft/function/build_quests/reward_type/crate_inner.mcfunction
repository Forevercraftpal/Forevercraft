# BQ crate grant — inner macro; $(crate) = tier resolved by reward_type/crate. @s = player.
# Table = EXISTING shared crate table at evercraft:fishing/gameplay/fishing/crates/<tier>/1
# (reused so the Build line ships without authoring a parallel crate-table tree; a
# Build-themed table can swap in later with zero engine change). Inv-full aware
# (prospect/complete_mine pattern).
execute store result score #bq_inv_full ec.var run function evercraft:util/check_inv_full
$execute if score #bq_inv_full ec.var matches 0 run loot give @s loot evercraft:fishing/gameplay/fishing/crates/$(crate)/1
$execute if score #bq_inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:fishing/gameplay/fishing/crates/$(crate)/1
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"yellow"},{text:"Reward: a reward crate!",color:"yellow"},{text:" ✦",color:"yellow"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Inventory full! Your crate was dropped at your feet.",color:"yellow"}]
scoreboard players set #ndur ec.temp 45
execute if score #bq_inv_full ec.var matches 1 run function evercraft:util/notify/emit
execute if score #bq_inv_full ec.var matches 1 if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bass player @s ~ ~ ~ 1 0.5
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.experience_orb.pickup master @s ~ ~ ~ 0.6 1.0
