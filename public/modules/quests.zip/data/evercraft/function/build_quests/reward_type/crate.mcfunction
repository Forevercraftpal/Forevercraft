# BQ reward — crate (a reward crate of a given tier). @s = player.
# quest.target NORMALLY names the tier (common|uncommon|rare|ornate|exquisite|mythical),
# but q2's target is the palette family ("warm" — type:place_palette reads it), so non-tier
# values are resolved HERE: warm -> common (chapter-1 crate). q7/q12 carry real tiers in the
# registry since the 2026-06-10 re-pacing fix — their targets were "" and the macro built a
# nonexistent table path, so the advertised crate silently vanished (RE-9 smoke).
# Grant body lives in crate_inner (the resolved tier must pass through a second macro expansion).
$data modify storage evercraft:bq_cur crate set value "$(target)"
execute if data storage evercraft:bq_cur {crate:"warm"} run data modify storage evercraft:bq_cur crate set value "common"
function evercraft:build_quests/reward_type/crate_inner with storage evercraft:bq_cur
