# BQ reward — gear (a Build-line gear/part item). @s = player.
# quest.target is the gear id; the loot table is owned by the REWARD AGENT at
# evercraft:build_quests/rewards/gear/<id> (NOT shipped in F1 — the starter
# batch_0 rewards only xp/coins/crate, so this path is never invoked yet). When a
# later wave awards a builder PART item (the Hand-of-Creation parts, R13) it ships
# the matching loot table under build_quests/rewards/gear/ and adds a `gear` quest.
# Inv-full aware (prospect/complete_mine pattern). Macro body — reads $(target).
#
# SAFE-NO-OP IN F1: loot-table refs are resolved at CALL time (not load time), and
# no batch_0 quest uses reward:"gear", so the absent table is never touched. This
# dispatcher exists for engine-completeness / clone-parity (every later line clones
# this file) — do NOT add a gear quest to batch_0 until the table is authored.
execute store result score #bq_inv_full ec.var run function evercraft:util/check_inv_full
$execute if score #bq_inv_full ec.var matches 0 run loot give @s loot evercraft:build_quests/rewards/gear/$(target)
$execute if score #bq_inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:build_quests/rewards/gear/$(target)
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"aqua"},{text:"Reward: new builder's gear!",color:"aqua"},{text:" ✦",color:"aqua"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Inventory full! Your gear was dropped at your feet.",color:"yellow"}]
scoreboard players set #ndur ec.temp 45
execute if score #bq_inv_full ec.var matches 1 run function evercraft:util/notify/emit
execute if score #bq_inv_full ec.var matches 1 if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bass player @s ~ ~ ~ 1 0.5
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.experience_orb.pickup master @s ~ ~ ~ 0.6 1.0
