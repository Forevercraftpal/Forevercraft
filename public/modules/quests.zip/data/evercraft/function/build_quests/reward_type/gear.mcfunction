# BQ reward — gear (a Build-line gear/part item). @s = player.
# quest.target is the gear id; the loot table is owned by the REWARD AGENT at
# evercraft:build_quests/rewards/gear/<id>. LIVE: batch_g q21 "The Keystone" uses
# reward:"gear",target:"keystone_helm", and the matching loot table
# (build_quests/rewards/gear/keystone_helm) is shipped — so this path IS invoked at
# the line capstone. (The earlier Hand-of-Creation PART grants are additive, done
# directly in reward.mcfunction, not via this dispatcher.)
# Inv-full aware (prospect/complete_mine pattern). Macro body — reads $(target).
#
# CONTRACT: loot-table refs resolve at CALL time (not load time). Before adding ANY
# new gear quest, ship the matching loot table under build_quests/rewards/gear/<id>
# FIRST — calling this with an absent table is a silent no-op (RE-9 class).
execute store result score #bq_inv_full ec.var run function evercraft:util/check_inv_full
$execute if score #bq_inv_full ec.var matches 0 run loot give @s loot evercraft:build_quests/rewards/gear/$(target)
$execute if score #bq_inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:build_quests/rewards/gear/$(target)
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"aqua"},{text:"Reward: new builder's gear!",color:"aqua"},{text:" ✦",color:"aqua"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Inventory full! Your gear was dropped at your feet.",color:"yellow"}]
scoreboard players set #ndur ec.temp 45
execute if score #bq_inv_full ec.var matches 1 run function evercraft:util/notify/emit
execute if score #bq_inv_full ec.var matches 1 if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bass player @s ~ ~ ~ 1 0.5
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.experience_orb.pickup master @s ~ ~ ~ 0.6 1.0
