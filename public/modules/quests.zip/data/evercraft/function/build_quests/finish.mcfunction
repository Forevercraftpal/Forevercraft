# ============================================================
# The Build Quests Engine — Finish (one-shot completion fanfare)
# ============================================================
# Run as @s = the player who just completed the final quest. Sets the
# ec.bq_complete sentinel so this fires exactly once, then prints the
# "line complete!" celebration. WRITER of ec.bq_complete (with advance).
# (Structural clone of fishing/questline/finish — but NO title: building-mastery
#  titles come from the Builder CARD, not the Build line. R2.)

# Guard: only ever fire once.
execute if score @s ec.bq_complete matches 1 run return 0
scoreboard players set @s ec.bq_complete 1

# Auto-track repoint (Wiring #52): if the [Skip ▸] tracker was pointed at THIS line
# (Build = slot 8), clear it now that the line is done — a completed line must never
# accept a skip. The player can re-pin another active line from the Grand Quests hub,
# or the next line they start auto-re-tracks. (One-writer: finish + start, gated.)
execute if score @s ec.gq_track matches 8 run scoreboard players set @s ec.gq_track 0

data modify storage evercraft:notify stage.c set value [{text:"★ ",color:"gold"},{text:"The Builder's Quests — Complete!",color:"gold",bold:true},{text:" ★",color:"gold"}]
scoreboard players set #ndur ec.temp 50
function evercraft:util/notify/emit_keep
data modify storage evercraft:notify stage.c set value [{text:"Stone upon honest stone, you have raised your craft to its height. The made world is yours to shape.",color:"yellow",italic:true}]
scoreboard players set #ndur ec.temp 70
function evercraft:util/notify/emit

title @s times 10 60 20
title @s title {text:"Master of the Craft",color:"gold"}
title @s subtitle {text:"The Builder's Quests are complete",color:"yellow"}

execute if score @s ec.fx_snd matches 1.. run playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 1.0 1.0
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.player.levelup master @s ~ ~ ~ 0.6 1.2

# === ADDITIVE: difficulty-scaled DEXTERITY prestige capstone (XP-REWARD-ECONOMY.md). ===
# On TOP of the celebration above. Runs once (inside this ec.bq_complete one-shot guard).
# Drives advantage/prestige/do_prestige on the Dexterity tree, prestige count scaled:
# Newcomer = 2 / Adventurer = 1 / Pioneer or unset = 1 (Phase-3 re-gradient). See tree_capstone.
function evercraft:build_quests/tree_capstone

# === ADDITIVE: exit handoff (Questline Restructure W4, 2026-06-10) ===
# A finished Path never goes dark: name the repeatable continuation (Trade Trials),
# bridge with 1 Trial Pass, and nudge the Grand Chronicle if both branches qualify.
# Runs inside this finish's one-shot complete-sentinel guard.
function evercraft:grand_quests/exit_handoff_craft

# Clear a stale tracked-Path pin if THIS line was pinned (QR-P5, 2026-06-10).
function evercraft:grand_quests/untrack_on_finish {slot:8}
