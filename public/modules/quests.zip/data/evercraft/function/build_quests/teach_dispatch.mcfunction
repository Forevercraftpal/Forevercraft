# ============================================================
# The Build Quests Engine — Teach dispatch (W6-housing convergence)
# ============================================================
# Run as @s = the player. Called from each housing-detect check_type helper while
# a housing convergence beat (H1..H10) is the active quest. Routes to the beat's
# self-guarded teach-grant `build_quests/teach/<name>`, where <name> is the OPTIONAL
# `teach` field on the registry quest object (absent on engine/legacy beats).
#
# WHY a dispatch wrapper: the H-beats DETECT existing housing state (read-only) and
# need to GIVE the player the affordance they are being taught (a Stash Label, a
# House Key) or POINT them at it (claim a home, hire a laborer). The teach fns are
# unless-guarded — they only give/tellraw when the player still lacks the thing —
# so firing them every 20t check is idempotent and spam-free. No engine file edited:
# the check_type helpers call this; this calls the teach fn named by the registry.
#
# EXISTENCE-GATED: bq_cur o must carry a `teach` field, else this is a clean no-op
# (a macro can't expand a missing $(teach), so we guard on the field's presence and
# only then macro-route). bq_cur o = the current quest, already flattened by check.

# Only act if the active beat names a teach-grant (H-beats carry `teach`; engine
# beats q1..q5 do not). Existence-gate so the macro never expands a missing field.
execute if data storage evercraft:bq_cur o.teach run function evercraft:build_quests/teach_dispatch_macro with storage evercraft:bq_cur o
