# ============================================================
# The Build Quests Engine — Place tally (the ec.bq_prog incrementer)
# ============================================================
# Run as @s = the player who just placed a block. TWO callers:
#   A) THE HOT PATH (R7): advantage/track/on_place_block fires this on a placement,
#      behind TWO gate-first scores there (ec.bq_active=1 AND ec.bq_place_active=1 —
#      the WA63-PERF flag that is 1 ONLY while a placement beat place_any/variety/
#      place_palette is active). So a Build player on a NON-placement beat never even
#      reaches this file. This file owns the +1 for the two UNTYPED incremental beats
#      (place_any/variety). The generic placement advancement carries NO block
#      type/coords, so it CANNOT tell a palette family — palette placements are
#      handled by caller (B) instead.
#   B) THE PALETTE ADVANCEMENTS: build_quests/place_palette/{warm,cool,stone_family,
#      nature,monochrome} (5 families) are tag-filtered placed_block advancements (block:{blocks:"#evercraft:
#      bq_palette/<fam>"}). Each fires build_quests/on_place_palette {palette:"<fam>"}
#      ONLY for a matching block; that helper gates on quest.target==palette, then
#      +1 here-equivalent and calls check. (Canonical pack pattern, mirrors
#      housing/place_decoration.) See on_place_palette.mcfunction.
#
# WRITER of ec.bq_prog (increment): this file + on_place_palette (the two incremental
# entry points). start + advance own the reset-to-0. One-writer law: both increment
# paths live in this engine, gated to disjoint quest types (place_any/variety here;
# place_palette in on_place_palette), so they never double-count one placement.
#
# This file is reached ONLY when the hot-path gate already confirmed an UNTYPED
# incremental beat is active, so we just +1 and re-check. Re-load the quest to be
# caller-order-proof (check re-loads it anyway; cheap).

# --- Existence gate (defensive; the hot-path line already gated this). ---
execute unless score @s ec.bq_active matches 1 run return 0
execute if score @s ec.bq_complete matches 1 run return 0

# Load the current quest so the type guards below read the right beat.
function evercraft:build_quests/get_quest

# +1 for the two UNTYPED incremental beats this entry owns.
execute if data storage evercraft:bq_cur {quest:{type:"place_any"}} run scoreboard players add @s ec.bq_prog 1
execute if data storage evercraft:bq_cur {quest:{type:"variety"}} run scoreboard players add @s ec.bq_prog 1

# === HANDCRAFTER "Resourceful Hands" refund perk (W3, R7 piggyback) ===
# Rides this existing tally line (NO second hot-path edit): a rank-S (8)+ Handcrafter
# has a chance to refund the placed block. Cheap-gate-first — sub-rank-8 players pay
# one score comparison and stop. (Limitation: only fires while on an untyped-incremental
# Build quest, since that is when the hot path reaches this file — see on_place_refund.)
execute if score @s ec.bc_rank matches 8.. run function evercraft:guild_cards/perks/on_place_refund

# Re-evaluate the active quest (check is existence-gated + idempotent).
function evercraft:build_quests/check
