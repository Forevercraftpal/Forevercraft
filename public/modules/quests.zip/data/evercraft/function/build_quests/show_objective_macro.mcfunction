# ============================================================
# The Build Quests Engine — Show objective (macro body)
# ============================================================
# Called `with storage evercraft:bq_cur o`, where o = the current quest object
#   {id,title,desc,type,target,count,reward,reward_amt,chapter,(lore,beat,skippable)}.
# Mirrors the Fisher show_objective tone (white-not-gray active line, gray desc).
# (The C0 lore line + [Skip ▸] button are rendered separately by the caller via
#  quest_pacing/render_lore, AFTER this — keeps the objective render line-agnostic.)
$tellraw @s [{text:"➤ ",color:"yellow"},{text:"$(title)",color:"white",bold:true}]
$tellraw @s [{text:"  $(desc)",color:"gray"}]
$tellraw @s [{text:"  Quest $(id)",color:"dark_gray"},{text:"  ·  Chapter $(chapter)",color:"dark_gray"}]
