# ============================================================
# The Build Quests Engine — get_quest macro body
# ============================================================
# Called with storage evercraft:bq_cur containing {idx:<0-based index>}.
# Copies registry quest[idx] into evercraft:bq_cur quest.
$data modify storage evercraft:bq_cur quest set from storage evercraft:bq_registry quests[$(idx)]
