# ============================================================
# The Build Quests Engine — Registry batch C (COLOUR MASTERY, q19..q20)
# ============================================================
# Two extra place_palette beats that finally use the COOL and MONOCHROME palettes
# (tags + advancements + handlers already existed; only quests were missing).
# Appended AFTER batch H (q6..q18), so the FIRST quest here is id=19 (list index 18),
# contiguous — list-position == ec.bq_quest-1 stays true. Do NOT renumber earlier
# batches (the linear pointer is each player's saved progress).
#
# advance reads N (list length) dynamically, so the line auto-extends past q18: the
# old capstone (q18 "A Ward on the Threshold") is now a normal beat, and q20
# (monochrome) becomes the line-ender that fires finish() — the "Master of the Craft"
# fanfare + Dexterity prestige capstone. Schema + XP tier table per batch 0.
# ------------------------------------------------------------

# === Chapter 7: Colour Mastery (the painter's eye) ==========================

# q19 — COOL palette. place_palette target:"cool" (#evercraft:bq_palette/cool).
#   xp tier 6. Default [Skip ▸].
data modify storage evercraft:bq_registry quests append value {id:19,title:"The Colour of Distance",desc:"Place 18 blocks from the COOL colour family (blues, greens, ice, prismarine).",type:"place_palette",target:"cool",count:18,reward:"xp",reward_amt:700,chapter:7,lore:"Cool tones step back and let a room breathe — blue and green are the colours of far water and distant hills. Lay them, and a wall starts to feel like open sky."}

# q20 — MONOCHROME palette + NEW LINE-ENDER. place_palette target:"monochrome"
#   (#evercraft:bq_palette/monochrome). xp tier 7 (capstone). Its completion fires
#   build_quests/finish (Master of the Craft) since it is now the last quest.
data modify storage evercraft:bq_registry quests append value {id:20,title:"Discipline in Grey",desc:"Place 20 blocks from the MONOCHROME palette (whites, greys, quartz, blackstone).",type:"place_palette",target:"monochrome",count:20,reward:"xp",reward_amt:950,chapter:7,lore:"The hardest palette is the one with no colour at all. In white and grey and quartz the master hides every flaw in plain sight — restraint is the last discipline the hand learns."}

# ------------------------------------------------------------
# This batch ends at id=20. A future batch's FIRST quest MUST be id=21, appended
# immediately after q20, contiguously. registry/load calls load_batch_0, _h, then
# this batch — do NOT renumber. advance reads N dynamically, so q20's finish() fires
# only while N == 20; a later batch auto-extends the line past it.
# ------------------------------------------------------------
