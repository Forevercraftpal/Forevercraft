# ============================================================
# The Build Quests Engine — Registry batch G (GEAR CAPSTONE, q21)
# ============================================================
# The first Build quest that pays reward:"gear" — the line's true capstone reward,
# the Keystone Helm (a Master-Builder wearable). The gear reward dispatcher
# (reward_type/gear) and its inv-full handling already existed (engine-completeness
# clone of the Fisher line); this batch finally AUTHORS a quest that invokes it,
# plus the matching reward-agent loot table at
#   evercraft:build_quests/rewards/gear/keystone_helm.
# (Structural clone of the Fisher gear capstone, fishing/.../load_batch_5 q132 "The
# Deepline Boots" — a free-target objective type carrying the gear id in `target`.)
#
# Appended AFTER batch C (q19..q20), so the FIRST quest here is id=21 (list index 20),
# contiguous — list-position == ec.bq_quest-1 stays true. Do NOT renumber earlier
# batches (the linear pointer is each player's saved progress).
#
# advance reads N (list length) dynamically, so the line auto-extends past q20: the
# old capstone (q20 "Discipline in Grey") is now a normal beat, and q21 becomes the
# new line-ender that fires finish() — the "Master of the Craft" fanfare + Dexterity
# prestige capstone. (Same pattern by which batch C demoted q18 and batch H demoted
# q5.) Schema + XP tier table per batch 0.
#
# TYPE NOTE: `place_any` (one of the free-target types — place_any/variety/lifetime
# leave target "" per the batch-0 schema) leaves `target` free to carry the GEAR item
# id, exactly like the Fisher capstone's catch_node. (REBALANCE Joseph 2026-06-05: was
# `lifetime` reading ach.blocks_placed directly — a veteran past 10,000 auto-passed the
# whole capstone at FULL gear reward for zero effort this run. Now `place_any` counts
# ec.bq_prog from quest-START via on_place_tally, so it is a real "place N from now"
# grind. Gear items still pay in full even on an auto-pass — only XP dumps are throttled
# by the autopass token — so the helm always flows once the count is honestly met.)
# ------------------------------------------------------------

# === Chapter 8: The Keystone (the master's reward) ==========================

# q21 — *** GEAR CAPSTONE + NEW LINE-ENDER ***: place 2,000 blocks (from quest-start)
#   and earn the Keystone Helm. type:"place_any" leaves target free, so target carries
#   the gear id "keystone_helm" (the reward-agent loot table). reward:"gear" routes to
#   reward_type/gear, which loot-gives evercraft:build_quests/rewards/gear/$(target).
#   Its completion fires build_quests/finish (Master of the Craft) since it is now
#   the last quest. reward_amt:1 (one helm). No XP tier here — the gear IS the prize.
data modify storage evercraft:bq_registry quests append value {id:21,title:"The Keystone",desc:"Place 2,000 blocks in all, then receive the Keystone Helm — the mark of a master builder, set atop a life of honest work.",type:"place_any",target:"keystone_helm",count:2000,reward:"gear",reward_amt:1,chapter:8,lore:"Every wall you have ever raised was leading here. The keystone is the last stone set and the first that would be missed — and so is the builder who knows how to set it."}

# ------------------------------------------------------------
# This batch ends at id=21. A future batch's FIRST quest MUST be id=22, appended
# immediately after q21, contiguously. registry/load calls load_batch_0, _h, _c,
# then this batch — do NOT renumber. advance reads N dynamically, so q21's finish()
# fires only while N == 21; a later batch auto-extends the line past it.
# ------------------------------------------------------------
