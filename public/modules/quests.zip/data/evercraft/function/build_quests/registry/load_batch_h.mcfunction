# ============================================================
# The Build Quests Engine — Registry batch H (HOUSING CONVERGENCE, round-1 W6)
# ============================================================
# The converging "top-layer sequence": 10 teach-beats (H1..H10) that surface every
# useful housing / Baúl / glyph-totem / House-Key / garden / laborer / artifact /
# protection feature, authored as Build registry rows on the W1 engine. Plus 3
# interlude breathers (3:1-ish cadence). Appended AFTER batch 0 (q1..q5), so the
# FIRST quest here is id=6 (list index 5), contiguous. (Housing seat owns this CONTENT;
# the W1 Build engine is untouched — these rows ride it.)
#
# ZERO new objectives. Every H-beat DETECTS existing housing state read-only via a
# check_type helper and (for the teach grant) calls an EXISTING give-fn or pointer via
# the OPTIONAL `teach` field -> build_quests/teach/<name> (self-guarded, idempotent,
# spam-free via the ec.bq_prog-0 latch). housing/Baúl/inscription/artifact internals
# are NOT edited.
#
# NEW check_types this batch introduces (all read-only, all call teach_dispatch first):
#   home_tier      -> hs.tier >= count            (H1 count:1 claim home; H6 count:3 garden)
#   stash_used     -> hs.stashed >= count         (H2 Quick-Stash)
#   bb_haul        -> hs.stashed >= count          (H3 Baúl big-haul, DECISIONS D2)
#   totem_at_home  -> hs.totems >= count AND hs.in_zone==1   (H4 — home-zone-gated)
#   place_palette  -> ec.bq_prog >= count          (H5 nature palette; ENGINE type reused)
#   has_house_key  -> tag hs.has_satchel           (H7)
#   laborer        -> ec.lb_count >= count          (H8)
#   artifact       -> ec.artifacts_ever >= count    (H9, lifetime read)
#   protection     -> hs.protect >= count           (H10, R11 honest copy)
#
# XP TIER TABLE (R9, shared with batch 0): 40 / 90 / 180 / 320 / 480 / 700 / 950.
# All H-beats AUTO-PASS for a veteran via the threshold read on the next 20t
# check_progress tick (no re-grinding; forward cursor blocks retro-credit). The
# skippable:0 see-it-once beat (H2) shows NO [Skip ▸] for a newcomer but still auto-
# passes a vet.
# (REBALANCE Joseph 2026-06-05: an auto-passed XP-reward beat now pays a flat TOKEN
# (25 Building XP) instead of the full tier dump, via the activation probe in
# build_quests/advance + reward_autopass — a veteran who already owns the home/key/
# artifact no longer cascades 320–950 XP per beat for zero effort this run. ITEMS
# (the crate on H2/H6) still pay in full; only the XP dump is throttled.)
# ------------------------------------------------------------

# === Chapter 4: Hearth & Home (claim, stash, the Baúl) ======================

# q6 — H1: claim a Hearthstone (home tier reaches 1). POINTER teach. xp tier 4.
data modify storage evercraft:bq_registry quests append value {id:6,title:"A Place to Stand",desc:"Claim a home: set a Hearthstone (reach home Tier 1).",type:"home_tier",target:"",count:1,reward:"xp",reward_amt:320,chapter:4,teach:"h1_claim_home",lore:"A builder without a home is a traveller with good tools. Set your Hearthstone, and the world gains a centre it did not have before."}

# q7 — *** SEE-IT-ONCE teach beat (skippable:0) ***  H2: Quick-Stash. GRANT teach
#   (a Stash Label). NO [Skip ▸] for a newcomer; a veteran still auto-passes. Crate.
data modify storage evercraft:bq_registry quests append value {id:7,title:"Everything In Its Place",desc:"Quick-Stash your pack at least once (use a Stash Label on a barrel, then stash).",type:"stash_used",target:"uncommon",count:1,reward:"crate",reward_amt:1,chapter:4,teach:"h2_quick_stash",lore:"A tidy hold is a clear mind. Name your barrels once, and your whole pack files itself in a single motion ever after.",skippable:0}

# q8 — H3: the Baúl big-haul funnel (DECISIONS D2 — ships now, honest copy). POINTER
#   teach. count:8 stashes (a threshold past H2, so a big haul has plausibly flowed
#   through). xp tier 5. The honest copy names BOTH preconditions (>256 of one item +
#   an empty Baúl nearby) so it never promises behaviour that does not fire.
data modify storage evercraft:bq_registry quests append value {id:8,title:"The Bottomless Barrel",desc:"Learn the Baúl: carry 256+ of one item with an empty Baúl nearby, then Quick-Stash to funnel the whole haul into it. (Keep stashing — 8 stashes complete this.)",type:"bb_haul",target:"",count:8,reward:"xp",reward_amt:480,chapter:4,teach:"h3_big_haul",lore:"Some hoards outgrow a barrel's nine stacks. A Baúl swallows nine thousand of a single thing and asks for no label — it is named by what it holds."}

# q9 — *** INTERLUDE *** (count:0, pure lore): a breather before the colour-theory
#   and estate chapters. Auto-passes on the next 20t check, lore once, coins:1 once.
data modify storage evercraft:bq_registry quests append value {id:9,title:"On Making a House a Home",desc:"",type:"interlude",target:"",count:0,reward:"coins",reward_amt:8,chapter:4,beat:"interlude",lore:"Walls keep out the weather. What makes a home is everything you choose to put inside the walls — and the care with which you place it."}

# === Chapter 5: The Living Estate (totem, colour, garden, the Key) ==========

# q10 — H4: forge a glyph totem AND be in your home zone. POINTER teach. Home-zone-
#   gated (hs.in_zone) per the wave. xp tier 5.
data modify storage evercraft:bq_registry quests append value {id:10,title:"The Ancient Network",desc:"Set a glyph totem inside your home zone (forge one at a Glyph Forge).",type:"totem_at_home",target:"",count:1,reward:"xp",reward_amt:480,chapter:5,teach:"h4_glyph_totem",lore:"The old patterns answer to those who lay them at home. One totem is a candle; a network of them is a hearth-fire that warms the whole estate."}

# q11 — H5: colour theory — build a stretch from the NATURE palette (new this wave).
#   place_palette (ENGINE type) target:"nature". POINTER teach (one-time, does NOT
#   write ec.bq_prog — the placement tally owns it). xp tier 4.
data modify storage evercraft:bq_registry quests append value {id:11,title:"One Calm Colour",desc:"Place 20 blocks from the NATURE palette (greens, woods, mossy stone).",type:"place_palette",target:"nature",count:20,reward:"xp",reward_amt:320,chapter:5,teach:"h5_color_theory",lore:"Colour is the builder's quiet language. Hold to one family across a wall and the eye reads it as a single, deliberate thought."}

# q12 — H6: the Garden Plot — reach home Tier 3 (Estate). POINTER teach. Crate.
data modify storage evercraft:bq_registry quests append value {id:12,title:"A Garden of Your Own",desc:"Grow your home to Tier 3 (Estate) — it unlocks the Garden Plot.",type:"home_tier",target:"rare",count:3,reward:"crate",reward_amt:1,chapter:5,teach:"h6_garden",lore:"An Estate feeds the hands that raised it. Bring your home to its third tier and the ground around your Hearthstone learns to ripen on its own."}

# q13 — *** INTERLUDE *** (count:0): a breather framing the estate as a living thing.
data modify storage evercraft:bq_registry quests append value {id:13,title:"The Estate Breathes",desc:"",type:"interlude",target:"",count:0,reward:"coins",reward_amt:12,chapter:5,beat:"interlude",lore:"A great home is never finished — it grows, it tends itself, it remembers who built it. You are no longer just placing blocks. You are keeping a place alive."}

# q14 — H7: earn the House Key (remote stashing). GATED GRANT teach (only awards to a
#   player who already meets the Tier-3 + Architect-comfort gate but missed it; else
#   points). xp tier 6.
data modify storage evercraft:bq_registry quests append value {id:14,title:"The Key of the House",desc:"Earn a House Key (Tier-3 home + Architect comfort) — stash from anywhere.",type:"has_house_key",target:"",count:1,reward:"xp",reward_amt:700,chapter:5,teach:"h7_house_key",lore:"The Key is the estate's trust in your hands. Hold it, and the distance between you and your own shelves disappears."}

# === Chapter 6: Stewardship (laborers, artifacts, the ward) =================

# q15 — H8: hire a Laborer. POINTER teach. xp tier 5.
data modify storage evercraft:bq_registry quests append value {id:15,title:"Many Hands",desc:"Take on a Laborer at your estate.",type:"laborer",target:"",count:1,reward:"xp",reward_amt:480,chapter:6,teach:"h8_laborers",lore:"No steward builds an empire alone. Hire a willing hand, send them out, and let the estate work even while you rest."}

# q16 — H9: discover an Artifact (lifetime read). POINTER teach. xp tier 6.
data modify storage evercraft:bq_registry quests append value {id:16,title:"Heirlooms",desc:"Discover your first Artifact (forge one or unearth it).",type:"artifact",target:"",count:1,reward:"xp",reward_amt:700,chapter:6,teach:"h9_artifact",lore:"A home is built to hold what matters. The first artifact you bring under your roof is the first thing your house was waiting for."}

# q17 — *** INTERLUDE *** (count:0): a breather before the final ward beat.
data modify storage evercraft:bq_registry quests append value {id:17,title:"What You Leave Standing",desc:"",type:"interlude",target:"",count:0,reward:"coins",reward_amt:15,chapter:6,beat:"interlude",lore:"Long after a builder lays down their tools, the home stands and speaks for them. Build as though it will outlast you — because, set true, it will."}

# q18 — H10: guard your home (protection). POINTER teach with HONEST copy (R11 —
#   "deters mining-griefers," NOT "untouchable"). xp tier 7 (line capstone).
data modify storage evercraft:bq_registry quests append value {id:18,title:"A Ward on the Threshold",desc:"Toggle home protection on at your Hearthstone (deters mining-griefers in your zone).",type:"protection",target:"",count:1,reward:"xp",reward_amt:950,chapter:6,teach:"h10_protection",lore:"The last thing a steward learns is how to say 'this is mine, and it is kept.' A ward will not make your home untouchable — but it will make a careless hand think twice, and that is often enough."}

# ------------------------------------------------------------
# This batch ends at id=18. A future batch's FIRST quest MUST be id=19, appended
# immediately after q18, contiguously. registry/load calls load_batch_0 then this
# batch — do NOT renumber. advance reads N (list length) dynamically, so q18's
# finish() fires only while N == 18; a later batch auto-extends the line past it.
# ------------------------------------------------------------
