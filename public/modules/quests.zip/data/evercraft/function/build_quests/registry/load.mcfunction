# ============================================================
# The Build Quests Engine — Registry load (storage init + batch dispatch)
# ============================================================
# Initializes the quest registry storage to an empty list, then calls each
# load_batch_K to append its quests. The storage is volatile across /reload, so
# this MUST run every reload (called from build_quests/load).
# (Structural clone of fishing/questline/registry/load.)
#
# Registry shape (storage evercraft:bq_registry):
#   {quests:[ {id,title,desc,type,target,count,reward,reward_amt,chapter,
#              (lore,beat,skippable)}, ... ]}
# The three trailing fields are the C0 pacing delta (SCHEMA_DELTA) — all OPTIONAL.
#
# Each load_batch_K appends via:
#   data modify storage evercraft:bq_registry quests append value {...}
# Quests are appended in id order so the 0-based list index == (ec.bq_quest - 1).

# Reset to an empty quest list.
data modify storage evercraft:bq_registry quests set value []

# Append the quest batches, in id order (id 1 first => list index 0). Batch 0 is
# the starter on-ramp (q1..q5) — the smallest playable slice (WAVE-PLAN W1). Batch H
# is the Housing convergence chapters (round-1 W6, q6..q18) — appended AFTER batch 0,
# contiguously, so the line auto-extends past q5 into H1.
function evercraft:build_quests/registry/load_batch_0
function evercraft:build_quests/registry/load_batch_h
# Batch C — Colour Mastery (q19 cool, q20 monochrome). Appended after H, contiguously;
# q20 becomes the new line-ender (fires finish). The line auto-extends past q18.
function evercraft:build_quests/registry/load_batch_c
# Batch G — Gear Capstone (q21 "The Keystone", reward:"gear" -> Keystone Helm). Appended
# after C, contiguously; q21 becomes the new line-ender (fires finish). The first Build
# quest to invoke the gear reward path + its rewards/gear/keystone_helm loot table.
function evercraft:build_quests/registry/load_batch_g
