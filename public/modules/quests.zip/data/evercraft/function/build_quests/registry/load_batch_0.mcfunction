# ============================================================
# The Build Quests Engine — Registry batch 0 (STARTER on-ramp, q1..q5)
# ============================================================
# Appends the first 5 quests onto storage evercraft:bq_registry quests.
# Called by registry/load AFTER it sets quests=[]. MUST append in id order
# (id=1 first => list index 0), contiguous, so list-position == ec.bq_quest-1.
# (Structural clone of fishing/questline/registry/load_batch_0, paced via C0.)
#
# Quest object schema (the engine reads these exact fields):
#   {id:int, title:string, desc:string, type:string, target:string,
#    count:int, reward:string, reward_amt:int, chapter:int,
#    [lore:string], [beat:string], [skippable:int]}      <- C0 fields OPTIONAL
#
# type    -> dispatched by check_type/$(type):
#            place_any | place_palette | variety | lifetime | milestone
#            (beat:"interlude"/count:0 auto-passes BEFORE dispatch — SCHEMA_DELTA §3)
# target  -> place_palette: the colour/material family (warm|cool|stone_family),
#              matched against the tag #evercraft:bq_palette/<family>
#            milestone: "blocks_placed" | "total_done" | "cf_rank" (mirror score)
#            reward crate: tier name (common|uncommon|rare|ornate|exquisite|mythical)
#            reward gear: the reward-table id (NOT used in batch 0)
#            (place_any/variety/lifetime leave target "" — engine ignores it)
# count   -> place_*/variety: ec.bq_prog threshold; lifetime/milestone: mirror
#              threshold (read off ach.blocks_placed / ec.bq_done / ec.cf_rank);
#              interlude: 0 (auto-pass)
# reward  -> xp | coins | crate | gear   (NO title — R2). reward_amt = amount.
#            xp pays category-3 Building XP via the FROZEN add_xp contract (R9).
# chapter -> display grouping only.
#
# XP TIER TABLE (R9, artisan-locked flat curve, sits just under the blueprint band
# so a Build quest is never a fatter XP source than a blueprint of equal tier):
#   40 / 90 / 180 / 320 / 480 / 700 / 950
#
# C0 CADENCE (SCHEMA_DELTA §1): batch 0 carries `lore` on every objective beat,
# one `interlude` breather (q3), and one `skippable:0` see-it-once teach beat (q2,
# the headline place_palette mechanic). 4 objective beats : 1 interlude ≈ the 3:1 aim.
# (REBALANCE Joseph 2026-06-05: q4 was a `lifetime` catch-up that auto-passed veterans
# PAST q2; q4 is now `place_any` counting from quest-start, so the early on-ramp is a
# genuine task for everyone — a veteran still has the [Skip ▸] button per the C0 spec.)
# ------------------------------------------------------------

# --- Chapter 1: First Foundations ------------------------------------------

# q1 — gentle intro: place ANY 10 blocks. Pure on-ramp. lore + default [Skip ▸].
data modify storage evercraft:bq_registry quests append value {id:1,title:"First Foundation",desc:"Place 10 blocks of any kind.",type:"place_any",target:"",count:10,reward:"xp",reward_amt:40,chapter:1,lore:"Ten blocks is a beginning the Building XP ladder already counts — every placement feeds your Artisan rank through the same gate as quests. Build because you want to; the Chronicle keeps score anyway."}

# q2 — *** SEE-IT-ONCE teach beat (skippable:0) ***: the headline place_palette
#   mechanic. NO [Skip ▸] button for a newcomer. (A veteran no longer auto-cascades
#   past this via q4 — q4 is now place_any from quest-start; Decision #5 superseded by
#   the 2026-06-05 rebalance — but can still reach it normally.) Reward a small crate.
data modify storage evercraft:bq_registry quests append value {id:2,title:"Raise a Palette",desc:"Place 16 blocks from the WARM colour family.",type:"place_palette",target:"warm",count:16,reward:"crate",reward_amt:1,chapter:1,lore:"Colour is the builder's quiet language. Speak one hue at a time, and your walls will sing.",skippable:0}

# q3 — *** INTERLUDE (pure lore, count:0) ***: a tiny breather that auto-passes on
#   the next 20t check, delivers its lore once, pays coins:1 once. Proves the C0
#   interlude path end-to-end. beat:"interlude" => check() satisfies it pre-dispatch.
data modify storage evercraft:bq_registry quests append value {id:3,title:"A Word on Proportion",desc:"",type:"interlude",target:"",count:0,reward:"coins",reward_amt:5,chapter:1,beat:"interlude",lore:"Proportion is free: a third of height in roof, a door off-center, windows in odd numbers. The Build Quests teach the eye; the Housing system rewards what the eye learns."}

# q4 — PLACE-ANY on-ramp: place 100 blocks FROM QUEST-START. (REBALANCE Joseph
#   2026-06-05: was type:"lifetime" reading ach.blocks_placed directly, which let a
#   veteran auto-pass at FULL reward for zero effort this run and cascaded the early
#   chain. Now counts ec.bq_prog from activation via on_place_tally — a real "place
#   100 from now" task. An auto-pass here is impossible: ec.bq_prog=0 at activation.)
data modify storage evercraft:bq_registry quests append value {id:4,title:"Ground Won",desc:"Place 100 blocks in all. The land takes the shape of patient hands.",type:"place_any",target:"",count:100,reward:"xp",reward_amt:90,chapter:1,lore:"A hundred blocks won is ground the laborers can work, the Hearthstone can claim, and the garden plots can grow. Building is the Crafter chronicle's load-bearing wall."}

# q5 — second place_palette family (stone_family), a slightly bigger pour. Default
#   [Skip ▸]. Reward Building XP (tier 3). Chapter-1 closer.
data modify storage evercraft:bq_registry quests append value {id:5,title:"The Bones of a Build",desc:"Place 24 blocks from the STONE family.",type:"place_palette",target:"stone_family",count:24,reward:"xp",reward_amt:180,chapter:1,lore:"Stone is the bone beneath every great work. Set it well, and what you raise upon it will stand for ages."}

# ------------------------------------------------------------
# HAND-OFF TO load_batch_h (Housing convergence chapters, round-1 W6):
#   - This batch ends at id=5. The next batch's FIRST quest MUST be id=6 (list
#     index 5), appended immediately after q5, contiguously.
#   - registry/load calls load_batch_0 then will call load_batch_h when it lands;
#     add that call to registry/load at that time. Do NOT renumber this batch.
#   - q5 is a soft finale, not THE line finale: advance reads N (list length)
#     dynamically, so appending load_batch_h auto-extends the line — q5's finish()
#     only fires while N == 5. Once a later batch is wired, q5 advances into q6.
# ------------------------------------------------------------
