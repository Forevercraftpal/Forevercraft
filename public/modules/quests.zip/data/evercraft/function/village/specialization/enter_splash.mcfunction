# ============================================================
# Village Entry Splash (title + subtitle)
# Called from on_enter with the nearest village-name armor_stand
# as the macro source:  ... with entity @n[type=armor_stand,tag=bestiary.village.name]
#   $(CustomName) = the village name text component (biome color), set by
#                   evercraft:mobs/village/name/set_name.
# Pre-set scores (by on_enter, all on vs.temp):
#   #vs_current_spec  = 1-6 (the village specialization)
#   #vs_splash_type   = 0 none / 1 Merchant (specs 1/2/3/6) / 2 Adventure (specs 4/5)
# Run as @s = the entering player.
# SNBT text components (matches on_enter / message/entering idiom).
# ============================================================

# Title timing: short fade so the name reads like the bestiary "entering" splash
title @s times 10 50 20

# --- Title = the village's name (◆ Name ◆), reusing the bestiary plate styling ---
$title @s title [{text:"◆ ",color:"#D6D0C7"},$(CustomName),{text:" ◆",color:"#D6D0C7"}]

# --- Subtitle = "<Spec> Village · <Category>" ---
# Merchant villages (specs 1/2/3/6)
execute if score #vs_current_spec vs.temp matches 1 run title @s subtitle [{text:"Mining Village",color:"yellow"},{text:" · ",color:"dark_gray"},{text:"Merchant",color:"gold"}]
execute if score #vs_current_spec vs.temp matches 2 run title @s subtitle [{text:"Fishing Village",color:"aqua"},{text:" · ",color:"dark_gray"},{text:"Merchant",color:"gold"}]
execute if score #vs_current_spec vs.temp matches 3 run title @s subtitle [{text:"Farming Village",color:"green"},{text:" · ",color:"dark_gray"},{text:"Merchant",color:"gold"}]
execute if score #vs_current_spec vs.temp matches 6 run title @s subtitle [{text:"Scholarly Village",color:"light_purple"},{text:" · ",color:"dark_gray"},{text:"Merchant",color:"gold"}]
# Adventure villages (specs 4/5)
execute if score #vs_current_spec vs.temp matches 4 run title @s subtitle [{text:"Combat Village",color:"red"},{text:" · ",color:"dark_gray"},{text:"Adventure",color:"#D08770"}]
execute if score #vs_current_spec vs.temp matches 5 run title @s subtitle [{text:"Exploration Village",color:"dark_aqua"},{text:" · ",color:"dark_gray"},{text:"Adventure",color:"#D08770"}]
