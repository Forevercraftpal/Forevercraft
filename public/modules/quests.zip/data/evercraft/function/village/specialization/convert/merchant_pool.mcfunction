# ============================================================
# Merchant-village OFF-TYPE pool (bias cross-pick)
# Called from convert_villager when a Merchant village (spec 1/2/3/6) rolls the
# cross-pick chance. Picks a random PASSIVE/utility job (flavor: gathering /
# crafting / nature / scholarly) instead of the spec's hard-mapped default.
# Runs positioned at the lectern (same context as convert/<spec>).
# Weighted roll over the 8 passive jobs (vs.temp #vs_pool_roll).
# Job classification + weights are TUNABLE — see SHIPLOG / guild_cards leaf doc.
# ============================================================

# 8 passive/utility jobs, equal weight (1..8)
execute store result score #vs_pool_roll vs.temp run random value 1..8
execute if score #vs_pool_roll vs.temp matches 1 as @e[type=villager,tag=!more_professions_verified,distance=..48,sort=random,limit=1] run function evercraft:professions/berries/convert_to_beekeeper
execute if score #vs_pool_roll vs.temp matches 2 as @e[type=villager,tag=!more_professions_verified,distance=..48,sort=random,limit=1] run function evercraft:professions/berries/convert_to_nymph
execute if score #vs_pool_roll vs.temp matches 3 as @e[type=villager,tag=!more_professions_verified,distance=..48,sort=random,limit=1] run function evercraft:professions/berries/convert_to_circut_board
execute if score #vs_pool_roll vs.temp matches 4 as @e[type=villager,tag=!more_professions_verified,distance=..48,sort=random,limit=1] run function evercraft:professions/berries/convert_to_miner
execute if score #vs_pool_roll vs.temp matches 5 as @e[type=villager,tag=!more_professions_verified,distance=..48,sort=random,limit=1] run function evercraft:professions/berries/convert_to_zookeeper
execute if score #vs_pool_roll vs.temp matches 6 as @e[type=villager,tag=!more_professions_verified,distance=..48,sort=random,limit=1] run function evercraft:professions/berries/convert_to_bartender
execute if score #vs_pool_roll vs.temp matches 7 as @e[type=villager,tag=!more_professions_verified,distance=..48,sort=random,limit=1] run function evercraft:professions/berries/convert_to_taskmaster
execute if score #vs_pool_roll vs.temp matches 8 as @e[type=villager,tag=!more_professions_verified,distance=..48,sort=random,limit=1] run function evercraft:professions/berries/convert_to_wise_wanderer
execute as @e[type=villager,tag=more_professions_verified,distance=..48,limit=1,sort=nearest] run tag @s add vs.just_converted
