# ============================================================
# Adventure-village OFF-TYPE pool (bias cross-pick)
# Called from convert_villager when an Adventure village (spec 4/5) rolls the
# cross-pick chance. Picks a random TRADER job (flavor: combat-gear /
# artifact / adventure-loot seller) instead of the spec's hard-mapped default.
# Runs positioned at the lectern (same context as convert/<spec>).
# Weighted roll over the 4 trader jobs (vs.temp #vs_pool_roll).
# Job classification + weights are TUNABLE — see SHIPLOG / guild_cards leaf doc.
# ============================================================

# 4 trader/adventurer jobs, equal weight (1..4)
execute store result score #vs_pool_roll vs.temp run random value 1..4
execute if score #vs_pool_roll vs.temp matches 1 as @e[type=villager,tag=!more_professions_verified,distance=..48,sort=random,limit=1] run function evercraft:professions/berries/convert_to_artificer
execute if score #vs_pool_roll vs.temp matches 2 as @e[type=villager,tag=!more_professions_verified,distance=..48,sort=random,limit=1] run function evercraft:professions/berries/convert_to_retired_adventurer
execute if score #vs_pool_roll vs.temp matches 3 as @e[type=villager,tag=!more_professions_verified,distance=..48,sort=random,limit=1] run function evercraft:professions/berries/convert_to_hunter
execute if score #vs_pool_roll vs.temp matches 4 as @e[type=villager,tag=!more_professions_verified,distance=..48,sort=random,limit=1] run function evercraft:professions/berries/convert_to_explorer
execute as @e[type=villager,tag=more_professions_verified,distance=..48,limit=1,sort=nearest] run tag @s add vs.just_converted
