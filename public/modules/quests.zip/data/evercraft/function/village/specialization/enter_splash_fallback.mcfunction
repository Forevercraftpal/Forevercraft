# ============================================================
# Village Entry Splash — FALLBACK (no name marker resolvable)
# Called from on_enter when NO bestiary.village.name armor_stand is within
# range (e.g. village naming disabled, or the marker hasn't spawned yet).
# Title = a generic spec headline (no per-village name), subtitle = category.
# Run as @s = the entering player. #vs_current_spec vs.temp = 1-6.
# SNBT text components (matches on_enter idiom).
# ============================================================

title @s times 10 50 20

# Title = "◆ <Spec> Village ◆" in the spec color (stands in for the missing name)
execute if score #vs_current_spec vs.temp matches 1 run title @s title [{text:"◆ ",color:"#D6D0C7"},{text:"Mining Village",color:"yellow"},{text:" ◆",color:"#D6D0C7"}]
execute if score #vs_current_spec vs.temp matches 2 run title @s title [{text:"◆ ",color:"#D6D0C7"},{text:"Fishing Village",color:"aqua"},{text:" ◆",color:"#D6D0C7"}]
execute if score #vs_current_spec vs.temp matches 3 run title @s title [{text:"◆ ",color:"#D6D0C7"},{text:"Farming Village",color:"green"},{text:" ◆",color:"#D6D0C7"}]
execute if score #vs_current_spec vs.temp matches 4 run title @s title [{text:"◆ ",color:"#D6D0C7"},{text:"Combat Village",color:"red"},{text:" ◆",color:"#D6D0C7"}]
execute if score #vs_current_spec vs.temp matches 5 run title @s title [{text:"◆ ",color:"#D6D0C7"},{text:"Exploration Village",color:"dark_aqua"},{text:" ◆",color:"#D6D0C7"}]
execute if score #vs_current_spec vs.temp matches 6 run title @s title [{text:"◆ ",color:"#D6D0C7"},{text:"Scholarly Village",color:"light_purple"},{text:" ◆",color:"#D6D0C7"}]

# Subtitle = category only (spec name is already in the title)
execute if score #vs_splash_type vs.temp matches 1 run title @s subtitle [{text:"Merchant Village",color:"gold"}]
execute if score #vs_splash_type vs.temp matches 2 run title @s subtitle [{text:"Adventure Village",color:"#D08770"}]
