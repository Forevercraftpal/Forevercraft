# ============================================================
# Convert Random Villager to Match Village Specialization
# Called from create_new.mcfunction after specialization assign
# Runs positioned at the lectern block
# Reads #vs_spec vs.temp (1-6) set by assign.mcfunction
# ============================================================

# Exit if no unconverted villagers nearby
execute unless entity @e[type=villager,tag=!more_professions_verified,distance=..48] run return 0

# --- Merchant/Adventure spawn bias (cross-pick) -------------------------------
# Most conversions use the spec's hard-mapped default (convert/<spec>). But with
# a small chance we instead pick an OFF-TYPE job that still matches the village's
# GUILD TYPE flavor: Merchant villages (specs 1/2/3/6) lean PASSIVE/utility jobs,
# Adventure villages (specs 4/5) lean TRADER jobs. This is a soft BIAS, not a
# lock — off-type jobs only appear on the cross-pick window; on-type stays common.
#
# #vs_vtype     vs.temp : 0 none / 1 Merchant / 2 Adventure (mirrors guild_cards/village_type)
# #vs_pick_roll vs.temp : 1..100 ; cross-pick when <= #vs_crosspick (TUNABLE, default 20 = 20%)
# #vs_did_cross vs.temp : 1 if the cross-pick fired (suppresses the spec default below)
scoreboard players set #vs_vtype vs.temp 0
execute if score #vs_spec vs.temp matches 1 run scoreboard players set #vs_vtype vs.temp 1
execute if score #vs_spec vs.temp matches 2 run scoreboard players set #vs_vtype vs.temp 1
execute if score #vs_spec vs.temp matches 3 run scoreboard players set #vs_vtype vs.temp 1
execute if score #vs_spec vs.temp matches 6 run scoreboard players set #vs_vtype vs.temp 1
execute if score #vs_spec vs.temp matches 4 run scoreboard players set #vs_vtype vs.temp 2
execute if score #vs_spec vs.temp matches 5 run scoreboard players set #vs_vtype vs.temp 2

# Cross-pick window (TUNABLE): raise #vs_crosspick for more off-type variety, lower for more on-type.
scoreboard players set #vs_crosspick vs.temp 20
scoreboard players set #vs_did_cross vs.temp 0
execute store result score #vs_pick_roll vs.temp run random value 1..100
execute if score #vs_vtype vs.temp matches 1.. if score #vs_pick_roll vs.temp <= #vs_crosspick vs.temp run scoreboard players set #vs_did_cross vs.temp 1
execute if score #vs_did_cross vs.temp matches 1 if score #vs_vtype vs.temp matches 1 run function evercraft:village/specialization/convert/merchant_pool
execute if score #vs_did_cross vs.temp matches 1 if score #vs_vtype vs.temp matches 2 run function evercraft:village/specialization/convert/adventure_pool

# Route by specialization ID (ON-TYPE default — skipped when the cross-pick fired)
execute if score #vs_did_cross vs.temp matches 0 if score #vs_spec vs.temp matches 1 run function evercraft:village/specialization/convert/mining
execute if score #vs_did_cross vs.temp matches 0 if score #vs_spec vs.temp matches 2 run function evercraft:village/specialization/convert/fishing
execute if score #vs_did_cross vs.temp matches 0 if score #vs_spec vs.temp matches 3 run function evercraft:village/specialization/convert/farming
execute if score #vs_did_cross vs.temp matches 0 if score #vs_spec vs.temp matches 4 run function evercraft:village/specialization/convert/combat
execute if score #vs_did_cross vs.temp matches 0 if score #vs_spec vs.temp matches 5 run function evercraft:village/specialization/convert/exploration
execute if score #vs_did_cross vs.temp matches 0 if score #vs_spec vs.temp matches 6 run function evercraft:village/specialization/convert/scholarly

# Highlight the converted villager with glowing (60s) and announce
execute as @e[type=villager,tag=vs.just_converted,distance=..48,limit=1] at @s run effect give @s glowing 60 0 true
execute as @e[type=villager,tag=vs.just_converted,distance=..48,limit=1] at @s run playsound minecraft:entity.player.levelup master @a[scores={ec.fx_snd=1..}] ~ ~ ~ 1 0.8
execute as @e[type=villager,tag=vs.just_converted,distance=..48,limit=1] at @s run particle minecraft:totem_of_undying ~ ~1 ~ 0.5 0.5 0.5 0.2 15
data modify storage evercraft:notify stage.c set value [{text:"A villager has been chosen as the village specialist: ",color:"green"},{nbt:"CustomName",entity:"@s",interpret:true},{text:"!",color:"green"}]
scoreboard players set #ndur ec.temp 50
execute as @e[type=villager,tag=vs.just_converted,distance=..48,limit=1] run execute as @a[distance=..64] run scoreboard players set #nttl ec.temp 600
execute as @e[type=villager,tag=vs.just_converted,distance=..48,limit=1] run execute as @a[distance=..64] run function evercraft:util/notify/emit_keep
# Scope the clear to THIS lectern's radius so a same-tick conversion at another
# village (<96 blocks away) keeps its just-set tag for its own highlight/announce
tag @e[tag=vs.just_converted,distance=..48] remove vs.just_converted
