# ============================================================
# On Enter Specialized Village
# Shows a NAME + TYPE title splash (+ buff actionbar) when entering a new village.
# Run as the player when entering a new village (once, from
# evercraft:quests/reputation/check_village — does NOT spam).
# Title  = the village's name (◆ Name ◆, biome color from the name marker)
# Subtitle = "<Spec> Village · Merchant|Adventure"
# Actionbar = the existing proximity-buff line (kept; renders below the subtitle)
# ============================================================

# Load specialization (sets #vs_current_spec vs.temp)
function evercraft:village/specialization/get_spec

# No specialization → no message
execute unless score #vs_current_spec vs.temp matches 1.. run return fail

# Check exile status first — if exiled, show exile warning instead
execute if score @s vs.exile matches 1 run function evercraft:village/exile/on_enter_exiled
execute if score @s vs.exile matches 1 run return fail

# --- Classify Merchant (specs 1/2/3/6) vs Adventure (specs 4/5) ---
# #vs_splash_type vs.temp = 0 none / 1 Merchant / 2 Adventure
scoreboard players set #vs_splash_type vs.temp 0
execute if score #vs_current_spec vs.temp matches 1 run scoreboard players set #vs_splash_type vs.temp 1
execute if score #vs_current_spec vs.temp matches 2 run scoreboard players set #vs_splash_type vs.temp 1
execute if score #vs_current_spec vs.temp matches 3 run scoreboard players set #vs_splash_type vs.temp 1
execute if score #vs_current_spec vs.temp matches 6 run scoreboard players set #vs_splash_type vs.temp 1
execute if score #vs_current_spec vs.temp matches 4 run scoreboard players set #vs_splash_type vs.temp 2
execute if score #vs_current_spec vs.temp matches 5 run scoreboard players set #vs_splash_type vs.temp 2

# --- Name + type title splash ---
# Preferred: read the village's NAME from the nearest bestiary.village.name armor_stand
# (same marker quests/reputation/check_village uses to resolve ec.current_village; its
# CustomName is the village name in biome color, set by mobs/village/name/set_name).
# Pass it as the macro source so the title can embed the live name component.
execute if entity @e[type=armor_stand,tag=bestiary.village.name,distance=..80] run function evercraft:village/specialization/enter_splash with entity @n[type=armor_stand,tag=bestiary.village.name]

# Fallback: no name marker resolvable (naming disabled, or marker not yet spawned) →
# spec-only headline so the entry splash still fires.
execute unless entity @e[type=armor_stand,tag=bestiary.village.name,distance=..80] run function evercraft:village/specialization/enter_splash_fallback

# --- Buff actionbar (existing tone; kept on the actionbar so it coexists with the splash) ---
execute if score #vs_current_spec vs.temp matches 1 run data modify storage evercraft:notify stage.c set value [{text:"◆ ",color:"gold"},{text:"Haste I while nearby",color:"gray"}]
execute if score #vs_current_spec vs.temp matches 2 run data modify storage evercraft:notify stage.c set value [{text:"◆ ",color:"gold"},{text:"Dreams I while nearby",color:"gray"}]
execute if score #vs_current_spec vs.temp matches 3 run data modify storage evercraft:notify stage.c set value [{text:"◆ ",color:"gold"},{text:"Regeneration I while nearby",color:"gray"}]
execute if score #vs_current_spec vs.temp matches 4 run data modify storage evercraft:notify stage.c set value [{text:"◆ ",color:"gold"},{text:"Strength I while nearby",color:"gray"}]
execute if score #vs_current_spec vs.temp matches 5 run data modify storage evercraft:notify stage.c set value [{text:"◆ ",color:"gold"},{text:"Speed I while nearby",color:"gray"}]
execute if score #vs_current_spec vs.temp matches 6 run data modify storage evercraft:notify stage.c set value [{text:"◆ ",color:"gold"},{text:"Night Vision while nearby",color:"gray"}]
scoreboard players set #ndur ec.temp 45
execute if score #vs_current_spec vs.temp matches 1..6 run function evercraft:util/notify/emit

execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.chime player @s ~ ~ ~ 0.5 1.2
