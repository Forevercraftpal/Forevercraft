# Remove Lockout Macro
# Clears exile data from evercraft:database
# Called with {vid: village_id, uuid: player_uuid_part}
$data remove storage evercraft:database exile.v$(vid).u$(uuid)
