# ============================================================
# Remove Village Exile
# Clears exile status and storage data
# Run as the player
# ============================================================

# Clear exile flag
scoreboard players set @s vs.exile 0

# Remove exile data from storage
execute store result storage eden:temp vs.vid int 1 run scoreboard players get @s ec.current_village
execute store result storage eden:temp vs.uuid int 1 run data get entity @s UUID[0]
function evercraft:village/exile/remove_lockout_macro with storage eden:temp vs

# Notify player
data modify storage evercraft:notify stage.c set value [{text:"Your exile has ended. You may once again interact with this village.",color:"green"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.villager.celebrate player @s ~ ~ ~ 1 1
particle minecraft:happy_villager ~ ~1 ~ 1 1 1 0.1 8

# Clean up temp
data remove storage eden:temp vs.exile_data
