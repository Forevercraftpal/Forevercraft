# ============================================================
# Upgrade Village to Legend Status
# Spawns iron golem guards and announces the upgrade
# Run positioned at the village marker
# ============================================================

# Spawn 2 iron golem guards at offset positions
execute positioned ~5 ~ ~3 run function evercraft:village/upgrades/spawn_guard
execute positioned ~-5 ~ ~-3 run function evercraft:village/upgrades/spawn_guard

# Visual effects at the village center
particle totem_of_undying ~ ~2 ~ 3 2 3 0.2 100
playsound minecraft:ui.toast.challenge_complete player @a[distance=..80,scores={ec.fx_snd=1..}] ~ ~ ~ 1 0.8
playsound minecraft:entity.iron_golem.repair player @a[distance=..80,scores={ec.fx_snd=1..}] ~ ~ ~ 1 1.2

# Announce to all players in range
data modify storage evercraft:notify stage.c set value [{text:"◆ ",color:"gold"},{text:"This village has been elevated to ",color:"gray"},{text:"Legend",color:"gold",bold:true},{text:" status!",color:"gray"},{text:" ◆",color:"gold"}]
scoreboard players set #ndur ec.temp 50
execute as @a[distance=..80] run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Iron Golem guardians now protect this settlement.",color:"yellow"}]
scoreboard players set #ndur ec.temp 40
execute as @a[distance=..80] run function evercraft:util/notify/emit
