# Upgrade Village Macro
# Stores the upgrade flag in persistent storage
$data modify storage evercraft:database village_upgraded.v$(vid) set value 1
