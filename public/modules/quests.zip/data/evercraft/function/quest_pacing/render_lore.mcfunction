# ============================================================
# Quest Pacing — Render Lore (deliver the beat's lore line + [Skip ▸] button)
# ============================================================
# Run as @s = the player. Called by each line's on_advance_notify (after the new
# beat loads) and overview (for the active beat). Delivers:
#   1. the beat's `lore` line  — gated `unless ec.qln_mute matches 1` (muted in
#      Quick Mode); a safe no-op if the beat has no `lore` field (legacy rows).
#   2. the law-compliant `[Skip ▸]` chat button — gated on the beat's `skippable`
#      field (see skip_button_macro); shown regardless of mute (the player can
#      always skip in Quick Mode — VOICE_CRIB §4).
#
# LINE-AGNOSTIC CALLING CONVENTION (so one shared file serves every line):
#   The caller copies the CURRENT beat object into the shared scratch storage
#   `evercraft:qp_cur o`, then calls this function, e.g.:
#       data modify storage evercraft:qp_cur o set from storage evercraft:cq_cur quest
#       function evercraft:quest_pacing/render_lore
#   (qp_cur is pacing-owned scratch; each line copies its own <line>_cur quest in,
#    so render_lore never needs to know the line's storage namespace.)
#
# This function READS ec.qln_mute but never writes it (apply_mute is the sole
# writer). Lines write none of pacing's objectives.

# === 1) LORE LINE (suppressed in Quick Mode; absent ⇒ no-op) ===
# Surface the lore field only when present, then macro-print it. Existence-gated
# twice: the beat must HAVE a lore field AND the player must NOT be muted.
execute unless score @s ec.qln_mute matches 1 if data storage evercraft:qp_cur o.lore run function evercraft:quest_pacing/render_lore_macro with storage evercraft:qp_cur o

# === 2) [Skip ▸] BUTTON (shown even when muted; gated on `skippable`) ===
function evercraft:quest_pacing/skip_button_macro with storage evercraft:qp_cur o
