# ============================================================
# Quest Pacing — Apply Narration Mute (sole writer of ec.qln_mute)
# ============================================================
# Run as @s = the player. Flips ec.qln_mute between 0 (Story ON — lore shown)
# and 1 (Quick Mode — lore muted), shows a confirm line, and re-renders.
#
# THE SOLE WRITER of ec.qln_mute. Called from:
#   - util/trigger_dispatch on ec.qln_tog (the Settings "Quest Narration" row's
#     [Toggle] chat button AND the login chronicle tellraw's [Quick Mode] link
#     both fire /trigger ec.qln_tog set 1).
#   - C1's Settings check_clicks (Adv.SetClick* path) MAY call this directly.
#
# Default narration mode = Story ON (Decision #6): an unset/0 player sees lore;
# the [Quick Mode] login link flips them to muted.
#
# Mirrors codex/hub/settings/toggle_auto_clm: snapshot prior -> flip atomically
# (avoids ping-pong) -> confirm tellraw -> re-render. Cooldown-guarded against
# click_event re-emission, like the auto-collect toggle.

# --- Cooldown guard (prevents double-fire from click_event re-emission) ---
# Gametime-stamped (QR-P4 pass 2026-06-10): the ec.qln_tog trigger fires from chat/login
# buttons ANYWHERE, and adv.gui_cd only decays inside the codex hub tick — stuck-at-4 outside
# it swallowed every later toggle/pin/skip click. ec.gq_cd is shared with do_skip /
# do_skip_chapter / set_track (module co-writers).
execute store result score #gqt_now ec.temp run time query gametime
execute if score @s ec.gq_cd > #gqt_now ec.temp run return 0
scoreboard players operation @s ec.gq_cd = #gqt_now ec.temp
scoreboard players add @s ec.gq_cd 4

# --- Snapshot prior state so the flip is atomic ---
scoreboard players operation #qln_prev ec.var = @s ec.qln_mute

# Prior MUTED (1) -> flip to Story ON (0)
execute if score #qln_prev ec.var matches 1 run scoreboard players set @s ec.qln_mute 0
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"aqua"},{text:"Quest Narration ",color:"white"},{text:"on",color:"green",bold:true},{text:" — the storytelling returns.",color:"gray"},{text:" ✦",color:"aqua"}]
scoreboard players set #ndur ec.temp 45
execute if score #qln_prev ec.var matches 1 run function evercraft:util/notify/emit

# Prior Story ON or unset (anything not 1) -> flip to Quick Mode (1, muted)
execute unless score #qln_prev ec.var matches 1 run scoreboard players set @s ec.qln_mute 1
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"aqua"},{text:"Quest Narration ",color:"white"},{text:"muted",color:"yellow",bold:true},{text:" — Quick Mode. Objectives only; the skip button still works.",color:"gray"},{text:" ✦",color:"aqua"}]
scoreboard players set #ndur ec.temp 45
execute unless score #qln_prev ec.var matches 1 run function evercraft:util/notify/emit

execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.hat master @s ~ ~ ~ 0.7 1.6
