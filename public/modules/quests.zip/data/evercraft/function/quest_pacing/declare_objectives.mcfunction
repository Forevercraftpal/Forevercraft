# ============================================================
# Quest Pacing — One-time scoreboard objective declaration
# Split from quest_pacing/load so the per-/reload "Objective already exists"
# warning only fires once (story/load/declare_objectives pattern, P6).
# Gated by `#qp_loaded ec.var matches 1` — set at the bottom of this file.
# ============================================================

# ec.qln_mute — 0/1 narration-mute flag (Quest Lore Narration). When 1, lore
#   lines are suppressed: interludes deliver silently (still auto-pass) and
#   objective beats render desc + the skip button only — never the lore line.
#   WRITER: quest_pacing/apply_mute ONLY (sole writer; one flag, one writer).
#   N1 LOCK: ec.qln_mute, NOT ec.lore_mute (ec.lore_* occupied by Ancient-Lore).
scoreboard objectives add ec.qln_mute dummy "Quest Lore Narration Muted"

# ec.gq_track — the [Skip ▸] tracker (Wiring #52). Holds the do_skip value-map SLOT of
#   the player's currently-tracked Chronicle line (Build=8 · Cooking=4 · Chemistry=6 ·
#   Forging=5 · Awakening=9 · Build&Conquer=7 · Tinkering=10; 0/unset = none tracked).
#   do_skip / do_skip_chapter read it; render_lore's [Skip ▸] button advances THAT line.
#   WRITERS: each line's <line>/start (auto-track on activate) + <line>/finish (clear if
#   it was pointed at the finished line). Latest-activated line wins for a veteran on
#   multiple active lines. (This is the round-1 "set_track" the C0 skeleton deferred.)
#   DECLARED by grand_quests/load (the canonical declarer); the duplicate add that
#   lived here was dropped (WA65-F4, 2026-06-22) — a re-add was a silent no-op.

# Mark declarations done so re-/reload skips this file.
scoreboard players set #qp_loaded ec.var 1
