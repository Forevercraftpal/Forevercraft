# ============================================================
# Quest Pacing — Render Lore (macro body)
# ============================================================
# Called `with storage evercraft:qp_cur o`, where o = the current beat object
# (the line copied its <line>_cur quest into qp_cur o). Only invoked by
# render_lore when o.lore EXISTS and the player is NOT muted, so $(lore) is
# always present here.
#
# Seven-voice register: gray-italic, in-world, unhurried — matches the Fisher
# intro tone (fishing/questline/start:27) and VOICE_CRIB §1. A leading quill
# glyph marks it as narration, distinct from the yellow ➤ objective line.
$tellraw @s [{text:"  ✒ ",color:"#C8A2C8"},{text:"$(lore)",color:"gray",italic:true}]
