# ============================================================
# Quest Pacing — Load (declare the narration-mute flag)
# ============================================================
# The shared, always-skippable, lore-mutable authoring layer EVERY Chronicle
# line rides (Build, Cooking, Chemistry, Forging, Adventure-A/B, Tinkering).
# This file declares the ONE pacing-owned persistent objective and is hosted
# off pack init (added to the init host alongside the other system loads).
#
# Declaration is guarded by #qp_loaded ec.var so subsequent /reloads skip the
# "Objective already exists" spam (story/load/declare_objectives polish, P6).
#
# N1 LOCK (council #2): the narration-mute flag is ec.qln_mute, NOT ec.lore_mute
# — ec.lore_* is OCCUPIED by ~30 Ancient-Lore collectible objectives. Using
# ec.lore_mute would sit one keystroke from a 30-objective family.
#
# The two pacing TRIGGER objectives (ec.qskip, ec.qln_tog) are NOT declared here
# — triggers are declared at init like the other player-trigger objectives so
# `scoreboard players enable` works server-wide; their gate/enable/reset triad
# lives in util/trigger_dispatch (added this wave, mirroring trigger_dispatch:5-7).

execute unless score #qp_loaded ec.var matches 1 run function evercraft:quest_pacing/declare_objectives
