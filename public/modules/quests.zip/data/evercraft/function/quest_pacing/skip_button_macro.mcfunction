# ============================================================
# Quest Pacing — Skip Button (emit the law-compliant [Skip ▸] chat button)
# ============================================================
# Run as @s = the player. Called by render_lore (and directly by any caller that
# copied a beat into `evercraft:qp_cur o`). Emits the [Skip ▸] button ONLY when
# the beat's `skippable` field is NOT 0:
#   - skippable absent or 1  -> SHOW the button (default — most beats).
#   - skippable:0            -> NO button (the tiny "see-it-once" teach set,
#                               Decision #5). The beat still AUTO-PASSES for a
#                               veteran via the line's lifetime threshold; only
#                               the one-click bypass button is withheld here.
#
# Named *_macro for naming consistency with the line's render pair, but it needs
# NO macro substitution: the button command is the STATIC, law-compliant
# /trigger affordance — the SAME shape as [⬆ Claim] in
# guild_cards/board_prompt_merchant:12 (a /trigger on a player-enabled objective,
# NOT a /function — immersion + Realms/non-op compatibility, no discoverability
# text). Clicking fires ec.qskip; util/trigger_dispatch routes it to do_skip,
# which advances the TRACKED line (ec.gq_track) at full reward.
#
# Existence/default logic: show the button UNLESS the beat explicitly carries
# skippable:0. `unless data ... {skippable:0}` is true for both "field absent"
# and "skippable:1", so the default-shown rule is one clean guard.

execute unless data storage evercraft:qp_cur o{skippable:0} run tellraw @s [{text:"  ",color:"gray"},{text:"[Skip ▸]",color:"#7FB3FF",bold:true,click_event:{action:"run_command",command:"/trigger ec.qskip set 1"},hover_event:{action:"show_text",value:{text:"Skip this beat — full reward, no penalty. The story moves on.",color:"gray"}}}]
