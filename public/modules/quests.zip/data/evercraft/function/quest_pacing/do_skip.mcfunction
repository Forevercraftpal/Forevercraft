# ============================================================
# Quest Pacing — Do Skip (player-initiated single-beat skip)
# ============================================================
# Run as @s = the player. Fired by the law-compliant [Skip ▸] chat button
# (/trigger ec.qskip set 1 -> util/trigger_dispatch routes here). Reads the
# player's TRACKED line (ec.gq_track, round-1's tracker objective) and fans out
# to THAT line's own public `advance` — full reward, forward cursor, never
# double-pays (mechanically identical to a satisfied beat; the forward cursor
# blocks retro-backfill). Round-1 R1 no-penalty law preserved.
#
# Skip = player-initiated auto-satisfy. This dispatcher writes NO line pointer —
# each pointer stays written ONLY inside that line's own `advance` (one-writer
# law intact, P4). Each fan-out line is gated `if ec.<line>_active matches 1`, so
# it is a safe no-op when that line is inactive or the player isn't on it.
#
# ─────────────────────────────────────────────────────────────────────────────
# EXTENSION CONTRACT (each line's wave ADDS its own case here — do NOT pre-wire
# unbuilt lines, since `function` to a missing path is a load-time error):
#
#   When a line ships, append ONE line below in its ec.gq_track slot, e.g.:
#     execute if score @s ec.gq_track matches <V> if score @s ec.<line>_active matches 1 \
#       run function evercraft:<line>/advance
#
#   ec.gq_track value map (SYNTHESIS §6b — one value per LINE, not per chapter):
#     Build=ec.bq_done · Fishing=ec.fq_done · Cooking=ec.cq_done · Chemistry=ec.chq_done
#     Forging=ec.fgq_done · Adventure-A=ec.ac_done · Adventure-B=ec.ak_done · Tinkering=ec.tnk_done
#   (picked slots until set_track pins them: Build=8 · Cooking=4 · Chemistry=6 · Forging=5 ·
#    Awakening=9 · B&C=7 · Tinkering=10)
#   (the exact integer per line is owned by round-1's set_track writer; each line
#    wave knows its own slot when it ships and adds the matching case here.)
#
# C0 ships the dispatcher SKELETON only: no line is built yet (round-1 unbuilt),
# so there are zero fan-out cases. The first adopter (round-1 Build engine) adds
# its case the moment build_quests/advance exists. Until then this is a safe
# no-op (the player still gets the acknowledgement below).
# ─────────────────────────────────────────────────────────────────────────────

# --- Cooldown guard (prevents double-fire from click_event re-emission) ---
# Gametime-stamped (QR-P4 pass 2026-06-10): the old adv.gui_cd guard only decays inside the
# codex hub tick, but the chat [Skip ▸] button fires ANYWHERE — outside the codex the 4 never
# ticked down, so the FIRST skip swallowed every later skip/pin click until a codex open+close.
# ec.gq_cd = gametime until which clicks are ignored (shared with set_track, module co-writer).
execute store result score #gqt_now ec.temp run time query gametime
execute if score @s ec.gq_cd > #gqt_now ec.temp run return 0
scoreboard players operation @s ec.gq_cd = #gqt_now ec.temp
scoreboard players add @s ec.gq_cd 4

# --- No tracked line? Open the pin menu right here (W1 2026-06-10: set_track is BUILT —
#     the old "go pin from the hub" dead-end ack is replaced by the actual pin list). ---
execute unless score @s ec.gq_track matches 1.. run return run function evercraft:grand_quests/pin_menu

# === FAN-OUT (one gated case per built line — appended by each line's wave) ===
# Build Quests (Wave F1, the first adopter). ec.gq_track slot 8 = the Build line
# (SYNTHESIS §2 category #8). Gated `if ec.bq_active matches 1` so it is a safe
# no-op when the player isn't on the Build line. Calls the PUBLIC build_quests/
# advance = a satisfied-beat advance: full reward, forward cursor, no double-pay.
execute if score @s ec.gq_track matches 8 if score @s ec.bq_active matches 1 run function evercraft:build_quests/advance

# Cook's Questline (Wave C3, the FIRST content slice). ec.gq_track slot 4 = the
# Cooking line (SYNTHESIS §2 category #4). Gated `if ec.cq_active matches 1` so it
# is a safe no-op when the player isn't on the Cooking line. Calls the PUBLIC
# cooking/questline/advance = a satisfied-beat advance: full reward, forward cursor,
# no double-pay.
execute if score @s ec.gq_track matches 4 if score @s ec.cq_active matches 1 run function evercraft:cooking/questline/advance

# Chemist's Questline (Wave C4). ec.gq_track slot 6 = the Chemistry line (aligned to
# the cat-6 Alchemy add_xp category; distinct from Build 8 / Cooking 4 / the tracker
# set {1,2,3,8}). Gated `if ec.chq_active matches 1` so it is a safe no-op when the
# player isn't on the Chemistry line. Calls the PUBLIC alchemy/questline/advance =
# a satisfied-beat advance: full reward, forward cursor, no double-pay.
execute if score @s ec.gq_track matches 6 if score @s ec.chq_active matches 1 run function evercraft:alchemy/questline/advance

# Smith's Questline (Wave C4). ec.gq_track slot 5 = the Forging line (aligned to the
# cat-5 Forging add_xp category). Gated `if ec.fgq_active matches 1` so it is a safe
# no-op when the player isn't on the Forging line. Calls the PUBLIC
# forging/questline/advance = a satisfied-beat advance: full reward, forward cursor,
# no double-pay.
execute if score @s ec.gq_track matches 5 if score @s ec.fgq_active matches 1 run function evercraft:forging/questline/advance

# The Awakening / Adventure-A (Wave C5, the FIRST Adventurer line). ec.gq_track slot
# 9 = the Awakening line (the next free integer after Build 8 / Cooking 4 / Chemistry
# 6 / Forging 5 and the round-1 tracker set {1,2,3,8}; round-1's set_track writer owns
# the final integer — until then slot 9 is this line's pick). Gated `if ec.ac_active
# matches 1` so it is a safe no-op when the player isn't on The Awakening line. Calls
# the PUBLIC adventure/questline/advance = a satisfied-beat advance: full reward,
# forward cursor, no double-pay. (Gate is `matches 1` exactly — a value-2 player is
# DONE; a completed line should never accept a skip.)
execute if score @s ec.gq_track matches 9 if score @s ec.ac_active matches 1 run function evercraft:adventure/questline/advance

# Build & Conquer / Adventure-B (Wave C6, the SECOND Adventurer line). ec.gq_track slot
# 7 = the kingdom line (the next free integer — Build 8 / Cooking 4 / Chemistry 6 /
# Forging 5 / Awakening 9 and the round-1 tracker set {1,2,3,8} leave 7 free; round-1's
# set_track writer owns the final integer — until then slot 7 is this line's pick).
# Gated `if ec.ak_active matches 1` so it is a safe no-op when the player isn't on Build
# & Conquer. Calls the PUBLIC adventure/kingdom/advance = a satisfied-beat advance: full
# reward, forward cursor, no double-pay. (Gate is `matches 1` exactly — a value-2 player
# is DONE; a completed line should never accept a skip.)
execute if score @s ec.gq_track matches 7 if score @s ec.ak_active matches 1 run function evercraft:adventure/kingdom/advance

# Tinkering / the universal mini-line (Wave C7). ec.gq_track slot 10 = the Tinkering line
# (the next free integer — Build 8 / Cooking 4 / Chemistry 6 / Forging 5 / Awakening 9 / B&C 7
# and the round-1 tracker set {1,2,3,8} leave 10 free; round-1's set_track writer owns the
# final integer — until then slot 10 is this line's pick). Gated `if ec.tnk_active matches 1`
# so it is a safe no-op when the player isn't on Tinkering. Calls the PUBLIC tinkering/advance
# = a satisfied-beat advance: full reward, forward cursor, no double-pay. (Gate is `matches 1`
# exactly — a value-2 player is DONE; a completed line should never accept a skip.)
execute if score @s ec.gq_track matches 10 if score @s ec.tnk_active matches 1 run function evercraft:tinkering/advance

# The Grand Chronicle (Questline Restructure W2). ec.gq_track slot 11 = the convergence
# line. Gated `if ec.gch_active matches 1` (2 = done). Calls the PUBLIC grand_quests/
# advance = a satisfied-beat advance: full reward, forward cursor, no double-pay.
execute if score @s ec.gq_track matches 11 if score @s ec.gch_active matches 1 run function evercraft:grand_quests/advance

# Acknowledge the click (sound only; the called line's advance shows the beat).
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.hat master @s ~ ~ ~ 0.6 1.9
