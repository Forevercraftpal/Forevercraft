# ============================================================
# Quest Pacing — Do Skip Chapter (bulk-skip to the next chapter boundary)
# ============================================================
# Run as @s = the player. Fired by the Settings "Skip Chapter" row (C1 wires the
# Adv.SetClickSkipCh click here). Advances the player's TRACKED line (ec.gq_track)
# beat-by-beat until the current beat's `chapter` field changes — i.e. skips the
# REST of the current chapter at full reward per beat (each advance pays its own
# reward + moves the forward cursor; never double-pays — round-1 R1 preserved).
#
# Implemented as a bounded fan-out to a per-line `skip_chapter` helper (NOT raw
# `advance` in a loop here) so the chapter-boundary read stays inside the line's
# own engine (it owns its registry + cursor). The dispatcher writes NO pointer.
#
# ─────────────────────────────────────────────────────────────────────────────
# EXTENSION CONTRACT (each line's wave ADDS its case + ships a `skip_chapter`
# helper in its own folder — do NOT pre-wire unbuilt lines):
#
#   Per-line `<line>/skip_chapter` (the line author writes this, cloned across
#   lines) does, run as @s:
#     1. snapshot the current beat's chapter:  data get <line>_cur quest.chapter -> #qp_ch0 ec.temp
#     2. call <line>/advance once (pays reward, loads the next beat)
#     3. re-read the new beat's chapter; if it still == #qp_ch0 AND the line is
#        not complete, recurse (function evercraft:<line>/skip_chapter) — a
#        bounded self-loop that stops at the chapter boundary or line end.
#   This keeps the registry read + cursor write inside the line (one-writer law).
#
#   Then append ONE case here in the line's ec.gq_track slot:
#     execute if score @s ec.gq_track matches <V> if score @s ec.<line>_active matches 1 \
#       run function evercraft:<line>/skip_chapter
#
# C0 ships the dispatcher SKELETON only (round-1/round-2 lines unbuilt). The
# first adopter adds its case + skip_chapter helper when its engine exists.
# ─────────────────────────────────────────────────────────────────────────────

# --- Cooldown guard (prevents double-fire from click_event re-emission) ---
# Gametime-stamped (QR-P4 pass 2026-06-10): adv.gui_cd only decays inside the codex hub tick —
# stuck-at-4 outside it swallowed every later quest-button click. ec.gq_cd is shared with
# do_skip / set_track / apply_mute (module co-writers).
execute store result score #gqt_now ec.temp run time query gametime
execute if score @s ec.gq_cd > #gqt_now ec.temp run return 0
scoreboard players operation @s ec.gq_cd = #gqt_now ec.temp
scoreboard players add @s ec.gq_cd 4

# --- No tracked line? Open the pin menu right here (W1 2026-06-10: set_track is BUILT). ---
execute unless score @s ec.gq_track matches 1.. run return run function evercraft:grand_quests/pin_menu

# === FAN-OUT (QR-P1 BUILT 2026-06-10 — one gated case per line via the SHARED
#     skip_chapter_start macro pair; Fisher slot 1 excluded, catches can't be granted) ===
execute if score @s ec.gq_track matches 4 if score @s ec.cq_active matches 1 run function evercraft:quest_pacing/skip_chapter_start {get:"cooking/questline/get_quest",adv:"cooking/questline/advance",cur:"cq_cur",act:"ec.cq_active",comp:"ec.cq_complete"}
execute if score @s ec.gq_track matches 5 if score @s ec.fgq_active matches 1 run function evercraft:quest_pacing/skip_chapter_start {get:"forging/questline/get_quest",adv:"forging/questline/advance",cur:"fgq_cur",act:"ec.fgq_active",comp:"ec.fgq_complete"}
execute if score @s ec.gq_track matches 6 if score @s ec.chq_active matches 1 run function evercraft:quest_pacing/skip_chapter_start {get:"alchemy/questline/get_quest",adv:"alchemy/questline/advance",cur:"chq_cur",act:"ec.chq_active",comp:"ec.chq_complete"}
execute if score @s ec.gq_track matches 7 if score @s ec.ak_active matches 1 run function evercraft:quest_pacing/skip_chapter_start {get:"adventure/kingdom/get_quest",adv:"adventure/kingdom/advance",cur:"ak_cur",act:"ec.ak_active",comp:"ec.ak_complete"}
execute if score @s ec.gq_track matches 8 if score @s ec.bq_active matches 1 run function evercraft:quest_pacing/skip_chapter_start {get:"build_quests/get_quest",adv:"build_quests/advance",cur:"bq_cur",act:"ec.bq_active",comp:"ec.bq_complete"}
execute if score @s ec.gq_track matches 9 if score @s ec.ac_active matches 1 run function evercraft:quest_pacing/skip_chapter_start {get:"adventure/questline/get_quest",adv:"adventure/questline/advance",cur:"ac_cur",act:"ec.ac_active",comp:"ec.ac_complete"}
execute if score @s ec.gq_track matches 10 if score @s ec.tnk_active matches 1 run function evercraft:quest_pacing/skip_chapter_start {get:"tinkering/get_quest",adv:"tinkering/advance",cur:"tnk_cur",act:"ec.tnk_active",comp:"ec.tnk_complete"}
execute if score @s ec.gq_track matches 11 if score @s ec.gch_active matches 1 run function evercraft:quest_pacing/skip_chapter_start {get:"grand_quests/get_quest",adv:"grand_quests/advance",cur:"gch_cur",act:"ec.gch_active",comp:"ec.gch_complete"}

execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.hat master @s ~ ~ ~ 0.6 1.9
