# ============================================================
# Quest Pacing — Skip Chapter, shared starter (QR-P1, Joseph verdict 2026-06-10)
# ============================================================
# ONE generic macro pair serves every line (no 8× per-line clones). Run as @s from a
# do_skip_chapter fan-out case. Macro args (per line):
#   get  — the line's get_quest fn path under evercraft: (loads <cur>.quest)
#   adv  — the line's PUBLIC advance fn path (satisfied-beat advance, full reward)
#   cur  — the line's cur storage namespace (e.g. "bq_cur")
#   act  — the line's active objective (e.g. "ec.bq_active")
#   comp — the line's complete objective
# Semantics: record the CURRENT chapter, then advance (full reward per beat — identical
# to mashing [Skip ▸]) until the chapter number changes, the line completes, or the
# 30-beat safety cap trips. Forward cursor + per-beat one-shot guards in each line's
# advance make this double-pay-proof.
$function evercraft:$(get)
$execute store result score #skc_ch ec.temp run data get storage evercraft:$(cur) quest.chapter
scoreboard players set #skc_iter ec.temp 0
$function evercraft:quest_pacing/skip_chapter_loop {get:"$(get)",adv:"$(adv)",cur:"$(cur)",act:"$(act)",comp:"$(comp)"}
