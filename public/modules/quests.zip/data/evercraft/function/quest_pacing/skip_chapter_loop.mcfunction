# Quest Pacing — Skip Chapter, shared loop body (see skip_chapter_start). Run as @s.
# Recursive macro: advance once, re-read the chapter, recurse while unchanged.
# Exits: line inactive / complete / chapter changed / 30-beat safety cap.
$execute unless score @s $(act) matches 1 run return 0
$execute if score @s $(comp) matches 1 run return 0
scoreboard players add #skc_iter ec.temp 1
execute if score #skc_iter ec.temp matches 30.. run return 0
$function evercraft:$(adv)
$execute unless score @s $(act) matches 1 run return 0
$execute if score @s $(comp) matches 1 run return 0
$function evercraft:$(get)
$execute store result score #skc_now ec.temp run data get storage evercraft:$(cur) quest.chapter
$execute if score #skc_now ec.temp = #skc_ch ec.temp run function evercraft:quest_pacing/skip_chapter_loop {get:"$(get)",adv:"$(adv)",cur:"$(cur)",act:"$(act)",comp:"$(comp)"}
