# Bounty Reward — Party Share (50% of base rewards)
# Run as nearby party member (not the bounty killer)

# Flat party share: 4 emeralds + 75 XP + 100 Rep
give @s emerald 4
experience add @s 75 points
scoreboard players add @s ec.village_rep 100

data modify storage evercraft:notify stage.c set value [{text:"Your ally completed a bounty! ",color:"gold"},{text:"+4 emeralds, +75 XP, +100 rep",color:"yellow"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.experience_orb.pickup player @s ~ ~ ~ 0.8 1.2
