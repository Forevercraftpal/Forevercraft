# Bounty Reward — Commission (T4): Ornate Crate + 350 Rep
# Inv-full guard: drop at the player's feet rather than void on a full inventory.
execute store result score #inv_full ec.var run function evercraft:util/check_inv_full
execute if score #inv_full ec.var matches 0 run loot give @s loot evercraft:achievements/crates/ornate
execute if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:achievements/crates/ornate
experience add @s 250 points

# Reputation
scoreboard players add @s ec.village_rep 350
data modify storage evercraft:notify stage.c set value [{text:"Bounty Reward: ",color:"gold"},{text:"Ornate Crate",color:"light_purple"},{text:" + ",color:"gray"},{text:"250 XP",color:"green"},{text:" + ",color:"gray"},{text:"350 Rep",color:"aqua"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit

# Guild Expedition: Bounty bonus XP (activity=8)
function evercraft:guild/expedition/bonus_xp {base:250,activity:8}

# Class Affinity XP — bounty complete
scoreboard players set #delta ec.temp 30000
function evercraft:affinity/grant_current
