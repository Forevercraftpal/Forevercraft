# Bounty — Display directional hint with biome flavor
# Macro: flavor (biome description), direction (cardinal/intercardinal or "nearby")

$data modify storage evercraft:notify stage.c set value [{text:"You hear $(flavor) from $(direction), make haste before it's too late!",color:"yellow",italic:true}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
