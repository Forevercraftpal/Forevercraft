# Bounty — Display actionbar with distance (macro)
$execute unless entity @s[tag=ab_q] run title @s actionbar [{text:"Bounty Target: ",color:"red"},{text:"$(dist) blocks",color:"gold"}]
