# Bounty — Cancel active bounty (player command)
# Run as player

data modify storage evercraft:notify stage.c set value [{text:"You don't have an active bounty.",color:"gray"}]
scoreboard players set #ndur ec.temp 45
execute unless score @s ec.bnt_tier matches 1.. run function evercraft:util/notify/emit
execute unless score @s ec.bnt_tier matches 1.. run return 0

# Kill only this player's bounty target (per-player owner tracking)
scoreboard players operation #bnt_check ec.var = @s ec.bnt_owner
execute as @e[tag=ec.bounty_target] if score @s ec.bnt_owner = #bnt_check ec.var run kill @s

# Clear state
scoreboard players set @s ec.bnt_tier 0
scoreboard players set @s ec.bnt_biome -1
scoreboard players set @s ec.bnt_timer 0
scoreboard players set @s ec.bnt_spawned 0
scoreboard players set @s ec.bnt_owner 0

data modify storage evercraft:notify stage.c set value [{text:"Bounty cancelled.",color:"gray"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
