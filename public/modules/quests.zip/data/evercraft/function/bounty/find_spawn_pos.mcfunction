# Bounty — Find valid spawn position 30-50 blocks from player
# Run as player at player

# Use spreadplayers on a marker to find safe surface position
summon marker ~ ~ ~ {Tags:["bnt_spawn_check"]}
execute as @e[type=marker,tag=bnt_spawn_check,limit=1] at @s run spreadplayers ~ ~ 30 50 false @s

# Spawn patron at marker location
execute at @e[type=marker,tag=bnt_spawn_check,limit=1] run function evercraft:bounty/spawn_patron

# Cleanup marker
kill @e[type=marker,tag=bnt_spawn_check]

# Mark as spawned
scoreboard players set @s ec.bnt_spawned 1

# Announce
data modify storage evercraft:notify stage.c set value [{text:"Your bounty target has appeared!",color:"red"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.wither.spawn hostile @s ~ ~ ~ 0.3 1.5
