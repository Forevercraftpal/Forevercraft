# Bounty — Display pre-spawn actionbar
# Shows biome target before patron has spawned
execute unless entity @s[tag=ab_q] run title @s actionbar [{text:"Bounty: ",color:"red"},{text:"Travel to target biome to summon patron",color:"gray"}]
