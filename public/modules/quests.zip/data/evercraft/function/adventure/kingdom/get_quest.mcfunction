# ============================================================
# Build & Conquer (Adventure-B) — Load the current quest object into ak_cur
# ============================================================
# Reads the current quest (by linear pointer ec.ak_quest) out of the registry list
# and writes it to storage evercraft:ak_cur quest, so check/advance/reward can read
# quest.type/target/count/reward/reward_amt without per-quest files.
#
# The registry list is 0-indexed; ec.ak_quest is 1-based. This wrapper computes
# idx = ec.ak_quest - 1, stuffs it into storage, and calls the macro.
# Run as @s = the player.

# Compute 0-based list index from the 1-based linear pointer.
execute store result score #ak_idx ec.temp run scoreboard players get @s ec.ak_quest
scoreboard players remove #ak_idx ec.temp 1
execute store result storage evercraft:ak_cur idx int 1 run scoreboard players get #ak_idx ec.temp

# Macro-copy the quest object at that index into ak_cur.quest.
function evercraft:adventure/kingdom/get_quest_macro with storage evercraft:ak_cur
