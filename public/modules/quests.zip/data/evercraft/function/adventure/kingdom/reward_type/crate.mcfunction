# AK reward — crate (a reward crate of a given tier). @s = player.
# quest.target names the tier; the table is the EXISTING shared crate table at
# evercraft:fishing/gameplay/fishing/crates/<tier>/1 (tiers that exist: common,
# uncommon, rare, ornate, exquisite, mythical) — reused so Build & Conquer ships
# without authoring a parallel crate-table tree (an Adventure-themed table can swap in
# later with zero engine change). Inv-full aware (prospect/complete_mine pattern).
# Macro body — the loot lines read $(target).
execute store result score #ak_inv_full ec.var run function evercraft:util/check_inv_full
$execute if score #ak_inv_full ec.var matches 0 run loot give @s loot evercraft:fishing/gameplay/fishing/crates/$(target)/1
$execute if score #ak_inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:fishing/gameplay/fishing/crates/$(target)/1
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"yellow"},{text:"Reward: a reward crate!",color:"yellow"},{text:" ✦",color:"yellow"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Inventory full! Your crate was dropped at your feet.",color:"yellow"}]
scoreboard players set #ndur ec.temp 45
execute if score #ak_inv_full ec.var matches 1 run function evercraft:util/notify/emit
execute if score #ak_inv_full ec.var matches 1 if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bass player @s ~ ~ ~ 1 0.5
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.experience_orb.pickup master @s ~ ~ ~ 0.6 1.0
