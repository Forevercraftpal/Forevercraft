# Run as operator (testing). Temp entry to hand yourself the King's Codex + start
# Build & Conquer before the canonical entries (the soft guild-creation offer and the
# Adventurer Tier-2 row) are exercised.
# Usage: /execute as <player> run function evercraft:adventure/kingdom/admin/give_book_temp
# (debug) — starts the line if not already active (start gives the book, dup-guarded).
execute unless score @s ec.ak_active matches 1.. run function evercraft:adventure/kingdom/start
# If already on the line, just (re)hand the book in case it was lost.
execute if score @s ec.ak_active matches 1.. run function evercraft:adventure/kingdom/book/give
