# ============================================================
# Build & Conquer (Adventure-B) — Load (objective declarations + registry + schedule)
# ============================================================
# A strictly-linear, data-driven quest line (q1..N in order, one active quest at a
# time), structural clone of adventure/questline/load (C5). Called from init (the
# pack load host) on /reload — see init.mcfunction "BUILD & CONQUER (ADVENTURE-B)"
# block.
#
# This is the SECOND Adventurer chronicle line (Council #2 Wave C6): three guided
# chapters — forge a glyph + home totem (chapter 1), run a little kingdom (guild +
# laborers, chapter 2), and the one-ladder build-and-conquer escalation (chapter 3,
# S7). It is a Fisher's clone that only READS public state (ach.runes_forged,
# hs.totems/hs.in_zone, ec.guild_id/ec.guild_rank, ec.lb_count, ach.dungeons_done,
# ach.boss_kills/ach.boss_unique, ach.crates_structure/ach.crates_opened,
# ec.cf_axp_build) and WRITES none of those engines' objectives — the no-write proof.
#
# SEQUENCING (S9): the soft "[Begin Build & Conquer ->]" offer (guild/announce_create's
# +1 gated line) fires ONLY after Adventure-A completes (ec.ac_active matches 2), so
# this line is never offered before The Awakening is done. The Adventurer Tier-2 row
# is the always-available fallback once the lens is Adventurer/Both: it renders a
# clickable [Begin →] START row (WA63-D1, Adv.GqStart10 -> kingdom/start) whenever the
# line is not yet begun and Adventure-A is complete, so a player who joined/founded a
# guild before finishing The Awakening is never locked out. A belt-and-suspenders
# re-offer also fires from questline/finish for a guild-holder.
#
# NAMESPACE LOCK (Council #2): distinct from ec.ac_* (Adventure-A), ec.ag_*
# (Adventurer Card), ec.guild_* (guild engine — read-only here). This line uses the
# council-locked ec.ak_* family ONLY (Adventure-B / kingdom). It adds ZERO new
# ec.quest board triggers (K10).
#
# Declarations are guarded by #ak_loaded ec.var so subsequent /reloads skip the
# re-declaration spam, matching the C5 line's polish.
#
# After declaring objectives, this fn ALWAYS (re)loads the registry (the quest data
# storage is NOT persisted across /reload) and (re)kicks the 20t catch-up scheduler
# with `replace` (so /reload never stacks duplicate schedules).

# === ONE-TIME OBJECTIVE DECLARATIONS (skipped on subsequent /reloads) ===
execute unless score #ak_loaded ec.var matches 1 run function evercraft:adventure/kingdom/declare_objectives

# === REGISTRY (re)load — storage is volatile across /reload, must re-run ===
function evercraft:adventure/kingdom/registry/load

# === 20t CATCH-UP / INTERLUDE SCHEDULER (self-rescheduling, existence-gated) ===
# check_progress only does work for @a[scores={ec.ak_active=1}] — no per-tick @a
# scan when nobody is on the line. It re-schedules itself; kick once here.
schedule function evercraft:adventure/kingdom/check_progress 20t replace
