# ============================================================
# Build & Conquer (Adventure-B) — Give the King's Codex book (dup-guarded)
# ============================================================
# Run as @s = the player. Gives a single "King's Codex" book item — a minecraft:book
# carrying custom_data{kingdom_book:true} so the using_item advancement
# (advancement/kingdom_questline/on_use.json) detects a right-click and opens the
# Build & Conquer overview. Clone of the Adventurer's Codex item shape (C5):
# consumable{consume_seconds:999999} = right-click "uses" without consuming;
# use_cooldown prevents spam.
#
# DUP-GUARD: only give if the player does NOT already hold one (anywhere in the
# inventory). Called from adventure/kingdom/start — so a player who already has the
# book and re-triggers start (the start dup-guard should prevent it, but defensive)
# never stacks a second copy. Re-give on loss is handled by the temp admin entry / a
# future Tier-2 affordance.
execute if items entity @s container.* minecraft:book[custom_data~{kingdom_book:true}] run return 0
execute if items entity @s weapon.* minecraft:book[custom_data~{kingdom_book:true}] run return 0

# Give the King's Codex (direct give — self-contained, no parallel loot tree).
give @s minecraft:book[minecraft:custom_name={text:"The King's Codex",color:"gold",italic:false},minecraft:lore=[{text:"Build & Conquer",color:"#FFAA00",italic:false},"",{text:"Right-click",color:"yellow",italic:false,extra:[{text:" to open your Conquest path",color:"gray"}]}],minecraft:custom_data={kingdom_book:true,evercraft_item:true},minecraft:consumable={consume_seconds:999999,animation:"brush",sound:"intentionally_empty",has_consume_particles:false},minecraft:use_cooldown={seconds:1,cooldown_group:"evercraft:kingdom_book"},minecraft:max_stack_size=1,minecraft:rarity="rare",minecraft:enchantment_glint_override=false] 1

data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"You received ",color:"gray"},{text:"The King's Codex",color:"gold",bold:true},{text:" — right-click to open your Conquest path.",color:"gray"},{text:" ✦",color:"gold"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:item.book.page_turn master @s ~ ~ ~ 0.8 1.1
