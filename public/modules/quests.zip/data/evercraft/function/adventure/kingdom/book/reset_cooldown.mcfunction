# The King's Codex — Reset cooldown (runs ~1s after a right-click use).
# Revokes the using_item advancement so the book can be used again. Clone of
# adventure/questline/book/reset_cooldown (C5).
execute as @a[tag=ec.kingbook_cd] run advancement revoke @s only evercraft:kingdom_questline/on_use
tag @a[tag=ec.kingbook_cd] remove ec.kingbook_cd
