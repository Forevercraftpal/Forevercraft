# ============================================================
# Build & Conquer (Adventure-B) — One-time scoreboard objective declarations.
# (Structural clone of adventure/questline/declare_objectives, Council #2 Wave C6 —
#  the SECOND Adventurer chronicle line.) Split from adventure/kingdom/load so the
#  per-/reload "Objective already exists" warnings only fire once. Gated by
#  `#ak_loaded ec.var matches 1` — set at the bottom of this file.
# ============================================================
# A paced, always-skippable kingdom line: a sibling Fisher's clone that only READS
# public state (ach.runes_forged for chapter 1 glyph-forging; hs.totems/hs.in_zone
# for the home totem; ec.guild_id/ec.guild_rank + ec.lb_count for chapter 2's
# kingdom; ach.dungeons_done + ach.boss_kills/ach.boss_unique + ach.crates_structure/
# ach.crates_opened for chapter 3's escalation ladder). It WRITES none of those
# engines' objectives — the no-write proof. It is pacing-aware from the start
# (lore/beat/skippable) — see check.mcfunction (interlude guard), on_advance_notify +
# overview (render_lore), and the registry rows that carry `lore`.
#
# NOTE: ec.ac_* is OCCUPIED by Adventure-A; ec.ag_* is the Adventurer Card; the guild
# engine owns ec.guild_*; the laborer engine owns ec.lb_*. This line reads all of
# them but uses the council-locked ec.ak_* family ONLY for its OWN pointers.

# === CORE LINEAR-POINTER SCOREBOARDS (mirror ec.ac_*; one writer each) ===
# ec.ak_active — 0/1/2, has this player started Build & Conquer?
#   WRITER: adventure/kingdom/start (sets 1). The completion path sets it to 2 (via
#   finish) so a future sequenced line could detect "Adventure-B complete" — but
#   every gate in THIS line treats it as "1.. = active". (start sets 1; finish bumps
#   to 2 on the final quest.)
scoreboard objectives add ec.ak_active dummy "Build&Conquer Active"
# ec.ak_quest — current quest index, 1..N. The ONLY linear pointer.
#   WRITER: adventure/kingdom/start (sets 1) + adventure/kingdom/advance (+1, clamped at N).
scoreboard objectives add ec.ak_quest dummy "Build&Conquer Quest Idx"
# ec.ak_prog — progress within the current quest, surfaced ONLY in the overview
#   progress bar. The kingdom check types are all READ-DERIVED (they compute their
#   satisfied condition from a public mirror + the ec.ak_seen cursor into ec.temp,
#   never persisting a per-deed tally), so the single persistent writer of ak_prog
#   is the reset path — keeping it strictly one-writer.
#   WRITER (reset to 0): adventure/kingdom/start + adventure/kingdom/advance.
#   WRITER (live mirror for the bar): adventure/kingdom/check_progress re-syncs it to
#     the present-beat conquest delta (one writer, on the 20t loop).
scoreboard objectives add ec.ak_prog dummy "Build&Conquer Progress"
# ec.ak_done — lifetime completed quest count (overview + the ec.gq_track value).
#   WRITER: adventure/kingdom/advance (+1) + adventure/kingdom/start (sets 0 on first start).
scoreboard objectives add ec.ak_done dummy "Build&Conquer Done"
# (NO ec.ak_title — per the wave spec (K4) the kingdom line rewards only xp/coins/
#  crate. Adventurer identity comes from the Reaper alignment + the Adventurer Card;
#  no reward_type/title file exists in this engine.)

# === COMPLETION SENTINEL ===
# ec.ak_complete — 0/1, set once when the player finishes the final quest so the
#   "line complete!" tellraw fires exactly once. WRITER: adventure/kingdom/advance
#   (via finish) + adventure/kingdom/start (sets 0 on first start).
scoreboard objectives add ec.ak_complete dummy "Build&Conquer Complete"

# === LIFETIME-THRESHOLD CATCH-UP CURSOR (forward-only, no-penalty) ===
# ec.ak_seen — snapshot of the two chapter-3 forward counters (conquest progress)
#   taken at start AND re-snapshotted at chapter-3 entry by adventure/kingdom/start's
#   chapter-3 cursor (S8: no lifetime raid/blueprint counter exists, so the forward
#   cursor + ec.cf_axp_build veteran catch-up cover it). The present-action conquest
#   beats read (ach.dungeons_done + ach.boss_kills - this) as deeds SINCE the line/
#   chapter began, so pre-activation conquest never retro-credits the present beat
#   (forward cursor). The catch-up TYPES (block_present / lifetime_at / guild_member /
#   conquest_any high thresholds) read their lifetime mirror DIRECTLY, so a veteran
#   auto-passes at full reward. WRITER: adventure/kingdom/start (seeds it) +
#   adventure/kingdom/check_progress (re-syncs the live ec.ak_prog delta).
scoreboard objectives add ec.ak_seen dummy "AK Conquest Cursor"

# === ONE-SHOT SOFT-OFFER LATCH (sole writer: guild/announce_create's +1 gated line) ===
# ec.ak_offer — 0/1, set to 1 the first time the soft "[Begin Build & Conquer ->]"
#   auto-offer fires on a guild creation (S9), so it never re-fires. The offer is
#   gated ec.chron_view matches 1/3 + ec.ak_active matches 0 + ec.ac_active matches 2
#   (sequenced AFTER Adventure-A). The button itself calls adventure/kingdom/start.
#   WRITER: guild/announce_create (the +1 gated line — sole writer; the strip-reset is
#   the documented exception, like ec.ac_offer / ec.gq_offered).
scoreboard objectives add ec.ak_offer dummy "Build&Conquer Offer Latch"

# Mark declarations done so re-/reload skips this file.
scoreboard players set #ak_loaded ec.var 1
