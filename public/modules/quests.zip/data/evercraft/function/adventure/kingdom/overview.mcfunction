# ============================================================
# Build & Conquer (Adventure-B) — Overview page ("Build & Conquer" tab)
# ============================================================
# A clean tellraw page reached from the Grand Quests Adventurer Tier-2 row (C1/C6) and
# from a right-click on the King's Codex book (book/on_use). Shows the player's current
# quest (title + desc + progress), lifetime completed count, and the active beat's lore
# + [Skip ▸] via render_lore. GUI/interaction-only; no /trigger. Run as @s = the player.
#
# Data-driven fields (current quest title / desc / count) live in the registry, so the
# variable lines go through overview_macro (mirrors show_objective split). Score-driven
# lines (progress, done, the glyph/kingdom/conquest tallies) stay here.
#
# NOTE: ec.ak_active == 2 means the line is COMPLETE (finish() bumped it); the
# completion block keys off ec.ak_complete, which is set in lockstep. "Active" copy uses
# `ec.ak_active matches 1` (NOT 1..) so a value-2 player sees the celebration, not the
# current-quest panel.

# Frame header.
tellraw @s ""
tellraw @s [{text:"═══════════════════════════════",color:"gold"}]
tellraw @s [{text:"  ⚔ ",color:"gold"},{text:"Build & Conquer",color:"gold",bold:true},{text:" ⚔",color:"gold"}]
tellraw @s [{text:"  Glyphs • Kingdom • Conquest",color:"gray",italic:true}]
tellraw @s [{text:"═══════════════════════════════",color:"gold"}]
tellraw @s ""

# === Not yet started: prompt to begin (offer or menu). ===
execute unless score @s ec.ak_active matches 1.. run tellraw @s [{text:"  ✦ ",color:"yellow"},{text:"Your hold has not yet risen.",color:"white"}]
execute unless score @s ec.ak_active matches 1.. run tellraw @s [{text:"  Complete The Awakening first, then found a guild,",color:"gray"}]
execute unless score @s ec.ak_active matches 1.. run tellraw @s [{text:"  and the road to conquest will open to you.",color:"gray"}]
execute unless score @s ec.ak_active matches 1.. run tellraw @s ""

# === Completed the whole line: celebrate, no current quest. ===
execute if score @s ec.ak_complete matches 1 run tellraw @s [{text:"  ★ ",color:"gold"},{text:"Build & Conquer Complete!",color:"gold",bold:true}]
execute if score @s ec.ak_complete matches 1 run tellraw @s [{text:"  Glyph, kingdom, and conquest are yours.",color:"yellow"}]
execute if score @s ec.ak_complete matches 1 run tellraw @s [{text:"  Your hold is carved into the land.",color:"yellow"}]
execute if score @s ec.ak_complete matches 1 run tellraw @s ""

# === Active + not complete: show the current quest (data-driven). ===
execute if score @s ec.ak_active matches 1 unless score @s ec.ak_complete matches 1 run function evercraft:adventure/kingdom/get_quest
execute if score @s ec.ak_active matches 1 unless score @s ec.ak_complete matches 1 run data modify storage evercraft:ak_cur o set from storage evercraft:ak_cur quest
execute if score @s ec.ak_active matches 1 unless score @s ec.ak_complete matches 1 run tellraw @s [{text:"  Current Quest",color:"yellow",bold:true}]
execute if score @s ec.ak_active matches 1 unless score @s ec.ak_complete matches 1 run function evercraft:adventure/kingdom/overview_macro with storage evercraft:ak_cur o
# Live progress bar — ec.ak_prog (conquest-since-start delta, re-synced by check_progress).
execute if score @s ec.ak_active matches 1 unless score @s ec.ak_complete matches 1 run tellraw @s [{text:"   Progress: ",color:"gray"},{score:{name:"@s",objective:"ec.ak_prog"},color:"#FFAA00",bold:true},{text:" conquests since you began",color:"dark_gray"}]
execute if score @s ec.ak_active matches 1 unless score @s ec.ak_complete matches 1 run tellraw @s ""
# C0: re-show the active beat's lore + the [Skip ▸] button on the overview page.
execute if score @s ec.ak_active matches 1 unless score @s ec.ak_complete matches 1 run data modify storage evercraft:qp_cur o set from storage evercraft:ak_cur quest
execute if score @s ec.ak_active matches 1 unless score @s ec.ak_complete matches 1 run function evercraft:quest_pacing/render_lore
execute if score @s ec.ak_active matches 1 unless score @s ec.ak_complete matches 1 run tellraw @s ""

# === Lifetime tallies (always shown once started) — the three pillars this line teaches. ===
execute if score @s ec.ak_active matches 1.. run tellraw @s [{text:"  Quests Completed: ",color:"gray"},{score:{name:"@s",objective:"ec.ak_done"},color:"green",bold:true}]
execute if score @s ec.ak_active matches 1.. run tellraw @s [{text:"  Glyphs Forged: ",color:"gray"},{score:{name:"@s",objective:"ach.runes_forged"},color:"#55FFFF",bold:true},{text:"   Home Totems: ",color:"gray"},{score:{name:"@s",objective:"hs.totems"},color:"light_purple",bold:true}]
execute if score @s ec.ak_active matches 1.. run tellraw @s [{text:"  Guild Rank: ",color:"gray"},{score:{name:"@s",objective:"ec.guild_rank"},color:"gold",bold:true},{text:"   Laborers: ",color:"gray"},{score:{name:"@s",objective:"ec.lb_count"},color:"yellow",bold:true}]
execute if score @s ec.ak_active matches 1.. run tellraw @s [{text:"  Dungeons Cleared: ",color:"gray"},{score:{name:"@s",objective:"ach.dungeons_done"},color:"red",bold:true},{text:"   Bosses Downed: ",color:"gray"},{score:{name:"@s",objective:"ach.boss_kills"},color:"dark_red",bold:true}]
execute if score @s ec.ak_active matches 1.. run tellraw @s ""

# Frame footer.
tellraw @s [{text:"═══════════════════════════════",color:"gold"}]
