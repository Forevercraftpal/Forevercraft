# ============================================================
# Build & Conquer (Adventure-B) — get_quest macro body
# ============================================================
# Called with storage evercraft:ak_cur containing {idx:<0-based index>}.
# Copies registry quest[idx] into evercraft:ak_cur quest.
$data modify storage evercraft:ak_cur quest set from storage evercraft:ak_registry quests[$(idx)]
