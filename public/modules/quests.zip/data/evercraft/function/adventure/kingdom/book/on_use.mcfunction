# ============================================================
# Build & Conquer (Adventure-B) — King's Codex right-click handler
# ============================================================
# Triggered by the using_item advancement (kingdom_questline/on_use.json) when the
# player right-clicks a minecraft:book carrying custom_data{kingdom_book:true}. Clone
# of adventure/questline/book/on_use (C5): the advancement stays granted briefly to
# prevent spam, then is revoked by a scheduled cooldown reset. Opens the Build &
# Conquer overview page. Run as @s = the player.

# Only fire from the mainhand (a book sitting in a container shouldn't trigger).
execute unless items entity @s weapon.mainhand minecraft:book[custom_data~{kingdom_book:true}] run return fail

# Cooldown guard: schedule advancement revoke after ~1s (always, regardless of
# outcome) so a single right-click opens the page exactly once.
tag @s add ec.kingbook_cd
schedule function evercraft:adventure/kingdom/book/reset_cooldown 20t append

# Open the Build & Conquer overview (the same page the Tier-2 row opens).
function evercraft:adventure/kingdom/overview
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:item.book.page_turn master @s ~ ~ ~ 0.8 1.2
