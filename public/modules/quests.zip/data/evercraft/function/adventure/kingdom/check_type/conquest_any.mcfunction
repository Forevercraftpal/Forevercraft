# AK check helper — conquest_any (the AXIS-FLEXIBLE conquest apex, S7/K7). @s = player.
# Catch-up beat. The chapter-3 apex satisfies on EITHER axis of conquest: surviving the
# raid escalation (dungeons cleared / the floor-10 dungeon->raid funnel) OR downing a
# World Boss. So this helper computes the MAX of three lifetime conquest mirrors —
# ach.dungeons_done, ach.boss_kills, ach.boss_unique — and satisfies when that max
# reaches quest.count (#ak_count ec.temp). DECISIONS #4: the conquest apex is axis-
# flexible (survive a Spirit Raid OR down a World Boss); either road satisfies the beat
# identically, advancing ONCE (no double-count — the engine's forward cursor makes a
# single advance per satisfied beat).
#
# Called `with storage evercraft:ak_cur o` (the check_macro passes it for uniformity);
# this helper ignores the macro args and reads fixed mirrors, so it is a PLAIN (non-$)
# file.
#
# A veteran who has cleared a dungeon OR killed a boss past the threshold on EITHER
# axis auto-passes on the next 20t check at full reward (R1).
#
# READ-ONLY: reads ach.dungeons_done + ach.boss_kills + ach.boss_unique (achievements-
# owned). Folds the running max into a private temp register (#ak_conq_max), never
# writes a dungeon/raid/boss objective (the no-write proof).
scoreboard players set #ak_satisfied ec.temp 0
scoreboard players operation #ak_conq_max ec.temp = @s ach.dungeons_done
execute if score @s ach.boss_kills > #ak_conq_max ec.temp run scoreboard players operation #ak_conq_max ec.temp = @s ach.boss_kills
execute if score @s ach.boss_kills > #ak_conq_max ec.temp run scoreboard players operation #ak_conq_max ec.temp = @s ach.boss_kills
execute if score #ak_conq_max ec.temp >= #ak_count ec.temp run scoreboard players set #ak_satisfied ec.temp 1
