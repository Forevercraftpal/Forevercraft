# ============================================================
# Build & Conquer (Adventure-B) — Reward dispatch (macro body)
# ============================================================
# Called `with storage evercraft:ak_cur o`, o = the completed quest
#   {...,reward,reward_amt,target,...}. Exposes the reward args to ec.temp / storage
# and routes to reward_type/$(reward). Run as @s = the player.
#
# Shared args the helpers consume:
#   #ak_reward_amt ec.temp = quest.reward_amt (coins amount / xp amount)
#   storage evercraft:ak_cur o.target = crate tier name (crate reward only)
$scoreboard players set #ak_reward_amt ec.temp $(reward_amt)

# Dispatch on reward type: xp | coins | crate  (NO title — wave spec K4).
$function evercraft:adventure/kingdom/reward_type/$(reward) with storage evercraft:ak_cur o
