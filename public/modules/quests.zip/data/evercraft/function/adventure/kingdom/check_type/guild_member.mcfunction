# AK check helper — guild_member (the player is in a guild). @s = player. Reads
# ec.guild_id (the guild-membership flag, set to a positive guild ID when a player
# founds or joins a guild, cleared to 0 on leave/disband — guild-owned, written by
# guild/create + guild/join + guild/leave). Satisfied when ec.guild_id matches 1..
# (the player currently belongs to a guild). This is the chapter-2 "gather a guild"
# teach beat — it TEACHES the existing guild flow (founding via a charter, or joining
# an invite); it adds NO new ec.quest trigger (K10).
#
# Called `with storage evercraft:ak_cur o` (the check_macro passes it for uniformity);
# this helper ignores the macro args (the condition is a flag, not a threshold — the
# macro still set #ak_count for uniformity, unread here), so it is a PLAIN (non-$) file.
#
# READ-ONLY: reads ec.guild_id (guild-owned). Writes NO guild objective. A veteran who
# already belongs to a guild auto-passes on the next 20t check; one who does not simply
# founds or joins one (taught, never walled — the beat is skippable).
scoreboard players set #ak_satisfied ec.temp 0
execute if score @s ec.guild_id matches 1.. run scoreboard players set #ak_satisfied ec.temp 1
