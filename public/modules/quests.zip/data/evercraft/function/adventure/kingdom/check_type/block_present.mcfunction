# AK check helper — block_present (a glyph has been FORGED / is present in the world).
# @s = player. Catch-up beat. Reads ach.runes_forged (the lifetime count of glyph
# runes the player has forged at a Glyph Forge, achievements-owned) DIRECTLY and
# satisfies when it reaches quest.count (#ak_count ec.temp). This is the chapter-1
# "forge your first glyph" beat — the name `block_present` is the council-locked type
# (the glyph manifests as a placed/forged block in the world); we read the lifetime
# forge counter as the durable proof. A veteran who has already forged a glyph
# auto-passes on the next 20t check at full reward (R1).
#
# Called `with storage evercraft:ak_cur o` (the check_macro passes it for uniformity
# with lifetime_at); this helper ignores the macro args and reads a fixed mirror, so
# it is a PLAIN (non-$) file.
#
# READ-ONLY: reads ach.runes_forged (achievements-owned). Writes NO glyph/inscription
# objective (the no-write proof over the glyph engine).
scoreboard players set #ak_satisfied ec.temp 0
execute if score @s ach.runes_forged >= #ak_count ec.temp run scoreboard players set #ak_satisfied ec.temp 1
