# ============================================================
# Build & Conquer (Adventure-B) — Check (macro body, dispatch on quest.type)
# ============================================================
# Called `with storage evercraft:ak_cur o`, o = current quest
#   {id,title,desc,type,target,count,reward,reward_amt,chapter,...}.
# Sets #ak_satisfied ec.temp to 1 iff the active quest's completion condition is met.
# Run as @s = the player.
#
# A macro can't branch on an int comparison inline, so we expose the threshold to
# ec.temp and route the per-TYPE decision to a tiny helper file:
#   - #ak_count ec.temp     = quest.count
# Each helper at check_type/$(type) reads its OWN public mirror and sets
# #ak_satisfied ec.temp. All helpers are READ-ONLY: they never write a glyph/housing/
# guild/laborer/dungeon/raid/boss engine objective (the no-write proof). The types,
# by chapter:
#   ch.1 Glyphs:   block_present (ach.runes_forged — glyphs forged), lifetime_at
#                  (hs.totems — home totems raised; reads hs.in_zone too for "at home")
#   ch.2 Kingdom:  guild_member (ec.guild_id — in a guild), lifetime_at (ec.guild_rank
#                  depth / ec.lb_count laborers)
#   ch.3 Conquest: count_seen (forward delta of dungeons+bosses off ec.ak_seen),
#                  lifetime_at (ach.dungeons_done / ach.crates_structure), conquest_any
#                  (axis-flexible raid-OR-boss apex — ach.dungeons_done OR
#                  ach.boss_kills OR ach.boss_unique reaches count; S7/K7)

# Expose the threshold for the helpers to compare against.
$scoreboard players set #ak_count ec.temp $(count)

# Per-type decision (sets #ak_satisfied ec.temp). $(type) is one of:
#   block_present | lifetime_at | count_seen | guild_member | lb_active | conquest_any
$function evercraft:adventure/kingdom/check_type/$(type) with storage evercraft:ak_cur o
