# ============================================================
# Build & Conquer (Adventure-B) — Advance (complete current quest -> next)
# ============================================================
# Run as @s = the player. Called by adventure/kingdom/check when the active quest is
# satisfied, OR by quest_pacing/do_skip (the [Skip ▸] button, full reward). WRITER of
# the linear pointer (ec.ak_quest), ec.ak_prog reset, ec.ak_done, ec.ak_complete (via
# finish).
#
# Order: show_completed -> reward -> bump pointer (clamped) -> reset prog -> +1 done
#        -> load next quest -> show_objective. Final quest -> a one-shot "line
#        complete!" tellraw + ec.ak_active bumped to 2, pointer clamped at N.

# --- Idempotency / out-of-range guards (mirror the C5 upper-bound guard) ---
execute unless score @s ec.ak_active matches 1.. run return 0
execute if score @s ec.ak_complete matches 1 run return 0

# Registry length = N (the last valid quest index). Dynamic so the engine never
# hardcodes the quest count — it grows automatically as batches are added.
execute store result score #ak_n ec.temp run data get storage evercraft:ak_registry quests
# Defensive: if the registry failed to load (length 0), do nothing.
execute if score #ak_n ec.temp matches ..0 run return 0
# If the pointer is somehow already past N, clamp + finish (don't run past the end).
execute if score @s ec.ak_quest > #ak_n ec.temp run function evercraft:adventure/kingdom/finish
execute if score @s ec.ak_quest > #ak_n ec.temp run return 0

# === 1) SHOW WHAT WAS JUST COMPLETED (ak_cur still holds the old quest) ===
function evercraft:adventure/kingdom/show_completed

# === 2) PAY OUT THE REWARD for the completed quest ===
function evercraft:adventure/kingdom/reward

# === 3) ADVANCE THE LINEAR POINTER + COUNTERS ===
scoreboard players add @s ec.ak_quest 1
scoreboard players set @s ec.ak_prog 0
scoreboard players add @s ec.ak_done 1

# === 4) FINAL-QUEST HANDLING ===
# If the new pointer exceeds N, the player just finished the LAST quest. Detect the
# overflow FIRST (into a flag), then clamp the pointer back to N (so a future check
# can't index out of range) and run the one-shot completion fanfare.
scoreboard players set #ak_overflow ec.temp 0
execute if score @s ec.ak_quest > #ak_n ec.temp run scoreboard players set #ak_overflow ec.temp 1
execute if score #ak_overflow ec.temp matches 1 run scoreboard players operation @s ec.ak_quest = #ak_n ec.temp
execute if score #ak_overflow ec.temp matches 1 run function evercraft:adventure/kingdom/finish

# Not finished: load the next quest into ak_cur and show its objective (paced).
execute if score #ak_overflow ec.temp matches 0 run function evercraft:adventure/kingdom/get_quest
execute if score #ak_overflow ec.temp matches 0 run function evercraft:adventure/kingdom/on_advance_notify
