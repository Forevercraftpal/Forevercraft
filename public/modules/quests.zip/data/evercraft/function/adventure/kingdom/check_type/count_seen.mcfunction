# AK check helper — count_seen (conquests completed SINCE the line began). @s =
# player. Present-action beat: reads the FORWARD-only delta
# ((ach.dungeons_done + ach.boss_kills) - ec.ak_seen) so conquests completed before
# this beat was active never retro-credit it. Satisfied when the delta reaches
# quest.count (#ak_count ec.temp).
#
# Called `with storage evercraft:ak_cur o` (the check_macro passes it for uniformity);
# this helper ignores the macro args and reads fixed mirrors, so it is a PLAIN (non-$)
# file.
#
# READ-ONLY: reads ach.dungeons_done + ach.boss_kills (achievements-owned, the lifetime
# conquest counters) + ec.ak_seen (this line's OWN cursor, seeded at start). Writes NO
# foreign objective.
#
# Note: a true veteran is NOT auto-passed by count_seen (the forward cursor is
# intentional for present-action beats) — but the line never WALLS on it, because every
# count_seen beat is `skippable` (default), so a player who would rather not run fresh
# conquests can [Skip ▸] at full reward. The lifetime-threshold veteran auto-pass for the
# conquest chapter rides the catch-up types (conquest_any / lifetime_at) elsewhere.
# (Mirrors adventure/questline check_type/quest_count_seen's forward-cursor design.)
scoreboard players set #ak_satisfied ec.temp 0
scoreboard players operation #ak_delta ec.temp = @s ach.dungeons_done
scoreboard players operation #ak_delta ec.temp += @s ach.boss_kills
scoreboard players operation #ak_delta ec.temp -= @s ec.ak_seen
execute if score #ak_delta ec.temp >= #ak_count ec.temp run scoreboard players set #ak_satisfied ec.temp 1
