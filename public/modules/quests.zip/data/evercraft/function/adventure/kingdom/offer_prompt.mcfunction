# ============================================================
# Build & Conquer (Adventure-B) — One-time soft BEGIN offer (S9)
# ============================================================
# Run as @s = the player. Called from guild/announce_create's ONE additive gated line
# on a guild creation. Fires the ONE-TIME Seven-voice soft offer to begin Build &
# Conquer — the FALLBACK to begin the line is always the Adventurer Tier-2 row, which
# renders a real clickable [Begin →] START surface (WA63-D1, Adv.GqStart10 ->
# kingdom/start) once Adventure-A is complete and the line is not yet begun. So this is
# a convenience nudge, not the only door — and questline/finish re-fires this offer for
# a guild-holder who finished The Awakening late (the closed D1 trap).
#
# SEQUENCING (S9, the C6-distinct gate): this offer fires ONLY after Adventure-A is
# COMPLETE (ec.ac_active matches 2) — so it never appears simultaneously with the C5
# Awakening offer, and a player who has not finished The Awakening is never nudged onto
# the kingdom line.
#
# GATING (the caller's single line gates these; re-guarded here defensively):
#   - ec.chron_view matches 1 (Adventurer) OR 3 (Both) — a Crafter-only player (view 2)
#     NEVER sees the Build & Conquer offer.
#   - ec.ac_active matches 2 — Adventure-A complete (the sequenced prereq).
#   - ec.ak_active matches 0 — never offered to someone already on (or past) the line.
#   - ec.ak_offer matches 0 — one-shot; set to 1 at the END so a mid-fn failure doesn't
#     permanently swallow a never-shown offer. SOLE WRITER of ec.ak_offer is this
#     function (called from announce_create); the strip-reset is the documented exception.
#
# IMMERSION LAW (no /trigger): the begin affordance is a clickable chat button whose
# click_event runs adventure/kingdom/start directly (the locked "offer surface" default
# — round-1 DECISIONS: clickable chat prompt with a function click_event). Declining =
# simply not clicking; the offer never re-fires (ec.ak_offer latch). Mirrors
# adventure/questline/offer_prompt verbatim.
#
# NOTIFY (alert class, mute_at:99, key "ak_offer"): the Seven-voice chime/flash routes
# through util/notify/dispatch so it respects the player's global ec.notify filter.
# mute_at:99 means the [Mute] button effectively never appears — a one-shot offer, not a
# repeating nudge. The clickable [Begin ->] button is INDEPENDENT of the chatter gate: a
# player with notifications OFF still gets the offer + can begin.

# === Re-guard the latches (caller already gated; defensive against re-entry) ===
execute if score @s ec.ak_offer matches 1 run return 0
execute if score @s ec.ak_active matches 1.. run return 0
# Re-guard the sequencing prereq: Adventure-A must be COMPLETE (ec.ac_active matches 2).
execute unless score @s ec.ac_active matches 2 run return 0
# Re-guard the lens too (1 = Adventurer, 3 = Both; never view 2 = Crafter-only).
execute unless score @s ec.chron_view matches 1 unless score @s ec.chron_view matches 3 run return 0

# === 1) MUTABLE Seven-voice OFFER nudge (alert class) ===
function evercraft:util/notify/dispatch {key:"ak_offer",class:"alert",mute_at:99}
# Only the chime/flash respects the dispatcher's approval (global ec.notify filter).
execute if score #notif_show_ak_offer ec.temp matches 1 run title @s times 8 50 12
execute if score #notif_show_ak_offer ec.temp matches 1 run title @s subtitle {text:"A throne is rising",color:"gold",italic:true}
execute if score #notif_show_ak_offer ec.temp matches 1 if score @s ec.fx_snd matches 1.. run playsound minecraft:block.beacon.activate master @s ~ ~ ~ 0.7 1.5

# === 2) THE OFFER itself (always shown — independent of the chatter chime) ===
# A quiet Seven-voice card. The [Begin Build & Conquer ->] button is the one
# interaction-driven affordance (function click_event, non-op-safe per the
# adventure/questline/offer_prompt precedent). One-shot: it can be clicked once;
# clicking it runs adventure/kingdom/start (which dup-guards on ec.ak_active).
tellraw @s ""
tellraw @s [{text:"  ⚔ ",color:"gold"},{text:"Build & Conquer",color:"gold",bold:true,italic:false}]
tellraw @s [{text:"  You have a banner now, and a hold to fly it over.",color:"gray",italic:true}]
tellraw @s [{text:"  Carve a glyph, raise a totem, gather laborers to",color:"gray",italic:true}]
tellraw @s [{text:"  serve your kingdom — and when it is strong, march",color:"gray",italic:true}]
tellraw @s [{text:"  out and conquer what you choose.",color:"gray",italic:true}]
tellraw @s ""
tellraw @s [{text:"  ",color:"dark_gray"},{text:"[Begin Build & Conquer →]",color:"#FFC24D",bold:true,hover_event:{action:"show_text",value:[{text:"Start Build & Conquer — a paced, fully skippable Adventurer line.",color:"gray"},"",{text:"You can also begin it any time from the Grand Quests hub (Adventurer → Build & Conquer).",color:"dark_gray",italic:true}]},click_event:{action:"run_command",command:"/function evercraft:adventure/kingdom/start"}}]
tellraw @s [{text:"  ",color:"dark_gray"},{text:"(or simply walk on — the offer will not return)",color:"dark_gray",italic:true}]
tellraw @s ""

# === 3) LATCH the offer (sole writer of ec.ak_offer) ===
# Set LAST so a failure above doesn't permanently swallow a never-shown offer.
scoreboard players set @s ec.ak_offer 1
