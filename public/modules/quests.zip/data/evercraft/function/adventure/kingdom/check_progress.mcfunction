# ============================================================
# Build & Conquer (Adventure-B) — 20t catch-up / interlude scheduler
# ============================================================
# Self-rescheduling, EXISTENCE-GATED 20t loop (kicked from adventure/kingdom/load with
# `replace`). It does work ONLY for players on the line
# (@a[scores={ec.ak_active=1,ec.ak_complete=0}]), so with no Build & Conquer players it
# iterates over NOTHING — no per-tick @a scan (the datapack's perf law).
#
# IMPORTANT (ec.ak_active range): the selector uses `ec.ak_active=1` exactly (NOT 1..)
# because finish() bumps ec.ak_active to 2 on completion — a value-2 player is DONE and
# must not be re-scanned. A value-1 + complete-0 player is the active set.
#
# This line has NO per-action engine splice (it would add ec.quest board triggers,
# which is forbidden, K10). So the 20t loop is the SOLE driver: every check type is
# READ-DERIVED over a public mirror, so this loop catches each satisfied beat (a glyph
# forged, a totem raised, a guild joined, a dungeon cleared, a boss downed) within ~1s.
# Two jobs per active player (both via check):
#   1. CATCH-UP (R1): a block_present / lifetime_at / guild_member / conquest_any beat
#      whose lifetime threshold the player's mirror already clears auto-satisfies on
#      this tick and pays full reward — a veteran is never walled. Those helpers read
#      the lifetime mirror directly.
#   2. INTERLUDE auto-pass (C0, SCHEMA_DELTA §3): a beat:"interlude"/count:0 beat is
#      instantly satisfied by check()'s interlude guard, so it advances here on the
#      next tick — delivering its lore once, paying its tiny reward once.
#
# The forward-only ec.ak_quest cursor (one advance per satisfied beat, inside advance)
# makes this no-double-credit and no-penalty.

# === RUN THE CHECK FOR EVERY ACTIVE, NON-COMPLETE PLAYER ===
# (check() is itself existence-gated + idempotent; the outer selector keeps the
#  per-tick cost zero when nobody is on the line.)
execute as @a[scores={ec.ak_active=1,ec.ak_complete=0}] run function evercraft:adventure/kingdom/check

# === RE-SYNC THE OVERVIEW PROGRESS BAR (ak_prog, one writer) ===
# Keep ec.ak_prog mirroring the present-beat conquest delta for active players, so the
# overview's live progress bar reads true for the chapter-3 count_seen beats. This is
# the ONLY persistent writer of ak_prog besides the reset path — strictly one-writer.
# Computed per active @s: ak_prog = (ach.dungeons_done + ach.boss_kills) - ec.ak_seen
# (clamped at 0 via the seed, which is always <= the live sum). Harmless for non-
# conquest beats (the bar just shows the conquest-since-start delta, a meaningful
# "you're conquering" indicator). No-op for non-active players via the selector.
execute as @a[scores={ec.ak_active=1,ec.ak_complete=0}] run scoreboard players operation @s ec.ak_prog = @s ach.dungeons_done
execute as @a[scores={ec.ak_active=1,ec.ak_complete=0}] run scoreboard players operation @s ec.ak_prog += @s ach.boss_kills
execute as @a[scores={ec.ak_active=1,ec.ak_complete=0}] run scoreboard players operation @s ec.ak_prog -= @s ec.ak_seen

# Re-schedule self.
schedule function evercraft:adventure/kingdom/check_progress 20t replace
