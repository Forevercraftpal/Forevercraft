# ============================================================
# Build & Conquer (Adventure-B) — 20t catch-up / interlude scheduler
# ============================================================
# Self-rescheduling, EXISTENCE-GATED 20t loop (kicked from adventure/kingdom/load with
# `replace`). It does work ONLY for players on the line
# (@a[scores={ec.ak_active=1,ec.ak_complete=0}]), so with no Build & Conquer players it
# iterates over NOTHING — no per-tick @a scan (the datapack's perf law).
#
# IMPORTANT (ec.ak_active range): the selector uses `ec.ak_active=1` exactly (NOT 1..)
# because finish() bumps ec.ak_active to 2 on completion — a value-2 player is DONE and
# must not be re-scanned. A value-1 + complete-0 player is the active set.
#
# This line has NO per-action engine splice (it would add ec.quest board triggers,
# which is forbidden, K10). So the 20t loop is the SOLE driver: every check type is
# READ-DERIVED over a public mirror, so this loop catches each satisfied beat (a glyph
# forged, a totem raised, a guild joined, a dungeon cleared, a boss downed) within ~1s.
# Two jobs per active player (both via check):
#   1. CATCH-UP (R1): a block_present / lifetime_at / guild_member / conquest_any beat
#      whose lifetime threshold the player's mirror already clears auto-satisfies on
#      this tick and pays full reward — a veteran is never walled. Those helpers read
#      the lifetime mirror directly.
#   2. INTERLUDE auto-pass (C0, SCHEMA_DELTA §3): a beat:"interlude"/count:0 beat is
#      instantly satisfied by check()'s interlude guard, so it advances here on the
#      next tick — delivering its lore once, paying its tiny reward once.
#
# The forward-only ec.ak_quest cursor (one advance per satisfied beat, inside advance)
# makes this no-double-credit and no-penalty.

# === RUN BOTH PER-PLAYER JOBS IN A SINGLE @a SCAN (WA63-PERF-CHECKPROG-SCANS) ===
# ONE @a[scores={ec.ak_active=1,ec.ak_complete=0}] pass into a tiny per-player body fn
# (check_progress_player) that does BOTH the catch-up check AND the ak_prog re-sync —
# collapsing the former 4 @a passes into 1 (the build_quests loop shape). check() is
# existence-gated + idempotent; the selector keeps the per-tick cost zero off-line.
# ec.ak_prog stays one-writer (the body fn is its only persistent writer besides reset):
# ak_prog = (ach.dungeons_done + ach.boss_kills) - ec.ak_seen, clamped at 0 via the seed.
execute as @a[scores={ec.ak_active=1,ec.ak_complete=0}] run function evercraft:adventure/kingdom/check_progress_player

# Re-schedule self.
schedule function evercraft:adventure/kingdom/check_progress 20t replace
