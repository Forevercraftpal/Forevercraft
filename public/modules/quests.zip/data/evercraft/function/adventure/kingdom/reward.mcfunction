# ============================================================
# Build & Conquer (Adventure-B) — Reward (pay out the completed quest)
# ============================================================
# Run as @s = the player. Reads the just-completed quest's reward fields from ak_cur.
# quest and dispatches on reward type. ak_cur still holds the OLD (just-completed)
# quest at this point (reward runs BEFORE advance bumps the pointer).
#
# Reward fields: reward (xp|coins|crate), reward_amt (int), target (crate tier). NO
# `title` reward type exists in this engine (per the wave spec, K4 — Build & Conquer
# pays only xp/coins/crate; Adventurer identity comes from the Reaper alignment + the
# Adventurer Card).
#
# XP NOTE (deliberate, mirrors C5 reward.mcfunction): the `xp` reward pays VANILLA
# player experience (`experience add @s N points`), NOT artisan XP. The frozen add_xp
# contract feeds the SIX crafter categories (0-6 Mining..Alchemy) — there is NO
# "Adventuring" artisan category, and the live Adventurer reward economy (the village
# quest board, quests/active/complete_tier*) pays vanilla XP. Routing an Adventurer
# reward through a crafter category would mislabel it; vanilla XP matches the board
# economy this line teaches. `internal_grant` / add_xp are never used.

# Flatten the quest fields for the reward macro.
data modify storage evercraft:ak_cur o set from storage evercraft:ak_cur quest
function evercraft:adventure/kingdom/reward_macro with storage evercraft:ak_cur o

# === ADDITIVE: D-Q10-REWARD artifact (Artifact-Fusion w1) ===
# On TOP of the q10 xp reward above ("The Working Hold"). Fires only when the just-
# completed quest is #10 (ec.ak_quest still holds 10 here — advance bumps the
# pointer AFTER reward). Adventure-B q10 -> Stoneward Pebble (B1, Family L Vanguard
# combat-buff leaf). One-shot per the pointer-equals-10 gate. Inv-full aware via
# the shared helper.
execute if score @s ec.ak_quest matches 10 run data modify storage evercraft:q10r args set value {lt:"artifacts/common/stoneward_pebble",name:"Stoneward Pebble",color:"white"}
execute if score @s ec.ak_quest matches 10 run function evercraft:artifacts/give/q10_reward with storage evercraft:q10r args

# === ADDITIVE: D-Q10-REWARD artifact (Artifact-Fusion D2 — Dragonheart Fam11/M) ===
# On TOP of the q10 xp reward AND the Stoneward Pebble grant above (additive — the
# q10_reward helper is stateless, a second args-set + call is an independent grant,
# the same two-call-per-line pattern as the q25 hook below). Adventure-B q10 ->
# Dragonheart Ember (#11, Family M Heart-slot combat-buff leaf: Fire Resistance) —
# the guaranteed Heart-slot piece every player gets. One-shot per the pointer-
# equals-10 gate. Inv-full aware via the shared helper.
execute if score @s ec.ak_quest matches 10 run data modify storage evercraft:q10r args set value {lt:"artifacts/exquisite/dragonheart_ember",name:"Dragonheart Ember",color:"light_purple"}
execute if score @s ec.ak_quest matches 10 run function evercraft:artifacts/give/q10_reward with storage evercraft:q10r args

# === ADDITIVE: Soulguard post-hit-immunity piece — Newcomer q25 gift (Artifact-Fusion w2) ===
# D-MOBDROP EXCEPTION: the Soulguard Aegis post-hit-immunity piece (the Totem of
# Soul Protection, soul_protection) is CRAFT-ONLY — deliberately NOT a mob drop
# (see w2: it is the ONE Soulguard piece omitted from the mob-drop map). Newcomer
# exception: it is GIFTED at quest 25 of the Adventure-B (Build & Conquer)
# survival/combat line, Newcomer mode only (ec.difficulty matches 1). Fires when
# the just-completed quest is #25 (ec.ak_quest still holds 25 here — advance bumps
# the pointer AFTER reward); one-shot per the pointer-equals-25 gate. Inv-full aware
# via the shared helper. NOTE: Adventure-B currently ends at q20 — this hook is
# DORMANT until the line is extended past q25 (the q25 anchor + line are Open-
# Decision 2; see the w2 build-log followups for Joseph's confirmation).
execute if score @s ec.ak_quest matches 25 if score @s ec.difficulty matches 1 run data modify storage evercraft:q10r args set value {lt:"artifacts/exquisite/soul_protection",name:"Totem of Soul Protection",color:"light_purple"}
execute if score @s ec.ak_quest matches 25 if score @s ec.difficulty matches 1 run function evercraft:artifacts/give/q10_reward with storage evercraft:q10r args
