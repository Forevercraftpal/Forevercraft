# ============================================================
# Build & Conquer (Adventure-B) — Finish (one-shot completion fanfare)
# ============================================================
# Run as @s = the player who just completed the final quest. Sets the ec.ak_complete
# sentinel so this fires exactly once, then prints the "line complete!" celebration.
# WRITER of ec.ak_complete (with advance).
#
# On completion this bumps ec.ak_active 1 -> 2 (mirroring the C5 sentinel pattern), so
# a finished player is excluded from the active-only check_progress selector and the
# overview shows the celebration, not the current-quest panel. Every gate in THIS line
# uses `ec.ak_active matches 1..` so the 1->2 bump is transparent to it.

# Guard: only ever fire once.
execute if score @s ec.ak_complete matches 1 run return 0
scoreboard players set @s ec.ak_complete 1

# Mark Build & Conquer complete (the 1->2 bump excludes a done player from the
# active-only check_progress selector and flips the overview to the celebration).
scoreboard players set @s ec.ak_active 2

# Auto-track repoint (Wiring #52): clear the [Skip ▸] tracker if it was pointed at THIS
# line (Build & Conquer = slot 7) — a completed line must never accept a skip.
execute if score @s ec.gq_track matches 7 run scoreboard players set @s ec.gq_track 0

data modify storage evercraft:notify stage.c set value [{text:"★ ",color:"gold"},{text:"Build & Conquer — Complete!",color:"gold",bold:true},{text:" ★",color:"gold"}]
scoreboard players set #ndur ec.temp 50
function evercraft:util/notify/emit_keep
data modify storage evercraft:notify stage.c set value [{text:"You raised a glyph over your hearth, gathered a guild and the hands to serve it, and marched out to conquer what you chose. A hold, a kingdom, a name carved into the land — and it is wholly your own.",color:"yellow",italic:true}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit

title @s times 10 60 20
title @s title {text:"Conqueror",color:"gold"}
title @s subtitle {text:"Build & Conquer is complete",color:"yellow"}

execute if score @s ec.fx_snd matches 1.. run playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 1.0 1.0
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.player.levelup master @s ~ ~ ~ 0.6 1.2

# === ADDITIVE: exit handoff (Questline Restructure W4, 2026-06-10) ===
# A finished Path never goes dark: name the repeatable continuation (Heroic board,
# patron bounties, dungeons) and nudge the Grand Chronicle if both branches qualify.
# Runs inside this finish's one-shot complete-sentinel guard.
function evercraft:grand_quests/exit_handoff_adventure

# Clear a stale tracked-Path pin if THIS line was pinned (QR-P5, 2026-06-10).
function evercraft:grand_quests/untrack_on_finish {slot:7}
