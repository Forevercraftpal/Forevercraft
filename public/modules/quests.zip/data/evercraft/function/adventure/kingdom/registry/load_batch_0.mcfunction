# ============================================================
# Build & Conquer (Adventure-B) — Registry batch 0 (the starter line, q1..q20)
# ============================================================
# Appends the first 20 quests onto storage evercraft:ak_registry quests. Called by
# registry/load AFTER it sets quests=[]. MUST append in id order (id=1 first => list
# index 0), contiguous, so list-position == ec.ak_quest-1. (Structural clone of
# adventure/questline/registry/load_batch_0 (C5), paced via C0.)
#
# Quest object schema (the engine reads these exact fields):
#   {id:int, title:string, desc:string, type:string, target:string,
#    count:int, reward:string, reward_amt:int, chapter:int,
#    [lore:string], [beat:string], [skippable:int]}      <- C0 fields OPTIONAL
#
# type    -> dispatched by check_type/$(type):
#            block_present | lifetime_at | count_seen | guild_member | lb_active
#            | conquest_any
#            (beat:"interlude"/count:0 auto-passes BEFORE dispatch — SCHEMA_DELTA §3)
# target  -> IGNORED by block_present / count_seen / guild_member / lb_active /
#             conquest_any (each reads a fixed mirror). For type:"lifetime_at" target
#             NAMES the lifetime objective to read (hs.totems | ec.guild_rank |
#             ec.lb_count | ach.dungeons_done | ach.crates_structure). On a
#             reward:"crate" beat target instead names the crate TIER consumed by
#             reward_type/crate (common|uncommon|rare|ornate|exquisite|mythical).
# count   -> block_present: ach.runes_forged threshold (glyphs forged);
#            lifetime_at: threshold for the named target mirror;
#            count_seen: conquest-since-start delta ((dungeons+bosses) - ec.ak_seen);
#            guild_member: IGNORED (flag — "be in a guild");
#            lb_active: ec.lb_count threshold (laborers hired);
#            conquest_any: max(dungeons_done, boss_kills, boss_unique) threshold
#              (the axis-flexible apex — survive a raid OR down a boss, DECISIONS #4);
#            interlude: 0 (auto-pass).
# reward  -> xp | coins | crate   (NO title, K4). reward_amt = amount.
#            xp pays VANILLA player experience (Adventurer economy — there is no
#            Adventuring artisan category; matches the village board's vanilla XP).
# chapter -> display grouping: 1=glyphs, 2=kingdom, 3=conquest.
#
# XP TIER TABLE (vanilla-XP, modest — a kingdom beat is never a fatter XP source than
# a board quest of equal effort):
#   30 / 60 / 100 / 150 / 220 / 300 / 400 / 500  (points)
#
# C0 CADENCE (SCHEMA_DELTA §1): every objective beat carries `lore`; interludes sit
# ~2.3:1 against objective beats (q4 what-a-glyph-is, q8 a-kingdom-is-people, q11 the
# RUNE-WORD bridge to Tinkering [S14 pure-lore], q14 the floor-10 dungeon->raid funnel
# KEYSTONE [S7 pure-lore], q17 the-cost-of-conquest, q19 the-finale-reflection). The
# two headline teach beats q1 (forge your first glyph, block_present) + q6 (gather a
# guild, guild_member) are `skippable:0` "see-it-once" — both still auto-pass a veteran
# via the lifetime read in their check helper (Decision #5).
#
# HOME-ZONE SOFT PREREQ (S10, Decision): the chapter-1 glyph/totem beats ASSUME the
# home exists. The lore SOFT-POINTS at the Housing/Builder path ("if you have not yet
# claimed a home, the Builder's Path teaches it") — it NEVER re-teaches Hearthstone /
# home-claiming, and the checks NEVER hard-gate on hs.in_zone (a homeless player simply
# has not raised hs.totems yet, and can [Skip ▸] or catch up later). No dead-ends.
#
# ESCALATION LADDER (S7, chapter 3): the conquest chapter narrates the one-ladder
# build-and-conquer escalation, with the floor-10 dungeon->raid funnel as its KEYSTONE
# interlude (q14). The apex beats (q18 / q20, conquest_any) are AXIS-FLEXIBLE: surviving
# a Spirit Raid OR downing a World Boss satisfies them identically (DECISIONS #4).
#
# "magic" never appears (arcane/ancient/potent only).
# ------------------------------------------------------------

# --- Chapter 1: Glyphs (forge a glyph + raise a home totem) ----------------

# q1 — *** SEE-IT-ONCE teach beat (skippable:0) ***: forge your first glyph.
#   block_present reads ach.runes_forged (lifetime glyphs forged). NO [Skip ▸] for a
#   newcomer, but a VETERAN who has forged a glyph auto-passes via the lifetime read.
#   count:1 = forge one glyph rune.
data modify storage evercraft:ak_registry quests append value {id:1,title:"The First Glyph",desc:"Forge a glyph rune at a Glyph Forge.",type:"block_present",target:"",count:1,reward:"xp",reward_amt:60,chapter:1,lore:"A Glyph Forge cuts standing signs into rune-stone. Glyphs are the kingdom's grammar — wards, marks and meanings your home and your guild will read.",skippable:0}

# q2 — raise a home totem. lifetime_at target:"hs.totems". SOFT Housing pointer in the
#   lore (S10 — assume a home, never re-teach claiming). lore + default [Skip ▸].
#   count:1 = one totem raised. A veteran with a totem auto-passes via the hs.totems read.
data modify storage evercraft:ak_registry quests append value {id:2,title:"A Totem Over the Hearth",desc:"Raise a glyph totem at your home.",type:"lifetime_at",target:"hs.totems",count:1,reward:"xp",reward_amt:100,chapter:1,lore:"A totem raised over your hearth is a claim the world respects. Home, glyph and guild are one system wearing three faces."}

# q3 — forge more glyphs to deepen your marking. block_present count:3. lore + [Skip ▸].
data modify storage evercraft:ak_registry quests append value {id:3,title:"A Hand of Signs",desc:"Forge 3 glyph runes in all.",type:"block_present",target:"",count:3,reward:"xp",reward_amt:150,chapter:1,lore:"Three runes make a vocabulary. Build & Conquer is the Adventurer's second chapter for a reason — what you conquer, you must also be able to KEEP."}

# q4 — *** INTERLUDE (count:0, beat:interlude) ***: what a glyph IS.
data modify storage evercraft:ak_registry quests append value {id:4,title:"What a Glyph Is",desc:"",type:"interlude",target:"",count:0,reward:"coins",reward_amt:1,chapter:1,beat:"interlude",lore:"A glyph is a promise cut in stone. Kingdoms are built from kept promises."}

# q5 — raise a second totem to extend your hold's reach. lifetime_at hs.totems count:2.
#   lore + default [Skip ▸]. A veteran with two totems auto-passes.
data modify storage evercraft:ak_registry quests append value {id:5,title:"The Watched Bounds",desc:"Raise a second glyph totem (2 in all).",type:"lifetime_at",target:"hs.totems",count:2,reward:"xp",reward_amt:220,chapter:1,lore:"One totem holds a hearth; two hold a bounds. Set your second and the watched ground between them becomes yours in more than name — the glyphs network, the way old wards once did, and your hold begins to feel like a place with edges worth defending."}

# --- Chapter 2: Kingdom (gather a guild + hire laborers) -------------------

# q6 — *** SEE-IT-ONCE teach beat (skippable:0) ***: gather a guild. guild_member reads
#   ec.guild_id. NO [Skip ▸] for a newcomer; a VETERAN already in a guild auto-passes via
#   the ec.guild_id read. This TEACHES the existing guild flow (found via a charter, or
#   accept an invite) — it adds NO new ec.quest trigger (K10).
data modify storage evercraft:ak_registry quests append value {id:6,title:"Gather Your Banner",desc:"Found or join a guild.",type:"guild_member",target:"common",count:1,reward:"crate",reward_amt:1,chapter:2,lore:"A hold of one is a hermitage; a hold of many is a kingdom. Raise a guild banner — found one from a signed charter, or answer another's invitation — and you stop being a lone adventurer and become the center of something. People will gather to a mark that means safety. Give them one.",skippable:0}

# q7 — rise in the guild. lifetime_at target:"ec.guild_rank" count:2. lore + [Skip ▸].
#   (A founder starts Valorous=7, so this auto-passes for them; a fresh recruit climbs.)
data modify storage evercraft:ak_registry quests append value {id:7,title:"A Rank Worth the Banner",desc:"Hold guild rank 2 or higher.",type:"lifetime_at",target:"ec.guild_rank",count:2,reward:"xp",reward_amt:220,chapter:2,lore:"A banner needs a hand to carry it. Earn your standing within the guild — contribute, lead, be relied upon — until your rank says what your deeds already do. A founder wears the high rank from the first day; a recruit earns it. Either way, the guild learns it can lean on you."}

# q8 — *** INTERLUDE (count:0) ***: a kingdom is people, not walls.
data modify storage evercraft:ak_registry quests append value {id:8,title:"A Kingdom Is People",desc:"",type:"interlude",target:"",count:0,reward:"coins",reward_amt:1,chapter:2,beat:"interlude",lore:"Here is the secret the old kings forgot and the good ones remembered: a kingdom is not its borders or its gold. It is the people who choose to stand inside its walls. Every name on your guild roster is a person who decided your mark meant something. Carry that lightly, and carry it well."}

# q9 — hire laborers to work the hold. lb_active count:1. lore + default [Skip ▸].
#   A veteran keeping laborers auto-passes via the ec.lb_count read.
data modify storage evercraft:ak_registry quests append value {id:9,title:"Hands for the Hold",desc:"Hire a laborer to work your kingdom.",type:"lb_active",target:"",count:1,reward:"xp",reward_amt:220,chapter:2,lore:"Walls do not farm; banners do not haul. Hire your first laborer and your hold stops being a place you tend alone and becomes a place that tends itself a little. Give them honest work and they will give you a kingdom that runs while you sleep."}

# q10 — grow the workforce. lb_active count:3. lore + default [Skip ▸].
data modify storage evercraft:ak_registry quests append value {id:10,title:"The Working Hold",desc:"Keep 3 laborers at work in your kingdom.",type:"lb_active",target:"",count:3,reward:"xp",reward_amt:300,chapter:2,lore:"Three hands turn a holding into a household. With laborers at the field, the forge, and the gate, your kingdom hums — and you are freed from the small endless tasks to think about larger ones. A well-run hold is the foundation every conquest is launched from. Yours is nearly ready."}

# q11 — *** INTERLUDE (count:0) — the RUNE-WORD BRIDGE to Tinkering (S14, pure lore) ***
#   A lore-only bridge that POINTS toward the Tinkering line without unlocking or
#   referencing any Tinkering mechanic (Tinkering = Wave C7). No re-teach, no gate.
data modify storage evercraft:ak_registry quests append value {id:11,title:"When Signs Become Words",desc:"",type:"interlude",target:"",count:0,reward:"coins",reward_amt:1,chapter:2,beat:"interlude",lore:"You have forged glyphs, and your laborers have set many more around the hold. Stand among them and you may notice the marks beginning to RHYME — sign answering sign, until a string of them reads almost like a sentence. The old crafters called this a rune-word, and they learned to bind such words into the things they made. That is a deeper art than conquest, and a road for another day; remember it when the Tinkerer's work calls to you. For now, a kingdom waits to march."}

# --- Chapter 3: Conquest (the one-ladder build-and-conquer escalation) -----

# q12 — first conquest: clear a dungeon. lifetime_at target:"ach.dungeons_done" count:1.
#   lore + default [Skip ▸]. A veteran who has cleared a dungeon auto-passes.
data modify storage evercraft:ak_registry quests append value {id:12,title:"March on the Dark",desc:"Clear a dungeon.",type:"lifetime_at",target:"ach.dungeons_done",count:1,reward:"xp",reward_amt:220,chapter:3,lore:"A hold strong enough to hold is strong enough to reach. Take your first dungeon — descend into the dark beyond your bounds, clear what waits there, and come home heavier than you left. This is where build becomes conquer: the kingdom you raised is now the spear you throw."}

# q13 — press the offensive: a FRESH conquest since the chapter began. count_seen count:1
#   (forward delta of dungeons+bosses off ec.ak_seen). lore + default [Skip ▸]. A
#   present-action beat — pre-line conquests do not retro-credit (skippable for vets).
data modify storage evercraft:ak_registry quests append value {id:13,title:"No Going Back",desc:"Win a fresh conquest — clear a dungeon or down a foe since beginning this chapter.",type:"count_seen",target:"",count:1,reward:"xp",reward_amt:300,chapter:3,lore:"The first march is a test; the second is a habit. Press out again — clear another dungeon, or break a foe that has been troubling your bounds — and your kingdom learns that it is not only a place to defend but a power to project. The villages near your hold will start to call you when the dark presses in."}

# q14 — *** INTERLUDE (count:0) — the FLOOR-10 DUNGEON->RAID FUNNEL KEYSTONE (S7, pure
#   lore) ***: narrates how the escalation ladder turns dungeons INTO raids at depth.
#   The keystone of chapter 3's escalation story. No mechanic unlocked here.
data modify storage evercraft:ak_registry quests append value {id:14,title:"Where Dungeons Become Raids",desc:"",type:"interlude",target:"",count:0,reward:"coins",reward_amt:1,chapter:3,beat:"interlude",lore:"Go deep enough and the dark changes its nature. The old dungeons funnel downward, floor on floor, and somewhere around the tenth the corridors open into something larger and hungrier — a Spirit Raid, where the foes no longer wait in rooms but come in waves to meet you. This is the ladder of conquest: every dungeon you clear is a rung toward the raids, and every raid a rung toward the World Bosses beyond. Climb it as far as your hold can carry you."}

# q15 — loot a structure crate from the deep. lifetime_at target:"ach.crates_structure"
#   count:1. lore + default [Skip ▸]. A veteran who has cracked a structure crate auto-passes.
data modify storage evercraft:ak_registry quests append value {id:15,title:"Spoils of the Deep",desc:"Loot a structure crate from a conquered dungeon or stronghold.",type:"lifetime_at",target:"ach.crates_structure",count:1,reward:"xp",reward_amt:300,chapter:3,lore:"Conquest pays. Crack a structure crate from the heart of a cleared dungeon and the deep gives up what it hoarded — coin, gear, the occasional ancient thing. Bring it home to the hold that armed you. A kingdom that feeds itself on its own conquests is a kingdom that does not stop growing."}

# q16 — climb the ladder: clear more dungeons. lifetime_at ach.dungeons_done count:3.
#   lore + default [Skip ▸]. A veteran at 3 dungeons auto-passes.
data modify storage evercraft:ak_registry quests append value {id:16,title:"Up the Ladder",desc:"Clear 3 dungeons in all.",type:"lifetime_at",target:"ach.dungeons_done",count:3,reward:"xp",reward_amt:400,chapter:3,lore:"Three dungeons cleared, and the corridors no longer frighten you — they invite you. You feel the floor-numbers climbing toward the place where dungeons become raids, and you find you want to be there. This is the appetite conquest gives: not greed, exactly, but the certainty that you were built to reach further. Reach."}

# q17 — *** INTERLUDE (count:0) ***: what conquest costs (honest, never moralized).
data modify storage evercraft:ak_registry quests append value {id:17,title:"The Cost of the Crown",desc:"",type:"interlude",target:"",count:0,reward:"coins",reward_amt:1,chapter:3,beat:"interlude",lore:"Be honest with yourself about the price. Every raid risks the hands you hired and the banner you raised; every World Boss can break a kingdom that marched on it unready. Conquest is not free, and a wise ruler counts the cost before the drums. None of this is a reason not to march — only a reason to march well, with your hold strong behind you. Spend your strength like someone who had to earn it. You did."}

# q18 — the APEX (axis-flexible). conquest_any count:1 — survive a Spirit Raid OR down a
#   World Boss (max of dungeons/boss_kills/boss_unique, DECISIONS #4). lore + [Skip ▸].
#   A veteran who has cleared either auto-passes. EITHER road satisfies identically.
data modify storage evercraft:ak_registry quests append value {id:18,title:"The Apex",desc:"Win the apex of conquest — survive a Spirit Raid OR down a World Boss.",type:"conquest_any",target:"",count:1,reward:"xp",reward_amt:400,chapter:3,lore:"Here is the top of the ladder, and there are two ways to stand on it: hold your ground through a Spirit Raid until the last wave breaks against your kingdom, or march on a World Boss and bring it down. Either is the apex; neither is the lesser road. Choose the conquest that suits the hold you built — and when it is done, you will know exactly what your kingdom is worth."}

# q19 — *** INTERLUDE (count:0) ***: the finale reflection (before the deepening capstone).
data modify storage evercraft:ak_registry quests append value {id:19,title:"What You Built",desc:"",type:"interlude",target:"",count:0,reward:"coins",reward_amt:1,chapter:3,beat:"interlude",lore:"Stand in your hold a moment and look at what you made of it: a glyph carved into a hearth, a banner with names beneath it, hands at work in the fields, and a road of cleared dark running out from your gate to the apex and back. You did not find this kingdom. You built it, rung by rung, and then you conquered with it. Few ever do both. Take the quiet — you have earned it — and then go deeper still."}

# q20 — FINALE: deepen the conquest. conquest_any count:3 (axis-flexible — three apex
#   deeds on EITHER road). lore + default [Skip ▸]. q20 is a soft finale, not a hard
#   cap: advance reads N dynamically, so appending load_batch_1 later auto-extends the
#   line — q20's finish() only fires while N==20.
data modify storage evercraft:ak_registry quests append value {id:20,title:"A Name Carved in the Land",desc:"Deepen your conquest — win 3 apex deeds in all (raids survived or World Bosses downed).",type:"conquest_any",target:"",count:3,reward:"xp",reward_amt:500,chapter:3,lore:"Once is a victory; three times is a reign. Whether you held three raids or felled three World Bosses or braided the two roads together, the land now carries your mark the way the old holds carried theirs — not as a rumor but as a fact. You built a kingdom and conquered with it, and Forevercraft will remember the shape of what you raised long after you have walked on to the next horizon. The crown is yours. It always was."}

# ------------------------------------------------------------
# HAND-OFF TO load_batch_1 (future Build & Conquer chapters):
#   - This batch ends at id=20. The next batch's FIRST quest MUST be id=21 (list index
#     20), appended immediately after q20, contiguously.
#   - registry/load calls load_batch_0; add the load_batch_1 call there when it lands.
#     Do NOT renumber this batch.
# ------------------------------------------------------------
