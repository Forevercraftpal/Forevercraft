# AK check helper — lb_active (the player has hired laborers). @s = player. Catch-up
# beat. Reads ec.lb_count (the count of laborers the player has hired, laborer-owned,
# written by laborer/reconcile_count) DIRECTLY and satisfies when it reaches
# quest.count (#ak_count ec.temp). This is the chapter-2 "put the kingdom to work"
# beat — hire the hands that serve your hold. A veteran who already keeps laborers
# auto-passes on the next 20t check at full reward (R1).
#
# Called `with storage evercraft:ak_cur o` (the check_macro passes it for uniformity);
# this helper ignores the macro args and reads a fixed mirror, so it is a PLAIN (non-$)
# file.
#
# READ-ONLY: reads ec.lb_count (laborer-owned). Writes NO laborer objective (the
# no-write proof over the laborer engine).
scoreboard players set #ak_satisfied ec.temp 0
execute if score @s ec.lb_count >= #ak_count ec.temp run scoreboard players set #ak_satisfied ec.temp 1
