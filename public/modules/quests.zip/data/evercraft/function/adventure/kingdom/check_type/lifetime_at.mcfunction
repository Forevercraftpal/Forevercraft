# AK check helper — lifetime_at (a named lifetime mirror reaches a threshold). @s =
# player. Catch-up beat + MACRO body. Called `with storage evercraft:ak_cur o`, o =
# the current quest. Reads the objective NAMED by quest.target DIRECTLY and satisfies
# when its value reaches quest.count (#ak_count ec.temp). This is the generic lifetime
# threshold reader the kingdom line uses for several mirrors:
#   target:"hs.totems"          -> chapter 1: home totems raised (housing-owned)
#   target:"ec.guild_rank"      -> chapter 2: guild rank depth (guild-owned)
#   target:"ec.lb_count"        -> chapter 2: laborers hired (laborer-owned)
#   target:"ach.dungeons_done"  -> chapter 3: dungeons cleared (achievements-owned)
#   target:"ach.crates_structure" -> chapter 3: structure crates looted (achievements-owned)
# A veteran whose named mirror already clears the count auto-passes on the next 20t
# check at full reward (R1). S10: these are SOFT lifetime reads — never a hard gate on
# being at home; a homeless player simply hasn't raised the mirror yet (the lore
# points at the Housing/Builder path, never re-teaches it).
#
# READ-ONLY: reads ONLY the named mirror via `scoreboard players get @s $(target)` —
# a pure read; writes NO foreign objective (the no-write proof). Folds the value into
# a private temp register (#ak_lt_val), never writes back.
scoreboard players set #ak_satisfied ec.temp 0
# Pre-zero so an unset target score (player never touched the mirror) reads as 0
# instead of leaking the previous register value (store result is a no-op on a failed
# `get`, so the default must be set first).
scoreboard players set #ak_lt_val ec.temp 0
$execute store result score #ak_lt_val ec.temp run scoreboard players get @s $(target)
execute if score #ak_lt_val ec.temp >= #ak_count ec.temp run scoreboard players set #ak_satisfied ec.temp 1
