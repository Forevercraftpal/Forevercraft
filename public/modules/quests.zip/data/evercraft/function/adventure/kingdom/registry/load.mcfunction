# ============================================================
# Build & Conquer (Adventure-B) — Registry load (storage init + batch dispatch)
# ============================================================
# Initializes the quest registry storage to an empty list, then calls each
# load_batch_K to append its quests. The storage is volatile across /reload, so this
# MUST run every reload (called from adventure/kingdom/load).
#
# Registry shape (storage evercraft:ak_registry):
#   {quests:[ {id,title,desc,type,target,count,reward,reward_amt,chapter,
#              [lore],[beat],[skippable]}, ... ]}
#
# Each load_batch_K appends via:
#   data modify storage evercraft:ak_registry quests append value {...}
# Quests are appended in id order so the 0-based list index == (ec.ak_quest - 1).

# Reset to an empty quest list.
data modify storage evercraft:ak_registry quests set value []

# Append the quest batches, in id order (id 1 first => list index 0). Batch 0 is the
# full ~20-beat starter Build & Conquer line: 3 chapters (glyphs / kingdom / conquest),
# 3:1 lore:objective cadence. Later batches (load_batch_1+) extend the line; advance
# reads N (list length) dynamically, so appending a batch auto-extends with no engine
# edit.
function evercraft:adventure/kingdom/registry/load_batch_0
