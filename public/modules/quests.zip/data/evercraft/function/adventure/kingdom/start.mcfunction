# ============================================================
# Build & Conquer (Adventure-B) — Start (begin the line at quest 1)
# ============================================================
# Run as @s = the player. Started from the soft "[Begin Build & Conquer ->]" offer
# button (fired by guild/announce_create's one-shot offer, gated ec.chron_view 1/3 +
# ec.ak_active 0 + ec.ac_active matches 2 — sequenced AFTER Adventure-A) OR the
# Adventurer Tier-2 "Build & Conquer" row OR the temp admin entry. Sets the linear
# pointer to quest 1, loads it, shows the intro + first objective. WRITER of the
# initial pointer state.
#
# Dup-guard: callers gate on `ec.ak_active matches 0`, but be defensive here too —
# a re-entrant start must NOT re-seed the cursor or reset progress.

# === DUP-GUARD: already on (or past) the line? Do nothing. ===
execute if score @s ec.ak_active matches 1.. run return 0

# Unified UI-click FX (Joseph 2026-06-05): tellraw-option click — play the gated cue once on a real start
# (after the dup-guard, so a stale re-click stays a silent no-op).
function evercraft:fx/ui/click

# === ACTIVATE + RESET LINEAR STATE ===
scoreboard players set @s ec.ak_active 1
# Auto-track this line for the [Skip ▸] button (Wiring #52): Build & Conquer = slot 7
# (do_skip value-map). Latest-activated line wins; finish clears it if still pointed
# here. (After the dup-guard above, so a re-click never re-tracks a line already past.)
scoreboard players set @s ec.gq_track 7
scoreboard players set @s ec.ak_quest 1
scoreboard players set @s ec.ak_prog 0
scoreboard players set @s ec.ak_done 0
scoreboard players set @s ec.ak_complete 0
# Seed the conquest cursor at the player's current lifetime conquest count so deeds
# completed BEFORE the line began never retro-credit the present chapter-3
# `conquest_any` / `count_seen` beats (forward-only). The cursor is the COMBINED
# chapter-3 forward counter (dungeons cleared + bosses downed); check_progress
# advances ec.ak_prog off it. The catch-up TYPES (block_present / lifetime_at /
# guild_member, and the high-threshold conquest beats) read their lifetime mirror
# DIRECTLY (so a veteran still auto-passes at full reward — S8: there is no separate
# lifetime raid/blueprint counter, so this combined forward cursor + the
# ec.cf_axp_build veteran catch-up cover it). (S8: re-snapshotted at chapter-3 entry
# is unnecessary — the cursor seeded at line-start is already forward-only for every
# chapter-3 beat, and chapter 1/2 beats read fixed mirrors, not the cursor.)
scoreboard players operation @s ec.ak_seen = @s ach.dungeons_done
scoreboard players operation @s ec.ak_seen += @s ach.boss_kills

# Load quest 1 into ak_cur for the objective display.
function evercraft:adventure/kingdom/get_quest

# Give the King's Codex (dup-guarded) so the player can re-open this line's overview
# at will. Build & Conquer has NO first-action engine splice (adding a board trigger
# is forbidden, K10), so the book arrives WITH the line start (offer button / Tier-2
# row / admin), not on a first deed.
function evercraft:adventure/kingdom/book/give

# === INTRO ACTION-BAR (mirrors the C5 start tone, kingdom-keyed) ===
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"Build & Conquer",color:"gold",bold:true},{text:" ✦",color:"gold"}]
scoreboard players set #ndur ec.temp 50
function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"You have a home, adventurer — now make it a seat of power. Carve a glyph, raise a totem over your hearth, gather a guild and the laborers to serve it, and when your hold is strong, march out and conquer. The road is yours to walk however you choose.",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.player.levelup master @s ~ ~ ~ 0.4 1.4
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.beacon.activate master @s ~ ~ ~ 0.5 1.6

# Subtle title flash, then show the first objective.
title @s times 5 40 10
title @s subtitle {text:"Your first task awaits",color:"gray",italic:true}
function evercraft:adventure/kingdom/show_objective
# Pacing (q1-lore fill 2026-06-10, mirror build_quests/start): deliver quest 1's lore line
# (muted in Quick Mode) + [Skip ▸] button — advances get this via on_advance_notify; the start
# path was the one chat-silent entry.
data modify storage evercraft:qp_cur o set from storage evercraft:ak_cur quest
function evercraft:quest_pacing/render_lore
