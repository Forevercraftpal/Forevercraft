# ============================================================
# Build & Conquer (Adventure-B) — per-player catch-up body (WA63-PERF-CHECKPROG-SCANS)
# ============================================================
# Run as @s = a single active, non-complete Build & Conquer player. Called once per
# player from a SINGLE @a[scores={ec.ak_active=1,ec.ak_complete=0}] scan in
# check_progress (collapsing the former 4 @a passes into 1 scan + this body fn —
# matching the build_quests loop shape). Does the two per-player jobs:
#   1. CATCH-UP / INTERLUDE auto-pass via check (existence-gated + idempotent).
#   2. RE-SYNC the overview progress bar (ec.ak_prog, one writer):
#      ak_prog = (ach.dungeons_done + ach.boss_kills) - ec.ak_seen, clamped at 0 via
#      the seed (always <= the live sum). Harmless for non-conquest beats.

# 1. Run the catch-up / interlude check.
function evercraft:adventure/kingdom/check

# 2. Re-sync the conquest-since-start progress bar (one writer of ec.ak_prog here).
scoreboard players operation @s ec.ak_prog = @s ach.dungeons_done
scoreboard players operation @s ec.ak_prog += @s ach.boss_kills
scoreboard players operation @s ec.ak_prog -= @s ec.ak_seen
