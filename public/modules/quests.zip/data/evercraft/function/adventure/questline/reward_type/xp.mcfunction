# AC reward — xp (VANILLA player experience). @s = player. MACRO body.
# Called `with storage evercraft:ac_cur o`, o = the completed quest (reward_amt int).
#
# The Awakening is an ADVENTURER line, not a crafter line: there is NO "Adventuring"
# artisan category (add_xp feeds cats 0-6 Mining..Alchemy only), and the live
# Adventurer economy (the village quest board, quests/active/complete_tier*) pays
# vanilla XP via `experience add @s N points`. So this reward pays vanilla player
# experience — matching the board economy this line teaches, never mislabeling an
# Adventurer reward as a crafter skill. NOTHING here touches ec.cf_xp / a crafter
# category; `internal_grant` / add_xp are NOT used (by design, not omission).
#
# `experience add` needs a literal amount, so the grant line is a macro on the
# reward_amt field. #ac_reward_amt ec.temp (set by reward_macro) drives the tellraw.
$experience add @s $(reward_amt) points
# BAKE the amount as a literal $(reward_amt) — NOT a live {score:#ac_reward_amt} ref, which the queued
# notify resolves at DISPLAY time after a multi-advance cascade overwrote the temp (build_quests bug class).
$data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"#55FFFF"},{text:"Reward: ",color:"yellow"},{text:"$(reward_amt)",color:"#55FFFF"},{text:" Experience",color:"#55FFFF"},{text:" ✦",color:"#55FFFF"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.experience_orb.pickup master @s ~ ~ ~ 0.6 1.0
