# ============================================================
# The Awakening (Adventure-A) — per-player catch-up body (WA63-PERF-CHECKPROG-SCANS)
# ============================================================
# Run as @s = a single active, non-complete Awakening player. Called once per player
# from a SINGLE @a[scores={ec.ac_active=1,ec.ac_complete=0}] scan in check_progress
# (collapsing the former 3 @a passes into 1 scan + this body fn — matching the
# build_quests loop shape). Does the two per-player jobs:
#   1. CATCH-UP / INTERLUDE auto-pass via check (existence-gated + idempotent).
#   2. RE-SYNC the overview progress bar (ec.ac_prog, one writer):
#      ac_prog = ach.quests_done - ec.ac_seen, clamped at 0 via the seed (always
#      <= ach.quests_done). Harmless for non-board beats.

# 1. Run the catch-up / interlude check.
function evercraft:adventure/questline/check

# 2. Re-sync the board-quests-since-start progress bar (one writer of ec.ac_prog here).
scoreboard players operation @s ec.ac_prog = @s ach.quests_done
scoreboard players operation @s ec.ac_prog -= @s ec.ac_seen
