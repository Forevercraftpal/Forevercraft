# AC check helper — showcase_viewed (the Reaper Alignment showcase is meaningful).
# @s = player. Catch-up beat. The Reaper showcase (reaper/showcase/spawn_alignment)
# displays the player's standing; it only says something once the axis is non-zero.
# This beat satisfies when the SUM of rp.renown + rp.infamy reaches quest.count —
# i.e. the player has accrued enough TOTAL deeds (on either or both roads) that their
# alignment showcase reads as a real legend rather than blank Neutral. Axis-agnostic
# and strictly neutral (Decision #3): renown and infamy both count toward "you have a
# face the village remembers". A veteran with deeds on either road auto-passes on the
# next 20t check at full reward (R1).
#
# READ-ONLY: reads rp.renown + rp.infamy (reaper-owned). We sum into a private temp
# register (#ac_show_sum), never write rp.* (the no-write proof). The chapter-3 lore
# POINTS the player at the showcase (Codex -> Reaper alignment, read-only reuse of
# reaper/showcase/spawn_alignment — no edit, S5); this check just confirms the axis
# has moved enough for the showcase to mean something.
scoreboard players set #ac_satisfied ec.temp 0
scoreboard players operation #ac_show_sum ec.temp = @s rp.renown
scoreboard players operation #ac_show_sum ec.temp += @s rp.infamy
execute if score #ac_show_sum ec.temp >= #ac_count ec.temp run scoreboard players set #ac_satisfied ec.temp 1
