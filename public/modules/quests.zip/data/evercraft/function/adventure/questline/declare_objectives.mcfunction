# ============================================================
# The Awakening (Adventure-A) — One-time scoreboard objective declarations.
# (Structural clone of cooking/questline/declare_objectives, Council #2 Wave C5 —
#  the FIRST Adventurer chronicle line.) Split from adventure/questline/load so the
#  per-/reload "Objective already exists" warnings only fire once. Gated by
#  `#ac_loaded ec.var matches 1` — set at the bottom of this file.
# ============================================================
# A paced, always-skippable Adventure line: a sibling Fisher's clone that only
# READS public adventure state (ec.dream_rate / ec.dr_peak / ec.dream_rank for
# chapter 1; ec.qp_active + ach.quests_done board pointers for chapter 2;
# rp.renown / rp.infamy / rp.tier for chapter 3). It WRITES none of those engines'
# objectives — the no-write proof. It is pacing-aware from the start (lore/beat/
# skippable) — see check.mcfunction (interlude guard), on_advance_notify + overview
# (render_lore), and the registry rows that carry `lore`.
#
# NOTE: ec.qp_* is OCCUPIED by the live village quest-preview system; rp.* is the
# live Reaper axis; ec.ag_* is the Adventurer Card. This line uses the council-
# locked ec.ac_* family ONLY.

# === CORE LINEAR-POINTER SCOREBOARDS (mirror ec.cq_*; one writer each) ===
# ec.ac_active — 0/1, has this player started The Awakening line?
#   WRITER: adventure/questline/start (sets 1). The completion path sets it to 2
#   (via finish) so the sequenced Adventure-B offer (Wave C6, ec.ac_active matches 2)
#   can detect "Adventure-A complete" — but every gate in THIS line treats it as
#   "1.. = active". (start sets 1; finish bumps to 2 on the final quest.)
scoreboard objectives add ec.ac_active dummy "Awakening Active"
# ec.ac_quest — current quest index, 1..N. The ONLY linear pointer.
#   WRITER: adventure/questline/start (sets 1) + adventure/questline/advance (+1, clamped at N).
scoreboard objectives add ec.ac_quest dummy "Awakening Quest Index"
# ec.ac_prog — progress within the current quest, surfaced ONLY in the overview
#   progress bar. The Adventure check types are all READ-DERIVED (they compute their
#   satisfied condition from a public mirror + the ec.ac_seen cursor into ec.temp,
#   never persisting a per-deed tally), so the single persistent writer of ac_prog
#   is the reset path — keeping it strictly one-writer.
#   WRITER (reset to 0): adventure/questline/start + adventure/questline/advance.
#   WRITER (live mirror for the bar): adventure/questline/check_progress re-syncs it
#     to the present-beat board-quest delta (one writer, on the 20t loop).
scoreboard objectives add ec.ac_prog dummy "Awakening Quest Progress"
# ec.ac_done — lifetime completed quest count (overview + the ec.gq_track value).
#   WRITER: adventure/questline/advance (+1) + adventure/questline/start (sets 0 on first start).
scoreboard objectives add ec.ac_done dummy "Awakening Quests Done"
# (NO ec.ac_title — per the wave spec the Awakening line rewards only xp/coins/crate.
#  Adventurer identity comes from the Reaper alignment + the Adventurer Card (A3);
#  no reward_type/title file exists in this engine.)

# === COMPLETION SENTINEL ===
# ec.ac_complete — 0/1, set once when the player finishes the final quest so the
#   "line complete!" tellraw fires exactly once. WRITER: adventure/questline/advance
#   (via finish) + adventure/questline/start (sets 0 on first start).
scoreboard objectives add ec.ac_complete dummy "Awakening Complete"

# === LIFETIME-THRESHOLD CATCH-UP CURSOR (forward-only, no-penalty) ===
# ec.ac_seen — snapshot of ach.quests_done taken at start. The present-action
#   `quest_count_seen` beat reads (ach.quests_done - this) as the count of board
#   quests completed SINCE the line began, so pre-activation quests never retro-
#   credit the present beat (forward cursor). The catch-up TYPES (score_at_least /
#   tier_reached / dream_entered / align_shifted / showcase_viewed) read their
#   lifetime mirror DIRECTLY, so a veteran auto-passes at full reward. WRITER:
#   adventure/questline/start (seeds it) + adventure/questline/check_progress
#   (re-syncs the live ec.ac_prog delta).
scoreboard objectives add ec.ac_seen dummy "AC Quests-Done Cursor"

# === ONE-SHOT SOFT-OFFER LATCH (sole writer: dream_rank/rank_up's +1 gated line) ===
# ec.ac_offer — 0/1, set to 1 the first time the soft "[Begin the Adventure
#   Chronicle ->]" auto-offer fires on a dream-rank gain (S9), so it never re-fires.
#   The offer is gated ec.chron_view matches 1/3 + ec.ac_active matches 0. The
#   button itself calls adventure/questline/start. WRITER: dream_rank/rank_up (the
#   +1 gated line — sole writer; the strip-reset is the documented exception, like
#   ec.gq_offered).
scoreboard objectives add ec.ac_offer dummy "Awakening Offer Latch"

# Mark declarations done so re-/reload skips this file.
scoreboard players set #ac_loaded ec.var 1
