# ============================================================
# The Awakening (Adventure-A) — One-time soft BEGIN offer (S9)
# ============================================================
# Run as @s = the player. Called from dream_rank/rank_up's ONE additive gated line
# on a dream-rank gain. Fires the ONE-TIME Seven-voice soft offer to begin The
# Awakening — the FALLBACK to begin the line is always the Adventurer Tier-2 row, which
# renders a real clickable [Begin →] START surface (WA63-D1, Adv.GqStart9 ->
# questline/start) whenever the line is not yet begun. So this offer is a convenience
# nudge, not the only door — declining it never locks the line out.
#
# GATING (the caller's single line gates these; re-guarded here defensively):
#   - ec.chron_view matches 1 (Adventurer) OR 3 (Both) — a Crafter-only player
#     (view 2) NEVER sees the Adventure offer.
#   - ec.ac_active matches 0 — never offered to someone already on (or past) the line.
#   - ec.ac_offer matches 0 — one-shot; set to 1 at the END so a mid-fn failure
#     doesn't permanently swallow a never-shown offer. SOLE WRITER of ec.ac_offer is
#     this function (called from rank_up); the strip-reset is the documented exception.
#
# IMMERSION LAW (no /trigger): the begin affordance is a clickable chat button whose
# click_event runs adventure/questline/start directly (the locked "offer surface"
# default — round-1 DECISIONS: clickable chat prompt with a function click_event).
# Declining = simply not clicking; the offer never re-fires (ec.ac_offer latch).
# Mirrors gq/offer_prompt verbatim.
#
# NOTIFY (alert class, mute_at:99, key "ac_offer"): the Seven-voice chime/flash
# routes through util/notify/dispatch so it respects the player's global ec.notify
# filter. mute_at:99 means the [Mute] button effectively never appears — a one-shot
# offer, not a repeating nudge. The clickable [Begin ->] button is INDEPENDENT of
# the chatter gate: a player with notifications OFF still gets the offer + can begin.

# === Re-guard the latches (caller already gated; defensive against re-entry) ===
execute if score @s ec.ac_offer matches 1 run return 0
execute if score @s ec.ac_active matches 1.. run return 0
# Re-guard the lens too (1 = Adventurer, 3 = Both; never view 2 = Crafter-only).
execute unless score @s ec.chron_view matches 1 unless score @s ec.chron_view matches 3 run return 0

# === 1) MUTABLE Seven-voice OFFER nudge (alert class) ===
function evercraft:util/notify/dispatch {key:"ac_offer",class:"alert",mute_at:99}
# Only the chime/flash respects the dispatcher's approval (global ec.notify filter).
execute if score #notif_show_ac_offer ec.temp matches 1 run title @s times 8 50 12
execute if score #notif_show_ac_offer ec.temp matches 1 run title @s subtitle {text:"A road is opening",color:"red",italic:true}
execute if score #notif_show_ac_offer ec.temp matches 1 if score @s ec.fx_snd matches 1.. run playsound minecraft:block.beacon.activate master @s ~ ~ ~ 0.7 1.5

# === 2) THE OFFER itself (always shown — independent of the chatter chime) ===
# A quiet Seven-voice card. The [Begin the Adventure Chronicle ->] button is the one
# interaction-driven affordance (function click_event, non-op-safe per the
# gq/offer_prompt precedent). One-shot: it can be clicked once; clicking it runs
# adventure/questline/start (which dup-guards on ec.ac_active).
tellraw @s ""
tellraw @s [{text:"  ⚔ ",color:"red"},{text:"The Awakening",color:"red",bold:true,italic:false}]
tellraw @s [{text:"  Your dreams are rising, and a longer road",color:"gray",italic:true}]
tellraw @s [{text:"  is opening beneath them — through the village",color:"gray",italic:true}]
tellraw @s [{text:"  board and on to the legend you will become,",color:"gray",italic:true}]
tellraw @s [{text:"  renowned or infamous, as you choose.",color:"gray",italic:true}]
tellraw @s ""
tellraw @s [{text:"  ",color:"dark_gray"},{text:"[Begin the Adventure Chronicle →]",color:"#FF8C8C",bold:true,hover_event:{action:"show_text",value:[{text:"Start The Awakening — a paced, fully skippable Adventurer line.",color:"gray"},"",{text:"You can also begin it any time from the Grand Quests hub (Adventurer → The Awakening).",color:"dark_gray",italic:true}]},click_event:{action:"run_command",command:"/function evercraft:adventure/questline/start"}}]
tellraw @s [{text:"  ",color:"dark_gray"},{text:"(or simply walk on — the offer will not return)",color:"dark_gray",italic:true}]
tellraw @s ""

# === 3) LATCH the offer (sole writer of ec.ac_offer) ===
# Set LAST so a failure above doesn't permanently swallow a never-shown offer.
scoreboard players set @s ec.ac_offer 1
