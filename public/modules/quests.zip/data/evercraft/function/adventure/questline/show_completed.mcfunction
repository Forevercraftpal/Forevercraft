# ============================================================
# The Awakening (Adventure-A) — Show completed quest (just-finished one)
# ============================================================
# Reads the just-completed quest from ac_cur.quest (still the OLD quest at this
# point in advance, before the pointer is bumped) and prints a green checkmark
# line. Mirrors the Cook/Fisher show_completed tone.
# Run as @s = the player.

data modify storage evercraft:ac_cur o set from storage evercraft:ac_cur quest
function evercraft:adventure/questline/show_completed_macro with storage evercraft:ac_cur o
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.player.levelup master @s ~ ~ ~ 0.4 1.8
