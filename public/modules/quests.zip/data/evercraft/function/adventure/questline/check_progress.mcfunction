# ============================================================
# The Awakening (Adventure-A) — 20t catch-up / interlude scheduler
# ============================================================
# Self-rescheduling, EXISTENCE-GATED 20t loop (kicked from adventure/questline/load
# with `replace`). It does work ONLY for players on the line
# (@a[scores={ec.ac_active=1,ec.ac_complete=0}]), so with no Awakening players it
# iterates over NOTHING — no per-tick @a scan (the datapack's perf law).
#
# IMPORTANT (ec.ac_active range): the selector uses `ec.ac_active=1` exactly (NOT
# 1..) because finish() bumps ec.ac_active to 2 on completion — a value-2 player is
# DONE and must not be re-scanned. A value-1 + complete-0 player is the active set.
#
# This line has NO per-action engine splice (it would add ec.quest board triggers,
# which is forbidden — it protects round-1 trigger 42, S9/A7). So the 20t loop is
# the SOLE driver: every check type is READ-DERIVED over a public mirror, so this
# loop catches each satisfied beat (a board quest completed, a dream rank gained, a
# tier reached) within ~1s. Two jobs per active player (both via check):
#   1. CATCH-UP (R1): a score_at_least / tier_reached / dream_entered / align_shifted
#      / showcase_viewed beat whose lifetime threshold the player's mirror already
#      clears auto-satisfies on this tick and pays full reward — a veteran is never
#      walled. Those helpers read the lifetime mirror directly.
#   2. INTERLUDE auto-pass (C0, SCHEMA_DELTA §3): a beat:"interlude"/count:0 beat is
#      instantly satisfied by check()'s interlude guard, so it advances here on the
#      next tick — delivering its lore once, paying its tiny reward once.
#
# The forward-only ec.ac_quest cursor (one advance per satisfied beat, inside
# advance) makes this no-double-credit and no-penalty.

# === RUN BOTH PER-PLAYER JOBS IN A SINGLE @a SCAN (WA63-PERF-CHECKPROG-SCANS) ===
# ONE @a[scores={ec.ac_active=1,ec.ac_complete=0}] pass into a tiny per-player body fn
# (check_progress_player) that does BOTH the catch-up check AND the ac_prog re-sync —
# collapsing the former 3 @a passes into 1 (the build_quests loop shape). check() is
# existence-gated + idempotent; the selector keeps the per-tick cost zero off-line.
# ec.ac_prog stays one-writer (the body fn is its only persistent writer besides reset):
# ac_prog = ach.quests_done - ec.ac_seen, clamped at 0 via the seed.
execute as @a[scores={ec.ac_active=1,ec.ac_complete=0}] run function evercraft:adventure/questline/check_progress_player

# Re-schedule self.
schedule function evercraft:adventure/questline/check_progress 20t replace
