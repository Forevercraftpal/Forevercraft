# ============================================================
# The Awakening (Adventure-A) — Reward (pay out the completed quest)
# ============================================================
# Run as @s = the player. Reads the just-completed quest's reward fields from
# ac_cur.quest and dispatches on reward type. ac_cur still holds the OLD (just-
# completed) quest at this point (reward runs BEFORE advance bumps the pointer).
#
# Reward fields: reward (xp|coins|crate), reward_amt (int), target (crate tier).
# NO `title` reward type exists in this engine (per the wave spec — The Awakening
# pays only xp/coins/crate; Adventurer identity comes from the Reaper alignment +
# the Adventurer Card, A3).
#
# XP NOTE (deliberate, design ref §10 / wave spec): the `xp` reward pays VANILLA
# player experience (`experience add @s N points`), NOT artisan XP. The frozen
# add_xp contract feeds the SIX crafter categories (0-6 Mining..Alchemy) — there
# is NO "Adventuring" artisan category, and the live Adventurer reward economy (the
# village quest board, quests/active/complete_tier*) pays vanilla XP. Routing an
# Adventurer reward through a crafter category would mislabel it; vanilla XP matches
# the board economy this line teaches. `internal_grant` is never used.

# Flatten the quest fields for the reward macro.
data modify storage evercraft:ac_cur o set from storage evercraft:ac_cur quest
function evercraft:adventure/questline/reward_macro with storage evercraft:ac_cur o

# === ADDITIVE: D-Q10-REWARD artifact (Artifact-Fusion w1) ===
# On TOP of the q10 xp reward above ("Known on Every Board"). Fires only when the
# just-completed quest is #10 (ec.ac_quest still holds 10 here — advance bumps the
# pointer AFTER reward). Adventure-A q10 -> Wishing Shard (#3, Family B Dream/DR
# leaf). One-shot per the pointer-equals-10 gate. Inv-full aware via the shared
# helper.
execute if score @s ec.ac_quest matches 10 run data modify storage evercraft:q10r args set value {lt:"artifacts/common/wishing_shard",name:"Wishing Shard",color:"white"}
execute if score @s ec.ac_quest matches 10 run function evercraft:artifacts/give/q10_reward with storage evercraft:q10r args
