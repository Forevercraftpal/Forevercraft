# Run as operator (testing). Temp entry to hand yourself the Adventurer's Codex +
# start The Awakening line before the canonical entries (the soft dream-rank offer
# and the Adventurer Tier-2 row) are exercised.
# Usage: /execute as <player> run function evercraft:adventure/questline/admin/give_book_temp
# (debug) — starts the line if not already active (start gives the book, dup-guarded).
execute unless score @s ec.ac_active matches 1.. run function evercraft:adventure/questline/start
# If already on the line, just (re)hand the book in case it was lost.
execute if score @s ec.ac_active matches 1.. run function evercraft:adventure/questline/book/give
