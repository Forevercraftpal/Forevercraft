# ============================================================
# The Awakening (Adventure-A) — Finish (one-shot completion fanfare)
# ============================================================
# Run as @s = the player who just completed the final quest. Sets the
# ec.ac_complete sentinel so this fires exactly once, then prints the
# "line complete!" celebration. WRITER of ec.ac_complete (with advance).
#
# SEQUENCING (S9): on completion this bumps ec.ac_active 1 -> 2. Adventure-B's
# soft offer (Wave C6) gates on `ec.ac_active matches 2`, so finishing The
# Awakening is what UNLOCKS the Build & Conquer offer. Every gate in THIS line
# uses `ec.ac_active matches 1..` so the 1->2 bump is transparent to it.

# Guard: only ever fire once.
execute if score @s ec.ac_complete matches 1 run return 0
scoreboard players set @s ec.ac_complete 1

# Mark Adventure-A complete for the sequenced Adventure-B offer (C6 reads this).
scoreboard players set @s ec.ac_active 2

# === ADDITIVE re-offer (WA63-D1, belt-and-suspenders): if the player already holds a
# guild when they finish The Awakening, fire the Build & Conquer offer NOW — the original
# offer only fires at the instant a player CREATES a guild while Awakening-complete, so a
# player who founded/joined their guild BEFORE finishing The Awakening never got it.
# offer_prompt re-guards every latch (ec.ak_offer 0 + ec.ak_active 0 + ec.ac_active 2 +
# lens) so it is self-deduping and race-safe. Gated here on the not-yet-offered/not-active
# latches + an existing guild so it only fires for the trapped cohort. (Runs inside this
# finish's one-shot complete-sentinel guard above, so it can fire at most once.)
execute if score @s ec.ak_offer matches 0 if score @s ec.ak_active matches 0 if score @s ec.guild_id matches 1.. run function evercraft:adventure/kingdom/offer_prompt

# Auto-track repoint (Wiring #52): clear the [Skip ▸] tracker if it was pointed at THIS
# line (The Awakening = slot 9) — a completed line must never accept a skip. (do_skip's
# slot-9 case also gates `ec.ac_active matches 1`, so the 1->2 bump above already blocks
# a skip; clearing the tracker keeps it from sitting on a finished line in the UI.)
execute if score @s ec.gq_track matches 9 run scoreboard players set @s ec.gq_track 0

data modify storage evercraft:notify stage.c set value [{text:"★ ",color:"gold"},{text:"The Awakening — Complete!",color:"red",bold:true},{text:" ★",color:"gold"}]
scoreboard players set #ndur ec.temp 50
function evercraft:util/notify/emit_keep
data modify storage evercraft:notify stage.c set value [{text:"You have learned the dream, the board, and the long road of renown and infamy alike. What you become from here is your own legend to write — and the village will remember it, whichever way you walk.",color:"yellow",italic:true}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit

title @s times 10 60 20
title @s title {text:"Awakened",color:"gold"}
title @s subtitle {text:"The Awakening is complete",color:"yellow"}

execute if score @s ec.fx_snd matches 1.. run playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 1.0 1.0
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.player.levelup master @s ~ ~ ~ 0.6 1.2

# === ADDITIVE: exit handoff (Questline Restructure W4, 2026-06-10) ===
# A finished Path never goes dark: name the repeatable continuation (Heroic board,
# patron bounties, dungeons) and nudge the Grand Chronicle if both branches qualify.
# Runs inside this finish's one-shot complete-sentinel guard.
function evercraft:grand_quests/exit_handoff_adventure

# Clear a stale tracked-Path pin if THIS line was pinned (QR-P5, 2026-06-10).
function evercraft:grand_quests/untrack_on_finish {slot:9}
