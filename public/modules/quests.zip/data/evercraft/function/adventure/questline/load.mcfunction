# ============================================================
# The Awakening (Adventure-A) — Load (objective declarations + registry + schedule)
# ============================================================
# A strictly-linear, data-driven quest line (q1..N in order, one active quest at
# a time), structural clone of cooking/questline/load. Called from init (the pack
# load host) on /reload — see init.mcfunction "THE AWAKENING (ADVENTURE-A)" block.
#
# This is the FIRST Adventurer chronicle line (Council #2 Wave C5): three guided
# chapters teaching Dream Rate<->Rank (chapter 1), the village quest board
# (chapter 2), and the Reaper morality axis — Renown<->Infamy (chapter 3). It is a
# Fisher's clone that only READS public adventure state (ec.dream_rate/ec.dr_peak/
# ec.dream_rank, ec.qp_active + ach.quests_done board pointers, rp.renown/rp.infamy/
# rp.tier) and WRITES none of those engines' objectives — the no-write proof.
#
# NAMESPACE LOCK (Council #2): distinct from ec.ag_* (Adventurer Card), ec.qp_*
# (village quest preview — OCCUPIED), rp.* (reaper). This line uses the council-
# locked ec.ac_* family ONLY (Adventure-A questline). It adds ZERO new ec.quest
# board triggers (it TEACHES the existing buttons — protects round-1 trigger 42).
#
# Declarations are guarded by #ac_loaded ec.var so subsequent /reloads skip the
# re-declaration spam, matching questline/load's P6 polish.
#
# After declaring objectives, this fn ALWAYS (re)loads the registry (the quest
# data storage is NOT persisted across /reload) and (re)kicks the 20t catch-up
# scheduler with `replace` (so /reload never stacks duplicate schedules).

# === ONE-TIME OBJECTIVE DECLARATIONS (skipped on subsequent /reloads) ===
execute unless score #ac_loaded ec.var matches 1 run function evercraft:adventure/questline/declare_objectives

# === REGISTRY (re)load — storage is volatile across /reload, must re-run ===
function evercraft:adventure/questline/registry/load

# === 20t CATCH-UP / INTERLUDE SCHEDULER (self-rescheduling, existence-gated) ===
# check_progress only does work for @a[scores={ec.ac_active=1}] — no per-tick @a
# scan when nobody is on the line. It re-schedules itself; kick once here.
schedule function evercraft:adventure/questline/check_progress 20t replace
