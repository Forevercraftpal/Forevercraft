# AC check helper — dream_entered (live Dream RATE peak). @s = player.
# Reads ec.dr_peak (the STABLE peak Dream Rate, luck x10 — the live "current
# fortune / realm-entry tide", written by dreams/peak/update + dream_rank/calculate)
# DIRECTLY. Satisfied when the peak Rate reaches quest.count (#ac_count ec.temp).
# This is the "raise your Rate" beat — chapter 1 teaches that the RATE is the live
# tide you push up, distinct from the lifetime RANK (S6, NOT conflated; the Rank is
# read by check_type/score_at_least). A veteran whose peak already clears the count
# auto-passes on the next 20t check at full reward (R1).
#
# READ-ONLY: reads ec.dr_peak (dreams-owned). Writes NO dream/board/reaper objective.
scoreboard players set #ac_satisfied ec.temp 0
execute if score @s ec.dr_peak >= #ac_count ec.temp run scoreboard players set #ac_satisfied ec.temp 1
