# ============================================================
# The Awakening (Adventure-A) — Registry batch 0 (the starter line, q1..q16)
# ============================================================
# Appends the first 16 quests onto storage evercraft:ac_registry quests.
# Called by registry/load AFTER it sets quests=[]. MUST append in id order
# (id=1 first => list index 0), contiguous, so list-position == ec.ac_quest-1.
# (Structural clone of cooking/questline/registry/load_batch_0, paced via C0.)
#
# Quest object schema (the engine reads these exact fields):
#   {id:int, title:string, desc:string, type:string, target:string,
#    count:int, reward:string, reward_amt:int, chapter:int,
#    [lore:string], [beat:string], [skippable:int]}      <- C0 fields OPTIONAL
#
# type    -> dispatched by check_type/$(type):
#            dream_entered | score_at_least | board_active | quest_count_seen
#            | align_shifted | tier_reached | showcase_viewed
#            (beat:"interlude"/count:0 auto-passes BEFORE dispatch — SCHEMA_DELTA §3)
# target  -> the check helpers IGNORE it (each reads a fixed public mirror), so it
#             is "" on most beats. On a `reward:"crate"` beat it names the crate
#             TIER consumed by reward_type/crate (common|uncommon|rare|ornate|
#             exquisite|mythical) — the only consumer of target in this batch.
# count   -> dream_entered: ec.dr_peak (peak Dream Rate, luck x10) threshold;
#            score_at_least: ec.dream_rank (1=G..10=SSS) threshold;
#            board_active: IGNORED (flag — "hold a board quest");
#            quest_count_seen: board-quests-since-start delta (off ec.ac_seen);
#            align_shifted: max(rp.renown,rp.infamy) threshold;
#            tier_reached: |rp.tier| threshold (depth on EITHER road);
#            showcase_viewed: rp.renown+rp.infamy sum threshold;
#            interlude: 0 (auto-pass).
# reward  -> xp | coins | crate   (NO title). reward_amt = amount.
#            xp pays VANILLA player experience (Adventurer economy — there is no
#            Adventuring artisan category; matches the village board's vanilla XP).
# chapter -> display grouping: 1=dream, 2=board, 3=reputation.
#
# XP TIER TABLE (vanilla-XP, modest — an Awakening beat is never a fatter XP source
# than a board quest of equal effort):
#   30 / 60 / 100 / 150 / 220 / 300 / 400  (points)
#
# C0 CADENCE (SCHEMA_DELTA §1): every objective beat carries `lore`; interludes sit
# ~3:1 against objective beats (q4 dream-meaning, q9 the-board-as-a-promise, q12
# Renowned Road, q13 Infamous Road — the SYMMETRIC two-roads pair, EQUAL length /
# weight, strictly neutral; q15 exile-cost-with-forgiveness). The two headline teach
# beats q2 (the Rate<->Rank distinction, score_at_least) + q6 (board_active) are
# `skippable:0` "see-it-once" — both still auto-pass a veteran via the lifetime read
# in their check helper (Decision #5).
#
# CHAPTER 3 NEUTRALITY LOCK (Decision #3, S5): the reputation chapter presents
# Renown and Infamy as a SPECTRUM YOU STEER, not a moral pick. The Renowned Road
# (q12) and the Infamous Road (q13) interludes are equal length, equal tone — the
# villain road is "a legend, not a mistake". q15 teaches exile honestly as the
# villain's COST, and names the forgiveness path (village/exile/forgiveness) so the
# road is never a dead end. No beat pays MORE for one road than the other; the
# axis-agnostic check types (align_shifted/tier_reached/showcase_viewed) satisfy on
# EITHER road identically. "magic" never appears (arcane/ancient/potent only).
# ------------------------------------------------------------

# --- Chapter 1: The Dream -------------------------------------------------

# q1 — gentle intro: raise your Dream Rate. Pure on-ramp. lore + default [Skip ▸].
#   dream_entered reads ec.dr_peak (the LIVE tide). count:5 = a peak Rate of 5 (x10).
data modify storage evercraft:ac_registry quests append value {id:1,title:"The First Dream",desc:"Raise your Dream Rate — let your fortune rise to a peak of 5.",type:"dream_entered",target:"",count:5,reward:"xp",reward_amt:30,chapter:1,lore:"Dream Rate is this world's hidden current — gear, luck and deeds raise it, and EVERYTHING pays better as it rises: chests, crates, structures, the Pass. Watch the number; it watches you."}

# q2 — *** SEE-IT-ONCE teach beat (skippable:0) ***: the headline Rate<->Rank
#   distinction. score_at_least reads ec.dream_rank (the LIFETIME tally). NO [Skip ▸]
#   for a newcomer, but a VETERAN auto-passes via the lifetime ec.dream_rank read.
#   count:1 = reach Rank G. The lore is the WHOLE POINT: Rate is the live tide, Rank
#   is the lifetime master-mark — they are NOT the same number (S6).
data modify storage evercraft:ac_registry quests append value {id:2,title:"Rate Is Not Rank",desc:"Earn your first Dream Rank — reach Rank G.",type:"score_at_least",target:"",count:1,reward:"xp",reward_amt:60,chapter:1,lore:"Rate is the tide, Rank is the watermark: your PEAK Dream Rate earns the ranks G through SSS, and each rank opens doors — crate tiers, housing, guild cards. Raise the peak once and it is yours forever.",skippable:0}

# q3 — push the Rate higher to settle into the rhythm. lore + default [Skip ▸].
data modify storage evercraft:ac_registry quests append value {id:3,title:"A Higher Tide",desc:"Raise your Dream Rate to a peak of 12.",type:"dream_entered",target:"",count:12,reward:"xp",reward_amt:100,chapter:1,lore:"A peak of 12 opens the world's better chests. Wear what raises you, enshrine artifacts in the Codex Vault, and let every system you touch add its drop to the river."}

# q4 — *** INTERLUDE (count:0, beat:interlude) ***: a breather on what the dream is FOR.
data modify storage evercraft:ac_registry quests append value {id:4,title:"What the Dream Is For",desc:"",type:"interlude",target:"",count:0,reward:"coins",reward_amt:1,chapter:1,beat:"interlude",lore:"The dream is FOR something: it gates the ornate, the exquisite and the mythical. The Adventurer's whole chronicle is learning to raise it on purpose."}

# q5 — climb the Rank. lore + default [Skip ▸]. score_at_least reads ec.dream_rank
#   (lifetime catch-up — a veteran at Rank E auto-passes at full XP). count:3 = Rank E.
data modify storage evercraft:ac_registry quests append value {id:5,title:"The Climb Begins",desc:"Reach Dream Rank E.",type:"score_at_least",target:"",count:3,reward:"xp",reward_amt:150,chapter:1,lore:"Rank by rank the master-mark rises, and with it the quiet certainty that you belong to this world. G, F, E — each one a night you did not waste. The legend is starting to take shape, and it is yours."}

# --- Chapter 2: The Board --------------------------------------------------

# q6 — *** SEE-IT-ONCE teach beat (skippable:0) ***: the village quest board. NO
#   [Skip ▸] for a newcomer; a VETERAN holding a board quest auto-passes via the
#   ec.qp_active read in check_type/board_active. This TEACHES the existing board
#   buttons — it adds NO new ec.quest trigger (protects round-1 trigger 42, S9/A7).
data modify storage evercraft:ac_registry quests append value {id:6,title:"The Village Board",desc:"Find a village quest board and accept a quest from it.",type:"board_active",target:"common",count:1,reward:"crate",reward_amt:1,chapter:2,lore:"Every village keeps a board, and every board keeps a need. Stand before one, read what the people ask of you, and take a task into your hands. This is how an adventurer becomes known — one promise kept at a time.",skippable:0}

# q7 — complete a board quest. quest_count_seen reads the forward delta off
#   ec.ac_seen. lore + default [Skip ▸]. count:1 = one quest finished since you began.
data modify storage evercraft:ac_registry quests append value {id:7,title:"A Promise Kept",desc:"Complete a village board quest.",type:"quest_count_seen",target:"",count:1,reward:"xp",reward_amt:150,chapter:2,lore:"Accepting is easy; finishing is the whole of it. Bring back what the village asked for and watch a stranger's face soften toward you. A kept promise is the truest coin an adventurer spends."}

# q8 — complete more board quests. lore + default [Skip ▸]. count:3.
data modify storage evercraft:ac_registry quests append value {id:8,title:"The Reliable Hand",desc:"Complete 3 village board quests.",type:"quest_count_seen",target:"",count:3,reward:"xp",reward_amt:220,chapter:2,lore:"Do a thing once and you are a passer-by. Do it three times and the village starts to expect you — to leave the lantern lit, to save you the better task. Reliability is a slow, warm kind of fame."}

# q9 — *** INTERLUDE (count:0) ***: a breather on the board as a promise between strangers.
data modify storage evercraft:ac_registry quests append value {id:9,title:"On Strangers and Trust",desc:"",type:"interlude",target:"",count:0,reward:"coins",reward_amt:1,chapter:2,beat:"interlude",lore:"The board is a strange and lovely thing: a stranger writes a need, another stranger answers it, and neither ever learns the other's whole story. Trust, offered into the dark and returned. Forget the rewards a moment — that exchange is the quiet heart of every village you will ever help."}

# q10 — a board milestone to mark the chapter. lore + default [Skip ▸]. count:6.
data modify storage evercraft:ac_registry quests append value {id:10,title:"Known on Every Board",desc:"Complete 6 village board quests in all.",type:"quest_count_seen",target:"",count:6,reward:"xp",reward_amt:300,chapter:2,lore:"Six promises kept, and the boards of Forevercraft begin to know your hand. You are no longer a wanderer who passes through; you are someone the villages wait for. That is its own kind of arrival."}

# --- Chapter 3: Reputation (strictly neutral — a spectrum you steer) -------

# q11 — step off neutral. tier_reached reads |rp.tier| (depth on EITHER road, equal
#   weight). count:1 = reach tier 1 in either direction. lore + default [Skip ▸].
data modify storage evercraft:ac_registry quests append value {id:11,title:"The Long Question",desc:"Let your deeds shift your alignment — reach tier 1 on either road (Renown or Infamy).",type:"tier_reached",target:"",count:1,reward:"xp",reward_amt:220,chapter:3,lore:"Now the longest question of all, and only you can answer it: what kind of legend will you be? Defend the villages and become Renowned, or prey upon them and become Infamous. Both are real roads, both are remembered. The Reaper keeps the ledger; the choosing is entirely yours."}

# q12 — *** INTERLUDE (count:0) — the RENOWNED ROAD (symmetric pair, equal weight) ***
data modify storage evercraft:ac_registry quests append value {id:12,title:"The Renowned Road",desc:"",type:"interlude",target:"",count:0,reward:"coins",reward_amt:1,chapter:3,beat:"interlude",lore:"Walk toward Renown and you become the one the village calls for when the dark presses in — the guard at the gate, the hand that hunts the bandit, the name children are taught to thank. Peacemonger is a heavy crown, freely given and freely worn. It is a fine legend, if it is the one you want."}

# q13 — *** INTERLUDE (count:0) — the INFAMOUS ROAD (symmetric pair, equal weight) ***
#   Deliberately the SAME length + tone as q12. The villain road is "a legend, not a
#   mistake" (Decision #3). Strictly neutral: no judgment, no penalty, equal reward.
data modify storage evercraft:ac_registry quests append value {id:13,title:"The Infamous Road",desc:"",type:"interlude",target:"",count:0,reward:"coins",reward_amt:1,chapter:3,beat:"interlude",lore:"Walk toward Infamy and you become the one the village fears at the treeline — the raider, the breaker of trades, the name spoken low and quick. Villain is a sharp crown, taken rather than given, and it draws bounty hunters the way honey draws the bear. It is a fine legend too, if it is the one you want. No road here is the wrong road; there is only the road you choose to walk."}

# q14 — commit to a road. tier_reached |rp.tier| count:3 (depth on EITHER road,
#   identical for Renowned +3 or Infamous -3). lore + default [Skip ▸]. EQUAL reward.
data modify storage evercraft:ac_registry quests append value {id:14,title:"Commit to the Walk",desc:"Deepen your alignment — reach tier 3 on either road.",type:"tier_reached",target:"",count:3,reward:"xp",reward_amt:300,chapter:3,lore:"Halfway down any road a person stops being a tourist and starts being what they do. Renowned or Infamous, the village now KNOWS you — and a known thing casts a long shadow. Walk on. The legend is no longer a maybe."}

# q15 — *** INTERLUDE (count:0) — EXILE AS THE VILLAIN'S COST + the FORGIVENESS PATH ***
#   Honest about the price of the Infamous road WITHOUT moralizing it as wrong, and
#   names the real forgiveness mechanic (village/exile/forgiveness) so it is NEVER a
#   dead end. Strictly neutral framing: a cost, not a punishment-for-being-bad.
data modify storage evercraft:ac_registry quests append value {id:15,title:"The Price of the Legend",desc:"",type:"interlude",target:"",count:0,reward:"coins",reward_amt:1,chapter:3,beat:"interlude",lore:"Every legend has its cost. Walk the Infamous road far enough and a village may bar its gates to you — exile, the villain's price, freely earned. But no door in Forevercraft is locked forever: make amends, pay the weregild, and the village can forgive even the worst of its old enemies. The price is real. So is the way back. That, too, is part of the legend."}

# q16 — FINALE: have a face the village remembers. showcase_viewed reads
#   rp.renown+rp.infamy sum (axis-agnostic — a hero's deeds and a villain's deeds
#   count the SAME toward "you are someone now"). lore + default [Skip ▸].
#   q16 is a soft finale, not a hard cap: advance reads N dynamically, so appending
#   load_batch_1 later auto-extends the line — q16's finish() only fires while N==16.
data modify storage evercraft:ac_registry quests append value {id:16,title:"A Name the Village Remembers",desc:"Accrue 200 total deeds across Renown and Infamy — let your alignment showcase read as a true legend. (See it in the Codex: Reaper → Alignment.)",type:"showcase_viewed",target:"",count:200,reward:"xp",reward_amt:400,chapter:3,lore:"Open the showcase and look: where once it read only 'Neutral', now it names you. Hero or villain or some restless braid of both — it does not matter which. What matters is that Forevercraft knows your face, and will tell your story long after you have walked on. You are Awakened. The legend is written, and it is yours."}

# ------------------------------------------------------------
# HAND-OFF TO load_batch_1 (future Awakening chapters):
#   - This batch ends at id=16. The next batch's FIRST quest MUST be id=17 (list
#     index 16), appended immediately after q16, contiguously.
#   - registry/load calls load_batch_0; add the load_batch_1 call there when it
#     lands. Do NOT renumber this batch.
# ------------------------------------------------------------
