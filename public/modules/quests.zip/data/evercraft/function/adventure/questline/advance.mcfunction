# ============================================================
# The Awakening (Adventure-A) — Advance (complete current quest -> next)
# ============================================================
# Run as @s = the player. Called by adventure/questline/check when the active quest
# is satisfied, OR by quest_pacing/do_skip (the [Skip ▸] button, full reward).
# WRITER of the linear pointer (ec.ac_quest), ec.ac_prog reset, ec.ac_done,
# ec.ac_complete (via finish).
#
# Order: show_completed -> reward -> bump pointer (clamped) -> reset prog ->
#        +1 done -> load next quest -> show_objective. Final quest -> a one-shot
#        "line complete!" tellraw + ec.ac_active bumped to 2 (the Adventure-B
#        sequenced-offer sentinel), pointer clamped at N.

# --- Idempotency / out-of-range guards (mirror the Cook/Fisher upper-bound guard) ---
execute unless score @s ec.ac_active matches 1.. run return 0
execute if score @s ec.ac_complete matches 1 run return 0

# Registry length = N (the last valid quest index). Dynamic so the engine never
# hardcodes the quest count — it grows automatically as batches are added.
execute store result score #ac_n ec.temp run data get storage evercraft:ac_registry quests
# Defensive: if the registry failed to load (length 0), do nothing.
execute if score #ac_n ec.temp matches ..0 run return 0
# If the pointer is somehow already past N, clamp + finish (don't run past the end).
execute if score @s ec.ac_quest > #ac_n ec.temp run function evercraft:adventure/questline/finish
execute if score @s ec.ac_quest > #ac_n ec.temp run return 0

# === 1) SHOW WHAT WAS JUST COMPLETED (ac_cur still holds the old quest) ===
function evercraft:adventure/questline/show_completed

# === 2) PAY OUT THE REWARD for the completed quest ===
function evercraft:adventure/questline/reward

# === 3) ADVANCE THE LINEAR POINTER + COUNTERS ===
scoreboard players add @s ec.ac_quest 1
scoreboard players set @s ec.ac_prog 0
scoreboard players add @s ec.ac_done 1

# === 4) FINAL-QUEST HANDLING ===
# If the new pointer exceeds N, the player just finished the LAST quest. Detect
# the overflow FIRST (into a flag), then clamp the pointer back to N (so a future
# check can't index out of range) and run the one-shot completion fanfare.
scoreboard players set #ac_overflow ec.temp 0
execute if score @s ec.ac_quest > #ac_n ec.temp run scoreboard players set #ac_overflow ec.temp 1
execute if score #ac_overflow ec.temp matches 1 run scoreboard players operation @s ec.ac_quest = #ac_n ec.temp
execute if score #ac_overflow ec.temp matches 1 run function evercraft:adventure/questline/finish

# Not finished: load the next quest into ac_cur and show its objective (paced).
execute if score #ac_overflow ec.temp matches 0 run function evercraft:adventure/questline/get_quest
execute if score #ac_overflow ec.temp matches 0 run function evercraft:adventure/questline/on_advance_notify
