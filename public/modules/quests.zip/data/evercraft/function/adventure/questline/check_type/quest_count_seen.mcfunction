# AC check helper — quest_count_seen (board quests completed SINCE the line began).
# @s = player. Present-action beat: reads the FORWARD-only delta
# (ach.quests_done - ec.ac_seen) so board quests completed before this beat was
# active never retro-credit it. Satisfied when the delta reaches quest.count
# (#ac_count ec.temp).
#
# READ-ONLY: reads ach.quests_done (achievements-owned, the lifetime board-quest
# completion counter) + ec.ac_seen (this line's OWN cursor, seeded at start). Writes
# NO dream/board/reaper objective.
#
# Note: a true veteran is NOT auto-passed by quest_count_seen (the forward cursor is
# intentional for present-action beats) — but the line never WALLS on it, because
# every quest_count_seen beat is `skippable` (default), so a player who would rather
# not run fresh board quests can [Skip ▸] at full reward. The lifetime-threshold
# veteran auto-pass for the board chapter rides the catch-up types elsewhere; a
# true veteran (many lifetime quests) can also just complete one quickly. (This
# mirrors cooking/questline check_type/cooked_meal's forward-cursor design.)
scoreboard players set #ac_satisfied ec.temp 0
scoreboard players operation #ac_delta ec.temp = @s ach.quests_done
scoreboard players operation #ac_delta ec.temp -= @s ec.ac_seen
execute if score #ac_delta ec.temp >= #ac_count ec.temp run scoreboard players set #ac_satisfied ec.temp 1
