# AC check helper — board_active (player has an ACCEPTED village board quest).
# @s = player. Satisfied when the player actually HOLDS an accepted board quest in any
# of the 6 tier slots — i.e. any of ec.quest_id_1..6 matches 1.. . When a player accepts
# a board quest, quests setup_tierN sets ec.quest_id_N to the quest's id (matches 1..),
# and track_progress uses exactly this "matches 1.." test as "active quest in slot N",
# so we mirror it here. This is the "accept a quest from the village board" teach beat
# of chapter 2 — it TEACHES the existing board buttons (no new ec.quest trigger added,
# protecting round-1 trigger 42, S9/A7).
#
# NOTE: ec.qp_active was the WRONG signal — it is the quest-PREVIEW-open flag (set 1 when
# the preview GUI opens, cleared back to 0 the moment the player ACCEPTS or closes the
# preview), so it fires while BROWSING and un-satisfies on ACCEPT, backwards from the
# promise. The quest_id_N slots are the durable "accepted quest in hand" signal.
#
# quest.count is IGNORED here (the condition is a flag, not a threshold) — the macro
# still sets #ac_count for uniformity; this helper does not read it.
#
# READ-ONLY: reads ec.quest_id_1..6 (quests-owned). Writes NO dream/board/reaper objective.
# A veteran who happens to hold a board quest auto-passes on the next 20t check; one
# who does not simply accepts a quest (taught, never walled — the beat is skippable).
scoreboard players set #ac_satisfied ec.temp 0
execute if score @s ec.quest_id_1 matches 1.. run scoreboard players set #ac_satisfied ec.temp 1
execute if score @s ec.quest_id_2 matches 1.. run scoreboard players set #ac_satisfied ec.temp 1
execute if score @s ec.quest_id_3 matches 1.. run scoreboard players set #ac_satisfied ec.temp 1
execute if score @s ec.quest_id_4 matches 1.. run scoreboard players set #ac_satisfied ec.temp 1
execute if score @s ec.quest_id_5 matches 1.. run scoreboard players set #ac_satisfied ec.temp 1
execute if score @s ec.quest_id_6 matches 1.. run scoreboard players set #ac_satisfied ec.temp 1
