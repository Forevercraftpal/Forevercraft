# ============================================================
# The Awakening (Adventure-A) — Check (macro body, dispatch on quest.type)
# ============================================================
# Called `with storage evercraft:ac_cur o`, o = current quest
#   {id,title,desc,type,target,count,reward,reward_amt,chapter,...}.
# Sets #ac_satisfied ec.temp to 1 iff the active quest's completion condition is
# met. Run as @s = the player.
#
# A macro can't branch on an int comparison inline, so we expose the threshold to
# ec.temp and route the per-TYPE decision to a tiny helper file:
#   - #ac_count ec.temp     = quest.count
# Each helper at check_type/$(type) reads its OWN public mirror and sets
# #ac_satisfied ec.temp. All helpers are READ-ONLY: they never write a dream/board/
# reaper engine objective (the no-write proof). The types, by chapter:
#   ch.1 Dream:      dream_entered (ec.dr_peak — the live Rate), score_at_least
#                    (ec.dream_rank — the lifetime Rank; the two are NOT conflated, S6)
#   ch.2 Board:      board_active (ec.quest_id_1..6 — holds an accepted board quest in
#                    any tier slot; NOT ec.qp_active, the preview-open flag — comment drift),
#                    quest_count_seen (ach.quests_done forward delta off ec.ac_seen)
#   ch.3 Reputation: align_shifted (rp.renown OR rp.infamy — axis-agnostic),
#                    tier_reached (|rp.tier| — depth on EITHER road, equal weight),
#                    showcase_viewed (rp.renown+rp.infamy any movement / showcase seen)

# Expose the threshold for the helpers to compare against.
$scoreboard players set #ac_count ec.temp $(count)

# Per-type decision (sets #ac_satisfied ec.temp). $(type) is one of:
#   dream_entered | score_at_least | board_active | quest_count_seen
#   | align_shifted | tier_reached | showcase_viewed
$function evercraft:adventure/questline/check_type/$(type)
