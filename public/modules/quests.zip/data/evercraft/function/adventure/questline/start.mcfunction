# ============================================================
# The Awakening (Adventure-A) — Start (begin the line at quest 1)
# ============================================================
# Run as @s = the player. Started from the soft "[Begin the Adventure Chronicle ->]"
# offer button (fired by dream_rank/rank_up's one-shot offer, gated ec.chron_view
# 1/3 + ec.ac_active 0) OR the Adventurer Tier-2 "The Awakening" [Begin →] START row
# (WA63-D1, Adv.GqStart9 -> here, the always-available hub door) OR the temp admin
# entry. Sets the linear pointer to quest 1, loads it, shows the intro + first
# objective. WRITER of the initial pointer state.
#
# Dup-guard: callers gate on `ec.ac_active matches 0`, but be defensive here too —
# a re-entrant start must NOT re-seed the cursor or reset progress.

# === DUP-GUARD: already on (or past) the line? Do nothing. ===
execute if score @s ec.ac_active matches 1.. run return 0

# Unified UI-click FX (Joseph 2026-06-05): tellraw-option click — play the gated cue once on a real start
# (after the dup-guard, so a stale re-click stays a silent no-op).
function evercraft:fx/ui/click

# === ACTIVATE + RESET LINEAR STATE ===
scoreboard players set @s ec.ac_active 1
# Auto-track this line for the [Skip ▸] button (Wiring #52): The Awakening = slot 9
# (do_skip value-map). Latest-activated line wins; finish clears it if still pointed
# here. (After the dup-guard above, so a re-click never re-tracks a line already past.)
scoreboard players set @s ec.gq_track 9
scoreboard players set @s ec.ac_quest 1
scoreboard players set @s ec.ac_prog 0
scoreboard players set @s ec.ac_done 0
scoreboard players set @s ec.ac_complete 0
# Seed the board-quests-done cursor at the player's current lifetime quest count so
# board quests completed BEFORE the line began never retro-credit the present
# `quest_count_seen` beat (forward-only). check_progress advances ec.ac_prog off
# this cursor; the catch-up TYPES (score_at_least / tier_reached / dream_entered /
# align_shifted / showcase_viewed) read their lifetime mirror DIRECTLY (so a veteran
# still auto-passes at full reward).
scoreboard players operation @s ec.ac_seen = @s ach.quests_done

# Load quest 1 into ac_cur for the objective display.
function evercraft:adventure/questline/get_quest

# Give the Adventurer's Codex (dup-guarded) so the player can re-open this line's
# overview at will. The Awakening has NO first-action engine splice (adding a board
# trigger is forbidden — it protects round-1 trigger 42), so the book arrives WITH
# the line start (offer button / Tier-2 row / admin), not on a first deed.
function evercraft:adventure/questline/book/give

# === INTRO ACTION-BAR (mirrors the Fisher's start tone, Adventurer-keyed) ===
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"The Awakening",color:"red",bold:true},{text:" ✦",color:"gold"}]
scoreboard players set #ndur ec.temp 50
function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"A road opens before you, adventurer — through dreams, through the village board, and at last to the long question of what kind of legend you will be. Walk it however you choose; it is yours.",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.player.levelup master @s ~ ~ ~ 0.4 1.4
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.beacon.activate master @s ~ ~ ~ 0.5 1.6

# Subtle title flash, then show the first objective.
title @s times 5 40 10
title @s subtitle {text:"Your first task awaits",color:"gray",italic:true}
function evercraft:adventure/questline/show_objective
# Pacing (q1-lore fill 2026-06-10, mirror build_quests/start): deliver quest 1's lore line
# (muted in Quick Mode) + [Skip ▸] button — advances get this via on_advance_notify; the start
# path was the one chat-silent entry.
data modify storage evercraft:qp_cur o set from storage evercraft:ac_cur quest
function evercraft:quest_pacing/render_lore
