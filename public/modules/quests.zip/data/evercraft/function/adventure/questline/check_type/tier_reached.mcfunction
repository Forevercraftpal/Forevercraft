# AC check helper — tier_reached (alignment DEPTH on EITHER road). @s = player.
# Catch-up beat. Reads rp.tier (the Reaper alignment tier, -5 Villain .. +5
# Peacemonger, dominant-axis-wins) and satisfies when its ABSOLUTE value reaches
# quest.count — i.e. "reach tier N in EITHER direction". A Renowned player at +N and
# an Infamous player at -N are treated identically (equal weight, strictly neutral —
# Decision #3). count:1 = "step off neutral onto either road"; higher counts =
# "commit to a road" without ever naming which is right. A veteran already at depth
# auto-passes on the next 20t check at full reward (R1).
#
# READ-ONLY: reads rp.tier (reaper-owned). We compute |rp.tier| into a private temp
# register, never write rp.* (the no-write proof). abs() via copy + negate-if-negative.
scoreboard players set #ac_satisfied ec.temp 0
scoreboard players operation #ac_tier_abs ec.temp = @s rp.tier
# If negative (villain road), flip the sign so depth is positive on both roads.
execute if score @s rp.tier matches ..-1 run scoreboard players set #ac_neg1 ec.temp -1
execute if score @s rp.tier matches ..-1 run scoreboard players operation #ac_tier_abs ec.temp *= #ac_neg1 ec.temp
execute if score #ac_tier_abs ec.temp >= #ac_count ec.temp run scoreboard players set #ac_satisfied ec.temp 1
