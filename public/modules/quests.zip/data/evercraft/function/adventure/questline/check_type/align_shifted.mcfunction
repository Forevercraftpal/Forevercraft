# AC check helper — align_shifted (ANY alignment movement, axis-AGNOSTIC). @s = player.
# Catch-up beat. Computes the MAX of rp.renown and rp.infamy (the two Reaper deed
# meters, 0-5000 each) and satisfies when that max reaches quest.count. "Shift your
# alignment" is satisfied by EITHER a renown deed OR an infamy deed — the chapter-3
# beat is strictly neutral: the villain road and the hero road carry EQUAL weight
# (Decision #3 "spectrum you steer; a legend, not a mistake"). A veteran who has
# walked EITHER road past the threshold auto-passes on the next 20t check at full
# reward (R1).
#
# READ-ONLY: reads rp.renown + rp.infamy (reaper-owned). Writes NO reaper objective.
# We fold the running max into a private temp register (#ac_align_max), never write
# rp.* (the no-write proof over the Reaper axis).
scoreboard players set #ac_satisfied ec.temp 0
scoreboard players operation #ac_align_max ec.temp = @s rp.renown
execute if score @s rp.infamy > #ac_align_max ec.temp run scoreboard players operation #ac_align_max ec.temp = @s rp.infamy
execute if score #ac_align_max ec.temp >= #ac_count ec.temp run scoreboard players set #ac_satisfied ec.temp 1
