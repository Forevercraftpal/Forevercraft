# ============================================================
# The Awakening (Adventure-A) — Reward dispatch (macro body)
# ============================================================
# Called `with storage evercraft:ac_cur o`, o = the completed quest
#   {...,reward,reward_amt,target,...}. Exposes the reward args to ec.temp /
# storage and routes to reward_type/$(reward). Run as @s = the player.
#
# Shared args the helpers consume:
#   #ac_reward_amt ec.temp = quest.reward_amt (coins amount / xp amount)
#   storage evercraft:ac_cur o.target = crate tier name (crate reward only)
$scoreboard players set #ac_reward_amt ec.temp $(reward_amt)

# Dispatch on reward type: xp | coins | crate  (NO title — wave spec).
$function evercraft:adventure/questline/reward_type/$(reward) with storage evercraft:ac_cur o
