# ============================================================
# The Awakening (Adventure-A) — Show objective (macro body)
# ============================================================
# Called `with storage evercraft:ac_cur o`, where o = the current quest object
# {id,title,desc,type,target,count,reward,reward_amt,chapter,...}.
# Mirrors the Cook/Fisher show_objective tone (white-not-gray active line).
$tellraw @s [{text:"➤ ",color:"yellow"},{text:"$(title)",color:"white",bold:true}]
$tellraw @s [{text:"  $(desc)",color:"gray"}]
$tellraw @s [{text:"  Quest $(id)",color:"dark_gray"},{text:"  ·  Chapter $(chapter)",color:"dark_gray"}]
