# ============================================================
# The Awakening (Adventure-A) — Load the current quest object into ac_cur
# ============================================================
# Reads the current quest (by linear pointer ec.ac_quest) out of the registry
# list and writes it to storage evercraft:ac_cur quest, so check/advance/reward
# can read quest.type/target/count/reward/reward_amt without per-quest files.
#
# The registry list is 0-indexed; ec.ac_quest is 1-based. This wrapper computes
# idx = ec.ac_quest - 1, stuffs it into storage, and calls the macro.
# Run as @s = the player.

# Compute 0-based list index from the 1-based linear pointer.
execute store result score #ac_idx ec.temp run scoreboard players get @s ec.ac_quest
scoreboard players remove #ac_idx ec.temp 1
execute store result storage evercraft:ac_cur idx int 1 run scoreboard players get #ac_idx ec.temp

# Macro-copy the quest object at that index into ac_cur.quest.
function evercraft:adventure/questline/get_quest_macro with storage evercraft:ac_cur
