# ============================================================
# The Awakening (Adventure-A) — Show current objective
# ============================================================
# Reads the current quest from ac_cur.quest (already loaded by get_quest) and
# prints its title + description as the active objective. Data-driven via macro
# (the quest text lives in the registry, not in per-quest files).
# Run as @s = the player.

# Surface the quest fields the macro needs at the top level of ac_cur.
data modify storage evercraft:ac_cur o set from storage evercraft:ac_cur quest
function evercraft:adventure/questline/show_objective_macro with storage evercraft:ac_cur o
