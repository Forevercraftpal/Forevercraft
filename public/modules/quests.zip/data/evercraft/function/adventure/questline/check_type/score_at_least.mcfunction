# AC check helper — score_at_least (lifetime Dream RANK). @s = player. Catch-up beat.
# Reads ec.dream_rank (the aggregate G->SSS master rank: 1=G,2=F,3=E,4=D,5=C,6=B,
# 7=A,8=S,9=SS,10=SSS — the Adventurer Card mirror, written by dream_rank/calculate)
# DIRECTLY. Satisfied when the Rank reaches quest.count (e.g. count:1 = "reach Rank G").
# This is the "reach Rank N" beat — chapter 1 teaches that the RANK is the lifetime
# tally, distinct from the live RATE peak (S6, NOT conflated; the Rate is read by
# check_type/dream_entered). A veteran already at the rank auto-passes on the next 20t
# check at full reward (R1).
#
# READ-ONLY: reads ec.dream_rank (stats-owned). Writes NO dream/board/reaper objective.
scoreboard players set #ac_satisfied ec.temp 0
execute if score @s ec.dream_rank >= #ac_count ec.temp run scoreboard players set #ac_satisfied ec.temp 1
