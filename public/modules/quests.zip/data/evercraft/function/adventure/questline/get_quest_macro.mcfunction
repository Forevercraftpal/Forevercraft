# ============================================================
# The Awakening (Adventure-A) — get_quest macro body
# ============================================================
# Called with storage evercraft:ac_cur containing {idx:<0-based index>}.
# Copies registry quest[idx] into evercraft:ac_cur quest.
$data modify storage evercraft:ac_cur quest set from storage evercraft:ac_registry quests[$(idx)]
