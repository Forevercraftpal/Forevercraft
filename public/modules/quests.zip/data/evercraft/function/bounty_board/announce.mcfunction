# ============================================================
# Artifact Bounty Board — Announce Turn-In (Macro)
# ============================================================
$data modify storage evercraft:notify stage.c set value [{text:"Turned in ",color:"green"},{text:"$(name)",color:"gold",bold:true},{text:"! Earned ",color:"green"},{text:"$(coins) Coins",color:"yellow"},{text:" + a bonus item!",color:"green"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
