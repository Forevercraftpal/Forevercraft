# ============================================================
# Artifact Bounty Board — Append Bounty From Pool (Macro)
# ============================================================
$data modify storage evercraft:database bounty_board.bounties append from storage evercraft:database bounty_board.pool[$(index)]
