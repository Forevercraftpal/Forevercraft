# ============================================================
# Artifact Bounty Board — Mark Index As Used (Macro)
# ============================================================
$data modify storage evercraft:database bounty_board.used.i$(index) set value 1b
