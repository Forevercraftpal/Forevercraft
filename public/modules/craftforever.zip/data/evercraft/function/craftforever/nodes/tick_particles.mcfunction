# Biome Node: Render node particles (10-tick schedule)
schedule function evercraft:craftforever/nodes/tick_particles 10t replace

# Perf retrofit M2 (2026-06-14): match the sibling node systems — skip the marker enumeration
# entirely with nobody online (still reschedules above).
execute unless entity @a run return 0

# Only render for nodes near players (performance optimization)
execute as @e[type=marker,tag=ec.cf_node_data] at @s if entity @a[distance=..48] run function evercraft:craftforever/nodes/render_node
