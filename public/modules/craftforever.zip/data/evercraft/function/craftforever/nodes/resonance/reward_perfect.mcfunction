# Resonance Strike — PERFECT HIT
# Run as player, at player position

data modify storage evercraft:notify stage.c set value [{text:"\u2726 ",color:"gold"},{text:"Perfect Resonance! ",color:"gold",bold:true},{text:"Rare bonus loot! \u2726",color:"gold"}]
scoreboard players set #ndur ec.temp 50
function evercraft:util/notify/emit

# Award bonus rare loot
execute store result score #inv_full ec.var run function evercraft:util/check_inv_full
execute if score #inv_full ec.var matches 0 run loot give @s loot evercraft:craftforever/nodes/resonance_perfect
execute if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:craftforever/nodes/resonance_perfect

# === P0-5: Resonance Dust (+1% specialized catalyst) — ~10% rare drop on Perfect ===
# Thematic: the catalyst is named "Resonance Dust" and this is the Resonance Strike.
# Single 1-in-10 roll; inv-full guarded (reuses #inv_full above).
execute if predicate evercraft:craftforever/resonance_dust_10pct if score #inv_full ec.var matches 0 run loot give @s loot evercraft:craftforever/materials/resonance_dust
execute if predicate evercraft:craftforever/resonance_dust_10pct if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:craftforever/materials/resonance_dust
data modify storage evercraft:notify stage.c set value [{text:"◆ ",color:"#AADDFF"},{text:"Resonance Dust",color:"#AADDFF",bold:true},{text:" condenses from the resonance! (+1% artifact catalyst)",color:"gray"}]
scoreboard players set #ndur ec.temp 45
execute if predicate evercraft:craftforever/resonance_dust_10pct run function evercraft:util/notify/emit
# Wiring Audit #14 C15: mark the Forge Catalysts almanac entry (cat2 #6) discovered.
execute if predicate evercraft:craftforever/resonance_dust_10pct run function evercraft:craftforever/codex/hub/almanac/mark_found {field:"cf_craft_found",bit:32}

# Also give duplicate of the biome material they just mined (P2-3: inv-full guarded via shared helper)
function evercraft:craftforever/nodes/resonance/give_dup_material

# Resonance Duplicator Charm (C46, Family K Prospector — art-K): an EXTRA duplicate-material chance on
# a Perfect Strike, ADDITIVE on the base perfect-strike dup above (the base always dups; this rolls a
# SECOND dup). Item-gated 33% (1..3 -> 1) so a holder occasionally gets a triple of the biome material
# on a perfect strike — distinct yield verb from the crate-roll Geode Heart (C43). give_dup_material
# is inv-full guarded (recomputes #inv_full fresh), so the bonus is never voided. id-presence (one
# `if items` test -> two copies roll once = m4 multi-copy-safe). Non-holders pay one comparison.
execute if items entity @s container.* *[custom_data~{artifact:"resonance_duplicator_charm"}] store result score #rdc_dup ec.temp run random value 1..3
execute unless items entity @s container.* *[custom_data~{artifact:"resonance_duplicator_charm"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"resonance_duplicator_charm"}] if entity @s[tag=ec.sat_resonance_duplicator_charm] store result score #rdc_dup ec.temp run random value 1..3
execute unless items entity @s container.* *[custom_data~{artifact:"resonance_duplicator_charm"}] if items entity @s weapon.offhand *[custom_data~{artifact:"resonance_duplicator_charm"}] store result score #rdc_dup ec.temp run random value 1..3
execute if items entity @s container.* *[custom_data~{artifact:"resonance_duplicator_charm"}] if score #rdc_dup ec.temp matches 1 run function evercraft:craftforever/nodes/resonance/give_dup_material
execute unless items entity @s container.* *[custom_data~{artifact:"resonance_duplicator_charm"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"resonance_duplicator_charm"}] if entity @s[tag=ec.sat_resonance_duplicator_charm] if score #rdc_dup ec.temp matches 1 run function evercraft:craftforever/nodes/resonance/give_dup_material
execute unless items entity @s container.* *[custom_data~{artifact:"resonance_duplicator_charm"}] if items entity @s weapon.offhand *[custom_data~{artifact:"resonance_duplicator_charm"}] if score #rdc_dup ec.temp matches 1 run function evercraft:craftforever/nodes/resonance/give_dup_material

# cap-K (m4): the Crate Pair / Node Mastery / Demiurge's Spirit Artifact consolidate the Resonance
# Duplicator Charm's extra Perfect-Strike dup — re-roll it gated on any held flag, but ONLY when the loose
# Charm is NOT held (so a re-acquired loose Charm never double-rolls; exactly one path runs). Same 33%
# (1..3 -> 1) give_dup_material, ADDITIVE on the base perfect dup. #rdc_cap is a distinct fake so it never
# clobbers the loose Charm's #rdc_dup. Supersede: grand absorbs node_mastery absorbs crate_pair — gate each
# lower tier `unless` a higher one is held so exactly ONE node-tier rolls. (Loose always rolls when held.)
execute unless items entity @s container.* *[custom_data~{artifact:"resonance_duplicator_charm"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"resonance_duplicator_charm"}] unless entity @s[tag=ec.sat_resonance_duplicator_charm] if items entity @s container.* *[custom_data~{demiurges_capstone:true}] store result score #rdc_cap ec.temp run random value 1..3
execute unless items entity @s container.* *[custom_data~{artifact:"resonance_duplicator_charm"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"resonance_duplicator_charm"}] unless entity @s[tag=ec.sat_resonance_duplicator_charm] unless items entity @s container.* *[custom_data~{demiurges_capstone:true}] unless items entity @s weapon.offhand *[custom_data~{demiurges_capstone:true}] if entity @s[tag=ec.sat_demiurges_capstone] store result score #rdc_cap ec.temp run random value 1..3
execute unless items entity @s container.* *[custom_data~{artifact:"resonance_duplicator_charm"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"resonance_duplicator_charm"}] unless entity @s[tag=ec.sat_resonance_duplicator_charm] unless items entity @s container.* *[custom_data~{demiurges_capstone:true}] if items entity @s weapon.offhand *[custom_data~{demiurges_capstone:true}] store result score #rdc_cap ec.temp run random value 1..3
execute unless items entity @s container.* *[custom_data~{artifact:"resonance_duplicator_charm"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"resonance_duplicator_charm"}] unless entity @s[tag=ec.sat_resonance_duplicator_charm] unless items entity @s container.* *[custom_data~{demiurges_capstone:true}] unless items entity @s weapon.offhand *[custom_data~{demiurges_capstone:true}] if items entity @s container.* *[custom_data~{node_mastery:true}] store result score #rdc_cap ec.temp run random value 1..3
execute unless items entity @s container.* *[custom_data~{artifact:"resonance_duplicator_charm"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"resonance_duplicator_charm"}] unless entity @s[tag=ec.sat_resonance_duplicator_charm] unless items entity @s container.* *[custom_data~{demiurges_capstone:true}] unless items entity @s weapon.offhand *[custom_data~{demiurges_capstone:true}] unless items entity @s container.* *[custom_data~{node_mastery:true}] unless items entity @s weapon.offhand *[custom_data~{node_mastery:true}] if entity @s[tag=ec.sat_node_mastery] store result score #rdc_cap ec.temp run random value 1..3
execute unless items entity @s container.* *[custom_data~{artifact:"resonance_duplicator_charm"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"resonance_duplicator_charm"}] unless entity @s[tag=ec.sat_resonance_duplicator_charm] unless items entity @s container.* *[custom_data~{demiurges_capstone:true}] unless items entity @s weapon.offhand *[custom_data~{demiurges_capstone:true}] unless items entity @s container.* *[custom_data~{node_mastery:true}] if items entity @s weapon.offhand *[custom_data~{node_mastery:true}] store result score #rdc_cap ec.temp run random value 1..3
execute unless items entity @s container.* *[custom_data~{artifact:"resonance_duplicator_charm"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"resonance_duplicator_charm"}] unless entity @s[tag=ec.sat_resonance_duplicator_charm] unless items entity @s container.* *[custom_data~{demiurges_capstone:true}] unless items entity @s weapon.offhand *[custom_data~{demiurges_capstone:true}] unless items entity @s container.* *[custom_data~{node_mastery:true}] unless items entity @s weapon.offhand *[custom_data~{node_mastery:true}] if items entity @s container.* *[custom_data~{crate_pair:true}] store result score #rdc_cap ec.temp run random value 1..3
execute unless items entity @s container.* *[custom_data~{artifact:"resonance_duplicator_charm"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"resonance_duplicator_charm"}] unless entity @s[tag=ec.sat_resonance_duplicator_charm] unless items entity @s container.* *[custom_data~{demiurges_capstone:true}] unless items entity @s weapon.offhand *[custom_data~{demiurges_capstone:true}] unless items entity @s container.* *[custom_data~{node_mastery:true}] unless items entity @s weapon.offhand *[custom_data~{node_mastery:true}] unless items entity @s container.* *[custom_data~{crate_pair:true}] if items entity @s weapon.offhand *[custom_data~{crate_pair:true}] store result score #rdc_cap ec.temp run random value 1..3
execute if score #rdc_cap ec.temp matches 1 run function evercraft:craftforever/nodes/resonance/give_dup_material

# Double Artisan XP (award same XP again)
scoreboard players set #cf_xp_gain ec.temp 10
execute if score @s ec.cf_node_mined matches 4 run scoreboard players set #cf_xp_gain ec.temp 5
execute if score @s ec.cf_node_mined matches 14 run scoreboard players set #cf_xp_gain ec.temp 5
execute if score @s ec.cf_node_mined matches 6 run scoreboard players set #cf_xp_gain ec.temp 15
execute if score @s ec.cf_node_mined matches 7 run scoreboard players set #cf_xp_gain ec.temp 15
execute if score @s ec.cf_node_mined matches 9 run scoreboard players set #cf_xp_gain ec.temp 15
execute if score @s ec.cf_node_mined matches 3 run scoreboard players set #cf_xp_gain ec.temp 20
execute if score @s ec.cf_node_mined matches 11 run scoreboard players set #cf_xp_gain ec.temp 20
execute if score @s ec.cf_node_mined matches 8 run scoreboard players set #cf_xp_gain ec.temp 25
scoreboard players operation @s ec.cf_xp += #cf_xp_gain ec.temp
# P1-9 cf_xp drift quick-fix: direct ec.cf_xp write bypasses add_xp, so fire check_levelup.
function evercraft:craftforever/artisan/check_levelup

# Effects (gated FX preset — bespoke amethyst identity replaces the old levelup cue)
execute at @s run function evercraft:fx/node/resonance_perfect
experience add @s 15 points
