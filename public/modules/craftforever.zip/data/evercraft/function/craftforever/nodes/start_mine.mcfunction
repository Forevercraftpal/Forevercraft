# Biome Node: Begin 4-second mining progress
# Run as the player who clicked, at player position

# If already mining a regular prospect node, a biome node, or in resonance minigame, ignore
execute if score @s ec.pr_picking matches 1 run return 0
execute if score @s ec.cf_mining matches 1 run return 0
execute if score @s ec.cf_reso matches 1 run return 0

# Require any pickaxe
data modify storage evercraft:notify stage.c set value [{text:"You need a pickaxe to extract biome materials.",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute unless items entity @s container.* minecraft:wooden_pickaxe unless items entity @s container.* minecraft:stone_pickaxe unless items entity @s container.* minecraft:iron_pickaxe unless items entity @s container.* minecraft:diamond_pickaxe unless items entity @s container.* minecraft:netherite_pickaxe unless items entity @s container.* *[custom_data~{spirit_pickaxe:true}] run function evercraft:util/notify/emit
execute unless items entity @s container.* minecraft:wooden_pickaxe unless items entity @s container.* minecraft:stone_pickaxe unless items entity @s container.* minecraft:iron_pickaxe unless items entity @s container.* minecraft:diamond_pickaxe unless items entity @s container.* minecraft:netherite_pickaxe unless items entity @s container.* *[custom_data~{spirit_pickaxe:true}] run return 0

# Check rank requirement from nearest biome node marker
execute store result score #cf_node_rank ec.temp run data get entity @e[type=marker,tag=ec.cf_node_data,distance=..5,limit=1,sort=nearest] data.min_rank
# If player doesn't meet rank and doesn't have spirit pickaxe, deny
data modify storage evercraft:notify stage.c set value [{text:"Your Artisan Rank is too low to extract this node.",color:"red"},{text:" (Requires rank ",color:"gray"},{score:{name:"#cf_node_rank",objective:"ec.temp"},color:"yellow"},{text:")",color:"gray"}]
scoreboard players set #ndur ec.temp 45
execute unless items entity @s weapon.* *[custom_data~{spirit_pickaxe:true}] unless score @s ec.cf_rank >= #cf_node_rank ec.temp run function evercraft:util/notify/emit
execute unless items entity @s weapon.* *[custom_data~{spirit_pickaxe:true}] unless score @s ec.cf_rank >= #cf_node_rank ec.temp run return 0

# Mark player as mining biome node
scoreboard players set @s ec.cf_mining 1
scoreboard players set @s ec.cf_mine_prog 0

# Store node position for range checking
execute store result score @s ec.cf_mine_sx run data get entity @e[type=marker,tag=ec.cf_node_data,distance=..5,limit=1,sort=nearest] Pos[0] 1
execute store result score @s ec.cf_mine_sy run data get entity @e[type=marker,tag=ec.cf_node_data,distance=..5,limit=1,sort=nearest] Pos[1] 1
execute store result score @s ec.cf_mine_sz run data get entity @e[type=marker,tag=ec.cf_node_data,distance=..5,limit=1,sort=nearest] Pos[2] 1

# Store biome ID for loot routing on completion
execute store result score @s ec.cf_node_mined run data get entity @e[type=marker,tag=ec.cf_node_data,distance=..5,limit=1,sort=nearest] data.biome_id

# Show boss bar (mirrors prospect/buried_cache; fixed 80t fill, max set in load — Joseph 2026-06-16)
bossbar set evercraft:biome_node value 0
bossbar set evercraft:biome_node visible true
bossbar set evercraft:biome_node players @s
# Safety auto-dismiss: clear the bar if it lingers 30s (e.g. interrupted mid-extract by death).
schedule function evercraft:bossbar/autodismiss/clear/biome_node 30s replace

# Start sound — pick-on-stone texture + the biome-node "instrument picks up" note (pling C#4; the
# biome-node family voice is C# MINOR pling — crystalline arcane — gather-FX identity pass, 2026-06-09).
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.stone.hit master @s ~ ~ ~ 0.6 0.8
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.pling master @s ~ ~ ~ 0.45 0.749
