# Biome Node: Check node lifetimes (every 5 seconds)
schedule function evercraft:craftforever/nodes/tick_despawn 100t replace

# Perf retrofit M2 (2026-06-14): compute the "carries a node life-extender" flag ONCE per player
# per cycle (was up to 8 expensive container.* scans PER NODE). Each node then reads the cheap
# ec.cf_life_ext tag instead of re-scanning inventories. Big win when nodes >> players.
execute unless entity @a run return 0
tag @a remove ec.cf_life_ext
execute as @a if items entity @s container.* *[custom_data~{artifact:"wayfinders_dowsing_rod"}] run tag @s add ec.cf_life_ext
execute as @a unless entity @s[tag=ec.cf_life_ext] if items entity @s weapon.offhand *[custom_data~{artifact:"wayfinders_dowsing_rod"}] run tag @s add ec.cf_life_ext
execute as @a unless entity @s[tag=ec.cf_life_ext] if items entity @s container.* *[custom_data~{node_mastery:true}] run tag @s add ec.cf_life_ext
execute as @a unless entity @s[tag=ec.cf_life_ext] if items entity @s weapon.offhand *[custom_data~{node_mastery:true}] run tag @s add ec.cf_life_ext
execute as @a unless entity @s[tag=ec.cf_life_ext] if items entity @s container.* *[custom_data~{demiurges_capstone:true}] run tag @s add ec.cf_life_ext
execute as @a unless entity @s[tag=ec.cf_life_ext] if items entity @s weapon.offhand *[custom_data~{demiurges_capstone:true}] run tag @s add ec.cf_life_ext

execute as @e[type=marker,tag=ec.cf_node_data] run function evercraft:craftforever/nodes/check_despawn
