# Resonance Strike — give one duplicate of the biome material just mined.
# Shared by reward_good + reward_perfect. Inv-full guarded (P2-3) so the bonus
# material is never voided. Recomputes #inv_full fresh (the fake-player is shared,
# so never trust a stale value from a prior call/tick).
execute store result score #inv_full ec.var run function evercraft:util/check_inv_full
execute if score @s ec.cf_node_mined matches 1 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:craftforever/nodes/frostcrystal
execute if score @s ec.cf_node_mined matches 1 if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:craftforever/nodes/frostcrystal
execute if score @s ec.cf_node_mined matches 2 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:craftforever/nodes/sunite
execute if score @s ec.cf_node_mined matches 2 if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:craftforever/nodes/sunite
execute if score @s ec.cf_node_mined matches 3 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:craftforever/nodes/voidite
execute if score @s ec.cf_node_mined matches 3 if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:craftforever/nodes/voidite
execute if score @s ec.cf_node_mined matches 4 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:craftforever/nodes/livingstone
execute if score @s ec.cf_node_mined matches 4 if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:craftforever/nodes/livingstone
execute if score @s ec.cf_node_mined matches 5 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:craftforever/nodes/tideforged
execute if score @s ec.cf_node_mined matches 5 if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:craftforever/nodes/tideforged
execute if score @s ec.cf_node_mined matches 6 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:craftforever/nodes/blazite
execute if score @s ec.cf_node_mined matches 6 if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:craftforever/nodes/blazite
execute if score @s ec.cf_node_mined matches 7 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:craftforever/nodes/warpstone
execute if score @s ec.cf_node_mined matches 7 if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:craftforever/nodes/warpstone
execute if score @s ec.cf_node_mined matches 8 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:craftforever/nodes/endric
execute if score @s ec.cf_node_mined matches 8 if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:craftforever/nodes/endric
execute if score @s ec.cf_node_mined matches 9 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:craftforever/nodes/sporite
execute if score @s ec.cf_node_mined matches 9 if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:craftforever/nodes/sporite
execute if score @s ec.cf_node_mined matches 10 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:craftforever/nodes/verdant
execute if score @s ec.cf_node_mined matches 10 if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:craftforever/nodes/verdant
execute if score @s ec.cf_node_mined matches 11 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:craftforever/nodes/skymetal
execute if score @s ec.cf_node_mined matches 11 if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:craftforever/nodes/skymetal
execute if score @s ec.cf_node_mined matches 12 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:craftforever/nodes/sunforged
execute if score @s ec.cf_node_mined matches 12 if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:craftforever/nodes/sunforged
execute if score @s ec.cf_node_mined matches 13 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:craftforever/nodes/shadowroot
execute if score @s ec.cf_node_mined matches 13 if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:craftforever/nodes/shadowroot
execute if score @s ec.cf_node_mined matches 14 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:craftforever/nodes/bogstone
execute if score @s ec.cf_node_mined matches 14 if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:craftforever/nodes/bogstone
execute if score @s ec.cf_node_mined matches 15 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:craftforever/nodes/blossom
execute if score @s ec.cf_node_mined matches 15 if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:craftforever/nodes/blossom
