# Biome Node: Check if this node should despawn (5-minute lifetime)
# Run as node marker

# Calculate elapsed ticks since spawn
execute store result score #cf_now ec.temp run time query gametime
execute store result score #cf_spawn ec.temp run data get entity @s data.spawn_time
scoreboard players operation #cf_elapsed ec.temp = #cf_now ec.temp
scoreboard players operation #cf_elapsed ec.temp -= #cf_spawn ec.temp

# Wayfinder's Dowsing Rod (C7, Family K Prospector — art-K) + Node Mastery sub-cap + Demiurge's
# Capstone: a craft-node near a carrier of ANY of these lingers +50% (threshold 6000t -> 9000t).
# Perf retrofit M2 (2026-06-14): the per-item container.* inventory scans (8 of them, run PER NODE)
# are gone — tick_despawn now computes the ec.cf_life_ext tag ONCE per player per cycle, so this is
# a single bounded nearest-player tag check. ADDITIVE (extends life; never shortens), read-only on
# the node. Behaviour is identical to the old 8-line scan; only the cost moved off the per-node path.
scoreboard players set #cf_life ec.temp 6000
execute if entity @p[distance=..100,tag=ec.cf_life_ext] run scoreboard players set #cf_life ec.temp 9000

# Despawn after the (possibly extended) lifetime threshold.
execute if score #cf_elapsed ec.temp >= #cf_life ec.temp at @s run function evercraft:craftforever/nodes/despawn_node
