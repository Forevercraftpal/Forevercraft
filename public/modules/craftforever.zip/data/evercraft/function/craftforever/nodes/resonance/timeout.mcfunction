# Resonance Strike — Timeout (5 seconds elapsed with no click)
# Run as player

data modify storage evercraft:notify stage.c set value [{text:"The resonance faded...",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit

# Same flat miss cue (gated FX preset)
execute at @s run function evercraft:fx/node/resonance_miss

# Cleanup
function evercraft:craftforever/nodes/resonance/cleanup
