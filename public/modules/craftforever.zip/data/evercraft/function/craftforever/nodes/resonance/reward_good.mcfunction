# Resonance Strike — GOOD HIT (edge of zone)
# Run as player, at player position

data modify storage evercraft:notify stage.c set value [{text:"\u2726 ",color:"yellow"},{text:"Good Strike! ",color:"yellow",bold:true},{text:"Bonus material! \u2726",color:"yellow"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit

# Award duplicate of the biome material they just mined (P2-3: inv-full guarded via shared helper)
function evercraft:craftforever/nodes/resonance/give_dup_material

# +50% Artisan XP (half of the base gain)
scoreboard players set #cf_xp_gain ec.temp 5
execute if score @s ec.cf_node_mined matches 4 run scoreboard players set #cf_xp_gain ec.temp 3
execute if score @s ec.cf_node_mined matches 14 run scoreboard players set #cf_xp_gain ec.temp 3
execute if score @s ec.cf_node_mined matches 6 run scoreboard players set #cf_xp_gain ec.temp 8
execute if score @s ec.cf_node_mined matches 7 run scoreboard players set #cf_xp_gain ec.temp 8
execute if score @s ec.cf_node_mined matches 9 run scoreboard players set #cf_xp_gain ec.temp 8
execute if score @s ec.cf_node_mined matches 3 run scoreboard players set #cf_xp_gain ec.temp 10
execute if score @s ec.cf_node_mined matches 11 run scoreboard players set #cf_xp_gain ec.temp 10
execute if score @s ec.cf_node_mined matches 8 run scoreboard players set #cf_xp_gain ec.temp 13
scoreboard players operation @s ec.cf_xp += #cf_xp_gain ec.temp
# P1-9 cf_xp drift quick-fix: direct ec.cf_xp write bypasses add_xp, so fire check_levelup.
function evercraft:craftforever/artisan/check_levelup

# Effects (gated FX preset)
execute at @s run function evercraft:fx/node/resonance_good
experience add @s 10 points
