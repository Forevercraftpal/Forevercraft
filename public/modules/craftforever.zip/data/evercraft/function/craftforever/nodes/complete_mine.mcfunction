# Biome Node: Mining complete — award biome-specific material
# Run as player, at player position
# @s ec.cf_node_mined = biome ID (1-15)

# Hide the boss bar + reset state, then surface the "Extracted!" message
data modify storage evercraft:chanbar bar set value "biome_node"
execute store result storage evercraft:chanbar id int 1 run scoreboard players get @s ec.chanbar_id
function evercraft:bossbar/chanbar/op_hide with storage evercraft:chanbar
data modify storage evercraft:notify stage.c set value [{text:"Extracted!",color:"#8BC34A",bold:true}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
scoreboard players set @s ec.cf_mining 0
scoreboard players set @s ec.cf_mine_prog 0

# Node 2-harvest life (Joseph 2026-06-01): each node survives TWO successful mines before despawning.
# Count this mine on the nearest node marker (marker-level, so 2 total harvests regardless of who mines it);
# despawn only on the 2nd. The 5-min check_despawn timer still applies in parallel (whichever comes first).
execute as @e[type=marker,tag=ec.cf_node_data,distance=..8,limit=1,sort=nearest] run scoreboard players add @s ec.cf_node_uses 1
execute as @e[type=marker,tag=ec.cf_node_data,distance=..8,limit=1,sort=nearest] if score @s ec.cf_node_uses matches 2.. at @s run function evercraft:craftforever/nodes/despawn_node

# --- Award biome-specific loot ---
execute store result score #inv_full ec.var run function evercraft:util/check_inv_full

# Route to biome-specific loot table based on ec.cf_node_mined
execute if score @s ec.cf_node_mined matches 1 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:craftforever/nodes/frostcrystal
execute if score @s ec.cf_node_mined matches 1 if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:craftforever/nodes/frostcrystal

execute if score @s ec.cf_node_mined matches 2 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:craftforever/nodes/sunite
execute if score @s ec.cf_node_mined matches 2 if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:craftforever/nodes/sunite

execute if score @s ec.cf_node_mined matches 3 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:craftforever/nodes/voidite
execute if score @s ec.cf_node_mined matches 3 if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:craftforever/nodes/voidite

execute if score @s ec.cf_node_mined matches 4 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:craftforever/nodes/livingstone
execute if score @s ec.cf_node_mined matches 4 if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:craftforever/nodes/livingstone

execute if score @s ec.cf_node_mined matches 5 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:craftforever/nodes/tideforged
execute if score @s ec.cf_node_mined matches 5 if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:craftforever/nodes/tideforged

execute if score @s ec.cf_node_mined matches 6 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:craftforever/nodes/blazite
execute if score @s ec.cf_node_mined matches 6 if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:craftforever/nodes/blazite

execute if score @s ec.cf_node_mined matches 7 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:craftforever/nodes/warpstone
execute if score @s ec.cf_node_mined matches 7 if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:craftforever/nodes/warpstone

execute if score @s ec.cf_node_mined matches 8 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:craftforever/nodes/endric
execute if score @s ec.cf_node_mined matches 8 if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:craftforever/nodes/endric

execute if score @s ec.cf_node_mined matches 9 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:craftforever/nodes/sporite
execute if score @s ec.cf_node_mined matches 9 if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:craftforever/nodes/sporite

execute if score @s ec.cf_node_mined matches 10 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:craftforever/nodes/verdant
execute if score @s ec.cf_node_mined matches 10 if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:craftforever/nodes/verdant

execute if score @s ec.cf_node_mined matches 11 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:craftforever/nodes/skymetal
execute if score @s ec.cf_node_mined matches 11 if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:craftforever/nodes/skymetal

execute if score @s ec.cf_node_mined matches 12 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:craftforever/nodes/sunforged
execute if score @s ec.cf_node_mined matches 12 if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:craftforever/nodes/sunforged

execute if score @s ec.cf_node_mined matches 13 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:craftforever/nodes/shadowroot
execute if score @s ec.cf_node_mined matches 13 if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:craftforever/nodes/shadowroot

execute if score @s ec.cf_node_mined matches 14 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:craftforever/nodes/bogstone
execute if score @s ec.cf_node_mined matches 14 if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:craftforever/nodes/bogstone

execute if score @s ec.cf_node_mined matches 15 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:craftforever/nodes/blossom
execute if score @s ec.cf_node_mined matches 15 if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:craftforever/nodes/blossom

# Warn if inventory full
data modify storage evercraft:notify stage.c set value [{text:"Inventory full! Material dropped at your feet.",color:"yellow"}]
scoreboard players set #ndur ec.temp 45
execute if score #inv_full ec.var matches 1 run function evercraft:util/notify/emit
execute if score #inv_full ec.var matches 1 if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bass player @s ~ ~ ~ 1 0.5

# --- Discovery tracking (bitfield) ---
# Check if this biome node was already discovered (bit = biome_id - 1)
# We need 2^(biome_id-1) as a bitmask for biome IDs 1-15.
# Switch-table (one op/mine): keep this INLINE — uses global ec.temp scratch,
# serial @a iteration from tick.mcfunction is the race fence. Do NOT extract
# into a schedule-callable function (Wiring Audit #14, race seat guard-rail).
scoreboard players set #cf_bitmask ec.temp 1
execute if score @s ec.cf_node_mined matches 2 run scoreboard players set #cf_bitmask ec.temp 2
execute if score @s ec.cf_node_mined matches 3 run scoreboard players set #cf_bitmask ec.temp 4
execute if score @s ec.cf_node_mined matches 4 run scoreboard players set #cf_bitmask ec.temp 8
execute if score @s ec.cf_node_mined matches 5 run scoreboard players set #cf_bitmask ec.temp 16
execute if score @s ec.cf_node_mined matches 6 run scoreboard players set #cf_bitmask ec.temp 32
execute if score @s ec.cf_node_mined matches 7 run scoreboard players set #cf_bitmask ec.temp 64
execute if score @s ec.cf_node_mined matches 8 run scoreboard players set #cf_bitmask ec.temp 128
execute if score @s ec.cf_node_mined matches 9 run scoreboard players set #cf_bitmask ec.temp 256
execute if score @s ec.cf_node_mined matches 10 run scoreboard players set #cf_bitmask ec.temp 512
execute if score @s ec.cf_node_mined matches 11 run scoreboard players set #cf_bitmask ec.temp 1024
execute if score @s ec.cf_node_mined matches 12 run scoreboard players set #cf_bitmask ec.temp 2048
execute if score @s ec.cf_node_mined matches 13 run scoreboard players set #cf_bitmask ec.temp 4096
execute if score @s ec.cf_node_mined matches 14 run scoreboard players set #cf_bitmask ec.temp 8192
execute if score @s ec.cf_node_mined matches 15 run scoreboard players set #cf_bitmask ec.temp 16384

# Check if already discovered (AND operation)
scoreboard players operation #cf_check ec.temp = @s ec.cf_nodes_found
scoreboard players operation #cf_check ec.temp /= #cf_bitmask ec.temp
scoreboard players operation #cf_check ec.temp %= #2 ec.const

# If NOT discovered yet (bit is 0), set it and announce
execute if score #cf_check ec.temp matches 0 run scoreboard players operation @s ec.cf_nodes_found += #cf_bitmask ec.temp
data modify storage evercraft:notify stage.c set value [{text:"New biome node discovered!",color:"green"}]
scoreboard players set #ndur ec.temp 45
execute if score #cf_check ec.temp matches 0 run function evercraft:util/notify/emit
execute if score #cf_check ec.temp matches 0 if score @s ec.fx_snd matches 1.. run playsound minecraft:item.book.page_turn master @s ~ ~ ~ 0.8 1.0
execute if score #cf_check ec.temp matches 0 if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.experience_orb.pickup master @s ~ ~ ~ 0.5 1.2
# "New entry!" sparkle on first discovery — one bright bell C#5 atop the page-turn (2026-06-09).
execute if score #cf_check ec.temp matches 0 if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.4 1.498

# Also track in materials found bitfield
scoreboard players operation #cf_mat_check ec.temp = @s ec.cf_materials
scoreboard players operation #cf_mat_check ec.temp /= #cf_bitmask ec.temp
scoreboard players operation #cf_mat_check ec.temp %= #2 ec.const
execute if score #cf_mat_check ec.temp matches 0 run scoreboard players operation @s ec.cf_materials += #cf_bitmask ec.temp

# --- Artisan XP ---
# XP based on rarity: Uncommon=5, Rare=10, Ornate=15, Exquisite=20, Mythical=25
scoreboard players set #cf_xp_gain ec.temp 10
execute if score @s ec.cf_node_mined matches 4 run scoreboard players set #cf_xp_gain ec.temp 5
execute if score @s ec.cf_node_mined matches 14 run scoreboard players set #cf_xp_gain ec.temp 5
execute if score @s ec.cf_node_mined matches 6 run scoreboard players set #cf_xp_gain ec.temp 15
execute if score @s ec.cf_node_mined matches 7 run scoreboard players set #cf_xp_gain ec.temp 15
execute if score @s ec.cf_node_mined matches 9 run scoreboard players set #cf_xp_gain ec.temp 15
execute if score @s ec.cf_node_mined matches 3 run scoreboard players set #cf_xp_gain ec.temp 20
execute if score @s ec.cf_node_mined matches 11 run scoreboard players set #cf_xp_gain ec.temp 20
execute if score @s ec.cf_node_mined matches 8 run scoreboard players set #cf_xp_gain ec.temp 25
scoreboard players operation @s ec.cf_xp += #cf_xp_gain ec.temp
# P1-9 cf_xp drift quick-fix: biome-node XP writes ec.cf_xp directly (bypassing add_xp), so fire check_levelup.
function evercraft:craftforever/artisan/check_levelup

# --- Mining stat tracking ---
scoreboard players add @s adv.stat_mine 4
# Cumulative harvest counter (codex grant + profile-card "Nodes Mined" — Audit #15 AU15-X2;
# matches the prospect/forage idiom so biome-node mines also count). Additive aggregate.
scoreboard players add @s ec.cf_nodes_done 1

# --- Completion effects — the C#-MINOR biome-node "resonance lift" (gather-FX identity pass,
#     2026-06-09): amethyst shatter kept quiet as the material accent, then a crystalline pling
#     chord in one of THREE randomized voicings (minor = the arcane family, distinct by ear from
#     every major-key gather node). C# minor: C#4 0.749 / E4 0.891 / G#4 1.122 / C#5 1.498.
#     #fx_voice scratch, local to this file. ---
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.amethyst_block.break master @s ~ ~ ~ 0.5 1.0
execute if score @s ec.fx_snd matches 1.. store result score #fx_voice ec.temp run random value 1..3
execute if score @s ec.fx_snd matches 1.. if score #fx_voice ec.temp matches 1 run playsound minecraft:block.note_block.pling master @s ~ ~ ~ 0.6 0.749
execute if score @s ec.fx_snd matches 1.. if score #fx_voice ec.temp matches 1 run playsound minecraft:block.note_block.pling master @s ~ ~ ~ 0.45 0.891
execute if score @s ec.fx_snd matches 1.. if score #fx_voice ec.temp matches 1 run playsound minecraft:block.note_block.chime master @s ~ ~ ~ 0.35 1.498
execute if score @s ec.fx_snd matches 1.. if score #fx_voice ec.temp matches 2 run playsound minecraft:block.note_block.pling master @s ~ ~ ~ 0.6 0.891
execute if score @s ec.fx_snd matches 1.. if score #fx_voice ec.temp matches 2 run playsound minecraft:block.note_block.pling master @s ~ ~ ~ 0.45 1.122
execute if score @s ec.fx_snd matches 1.. if score #fx_voice ec.temp matches 2 run playsound minecraft:block.note_block.chime master @s ~ ~ ~ 0.35 1.498
execute if score @s ec.fx_snd matches 1.. if score #fx_voice ec.temp matches 3 run playsound minecraft:block.note_block.pling master @s ~ ~ ~ 0.6 0.749
execute if score @s ec.fx_snd matches 1.. if score #fx_voice ec.temp matches 3 run playsound minecraft:block.note_block.pling master @s ~ ~ ~ 0.45 1.122
execute if score @s ec.fx_snd matches 1.. if score #fx_voice ec.temp matches 3 run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.25 1.498
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.experience_orb.pickup master @s ~ ~ ~ 0.5 0.8
execute if score @s ec.fx_vis matches 1.. run particle minecraft:electric_spark ~ ~0.5 ~ 0.3 0.3 0.3 0.02 8

# Award XP orbs
experience add @s 8 points

# --- Forever Coin chance: 3% per node mined (single roll) ---
execute store success score #cf_coin_roll ec.temp if predicate {"condition":"minecraft:random_chance","chance":0.03}
execute if score #cf_coin_roll ec.temp matches 1 run scoreboard players add @s ec.coins 1
execute if score #cf_coin_roll ec.temp matches 1 run scoreboard players add #rm_coins ec.var 1
data modify storage evercraft:notify stage.c set value [{text:"★ ",color:"#E0B0FF"},{text:"+1 Forever Coin",color:"#E0B0FF"},{text:" — there's something shiny in between the rocks...",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 45
execute if score #cf_coin_roll ec.temp matches 1 run function evercraft:util/notify/emit
execute if score #cf_coin_roll ec.temp matches 1 if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.experience_orb.pickup player @s ~ ~ ~ 0.3 1.5

# --- Resonance Strike: 5% chance to trigger precision minigame for bonus loot ---
execute store result score #cf_reso_roll ec.temp run random value 1..20
execute if score #cf_reso_roll ec.temp matches 1 run function evercraft:craftforever/nodes/resonance/start

# --- Wild Companion Ambush: 5% chance (Plan 3) ---
# Exempt from daily cap — this is a bonus encounter
scoreboard players set @s ec.cf_node_type 1
function evercraft:wild_companions/ambush/check
