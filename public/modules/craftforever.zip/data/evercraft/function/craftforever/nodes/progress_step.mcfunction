# Biome Node: Per-tick mining progress
# Run as player with active biome mining, at player position

# --- Range check: cancel if too far from node ---
execute store result score #cf_px ec.temp run data get entity @s Pos[0] 1
execute store result score #cf_py ec.temp run data get entity @s Pos[1] 1
execute store result score #cf_pz ec.temp run data get entity @s Pos[2] 1
scoreboard players operation #cf_px ec.temp -= @s ec.cf_mine_sx
scoreboard players operation #cf_py ec.temp -= @s ec.cf_mine_sy
scoreboard players operation #cf_pz ec.temp -= @s ec.cf_mine_sz
# Absolute values
execute if score #cf_px ec.temp matches ..-1 run scoreboard players operation #cf_px ec.temp *= #-1 ec.const
execute if score #cf_py ec.temp matches ..-1 run scoreboard players operation #cf_py ec.temp *= #-1 ec.const
execute if score #cf_pz ec.temp matches ..-1 run scoreboard players operation #cf_pz ec.temp *= #-1 ec.const
# Manhattan distance
scoreboard players operation #cf_px ec.temp += #cf_py ec.temp
scoreboard players operation #cf_px ec.temp += #cf_pz ec.temp
# Cancel if Manhattan distance > 4 blocks
execute if score #cf_px ec.temp matches 5.. run return run function evercraft:craftforever/nodes/cancel_mine

# --- Check node still exists ---
execute unless entity @e[type=marker,tag=ec.cf_node_data,distance=..8] run return run function evercraft:craftforever/nodes/cancel_mine

# --- Increment progress ---
scoreboard players add @s ec.cf_mine_prog 1

# --- Update boss bar (mirrors prospect/buried_cache — Joseph 2026-06-16) ---
execute store result bossbar evercraft:biome_node value run scoreboard players get @s ec.cf_mine_prog

# --- Periodic audio feedback — the C#-minor extraction scale (gather-FX identity pass, 2026-06-09):
#     three pling steps walking UP the family scale (C#4 -> D#4 -> E4) toward the completion chord, so
#     the channel literally "tunes up" to the payoff instead of crunching stone three times. ---
execute if score @s ec.cf_mine_prog matches 20 if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.pling master @s ~ ~ ~ 0.4 0.749
execute if score @s ec.cf_mine_prog matches 40 if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.pling master @s ~ ~ ~ 0.4 0.841
execute if score @s ec.cf_mine_prog matches 60 if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.pling master @s ~ ~ ~ 0.4 0.891

# --- Complete at 80 ticks (4 seconds) ---
execute if score @s ec.cf_mine_prog matches 80.. run function evercraft:craftforever/nodes/complete_mine
