# Resonance Strike — MISS (outside zone)
# Run as player

data modify storage evercraft:notify stage.c set value [{text:"Missed the resonance... no bonus this time.",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit

# No penalty — normal loot already awarded
execute at @s run function evercraft:fx/node/resonance_miss
