# Biome Node: Cancel active mining (moved too far)
# Run as player

# Hide the boss bar
bossbar set evercraft:biome_node visible false
scoreboard players set @s ec.cf_mining 0
scoreboard players set @s ec.cf_mine_prog 0
data modify storage evercraft:notify stage.c set value [{text:"You moved too far away...",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.stone.break master @s ~ ~ ~ 0.4 0.6
