# === CRAFTFOREVER SYSTEM ===
# Initialize all Craftforever scoreboards and start scheduled loops

# D1 (Trial Pass — broaden): per-player day stamp of the last claimed daily-login pass.
# Set to #cur_day after grant in `evercraft:craftforever/trials/daily_login_pass`.
scoreboard objectives add ec.tp_daily_day dummy "Trial Pass Daily-Login Day Stamp"

# ═══ ARTISAN RANK (Plan 2 — Full Implementation) ═══
scoreboard objectives add ec.cf_rank dummy "Artisan Rank"
scoreboard objectives add ec.cf_xp dummy "Artisan XP"
scoreboard objectives add ec.cf_xp_next dummy "Artisan XP Next"

# Artisan category XP (ec.cf_axp_ prefix to avoid collision with node mining ec.cf_mining)
scoreboard objectives add ec.cf_axp_mine dummy "Artisan XP: Mining"
scoreboard objectives add ec.cf_axp_cook dummy "Artisan XP: Cooking"
scoreboard objectives add ec.cf_axp_build dummy "Artisan XP: Building"
scoreboard objectives add ec.cf_axp_fish dummy "Artisan XP: Fishing"
scoreboard objectives add ec.cf_axp_forage dummy "Artisan XP: Foraging"
scoreboard objectives add ec.cf_axp_forge dummy "Artisan XP: Forging"
scoreboard objectives add ec.cf_axp_alch dummy "Artisan XP: Alchemy"

# Codex first-grant tracking (Joseph 2026-05-27 — 5 nodes = book)
scoreboard objectives add ec.cf_nodes_done dummy "CF Nodes Harvested (for codex grant)"

# ═══ CRAFT RATE (CR) — Passive mirror of Dream Rate ═══
# Cap: 50.0 (stored as x10 internally, so 500 = 50.0 CR)
scoreboard objectives add ec.craft_rate dummy "Craft Rate"
scoreboard objectives add ec.cr_base dummy "CR Base (from mastery)"
scoreboard objectives add ec.cr_artisan dummy "CR from Artisan Rank"
scoreboard objectives add ec.cr_tool dummy "CR from Spirit Tool"
scoreboard objectives add ec.cr_forge_crystal dummy "CR from Forge Crystal"
scoreboard objectives add ec.cr_temp dummy "CR Temporary Bonuses"

# Cooking artifact state
scoreboard objectives add ec.ck_art_cat dummy "Cook Artifact Category"
scoreboard objectives add ec.ck_art_tier dummy "Cook Artifact Tier"

# Alchemy artifact roll scratch (player-scoped — Council #4 race fix)
scoreboard objectives add ec.cf_art_thresh dummy "Alchemy Artifact Threshold"
scoreboard objectives add ec.cf_art_check_roll dummy "Alchemy Artifact Roll"

# Fusion Funnel state
scoreboard objectives add ec.ff_state dummy "Funnel State"
scoreboard objectives add ec.ff_phase dummy "Funnel Phase"
scoreboard objectives add ec.ff_quality dummy "Funnel Quality"
scoreboard objectives add ec.ff_timer dummy "Funnel Timer"
scoreboard objectives add ec.ff_heat dummy "Funnel Heat"
scoreboard objectives add ec.ff_target dummy "Funnel Target"
scoreboard objectives add ec.ff_pri_tier dummy "Primary Reagent Tier"
scoreboard objectives add ec.ff_sec_tier dummy "Secondary Reagent Tier"
scoreboard objectives add ec.ff_pri_cat dummy "Primary Reagent Category"
scoreboard objectives add ec.ff_sec_cat dummy "Secondary Reagent Category"
scoreboard objectives add ec.ff_recipe dummy "Funnel Recipe"
# Aquatic-alchemy WS2: which spirit (T7) fish was deposited (0=none, 1 voidfin / 2 starscale / 3 deepcurrent / 4 leviathans_whisker).
# SOLE writers: do_deposit_primary + do_deposit_secondary (one-writer law); reset in open/close.
scoreboard objectives add ec.ff_spirit_fish dummy "Funnel Spirit Fish"
scoreboard objectives add ec.ff_grind_ct dummy "Grind Click Count"
scoreboard objectives add ec.ff_rune_round dummy "Infuse Round"
scoreboard objectives add ec.ff_rune_target dummy "Infuse Target Rune"

# Breakdown trigger
scoreboard objectives add ec.cf_info trigger "Artisan Info"
scoreboard players enable @a ec.cf_info

# ═══ FORGE TABLE STATE SCOREBOARDS ═══
scoreboard objectives add ec.cf_state dummy "Forge State"
scoreboard objectives add ec.cf_phase dummy "Forge Phase"
scoreboard objectives add ec.cf_heat dummy "Forge Heat"
scoreboard objectives add ec.cf_quality dummy "Forge Quality"
scoreboard objectives add ec.cf_timer dummy "Forge Timer"
scoreboard objectives add ec.cf_menu_time dummy "Forge Menu Time"
scoreboard objectives add ec.cf_mat_tier dummy "Material Tier"
scoreboard objectives add ec.cf_cat_tier dummy "Catalyst Tier"
scoreboard objectives add ec.cf_recipe dummy "Matched Recipe"
scoreboard objectives add ec.cf_pending dummy "Forge Pending Deposit"

# Artifact forging state
scoreboard objectives add ec.cf_art_cat dummy "Artifact Category"
scoreboard objectives add ec.cf_art_tier dummy "Artifact Tier"

# Pattern matching (Phase 2: Hammer)
scoreboard objectives add ec.cf_p1 dummy "Pattern Slot 1"
scoreboard objectives add ec.cf_p2 dummy "Pattern Slot 2"
scoreboard objectives add ec.cf_p3 dummy "Pattern Slot 3"
scoreboard objectives add ec.cf_p4 dummy "Pattern Slot 4"
scoreboard objectives add ec.cf_p5 dummy "Pattern Slot 5"
scoreboard objectives add ec.cf_p6 dummy "Pattern Slot 6"
scoreboard objectives add ec.cf_p7 dummy "Pattern Slot 7"
scoreboard objectives add ec.cf_pat_pos dummy "Pattern Position"
scoreboard objectives add ec.cf_pat_len dummy "Pattern Length"

# Quench (Phase 3)
scoreboard objectives add ec.cf_quench dummy "Quench Position"
scoreboard objectives add ec.cf_lock_zone dummy "Quench Lock Zone"

# Temp scoreboard
scoreboard objectives add ec.cf_temp dummy "Craftforever Temp"

# ═══ ARTISAN RANK CONSTANTS ═══
scoreboard players set #cf_5 ec.cf_temp 5
scoreboard players set #cf_20 ec.cf_temp 20
scoreboard players set #cf_100 ec.cf_temp 100
scoreboard players set #cf_neg1 ec.cf_temp -1
scoreboard players set #cf_60 ec.cf_temp 60
scoreboard players set #cf_300 ec.cf_temp 300
scoreboard players set #cf_3 ec.cf_temp 3

# ═══ ORE MINING — Artifact Material Drops ═══
scoreboard objectives add ec.om_debris minecraft.mined:minecraft.ancient_debris "OM Debris Mined"
# Snapshot scoreboards for ore mining detection
scoreboard objectives add ec.om_prev_coal dummy "OM Prev Coal"
scoreboard objectives add ec.om_prev_dcoal dummy "OM Prev DS Coal"
scoreboard objectives add ec.om_prev_cop dummy "OM Prev Copper"
scoreboard objectives add ec.om_prev_dcop dummy "OM Prev DS Copper"
scoreboard objectives add ec.om_prev_iron dummy "OM Prev Iron"
scoreboard objectives add ec.om_prev_diron dummy "OM Prev DS Iron"
scoreboard objectives add ec.om_prev_gold dummy "OM Prev Gold"
scoreboard objectives add ec.om_prev_dgold dummy "OM Prev DS Gold"
scoreboard objectives add ec.om_prev_ngold dummy "OM Prev Nether Gold"
scoreboard objectives add ec.om_prev_lapis dummy "OM Prev Lapis"
scoreboard objectives add ec.om_prev_dlapis dummy "OM Prev DS Lapis"
scoreboard objectives add ec.om_prev_red dummy "OM Prev Redstone"
scoreboard objectives add ec.om_prev_dred dummy "OM Prev DS Redstone"
scoreboard objectives add ec.om_prev_dia dummy "OM Prev Diamond"
scoreboard objectives add ec.om_prev_ddia dummy "OM Prev DS Diamond"
scoreboard objectives add ec.om_prev_emer dummy "OM Prev Emerald"
scoreboard objectives add ec.om_prev_demer dummy "OM Prev DS Emerald"
scoreboard objectives add ec.om_prev_debris dummy "OM Prev Debris"

# ═══ FORGE TABLE SKIN ═══
data modify storage evercraft:craftforever forge_skin set value "ewogICJ0aW1lc3RhbXAiIDogMTc3Mzg0MzMzNjE0OCwKICAicHJvZmlsZUlkIiA6ICJiZmQ3MjMxMGNmYWY0Yjc5OTNlYzhiYzU3ODg3YzU5ZCIsCiAgInByb2ZpbGVOYW1lIiA6ICJBbHBoYVNwQW0iLAogICJzaWduYXR1cmVSZXF1aXJlZCIgOiB0cnVlLAogICJ0ZXh0dXJlcyIgOiB7CiAgICAiU0tJTiIgOiB7CiAgICAgICJ1cmwiIDogImh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvZGM3NGU2ZWRmZTAxZDRjZGEyMjNhNjlhMTQ0MDQ4Y2E1ODgwNDYyNzE2MjE3MTNmZjc0NDdhYjJmNzQzYjU2OSIsCiAgICAgICJtZXRhZGF0YSIgOiB7CiAgICAgICAgIm1vZGVsIiA6ICJzbGltIgogICAgICB9CiAgICB9CiAgfQp9"

# ═══ XP THRESHOLD TABLE ═══
# RETUNE 2026-06-10 (_council/2026-06-10-codex-vault-dream-rank/): 150 * 1.09^n,
# per-rank cost CAPPED at 30,000 (cap binds from rank 63) — kills the old curve's
# pathology where ranks 50→100 were 98.5% of 5.69M total (3-4 YEARS for a Pioneer).
# Checkpoints: r10=2,280 · r25=12,707 · r50=122,264 · r75=736,905 · r100=1,486,905 total.
# Earn rates untouched (drips 1-4 XP + craft-affinity cross-feed, 50k/day cap):
# active Pioneer ≈ a year-plus to 100; Newcomer (x10) a few months. Players' banked
# ec.cf_xp/ec.cf_rank are NOT migrated — next level-up just uses the new thresholds
# (check_levelup re-seeds ec.cf_xp_next from this table via calc_next_threshold).
data modify storage evercraft:craftforever xp_table set value [150,164,178,194,212,231,252,274,299,326,355,387,422,460,501,546,596,649,708,771,841,916,999,1089,1187,1293,1410,1537,1675,1826,1990,2169,2364,2577,2809,3062,3338,3638,3966,4322,4711,5135,5598,6101,6651,7249,7902,8613,9388,10233,11154,12157,13252,14444,15744,17161,18706,20389,22224,24224,26405,28781,30000,30000,30000,30000,30000,30000,30000,30000,30000,30000,30000,30000,30000,30000,30000,30000,30000,30000,30000,30000,30000,30000,30000,30000,30000,30000,30000,30000,30000,30000,30000,30000,30000,30000,30000,30000,30000,30000]

# ═══ CRAFTER GLOWIE TEAMS ═══
team add ec.cf_glow_mine
team modify ec.cf_glow_mine color gold

team add ec.cf_glow_cook
team modify ec.cf_glow_cook color red

team add ec.cf_glow_fish
team modify ec.cf_glow_fish color aqua

team add ec.cf_glow_build
team modify ec.cf_glow_build color green

team add ec.cf_glow_forage
team modify ec.cf_glow_forage color dark_purple

team add ec.cf_glow_forge
team modify ec.cf_glow_forge color white

# --- Codex tracking ---
scoreboard objectives add ec.cf_nodes_found dummy "CF Nodes Found"
scoreboard objectives add ec.cf_craft_found dummy "CF Craft Materials Found"
scoreboard objectives add ec.cf_recipes_found dummy "CF Recipes Found"
# AU14-P6 / AU21-P6 (Wave L council, 2026-05-31): ec.cf_meals_found ARCHIVED — 5/5 unanimous
# dead-code council verdict. Superseded by the cooking ck.m_*/ck.disc* counters that the live
# cookbook codex reads; the decl had 0 readers + 0 incrementing writers. See dead-code.md.
# Wiring Audit #14 C2: per-category almanac discovery bitfields (cats 3-7).
# Each is independent — entry K = bit 2^(K-1) — so no cross-cat / cf_nodes_found collision.
scoreboard objectives add ec.cf_chem_found dummy "CF Chemistry Reagents Found"
scoreboard objectives add ec.cf_cook_found dummy "CF Cooking Ingredients Found"
scoreboard objectives add ec.cf_fish_found dummy "CF Spirit Fish Found"
scoreboard objectives add ec.cf_forage_found dummy "CF Forage Gathers Found"
scoreboard objectives add ec.cf_build_found dummy "CF Building Materials Found"
# Wiring Audit #14 C5/C14/C16: recipe-discovery bitfields for the new panels.
scoreboard objectives add ec.cf_alch_recipes_found dummy "CF Alchemy Recipes Found"
# Wave J FU (2026-05-31): aquatic + spirit-capstone field 2 (22 bits — aquatic 0-17, spirit 18-21).
# Field 1 covers standard combos (21 bits: 12x/13x/23x × T1-T7).
scoreboard objectives add ec.cf_alch_aq_recipes_found dummy "CF Alchemy Aquatic Recipes Found"
scoreboard objectives add ec.cf_art_recipes_found dummy "CF Artifact Recipes Found"
# Wiring Audit #14 C19: forge-rolled artifact counter (surfaced in Forge Artifacts panel).
scoreboard objectives add ach.artifacts_forged dummy "Artifacts Forged"
scoreboard objectives add ec.cf_trophies dummy "CF Trophies"
scoreboard objectives add ec.cf_materials dummy "CF Materials"
scoreboard objectives add ec.cf_codex_page dummy "CF Codex Page"
scoreboard objectives add ec.cf_codex_section dummy "CF Codex Section"
scoreboard objectives add ec.cf_gui_session dummy "CF GUI Session"

# --- Node mining state ---
scoreboard objectives add ec.cf_mining dummy "CF Mining Active"
scoreboard objectives add ec.cf_mine_prog dummy "CF Mining Progress"
scoreboard objectives add ec.cf_mine_sx dummy "CF Mine Node X"
scoreboard objectives add ec.cf_mine_sy dummy "CF Mine Node Y"
scoreboard objectives add ec.cf_mine_sz dummy "CF Mine Node Z"

# --- Node counts ---
scoreboard objectives add ec.cf_node_mined dummy "CF Nodes Mined"
scoreboard objectives add ec.cf_node_uses dummy "CF Node Uses (2-harvest life)"

# --- Biome node mining bossbar (mirrors prospect_mine / buried_cache; fixed 80t / 4s fill).
#     Converted from per-player actionbar to a shared bossbar for gather-channel consistency
#     (Joseph 2026-06-16). One shared bar; viewer set to the active miner on start. ---
# evercraft:biome_node is now a PER-PLAYER bar pool (WA62-CHANNEL-BAR, 2026-06-22):
# each channeler drives their own evercraft:biome_node.<id> (see bossbar/chanbar/), so
# there is no shared global bar to create here. The id is allocated lazily on first open.

# --- Resonance Strike minigame ---
scoreboard objectives add ec.cf_reso dummy "CF Resonance Active"
scoreboard objectives add ec.cf_reso_pos dummy "CF Resonance Cursor Pos"
scoreboard objectives add ec.cf_reso_dir dummy "CF Resonance Direction"
scoreboard objectives add ec.cf_reso_zone dummy "CF Resonance Zone Center"
scoreboard objectives add ec.cf_reso_timer dummy "CF Resonance Timer"

# --- Codex GUI state ---
scoreboard objectives add ec.cf_codex_use dummy "CF Codex Use Flag"
scoreboard objectives add ec.cf_codex_cd dummy "CF Codex Cooldown"
scoreboard objectives add ec.cf_held dummy "CF Codex Held-Click Filter"
# Artisan Profile sub-page state (#10 CR ladder tab): 0=stat card, 1=Craft-Rate ladder.
# One writer: artisan_profile/open_ladder (set 1) + back_to_profile/spawn (set 0).
scoreboard objectives add ec.cf_ap_pg dummy "Artisan Profile Page"

# Initialize global session counter (only if not already set)
execute unless score #cf_gui_session ec.var matches 1.. run scoreboard players set #cf_gui_session ec.var 0

# --- Codex give trigger (testing) ---
scoreboard objectives add ec.cf_codex trigger "Give CF Codex"
scoreboard players enable @a ec.cf_codex

# --- Trade Trials ---
scoreboard objectives add ec.tt_active dummy "TT Active"
scoreboard objectives add ec.tt_type dummy "TT Type"
scoreboard objectives add ec.tt_tier dummy "TT Tier"
scoreboard objectives add ec.tt_timer dummy "TT Timer"
scoreboard objectives add ec.tt_score dummy "TT Score"
scoreboard objectives add ec.tt_target dummy "TT Target"
scoreboard objectives add ec.tt_exit trigger "TT Emergency Exit"
scoreboard players enable @a ec.tt_exit

# Per-category best tier completed (1-10)
scoreboard objectives add ec.tt_m_best dummy "TT Mining Best"
scoreboard objectives add ec.tt_farm_best dummy "TT Farming Best"
scoreboard objectives add ec.tt_fish_best dummy "TT Fishing Best"
scoreboard objectives add ec.tt_build_best dummy "TT Building Best"
scoreboard objectives add ec.tt_lumb_best dummy "TT Lumber Best"
scoreboard objectives add ec.tt_art_best dummy "TT Artisan Best"

# Trial expansion: mastery, stats, challenge modes
scoreboard objectives add ec.tt_completed dummy "TT Total Completed"
scoreboard objectives add ec.tt_mastery dummy "TT Categories Mastered"
scoreboard objectives add ec.tt_speed_clear dummy "TT Speed Clears"
scoreboard objectives add ec.tt_first_clear dummy "TT First Clear Flag"
scoreboard objectives add ec.tt_hard_mode dummy "TT Hard Mode"
scoreboard objectives add ec.tt_hard_wins dummy "TT Hard Mode Wins"
scoreboard objectives add ec.tt_daily_wins dummy "TT Daily Wins"
scoreboard objectives add ec.tt_is_daily dummy "TT Is Daily Flag"
scoreboard objectives add ec.tt_daily_type dummy "TT Daily Type"
scoreboard objectives add ec.tt_daily_tier dummy "TT Daily Tier"
scoreboard objectives add ec.tt_daily_done dummy "TT Daily Done Today"
scoreboard objectives add ec.tt_daily_day dummy "TT Daily Last Day"
scoreboard objectives add ec.tt_title dummy "TT Active Title"

# Mining stat trackers (auto-update — live values)
scoreboard objectives add ec.tt_s_stone minecraft.mined:minecraft.stone "TT Stone Mined"
scoreboard objectives add ec.tt_s_iron minecraft.mined:minecraft.iron_ore "TT Iron Mined"
scoreboard objectives add ec.tt_s_diron minecraft.mined:minecraft.deepslate_iron_ore "TT DS Iron Mined"
scoreboard objectives add ec.tt_s_gold minecraft.mined:minecraft.gold_ore "TT Gold Mined"
scoreboard objectives add ec.tt_s_dgold minecraft.mined:minecraft.deepslate_gold_ore "TT DS Gold Mined"
scoreboard objectives add ec.tt_s_dia minecraft.mined:minecraft.diamond_ore "TT Diamond Mined"
scoreboard objectives add ec.tt_s_ddia minecraft.mined:minecraft.deepslate_diamond_ore "TT DS Diamond Mined"
scoreboard objectives add ec.tt_s_coal minecraft.mined:minecraft.coal_ore "TT Coal Mined"
scoreboard objectives add ec.tt_s_dcoal minecraft.mined:minecraft.deepslate_coal_ore "TT DS Coal Mined"
scoreboard objectives add ec.tt_s_cop minecraft.mined:minecraft.copper_ore "TT Copper Mined"
scoreboard objectives add ec.tt_s_dcop minecraft.mined:minecraft.deepslate_copper_ore "TT DS Copper Mined"
scoreboard objectives add ec.tt_s_lapis minecraft.mined:minecraft.lapis_ore "TT Lapis Mined"
scoreboard objectives add ec.tt_s_dlapis minecraft.mined:minecraft.deepslate_lapis_ore "TT DS Lapis Mined"
scoreboard objectives add ec.tt_s_red minecraft.mined:minecraft.redstone_ore "TT Redstone Mined"
scoreboard objectives add ec.tt_s_dred minecraft.mined:minecraft.deepslate_redstone_ore "TT DS Redstone Mined"
scoreboard objectives add ec.tt_s_emer minecraft.mined:minecraft.emerald_ore "TT Emerald Mined"
scoreboard objectives add ec.tt_s_demer minecraft.mined:minecraft.deepslate_emerald_ore "TT DS Emerald Mined"
scoreboard objectives add ec.tt_s_debris minecraft.mined:minecraft.ancient_debris "TT Debris Mined"
scoreboard objectives add ec.tt_s_dslate minecraft.mined:minecraft.deepslate "TT Deepslate Mined"
scoreboard objectives add ec.tt_s_dior minecraft.mined:minecraft.diorite "TT Diorite Mined"
scoreboard objectives add ec.tt_s_gran minecraft.mined:minecraft.granite "TT Granite Mined"
scoreboard objectives add ec.tt_s_ande minecraft.mined:minecraft.andesite "TT Andesite Mined"

# Farming stat trackers (item pickup)
scoreboard objectives add ec.tt_s_wheat minecraft.picked_up:minecraft.wheat "TT Wheat Picked"
scoreboard objectives add ec.tt_s_carrot minecraft.picked_up:minecraft.carrot "TT Carrot Picked"
scoreboard objectives add ec.tt_s_potato minecraft.picked_up:minecraft.potato "TT Potato Picked"
scoreboard objectives add ec.tt_s_beetrt minecraft.picked_up:minecraft.beetroot "TT Beetroot Picked"
scoreboard objectives add ec.tt_s_melon minecraft.picked_up:minecraft.melon_slice "TT Melon Picked"
scoreboard objectives add ec.tt_s_pumpkn minecraft.picked_up:minecraft.pumpkin "TT Pumpkin Picked"
scoreboard objectives add ec.tt_s_nwart minecraft.picked_up:minecraft.nether_wart "TT Nether Wart Picked"
scoreboard objectives add ec.tt_s_sugar minecraft.picked_up:minecraft.sugar_cane "TT Sugar Cane Picked"
# AU34-1 (Joseph 2026-05-30): sweet_berries added to complete the 9-crop coverage for H04 per-crop tracking.
scoreboard objectives add ec.tt_s_berries minecraft.picked_up:minecraft.sweet_berries "TT Sweet Berries Picked"

# Fishing stat tracker
scoreboard objectives add ec.tt_s_fish minecraft.custom:minecraft.fish_caught "TT Fish Caught"

# Lumber stat trackers (log mining)
scoreboard objectives add ec.tt_s_oaklog minecraft.mined:minecraft.oak_log "TT Oak Log"
scoreboard objectives add ec.tt_s_sprlog minecraft.mined:minecraft.spruce_log "TT Spruce Log"
scoreboard objectives add ec.tt_s_birlog minecraft.mined:minecraft.birch_log "TT Birch Log"
scoreboard objectives add ec.tt_s_junlog minecraft.mined:minecraft.jungle_log "TT Jungle Log"
scoreboard objectives add ec.tt_s_acalog minecraft.mined:minecraft.acacia_log "TT Acacia Log"
scoreboard objectives add ec.tt_s_drklog minecraft.mined:minecraft.dark_oak_log "TT Dark Oak Log"
scoreboard objectives add ec.tt_s_mnglog minecraft.mined:minecraft.mangrove_log "TT Mangrove Log"
scoreboard objectives add ec.tt_s_chrlog minecraft.mined:minecraft.cherry_log "TT Cherry Log"

# Building stat trackers (blocks placed/used)
scoreboard objectives add ec.tt_s_dirt minecraft.used:minecraft.dirt "TT Dirt Used"
scoreboard objectives add ec.tt_s_cobble minecraft.used:minecraft.cobblestone "TT Cobble Used"
scoreboard objectives add ec.tt_s_planks minecraft.used:minecraft.oak_planks "TT Planks Used"

# Artisan stat trackers
scoreboard objectives add ec.tt_s_wool minecraft.picked_up:minecraft.white_wool "TT White Wool"
scoreboard objectives add ec.tt_s_string minecraft.picked_up:minecraft.string "TT String Picked"
scoreboard objectives add ec.tt_s_cobweb minecraft.mined:minecraft.cobweb "TT Cobweb Mined"
scoreboard objectives add ec.tt_s_poppy minecraft.picked_up:minecraft.poppy "TT Poppy Picked"
scoreboard objectives add ec.tt_s_dandy minecraft.picked_up:minecraft.dandelion "TT Dandelion Picked"
scoreboard objectives add ec.tt_s_blorch minecraft.picked_up:minecraft.blue_orchid "TT Blue Orchid Picked"
scoreboard objectives add ec.tt_s_allium minecraft.picked_up:minecraft.allium "TT Allium Picked"
scoreboard objectives add ec.tt_s_tulip minecraft.picked_up:minecraft.red_tulip "TT Red Tulip Picked"
scoreboard objectives add ec.tt_s_lily minecraft.picked_up:minecraft.lily_of_the_valley "TT Lily Picked"

# Dummy snapshots (store starting values for delta calculation)
scoreboard objectives add ec.tt_snap dummy "TT Snapshot"
scoreboard objectives add ec.tt_snap2 dummy "TT Snapshot 2"
scoreboard objectives add ec.tt_snap3 dummy "TT Snapshot 3"
scoreboard objectives add ec.tt_snap4 dummy "TT Snapshot 4"
scoreboard objectives add ec.tt_snap5 dummy "TT Snapshot 5"
scoreboard objectives add ec.tt_snap6 dummy "TT Snapshot 6"
scoreboard objectives add ec.tt_snap7 dummy "TT Snapshot 7"
scoreboard objectives add ec.tt_snap8 dummy "TT Snapshot 8"
scoreboard objectives add ec.tt_snap9 dummy "TT Snapshot 9"

# Arena position (for fill cleanup)
scoreboard objectives add ec.tt_arena_x dummy "TT Arena X"
scoreboard objectives add ec.tt_arena_y dummy "TT Arena Y"
scoreboard objectives add ec.tt_arena_z dummy "TT Arena Z"

# Far-grid arena slot: @s = claimed slot index (1-64, 0=none); fake players #tts1..#tts64 = the
# occupancy registry (1=in use). Persists across restarts so a mid-trial slot stays reserved;
# admin reset = evercraft:craftforever/trials/slot/reset_all.
scoreboard objectives add ec.tt_slot dummy "TT Arena Slot"

# Per-player return-marker owner id (race P0-2 — prevents cross-player teleport on simultaneous exit)
scoreboard objectives add ec.tt_owner dummy "TT Return Marker Owner"

# Per-player modifier bitfield (Craft-Trial Complexity Ladder, Wave 1). One bit per active
# modifier (bits 0-10); single-writer = craftforever/trials/mods/roll + roll_one. See
# craftforever/trials/mods/roll for the bit map.
scoreboard objectives add ec.tt_mods dummy "TT Modifier Bitfield"
# Per-player T10 instance id (castle p$(pid) adoption). Allocated by trials/t10/begin.
scoreboard objectives add ec.tt_pid dummy "TT T10 Instance Id"
# Per-player T10 themed-zone layout pick (1..4). Single-writer = trials/t10/begin.
scoreboard objectives add ec.tt_zone dummy "TT T10 Zone Layout"
# T10 instance-id allocator (global counter, single-writer = trials/t10/begin).
scoreboard objectives add ec.tt_pid_seq dummy "TT T10 Pid Sequence"
# Modifier hazard cadence counter (env hazards step on a shared timer; single-writer = mods/tick).
scoreboard objectives add ec.tt_haz_t dummy "TT Hazard Cadence"
# Creeping-hazard rising-floor current Y level (single-writer = mods/apply + mods/tick).
scoreboard objectives add ec.tt_haz_y dummy "TT Creeping Hazard Y"

# Spirit-Tool Pity (Joseph 2026-06-06): each successful GRAND (T10) clear of a category
# bumps that category's spirit-tool drop odds by +1 percentage point (cumulative bad-luck
# protection on top of the 5% base). Indexed by ec.tt_type (1-6 → mining/farming/fishing/
# building/lumber/artisan). Single-writer = craftforever/trials/spirit_pity: it ADDS 1 on a
# T10 clear that does NOT drop, and RESETS to 0 on the clear that DOES drop.
scoreboard objectives add ec.tt_sp_pity1 dummy "TT Spirit Pity: Mining"
scoreboard objectives add ec.tt_sp_pity2 dummy "TT Spirit Pity: Farming"
scoreboard objectives add ec.tt_sp_pity3 dummy "TT Spirit Pity: Fishing"
scoreboard objectives add ec.tt_sp_pity4 dummy "TT Spirit Pity: Building"
scoreboard objectives add ec.tt_sp_pity5 dummy "TT Spirit Pity: Lumber"
scoreboard objectives add ec.tt_sp_pity6 dummy "TT Spirit Pity: Artisan"

# Trial bossbar
bossbar add evercraft:trial_timer {"text":"Trial","color":"gold","italic":false}
bossbar set evercraft:trial_timer max 6000
bossbar set evercraft:trial_timer color yellow
bossbar set evercraft:trial_timer style notched_10
bossbar set evercraft:trial_timer visible false

# Global active flag (for tick gating)
execute unless score #tt_active ec.var matches 0.. run scoreboard players set #tt_active ec.var 0

# --- Constants ---
scoreboard players set #2 ec.const 2
scoreboard players set #6 ec.const 6
scoreboard players set #7 ec.const 7
scoreboard players set #20 ec.const 20
scoreboard players set #60 ec.const 60
# Powers of two for the trial modifier bitfield (ec.tt_mods) bit tests. Declared here so the
# trial engine never depends on another system's load order (idempotent re-set if already set).
scoreboard players set #4 ec.const 4
scoreboard players set #8 ec.const 8
scoreboard players set #16 ec.const 16
scoreboard players set #32 ec.const 32
scoreboard players set #64 ec.const 64
scoreboard players set #128 ec.const 128
scoreboard players set #256 ec.const 256
scoreboard players set #512 ec.const 512
scoreboard players set #1024 ec.const 1024

# --- Daily challenge init ---
function evercraft:craftforever/trials/daily_roll

# --- Start scheduled loops ---
# craftforever/tick is called every tick from main tick.mcfunction (line 460)
# Glow refresh runs on a 1s schedule since it only needs periodic refresh
schedule function evercraft:craftforever/artisan/glowies/refresh 1s replace

# --- Biome Node scheduled loops (Plan 3) ---
schedule function evercraft:craftforever/nodes/tick_spawn 5s replace
schedule function evercraft:craftforever/nodes/tick_particles 10t replace
schedule function evercraft:craftforever/nodes/tick_despawn 100t replace

# ═══ HOUSING LABORERS (Plan 4) ═══
scoreboard objectives add ec.lb_count dummy "Laborer Count"
scoreboard objectives add ec.lb_max dummy "Laborer Max Slots"
scoreboard objectives add ec.lb_state dummy "Laborer State"
scoreboard objectives add ec.lb_fed dummy "Laborer Satisfaction"
scoreboard objectives add ec.lb_food_tier dummy "Laborer Food Tier"
scoreboard objectives add ec.lb_food_cat dummy "Laborer Food Cat Match"
scoreboard objectives add ec.lb_quality dummy "Laborer Expedition Quality"
scoreboard objectives add ec.lb_expeditions dummy "Laborer Total Expeditions"
scoreboard objectives add ec.lb_adventures dummy "Laborer Total Adventures"
scoreboard objectives add ec.lb_perm_bonus dummy "Laborer Permanent Bonus"
scoreboard objectives add ec.lb_slot dummy "Laborer Slot Index"
scoreboard objectives add ec.lb_exp_start dummy "Laborer Expedition Start"
scoreboard objectives add ec.lb_exp_dur dummy "Laborer Expedition Duration"

# --- Spirit Tools (Plan: GOD-TIER T10 tools) ---
function evercraft:craftforever/spirit_tools/load

# --- Craftforever Titles (AU35-P2.1 Wave I 2026-05-31) — 3-tier Artisan title-team ---
scoreboard objectives add ec.cf_title_earned dummy "CF Title Tier Earned (0-3)"
scoreboard objectives add ec.cf_title_active dummy "CF Title Tier Equipped (0-3)"
function evercraft:craftforever/titles/load_teams
