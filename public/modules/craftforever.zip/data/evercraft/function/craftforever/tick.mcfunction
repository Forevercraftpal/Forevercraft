# === CRAFTFOREVER MAIN TICK ===
# Called from evercraft:tick

# ═══ ARTISAN TOME PANEL (#11, D1) — per-tick close/click scan ═══
# Existence-gated on ec.tome_menu (only players with the panel open). Runs BEFORE the forge
# early-exit gate below — the tome panel is NOT a forge entity, so it must not be gated by it.
execute as @a[tag=ec.tome_menu] at @s run function evercraft:craftforever/spirit_tools/tome/menu/tick
# Watchdog (5s): if nobody has a tome panel open, sweep any leaked panel entities.
execute if score #watchdog ec.var matches 99 if entity @e[tag=ec.tome_el,limit=1] unless entity @a[tag=ec.tome_menu] run kill @e[tag=ec.tome_el]

# ═══ QUESTLINE BOOK PANEL (#3, D1) — per-tick close/click scan (existence-gated on ec.qln_book) ═══
execute as @a[tag=ec.qln_book] at @s run function evercraft:codex/hub/grand_quests/qln/book_tick
execute if score #watchdog ec.var matches 99 if entity @e[tag=ec.qln_book_el,limit=1] unless entity @a[tag=ec.qln_book] run kill @e[tag=ec.qln_book_el]

# ═══ CRAFTFOREVER CODEX ORPHAN CLEANUP (runs before exit gate so orphans are always caught) ═══
# Every 5s (watchdog cycle): kill codex menu entities with no nearby owner
execute if score #watchdog ec.var matches 99 if entity @e[type=marker,tag=CF.MenuAnchor,limit=1] unless entity @a[tag=CF.InCodex] as @e[type=marker,tag=CF.MenuAnchor] at @s run kill @e[tag=CF.MenuElement,distance=..5]

# OPT: Early exit if no craftforever entities or menus exist
execute unless entity @e[type=interaction,tag=CF.Interact,limit=1] unless entity @e[type=marker,tag=CF.Marker,limit=1] unless entity @a[tag=CF.InMenu,limit=1] unless entity @a[scores={ec.tt_mastery=1..},limit=1] run return 0

# ═══ ARTISAN FORGE TABLE ═══

# Forge Table interaction detection
execute if entity @e[type=interaction,tag=CF.Interact,limit=1] as @e[type=interaction,tag=CF.Interact] if data entity @s interaction at @s run function evercraft:craftforever/forging/on_interact
execute if entity @e[type=interaction,tag=CF.Interact,limit=1] as @e[type=interaction,tag=CF.Interact] if data entity @s interaction at @s run data remove entity @s interaction

# Forge Table break detection (lodestone removed)
# OPT: Existence gate — skip when no Forge Table markers exist
execute if entity @e[type=marker,tag=CF.Marker,limit=1] as @e[type=marker,tag=CF.Marker] at @s unless block ~ ~ ~ minecraft:lodestone run function evercraft:craftforever/forging/on_break

# Forge Table ambient particles
execute if score #daylight_counter ec.var matches 0 as @e[type=marker,tag=CF.Marker] at @s if entity @a[distance=..32] run particle minecraft:flame ~0 ~1.3 ~0 0.15 0.1 0.15 0.01 2

# Forge GUI orphan cleanup (every 5s watchdog cycle)
# Kill forge menu entities if no CF.InMenu player exists nearby
# OPT: Consolidated 3 type-specific selectors into 1 tag-only selector
execute if score #watchdog ec.var matches 99 if entity @e[tag=CF.MenuEl,limit=1] unless entity @a[tag=CF.InMenu] as @e[tag=CF.MenuEl] run kill @s

# ═══ TRIAL MASTERY PARTICLES (every 20 ticks) ═══
execute if score #daylight_counter ec.var matches 0 as @a[scores={ec.tt_mastery=1..}] at @s run function evercraft:craftforever/trials/mastery_particles

# ═══ CRAFT RATE — Recalculate every 100 ticks (5s) ═══
# OPT-M1: Player-online gate — skip if no players online
execute if score #watchdog ec.var matches 99 if entity @a[limit=1] as @a run function evercraft:craftforever/craft_rate/calculate

# ═══ TITLE TIER — Recalculate every 5s (AU35-P2.1 Wave I) ═══
execute if score #watchdog ec.var matches 99 if entity @a[limit=1] as @a run function evercraft:craftforever/titles/check_tier
execute if score #watchdog ec.var matches 99 if entity @a[limit=1] as @a run function evercraft:craftforever/titles/apply

# ═══ DAILY CHALLENGE ROLL — moved to luck_buffs/tick.mcfunction dawn block ═══
# (Now unified with dungeon daily challenge via personal_roll)

# ═══ CRAFTFOREVER CODEX ORPHAN CLEANUP — moved before early exit gate (top of file) ═══
