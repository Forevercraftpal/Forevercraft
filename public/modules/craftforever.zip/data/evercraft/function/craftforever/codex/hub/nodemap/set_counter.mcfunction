# Node Map — Update discovery counter (two-row: OW + Total)
# Run as player, with storage evercraft:cf_temp {discovered:N, ow_count:N}
# AU14-P3 (Joseph 2026-05-30): two-row "OW: N/12" + "Total: N/15" resolves the denominator drift.

$execute as @e[type=text_display,tag=CF.MapCounter,distance=..5,limit=1] run data modify entity @s text set value [{text:"OW: $(ow_count)/12",color:"#8BC34A",bold:true},{text:"\n"},{text:"Total: $(discovered)/15",color:"yellow"}]
