# Craftforever Codex — Hub click detection
# Run as player in codex, #cf_gui_owner ec.temp = session ID

# Combine Three Codices into Eternal Codex
execute as @e[type=interaction,tag=CF.HubClickCombCodex,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s interaction on target run function evercraft:ecodex/do_combine_codices_cf
execute as @e[type=interaction,tag=CF.HubClickCombCodex,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction

# Section 9: Recipes (Cookbook + Recipe Book) — CF-specific
# Tinkering (2026-06-10 almanac promotion) -> section 22 (tinkerers family list)
execute as @e[type=interaction,tag=CF.HubClickTnk,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s interaction on target run function evercraft:craftforever/codex/hub/enter_section {section:22}
execute as @e[type=interaction,tag=CF.HubClickTnk,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction

execute as @e[type=interaction,tag=CF.HubClick1,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s interaction on target run function evercraft:craftforever/codex/hub/enter_section {section:9}
execute as @e[type=interaction,tag=CF.HubClick1,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction

# Section 4: Housing (Housing Guide + Trophy Gallery + Laborers) — CF-specific
execute as @e[type=interaction,tag=CF.HubClick2,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s interaction on target run function evercraft:craftforever/codex/hub/enter_section {section:4}
execute as @e[type=interaction,tag=CF.HubClick2,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction

# Section 10: Discovery (Almanac + Node Map + Material Index) — CF-specific
execute as @e[type=interaction,tag=CF.HubClick3,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s interaction on target run function evercraft:craftforever/codex/hub/enter_section {section:10}
execute as @e[type=interaction,tag=CF.HubClick3,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction

# === Journal + Cosmetics — CF-NATIVE pages (2026-06-10, Joseph) ===
# Was bridge_to_fc {section:5}/{section:3}: closing the CF codex and reopening
# the FC codex looked janky. The CF codex has its OWN pages (§11 travel_journal,
# §12 cf_cosmetics) — navigate inside instead.

# Section 11: Journal — CF-native
execute as @e[type=interaction,tag=CF.HubClick4,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s interaction on target run function evercraft:craftforever/codex/hub/enter_section {section:11}
execute as @e[type=interaction,tag=CF.HubClick4,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction

# Section 12: Cosmetics — CF-native
execute as @e[type=interaction,tag=CF.HubClick5,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s interaction on target run function evercraft:craftforever/codex/hub/enter_section {section:12}
execute as @e[type=interaction,tag=CF.HubClick5,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction

# Section 13: Crafting Classes — CF-specific
execute as @e[type=interaction,tag=CF.HubClick6,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s interaction on target run function evercraft:craftforever/codex/hub/enter_section {section:13}
execute as @e[type=interaction,tag=CF.HubClick6,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction

# Section 14: Milestones — CF-specific (overview with drill-down into FC detail pages)
execute as @e[type=interaction,tag=CF.HubClick7,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s interaction on target run function evercraft:craftforever/codex/hub/enter_section {section:14}
execute as @e[type=interaction,tag=CF.HubClick7,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction

# Section 21: Mastery & Forge overview (Wiring Audit #14 W3 — Alchemy/GrandForge/Trials/Profile/Artifacts/SpiritTools)
execute as @e[type=interaction,tag=CF.HubClick8,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s interaction on target run function evercraft:craftforever/codex/hub/enter_section {section:21}
execute as @e[type=interaction,tag=CF.HubClick8,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction

# Fisher's Path: bridge into the main codex §26 Grand Quests + open the Fisher's Path questline
# PAGE (#3/D3 GUI; was the fishing/questline/overview chat wall). Fires as the player, on target.
execute as @e[type=interaction,tag=CF.HubClick9,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s interaction on target run function evercraft:craftforever/codex/hub/bridge_to_fish
execute as @e[type=interaction,tag=CF.HubClick9,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction

# ===== CORNER BUTTONS (mirror of the main Eternal Codex hub — Joseph D4) =====
# Help ? → bridge to main codex §9 (Help Guide — global, reuse don't fork).
execute as @e[type=interaction,tag=CF.HubClickHelp,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s interaction on target run function evercraft:craftforever/codex/hub/bridge_to_fc {section:9}
execute as @e[type=interaction,tag=CF.HubClickHelp,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction
# Settings ⚙ → bridge to main codex §25 (Settings — global player setting).
execute as @e[type=interaction,tag=CF.HubClickSettings,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s interaction on target run function evercraft:craftforever/codex/hub/bridge_to_fc {section:25}
execute as @e[type=interaction,tag=CF.HubClickSettings,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction
# Profile ☺ → the NEW crafting profile = CF §18 Artisan Profile (+ the #10 Craft-Rate ladder),
# NOT the main §21 Adventurer Card. CF-native — the repoint Joseph called.
execute as @e[type=interaction,tag=CF.HubClickProfile,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s interaction on target run function evercraft:craftforever/codex/hub/enter_section {section:18}
execute as @e[type=interaction,tag=CF.HubClickProfile,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction
# Recap ⟳ → close the CF codex + show the global run recap (mirror the main codex recap action).
scoreboard players set #cf_recap_click ec.temp 0
execute store success score #cf_recap_click ec.temp as @e[type=interaction,tag=CF.HubClickRecap,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction
execute if score #cf_recap_click ec.temp matches 1 run function evercraft:craftforever/codex/hub/close
execute if score #cf_recap_click ec.temp matches 1 run function evercraft:stats/recap/show

# ===== INSPECT (left-click = what does this button do?) — gui/inspect pattern 2026-06-11 =====
execute as @e[type=interaction,tag=CF.HubClickCombCodex,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Combine Codices",b:"Fuses the three codices you carry into the single Eternal Codex."}
execute as @e[type=interaction,tag=CF.HubClickCombCodex,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=CF.HubClickTnk,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Tinkering",b:"Artifact fusion families — every recipe, and which fusions are ready right now."}
execute as @e[type=interaction,tag=CF.HubClickTnk,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=CF.HubClick1,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Recipes",b:"The cookbook and recipe book — every dish and recipe you have learned."}
execute as @e[type=interaction,tag=CF.HubClick1,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=CF.HubClick2,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Housing",b:"The housing guide, your trophy gallery, and your laborers."}
execute as @e[type=interaction,tag=CF.HubClick2,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=CF.HubClick3,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Discovery",b:"Discovery tools — the almanac, the node map, and the material index."}
execute as @e[type=interaction,tag=CF.HubClick3,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=CF.HubClick4,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Journal",b:"Your CraftForever journal — journeys and finds recorded as you craft and gather."}
execute as @e[type=interaction,tag=CF.HubClick4,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=CF.HubClick5,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Cosmetics",b:"CraftForever cosmetics — looks earned through crafting feats."}
execute as @e[type=interaction,tag=CF.HubClick5,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=CF.HubClick6,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Crafting Classes",b:"The crafting classes — pick a path and see what each one offers."}
execute as @e[type=interaction,tag=CF.HubClick6,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=CF.HubClick7,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Milestones",b:"CraftForever milestone walls — claim rewards as your craft totals climb."}
execute as @e[type=interaction,tag=CF.HubClick7,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=CF.HubClick8,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Mastery and Forge",b:"Mastery overview — chemistry, the Grand Forge, trials, spirit tools, and more."}
execute as @e[type=interaction,tag=CF.HubClick8,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=CF.HubClick9,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Fishers Path",b:"Opens the Fishers Path questline in the Grand Quests chronicle."}
execute as @e[type=interaction,tag=CF.HubClick9,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=CF.HubClickHelp,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Help Guide",b:"Guides that explain every system in the realm, one page at a time."}
execute as @e[type=interaction,tag=CF.HubClickHelp,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=CF.HubClickSettings,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Settings",b:"Personal toggles — effect visuals, sounds, and notification preferences."}
execute as @e[type=interaction,tag=CF.HubClickSettings,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=CF.HubClickProfile,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Artisan Profile",b:"Your artisan profile — Craft Rate ladder and crafting standing."}
execute as @e[type=interaction,tag=CF.HubClickProfile,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=CF.HubClickRecap,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Session Recap",b:"Closes the codex and prints a recap of what this session earned you."}
execute as @e[type=interaction,tag=CF.HubClickRecap,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s attack run data remove entity @s attack
