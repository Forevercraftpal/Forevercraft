# Per-player Craftforever Codex give with inv-full hygiene
# Run as @s = player, at @s.
# Wraps the inv-full check + give/drop so #inv_full ec.var can't race across players.

execute store result score #inv_full ec.var run function evercraft:util/check_inv_full
execute if score #inv_full ec.var matches 0 run loot give @s loot evercraft:craftforever/codex_item
execute if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:craftforever/codex_item
