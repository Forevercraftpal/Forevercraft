# Node Map — Append the overworld Nest discovery line (Forest Hive + Tidal Nest) [PLAN-nest §7].
# Run as the CF.MapOverworld text_display (build_overworld already set its text array). Appends a
# newline + the two OW nest statuses (Forest = bit 1, Water = bit 2 of cf_nest_found).
data modify entity @s text append value {"text":"\n","color":"gray"}
execute if score #cf_n_forest ec.temp matches 1 run data modify entity @s text append value {"text":"✓ Forest Hive  ","color":"#FBBF24"}
execute if score #cf_n_forest ec.temp matches 0 run data modify entity @s text append value {"text":"○ Forest Hive  ","color":"dark_gray"}
execute if score #cf_n_water ec.temp matches 1 run data modify entity @s text append value {"text":"✓ Tidal Nest","color":"#22D3EE"}
execute if score #cf_n_water ec.temp matches 0 run data modify entity @s text append value {"text":"○ Tidal Nest","color":"dark_gray"}
