# Material Index — Click handler for material row
# Runs as interaction entity, outputs detail tellraw to nearest codex player.
# AU14-P2 (Joseph 2026-05-30): per-material spoiler gate. Each material reveal is gated on its
# `ec.cf_materials` bitfield discovery bit (set by `craftforever/nodes/complete_mine` on first mine).
# Undiscovered materials show a shared "Undiscovered Material" placeholder via show_locked.

data remove entity @s interaction

# Mat 1: Frostcrystal Shard — Frozen biomes (bit 0 / pow 1)
execute if entity @s[tag=CF.MatRow1] run function evercraft:craftforever/codex/hub/materials/check_disc_bit {pow:1}
execute if entity @s[tag=CF.MatRow1] if score #cf_disc_match ec.temp matches 1 run tellraw @p[tag=CF.InCodex,distance=..5] [{"text":"\n"},{"text":"◆ ","color":"#7DD3FC"},{"text":"Frostcrystal Shard","color":"#7DD3FC","bold":true},{"text":"\n"},{"text":"Shards of frozen light from tundra nodes.","color":"gray","italic":true},{"text":"\n"},{"text":"Biome: ","color":"gray"},{"text":"Frozen / Snowy","color":"#7DD3FC"},{"text":"\n"},{"text":"Rarity: ","color":"gray"},{"text":"Rare","color":"aqua"},{"text":"\n"},{"text":"Used in higher-tier forging recipes.","color":"dark_gray","italic":true}]
execute if entity @s[tag=CF.MatRow1] unless score #cf_disc_match ec.temp matches 1 run function evercraft:craftforever/codex/hub/materials/show_locked

# Mat 2: Sunite Dust — Desert/warm biomes (bit 1 / pow 2)
execute if entity @s[tag=CF.MatRow2] run function evercraft:craftforever/codex/hub/materials/check_disc_bit {pow:2}
execute if entity @s[tag=CF.MatRow2] if score #cf_disc_match ec.temp matches 1 run tellraw @p[tag=CF.InCodex,distance=..5] [{"text":"\n"},{"text":"◆ ","color":"#FCD34D"},{"text":"Sunite Dust","color":"#FCD34D","bold":true},{"text":"\n"},{"text":"Golden dust that glitters like sunlight.","color":"gray","italic":true},{"text":"\n"},{"text":"Biome: ","color":"gray"},{"text":"Desert / Badlands","color":"#FCD34D"},{"text":"\n"},{"text":"Rarity: ","color":"gray"},{"text":"Rare","color":"aqua"},{"text":"\n"},{"text":"Used in higher-tier forging recipes.","color":"dark_gray","italic":true}]
execute if entity @s[tag=CF.MatRow2] unless score #cf_disc_match ec.temp matches 1 run function evercraft:craftforever/codex/hub/materials/show_locked

# Mat 3: Voidite Fragment — Deep dark (bit 2 / pow 4)
execute if entity @s[tag=CF.MatRow3] run function evercraft:craftforever/codex/hub/materials/check_disc_bit {pow:4}
execute if entity @s[tag=CF.MatRow3] if score #cf_disc_match ec.temp matches 1 run tellraw @p[tag=CF.InCodex,distance=..5] [{"text":"\n"},{"text":"◆ ","color":"#164E63"},{"text":"Voidite Fragment","color":"#164E63","bold":true},{"text":"\n"},{"text":"A shard of compressed darkness.","color":"gray","italic":true},{"text":"\n"},{"text":"Biome: ","color":"gray"},{"text":"Deep Dark","color":"#164E63"},{"text":"\n"},{"text":"Rarity: ","color":"gray"},{"text":"Exquisite","color":"gold"},{"text":"\n"},{"text":"Highly prized by master forgers.","color":"dark_gray","italic":true}]
execute if entity @s[tag=CF.MatRow3] unless score #cf_disc_match ec.temp matches 1 run function evercraft:craftforever/codex/hub/materials/show_locked

# Mat 4: Livingstone Moss — Lush biomes (bit 3 / pow 8)
execute if entity @s[tag=CF.MatRow4] run function evercraft:craftforever/codex/hub/materials/check_disc_bit {pow:8}
execute if entity @s[tag=CF.MatRow4] if score #cf_disc_match ec.temp matches 1 run tellraw @p[tag=CF.InCodex,distance=..5] [{"text":"\n"},{"text":"◆ ","color":"#4ADE80"},{"text":"Livingstone Moss","color":"#4ADE80","bold":true},{"text":"\n"},{"text":"Moss that pulses with gentle life.","color":"gray","italic":true},{"text":"\n"},{"text":"Biome: ","color":"gray"},{"text":"Lush Caves / Forest","color":"#4ADE80"},{"text":"\n"},{"text":"Rarity: ","color":"gray"},{"text":"Uncommon","color":"green"},{"text":"\n"},{"text":"A common but useful crafting material.","color":"dark_gray","italic":true}]
execute if entity @s[tag=CF.MatRow4] unless score #cf_disc_match ec.temp matches 1 run function evercraft:craftforever/codex/hub/materials/show_locked

# Mat 5: Tideforged Pearl — Ocean biomes (bit 4 / pow 16)
execute if entity @s[tag=CF.MatRow5] run function evercraft:craftforever/codex/hub/materials/check_disc_bit {pow:16}
execute if entity @s[tag=CF.MatRow5] if score #cf_disc_match ec.temp matches 1 run tellraw @p[tag=CF.InCodex,distance=..5] [{"text":"\n"},{"text":"◆ ","color":"#22D3EE"},{"text":"Tideforged Pearl","color":"#22D3EE","bold":true},{"text":"\n"},{"text":"A pearl shaped by ocean currents over millennia.","color":"gray","italic":true},{"text":"\n"},{"text":"Biome: ","color":"gray"},{"text":"Ocean / Beach","color":"#22D3EE"},{"text":"\n"},{"text":"Rarity: ","color":"gray"},{"text":"Rare","color":"aqua"},{"text":"\n"},{"text":"Sought by artisans and traders alike.","color":"dark_gray","italic":true}]
execute if entity @s[tag=CF.MatRow5] unless score #cf_disc_match ec.temp matches 1 run function evercraft:craftforever/codex/hub/materials/show_locked

# Mat 6: Blazite Crystal — Nether biomes (bit 5 / pow 32)
execute if entity @s[tag=CF.MatRow6] run function evercraft:craftforever/codex/hub/materials/check_disc_bit {pow:32}
execute if entity @s[tag=CF.MatRow6] if score #cf_disc_match ec.temp matches 1 run tellraw @p[tag=CF.InCodex,distance=..5] [{"text":"\n"},{"text":"◆ ","color":"#EF4444"},{"text":"Blazite Crystal","color":"#EF4444","bold":true},{"text":"\n"},{"text":"Crystallized nether flame, burning eternally.","color":"gray","italic":true},{"text":"\n"},{"text":"Biome: ","color":"gray"},{"text":"Nether Wastes / Basalt","color":"#EF4444"},{"text":"\n"},{"text":"Rarity: ","color":"gray"},{"text":"Ornate","color":"light_purple"},{"text":"\n"},{"text":"Essential for advanced alloy forging.","color":"dark_gray","italic":true}]
execute if entity @s[tag=CF.MatRow6] unless score #cf_disc_match ec.temp matches 1 run function evercraft:craftforever/codex/hub/materials/show_locked

# Mat 7: Warpstone Dust — Warped Forest (bit 6 / pow 64)
execute if entity @s[tag=CF.MatRow7] run function evercraft:craftforever/codex/hub/materials/check_disc_bit {pow:64}
execute if entity @s[tag=CF.MatRow7] if score #cf_disc_match ec.temp matches 1 run tellraw @p[tag=CF.InCodex,distance=..5] [{"text":"\n"},{"text":"◆ ","color":"#2DD4BF"},{"text":"Warpstone Dust","color":"#2DD4BF","bold":true},{"text":"\n"},{"text":"Dust from between dimensions.","color":"gray","italic":true},{"text":"\n"},{"text":"Biome: ","color":"gray"},{"text":"Warped / Crimson Forest","color":"#2DD4BF"},{"text":"\n"},{"text":"Rarity: ","color":"gray"},{"text":"Ornate","color":"light_purple"},{"text":"\n"},{"text":"Bends space when forged into alloys.","color":"dark_gray","italic":true}]
execute if entity @s[tag=CF.MatRow7] unless score #cf_disc_match ec.temp matches 1 run function evercraft:craftforever/codex/hub/materials/show_locked

# Mat 8: Endric Shard — End biomes (bit 7 / pow 128)
execute if entity @s[tag=CF.MatRow8] run function evercraft:craftforever/codex/hub/materials/check_disc_bit {pow:128}
execute if entity @s[tag=CF.MatRow8] if score #cf_disc_match ec.temp matches 1 run tellraw @p[tag=CF.InCodex,distance=..5] [{"text":"\n"},{"text":"◆ ","color":"#A855F7"},{"text":"Endric Shard","color":"#A855F7","bold":true},{"text":"\n"},{"text":"A fragment of the void between stars.","color":"gray","italic":true},{"text":"\n"},{"text":"Biome: ","color":"gray"},{"text":"The End","color":"#A855F7"},{"text":"\n"},{"text":"Rarity: ","color":"gray"},{"text":"Mythical","color":"gold"},{"text":"\n"},{"text":"The rarest of all forging materials.","color":"dark_gray","italic":true}]
execute if entity @s[tag=CF.MatRow8] unless score #cf_disc_match ec.temp matches 1 run function evercraft:craftforever/codex/hub/materials/show_locked

# Mat 9: Sporite Cap — Mushroom biomes (bit 8 / pow 256)
execute if entity @s[tag=CF.MatRow9] run function evercraft:craftforever/codex/hub/materials/check_disc_bit {pow:256}
execute if entity @s[tag=CF.MatRow9] if score #cf_disc_match ec.temp matches 1 run tellraw @p[tag=CF.InCodex,distance=..5] [{"text":"\n"},{"text":"◆ ","color":"#E879F9"},{"text":"Sporite Cap","color":"#E879F9","bold":true},{"text":"\n"},{"text":"A luminous fungal cap that hums softly.","color":"gray","italic":true},{"text":"\n"},{"text":"Biome: ","color":"gray"},{"text":"Mushroom Fields","color":"#E879F9"},{"text":"\n"},{"text":"Rarity: ","color":"gray"},{"text":"Ornate","color":"light_purple"},{"text":"\n"},{"text":"Prized for its unique chemical properties.","color":"dark_gray","italic":true}]
execute if entity @s[tag=CF.MatRow9] unless score #cf_disc_match ec.temp matches 1 run function evercraft:craftforever/codex/hub/materials/show_locked

# Mat 10: Verdant Gem — Jungle biomes (bit 9 / pow 512)
execute if entity @s[tag=CF.MatRow10] run function evercraft:craftforever/codex/hub/materials/check_disc_bit {pow:512}
execute if entity @s[tag=CF.MatRow10] if score #cf_disc_match ec.temp matches 1 run tellraw @p[tag=CF.InCodex,distance=..5] [{"text":"\n"},{"text":"◆ ","color":"#34D399"},{"text":"Verdant Gem","color":"#34D399","bold":true},{"text":"\n"},{"text":"A gem saturated with life energy.","color":"gray","italic":true},{"text":"\n"},{"text":"Biome: ","color":"gray"},{"text":"Jungle / Bamboo","color":"#34D399"},{"text":"\n"},{"text":"Rarity: ","color":"gray"},{"text":"Rare","color":"aqua"},{"text":"\n"},{"text":"Channels natural growth into forged metal.","color":"dark_gray","italic":true}]
execute if entity @s[tag=CF.MatRow10] unless score #cf_disc_match ec.temp matches 1 run function evercraft:craftforever/codex/hub/materials/show_locked

# Mat 11: Skymetal Nugget — Mountain biomes (bit 10 / pow 1024)
execute if entity @s[tag=CF.MatRow11] run function evercraft:craftforever/codex/hub/materials/check_disc_bit {pow:1024}
execute if entity @s[tag=CF.MatRow11] if score #cf_disc_match ec.temp matches 1 run tellraw @p[tag=CF.InCodex,distance=..5] [{"text":"\n"},{"text":"◆ ","color":"#E2E8F0"},{"text":"Skymetal Nugget","color":"#E2E8F0","bold":true},{"text":"\n"},{"text":"Metal fallen from beyond the sky.","color":"gray","italic":true},{"text":"\n"},{"text":"Biome: ","color":"gray"},{"text":"Mountains / Peaks","color":"#E2E8F0"},{"text":"\n"},{"text":"Rarity: ","color":"gray"},{"text":"Exquisite","color":"gold"},{"text":"\n"},{"text":"Incredibly light yet unbreakable.","color":"dark_gray","italic":true}]
execute if entity @s[tag=CF.MatRow11] unless score #cf_disc_match ec.temp matches 1 run function evercraft:craftforever/codex/hub/materials/show_locked

# Mat 12: Sunforged Brick — Savanna biomes (bit 11 / pow 2048)
execute if entity @s[tag=CF.MatRow12] run function evercraft:craftforever/codex/hub/materials/check_disc_bit {pow:2048}
execute if entity @s[tag=CF.MatRow12] if score #cf_disc_match ec.temp matches 1 run tellraw @p[tag=CF.InCodex,distance=..5] [{"text":"\n"},{"text":"◆ ","color":"#F97316"},{"text":"Sunforged Brick","color":"#F97316","bold":true},{"text":"\n"},{"text":"Clay baked by millennia of unbroken sun.","color":"gray","italic":true},{"text":"\n"},{"text":"Biome: ","color":"gray"},{"text":"Savanna / Plains","color":"#F97316"},{"text":"\n"},{"text":"Rarity: ","color":"gray"},{"text":"Rare","color":"aqua"},{"text":"\n"},{"text":"Retains heat long after forging.","color":"dark_gray","italic":true}]
execute if entity @s[tag=CF.MatRow12] unless score #cf_disc_match ec.temp matches 1 run function evercraft:craftforever/codex/hub/materials/show_locked

# Mat 13: Shadowroot Extract — Dark forest (bit 12 / pow 4096)
execute if entity @s[tag=CF.MatRow13] run function evercraft:craftforever/codex/hub/materials/check_disc_bit {pow:4096}
execute if entity @s[tag=CF.MatRow13] if score #cf_disc_match ec.temp matches 1 run tellraw @p[tag=CF.InCodex,distance=..5] [{"text":"\n"},{"text":"◆ ","color":"#581C87"},{"text":"Shadowroot Extract","color":"#581C87","bold":true},{"text":"\n"},{"text":"Sap from roots that grow in total darkness.","color":"gray","italic":true},{"text":"\n"},{"text":"Biome: ","color":"gray"},{"text":"Dark Forest / Roofed","color":"#581C87"},{"text":"\n"},{"text":"Rarity: ","color":"gray"},{"text":"Rare","color":"aqua"},{"text":"\n"},{"text":"Absorbs light and strengthens shadow.","color":"dark_gray","italic":true}]
execute if entity @s[tag=CF.MatRow13] unless score #cf_disc_match ec.temp matches 1 run function evercraft:craftforever/codex/hub/materials/show_locked

# Mat 14: Bogstone — Swamp biomes (bit 13 / pow 8192)
execute if entity @s[tag=CF.MatRow14] run function evercraft:craftforever/codex/hub/materials/check_disc_bit {pow:8192}
execute if entity @s[tag=CF.MatRow14] if score #cf_disc_match ec.temp matches 1 run tellraw @p[tag=CF.InCodex,distance=..5] [{"text":"\n"},{"text":"◆ ","color":"#65A30D"},{"text":"Bogstone","color":"#65A30D","bold":true},{"text":"\n"},{"text":"Ancient stone marinated in swamp water.","color":"gray","italic":true},{"text":"\n"},{"text":"Biome: ","color":"gray"},{"text":"Swamp / Mangrove","color":"#65A30D"},{"text":"\n"},{"text":"Rarity: ","color":"gray"},{"text":"Uncommon","color":"green"},{"text":"\n"},{"text":"Surprisingly resilient when properly forged.","color":"dark_gray","italic":true}]
execute if entity @s[tag=CF.MatRow14] unless score #cf_disc_match ec.temp matches 1 run function evercraft:craftforever/codex/hub/materials/show_locked

# Mat 15: Blossom Essence — Cherry / Flower biomes (bit 14 / pow 16384)
execute if entity @s[tag=CF.MatRow15] run function evercraft:craftforever/codex/hub/materials/check_disc_bit {pow:16384}
execute if entity @s[tag=CF.MatRow15] if score #cf_disc_match ec.temp matches 1 run tellraw @p[tag=CF.InCodex,distance=..5] [{"text":"\n"},{"text":"◆ ","color":"#F9A8D4"},{"text":"Blossom Essence","color":"#F9A8D4","bold":true},{"text":"\n"},{"text":"Distilled petals from an eternal spring.","color":"gray","italic":true},{"text":"\n"},{"text":"Biome: ","color":"gray"},{"text":"Cherry Grove / Flower","color":"#F9A8D4"},{"text":"\n"},{"text":"Rarity: ","color":"gray"},{"text":"Rare","color":"aqua"},{"text":"\n"},{"text":"Infuses forged items with gentle warmth.","color":"dark_gray","italic":true}]
execute if entity @s[tag=CF.MatRow15] unless score #cf_disc_match ec.temp matches 1 run function evercraft:craftforever/codex/hub/materials/show_locked

# Sound + cooldown
playsound minecraft:block.note_block.hat master @p[tag=CF.InCodex,distance=..5,scores={ec.fx_snd=1..}] ~ ~ ~ 0.5 1.8
execute as @p[tag=CF.InCodex,distance=..5] run scoreboard players set @s ec.cf_codex_cd 3
