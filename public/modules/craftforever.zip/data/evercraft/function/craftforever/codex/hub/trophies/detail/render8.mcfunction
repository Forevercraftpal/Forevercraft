# Trophy Detail — Battle Master (trophy id 7, pg 8). Run as player at player.
# Mirror of materials/detail/render1: stacked text_display rows at ^ ^Y ^1.78 + Back hitbox at ^1.8.
# Reproduces every datum from trophies/check_clicks arg-set 7 + show_trophy_info_tell (bareword SNBT).
# ec.cf_trophies + all earned_score objectives READ-ONLY. Earned bit via #trophy_bit_7 (mirror tell:5-7).
# NOTE (mixed input): the gallery grid opens on LEFT-click (attack); this page's Back is RIGHT-click
# (CF.TrBackClick, matches every other codex Back). Do not "fix" to one mode — it is intentional.

# Earned bit (mirror show_trophy_info_tell): #trophy_earned = trophies / bit_7 % 2
scoreboard players operation #trophy_earned ec.temp = @s ec.cf_trophies
scoreboard players operation #trophy_earned ec.temp /= #trophy_bit_7 ec.const
scoreboard players operation #trophy_earned ec.temp %= #2 ec.const

# === EARNED CARD ===
execute if score #trophy_earned ec.temp matches 1 at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^ ^1.78 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["CF.MenuElement","CF.SectionContent"],billboard:"center",text:["",{text:"✦ ",color:"red"},{text:"Battle Master",color:"red",bold:true},{text:" ✦",color:"red"}],background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.245f,0.245f,0.245f]}}
execute if score #trophy_earned ec.temp matches 1 at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^ ^1.66 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["CF.MenuElement","CF.SectionContent"],billboard:"center",text:["",{text:"Status: ",color:"gray"},{text:"✓ Earned!",color:"green",bold:true}],background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.18f,0.18f,0.18f]}}
execute if score #trophy_earned ec.temp matches 1 at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^ ^1.56 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["CF.MenuElement","CF.SectionContent"],billboard:"center",text:["",{text:"Requirement: ",color:"gray"},{text:"Complete 20 combat milestones",color:"white"}],background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.15f,0.15f,0.15f]}}
execute if score #trophy_earned ec.temp matches 1 at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^ ^1.38 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["CF.MenuElement","CF.SectionContent"],billboard:"center",text:["",{text:"Reward: ",color:"gray"},{text:"Trophy head (+25 Comfort)",color:"#FDD835"}],background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.15f,0.15f,0.15f]}}

# === LOCKED CARD ===
execute if score #trophy_earned ec.temp matches 0 at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^ ^1.78 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["CF.MenuElement","CF.SectionContent"],billboard:"center",text:["",{text:"✦ ",color:"dark_gray"},{text:"??? ",color:"dark_gray",bold:true},{text:"✦",color:"dark_gray"}],background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.245f,0.245f,0.245f]}}
execute if score #trophy_earned ec.temp matches 0 at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^ ^1.66 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["CF.MenuElement","CF.SectionContent"],billboard:"center",text:["",{text:"Status: ",color:"gray"},{text:"✗ Locked",color:"red"}],background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.18f,0.18f,0.18f]}}
execute if score #trophy_earned ec.temp matches 0 at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^ ^1.56 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["CF.MenuElement","CF.SectionContent"],billboard:"center",text:["",{text:"Requirement: ",color:"gray"},{text:"Complete 20 combat milestones",color:"white"}],background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.15f,0.15f,0.15f]}}
# === 26.1 fix: {score} blank in text_display -> bake via storage macro ===
scoreboard players add @s ec.combat_ms 0
execute store result storage evercraft:scorebake args.v1 int 1 run scoreboard players get @s ec.combat_ms
function evercraft:craftforever/codex/hub/trophies/detail/render8_dyn with storage evercraft:scorebake args
execute if score #trophy_earned ec.temp matches 0 at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^ ^1.38 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["CF.MenuElement","CF.SectionContent"],billboard:"center",text:["",{text:"Reward: ",color:"gray"},{text:"Trophy head (+25 Comfort)",color:"dark_gray"}],background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.15f,0.15f,0.15f]}}

# === Back to Gallery (always; reached via right-click on target, NOT attack) ===
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^ ^1.1 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["CF.MenuElement","CF.SectionContent"],billboard:"center",text:{text:"◀ Back to Gallery",color:"gold"},background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.215f,0.215f,0.215f]}}
# [strip] CF.MenuElement: 0.8w split into 4 x 0.2 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^-0.3 ^1.1 ^1.8 run summon interaction ~ ~ ~ {Tags:["CF.MenuElement","CF.SectionContent","CF.TrBackClick"],width:0.2f,height:0.2f,response:1b}
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^-0.1 ^1.1 ^1.8 run summon interaction ~ ~ ~ {Tags:["CF.MenuElement","CF.SectionContent","CF.TrBackClick"],width:0.2f,height:0.2f,response:1b}
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^0.1 ^1.1 ^1.8 run summon interaction ~ ~ ~ {Tags:["CF.MenuElement","CF.SectionContent","CF.TrBackClick"],width:0.2f,height:0.2f,response:1b}
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^0.3 ^1.1 ^1.8 run summon interaction ~ ~ ~ {Tags:["CF.MenuElement","CF.SectionContent","CF.TrBackClick"],width:0.2f,height:0.2f,response:1b}
