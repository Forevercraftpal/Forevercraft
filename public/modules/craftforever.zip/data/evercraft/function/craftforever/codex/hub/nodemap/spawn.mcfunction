# Craftforever Codex — Node Map Section
# Text-based map showing which biomes have been discovered
# Clickable dimension headers show detailed breakdown in chat
# Run as player at player position

# Init node map to grid page (0 = grid, 1=Overworld 2=Nether 3=End detail). Mirrors materials/spawn:6.
scoreboard players set @s ec.cf_node_pg 0

# Hint text
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^ ^2.03 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["CF.MenuElement","CF.SectionContent"],billboard:"center",text:[{text:"\u25b6 ",color:"dark_gray"},{text:"Click a region for details",color:"dark_gray",italic:true}],background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.191f,0.191f,0.191f]}}

# === OVERWORLD ===
# Header (clickable)
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^ ^1.85 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["CF.MenuElement","CF.SectionContent"],billboard:"center",text:[{text:"\u25b6 ",color:"#8BC34A"},{text:"Overworld","color":"white","bold":true},{text:" \u25c0","color":"#8BC34A"}],background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.334f,0.334f,0.334f]}}
# [strip] CF.MenuElement: 0.8w split into 4 x 0.2 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^-0.3 ^1.7 ^1.8 run summon interaction ~ ~ ~ {Tags:["CF.MenuElement","CF.SectionContent","CF.MapOWClick"],width:0.2f,height:0.3f,response:1b}
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^-0.1 ^1.7 ^1.8 run summon interaction ~ ~ ~ {Tags:["CF.MenuElement","CF.SectionContent","CF.MapOWClick"],width:0.2f,height:0.3f,response:1b}
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^0.1 ^1.7 ^1.8 run summon interaction ~ ~ ~ {Tags:["CF.MenuElement","CF.SectionContent","CF.MapOWClick"],width:0.2f,height:0.3f,response:1b}
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^0.3 ^1.7 ^1.8 run summon interaction ~ ~ ~ {Tags:["CF.MenuElement","CF.SectionContent","CF.MapOWClick"],width:0.2f,height:0.3f,response:1b}

# Overworld biome grid
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^ ^1.55 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,line_width:300,Tags:["CF.MenuElement","CF.SectionContent","CF.MapOverworld"],billboard:"center",text:{text:"Loading...",color:"gray"},background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.238f,0.238f,0.238f]}}

# === NETHER ===
# Header (clickable)
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^ ^1.13 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["CF.MenuElement","CF.SectionContent"],billboard:"center",text:[{text:"\u25b6 ",color:"#EF4444"},{text:"Nether","color":"#EF4444","bold":true},{text:" \u25c0","color":"#EF4444"}],background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.334f,0.334f,0.334f]}}
# [strip] CF.MenuElement: 0.6w split into 4 x 0.16 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^-0.22 ^1.05 ^1.8 run summon interaction ~ ~ ~ {Tags:["CF.MenuElement","CF.SectionContent","CF.MapNetherClick"],width:0.16f,height:0.16f,response:1b}
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^-0.0733 ^1.05 ^1.8 run summon interaction ~ ~ ~ {Tags:["CF.MenuElement","CF.SectionContent","CF.MapNetherClick"],width:0.16f,height:0.16f,response:1b}
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^0.0733 ^1.05 ^1.8 run summon interaction ~ ~ ~ {Tags:["CF.MenuElement","CF.SectionContent","CF.MapNetherClick"],width:0.16f,height:0.16f,response:1b}
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^0.22 ^1.05 ^1.8 run summon interaction ~ ~ ~ {Tags:["CF.MenuElement","CF.SectionContent","CF.MapNetherClick"],width:0.16f,height:0.16f,response:1b}

# Nether entries
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^ ^0.97 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,line_width:300,Tags:["CF.MenuElement","CF.SectionContent","CF.MapNether"],billboard:"center",text:{text:"Loading...",color:"gray"},background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.238f,0.238f,0.238f]}}

# === THE END ===
# Header (clickable)
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^ ^0.73 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["CF.MenuElement","CF.SectionContent"],billboard:"center",text:[{text:"\u25b6 ",color:"#A855F7"},{text:"The End","color":"#A855F7","bold":true},{text:" \u25c0","color":"#A855F7"}],background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.334f,0.334f,0.334f]}}
# [strip] CF.MenuElement: 0.6w split into 5 x 0.13 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^-0.235 ^0.665 ^1.8 run summon interaction ~ ~ ~ {Tags:["CF.MenuElement","CF.SectionContent","CF.MapEndClick"],width:0.13f,height:0.13f,response:1b}
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^-0.1175 ^0.665 ^1.8 run summon interaction ~ ~ ~ {Tags:["CF.MenuElement","CF.SectionContent","CF.MapEndClick"],width:0.13f,height:0.13f,response:1b}
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^0 ^0.665 ^1.8 run summon interaction ~ ~ ~ {Tags:["CF.MenuElement","CF.SectionContent","CF.MapEndClick"],width:0.13f,height:0.13f,response:1b}
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^0.1175 ^0.665 ^1.8 run summon interaction ~ ~ ~ {Tags:["CF.MenuElement","CF.SectionContent","CF.MapEndClick"],width:0.13f,height:0.13f,response:1b}
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^0.235 ^0.665 ^1.8 run summon interaction ~ ~ ~ {Tags:["CF.MenuElement","CF.SectionContent","CF.MapEndClick"],width:0.13f,height:0.13f,response:1b}

# End entry
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^ ^0.6 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,line_width:300,Tags:["CF.MenuElement","CF.SectionContent","CF.MapEnd"],billboard:"center",text:{text:"Loading...",color:"gray"},background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.238f,0.238f,0.238f]}}

# Discovery counter (placeholder; overwritten same-tick by refresh -> set_counter two-row "OW: N/12" + "Total: N/15", AU14-P3)
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^ ^0.4 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["CF.MenuElement","CF.SectionContent","CF.MapCounter"],billboard:"center",text:[{text:"OW: 0/12",color:"#8BC34A",bold:true},{text:"\n"},{text:"Total: 0/15",color:"yellow"}],background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.286f,0.286f,0.286f]}}

# Refresh with live data
function evercraft:craftforever/codex/hub/nodemap/refresh
