# CF Milestones — Open Combat detail page (runs as player)

# Kill CF section content
scoreboard players operation #cf_gui_stamp ec.temp = @s ec.cf_gui_session
execute as @e[type=marker,tag=CF.MenuAnchor,distance=..5] if score @s ec.cf_gui_session = #cf_gui_stamp ec.temp at @s run kill @e[tag=CF.SectionContent,distance=..5]

# Spawn back button
function evercraft:craftforever/codex/hub/spawn_back_button

# Set page (13 = Combat, matching FC codex)
scoreboard players set @s ec.cf_codex_page 13

# Update title
execute as @e[type=marker,tag=CF.MenuAnchor,distance=..5] if score @s ec.cf_gui_session = #cf_gui_stamp ec.temp at @s run data modify entity @e[type=text_display,tag=CF.MenuTitle,distance=..5,limit=1] text set value {"text":"\u2726 Combat \u2726","color":"red","bold":true}

# Spawn FC milestone detail page (creates entities with Adv.* tags)
function evercraft:codex/hub/journal/spawn_ms_combat
# CF layout fix (Joseph 2026-06-06): the FC journal spawn is authored for the taller FC shell
# (content caret-Y ~2.65); the CF shell content area sits ~0.85 lower, so fresh rows overlap the CF
# header. Shift THIS player's just-spawned FC content down before it gets CF-tagged below.
execute as @e[tag=Adv.SectionContent,tag=!CF.SectionContent,distance=..5] at @s run tp @s ~ ~-0.85 ~

# Dual-tag: add CF tags so CF tick can manage these entities
execute as @e[tag=Adv.MenuElement,tag=!CF.MenuElement,distance=..5] run tag @s add CF.MenuElement
execute as @e[tag=Adv.SectionContent,tag=!CF.SectionContent,distance=..5] run tag @s add CF.SectionContent

# Stamp FC entities with player's CF session as adv.gui_session (for claim compat)
execute as @e[tag=Adv.MenuElement,distance=..5] unless score @s adv.gui_session matches 1.. run scoreboard players operation @s adv.gui_session = #cf_gui_stamp ec.temp

scoreboard players set @s ec.cf_codex_cd 3
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.hat master @s ~ ~ ~ 0.5 1.8
