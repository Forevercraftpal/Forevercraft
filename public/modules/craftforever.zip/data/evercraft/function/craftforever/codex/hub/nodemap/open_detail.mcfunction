# Node Map — repaint grid into a dimension-detail page (mirror of materials/open_detail)
# Macro: $(dim) = dimension id 1=Overworld 2=Nether 3=End. Runs as the clicked interaction entity.
data remove entity @s interaction

# Set page-state to this dimension (cf_node_pg: 0=grid, 1=Overworld 2=Nether 3=End)
$scoreboard players set @p[tag=CF.InCodex,distance=..5] ec.cf_node_pg $(dim)

# Kill the grid (and any prior detail) content — session-scoped via CF.SectionContent near player
execute as @p[tag=CF.InCodex,distance=..5] at @s run kill @e[tag=CF.SectionContent,distance=..5]

# Spawn this dimension's detail content (player-run, at player)
$execute as @p[tag=CF.InCodex,distance=..5] at @s run function evercraft:craftforever/codex/hub/nodemap/detail/render$(dim)

# Cooldown so the same click can't re-fire, then click sound (matches open_detail idiom)
execute as @p[tag=CF.InCodex,distance=..5] run scoreboard players set @s ec.cf_codex_cd 3
playsound minecraft:block.note_block.hat master @p[tag=CF.InCodex,distance=..5,scores={ec.fx_snd=1..}] ~ ~ ~ 0.5 1.8
