# Codex first-grant check (Joseph 2026-05-27)
# Grant Craftforever Codex after the player's 5th prospect or forage harvest.
# Called from prospect/complete_mine + forage/complete_gather after ec.cf_nodes_done increment.

# Sentinel: already granted? skip
execute if entity @s[tag=ec.cf_codex_granted] run return 0

# Threshold: under 5 nodes? skip
execute unless score @s ec.cf_nodes_done matches 5.. run return 0

# Grant the codex via the shared idempotent path (also used by the Level-1 unlock).
function evercraft:craftforever/codex/grant_codex
