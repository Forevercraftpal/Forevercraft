# Mastery & Forge Section — Click detection (Wiring Audit #14 W3)
# Run as player, #cf_gui_owner ec.temp = session ID.
# Page 1 (overview): 6 sub-tab buttons dispatch to the new subsystem sections.
# Each calls enter_section (full section swap); the universal back button returns
# to the hub.

execute if score @s ec.cf_codex_page matches 1 as @e[type=interaction,tag=CF.MasteryClick1,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s interaction on target run function evercraft:craftforever/codex/hub/enter_section {section:18}
execute if score @s ec.cf_codex_page matches 1 as @e[type=interaction,tag=CF.MasteryClick1,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction
execute if score @s ec.cf_codex_page matches 1 as @e[type=interaction,tag=CF.MasteryClick2,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s interaction on target run function evercraft:craftforever/codex/hub/enter_section {section:19}
execute if score @s ec.cf_codex_page matches 1 as @e[type=interaction,tag=CF.MasteryClick2,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction
execute if score @s ec.cf_codex_page matches 1 as @e[type=interaction,tag=CF.MasteryClick3,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s interaction on target run function evercraft:craftforever/codex/hub/enter_section {section:15}
execute if score @s ec.cf_codex_page matches 1 as @e[type=interaction,tag=CF.MasteryClick3,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction
execute if score @s ec.cf_codex_page matches 1 as @e[type=interaction,tag=CF.MasteryClick4,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s interaction on target run function evercraft:craftforever/codex/hub/enter_section {section:16}
execute if score @s ec.cf_codex_page matches 1 as @e[type=interaction,tag=CF.MasteryClick4,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction
execute if score @s ec.cf_codex_page matches 1 as @e[type=interaction,tag=CF.MasteryClick5,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s interaction on target run function evercraft:craftforever/codex/hub/enter_section {section:17}
execute if score @s ec.cf_codex_page matches 1 as @e[type=interaction,tag=CF.MasteryClick5,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction
execute if score @s ec.cf_codex_page matches 1 as @e[type=interaction,tag=CF.MasteryClick6,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s interaction on target run function evercraft:craftforever/codex/hub/enter_section {section:20}
execute if score @s ec.cf_codex_page matches 1 as @e[type=interaction,tag=CF.MasteryClick6,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction

# ===== INSPECT (left-click) — gui/inspect pattern 2026-06-11. Cards explain buttons; detail
# rows get attack-PARITY twins (punch opens the same detail a use does — companion doctrine). =====
execute as @e[type=interaction,tag=CF.MasteryClick1,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Artisan Profile",b:"Right-click to open Artisan Profile — your CraftForever artisan ranks across all crafts."}
execute as @e[type=interaction,tag=CF.MasteryClick1,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=CF.MasteryClick2,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Trials",b:"Right-click to open Trials — the CraftForever trial ladder — performance challenges per craft."}
execute as @e[type=interaction,tag=CF.MasteryClick2,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=CF.MasteryClick3,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Alchemy Recipes",b:"Right-click to open Alchemy Recipes — the alchemy recipe almanac."}
execute as @e[type=interaction,tag=CF.MasteryClick3,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=CF.MasteryClick4,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Grand Forge",b:"Right-click to open Grand Forge — the Grand Forge — high-tier smithing recipes and templates."}
execute as @e[type=interaction,tag=CF.MasteryClick4,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=CF.MasteryClick5,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Forge Artifacts",b:"Right-click to open Forge Artifacts — the forge-artifact catalogue — what each forge produces."}
execute as @e[type=interaction,tag=CF.MasteryClick5,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=CF.MasteryClick6,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Spirit Loadout",b:"Right-click to open Spirit Loadout — your spirit loadout — equipped spirits and their effects."}
execute as @e[type=interaction,tag=CF.MasteryClick6,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s attack run data remove entity @s attack
