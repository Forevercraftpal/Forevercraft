# Material Index — Header display with count
# Macro: $(mat_count)

$execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^ ^1.8 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["CF.MenuElement","CF.SectionContent"],billboard:"center",text:[{"text":"$(mat_count)","color":"#8BC34A","bold":true},{"text":"/15 Biome Materials","color":"gray"}],background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.274f,0.274f,0.274f]}}
