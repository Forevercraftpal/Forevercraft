# CF Milestones — Personal page session bridge + refresh (run as the player, at the player).
#
# The CF "Personal Milestones" page borrows the main Eternal Codex personal-claims panel, which
# sets each row's text — and gates its [Claim] clicks — on adv.gui_session. But the CF hub tracks
# ec.cf_gui_session, and the main codex tick never runs for a CF-codex player (no Adv.InMenu tag),
# so the panel's own in-spawn refresh runs before these rows carry a matching session and leaves
# them blank (header + footer only). After every CF-context (re)spawn of this page we therefore:
# dual-tag the rows so CF cleanup can despawn them on section change, mirror the CF session into
# adv.gui_session, stamp the rows to match, then re-run the page-routed refresh so the text
# populates. Shared by open_personal (page 1) and the CF Next/Prev nav in cf_milestones/check_clicks.
execute as @e[tag=Adv.MenuElement,tag=!CF.MenuElement,distance=..5] run tag @s add CF.MenuElement
execute as @e[tag=Adv.SectionContent,tag=!CF.SectionContent,distance=..5] run tag @s add CF.SectionContent
scoreboard players operation @s adv.gui_session = @s ec.cf_gui_session
scoreboard players operation #cf_gui_stamp ec.temp = @s ec.cf_gui_session
execute as @e[tag=Adv.MenuElement,distance=..5] run scoreboard players operation @s adv.gui_session = #cf_gui_stamp ec.temp
function evercraft:ecodex/sections/personal_claims/refresh
