# === CRAFTFOREVER CODEX — LEVEL-1 UNLOCK CHECK (Joseph 2026-05-31) ===
# Run as @s. Called from craft_affinity/internal_grant (gated `unless ec.cf_codex_granted`, so it's
# a no-op for players who already have the codex). update_stage just refreshed ec.caffl_*; if the
# just-progressed class has reached Level 1, grant the codex. This unlocks the codex at Level 1 of
# ANY class — including fishing/Sirencall, which the 5-node prospect/forage path never reached.

scoreboard players set #cf_lvl ec.temp 0
execute if score @s ec.caff_class matches 1 run scoreboard players operation #cf_lvl ec.temp = @s ec.caffl_ss
execute if score @s ec.caff_class matches 2 run scoreboard players operation #cf_lvl ec.temp = @s ec.caffl_lf
execute if score @s ec.caff_class matches 3 run scoreboard players operation #cf_lvl ec.temp = @s ec.caffl_gs
execute if score @s ec.caff_class matches 4 run scoreboard players operation #cf_lvl ec.temp = @s ec.caffl_tw
execute if score @s ec.caff_class matches 5 run scoreboard players operation #cf_lvl ec.temp = @s ec.caffl_sc
execute if score @s ec.caff_class matches 6 run scoreboard players operation #cf_lvl ec.temp = @s ec.caffl_lm
execute if score #cf_lvl ec.temp matches 1.. run function evercraft:craftforever/codex/grant_codex
