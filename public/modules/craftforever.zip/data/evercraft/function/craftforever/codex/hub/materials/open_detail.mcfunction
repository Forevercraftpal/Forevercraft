# Material Index — repaint grid into material-detail page (mirror of recipes/open_detail)
# Macro: $(mat) = material id 1..15. Runs as the clicked interaction entity.
data remove entity @s interaction

# Set page-state to this material (cf_mat_pg: 0=grid, 1..15=material detail)
$scoreboard players set @p[tag=CF.InCodex,distance=..5] ec.cf_mat_pg $(mat)

# Kill the grid (and any prior detail) content — session-scoped via CF.SectionContent near player
execute as @p[tag=CF.InCodex,distance=..5] at @s run kill @e[tag=CF.SectionContent,distance=..5]

# Spawn this material's detail content (player-run, at player)
$execute as @p[tag=CF.InCodex,distance=..5] at @s run function evercraft:craftforever/codex/hub/materials/detail/render$(mat)

# Cooldown so the same click can't re-fire, then click sound (matches open_detail idiom)
execute as @p[tag=CF.InCodex,distance=..5] run scoreboard players set @s ec.cf_codex_cd 3
playsound minecraft:block.note_block.hat master @p[tag=CF.InCodex,distance=..5,scores={ec.fx_snd=1..}] ~ ~ ~ 0.5 1.8
