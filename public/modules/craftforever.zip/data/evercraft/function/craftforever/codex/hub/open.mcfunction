# Craftforever Codex Hub — Open
# Spawns the floating GUI shell + 8 section buttons
# Toggle: if already open, close instead

# Toggle — if already open, close instead
execute if entity @s[tag=CF.InCodex] run return run function evercraft:craftforever/codex/hub/close

# Menu Core: Y-displacement close anchor
# One-menu-at-a-time (2026-06-15): close any other open menu before this one claims
# ec.menu_active. Two overlapping menus share the @s adv.gui_session slot; the newer
# open orphans the older menu's session, so it can never consume its click -> stuck
# interaction NBT -> click-sound spam. force_close is idempotent (no-op when nothing open).
execute if entity @s[tag=ec.menu_active] run function evercraft:menu_core/force_close
tag @s add ec.menu_active
execute store result score @s ec.menu_open_y run data get entity @s Pos[1] 100

# Tag player
tag @s add CF.InCodex
scoreboard players set @s ec.cf_codex_section 0
scoreboard players set @s ec.cf_codex_page 1

# Generate unique session ID for multiplayer isolation
scoreboard players add #cf_gui_session ec.var 1
scoreboard players operation @s ec.cf_gui_session = #cf_gui_session ec.var

# CF.RenderAnchor (line-drift fix, 2026-06-05): a feet-level marker FROZEN at the open position + yaw.
# All re-rendered content anchors to THIS via `at @e[CF.RenderAnchor]` (which sets position+rotation+
# dimension) instead of the player's LIVE look — so the lines stay locked to the window instead of
# tracking your line of sight. Pitch is left at 0 (matches the old `rotated ~ 0`). Summoned at the
# player's feet; only the yaw is copied. Tagged CF.MenuElement so close/cleanup reap it with the rest.
summon marker ~ ~ ~ {Tags:["CF.RenderAnchor","CF.MenuElement"]}
data modify entity @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..2] Rotation[0] set from entity @s Rotation[0]

# Spawn anchor marker (yaw-only, eye level, 1.8 blocks forward)
execute rotated ~ 0 positioned ^ ^1.3 ^1.8 run summon marker ~ ~ ~ {Tags:["CF.MenuAnchor","CF.MenuElement"]}

# Background panel
execute rotated ~ 0 positioned ^ ^1.3 ^1.8 run summon item_display ~ ~ ~ {Tags:["CF.MenuBG","CF.MenuElement"],billboard:"center",item:{id:"black_stained_glass_pane",count:1},item_display:"fixed",transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,-0.02f],scale:[4.0f,2.5f,0.01f]}}

# Title (gold when unclaimed rewards available, green otherwise)
# Ownership-header label (MP-P3.6): foreign viewers see whose menu this is
# 26.1: {selector:} renders blank in text_display — bake @s's name to a $(owner) literal.
function evercraft:util/gui/owner_name
execute rotated ~ 0 positioned ^ ^2.43 ^1.8 run function evercraft:craftforever/codex/hub/open_nm with storage evercraft:scorebake args
execute unless score @s ec.claim_any matches 1.. rotated ~ 0 positioned ^ ^2.25 ^1.8 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["CF.MenuTitle","CF.MenuElement"],billboard:"center",text:{text:"\u2726 The Craftforever Codex \u2726",color:"#8BC34A",bold:true},background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.715f,0.715f,0.715f]}}
execute if score @s ec.claim_any matches 1.. rotated ~ 0 positioned ^ ^2.25 ^1.8 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["CF.MenuTitle","CF.MenuElement"],billboard:"center",text:{text:"\u2726 The Craftforever Codex \u2726",color:"gold",bold:true},background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.715f,0.715f,0.715f]}}

# Spawn hub directory buttons
function evercraft:craftforever/codex/hub/spawn_hub

# Stamp all newly spawned entities with our session ID
scoreboard players operation #cf_gui_stamp ec.temp = @s ec.cf_gui_session
execute as @e[type=marker,tag=CF.MenuAnchor,distance=..5] unless score @s ec.cf_gui_session matches 1.. run scoreboard players operation @s ec.cf_gui_session = #cf_gui_stamp ec.temp
execute as @e[type=marker,tag=CF.MenuAnchor,distance=..5] if score @s ec.cf_gui_session = #cf_gui_stamp ec.temp at @s as @e[tag=CF.MenuElement,distance=..5] unless score @s ec.cf_gui_session matches 1.. run scoreboard players operation @s ec.cf_gui_session = #cf_gui_stamp ec.temp

# Click cooldown + held-click filter (matches FC codex pattern)
scoreboard players set @s ec.cf_codex_cd 10
scoreboard players set @s ec.cf_held 1
# Flush any interaction data set by the opening right-click
execute as @e[type=interaction,tag=CF.MenuElement,distance=..5] if data entity @s interaction run data remove entity @s interaction

# Count unclaimed rewards (for gold header indicators)
function evercraft:claim/check_unclaimed

# Play open sound
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.enchantment_table.use master @s ~ ~ ~ 0.5 1.2

# === INSPECT tip (gui/inspect pattern 2026-06-11) — once ever (shared ec.insp_tip tag w/ main hub) ===
execute unless entity @s[tag=ec.insp_tip] run tellraw @s [{text:"[",color:"dark_gray"},{text:"?",color:"gold"},{text:"] ",color:"dark_gray"},{text:"Tip: ",color:"gold"},{text:"punch any button to learn what it does before pressing it.",color:"gray"}]
execute unless entity @s[tag=ec.insp_tip] run tag @s add ec.insp_tip
