# Node Map — return to the dimension grid from a detail page (mirror materials/back_to_list)
# Runs as the clicked Back interaction entity.
data remove entity @s interaction

# Kill detail content (session-scoped via CF.SectionContent near player)
execute as @p[tag=CF.InCodex,distance=..5] at @s run kill @e[tag=CF.SectionContent,distance=..5]

# Reset page-state to the grid (spawn re-zeroes cf_node_pg as its first line, too)
scoreboard players set @p[tag=CF.InCodex,distance=..5] ec.cf_node_pg 0

# Re-spawn the full node map grid (counter + per-dimension summaries + headers + refresh)
execute as @p[tag=CF.InCodex,distance=..5] at @s run function evercraft:craftforever/codex/hub/nodemap/spawn

# Cooldown + softer back sound (matches back_to_list idiom)
execute as @p[tag=CF.InCodex,distance=..5] run scoreboard players set @s ec.cf_codex_cd 3
playsound minecraft:block.note_block.hat master @p[tag=CF.InCodex,distance=..5,scores={ec.fx_snd=1..}] ~ ~ ~ 0.5 1.4
