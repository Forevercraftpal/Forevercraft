# Craftforever Codex — Alchemy Recipes Section (Wiring Audit #14 C5 + C14)
# Spawn-only. Surfaces the Fusion Funnel recipe-discovery progress
# (ec.cf_alch_recipes_found) + the three reagent families.
# Reached via enter_section {section:15}; closed-state gated by the codex dispatch.

# Count discovered alchemy recipes (Wave J FU 2026-05-31: sum field 1 + field 2).
# Field 1 = std combos × T1-T7 (21 bits); field 2 = aquatic × T1-T6 + spirit T7 (22 bits).
function evercraft:craftforever/codex/hub/popcount {field:"cf_alch_recipes_found"}
scoreboard players operation #cf_alch_total ec.temp = #cf_pc_count ec.temp
function evercraft:craftforever/codex/hub/popcount {field:"cf_alch_aq_recipes_found"}
scoreboard players operation #cf_alch_total ec.temp += #cf_pc_count ec.temp
scoreboard players operation #cf_pc_count ec.temp = #cf_alch_total ec.temp

# Subtitle
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^ ^1.97 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["CF.MenuElement","CF.SectionContent"],billboard:"center",text:{text:"Recipes brewed at the Fusion Funnel",color:"gray",italic:true},background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.215f,0.215f,0.215f]}}

# Discovered count
# === 26.1 fix: {score} blank in text_display -> bake via storage macro ===
scoreboard players add #cf_pc_count ec.temp 0
execute store result storage evercraft:scorebake args.v1 int 1 run scoreboard players get #cf_pc_count ec.temp
function evercraft:craftforever/codex/hub/alchemy_recipes/spawn_dyn with storage evercraft:scorebake args

# Reagent families
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^ ^1.65 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["CF.MenuElement","CF.SectionContent"],billboard:"center",text:[{text:"◆ Botanical ",color:"#86EFAC"},{text:"— T1-T7, foraged & grown",color:"gray"}],background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.215f,0.215f,0.215f]}}
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^ ^1.53 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["CF.MenuElement","CF.SectionContent"],billboard:"center",text:[{text:"◆ Visceral ",color:"#F87171"},{text:"— T1-T7, mob drops",color:"gray"}],background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.215f,0.215f,0.215f]}}
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^ ^1.41 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["CF.MenuElement","CF.SectionContent"],billboard:"center",text:[{text:"◆ Mineral ",color:"#9CA3AF"},{text:"— T1-T7, mined & prospected",color:"gray"}],background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.215f,0.215f,0.215f]}}

# Tier-unlock ladder (AU14-P5 codex polish) — the Artisan Rank each fusion tier needs,
# matching the match_recipe gate thresholds 1:1 (so the locked-craft rejection is discoverable).
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^ ^1.29 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["CF.MenuElement","CF.SectionContent"],billboard:"center",text:[{text:"Unlocks: ",color:"#22D3EE"},{text:"T2@5 · T3@10 · T4@20 · T5@40 · T6@50 · T7@60 ",color:"gray"},{text:"(Artisan Rank)",color:"dark_gray"}],background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.191f,0.191f,0.191f]}}

# Footer hint
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^ ^1.21 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["CF.MenuElement","CF.SectionContent"],billboard:"center",text:{text:"Combine reagents at the Fusion Funnel to discover recipes.",color:"dark_gray",italic:true},background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.191f,0.191f,0.191f]}}
