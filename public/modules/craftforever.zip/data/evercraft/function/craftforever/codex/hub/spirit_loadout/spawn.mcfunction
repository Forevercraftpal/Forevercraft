# Craftforever Codex — Spirit Tools Loadout Section (Wiring Audit #14 C11)
# Spawn-only. Surfaces the player's active spirit-tool ownership/tier/cooldown
# state (ec.st_held / ec.st_tier / ec.st_cd / ec.st_eff). The Crafting Classes
# section shows only static info; this is the live loadout view.
# Reached via enter_section {section:20}; closed-state gated by the codex dispatch.

# Subtitle
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^ ^1.97 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["CF.MenuElement","CF.SectionContent"],billboard:"center",text:{text:"Your equipped spirit tool",color:"gray",italic:true},background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.215f,0.215f,0.215f]}}

# Ownership state
execute if score @s ec.st_held matches 1.. at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^ ^1.79 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["CF.MenuElement","CF.SectionContent"],billboard:"center",text:{text:"⚒ Spirit Tool Equipped",color:"#8BC34A",bold:true},background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.262f,0.262f,0.262f]}}
execute unless score @s ec.st_held matches 1.. at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^ ^1.79 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["CF.MenuElement","CF.SectionContent"],billboard:"center",text:{text:"☗ No spirit tool held",color:"dark_gray",bold:true},background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.262f,0.262f,0.262f]}}

# Tier

# Tier progress (objectives done toward next tier)

# Cooldown
# === 26.1 fix: {score} blank in text_display -> bake via storage macro ===
scoreboard players add @s ec.st_tier 0
execute store result storage evercraft:scorebake args.v1 int 1 run scoreboard players get @s ec.st_tier
scoreboard players add @s ec.st_obj_done 0
execute store result storage evercraft:scorebake args.v2 int 1 run scoreboard players get @s ec.st_obj_done
scoreboard players add @s ec.st_cd 0
execute store result storage evercraft:scorebake args.v3 int 1 run scoreboard players get @s ec.st_cd
function evercraft:craftforever/codex/hub/spirit_loadout/spawn_dyn with storage evercraft:scorebake args

# Footer hint
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^ ^1.21 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["CF.MenuElement","CF.SectionContent"],billboard:"center",text:{text:"See Crafting Classes for each tool's specialization.",color:"dark_gray",italic:true},background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.191f,0.191f,0.191f]}}
