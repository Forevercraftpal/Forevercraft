# CF Milestones — Spawn Overview (matches FC milestones scheme)
# 8 milestone categories in 2x4 grid with clickable interaction entities
# Run as player, at player

# Subtitle
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^ ^1.97 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["CF.MenuElement","CF.SectionContent"],billboard:"center",text:{text:"Track progress & claim rewards",color:"gray",italic:true},background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.215f,0.215f,0.215f]}}

# ===== ROW 1 =====

# === Origins (left) ===
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^0.55 ^1.75 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["CF.MenuElement","CF.SectionContent","CF.MsLbl0"],billboard:"center",text:{text:"Origins",color:"yellow",bold:true},background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.382f,0.382f,0.382f]}}
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^0.55 ^1.63 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["CF.MenuElement","CF.SectionContent","CF.MsOvDesc0","Adv.MsOvDesc0"],billboard:"center",text:{text:"- / 10",color:"gray",italic:true},background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.215f,0.215f,0.215f]}}
# [strip] CF.MenuElement: 0.55w split into 5 x 0.12 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^0.335 ^1.69 ^1.8 run summon interaction ~ ~ ~ {Tags:["CF.MenuElement","CF.SectionContent","CF.MsOvClick0"],width:0.12f,height:0.12f,response:1b}
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^0.4425 ^1.69 ^1.8 run summon interaction ~ ~ ~ {Tags:["CF.MenuElement","CF.SectionContent","CF.MsOvClick0"],width:0.12f,height:0.12f,response:1b}
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^0.55 ^1.69 ^1.8 run summon interaction ~ ~ ~ {Tags:["CF.MenuElement","CF.SectionContent","CF.MsOvClick0"],width:0.12f,height:0.12f,response:1b}
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^0.6575 ^1.69 ^1.8 run summon interaction ~ ~ ~ {Tags:["CF.MenuElement","CF.SectionContent","CF.MsOvClick0"],width:0.12f,height:0.12f,response:1b}
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^0.765 ^1.69 ^1.8 run summon interaction ~ ~ ~ {Tags:["CF.MenuElement","CF.SectionContent","CF.MsOvClick0"],width:0.12f,height:0.12f,response:1b}

# === Social (right) ===
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^-0.55 ^1.75 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["CF.MenuElement","CF.SectionContent","CF.MsLbl1"],billboard:"center",text:{text:"Social",color:"#FF69B4",bold:true},background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.382f,0.382f,0.382f]}}
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^-0.55 ^1.63 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["CF.MenuElement","CF.SectionContent","CF.MsOvDesc1","Adv.MsOvDesc1"],billboard:"center",text:{text:"- / 5",color:"gray",italic:true},background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.215f,0.215f,0.215f]}}
# [strip] CF.MenuElement: 0.55w split into 5 x 0.12 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^-0.765 ^1.69 ^1.8 run summon interaction ~ ~ ~ {Tags:["CF.MenuElement","CF.SectionContent","CF.MsOvClick1"],width:0.12f,height:0.12f,response:1b}
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^-0.6575 ^1.69 ^1.8 run summon interaction ~ ~ ~ {Tags:["CF.MenuElement","CF.SectionContent","CF.MsOvClick1"],width:0.12f,height:0.12f,response:1b}
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^-0.55 ^1.69 ^1.8 run summon interaction ~ ~ ~ {Tags:["CF.MenuElement","CF.SectionContent","CF.MsOvClick1"],width:0.12f,height:0.12f,response:1b}
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^-0.4425 ^1.69 ^1.8 run summon interaction ~ ~ ~ {Tags:["CF.MenuElement","CF.SectionContent","CF.MsOvClick1"],width:0.12f,height:0.12f,response:1b}
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^-0.335 ^1.69 ^1.8 run summon interaction ~ ~ ~ {Tags:["CF.MenuElement","CF.SectionContent","CF.MsOvClick1"],width:0.12f,height:0.12f,response:1b}

# ===== ROW 2 =====

# === Guild (left) ===
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^0.55 ^1.4 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["CF.MenuElement","CF.SectionContent","CF.MsLbl2"],billboard:"center",text:{text:"Guild",color:"dark_red",bold:true},background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.382f,0.382f,0.382f]}}
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^0.55 ^1.28 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["CF.MenuElement","CF.SectionContent","CF.MsOvDesc2","Adv.MsOvDesc2"],billboard:"center",text:{text:"- / 5",color:"gray",italic:true},background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.215f,0.215f,0.215f]}}
# [strip] CF.MenuElement: 0.55w split into 5 x 0.12 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^0.335 ^1.34 ^1.8 run summon interaction ~ ~ ~ {Tags:["CF.MenuElement","CF.SectionContent","CF.MsOvClick2"],width:0.12f,height:0.12f,response:1b}
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^0.4425 ^1.34 ^1.8 run summon interaction ~ ~ ~ {Tags:["CF.MenuElement","CF.SectionContent","CF.MsOvClick2"],width:0.12f,height:0.12f,response:1b}
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^0.55 ^1.34 ^1.8 run summon interaction ~ ~ ~ {Tags:["CF.MenuElement","CF.SectionContent","CF.MsOvClick2"],width:0.12f,height:0.12f,response:1b}
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^0.6575 ^1.34 ^1.8 run summon interaction ~ ~ ~ {Tags:["CF.MenuElement","CF.SectionContent","CF.MsOvClick2"],width:0.12f,height:0.12f,response:1b}
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^0.765 ^1.34 ^1.8 run summon interaction ~ ~ ~ {Tags:["CF.MenuElement","CF.SectionContent","CF.MsOvClick2"],width:0.12f,height:0.12f,response:1b}

# === Adventure (right) ===
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^-0.55 ^1.4 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["CF.MenuElement","CF.SectionContent","CF.MsLbl3"],billboard:"center",text:{text:"Adventure",color:"dark_aqua",bold:true},background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.382f,0.382f,0.382f]}}
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^-0.55 ^1.28 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["CF.MenuElement","CF.SectionContent","CF.MsOvDesc3","Adv.MsOvDesc3"],billboard:"center",text:{text:"- / 4",color:"gray",italic:true},background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.215f,0.215f,0.215f]}}
# [strip] CF.MenuElement: 0.55w split into 5 x 0.12 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^-0.765 ^1.34 ^1.8 run summon interaction ~ ~ ~ {Tags:["CF.MenuElement","CF.SectionContent","CF.MsOvClick3"],width:0.12f,height:0.12f,response:1b}
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^-0.6575 ^1.34 ^1.8 run summon interaction ~ ~ ~ {Tags:["CF.MenuElement","CF.SectionContent","CF.MsOvClick3"],width:0.12f,height:0.12f,response:1b}
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^-0.55 ^1.34 ^1.8 run summon interaction ~ ~ ~ {Tags:["CF.MenuElement","CF.SectionContent","CF.MsOvClick3"],width:0.12f,height:0.12f,response:1b}
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^-0.4425 ^1.34 ^1.8 run summon interaction ~ ~ ~ {Tags:["CF.MenuElement","CF.SectionContent","CF.MsOvClick3"],width:0.12f,height:0.12f,response:1b}
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^-0.335 ^1.34 ^1.8 run summon interaction ~ ~ ~ {Tags:["CF.MenuElement","CF.SectionContent","CF.MsOvClick3"],width:0.12f,height:0.12f,response:1b}

# ===== ROW 3 =====

# === Combat (left) ===
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^0.55 ^1.05 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["CF.MenuElement","CF.SectionContent","CF.MsLbl4"],billboard:"center",text:{text:"Combat",color:"red",bold:true},background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.382f,0.382f,0.382f]}}
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^0.55 ^0.93 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["CF.MenuElement","CF.SectionContent","CF.MsOvDesc4","Adv.MsOvDesc4"],billboard:"center",text:{text:"- / 4",color:"gray",italic:true},background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.215f,0.215f,0.215f]}}
# [strip] CF.MenuElement: 0.55w split into 5 x 0.12 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^0.335 ^0.99 ^1.8 run summon interaction ~ ~ ~ {Tags:["CF.MenuElement","CF.SectionContent","CF.MsOvClick4"],width:0.12f,height:0.12f,response:1b}
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^0.4425 ^0.99 ^1.8 run summon interaction ~ ~ ~ {Tags:["CF.MenuElement","CF.SectionContent","CF.MsOvClick4"],width:0.12f,height:0.12f,response:1b}
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^0.55 ^0.99 ^1.8 run summon interaction ~ ~ ~ {Tags:["CF.MenuElement","CF.SectionContent","CF.MsOvClick4"],width:0.12f,height:0.12f,response:1b}
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^0.6575 ^0.99 ^1.8 run summon interaction ~ ~ ~ {Tags:["CF.MenuElement","CF.SectionContent","CF.MsOvClick4"],width:0.12f,height:0.12f,response:1b}
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^0.765 ^0.99 ^1.8 run summon interaction ~ ~ ~ {Tags:["CF.MenuElement","CF.SectionContent","CF.MsOvClick4"],width:0.12f,height:0.12f,response:1b}

# === Mastery (right) ===
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^-0.55 ^1.05 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["CF.MenuElement","CF.SectionContent","CF.MsLbl5"],billboard:"center",text:{text:"Mastery",color:"light_purple",bold:true},background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.382f,0.382f,0.382f]}}
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^-0.55 ^0.93 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["CF.MenuElement","CF.SectionContent","CF.MsOvDesc5","Adv.MsOvDesc5"],billboard:"center",text:{text:"- / 4",color:"gray",italic:true},background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.215f,0.215f,0.215f]}}
# [strip] CF.MenuElement: 0.55w split into 5 x 0.12 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^-0.765 ^0.99 ^1.8 run summon interaction ~ ~ ~ {Tags:["CF.MenuElement","CF.SectionContent","CF.MsOvClick5"],width:0.12f,height:0.12f,response:1b}
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^-0.6575 ^0.99 ^1.8 run summon interaction ~ ~ ~ {Tags:["CF.MenuElement","CF.SectionContent","CF.MsOvClick5"],width:0.12f,height:0.12f,response:1b}
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^-0.55 ^0.99 ^1.8 run summon interaction ~ ~ ~ {Tags:["CF.MenuElement","CF.SectionContent","CF.MsOvClick5"],width:0.12f,height:0.12f,response:1b}
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^-0.4425 ^0.99 ^1.8 run summon interaction ~ ~ ~ {Tags:["CF.MenuElement","CF.SectionContent","CF.MsOvClick5"],width:0.12f,height:0.12f,response:1b}
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^-0.335 ^0.99 ^1.8 run summon interaction ~ ~ ~ {Tags:["CF.MenuElement","CF.SectionContent","CF.MsOvClick5"],width:0.12f,height:0.12f,response:1b}

# ===== ROW 4 =====

# === Personal (left) ===
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^0.55 ^0.7 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["CF.MenuElement","CF.SectionContent"],billboard:"center",text:{text:"Personal",color:"green",bold:true},background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.382f,0.382f,0.382f]}}
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^0.55 ^0.58 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["CF.MenuElement","CF.SectionContent","CF.MsOvDesc6","Adv.MsOvDesc6"],billboard:"center",text:{text:"100 personal goals",color:"gray",italic:true},background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.215f,0.215f,0.215f]}}
# [strip] CF.MenuElement: 0.55w split into 5 x 0.12 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^0.335 ^0.64 ^1.8 run summon interaction ~ ~ ~ {Tags:["CF.MenuElement","CF.SectionContent","CF.MsOvClick6"],width:0.12f,height:0.12f,response:1b}
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^0.4425 ^0.64 ^1.8 run summon interaction ~ ~ ~ {Tags:["CF.MenuElement","CF.SectionContent","CF.MsOvClick6"],width:0.12f,height:0.12f,response:1b}
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^0.55 ^0.64 ^1.8 run summon interaction ~ ~ ~ {Tags:["CF.MenuElement","CF.SectionContent","CF.MsOvClick6"],width:0.12f,height:0.12f,response:1b}
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^0.6575 ^0.64 ^1.8 run summon interaction ~ ~ ~ {Tags:["CF.MenuElement","CF.SectionContent","CF.MsOvClick6"],width:0.12f,height:0.12f,response:1b}
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^0.765 ^0.64 ^1.8 run summon interaction ~ ~ ~ {Tags:["CF.MenuElement","CF.SectionContent","CF.MsOvClick6"],width:0.12f,height:0.12f,response:1b}

# === Memories (right) ===
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^-0.55 ^0.7 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["CF.MenuElement","CF.SectionContent"],billboard:"center",text:{text:"Memories",color:"#FF8C00",bold:true},background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.382f,0.382f,0.382f]}}
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^-0.55 ^0.58 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["CF.MenuElement","CF.SectionContent","CF.MsOvDesc7","Adv.MsOvDesc7"],billboard:"center",text:{text:"Companion memories",color:"gray",italic:true},background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.215f,0.215f,0.215f]}}
# [strip] CF.MenuElement: 0.55w split into 5 x 0.12 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^-0.765 ^0.64 ^1.8 run summon interaction ~ ~ ~ {Tags:["CF.MenuElement","CF.SectionContent","CF.MsOvClick7"],width:0.12f,height:0.12f,response:1b}
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^-0.6575 ^0.64 ^1.8 run summon interaction ~ ~ ~ {Tags:["CF.MenuElement","CF.SectionContent","CF.MsOvClick7"],width:0.12f,height:0.12f,response:1b}
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^-0.55 ^0.64 ^1.8 run summon interaction ~ ~ ~ {Tags:["CF.MenuElement","CF.SectionContent","CF.MsOvClick7"],width:0.12f,height:0.12f,response:1b}
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^-0.4425 ^0.64 ^1.8 run summon interaction ~ ~ ~ {Tags:["CF.MenuElement","CF.SectionContent","CF.MsOvClick7"],width:0.12f,height:0.12f,response:1b}
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^-0.335 ^0.64 ^1.8 run summon interaction ~ ~ ~ {Tags:["CF.MenuElement","CF.SectionContent","CF.MsOvClick7"],width:0.12f,height:0.12f,response:1b}

# Info hint
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^ ^0.35 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["CF.MenuElement","CF.SectionContent"],billboard:"center",text:{text:"Click a category to view details",color:"dark_gray",italic:true},background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.191f,0.191f,0.191f]}}

# Refresh overview counts
function evercraft:codex/hub/milestones/refresh_overview

# Gold category labels when unclaimed rewards exist (per-category, mirrors FC journal pattern)
# Origins (ms 1,3,5-12)
scoreboard players set #ms_uncl ec.temp 0
execute if score #rm_done_1 ec.var matches 1 unless entity @s[advancements={evercraft:milestones/claimed/ms_1=true}] run scoreboard players set #ms_uncl ec.temp 1
execute if score #rm_done_3 ec.var matches 1 unless entity @s[advancements={evercraft:milestones/claimed/ms_3=true}] run scoreboard players set #ms_uncl ec.temp 1
execute if score #rm_done_5 ec.var matches 1 unless entity @s[advancements={evercraft:milestones/claimed/ms_5=true}] run scoreboard players set #ms_uncl ec.temp 1
execute if score #rm_done_6 ec.var matches 1 unless entity @s[advancements={evercraft:milestones/claimed/ms_6=true}] run scoreboard players set #ms_uncl ec.temp 1
execute if score #rm_done_7 ec.var matches 1 unless entity @s[advancements={evercraft:milestones/claimed/ms_7=true}] run scoreboard players set #ms_uncl ec.temp 1
execute if score #rm_done_8 ec.var matches 1 unless entity @s[advancements={evercraft:milestones/claimed/ms_8=true}] run scoreboard players set #ms_uncl ec.temp 1
execute if score #rm_done_9 ec.var matches 1 unless entity @s[advancements={evercraft:milestones/claimed/ms_9=true}] run scoreboard players set #ms_uncl ec.temp 1
execute if score #rm_done_10 ec.var matches 1 unless entity @s[advancements={evercraft:milestones/claimed/ms_10=true}] run scoreboard players set #ms_uncl ec.temp 1
execute if score #rm_done_11 ec.var matches 1 unless entity @s[advancements={evercraft:milestones/claimed/ms_11=true}] run scoreboard players set #ms_uncl ec.temp 1
execute if score #rm_done_12 ec.var matches 1 unless entity @s[advancements={evercraft:milestones/claimed/ms_12=true}] run scoreboard players set #ms_uncl ec.temp 1
execute if score #ms_uncl ec.temp matches 1.. run data modify entity @e[type=text_display,tag=CF.MsLbl0,distance=..5,limit=1,sort=nearest] text set value {text:"Origins",color:"gold",bold:true}
# Social (ms 13-17)
scoreboard players set #ms_uncl ec.temp 0
execute if score #rm_done_13 ec.var matches 1 unless entity @s[advancements={evercraft:milestones/claimed/ms_13=true}] run scoreboard players set #ms_uncl ec.temp 1
execute if score #rm_done_14 ec.var matches 1 unless entity @s[advancements={evercraft:milestones/claimed/ms_14=true}] run scoreboard players set #ms_uncl ec.temp 1
execute if score #rm_done_15 ec.var matches 1 unless entity @s[advancements={evercraft:milestones/claimed/ms_15=true}] run scoreboard players set #ms_uncl ec.temp 1
execute if score #rm_done_16 ec.var matches 1 unless entity @s[advancements={evercraft:milestones/claimed/ms_16=true}] run scoreboard players set #ms_uncl ec.temp 1
execute if score #rm_done_17 ec.var matches 1 unless entity @s[advancements={evercraft:milestones/claimed/ms_17=true}] run scoreboard players set #ms_uncl ec.temp 1
execute if score #ms_uncl ec.temp matches 1.. run data modify entity @e[type=text_display,tag=CF.MsLbl1,distance=..5,limit=1,sort=nearest] text set value {text:"Social",color:"gold",bold:true}
# Guild (ms 18-22)
scoreboard players set #ms_uncl ec.temp 0
execute if score #rm_done_18 ec.var matches 1 unless entity @s[advancements={evercraft:milestones/claimed/ms_18=true}] run scoreboard players set #ms_uncl ec.temp 1
execute if score #rm_done_19 ec.var matches 1 unless entity @s[advancements={evercraft:milestones/claimed/ms_19=true}] run scoreboard players set #ms_uncl ec.temp 1
execute if score #rm_done_20 ec.var matches 1 unless entity @s[advancements={evercraft:milestones/claimed/ms_20=true}] run scoreboard players set #ms_uncl ec.temp 1
execute if score #rm_done_21 ec.var matches 1 unless entity @s[advancements={evercraft:milestones/claimed/ms_21=true}] run scoreboard players set #ms_uncl ec.temp 1
execute if score #rm_done_22 ec.var matches 1 unless entity @s[advancements={evercraft:milestones/claimed/ms_22=true}] run scoreboard players set #ms_uncl ec.temp 1
execute if score #ms_uncl ec.temp matches 1.. run data modify entity @e[type=text_display,tag=CF.MsLbl2,distance=..5,limit=1,sort=nearest] text set value {text:"Guild",color:"gold",bold:true}
# Adventure (ms 23-26)
scoreboard players set #ms_uncl ec.temp 0
execute if score #rm_done_23 ec.var matches 1 unless entity @s[advancements={evercraft:milestones/claimed/ms_23=true}] run scoreboard players set #ms_uncl ec.temp 1
execute if score #rm_done_24 ec.var matches 1 unless entity @s[advancements={evercraft:milestones/claimed/ms_24=true}] run scoreboard players set #ms_uncl ec.temp 1
execute if score #rm_done_25 ec.var matches 1 unless entity @s[advancements={evercraft:milestones/claimed/ms_25=true}] run scoreboard players set #ms_uncl ec.temp 1
execute if score #rm_done_26 ec.var matches 1 unless entity @s[advancements={evercraft:milestones/claimed/ms_26=true}] run scoreboard players set #ms_uncl ec.temp 1
execute if score #ms_uncl ec.temp matches 1.. run data modify entity @e[type=text_display,tag=CF.MsLbl3,distance=..5,limit=1,sort=nearest] text set value {text:"Adventure",color:"gold",bold:true}
# Combat (ms 27-30)
scoreboard players set #ms_uncl ec.temp 0
execute if score #rm_done_27 ec.var matches 1 unless entity @s[advancements={evercraft:milestones/claimed/ms_27=true}] run scoreboard players set #ms_uncl ec.temp 1
execute if score #rm_done_28 ec.var matches 1 unless entity @s[advancements={evercraft:milestones/claimed/ms_28=true}] run scoreboard players set #ms_uncl ec.temp 1
execute if score #rm_done_29 ec.var matches 1 unless entity @s[advancements={evercraft:milestones/claimed/ms_29=true}] run scoreboard players set #ms_uncl ec.temp 1
execute if score #rm_done_30 ec.var matches 1 unless entity @s[advancements={evercraft:milestones/claimed/ms_30=true}] run scoreboard players set #ms_uncl ec.temp 1
execute if score #ms_uncl ec.temp matches 1.. run data modify entity @e[type=text_display,tag=CF.MsLbl4,distance=..5,limit=1,sort=nearest] text set value {text:"Combat",color:"gold",bold:true}
# Mastery (ms 31-34)
scoreboard players set #ms_uncl ec.temp 0
execute if score #rm_done_31 ec.var matches 1 unless entity @s[advancements={evercraft:milestones/claimed/ms_31=true}] run scoreboard players set #ms_uncl ec.temp 1
execute if score #rm_done_32 ec.var matches 1 unless entity @s[advancements={evercraft:milestones/claimed/ms_32=true}] run scoreboard players set #ms_uncl ec.temp 1
execute if score #rm_done_33 ec.var matches 1 unless entity @s[advancements={evercraft:milestones/claimed/ms_33=true}] run scoreboard players set #ms_uncl ec.temp 1
execute if score #rm_done_34 ec.var matches 1 unless entity @s[advancements={evercraft:milestones/claimed/ms_34=true}] run scoreboard players set #ms_uncl ec.temp 1
execute if score #ms_uncl ec.temp matches 1.. run data modify entity @e[type=text_display,tag=CF.MsLbl5,distance=..5,limit=1,sort=nearest] text set value {text:"Mastery",color:"gold",bold:true}
