# Trophy Gallery — repaint grid into trophy-detail page (mirror of materials/open_detail,
# adapted for the ATTACK trigger + interaction->player bridge that show_trophy_info performs).
# Macro: $(pg) = trophy id + 1 (1..15). Runs as the clicked CF.TrophyCl{N} interaction entity.
# Trophy left-click stores BOTH attack + interaction data on response:1b hitboxes — flush both.
data remove entity @s attack
data remove entity @s interaction

# Set page-state to this trophy (cf_troph_pg: 0=grid, 1..15 = trophy id+1)
$scoreboard players set @p[tag=CF.InCodex,distance=..5] ec.cf_troph_pg $(pg)

# Kill the grid (and any prior detail) content — session-scoped via CF.SectionContent near player
execute as @p[tag=CF.InCodex,distance=..5] at @s run kill @e[tag=CF.SectionContent,distance=..5]

# Spawn this trophy's detail content (player-run, at player — preserves the interaction->player bridge)
$execute as @p[tag=CF.InCodex,distance=..5] at @s run function evercraft:craftforever/codex/hub/trophies/detail/render$(pg)

# Cooldown so the same click can't re-fire, then click sound (matches open_detail idiom)
execute as @p[tag=CF.InCodex,distance=..5] run scoreboard players set @s ec.cf_codex_cd 3
playsound minecraft:block.note_block.hat master @p[tag=CF.InCodex,distance=..5,scores={ec.fx_snd=1..}] ~ ~ ~ 0.5 1.8
