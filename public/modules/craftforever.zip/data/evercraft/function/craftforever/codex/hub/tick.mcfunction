# Craftforever Codex — Per-tick GUI logic
# Run as player with CF.InCodex tag, at player position

# Close if player drops/loses codex item (also accept eternal/phoenix codex — opens CF hub via selector)
execute unless items entity @s weapon.mainhand *[custom_data~{craftforever_codex:true}] unless items entity @s weapon.offhand *[custom_data~{craftforever_codex:true}] unless items entity @s weapon.mainhand book[custom_data~{eternal_codex:true}] unless items entity @s weapon.offhand book[custom_data~{eternal_codex:true}] unless items entity @s weapon.mainhand book[custom_data~{phoenix_codex:true}] unless items entity @s weapon.offhand book[custom_data~{phoenix_codex:true}] run return run function evercraft:craftforever/codex/hub/close

# Store session for entity filtering (before cooldown gate so flush can session-filter)
scoreboard players operation #cf_gui_owner ec.temp = @s ec.cf_gui_session

# Unified UI-click FX (Joseph 2026-06-05): mirrors the FC codex hub hook — if ANY CF codex menu element
# registered a click this tick, play the gated cue ONCE before the per-section dispatchers consume it.
# The cf_codex_cd gate (checked just below) plus one-tick interaction-data lifetime prevent re-fire.
execute unless score @s ec.cf_codex_cd matches 1.. if entity @e[type=interaction,tag=CF.MenuElement,distance=..6,nbt={interaction:{}},limit=1] run function evercraft:fx/ui/click

# Cooldown gate — flush stale interaction data during cooldown
# Right-click re-consume while in menu stores click data on interaction entities — clear it
# Session-filtered: only flush THIS player's entities, not a nearby player's legitimate clicks
execute if score @s ec.cf_codex_cd matches 1.. as @e[type=interaction,tag=CF.MenuElement,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction
execute if score @s ec.cf_codex_cd matches 1.. run return run scoreboard players remove @s ec.cf_codex_cd 1

# === HELD-RIGHT-CLICK FILTER (matches FC codex pattern) ===
# Detect if ANY interaction entity currently has click data this tick
scoreboard players set #cf_has_click ec.temp 0
execute as @e[type=interaction,tag=CF.MenuElement,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s interaction run scoreboard players set #cf_has_click ec.temp 1
# Track consecutive ticks with click data present
# cf_held is primed to 1 by open/back_to_hub/enter, so first data tick after cooldown hits 2+ → blocked
# When player RELEASES right-click, cf_held resets to 0. A NEW click then passes (0+1=1).
scoreboard players add @s ec.cf_held 0
execute if score #cf_has_click ec.temp matches 1 run scoreboard players add @s ec.cf_held 1
execute unless score #cf_has_click ec.temp matches 1 run scoreboard players set @s ec.cf_held 0
# If held for 2+ consecutive ticks: flush all data and skip click processing
execute if score @s ec.cf_held matches 2.. as @e[type=interaction,tag=CF.MenuElement,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction
execute if score @s ec.cf_held matches 2.. run return 0

# Stamp new entities with session ID (entities spawned by section transitions)
scoreboard players operation #cf_gui_stamp ec.temp = @s ec.cf_gui_session
execute as @e[type=marker,tag=CF.MenuAnchor,distance=..5] if score @s ec.cf_gui_session = #cf_gui_stamp ec.temp at @s as @e[tag=CF.MenuElement,distance=..5] unless score @s ec.cf_gui_session matches 1.. run scoreboard players operation @s ec.cf_gui_session = #cf_gui_stamp ec.temp
# Fallback stamp from player position (covers entities spawned after player moved from anchor)
execute as @e[tag=CF.MenuElement,distance=..5] unless score @s ec.cf_gui_session matches 1.. run scoreboard players operation @s ec.cf_gui_session = #cf_gui_stamp ec.temp

# Sub-tab sections: back from sub-page returns to overview (intercept before generic back).
# Perf P1-4: collapsed the 5 per-section sub-page back checks into ONE umbrella scan.
# Gate on page 2+ first, then a single CF.BackBtnClick scan dispatches to the correct
# per-section back_to_overview by ec.cf_codex_section inside the helper. (Sections that
# have a sub-page back: 3 cookbook, 4 housing, 9 recipes, 10 discovery, 14 milestones.)
# Stamp the player's section into a temp so the dispatch (which runs as the
# interaction entity) can route correctly.
execute if score @s ec.cf_codex_page matches 2.. run scoreboard players operation #cf_back_section ec.temp = @s ec.cf_codex_section
execute if score @s ec.cf_codex_page matches 2.. as @e[type=interaction,tag=CF.BackBtnClick,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s interaction on target run function evercraft:craftforever/codex/hub/back_to_overview_dispatch
execute if score @s ec.cf_codex_page matches 2.. as @e[type=interaction,tag=CF.BackBtnClick,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction

# Check back button first (universal across all sections)
execute if score @s ec.cf_codex_section matches 1.. as @e[type=interaction,tag=CF.BackBtnClick,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s interaction on target run function evercraft:craftforever/codex/hub/back_to_hub
execute if score @s ec.cf_codex_section matches 1.. as @e[type=interaction,tag=CF.BackBtnClick,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction

# Second cooldown gate — catches same-tick back_to_hub which sets cooldown after the first check
execute if score @s ec.cf_codex_cd matches 1.. as @e[type=interaction,tag=CF.MenuElement,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction
execute if score @s ec.cf_codex_cd matches 1.. run return run scoreboard players remove @s ec.cf_codex_cd 1

# Route to appropriate click handler based on current section
execute if score @s ec.cf_codex_section matches 0 run function evercraft:craftforever/codex/hub/check_clicks_hub
execute if score @s ec.cf_codex_section matches 1 run function evercraft:craftforever/codex/hub/almanac/check_clicks
# Section 22 (Tinkering) reuses the almanac click router — its routes are all gated on
# ec.cf_alm_pg values, which spawn_families/fam pages set (8 / 81..91).
execute if score @s ec.cf_codex_section matches 22 run function evercraft:craftforever/codex/hub/almanac/check_clicks
execute if score @s ec.cf_codex_section matches 3 run function evercraft:craftforever/codex/hub/cookbook/check_clicks
execute if score @s ec.cf_codex_section matches 4 run function evercraft:craftforever/codex/hub/housing/check_clicks
execute if score @s ec.cf_codex_section matches 9 run function evercraft:craftforever/codex/hub/recipes/check_clicks
execute if score @s ec.cf_codex_section matches 10 run function evercraft:craftforever/codex/hub/discovery/check_clicks
# (Almanac internal nav handled inside discovery/check_clicks)

# New sections: Journal, Cosmetics, Crafting Classes, Milestones
execute if score @s ec.cf_codex_section matches 11 run function evercraft:craftforever/codex/hub/travel_journal/check_clicks
execute if score @s ec.cf_codex_section matches 12 run function evercraft:craftforever/codex/hub/cf_cosmetics/check_clicks
execute if score @s ec.cf_codex_section matches 13 run function evercraft:craftforever/codex/hub/crafting_classes/check_clicks
execute if score @s ec.cf_codex_section matches 14 run function evercraft:craftforever/codex/hub/cf_milestones/check_clicks
# Wiring Audit #14 W3: Mastery & Forge overview sub-tab clicks (section 21).
# Sections 15-17,19,20 are single-page panels reached via enter_section — no per-section handler.
# Section 18 (Artisan Profile) gained a handler with #10: the [Craft-Rate Ladder] tab repaint.
execute if score @s ec.cf_codex_section matches 18 run function evercraft:craftforever/codex/hub/artisan_profile/check_clicks
execute if score @s ec.cf_codex_section matches 21 run function evercraft:craftforever/codex/hub/mastery/check_clicks
