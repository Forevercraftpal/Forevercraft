# === CRAFTFOREVER CODEX — GRANT (idempotent, shared) ===
# Run as @s = player. Grants the Codex of Craftforever exactly once (sentinel ec.cf_codex_granted,
# survives reload; reset by admin/strip_player_zero). Two triggers share this:
#   - check_first_grant: 5th prospect/forage harvest (the original path)
#   - check_level1_unlock: reaching Level 1 of ANY Crafting Class (Joseph 2026-05-31)

# Already granted? bail.
execute if entity @s[tag=ec.cf_codex_granted] run return 0
tag @s add ec.cf_codex_granted

# Trigger the existing tick give-loop (it loot-gives the codex item + auto-resets ec.cf_codex to 0).
scoreboard players set @s ec.cf_codex 1

# Celebration.
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold",bold:true},{text:"The Craftforever Codex",color:"gold",bold:true},{text:" appears in your hand!",color:"yellow"}]
scoreboard players set #ndur ec.temp 50
function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Right-click to open.",italic:true,color:"gray"}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 1 1.2
