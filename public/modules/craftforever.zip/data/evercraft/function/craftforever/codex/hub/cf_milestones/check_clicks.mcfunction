# CF Milestones — Check Clicks
# Page 1 (overview): detect category clicks
# Pages 9-14: realm milestone detail pages (reuse FC functions)
# Page 20: personal milestones
# Run as player, #cf_gui_owner ec.temp = session ID

# Auto-refresh overview page (every 60 ticks) so unclaimed counts update
execute if score @s ec.cf_codex_page matches 1 store result score #ms_refresh ec.temp run time query gametime
execute if score @s ec.cf_codex_page matches 1 run scoreboard players operation #ms_refresh ec.temp %= #60 ec.const
execute if score @s ec.cf_codex_page matches 1 if score #ms_refresh ec.temp matches 0 run function evercraft:codex/hub/milestones/refresh_overview

# === OVERVIEW CLICKS (page 1) ===
execute if score @s ec.cf_codex_page matches 1 as @e[type=interaction,tag=CF.MsOvClick0,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s interaction on target run function evercraft:craftforever/codex/hub/cf_milestones/click_origins
execute if score @s ec.cf_codex_page matches 1 as @e[type=interaction,tag=CF.MsOvClick0,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction
execute if score @s ec.cf_codex_page matches 1 as @e[type=interaction,tag=CF.MsOvClick1,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s interaction on target run function evercraft:craftforever/codex/hub/cf_milestones/click_social
execute if score @s ec.cf_codex_page matches 1 as @e[type=interaction,tag=CF.MsOvClick1,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction
execute if score @s ec.cf_codex_page matches 1 as @e[type=interaction,tag=CF.MsOvClick2,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s interaction on target run function evercraft:craftforever/codex/hub/cf_milestones/click_guild
execute if score @s ec.cf_codex_page matches 1 as @e[type=interaction,tag=CF.MsOvClick2,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction
execute if score @s ec.cf_codex_page matches 1 as @e[type=interaction,tag=CF.MsOvClick3,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s interaction on target run function evercraft:craftforever/codex/hub/cf_milestones/click_adventure
execute if score @s ec.cf_codex_page matches 1 as @e[type=interaction,tag=CF.MsOvClick3,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction
execute if score @s ec.cf_codex_page matches 1 as @e[type=interaction,tag=CF.MsOvClick4,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s interaction on target run function evercraft:craftforever/codex/hub/cf_milestones/click_combat
execute if score @s ec.cf_codex_page matches 1 as @e[type=interaction,tag=CF.MsOvClick4,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction
execute if score @s ec.cf_codex_page matches 1 as @e[type=interaction,tag=CF.MsOvClick5,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s interaction on target run function evercraft:craftforever/codex/hub/cf_milestones/click_mastery
execute if score @s ec.cf_codex_page matches 1 as @e[type=interaction,tag=CF.MsOvClick5,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction
execute if score @s ec.cf_codex_page matches 1 as @e[type=interaction,tag=CF.MsOvClick6,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s interaction on target run function evercraft:craftforever/codex/hub/cf_milestones/click_personal
execute if score @s ec.cf_codex_page matches 1 as @e[type=interaction,tag=CF.MsOvClick6,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction
execute if score @s ec.cf_codex_page matches 1 as @e[type=interaction,tag=CF.MsOvClick7,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s interaction on target run function evercraft:craftforever/codex/hub/cf_milestones/click_memories
execute if score @s ec.cf_codex_page matches 1 as @e[type=interaction,tag=CF.MsOvClick7,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction

# === DETAIL PAGES (9-14): Realm milestone claim clicks ===
# Set #gui_owner for FC claim function compatibility
scoreboard players operation #gui_owner ec.temp = @s ec.cf_gui_session

# Claim clicks (reuse FC claim functions — they check Adv.JnMsClaim* entities)
execute if score @s ec.cf_codex_page matches 9 run function evercraft:milestones/check_claims_origins
execute if score @s ec.cf_codex_page matches 10 run function evercraft:milestones/check_claims_social
execute if score @s ec.cf_codex_page matches 11 run function evercraft:milestones/check_claims_guild
execute if score @s ec.cf_codex_page matches 12 run function evercraft:milestones/check_claims_adventure
execute if score @s ec.cf_codex_page matches 13 run function evercraft:milestones/check_claims_combat
execute if score @s ec.cf_codex_page matches 14 run function evercraft:milestones/check_claims_mastery

# Auto-refresh detail pages every 60 ticks
execute if score @s ec.cf_codex_page matches 9..14 store result score #ms_refresh ec.temp run time query gametime
execute if score @s ec.cf_codex_page matches 9..14 run scoreboard players operation #ms_refresh ec.temp %= #60 ec.const
execute if score @s ec.cf_codex_page matches 9 if score #ms_refresh ec.temp matches 0 run function evercraft:codex/hub/journal/refresh_ms_origins
execute if score @s ec.cf_codex_page matches 10 if score #ms_refresh ec.temp matches 0 run function evercraft:codex/hub/journal/refresh_ms_social
execute if score @s ec.cf_codex_page matches 11 if score #ms_refresh ec.temp matches 0 run function evercraft:codex/hub/journal/refresh_ms_guild
execute if score @s ec.cf_codex_page matches 12 if score #ms_refresh ec.temp matches 0 run function evercraft:codex/hub/journal/refresh_ms_adventure
execute if score @s ec.cf_codex_page matches 13 if score #ms_refresh ec.temp matches 0 run function evercraft:codex/hub/journal/refresh_ms_combat
execute if score @s ec.cf_codex_page matches 14 if score #ms_refresh ec.temp matches 0 run function evercraft:codex/hub/journal/refresh_ms_mastery

# === PERSONAL MILESTONES (page 20) ===
# CF-aware page nav: the ecodex next_click/prev_click bridges select the main-codex shell
# (@p[Adv.InMenu] + Adv.MenuAnchor), which a CF-codex player lacks — so the panel's own Next/Prev
# would no-op here. Detect the click on the interaction + consume it, then run the SHARED ecodex
# page-change as the player (@s) facing the CF anchor (so its caret-spawned rows land on the menu)
# and re-apply the CF session bridge so the new page renders. Runs before the shared click handler
# below, which then sees no Next/Prev data and just handles claim clicks + auto-refresh.
scoreboard players set #cf_pm_next ec.temp 0
scoreboard players set #cf_pm_prev ec.temp 0
execute if score @s ec.cf_codex_page matches 20 as @e[type=interaction,tag=Ec.PMNextCl,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s interaction run scoreboard players set #cf_pm_next ec.temp 1
execute if score @s ec.cf_codex_page matches 20 as @e[type=interaction,tag=Ec.PMPrevCl,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s interaction run scoreboard players set #cf_pm_prev ec.temp 1
execute if score @s ec.cf_codex_page matches 20 as @e[type=interaction,tag=Ec.PMNextCl,distance=..5] if data entity @s interaction run data remove entity @s interaction
execute if score @s ec.cf_codex_page matches 20 as @e[type=interaction,tag=Ec.PMPrevCl,distance=..5] if data entity @s interaction run data remove entity @s interaction
execute if score #cf_pm_next ec.temp matches 1 at @s facing entity @e[type=marker,tag=CF.MenuAnchor,distance=..5,limit=1,sort=nearest] feet run function evercraft:ecodex/sections/personal_claims/next_page
execute if score #cf_pm_prev ec.temp matches 1 at @s facing entity @e[type=marker,tag=CF.MenuAnchor,distance=..5,limit=1,sort=nearest] feet run function evercraft:ecodex/sections/personal_claims/prev_page
execute if score #cf_pm_next ec.temp matches 1 run function evercraft:craftforever/codex/hub/cf_milestones/personal_bridge
execute if score #cf_pm_prev ec.temp matches 1 run function evercraft:craftforever/codex/hub/cf_milestones/personal_bridge

execute if score @s ec.cf_codex_page matches 20 run function evercraft:ecodex/sections/personal_claims/check_clicks

# ===== INSPECT (left-click) — gui/inspect pattern 2026-06-11. Cards explain buttons; detail
# rows get attack-PARITY twins (punch opens the same detail a use does — companion doctrine). =====
execute as @e[type=interaction,tag=CF.MsOvClick0,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"CF Origins Wall",b:"Right-click for starter crafting milestones. Claim what your totals have earned."}
execute as @e[type=interaction,tag=CF.MsOvClick0,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=CF.MsOvClick1,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"CF Social Wall",b:"Right-click for trade, gift, and gift-loop milestones. Claim what your totals have earned."}
execute as @e[type=interaction,tag=CF.MsOvClick1,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=CF.MsOvClick2,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"CF Guild Wall",b:"Right-click for guild-crafting and guild-trade milestones. Claim what your totals have earned."}
execute as @e[type=interaction,tag=CF.MsOvClick2,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=CF.MsOvClick3,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"CF Adventure Wall",b:"Right-click for expedition and travel crafting totals. Claim what your totals have earned."}
execute as @e[type=interaction,tag=CF.MsOvClick3,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=CF.MsOvClick4,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"CF Combat Wall",b:"Right-click for battle-crafting milestones — repair / forge / fuse counts. Claim what your totals have earned."}
execute as @e[type=interaction,tag=CF.MsOvClick4,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=CF.MsOvClick5,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"CF Mastery Wall",b:"Right-click for rank-up and high-tier mastery totals. Claim what your totals have earned."}
execute as @e[type=interaction,tag=CF.MsOvClick5,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=CF.MsOvClick6,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"CF Personal Wall",b:"Right-click for your self-set crafting dedications. Claim what your totals have earned."}
execute as @e[type=interaction,tag=CF.MsOvClick6,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=CF.MsOvClick7,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"CF Memories Wall",b:"Right-click for scrapbook crafting moments. Claim what your totals have earned."}
execute as @e[type=interaction,tag=CF.MsOvClick7,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s attack run data remove entity @s attack
