# Craftforever Codex — Trophy Gallery Section
# Two-column interactive layout with click-for-info
# Left-click a trophy to see how to earn it
# Run as player at player position

# Init trophy gallery to grid page (0 = grid, 1..15 = trophy id+1 detail). Mirrors recipes/spawn:6.
scoreboard players set @s ec.cf_troph_pg 0

# Subtitle
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^ ^1.97 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["CF.MenuElement","CF.SectionContent"],billboard:"center",text:{text:"Your collection of rare achievements",color:"gray",italic:true},background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.215f,0.215f,0.215f]}}

# Count trophies from bitfield (15 bits)
scoreboard players operation #cf_bits ec.temp = @s ec.cf_trophies
scoreboard players set #cf_trophy_count ec.temp 0
# Bit 0
scoreboard players operation #cf_b ec.temp = #cf_bits ec.temp
scoreboard players operation #cf_b ec.temp %= #2 ec.const
scoreboard players operation #cf_trophy_count ec.temp += #cf_b ec.temp
# Bits 1-14
execute store result score #cf_b ec.temp run scoreboard players operation #cf_bits ec.temp /= #2 ec.const
scoreboard players operation #cf_b ec.temp = #cf_bits ec.temp
scoreboard players operation #cf_b ec.temp %= #2 ec.const
scoreboard players operation #cf_trophy_count ec.temp += #cf_b ec.temp
execute store result score #cf_b ec.temp run scoreboard players operation #cf_bits ec.temp /= #2 ec.const
scoreboard players operation #cf_b ec.temp = #cf_bits ec.temp
scoreboard players operation #cf_b ec.temp %= #2 ec.const
scoreboard players operation #cf_trophy_count ec.temp += #cf_b ec.temp
execute store result score #cf_b ec.temp run scoreboard players operation #cf_bits ec.temp /= #2 ec.const
scoreboard players operation #cf_b ec.temp = #cf_bits ec.temp
scoreboard players operation #cf_b ec.temp %= #2 ec.const
scoreboard players operation #cf_trophy_count ec.temp += #cf_b ec.temp
execute store result score #cf_b ec.temp run scoreboard players operation #cf_bits ec.temp /= #2 ec.const
scoreboard players operation #cf_b ec.temp = #cf_bits ec.temp
scoreboard players operation #cf_b ec.temp %= #2 ec.const
scoreboard players operation #cf_trophy_count ec.temp += #cf_b ec.temp
execute store result score #cf_b ec.temp run scoreboard players operation #cf_bits ec.temp /= #2 ec.const
scoreboard players operation #cf_b ec.temp = #cf_bits ec.temp
scoreboard players operation #cf_b ec.temp %= #2 ec.const
scoreboard players operation #cf_trophy_count ec.temp += #cf_b ec.temp
execute store result score #cf_b ec.temp run scoreboard players operation #cf_bits ec.temp /= #2 ec.const
scoreboard players operation #cf_b ec.temp = #cf_bits ec.temp
scoreboard players operation #cf_b ec.temp %= #2 ec.const
scoreboard players operation #cf_trophy_count ec.temp += #cf_b ec.temp
execute store result score #cf_b ec.temp run scoreboard players operation #cf_bits ec.temp /= #2 ec.const
scoreboard players operation #cf_b ec.temp = #cf_bits ec.temp
scoreboard players operation #cf_b ec.temp %= #2 ec.const
scoreboard players operation #cf_trophy_count ec.temp += #cf_b ec.temp
execute store result score #cf_b ec.temp run scoreboard players operation #cf_bits ec.temp /= #2 ec.const
scoreboard players operation #cf_b ec.temp = #cf_bits ec.temp
scoreboard players operation #cf_b ec.temp %= #2 ec.const
scoreboard players operation #cf_trophy_count ec.temp += #cf_b ec.temp
execute store result score #cf_b ec.temp run scoreboard players operation #cf_bits ec.temp /= #2 ec.const
scoreboard players operation #cf_b ec.temp = #cf_bits ec.temp
scoreboard players operation #cf_b ec.temp %= #2 ec.const
scoreboard players operation #cf_trophy_count ec.temp += #cf_b ec.temp
execute store result score #cf_b ec.temp run scoreboard players operation #cf_bits ec.temp /= #2 ec.const
scoreboard players operation #cf_b ec.temp = #cf_bits ec.temp
scoreboard players operation #cf_b ec.temp %= #2 ec.const
scoreboard players operation #cf_trophy_count ec.temp += #cf_b ec.temp
execute store result score #cf_b ec.temp run scoreboard players operation #cf_bits ec.temp /= #2 ec.const
scoreboard players operation #cf_b ec.temp = #cf_bits ec.temp
scoreboard players operation #cf_b ec.temp %= #2 ec.const
scoreboard players operation #cf_trophy_count ec.temp += #cf_b ec.temp
execute store result score #cf_b ec.temp run scoreboard players operation #cf_bits ec.temp /= #2 ec.const
scoreboard players operation #cf_b ec.temp = #cf_bits ec.temp
scoreboard players operation #cf_b ec.temp %= #2 ec.const
scoreboard players operation #cf_trophy_count ec.temp += #cf_b ec.temp
execute store result score #cf_b ec.temp run scoreboard players operation #cf_bits ec.temp /= #2 ec.const
scoreboard players operation #cf_b ec.temp = #cf_bits ec.temp
scoreboard players operation #cf_b ec.temp %= #2 ec.const
scoreboard players operation #cf_trophy_count ec.temp += #cf_b ec.temp

execute store result storage evercraft:cf_temp trophy_count int 1 run scoreboard players get #cf_trophy_count ec.temp
function evercraft:craftforever/codex/hub/trophies/set_display with storage evercraft:cf_temp

# === LEFT COLUMN (bits 0-7) ===

# 0: Hearthkeeper
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^0.47 ^1.65 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["CF.MenuElement","CF.SectionContent","CF.Trophy0"],billboard:"center",text:{text:"",color:"gray"},background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.215f,0.215f,0.215f]}}
# [strip] CF.MenuElement: 0.5w split into 4 x 0.15 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^0.295 ^1.575 ^1.8 run summon interaction ~ ~ ~ {Tags:["CF.MenuElement","CF.SectionContent","CF.TrophyCl0"],width:0.15f,height:0.15f,response:1b}
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^0.4117 ^1.575 ^1.8 run summon interaction ~ ~ ~ {Tags:["CF.MenuElement","CF.SectionContent","CF.TrophyCl0"],width:0.15f,height:0.15f,response:1b}
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^0.5283 ^1.575 ^1.8 run summon interaction ~ ~ ~ {Tags:["CF.MenuElement","CF.SectionContent","CF.TrophyCl0"],width:0.15f,height:0.15f,response:1b}
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^0.645 ^1.575 ^1.8 run summon interaction ~ ~ ~ {Tags:["CF.MenuElement","CF.SectionContent","CF.TrophyCl0"],width:0.15f,height:0.15f,response:1b}

# 1: Grand Architect
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^0.47 ^1.5 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["CF.MenuElement","CF.SectionContent","CF.Trophy1"],billboard:"center",text:{text:"",color:"gray"},background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.215f,0.215f,0.215f]}}
# [strip] CF.MenuElement: 0.5w split into 4 x 0.15 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^0.295 ^1.425 ^1.8 run summon interaction ~ ~ ~ {Tags:["CF.MenuElement","CF.SectionContent","CF.TrophyCl1"],width:0.15f,height:0.15f,response:1b}
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^0.4117 ^1.425 ^1.8 run summon interaction ~ ~ ~ {Tags:["CF.MenuElement","CF.SectionContent","CF.TrophyCl1"],width:0.15f,height:0.15f,response:1b}
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^0.5283 ^1.425 ^1.8 run summon interaction ~ ~ ~ {Tags:["CF.MenuElement","CF.SectionContent","CF.TrophyCl1"],width:0.15f,height:0.15f,response:1b}
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^0.645 ^1.425 ^1.8 run summon interaction ~ ~ ~ {Tags:["CF.MenuElement","CF.SectionContent","CF.TrophyCl1"],width:0.15f,height:0.15f,response:1b}

# 2: Legendary Builder
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^0.47 ^1.35 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["CF.MenuElement","CF.SectionContent","CF.Trophy2"],billboard:"center",text:{text:"",color:"gray"},background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.215f,0.215f,0.215f]}}
# [strip] CF.MenuElement: 0.5w split into 4 x 0.15 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^0.295 ^1.275 ^1.8 run summon interaction ~ ~ ~ {Tags:["CF.MenuElement","CF.SectionContent","CF.TrophyCl2"],width:0.15f,height:0.15f,response:1b}
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^0.4117 ^1.275 ^1.8 run summon interaction ~ ~ ~ {Tags:["CF.MenuElement","CF.SectionContent","CF.TrophyCl2"],width:0.15f,height:0.15f,response:1b}
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^0.5283 ^1.275 ^1.8 run summon interaction ~ ~ ~ {Tags:["CF.MenuElement","CF.SectionContent","CF.TrophyCl2"],width:0.15f,height:0.15f,response:1b}
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^0.645 ^1.275 ^1.8 run summon interaction ~ ~ ~ {Tags:["CF.MenuElement","CF.SectionContent","CF.TrophyCl2"],width:0.15f,height:0.15f,response:1b}

# 3: Dragon Slayer
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^0.47 ^1.2 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["CF.MenuElement","CF.SectionContent","CF.Trophy3"],billboard:"center",text:{text:"",color:"gray"},background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.215f,0.215f,0.215f]}}
# [strip] CF.MenuElement: 0.5w split into 4 x 0.15 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^0.295 ^1.125 ^1.8 run summon interaction ~ ~ ~ {Tags:["CF.MenuElement","CF.SectionContent","CF.TrophyCl3"],width:0.15f,height:0.15f,response:1b}
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^0.4117 ^1.125 ^1.8 run summon interaction ~ ~ ~ {Tags:["CF.MenuElement","CF.SectionContent","CF.TrophyCl3"],width:0.15f,height:0.15f,response:1b}
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^0.5283 ^1.125 ^1.8 run summon interaction ~ ~ ~ {Tags:["CF.MenuElement","CF.SectionContent","CF.TrophyCl3"],width:0.15f,height:0.15f,response:1b}
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^0.645 ^1.125 ^1.8 run summon interaction ~ ~ ~ {Tags:["CF.MenuElement","CF.SectionContent","CF.TrophyCl3"],width:0.15f,height:0.15f,response:1b}

# 4: Wither Bane
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^0.47 ^1.05 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["CF.MenuElement","CF.SectionContent","CF.Trophy4"],billboard:"center",text:{text:"",color:"gray"},background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.215f,0.215f,0.215f]}}
# [strip] CF.MenuElement: 0.5w split into 4 x 0.15 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^0.295 ^0.975 ^1.8 run summon interaction ~ ~ ~ {Tags:["CF.MenuElement","CF.SectionContent","CF.TrophyCl4"],width:0.15f,height:0.15f,response:1b}
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^0.4117 ^0.975 ^1.8 run summon interaction ~ ~ ~ {Tags:["CF.MenuElement","CF.SectionContent","CF.TrophyCl4"],width:0.15f,height:0.15f,response:1b}
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^0.5283 ^0.975 ^1.8 run summon interaction ~ ~ ~ {Tags:["CF.MenuElement","CF.SectionContent","CF.TrophyCl4"],width:0.15f,height:0.15f,response:1b}
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^0.645 ^0.975 ^1.8 run summon interaction ~ ~ ~ {Tags:["CF.MenuElement","CF.SectionContent","CF.TrophyCl4"],width:0.15f,height:0.15f,response:1b}

# 5: World Explorer
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^0.47 ^0.9 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["CF.MenuElement","CF.SectionContent","CF.Trophy5"],billboard:"center",text:{text:"",color:"gray"},background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.215f,0.215f,0.215f]}}
# [strip] CF.MenuElement: 0.5w split into 4 x 0.15 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^0.295 ^0.825 ^1.8 run summon interaction ~ ~ ~ {Tags:["CF.MenuElement","CF.SectionContent","CF.TrophyCl5"],width:0.15f,height:0.15f,response:1b}
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^0.4117 ^0.825 ^1.8 run summon interaction ~ ~ ~ {Tags:["CF.MenuElement","CF.SectionContent","CF.TrophyCl5"],width:0.15f,height:0.15f,response:1b}
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^0.5283 ^0.825 ^1.8 run summon interaction ~ ~ ~ {Tags:["CF.MenuElement","CF.SectionContent","CF.TrophyCl5"],width:0.15f,height:0.15f,response:1b}
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^0.645 ^0.825 ^1.8 run summon interaction ~ ~ ~ {Tags:["CF.MenuElement","CF.SectionContent","CF.TrophyCl5"],width:0.15f,height:0.15f,response:1b}

# 6: Lore Keeper
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^0.47 ^0.75 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["CF.MenuElement","CF.SectionContent","CF.Trophy6"],billboard:"center",text:{text:"",color:"gray"},background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.215f,0.215f,0.215f]}}
# [strip] CF.MenuElement: 0.5w split into 4 x 0.15 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^0.295 ^0.675 ^1.8 run summon interaction ~ ~ ~ {Tags:["CF.MenuElement","CF.SectionContent","CF.TrophyCl6"],width:0.15f,height:0.15f,response:1b}
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^0.4117 ^0.675 ^1.8 run summon interaction ~ ~ ~ {Tags:["CF.MenuElement","CF.SectionContent","CF.TrophyCl6"],width:0.15f,height:0.15f,response:1b}
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^0.5283 ^0.675 ^1.8 run summon interaction ~ ~ ~ {Tags:["CF.MenuElement","CF.SectionContent","CF.TrophyCl6"],width:0.15f,height:0.15f,response:1b}
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^0.645 ^0.675 ^1.8 run summon interaction ~ ~ ~ {Tags:["CF.MenuElement","CF.SectionContent","CF.TrophyCl6"],width:0.15f,height:0.15f,response:1b}

# 7: Battle Master
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^0.47 ^0.6 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["CF.MenuElement","CF.SectionContent","CF.Trophy7"],billboard:"center",text:{text:"",color:"gray"},background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.215f,0.215f,0.215f]}}
# [strip] CF.MenuElement: 0.5w split into 4 x 0.15 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^0.295 ^0.525 ^1.8 run summon interaction ~ ~ ~ {Tags:["CF.MenuElement","CF.SectionContent","CF.TrophyCl7"],width:0.15f,height:0.15f,response:1b}
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^0.4117 ^0.525 ^1.8 run summon interaction ~ ~ ~ {Tags:["CF.MenuElement","CF.SectionContent","CF.TrophyCl7"],width:0.15f,height:0.15f,response:1b}
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^0.5283 ^0.525 ^1.8 run summon interaction ~ ~ ~ {Tags:["CF.MenuElement","CF.SectionContent","CF.TrophyCl7"],width:0.15f,height:0.15f,response:1b}
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^0.645 ^0.525 ^1.8 run summon interaction ~ ~ ~ {Tags:["CF.MenuElement","CF.SectionContent","CF.TrophyCl7"],width:0.15f,height:0.15f,response:1b}

# === RIGHT COLUMN (bits 8-14) ===

# 8: Pack Leader
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^-0.63 ^1.65 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["CF.MenuElement","CF.SectionContent","CF.Trophy8"],billboard:"center",text:{text:"",color:"gray"},background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.215f,0.215f,0.215f]}}
# [strip] CF.MenuElement: 0.5w split into 4 x 0.15 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^-0.805 ^1.575 ^1.8 run summon interaction ~ ~ ~ {Tags:["CF.MenuElement","CF.SectionContent","CF.TrophyCl8"],width:0.15f,height:0.15f,response:1b}
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^-0.6883 ^1.575 ^1.8 run summon interaction ~ ~ ~ {Tags:["CF.MenuElement","CF.SectionContent","CF.TrophyCl8"],width:0.15f,height:0.15f,response:1b}
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^-0.5717 ^1.575 ^1.8 run summon interaction ~ ~ ~ {Tags:["CF.MenuElement","CF.SectionContent","CF.TrophyCl8"],width:0.15f,height:0.15f,response:1b}
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^-0.455 ^1.575 ^1.8 run summon interaction ~ ~ ~ {Tags:["CF.MenuElement","CF.SectionContent","CF.TrophyCl8"],width:0.15f,height:0.15f,response:1b}

# 9: CraftForever Star
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^-0.63 ^1.5 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["CF.MenuElement","CF.SectionContent","CF.Trophy9"],billboard:"center",text:{text:"",color:"gray"},background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.215f,0.215f,0.215f]}}
# [strip] CF.MenuElement: 0.5w split into 4 x 0.15 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^-0.805 ^1.425 ^1.8 run summon interaction ~ ~ ~ {Tags:["CF.MenuElement","CF.SectionContent","CF.TrophyCl9"],width:0.15f,height:0.15f,response:1b}
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^-0.6883 ^1.425 ^1.8 run summon interaction ~ ~ ~ {Tags:["CF.MenuElement","CF.SectionContent","CF.TrophyCl9"],width:0.15f,height:0.15f,response:1b}
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^-0.5717 ^1.425 ^1.8 run summon interaction ~ ~ ~ {Tags:["CF.MenuElement","CF.SectionContent","CF.TrophyCl9"],width:0.15f,height:0.15f,response:1b}
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^-0.455 ^1.425 ^1.8 run summon interaction ~ ~ ~ {Tags:["CF.MenuElement","CF.SectionContent","CF.TrophyCl9"],width:0.15f,height:0.15f,response:1b}

# 10: Treasure Hunter
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^-0.63 ^1.35 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["CF.MenuElement","CF.SectionContent","CF.Trophy10"],billboard:"center",text:{text:"",color:"gray"},background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.215f,0.215f,0.215f]}}
# [strip] CF.MenuElement: 0.5w split into 4 x 0.15 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^-0.805 ^1.275 ^1.8 run summon interaction ~ ~ ~ {Tags:["CF.MenuElement","CF.SectionContent","CF.TrophyCl10"],width:0.15f,height:0.15f,response:1b}
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^-0.6883 ^1.275 ^1.8 run summon interaction ~ ~ ~ {Tags:["CF.MenuElement","CF.SectionContent","CF.TrophyCl10"],width:0.15f,height:0.15f,response:1b}
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^-0.5717 ^1.275 ^1.8 run summon interaction ~ ~ ~ {Tags:["CF.MenuElement","CF.SectionContent","CF.TrophyCl10"],width:0.15f,height:0.15f,response:1b}
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^-0.455 ^1.275 ^1.8 run summon interaction ~ ~ ~ {Tags:["CF.MenuElement","CF.SectionContent","CF.TrophyCl10"],width:0.15f,height:0.15f,response:1b}

# 11: Expeditionist
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^-0.63 ^1.2 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["CF.MenuElement","CF.SectionContent","CF.Trophy11"],billboard:"center",text:{text:"",color:"gray"},background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.215f,0.215f,0.215f]}}
# [strip] CF.MenuElement: 0.5w split into 4 x 0.15 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^-0.805 ^1.125 ^1.8 run summon interaction ~ ~ ~ {Tags:["CF.MenuElement","CF.SectionContent","CF.TrophyCl11"],width:0.15f,height:0.15f,response:1b}
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^-0.6883 ^1.125 ^1.8 run summon interaction ~ ~ ~ {Tags:["CF.MenuElement","CF.SectionContent","CF.TrophyCl11"],width:0.15f,height:0.15f,response:1b}
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^-0.5717 ^1.125 ^1.8 run summon interaction ~ ~ ~ {Tags:["CF.MenuElement","CF.SectionContent","CF.TrophyCl11"],width:0.15f,height:0.15f,response:1b}
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^-0.455 ^1.125 ^1.8 run summon interaction ~ ~ ~ {Tags:["CF.MenuElement","CF.SectionContent","CF.TrophyCl11"],width:0.15f,height:0.15f,response:1b}

# 12: Realm Champion
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^-0.63 ^1.05 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["CF.MenuElement","CF.SectionContent","CF.Trophy12"],billboard:"center",text:{text:"",color:"gray"},background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.215f,0.215f,0.215f]}}
# [strip] CF.MenuElement: 0.5w split into 4 x 0.15 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^-0.805 ^0.975 ^1.8 run summon interaction ~ ~ ~ {Tags:["CF.MenuElement","CF.SectionContent","CF.TrophyCl12"],width:0.15f,height:0.15f,response:1b}
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^-0.6883 ^0.975 ^1.8 run summon interaction ~ ~ ~ {Tags:["CF.MenuElement","CF.SectionContent","CF.TrophyCl12"],width:0.15f,height:0.15f,response:1b}
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^-0.5717 ^0.975 ^1.8 run summon interaction ~ ~ ~ {Tags:["CF.MenuElement","CF.SectionContent","CF.TrophyCl12"],width:0.15f,height:0.15f,response:1b}
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^-0.455 ^0.975 ^1.8 run summon interaction ~ ~ ~ {Tags:["CF.MenuElement","CF.SectionContent","CF.TrophyCl12"],width:0.15f,height:0.15f,response:1b}

# 13: Spirit Forger
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^-0.63 ^0.9 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["CF.MenuElement","CF.SectionContent","CF.Trophy13"],billboard:"center",text:{text:"",color:"gray"},background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.215f,0.215f,0.215f]}}
# [strip] CF.MenuElement: 0.5w split into 4 x 0.15 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^-0.805 ^0.825 ^1.8 run summon interaction ~ ~ ~ {Tags:["CF.MenuElement","CF.SectionContent","CF.TrophyCl13"],width:0.15f,height:0.15f,response:1b}
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^-0.6883 ^0.825 ^1.8 run summon interaction ~ ~ ~ {Tags:["CF.MenuElement","CF.SectionContent","CF.TrophyCl13"],width:0.15f,height:0.15f,response:1b}
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^-0.5717 ^0.825 ^1.8 run summon interaction ~ ~ ~ {Tags:["CF.MenuElement","CF.SectionContent","CF.TrophyCl13"],width:0.15f,height:0.15f,response:1b}
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^-0.455 ^0.825 ^1.8 run summon interaction ~ ~ ~ {Tags:["CF.MenuElement","CF.SectionContent","CF.TrophyCl13"],width:0.15f,height:0.15f,response:1b}

# 14: Guild Legend
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^-0.63 ^0.75 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["CF.MenuElement","CF.SectionContent","CF.Trophy14"],billboard:"center",text:{text:"",color:"gray"},background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.215f,0.215f,0.215f]}}
# [strip] CF.MenuElement: 0.5w split into 4 x 0.15 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^-0.805 ^0.675 ^1.8 run summon interaction ~ ~ ~ {Tags:["CF.MenuElement","CF.SectionContent","CF.TrophyCl14"],width:0.15f,height:0.15f,response:1b}
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^-0.6883 ^0.675 ^1.8 run summon interaction ~ ~ ~ {Tags:["CF.MenuElement","CF.SectionContent","CF.TrophyCl14"],width:0.15f,height:0.15f,response:1b}
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^-0.5717 ^0.675 ^1.8 run summon interaction ~ ~ ~ {Tags:["CF.MenuElement","CF.SectionContent","CF.TrophyCl14"],width:0.15f,height:0.15f,response:1b}
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^-0.455 ^0.675 ^1.8 run summon interaction ~ ~ ~ {Tags:["CF.MenuElement","CF.SectionContent","CF.TrophyCl14"],width:0.15f,height:0.15f,response:1b}

# Footer
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^ ^0.35 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["CF.MenuElement","CF.SectionContent"],billboard:"center",text:{text:"Trophies boost Comfort by +25 when placed!",color:"dark_gray",italic:true},background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.191f,0.191f,0.191f]}}

# Refresh display text for all trophies
function evercraft:craftforever/codex/hub/trophies/refresh
