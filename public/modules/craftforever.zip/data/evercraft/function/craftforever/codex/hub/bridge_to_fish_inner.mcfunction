# #3 (D3) — Fisher's Path bridge inner. Run as the player holding the CF codex, at player.
# Mirrors bridge_to_fc_inner, then deep-links to the Fisher's Path questline page: enter §26
# (grand_quests/spawn lays a Tier-1/Tier-2 landing by lens), then open_detail overwrites it with
# the fishing page. [← Path Overview] from there returns to the Crafter Tier-2 (line 1 → spawn_crafter).
function evercraft:craftforever/codex/hub/close
tag @s add ec.cf_bridge_active
function evercraft:codex/hub/open
function evercraft:codex/hub/enter_section_inner {section:26}
scoreboard players set @s ec.gq_qln_ln 1
function evercraft:codex/hub/grand_quests/qln/open_detail
