# #3 (D3) — Fisher's Path CF tab → bridge into the main codex §26 Grand Quests, then open the
# Fisher's Path questline page (line 1). Mirrors bridge_to_fc but lands on a specific questline
# page instead of a bare section. Run as the clicked CF.HubClick9 interaction entity.
data remove entity @s interaction
scoreboard players operation #cf_click_sess ec.temp = @s ec.cf_gui_session
execute as @a[tag=CF.InCodex,distance=..5] if score @s ec.cf_gui_session = #cf_click_sess ec.temp at @s run function evercraft:craftforever/codex/hub/bridge_to_fish_inner
