# CF Cosmetics — Tier Cosmetics Click (runs as interaction entity)
data remove entity @s interaction
execute as @p[tag=CF.InCodex,distance=..5] run tellraw @s [{"text":"[","color":"dark_gray"},{"text":"Tier Cosmetics","color":"aqua","bold":true},{"text":"] ","color":"dark_gray"},{"text":"Open the ","color":"gray"},{"text":"Forevercraft Codex","color":"green","bold":true},{"text":" > Cosmetics to equip!","color":"gray"}]
execute as @p[tag=CF.InCodex,distance=..5] if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.hat master @s ~ ~ ~ 0.3 1.8
