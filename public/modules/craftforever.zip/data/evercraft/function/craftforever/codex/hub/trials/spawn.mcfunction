# Craftforever Codex — Trade Trials Section (Wiring Audit #14 C12)
# Spawn-only. Shows the 6 per-class best scores from the Trade Trial / Trial Anvil.
# Reached via enter_section {section:19}; closed-state gated by the codex dispatch.

# Subtitle
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^ ^1.97 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["CF.MenuElement","CF.SectionContent"],billboard:"center",text:{text:"Your best scores across the six trade trials",color:"gray",italic:true},background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.215f,0.215f,0.215f]}}

# 6 class best-score rows
# === 26.1 fix: {score} blank in text_display -> bake via storage macro ===
scoreboard players add @s ec.tt_m_best 0
execute store result storage evercraft:scorebake args.v1 int 1 run scoreboard players get @s ec.tt_m_best
scoreboard players add @s ec.tt_farm_best 0
execute store result storage evercraft:scorebake args.v2 int 1 run scoreboard players get @s ec.tt_farm_best
scoreboard players add @s ec.tt_fish_best 0
execute store result storage evercraft:scorebake args.v3 int 1 run scoreboard players get @s ec.tt_fish_best
scoreboard players add @s ec.tt_build_best 0
execute store result storage evercraft:scorebake args.v4 int 1 run scoreboard players get @s ec.tt_build_best
scoreboard players add @s ec.tt_lumb_best 0
execute store result storage evercraft:scorebake args.v5 int 1 run scoreboard players get @s ec.tt_lumb_best
scoreboard players add @s ec.tt_art_best 0
execute store result storage evercraft:scorebake args.v6 int 1 run scoreboard players get @s ec.tt_art_best
function evercraft:craftforever/codex/hub/trials/spawn_dyn with storage evercraft:scorebake args

# Footer hint
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^ ^0.87 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["CF.MenuElement","CF.SectionContent"],billboard:"center",text:{text:"Begin a trial at the Trial Anvil with a Trial Pass.",color:"dark_gray",italic:true},background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.191f,0.191f,0.191f]}}
