# Codex hub — sub-page Back dispatch (perf P1-4)
# Run as the player who clicked CF.BackBtnClick on a sub-page (cf_codex_page>=2).
# Routes to the correct per-section back_to_overview by ec.cf_codex_section.
# Sections without a sub-page back fall through here as a no-op (the generic
# back_to_hub later in tick.mcfunction handles them).
# @s is the interaction entity; the player's section was stamped into
# #cf_back_section ec.temp by tick.mcfunction before this scan.
execute if score #cf_back_section ec.temp matches 3 run function evercraft:craftforever/codex/hub/cookbook/back_to_overview
execute if score #cf_back_section ec.temp matches 4 run function evercraft:craftforever/codex/hub/housing/back_to_overview
execute if score #cf_back_section ec.temp matches 9 run function evercraft:craftforever/codex/hub/recipes/back_to_overview
execute if score #cf_back_section ec.temp matches 10 run function evercraft:craftforever/codex/hub/discovery/back_to_overview
execute if score #cf_back_section ec.temp matches 14 run function evercraft:craftforever/codex/hub/cf_milestones/back_to_overview
