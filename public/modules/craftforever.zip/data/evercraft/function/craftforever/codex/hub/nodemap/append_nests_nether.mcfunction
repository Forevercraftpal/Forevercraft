# Node Map — Append the nether Nest discovery line (Ember Nest = bit 4 of cf_nest_found) [PLAN-nest §7].
# Run as the CF.MapNether text_display (build_nether already set its text array).
data modify entity @s text append value {"text":"\n","color":"gray"}
execute if score #cf_n_nether ec.temp matches 1 run data modify entity @s text append value {"text":"✓ Ember Nest","color":"#F97316"}
execute if score #cf_n_nether ec.temp matches 0 run data modify entity @s text append value {"text":"○ Ember Nest","color":"dark_gray"}
