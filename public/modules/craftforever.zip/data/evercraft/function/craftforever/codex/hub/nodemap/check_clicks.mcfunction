# Node Map — Click detection (page-gated grid<->detail; mirror crafting_classes/check_clicks)
# Run as player, #cf_gui_owner ec.temp = session ID. cf_node_pg: 0=grid, 1=Overworld 2=Nether 3=End.

# === GRID PAGE (cf_node_pg 0): 3 dimension headers -> open_detail {dim:N} ===
execute if score @s ec.cf_node_pg matches 0 as @e[type=interaction,tag=CF.MapOWClick,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s interaction on target run function evercraft:craftforever/codex/hub/nodemap/open_detail {dim:1}
execute if score @s ec.cf_node_pg matches 0 as @e[type=interaction,tag=CF.MapOWClick,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction
execute if score @s ec.cf_node_pg matches 0 as @e[type=interaction,tag=CF.MapNetherClick,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s interaction on target run function evercraft:craftforever/codex/hub/nodemap/open_detail {dim:2}
execute if score @s ec.cf_node_pg matches 0 as @e[type=interaction,tag=CF.MapNetherClick,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction
execute if score @s ec.cf_node_pg matches 0 as @e[type=interaction,tag=CF.MapEndClick,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s interaction on target run function evercraft:craftforever/codex/hub/nodemap/open_detail {dim:3}
execute if score @s ec.cf_node_pg matches 0 as @e[type=interaction,tag=CF.MapEndClick,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction

# === DETAIL PAGE (cf_node_pg 1..3): only the Back hitbox is live ===
execute unless score @s ec.cf_node_pg matches 0 as @e[type=interaction,tag=CF.NodeBackClick,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s interaction on target run function evercraft:craftforever/codex/hub/nodemap/back_to_map
execute unless score @s ec.cf_node_pg matches 0 as @e[type=interaction,tag=CF.NodeBackClick,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction

# ===== INSPECT (left-click) — gui/inspect pattern 2026-06-11. Cards explain buttons; detail
# rows get attack-PARITY twins (punch opens the same detail a use does — companion doctrine). =====
execute as @e[type=interaction,tag=CF.MapOWClick,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Overworld Nodes",b:"Opens the Overworld node map — where its gathering nodes live."}
execute as @e[type=interaction,tag=CF.MapOWClick,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=CF.MapNetherClick,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Nether Nodes",b:"Opens the Nether node map — where its gathering nodes live."}
execute as @e[type=interaction,tag=CF.MapNetherClick,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=CF.MapEndClick,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"End Nodes",b:"Opens the End node map — where its gathering nodes live."}
execute as @e[type=interaction,tag=CF.MapEndClick,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=CF.NodeBackClick,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Back",b:"Returns to the node map overview."}
execute as @e[type=interaction,tag=CF.NodeBackClick,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s attack run data remove entity @s attack
