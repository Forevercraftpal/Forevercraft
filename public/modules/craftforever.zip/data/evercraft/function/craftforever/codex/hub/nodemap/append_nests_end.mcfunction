# Node Map — Append the End Nest discovery line (Astral Nest = bit 8 of cf_nest_found) [PLAN-nest §7].
# Run as the CF.MapEnd text_display (build_end already set its text array).
data modify entity @s text append value {"text":"\n","color":"gray"}
execute if score #cf_n_end ec.temp matches 1 run data modify entity @s text append value {"text":"✓ Astral Nest","color":"#A855F7"}
execute if score #cf_n_end ec.temp matches 0 run data modify entity @s text append value {"text":"○ Astral Nest","color":"dark_gray"}
