# Materials Panel — Locked-material tellraw (shared)
# AU14-P2 (Joseph 2026-05-30): fires when a click_material hit a row whose discovery bit is unset.
# Run as the interaction entity (the click_material caller).

tellraw @p[tag=CF.InCodex,distance=..5] [{"text":"\n"},{"text":"◆ ","color":"dark_gray"},{"text":"Undiscovered Material","color":"dark_gray","bold":true,"italic":true},{"text":"\n"},{"text":"This material has not yet been revealed.","color":"gray","italic":true},{"text":"\n"},{"text":"Mine biome nodes across the world to discover it.","color":"dark_gray","italic":true}]
