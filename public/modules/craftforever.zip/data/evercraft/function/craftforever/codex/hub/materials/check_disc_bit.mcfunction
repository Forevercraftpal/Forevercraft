# Materials Panel — Check discovery bit (macro)
# AU14-P2 (Joseph 2026-05-30): per-material spoiler gate. Sets #cf_disc_match ec.temp = 0/1
# based on whether the codex viewer's ec.cf_materials bitfield has the bit at `pow` set.
# Args: {pow:N} where N is the power-of-two bitmask (1, 2, 4, 8, 16, ..., 16384).
# Run as the interaction entity (the click_material caller); viewer = @p[tag=CF.InCodex,distance=..5].

execute store result score #cf_disc_match ec.temp run scoreboard players get @p[tag=CF.InCodex,distance=..5] ec.cf_materials
$scoreboard players set #cf_d ec.temp $(pow)
scoreboard players operation #cf_disc_match ec.temp /= #cf_d ec.temp
scoreboard players operation #cf_disc_match ec.temp %= #2 ec.const
