# Craftforever Codex — Universal back button
# Run as player, at player position

execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^ ^0.17 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["CF.MenuElement","CF.SectionContent","CF.BackBtnText"],billboard:"center",text:{text:"[ \u2190 Menu ]",color:"yellow",bold:true},background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.358f,0.358f,0.358f]}}
# [strip] CF.MenuElement: 0.4w split into 4 x 0.12 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^-0.14 ^0.13 ^1.8 run summon interaction ~ ~ ~ {Tags:["CF.MenuElement","CF.SectionContent","CF.BackBtnClick"],width:0.12f,height:0.06f,response:1b}
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^-0.0467 ^0.13 ^1.8 run summon interaction ~ ~ ~ {Tags:["CF.MenuElement","CF.SectionContent","CF.BackBtnClick"],width:0.12f,height:0.06f,response:1b}
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^0.0467 ^0.13 ^1.8 run summon interaction ~ ~ ~ {Tags:["CF.MenuElement","CF.SectionContent","CF.BackBtnClick"],width:0.12f,height:0.06f,response:1b}
execute at @e[tag=CF.RenderAnchor,limit=1,sort=nearest,distance=..8] positioned ^0.14 ^0.13 ^1.8 run summon interaction ~ ~ ~ {Tags:["CF.MenuElement","CF.SectionContent","CF.BackBtnClick"],width:0.12f,height:0.06f,response:1b}
