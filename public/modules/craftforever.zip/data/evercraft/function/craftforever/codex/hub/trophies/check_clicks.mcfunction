# Trophy Gallery — Check Clicks (Housing page 3)
# Run as player, #cf_gui_owner ec.temp = session ID
# Two-level page-gate: cf_codex_page matches 3 (gallery active) AND cf_troph_pg (0=grid, 1..15=detail).
# Mirrors recipes/check_clicks (closest sibling), adapted: the GRID opens on ATTACK (left-click) and
# flushes BOTH attack + interaction; the DETAIL Back opens on RIGHT-click (interaction) like every codex Back.

# === GALLERY GRID (cf_troph_pg 0): attack a trophy -> open_detail {pg: id+1} ===
# id 0 Hearthkeeper -> pg 1
execute if score @s ec.cf_codex_page matches 3 if score @s ec.cf_troph_pg matches 0 as @e[type=interaction,tag=CF.TrophyCl0,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s attack on target run function evercraft:craftforever/codex/hub/trophies/open_detail {pg:1}
execute if score @s ec.cf_codex_page matches 3 if score @s ec.cf_troph_pg matches 0 as @e[type=interaction,tag=CF.TrophyCl0,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute if score @s ec.cf_codex_page matches 3 if score @s ec.cf_troph_pg matches 0 as @e[type=interaction,tag=CF.TrophyCl0,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction
# id 1 Grand Architect -> pg 2
execute if score @s ec.cf_codex_page matches 3 if score @s ec.cf_troph_pg matches 0 as @e[type=interaction,tag=CF.TrophyCl1,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s attack on target run function evercraft:craftforever/codex/hub/trophies/open_detail {pg:2}
execute if score @s ec.cf_codex_page matches 3 if score @s ec.cf_troph_pg matches 0 as @e[type=interaction,tag=CF.TrophyCl1,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute if score @s ec.cf_codex_page matches 3 if score @s ec.cf_troph_pg matches 0 as @e[type=interaction,tag=CF.TrophyCl1,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction
# id 2 Legendary Builder -> pg 3
execute if score @s ec.cf_codex_page matches 3 if score @s ec.cf_troph_pg matches 0 as @e[type=interaction,tag=CF.TrophyCl2,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s attack on target run function evercraft:craftforever/codex/hub/trophies/open_detail {pg:3}
execute if score @s ec.cf_codex_page matches 3 if score @s ec.cf_troph_pg matches 0 as @e[type=interaction,tag=CF.TrophyCl2,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute if score @s ec.cf_codex_page matches 3 if score @s ec.cf_troph_pg matches 0 as @e[type=interaction,tag=CF.TrophyCl2,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction
# id 3 Dragon Slayer -> pg 4
execute if score @s ec.cf_codex_page matches 3 if score @s ec.cf_troph_pg matches 0 as @e[type=interaction,tag=CF.TrophyCl3,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s attack on target run function evercraft:craftforever/codex/hub/trophies/open_detail {pg:4}
execute if score @s ec.cf_codex_page matches 3 if score @s ec.cf_troph_pg matches 0 as @e[type=interaction,tag=CF.TrophyCl3,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute if score @s ec.cf_codex_page matches 3 if score @s ec.cf_troph_pg matches 0 as @e[type=interaction,tag=CF.TrophyCl3,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction
# id 4 Wither Bane -> pg 5
execute if score @s ec.cf_codex_page matches 3 if score @s ec.cf_troph_pg matches 0 as @e[type=interaction,tag=CF.TrophyCl4,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s attack on target run function evercraft:craftforever/codex/hub/trophies/open_detail {pg:5}
execute if score @s ec.cf_codex_page matches 3 if score @s ec.cf_troph_pg matches 0 as @e[type=interaction,tag=CF.TrophyCl4,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute if score @s ec.cf_codex_page matches 3 if score @s ec.cf_troph_pg matches 0 as @e[type=interaction,tag=CF.TrophyCl4,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction
# id 5 World Explorer -> pg 6
execute if score @s ec.cf_codex_page matches 3 if score @s ec.cf_troph_pg matches 0 as @e[type=interaction,tag=CF.TrophyCl5,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s attack on target run function evercraft:craftforever/codex/hub/trophies/open_detail {pg:6}
execute if score @s ec.cf_codex_page matches 3 if score @s ec.cf_troph_pg matches 0 as @e[type=interaction,tag=CF.TrophyCl5,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute if score @s ec.cf_codex_page matches 3 if score @s ec.cf_troph_pg matches 0 as @e[type=interaction,tag=CF.TrophyCl5,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction
# id 6 Lore Keeper -> pg 7
execute if score @s ec.cf_codex_page matches 3 if score @s ec.cf_troph_pg matches 0 as @e[type=interaction,tag=CF.TrophyCl6,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s attack on target run function evercraft:craftforever/codex/hub/trophies/open_detail {pg:7}
execute if score @s ec.cf_codex_page matches 3 if score @s ec.cf_troph_pg matches 0 as @e[type=interaction,tag=CF.TrophyCl6,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute if score @s ec.cf_codex_page matches 3 if score @s ec.cf_troph_pg matches 0 as @e[type=interaction,tag=CF.TrophyCl6,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction
# id 7 Battle Master -> pg 8
execute if score @s ec.cf_codex_page matches 3 if score @s ec.cf_troph_pg matches 0 as @e[type=interaction,tag=CF.TrophyCl7,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s attack on target run function evercraft:craftforever/codex/hub/trophies/open_detail {pg:8}
execute if score @s ec.cf_codex_page matches 3 if score @s ec.cf_troph_pg matches 0 as @e[type=interaction,tag=CF.TrophyCl7,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute if score @s ec.cf_codex_page matches 3 if score @s ec.cf_troph_pg matches 0 as @e[type=interaction,tag=CF.TrophyCl7,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction
# id 8 Pack Leader -> pg 9
execute if score @s ec.cf_codex_page matches 3 if score @s ec.cf_troph_pg matches 0 as @e[type=interaction,tag=CF.TrophyCl8,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s attack on target run function evercraft:craftforever/codex/hub/trophies/open_detail {pg:9}
execute if score @s ec.cf_codex_page matches 3 if score @s ec.cf_troph_pg matches 0 as @e[type=interaction,tag=CF.TrophyCl8,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute if score @s ec.cf_codex_page matches 3 if score @s ec.cf_troph_pg matches 0 as @e[type=interaction,tag=CF.TrophyCl8,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction
# id 9 CraftForever Star -> pg 10
execute if score @s ec.cf_codex_page matches 3 if score @s ec.cf_troph_pg matches 0 as @e[type=interaction,tag=CF.TrophyCl9,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s attack on target run function evercraft:craftforever/codex/hub/trophies/open_detail {pg:10}
execute if score @s ec.cf_codex_page matches 3 if score @s ec.cf_troph_pg matches 0 as @e[type=interaction,tag=CF.TrophyCl9,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute if score @s ec.cf_codex_page matches 3 if score @s ec.cf_troph_pg matches 0 as @e[type=interaction,tag=CF.TrophyCl9,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction
# id 10 Treasure Hunter -> pg 11
execute if score @s ec.cf_codex_page matches 3 if score @s ec.cf_troph_pg matches 0 as @e[type=interaction,tag=CF.TrophyCl10,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s attack on target run function evercraft:craftforever/codex/hub/trophies/open_detail {pg:11}
execute if score @s ec.cf_codex_page matches 3 if score @s ec.cf_troph_pg matches 0 as @e[type=interaction,tag=CF.TrophyCl10,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute if score @s ec.cf_codex_page matches 3 if score @s ec.cf_troph_pg matches 0 as @e[type=interaction,tag=CF.TrophyCl10,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction
# id 11 Expeditionist -> pg 12
execute if score @s ec.cf_codex_page matches 3 if score @s ec.cf_troph_pg matches 0 as @e[type=interaction,tag=CF.TrophyCl11,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s attack on target run function evercraft:craftforever/codex/hub/trophies/open_detail {pg:12}
execute if score @s ec.cf_codex_page matches 3 if score @s ec.cf_troph_pg matches 0 as @e[type=interaction,tag=CF.TrophyCl11,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute if score @s ec.cf_codex_page matches 3 if score @s ec.cf_troph_pg matches 0 as @e[type=interaction,tag=CF.TrophyCl11,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction
# id 12 Realm Champion -> pg 13
execute if score @s ec.cf_codex_page matches 3 if score @s ec.cf_troph_pg matches 0 as @e[type=interaction,tag=CF.TrophyCl12,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s attack on target run function evercraft:craftforever/codex/hub/trophies/open_detail {pg:13}
execute if score @s ec.cf_codex_page matches 3 if score @s ec.cf_troph_pg matches 0 as @e[type=interaction,tag=CF.TrophyCl12,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute if score @s ec.cf_codex_page matches 3 if score @s ec.cf_troph_pg matches 0 as @e[type=interaction,tag=CF.TrophyCl12,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction
# id 13 Spirit Forger -> pg 14
execute if score @s ec.cf_codex_page matches 3 if score @s ec.cf_troph_pg matches 0 as @e[type=interaction,tag=CF.TrophyCl13,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s attack on target run function evercraft:craftforever/codex/hub/trophies/open_detail {pg:14}
execute if score @s ec.cf_codex_page matches 3 if score @s ec.cf_troph_pg matches 0 as @e[type=interaction,tag=CF.TrophyCl13,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute if score @s ec.cf_codex_page matches 3 if score @s ec.cf_troph_pg matches 0 as @e[type=interaction,tag=CF.TrophyCl13,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction
# id 14 Guild Legend -> pg 15
execute if score @s ec.cf_codex_page matches 3 if score @s ec.cf_troph_pg matches 0 as @e[type=interaction,tag=CF.TrophyCl14,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s attack on target run function evercraft:craftforever/codex/hub/trophies/open_detail {pg:15}
execute if score @s ec.cf_codex_page matches 3 if score @s ec.cf_troph_pg matches 0 as @e[type=interaction,tag=CF.TrophyCl14,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute if score @s ec.cf_codex_page matches 3 if score @s ec.cf_troph_pg matches 0 as @e[type=interaction,tag=CF.TrophyCl14,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction

# === TROPHY DETAIL (cf_codex_page 3, cf_troph_pg 1..15): only the Back hitbox is live (right-click) ===
execute if score @s ec.cf_codex_page matches 3 unless score @s ec.cf_troph_pg matches 0 as @e[type=interaction,tag=CF.TrBackClick,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s interaction on target run function evercraft:craftforever/codex/hub/trophies/back_to_grid
execute if score @s ec.cf_codex_page matches 3 unless score @s ec.cf_troph_pg matches 0 as @e[type=interaction,tag=CF.TrBackClick,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction

# ===== INSPECT (left-click) — gui/inspect pattern 2026-06-11. Cards explain buttons; detail
# rows get attack-PARITY twins (punch opens the same detail a use does — companion doctrine). =====
execute as @e[type=interaction,tag=CF.TrBackClick,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Back",b:"Returns to the trophy grid."}
execute as @e[type=interaction,tag=CF.TrBackClick,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute if score @s ec.cf_codex_page matches 3 if score @s ec.cf_troph_pg matches 0 as @e[type=interaction,tag=CF.TrophyCl0,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute if score @s ec.cf_codex_page matches 3 if score @s ec.cf_troph_pg matches 0 as @e[type=interaction,tag=CF.TrophyCl1,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute if score @s ec.cf_codex_page matches 3 if score @s ec.cf_troph_pg matches 0 as @e[type=interaction,tag=CF.TrophyCl2,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute if score @s ec.cf_codex_page matches 3 if score @s ec.cf_troph_pg matches 0 as @e[type=interaction,tag=CF.TrophyCl3,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute if score @s ec.cf_codex_page matches 3 if score @s ec.cf_troph_pg matches 0 as @e[type=interaction,tag=CF.TrophyCl4,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute if score @s ec.cf_codex_page matches 3 if score @s ec.cf_troph_pg matches 0 as @e[type=interaction,tag=CF.TrophyCl5,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute if score @s ec.cf_codex_page matches 3 if score @s ec.cf_troph_pg matches 0 as @e[type=interaction,tag=CF.TrophyCl6,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute if score @s ec.cf_codex_page matches 3 if score @s ec.cf_troph_pg matches 0 as @e[type=interaction,tag=CF.TrophyCl7,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute if score @s ec.cf_codex_page matches 3 if score @s ec.cf_troph_pg matches 0 as @e[type=interaction,tag=CF.TrophyCl8,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute if score @s ec.cf_codex_page matches 3 if score @s ec.cf_troph_pg matches 0 as @e[type=interaction,tag=CF.TrophyCl9,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute if score @s ec.cf_codex_page matches 3 if score @s ec.cf_troph_pg matches 0 as @e[type=interaction,tag=CF.TrophyCl10,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute if score @s ec.cf_codex_page matches 3 if score @s ec.cf_troph_pg matches 0 as @e[type=interaction,tag=CF.TrophyCl11,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute if score @s ec.cf_codex_page matches 3 if score @s ec.cf_troph_pg matches 0 as @e[type=interaction,tag=CF.TrophyCl12,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute if score @s ec.cf_codex_page matches 3 if score @s ec.cf_troph_pg matches 0 as @e[type=interaction,tag=CF.TrophyCl13,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute if score @s ec.cf_codex_page matches 3 if score @s ec.cf_troph_pg matches 0 as @e[type=interaction,tag=CF.TrophyCl14,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s attack run data remove entity @s attack
