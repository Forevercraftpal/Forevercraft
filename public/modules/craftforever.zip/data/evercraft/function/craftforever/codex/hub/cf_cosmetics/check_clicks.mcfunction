# CF Cosmetics — Check Clicks
# Run as player, #cf_gui_owner ec.temp = session ID

execute as @e[type=interaction,tag=CF.CosClick0,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s interaction on target run function evercraft:craftforever/codex/hub/cf_cosmetics/click_tiers
execute as @e[type=interaction,tag=CF.CosClick0,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=CF.CosClick1,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s interaction on target run function evercraft:craftforever/codex/hub/cf_cosmetics/click_particles
execute as @e[type=interaction,tag=CF.CosClick1,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=CF.CosClick2,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s interaction on target run function evercraft:craftforever/codex/hub/cf_cosmetics/click_titles
execute as @e[type=interaction,tag=CF.CosClick2,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction

# ===== INSPECT (left-click) — gui/inspect pattern 2026-06-11. Cards explain buttons; detail
# rows get attack-PARITY twins (punch opens the same detail a use does — companion doctrine). =====
execute as @e[type=interaction,tag=CF.CosClick0,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Tier Cosmetics",b:"Opens the tier cosmetics — looks earned by rank."}
execute as @e[type=interaction,tag=CF.CosClick0,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=CF.CosClick1,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Particles",b:"Opens the particle cosmetics."}
execute as @e[type=interaction,tag=CF.CosClick1,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=CF.CosClick2,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Titles",b:"Opens the CraftForever titles."}
execute as @e[type=interaction,tag=CF.CosClick2,distance=..5] if score @s ec.cf_gui_session = #cf_gui_owner ec.temp if data entity @s attack run data remove entity @s attack
