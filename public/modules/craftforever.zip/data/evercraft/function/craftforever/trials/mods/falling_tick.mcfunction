# Trade Trial modifier — Falling hazard (bit 3): anvil / falling-block rain.
# Run as/at: the trial player, from mods/tick on the 2s cadence beat.
# Generalises mining/collapse into a per-player roaming hazard: drop a couple of anvils a few
# blocks above the player at slightly offset positions, so they must keep moving. Anvils that
# land become real blocks INSIDE the arena envelope -> fill_air cleans them at teardown; any
# in-flight falling_block is also killed in cleanup_player's arena-band sweep.
#
# Category flavour: mining = anvil (cave-in stone). Others fall back to a generic anvil too;
# wave 2-6 can branch on ec.tt_type here for a themed falling block (e.g. dripstone, ice).

# Two drop points a few blocks above and beside the player (~ = axis-aligned, predictable).
# Farming flavour (type 2): a hailstorm pelts the field — pointed dripstone "ice-shards"
# rain down instead of cave anvils. Same ec.tt_haz tag + envelope landing -> fill_air cleans.
# Wave 1 (Joseph 2026-06-10, actionbar-priority): every hazard paint below yields to the notify
# queue (`unless entity @s[tag=ab_q]`) — HUD convention. The 2s beat repaints it right after any
# queued frame drains, so the telegraph stays effectively continuous without stomping messages.
execute if score @s ec.tt_type matches 2 at @s run summon falling_block ~2 ~7 ~ {BlockState:{Name:"minecraft:pointed_dripstone"},Tags:["ec.tt_haz"],Time:1,DropItem:0b,HurtEntities:1b}
execute if score @s ec.tt_type matches 2 at @s run summon falling_block ~-2 ~7 ~1 {BlockState:{Name:"minecraft:pointed_dripstone"},Tags:["ec.tt_haz"],Time:1,DropItem:0b,HurtEntities:1b}
execute if score @s ec.tt_type matches 2 if score @s ec.fx_snd matches 2.. run playsound minecraft:weather.rain master @s ~ ~ ~ 0.6 0.8
execute if score @s ec.tt_type matches 2 unless entity @s[tag=ab_q] run title @s actionbar {"text":"⚠ Hail batters the fields! Keep moving!","color":"aqua"}
# Fishing flavour (type 3): a SQUALL whips the open water — chunks of squall ice crash down
# from the storm-cloud. blue_ice falling blocks land inside the envelope -> fill_air cleans.
execute if score @s ec.tt_type matches 3 at @s run summon falling_block ~2 ~7 ~ {BlockState:{Name:"minecraft:blue_ice"},Tags:["ec.tt_haz"],Time:1,DropItem:0b,HurtEntities:1b}
execute if score @s ec.tt_type matches 3 at @s run summon falling_block ~-2 ~7 ~1 {BlockState:{Name:"minecraft:blue_ice"},Tags:["ec.tt_haz"],Time:1,DropItem:0b,HurtEntities:1b}
execute if score @s ec.tt_type matches 3 if score @s ec.fx_snd matches 2.. run playsound minecraft:weather.rain.above master @s ~ ~ ~ 0.7 0.7
execute if score @s ec.tt_type matches 3 unless entity @s[tag=ab_q] run title @s actionbar {"text":"⚠ A squall hammers the water! Keep moving!","color":"aqua"}
# Building flavour (type 4): the SCAFFOLDING COLLAPSES — loose sand + gravel sluff off the
# overhead staging and rain onto the site. sand/gravel falling blocks land inside the envelope
# -> fill_air cleans them; HurtEntities so a careless builder takes the hit.
execute if score @s ec.tt_type matches 4 at @s run summon falling_block ~2 ~7 ~ {BlockState:{Name:"minecraft:sand"},Tags:["ec.tt_haz"],Time:1,DropItem:0b,HurtEntities:1b}
execute if score @s ec.tt_type matches 4 at @s run summon falling_block ~-2 ~7 ~1 {BlockState:{Name:"minecraft:gravel"},Tags:["ec.tt_haz"],Time:1,DropItem:0b,HurtEntities:1b}
execute if score @s ec.tt_type matches 4 if score @s ec.fx_snd matches 2.. run playsound minecraft:block.scaffolding.break master @s ~ ~ ~ 0.6 0.7
execute if score @s ec.tt_type matches 4 unless entity @s[tag=ab_q] run title @s actionbar {"text":"⚠ The scaffolding is collapsing! Keep moving!","color":"gold"}
# Lumber flavour (type 5): WIDOWMAKERS — dead boughs + sheared crowns break loose from the high
# canopy and crash down on the feller. Falling logs (the snapped trunk-section) land inside the
# envelope -> fill_air cleans them; HurtEntities so a careless feller takes the hit.
execute if score @s ec.tt_type matches 5 at @s run summon falling_block ~2 ~7 ~ {BlockState:{Name:"minecraft:oak_log"},Tags:["ec.tt_haz"],Time:1,DropItem:0b,HurtEntities:1b}
execute if score @s ec.tt_type matches 5 at @s run summon falling_block ~-2 ~7 ~1 {BlockState:{Name:"minecraft:spruce_log"},Tags:["ec.tt_haz"],Time:1,DropItem:0b,HurtEntities:1b}
execute if score @s ec.tt_type matches 5 if score @s ec.fx_snd matches 2.. run playsound minecraft:block.wood.break master @s ~ ~ ~ 0.7 0.6
execute if score @s ec.tt_type matches 5 unless entity @s[tag=ab_q] run title @s actionbar {"text":"⚠ Widowmakers fall from the canopy! Keep moving!","color":"dark_green"}
# Artisan flavour (type 6): FALLING SLAG + ANVILS — the overhead forge gantry sheds white-hot slag
# and a dropped anvil from the smithy crane. magma_block "slag" + a forge anvil land inside the
# envelope -> fill_air cleans them; HurtEntities so a careless smith takes the hit. Echoes the
# Grand Forge's anvil-land aesthetic (forge theme — the hottest part of the smithy is overhead).
execute if score @s ec.tt_type matches 6 at @s run summon falling_block ~2 ~7 ~ {BlockState:{Name:"minecraft:magma_block"},Tags:["ec.tt_haz"],Time:1,DropItem:0b,HurtEntities:1b}
execute if score @s ec.tt_type matches 6 at @s run summon falling_block ~-2 ~7 ~1 {BlockState:{Name:"minecraft:anvil"},Tags:["ec.tt_haz"],Time:1,DropItem:0b,HurtEntities:1b}
execute if score @s ec.tt_type matches 6 if score @s ec.fx_snd matches 2.. run playsound minecraft:block.anvil.land master @s ~ ~ ~ 0.5 0.7
execute if score @s ec.tt_type matches 6 unless entity @s[tag=ab_q] run title @s actionbar {"text":"⚠ Slag and anvils fall from the forge gantry! Keep moving!","color":"gold"}
# Default (mining + any category with no flavour): anvil cave-in.
execute unless score @s ec.tt_type matches 2 unless score @s ec.tt_type matches 3 unless score @s ec.tt_type matches 4 unless score @s ec.tt_type matches 5 unless score @s ec.tt_type matches 6 at @s run summon falling_block ~2 ~7 ~ {BlockState:{Name:"minecraft:anvil"},Tags:["ec.tt_haz"],Time:1,DropItem:0b,HurtEntities:1b}
execute unless score @s ec.tt_type matches 2 unless score @s ec.tt_type matches 3 unless score @s ec.tt_type matches 4 unless score @s ec.tt_type matches 5 unless score @s ec.tt_type matches 6 at @s run summon falling_block ~-2 ~7 ~1 {BlockState:{Name:"minecraft:anvil"},Tags:["ec.tt_haz"],Time:1,DropItem:0b,HurtEntities:1b}
execute unless score @s ec.tt_type matches 2 unless score @s ec.tt_type matches 3 unless score @s ec.tt_type matches 4 unless score @s ec.tt_type matches 5 unless score @s ec.tt_type matches 6 if score @s ec.fx_snd matches 2.. run playsound minecraft:block.anvil.land master @s ~ ~ ~ 0.4 0.6
execute unless score @s ec.tt_type matches 2 unless score @s ec.tt_type matches 3 unless score @s ec.tt_type matches 4 unless score @s ec.tt_type matches 5 unless score @s ec.tt_type matches 6 unless entity @s[tag=ab_q] run title @s actionbar {"text":"⚠ Falling rocks! Keep moving!","color":"red"}
