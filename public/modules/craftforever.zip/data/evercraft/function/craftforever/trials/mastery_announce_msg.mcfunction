# Mastery announcement (actor-naming @a broadcast \u2014 \u00a75b direct render, macro)
# (Wave 2, 2026-06-10: mastery brag — whoami-baked, protected, 30s TTL.)
function evercraft:util/notify/whoami
$data modify storage evercraft:notify stage.c set value [{text:"\u2726\u2726\u2726 ",color:"gold"},{text:"",color:"yellow",bold:true},{text:" has achieved ",color:"gray"},{text:"$(mastery_name) MASTERY",color:"gold",bold:true},{text:"! \u2726\u2726\u2726",color:"gold"}]
data modify storage evercraft:notify stage.c[1].text set from storage evercraft:notify named.who
scoreboard players set #ndur ec.temp 50
execute as @a run scoreboard players set #nttl ec.temp 600
execute as @a run function evercraft:util/notify/emit_keep
