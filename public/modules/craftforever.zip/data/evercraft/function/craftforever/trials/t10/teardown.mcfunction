# Trade Trial — T10 INSTANCE TEARDOWN (castle p$(pid) adoption)
# Run as/at: the trial player, from cleanup_player (only matters for a T10 run; a no-op
# otherwise since ec.tt_pid=0 and no p$(pid)/anchor exist). Mirrors castle cleanup rigor:
# remove the per-instance tag and kill the per-instance anchor marker. The zone BLOCKS are
# cleared by the standard fill_air (the zone fits the arena envelope). Any pending mining
# collapse schedule self-gates on #tt_active, which cleanup_player drops, so it no-ops.

# Stash this player's pid for the macros.
execute store result storage evercraft:trials pid int 1 run scoreboard players get @s ec.tt_pid

# Kill THIS instance's anchor marker + drop the tag (scoped by p$(pid) — never another instance).
execute if score @s ec.tt_pid matches 1.. run function evercraft:craftforever/trials/t10/kill_anchor with storage evercraft:trials
execute if score @s ec.tt_pid matches 1.. run function evercraft:craftforever/trials/t10/untag_player with storage evercraft:trials

# Reset the instance scores.
scoreboard players set @s ec.tt_pid 0
scoreboard players set @s ec.tt_zone 0
