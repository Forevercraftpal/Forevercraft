# Trial Pass — Right-click to open trial GUI remotely
# Triggered by using_item advancement (fires every tick while right-click held).
# Pass is NOT consumed by vanilla — consume_seconds on the item is 32767, the player
# releases right-click long before that. Consumption happens in trials/start.mcfunction
# when the player actually clicks "Start Trial" in the menu.

# Revoke so this can trigger again on next right-click
advancement revoke @s only evercraft:craftforever/use_trial_pass

# Debounce — using_item fires every tick. If we just opened (cooldown active), skip.
execute if entity @s[tag=TT.PassOpenCD] run return 0

# If already in the trial menu, no-op (don't toggle-close on every tick of right-click)
execute if entity @s[tag=TT.InMenu] run return 0

# Brief cooldown so the next 10t of using_item ticks don't re-fire
tag @s add TT.PassOpenCD
schedule function evercraft:craftforever/trials/clear_pass_cd 10t append

# Mark this menu session as pass-opened so trial_anvil/gui/tick.mcfunction
# skips the "must be near a TT.Marker" auto-close check.
tag @s add TT.OpenedByPass

# Open the trial GUI
function evercraft:craftforever/trial_anvil/gui/open
