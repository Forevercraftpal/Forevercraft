# Trade Trial modifier — Parkour (bit 8): build a short traversal course.
# Run as/at: the trial player, from mods/apply (on start).
# Builds a small floating jump trail just off the spawn platform, inside the arena envelope
# (offset 0..47, Y300..324) so fill_air clears it at teardown — no extra cleanup needed.
# The course is a set of single-block stepping stones the player must hop across; it adds
# depth/traversal without a hard gate (failing just costs time, not the run).
#
# Category flavour: mining = stone bricks over a gap. Wave 2-6 can reskin the block on ec.tt_type.
execute store result storage evercraft:trials px int 1 run scoreboard players get @s ec.tt_arena_x
execute store result storage evercraft:trials pz int 1 run scoreboard players get @s ec.tt_arena_z
function evercraft:craftforever/trials/mods/parkour_fill with storage evercraft:trials
