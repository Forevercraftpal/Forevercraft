# Fishing Trial T10 — Leviathan's Pool (4 blocks deep)
# Depth capped at 4 (Y=300-303) so the player never spawns submerged.
# Macro file — run with storage evercraft:trials

$execute positioned $(ax) 300 $(az) run fill ~2 ~ ~2 ~46 ~3 ~46 water

# Kelp and seagrass throughout
$execute positioned $(ax) 300 $(az) run fill ~5 ~ ~5 ~15 ~3 ~15 kelp replace water
$execute positioned $(ax) 300 $(az) run fill ~30 ~ ~30 ~42 ~3 ~42 kelp replace water
$execute positioned $(ax) 300 $(az) run fill ~5 ~ ~30 ~15 ~ ~42 seagrass replace water
$execute positioned $(ax) 300 $(az) run fill ~30 ~ ~5 ~42 ~ ~15 seagrass replace water
