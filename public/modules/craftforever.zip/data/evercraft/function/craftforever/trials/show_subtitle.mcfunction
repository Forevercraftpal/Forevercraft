# Show trial tier subtitle (macro)
# (AB-1 sticky-times sweep 2026-06-10: explicit stamp — `title times` is sticky per player and this sequence set none, so it inherited whatever ran last.)
title @s times 10 60 20
$title @s subtitle [{"text":"$(trial_name) Tier $(tier)","color":"#FFA500"}]
