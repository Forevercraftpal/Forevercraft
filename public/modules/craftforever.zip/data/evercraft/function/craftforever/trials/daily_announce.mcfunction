# Trade Trial — Daily Announcement
# Macro: called with storage evercraft:trials
# Announces the new daily trade trial to all players

# Static @a broadcast (\u00a75 staged fan-out, macro)
$data modify storage evercraft:notify stage.c set value [{text:"Today's Trade Trial: ",color:"yellow"},{text:"$(trial_name)",color:"aqua",bold:true},{text:" \u2014 $(trial_desc)",color:"gray"}]
scoreboard players set #ndur ec.temp 50
execute as @a run function evercraft:util/notify/emit
