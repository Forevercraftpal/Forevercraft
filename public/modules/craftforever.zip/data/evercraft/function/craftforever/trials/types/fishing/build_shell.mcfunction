# Fishing Trial — Shell (HOLLOW 48x25x48 stone box at Y=299-324)
# Macro file — run with storage evercraft:trials
# The interior MUST be air above the water line. A solid fill capped the 4-deep lake
# with stone at Y=304 (no air to surface into) — you spawned in the water under a stone
# lid and drowned, and there was no open air over the water to cast into. Hollowing it
# also lets the ceiling lights actually illuminate the arena.

# Floor at Y=299
# Floor: sandy lakebed (Y=299) — visible through the clear water
$execute positioned $(ax) 299 $(az) run fill ~ ~ ~ ~47 ~ ~47 sandstone
$execute positioned $(ax) 299 $(az) run fill ~6 ~ ~8 ~16 ~ ~18 clay
$execute positioned $(ax) 299 $(az) run fill ~28 ~ ~30 ~40 ~ ~42 dirt
$execute positioned $(ax) 299 $(az) run fill ~20 ~ ~5 ~27 ~ ~12 clay
# Interior air (Y=300-323, split for the 32768 fill limit)
$execute positioned $(ax) 300 $(az) run fill ~ ~ ~ ~47 ~7 ~47 air
$execute positioned $(ax) 308 $(az) run fill ~ ~ ~ ~47 ~7 ~47 air
$execute positioned $(ax) 316 $(az) run fill ~ ~ ~ ~47 ~7 ~47 air
# Walls (stone shell, 1 block thick, Y=300-323)
$execute positioned $(ax) 300 $(az) run fill ~ ~ ~ ~47 ~23 ~ stone
$execute positioned $(ax) 300 $(az) run fill ~ ~ ~47 ~47 ~23 ~47 stone
$execute positioned $(ax) 300 $(az) run fill ~ ~ ~ ~ ~23 ~47 stone
$execute positioned $(ax) 300 $(az) run fill ~47 ~ ~ ~47 ~23 ~47 stone
# Ceiling: organic frame ring at Y=324, open center to the sky
$execute positioned $(ax) 324 $(az) run fill ~ ~ ~ ~47 ~ ~47 prismarine
$execute positioned $(ax) 324 $(az) run fill ~5 ~ ~5 ~42 ~ ~42 sea_lantern
$execute positioned $(ax) 324 $(az) run fill ~6 ~ ~6 ~41 ~ ~41 air
# Invisible barrier shell — full containment (no falling out / breaking through any block).
# Barriers transmit light + sky, so the open ceilings still read as open. Box: (-1,298,-1)->(48,325,48).
$execute positioned $(ax) 298 $(az) run fill ~-1 ~ ~-1 ~48 ~ ~48 barrier
$execute positioned $(ax) 325 $(az) run fill ~-1 ~ ~-1 ~48 ~ ~48 barrier
$execute positioned $(ax) 298 $(az) run fill ~-1 ~ ~-1 ~48 ~27 ~-1 barrier
$execute positioned $(ax) 298 $(az) run fill ~-1 ~ ~48 ~48 ~27 ~48 barrier
$execute positioned $(ax) 298 $(az) run fill ~-1 ~ ~-1 ~-1 ~27 ~48 barrier
$execute positioned $(ax) 298 $(az) run fill ~48 ~ ~-1 ~48 ~27 ~48 barrier
