# Trade Trial modifier — Blackout (bit 5): the arena lights periodically go out.
# Run as/at: the trial player, from mods/tick on the 2s cadence beat.
# Shared mechanic: every other beat (~4s) the lights "fail" — a short blindness pulse + an
# extinguish sound — then they flicker back. The player works in stutter-darkness. We use the
# hazard cadence parity so two adjacent env beats don't both fire (cheap, no extra objective).
#
# Category flavour: mining = cave-lamps failing. Farming (type 2) = a storm-cloud rolling over
# the field (same blindness pulse, reskinned to a thunderhead darkening the rows). Fishing
# (type 3) = murky silt clouding the pool (same blindness pulse, reskinned to roiled water).

# Only fire on even cadence cycles so it pulses ~every 4s, not every 2s (less punishing).
# Reusing ec.tt_haz_y as a parity counter is SAFE: the env-exclusion rule (bits 3/4/5 pick at
# most one per run) guarantees creeping-lava (which owns ec.tt_haz_y) is never co-active.
# Wave 1 (Joseph 2026-06-10, actionbar-priority): every hazard paint below yields to the notify
# queue (`unless entity @s[tag=ab_q]`) — HUD convention. The 2s beat repaints it right after any
# queued frame drains, so the telegraph stays effectively continuous without stomping messages.
scoreboard players operation #tt_bo ec.var = @s ec.tt_haz_y
scoreboard players add @s ec.tt_haz_y 1
scoreboard players operation #tt_bo ec.var %= #2 ec.const
execute unless score #tt_bo ec.var matches 0 run return 0

effect give @s minecraft:blindness 3 0 true
# Farming: a thunderhead rolls over. Fishing: silt roils up and clouds the water.
# Default (mining/etc.): the lamps fail.
execute if score @s ec.tt_type matches 2 if score @s ec.fx_snd matches 2.. run playsound minecraft:entity.lightning_bolt.thunder master @s ~ ~ ~ 0.5 1.2
execute if score @s ec.tt_type matches 2 unless entity @s[tag=ab_q] run title @s actionbar {"text":"☼ A storm cloud darkens the field…","color":"dark_gray"}
execute if score @s ec.tt_type matches 3 if score @s ec.fx_snd matches 2.. run playsound minecraft:ambient.underwater.loop master @s ~ ~ ~ 0.7 0.8
execute if score @s ec.tt_type matches 3 unless entity @s[tag=ab_q] run title @s actionbar {"text":"☼ Silt clouds the water…","color":"dark_gray"}
# Building: the work-site lamps cut out. Same blindness pulse, reskinned to the blueprint lamps
# going dark across the staging — the builder must place from memory until the power flickers back.
execute if score @s ec.tt_type matches 4 if score @s ec.fx_snd matches 2.. run playsound minecraft:block.fire.extinguish master @s ~ ~ ~ 0.6 0.6
execute if score @s ec.tt_type matches 4 unless entity @s[tag=ab_q] run title @s actionbar {"text":"☼ The blueprint lamps go dark…","color":"dark_gray"}
# Lumber: the DENSE CANOPY closes over. Same blindness pulse, reskinned to the old-growth crowns
# knitting shut overhead so no light reaches the forest floor until a gust parts them again.
execute if score @s ec.tt_type matches 5 if score @s ec.fx_snd matches 2.. run playsound minecraft:block.azalea_leaves.fall master @s ~ ~ ~ 0.7 0.7
execute if score @s ec.tt_type matches 5 unless entity @s[tag=ab_q] run title @s actionbar {"text":"☼ The canopy closes over — the forest floor goes dark…","color":"dark_gray"}
# Artisan: the FORGE FIRES GUTTER OUT. Same blindness pulse, reskinned to the bellows failing —
# the smithy fires die down to dull coals and the workshop goes dark until they roar back up.
execute if score @s ec.tt_type matches 6 if score @s ec.fx_snd matches 2.. run playsound minecraft:block.fire.extinguish master @s ~ ~ ~ 0.7 0.5
execute if score @s ec.tt_type matches 6 unless entity @s[tag=ab_q] run title @s actionbar {"text":"☼ The forge fires gutter out — the smithy goes dark…","color":"dark_gray"}
execute unless score @s ec.tt_type matches 2 unless score @s ec.tt_type matches 3 unless score @s ec.tt_type matches 4 unless score @s ec.tt_type matches 5 unless score @s ec.tt_type matches 6 if score @s ec.fx_snd matches 2.. run playsound minecraft:block.fire.extinguish master @s ~ ~ ~ 0.6 0.7
execute unless score @s ec.tt_type matches 2 unless score @s ec.tt_type matches 3 unless score @s ec.tt_type matches 4 unless score @s ec.tt_type matches 5 unless score @s ec.tt_type matches 6 unless entity @s[tag=ab_q] run title @s actionbar {"text":"☼ The lights flicker out…","color":"dark_gray"}
