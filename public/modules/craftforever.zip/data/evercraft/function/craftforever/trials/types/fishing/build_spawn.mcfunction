# Fishing Trial — Dry dock at arena center (player spawns at center, Y=303)
# Macro file — run with storage evercraft:trials
# Runs AFTER the tier water fill (build_arena PHASE 3). All fishing tiers are
# 4 blocks deep (water Y=300-303), so the dock keeps the spawn pocket dry:
#   - solid plank platform Y=300-302 (top at 302) -> player lands at Y=303
#   - plank retaining rim at Y=303 holds the surrounding lake back; interior carved to air
#   - fence railing at Y=304 for a dock feel
# Without this the player spawned submerged on a sunken dock and drowned.

# Dock platform: solid oak planks, top at Y=302 (player stands at Y=303)
$execute positioned $(ax) 300 $(az) run fill ~20 ~ ~20 ~28 ~2 ~28 oak_planks

# Foot-level retaining rim at Y=303, then hollow the interior to dry air.
# The 1-wide plank rim (offset 19 & 29) holds the 4-deep lake out of the spawn pocket.
$execute positioned $(ax) 303 $(az) run fill ~19 ~ ~19 ~29 ~ ~29 oak_planks
$execute positioned $(ax) 303 $(az) run fill ~20 ~ ~20 ~28 ~ ~28 air

# Fence railing on the rim (Y=304) for a dock look; interior stays open air for casting
$execute positioned $(ax) 304 $(az) run fill ~19 ~ ~19 ~29 ~ ~29 oak_fence
$execute positioned $(ax) 304 $(az) run fill ~20 ~ ~20 ~28 ~ ~28 air
