# Artisan T10 themed zone — geometry (macro)
# Called: function .../artisan/build_t10_zone_fill with storage evercraft:trials  (zx,zz set)
# All offsets stay inside the arena envelope (0..47, Y300..324) and the fill_air sweep clears
# Y298..325 -> every block here is torn down by the standard teardown (no per-zone teardown).
#
# The base build_t10 laid the massive workshop on the FLOOR (sheep/cobweb/flowers Y300..305 across
# offset 2..46) + the spawn platform pocket (offset 22..26, Y300..303). This zone ADDS, in the OPEN
# AIR BAND ABOVE that floor (Y306+, below the Y324 ceiling ring), a GRAND-FORGE smithy reach:
#   * a SCAFFOLD CLIMB beside spawn rising to the forge catwalk (bottom=true, self-supporting),
#   * a RAISED FORGE MEZZANINE of blackstone with an open LAVA CHANNEL cut through it (the molten
#     smelt-bath the catwalk leaps over),
#   * a FORGE-PLATFORM LEAP PARKOUR of solid blackstone/anvil platforms across the lava channel gap
#     (no support deps; a missed jump drops to the floor workshop below — costs time, not the run),
#   * DECOY CRAFTING STATIONS — smithing tables / blast furnaces / grindstones / stonecutters that
#     read as prime work-stations but are NOT counted materials (the artisan scorer counts only
#     wool/string/cobweb/flowers, so harvesting a station scores nothing — scorer-invisible decoys),
#   * the real MASTER FORGE on a raised deck across the channel (a clean forge terrace stocked with
#     prime wool-sheep + cobweb + flower beds — the uncontested prime materials the parkour earns),
#     with a topping-out forge beacon.
# The central spawn pocket (offset 22..26) is left clear so the player still drops to the floor
# workshop. Scoring is the existing material delta (artisan/track_t10) — the zone only moves the
# BEST, uncontested materials up onto the master-forge deck behind the gap; it never changes how a
# gathered material is counted.

# === SCAFFOLD CLIMB — a supported scaffolding tower rising from the floor (Y300) beside the spawn
# pocket up to the forge-catwalk start (~Y307). bottom=true anchors the base so the column
# self-supports. Two offset rungs give a readable climbing route up to the mezzanine. ===
$execute positioned $(zx) 300 $(zz) run fill ~29 ~ ~22 ~29 ~7 ~22 scaffolding[bottom=true]
$execute positioned $(zx) 300 $(zz) run fill ~31 ~ ~25 ~31 ~8 ~25 scaffolding[bottom=true]

# === RAISED FORGE MEZZANINE + LAVA CHANNEL — a blackstone forge deck floating at Y306 in the SE
# half (offset 28..46 x 28..46), with an open lava channel (the smelt-bath) cut through its middle.
# The catwalk parkour leaps the channel to reach the master forge beyond it. The blackstone reads as
# the Grand Forge's hearth-stone; gilded accents echo the forge's gold aesthetic. Lava sits inside
# the envelope -> fill_air clears it (no orphaned fluid). ===
$execute positioned $(zx) 306 $(zz) run fill ~28 ~ ~28 ~46 ~ ~46 blackstone
$execute positioned $(zx) 306 $(zz) run fill ~30 ~ ~36 ~44 ~ ~38 lava replace blackstone
$execute positioned $(zx) 306 $(zz) run fill ~30 ~ ~33 ~44 ~ ~33 gilded_blackstone replace blackstone
$execute positioned $(zx) 306 $(zz) run fill ~30 ~ ~41 ~44 ~ ~41 gilded_blackstone replace blackstone
# Forge furnaces lit along the near edge of the mezzanine (cosmetic hearth — lit blast furnaces).
$execute positioned $(zx) 307 $(zz) run setblock ~31 ~ ~33 blast_furnace[facing=north,lit=true]
$execute positioned $(zx) 307 $(zz) run setblock ~37 ~ ~33 blast_furnace[facing=north,lit=true]
$execute positioned $(zx) 307 $(zz) run setblock ~43 ~ ~33 blast_furnace[facing=north,lit=true]

# === DECOY CRAFTING STATIONS — a row of prime-looking work-stations on the NEAR mezzanine ledge
# (Y307, before the lava channel) that LOOK like the workshop's catalyst benches but yield NOTHING
# the scorer counts (smithing table / blast furnace / grindstone / stonecutter / anvil are not
# wool/string/cobweb/flowers). A smith who stops to "work" them loses time. They sit on the near
# side so the player must pass them to reach the channel — pure distraction. ===
$execute positioned $(zx) 307 $(zz) run setblock ~30 ~ ~30 smithing_table
$execute positioned $(zx) 307 $(zz) run setblock ~33 ~ ~30 grindstone
$execute positioned $(zx) 307 $(zz) run setblock ~36 ~ ~30 stonecutter
$execute positioned $(zx) 307 $(zz) run setblock ~39 ~ ~30 smithing_table
$execute positioned $(zx) 307 $(zz) run setblock ~42 ~ ~30 anvil
$execute positioned $(zx) 307 $(zz) run setblock ~45 ~ ~30 grindstone

# === FORGE-PLATFORM LEAP PARKOUR — solid blackstone/anvil/chiseled platforms strung from the
# scaffold top (Y307) out across the OPEN LAVA CHANNEL to the master-forge deck. Solid blocks (no
# gravity/support dependency). Spacing is jumpable; a missed jump drops to the floor workshop below
# (costs time, not the run). Platforms rise Y308 -> Y314 to read as climbing across the forge to the
# high master deck. The anvils mid-course echo the Grand Forge's anvil-land aesthetic. ===
$execute positioned $(zx) 308 $(zz) run setblock ~31 ~ ~26 polished_blackstone
$execute positioned $(zx) 308 $(zz) run setblock ~32 ~ ~29 chiseled_polished_blackstone
$execute positioned $(zx) 309 $(zz) run setblock ~33 ~ ~32 anvil
$execute positioned $(zx) 310 $(zz) run setblock ~35 ~ ~35 polished_blackstone
$execute positioned $(zx) 311 $(zz) run setblock ~37 ~ ~37 chiseled_polished_blackstone
$execute positioned $(zx) 312 $(zz) run setblock ~39 ~ ~39 anvil
$execute positioned $(zx) 313 $(zz) run setblock ~41 ~ ~41 polished_blackstone
$execute positioned $(zx) 314 $(zz) run setblock ~43 ~ ~43 chiseled_polished_blackstone

# === MASTER FORGE DECK — the real raised platform across the lava channel (Y315 deck, far SE
# corner). A clean gilded-blackstone forge terrace ringed by a low blackstone-wall rim, stocked with
# the PRIME, uncontested materials the parkour earns: a small pen of prime wool-sheep, a cluster of
# cobwebs, and dense flower beds (every flower type the scorer counts). Gathering these counts
# exactly like the floor workshop (the scorer is global); this is simply the prime, untouched stand.
# Kept inside the envelope (offset to ~45, deck Y315, content to ~Y318). ===
$execute positioned $(zx) 315 $(zz) run fill ~38 ~ ~38 ~45 ~ ~45 gilded_blackstone
$execute positioned $(zx) 316 $(zz) run fill ~38 ~ ~38 ~45 ~ ~38 blackstone_wall
$execute positioned $(zx) 316 $(zz) run fill ~38 ~ ~45 ~45 ~ ~45 blackstone_wall
$execute positioned $(zx) 316 $(zz) run fill ~38 ~ ~38 ~38 ~ ~45 blackstone_wall
$execute positioned $(zx) 316 $(zz) run fill ~45 ~ ~38 ~45 ~ ~45 blackstone_wall

# Prime wool-sheep pen (4 sheep — prime, uncontested wool; same ec.tt_mob tag -> cleanup kill sweep).
$execute positioned $(zx) 316 $(zz) run summon sheep ~40 ~ ~40 {"Tags":["ec.tt_mob"]}
$execute positioned $(zx) 316 $(zz) run summon sheep ~43 ~ ~40 {"Tags":["ec.tt_mob"]}
$execute positioned $(zx) 316 $(zz) run summon sheep ~40 ~ ~43 {"Tags":["ec.tt_mob"]}
$execute positioned $(zx) 316 $(zz) run summon sheep ~43 ~ ~43 {"Tags":["ec.tt_mob"]}
# Prime cobweb cluster (counted material) raised over the deck.
$execute positioned $(zx) 317 $(zz) run setblock ~41 ~ ~41 cobweb
$execute positioned $(zx) 317 $(zz) run setblock ~42 ~ ~42 cobweb
$execute positioned $(zx) 318 $(zz) run setblock ~41 ~ ~42 cobweb
# Prime flower beds on the deck (every counted flower type — poppy/dandelion/blue_orchid/allium/
# red_tulip/lily_of_the_valley). Placed on the gilded deck (flowers don't need grass on a setblock).
$execute positioned $(zx) 316 $(zz) run setblock ~39 ~ ~39 poppy
$execute positioned $(zx) 316 $(zz) run setblock ~44 ~ ~39 dandelion
$execute positioned $(zx) 316 $(zz) run setblock ~39 ~ ~44 blue_orchid
$execute positioned $(zx) 316 $(zz) run setblock ~44 ~ ~44 allium
$execute positioned $(zx) 316 $(zz) run setblock ~41 ~ ~39 red_tulip
$execute positioned $(zx) 316 $(zz) run setblock ~42 ~ ~44 lily_of_the_valley

# === TOPPING-OUT FORGE BEACON — a gilded-blackstone + lantern pillar on the master deck marking the
# prime forge (the "master's mark" the high deck promises). Soul-lantern (forge-blue flame) atop the
# short pillar over a lit furnace. Cosmetic; the material delta is still the only scorer. ===
$execute positioned $(zx) 316 $(zz) run fill ~44 ~ ~41 ~44 ~2 ~41 gilded_blackstone
$execute positioned $(zx) 319 $(zz) run setblock ~44 ~ ~41 soul_lantern[hanging=false]

# === LIGHTS — keep the catwalk + master deck readable even under the Blackout forge-fires-gutter
# pulse. A floating sea-lantern over a mid platform (off to the side, clear of the parkour line) +
# a light block above the master deck (clear of the beacon pillar at offset 44,41). ===
$execute positioned $(zx) 312 $(zz) run setblock ~35 ~ ~32 sea_lantern
$execute positioned $(zx) 318 $(zz) run setblock ~40 ~ ~43 light[level=15]
