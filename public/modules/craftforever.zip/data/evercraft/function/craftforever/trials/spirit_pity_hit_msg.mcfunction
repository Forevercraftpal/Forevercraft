# Spirit-Tool Pity — celebratory drop line (MACRO). Run as @s.
#   storage evercraft:trials sp.tool = display name of the spirit tool ("Earthsong", ...)
$data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"$(tool)",color:"gold",bold:true},{text:" — the Spirit Tool answers your craft!",color:"yellow"}]
scoreboard players set #ndur ec.temp 60
function evercraft:util/notify/emit
