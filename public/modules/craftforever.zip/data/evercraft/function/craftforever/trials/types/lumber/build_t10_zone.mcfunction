# Lumber T10 — THEMED INSTANCED ZONE (Craft-Trial Complexity Ladder, Wave 5)
# Run as/at: the trial player, from t10/build_zone (T10 only, AFTER build_t10 laid the base
# dense ancient forest — massive oak/dark-oak/spruce/jungle/birch/acacia/mangrove/cherry trees
# rising Y301..312 across the floor). This ADDS a castle-style multi-room depth on top of
# lumber's signature chop-500-logs: a FOREST-CANOPY zone — a BRANCH-WALK + LEAP PARKOUR across
# log/leaf beams strung through the open air ABOVE the existing crowns (Y314+), DECOY FAKE-TREES
# (hollow leaf-clad posts that READ as fellable timber but are decoration — chopping them scores
# nothing), and the real PRIME OLD-GROWTH GROVE across the canopy gap (a raised platform of
# extra-tall, untouched giants — the uncontested prime timber the parkour earns).
# Authored to fit the arena envelope (offset 0..47, Y300..323, all cleared by the standard
# fill_air sweep over Y298..325) so the standard teardown clears it — no per-zone teardown.
#
# Modeled on types/building/build_t10_zone + types/fishing/build_t10_zone (the Wave-3/4 reference).
# Uses the scaffolding bottom=true floor-support + solid-log/leaf beam idiom (no gravity/support-
# dependent floating blocks) the Building wave proved for the canopy walk. Keeps lumber's reward +
# the 2% catalyst roll (in lumber/reward) untouched. The scorer is the existing per-tick log delta
# (lumber/track_t10: sum of all 8 log-type stat deltas - ec.tt_snap) — honest "you must CHOP" —
# the zone only changes WHERE the best, uncontested timber stands, never how scoring works.

execute store result storage evercraft:trials zx int 1 run scoreboard players get @s ec.tt_arena_x
execute store result storage evercraft:trials zz int 1 run scoreboard players get @s ec.tt_arena_z
function evercraft:craftforever/trials/types/lumber/build_t10_zone_fill with storage evercraft:trials

# Themed intro title — the player arrives onto an instanced old-growth canopy.
title @s times 5 30 10
title @s subtitle {"text":"The old-growth canopy rises above you…","color":"dark_green"}
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.azalea_leaves.place master @s ~ ~ ~ 1 0.8
