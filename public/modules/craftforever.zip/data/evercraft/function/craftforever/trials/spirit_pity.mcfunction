# Spirit-Tool Pity — dispatcher (run as/at @s = the player, ONLY on a T10 clear).
# Joseph 2026-06-06: each successful GRAND (T10) clear of a category bumps that category's
# spirit-tool drop odds by +1 percentage point (cumulative bad-luck protection on the 5%
# base). On the clear that DOES drop, that category's pity resets to 0.
#
# This function is the SOLE writer of the 6 ec.tt_sp_pity1..6 objectives (one-writer law):
# it copies the active category's accrued pity into the shared #sp_pity ec.var, runs the
# category-agnostic roll worker (which leaves #sp_pity = pity+1 on a miss, 0 on a hit), then
# copies #sp_pity back into that category's objective.
#
# Caller: complete.mcfunction, gated on `ec.tt_tier matches 10` (grand trial only — NOT T1-9).
# ec.tt_type: 1 mining / 2 farming / 3 fishing / 4 building / 5 lumber / 6 artisan.

# Already-owned check: if the player already carries this category's spirit tool ANYWHERE in
# their inventory, skip the roll AND skip accruing pity. Spirit tools are unique GOD-TIER
# items — a spare adds nothing, and letting pity climb while owned would just dump a duplicate
# the next clear. (Simplest correct behavior; matches the "you have it, you're done" intent.)
tag @s remove ec.tt_sp_owned
execute if score @s ec.tt_type matches 1 if items entity @s container.* *[custom_data~{spirit_tool:"earthsong"}] run tag @s add ec.tt_sp_owned
execute if score @s ec.tt_type matches 2 if items entity @s container.* *[custom_data~{spirit_tool:"bloomweaver"}] run tag @s add ec.tt_sp_owned
execute if score @s ec.tt_type matches 3 if items entity @s container.* *[custom_data~{spirit_tool:"tidecaller"}] run tag @s add ec.tt_sp_owned
execute if score @s ec.tt_type matches 4 if items entity @s container.* *[custom_data~{spirit_tool:"dustwalker"}] run tag @s add ec.tt_sp_owned
execute if score @s ec.tt_type matches 5 if items entity @s container.* *[custom_data~{spirit_tool:"heartwood"}] run tag @s add ec.tt_sp_owned
execute if score @s ec.tt_type matches 6 if items entity @s container.* *[custom_data~{spirit_tool:"silkgrasp"}] run tag @s add ec.tt_sp_owned
execute if entity @s[tag=ec.tt_sp_owned] run return 0

# Copy this category's accrued pity → #sp_pity (the worker reads/writes this fake).
execute if score @s ec.tt_type matches 1 run scoreboard players operation #sp_pity ec.var = @s ec.tt_sp_pity1
execute if score @s ec.tt_type matches 2 run scoreboard players operation #sp_pity ec.var = @s ec.tt_sp_pity2
execute if score @s ec.tt_type matches 3 run scoreboard players operation #sp_pity ec.var = @s ec.tt_sp_pity3
execute if score @s ec.tt_type matches 4 run scoreboard players operation #sp_pity ec.var = @s ec.tt_sp_pity4
execute if score @s ec.tt_type matches 5 run scoreboard players operation #sp_pity ec.var = @s ec.tt_sp_pity5
execute if score @s ec.tt_type matches 6 run scoreboard players operation #sp_pity ec.var = @s ec.tt_sp_pity6

# Set the macro args (loot-table folder + spirit-tool display name) for the active category.
execute if score @s ec.tt_type matches 1 run data modify storage evercraft:trials sp set value {cat:"mining",tool:"Earthsong"}
execute if score @s ec.tt_type matches 2 run data modify storage evercraft:trials sp set value {cat:"farming",tool:"Bloomweaver"}
execute if score @s ec.tt_type matches 3 run data modify storage evercraft:trials sp set value {cat:"fishing",tool:"Tidecaller's Line"}
execute if score @s ec.tt_type matches 4 run data modify storage evercraft:trials sp set value {cat:"building",tool:"Dustwalker"}
execute if score @s ec.tt_type matches 5 run data modify storage evercraft:trials sp set value {cat:"lumber",tool:"Heartwood"}
execute if score @s ec.tt_type matches 6 run data modify storage evercraft:trials sp set value {cat:"artisan",tool:"Silkgrasp"}

# Run the roll (drops on hit, climbs pity on miss; mutates #sp_pity).
function evercraft:craftforever/trials/spirit_pity_roll with storage evercraft:trials sp

# Persist the new pity back into this category's objective.
execute if score @s ec.tt_type matches 1 run scoreboard players operation @s ec.tt_sp_pity1 = #sp_pity ec.var
execute if score @s ec.tt_type matches 2 run scoreboard players operation @s ec.tt_sp_pity2 = #sp_pity ec.var
execute if score @s ec.tt_type matches 3 run scoreboard players operation @s ec.tt_sp_pity3 = #sp_pity ec.var
execute if score @s ec.tt_type matches 4 run scoreboard players operation @s ec.tt_sp_pity4 = #sp_pity ec.var
execute if score @s ec.tt_type matches 5 run scoreboard players operation @s ec.tt_sp_pity5 = #sp_pity ec.var
execute if score @s ec.tt_type matches 6 run scoreboard players operation @s ec.tt_sp_pity6 = #sp_pity ec.var
