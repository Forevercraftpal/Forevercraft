# Building T10 themed zone — geometry (macro)
# Called: function .../building/build_t10_zone_fill with storage evercraft:trials  (zx,zz set)
# All offsets stay inside the arena envelope (0..47, Y300..323) and the fill_air sweep clears
# Y298..325 -> every block here is torn down by the standard teardown (no per-zone teardown).
#
# The base build_t10 laid the open 48x48 build floor (grass Y299) + four glowstone quadrant
# markers (offset 12/36 at Y300). The spawn platform is stone_bricks at offset 22..26, Y301.
# This zone ADDS, in the open air band ABOVE the floor (Y302+), a construction-site reach:
#   * a SCAFFOLD-CLIMB + BEAM-WALK PARKOUR rising from beside the spawn out over an open gap,
#   * a GHOST-BLUEPRINT decoy frame (stained-glass plan that looks like the build target, isn't),
#   * the real raised BUILD DECK across the gap (the prime high terrace the parkour earns).
# The central spawn deck (offset 22..26) is left clear so the player can still build at spawn —
# the zone only adds a BETTER, higher, uncontested build deck behind the gap. Scoring is the
# existing placed-block sum (building/tick); the zone never changes how a placement is counted.

# === GHOST-BLUEPRINT DECOY FRAME — a phantom "plan" of the build hovering over the NW floor.
# Stained-glass outline + light-blue wireframe that READS as the target structure to copy, but
# it is decoration: placing against it earns nothing, and it sits away from the prime deck so the
# builder who chases the wrong plan loses time. Glass is non-solid-feel + the frame is hollow. ===
$execute positioned $(zx) 305 $(zz) run fill ~7 ~ ~7 ~13 ~ ~7 light_blue_stained_glass
$execute positioned $(zx) 305 $(zz) run fill ~7 ~ ~13 ~13 ~ ~13 light_blue_stained_glass
$execute positioned $(zx) 305 $(zz) run fill ~7 ~ ~7 ~7 ~ ~13 light_blue_stained_glass
$execute positioned $(zx) 305 $(zz) run fill ~13 ~ ~7 ~13 ~ ~13 light_blue_stained_glass
$execute positioned $(zx) 306 $(zz) run setblock ~7 ~ ~7 white_stained_glass
$execute positioned $(zx) 306 $(zz) run setblock ~13 ~ ~7 white_stained_glass
$execute positioned $(zx) 306 $(zz) run setblock ~7 ~ ~13 white_stained_glass
$execute positioned $(zx) 306 $(zz) run setblock ~13 ~ ~13 white_stained_glass
$execute positioned $(zx) 307 $(zz) run fill ~7 ~ ~7 ~13 ~ ~7 white_stained_glass
$execute positioned $(zx) 307 $(zz) run fill ~7 ~ ~13 ~13 ~ ~13 white_stained_glass

# === SCAFFOLD COLUMNS — supported scaffolding towers rising from the floor (Y300 up) beside the
# spawn deck. bottom=true keeps the base anchored; the column self-supports so nothing pops off. ===
$execute positioned $(zx) 300 $(zz) run fill ~28 ~ ~24 ~28 ~5 ~24 scaffolding[bottom=true]
$execute positioned $(zx) 300 $(zz) run fill ~31 ~ ~26 ~31 ~6 ~26 scaffolding[bottom=true]
$execute positioned $(zx) 300 $(zz) run fill ~34 ~ ~22 ~34 ~7 ~22 scaffolding[bottom=true]

# === BEAM-WALK PARKOUR — stripped-log beams across an open gap from scaffold to scaffold to the
# far build deck. Solid blocks (no gravity/support dependency). Spacing is jumpable; a missed
# jump drops to the floor (costs time, not the run). Beams rise Y305 -> Y309 to read as climbing
# out over the site to the high terrace. ===
$execute positioned $(zx) 305 $(zz) run setblock ~28 ~ ~24 stripped_oak_log[axis=x]
$execute positioned $(zx) 305 $(zz) run setblock ~30 ~ ~25 stripped_oak_log[axis=x]
$execute positioned $(zx) 306 $(zz) run setblock ~31 ~ ~26 stripped_oak_log[axis=z]
$execute positioned $(zx) 306 $(zz) run setblock ~33 ~ ~24 stripped_oak_log[axis=x]
$execute positioned $(zx) 307 $(zz) run setblock ~34 ~ ~22 stripped_oak_log[axis=x]
$execute positioned $(zx) 307 $(zz) run setblock ~36 ~ ~24 stripped_oak_log[axis=x]
$execute positioned $(zx) 308 $(zz) run setblock ~38 ~ ~27 stripped_oak_log[axis=z]
$execute positioned $(zx) 308 $(zz) run setblock ~39 ~ ~30 stripped_oak_log[axis=x]
$execute positioned $(zx) 309 $(zz) run setblock ~40 ~ ~33 stripped_oak_log[axis=x]

# === BUILD DECK — the real raised build platform across the gap (Y310, far SE corner). A clean
# oak-plank terrace, walled by a low fence, with a target marker. Placed blocks here count exactly
# like anywhere else (the scorer is global) — it is simply the prime, uncontested high real estate
# the parkour earns. Kept inside the envelope (offset to ~45, Y310..312). ===
$execute positioned $(zx) 310 $(zz) run fill ~38 ~ ~33 ~45 ~ ~42 oak_planks
$execute positioned $(zx) 311 $(zz) run fill ~38 ~ ~33 ~45 ~ ~33 oak_fence
$execute positioned $(zx) 311 $(zz) run fill ~38 ~ ~42 ~45 ~ ~42 oak_fence
$execute positioned $(zx) 311 $(zz) run fill ~38 ~ ~33 ~38 ~ ~42 oak_fence
$execute positioned $(zx) 311 $(zz) run fill ~45 ~ ~33 ~45 ~ ~42 oak_fence

# === SITE BEACON — a scaffold + lantern pillar on the build deck marking the prime spot (the
# "topping-out" flag the high terrace promises). The lantern stands on top of the scaffold tower
# (Y311..314 column -> standing lantern at Y315). Cosmetic; the placed-block sum is still the
# only scorer. ===
$execute positioned $(zx) 311 $(zz) run fill ~41 ~ ~37 ~41 ~3 ~37 scaffolding[bottom=true]
$execute positioned $(zx) 315 $(zz) run setblock ~41 ~ ~37 lantern[hanging=false]

# === LIGHTS — keep the parkour + build deck readable even under the Blackout lamps-out pulse.
# A floating sea-lantern over a mid beam (Y310 over the Y309 beam, off to the side of the deck)
# + a light block above the deck (clear of the scaffold pillar at offset 41,37). ===
$execute positioned $(zx) 310 $(zz) run setblock ~39 ~ ~30 sea_lantern
$execute positioned $(zx) 313 $(zz) run setblock ~43 ~ ~38 light[level=15]
