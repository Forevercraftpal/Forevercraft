# Mining Arena — Clear spawn platform at center (macro)
# 5x5x5 air pocket at center of arena, Y=300-304
# Center is at ax+24, az+24. Must reach Y=304: teleport_to_arena drops the player at
# Y=303, so the head block (Y=304) has to be air or the solid stone interior suffocates
# them (~4 hearts) before they fall to the floor.

$execute positioned $(ax) 300 $(az) run fill ~22 ~ ~22 ~26 ~4 ~26 air
