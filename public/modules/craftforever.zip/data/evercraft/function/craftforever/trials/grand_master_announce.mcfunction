# Trade Trial — Grand Master Announcement (all 6 categories mastered!)
# Run as/at: the player

# Actor-naming @a broadcast (\u00a75b direct render)
execute as @s run function evercraft:util/notify/whoami
data modify storage evercraft:notify stage.c set value [{text:"\u2605\u2605\u2605 ",color:"gold"},{text:"",color:"yellow",bold:true},{text:" has become a ",color:"gray"},{text:"GRAND MASTER",color:"gold",bold:true},{text:"! \u2605\u2605\u2605",color:"gold"}]
data modify storage evercraft:notify stage.c[1].text set from storage evercraft:notify named.who
scoreboard players set #ndur ec.temp 50
execute as @s run execute as @a run scoreboard players set #nttl ec.temp 600
execute as @s run execute as @a run function evercraft:util/notify/emit_keep

playsound minecraft:entity.wither.death master @a[scores={ec.fx_snd=1..}] ~ ~ ~ 0.5 1.5
particle minecraft:end_rod ~ ~1 ~ 3 3 3 0.1 100
particle minecraft:totem_of_undying ~ ~1 ~ 3 3 3 1.0 250
