# Trade Trial modifier — Parkour stepping-stone course (macro).
# Called: function .../mods/parkour_fill with storage evercraft:trials  (px,pz set)
# Spawn platform clears offset 22..26 at Y300-304. We lay a trail of single stepping stones
# starting at the platform edge (offset 27) and stepping outward at a jumpable spacing, at
# Y=301 so they float one above the cleared floor. All inside the arena -> fill_air cleans them.
$execute positioned $(px) 301 $(pz) run setblock ~28 ~ ~24 polished_andesite
$execute positioned $(px) 301 $(pz) run setblock ~31 ~ ~25 polished_andesite
$execute positioned $(px) 302 $(pz) run setblock ~34 ~ ~24 polished_andesite
$execute positioned $(px) 302 $(pz) run setblock ~37 ~ ~26 polished_andesite
$execute positioned $(px) 303 $(pz) run setblock ~40 ~ ~24 gold_block
