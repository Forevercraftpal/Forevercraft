# Trade Trials — Auto-redeem earned Crate Coins into crates
# Run as/at: the player who just completed a trial (or daily challenge).
#
# Crate Coins from trials are a COUNTER, not a saved currency: the completion
# tallies how many were earned into #tt_crate_n ec.var, then this function
# instantly rolls that many crates and hands them over. This is deliberately
# SEPARATE from the Infinite Castle's ic.coins ("Castle Crate Coins"), which is
# castle-scoped and wiped to 0 on castle entry — writing trial coins there made
# them unspendable. (Caller resets #tt_crate_n + #tt_crate_warned before tallying.)
#
# Each redeemed crate rolls a CHANNEL:
#   1..20  (~20%) -> an Accessory Crate (set + tier via accessory_roll)
#   21..100(~80%) -> a regular tier crate (regular_roll):
#                    Common 58 / Uncommon 25 / Rare 10 / Ornate 5 / Exquisite 1.5 / Mythical 0.5%
# Both give the crate to @s, or drop it at feet (warned once) if inventory is full.

# Nothing left to redeem
execute if score #tt_crate_n ec.var matches ..0 run return 0

# Re-check inventory fullness each crate (a give can fill the last slot)
execute store result score #inv_full ec.var run function evercraft:util/check_inv_full

# Pick this crate's channel, then hand off to the matching roller
execute store result score #tt_channel ec.var run random value 1..100
execute if score #tt_channel ec.var matches 1..20 run function evercraft:craftforever/trials/accessory_roll
execute if score #tt_channel ec.var matches 21..100 run function evercraft:craftforever/trials/regular_roll

# Warn once if crates had to be dropped at feet
data modify storage evercraft:notify stage.c set value [{text:"Inventory full! Crates dropped at your feet.",color:"yellow"}]
scoreboard players set #ndur ec.temp 45
execute if score #inv_full ec.var matches 1 unless score #tt_crate_warned ec.var matches 1 run function evercraft:util/notify/emit
execute if score #inv_full ec.var matches 1 unless score #tt_crate_warned ec.var matches 1 if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bass player @s ~ ~ ~ 1 0.5
execute if score #inv_full ec.var matches 1 run scoreboard players set #tt_crate_warned ec.var 1

# Decrement and recurse until all earned coins are spent
scoreboard players remove #tt_crate_n ec.var 1
execute if score #tt_crate_n ec.var matches 1.. run function evercraft:craftforever/trials/crate_redeem
