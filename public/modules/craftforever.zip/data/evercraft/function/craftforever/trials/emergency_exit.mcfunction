# Trade Trial — Emergency Exit (/trigger ec.tt_exit)
# Run as: the player who triggered exit

data modify storage evercraft:notify stage.c set value [{text:"Emergency exit — trial abandoned.",color:"red"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.anvil.destroy master @s ~ ~ ~ 0.5 0.8
function evercraft:craftforever/trials/cleanup_player
