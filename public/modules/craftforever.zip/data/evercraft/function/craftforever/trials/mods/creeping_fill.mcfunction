# Trade Trial modifier — Creeping hazard fill one fluid layer (macro).
# Called: function .../mods/creeping_fill with storage evercraft:trials  (hx,hy,hz,hf set)
# Fills a single Y layer of the $(hf) fluid (lava default; water for farming) across the arena
# interior (offset 1..46, inside the shell). Only fills where air currently is, so it pours
# around standing pillars rather than erasing them.
$execute positioned $(hx) $(hy) $(hz) run fill ~1 ~ ~1 ~46 ~ ~46 $(hf) replace air
