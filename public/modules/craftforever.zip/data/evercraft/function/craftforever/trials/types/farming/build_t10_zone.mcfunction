# Farming T10 — THEMED INSTANCED ZONE (Craft-Trial Complexity Ladder, Wave 2)
# Run as/at: the trial player, from t10/build_zone (T10 only, AFTER build_t10 laid the base
# two-level main field + the harvest target of 500). This ADDS a castle-style multi-room depth
# on top of farming's signature harvest: a TERRACED upper garden with a hay-bale PARKOUR
# traverse over a wide irrigation channel, DECOY rows of unripe crops (look ripe, score
# nothing), and a RIPE reward bed (the only crops that feed the harvest counter) reachable
# only across the jump. Authored to fit the arena envelope (offset 0..47, Y309..322, inside
# the free band above the level-2 field) so the standard fill_air teardown clears it — no
# per-zone teardown geometry.
#
# Modeled on types/mining/build_t10_zone (the Wave-1 reference). Keeps farming's reward +
# the 2% catalyst roll (in farming/reward) untouched.

execute store result storage evercraft:trials zx int 1 run scoreboard players get @s ec.tt_arena_x
execute store result storage evercraft:trials zz int 1 run scoreboard players get @s ec.tt_arena_z
function evercraft:craftforever/trials/types/farming/build_t10_zone_fill with storage evercraft:trials

# Themed intro title — the player arrives into a terraced, instanced garden.
title @s times 5 30 10
title @s subtitle {"text":"Terraced gardens rise above the fields…","color":"green"}
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.sweet_berry_bush.pick master @s ~ ~ ~ 1 1.1
