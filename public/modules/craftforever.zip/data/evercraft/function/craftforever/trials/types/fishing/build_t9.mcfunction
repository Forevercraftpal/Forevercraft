# Fishing Trial T9 — Deep Sea lake (4 blocks deep)
# Depth capped at 4 (Y=300-303) so the player never spawns submerged.
# Macro file — run with storage evercraft:trials

$execute positioned $(ax) 300 $(az) run fill ~2 ~ ~2 ~46 ~3 ~46 water

# Kelp columns in deep water
$execute positioned $(ax) 300 $(az) run fill ~5 ~ ~5 ~10 ~2 ~10 kelp replace water
$execute positioned $(ax) 300 $(az) run fill ~35 ~ ~35 ~42 ~2 ~42 kelp replace water
$execute positioned $(ax) 300 $(az) run fill ~5 ~ ~35 ~10 ~2 ~42 kelp replace water
