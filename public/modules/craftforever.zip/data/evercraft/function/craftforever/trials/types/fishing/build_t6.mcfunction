# Fishing Trial T6 — Treasure lake (4 blocks deep)
# Depth capped at 4 (Y=300-303) so the player never spawns submerged.
# Macro file — run with storage evercraft:trials

$execute positioned $(ax) 300 $(az) run fill ~2 ~ ~2 ~46 ~3 ~46 water

# Kelp patches in deep water
$execute positioned $(ax) 300 $(az) run fill ~5 ~ ~5 ~12 ~3 ~12 kelp replace water
$execute positioned $(ax) 300 $(az) run fill ~35 ~ ~35 ~42 ~3 ~42 kelp replace water
