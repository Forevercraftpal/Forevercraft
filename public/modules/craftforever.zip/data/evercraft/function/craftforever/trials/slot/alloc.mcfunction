# Trade Trial — claim a free arena slot on the far-away grid (slots 1..64).
# A slot is FREE when its registry flag #tts<n> on ec.tt_slot is NOT 1 (unset counts as free).
# Walk 1->64 and claim the LOWEST free one into @s ec.tt_slot (the `if @s matches 0` guard
# freezes the pick after the first hit). Result: @s ec.tt_slot = lowest free index, or 0 if the
# whole grid is busy (caller aborts the start before consuming the key). If a slot was claimed,
# mark it occupied, compute its grid coords into ec.tt_arena_x/z, and forceload its chunks.
scoreboard players set @s ec.tt_slot 0
execute if score @s ec.tt_slot matches 0 unless score #tts1 ec.tt_slot matches 1 run scoreboard players set @s ec.tt_slot 1
execute if score @s ec.tt_slot matches 0 unless score #tts2 ec.tt_slot matches 1 run scoreboard players set @s ec.tt_slot 2
execute if score @s ec.tt_slot matches 0 unless score #tts3 ec.tt_slot matches 1 run scoreboard players set @s ec.tt_slot 3
execute if score @s ec.tt_slot matches 0 unless score #tts4 ec.tt_slot matches 1 run scoreboard players set @s ec.tt_slot 4
execute if score @s ec.tt_slot matches 0 unless score #tts5 ec.tt_slot matches 1 run scoreboard players set @s ec.tt_slot 5
execute if score @s ec.tt_slot matches 0 unless score #tts6 ec.tt_slot matches 1 run scoreboard players set @s ec.tt_slot 6
execute if score @s ec.tt_slot matches 0 unless score #tts7 ec.tt_slot matches 1 run scoreboard players set @s ec.tt_slot 7
execute if score @s ec.tt_slot matches 0 unless score #tts8 ec.tt_slot matches 1 run scoreboard players set @s ec.tt_slot 8
execute if score @s ec.tt_slot matches 0 unless score #tts9 ec.tt_slot matches 1 run scoreboard players set @s ec.tt_slot 9
execute if score @s ec.tt_slot matches 0 unless score #tts10 ec.tt_slot matches 1 run scoreboard players set @s ec.tt_slot 10
execute if score @s ec.tt_slot matches 0 unless score #tts11 ec.tt_slot matches 1 run scoreboard players set @s ec.tt_slot 11
execute if score @s ec.tt_slot matches 0 unless score #tts12 ec.tt_slot matches 1 run scoreboard players set @s ec.tt_slot 12
execute if score @s ec.tt_slot matches 0 unless score #tts13 ec.tt_slot matches 1 run scoreboard players set @s ec.tt_slot 13
execute if score @s ec.tt_slot matches 0 unless score #tts14 ec.tt_slot matches 1 run scoreboard players set @s ec.tt_slot 14
execute if score @s ec.tt_slot matches 0 unless score #tts15 ec.tt_slot matches 1 run scoreboard players set @s ec.tt_slot 15
execute if score @s ec.tt_slot matches 0 unless score #tts16 ec.tt_slot matches 1 run scoreboard players set @s ec.tt_slot 16
execute if score @s ec.tt_slot matches 0 unless score #tts17 ec.tt_slot matches 1 run scoreboard players set @s ec.tt_slot 17
execute if score @s ec.tt_slot matches 0 unless score #tts18 ec.tt_slot matches 1 run scoreboard players set @s ec.tt_slot 18
execute if score @s ec.tt_slot matches 0 unless score #tts19 ec.tt_slot matches 1 run scoreboard players set @s ec.tt_slot 19
execute if score @s ec.tt_slot matches 0 unless score #tts20 ec.tt_slot matches 1 run scoreboard players set @s ec.tt_slot 20
execute if score @s ec.tt_slot matches 0 unless score #tts21 ec.tt_slot matches 1 run scoreboard players set @s ec.tt_slot 21
execute if score @s ec.tt_slot matches 0 unless score #tts22 ec.tt_slot matches 1 run scoreboard players set @s ec.tt_slot 22
execute if score @s ec.tt_slot matches 0 unless score #tts23 ec.tt_slot matches 1 run scoreboard players set @s ec.tt_slot 23
execute if score @s ec.tt_slot matches 0 unless score #tts24 ec.tt_slot matches 1 run scoreboard players set @s ec.tt_slot 24
execute if score @s ec.tt_slot matches 0 unless score #tts25 ec.tt_slot matches 1 run scoreboard players set @s ec.tt_slot 25
execute if score @s ec.tt_slot matches 0 unless score #tts26 ec.tt_slot matches 1 run scoreboard players set @s ec.tt_slot 26
execute if score @s ec.tt_slot matches 0 unless score #tts27 ec.tt_slot matches 1 run scoreboard players set @s ec.tt_slot 27
execute if score @s ec.tt_slot matches 0 unless score #tts28 ec.tt_slot matches 1 run scoreboard players set @s ec.tt_slot 28
execute if score @s ec.tt_slot matches 0 unless score #tts29 ec.tt_slot matches 1 run scoreboard players set @s ec.tt_slot 29
execute if score @s ec.tt_slot matches 0 unless score #tts30 ec.tt_slot matches 1 run scoreboard players set @s ec.tt_slot 30
execute if score @s ec.tt_slot matches 0 unless score #tts31 ec.tt_slot matches 1 run scoreboard players set @s ec.tt_slot 31
execute if score @s ec.tt_slot matches 0 unless score #tts32 ec.tt_slot matches 1 run scoreboard players set @s ec.tt_slot 32
execute if score @s ec.tt_slot matches 0 unless score #tts33 ec.tt_slot matches 1 run scoreboard players set @s ec.tt_slot 33
execute if score @s ec.tt_slot matches 0 unless score #tts34 ec.tt_slot matches 1 run scoreboard players set @s ec.tt_slot 34
execute if score @s ec.tt_slot matches 0 unless score #tts35 ec.tt_slot matches 1 run scoreboard players set @s ec.tt_slot 35
execute if score @s ec.tt_slot matches 0 unless score #tts36 ec.tt_slot matches 1 run scoreboard players set @s ec.tt_slot 36
execute if score @s ec.tt_slot matches 0 unless score #tts37 ec.tt_slot matches 1 run scoreboard players set @s ec.tt_slot 37
execute if score @s ec.tt_slot matches 0 unless score #tts38 ec.tt_slot matches 1 run scoreboard players set @s ec.tt_slot 38
execute if score @s ec.tt_slot matches 0 unless score #tts39 ec.tt_slot matches 1 run scoreboard players set @s ec.tt_slot 39
execute if score @s ec.tt_slot matches 0 unless score #tts40 ec.tt_slot matches 1 run scoreboard players set @s ec.tt_slot 40
execute if score @s ec.tt_slot matches 0 unless score #tts41 ec.tt_slot matches 1 run scoreboard players set @s ec.tt_slot 41
execute if score @s ec.tt_slot matches 0 unless score #tts42 ec.tt_slot matches 1 run scoreboard players set @s ec.tt_slot 42
execute if score @s ec.tt_slot matches 0 unless score #tts43 ec.tt_slot matches 1 run scoreboard players set @s ec.tt_slot 43
execute if score @s ec.tt_slot matches 0 unless score #tts44 ec.tt_slot matches 1 run scoreboard players set @s ec.tt_slot 44
execute if score @s ec.tt_slot matches 0 unless score #tts45 ec.tt_slot matches 1 run scoreboard players set @s ec.tt_slot 45
execute if score @s ec.tt_slot matches 0 unless score #tts46 ec.tt_slot matches 1 run scoreboard players set @s ec.tt_slot 46
execute if score @s ec.tt_slot matches 0 unless score #tts47 ec.tt_slot matches 1 run scoreboard players set @s ec.tt_slot 47
execute if score @s ec.tt_slot matches 0 unless score #tts48 ec.tt_slot matches 1 run scoreboard players set @s ec.tt_slot 48
execute if score @s ec.tt_slot matches 0 unless score #tts49 ec.tt_slot matches 1 run scoreboard players set @s ec.tt_slot 49
execute if score @s ec.tt_slot matches 0 unless score #tts50 ec.tt_slot matches 1 run scoreboard players set @s ec.tt_slot 50
execute if score @s ec.tt_slot matches 0 unless score #tts51 ec.tt_slot matches 1 run scoreboard players set @s ec.tt_slot 51
execute if score @s ec.tt_slot matches 0 unless score #tts52 ec.tt_slot matches 1 run scoreboard players set @s ec.tt_slot 52
execute if score @s ec.tt_slot matches 0 unless score #tts53 ec.tt_slot matches 1 run scoreboard players set @s ec.tt_slot 53
execute if score @s ec.tt_slot matches 0 unless score #tts54 ec.tt_slot matches 1 run scoreboard players set @s ec.tt_slot 54
execute if score @s ec.tt_slot matches 0 unless score #tts55 ec.tt_slot matches 1 run scoreboard players set @s ec.tt_slot 55
execute if score @s ec.tt_slot matches 0 unless score #tts56 ec.tt_slot matches 1 run scoreboard players set @s ec.tt_slot 56
execute if score @s ec.tt_slot matches 0 unless score #tts57 ec.tt_slot matches 1 run scoreboard players set @s ec.tt_slot 57
execute if score @s ec.tt_slot matches 0 unless score #tts58 ec.tt_slot matches 1 run scoreboard players set @s ec.tt_slot 58
execute if score @s ec.tt_slot matches 0 unless score #tts59 ec.tt_slot matches 1 run scoreboard players set @s ec.tt_slot 59
execute if score @s ec.tt_slot matches 0 unless score #tts60 ec.tt_slot matches 1 run scoreboard players set @s ec.tt_slot 60
execute if score @s ec.tt_slot matches 0 unless score #tts61 ec.tt_slot matches 1 run scoreboard players set @s ec.tt_slot 61
execute if score @s ec.tt_slot matches 0 unless score #tts62 ec.tt_slot matches 1 run scoreboard players set @s ec.tt_slot 62
execute if score @s ec.tt_slot matches 0 unless score #tts63 ec.tt_slot matches 1 run scoreboard players set @s ec.tt_slot 63
execute if score @s ec.tt_slot matches 0 unless score #tts64 ec.tt_slot matches 1 run scoreboard players set @s ec.tt_slot 64

# No free slot -> leave @s ec.tt_slot 0 and bail; start.mcfunction shows the busy message.
execute if score @s ec.tt_slot matches 0 run return 0

# Claim it: occupancy flag, grid coords, forceload.
execute store result storage evercraft:trials slot int 1 run scoreboard players get @s ec.tt_slot
function evercraft:craftforever/trials/slot/claim with storage evercraft:trials
function evercraft:craftforever/trials/slot/grid_coords
function evercraft:craftforever/trials/slot/fl_box
function evercraft:craftforever/trials/slot/forceload_add with storage evercraft:trials
