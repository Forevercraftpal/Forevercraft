# Free grid slot $(slot) (macro). Run with storage evercraft:trials {slot:<1-64>}.
$scoreboard players set #tts$(slot) ec.tt_slot 0
