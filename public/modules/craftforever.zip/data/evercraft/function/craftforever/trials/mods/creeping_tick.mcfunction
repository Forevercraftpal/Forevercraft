# Trade Trial modifier — Creeping hazard (bit 4): rising lava floor, stay above it.
# Run as/at: the trial player, from mods/tick on the 2s cadence beat.
# Each beat raises a one-block lava layer by one Y. ec.tt_haz_y holds the current layer Y
# (seeded to 300 in mods/apply). The lava sits inside the arena envelope so fill_air clears
# it at teardown. We cap the rise at Y=316 so the ceiling band + spawn never fully drown.
#
# Category flavour: mining = lava. Farming (type 2) = water (the irrigation floods over).
# Fishing (type 3) = water (a storm-surge tide swells the pool). The fill fluid is passed to the
# creeping_fill macro via the `hf` storage field so the macro stays a single fill line; both
# lava and water sit inside the envelope -> fill_air clears them.
# Artisan (type 6) KEEPS the lava default — it reads as the FORGE'S MOLTEN CHANNEL overflowing,
# the smelt-bath rising one layer per beat (the smith climbs the platforms to stay above the
# white-hot metal). No `hf`/creeping_fill edit — lava is already the default fluid.

# Stop rising once we hit the cap (keeps a safe air gap below the ceiling).
# Wave 1 (Joseph 2026-06-10, actionbar-priority): every hazard paint below yields to the notify
# queue (`unless entity @s[tag=ab_q]`) — HUD convention. The 2s beat repaints it right after any
# queued frame drains, so the telegraph stays effectively continuous without stomping messages.
execute if score @s ec.tt_haz_y matches 317.. run return 0

# Fill the current layer across the arena interior (offset 1..46 to stay inside the shell).
execute store result storage evercraft:trials hx int 1 run scoreboard players get @s ec.tt_arena_x
execute store result storage evercraft:trials hz int 1 run scoreboard players get @s ec.tt_arena_z
execute store result storage evercraft:trials hy int 1 run scoreboard players get @s ec.tt_haz_y
# Pick the rising fluid by category (default lava; farming + fishing + building flood with water).
# Lumber (type 5) keeps the lava default — it reads as a forest-floor WILDFIRE the feller must
# climb the trees to escape (the fire eats the understorey, rising one layer per beat).
data modify storage evercraft:trials hf set value "lava"
execute if score @s ec.tt_type matches 2 run data modify storage evercraft:trials hf set value "water"
execute if score @s ec.tt_type matches 3 run data modify storage evercraft:trials hf set value "water"
execute if score @s ec.tt_type matches 4 run data modify storage evercraft:trials hf set value "water"
function evercraft:craftforever/trials/mods/creeping_fill with storage evercraft:trials

# Raise the level for next beat.
scoreboard players add @s ec.tt_haz_y 1

# Warn the player (farming = flood, fishing = storm-surge tide, building = burst main, else = lava).
execute if score @s ec.tt_type matches 2 if score @s ec.fx_snd matches 2.. run playsound minecraft:block.water.ambient master @s ~ ~ ~ 0.5 1.0
execute if score @s ec.tt_type matches 2 unless entity @s[tag=ab_q] run title @s actionbar {"text":"⚠ The fields are flooding — climb higher!","color":"aqua"}
execute if score @s ec.tt_type matches 3 if score @s ec.fx_snd matches 2.. run playsound minecraft:ambient.underwater.enter master @s ~ ~ ~ 0.6 0.9
execute if score @s ec.tt_type matches 3 unless entity @s[tag=ab_q] run title @s actionbar {"text":"⚠ The tide is surging — climb higher!","color":"aqua"}
execute if score @s ec.tt_type matches 4 if score @s ec.fx_snd matches 2.. run playsound minecraft:block.water.ambient master @s ~ ~ ~ 0.6 0.9
execute if score @s ec.tt_type matches 4 unless entity @s[tag=ab_q] run title @s actionbar {"text":"⚠ A burst main is flooding the site — climb higher!","color":"aqua"}
execute if score @s ec.tt_type matches 5 if score @s ec.fx_snd matches 2.. run playsound minecraft:block.fire.ambient master @s ~ ~ ~ 0.6 1.0
execute if score @s ec.tt_type matches 5 unless entity @s[tag=ab_q] run title @s actionbar {"text":"⚠ A wildfire is climbing the understorey — get up the trees!","color":"gold"}
# Artisan (type 6): the FORGE'S MOLTEN CHANNEL overflows — the smelt-bath rises one layer per beat.
# Same lava default (the smith climbs the forge platforms to stay above the white-hot metal).
execute if score @s ec.tt_type matches 6 if score @s ec.fx_snd matches 2.. run playsound minecraft:block.lava.ambient master @s ~ ~ ~ 0.6 0.9
execute if score @s ec.tt_type matches 6 unless entity @s[tag=ab_q] run title @s actionbar {"text":"⚠ The molten channel is overflowing — climb the forge platforms!","color":"gold"}
execute unless score @s ec.tt_type matches 2 unless score @s ec.tt_type matches 3 unless score @s ec.tt_type matches 4 unless score @s ec.tt_type matches 5 unless score @s ec.tt_type matches 6 if score @s ec.fx_snd matches 2.. run playsound minecraft:block.lava.ambient master @s ~ ~ ~ 0.5 1.0
execute unless score @s ec.tt_type matches 2 unless score @s ec.tt_type matches 3 unless score @s ec.tt_type matches 4 unless score @s ec.tt_type matches 5 unless score @s ec.tt_type matches 6 unless entity @s[tag=ab_q] run title @s actionbar {"text":"⚠ The lava is rising — climb higher!","color":"gold"}
