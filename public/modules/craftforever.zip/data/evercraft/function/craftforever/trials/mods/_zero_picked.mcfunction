# Trade Trial — zero the weight of any modifier bit already set in ec.tt_mods.
# Run as/at: the trial player, from roll_one (after #tt_w0..#tt_w10 are seeded).
# Bit set test: (ec.tt_mods / 2^bit) % 2 == 1.

# bit 0
scoreboard players operation #tt_bt ec.var = @s ec.tt_mods
scoreboard players operation #tt_bt ec.var %= #2 ec.const
execute if score #tt_bt ec.var matches 1 run scoreboard players set #tt_w0 ec.var 0
# bit 1
scoreboard players operation #tt_bt ec.var = @s ec.tt_mods
scoreboard players operation #tt_bt ec.var /= #2 ec.const
scoreboard players operation #tt_bt ec.var %= #2 ec.const
execute if score #tt_bt ec.var matches 1 run scoreboard players set #tt_w1 ec.var 0
# bit 2
scoreboard players operation #tt_bt ec.var = @s ec.tt_mods
scoreboard players operation #tt_bt ec.var /= #4 ec.const
scoreboard players operation #tt_bt ec.var %= #2 ec.const
execute if score #tt_bt ec.var matches 1 run scoreboard players set #tt_w2 ec.var 0
# bit 3
scoreboard players operation #tt_bt ec.var = @s ec.tt_mods
scoreboard players operation #tt_bt ec.var /= #8 ec.const
scoreboard players operation #tt_bt ec.var %= #2 ec.const
execute if score #tt_bt ec.var matches 1 run scoreboard players set #tt_w3 ec.var 0
# bit 4
scoreboard players operation #tt_bt ec.var = @s ec.tt_mods
scoreboard players operation #tt_bt ec.var /= #16 ec.const
scoreboard players operation #tt_bt ec.var %= #2 ec.const
execute if score #tt_bt ec.var matches 1 run scoreboard players set #tt_w4 ec.var 0
# bit 5
scoreboard players operation #tt_bt ec.var = @s ec.tt_mods
scoreboard players operation #tt_bt ec.var /= #32 ec.const
scoreboard players operation #tt_bt ec.var %= #2 ec.const
execute if score #tt_bt ec.var matches 1 run scoreboard players set #tt_w5 ec.var 0
# bit 6
scoreboard players operation #tt_bt ec.var = @s ec.tt_mods
scoreboard players operation #tt_bt ec.var /= #64 ec.const
scoreboard players operation #tt_bt ec.var %= #2 ec.const
execute if score #tt_bt ec.var matches 1 run scoreboard players set #tt_w6 ec.var 0
# bit 7
scoreboard players operation #tt_bt ec.var = @s ec.tt_mods
scoreboard players operation #tt_bt ec.var /= #128 ec.const
scoreboard players operation #tt_bt ec.var %= #2 ec.const
execute if score #tt_bt ec.var matches 1 run scoreboard players set #tt_w7 ec.var 0
# bit 8
scoreboard players operation #tt_bt ec.var = @s ec.tt_mods
scoreboard players operation #tt_bt ec.var /= #256 ec.const
scoreboard players operation #tt_bt ec.var %= #2 ec.const
execute if score #tt_bt ec.var matches 1 run scoreboard players set #tt_w8 ec.var 0
# bit 9
scoreboard players operation #tt_bt ec.var = @s ec.tt_mods
scoreboard players operation #tt_bt ec.var /= #512 ec.const
scoreboard players operation #tt_bt ec.var %= #2 ec.const
execute if score #tt_bt ec.var matches 1 run scoreboard players set #tt_w9 ec.var 0
# bit 10
scoreboard players operation #tt_bt ec.var = @s ec.tt_mods
scoreboard players operation #tt_bt ec.var /= #1024 ec.const
scoreboard players operation #tt_bt ec.var %= #2 ec.const
execute if score #tt_bt ec.var matches 1 run scoreboard players set #tt_w10 ec.var 0
