# Show actionbar with score and time (macro)
$execute unless entity @s[tag=ab_q] run title @s actionbar [{"text":"Progress: ","color":"gray"},{"text":"$(score)/$(target)","color":"gold"},{"text":" | Time: ","color":"gray"},{"text":"$(seconds)s","color":"yellow"}]
