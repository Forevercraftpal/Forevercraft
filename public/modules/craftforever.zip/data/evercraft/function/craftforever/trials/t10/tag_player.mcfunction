# Trade Trial — T10 tag the player p$(pid) (macro, castle adoption)
# Called: function .../t10/tag_player with storage evercraft:trials  (pid set)
# Adds the per-instance isolation tag (mirrors castle/begin_inner:22 `$tag @s add p$(pid)`).
# Removed in t10/teardown.
$tag @s add p$(pid)
