# Trade Trial — Crash/disconnect recovery
# Player reconnected while in a trial — clean up gracefully
# Run as: the player with ec.tt_player tag who just reconnected

data modify storage evercraft:notify stage.c set value [{text:"Your trial was interrupted. Returning you safely.",color:"gray"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
function evercraft:craftforever/trials/cleanup_player
