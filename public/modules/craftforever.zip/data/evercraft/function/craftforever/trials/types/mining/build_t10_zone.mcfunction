# Mining T10 — THEMED INSTANCED ZONE (Craft-Trial Complexity Ladder, Wave 1)
# Run as/at: the trial player, from t10/build_zone (T10 only, AFTER build_t10 laid the base
# deep-vein cave + ores + the collapse schedule). This ADDS the castle-style multi-room depth
# on top of mining's signature collapse: a parkour traverse over a lava chasm to a high-value
# vein, plus a couple of distraction decoy pockets. Authored to fit the arena envelope (offset
# 0..47, Y300..324) so the standard fill_air teardown clears it — no per-zone teardown geometry.
#
# This is the REFERENCE the other 5 categories copy for their own T10 zone.

execute store result storage evercraft:trials zx int 1 run scoreboard players get @s ec.tt_arena_x
execute store result storage evercraft:trials zz int 1 run scoreboard players get @s ec.tt_arena_z
function evercraft:craftforever/trials/types/mining/build_t10_zone_fill with storage evercraft:trials

# Themed intro title — the player arrives into a deeper, instanced cavern.
title @s times 5 30 10
title @s subtitle {"text":"A deeper vein opens before you…","color":"dark_aqua"}
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:ambient.cave master @s ~ ~ ~ 1 0.7
