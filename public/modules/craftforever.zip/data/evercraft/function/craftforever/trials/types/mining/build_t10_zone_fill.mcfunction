# Mining T10 themed zone — geometry (macro)
# Called: function .../mining/build_t10_zone_fill with storage evercraft:trials  (zx,zz set)
# All offsets stay inside the arena envelope (0..47, Y300..324) -> cleared by fill_air.
#
# Layout (a distinct "upper room" above the base deep-vein cave):
#   * A lava CHASM carved into the far quadrant (offset 28..44 x, Y302..304).
#   * A PARKOUR BRIDGE of stepping stones across it at Y306 (the traversal-over-hazard depth).
#   * A reward VEIN of diamond + ancient debris on the far landing (only reachable via the jump).
#   * Two DISTRACTION decoy pockets of fool's blocks (raw-iron-look) elsewhere — no score value.

# --- Carve the upper room (air pocket above the base cave) ---
$execute positioned $(zx) 305 $(zz) run fill ~26 ~ ~6 ~46 ~6 ~42 air

# --- The lava chasm (a drop hazard the bridge spans) ---
$execute positioned $(zx) 302 $(zz) run fill ~30 ~ ~14 ~44 ~2 ~34 deepslate replace air
$execute positioned $(zx) 302 $(zz) run fill ~31 ~ ~15 ~43 ~0 ~33 lava

# --- Parkour bridge: floating stepping stones across the chasm at Y306 ---
$execute positioned $(zx) 306 $(zz) run setblock ~30 ~ ~24 polished_deepslate
$execute positioned $(zx) 306 $(zz) run setblock ~33 ~ ~22 polished_deepslate
$execute positioned $(zx) 306 $(zz) run setblock ~36 ~ ~25 polished_deepslate
$execute positioned $(zx) 306 $(zz) run setblock ~39 ~ ~23 polished_deepslate
$execute positioned $(zx) 306 $(zz) run setblock ~42 ~ ~25 polished_deepslate

# --- Far landing + reward vein (only reachable across the bridge) ---
$execute positioned $(zx) 305 $(zz) run fill ~43 ~ ~22 ~45 ~ ~28 deepslate
$execute positioned $(zx) 306 $(zz) run fill ~44 ~ ~24 ~45 ~ ~26 deepslate_diamond_ore
$execute positioned $(zx) 306 $(zz) run setblock ~44 ~ ~23 ancient_debris
$execute positioned $(zx) 306 $(zz) run setblock ~45 ~ ~27 ancient_debris

# --- Distraction decoy pockets: raw-iron blocks (look minable, score nothing) ---
$execute positioned $(zx) 305 $(zz) run fill ~10 ~ ~10 ~12 ~ ~12 raw_iron_block
$execute positioned $(zx) 305 $(zz) run fill ~14 ~ ~36 ~16 ~ ~38 raw_iron_block

# --- Torches on the bridge so the traverse is readable even under Blackout ---
$execute positioned $(zx) 307 $(zz) run setblock ~36 ~ ~25 shroomlight
