# Trial Pass — Clear right-click open cooldown (scheduled from on_use_pass)
execute as @a[tag=TT.PassOpenCD] run tag @s remove TT.PassOpenCD
