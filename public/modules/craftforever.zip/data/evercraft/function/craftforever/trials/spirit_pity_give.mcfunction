# Spirit-Tool Pity — give the rolled spirit tool to the player (MACRO)
# Called from spirit_pity_roll on a HIT with a free inventory slot.
#   storage evercraft:trials sp.cat = loot-table folder (mining/.../artisan)
# The spirit_drop table is the exact rich T10 spirit-tool item (st_tier:1, common).
$loot give @s loot evercraft:craftforever/trials/$(cat)/spirit_drop
