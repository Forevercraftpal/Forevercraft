# Mining Arena — Build shell (macro)
# Fully organic: deepslate floor, a natural stone/deepslate/tuff/andesite/diorite mass
# you mine into, and a solid cobbled-deepslate cap. Kept enclosed (you mine UP into it).

# Floor: deep-mine bedrock (Y=299)
$execute positioned $(ax) 299 $(az) run fill ~ ~ ~ ~47 ~ ~47 deepslate

# Minable mass — stone primary (Y=300-323), split for the 32768 fill limit
$execute positioned $(ax) 300 $(az) run fill ~ ~ ~ ~47 ~7 ~47 stone
$execute positioned $(ax) 308 $(az) run fill ~ ~ ~ ~47 ~7 ~47 stone
$execute positioned $(ax) 316 $(az) run fill ~ ~ ~ ~47 ~7 ~47 stone

# Natural rock variation — veins replace stone (tier ores are placed absolutely, so safe)
$execute positioned $(ax) 300 $(az) run fill ~4 ~ ~4 ~16 ~5 ~16 deepslate replace stone
$execute positioned $(ax) 302 $(az) run fill ~30 ~ ~28 ~44 ~6 ~42 tuff replace stone
$execute positioned $(ax) 310 $(az) run fill ~10 ~ ~30 ~22 ~6 ~42 andesite replace stone
$execute positioned $(ax) 314 $(az) run fill ~32 ~ ~6 ~44 ~6 ~18 diorite replace stone
$execute positioned $(ax) 318 $(az) run fill ~6 ~ ~8 ~18 ~5 ~20 tuff replace stone

# Ceiling: solid organic cap at Y=324 (mining stays enclosed)
$execute positioned $(ax) 324 $(az) run fill ~ ~ ~ ~47 ~ ~47 cobbled_deepslate
# Invisible barrier shell — full containment (no falling out / breaking through any block).
# Barriers transmit light + sky, so the open ceilings still read as open. Box: (-1,298,-1)->(48,325,48).
$execute positioned $(ax) 298 $(az) run fill ~-1 ~ ~-1 ~48 ~ ~48 barrier
$execute positioned $(ax) 325 $(az) run fill ~-1 ~ ~-1 ~48 ~ ~48 barrier
$execute positioned $(ax) 298 $(az) run fill ~-1 ~ ~-1 ~48 ~27 ~-1 barrier
$execute positioned $(ax) 298 $(az) run fill ~-1 ~ ~48 ~48 ~27 ~48 barrier
$execute positioned $(ax) 298 $(az) run fill ~-1 ~ ~-1 ~-1 ~27 ~48 barrier
$execute positioned $(ax) 298 $(az) run fill ~48 ~ ~-1 ~48 ~27 ~48 barrier
