# Lumber T10 themed zone — geometry (macro)
# Called: function .../lumber/build_t10_zone_fill with storage evercraft:trials  (zx,zz set)
# All offsets stay inside the arena envelope (0..47, Y300..323) and the fill_air sweep clears
# Y298..325 -> every block here is torn down by the standard teardown (no per-zone teardown).
#
# The base build_t10 laid the dense ancient forest (logs/leaves Y301..312 across the floor) + the
# spawn platform (stone_bricks offset 22..26, Y301). This zone ADDS, in the OPEN AIR BAND ABOVE
# the existing crowns (Y314+, below the Y324 leaf ceiling ring), a forest-canopy reach:
#   * a SCAFFOLD CLIMB beside spawn rising to the canopy walk (bottom=true, self-supporting),
#   * a BRANCH-WALK + LEAP PARKOUR of solid log/leaf beams across an open gap (no support deps),
#   * DECOY FAKE-TREES — hollow leaf-clad posts that read as fellable timber but are LEAVES, not
#     logs (chopping them scores nothing — the lumber scorer counts log blocks only),
#   * the real PRIME OLD-GROWTH GROVE on a raised platform across the gap (extra-tall untouched
#     giants — the uncontested prime timber the parkour earns), with a topping-out beacon.
# The central spawn platform (offset 22..26, Y301) is left clear. Scoring is the existing log
# delta (lumber/track_t10) — the zone only moves the BEST timber up into the canopy behind the
# gap; it never changes how a felled log is counted.

# === SCAFFOLD CLIMB — a supported scaffolding tower rising from the floor (Y300) beside the
# spawn platform up to the canopy-walk start (~Y314). bottom=true anchors the base; the column
# self-supports so nothing pops off. Three offset rungs give a readable climbing route. ===
$execute positioned $(zx) 300 $(zz) run fill ~28 ~ ~24 ~28 ~13 ~24 scaffolding[bottom=true]
$execute positioned $(zx) 300 $(zz) run fill ~30 ~ ~27 ~30 ~14 ~27 scaffolding[bottom=true]
$execute positioned $(zx) 300 $(zz) run fill ~27 ~ ~21 ~27 ~12 ~21 scaffolding[bottom=true]

# === DECOY FAKE-TREES — three hollow leaf-clad "trunks" up in the canopy band near the path.
# Each is a stripped-log CORE wrapped... no: they are pure LEAVES shaped like a slim trunk + crown,
# so they LOOK like a fellable tree from the walk, but contain NO log blocks — chopping them yields
# nothing and the log scorer never ticks. They sit OFF the prime grove so a feller who swings at the
# wrong "tree" loses time. (azalea/oak leaves persistent so they don't decay mid-run.) ===
$execute positioned $(zx) 313 $(zz) run fill ~9 ~ ~9 ~9 ~6 ~9 oak_leaves[persistent=true]
$execute positioned $(zx) 318 $(zz) run fill ~7 ~ ~7 ~11 ~1 ~11 azalea_leaves[persistent=true]
$execute positioned $(zx) 313 $(zz) run fill ~9 ~ ~36 ~9 ~5 ~36 oak_leaves[persistent=true]
$execute positioned $(zx) 317 $(zz) run fill ~7 ~ ~34 ~11 ~1 ~38 flowering_azalea_leaves[persistent=true]
$execute positioned $(zx) 314 $(zz) run fill ~36 ~ ~10 ~36 ~5 ~10 oak_leaves[persistent=true]
$execute positioned $(zx) 318 $(zz) run fill ~34 ~ ~8 ~38 ~1 ~12 azalea_leaves[persistent=true]

# === BRANCH-WALK + LEAP PARKOUR — solid log + leaf-block beams strung from the scaffold top out
# over an open gap to the prime grove. Solid blocks (no gravity/support dependency). Spacing is
# jumpable; a missed jump drops into the canopy/floor below (costs time, not the run). Beams rise
# Y314 -> Y320 to read as climbing out across the treetops to the high old-growth grove. ===
$execute positioned $(zx) 314 $(zz) run setblock ~28 ~ ~24 stripped_oak_log[axis=x]
$execute positioned $(zx) 314 $(zz) run setblock ~30 ~ ~25 oak_leaves[persistent=true]
$execute positioned $(zx) 315 $(zz) run setblock ~30 ~ ~27 stripped_spruce_log[axis=z]
$execute positioned $(zx) 315 $(zz) run setblock ~32 ~ ~29 stripped_jungle_log[axis=x]
$execute positioned $(zx) 316 $(zz) run setblock ~34 ~ ~31 oak_leaves[persistent=true]
$execute positioned $(zx) 316 $(zz) run setblock ~36 ~ ~33 stripped_oak_log[axis=x]
$execute positioned $(zx) 317 $(zz) run setblock ~38 ~ ~35 stripped_dark_oak_log[axis=z]
$execute positioned $(zx) 318 $(zz) run setblock ~39 ~ ~37 azalea_leaves[persistent=true]
$execute positioned $(zx) 319 $(zz) run setblock ~40 ~ ~38 stripped_birch_log[axis=x]

# === PRIME OLD-GROWTH GROVE — the real raised platform across the gap (Y320 deck, far SE corner).
# A clean podzol terrace ringed by a low mangrove-root rim, planted with extra-tall PRIME giants
# (full log trunks, leaf crowns) — the uncontested old-growth timber the parkour earns. Felling
# these logs counts exactly like anywhere else (the scorer is global); this is simply the prime,
# untouched grove. Kept inside the envelope (offset to ~45, deck Y320, crowns to ~Y323). ===
$execute positioned $(zx) 320 $(zz) run fill ~38 ~ ~36 ~45 ~ ~44 podzol
$execute positioned $(zx) 321 $(zz) run fill ~38 ~ ~36 ~45 ~ ~36 mangrove_roots
$execute positioned $(zx) 321 $(zz) run fill ~38 ~ ~44 ~45 ~ ~44 mangrove_roots
$execute positioned $(zx) 321 $(zz) run fill ~38 ~ ~36 ~38 ~ ~44 mangrove_roots
$execute positioned $(zx) 321 $(zz) run fill ~45 ~ ~36 ~45 ~ ~44 mangrove_roots

# Prime giant 1 — dark oak (tall trunk + crown)
$execute positioned $(zx) 321 $(zz) run fill ~40 ~ ~38 ~40 ~2 ~38 dark_oak_log
$execute positioned $(zx) 323 $(zz) run fill ~39 ~ ~37 ~41 ~ ~39 dark_oak_leaves[persistent=true]
# Prime giant 2 — jungle (tall trunk + crown)
$execute positioned $(zx) 321 $(zz) run fill ~43 ~ ~41 ~43 ~2 ~41 jungle_log
$execute positioned $(zx) 323 $(zz) run fill ~42 ~ ~40 ~44 ~ ~42 jungle_leaves[persistent=true]
# Prime giant 3 — spruce (tall trunk + crown)
$execute positioned $(zx) 321 $(zz) run fill ~40 ~ ~42 ~40 ~2 ~42 spruce_log
$execute positioned $(zx) 323 $(zz) run fill ~39 ~ ~41 ~41 ~ ~43 spruce_leaves[persistent=true]

# === TOPPING-OUT BEACON — a stripped-log + lantern pillar on the grove deck marking the prime
# stand (the "first cut" flag the high grove promises). Lantern stands atop the short pillar.
# Cosmetic; the log delta is still the only scorer. ===
$execute positioned $(zx) 321 $(zz) run fill ~43 ~ ~38 ~43 ~2 ~38 stripped_oak_log[axis=y]
$execute positioned $(zx) 324 $(zz) run setblock ~43 ~ ~38 lantern[hanging=false]

# === LIGHTS — keep the branch-walk + grove readable even under the Blackout dense-canopy pulse.
# A floating sea-lantern over a mid beam (Y317 over the Y316 beam, off to the side) + a light
# block above the grove deck (clear of the beacon pillar at offset 43,38). ===
$execute positioned $(zx) 317 $(zz) run setblock ~36 ~ ~31 sea_lantern
$execute positioned $(zx) 323 $(zz) run setblock ~41 ~ ~40 light[level=15]
