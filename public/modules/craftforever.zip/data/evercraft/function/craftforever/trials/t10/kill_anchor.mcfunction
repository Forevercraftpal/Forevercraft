# Trade Trial — T10 kill this instance's anchor marker (macro)
# Called: function .../t10/kill_anchor with storage evercraft:trials  (pid set)
# Scoped by p$(pid) so it only ever removes THIS instance's anchor (cross-instance isolation).
$kill @e[type=marker,tag=ec.tt_anchor,tag=p$(pid)]
