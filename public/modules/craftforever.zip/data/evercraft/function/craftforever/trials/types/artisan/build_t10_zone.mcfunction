# Artisan T10 — THEMED INSTANCED ZONE (Craft-Trial Complexity Ladder, Wave 6 — FINAL category)
# Run as/at: the trial player, from t10/build_zone (T10 only, AFTER build_t10 laid the base massive
# workshop — 80 wool-sheep + dense cobwebs + flower patches across the floor Y300..305). This ADDS a
# castle-style multi-room depth on top of artisan's signature collect-500-materials: a GRAND-FORGE
# SMITHY zone — a FORGE-PLATFORM LEAP PARKOUR across blackstone/anvil catwalks strung over an open
# LAVA CHANNEL (the molten smelt-bath below), DECOY CRAFTING STATIONS (smithing tables / blast
# furnaces / grindstones that read as prime work-stations but yield NO wool/string/cobweb/flowers —
# the artisan scorer can't count a station, so harvesting them scores nothing), and the real MASTER
# FORGE across the channel (a raised deck stocked with prime wool-sheep + cobweb + flower beds — the
# uncontested prime materials the parkour earns). The thematic bridge to the actual Grand Forge: a
# worthy capstone of the whole ladder.
# Authored to fit the arena envelope (offset 0..47, Y300..324, all cleared by the standard fill_air
# sweep over Y298..325) so the standard teardown clears it — no per-zone teardown.
#
# Modeled on types/lumber/build_t10_zone + types/building/build_t10_zone (the Wave-4/5 reference).
# Uses the scaffolding bottom=true floor-support + solid-block beam idiom (no gravity/support-
# dependent floating blocks) the Building/Lumber waves proved for the catwalk. Keeps artisan's reward
# + the 2% catalyst roll (in artisan/reward) untouched. The scorer is the existing per-tick material
# delta (artisan/track_t10: wool+string+cobweb+6 flowers − ec.tt_snap) — honest "you must GATHER" —
# the zone only changes WHERE the best, uncontested materials stand, never how scoring works. The
# decoy stations are scorer-invisible blocks (a smithing table is not a counted material).

execute store result storage evercraft:trials zx int 1 run scoreboard players get @s ec.tt_arena_x
execute store result storage evercraft:trials zz int 1 run scoreboard players get @s ec.tt_arena_z
function evercraft:craftforever/trials/types/artisan/build_t10_zone_fill with storage evercraft:trials

# Themed intro title — the player arrives onto an instanced grand-forge smithy, the ladder's capstone.
title @s times 5 30 10
title @s subtitle {"text":"The Grand Forge roars to life around you…","color":"gold"}
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.beacon.activate master @s ~ ~ ~ 1 0.7
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.anvil.land master @s ~ ~ ~ 0.6 0.6
