# Farming Arena — Shell (macro)
# Floor at Y=299, HOLLOW air interior Y=300-323, stone-brick walls, ceiling at Y=324.
# The interior MUST be air: filling it solid entombed the player at spawn (suffocation
# death at Y=303-304, where teleport_to_arena drops them) and buried the crop field.

# Floor: tilled earth base (Y=299)
$execute positioned $(ax) 299 $(az) run fill ~ ~ ~ ~47 ~ ~47 coarse_dirt
# Interior air (Y=300-323, split for the 32768 fill limit)
$execute positioned $(ax) 300 $(az) run fill ~ ~ ~ ~47 ~7 ~47 air
$execute positioned $(ax) 308 $(az) run fill ~ ~ ~ ~47 ~7 ~47 air
$execute positioned $(ax) 316 $(az) run fill ~ ~ ~ ~47 ~7 ~47 air
# Walls (stone-brick shell, 1 block thick, Y=300-323)
$execute positioned $(ax) 300 $(az) run fill ~ ~ ~ ~47 ~23 ~ stone_bricks
$execute positioned $(ax) 300 $(az) run fill ~ ~ ~47 ~47 ~23 ~47 stone_bricks
$execute positioned $(ax) 300 $(az) run fill ~ ~ ~ ~ ~23 ~47 stone_bricks
$execute positioned $(ax) 300 $(az) run fill ~47 ~ ~ ~47 ~23 ~47 stone_bricks
# Ceiling: organic frame ring at Y=324, open center to the sky
$execute positioned $(ax) 324 $(az) run fill ~ ~ ~ ~47 ~ ~47 oak_leaves[persistent=true]
$execute positioned $(ax) 324 $(az) run fill ~5 ~ ~5 ~42 ~ ~42 flowering_azalea_leaves[persistent=true]
$execute positioned $(ax) 324 $(az) run fill ~6 ~ ~6 ~41 ~ ~41 air
# Invisible barrier shell — full containment (no falling out / breaking through any block).
# Barriers transmit light + sky, so the open ceilings still read as open. Box: (-1,298,-1)->(48,325,48).
$execute positioned $(ax) 298 $(az) run fill ~-1 ~ ~-1 ~48 ~ ~48 barrier
$execute positioned $(ax) 325 $(az) run fill ~-1 ~ ~-1 ~48 ~ ~48 barrier
$execute positioned $(ax) 298 $(az) run fill ~-1 ~ ~-1 ~48 ~27 ~-1 barrier
$execute positioned $(ax) 298 $(az) run fill ~-1 ~ ~48 ~48 ~27 ~48 barrier
$execute positioned $(ax) 298 $(az) run fill ~-1 ~ ~-1 ~-1 ~27 ~48 barrier
$execute positioned $(ax) 298 $(az) run fill ~48 ~ ~-1 ~48 ~27 ~48 barrier
