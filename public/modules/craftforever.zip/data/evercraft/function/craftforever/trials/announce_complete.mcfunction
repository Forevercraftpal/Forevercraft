# Announce trial completion (actor-naming @a broadcast — §5b direct render, macro)
# (Wave 2, 2026-06-10: trial-complete brag — whoami-baked, protected, 30s TTL.)
function evercraft:util/notify/whoami
$data modify storage evercraft:notify stage.c set value [{text:"",color:"gold"},{text:" completed ",color:"gray"},{text:"$(trial_name) Trial Tier $(tier)",color:"#FFA500",bold:true},{text:"$(hard)",color:"red",bold:true},{text:"!",color:"gray"}]
data modify storage evercraft:notify stage.c[0].text set from storage evercraft:notify named.who
scoreboard players set #ndur ec.temp 50
execute as @a run scoreboard players set #nttl ec.temp 600
execute as @a run function evercraft:util/notify/emit_keep
