# Trade Trials — give ONE accessory crate (folded into the Crate Coin pool).
# Run as/at: the player, from crate_redeem's accessory channel (~20% of coin crates).
# Mirrors accessory_crates/resolve_drop's SET + TIER logic, but self-contained for
# the trial reward (no chest "lay within the chest" flourish — the trial already
# announced the Crate Coins). Expects #inv_full ec.var set (1=drop / 0=give).
#
# SET (#tt_accset ec.temp): Regular blend by default; if the player is on EXACTLY
#   one chronicle, lean to that chronicle's set (matches resolve_drop's plain-chest
#   rule).  1 = Adventurer (dream_rank) / 2 = Crafting (cf_rank) / 3 = Regular blend
scoreboard players set #tt_accset ec.temp 3
execute if score @s ec.dream_rank matches 1.. unless score @s ec.cf_rank matches 1.. run scoreboard players set #tt_accset ec.temp 1
execute if score @s ec.cf_rank matches 1.. unless score @s ec.dream_rank matches 1.. run scoreboard players set #tt_accset ec.temp 2

# TIER (#tt_acctier ec.temp): common 55 / uncommon 25 / rare 12 / ornate 5 / exquisite 2 / mythical 1
execute store result score #tt_acctier ec.temp run random value 1..100

# --- ADV set ---
execute if score #tt_accset ec.temp matches 1 if score #tt_acctier ec.temp matches 1..55 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:crates/items/accessory_adv_common
execute if score #tt_accset ec.temp matches 1 if score #tt_acctier ec.temp matches 1..55 if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:crates/items/accessory_adv_common
execute if score #tt_accset ec.temp matches 1 if score #tt_acctier ec.temp matches 56..80 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:crates/items/accessory_adv_uncommon
execute if score #tt_accset ec.temp matches 1 if score #tt_acctier ec.temp matches 56..80 if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:crates/items/accessory_adv_uncommon
execute if score #tt_accset ec.temp matches 1 if score #tt_acctier ec.temp matches 81..92 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:crates/items/accessory_adv_rare
execute if score #tt_accset ec.temp matches 1 if score #tt_acctier ec.temp matches 81..92 if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:crates/items/accessory_adv_rare
execute if score #tt_accset ec.temp matches 1 if score #tt_acctier ec.temp matches 93..97 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:crates/items/accessory_adv_ornate
execute if score #tt_accset ec.temp matches 1 if score #tt_acctier ec.temp matches 93..97 if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:crates/items/accessory_adv_ornate
execute if score #tt_accset ec.temp matches 1 if score #tt_acctier ec.temp matches 98..99 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:crates/items/accessory_adv_exquisite
execute if score #tt_accset ec.temp matches 1 if score #tt_acctier ec.temp matches 98..99 if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:crates/items/accessory_adv_exquisite
execute if score #tt_accset ec.temp matches 1 if score #tt_acctier ec.temp matches 100 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:crates/items/accessory_adv_mythical
execute if score #tt_accset ec.temp matches 1 if score #tt_acctier ec.temp matches 100 if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:crates/items/accessory_adv_mythical

# --- CRAFT set ---
execute if score #tt_accset ec.temp matches 2 if score #tt_acctier ec.temp matches 1..55 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:crates/items/accessory_craft_common
execute if score #tt_accset ec.temp matches 2 if score #tt_acctier ec.temp matches 1..55 if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:crates/items/accessory_craft_common
execute if score #tt_accset ec.temp matches 2 if score #tt_acctier ec.temp matches 56..80 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:crates/items/accessory_craft_uncommon
execute if score #tt_accset ec.temp matches 2 if score #tt_acctier ec.temp matches 56..80 if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:crates/items/accessory_craft_uncommon
execute if score #tt_accset ec.temp matches 2 if score #tt_acctier ec.temp matches 81..92 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:crates/items/accessory_craft_rare
execute if score #tt_accset ec.temp matches 2 if score #tt_acctier ec.temp matches 81..92 if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:crates/items/accessory_craft_rare
execute if score #tt_accset ec.temp matches 2 if score #tt_acctier ec.temp matches 93..97 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:crates/items/accessory_craft_ornate
execute if score #tt_accset ec.temp matches 2 if score #tt_acctier ec.temp matches 93..97 if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:crates/items/accessory_craft_ornate
execute if score #tt_accset ec.temp matches 2 if score #tt_acctier ec.temp matches 98..99 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:crates/items/accessory_craft_exquisite
execute if score #tt_accset ec.temp matches 2 if score #tt_acctier ec.temp matches 98..99 if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:crates/items/accessory_craft_exquisite
execute if score #tt_accset ec.temp matches 2 if score #tt_acctier ec.temp matches 100 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:crates/items/accessory_craft_mythical
execute if score #tt_accset ec.temp matches 2 if score #tt_acctier ec.temp matches 100 if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:crates/items/accessory_craft_mythical

# --- REG set ---
execute if score #tt_accset ec.temp matches 3 if score #tt_acctier ec.temp matches 1..55 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:crates/items/accessory_reg_common
execute if score #tt_accset ec.temp matches 3 if score #tt_acctier ec.temp matches 1..55 if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:crates/items/accessory_reg_common
execute if score #tt_accset ec.temp matches 3 if score #tt_acctier ec.temp matches 56..80 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:crates/items/accessory_reg_uncommon
execute if score #tt_accset ec.temp matches 3 if score #tt_acctier ec.temp matches 56..80 if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:crates/items/accessory_reg_uncommon
execute if score #tt_accset ec.temp matches 3 if score #tt_acctier ec.temp matches 81..92 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:crates/items/accessory_reg_rare
execute if score #tt_accset ec.temp matches 3 if score #tt_acctier ec.temp matches 81..92 if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:crates/items/accessory_reg_rare
execute if score #tt_accset ec.temp matches 3 if score #tt_acctier ec.temp matches 93..97 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:crates/items/accessory_reg_ornate
execute if score #tt_accset ec.temp matches 3 if score #tt_acctier ec.temp matches 93..97 if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:crates/items/accessory_reg_ornate
execute if score #tt_accset ec.temp matches 3 if score #tt_acctier ec.temp matches 98..99 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:crates/items/accessory_reg_exquisite
execute if score #tt_accset ec.temp matches 3 if score #tt_acctier ec.temp matches 98..99 if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:crates/items/accessory_reg_exquisite
execute if score #tt_accset ec.temp matches 3 if score #tt_acctier ec.temp matches 100 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:crates/items/accessory_reg_mythical
execute if score #tt_accset ec.temp matches 3 if score #tt_acctier ec.temp matches 100 if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:crates/items/accessory_reg_mythical
