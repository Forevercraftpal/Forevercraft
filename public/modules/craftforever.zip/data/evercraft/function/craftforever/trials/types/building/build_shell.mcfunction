# Building Arena — Build shell (macro)
# Stone box 48x25x48 at Y=299-324
# Floor at Y=299, walls Y=300-323, ceiling at Y=324
# Interior cleared to air for building space

# Floor (48x1x48)
# Floor: meadow build surface (Y=299)
$execute positioned $(ax) 299 $(az) run fill ~ ~ ~ ~47 ~ ~47 grass_block
$execute positioned $(ax) 299 $(az) run fill ~8 ~ ~8 ~18 ~ ~18 podzol
$execute positioned $(ax) 299 $(az) run fill ~28 ~ ~28 ~40 ~ ~40 coarse_dirt
$execute positioned $(ax) 299 $(az) run fill ~22 ~ ~6 ~30 ~ ~14 moss_block

# Walls — fill entire volume with stone first, then hollow interior
# Fill outer shell (48x25x48 from Y=300 to Y=323)
# Split into chunks to stay under 32768 block limit (48x8x48 = 18432)
$execute positioned $(ax) 300 $(az) run fill ~ ~ ~ ~47 ~7 ~47 stone
$execute positioned $(ax) 308 $(az) run fill ~ ~ ~ ~47 ~7 ~47 stone
$execute positioned $(ax) 316 $(az) run fill ~ ~ ~ ~47 ~7 ~47 stone

# Ceiling: organic frame ring at Y=324, open center to the sky
$execute positioned $(ax) 324 $(az) run fill ~ ~ ~ ~47 ~ ~47 mossy_stone_bricks
$execute positioned $(ax) 324 $(az) run fill ~5 ~ ~5 ~42 ~ ~42 oak_leaves[persistent=true]
$execute positioned $(ax) 324 $(az) run fill ~6 ~ ~6 ~41 ~ ~41 air

# Hollow out interior (leave 1-block thick walls)
# Interior: 46x23x46 from Y=300 to Y=323, offset +1 from edges
# Split into chunks (46x8x46 = 16928)
$execute positioned $(ax) 300 $(az) run fill ~1 ~ ~1 ~46 ~7 ~46 air
$execute positioned $(ax) 308 $(az) run fill ~1 ~ ~1 ~46 ~7 ~46 air
$execute positioned $(ax) 316 $(az) run fill ~1 ~ ~1 ~46 ~7 ~46 air
# Invisible barrier shell — full containment (no falling out / breaking through any block).
# Barriers transmit light + sky, so the open ceilings still read as open. Box: (-1,298,-1)->(48,325,48).
$execute positioned $(ax) 298 $(az) run fill ~-1 ~ ~-1 ~48 ~ ~48 barrier
$execute positioned $(ax) 325 $(az) run fill ~-1 ~ ~-1 ~48 ~ ~48 barrier
$execute positioned $(ax) 298 $(az) run fill ~-1 ~ ~-1 ~48 ~27 ~-1 barrier
$execute positioned $(ax) 298 $(az) run fill ~-1 ~ ~48 ~48 ~27 ~48 barrier
$execute positioned $(ax) 298 $(az) run fill ~-1 ~ ~-1 ~-1 ~27 ~48 barrier
$execute positioned $(ax) 298 $(az) run fill ~48 ~ ~-1 ~48 ~27 ~48 barrier
