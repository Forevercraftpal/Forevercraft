# Trade Trial — Daily Challenge Completed!
# Run as/at: the player who matched the daily challenge

scoreboard players set @s ec.tt_daily_done 1

data modify storage evercraft:notify stage.c set value [{text:"\u2726 ",color:"gold"},{text:"DAILY CHALLENGE COMPLETE!",color:"yellow",bold:true},{text:" \u2726",color:"gold"}]
scoreboard players set #ndur ec.temp 50
function evercraft:util/notify/emit

# Bonus rewards: 5 crate coins + bonus XP. Tallied + auto-redeemed into actual
# crates (NOT the Castle's wiped ic.coins \u2014 see craftforever/trials/crate_redeem).
scoreboard players set #tt_crate_n ec.var 5
scoreboard players set #tt_crate_warned ec.var 0
data modify storage evercraft:notify stage.c set value [{text:"\u2726 ",color:"gold"},{text:"+5 Bonus Crate Coins",color:"yellow"},{text:" (Daily Reward)",color:"gray"}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit
function evercraft:craftforever/trials/crate_redeem

scoreboard players add @s ec.cf_xp 500
data modify storage evercraft:notify stage.c set value [{text:"\u2726 ",color:"gold"},{text:"+500 Bonus Artisan XP",color:"green"},{text:" (Daily Reward)",color:"gray"}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit
# P1-9 cf_xp drift quick-fix: direct ec.cf_xp write bypasses add_xp, so fire check_levelup.
function evercraft:craftforever/artisan/check_levelup

# Bonus artifact
# Inv-full guard: drop at the player's feet rather than void on a full inventory.
execute store result score #inv_full ec.var run function evercraft:util/check_inv_full
execute if score #inv_full ec.var matches 0 run loot give @s loot evercraft:artifacts/ornate/main
execute if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:artifacts/ornate/main
data modify storage evercraft:notify stage.c set value [{text:"\u2605 ",color:"dark_purple"},{text:"Ornate Artifact",color:"dark_purple",bold:true},{text:" \u2014 Daily Challenge Bonus!",color:"gray"}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit

execute if score @s ec.fx_snd matches 1.. run playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 1 1.2
particle minecraft:firework ~ ~1 ~ 1 1 1 0.5 25
