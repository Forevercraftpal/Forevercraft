# Spirit-Tool Pity — drop the rolled spirit tool at the player's feet (MACRO)
# Called from spirit_pity_roll on a HIT when the inventory is full.
#   storage evercraft:trials sp.cat = loot-table folder (mining/.../artisan)
$execute at @s run loot spawn ~ ~ ~ loot evercraft:craftforever/trials/$(cat)/spirit_drop
