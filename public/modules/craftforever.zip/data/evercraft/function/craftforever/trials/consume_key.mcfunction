# === TRIAL PASS — FULL-WEAR ON TRIAL START (Chest-Node §3 key lifecycle) ===
# Run as @s = player, from trials/start (gated to a non-daily trial that passed the pass + lockout
# checks). A Trial Pass now PERSISTS through a trial and follows the worn/cracked/break lifecycle like a
# Dungeon Key, instead of vanishing on first use. Doing a trial CRACKS the pass (mirror of the dungeon
# key's cracked path). The trial-start gate (start:39) only admits a FRESH or WORN pass — a CRACKED pass
# can no longer start a trial (cracked = chests only), so the pass consumed here is FRESH or WORN.
#
# Decision (§3 key lifecycle), mirroring dungeon/key_handback:
#   • FRESH pass (not worn) -> CRACK it: clear the fresh pass + re-give a CRACKED copy. The player keeps a
#     pass that is now cracked — it still opens chest nodes (where do_open marks it worn -> worn AND
#     cracked -> it breaks on that chest attempt), but it can no longer start a trial.
#   • WORN pass -> it is now worn AND cracked = it BREAKS. Clear it, re-give nothing, play the shatter cue.
# The pass is GUI-consumed (cleared by command), not vanilla-consumed, so we mark it in place
# synchronously here — no deferred re-give (the dungeon key needs key_handback only because RC vanilla-
# eats it before start can inspect its NBT; the trial pass never leaves the inventory).
#
# Clear order = most-specific first so the consumed pass is counted exactly once: a worn-AND-cracked pass
# can't exist (it would have broken), and a cracked pass can't reach here (gated at start), so the only
# forms present are WORN and FRESH. Clear WORN first (the break case), then FRESH (the crack case).

# WORN pass consumed -> worn AND cracked -> BREAK (no re-give). #tt_pass_broke=1 marks the break.
scoreboard players set #tt_pass_broke ec.temp 0
execute store result score #tt_pass_broke ec.temp run clear @s minecraft:trial_key[custom_data~{trial_pass:1b,worn:1b}] 1

# FRESH pass consumed (only if no worn pass was just cleared) -> CRACK it: clear + re-give a cracked copy.
execute if score #tt_pass_broke ec.temp matches 0 run clear @s minecraft:trial_key[custom_data~{trial_pass:1b}] 1
# Inv-full guard: drop at the player's feet rather than void on a full inventory.
execute store result score #inv_full ec.var run function evercraft:util/check_inv_full
execute if score #tt_pass_broke ec.temp matches 0 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:craftforever/trials/trial_pass_cracked
execute if score #tt_pass_broke ec.temp matches 0 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:craftforever/trials/trial_pass_cracked

# Shatter cue for the break case (worn pass gave its last turn).
execute if score #tt_pass_broke ec.temp matches 1 at @s if score @s ec.fx_snd matches 1.. run playsound minecraft:block.glass.break master @s ~ ~ ~ 0.8 0.9
data modify storage evercraft:notify stage.c set value [{text:"⚙ ",color:"#B87333"},{text:"The Trial Pass shattered",color:"red"},{text:" — worn and cracked, it gave its last turn.",color:"gray"}]
scoreboard players set #ndur ec.temp 50
execute if score #tt_pass_broke ec.temp matches 1 run function evercraft:util/notify/emit
