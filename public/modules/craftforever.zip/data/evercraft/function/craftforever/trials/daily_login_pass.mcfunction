# D1 (Trial Pass — broaden): per-player Mon/Wed/Fri-cadence daily Trial Pass drop.
# Runs once per player at morning_announce; gated on #tp_drop_day (set in news/dawn_reset)
# + a per-player day stamp so the grant survives /reload and second logins.
# Run as @s = player.

execute unless score #tp_drop_day ec.var matches 1 run return 0
execute if score @s ec.tp_daily_day = #cur_day ec.var run return 0

scoreboard players operation @s ec.tp_daily_day = #cur_day ec.var

# Inv-full guard: drop at the player's feet rather than void on a full inventory.
execute store result score #inv_full ec.var run function evercraft:util/check_inv_full
execute at @s if score #inv_full ec.var matches 0 run loot give @s loot evercraft:craftforever/trials/trial_pass
execute at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:craftforever/trials/trial_pass
data modify storage evercraft:notify stage.c set value [{text:"★ ",color:"gold"},{text:"Trial Pass",color:"#FFD700",bold:true},{text:" delivered with the morning post.",color:"gray"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.experience_orb.pickup player @s ~ ~ ~ 0.6 1.4
