# Artisan Arena — Build shell (macro)
# Stone box 48x25x48 at Y=299-324

# Floor (48x1x48 at Y=299)
# Floor: wooden workshop floor with beams (Y=299)
$execute positioned $(ax) 299 $(az) run fill ~ ~ ~ ~47 ~ ~47 oak_planks
$execute positioned $(ax) 299 $(az) run fill ~ ~ ~10 ~47 ~ ~10 stripped_oak_log
$execute positioned $(ax) 299 $(az) run fill ~ ~ ~24 ~47 ~ ~24 stripped_oak_log
$execute positioned $(ax) 299 $(az) run fill ~ ~ ~38 ~47 ~ ~38 stripped_oak_log

# Walls — fill interior with air first, then walls are just the shell edges
# Fill interior air (48x24x48 from Y=300 to Y=323)
# Split into chunks to stay under 32768 block limit (48x8x48 = 18432)
$execute positioned $(ax) 300 $(az) run fill ~ ~ ~ ~47 ~7 ~47 air
$execute positioned $(ax) 308 $(az) run fill ~ ~ ~ ~47 ~7 ~47 air
$execute positioned $(ax) 316 $(az) run fill ~ ~ ~ ~47 ~7 ~47 air

# Walls (stone bricks shell — 1 block thick on all 4 sides)
# North wall (Z=az)
$execute positioned $(ax) 300 $(az) run fill ~ ~ ~ ~47 ~23 ~ stone_bricks
# South wall (Z=az+47)
$execute positioned $(ax) 300 $(az) run fill ~ ~ ~47 ~47 ~23 ~47 stone_bricks
# West wall (X=ax)
$execute positioned $(ax) 300 $(az) run fill ~ ~ ~ ~ ~23 ~47 stone_bricks
# East wall (X=ax+47)
$execute positioned $(ax) 300 $(az) run fill ~47 ~ ~ ~47 ~23 ~47 stone_bricks

# Ceiling: organic frame ring at Y=324, open center to the sky
$execute positioned $(ax) 324 $(az) run fill ~ ~ ~ ~47 ~ ~47 oak_log
$execute positioned $(ax) 324 $(az) run fill ~5 ~ ~5 ~42 ~ ~42 oak_leaves[persistent=true]
$execute positioned $(ax) 324 $(az) run fill ~6 ~ ~6 ~41 ~ ~41 air
# Invisible barrier shell — full containment (no falling out / breaking through any block).
# Barriers transmit light + sky, so the open ceilings still read as open. Box: (-1,298,-1)->(48,325,48).
$execute positioned $(ax) 298 $(az) run fill ~-1 ~ ~-1 ~48 ~ ~48 barrier
$execute positioned $(ax) 325 $(az) run fill ~-1 ~ ~-1 ~48 ~ ~48 barrier
$execute positioned $(ax) 298 $(az) run fill ~-1 ~ ~-1 ~48 ~27 ~-1 barrier
$execute positioned $(ax) 298 $(az) run fill ~-1 ~ ~48 ~48 ~27 ~48 barrier
$execute positioned $(ax) 298 $(az) run fill ~-1 ~ ~-1 ~-1 ~27 ~48 barrier
$execute positioned $(ax) 298 $(az) run fill ~48 ~ ~-1 ~48 ~27 ~48 barrier
