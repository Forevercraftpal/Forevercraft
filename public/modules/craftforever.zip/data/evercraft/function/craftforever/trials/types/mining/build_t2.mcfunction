# Mining T2: Mine 32 iron ore.
# The player drops into the 5x5 spawn pocket at the arena CENTRE (offset 22..26, Y300-304) and
# mines outward through solid stone with ~75s on the clock. The old layout flung 10 veins to the
# far corners at Y301..319 (several up near the Y324 ceiling), so a player tunnelling from centre
# realistically reached only one or two before time ran out — iron read as "two blobs."
#
# New layout: a RING of veins close to spawn so iron is struck in ANY tunnelling direction within
# a few blocks, plus outer veins for spread — ALL kept in the low/mid reachable band (Y300..305,
# right at the player's level), never up by the ceiling. Total ~270 ore for a target of 32, so the
# trial is findable/finishable; the time pressure + modifiers keep it a challenge.
# (Variety blocks are placed FIRST so a vein is never overwritten by a granite/diorite patch.)

# --- Visual variety (placed first, low Y, away from the vein anchors) ---
$execute positioned $(ax) 304 $(az) run fill ~8 ~ ~28 ~12 ~2 ~32 granite
$execute positioned $(ax) 303 $(az) run fill ~34 ~ ~16 ~38 ~2 ~20 diorite

# --- Inner ring: 8 veins ~6-10 blocks out from the centre spawn, at the player's level (Y301-303) ---
$execute positioned $(ax) 301 $(az) run fill ~14 ~ ~22 ~16 ~1 ~24 iron_ore
$execute positioned $(ax) 302 $(az) run fill ~30 ~ ~22 ~32 ~1 ~24 iron_ore
$execute positioned $(ax) 302 $(az) run fill ~22 ~ ~14 ~24 ~1 ~16 iron_ore
$execute positioned $(ax) 301 $(az) run fill ~22 ~ ~30 ~24 ~1 ~32 iron_ore
$execute positioned $(ax) 303 $(az) run fill ~14 ~ ~14 ~16 ~1 ~16 iron_ore
$execute positioned $(ax) 302 $(az) run fill ~30 ~ ~30 ~32 ~1 ~32 iron_ore
$execute positioned $(ax) 303 $(az) run fill ~30 ~ ~14 ~32 ~1 ~16 iron_ore
$execute positioned $(ax) 302 $(az) run fill ~14 ~ ~30 ~16 ~1 ~32 iron_ore

# --- Outer veins: more iron toward the edges, still in the reachable band (Y302-305) ---
$execute positioned $(ax) 303 $(az) run fill ~5 ~ ~8 ~8 ~1 ~10 iron_ore
$execute positioned $(ax) 304 $(az) run fill ~38 ~ ~6 ~41 ~1 ~8 iron_ore
$execute positioned $(ax) 304 $(az) run fill ~6 ~ ~38 ~9 ~1 ~40 iron_ore
$execute positioned $(ax) 305 $(az) run fill ~38 ~ ~38 ~41 ~1 ~40 iron_ore
$execute positioned $(ax) 303 $(az) run fill ~40 ~ ~22 ~42 ~1 ~24 iron_ore
$execute positioned $(ax) 303 $(az) run fill ~22 ~ ~40 ~24 ~1 ~42 iron_ore
