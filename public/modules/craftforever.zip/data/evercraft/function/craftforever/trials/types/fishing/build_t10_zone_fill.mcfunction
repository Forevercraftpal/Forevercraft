# Fishing T10 themed zone — geometry (macro)
# Called: function .../fishing/build_t10_zone_fill with storage evercraft:trials  (zx,zz set)
# All offsets stay inside the arena envelope (0..47, Y300..323) and the fill_air sweep clears
# Y298..325 -> every block here is torn down by the standard teardown (no per-zone teardown).
#
# The base build_t10 already laid the 4-deep Leviathan's Pool (water Y300-303) + the central dry
# dock (planks Y300-302, dry pocket offset 20..28 at Y303). This zone ADDS, in the open air band
# ABOVE the water surface (Y304+), a multi-room aquatic reach:
#   * an AQUATIC PARKOUR of buoy / lily-pad / boat-deck stepping stones out over the open pool,
#   * DECOY bobber-buoys over the kelp-choked near shallows (look prime, the kelp fouls the line),
#   * a far PRIME-DEEP fishing pier over CLEAR open water (kelp cleared) reachable ONLY across the
#     jump — the uncontested casting spot — with a sea-treasure pillar selling the depth.
# The central dry dock pocket (offset 19..29, Y303-304) is left untouched so the player still
# spawns dry. Scoring is the existing catch counter (fishing/tick) — the zone only moves the BEST
# casting spot behind the parkour gap; it never changes how a catch is counted.

# === DECOY BOBBER-BUOYS — near the dock over the kelp-choked NW shallows (look prime, foul) ===
# These ring the kelp the base build_t10 planted at offset 5..15: lily pads + a fence "post"
# that reads as a marked fishing spot, but the kelp underneath fouls the cast (no clear water).
$execute positioned $(zx) 304 $(zz) run setblock ~8 ~ ~8 lily_pad
$execute positioned $(zx) 304 $(zz) run setblock ~12 ~ ~10 lily_pad
$execute positioned $(zx) 304 $(zz) run setblock ~10 ~ ~14 lily_pad
$execute positioned $(zx) 304 $(zz) run setblock ~14 ~ ~6 oak_fence
$execute positioned $(zx) 305 $(zz) run setblock ~14 ~ ~6 sea_pickle[pickles=3,waterlogged=false]
$execute positioned $(zx) 304 $(zz) run setblock ~6 ~ ~12 oak_fence
$execute positioned $(zx) 305 $(zz) run setblock ~6 ~ ~12 sea_pickle[pickles=2,waterlogged=false]

# === A SECOND DECOY — a derelict "boat" deck in the SW, also over choked water (no clear lane) ===
$execute positioned $(zx) 304 $(zz) run fill ~6 ~ ~34 ~10 ~ ~38 oak_planks
$execute positioned $(zx) 305 $(zz) run setblock ~8 ~ ~34 oak_fence
$execute positioned $(zx) 305 $(zz) run setblock ~8 ~ ~38 oak_fence
$execute positioned $(zx) 306 $(zz) run setblock ~8 ~ ~36 lantern[hanging=true]

# === AQUATIC PARKOUR — buoy / lily-pad / boat-deck stepping stones from the dock out to the
# far pier. Spacing is jumpable; a missed jump just drops into the water (costs time, not the
# run). Stones rise gently (Y305 -> Y308) so the traverse reads as climbing out over the pool. ===
$execute positioned $(zx) 305 $(zz) run setblock ~31 ~ ~24 oak_planks
$execute positioned $(zx) 305 $(zz) run setblock ~34 ~ ~22 mangrove_roots
$execute positioned $(zx) 306 $(zz) run setblock ~37 ~ ~25 oak_planks
$execute positioned $(zx) 306 $(zz) run setblock ~40 ~ ~28 mangrove_roots
$execute positioned $(zx) 307 $(zz) run setblock ~42 ~ ~31 oak_planks
$execute positioned $(zx) 307 $(zz) run setblock ~41 ~ ~35 mangrove_roots
$execute positioned $(zx) 308 $(zz) run setblock ~40 ~ ~38 oak_planks

# === PRIME-DEEP POOL — clear the base kelp from the far SE corner so it reads as open, clear
# deep water (the real prime fishing lane the parkour earns). Kelp/seagrass -> water. ===
$execute positioned $(zx) 300 $(zz) run fill ~36 ~ ~36 ~45 ~3 ~45 water replace kelp
$execute positioned $(zx) 300 $(zz) run fill ~36 ~ ~36 ~45 ~3 ~45 water replace seagrass

# === PRIME PIER — a small platform at the far landing (Y308), only reachable across the jump.
# This is the uncontested clear-water casting spot. ===
$execute positioned $(zx) 308 $(zz) run fill ~39 ~ ~38 ~43 ~ ~42 oak_planks
$execute positioned $(zx) 309 $(zz) run setblock ~39 ~ ~38 oak_fence
$execute positioned $(zx) 309 $(zz) run setblock ~43 ~ ~38 oak_fence
$execute positioned $(zx) 309 $(zz) run setblock ~39 ~ ~42 oak_fence
$execute positioned $(zx) 309 $(zz) run setblock ~43 ~ ~42 oak_fence

# === SEA-TREASURE PILLAR — a prismarine + sea-lantern beacon on the prime pier marking the deep
# (the "great catch" the depth promises). Cosmetic; the catch counter is still the only scorer. ===
$execute positioned $(zx) 309 $(zz) run setblock ~41 ~ ~40 prismarine_bricks
$execute positioned $(zx) 310 $(zz) run setblock ~41 ~ ~40 sea_lantern
$execute positioned $(zx) 311 $(zz) run setblock ~41 ~ ~40 conduit

# === LIGHTS on the parkour + prime pier so the traverse stays readable even under the Blackout
# silt pulse. A floating sea-lantern ONE block ABOVE a mid stepping stone (Y308 over the Y307
# stone, so it lights the jump without blocking the landing) + a light block over the pier. ===
$execute positioned $(zx) 308 $(zz) run setblock ~42 ~ ~31 sea_lantern
$execute positioned $(zx) 312 $(zz) run fill ~41 ~ ~40 ~41 ~ ~40 light[level=15]
