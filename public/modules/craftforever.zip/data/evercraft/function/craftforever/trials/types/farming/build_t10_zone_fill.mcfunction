# Farming T10 themed zone — geometry (macro)
# Called: function .../farming/build_t10_zone_fill with storage evercraft:trials  (zx,zz set)
# All offsets stay inside the arena envelope (0..47, Y300..324) -> cleared by fill_air.
#
# The base build_t10 already laid the two-level main field (Y300-301, Y305-306). This zone
# ADDS a TERRACED UPPER GARDEN in the free upper band (Y309..322): three raised terraces, a
# PARKOUR traverse of hay-bale stepping stones across a wide irrigation channel, DECOY rows of
# unripe crops (look ripe, score nothing), and a RIPE reward bed only reachable across the jump.
# "Only ripe crops score" twist is honest: the harvest counter only ticks on mature (age=7)
# crops, so the unripe decoy rows the player chases never count — the real bed is past the gap.

# --- Carve the upper-garden air pocket (clear the band above the level-2 field) ---
$execute positioned $(zx) 309 $(zz) run fill ~2 ~ ~2 ~46 ~13 ~46 air

# === TERRACE A — low near-terrace (Y310), the safe staging garden ===
$execute positioned $(zx) 310 $(zz) run fill ~4 ~ ~4 ~20 ~ ~20 dirt
$execute positioned $(zx) 310 $(zz) run fill ~4 ~ ~10 ~20 ~ ~10 water
$execute positioned $(zx) 310 $(zz) run fill ~4 ~ ~4 ~20 ~ ~9 farmland
$execute positioned $(zx) 310 $(zz) run fill ~4 ~ ~11 ~20 ~ ~20 farmland
# DECOY rows: unripe wheat + carrots (look like a crop, but age<7 -> never harvest-counts).
$execute positioned $(zx) 311 $(zz) run fill ~4 ~ ~4 ~20 ~ ~9 wheat[age=2]
$execute positioned $(zx) 311 $(zz) run fill ~4 ~ ~11 ~20 ~ ~20 carrots[age=3]

# === IRRIGATION CHANNEL — the wide water gap the parkour spans (Y309 water trough) ===
$execute positioned $(zx) 309 $(zz) run fill ~4 ~ ~22 ~44 ~ ~30 dirt
$execute positioned $(zx) 310 $(zz) run fill ~5 ~ ~23 ~43 ~ ~29 water

# === PARKOUR TRAVERSE — hay-bale stepping stones across the channel at Y312 ===
# Jumpable spacing; failing a jump just drops into the water (costs time, not the run).
$execute positioned $(zx) 312 $(zz) run setblock ~8 ~ ~26 hay_block
$execute positioned $(zx) 312 $(zz) run setblock ~12 ~ ~24 hay_block
$execute positioned $(zx) 313 $(zz) run setblock ~16 ~ ~27 hay_block
$execute positioned $(zx) 313 $(zz) run setblock ~20 ~ ~25 hay_block
$execute positioned $(zx) 314 $(zz) run setblock ~24 ~ ~28 hay_block
$execute positioned $(zx) 314 $(zz) run setblock ~28 ~ ~25 hay_block
$execute positioned $(zx) 315 $(zz) run setblock ~32 ~ ~27 hay_block
$execute positioned $(zx) 315 $(zz) run setblock ~36 ~ ~26 hay_block

# === TERRACE B — the high RIPE reward bed (Y316), only reachable across the parkour ===
$execute positioned $(zx) 316 $(zz) run fill ~36 ~ ~30 ~46 ~ ~46 dirt
$execute positioned $(zx) 316 $(zz) run fill ~36 ~ ~38 ~46 ~ ~38 water
$execute positioned $(zx) 316 $(zz) run fill ~36 ~ ~30 ~46 ~ ~37 farmland
$execute positioned $(zx) 316 $(zz) run fill ~36 ~ ~39 ~46 ~ ~46 farmland
# RIPE crops (age=7 / beetroot age=3) — these DO feed the harvest counter (the real prize).
$execute positioned $(zx) 317 $(zz) run fill ~36 ~ ~30 ~46 ~ ~33 wheat[age=7]
$execute positioned $(zx) 317 $(zz) run fill ~36 ~ ~34 ~46 ~ ~37 carrots[age=7]
$execute positioned $(zx) 317 $(zz) run fill ~36 ~ ~39 ~46 ~ ~42 potatoes[age=7]
$execute positioned $(zx) 317 $(zz) run fill ~36 ~ ~43 ~46 ~ ~46 beetroots[age=3]

# === DECOY garden patch — a lush-looking but unripe corner far from the prize ===
$execute positioned $(zx) 310 $(zz) run fill ~26 ~ ~4 ~44 ~ ~18 dirt
$execute positioned $(zx) 310 $(zz) run fill ~26 ~ ~4 ~44 ~ ~18 farmland
$execute positioned $(zx) 311 $(zz) run fill ~26 ~ ~4 ~44 ~ ~10 potatoes[age=3]
$execute positioned $(zx) 311 $(zz) run fill ~26 ~ ~12 ~44 ~ ~18 beetroots[age=1]
# A couple of composters in the decoy patch to sell the "ready harvest" illusion.
$execute positioned $(zx) 311 $(zz) run setblock ~30 ~ ~6 composter[level=7]
$execute positioned $(zx) 311 $(zz) run setblock ~38 ~ ~14 composter[level=7]

# === Lanterns / lights so the terraces stay readable (esp. under the Blackout storm) ===
$execute positioned $(zx) 322 $(zz) run fill ~12 ~ ~12 ~12 ~ ~12 light[level=15]
$execute positioned $(zx) 322 $(zz) run fill ~40 ~ ~40 ~40 ~ ~40 light[level=15]
$execute positioned $(zx) 313 $(zz) run setblock ~24 ~ ~28 shroomlight
