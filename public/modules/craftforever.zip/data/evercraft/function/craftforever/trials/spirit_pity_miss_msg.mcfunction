# Spirit-Tool Pity — climbing-odds line on a T10 clear that did NOT drop (MACRO). Run as @s.
#   storage evercraft:trials sp.tool = display name of the spirit tool ("Earthsong", ...)
#   storage evercraft:trials sp.odds = effective drop odds (percent) now, after this clear
$data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gray"},{text:"$(tool)",color:"yellow"},{text:" Spirit Tool odds for this craft: now ",color:"gray"},{text:"$(odds)%",color:"aqua",bold:true}]
scoreboard players set #ndur ec.temp 55
function evercraft:util/notify/emit
