# Trade Trial — compute the forceload chunk-box for THIS arena into storage (fx1,fz1,fx2,fz2).
# Run as the trial player (reads ec.tt_arena_x/z). Box = (ax-16, az-16) .. (ax+63, az+63): a
# generous wrap around the -11..+58 clear envelope so every chunk the build/teardown touches is
# loaded. `forceload` is column-based (X/Z only) and loads any chunk containing these blocks.
scoreboard players operation #tt_fb ec.var = @s ec.tt_arena_x
scoreboard players remove #tt_fb ec.var 16
execute store result storage evercraft:trials fx1 int 1 run scoreboard players get #tt_fb ec.var
scoreboard players operation #tt_fb ec.var = @s ec.tt_arena_x
scoreboard players add #tt_fb ec.var 63
execute store result storage evercraft:trials fx2 int 1 run scoreboard players get #tt_fb ec.var
scoreboard players operation #tt_fb ec.var = @s ec.tt_arena_z
scoreboard players remove #tt_fb ec.var 16
execute store result storage evercraft:trials fz1 int 1 run scoreboard players get #tt_fb ec.var
scoreboard players operation #tt_fb ec.var = @s ec.tt_arena_z
scoreboard players add #tt_fb ec.var 63
execute store result storage evercraft:trials fz2 int 1 run scoreboard players get #tt_fb ec.var
