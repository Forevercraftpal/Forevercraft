# Trade Trial — T10 themed-zone build dispatcher (per-category)
# Run as/at: the trial player, from t10/begin (T10 only).
# Routes to the per-category themed multi-room zone builder. Each category's builder is
# authored to fit the existing arena envelope (offset 0..47, Y300..324) so the standard
# fill_air teardown stays battle-tested (no per-zone teardown geometry to maintain).
#
# WAVE 1 ships MINING (type 1). WAVE 2 adds FARMING (type 2). WAVE 3 adds FISHING (type 3).
# WAVE 4 adds BUILDING (type 4). WAVE 5 adds LUMBER (type 5). WAVE 6 adds ARTISAN (type 6) — the
# FINAL category, completing the ladder. Each category's zone fits the arena envelope so the standard
# fill_air teardown clears it (no per-zone teardown). All six categories now have a themed T10 zone.
execute if score @s ec.tt_type matches 1 run function evercraft:craftforever/trials/types/mining/build_t10_zone
execute if score @s ec.tt_type matches 2 run function evercraft:craftforever/trials/types/farming/build_t10_zone
execute if score @s ec.tt_type matches 3 run function evercraft:craftforever/trials/types/fishing/build_t10_zone
execute if score @s ec.tt_type matches 4 run function evercraft:craftforever/trials/types/building/build_t10_zone
execute if score @s ec.tt_type matches 5 run function evercraft:craftforever/trials/types/lumber/build_t10_zone
execute if score @s ec.tt_type matches 6 run function evercraft:craftforever/trials/types/artisan/build_t10_zone
