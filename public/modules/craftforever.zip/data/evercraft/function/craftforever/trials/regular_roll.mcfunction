# Trade Trials — give ONE regular tier crate (the bulk of the Crate Coin pool).
# Run as/at: the player, from crate_redeem's regular channel.
# Expects #inv_full ec.var already set (1=drop at feet / 0=give).
# Odds: Common 58 / Uncommon 25 / Rare 10 / Ornate 5 / Exquisite 1.5 / Mythical 0.5%

execute store result score #ic_tier ec.var run random value 1..1000

execute if score #ic_tier ec.var matches 996..1000 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:crates/items/mythical
execute if score #ic_tier ec.var matches 996..1000 if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:crates/items/mythical

execute if score #ic_tier ec.var matches 981..995 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:crates/items/exquisite
execute if score #ic_tier ec.var matches 981..995 if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:crates/items/exquisite

execute if score #ic_tier ec.var matches 931..980 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:crates/items/ornate
execute if score #ic_tier ec.var matches 931..980 if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:crates/items/ornate

execute if score #ic_tier ec.var matches 831..930 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:crates/items/rare
execute if score #ic_tier ec.var matches 831..930 if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:crates/items/rare

execute if score #ic_tier ec.var matches 581..830 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:crates/items/uncommon
execute if score #ic_tier ec.var matches 581..830 if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:crates/items/uncommon

execute if score #ic_tier ec.var matches 1..580 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:crates/items/common
execute if score #ic_tier ec.var matches 1..580 if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:crates/items/common
