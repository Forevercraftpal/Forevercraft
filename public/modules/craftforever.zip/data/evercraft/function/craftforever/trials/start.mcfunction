# Trade Trial — Start
# Run as/at: the player who clicked Start Trial
# Requires: ec.tt_type and ec.tt_tier already set

# === VALIDATION ===

# Check not already in a trial
data modify storage evercraft:notify stage.c set value [{text:"You are already in a trial!",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute if entity @s[tag=ec.tt_player] run return run function evercraft:util/notify/emit

# Check not in dungeon
data modify storage evercraft:notify stage.c set value [{text:"Cannot start a trial while in the Dreaming Realm!",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute if score @s ec.dream_active matches 1.. run return run function evercraft:util/notify/emit
execute if entity @s[tag=dr.in_realm] run return run function evercraft:util/notify/emit

# Check not in duel/heist/raid/dungeon/castle
data modify storage evercraft:notify stage.c set value [{text:"Cannot start a trial while in a duel!",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute if entity @s[tag=ec.duel_active_tag] run return run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Cannot start a trial during a heist!",color:"red"}]
execute if entity @s[tag=ec.heist_active_tag] run return run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Cannot start a trial during a raid!",color:"red"}]
execute if entity @s[tag=rd.player] run return run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Cannot start a trial in the Infinite Castle!",color:"red"}]
execute if entity @s[tag=ic.player] run return run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Cannot start a trial during a dungeon!",color:"red"}]
execute if entity @s[tag=dg.player] run return run function evercraft:util/notify/emit

# === KEY + LOCKOUT CHECKS ===
# Detect if this is the player's personal daily challenge (trial type)
scoreboard players set @s ec.tt_is_daily 0
execute if score @s ec.daily_type matches 1 if score @s ec.tt_type = #tt_daily_type ec.var if score @s ec.tt_tier = #tt_daily_tier ec.var unless score @s ec.daily_done matches 1 run scoreboard players set @s ec.tt_is_daily 1

# Trial Pass check (skip if daily challenge)
# A pass now wears like a Dungeon Key (Chest-Node §3): FRESH or WORN passes start a trial; a CRACKED
# pass cannot (cracked = chests only). So count USABLE passes = (all trial passes) - (cracked ones).
# `clear ... 0` returns the count and removes NOTHING (the count idiom — precedent guild/contribution/
# donate_1). #tt_haspass=1 means a non-cracked pass exists. Single-writer #tt_haspass/#tt_pass_any/
# #tt_pass_crk on ec.temp.
scoreboard players set #tt_pass_any ec.temp 0
scoreboard players set #tt_pass_crk ec.temp 0
execute unless score @s ec.tt_is_daily matches 1 store result score #tt_pass_any ec.temp run clear @s minecraft:trial_key[custom_data~{trial_pass:1b}] 0
execute unless score @s ec.tt_is_daily matches 1 store result score #tt_pass_crk ec.temp run clear @s minecraft:trial_key[custom_data~{trial_pass:1b,cracked:1b}] 0
scoreboard players set #tt_haspass ec.temp 0
execute if score #tt_pass_any ec.temp > #tt_pass_crk ec.temp run scoreboard players set #tt_haspass ec.temp 1
data modify storage evercraft:notify stage.c set value [{text:"You need a ",color:"red"},{text:"Trial Pass",color:"#FFA500",bold:true},{text:" to start a trial!",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute unless score @s ec.tt_is_daily matches 1 if score #tt_haspass ec.temp matches 0 run return run function evercraft:util/notify/emit

# Lockout check (skip if daily challenge)
execute unless score @s ec.tt_is_daily matches 1 run function evercraft:craftforever/trials/lockout/get
execute unless score @s ec.tt_is_daily matches 1 store result score #dg_now ec.var run time query gametime
execute unless score @s ec.tt_is_daily matches 1 run scoreboard players operation #dg_elapsed ec.var = #dg_now ec.var
execute unless score @s ec.tt_is_daily matches 1 run scoreboard players operation #dg_elapsed ec.var -= #dg_lockout_val ec.var
data modify storage evercraft:notify stage.c set value [{text:"This trial type is on cooldown! Come back later.",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute unless score @s ec.tt_is_daily matches 1 if score #dg_lockout_val ec.var matches 1.. if score #dg_elapsed ec.var matches ..503999 run return run function evercraft:util/notify/emit

# === ARENA SLOT ALLOCATION (far-grid — no two concurrent trials ever share space) ===
# Claim a free slot on the dedicated far-away arena grid: this sets ec.tt_arena_x/z to the slot's
# coords and forceloads its chunks. If every slot is busy, abort HERE — before the key/pass is
# consumed and before any trial state is set, so a full grid never costs the player a key.
function evercraft:craftforever/trials/slot/alloc
execute if score @s ec.tt_slot matches 0 run return run function evercraft:craftforever/trials/slot/full_abort

# Consume one key (skip if daily challenge)
execute unless score @s ec.tt_is_daily matches 1 run function evercraft:craftforever/trials/consume_key

# Daily challenge announce
data modify storage evercraft:notify stage.c set value [{text:"Daily Challenge! ",color:"gold",bold:true},{text:"No key needed \u2014 bonus rewards await!",color:"yellow"}]
scoreboard players set #ndur ec.temp 50
execute if score @s ec.tt_is_daily matches 1 run function evercraft:util/notify/emit

# === CLOSE GUI ===
function evercraft:craftforever/trial_anvil/gui/close

# === SAVE PLAYER POSITION ===
# Per-player owner stamp (race P0-2): assign a unique session id from a global
# incrementing counter, then stamp it onto the return marker so cleanup_player
# only teleports the OWNING player. Without this, two players exiting the same
# tick can grab each other's return marker (limit=1 is non-deterministic).
scoreboard players add #tt_owner_seq ec.var 1
scoreboard players operation @s ec.tt_owner = #tt_owner_seq ec.var
summon marker ~ ~ ~ {Tags:["ec.tt_return","ec.entity"]}
execute store result entity @e[type=marker,tag=ec.tt_return,distance=..1,limit=1,sort=nearest] Pos[0] double 1 run data get entity @s Pos[0]
execute store result entity @e[type=marker,tag=ec.tt_return,distance=..1,limit=1,sort=nearest] Pos[1] double 1 run data get entity @s Pos[1]
execute store result entity @e[type=marker,tag=ec.tt_return,distance=..1,limit=1,sort=nearest] Pos[2] double 1 run data get entity @s Pos[2]
data modify entity @e[type=marker,tag=ec.tt_return,distance=..1,limit=1,sort=nearest] Rotation set from entity @s Rotation
scoreboard players operation @e[type=marker,tag=ec.tt_return,distance=..1,limit=1,sort=nearest] ec.tt_owner = @s ec.tt_owner

# === SET STATE ===
tag @s add ec.tt_player
scoreboard players set @s ec.tt_active 1
scoreboard players set #tt_active ec.var 1
scoreboard players set @s ec.tt_score 0

# === BUILD ARENA ===
# Arena X/Z were assigned by slot/alloc above (a far-grid slot — no overlap with other players or
# the real world); just stamp the Y plane here.
scoreboard players set @s ec.tt_arena_y 300

# === CATEGORY SETUP (timer, target, arena, snapshot, tools) ===
execute if score @s ec.tt_type matches 1 run function evercraft:craftforever/trials/types/mining/setup
execute if score @s ec.tt_type matches 2 run function evercraft:craftforever/trials/types/farming/setup
execute if score @s ec.tt_type matches 3 run function evercraft:craftforever/trials/types/fishing/setup
execute if score @s ec.tt_type matches 4 run function evercraft:craftforever/trials/types/building/setup
execute if score @s ec.tt_type matches 5 run function evercraft:craftforever/trials/types/lumber/setup
execute if score @s ec.tt_type matches 6 run function evercraft:craftforever/trials/types/artisan/setup

# === MODIFIER STACK (Craft-Trial Complexity Ladder, Wave 1) ===
# Roll a variable, tier-scaled set of modifiers into ec.tt_mods, apply their on-start effects,
# and tell the player what they are facing. Runs AFTER setup (arena built, tier/timer/target set)
# so apply can build hazard/parkour geometry inside the fresh arena. Per-tick logic is driven
# from tick_player -> mods/tick; teardown from cleanup_player -> mods/cleanup.
function evercraft:craftforever/trials/mods/roll
function evercraft:craftforever/trials/mods/apply
function evercraft:craftforever/trials/mods/announce

# === T10 INSTANCED THEMED ZONE (Craft-Trial Complexity Ladder, Wave 1) ===
# ONLY T10 instances (castle p$(pid) adoption): allocate an instance id, tag p$(pid), anchor a
# per-instance marker, and build the per-category themed multi-room zone (parkour + distraction
# woven on top of the category signature; mining keeps its collapse). T1-9 keep the floating box.
execute if score @s ec.tt_tier matches 10 run function evercraft:craftforever/trials/t10/begin

# === HARD MODE MODIFIER ===
# Hard mode halves the timer and applies debuffs
execute if score @s ec.tt_hard_mode matches 1 run scoreboard players operation @s ec.tt_timer /= #2 ec.const
execute if score @s ec.tt_hard_mode matches 1 run effect give @s mining_fatigue 999 0 true
execute if score @s ec.tt_hard_mode matches 1 run bossbar set evercraft:trial_timer color red

# === TELEPORT TO ARENA ===
execute store result storage evercraft:trials arena_x int 1 run scoreboard players get @s ec.tt_arena_x
execute store result storage evercraft:trials arena_z int 1 run scoreboard players get @s ec.tt_arena_z
function evercraft:craftforever/trials/teleport_to_arena with storage evercraft:trials

# === SETUP BOSSBAR ===
bossbar set evercraft:trial_timer visible true
execute store result bossbar evercraft:trial_timer max run scoreboard players get @s ec.tt_timer
execute store result bossbar evercraft:trial_timer value run scoreboard players get @s ec.tt_timer
bossbar set evercraft:trial_timer players @s
bossbar set evercraft:trial_timer color yellow

# Set gamemode to survival (in case they were creative for testing)
gamemode survival @s

# === COUNTDOWN ===
title @s times 5 20 5
title @s title [{"text":"TRIAL ","color":"gold"},{"text":"START","color":"yellow"}]
execute store result storage evercraft:trials tier int 1 run scoreboard players get @s ec.tt_tier
# Store trial name for subtitle
execute if score @s ec.tt_type matches 1 run data modify storage evercraft:trials trial_name set value "Mining"
execute if score @s ec.tt_type matches 2 run data modify storage evercraft:trials trial_name set value "Farming"
execute if score @s ec.tt_type matches 3 run data modify storage evercraft:trials trial_name set value "Fishing"
execute if score @s ec.tt_type matches 4 run data modify storage evercraft:trials trial_name set value "Building"
execute if score @s ec.tt_type matches 5 run data modify storage evercraft:trials trial_name set value "Lumber"
execute if score @s ec.tt_type matches 6 run data modify storage evercraft:trials trial_name set value "Artisan"
function evercraft:craftforever/trials/show_subtitle with storage evercraft:trials
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 1 1.5
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.ender_dragon.growl master @s ~ ~ ~ 0.3 1.5
