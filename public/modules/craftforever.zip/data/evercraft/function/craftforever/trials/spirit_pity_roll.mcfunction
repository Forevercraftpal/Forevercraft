# Spirit-Tool Pity — category-agnostic roll worker (MACRO)
# Joseph 2026-06-06: each successful GRAND (T10) clear bumps that category's spirit-tool
# drop odds by +1 percentage point (cumulative bad-luck protection on the 5% base).
#
# Called: function .../spirit_pity_roll with storage evercraft:trials   (sp set: {cat,tool})
#   storage evercraft:trials sp.cat   = loot-table folder name (mining/farming/.../artisan)
#   storage evercraft:trials sp.tool  = display name of the spirit tool ("Earthsong", ...)
# Caller (spirit_pity dispatcher) pre-loads this category's accrued pity into #sp_pity ec.var
# and reads #sp_pity back out afterward to persist it. Run as/at the player (@s).
#
# Contract: #sp_pity in = accrued pity (percentage points). On a MISS it is left = pity+1;
# on a HIT it is left = 0. Effective chance = min(5 + pity, 100).

# Effective drop chance (percent) = base 5 + accrued pity, capped at 100.
scoreboard players operation #sp_chance ec.var = #sp_pity ec.var
scoreboard players add #sp_chance ec.var 5
execute if score #sp_chance ec.var matches 101.. run scoreboard players set #sp_chance ec.var 100

# Roll d100. Hit when roll <= chance.
execute store result score #sp_roll ec.var run random value 1..100
scoreboard players set #sp_hit ec.var 0
execute if score #sp_roll ec.var <= #sp_chance ec.var run scoreboard players set #sp_hit ec.var 1

# ── HIT: drop the spirit tool (inv-full guard), reset pity to 0, celebrate ──
# Inv-full guard: drop at the player's feet rather than void on a full inventory.
execute store result score #sp_invfull ec.var run function evercraft:util/check_inv_full
execute if score #sp_hit ec.var matches 1 if score #sp_invfull ec.var matches 0 run function evercraft:craftforever/trials/spirit_pity_give with storage evercraft:trials sp
execute if score #sp_hit ec.var matches 1 if score #sp_invfull ec.var matches 1 run function evercraft:craftforever/trials/spirit_pity_spawn with storage evercraft:trials sp
execute if score #sp_hit ec.var matches 1 run scoreboard players set #sp_pity ec.var 0
execute if score #sp_hit ec.var matches 1 if score @s ec.fx_snd matches 1.. run playsound minecraft:block.beacon.power_select master @s ~ ~ ~ 1 1.4
execute if score #sp_hit ec.var matches 1 if score @s ec.fx_snd matches 1.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 1 1.6
execute if score #sp_hit ec.var matches 1 run particle minecraft:totem_of_undying ~ ~1 ~ 0.6 0.8 0.6 0.2 40
execute if score #sp_hit ec.var matches 1 run function evercraft:craftforever/trials/spirit_pity_hit_msg with storage evercraft:trials sp

# ── MISS: climb pity by 1 (+1 percentage point), surface the new odds ──
execute if score #sp_hit ec.var matches 0 run scoreboard players add #sp_pity ec.var 1
# Recompute the displayed odds = min(5 + new pity, 100).
execute if score #sp_hit ec.var matches 0 run scoreboard players operation #sp_show ec.var = #sp_pity ec.var
execute if score #sp_hit ec.var matches 0 run scoreboard players add #sp_show ec.var 5
execute if score #sp_hit ec.var matches 0 if score #sp_show ec.var matches 101.. run scoreboard players set #sp_show ec.var 100
execute if score #sp_hit ec.var matches 0 store result storage evercraft:trials sp.odds int 1 run scoreboard players get #sp_show ec.var
execute if score #sp_hit ec.var matches 0 run function evercraft:craftforever/trials/spirit_pity_miss_msg with storage evercraft:trials sp
