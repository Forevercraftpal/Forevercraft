# Teleport player to arena CENTER (macro)
# Args: $(arena_x), $(arena_z) = the arena's CORNER (fill_air / build_* anchor at ax,az extending +47).
# Every type clears its safe spawn pocket at center (ax+24, az+24); the player must land THERE,
# not at the corner — landing at the corner dropped pioneers inside the perimeter wall and the
# boundary check re-teleported them into it ("fell out of the arena" loop). Y=303 → short, damage-free
# drop into the center pocket for all 6 types (floor/platform 299-302).
$execute positioned $(arena_x) 303 $(arena_z) run tp @s ~24 ~ ~24 0 0
