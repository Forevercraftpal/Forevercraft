# Drop the arena slot's forceload (macro). Run with storage evercraft:trials {fx1,fz1,fx2,fz2}.
# MUST run AFTER fill_air (which needs the chunks loaded to clear the arena).
$forceload remove $(fx1) $(fz1) $(fx2) $(fz2)
