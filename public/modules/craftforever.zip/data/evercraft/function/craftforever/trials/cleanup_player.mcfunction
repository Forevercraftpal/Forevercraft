# Trade Trial — Cleanup single player
# Run as/at: the ec.tt_player
#
# ORDER MATTERS. The arena floats ~240 blocks above the real terrain. If we remove the
# floor (fill_air) while the player is still standing on it and the return teleport then
# fails, they free-fall to a fatal landing — and the boundary respawn can't help because
# the ec.tt_player tag gets cleared at the end of this file. So the sequence is:
#   1. clear inventory / dropped items / mobs  (player still in arena -> ~ is the arena)
#   2. teleport the player OUT, with fallbacks so it can never fail to a void/fall death
#   3. ONLY THEN fill the arena (incl. barrier shell + water) with air
#   4. reset state, removing the protective tag LAST
# Shared by all six trial types, so this guard covers fishing/lumber/mining/farming/
# building/artisan identically.

# === REMOVE ALL TRIAL TOOLS/ITEMS (position-independent) ===
clear @s netherite_pickaxe[custom_data~{trial_tool:1b}]
clear @s netherite_hoe[custom_data~{trial_tool:1b}]
clear @s fishing_rod[custom_data~{trial_tool:1b}]
clear @s netherite_axe[custom_data~{trial_tool:1b}]
clear @s shears[custom_data~{trial_tool:1b}]
clear @s cobblestone[custom_data~{trial_tool:1b}]
clear @s dirt[custom_data~{trial_tool:1b}]
clear @s oak_planks[custom_data~{trial_tool:1b}]
clear @s bone_meal[custom_data~{trial_tool:1b}]
clear @s water_bucket[custom_data~{trial_tool:1b}]

# === CLEAR DROPPED ITEMS + TRIAL MOBS + HAZARDS (box-anchored on the arena footprint) ===
# Anchored on the arena column via ax/az (NOT a player-centred sphere), so it catches every trial
# entity wherever the player wandered — otherwise artisan's sheep (and any off-centre mob/item)
# survive cleanup and free-fall ~240 blocks onto builds below when fill_air removes the floor.
execute store result storage evercraft:trials ax int 1 run scoreboard players get @s ec.tt_arena_x
execute store result storage evercraft:trials az int 1 run scoreboard players get @s ec.tt_arena_z
function evercraft:craftforever/trials/kill_arena with storage evercraft:trials

# === MODIFIER TEARDOWN (Craft-Trial Complexity Ladder, Wave 1) ===
# Clear all modifier effects, kill modifier entities (harasser + in-flight falling-block
# hazards), and reset the modifier scores. Runs while the player is STILL in the arena (so ~
# targets the arena for the entity kills) and BEFORE the fill_air below removes the floor —
# matching the load-bearing teardown order documented at the top of this file.
function evercraft:craftforever/trials/mods/cleanup

# === T10 INSTANCE TEARDOWN (Craft-Trial Complexity Ladder, Wave 1) ===
# Remove the p$(pid) instance tag + kill the anchor marker (no-op for T1-9 / non-instanced runs).
# Runs while still in-arena (anchor is at the arena centre) and before fill_air clears the zone.
function evercraft:craftforever/trials/t10/teardown

# === TELEPORT BACK — BEFORE removing the floor ===
# Race P0-2: filter the return marker by owner so this player only teleports to THEIR own
# pre-trial position (markers are owner-stamped at start.mcfunction:84).
scoreboard players operation #tt_who ec.temp = @s ec.tt_owner
execute as @e[type=marker,tag=ec.tt_return] if score @s ec.tt_owner = #tt_who ec.temp at @s rotated as @s as @a[tag=ec.tt_player] if score @s ec.tt_owner = #tt_who ec.temp run tp @s ~ ~ ~ ~ ~
# Fallback 1: if the owner-matched teleport didn't move us (still in the arena Y-band,
# Y 295-335), teleport to the NEAREST return marker. The player's own marker sits directly
# below the arena (same X/Z), so this recovers the correct spot even on an owner mismatch.
execute if entity @s[y=295,dy=40] at @e[type=marker,tag=ec.tt_return,limit=1,sort=nearest] run tp @s ~ ~ ~
# Fallback 2: if there is NO return marker at all and we're somehow still in the arena band,
# grant slow_falling + resistance so the floor-removal below can never deal fatal fall
# damage — the player drifts safely down to the real terrain instead.
execute if entity @s[y=295,dy=40] run effect give @s slow_falling 12 0 true
execute if entity @s[y=295,dy=40] run effect give @s resistance 12 4 true
# Player is safe now — remove their owned marker.
execute as @e[type=marker,tag=ec.tt_return] if score @s ec.tt_owner = #tt_who ec.temp run kill @s

# === CLEAR ARENA (player is now elsewhere; removes blocks, water, and barrier shell) ===
execute store result storage evercraft:trials ax int 1 run scoreboard players get @s ec.tt_arena_x
execute store result storage evercraft:trials az int 1 run scoreboard players get @s ec.tt_arena_z
function evercraft:craftforever/trials/fill_air with storage evercraft:trials

# === RELEASE THE FAR-GRID ARENA SLOT (after fill_air — chunks must stay loaded until cleared) ===
# Drops this arena's forceload and frees its grid slot so the next trial can reuse the space.
function evercraft:craftforever/trials/slot/free

# === HIDE BOSSBAR ===
bossbar set evercraft:trial_timer visible false
bossbar set evercraft:trial_timer players

# === RESET STATE (remove the protective ec.tt_player tag LAST) ===
tag @s remove ec.tt_player
tag @s remove ec.tt_complete
scoreboard players set @s ec.tt_active 0
scoreboard players set @s ec.tt_type 0
scoreboard players set @s ec.tt_tier 0
scoreboard players set @s ec.tt_timer 0
scoreboard players set @s ec.tt_score 0
scoreboard players set @s ec.tt_target 0
scoreboard players set @s ec.tt_hard_mode 0
scoreboard players set @s ec.tt_first_clear 0

# Clear hard mode debuffs
effect clear @s mining_fatigue

# Reset global flag (check if any other players still in trials)
execute unless entity @a[tag=ec.tt_player] run scoreboard players set #tt_active ec.var 0

# Clear actionbar
# (Wave 2, 2026-06-10: bar-clear stays RAW — gated so it never blanks a queue frame.)
execute unless entity @s[tag=ab_q] run title @s actionbar {"text":""}

# Sound
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.enderman.teleport master @s ~ ~ ~ 0.5 1.0
