# Trade Trial — pick ONE distinct modifier into ec.tt_mods (weighted, env-exclusion aware)
# Run as/at: the trial player, called `count` times from mods/roll.
#
# Weighted bag: every ELIGIBLE bit gets weight 15, EXCEPT combat (bit 10) which gets
# weight 1 (~1/15 of a normal bit -> combat is rare per the plan). A bit is eligible if
# it is NOT already set AND (for env hazards 3/4/5) no env hazard is used yet this run.
# We sum eligible weights, roll 1..total, then walk the cumulative weight to land on a bit.

# --- Build per-bit eligibility weight (#tt_w0..#tt_w10) ---
# Default normal weight 15; combat 1. Zero out any bit already set, and (if an env hazard
# is already used) zero the env bits 3/4/5.
scoreboard players set #tt_w0 ec.var 15
scoreboard players set #tt_w1 ec.var 15
scoreboard players set #tt_w2 ec.var 15
scoreboard players set #tt_w3 ec.var 15
scoreboard players set #tt_w4 ec.var 15
scoreboard players set #tt_w5 ec.var 15
scoreboard players set #tt_w6 ec.var 15
scoreboard players set #tt_w7 ec.var 15
scoreboard players set #tt_w8 ec.var 15
scoreboard players set #tt_w9 ec.var 15
scoreboard players set #tt_w10 ec.var 1

# Zero out already-picked bits: (ec.tt_mods / 2^bit) % 2 == 1 -> set -> weight 0
function evercraft:craftforever/trials/mods/_zero_picked

# Env-exclusion: if an env hazard (bit 3/4/5) is already used this run, the other env
# bits become ineligible (weight 0). #tt_env_used is set by this fn when one is picked.
execute if score #tt_env_used ec.var matches 1.. run scoreboard players set #tt_w3 ec.var 0
execute if score #tt_env_used ec.var matches 1.. run scoreboard players set #tt_w4 ec.var 0
execute if score #tt_env_used ec.var matches 1.. run scoreboard players set #tt_w5 ec.var 0

# --- Total eligible weight ---
scoreboard players set #tt_wtot ec.var 0
scoreboard players operation #tt_wtot ec.var += #tt_w0 ec.var
scoreboard players operation #tt_wtot ec.var += #tt_w1 ec.var
scoreboard players operation #tt_wtot ec.var += #tt_w2 ec.var
scoreboard players operation #tt_wtot ec.var += #tt_w3 ec.var
scoreboard players operation #tt_wtot ec.var += #tt_w4 ec.var
scoreboard players operation #tt_wtot ec.var += #tt_w5 ec.var
scoreboard players operation #tt_wtot ec.var += #tt_w6 ec.var
scoreboard players operation #tt_wtot ec.var += #tt_w7 ec.var
scoreboard players operation #tt_wtot ec.var += #tt_w8 ec.var
scoreboard players operation #tt_wtot ec.var += #tt_w9 ec.var
scoreboard players operation #tt_wtot ec.var += #tt_w10 ec.var

# Nothing eligible (all 11 bits picked, or only env left after exclusion): bail this pick.
execute if score #tt_wtot ec.var matches ..0 run return 0

# --- Roll a point in [1..total] and walk the cumulative weight ---
execute store result score #tt_pick ec.var run random value 1..2147483646
scoreboard players operation #tt_pick ec.var %= #tt_wtot ec.var
scoreboard players add #tt_pick ec.var 1

# Walk: subtract each eligible bit's weight; when #tt_pick drops to <=0 first, that's the bit.
# We use a running accumulator #tt_acc and find the first bit whose cumulative >= #tt_pick.
scoreboard players set #tt_acc ec.var 0
scoreboard players set #tt_chosen ec.var -1

scoreboard players operation #tt_acc ec.var += #tt_w0 ec.var
execute if score #tt_chosen ec.var matches -1 if score #tt_pick ec.var <= #tt_acc ec.var run scoreboard players set #tt_chosen ec.var 0
scoreboard players operation #tt_acc ec.var += #tt_w1 ec.var
execute if score #tt_chosen ec.var matches -1 if score #tt_pick ec.var <= #tt_acc ec.var run scoreboard players set #tt_chosen ec.var 1
scoreboard players operation #tt_acc ec.var += #tt_w2 ec.var
execute if score #tt_chosen ec.var matches -1 if score #tt_pick ec.var <= #tt_acc ec.var run scoreboard players set #tt_chosen ec.var 2
scoreboard players operation #tt_acc ec.var += #tt_w3 ec.var
execute if score #tt_chosen ec.var matches -1 if score #tt_pick ec.var <= #tt_acc ec.var run scoreboard players set #tt_chosen ec.var 3
scoreboard players operation #tt_acc ec.var += #tt_w4 ec.var
execute if score #tt_chosen ec.var matches -1 if score #tt_pick ec.var <= #tt_acc ec.var run scoreboard players set #tt_chosen ec.var 4
scoreboard players operation #tt_acc ec.var += #tt_w5 ec.var
execute if score #tt_chosen ec.var matches -1 if score #tt_pick ec.var <= #tt_acc ec.var run scoreboard players set #tt_chosen ec.var 5
scoreboard players operation #tt_acc ec.var += #tt_w6 ec.var
execute if score #tt_chosen ec.var matches -1 if score #tt_pick ec.var <= #tt_acc ec.var run scoreboard players set #tt_chosen ec.var 6
scoreboard players operation #tt_acc ec.var += #tt_w7 ec.var
execute if score #tt_chosen ec.var matches -1 if score #tt_pick ec.var <= #tt_acc ec.var run scoreboard players set #tt_chosen ec.var 7
scoreboard players operation #tt_acc ec.var += #tt_w8 ec.var
execute if score #tt_chosen ec.var matches -1 if score #tt_pick ec.var <= #tt_acc ec.var run scoreboard players set #tt_chosen ec.var 8
scoreboard players operation #tt_acc ec.var += #tt_w9 ec.var
execute if score #tt_chosen ec.var matches -1 if score #tt_pick ec.var <= #tt_acc ec.var run scoreboard players set #tt_chosen ec.var 9
scoreboard players operation #tt_acc ec.var += #tt_w10 ec.var
execute if score #tt_chosen ec.var matches -1 if score #tt_pick ec.var <= #tt_acc ec.var run scoreboard players set #tt_chosen ec.var 10

# --- Set the chosen bit in ec.tt_mods (add its power-of-two) ---
execute if score #tt_chosen ec.var matches 0 run scoreboard players add @s ec.tt_mods 1
execute if score #tt_chosen ec.var matches 1 run scoreboard players add @s ec.tt_mods 2
execute if score #tt_chosen ec.var matches 2 run scoreboard players add @s ec.tt_mods 4
execute if score #tt_chosen ec.var matches 3 run scoreboard players add @s ec.tt_mods 8
execute if score #tt_chosen ec.var matches 4 run scoreboard players add @s ec.tt_mods 16
execute if score #tt_chosen ec.var matches 5 run scoreboard players add @s ec.tt_mods 32
execute if score #tt_chosen ec.var matches 6 run scoreboard players add @s ec.tt_mods 64
execute if score #tt_chosen ec.var matches 7 run scoreboard players add @s ec.tt_mods 128
execute if score #tt_chosen ec.var matches 8 run scoreboard players add @s ec.tt_mods 256
execute if score #tt_chosen ec.var matches 9 run scoreboard players add @s ec.tt_mods 512
execute if score #tt_chosen ec.var matches 10 run scoreboard players add @s ec.tt_mods 1024

# Mark env-used if we just picked an env hazard (3/4/5) so the other two are excluded next.
execute if score #tt_chosen ec.var matches 3..5 run scoreboard players set #tt_env_used ec.var 1
