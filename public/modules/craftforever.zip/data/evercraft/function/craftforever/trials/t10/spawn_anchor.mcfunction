# Trade Trial — T10 spawn the instance center marker (macro, castle adoption)
# Called: function .../t10/spawn_anchor with storage evercraft:trials  (cx,cz,pid set)
# Summons a marker at the spawn-platform centre (ax+24, Y302, az+24) tagged ec.tt_anchor +
# p$(pid) so each instance's selectors only ever see their OWN anchor (cross-instance
# isolation, mirrors castle's p$(pid)-tagged center/return markers). Killed in t10/teardown.
$execute positioned $(cx) 302 $(cz) run summon marker ~24 ~ ~24 {Tags:["ec.tt_anchor","ec.entity","p$(pid)"]}
