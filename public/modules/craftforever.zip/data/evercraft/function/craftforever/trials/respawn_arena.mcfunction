# Respawn player at arena center (fell out of bounds)
execute store result storage evercraft:trials arena_x int 1 run scoreboard players get @s ec.tt_arena_x
execute store result storage evercraft:trials arena_z int 1 run scoreboard players get @s ec.tt_arena_z
function evercraft:craftforever/trials/teleport_to_arena with storage evercraft:trials
data modify storage evercraft:notify stage.c set value [{text:"You fell out of the arena!",color:"red"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.enderman.teleport master @s ~ ~ ~ 0.5 1.0
