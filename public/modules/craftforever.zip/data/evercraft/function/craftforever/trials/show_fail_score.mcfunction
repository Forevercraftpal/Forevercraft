# Show final score on failure (macro)
$data modify storage evercraft:notify stage.c set value [{text:"Final score: ",color:"gray"},{text:"$(score)/$(target)",color:"red"}]
scoreboard players set #ndur ec.temp 50
function evercraft:util/notify/emit
