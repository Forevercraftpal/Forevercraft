# Trade Trial — map the claimed slot index (@s ec.tt_slot, 1..64) to its grid world coords,
# writing ec.tt_arena_x / ec.tt_arena_z (the arena's min corner). Run as the trial player.
#
# Grid: base (2,000,000, 2,000,000), 16 columns, 128 blocks/slot. Slot i (0-based = n-1):
#   col = i % 16 ,  row = i / 16
#   X = 2000000 + col*128 ,  Z = 2000000 + row*128
# 128-block spacing keeps every arena's -11..+58 clear envelope from ever touching its neighbour.
scoreboard players operation #tt_gi ec.var = @s ec.tt_slot
scoreboard players remove #tt_gi ec.var 1
scoreboard players set #tt_c16 ec.var 16
scoreboard players set #tt_c128 ec.var 128

# col = (n-1) % 16  ->  X = 2000000 + col*128
scoreboard players operation #tt_gcol ec.var = #tt_gi ec.var
scoreboard players operation #tt_gcol ec.var %= #tt_c16 ec.var
scoreboard players operation #tt_gcol ec.var *= #tt_c128 ec.var
scoreboard players set #tt_gx ec.var 2000000
scoreboard players operation #tt_gx ec.var += #tt_gcol ec.var
scoreboard players operation @s ec.tt_arena_x = #tt_gx ec.var

# row = (n-1) / 16  ->  Z = 2000000 + row*128
scoreboard players operation #tt_grow ec.var = #tt_gi ec.var
scoreboard players operation #tt_grow ec.var /= #tt_c16 ec.var
scoreboard players operation #tt_grow ec.var *= #tt_c128 ec.var
scoreboard players set #tt_gz ec.var 2000000
scoreboard players operation #tt_gz ec.var += #tt_grow ec.var
scoreboard players operation @s ec.tt_arena_z = #tt_gz ec.var
