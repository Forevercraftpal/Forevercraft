# Trade Trial — Modifier per-tick logic
# Run as/at: the trial player, from trials/tick_player AFTER the type tracker.
# The whole tick chain is already existence-gated on #tt_active and the ec.tt_player tag,
# so this only runs for players actually in a trial. We decode the bitfield once, then run
# only the active bits. Env hazards + harasser fire on a shared cadence (every 40t = 2s)
# so this stays cheap; the debuffs (0/1/2) are on-start effects and do nothing here.

function evercraft:craftforever/trials/mods/_decode

# Advance the shared hazard cadence and detect the 2s boundary (#tt_haz_fire=1 on the beat).
scoreboard players add @s ec.tt_haz_t 1
scoreboard players set #tt_haz_fire ec.var 0
execute if score @s ec.tt_haz_t matches 40.. run scoreboard players set #tt_haz_fire ec.var 1
execute if score @s ec.tt_haz_t matches 40.. run scoreboard players set @s ec.tt_haz_t 0

# --- bit 3: Falling hazard — anvil/falling-block rain on the cadence beat ---
execute if score #tt_m3 ec.var matches 1 if score #tt_haz_fire ec.var matches 1 run function evercraft:craftforever/trials/mods/falling_tick

# --- bit 4: Creeping hazard — raise the lava/water floor one layer on the beat ---
execute if score #tt_m4 ec.var matches 1 if score #tt_haz_fire ec.var matches 1 run function evercraft:craftforever/trials/mods/creeping_tick

# --- bit 5: Blackout — pulse the lights out on the beat (re-light = arena relit) ---
execute if score #tt_m5 ec.var matches 1 if score #tt_haz_fire ec.var matches 1 run function evercraft:craftforever/trials/mods/blackout_tick

# --- bit 7: Distraction — spawn decoy particle noise / fake markers on the beat ---
execute if score #tt_m7 ec.var matches 1 if score #tt_haz_fire ec.var matches 1 run function evercraft:craftforever/trials/mods/distraction_tick

# --- bit 9: Haste-drain — the timer drains faster (extra -1 every other tick = ~x1.5) ---
# tick_player already removed 1 from ec.tt_timer this tick; we shave a bit more, but only
# while there's time left and the player has not yet completed (post-complete the timer is
# intentionally negative as a countdown — never accelerate that).
execute if score #tt_m9 ec.var matches 1 unless entity @s[tag=ec.tt_complete] if score @s ec.tt_timer matches 8.. run function evercraft:craftforever/trials/mods/hastedrain_tick

# --- bit 10: Harasser — slow re-spawn if the lone mob was killed (keep exactly 1 alive) ---
execute if score #tt_m10 ec.var matches 1 if score #tt_haz_fire ec.var matches 1 run function evercraft:craftforever/trials/mods/harasser_tick

# (bits 6 Precision + 8 Parkour are enforced by the arena build + the type tracker / geometry,
#  so they have no per-tick cost here. Precision flavour text is shown in mods/announce.)
