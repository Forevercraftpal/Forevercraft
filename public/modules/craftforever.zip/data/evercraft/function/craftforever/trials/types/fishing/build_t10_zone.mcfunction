# Fishing T10 — THEMED INSTANCED ZONE (Craft-Trial Complexity Ladder, Wave 3)
# Run as/at: the trial player, from t10/build_zone (T10 only, AFTER build_t10 laid the base
# 4-deep Leviathan's Pool + the central dry dock). This ADDS a castle-style multi-room depth on
# top of fishing's signature open-water casting: an AQUATIC PARKOUR of lily-pad / boat / buoy
# stepping stones across the open pool, DECOY bobber-buoys over kelp-choked shallows (look like
# prime spots, give nothing), and a far PRIME-DEEP fishing pier reachable ONLY across the jump —
# the uncontested clear-water casting spot, with a sea-treasure marker selling the depth.
# Authored to fit the arena envelope (offset 0..47, Y300..323, all cleared by the standard
# fill_air sweep over Y298..325) so the standard teardown clears it — no per-zone teardown.
#
# Modeled on types/mining/build_t10_zone + types/farming/build_t10_zone (the Wave-1/2 reference).
# Keeps fishing's reward + the 2% catalyst roll (in fishing/reward) untouched. The scorer is the
# existing per-tick catch counter (fishing/tick: ec.tt_s_fish delta) — honest "you must FISH" —
# the zone only changes WHERE the best casting is, never how scoring works.

execute store result storage evercraft:trials zx int 1 run scoreboard players get @s ec.tt_arena_x
execute store result storage evercraft:trials zz int 1 run scoreboard players get @s ec.tt_arena_z
function evercraft:craftforever/trials/types/fishing/build_t10_zone_fill with storage evercraft:trials

# Themed intro title — the player arrives at a wider, instanced reach of open water.
title @s times 5 30 10
title @s subtitle {"text":"The Tidecaller's Reach opens before you…","color":"aqua"}
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:ambient.underwater.enter master @s ~ ~ ~ 1 0.9
