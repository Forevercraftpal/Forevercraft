# Trade Trial — Modifier ANNOUNCE (show the rolled modifiers to the player)
# Run as/at: the trial player, from trials/start after mods/apply.
# Tells the player exactly what they are facing this run, as a tellraw list:
#   "Trial Modifiers: ⚡Slowness, 🌑Darkness, …"
# Decodes ec.tt_mods (re-using _decode's #tt_m0..#tt_m10 flags). If no modifiers rolled (only
# possible if every eligible bit was excluded — practically never), shows nothing extra.

function evercraft:craftforever/trials/mods/_decode

# Header line.
tellraw @s [{"text":"⚒ Trial Modifiers — ","color":"gold","bold":true},{"text":"this run twists against you:","color":"yellow"}]

# Each active bit -> one labelled line. Plain (non-bold) per popup-law for in-world lists.
execute if score #tt_m0 ec.var matches 1 run tellraw @s [{"text":"  ⚡ ","color":"aqua"},{"text":"Slowness","color":"white"},{"text":" — your steps drag.","color":"gray"}]
execute if score #tt_m1 ec.var matches 1 run tellraw @s [{"text":"  🌑 ","color":"dark_purple"},{"text":"Darkness","color":"white"},{"text":" — the dark closes in.","color":"gray"}]
execute if score #tt_m2 ec.var matches 1 run tellraw @s [{"text":"  💤 ","color":"blue"},{"text":"Fatigue","color":"white"},{"text":" — your arms grow heavy.","color":"gray"}]
execute if score #tt_m3 ec.var matches 1 run tellraw @s [{"text":"  🪨 ","color":"red"},{"text":"Falling Hazard","color":"white"},{"text":" — rocks rain down.","color":"gray"}]
# Creeping hazard flavour follows the rising fluid (creeping_tick floods WATER for farming/
# fishing/building, LAVA for mining/lumber/artisan) — don't promise lava then flood water.
execute if score #tt_m4 ec.var matches 1 if score @s ec.tt_type matches 2 run tellraw @s [{"text":"  🌊 ","color":"aqua"},{"text":"Creeping Hazard","color":"white"},{"text":" — the fields flood; climb higher.","color":"gray"}]
execute if score #tt_m4 ec.var matches 1 if score @s ec.tt_type matches 3 run tellraw @s [{"text":"  🌊 ","color":"aqua"},{"text":"Creeping Hazard","color":"white"},{"text":" — the tide surges; climb higher.","color":"gray"}]
execute if score #tt_m4 ec.var matches 1 if score @s ec.tt_type matches 4 run tellraw @s [{"text":"  🌊 ","color":"aqua"},{"text":"Creeping Hazard","color":"white"},{"text":" — a burst main floods the site; climb higher.","color":"gray"}]
execute if score #tt_m4 ec.var matches 1 unless score @s ec.tt_type matches 2 unless score @s ec.tt_type matches 3 unless score @s ec.tt_type matches 4 run tellraw @s [{"text":"  🌋 ","color":"gold"},{"text":"Creeping Hazard","color":"white"},{"text":" — the floor rises with lava.","color":"gray"}]
execute if score #tt_m5 ec.var matches 1 run tellraw @s [{"text":"  ☼ ","color":"dark_gray"},{"text":"Blackout","color":"white"},{"text":" — the lights keep failing.","color":"gray"}]
execute if score #tt_m6 ec.var matches 1 run tellraw @s [{"text":"  🎯 ","color":"green"},{"text":"Precision","color":"white"},{"text":" — only the right target scores.","color":"gray"}]
execute if score #tt_m7 ec.var matches 1 run tellraw @s [{"text":"  ✦ ","color":"light_purple"},{"text":"Distraction","color":"white"},{"text":" — decoys mislead you.","color":"gray"}]
execute if score #tt_m8 ec.var matches 1 run tellraw @s [{"text":"  🦶 ","color":"yellow"},{"text":"Parkour","color":"white"},{"text":" — a gap bars the way.","color":"gray"}]
execute if score #tt_m9 ec.var matches 1 run tellraw @s [{"text":"  ⏳ ","color":"red"},{"text":"Haste-Drain","color":"white"},{"text":" — the clock runs faster.","color":"gray"}]
execute if score #tt_m10 ec.var matches 1 run tellraw @s [{"text":"  ⚔ ","color":"dark_red"},{"text":"Harasser","color":"white"},{"text":" — something hunts you.","color":"gray"}]

execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 0.6 0.8
