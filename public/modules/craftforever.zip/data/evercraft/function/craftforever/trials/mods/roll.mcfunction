# Trade Trial — Modifier ROLL (the crescendo curve)
# Run as/at: the trial player, AFTER ec.tt_tier + arena are set, BEFORE mods/apply.
# Picks a VARIABLE, tier-scaled count of DISTINCT modifiers into the per-player
# bitfield ec.tt_mods (bit per modifier, 0-10). Weighted bag; combat (bit 10) is rare;
# at most ONE environmental hazard (bits 3/4/5) per run.
#
# ec.tt_mods bit map (value = sum of 2^bit):
#   0=Slowness 1=Darkness 2=Fatigue 3=Falling-haz(env) 4=Creeping-haz(env)
#   5=Blackout(env) 6=Precision 7=Distraction 8=Parkour 9=Haste-drain 10=Harasser(rare)

# Fresh bitfield + per-roll scratch (single-writer on ec.var / ec.temp scratch here + roll_one)
scoreboard players set @s ec.tt_mods 0
scoreboard players set #tt_env_used ec.var 0
scoreboard players set #tt_roll_left ec.var 0

# === COUNT = the variable, tier-scaled number of modifiers ===
# T1-T9: random(1 .. tt_tier). T10: random(7 .. 10) (the guaranteed floor of 7).
execute if score @s ec.tt_tier matches 1 store result score #tt_roll_left ec.var run random value 1..1
execute if score @s ec.tt_tier matches 2 store result score #tt_roll_left ec.var run random value 1..2
execute if score @s ec.tt_tier matches 3 store result score #tt_roll_left ec.var run random value 1..3
execute if score @s ec.tt_tier matches 4 store result score #tt_roll_left ec.var run random value 1..4
execute if score @s ec.tt_tier matches 5 store result score #tt_roll_left ec.var run random value 1..5
execute if score @s ec.tt_tier matches 6 store result score #tt_roll_left ec.var run random value 1..6
execute if score @s ec.tt_tier matches 7 store result score #tt_roll_left ec.var run random value 1..7
execute if score @s ec.tt_tier matches 8 store result score #tt_roll_left ec.var run random value 1..8
execute if score @s ec.tt_tier matches 9 store result score #tt_roll_left ec.var run random value 1..9
execute if score @s ec.tt_tier matches 10 store result score #tt_roll_left ec.var run random value 7..10

# === PICK `count` DISTINCT modifiers (weighted, with env-exclusion) ===
# roll_one rebuilds the eligible-weight bag each call (zeroing already-picked bits + the other
# env bits once one env hazard is used), then does an exact weighted pick over what's left — so
# each call yields a NEW distinct bit, no re-roll loop, and bails cleanly if nothing's eligible.
execute if score #tt_roll_left ec.var matches 1.. run function evercraft:craftforever/trials/mods/roll_one
execute if score #tt_roll_left ec.var matches 2.. run function evercraft:craftforever/trials/mods/roll_one
execute if score #tt_roll_left ec.var matches 3.. run function evercraft:craftforever/trials/mods/roll_one
execute if score #tt_roll_left ec.var matches 4.. run function evercraft:craftforever/trials/mods/roll_one
execute if score #tt_roll_left ec.var matches 5.. run function evercraft:craftforever/trials/mods/roll_one
execute if score #tt_roll_left ec.var matches 6.. run function evercraft:craftforever/trials/mods/roll_one
execute if score #tt_roll_left ec.var matches 7.. run function evercraft:craftforever/trials/mods/roll_one
execute if score #tt_roll_left ec.var matches 8.. run function evercraft:craftforever/trials/mods/roll_one
execute if score #tt_roll_left ec.var matches 9.. run function evercraft:craftforever/trials/mods/roll_one
execute if score #tt_roll_left ec.var matches 10.. run function evercraft:craftforever/trials/mods/roll_one
