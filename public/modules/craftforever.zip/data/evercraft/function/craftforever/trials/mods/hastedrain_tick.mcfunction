# Trade Trial modifier — Haste-drain (bit 9): the timer drains ~x1.25.
# Run as/at: the trial player, from mods/tick (already gated: bit active, not complete,
# timer >= 8). tick_player removes 1/tick normally; we shave 1 MORE on 1 of every 4 ticks
# => ~25% faster drain. Use the current timer value's low bits as a cheap "every 4th".
scoreboard players operation #tt_hd ec.var = @s ec.tt_timer
scoreboard players operation #tt_hd ec.var %= #4 ec.const
execute if score #tt_hd ec.var matches 0 run scoreboard players remove @s ec.tt_timer 1
