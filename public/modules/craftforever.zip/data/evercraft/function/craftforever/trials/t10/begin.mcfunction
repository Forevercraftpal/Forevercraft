# Trade Trial — T10 INSTANCE BEGIN (castle p$(pid) adoption)
# Run as/at: the trial player, from trials/start ONLY for tier 10 (after the floating arena is
# built by setup). This layers a per-player INSTANCE identity on top of the floating arena so
# concurrent T10 runs never collide scratch/markers, and anchors the themed zone with a tagged
# center marker — exactly mirroring castle/begin_inner:8-15,22,32,41 (pid, p$(pid) tag,
# .$(pid) scratch, return/center marker, instance pick).
#
# This does NOT replace T1-9's arena (only T10 calls it). The zone itself is built by
# t10/build_zone (dispatch -> per-category builder); teardown is the standard fill_air (the
# zone is authored to fit the existing arena envelope, so cleanup stays battle-tested).

# === ALLOCATE A UNIQUE INSTANCE ID (global incrementing counter -> per-player ec.tt_pid) ===
scoreboard players add #tt_pid_seq ec.tt_pid_seq 1
scoreboard players operation @s ec.tt_pid = #tt_pid_seq ec.tt_pid_seq

# === TAG THE PLAYER p$(pid) (cross-instance selector isolation, castle AU-B-FOLLOWUP.10) ===
execute store result storage evercraft:trials pid int 1 run scoreboard players get @s ec.tt_pid
function evercraft:craftforever/trials/t10/tag_player with storage evercraft:trials

# === PICK A THEMED ZONE LAYOUT (1..4) so repeat T10s feel different (castle instance pick) ===
execute store result score @s ec.tt_zone run random value 1..4

# === ANCHOR THE INSTANCE: a p$(pid)-tagged center marker at the arena spawn center ===
# Center = arena (ax+24, Y302, az+24) — the spawn platform middle. Tagged p$(pid) so each
# instance's selectors (distraction decoys, room lookups) only see their own anchor.
execute store result storage evercraft:trials cx int 1 run scoreboard players get @s ec.tt_arena_x
execute store result storage evercraft:trials cz int 1 run scoreboard players get @s ec.tt_arena_z
function evercraft:craftforever/trials/t10/spawn_anchor with storage evercraft:trials

# === BUILD THE THEMED MULTI-ROOM ZONE (per-category) ===
function evercraft:craftforever/trials/t10/build_zone

execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.end_portal.spawn master @s ~ ~ ~ 0.4 1.1
