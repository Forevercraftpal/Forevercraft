# Trade Trial modifier — Harasser (bit 10, RARE): spawn ONE weak mob.
# Run as/at: the trial player, from mods/apply (on start) and mods/harasser_tick (re-spawn).
# Scaled-down adoption of grand_forge/phase/spawn_wave (which spawns 5): we summon exactly 1,
# tagged ec.tt_mob so cleanup_player's existing `kill @e[tag=ec.tt_mob,...]` sweep removes it.
# Weak on purpose (no armour, low-tier) — pressure, not a kill-quest.
#
# Category flavour: mining = a "Cave Lurker" zombie. Farming (type 2) = a "Crop-Raider" husk
# (a sun-tolerant field pest gnawing the rows; husk won't burn under the open-sky arena).
# Fishing (type 3) = a "Reefstalker" drowned (an aquatic predator haunting the pool; the drowned
# is at home in the water and won't burn). Same ec.tt_mob tag -> cleanup_player's kill sweep.
execute if score @s ec.tt_type matches 2 at @s run summon minecraft:husk ~ ~ ~5 {Tags:["ec.tt_mob","ec.entity"],CustomName:{"text":"Crop-Raider","color":"red"},PersistenceRequired:1b,DeathLootTable:"minecraft:empty",Health:14.0f,Attributes:[{id:"minecraft:max_health",base:14.0d}]}
execute if score @s ec.tt_type matches 2 if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.husk.ambient master @s ~ ~ ~ 0.6 0.8
execute if score @s ec.tt_type matches 3 at @s run summon minecraft:drowned ~ ~ ~5 {Tags:["ec.tt_mob","ec.entity"],CustomName:{"text":"Reefstalker","color":"red"},PersistenceRequired:1b,DeathLootTable:"minecraft:empty",Health:14.0f,Attributes:[{id:"minecraft:max_health",base:14.0d}]}
execute if score @s ec.tt_type matches 3 if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.drowned.ambient master @s ~ ~ ~ 0.6 0.8
# Building flavour (type 4): a "Site Saboteur" husk — a grimy work-site pest that shoves the
# builder and trashes the staging. A husk is sun-tolerant so it won't burn under the open-sky
# arena. Same ec.tt_mob tag -> cleanup_player's kill sweep removes it.
execute if score @s ec.tt_type matches 4 at @s run summon minecraft:husk ~ ~ ~5 {Tags:["ec.tt_mob","ec.entity"],CustomName:{"text":"Site Saboteur","color":"red"},PersistenceRequired:1b,DeathLootTable:"minecraft:empty",Health:14.0f,Attributes:[{id:"minecraft:max_health",base:14.0d}]}
execute if score @s ec.tt_type matches 4 if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.husk.ambient master @s ~ ~ ~ 0.6 0.7
# Lumber flavour (type 5): a "Timberwolf" — a territorial forest predator that harries the feller
# as they work the grove. A wolf is at home in the open-sky forest (won't burn), is Angry so it
# stays hostile, and (NotForBuild-irrelevant) hunts the player. Same ec.tt_mob tag -> kill sweep.
execute if score @s ec.tt_type matches 5 at @s run summon minecraft:wolf ~ ~ ~5 {Tags:["ec.tt_mob","ec.entity"],CustomName:{"text":"Timberwolf","color":"red"},AngerTime:32000,PersistenceRequired:1b,DeathLootTable:"minecraft:empty",Health:14.0f,Attributes:[{id:"minecraft:max_health",base:14.0d}]}
execute if score @s ec.tt_type matches 5 if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.wolf.growl master @s ~ ~ ~ 0.7 0.8
# Artisan flavour (type 6): a "Cinderwraith" — a forge-construct of living cinder + slag that
# rises from the smelt-bath to harry the smith. A blaze is born of fire (it won't burn at the
# forge), stays hostile, and pelts the player with embers — the perfect forge-spirit pressure.
# Same ec.tt_mob tag -> cleanup_player's kill sweep removes it. Echoes the Grand Forge's fire aesthetic.
execute if score @s ec.tt_type matches 6 at @s run summon minecraft:blaze ~ ~ ~5 {Tags:["ec.tt_mob","ec.entity"],CustomName:{"text":"Cinderwraith","color":"red"},PersistenceRequired:1b,DeathLootTable:"minecraft:empty",Health:14.0f,Attributes:[{id:"minecraft:max_health",base:14.0d}]}
execute if score @s ec.tt_type matches 6 if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.blaze.ambient master @s ~ ~ ~ 0.7 0.8
# Default (mining + any category with no flavour): a Cave Lurker zombie.
execute unless score @s ec.tt_type matches 2 unless score @s ec.tt_type matches 3 unless score @s ec.tt_type matches 4 unless score @s ec.tt_type matches 5 unless score @s ec.tt_type matches 6 at @s run summon minecraft:zombie ~ ~ ~5 {Tags:["ec.tt_mob","ec.entity"],CustomName:{"text":"Cave Lurker","color":"red"},PersistenceRequired:1b,DeathLootTable:"minecraft:empty",Health:14.0f,Attributes:[{id:"minecraft:max_health",base:14.0d}]}
execute unless score @s ec.tt_type matches 2 unless score @s ec.tt_type matches 3 unless score @s ec.tt_type matches 4 unless score @s ec.tt_type matches 5 unless score @s ec.tt_type matches 6 if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.zombie.ambient master @s ~ ~ ~ 0.6 0.8
