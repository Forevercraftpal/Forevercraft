# Fishing trial rewards — dispatch by tier
# Inv-full guard: drop at the player's feet rather than void on a full inventory.
execute store result score #inv_full ec.var run function evercraft:util/check_inv_full
execute if score @s ec.tt_tier matches 1 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:craftforever/trials/fishing/t1_reward
execute if score @s ec.tt_tier matches 1 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:craftforever/trials/fishing/t1_reward
execute if score @s ec.tt_tier matches 2 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:craftforever/trials/fishing/t2_reward
execute if score @s ec.tt_tier matches 2 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:craftforever/trials/fishing/t2_reward
execute if score @s ec.tt_tier matches 3 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:craftforever/trials/fishing/t3_reward
execute if score @s ec.tt_tier matches 3 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:craftforever/trials/fishing/t3_reward
execute if score @s ec.tt_tier matches 4 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:craftforever/trials/fishing/t4_reward
execute if score @s ec.tt_tier matches 4 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:craftforever/trials/fishing/t4_reward
execute if score @s ec.tt_tier matches 5 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:craftforever/trials/fishing/t5_reward
execute if score @s ec.tt_tier matches 5 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:craftforever/trials/fishing/t5_reward
execute if score @s ec.tt_tier matches 6 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:craftforever/trials/fishing/t6_reward
execute if score @s ec.tt_tier matches 6 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:craftforever/trials/fishing/t6_reward
execute if score @s ec.tt_tier matches 7 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:craftforever/trials/fishing/t7_reward
execute if score @s ec.tt_tier matches 7 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:craftforever/trials/fishing/t7_reward
execute if score @s ec.tt_tier matches 8 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:craftforever/trials/fishing/t8_reward
execute if score @s ec.tt_tier matches 8 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:craftforever/trials/fishing/t8_reward
execute if score @s ec.tt_tier matches 9 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:craftforever/trials/fishing/t9_reward
execute if score @s ec.tt_tier matches 9 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:craftforever/trials/fishing/t9_reward
execute if score @s ec.tt_tier matches 10 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:craftforever/trials/fishing/t10_reward
execute if score @s ec.tt_tier matches 10 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:craftforever/trials/fishing/t10_reward

# 2% catalyst chance for Rank 30+ players (Council #4 wire; P1-1 inv-full guard via helper — single roll)
execute if score @s ec.tt_tier matches 10 if score @s ec.cf_rank matches 30.. if predicate evercraft:craftforever/catalyst_2pct run function evercraft:craftforever/trials/give_catalyst_drop

# Fisher's Questline spine: mirror the earned rod tier (1-9) for the rod_tier milestones
# (q8/q17/q22). Tier 10 = OWNING the spirit Tidecaller, set by on_catch_hook on use, not
# by clearing t10 (the Tidecaller is a 5% drop). Gated so non-questline players pay nothing.
execute if score @s ec.fq_active matches 1 if score @s ec.tt_tier matches 1..9 if score @s ec.tt_tier > @s ec.fq_rod_tier run scoreboard players operation @s ec.fq_rod_tier = @s ec.tt_tier
execute if score @s ec.fq_active matches 1 run function evercraft:fishing/questline/check
