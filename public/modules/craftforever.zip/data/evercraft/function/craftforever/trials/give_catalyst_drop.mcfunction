# Forge Catalyst T10 drop (Rank 30+, 2% roll already passed by caller)
# Run as/at the player. Inv-full guarded (P1-1) so the rare drop is never voided.
execute store result score #inv_full ec.var run function evercraft:util/check_inv_full
execute if score #inv_full ec.var matches 0 run loot give @s loot evercraft:craftforever/forge_catalyst
execute if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:craftforever/forge_catalyst
data modify storage evercraft:notify stage.c set value [{text:"◆ ",color:"gold"},{text:"Forge Catalyst",color:"gold",bold:true},{text:" found in the trial remnants! Right-click to ignite the Grand Forge.",color:"gray"}]
scoreboard players set #ndur ec.temp 50
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.beacon.activate master @s ~ ~ ~ 0.6 1.6
# Wiring Audit #14 C15: mark the Forge Catalysts almanac entry (cat2 #4) discovered.
function evercraft:craftforever/codex/hub/almanac/mark_found {field:"cf_craft_found",bit:8}
