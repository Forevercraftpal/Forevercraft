# Building T10 — THEMED INSTANCED ZONE (Craft-Trial Complexity Ladder, Wave 4)
# Run as/at: the trial player, from t10/build_zone (T10 only, AFTER build_t10 laid the base
# open 48x48 build floor + the four glowstone quadrant markers). This ADDS a castle-style
# multi-room depth on top of building's signature place-1000-blocks: a CONSTRUCTION SITE /
# SCAFFOLD zone — a SCAFFOLD-CLIMB + BEAM-WALK PARKOUR out over an open gap, a GHOST-BLUEPRINT
# decoy frame (a phantom stained-glass plan that looks like the build target but is NOT part of
# it — placing against it wastes blocks), and the real raised BUILD DECK across the gap (the
# uncontested high terrace — the prime real estate the parkour earns).
# Authored to fit the arena envelope (offset 0..47, Y300..323, all cleared by the standard
# fill_air sweep over Y298..325) so the standard teardown clears it — no per-zone teardown.
#
# Building had NO per-tier content before this wave (purely stat-scaled); this is its FIRST.
# Modeled on types/mining/build_t10_zone + types/fishing/build_t10_zone (the Wave-1/3 reference).
# Keeps building's reward + the 2% catalyst roll (in building/reward) untouched. The scorer is
# the existing per-tick placed-block sum (building/tick: ec.tt_s_cobble+dirt+planks - ec.tt_snap)
# — honest "you must BUILD" — the zone only changes WHERE the best build real estate is, never
# how scoring works (the central spawn deck is left clear so the player can still build there).

execute store result storage evercraft:trials zx int 1 run scoreboard players get @s ec.tt_arena_x
execute store result storage evercraft:trials zz int 1 run scoreboard players get @s ec.tt_arena_z
function evercraft:craftforever/trials/types/building/build_t10_zone_fill with storage evercraft:trials

# Themed intro title — the player arrives onto an instanced construction site.
title @s times 5 30 10
title @s subtitle {"text":"The high scaffold rises above the site…","color":"gold"}
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.scaffolding.place master @s ~ ~ ~ 1 0.9
