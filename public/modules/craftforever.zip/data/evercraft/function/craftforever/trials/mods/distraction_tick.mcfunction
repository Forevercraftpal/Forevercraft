# Trade Trial modifier — Distraction (bit 7): decoy particle noise + fake markers.
# Run as/at: the trial player, from mods/tick on the 2s cadence beat.
# Shared mechanic: bursts of misleading particles and a roaming fake "objective glint" a few
# blocks away, plus an occasional false ping, so the player must ignore the noise and stay on
# the real target. Particles are self-cleaning -> zero teardown cost.
#
# Category flavour: mining = ore-glint decoys. Farming (type 2) = a fake "ripe crop" sparkle —
# the bone-meal growth-burst the player chases to a row that turns out to be unripe.
# Fishing (type 3) = fake bobber-splashes / bubble columns — a phantom "bite" rippling the
# water nearby that the player chases, only to find no fish there.

# Roaming fake glint at a random nearby spot (the "decoy target").
# Farming: composter / growth sparkles that mimic a ripening crop.
# Wave 1 (Joseph 2026-06-10, actionbar-priority): every hazard paint below yields to the notify
# queue (`unless entity @s[tag=ab_q]`) — HUD convention. The 2s beat repaints it right after any
# queued frame drains, so the telegraph stays effectively continuous without stomping messages.
execute if score @s ec.tt_type matches 2 at @s run particle minecraft:happy_villager ^3 ^1 ^4 0.5 0.5 0.5 0.1 14 force
execute if score @s ec.tt_type matches 2 at @s run particle minecraft:composter ^-4 ^1 ^2 0.5 0.5 0.5 0.05 12 force
execute if score @s ec.tt_type matches 2 at @s run particle minecraft:falling_spore_blossom ^0 ^2 ^-4 0.5 0.5 0.5 0.2 18 force
execute if score @s ec.tt_type matches 2 if score @s ec.fx_snd matches 2.. run playsound minecraft:block.composter.fill_success master @s ~ ~ ~ 0.3 1.3
execute if score @s ec.tt_type matches 2 unless entity @s[tag=ab_q] run title @s actionbar {"text":"✦ A crop looks ripe over there… is it real?","color":"green"}
# Fishing: fishing-bobber splashes + bubble plumes that fake a bite somewhere it isn't.
execute if score @s ec.tt_type matches 3 at @s run particle minecraft:fishing ^3 ^1 ^4 0.5 0.5 0.5 0.1 16 force
execute if score @s ec.tt_type matches 3 at @s run particle minecraft:bubble_column_up ^-4 ^1 ^2 0.5 0.5 0.5 0.05 14 force
execute if score @s ec.tt_type matches 3 at @s run particle minecraft:splash ^0 ^2 ^-4 0.5 0.5 0.5 0.2 20 force
execute if score @s ec.tt_type matches 3 if score @s ec.fx_snd matches 2.. run playsound minecraft:entity.fishing_bobber.splash master @s ~ ~ ~ 0.4 1.2
execute if score @s ec.tt_type matches 3 unless entity @s[tag=ab_q] run title @s actionbar {"text":"✦ A splash ripples over there… is it a bite?","color":"aqua"}
# Building: GHOST-BLUEPRINT outlines — a decoy plan shimmers in the air nearby, a phantom
# wireframe of blocks-to-place that mimics the real build target but isn't part of it. The
# builder who chases the wrong outline wastes blocks. Block-marker + glint particles draw the
# false plan; particles self-clean -> zero teardown cost.
execute if score @s ec.tt_type matches 4 at @s run particle minecraft:glow ^3 ^1 ^4 0.5 0.5 0.5 0.05 16 force
execute if score @s ec.tt_type matches 4 at @s run particle minecraft:wax_on ^-4 ^1 ^2 0.5 0.5 0.5 0.05 12 force
execute if score @s ec.tt_type matches 4 at @s run particle minecraft:end_rod ^0 ^2 ^-4 0.5 0.5 0.5 0.1 18 force
execute if score @s ec.tt_type matches 4 if score @s ec.fx_snd matches 2.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.3 0.9
execute if score @s ec.tt_type matches 4 unless entity @s[tag=ab_q] run title @s actionbar {"text":"✦ A ghost blueprint shimmers nearby… is it the real plan?","color":"aqua"}
# Lumber: LEAF-FLURRY decoys — a gust shakes loose a swirl of falling leaves + a creak of bending
# wood somewhere it isn't, mimicking a tree about to fall so the feller turns the wrong way. The
# spore/leaf particles read as a shedding crown; they self-clean -> zero teardown cost.
execute if score @s ec.tt_type matches 5 at @s run particle minecraft:falling_spore_blossom ^3 ^2 ^4 0.6 0.8 0.6 0.2 18 force
execute if score @s ec.tt_type matches 5 at @s run particle minecraft:spore_blossom_air ^-4 ^2 ^2 0.6 0.8 0.6 0.05 14 force
execute if score @s ec.tt_type matches 5 at @s run particle minecraft:cherry_leaves ^0 ^2 ^-4 0.6 0.8 0.6 0.2 20 force
execute if score @s ec.tt_type matches 5 if score @s ec.fx_snd matches 2.. run playsound minecraft:block.bamboo_wood.break master @s ~ ~ ~ 0.4 0.7
execute if score @s ec.tt_type matches 5 unless entity @s[tag=ab_q] run title @s actionbar {"text":"✦ Leaves swirl as a tree creaks nearby… is it falling?","color":"green"}
# Artisan: FALSE-CATALYST decoys — a phantom forge-station flares to life nearby, embers + spark
# showers + a glint of "loose ingots" that mimic a fresh catalyst the smith should chase, but the
# station is cold and yields nothing. flame/lava-spark/crit particles read as a firing furnace;
# they self-clean -> zero teardown cost. Echoes the Grand Forge's anvil/ember aesthetic.
execute if score @s ec.tt_type matches 6 at @s run particle minecraft:flame ^3 ^1 ^4 0.5 0.5 0.5 0.02 16 force
execute if score @s ec.tt_type matches 6 at @s run particle minecraft:lava ^-4 ^1 ^2 0.5 0.5 0.5 0.05 8 force
execute if score @s ec.tt_type matches 6 at @s run particle minecraft:crit ^0 ^2 ^-4 0.5 0.5 0.5 0.4 20 force
execute if score @s ec.tt_type matches 6 if score @s ec.fx_snd matches 2.. run playsound minecraft:block.anvil.use master @s ~ ~ ~ 0.3 1.3
execute if score @s ec.tt_type matches 6 unless entity @s[tag=ab_q] run title @s actionbar {"text":"✦ A forge fires up nearby… is that a fresh catalyst?","color":"gold"}
# Default (mining + any category with no flavour): ore-glint decoys.
execute unless score @s ec.tt_type matches 2 unless score @s ec.tt_type matches 3 unless score @s ec.tt_type matches 4 unless score @s ec.tt_type matches 5 unless score @s ec.tt_type matches 6 at @s run particle minecraft:wax_off ^3 ^1 ^4 0.5 0.5 0.5 0.1 12 force
execute unless score @s ec.tt_type matches 2 unless score @s ec.tt_type matches 3 unless score @s ec.tt_type matches 4 unless score @s ec.tt_type matches 5 unless score @s ec.tt_type matches 6 at @s run particle minecraft:glow ^-4 ^1 ^2 0.5 0.5 0.5 0.05 10 force
execute unless score @s ec.tt_type matches 2 unless score @s ec.tt_type matches 3 unless score @s ec.tt_type matches 4 unless score @s ec.tt_type matches 5 unless score @s ec.tt_type matches 6 at @s run particle minecraft:enchant ^0 ^2 ^-4 0.5 0.5 0.5 0.6 20 force
execute unless score @s ec.tt_type matches 2 unless score @s ec.tt_type matches 3 unless score @s ec.tt_type matches 4 unless score @s ec.tt_type matches 5 unless score @s ec.tt_type matches 6 if score @s ec.fx_snd matches 2.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.3 1.4
execute unless score @s ec.tt_type matches 2 unless score @s ec.tt_type matches 3 unless score @s ec.tt_type matches 4 unless score @s ec.tt_type matches 5 unless score @s ec.tt_type matches 6 unless entity @s[tag=ab_q] run title @s actionbar {"text":"✦ A glint catches your eye… is it real?","color":"light_purple"}
