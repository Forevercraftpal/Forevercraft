# Trade Trial modifier — Harasser slow re-spawn (bit 10).
# Run as/at: the trial player, from mods/tick on the 2s cadence beat.
# Keeps exactly ONE ec.tt_mob alive near this player: if none is within the arena radius,
# re-spawn one. Scoped by distance to @s so concurrent trials don't cross-count each other.
# (2s cadence => a slow re-spawn, per the plan, not an instant swarm.)
execute unless entity @e[tag=ec.tt_mob,distance=..40] run function evercraft:craftforever/trials/mods/harasser_spawn
