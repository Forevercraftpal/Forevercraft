# Trade Trial — T10 remove this instance's isolation tag (macro)
# Called: function .../t10/untag_player with storage evercraft:trials  (pid set)
$tag @s remove p$(pid)
