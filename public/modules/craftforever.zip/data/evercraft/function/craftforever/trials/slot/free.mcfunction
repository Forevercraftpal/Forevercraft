# Trade Trial — release this player's arena grid slot. Run as the trial player from cleanup_player,
# AFTER fill_air (the chunks must stay loaded until the arena is cleared). Drops the forceload,
# frees the occupancy flag, and resets the player's slot index. No-op if no slot was held.
execute if score @s ec.tt_slot matches 1.. run function evercraft:craftforever/trials/slot/fl_box
execute if score @s ec.tt_slot matches 1.. run function evercraft:craftforever/trials/slot/forceload_remove with storage evercraft:trials
execute store result storage evercraft:trials slot int 1 run scoreboard players get @s ec.tt_slot
execute if score @s ec.tt_slot matches 1.. run function evercraft:craftforever/trials/slot/release with storage evercraft:trials
scoreboard players set @s ec.tt_slot 0
