# Trade Trial — decode ec.tt_mods into per-bit flags #tt_m0..#tt_m10 (1=active, 0=off).
# Run as/at: the trial player. Shared by mods/apply, mods/tick, mods/cleanup so each only
# does the bit math ONCE. Cheap: 11 div/mod ops, only called when #tt_active gates allow.
# Bit set test: (ec.tt_mods / 2^bit) % 2 == 1.

scoreboard players operation #tt_m0 ec.var = @s ec.tt_mods
scoreboard players operation #tt_m0 ec.var %= #2 ec.const

scoreboard players operation #tt_m1 ec.var = @s ec.tt_mods
scoreboard players operation #tt_m1 ec.var /= #2 ec.const
scoreboard players operation #tt_m1 ec.var %= #2 ec.const

scoreboard players operation #tt_m2 ec.var = @s ec.tt_mods
scoreboard players operation #tt_m2 ec.var /= #4 ec.const
scoreboard players operation #tt_m2 ec.var %= #2 ec.const

scoreboard players operation #tt_m3 ec.var = @s ec.tt_mods
scoreboard players operation #tt_m3 ec.var /= #8 ec.const
scoreboard players operation #tt_m3 ec.var %= #2 ec.const

scoreboard players operation #tt_m4 ec.var = @s ec.tt_mods
scoreboard players operation #tt_m4 ec.var /= #16 ec.const
scoreboard players operation #tt_m4 ec.var %= #2 ec.const

scoreboard players operation #tt_m5 ec.var = @s ec.tt_mods
scoreboard players operation #tt_m5 ec.var /= #32 ec.const
scoreboard players operation #tt_m5 ec.var %= #2 ec.const

scoreboard players operation #tt_m6 ec.var = @s ec.tt_mods
scoreboard players operation #tt_m6 ec.var /= #64 ec.const
scoreboard players operation #tt_m6 ec.var %= #2 ec.const

scoreboard players operation #tt_m7 ec.var = @s ec.tt_mods
scoreboard players operation #tt_m7 ec.var /= #128 ec.const
scoreboard players operation #tt_m7 ec.var %= #2 ec.const

scoreboard players operation #tt_m8 ec.var = @s ec.tt_mods
scoreboard players operation #tt_m8 ec.var /= #256 ec.const
scoreboard players operation #tt_m8 ec.var %= #2 ec.const

scoreboard players operation #tt_m9 ec.var = @s ec.tt_mods
scoreboard players operation #tt_m9 ec.var /= #512 ec.const
scoreboard players operation #tt_m9 ec.var %= #2 ec.const

scoreboard players operation #tt_m10 ec.var = @s ec.tt_mods
scoreboard players operation #tt_m10 ec.var /= #1024 ec.const
scoreboard players operation #tt_m10 ec.var %= #2 ec.const
