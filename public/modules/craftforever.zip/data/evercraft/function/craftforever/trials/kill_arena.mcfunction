# Trade Trial — kill every trial entity inside THIS arena's footprint (macro). Run with ax/az set.
#
# Box-anchored on the arena COLUMN (offset 0..48, Y294..345) so it catches mobs/items/hazards no
# matter where the player wandered. The old kills were a player-CENTRED sphere (distance=..50);
# when the player stood at one corner of the 48-wide arena the far corner was ~66 blocks away and
# escaped — so e.g. artisan T8's 35 sheep survived cleanup and free-fell ~240 blocks, "splatting"
# on builds below the moment fill_air pulled the floor. A box (not a wide radius) also never reaches
# into a neighbouring concurrent arena: ec.tt_mob/ec.tt_haz are NOT owner-scoped, so a big sphere
# could wipe another player's trial. (Arenas are built at the player's position with no spacing —
# this footprint box is the tightest selector that still reliably covers the whole arena.)
$kill @e[type=item,x=$(ax),y=294,z=$(az),dx=48,dy=51,dz=48]
$kill @e[tag=ec.tt_mob,x=$(ax),y=294,z=$(az),dx=48,dy=51,dz=48]
$kill @e[tag=ec.tt_haz,x=$(ax),y=294,z=$(az),dx=48,dy=51,dz=48]
