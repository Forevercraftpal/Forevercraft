# Trade Trial — the far-grid is full (all 64 arena slots in use). Tell the player and bail.
# Reached from start.mcfunction BEFORE consume_key, so no key/pass is spent. No state was set yet.
data modify storage evercraft:notify stage.c set value [{text:"All trial arenas are busy right now — try again in a moment!",color:"red"}]
scoreboard players set #ndur ec.temp 50
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 0.6 0.8
