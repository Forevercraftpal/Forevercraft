# Trade Trial — Modifier CLEANUP (teardown)
# Run as/at: the trial player, from trials/cleanup_player.
# MUST be called BEFORE the arena air-fill so any modifier blocks/entities are gone with the
# arena (the lava/parkour/anvil blocks live INSIDE the arena envelope and fill_air clears them;
# we only need to clear EFFECTS, ENTITIES, and SCORES here). Idempotent — safe if no mods rolled.

# --- Remove every effect a modifier could have applied ---
effect clear @s minecraft:slowness
effect clear @s minecraft:darkness
effect clear @s minecraft:blindness
effect clear @s minecraft:mining_fatigue
effect clear @s minecraft:weakness

# --- Kill modifier entities still in the arena band (player is still in-arena at this point) ---
# Harasser mob (ec.tt_mob is ALSO killed by cleanup_player's sweep, but we do it here too so a
# fail/early-exit path that calls mods/cleanup first never leaks). In-flight falling-block
# hazards (ec.tt_haz) are killed here since fill_air only removes landed blocks, not entities.
execute positioned ~ 300 ~ run kill @e[tag=ec.tt_mob,distance=..50,y=295,dy=50]
execute positioned ~ 300 ~ run kill @e[tag=ec.tt_haz,distance=..50,y=295,dy=50]

# --- Reset modifier scores (the bitfield + hazard cadence/level) ---
scoreboard players set @s ec.tt_mods 0
scoreboard players set @s ec.tt_haz_t 0
scoreboard players set @s ec.tt_haz_y 0
