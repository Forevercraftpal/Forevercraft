# Trade Trial — Modifier APPLY (on-start effects)
# Run as/at: the trial player, ONCE at trial start (from trials/start, after mods/roll).
# Applies the durable on-start effects for each active bit and initialises hazard state.
# Per-tick logic (hazard cadence, decoys, parkour pressure) lives in mods/tick.

function evercraft:craftforever/trials/mods/_decode

# Reset hazard cadence state for this run.
scoreboard players set @s ec.tt_haz_t 0
scoreboard players set @s ec.tt_haz_y 0

# --- bit 0: Slowness (debuff) ---
# Long duration; cleared in mods/cleanup. Slowness I (amplifier 0) is firm but fair.
execute if score #tt_m0 ec.var matches 1 run effect give @s minecraft:slowness 9999 0 true

# --- bit 1: Darkness (debuff) ---
execute if score #tt_m1 ec.var matches 1 run effect give @s minecraft:darkness 9999 0 true

# --- bit 2: Fatigue (debuff) ---
# Mining flavour = mining_fatigue (slower break). Other categories = weakness. mods/tick
# does not touch this; it is a pure on-start debuff.
execute if score #tt_m2 ec.var matches 1 if score @s ec.tt_type matches 1 run effect give @s minecraft:mining_fatigue 9999 0 true
execute if score #tt_m2 ec.var matches 1 unless score @s ec.tt_type matches 1 run effect give @s minecraft:weakness 9999 0 true

# --- bit 4: Creeping hazard (env) — seed the rising floor at arena floor level ---
# Arena interior floor sits at Y=300 (build_shell). The creeping layer starts one above it.
execute if score #tt_m4 ec.var matches 1 run scoreboard players set @s ec.tt_haz_y 300

# --- bit 8: Parkour (depth) — build a traversal gap near spawn ---
# Generic shared build: a short floating-island jump course just off the spawn platform.
# Lives inside the arena envelope so fill_air cleans it at teardown (no extra cleanup).
execute if score #tt_m8 ec.var matches 1 run function evercraft:craftforever/trials/mods/parkour_build

# --- bit 10: Harasser (RARE combat) — spawn ONE weak ec.tt_mob ---
execute if score #tt_m10 ec.var matches 1 run function evercraft:craftforever/trials/mods/harasser_spawn

# On-start announce sound so the player feels the run "lock in".
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.respawn_anchor.charge master @s ~ ~ ~ 0.7 0.8
