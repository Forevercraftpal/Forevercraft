# (admin) Reset the entire trial arena-slot grid. Run as operator.
# Use if a slot ever LEAKS — e.g. a player was mid-trial during a server restart and never relogged
# (their crash_recovery never fired to free the slot + drop the forceload). Assumes no trials are
# active. Wipes every occupancy flag (by clearing+re-adding the objective, which also zeroes every
# player's claimed index) and drops every forceload across the dedicated grid footprint ONLY —
# the bounded `forceload remove <region>` never touches housing's forceloads elsewhere.
scoreboard objectives remove ec.tt_slot
scoreboard objectives add ec.tt_slot dummy "TT Slot"
# Grid spans X 2,000,000..2,001,920 / Z 2,000,000..2,000,384 (+ envelope); clear a safe super-box.
forceload remove 1999980 1999980 2002010 2000460
