# Trade Trial — ORDERED, physics-safe arena teardown (macro). Run with ax/az in storage.
#
# The arena interior (offset 0..47, Y299..324) is wrapped by an invisible barrier shell
# (offset -1..48, Y298..325) and floats ~240 blocks above the real terrain. The ORDER below is
# load-bearing — clearing blindly griefs the site and lags the server:
#
#   PHASE 1 — FLUIDS FIRST (water + lava -> air). Remove every fluid SOURCE before any solid.
#     If solids went first, orphaned water/lava would pour ~240 blocks straight down to the real
#     ground — a flowing-fluid cascade that updates for many ticks and lags HARD (a real problem
#     if several players finish trials at once). Killing the sources first means there is nothing
#     left to flow when the blocks around them vanish. Covers a touch past the shell (offset -2..49)
#     so edge fluid against the barrier is caught too.
#
#   PHASE 2 — EVERYTHING ABOVE THE FLOOR (blanket air, Y300+). This erases crops/plants, the
#     shell walls, decor AND whatever the player PLACED — while the floor (Y299) stays put. Because
#     each crop is set to air with its support block still beneath it (we never pull the dirt out
#     from under a standing crop), nothing pops off as a dropped item ("a rain of wheat and seeds").
#     Runs the fat +10 envelope (offset -11..58) so the perimeter walls + anything that crept past
#     the barrier are swept up.
#
#   PHASE 3 — THE FLOOR LAST (blanket air, Y298..299). With every fluid gone and everything above
#     already air, pulling the floor + barrier base drops nothing and floods nothing.
#
# fill caps at 32768 blocks/call, so each phase is split to stay under the cap.

# === PHASE 1: fluids first (interior + 1-block barrier margin, Y299..320) ===
$execute positioned $(ax) 299 $(az) run fill ~-2 ~ ~-2 ~49 ~11 ~49 air replace water
$execute positioned $(ax) 311 $(az) run fill ~-2 ~ ~-2 ~49 ~9 ~49 air replace water
$execute positioned $(ax) 299 $(az) run fill ~-2 ~ ~-2 ~49 ~11 ~49 air replace lava
$execute positioned $(ax) 311 $(az) run fill ~-2 ~ ~-2 ~49 ~9 ~49 air replace lava

# === PHASE 2: everything above the floor (blanket air, +10 envelope, Y300..326) ===
$execute positioned $(ax) 300 $(az) run fill ~-11 ~ ~-11 ~58 ~5 ~58 air
$execute positioned $(ax) 306 $(az) run fill ~-11 ~ ~-11 ~58 ~5 ~58 air
$execute positioned $(ax) 312 $(az) run fill ~-11 ~ ~-11 ~58 ~5 ~58 air
$execute positioned $(ax) 318 $(az) run fill ~-11 ~ ~-11 ~58 ~5 ~58 air
$execute positioned $(ax) 324 $(az) run fill ~-11 ~ ~-11 ~58 ~2 ~58 air

# === PHASE 3: the floor + barrier base last (blanket air, +10 envelope, Y298..299) ===
$execute positioned $(ax) 298 $(az) run fill ~-11 ~ ~-11 ~58 ~1 ~58 air
