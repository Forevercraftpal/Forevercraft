# Forceload the arena slot's chunks (macro). Run with storage evercraft:trials {fx1,fz1,fx2,fz2}.
# Keeps the far-grid arena loaded so its build (and later fill_air teardown) actually apply even
# though the player isn't standing in those chunks yet. Removed in slot/free at cleanup.
$forceload add $(fx1) $(fz1) $(fx2) $(fz2)
