# Artisan Forge — Dye Block (right-click with dye)
# Run as: the interaction entity, at its position
# Called from on_interact when player holds a dye


# Detect which dye the player is holding
execute as @p[distance=..6] run function evercraft:dyeing/detect_color

# Azure
execute if data storage evercraft:dyeing {color_id:"azure"} as @e[type=marker,tag=CF.Marker,distance=..2,limit=1] run data modify entity @s data.color set value "artisan_forge_azure"
execute if data storage evercraft:dyeing {color_id:"azure"} as @e[type=armor_stand,tag=CF.Stand,distance=..2,limit=1] on passengers run data modify entity @s item.components."minecraft:profile".properties[0].value set value "ewogICJ0aW1lc3RhbXAiIDogMTc3NDM2OTQ4NDcxOSwKICAicHJvZmlsZUlkIiA6ICI1ZTEwYjc5MTY2ZTA0MTNkYjI2MThkMzE3MTc2M2Y4NCIsCiAgInByb2ZpbGVOYW1lIiA6ICJPTUZfQmxvY2tCdXN0ZXIiLAogICJzaWduYXR1cmVSZXF1aXJlZCIgOiB0cnVlLAogICJ0ZXh0dXJlcyIgOiB7CiAgICAiU0tJTiIgOiB7CiAgICAgICJ1cmwiIDogImh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvM2RiNjA5ZjUwNmZmYTYyYWM3NDkzMWY2YTcwODkwYjQxNWFhNmU2N2E3NjZmYTdhYjc3NzYwNzA0NjY5NzZiOCIsCiAgICAgICJtZXRhZGF0YSIgOiB7CiAgICAgICAgIm1vZGVsIiA6ICJzbGltIgogICAgICB9CiAgICB9CiAgfQp9"

# Crimson
execute if data storage evercraft:dyeing {color_id:"crimson"} as @e[type=marker,tag=CF.Marker,distance=..2,limit=1] run data modify entity @s data.color set value "artisan_forge_crimson"
execute if data storage evercraft:dyeing {color_id:"crimson"} as @e[type=armor_stand,tag=CF.Stand,distance=..2,limit=1] on passengers run data modify entity @s item.components."minecraft:profile".properties[0].value set value "ewogICJ0aW1lc3RhbXAiIDogMTc3NDM2OTQ5NjQyNCwKICAicHJvZmlsZUlkIiA6ICI1YmZhNjQzZjQ0ZDg0YmZmODEwZjJkYzlmOGEzOTY1MCIsCiAgInByb2ZpbGVOYW1lIiA6ICJJdHNSbER1eGciLAogICJzaWduYXR1cmVSZXF1aXJlZCIgOiB0cnVlLAogICJ0ZXh0dXJlcyIgOiB7CiAgICAiU0tJTiIgOiB7CiAgICAgICJ1cmwiIDogImh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvMWVlYzI4ZWExMDU2YmYyYmI1MzU5MzFjNmFjMjg2YmZlOTkwMjM3YzM5NjcyMmIyNDYxOTc2ZDIxMDdkMTBlYyIsCiAgICAgICJtZXRhZGF0YSIgOiB7CiAgICAgICAgIm1vZGVsIiA6ICJzbGltIgogICAgICB9CiAgICB9CiAgfQp9"

# Solar
execute if data storage evercraft:dyeing {color_id:"solar"} as @e[type=marker,tag=CF.Marker,distance=..2,limit=1] run data modify entity @s data.color set value "artisan_forge_solar"
execute if data storage evercraft:dyeing {color_id:"solar"} as @e[type=armor_stand,tag=CF.Stand,distance=..2,limit=1] on passengers run data modify entity @s item.components."minecraft:profile".properties[0].value set value "ewogICJ0aW1lc3RhbXAiIDogMTc3NDM2OTUwNzc3NSwKICAicHJvZmlsZUlkIiA6ICI1MzE4YWJhNDJiMTk0ODNiODFiMWY2N2Y1ODVjNDdkNSIsCiAgInByb2ZpbGVOYW1lIiA6ICJocHllZiIsCiAgInNpZ25hdHVyZVJlcXVpcmVkIiA6IHRydWUsCiAgInRleHR1cmVzIiA6IHsKICAgICJTS0lOIiA6IHsKICAgICAgInVybCIgOiAiaHR0cDovL3RleHR1cmVzLm1pbmVjcmFmdC5uZXQvdGV4dHVyZS8zMDRkYzZjOTFiZjA3ZjVmOTc4YjQzZjk1ZDVlZmU2ZWE5NmQwMTY2YmFkZDVmYjRlNTliODc1YWY2ZGVmY2QiLAogICAgICAibWV0YWRhdGEiIDogewogICAgICAgICJtb2RlbCIgOiAic2xpbSIKICAgICAgfQogICAgfQogIH0KfQ=="

# Verdant
execute if data storage evercraft:dyeing {color_id:"verdant"} as @e[type=marker,tag=CF.Marker,distance=..2,limit=1] run data modify entity @s data.color set value "artisan_forge_verdant"
execute if data storage evercraft:dyeing {color_id:"verdant"} as @e[type=armor_stand,tag=CF.Stand,distance=..2,limit=1] on passengers run data modify entity @s item.components."minecraft:profile".properties[0].value set value "ewogICJ0aW1lc3RhbXAiIDogMTc3NDM2OTUxOTIyNiwKICAicHJvZmlsZUlkIiA6ICIzYWE3NzRlYjRiNmY0MzlkODA1NDJiNWIzYjFmNzY5ZCIsCiAgInByb2ZpbGVOYW1lIiA6ICJUaGVSb3NlUXVlZW4xOTIiLAogICJzaWduYXR1cmVSZXF1aXJlZCIgOiB0cnVlLAogICJ0ZXh0dXJlcyIgOiB7CiAgICAiU0tJTiIgOiB7CiAgICAgICJ1cmwiIDogImh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvMTI4YTNhNDFmYmRlNmM2NjhlZjNkMDYxNmY0YWFhOTUzNGE5NTg1ODY3ODdjOTVlZjZlOTZlZWUwNTVlNjkwZCIsCiAgICAgICJtZXRhZGF0YSIgOiB7CiAgICAgICAgIm1vZGVsIiA6ICJzbGltIgogICAgICB9CiAgICB9CiAgfQp9"

# Ivory
execute if data storage evercraft:dyeing {color_id:"ivory"} as @e[type=marker,tag=CF.Marker,distance=..2,limit=1] run data modify entity @s data.color set value "artisan_forge_ivory"
execute if data storage evercraft:dyeing {color_id:"ivory"} as @e[type=armor_stand,tag=CF.Stand,distance=..2,limit=1] on passengers run data modify entity @s item.components."minecraft:profile".properties[0].value set value "ewogICJ0aW1lc3RhbXAiIDogMTc3NDM2OTUzMDk2MCwKICAicHJvZmlsZUlkIiA6ICI3YmFiY2ExNGU2MDI0MTJlYTM3YjU5NjU1MGZkOWRiYSIsCiAgInByb2ZpbGVOYW1lIiA6ICJNaWthX05vZWwiLAogICJzaWduYXR1cmVSZXF1aXJlZCIgOiB0cnVlLAogICJ0ZXh0dXJlcyIgOiB7CiAgICAiU0tJTiIgOiB7CiAgICAgICJ1cmwiIDogImh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvYzZmYjJhYTgwOTVhOGI2Yjg5MWRhMGU4OGRlMThhYzAzMmUwOWQ0ZTI2MDlkNjdlYzZiYzgxMzYzYzEyYjNhMiIsCiAgICAgICJtZXRhZGF0YSIgOiB7CiAgICAgICAgIm1vZGVsIiA6ICJzbGltIgogICAgICB9CiAgICB9CiAgfQp9"

# Obsidian
execute if data storage evercraft:dyeing {color_id:"obsidian"} as @e[type=marker,tag=CF.Marker,distance=..2,limit=1] run data modify entity @s data.color set value "artisan_forge_obsidian"
execute if data storage evercraft:dyeing {color_id:"obsidian"} as @e[type=armor_stand,tag=CF.Stand,distance=..2,limit=1] on passengers run data modify entity @s item.components."minecraft:profile".properties[0].value set value "ewogICJ0aW1lc3RhbXAiIDogMTc3NDM2OTU0MjM3NSwKICAicHJvZmlsZUlkIiA6ICI0MjJlMzdiNjc4ZGU0OTA2YWFiMWU5NGY0N2E5NGM0OSIsCiAgInByb2ZpbGVOYW1lIiA6ICJzcGlmZnRvcGlhOSIsCiAgInNpZ25hdHVyZVJlcXVpcmVkIiA6IHRydWUsCiAgInRleHR1cmVzIiA6IHsKICAgICJTS0lOIiA6IHsKICAgICAgInVybCIgOiAiaHR0cDovL3RleHR1cmVzLm1pbmVjcmFmdC5uZXQvdGV4dHVyZS9hMjFlNGUxYWQ0NThkMzQ5OWMzYjIwYWM5YTg3ZmI0N2Y3M2VmOGExZTRhNWU2YWM4MzBjYThkYTU0ZmEyYjYzIiwKICAgICAgIm1ldGFkYXRhIiA6IHsKICAgICAgICAibW9kZWwiIDogInNsaW0iCiAgICAgIH0KICAgIH0KICB9Cn0="

# Rose
execute if data storage evercraft:dyeing {color_id:"rose"} as @e[type=marker,tag=CF.Marker,distance=..2,limit=1] run data modify entity @s data.color set value "artisan_forge_rose"
execute if data storage evercraft:dyeing {color_id:"rose"} as @e[type=armor_stand,tag=CF.Stand,distance=..2,limit=1] on passengers run data modify entity @s item.components."minecraft:profile".properties[0].value set value "ewogICJ0aW1lc3RhbXAiIDogMTc3NDM2OTU1MzQ3MCwKICAicHJvZmlsZUlkIiA6ICIzMjFjNTBiMjJhY2Q0OGUxOGEyMGU0N2I2ZThhYjE2ZSIsCiAgInByb2ZpbGVOYW1lIiA6ICJsaWdodDEzMzM3IiwKICAic2lnbmF0dXJlUmVxdWlyZWQiIDogdHJ1ZSwKICAidGV4dHVyZXMiIDogewogICAgIlNLSU4iIDogewogICAgICAidXJsIiA6ICJodHRwOi8vdGV4dHVyZXMubWluZWNyYWZ0Lm5ldC90ZXh0dXJlLzM5NTJiM2ZkMTE0YmY0NmNhMWZmY2MzYTRiMzM4YWI2ZDMwMWI3NWFhYWJhNDFiNzViYzY0YjVlNWMzZjU2MjQiLAogICAgICAibWV0YWRhdGEiIDogewogICAgICAgICJtb2RlbCIgOiAic2xpbSIKICAgICAgfQogICAgfQogIH0KfQ=="

# Noir
execute if data storage evercraft:dyeing {color_id:"noir"} as @e[type=marker,tag=CF.Marker,distance=..2,limit=1] run data modify entity @s data.color set value "artisan_forge_noir"
execute if data storage evercraft:dyeing {color_id:"noir"} as @e[type=armor_stand,tag=CF.Stand,distance=..2,limit=1] on passengers run data modify entity @s item.components."minecraft:profile".properties[0].value set value "ewogICJ0aW1lc3RhbXAiIDogMTc3NDM2OTU2NDY2NSwKICAicHJvZmlsZUlkIiA6ICJiOTc3ODUwYWMxMGE0Mjk4YmRiNWNhYjBhODA0NmM4YSIsCiAgInByb2ZpbGVOYW1lIiA6ICJTb3JheER1YmJlciIsCiAgInNpZ25hdHVyZVJlcXVpcmVkIiA6IHRydWUsCiAgInRleHR1cmVzIiA6IHsKICAgICJTS0lOIiA6IHsKICAgICAgInVybCIgOiAiaHR0cDovL3RleHR1cmVzLm1pbmVjcmFmdC5uZXQvdGV4dHVyZS84YjRiZmQwZTYyMTFiZDI4OTM5Yzc4NDliMmQ1NTI0MDMwYTllOGQyMzNiNmQ2NzJkMmY3NGRiYTllZDY1ZGU1IiwKICAgICAgIm1ldGFkYXRhIiA6IHsKICAgICAgICAibW9kZWwiIDogInNsaW0iCiAgICAgIH0KICAgIH0KICB9Cn0="

# Consume 1 dye from player's hand
execute as @p[distance=..6] run item modify entity @s weapon.mainhand {"function":"minecraft:set_count","count":-1,"add":true}

# Effects
function evercraft:dyeing/effects

# Feedback
data modify storage evercraft:notify stage.c set value [{text:"Dyed ",color:"gray",italic:true},{storage:"evercraft:dyeing",nbt:"color_name",interpret:false,color:"#E0B0FF",italic:true},{text:" Artisan Forge",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 45
execute as @p[distance=..6] run function evercraft:util/notify/emit
