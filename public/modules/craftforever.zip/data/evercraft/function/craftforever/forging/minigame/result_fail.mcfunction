# Forging Result: FAIL — Produce Slag or Artifact (if artifact material)

# Check if this is an artifact material forge (art_cat 1-4)
execute if score @s ec.cf_art_cat matches 1..4 run function evercraft:craftforever/forging/minigame/result_fail_artifact
execute if score @s ec.cf_art_cat matches 1..4 run return 0

# Standard forge fail — always slag
data modify storage evercraft:notify stage.c set value [{text:"The material crumbled \u2014 Slag produced.",color:"red"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute at @s run function evercraft:fx/craft/forge_fail

# Give slag
execute if score #inv_full ec.var matches 0 run loot give @s loot evercraft:craftforever/materials/slag
execute if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:craftforever/materials/slag

# Byproduct: Slag → Mineral reagent (25% chance)
execute store result score #byp_roll ec.cf_temp run random value 1..4
# Inv-full guard: drop at the player's feet rather than void on a full inventory.
execute store result score #inv_full ec.var run function evercraft:util/check_inv_full
execute if score #byp_roll ec.cf_temp matches 1 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:alchemy/reagents/byproduct_mineral
execute if score #byp_roll ec.cf_temp matches 1 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:alchemy/reagents/byproduct_mineral
