# Artifact drop, inv-full guarded (Wiring Audit #3 S1.3, 2026-05-29).
# Macro arg: $(tbl) = artifact loot table path tail (e.g. "common_weapon", "mythical_armor").
# #inv_full ec.var must already be computed by the caller this tick.
$execute if score #inv_full ec.var matches 0 run loot give @s loot evercraft:craftforever/artifacts/$(tbl)
$execute if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:craftforever/artifacts/$(tbl)
