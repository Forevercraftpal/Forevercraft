# Artisan Forge — Do Deposit Material (runs as player)
# Check mainhand for forge materials and deposit them

# Already deposited?
data modify storage evercraft:notify stage.c set value [{text:"Material already deposited!",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute if score @s ec.cf_mat_tier matches 0.. run return run function evercraft:util/notify/emit

# Check each tier via clear ... 0 (returns count found, does NOT remove)
# store result (not success) to get actual item count for >= 3 check
scoreboard players set @s ec.cf_mat_tier -1
scoreboard players set @s ec.cf_art_cat 0
scoreboard players set @s ec.cf_art_tier 0

# === STANDARD MATERIALS (Tier 0-5) ===
execute store result score #cf_count ec.cf_temp run clear @s iron_nugget[custom_data~{forge_mat:"scrap_metal"}] 0
execute if score #cf_count ec.cf_temp matches 3.. run scoreboard players set @s ec.cf_mat_tier 0

execute if score @s ec.cf_mat_tier matches -1 store result score #cf_count ec.cf_temp run clear @s iron_ingot[custom_data~{forge_mat:"tempered_alloy"}] 0
execute if score #cf_count ec.cf_temp matches 3.. if score @s ec.cf_mat_tier matches -1 run scoreboard players set @s ec.cf_mat_tier 1

execute if score @s ec.cf_mat_tier matches -1 store result score #cf_count ec.cf_temp run clear @s diamond[custom_data~{forge_mat:"starforged_ingot"}] 0
execute if score #cf_count ec.cf_temp matches 3.. if score @s ec.cf_mat_tier matches -1 run scoreboard players set @s ec.cf_mat_tier 2

execute if score @s ec.cf_mat_tier matches -1 store result score #cf_count ec.cf_temp run clear @s amethyst_shard[custom_data~{forge_mat:"dreamwrought_bar"}] 0
execute if score #cf_count ec.cf_temp matches 3.. if score @s ec.cf_mat_tier matches -1 run scoreboard players set @s ec.cf_mat_tier 3

execute if score @s ec.cf_mat_tier matches -1 store result score #cf_count ec.cf_temp run clear @s gold_ingot[custom_data~{forge_mat:"eternal_essence"}] 0
execute if score #cf_count ec.cf_temp matches 3.. if score @s ec.cf_mat_tier matches -1 run scoreboard players set @s ec.cf_mat_tier 4

execute if score @s ec.cf_mat_tier matches -1 store result score #cf_count ec.cf_temp run clear @s nether_star[custom_data~{forge_mat:"soulbound_core"}] 0
execute if score #cf_count ec.cf_temp matches 3.. if score @s ec.cf_mat_tier matches -1 run scoreboard players set @s ec.cf_mat_tier 5

# mat_tier 5 (Soulbound Core) refuse-guard — Wiring Audit #3, 2026-05-29
# Soulbound Core has no Artisan Forge recipe; it's reserved for the Grand Forge.
# Without this guard, line 186 consumes 3 Soulbound Cores silently (rare endgame material).
execute if score @s ec.cf_mat_tier matches 5 run scoreboard players set @s ec.cf_mat_tier -1
data modify storage evercraft:notify stage.c set value [{text:"Soulbound Core belongs in the Grand Forge, not the Artisan Forge.",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute if score @s ec.cf_mat_tier matches -1 if score #cf_count ec.cf_temp matches 3.. run return run function evercraft:util/notify/emit

# Geode Dust (mat_tier 6) — Wiring Audit #37 D1. A mid-tier standard material dug from buried caches
# (Terrawarp). glowstone_dust base + forge_mat:"geode_dust" (distinct base item, no collision with the
# iron/diamond/star tiers). Pairs with Heart of the Sea (cat_tier 2) -> Dreamwrought Bar in match_recipe.
# Placed AFTER the soulbound refuse-guard so the guard's `#cf_count matches 3..` test reads the soulbound
# count, not a clobbered geode count. mat_tier still -1 here unless a standard 0-4 already matched.
execute if score @s ec.cf_mat_tier matches -1 store result score #cf_count ec.cf_temp run clear @s glowstone_dust[custom_data~{forge_mat:"geode_dust"}] 0
execute if score #cf_count ec.cf_temp matches 3.. if score @s ec.cf_mat_tier matches -1 run scoreboard players set @s ec.cf_mat_tier 6

# === WEAPON MATERIALS (mat_tier 10-16, art_cat=1) ===
execute if score @s ec.cf_mat_tier matches -1 store result score #cf_count ec.cf_temp run clear @s iron_nugget[custom_data~{forge_mat:"weapon_t1"}] 0
execute if score #cf_count ec.cf_temp matches 3.. if score @s ec.cf_mat_tier matches -1 run scoreboard players set @s ec.cf_mat_tier 10
execute if score @s ec.cf_mat_tier matches 10 run scoreboard players set @s ec.cf_art_cat 1
execute if score @s ec.cf_mat_tier matches 10 run scoreboard players set @s ec.cf_art_tier 1

execute if score @s ec.cf_mat_tier matches -1 store result score #cf_count ec.cf_temp run clear @s iron_ingot[custom_data~{forge_mat:"weapon_t2"}] 0
execute if score #cf_count ec.cf_temp matches 3.. if score @s ec.cf_mat_tier matches -1 run scoreboard players set @s ec.cf_mat_tier 11
execute if score @s ec.cf_mat_tier matches 11 run scoreboard players set @s ec.cf_art_cat 1
execute if score @s ec.cf_mat_tier matches 11 run scoreboard players set @s ec.cf_art_tier 2

execute if score @s ec.cf_mat_tier matches -1 store result score #cf_count ec.cf_temp run clear @s diamond[custom_data~{forge_mat:"weapon_t3"}] 0
execute if score #cf_count ec.cf_temp matches 3.. if score @s ec.cf_mat_tier matches -1 run scoreboard players set @s ec.cf_mat_tier 12
execute if score @s ec.cf_mat_tier matches 12 run scoreboard players set @s ec.cf_art_cat 1
execute if score @s ec.cf_mat_tier matches 12 run scoreboard players set @s ec.cf_art_tier 3

execute if score @s ec.cf_mat_tier matches -1 store result score #cf_count ec.cf_temp run clear @s amethyst_shard[custom_data~{forge_mat:"weapon_t4"}] 0
execute if score #cf_count ec.cf_temp matches 3.. if score @s ec.cf_mat_tier matches -1 run scoreboard players set @s ec.cf_mat_tier 13
execute if score @s ec.cf_mat_tier matches 13 run scoreboard players set @s ec.cf_art_cat 1
execute if score @s ec.cf_mat_tier matches 13 run scoreboard players set @s ec.cf_art_tier 4

execute if score @s ec.cf_mat_tier matches -1 store result score #cf_count ec.cf_temp run clear @s gold_ingot[custom_data~{forge_mat:"weapon_t5"}] 0
execute if score #cf_count ec.cf_temp matches 3.. if score @s ec.cf_mat_tier matches -1 run scoreboard players set @s ec.cf_mat_tier 14
execute if score @s ec.cf_mat_tier matches 14 run scoreboard players set @s ec.cf_art_cat 1
execute if score @s ec.cf_mat_tier matches 14 run scoreboard players set @s ec.cf_art_tier 5

execute if score @s ec.cf_mat_tier matches -1 store result score #cf_count ec.cf_temp run clear @s nether_star[custom_data~{forge_mat:"weapon_t6"}] 0
execute if score #cf_count ec.cf_temp matches 3.. if score @s ec.cf_mat_tier matches -1 run scoreboard players set @s ec.cf_mat_tier 15
execute if score @s ec.cf_mat_tier matches 15 run scoreboard players set @s ec.cf_art_cat 1
execute if score @s ec.cf_mat_tier matches 15 run scoreboard players set @s ec.cf_art_tier 6

execute if score @s ec.cf_mat_tier matches -1 store result score #cf_count ec.cf_temp run clear @s echo_shard[custom_data~{forge_mat:"weapon_t7"}] 0
execute if score #cf_count ec.cf_temp matches 3.. if score @s ec.cf_mat_tier matches -1 run scoreboard players set @s ec.cf_mat_tier 16
execute if score @s ec.cf_mat_tier matches 16 run scoreboard players set @s ec.cf_art_cat 1
execute if score @s ec.cf_mat_tier matches 16 run scoreboard players set @s ec.cf_art_tier 7

# === ARMOR MATERIALS (mat_tier 20-26, art_cat=2) ===
execute if score @s ec.cf_mat_tier matches -1 store result score #cf_count ec.cf_temp run clear @s iron_nugget[custom_data~{forge_mat:"armor_t1"}] 0
execute if score #cf_count ec.cf_temp matches 3.. if score @s ec.cf_mat_tier matches -1 run scoreboard players set @s ec.cf_mat_tier 20
execute if score @s ec.cf_mat_tier matches 20 run scoreboard players set @s ec.cf_art_cat 2
execute if score @s ec.cf_mat_tier matches 20 run scoreboard players set @s ec.cf_art_tier 1

execute if score @s ec.cf_mat_tier matches -1 store result score #cf_count ec.cf_temp run clear @s iron_ingot[custom_data~{forge_mat:"armor_t2"}] 0
execute if score #cf_count ec.cf_temp matches 3.. if score @s ec.cf_mat_tier matches -1 run scoreboard players set @s ec.cf_mat_tier 21
execute if score @s ec.cf_mat_tier matches 21 run scoreboard players set @s ec.cf_art_cat 2
execute if score @s ec.cf_mat_tier matches 21 run scoreboard players set @s ec.cf_art_tier 2

execute if score @s ec.cf_mat_tier matches -1 store result score #cf_count ec.cf_temp run clear @s diamond[custom_data~{forge_mat:"armor_t3"}] 0
execute if score #cf_count ec.cf_temp matches 3.. if score @s ec.cf_mat_tier matches -1 run scoreboard players set @s ec.cf_mat_tier 22
execute if score @s ec.cf_mat_tier matches 22 run scoreboard players set @s ec.cf_art_cat 2
execute if score @s ec.cf_mat_tier matches 22 run scoreboard players set @s ec.cf_art_tier 3

execute if score @s ec.cf_mat_tier matches -1 store result score #cf_count ec.cf_temp run clear @s amethyst_shard[custom_data~{forge_mat:"armor_t4"}] 0
execute if score #cf_count ec.cf_temp matches 3.. if score @s ec.cf_mat_tier matches -1 run scoreboard players set @s ec.cf_mat_tier 23
execute if score @s ec.cf_mat_tier matches 23 run scoreboard players set @s ec.cf_art_cat 2
execute if score @s ec.cf_mat_tier matches 23 run scoreboard players set @s ec.cf_art_tier 4

execute if score @s ec.cf_mat_tier matches -1 store result score #cf_count ec.cf_temp run clear @s gold_ingot[custom_data~{forge_mat:"armor_t5"}] 0
execute if score #cf_count ec.cf_temp matches 3.. if score @s ec.cf_mat_tier matches -1 run scoreboard players set @s ec.cf_mat_tier 24
execute if score @s ec.cf_mat_tier matches 24 run scoreboard players set @s ec.cf_art_cat 2
execute if score @s ec.cf_mat_tier matches 24 run scoreboard players set @s ec.cf_art_tier 5

execute if score @s ec.cf_mat_tier matches -1 store result score #cf_count ec.cf_temp run clear @s nether_star[custom_data~{forge_mat:"armor_t6"}] 0
execute if score #cf_count ec.cf_temp matches 3.. if score @s ec.cf_mat_tier matches -1 run scoreboard players set @s ec.cf_mat_tier 25
execute if score @s ec.cf_mat_tier matches 25 run scoreboard players set @s ec.cf_art_cat 2
execute if score @s ec.cf_mat_tier matches 25 run scoreboard players set @s ec.cf_art_tier 6

execute if score @s ec.cf_mat_tier matches -1 store result score #cf_count ec.cf_temp run clear @s echo_shard[custom_data~{forge_mat:"armor_t7"}] 0
execute if score #cf_count ec.cf_temp matches 3.. if score @s ec.cf_mat_tier matches -1 run scoreboard players set @s ec.cf_mat_tier 26
execute if score @s ec.cf_mat_tier matches 26 run scoreboard players set @s ec.cf_art_cat 2
execute if score @s ec.cf_mat_tier matches 26 run scoreboard players set @s ec.cf_art_tier 7

# === TOOL MATERIALS (mat_tier 30-36, art_cat=3) ===
execute if score @s ec.cf_mat_tier matches -1 store result score #cf_count ec.cf_temp run clear @s iron_nugget[custom_data~{forge_mat:"tool_t1"}] 0
execute if score #cf_count ec.cf_temp matches 3.. if score @s ec.cf_mat_tier matches -1 run scoreboard players set @s ec.cf_mat_tier 30
execute if score @s ec.cf_mat_tier matches 30 run scoreboard players set @s ec.cf_art_cat 3
execute if score @s ec.cf_mat_tier matches 30 run scoreboard players set @s ec.cf_art_tier 1

execute if score @s ec.cf_mat_tier matches -1 store result score #cf_count ec.cf_temp run clear @s iron_ingot[custom_data~{forge_mat:"tool_t2"}] 0
execute if score #cf_count ec.cf_temp matches 3.. if score @s ec.cf_mat_tier matches -1 run scoreboard players set @s ec.cf_mat_tier 31
execute if score @s ec.cf_mat_tier matches 31 run scoreboard players set @s ec.cf_art_cat 3
execute if score @s ec.cf_mat_tier matches 31 run scoreboard players set @s ec.cf_art_tier 2

execute if score @s ec.cf_mat_tier matches -1 store result score #cf_count ec.cf_temp run clear @s diamond[custom_data~{forge_mat:"tool_t3"}] 0
execute if score #cf_count ec.cf_temp matches 3.. if score @s ec.cf_mat_tier matches -1 run scoreboard players set @s ec.cf_mat_tier 32
execute if score @s ec.cf_mat_tier matches 32 run scoreboard players set @s ec.cf_art_cat 3
execute if score @s ec.cf_mat_tier matches 32 run scoreboard players set @s ec.cf_art_tier 3

execute if score @s ec.cf_mat_tier matches -1 store result score #cf_count ec.cf_temp run clear @s amethyst_shard[custom_data~{forge_mat:"tool_t4"}] 0
execute if score #cf_count ec.cf_temp matches 3.. if score @s ec.cf_mat_tier matches -1 run scoreboard players set @s ec.cf_mat_tier 33
execute if score @s ec.cf_mat_tier matches 33 run scoreboard players set @s ec.cf_art_cat 3
execute if score @s ec.cf_mat_tier matches 33 run scoreboard players set @s ec.cf_art_tier 4

execute if score @s ec.cf_mat_tier matches -1 store result score #cf_count ec.cf_temp run clear @s gold_ingot[custom_data~{forge_mat:"tool_t5"}] 0
execute if score #cf_count ec.cf_temp matches 3.. if score @s ec.cf_mat_tier matches -1 run scoreboard players set @s ec.cf_mat_tier 34
execute if score @s ec.cf_mat_tier matches 34 run scoreboard players set @s ec.cf_art_cat 3
execute if score @s ec.cf_mat_tier matches 34 run scoreboard players set @s ec.cf_art_tier 5

execute if score @s ec.cf_mat_tier matches -1 store result score #cf_count ec.cf_temp run clear @s nether_star[custom_data~{forge_mat:"tool_t6"}] 0
execute if score #cf_count ec.cf_temp matches 3.. if score @s ec.cf_mat_tier matches -1 run scoreboard players set @s ec.cf_mat_tier 35
execute if score @s ec.cf_mat_tier matches 35 run scoreboard players set @s ec.cf_art_cat 3
execute if score @s ec.cf_mat_tier matches 35 run scoreboard players set @s ec.cf_art_tier 6

execute if score @s ec.cf_mat_tier matches -1 store result score #cf_count ec.cf_temp run clear @s echo_shard[custom_data~{forge_mat:"tool_t7"}] 0
execute if score #cf_count ec.cf_temp matches 3.. if score @s ec.cf_mat_tier matches -1 run scoreboard players set @s ec.cf_mat_tier 36
execute if score @s ec.cf_mat_tier matches 36 run scoreboard players set @s ec.cf_art_cat 3
execute if score @s ec.cf_mat_tier matches 36 run scoreboard players set @s ec.cf_art_tier 7

# === ACCESSORY MATERIALS (mat_tier 40-46, art_cat=4) ===
execute if score @s ec.cf_mat_tier matches -1 store result score #cf_count ec.cf_temp run clear @s iron_nugget[custom_data~{forge_mat:"accessory_t1"}] 0
execute if score #cf_count ec.cf_temp matches 3.. if score @s ec.cf_mat_tier matches -1 run scoreboard players set @s ec.cf_mat_tier 40
execute if score @s ec.cf_mat_tier matches 40 run scoreboard players set @s ec.cf_art_cat 4
execute if score @s ec.cf_mat_tier matches 40 run scoreboard players set @s ec.cf_art_tier 1

execute if score @s ec.cf_mat_tier matches -1 store result score #cf_count ec.cf_temp run clear @s iron_ingot[custom_data~{forge_mat:"accessory_t2"}] 0
execute if score #cf_count ec.cf_temp matches 3.. if score @s ec.cf_mat_tier matches -1 run scoreboard players set @s ec.cf_mat_tier 41
execute if score @s ec.cf_mat_tier matches 41 run scoreboard players set @s ec.cf_art_cat 4
execute if score @s ec.cf_mat_tier matches 41 run scoreboard players set @s ec.cf_art_tier 2

execute if score @s ec.cf_mat_tier matches -1 store result score #cf_count ec.cf_temp run clear @s diamond[custom_data~{forge_mat:"accessory_t3"}] 0
execute if score #cf_count ec.cf_temp matches 3.. if score @s ec.cf_mat_tier matches -1 run scoreboard players set @s ec.cf_mat_tier 42
execute if score @s ec.cf_mat_tier matches 42 run scoreboard players set @s ec.cf_art_cat 4
execute if score @s ec.cf_mat_tier matches 42 run scoreboard players set @s ec.cf_art_tier 3

execute if score @s ec.cf_mat_tier matches -1 store result score #cf_count ec.cf_temp run clear @s amethyst_shard[custom_data~{forge_mat:"accessory_t4"}] 0
execute if score #cf_count ec.cf_temp matches 3.. if score @s ec.cf_mat_tier matches -1 run scoreboard players set @s ec.cf_mat_tier 43
execute if score @s ec.cf_mat_tier matches 43 run scoreboard players set @s ec.cf_art_cat 4
execute if score @s ec.cf_mat_tier matches 43 run scoreboard players set @s ec.cf_art_tier 4

execute if score @s ec.cf_mat_tier matches -1 store result score #cf_count ec.cf_temp run clear @s gold_ingot[custom_data~{forge_mat:"accessory_t5"}] 0
execute if score #cf_count ec.cf_temp matches 3.. if score @s ec.cf_mat_tier matches -1 run scoreboard players set @s ec.cf_mat_tier 44
execute if score @s ec.cf_mat_tier matches 44 run scoreboard players set @s ec.cf_art_cat 4
execute if score @s ec.cf_mat_tier matches 44 run scoreboard players set @s ec.cf_art_tier 5

execute if score @s ec.cf_mat_tier matches -1 store result score #cf_count ec.cf_temp run clear @s nether_star[custom_data~{forge_mat:"accessory_t6"}] 0
execute if score #cf_count ec.cf_temp matches 3.. if score @s ec.cf_mat_tier matches -1 run scoreboard players set @s ec.cf_mat_tier 45
execute if score @s ec.cf_mat_tier matches 45 run scoreboard players set @s ec.cf_art_cat 4
execute if score @s ec.cf_mat_tier matches 45 run scoreboard players set @s ec.cf_art_tier 6

execute if score @s ec.cf_mat_tier matches -1 store result score #cf_count ec.cf_temp run clear @s echo_shard[custom_data~{forge_mat:"accessory_t7"}] 0
execute if score #cf_count ec.cf_temp matches 3.. if score @s ec.cf_mat_tier matches -1 run scoreboard players set @s ec.cf_mat_tier 46
execute if score @s ec.cf_mat_tier matches 46 run scoreboard players set @s ec.cf_art_cat 4
execute if score @s ec.cf_mat_tier matches 46 run scoreboard players set @s ec.cf_art_tier 7

# No valid material found (or not enough — need 3)
data modify storage evercraft:notify stage.c set value [{text:"You need 3 of a forging material!",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute if score @s ec.cf_mat_tier matches -1 run return run function evercraft:util/notify/emit

# Remove exactly 3 of the matched material
# Standard materials
execute if score @s ec.cf_mat_tier matches 0 run clear @s iron_nugget[custom_data~{forge_mat:"scrap_metal"}] 3
execute if score @s ec.cf_mat_tier matches 1 run clear @s iron_ingot[custom_data~{forge_mat:"tempered_alloy"}] 3
execute if score @s ec.cf_mat_tier matches 2 run clear @s diamond[custom_data~{forge_mat:"starforged_ingot"}] 3
execute if score @s ec.cf_mat_tier matches 3 run clear @s amethyst_shard[custom_data~{forge_mat:"dreamwrought_bar"}] 3
execute if score @s ec.cf_mat_tier matches 4 run clear @s gold_ingot[custom_data~{forge_mat:"eternal_essence"}] 3
execute if score @s ec.cf_mat_tier matches 5 run clear @s nether_star[custom_data~{forge_mat:"soulbound_core"}] 3
execute if score @s ec.cf_mat_tier matches 6 run clear @s glowstone_dust[custom_data~{forge_mat:"geode_dust"}] 3
# Weapon materials
execute if score @s ec.cf_mat_tier matches 10 run clear @s iron_nugget[custom_data~{forge_mat:"weapon_t1"}] 3
execute if score @s ec.cf_mat_tier matches 11 run clear @s iron_ingot[custom_data~{forge_mat:"weapon_t2"}] 3
execute if score @s ec.cf_mat_tier matches 12 run clear @s diamond[custom_data~{forge_mat:"weapon_t3"}] 3
execute if score @s ec.cf_mat_tier matches 13 run clear @s amethyst_shard[custom_data~{forge_mat:"weapon_t4"}] 3
execute if score @s ec.cf_mat_tier matches 14 run clear @s gold_ingot[custom_data~{forge_mat:"weapon_t5"}] 3
execute if score @s ec.cf_mat_tier matches 15 run clear @s nether_star[custom_data~{forge_mat:"weapon_t6"}] 3
execute if score @s ec.cf_mat_tier matches 16 run clear @s echo_shard[custom_data~{forge_mat:"weapon_t7"}] 3
# Armor materials
execute if score @s ec.cf_mat_tier matches 20 run clear @s iron_nugget[custom_data~{forge_mat:"armor_t1"}] 3
execute if score @s ec.cf_mat_tier matches 21 run clear @s iron_ingot[custom_data~{forge_mat:"armor_t2"}] 3
execute if score @s ec.cf_mat_tier matches 22 run clear @s diamond[custom_data~{forge_mat:"armor_t3"}] 3
execute if score @s ec.cf_mat_tier matches 23 run clear @s amethyst_shard[custom_data~{forge_mat:"armor_t4"}] 3
execute if score @s ec.cf_mat_tier matches 24 run clear @s gold_ingot[custom_data~{forge_mat:"armor_t5"}] 3
execute if score @s ec.cf_mat_tier matches 25 run clear @s nether_star[custom_data~{forge_mat:"armor_t6"}] 3
execute if score @s ec.cf_mat_tier matches 26 run clear @s echo_shard[custom_data~{forge_mat:"armor_t7"}] 3
# Tool materials
execute if score @s ec.cf_mat_tier matches 30 run clear @s iron_nugget[custom_data~{forge_mat:"tool_t1"}] 3
execute if score @s ec.cf_mat_tier matches 31 run clear @s iron_ingot[custom_data~{forge_mat:"tool_t2"}] 3
execute if score @s ec.cf_mat_tier matches 32 run clear @s diamond[custom_data~{forge_mat:"tool_t3"}] 3
execute if score @s ec.cf_mat_tier matches 33 run clear @s amethyst_shard[custom_data~{forge_mat:"tool_t4"}] 3
execute if score @s ec.cf_mat_tier matches 34 run clear @s gold_ingot[custom_data~{forge_mat:"tool_t5"}] 3
execute if score @s ec.cf_mat_tier matches 35 run clear @s nether_star[custom_data~{forge_mat:"tool_t6"}] 3
execute if score @s ec.cf_mat_tier matches 36 run clear @s echo_shard[custom_data~{forge_mat:"tool_t7"}] 3
# Accessory materials
execute if score @s ec.cf_mat_tier matches 40 run clear @s iron_nugget[custom_data~{forge_mat:"accessory_t1"}] 3
execute if score @s ec.cf_mat_tier matches 41 run clear @s iron_ingot[custom_data~{forge_mat:"accessory_t2"}] 3
execute if score @s ec.cf_mat_tier matches 42 run clear @s diamond[custom_data~{forge_mat:"accessory_t3"}] 3
execute if score @s ec.cf_mat_tier matches 43 run clear @s amethyst_shard[custom_data~{forge_mat:"accessory_t4"}] 3
execute if score @s ec.cf_mat_tier matches 44 run clear @s gold_ingot[custom_data~{forge_mat:"accessory_t5"}] 3
execute if score @s ec.cf_mat_tier matches 45 run clear @s nether_star[custom_data~{forge_mat:"accessory_t6"}] 3
execute if score @s ec.cf_mat_tier matches 46 run clear @s echo_shard[custom_data~{forge_mat:"accessory_t7"}] 3

# Update display
# Standard materials
execute if score @s ec.cf_mat_tier matches 0 at @s run data modify entity @e[type=text_display,tag=CF.MatLine,distance=..7,limit=1] text set value [{text:"Material: ",color:"gray"},{text:"3x Scrap Metal",color:"white"}]
execute if score @s ec.cf_mat_tier matches 1 at @s run data modify entity @e[type=text_display,tag=CF.MatLine,distance=..7,limit=1] text set value [{text:"Material: ",color:"gray"},{text:"3x Tempered Alloy",color:"white"}]
execute if score @s ec.cf_mat_tier matches 2 at @s run data modify entity @e[type=text_display,tag=CF.MatLine,distance=..7,limit=1] text set value [{text:"Material: ",color:"gray"},{text:"3x Starforged Ingot",color:"blue"}]
execute if score @s ec.cf_mat_tier matches 3 at @s run data modify entity @e[type=text_display,tag=CF.MatLine,distance=..7,limit=1] text set value [{text:"Material: ",color:"gray"},{text:"3x Dreamwrought Bar",color:"dark_purple"}]
execute if score @s ec.cf_mat_tier matches 4 at @s run data modify entity @e[type=text_display,tag=CF.MatLine,distance=..7,limit=1] text set value [{text:"Material: ",color:"gray"},{text:"3x Eternal Essence",color:"gold"}]
execute if score @s ec.cf_mat_tier matches 5 at @s run data modify entity @e[type=text_display,tag=CF.MatLine,distance=..7,limit=1] text set value [{text:"Material: ",color:"gray"},{text:"3x Soulbound Core",color:"white",bold:true}]
execute if score @s ec.cf_mat_tier matches 6 at @s run data modify entity @e[type=text_display,tag=CF.MatLine,distance=..7,limit=1] text set value [{text:"Material: ",color:"gray"},{text:"3x Geode Dust",color:"#9FD8C8"}]
# Weapon materials
execute if score @s ec.cf_mat_tier matches 10 at @s run data modify entity @e[type=text_display,tag=CF.MatLine,distance=..7,limit=1] text set value [{text:"Material: ",color:"gray"},{text:"3x Warbrand Scrap",color:"dark_red"},{text:" [Weapon]",color:"#FF6666"}]
execute if score @s ec.cf_mat_tier matches 11 at @s run data modify entity @e[type=text_display,tag=CF.MatLine,distance=..7,limit=1] text set value [{text:"Material: ",color:"gray"},{text:"3x Embersteel Shard",color:"#FF8844"},{text:" [Weapon]",color:"#FF6666"}]
execute if score @s ec.cf_mat_tier matches 12 at @s run data modify entity @e[type=text_display,tag=CF.MatLine,distance=..7,limit=1] text set value [{text:"Material: ",color:"gray"},{text:"3x Stormforged Edge",color:"#44DDFF"},{text:" [Weapon]",color:"#FF6666"}]
execute if score @s ec.cf_mat_tier matches 13 at @s run data modify entity @e[type=text_display,tag=CF.MatLine,distance=..7,limit=1] text set value [{text:"Material: ",color:"gray"},{text:"3x Voidthorn Fragment",color:"dark_purple"},{text:" [Weapon]",color:"#FF6666"}]
execute if score @s ec.cf_mat_tier matches 14 at @s run data modify entity @e[type=text_display,tag=CF.MatLine,distance=..7,limit=1] text set value [{text:"Material: ",color:"gray"},{text:"3x Drakefang Alloy",color:"#FF6633"},{text:" [Weapon]",color:"#FF6666"}]
execute if score @s ec.cf_mat_tier matches 15 at @s run data modify entity @e[type=text_display,tag=CF.MatLine,distance=..7,limit=1] text set value [{text:"Material: ",color:"gray"},{text:"3x Celestial Blade Ore",color:"#99BBFF"},{text:" [Weapon]",color:"#FF6666"}]
execute if score @s ec.cf_mat_tier matches 16 at @s run data modify entity @e[type=text_display,tag=CF.MatLine,distance=..7,limit=1] text set value [{text:"Material: ",color:"gray"},{text:"3x Doomforge Core",color:"#FFD700",bold:true},{text:" [Weapon]",color:"#FF6666"}]
# Armor materials
execute if score @s ec.cf_mat_tier matches 20 at @s run data modify entity @e[type=text_display,tag=CF.MatLine,distance=..7,limit=1] text set value [{text:"Material: ",color:"gray"},{text:"3x Ironbark Plate",color:"#8B7355"},{text:" [Armor]",color:"#6699FF"}]
execute if score @s ec.cf_mat_tier matches 21 at @s run data modify entity @e[type=text_display,tag=CF.MatLine,distance=..7,limit=1] text set value [{text:"Material: ",color:"gray"},{text:"3x Frostweave Thread",color:"#AADDFF"},{text:" [Armor]",color:"#6699FF"}]
execute if score @s ec.cf_mat_tier matches 22 at @s run data modify entity @e[type=text_display,tag=CF.MatLine,distance=..7,limit=1] text set value [{text:"Material: ",color:"gray"},{text:"3x Stoneward Shell",color:"#77AA77"},{text:" [Armor]",color:"#6699FF"}]
execute if score @s ec.cf_mat_tier matches 23 at @s run data modify entity @e[type=text_display,tag=CF.MatLine,distance=..7,limit=1] text set value [{text:"Material: ",color:"gray"},{text:"3x Shadowmeld Fiber",color:"#444444"},{text:" [Armor]",color:"#6699FF"}]
execute if score @s ec.cf_mat_tier matches 24 at @s run data modify entity @e[type=text_display,tag=CF.MatLine,distance=..7,limit=1] text set value [{text:"Material: ",color:"gray"},{text:"3x Dragonscale Plate",color:"#227733"},{text:" [Armor]",color:"#6699FF"}]
execute if score @s ec.cf_mat_tier matches 25 at @s run data modify entity @e[type=text_display,tag=CF.MatLine,distance=..7,limit=1] text set value [{text:"Material: ",color:"gray"},{text:"3x Astralguard Lattice",color:"#DDDDFF"},{text:" [Armor]",color:"#6699FF"}]
execute if score @s ec.cf_mat_tier matches 26 at @s run data modify entity @e[type=text_display,tag=CF.MatLine,distance=..7,limit=1] text set value [{text:"Material: ",color:"gray"},{text:"3x Eternium Carapace",color:"#DD88FF",bold:true},{text:" [Armor]",color:"#6699FF"}]
# Tool materials
execute if score @s ec.cf_mat_tier matches 30 at @s run data modify entity @e[type=text_display,tag=CF.MatLine,distance=..7,limit=1] text set value [{text:"Material: ",color:"gray"},{text:"3x Copperstone Chunk",color:"#CC7744"},{text:" [Tool]",color:"#44BB44"}]
execute if score @s ec.cf_mat_tier matches 31 at @s run data modify entity @e[type=text_display,tag=CF.MatLine,distance=..7,limit=1] text set value [{text:"Material: ",color:"gray"},{text:"3x Heartwood Resin",color:"#44BB44"},{text:" [Tool]",color:"#44BB44"}]
execute if score @s ec.cf_mat_tier matches 32 at @s run data modify entity @e[type=text_display,tag=CF.MatLine,distance=..7,limit=1] text set value [{text:"Material: ",color:"gray"},{text:"3x Crystalvein Ore",color:"#CC88FF"},{text:" [Tool]",color:"#44BB44"}]
execute if score @s ec.cf_mat_tier matches 33 at @s run data modify entity @e[type=text_display,tag=CF.MatLine,distance=..7,limit=1] text set value [{text:"Material: ",color:"gray"},{text:"3x Leyline Conduit",color:"#88BBFF"},{text:" [Tool]",color:"#44BB44"}]
execute if score @s ec.cf_mat_tier matches 34 at @s run data modify entity @e[type=text_display,tag=CF.MatLine,distance=..7,limit=1] text set value [{text:"Material: ",color:"gray"},{text:"3x Worldroot Heartwood",color:"#664422"},{text:" [Tool]",color:"#44BB44"}]
execute if score @s ec.cf_mat_tier matches 35 at @s run data modify entity @e[type=text_display,tag=CF.MatLine,distance=..7,limit=1] text set value [{text:"Material: ",color:"gray"},{text:"3x Archon's Implement",color:"#FFDD88"},{text:" [Tool]",color:"#44BB44"}]
execute if score @s ec.cf_mat_tier matches 36 at @s run data modify entity @e[type=text_display,tag=CF.MatLine,distance=..7,limit=1] text set value [{text:"Material: ",color:"gray"},{text:"3x Genesis Catalyst",color:"#FF88AA",bold:true},{text:" [Tool]",color:"#44BB44"}]
# Accessory materials
execute if score @s ec.cf_mat_tier matches 40 at @s run data modify entity @e[type=text_display,tag=CF.MatLine,distance=..7,limit=1] text set value [{text:"Material: ",color:"gray"},{text:"3x Glimmer Dust",color:"#FFEE88"},{text:" [Accessory]",color:"#FFAA00"}]
execute if score @s ec.cf_mat_tier matches 41 at @s run data modify entity @e[type=text_display,tag=CF.MatLine,distance=..7,limit=1] text set value [{text:"Material: ",color:"gray"},{text:"3x Moonstone Sliver",color:"#AABBDD"},{text:" [Accessory]",color:"#FFAA00"}]
execute if score @s ec.cf_mat_tier matches 42 at @s run data modify entity @e[type=text_display,tag=CF.MatLine,distance=..7,limit=1] text set value [{text:"Material: ",color:"gray"},{text:"3x Dreamglass Shard",color:"#55BBAA"},{text:" [Accessory]",color:"#FFAA00"}]
execute if score @s ec.cf_mat_tier matches 43 at @s run data modify entity @e[type=text_display,tag=CF.MatLine,distance=..7,limit=1] text set value [{text:"Material: ",color:"gray"},{text:"3x Soulthread Strand",color:"#9966CC"},{text:" [Accessory]",color:"#FFAA00"}]
execute if score @s ec.cf_mat_tier matches 44 at @s run data modify entity @e[type=text_display,tag=CF.MatLine,distance=..7,limit=1] text set value [{text:"Material: ",color:"gray"},{text:"3x Starweave Filament",color:"#FFCC22"},{text:" [Accessory]",color:"#FFAA00"}]
execute if score @s ec.cf_mat_tier matches 45 at @s run data modify entity @e[type=text_display,tag=CF.MatLine,distance=..7,limit=1] text set value [{text:"Material: ",color:"gray"},{text:"3x Voidheart Gem",color:"#6622AA"},{text:" [Accessory]",color:"#FFAA00"}]
execute if score @s ec.cf_mat_tier matches 46 at @s run data modify entity @e[type=text_display,tag=CF.MatLine,distance=..7,limit=1] text set value [{text:"Material: ",color:"gray"},{text:"3x Eternity Spark",color:"#FFEEDD",bold:true},{text:" [Accessory]",color:"#FFAA00"}]

execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.item.pickup master @s ~ ~ ~ 0.5 1.2

# Deposited — mark pending so backing out before forging refunds it
scoreboard players set @s ec.cf_pending 1

# Try recipe match
function evercraft:craftforever/forging/recipes/match_recipe
