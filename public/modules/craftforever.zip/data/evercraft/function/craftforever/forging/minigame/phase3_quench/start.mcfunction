# Phase 3: QUENCH — Start
scoreboard players set @s ec.cf_quench 100
scoreboard players set @s ec.cf_timer 0

# Random lock zone position (35-70 range — aligned to visible green band, shipped Wiring Audit #3, 2026-05-29)
# Previous 25..75 range left a 31% misleading-visual band; 35..70 keeps lock_zone in the
# always-visibly-green segment of the bar render (tick:28-30 covers quench 31..75).
execute store result score @s ec.cf_lock_zone run random value 35..70

# Title
execute at @s run data modify entity @e[type=text_display,tag=CF.Title,distance=..7,limit=1] text set value [{text:"Phase 3: ",color:"gray"},{text:"QUENCH",color:"aqua",bold:true}]

# Info — show numeric target so visible-green vs lock_zone is unambiguous (Wiring Audit #3 fix)
# === 26.1 fix: {score} blank in text_display -> bake via storage macro (cat B) ===
scoreboard players add @s ec.cf_lock_zone 0
execute store result storage evercraft:scorebake bargs.v1 int 1 run scoreboard players get @s ec.cf_lock_zone
function evercraft:craftforever/forging/minigame/phase3_quench/start_dynb with storage evercraft:scorebake bargs

# Quench bar
execute rotated ~ 0 positioned ^ ^2.5 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["CF.MenuEl","CF.QuenchBar"],billboard:"center",text:{text:"\u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2588",color:"red"},background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.597f,0.597f,0.597f]}}

# Quench button
execute rotated ~ 0 positioned ^ ^1.75 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["CF.MenuEl","CF.QuenchText"],billboard:"center",text:{text:"[ QUENCH ]",color:"aqua",bold:true},background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.477f,0.477f,0.477f]}}
# [strip] CF.MenuEl: 0.5w split into 5 x 0.12 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute rotated ~ 0 positioned ^-0.19 ^1.68 ^1.8 run summon interaction ~ ~ ~ {Tags:["CF.MenuEl","CF.QuenchBtn"],width:0.12f,height:0.1f,response:1b}
execute rotated ~ 0 positioned ^-0.095 ^1.68 ^1.8 run summon interaction ~ ~ ~ {Tags:["CF.MenuEl","CF.QuenchBtn"],width:0.12f,height:0.1f,response:1b}
execute rotated ~ 0 positioned ^0 ^1.68 ^1.8 run summon interaction ~ ~ ~ {Tags:["CF.MenuEl","CF.QuenchBtn"],width:0.12f,height:0.1f,response:1b}
execute rotated ~ 0 positioned ^0.095 ^1.68 ^1.8 run summon interaction ~ ~ ~ {Tags:["CF.MenuEl","CF.QuenchBtn"],width:0.12f,height:0.1f,response:1b}
execute rotated ~ 0 positioned ^0.19 ^1.68 ^1.8 run summon interaction ~ ~ ~ {Tags:["CF.MenuEl","CF.QuenchBtn"],width:0.12f,height:0.1f,response:1b}

# Session stamp
scoreboard players operation #gui_stamp ec.temp = @s adv.gui_session
execute as @e[type=text_display,tag=CF.QuenchBar,distance=..8] unless score @s adv.gui_session matches 1.. run scoreboard players operation @s adv.gui_session = #gui_stamp ec.temp
execute as @e[type=text_display,tag=CF.QuenchText,distance=..8] unless score @s adv.gui_session matches 1.. run scoreboard players operation @s adv.gui_session = #gui_stamp ec.temp
execute as @e[type=interaction,tag=CF.QuenchBtn,distance=..8] unless score @s adv.gui_session matches 1.. run scoreboard players operation @s adv.gui_session = #gui_stamp ec.temp

execute if score @s ec.fx_snd matches 1.. run playsound minecraft:item.bucket.fill master @s ~ ~ ~ 0.8 0.8
