# Phase 1: HEAT — Evaluate heat position (runs as player)
# Sweet spot varies by tier: lower tiers = wider sweet spot

scoreboard players set #cf_heat_result ec.cf_temp 0

# Sweet spot zones (tier-scaled)
# Tier 0 (Scrap): 55-90 (wide)
# Tier 1 (Tempered): 60-88
# Tier 2 (Starforged): 65-85
# Tier 3 (Dreamwrought): 68-82
# Tier 4 (Eternal): 72-80
execute if score @s ec.cf_mat_tier matches 0 if score @s ec.cf_heat matches 55..90 run scoreboard players set #cf_heat_result ec.cf_temp 3
execute if score @s ec.cf_mat_tier matches 1 if score @s ec.cf_heat matches 60..88 run scoreboard players set #cf_heat_result ec.cf_temp 3
execute if score @s ec.cf_mat_tier matches 2 if score @s ec.cf_heat matches 65..85 run scoreboard players set #cf_heat_result ec.cf_temp 3
execute if score @s ec.cf_mat_tier matches 3 if score @s ec.cf_heat matches 68..82 run scoreboard players set #cf_heat_result ec.cf_temp 3
execute if score @s ec.cf_mat_tier matches 4 if score @s ec.cf_heat matches 72..80 run scoreboard players set #cf_heat_result ec.cf_temp 3

# Artifact-material sweet spots — tier-graduated curve (extension shipped Wiring Audit #3, 2026-05-29)
# Without these rows, mat_tier 10..46 (all artifact tiers) fall through and always get -1.
# Curve narrows as art_tier rises (matches the existing 0..4 ramp's narrowing pattern).
execute if score @s ec.cf_art_tier matches 1 if score @s ec.cf_mat_tier matches 10..46 if score @s ec.cf_heat matches 68..84 run scoreboard players set #cf_heat_result ec.cf_temp 3
execute if score @s ec.cf_art_tier matches 2 if score @s ec.cf_mat_tier matches 10..46 if score @s ec.cf_heat matches 70..82 run scoreboard players set #cf_heat_result ec.cf_temp 3
execute if score @s ec.cf_art_tier matches 3 if score @s ec.cf_mat_tier matches 10..46 if score @s ec.cf_heat matches 71..81 run scoreboard players set #cf_heat_result ec.cf_temp 3
execute if score @s ec.cf_art_tier matches 4 if score @s ec.cf_mat_tier matches 10..46 if score @s ec.cf_heat matches 72..80 run scoreboard players set #cf_heat_result ec.cf_temp 3
execute if score @s ec.cf_art_tier matches 5 if score @s ec.cf_mat_tier matches 10..46 if score @s ec.cf_heat matches 73..79 run scoreboard players set #cf_heat_result ec.cf_temp 3
execute if score @s ec.cf_art_tier matches 6 if score @s ec.cf_mat_tier matches 10..46 if score @s ec.cf_heat matches 74..78 run scoreboard players set #cf_heat_result ec.cf_temp 3
execute if score @s ec.cf_art_tier matches 7 if score @s ec.cf_mat_tier matches 10..46 if score @s ec.cf_heat matches 75..77 run scoreboard players set #cf_heat_result ec.cf_temp 3

# Not in sweet spot = miss
execute if score #cf_heat_result ec.cf_temp matches 0 run scoreboard players set #cf_heat_result ec.cf_temp -1

# Apply quality
scoreboard players operation @s ec.cf_quality += #cf_heat_result ec.cf_temp

# Clamp quality at 0 minimum
execute if score @s ec.cf_quality matches ..-1 run scoreboard players set @s ec.cf_quality 0

# Feedback
scoreboard players set #ndur ec.temp 45
execute if score #cf_heat_result ec.cf_temp matches 3 run data modify storage evercraft:notify stage.c set value [{text:"Perfect heat! ",color:"gold",bold:true},{text:"+3 quality",color:"yellow"}]
execute if score #cf_heat_result ec.cf_temp matches 3 run function evercraft:util/notify/emit
execute if score #cf_heat_result ec.cf_temp matches 3 if score @s ec.fx_snd matches 1.. run playsound minecraft:block.anvil.use master @s ~ ~ ~ 0.8 1.2

execute if score #cf_heat_result ec.cf_temp matches -1 run data modify storage evercraft:notify stage.c set value [{text:"Missed the sweet spot! ",color:"red"},{text:"-1 quality",color:"gray"}]
execute if score #cf_heat_result ec.cf_temp matches -1 run function evercraft:util/notify/emit
execute if score #cf_heat_result ec.cf_temp matches -1 if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 0.5 1.0

# Clean up phase 1 elements
execute at @s as @e[type=text_display,tag=CF.HeatBar,distance=..7] run kill @s
execute at @s as @e[type=text_display,tag=CF.HeatReadyText,distance=..7] run kill @s
execute at @s as @e[type=interaction,tag=CF.HeatReadyBtn,distance=..7] run kill @s

# Transition to Phase 2
scoreboard players set @s ec.cf_phase 2
scoreboard players set @s ec.cf_timer 0
function evercraft:craftforever/forging/minigame/phase2_hammer/start
