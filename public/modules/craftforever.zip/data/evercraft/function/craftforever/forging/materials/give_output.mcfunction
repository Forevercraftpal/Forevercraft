# Artisan Forge — Give Output Item based on recipe
# Recipe 1-5: Standard forge materials
# Recipe 100: Artifact material (next tier based on art_cat + art_tier)
# P1-1: every output is inv-full guarded via give_one (drops at feet if full).

# Compute inventory-full state once for all branches this tick.
execute store result score #inv_full ec.var run function evercraft:util/check_inv_full

# === STANDARD RECIPES ===
execute if score @s ec.cf_recipe matches 1 run function evercraft:craftforever/forging/materials/give_one {tbl:"tempered_alloy"}
execute if score @s ec.cf_recipe matches 2 run function evercraft:craftforever/forging/materials/give_one {tbl:"starforged_ingot"}
execute if score @s ec.cf_recipe matches 3 run function evercraft:craftforever/forging/materials/give_one {tbl:"dreamwrought_bar"}
execute if score @s ec.cf_recipe matches 4 run function evercraft:craftforever/forging/materials/give_one {tbl:"eternal_essence"}
execute if score @s ec.cf_recipe matches 5 run function evercraft:craftforever/forging/materials/give_one {tbl:"soulbound_core"}

# === ARTIFACT MATERIAL RECIPES (T1→T2, T2→T3, ..., T6→T7) ===
# T7 produces no material — handled separately in result_masterwork/result_good for artifact chance
execute unless score @s ec.cf_recipe matches 100 run return 0
execute if score @s ec.cf_art_tier matches 7 run return 0

# Weapon upgrades (T1→T2 through T6→T7)
execute if score @s ec.cf_art_cat matches 1 if score @s ec.cf_art_tier matches 1 run function evercraft:craftforever/forging/materials/give_one {tbl:"weapon_t2"}
execute if score @s ec.cf_art_cat matches 1 if score @s ec.cf_art_tier matches 2 run function evercraft:craftforever/forging/materials/give_one {tbl:"weapon_t3"}
execute if score @s ec.cf_art_cat matches 1 if score @s ec.cf_art_tier matches 3 run function evercraft:craftforever/forging/materials/give_one {tbl:"weapon_t4"}
execute if score @s ec.cf_art_cat matches 1 if score @s ec.cf_art_tier matches 4 run function evercraft:craftforever/forging/materials/give_one {tbl:"weapon_t5"}
execute if score @s ec.cf_art_cat matches 1 if score @s ec.cf_art_tier matches 5 run function evercraft:craftforever/forging/materials/give_one {tbl:"weapon_t6"}
execute if score @s ec.cf_art_cat matches 1 if score @s ec.cf_art_tier matches 6 run function evercraft:craftforever/forging/materials/give_one {tbl:"weapon_t7"}

# Armor upgrades
execute if score @s ec.cf_art_cat matches 2 if score @s ec.cf_art_tier matches 1 run function evercraft:craftforever/forging/materials/give_one {tbl:"armor_t2"}
execute if score @s ec.cf_art_cat matches 2 if score @s ec.cf_art_tier matches 2 run function evercraft:craftforever/forging/materials/give_one {tbl:"armor_t3"}
execute if score @s ec.cf_art_cat matches 2 if score @s ec.cf_art_tier matches 3 run function evercraft:craftforever/forging/materials/give_one {tbl:"armor_t4"}
execute if score @s ec.cf_art_cat matches 2 if score @s ec.cf_art_tier matches 4 run function evercraft:craftforever/forging/materials/give_one {tbl:"armor_t5"}
execute if score @s ec.cf_art_cat matches 2 if score @s ec.cf_art_tier matches 5 run function evercraft:craftforever/forging/materials/give_one {tbl:"armor_t6"}
execute if score @s ec.cf_art_cat matches 2 if score @s ec.cf_art_tier matches 6 run function evercraft:craftforever/forging/materials/give_one {tbl:"armor_t7"}

# Tool upgrades
execute if score @s ec.cf_art_cat matches 3 if score @s ec.cf_art_tier matches 1 run function evercraft:craftforever/forging/materials/give_one {tbl:"tool_t2"}
execute if score @s ec.cf_art_cat matches 3 if score @s ec.cf_art_tier matches 2 run function evercraft:craftforever/forging/materials/give_one {tbl:"tool_t3"}
execute if score @s ec.cf_art_cat matches 3 if score @s ec.cf_art_tier matches 3 run function evercraft:craftforever/forging/materials/give_one {tbl:"tool_t4"}
execute if score @s ec.cf_art_cat matches 3 if score @s ec.cf_art_tier matches 4 run function evercraft:craftforever/forging/materials/give_one {tbl:"tool_t5"}
execute if score @s ec.cf_art_cat matches 3 if score @s ec.cf_art_tier matches 5 run function evercraft:craftforever/forging/materials/give_one {tbl:"tool_t6"}
execute if score @s ec.cf_art_cat matches 3 if score @s ec.cf_art_tier matches 6 run function evercraft:craftforever/forging/materials/give_one {tbl:"tool_t7"}

# Accessory upgrades
execute if score @s ec.cf_art_cat matches 4 if score @s ec.cf_art_tier matches 1 run function evercraft:craftforever/forging/materials/give_one {tbl:"accessory_t2"}
execute if score @s ec.cf_art_cat matches 4 if score @s ec.cf_art_tier matches 2 run function evercraft:craftforever/forging/materials/give_one {tbl:"accessory_t3"}
execute if score @s ec.cf_art_cat matches 4 if score @s ec.cf_art_tier matches 3 run function evercraft:craftforever/forging/materials/give_one {tbl:"accessory_t4"}
execute if score @s ec.cf_art_cat matches 4 if score @s ec.cf_art_tier matches 4 run function evercraft:craftforever/forging/materials/give_one {tbl:"accessory_t5"}
execute if score @s ec.cf_art_cat matches 4 if score @s ec.cf_art_tier matches 5 run function evercraft:craftforever/forging/materials/give_one {tbl:"accessory_t6"}
execute if score @s ec.cf_art_cat matches 4 if score @s ec.cf_art_tier matches 6 run function evercraft:craftforever/forging/materials/give_one {tbl:"accessory_t7"}
