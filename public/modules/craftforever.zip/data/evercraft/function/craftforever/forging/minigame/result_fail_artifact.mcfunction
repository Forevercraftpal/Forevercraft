# Forging Result: FAIL on Artifact Material
# 7% chance for artifact, 93% chance for slag
# Specialized catalyst can boost artifact chance by +1-3%

# Base artifact chance: 7 in 100
scoreboard players set #art_thresh ec.cf_temp 7

# Specialized catalyst boost (cat_tier 10=+1%, 11=+2%, 12=+3%)
execute if score @s ec.cf_cat_tier matches 10 run scoreboard players add #art_thresh ec.cf_temp 1
execute if score @s ec.cf_cat_tier matches 11 run scoreboard players add #art_thresh ec.cf_temp 2
execute if score @s ec.cf_cat_tier matches 12 run scoreboard players add #art_thresh ec.cf_temp 3

# Roll for artifact
execute store result score #art_fail_roll ec.cf_temp run random value 1..100

# Check if we hit
execute if score #art_fail_roll ec.cf_temp <= #art_thresh ec.cf_temp run function evercraft:craftforever/forging/artifacts/roll_artifact
execute if score #art_fail_roll ec.cf_temp <= #art_thresh ec.cf_temp run return 0

# No artifact — give slag
data modify storage evercraft:notify stage.c set value [{text:"The material crumbled \u2014 Slag produced.",color:"red"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute at @s run function evercraft:fx/craft/forge_fail_artifact
# Inv-full guard: drop at the player's feet rather than void on a full inventory.
execute store result score #inv_full ec.var run function evercraft:util/check_inv_full
execute if score #inv_full ec.var matches 0 run loot give @s loot evercraft:craftforever/materials/slag
execute if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:craftforever/materials/slag
