# Forging Result: MASTERWORK — Exceptional quality!
data modify storage evercraft:notify stage.c set value [{text:"MASTERWORK! ",color:"gold",bold:true},{text:"A flawless creation.",color:"yellow"}]
scoreboard players set #ndur ec.temp 50
function evercraft:util/notify/emit
execute at @s run function evercraft:fx/craft/forge_masterwork

# Give output + bonus (extra material) — T7 handled by roll_t7_success in resolve.mcfunction
execute unless score @s ec.cf_art_tier matches 7 run function evercraft:craftforever/forging/materials/give_output
execute unless score @s ec.cf_art_tier matches 7 run function evercraft:craftforever/forging/materials/give_output
data modify storage evercraft:notify stage.c set value [{text:"Bonus: ",color:"gold"},{text:"Double output!",color:"yellow"}]
scoreboard players set #ndur ec.temp 40
execute unless score @s ec.cf_art_tier matches 7 run function evercraft:util/notify/emit

# Coin reward
function evercraft:coins/forge_masterwork
