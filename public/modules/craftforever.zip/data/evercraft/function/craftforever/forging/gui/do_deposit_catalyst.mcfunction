# Artisan Forge — Do Deposit Catalyst (runs as player)

# Already deposited?
data modify storage evercraft:notify stage.c set value [{text:"Catalyst already deposited!",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute if score @s ec.cf_cat_tier matches 0.. run return run function evercraft:util/notify/emit

scoreboard players set @s ec.cf_cat_tier -1

# Check for each catalyst type
# Node-tree Heartwood Kindling (premium charcoal catalyst, cat_tier 5) — checked BEFORE plain
# charcoal so the tree_fuel variant gets its own slot instead of being counted as raw charcoal.
execute store success score #cf_found ec.cf_temp run clear @s charcoal[custom_data~{tree_fuel:true}] 0
execute if score #cf_found ec.cf_temp matches 1 run scoreboard players set @s ec.cf_cat_tier 5

execute if score @s ec.cf_cat_tier matches -1 store success score #cf_found ec.cf_temp run clear @s charcoal 0
execute if score #cf_found ec.cf_temp matches 1 if score @s ec.cf_cat_tier matches -1 run scoreboard players set @s ec.cf_cat_tier 0

execute if score @s ec.cf_cat_tier matches -1 store success score #cf_found ec.cf_temp run clear @s blaze_powder 0
execute if score #cf_found ec.cf_temp matches 1 if score @s ec.cf_cat_tier matches -1 run scoreboard players set @s ec.cf_cat_tier 1

execute if score @s ec.cf_cat_tier matches -1 store success score #cf_found ec.cf_temp run clear @s heart_of_the_sea 0
execute if score #cf_found ec.cf_temp matches 1 if score @s ec.cf_cat_tier matches -1 run scoreboard players set @s ec.cf_cat_tier 2

# AU27-FOLLOWUP.3 (Joseph 2026-05-30): nether_star catalyst (highest tier slot) gated on the
# `forge_catalyst:true` discriminator. Vanilla wither-drop nether_stars no longer qualify;
# the "premium" nether_star comes from the grand_forge restore_catalyst flow
# (`evercraft:craftforever/forge_catalyst` loot, given via `evercraft:craftforever/grand_forge/restore_catalyst_one`).
# `blaze_powder` (T2) + `heart_of_the_sea` (T3) stay open per locked decision.
execute if score @s ec.cf_cat_tier matches -1 store success score #cf_found ec.cf_temp run clear @s nether_star[custom_data~{forge_catalyst:true}] 0
execute if score #cf_found ec.cf_temp matches 1 if score @s ec.cf_cat_tier matches -1 run scoreboard players set @s ec.cf_cat_tier 3

execute if score @s ec.cf_cat_tier matches -1 store success score #cf_found ec.cf_temp run clear @s wheat_seeds[custom_data~{spirit_treat:true}] 0
execute if score #cf_found ec.cf_temp matches 1 if score @s ec.cf_cat_tier matches -1 run scoreboard players set @s ec.cf_cat_tier 4

# === SPECIALIZED CATALYSTS (artifact chance boost) ===
# cat_tier 10=Resonance Dust (+1%), 11=Harmonic Essence (+2%), 12=Convergence Shard (+3%)
execute if score @s ec.cf_cat_tier matches -1 store success score #cf_found ec.cf_temp run clear @s glowstone_dust[custom_data~{forge_catalyst:"resonance_dust"}] 0
execute if score #cf_found ec.cf_temp matches 1 if score @s ec.cf_cat_tier matches -1 run scoreboard players set @s ec.cf_cat_tier 10

execute if score @s ec.cf_cat_tier matches -1 store success score #cf_found ec.cf_temp run clear @s amethyst_shard[custom_data~{forge_catalyst:"harmonic_essence"}] 0
execute if score #cf_found ec.cf_temp matches 1 if score @s ec.cf_cat_tier matches -1 run scoreboard players set @s ec.cf_cat_tier 11

execute if score @s ec.cf_cat_tier matches -1 store success score #cf_found ec.cf_temp run clear @s prismarine_shard[custom_data~{forge_catalyst:"convergence_shard"}] 0
execute if score #cf_found ec.cf_temp matches 1 if score @s ec.cf_cat_tier matches -1 run scoreboard players set @s ec.cf_cat_tier 12

# No valid catalyst found
data modify storage evercraft:notify stage.c set value [{text:"Hold a valid catalyst in your hand!",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute if score @s ec.cf_cat_tier matches -1 run return run function evercraft:util/notify/emit

# Remove 1 catalyst
execute if score @s ec.cf_cat_tier matches 5 run clear @s charcoal[custom_data~{tree_fuel:true}] 1
execute if score @s ec.cf_cat_tier matches 0 run clear @s charcoal 1
execute if score @s ec.cf_cat_tier matches 1 run clear @s blaze_powder 1
execute if score @s ec.cf_cat_tier matches 2 run clear @s heart_of_the_sea 1
execute if score @s ec.cf_cat_tier matches 3 run clear @s nether_star[custom_data~{forge_catalyst:true}] 1
execute if score @s ec.cf_cat_tier matches 4 run clear @s wheat_seeds[custom_data~{spirit_treat:true}] 1
execute if score @s ec.cf_cat_tier matches 10 run clear @s glowstone_dust[custom_data~{forge_catalyst:"resonance_dust"}] 1
execute if score @s ec.cf_cat_tier matches 11 run clear @s amethyst_shard[custom_data~{forge_catalyst:"harmonic_essence"}] 1
execute if score @s ec.cf_cat_tier matches 12 run clear @s prismarine_shard[custom_data~{forge_catalyst:"convergence_shard"}] 1

# Update display
execute if score @s ec.cf_cat_tier matches 5 at @s run data modify entity @e[type=text_display,tag=CF.CatLine,distance=..7,limit=1] text set value [{text:"Catalyst: ",color:"gray"},{text:"Heartwood Kindling",color:"#B5651D"},{text:" (potent charcoal)",color:"#8A6240"}]
execute if score @s ec.cf_cat_tier matches 0 at @s run data modify entity @e[type=text_display,tag=CF.CatLine,distance=..7,limit=1] text set value [{text:"Catalyst: ",color:"gray"},{text:"Charcoal",color:"yellow"}]
execute if score @s ec.cf_cat_tier matches 1 at @s run data modify entity @e[type=text_display,tag=CF.CatLine,distance=..7,limit=1] text set value [{text:"Catalyst: ",color:"gray"},{text:"Blaze Powder",color:"gold"}]
execute if score @s ec.cf_cat_tier matches 2 at @s run data modify entity @e[type=text_display,tag=CF.CatLine,distance=..7,limit=1] text set value [{text:"Catalyst: ",color:"gray"},{text:"Heart of the Sea",color:"aqua"}]
execute if score @s ec.cf_cat_tier matches 3 at @s run data modify entity @e[type=text_display,tag=CF.CatLine,distance=..7,limit=1] text set value [{text:"Catalyst: ",color:"gray"},{text:"Nether Star",color:"light_purple"}]
execute if score @s ec.cf_cat_tier matches 4 at @s run data modify entity @e[type=text_display,tag=CF.CatLine,distance=..7,limit=1] text set value [{text:"Catalyst: ",color:"gray"},{text:"Spirit Treat",color:"white",bold:true}]
execute if score @s ec.cf_cat_tier matches 10 at @s run data modify entity @e[type=text_display,tag=CF.CatLine,distance=..7,limit=1] text set value [{text:"Catalyst: ",color:"gray"},{text:"Resonance Dust",color:"#AADDFF"},{text:" (+1% artifact)",color:"#88BBDD"}]
execute if score @s ec.cf_cat_tier matches 11 at @s run data modify entity @e[type=text_display,tag=CF.CatLine,distance=..7,limit=1] text set value [{text:"Catalyst: ",color:"gray"},{text:"Harmonic Essence",color:"#CC88FF"},{text:" (+2% artifact)",color:"#AA66DD"}]
execute if score @s ec.cf_cat_tier matches 12 at @s run data modify entity @e[type=text_display,tag=CF.CatLine,distance=..7,limit=1] text set value [{text:"Catalyst: ",color:"gray"},{text:"Convergence Shard",color:"#FFD700"},{text:" (+3% artifact)",color:"#DDBB00"}]

execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.item.pickup master @s ~ ~ ~ 0.5 1.2

# Deposited — mark pending so backing out before forging refunds it
scoreboard players set @s ec.cf_pending 1

# Try recipe match
function evercraft:craftforever/forging/recipes/match_recipe
