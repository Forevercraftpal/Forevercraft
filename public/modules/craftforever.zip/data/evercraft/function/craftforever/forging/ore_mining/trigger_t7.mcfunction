# Ore Mining — Trigger T7 (ancient debris bonus — 0.3% chance)
scoreboard players set #ore_tier ec.cf_temp 7
function evercraft:craftforever/forging/ore_mining/check_drop
