# Artisan Forge GUI — Open
# Spawns floating display entities in front of the player

# Toggle — if already open, close instead
execute if entity @s[tag=CF.InMenu] run return run function evercraft:craftforever/forging/gui/close

# Menu Core: Y-displacement close anchor
# One-menu-at-a-time (2026-06-15): close any other open menu before this one claims
# ec.menu_active. Two overlapping menus share the @s adv.gui_session slot; the newer
# open orphans the older menu's session, so it can never consume its click -> stuck
# interaction NBT -> click-sound spam. force_close is idempotent (no-op when nothing open).
execute if entity @s[tag=ec.menu_active] run function evercraft:menu_core/force_close
tag @s add ec.menu_active
execute store result score @s ec.menu_open_y run data get entity @s Pos[1] 100

# Clean orphaned elements
kill @e[type=text_display,tag=CF.MenuEl,distance=..10]
kill @e[type=item_display,tag=CF.MenuEl,distance=..10]
kill @e[type=interaction,tag=CF.MenuEl,distance=..10]

# Tag player
tag @s add CF.InMenu
scoreboard players set @s ec.cf_menu_time 0
scoreboard players set @s ec.cf_state 1
scoreboard players set @s ec.cf_mat_tier -1
scoreboard players set @s ec.cf_cat_tier -1
scoreboard players set @s ec.cf_recipe 0
scoreboard players set @s ec.cf_pending 0

# Background panel
execute rotated ~ 0 positioned ^ ^2.15 ^1.8 run summon item_display ~ ~ ~ {Tags:["CF.MenuBG","CF.MenuEl"],billboard:"center",item:{id:"black_stained_glass_pane",count:1},item_display:"fixed",transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,-0.02f],scale:[2.8f,2.2f,0.01f]}}

# Title
# Ownership-header label (MP-P3.6): foreign viewers see whose menu this is
# 26.1: {selector:} renders blank in text_display — bake @s's name to a $(owner) literal.
function evercraft:util/gui/owner_name
execute rotated ~ 0 positioned ^ ^3.13 ^1.78 run function evercraft:craftforever/forging/gui/open_nm with storage evercraft:scorebake args
execute rotated ~ 0 positioned ^ ^2.95 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["CF.MenuEl","CF.Title"],billboard:"center",text:{text:"Artisan Forge",color:"light_purple",bold:true},background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.715f,0.715f,0.715f]}}

# Material line
execute rotated ~ 0 positioned ^ ^2.65 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["CF.MenuEl","CF.MatLine"],billboard:"center",text:{text:"Material: Empty",color:"gray"},background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.418f,0.418f,0.418f]}}

# Catalyst line
execute rotated ~ 0 positioned ^ ^2.45 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["CF.MenuEl","CF.CatLine"],billboard:"center",text:{text:"Catalyst: None (optional)",color:"dark_gray"},background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.418f,0.418f,0.418f]}}

# Recipe status
execute rotated ~ 0 positioned ^ ^2.25 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["CF.MenuEl","CF.RecipeStatus"],billboard:"center",text:{text:"Deposit a material to begin",color:"dark_gray"},background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.358f,0.358f,0.358f]}}

# Deposit Material button
execute rotated ~ 0 positioned ^0.65 ^2 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["CF.MenuEl","CF.DepMatText"],billboard:"center",text:{text:"[ Deposit Material ]",color:"aqua",bold:true},background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.358f,0.358f,0.358f]}}
# [strip] CF.MenuEl: 0.5w split into 5 x 0.12 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute rotated ~ 0 positioned ^0.46 ^1.93 ^1.8 run summon interaction ~ ~ ~ {Tags:["CF.MenuEl","CF.DepMatBtn"],width:0.12f,height:0.1f,response:1b}
execute rotated ~ 0 positioned ^0.555 ^1.93 ^1.8 run summon interaction ~ ~ ~ {Tags:["CF.MenuEl","CF.DepMatBtn"],width:0.12f,height:0.1f,response:1b}
execute rotated ~ 0 positioned ^0.65 ^1.93 ^1.8 run summon interaction ~ ~ ~ {Tags:["CF.MenuEl","CF.DepMatBtn"],width:0.12f,height:0.1f,response:1b}
execute rotated ~ 0 positioned ^0.745 ^1.93 ^1.8 run summon interaction ~ ~ ~ {Tags:["CF.MenuEl","CF.DepMatBtn"],width:0.12f,height:0.1f,response:1b}
execute rotated ~ 0 positioned ^0.84 ^1.93 ^1.8 run summon interaction ~ ~ ~ {Tags:["CF.MenuEl","CF.DepMatBtn"],width:0.12f,height:0.1f,response:1b}

# Deposit Catalyst button
execute rotated ~ 0 positioned ^-0.65 ^2 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["CF.MenuEl","CF.DepCatText"],billboard:"center",text:{text:"[ Deposit Catalyst ]",color:"yellow"},background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.358f,0.358f,0.358f]}}
# [strip] CF.MenuEl: 0.5w split into 5 x 0.12 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute rotated ~ 0 positioned ^-0.84 ^1.93 ^1.8 run summon interaction ~ ~ ~ {Tags:["CF.MenuEl","CF.DepCatBtn"],width:0.12f,height:0.1f,response:1b}
execute rotated ~ 0 positioned ^-0.745 ^1.93 ^1.8 run summon interaction ~ ~ ~ {Tags:["CF.MenuEl","CF.DepCatBtn"],width:0.12f,height:0.1f,response:1b}
execute rotated ~ 0 positioned ^-0.65 ^1.93 ^1.8 run summon interaction ~ ~ ~ {Tags:["CF.MenuEl","CF.DepCatBtn"],width:0.12f,height:0.1f,response:1b}
execute rotated ~ 0 positioned ^-0.555 ^1.93 ^1.8 run summon interaction ~ ~ ~ {Tags:["CF.MenuEl","CF.DepCatBtn"],width:0.12f,height:0.1f,response:1b}
execute rotated ~ 0 positioned ^-0.46 ^1.93 ^1.8 run summon interaction ~ ~ ~ {Tags:["CF.MenuEl","CF.DepCatBtn"],width:0.12f,height:0.1f,response:1b}

# Begin Forging button (initially gray — activates when recipe matches)
execute rotated ~ 0 positioned ^ ^1.75 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["CF.MenuEl","CF.ForgeText"],billboard:"center",text:{text:"[ Begin Forging ]",color:"gray",bold:true},background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.418f,0.418f,0.418f]}}
# [strip] CF.MenuEl: 0.5w split into 3 x 0.2 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute rotated ~ 0 positioned ^-0.15 ^1.65 ^1.8 run summon interaction ~ ~ ~ {Tags:["CF.MenuEl","CF.ForgeBtn"],width:0.2f,height:0.2f,response:1b}
execute rotated ~ 0 positioned ^0 ^1.65 ^1.8 run summon interaction ~ ~ ~ {Tags:["CF.MenuEl","CF.ForgeBtn"],width:0.2f,height:0.2f,response:1b}
execute rotated ~ 0 positioned ^0.15 ^1.65 ^1.8 run summon interaction ~ ~ ~ {Tags:["CF.MenuEl","CF.ForgeBtn"],width:0.2f,height:0.2f,response:1b}

# Close button
execute rotated ~ 0 positioned ^ ^1.5 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["CF.MenuEl","CF.CloseText"],billboard:"center",text:{text:"[ Close ]",color:"red"},background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.358f,0.358f,0.358f]}}
execute rotated ~ 0 positioned ^ ^1.43 ^1.8 run summon interaction ~ ~ ~ {Tags:["CF.MenuEl","CF.CloseBtn"],width:0.35f,height:0.08f,response:1b}

# Session isolation
scoreboard players add #gui_session ec.var 1
scoreboard players operation @s adv.gui_session = #gui_session ec.var
scoreboard players operation #gui_stamp ec.temp = @s adv.gui_session
execute as @e[type=text_display,tag=CF.MenuEl,distance=..5] unless score @s adv.gui_session matches 1.. run scoreboard players operation @s adv.gui_session = #gui_stamp ec.temp
execute as @e[type=item_display,tag=CF.MenuEl,distance=..5] unless score @s adv.gui_session matches 1.. run scoreboard players operation @s adv.gui_session = #gui_stamp ec.temp
execute as @e[type=interaction,tag=CF.MenuEl,distance=..5] unless score @s adv.gui_session matches 1.. run scoreboard players operation @s adv.gui_session = #gui_stamp ec.temp

execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.anvil.use master @s ~ ~ ~ 0.3 1.5
