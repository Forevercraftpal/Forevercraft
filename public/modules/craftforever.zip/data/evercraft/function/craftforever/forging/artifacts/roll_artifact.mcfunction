# Artisan Forge — Roll Artifact on Failed Forge
# Uses ec.cf_art_tier (1-7) to determine rarity weights
# Uses ec.cf_art_cat (1-4) to determine category
# Called when fail roll hits the 7% artifact chance

# Determine rarity based on tier
# T1-T2: 80 common, 15 uncommon, 5 rare (total 100)
# T3: 50 common, 30 uncommon, 15 rare, 5 exquisite (total 100)
# T4: 30 common, 30 uncommon, 25 rare, 10 exquisite, 5 ornate (total 100)
# T5: 15 common, 25 uncommon, 25 rare, 20 exquisite, 10 ornate, 5 mythical (total 100)
# T6: 5 common, 15 uncommon, 25 rare, 25 exquisite, 20 ornate, 10 mythical (total 100)
# T7: 10 uncommon, 25 rare, 35 exquisite, 30 ornate — NO mythical (total 100)

execute store result score #art_roll ec.cf_temp run random value 1..100

# Default rarity score: 0=common, 1=uncommon, 2=rare, 3=exquisite, 4=ornate, 5=mythical
scoreboard players set #art_rarity ec.cf_temp 0

# === T1-T2 RARITY ===
# 1-80 common, 81-95 uncommon, 96-100 rare
execute if score @s ec.cf_art_tier matches 1..2 if score #art_roll ec.cf_temp matches 81..95 run scoreboard players set #art_rarity ec.cf_temp 1
execute if score @s ec.cf_art_tier matches 1..2 if score #art_roll ec.cf_temp matches 96..100 run scoreboard players set #art_rarity ec.cf_temp 2

# === T3 RARITY ===
# 1-50 common, 51-80 uncommon, 81-95 rare, 96-100 exquisite
execute if score @s ec.cf_art_tier matches 3 if score #art_roll ec.cf_temp matches 51..80 run scoreboard players set #art_rarity ec.cf_temp 1
execute if score @s ec.cf_art_tier matches 3 if score #art_roll ec.cf_temp matches 81..95 run scoreboard players set #art_rarity ec.cf_temp 2
execute if score @s ec.cf_art_tier matches 3 if score #art_roll ec.cf_temp matches 96..100 run scoreboard players set #art_rarity ec.cf_temp 3

# === T4 RARITY ===
# 1-30 common, 31-60 uncommon, 61-85 rare, 86-95 exquisite, 96-100 ornate
execute if score @s ec.cf_art_tier matches 4 if score #art_roll ec.cf_temp matches 31..60 run scoreboard players set #art_rarity ec.cf_temp 1
execute if score @s ec.cf_art_tier matches 4 if score #art_roll ec.cf_temp matches 61..85 run scoreboard players set #art_rarity ec.cf_temp 2
execute if score @s ec.cf_art_tier matches 4 if score #art_roll ec.cf_temp matches 86..95 run scoreboard players set #art_rarity ec.cf_temp 3
execute if score @s ec.cf_art_tier matches 4 if score #art_roll ec.cf_temp matches 96..100 run scoreboard players set #art_rarity ec.cf_temp 4

# === T5 RARITY ===
# 1-15 common, 16-40 uncommon, 41-65 rare, 66-85 exquisite, 86-95 ornate, 96-100 mythical
execute if score @s ec.cf_art_tier matches 5 if score #art_roll ec.cf_temp matches 16..40 run scoreboard players set #art_rarity ec.cf_temp 1
execute if score @s ec.cf_art_tier matches 5 if score #art_roll ec.cf_temp matches 41..65 run scoreboard players set #art_rarity ec.cf_temp 2
execute if score @s ec.cf_art_tier matches 5 if score #art_roll ec.cf_temp matches 66..85 run scoreboard players set #art_rarity ec.cf_temp 3
execute if score @s ec.cf_art_tier matches 5 if score #art_roll ec.cf_temp matches 86..95 run scoreboard players set #art_rarity ec.cf_temp 4
execute if score @s ec.cf_art_tier matches 5 if score #art_roll ec.cf_temp matches 96..100 run scoreboard players set #art_rarity ec.cf_temp 5

# === T6 RARITY ===
# 1-5 common, 6-20 uncommon, 21-45 rare, 46-70 exquisite, 71-90 ornate, 91-100 mythical
execute if score @s ec.cf_art_tier matches 6 if score #art_roll ec.cf_temp matches 6..20 run scoreboard players set #art_rarity ec.cf_temp 1
execute if score @s ec.cf_art_tier matches 6 if score #art_roll ec.cf_temp matches 21..45 run scoreboard players set #art_rarity ec.cf_temp 2
execute if score @s ec.cf_art_tier matches 6 if score #art_roll ec.cf_temp matches 46..70 run scoreboard players set #art_rarity ec.cf_temp 3
execute if score @s ec.cf_art_tier matches 6 if score #art_roll ec.cf_temp matches 71..90 run scoreboard players set #art_rarity ec.cf_temp 4
execute if score @s ec.cf_art_tier matches 6 if score #art_roll ec.cf_temp matches 91..100 run scoreboard players set #art_rarity ec.cf_temp 5

# === T7 RARITY (NO MYTHICAL) ===
# 1-10 uncommon, 11-35 rare, 36-70 exquisite, 71-100 ornate
execute if score @s ec.cf_art_tier matches 7 run scoreboard players set #art_rarity ec.cf_temp 1
execute if score @s ec.cf_art_tier matches 7 if score #art_roll ec.cf_temp matches 11..35 run scoreboard players set #art_rarity ec.cf_temp 2
execute if score @s ec.cf_art_tier matches 7 if score #art_roll ec.cf_temp matches 36..70 run scoreboard players set #art_rarity ec.cf_temp 3
execute if score @s ec.cf_art_tier matches 7 if score #art_roll ec.cf_temp matches 71..100 run scoreboard players set #art_rarity ec.cf_temp 4

# === GIVE ARTIFACT BY CATEGORY + RARITY === (inv-full guarded — Wiring Audit #3 S1.3, 2026-05-29)
# Rare 7%-on-fail + T7-mythical rolls were previously voided on full inventory; now drop at feet.
execute store result score #inv_full ec.var run function evercraft:util/check_inv_full

# Weapon artifacts
execute if score @s ec.cf_art_cat matches 1 if score #art_rarity ec.cf_temp matches 0 run function evercraft:craftforever/forging/artifacts/give_one {tbl:"common_weapon"}
execute if score @s ec.cf_art_cat matches 1 if score #art_rarity ec.cf_temp matches 1 run function evercraft:craftforever/forging/artifacts/give_one {tbl:"uncommon_weapon"}
execute if score @s ec.cf_art_cat matches 1 if score #art_rarity ec.cf_temp matches 2 run function evercraft:craftforever/forging/artifacts/give_one {tbl:"rare_weapon"}
execute if score @s ec.cf_art_cat matches 1 if score #art_rarity ec.cf_temp matches 3 run function evercraft:craftforever/forging/artifacts/give_one {tbl:"exquisite_weapon"}
execute if score @s ec.cf_art_cat matches 1 if score #art_rarity ec.cf_temp matches 4 run function evercraft:craftforever/forging/artifacts/give_one {tbl:"ornate_weapon"}
execute if score @s ec.cf_art_cat matches 1 if score #art_rarity ec.cf_temp matches 5 run function evercraft:craftforever/forging/artifacts/give_one {tbl:"mythical_weapon"}

# Armor artifacts
execute if score @s ec.cf_art_cat matches 2 if score #art_rarity ec.cf_temp matches 0 run function evercraft:craftforever/forging/artifacts/give_one {tbl:"common_armor"}
execute if score @s ec.cf_art_cat matches 2 if score #art_rarity ec.cf_temp matches 1 run function evercraft:craftforever/forging/artifacts/give_one {tbl:"uncommon_armor"}
execute if score @s ec.cf_art_cat matches 2 if score #art_rarity ec.cf_temp matches 2 run function evercraft:craftforever/forging/artifacts/give_one {tbl:"rare_armor"}
execute if score @s ec.cf_art_cat matches 2 if score #art_rarity ec.cf_temp matches 3 run function evercraft:craftforever/forging/artifacts/give_one {tbl:"exquisite_armor"}
execute if score @s ec.cf_art_cat matches 2 if score #art_rarity ec.cf_temp matches 4 run function evercraft:craftforever/forging/artifacts/give_one {tbl:"ornate_armor"}
execute if score @s ec.cf_art_cat matches 2 if score #art_rarity ec.cf_temp matches 5 run function evercraft:craftforever/forging/artifacts/give_one {tbl:"mythical_armor"}

# Tool artifacts
execute if score @s ec.cf_art_cat matches 3 if score #art_rarity ec.cf_temp matches 0 run function evercraft:craftforever/forging/artifacts/give_one {tbl:"common_tool"}
execute if score @s ec.cf_art_cat matches 3 if score #art_rarity ec.cf_temp matches 1 run function evercraft:craftforever/forging/artifacts/give_one {tbl:"uncommon_tool"}
execute if score @s ec.cf_art_cat matches 3 if score #art_rarity ec.cf_temp matches 2 run function evercraft:craftforever/forging/artifacts/give_one {tbl:"rare_tool"}
execute if score @s ec.cf_art_cat matches 3 if score #art_rarity ec.cf_temp matches 3 run function evercraft:craftforever/forging/artifacts/give_one {tbl:"exquisite_tool"}
execute if score @s ec.cf_art_cat matches 3 if score #art_rarity ec.cf_temp matches 4 run function evercraft:craftforever/forging/artifacts/give_one {tbl:"ornate_tool"}
execute if score @s ec.cf_art_cat matches 3 if score #art_rarity ec.cf_temp matches 5 run function evercraft:craftforever/forging/artifacts/give_one {tbl:"mythical_tool"}

# Accessory artifacts
execute if score @s ec.cf_art_cat matches 4 if score #art_rarity ec.cf_temp matches 0 run function evercraft:craftforever/forging/artifacts/give_one {tbl:"common_accessory"}
execute if score @s ec.cf_art_cat matches 4 if score #art_rarity ec.cf_temp matches 1 run function evercraft:craftforever/forging/artifacts/give_one {tbl:"uncommon_accessory"}
execute if score @s ec.cf_art_cat matches 4 if score #art_rarity ec.cf_temp matches 2 run function evercraft:craftforever/forging/artifacts/give_one {tbl:"rare_accessory"}
execute if score @s ec.cf_art_cat matches 4 if score #art_rarity ec.cf_temp matches 3 run function evercraft:craftforever/forging/artifacts/give_one {tbl:"exquisite_accessory"}
execute if score @s ec.cf_art_cat matches 4 if score #art_rarity ec.cf_temp matches 4 run function evercraft:craftforever/forging/artifacts/give_one {tbl:"ornate_accessory"}
execute if score @s ec.cf_art_cat matches 4 if score #art_rarity ec.cf_temp matches 5 run function evercraft:craftforever/forging/artifacts/give_one {tbl:"mythical_accessory"}

# Rarity name for feedback
scoreboard players set #ndur ec.temp 45
execute if score #art_rarity ec.cf_temp matches 0 run data modify storage evercraft:notify stage.c set value [{text:"An artifact emerges from the flames! ",color:"gold"},{text:"Common",color:"white"}]
execute if score #art_rarity ec.cf_temp matches 1 run data modify storage evercraft:notify stage.c set value [{text:"An artifact emerges from the flames! ",color:"gold"},{text:"Uncommon",color:"blue"}]
execute if score #art_rarity ec.cf_temp matches 2 run data modify storage evercraft:notify stage.c set value [{text:"An artifact emerges from the flames! ",color:"gold"},{text:"Rare",color:"aqua"}]
execute if score #art_rarity ec.cf_temp matches 3 run data modify storage evercraft:notify stage.c set value [{text:"An artifact emerges from the flames! ",color:"gold"},{text:"Exquisite",color:"light_purple"}]
execute if score #art_rarity ec.cf_temp matches 4 run data modify storage evercraft:notify stage.c set value [{text:"An artifact emerges from the flames! ",color:"gold"},{text:"Ornate",color:"dark_purple"}]
execute if score #art_rarity ec.cf_temp matches 5 run data modify storage evercraft:notify stage.c set value [{text:"An artifact emerges from the flames! ",color:"gold"},{text:"Mythical",color:"gold",bold:true}]
function evercraft:util/notify/emit

# Effects — the gated "an artifact takes shape" reveal (channel-gated preset, fires ON TOP of the
# station's own result cue). Replaces the old ungated anvil.use + levelup + totem + ui.toast reveal
# (which double-fired alongside the station cue and broke the palette/ceiling).
execute at @s run function evercraft:fx/craft/artifact_forged

# Wiring Audit #14 C19: count forge-rolled artifacts (surfaced in the Forge Artifacts codex panel).
scoreboard players add @s ach.artifacts_forged 1
