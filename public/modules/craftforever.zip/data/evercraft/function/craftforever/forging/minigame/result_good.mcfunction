# Forging Result: GOOD — Solid work
data modify storage evercraft:notify stage.c set value [{text:"Well forged! A fine creation.",color:"yellow"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute at @s run function evercraft:fx/craft/forge_good

# Give output (T7 handled by roll_t7_success in resolve.mcfunction)
execute unless score @s ec.cf_art_tier matches 7 run function evercraft:craftforever/forging/materials/give_output
