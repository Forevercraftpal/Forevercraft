# AUTO (start.mcfunction): data-modify text_display rows with {score} baked as macro args (26.1 fix, cat B).
# Invoked `with storage evercraft:scorebake bargs` from the parent.
$execute at @s run data modify entity @e[type=text_display,tag=CF.RecipeStatus,distance=..7,limit=1] text set value [{text:"Click QUENCH when bar hits ",color:"yellow"},{text:"$(v1)",color:"green",bold:true},{text:" (green band)",color:"yellow"}]
