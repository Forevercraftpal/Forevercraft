# Forging Minigame — Mark a standard recipe as discovered (Wiring Audit #14 C4)
# Run as player. Expects #cf_recbit ec.cf_temp = 2^(recipe-1) for the matched recipe.
# Ding-once OR-pattern: only sets the Recipe Book bit + announces if not already found.

scoreboard players operation #cf_reccheck ec.cf_temp = @s ec.cf_recipes_found
scoreboard players operation #cf_reccheck ec.cf_temp /= #cf_recbit ec.cf_temp
scoreboard players operation #cf_reccheck ec.cf_temp %= #2 ec.const

execute if score #cf_reccheck ec.cf_temp matches 0 run scoreboard players operation @s ec.cf_recipes_found += #cf_recbit ec.cf_temp
# Wave J AU14-X4 (2026-05-31): forge-standard-family writer for cross-family recipes-learned aggregate.
execute if score #cf_reccheck ec.cf_temp matches 0 run scoreboard players add @s ec.recipes_learned_total 1
data modify storage evercraft:notify stage.c set value [{text:"New forge recipe discovered!",color:"yellow"}]
scoreboard players set #ndur ec.temp 45
execute if score #cf_reccheck ec.cf_temp matches 0 run function evercraft:util/notify/emit
execute if score #cf_reccheck ec.cf_temp matches 0 if score @s ec.fx_snd matches 1.. run playsound minecraft:item.book.page_turn master @s ~ ~ ~ 0.8 1.0
execute if score #cf_reccheck ec.cf_temp matches 0 if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.experience_orb.pickup master @s ~ ~ ~ 0.5 1.2
