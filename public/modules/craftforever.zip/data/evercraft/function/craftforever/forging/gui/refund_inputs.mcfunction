# === ARTISAN FORGE — REFUND PENDING DEPOSITS (run as @s player) ===
# Returns the deposited material (3x) + catalyst (1x) when a player backs out BEFORE forging.
# Gated by ec.cf_pending (set on deposit, cleared at forge-start) so a committed/finished forge
# never refunds. Reuses give_one's loot tables so the FULL named material item is returned.
scoreboard players set #cf_refunded ec.cf_temp 0

# Inventory-full guard shared with give_one (drops at feet if full).
execute store result score #inv_full ec.var run function evercraft:util/check_inv_full

# --- Material refund (3x of the matched material) ---
execute if score @s ec.cf_mat_tier matches 0 run function evercraft:craftforever/forging/gui/refund_mat {tbl:"scrap_metal"}
execute if score @s ec.cf_mat_tier matches 1 run function evercraft:craftforever/forging/gui/refund_mat {tbl:"tempered_alloy"}
execute if score @s ec.cf_mat_tier matches 2 run function evercraft:craftforever/forging/gui/refund_mat {tbl:"starforged_ingot"}
execute if score @s ec.cf_mat_tier matches 3 run function evercraft:craftforever/forging/gui/refund_mat {tbl:"dreamwrought_bar"}
execute if score @s ec.cf_mat_tier matches 4 run function evercraft:craftforever/forging/gui/refund_mat {tbl:"eternal_essence"}
execute if score @s ec.cf_mat_tier matches 6 run function evercraft:craftforever/forging/gui/refund_mat {tbl:"geode_dust"}
execute if score @s ec.cf_mat_tier matches 10 run function evercraft:craftforever/forging/gui/refund_mat {tbl:"weapon_t1"}
execute if score @s ec.cf_mat_tier matches 11 run function evercraft:craftforever/forging/gui/refund_mat {tbl:"weapon_t2"}
execute if score @s ec.cf_mat_tier matches 12 run function evercraft:craftforever/forging/gui/refund_mat {tbl:"weapon_t3"}
execute if score @s ec.cf_mat_tier matches 13 run function evercraft:craftforever/forging/gui/refund_mat {tbl:"weapon_t4"}
execute if score @s ec.cf_mat_tier matches 14 run function evercraft:craftforever/forging/gui/refund_mat {tbl:"weapon_t5"}
execute if score @s ec.cf_mat_tier matches 15 run function evercraft:craftforever/forging/gui/refund_mat {tbl:"weapon_t6"}
execute if score @s ec.cf_mat_tier matches 16 run function evercraft:craftforever/forging/gui/refund_mat {tbl:"weapon_t7"}
execute if score @s ec.cf_mat_tier matches 20 run function evercraft:craftforever/forging/gui/refund_mat {tbl:"armor_t1"}
execute if score @s ec.cf_mat_tier matches 21 run function evercraft:craftforever/forging/gui/refund_mat {tbl:"armor_t2"}
execute if score @s ec.cf_mat_tier matches 22 run function evercraft:craftforever/forging/gui/refund_mat {tbl:"armor_t3"}
execute if score @s ec.cf_mat_tier matches 23 run function evercraft:craftforever/forging/gui/refund_mat {tbl:"armor_t4"}
execute if score @s ec.cf_mat_tier matches 24 run function evercraft:craftforever/forging/gui/refund_mat {tbl:"armor_t5"}
execute if score @s ec.cf_mat_tier matches 25 run function evercraft:craftforever/forging/gui/refund_mat {tbl:"armor_t6"}
execute if score @s ec.cf_mat_tier matches 26 run function evercraft:craftforever/forging/gui/refund_mat {tbl:"armor_t7"}
execute if score @s ec.cf_mat_tier matches 30 run function evercraft:craftforever/forging/gui/refund_mat {tbl:"tool_t1"}
execute if score @s ec.cf_mat_tier matches 31 run function evercraft:craftforever/forging/gui/refund_mat {tbl:"tool_t2"}
execute if score @s ec.cf_mat_tier matches 32 run function evercraft:craftforever/forging/gui/refund_mat {tbl:"tool_t3"}
execute if score @s ec.cf_mat_tier matches 33 run function evercraft:craftforever/forging/gui/refund_mat {tbl:"tool_t4"}
execute if score @s ec.cf_mat_tier matches 34 run function evercraft:craftforever/forging/gui/refund_mat {tbl:"tool_t5"}
execute if score @s ec.cf_mat_tier matches 35 run function evercraft:craftforever/forging/gui/refund_mat {tbl:"tool_t6"}
execute if score @s ec.cf_mat_tier matches 36 run function evercraft:craftforever/forging/gui/refund_mat {tbl:"tool_t7"}
execute if score @s ec.cf_mat_tier matches 40 run function evercraft:craftforever/forging/gui/refund_mat {tbl:"accessory_t1"}
execute if score @s ec.cf_mat_tier matches 41 run function evercraft:craftforever/forging/gui/refund_mat {tbl:"accessory_t2"}
execute if score @s ec.cf_mat_tier matches 42 run function evercraft:craftforever/forging/gui/refund_mat {tbl:"accessory_t3"}
execute if score @s ec.cf_mat_tier matches 43 run function evercraft:craftforever/forging/gui/refund_mat {tbl:"accessory_t4"}
execute if score @s ec.cf_mat_tier matches 44 run function evercraft:craftforever/forging/gui/refund_mat {tbl:"accessory_t5"}
execute if score @s ec.cf_mat_tier matches 45 run function evercraft:craftforever/forging/gui/refund_mat {tbl:"accessory_t6"}
execute if score @s ec.cf_mat_tier matches 46 run function evercraft:craftforever/forging/gui/refund_mat {tbl:"accessory_t7"}
execute if score @s ec.cf_mat_tier matches 0.. run scoreboard players set #cf_refunded ec.cf_temp 1

# --- Catalyst refund (1x) ---
execute if score @s ec.cf_cat_tier matches 0 run give @s charcoal 1
execute if score @s ec.cf_cat_tier matches 1 run give @s blaze_powder 1
execute if score @s ec.cf_cat_tier matches 2 run give @s heart_of_the_sea 1
execute if score @s ec.cf_cat_tier matches 3 run give @s nether_star 1
execute if score @s ec.cf_cat_tier matches 4 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:cooking/treats/spirit_treat
execute if score @s ec.cf_cat_tier matches 4 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:cooking/treats/spirit_treat
execute if score @s ec.cf_cat_tier matches 5 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:timberfall/items/heartwood_kindling
execute if score @s ec.cf_cat_tier matches 5 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:timberfall/items/heartwood_kindling
execute if score @s ec.cf_cat_tier matches 10 run function evercraft:craftforever/forging/materials/give_one {tbl:"resonance_dust"}
execute if score @s ec.cf_cat_tier matches 11 run function evercraft:craftforever/forging/materials/give_one {tbl:"harmonic_essence"}
execute if score @s ec.cf_cat_tier matches 12 run function evercraft:craftforever/forging/materials/give_one {tbl:"convergence_shard"}
execute if score @s ec.cf_cat_tier matches 0.. run scoreboard players set #cf_refunded ec.cf_temp 1

# Clear the pending flag + feedback
scoreboard players set @s ec.cf_pending 0
data modify storage evercraft:notify stage.c set value [{text:"Returned your deposited materials.",color:"green"}]
scoreboard players set #ndur ec.temp 45
execute if score #cf_refunded ec.cf_temp matches 1 run function evercraft:util/notify/emit
execute if score #cf_refunded ec.cf_temp matches 1 if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.item.pickup master @s ~ ~ ~ 0.6 1.0
