# Phase 2: HAMMER — Time's up!
data modify storage evercraft:notify stage.c set value [{text:"Time's up! ",color:"red"},{text:"Moving to quench phase.",color:"gray"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit

# Clean up and advance
function evercraft:craftforever/forging/minigame/phase2_hammer/cleanup
scoreboard players set @s ec.cf_phase 3
scoreboard players set @s ec.cf_timer 0
function evercraft:craftforever/forging/minigame/phase3_quench/start
