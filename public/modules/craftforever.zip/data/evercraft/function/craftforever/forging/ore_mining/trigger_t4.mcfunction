# Ore Mining — Trigger T4 (diamond ore)
scoreboard players set #ore_tier ec.cf_temp 4
function evercraft:craftforever/forging/ore_mining/check_drop
