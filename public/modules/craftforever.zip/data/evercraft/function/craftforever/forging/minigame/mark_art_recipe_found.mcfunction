# Forging Minigame — Mark an artifact-tier recipe discovered (Wiring Audit #14 C16)
# Run as player on a successful artifact forge (recipe 100).
# Bit index = (art_cat-1)*7 + (art_tier-1), 0..27 → 28 distinct (cat × tier) cells.
# Switch-table for 2^index (keep INLINE — global ec.cf_temp scratch, serial @s).

# index = (art_cat-1)*7 + (art_tier-1)
scoreboard players operation #cf_ar_idx ec.cf_temp = @s ec.cf_art_cat
scoreboard players remove #cf_ar_idx ec.cf_temp 1
scoreboard players operation #cf_ar_idx ec.cf_temp *= #7 ec.const
scoreboard players operation #cf_ar_t ec.cf_temp = @s ec.cf_art_tier
scoreboard players remove #cf_ar_t ec.cf_temp 1
scoreboard players operation #cf_ar_idx ec.cf_temp += #cf_ar_t ec.cf_temp

# bitmask = 2^index (index 0..27 fits a signed 32-bit int; bit 27 = 134217728)
scoreboard players set #cf_ar_mask ec.cf_temp 1
execute if score #cf_ar_idx ec.cf_temp matches 1 run scoreboard players set #cf_ar_mask ec.cf_temp 2
execute if score #cf_ar_idx ec.cf_temp matches 2 run scoreboard players set #cf_ar_mask ec.cf_temp 4
execute if score #cf_ar_idx ec.cf_temp matches 3 run scoreboard players set #cf_ar_mask ec.cf_temp 8
execute if score #cf_ar_idx ec.cf_temp matches 4 run scoreboard players set #cf_ar_mask ec.cf_temp 16
execute if score #cf_ar_idx ec.cf_temp matches 5 run scoreboard players set #cf_ar_mask ec.cf_temp 32
execute if score #cf_ar_idx ec.cf_temp matches 6 run scoreboard players set #cf_ar_mask ec.cf_temp 64
execute if score #cf_ar_idx ec.cf_temp matches 7 run scoreboard players set #cf_ar_mask ec.cf_temp 128
execute if score #cf_ar_idx ec.cf_temp matches 8 run scoreboard players set #cf_ar_mask ec.cf_temp 256
execute if score #cf_ar_idx ec.cf_temp matches 9 run scoreboard players set #cf_ar_mask ec.cf_temp 512
execute if score #cf_ar_idx ec.cf_temp matches 10 run scoreboard players set #cf_ar_mask ec.cf_temp 1024
execute if score #cf_ar_idx ec.cf_temp matches 11 run scoreboard players set #cf_ar_mask ec.cf_temp 2048
execute if score #cf_ar_idx ec.cf_temp matches 12 run scoreboard players set #cf_ar_mask ec.cf_temp 4096
execute if score #cf_ar_idx ec.cf_temp matches 13 run scoreboard players set #cf_ar_mask ec.cf_temp 8192
execute if score #cf_ar_idx ec.cf_temp matches 14 run scoreboard players set #cf_ar_mask ec.cf_temp 16384
execute if score #cf_ar_idx ec.cf_temp matches 15 run scoreboard players set #cf_ar_mask ec.cf_temp 32768
execute if score #cf_ar_idx ec.cf_temp matches 16 run scoreboard players set #cf_ar_mask ec.cf_temp 65536
execute if score #cf_ar_idx ec.cf_temp matches 17 run scoreboard players set #cf_ar_mask ec.cf_temp 131072
execute if score #cf_ar_idx ec.cf_temp matches 18 run scoreboard players set #cf_ar_mask ec.cf_temp 262144
execute if score #cf_ar_idx ec.cf_temp matches 19 run scoreboard players set #cf_ar_mask ec.cf_temp 524288
execute if score #cf_ar_idx ec.cf_temp matches 20 run scoreboard players set #cf_ar_mask ec.cf_temp 1048576
execute if score #cf_ar_idx ec.cf_temp matches 21 run scoreboard players set #cf_ar_mask ec.cf_temp 2097152
execute if score #cf_ar_idx ec.cf_temp matches 22 run scoreboard players set #cf_ar_mask ec.cf_temp 4194304
execute if score #cf_ar_idx ec.cf_temp matches 23 run scoreboard players set #cf_ar_mask ec.cf_temp 8388608
execute if score #cf_ar_idx ec.cf_temp matches 24 run scoreboard players set #cf_ar_mask ec.cf_temp 16777216
execute if score #cf_ar_idx ec.cf_temp matches 25 run scoreboard players set #cf_ar_mask ec.cf_temp 33554432
execute if score #cf_ar_idx ec.cf_temp matches 26 run scoreboard players set #cf_ar_mask ec.cf_temp 67108864
execute if score #cf_ar_idx ec.cf_temp matches 27 run scoreboard players set #cf_ar_mask ec.cf_temp 134217728

# ding-once OR
scoreboard players operation #cf_ar_check ec.cf_temp = @s ec.cf_art_recipes_found
scoreboard players operation #cf_ar_check ec.cf_temp /= #cf_ar_mask ec.cf_temp
scoreboard players operation #cf_ar_check ec.cf_temp %= #2 ec.const
execute if score #cf_ar_check ec.cf_temp matches 0 run scoreboard players operation @s ec.cf_art_recipes_found += #cf_ar_mask ec.cf_temp
# Wave J AU14-X4 (2026-05-31): forge-artifact-family writer for cross-family recipes-learned aggregate.
execute if score #cf_ar_check ec.cf_temp matches 0 run scoreboard players add @s ec.recipes_learned_total 1
data modify storage evercraft:notify stage.c set value [{text:"New artifact recipe discovered!",color:"#FFAA00"}]
scoreboard players set #ndur ec.temp 45
execute if score #cf_ar_check ec.cf_temp matches 0 run function evercraft:util/notify/emit
execute if score #cf_ar_check ec.cf_temp matches 0 if score @s ec.fx_snd matches 1.. run playsound minecraft:item.book.page_turn master @s ~ ~ ~ 0.8 1.0
