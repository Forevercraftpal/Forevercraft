# Artisan Forge — On Break (lodestone removed)
# Runs as the marker entity at the forge position

# Close any player's open menu nearby
execute as @a[tag=CF.InMenu,distance=..8] run function evercraft:craftforever/forging/gui/close

# Kill all forge entities (interaction + armor_stand w/ item_display passenger)
execute as @e[type=interaction,tag=CF.Interact,distance=..2] run kill @s
execute as @e[type=armor_stand,tag=CF.Visual,distance=..2] run kill @s
execute as @e[type=item_display,tag=CF.Visual,distance=..2] run kill @s

# ═══ COLOR-AWARE LOOT DROP ═══
# Kill vanilla lodestone drop
kill @e[type=item,nbt={Item:{id:"minecraft:lodestone"}},distance=..2]

# Drop correct color variant
execute if data entity @s {data:{color:"artisan_forge_azure"}} run loot spawn ~ ~0.5 ~ loot evercraft:craftforever/artisan_forge_drop_azure
execute if data entity @s {data:{color:"artisan_forge_crimson"}} run loot spawn ~ ~0.5 ~ loot evercraft:craftforever/artisan_forge_drop_crimson
execute if data entity @s {data:{color:"artisan_forge_solar"}} run loot spawn ~ ~0.5 ~ loot evercraft:craftforever/artisan_forge_drop_solar
execute if data entity @s {data:{color:"artisan_forge_verdant"}} run loot spawn ~ ~0.5 ~ loot evercraft:craftforever/artisan_forge_drop_verdant
execute if data entity @s {data:{color:"artisan_forge_ivory"}} run loot spawn ~ ~0.5 ~ loot evercraft:craftforever/artisan_forge_drop_ivory
execute if data entity @s {data:{color:"artisan_forge_obsidian"}} run loot spawn ~ ~0.5 ~ loot evercraft:craftforever/artisan_forge_drop_obsidian
execute if data entity @s {data:{color:"artisan_forge_rose"}} run loot spawn ~ ~0.5 ~ loot evercraft:craftforever/artisan_forge_drop_rose
execute if data entity @s {data:{color:"artisan_forge_noir"}} run loot spawn ~ ~0.5 ~ loot evercraft:craftforever/artisan_forge_drop_noir
execute unless data entity @s {data:{color:"artisan_forge_azure"}} unless data entity @s {data:{color:"artisan_forge_crimson"}} unless data entity @s {data:{color:"artisan_forge_solar"}} unless data entity @s {data:{color:"artisan_forge_verdant"}} unless data entity @s {data:{color:"artisan_forge_ivory"}} unless data entity @s {data:{color:"artisan_forge_obsidian"}} unless data entity @s {data:{color:"artisan_forge_rose"}} unless data entity @s {data:{color:"artisan_forge_noir"}} run loot spawn ~ ~0.5 ~ loot evercraft:craftforever/artisan_forge_drop

# Kill self (marker)
kill @s
