# Artisan Forge GUI — Close

# Kill all session-matched GUI entities
# Menu Core: Y-displacement close anchor
tag @s remove ec.menu_active
scoreboard players reset @s ec.menu_open_y

scoreboard players operation #gui_check ec.temp = @s adv.gui_session
execute as @e[type=text_display,tag=CF.MenuEl,distance=..7] if score @s adv.gui_session = #gui_check ec.temp run kill @s
execute as @e[type=item_display,tag=CF.MenuEl,distance=..7] if score @s adv.gui_session = #gui_check ec.temp run kill @s
execute as @e[type=interaction,tag=CF.MenuEl,distance=..7] if score @s adv.gui_session = #gui_check ec.temp run kill @s

# Remove player tags
tag @s remove CF.InMenu
tag @s remove CF.Forging

# Refund any material/catalyst the player deposited but never forged (data-loss fix).
# Gated by ec.cf_pending; runs BEFORE the tier reset below so it knows what to return.
execute if score @s ec.cf_pending matches 1 run function evercraft:craftforever/forging/gui/refund_inputs

# Reset state
scoreboard players set @s ec.cf_state 0
scoreboard players set @s ec.cf_phase 0
scoreboard players set @s ec.cf_mat_tier -1
scoreboard players set @s ec.cf_cat_tier -1
scoreboard players set @s ec.cf_recipe 0

execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.anvil.land master @s ~ ~ ~ 0.2 1.8
