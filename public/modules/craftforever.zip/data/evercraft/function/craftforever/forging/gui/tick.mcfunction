# Artisan Forge GUI — Per-tick
# Called from main tick for CF.InMenu players

# Auto-close if player moved too far from forge
execute unless entity @e[type=marker,tag=CF.Marker,distance=..6] run function evercraft:craftforever/forging/gui/close
execute unless entity @s[tag=CF.InMenu] run return 0

# Auto-close after 20 seconds of inactivity (400 ticks)
scoreboard players add @s ec.cf_menu_time 1
execute if score @s ec.cf_menu_time matches 400.. run return run function evercraft:craftforever/forging/gui/close
execute unless entity @s[tag=CF.InMenu] run return 0

# Reset inactivity timer on any click
scoreboard players operation #gui_check ec.temp = @s adv.gui_session
execute as @e[type=interaction,tag=CF.MenuEl,distance=..7] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction run scoreboard players set @a[predicate=evercraft:craftforever/forging/check_menu_session,limit=1] ec.cf_menu_time 0

# Unified UI-click FX (Joseph 2026-06-05): play the gated cue ONCE on a CF.MenuEl click in the menu states
# (1..2). During the minigame (state 3) only the Close button stays live, so blip just for that one.
execute if score @s ec.cf_state matches 1..2 if entity @e[type=interaction,tag=CF.MenuEl,distance=..7,nbt={interaction:{}},limit=1] run function evercraft:fx/ui/click
execute if score @s ec.cf_state matches 3 if entity @e[type=interaction,tag=CF.CloseBtn,distance=..5,nbt={interaction:{}},limit=1] run function evercraft:fx/ui/click

# Route based on state
execute if score @s ec.cf_state matches 1..2 run function evercraft:craftforever/forging/gui/check_clicks
# Close button must remain live during minigame state=3 (Wiring Audit #3 fix, 2026-05-29)
# Without this route, CloseBtn entity is visible+clickable during Phase 1/2/3 but never queried.
execute if score @s ec.cf_state matches 3 as @e[type=interaction,tag=CF.CloseBtn,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction on target run function evercraft:craftforever/forging/gui/click_close
execute if score @s ec.cf_state matches 3 as @e[type=interaction,tag=CF.CloseBtn,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction run data remove entity @s interaction
execute if score @s ec.cf_state matches 3 run function evercraft:craftforever/forging/minigame/tick
