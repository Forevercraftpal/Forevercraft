# Ore Mining — Trigger T1 (stone-tier ores: coal, copper)
scoreboard players set #ore_tier ec.cf_temp 1
function evercraft:craftforever/forging/ore_mining/check_drop
