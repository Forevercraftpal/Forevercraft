# Phase 2: HAMMER — Pattern complete!
data modify storage evercraft:notify stage.c set value [{text:"Pattern complete! ",color:"green",bold:true}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.anvil.use master @s ~ ~ ~ 1.0 0.8

# Clean up phase 2 elements
function evercraft:craftforever/forging/minigame/phase2_hammer/cleanup

# Advance to Phase 3
scoreboard players set @s ec.cf_phase 3
scoreboard players set @s ec.cf_timer 0
function evercraft:craftforever/forging/minigame/phase3_quench/start
