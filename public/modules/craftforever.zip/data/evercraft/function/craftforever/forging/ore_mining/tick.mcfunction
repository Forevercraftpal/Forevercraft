# Ore Mining — Per-player tick (detect vanilla ore breaks, roll for artifact material drops)
# Uses ec.tt_s_* scoreboards (auto-tracking minecraft.mined stats)
# Compares current value to ec.om_prev_* snapshot to detect new mines
# Tier mapping: coal/copper=T1, iron/gold=T2, lapis/redstone=T3,
#   diamond=T4, emerald=T5, ancient debris=T6+T7
#
# Perf P1-5 (minimum-viable gate): you can only mine ore with a pickaxe in hand,
# so bail before the 28 stat-compares unless the player is holding a pickaxe. This
# drops AFK / non-mining ranked players to ~1 selector/tick. The snapshots stay in
# sync because a player without a pickaxe cannot increment any ore-mine stat. The
# fuller composite-stat-trigger refactor (perf F3) is queued in 10-pending.
# NOTE: snapshots are NOT touched on the early-exit, so no mined-ore event is lost.
execute unless items entity @s weapon.mainhand #minecraft:pickaxes run return 0

# ═══ T1: Coal ore ═══
execute if score @s ec.tt_s_coal > @s ec.om_prev_coal run function evercraft:craftforever/forging/ore_mining/trigger_t1
scoreboard players operation @s ec.om_prev_coal = @s ec.tt_s_coal

execute if score @s ec.tt_s_dcoal > @s ec.om_prev_dcoal run function evercraft:craftforever/forging/ore_mining/trigger_t1
scoreboard players operation @s ec.om_prev_dcoal = @s ec.tt_s_dcoal

# ═══ T1: Copper ore ═══
execute if score @s ec.tt_s_cop > @s ec.om_prev_cop run function evercraft:craftforever/forging/ore_mining/trigger_t1
scoreboard players operation @s ec.om_prev_cop = @s ec.tt_s_cop

execute if score @s ec.tt_s_dcop > @s ec.om_prev_dcop run function evercraft:craftforever/forging/ore_mining/trigger_t1
scoreboard players operation @s ec.om_prev_dcop = @s ec.tt_s_dcop

# ═══ T2: Iron ore ═══
execute if score @s ec.tt_s_iron > @s ec.om_prev_iron run function evercraft:craftforever/forging/ore_mining/trigger_t2
scoreboard players operation @s ec.om_prev_iron = @s ec.tt_s_iron

execute if score @s ec.tt_s_diron > @s ec.om_prev_diron run function evercraft:craftforever/forging/ore_mining/trigger_t2
scoreboard players operation @s ec.om_prev_diron = @s ec.tt_s_diron

# ═══ T2: Gold ore ═══
execute if score @s ec.tt_s_gold > @s ec.om_prev_gold run function evercraft:craftforever/forging/ore_mining/trigger_t2
scoreboard players operation @s ec.om_prev_gold = @s ec.tt_s_gold

execute if score @s ec.tt_s_dgold > @s ec.om_prev_dgold run function evercraft:craftforever/forging/ore_mining/trigger_t2
scoreboard players operation @s ec.om_prev_dgold = @s ec.tt_s_dgold

# ═══ T3: Lapis ore ═══
execute if score @s ec.tt_s_lapis > @s ec.om_prev_lapis run function evercraft:craftforever/forging/ore_mining/trigger_t3
scoreboard players operation @s ec.om_prev_lapis = @s ec.tt_s_lapis

execute if score @s ec.tt_s_dlapis > @s ec.om_prev_dlapis run function evercraft:craftforever/forging/ore_mining/trigger_t3
scoreboard players operation @s ec.om_prev_dlapis = @s ec.tt_s_dlapis

# ═══ T3: Redstone ore ═══
execute if score @s ec.tt_s_red > @s ec.om_prev_red run function evercraft:craftforever/forging/ore_mining/trigger_t3
scoreboard players operation @s ec.om_prev_red = @s ec.tt_s_red

execute if score @s ec.tt_s_dred > @s ec.om_prev_dred run function evercraft:craftforever/forging/ore_mining/trigger_t3
scoreboard players operation @s ec.om_prev_dred = @s ec.tt_s_dred

# ═══ T4: Diamond ore ═══
execute if score @s ec.tt_s_dia > @s ec.om_prev_dia run function evercraft:craftforever/forging/ore_mining/trigger_t4
scoreboard players operation @s ec.om_prev_dia = @s ec.tt_s_dia

execute if score @s ec.tt_s_ddia > @s ec.om_prev_ddia run function evercraft:craftforever/forging/ore_mining/trigger_t4
scoreboard players operation @s ec.om_prev_ddia = @s ec.tt_s_ddia

# ═══ T5: Emerald ore ═══
execute if score @s ec.tt_s_emer > @s ec.om_prev_emer run function evercraft:craftforever/forging/ore_mining/trigger_t5
scoreboard players operation @s ec.om_prev_emer = @s ec.tt_s_emer

execute if score @s ec.tt_s_demer > @s ec.om_prev_demer run function evercraft:craftforever/forging/ore_mining/trigger_t5
scoreboard players operation @s ec.om_prev_demer = @s ec.tt_s_demer

# ═══ T6 + T7: Ancient Debris ═══
execute if score @s ec.om_debris > @s ec.om_prev_debris run function evercraft:craftforever/forging/ore_mining/trigger_t6
execute if score @s ec.om_debris > @s ec.om_prev_debris run function evercraft:craftforever/forging/ore_mining/trigger_t7
scoreboard players operation @s ec.om_prev_debris = @s ec.om_debris
