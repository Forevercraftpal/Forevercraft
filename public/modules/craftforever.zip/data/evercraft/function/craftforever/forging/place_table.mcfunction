# Artisan Forge — Setup placed block
# Spawns marker at block center, interaction entity on top, and display overlay

tag @s remove ec.searching

# Spawn marker at block center with forge state data
summon marker ~0.5 ~ ~0.5 {Tags:["CF.Marker","ec.lodestone_registered"],data:{}}

# Store color on marker
data modify entity @e[type=marker,tag=CF.Marker,distance=..5,limit=1,sort=nearest] data.color set from storage evercraft:craftforever temp_color

# Spawn interaction entity on top of block for right-click detection
summon interaction ~0.5 ~1.0 ~0.5 {Tags:["CF.Interact"],width:0.9f,height:0.5f,response:1b}

# Spawn custom head display — use color skin if variant, else default forge_skin from load.mcfunction
execute if data storage evercraft:craftforever {temp_color:"artisan_forge"} run function evercraft:craftforever/forging/spawn_display with storage evercraft:craftforever
execute unless data storage evercraft:craftforever {temp_color:"artisan_forge"} run data modify storage evercraft:craftforever forge_skin set from storage evercraft:craftforever temp_skin
execute unless data storage evercraft:craftforever {temp_color:"artisan_forge"} run function evercraft:craftforever/forging/spawn_display with storage evercraft:craftforever

# Feedback
data modify storage evercraft:notify stage.c set value [{text:"Artisan Forge placed! ",color:"light_purple"},{text:"Right-click to open.",color:"gray"}]
scoreboard players set #ndur ec.temp 45
execute as @p[distance=..8] run function evercraft:util/notify/emit
playsound minecraft:block.anvil.place master @a[distance=..16,scores={ec.fx_snd=1..}] ~ ~ ~ 0.8 0.8
particle minecraft:flame ~0.5 ~1.2 ~0.5 0.3 0.2 0.3 0.02 8

# Clear temp color/skin storage so leftovers don't bleed into the next placement (Wiring Audit #27 AU27-FOLLOWUP.5)
data remove storage evercraft:craftforever temp_color
data remove storage evercraft:craftforever temp_skin
