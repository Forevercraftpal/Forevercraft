# T7 Success — Guaranteed artifact from matching category
# 7% chance it's Mythical, otherwise roll from T7 rarity table (no mythical)
# Called from resolve.mcfunction after a successful T7 forge

execute store result score #t7_roll ec.cf_temp run random value 1..100

# 7% chance for Mythical (inv-full guarded — Wiring Audit #3 S1.3, 2026-05-29)
execute if score #t7_roll ec.cf_temp matches 1..7 store result score #inv_full ec.var run function evercraft:util/check_inv_full
execute if score #t7_roll ec.cf_temp matches 1..7 if score @s ec.cf_art_cat matches 1 run function evercraft:craftforever/forging/artifacts/give_one {tbl:"mythical_weapon"}
execute if score #t7_roll ec.cf_temp matches 1..7 if score @s ec.cf_art_cat matches 2 run function evercraft:craftforever/forging/artifacts/give_one {tbl:"mythical_armor"}
execute if score #t7_roll ec.cf_temp matches 1..7 if score @s ec.cf_art_cat matches 3 run function evercraft:craftforever/forging/artifacts/give_one {tbl:"mythical_tool"}
execute if score #t7_roll ec.cf_temp matches 1..7 if score @s ec.cf_art_cat matches 4 run function evercraft:craftforever/forging/artifacts/give_one {tbl:"mythical_accessory"}

data modify storage evercraft:notify stage.c set value [{text:"★ MYTHICAL ARTIFACT FORGED! ★",color:"gold",bold:true}]
scoreboard players set #ndur ec.temp 50
execute if score #t7_roll ec.cf_temp matches 1..7 run function evercraft:util/notify/emit
execute if score #t7_roll ec.cf_temp matches 1..7 if score @s ec.fx_snd matches 1.. run playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 1.0 1.0
execute if score #t7_roll ec.cf_temp matches 1..7 if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.ender_dragon.growl master @s ~ ~ ~ 0.3 1.5
execute if score #t7_roll ec.cf_temp matches 1..7 at @s run particle minecraft:totem_of_undying ~ ~1.5 ~ 0.5 0.5 0.5 0.5 80
execute if score #t7_roll ec.cf_temp matches 1..7 at @s run particle minecraft:end_rod ~ ~2 ~ 0.3 0.3 0.3 0.05 30
execute if score #t7_roll ec.cf_temp matches 1..7 run return 0

# 93% — Non-mythical artifact (T7 fail rarity table: 10% uncommon, 25% rare, 35% exquisite, 30% ornate)
# Reuse the roll_artifact function but force art_tier=7 (which excludes mythical)
function evercraft:craftforever/forging/artifacts/roll_artifact
