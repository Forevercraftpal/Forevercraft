# Ore Mining — Check for artifact material drop
# Receives #ore_tier ec.cf_temp (1-7) set by caller
# Rolls 1..200 (0.5%) for T1-T6, 1..333 (0.3%) for T7

# Roll chance based on tier
execute if score #ore_tier ec.cf_temp matches 1..6 store result score #ore_roll ec.cf_temp run random value 1..200
execute if score #ore_tier ec.cf_temp matches 7 store result score #ore_roll ec.cf_temp run random value 1..333

# Prospector's Loupe (C14, Family G accessory — art-G): an item-gated EXTRA +1% artifact-material
# roll, ADDITIVE on top of the base per-tile 0.5%/0.3% roll above (NOT an edit to the base odds).
# One independent 1..100 roll; on a 1 (1%) force a hit by setting #ore_roll to 1 so the base
# early-exit below passes. set-not-add idiom (one `if items` test -> two copies still roll once =
# m4 multi-copy-safe). Only a Loupe holder pays the extra roll; non-holders early-exit unchanged.
execute if items entity @s container.* *[custom_data~{artifact:"prospectors_loupe"}] store result score #loupe_roll ec.cf_temp run random value 1..100
execute unless items entity @s container.* *[custom_data~{artifact:"prospectors_loupe"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"prospectors_loupe"}] if entity @s[tag=ec.sat_prospectors_loupe] store result score #loupe_roll ec.cf_temp run random value 1..100
execute if items entity @s container.* *[custom_data~{artifact:"prospectors_loupe"}] if score #loupe_roll ec.cf_temp matches 1 run scoreboard players set #ore_roll ec.cf_temp 1
execute unless items entity @s container.* *[custom_data~{artifact:"prospectors_loupe"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"prospectors_loupe"}] if entity @s[tag=ec.sat_prospectors_loupe] if score #loupe_roll ec.cf_temp matches 1 run scoreboard players set #ore_roll ec.cf_temp 1
execute unless items entity @s container.* *[custom_data~{artifact:"prospectors_loupe"}] if items entity @s weapon.offhand *[custom_data~{artifact:"prospectors_loupe"}] store result score #loupe_roll ec.cf_temp run random value 1..100
execute unless items entity @s container.* *[custom_data~{artifact:"prospectors_loupe"}] if items entity @s weapon.offhand *[custom_data~{artifact:"prospectors_loupe"}] if score #loupe_roll ec.cf_temp matches 1 run scoreboard players set #ore_roll ec.cf_temp 1
# cap-G: the Forge Resolve sub-cap + the grand Grandforge Regalia consolidate the Prospector's Loupe
# +1% extra roll — re-roll it gated on either held flag, but ONLY when the loose Loupe is NOT held (so a
# re-acquired loose Loupe never double-rolls; exactly one path runs). Same independent 1..100 -> on a 1
# force a hit, set-not-add. The grand line OR-s with the Forge Resolve line (held together, one #cgf_lp
# write). #cgf_lp is a distinct fake so it never clobbers the Loupe's #loupe_roll in the same break;
# zeroed first so a stale value from a previous break never leaks into the final hit-check.
scoreboard players set #cgf_lp ec.cf_temp 0
execute unless items entity @s container.* *[custom_data~{artifact:"prospectors_loupe"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"prospectors_loupe"}] unless entity @s[tag=ec.sat_prospectors_loupe] if items entity @s container.* *[custom_data~{grandforge_regalia:true}] store result score #cgf_lp ec.cf_temp run random value 1..100
execute unless items entity @s container.* *[custom_data~{artifact:"prospectors_loupe"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"prospectors_loupe"}] unless entity @s[tag=ec.sat_prospectors_loupe] unless items entity @s container.* *[custom_data~{grandforge_regalia:true}] unless items entity @s weapon.offhand *[custom_data~{grandforge_regalia:true}] if entity @s[tag=ec.sat_grandforge_regalia] store result score #cgf_lp ec.cf_temp run random value 1..100
execute unless items entity @s container.* *[custom_data~{artifact:"prospectors_loupe"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"prospectors_loupe"}] unless entity @s[tag=ec.sat_prospectors_loupe] unless items entity @s container.* *[custom_data~{grandforge_regalia:true}] if items entity @s weapon.offhand *[custom_data~{grandforge_regalia:true}] store result score #cgf_lp ec.cf_temp run random value 1..100
execute unless items entity @s container.* *[custom_data~{artifact:"prospectors_loupe"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"prospectors_loupe"}] unless entity @s[tag=ec.sat_prospectors_loupe] unless items entity @s container.* *[custom_data~{grandforge_regalia:true}] unless items entity @s weapon.offhand *[custom_data~{grandforge_regalia:true}] if items entity @s container.* *[custom_data~{forge_resolve:true}] store result score #cgf_lp ec.cf_temp run random value 1..100
execute unless items entity @s container.* *[custom_data~{artifact:"prospectors_loupe"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"prospectors_loupe"}] unless entity @s[tag=ec.sat_prospectors_loupe] unless items entity @s container.* *[custom_data~{grandforge_regalia:true}] unless items entity @s weapon.offhand *[custom_data~{grandforge_regalia:true}] unless items entity @s container.* *[custom_data~{forge_resolve:true}] unless items entity @s weapon.offhand *[custom_data~{forge_resolve:true}] if entity @s[tag=ec.sat_forge_resolve] store result score #cgf_lp ec.cf_temp run random value 1..100
execute unless items entity @s container.* *[custom_data~{artifact:"prospectors_loupe"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"prospectors_loupe"}] unless entity @s[tag=ec.sat_prospectors_loupe] unless items entity @s container.* *[custom_data~{grandforge_regalia:true}] unless items entity @s weapon.offhand *[custom_data~{grandforge_regalia:true}] unless items entity @s container.* *[custom_data~{forge_resolve:true}] if items entity @s weapon.offhand *[custom_data~{forge_resolve:true}] store result score #cgf_lp ec.cf_temp run random value 1..100
execute if score #cgf_lp ec.cf_temp matches 1 run scoreboard players set #ore_roll ec.cf_temp 1

# Prospector's Doohickey (C6 — D-RENAME from "Prospector's Talisman"; Family K Prospector — art-K): an
# item-gated EXTRA +1.5% artifact-material roll, ADDITIVE on top of the base per-tile 0.5%/0.3% roll
# AND on the Loupe's +1% above (distinct charm, stacks). One independent 1..1000 roll; on 1..15 (1.5%)
# force a hit by setting #ore_roll to 1 so the base early-exit below passes. set-not-add idiom (one
# `if items` test -> two copies still roll once = m4 multi-copy-safe). Only a Doohickey holder pays the
# extra roll; non-holders early-exit unchanged. Distinct fake (#dook_roll) so it never clobbers the
# Loupe's #loupe_roll in the same break.
execute if items entity @s container.* *[custom_data~{artifact:"prospectors_doohickey"}] store result score #dook_roll ec.cf_temp run random value 1..1000
execute unless items entity @s container.* *[custom_data~{artifact:"prospectors_doohickey"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"prospectors_doohickey"}] if entity @s[tag=ec.sat_prospectors_doohickey] store result score #dook_roll ec.cf_temp run random value 1..1000
execute if items entity @s container.* *[custom_data~{artifact:"prospectors_doohickey"}] if score #dook_roll ec.cf_temp matches 1..15 run scoreboard players set #ore_roll ec.cf_temp 1
execute unless items entity @s container.* *[custom_data~{artifact:"prospectors_doohickey"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"prospectors_doohickey"}] if entity @s[tag=ec.sat_prospectors_doohickey] if score #dook_roll ec.cf_temp matches 1..15 run scoreboard players set #ore_roll ec.cf_temp 1
execute unless items entity @s container.* *[custom_data~{artifact:"prospectors_doohickey"}] if items entity @s weapon.offhand *[custom_data~{artifact:"prospectors_doohickey"}] store result score #dook_roll ec.cf_temp run random value 1..1000
execute unless items entity @s container.* *[custom_data~{artifact:"prospectors_doohickey"}] if items entity @s weapon.offhand *[custom_data~{artifact:"prospectors_doohickey"}] if score #dook_roll ec.cf_temp matches 1..15 run scoreboard players set #ore_roll ec.cf_temp 1

# cap-K (m4): the Surveyor Line sub-cap + the Demiurge's Spirit Artifact consolidate the Prospector's
# Doohickey +1.5% extra roll — re-roll it gated on either held flag, but ONLY when the loose Doohickey is
# NOT held (so a re-acquired loose Doohickey never double-rolls; exactly one path runs). Same independent
# 1..1000 -> on 1..15 force a hit, set-not-add. The grand line OR-s with the Surveyor line (one #dkk_cap
# write). #dkk_cap is a distinct fake so it never clobbers the Doohickey's #dook_roll in the same break;
# zeroed first so a stale value from a previous break never leaks into the final hit-check. (No Newcomer
# carve-out needed here: the suppress is built INTO the re-grant guard — the loose Doohickey always fires
# its own roll when held, so Newcomer who re-holds the loose charm keeps it; the node only ADDS when the
# loose is absent. This mirrors cap-G's grandforge Loupe re-roll.)
scoreboard players set #dkk_cap ec.cf_temp 0
execute unless items entity @s container.* *[custom_data~{artifact:"prospectors_doohickey"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"prospectors_doohickey"}] unless entity @s[tag=ec.sat_prospectors_doohickey] if items entity @s container.* *[custom_data~{demiurges_capstone:true}] store result score #dkk_cap ec.cf_temp run random value 1..1000
execute unless items entity @s container.* *[custom_data~{artifact:"prospectors_doohickey"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"prospectors_doohickey"}] unless entity @s[tag=ec.sat_prospectors_doohickey] unless items entity @s container.* *[custom_data~{demiurges_capstone:true}] unless items entity @s weapon.offhand *[custom_data~{demiurges_capstone:true}] if entity @s[tag=ec.sat_demiurges_capstone] store result score #dkk_cap ec.cf_temp run random value 1..1000
execute unless items entity @s container.* *[custom_data~{artifact:"prospectors_doohickey"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"prospectors_doohickey"}] unless entity @s[tag=ec.sat_prospectors_doohickey] unless items entity @s container.* *[custom_data~{demiurges_capstone:true}] if items entity @s weapon.offhand *[custom_data~{demiurges_capstone:true}] store result score #dkk_cap ec.cf_temp run random value 1..1000
execute unless items entity @s container.* *[custom_data~{artifact:"prospectors_doohickey"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"prospectors_doohickey"}] unless entity @s[tag=ec.sat_prospectors_doohickey] unless items entity @s container.* *[custom_data~{demiurges_capstone:true}] unless items entity @s weapon.offhand *[custom_data~{demiurges_capstone:true}] if items entity @s container.* *[custom_data~{surveyor_line:true}] store result score #dkk_cap ec.cf_temp run random value 1..1000
execute unless items entity @s container.* *[custom_data~{artifact:"prospectors_doohickey"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"prospectors_doohickey"}] unless entity @s[tag=ec.sat_prospectors_doohickey] unless items entity @s container.* *[custom_data~{demiurges_capstone:true}] unless items entity @s weapon.offhand *[custom_data~{demiurges_capstone:true}] unless items entity @s container.* *[custom_data~{surveyor_line:true}] unless items entity @s weapon.offhand *[custom_data~{surveyor_line:true}] if entity @s[tag=ec.sat_surveyor_line] store result score #dkk_cap ec.cf_temp run random value 1..1000
execute unless items entity @s container.* *[custom_data~{artifact:"prospectors_doohickey"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"prospectors_doohickey"}] unless entity @s[tag=ec.sat_prospectors_doohickey] unless items entity @s container.* *[custom_data~{demiurges_capstone:true}] unless items entity @s weapon.offhand *[custom_data~{demiurges_capstone:true}] unless items entity @s container.* *[custom_data~{surveyor_line:true}] if items entity @s weapon.offhand *[custom_data~{surveyor_line:true}] store result score #dkk_cap ec.cf_temp run random value 1..1000
execute if score #dkk_cap ec.cf_temp matches 1..15 run scoreboard players set #ore_roll ec.cf_temp 1

# Early exit if roll misses (not 1)
execute unless score #ore_roll ec.cf_temp matches 1 run return 0

# Drop the matching tier loot table — inv-full guarded (Wiring Audit #3 S1.2, 2026-05-29)
# Rare 0.5%/0.3% rolls were previously voided silently on full inventory; now drop at feet.
execute store result score #inv_full ec.var run function evercraft:util/check_inv_full
execute if score #ore_tier ec.cf_temp matches 1 run function evercraft:craftforever/forging/ore_mining/give_drop {tier:"1"}
execute if score #ore_tier ec.cf_temp matches 2 run function evercraft:craftforever/forging/ore_mining/give_drop {tier:"2"}
execute if score #ore_tier ec.cf_temp matches 3 run function evercraft:craftforever/forging/ore_mining/give_drop {tier:"3"}
execute if score #ore_tier ec.cf_temp matches 4 run function evercraft:craftforever/forging/ore_mining/give_drop {tier:"4"}
execute if score #ore_tier ec.cf_temp matches 5 run function evercraft:craftforever/forging/ore_mining/give_drop {tier:"5"}
execute if score #ore_tier ec.cf_temp matches 6 run function evercraft:craftforever/forging/ore_mining/give_drop {tier:"6"}
execute if score #ore_tier ec.cf_temp matches 7 run function evercraft:craftforever/forging/ore_mining/give_drop {tier:"7"}

# Tiered sound effects — higher tiers = more dramatic sounds
execute if score #ore_tier ec.cf_temp matches 1..2 if score @s ec.fx_snd matches 1.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 1.0 1.2
execute if score #ore_tier ec.cf_temp matches 3..4 if score @s ec.fx_snd matches 1.. run playsound minecraft:block.amethyst_cluster.break master @s ~ ~ ~ 1.0 1.0
execute if score #ore_tier ec.cf_temp matches 3..4 if score @s ec.fx_snd matches 1.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.8 0.8
execute if score #ore_tier ec.cf_temp matches 5..6 if score @s ec.fx_snd matches 1.. run playsound minecraft:block.amethyst_block.resonate master @s ~ ~ ~ 1.2 1.0
execute if score #ore_tier ec.cf_temp matches 5..6 if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.player.levelup master @s ~ ~ ~ 0.6 1.4
execute if score #ore_tier ec.cf_temp matches 7 if score @s ec.fx_snd matches 1.. run playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 1.0 1.0
execute if score #ore_tier ec.cf_temp matches 7 if score @s ec.fx_snd matches 1.. run playsound minecraft:block.amethyst_block.resonate master @s ~ ~ ~ 1.2 0.6

# Chat notification — tier-colored messages for rare finds
scoreboard players set #ndur ec.temp 45
execute if score #ore_tier ec.cf_temp matches 1..2 run data modify storage evercraft:notify stage.c set value [{text:"You found an artifact material.",color:"gray"}]
execute if score #ore_tier ec.cf_temp matches 1..2 run function evercraft:util/notify/emit
execute if score #ore_tier ec.cf_temp matches 3..4 run data modify storage evercraft:notify stage.c set value [{text:"You found a ",color:"yellow"},{text:"quality",color:"aqua"},{text:" artifact material!",color:"yellow"}]
execute if score #ore_tier ec.cf_temp matches 3..4 run function evercraft:util/notify/emit
execute if score #ore_tier ec.cf_temp matches 5..6 run data modify storage evercraft:notify stage.c set value [{text:"\u2726 You found a ",color:"yellow"},{text:"rare",color:"light_purple",bold:true},{text:" artifact material! \u2726",color:"yellow"}]
execute if score #ore_tier ec.cf_temp matches 5..6 run function evercraft:util/notify/emit
execute if score #ore_tier ec.cf_temp matches 7 run data modify storage evercraft:notify stage.c set value [{text:"\u2726 You found an ",color:"yellow"},{text:"extraordinary",color:"gold",bold:true},{text:" artifact material! \u2726",color:"yellow"}]
execute if score #ore_tier ec.cf_temp matches 7 run function evercraft:util/notify/emit

# Particle effects for rare finds (T5+)
execute if score #ore_tier ec.cf_temp matches 5..6 run particle minecraft:enchant ~ ~1 ~ 0.5 0.5 0.5 0.5 20
execute if score #ore_tier ec.cf_temp matches 7 run particle minecraft:totem_of_undying ~ ~1 ~ 0.3 0.5 0.3 0.2 30
