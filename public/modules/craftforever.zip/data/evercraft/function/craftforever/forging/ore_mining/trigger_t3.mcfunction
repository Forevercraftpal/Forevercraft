# Ore Mining — Trigger T3 (lapis, redstone ores)
scoreboard players set #ore_tier ec.cf_temp 3
function evercraft:craftforever/forging/ore_mining/check_drop
