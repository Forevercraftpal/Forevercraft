# Give one forge output, inv-full guarded (P1-1). Macro arg: $(tbl) = loot table path.
# #inv_full ec.var must already be computed by the caller (give_output) this tick.
$execute if score #inv_full ec.var matches 0 run loot give @s loot evercraft:craftforever/materials/$(tbl)
$execute if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:craftforever/materials/$(tbl)
