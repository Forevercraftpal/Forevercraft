# Ore Mining — Trigger T2 (iron, gold ores)
scoreboard players set #ore_tier ec.cf_temp 2
function evercraft:craftforever/forging/ore_mining/check_drop
