# Ore-mining drop, inv-full guarded (Wiring Audit #3 S1.2, 2026-05-29).
# Macro arg: $(tier) = "1".."7" — selects ore_drop_t<N> loot table.
# #inv_full ec.var must already be computed by the caller (check_drop) this tick.
$execute if score #inv_full ec.var matches 0 run loot give @s loot evercraft:craftforever/materials/ore_drop_t$(tier)
$execute if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:craftforever/materials/ore_drop_t$(tier)
