# Artisan Forge — Refund 3x of a material via its loot table (macro {tbl}).
# #inv_full must be precomputed by the caller (refund_inputs). give_one drops at feet if full.
$function evercraft:craftforever/forging/materials/give_one {tbl:"$(tbl)"}
$function evercraft:craftforever/forging/materials/give_one {tbl:"$(tbl)"}
$function evercraft:craftforever/forging/materials/give_one {tbl:"$(tbl)"}
