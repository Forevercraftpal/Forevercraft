# Artisan Forge — Wash Block (right-click with water bucket)
# Removes dye and restores default appearance
# Run as: player, at: interaction entity position

# Reset marker color to default
execute as @e[type=marker,tag=CF.Marker,distance=..2,limit=1] run data modify entity @s data.color set value "artisan_forge"

# Reset display skin to default
execute as @e[type=armor_stand,tag=CF.Stand,distance=..2,limit=1] on passengers run data modify entity @s item.components."minecraft:profile".properties[0].value set value "ewogICJ0aW1lc3RhbXAiIDogMTc3Mzg0MzMzNjE0OCwKICAicHJvZmlsZUlkIiA6ICJiZmQ3MjMxMGNmYWY0Yjc5OTNlYzhiYzU3ODg3YzU5ZCIsCiAgInByb2ZpbGVOYW1lIiA6ICJBbHBoYVNwQW0iLAogICJzaWduYXR1cmVSZXF1aXJlZCIgOiB0cnVlLAogICJ0ZXh0dXJlcyIgOiB7CiAgICAiU0tJTiIgOiB7CiAgICAgICJ1cmwiIDogImh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvZGM3NGU2ZWRmZTAxZDRjZGEyMjNhNjlhMTQ0MDQ4Y2E1ODgwNDYyNzE2MjE3MTNmZjc0NDdhYjJmNzQzYjU2OSIsCiAgICAgICJtZXRhZGF0YSIgOiB7CiAgICAgICAgIm1vZGVsIiA6ICJzbGltIgogICAgICB9CiAgICB9CiAgfQp9"

# Effects
playsound minecraft:item.bucket.empty master @a[distance=..16,scores={ec.fx_snd=1..}] ~ ~ ~ 1 1.2
particle minecraft:splash ~0.5 ~1.0 ~0.5 0.3 0.2 0.3 0.05 12

# Feedback
data modify storage evercraft:notify stage.c set value [{text:"Washed ",color:"gray",italic:true},{text:"Artisan Forge",color:"#E0B0FF",italic:true},{text:" back to default",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
