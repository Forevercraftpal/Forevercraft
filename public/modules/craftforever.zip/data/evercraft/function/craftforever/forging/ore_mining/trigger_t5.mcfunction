# Ore Mining — Trigger T5 (emerald ore)
scoreboard players set #ore_tier ec.cf_temp 5
function evercraft:craftforever/forging/ore_mining/check_drop
