# Forging Minigame — Resolve (calculate final quality and outcome)

# Apply bonuses
# Artisan Rank bonus: rank/20, max +5
scoreboard players operation #cf_rank_bonus ec.cf_temp = @s ec.cf_rank
scoreboard players operation #cf_rank_bonus ec.cf_temp /= #cf_20 ec.cf_temp
execute if score #cf_rank_bonus ec.cf_temp matches 6.. run scoreboard players set #cf_rank_bonus ec.cf_temp 5
scoreboard players operation @s ec.cf_quality += #cf_rank_bonus ec.cf_temp
data modify storage evercraft:notify stage.c set value [{text:"Rank Bonus: ",color:"gold"},{text:"+",color:"yellow"},{score:{name:"#cf_rank_bonus",objective:"ec.cf_temp"},color:"yellow"},{text:" quality",color:"yellow"}]
scoreboard players set #ndur ec.temp 45
execute if score #cf_rank_bonus ec.cf_temp matches 1.. run function evercraft:util/notify/emit

# Artisan Level bonus for previous tiers: +2% success per level (applied as quality bonus)
# For artifact materials: if art_tier < max tier forged, apply level bonus
# This is calculated as: (rank / 5) for the tier below current, capped at quality +2
execute if score @s ec.cf_art_cat matches 1..4 run function evercraft:craftforever/forging/minigame/apply_level_bonus

# Tiered catalyst success boost (+1 to +5 quality based on catalyst tier)
execute if score @s ec.cf_art_cat matches 1..4 if score @s ec.cf_cat_tier matches 0 run scoreboard players add @s ec.cf_quality 0
execute if score @s ec.cf_art_cat matches 1..4 if score @s ec.cf_cat_tier matches 1 run scoreboard players add @s ec.cf_quality 1
execute if score @s ec.cf_art_cat matches 1..4 if score @s ec.cf_cat_tier matches 2 run scoreboard players add @s ec.cf_quality 1
execute if score @s ec.cf_art_cat matches 1..4 if score @s ec.cf_cat_tier matches 3 run scoreboard players add @s ec.cf_quality 2
execute if score @s ec.cf_art_cat matches 1..4 if score @s ec.cf_cat_tier matches 4 run scoreboard players add @s ec.cf_quality 2
data modify storage evercraft:notify stage.c set value [{text:"Catalyst: ",color:"gold"},{text:"Success boost applied!",color:"yellow"}]
scoreboard players set #ndur ec.temp 45
execute if score @s ec.cf_art_cat matches 1..4 if score @s ec.cf_cat_tier matches 1.. run function evercraft:util/notify/emit

# Comfort bonus if at home forge (+1 to +3 based on housing tier)
execute if score @s hs.in_zone matches 1 if score @s hs.tier matches 1..2 run scoreboard players add @s ec.cf_quality 1
execute if score @s hs.in_zone matches 1 if score @s hs.tier matches 3..4 run scoreboard players add @s ec.cf_quality 2
execute if score @s hs.in_zone matches 1 if score @s hs.tier matches 5.. run scoreboard players add @s ec.cf_quality 3
data modify storage evercraft:notify stage.c set value [{text:"Home Forge: ",color:"gold"},{text:"Comfort bonus applied!",color:"yellow"}]
scoreboard players set #ndur ec.temp 45
execute if score @s hs.in_zone matches 1 run function evercraft:util/notify/emit

# === Family G — Forge Trade resolve-quality leaves (art-G + cap-G) ===
# Forgemaster's Tongs (C15) + Grand Anvil Heart (C17) each grant +1 forge-resolve quality, item-
# gated while held — mirrors the existing Catalyst / Home Forge +1 adds above (resolve quality is a
# per-forge session accumulator with multiple legit add-sites; this is one more, NOT a one-writer
# violation). Both add independently (a player holding both gets +2) — additive, exactly like the
# Catalyst + Home Forge bonuses stack. set-not-add per id (one `if items` test -> two copies of the
# same charm add once = m4 multi-copy-safe). C17's +0.3 CR is in calculate; its +25% break-speed is
# in player_tick; this is its forge-resolve lever (the sub-binding consolidates all three).
#
# cap-G m4 Layer-1 SUPPRESSION (per-forge-session): the grand Grandforge Regalia provides the
# CONSOLIDATED +2 forge quality below (Tongs +1 + Grand Anvil +1), and the Forge Resolve sub-cap
# provides the Tongs +1 — so the loose leaves they absorb are suppressed to avoid a double-dip on a
# re-acquired loose leaf. Newcomer-exempt (`unless ec.difficulty matches 1`): the ec._gfhq tag is set
# ONLY for Adventurer/Pioneer when an absorbing node is held. The loose Forgemaster's Tongs is absorbed
# by BOTH the Forge Resolve sub-cap AND the grand; the loose Grand Anvil Heart is absorbed only by the
# grand. (Smith's Apron / Quench Line carry NO forge-quality, so they do not suppress.)
tag @s remove ec._gfhq
execute if items entity @s container.* *[custom_data~{grandforge_regalia:true}] unless score @s ec.difficulty matches 1 run tag @s add ec._gfhq
execute unless items entity @s container.* *[custom_data~{grandforge_regalia:true}] unless items entity @s weapon.offhand *[custom_data~{grandforge_regalia:true}] if entity @s[tag=ec.sat_grandforge_regalia] unless score @s ec.difficulty matches 1 run tag @s add ec._gfhq
execute unless entity @s[tag=ec._gfhq] if items entity @s weapon.offhand *[custom_data~{grandforge_regalia:true}] unless score @s ec.difficulty matches 1 run tag @s add ec._gfhq
execute unless entity @s[tag=ec._gfhq] if items entity @s container.* *[custom_data~{forge_resolve:true}] unless score @s ec.difficulty matches 1 run tag @s add ec._gfhq
execute unless entity @s[tag=ec._gfhq] unless items entity @s container.* *[custom_data~{forge_resolve:true}] unless items entity @s weapon.offhand *[custom_data~{forge_resolve:true}] if entity @s[tag=ec.sat_forge_resolve] unless score @s ec.difficulty matches 1 run tag @s add ec._gfhq
execute unless entity @s[tag=ec._gfhq] if items entity @s weapon.offhand *[custom_data~{forge_resolve:true}] unless score @s ec.difficulty matches 1 run tag @s add ec._gfhq
# Loose Forgemaster's Tongs (suppressed when Forge Resolve OR the grand is held + not Newcomer).
execute unless entity @s[tag=ec._gfhq] if items entity @s container.* *[custom_data~{artifact:"forgemasters_tongs"}] run scoreboard players add @s ec.cf_quality 1
execute unless entity @s[tag=ec._gfhq] unless items entity @s container.* *[custom_data~{artifact:"forgemasters_tongs"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"forgemasters_tongs"}] if entity @s[tag=ec.sat_forgemasters_tongs] run scoreboard players add @s ec.cf_quality 1
execute unless entity @s[tag=ec._gfhq] unless items entity @s container.* *[custom_data~{artifact:"forgemasters_tongs"}] if items entity @s weapon.offhand *[custom_data~{artifact:"forgemasters_tongs"}] run scoreboard players add @s ec.cf_quality 1
data modify storage evercraft:notify stage.c set value [{text:"Forgemaster's Tongs: ",color:"gold"},{text:"+1 quality",color:"yellow"}]
scoreboard players set #ndur ec.temp 45
execute unless entity @s[tag=ec._gfhq] if items entity @s container.* *[custom_data~{artifact:"forgemasters_tongs"}] run function evercraft:util/notify/emit
execute unless entity @s[tag=ec._gfhq] unless items entity @s container.* *[custom_data~{artifact:"forgemasters_tongs"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"forgemasters_tongs"}] if entity @s[tag=ec.sat_forgemasters_tongs] run function evercraft:util/notify/emit
execute unless entity @s[tag=ec._gfhq] unless items entity @s container.* *[custom_data~{artifact:"forgemasters_tongs"}] if items entity @s weapon.offhand *[custom_data~{artifact:"forgemasters_tongs"}] run function evercraft:util/notify/emit
# Loose Grand Anvil Heart (suppressed only when the grand is held + not Newcomer; the Forge Resolve
# sub-cap does NOT absorb it, so a forge_resolve holder keeps a loose Grand Anvil Heart's +1).
tag @s remove ec._gfhq2
execute if items entity @s container.* *[custom_data~{grandforge_regalia:true}] unless score @s ec.difficulty matches 1 run tag @s add ec._gfhq2
execute unless items entity @s container.* *[custom_data~{grandforge_regalia:true}] unless items entity @s weapon.offhand *[custom_data~{grandforge_regalia:true}] if entity @s[tag=ec.sat_grandforge_regalia] unless score @s ec.difficulty matches 1 run tag @s add ec._gfhq2
execute unless entity @s[tag=ec._gfhq2] if items entity @s weapon.offhand *[custom_data~{grandforge_regalia:true}] unless score @s ec.difficulty matches 1 run tag @s add ec._gfhq2
execute unless entity @s[tag=ec._gfhq2] if items entity @s container.* *[custom_data~{artifact:"grand_anvil_heart"}] run scoreboard players add @s ec.cf_quality 1
execute unless entity @s[tag=ec._gfhq2] unless items entity @s container.* *[custom_data~{artifact:"grand_anvil_heart"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"grand_anvil_heart"}] if entity @s[tag=ec.sat_grand_anvil_heart] run scoreboard players add @s ec.cf_quality 1
execute unless entity @s[tag=ec._gfhq2] unless items entity @s container.* *[custom_data~{artifact:"grand_anvil_heart"}] if items entity @s weapon.offhand *[custom_data~{artifact:"grand_anvil_heart"}] run scoreboard players add @s ec.cf_quality 1
data modify storage evercraft:notify stage.c set value [{text:"Grand Anvil Heart: ",color:"gold"},{text:"+1 quality",color:"yellow"}]
scoreboard players set #ndur ec.temp 45
execute unless entity @s[tag=ec._gfhq2] if items entity @s container.* *[custom_data~{artifact:"grand_anvil_heart"}] run function evercraft:util/notify/emit
execute unless entity @s[tag=ec._gfhq2] unless items entity @s container.* *[custom_data~{artifact:"grand_anvil_heart"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"grand_anvil_heart"}] if entity @s[tag=ec.sat_grand_anvil_heart] run function evercraft:util/notify/emit
execute unless entity @s[tag=ec._gfhq2] unless items entity @s container.* *[custom_data~{artifact:"grand_anvil_heart"}] if items entity @s weapon.offhand *[custom_data~{artifact:"grand_anvil_heart"}] run function evercraft:util/notify/emit
# cap-G CONSOLIDATED forge-quality rungs (sub-cap + grand). Forge Resolve sub-cap = +1 (Tongs); grand
# Grandforge Regalia = +2 (Tongs + Grand Anvil), unless superseded. Each id-presence gated (set-not-add).
execute unless items entity @s container.* *[custom_data~{grandforge_regalia:true}] unless items entity @s weapon.offhand *[custom_data~{grandforge_regalia:true}] unless entity @s[tag=ec.sat_grandforge_regalia] if items entity @s container.* *[custom_data~{forge_resolve:true}] run scoreboard players add @s ec.cf_quality 1
execute unless items entity @s container.* *[custom_data~{grandforge_regalia:true}] unless items entity @s weapon.offhand *[custom_data~{grandforge_regalia:true}] unless entity @s[tag=ec.sat_grandforge_regalia] unless items entity @s container.* *[custom_data~{forge_resolve:true}] unless items entity @s weapon.offhand *[custom_data~{forge_resolve:true}] if entity @s[tag=ec.sat_forge_resolve] run scoreboard players add @s ec.cf_quality 1
execute unless items entity @s container.* *[custom_data~{grandforge_regalia:true}] unless items entity @s weapon.offhand *[custom_data~{grandforge_regalia:true}] unless entity @s[tag=ec.sat_grandforge_regalia] unless items entity @s container.* *[custom_data~{forge_resolve:true}] if items entity @s weapon.offhand *[custom_data~{forge_resolve:true}] run scoreboard players add @s ec.cf_quality 1
data modify storage evercraft:notify stage.c set value [{text:"Forge Resolve: ",color:"gold"},{text:"+1 quality",color:"yellow"}]
scoreboard players set #ndur ec.temp 45
execute unless items entity @s container.* *[custom_data~{grandforge_regalia:true}] unless items entity @s weapon.offhand *[custom_data~{grandforge_regalia:true}] unless entity @s[tag=ec.sat_grandforge_regalia] if items entity @s container.* *[custom_data~{forge_resolve:true}] run function evercraft:util/notify/emit
execute unless items entity @s container.* *[custom_data~{grandforge_regalia:true}] unless items entity @s weapon.offhand *[custom_data~{grandforge_regalia:true}] unless entity @s[tag=ec.sat_grandforge_regalia] unless items entity @s container.* *[custom_data~{forge_resolve:true}] unless items entity @s weapon.offhand *[custom_data~{forge_resolve:true}] if entity @s[tag=ec.sat_forge_resolve] run function evercraft:util/notify/emit
execute unless items entity @s container.* *[custom_data~{grandforge_regalia:true}] unless items entity @s weapon.offhand *[custom_data~{grandforge_regalia:true}] unless entity @s[tag=ec.sat_grandforge_regalia] unless items entity @s container.* *[custom_data~{forge_resolve:true}] if items entity @s weapon.offhand *[custom_data~{forge_resolve:true}] run function evercraft:util/notify/emit
execute if items entity @s container.* *[custom_data~{grandforge_regalia:true}] run scoreboard players add @s ec.cf_quality 2
execute unless items entity @s container.* *[custom_data~{grandforge_regalia:true}] unless items entity @s weapon.offhand *[custom_data~{grandforge_regalia:true}] if entity @s[tag=ec.sat_grandforge_regalia] run scoreboard players add @s ec.cf_quality 2
execute unless items entity @s container.* *[custom_data~{grandforge_regalia:true}] if items entity @s weapon.offhand *[custom_data~{grandforge_regalia:true}] run scoreboard players add @s ec.cf_quality 2
data modify storage evercraft:notify stage.c set value [{text:"Grandforge Regalia: ",color:"gold"},{text:"+2 quality",color:"yellow"}]
scoreboard players set #ndur ec.temp 45
execute if items entity @s container.* *[custom_data~{grandforge_regalia:true}] run function evercraft:util/notify/emit
execute unless items entity @s container.* *[custom_data~{grandforge_regalia:true}] unless items entity @s weapon.offhand *[custom_data~{grandforge_regalia:true}] if entity @s[tag=ec.sat_grandforge_regalia] run function evercraft:util/notify/emit
execute unless items entity @s container.* *[custom_data~{grandforge_regalia:true}] if items entity @s weapon.offhand *[custom_data~{grandforge_regalia:true}] run function evercraft:util/notify/emit
tag @s remove ec._gfhq
tag @s remove ec._gfhq2

# Show total quality
data modify storage evercraft:notify stage.c set value [{text:"Final Quality: ",color:"gray"},{score:{name:"@s",objective:"ec.cf_quality"},color:"white",bold:true}]
scoreboard players set #ndur ec.temp 50
function evercraft:util/notify/emit

# Determine outcome
execute at @s run data modify entity @e[type=text_display,tag=CF.Title,distance=..7,limit=1] text set value {text:"Forging Complete!",color:"gold",bold:true}

execute if score @s ec.cf_quality matches ..3 run function evercraft:craftforever/forging/minigame/result_fail
execute if score @s ec.cf_quality matches 4..7 run function evercraft:craftforever/forging/minigame/result_rough
execute if score @s ec.cf_quality matches 8..11 run function evercraft:craftforever/forging/minigame/result_good
execute if score @s ec.cf_quality matches 12.. run function evercraft:craftforever/forging/minigame/result_masterwork

# --- Recipe discovery (Wiring Audit #14 C4) ---
# On a successful forge (quality 4+) of a standard recipe (1-5), light up the
# Recipe Book bit. Ding-once OR-pattern (parallel to nodes/complete_mine):
# bit = 2^(recipe-1). Idempotent — masterwork double-give can't double-set.
execute if score @s ec.cf_quality matches 4.. if score @s ec.cf_recipe matches 1 run scoreboard players set #cf_recbit ec.cf_temp 1
execute if score @s ec.cf_quality matches 4.. if score @s ec.cf_recipe matches 2 run scoreboard players set #cf_recbit ec.cf_temp 2
execute if score @s ec.cf_quality matches 4.. if score @s ec.cf_recipe matches 3 run scoreboard players set #cf_recbit ec.cf_temp 4
execute if score @s ec.cf_quality matches 4.. if score @s ec.cf_recipe matches 4 run scoreboard players set #cf_recbit ec.cf_temp 8
execute if score @s ec.cf_quality matches 4.. if score @s ec.cf_recipe matches 5 run scoreboard players set #cf_recbit ec.cf_temp 16
execute if score @s ec.cf_quality matches 4.. if score @s ec.cf_recipe matches 1..5 run function evercraft:craftforever/forging/minigame/mark_recipe_found
# Wiring Audit #14 C16: artifact-tier recipe discovery (recipe 100, keyed by art_cat × art_tier).
execute if score @s ec.cf_quality matches 4.. if score @s ec.cf_recipe matches 100 run function evercraft:craftforever/forging/minigame/mark_art_recipe_found

# T7 success: 7% chance for Mythical artifact (only on non-fail results)
execute if score @s ec.cf_art_tier matches 7 if score @s ec.cf_quality matches 4.. run function evercraft:craftforever/forging/artifacts/roll_t7_success

# === Family J — Harvest Censer (C27) bonus-material roll on a FORGE (art-J) ===
# The "OR forge" half of C27's +2% bonus-material draw (its cook half lives in cooking/minigame/
# resolve). H13 additive extra forge-artifact roll, item-gated, parallel to (NOT a rewrite of) the
# T7 roll above. Gated on a successful forge (quality 4+) of an artifact recipe (cf_art_cat 1..4 set
# during the forge), so roll_artifact's category + rarity (cf_art_cat / cf_art_tier) are meaningful.
# ONE extra `random value 1..100` (matches 1..2 = ~2%). id-presence -> two copies of the Censer roll
# once (m4 multi-copy-safe). Base forge odds untouched (ADDITIVE).
execute if score @s ec.cf_quality matches 4.. if score @s ec.cf_art_cat matches 1..4 if items entity @s container.* *[custom_data~{artifact:"harvest_censer"}] store result score #cfj_cen ec.cf_temp run random value 1..100
execute if score @s ec.cf_quality matches 4.. if score @s ec.cf_art_cat matches 1..4 unless items entity @s container.* *[custom_data~{artifact:"harvest_censer"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"harvest_censer"}] if entity @s[tag=ec.sat_harvest_censer] store result score #cfj_cen ec.cf_temp run random value 1..100
execute if score @s ec.cf_quality matches 4.. if score @s ec.cf_art_cat matches 1..4 if items entity @s container.* *[custom_data~{artifact:"harvest_censer"}] if score #cfj_cen ec.cf_temp matches 1..2 run function evercraft:craftforever/forging/artifacts/roll_artifact
execute if score @s ec.cf_quality matches 4.. if score @s ec.cf_art_cat matches 1..4 unless items entity @s container.* *[custom_data~{artifact:"harvest_censer"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"harvest_censer"}] if entity @s[tag=ec.sat_harvest_censer] if score #cfj_cen ec.cf_temp matches 1..2 run function evercraft:craftforever/forging/artifacts/roll_artifact
execute if score @s ec.cf_quality matches 4.. if score @s ec.cf_art_cat matches 1..4 unless items entity @s container.* *[custom_data~{artifact:"harvest_censer"}] if items entity @s weapon.offhand *[custom_data~{artifact:"harvest_censer"}] store result score #cfj_cen ec.cf_temp run random value 1..100
execute if score @s ec.cf_quality matches 4.. if score @s ec.cf_art_cat matches 1..4 unless items entity @s container.* *[custom_data~{artifact:"harvest_censer"}] if items entity @s weapon.offhand *[custom_data~{artifact:"harvest_censer"}] if score #cfj_cen ec.cf_temp matches 1..2 run function evercraft:craftforever/forging/artifacts/roll_artifact

# Award Artisan XP: Forging category
# Success: base 6 + quality | Fail: 1/3 of success (base 2 + quality/3)
execute if score @s ec.cf_quality matches 4.. run scoreboard players set #cf_xp_amount ec.cf_temp 6
execute if score @s ec.cf_quality matches 4.. run scoreboard players operation #cf_xp_amount ec.cf_temp += @s ec.cf_quality
execute if score @s ec.cf_quality matches ..3 run scoreboard players set #cf_xp_amount ec.cf_temp 2
execute if score @s ec.cf_quality matches ..3 run scoreboard players operation #cf_xp_temp ec.cf_temp = @s ec.cf_quality
execute if score @s ec.cf_quality matches ..3 run scoreboard players operation #cf_xp_temp ec.cf_temp /= #cf_3 ec.cf_temp
execute if score @s ec.cf_quality matches ..3 run scoreboard players operation #cf_xp_amount ec.cf_temp += #cf_xp_temp ec.cf_temp
execute if score #cf_xp_amount ec.cf_temp matches ..1 run scoreboard players set #cf_xp_amount ec.cf_temp 1
scoreboard players set #cf_xp_cat ec.cf_temp 5
function evercraft:craftforever/artisan/add_xp

# Clean up minigame state
tag @s remove CF.Forging

# Forge stat tracking (Blacksmith primary progression)
execute if score @s ec.cf_quality matches 4.. run scoreboard players add @s adv.stat_forge 2
execute if score @s ec.cf_quality matches ..3 run scoreboard players add @s adv.stat_forge 1

# Competition scoring (Forging Championship / H2H)
function evercraft:competition/score/forge_complete

scoreboard players set @s ec.cf_phase 0

# === SMITH'S QUESTLINE HOOK (Chronicles Wave C4) ===========================
# This forging resolve is the single funnel every completed forge passes through
# (it just paid cat-5 Forging XP above). On the player's FIRST forge, hand them the
# Smith's Codex + start the paced Forging line; on every later forge, poke the
# line's check so a `forged_item`/lifetime beat advances. Both gate-first (cheap)
# and dup-guarded inside on_first_forge / check. forging/questline/* only READS
# public forging state — it writes NONE of craftforever/forging/'s engine objectives.
execute unless score @s ec.fgq_active matches 1 run function evercraft:forging/questline/on_first_forge
execute if score @s ec.fgq_active matches 1 run function evercraft:forging/questline/check

# Close the GUI (player can see the result title briefly, then we clean up)
function evercraft:craftforever/forging/gui/close
