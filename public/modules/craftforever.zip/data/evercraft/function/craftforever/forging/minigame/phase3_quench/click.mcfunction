# Phase 3: QUENCH — Evaluate click position (runs as player)

# Calculate distance from lock zone center
scoreboard players operation #cf_dist ec.cf_temp = @s ec.cf_quench
scoreboard players operation #cf_dist ec.cf_temp -= @s ec.cf_lock_zone

# Absolute value
execute if score #cf_dist ec.cf_temp matches ..-1 run scoreboard players operation #cf_dist ec.cf_temp *= #cf_neg1 ec.cf_temp

scoreboard players set #ndur ec.temp 45

# Perfect (within 5 units): +3 quality
execute if score #cf_dist ec.cf_temp matches 0..5 run scoreboard players add @s ec.cf_quality 3
execute if score #cf_dist ec.cf_temp matches 0..5 run data modify storage evercraft:notify stage.c set value [{text:"Perfect quench! ",color:"aqua",bold:true},{text:"+3 quality",color:"yellow"}]
execute if score #cf_dist ec.cf_temp matches 0..5 run function evercraft:util/notify/emit
execute if score #cf_dist ec.cf_temp matches 0..5 if score @s ec.fx_snd matches 1.. run playsound minecraft:item.bucket.fill master @s ~ ~ ~ 1.0 1.5

# Close (within 15 units): +1 quality
execute if score #cf_dist ec.cf_temp matches 6..15 run scoreboard players add @s ec.cf_quality 1
execute if score #cf_dist ec.cf_temp matches 6..15 run data modify storage evercraft:notify stage.c set value [{text:"Decent quench. ",color:"green"},{text:"+1 quality",color:"gray"}]
execute if score #cf_dist ec.cf_temp matches 6..15 run function evercraft:util/notify/emit
execute if score #cf_dist ec.cf_temp matches 6..15 if score @s ec.fx_snd matches 1.. run playsound minecraft:item.bucket.fill master @s ~ ~ ~ 0.7 1.0

# Missed (>15): +0 quality
execute if score #cf_dist ec.cf_temp matches 16.. run data modify storage evercraft:notify stage.c set value [{text:"Rough quench. ",color:"red"},{text:"+0 quality",color:"gray"}]
execute if score #cf_dist ec.cf_temp matches 16.. run function evercraft:util/notify/emit
execute if score #cf_dist ec.cf_temp matches 16.. if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 0.5 0.8

# Clean up phase 3 elements
execute at @s run kill @e[type=text_display,tag=CF.QuenchBar,distance=..7]
execute at @s run kill @e[type=text_display,tag=CF.QuenchText,distance=..7]
execute at @s run kill @e[type=interaction,tag=CF.QuenchBtn,distance=..7]

# Resolve minigame
function evercraft:craftforever/forging/minigame/resolve
