# Ore Mining — Trigger T6 (ancient debris)
scoreboard players set #ore_tier ec.cf_temp 6
function evercraft:craftforever/forging/ore_mining/check_drop
