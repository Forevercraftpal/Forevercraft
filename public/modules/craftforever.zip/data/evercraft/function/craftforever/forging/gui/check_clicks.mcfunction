# Artisan Forge GUI — Check Clicks

scoreboard players operation #gui_check ec.temp = @s adv.gui_session

# Close button (always)
execute as @e[type=interaction,tag=CF.CloseBtn,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction on target run function evercraft:craftforever/forging/gui/click_close
execute as @e[type=interaction,tag=CF.CloseBtn,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction run data remove entity @s interaction

# Deposit Material
execute as @e[type=interaction,tag=CF.DepMatBtn,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction on target run function evercraft:craftforever/forging/gui/deposit_material
execute as @e[type=interaction,tag=CF.DepMatBtn,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction run data remove entity @s interaction

# Deposit Catalyst
execute as @e[type=interaction,tag=CF.DepCatBtn,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction on target run function evercraft:craftforever/forging/gui/deposit_catalyst
execute as @e[type=interaction,tag=CF.DepCatBtn,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction run data remove entity @s interaction

# Begin Forging (only if recipe matched, state=2)
execute if score @s ec.cf_state matches 2 as @e[type=interaction,tag=CF.ForgeBtn,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction on target run function evercraft:craftforever/forging/gui/start_forge
execute if score @s ec.cf_state matches 2 as @e[type=interaction,tag=CF.ForgeBtn,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction run data remove entity @s interaction

# ===== INSPECT (left-click = what does this button do?) — gui/inspect pattern 2026-06-11 =====
execute as @e[type=interaction,tag=CF.DepMatBtn,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Deposit Material",b:"Sets the material you are holding into the forge."}
execute as @e[type=interaction,tag=CF.DepMatBtn,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=CF.DepCatBtn,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Deposit Catalyst",b:"Sets the catalyst you are holding into the forge."}
execute as @e[type=interaction,tag=CF.DepCatBtn,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=CF.ForgeBtn,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Forge",b:"Begins the forging — a three-phase craft of heat, hammer, and quench."}
execute as @e[type=interaction,tag=CF.ForgeBtn,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=CF.CloseBtn,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Close",b:"Closes the Grand Forge."}
execute as @e[type=interaction,tag=CF.CloseBtn,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack run data remove entity @s attack
