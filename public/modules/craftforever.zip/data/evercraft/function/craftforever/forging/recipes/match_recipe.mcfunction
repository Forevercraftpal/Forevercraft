# Artisan Forge — Match Recipe
# Checks deposited mat_tier + cat_tier against known recipes
# Sets ec.cf_recipe (1-5 standard, 100 artifact) and state=2 on match

scoreboard players set @s ec.cf_recipe 0

# === STANDARD RECIPES (require specific catalyst) ===
# Recipe 1: 3x Scrap Metal + Charcoal → Tempered Alloy (Rank 1+)
# Heartwood Kindling (cat_tier 5) is a premium charcoal — also valid for this recipe.
execute if score @s ec.cf_mat_tier matches 0 if score @s ec.cf_cat_tier matches 0 run scoreboard players set @s ec.cf_recipe 1
execute if score @s ec.cf_mat_tier matches 0 if score @s ec.cf_cat_tier matches 5 run scoreboard players set @s ec.cf_recipe 1

# Recipe 2: 3x Tempered Alloy + Blaze Powder → Starforged Ingot (Rank 20+)
execute if score @s ec.cf_mat_tier matches 1 if score @s ec.cf_cat_tier matches 1 run scoreboard players set @s ec.cf_recipe 2

# Recipe 3: 3x Starforged Ingot + Heart of the Sea → Dreamwrought Bar (Rank 40+)
execute if score @s ec.cf_mat_tier matches 2 if score @s ec.cf_cat_tier matches 2 run scoreboard players set @s ec.cf_recipe 3
# Recipe 3 (alt): 3x Geode Dust + Heart of the Sea → Dreamwrought Bar — Wiring Audit #37 D1.
# Geode Dust (mat_tier 6) is an alternate mid-tier input to the same Dreamwrought Bar recipe, so a
# Terrawarp digger can spend their cache haul. give_output keys on ec.cf_recipe, so the output is
# correctly a Dreamwrought Bar regardless of which material fed it.
execute if score @s ec.cf_mat_tier matches 6 if score @s ec.cf_cat_tier matches 2 run scoreboard players set @s ec.cf_recipe 3

# Recipe 4: 3x Dreamwrought Bar + Nether Star → Eternal Essence (Rank 60+)
execute if score @s ec.cf_mat_tier matches 3 if score @s ec.cf_cat_tier matches 3 run scoreboard players set @s ec.cf_recipe 4

# Recipe 5: 3x Eternal Essence + Spirit Treat → Soulbound Core (Rank 80+)
execute if score @s ec.cf_mat_tier matches 4 if score @s ec.cf_cat_tier matches 4 run scoreboard players set @s ec.cf_recipe 5

# === ARTIFACT MATERIAL RECIPES (catalyst optional — provides bonus) ===
# Artifact materials auto-match when deposited (no catalyst required)
# mat_tier 10-16 = weapon, 20-26 = armor, 30-36 = tool, 40-46 = accessory
execute if score @s ec.cf_mat_tier matches 10..46 run scoreboard players set @s ec.cf_recipe 100

# No match yet (standard recipes need both material + catalyst)
execute if score @s ec.cf_recipe matches 0 run return 0

# === RANK CHECKS ===
# Standard recipes
execute if score @s ec.cf_recipe matches 2 unless score @s ec.cf_rank matches 20.. run scoreboard players set @s ec.cf_recipe 0
execute if score @s ec.cf_recipe matches 2 unless score @s ec.cf_rank matches 20.. at @s run data modify entity @e[type=text_display,tag=CF.RecipeStatus,distance=..7,limit=1] text set value {text:"Requires Artisan Rank 20!",color:"red"}
execute if score @s ec.cf_recipe matches 0 run return 0

execute if score @s ec.cf_recipe matches 3 unless score @s ec.cf_rank matches 40.. run scoreboard players set @s ec.cf_recipe 0
execute if score @s ec.cf_recipe matches 3 unless score @s ec.cf_rank matches 40.. at @s run data modify entity @e[type=text_display,tag=CF.RecipeStatus,distance=..7,limit=1] text set value {text:"Requires Artisan Rank 40!",color:"red"}
execute if score @s ec.cf_recipe matches 0 run return 0

execute if score @s ec.cf_recipe matches 4 unless score @s ec.cf_rank matches 60.. run scoreboard players set @s ec.cf_recipe 0
execute if score @s ec.cf_recipe matches 4 unless score @s ec.cf_rank matches 60.. at @s run data modify entity @e[type=text_display,tag=CF.RecipeStatus,distance=..7,limit=1] text set value {text:"Requires Artisan Rank 60!",color:"red"}
execute if score @s ec.cf_recipe matches 0 run return 0

execute if score @s ec.cf_recipe matches 5 unless score @s ec.cf_rank matches 80.. run scoreboard players set @s ec.cf_recipe 0
execute if score @s ec.cf_recipe matches 5 unless score @s ec.cf_rank matches 80.. at @s run data modify entity @e[type=text_display,tag=CF.RecipeStatus,distance=..7,limit=1] text set value {text:"Requires Artisan Rank 80!",color:"red"}
execute if score @s ec.cf_recipe matches 0 run return 0

# Artifact material rank checks (T1=Rank 1, T2=10, T3=20, T4=35, T5=50, T6=70, T7=90)
execute if score @s ec.cf_recipe matches 100 if score @s ec.cf_art_tier matches 2 unless score @s ec.cf_rank matches 10.. run scoreboard players set @s ec.cf_recipe 0
execute if score @s ec.cf_recipe matches 0 if score @s ec.cf_art_tier matches 2 at @s run data modify entity @e[type=text_display,tag=CF.RecipeStatus,distance=..7,limit=1] text set value {text:"Requires Artisan Rank 10!",color:"red"}
execute if score @s ec.cf_recipe matches 0 if score @s ec.cf_art_tier matches 2 run return 0

execute if score @s ec.cf_recipe matches 100 if score @s ec.cf_art_tier matches 3 unless score @s ec.cf_rank matches 20.. run scoreboard players set @s ec.cf_recipe 0
execute if score @s ec.cf_recipe matches 0 if score @s ec.cf_art_tier matches 3 at @s run data modify entity @e[type=text_display,tag=CF.RecipeStatus,distance=..7,limit=1] text set value {text:"Requires Artisan Rank 20!",color:"red"}
execute if score @s ec.cf_recipe matches 0 if score @s ec.cf_art_tier matches 3 run return 0

execute if score @s ec.cf_recipe matches 100 if score @s ec.cf_art_tier matches 4 unless score @s ec.cf_rank matches 35.. run scoreboard players set @s ec.cf_recipe 0
execute if score @s ec.cf_recipe matches 0 if score @s ec.cf_art_tier matches 4 at @s run data modify entity @e[type=text_display,tag=CF.RecipeStatus,distance=..7,limit=1] text set value {text:"Requires Artisan Rank 35!",color:"red"}
execute if score @s ec.cf_recipe matches 0 if score @s ec.cf_art_tier matches 4 run return 0

execute if score @s ec.cf_recipe matches 100 if score @s ec.cf_art_tier matches 5 unless score @s ec.cf_rank matches 50.. run scoreboard players set @s ec.cf_recipe 0
execute if score @s ec.cf_recipe matches 0 if score @s ec.cf_art_tier matches 5 at @s run data modify entity @e[type=text_display,tag=CF.RecipeStatus,distance=..7,limit=1] text set value {text:"Requires Artisan Rank 50!",color:"red"}
execute if score @s ec.cf_recipe matches 0 if score @s ec.cf_art_tier matches 5 run return 0

execute if score @s ec.cf_recipe matches 100 if score @s ec.cf_art_tier matches 6 unless score @s ec.cf_rank matches 70.. run scoreboard players set @s ec.cf_recipe 0
execute if score @s ec.cf_recipe matches 0 if score @s ec.cf_art_tier matches 6 at @s run data modify entity @e[type=text_display,tag=CF.RecipeStatus,distance=..7,limit=1] text set value {text:"Requires Artisan Rank 70!",color:"red"}
execute if score @s ec.cf_recipe matches 0 if score @s ec.cf_art_tier matches 6 run return 0

execute if score @s ec.cf_recipe matches 100 if score @s ec.cf_art_tier matches 7 unless score @s ec.cf_rank matches 90.. run scoreboard players set @s ec.cf_recipe 0
execute if score @s ec.cf_recipe matches 0 if score @s ec.cf_art_tier matches 7 at @s run data modify entity @e[type=text_display,tag=CF.RecipeStatus,distance=..7,limit=1] text set value {text:"Requires Artisan Rank 90!",color:"red"}
execute if score @s ec.cf_recipe matches 0 if score @s ec.cf_art_tier matches 7 run return 0

# Recipe matched — update state and display
scoreboard players set @s ec.cf_state 2

# Update recipe status line — standard
execute if score @s ec.cf_recipe matches 1 at @s run data modify entity @e[type=text_display,tag=CF.RecipeStatus,distance=..7,limit=1] text set value [{text:"Recipe: ",color:"gray"},{text:"Tempered Alloy",color:"white"}]
execute if score @s ec.cf_recipe matches 2 at @s run data modify entity @e[type=text_display,tag=CF.RecipeStatus,distance=..7,limit=1] text set value [{text:"Recipe: ",color:"gray"},{text:"Starforged Ingot",color:"blue"}]
execute if score @s ec.cf_recipe matches 3 at @s run data modify entity @e[type=text_display,tag=CF.RecipeStatus,distance=..7,limit=1] text set value [{text:"Recipe: ",color:"gray"},{text:"Dreamwrought Bar",color:"dark_purple"}]
execute if score @s ec.cf_recipe matches 4 at @s run data modify entity @e[type=text_display,tag=CF.RecipeStatus,distance=..7,limit=1] text set value [{text:"Recipe: ",color:"gray"},{text:"Eternal Essence",color:"gold"}]
execute if score @s ec.cf_recipe matches 5 at @s run data modify entity @e[type=text_display,tag=CF.RecipeStatus,distance=..7,limit=1] text set value [{text:"Recipe: ",color:"gray"},{text:"Soulbound Core",color:"white",bold:true}]

# Update recipe status line — artifact materials (show next tier or "Artifact Forge" for T7)
execute if score @s ec.cf_recipe matches 100 if score @s ec.cf_art_tier matches 1..6 at @s run function evercraft:craftforever/forging/recipes/show_artifact_recipe
execute if score @s ec.cf_recipe matches 100 if score @s ec.cf_art_tier matches 7 if score @s ec.cf_art_cat matches 1 at @s run data modify entity @e[type=text_display,tag=CF.RecipeStatus,distance=..7,limit=1] text set value [{text:"Recipe: ",color:"gray"},{text:"Weapon Artifact Forge",color:"#FF6666",bold:true}]
execute if score @s ec.cf_recipe matches 100 if score @s ec.cf_art_tier matches 7 if score @s ec.cf_art_cat matches 2 at @s run data modify entity @e[type=text_display,tag=CF.RecipeStatus,distance=..7,limit=1] text set value [{text:"Recipe: ",color:"gray"},{text:"Armor Artifact Forge",color:"#6699FF",bold:true}]
execute if score @s ec.cf_recipe matches 100 if score @s ec.cf_art_tier matches 7 if score @s ec.cf_art_cat matches 3 at @s run data modify entity @e[type=text_display,tag=CF.RecipeStatus,distance=..7,limit=1] text set value [{text:"Recipe: ",color:"gray"},{text:"Tool Artifact Forge",color:"#44BB44",bold:true}]
execute if score @s ec.cf_recipe matches 100 if score @s ec.cf_art_tier matches 7 if score @s ec.cf_art_cat matches 4 at @s run data modify entity @e[type=text_display,tag=CF.RecipeStatus,distance=..7,limit=1] text set value [{text:"Recipe: ",color:"gray"},{text:"Accessory Artifact Forge",color:"#FFAA00",bold:true}]

# Light up the forge button
execute at @s run data modify entity @e[type=text_display,tag=CF.ForgeText,distance=..7,limit=1] text set value {text:"[ Begin Forging ]",color:"gold",bold:true}

execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.chime master @s ~ ~ ~ 0.5 1.5
data modify storage evercraft:notify stage.c set value [{text:"Recipe matched! Click ",color:"green"},{text:"Begin Forging",color:"gold",bold:true},{text:" to start.",color:"green"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
