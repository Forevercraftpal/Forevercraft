# Apply Artisan Level bonus to artifact material forging
# +2% success rate per level to previous tier recipes
# Implemented as: for each 5 ranks, +1 quality to recipes from tiers below current art_tier
# Max bonus: rank/5 but capped at (art_tier - 1) * 2

# Calculate rank-based bonus: rank / 5
scoreboard players operation #lvl_bonus ec.cf_temp = @s ec.cf_rank
scoreboard players operation #lvl_bonus ec.cf_temp /= #cf_5 ec.cf_temp

# Cap based on art_tier (higher tiers benefit more from leveling)
# T1: no bonus (no previous tier)
# T2: cap at 2
# T3: cap at 4
# T4: cap at 6
# T5: cap at 8
# T6: cap at 10
# T7: cap at 12
execute if score @s ec.cf_art_tier matches 1 run scoreboard players set #lvl_bonus ec.cf_temp 0
execute if score @s ec.cf_art_tier matches 2 if score #lvl_bonus ec.cf_temp matches 3.. run scoreboard players set #lvl_bonus ec.cf_temp 2
execute if score @s ec.cf_art_tier matches 3 if score #lvl_bonus ec.cf_temp matches 5.. run scoreboard players set #lvl_bonus ec.cf_temp 4
execute if score @s ec.cf_art_tier matches 4 if score #lvl_bonus ec.cf_temp matches 7.. run scoreboard players set #lvl_bonus ec.cf_temp 6
execute if score @s ec.cf_art_tier matches 5 if score #lvl_bonus ec.cf_temp matches 9.. run scoreboard players set #lvl_bonus ec.cf_temp 8
execute if score @s ec.cf_art_tier matches 6 if score #lvl_bonus ec.cf_temp matches 11.. run scoreboard players set #lvl_bonus ec.cf_temp 10
execute if score @s ec.cf_art_tier matches 7 if score #lvl_bonus ec.cf_temp matches 13.. run scoreboard players set #lvl_bonus ec.cf_temp 12

# Apply bonus
scoreboard players operation @s ec.cf_quality += #lvl_bonus ec.cf_temp
data modify storage evercraft:notify stage.c set value [{text:"Artisan Mastery: ",color:"gold"},{text:"+",color:"yellow"},{score:{name:"#lvl_bonus",objective:"ec.cf_temp"},color:"yellow"},{text:" quality from experience",color:"yellow"}]
scoreboard players set #ndur ec.temp 45
execute if score #lvl_bonus ec.cf_temp matches 1.. run function evercraft:util/notify/emit
