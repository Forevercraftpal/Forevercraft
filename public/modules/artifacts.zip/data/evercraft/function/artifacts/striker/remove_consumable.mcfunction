# Remove consumable component from mainhand striker mace
# Uses hopper_minecart intermediary (player item data is read-only in 1.21.5+)
# Run as player, at player
# Wiring Audit #5 W3b: hybrid per-player scope — tag-suffix on entity for selection,
# storage namespace for derived pid. Defends against 2-player same-tick item-swap race.

# Derive per-player id (cheap UUID surrogate via session counter) into storage; pass via macro.
execute store result storage evercraft:artifacts cart.pid int 1 run scoreboard players get @s adv.gui_session
function evercraft:artifacts/striker/remove_consumable_inner with storage evercraft:artifacts cart
