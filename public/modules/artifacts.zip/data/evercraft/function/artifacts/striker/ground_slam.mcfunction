# Striker — Ground Slam
# Sneaking + hit while grounded = AoE centered on PLAYER (not target)
# Requires 25+ Impact, consumes all Impact
# At 75+ Impact: launches nearby enemies upward

# === STORE IMPACT LEVEL BEFORE CONSUMING ===
scoreboard players operation #sk_stored_impact ec.var = @s ec.sk_impact

# === BOUGH C5 Ground Slam node: the slam also slows the foes it catches ===
execute if score @s ec.sk_n_c5 matches 1.. at @s as @e[type=#evercraft:aoe_targets,distance=..5] run effect give @s minecraft:slowness 3 1 true

# === ABILITY FX (here, NOT at the tail — the 75+/50-74 branches below return early) ===
# Generic rarity layer (common→rare, no-op at ornate+) + the bespoke "Tectonic" signature (ornate+,
# scaled by #sk_stored_impact). Channel-gated. Fires for ALL slam magnitudes.
scoreboard players operation #fx_tier ec.var = @s ec.sk_tier
execute at @s run function evercraft:fx/tier/proc
execute if score #fx_tier ec.var matches 4.. at @s run function evercraft:fx/bespoke/striker/slam

# === VOIDSHATTER (xara_hammer Wave 1-B) — here at the top so it fires for ALL slam magnitudes ===
# The Void Voyage's slam shatters body AND spirit: Shadow Shatter (AoE Weakness II) + Void Pulse
# (Levitation) on the aoe_targets in the slam zone. Gated on the xara_hammer being in mainhand. Radius
# matches the slam magnitude (7b at 75+, 5b at 50-74, 3b otherwise) — same selector as the slam damage.
execute if items entity @s weapon.mainhand *[custom_data~{artifact:"xara_hammer"}] if score #sk_stored_impact ec.var matches 75.. at @s as @e[type=#evercraft:aoe_targets,distance=..7] run function evercraft:artifacts/abilities/xara_voidshatter
execute if items entity @s weapon.mainhand *[custom_data~{artifact:"xara_hammer"}] if score #sk_stored_impact ec.var matches 50..74 at @s as @e[type=#evercraft:aoe_targets,distance=..5] run function evercraft:artifacts/abilities/xara_voidshatter
execute if items entity @s weapon.mainhand *[custom_data~{artifact:"xara_hammer"}] if score #sk_stored_impact ec.var matches ..49 at @s as @e[type=#evercraft:aoe_targets,distance=..3] run function evercraft:artifacts/abilities/xara_voidshatter

# === SET COOLDOWN BY TIER ===
execute if score @s ec.sk_tier matches 1 run scoreboard players set @s ec.sk_cd 18
execute if score @s ec.sk_tier matches 2 run scoreboard players set @s ec.sk_cd 15
execute if score @s ec.sk_tier matches 3 run scoreboard players set @s ec.sk_cd 12
execute if score @s ec.sk_tier matches 4 run scoreboard players set @s ec.sk_cd 10
execute if score @s ec.sk_tier matches 5 run scoreboard players set @s ec.sk_cd 8
execute if score @s ec.sk_tier matches 6 run scoreboard players set @s ec.sk_cd 6

# === BOUGH MASTERY HOOKS (Wave 37) ===
# M1 Earthtouch — Ground Slam cooldown -10s. Floor at 0 (cd_ready chain still
# fires next tick — turning cd negative would skip the visual "ready" pulse).
execute if score @s ec.sk_n_m1 matches 1.. run scoreboard players remove @s ec.sk_cd 10
execute if score @s ec.sk_n_m1 matches 1.. if score @s ec.sk_cd matches ..-1 run scoreboard players set @s ec.sk_cd 0
# M3 Quake Listen (pivot) — slam grants Slow Falling 5s. Spec's "reveal all
# ore within 10 blocks" needed an area-scan that doesn't pay for itself on
# every slam; the Slow Falling proxy reads as "earth holds its breath after
# the quake" and gives a movement payoff that stacks nicely with the AoE.
execute if score @s ec.sk_n_m3 matches 1.. run effect give @s minecraft:slow_falling 5 0 true

# === CONSUME ALL IMPACT ===
scoreboard players set @s ec.sk_impact 0

# === AFFINITY SETUP ===
tag @s add ec.aff_attacker
# Wiring Audit #5 W3a: stamp owner-id surrogate; mirror to #Search aff.id for the predicate filter.
scoreboard players operation @s ec.aff_owner_id = @s adv.gui_session
scoreboard players operation #Search aff.id = @s ec.aff_owner_id
data modify storage evercraft:affinity temp.damage_type set value "minecraft:mob_attack"

# === 75+ Impact: 7 block radius + launch upward ===
execute if score #sk_stored_impact ec.var matches 75.. run scoreboard players set #aff_base ec.temp 8
execute if score #sk_stored_impact ec.var matches 75.. if score @s ec.sk_n_c10 matches 1.. run scoreboard players add #aff_base ec.temp 3
execute if score #sk_stored_impact ec.var matches 75.. run function evercraft:affinity/boost_damage
execute if score #sk_stored_impact ec.var matches 75.. at @s as @e[type=#evercraft:aoe_targets,distance=..7] run function evercraft:affinity/deal_damage_typed with storage evercraft:affinity temp
execute if score #sk_stored_impact ec.var matches 75.. at @s as @e[type=#evercraft:aoe_targets,distance=..7] run effect give @s levitation 1 10 false
execute if score #sk_stored_impact ec.var matches 75.. at @s run particle explosion ~ ~0.5 ~ 3.5 0.3 3.5 0.1 15
execute if score #sk_stored_impact ec.var matches 75.. run tag @s remove ec.aff_attacker
execute if score #sk_stored_impact ec.var matches 75.. run return 1

# === 50-74 Impact: 5 block radius ===
execute if score #sk_stored_impact ec.var matches 50..74 run scoreboard players set #aff_base ec.temp 6
execute if score #sk_stored_impact ec.var matches 50..74 if score @s ec.sk_n_c10 matches 1.. run scoreboard players add #aff_base ec.temp 3
execute if score #sk_stored_impact ec.var matches 50..74 run function evercraft:affinity/boost_damage
execute if score #sk_stored_impact ec.var matches 50..74 at @s as @e[type=#evercraft:aoe_targets,distance=..5] run function evercraft:affinity/deal_damage_typed with storage evercraft:affinity temp
execute if score #sk_stored_impact ec.var matches 50..74 at @s run particle explosion ~ ~0.5 ~ 2.5 0.3 2.5 0.1 10
execute if score #sk_stored_impact ec.var matches 50..74 run tag @s remove ec.aff_attacker
execute if score #sk_stored_impact ec.var matches 50..74 run return 1

# === 25-49 Impact: 3 block radius ===
scoreboard players set #aff_base ec.temp 4
execute if score @s ec.sk_n_c10 matches 1.. run scoreboard players add #aff_base ec.temp 3
function evercraft:affinity/boost_damage
execute at @s as @e[type=#evercraft:aoe_targets,distance=..3] run function evercraft:affinity/deal_damage_typed with storage evercraft:affinity temp
execute at @s run particle explosion ~ ~0.5 ~ 1.5 0.3 1.5 0.1 8

# === VISUAL + AUDIO (always) ===
execute at @s as @a[distance=..20] if score @s ec.fx_snd matches 1.. run playsound minecraft:block.anvil.land player @s ~ ~ ~ 1.0 0.3
execute at @s as @a[distance=..20] if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.generic.explode player @s ~ ~ ~ 0.8 0.5
data modify storage evercraft:notify stage.c set value [{text:"Ground Slam!",color:"gold",bold:true}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
tag @s remove ec.aff_attacker

# (Ability FX moved to the top — see "ABILITY FX" near STORE IMPACT — so it fires for all magnitudes.)

# Achievement tracking
scoreboard players add @s ach.weapon_abilities 1
