# Macro inner: per-player hopper_minecart consumable strip.
# Args from storage evercraft:artifacts cart:
#   pid = per-player session-counter (cheap UUID surrogate; collision-resistant within a session)
# Wiring Audit #5 W3b — paired with remove_consumable.mcfunction (outer derives pid).

$execute at @s run summon hopper_minecart ~ ~ ~ {Tags:["ec.temp_cart","ec.temp_cart.$(pid)"]}
$item replace entity @e[type=hopper_minecart,tag=ec.temp_cart.$(pid),limit=1] container.0 from entity @s weapon.mainhand
$data remove entity @e[type=hopper_minecart,tag=ec.temp_cart.$(pid),limit=1] Items[0].components."minecraft:consumable"
$item replace entity @s weapon.mainhand from entity @e[type=hopper_minecart,tag=ec.temp_cart.$(pid),limit=1] container.0
$item replace entity @e[type=hopper_minecart,tag=ec.temp_cart.$(pid),limit=1] container.0 with minecraft:air
$kill @e[type=hopper_minecart,tag=ec.temp_cart.$(pid)]
