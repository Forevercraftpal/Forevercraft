# Striker — On-hit router
# Triggered by player_hurt_entity advancement

# Re-arm advancement
advancement revoke @s only evercraft:artifacts/striker/on_hit_trigger

# Verify still holding striker mace
execute unless items entity @s weapon.mainhand mace[custom_data~{striker:true}] run return 0

# === IMPACT GAIN: +8 on hit ===
scoreboard players add @s ec.sk_impact 8

# === REFRESH COMBAT TIMER (5 seconds = 100 ticks) ===
scoreboard players set @s ec.sk_combat 100

# === BOUGH STRIKER COMBAT TREE (on-hit riders) ===
# Guard `unless ec.aff_attacker` so the nested re-fires from rider/slam AoE damage skip it
# (quake/hit sets ec.aff_attacker around its own bonus damage to suppress recursion).
execute if score @s ec.sk_b_combat matches 1.. unless entity @s[tag=ec.aff_attacker] at @s run function evercraft:bough/striker/quake/hit

# === BOUGH CROWN: EARTHBREAK 5TH STRIKE (Wave 13) ===
# Self-gates on ec.sk_b_crown — cheap no-op for non-crown strikers. The
# `unless ec.aff_attacker` guard skips nested rewards: slam/ability AoE damage
# is dealt `by` the player (affinity/deal_damage*), which re-fires this very
# function per target WHILE the tag is up — counting those would chain-arm
# slams on crowds. On the 5th strike crown_strike fires a FREE Ground Slam and
# supersedes the paid fortress/slam checks below for that hit (it re-applies
# the Impact caps itself before returning).
execute if score @s ec.sk_b_crown matches 1.. unless entity @s[tag=ec.aff_attacker] run scoreboard players add @s ec.sk_strike_count 1
execute if score @s ec.sk_b_crown matches 1.. unless entity @s[tag=ec.aff_attacker] if score @s ec.sk_strike_count matches 5.. run return run function evercraft:bough/striker/crown_strike

# === CHECK: SENTINEL FORTRESS (sneaking + 50+ Impact + off cooldown) ===
# Uses return run to guarantee exit after fortress fires (prevents double-fire with ground slam)
execute if entity @s[tag=ec.sk_sentinel] if predicate evercraft:sneaking if predicate evercraft:on_ground if score @s ec.sk_impact matches 50.. if score @s ec.sk_fort_cd matches ..-1 run return run function evercraft:artifacts/striker/fortress

# === CHECK: GROUND SLAM (sneaking + grounded + 25+ Impact + off cooldown) ===
execute if predicate evercraft:sneaking if predicate evercraft:on_ground if score @s ec.sk_impact matches 25.. if score @s ec.sk_cd matches ..-1 run return run function evercraft:artifacts/striker/ground_slam

# === IMPACT STRIKE: Now activated via right-click (impact_use.mcfunction) ===

# Cap Impact
execute if entity @s[tag=!ec.sk_sentinel] if score @s ec.sk_impact matches 101.. run scoreboard players set @s ec.sk_impact 100
execute if entity @s[tag=ec.sk_sentinel] if score @s ec.sk_impact matches 76.. run scoreboard players set @s ec.sk_impact 75
