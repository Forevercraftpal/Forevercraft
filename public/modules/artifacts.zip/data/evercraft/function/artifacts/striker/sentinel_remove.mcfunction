# Sentinel Removal — Shield removed from offhand
# Run as player who was ec.sk_sentinel but lost their shield

tag @s remove ec.sk_sentinel

# Add consumable back to mace for right-click impact
item modify entity @s weapon.mainhand evercraft:add_striker_consumable

# Clear Resistance and Weakness (natural expiry from 2s duration, but clear for instant feedback)
effect clear @s resistance
effect clear @s weakness

execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.anvil.land player @s ~ ~ ~ 0.5 0.8
data modify storage evercraft:notify stage.c set value [{text:"Striker Mode",color:"gold",bold:true},{text:" — active",color:"yellow",bold:false}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
