# Striker — Empowered Impact Strike
# Consumes all Impact for AoE bonus damage
# Run as player with ec.sk_impact >= 25, activated via right-click

# === AFFINITY SETUP ===
tag @s add ec.aff_attacker
# Wiring Audit #5 W3a: stamp owner-id surrogate; mirror to #Search aff.id for the predicate filter.
scoreboard players operation @s ec.aff_owner_id = @s adv.gui_session
scoreboard players operation #Search aff.id = @s ec.aff_owner_id
data modify storage evercraft:affinity temp.damage_type set value "minecraft:mob_attack"

# === CATACLYSM (100+) ===
execute if score @s ec.sk_impact matches 100.. run scoreboard players set #aff_base ec.temp 30
execute if score @s ec.sk_impact matches 100.. run function evercraft:affinity/boost_damage
execute if score @s ec.sk_impact matches 100.. at @s as @e[type=#evercraft:aoe_targets,distance=..10] run function evercraft:affinity/deal_damage_typed with storage evercraft:affinity temp
execute if score @s ec.sk_impact matches 100.. at @s as @e[type=#evercraft:aoe_targets,distance=..10] run effect give @s slowness 5 2 false
execute if score @s ec.sk_impact matches 100.. at @s as @e[type=#evercraft:aoe_targets,distance=..10] run effect give @s mining_fatigue 5 1 false
execute if score @s ec.sk_impact matches 100.. at @s run particle explosion ~ ~0.5 ~ 5 0.3 5 0.1 15
execute if score @s ec.sk_impact matches 100.. at @s as @a[distance=..30] if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.generic.explode player @s ~ ~ ~ 1.0 0.4
data modify storage evercraft:notify stage.c set value [{text:"CATACLYSM!",color:"dark_red",bold:true}]
scoreboard players set #ndur ec.temp 45
execute if score @s ec.sk_impact matches 100.. run function evercraft:util/notify/emit
execute if score @s ec.sk_impact matches 100.. run scoreboard players set @s ec.sk_impact 0
execute if score @s ec.sk_impact matches 0 run tag @s remove ec.aff_attacker
execute if score @s ec.sk_impact matches 0 run return 0

# === SHATTER (75-99) ===
execute if score @s ec.sk_impact matches 75.. run scoreboard players set #aff_base ec.temp 20
execute if score @s ec.sk_impact matches 75.. run function evercraft:affinity/boost_damage
execute if score @s ec.sk_impact matches 75.. at @s as @e[type=#evercraft:aoe_targets,distance=..7] run function evercraft:affinity/deal_damage_typed with storage evercraft:affinity temp
execute if score @s ec.sk_impact matches 75.. at @s as @e[type=#evercraft:aoe_targets,distance=..7] run effect give @s slowness 5 1 false
execute if score @s ec.sk_impact matches 75.. at @s run particle explosion ~ ~0.5 ~ 3.5 0.3 3.5 0.1 10
execute if score @s ec.sk_impact matches 75.. at @s as @a[distance=..25] if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.generic.explode player @s ~ ~ ~ 0.8 0.5
data modify storage evercraft:notify stage.c set value [{text:"Shatter!",color:"light_purple",bold:true}]
scoreboard players set #ndur ec.temp 45
execute if score @s ec.sk_impact matches 75.. run function evercraft:util/notify/emit
execute if score @s ec.sk_impact matches 75.. run scoreboard players set @s ec.sk_impact 0
execute if score @s ec.sk_impact matches 0 run tag @s remove ec.aff_attacker
execute if score @s ec.sk_impact matches 0 run return 0

# === QUAKE (50-74) ===
execute if score @s ec.sk_impact matches 50.. run scoreboard players set #aff_base ec.temp 10
execute if score @s ec.sk_impact matches 50.. run function evercraft:affinity/boost_damage
execute if score @s ec.sk_impact matches 50.. at @s as @e[type=#evercraft:aoe_targets,distance=..5] run function evercraft:affinity/deal_damage_typed with storage evercraft:affinity temp
execute if score @s ec.sk_impact matches 50.. at @s as @e[type=#evercraft:aoe_targets,distance=..5] run effect give @s slowness 3 0 false
execute if score @s ec.sk_impact matches 50.. at @s run particle explosion ~ ~0.5 ~ 2.5 0.3 2.5 0.1 8
execute if score @s ec.sk_impact matches 50.. at @s as @a[distance=..20] if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.generic.explode player @s ~ ~ ~ 0.6 0.7
data modify storage evercraft:notify stage.c set value [{text:"Quake!",color:"aqua",bold:true}]
scoreboard players set #ndur ec.temp 45
execute if score @s ec.sk_impact matches 50.. run function evercraft:util/notify/emit
execute if score @s ec.sk_impact matches 50.. run scoreboard players set @s ec.sk_impact 0
execute if score @s ec.sk_impact matches 0 run tag @s remove ec.aff_attacker
execute if score @s ec.sk_impact matches 0 run return 0

# === TREMOR (25-49) ===
scoreboard players set #aff_base ec.temp 5
function evercraft:affinity/boost_damage
execute at @s as @e[type=#evercraft:aoe_targets,distance=..3] run function evercraft:affinity/deal_damage_typed with storage evercraft:affinity temp
# Knockback (0.4 blocks per step, stops at solid blocks)
# Wiring Audit #5 R-P1-1: `facing entity @p feet` → swinger-scoped via predicate (avoids cross-player @p mis-direction).
execute at @s run tag @e[type=#evercraft:aoe_targets,distance=..3] add ec.kb
execute as @e[tag=ec.kb] at @s facing entity @a[tag=ec.aff_attacker,predicate=evercraft:artifacts/check_owner,limit=1] feet positioned ^ ^ ^-0.4 if block ~ ~ ~ #minecraft:replaceable if block ~ ~1 ~ #minecraft:replaceable run tp @s ~ ~ ~
execute as @e[tag=ec.kb] at @s facing entity @a[tag=ec.aff_attacker,predicate=evercraft:artifacts/check_owner,limit=1] feet positioned ^ ^ ^-0.4 if block ~ ~ ~ #minecraft:replaceable if block ~ ~1 ~ #minecraft:replaceable run tp @s ~ ~ ~
execute as @e[tag=ec.kb] at @s facing entity @a[tag=ec.aff_attacker,predicate=evercraft:artifacts/check_owner,limit=1] feet positioned ^ ^ ^-0.4 if block ~ ~ ~ #minecraft:replaceable if block ~ ~1 ~ #minecraft:replaceable run tp @s ~ ~ ~
# Wall-slam bonus (kinetic): tremor-knocked mobs flush against a wall take bonus damage
# Direction is swinger-scoped via the ec.aff_attacker predicate (Audit #5); credit needs ec.kin_attacker
# so slam_apply's `by @a[tag=ec.kin_attacker,limit=1]` attributes the slam to the swinger, not @p.
scoreboard players set #kin_force ec.var 32
tag @s add ec.kin_attacker
execute as @e[tag=ec.kb] at @s facing entity @a[tag=ec.aff_attacker,predicate=evercraft:artifacts/check_owner,limit=1] feet positioned ^ ^ ^-0.4 unless block ~ ~ ~ #minecraft:replaceable run function evercraft:kinetic/slam_mob
execute as @e[tag=ec.kb] at @s facing entity @a[tag=ec.aff_attacker,predicate=evercraft:artifacts/check_owner,limit=1] feet positioned ^ ^ ^-0.4 if block ~ ~ ~ #minecraft:replaceable unless block ~ ~1 ~ #minecraft:replaceable run function evercraft:kinetic/slam_mob
tag @s remove ec.kin_attacker
tag @e[tag=ec.kb] remove ec.kb
execute at @s run particle explosion ~ ~0.5 ~ 1.5 0.2 1.5 0.1 5
execute at @s as @a[distance=..15] if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.generic.explode player @s ~ ~ ~ 0.4 0.9
data modify storage evercraft:notify stage.c set value [{text:"Tremor!",color:"green",bold:true}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
scoreboard players set @s ec.sk_impact 0
tag @s remove ec.aff_attacker
