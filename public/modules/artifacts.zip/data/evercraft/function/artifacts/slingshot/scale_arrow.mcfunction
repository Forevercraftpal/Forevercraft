# Slingshot — Scale Arrow Motion ×1.4 (Swift Shot)
# Run as @s = the freshly-loosed arrow (captured by on_fire). Reads each Motion axis as an integer
# scaled ×1000, then writes it back ×0.0014 (= original ×1.4). Same store-result-to-Motion idiom as
# artifacts/graviton_core/deflect_projectile. Marks the arrow ec.sl_boosted so it is never re-scaled.
tag @s add ec.sl_boosted

# X
execute store result score #sl_m ec.temp run data get entity @s Motion[0] 1000
execute store result entity @s Motion[0] double 0.0014 run scoreboard players get #sl_m ec.temp
# Y
execute store result score #sl_m ec.temp run data get entity @s Motion[1] 1000
execute store result entity @s Motion[1] double 0.0014 run scoreboard players get #sl_m ec.temp
# Z
execute store result score #sl_m ec.temp run data get entity @s Motion[2] 1000
execute store result entity @s Motion[2] double 0.0014 run scoreboard players get #sl_m ec.temp
