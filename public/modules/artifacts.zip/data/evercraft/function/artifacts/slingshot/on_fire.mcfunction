# Slingshot — On Fire (draw stopped → arrow released)
# Run as @s = player; called from main tick when ec.sl_stale >= 2 (player let go of the draw).
# Scales the just-loosed arrow's Motion ×1.4 so it flies faster (Swift Shot). The arrow is tagged
# ec.sl_boosted so it is processed exactly once. Strictly gated: this fn only runs for a player who
# WAS drawing a slingshot, and only acts on a still-untagged arrow within 2 blocks (just fired) —
# the same nearest-fresh-arrow capture the archer overcharge uses (artifacts/archer/on_fire).

# Reset the draw state so this fires only once per shot.
scoreboard players set @s ec.sl_draw 0
scoreboard players set @s ec.sl_stale 0

# Confirm a fresh, untagged arrow exists within 2 blocks before doing any Motion math (existence gate).
execute at @s unless entity @e[type=arrow,tag=!ec.sl_boosted,distance=..2] run return 0

# Tag the nearest fresh arrow so it's boosted exactly once (distance ..2 defends against capturing
# a neighbouring shooter's arrow, same tightening as archer on_fire).
execute at @s run tag @e[type=arrow,tag=!ec.sl_boosted,distance=..2,sort=nearest,limit=1] add ec.sl_boost_now

# Scale the captured arrow's Motion ×1.4 (read each axis ×1000 into ec.temp, write back ×0.0014).
execute as @e[tag=ec.sl_boost_now,limit=1] run function evercraft:artifacts/slingshot/scale_arrow

# Done — drop the transient capture tag.
tag @e[tag=ec.sl_boost_now] remove ec.sl_boost_now
