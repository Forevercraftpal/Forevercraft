# Slingshot — Draw Tick
# Called by the using_item advancement EVERY tick while drawing a slingshot (custom_data slingshot:true)
advancement revoke @s only evercraft:artifacts/slingshot/draw

# Latch "currently drawing" and reset the stale counter (mirrors archer/draw_tick).
# Main tick increments ec.sl_stale; when the player STOPS drawing (arrow released) the latch goes
# stale and on_fire fires once to boost the just-loosed arrow.
scoreboard players set @s ec.sl_draw 1
scoreboard players set @s ec.sl_stale 0
