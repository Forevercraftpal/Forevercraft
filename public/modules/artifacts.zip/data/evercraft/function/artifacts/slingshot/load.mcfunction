# Slingshot (common) — Swift Shot velocity boost — Load
# The Slingshot is a minecraft:bow base, so the crossbow-only Quick Charge enchant was inert.
# Instead we boost the VELOCITY of arrows it fires (×1.4) — there is no bow draw-speed attribute.
# Mirrors the archer overcharge draw→stale→on_fire release-detection idiom (see artifacts/archer),
# but minimal: no overcharge, no cooldowns — just tag the freshly-loosed arrow and scale its Motion.

# === SCOREBOARDS ===
# ec.sl_draw  — per-tick draw latch, set by the using_item advancement reward (draw_tick)
# ec.sl_stale — release detector; incremented in main tick, fires on_fire at >=2 (player let go)
scoreboard objectives add ec.sl_draw dummy "Slingshot Draw Latch"
scoreboard objectives add ec.sl_stale dummy "Slingshot Stale Counter"
