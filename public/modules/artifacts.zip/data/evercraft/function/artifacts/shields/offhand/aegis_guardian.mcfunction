# Vanguard Shield (aegis_guardian) — "Guardian's Spite"
# AoE 2 damage to enemies within 3 blocks + Resistance I (3s) to self, 20s CD.
# Mirrors the dragonslayer_shield / drowned_king_shield offhand template (at @s AoE + self-buff + cd + notify).

# AoE damage to nearby hostile mobs
execute at @s as @e[type=!player,type=!item,distance=..3,limit=8,sort=nearest] run damage @s 2 evercraft:bonus_strike

# Resistance to self
effect give @s resistance 3 0 false

# Particles + sound
execute at @s run particle crit ~ ~0.5 ~ 1.2 0.5 1.2 0.1 14
execute at @s run particle enchanted_hit ~ ~1 ~ 1.0 0.4 1.0 0.05 8
execute at @s as @a if score @s ec.fx_snd matches 1.. run playsound minecraft:block.amethyst_block.resonate master @s ~ ~ ~ 0.8 0.6
execute at @s if score @s ec.fx_snd matches 1.. run playsound minecraft:item.shield.block master @s ~ ~ ~ 0.6 1.0

# Set cooldown
scoreboard players set @s ec.tk_off_cd 20

# Actionbar feedback
data modify storage evercraft:notify stage.c set value [{text:"Guardian's Spite!",color:"aqua",bold:true}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
