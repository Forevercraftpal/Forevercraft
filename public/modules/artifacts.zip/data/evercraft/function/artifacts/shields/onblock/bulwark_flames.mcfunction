# Burning Skull (bulwark_flames) — On-Block: Ignite Attackers
# Run as @s = blocking player. Sets nearby attacker(s) on fire + brief Fire Resistance to self.
# Makes the "On Block: Ignite attackers" lore literally true. Mirrors fire_thorns' ignite + fire_res.
execute at @s as @e[type=#evercraft:hostile_mobs,distance=..3,limit=4,nbt={HurtTime:0s}] run data merge entity @s {Fire:60s}
effect give @s fire_resistance 4 0 false
execute at @s run particle flame ~ ~1 ~ 0.4 0.5 0.4 0.03 8
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:item.firecharge.use player @s ~ ~ ~ 0.6 1.2
