# Tower Shield / Ocean Tower Shield — On-Block: Fortify
# Run as @s = blocking player. Brief Resistance I — the feasible cousin of "50% damage reduction".
# Makes the "On Block: Fortify (Resistance)" lore literally true. Mirrors fortified_defense.
effect give @s resistance 3 0 false
execute at @s run particle enchant ~ ~1 ~ 0.3 0.5 0.3 0.4 6
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:item.shield.block player @s ~ ~ ~ 0.8 1
