# Shield Block — Rare: Counter Stance
# Empowers counter-attack after blocking
effect give @s strength 3 0 false
execute at @s run particle crit ~ ~1 ~ 0.3 0.5 0.3 0.1 5
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:item.shield.block master @s ~ ~ ~ 0.8 1.2
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.player.attack.strong master @s ~ ~ ~ 0.4 0.8

# Per-shield themed on-block effect (the lore made literally true). Branch by artifact id —
# check both hands (shield may be main- or off-hand). Each themed effect mirrors the shield's
# matching on-HIT handler (thorns_block / fire_thorns / fortified_defense) but fires ON BLOCK.
# Generic tier Strength above remains as the baseline counter-stance perk.

# Vanguard Shield (aegis_guardian) — Thorns: reflect 3 dmg to nearby attackers (mirrors thorns_block)
execute if items entity @s weapon.mainhand minecraft:shield[custom_data~{artifact:"aegis_guardian"}] run function evercraft:artifacts/shields/onblock/aegis_guardian
execute unless items entity @s weapon.mainhand minecraft:shield[custom_data~{artifact:"aegis_guardian"}] if items entity @s weapon.offhand minecraft:shield[custom_data~{artifact:"aegis_guardian"}] run function evercraft:artifacts/shields/onblock/aegis_guardian

# Burning Skull (bulwark_flames) — Fire: ignite nearby attackers + brief Fire Resistance (mirrors fire_thorns)
execute if items entity @s weapon.mainhand minecraft:shield[custom_data~{artifact:"bulwark_flames"}] run function evercraft:artifacts/shields/onblock/bulwark_flames
execute unless items entity @s weapon.mainhand minecraft:shield[custom_data~{artifact:"bulwark_flames"}] if items entity @s weapon.offhand minecraft:shield[custom_data~{artifact:"bulwark_flames"}] run function evercraft:artifacts/shields/onblock/bulwark_flames

# Tower Shield (tower_shield) — Fortify: brief Resistance I (mirrors fortified_defense)
execute if items entity @s weapon.mainhand minecraft:shield[custom_data~{artifact:"tower_shield"}] run function evercraft:artifacts/shields/onblock/fortify
execute unless items entity @s weapon.mainhand minecraft:shield[custom_data~{artifact:"tower_shield"}] if items entity @s weapon.offhand minecraft:shield[custom_data~{artifact:"tower_shield"}] run function evercraft:artifacts/shields/onblock/fortify

# Ocean Tower Shield (ocean_tower_shield) — Fortify: brief Resistance I (same as tower_shield per lore)
execute if items entity @s weapon.mainhand minecraft:shield[custom_data~{artifact:"ocean_tower_shield"}] run function evercraft:artifacts/shields/onblock/fortify
execute unless items entity @s weapon.mainhand minecraft:shield[custom_data~{artifact:"ocean_tower_shield"}] if items entity @s weapon.offhand minecraft:shield[custom_data~{artifact:"ocean_tower_shield"}] run function evercraft:artifacts/shields/onblock/fortify

# Generic tier-FX layer (common→rare; ornate+ no-ops for a future bespoke preset). Channel-gated.
# Tier is the block file's own rarity (slot-agnostic — shield may be main- or off-hand).
scoreboard players set #fx_tier ec.var 3
execute at @s run function evercraft:fx/tier/proc
