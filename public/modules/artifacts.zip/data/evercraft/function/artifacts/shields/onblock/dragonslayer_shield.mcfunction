# Dragonslayer Shield (dragonslayer_shield) — On-Block: Flame Ward
# Run as @s = blocking player. Ignites nearby attacker(s) + Fire Resistance to self.
# Makes the "On Block: Ignite attackers + Fire Resistance" lore literally true. Mirrors flame_ward.
execute at @s as @e[type=#evercraft:hostile_mobs,distance=..4,limit=4,nbt={HurtTime:0s}] run data merge entity @s {Fire:60s}
effect give @s fire_resistance 6 0 false
execute at @s run particle flame ~ ~1 ~ 0.5 0.6 0.5 0.03 10
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:item.firecharge.use player @s ~ ~ ~ 0.6 1
