# Shield Offhand Ability — Route to specific shield's ability
# Runs as player with tank shield in offhand + sneaking

# Cooldown check
data modify storage evercraft:notify stage.c set value [{text:"Shield ability recharging...",color:"red",italic:true}]
scoreboard players set #ndur ec.temp 45
execute if score @s ec.tk_off_cd matches 1.. run return run function evercraft:util/notify/emit

# Route by artifact ID (check artifact key first, then weapon key)
execute if items entity @s weapon.offhand minecraft:shield[custom_data~{artifact:"common_deku_shield"}] run return run function evercraft:artifacts/shields/offhand/deku_shield
execute if items entity @s weapon.offhand minecraft:shield[custom_data~{artifact:"uncommon_chargin_targe"}] run return run function evercraft:artifacts/shields/offhand/chargin_targe
execute if items entity @s weapon.offhand minecraft:shield[custom_data~{artifact:"tower_shield"}] run return run function evercraft:artifacts/shields/offhand/tower_shield
execute if items entity @s weapon.offhand minecraft:shield[custom_data~{artifact:"dragonslayer_shield"}] run return run function evercraft:artifacts/shields/offhand/dragonslayer_shield
execute if items entity @s weapon.offhand minecraft:shield[custom_data~{artifact:"dragonmaster_shield"}] run return run function evercraft:artifacts/shields/offhand/dragonmaster_shield
execute if items entity @s weapon.offhand minecraft:shield[custom_data~{artifact:"golden_goliath_shield"}] run return run function evercraft:artifacts/shields/offhand/golden_goliath_shield
execute if items entity @s weapon.offhand minecraft:shield[custom_data~{artifact:"command_block_shield"}] run return run function evercraft:artifacts/shields/offhand/command_block_shield
execute if items entity @s weapon.offhand minecraft:shield[custom_data~{artifact:"drowned_king_shield"}] run return run function evercraft:artifacts/shields/offhand/drowned_king_shield
# Rare tank shields (id-mismatch wire: the handler/effect existed but no router line named them)
execute if items entity @s weapon.offhand minecraft:shield[custom_data~{artifact:"aegis_guardian"}] run return run function evercraft:artifacts/shields/offhand/aegis_guardian
execute if items entity @s weapon.offhand minecraft:shield[custom_data~{artifact:"bulwark_flames"}] run return run function evercraft:artifacts/shields/offhand/bulwark_flames
# Ocean Tower Shield "Fortify" (Res II + Slowness I 5s) == the tower_shield handler exactly (per loot lore) — reuse it
execute if items entity @s weapon.offhand minecraft:shield[custom_data~{artifact:"ocean_tower_shield"}] run return run function evercraft:artifacts/shields/offhand/tower_shield

# Biome artifact shields
execute if items entity @s weapon.offhand minecraft:shield[custom_data~{weapon:"trial_shield"}] run return run function evercraft:artifacts/shields/offhand/trial_shield
