# Shield Block — Exquisite: Arcane Ward
# Protective ward absorbs damage and regenerates
effect give @s absorption 4 1 false
effect give @s regeneration 4 0 false
execute at @s run particle enchanted_hit ~ ~1 ~ 0.4 0.6 0.4 0.3 6
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:item.shield.block master @s ~ ~ ~ 0.9 1.1
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.enchantment_table.use master @s ~ ~ ~ 0.4 1.6

# Per-shield themed on-block effect. Dragonslayer Shield (dragonslayer_shield) — Flame Ward:
# ignite nearby attackers + brief Fire Resistance (mirrors its flame_ward on-HIT handler, but ON BLOCK).
# Generic tier Absorption/Regen above remains as the baseline ward.
execute if items entity @s weapon.mainhand minecraft:shield[custom_data~{artifact:"dragonslayer_shield"}] run function evercraft:artifacts/shields/onblock/dragonslayer_shield
execute unless items entity @s weapon.mainhand minecraft:shield[custom_data~{artifact:"dragonslayer_shield"}] if items entity @s weapon.offhand minecraft:shield[custom_data~{artifact:"dragonslayer_shield"}] run function evercraft:artifacts/shields/onblock/dragonslayer_shield
