# Burning Skull (bulwark_flames) — "Infernal Pulse"
# AoE fire damage (2) to enemies within 3 blocks + ignite + Fire Resistance (4s) to self, 20s CD.
# Mirrors the dragonslayer_shield offhand template (at @s fire AoE + self-buff + cd + notify).

# AoE fire damage to nearby hostile mobs + ignite
execute at @s as @e[type=!player,type=!item,distance=..3,limit=8,sort=nearest] run damage @s 2 minecraft:in_fire
execute at @s as @e[type=!player,type=!item,distance=..3,limit=8,sort=nearest] run data merge entity @s {Fire:60s}

# Fire Resistance to self
effect give @s fire_resistance 4 0 false

# Particles + sound
execute at @s run particle flame ~ ~0.5 ~ 1.2 0.5 1.2 0.08 15
execute at @s run particle smoke ~ ~0.3 ~ 0.9 0.3 0.9 0.05 8
execute at @s as @a if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.blaze.shoot master @s ~ ~ ~ 0.8 0.8
execute at @s if score @s ec.fx_snd matches 1.. run playsound minecraft:item.shield.block master @s ~ ~ ~ 0.6 1.0

# Set cooldown
scoreboard players set @s ec.tk_off_cd 20

# Actionbar feedback
data modify storage evercraft:notify stage.c set value [{text:"Infernal Pulse!",color:"red",bold:true}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
