# Shield Block — Mythical: Titan's Resolve
# Massive defensive surge + empowered counter + party aura
effect give @s absorption 5 2 false
effect give @s strength 5 0 false
execute at @s run particle end_rod ~ ~1 ~ 0.5 0.8 0.5 0.05 8
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:item.shield.block master @s ~ ~ ~ 1.0 1.0
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.beacon.activate master @s ~ ~ ~ 0.3 1.8

# Party aura — nearby allies get Absorption I
execute at @s as @a[distance=0.1..8,tag=ec.in_party] run effect give @s absorption 3 0 false

# Order of the Stone Shield — Titan's Guard: thorns retaliation on block (hurts attackers in 3b).
# (Replaces the old dead "reflect 50%" claim with a real thorns counter; the elderguard/damage_reflect idiom.)
execute if items entity @s weapon.mainhand minecraft:shield[custom_data~{artifact:"golden_goliath_shield"}] at @s as @e[type=#evercraft:hostile_mobs,distance=..3,nbt={HurtTime:0s}] run damage @s 3 minecraft:thorns
execute if items entity @s weapon.offhand minecraft:shield[custom_data~{artifact:"golden_goliath_shield"}] at @s as @e[type=#evercraft:hostile_mobs,distance=..3,nbt={HurtTime:0s}] run damage @s 3 minecraft:thorns
