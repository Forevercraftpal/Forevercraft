# Golden Goliath Shield — "Goliath's Fury"
# Haste 3 for 5 seconds, 20s cooldown

effect give @s haste 5 2 false

# Particles + sound
execute at @s run particle enchant ~ ~1 ~ 0.5 0.6 0.5 0.5 8
execute at @s run particle enchanted_hit ~ ~0.5 ~ 0.4 0.4 0.4 0.3 5
execute at @s if score @s ec.fx_snd matches 1.. run playsound minecraft:block.beacon.power_select master @s ~ ~ ~ 0.7 1.0
execute at @s if score @s ec.fx_snd matches 1.. run playsound minecraft:item.shield.block master @s ~ ~ ~ 0.6 1.3

# Set cooldown
scoreboard players set @s ec.tk_off_cd 20

# Actionbar feedback
data modify storage evercraft:notify stage.c set value [{text:"Goliath's Fury!",color:"yellow",bold:true}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
