# Shield Block — Common: Shield Brace
# Absorbs a small hit after a successful block
effect give @s absorption 4 0 false
execute at @s run particle enchant ~ ~1 ~ 0.3 0.5 0.3 0.3 4
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:item.shield.block master @s ~ ~ ~ 0.6 1.4

# Generic tier-FX layer (common→rare; ornate+ no-ops for a future bespoke preset). Channel-gated.
# Tier is the block file's own rarity (slot-agnostic — shield may be main- or off-hand).
scoreboard players set #fx_tier ec.var 1
execute at @s run function evercraft:fx/tier/proc
