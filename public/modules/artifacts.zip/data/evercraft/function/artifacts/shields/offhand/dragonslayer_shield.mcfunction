# Dragonslayer Shield — "Dragon's Breath"
# AoE fire damage (3) to enemies within 4 blocks + Fire Resistance 5s to self, 20s CD

# AoE fire damage to nearby hostile mobs
execute at @s as @e[type=!player,type=!item,distance=..4,limit=8,sort=nearest] run damage @s 3 minecraft:in_fire

# Fire Resistance to self
effect give @s fire_resistance 5 0 false

# Particles + sound
execute at @s run particle flame ~ ~0.5 ~ 1.5 0.5 1.5 0.08 15
execute at @s run particle smoke ~ ~0.3 ~ 1.0 0.3 1.0 0.05 8
execute at @s as @a if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.blaze.shoot master @s ~ ~ ~ 0.8 0.7
execute at @s if score @s ec.fx_snd matches 1.. run playsound minecraft:item.shield.block master @s ~ ~ ~ 0.6 1.0

# Set cooldown
scoreboard players set @s ec.tk_off_cd 20

# Actionbar feedback
data modify storage evercraft:notify stage.c set value [{text:"Dragon's Breath!",color:"gold",bold:true}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
