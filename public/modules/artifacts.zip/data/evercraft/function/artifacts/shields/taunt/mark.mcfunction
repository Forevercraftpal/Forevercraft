# Taunt Mark — runs AS the mob that was hit, with player context available
# Tags mob as taunted, stores owner ID and expiry gametime

# Tag mob as taunted
tag @s add ec.taunted

# Copy taunting player's ID to the mob
scoreboard players operation @s ec.tk_owner = @p ec.tk_id

# Calculate expiry: current gametime + duration_ticks
execute store result score @s ec.tk_expire run time query gametime
scoreboard players operation @s ec.tk_expire += #tk_duration_ticks ec.var

# Visual feedback
execute at @s run particle soul_fire_flame ~ ~1 ~ 0.3 0.5 0.3 0.02 4
# mark runs AS the hit MOB (@s = non-player) — gate per-listener on each player's own ec.fx_snd
execute at @s as @a if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bass hostile @s ~ ~ ~ 0.5 0.7
execute at @s as @a if score @s ec.fx_snd matches 1.. run playsound minecraft:block.amethyst_block.resonate hostile @s ~ ~ ~ 0.4 1.8
