# Vanguard Shield (aegis_guardian) — On-Block: Thorns Reflect
# Run as @s = blocking player. Reflects 3 thorns damage to nearby attacker(s) + brief Resistance.
# This makes the "On Block: Reflect thorns to attackers" lore literally true.
# Mirrors the golden_goliath block-thorns idiom (fresh, un-hurt hostiles in 3b) + thorns_block's Res grant.
execute at @s as @e[type=#evercraft:hostile_mobs,distance=..3,limit=4,nbt={HurtTime:0s}] run damage @s 3 minecraft:thorns
effect give @s resistance 3 0 false
execute at @s run particle crit ~ ~1 ~ 0.3 0.3 0.3 0.1 6
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:enchant.thorns.hit player @s ~ ~ ~ 1 1
