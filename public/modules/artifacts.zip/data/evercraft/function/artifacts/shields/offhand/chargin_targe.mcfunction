# Chargin' Targe — "Highland Rush"
# Speed II + Strength I for 3 seconds, 25s cooldown

effect give @s speed 3 1 false
effect give @s strength 3 0 false

# Particles + sound
execute at @s run particle crit ~ ~0.5 ~ 0.4 0.5 0.4 0.15 12
execute at @s if score @s ec.fx_snd matches 1.. run playsound minecraft:block.anvil.land master @s ~ ~ ~ 0.5 1.4
execute at @s if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.basedrum master @s ~ ~ ~ 0.5 0.8
execute at @s if score @s ec.fx_snd matches 1.. run playsound minecraft:item.shield.block master @s ~ ~ ~ 0.6 1.1

# Set cooldown
scoreboard players set @s ec.tk_off_cd 25

# Actionbar feedback
data modify storage evercraft:notify stage.c set value [{text:"Highland Rush!",color:"dark_aqua",bold:true}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
