# Shield Block — Uncommon: Quick Recovery
# Burst of speed after blocking to reposition
effect give @s speed 3 0 false
execute at @s run particle cloud ~ ~0.5 ~ 0.3 0.2 0.3 0.02 3
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:item.shield.block master @s ~ ~ ~ 0.7 1.3

# Generic tier-FX layer (common→rare; ornate+ no-ops for a future bespoke preset). Channel-gated.
# Tier is the block file's own rarity (slot-agnostic — shield may be main- or off-hand).
scoreboard players set #fx_tier ec.var 2
execute at @s run function evercraft:fx/tier/proc
