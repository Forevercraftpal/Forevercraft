# Resonance — Damage echoes to nearby mobs
# @s = player

# Find the hit entity and execute AoE at their location
execute as @e[type=!player,sort=nearest,limit=1,distance=..100,nbt={HurtTime:10s}] at @s run function evercraft:artifacts/hunter/precision/resonance_aoe

# Feedback
data modify storage evercraft:notify stage.c set value [{text:"Resonance! ",color:"yellow",bold:true},{text:"Echo reverberates!",color:"gold"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
