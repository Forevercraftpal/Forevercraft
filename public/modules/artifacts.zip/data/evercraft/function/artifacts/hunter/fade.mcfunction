# Fade — Hunter stealth reposition
# Gain Invisibility + Speed briefly

# Set fade cooldown (10 seconds)
scoreboard players set @s ec.ht_fade 10

# Effects
effect give @s invisibility 3 0 true
effect give @s speed 2 1 true

# Particles (smoke poof)
particle minecraft:campfire_cosy_smoke ~ ~1 ~ 0.5 0.5 0.5 0.02 8
particle minecraft:large_smoke ~ ~1 ~ 0.5 0.5 0.5 0.05 5

# Sound
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.enchantment_table.use master @s ~ ~ ~ 1 1.5
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.7 2.0
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.enderman.teleport master @s ~ ~ ~ 0.5 2.0

# Reset aim state
scoreboard players set @s ec.ht_aim 0

# Feedback
data modify storage evercraft:notify stage.c set value [{text:"Fade",color:"aqua",bold:true},{text:" \u2014 Vanishing into shadow!",color:"gray"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
