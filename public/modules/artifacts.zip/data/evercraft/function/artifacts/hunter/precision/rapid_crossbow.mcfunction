# Quickdraw — Speed boost for rapid reload
# @s = player

# Give Speed III for 2 seconds (simulates faster reload)
effect give @s speed 2 2 true

# Particles
particle minecraft:crit ~ ~1 ~ 0.3 0.3 0.3 0.2 5
particle minecraft:enchanted_hit ~ ~1 ~ 0.3 0.3 0.3 0.3 4

# Sound
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.arrow.hit_player master @s ~ ~ ~ 1 2.0

# Feedback
data modify storage evercraft:notify stage.c set value [{text:"Quickdraw! ",color:"yellow",bold:true},{text:"Rapid reload!",color:"gray"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
