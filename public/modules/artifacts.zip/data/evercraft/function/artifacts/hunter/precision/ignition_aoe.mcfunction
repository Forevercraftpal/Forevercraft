# Ignition — Fire AoE at target location
# @s = hit entity, position = hit entity

# Set fire to all entities in 4-block radius (6 seconds of fire)
execute as @e[type=!player,distance=..4] run data merge entity @s {Fire:120s}

# Particles
particle minecraft:flame ~ ~1 ~ 4 2 4 0.1 25
particle minecraft:lava ~ ~1 ~ 4 1 4 0.5 10

# Sound
execute as @a if score @s ec.fx_snd matches 1.. run playsound minecraft:item.firecharge.use master @s ~ ~ ~ 1.5 0.8
