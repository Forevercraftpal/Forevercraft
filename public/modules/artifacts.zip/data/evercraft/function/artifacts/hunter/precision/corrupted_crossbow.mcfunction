# Blight — Wither + Poison AoE (5 blocks)
# @s = player

# Find the hit entity and execute AoE at their location
execute as @e[type=!player,sort=nearest,limit=1,distance=..100,nbt={HurtTime:10s}] at @s run function evercraft:artifacts/hunter/precision/blight_aoe

# Feedback
data modify storage evercraft:notify stage.c set value [{text:"Blight! ",color:"dark_purple",bold:true},{text:"Corruption spreads!",color:"light_purple"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
