# Impale — Single target devastation
# @s = hit entity, position = hit entity

# Massive single-target effects
effect give @s slowness 4 3 false
effect give @s instant_damage 1 0 false

# Particles
particle minecraft:crit ~ ~1 ~ 0.5 0.5 0.5 0.5 10
particle minecraft:enchanted_hit ~ ~1 ~ 0.3 0.5 0.3 0.3 8

# Sound
execute as @a if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.arrow.hit master @s ~ ~ ~ 2 0.5
