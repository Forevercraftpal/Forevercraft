# Rift — Collapse burst at marker location
# @s = rift marker, position = marker

# Final burst — Wither II + Instant Damage I to everything in 6-block radius
effect give @e[type=!player,distance=..6] wither 6 1 false
effect give @e[type=!player,distance=..6] instant_damage 1 0 false

# Collapse particles
particle minecraft:explosion ~ ~1 ~ 3 2 3 0.5 5
particle minecraft:reverse_portal ~ ~1 ~ 6 3 6 0.2 40
particle minecraft:sculk_soul ~ ~1 ~ 4 2 4 0.1 15

# Sound
execute as @a if score @s ec.fx_snd matches 1.. run playsound minecraft:block.amethyst_block.resonate master @s ~ ~ ~ 2 0.3
