# Hunter — Arrow Hit Detection
advancement revoke @s only evercraft:artifacts/hunter/hit

# Only process if holding a hunter crossbow
execute unless score @s ec.ht_bow_id matches 1.. run return 0

# War-Prep — Storm Bolt (ht abil 1): the bolt bursts on impact, a grief-off AoE (4 explosion
# to hostiles within 3, no block damage). by the hunter for credit.
execute if score @s ec.ht_abil_id matches 1 run tag @s add ht.burst_src
execute if score @s ec.ht_abil_id matches 1 at @e[type=!player,type=!item,distance=..60,limit=1,sort=nearest,nbt={HurtTime:10s}] as @e[type=#evercraft:hostile_mobs,distance=..3] run damage @s 4 minecraft:explosion by @a[tag=ht.burst_src,limit=1]
execute if score @s ec.ht_abil_id matches 1 at @e[type=!player,type=!item,distance=..60,limit=1,sort=nearest,nbt={HurtTime:10s}] if score @s ec.fx_vis matches 1.. run particle minecraft:explosion ~ ~ ~ 0 0 0 0 1
execute if score @s ec.ht_abil_id matches 1 as @a[distance=..24] if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.generic.explode player @s ~ ~ ~ 0.6 1.1
execute if score @s ec.ht_abil_id matches 1 run tag @s remove ht.burst_src

# === ARROW HIT TING ===
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.arrow.hit_player player @s

# Dispatch to precision hit or passive
execute if score @s ec.ht_charged matches 1 run function evercraft:artifacts/hunter/precision_hit
execute unless score @s ec.ht_charged matches 1.. run function evercraft:artifacts/hunter/passive_hit
