# === HEALER — POLLEN AMP (Living Bough Wave 14/15/16/18/19 pollen consumers) ===
# Run as/at @s = the Healer, immediately after a healer-item heal fires (called
# by all 12 artifacts/healer/use/* items, AFTER the cooldown gate — so it only
# fires on a successful use). Flags are live-owned (bough/pollen_tick single
# writer), so Reroot/strips propagate automatically.
#
# pollen_gs_garden (Growseer U1 Gardener → Healer): garden-fed hands — your
#   heals restore +1 HP to YOU (an extra instant-health ping on the caster,
#   riding the base heal you just cast). Hidden particles.
# pollen_dn_breath (Dancer U1 Breath-step → Healer): healer items are
#   instant-use — no cast-time surface exists to speed up — so this lands as
#   the design-sanctioned fallback: +1s saturation on heal trigger (the
#   permanent_tick saturation idiom).
# pollen_bl_howl (Beastlord U2 Pack Pulse → Healer) — Wave 15: the pack's pulse
#   beats in the mender's hands — heals also grant the caster 1s of Regen II.
# pollen_rg_poison (Rogue U11 Wet Work → Healer) — Wave 16: counter-pollen —
#   one who works in poisons does not fear them. Heals grant the caster 2s of
#   Resistance I (small flat rider; vanilla has no poison-only immunity effect
#   short of a damage-event intercept, so the brief's sanctioned flat
#   resistance lands here).
# pollen_sn_calm (Sentinel U2 Iron Refrain → Healer) — Wave 16: the refrain
#   steadies the hand — +1s saturation rider on heal trigger (the dn_breath
#   idiom; when both flags are owned the two lines refresh the same 1s effect,
#   which is the accepted small-bonus overlap).
# pollen_lf_heart (Lumberfell U11 Heartfall Pact → Healer) — Wave 16: heartwood
#   holds the mender — heals grant 1s of Absorption I (vanilla's absorption
#   floor is 2 hearts; the 1s duration keeps it a blip-shield, the brief's
#   "+0.5 absorption" rounded up to the effect system's resolution).
# pollen_sc_pearl (Sirencall U6 Pearl Pact → Healer) — Wave 18: the pearl
#   layers the shield — a second 1s Absorption I rider (the lf_heart idiom;
#   the brief's "+0.5 absorption" rounded up to effect resolution — when both
#   flags are owned the two lines refresh the same 1s effect, the accepted
#   small-bonus overlap, cf. sn_calm/dn_breath).
# pollen_kt_radiance (Knight U6 Noble Light → Healer) — Wave 19: the noble
#   light warms the mender's hands — +1s saturation rider on heal trigger (the
#   sn_calm/dn_breath idiom; when more than one of the three saturation flags
#   is owned the lines refresh the same 1s effect, the accepted small-bonus
#   overlap).
execute if score @s ec.pollen_gs_garden matches 1.. run effect give @s minecraft:instant_health 1 0 true
execute if score @s ec.pollen_dn_breath matches 1.. run effect give @s minecraft:saturation 1 0 true
execute if score @s ec.pollen_bl_howl matches 1.. run effect give @s minecraft:regeneration 1 1 true
execute if score @s ec.pollen_rg_poison matches 1.. run effect give @s minecraft:resistance 2 0 true
execute if score @s ec.pollen_sn_calm matches 1.. run effect give @s minecraft:saturation 1 0 true
execute if score @s ec.pollen_lf_heart matches 1.. run effect give @s minecraft:absorption 1 0 true
execute if score @s ec.pollen_sc_pearl matches 1.. run effect give @s minecraft:absorption 1 0 true
execute if score @s ec.pollen_kt_radiance matches 1.. run effect give @s minecraft:saturation 1 0 true
