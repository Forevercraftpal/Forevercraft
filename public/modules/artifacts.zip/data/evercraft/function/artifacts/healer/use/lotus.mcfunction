# Celestial Lotus — Exquisite Healer
# Heals 4 hearts (8 HP) + Absorption II 12s within 24 blocks
# Cooldown: 28 seconds

advancement revoke @s only evercraft:artifacts/healer/use_lotus
# Mark for delayed restore (consume_item fires before item removal — restore next tick)
scoreboard players set @s ec.hl_restore_hand 0
execute if items entity @s weapon.mainhand *[custom_data~{healer_id:"lotus"}] run scoreboard players set @s ec.hl_restore_hand 1
scoreboard players set @s ec.hl_restore_id 9
tag @s add ec.hl_restore
# Save actual item data (preserves glyphforge runes, patina, mastery, etc.)
# Wiring Audit #5 W3b: per-player storage scope (`healer.$(pid)`) via macro inner.
execute store result storage evercraft:artifacts cart.pid int 1 run scoreboard players get @s adv.gui_session
function evercraft:artifacts/healer/save_held_inner with storage evercraft:artifacts cart

data modify storage evercraft:notify stage.c set value [{text:"Recharging... ",color:"gray"},{score:{name:"@s",objective:"ec.hl_lotus"},color:"dark_gray"},{text:"s",color:"dark_gray"}]
scoreboard players set #ndur ec.temp 45
execute if score @s ec.hl_lotus matches 1.. run function evercraft:util/notify/emit
execute if score @s ec.hl_lotus matches 1.. run return 0

# === HEAL + ABSORPTION ===
execute at @s run effect give @a[distance=..24] instant_health 1 2 false
execute at @s run effect give @a[distance=..24] absorption 240 1 false
execute at @s run effect give @e[type=#evercraft:tameable_companions,distance=..24,tag=ec.tame_protected] instant_health 1 2 true
execute at @s run effect give @e[type=#evercraft:tameable_companions,distance=..24,tag=ec.tame_protected] absorption 240 1 true

# Feedback
execute at @s as @a[distance=..24] if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.player.levelup master @s ~ ~ ~ 0.8 1.5
execute at @s run particle end_rod ~ ~1.5 ~ 3 1 3 0.05 15
execute at @s run particle heart ~ ~2 ~ 2 0.5 2 0.1 8
data modify storage evercraft:notify stage.c set value [{text:"Celestial light shields all players within 24 blocks",color:"green"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
tag @s add ec.healer_self
data modify storage evercraft:notify stage.c set value [{text:"Golden light envelops you!",color:"green"}]
scoreboard players set #ndur ec.temp 45
execute at @s as @a[distance=..24,tag=!ec.healer_self] run function evercraft:util/notify/emit
tag @s remove ec.healer_self

scoreboard players set @s ec.hl_lotus 28
scoreboard players set @s ec.hl_locked 1
# Pollen amp (Living Bough Wave 14): gs_garden +1 HP caster ping / dn_breath saturation flavor.
execute at @s run function evercraft:artifacts/healer/pollen_amp

# Generic tier-FX layer (common→rare; ornate+ no-ops for a future bespoke preset). Channel-gated.
function evercraft:fx/tier/read_mainhand
execute at @s run function evercraft:fx/tier/proc
# Bespoke healer flourish (ornate+; #fx_tier set by read_mainhand above). Channel-gated internally.
execute at @s if score #fx_tier ec.var matches 4.. run function evercraft:fx/bespoke/healer/celestial_lotus
