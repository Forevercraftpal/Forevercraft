# Endless Ambrosia — Mythical Healer
# Full heal all players + Resistance II 10s within 32 blocks
# Cooldown: 30 seconds

advancement revoke @s only evercraft:artifacts/healer/use_ambrosia
# Mark for delayed restore (consume_item fires before item removal — restore next tick)
scoreboard players set @s ec.hl_restore_hand 0
execute if items entity @s weapon.mainhand *[custom_data~{healer_id:"ambrosia"}] run scoreboard players set @s ec.hl_restore_hand 1
scoreboard players set @s ec.hl_restore_id 10
tag @s add ec.hl_restore
# Save actual item data (preserves glyphforge runes, patina, mastery, etc.)
# Wiring Audit #5 W3b: per-player storage scope (`healer.$(pid)`) via macro inner.
execute store result storage evercraft:artifacts cart.pid int 1 run scoreboard players get @s adv.gui_session
function evercraft:artifacts/healer/save_held_inner with storage evercraft:artifacts cart

data modify storage evercraft:notify stage.c set value [{text:"Recharging... ",color:"gray"},{score:{name:"@s",objective:"ec.hl_ambrosia"},color:"dark_gray"},{text:"s",color:"dark_gray"}]
scoreboard players set #ndur ec.temp 45
execute if score @s ec.hl_ambrosia matches 1.. run function evercraft:util/notify/emit
execute if score @s ec.hl_ambrosia matches 1.. run return 0

# === FULL HEAL + RESISTANCE II ===
execute at @s run effect give @a[distance=..32] instant_health 1 4 false
execute at @s run effect give @a[distance=..32] resistance 200 1 false
execute at @s run effect give @e[type=#evercraft:tameable_companions,distance=..32,tag=ec.tame_protected] instant_health 1 4 true
execute at @s run effect give @e[type=#evercraft:tameable_companions,distance=..32,tag=ec.tame_protected] resistance 200 1 true

# Feedback — mythical-tier dramatic effects
execute at @s as @a[distance=..32] if score @s ec.fx_snd matches 1.. run playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 1 1.0
execute at @s as @a[distance=..32] if score @s ec.fx_snd matches 1.. run playsound minecraft:block.beacon.power_select master @s ~ ~ ~ 1 1.5
execute at @s run particle totem_of_undying ~ ~1.5 ~ 4 1 4 1 50
execute at @s run particle heart ~ ~2.5 ~ 3 1 3 0.1 13

# Announcements
data modify storage evercraft:notify stage.c set value [{text:"The food of the gods restores all within 32 blocks!",color:"yellow"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
tag @s add ec.healer_self
data modify storage evercraft:notify stage.c set value [{text:"Divine healing washes over you!",color:"yellow"}]
scoreboard players set #ndur ec.temp 45
execute at @s as @a[distance=..32,tag=!ec.healer_self] run function evercraft:util/notify/emit
tag @s remove ec.healer_self

# Broadcast to all distant players (§5b actor-named — direct render so {selector:@s} resolves once)
execute at @s run function evercraft:util/notify/whoami
data modify storage evercraft:notify stage.c set value [{text:"",color:"white"},{text:" unleashed the Ambrosia!",color:"yellow"}]
data modify storage evercraft:notify stage.c[0].text set from storage evercraft:notify named.who
scoreboard players set #ndur ec.temp 50
execute at @s run execute as @a[distance=33..] run scoreboard players set #nttl ec.temp 600
execute at @s run execute as @a[distance=33..] run function evercraft:util/notify/emit_keep

scoreboard players set @s ec.hl_ambrosia 30
scoreboard players set @s ec.hl_locked 1
# Pollen amp (Living Bough Wave 14): gs_garden +1 HP caster ping / dn_breath saturation flavor.
execute at @s run function evercraft:artifacts/healer/pollen_amp

# Generic tier-FX layer (common→rare; ornate+ no-ops for a future bespoke preset). Channel-gated.
function evercraft:fx/tier/read_mainhand
execute at @s run function evercraft:fx/tier/proc
# Bespoke healer flourish (ornate+; #fx_tier set by read_mainhand above). Channel-gated internally.
execute at @s if score #fx_tier ec.var matches 4.. run function evercraft:fx/bespoke/healer/endless_ambrosia
