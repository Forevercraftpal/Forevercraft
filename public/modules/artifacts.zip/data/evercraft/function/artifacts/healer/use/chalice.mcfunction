# Mending Chalice — Rare Healer
# Heals 2 hearts (4 HP) + Regeneration I 5s within 16 blocks
# Cooldown: 20 seconds

advancement revoke @s only evercraft:artifacts/healer/use_chalice
# Mark for delayed restore (consume_item fires before item removal — restore next tick)
scoreboard players set @s ec.hl_restore_hand 0
execute if items entity @s weapon.mainhand *[custom_data~{healer_id:"chalice"}] run scoreboard players set @s ec.hl_restore_hand 1
scoreboard players set @s ec.hl_restore_id 5
tag @s add ec.hl_restore
# Save actual item data (preserves glyphforge runes, patina, mastery, etc.)
# Wiring Audit #5 W3b: per-player storage scope (`healer.$(pid)`) via macro inner.
execute store result storage evercraft:artifacts cart.pid int 1 run scoreboard players get @s adv.gui_session
function evercraft:artifacts/healer/save_held_inner with storage evercraft:artifacts cart

data modify storage evercraft:notify stage.c set value [{text:"Recharging... ",color:"gray"},{score:{name:"@s",objective:"ec.hl_chalice"},color:"dark_gray"},{text:"s",color:"dark_gray"}]
scoreboard players set #ndur ec.temp 45
execute if score @s ec.hl_chalice matches 1.. run function evercraft:util/notify/emit
execute if score @s ec.hl_chalice matches 1.. run return 0

# === HEAL + REGEN ===
execute at @s run effect give @a[distance=..16] instant_health 1 1 false
execute at @s run effect give @a[distance=..16] regeneration 100 0 false
execute at @s run effect give @e[type=#evercraft:tameable_companions,distance=..16,tag=ec.tame_protected] instant_health 1 1 true
execute at @s run effect give @e[type=#evercraft:tameable_companions,distance=..16,tag=ec.tame_protected] regeneration 100 0 true

# Feedback
execute at @s as @a[distance=..16] if score @s ec.fx_snd matches 1.. run playsound minecraft:block.beacon.activate master @s ~ ~ ~ 0.8 1.5
execute at @s run particle heart ~ ~1.5 ~ 2 0.5 2 0.1 6
data modify storage evercraft:notify stage.c set value [{text:"Healed and restored all players within 16 blocks",color:"green"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
tag @s add ec.healer_self
data modify storage evercraft:notify stage.c set value [{text:"Wounds mending...",color:"green"}]
scoreboard players set #ndur ec.temp 45
execute at @s as @a[distance=..16,tag=!ec.healer_self] run function evercraft:util/notify/emit
tag @s remove ec.healer_self

scoreboard players set @s ec.hl_chalice 20
scoreboard players set @s ec.hl_locked 1
# Pollen amp (Living Bough Wave 14): gs_garden +1 HP caster ping / dn_breath saturation flavor.
execute at @s run function evercraft:artifacts/healer/pollen_amp

# Generic tier-FX layer (common→rare; ornate+ no-ops for a future bespoke preset). Channel-gated.
function evercraft:fx/tier/read_mainhand
execute at @s run function evercraft:fx/tier/proc
