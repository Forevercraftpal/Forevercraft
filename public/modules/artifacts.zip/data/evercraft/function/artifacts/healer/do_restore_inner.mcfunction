# Macro inner: per-player hopper_minecart restore from per-player healer storage.
# Args from storage evercraft:artifacts cart:
#   pid = per-player session-counter (cheap UUID surrogate)
# Wiring Audit #5 W3b — paired with do_restore.mcfunction (outer derives pid).
# Per-player tag suffix on hopper_minecart entity + per-player storage path.

# Set up hopper_minecart with saved item data (per-player tag).
$data modify entity @e[type=hopper_minecart,tag=ec.hl_temp.$(pid),limit=1] Items set value []
$kill @e[type=hopper_minecart,tag=ec.hl_temp.$(pid)]
$summon hopper_minecart ~ 320 ~ {Tags:["ec.hl_temp","ec.hl_temp.$(pid)"],Items:[{Slot:0b,id:"minecraft:stone",count:1}]}
$data modify entity @e[type=hopper_minecart,tag=ec.hl_temp.$(pid),limit=1] Items[0] merge from storage evercraft:item_restore healer.$(pid)

# Restore to correct hand
$execute if score @s ec.hl_restore_hand matches 1 run item replace entity @s weapon.mainhand from entity @e[type=hopper_minecart,tag=ec.hl_temp.$(pid),limit=1] container.0
$execute if score @s ec.hl_restore_hand matches 0 run item replace entity @s weapon.offhand from entity @e[type=hopper_minecart,tag=ec.hl_temp.$(pid),limit=1] container.0

# Cleanup
$data modify entity @e[type=hopper_minecart,tag=ec.hl_temp.$(pid),limit=1] Items set value []
$kill @e[type=hopper_minecart,tag=ec.hl_temp.$(pid)]
