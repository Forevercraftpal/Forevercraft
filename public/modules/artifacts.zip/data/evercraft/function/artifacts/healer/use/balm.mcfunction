# Soothing Balm — Uncommon Healer
# Heals 2 hearts (4 HP) + Speed I 5s within 12 blocks
# Cooldown: 16 seconds

advancement revoke @s only evercraft:artifacts/healer/use_balm
# Mark for delayed restore (consume_item fires before item removal — restore next tick)
scoreboard players set @s ec.hl_restore_hand 0
execute if items entity @s weapon.mainhand *[custom_data~{healer_id:"balm"}] run scoreboard players set @s ec.hl_restore_hand 1
scoreboard players set @s ec.hl_restore_id 4
tag @s add ec.hl_restore
# Save actual item data (preserves glyphforge runes, patina, mastery, etc.)
# Wiring Audit #5 W3b: per-player storage scope (`healer.$(pid)`) via macro inner.
execute store result storage evercraft:artifacts cart.pid int 1 run scoreboard players get @s adv.gui_session
function evercraft:artifacts/healer/save_held_inner with storage evercraft:artifacts cart

data modify storage evercraft:notify stage.c set value [{text:"Recharging... ",color:"gray"},{score:{name:"@s",objective:"ec.hl_balm"},color:"dark_gray"},{text:"s",color:"dark_gray"}]
scoreboard players set #ndur ec.temp 45
execute if score @s ec.hl_balm matches 1.. run function evercraft:util/notify/emit
execute if score @s ec.hl_balm matches 1.. run return 0

# === HEAL + SPEED ===
execute at @s run effect give @a[distance=..12] instant_health 1 1 false
execute at @s run effect give @a[distance=..12] speed 100 0 false
execute at @s run effect give @e[type=#evercraft:tameable_companions,distance=..12,tag=ec.tame_protected] instant_health 1 1 true
execute at @s run effect give @e[type=#evercraft:tameable_companions,distance=..12,tag=ec.tame_protected] speed 100 0 true

# Feedback
execute at @s as @a[distance=..12] if score @s ec.fx_snd matches 1.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 1 1.4
execute at @s run particle happy_villager ~ ~1.5 ~ 1.5 0.5 1.5 0.1 6
data modify storage evercraft:notify stage.c set value [{text:"Healed and hastened all players within 12 blocks",color:"green"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
tag @s add ec.healer_self
data modify storage evercraft:notify stage.c set value [{text:"You feel invigorated!",color:"green"}]
scoreboard players set #ndur ec.temp 45
execute at @s as @a[distance=..12,tag=!ec.healer_self] run function evercraft:util/notify/emit
tag @s remove ec.healer_self

scoreboard players set @s ec.hl_balm 16
scoreboard players set @s ec.hl_locked 1
# Pollen amp (Living Bough Wave 14): gs_garden +1 HP caster ping / dn_breath saturation flavor.
execute at @s run function evercraft:artifacts/healer/pollen_amp

# Generic tier-FX layer (common→rare; ornate+ no-ops for a future bespoke preset). Channel-gated.
function evercraft:fx/tier/read_mainhand
execute at @s run function evercraft:fx/tier/proc
