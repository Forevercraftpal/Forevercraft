# Herbal Poultice — Common Healer
# Heals SELF for 2 hearts (4 HP)
# Cooldown: 12 seconds

advancement revoke @s only evercraft:artifacts/healer/use_poultice
# Mark for delayed restore (consume_item fires before item removal — restore next tick)
scoreboard players set @s ec.hl_restore_hand 0
execute if items entity @s weapon.mainhand *[custom_data~{healer_id:"poultice"}] run scoreboard players set @s ec.hl_restore_hand 1
scoreboard players set @s ec.hl_restore_id 2
tag @s add ec.hl_restore
# Save actual item data (preserves glyphforge runes, patina, mastery, etc.)
# Wiring Audit #5 W3b: per-player storage scope (`healer.$(pid)`) via macro inner.
execute store result storage evercraft:artifacts cart.pid int 1 run scoreboard players get @s adv.gui_session
function evercraft:artifacts/healer/save_held_inner with storage evercraft:artifacts cart

data modify storage evercraft:notify stage.c set value [{text:"Recharging... ",color:"gray"},{score:{name:"@s",objective:"ec.hl_poultice"},color:"dark_gray"},{text:"s",color:"dark_gray"}]
scoreboard players set #ndur ec.temp 45
execute if score @s ec.hl_poultice matches 1.. run function evercraft:util/notify/emit
execute if score @s ec.hl_poultice matches 1.. run return 0

# === HEAL (self only) ===
effect give @s instant_health 1 1 false

# Feedback
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 1 1.0
execute at @s run particle heart ~ ~1.5 ~ 0.3 0.3 0.3 0.1 3
data modify storage evercraft:notify stage.c set value [{text:"Healed self for 2 hearts",color:"green"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit

scoreboard players set @s ec.hl_poultice 12
scoreboard players set @s ec.hl_locked 1
# Pollen amp (Living Bough Wave 14): gs_garden +1 HP caster ping / dn_breath saturation flavor.
execute at @s run function evercraft:artifacts/healer/pollen_amp

# Generic tier-FX layer (common→rare; ornate+ no-ops for a future bespoke preset). Channel-gated.
function evercraft:fx/tier/read_mainhand
execute at @s run function evercraft:fx/tier/proc
