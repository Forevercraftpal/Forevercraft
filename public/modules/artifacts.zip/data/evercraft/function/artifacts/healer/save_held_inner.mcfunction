# Macro inner: per-player save of held healer tool into storage.
# Args from storage evercraft:artifacts cart:
#   pid = per-player session-counter (cheap UUID surrogate)
# Wiring Audit #5 W3b — paired with healer/use/*.mcfunction (outer derives pid).
# Replaces single-key `storage evercraft:item_restore healer` write race.

$execute if score @s ec.hl_restore_hand matches 1 run data modify storage evercraft:item_restore healer.$(pid) set from entity @s SelectedItem
$execute if score @s ec.hl_restore_hand matches 0 run data modify storage evercraft:item_restore healer.$(pid) set from entity @s equipment.offhand
