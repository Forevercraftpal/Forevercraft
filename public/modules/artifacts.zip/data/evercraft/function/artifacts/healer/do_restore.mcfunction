# Healer Artifacts — Delayed Item Restore (preserves all modifications)
# Uses hopper_minecart intermediary to restore the exact saved item
# (glyphforge runes, patina, weapon mastery, etc. are preserved)
# ec.hl_restore_hand: 1 = mainhand, 0 = offhand
# Wiring Audit #5 W3b: hybrid per-player scope — tag-suffix on cart + storage-path suffix.
# Defends against 2-healer same-tick item-swap race + cross-player storage clobber.

tag @s remove ec.hl_restore

# Derive per-player id; delegate to macro inner (do_restore_inner).
execute store result storage evercraft:artifacts cart.pid int 1 run scoreboard players get @s adv.gui_session
function evercraft:artifacts/healer/do_restore_inner with storage evercraft:artifacts cart
