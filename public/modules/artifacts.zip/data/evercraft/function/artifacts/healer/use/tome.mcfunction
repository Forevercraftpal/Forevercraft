# Lifewarden's Tome — Exquisite Healer (Book — using_item trigger, not consumed)
# Heals all 2 hearts; players below 50% HP get 8 hearts instead (24 blocks)
# Cooldown: 26 seconds

advancement revoke @s only evercraft:artifacts/healer/use_tome

# Check cooldown
data modify storage evercraft:notify stage.c set value [{text:"Recharging... ",color:"gray"},{score:{name:"@s",objective:"ec.hl_tome"},color:"dark_gray"},{text:"s",color:"dark_gray"}]
scoreboard players set #ndur ec.temp 45
execute if score @s ec.hl_tome matches 1.. run function evercraft:util/notify/emit
execute if score @s ec.hl_tome matches 1.. run return 0

# === TRIAGE HEAL ===
# Base heal: 2 hearts (4 HP) to everyone
execute at @s run effect give @a[distance=..24] instant_health 1 1 false
execute at @s run effect give @e[type=#evercraft:tameable_companions,distance=..24,tag=ec.tame_protected] instant_health 1 1 true

# Triage: players below 50% HP (10 HP) get additional 8 hearts (16 HP)
execute at @s as @a[distance=..24] store result score @s ec.hl_temp run data get entity @s Health
execute at @s as @a[distance=..24,scores={ec.hl_temp=..10}] run effect give @s instant_health 1 3 false

# Feedback
execute at @s as @a[distance=..24] if score @s ec.fx_snd matches 1.. run playsound minecraft:item.book.page_turn master @s ~ ~ ~ 1 0.8
execute at @s as @a[distance=..24] if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.player.levelup master @s ~ ~ ~ 0.6 1.8
execute at @s run particle enchant ~ ~1.5 ~ 3 1 3 1 20
execute at @s run particle heart ~ ~2 ~ 2 0.5 2 0.1 6
data modify storage evercraft:notify stage.c set value [{text:"Triage complete — the wounded are prioritized",color:"green"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
tag @s add ec.healer_self
data modify storage evercraft:notify stage.c set value [{text:"Emergency healing surges through you!",color:"yellow"}]
scoreboard players set #ndur ec.temp 45
execute at @s as @a[distance=..24,scores={ec.hl_temp=..10},tag=!ec.healer_self] run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"You were healed!",color:"green"}]
scoreboard players set #ndur ec.temp 45
execute at @s as @a[distance=..24,scores={ec.hl_temp=11..},tag=!ec.healer_self] run function evercraft:util/notify/emit
tag @s remove ec.healer_self

scoreboard players set @s ec.hl_tome 26
scoreboard players set @s ec.hl_locked 1
# Pollen amp (Living Bough Wave 14): gs_garden +1 HP caster ping / dn_breath saturation flavor.
execute at @s run function evercraft:artifacts/healer/pollen_amp

# Generic tier-FX layer (common→rare; ornate+ no-ops for a future bespoke preset). Channel-gated.
function evercraft:fx/tier/read_mainhand
execute at @s run function evercraft:fx/tier/proc
# Bespoke healer flourish (ornate+; #fx_tier set by read_mainhand above). Channel-gated internally.
execute at @s if score #fx_tier ec.var matches 4.. run function evercraft:fx/bespoke/healer/lifewardens_tome
