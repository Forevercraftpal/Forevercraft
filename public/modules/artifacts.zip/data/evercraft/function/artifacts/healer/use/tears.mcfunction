# Tears of the World Tree — Mythical Healer
# Heals 8 hearts (16 HP) + Regen III 10s + Absorption III 15s within 32 blocks
# Emergency: players below 20% HP get extra 4 hearts (8 HP)
# Cooldown: 30 seconds

advancement revoke @s only evercraft:artifacts/healer/use_tears
# Mark for delayed restore (consume_item fires before item removal — restore next tick)
scoreboard players set @s ec.hl_restore_hand 0
execute if items entity @s weapon.mainhand *[custom_data~{healer_id:"tears"}] run scoreboard players set @s ec.hl_restore_hand 1
scoreboard players set @s ec.hl_restore_id 11
tag @s add ec.hl_restore
# Save actual item data (preserves glyphforge runes, patina, mastery, etc.)
# Wiring Audit #5 W3b: per-player storage scope (`healer.$(pid)`) via macro inner.
execute store result storage evercraft:artifacts cart.pid int 1 run scoreboard players get @s adv.gui_session
function evercraft:artifacts/healer/save_held_inner with storage evercraft:artifacts cart

data modify storage evercraft:notify stage.c set value [{text:"Recharging... ",color:"gray"},{score:{name:"@s",objective:"ec.hl_tears"},color:"dark_gray"},{text:"s",color:"dark_gray"}]
scoreboard players set #ndur ec.temp 45
execute if score @s ec.hl_tears matches 1.. run function evercraft:util/notify/emit
execute if score @s ec.hl_tears matches 1.. run return 0

# === HEAL + REGEN III + ABSORPTION III ===
execute at @s run effect give @a[distance=..32] instant_health 1 3 false
execute at @s run effect give @a[distance=..32] regeneration 200 2 false
execute at @s run effect give @a[distance=..32] absorption 300 2 false
execute at @s run effect give @e[type=#evercraft:tameable_companions,distance=..32,tag=ec.tame_protected] instant_health 1 3 true
execute at @s run effect give @e[type=#evercraft:tameable_companions,distance=..32,tag=ec.tame_protected] regeneration 200 2 true
execute at @s run effect give @e[type=#evercraft:tameable_companions,distance=..32,tag=ec.tame_protected] absorption 300 2 true

# Emergency bonus: players below 20% HP (4 HP) get extra heal
execute at @s as @a[distance=..32] store result score @s ec.hl_temp run data get entity @s Health
execute at @s as @a[distance=..32,scores={ec.hl_temp=..4}] run effect give @s instant_health 1 2 false

# Feedback — mythical-tier dramatic effects
execute at @s as @a[distance=..32] if score @s ec.fx_snd matches 1.. run playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 1 1.2
execute at @s as @a[distance=..32] if score @s ec.fx_snd matches 1.. run playsound minecraft:block.beacon.power_select master @s ~ ~ ~ 1 1.8
execute at @s run particle totem_of_undying ~ ~1.5 ~ 4 1 4 1 40
execute at @s run particle falling_water ~ ~2 ~ 4 1 4 0.1 20
execute at @s run particle heart ~ ~2.5 ~ 3 1 3 0.1 10

# Announcements
data modify storage evercraft:notify stage.c set value [{text:"The World Tree weeps — life surges through all within 32 blocks!",color:"yellow"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
tag @s add ec.healer_self
data modify storage evercraft:notify stage.c set value [{text:"Emergency healing saves you from death's door!",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute at @s as @a[distance=..32,scores={ec.hl_temp=..4},tag=!ec.healer_self] run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Ancient healing flows through you!",color:"yellow"}]
scoreboard players set #ndur ec.temp 45
execute at @s as @a[distance=..32,scores={ec.hl_temp=5..},tag=!ec.healer_self] run function evercraft:util/notify/emit
tag @s remove ec.healer_self

# Broadcast to all distant players (§5b actor-named — direct render so {selector:@s} resolves once)
execute at @s run function evercraft:util/notify/whoami
data modify storage evercraft:notify stage.c set value [{text:"",color:"white"},{text:" invoked the World Tree's tears!",color:"yellow"}]
data modify storage evercraft:notify stage.c[0].text set from storage evercraft:notify named.who
scoreboard players set #ndur ec.temp 50
execute at @s run execute as @a[distance=33..] run scoreboard players set #nttl ec.temp 600
execute at @s run execute as @a[distance=33..] run function evercraft:util/notify/emit_keep

scoreboard players set @s ec.hl_tears 30
scoreboard players set @s ec.hl_locked 1
# Pollen amp (Living Bough Wave 14): gs_garden +1 HP caster ping / dn_breath saturation flavor.
execute at @s run function evercraft:artifacts/healer/pollen_amp

# Generic tier-FX layer (common→rare; ornate+ no-ops for a future bespoke preset). Channel-gated.
function evercraft:fx/tier/read_mainhand
execute at @s run function evercraft:fx/tier/proc
# Bespoke healer flourish (ornate+; #fx_tier set by read_mainhand above). Channel-gated internally.
execute at @s if score #fx_tier ec.var matches 4.. run function evercraft:fx/bespoke/healer/tears_of_world_tree
