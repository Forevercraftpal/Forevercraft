# Xara Hammer (Void Voyage) — Voidshatter
# Run as @s = an aoe_target caught in the Striker ground_slam (dispatched from striker/ground_slam, gated
# on the xara_hammer being in mainhand). Revives the two DEAD headline abilities the audit flagged:
#   Shadow Shatter -> AoE Weakness II (5s)
#   Void Pulse     -> Levitation (3s) — lifts the target off its feet
effect give @s weakness 5 1 false
effect give @s levitation 3 0 false

# Shadow/void visual on the shattered target
execute at @s run particle dust{color:[0.4,0.1,0.6],scale:1.1} ~ ~1 ~ 0.4 0.5 0.4 0 8
execute at @s run particle reverse_portal ~ ~1 ~ 0.3 0.5 0.3 0.05 6
