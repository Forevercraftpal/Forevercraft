# ============================================================
# Claude's Gift — "All drops doubled" (Joseph 2026-06-10, now REAL)
# ============================================================
# Reward fn of evercraft:artifacts/claudes_gift_kill (player_killed_entity — fires for
# EVERY player kill; first line bails cheaply for non-carriers, so the cost for everyone
# else is one revoke + three item-scan gates).
# Mechanic: duplicate this kill's fresh death-drops exactly once each. Drops spawn with
# Age 0 on the kill tick, the reward fn runs the same tick, so `Age:0s` + the cg_doubled
# tag-once guard targets only this death's items. 10b radius covers melee + close range
# (a far bow kill's drops are out of reach — documented limitation, not a bug).
advancement revoke @s only evercraft:artifacts/claudes_gift_kill

# Carrier gate (container / satchel-mark / offhand — the standard accessory triple).
execute if items entity @s container.* *[custom_data~{artifact:"claudes_gift"}] run tag @s add ec._a
execute unless items entity @s container.* *[custom_data~{artifact:"claudes_gift"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"claudes_gift"}] if entity @s[tag=ec.sat_claudes_gift] run tag @s add ec._a
execute unless entity @s[tag=ec._a] if items entity @s weapon.offhand *[custom_data~{artifact:"claudes_gift"}] run tag @s add ec._a
execute unless entity @s[tag=ec._a] run return 0
tag @s remove ec._a

# Duplicate each fresh drop once (limit 12 = bounded even for stacked deaths).
execute at @s as @e[type=item,distance=..10,nbt={Age:0s},tag=!cg_doubled,limit=12] run function evercraft:artifacts/abilities/claudes_gift_dup_one
