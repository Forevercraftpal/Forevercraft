# Wind Gust - Activate wind charge burst on the hit mob
# Called when player attacks with Draconic Gale (non-sneaking)

# Find the nearest mob that was just attacked (closest to player, recently hurt)
execute at @s as @e[type=#evercraft:aoe_targets,distance=..6,sort=nearest,limit=1,nbt={HurtTime:10s}] at @s run summon wind_charge ~ ~0.5 ~ {HasBeenShot:1b,acceleration_power:[0.0,0.0,0.0],Tags:["dragon_fan_wind_burst"]}

# Sound and visual at player
execute as @a if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.wind_charge.wind_burst player @s ~ ~ ~ 1.0 1.0
particle gust ~ ~1.5 ~ 0.3 0.3 0.3 0.1 3

# Brief actionbar notification
data modify storage evercraft:notify stage.c set value [{text:"Wind Gust!",color:"aqua"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
