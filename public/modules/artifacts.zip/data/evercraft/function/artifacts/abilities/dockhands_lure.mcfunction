# Dockhand's Knot (C31, Family J — art-J) — Lure I on held rod
# Mirrors the Angler's Pearl fast_fishing idiom: inject Lure I onto a held fishing rod that lacks
# Lure, tag the player so the cleanup runs on removal/switch. Lure-I-ONLY, BELOW Angler's Pearl
# (Lure II + LotS I) and BELOW Anglerwarden's Sigil (Lure II + LotS III) — a tier ladder, not a copy.
# Lure-on-rod is NOT fortune-rewritten (D-FORTUNE-REWRITE excludes fishing rod items).

# Early-exit unless the player holds the Knot (container or offhand)
execute unless items entity @s container.* *[custom_data~{artifact:"dockhands_knot"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"dockhands_knot"}] run return 0

# Apply Lure I to a held fishing rod that has no Lure yet, then tag for cleanup
execute if items entity @s weapon.mainhand minecraft:fishing_rod unless items entity @s weapon.mainhand *[enchantments~[{enchantment:"minecraft:lure",levels:{min:1}}]] run item modify entity @s weapon.mainhand evercraft:fishing_lure_1
execute if items entity @s weapon.mainhand minecraft:fishing_rod run tag @s add ec.dockhands_knot_fishing
