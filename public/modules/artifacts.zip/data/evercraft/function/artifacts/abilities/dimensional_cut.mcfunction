# Dimensional Cut — Zantetsuken Enhancement (Mythical)
# Teleports player 2 blocks behind nearest target
# Called from swing_t6 every 10th auto-swing

# Teleport behind nearest target (2 blocks behind where they're facing)
# Safety: only teleport if destination feet+head are clear (not solid blocks)
execute at @s as @e[type=!player,type=!item,distance=..5,limit=1,sort=nearest] at @s positioned ^ ^ ^-2 if block ~ ~ ~ #minecraft:replaceable if block ~ ~1 ~ #minecraft:replaceable run tp @a[tag=ec.rg_swinger,limit=1] ~ ~ ~

# Visual/audio feedback
data modify storage evercraft:notify stage.c set value [{text:"Dimensional Cut!",color:"#9B59B6",bold:true}]
scoreboard players set #ndur ec.temp 45
execute as @a[tag=ec.rg_swinger,limit=1] run function evercraft:util/notify/emit
execute at @s run particle reverse_portal ~ ~1 ~ 0.5 1 0.5 0.1 15
execute at @s run particle enchanted_hit ~ ~1 ~ 0.5 0.5 0.5 1 8
execute as @a[distance=..16] if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.enderman.teleport player @s ~ ~ ~ 0.7 1.5
execute as @a[distance=..16] if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.player.attack.crit player @s ~ ~ ~ 0.5 0.5

# Bespoke FX flourish (channel-gated; adds the in-palette warp cue)
execute at @s run function evercraft:fx/bespoke/ability/dimensional_cut
