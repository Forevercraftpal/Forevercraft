# True Strike — Gungnir
# Target gets Glowing + bonus 3 damage
advancement revoke @s only evercraft:artifacts/abilities/true_strike_trigger
execute at @s as @e[type=!player,distance=..5,limit=1,sort=nearest,nbt={HurtTime:10s}] run effect give @s glowing 5 0 false
execute at @s as @e[type=!player,distance=..5,limit=1,sort=nearest,nbt={HurtTime:10s}] run damage @s 3 evercraft:bonus_strike
execute at @s run particle enchanted_hit ~ ~1 ~ 0.3 0.5 0.3 0.5 5
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.player.attack.crit player @s ~ ~ ~ 1 1

# Generic tier FX (common→rare; no-ops at ornate+)
function evercraft:fx/tier/read_mainhand
execute at @s run function evercraft:fx/tier/proc

# Achievement tracking
scoreboard players add @s ach.weapon_abilities 1
