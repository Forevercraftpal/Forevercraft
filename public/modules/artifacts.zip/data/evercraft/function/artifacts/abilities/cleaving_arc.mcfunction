# Cleaving Arc — Double Axe (Uncommon Berserker)
# On hit: damages a second mob within 3 blocks for 3 damage (mini sweep)
# AR-P2-9: per-player tag suffix so two simultaneous swingers can't share a primary mark.

advancement revoke @s only evercraft:artifacts/abilities/cleaving_arc_trigger

execute store result storage evercraft:artifacts cleave_dispatch.pid int 1 run scoreboard players get @s companion.id
execute at @s run function evercraft:artifacts/abilities/cleaving_arc_inner with storage evercraft:artifacts cleave_dispatch

# Generic tier FX (common→rare; no-ops at ornate+)
function evercraft:fx/tier/read_mainhand
execute at @s run function evercraft:fx/tier/proc

# Achievement tracking
scoreboard players add @s ach.weapon_abilities 1
