# Winter Harvest — Frost Hoe
# On hit: Grants Resistance + Speed
advancement revoke @s only evercraft:artifacts/abilities/winter_harvest_trigger
effect give @s resistance 8 0 false
effect give @s speed 8 1 false
execute at @s run particle snowflake ~ ~0.5 ~ 0.3 0.3 0.3 0.02 5
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.glass.break player @s ~ ~ ~ 0.4 1.5
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.chime player @s ~ ~ ~ 0.4 1.8

# Generic tier FX (common→rare; no-ops at ornate+)
function evercraft:fx/tier/read_mainhand
execute at @s run function evercraft:fx/tier/proc

# Achievement tracking
scoreboard players add @s ach.weapon_abilities 1
