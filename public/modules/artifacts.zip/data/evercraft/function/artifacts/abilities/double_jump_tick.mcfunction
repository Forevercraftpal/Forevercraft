# Double Jump Tick - Runs every 2 ticks for responsive double jump
# Cloudstep Boots (Nimble Turtle Boots) ability

# Decrease cooldown for players that have one (already gated by score)
execute as @a[scores={ec.double_jump_cd=1..}] run scoreboard players remove @s ec.double_jump_cd 1

# Only process players actually wearing double jump boots (OPT Session 76 + AR-P2-1 tag-gate)
# Reset cooldown when on ground (can double jump again)
execute as @a[tag=ec.has_dj_boots] if predicate evercraft:on_ground run scoreboard players set @s ec.double_jump_cd 0

# Trigger double jump: has boots + sneaking + not on ground + no cooldown
execute as @a[tag=ec.has_dj_boots,scores={ec.double_jump_cd=0}] if predicate evercraft:is_sneaking if predicate evercraft:not_on_ground at @s run function evercraft:artifacts/abilities/double_jump

schedule function evercraft:artifacts/abilities/double_jump_tick 2t
