# Battle Tempo — Mauler (Common Dancer)
# Each hit increments tempo counter (max 5). At 5 stacks: AoE burst +4 damage in 3 blocks, reset.
# Stacks decay if no hit within 3 seconds (handled by battle_tempo_decay schedule).

advancement revoke @s only evercraft:artifacts/abilities/battle_tempo_trigger

# Increment tempo counter
scoreboard players add @s ec.battle_tempo 1

# BUG-002 FIX: Per-player cooldown instead of global schedule (3s = 3 ticks at 1s interval)
scoreboard players set @s ec.tempo_cd 3

# Feedback per stack (note particle trail building)
execute if score @s ec.battle_tempo matches 1..4 at @s run particle crit ~ ~1 ~ 0.2 0.2 0.2 0.1 2
execute if score @s ec.battle_tempo matches 1..4 if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.player.attack.weak player @s ~ ~ ~ 0.3 1.5

# At 5 stacks: AoE burst!
execute if score @s ec.battle_tempo matches 5.. at @s as @e[type=!player,distance=..3,limit=10] run damage @s 4 minecraft:generic
execute if score @s ec.battle_tempo matches 5.. at @s run particle explosion ~ ~1 ~ 0.5 0.5 0.5 0.1 3
execute if score @s ec.battle_tempo matches 5.. at @s run particle crit ~ ~1 ~ 1 0.5 1 0.2 10
execute if score @s ec.battle_tempo matches 5.. as @a[distance=..16] if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.player.attack.sweep player @s ~ ~ ~ 1.0 0.8
execute if score @s ec.battle_tempo matches 5.. as @a[distance=..16] if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.generic.explode player @s ~ ~ ~ 0.4 1.5

# Reset on burst
execute if score @s ec.battle_tempo matches 5.. run scoreboard players set @s ec.battle_tempo 0

# Generic tier FX (common→rare; no-ops at ornate+)
function evercraft:fx/tier/read_mainhand
execute at @s run function evercraft:fx/tier/proc

# Achievement tracking
scoreboard players add @s ach.weapon_abilities 1
