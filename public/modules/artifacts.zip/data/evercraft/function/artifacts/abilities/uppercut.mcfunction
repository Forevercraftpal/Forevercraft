# Uppercut — Golden Gauntlet + Meteor Fist Enhancement
# Base: Launches target into the air with Levitation
# Enhancement: If target already has Levitation (from prior uppercut), deal 3x damage + slam down
advancement revoke @s only evercraft:artifacts/abilities/uppercut_trigger

# Check if target already has Levitation (Meteor Fist combo)
execute at @s as @e[type=!player,distance=..5,limit=1,sort=nearest,nbt={HurtTime:10s}] if data entity @s {active_effects:[{id:"minecraft:levitation"}]} run function evercraft:artifacts/abilities/meteor_fist
execute at @s as @e[type=!player,distance=..5,limit=1,sort=nearest,nbt={HurtTime:10s}] unless data entity @s {active_effects:[{id:"minecraft:levitation"}]} run effect give @s levitation 1 10 false

# Visual/audio feedback (base)
execute at @s run particle cloud ~ ~1 ~ 0.3 0.2 0.3 0.1 5
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.anvil.land player @s ~ ~ ~ 1 0.7
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.basedrum player @s ~ ~ ~ 0.8 0.5

# Generic tier FX (common→rare; no-ops at ornate+)
function evercraft:fx/tier/read_mainhand
execute at @s run function evercraft:fx/tier/proc

# Achievement tracking
scoreboard players add @s ach.weapon_abilities 1
