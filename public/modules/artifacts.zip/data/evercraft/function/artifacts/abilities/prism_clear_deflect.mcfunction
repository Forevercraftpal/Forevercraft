# Clear the pol_deflected tag from all projectiles (Prism of Light deflect cleanup).
# Runs 3 seconds after a deflection (schedule-append from prism_deflect) so the same projectile
# isn't re-deflected every tick. Mirrors artifacts/graviton_core/clear_deflect_tag.
tag @e[type=!player,tag=pol_deflected] remove pol_deflected
