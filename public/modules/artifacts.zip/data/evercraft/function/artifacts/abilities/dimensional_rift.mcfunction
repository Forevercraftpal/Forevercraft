# Dimensional Rift — Portal Staff Enhancement (Mythical)
# Sneak + hit creates a portal trap at target location
# Summons a marker with portal particles for 5s. Mobs that enter take 5 damage + Levitation III (2s)

# Summon rift marker at target location (with gametime tag for init)
execute at @s at @e[type=!player,distance=..5,limit=1,sort=nearest,nbt={HurtTime:10s}] run summon marker ~ ~ ~ {Tags:["ec.rift","ec.rift_new","ec.rift_init"]}
# Store spawn gametime for chunk-safe expiry
execute as @e[tag=ec.rift_init] store result entity @s data.spawn_time int 1 run time query gametime
execute as @e[tag=ec.rift_init] run tag @s remove ec.rift_init

# Apply immediate damage + levitation to the hit target
execute at @s as @e[type=!player,distance=..5,limit=1,sort=nearest,nbt={HurtTime:10s}] run effect give @s levitation 2 2 false

# Visual/audio feedback
execute at @s at @e[type=!player,distance=..5,limit=1,sort=nearest,nbt={HurtTime:10s}] run particle portal ~ ~1 ~ 1 1 1 0.5 20
execute at @s at @e[type=!player,distance=..5,limit=1,sort=nearest,nbt={HurtTime:10s}] run particle reverse_portal ~ ~0.5 ~ 0.8 0.2 0.8 0.3 13
# Bespoke FX flourish (channel-gated; positioned at the struck target)
execute at @s at @e[type=!player,distance=..5,limit=1,sort=nearest,nbt={HurtTime:10s}] run function evercraft:fx/bespoke/ability/dimensional_rift
data modify storage evercraft:notify stage.c set value [{text:"Dimensional Rift!",color:"#8B00FF",bold:true}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute as @a[distance=..16] if score @s ec.fx_snd matches 1.. run playsound minecraft:block.end_portal.spawn player @s ~ ~ ~ 0.3 2
execute as @a[distance=..16] if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.enderman.teleport player @s ~ ~ ~ 0.5 0.5
