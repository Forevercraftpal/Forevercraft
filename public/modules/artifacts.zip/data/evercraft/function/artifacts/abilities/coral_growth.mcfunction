# Coral Growth — Prismarine Shovel
# On hit: Regeneration burst + coral particles
advancement revoke @s only evercraft:artifacts/abilities/coral_growth_trigger
effect give @s regeneration 5 1 false
execute at @s run particle bubble ~ ~0.5 ~ 1 0.5 1 0.05 8
execute at @s run particle happy_villager ~ ~1 ~ 0.5 0.5 0.5 0 3
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.coral_block.place player @s ~ ~ ~ 0.8 1

# Generic tier FX (common→rare; no-ops at ornate+)
function evercraft:fx/tier/read_mainhand
execute at @s run function evercraft:fx/tier/proc

# Achievement tracking
scoreboard players add @s ach.weapon_abilities 1
