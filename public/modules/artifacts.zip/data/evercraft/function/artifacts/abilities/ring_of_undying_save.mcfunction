# Ring of Undying — Custom Death Save (Absorption IV revive)
# Triggers when the bearer drops below 3 hearts (health_below_6) with the Ring carried (container /
# offhand / satchel). The "budget totem": revives with a fixed Absorption IV (30s) so the lore line
# "Revives with Absorption IV (30s)" is true. Shorter 2-minute cooldown vs the phoenix's full rebirth.
# G6 / m4: the ec.cd_undying_rev gate is idempotent + multi-copy-safe by construction — the cooldown is
# SET after the first fire, so two copies of the Ring still grant ONE revive, never two.
# Absorption is SET to a fixed level (effect give SETs, max-not-sum), matching the phoenix idiom.

# Heal so the bearer survives the otherwise-lethal blow
effect give @s instant_health 1 1 false

# Revive buffs — Absorption IV (30s, the named lore effect) + a brief Regen so the heal lands cleanly
effect give @s absorption 30 3 false
effect give @s regeneration 8 1 false

# Revival visual + audio feedback (totem-grade pop)
particle totem_of_undying ~ ~1 ~ 0.5 1 0.5 0.5 35
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:item.totem.use player @s ~ ~ ~ 1 1
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.beacon.activate player @s ~ ~ ~ 0.6 1.4

# Set 2-minute cooldown — read by player_tick (decremented there, one writer besides this source-set).
# 1s tick-down cadence -> VALUE = SECONDS, so 120 = 2 minutes.
scoreboard players set @s ec.cd_undying_rev 120

# Actionbar notification
data modify storage evercraft:notify stage.c set value [{text:"The Ring of Undying restores you!",color:"gold"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
