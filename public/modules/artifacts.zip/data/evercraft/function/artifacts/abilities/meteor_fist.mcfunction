# Meteor Fist — Golden Gauntlet combo hit
# Triggered when hitting a target that already has Levitation
# Removes Levitation, deals 5 bonus damage, slam particles
effect clear @s levitation
damage @s 5 minecraft:mob_attack
execute at @s run particle explosion ~ ~0.5 ~ 0.5 0.3 0.5 0.1 4
execute at @s run particle crit ~ ~1 ~ 0.8 0.5 0.8 0.2 8
execute at @s as @a[distance=..16] if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.generic.explode player @s ~ ~ ~ 0.6 1.2
execute at @s as @a[distance=..16] if score @s ec.fx_snd matches 1.. run playsound minecraft:block.anvil.land player @s ~ ~ ~ 0.8 0.5

# Generic tier FX (common→rare; no-ops at ornate+)
function evercraft:fx/tier/read_mainhand
execute at @s run function evercraft:fx/tier/proc
