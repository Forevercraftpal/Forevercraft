# Claude's Gift — duplicate ONE fresh death-drop. Run as + at the original item entity.
# Both the original and the copy carry cg_doubled so neither can ever be doubled again
# (also guards overlapping kills from two Gift carriers).
tag @s add cg_doubled
summon item ~ ~0.1 ~ {PickupDelay:10s,Tags:["cg_doubled","cg_dup_new"],Item:{id:"minecraft:stone",count:1}}
data modify entity @e[type=item,tag=cg_dup_new,limit=1,sort=nearest,distance=..2] Item set from entity @s Item
tag @e[type=item,tag=cg_dup_new,distance=..2] remove cg_dup_new
particle end_rod ~ ~0.3 ~ 0.15 0.15 0.15 0.02 6 normal @a[distance=..16,scores={ec.fx_vis=2..}]
