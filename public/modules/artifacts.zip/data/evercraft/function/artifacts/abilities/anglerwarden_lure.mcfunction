# Anglerwarden's Sigil (C34, Family J — art-J) — Lure II + Luck of the Sea III on held rod
# The Ornate rod head: strictly ABOVE Angler's Pearl (Lure II + LotS I) by its higher LotS III, and
# above Dockhand's Knot (Lure I). Mirrors the fast_fishing inject idiom. Reuses the existing shared
# item modifiers evercraft:fishing_lure_2 (set Lure 2, add) + evercraft:fishing_luck_3 (set LotS 3,
# add). Lure-on-rod is NOT fortune-rewritten. A tier ladder above the existing rod charms, not a copy.

# Early-exit unless the player holds the Sigil
execute unless items entity @s container.* *[custom_data~{artifact:"anglerwardens_sigil"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"anglerwardens_sigil"}] run return 0

# Apply Lure II + LotS III to a held fishing rod lacking each, then tag for cleanup
execute if items entity @s weapon.mainhand minecraft:fishing_rod unless items entity @s weapon.mainhand *[enchantments~[{enchantment:"minecraft:lure",levels:{min:2}}]] run item modify entity @s weapon.mainhand evercraft:fishing_lure_2
execute if items entity @s weapon.mainhand minecraft:fishing_rod unless items entity @s weapon.mainhand *[enchantments~[{enchantment:"minecraft:luck_of_the_sea",levels:{min:3}}]] run item modify entity @s weapon.mainhand evercraft:fishing_luck_3
execute if items entity @s weapon.mainhand minecraft:fishing_rod run tag @s add ec.anglerwarden_fishing
