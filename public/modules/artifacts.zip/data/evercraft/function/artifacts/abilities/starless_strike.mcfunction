# The Starless Night — Mythical Sword
# On Hit: Blindness (3s) + Wither I (5s)
# +3 bonus damage at night (DayTime 13000-23000)

# Revoke for re-trigger
advancement revoke @s only evercraft:artifacts/abilities/starless_strike_trigger

# Apply Blindness + Wither to hit target
execute at @s as @e[type=!player,type=!item,distance=..5,limit=1,sort=nearest,nbt={HurtTime:10s}] run effect give @s blindness 3 0 false
execute at @s as @e[type=!player,type=!item,distance=..5,limit=1,sort=nearest,nbt={HurtTime:10s}] run effect give @s wither 5 0 false

# Night bonus — +3 damage when DayTime is 13000-23000
execute store result score #time ec.var run time query minecraft:day
execute if score #time ec.var matches 13000..23000 at @s as @e[type=!player,type=!item,distance=..5,limit=1,sort=nearest,nbt={HurtTime:10s}] run damage @s 3 minecraft:player_attack

# Visual/audio feedback
particle smoke ~ ~1 ~ 0.3 0.5 0.3 0.02 5
particle sculk_soul ~ ~1 ~ 0.3 0.3 0.3 0.02 3
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bass player @s ~ ~ ~ 0.3 1.5

# Generic tier FX (common→rare; no-ops at ornate+)
function evercraft:fx/tier/read_mainhand
execute at @s run function evercraft:fx/tier/proc

# Achievement tracking
scoreboard players add @s ach.weapon_abilities 1
