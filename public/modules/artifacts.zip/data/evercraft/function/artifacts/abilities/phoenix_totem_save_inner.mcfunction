# Phoenix rebirth BODY — the shared heal + buffs + visuals + notify, WITHOUT the cooldown set.
# Extracted so multiple bearers can reuse ONE rebirth without duplicating the save logic, while each
# caller SETs its OWN cooldown id (the one-writer for that cooldown lives in the caller, not here).
# Callers: phoenix_totem_save (ec.cd_phoenix 300 = 5min), phoenix_feather_save (ec.cd_feather 600 = 10min).
# G6: Absorption is SET to a fixed level here (max-not-sum) so a Soulguard Aegis death-save bucket
# never stacks revive Absorption across pieces — the leaf-level save uses the fixed-level idiom
# (effect give SETs, not adds).

# Full heal (totem-of-undying-grade rebirth)
effect give @s instant_health 1 4 false

# Protective rebirth buffs (totem-like save; Absorption set to a fixed level, not summed)
effect give @s absorption 8 3 false
effect give @s resistance 8 2 false
effect give @s fire_resistance 10 0 false
effect give @s regeneration 8 1 false

# Phoenix rebirth visual feedback
particle totem_of_undying ~ ~1 ~ 0.5 1 0.5 0.5 40
particle flame ~ ~1 ~ 0.6 1 0.6 0.02 30
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:item.totem.use player @s ~ ~ ~ 1 1
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.blaze.shoot player @s ~ ~ ~ 0.8 0.8

# Actionbar notification
data modify storage evercraft:notify stage.c set value [{text:"The Phoenix rises again!",color:"gold",bold:true}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
