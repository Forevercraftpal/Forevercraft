# Redstone Heart — boost one brewing stand (positioned at the block). BrewTime counts
# DOWN (400 -> 0 completes), so 4x = subtract 60/s, clamped to 1 so the final brew tick
# stays engine-owned. Bail unless actually brewing (BrewTime >= 1).
execute store result score #rh_brew ec.temp run data get block ~ ~ ~ BrewTime
execute unless score #rh_brew ec.temp matches 1.. run return 0
scoreboard players remove #rh_brew ec.temp 60
execute if score #rh_brew ec.temp matches ..0 run scoreboard players set #rh_brew ec.temp 1
execute store result block ~ ~ ~ BrewTime short 1 run scoreboard players get #rh_brew ec.temp
