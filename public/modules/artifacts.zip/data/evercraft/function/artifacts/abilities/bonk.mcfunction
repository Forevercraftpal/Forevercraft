# BONK! — Frying Pan (Uncommon Striker)
# On kill: anvil sound at max volume + "BONK!" actionbar to all nearby players

advancement revoke @s only evercraft:artifacts/abilities/bonk_trigger

# The almighty BONK
execute as @a[distance=..30] if score @s ec.fx_snd matches 1.. run playsound minecraft:block.anvil.land player @s ~ ~ ~ 1.0 0.6
data modify storage evercraft:notify stage.c set value [{text:"BONK!",color:"gold",bold:true}]
scoreboard players set #ndur ec.temp 45
execute at @s as @a[distance=..30] run function evercraft:util/notify/emit

# Particles at death location
execute at @s run particle crit ~ ~1 ~ 0.5 0.5 0.5 0.2 8
execute at @s run particle explosion ~ ~1 ~ 0.3 0.3 0.3 0.05 2

# Generic tier FX (common→rare; no-ops at ornate+)
function evercraft:fx/tier/read_mainhand
execute at @s run function evercraft:fx/tier/proc

# Achievement tracking
scoreboard players add @s ach.weapon_abilities 1
