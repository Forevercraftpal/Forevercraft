# Fortune Bonus — Apply fortune enchant + tag player as holder
# Run as player who is holding a non-awakened fortune_bonus tool without the tag
# Skip if already has Fortune 5+ (don't stack)
execute unless items entity @s weapon.mainhand *[enchantments~[{enchantment:"minecraft:fortune",levels:{min:5b}}]] run item modify entity @s weapon.mainhand evercraft:fortune_add_5
tag @s add ec.holding_fortune_tool
