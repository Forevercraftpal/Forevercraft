# Berserker Totem — Berserker Frenzy (on-kill proc)
# Fires on any player_killed_entity; checks for berserker_totem held (inventory/offhand/satchel).
# Grants Strength II + Speed II for 10s after a kill; stacking kills refresh + escalate (the
# strength_on_kill kill-chain idiom, but on its OWN dedicated ec.berserk_chain / ec.berserk_cd
# counters so it never clobbers the weapon Kill Chain — one writer per scoreboard).

# Revoke for re-trigger
advancement revoke @s only evercraft:artifacts/abilities/berserker_totem_kill_trigger

# Early exit if player doesn't hold the totem (inventory / offhand / satchel)
execute unless items entity @s container.* *[custom_data~{artifact:"berserker_totem"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"berserker_totem"}] unless entity @s[tag=ec.sat_berserker_totem] run return 0

# Increment frenzy stack counter + reset its 10s decay window (decremented in accessories/tick)
scoreboard players add @s ec.berserk_chain 1
scoreboard players set @s ec.berserk_cd 10

# Frenzy: Strength II + Speed II for 10s (matches lore "Strength II + Speed II for 10s after kill")
effect give @s strength 10 1 false
effect give @s speed 10 1 false

# Visual/audio feedback — escalates with the frenzy stack
particle minecraft:angry_villager ~ ~1 ~ 0.3 0.5 0.3 0.02 4
execute if score @s ec.berserk_chain matches 3.. at @s run particle minecraft:crit ~ ~1 ~ 0.5 0.8 0.5 0.1 12
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.anvil.land player @s ~ ~ ~ 0.4 0.6
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.basedrum player @s ~ ~ ~ 0.5 0.7

# Generic tier FX (common→rare; no-ops at ornate+)
function evercraft:fx/tier/read_mainhand
execute at @s run function evercraft:fx/tier/proc
