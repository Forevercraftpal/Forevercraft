# Berserker Totem — Lifesteal (on-hit accessory proc) — exquisite, Wave 3 §2E
# The orphaned lifesteal as an accessory on-hit win: a bare player_hurt_entity trigger with an
# artifact:"berserker_totem" early-exit (mirrors blaze_core_hit). Heals a ½-heart FLOOR per hit via a tiny
# Regeneration I tick (auto-clamps at max_health; overheal-safe — NOT instant_health, which heals 2 hearts
# and is too strong per AUDIT §2E). The berserker_totem's Frenzy (on-kill, Strength/Speed) and its passive
# floor grant NO healing, so this does not heal-stack with the totem's own kit; the ec.regen_capped gate
# (fallback-aware, set in player_tick) further prevents stacking with any other regen source already active.

# Revoke for re-trigger (so the next hit fires it again)
advancement revoke @s only evercraft:artifacts/abilities/berserker_totem_hit_trigger

# Early exit if the player doesn't carry the totem (inventory / offhand / satchel)
execute unless items entity @s container.* *[custom_data~{artifact:"berserker_totem"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"berserker_totem"}] unless entity @s[tag=ec.sat_berserker_totem] run return 0

# Lifesteal — ½-heart floor heal. Regen I heals 1 HP per 50 ticks (2.5s), so a 3s window yields exactly
# ONE heal tick = 1 HP = ½ heart (the AUDIT §2E floor). Skipped if a stronger regen source is already up.
execute unless entity @s[tag=ec.regen_capped] run effect give @s regeneration 3 0 true

# Subtle blood-mote feedback on the wearer
particle minecraft:damage_indicator ~ ~1.2 ~ 0.2 0.3 0.2 0 2
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.player.levelup player @s ~ ~ ~ 0.2 0.8
