# Soulguard Aegis — Consolidated Death Save (G6: ONE death-save bucket)
# Triggers when player health drops below 3 hearts (health_below_6) while a Soulguard death-save
# node is held: the Grand Totem (Phoenix/Soul auto-revive), the Lifewarden (Void Recall + regen),
# or the grand Soulguard Aegis. G6 LAW: every D death-save (Phoenix Totem auto-revive, Soul
# Protection shield, Void Heart recall) is COLLAPSED into this ONE shared cooldown bucket (ec.cd_save)
# so a Soulguard player cannot chain three independent revives. Absorption is SET to a fixed level
# (max-not-sum) here, exactly like the leaf saves (soul_protection_save / void_heart_save /
# phoenix_totem_save) — effect give SETs, never sums — so the bucket never stacks revive Absorption
# across the absorbed pieces.
# Run as @s = the player, at @s. The call site (player_tick a7 death-save block) already gates on
# health_below_6 + `unless score @s ec.cd_save matches 1..` so this fires at most once per cooldown.

# Full heal — totem-of-undying-grade rebirth (the strongest of the absorbed saves)
effect give @s instant_health 1 4 false

# Protective rebirth buffs (Absorption SET to a fixed level, not summed — G6 max-not-sum)
effect give @s absorption 10 3 false
effect give @s resistance 10 2 false
effect give @s fire_resistance 12 0 false
effect give @s regeneration 10 1 false
# Slow Falling — safe landing after any displacement (the Void Heart recall idiom)
effect give @s slow_falling 10 0 false

# Aegis rebirth visual feedback (phoenix flame + totem)
particle totem_of_undying ~ ~1 ~ 0.5 1 0.5 0.5 50
particle flame ~ ~1 ~ 0.6 1 0.6 0.02 30
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:item.totem.use player @s ~ ~ ~ 1 1
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.blaze.shoot player @s ~ ~ ~ 0.8 0.8

# Set the SHARED 5-minute death-save cooldown (300 = 5min) — the ONE bucket for ALL D revives.
# Read + decremented 1/sec in player_tick's 1s-cadence cd block (one writer = the source-set here +
# the single tick-down there, the established cd_soul / cd_void / cd_phoenix two-function idiom).
# NOTE 2026-06-05: was 6000 ("ticks") but the decrement is PER-SECOND, so 6000 = 100 min; corrected to 300.
scoreboard players set @s ec.cd_save 300

# Actionbar notification
data modify storage evercraft:notify stage.c set value [{text:"The Soulguard holds!",color:"gold"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
