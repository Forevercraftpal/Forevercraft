# Sculk Heart — Death Harvest (bonus XP on kill)
# Fires on any player_killed_entity; checks for sculk_heart in inventory

# Revoke for re-trigger
advancement revoke @s only evercraft:artifacts/abilities/sculk_heart_kill_trigger

# Early exit if player doesn't have sculk heart
execute unless items entity @s container.* *[custom_data~{artifact:"sculk_heart"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"sculk_heart"}] run return 0

# Bonus XP orbs (Death Harvest "2x XP" — spawns extra XP at the kill site)
summon experience_orb ~ ~0.5 ~ {Value:7}

# Bonus-drop roll (the real "rare loot chance / Looting-equivalent" mechanic, replacing the dead
# +50% rare-loot claim). 25% chance per kill for a bonus reward; the ore_double_check random-gate
# idiom (random value 1..100, gate on the low band). Tiered so commons are common, rares are rare.
execute store result score @s ec.artifact_roll run random value 1..100
execute if score @s ec.artifact_roll matches 1..15 at @s run summon experience_orb ~ ~0.5 ~ {Value:12}
execute if score @s ec.artifact_roll matches 16..23 at @s run give @s minecraft:iron_nugget 1
execute if score @s ec.artifact_roll matches 24..25 at @s run give @s minecraft:emerald 1
# Visual cue when the bonus actually procs (the low 1..25 band)
execute if score @s ec.artifact_roll matches 1..25 at @s run particle minecraft:soul ~ ~0.8 ~ 0.4 0.4 0.4 0.04 8
execute if score @s ec.artifact_roll matches 1..25 if score @s ec.fx_snd matches 1.. run playsound minecraft:block.sculk_catalyst.bloom player @s ~ ~ ~ 0.7 1.4

# Visual feedback
particle sculk_soul ~ ~0.5 ~ 0.5 0.3 0.5 0.02 4
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.sculk.spread player @s ~ ~ ~ 0.8 1.2

# Generic tier FX (common→rare; no-ops at ornate+)
function evercraft:fx/tier/read_mainhand
execute at @s run function evercraft:fx/tier/proc
