# Cleaving Arc inner — per-pid tag suffix keeps two simultaneous swingers from sharing a primary mark.
# Macro: {pid:<int>}
# Run as = swinger; at @s = swinger position (set by dispatcher).

# Tag the primary target so we can skip it
$execute as @e[type=!player,distance=..5,limit=1,sort=nearest,nbt={HurtTime:10s}] run tag @s add ec.cleave_primary.$(pid)

# Find a second mob near the primary target and damage it
$execute at @e[tag=ec.cleave_primary.$(pid),limit=1] as @e[type=!player,distance=..3,limit=1,sort=nearest,tag=!ec.cleave_primary.$(pid)] run damage @s 3 minecraft:generic
$execute at @e[tag=ec.cleave_primary.$(pid),limit=1] as @e[type=!player,distance=..3,limit=1,sort=nearest,tag=!ec.cleave_primary.$(pid)] at @s run particle sweep_attack ~ ~1 ~ 0 0 0 0 1

# Visual + audio for the arc
$execute at @e[tag=ec.cleave_primary.$(pid),limit=1] run particle sweep_attack ~ ~1 ~ 0.5 0.3 0.5 0 2
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.player.attack.sweep player @s ~ ~ ~ 0.8 1.0

# Cleanup tag
$tag @e[tag=ec.cleave_primary.$(pid)] remove ec.cleave_primary.$(pid)
