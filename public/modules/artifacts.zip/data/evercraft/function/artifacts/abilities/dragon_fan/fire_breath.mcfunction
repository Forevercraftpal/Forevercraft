# Dragon's Breath - Fire Laser Beam
# Called on right-click via consume_item advancement
# 50 damage direct hit, ignites targets, 300 block range, 15s cooldown

# Check cooldown
data modify storage evercraft:notify stage.c set value [{text:"Dragon's Breath on cooldown!",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute if score @s ec.df_cd matches 1.. run function evercraft:util/notify/emit
execute if score @s ec.df_cd matches 1.. if score @s ec.fx_snd matches 1.. run playsound minecraft:block.fire.extinguish player @s ~ ~ ~ 0.5 1.5
execute if score @s ec.df_cd matches 1.. run return 0

# Set 15s cooldown (300 ticks)
scoreboard players set @s ec.df_cd 300

# Tag self to exclude from raycast
tag @s add ec.dragon_fire

# Initialize raycast tracking
scoreboard players set #df_hit ec.var 0
scoreboard players set #df_dist ec.var 0

# Sound effects
execute at @s as @a[distance=..25] if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.blaze.shoot player @s ~ ~ ~ 1.0 0.8
execute at @s as @a[distance=..25] if score @s ec.fx_snd matches 1.. run playsound minecraft:item.firecharge.use player @s ~ ~ ~ 0.8 1.0
execute at @s as @a[distance=..25] if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.firework_rocket.large_blast player @s ~ ~ ~ 0.5 1.67

# Get UUID for damage attribution
function evercraft:treasure/database/get with entity @s

# Execute raycast from eyes (at @s sets position context for ^ ^ ^ coordinates)
execute at @s anchored eyes run function evercraft:artifacts/abilities/dragon_fan/fire_raycast_step

# Cleanup
tag @s remove ec.dragon_fire

# Fire notification — single line (the second "fired (cooldown)" emit was a redundant dupe for
# the same activation, removed 2026-06-02 to match the one-success-line norm).
data modify storage evercraft:notify stage.c set value [{text:"Dragon's Breath! ",color:"gold"},{text:"(15s cooldown)",color:"dark_gray"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
