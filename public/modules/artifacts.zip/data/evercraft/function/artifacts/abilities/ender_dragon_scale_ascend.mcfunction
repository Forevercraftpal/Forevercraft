# Ender Dragon Scale — Dragon Ascendant (sneak-active launch + glide)
# Called from the ender_dragon_scale block in artifacts/accessories/player_tick when the bearer is
# sneaking AND off cooldown (ec.cd_dragon). Replaces the infeasible "elytra flight without elytra" with a
# feasible burst: a brief Levitation launch (~2s rise) that hands off to Slow Falling for the glide down,
# trailing dragon's breath. The void-save half (teleport-up below the void) lives passively in player_tick
# (the voidscale_shard ec._vy idiom). Cooldown ec.cd_dragon (15s) is SET here, decremented in player_tick
# (one writer beside this source-set). 1s tick-down cadence -> VALUE = SECONDS, so 15 = 15 seconds.

# Launch — Levitation IV for 2s (the rise). effect give SETs (max-not-sum).
effect give @s levitation 2 3 false

# Schedule the glide hand-off (Slow Falling + dragon's-breath trail) after the ~2s rise (40t).
schedule function evercraft:artifacts/abilities/ender_dragon_scale_glide 40t

# Extra dragon's-breath trail puffs during the rise (no objective / unbounded loop needed)
execute at @s run particle dragon_breath ~ ~0.5 ~ 0.4 0.5 0.4 0.04 20
schedule function evercraft:artifacts/abilities/ender_dragon_scale_trail 15t
schedule function evercraft:artifacts/abilities/ender_dragon_scale_trail 30t

# Launch visual + audio feedback
execute at @s run particle end_rod ~ ~0.2 ~ 0.4 0.2 0.4 0.1 25
execute at @s if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.wind_charge.wind_burst player @s ~ ~ ~ 1 1
execute at @s if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.ender_dragon.growl player @s ~ ~ ~ 0.5 1.4

# Set 15-second cooldown (read + decremented in player_tick, one writer beside this set)
scoreboard players set @s ec.cd_dragon 15

# Actionbar notification
data modify storage evercraft:notify stage.c set value [{text:"Dragon Ascendant! Take to the skies.",color:"dark_purple"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
