# Phoenix Totem — Auto-Revive (Death Save)
# Triggers when player health drops below 3 hearts (health_below_6) with Phoenix Totem in inventory.
# The mythical D-Soulguard totem: full rebirth + protective buffs + 5-minute cooldown.
# The rebirth body (heal + buffs + visuals + notify) lives in phoenix_totem_save_inner so the ornate
# Phoenix Feather can reuse the SAME rebirth without duplicating the save logic; this fn owns ONLY the
# totem's cooldown (ec.cd_phoenix). Newcomer-exempt + Soulguard-suppression gating live in player_tick.

# Shared rebirth body (heal + buffs + visuals + notify)
function evercraft:artifacts/abilities/phoenix_totem_save_inner

# Set 5 minute cooldown (300 = 5min, decremented 1/sec in player_tick's 1s-cadence cd block, one writer).
# NOTE 2026-06-05: was 6000 ("ticks") but the decrement is PER-SECOND, so 6000 = 100 min; corrected to 300.
scoreboard players set @s ec.cd_phoenix 300
