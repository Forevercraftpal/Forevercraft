# Power Shot - +2 bonus damage on arrows
# The damage bonus is already applied via the arrow, this just gives feedback
# Note: For actual damage, the bow should have Power enchant or we deal extra damage here

# Revoke advancement so it can trigger again
advancement revoke @s only evercraft:artifacts/abilities/power_shot_trigger

# Deal 2 extra damage to the target (simulating +2 damage)
execute at @s as @e[type=!player,distance=..50,limit=1,sort=nearest,nbt={HurtTime:10s}] run damage @s 2 minecraft:arrow

# Visual/audio feedback
execute at @s run particle crit ~ ~1 ~ 0.3 0.3 0.3 0.1 4
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.arrow.hit_player player @s ~ ~ ~ 0.5 1.3

# Generic tier FX (common→rare; no-ops at ornate+)
function evercraft:fx/tier/read_mainhand
execute at @s run function evercraft:fx/tier/proc

# Achievement tracking
scoreboard players add @s ach.weapon_abilities 1
