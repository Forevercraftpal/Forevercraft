# Swift Strikes + Flowing Strikes — Battlestaff (Rare Beastlord)
# On hit: Increment flow counter. Every 3rd hit grants Haste I.
# If already Haste I, upgrades to Haste II.
# Counter resets after 3s of no hits (via schedule).

advancement revoke @s only evercraft:artifacts/abilities/swift_strikes_trigger

# Increment flow counter
scoreboard players add @s ec.flow_hits 1

# BUG-003 FIX: Per-player cooldown instead of global schedule (3s = 3 ticks at 1s interval)
scoreboard players set @s ec.flow_cd 3

# Every 3rd hit: grant or upgrade Haste
execute if score @s ec.flow_hits matches 3 run effect give @s haste 5 0 false
execute if score @s ec.flow_hits matches 3 at @s run particle enchant ~ ~1 ~ 0.3 0.5 0.3 0.5 4
execute if score @s ec.flow_hits matches 3 if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.player.attack.sweep player @s ~ ~ ~ 0.5 1.8
execute if score @s ec.flow_hits matches 3 run scoreboard players set @s ec.flow_hits 0

# At 6+ hits (2nd cycle while Haste I active): upgrade to Haste II
execute if score @s ec.flow_hits matches 6.. run effect give @s haste 5 1 false
execute if score @s ec.flow_hits matches 6.. at @s run particle enchant ~ ~1 ~ 0.5 0.8 0.5 1 8
execute if score @s ec.flow_hits matches 6.. if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.player.attack.sweep player @s ~ ~ ~ 0.7 2.0
execute if score @s ec.flow_hits matches 6.. run scoreboard players set @s ec.flow_hits 0

# Small visual per hit (building momentum)
execute at @s run particle enchant ~ ~1 ~ 0.2 0.3 0.2 0.3 2

# Generic tier FX (common→rare; no-ops at ornate+)
function evercraft:fx/tier/read_mainhand
execute at @s run function evercraft:fx/tier/proc

# Achievement tracking
scoreboard players add @s ach.weapon_abilities 1
