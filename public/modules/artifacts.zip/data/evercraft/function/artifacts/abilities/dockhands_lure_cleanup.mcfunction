# Dockhand's Knot (C31, Family J — art-J) — Cleanup the injected Lure
# Mirrors fast_fishing_cleanup: when the player no longer holds the Knot OR is no longer holding a
# fishing rod, strip the injected enchant from whatever rod they hold and clear the tag. Uses the
# shared fishing_remove modifier (same as Angler's Pearl). Order: this runs AFTER dockhands_lure in
# player_tick, gated on the ec.dockhands_knot_fishing tag, so a still-valid holder returns early.

# Still holding the Knot AND a rod? leave the lure in place.
execute if items entity @s container.* *[custom_data~{artifact:"dockhands_knot"}] if items entity @s weapon.mainhand minecraft:fishing_rod run return 0
execute if items entity @s weapon.offhand *[custom_data~{artifact:"dockhands_knot"}] if items entity @s weapon.mainhand minecraft:fishing_rod run return 0

# Otherwise strip the injected enchant and clear the tag.
execute if items entity @s weapon.mainhand minecraft:fishing_rod run item modify entity @s weapon.mainhand evercraft:fishing_remove
tag @s remove ec.dockhands_knot_fishing
