# Sculk Singularity — Singularity Shield: deflect a projectile away from the bearer (the feasible
# substitute for "projectiles curve away"). Adapted from artifacts/graviton_core/deflect_projectile,
# tagged sng_deflected so each projectile is only deflected once (cleared 3s later by
# sculk_singularity_clear_deflect). Arrows are replaced with an ownerless copy; non-arrows redirected.
# @s = the projectile, position = the projectile.

tag @s add sng_deflected

# Visual feedback (sculk-warp pulse)
execute at @s run particle minecraft:sculk_soul ~ ~ ~ 0.3 0.3 0.3 0.02 6
execute at @s as @a[distance=..10] if score @s ec.fx_snd matches 1.. run playsound minecraft:block.sculk_sensor.clicking hostile @s ~ ~ ~ 0.5 0.6

# === ARROWS: Replace with ownerless copy ===
execute store result score #sng_mx ec.temp run random value -5..5
execute store result score #sng_mz ec.temp run random value -5..5
execute if entity @s[type=arrow] at @s run summon arrow ~ ~ ~ {Tags:["sng_deflected","sng_new"],pickup:0b,life:1180s}
execute if entity @s[type=spectral_arrow] at @s run summon spectral_arrow ~ ~ ~ {Tags:["sng_deflected","sng_new"],pickup:0b,life:1180s}
execute if entity @e[tag=sng_new,limit=1] as @e[tag=sng_new,limit=1] store result entity @s Motion[0] double 0.1 run scoreboard players get #sng_mx ec.temp
execute if entity @e[tag=sng_new,limit=1] as @e[tag=sng_new,limit=1] run data modify entity @s Motion[1] set value 0.5d
execute if entity @e[tag=sng_new,limit=1] as @e[tag=sng_new,limit=1] store result entity @s Motion[2] double 0.1 run scoreboard players get #sng_mz ec.temp
execute if entity @e[tag=sng_new,limit=1] as @e[tag=sng_new,limit=1] run tag @s remove sng_new
execute if entity @s[type=arrow] run kill @s
execute if entity @s[type=spectral_arrow] run kill @s

# === NON-ARROWS: Redirect motion directly ===
execute unless entity @s[type=arrow] unless entity @s[type=spectral_arrow] run data modify entity @s Motion[1] set value 0.5d
execute unless entity @s[type=arrow] unless entity @s[type=spectral_arrow] store result entity @s Motion[0] double 0.1 run scoreboard players get #sng_mx ec.temp
execute unless entity @s[type=arrow] unless entity @s[type=spectral_arrow] store result entity @s Motion[2] double 0.1 run scoreboard players get #sng_mz ec.temp

# Remove the tag after 3 seconds (allows re-deflection of new projectiles)
schedule function evercraft:artifacts/abilities/sculk_singularity_clear_deflect 60t append
