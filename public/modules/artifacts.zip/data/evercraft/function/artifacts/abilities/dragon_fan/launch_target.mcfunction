# Launch Target - Sends mob flying up to 50 blocks
# Runs as the target entity

# Apply massive upward velocity
# Motion[1] = vertical velocity, 3.5 = ~50 blocks high
data merge entity @s {Motion:[0.0d,3.5d,0.0d]}

# Visual and sound effects
particle gust ~ ~ ~ 0.5 0.5 0.5 0.2 10
particle cloud ~ ~ ~ 0.3 0.3 0.3 0.1 8
execute as @a if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.wind_charge.wind_burst hostile @s ~ ~ ~ 1.0 0.8
execute as @a if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.flute hostile @s ~ ~ ~ 1.0 0.6

# Announce the launch
data modify storage evercraft:notify stage.c set value [{text:"Skyward Strike!",color:"yellow",bold:true}]
scoreboard players set #ndur ec.temp 45
execute as @a[distance=..32] run function evercraft:util/notify/emit
