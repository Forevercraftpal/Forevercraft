# Fertile Dig — Living Vines Shovel
# On hit: Heal + saturation
advancement revoke @s only evercraft:artifacts/abilities/fertile_dig_trigger
effect give @s regeneration 3 1 false
effect give @s saturation 1 0 false
execute at @s run particle happy_villager ~ ~1 ~ 0.5 0.5 0.5 0 5
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.moss.place player @s ~ ~ ~ 0.8 1

# Generic tier FX (common→rare; no-ops at ornate+)
function evercraft:fx/tier/read_mainhand
execute at @s run function evercraft:fx/tier/proc

# Achievement tracking
scoreboard players add @s ach.weapon_abilities 1
