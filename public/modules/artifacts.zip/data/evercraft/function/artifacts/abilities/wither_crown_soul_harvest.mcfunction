# ============================================================
# Wither Rose Crown — "Soul Harvest" (Joseph 2026-06-10)
# ============================================================
# Reward fn of evercraft:artifacts/wither_crown_kill (player_killed_entity, #minecraft:undead
# only). The equal-power replacement for the un-implementable "undead fight for you" codex
# claim: the Death Lord harvests the souls of slain undead — each kill stacks a soul
# (max 4) and refreshes a 30s window; the stack is worn as Absorption I-IV golden hearts.
# Window decay + reset live beside the cd_chrono tick-down in player_tick (ec.wrc_t).
advancement revoke @s only evercraft:artifacts/wither_crown_kill

# Carrier gate (container / satchel-mark / offhand).
execute if items entity @s container.* *[custom_data~{artifact:"wither_rose_crown"}] run tag @s add ec._a
execute unless items entity @s container.* *[custom_data~{artifact:"wither_rose_crown"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"wither_rose_crown"}] if entity @s[tag=ec.sat_wither_rose_crown] run tag @s add ec._a
execute unless entity @s[tag=ec._a] if items entity @s weapon.offhand *[custom_data~{artifact:"wither_rose_crown"}] run tag @s add ec._a
execute unless entity @s[tag=ec._a] run return 0
tag @s remove ec._a

# Stack a soul (cap 4) + refresh the window.
scoreboard players add @s ec.wrc_souls 1
execute if score @s ec.wrc_souls matches 5.. run scoreboard players set @s ec.wrc_souls 4
scoreboard players set @s ec.wrc_t 30

# Wear the harvest: Absorption I-IV for the window length.
execute if score @s ec.wrc_souls matches 1 run effect give @s absorption 30 0 false
execute if score @s ec.wrc_souls matches 2 run effect give @s absorption 30 1 false
execute if score @s ec.wrc_souls matches 3 run effect give @s absorption 30 2 false
execute if score @s ec.wrc_souls matches 4 run effect give @s absorption 30 3 false

# Soul-taking cue (somber, musical — no mob vocals).
execute at @s run particle soul ~ ~1 ~ 0.3 0.5 0.3 0.02 12 normal @a[distance=..16,scores={ec.fx_vis=1..}]
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 0.6 0.7
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:particle.soul_escape master @s ~ ~ ~ 1.0 0.8
