# Macro inner: per-player save of held Dragon Fan into storage.
# Args from storage evercraft:artifacts cart:
#   pid = per-player session-counter (cheap UUID surrogate)
# Wiring Audit #5 W3b — paired with abilities/dragon_fan/on_consume.mcfunction (outer derives pid).

$data modify storage evercraft:item_restore dragon_fan.$(pid) set from entity @s SelectedItem
