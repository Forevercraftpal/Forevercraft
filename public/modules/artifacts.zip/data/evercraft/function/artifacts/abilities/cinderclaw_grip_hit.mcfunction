# Cinderclaw Grip (Family M — Dragonheart leaf, art-M) — attacks ignite hostiles for 3 seconds
# Generic player_hurt_entity trigger (the blaze_core_hit idiom) — re-grants the advancement so it can
# fire again, early-exits unless the player holds a Cinderclaw Grip, then sets the struck mob alight.

# Revoke for re-trigger
advancement revoke @s only evercraft:artifacts/abilities/cinderclaw_grip_hit_trigger

# Early exit if the player doesn't hold a Cinderclaw Grip OR any fusion node that ABSORBS it (the Wyrmclaw
# Grips sub-cap, the grand Dragonheart, or the final-form Wyrmscale Aegis). Full-power union (no nerf
# fence): a fused holder gets the on-hit ignite even though the loose Cinderclaw leaf was consumed by the
# fusion. id-presence gate; the loose leaf and the fusion flags never both apply on one player in practice
# (the leaf is consumed), so this never double-ignites (one Fire:60s set, not summed).
execute unless items entity @s container.* *[custom_data~{artifact:"cinderclaw_grip"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"cinderclaw_grip"}] unless items entity @s container.* *[custom_data~{wyrmclaw_grips:true}] unless items entity @s weapon.offhand *[custom_data~{wyrmclaw_grips:true}] unless items entity @s container.* *[custom_data~{dragonheart:true}] unless items entity @s weapon.offhand *[custom_data~{dragonheart:true}] unless items entity @s container.* *[custom_data~{wyrmscale_aegis:true}] unless items entity @s weapon.offhand *[custom_data~{wyrmscale_aegis:true}] run return 0

# Ignite the mob the player just hit for 3 seconds (60 ticks of Fire), hostiles only
execute at @s as @e[type=#evercraft:hostile_mobs,distance=..5,limit=1,sort=nearest,nbt={HurtTime:10s}] run data merge entity @s {Fire:60s}

# Subtle ember burst on the target
execute at @s as @e[type=#evercraft:hostile_mobs,distance=..5,limit=1,sort=nearest,nbt={HurtTime:10s}] at @s run particle flame ~ ~0.5 ~ 0.3 0.3 0.3 0.05 4

# Generic tier FX (common→rare; no-ops at ornate+)
function evercraft:fx/tier/read_mainhand
execute at @s run function evercraft:fx/tier/proc
