# Kelp Harvest — Prismarine Hoe
# On hit: Grants aquatic buffs
advancement revoke @s only evercraft:artifacts/abilities/kelp_harvest_trigger
effect give @s dolphins_grace 10 0 false
effect give @s water_breathing 10 0 false
execute at @s run particle fishing ~ ~0.5 ~ 0.5 0.3 0.5 0 4
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.amethyst_block.chime player @s ~ ~ ~ 0.5 1.2

# Generic tier FX (common→rare; no-ops at ornate+)
function evercraft:fx/tier/read_mainhand
execute at @s run function evercraft:fx/tier/proc

# Achievement tracking
scoreboard players add @s ach.weapon_abilities 1
