# Temporal Hourglass — Chrono Rewind (Death Save)
# Triggers when the bearer drops below 3 hearts (health_below_6) with the Hourglass carried (container /
# offhand / satchel). "Chrono Rewind" replaces the infeasible "50% damage negate / -50% all cooldowns":
# on an otherwise-lethal blow, time rewinds — the bearer is restored with a fixed Absorption IV (30s).
# Longer 4-minute cooldown than the Ring of Undying (it also carries strong passive Res II + Speed II).
# G6 / m4: the ec.cd_chrono gate is idempotent + multi-copy-safe (cooldown SET after the first fire).
# Absorption is SET to a fixed level (effect give SETs, max-not-sum), matching the phoenix idiom.

# Heal so the bearer survives the otherwise-lethal blow
effect give @s instant_health 1 1 false

# Rewind buffs — Absorption IV (30s) + a brief Regen so the heal lands cleanly
effect give @s absorption 30 3 false
effect give @s regeneration 8 1 false

# Chrono Rewind visual + audio feedback (time-bend pop)
particle totem_of_undying ~ ~1 ~ 0.5 1 0.5 0.5 35
particle reverse_portal ~ ~1 ~ 0.6 1 0.6 0.04 25
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:item.totem.use player @s ~ ~ ~ 1 1
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.beacon.power_select player @s ~ ~ ~ 0.8 0.6

# Set 4-minute cooldown — read by player_tick (decremented there, one writer besides this source-set).
# 1s tick-down cadence -> VALUE = SECONDS, so 240 = 4 minutes.
scoreboard players set @s ec.cd_chrono 240

# Actionbar notification
data modify storage evercraft:notify stage.c set value [{text:"Chrono Rewind! Time turns back.",color:"light_purple"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
