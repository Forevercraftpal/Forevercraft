# Dragon Fan — Restore consumed item preserving all modifications
# (glyphforge runes, patina, weapon mastery, etc.)
# Uses hopper_minecart intermediary since Player Inventory is read-only in 1.21.5+
# Wiring Audit #5 W3b: hybrid per-player scope — tag-suffix on cart + storage-path suffix.

# Derive per-player id; delegate to macro inner.
execute store result storage evercraft:artifacts cart.pid int 1 run scoreboard players get @s adv.gui_session
function evercraft:artifacts/abilities/dragon_fan/restore_inner with storage evercraft:artifacts cart
