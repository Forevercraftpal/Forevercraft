# Warriors Crown — Kill Chain (champion's resolve)
# Worn armor (head slot) can't gate on weapon.mainhand, so this fires from a BARE player_killed_entity
# trigger (warriors_crown_kill_trigger) and early-exits unless the helmet is worn — the canonical
# armor on-kill proc pattern (mirrors blaze_core_hit's artifact-id early-exit). Reuses the
# strength_on_kill "Kill Chain" escalation (I -> II -> +Speed) but on its own ec.wc_chain counter so it
# doesn't collide with a Caliburn the player might also wield. Keeps the +10% attack damage attr (loot).
advancement revoke @s only evercraft:artifacts/abilities/warriors_crown_kill_trigger

# Early exit unless the Warriors Crown is worn on the head
execute unless items entity @s armor.head *[custom_data~{artifact:"warriors_crown"}] run return 0

# Increment kill chain counter
scoreboard players add @s ec.wc_chain 1

# Reset per-player chain decay timer (10 seconds)
scoreboard players set @s ec.wc_chain_cd 10

# Base: Strength I for 5s (always)
effect give @s strength 5 0 false

# Enhancement: If 2+ kills in chain, upgrade to Strength II
execute if score @s ec.wc_chain matches 2.. run effect give @s strength 5 1 false

# Enhancement: At 3+ kills, also grant Speed I (5s)
execute if score @s ec.wc_chain matches 3.. run effect give @s speed 5 0 false
execute if score @s ec.wc_chain matches 3.. run data modify storage evercraft:notify stage.c set value [{text:"Champion's Resolve!",color:"gold",bold:true}]
scoreboard players set #ndur ec.temp 45
execute if score @s ec.wc_chain matches 3.. run function evercraft:util/notify/emit

# Visual/audio feedback — escalating with chain
particle crit ~ ~1 ~ 0.3 0.5 0.3 0.05 6
execute if score @s ec.wc_chain matches 2.. at @s run particle enchant ~ ~1 ~ 0.5 0.8 0.5 1 8
execute if score @s ec.wc_chain matches 3.. at @s run particle totem_of_undying ~ ~1 ~ 0.5 0.5 0.5 0.1 12
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.player.attack.crit player @s ~ ~ ~ 0.5 1.2
execute if score @s ec.wc_chain matches 3.. if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.player.levelup player @s ~ ~ ~ 0.4 1.8

# Achievement tracking
scoreboard players add @s ach.weapon_abilities 1
