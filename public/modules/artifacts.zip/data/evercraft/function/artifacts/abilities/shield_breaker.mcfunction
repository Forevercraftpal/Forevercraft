# Shield Breaker — Combat Mace
# Applies Weakness II + removes Resistance from target
# (Striker: +Mining Fatigue II at 50+ Impact, doubled durations at 75+ Impact)
advancement revoke @s only evercraft:artifacts/abilities/shield_breaker_trigger

# === ARMOR-SHRED MARK (Wave 1-B) ===
# Each hit stacks an armor-shred mark ON the target mob (ec.shred, capped at 5). The mark makes the
# target more vulnerable: combat_mace deals +1 bonus damage per existing stack BEFORE incrementing.
# The score lives on the mob (not the player), so the vulnerability persists across attackers. The
# mark decays in artifacts/accessories/tick (loses its stacks when the 5s decay window lapses unre-hit).
execute at @s as @e[type=!player,type=!item,distance=..5,limit=1,sort=nearest,nbt={HurtTime:10s}] if score @s ec.shred matches 1.. run damage @s 1 minecraft:player_attack
execute at @s as @e[type=!player,type=!item,distance=..5,limit=1,sort=nearest,nbt={HurtTime:10s}] if score @s ec.shred matches 2.. run damage @s 1 minecraft:player_attack
execute at @s as @e[type=!player,type=!item,distance=..5,limit=1,sort=nearest,nbt={HurtTime:10s}] if score @s ec.shred matches 3.. run damage @s 1 minecraft:player_attack
execute at @s as @e[type=!player,type=!item,distance=..5,limit=1,sort=nearest,nbt={HurtTime:10s}] if score @s ec.shred matches 4.. run damage @s 1 minecraft:player_attack
execute at @s as @e[type=!player,type=!item,distance=..5,limit=1,sort=nearest,nbt={HurtTime:10s}] if score @s ec.shred matches 5.. run damage @s 1 minecraft:player_attack
# Increment the mark (cap 5) + refresh its decay window, and flag a brief glow so the marked target reads
execute at @s as @e[type=!player,type=!item,distance=..5,limit=1,sort=nearest,nbt={HurtTime:10s}] unless score @s ec.shred matches 5.. run scoreboard players add @s ec.shred 1
execute at @s as @e[type=!player,type=!item,distance=..5,limit=1,sort=nearest,nbt={HurtTime:10s}] run scoreboard players set @s ec.shred_cd 5
execute at @s as @e[type=!player,type=!item,distance=..5,limit=1,sort=nearest,nbt={HurtTime:10s}] run effect give @s glowing 2 0 true
execute at @s as @e[type=!player,type=!item,distance=..5,limit=1,sort=nearest,nbt={HurtTime:10s}] at @s run particle crit ~ ~1 ~ 0.3 0.3 0.3 0.2 6

# Generic tier FX (common→rare; no-ops at ornate+) — above the impact branches that return early
function evercraft:fx/tier/read_mainhand
execute at @s run function evercraft:fx/tier/proc

# === STRIKER IMPACT SCALING ===
# 75+ Impact: Weakness II 10s + Mining Fatigue II 10s + strip Resistance
execute if score @s ec.sk_impact matches 75.. at @s as @e[type=!player,distance=..5,limit=1,sort=nearest,nbt={HurtTime:10s}] run effect give @s weakness 10 1 false
execute if score @s ec.sk_impact matches 75.. at @s as @e[type=!player,distance=..5,limit=1,sort=nearest,nbt={HurtTime:10s}] run effect give @s mining_fatigue 10 1 false
execute if score @s ec.sk_impact matches 75.. at @s as @e[type=!player,distance=..5,limit=1,sort=nearest,nbt={HurtTime:10s}] run effect clear @s resistance
execute if score @s ec.sk_impact matches 75.. at @s run particle crit ~ ~1 ~ 0.5 0.5 0.5 0.1 10
execute if score @s ec.sk_impact matches 75.. if score @s ec.fx_snd matches 1.. run playsound minecraft:block.anvil.land player @s ~ ~ ~ 1 0.3
execute if score @s ec.sk_impact matches 75.. if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.basedrum player @s ~ ~ ~ 1 0.3
execute if score @s ec.sk_impact matches 75.. run return 1

# 50-74 Impact: Weakness II 5s + Mining Fatigue II 5s + strip Resistance
execute if score @s ec.sk_impact matches 50..74 at @s as @e[type=!player,distance=..5,limit=1,sort=nearest,nbt={HurtTime:10s}] run effect give @s weakness 5 1 false
execute if score @s ec.sk_impact matches 50..74 at @s as @e[type=!player,distance=..5,limit=1,sort=nearest,nbt={HurtTime:10s}] run effect give @s mining_fatigue 5 1 false
execute if score @s ec.sk_impact matches 50..74 at @s as @e[type=!player,distance=..5,limit=1,sort=nearest,nbt={HurtTime:10s}] run effect clear @s resistance
execute if score @s ec.sk_impact matches 50..74 at @s run particle crit ~ ~1 ~ 0.4 0.4 0.4 0.1 8
execute if score @s ec.sk_impact matches 50..74 if score @s ec.fx_snd matches 1.. run playsound minecraft:block.anvil.land player @s ~ ~ ~ 1 0.4
execute if score @s ec.sk_impact matches 50..74 run return 1

# Default: Weakness II 5s + strip Resistance
execute at @s as @e[type=!player,distance=..5,limit=1,sort=nearest,nbt={HurtTime:10s}] run effect give @s weakness 5 1 false
execute at @s as @e[type=!player,distance=..5,limit=1,sort=nearest,nbt={HurtTime:10s}] run effect clear @s resistance
execute at @s run particle crit ~ ~1 ~ 0.3 0.3 0.3 0.1 5
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.anvil.land player @s ~ ~ ~ 1 0.5

# Achievement tracking
scoreboard players add @s ach.weapon_abilities 1
