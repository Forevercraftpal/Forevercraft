# Legendary Smash — Mace of Legends
# AoE damage + knockback in radius + Slowness
# (Striker: +3 AoE dmg at 50+ Impact, radius 8 at 75+ Impact)
advancement revoke @s only evercraft:artifacts/abilities/legendary_smash_trigger

# Generic tier FX (common→rare; no-ops at ornate+) — above the impact branches that return early
function evercraft:fx/tier/read_mainhand
execute at @s run function evercraft:fx/tier/proc

# === STRIKER IMPACT SCALING ===
# 75+ Impact: 7 damage, radius 8, Slowness II
execute if score @s ec.sk_impact matches 75.. at @s as @e[type=#evercraft:aoe_targets,distance=..8] run damage @s 7 minecraft:mob_attack
execute if score @s ec.sk_impact matches 75.. at @s run tag @e[type=#evercraft:aoe_targets,distance=..8] add ec.kb
execute if score @s ec.sk_impact matches 75.. as @e[tag=ec.kb] at @s facing entity @p feet positioned ^ ^ ^-0.4 if block ~ ~ ~ #minecraft:replaceable if block ~ ~1 ~ #minecraft:replaceable run tp @s ~ ~ ~
execute if score @s ec.sk_impact matches 75.. as @e[tag=ec.kb] at @s facing entity @p feet positioned ^ ^ ^-0.4 if block ~ ~ ~ #minecraft:replaceable if block ~ ~1 ~ #minecraft:replaceable run tp @s ~ ~ ~
execute if score @s ec.sk_impact matches 75.. as @e[tag=ec.kb] at @s facing entity @p feet positioned ^ ^ ^-0.4 if block ~ ~ ~ #minecraft:replaceable if block ~ ~1 ~ #minecraft:replaceable run tp @s ~ ~ ~
execute if score @s ec.sk_impact matches 75.. as @e[tag=ec.kb] at @s facing entity @p feet positioned ^ ^ ^-0.4 if block ~ ~ ~ #minecraft:replaceable if block ~ ~1 ~ #minecraft:replaceable run tp @s ~ ~ ~
execute if score @s ec.sk_impact matches 75.. as @e[tag=ec.kb] at @s facing entity @p feet positioned ^ ^ ^-0.4 if block ~ ~ ~ #minecraft:replaceable if block ~ ~1 ~ #minecraft:replaceable run tp @s ~ ~ ~
execute if score @s ec.sk_impact matches 75.. as @e[tag=ec.kb] at @s facing entity @p feet positioned ^ ^ ^-0.4 if block ~ ~ ~ #minecraft:replaceable if block ~ ~1 ~ #minecraft:replaceable run tp @s ~ ~ ~
execute if score @s ec.sk_impact matches 75.. as @e[tag=ec.kb] at @s facing entity @p feet positioned ^ ^ ^-0.4 if block ~ ~ ~ #minecraft:replaceable if block ~ ~1 ~ #minecraft:replaceable run tp @s ~ ~ ~
execute if score @s ec.sk_impact matches 75.. as @e[tag=ec.kb] at @s facing entity @p feet positioned ^ ^ ^-0.4 if block ~ ~ ~ #minecraft:replaceable if block ~ ~1 ~ #minecraft:replaceable run tp @s ~ ~ ~
execute if score @s ec.sk_impact matches 75.. as @e[tag=ec.kb] run effect give @s slowness 4 1 false
execute if score @s ec.sk_impact matches 75.. run scoreboard players set #kin_force ec.var 80
execute if score @s ec.sk_impact matches 75.. run function evercraft:kinetic/slam_kb
execute if score @s ec.sk_impact matches 75.. run tag @e[tag=ec.kb] remove ec.kb

execute if score @s ec.sk_impact matches 75.. at @s run particle explosion ~ ~0.5 ~ 4 0.2 4 0.1 15
execute if score @s ec.sk_impact matches 75.. as @a[distance=..20] if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.generic.explode player @s ~ ~ ~ 1.0 0.4
execute if score @s ec.sk_impact matches 75.. run return 1

# 50-74 Impact: 7 damage, radius 5, Slowness II
execute if score @s ec.sk_impact matches 50..74 at @s as @e[type=#evercraft:aoe_targets,distance=..5] run damage @s 7 minecraft:mob_attack
execute if score @s ec.sk_impact matches 50..74 at @s run tag @e[type=#evercraft:aoe_targets,distance=..5] add ec.kb
execute if score @s ec.sk_impact matches 50..74 as @e[tag=ec.kb] at @s facing entity @p feet positioned ^ ^ ^-0.4 if block ~ ~ ~ #minecraft:replaceable if block ~ ~1 ~ #minecraft:replaceable run tp @s ~ ~ ~
execute if score @s ec.sk_impact matches 50..74 as @e[tag=ec.kb] at @s facing entity @p feet positioned ^ ^ ^-0.4 if block ~ ~ ~ #minecraft:replaceable if block ~ ~1 ~ #minecraft:replaceable run tp @s ~ ~ ~
execute if score @s ec.sk_impact matches 50..74 as @e[tag=ec.kb] at @s facing entity @p feet positioned ^ ^ ^-0.4 if block ~ ~ ~ #minecraft:replaceable if block ~ ~1 ~ #minecraft:replaceable run tp @s ~ ~ ~
execute if score @s ec.sk_impact matches 50..74 as @e[tag=ec.kb] at @s facing entity @p feet positioned ^ ^ ^-0.4 if block ~ ~ ~ #minecraft:replaceable if block ~ ~1 ~ #minecraft:replaceable run tp @s ~ ~ ~
execute if score @s ec.sk_impact matches 50..74 as @e[tag=ec.kb] at @s facing entity @p feet positioned ^ ^ ^-0.4 if block ~ ~ ~ #minecraft:replaceable if block ~ ~1 ~ #minecraft:replaceable run tp @s ~ ~ ~
execute if score @s ec.sk_impact matches 50..74 as @e[tag=ec.kb] at @s facing entity @p feet positioned ^ ^ ^-0.4 if block ~ ~ ~ #minecraft:replaceable if block ~ ~1 ~ #minecraft:replaceable run tp @s ~ ~ ~
execute if score @s ec.sk_impact matches 50..74 as @e[tag=ec.kb] run effect give @s slowness 3 1 false
execute if score @s ec.sk_impact matches 50..74 run scoreboard players set #kin_force ec.var 64
execute if score @s ec.sk_impact matches 50..74 run function evercraft:kinetic/slam_kb
execute if score @s ec.sk_impact matches 50..74 run tag @e[tag=ec.kb] remove ec.kb

execute if score @s ec.sk_impact matches 50..74 at @s run particle explosion ~ ~0.5 ~ 2.5 0.2 2.5 0.1 10
execute if score @s ec.sk_impact matches 50..74 as @a[distance=..20] if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.generic.explode player @s ~ ~ ~ 0.9 0.5
execute if score @s ec.sk_impact matches 50..74 run return 1

# Default: 4 damage, radius 5, Slowness II
execute at @s as @e[type=#evercraft:aoe_targets,distance=..5] run damage @s 4 minecraft:mob_attack
execute at @s run tag @e[type=#evercraft:aoe_targets,distance=..5] add ec.kb
execute as @e[tag=ec.kb] at @s facing entity @p feet positioned ^ ^ ^-0.4 if block ~ ~ ~ #minecraft:replaceable if block ~ ~1 ~ #minecraft:replaceable run tp @s ~ ~ ~
execute as @e[tag=ec.kb] at @s facing entity @p feet positioned ^ ^ ^-0.4 if block ~ ~ ~ #minecraft:replaceable if block ~ ~1 ~ #minecraft:replaceable run tp @s ~ ~ ~
execute as @e[tag=ec.kb] at @s facing entity @p feet positioned ^ ^ ^-0.4 if block ~ ~ ~ #minecraft:replaceable if block ~ ~1 ~ #minecraft:replaceable run tp @s ~ ~ ~
execute as @e[tag=ec.kb] at @s facing entity @p feet positioned ^ ^ ^-0.4 if block ~ ~ ~ #minecraft:replaceable if block ~ ~1 ~ #minecraft:replaceable run tp @s ~ ~ ~
execute as @e[tag=ec.kb] at @s facing entity @p feet positioned ^ ^ ^-0.4 if block ~ ~ ~ #minecraft:replaceable if block ~ ~1 ~ #minecraft:replaceable run tp @s ~ ~ ~
execute as @e[tag=ec.kb] run effect give @s slowness 3 1 false
# Wall-slam bonus (kinetic)
scoreboard players set #kin_force ec.var 48
function evercraft:kinetic/slam_kb
tag @e[tag=ec.kb] remove ec.kb
execute at @s run particle explosion ~ ~0.5 ~ 2 0.2 2 0.1 8
execute as @a[distance=..20] if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.generic.explode player @s ~ ~ ~ 0.8 0.6

# Achievement tracking
scoreboard players add @s ach.weapon_abilities 1
