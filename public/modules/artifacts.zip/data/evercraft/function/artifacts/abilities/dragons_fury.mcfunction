# Dragon's Fury — Dragonmaster Sword Enhancement (Mythical)
# Fire breath cone: 4 fire damage to mobs in front of player (3 blocks)

# AoE fire damage in cone (using local coordinates to hit mobs in front)
execute at @s positioned ^ ^ ^1 as @e[type=!player,type=!item,distance=..3] run damage @s 4 minecraft:on_fire
execute at @s positioned ^ ^ ^1 as @e[type=!player,type=!item,distance=..3] run data merge entity @s {Fire:80s}

# Fire breath visual — flame particles in a cone
execute at @s run particle flame ^ ^ ^1 0.3 0.3 0.3 0.05 5
execute at @s run particle flame ^ ^ ^2 0.5 0.4 0.5 0.05 8
execute at @s run particle flame ^ ^ ^3 0.8 0.5 0.8 0.05 10
execute at @s run particle small_flame ^ ^ ^1.5 0.4 0.3 0.4 0.08 6

# Audio + actionbar
data modify storage evercraft:notify stage.c set value [{text:"Dragon's Fury!",color:"#FF4500",bold:true}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute as @a[distance=..16] if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.ender_dragon.growl player @s ~ ~ ~ 0.4 1.5
execute as @a[distance=..16] if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.blaze.shoot player @s ~ ~ ~ 0.6 0.8

# Bespoke FX flourish (channel-gated)
execute at @s run function evercraft:fx/bespoke/ability/dragons_fury
