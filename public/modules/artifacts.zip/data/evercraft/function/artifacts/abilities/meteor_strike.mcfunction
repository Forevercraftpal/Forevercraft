# Meteor Strike — Star Axe + Impact Crater Enhancement
# Base: AoE fire damage on hit + fire particles (falling star impact)
# Enhancement: Targets hit also get Slowness II (3s) — trapped in the crater
advancement revoke @s only evercraft:artifacts/abilities/meteor_strike_trigger
execute at @s at @e[type=!player,distance=..5,limit=1,sort=nearest,nbt={HurtTime:10s}] as @e[type=!player,type=!item,distance=..3] run damage @s 3 minecraft:on_fire
execute at @s at @e[type=!player,distance=..5,limit=1,sort=nearest,nbt={HurtTime:10s}] as @e[type=!player,type=!item,distance=..3] run data merge entity @s {Fire:60s}

# Impact Crater: Slowness II to all AoE targets
execute at @s at @e[type=!player,distance=..5,limit=1,sort=nearest,nbt={HurtTime:10s}] as @e[type=!player,type=!item,distance=..3] run effect give @s slowness 3 1 false

# Visual/audio feedback
execute at @s run particle lava ~ ~2 ~ 1 1 1 0.1 10
execute at @s run particle campfire_cosy_smoke ~ ~0.2 ~ 0.8 0.1 0.8 0.01 5
execute as @a[distance=..20] if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.generic.explode player @s ~ ~ ~ 0.5 1.5

# Generic tier FX (common→rare; no-ops at ornate+)
function evercraft:fx/tier/read_mainhand
execute at @s run function evercraft:fx/tier/proc

# Achievement tracking
scoreboard players add @s ach.weapon_abilities 1
