# Storm Sow — Vortex Hoe
# On hit: Channel the wind — Speed II + Jump Boost
advancement revoke @s only evercraft:artifacts/abilities/storm_sow_trigger
effect give @s speed 8 1 false
effect give @s jump_boost 8 1 false
execute at @s run particle cloud ~ ~1 ~ 0.5 0.5 0.5 0.05 5
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.wind_charge.wind_burst player @s ~ ~ ~ 0.5 1.2

# Generic tier FX (common→rare; no-ops at ornate+)
function evercraft:fx/tier/read_mainhand
execute at @s run function evercraft:fx/tier/proc

# Achievement tracking
scoreboard players add @s ach.weapon_abilities 1
