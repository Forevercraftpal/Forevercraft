# Void Strike — Voidbane
# Deals 4 bonus arcane damage + Darkness effect on target
advancement revoke @s only evercraft:artifacts/abilities/void_strike_trigger
execute at @s as @e[type=!player,distance=..5,limit=1,sort=nearest,nbt={HurtTime:10s}] at @s run damage @s 4 evercraft:bonus_strike
execute at @s as @e[type=!player,distance=..5,limit=1,sort=nearest,nbt={HurtTime:10s}] run effect give @s darkness 3 0 false
execute at @s run particle reverse_portal ~ ~1 ~ 0.3 0.5 0.3 0.05 10
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.enderman.teleport player @s ~ ~ ~ 0.5 0.5

# Generic tier FX (common→rare; no-ops at ornate+)
function evercraft:fx/tier/read_mainhand
execute at @s run function evercraft:fx/tier/proc

# Achievement tracking
scoreboard players add @s ach.weapon_abilities 1
