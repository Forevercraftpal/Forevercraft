# Dragon's Spite — Damage boost based on missing health (4-tier discrete)
# 50-74% HP: +5%   /   35-49% HP: +15%   /   20-34% HP: +20%   /   ≤19% HP: +25%
# Tier table lives in calculate_spite_bonus; this dispatcher gates on the 75% threshold.

# Get current and max health
execute store result score @s ec.health_raw run data get entity @s Health 100
execute store result score @s ec.max_health run attribute @s max_health get 100

# Calculate health percentage (health * 100 / max_health)
scoreboard players operation @s ec.health_pct = @s ec.health_raw
scoreboard players operation @s ec.health_pct *= #100 ec.const
scoreboard players operation @s ec.health_pct /= @s ec.max_health

# Dragon's Spite activates below 75% HP (4-tier table — see calculate_spite_bonus).

# If health >= 75%, remove any spite bonus
execute if score @s ec.health_pct matches 75.. run attribute @s attack_damage modifier remove evercraft:dragons_spite

# If health < 75%, apply scaled bonus
execute if score @s ec.health_pct matches ..74 run function evercraft:artifacts/abilities/dragon_fan/calculate_spite_bonus
