# Ender Dragon Scale — Dragon Ascendant trail puff
# A single dragon's-breath particle puff at the bearer's position. Scheduled at fixed offsets from
# ender_dragon_scale_ascend + ender_dragon_scale_glide so the launch/glide leaves a dragon's-breath wake.
# No loop / no objective: each invocation is one puff (fixed-count schedules drive the trail).
# Runs as @s = the bearer (schedule preserves the executor).

execute at @s run particle dragon_breath ~ ~0.5 ~ 0.35 0.4 0.35 0.03 18
