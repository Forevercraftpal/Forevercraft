# Prism of Light — Deflect projectile away from the bearer (the feasible substitute for "100% reflect").
# Adapted from artifacts/graviton_core/deflect_projectile: reverses/scatters the projectile's motion and
# tags it pol_deflected to prevent re-deflection. Arrows can't be re-aimed (1.21.5+ drops Owner on
# removal), so they are replaced with an ownerless copy; non-arrows just get their Motion redirected.
# @s = the projectile, position = the projectile.

# Tag this projectile as deflected so it won't be deflected again
tag @s add pol_deflected

# Visual feedback (prismatic flash before any kill for arrows)
execute at @s run particle minecraft:end_rod ~ ~ ~ 0.3 0.3 0.3 0.05 6
execute at @s as @a[distance=..10] if score @s ec.fx_snd matches 1.. run playsound minecraft:block.amethyst_block.chime hostile @s ~ ~ ~ 0.4 1.5

# === ARROWS: Replace with ownerless copy ===
execute store result score #pol_mx ec.temp run random value -5..5
execute store result score #pol_mz ec.temp run random value -5..5
execute if entity @s[type=arrow] at @s run summon arrow ~ ~ ~ {Tags:["pol_deflected","pol_new"],pickup:0b,life:1180s}
execute if entity @s[type=spectral_arrow] at @s run summon spectral_arrow ~ ~ ~ {Tags:["pol_deflected","pol_new"],pickup:0b,life:1180s}
execute if entity @e[tag=pol_new,limit=1] as @e[tag=pol_new,limit=1] store result entity @s Motion[0] double 0.1 run scoreboard players get #pol_mx ec.temp
execute if entity @e[tag=pol_new,limit=1] as @e[tag=pol_new,limit=1] run data modify entity @s Motion[1] set value 0.5d
execute if entity @e[tag=pol_new,limit=1] as @e[tag=pol_new,limit=1] store result entity @s Motion[2] double 0.1 run scoreboard players get #pol_mz ec.temp
execute if entity @e[tag=pol_new,limit=1] as @e[tag=pol_new,limit=1] run tag @s remove pol_new
execute if entity @s[type=arrow] run kill @s
execute if entity @s[type=spectral_arrow] run kill @s

# === NON-ARROWS: Redirect motion directly (fireballs, wither skulls, etc.) ===
execute unless entity @s[type=arrow] unless entity @s[type=spectral_arrow] run data modify entity @s Motion[1] set value 0.5d
execute unless entity @s[type=arrow] unless entity @s[type=spectral_arrow] store result entity @s Motion[0] double 0.1 run scoreboard players get #pol_mx ec.temp
execute unless entity @s[type=arrow] unless entity @s[type=spectral_arrow] store result entity @s Motion[2] double 0.1 run scoreboard players get #pol_mz ec.temp

# Remove the tag after 3 seconds (allows re-deflection of new projectiles, cleans up the tag)
schedule function evercraft:artifacts/abilities/prism_clear_deflect 60t append
