# Redstone Heart — boost one smelter (positioned at the block). Blacksmith boost idiom,
# generalized: cap is read from THIS block's cooking_total_time (furnace 200 / blast+smoker
# 100), so every smelter type lands at total-1 and the engine finishes the item itself.
# Bail unless actively cooking: lit + an input item present (cooking_time_spent only
# advances mid-smelt; boosting an idle furnace would be discarded by the engine anyway).
execute unless data block ~ ~ ~ Items[0] run return 0
execute store result score #rh_cook ec.temp run data get block ~ ~ ~ cooking_time_spent
execute store result score #rh_total ec.temp run data get block ~ ~ ~ cooking_total_time
execute unless score #rh_total ec.temp matches 1.. run return 0
scoreboard players add #rh_cook ec.temp 60
scoreboard players remove #rh_total ec.temp 1
execute if score #rh_cook ec.temp > #rh_total ec.temp run scoreboard players operation #rh_cook ec.temp = #rh_total ec.temp
execute store result block ~ ~ ~ cooking_time_spent short 1 run scoreboard players get #rh_cook ec.temp
