# Undead Slayer - Bonus damage vs undead
# Deals 4 extra damage to undead mobs

# Revoke advancement so it can trigger again
advancement revoke @s only evercraft:artifacts/abilities/undead_slayer_trigger

# Deal bonus damage to the undead target
# BUG-006 FIX: was `by @s` which credited the mob (after `as @e`), now uses `by @p` for player credit
execute at @s as @e[type=#minecraft:undead,distance=..5,limit=1,sort=nearest,nbt={HurtTime:10s}] run damage @s 4 minecraft:player_attack by @p[sort=nearest,limit=1]

# Visual/audio feedback
execute at @s run particle enchant ~ ~1 ~ 0.3 0.5 0.3 0.5 10
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bass player @s ~ ~ ~ 0.8 0.5

# Generic tier FX (common→rare; no-ops at ornate+)
function evercraft:fx/tier/read_mainhand
execute at @s run function evercraft:fx/tier/proc

# Achievement tracking
scoreboard players add @s ach.weapon_abilities 1
