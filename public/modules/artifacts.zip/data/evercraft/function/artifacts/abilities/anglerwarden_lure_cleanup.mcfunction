# Anglerwarden's Sigil (C34, Family J — art-J) — Cleanup the injected Lure II + LotS III
# Mirrors fast_fishing_cleanup: when the player no longer holds the Sigil OR is no longer holding a
# fishing rod, strip the injected enchants and clear the tag. Uses the shared fishing_remove modifier.

# Still holding the Sigil AND a rod? leave the enchants in place.
execute if items entity @s container.* *[custom_data~{artifact:"anglerwardens_sigil"}] if items entity @s weapon.mainhand minecraft:fishing_rod run return 0
execute if items entity @s weapon.offhand *[custom_data~{artifact:"anglerwardens_sigil"}] if items entity @s weapon.mainhand minecraft:fishing_rod run return 0

# Otherwise strip the injected enchants and clear the tag.
execute if items entity @s weapon.mainhand minecraft:fishing_rod run item modify entity @s weapon.mainhand evercraft:fishing_remove
tag @s remove ec.anglerwarden_fishing
