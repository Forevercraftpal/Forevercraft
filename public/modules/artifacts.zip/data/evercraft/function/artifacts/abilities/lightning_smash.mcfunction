# Lightning Smash — Mjolnir (Rare Striker)
# Summon lightning at target (Striker: chains at 50+/75+ Impact)
# "Worthy" Enhancement: Every 3rd lightning proc within 60s triggers a mini-storm
# (chain to ALL mobs within 8 blocks regardless of Impact tier)

advancement revoke @s only evercraft:artifacts/abilities/lightning_smash_trigger

# Generic tier FX (common→rare; no-ops at ornate+) — above the branches that return early
function evercraft:fx/tier/read_mainhand
execute at @s run function evercraft:fx/tier/proc

# Track "Worthy" chain counter
scoreboard players add @s ec.mjolnir_chain 1
# BUG-004 FIX: Per-player cooldown instead of global schedule (60s = 60 ticks at 1s interval)
scoreboard players set @s ec.worthy_cd 60

# === WORTHY CHECK: 3rd proc = mini-storm! ===
execute if score @s ec.mjolnir_chain matches 3.. at @s as @e[type=!player,type=!item,distance=..8,limit=8] at @s run summon lightning_bolt ~ ~ ~
execute if score @s ec.mjolnir_chain matches 3.. at @s run particle electric_spark ~ ~2 ~ 2 1 2 0.3 25
execute if score @s ec.mjolnir_chain matches 3.. at @s run particle minecraft:flash{color:-1} ~ ~5 ~ 0 0 0 0 1
execute if score @s ec.mjolnir_chain matches 3.. as @a[distance=..30] if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.lightning_bolt.thunder player @s ~ ~ ~ 1.0 0.5
execute if score @s ec.mjolnir_chain matches 3.. as @a[distance=..30] if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.lightning_bolt.impact player @s ~ ~ ~ 1.0 0.7
data modify storage evercraft:notify stage.c set value [{text:"⚡ WORTHY ⚡",color:"yellow",bold:true}]
scoreboard players set #ndur ec.temp 45
execute if score @s ec.mjolnir_chain matches 3.. run function evercraft:util/notify/emit
# BUG-005 FIX: return BEFORE reset (reset made the return unreachable, causing double damage)
execute if score @s ec.mjolnir_chain matches 3.. run scoreboard players set @s ec.mjolnir_chain 0
execute if score @s ec.mjolnir_chain matches ..0 run return 1

# === STRIKER IMPACT SCALING ===
# 75+ Impact: chain to 4 nearby targets
execute if score @s ec.sk_impact matches 75.. at @s at @e[type=!player,distance=..5,limit=1,sort=nearest,nbt={HurtTime:10s}] run summon lightning_bolt ~ ~ ~
execute if score @s ec.sk_impact matches 75.. at @s as @e[type=!player,type=!item,distance=..10,limit=4,sort=nearest,nbt={HurtTime:0s}] at @s run summon lightning_bolt ~ ~ ~
execute if score @s ec.sk_impact matches 75.. at @s run particle electric_spark ~ ~1 ~ 1 0.5 1 0.2 15
execute if score @s ec.sk_impact matches 75.. as @a[distance=..30] if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.lightning_bolt.thunder player @s ~ ~ ~ 0.8 0.8
execute if score @s ec.sk_impact matches 75.. run return 1

# 50-74 Impact: chain to 2 nearby targets
execute if score @s ec.sk_impact matches 50..74 at @s at @e[type=!player,distance=..5,limit=1,sort=nearest,nbt={HurtTime:10s}] run summon lightning_bolt ~ ~ ~
execute if score @s ec.sk_impact matches 50..74 at @s as @e[type=!player,type=!item,distance=..10,limit=2,sort=nearest,nbt={HurtTime:0s}] at @s run summon lightning_bolt ~ ~ ~
execute if score @s ec.sk_impact matches 50..74 at @s run particle electric_spark ~ ~1 ~ 0.8 0.5 0.8 0.2 10
execute if score @s ec.sk_impact matches 50..74 as @a[distance=..30] if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.lightning_bolt.thunder player @s ~ ~ ~ 0.6 0.9
execute if score @s ec.sk_impact matches 50..74 run return 1

# Default: single target
execute at @s at @e[type=!player,distance=..5,limit=1,sort=nearest,nbt={HurtTime:10s}] run summon lightning_bolt ~ ~ ~
execute at @s run particle electric_spark ~ ~1 ~ 0.5 0.5 0.5 0.1 8
execute as @a[distance=..30] if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.lightning_bolt.thunder player @s ~ ~ ~ 0.5 1

# Achievement tracking
scoreboard players add @s ach.weapon_abilities 1
