# Deep Sense — Soul Shovel
# On hit: Echolocation — Night Vision + reveal nearby enemies
advancement revoke @s only evercraft:artifacts/abilities/deep_sense_trigger
effect give @s night_vision 10 0 false
execute at @s run effect give @e[type=!player,type=!item,type=!armor_stand,type=!marker,type=!item_display,type=!interaction,distance=..16] glowing 8 0 false
execute at @s run particle sculk_soul ~ ~1 ~ 0.5 0.5 0.5 0.02 5
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bass player @s ~ ~ ~ 0.5 0.5

# Generic tier FX (common→rare; no-ops at ornate+)
function evercraft:fx/tier/read_mainhand
execute at @s run function evercraft:fx/tier/proc

# Achievement tracking
scoreboard players add @s ach.weapon_abilities 1
