# Soul Harvest — Eyelander + True Stacking Enhancement
# Each kill within 15s stacks souls (max 5). Effects scale with soul count:
# 1 soul = Str I + Speed I, 2 = Str II + Speed I, 3 = Str III + Speed II
# 4 = Str III + Speed II + Resistance I, 5 = all above + brief invulnerability flash
advancement revoke @s only evercraft:artifacts/abilities/soul_harvest_trigger

# Increment soul counter
scoreboard players add @s ec.eyelander_souls 1

# Reset per-player soul decay timer (15 seconds)
scoreboard players set @s ec.soul_cd 15

# Base: Strength I + Speed I (1 soul)
effect give @s strength 15 0 false
effect give @s speed 15 0 false

# 2+ souls: Strength II
execute if score @s ec.eyelander_souls matches 2.. run effect give @s strength 15 1 false

# 3+ souls: Strength III + Speed II
execute if score @s ec.eyelander_souls matches 3.. run effect give @s strength 15 2 false
execute if score @s ec.eyelander_souls matches 3.. run effect give @s speed 15 1 false

# 4+ souls: Also Resistance I
execute if score @s ec.eyelander_souls matches 4.. run effect give @s resistance 15 0 false

# 5 souls: Invulnerability flash + soul explosion — cap at 5
execute if score @s ec.eyelander_souls matches 5.. run effect give @s resistance 1 4 false
data modify storage evercraft:notify stage.c set value [{text:"SOUL STORM!",color:"#00FFCC"}]
scoreboard players set #ndur ec.temp 45
execute if score @s ec.eyelander_souls matches 5.. run function evercraft:util/notify/emit
execute if score @s ec.eyelander_souls matches 5.. at @s run particle soul ~ ~1 ~ 1.5 1 1.5 0.1 25
execute if score @s ec.eyelander_souls matches 5.. at @s as @a[distance=..16] if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.basedrum player @s ~ ~ ~ 0.5 1.5
execute if score @s ec.eyelander_souls matches 5.. run scoreboard players set @s ec.eyelander_souls 5

# Cap at 5 for all cases
execute if score @s ec.eyelander_souls matches 6.. run scoreboard players set @s ec.eyelander_souls 5

# Visual/audio — escalating
particle soul ~ ~1 ~ 0.3 0.5 0.3 0.02 5
execute if score @s ec.eyelander_souls matches 3.. at @s run particle soul ~ ~1 ~ 0.8 0.8 0.8 0.05 10
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bass player @s ~ ~ ~ 0.2 2

# Bespoke FX flourish (channel-gated; scales subtly with ec.eyelander_souls)
execute at @s run function evercraft:fx/bespoke/ability/soul_harvest

# Achievement tracking
scoreboard players add @s ach.weapon_abilities 1
