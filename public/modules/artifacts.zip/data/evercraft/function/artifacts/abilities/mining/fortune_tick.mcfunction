# Fortune Bonus System - Applied every tick to held tools
# This allows tools to have Fortune without the enchant permanently on them
# which would cause rarity bump and wrong name colors

# Remove fortune from tools that were put away (previous holders)
# We track this with a tag to avoid constantly checking all inventories
execute as @a[tag=ec.holding_fortune_tool] unless items entity @s weapon.mainhand *[custom_data~{fortune_bonus:5b}] run function evercraft:artifacts/abilities/mining/fortune_cleanup

# OPT: Detect new fortune tool pickups every 3 ticks (0.15s) — instant enough for mining
# Skips the expensive @a item scan on 2/3 of ticks
execute if score #daylight_counter ec.var matches 0 as @a[tag=!ec.holding_fortune_tool] if items entity @s weapon.mainhand *[custom_data~{fortune_bonus:5b}] unless items entity @s weapon.mainhand *[custom_data~{awakened:1b}] run function evercraft:artifacts/abilities/mining/fortune_apply
