# Calculate Dragon's Spite bonus — 4-tier discrete table by HP range
# 50-74% HP: +5%   /   35-49% HP: +15%   /   20-34% HP: +20%   /   ≤19% HP: +25%
# Doc-impl aligned 2026-05-30 (AU3-P3.3); prior comments promised a continuous formula not implemented.

# Remove existing modifier first
attribute @s attack_damage modifier remove evercraft:dragons_spite

# 50-74% HP: +5% damage
execute if score @s ec.health_pct matches 50..74 run attribute @s attack_damage modifier add evercraft:dragons_spite 0.05 add_multiplied_base

# 35-49% HP: +15% damage
execute if score @s ec.health_pct matches 35..49 run attribute @s attack_damage modifier add evercraft:dragons_spite 0.15 add_multiplied_base

# 20-34% HP: +20% damage
execute if score @s ec.health_pct matches 20..34 run attribute @s attack_damage modifier add evercraft:dragons_spite 0.20 add_multiplied_base

# Below 20% HP: +25% damage (max)
execute if score @s ec.health_pct matches ..19 run attribute @s attack_damage modifier add evercraft:dragons_spite 0.25 add_multiplied_base
