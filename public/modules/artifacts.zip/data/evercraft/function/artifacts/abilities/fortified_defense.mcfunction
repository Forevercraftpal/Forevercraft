# Fortified Defense — Tower Shield
# Grants Resistance I on hit for 5 seconds
advancement revoke @s only evercraft:artifacts/abilities/fortified_defense_trigger
effect give @s resistance 5 0 false
execute at @s run particle enchant ~ ~1 ~ 0.3 0.5 0.3 0.5 4
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:item.shield.block player @s ~ ~ ~ 0.8 1

# Generic tier FX (common→rare; no-ops at ornate+)
function evercraft:fx/tier/read_mainhand
execute at @s run function evercraft:fx/tier/proc

# Achievement tracking
scoreboard players add @s ach.weapon_abilities 1
