# Critical Edge — Katana + Iai Draw Enhancement
# Base: +3 bonus damage on critical hits
# Enhancement: Sneaking 2+ seconds activates Iai stance. Next crit from Iai = 3x damage + cherry blossom particles.
advancement revoke @s only evercraft:artifacts/abilities/critical_edge_trigger

# Check for Iai Draw stance (set by tick check in accessories/tick)
execute if entity @s[tag=ec.iai_ready] run tag @s remove ec.iai_ready
execute if entity @s[tag=!ec.iai_fired] run effect give @s strength 1 0 false
execute if entity @s[tag=!ec.iai_fired] run particle crit ~ ~1 ~ 0.5 0.5 0.5 0.1 8
execute if entity @s[tag=!ec.iai_fired] if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.player.attack.crit player @s ~ ~ ~ 1 1.2

# Iai Draw — 3x crit (Strength III for 1 tick = massive bonus)
execute if entity @s[tag=ec.iai_fired] run effect give @s strength 1 2 false
execute if entity @s[tag=ec.iai_fired] at @s run particle cherry_leaves ~ ~1 ~ 1 1 1 0.05 15
execute if entity @s[tag=ec.iai_fired] at @s run particle crit ~ ~1 ~ 0.8 0.8 0.8 0.2 10
execute if entity @s[tag=ec.iai_fired] if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.player.attack.crit player @s ~ ~ ~ 1 1.8
execute if entity @s[tag=ec.iai_fired] if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.player.attack.knockback player @s ~ ~ ~ 0.6 1.5
data modify storage evercraft:notify stage.c set value [{text:"Iai Draw!",color:"#FF69B4",bold:true}]
scoreboard players set #ndur ec.temp 45
execute if entity @s[tag=ec.iai_fired] run function evercraft:util/notify/emit
execute if entity @s[tag=ec.iai_fired] run tag @s remove ec.iai_fired

# Generic tier FX (common→rare; no-ops at ornate+)
function evercraft:fx/tier/read_mainhand
execute at @s run function evercraft:fx/tier/proc

# Achievement tracking
scoreboard players add @s ach.weapon_abilities 1
