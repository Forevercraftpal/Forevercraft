# Consecration — Bone Cudgel (Rare Beastlord)
# On undead kill: Strength I (5s) + all undead within 8 blocks glow
# "The holy aura reveals the undead"

advancement revoke @s only evercraft:artifacts/abilities/consecration_trigger

# Grant Strength I to the slayer
effect give @s strength 5 0 false

# Reveal all undead within 8 blocks (Glowing 5s)
execute at @s as @e[type=#minecraft:undead,distance=..8,limit=10] run effect give @s glowing 5 0 false

# Holy aura visuals
execute at @s run particle enchant ~ ~1 ~ 1 0.5 1 1 10
execute at @s run particle end_rod ~ ~1 ~ 0.5 0.5 0.5 0.05 4
execute as @a[distance=..16] if score @s ec.fx_snd matches 1.. run playsound minecraft:block.beacon.activate player @s ~ ~ ~ 0.5 1.5

# Bespoke FX flourish (channel-gated)
execute at @s run function evercraft:fx/bespoke/ability/consecration

# Achievement tracking
scoreboard players add @s ach.weapon_abilities 1
