# Shatter — Frostmourne Enhancement (Exquisite)
# On kill: AoE frost damage (3) + Slowness I to all mobs within 4 blocks
# Represents the frozen target shattering and sending ice shards outward
advancement revoke @s only evercraft:artifacts/abilities/frost_drain_kill_trigger

# AoE frost shatter — 3 damage + Slowness I (5s) to all nearby mobs
execute at @s as @e[type=#evercraft:aoe_targets,distance=..4] run damage @s 3 minecraft:freeze
execute at @s as @e[type=#evercraft:aoe_targets,distance=..4] run effect give @s slowness 5 0 false

# Visual/audio feedback — ice shatter
execute at @s run particle snowflake ~ ~1 ~ 1 0.5 1 0.1 15
execute at @s run particle block{block_state:{Name:"minecraft:blue_ice"}} ~ ~0.5 ~ 0.8 0.3 0.8 0.5 10
execute as @a[distance=..16] if score @s ec.fx_snd matches 1.. run playsound minecraft:block.glass.break player @s ~ ~ ~ 1 0.5
execute as @a[distance=..16] if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.chime player @s ~ ~ ~ 0.6 1.2
data modify storage evercraft:notify stage.c set value [{text:"Shatter!",color:"aqua",bold:true}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit

# Generic tier FX (common→rare; no-ops at ornate+)
function evercraft:fx/tier/read_mainhand
execute at @s run function evercraft:fx/tier/proc

# Achievement tracking
scoreboard players add @s ach.weapon_abilities 1
