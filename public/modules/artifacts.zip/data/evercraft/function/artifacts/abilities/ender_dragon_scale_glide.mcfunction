# Ender Dragon Scale — Dragon Ascendant glide hand-off
# Scheduled 40t after ender_dragon_scale_ascend (when the Levitation launch is ending). Hands off to Slow
# Falling for a controlled glide down + a dragon's-breath trail puff. Slow Falling 8s covers the descent;
# it self-expires (no strip). Runs as @s = the bearer (schedule preserves the executor).

effect give @s slow_falling 8 0 false
execute at @s run particle dragon_breath ~ ~0.5 ~ 0.4 0.4 0.4 0.04 25
execute at @s if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.wind_charge.wind_burst player @s ~ ~ ~ 0.6 1.2

# Two more trail puffs during the glide so the descent leaves a dragon's-breath wake
schedule function evercraft:artifacts/abilities/ender_dragon_scale_trail 20t
schedule function evercraft:artifacts/abilities/ender_dragon_scale_trail 40t
