# Macro inner: per-player hopper_minecart restore from per-player dragon_fan storage.
# Args from storage evercraft:artifacts cart:
#   pid = per-player session-counter (cheap UUID surrogate)
# Wiring Audit #5 W3b — paired with abilities/dragon_fan/restore.mcfunction (outer derives pid).

$data modify entity @e[type=hopper_minecart,tag=ec.df_temp.$(pid),limit=1] Items set value []
$kill @e[type=hopper_minecart,tag=ec.df_temp.$(pid)]
$summon hopper_minecart ~ 320 ~ {Tags:["ec.df_temp","ec.df_temp.$(pid)"],Items:[{Slot:0b,id:"minecraft:stone",count:1}]}
$data modify entity @e[type=hopper_minecart,tag=ec.df_temp.$(pid),limit=1] Items[0] merge from storage evercraft:item_restore dragon_fan.$(pid)
$item replace entity @s weapon.mainhand from entity @e[type=hopper_minecart,tag=ec.df_temp.$(pid),limit=1] container.0
$data modify entity @e[type=hopper_minecart,tag=ec.df_temp.$(pid),limit=1] Items set value []
$kill @e[type=hopper_minecart,tag=ec.df_temp.$(pid)]
