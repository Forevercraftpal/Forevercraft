# Clear the sng_deflected tag from all projectiles (Sculk Singularity deflect cleanup).
# Runs 3 seconds after a deflection (schedule-append from sculk_singularity_deflect). Mirrors
# artifacts/graviton_core/clear_deflect_tag.
tag @e[type=!player,tag=sng_deflected] remove sng_deflected
