# Fireforged 4pc — Phoenix Rebirth (Death Save), exquisite armor-SET marquee
# Triggers when the wearer of the full Fireforged set (tag fireforged_4pc) drops below 3 hearts
# (health_below_6). Reuses the SHARED phoenix rebirth body (heal + buffs + visuals + notify) from
# phoenix_totem_save_inner — NO duplicated save logic. This fn owns ONLY the set's OWN cooldown
# (ec.fireforged_cd, 3600s = 1 hour, so the set revive does NOT cheaply stack with a
# held Phoenix Totem / Feather). Decremented in player_tick's cd_* block (one writer beside this
# source-set). VALUE = SECONDS (1s player_tick cadence). Gated + Newcomer-exempt at the callsite.

# Shared rebirth body (heal + buffs + visuals + notify)
function evercraft:artifacts/abilities/phoenix_totem_save_inner

# Set 1 hour cooldown (3600s) — read by player_tick (decremented there, one writer)
scoreboard players set @s ec.fireforged_cd 3600
