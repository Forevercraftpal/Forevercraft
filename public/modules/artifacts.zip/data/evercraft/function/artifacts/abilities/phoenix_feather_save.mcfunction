# Phoenix Feather — Rebirth (Death Save), ornate tier
# Triggers when player health drops below 3 hearts (health_below_6) with the Phoenix Feather carried.
# Reuses the SHARED phoenix rebirth body (heal + buffs + visuals + notify) from phoenix_totem_save_inner
# — NO duplicated save logic. This fn owns ONLY the Feather's OWN cooldown (ec.cd_feather, 600s = 10min),
# longer than the mythical Phoenix Totem's revive since this is the cheaper ornate item. Decremented in
# player_tick's cd_* block (one writer beside this source-set). VALUE = SECONDS (1s player_tick cadence).

# Shared rebirth body (heal + buffs + visuals + notify)
function evercraft:artifacts/abilities/phoenix_totem_save_inner

# Set 10 minute cooldown (600s) — read by player_tick (decremented there, one writer)
scoreboard players set @s ec.cd_feather 600
