# Redstone Heart — Overclock (sneak-active mining burst)
# Called from the redstone_heart block in artifacts/accessories/player_tick when the bearer is sneaking
# AND off cooldown (ec.cd_overclock). Replaces the infeasible "auto-power 32b" / "furnaces 4x" claims with
# a real, vanilla-feasible burst: Haste IV for 8s (a large break-speed surge — Haste IS the vanilla
# mining-speed mechanic), layered over the item's always-on passive Haste III. effect give SETs (max-not-
# sum), so Haste IV wins for the 8s window then reverts to the passive III. Self-expiring: no attribute
# strip needed. Cooldown ec.cd_overclock (30s) is SET here, decremented in player_tick (one writer beside
# this source-set). 1s tick-down cadence -> VALUE = SECONDS, so 30 = 30 seconds.

# Overclock burst — Haste IV for 8s
effect give @s haste 8 3 false

# Redstone-themed visual + audio feedback
execute at @s run particle dust{color:[1.0,0.1,0.1],scale:1.2} ~ ~1 ~ 0.5 0.6 0.5 0 25
execute at @s run particle electric_spark ~ ~1 ~ 0.4 0.6 0.4 0.1 15
execute at @s if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.pling player @s ~ ~ ~ 0.8 0.6
execute at @s if score @s ec.fx_snd matches 1.. run playsound minecraft:block.beacon.activate player @s ~ ~ ~ 0.5 1.6

# Set 30-second cooldown (read + decremented in player_tick, one writer beside this set)
scoreboard players set @s ec.cd_overclock 30

# Actionbar notification
data modify storage evercraft:notify stage.c set value [{text:"Overclock! Haste surges (8s).",color:"red"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
