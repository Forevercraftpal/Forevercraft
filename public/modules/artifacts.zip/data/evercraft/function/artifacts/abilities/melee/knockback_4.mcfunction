# Melee Knockback 4 - Enhanced knockback on melee hit
# Knocks target back ~2.0 blocks (5 steps with collision checking)

advancement revoke @s only evercraft:artifacts/abilities/melee/knockback_4_trigger

# Tag the target entity
execute at @s as @e[type=!player,distance=..5,limit=1,sort=nearest,nbt={HurtTime:10s}] run tag @s add ec.kb

# Knock target away from player (0.4 blocks per step, stops at solid blocks)
execute as @e[tag=ec.kb] at @s facing entity @p feet positioned ^ ^ ^-0.4 if block ~ ~ ~ #minecraft:replaceable if block ~ ~1 ~ #minecraft:replaceable run tp @s ~ ~ ~
execute as @e[tag=ec.kb] at @s facing entity @p feet positioned ^ ^ ^-0.4 if block ~ ~ ~ #minecraft:replaceable if block ~ ~1 ~ #minecraft:replaceable run tp @s ~ ~ ~
execute as @e[tag=ec.kb] at @s facing entity @p feet positioned ^ ^ ^-0.4 if block ~ ~ ~ #minecraft:replaceable if block ~ ~1 ~ #minecraft:replaceable run tp @s ~ ~ ~
execute as @e[tag=ec.kb] at @s facing entity @p feet positioned ^ ^ ^-0.4 if block ~ ~ ~ #minecraft:replaceable if block ~ ~1 ~ #minecraft:replaceable run tp @s ~ ~ ~
execute as @e[tag=ec.kb] at @s facing entity @p feet positioned ^ ^ ^-0.4 if block ~ ~ ~ #minecraft:replaceable if block ~ ~1 ~ #minecraft:replaceable run tp @s ~ ~ ~

# Wall-slam bonus (kinetic): a mob knocked flush into a wall takes scaled bonus damage
scoreboard players set #kin_force ec.var 64
tag @s add ec.kin_attacker
function evercraft:kinetic/slam_kb
tag @s remove ec.kin_attacker

# Cleanup
tag @e[tag=ec.kb] remove ec.kb

# Visual feedback
execute at @s run particle crit ~ ~0.5 ~ 0.3 0.3 0.3 0.1 7
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.player.attack.knockback player @s ~ ~ ~ 0.8 0.6
