# Echo Mining — Soul Pickaxe
# On hit: Sonic pulse — AoE damage in 6 blocks
advancement revoke @s only evercraft:artifacts/abilities/echo_mining_trigger
execute at @s as @e[type=!player,type=!item,distance=..6,limit=5,sort=nearest] run damage @s 4 minecraft:sonic_boom
execute at @s run particle sonic_boom ~ ~1 ~ 0 0 0 0 1
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bass player @s ~ ~ ~ 0.4 0.5
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.amethyst_block.resonate player @s ~ ~ ~ 0.4 1.5

# Generic tier FX (common→rare; no-ops at ornate+)
function evercraft:fx/tier/read_mainhand
execute at @s run function evercraft:fx/tier/proc

# Achievement tracking
scoreboard players add @s ach.weapon_abilities 1
