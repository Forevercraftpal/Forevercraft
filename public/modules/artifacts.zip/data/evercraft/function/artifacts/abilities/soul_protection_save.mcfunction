# Soul Protection — Death Save
# Triggers when player health drops below 2 hearts with Soul Protection in inventory
# Heals player, applies protective buffs, sets 3-minute cooldown

# Heal to 10 HP (5 hearts)
effect give @s instant_health 1 1 false

# Protective buffs (totem-like save)
effect give @s absorption 5 3 false
effect give @s resistance 5 1 false
effect give @s fire_resistance 5 0 false

# Totem-like visual feedback
particle totem_of_undying ~ ~1 ~ 0.5 1 0.5 0.5 25
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:item.totem.use player @s ~ ~ ~ 1 1

# Set 3 minute cooldown (180 = 3min, decremented 1/sec in player_tick's 1s-cadence cd block).
# NOTE 2026-06-05: was 3600 ("ticks") but the decrement is PER-SECOND, so 3600 = 60 min; corrected to 180.
scoreboard players set @s ec.cd_soul 180

# Actionbar notification
data modify storage evercraft:notify stage.c set value [{text:"Soul Shield activated!",color:"gold"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
