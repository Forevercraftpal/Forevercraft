# Titan's Plate — Titan's Bulwark (sneak + look-down brace stance)
# Called from worn_tick_player when the wearer is sneaking, looking down, and off cooldown
# (ec.cd_titan). A deliberate "plant your feet" brace: Resistance II + Slowness I for 8s — a heavy
# defensive stance (you root in place and tank). effect give SETs (max-not-sum), self-expiring, no
# attribute strip needed. The passive +0.1 knockback_resistance is a baked static attr in the loot
# table. Cooldown ec.cd_titan (12s) is SET here, decremented in player_tick (one writer beside this
# source-set). 1s tick-down cadence -> VALUE = SECONDS, so 12 = 12 seconds.

# Brace stance — Resistance II + Slowness I for 8s
effect give @s resistance 8 1 false
effect give @s slowness 8 0 false

# Titan-themed visual + audio feedback (stone-brace slam)
execute at @s run particle block{block_state:"minecraft:deepslate"} ~ ~0.1 ~ 0.5 0.1 0.5 0.1 20
execute at @s run particle crit ~ ~1 ~ 0.4 0.6 0.4 0.05 12
execute at @s if score @s ec.fx_snd matches 1.. run playsound minecraft:block.anvil.land player @s ~ ~ ~ 0.5 0.4
execute at @s if score @s ec.fx_snd matches 1.. run playsound minecraft:block.beacon.activate player @s ~ ~ ~ 0.4 0.5

# Set 12-second cooldown (read + decremented in player_tick, one writer beside this set)
scoreboard players set @s ec.cd_titan 12

# Actionbar notification
data modify storage evercraft:notify stage.c set value [{text:"Titan's Bulwark braced (8s).",color:"dark_purple"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
