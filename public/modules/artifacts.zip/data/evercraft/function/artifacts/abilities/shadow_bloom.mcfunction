# Shadow Bloom — Soul Hoe
# On hit: Emanate darkness — blinds enemies, empowers self
advancement revoke @s only evercraft:artifacts/abilities/shadow_bloom_trigger
execute at @s run effect give @e[type=!player,type=!item,distance=..8,limit=3,sort=nearest] darkness 5 0 false
effect give @s strength 8 0 false
execute at @s run particle sculk_charge_pop ~ ~1 ~ 0.5 0.5 0.5 0.02 8
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bass player @s ~ ~ ~ 0.4 0.6
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.amethyst_block.resonate player @s ~ ~ ~ 0.4 1.5

# Generic tier FX (common→rare; no-ops at ornate+)
function evercraft:fx/tier/read_mainhand
execute at @s run function evercraft:fx/tier/proc

# Achievement tracking
scoreboard players add @s ach.weapon_abilities 1
