# Shadowstrike — Shadow Walker Boots Enhancement (Exquisite)
# First attack from stealth (invisibility from shadow_walk) deals +4 bonus damage
advancement revoke @s only evercraft:artifacts/abilities/shadowstrike_trigger

# Only trigger if player has invisibility (from shadow_walk sneaking)
execute unless entity @s[nbt={active_effects:[{id:"minecraft:invisibility"}]}] run return 0

# Shadowstrike: +4 bonus damage to nearest hurt target
execute at @s as @e[type=!player,distance=..5,limit=1,sort=nearest,nbt={HurtTime:10s}] run damage @s 4 minecraft:mob_attack

# Visual/audio feedback
data modify storage evercraft:notify stage.c set value [{text:"Shadowstrike!",color:"#4B0082",bold:true}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute at @s run particle witch ~ ~1 ~ 0.5 0.5 0.5 0.1 13
execute at @s run particle smoke ~ ~0.5 ~ 0.5 0.3 0.5 0.05 8
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.player.attack.crit player @s ~ ~ ~ 0.9 0.5
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.enderman.teleport player @s ~ ~ ~ 0.3 1.8

# Clear invisibility — stealth is broken
effect clear @s invisibility

# Generic tier FX (common→rare; no-ops at ornate+)
function evercraft:fx/tier/read_mainhand
execute at @s run function evercraft:fx/tier/proc

# Achievement tracking
scoreboard players add @s ach.weapon_abilities 1
