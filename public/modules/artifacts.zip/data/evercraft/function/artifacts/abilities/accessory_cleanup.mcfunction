# Accessory Cleanup - Remove attribute modifiers from items player no longer has
# Called from tick function for all players
# Check both container.* (hotbar+inventory) AND weapon.offhand (offhand slot)

# Remove Healer's Salve +2 Max Health bonus if not in inventory or offhand
execute unless items entity @s container.* *[custom_data~{artifact:"healers_salve"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"healers_salve"}] run attribute @s max_health modifier remove evercraft:healers_salve_health

# === Remove artifact passive Dream Rate modifiers when artifact leaves inventory ===
execute unless items entity @s container.* *[custom_data~{artifact:"pebble_of_dreams"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"pebble_of_dreams"}] run attribute @s luck modifier remove evercraft:pebble_of_dreams_luck
execute unless items entity @s container.* *[custom_data~{artifact:"aquamarine_ring"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"aquamarine_ring"}] run attribute @s luck modifier remove evercraft:aquamarine_ring_luck
execute unless items entity @s container.* *[custom_data~{artifact:"ruin_watch"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"ruin_watch"}] run attribute @s luck modifier remove evercraft:ruin_watch_luck
execute unless items entity @s container.* *[custom_data~{artifact:"miners_lantern"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"miners_lantern"}] run attribute @s luck modifier remove evercraft:miners_lantern_luck
execute unless items entity @s container.* *[custom_data~{artifact:"merchants_coin"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"merchants_coin"}] run attribute @s luck modifier remove evercraft:merchants_coin_luck
execute unless items entity @s container.* *[custom_data~{artifact:"anglers_pearl"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"anglers_pearl"}] run attribute @s luck modifier remove evercraft:anglers_pearl_luck
execute unless items entity @s container.* *[custom_data~{artifact:"enchanted_monocle"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"enchanted_monocle"}] run attribute @s luck modifier remove evercraft:enchanted_monocle_luck
execute unless items entity @s container.* *[custom_data~{artifact:"ring_of_undying"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"ring_of_undying"}] run attribute @s luck modifier remove evercraft:ring_of_undying_luck
execute unless items entity @s container.* *[custom_data~{artifact:"claudes_eye"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"claudes_eye"}] run attribute @s luck modifier remove evercraft:claudes_eye_luck
execute unless items entity @s container.* *[custom_data~{artifact:"sculk_heart"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"sculk_heart"}] run attribute @s luck modifier remove evercraft:sculk_heart_luck
# Berserker Totem +25% attack speed (re-added each tick while held in player_tick; the whetstone/beacon_eff
# attribute idiom — stripped here on removal). Frenzy + Slowness-clear are self-expiring effects, no strip.
execute unless items entity @s container.* *[custom_data~{artifact:"berserker_totem"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"berserker_totem"}] run attribute @s attack_speed modifier remove evercraft:berserker_totem_as
execute unless items entity @s container.* *[custom_data~{artifact:"ring_trial"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"ring_trial"}] run attribute @s luck modifier remove evercraft:trial_ring_luck
execute unless items entity @s container.* *[custom_data~{artifact:"codex_of_everything"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"codex_of_everything"}] run attribute @s luck modifier remove evercraft:codex_of_everything_luck
execute unless items entity @s container.* *[custom_data~{artifact:"beacon_of_ancients"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"beacon_of_ancients"}] run attribute @s luck modifier remove evercraft:beacon_of_ancients_luck
# Beacon of Ancients Builder's Legacy mining_efficiency +2 (re-added each tick while held in player_tick).
execute unless items entity @s container.* *[custom_data~{artifact:"beacon_of_ancients"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"beacon_of_ancients"}] run attribute @s mining_efficiency modifier remove evercraft:beacon_of_ancients_eff
# Netherite Nexus armor/toughness x2 (Nexus Field, 2026-06-10 — re-added each tick in player_tick).
execute unless items entity @s container.* *[custom_data~{artifact:"netherite_nexus"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"netherite_nexus"}] run attribute @s armor modifier remove evercraft:netherite_nexus_armor
execute unless items entity @s container.* *[custom_data~{artifact:"netherite_nexus"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"netherite_nexus"}] run attribute @s armor_toughness modifier remove evercraft:netherite_nexus_tough
# Claude's Gift "Claude's Touch" +1-enchant-equivalents (2026-06-10 — re-added each tick in player_tick).
execute unless items entity @s container.* *[custom_data~{artifact:"claudes_gift"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"claudes_gift"}] run attribute @s mining_efficiency modifier remove evercraft:claudes_gift_eff
execute unless items entity @s container.* *[custom_data~{artifact:"claudes_gift"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"claudes_gift"}] run attribute @s sneaking_speed modifier remove evercraft:claudes_gift_sneak
execute unless items entity @s container.* *[custom_data~{artifact:"claudes_gift"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"claudes_gift"}] run attribute @s water_movement_efficiency modifier remove evercraft:claudes_gift_dstr
execute unless items entity @s container.* *[custom_data~{artifact:"claudes_gift"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"claudes_gift"}] run attribute @s oxygen_bonus modifier remove evercraft:claudes_gift_resp
execute unless items entity @s container.* *[custom_data~{artifact:"netherite_nexus"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"netherite_nexus"}] run attribute @s luck modifier remove evercraft:netherite_nexus_luck
execute unless items entity @s container.* *[custom_data~{artifact:"netherite_nexus"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"netherite_nexus"}] run attribute @s knockback_resistance modifier remove evercraft:netherite_nexus_kb
execute unless items entity @s container.* *[custom_data~{artifact:"claudes_gift"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"claudes_gift"}] run attribute @s luck modifier remove evercraft:claudes_gift_luck
# Nether Star Shard self +2 Dream Rate (Star Power aura's self-perk; party Haste/Speed/Regen are self-expiring effects).
execute unless items entity @s container.* *[custom_data~{artifact:"nether_star_shard"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"nether_star_shard"}] run attribute @s luck modifier remove evercraft:nether_star_shard_luck

# === Family B new leaves (art-B) — Dream Rate modifier cleanup ===
# Strip each new B leaf's luck modifier the moment it leaves the inventory. For the conditional-DR
# leaves (Geologist's Loupe / Cache-Eye / Worldforge Ember) the player_tick block already strips
# when the activity window is closed, but the unconditional removal here guarantees cleanup the
# moment the item leaves (the activity window may still be open when the item is dropped). Worldforge
# Ember's +2 CR lever needs no strip — it lives in calculate.mcfunction gated `if items`, so it
# vanishes the next recompute when the item is gone.
execute unless items entity @s container.* *[custom_data~{artifact:"wishing_shard"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"wishing_shard"}] run attribute @s luck modifier remove evercraft:wishing_shard_luck
execute unless items entity @s container.* *[custom_data~{artifact:"dreamspun_crown"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"dreamspun_crown"}] run attribute @s luck modifier remove evercraft:dreamspun_crown_luck
execute unless items entity @s container.* *[custom_data~{artifact:"geologist_loupe"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"geologist_loupe"}] run attribute @s luck modifier remove evercraft:geologist_loupe_luck
execute unless items entity @s container.* *[custom_data~{artifact:"cache_eye"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"cache_eye"}] run attribute @s luck modifier remove evercraft:cache_eye_luck
execute unless items entity @s container.* *[custom_data~{artifact:"worldforge_ember"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"worldforge_ember"}] run attribute @s luck modifier remove evercraft:worldforge_ember_luck

# === Family C — Wayfarer (art-C) — Far-Lens waypoint-range modifier cleanup ===
# Strip Voyager's Far-Lens's waypoint_receive_range modifier the moment it leaves the inventory. (The
# other 6 Wayfarer leaves grant NO attribute modifier — they are pure readouts/light/locate, so they
# need no cleanup here; the Lantern-Lichen Clasp's transient light block is reverted in player_tick's
# own not-held branch.) NO DR on the whole family (balance-neutral bundle).
execute unless items entity @s container.* *[custom_data~{artifact:"voyagers_far_lens"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"voyagers_far_lens"}] run attribute @s waypoint_receive_range modifier remove evercraft:voyagers_far_lens_wp

# === Family F — Builder / traversal-QoL leaves (art-F) — attribute modifier cleanup ===
# Strip each F-adjacent leaf's attribute modifier the moment it leaves the inventory (the same
# clear-on-removal idiom the Far-Lens uses above). These route to L's Stride Line + K's Surveyor Line
# per Review Decision-6, but all hang on the accessories chassis, so their cleanup lives here. The
# Featherfall gravity-glide modifier (evercraft:featherfall_glide) is normally removed in player_tick
# the tick the player lands; this unconditional removal-on-drop guarantees it never lingers if the knot
# is dropped MID-FALL (while the gravity modifier is still applied). Steady-Hand Caliper grants only a
# transient particle ghost (no attribute modifier), so it needs no strip. No DR/luck on any F leaf.
execute unless items entity @s container.* *[custom_data~{artifact:"masons_long_arm_band"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"masons_long_arm_band"}] run attribute @s block_interaction_range modifier remove evercraft:masons_long_arm_reach
execute unless items entity @s container.* *[custom_data~{artifact:"surveyors_reach_glass"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"surveyors_reach_glass"}] run attribute @s block_interaction_range modifier remove evercraft:surveyors_reach_glass
execute unless items entity @s container.* *[custom_data~{artifact:"builders_loftstride"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"builders_loftstride"}] run attribute @s step_height modifier remove evercraft:builders_loftstride_step
execute unless items entity @s container.* *[custom_data~{artifact:"builders_loftstride"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"builders_loftstride"}] run attribute @s block_interaction_range modifier remove evercraft:builders_loftstride_reach
execute unless items entity @s container.* *[custom_data~{artifact:"sure_step_pebble"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"sure_step_pebble"}] run attribute @s step_height modifier remove evercraft:sure_step_pebble_step
execute unless items entity @s container.* *[custom_data~{artifact:"wayfarers_greaves"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"wayfarers_greaves"}] run attribute @s step_height modifier remove evercraft:wayfarers_greaves_step
execute unless items entity @s container.* *[custom_data~{artifact:"wayfarers_greaves"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"wayfarers_greaves"}] run attribute @s fall_damage_multiplier modifier remove evercraft:wayfarers_greaves_fall
execute unless items entity @s container.* *[custom_data~{artifact:"featherfall_glider_knot"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"featherfall_glider_knot"}] run attribute @s safe_fall_distance modifier remove evercraft:featherfall_safe_fall
execute unless items entity @s container.* *[custom_data~{artifact:"featherfall_glider_knot"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"featherfall_glider_knot"}] run attribute @s gravity modifier remove evercraft:featherfall_glide
execute unless items entity @s container.* *[custom_data~{artifact:"featherfall_glider_knot"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"featherfall_glider_knot"}] run attribute @s fall_damage_multiplier modifier remove evercraft:featherfall_glider_knot_fall
# Phantom Charm 50% fall-damage reduction + Wind Chime fall-damage reduction (the featherscale_down fall idiom).
execute unless items entity @s container.* *[custom_data~{artifact:"phantom_charm"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"phantom_charm"}] run attribute @s fall_damage_multiplier modifier remove evercraft:phantom_charm_fall
execute unless items entity @s container.* *[custom_data~{artifact:"wind_chime"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"wind_chime"}] run attribute @s fall_damage_multiplier modifier remove evercraft:wind_chime_fall

# === Family G — Forge Trade (Grandforge Regalia) attribute modifier cleanup (art-G) ===
# Strip each forge leaf's break-speed / mining-efficiency / armor modifier the moment it leaves the
# inventory. The break-speed (% add_multiplied_base) + mining_efficiency (add_value) leaves are
# re-added every tick in player_tick while held, so this removal-on-drop is the clear-on-removal
# guarantee. The Ember-Forged Band's two CONDITIONAL modifiers (armor + break-speed, on near-heat)
# are also removed each tick in player_tick (remove-then-conditional-add), but these unconditional
# removal-on-drop lines guarantee they never linger if the band is dropped WHILE near heat. No
# DR/luck on any G leaf (G = bundle, DR 0) so no luck-modifier strip here. The 3 CR levers
# (C10/C16/C17) are scoreboard set-not-add in calculate.mcfunction (re-summed each calc -> drop the
# charm and the next calc zeroes ec.cr_temp; nothing to strip here).
execute unless items entity @s container.* *[custom_data~{artifact:"quarry_worn_knuckle"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"quarry_worn_knuckle"}] run attribute @s block_break_speed modifier remove evercraft:quarry_worn_knuckle
execute unless items entity @s container.* *[custom_data~{artifact:"quenching_stone"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"quenching_stone"}] run attribute @s block_break_speed modifier remove evercraft:quenching_stone
execute unless items entity @s container.* *[custom_data~{artifact:"quarrymans_grip"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"quarrymans_grip"}] run attribute @s block_break_speed modifier remove evercraft:quarrymans_grip
execute unless items entity @s container.* *[custom_data~{artifact:"grand_anvil_heart"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"grand_anvil_heart"}] run attribute @s block_break_speed modifier remove evercraft:grand_anvil_heart_bs
execute unless items entity @s container.* *[custom_data~{artifact:"whetstone_charm"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"whetstone_charm"}] run attribute @s mining_efficiency modifier remove evercraft:whetstone_charm
execute unless items entity @s container.* *[custom_data~{artifact:"tinsmiths_pocket_hammer"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"tinsmiths_pocket_hammer"}] run attribute @s mining_efficiency modifier remove evercraft:tinsmiths_pocket_hammer
execute unless items entity @s container.* *[custom_data~{artifact:"forge_charm"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"forge_charm"}] run attribute @s mining_efficiency modifier remove evercraft:forge_charm_eff
execute unless items entity @s container.* *[custom_data~{artifact:"forge_charm"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"forge_charm"}] run attribute @s block_break_speed modifier remove evercraft:forge_charm_bs
execute unless items entity @s container.* *[custom_data~{artifact:"forge_seed_a"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"forge_seed_a"}] run attribute @s block_break_speed modifier remove evercraft:forge_seed_a_bs
execute unless items entity @s container.* *[custom_data~{artifact:"forge_seed_b"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"forge_seed_b"}] run attribute @s submerged_mining_speed modifier remove evercraft:forge_seed_b_sub
execute unless items entity @s container.* *[custom_data~{artifact:"ember_forged_band"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"ember_forged_band"}] run attribute @s armor modifier remove evercraft:ember_forged_band_armor
execute unless items entity @s container.* *[custom_data~{artifact:"ember_forged_band"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"ember_forged_band"}] run attribute @s block_break_speed modifier remove evercraft:ember_forged_band_bs

# === Family G — Grandforge Regalia tree (Fusion / cap-G) consolidated attribute cleanup ===
# The grand Grandforge Regalia + its NEW sub-bindings (Smith's Apron / Quench Line) grant their
# consolidated forge attributes via DISTINCT capstone-scoped ids (NOT the loose leaf ids) in their
# tinkering/grandforge/*_apply fns (re-added every tick while held). Strip each capstone id the moment
# its node leaves the inventory — the clear-on-removal guarantee (mirrors the loose leaf strips above +
# the cap-C Far-Lens waypoint strip). The grand's Ember-Forged Band conditional pair (grandforge_band_*)
# is also remove-then-conditional-added each tick in grandforge_regalia_apply, but these unconditional
# removal-on-drop lines guarantee they never linger if the Regalia is dropped WHILE near heat. Forge
# Resolve carries NO persistent attribute (its perks are event-gated), so it needs no strip. NO DR/luck
# on any G node (G = bundle, DR 0). The consolidated CR is scoreboard set-not-add in calculate.mcfunction
# (re-summed each calc -> drop the node and the next calc zeroes ec.cr_temp; nothing to strip here).
execute unless items entity @s container.* *[custom_data~{grandforge_regalia:true}] unless items entity @s weapon.offhand *[custom_data~{grandforge_regalia:true}] run attribute @s block_break_speed modifier remove evercraft:grandforge_bs
execute unless items entity @s container.* *[custom_data~{grandforge_regalia:true}] unless items entity @s weapon.offhand *[custom_data~{grandforge_regalia:true}] run attribute @s mining_efficiency modifier remove evercraft:grandforge_eff
execute unless items entity @s container.* *[custom_data~{grandforge_regalia:true}] unless items entity @s weapon.offhand *[custom_data~{grandforge_regalia:true}] run attribute @s armor modifier remove evercraft:grandforge_band_armor
execute unless items entity @s container.* *[custom_data~{grandforge_regalia:true}] unless items entity @s weapon.offhand *[custom_data~{grandforge_regalia:true}] run attribute @s block_break_speed modifier remove evercraft:grandforge_band_bs
execute unless items entity @s container.* *[custom_data~{smiths_apron:true}] unless items entity @s weapon.offhand *[custom_data~{smiths_apron:true}] run attribute @s mining_efficiency modifier remove evercraft:smiths_apron_eff
execute unless items entity @s container.* *[custom_data~{quench_line:true}] unless items entity @s weapon.offhand *[custom_data~{quench_line:true}] run attribute @s block_break_speed modifier remove evercraft:quench_line_bs
execute unless items entity @s container.* *[custom_data~{quench_line:true}] unless items entity @s weapon.offhand *[custom_data~{quench_line:true}] run attribute @s mining_efficiency modifier remove evercraft:quench_line_eff

# === Family J — Harvest & Tide (Cornucopia Tide) attribute + conditional-DR cleanup (art-J) ===
# Strip each J modifier the moment its leaf leaves the inventory. The conditional-DR fishing pieces
# (Riverpearl/Deepcurrent) are ALSO remove-then-conditional-add each tick in player_tick (so their
# luck drops the instant the condition lapses); these unconditional removal-on-drop lines guarantee
# the modifier never lingers if the leaf is dropped WHILE the condition is true (in water / fishing) —
# exactly the Geologist's Loupe removal-on-drop pattern. The aquatic-attribute pieces (Coral Diver's
# Pearl / Tidefinder's Astrolite) are re-added each tick while held, so this is their clear-on-removal
# guarantee. The Lure-on-rod injects (C31/C34) self-clean via their own *_cleanup fns (held tag). The
# CR/cook-quality/harvest-yield levers are scoreboard set-not-add / break-event rolls — nothing to
# strip here.
execute unless items entity @s container.* *[custom_data~{artifact:"riverpearl_charm"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"riverpearl_charm"}] run attribute @s luck modifier remove evercraft:riverpearl_charm_luck
execute unless items entity @s container.* *[custom_data~{artifact:"deepcurrent_reliquary"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"deepcurrent_reliquary"}] run attribute @s luck modifier remove evercraft:deepcurrent_reliquary_luck
execute unless items entity @s container.* *[custom_data~{artifact:"coral_divers_pearl"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"coral_divers_pearl"}] run attribute @s submerged_mining_speed modifier remove evercraft:coral_divers_pearl_smine
execute unless items entity @s container.* *[custom_data~{artifact:"coral_divers_pearl"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"coral_divers_pearl"}] run attribute @s water_movement_efficiency modifier remove evercraft:coral_divers_pearl_wme
execute unless items entity @s container.* *[custom_data~{artifact:"sea_heart_relic"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"sea_heart_relic"}] run attribute @s submerged_mining_speed modifier remove evercraft:sea_heart_mining
execute unless items entity @s container.* *[custom_data~{artifact:"tidefinders_astrolite"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"tidefinders_astrolite"}] run attribute @s submerged_mining_speed modifier remove evercraft:tidefinders_astrolite_smine

# === Family J — Cornucopia Tide tree (Fusion / cap-J) consolidated attribute + conditional-DR cleanup ===
# Strip the cap-J consolidated DISTINCT ids (NOT the loose leaf ids above — those are owned by the
# art-J cleanup block) the moment the node leaves the inventory. The conditional-DR folds
# (cornucopia_tide_luck / tidewright_luck) are ALSO remove-then-conditional-add each tick in player_tick;
# these unconditional removal-on-drop lines guarantee no linger if the node is dropped WHILE the
# condition is true (fishing / in water) — the Geologist's Loupe removal-on-drop pattern. The aquatic
# attrs (smine / wme) are re-added each tick while held → this is their clear-on-removal guarantee. The
# CR / cook-quality / crop-yield / crate levers are scoreboard set-not-add / break-event rolls — nothing
# to strip. The Net/grand lure-on-rod injects (Lure II + LotS III) are stripped here when the node is no
# longer held AND a rod is held (the fast_fishing removal-on-drop idiom; the *_fishing tag gates it).
execute unless items entity @s container.* *[custom_data~{cornucopia_tide:true}] unless items entity @s weapon.offhand *[custom_data~{cornucopia_tide:true}] run attribute @s luck modifier remove evercraft:cornucopia_tide_luck
execute unless items entity @s container.* *[custom_data~{cornucopia_tide:true}] unless items entity @s weapon.offhand *[custom_data~{cornucopia_tide:true}] run attribute @s submerged_mining_speed modifier remove evercraft:cornucopia_tide_smine
execute unless items entity @s container.* *[custom_data~{cornucopia_tide:true}] unless items entity @s weapon.offhand *[custom_data~{cornucopia_tide:true}] run attribute @s water_movement_efficiency modifier remove evercraft:cornucopia_tide_wme
execute unless items entity @s container.* *[custom_data~{tidewrights_net:true}] unless items entity @s weapon.offhand *[custom_data~{tidewrights_net:true}] run attribute @s luck modifier remove evercraft:tidewright_luck
execute unless items entity @s container.* *[custom_data~{tidewrights_net:true}] unless items entity @s weapon.offhand *[custom_data~{tidewrights_net:true}] run attribute @s submerged_mining_speed modifier remove evercraft:tidewrights_net_smine
execute unless items entity @s container.* *[custom_data~{tidewrights_net:true}] unless items entity @s weapon.offhand *[custom_data~{tidewrights_net:true}] run attribute @s water_movement_efficiency modifier remove evercraft:tidewrights_net_wme
execute unless items entity @s container.* *[custom_data~{harvest_knot:true}] unless items entity @s weapon.offhand *[custom_data~{harvest_knot:true}] run attribute @s submerged_mining_speed modifier remove evercraft:harvest_knot_smine
# Net lure-on-rod cleanup (strip the injected Lure II + LotS III when the Net is no longer held).
execute if entity @s[tag=ec.tidewrights_net_fishing] unless items entity @s container.* *[custom_data~{tidewrights_net:true}] unless items entity @s weapon.offhand *[custom_data~{tidewrights_net:true}] if items entity @s weapon.mainhand minecraft:fishing_rod run item modify entity @s weapon.mainhand evercraft:fishing_remove
execute if entity @s[tag=ec.tidewrights_net_fishing] unless items entity @s weapon.mainhand minecraft:fishing_rod run tag @s remove ec.tidewrights_net_fishing
execute if entity @s[tag=ec.tidewrights_net_fishing] unless items entity @s container.* *[custom_data~{tidewrights_net:true}] unless items entity @s weapon.offhand *[custom_data~{tidewrights_net:true}] run tag @s remove ec.tidewrights_net_fishing
# Grand Cornucopia Tide lure-on-rod cleanup (same shape).
execute if entity @s[tag=ec.cornucopia_tide_fishing] unless items entity @s container.* *[custom_data~{cornucopia_tide:true}] unless items entity @s weapon.offhand *[custom_data~{cornucopia_tide:true}] if items entity @s weapon.mainhand minecraft:fishing_rod run item modify entity @s weapon.mainhand evercraft:fishing_remove
execute if entity @s[tag=ec.cornucopia_tide_fishing] unless items entity @s weapon.mainhand minecraft:fishing_rod run tag @s remove ec.cornucopia_tide_fishing
execute if entity @s[tag=ec.cornucopia_tide_fishing] unless items entity @s container.* *[custom_data~{cornucopia_tide:true}] unless items entity @s weapon.offhand *[custom_data~{cornucopia_tide:true}] run tag @s remove ec.cornucopia_tide_fishing

# === Family K — Prospector (Demiurge's Spirit Artifact) attribute + conditional-DR cleanup (art-K) ===
# Strip each K modifier the moment its leaf leaves the inventory. Tidewright's Pearl (C3) is a
# CONDITIONAL aquatic kit (remove-then-conditional-add each tick in player_tick, gated on in_water);
# these unconditional removal-on-drop lines guarantee its three modifiers never linger if the Pearl is
# dropped WHILE submerged (the Geologist removal-on-drop pattern). Driftcurrent Fin (U11) re-adds its
# two modifiers each tick while held -> this is its clear-on-removal guarantee. The Demiurge's Spirit Artifact
# consolidated mining-DR (conditional, pre-wired for cap-K) is also remove-then-conditional-add in
# player_tick; this strips it on drop-while-mining. The crate/yield/access/survey leaves (C4/C6/C7/C8/
# C9/C43/C46/U6/U10/U12/U13/U19/U20/U21) carry NO attribute modifier (break-event rolls / readouts) —
# nothing to strip here.
execute unless items entity @s container.* *[custom_data~{artifact:"tidewright_pearl"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"tidewright_pearl"}] run attribute @s submerged_mining_speed modifier remove evercraft:tidewright_pearl_smine
execute unless items entity @s container.* *[custom_data~{artifact:"tidewright_pearl"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"tidewright_pearl"}] run attribute @s water_movement_efficiency modifier remove evercraft:tidewright_pearl_wme
execute unless items entity @s container.* *[custom_data~{artifact:"tidewright_pearl"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"tidewright_pearl"}] run attribute @s oxygen_bonus modifier remove evercraft:tidewright_pearl_o2
execute unless items entity @s container.* *[custom_data~{artifact:"driftcurrent_fin"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"driftcurrent_fin"}] run attribute @s submerged_mining_speed modifier remove evercraft:driftcurrent_fin_smine
execute unless items entity @s container.* *[custom_data~{artifact:"driftcurrent_fin"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"driftcurrent_fin"}] run attribute @s water_movement_efficiency modifier remove evercraft:driftcurrent_fin_wme
execute unless items entity @s container.* *[custom_data~{artifact:"demiurges_capstone"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"demiurges_capstone"}] run attribute @s luck modifier remove evercraft:demiurges_capstone_luck

# === Family K — Demiurge's Spirit Artifact tree (Fusion / cap-K) consolidated attribute cleanup ===
# Strip the grand + Deepdig sub-cap consolidated attribute modifiers the moment their node leaves the
# inventory. These are DISTINCT capstone-scoped ids (NOT the loose leaf ids) re-added each tick in
# tinkering/demiurge/*_apply — so when the node is dropped, this is their clear-on-removal guarantee. The
# grand's aquatic kit (demiurge_smine/_wme/_o2) is ALSO remove-then-conditional-add each tick in the apply
# (gated on in_water); these unconditional drop-removals guarantee they never linger if the Capstone is
# dropped WHILE submerged (the Pearl drop-while-submerged pattern). The conditional mining-DR
# (demiurges_capstone_luck) is stripped above (it is remove-then-conditional-add in player_tick). The CR
# (+8.0) is the nuclear-reset-cleared ec.cr_temp; the yield/crate/access levers are event hooks (nothing
# to strip). Node Mastery / Surveyor Line carry NO attribute (their per-tick perk is only the Astrolabe
# pip / a no-op) -> nothing to strip for those two.
execute unless items entity @s container.* *[custom_data~{demiurges_capstone:true}] unless items entity @s weapon.offhand *[custom_data~{demiurges_capstone:true}] run attribute @s block_break_speed modifier remove evercraft:demiurge_bs
execute unless items entity @s container.* *[custom_data~{demiurges_capstone:true}] unless items entity @s weapon.offhand *[custom_data~{demiurges_capstone:true}] run attribute @s mining_efficiency modifier remove evercraft:demiurge_eff
execute unless items entity @s container.* *[custom_data~{demiurges_capstone:true}] unless items entity @s weapon.offhand *[custom_data~{demiurges_capstone:true}] run attribute @s block_interaction_range modifier remove evercraft:demiurge_reach
execute unless items entity @s container.* *[custom_data~{demiurges_capstone:true}] unless items entity @s weapon.offhand *[custom_data~{demiurges_capstone:true}] run attribute @s submerged_mining_speed modifier remove evercraft:demiurge_smine
execute unless items entity @s container.* *[custom_data~{demiurges_capstone:true}] unless items entity @s weapon.offhand *[custom_data~{demiurges_capstone:true}] run attribute @s water_movement_efficiency modifier remove evercraft:demiurge_wme
execute unless items entity @s container.* *[custom_data~{demiurges_capstone:true}] unless items entity @s weapon.offhand *[custom_data~{demiurges_capstone:true}] run attribute @s oxygen_bonus modifier remove evercraft:demiurge_o2
execute unless items entity @s container.* *[custom_data~{deepdig_line:true}] unless items entity @s weapon.offhand *[custom_data~{deepdig_line:true}] run attribute @s submerged_mining_speed modifier remove evercraft:deepdig_smine
execute unless items entity @s container.* *[custom_data~{deepdig_line:true}] unless items entity @s weapon.offhand *[custom_data~{deepdig_line:true}] run attribute @s water_movement_efficiency modifier remove evercraft:deepdig_wme
execute unless items entity @s container.* *[custom_data~{deepdig_line:true}] unless items entity @s weapon.offhand *[custom_data~{deepdig_line:true}] run attribute @s oxygen_bonus modifier remove evercraft:deepdig_o2

# === Family L — Vanguard (Heart of the Mountain) attribute + conditional-DR cleanup (art-L) ===
# Strip each L combat/armor modifier the moment its leaf leaves the inventory. The conditional pieces
# (B5 Sprinter's Anklet movement_speed, B6 Reaver's Knuckle attack_damage, B10 Resonant Locket's
# node-DR luck) are remove-then-conditional-add each tick in player_tick; these unconditional removal-
# on-drop lines guarantee those modifiers never linger if the piece is dropped WHILE the condition holds
# (the Geologist removal-on-drop pattern). The 4 re-homed mythical defense stones run via effects/their
# own legacy blocks (no NEW L attribute modifier) and #7 Bastion Totem is effect-only -> nothing to
# strip for those. P2's CR lever is a scoreboard slot re-summed each tick in craft_rate/calculate
# (no modifier to strip); only its attack_damage modifier is stripped here.
execute unless items entity @s container.* *[custom_data~{artifact:"stoneward_pebble"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"stoneward_pebble"}] run attribute @s armor modifier remove evercraft:stoneward_pebble_armor
execute unless items entity @s container.* *[custom_data~{artifact:"iron_talisman"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"iron_talisman"}] run attribute @s armor modifier remove evercraft:iron_talisman_armor
execute unless items entity @s container.* *[custom_data~{artifact:"vital_acorn"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"vital_acorn"}] run attribute @s max_health modifier remove evercraft:vital_acorn_health
execute unless items entity @s container.* *[custom_data~{artifact:"sprinters_anklet"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"sprinters_anklet"}] run attribute @s movement_speed modifier remove evercraft:sprinters_anklet_spd
execute unless items entity @s container.* *[custom_data~{artifact:"reavers_knuckle"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"reavers_knuckle"}] run attribute @s attack_damage modifier remove evercraft:reavers_knuckle_atk
execute unless items entity @s container.* *[custom_data~{artifact:"anvil_heart"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"anvil_heart"}] run attribute @s armor_toughness modifier remove evercraft:anvil_heart_tough
execute unless items entity @s container.* *[custom_data~{artifact:"anvil_heart"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"anvil_heart"}] run attribute @s knockback_resistance modifier remove evercraft:anvil_heart_kb
execute unless items entity @s container.* *[custom_data~{artifact:"resonant_locket"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"resonant_locket"}] run attribute @s attack_damage modifier remove evercraft:resonant_locket_atk
execute unless items entity @s container.* *[custom_data~{artifact:"resonant_locket"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"resonant_locket"}] run attribute @s luck modifier remove evercraft:resonant_locket_luck
execute unless items entity @s container.* *[custom_data~{artifact:"bulwark_plate"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"bulwark_plate"}] run attribute @s armor modifier remove evercraft:bulwark_plate_armor
execute unless items entity @s container.* *[custom_data~{artifact:"bulwark_plate"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"bulwark_plate"}] run attribute @s armor_toughness modifier remove evercraft:bulwark_plate_tough
execute unless items entity @s container.* *[custom_data~{artifact:"bulwark_plate"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"bulwark_plate"}] run attribute @s explosion_knockback_resistance modifier remove evercraft:bulwark_plate_ekb
execute unless items entity @s container.* *[custom_data~{artifact:"ascendant_forgeheart"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"ascendant_forgeheart"}] run attribute @s attack_damage modifier remove evercraft:ascendant_forgeheart_atk

# === Family M — Dragonheart leaf attribute cleanup (art-M) ===
# Strip each Dragonheart leaf's fixed-id attribute modifier the moment its leaf leaves the inventory (the
# stoneward_pebble / anvil_heart removal-on-drop idiom). These four leaves carry an always-on attribute
# (Wyrmscale Plate toughness · Ridgeback Spur knockback-resist · Wyrmtooth Fang attack · Featherscale Down
# fall-immunity); the rest of the family's perks are self-expiring effects / the breath-cone / the dodge
# lane (nothing to strip). Each id is distinct, so the strip never clobbers an active sibling.
execute unless items entity @s container.* *[custom_data~{artifact:"wyrmscale_plate"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"wyrmscale_plate"}] run attribute @s armor_toughness modifier remove evercraft:wyrmscale_plate_tough
execute unless items entity @s container.* *[custom_data~{artifact:"ridgeback_spur"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"ridgeback_spur"}] run attribute @s knockback_resistance modifier remove evercraft:ridgeback_spur_kb
execute unless items entity @s container.* *[custom_data~{artifact:"wyrmscale_plate"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"wyrmscale_plate"}] run attribute @s knockback_resistance modifier remove evercraft:wyrmscale_plate_kb
execute unless items entity @s container.* *[custom_data~{artifact:"wyrmtooth_fang"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"wyrmtooth_fang"}] run attribute @s attack_damage modifier remove evercraft:wyrmtooth_fang_atk
execute unless items entity @s container.* *[custom_data~{artifact:"featherscale_down"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"featherscale_down"}] run attribute @s fall_damage_multiplier modifier remove evercraft:featherscale_down_fall

# === Family L — Heart of the Mountain tree (Fusion / cap-L) consolidated attribute + conditional-DR cleanup ===
# Strip the grand + sub-cap consolidated attribute modifiers the moment their node leaves the inventory.
# These are DISTINCT capstone-scoped ids (NOT the loose leaf ids) re-added each tick in tinkering/heart/*_apply
# (the grand calls all four sub-cap applies) — so when the node is dropped, this is their clear-on-removal
# guarantee. The conditional pieces (Stride Line stride_spd, Ascendant Line ascendant_atk_hp +
# ascendant_locket_luck) are ALSO remove-then-conditional-add each tick in their apply; these unconditional
# drop-removals guarantee they never linger if the node is dropped WHILE the condition holds (the Geologist
# removal-on-drop pattern). The Titan Core grants only Form-2 effects (no attribute modifier) -> nothing to
# strip for it. The CR (+5.0) is the nuclear-reset-cleared ec.cr_temp (no modifier to strip). Each strip is
# `unless` BOTH the matching sub-cap AND the grand are held (the grand calls the sub-cap apply, so the id is
# live while either is held -> only strip when neither is).
# Bulwark Stone consolidated tank attrs (live while titan_bulwark OR heart_of_the_mountain held).
execute unless items entity @s container.* *[custom_data~{titan_bulwark:true}] unless items entity @s weapon.offhand *[custom_data~{titan_bulwark:true}] unless items entity @s container.* *[custom_data~{heart_of_the_mountain:true}] unless items entity @s weapon.offhand *[custom_data~{heart_of_the_mountain:true}] run attribute @s armor modifier remove evercraft:titan_bulwark_armor
execute unless items entity @s container.* *[custom_data~{titan_bulwark:true}] unless items entity @s weapon.offhand *[custom_data~{titan_bulwark:true}] unless items entity @s container.* *[custom_data~{heart_of_the_mountain:true}] unless items entity @s weapon.offhand *[custom_data~{heart_of_the_mountain:true}] run attribute @s armor_toughness modifier remove evercraft:titan_bulwark_tough
execute unless items entity @s container.* *[custom_data~{titan_bulwark:true}] unless items entity @s weapon.offhand *[custom_data~{titan_bulwark:true}] unless items entity @s container.* *[custom_data~{heart_of_the_mountain:true}] unless items entity @s weapon.offhand *[custom_data~{heart_of_the_mountain:true}] run attribute @s max_health modifier remove evercraft:titan_bulwark_hp
execute unless items entity @s container.* *[custom_data~{titan_bulwark:true}] unless items entity @s weapon.offhand *[custom_data~{titan_bulwark:true}] unless items entity @s container.* *[custom_data~{heart_of_the_mountain:true}] unless items entity @s weapon.offhand *[custom_data~{heart_of_the_mountain:true}] run attribute @s knockback_resistance modifier remove evercraft:titan_bulwark_kb
execute unless items entity @s container.* *[custom_data~{titan_bulwark:true}] unless items entity @s weapon.offhand *[custom_data~{titan_bulwark:true}] unless items entity @s container.* *[custom_data~{heart_of_the_mountain:true}] unless items entity @s weapon.offhand *[custom_data~{heart_of_the_mountain:true}] run attribute @s explosion_knockback_resistance modifier remove evercraft:titan_bulwark_ekb
# Ascendant Line consolidated combat attrs + conditional node-DR (live while ascendant_line OR grand held).
execute unless items entity @s container.* *[custom_data~{ascendant_line:true}] unless items entity @s weapon.offhand *[custom_data~{ascendant_line:true}] unless items entity @s container.* *[custom_data~{heart_of_the_mountain:true}] unless items entity @s weapon.offhand *[custom_data~{heart_of_the_mountain:true}] run attribute @s attack_damage modifier remove evercraft:ascendant_atk
execute unless items entity @s container.* *[custom_data~{ascendant_line:true}] unless items entity @s weapon.offhand *[custom_data~{ascendant_line:true}] unless items entity @s container.* *[custom_data~{heart_of_the_mountain:true}] unless items entity @s weapon.offhand *[custom_data~{heart_of_the_mountain:true}] run attribute @s attack_damage modifier remove evercraft:ascendant_atk_hp
execute unless items entity @s container.* *[custom_data~{ascendant_line:true}] unless items entity @s weapon.offhand *[custom_data~{ascendant_line:true}] unless items entity @s container.* *[custom_data~{heart_of_the_mountain:true}] unless items entity @s weapon.offhand *[custom_data~{heart_of_the_mountain:true}] run attribute @s luck modifier remove evercraft:ascendant_locket_luck
# Stride Line consolidated traversal attrs (live while stride_line OR grand held).
execute unless items entity @s container.* *[custom_data~{stride_line:true}] unless items entity @s weapon.offhand *[custom_data~{stride_line:true}] unless items entity @s container.* *[custom_data~{heart_of_the_mountain:true}] unless items entity @s weapon.offhand *[custom_data~{heart_of_the_mountain:true}] run attribute @s step_height modifier remove evercraft:stride_step
execute unless items entity @s container.* *[custom_data~{stride_line:true}] unless items entity @s weapon.offhand *[custom_data~{stride_line:true}] unless items entity @s container.* *[custom_data~{heart_of_the_mountain:true}] unless items entity @s weapon.offhand *[custom_data~{heart_of_the_mountain:true}] run attribute @s fall_damage_multiplier modifier remove evercraft:stride_fall
execute unless items entity @s container.* *[custom_data~{stride_line:true}] unless items entity @s weapon.offhand *[custom_data~{stride_line:true}] unless items entity @s container.* *[custom_data~{heart_of_the_mountain:true}] unless items entity @s weapon.offhand *[custom_data~{heart_of_the_mountain:true}] run attribute @s movement_speed modifier remove evercraft:stride_spd

# === Boss Exclusive artifact cleanup ===
execute unless items entity @s container.* *[custom_data~{artifact:"soul_reaver"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"soul_reaver"}] run attribute @s luck modifier remove evercraft:soul_reaver_luck
execute unless items entity @s container.* *[custom_data~{artifact:"thornheart_bloom"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"thornheart_bloom"}] run attribute @s luck modifier remove evercraft:thornheart_bloom_luck
execute unless items entity @s container.* *[custom_data~{artifact:"thunderstrike_core"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"thunderstrike_core"}] run attribute @s luck modifier remove evercraft:thunderstrike_core_luck
execute unless items entity @s container.* *[custom_data~{artifact:"abyssal_pearl"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"abyssal_pearl"}] run attribute @s luck modifier remove evercraft:abyssal_pearl_luck
execute unless items entity @s container.* *[custom_data~{artifact:"earthshaker_core"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"earthshaker_core"}] run attribute @s luck modifier remove evercraft:earthshaker_core_luck
execute unless items entity @s container.* *[custom_data~{artifact:"earthshaker_core"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"earthshaker_core"}] run attribute @s knockback_resistance modifier remove evercraft:earthshaker_core_kb
execute unless items entity @s container.* *[custom_data~{artifact:"nightmare_fragment"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"nightmare_fragment"}] run attribute @s luck modifier remove evercraft:nightmare_fragment_luck
execute unless items entity @s container.* *[custom_data~{artifact:"infernal_heart"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"infernal_heart"}] run attribute @s luck modifier remove evercraft:infernal_heart_luck
execute unless items entity @s container.* *[custom_data~{artifact:"soulkeepers_ember"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"soulkeepers_ember"}] run attribute @s luck modifier remove evercraft:soulkeepers_ember_luck
execute unless items entity @s container.* *[custom_data~{artifact:"behemoths_heart"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"behemoths_heart"}] run attribute @s luck modifier remove evercraft:behemoths_heart_luck
execute unless items entity @s container.* *[custom_data~{artifact:"void_sovereigns_eye"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"void_sovereigns_eye"}] run attribute @s luck modifier remove evercraft:void_sovereigns_eye_luck
execute unless items entity @s container.* *[custom_data~{artifact:"architects_design"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"architects_design"}] run attribute @s luck modifier remove evercraft:architects_design_luck

# === Fusion Wave 1 (Family A) — consolidated capstone Dream-Rate cleanup ===
# Strip the single consolidated modifier when its capstone is no longer carried. (When the
# capstone IS carried, hero_satchel/apply_consolidated_luck re-adds it later in the same tick —
# check_and_apply runs AFTER player_tick's accessory_cleanup, so the active value always survives.)
execute unless items entity @s container.* *[custom_data~{pebble_of_creation:true}] unless items entity @s weapon.offhand *[custom_data~{pebble_of_creation:true}] run attribute @s luck modifier remove evercraft:pebble_of_creation_luck
execute unless items entity @s container.* *[custom_data~{aegis_half:true}] unless items entity @s weapon.offhand *[custom_data~{aegis_half:true}] run attribute @s luck modifier remove evercraft:pebble_aegis_luck
execute unless items entity @s container.* *[custom_data~{astral_half:true}] unless items entity @s weapon.offhand *[custom_data~{astral_half:true}] run attribute @s luck modifier remove evercraft:pebble_astral_luck

# === Clear lingering potion effects (night_vision, fire_resistance, water_breathing) ===
function evercraft:artifacts/effect_cleanup
