# AR-P2-8: per-pid stash macro — copies the dispatched sig into a player-scoped slot
# before the increment, so a parallel kill on another player can't race-clobber.
# Macro: {pid:<int>, sig:<int>}

$data modify storage evercraft:artifact_kills temp_$(pid).sig set value $(sig)
$function evercraft:artifacts/kill_track_increment with storage evercraft:artifact_kills temp_$(pid)
