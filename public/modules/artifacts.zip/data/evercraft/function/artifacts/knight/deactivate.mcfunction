# Knight Mode — Silent Deactivate (player swapped away from knight sword)
# Clears fencer bonuses without notification (unlike fencer_off which is for shield toggle)

attribute @s minecraft:attack_damage modifier remove evercraft:fencer_damage
attribute @s minecraft:entity_interaction_range modifier remove evercraft:fencer_reach
attribute @s minecraft:block_interaction_range modifier remove evercraft:fencer_reach
attribute @s minecraft:max_health modifier remove evercraft:tank_hearts
effect clear @s minecraft:absorption
scoreboard players set @s ec.kt_fencer 0
# Sword may have been swapped away; reconciler's mainhand-sword gate makes this a no-op if so.
function evercraft:artifacts/knight/reconcile_reach
# Strip Duelist Discipline combat modifiers (C1/C10 melee, C4 attack speed) — active-gated.
attribute @s minecraft:attack_damage modifier remove evercraft:bough_kt_c1
attribute @s minecraft:attack_damage modifier remove evercraft:bough_kt_c10
attribute @s minecraft:attack_speed modifier remove evercraft:bough_kt_c4
# Strip Tank Bulwark combat modifiers (C1 armor, C2 melee, C3 knockback) — Tank shares this
# deactivate (it's the Knight shield stance).
attribute @s minecraft:armor modifier remove evercraft:bough_tk_c1
attribute @s minecraft:attack_damage modifier remove evercraft:bough_tk_c2
attribute @s minecraft:knockback_resistance modifier remove evercraft:bough_tk_c3
# OPT: tag removal moved here from tick (was separate @a scan)
tag @s remove ec.kt_active
# Leaving the Knight class also ends any Dual Swordsman ??? grind (no longer dual-wielding two
# Fencer swords). Keeps ec.ds_seeking accurate when the mainhand sword is swapped away entirely.
tag @s remove ec.ds_seeking
