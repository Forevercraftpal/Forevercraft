# Knight Artifacts — Per-Tick Processing
# Manages fencer stance (no shield = +2 damage, +1 reach)

# === STEP 1: Verify active players still hold a knight sword ===
# If they swapped away, silently clear fencer bonuses and remove tag
# OPT: tag removal moved into deactivate (was 2 @a scans, now 1)
execute as @a[tag=ec.kt_active] unless items entity @s weapon.mainhand *[custom_data~{knight:true}] run function evercraft:artifacts/knight/deactivate

# === STEP 2: Fencer stance — toggle based on offhand shield ===
# No shield in offhand AND fencer not yet active → apply bonuses
execute as @a[tag=ec.kt_active,scores={ec.kt_fencer=0}] unless items entity @s weapon.offhand minecraft:shield run function evercraft:artifacts/knight/fencer_on

# Shield in offhand AND fencer currently active → remove bonuses
execute as @a[tag=ec.kt_active,scores={ec.kt_fencer=1}] if items entity @s weapon.offhand minecraft:shield run function evercraft:artifacts/knight/fencer_off

# === TANK ABSORPTION REFRESH ===
# Tank stance (knight + shield, kt_fencer=0) keeps a 5-heart absorption shield.
# Re-applied every tick with hidden particles; amplifier 4 = 10 absorption HP =
# 5 hearts. The 5-second buffer ensures the shield never drops to 0 mid-fight.
effect give @a[tag=ec.kt_active,scores={ec.kt_fencer=0}] minecraft:absorption 5 4 true

# === STEP 3: Dual Swordsman handoff (the earned path, Joseph 2026-06-19) ===
# A Knight holding a SECOND single-hand sword (custom_data{knight:true}) in the offhand is
# dual-wielding two Fencer blades. If they've already EARNED the Dual Swordsman unlock, promote
# them now (detect_fencer deactivates Knight + activates DS). If not yet unlocked, mark them
# SEEKING so hostile kills feed the ??? unlock track; drop the tag once the 2nd sword leaves the
# offhand. SOLE writer of ec.ds_seeking (detect_fencer also clears it on promotion).
execute as @a[tag=ec.kt_active] if items entity @s weapon.offhand *[custom_data~{knight:true}] if score @s ec.ds_unlocked matches 1.. run function evercraft:dual_swordsman/detect_fencer
execute as @a[tag=ec.kt_active] if items entity @s weapon.offhand *[custom_data~{knight:true}] unless score @s ec.ds_unlocked matches 1.. run tag @s add ec.ds_seeking
execute as @a[tag=ec.kt_active] unless items entity @s weapon.offhand *[custom_data~{knight:true}] run tag @s remove ec.ds_seeking
