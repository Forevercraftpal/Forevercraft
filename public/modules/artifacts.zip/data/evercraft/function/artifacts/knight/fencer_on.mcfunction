# Knight Fencing Stance — Apply Bonuses
# +2 attack damage, +1 entity interaction range (reach)

attribute @s minecraft:attack_damage modifier add evercraft:fencer_damage 2 add_value
# Fencer reach bumped 1 → 2 (Joseph 2026-06-10): "increase reach by one" on top
# of the existing fencer +1, so fencer total is +2 entity-interaction range.
attribute @s minecraft:entity_interaction_range modifier add evercraft:fencer_reach 2 add_value
# Mirror onto block_interaction_range so the post-swing block reach stays
# intact in 26.1 (some 26.1 builds clamp block reach to the held item's
# attack_range max_reach after the first swing — the redundant attribute
# add keeps the player attribute high enough that the clamp is a no-op).
attribute @s minecraft:block_interaction_range modifier add evercraft:fencer_reach 2 add_value
# Tank-only bonuses end when entering fencer stance: drop hearts + clear absorption.
attribute @s minecraft:max_health modifier remove evercraft:tank_hearts
effect clear @s minecraft:absorption
# 26.1: melee reach comes from the held item's attack_range component, which overrides the player attribute.
# Toggle the score first so the reconciler picks the right tier (4.0 alone, 5.0 if ed_knight_6pc also active).
scoreboard players set @s ec.kt_fencer 1
function evercraft:artifacts/knight/reconcile_reach

execute if score @s ec.fx_snd matches 1.. run playsound minecraft:item.armor.equip_iron player @s ~ ~ ~ 0.6 1.5
data modify storage evercraft:notify stage.c set value [{text:"Knight Mode, ",color:"gold",bold:true},{text:"Fencing Stance",color:"#C0A040",bold:true},{text:" — active",color:"yellow",bold:false}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit

# Generic tier-FX layer (common→rare; ornate+ no-ops for the bespoke preset below). Channel-gated.
# Knight has no cached rarity score — read true rarity from the mainhand.
function evercraft:fx/tier/read_mainhand
execute at @s run function evercraft:fx/tier/proc
# Bespoke "Steel & Honor" — the steel gleam-line + noble bell when the stance engages (ornate+).
execute if score #fx_tier ec.var matches 4.. at @s run function evercraft:fx/bespoke/knight/fencer_on
