# Knight Fencing Stance — Remove Bonuses

attribute @s minecraft:attack_damage modifier remove evercraft:fencer_damage
attribute @s minecraft:entity_interaction_range modifier remove evercraft:fencer_reach
attribute @s minecraft:block_interaction_range modifier remove evercraft:fencer_reach
# Toggle the score first so the reconciler picks the right tier (3.0 alone, 4.0 if ed_knight_6pc still active).
scoreboard players set @s ec.kt_fencer 0
function evercraft:artifacts/knight/reconcile_reach
# Tank-stance bonuses re-engage: +6 max HP. Absorption re-applies via knight/tick.
attribute @s minecraft:max_health modifier add evercraft:tank_hearts 6 add_value

execute if score @s ec.fx_snd matches 1.. run playsound minecraft:item.armor.equip_iron player @s ~ ~ ~ 0.6 0.8
data modify storage evercraft:notify stage.c set value [{text:"Tank Mode",color:"#4A90D9",bold:true},{text:" — shield raised",color:"white",bold:false}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit

# Generic tier-FX layer (common→rare; ornate+ no-ops for the bespoke preset below). Channel-gated.
# Knight has no cached rarity score — read true rarity from the mainhand.
function evercraft:fx/tier/read_mainhand
execute at @s run function evercraft:fx/tier/proc
# Bespoke "Steel & Honor" — the softer settling note when the blade lowers to guard (ornate+).
execute if score #fx_tier ec.var matches 4.. at @s run function evercraft:fx/bespoke/knight/fencer_off
