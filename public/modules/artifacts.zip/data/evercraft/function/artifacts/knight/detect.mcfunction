# Knight Sword Detection — Activate knight mode and check fencer stance
# Run as player who just equipped a knight sword in mainhand

tag @s add ec.kt_active

# === FENCER STANCE CHECK ===
# If no shield in offhand, apply fencer bonuses immediately
execute unless items entity @s weapon.offhand minecraft:shield run function evercraft:artifacts/knight/fencer_on

# === TANK STANCE BONUS ===
# Shield in offhand → Tank Mode: +3 hearts (+6 max HP). Absorption shield is
# re-applied every tick by knight/tick. Hearts are removed in fencer_on and
# re-added in fencer_off so the bonus belongs to Tank stance only.
execute if items entity @s weapon.offhand minecraft:shield run attribute @s minecraft:max_health modifier add evercraft:tank_hearts 6 add_value

# === ACTIVATION FEEDBACK ===
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:item.armor.equip_iron player @s ~ ~ ~ 0.8 1.2
data modify storage evercraft:notify stage.c set value [{text:"Knight Mode, ",color:"gold",bold:true},{text:"Fencing Stance",color:"#C0A040",bold:true},{text:" — blade ready",color:"yellow",bold:false}]
scoreboard players set #ndur ec.temp 45
execute if score @s ec.kt_fencer matches 1 run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Tank Mode",color:"#4A90D9",bold:true},{text:" — blade ready",color:"white",bold:false}]
scoreboard players set #ndur ec.temp 45
execute unless score @s ec.kt_fencer matches 1 run function evercraft:util/notify/emit
