# Knight reach reconciler — picks the right attack_range tier on the held sword.
# Called from every place that toggles ec.kt_fencer or the ed_knight_6pc tag,
# AFTER the state change. 3 tiers: stack 5.0 (both) / on 4.0 (one) / off 3.0 (neither).
# Mainhand sword gate prevents stamping attack_range onto unrelated items.

execute unless items entity @s weapon.mainhand #minecraft:swords run return 0

execute if score @s ec.kt_fencer matches 1 if entity @s[tag=ed_knight_6pc] run item modify entity @s weapon.mainhand evercraft:knight/fencer_reach_stack
execute if score @s ec.kt_fencer matches 1 unless entity @s[tag=ed_knight_6pc] run item modify entity @s weapon.mainhand evercraft:knight/fencer_reach_on
execute unless score @s ec.kt_fencer matches 1 if entity @s[tag=ed_knight_6pc] run item modify entity @s weapon.mainhand evercraft:knight/fencer_reach_on
execute unless score @s ec.kt_fencer matches 1 unless entity @s[tag=ed_knight_6pc] run item modify entity @s weapon.mainhand evercraft:knight/fencer_reach_off
