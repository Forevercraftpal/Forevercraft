# === POCKET ENDER ANCHOR — SHIFT-RC HANDLER (Chest-Node §6 / §7) ===
# Run as @s = player. Fired by the shift-RC using_item advancement (artifacts/system/pocket_ender_use)
# when the player sneak-right-clicks while holding the Pocket Ender Anchor (either the full-loot or the
# {loot:0b} Artifact-Crate variant — both open the portable ender the same way; the loot flag only
# gates the separate chest-loot feature, not this access). Places a TEMPORARY real ender_chest at the
# player's feet via the shared portable_ender/open helper (§14.8) so the player can open their ACTUAL
# ender inventory (the only way — the UI can't be command-opened). Revoke+re-arm so a single click
# fires exactly once (clone of activate_monocle / on_use cooldown idiom).

# Revoke so the advancement can re-trigger on the next shift-RC.
advancement revoke @s only evercraft:artifacts/system/pocket_ender_use

# Only fire from a held slot (mainhand or offhand) — never from a stray copy in a container.
execute unless items entity @s weapon.mainhand *[custom_data~{artifact:"pocket_ender_anchor"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"pocket_ender_anchor"}] run return fail

# Place / open the portable ender chest at the player.
execute at @s run function evercraft:portable_ender/open
