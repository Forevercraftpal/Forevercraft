# === TINKER'S OMNITOOL — SHIFT-RC HANDLER (Chest-Node §6 / A2) ===
# Run as @s = player. Fired by the shift-RC using_item advancement (artifacts/system/omnitool_use)
# when the player sneak-right-clicks while holding the combined Tinker's Omnitool. The Omnitool folds
# in the Pocket Ender Anchor's portable-ender access, so shift-RC opens the portable ender chest (the
# same shared mechanism as the standalone anchor). Revoke+re-arm so a single click fires exactly once.

advancement revoke @s only evercraft:artifacts/system/omnitool_use

# Only fire from a held slot (mainhand or offhand).
execute unless items entity @s weapon.mainhand *[custom_data~{artifact:"tinkers_omnitool"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"tinkers_omnitool"}] run return fail

# Place / open the portable ender chest at the player.
execute at @s run function evercraft:portable_ender/open
