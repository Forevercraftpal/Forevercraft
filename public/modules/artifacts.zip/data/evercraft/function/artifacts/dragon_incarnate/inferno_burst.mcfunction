# Dragon Incarnate — Inferno Burst
# AOE fire nova: 20 true damage to all hostile mobs within 5 blocks, 20s cooldown
# Called from on_consume when sneaking

# Check cooldown
data modify storage evercraft:notify stage.c set value [{text:"Inferno Burst recharging!",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute if score @s ec.di_burst_cd matches 1.. run function evercraft:util/notify/emit
execute if score @s ec.di_burst_cd matches 1.. if score @s ec.fx_snd matches 1.. run playsound minecraft:block.fire.extinguish player @s ~ ~ ~ 0.5 1.5
execute if score @s ec.di_burst_cd matches 1.. run return 0

# Set 20s cooldown (400 ticks)
scoreboard players set @s ec.di_burst_cd 400

# Get UUID for damage attribution
function evercraft:treasure/database/get with entity @s

# Tag self to exclude from damage
tag @s add ec.di_burst

# AOE damage — 20 true damage (arcane damage-type bypasses armor) to all hostile mobs in 5 blocks
execute at @s as @e[type=!#evercraft:treasure/non_entity,type=!player,distance=..5] run function evercraft:artifacts/dragon_incarnate/inferno_burst_hit with storage evercraft:treasure/write data

# VFX — fire nova
execute at @s run particle flame ~ ~0.5 ~ 3 0.5 3 0.15 300 force @a
execute at @s run particle lava ~ ~1 ~ 2 1 2 0 40 force @a
execute at @s run particle smoke ~ ~0.5 ~ 3 1 3 0.1 100 force @a
execute at @s run particle minecraft:explosion ~ ~1 ~ 2 0.5 2 0.05 5 force @a

# SFX
execute at @s as @a[distance=..25] if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.ender_dragon.growl player @s ~ ~ ~ 1.0 0.6
execute at @s as @a[distance=..25] if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.generic.explode player @s ~ ~ ~ 0.8 1.2
execute at @s as @a[distance=..25] if score @s ec.fx_snd matches 1.. run playsound minecraft:item.firecharge.use player @s ~ ~ ~ 0.6 0.8

# Ignite all hit targets (3 seconds = 60 ticks)
execute at @s as @e[type=!#evercraft:treasure/non_entity,type=!player,distance=..5] run data merge entity @s {Fire:60s}

# Cleanup
tag @s remove ec.di_burst

# Feedback — single line (matches the one-success-line norm of every other ability; the second
# "unleashed (cooldown)" emit was a redundant dupe for the same activation, removed 2026-06-02).
data modify storage evercraft:notify stage.c set value [{text:"Inferno Burst! ",color:"#FF4400",bold:true},{text:"(20s cooldown)",color:"dark_gray"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit

# Generic tier-FX layer (common→rare; ornate+ no-ops for a future bespoke preset). Channel-gated.
# Dragon Incarnate has no cached rarity score — read true rarity from the mainhand.
function evercraft:fx/tier/read_mainhand
execute at @s run function evercraft:fx/tier/proc
