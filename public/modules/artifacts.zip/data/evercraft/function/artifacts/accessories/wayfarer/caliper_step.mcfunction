# Wayfarer / Surveyor — Steady-Hand Caliper raystep (max 6 blocks = ~15 steps of 0.4)
# Run AT each ray sample position; @s = the player (for force @s render + sound). Walks forward in
# 0.4-block increments. On the FIRST solid hit, render a faint dust-cell outline at the LAST air cell
# stepped through (the would-be placement cell), 1 sound ping, and stop. Bounded: ≤15 steps.
execute if score #cal_ray ec.temp matches 15.. run return 0

# Solid hit → the next-placed-block cell is the air cell we just came from. Render the ghost there.
# `caliper_cell` draws a 12-particle dust outline of the unit cube at the air position, force @s.
execute unless block ~ ~ ~ air unless block ~ ~ ~ cave_air unless block ~ ~ ~ water unless block ~ ~ ~ lava if score #cal_hit ec.temp matches 1.. positioned ^ ^ ^-0.4 align xyz run function evercraft:artifacts/accessories/wayfarer/caliper_cell
execute unless block ~ ~ ~ air unless block ~ ~ ~ cave_air unless block ~ ~ ~ water unless block ~ ~ ~ lava if score #cal_hit ec.temp matches 1.. if score @s ec.fx_snd matches 1.. run playsound minecraft:block.amethyst_block.chime player @s ~ ~ ~ 0.4 1.8
execute unless block ~ ~ ~ air unless block ~ ~ ~ cave_air unless block ~ ~ ~ water unless block ~ ~ ~ lava run return 0

# Still in open space — mark that we have at least one valid air step behind us, advance, recurse.
scoreboard players set #cal_hit ec.temp 1
scoreboard players add #cal_ray ec.temp 1
execute positioned ^ ^ ^0.4 run function evercraft:artifacts/accessories/wayfarer/caliper_step
