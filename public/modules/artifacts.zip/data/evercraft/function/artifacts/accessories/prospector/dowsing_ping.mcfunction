# C7 Wayfinder's Dowsing Rod (Family K Prospector — art-K) — sneak node-ping
# Run as @s = player, at @s. Sneak-triggered on-demand (gate at the call site). The Rod's headline
# perk (craft-nodes near it linger +50% longer) is passive in craftforever/nodes/check_despawn; this
# is its sneak DOWSING cue: a faint particle wisp toward the nearest craft-node marker (ec.cf_node_data)
# within 100 b, plus an action-bar line. Bounded: one nearest-marker probe (NO scan). Debounced by
# ec.pr_pingcd (40t = 2s). No DR, no roll — a sense readout.

# Cooldown gate (debounce). If still recharging, bail quietly.
# (Wave 1, 2026-06-10: the two actionbar lines below yield to the notify queue via ab_q — HUD convention.)
execute if score @s ec.pr_pingcd matches 1.. run return 0
scoreboard players set @s ec.pr_pingcd 40

# If a node is within 100 b: face it (rotate toward the nearest marker) and emit a short forward
# particle trail toward it; else say "no node nearby". The rotate-then-emit-forward idiom gives a
# direction cue without an O(r^3) scan — one nearest-marker probe.
execute if entity @e[type=marker,tag=ec.cf_node_data,distance=..100,limit=1] facing entity @e[type=marker,tag=ec.cf_node_data,distance=..100,limit=1,sort=nearest] feet run particle minecraft:wax_on ^ ^1 ^1 0.0 0.0 0.0 0.0 1 force @s
execute if entity @e[type=marker,tag=ec.cf_node_data,distance=..100,limit=1] facing entity @e[type=marker,tag=ec.cf_node_data,distance=..100,limit=1,sort=nearest] feet run particle minecraft:wax_on ^ ^1 ^3 0.0 0.0 0.0 0.0 1 force @s
execute if entity @e[type=marker,tag=ec.cf_node_data,distance=..100,limit=1] facing entity @e[type=marker,tag=ec.cf_node_data,distance=..100,limit=1,sort=nearest] feet run particle minecraft:wax_on ^ ^1 ^5 0.0 0.0 0.0 0.0 1 force @s
execute if entity @e[type=marker,tag=ec.cf_node_data,distance=..100,limit=1] unless entity @s[tag=ab_q] run title @s actionbar [{text:"⤜ ",color:"gold"},{text:"Dowsing Rod: ",color:"#FFD27F"},{text:"a craft-node pulls the rod",color:"gray"}]
execute unless entity @e[type=marker,tag=ec.cf_node_data,distance=..100,limit=1] unless entity @s[tag=ab_q] run title @s actionbar [{text:"⤜ ",color:"dark_gray"},{text:"Dowsing Rod: ",color:"gray"},{text:"no craft-node within reach",color:"dark_gray"}]
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:item.lodestone_compass.lock player @s ~ ~ ~ 0.5 1.3
