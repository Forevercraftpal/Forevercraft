# U21 Loadmaster's Sortstone (Family K Prospector — art-K) — sneak tidy pulse (stackable materials)
# Run as @s = player, at @s. Sneak-triggered on-demand (gate at the call site). UTILITY-FEASIBILITY
# RESCOPE + DROP-candidate: vanilla has NO "merge partial stacks in place" command, and a clear+regive
# of arbitrary items REORDERS the inventory + is unsafe for NBT/durability items (enchanted/damaged
# tools). So this collapses ONLY a curated set of STACKABLE, NBT-FREE MATERIALS (ores, common blocks,
# food) — count the total of each, clear it, regive the collapsed total — leaving tools/gear/anything
# with components UNTOUCHED. The collapse merges 3×17 cobblestone into 1×51, freeing slots. Debounced
# by ec.pr_pingcd (60t = 3s). NOTE for Joseph: this reorders the collapsed materials (they jump to the
# first free slot) — if that UX is unwanted, the item is a DROP candidate (one-line removal). Flagged.
#
# Safety: each material is collapsed only if the player has >1 of it (no-op for a single stack), and we
# only touch the curated list — a damaged pickaxe or an artifact is NEVER cleared (not in the list).

# Cooldown gate (debounce). If still recharging, bail quietly.
execute if score @s ec.pr_pingcd matches 1.. run return 0
scoreboard players set @s ec.pr_pingcd 60

scoreboard players set #sort_freed ec.temp 0

# Collapse each curated material: count -> clear -> regive collapsed. The helper does the count/clear/
# macro-regive per item id so this stays a flat call list (the collapse is per-id, never a slot sweep).
function evercraft:artifacts/accessories/prospector/sort_one {item:"minecraft:cobblestone"}
function evercraft:artifacts/accessories/prospector/sort_one {item:"minecraft:cobbled_deepslate"}
function evercraft:artifacts/accessories/prospector/sort_one {item:"minecraft:stone"}
function evercraft:artifacts/accessories/prospector/sort_one {item:"minecraft:dirt"}
function evercraft:artifacts/accessories/prospector/sort_one {item:"minecraft:netherrack"}
function evercraft:artifacts/accessories/prospector/sort_one {item:"minecraft:raw_iron"}
function evercraft:artifacts/accessories/prospector/sort_one {item:"minecraft:raw_gold"}
function evercraft:artifacts/accessories/prospector/sort_one {item:"minecraft:raw_copper"}
function evercraft:artifacts/accessories/prospector/sort_one {item:"minecraft:iron_ingot"}
function evercraft:artifacts/accessories/prospector/sort_one {item:"minecraft:gold_ingot"}
function evercraft:artifacts/accessories/prospector/sort_one {item:"minecraft:copper_ingot"}
function evercraft:artifacts/accessories/prospector/sort_one {item:"minecraft:coal"}
function evercraft:artifacts/accessories/prospector/sort_one {item:"minecraft:redstone"}
function evercraft:artifacts/accessories/prospector/sort_one {item:"minecraft:lapis_lazuli"}
function evercraft:artifacts/accessories/prospector/sort_one {item:"minecraft:quartz"}
function evercraft:artifacts/accessories/prospector/sort_one {item:"minecraft:amethyst_shard"}
function evercraft:artifacts/accessories/prospector/sort_one {item:"minecraft:gravel"}
function evercraft:artifacts/accessories/prospector/sort_one {item:"minecraft:sand"}

# Feedback: a tidy chime + an action-bar readout (slots freed is approximate — the count of materials
# that were multi-stack collapsed; exact slot math isn't cheap, so we report the collapse cue).
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.amethyst_block.chime player @s ~ ~ ~ 0.7 1.0
# (Wave 1, 2026-06-10: routed through the notify queue — a discrete confirm, was an ungated raw paint.)
execute if score #sort_freed ec.temp matches 1.. run data modify storage evercraft:notify stage.c set value [{text:"▣ ",color:"light_purple"},{text:"Sortstone: ",color:"#E0B0FF"},{text:"materials tidied",color:"gray"}]
execute if score #sort_freed ec.temp matches 0 run data modify storage evercraft:notify stage.c set value [{text:"▣ ",color:"dark_gray"},{text:"Sortstone: ",color:"gray"},{text:"nothing to tidy",color:"dark_gray"}]
scoreboard players set #ndur ec.temp 30
function evercraft:util/notify/emit
