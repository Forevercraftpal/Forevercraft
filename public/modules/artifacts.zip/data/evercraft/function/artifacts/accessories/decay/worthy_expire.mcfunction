# BUG-004 FIX: Per-player Mjolnir Worthy decay (replaces global schedule+@a)
scoreboard players set @s ec.mjolnir_chain 0
scoreboard players set @s ec.worthy_cd -1
