# Wayfarer — Lantern-Lichen Clasp: stage the stored prev cell into storage + call the clean macro.
# Run as @s = player. Only called when ec.wf_lhas==1 (we own a light at the prev cell). Stages the
# prev coords (ec.wf_plx/ply/plz) into storage evercraft:wf_temp, then runs the coord-pinned macro
# that reverts that exact cell to air IFF it still holds our light block.
execute store result storage evercraft:wf_temp clean.x int 1 run scoreboard players get @s ec.wf_plx
execute store result storage evercraft:wf_temp clean.y int 1 run scoreboard players get @s ec.wf_ply
execute store result storage evercraft:wf_temp clean.z int 1 run scoreboard players get @s ec.wf_plz
function evercraft:artifacts/accessories/wayfarer/light_clean with storage evercraft:wf_temp clean
# The prev cell no longer holds our light (we just reverted it). Zero the own-light flag. This is the
# ONE not-held / pre-move reset of ec.wf_lhas; light_step re-sets it to 1 after it places the new cell
# on a move (so wf_lhas's only writers are light_step + this dispatch, both in the light subsystem).
scoreboard players set @s ec.wf_lhas 0
