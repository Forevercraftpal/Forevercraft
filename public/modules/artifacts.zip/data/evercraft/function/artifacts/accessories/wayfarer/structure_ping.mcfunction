# Wayfarer — Structure Survey Ping (U23 Voyager's Far-Lens · #5 Cartographer's Astrolabe)
# Run as @s = player, at @s. Sneak-triggered on-demand (the sneak+hold gate lives at the call site).
# Uses the VANILLA `locate structure` command (NOT an O(r3) terrain scan — UTILITY-FEASIBILITY's
# mandated salvage for the dropped 64 b terrain outline) to print the nearest structures' coords +
# distance in chat, dimension-aware. A per-player cooldown ec.wf_pingcd (60t = 3s) debounces a held
# sneak so this fires once per pulse, not 20x/s. Particle budget here: a single 12-count enchant
# burst (well under the <=36 budget). No block-glow.

# Cooldown gate (debounce). If still recharging, show a quiet recharging line and bail.
# Wave 1 (2026-06-10): the recharging line yields to the notify queue (ab_q); the bail is unchanged.
execute if score @s ec.wf_pingcd matches 1.. unless entity @s[tag=ab_q] run title @s actionbar [{"text":"⌖ Survey recharging...","color":"gray"}]
execute if score @s ec.wf_pingcd matches 1.. run return 0
scoreboard players set @s ec.wf_pingcd 60

tellraw @s [{"text":"⌖ ","color":"yellow"},{"text":"Survey ","color":"aqua","bold":true},{"text":"— nearest landmarks:","color":"gray"}]

# Overworld structures (locate prints "<id> is at [x, ~, z] (<n> blocks away)").
execute in minecraft:overworld run locate structure #minecraft:village
execute in minecraft:overworld run locate structure minecraft:pillager_outpost
execute in minecraft:overworld run locate structure minecraft:trial_chambers
execute in minecraft:overworld run locate structure minecraft:monument
execute in minecraft:overworld run locate structure minecraft:mansion
execute in minecraft:overworld run locate structure minecraft:stronghold
# Nether structures.
execute in minecraft:the_nether run locate structure minecraft:fortress
execute in minecraft:the_nether run locate structure minecraft:bastion_remnant
# End structures.
execute in minecraft:the_end run locate structure minecraft:end_city

# Feedback (single small particle burst + lock sound — bounded, no block-glow).
execute at @s run particle minecraft:enchant ~ ~1 ~ 0.5 0.5 0.5 0.5 12
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:item.lodestone_compass.lock player @s ~ ~ ~ 0.6 1.4
