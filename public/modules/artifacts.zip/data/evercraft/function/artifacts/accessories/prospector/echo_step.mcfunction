# U10 Echolocator Shard — bounded ray step (Family K Prospector — art-K)
# Run AT each ray sample position; @s = the player (for force @s particle + sound). Walks forward in
# 2-block strides. If THIS cell is a large air gap (the cell AND the one above it are air/cave_air — a
# stand-up cavity, not a 1-block crack), ping a particle wisp + a soft echo at the cavity and stop this
# ray. Bounded: ≤12 strides (≈24 b). No volume scan, no block-glow — particles/sound only.
execute if score #echo_step ec.temp matches 12.. run return 0

# Large-air-gap detection: this cell + the one above are open (a cavity you could enter).
execute if block ~ ~ ~ air if block ~ ~1 ~ air run function evercraft:artifacts/accessories/prospector/echo_hit
execute if block ~ ~ ~ air if block ~ ~1 ~ air run return 0
execute if block ~ ~ ~ cave_air if block ~ ~1 ~ cave_air run function evercraft:artifacts/accessories/prospector/echo_hit
execute if block ~ ~ ~ cave_air if block ~ ~1 ~ cave_air run return 0

# A solid wall ends this ray (no cavity along it). Stop.
execute unless block ~ ~ ~ air unless block ~ ~ ~ cave_air unless block ~ ~ ~ water unless block ~ ~ ~ lava run return 0

# Still in open-but-narrow space (or a fluid) — advance and recurse.
scoreboard players add #echo_step ec.temp 1
execute positioned ^ ^ ^2 run function evercraft:artifacts/accessories/prospector/echo_step
