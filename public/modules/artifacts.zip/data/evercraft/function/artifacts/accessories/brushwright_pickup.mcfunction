# === BRUSHWRIGHT'S MITT (C9) — PER-BREAK ORE AUTO-PICKUP (Family K Prospector, art-K) ===
# Run as @s = player, at @s. Called from craft_affinity/detect_ordinary_tool ON a mining-delta event
# (already break-gated) when the player holds the Brushwright's Mitt accessory + a pickaxe. Charge-FREE
# + no tick-loop scan: it rides the break event and teleports the ore/gem items that just dropped at
# the player's position straight onto the player (auto-pickup) — a Craft-Affinity convenience verb
# DISTINCT from the Smelter's Sigil auto-smelt (which transforms; this collects). The two never
# overlap: a player holding BOTH gets smelt THEN pickup (the smelt rewrites the drop's id in place,
# then this collects whatever is on the ground). The tp-to-player magnetize is the proven vanilla
# auto-pickup idiom (drops within 4 b of the just-broken block snap to the player's feet -> instant
# pickup). Bounded: distance=..4 = the just-dropped items at the player (not a region sweep).
#
# Smeltable/collectable list = the gathering drops a pickaxe produces (ores, raw ores, gems, ingots
# from a co-held Sigil). We tp the common mining drops; non-mining clutter (e.g. cobblestone the
# player chose to leave) is intentionally NOT magnetized broadly — only the valuable gathering items,
# matching "auto-pickup of ore/gem drops" (EXPANSION-IDEAS C9). distance=..4, limit per type.

# Raw ores (the headline gathering drops).
tp @e[type=item,distance=..4,nbt={Item:{id:"minecraft:raw_iron"}}] @s
tp @e[type=item,distance=..4,nbt={Item:{id:"minecraft:raw_gold"}}] @s
tp @e[type=item,distance=..4,nbt={Item:{id:"minecraft:raw_copper"}}] @s
# Smelted outputs (if a co-held Smelter's Sigil already transformed the drop this break).
tp @e[type=item,distance=..4,nbt={Item:{id:"minecraft:iron_ingot"}}] @s
tp @e[type=item,distance=..4,nbt={Item:{id:"minecraft:gold_ingot"}}] @s
tp @e[type=item,distance=..4,nbt={Item:{id:"minecraft:copper_ingot"}}] @s
# Gems + mining-only drops.
tp @e[type=item,distance=..4,nbt={Item:{id:"minecraft:diamond"}}] @s
tp @e[type=item,distance=..4,nbt={Item:{id:"minecraft:emerald"}}] @s
tp @e[type=item,distance=..4,nbt={Item:{id:"minecraft:lapis_lazuli"}}] @s
tp @e[type=item,distance=..4,nbt={Item:{id:"minecraft:redstone"}}] @s
tp @e[type=item,distance=..4,nbt={Item:{id:"minecraft:coal"}}] @s
tp @e[type=item,distance=..4,nbt={Item:{id:"minecraft:quartz"}}] @s
tp @e[type=item,distance=..4,nbt={Item:{id:"minecraft:amethyst_shard"}}] @s
tp @e[type=item,distance=..4,nbt={Item:{id:"minecraft:ancient_debris"}}] @s
tp @e[type=item,distance=..4,nbt={Item:{id:"minecraft:netherite_scrap"}}] @s
