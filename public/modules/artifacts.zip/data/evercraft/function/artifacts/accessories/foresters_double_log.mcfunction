# === FORESTER'S TALLY (C4) — DOUBLE-LOG ROLL (Family K Prospector, art-K) ===
# Run as @s = player, at @s. Called from craft_affinity/detect_ordinary_tool on a LOG delta with an
# axe + the Forester's Tally held. FORTUNE-REWRITE m2 double-LOG half (the tree-crate half is already
# rolled by grant_verb class 2 -> harvest_bonus_crate; this does NOT roll the crate again -> no double
# crate). Reads the player's harvest-bonus odds (sets #hb_dbl), rolls ONE 1..100, and on a win gives a
# duplicate of the LOG that just dropped at the player's feet. One roll per break (not per log of the
# stack) — keeps it a per-break charm, not a sweep. Byte-identical shape to art-G's crystal_double_log.

# Read odds: harvest_bonus_read is the ONE writer of #hb_dbl / ec.hb_active. The Tally sets both.
function evercraft:artifacts/accessories/harvest_bonus_read
execute unless score @s ec.hb_active matches 1 run return 0
execute unless score #hb_dbl ec.temp matches 1.. run return 0

# Roll the double-log chance once.
execute store result score #hb_droll ec.temp run random value 1..100
execute unless score #hb_droll ec.temp <= #hb_dbl ec.temp run return 0

# WIN: read the nearest fresh dropped item's id into storage, then macro-give one more of it. This
# fires ONLY on the LUMBERFELL axe class-2 path (a confirmed log/stem delta — a log was just broken),
# so the nearest ground drop at the player IS that log. Guard: only if a fresh item drop is actually
# nearby (distance=..4 catches the ground drop; the break may have routed straight to inventory at
# point-blank). The duplicate matches the broken log's exact id (read from the drop itself). Uses a
# DISTINCT storage subkey (ftally_log_id) so it never clobbers crystal_double_log's log_id if a player
# somehow holds both the Crystal and the Tally on the same break.
execute store success score #ft_haslog ec.temp if entity @e[type=item,distance=..4,limit=1]
execute if score #ft_haslog ec.temp matches 1 run data modify storage evercraft:forge_temp ftally_log_id set from entity @e[type=item,distance=..4,limit=1,sort=nearest] Item.id
execute if score #ft_haslog ec.temp matches 1 run function evercraft:artifacts/accessories/foresters_give_log with storage evercraft:forge_temp
