# Wayfarer / Surveyor — Steady-Hand Caliper placement ghost (U16, art-F → K Surveyor Line)
# Run as @s = player, at @s. Sneak-triggered on-demand (the sneak + mainhand-hold gate lives at
# the call site in player_tick). Casts ONE bounded ray from the eyes (UTILITY-FEASIBILITY's mandated
# salvage: a bounded ≤~12-step `execute positioned … if block` ray, NEVER an O(r³) cell sweep) to the
# first solid block the player is aiming at, then renders a faint dust outline at the AIR cell one step
# BEFORE that solid hit — i.e. the cell where the next placed block would land. Per-player `force @s`
# render, tiny particle budget (≤12 dust particles, well under the 36 cap). No block-glow (blocks can't
# glow — particles only, per the hard build rule). A short cooldown debounces a held sneak so this fires
# once per pulse, not 20×/s.

# Cooldown gate (debounce, 6t ≈ 0.3s — short so the ghost feels responsive while you re-aim).
execute if score @s ec.cal_ghostcd matches 1.. run return 0
scoreboard players set @s ec.cal_ghostcd 6

# Reset the ray step counter, remember NO ghost cell found yet, then cast from the eyes.
scoreboard players set #cal_ray ec.temp 0
scoreboard players set #cal_hit ec.temp 0
execute anchored eyes positioned ^ ^ ^0.4 run function evercraft:artifacts/accessories/wayfarer/caliper_step
