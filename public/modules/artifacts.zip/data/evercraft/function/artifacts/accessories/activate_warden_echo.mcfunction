# Warden's Echo — Mob Vision Activation (sneak + mainhand)
# Ornate: 24 blocks all mobs, 10s glow, 30s cooldown (600 ticks)

# Check cooldown
data modify storage evercraft:notify stage.c set value [{text:"Recharging... ",color:"gray"},{text:"(",color:"dark_gray"},{score:{name:"@s",objective:"ec.wecho_cd"},color:"dark_gray"},{text:" ticks)",color:"dark_gray"}]
scoreboard players set #ndur ec.temp 45
execute if score @s ec.wecho_cd matches 1.. run function evercraft:util/notify/emit
execute if score @s ec.wecho_cd matches 1.. run return 0

# Apply glowing to all non-player entities within 24 blocks for 10s
execute at @s run effect give @e[type=!player,distance=..24] glowing 10 0 false

# Set cooldown
scoreboard players set @s ec.wecho_cd 30

# Feedback
data modify storage evercraft:notify stage.c set value [{text:"Vibrations sensed! ",color:"dark_aqua"},{text:"(10s)",color:"gray"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute at @s run particle sculk_soul ~ ~1 ~ 1 1 1 0.02 5
execute at @s if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bass player @s ~ ~ ~ 0.5 0.5
