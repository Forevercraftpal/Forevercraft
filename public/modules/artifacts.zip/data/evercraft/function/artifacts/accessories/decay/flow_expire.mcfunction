# BUG-003 FIX: Per-player Flowing Strikes decay (replaces global schedule+@a)
scoreboard players set @s ec.flow_hits 0
scoreboard players set @s ec.flow_cd -1
