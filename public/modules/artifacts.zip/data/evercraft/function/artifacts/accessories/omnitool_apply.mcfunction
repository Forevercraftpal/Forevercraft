# === GEARWRIGHT — TINKER'S OMNITOOL APPLY (Chest-Node §6 / A2) ===
# Run as @s = player, called from artifacts/accessories/player_tick when the combined Tinker's
# Omnitool is held (container.* or offhand). The Omnitool IS Gearwright's spirit-item: it sets ALL
# FOUR chest-system flags at once (the union of the four singles). One-writer of these flags is the
# detection block in player_tick (this is a leaf of that block — the flags it sets are owned there).
#
# The four flags are boolean presence (the chest engine reads them `matches 1`). The deeper magnitude
# of a fused/re-fused omnitool is conferred via ec.gw_sigtier (read by craft_affinity/abilities/
# read_sig_tier — the spirit-item tier-7 row of every Gearwright ability table), NOT a per-flag scalar.
# The per-ability counters {crate_lvl,spawn_lvl,open_lvl,ender_lvl} on the item (capped 3) are a
# progression record bumped by the Plinth consume-merge handler; they are read by the Almanac/lore,
# not by this flag set.
scoreboard players set @s ec.acc_cratepct 1
scoreboard players set @s ec.acc_spawn 1
scoreboard players set @s ec.acc_openpct 1
scoreboard players set @s ec.acc_ender 1
