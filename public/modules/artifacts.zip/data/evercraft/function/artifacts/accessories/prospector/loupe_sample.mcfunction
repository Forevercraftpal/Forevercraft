# U13 Quartzlight Loupe (Family K Prospector — art-K) — on-demand ore sample + ping
# Run as @s = player, at @s. Sneak-triggered on-demand (gate at the call site). UTILITY-FEASIBILITY
# RESCOPE: blocks can't glow and a 12 b ore-cube scan (~15k cells) is infeasible. So this REUSES the
# proven bounded ore-SAMPLE pattern (artifacts/accessories/ore_ping — a fixed set of ≤~40 `if block`
# samples in a tight radius, NOT a cube sweep) + a directional amethyst ping, on a manual sneak pulse.
# DISTINCT from Miner's Lantern's PASSIVE per-tick ping: this is an ON-DEMAND sneak burst with a louder
# chime, so it earns its slot as a deliberate "read the stone for ore" verb (the DROP-candidate edge:
# if Joseph finds it too close to Miner's Lantern, it's a one-line removal — flagged). Debounced by
# ec.pr_pingcd (40t = 2s). NO block-glow, NO volume scan.

# Cooldown gate (debounce). If still recharging, bail quietly.
execute if score @s ec.pr_pingcd matches 1.. run return 0
scoreboard players set @s ec.pr_pingcd 40

# Sample cue: a quartz-bright chime + a small dust burst at the player.
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.amethyst_block.chime player @s ~ ~ ~ 0.8 1.6
particle minecraft:end_rod ~ ~1 ~ 0.3 0.3 0.3 0.0 8 force @s

# Reuse the proven bounded ore-sample (happy_villager/soul_fire_flame particles at sampled ore cells).
# This is the on-demand "outline replacement" the RESCOPE mandates: particles at detected ore, not a
# rendered vein. ore_ping already runs `at @s` internally per-cell.
function evercraft:artifacts/accessories/ore_ping
