# === ACCESSORY HARVEST BONUS — READ (D-FORTUNE-REWRITE, m2) ===
# Run as @s = player, ON a qualifying harvest break event (NOT a tick loop). Computes this
# player's harvest-bonus odds from the accessories they currently hold, into three fakes:
#   #hb_crate ec.temp  — EXTRA crate odds, in roll-units out of 100 (e.g. 2 = +2% crate chance)
#   #hb_dbl   ec.temp  — DOUBLE-HARVEST chance, in roll-units out of 100 (e.g. 15 = 15% per item)
#   @s ec.hb_active     — 1 if the player holds ANY harvest-bonus accessory, else 0 (early-exit gate)
#
# THIS is the ONE writer of #hb_crate / #hb_dbl / ec.hb_active (one-writer-per-scoreboard). The
# foundation entry fns (harvest_bonus / harvest_bonus_crate) only READ them. Leaf units (the
# rewritten C4 Forester's Tally -> Family K, C16 Master Smith's Crystal axe-part -> Family G,
# C41 Tiller's Knot / C42 Gleaner's Twine -> Family J, + any sibling) add EXACTLY two lines each
# in the LEAF ADD block below — no other wiring. This replaces the dropped Fortune-enchant-inject
# mechanic (the old item modify evercraft:fortune_add_* / hoe_fortune_* injects): no enchant is
# ever applied to a tool; instead each harvest break rolls these item-gated odds.
#
# COST: this runs only on a harvest break (a few times/sec per active harvester), and only after
# the caller already did its own existence work — so the item scans here are not per-tick.

# Zero the three outputs (clear-on-removal: a player who unequips all harvest pieces re-reads 0).
scoreboard players set #hb_crate ec.temp 0
scoreboard players set #hb_dbl ec.temp 0
scoreboard players set @s ec.hb_active 0

# ============================================================
# >>> LEAF HARVEST-BONUS ADDS GO HERE (units C4->K, C16->G, C41/C42->J + siblings).
# Each rewritten Fortune-item appends EXACTLY these two lines (container.* + offhand), tuned
# to its tier. Set ec.hb_active=1 and ADD crate-odds + double-harvest points:
#
#   execute if items entity @s container.* *[custom_data~{artifact:"<id>"}] run scoreboard players set @s ec.hb_active 1
#   execute if items entity @s weapon.offhand  *[custom_data~{artifact:"<id>"}] run scoreboard players set @s ec.hb_active 1
#   execute if items entity @s container.* *[custom_data~{artifact:"<id>"}] run scoreboard players add #hb_crate ec.temp <C>
#   execute if items entity @s weapon.offhand  *[custom_data~{artifact:"<id>"}] run scoreboard players add #hb_crate ec.temp <C>
#   execute if items entity @s container.* *[custom_data~{artifact:"<id>"}] run scoreboard players add #hb_dbl ec.temp <D>
#   execute if items entity @s weapon.offhand  *[custom_data~{artifact:"<id>"}] run scoreboard players add #hb_dbl ec.temp <D>
#
# Suggested tuning (per the lattice tiers — leaf units finalize):
#   C42 Gleaner's Twine  (Uncommon, crop) : <C>=2  <D>=10
#   C41 Tiller's Knot    (Rare, crop)     : <C>=3  <D>=20
#   C4  Forester's Tally (Uncommon, tree) : <C>=2  <D>=10
#   C16 Master Smith's Crystal (Ornate, axe-part) : <C>=3  <D>=20
# (Crops route through harvest_bonus with the correct ITEM id; trees/prospect route the same way.)
# C16 Master Smith's Crystal (Ornate, axe-part -> Family G; art-G). FORTUNE-REWRITE m2: the axe
# yield charm. Tree-crate odds <C>=3 + double-log chance <D>=20 (the lattice's Ornate axe-part
# tuning). The crate half fires on a LOG/TREE break via grant_verb class 2 -> harvest_bonus_crate
# (already wired, m2). The double-LOG half is owned by C16's own looked-at-log give in detect_
# ordinary_tool (the broken log id is not known at the grant_verb detector site, so C16 supplies it
# via the axe break event). Both halves read the #hb_dbl / #hb_crate this block sets.
execute if items entity @s container.* *[custom_data~{artifact:"master_smiths_crystal"}] run scoreboard players set @s ec.hb_active 1
execute unless items entity @s container.* *[custom_data~{artifact:"master_smiths_crystal"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"master_smiths_crystal"}] if entity @s[tag=ec.sat_master_smiths_crystal] run scoreboard players set @s ec.hb_active 1
execute if items entity @s weapon.offhand *[custom_data~{artifact:"master_smiths_crystal"}] run scoreboard players set @s ec.hb_active 1
execute if items entity @s container.* *[custom_data~{artifact:"master_smiths_crystal"}] run scoreboard players add #hb_crate ec.temp 3
execute unless items entity @s container.* *[custom_data~{artifact:"master_smiths_crystal"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"master_smiths_crystal"}] if entity @s[tag=ec.sat_master_smiths_crystal] run scoreboard players add #hb_crate ec.temp 3
execute if items entity @s weapon.offhand *[custom_data~{artifact:"master_smiths_crystal"}] run scoreboard players add #hb_crate ec.temp 3
execute if items entity @s container.* *[custom_data~{artifact:"master_smiths_crystal"}] run scoreboard players add #hb_dbl ec.temp 20
execute unless items entity @s container.* *[custom_data~{artifact:"master_smiths_crystal"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"master_smiths_crystal"}] if entity @s[tag=ec.sat_master_smiths_crystal] run scoreboard players add #hb_dbl ec.temp 20
execute if items entity @s weapon.offhand *[custom_data~{artifact:"master_smiths_crystal"}] run scoreboard players add #hb_dbl ec.temp 20
# cap-G: the grand Grandforge Regalia consolidates the Master Smith's Crystal tree-crate + double-log
# (m2) — re-supply the SAME odds gated on the grand, but ONLY when the loose Crystal is NOT held (so a
# re-acquired loose Crystal never doubles the odds; exactly one path runs). Only the grand consolidates
# the Crystal (it lives in the Grand Anvil Heart sub-line, not the Forge Resolve sub-cap). Same crate
# +3 / double +20 (the Ornate axe-part tuning). The double-LOG half re-fires via crystal_double_log,
# gated on the grand in detect_ordinary_tool above.
execute unless items entity @s container.* *[custom_data~{artifact:"master_smiths_crystal"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"master_smiths_crystal"}] unless entity @s[tag=ec.sat_master_smiths_crystal] if items entity @s container.* *[custom_data~{grandforge_regalia:true}] run scoreboard players set @s ec.hb_active 1
execute unless items entity @s container.* *[custom_data~{artifact:"master_smiths_crystal"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"master_smiths_crystal"}] unless entity @s[tag=ec.sat_master_smiths_crystal] unless items entity @s container.* *[custom_data~{grandforge_regalia:true}] unless items entity @s weapon.offhand *[custom_data~{grandforge_regalia:true}] if entity @s[tag=ec.sat_grandforge_regalia] run scoreboard players set @s ec.hb_active 1
execute unless items entity @s container.* *[custom_data~{artifact:"master_smiths_crystal"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"master_smiths_crystal"}] unless entity @s[tag=ec.sat_master_smiths_crystal] if items entity @s weapon.offhand *[custom_data~{grandforge_regalia:true}] run scoreboard players set @s ec.hb_active 1
execute unless items entity @s container.* *[custom_data~{artifact:"master_smiths_crystal"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"master_smiths_crystal"}] unless entity @s[tag=ec.sat_master_smiths_crystal] if items entity @s container.* *[custom_data~{grandforge_regalia:true}] run scoreboard players add #hb_crate ec.temp 3
execute unless items entity @s container.* *[custom_data~{artifact:"master_smiths_crystal"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"master_smiths_crystal"}] unless entity @s[tag=ec.sat_master_smiths_crystal] unless items entity @s container.* *[custom_data~{grandforge_regalia:true}] unless items entity @s weapon.offhand *[custom_data~{grandforge_regalia:true}] if entity @s[tag=ec.sat_grandforge_regalia] run scoreboard players add #hb_crate ec.temp 3
execute unless items entity @s container.* *[custom_data~{artifact:"master_smiths_crystal"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"master_smiths_crystal"}] unless entity @s[tag=ec.sat_master_smiths_crystal] if items entity @s weapon.offhand *[custom_data~{grandforge_regalia:true}] run scoreboard players add #hb_crate ec.temp 3
execute unless items entity @s container.* *[custom_data~{artifact:"master_smiths_crystal"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"master_smiths_crystal"}] unless entity @s[tag=ec.sat_master_smiths_crystal] if items entity @s container.* *[custom_data~{grandforge_regalia:true}] run scoreboard players add #hb_dbl ec.temp 20
execute unless items entity @s container.* *[custom_data~{artifact:"master_smiths_crystal"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"master_smiths_crystal"}] unless entity @s[tag=ec.sat_master_smiths_crystal] unless items entity @s container.* *[custom_data~{grandforge_regalia:true}] unless items entity @s weapon.offhand *[custom_data~{grandforge_regalia:true}] if entity @s[tag=ec.sat_grandforge_regalia] run scoreboard players add #hb_dbl ec.temp 20
execute unless items entity @s container.* *[custom_data~{artifact:"master_smiths_crystal"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"master_smiths_crystal"}] unless entity @s[tag=ec.sat_master_smiths_crystal] if items entity @s weapon.offhand *[custom_data~{grandforge_regalia:true}] run scoreboard players add #hb_dbl ec.temp 20
# C41 Tiller's Knot (Rare, crop -> Family J; art-J). FORTUNE-REWRITE m2 (drops the old hoe_fortune_2
# enchant-inject entirely — never built, so nothing to delete). Crop crate-odds <C>=3 + double-crop
# chance <D>=20 (the lattice's Rare crop tuning). Fires on a crop break via crop_harvest/process_*
# -> harvest_bonus {drop:"<ITEM>", n:1} (item-aware double-harvest + crate roll, m2). NO Fortune
# enchant on any hoe. set-not-add / id-presence -> two copies of the Knot add once (m4 multi-copy-safe).
# cap-J m4 SUPPRESS-AT-SOURCE: when the Harvest Knot sub-cap OR the grand Cornucopia Tide is held on
# Adventurer/Pioneer, the loose Tiller + Gleaner are suppressed (#hb_jsup) — the node grants the
# consolidated crate +5 / double +30 below — so a re-acquired loose crop charm never double-counts.
# Newcomer-exempt (casual players keep the full loose stack). This is a break-event hook, no cross-tick.
scoreboard players set #hb_jsup ec.temp 0
execute unless score @s ec.difficulty matches 1 if items entity @s container.* *[custom_data~{harvest_knot:true}] run scoreboard players set #hb_jsup ec.temp 1
execute unless score @s ec.difficulty matches 1 unless items entity @s container.* *[custom_data~{harvest_knot:true}] unless items entity @s weapon.offhand *[custom_data~{harvest_knot:true}] if entity @s[tag=ec.sat_harvest_knot] run scoreboard players set #hb_jsup ec.temp 1
execute unless score @s ec.difficulty matches 1 if items entity @s weapon.offhand *[custom_data~{harvest_knot:true}] run scoreboard players set #hb_jsup ec.temp 1
execute unless score @s ec.difficulty matches 1 if items entity @s container.* *[custom_data~{cornucopia_tide:true}] run scoreboard players set #hb_jsup ec.temp 1
execute unless score @s ec.difficulty matches 1 unless items entity @s container.* *[custom_data~{cornucopia_tide:true}] unless items entity @s weapon.offhand *[custom_data~{cornucopia_tide:true}] if entity @s[tag=ec.sat_cornucopia_tide] run scoreboard players set #hb_jsup ec.temp 1
execute unless score @s ec.difficulty matches 1 if items entity @s weapon.offhand *[custom_data~{cornucopia_tide:true}] run scoreboard players set #hb_jsup ec.temp 1
execute unless score #hb_jsup ec.temp matches 1 if items entity @s container.* *[custom_data~{artifact:"tillers_knot"}] run scoreboard players set @s ec.hb_active 1
execute unless score #hb_jsup ec.temp matches 1 unless items entity @s container.* *[custom_data~{artifact:"tillers_knot"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"tillers_knot"}] if entity @s[tag=ec.sat_tillers_knot] run scoreboard players set @s ec.hb_active 1
execute unless score #hb_jsup ec.temp matches 1 if items entity @s weapon.offhand *[custom_data~{artifact:"tillers_knot"}] run scoreboard players set @s ec.hb_active 1
execute unless score #hb_jsup ec.temp matches 1 if items entity @s container.* *[custom_data~{artifact:"tillers_knot"}] run scoreboard players add #hb_crate ec.temp 3
execute unless score #hb_jsup ec.temp matches 1 unless items entity @s container.* *[custom_data~{artifact:"tillers_knot"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"tillers_knot"}] if entity @s[tag=ec.sat_tillers_knot] run scoreboard players add #hb_crate ec.temp 3
execute unless score #hb_jsup ec.temp matches 1 if items entity @s weapon.offhand *[custom_data~{artifact:"tillers_knot"}] run scoreboard players add #hb_crate ec.temp 3
execute unless score #hb_jsup ec.temp matches 1 if items entity @s container.* *[custom_data~{artifact:"tillers_knot"}] run scoreboard players add #hb_dbl ec.temp 20
execute unless score #hb_jsup ec.temp matches 1 unless items entity @s container.* *[custom_data~{artifact:"tillers_knot"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"tillers_knot"}] if entity @s[tag=ec.sat_tillers_knot] run scoreboard players add #hb_dbl ec.temp 20
execute unless score #hb_jsup ec.temp matches 1 if items entity @s weapon.offhand *[custom_data~{artifact:"tillers_knot"}] run scoreboard players add #hb_dbl ec.temp 20
# C42 Gleaner's Twine (Uncommon, crop -> Family J; art-J). Lower-tier sibling of Tiller's Knot (the
# ladder). FORTUNE-REWRITE m2: crop crate-odds <C>=2 + double-crop chance <D>=10 (the lattice's
# Uncommon crop tuning). Same crop-break path. NO Fortune enchant. id-presence (m4 multi-copy-safe).
execute unless score #hb_jsup ec.temp matches 1 if items entity @s container.* *[custom_data~{artifact:"gleaners_twine"}] run scoreboard players set @s ec.hb_active 1
execute unless score #hb_jsup ec.temp matches 1 unless items entity @s container.* *[custom_data~{artifact:"gleaners_twine"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"gleaners_twine"}] if entity @s[tag=ec.sat_gleaners_twine] run scoreboard players set @s ec.hb_active 1
execute unless score #hb_jsup ec.temp matches 1 if items entity @s weapon.offhand *[custom_data~{artifact:"gleaners_twine"}] run scoreboard players set @s ec.hb_active 1
execute unless score #hb_jsup ec.temp matches 1 if items entity @s container.* *[custom_data~{artifact:"gleaners_twine"}] run scoreboard players add #hb_crate ec.temp 2
execute unless score #hb_jsup ec.temp matches 1 unless items entity @s container.* *[custom_data~{artifact:"gleaners_twine"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"gleaners_twine"}] if entity @s[tag=ec.sat_gleaners_twine] run scoreboard players add #hb_crate ec.temp 2
execute unless score #hb_jsup ec.temp matches 1 if items entity @s weapon.offhand *[custom_data~{artifact:"gleaners_twine"}] run scoreboard players add #hb_crate ec.temp 2
execute unless score #hb_jsup ec.temp matches 1 if items entity @s container.* *[custom_data~{artifact:"gleaners_twine"}] run scoreboard players add #hb_dbl ec.temp 10
execute unless score #hb_jsup ec.temp matches 1 unless items entity @s container.* *[custom_data~{artifact:"gleaners_twine"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"gleaners_twine"}] if entity @s[tag=ec.sat_gleaners_twine] run scoreboard players add #hb_dbl ec.temp 10
execute unless score #hb_jsup ec.temp matches 1 if items entity @s weapon.offhand *[custom_data~{artifact:"gleaners_twine"}] run scoreboard players add #hb_dbl ec.temp 10
# cap-J CONSOLIDATED crop yield: the Harvest Knot sub-cap + the grand Cornucopia Tide each grant the
# consolidated crate +5 / double +30 (Tiller +3/+20 + Gleaner +2/+10 folded). set-not-add / id-presence
# -> two copies add once. The grand supersedes the Knot (guarded `unless` the grand) so only one fold
# fires. Routes through the same crop-break harvest_bonus path (NO Fortune enchant on any hoe).
execute if items entity @s container.* *[custom_data~{cornucopia_tide:true}] run scoreboard players set @s ec.hb_active 1
execute unless items entity @s container.* *[custom_data~{cornucopia_tide:true}] unless items entity @s weapon.offhand *[custom_data~{cornucopia_tide:true}] if entity @s[tag=ec.sat_cornucopia_tide] run scoreboard players set @s ec.hb_active 1
execute if items entity @s weapon.offhand *[custom_data~{cornucopia_tide:true}] run scoreboard players set @s ec.hb_active 1
execute if items entity @s container.* *[custom_data~{cornucopia_tide:true}] run scoreboard players add #hb_crate ec.temp 5
execute unless items entity @s container.* *[custom_data~{cornucopia_tide:true}] unless items entity @s weapon.offhand *[custom_data~{cornucopia_tide:true}] if entity @s[tag=ec.sat_cornucopia_tide] run scoreboard players add #hb_crate ec.temp 5
execute if items entity @s weapon.offhand *[custom_data~{cornucopia_tide:true}] run scoreboard players add #hb_crate ec.temp 5
execute if items entity @s container.* *[custom_data~{cornucopia_tide:true}] run scoreboard players add #hb_dbl ec.temp 30
execute unless items entity @s container.* *[custom_data~{cornucopia_tide:true}] unless items entity @s weapon.offhand *[custom_data~{cornucopia_tide:true}] if entity @s[tag=ec.sat_cornucopia_tide] run scoreboard players add #hb_dbl ec.temp 30
execute if items entity @s weapon.offhand *[custom_data~{cornucopia_tide:true}] run scoreboard players add #hb_dbl ec.temp 30
execute unless items entity @s container.* *[custom_data~{cornucopia_tide:true}] unless items entity @s weapon.offhand *[custom_data~{cornucopia_tide:true}] unless entity @s[tag=ec.sat_cornucopia_tide] if items entity @s container.* *[custom_data~{harvest_knot:true}] run scoreboard players set @s ec.hb_active 1
execute unless items entity @s container.* *[custom_data~{cornucopia_tide:true}] unless items entity @s weapon.offhand *[custom_data~{cornucopia_tide:true}] unless entity @s[tag=ec.sat_cornucopia_tide] unless items entity @s container.* *[custom_data~{harvest_knot:true}] unless items entity @s weapon.offhand *[custom_data~{harvest_knot:true}] if entity @s[tag=ec.sat_harvest_knot] run scoreboard players set @s ec.hb_active 1
execute unless items entity @s container.* *[custom_data~{cornucopia_tide:true}] unless items entity @s weapon.offhand *[custom_data~{cornucopia_tide:true}] unless entity @s[tag=ec.sat_cornucopia_tide] if items entity @s weapon.offhand *[custom_data~{harvest_knot:true}] run scoreboard players set @s ec.hb_active 1
execute unless items entity @s container.* *[custom_data~{cornucopia_tide:true}] unless items entity @s weapon.offhand *[custom_data~{cornucopia_tide:true}] unless entity @s[tag=ec.sat_cornucopia_tide] if items entity @s container.* *[custom_data~{harvest_knot:true}] run scoreboard players add #hb_crate ec.temp 5
execute unless items entity @s container.* *[custom_data~{cornucopia_tide:true}] unless items entity @s weapon.offhand *[custom_data~{cornucopia_tide:true}] unless entity @s[tag=ec.sat_cornucopia_tide] unless items entity @s container.* *[custom_data~{harvest_knot:true}] unless items entity @s weapon.offhand *[custom_data~{harvest_knot:true}] if entity @s[tag=ec.sat_harvest_knot] run scoreboard players add #hb_crate ec.temp 5
execute unless items entity @s container.* *[custom_data~{cornucopia_tide:true}] unless items entity @s weapon.offhand *[custom_data~{cornucopia_tide:true}] unless entity @s[tag=ec.sat_cornucopia_tide] if items entity @s weapon.offhand *[custom_data~{harvest_knot:true}] run scoreboard players add #hb_crate ec.temp 5
execute unless items entity @s container.* *[custom_data~{cornucopia_tide:true}] unless items entity @s weapon.offhand *[custom_data~{cornucopia_tide:true}] unless entity @s[tag=ec.sat_cornucopia_tide] if items entity @s container.* *[custom_data~{harvest_knot:true}] run scoreboard players add #hb_dbl ec.temp 30
execute unless items entity @s container.* *[custom_data~{cornucopia_tide:true}] unless items entity @s weapon.offhand *[custom_data~{cornucopia_tide:true}] unless entity @s[tag=ec.sat_cornucopia_tide] unless items entity @s container.* *[custom_data~{harvest_knot:true}] unless items entity @s weapon.offhand *[custom_data~{harvest_knot:true}] if entity @s[tag=ec.sat_harvest_knot] run scoreboard players add #hb_dbl ec.temp 30
execute unless items entity @s container.* *[custom_data~{cornucopia_tide:true}] unless items entity @s weapon.offhand *[custom_data~{cornucopia_tide:true}] unless entity @s[tag=ec.sat_cornucopia_tide] if items entity @s weapon.offhand *[custom_data~{harvest_knot:true}] run scoreboard players add #hb_dbl ec.temp 30
# C4 Forester's Tally (Uncommon, tree -> Family K Prospector; art-K). FORTUNE-REWRITE m2 (drops the
# old fortune_add_3 enchant-inject entirely — never built, so nothing to delete). Tree crate-odds
# <C>=2 + double-LOG chance <D>=10 (the lattice's Uncommon tree tuning). The crate half fires on a
# LOG/TREE break via grant_verb class 2 -> harvest_bonus_crate (already wired, m2). The double-LOG
# half is owned by art-K's own looked-at-log give (foresters_double_log in detect_ordinary_tool, the
# C16 crystal_double_log pattern — the broken log id isn't known at the grant_verb site). Both halves
# read the #hb_dbl / #hb_crate this block sets. set-not-add / id-presence -> two copies add once
# (m4 multi-copy-safe). NO Fortune enchant on any axe.
execute if items entity @s container.* *[custom_data~{artifact:"foresters_tally"}] run scoreboard players set @s ec.hb_active 1
execute unless items entity @s container.* *[custom_data~{artifact:"foresters_tally"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"foresters_tally"}] if entity @s[tag=ec.sat_foresters_tally] run scoreboard players set @s ec.hb_active 1
execute if items entity @s weapon.offhand *[custom_data~{artifact:"foresters_tally"}] run scoreboard players set @s ec.hb_active 1
execute if items entity @s container.* *[custom_data~{artifact:"foresters_tally"}] run scoreboard players add #hb_crate ec.temp 2
execute unless items entity @s container.* *[custom_data~{artifact:"foresters_tally"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"foresters_tally"}] if entity @s[tag=ec.sat_foresters_tally] run scoreboard players add #hb_crate ec.temp 2
execute if items entity @s weapon.offhand *[custom_data~{artifact:"foresters_tally"}] run scoreboard players add #hb_crate ec.temp 2
execute if items entity @s container.* *[custom_data~{artifact:"foresters_tally"}] run scoreboard players add #hb_dbl ec.temp 10
execute unless items entity @s container.* *[custom_data~{artifact:"foresters_tally"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"foresters_tally"}] if entity @s[tag=ec.sat_foresters_tally] run scoreboard players add #hb_dbl ec.temp 10
execute if items entity @s weapon.offhand *[custom_data~{artifact:"foresters_tally"}] run scoreboard players add #hb_dbl ec.temp 10
# Claude's Gift — harvest-doubling REMOVED 2026-06-05 (balance). It was wired as an all-gather capstone
# (<D>=100 always-2x + <C>=5 crate) which strictly ECLIPSED the cornucopia_tide fusion capstone (a long
# progression). Claude's Gift's identity is its Str/Haste/Speed III + Luck V (+5 Dream Rate) buff stack;
# harvest belongs to the Cornucopia/Demiurge/Grandforge capstones. cornucopia_tide is again harvest king.
# C43 Resonant Geode Heart (Exquisite, all-gather -> Family K Prospector; art-K). +2% Crafting Crate
# on break/harvest/catch. CRATE-ONLY (<C>=2, NO double-harvest): it rides the SAME crate hooks the m2
# foundation already wires — grant_verb class 2 (logs) + gather/resolve_win (nodes) ->
# harvest_bonus_crate — PLUS art-K adds an ore-mining (grant_weighted class 1) + a fishing-catch hook
# elsewhere so it truly fires on break/harvest/catch. Steady crate stream, ADDITIVE on try_crate_drop's
# base. set-not-add / id-presence (m4 multi-copy-safe). NO double-harvest (a crate charm, not a yield).
# cap-K m4 SUPPRESS-AT-SOURCE: the Geode is absorbed by the Crate Pair -> Node Mastery -> the grand
# Demiurge's Spirit Artifact. When ANY of those absorbing nodes is held, suppress the loose Geode (#hb_ksup,
# Newcomer-exempt) and let the node grant the consolidated +2 crate below — so a re-acquired loose Geode
# never double-dips. The loose Geode keeps its full +2 on Newcomer (forgiving stack) + whenever no
# absorbing node is held. (C4 Forester's Tally is NOT a cap-K tree member — it stays loose, untouched.)
scoreboard players set #hb_ksup ec.temp 0
execute unless score @s ec.difficulty matches 1 if items entity @s container.* *[custom_data~{crate_pair:true}] run scoreboard players set #hb_ksup ec.temp 1
execute unless score @s ec.difficulty matches 1 if items entity @s weapon.offhand *[custom_data~{crate_pair:true}] run scoreboard players set #hb_ksup ec.temp 1
execute unless score @s ec.difficulty matches 1 if items entity @s container.* *[custom_data~{node_mastery:true}] run scoreboard players set #hb_ksup ec.temp 1
execute unless score @s ec.difficulty matches 1 unless items entity @s container.* *[custom_data~{node_mastery:true}] unless items entity @s weapon.offhand *[custom_data~{node_mastery:true}] if entity @s[tag=ec.sat_node_mastery] run scoreboard players set #hb_ksup ec.temp 1
execute unless score @s ec.difficulty matches 1 if items entity @s weapon.offhand *[custom_data~{node_mastery:true}] run scoreboard players set #hb_ksup ec.temp 1
execute unless score @s ec.difficulty matches 1 if items entity @s container.* *[custom_data~{demiurges_capstone:true}] run scoreboard players set #hb_ksup ec.temp 1
execute unless score @s ec.difficulty matches 1 unless items entity @s container.* *[custom_data~{demiurges_capstone:true}] unless items entity @s weapon.offhand *[custom_data~{demiurges_capstone:true}] if entity @s[tag=ec.sat_demiurges_capstone] run scoreboard players set #hb_ksup ec.temp 1
execute unless score @s ec.difficulty matches 1 if items entity @s weapon.offhand *[custom_data~{demiurges_capstone:true}] run scoreboard players set #hb_ksup ec.temp 1
execute unless score #hb_ksup ec.temp matches 1 if items entity @s container.* *[custom_data~{artifact:"resonant_geode_heart"}] run scoreboard players set @s ec.hb_active 1
execute unless score #hb_ksup ec.temp matches 1 unless items entity @s container.* *[custom_data~{artifact:"resonant_geode_heart"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"resonant_geode_heart"}] if entity @s[tag=ec.sat_resonant_geode_heart] run scoreboard players set @s ec.hb_active 1
execute unless score #hb_ksup ec.temp matches 1 if items entity @s weapon.offhand *[custom_data~{artifact:"resonant_geode_heart"}] run scoreboard players set @s ec.hb_active 1
execute unless score #hb_ksup ec.temp matches 1 if items entity @s container.* *[custom_data~{artifact:"resonant_geode_heart"}] run scoreboard players add #hb_crate ec.temp 2
execute unless score #hb_ksup ec.temp matches 1 unless items entity @s container.* *[custom_data~{artifact:"resonant_geode_heart"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"resonant_geode_heart"}] if entity @s[tag=ec.sat_resonant_geode_heart] run scoreboard players add #hb_crate ec.temp 2
execute unless score #hb_ksup ec.temp matches 1 if items entity @s weapon.offhand *[custom_data~{artifact:"resonant_geode_heart"}] run scoreboard players add #hb_crate ec.temp 2
# cap-K CONSOLIDATED Geode crate (+2): the Crate Pair / Node Mastery / Demiurge's Spirit Artifact grant the
# consolidated +2 crate (the Geode's lever folded). set-not-add / id-presence -> never stacks. Supersede is
# unnecessary (the value is identical +2 from any node, and ec.hb_active is a set-to-1, #hb_crate add +2;
# only one node-tier need fire, so gate each lower tier `unless` a higher one is held). Grand FIRST.
execute if items entity @s container.* *[custom_data~{demiurges_capstone:true}] run scoreboard players set @s ec.hb_active 1
execute unless items entity @s container.* *[custom_data~{demiurges_capstone:true}] unless items entity @s weapon.offhand *[custom_data~{demiurges_capstone:true}] if entity @s[tag=ec.sat_demiurges_capstone] run scoreboard players set @s ec.hb_active 1
execute if items entity @s weapon.offhand *[custom_data~{demiurges_capstone:true}] run scoreboard players set @s ec.hb_active 1
execute if items entity @s container.* *[custom_data~{demiurges_capstone:true}] run scoreboard players add #hb_crate ec.temp 2
execute unless items entity @s container.* *[custom_data~{demiurges_capstone:true}] unless items entity @s weapon.offhand *[custom_data~{demiurges_capstone:true}] if entity @s[tag=ec.sat_demiurges_capstone] run scoreboard players add #hb_crate ec.temp 2
execute if items entity @s weapon.offhand *[custom_data~{demiurges_capstone:true}] run scoreboard players add #hb_crate ec.temp 2
execute unless items entity @s container.* *[custom_data~{demiurges_capstone:true}] unless items entity @s weapon.offhand *[custom_data~{demiurges_capstone:true}] unless entity @s[tag=ec.sat_demiurges_capstone] if items entity @s container.* *[custom_data~{node_mastery:true}] run scoreboard players set @s ec.hb_active 1
execute unless items entity @s container.* *[custom_data~{demiurges_capstone:true}] unless items entity @s weapon.offhand *[custom_data~{demiurges_capstone:true}] unless entity @s[tag=ec.sat_demiurges_capstone] unless items entity @s container.* *[custom_data~{node_mastery:true}] unless items entity @s weapon.offhand *[custom_data~{node_mastery:true}] if entity @s[tag=ec.sat_node_mastery] run scoreboard players set @s ec.hb_active 1
execute unless items entity @s container.* *[custom_data~{demiurges_capstone:true}] unless items entity @s weapon.offhand *[custom_data~{demiurges_capstone:true}] unless entity @s[tag=ec.sat_demiurges_capstone] if items entity @s weapon.offhand *[custom_data~{node_mastery:true}] run scoreboard players set @s ec.hb_active 1
execute unless items entity @s container.* *[custom_data~{demiurges_capstone:true}] unless items entity @s weapon.offhand *[custom_data~{demiurges_capstone:true}] unless entity @s[tag=ec.sat_demiurges_capstone] if items entity @s container.* *[custom_data~{node_mastery:true}] run scoreboard players add #hb_crate ec.temp 2
execute unless items entity @s container.* *[custom_data~{demiurges_capstone:true}] unless items entity @s weapon.offhand *[custom_data~{demiurges_capstone:true}] unless entity @s[tag=ec.sat_demiurges_capstone] unless items entity @s container.* *[custom_data~{node_mastery:true}] unless items entity @s weapon.offhand *[custom_data~{node_mastery:true}] if entity @s[tag=ec.sat_node_mastery] run scoreboard players add #hb_crate ec.temp 2
execute unless items entity @s container.* *[custom_data~{demiurges_capstone:true}] unless items entity @s weapon.offhand *[custom_data~{demiurges_capstone:true}] unless entity @s[tag=ec.sat_demiurges_capstone] if items entity @s weapon.offhand *[custom_data~{node_mastery:true}] run scoreboard players add #hb_crate ec.temp 2
execute unless items entity @s container.* *[custom_data~{demiurges_capstone:true}] unless items entity @s weapon.offhand *[custom_data~{demiurges_capstone:true}] unless entity @s[tag=ec.sat_demiurges_capstone] unless items entity @s container.* *[custom_data~{node_mastery:true}] unless items entity @s weapon.offhand *[custom_data~{node_mastery:true}] unless entity @s[tag=ec.sat_node_mastery] if items entity @s container.* *[custom_data~{crate_pair:true}] run scoreboard players set @s ec.hb_active 1
execute unless items entity @s container.* *[custom_data~{demiurges_capstone:true}] unless items entity @s weapon.offhand *[custom_data~{demiurges_capstone:true}] unless entity @s[tag=ec.sat_demiurges_capstone] unless items entity @s container.* *[custom_data~{node_mastery:true}] unless items entity @s weapon.offhand *[custom_data~{node_mastery:true}] unless entity @s[tag=ec.sat_node_mastery] if items entity @s weapon.offhand *[custom_data~{crate_pair:true}] run scoreboard players set @s ec.hb_active 1
execute unless items entity @s container.* *[custom_data~{demiurges_capstone:true}] unless items entity @s weapon.offhand *[custom_data~{demiurges_capstone:true}] unless entity @s[tag=ec.sat_demiurges_capstone] unless items entity @s container.* *[custom_data~{node_mastery:true}] unless items entity @s weapon.offhand *[custom_data~{node_mastery:true}] unless entity @s[tag=ec.sat_node_mastery] if items entity @s container.* *[custom_data~{crate_pair:true}] run scoreboard players add #hb_crate ec.temp 2
execute unless items entity @s container.* *[custom_data~{demiurges_capstone:true}] unless items entity @s weapon.offhand *[custom_data~{demiurges_capstone:true}] unless entity @s[tag=ec.sat_demiurges_capstone] unless items entity @s container.* *[custom_data~{node_mastery:true}] unless items entity @s weapon.offhand *[custom_data~{node_mastery:true}] unless entity @s[tag=ec.sat_node_mastery] if items entity @s weapon.offhand *[custom_data~{crate_pair:true}] run scoreboard players add #hb_crate ec.temp 2
#
# Until the leaf units land, this block is EMPTY -> ec.hb_active stays 0 -> every caller early-
# exits with zero cost beyond one comparison. Wired-but-empty is harmless and ADDITIVE.
# ============================================================
