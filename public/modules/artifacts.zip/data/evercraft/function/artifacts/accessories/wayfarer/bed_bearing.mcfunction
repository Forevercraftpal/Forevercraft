# Wayfarer — Respawn-Point Bearing + Distance Readout (U7 Wanderer's Whetcompass)
# Run as @s = player, at @s. Sneak-triggered on-demand (the sneak+hold gate + cooldown debounce live
# at the call site). Reads the player's respawn point (26.1 respawn.pos int array — the modern
# replacement for SpawnX/Y/Z) and reports the 8-point cardinal bearing + the max-axis block distance
# toward it on the action bar. No held compass item, no loop, no scan — pure data read + arithmetic.
# Uses the global ec.const fakeplayers (#-1, #2 — seeded in init) for negation/ratio; declares NO new
# objective beyond the shared ec.wf_* temp lane (one writer = this readout family).

# No respawn set -> tell the player and bail (avoids a misleading 0,0 reading).
execute unless data entity @s respawn.pos unless entity @s[tag=ab_q] run title @s actionbar [{"text":"⚐ Whetcompass: ","color":"yellow"},{"text":"no respawn point set","color":"gray"}]
execute unless data entity @s respawn.pos run return 0

# Read respawn coords + current coords into scores.
execute store result score @s ec.wf_bx run data get entity @s respawn.pos[0]
execute store result score @s ec.wf_bz run data get entity @s respawn.pos[2]
execute store result score @s ec.wf_x run data get entity @s Pos[0] 1
execute store result score @s ec.wf_z run data get entity @s Pos[2] 1

# Deltas (target - self): +dx = bed is to +X (East), +dz = bed is to +Z (South).
scoreboard players operation @s ec.wf_dx = @s ec.wf_bx
scoreboard players operation @s ec.wf_dx -= @s ec.wf_x
scoreboard players operation @s ec.wf_dz = @s ec.wf_bz
scoreboard players operation @s ec.wf_dz -= @s ec.wf_z

# Absolute values via the shared #-1 ec.const.
scoreboard players operation @s ec.wf_adx = @s ec.wf_dx
execute if score @s ec.wf_adx matches ..-1 run scoreboard players operation @s ec.wf_adx *= #-1 ec.const
scoreboard players operation @s ec.wf_adz = @s ec.wf_dz
execute if score @s ec.wf_adz matches ..-1 run scoreboard players operation @s ec.wf_adz *= #-1 ec.const

# Max-axis (Chebyshev) block distance — cheap, no sqrt, fine for a "how far" readout.
scoreboard players operation @s ec.wf_dist = @s ec.wf_adx
execute if score @s ec.wf_adz > @s ec.wf_adx run scoreboard players operation @s ec.wf_dist = @s ec.wf_adz

# 2x the smaller axis, to test "is this a diagonal?" (corner named when min*2 >= max -> within ~26deg).
scoreboard players operation @s ec.wf_min = @s ec.wf_adx
execute if score @s ec.wf_adz < @s ec.wf_adx run scoreboard players operation @s ec.wf_min = @s ec.wf_adz
scoreboard players operation @s ec.wf_min2 = @s ec.wf_min
scoreboard players operation @s ec.wf_min2 *= #2 ec.const

# Face code 1..8 = N / NE / E / SE / S / SW / W / NW (shared encoding the sextant/codex reuse).
scoreboard players set @s ec.wf_bear 0
# Cardinal (not a diagonal): dominant axis wins outright.
execute if score @s ec.wf_min2 < @s ec.wf_dist if score @s ec.wf_dz matches ..-1 if score @s ec.wf_adz >= @s ec.wf_adx run scoreboard players set @s ec.wf_bear 1
execute if score @s ec.wf_min2 < @s ec.wf_dist if score @s ec.wf_dz matches 0.. if score @s ec.wf_adz > @s ec.wf_adx run scoreboard players set @s ec.wf_bear 5
execute if score @s ec.wf_min2 < @s ec.wf_dist if score @s ec.wf_dx matches 1.. if score @s ec.wf_adx >= @s ec.wf_adz run scoreboard players set @s ec.wf_bear 3
execute if score @s ec.wf_min2 < @s ec.wf_dist if score @s ec.wf_dx matches ..-1 if score @s ec.wf_adx > @s ec.wf_adz run scoreboard players set @s ec.wf_bear 7
# Diagonal: both axes comparable (min*2 >= max) -> name the corner from the two signs.
execute if score @s ec.wf_min2 >= @s ec.wf_dist if score @s ec.wf_dx matches 1.. if score @s ec.wf_dz matches ..-1 run scoreboard players set @s ec.wf_bear 2
execute if score @s ec.wf_min2 >= @s ec.wf_dist if score @s ec.wf_dx matches 1.. if score @s ec.wf_dz matches 0.. run scoreboard players set @s ec.wf_bear 4
execute if score @s ec.wf_min2 >= @s ec.wf_dist if score @s ec.wf_dx matches ..-1 if score @s ec.wf_dz matches 0.. run scoreboard players set @s ec.wf_bear 6
execute if score @s ec.wf_min2 >= @s ec.wf_dist if score @s ec.wf_dx matches ..-1 if score @s ec.wf_dz matches ..-1 run scoreboard players set @s ec.wf_bear 8

# Render the bearing glyph + distance.
function evercraft:artifacts/accessories/wayfarer/bed_render
