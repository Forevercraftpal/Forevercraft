# Iai Draw — Charge complete, enter ready stance
# OPT: Consolidates 6 @a scans into 1 function call
tag @s add ec.iai_ready
tag @s add ec.iai_fired
tag @s remove ec.iai_charging
scoreboard players set @s ec.iai_charge 0
data modify storage evercraft:notify stage.c set value [{text:"Iai Draw Ready!",color:"#FF69B4",bold:true}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.amethyst_block.chime player @s ~ ~ ~ 0.5 1.5
