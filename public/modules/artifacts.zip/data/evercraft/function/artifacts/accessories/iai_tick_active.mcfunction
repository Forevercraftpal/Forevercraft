# Iai Draw — Active state processing (only called when iai_charging or iai_ready exists)
# OPT: Extracted from accessories/tick to avoid 6 @a scans when nobody has a katana

# New charger detection (for players who just started sneaking with katana)
execute as @a[predicate=evercraft:is_sneaking] if items entity @s weapon.mainhand *[custom_data~{ability:"critical_edge"}] unless entity @s[tag=ec.iai_ready] run tag @s add ec.iai_charging

# Charge increment
execute as @a[tag=ec.iai_charging,predicate=evercraft:is_sneaking] if items entity @s weapon.mainhand *[custom_data~{ability:"critical_edge"}] run scoreboard players add @s ec.iai_charge 1

# After 2 ticks (2 seconds) of sneaking → Iai ready
execute as @a[tag=ec.iai_charging,scores={ec.iai_charge=2..}] at @s run function evercraft:artifacts/accessories/iai_ready

# Stop charging if no longer sneaking or weapon changed
execute as @a[tag=ec.iai_charging] unless predicate evercraft:is_sneaking run function evercraft:artifacts/accessories/iai_cancel_charge
execute as @a[tag=ec.iai_charging] unless items entity @s weapon.mainhand *[custom_data~{ability:"critical_edge"}] run function evercraft:artifacts/accessories/iai_cancel_charge

# Clear Iai stance if weapon changes
execute as @a[tag=ec.iai_ready] unless items entity @s weapon.mainhand *[custom_data~{ability:"critical_edge"}] run function evercraft:artifacts/accessories/iai_cancel_stance
