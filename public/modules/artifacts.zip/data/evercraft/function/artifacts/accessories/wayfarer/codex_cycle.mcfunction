# Wayfarer — Loremaster's Omni-Codex sneak-cycle dispatch (U24)
# Run as @s = player, at @s. Sneak-triggered (gate at the call site). Debounced via ec.wf_cyccd (16t,
# shared with the Sextant — a player won't sensibly cycle both at once). Cycles ec.wf_ccyc through
# 1..5 = coords / depth / home-bearing / biome / Dream Rate, running ONLY the active readout
# (lazy-eval per UTILITY-FEASIBILITY — never run all six per tick). Inherits each component's bounded
# cost. No scan, no particles, no loop.
execute if score @s ec.wf_cyccd matches 1.. run return 0
scoreboard players set @s ec.wf_cyccd 16
# Advance 1..5 (wrap).
scoreboard players add @s ec.wf_ccyc 1
execute unless score @s ec.wf_ccyc matches 1..5 run scoreboard players set @s ec.wf_ccyc 1
# Run only the active readout (the coords line forces face-derivation; the rest are self-contained).
execute if score @s ec.wf_ccyc matches 1 run function evercraft:artifacts/accessories/wayfarer/coord_readout
execute if score @s ec.wf_ccyc matches 2 run function evercraft:artifacts/accessories/wayfarer/depth_readout
execute if score @s ec.wf_ccyc matches 3 run function evercraft:artifacts/accessories/wayfarer/bed_bearing
execute if score @s ec.wf_ccyc matches 4 run function evercraft:artifacts/accessories/wayfarer/biome_readout
execute if score @s ec.wf_ccyc matches 5 run function evercraft:artifacts/accessories/wayfarer/dr_readout
