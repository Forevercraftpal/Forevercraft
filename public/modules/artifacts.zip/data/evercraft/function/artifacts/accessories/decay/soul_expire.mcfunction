# Soul Harvest expired — reset soul count and sentinel cooldown
scoreboard players set @s ec.eyelander_souls 0
scoreboard players set @s ec.soul_cd -1
