# U6 Plumb-Bob Token (Family K Prospector — art-K) — depth gauge + cave-below hint
# Run as @s = player, at @s. Sneak-triggered on-demand (gate at the call site). Action-bar readout:
# blocks-to-bedrock (Pos[1] - (-64), the build floor) + a "cave below" hint from a BOUNDED downward
# probe (≤8 `if block` tests, NOT a volume scan — UTILITY-FEASIBILITY's KEEP form, "already 90% built"
# via quests/depth/calculate). Debounced by ec.pr_pingcd (40t = 2s). No DR, no roll — a pure readout.

# Cooldown gate (debounce). If still recharging, bail quietly.
execute if score @s ec.pr_pingcd matches 1.. run return 0
scoreboard players set @s ec.pr_pingcd 40

# Depth to the world floor: read Pos[1], blocks-to-bedrock = Pos[1] + 64 (bedrock floor at y=-64).
execute store result score #pb_y ec.temp run data get entity @s Pos[1]
scoreboard players operation #pb_depth ec.temp = #pb_y ec.temp
scoreboard players add #pb_depth ec.temp 64

# "Cave below" hint: bounded downward probe of cells 3..8 below (~ ~-3..~-8 ~). If ANY is air/cave_air,
# there's an open pocket beneath. ≤12 `if block` tests (NOT an O(r^3) sweep), the directive's bound.
# (Cells -1/-2 are skipped — that's the floor the player is standing on, not a "cave below".)
scoreboard players set #pb_cave ec.temp 0
execute if block ~ ~-3 ~ air run scoreboard players set #pb_cave ec.temp 1
execute if block ~ ~-3 ~ cave_air run scoreboard players set #pb_cave ec.temp 1
execute if block ~ ~-4 ~ air run scoreboard players set #pb_cave ec.temp 1
execute if block ~ ~-4 ~ cave_air run scoreboard players set #pb_cave ec.temp 1
execute if block ~ ~-5 ~ air run scoreboard players set #pb_cave ec.temp 1
execute if block ~ ~-5 ~ cave_air run scoreboard players set #pb_cave ec.temp 1
execute if block ~ ~-6 ~ air run scoreboard players set #pb_cave ec.temp 1
execute if block ~ ~-6 ~ cave_air run scoreboard players set #pb_cave ec.temp 1
execute if block ~ ~-7 ~ air run scoreboard players set #pb_cave ec.temp 1
execute if block ~ ~-7 ~ cave_air run scoreboard players set #pb_cave ec.temp 1
execute if block ~ ~-8 ~ air run scoreboard players set #pb_cave ec.temp 1
execute if block ~ ~-8 ~ cave_air run scoreboard players set #pb_cave ec.temp 1

# Readout: depth line, plus the cave-below hint when a pocket is detected.
execute store result storage evercraft:pr_temp depth int 1 run scoreboard players get #pb_depth ec.temp
execute if score #pb_cave ec.temp matches 0 run function evercraft:artifacts/accessories/prospector/plumb_show_nocave with storage evercraft:pr_temp
execute if score #pb_cave ec.temp matches 1 run function evercraft:artifacts/accessories/prospector/plumb_show_cave with storage evercraft:pr_temp
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.amethyst_block.chime player @s ~ ~ ~ 0.4 0.9
