# Warden Totem — Mob Vision Activation (sneak + mainhand)
# Exquisite: 48 blocks all entities, 15s glow, 45s cooldown (900 ticks)

# Check cooldown
data modify storage evercraft:notify stage.c set value [{text:"Recharging... ",color:"gray"},{text:"(",color:"dark_gray"},{score:{name:"@s",objective:"ec.wtotem_cd"},color:"dark_gray"},{text:" ticks)",color:"dark_gray"}]
scoreboard players set #ndur ec.temp 45
execute if score @s ec.wtotem_cd matches 1.. run function evercraft:util/notify/emit
execute if score @s ec.wtotem_cd matches 1.. run return 0

# Apply glowing to all non-player entities within 48 blocks for 15s
execute at @s run effect give @e[type=!player,distance=..48] glowing 15 0 false

# Set cooldown
scoreboard players set @s ec.wtotem_cd 45

# Feedback
data modify storage evercraft:notify stage.c set value [{text:"Sculk Sense activated! ",color:"dark_aqua"},{text:"(15s)",color:"gray"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute at @s run particle sculk_soul ~ ~1 ~ 2 2 2 0.02 10
execute at @s if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bass player @s ~ ~ ~ 0.7 0.5
