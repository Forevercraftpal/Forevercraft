# === MASTER SMITH'S CRYSTAL (C16) — DOUBLE-LOG GIVE (MACRO) (Family G, art-G) ===
# Call (MACRO): function evercraft:artifacts/accessories/forge/crystal_give_log
#               with storage evercraft:forge_temp
#   $(log_id) = the dropped log's item id (e.g. "minecraft:oak_log"), copied by crystal_double_log
#               from the nearest fresh log drop.
# Run as @s = player. Gives one duplicate of the just-broken log (the double-LOG yield half of the
# FORTUNE-REWRITE). Species-exact (the id is read from the actual drop). The caller already rolled
# the win, so this unconditionally gives +1.

$give @s $(log_id) 1
