# === FORESTER'S TALLY (C4) — DOUBLE-LOG GIVE (MACRO) (Family K Prospector, art-K) ===
# Call (MACRO): function evercraft:artifacts/accessories/foresters_give_log
#               with storage evercraft:forge_temp
#   $(ftally_log_id) = the dropped log's item id (e.g. "minecraft:oak_log"), copied by
#               foresters_double_log from the nearest fresh log drop.
# Run as @s = player. Gives one duplicate of the just-broken log (the double-LOG yield half of the
# FORTUNE-REWRITE). Species-exact (the id is read from the actual drop). The caller already rolled the
# win, so this unconditionally gives +1. Distinct subkey from crystal_give_log's log_id (no collision).

$give @s $(ftally_log_id) 1
