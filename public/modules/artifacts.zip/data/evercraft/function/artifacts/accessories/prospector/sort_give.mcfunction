# U21 Loadmaster's Sortstone — regive collapsed total (MACRO) (Family K Prospector — art-K)
# Call: function evercraft:artifacts/accessories/prospector/sort_give with storage evercraft:pr_temp
#   $(sort_item) = the material id (e.g. "minecraft:cobblestone"), staged by sort_one.
#   $(sort_n)    = the counted total to regive, staged by sort_one.
# Run as @s = player. Gives back the full counted total in one `give` (vanilla auto-stacks to the
# material's max stack size -> collapsed into the fewest stacks). The caller already cleared the loose
# partial stacks, so this re-materializes them merged. NBT-free curated materials only (no components to
# preserve). If the player's inventory is now too full to hold the regive, vanilla drops the overflow at
# the player's feet (no loss).
$give @s $(sort_item) $(sort_n)
