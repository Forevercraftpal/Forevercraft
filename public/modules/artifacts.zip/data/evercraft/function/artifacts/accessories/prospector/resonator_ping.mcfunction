# U19 Spelunker's Resonator (Family K Prospector — art-K) — locate-structure bearing + cavity pulse
# Run as @s = player, at @s. Sneak-triggered on-demand (gate at the call site). UTILITY-FEASIBILITY
# RESCOPE: a 48 b structure-wall + cavern outline = a ~900k-cell volume scan (infeasible) and blocks
# can't glow. So the wall-OUTLINE promise is DROPPED; the salvage is (a) the VANILLA `locate structure`
# long-range bearing ping (cheap — the structure_ping idiom) + (b) a tiny LOCAL cavity ray-pulse (the
# echo_pulse rays, reused) for the immediate spelunking cue. NO volume scan, NO block-glow. Debounced
# by ec.pr_pingcd (60t = 3s — slightly longer, this is the heaviest of the K sense items at locate +
# 8 rays, still all bounded).

# Cooldown gate (debounce). If still recharging, show a quiet recharging line and bail.
# Wave 1 (2026-06-10): the recharging line yields to the notify queue (ab_q); the bail is unchanged.
execute if score @s ec.pr_pingcd matches 1.. unless entity @s[tag=ab_q] run title @s actionbar [{text:"◎ Resonator recharging...",color:"gray"}]
execute if score @s ec.pr_pingcd matches 1.. run return 0
scoreboard players set @s ec.pr_pingcd 60

# Long-range bearing: nearest structures via vanilla `locate` (dimension-aware), printed to chat.
tellraw @s [{text:"◎ ",color:"light_purple"},{text:"Resonator ",color:"light_purple",bold:true},{text:"— nearest ruins:",color:"gray"}]
execute in minecraft:overworld run locate structure minecraft:stronghold
execute in minecraft:overworld run locate structure minecraft:trial_chambers
execute in minecraft:overworld run locate structure minecraft:mineshaft
execute in minecraft:overworld run locate structure minecraft:ancient_city
execute in minecraft:overworld run locate structure minecraft:monument
execute in minecraft:the_nether run locate structure minecraft:fortress
execute in minecraft:the_nether run locate structure minecraft:bastion_remnant
execute in minecraft:the_end run locate structure minecraft:end_city

# Local cavity pulse: reuse the echo_pulse bounded rays for the immediate "open space nearby" cue.
# (echo_pulse self-debounces on ec.pr_pingcd — but we just set it, so skip its own gate by calling the
# cast rays directly through a tiny inline wrapper. To stay simple + idempotent, fire the same 8 casts.)
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.sculk_sensor.clicking player @s ~ ~ ~ 0.7 1.0
particle minecraft:sculk_soul ~ ~1 ~ 0.2 0.2 0.2 0.0 6 force @s
execute positioned ~ ~1 ~ rotated 90 0 run function evercraft:artifacts/accessories/prospector/echo_cast
execute positioned ~ ~1 ~ rotated -90 0 run function evercraft:artifacts/accessories/prospector/echo_cast
execute positioned ~ ~1 ~ rotated 0 0 run function evercraft:artifacts/accessories/prospector/echo_cast
execute positioned ~ ~1 ~ rotated 180 0 run function evercraft:artifacts/accessories/prospector/echo_cast
