# U21 Loadmaster's Sortstone — collapse one material id (MACRO) (Family K Prospector — art-K)
# Call: function evercraft:artifacts/accessories/prospector/sort_one {item:"minecraft:cobblestone"}
# Run as @s = player. Counts how many of $(item) the player holds (clear with maxCount 0 = count-only,
# no removal). If >1 (worth collapsing — a single stack is already tidy / a no-op), clear ALL of it then
# regive the counted total in collapsed stacks (vanilla `give` auto-stacks to max). Only the curated,
# NBT-FREE materials in sort_pulse's list reach here, so this NEVER touches tools/gear/components. The
# count is staged in storage so the regive macro can read it; the collapse marks #sort_freed for the
# feedback line. NOTE: this is the count/clear/regive cycle the RESCOPE accepts (it reorders the
# collapsed material to the first free slot — the flagged DROP-candidate UX cost).

# Count-only (maxCount 0 removes nothing, returns the count via store result).
$execute store result score #sort_n ec.temp run clear @s $(item) 0

# Only collapse when there's more than one (a partial-stack situation worth merging).
execute if score #sort_n ec.temp matches 2.. run scoreboard players set #sort_freed ec.temp 1
$execute if score #sort_n ec.temp matches 2.. run clear @s $(item)
execute if score #sort_n ec.temp matches 2.. store result storage evercraft:pr_temp sort_n int 1 run scoreboard players get #sort_n ec.temp
$execute if score #sort_n ec.temp matches 2.. run data modify storage evercraft:pr_temp sort_item set value "$(item)"
execute if score #sort_n ec.temp matches 2.. run function evercraft:artifacts/accessories/prospector/sort_give with storage evercraft:pr_temp
