# Wayfarer — Depth Action-bar Readout (U24 Omni-Codex)
# Run as @s = player, at @s. Sneak-triggered on-demand (gate at the call site). Reads Y, reports
# blocks-to-bedrock (Y - (-64)) + a coarse depth band. Pure read + one subtraction; no scan.
execute store result score @s ec.wf_y run data get entity @s Pos[1] 1
scoreboard players operation @s ec.wf_depth = @s ec.wf_y
scoreboard players add @s ec.wf_depth 64
execute if score @s ec.wf_y matches 64.. unless entity @s[tag=ab_q] run title @s actionbar [{"text":"⛏ Depth: ","color":"yellow"},{"text":"Surface","color":"green"},{"text":"  Y ","color":"gray"},{"score":{"name":"@s","objective":"ec.wf_y"},"color":"white"}]
execute if score @s ec.wf_y matches 0..63 unless entity @s[tag=ab_q] run title @s actionbar [{"text":"⛏ Depth: ","color":"yellow"},{"text":"Shallow","color":"green"},{"text":"  ","color":"gray"},{"score":{"name":"@s","objective":"ec.wf_depth"},"color":"white"},{"text":"m to bedrock","color":"gray"}]
execute if score @s ec.wf_y matches -32..-1 unless entity @s[tag=ab_q] run title @s actionbar [{"text":"⛏ Depth: ","color":"yellow"},{"text":"Deep","color":"gold"},{"text":"  ","color":"gray"},{"score":{"name":"@s","objective":"ec.wf_depth"},"color":"white"},{"text":"m to bedrock","color":"gray"}]
execute if score @s ec.wf_y matches ..-33 unless entity @s[tag=ab_q] run title @s actionbar [{"text":"⛏ Depth: ","color":"yellow"},{"text":"Deepslate","color":"red"},{"text":"  ","color":"gray"},{"score":{"name":"@s","objective":"ec.wf_depth"},"color":"white"},{"text":"m to bedrock","color":"gray"}]
