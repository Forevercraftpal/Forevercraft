# U12 Pathfinder's Astrolabe (Family K Prospector — art-K) — craft-node proximity cue
# Run as @s = player, at @s (positioned by the caller in player_tick). Read-only SENSE (mirrors the
# U15 Tidefinder ping idiom): surfaces whether a craft-node marker (ec.cf_node_data, placed by
# craftforever/nodes/place_node) is within ~100 blocks — the "near a craft-node?" cue
# (EXPANSION-IDEAS U12). No odds touched, no scan (one @e existence test). No DR, no extra roll.
#
# EDGE-TRIGGER + SOFT RE-PING (Wave 1, Joseph 2026-06-10 — was an UNGATED 1s repaint stomping the
# notify queue): ping ONCE on first sense (emit_now + #nttl so it never shows stale), then quiet
# for ~10 loop passes (~10s; ec.ping_al, units = passes of the 1s accessories loop, NOT ticks).
# Cooldown decays every pass including out-of-range — fresh encounters ping promptly, range-edge
# bouncing can't flicker-spam. Sole writer of ec.ping_al: this function.
execute if score @s ec.ping_al matches 1.. run scoreboard players remove @s ec.ping_al 1
execute unless entity @e[type=marker,tag=ec.cf_node_data,distance=..100,limit=1] run return 0
execute if score @s ec.ping_al matches 1.. run return 0
data modify storage evercraft:notify stage.c set value [{text:"◈ ",color:"gold"},{text:"Astrolabe: ",color:"#FFD27F"},{text:"a craft-node is near",color:"gray"}]
scoreboard players set #ndur ec.temp 35
scoreboard players set #nttl ec.temp 100
function evercraft:util/notify/emit_now
scoreboard players set @s ec.ping_al 10
