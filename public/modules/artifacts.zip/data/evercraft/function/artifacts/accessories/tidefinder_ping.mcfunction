# Tidefinder's Astrolite (U15, Family J — art-J) — splash-node proximity cue
# Run as @s = player, at @s (positioned by the caller in player_tick). Read-only SENSE (NOT an extra
# roll — Angler's Pearl owns Lure/LotS; this is a datapack-native cue, no resource pack). Surfaces
# whether a fishing splash-node (the markers tagged ec.splash_data, placed by
# fishing/splash_nodes/place_node) is within ~48 blocks — the "nearest open-water fishing spot" cue.
# The small +0.15 submerged_mining_speed lives in player_tick as an attribute modifier.
#
# EDGE-TRIGGER + SOFT RE-PING (Wave 1, Joseph 2026-06-10 — was an UNGATED 1s repaint, the pack's
# worst queue-stomper): ping ONCE when a node is first sensed (emit_now — jumps the queue; #nttl
# kills it if it would show stale), then stay quiet for ~10 loop passes (~10s; ec.ping_tf, units =
# passes of the 1s accessories loop, NOT ticks). The cooldown decays every pass — also while OUT
# of range — so a fresh encounter ≥10s later pings promptly, while bouncing on the range edge
# can't flicker-spam. Sole writer of ec.ping_tf: this function (the accessories 1s loop chain).
execute if score @s ec.ping_tf matches 1.. run scoreboard players remove @s ec.ping_tf 1
execute unless entity @e[type=marker,tag=ec.splash_data,distance=..48,limit=1] run return 0
execute if score @s ec.ping_tf matches 1.. run return 0
data modify storage evercraft:notify stage.c set value [{text:"◈ ",color:"aqua"},{text:"Tidefinder: ",color:"#87CEEB"},{text:"a splash-node ripples nearby",color:"gray"}]
scoreboard players set #ndur ec.temp 35
scoreboard players set #nttl ec.temp 100
function evercraft:util/notify/emit_now
scoreboard players set @s ec.ping_tf 10
