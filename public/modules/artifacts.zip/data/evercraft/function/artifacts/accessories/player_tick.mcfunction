# Accessory Artifacts — Per-Player Tick
# Runs as @s = player, at @s (position set by caller)
# Checks container.* (all inventory + hotbar slots) + weapon.offhand for accessory effects
# OPT: Multi-effect accessories use temp tag ec._a to consolidate item scans
# (reduces ~196 item scans to ~68 per player per second)

# OPT: Early exit for players with no accessories, rings, or boss-exclusives
# ec.has_accessory persists 1 extra tick to allow attribute modifier cleanup
# (2026-06-06) Worn ARTIFACT-armor abilities were SPLIT OUT into accessories/tick's own lightweight @a
# dispatch (-> worn_tick_player), gated on armor.* is_artifact:true OR ec.has_worn_armor. So an armor-ONLY
# player (no accessory/ring/boss) no longer needs to pass this gate — they get their armor abilities from
# the separate tick and correctly early-exit here, skipping the ~474-line accessory scan. The earlier
# `unless items @s armor.* is_artifact:true` clause + its has_accessory armor-tag line were reverted.
execute unless entity @s[tag=ec.has_accessory] unless items entity @s container.* *[custom_data~{accessory:true}] unless items entity @s weapon.offhand *[custom_data~{accessory:true}] unless items entity @s container.* *[custom_data~{ring:true}] unless items entity @s weapon.offhand *[custom_data~{ring:true}] unless items entity @s container.* *[custom_data~{boss_exclusive:true}] unless items entity @s weapon.offhand *[custom_data~{boss_exclusive:true}] run return 0

# ============================================================
# === ACCESSORY DODGE LANE — RE-SUM (D-DODGE, m1) ===
# ============================================================
# ec.acc_dodge is a NEW additive dodge-points lane (1% = 4 pts; 0.25%/pt), DISTINCT from the
# Dancer's single-writer ec.dn_evasion_add so accessories STACK. Re-summed from scratch every
# tick (clear-on-removal idiom): zero here, then each held dodge accessory ADDS its points in the
# leaf-accumulation block below. Because ec.has_accessory persists one extra tick after the last
# accessory leaves (same window the band_luck/hand strips rely on), a player who drops their last
# dodge piece runs this reset one final time with nothing to re-add, so the lane correctly lands
# at 0 — then the next tick they early-exit above with it already 0. Wired into TWO consumers:
#   (1) advantage/tick/evasion_check  — #chance += ec.acc_dodge
#   (2) advantage/dodge_eligible predicate — OR ec.acc_dodge >= 1 (accessory-only build still snapshots)
scoreboard players set @s ec.acc_dodge 0
# >>> LEAF DODGE-POINT ADDS GO HERE (units C/D/L). Each held dodge accessory appends one line:
# >>>   execute if items entity @s container.* *[custom_data~{artifact:"<id>"}] run scoreboard players add @s ec.acc_dodge 4
# >>>   execute if items entity @s weapon.offhand  *[custom_data~{artifact:"<id>"}] run scoreboard players add @s ec.acc_dodge 4
# >>> (+4 = 1% for the nimble pieces; +40 = 10% for the ONE final-form, Soulguard Aegis.)
# --- Family C (Wayfarer, art-C) — the two agile existing pieces in the +4 set (D-DODGE: the
#     nimble/dodgy-flavored accessories each get a small ~1% = +4). Travelers Charm + Wind Chime are
#     the speed charms; their +4 STACKS additively via this re-summed lane (id-presence gate, not
#     per-copy count -> two copies add once = m4 Layer-2 multi-copy-safe). Honor each charm's existing
#     toggle so a player who toggled the speed perk OFF also drops the dodge (lockstep). ---
execute if items entity @s container.* *[custom_data~{artifact:"travelers_charm"}] unless score @s ec.t_traveler matches 1 run scoreboard players add @s ec.acc_dodge 4
execute unless items entity @s container.* *[custom_data~{artifact:"travelers_charm"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"travelers_charm"}] if entity @s[tag=ec.sat_travelers_charm] unless score @s ec.t_traveler matches 1 run scoreboard players add @s ec.acc_dodge 4
execute unless items entity @s container.* *[custom_data~{artifact:"travelers_charm"}] if items entity @s weapon.offhand *[custom_data~{artifact:"travelers_charm"}] unless score @s ec.t_traveler matches 1 run scoreboard players add @s ec.acc_dodge 4
execute if items entity @s container.* *[custom_data~{artifact:"wind_chime"}] unless score @s ec.t_wind matches 1 run scoreboard players add @s ec.acc_dodge 4
execute unless items entity @s container.* *[custom_data~{artifact:"wind_chime"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"wind_chime"}] if entity @s[tag=ec.sat_wind_chime] unless score @s ec.t_wind matches 1 run scoreboard players add @s ec.acc_dodge 4
execute unless items entity @s container.* *[custom_data~{artifact:"wind_chime"}] if items entity @s weapon.offhand *[custom_data~{artifact:"wind_chime"}] unless score @s ec.t_wind matches 1 run scoreboard players add @s ec.acc_dodge 4
# --- Family C consolidation (cap-C) — the Wanderer's Token + the grand Wayfarer's Lens each ABSORB the
#     Traveler's Charm + Wind Chime (the two agile members), so they re-grant the SAME +8 those two
#     would have contributed loose (+4 each), balance-neutral. NOT a NEW dodge perk for the bundle:
#     Open-Decision 4 routed the big +40/10% dodge to Soulguard Aegis, so the Wayfarer line carries
#     ONLY the member-level +1% it absorbs — no more. id-presence gate (not per-copy -> two copies add
#     once = m4 Layer-2 multi-copy-safe). The grand supersedes the Token (a fused player holds the Lens,
#     not the Token), so a player never holds both; both gates fire independently and each grants +8 if
#     held, which is the absorbed member sum — never double on the same player in practice. ---
execute if items entity @s container.* *[custom_data~{wanderers_token:true}] run scoreboard players add @s ec.acc_dodge 8
execute unless items entity @s container.* *[custom_data~{wanderers_token:true}] unless items entity @s weapon.offhand *[custom_data~{wanderers_token:true}] if entity @s[tag=ec.sat_wanderers_token] run scoreboard players add @s ec.acc_dodge 8
execute unless items entity @s container.* *[custom_data~{wanderers_token:true}] if items entity @s weapon.offhand *[custom_data~{wanderers_token:true}] run scoreboard players add @s ec.acc_dodge 8
execute if items entity @s container.* *[custom_data~{wayfarers_lens:true}] run scoreboard players add @s ec.acc_dodge 8
execute unless items entity @s container.* *[custom_data~{wayfarers_lens:true}] unless items entity @s weapon.offhand *[custom_data~{wayfarers_lens:true}] if entity @s[tag=ec.sat_wayfarers_lens] run scoreboard players add @s ec.acc_dodge 8
execute unless items entity @s container.* *[custom_data~{wayfarers_lens:true}] if items entity @s weapon.offhand *[custom_data~{wayfarers_lens:true}] run scoreboard players add @s ec.acc_dodge 8
# --- Family D (Soulguard, art-D) — the two nimble/defensive pieces in the +4 set (D-DODGE: the
#     dodgy-flavored defensive accessories each get a small ~1% = +4). Phantom Charm (slow-fall/glide
#     defensive) + Berserker's Fang (low-HP aggro charm) are the agile defensive leaves. Their +4
#     STACKS additively via this re-summed lane (id-presence gate, not per-copy count -> two copies add
#     once = m4 Layer-2 multi-copy-safe). Phantom Charm honors its existing ec.t_phantom toggle so a
#     player who toggled the slow-fall perk OFF also drops the dodge (lockstep, like travelers_charm
#     above). Berserker's Fang has no toggle, so its +4 is ungated. The big +40 (10%) dodge is the ONE
#     final-form Soulguard Aegis (built in cap-D), NOT a leaf — do NOT add it here. ---
execute if items entity @s container.* *[custom_data~{artifact:"phantom_charm"}] unless score @s ec.t_phantom matches 1 run scoreboard players add @s ec.acc_dodge 4
execute unless items entity @s container.* *[custom_data~{artifact:"phantom_charm"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"phantom_charm"}] if entity @s[tag=ec.sat_phantom_charm] unless score @s ec.t_phantom matches 1 run scoreboard players add @s ec.acc_dodge 4
execute unless items entity @s container.* *[custom_data~{artifact:"phantom_charm"}] if items entity @s weapon.offhand *[custom_data~{artifact:"phantom_charm"}] unless score @s ec.t_phantom matches 1 run scoreboard players add @s ec.acc_dodge 4
execute if items entity @s container.* *[custom_data~{artifact:"berserkers_fang"}] run scoreboard players add @s ec.acc_dodge 4
execute unless items entity @s container.* *[custom_data~{artifact:"berserkers_fang"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"berserkers_fang"}] if entity @s[tag=ec.sat_berserkers_fang] run scoreboard players add @s ec.acc_dodge 4
execute unless items entity @s container.* *[custom_data~{artifact:"berserkers_fang"}] if items entity @s weapon.offhand *[custom_data~{artifact:"berserkers_fang"}] run scoreboard players add @s ec.acc_dodge 4
# --- Family F builder/traversal-QoL leaves (art-F) — the three AGILE/traversal pieces in the +4 set
#     (D-DODGE: nimble-flavored builder/traversal leaves each get a small ~1% = +4). U2 Sure-Step Pebble
#     (auto-step), B9 Wayfarer's Greaves (step + soft-land), U18 Featherfall Glider-Knot (glide). Each
#     +4 STACKS additively via this re-summed lane (id-presence gate, not per-copy count -> two copies
#     add once = m4 Layer-2 multi-copy-safe). None of the three has a toggle objective, so all are
#     ungated (always-on while held), exactly like berserkers_fang above. The other 4 F-adjacent leaves
#     (masons_long_arm_band, builders_loftstride, surveyors_reach_glass, steady_hand_caliper) are
#     reach/ghost builder QoL — NOT nimble — so they correctly carry NO dodge. ---
execute if items entity @s container.* *[custom_data~{artifact:"sure_step_pebble"}] run scoreboard players add @s ec.acc_dodge 4
execute unless items entity @s container.* *[custom_data~{artifact:"sure_step_pebble"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"sure_step_pebble"}] if entity @s[tag=ec.sat_sure_step_pebble] run scoreboard players add @s ec.acc_dodge 4
execute unless items entity @s container.* *[custom_data~{artifact:"sure_step_pebble"}] if items entity @s weapon.offhand *[custom_data~{artifact:"sure_step_pebble"}] run scoreboard players add @s ec.acc_dodge 4
execute if items entity @s container.* *[custom_data~{artifact:"wayfarers_greaves"}] run scoreboard players add @s ec.acc_dodge 4
execute unless items entity @s container.* *[custom_data~{artifact:"wayfarers_greaves"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"wayfarers_greaves"}] if entity @s[tag=ec.sat_wayfarers_greaves] run scoreboard players add @s ec.acc_dodge 4
execute unless items entity @s container.* *[custom_data~{artifact:"wayfarers_greaves"}] if items entity @s weapon.offhand *[custom_data~{artifact:"wayfarers_greaves"}] run scoreboard players add @s ec.acc_dodge 4
execute if items entity @s container.* *[custom_data~{artifact:"featherfall_glider_knot"}] run scoreboard players add @s ec.acc_dodge 4
execute unless items entity @s container.* *[custom_data~{artifact:"featherfall_glider_knot"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"featherfall_glider_knot"}] if entity @s[tag=ec.sat_featherfall_glider_knot] run scoreboard players add @s ec.acc_dodge 4
execute unless items entity @s container.* *[custom_data~{artifact:"featherfall_glider_knot"}] if items entity @s weapon.offhand *[custom_data~{artifact:"featherfall_glider_knot"}] run scoreboard players add @s ec.acc_dodge 4
# --- Family L Vanguard agile leaves (art-L) — the two NEW nimble combat pieces in the +4 set
#     (D-DODGE: B5 Sprinter's Anklet + B6 Reaver's Knuckle each get ~1% = +4). B9 Wayfarer's Greaves +
#     U2 Sure-Step (also L Stride) already have their +4 in the Family F block above (art-F), so they are
#     NOT re-added here (one +4 each, no double-add). Neither B5 nor B6 has a toggle objective, so both
#     are ungated (always-on while held), exactly like berserkers_fang. id-presence gate (not per-copy
#     count) -> two copies add once = m4 Layer-2 multi-copy-safe. ---
execute if items entity @s container.* *[custom_data~{artifact:"sprinters_anklet"}] run scoreboard players add @s ec.acc_dodge 4
execute unless items entity @s container.* *[custom_data~{artifact:"sprinters_anklet"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"sprinters_anklet"}] if entity @s[tag=ec.sat_sprinters_anklet] run scoreboard players add @s ec.acc_dodge 4
execute unless items entity @s container.* *[custom_data~{artifact:"sprinters_anklet"}] if items entity @s weapon.offhand *[custom_data~{artifact:"sprinters_anklet"}] run scoreboard players add @s ec.acc_dodge 4
execute if items entity @s container.* *[custom_data~{artifact:"reavers_knuckle"}] run scoreboard players add @s ec.acc_dodge 4
execute unless items entity @s container.* *[custom_data~{artifact:"reavers_knuckle"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"reavers_knuckle"}] if entity @s[tag=ec.sat_reavers_knuckle] run scoreboard players add @s ec.acc_dodge 4
execute unless items entity @s container.* *[custom_data~{artifact:"reavers_knuckle"}] if items entity @s weapon.offhand *[custom_data~{artifact:"reavers_knuckle"}] run scoreboard players add @s ec.acc_dodge 4
# --- Family M Dragonheart dodge spread (art-M, D-DODGE §2: rows 1, 8, 9, 10, 14 at +4 + the Mythical seed
#     at +8). The FOUR NEW agile/winged leaves each carry +4: Wyrmwing Membrane (slow-fall glide) +
#     Stormrider Pinion (airborne dash) + Featherscale Down (soft-land) + Breath-Gland Sac (the agile breath
#     leaf) — rows 8/9/10/14 of the D-DODGE leaf set. The two SEEDS carry the rest of the spread (Dragon's
#     Tear +4 = row 1, Ender Dragon Scale +8 = row 16); their dodge is wired HERE (a pure additive
#     dodge-lane add — the seeds' own perk blocks/loot are untouched, the "don't alter the seeds beyond what
#     the spec says to add" carve-out, since D-DODGE §2 assigns them this dodge explicitly). Each add is an
#     id-presence gate (not per-copy count -> two copies add once = m4 Layer-2 multi-copy-safe), ungated by
#     toggle (always-on while held, like berserkers_fang). The +40 (10%) lives on the family's OWN
#     final-form Wyrmscale Aegis (cap-M), NOT a leaf and NOT a seed — do NOT add it here. ---
execute if items entity @s container.* *[custom_data~{artifact:"wyrmwing_membrane"}] run scoreboard players add @s ec.acc_dodge 4
execute unless items entity @s container.* *[custom_data~{artifact:"wyrmwing_membrane"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"wyrmwing_membrane"}] if entity @s[tag=ec.sat_wyrmwing_membrane] run scoreboard players add @s ec.acc_dodge 4
execute unless items entity @s container.* *[custom_data~{artifact:"wyrmwing_membrane"}] if items entity @s weapon.offhand *[custom_data~{artifact:"wyrmwing_membrane"}] run scoreboard players add @s ec.acc_dodge 4
execute if items entity @s container.* *[custom_data~{artifact:"stormrider_pinion"}] run scoreboard players add @s ec.acc_dodge 4
execute unless items entity @s container.* *[custom_data~{artifact:"stormrider_pinion"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"stormrider_pinion"}] if entity @s[tag=ec.sat_stormrider_pinion] run scoreboard players add @s ec.acc_dodge 4
execute unless items entity @s container.* *[custom_data~{artifact:"stormrider_pinion"}] if items entity @s weapon.offhand *[custom_data~{artifact:"stormrider_pinion"}] run scoreboard players add @s ec.acc_dodge 4
execute if items entity @s container.* *[custom_data~{artifact:"featherscale_down"}] run scoreboard players add @s ec.acc_dodge 4
execute unless items entity @s container.* *[custom_data~{artifact:"featherscale_down"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"featherscale_down"}] if entity @s[tag=ec.sat_featherscale_down] run scoreboard players add @s ec.acc_dodge 4
execute unless items entity @s container.* *[custom_data~{artifact:"featherscale_down"}] if items entity @s weapon.offhand *[custom_data~{artifact:"featherscale_down"}] run scoreboard players add @s ec.acc_dodge 4
execute if items entity @s container.* *[custom_data~{artifact:"breathgland_sac"}] run scoreboard players add @s ec.acc_dodge 4
execute unless items entity @s container.* *[custom_data~{artifact:"breathgland_sac"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"breathgland_sac"}] if entity @s[tag=ec.sat_breathgland_sac] run scoreboard players add @s ec.acc_dodge 4
execute unless items entity @s container.* *[custom_data~{artifact:"breathgland_sac"}] if items entity @s weapon.offhand *[custom_data~{artifact:"breathgland_sac"}] run scoreboard players add @s ec.acc_dodge 4
# The two seeds (row 1 Dragon's Tear +4 · row 16 Ender Dragon Scale +8) — additive dodge-lane adds only.
execute if items entity @s container.* *[custom_data~{artifact:"dragons_tear"}] run scoreboard players add @s ec.acc_dodge 4
execute unless items entity @s container.* *[custom_data~{artifact:"dragons_tear"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"dragons_tear"}] if entity @s[tag=ec.sat_dragons_tear] run scoreboard players add @s ec.acc_dodge 4
execute unless items entity @s container.* *[custom_data~{artifact:"dragons_tear"}] if items entity @s weapon.offhand *[custom_data~{artifact:"dragons_tear"}] run scoreboard players add @s ec.acc_dodge 4
execute if items entity @s container.* *[custom_data~{artifact:"ender_dragon_scale"}] run scoreboard players add @s ec.acc_dodge 8
execute unless items entity @s container.* *[custom_data~{artifact:"ender_dragon_scale"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"ender_dragon_scale"}] if entity @s[tag=ec.sat_ender_dragon_scale] run scoreboard players add @s ec.acc_dodge 8
execute unless items entity @s container.* *[custom_data~{artifact:"ender_dragon_scale"}] if items entity @s weapon.offhand *[custom_data~{artifact:"ender_dragon_scale"}] run scoreboard players add @s ec.acc_dodge 8
# --- SOULGUARD AEGIS — THE ONE +40 (10%) DODGE (cap-D, Open-Decision 4 + D-DODGE 430-432). The grand
#     Soulguard Aegis is THE single final-form in the whole pack that grants the big +40 (10%) dodge via
#     this m1 ec.acc_dodge lane (the "avoid the hit" headline of the defensive bundle). NO leaf and NO
#     other capstone gets +40 — this is the sole +40 in the pack. The absorbed agile members (Phantom
#     Charm + Berserker's Fang, +4 each = +8) are NOT separately re-added: the +40 is the bundle's whole
#     dodge headline (it supersedes, not sums with, the absorbed +8 — the loose pieces are consumed by
#     the fusion). id-presence gate (container.* OR offhand), not per-copy count -> two copies of the
#     Aegis add +40 ONCE = m4 Layer-2 multi-copy-safe. Ungated by toggle/difficulty (a dodge add, like
#     every other line in this block). ---
execute if items entity @s container.* *[custom_data~{soulguard_aegis:true}] run scoreboard players add @s ec.acc_dodge 40
execute unless items entity @s container.* *[custom_data~{soulguard_aegis:true}] unless items entity @s weapon.offhand *[custom_data~{soulguard_aegis:true}] if entity @s[tag=ec.sat_soulguard_aegis] run scoreboard players add @s ec.acc_dodge 40
execute unless items entity @s container.* *[custom_data~{soulguard_aegis:true}] if items entity @s weapon.offhand *[custom_data~{soulguard_aegis:true}] run scoreboard players add @s ec.acc_dodge 40
# --- WYRMSCALE AEGIS — THE DRAGONHEART FAMILY'S OWN +40 (10%) DODGE FINAL-FORM (cap-M, D-DODGE §4b). The
#     final-form Wyrmscale Aegis (Dragonheart + a Voidscale Shard catalyst) is the Dragonheart family's OWN
#     dodge pinnacle, so the mobility theme pays off. Per the lattice "ONE +40/10% final-form per dodge-heavy
#     family" (Soulguard owns the global one above; Dragonheart's mobility family gets its own). Locked
#     default +40 (10%), additive-stacking per D-DODGE intent (Joseph: "dodge STACKS"). id-presence gate
#     (container.* OR offhand), not per-copy count -> two copies of the Aegis add +40 ONCE = m4 Layer-2
#     multi-copy-safe. Ungated by toggle/difficulty (a dodge add, like every other line in this block). The
#     absorbed agile wing leaves' +4 (Membrane/Pinion/Down) are NOT separately re-added: the +40 is the
#     final-form's whole dodge headline (it supersedes, not sums with, the consumed leaves). NO leaf and NO
#     other capstone gets +40 here — the grand Dragonheart does NOT (only the Aegis final-form does). ---
execute if items entity @s container.* *[custom_data~{wyrmscale_aegis:true}] run scoreboard players add @s ec.acc_dodge 40
execute unless items entity @s container.* *[custom_data~{wyrmscale_aegis:true}] unless items entity @s weapon.offhand *[custom_data~{wyrmscale_aegis:true}] if entity @s[tag=ec.sat_wyrmscale_aegis] run scoreboard players add @s ec.acc_dodge 40
execute unless items entity @s container.* *[custom_data~{wyrmscale_aegis:true}] if items entity @s weapon.offhand *[custom_data~{wyrmscale_aegis:true}] run scoreboard players add @s ec.acc_dodge 40

# ============================================================
# === TINKERING — CONSOLIDATED FUSION BLOCK (Chronicles Wave C7, S13) ===
# ============================================================
# ONE additive block for ALL Tinkering fusion concerns, placed BEHIND the ec.has_accessory
# early-exit above (so players with no accessory paid ZERO and never reach this). S13 mandates
# that all fusion perk-reads (the Trinket Knot now; round-1's Hand/Band re-homed perk-reads
# fold in HERE in Wave C8) live in ONE consolidated block — no new top-level scan. This block
# reuses the file's existing accessory presence (we are already past the early-exit, so the
# player holds at least one accessory/ring/boss item).
#
# (a) TRINKET KNOT perk re-apply — BALANCE-NEUTRAL union of the Knot's two bound sub-trinkets
#     (DECISIONS #9 / R14). Only runs if the player holds a tinker_knot:true item; cheap-gate
#     first so a player with accessories-but-no-Knot pays one extra `if items` test, no more.
execute if items entity @s container.* *[custom_data~{tinker_knot:true}] run function evercraft:tinkering/knot_apply
execute unless items entity @s container.* *[custom_data~{tinker_knot:true}] if items entity @s weapon.offhand *[custom_data~{tinker_knot:true}] run function evercraft:tinkering/knot_apply
#
# (a2) HAND OF CREATION perk re-apply (round-1 Wave 7, re-homed onto the Plinth — C7/S11/T2).
#     BALANCE-NEUTRAL union of the six builder parts' held effects (R14 / DECISIONS #9): the
#     Hand only frees five slots. Cheap-gate first so a player with accessories-but-no-Hand pays
#     one extra `if items` test, no more. This perk-read lives in THIS consolidated block per
#     S13 (no new top-level scan).
execute if items entity @s container.* *[custom_data~{hand_of_creation:true}] run function evercraft:hand_of_creation/hand_apply
execute unless items entity @s container.* *[custom_data~{hand_of_creation:true}] if items entity @s weapon.offhand *[custom_data~{hand_of_creation:true}] run function evercraft:hand_of_creation/hand_apply
# Cleanup: strip the Hand's two distinct attribute modifiers the moment it leaves the inventory
# (the night_vision/slow_falling/haste/saturation effects are short-duration and self-expire;
# only the reach + luck attribute modifiers need explicit removal so they never linger).
execute unless items entity @s container.* *[custom_data~{hand_of_creation:true}] unless items entity @s weapon.offhand *[custom_data~{hand_of_creation:true}] run attribute @s block_interaction_range modifier remove evercraft:hoc_hand_reach
execute unless items entity @s container.* *[custom_data~{hand_of_creation:true}] unless items entity @s weapon.offhand *[custom_data~{hand_of_creation:true}] run attribute @s luck modifier remove evercraft:hoc_hand_luck
#
# === Hand-of-Creation LOOSE PARTS — per-part "while held" effect (2026-06-05 lore-vs-behavior audit fix) ===
# Each of the six builder parts (loot_table/hand_of_creation/parts/*) promises a "While held…" effect in
# its lore, but `build_part` was wired into ZERO handlers — Joseph's "Part of Reach" granted no reach. This
# restores the DOCUMENTED intent (see hand_apply.mcfunction header: "each of the six parts already granted
# its single effect while held; the Hand merely keeps that union in ONE slot — no new power, QoL-only").
# CRITICAL: reach/refund REUSE the Hand's distinct modifier ids (hoc_hand_reach / hoc_hand_luck) so holding
# a loose part AND the fused Hand can never double-stack (fixed-id modifiers; remove-then-add = idempotent).
# This block runs AFTER the reach/luck cleanup above (gated `unless hand_of_creation`): for a loose part
# with no Hand, cleanup strips first, then we re-add here; drop the last part and next tick nothing re-adds,
# so the modifier lands at 0 within the ec.has_accessory 1-extra-tick window. The 4 effect parts self-expire
# (short duration) — no cleanup needed; scaffold/steady/level gate on is_holding_block (same predicate the
# fused Hand uses) so they are strictly building QoL.
# reach -> Builder's Reach (block_interaction_range +1.0)
execute if items entity @s container.* *[custom_data~{build_part:"reach"}] run tag @s add ec._hp_reach
execute if items entity @s weapon.offhand *[custom_data~{build_part:"reach"}] run tag @s add ec._hp_reach
execute if entity @s[tag=ec._hp_reach] run attribute @s block_interaction_range modifier remove evercraft:hoc_hand_reach
execute if entity @s[tag=ec._hp_reach] run attribute @s block_interaction_range modifier add evercraft:hoc_hand_reach 1.0 add_value
tag @s remove ec._hp_reach
# refund -> Fortunate Eye (luck +1.0 = +1 Dream Rate)
execute if items entity @s container.* *[custom_data~{build_part:"refund"}] run tag @s add ec._hp_refund
execute if items entity @s weapon.offhand *[custom_data~{build_part:"refund"}] run tag @s add ec._hp_refund
execute if entity @s[tag=ec._hp_refund] run attribute @s luck modifier remove evercraft:hoc_hand_luck
execute if entity @s[tag=ec._hp_refund] run attribute @s luck modifier add evercraft:hoc_hand_luck 1.0 add_value
tag @s remove ec._hp_refund
# palette -> Artist's Eye (Night Vision, passive while held)
execute if items entity @s container.* *[custom_data~{build_part:"palette"}] run effect give @s night_vision 15 0 false
execute unless items entity @s container.* *[custom_data~{build_part:"palette"}] if items entity @s weapon.offhand *[custom_data~{build_part:"palette"}] run effect give @s night_vision 15 0 false
# scaffold -> Sure Footing (Slow Falling while holding a block)
execute if items entity @s container.* *[custom_data~{build_part:"scaffold"}] if predicate evercraft:is_holding_block run effect give @s slow_falling 5 0 false
execute unless items entity @s container.* *[custom_data~{build_part:"scaffold"}] if items entity @s weapon.offhand *[custom_data~{build_part:"scaffold"}] if predicate evercraft:is_holding_block run effect give @s slow_falling 5 0 false
# steady -> Tireless Mason (Haste I while holding a block)
execute if items entity @s container.* *[custom_data~{build_part:"steady"}] if predicate evercraft:is_holding_block run effect give @s haste 5 0 false
execute unless items entity @s container.* *[custom_data~{build_part:"steady"}] if items entity @s weapon.offhand *[custom_data~{build_part:"steady"}] if predicate evercraft:is_holding_block run effect give @s haste 5 0 false
# level -> Master's Focus (Saturation while building)
execute if items entity @s container.* *[custom_data~{build_part:"level"}] if predicate evercraft:is_holding_block run effect give @s saturation 3 0 false
execute unless items entity @s container.* *[custom_data~{build_part:"level"}] if items entity @s weapon.offhand *[custom_data~{build_part:"level"}] if predicate evercraft:is_holding_block run effect give @s saturation 3 0 false
#
# (a3) BAND OF ALL RINGS perk re-apply (Fusion Wave 1 / Family E — expanded 4 -> 15).
#     BALANCE-NEUTRAL union of ALL FIFTEEN rings' + the two charms' held effects (R14 /
#     DECISIONS #9 — the Band is still a slot-saver: it re-grants exactly the union of the
#     fifteen ring_* perks plus Phantom Charm + Travelers Charm, multiplying NOTHING). The Band
#     now frees FOURTEEN slots. CRITICAL (the balance guarantee): the Band reuses each ring's
#     EXISTING toggle objective and NO new toggle is introduced — but only TWO of the fifteen
#     rings actually have a per-ring toggle today (Aquamarine -> ec.t_dring, Ring of Undying ->
#     ec.t_undying); the other thirteen ring_* apply UNCONDITIONALLY in their own loose lines
#     (565-638), so the Band binds them UNCONDITIONALLY too — matching their loose behavior
#     exactly. Phantom Charm / Travelers Charm keep their loose toggles (ec.t_phantom /
#     ec.t_traveler). Cheap-gate first: a player holding accessories but no Band pays one
#     `if items` test, then skips the whole block.
#
#     DR CONSOLIDATION (Family E light-ascension, blueprint §E + DECISIONS D2): the rings carry
#     +4.0 Dream Rate in total (Aquamarine +1.0, Ring of Undying +1.0, Trial Ring +2.0). The
#     Band folds all three into ONE consolidated modifier evercraft:band_luck = +4.0, instead of
#     the legacy two separate band_dring_luck / band_undying_luck (those are migrated away; the
#     strip-law removes any pre-migration ids). Each DR source still honors its existing toggle:
#     Aqua's +1 drops if ec.t_dring, Undying's +1 drops if ec.t_undying; Trial has no toggle (its
#     loose line at 611-615 is un-gated), so its +2 is always in. The whole +4.0 is gated as one
#     unit only when all three sources are ON (the common case); the per-source removes below
#     handle the toggle-OFF cases so the number is exact.
#
#     The effect lines mirror the rings' own player_tick lines verbatim (same effect/level/
#     duration/ambient flag). Effect-cap rings (Redstone/Diamond/Slime/Nether/Ominous-tier read
#     ec.h_* harmonize scores) keep their `if score @s ec.h_* matches ..1` gate so the Band never
#     double-stacks a harmonizable buff. AoE rings (Bone/Honey weakness/slowness) re-emit their
#     aura. Warden Ring clears Darkness like the loose ring.
# Detect BOTH bands up front (ec._band = full 15-ring · ec._b4 = legacy 4-ring) so the two blocks'
# cleanups can reference each other and never strip each other's active modifier.
tag @s remove ec._band
tag @s remove ec._b4
execute if items entity @s container.* *[custom_data~{band_of_all_rings:true}] run tag @s add ec._band
execute unless items entity @s container.* *[custom_data~{band_of_all_rings:true}] unless items entity @s weapon.offhand *[custom_data~{band_of_all_rings:true}] if entity @s[tag=ec.sat_band_of_all_rings] run tag @s add ec._band
execute unless entity @s[tag=ec._band] if items entity @s weapon.offhand *[custom_data~{band_of_all_rings:true}] run tag @s add ec._band
execute if items entity @s container.* *[custom_data~{band_of_four_rings:true}] run tag @s add ec._b4
execute unless items entity @s container.* *[custom_data~{band_of_four_rings:true}] unless items entity @s weapon.offhand *[custom_data~{band_of_four_rings:true}] if entity @s[tag=ec.sat_band_of_four_rings] run tag @s add ec._b4
execute unless entity @s[tag=ec._b4] if items entity @s weapon.offhand *[custom_data~{band_of_four_rings:true}] run tag @s add ec._b4
# --- Gem tier (5): Amethyst NV / Lapis WaterBreath / Redstone Haste / Diamond Speed / Slime Jump ---
execute if entity @s[tag=ec._band] run effect give @s night_vision 13 0 true
execute if entity @s[tag=ec._band] run effect give @s water_breathing 5 0 true
execute if entity @s[tag=ec._band] if score @s ec.h_haste matches ..1 run effect give @s haste 5 0 true
execute if entity @s[tag=ec._band] if score @s ec.h_speed matches ..1 run effect give @s speed 5 0 true
execute if entity @s[tag=ec._band] if score @s ec.h_jump matches ..1 run effect give @s jump_boost 5 0 true
# --- Effect tier (4): Emerald HeroOfVillage / Bone Weakness aura / Honey Slowness aura / Nether Resist II ---
execute if entity @s[tag=ec._band] run effect give @s hero_of_the_village 5 0 true
execute if entity @s[tag=ec._band] run effect give @e[type=#evercraft:hostile_mobs,distance=..5] weakness 2 0 true
execute if entity @s[tag=ec._band] run effect give @e[type=#evercraft:hostile_mobs,distance=..5] slowness 2 0 true
execute if entity @s[tag=ec._band] if score @s ec.h_resist matches ..1 run effect give @s resistance 5 1 true
# --- Potent tier (4): Ominous HealthBoost II / Warden Str II + Darkness clear / Void Resist II + FireRes + SlowFall / Trial DR (folded into band_luck below) ---
execute if entity @s[tag=ec._band] run effect give @s health_boost 5 1 true
execute if entity @s[tag=ec._band] if score @s ec.h_str matches ..1 run effect give @s strength 5 1 true
execute if entity @s[tag=ec._band] run effect clear @s darkness
execute if entity @s[tag=ec._band] if score @s ec.h_resist matches ..1 run effect give @s resistance 5 1 true
execute if entity @s[tag=ec._band] run effect give @s fire_resistance 5 0 true
execute if entity @s[tag=ec._band] run effect give @s slow_falling 5 0 true
# --- The two charms folded into the Band at round-1 (Phantom / Travelers), toggle-gated as before ---
execute if entity @s[tag=ec._band] unless score @s ec.t_phantom matches 1 run effect give @s slow_falling 5 0 false
execute if entity @s[tag=ec._band] unless score @s ec.t_traveler matches 1 run effect give @s speed 5 0 false
execute if entity @s[tag=ec._band] if items entity @s armor.chest minecraft:elytra run item modify entity @s armor.chest evercraft:repair_elytra
# --- Consolidated +4.0 Dream Rate (Aqua +1 unless ec.t_dring · Undying +1 unless ec.t_undying · Trial +2 always) ---
# ONE modifier evercraft:band_luck. Remove-then-add so the value is exact every tick and toggles
# can shrink it. Both DR rings ON -> +4.0; one OFF -> +3.0; both OFF -> +2.0 (Trial only).
execute if entity @s[tag=ec._band] run attribute @s luck modifier remove evercraft:band_luck
execute if entity @s[tag=ec._band] if score @s ec.t_dring matches 1 if score @s ec.t_undying matches 1 run attribute @s luck modifier add evercraft:band_luck 2.0 add_value
execute if entity @s[tag=ec._band] if score @s ec.t_dring matches 1 unless score @s ec.t_undying matches 1 run attribute @s luck modifier add evercraft:band_luck 3.0 add_value
execute if entity @s[tag=ec._band] unless score @s ec.t_dring matches 1 if score @s ec.t_undying matches 1 run attribute @s luck modifier add evercraft:band_luck 3.0 add_value
execute if entity @s[tag=ec._band] unless score @s ec.t_dring matches 1 unless score @s ec.t_undying matches 1 run attribute @s luck modifier add evercraft:band_luck 4.0 add_value
# --- MULTI-COPY STRIP (D-MULTICOPY / m4, Layer 1: Spirit Artifact supersedes its loose pieces) ---
# The Band's consolidated band_luck (above) ALREADY contains Aquamarine +1 + Ring of Undying +1 +
# Trial +2. If the player ALSO re-acquired a loose Aquamarine Ring / Ring of Undying / Trial Ring,
# the loose lines (aquamarine_ring_luck :233-234, ring_of_undying_luck :359-360, trial_ring_luck
# :718) added those EARLIER this tick (the loose accessory lines run before this consolidated
# fusion block — see the tick.mcfunction invariant). Strip those three loose ids here, WHILE the
# full Band is held, so they do NOT double-dip on top of band_luck (would inflate +4.0 -> up to
# +8.0). The other twelve rings carry NO luck modifier (fixed-level effects, idempotent), so only
# these three DR rings need stripping. Each strip honors the ring's existing toggle to stay in
# lockstep with the loose line: Aqua/Undying strip `unless ec.t_dring`/`unless ec.t_undying` (when
# toggled OFF the loose line adds nothing); Trial's loose line is un-gated so its strip is too.
# NEWCOMER CARVE-OUT (`unless ... matches 1`): casual Newcomer players keep the forgiving double-dip
# stack (§D-MULTICOPY casual exception). [m4 — frozen Band stays the same SIZE; this is a
# balance-neutral redundancy strip, not a resize.]
execute if entity @s[tag=ec._band] unless score @s ec.difficulty matches 1 unless score @s ec.t_dring matches 1 run attribute @s luck modifier remove evercraft:aquamarine_ring_luck
execute if entity @s[tag=ec._band] unless score @s ec.difficulty matches 1 unless score @s ec.t_undying matches 1 run attribute @s luck modifier remove evercraft:ring_of_undying_luck
execute if entity @s[tag=ec._band] unless score @s ec.difficulty matches 1 run attribute @s luck modifier remove evercraft:trial_ring_luck
# MIGRATION: a Band fused BEFORE this Wave-1 expansion still carries the legacy two-modifier form
# (band_dring_luck +1 / band_undying_luck +1). The full Band-15 now uses ONLY band_luck, so strip
# the legacy ids WHILE the full Band is held to avoid double-counting their +2.0 on top of the new
# +4.0. (The legacy 4-ring band_of_four_rings still uses those ids — but a player never holds both
# the full Band and the legacy 4-ring band's ids meaningfully: if ec._band is set we are in the
# full-Band path and the legacy ids must go.)
execute if entity @s[tag=ec._band] run attribute @s luck modifier remove evercraft:band_dring_luck
execute if entity @s[tag=ec._band] run attribute @s luck modifier remove evercraft:band_undying_luck
# Cleanup: strip the Band's consolidated luck modifier the moment it leaves the inventory (the
# status effects are short-duration and self-expire; only the attribute modifier needs explicit
# removal so it never lingers after the Band is gone). The Band uses its OWN modifier id
# (band_luck), distinct from the loose rings' ids (aquamarine_ring_luck / ring_of_undying_luck /
# trial_ring_luck), so the two systems never clobber each other.
execute unless entity @s[tag=ec._band] run attribute @s luck modifier remove evercraft:band_luck
tag @s remove ec._band
#
# (a3b) BAND OF FOUR RINGS perk re-apply (the LEGACY non-Plinth Transmute shortcut, preserved
#     UNCHANGED). The legacy [Consolidate Rings] forge now mints band_of_four_rings (NOT the full
#     15-ring Band), carrying exactly the original four perks the four loose rings gave — this is
#     the pre-Wave-1 Band behavior, verbatim, so a player who used that path loses nothing. It
#     reuses the SAME existing toggles (ec.t_dring / ec.t_undying / ec.t_phantom / ec.t_traveler)
#     and the legacy band_dring_luck / band_undying_luck modifier ids. (ec._b4 was detected up
#     top, beside ec._band.)
execute if entity @s[tag=ec._b4] unless score @s ec.t_dring matches 1 run attribute @s luck modifier add evercraft:band_dring_luck 1.0 add_value
execute if entity @s[tag=ec._b4] unless score @s ec.t_undying matches 1 run attribute @s luck modifier add evercraft:band_undying_luck 1.0 add_value
execute if entity @s[tag=ec._b4] unless score @s ec.t_phantom matches 1 run effect give @s slow_falling 5 0 false
execute if entity @s[tag=ec._b4] unless score @s ec.t_traveler matches 1 run effect give @s speed 5 0 false
execute if entity @s[tag=ec._b4] if items entity @s armor.chest minecraft:elytra run item modify entity @s armor.chest evercraft:repair_elytra
# Cleanup: strip the legacy band's two distinct luck modifiers when neither it NOR the full Band
# is held. This is the SOLE strip for band_dring_luck / band_undying_luck (the full Band-15 no
# longer uses those ids — it uses band_luck — so this also serves as the migration strip for any
# pre-Wave-1 Band still carrying the old ids: once it leaves the inventory both ids are removed).
execute unless entity @s[tag=ec._b4] unless entity @s[tag=ec._band] run attribute @s luck modifier remove evercraft:band_dring_luck
execute unless entity @s[tag=ec._b4] unless entity @s[tag=ec._band] run attribute @s luck modifier remove evercraft:band_undying_luck
tag @s remove ec._b4
#
# (a4) SUB-BAND perk re-apply (Fusion Wave 1 / Family E intermediates — Gemband / Wardband /
#     Voidband). Each is an equippable mid-tier reward that re-grants its 5-ring partial union
#     while held (zero-loss, T#3). Cheap-gate first per sub-band (one `if items` test each), then
#     dispatch to the apply-unit. A player who already fused the full Band holds band_of_all_rings,
#     NOT the sub-bands, so these and the Band-15 block never both fire for the same player.
execute if items entity @s container.* *[custom_data~{gemband:true}] run function evercraft:tinkering/bands/gemband_apply
execute unless items entity @s container.* *[custom_data~{gemband:true}] unless items entity @s weapon.offhand *[custom_data~{gemband:true}] if entity @s[tag=ec.sat_gemband] run function evercraft:tinkering/bands/gemband_apply
execute unless items entity @s container.* *[custom_data~{gemband:true}] if items entity @s weapon.offhand *[custom_data~{gemband:true}] run function evercraft:tinkering/bands/gemband_apply
execute if items entity @s container.* *[custom_data~{wardband:true}] run function evercraft:tinkering/bands/wardband_apply
execute unless items entity @s container.* *[custom_data~{wardband:true}] unless items entity @s weapon.offhand *[custom_data~{wardband:true}] if entity @s[tag=ec.sat_wardband] run function evercraft:tinkering/bands/wardband_apply
execute unless items entity @s container.* *[custom_data~{wardband:true}] if items entity @s weapon.offhand *[custom_data~{wardband:true}] run function evercraft:tinkering/bands/wardband_apply
execute if items entity @s container.* *[custom_data~{voidband:true}] run function evercraft:tinkering/bands/voidband_apply
execute unless items entity @s container.* *[custom_data~{voidband:true}] unless items entity @s weapon.offhand *[custom_data~{voidband:true}] if entity @s[tag=ec.sat_voidband] run function evercraft:tinkering/bands/voidband_apply
execute unless items entity @s container.* *[custom_data~{voidband:true}] if items entity @s weapon.offhand *[custom_data~{voidband:true}] run function evercraft:tinkering/bands/voidband_apply
# Cleanup: strip each sub-band's consolidated luck modifier when it is no longer held (Gemband
# carries none, so only Wardband/Voidband need removal — but strip both ids defensively).
execute unless items entity @s container.* *[custom_data~{wardband:true}] unless items entity @s weapon.offhand *[custom_data~{wardband:true}] unless entity @s[tag=ec.sat_wardband] run attribute @s luck modifier remove evercraft:wardband_luck
execute unless items entity @s container.* *[custom_data~{voidband:true}] unless items entity @s weapon.offhand *[custom_data~{voidband:true}] unless entity @s[tag=ec.sat_voidband] run attribute @s luck modifier remove evercraft:voidband_luck
#
# (a5) DREAMER'S RELIQUARY tree perk re-apply (Fusion / Family B — cap-B). The grand Dreamer's
#     Reliquary + its four sub-bindings (Fortune Coffer / Dream Lens / Astral Core / Craft-Luck
#     Sigil) + the Lucky Charm starter. Each re-grants its bound members' union + folds their DR into
#     ONE consolidated modifier (D1 full-power ascension; the grand = +24 UNCAPPED, reported as one
#     breakdown line). Each apply ALSO strips its members' loose *_luck (m4 Layer-1, Newcomer-exempt)
#     so a re-acquired loose piece does NOT double-dip. The grand Reliquary supersedes its sub-nodes:
#     the sub-binding applies are guarded `unless` a Reliquary is held (the grand's apply strips the
#     sub-node ids itself). A player who fused the grand holds dreamers_reliquary, NOT the sub-caps
#     (they were consumed), so these never both fire — the guard is belt-and-suspenders for
#     re-acquisition. Cheap-gate first per node (one `if items` test each).
# Grand Reliquary FIRST (it supersedes everything; tested before the sub-nodes).
execute if items entity @s container.* *[custom_data~{dreamers_reliquary:true}] run function evercraft:tinkering/reliquary/reliquary_apply
execute unless items entity @s container.* *[custom_data~{dreamers_reliquary:true}] unless items entity @s weapon.offhand *[custom_data~{dreamers_reliquary:true}] if entity @s[tag=ec.sat_dreamers_reliquary] run function evercraft:tinkering/reliquary/reliquary_apply
execute unless items entity @s container.* *[custom_data~{dreamers_reliquary:true}] if items entity @s weapon.offhand *[custom_data~{dreamers_reliquary:true}] run function evercraft:tinkering/reliquary/reliquary_apply
# Sub-capstones (guarded unless the grand Reliquary is held).
execute unless items entity @s container.* *[custom_data~{dreamers_reliquary:true}] unless items entity @s weapon.offhand *[custom_data~{dreamers_reliquary:true}] unless entity @s[tag=ec.sat_dreamers_reliquary] if items entity @s container.* *[custom_data~{fortune_coffer:true}] run function evercraft:tinkering/reliquary/fortune_coffer_apply
execute unless items entity @s container.* *[custom_data~{dreamers_reliquary:true}] unless items entity @s weapon.offhand *[custom_data~{dreamers_reliquary:true}] unless entity @s[tag=ec.sat_dreamers_reliquary] unless items entity @s container.* *[custom_data~{fortune_coffer:true}] unless items entity @s weapon.offhand *[custom_data~{fortune_coffer:true}] if entity @s[tag=ec.sat_fortune_coffer] run function evercraft:tinkering/reliquary/fortune_coffer_apply
execute unless items entity @s container.* *[custom_data~{dreamers_reliquary:true}] unless items entity @s weapon.offhand *[custom_data~{dreamers_reliquary:true}] unless entity @s[tag=ec.sat_dreamers_reliquary] unless items entity @s container.* *[custom_data~{fortune_coffer:true}] if items entity @s weapon.offhand *[custom_data~{fortune_coffer:true}] run function evercraft:tinkering/reliquary/fortune_coffer_apply
execute unless items entity @s container.* *[custom_data~{dreamers_reliquary:true}] unless items entity @s weapon.offhand *[custom_data~{dreamers_reliquary:true}] unless entity @s[tag=ec.sat_dreamers_reliquary] if items entity @s container.* *[custom_data~{dream_lens:true}] run function evercraft:tinkering/reliquary/dream_lens_apply
execute unless items entity @s container.* *[custom_data~{dreamers_reliquary:true}] unless items entity @s weapon.offhand *[custom_data~{dreamers_reliquary:true}] unless entity @s[tag=ec.sat_dreamers_reliquary] unless items entity @s container.* *[custom_data~{dream_lens:true}] unless items entity @s weapon.offhand *[custom_data~{dream_lens:true}] if entity @s[tag=ec.sat_dream_lens] run function evercraft:tinkering/reliquary/dream_lens_apply
execute unless items entity @s container.* *[custom_data~{dreamers_reliquary:true}] unless items entity @s weapon.offhand *[custom_data~{dreamers_reliquary:true}] unless entity @s[tag=ec.sat_dreamers_reliquary] unless items entity @s container.* *[custom_data~{dream_lens:true}] if items entity @s weapon.offhand *[custom_data~{dream_lens:true}] run function evercraft:tinkering/reliquary/dream_lens_apply
execute unless items entity @s container.* *[custom_data~{dreamers_reliquary:true}] unless items entity @s weapon.offhand *[custom_data~{dreamers_reliquary:true}] unless entity @s[tag=ec.sat_dreamers_reliquary] if items entity @s container.* *[custom_data~{astral_core:true}] run function evercraft:tinkering/reliquary/astral_core_apply
execute unless items entity @s container.* *[custom_data~{dreamers_reliquary:true}] unless items entity @s weapon.offhand *[custom_data~{dreamers_reliquary:true}] unless entity @s[tag=ec.sat_dreamers_reliquary] unless items entity @s container.* *[custom_data~{astral_core:true}] unless items entity @s weapon.offhand *[custom_data~{astral_core:true}] if entity @s[tag=ec.sat_astral_core] run function evercraft:tinkering/reliquary/astral_core_apply
execute unless items entity @s container.* *[custom_data~{dreamers_reliquary:true}] unless items entity @s weapon.offhand *[custom_data~{dreamers_reliquary:true}] unless entity @s[tag=ec.sat_dreamers_reliquary] unless items entity @s container.* *[custom_data~{astral_core:true}] if items entity @s weapon.offhand *[custom_data~{astral_core:true}] run function evercraft:tinkering/reliquary/astral_core_apply
execute unless items entity @s container.* *[custom_data~{dreamers_reliquary:true}] unless items entity @s weapon.offhand *[custom_data~{dreamers_reliquary:true}] unless entity @s[tag=ec.sat_dreamers_reliquary] if items entity @s container.* *[custom_data~{craft_luck_sigil:true}] run function evercraft:tinkering/reliquary/craft_luck_sigil_apply
execute unless items entity @s container.* *[custom_data~{dreamers_reliquary:true}] unless items entity @s weapon.offhand *[custom_data~{dreamers_reliquary:true}] unless entity @s[tag=ec.sat_dreamers_reliquary] unless items entity @s container.* *[custom_data~{craft_luck_sigil:true}] unless items entity @s weapon.offhand *[custom_data~{craft_luck_sigil:true}] if entity @s[tag=ec.sat_craft_luck_sigil] run function evercraft:tinkering/reliquary/craft_luck_sigil_apply
execute unless items entity @s container.* *[custom_data~{dreamers_reliquary:true}] unless items entity @s weapon.offhand *[custom_data~{dreamers_reliquary:true}] unless entity @s[tag=ec.sat_dreamers_reliquary] unless items entity @s container.* *[custom_data~{craft_luck_sigil:true}] if items entity @s weapon.offhand *[custom_data~{craft_luck_sigil:true}] run function evercraft:tinkering/reliquary/craft_luck_sigil_apply
execute unless items entity @s container.* *[custom_data~{dreamers_reliquary:true}] unless items entity @s weapon.offhand *[custom_data~{dreamers_reliquary:true}] unless entity @s[tag=ec.sat_dreamers_reliquary] if items entity @s container.* *[custom_data~{lucky_charm:true}] run function evercraft:tinkering/reliquary/lucky_charm_apply
execute unless items entity @s container.* *[custom_data~{dreamers_reliquary:true}] unless items entity @s weapon.offhand *[custom_data~{dreamers_reliquary:true}] unless entity @s[tag=ec.sat_dreamers_reliquary] unless items entity @s container.* *[custom_data~{lucky_charm:true}] unless items entity @s weapon.offhand *[custom_data~{lucky_charm:true}] if entity @s[tag=ec.sat_lucky_charm] run function evercraft:tinkering/reliquary/lucky_charm_apply
execute unless items entity @s container.* *[custom_data~{dreamers_reliquary:true}] unless items entity @s weapon.offhand *[custom_data~{dreamers_reliquary:true}] unless entity @s[tag=ec.sat_dreamers_reliquary] unless items entity @s container.* *[custom_data~{lucky_charm:true}] if items entity @s weapon.offhand *[custom_data~{lucky_charm:true}] run function evercraft:tinkering/reliquary/lucky_charm_apply
# Cleanup: strip each Reliquary-tree consolidated luck modifier when its item is no longer held. Each
# uses its OWN distinct id, so the strips never clobber an active sibling. (When the item IS held its
# apply re-adds the value later in the same tick; accessory_cleanup runs before this block, but these
# strips here cover the not-held case for the consolidated ids specifically.)
execute unless items entity @s container.* *[custom_data~{dreamers_reliquary:true}] unless items entity @s weapon.offhand *[custom_data~{dreamers_reliquary:true}] unless entity @s[tag=ec.sat_dreamers_reliquary] run attribute @s luck modifier remove evercraft:dreamers_reliquary_luck
execute unless items entity @s container.* *[custom_data~{fortune_coffer:true}] unless items entity @s weapon.offhand *[custom_data~{fortune_coffer:true}] unless entity @s[tag=ec.sat_fortune_coffer] run attribute @s luck modifier remove evercraft:fortune_coffer_luck
execute unless items entity @s container.* *[custom_data~{dream_lens:true}] unless items entity @s weapon.offhand *[custom_data~{dream_lens:true}] unless entity @s[tag=ec.sat_dream_lens] run attribute @s luck modifier remove evercraft:dream_lens_luck
execute unless items entity @s container.* *[custom_data~{astral_core:true}] unless items entity @s weapon.offhand *[custom_data~{astral_core:true}] unless entity @s[tag=ec.sat_astral_core] run attribute @s luck modifier remove evercraft:astral_core_luck
execute unless items entity @s container.* *[custom_data~{craft_luck_sigil:true}] unless items entity @s weapon.offhand *[custom_data~{craft_luck_sigil:true}] unless entity @s[tag=ec.sat_craft_luck_sigil] run attribute @s luck modifier remove evercraft:craft_luck_sigil_luck
execute unless items entity @s container.* *[custom_data~{lucky_charm:true}] unless items entity @s weapon.offhand *[custom_data~{lucky_charm:true}] unless entity @s[tag=ec.sat_lucky_charm] run attribute @s luck modifier remove evercraft:lucky_charm_luck
#
# (a6) WAYFARER'S LENS tree perk re-apply (Fusion / Family C — cap-C). The grand Wayfarer's Lens + its
#     three sub-bindings (Oracle Lens / Wanderer's Token / Surveyor's Kit) + the Far Sight Lens
#     leaf-pair. Each re-grants its bound members' PASSIVE sense/travel/survey union (the sneak-
#     triggered survey/mob-vision halves are gated separately in the WAYFARER SNEAK block far below,
#     where the node ids are added as extra activation gates). ZERO DR anywhere (balance-neutral bundle,
#     DECISIONS + lattice §C; Open-Decision 4: the +40/10% dodge went to Soulguard Aegis, so the
#     Wayfarer line carries NO dodge bonus — only the +1% the two agile members already grant via the
#     m1 ec.acc_dodge LEAF block at the top of this file, re-added there for the Token/grand). No
#     `*_luck` is added or stripped (the family has zero DR members; m4 strip is a no-op — documented in
#     each apply). The ONLY consolidated attribute is the Far-Lens waypoint range (fixed-id, idempotent;
#     stripped in accessory_cleanup whose guard cap-C extends to far_lens / surveyors_kit / grand).
#     Supersede order: grand FIRST (it grants everything), then the 3 sub-caps guarded `unless` the
#     grand is held, then Far Sight Lens guarded `unless` an Oracle Lens OR the grand is held (Oracle
#     supersedes the leaf-pair). Cheap-gate first per node (one `if items` test each).
# Grand Wayfarer's Lens FIRST (it supersedes everything).
execute if items entity @s container.* *[custom_data~{wayfarers_lens:true}] run function evercraft:tinkering/wayfarer/wayfarer_lens_apply
execute unless items entity @s container.* *[custom_data~{wayfarers_lens:true}] unless items entity @s weapon.offhand *[custom_data~{wayfarers_lens:true}] if entity @s[tag=ec.sat_wayfarers_lens] run function evercraft:tinkering/wayfarer/wayfarer_lens_apply
execute unless items entity @s container.* *[custom_data~{wayfarers_lens:true}] if items entity @s weapon.offhand *[custom_data~{wayfarers_lens:true}] run function evercraft:tinkering/wayfarer/wayfarer_lens_apply
# Grand's passive coord readout (Wayworn Tally / Astrolabe half — SNEAK-SUPPRESSED, like the loose tally).
execute unless predicate evercraft:sneaking if items entity @s container.* *[custom_data~{wayfarers_lens:true}] run function evercraft:artifacts/accessories/wayfarer/coord_readout
execute unless predicate evercraft:sneaking unless items entity @s container.* *[custom_data~{wayfarers_lens:true}] unless items entity @s weapon.offhand *[custom_data~{wayfarers_lens:true}] if entity @s[tag=ec.sat_wayfarers_lens] run function evercraft:artifacts/accessories/wayfarer/coord_readout
execute unless predicate evercraft:sneaking unless items entity @s container.* *[custom_data~{wayfarers_lens:true}] if items entity @s weapon.offhand *[custom_data~{wayfarers_lens:true}] run function evercraft:artifacts/accessories/wayfarer/coord_readout
# Sub-capstones (guarded unless the grand Wayfarer's Lens is held).
execute unless items entity @s container.* *[custom_data~{wayfarers_lens:true}] unless items entity @s weapon.offhand *[custom_data~{wayfarers_lens:true}] unless entity @s[tag=ec.sat_wayfarers_lens] if items entity @s container.* *[custom_data~{oracle_lens:true}] run function evercraft:tinkering/wayfarer/oracle_lens_apply
execute unless items entity @s container.* *[custom_data~{wayfarers_lens:true}] unless items entity @s weapon.offhand *[custom_data~{wayfarers_lens:true}] unless entity @s[tag=ec.sat_wayfarers_lens] unless items entity @s container.* *[custom_data~{oracle_lens:true}] unless items entity @s weapon.offhand *[custom_data~{oracle_lens:true}] if entity @s[tag=ec.sat_oracle_lens] run function evercraft:tinkering/wayfarer/oracle_lens_apply
execute unless items entity @s container.* *[custom_data~{wayfarers_lens:true}] unless items entity @s weapon.offhand *[custom_data~{wayfarers_lens:true}] unless entity @s[tag=ec.sat_wayfarers_lens] unless items entity @s container.* *[custom_data~{oracle_lens:true}] if items entity @s weapon.offhand *[custom_data~{oracle_lens:true}] run function evercraft:tinkering/wayfarer/oracle_lens_apply
execute unless items entity @s container.* *[custom_data~{wayfarers_lens:true}] unless items entity @s weapon.offhand *[custom_data~{wayfarers_lens:true}] unless entity @s[tag=ec.sat_wayfarers_lens] if items entity @s container.* *[custom_data~{wanderers_token:true}] run function evercraft:tinkering/wayfarer/wanderers_token_apply
execute unless items entity @s container.* *[custom_data~{wayfarers_lens:true}] unless items entity @s weapon.offhand *[custom_data~{wayfarers_lens:true}] unless entity @s[tag=ec.sat_wayfarers_lens] unless items entity @s container.* *[custom_data~{wanderers_token:true}] unless items entity @s weapon.offhand *[custom_data~{wanderers_token:true}] if entity @s[tag=ec.sat_wanderers_token] run function evercraft:tinkering/wayfarer/wanderers_token_apply
execute unless items entity @s container.* *[custom_data~{wayfarers_lens:true}] unless items entity @s weapon.offhand *[custom_data~{wayfarers_lens:true}] unless entity @s[tag=ec.sat_wayfarers_lens] unless items entity @s container.* *[custom_data~{wanderers_token:true}] if items entity @s weapon.offhand *[custom_data~{wanderers_token:true}] run function evercraft:tinkering/wayfarer/wanderers_token_apply
execute unless items entity @s container.* *[custom_data~{wayfarers_lens:true}] unless items entity @s weapon.offhand *[custom_data~{wayfarers_lens:true}] unless entity @s[tag=ec.sat_wayfarers_lens] if items entity @s container.* *[custom_data~{surveyors_kit:true}] run function evercraft:tinkering/wayfarer/surveyors_kit_apply
execute unless items entity @s container.* *[custom_data~{wayfarers_lens:true}] unless items entity @s weapon.offhand *[custom_data~{wayfarers_lens:true}] unless entity @s[tag=ec.sat_wayfarers_lens] unless items entity @s container.* *[custom_data~{surveyors_kit:true}] unless items entity @s weapon.offhand *[custom_data~{surveyors_kit:true}] if entity @s[tag=ec.sat_surveyors_kit] run function evercraft:tinkering/wayfarer/surveyors_kit_apply
execute unless items entity @s container.* *[custom_data~{wayfarers_lens:true}] unless items entity @s weapon.offhand *[custom_data~{wayfarers_lens:true}] unless entity @s[tag=ec.sat_wayfarers_lens] unless items entity @s container.* *[custom_data~{surveyors_kit:true}] if items entity @s weapon.offhand *[custom_data~{surveyors_kit:true}] run function evercraft:tinkering/wayfarer/surveyors_kit_apply
# Surveyor's Kit passive coord readout (SNEAK-SUPPRESSED; only when no grand is held — grand handles it above).
execute unless items entity @s container.* *[custom_data~{wayfarers_lens:true}] unless items entity @s weapon.offhand *[custom_data~{wayfarers_lens:true}] unless entity @s[tag=ec.sat_wayfarers_lens] unless predicate evercraft:sneaking if items entity @s container.* *[custom_data~{surveyors_kit:true}] run function evercraft:artifacts/accessories/wayfarer/coord_readout
execute unless items entity @s container.* *[custom_data~{wayfarers_lens:true}] unless items entity @s weapon.offhand *[custom_data~{wayfarers_lens:true}] unless entity @s[tag=ec.sat_wayfarers_lens] unless predicate evercraft:sneaking unless items entity @s container.* *[custom_data~{surveyors_kit:true}] unless items entity @s weapon.offhand *[custom_data~{surveyors_kit:true}] if entity @s[tag=ec.sat_surveyors_kit] run function evercraft:artifacts/accessories/wayfarer/coord_readout
execute unless items entity @s container.* *[custom_data~{wayfarers_lens:true}] unless items entity @s weapon.offhand *[custom_data~{wayfarers_lens:true}] unless entity @s[tag=ec.sat_wayfarers_lens] unless predicate evercraft:sneaking unless items entity @s container.* *[custom_data~{surveyors_kit:true}] if items entity @s weapon.offhand *[custom_data~{surveyors_kit:true}] run function evercraft:artifacts/accessories/wayfarer/coord_readout
# Far Sight Lens leaf-pair (guarded unless an Oracle Lens OR the grand Wayfarer's Lens is held — both supersede it).
execute unless items entity @s container.* *[custom_data~{wayfarers_lens:true}] unless items entity @s weapon.offhand *[custom_data~{wayfarers_lens:true}] unless entity @s[tag=ec.sat_wayfarers_lens] unless items entity @s container.* *[custom_data~{oracle_lens:true}] unless items entity @s weapon.offhand *[custom_data~{oracle_lens:true}] unless entity @s[tag=ec.sat_oracle_lens] if items entity @s container.* *[custom_data~{far_sight_lens:true}] run function evercraft:tinkering/wayfarer/far_sight_lens_apply
execute unless items entity @s container.* *[custom_data~{wayfarers_lens:true}] unless items entity @s weapon.offhand *[custom_data~{wayfarers_lens:true}] unless entity @s[tag=ec.sat_wayfarers_lens] unless items entity @s container.* *[custom_data~{oracle_lens:true}] unless items entity @s weapon.offhand *[custom_data~{oracle_lens:true}] unless entity @s[tag=ec.sat_oracle_lens] unless items entity @s container.* *[custom_data~{far_sight_lens:true}] unless items entity @s weapon.offhand *[custom_data~{far_sight_lens:true}] if entity @s[tag=ec.sat_far_sight_lens] run function evercraft:tinkering/wayfarer/far_sight_lens_apply
execute unless items entity @s container.* *[custom_data~{wayfarers_lens:true}] unless items entity @s weapon.offhand *[custom_data~{wayfarers_lens:true}] unless entity @s[tag=ec.sat_wayfarers_lens] unless items entity @s container.* *[custom_data~{oracle_lens:true}] unless items entity @s weapon.offhand *[custom_data~{oracle_lens:true}] unless entity @s[tag=ec.sat_oracle_lens] unless items entity @s container.* *[custom_data~{far_sight_lens:true}] if items entity @s weapon.offhand *[custom_data~{far_sight_lens:true}] run function evercraft:tinkering/wayfarer/far_sight_lens_apply
# Cleanup: when NO Wayfarer node that grants the Far-Lens waypoint range is held (Surveyor's Kit OR the
# grand OR a loose Voyager's Far-Lens — the loose case is covered by accessory_cleanup), strip the
# shared voyagers_far_lens_wp here so dropping the Kit/grand returns the waypoint range to normal. (The
# loose-Far-Lens not-held strip already lives in accessory_cleanup; this extra strip covers the case
# where the Kit/grand granted it but no loose Far-Lens is present.) The other absorbed members grant no
# attribute (pure effects / readouts / light), so no further strip is needed for this family.
execute unless items entity @s container.* *[custom_data~{wayfarers_lens:true}] unless items entity @s weapon.offhand *[custom_data~{wayfarers_lens:true}] unless items entity @s container.* *[custom_data~{surveyors_kit:true}] unless items entity @s weapon.offhand *[custom_data~{surveyors_kit:true}] unless items entity @s container.* *[custom_data~{artifact:"voyagers_far_lens"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"voyagers_far_lens"}] unless entity @s[tag=ec.sat_voyagers_far_lens] run attribute @s waypoint_receive_range modifier remove evercraft:voyagers_far_lens_wp
#
# (a7) SOULGUARD AEGIS tree perk re-apply (Fusion / Family D — cap-D). The grand Soulguard Aegis + its
#     four sub-bindings (Grand Totem / Lifewarden / Bulwark Stone / Aura Ward). Each re-grants its
#     bound members' PASSIVE defensive ward union (the DEATH-SAVE halves route through the ONE shared
#     ec.cd_save bucket at the death-save block far below, where the node ids are added as activation
#     gates — G6: one bucket, Absorption max-not-sum). ZERO DR anywhere (balance-neutral, power-dense
#     bundle, DECISIONS + lattice §D). No `*_luck` is added or stripped (the family has zero DR members;
#     m4 strip targets the loose member auto-revive ids, handled at the death-save block, not a luck
#     strip). The ONE +40 (10%) dodge is added in the m1 ec.acc_dodge LEAF block at the top of this file,
#     NOT here (Open-Decision 4). Supersede order: grand FIRST (it grants everything via the 4 sub-cap
#     applies), then the 4 sub-caps each guarded `unless` the grand is held. Cheap-gate first per node
#     (one `if items` test each). The 4 sub-caps are SIBLINGS (no nesting — unlike the Wayfarer Far Sight
#     Lens leaf-pair), so each is guarded only against the grand.
# Grand Soulguard Aegis FIRST (it supersedes everything).
execute if items entity @s container.* *[custom_data~{soulguard_aegis:true}] run function evercraft:tinkering/soulguard/soulguard_aegis_apply
execute unless items entity @s container.* *[custom_data~{soulguard_aegis:true}] unless items entity @s weapon.offhand *[custom_data~{soulguard_aegis:true}] if entity @s[tag=ec.sat_soulguard_aegis] run function evercraft:tinkering/soulguard/soulguard_aegis_apply
execute unless items entity @s container.* *[custom_data~{soulguard_aegis:true}] if items entity @s weapon.offhand *[custom_data~{soulguard_aegis:true}] run function evercraft:tinkering/soulguard/soulguard_aegis_apply
# Sub-capstones (each guarded unless the grand Soulguard Aegis is held).
execute unless items entity @s container.* *[custom_data~{soulguard_aegis:true}] unless items entity @s weapon.offhand *[custom_data~{soulguard_aegis:true}] unless entity @s[tag=ec.sat_soulguard_aegis] if items entity @s container.* *[custom_data~{grand_totem:true}] run function evercraft:tinkering/soulguard/grand_totem_apply
execute unless items entity @s container.* *[custom_data~{soulguard_aegis:true}] unless items entity @s weapon.offhand *[custom_data~{soulguard_aegis:true}] unless entity @s[tag=ec.sat_soulguard_aegis] unless items entity @s container.* *[custom_data~{grand_totem:true}] unless items entity @s weapon.offhand *[custom_data~{grand_totem:true}] if entity @s[tag=ec.sat_grand_totem] run function evercraft:tinkering/soulguard/grand_totem_apply
execute unless items entity @s container.* *[custom_data~{soulguard_aegis:true}] unless items entity @s weapon.offhand *[custom_data~{soulguard_aegis:true}] unless entity @s[tag=ec.sat_soulguard_aegis] unless items entity @s container.* *[custom_data~{grand_totem:true}] if items entity @s weapon.offhand *[custom_data~{grand_totem:true}] run function evercraft:tinkering/soulguard/grand_totem_apply
execute unless items entity @s container.* *[custom_data~{soulguard_aegis:true}] unless items entity @s weapon.offhand *[custom_data~{soulguard_aegis:true}] unless entity @s[tag=ec.sat_soulguard_aegis] if items entity @s container.* *[custom_data~{lifewarden:true}] run function evercraft:tinkering/soulguard/lifewarden_apply
execute unless items entity @s container.* *[custom_data~{soulguard_aegis:true}] unless items entity @s weapon.offhand *[custom_data~{soulguard_aegis:true}] unless entity @s[tag=ec.sat_soulguard_aegis] unless items entity @s container.* *[custom_data~{lifewarden:true}] unless items entity @s weapon.offhand *[custom_data~{lifewarden:true}] if entity @s[tag=ec.sat_lifewarden] run function evercraft:tinkering/soulguard/lifewarden_apply
execute unless items entity @s container.* *[custom_data~{soulguard_aegis:true}] unless items entity @s weapon.offhand *[custom_data~{soulguard_aegis:true}] unless entity @s[tag=ec.sat_soulguard_aegis] unless items entity @s container.* *[custom_data~{lifewarden:true}] if items entity @s weapon.offhand *[custom_data~{lifewarden:true}] run function evercraft:tinkering/soulguard/lifewarden_apply
execute unless items entity @s container.* *[custom_data~{soulguard_aegis:true}] unless items entity @s weapon.offhand *[custom_data~{soulguard_aegis:true}] unless entity @s[tag=ec.sat_soulguard_aegis] if items entity @s container.* *[custom_data~{bulwark_stone:true}] run function evercraft:tinkering/soulguard/bulwark_stone_apply
execute unless items entity @s container.* *[custom_data~{soulguard_aegis:true}] unless items entity @s weapon.offhand *[custom_data~{soulguard_aegis:true}] unless entity @s[tag=ec.sat_soulguard_aegis] unless items entity @s container.* *[custom_data~{bulwark_stone:true}] unless items entity @s weapon.offhand *[custom_data~{bulwark_stone:true}] if entity @s[tag=ec.sat_bulwark_stone] run function evercraft:tinkering/soulguard/bulwark_stone_apply
execute unless items entity @s container.* *[custom_data~{soulguard_aegis:true}] unless items entity @s weapon.offhand *[custom_data~{soulguard_aegis:true}] unless entity @s[tag=ec.sat_soulguard_aegis] unless items entity @s container.* *[custom_data~{bulwark_stone:true}] if items entity @s weapon.offhand *[custom_data~{bulwark_stone:true}] run function evercraft:tinkering/soulguard/bulwark_stone_apply
execute unless items entity @s container.* *[custom_data~{soulguard_aegis:true}] unless items entity @s weapon.offhand *[custom_data~{soulguard_aegis:true}] unless entity @s[tag=ec.sat_soulguard_aegis] if items entity @s container.* *[custom_data~{aura_ward:true}] run function evercraft:tinkering/soulguard/aura_ward_apply
execute unless items entity @s container.* *[custom_data~{soulguard_aegis:true}] unless items entity @s weapon.offhand *[custom_data~{soulguard_aegis:true}] unless entity @s[tag=ec.sat_soulguard_aegis] unless items entity @s container.* *[custom_data~{aura_ward:true}] unless items entity @s weapon.offhand *[custom_data~{aura_ward:true}] if entity @s[tag=ec.sat_aura_ward] run function evercraft:tinkering/soulguard/aura_ward_apply
execute unless items entity @s container.* *[custom_data~{soulguard_aegis:true}] unless items entity @s weapon.offhand *[custom_data~{soulguard_aegis:true}] unless entity @s[tag=ec.sat_soulguard_aegis] unless items entity @s container.* *[custom_data~{aura_ward:true}] if items entity @s weapon.offhand *[custom_data~{aura_ward:true}] run function evercraft:tinkering/soulguard/aura_ward_apply
#
# (a8) GRANDFORGE REGALIA tree perk re-apply (Fusion / Family G — cap-G). The grand Grandforge Regalia +
#     its three NEW sub-bindings (Smith's Apron / Quench Line / Forge Resolve). Each re-grants its bound
#     forge leaves' PASSIVE attribute union (break-speed + mining-efficiency) via DISTINCT capstone-scoped
#     fixed ids (NOT the loose leaf ids — so the loose accessory_cleanup never strips them; the cap-G
#     accessory_cleanup block strips the capstone ids when the node is not held). The CR / forge-resolve /
#     auto-smelt / ore-roll / double-log halves route through their own ONE-writer hooks (calculate /
#     resolve / detect_ordinary_tool / check_drop / harvest_bonus_read), gated on the held capstone flag,
#     with the loose leaf CR adds m4-suppressed when the capstone is held (Newcomer-exempt) — NOT here.
#     ZERO DR anywhere (balance-neutral bundle; CR set-not-add so it never stacks; DECISIONS + lattice §G).
#     No `*_luck` added or stripped (the family has zero DR members). Supersede order: grand FIRST (it
#     grants the full consolidated union directly), then the 3 sub-caps each guarded `unless` the grand is
#     held. The 4th sub-cap, Grand Anvil Heart, is the EXISTING C17 leaf — its perks already fire from the
#     loose Family-G lines (break/CR/resolve), so it needs NO dispatch here; its loose CR/resolve are
#     m4-suppressed when the grand is held (in calculate.mcfunction + resolve.mcfunction). Cheap-gate first
#     per node (one `if items` test each). The 3 sub-caps are SIBLINGS (no nesting), each guarded vs the
#     grand only. Forge Resolve's apply is a documented no-op (its perks are all event-gated, routed
#     through the forge_resolve-flag hooks).
# Grand Grandforge Regalia FIRST (it supersedes everything — grants the full consolidated forge union).
execute if items entity @s container.* *[custom_data~{grandforge_regalia:true}] run function evercraft:tinkering/grandforge/grandforge_regalia_apply
execute unless items entity @s container.* *[custom_data~{grandforge_regalia:true}] unless items entity @s weapon.offhand *[custom_data~{grandforge_regalia:true}] if entity @s[tag=ec.sat_grandforge_regalia] run function evercraft:tinkering/grandforge/grandforge_regalia_apply
execute unless items entity @s container.* *[custom_data~{grandforge_regalia:true}] if items entity @s weapon.offhand *[custom_data~{grandforge_regalia:true}] run function evercraft:tinkering/grandforge/grandforge_regalia_apply
# Sub-capstones (each guarded unless the grand Grandforge Regalia is held).
execute unless items entity @s container.* *[custom_data~{grandforge_regalia:true}] unless items entity @s weapon.offhand *[custom_data~{grandforge_regalia:true}] unless entity @s[tag=ec.sat_grandforge_regalia] if items entity @s container.* *[custom_data~{smiths_apron:true}] run function evercraft:tinkering/grandforge/smiths_apron_apply
execute unless items entity @s container.* *[custom_data~{grandforge_regalia:true}] unless items entity @s weapon.offhand *[custom_data~{grandforge_regalia:true}] unless entity @s[tag=ec.sat_grandforge_regalia] unless items entity @s container.* *[custom_data~{smiths_apron:true}] unless items entity @s weapon.offhand *[custom_data~{smiths_apron:true}] if entity @s[tag=ec.sat_smiths_apron] run function evercraft:tinkering/grandforge/smiths_apron_apply
execute unless items entity @s container.* *[custom_data~{grandforge_regalia:true}] unless items entity @s weapon.offhand *[custom_data~{grandforge_regalia:true}] unless entity @s[tag=ec.sat_grandforge_regalia] unless items entity @s container.* *[custom_data~{smiths_apron:true}] if items entity @s weapon.offhand *[custom_data~{smiths_apron:true}] run function evercraft:tinkering/grandforge/smiths_apron_apply
execute unless items entity @s container.* *[custom_data~{grandforge_regalia:true}] unless items entity @s weapon.offhand *[custom_data~{grandforge_regalia:true}] unless entity @s[tag=ec.sat_grandforge_regalia] if items entity @s container.* *[custom_data~{quench_line:true}] run function evercraft:tinkering/grandforge/quench_line_apply
execute unless items entity @s container.* *[custom_data~{grandforge_regalia:true}] unless items entity @s weapon.offhand *[custom_data~{grandforge_regalia:true}] unless entity @s[tag=ec.sat_grandforge_regalia] unless items entity @s container.* *[custom_data~{quench_line:true}] unless items entity @s weapon.offhand *[custom_data~{quench_line:true}] if entity @s[tag=ec.sat_quench_line] run function evercraft:tinkering/grandforge/quench_line_apply
execute unless items entity @s container.* *[custom_data~{grandforge_regalia:true}] unless items entity @s weapon.offhand *[custom_data~{grandforge_regalia:true}] unless entity @s[tag=ec.sat_grandforge_regalia] unless items entity @s container.* *[custom_data~{quench_line:true}] if items entity @s weapon.offhand *[custom_data~{quench_line:true}] run function evercraft:tinkering/grandforge/quench_line_apply
execute unless items entity @s container.* *[custom_data~{grandforge_regalia:true}] unless items entity @s weapon.offhand *[custom_data~{grandforge_regalia:true}] unless entity @s[tag=ec.sat_grandforge_regalia] if items entity @s container.* *[custom_data~{forge_resolve:true}] run function evercraft:tinkering/grandforge/forge_resolve_apply
execute unless items entity @s container.* *[custom_data~{grandforge_regalia:true}] unless items entity @s weapon.offhand *[custom_data~{grandforge_regalia:true}] unless entity @s[tag=ec.sat_grandforge_regalia] unless items entity @s container.* *[custom_data~{forge_resolve:true}] unless items entity @s weapon.offhand *[custom_data~{forge_resolve:true}] if entity @s[tag=ec.sat_forge_resolve] run function evercraft:tinkering/grandforge/forge_resolve_apply
execute unless items entity @s container.* *[custom_data~{grandforge_regalia:true}] unless items entity @s weapon.offhand *[custom_data~{grandforge_regalia:true}] unless entity @s[tag=ec.sat_grandforge_regalia] unless items entity @s container.* *[custom_data~{forge_resolve:true}] if items entity @s weapon.offhand *[custom_data~{forge_resolve:true}] run function evercraft:tinkering/grandforge/forge_resolve_apply
#
# (a9) ALCHEMIST'S MAGNUM OPUS tree perk re-apply (Fusion / Family H — cap-H). The grand Alchemist's
#     Magnum Opus + the Sustain Vial sub-binding re-grant their bound leaf's ONLY per-tick perk:
#     Regeneration I while below half health (the Glacier-Cut Sigil B11 leaf). The other three sub-caps
#     (Steeping Line / Crucible Line / Reliquary Line) carry NO per-tick perk — their CR / alchemy-
#     quality / reagent-yield / potion-duration levers route through the brew-funnel ONE-writer hooks
#     (craft_rate/calculate [the ONE ec.cr_temp writer], alchemy/minigame/resolve, the result_* duration
#     steps), gated on the held capstone flag, with the loose leaf brew levers m4-suppressed when the
#     capstone is held (Newcomer-exempt) — NOT here. So only the grand + the Sustain Vial dispatch here.
#     ZERO DR anywhere (balance-neutral bundle; CR set-not-add so it never stacks; DECISIONS + lattice
#     §H). No `*_luck` added or stripped (the family has zero DR members). NO attribute modifier (the
#     only grant is the Regen effect -> no accessory_cleanup / strip_player_zero strip needed). Supersede
#     order: grand FIRST (it grants the Regen directly), then the Sustain Vial guarded `unless` the grand
#     is held. Cheap-gate first per node (one `if items` test each).
# Grand Alchemist's Magnum Opus FIRST (it supersedes — grants the Sustain Vial's Regen-below-half).
execute if items entity @s container.* *[custom_data~{alchemists_magnum_opus:true}] run function evercraft:tinkering/magnum_opus/alchemists_magnum_opus_apply
execute unless items entity @s container.* *[custom_data~{alchemists_magnum_opus:true}] unless items entity @s weapon.offhand *[custom_data~{alchemists_magnum_opus:true}] if entity @s[tag=ec.sat_alchemists_magnum_opus] run function evercraft:tinkering/magnum_opus/alchemists_magnum_opus_apply
execute unless items entity @s container.* *[custom_data~{alchemists_magnum_opus:true}] if items entity @s weapon.offhand *[custom_data~{alchemists_magnum_opus:true}] run function evercraft:tinkering/magnum_opus/alchemists_magnum_opus_apply
# Sustain Vial sub-binding (guarded unless the grand Magnum Opus is held).
execute unless items entity @s container.* *[custom_data~{alchemists_magnum_opus:true}] unless items entity @s weapon.offhand *[custom_data~{alchemists_magnum_opus:true}] unless entity @s[tag=ec.sat_alchemists_magnum_opus] if items entity @s container.* *[custom_data~{sustain_vial:true}] run function evercraft:tinkering/magnum_opus/sustain_vial_apply
execute unless items entity @s container.* *[custom_data~{alchemists_magnum_opus:true}] unless items entity @s weapon.offhand *[custom_data~{alchemists_magnum_opus:true}] unless entity @s[tag=ec.sat_alchemists_magnum_opus] unless items entity @s container.* *[custom_data~{sustain_vial:true}] unless items entity @s weapon.offhand *[custom_data~{sustain_vial:true}] if entity @s[tag=ec.sat_sustain_vial] run function evercraft:tinkering/magnum_opus/sustain_vial_apply
execute unless items entity @s container.* *[custom_data~{alchemists_magnum_opus:true}] unless items entity @s weapon.offhand *[custom_data~{alchemists_magnum_opus:true}] unless entity @s[tag=ec.sat_alchemists_magnum_opus] unless items entity @s container.* *[custom_data~{sustain_vial:true}] if items entity @s weapon.offhand *[custom_data~{sustain_vial:true}] run function evercraft:tinkering/magnum_opus/sustain_vial_apply
#
# (a10) CORNUCOPIA TIDE tree perk re-apply (Fusion / Family J — cap-J). The grand Cornucopia Tide + the
#     two PER-TICK sub-caps (Tidewright's Net = fishing · Harvest Knot = farming/aquatic) re-grant their
#     bound members' per-tick perks: rod Lure/LotS inject + aquatic submerged-mining/swim attrs + the
#     crop growth pulse + the splash-node sense. The third sub-cap — Hearthkeeper's Ladle (culinary) —
#     carries NO per-tick perk (its +2 cook quality / +10.0 CR / +2% bonus-roll route through the
#     cook-funnel ONE-writer hooks: cooking/minigame/resolve + craft_rate/calculate), so it gets NO
#     dispatch here (matches cap-H's Steeping/Crucible/Reliquary lines). The CONSOLIDATED conditional DR
#     (Riverpearl +2 while fishing + Deepcurrent +3 in water → ONE line) is condition-gated below for the
#     grand (cornucopia_tide_luck) + the Net (tidewright_luck). Supersede order: grand FIRST, then the
#     Net guarded `unless` the grand is held; the Harvest Knot is the SEPARATE farming sub-cap the grand
#     does NOT eat (the grand still folds its growth/aquatic perks in its own apply), so it dispatches on
#     its own flag BUT is guarded `unless` the grand is held to avoid a double growth pulse. Cheap-gate
#     first per node (one `if items` test each).
# Grand Cornucopia Tide FIRST (it supersedes — its apply re-grants the Net + Harvest Knot per-tick union).
execute if items entity @s container.* *[custom_data~{cornucopia_tide:true}] run function evercraft:tinkering/cornucopia/cornucopia_tide_apply
execute unless items entity @s container.* *[custom_data~{cornucopia_tide:true}] unless items entity @s weapon.offhand *[custom_data~{cornucopia_tide:true}] if entity @s[tag=ec.sat_cornucopia_tide] run function evercraft:tinkering/cornucopia/cornucopia_tide_apply
execute unless items entity @s container.* *[custom_data~{cornucopia_tide:true}] if items entity @s weapon.offhand *[custom_data~{cornucopia_tide:true}] run function evercraft:tinkering/cornucopia/cornucopia_tide_apply
# Tidewright's Net sub-binding (guarded unless the grand Cornucopia Tide is held).
execute unless items entity @s container.* *[custom_data~{cornucopia_tide:true}] unless items entity @s weapon.offhand *[custom_data~{cornucopia_tide:true}] unless entity @s[tag=ec.sat_cornucopia_tide] if items entity @s container.* *[custom_data~{tidewrights_net:true}] run function evercraft:tinkering/cornucopia/tidewrights_net_apply
execute unless items entity @s container.* *[custom_data~{cornucopia_tide:true}] unless items entity @s weapon.offhand *[custom_data~{cornucopia_tide:true}] unless entity @s[tag=ec.sat_cornucopia_tide] unless items entity @s container.* *[custom_data~{tidewrights_net:true}] unless items entity @s weapon.offhand *[custom_data~{tidewrights_net:true}] if entity @s[tag=ec.sat_tidewrights_net] run function evercraft:tinkering/cornucopia/tidewrights_net_apply
execute unless items entity @s container.* *[custom_data~{cornucopia_tide:true}] unless items entity @s weapon.offhand *[custom_data~{cornucopia_tide:true}] unless entity @s[tag=ec.sat_cornucopia_tide] unless items entity @s container.* *[custom_data~{tidewrights_net:true}] if items entity @s weapon.offhand *[custom_data~{tidewrights_net:true}] run function evercraft:tinkering/cornucopia/tidewrights_net_apply
# Harvest Knot farming/aquatic sub-binding (guarded unless the grand Cornucopia Tide is held — the
# grand folds the Knot's growth/aquatic perks in its own apply, so guard against a double pulse).
execute unless items entity @s container.* *[custom_data~{cornucopia_tide:true}] unless items entity @s weapon.offhand *[custom_data~{cornucopia_tide:true}] unless entity @s[tag=ec.sat_cornucopia_tide] if items entity @s container.* *[custom_data~{harvest_knot:true}] run function evercraft:tinkering/cornucopia/harvest_knot_apply
execute unless items entity @s container.* *[custom_data~{cornucopia_tide:true}] unless items entity @s weapon.offhand *[custom_data~{cornucopia_tide:true}] unless entity @s[tag=ec.sat_cornucopia_tide] unless items entity @s container.* *[custom_data~{harvest_knot:true}] unless items entity @s weapon.offhand *[custom_data~{harvest_knot:true}] if entity @s[tag=ec.sat_harvest_knot] run function evercraft:tinkering/cornucopia/harvest_knot_apply
execute unless items entity @s container.* *[custom_data~{cornucopia_tide:true}] unless items entity @s weapon.offhand *[custom_data~{cornucopia_tide:true}] unless entity @s[tag=ec.sat_cornucopia_tide] unless items entity @s container.* *[custom_data~{harvest_knot:true}] if items entity @s weapon.offhand *[custom_data~{harvest_knot:true}] run function evercraft:tinkering/cornucopia/harvest_knot_apply
#
# (a11) DEMIURGE'S CAPSTONE tree perk re-apply (Fusion / Family K — cap-K). The Demiurge's Spirit Artifact
#     + its three sub-caps (Node Mastery = node-craft · Deepdig Line = aquatic-dig · Surveyor Line =
#     gathering QoL) re-grant their bound members' PER-TICK perks. The grand's apply grants the full
#     consolidated craft-loop attribute union (break-speed + mining-efficiency + reach + the Deepdig
#     aquatic kit) + the Astrolabe node pip. The sub-caps each grant only their per-tick slice: Deepdig =
#     the aquatic kit (distinct deepdig ids); Node Mastery = the Astrolabe pip; Surveyor = a documented
#     no-op (all its levers are event/sneak-gated). The CONSOLIDATED conditional +3.0 mining-DR
#     (demiurges_capstone_luck) is condition-gated in the FAMILY K LEAVES block below (pre-wired by art-K,
#     ec.cf_actwin-gated) — NOT here. The CR (+8.0) is in craft_rate/calculate (the ONE ec.cr_temp writer).
#     The ore-roll / crate / node-crate / pickup / dup / despawn / rank-bypass route through their own
#     ONE-writer event hooks gated on the held flag (loose leaf `unless` the node, Newcomer-exempt) — NOT
#     here. Supersede order: grand FIRST (its apply re-grants the whole per-tick union), then the 3 sub-caps
#     each guarded `unless` the grand is held. Cheap-gate first per node (one `if items` test each).
# Grand Demiurge's Spirit Artifact FIRST (it supersedes — its apply re-grants the full per-tick craft-loop union).
execute if items entity @s container.* *[custom_data~{demiurges_capstone:true}] run function evercraft:tinkering/demiurge/demiurges_capstone_apply
execute unless items entity @s container.* *[custom_data~{demiurges_capstone:true}] unless items entity @s weapon.offhand *[custom_data~{demiurges_capstone:true}] if entity @s[tag=ec.sat_demiurges_capstone] run function evercraft:tinkering/demiurge/demiurges_capstone_apply
execute unless items entity @s container.* *[custom_data~{demiurges_capstone:true}] if items entity @s weapon.offhand *[custom_data~{demiurges_capstone:true}] run function evercraft:tinkering/demiurge/demiurges_capstone_apply
# Deepdig Line sub-binding (guarded unless the Demiurge's Spirit Artifact is held).
execute unless items entity @s container.* *[custom_data~{demiurges_capstone:true}] unless items entity @s weapon.offhand *[custom_data~{demiurges_capstone:true}] unless entity @s[tag=ec.sat_demiurges_capstone] if items entity @s container.* *[custom_data~{deepdig_line:true}] run function evercraft:tinkering/demiurge/deepdig_line_apply
execute unless items entity @s container.* *[custom_data~{demiurges_capstone:true}] unless items entity @s weapon.offhand *[custom_data~{demiurges_capstone:true}] unless entity @s[tag=ec.sat_demiurges_capstone] unless items entity @s container.* *[custom_data~{deepdig_line:true}] unless items entity @s weapon.offhand *[custom_data~{deepdig_line:true}] if entity @s[tag=ec.sat_deepdig_line] run function evercraft:tinkering/demiurge/deepdig_line_apply
execute unless items entity @s container.* *[custom_data~{demiurges_capstone:true}] unless items entity @s weapon.offhand *[custom_data~{demiurges_capstone:true}] unless entity @s[tag=ec.sat_demiurges_capstone] unless items entity @s container.* *[custom_data~{deepdig_line:true}] if items entity @s weapon.offhand *[custom_data~{deepdig_line:true}] run function evercraft:tinkering/demiurge/deepdig_line_apply
# Node Mastery sub-binding (guarded unless the Demiurge's Spirit Artifact is held).
execute unless items entity @s container.* *[custom_data~{demiurges_capstone:true}] unless items entity @s weapon.offhand *[custom_data~{demiurges_capstone:true}] unless entity @s[tag=ec.sat_demiurges_capstone] if items entity @s container.* *[custom_data~{node_mastery:true}] run function evercraft:tinkering/demiurge/node_mastery_apply
execute unless items entity @s container.* *[custom_data~{demiurges_capstone:true}] unless items entity @s weapon.offhand *[custom_data~{demiurges_capstone:true}] unless entity @s[tag=ec.sat_demiurges_capstone] unless items entity @s container.* *[custom_data~{node_mastery:true}] unless items entity @s weapon.offhand *[custom_data~{node_mastery:true}] if entity @s[tag=ec.sat_node_mastery] run function evercraft:tinkering/demiurge/node_mastery_apply
execute unless items entity @s container.* *[custom_data~{demiurges_capstone:true}] unless items entity @s weapon.offhand *[custom_data~{demiurges_capstone:true}] unless entity @s[tag=ec.sat_demiurges_capstone] unless items entity @s container.* *[custom_data~{node_mastery:true}] if items entity @s weapon.offhand *[custom_data~{node_mastery:true}] run function evercraft:tinkering/demiurge/node_mastery_apply
# Surveyor Line sub-binding (guarded unless the Demiurge's Spirit Artifact is held; documented no-op).
execute unless items entity @s container.* *[custom_data~{demiurges_capstone:true}] unless items entity @s weapon.offhand *[custom_data~{demiurges_capstone:true}] unless entity @s[tag=ec.sat_demiurges_capstone] if items entity @s container.* *[custom_data~{surveyor_line:true}] run function evercraft:tinkering/demiurge/surveyor_line_apply
execute unless items entity @s container.* *[custom_data~{demiurges_capstone:true}] unless items entity @s weapon.offhand *[custom_data~{demiurges_capstone:true}] unless entity @s[tag=ec.sat_demiurges_capstone] unless items entity @s container.* *[custom_data~{surveyor_line:true}] unless items entity @s weapon.offhand *[custom_data~{surveyor_line:true}] if entity @s[tag=ec.sat_surveyor_line] run function evercraft:tinkering/demiurge/surveyor_line_apply
execute unless items entity @s container.* *[custom_data~{demiurges_capstone:true}] unless items entity @s weapon.offhand *[custom_data~{demiurges_capstone:true}] unless entity @s[tag=ec.sat_demiurges_capstone] unless items entity @s container.* *[custom_data~{surveyor_line:true}] if items entity @s weapon.offhand *[custom_data~{surveyor_line:true}] run function evercraft:tinkering/demiurge/surveyor_line_apply
#
# (a12) HEART OF THE MOUNTAIN tree perk re-apply (Fusion / Family L — cap-L). The grand Heart of the
#     Mountain + its four sub-caps (Bulwark Stone = tank · Titan Core = mythical defense · Ascendant Line =
#     combat-craft · Stride Line = traversal) re-grant their bound members' PER-TICK perks. The grand's
#     apply calls all four sub-cap applies (the full consolidated vanguard union: armor/health/toughness/
#     KB-resist + the ward union + +3 attack [+1 above 80% HP] + the stride). Each sub-cap grants only its
#     own slice via DISTINCT sub-cap-scoped attribute ids (NOT the loose leaf ids). The CONSOLIDATED
#     conditional +1.0 node-proximity DR (ascendant_locket_luck) is gated inside ascendant_line_apply /
#     the grand's call chain (remove-then-conditional-add on a nearby ec.cf_node_data marker). The CR
#     (+5.0) is in craft_rate/calculate (the ONE ec.cr_temp writer) gated on the held flag — NOT here. The
#     loose FAMILY L leaf adds (below) are m4-SUPPRESSED when their absorbing sub-cap/grand is held
#     (Newcomer-exempt) so loose + node never both add. Supersede order: grand FIRST (its apply re-grants
#     the whole vanguard union), then the 4 sub-caps each guarded `unless` the grand is held. Cheap-gate
#     first per node (one `if items` test each).
# Grand Heart of the Mountain FIRST (it supersedes — its apply re-grants the full per-tick vanguard union).
execute if items entity @s container.* *[custom_data~{heart_of_the_mountain:true}] run function evercraft:tinkering/heart/heart_of_the_mountain_apply
execute unless items entity @s container.* *[custom_data~{heart_of_the_mountain:true}] unless items entity @s weapon.offhand *[custom_data~{heart_of_the_mountain:true}] if entity @s[tag=ec.sat_heart_of_the_mountain] run function evercraft:tinkering/heart/heart_of_the_mountain_apply
execute unless items entity @s container.* *[custom_data~{heart_of_the_mountain:true}] if items entity @s weapon.offhand *[custom_data~{heart_of_the_mountain:true}] run function evercraft:tinkering/heart/heart_of_the_mountain_apply
# Bulwark Stone sub-binding (guarded unless the grand Heart of the Mountain is held).
execute unless items entity @s container.* *[custom_data~{heart_of_the_mountain:true}] unless items entity @s weapon.offhand *[custom_data~{heart_of_the_mountain:true}] unless entity @s[tag=ec.sat_heart_of_the_mountain] if items entity @s container.* *[custom_data~{titan_bulwark:true}] run function evercraft:tinkering/heart/titan_bulwark_apply
execute unless items entity @s container.* *[custom_data~{heart_of_the_mountain:true}] unless items entity @s weapon.offhand *[custom_data~{heart_of_the_mountain:true}] unless entity @s[tag=ec.sat_heart_of_the_mountain] unless items entity @s container.* *[custom_data~{titan_bulwark:true}] unless items entity @s weapon.offhand *[custom_data~{titan_bulwark:true}] if entity @s[tag=ec.sat_titan_bulwark] run function evercraft:tinkering/heart/titan_bulwark_apply
execute unless items entity @s container.* *[custom_data~{heart_of_the_mountain:true}] unless items entity @s weapon.offhand *[custom_data~{heart_of_the_mountain:true}] unless entity @s[tag=ec.sat_heart_of_the_mountain] unless items entity @s container.* *[custom_data~{titan_bulwark:true}] if items entity @s weapon.offhand *[custom_data~{titan_bulwark:true}] run function evercraft:tinkering/heart/titan_bulwark_apply
# Titan Core sub-binding (guarded unless the grand Heart of the Mountain is held).
execute unless items entity @s container.* *[custom_data~{heart_of_the_mountain:true}] unless items entity @s weapon.offhand *[custom_data~{heart_of_the_mountain:true}] unless entity @s[tag=ec.sat_heart_of_the_mountain] if items entity @s container.* *[custom_data~{titan_core:true}] run function evercraft:tinkering/heart/titan_core_apply
execute unless items entity @s container.* *[custom_data~{heart_of_the_mountain:true}] unless items entity @s weapon.offhand *[custom_data~{heart_of_the_mountain:true}] unless entity @s[tag=ec.sat_heart_of_the_mountain] unless items entity @s container.* *[custom_data~{titan_core:true}] unless items entity @s weapon.offhand *[custom_data~{titan_core:true}] if entity @s[tag=ec.sat_titan_core] run function evercraft:tinkering/heart/titan_core_apply
execute unless items entity @s container.* *[custom_data~{heart_of_the_mountain:true}] unless items entity @s weapon.offhand *[custom_data~{heart_of_the_mountain:true}] unless entity @s[tag=ec.sat_heart_of_the_mountain] unless items entity @s container.* *[custom_data~{titan_core:true}] if items entity @s weapon.offhand *[custom_data~{titan_core:true}] run function evercraft:tinkering/heart/titan_core_apply
# Ascendant Line sub-binding (guarded unless the grand Heart of the Mountain is held).
execute unless items entity @s container.* *[custom_data~{heart_of_the_mountain:true}] unless items entity @s weapon.offhand *[custom_data~{heart_of_the_mountain:true}] unless entity @s[tag=ec.sat_heart_of_the_mountain] if items entity @s container.* *[custom_data~{ascendant_line:true}] run function evercraft:tinkering/heart/ascendant_line_apply
execute unless items entity @s container.* *[custom_data~{heart_of_the_mountain:true}] unless items entity @s weapon.offhand *[custom_data~{heart_of_the_mountain:true}] unless entity @s[tag=ec.sat_heart_of_the_mountain] unless items entity @s container.* *[custom_data~{ascendant_line:true}] unless items entity @s weapon.offhand *[custom_data~{ascendant_line:true}] if entity @s[tag=ec.sat_ascendant_line] run function evercraft:tinkering/heart/ascendant_line_apply
execute unless items entity @s container.* *[custom_data~{heart_of_the_mountain:true}] unless items entity @s weapon.offhand *[custom_data~{heart_of_the_mountain:true}] unless entity @s[tag=ec.sat_heart_of_the_mountain] unless items entity @s container.* *[custom_data~{ascendant_line:true}] if items entity @s weapon.offhand *[custom_data~{ascendant_line:true}] run function evercraft:tinkering/heart/ascendant_line_apply
# Stride Line sub-binding (guarded unless the grand Heart of the Mountain is held).
execute unless items entity @s container.* *[custom_data~{heart_of_the_mountain:true}] unless items entity @s weapon.offhand *[custom_data~{heart_of_the_mountain:true}] unless entity @s[tag=ec.sat_heart_of_the_mountain] if items entity @s container.* *[custom_data~{stride_line:true}] run function evercraft:tinkering/heart/stride_line_apply
execute unless items entity @s container.* *[custom_data~{heart_of_the_mountain:true}] unless items entity @s weapon.offhand *[custom_data~{heart_of_the_mountain:true}] unless entity @s[tag=ec.sat_heart_of_the_mountain] unless items entity @s container.* *[custom_data~{stride_line:true}] unless items entity @s weapon.offhand *[custom_data~{stride_line:true}] if entity @s[tag=ec.sat_stride_line] run function evercraft:tinkering/heart/stride_line_apply
execute unless items entity @s container.* *[custom_data~{heart_of_the_mountain:true}] unless items entity @s weapon.offhand *[custom_data~{heart_of_the_mountain:true}] unless entity @s[tag=ec.sat_heart_of_the_mountain] unless items entity @s container.* *[custom_data~{stride_line:true}] if items entity @s weapon.offhand *[custom_data~{stride_line:true}] run function evercraft:tinkering/heart/stride_line_apply
#
# (a11) DRAGONHEART tree perk re-apply (Fusion / Family M — cap-M). The grand Dragonheart + the final-form
#     Wyrmscale Aegis + the four sub-bindings (Wyrmscale Mantle = tank/sense · Wyrmclaw Grips = melee/breath ·
#     Wyrmwing Pinions = mobility · Wyrmheart Core = the heart) re-grant their bound members' PER-TICK perks.
#     The grand's / Aegis's apply calls all four sub-cap applies (the full consolidated dragon union: armor/
#     toughness/Resistance/KB-resist/Night Vision + melee/Strength/breath-cone + Slow-Fall/airborne-Speed/
#     no-fall/void-immunity + the aura/Strength III/Fire-Res/Regen + the Wyrmsoar glide). Each sub-cap grants
#     only its own slice via DISTINCT sub-cap-scoped attribute ids (NOT the loose leaf ids). MIXED-DR (like
#     Family A/B): each sub-cap apply emits its OWN consolidated *_luck (Mantle +4.5 / Grips +5.0 / Pinions
#     +5.0 / Core +6.5); the grand re-calls them then STRIPS the four sub-cap ids and emits the single
#     consolidated dragonheart_luck +21.0 (the FULL union, no nerf fence — the Reliquary idiom). The +40
#     (10%) dodge is the Aegis's OWN dodge pinnacle in the m1 ec.acc_dodge LEAF block at the top of this file
#     (one writer) — NOT here. The Family-M leaves carry NO loose *_luck (DR is realized only on fusion), so
#     there are no loose-member luck strips to do here. Supersede order: Aegis FIRST (its apply re-grants the
#     whole union + the grand's id is stripped inside it), then the grand `unless` the Aegis, then the four
#     sub-caps each guarded `unless` the Aegis AND `unless` the grand. Cheap-gate first per node (one
#     `if items` test each).
# Final-form Wyrmscale Aegis FIRST (it supersedes everything — its apply re-grants the full union + strips
# the grand's dragonheart_luck).
execute if items entity @s container.* *[custom_data~{wyrmscale_aegis:true}] run function evercraft:tinkering/dragonheart/wyrmscale_aegis_apply
execute unless items entity @s container.* *[custom_data~{wyrmscale_aegis:true}] unless items entity @s weapon.offhand *[custom_data~{wyrmscale_aegis:true}] if entity @s[tag=ec.sat_wyrmscale_aegis] run function evercraft:tinkering/dragonheart/wyrmscale_aegis_apply
execute unless items entity @s container.* *[custom_data~{wyrmscale_aegis:true}] if items entity @s weapon.offhand *[custom_data~{wyrmscale_aegis:true}] run function evercraft:tinkering/dragonheart/wyrmscale_aegis_apply
# Grand Dragonheart (guarded unless the Aegis is held — it supersedes the four sub-caps).
execute unless items entity @s container.* *[custom_data~{wyrmscale_aegis:true}] unless items entity @s weapon.offhand *[custom_data~{wyrmscale_aegis:true}] unless entity @s[tag=ec.sat_wyrmscale_aegis] if items entity @s container.* *[custom_data~{dragonheart:true}] run function evercraft:tinkering/dragonheart/dragonheart_apply
execute unless items entity @s container.* *[custom_data~{wyrmscale_aegis:true}] unless items entity @s weapon.offhand *[custom_data~{wyrmscale_aegis:true}] unless entity @s[tag=ec.sat_wyrmscale_aegis] unless items entity @s container.* *[custom_data~{dragonheart:true}] unless items entity @s weapon.offhand *[custom_data~{dragonheart:true}] if entity @s[tag=ec.sat_dragonheart] run function evercraft:tinkering/dragonheart/dragonheart_apply
execute unless items entity @s container.* *[custom_data~{wyrmscale_aegis:true}] unless items entity @s weapon.offhand *[custom_data~{wyrmscale_aegis:true}] unless entity @s[tag=ec.sat_wyrmscale_aegis] unless items entity @s container.* *[custom_data~{dragonheart:true}] if items entity @s weapon.offhand *[custom_data~{dragonheart:true}] run function evercraft:tinkering/dragonheart/dragonheart_apply
# Wyrmscale Mantle sub-binding (guarded unless the Aegis AND unless the grand Dragonheart is held).
execute unless items entity @s container.* *[custom_data~{wyrmscale_aegis:true}] unless items entity @s weapon.offhand *[custom_data~{wyrmscale_aegis:true}] unless entity @s[tag=ec.sat_wyrmscale_aegis] unless items entity @s container.* *[custom_data~{dragonheart:true}] unless items entity @s weapon.offhand *[custom_data~{dragonheart:true}] unless entity @s[tag=ec.sat_dragonheart] if items entity @s container.* *[custom_data~{wyrmscale_mantle:true}] run function evercraft:tinkering/dragonheart/wyrmscale_mantle_apply
execute unless items entity @s container.* *[custom_data~{wyrmscale_aegis:true}] unless items entity @s weapon.offhand *[custom_data~{wyrmscale_aegis:true}] unless entity @s[tag=ec.sat_wyrmscale_aegis] unless items entity @s container.* *[custom_data~{dragonheart:true}] unless items entity @s weapon.offhand *[custom_data~{dragonheart:true}] unless entity @s[tag=ec.sat_dragonheart] unless items entity @s container.* *[custom_data~{wyrmscale_mantle:true}] unless items entity @s weapon.offhand *[custom_data~{wyrmscale_mantle:true}] if entity @s[tag=ec.sat_wyrmscale_mantle] run function evercraft:tinkering/dragonheart/wyrmscale_mantle_apply
execute unless items entity @s container.* *[custom_data~{wyrmscale_aegis:true}] unless items entity @s weapon.offhand *[custom_data~{wyrmscale_aegis:true}] unless entity @s[tag=ec.sat_wyrmscale_aegis] unless items entity @s container.* *[custom_data~{dragonheart:true}] unless items entity @s weapon.offhand *[custom_data~{dragonheart:true}] unless entity @s[tag=ec.sat_dragonheart] unless items entity @s container.* *[custom_data~{wyrmscale_mantle:true}] if items entity @s weapon.offhand *[custom_data~{wyrmscale_mantle:true}] run function evercraft:tinkering/dragonheart/wyrmscale_mantle_apply
# Wyrmclaw Grips sub-binding (guarded unless the Aegis AND unless the grand Dragonheart is held).
execute unless items entity @s container.* *[custom_data~{wyrmscale_aegis:true}] unless items entity @s weapon.offhand *[custom_data~{wyrmscale_aegis:true}] unless entity @s[tag=ec.sat_wyrmscale_aegis] unless items entity @s container.* *[custom_data~{dragonheart:true}] unless items entity @s weapon.offhand *[custom_data~{dragonheart:true}] unless entity @s[tag=ec.sat_dragonheart] if items entity @s container.* *[custom_data~{wyrmclaw_grips:true}] run function evercraft:tinkering/dragonheart/wyrmclaw_grips_apply
execute unless items entity @s container.* *[custom_data~{wyrmscale_aegis:true}] unless items entity @s weapon.offhand *[custom_data~{wyrmscale_aegis:true}] unless entity @s[tag=ec.sat_wyrmscale_aegis] unless items entity @s container.* *[custom_data~{dragonheart:true}] unless items entity @s weapon.offhand *[custom_data~{dragonheart:true}] unless entity @s[tag=ec.sat_dragonheart] unless items entity @s container.* *[custom_data~{wyrmclaw_grips:true}] unless items entity @s weapon.offhand *[custom_data~{wyrmclaw_grips:true}] if entity @s[tag=ec.sat_wyrmclaw_grips] run function evercraft:tinkering/dragonheart/wyrmclaw_grips_apply
execute unless items entity @s container.* *[custom_data~{wyrmscale_aegis:true}] unless items entity @s weapon.offhand *[custom_data~{wyrmscale_aegis:true}] unless entity @s[tag=ec.sat_wyrmscale_aegis] unless items entity @s container.* *[custom_data~{dragonheart:true}] unless items entity @s weapon.offhand *[custom_data~{dragonheart:true}] unless entity @s[tag=ec.sat_dragonheart] unless items entity @s container.* *[custom_data~{wyrmclaw_grips:true}] if items entity @s weapon.offhand *[custom_data~{wyrmclaw_grips:true}] run function evercraft:tinkering/dragonheart/wyrmclaw_grips_apply
# Wyrmwing Pinions sub-binding (guarded unless the Aegis AND unless the grand Dragonheart is held).
execute unless items entity @s container.* *[custom_data~{wyrmscale_aegis:true}] unless items entity @s weapon.offhand *[custom_data~{wyrmscale_aegis:true}] unless entity @s[tag=ec.sat_wyrmscale_aegis] unless items entity @s container.* *[custom_data~{dragonheart:true}] unless items entity @s weapon.offhand *[custom_data~{dragonheart:true}] unless entity @s[tag=ec.sat_dragonheart] if items entity @s container.* *[custom_data~{wyrmwing_pinions:true}] run function evercraft:tinkering/dragonheart/wyrmwing_pinions_apply
execute unless items entity @s container.* *[custom_data~{wyrmscale_aegis:true}] unless items entity @s weapon.offhand *[custom_data~{wyrmscale_aegis:true}] unless entity @s[tag=ec.sat_wyrmscale_aegis] unless items entity @s container.* *[custom_data~{dragonheart:true}] unless items entity @s weapon.offhand *[custom_data~{dragonheart:true}] unless entity @s[tag=ec.sat_dragonheart] unless items entity @s container.* *[custom_data~{wyrmwing_pinions:true}] unless items entity @s weapon.offhand *[custom_data~{wyrmwing_pinions:true}] if entity @s[tag=ec.sat_wyrmwing_pinions] run function evercraft:tinkering/dragonheart/wyrmwing_pinions_apply
execute unless items entity @s container.* *[custom_data~{wyrmscale_aegis:true}] unless items entity @s weapon.offhand *[custom_data~{wyrmscale_aegis:true}] unless entity @s[tag=ec.sat_wyrmscale_aegis] unless items entity @s container.* *[custom_data~{dragonheart:true}] unless items entity @s weapon.offhand *[custom_data~{dragonheart:true}] unless entity @s[tag=ec.sat_dragonheart] unless items entity @s container.* *[custom_data~{wyrmwing_pinions:true}] if items entity @s weapon.offhand *[custom_data~{wyrmwing_pinions:true}] run function evercraft:tinkering/dragonheart/wyrmwing_pinions_apply
# Wyrmheart Core sub-binding (guarded unless the Aegis AND unless the grand Dragonheart is held).
execute unless items entity @s container.* *[custom_data~{wyrmscale_aegis:true}] unless items entity @s weapon.offhand *[custom_data~{wyrmscale_aegis:true}] unless entity @s[tag=ec.sat_wyrmscale_aegis] unless items entity @s container.* *[custom_data~{dragonheart:true}] unless items entity @s weapon.offhand *[custom_data~{dragonheart:true}] unless entity @s[tag=ec.sat_dragonheart] if items entity @s container.* *[custom_data~{wyrmheart_core:true}] run function evercraft:tinkering/dragonheart/wyrmheart_core_apply
execute unless items entity @s container.* *[custom_data~{wyrmscale_aegis:true}] unless items entity @s weapon.offhand *[custom_data~{wyrmscale_aegis:true}] unless entity @s[tag=ec.sat_wyrmscale_aegis] unless items entity @s container.* *[custom_data~{dragonheart:true}] unless items entity @s weapon.offhand *[custom_data~{dragonheart:true}] unless entity @s[tag=ec.sat_dragonheart] unless items entity @s container.* *[custom_data~{wyrmheart_core:true}] unless items entity @s weapon.offhand *[custom_data~{wyrmheart_core:true}] if entity @s[tag=ec.sat_wyrmheart_core] run function evercraft:tinkering/dragonheart/wyrmheart_core_apply
execute unless items entity @s container.* *[custom_data~{wyrmscale_aegis:true}] unless items entity @s weapon.offhand *[custom_data~{wyrmscale_aegis:true}] unless entity @s[tag=ec.sat_wyrmscale_aegis] unless items entity @s container.* *[custom_data~{dragonheart:true}] unless items entity @s weapon.offhand *[custom_data~{dragonheart:true}] unless entity @s[tag=ec.sat_dragonheart] unless items entity @s container.* *[custom_data~{wyrmheart_core:true}] if items entity @s weapon.offhand *[custom_data~{wyrmheart_core:true}] run function evercraft:tinkering/dragonheart/wyrmheart_core_apply
# Cleanup: strip each Dragonheart-tree consolidated luck modifier when its item is no longer held. Each uses
# its OWN distinct id, so the strips never clobber an active sibling. (When the item IS held its apply re-adds
# the value later in the same tick; accessory_cleanup runs before this block, but these strips here cover the
# not-held case for the consolidated ids specifically — the dreamers_reliquary idiom at :312.)
execute unless items entity @s container.* *[custom_data~{wyrmscale_aegis:true}] unless items entity @s weapon.offhand *[custom_data~{wyrmscale_aegis:true}] unless entity @s[tag=ec.sat_wyrmscale_aegis] run attribute @s luck modifier remove evercraft:wyrmscale_aegis_luck
execute unless items entity @s container.* *[custom_data~{dragonheart:true}] unless items entity @s weapon.offhand *[custom_data~{dragonheart:true}] unless entity @s[tag=ec.sat_dragonheart] unless items entity @s container.* *[custom_data~{wyrmscale_aegis:true}] unless items entity @s weapon.offhand *[custom_data~{wyrmscale_aegis:true}] unless entity @s[tag=ec.sat_wyrmscale_aegis] run attribute @s luck modifier remove evercraft:dragonheart_luck
execute unless items entity @s container.* *[custom_data~{wyrmscale_mantle:true}] unless items entity @s weapon.offhand *[custom_data~{wyrmscale_mantle:true}] unless entity @s[tag=ec.sat_wyrmscale_mantle] unless items entity @s container.* *[custom_data~{dragonheart:true}] unless items entity @s weapon.offhand *[custom_data~{dragonheart:true}] unless entity @s[tag=ec.sat_dragonheart] unless items entity @s container.* *[custom_data~{wyrmscale_aegis:true}] unless items entity @s weapon.offhand *[custom_data~{wyrmscale_aegis:true}] unless entity @s[tag=ec.sat_wyrmscale_aegis] run attribute @s luck modifier remove evercraft:wyrmscale_mantle_luck
execute unless items entity @s container.* *[custom_data~{wyrmclaw_grips:true}] unless items entity @s weapon.offhand *[custom_data~{wyrmclaw_grips:true}] unless entity @s[tag=ec.sat_wyrmclaw_grips] unless items entity @s container.* *[custom_data~{dragonheart:true}] unless items entity @s weapon.offhand *[custom_data~{dragonheart:true}] unless entity @s[tag=ec.sat_dragonheart] unless items entity @s container.* *[custom_data~{wyrmscale_aegis:true}] unless items entity @s weapon.offhand *[custom_data~{wyrmscale_aegis:true}] unless entity @s[tag=ec.sat_wyrmscale_aegis] run attribute @s luck modifier remove evercraft:wyrmclaw_grips_luck
execute unless items entity @s container.* *[custom_data~{wyrmwing_pinions:true}] unless items entity @s weapon.offhand *[custom_data~{wyrmwing_pinions:true}] unless entity @s[tag=ec.sat_wyrmwing_pinions] unless items entity @s container.* *[custom_data~{dragonheart:true}] unless items entity @s weapon.offhand *[custom_data~{dragonheart:true}] unless entity @s[tag=ec.sat_dragonheart] unless items entity @s container.* *[custom_data~{wyrmscale_aegis:true}] unless items entity @s weapon.offhand *[custom_data~{wyrmscale_aegis:true}] unless entity @s[tag=ec.sat_wyrmscale_aegis] run attribute @s luck modifier remove evercraft:wyrmwing_pinions_luck
execute unless items entity @s container.* *[custom_data~{wyrmheart_core:true}] unless items entity @s weapon.offhand *[custom_data~{wyrmheart_core:true}] unless entity @s[tag=ec.sat_wyrmheart_core] unless items entity @s container.* *[custom_data~{dragonheart:true}] unless items entity @s weapon.offhand *[custom_data~{dragonheart:true}] unless entity @s[tag=ec.sat_dragonheart] unless items entity @s container.* *[custom_data~{wyrmscale_aegis:true}] unless items entity @s weapon.offhand *[custom_data~{wyrmscale_aegis:true}] unless entity @s[tag=ec.sat_wyrmscale_aegis] run attribute @s luck modifier remove evercraft:wyrmheart_core_luck
# Cleanup: strip the Dragonheart tree's DISTINCT sub-cap-scoped attribute modifiers when neither the
# matching sub-cap NOR the grand NOR the Aegis is held (the heart/titan_bulwark cleanup idiom). The sub-cap
# applies re-add these `add`-form fixed-id modifiers each tick; these strips cover the not-held case so they
# do not linger as a ghost buff after the item leaves.
execute unless items entity @s container.* *[custom_data~{wyrmscale_mantle:true}] unless items entity @s weapon.offhand *[custom_data~{wyrmscale_mantle:true}] unless entity @s[tag=ec.sat_wyrmscale_mantle] unless items entity @s container.* *[custom_data~{dragonheart:true}] unless items entity @s weapon.offhand *[custom_data~{dragonheart:true}] unless entity @s[tag=ec.sat_dragonheart] unless items entity @s container.* *[custom_data~{wyrmscale_aegis:true}] unless items entity @s weapon.offhand *[custom_data~{wyrmscale_aegis:true}] unless entity @s[tag=ec.sat_wyrmscale_aegis] run attribute @s armor_toughness modifier remove evercraft:wyrmscale_mantle_tough
execute unless items entity @s container.* *[custom_data~{wyrmscale_mantle:true}] unless items entity @s weapon.offhand *[custom_data~{wyrmscale_mantle:true}] unless entity @s[tag=ec.sat_wyrmscale_mantle] unless items entity @s container.* *[custom_data~{dragonheart:true}] unless items entity @s weapon.offhand *[custom_data~{dragonheart:true}] unless entity @s[tag=ec.sat_dragonheart] unless items entity @s container.* *[custom_data~{wyrmscale_aegis:true}] unless items entity @s weapon.offhand *[custom_data~{wyrmscale_aegis:true}] unless entity @s[tag=ec.sat_wyrmscale_aegis] run attribute @s knockback_resistance modifier remove evercraft:wyrmscale_mantle_kb
execute unless items entity @s container.* *[custom_data~{wyrmclaw_grips:true}] unless items entity @s weapon.offhand *[custom_data~{wyrmclaw_grips:true}] unless entity @s[tag=ec.sat_wyrmclaw_grips] unless items entity @s container.* *[custom_data~{dragonheart:true}] unless items entity @s weapon.offhand *[custom_data~{dragonheart:true}] unless entity @s[tag=ec.sat_dragonheart] unless items entity @s container.* *[custom_data~{wyrmscale_aegis:true}] unless items entity @s weapon.offhand *[custom_data~{wyrmscale_aegis:true}] unless entity @s[tag=ec.sat_wyrmscale_aegis] run attribute @s attack_damage modifier remove evercraft:wyrmclaw_grips_atk
execute unless items entity @s container.* *[custom_data~{wyrmwing_pinions:true}] unless items entity @s weapon.offhand *[custom_data~{wyrmwing_pinions:true}] unless entity @s[tag=ec.sat_wyrmwing_pinions] unless items entity @s container.* *[custom_data~{dragonheart:true}] unless items entity @s weapon.offhand *[custom_data~{dragonheart:true}] unless entity @s[tag=ec.sat_dragonheart] unless items entity @s container.* *[custom_data~{wyrmscale_aegis:true}] unless items entity @s weapon.offhand *[custom_data~{wyrmscale_aegis:true}] unless entity @s[tag=ec.sat_wyrmscale_aegis] run attribute @s fall_damage_multiplier modifier remove evercraft:wyrmwing_pinions_fall
#
# (a10-DR) CORNUCOPIA TIDE / TIDEWRIGHT'S NET consolidated CONDITIONAL Dream Rate (cap-J). The ONLY DR in
#     Family J lives on the two fishing charms (Riverpearl +2 while fishing + Deepcurrent +3 in water).
#     The grand + the Net each consolidate BOTH into ONE +5.0 modifier that fires while fishing OR in
#     water (the union of the two loose conditions — additive but condition-gated). Remove-then-
#     conditional-add (the Geologist's Loupe / Demiurge idiom): the bare remove handles not-held AND
#     not-active; the add fires only while held + (fishing-rod-in-mainhand OR in_water). Fixed-id
#     (idempotent — two copies overwrite, m4 multi-copy-safe). ec._a single-scan. Each reports ONE line
#     in dreams/breakdown/artifacts (the loose Riverpearl/Deepcurrent lines self-hide because the m4
#     suppress-at-source in the FAMILY J LEAVES block skips their loose adds when an absorbing node is
#     held, so those loose ids never become active alongside the consolidated fold).
# Grand Cornucopia Tide — consolidated +5.0 while fishing OR in water (ONE line).
tag @s remove ec._a
execute if items entity @s container.* *[custom_data~{cornucopia_tide:true}] run tag @s add ec._a
execute unless items entity @s container.* *[custom_data~{cornucopia_tide:true}] unless items entity @s weapon.offhand *[custom_data~{cornucopia_tide:true}] if entity @s[tag=ec.sat_cornucopia_tide] run tag @s add ec._a
execute unless entity @s[tag=ec._a] if items entity @s weapon.offhand *[custom_data~{cornucopia_tide:true}] run tag @s add ec._a
execute if entity @s[tag=ec._a] run attribute @s luck modifier remove evercraft:cornucopia_tide_luck
execute if entity @s[tag=ec._a] if items entity @s weapon.mainhand minecraft:fishing_rod run attribute @s luck modifier add evercraft:cornucopia_tide_luck 5.0 add_value
execute if entity @s[tag=ec._a] unless items entity @s weapon.mainhand minecraft:fishing_rod if predicate evercraft:in_water run attribute @s luck modifier add evercraft:cornucopia_tide_luck 5.0 add_value
tag @s remove ec._a
# Tidewright's Net — consolidated +5.0 while fishing OR in water (ONE line), unless the grand is held
# (the grand supersedes — its cornucopia_tide_luck already covers it).
execute unless items entity @s container.* *[custom_data~{cornucopia_tide:true}] unless items entity @s weapon.offhand *[custom_data~{cornucopia_tide:true}] unless entity @s[tag=ec.sat_cornucopia_tide] if items entity @s container.* *[custom_data~{tidewrights_net:true}] run tag @s add ec._a
execute unless items entity @s container.* *[custom_data~{cornucopia_tide:true}] unless items entity @s weapon.offhand *[custom_data~{cornucopia_tide:true}] unless entity @s[tag=ec.sat_cornucopia_tide] unless items entity @s container.* *[custom_data~{tidewrights_net:true}] unless items entity @s weapon.offhand *[custom_data~{tidewrights_net:true}] if entity @s[tag=ec.sat_tidewrights_net] run tag @s add ec._a
execute unless items entity @s container.* *[custom_data~{cornucopia_tide:true}] unless items entity @s weapon.offhand *[custom_data~{cornucopia_tide:true}] unless entity @s[tag=ec.sat_cornucopia_tide] unless entity @s[tag=ec._a] if items entity @s weapon.offhand *[custom_data~{tidewrights_net:true}] run tag @s add ec._a
execute if entity @s[tag=ec._a] run attribute @s luck modifier remove evercraft:tidewright_luck
execute if entity @s[tag=ec._a] if items entity @s weapon.mainhand minecraft:fishing_rod run attribute @s luck modifier add evercraft:tidewright_luck 5.0 add_value
execute if entity @s[tag=ec._a] unless items entity @s weapon.mainhand minecraft:fishing_rod if predicate evercraft:in_water run attribute @s luck modifier add evercraft:tidewright_luck 5.0 add_value
tag @s remove ec._a
# (a10-m4) MULTI-COPY STRIP (D-MULTICOPY / m4, Layer 1: the absorbing node supersedes its loose fishing-
#     DR pieces) is enforced at the SOURCE: the loose Riverpearl Charm + Deepcurrent Reliquary add-lines
#     in the FAMILY J LEAVES block (far below) carry an `unless` guard against an absorbing node
#     (Tidewright's Net OR the grand Cornucopia Tide), Newcomer-exempt (`unless ec.difficulty matches 1`).
#     This is the cap-G / cap-H SUPPRESS-AT-SOURCE idiom (NOT a post-hoc strip here) — it is order-robust
#     because the loose add never fires when the absorbing node is held on Adventurer/Pioneer, so a
#     re-acquired loose copy cannot double-dip the conditional DR. Casual Newcomer players keep the
#     forgiving double-dip stack. The cook-quality / CR / crate / crop-yield levers are scoreboard
#     set-not-add / id-presence rolls suppressed in their own funnel hooks (resolve / calculate /
#     on_catch / harvest_bonus_read), so only the two modifier-DR leaves need the source guard.
#
# (b) ACCESSORY-PAIR OFFER detector — fire the one-shot Tinkering begin-offer the FIRST time a
#     player holds >=2 accessories at once (F). ONE gated line: only when the player is NOT
#     already on (or past) the line (ec.tnk_active 0) AND has not already been offered
#     (ec.tnk_offer 0) AND holds >=2 accessory items. We reuse the file's existing accessory
#     scan via a store-result count (no new iteration). The detector calls
#     tinkering/on_get_accessory_pair (which re-guards + latches ec.tnk_offer).
execute if score @s ec.tnk_active matches 0 if score @s ec.tnk_offer matches 0 run function evercraft:tinkering/offer_check

# === REGEN FALLBACK SYSTEM ===
# Detect if player already has Regen II+ (campfire boost / golden apple / harmonize)
# Regen artifacts switch to instant_health when regen would be wasted
# OPT: Predicate check replaces 2 NBT active_effects deep scans (amplifier min:1 = has regen AND level II+)
tag @s remove ec.regen_capped
execute if predicate evercraft:has_regen_above_0 run tag @s add ec.regen_capped
# Decrement instant-heal cooldown (shared across all regen artifacts)
execute if score @s ec.regen_ih_cd matches 1.. run scoreboard players remove @s ec.regen_ih_cd 1
# Decrement death-save cooldowns (Soul Protection 3min, Void Heart 5min, Phoenix Totem 5min)
execute if score @s ec.cd_soul matches 1.. run scoreboard players remove @s ec.cd_soul 1
execute if score @s ec.cd_void matches 1.. run scoreboard players remove @s ec.cd_void 1
execute if score @s ec.cd_phoenix matches 1.. run scoreboard players remove @s ec.cd_phoenix 1
# Decrement the SHARED Soulguard death-save bucket (Soulguard Aegis tree, cap-D — G6: ONE bucket for
# ALL D revives, 5min). SET by artifacts/abilities/soulguard_save; this is the single tick-down site
# (the same source-set + tick-decrement cooldown idiom as ec.cd_soul / cd_void / cd_phoenix above).
execute if score @s ec.cd_save matches 1.. run scoreboard players remove @s ec.cd_save 1
# Decrement the Heart of the Void's Void Blink dash cooldown (5s). SET to 5 in the heart_of_the_void
# block below; this is the single tick-down site (same source-set + tick-decrement idiom as the cd_*
# death-save cooldowns above — NOT a one-writer violation). 1s cadence -> set-to-5 = 5 real seconds.
execute if score @s ec.cd_void_blink matches 1.. run scoreboard players remove @s ec.cd_void_blink 1
# Decrement the Prism of Light's Radiance damage cadence (so the 24b 1dmg/s aura fires ONCE per second
# instead of every player_tick). SET to 1 in the prism_of_light block below; tick-down here.
execute if score @s ec.pol_dmgcd matches 1.. run scoreboard players remove @s ec.pol_dmgcd 1
# Decrement the Ring of Undying revive cooldown (2min) + Temporal Hourglass Chrono Rewind cooldown (4min).
# Each is a custom death-save (Absorption IV revive) SET in its own _save fn below; this is the single
# tick-down site for each (one writer beside the source-set). 1s cadence -> the SET value is in SECONDS.
execute if score @s ec.cd_undying_rev matches 1.. run scoreboard players remove @s ec.cd_undying_rev 1
execute if score @s ec.cd_chrono matches 1.. run scoreboard players remove @s ec.cd_chrono 1
# Decrement the Wither Rose Crown "Soul Harvest" stack window (30s, SET in wither_crown_soul_harvest;
# single tick-down site). When the window closes the soul stack resets — ungated so a dropped crown
# still decays cleanly. 1s cadence -> VALUE = SECONDS.
execute if score @s ec.wrc_t matches 1.. run scoreboard players remove @s ec.wrc_t 1
execute unless score @s ec.wrc_t matches 1.. if score @s ec.wrc_souls matches 1.. run scoreboard players set @s ec.wrc_souls 0
# Decrement the Phoenix Feather "Rebirth" death-save cooldown (10min). SET in phoenix_feather_save;
# this is the single tick-down site (one writer beside the source-set). 1s cadence -> VALUE = SECONDS.
execute if score @s ec.cd_feather matches 1.. run scoreboard players remove @s ec.cd_feather 1
# Decrement the Fireforged 4pc "Phoenix Rebirth" set death-save cooldown (3600s = 1 hour). SET in
# fireforged_4pc_save; this is the single tick-down site (one writer beside the source-set). SECONDS.
execute if score @s ec.fireforged_cd matches 1.. run scoreboard players remove @s ec.fireforged_cd 1
# Decrement the Ninja 4pc "Shadow Step" sneak-blink cooldown (5s) + the Space 4pc "Meteor Strike" sneak-
# active cooldown (8s). Each SET in its set's bonus_4pc; this is the single tick-down site for each (one
# writer beside the source-set). 1s cadence -> VALUE = SECONDS.
execute if score @s ec.cd_ninja matches 1.. run scoreboard players remove @s ec.cd_ninja 1
execute if score @s ec.cd_space matches 1.. run scoreboard players remove @s ec.cd_space 1
# Decrement the Ender Dragon Scale "Dragon Ascendant" sneak-active cooldown (15s) + the Redstone Heart
# "Overclock" sneak-active cooldown (30s). SET in ender_dragon_scale_ascend / redstone_heart_overclock;
# this is the single tick-down site for each (one writer beside the source-set). 1s cadence -> SECONDS.
execute if score @s ec.cd_dragon matches 1.. run scoreboard players remove @s ec.cd_dragon 1
execute if score @s ec.cd_overclock matches 1.. run scoreboard players remove @s ec.cd_overclock 1
# Decrement the Titan's Plate "Titan's Bulwark" sneak-active brace cooldown (12s). SET in titans_brace;
# single tick-down site (one writer beside the source-set). 1s cadence -> VALUE = SECONDS.
execute if score @s ec.cd_titan matches 1.. run scoreboard players remove @s ec.cd_titan 1
# Decrement the Steady-Hand Caliper placement-ghost debounce (U16, art-F; SET to 6 in caliper_ghost).
# Source-set + tick-decrement cooldown idiom (same shape as the cd_* death-save cooldowns above —
# NOT a one-writer violation). Without this the ghost would lock after one render.
execute if score @s ec.cal_ghostcd matches 1.. run scoreboard players remove @s ec.cal_ghostcd 1
# Decrement the craft/mine activity window (Family B conditional-DR leaves — art-B). SET to 100t
# by craft_affinity/grant_verb on each qualifying verb; counts down here (same idiom as the
# death-save cooldowns above). Read by Geologist's Loupe / Cache-Eye / Worldforge Ember below +
# the Demiurge's Spirit Artifact consolidated mining-DR (Family K).
execute if score @s ec.cf_actwin matches 1.. run scoreboard players remove @s ec.cf_actwin 1
# Decrement the Family-K prospector sneak-survey debounce (art-K; SET to 40-60t by the K survey fns:
# plumb_depth / echo_pulse / loupe_sample / resonator_ping / dowsing_ping / sort_pulse). Source-set +
# tick-decrement cooldown idiom (same shape as cal_ghostcd / the cd_* death-saves — NOT a one-writer
# violation). Without this the K survey items would lock after one pulse.
execute if score @s ec.pr_pingcd matches 1.. run scoreboard players remove @s ec.pr_pingcd 1
# Decrement the Family-C WAYFARER sneak-survey debounce cooldowns (cap-C BUGFIX). ec.wf_pingcd is SET
# to 60t by wayfarer/structure_ping; ec.wf_cyccd is SET to 16t by wayfarer/sextant_cycle + codex_cycle.
# art-C SET both but NEVER decremented them anywhere (a latent bug art-F flagged in load.mcfunction) —
# so the loose Wayfarer survey/cycle items + the cap-C capstone nodes would LOCK after one use. Same
# source-set + tick-decrement cooldown idiom as cal_ghostcd / pr_pingcd / the cd_* death-saves (NOT a
# one-writer violation — the survey fns are the source-setters, this is the single tick-down site).
execute if score @s ec.wf_pingcd matches 1.. run scoreboard players remove @s ec.wf_pingcd 1
execute if score @s ec.wf_cyccd matches 1.. run scoreboard players remove @s ec.wf_cyccd 1

# ============================================================
# === COMMON ACCESSORIES ===
# ============================================================

# Pebble of Dreams — +1 Dream Rate
execute if items entity @s container.* *[custom_data~{artifact:"pebble_of_dreams"}] unless score @s ec.t_pebble matches 1 run attribute @s luck modifier add evercraft:pebble_of_dreams_luck 1.0 add_value
execute unless items entity @s container.* *[custom_data~{artifact:"pebble_of_dreams"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"pebble_of_dreams"}] if entity @s[tag=ec.sat_pebble_of_dreams] unless score @s ec.t_pebble matches 1 run attribute @s luck modifier add evercraft:pebble_of_dreams_luck 1.0 add_value
execute if items entity @s weapon.offhand *[custom_data~{artifact:"pebble_of_dreams"}] unless score @s ec.t_pebble matches 1 run attribute @s luck modifier add evercraft:pebble_of_dreams_luck 1.0 add_value

# Travelers Charm — Speed I
execute if items entity @s container.* *[custom_data~{artifact:"travelers_charm"}] unless score @s ec.t_traveler matches 1 run effect give @s speed 5 0 false
execute unless items entity @s container.* *[custom_data~{artifact:"travelers_charm"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"travelers_charm"}] if entity @s[tag=ec.sat_travelers_charm] unless score @s ec.t_traveler matches 1 run effect give @s speed 5 0 false
execute if items entity @s weapon.offhand *[custom_data~{artifact:"travelers_charm"}] unless score @s ec.t_traveler matches 1 run effect give @s speed 5 0 false

# Worn Compass — Slow Falling when below Y=0
execute if entity @s[y=-64,dy=64] if items entity @s container.* *[custom_data~{artifact:"worn_compass"}] unless score @s ec.t_wcompass matches 1 run effect give @s slow_falling 5 0 false
execute if entity @s[y=-64,dy=64] unless items entity @s container.* *[custom_data~{artifact:"worn_compass"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"worn_compass"}] if entity @s[tag=ec.sat_worn_compass] unless score @s ec.t_wcompass matches 1 run effect give @s slow_falling 5 0 false
execute if entity @s[y=-64,dy=64] if items entity @s weapon.offhand *[custom_data~{artifact:"worn_compass"}] unless score @s ec.t_wcompass matches 1 run effect give @s slow_falling 5 0 false

# Wishing Shard — +1 Dream Rate (Family B new leaf — art-B; clean common DR leaf, fuses into the
# Lucky Charm starter). Fixed-id modifier (idempotent — two copies overwrite to one +1.0, never
# stack: m4 Layer-2 by construction). Cleanup in accessory_cleanup strips it on removal.
execute if items entity @s container.* *[custom_data~{artifact:"wishing_shard"}] run attribute @s luck modifier add evercraft:wishing_shard_luck 1.0 add_value
execute unless items entity @s container.* *[custom_data~{artifact:"wishing_shard"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"wishing_shard"}] if entity @s[tag=ec.sat_wishing_shard] run attribute @s luck modifier add evercraft:wishing_shard_luck 1.0 add_value
execute if items entity @s weapon.offhand *[custom_data~{artifact:"wishing_shard"}] run attribute @s luck modifier add evercraft:wishing_shard_luck 1.0 add_value

# ============================================================
# === FAMILY C — WAYFARER (Sense & Travel) PASSIVE PERKS (art-C) ===
# ============================================================
# The Wayfarer leaves' ALWAYS-WHILE-HELD halves (the sneak-triggered survey/cycle halves live in the
# MOB VISION ACTIVATION block near the bottom). NO DR (balance-neutral bundle). Every readout is a
# pure data-read -> one title actionbar (no scan); the light is one setblock per move w/ strict
# prev-cell cleanup; the Far-Lens waypoint perk is a real attribute. Each is item-gated so a player
# holding no Wayfarer piece pays only the `if items` test. ec._a consolidates container.*+offhand.
#
# U1 Wayworn Tally + #5 Cartographer's Astrolabe — persistent coord+facing readout, SUPPRESSED while
# sneaking (U1 "toggles off when sneaking"; the Astrolabe yields its sneak key to its survey ping).
execute unless predicate evercraft:sneaking if items entity @s container.* *[custom_data~{artifact:"wayworn_tally"}] run tag @s add ec._a
execute unless predicate evercraft:sneaking unless items entity @s container.* *[custom_data~{artifact:"wayworn_tally"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"wayworn_tally"}] if entity @s[tag=ec.sat_wayworn_tally] run tag @s add ec._a
execute unless predicate evercraft:sneaking unless entity @s[tag=ec._a] if items entity @s weapon.offhand *[custom_data~{artifact:"wayworn_tally"}] run tag @s add ec._a
execute unless predicate evercraft:sneaking unless entity @s[tag=ec._a] if items entity @s container.* *[custom_data~{artifact:"cartographers_astrolabe"}] run tag @s add ec._a
execute unless predicate evercraft:sneaking unless entity @s[tag=ec._a] unless items entity @s container.* *[custom_data~{artifact:"cartographers_astrolabe"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"cartographers_astrolabe"}] if entity @s[tag=ec.sat_cartographers_astrolabe] run tag @s add ec._a
execute unless predicate evercraft:sneaking unless entity @s[tag=ec._a] if items entity @s weapon.offhand *[custom_data~{artifact:"cartographers_astrolabe"}] run tag @s add ec._a
execute if entity @s[tag=ec._a] run function evercraft:artifacts/accessories/wayfarer/coord_readout
tag @s remove ec._a
#
# U5 Lantern-Lichen Clasp — transient local light at the foot cell, single-prev-cell cleanup on move.
execute if items entity @s container.* *[custom_data~{artifact:"lantern_lichen_clasp"}] run tag @s add ec._a
execute unless items entity @s container.* *[custom_data~{artifact:"lantern_lichen_clasp"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"lantern_lichen_clasp"}] if entity @s[tag=ec.sat_lantern_lichen_clasp] run tag @s add ec._a
execute unless entity @s[tag=ec._a] if items entity @s weapon.offhand *[custom_data~{artifact:"lantern_lichen_clasp"}] run tag @s add ec._a
execute if entity @s[tag=ec._a] at @s run function evercraft:artifacts/accessories/wayfarer/light_step
# Cleanup: when the clasp is NOT held but we still own a stale light cell, revert it once (the
# dispatch reverts the block AND zeroes ec.wf_lhas, keeping that flag's writes inside the light
# subsystem — light_step owns the held path, light_clean_dispatch owns the not-held reset).
execute unless items entity @s container.* *[custom_data~{artifact:"lantern_lichen_clasp"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"lantern_lichen_clasp"}] unless entity @s[tag=ec.sat_lantern_lichen_clasp] if score @s ec.wf_lhas matches 1 run function evercraft:artifacts/accessories/wayfarer/light_clean_dispatch
tag @s remove ec._a
#
# U23 Voyager's Far-Lens — extended waypoint-marker receive range (the REAL 26.1 waypoint_receive_range
# attribute; the dropped 64 b terrain outline is replaced by the sneak survey ping below). Fixed-id
# modifier (idempotent — two copies overwrite to one +96, m4 Layer-2). Cleanup in accessory_cleanup.
execute if items entity @s container.* *[custom_data~{artifact:"voyagers_far_lens"}] run tag @s add ec._a
execute unless items entity @s container.* *[custom_data~{artifact:"voyagers_far_lens"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"voyagers_far_lens"}] if entity @s[tag=ec.sat_voyagers_far_lens] run tag @s add ec._a
execute unless entity @s[tag=ec._a] if items entity @s weapon.offhand *[custom_data~{artifact:"voyagers_far_lens"}] run tag @s add ec._a
execute if entity @s[tag=ec._a] run attribute @s waypoint_receive_range modifier add evercraft:voyagers_far_lens_wp 96 add_value
tag @s remove ec._a

# ============================================================
# === FAMILY F — BUILDER / TRAVERSAL QoL (art-F) — PASSIVE ATTRIBUTE LEAVES ===
# ============================================================
# Loose builder/traversal-QoL leaves that are F-adjacent but route to OTHER families per the LATTICE
# + Review Decision-6 (recommendation a): the frozen 6-part Hand of Creation gets NO 7th part, so
# these live as standalone held-item perks routed into L's Stride Line (U2 / B9 / U18 / C40) and K's
# Surveyor Line (C39 / U9 / U16). Each is a held-item attribute perk on this player_tick chassis,
# behind the ec.has_accessory early-exit. ALL use the Far-Lens idiom above: an ec._a single-scan
# consolidation (container.* + offhand -> 1 modifier add) with a DISTINCT fixed modifier id, so two
# copies overwrite to ONE value (idempotent / m4 Layer-2 multi-copy-safe). Each modifier is STRIPPED
# the moment its item leaves the inventory in artifacts/abilities/accessory_cleanup (the
# Dancer/Soul-Reaver clear-on-removal idiom). No DR / luck modifier on any of these (pure QoL, balance
# -neutral). The +1% dodge on the three agile pieces (U2 / B9 / U18) is handled separately in the m1
# ec.acc_dodge LEAF block at the top of this file — NOT here.
#
# C39 Mason's Long-Arm Band (-> K Surveyor) — block_interaction_range +12% (place/mine reach only,
# never entity_interaction_range -> never reach-to-HIT). PERCENT via add_multiplied_base (the
# Dexterity-prestige reach idiom), so it does NOT dup Builder's Reach's flat +1.
execute if items entity @s container.* *[custom_data~{artifact:"masons_long_arm_band"}] run tag @s add ec._a
execute unless items entity @s container.* *[custom_data~{artifact:"masons_long_arm_band"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"masons_long_arm_band"}] if entity @s[tag=ec.sat_masons_long_arm_band] run tag @s add ec._a
execute unless entity @s[tag=ec._a] if items entity @s weapon.offhand *[custom_data~{artifact:"masons_long_arm_band"}] run tag @s add ec._a
execute if entity @s[tag=ec._a] run attribute @s block_interaction_range modifier add evercraft:masons_long_arm_reach 0.12 add_multiplied_base
tag @s remove ec._a
#
# U9 Surveyor's Reach-Glass (-> K Surveyor) — block_interaction_range +1.5 (FLAT place/harvest reach,
# the higher Rare value; never entity_interaction_range). Distinct modifier id so it STACKS with the
# Mason's percent band and the Hand's flat reach.
execute if items entity @s container.* *[custom_data~{artifact:"surveyors_reach_glass"}] run tag @s add ec._a
execute unless items entity @s container.* *[custom_data~{artifact:"surveyors_reach_glass"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"surveyors_reach_glass"}] if entity @s[tag=ec.sat_surveyors_reach_glass] run tag @s add ec._a
execute unless entity @s[tag=ec._a] if items entity @s weapon.offhand *[custom_data~{artifact:"surveyors_reach_glass"}] run tag @s add ec._a
execute if entity @s[tag=ec._a] run attribute @s block_interaction_range modifier add evercraft:surveyors_reach_glass 1.5 add_value
tag @s remove ec._a
#
# C40 Builder's Loftstride Greaves-Charm (-> L Stride) — step_height +1.0 (auto-step a full block) +
# block_interaction_range +25% (dedicated big-build QoL). Two distinct modifier ids, both via the same
# ec._a single-scan. The reach is PERCENT (add_multiplied_base) so it stacks with the Mason band + the
# Surveyor glass + the Hand's flat reach without duplicating any of them.
execute if items entity @s container.* *[custom_data~{artifact:"builders_loftstride"}] run tag @s add ec._a
execute unless items entity @s container.* *[custom_data~{artifact:"builders_loftstride"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"builders_loftstride"}] if entity @s[tag=ec.sat_builders_loftstride] run tag @s add ec._a
execute unless entity @s[tag=ec._a] if items entity @s weapon.offhand *[custom_data~{artifact:"builders_loftstride"}] run tag @s add ec._a
execute if entity @s[tag=ec._a] run attribute @s step_height modifier add evercraft:builders_loftstride_step 1.0 add_value
execute if entity @s[tag=ec._a] run attribute @s block_interaction_range modifier add evercraft:builders_loftstride_reach 0.25 add_multiplied_base
tag @s remove ec._a
#
# U2 Sure-Step Pebble (-> L Stride) — step_height +0.4 (0.6 -> 1.0 auto-steps full 1-block ledges).
# Distinct modifier id so it stacks with the Loftstride / Wayfarer's Greaves step adds.
execute if items entity @s container.* *[custom_data~{artifact:"sure_step_pebble"}] run tag @s add ec._a
execute unless items entity @s container.* *[custom_data~{artifact:"sure_step_pebble"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"sure_step_pebble"}] if entity @s[tag=ec.sat_sure_step_pebble] run tag @s add ec._a
execute unless entity @s[tag=ec._a] if items entity @s weapon.offhand *[custom_data~{artifact:"sure_step_pebble"}] run tag @s add ec._a
execute if entity @s[tag=ec._a] run attribute @s step_height modifier add evercraft:sure_step_pebble_step 0.4 add_value
tag @s remove ec._a
#
# B9 Wayfarer's Greaves (-> L Stride) — step_height +0.5 + fall_damage_multiplier -0.15 (-15% fall
# damage). Two distinct modifier ids via the one ec._a scan. fall_damage_multiplier uses
# add_multiplied_base so -0.15 = a flat -15% off incoming fall damage.
execute if items entity @s container.* *[custom_data~{artifact:"wayfarers_greaves"}] run tag @s add ec._a
execute unless items entity @s container.* *[custom_data~{artifact:"wayfarers_greaves"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"wayfarers_greaves"}] if entity @s[tag=ec.sat_wayfarers_greaves] run tag @s add ec._a
execute unless entity @s[tag=ec._a] if items entity @s weapon.offhand *[custom_data~{artifact:"wayfarers_greaves"}] run tag @s add ec._a
execute if entity @s[tag=ec._a] run attribute @s step_height modifier add evercraft:wayfarers_greaves_step 0.5 add_value
execute if entity @s[tag=ec._a] run attribute @s fall_damage_multiplier modifier add evercraft:wayfarers_greaves_fall -0.15 add_multiplied_base
tag @s remove ec._a
#
# U18 Featherfall Glider-Knot (-> L Stride) — safe_fall_distance +6.0 (passive soft-landing) + a
# gravity -0.06 WHILE FALLING (the steerable-glide feel; gated on not_on_ground so normal walking is
# unaffected, and the gravity modifier is stripped the moment the player lands OR drops the knot). The
# safe_fall_distance modifier is the always-on passive (stripped only on removal, in accessory_cleanup);
# the gravity modifier is re-evaluated each tick here (held + airborne -> add; otherwise remove) so it
# never lingers on the ground.
execute if items entity @s container.* *[custom_data~{artifact:"featherfall_glider_knot"}] run tag @s add ec._a
execute unless items entity @s container.* *[custom_data~{artifact:"featherfall_glider_knot"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"featherfall_glider_knot"}] if entity @s[tag=ec.sat_featherfall_glider_knot] run tag @s add ec._a
execute unless entity @s[tag=ec._a] if items entity @s weapon.offhand *[custom_data~{artifact:"featherfall_glider_knot"}] run tag @s add ec._a
execute if entity @s[tag=ec._a] run attribute @s safe_fall_distance modifier add evercraft:featherfall_safe_fall 6.0 add_value
# Lighter fall: fall-damage immunity (the featherscale_down fall_damage_multiplier idiom). Always-on while held.
execute if entity @s[tag=ec._a] run attribute @s fall_damage_multiplier modifier add evercraft:featherfall_glider_knot_fall -1.0 add_multiplied_base
execute if entity @s[tag=ec._a] if predicate evercraft:not_on_ground run attribute @s gravity modifier add evercraft:featherfall_glide -0.06 add_value
execute if entity @s[tag=ec._a] unless predicate evercraft:not_on_ground run attribute @s gravity modifier remove evercraft:featherfall_glide
tag @s remove ec._a

# ============================================================
# === FAMILY G — FORGE TRADE (Grandforge Regalia) PASSIVE ATTRIBUTE LEAVES (art-G) ===
# ============================================================
# The blacksmith trade-guild's break-speed / mining-efficiency / armor leaves, as held-item
# attribute perks behind the ec.has_accessory early-exit. ALL use the Far-Lens/Family-F idiom: an
# ec._a single-scan (container.* OR offhand -> 1 scan) + a fixed-id `modifier add` (re-added every
# tick at a constant value -> two copies overwrite to ONE value, m4 Layer-2 multi-copy-safe; clear-
# on-removal lives in accessory_cleanup). DR=0 for G (these are mining/efficiency/armor attrs, NOT
# Dream Rate -> no dreams/breakdown line). The CR levers (C10/C16/C17) live in craft_rate/calculate
# (the ONE ec.cr_temp writer); the forge-resolve +1 (C15/C17) lives in forging/minigame/resolve;
# C13 Smelter's auto-smelt + C14 Loupe ore-roll are item-gated on their break events (no tick cost).
# break_speed % uses add_multiplied_base (the adv_mining_surge / amethyst_trim precedent — stacks on
# Haste, NOT Haste). mining_efficiency uses add_value (the companion silverfish precedent).
#
# C1 Quarry-Worn Knuckle — block_break_speed +8% (permanent dig, stacks on Haste).
execute if items entity @s container.* *[custom_data~{artifact:"quarry_worn_knuckle"}] run tag @s add ec._a
execute unless items entity @s container.* *[custom_data~{artifact:"quarry_worn_knuckle"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"quarry_worn_knuckle"}] if entity @s[tag=ec.sat_quarry_worn_knuckle] run tag @s add ec._a
execute unless entity @s[tag=ec._a] if items entity @s weapon.offhand *[custom_data~{artifact:"quarry_worn_knuckle"}] run tag @s add ec._a
execute if entity @s[tag=ec._a] run attribute @s block_break_speed modifier add evercraft:quarry_worn_knuckle 0.08 add_multiplied_base
tag @s remove ec._a
#
# C12 Quenching Stone — block_break_speed +10% (the smith's quenched edge).
execute if items entity @s container.* *[custom_data~{artifact:"quenching_stone"}] run tag @s add ec._a
execute unless items entity @s container.* *[custom_data~{artifact:"quenching_stone"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"quenching_stone"}] if entity @s[tag=ec.sat_quenching_stone] run tag @s add ec._a
execute unless entity @s[tag=ec._a] if items entity @s weapon.offhand *[custom_data~{artifact:"quenching_stone"}] run tag @s add ec._a
execute if entity @s[tag=ec._a] run attribute @s block_break_speed modifier add evercraft:quenching_stone 0.10 add_multiplied_base
tag @s remove ec._a
#
# B3 Quarryman's Grip — block_break_speed +10% (the pick never tires). Distinct id -> stacks with
# the Quenching Stone / Quarry-Worn / Grand Anvil break-speed adds (additive percent layers).
execute if items entity @s container.* *[custom_data~{artifact:"quarrymans_grip"}] run tag @s add ec._a
execute unless items entity @s container.* *[custom_data~{artifact:"quarrymans_grip"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"quarrymans_grip"}] if entity @s[tag=ec.sat_quarrymans_grip] run tag @s add ec._a
execute unless entity @s[tag=ec._a] if items entity @s weapon.offhand *[custom_data~{artifact:"quarrymans_grip"}] run tag @s add ec._a
execute if entity @s[tag=ec._a] run attribute @s block_break_speed modifier add evercraft:quarrymans_grip 0.10 add_multiplied_base
tag @s remove ec._a
#
# C17 Grand Anvil Heart — block_break_speed +25% (the smith sub-binding's break-speed lever; its
# +0.3 CR is in calculate, its +1 forge-resolve is in resolve.mcfunction).
execute if items entity @s container.* *[custom_data~{artifact:"grand_anvil_heart"}] run tag @s add ec._a
execute unless items entity @s container.* *[custom_data~{artifact:"grand_anvil_heart"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"grand_anvil_heart"}] if entity @s[tag=ec.sat_grand_anvil_heart] run tag @s add ec._a
execute unless entity @s[tag=ec._a] if items entity @s weapon.offhand *[custom_data~{artifact:"grand_anvil_heart"}] run tag @s add ec._a
execute if entity @s[tag=ec._a] run attribute @s block_break_speed modifier add evercraft:grand_anvil_heart_bs 0.25 add_multiplied_base
tag @s remove ec._a
#
# C2 Whetstone Charm — mining_efficiency +2 (two Efficiency-units, an enchant feel without a slot).
execute if items entity @s container.* *[custom_data~{artifact:"whetstone_charm"}] run tag @s add ec._a
execute unless items entity @s container.* *[custom_data~{artifact:"whetstone_charm"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"whetstone_charm"}] if entity @s[tag=ec.sat_whetstone_charm] run tag @s add ec._a
execute unless entity @s[tag=ec._a] if items entity @s weapon.offhand *[custom_data~{artifact:"whetstone_charm"}] run tag @s add ec._a
execute if entity @s[tag=ec._a] run attribute @s mining_efficiency modifier add evercraft:whetstone_charm 2 add_value
tag @s remove ec._a
#
# C11 Tinsmith's Pocket Hammer — mining_efficiency +1 (lower tier of Whetstone; distinct id stacks).
execute if items entity @s container.* *[custom_data~{artifact:"tinsmiths_pocket_hammer"}] run tag @s add ec._a
execute unless items entity @s container.* *[custom_data~{artifact:"tinsmiths_pocket_hammer"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"tinsmiths_pocket_hammer"}] if entity @s[tag=ec.sat_tinsmiths_pocket_hammer] run tag @s add ec._a
execute unless entity @s[tag=ec._a] if items entity @s weapon.offhand *[custom_data~{artifact:"tinsmiths_pocket_hammer"}] run tag @s add ec._a
execute if entity @s[tag=ec._a] run attribute @s mining_efficiency modifier add evercraft:tinsmiths_pocket_hammer 1 add_value
tag @s remove ec._a
#
# Forge Charm (forge_seed_a + forge_seed_b awakened) — mining_efficiency +1 (add_value, the Tinsmith
# idiom) + block_break_speed +5% (add_multiplied_base, the Quarry-Worn idiom at 0.05). Distinct ids so
# it stacks cleanly with the loose leaves. One ec._a scan covers BOTH attribute adds (held -> both fire).
# Zero DR (forge bundle). Clear-on-removal: both ids stripped in accessory_cleanup.
execute if items entity @s container.* *[custom_data~{artifact:"forge_charm"}] run tag @s add ec._a
execute unless items entity @s container.* *[custom_data~{artifact:"forge_charm"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"forge_charm"}] if entity @s[tag=ec.sat_forge_charm] run tag @s add ec._a
execute unless entity @s[tag=ec._a] if items entity @s weapon.offhand *[custom_data~{artifact:"forge_charm"}] run tag @s add ec._a
execute if entity @s[tag=ec._a] run attribute @s mining_efficiency modifier add evercraft:forge_charm_eff 1 add_value
execute if entity @s[tag=ec._a] run attribute @s block_break_speed modifier add evercraft:forge_charm_bs 0.05 add_multiplied_base
tag @s remove ec._a
#
# Bellows Ember (forge_seed_a, ex-"Reserved I" — identity pass 2026-06-11) — block_break_speed +3%
# (add_multiplied_base, the Quarry-Worn idiom at 0.03). The smaller of the two Forge Charm leaves;
# distinct id stacks with the awakened charm + Quarry-Worn. Clear-on-removal in accessory_cleanup.
execute if items entity @s container.* *[custom_data~{artifact:"forge_seed_a"}] run tag @s add ec._a
execute unless items entity @s container.* *[custom_data~{artifact:"forge_seed_a"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"forge_seed_a"}] if entity @s[tag=ec.sat_forge_seed_a] run tag @s add ec._a
execute unless entity @s[tag=ec._a] if items entity @s weapon.offhand *[custom_data~{artifact:"forge_seed_a"}] run tag @s add ec._a
execute if entity @s[tag=ec._a] run attribute @s block_break_speed modifier add evercraft:forge_seed_a_bs 0.03 add_multiplied_base
tag @s remove ec._a
#
# Quench Stone (forge_seed_b, ex-"Reserved II" — identity pass 2026-06-11) — submerged_mining_speed
# +10% (add_multiplied_base). The quench-trough leaf works below the waterline. Clear-on-removal in
# accessory_cleanup.
execute if items entity @s container.* *[custom_data~{artifact:"forge_seed_b"}] run tag @s add ec._a
execute unless items entity @s container.* *[custom_data~{artifact:"forge_seed_b"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"forge_seed_b"}] if entity @s[tag=ec.sat_forge_seed_b] run tag @s add ec._a
execute unless entity @s[tag=ec._a] if items entity @s weapon.offhand *[custom_data~{artifact:"forge_seed_b"}] run tag @s add ec._a
execute if entity @s[tag=ec._a] run attribute @s submerged_mining_speed modifier add evercraft:forge_seed_b_sub 0.10 add_multiplied_base
tag @s remove ec._a
#
# B8 Ember-Forged Band — CONDITIONAL: +1 Armor + block_break_speed +8% ONLY near a heat source
# (forge/lava/fire/campfire/lit furnace family). The forge-context combat buff. Re-evaluated each
# tick: scan only when held (non-holders pay one `if items` test), then add or remove both modifiers
# based on the heat-source check (the band_luck remove-then-conditional-add idiom so it strips the
# moment the player walks away from heat OR drops the band). #g_heat ec.temp set by the detector.
execute if items entity @s container.* *[custom_data~{artifact:"ember_forged_band"}] run tag @s add ec._a
execute unless items entity @s container.* *[custom_data~{artifact:"ember_forged_band"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"ember_forged_band"}] if entity @s[tag=ec.sat_ember_forged_band] run tag @s add ec._a
execute unless entity @s[tag=ec._a] if items entity @s weapon.offhand *[custom_data~{artifact:"ember_forged_band"}] run tag @s add ec._a
scoreboard players set #g_heat ec.temp 0
execute if entity @s[tag=ec._a] at @s run function evercraft:artifacts/accessories/forge/ember_band_heat
attribute @s armor modifier remove evercraft:ember_forged_band_armor
attribute @s block_break_speed modifier remove evercraft:ember_forged_band_bs
execute if entity @s[tag=ec._a] if score #g_heat ec.temp matches 1 run attribute @s armor modifier add evercraft:ember_forged_band_armor 1 add_value
execute if entity @s[tag=ec._a] if score #g_heat ec.temp matches 1 run attribute @s block_break_speed modifier add evercraft:ember_forged_band_bs 0.08 add_multiplied_base
tag @s remove ec._a

# ============================================================
# === FAMILY H — CHEMISTRY TRADE (Alchemist's Magnum Opus) SUSTAIN LEAF (art-H) ===
# ============================================================
# B11 Glacier-Cut Sigil — Regeneration I while below HALF (50%) health. The alchemist's brew-bench
# sustain leaf. The 6 core H charms (C18-C23) hang on the alchemy brew funnel (craft_rate/calculate
# CR + alchemy/minigame/resolve quality/yield/duration), NOT the tick — this is the ONLY H leaf with
# a per-tick effect. DR=0 for H (no dreams/breakdown line). Distinct from Heartstone (Regen <6♥ FLAT
# + instant-heal fallback) by its RELATIVE 50% threshold + NO fallback (a non-dup per EXPANSION-IDEAS
# B11). Below-50% is the firebrand Tyrant's-Rage idiom (spirit/abilities/firebrand/tick:7-10): read
# max_health *100, take 50%, read current Health *100, compare. Regen respects the shared regen
# ceiling (ec.regen_capped) so it never over-stacks a stronger same-effect source — the Heartstone /
# Healer's-Salve idiom. ec._a single-scan (container.* OR offhand -> 1 scan); clear-on-removal is the
# effect's own 5t (0.25s) decay (no attribute modifier -> no accessory_cleanup strip needed).
execute if items entity @s container.* *[custom_data~{artifact:"glacier_cut_sigil"}] run tag @s add ec._a
execute unless items entity @s container.* *[custom_data~{artifact:"glacier_cut_sigil"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"glacier_cut_sigil"}] if entity @s[tag=ec.sat_glacier_cut_sigil] run tag @s add ec._a
execute unless entity @s[tag=ec._a] if items entity @s weapon.offhand *[custom_data~{artifact:"glacier_cut_sigil"}] run tag @s add ec._a
execute if entity @s[tag=ec._a] store result score #h_hpmax ec.temp run attribute @s max_health get 100
execute if entity @s[tag=ec._a] run scoreboard players operation #h_hpmax ec.temp *= #50 ec.const
execute if entity @s[tag=ec._a] run scoreboard players operation #h_hpmax ec.temp /= #100 ec.const
execute if entity @s[tag=ec._a] store result score #h_hpcur ec.temp run data get entity @s Health 100
execute if entity @s[tag=ec._a] if score #h_hpcur ec.temp <= #h_hpmax ec.temp unless entity @s[tag=ec.regen_capped] run effect give @s regeneration 5 0 false
execute if entity @s[tag=ec._a] if score #h_hpcur ec.temp <= #h_hpmax ec.temp if entity @s[tag=ec.regen_capped] run function evercraft:artifacts/accessories/regen_fallback
tag @s remove ec._a

# ============================================================
# === FAMILY J — HARVEST & TIDE (Cornucopia Tide) LEAVES (art-J) ===
# ============================================================
# The fishing-rod injects (C31/C34), conditional-DR fishing pieces (C33/C36), aquatic-attribute
# pieces (C35/U15), the agriculture head (#4 Harvest Totem), and U15's splash-node ping. The cook
# levers (C24-C30) live in cooking/minigame/resolve + craft_rate/calculate; the harvest-yield levers
# (C41 Tiller / C42 Gleaner) live in the m2 harvest_bonus_read LEAF block — none of those are tick
# perks. DR consolidated for J = the two CONDITIONAL fishing luck modifiers below (Riverpearl +2.0
# while fishing, Deepcurrent +3.0 while in water); both are condition-gated (remove-then-conditional-
# add, the Geologist's Loupe idiom) and EACH reports one breakdown line in dreams/breakdown/artifacts.
# Lure-on-rod (C31/C34) is NOT fortune-rewritten (D-FORTUNE-REWRITE excludes fishing rod items).
# cap-J m4 SUPPRESS-AT-SOURCE tag: set ec._jhide when an absorbing node (Tidewright's Net OR the grand
# Cornucopia Tide) is held on Adventurer/Pioneer — the conditional-DR add lines below (Riverpearl C33 /
# Deepcurrent C36) check `unless ec._jhide` so a re-acquired loose fishing-DR charm never double-dips the
# consolidated tidewright_luck / cornucopia_tide_luck. Newcomer-exempt (the set is `unless ec.difficulty
# matches 1`). Reset-before-set + cleared at the end of this block (no leak; the cap-H ec._mohide shape).
tag @s remove ec._jhide
execute unless score @s ec.difficulty matches 1 if items entity @s container.* *[custom_data~{cornucopia_tide:true}] run tag @s add ec._jhide
execute unless score @s ec.difficulty matches 1 unless items entity @s container.* *[custom_data~{cornucopia_tide:true}] unless items entity @s weapon.offhand *[custom_data~{cornucopia_tide:true}] if entity @s[tag=ec.sat_cornucopia_tide] run tag @s add ec._jhide
execute unless score @s ec.difficulty matches 1 if items entity @s weapon.offhand *[custom_data~{cornucopia_tide:true}] run tag @s add ec._jhide
execute unless score @s ec.difficulty matches 1 if items entity @s container.* *[custom_data~{tidewrights_net:true}] run tag @s add ec._jhide
execute unless score @s ec.difficulty matches 1 unless items entity @s container.* *[custom_data~{tidewrights_net:true}] unless items entity @s weapon.offhand *[custom_data~{tidewrights_net:true}] if entity @s[tag=ec.sat_tidewrights_net] run tag @s add ec._jhide
execute unless score @s ec.difficulty matches 1 if items entity @s weapon.offhand *[custom_data~{tidewrights_net:true}] run tag @s add ec._jhide

# C31 Dockhand's Knot — Lure I on a held fishing rod (+ cleanup on removal/switch). Tier ladder
# BELOW Angler's Pearl (Lure II + LotS I) and Anglerwarden's Sigil (Lure II + LotS III).
function evercraft:artifacts/abilities/dockhands_lure
execute if entity @s[tag=ec.dockhands_knot_fishing] run function evercraft:artifacts/abilities/dockhands_lure_cleanup

# C34 Anglerwarden's Sigil — Lure II + Luck of the Sea III on a held fishing rod (+ cleanup). The
# Ornate rod head: strictly above Angler's Pearl (its higher LotS III).
function evercraft:artifacts/abilities/anglerwarden_lure
execute if entity @s[tag=ec.anglerwarden_fishing] run function evercraft:artifacts/abilities/anglerwarden_lure_cleanup

# C33 Riverpearl Charm — CONDITIONAL +2.0 Dream Rate ONLY while actively fishing (holding a fishing
# rod = the bobber-out proxy; the rod must be held for a bobber to exist, and switching/reeling drops
# it). Remove-then-conditional-add so the value is exact every tick (the Geologist's Loupe / band_luck
# idiom): the bare remove handles not-held AND not-fishing; the add fires only while held + rod in
# mainhand. Fixed-id modifier (idempotent — two copies overwrite, m4 multi-copy-safe). ec._a single-
# scan. Reports one line in dreams/breakdown/artifacts (conditional, shows only while fishing).
# m4 SUPPRESS-AT-SOURCE (cap-J): on Adventurer/Pioneer, when an absorbing node (Tidewright's Net OR the
# grand Cornucopia Tide) is held, the conditional-add is suppressed (the node's consolidated tidewright_
# luck / cornucopia_tide_luck covers it) so a re-acquired loose Riverpearl never double-dips. The `remove`
# stays unconditional (always strips the loose id). Newcomer-exempt (`unless ec.difficulty matches 1`).
execute if items entity @s container.* *[custom_data~{artifact:"riverpearl_charm"}] run tag @s add ec._a
execute unless items entity @s container.* *[custom_data~{artifact:"riverpearl_charm"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"riverpearl_charm"}] if entity @s[tag=ec.sat_riverpearl_charm] run tag @s add ec._a
execute unless entity @s[tag=ec._a] if items entity @s weapon.offhand *[custom_data~{artifact:"riverpearl_charm"}] run tag @s add ec._a
execute if entity @s[tag=ec._a] run attribute @s luck modifier remove evercraft:riverpearl_charm_luck
execute if entity @s[tag=ec._a] if items entity @s weapon.mainhand minecraft:fishing_rod unless entity @s[tag=ec._jhide] run attribute @s luck modifier add evercraft:riverpearl_charm_luck 2.0 add_value
tag @s remove ec._a

# C36 Deepcurrent Reliquary — CONDITIONAL +3.0 Dream Rate while in water (the in/over-water gate via
# the existing evercraft:in_water predicate, used by ocean armor sets). Remove-then-conditional-add
# (Geologist idiom). Fixed-id (m4-safe). ec._a single-scan. Its extra splash-node crate roll lives in
# fishing/ref/on_catch. Reports one line in dreams/breakdown/artifacts (conditional, in water only).
# m4 SUPPRESS-AT-SOURCE (cap-J): same as Riverpearl — the conditional-add is suppressed (Newcomer-exempt)
# when an absorbing node is held (ec._jhide), so a re-acquired loose Deepcurrent never double-dips.
execute if items entity @s container.* *[custom_data~{artifact:"deepcurrent_reliquary"}] run tag @s add ec._a
execute unless items entity @s container.* *[custom_data~{artifact:"deepcurrent_reliquary"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"deepcurrent_reliquary"}] if entity @s[tag=ec.sat_deepcurrent_reliquary] run tag @s add ec._a
execute unless entity @s[tag=ec._a] if items entity @s weapon.offhand *[custom_data~{artifact:"deepcurrent_reliquary"}] run tag @s add ec._a
execute if entity @s[tag=ec._a] run attribute @s luck modifier remove evercraft:deepcurrent_reliquary_luck
execute if entity @s[tag=ec._a] if predicate evercraft:in_water unless entity @s[tag=ec._jhide] run attribute @s luck modifier add evercraft:deepcurrent_reliquary_luck 3.0 add_value
tag @s remove ec._a
# Clear the cap-J m4 suppression tag (set at the top of this FAMILY J LEAVES block).
tag @s remove ec._jhide

# C35 Coral Diver's Pearl — +30% submerged_mining_speed + water_movement_efficiency (companions-only
# attrs ⇒ novel for an accessory). Fixed-id modifiers, re-added each tick while held (clear-on-removal
# in accessory_cleanup). submerged_mining_speed uses add_multiplied_base for a % feel; water_movement_
# efficiency uses add_value (0..1 scalar, +0.30). ec._a single-scan.
execute if items entity @s container.* *[custom_data~{artifact:"coral_divers_pearl"}] run tag @s add ec._a
execute unless items entity @s container.* *[custom_data~{artifact:"coral_divers_pearl"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"coral_divers_pearl"}] if entity @s[tag=ec.sat_coral_divers_pearl] run tag @s add ec._a
execute unless entity @s[tag=ec._a] if items entity @s weapon.offhand *[custom_data~{artifact:"coral_divers_pearl"}] run tag @s add ec._a
execute if entity @s[tag=ec._a] run attribute @s submerged_mining_speed modifier add evercraft:coral_divers_pearl_smine 0.30 add_multiplied_base
execute if entity @s[tag=ec._a] run attribute @s water_movement_efficiency modifier add evercraft:coral_divers_pearl_wme 0.30 add_value
tag @s remove ec._a

# U15 Tidefinder's Astrolite — small +0.15 submerged_mining_speed + a read-only splash-node ping
# (datapack-native action-bar readout, NO resource pack). ec._a single-scan; the ping fn only emits
# when a splash-node marker is within ~48 blocks (no clutter otherwise). player_tick runs at 1s so the
# action bar is not spammed. Angler's Pearl owns Lure/LotS ⇒ no overlap (this is a sense readout).
execute if items entity @s container.* *[custom_data~{artifact:"tidefinders_astrolite"}] run tag @s add ec._a
execute unless items entity @s container.* *[custom_data~{artifact:"tidefinders_astrolite"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"tidefinders_astrolite"}] if entity @s[tag=ec.sat_tidefinders_astrolite] run tag @s add ec._a
execute unless entity @s[tag=ec._a] if items entity @s weapon.offhand *[custom_data~{artifact:"tidefinders_astrolite"}] run tag @s add ec._a
execute if entity @s[tag=ec._a] run attribute @s submerged_mining_speed modifier add evercraft:tidefinders_astrolite_smine 0.15 add_value
execute if entity @s[tag=ec._a] at @s run function evercraft:artifacts/accessories/tidefinder_ping
tag @s remove ec._a

# #4 Harvest Totem — agriculture head: a stronger crop-growth pulse than Farmer's Almanac (~15%/sec
# vs ~5%/sec), reusing the Almanac's proven try_bone_meal dispatch. ec._a single-scan; the tick fn is
# run positioned at @s so try_bone_meal scans the crops around the player. Stacks additively with the
# Almanac (a farming build holding both gets both pulses). DR=0.
execute if items entity @s container.* *[custom_data~{artifact:"harvest_totem"}] run tag @s add ec._a
execute unless items entity @s container.* *[custom_data~{artifact:"harvest_totem"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"harvest_totem"}] if entity @s[tag=ec.sat_harvest_totem] run tag @s add ec._a
execute unless entity @s[tag=ec._a] if items entity @s weapon.offhand *[custom_data~{artifact:"harvest_totem"}] run tag @s add ec._a
execute if entity @s[tag=ec._a] at @s run function evercraft:artifacts/accessories/harvest_totem_tick
tag @s remove ec._a

# ============================================================
# === FAMILY K — PROSPECTOR (Demiurge's Spirit Artifact) LEAVES (art-K) ===
# ============================================================
# The gathering/mining trade family: aquatic-dig attributes (C3/U11), a node-proximity pip (U12),
# and the capstone's CONSOLIDATED conditional mining-DR. The crate/yield/access leaves are NOT tick
# perks — they ride break events: C6 Doohickey (forging/ore_mining/check_drop), C9 Brushwright + C4
# double-log (craft_affinity/detect_ordinary_tool), C43 Geode crate (m2 harvest_bonus_read + the
# break/catch hooks), C46 Resonance dup (resonance/reward_perfect), C7 despawn (nodes/check_despawn),
# C8 rank-bypass (nodes/try_spawn), U20 Dice node-crate (gather/resolve_win extra roll). The
# sneak-triggered survey items (U6/U10/U13/U19 + C7 ping) live in the SNEAK-TRIGGERED block below. ALL
# attribute leaves use the Far-Lens/Family-J idiom: ec._a single-scan + fixed-id `modifier add`
# (two copies overwrite to ONE value -> m4 Layer-2 multi-copy-safe; clear-on-removal in
# accessory_cleanup). soul_lantern_fragment (re-homed into K) is already wired above (its xp_boost_check
# perk) — art-K only m3-stamps its loot table. The 3 F-routed Surveyor leaves (Mason's Long-Arm /
# Surveyor's Reach-Glass / Steady-Hand Caliper) were built by art-F into Family F's block above.

# C3 Tidewright's Pearl — CONDITIONAL aquatic kit while submerged (in/over water via the in_water
# predicate, the Deepcurrent gate): submerged_mining_speed +30% (% feel, add_multiplied_base) +
# water_movement_efficiency +0.5 (0..1 scalar, add_value) + oxygen_bonus +4 (the squid/axolotl breath
# attr). Remove-then-conditional-add (the band_luck/Geologist idiom) so all three strip the instant the
# player leaves the water OR drops the Pearl. ec._a single-scan. The submerged-DIG attrs only matter
# underwater anyway, so gating on in_water is both correct and frees the modifier on dry land.
execute if items entity @s container.* *[custom_data~{artifact:"tidewright_pearl"}] run tag @s add ec._a
execute unless items entity @s container.* *[custom_data~{artifact:"tidewright_pearl"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"tidewright_pearl"}] if entity @s[tag=ec.sat_tidewright_pearl] run tag @s add ec._a
execute unless entity @s[tag=ec._a] if items entity @s weapon.offhand *[custom_data~{artifact:"tidewright_pearl"}] run tag @s add ec._a
execute if entity @s[tag=ec._a] run attribute @s submerged_mining_speed modifier remove evercraft:tidewright_pearl_smine
execute if entity @s[tag=ec._a] run attribute @s water_movement_efficiency modifier remove evercraft:tidewright_pearl_wme
execute if entity @s[tag=ec._a] run attribute @s oxygen_bonus modifier remove evercraft:tidewright_pearl_o2
execute if entity @s[tag=ec._a] if predicate evercraft:in_water run attribute @s submerged_mining_speed modifier add evercraft:tidewright_pearl_smine 0.30 add_multiplied_base
execute if entity @s[tag=ec._a] if predicate evercraft:in_water run attribute @s water_movement_efficiency modifier add evercraft:tidewright_pearl_wme 0.5 add_value
execute if entity @s[tag=ec._a] if predicate evercraft:in_water run attribute @s oxygen_bonus modifier add evercraft:tidewright_pearl_o2 4 add_value
tag @s remove ec._a

# U11 Driftcurrent Fin — submerged_mining_speed +25% (add_multiplied_base) + water_movement_efficiency
# +0.25 (add_value). Unconditional while held (the attrs only matter underwater, like Coral Diver's
# Pearl) — fixed-id, re-added each tick; clear-on-removal in accessory_cleanup. No combat dolphin-grace
# (no movement_speed touch). Distinct ids -> stacks with Tidewright's Pearl / Coral Diver's Pearl.
execute if items entity @s container.* *[custom_data~{artifact:"driftcurrent_fin"}] run tag @s add ec._a
execute unless items entity @s container.* *[custom_data~{artifact:"driftcurrent_fin"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"driftcurrent_fin"}] if entity @s[tag=ec.sat_driftcurrent_fin] run tag @s add ec._a
execute unless entity @s[tag=ec._a] if items entity @s weapon.offhand *[custom_data~{artifact:"driftcurrent_fin"}] run tag @s add ec._a
execute if entity @s[tag=ec._a] run attribute @s submerged_mining_speed modifier add evercraft:driftcurrent_fin_smine 0.25 add_multiplied_base
execute if entity @s[tag=ec._a] run attribute @s water_movement_efficiency modifier add evercraft:driftcurrent_fin_wme 0.25 add_value
tag @s remove ec._a

# U12 Pathfinder's Astrolabe — read-only node-proximity pip (the U15 Tidefinder ping idiom, but for
# craft-nodes): emits an action-bar pip only when a craft-node marker (ec.cf_node_data) is within
# ~100 b. No odds touched, no scan (one @e existence test inside the ping fn). ec._a single-scan;
# positioned at @s so the ping reads nearby nodes. Self-rate-limited by player_tick's 1s cadence.
execute if items entity @s container.* *[custom_data~{artifact:"pathfinders_astrolabe"}] run tag @s add ec._a
execute unless items entity @s container.* *[custom_data~{artifact:"pathfinders_astrolabe"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"pathfinders_astrolabe"}] if entity @s[tag=ec.sat_pathfinders_astrolabe] run tag @s add ec._a
execute unless entity @s[tag=ec._a] if items entity @s weapon.offhand *[custom_data~{artifact:"pathfinders_astrolabe"}] run tag @s add ec._a
execute if entity @s[tag=ec._a] at @s run function evercraft:artifacts/accessories/astrolabe_ping
tag @s remove ec._a

# Demiurge's Spirit Artifact (C47, Family K GRAND — pre-wired by art-K for the future cap-K unit) —
# CONSOLIDATED conditional +3.0 Dream Rate while actively mining/building. Reads the ec.cf_actwin
# mining-activity window (SET to 100t by craft_affinity/grant_verb on every qualifying verb, DECREMENTED
# in this file above) exactly like the Geologist's Loupe / Cache-Eye. Remove-then-conditional-add
# (fixed-id, m4-safe). ec._a single-scan. This is the lattice's "DR consolidated: conditional +3.0 while
# mining (one line)" — it lives on the CAPSTONE id, NOT on any loose K leaf (no K leaf carries DR; U20
# is explicitly "NOT raw DR"). The Demiurge's Spirit Artifact item/recipe/loot is the later cap-K unit; this
# line + its breakdown entry are pre-wired so cap-K only adds the recipe + loot table + member strips.
# Harmless until the capstone exists (the `if items` test never matches -> zero cost). Reports ONE line
# in dreams/breakdown/artifacts (conditional, shows only while mining).
execute if items entity @s container.* *[custom_data~{artifact:"demiurges_capstone"}] run tag @s add ec._a
execute unless items entity @s container.* *[custom_data~{artifact:"demiurges_capstone"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"demiurges_capstone"}] if entity @s[tag=ec.sat_demiurges_capstone] run tag @s add ec._a
execute unless entity @s[tag=ec._a] if items entity @s weapon.offhand *[custom_data~{artifact:"demiurges_capstone"}] run tag @s add ec._a
execute if entity @s[tag=ec._a] run attribute @s luck modifier remove evercraft:demiurges_capstone_luck
execute if entity @s[tag=ec._a] if score @s ec.cf_actwin matches 1.. run attribute @s luck modifier add evercraft:demiurges_capstone_luck 3.0 add_value
tag @s remove ec._a

# ============================================================
# === FAMILY L — VANGUARD (Heart of the Mountain) PASSIVE COMBAT/ARMOR LEAVES (art-L) ===
# ============================================================
# The worn combat-power stones: flat armor/health/toughness/KB-resist, conditional combat buffs, and
# the combat-craft trophy. NEW members here: B1 Stoneward Pebble, B2 Vital Acorn, B5 Sprinter's Anklet,
# B6 Reaver's Knuckle, B7 Anvil Heart, B10 Resonant Locket, B12 Bulwark Plate, #7 Bastion Totem,
# P2 Ascendant Forgeheart. The Stride pieces (B5 / B9 / U2) + the Loftstride (C40) were built by art-F
# (their attr hooks + dodge live in the FAMILY F block above); the 4 mythical defense stones
# (temporal_hourglass / heart_of_the_void / redstone_heart / prism_of_light) are EXISTING items re-homed
# into L's Titan Core line (Material-tagged, not rebuilt — their effects already run in the legacy
# sections below). DR=0 base for L (power-bundle; P3's DR consolidates in B, B10's conditional node-DR is
# the ONLY luck modifier here and reports under B's craft-luck line). ALL use the Far-Lens/Family-F idiom:
# ec._a single-scan (container.* OR offhand) + a fixed-id `modifier add` re-added every tick at a constant
# value (two copies overwrite to ONE -> m4 Layer-2 multi-copy-safe); clear-on-removal lives in
# accessory_cleanup. P2's +5.0 CR lever lives in craft_rate/calculate (the ONE ec.cr_temp writer, m4
# HANDOFF #7 — NOT here). The +1% dodge on B5 / B6 is in the m1 ec.acc_dodge LEAF block at the top of this
# file (B9 / U2 dodge already there via art-F) — NOT here. armor / max_health / armor_toughness use
# add_value; knockback_resistance uses add_value (the earthshaker_core_kb precedent at :1076).
#
# --- m4 Layer-1 SUPPRESS-AT-SOURCE (cap-L): when an absorbing L sub-cap / the grand Heart of the Mountain
#     is held, skip the loose leaf's ATTRIBUTE add so a re-acquired loose piece does NOT double the
#     consolidated armor/health/toughness/attack/speed the (a12) dispatch already granted via distinct
#     sub-cap-scoped ids. Newcomer-EXEMPT (`unless ec.difficulty matches 1`) so casual players keep the
#     forgiving stack. Computed once into three group tags (the cap-D ec._sghide idiom): _lhb = Bulwark
#     Stone group (B1/B2/B7/B12), _lha = Ascendant Line group (B6/B10/P2), _lhs = Stride Line group (B5).
#     The effect-based leaves (#7 Bastion Totem + the 4 re-homed Titan Core stones) need NO suppression —
#     Form-2 effects re-applied at the same level do NOT stack, so the Titan Core grant + a loose effect
#     coexist harmlessly. The conditional luck (B10 resonant_locket_luck) is suppressed inside the _lha
#     group too (so it never double-counts with the Ascendant Line's consolidated ascendant_locket_luck).
tag @s remove ec._lhb
tag @s remove ec._lha
tag @s remove ec._lhs
execute unless score @s ec.difficulty matches 1 if items entity @s container.* *[custom_data~{titan_bulwark:true}] run tag @s add ec._lhb
execute unless score @s ec.difficulty matches 1 unless items entity @s container.* *[custom_data~{titan_bulwark:true}] unless items entity @s weapon.offhand *[custom_data~{titan_bulwark:true}] if entity @s[tag=ec.sat_titan_bulwark] run tag @s add ec._lhb
execute unless score @s ec.difficulty matches 1 if items entity @s weapon.offhand *[custom_data~{titan_bulwark:true}] run tag @s add ec._lhb
execute unless score @s ec.difficulty matches 1 if items entity @s container.* *[custom_data~{heart_of_the_mountain:true}] run tag @s add ec._lhb
execute unless score @s ec.difficulty matches 1 unless items entity @s container.* *[custom_data~{heart_of_the_mountain:true}] unless items entity @s weapon.offhand *[custom_data~{heart_of_the_mountain:true}] if entity @s[tag=ec.sat_heart_of_the_mountain] run tag @s add ec._lhb
execute unless score @s ec.difficulty matches 1 if items entity @s weapon.offhand *[custom_data~{heart_of_the_mountain:true}] run tag @s add ec._lhb
execute unless score @s ec.difficulty matches 1 if items entity @s container.* *[custom_data~{ascendant_line:true}] run tag @s add ec._lha
execute unless score @s ec.difficulty matches 1 unless items entity @s container.* *[custom_data~{ascendant_line:true}] unless items entity @s weapon.offhand *[custom_data~{ascendant_line:true}] if entity @s[tag=ec.sat_ascendant_line] run tag @s add ec._lha
execute unless score @s ec.difficulty matches 1 if items entity @s weapon.offhand *[custom_data~{ascendant_line:true}] run tag @s add ec._lha
execute unless score @s ec.difficulty matches 1 if items entity @s container.* *[custom_data~{heart_of_the_mountain:true}] run tag @s add ec._lha
execute unless score @s ec.difficulty matches 1 unless items entity @s container.* *[custom_data~{heart_of_the_mountain:true}] unless items entity @s weapon.offhand *[custom_data~{heart_of_the_mountain:true}] if entity @s[tag=ec.sat_heart_of_the_mountain] run tag @s add ec._lha
execute unless score @s ec.difficulty matches 1 if items entity @s weapon.offhand *[custom_data~{heart_of_the_mountain:true}] run tag @s add ec._lha
execute unless score @s ec.difficulty matches 1 if items entity @s container.* *[custom_data~{stride_line:true}] run tag @s add ec._lhs
execute unless score @s ec.difficulty matches 1 unless items entity @s container.* *[custom_data~{stride_line:true}] unless items entity @s weapon.offhand *[custom_data~{stride_line:true}] if entity @s[tag=ec.sat_stride_line] run tag @s add ec._lhs
execute unless score @s ec.difficulty matches 1 if items entity @s weapon.offhand *[custom_data~{stride_line:true}] run tag @s add ec._lhs
execute unless score @s ec.difficulty matches 1 if items entity @s container.* *[custom_data~{heart_of_the_mountain:true}] run tag @s add ec._lhs
execute unless score @s ec.difficulty matches 1 unless items entity @s container.* *[custom_data~{heart_of_the_mountain:true}] unless items entity @s weapon.offhand *[custom_data~{heart_of_the_mountain:true}] if entity @s[tag=ec.sat_heart_of_the_mountain] run tag @s add ec._lhs
execute unless score @s ec.difficulty matches 1 if items entity @s weapon.offhand *[custom_data~{heart_of_the_mountain:true}] run tag @s add ec._lhs
# m4 strip the loose FLAT leaf modifiers when their absorbing node is held (so a leaf held BEFORE the
# capstone was fused does not leave a lingering fixed-id modifier once the add is suppressed below). The
# CONDITIONAL leaves (B5 / B6 / B10-luck) already remove-then-conditional-add each tick, so they need no
# strip here. Fires only while the group tag is set (capstone held + not Newcomer).
execute if entity @s[tag=ec._lhb] run attribute @s armor modifier remove evercraft:stoneward_pebble_armor
execute if entity @s[tag=ec._lhb] run attribute @s max_health modifier remove evercraft:vital_acorn_health
execute if entity @s[tag=ec._lhb] run attribute @s armor_toughness modifier remove evercraft:anvil_heart_tough
execute if entity @s[tag=ec._lhb] run attribute @s knockback_resistance modifier remove evercraft:anvil_heart_kb
execute if entity @s[tag=ec._lhb] run attribute @s armor modifier remove evercraft:bulwark_plate_armor
execute if entity @s[tag=ec._lhb] run attribute @s armor_toughness modifier remove evercraft:bulwark_plate_tough
execute if entity @s[tag=ec._lhb] run attribute @s explosion_knockback_resistance modifier remove evercraft:bulwark_plate_ekb
execute if entity @s[tag=ec._lha] run attribute @s attack_damage modifier remove evercraft:resonant_locket_atk
execute if entity @s[tag=ec._lha] run attribute @s attack_damage modifier remove evercraft:ascendant_forgeheart_atk
#
# B1 Stoneward Pebble — +2 Armor (1 extra bar) while held.
execute if items entity @s container.* *[custom_data~{artifact:"stoneward_pebble"}] run tag @s add ec._a
execute unless items entity @s container.* *[custom_data~{artifact:"stoneward_pebble"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"stoneward_pebble"}] if entity @s[tag=ec.sat_stoneward_pebble] run tag @s add ec._a
execute unless entity @s[tag=ec._a] if items entity @s weapon.offhand *[custom_data~{artifact:"stoneward_pebble"}] run tag @s add ec._a
execute if entity @s[tag=ec._a] unless entity @s[tag=ec._lhb] run attribute @s armor modifier add evercraft:stoneward_pebble_armor 2 add_value
tag @s remove ec._a
#
# B2 Vital Acorn — +2 Max Health (1 heart) while held. Flat max_health modifier (existing HP comes via
# effects, none via a flat modifier -> novel; distinct id stacks with Bulwark Plate's armor stack).
execute if items entity @s container.* *[custom_data~{artifact:"vital_acorn"}] run tag @s add ec._a
execute unless items entity @s container.* *[custom_data~{artifact:"vital_acorn"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"vital_acorn"}] if entity @s[tag=ec.sat_vital_acorn] run tag @s add ec._a
execute unless entity @s[tag=ec._a] if items entity @s weapon.offhand *[custom_data~{artifact:"vital_acorn"}] run tag @s add ec._a
execute if entity @s[tag=ec._a] unless entity @s[tag=ec._lhb] run attribute @s max_health modifier add evercraft:vital_acorn_health 2 add_value
tag @s remove ec._a
#
# B5 Sprinter's Anklet — +8% Speed ONLY while sprinting (conditional -> not another flat Speed-I).
# Remove-then-conditional-add (the band_luck idiom) so it strips the moment the player stops sprinting
# OR drops the anklet. movement_speed add_multiplied_base (+0.08 = +8% off base). Its +1% dodge is in
# the m1 LEAF block.
execute if items entity @s container.* *[custom_data~{artifact:"sprinters_anklet"}] run tag @s add ec._a
execute unless items entity @s container.* *[custom_data~{artifact:"sprinters_anklet"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"sprinters_anklet"}] if entity @s[tag=ec.sat_sprinters_anklet] run tag @s add ec._a
execute unless entity @s[tag=ec._a] if items entity @s weapon.offhand *[custom_data~{artifact:"sprinters_anklet"}] run tag @s add ec._a
execute if entity @s[tag=ec._a] run attribute @s movement_speed modifier remove evercraft:sprinters_anklet_spd
execute if entity @s[tag=ec._a] unless entity @s[tag=ec._lhs] if predicate evercraft:sprinting run attribute @s movement_speed modifier add evercraft:sprinters_anklet_spd 0.08 add_multiplied_base
tag @s remove ec._a
#
# B6 Reaver's Knuckle — +1.0 Attack Damage ONLY while above 80% health (the inverted mirror of
# berserkers_fang's LOW-HP trigger -> novel). 80% of the default 20 max HP = 16 (health_above_16 NEW
# predicate, the fixed-threshold form the health_below_* predicates use). Remove-then-conditional-add so
# the buff drops the moment HP falls below the line OR the knuckle is dropped. Its +1% dodge is in the
# m1 LEAF block.
execute if items entity @s container.* *[custom_data~{artifact:"reavers_knuckle"}] run tag @s add ec._a
execute unless items entity @s container.* *[custom_data~{artifact:"reavers_knuckle"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"reavers_knuckle"}] if entity @s[tag=ec.sat_reavers_knuckle] run tag @s add ec._a
execute unless entity @s[tag=ec._a] if items entity @s weapon.offhand *[custom_data~{artifact:"reavers_knuckle"}] run tag @s add ec._a
execute if entity @s[tag=ec._a] run attribute @s attack_damage modifier remove evercraft:reavers_knuckle_atk
execute if entity @s[tag=ec._a] unless entity @s[tag=ec._lha] if predicate evercraft:health_above_16 run attribute @s attack_damage modifier add evercraft:reavers_knuckle_atk 1.0 add_value
tag @s remove ec._a
#
# B7 Anvil Heart — +1 Armor Toughness + 0.15 Knockback Resistance (stagger-proof). KB-resist used by
# earthshaker_core but never paired with toughness on an accessory -> novel. Both fixed-id add_value.
execute if items entity @s container.* *[custom_data~{artifact:"anvil_heart"}] run tag @s add ec._a
execute unless items entity @s container.* *[custom_data~{artifact:"anvil_heart"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"anvil_heart"}] if entity @s[tag=ec.sat_anvil_heart] run tag @s add ec._a
execute unless entity @s[tag=ec._a] if items entity @s weapon.offhand *[custom_data~{artifact:"anvil_heart"}] run tag @s add ec._a
execute if entity @s[tag=ec._a] unless entity @s[tag=ec._lhb] run attribute @s armor_toughness modifier add evercraft:anvil_heart_tough 1 add_value
execute if entity @s[tag=ec._a] unless entity @s[tag=ec._lhb] run attribute @s knockback_resistance modifier add evercraft:anvil_heart_kb 0.15 add_value
tag @s remove ec._a
#
# B10 Resonant Locket — +1.0 Attack Damage (always while held) + CONDITIONAL +1.0 Dream Rate while a
# craft-node marker is within 24 blocks (the ec.cf_node_data marker the Astrolabe/Dowsing pings read).
# The attack_damage is fixed-id always-on; the conditional DR is remove-then-conditional-add (gated on a
# nearby node marker). This is L's ONLY luck modifier; it reports one breakdown line in
# dreams/breakdown/artifacts (under B's craft-luck line per the lattice — the breakdown reads the live
# modifier value, so it shows only while a node is near).
execute if items entity @s container.* *[custom_data~{artifact:"resonant_locket"}] run tag @s add ec._a
execute unless items entity @s container.* *[custom_data~{artifact:"resonant_locket"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"resonant_locket"}] if entity @s[tag=ec.sat_resonant_locket] run tag @s add ec._a
execute unless entity @s[tag=ec._a] if items entity @s weapon.offhand *[custom_data~{artifact:"resonant_locket"}] run tag @s add ec._a
execute if entity @s[tag=ec._a] unless entity @s[tag=ec._lha] run attribute @s attack_damage modifier add evercraft:resonant_locket_atk 1.0 add_value
execute if entity @s[tag=ec._a] run attribute @s luck modifier remove evercraft:resonant_locket_luck
execute if entity @s[tag=ec._a] unless entity @s[tag=ec._lha] if entity @e[type=marker,tag=ec.cf_node_data,distance=..24,limit=1] run attribute @s luck modifier add evercraft:resonant_locket_luck 1.0 add_value
tag @s remove ec._a
#
# B12 Bulwark Plate — +3 Armor + +1 Armor Toughness + 0.10 Explosion Knockback Resistance (the tank
# sub-binding HEAD). Three distinct fixed-id modifiers via the one ec._a scan; all add_value. Distinct
# ids -> stacks with Stoneward Pebble (armor) + Anvil Heart (toughness) without duping any.
execute if items entity @s container.* *[custom_data~{artifact:"bulwark_plate"}] run tag @s add ec._a
execute unless items entity @s container.* *[custom_data~{artifact:"bulwark_plate"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"bulwark_plate"}] if entity @s[tag=ec.sat_bulwark_plate] run tag @s add ec._a
execute unless entity @s[tag=ec._a] if items entity @s weapon.offhand *[custom_data~{artifact:"bulwark_plate"}] run tag @s add ec._a
execute if entity @s[tag=ec._a] unless entity @s[tag=ec._lhb] run attribute @s armor modifier add evercraft:bulwark_plate_armor 3 add_value
execute if entity @s[tag=ec._a] unless entity @s[tag=ec._lhb] run attribute @s armor_toughness modifier add evercraft:bulwark_plate_tough 1 add_value
execute if entity @s[tag=ec._a] unless entity @s[tag=ec._lhb] run attribute @s explosion_knockback_resistance modifier add evercraft:bulwark_plate_ekb 0.10 add_value
tag @s remove ec._a
#
# P2 Ascendant Forgeheart — +2.0 Attack Damage (always while held); its +5.0 Craft Rate lever (sets the
# ec.cr_temp slot in craft_rate/calculate, the ONE writer — m4 HANDOFF #7) is NOT here. The worn-combat
# half is a fixed-id attack_damage add_value. The combat-craft trophy of L's Ascendant Line.
execute if items entity @s container.* *[custom_data~{artifact:"ascendant_forgeheart"}] run tag @s add ec._a
execute unless items entity @s container.* *[custom_data~{artifact:"ascendant_forgeheart"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"ascendant_forgeheart"}] if entity @s[tag=ec.sat_ascendant_forgeheart] run tag @s add ec._a
execute unless entity @s[tag=ec._a] if items entity @s weapon.offhand *[custom_data~{artifact:"ascendant_forgeheart"}] run tag @s add ec._a
execute if entity @s[tag=ec._a] unless entity @s[tag=ec._lha] run attribute @s attack_damage modifier add evercraft:ascendant_forgeheart_atk 2.0 add_value
tag @s remove ec._a
#
# #7 Bastion Totem — party-wide Resistance I aura to the holder + allies within 16 blocks (the
# nether_star_shard beacon idiom). Effect-based (re-applied each tick at a 5t/0.25s decay -> no attribute
# modifier, no accessory_cleanup strip needed; it lapses naturally when the totem is dropped). The 4th
# genuine totem feeding L's Titan Core line. ec._a single-scan.
execute if items entity @s container.* *[custom_data~{artifact:"bastion_totem"}] run tag @s add ec._a
execute unless items entity @s container.* *[custom_data~{artifact:"bastion_totem"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"bastion_totem"}] if entity @s[tag=ec.sat_bastion_totem] run tag @s add ec._a
execute unless entity @s[tag=ec._a] if items entity @s weapon.offhand *[custom_data~{artifact:"bastion_totem"}] run tag @s add ec._a
execute if entity @s[tag=ec._a] run effect give @a[distance=..16] resistance 5 0 false
tag @s remove ec._a

# ============================================================
# === UNCOMMON ACCESSORIES ===
# ============================================================

# Glowstone Pendant — Night Vision
execute if items entity @s container.* *[custom_data~{artifact:"glowstone_pendant"}] unless score @s ec.t_glowpend matches 1 run effect give @s night_vision 15 0 false
execute unless items entity @s container.* *[custom_data~{artifact:"glowstone_pendant"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"glowstone_pendant"}] if entity @s[tag=ec.sat_glowstone_pendant] unless score @s ec.t_glowpend matches 1 run effect give @s night_vision 15 0 false
execute if items entity @s weapon.offhand *[custom_data~{artifact:"glowstone_pendant"}] unless score @s ec.t_glowpend matches 1 run effect give @s night_vision 15 0 false

# Iron Talisman — +1 Armor (mirror the stoneward_pebble armor-modifier idiom: detect held into ec._a
# across container/offhand/satchel, then add a fixed-id armor modifier; stripped on unequip in
# accessory_cleanup. No ec._lhb guard — iron_talisman is NOT a titan_bulwark/heart_of_the_mountain leaf;
# its own resist-family fusion supersede lives in bulwark_stone/soulguard_aegis, not here.)
execute if items entity @s container.* *[custom_data~{artifact:"iron_talisman"}] run tag @s add ec._a
execute unless items entity @s container.* *[custom_data~{artifact:"iron_talisman"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"iron_talisman"}] if entity @s[tag=ec.sat_iron_talisman] run tag @s add ec._a
execute unless entity @s[tag=ec._a] if items entity @s weapon.offhand *[custom_data~{artifact:"iron_talisman"}] run tag @s add ec._a
execute if entity @s[tag=ec._a] run attribute @s armor modifier add evercraft:iron_talisman_armor 1 add_value
tag @s remove ec._a

# Featherweight Stone — Slow Falling
execute if items entity @s container.* *[custom_data~{artifact:"featherweight_stone"}] unless score @s ec.t_feather matches 1 run effect give @s slow_falling 5 0 false
execute unless items entity @s container.* *[custom_data~{artifact:"featherweight_stone"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"featherweight_stone"}] if entity @s[tag=ec.sat_featherweight_stone] unless score @s ec.t_feather matches 1 run effect give @s slow_falling 5 0 false
execute if items entity @s weapon.offhand *[custom_data~{artifact:"featherweight_stone"}] unless score @s ec.t_feather matches 1 run effect give @s slow_falling 5 0 false

# ============================================================
# === RARE ACCESSORIES ===
# ============================================================

# Diamond Ring — +1 Dream Rate
execute if items entity @s container.* *[custom_data~{artifact:"aquamarine_ring"}] unless score @s ec.t_dring matches 1 run attribute @s luck modifier add evercraft:aquamarine_ring_luck 1.0 add_value
execute unless items entity @s container.* *[custom_data~{artifact:"aquamarine_ring"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"aquamarine_ring"}] if entity @s[tag=ec.sat_aquamarine_ring] unless score @s ec.t_dring matches 1 run attribute @s luck modifier add evercraft:aquamarine_ring_luck 1.0 add_value
execute if items entity @s weapon.offhand *[custom_data~{artifact:"aquamarine_ring"}] unless score @s ec.t_dring matches 1 run attribute @s luck modifier add evercraft:aquamarine_ring_luck 1.0 add_value

# Ruin Watch — +1 Dream Rate + Right-click shows structure timers
execute if items entity @s container.* *[custom_data~{artifact:"ruin_watch"}] unless score @s ec.t_rwatch matches 1 run attribute @s luck modifier add evercraft:ruin_watch_luck 1.0 add_value
execute unless items entity @s container.* *[custom_data~{artifact:"ruin_watch"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"ruin_watch"}] if entity @s[tag=ec.sat_ruin_watch] unless score @s ec.t_rwatch matches 1 run attribute @s luck modifier add evercraft:ruin_watch_luck 1.0 add_value
execute if items entity @s weapon.offhand *[custom_data~{artifact:"ruin_watch"}] unless score @s ec.t_rwatch matches 1 run attribute @s luck modifier add evercraft:ruin_watch_luck 1.0 add_value

# Heartstone — Regeneration I (unconditional, instant heal fallback if Regen II+)
# OPT-77: Tag consolidation (was 4 item scans → 2)
execute if items entity @s container.* *[custom_data~{artifact:"heartstone"}] run tag @s add ec._a
execute unless items entity @s container.* *[custom_data~{artifact:"heartstone"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"heartstone"}] if entity @s[tag=ec.sat_heartstone] run tag @s add ec._a
execute unless entity @s[tag=ec._a] if items entity @s weapon.offhand *[custom_data~{artifact:"heartstone"}] run tag @s add ec._a
execute if entity @s[tag=ec._a] unless score @s ec.t_heart matches 1 unless entity @s[tag=ec.regen_capped] run effect give @s regeneration 5 0 false
execute if entity @s[tag=ec._a] unless score @s ec.t_heart matches 1 if entity @s[tag=ec.regen_capped] run function evercraft:artifacts/accessories/regen_fallback
tag @s remove ec._a

# Stormcatcher Shard — Haste I
execute if items entity @s container.* *[custom_data~{artifact:"stormcatcher_shard"}] unless score @s ec.t_storm matches 1 run effect give @s haste 5 0 false
execute unless items entity @s container.* *[custom_data~{artifact:"stormcatcher_shard"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"stormcatcher_shard"}] if entity @s[tag=ec.sat_stormcatcher_shard] unless score @s ec.t_storm matches 1 run effect give @s haste 5 0 false
execute if items entity @s weapon.offhand *[custom_data~{artifact:"stormcatcher_shard"}] unless score @s ec.t_storm matches 1 run effect give @s haste 5 0 false

# Geologist's Loupe — CONDITIONAL +2 Dream Rate ONLY while actively mining (Family B new leaf —
# art-B; re-homed conditional-DR craft charm). Remove-then-conditional-add so the value is exact
# every tick (the band_luck idiom): while held AND the craft/mine activity window is open
# (ec.cf_actwin set to 100t by grant_verb on each verb, counting down), grant +2.0; the bare
# remove handles the not-held AND the idle (window expired) cases so the DR drops ~5s after the
# last block break. Fixed-id modifier (idempotent — two copies overwrite, m4 Layer-2). Detect
# held into ec._a so container.* + offhand only scan once.
execute if items entity @s container.* *[custom_data~{artifact:"geologist_loupe"}] run tag @s add ec._a
execute unless items entity @s container.* *[custom_data~{artifact:"geologist_loupe"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"geologist_loupe"}] if entity @s[tag=ec.sat_geologist_loupe] run tag @s add ec._a
execute unless entity @s[tag=ec._a] if items entity @s weapon.offhand *[custom_data~{artifact:"geologist_loupe"}] run tag @s add ec._a
execute if entity @s[tag=ec._a] run attribute @s luck modifier remove evercraft:geologist_loupe_luck
execute if entity @s[tag=ec._a] if score @s ec.cf_actwin matches 1.. run attribute @s luck modifier add evercraft:geologist_loupe_luck 2.0 add_value
tag @s remove ec._a

# ============================================================
# === ORNATE ACCESSORIES ===
# ============================================================

# Miner's Lantern — Night Vision + Luck I + Ore Ping
# OPT: Tag consolidation (was 7 item scans → 2)
execute if items entity @s container.* *[custom_data~{artifact:"miners_lantern"}] run tag @s add ec._a
execute unless items entity @s container.* *[custom_data~{artifact:"miners_lantern"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"miners_lantern"}] if entity @s[tag=ec.sat_miners_lantern] run tag @s add ec._a
execute unless entity @s[tag=ec._a] if items entity @s weapon.offhand *[custom_data~{artifact:"miners_lantern"}] run tag @s add ec._a
execute if entity @s[tag=ec._a] run effect give @s night_vision 15 0 false
execute if entity @s[tag=ec._a] run attribute @s luck modifier add evercraft:miners_lantern_luck 1.0 add_value
execute if entity @s[tag=ec._a] run function evercraft:artifacts/accessories/ore_ping
tag @s remove ec._a
# Miner's Lantern — Fortune +2 on held pickaxe/shovel + cleanup
function evercraft:artifacts/abilities/miners_blessing
execute if entity @s[tag=ec.miners_lantern_fortune] run function evercraft:artifacts/abilities/miners_blessing_cleanup

# Seer's Compass — Night Vision + Speed I
# OPT: Tag consolidation (was 4 item scans → 2)
execute if items entity @s container.* *[custom_data~{artifact:"seers_compass"}] run tag @s add ec._a
execute unless items entity @s container.* *[custom_data~{artifact:"seers_compass"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"seers_compass"}] if entity @s[tag=ec.sat_seers_compass] run tag @s add ec._a
execute unless entity @s[tag=ec._a] if items entity @s weapon.offhand *[custom_data~{artifact:"seers_compass"}] run tag @s add ec._a
execute if entity @s[tag=ec._a] run effect give @s night_vision 15 0 false
execute if entity @s[tag=ec._a] run effect give @s speed 5 0 false
tag @s remove ec._a

# Merchant's Coin — +1 Dream Rate + Trade Discount (Hero of the Village)
# OPT: Tag consolidation (was 4 item scans → 2)
execute if items entity @s container.* *[custom_data~{artifact:"merchants_coin"}] run tag @s add ec._a
execute unless items entity @s container.* *[custom_data~{artifact:"merchants_coin"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"merchants_coin"}] if entity @s[tag=ec.sat_merchants_coin] run tag @s add ec._a
execute unless entity @s[tag=ec._a] if items entity @s weapon.offhand *[custom_data~{artifact:"merchants_coin"}] run tag @s add ec._a
execute if entity @s[tag=ec._a] unless score @s ec.t_merchant matches 1 run attribute @s luck modifier add evercraft:merchants_coin_luck 0.5 add_value
execute if entity @s[tag=ec._a] run effect give @s hero_of_the_village 5 0 true
tag @s remove ec._a

# Spelunker's Echo — Night Vision + Haste I + Treasure Ping
# OPT: Tag consolidation (was 6 item scans → 2)
execute if items entity @s container.* *[custom_data~{artifact:"spelunkers_echo"}] run tag @s add ec._a
execute unless items entity @s container.* *[custom_data~{artifact:"spelunkers_echo"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"spelunkers_echo"}] if entity @s[tag=ec.sat_spelunkers_echo] run tag @s add ec._a
execute unless entity @s[tag=ec._a] if items entity @s weapon.offhand *[custom_data~{artifact:"spelunkers_echo"}] run tag @s add ec._a
execute if entity @s[tag=ec._a] run effect give @s night_vision 15 0 false
execute if entity @s[tag=ec._a] run effect give @s haste 5 0 false
execute if entity @s[tag=ec._a] run function evercraft:artifacts/accessories/chest_ping
tag @s remove ec._a

# Healer's Salve — Regeneration I (instant heal fallback if Regen II+)
execute if items entity @s container.* *[custom_data~{artifact:"healers_salve"}] unless score @s ec.t_healer matches 1 unless entity @s[tag=ec.regen_capped] run effect give @s regeneration 5 0 false
execute unless items entity @s container.* *[custom_data~{artifact:"healers_salve"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"healers_salve"}] if entity @s[tag=ec.sat_healers_salve] unless score @s ec.t_healer matches 1 unless entity @s[tag=ec.regen_capped] run effect give @s regeneration 5 0 false
execute if items entity @s weapon.offhand *[custom_data~{artifact:"healers_salve"}] unless score @s ec.t_healer matches 1 unless entity @s[tag=ec.regen_capped] run effect give @s regeneration 5 0 false
execute if items entity @s container.* *[custom_data~{artifact:"healers_salve"}] unless score @s ec.t_healer matches 1 if entity @s[tag=ec.regen_capped] run function evercraft:artifacts/accessories/regen_fallback
execute unless items entity @s container.* *[custom_data~{artifact:"healers_salve"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"healers_salve"}] if entity @s[tag=ec.sat_healers_salve] unless score @s ec.t_healer matches 1 if entity @s[tag=ec.regen_capped] run function evercraft:artifacts/accessories/regen_fallback
execute if items entity @s weapon.offhand *[custom_data~{artifact:"healers_salve"}] unless score @s ec.t_healer matches 1 if entity @s[tag=ec.regen_capped] run function evercraft:artifacts/accessories/regen_fallback
# +2 Max Health while held (the titans_plate max_health idiom; 2 hearts = 4 HP). Re-add each tick by id (idempotent); stripped on drop in accessory_cleanup.
execute if items entity @s container.* *[custom_data~{artifact:"healers_salve"}] run attribute @s max_health modifier add evercraft:healers_salve_health 4 add_value
execute unless items entity @s container.* *[custom_data~{artifact:"healers_salve"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"healers_salve"}] if entity @s[tag=ec.sat_healers_salve] run attribute @s max_health modifier add evercraft:healers_salve_health 4 add_value
execute if items entity @s weapon.offhand *[custom_data~{artifact:"healers_salve"}] run attribute @s max_health modifier add evercraft:healers_salve_health 4 add_value

# Wind Chime — Speed I
execute if items entity @s container.* *[custom_data~{artifact:"wind_chime"}] unless score @s ec.t_wind matches 1 run effect give @s speed 5 0 false
execute unless items entity @s container.* *[custom_data~{artifact:"wind_chime"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"wind_chime"}] if entity @s[tag=ec.sat_wind_chime] unless score @s ec.t_wind matches 1 run effect give @s speed 5 0 false
execute if items entity @s weapon.offhand *[custom_data~{artifact:"wind_chime"}] unless score @s ec.t_wind matches 1 run effect give @s speed 5 0 false
# Wind Chime — fall-damage reduction (softer landings; the featherscale_down fall_damage_multiplier idiom). Always-on while held.
execute if items entity @s container.* *[custom_data~{artifact:"wind_chime"}] run attribute @s fall_damage_multiplier modifier add evercraft:wind_chime_fall -0.5 add_multiplied_base
execute unless items entity @s container.* *[custom_data~{artifact:"wind_chime"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"wind_chime"}] if entity @s[tag=ec.sat_wind_chime] run attribute @s fall_damage_multiplier modifier add evercraft:wind_chime_fall -0.5 add_multiplied_base
execute if items entity @s weapon.offhand *[custom_data~{artifact:"wind_chime"}] run attribute @s fall_damage_multiplier modifier add evercraft:wind_chime_fall -0.5 add_multiplied_base

# Angler's Pearl — +1 Dream Rate
execute if items entity @s container.* *[custom_data~{artifact:"anglers_pearl"}] unless score @s ec.t_angler matches 1 run attribute @s luck modifier add evercraft:anglers_pearl_luck 1.0 add_value
execute unless items entity @s container.* *[custom_data~{artifact:"anglers_pearl"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"anglers_pearl"}] if entity @s[tag=ec.sat_anglers_pearl] unless score @s ec.t_angler matches 1 run attribute @s luck modifier add evercraft:anglers_pearl_luck 1.0 add_value
execute if items entity @s weapon.offhand *[custom_data~{artifact:"anglers_pearl"}] unless score @s ec.t_angler matches 1 run attribute @s luck modifier add evercraft:anglers_pearl_luck 1.0 add_value
# Angler's Pearl — Lure II + Luck of the Sea I on held fishing rod + cleanup
function evercraft:artifacts/abilities/fast_fishing
execute if entity @s[tag=ec.anglers_pearl_fishing] run function evercraft:artifacts/abilities/fast_fishing_cleanup

# Soul Lantern Fragment — XP Boost # OPT: Tag consolidation
# cap-K: the soul_lantern is absorbed into the Surveyor Line -> the Demiurge's Spirit Artifact. A holder of
# either also gets the XP-orb perk (the ec._a single-scan tags on the loose leaf OR an absorbing node, and
# xp_boost_check fires ONCE if ec._a is set — so loose + node never double-fire; idempotent single roll).
execute if items entity @s container.* *[custom_data~{artifact:"soul_lantern_fragment"}] run tag @s add ec._a
execute unless items entity @s container.* *[custom_data~{artifact:"soul_lantern_fragment"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"soul_lantern_fragment"}] if entity @s[tag=ec.sat_soul_lantern_fragment] run tag @s add ec._a
execute unless entity @s[tag=ec._a] if items entity @s weapon.offhand *[custom_data~{artifact:"soul_lantern_fragment"}] run tag @s add ec._a
execute unless entity @s[tag=ec._a] if items entity @s container.* *[custom_data~{surveyor_line:true}] run tag @s add ec._a
execute unless entity @s[tag=ec._a] unless items entity @s container.* *[custom_data~{surveyor_line:true}] unless items entity @s weapon.offhand *[custom_data~{surveyor_line:true}] if entity @s[tag=ec.sat_surveyor_line] run tag @s add ec._a
execute unless entity @s[tag=ec._a] if items entity @s weapon.offhand *[custom_data~{surveyor_line:true}] run tag @s add ec._a
execute unless entity @s[tag=ec._a] if items entity @s container.* *[custom_data~{demiurges_capstone:true}] run tag @s add ec._a
execute unless entity @s[tag=ec._a] unless items entity @s container.* *[custom_data~{demiurges_capstone:true}] unless items entity @s weapon.offhand *[custom_data~{demiurges_capstone:true}] if entity @s[tag=ec.sat_demiurges_capstone] run tag @s add ec._a
execute unless entity @s[tag=ec._a] if items entity @s weapon.offhand *[custom_data~{demiurges_capstone:true}] run tag @s add ec._a
execute if entity @s[tag=ec._a] run function evercraft:artifacts/accessories/xp_boost_check
# XP magnet (12 blocks) — the graviton_core XP-magnet idiom (apply_effects:8), radius 12 to match the
# "XP orbs magnetize from 12 blocks" lore. Must run at @s (radius measured from the holder). Pulls all
# nearby experience orbs to the bearer; idempotent (single ec._a scan covers loose + node + satchel).
execute if entity @s[tag=ec._a] at @s run tp @e[type=experience_orb,distance=..12] @s
tag @s remove ec._a

# Farmer's Almanac — Bonus bone meal on random nearby crop # OPT: Tag consolidation
execute if items entity @s container.* *[custom_data~{artifact:"farmers_almanac"}] run tag @s add ec._a
execute unless items entity @s container.* *[custom_data~{artifact:"farmers_almanac"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"farmers_almanac"}] if entity @s[tag=ec.sat_farmers_almanac] run tag @s add ec._a
execute unless entity @s[tag=ec._a] if items entity @s weapon.offhand *[custom_data~{artifact:"farmers_almanac"}] run tag @s add ec._a
execute if entity @s[tag=ec._a] run function evercraft:artifacts/accessories/crop_boost
tag @s remove ec._a

# Berserker's Fang — Strength I when below 50% HP + Haste I when below 30% HP
execute if predicate evercraft:health_below_10 if items entity @s container.* *[custom_data~{artifact:"berserkers_fang"}] run effect give @s strength 5 0 false
execute if predicate evercraft:health_below_10 unless items entity @s container.* *[custom_data~{artifact:"berserkers_fang"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"berserkers_fang"}] if entity @s[tag=ec.sat_berserkers_fang] run effect give @s strength 5 0 false
execute if predicate evercraft:health_below_10 if items entity @s weapon.offhand *[custom_data~{artifact:"berserkers_fang"}] run effect give @s strength 5 0 false
execute if predicate evercraft:health_below_6 if items entity @s container.* *[custom_data~{artifact:"berserkers_fang"}] run effect give @s haste 5 0 false
execute if predicate evercraft:health_below_6 unless items entity @s container.* *[custom_data~{artifact:"berserkers_fang"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"berserkers_fang"}] if entity @s[tag=ec.sat_berserkers_fang] run effect give @s haste 5 0 false
execute if predicate evercraft:health_below_6 if items entity @s weapon.offhand *[custom_data~{artifact:"berserkers_fang"}] run effect give @s haste 5 0 false

# Cartographer's Lens — Trailblazer's Mark: sprint-gated Speed I + a fading particle trail behind the
# trailblazer (the "reads the road" kit). Sprint-gated so it rewards travel, not idling (the old ungated
# Speed + unadvertised Saturation are dropped). The sneak-RC home-bearing ping lives in the mainhand
# sneak-active region below (reuses the wayfarer bed_bearing readout — "points you home").
# OPT: Tag consolidation (was 4 item scans → 2)
execute if items entity @s container.* *[custom_data~{artifact:"cartographers_lens"}] run tag @s add ec._a
execute unless items entity @s container.* *[custom_data~{artifact:"cartographers_lens"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"cartographers_lens"}] if entity @s[tag=ec.sat_cartographers_lens] run tag @s add ec._a
execute unless entity @s[tag=ec._a] if items entity @s weapon.offhand *[custom_data~{artifact:"cartographers_lens"}] run tag @s add ec._a
execute if entity @s[tag=ec._a] if predicate evercraft:sprinting run effect give @s speed 5 0 false
execute if entity @s[tag=ec._a] if predicate evercraft:sprinting at @s run particle wax_off ~ ~0.1 ~ 0.2 0 0.2 0.01 4
tag @s remove ec._a

# Enchanted Monocle — Night Vision + +1 Dream Rate
# OPT: Tag consolidation (was 4 item scans → 2)
execute if items entity @s container.* *[custom_data~{artifact:"enchanted_monocle"}] run tag @s add ec._a
execute unless items entity @s container.* *[custom_data~{artifact:"enchanted_monocle"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"enchanted_monocle"}] if entity @s[tag=ec.sat_enchanted_monocle] run tag @s add ec._a
execute unless entity @s[tag=ec._a] if items entity @s weapon.offhand *[custom_data~{artifact:"enchanted_monocle"}] run tag @s add ec._a
execute if entity @s[tag=ec._a] run effect give @s night_vision 15 0 false
execute if entity @s[tag=ec._a] run attribute @s luck modifier add evercraft:enchanted_monocle_luck 1.0 add_value
tag @s remove ec._a

# Phoenix Feather — Fire Resistance + Rebirth death save (ornate)
execute if items entity @s container.* *[custom_data~{artifact:"phoenix_feather"}] unless score @s ec.t_phoenix matches 1 run effect give @s fire_resistance 15 0 false
execute unless items entity @s container.* *[custom_data~{artifact:"phoenix_feather"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"phoenix_feather"}] if entity @s[tag=ec.sat_phoenix_feather] unless score @s ec.t_phoenix matches 1 run effect give @s fire_resistance 15 0 false
execute if items entity @s weapon.offhand *[custom_data~{artifact:"phoenix_feather"}] unless score @s ec.t_phoenix matches 1 run effect give @s fire_resistance 15 0 false
# Rebirth — on an otherwise-lethal blow (health_below_6) with the Feather carried, fire phoenix_feather_save
# (the SHARED phoenix rebirth body) and set its OWN 10-min cooldown ec.cd_feather. Standalone save (NOT a
# Soulguard node) so no _sghide suppression; own cd id keeps it distinct from the mythical Phoenix Totem's
# ec.cd_phoenix. ec._a single-scan (container.* + satchel + offhand), same idiom as ring_of_undying above.
# Newcomer-exempt. Idempotent + multi-copy-safe (cooldown SET after the first fire).
execute if items entity @s container.* *[custom_data~{artifact:"phoenix_feather"}] run tag @s add ec._a
execute unless items entity @s container.* *[custom_data~{artifact:"phoenix_feather"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"phoenix_feather"}] if entity @s[tag=ec.sat_phoenix_feather] run tag @s add ec._a
execute unless entity @s[tag=ec._a] if items entity @s weapon.offhand *[custom_data~{artifact:"phoenix_feather"}] run tag @s add ec._a
execute if entity @s[tag=ec._a] if predicate evercraft:health_below_6 unless score @s ec.cd_feather matches 1.. unless score @s ec.difficulty matches 1 run function evercraft:artifacts/abilities/phoenix_feather_save
tag @s remove ec._a

# Warden's Echo — Night Vision # OPT: Tag consolidation
execute if items entity @s container.* *[custom_data~{artifact:"wardens_echo"}] run tag @s add ec._a
execute unless items entity @s container.* *[custom_data~{artifact:"wardens_echo"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"wardens_echo"}] if entity @s[tag=ec.sat_wardens_echo] run tag @s add ec._a
execute unless entity @s[tag=ec._a] if items entity @s weapon.offhand *[custom_data~{artifact:"wardens_echo"}] run tag @s add ec._a
execute if entity @s[tag=ec._a] run effect give @s night_vision 15 0 false
tag @s remove ec._a

# ============================================================
# === EXQUISITE ACCESSORIES ===
# ============================================================

# Ring of Undying — +1 Dream Rate
execute if items entity @s container.* *[custom_data~{artifact:"ring_of_undying"}] unless score @s ec.t_undying matches 1 run attribute @s luck modifier add evercraft:ring_of_undying_luck 1.0 add_value
execute unless items entity @s container.* *[custom_data~{artifact:"ring_of_undying"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"ring_of_undying"}] if entity @s[tag=ec.sat_ring_of_undying] unless score @s ec.t_undying matches 1 run attribute @s luck modifier add evercraft:ring_of_undying_luck 1.0 add_value
execute if items entity @s weapon.offhand *[custom_data~{artifact:"ring_of_undying"}] unless score @s ec.t_undying matches 1 run attribute @s luck modifier add evercraft:ring_of_undying_luck 1.0 add_value

# Claude's Eye — +1 Dream Rate + Night Vision
# OPT: Tag consolidation (was 4 item scans → 2)
execute if items entity @s container.* *[custom_data~{artifact:"claudes_eye"}] run tag @s add ec._a
execute unless items entity @s container.* *[custom_data~{artifact:"claudes_eye"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"claudes_eye"}] if entity @s[tag=ec.sat_claudes_eye] run tag @s add ec._a
execute unless entity @s[tag=ec._a] if items entity @s weapon.offhand *[custom_data~{artifact:"claudes_eye"}] run tag @s add ec._a
execute if entity @s[tag=ec._a] run attribute @s luck modifier add evercraft:claudes_eye_luck 1.0 add_value
execute if entity @s[tag=ec._a] run effect give @s night_vision 15 0 false
tag @s remove ec._a

# Void Heart — Resistance I + Void Recall (teleport to spawn when near death, 5min cd)
# OPT: Tag consolidation
execute if items entity @s container.* *[custom_data~{artifact:"void_heart"}] run tag @s add ec._a
execute unless items entity @s container.* *[custom_data~{artifact:"void_heart"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"void_heart"}] if entity @s[tag=ec.sat_void_heart] run tag @s add ec._a
execute unless entity @s[tag=ec._a] if items entity @s weapon.offhand *[custom_data~{artifact:"void_heart"}] run tag @s add ec._a
execute if entity @s[tag=ec._a] unless score @s ec.t_voidhrt matches 1 run effect give @s resistance 5 0 false
# Void Recall: triggers at 3 hearts (health_below_6) for better one-shot protection.
# m4 Layer-1 (cap-D, G6): SUPPRESS this loose save when a Soulguard node that ABSORBS Void Heart is held
# (the Lifewarden or the grand Soulguard Aegis) — the consolidated soulguard_save (shared ec.cd_save
# bucket) handles the revive instead, so a re-acquired loose Void Heart cannot add a 4th independent
# save. Newcomer-exempt (`unless ec.difficulty matches 1`): casual players keep the loose save stacked.
execute if entity @s[tag=ec._a] if predicate evercraft:health_below_6 unless score @s ec.cd_void matches 1.. unless score @s ec.difficulty matches 1 if items entity @s container.* *[custom_data~{lifewarden:true}] run tag @s add ec._sghide
execute if entity @s[tag=ec._a] if predicate evercraft:health_below_6 unless score @s ec.cd_void matches 1.. unless score @s ec.difficulty matches 1 unless items entity @s container.* *[custom_data~{lifewarden:true}] unless items entity @s weapon.offhand *[custom_data~{lifewarden:true}] if entity @s[tag=ec.sat_lifewarden] run tag @s add ec._sghide
execute if entity @s[tag=ec._a] if predicate evercraft:health_below_6 unless score @s ec.cd_void matches 1.. unless score @s ec.difficulty matches 1 if items entity @s weapon.offhand *[custom_data~{lifewarden:true}] run tag @s add ec._sghide
execute if entity @s[tag=ec._a] if predicate evercraft:health_below_6 unless score @s ec.cd_void matches 1.. unless score @s ec.difficulty matches 1 if items entity @s container.* *[custom_data~{soulguard_aegis:true}] run tag @s add ec._sghide
execute if entity @s[tag=ec._a] if predicate evercraft:health_below_6 unless score @s ec.cd_void matches 1.. unless score @s ec.difficulty matches 1 unless items entity @s container.* *[custom_data~{soulguard_aegis:true}] unless items entity @s weapon.offhand *[custom_data~{soulguard_aegis:true}] if entity @s[tag=ec.sat_soulguard_aegis] run tag @s add ec._sghide
execute if entity @s[tag=ec._a] if predicate evercraft:health_below_6 unless score @s ec.cd_void matches 1.. unless score @s ec.difficulty matches 1 if items entity @s weapon.offhand *[custom_data~{soulguard_aegis:true}] run tag @s add ec._sghide
execute if entity @s[tag=ec._a] if predicate evercraft:health_below_6 unless score @s ec.cd_void matches 1.. unless entity @s[tag=ec._sghide] run function evercraft:artifacts/abilities/void_heart_save
tag @s remove ec._sghide
tag @s remove ec._a

# Warden Totem — Night Vision + Darkness immunity # OPT: Tag consolidation
execute if items entity @s container.* *[custom_data~{artifact:"warden_totem"}] run tag @s add ec._a
execute unless items entity @s container.* *[custom_data~{artifact:"warden_totem"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"warden_totem"}] if entity @s[tag=ec.sat_warden_totem] run tag @s add ec._a
execute unless entity @s[tag=ec._a] if items entity @s weapon.offhand *[custom_data~{artifact:"warden_totem"}] run tag @s add ec._a
execute if entity @s[tag=ec._a] run effect give @s night_vision 15 0 false
execute if entity @s[tag=ec._a] run effect clear @s darkness
tag @s remove ec._a

# Soul Protection — Resistance I + Absorption I + Death Save (3min cd)
# OPT: Tag consolidation (was 4 item scans → 2)
execute if items entity @s container.* *[custom_data~{artifact:"soul_protection"}] run tag @s add ec._a
execute unless items entity @s container.* *[custom_data~{artifact:"soul_protection"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"soul_protection"}] if entity @s[tag=ec.sat_soul_protection] run tag @s add ec._a
execute unless entity @s[tag=ec._a] if items entity @s weapon.offhand *[custom_data~{artifact:"soul_protection"}] run tag @s add ec._a
execute if entity @s[tag=ec._a] run effect give @s resistance 5 0 false
execute if entity @s[tag=ec._a] run effect give @s absorption 5 0 false
execute if entity @s[tag=ec._a] run effect give @s fire_resistance 15 0 false
execute if entity @s[tag=ec._a] run effect clear @s wither
# Soul Shield: triggers at 3 hearts (health_below_6) for better one-shot protection.
# m4 Layer-1 (cap-D, G6): SUPPRESS this loose save when a Soulguard node that ABSORBS Soul Protection is
# held (the Grand Totem or the grand Soulguard Aegis) — the consolidated soulguard_save (shared
# ec.cd_save bucket) handles the revive instead. Newcomer-exempt.
execute if entity @s[tag=ec._a] if predicate evercraft:health_below_6 unless score @s ec.cd_soul matches 1.. unless score @s ec.difficulty matches 1 if items entity @s container.* *[custom_data~{grand_totem:true}] run tag @s add ec._sghide
execute if entity @s[tag=ec._a] if predicate evercraft:health_below_6 unless score @s ec.cd_soul matches 1.. unless score @s ec.difficulty matches 1 unless items entity @s container.* *[custom_data~{grand_totem:true}] unless items entity @s weapon.offhand *[custom_data~{grand_totem:true}] if entity @s[tag=ec.sat_grand_totem] run tag @s add ec._sghide
execute if entity @s[tag=ec._a] if predicate evercraft:health_below_6 unless score @s ec.cd_soul matches 1.. unless score @s ec.difficulty matches 1 if items entity @s weapon.offhand *[custom_data~{grand_totem:true}] run tag @s add ec._sghide
execute if entity @s[tag=ec._a] if predicate evercraft:health_below_6 unless score @s ec.cd_soul matches 1.. unless score @s ec.difficulty matches 1 if items entity @s container.* *[custom_data~{soulguard_aegis:true}] run tag @s add ec._sghide
execute if entity @s[tag=ec._a] if predicate evercraft:health_below_6 unless score @s ec.cd_soul matches 1.. unless score @s ec.difficulty matches 1 unless items entity @s container.* *[custom_data~{soulguard_aegis:true}] unless items entity @s weapon.offhand *[custom_data~{soulguard_aegis:true}] if entity @s[tag=ec.sat_soulguard_aegis] run tag @s add ec._sghide
execute if entity @s[tag=ec._a] if predicate evercraft:health_below_6 unless score @s ec.cd_soul matches 1.. unless score @s ec.difficulty matches 1 if items entity @s weapon.offhand *[custom_data~{soulguard_aegis:true}] run tag @s add ec._sghide
execute if entity @s[tag=ec._a] if predicate evercraft:health_below_6 unless score @s ec.cd_soul matches 1.. unless entity @s[tag=ec._sghide] run function evercraft:artifacts/abilities/soul_protection_save
tag @s remove ec._sghide
tag @s remove ec._a

# Phoenix Totem — Auto-Revive Death Save (5min cd) — NEW Family-D totem leaf #6 (art-D)
# The mythical auto-revive: on a fatal blow (health_below_6) it fires the rebirth save (full heal +
# totem buffs) and sets a 5-minute cooldown so it can't chain-revive. Death-save cooldown-gated per id
# (m4 / G6): the ec.cd_phoenix gate is idempotent + multi-copy-safe by construction — two copies of the
# totem still fire ONE save (the cooldown sets after the first), never two. ec._a single-scan
# consolidation (container.* + offhand), same idiom as soul_protection / void_heart above.
execute if items entity @s container.* *[custom_data~{artifact:"phoenix_totem"}] run tag @s add ec._a
execute unless items entity @s container.* *[custom_data~{artifact:"phoenix_totem"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"phoenix_totem"}] if entity @s[tag=ec.sat_phoenix_totem] run tag @s add ec._a
execute unless entity @s[tag=ec._a] if items entity @s weapon.offhand *[custom_data~{artifact:"phoenix_totem"}] run tag @s add ec._a
# m4 Layer-1 (cap-D, G6): SUPPRESS this loose auto-revive when a Soulguard node that ABSORBS the Phoenix
# Totem is held (the Grand Totem or the grand Soulguard Aegis) — the consolidated soulguard_save (shared
# ec.cd_save bucket) handles the revive instead. Newcomer-exempt.
execute if entity @s[tag=ec._a] if predicate evercraft:health_below_6 unless score @s ec.cd_phoenix matches 1.. unless score @s ec.difficulty matches 1 if items entity @s container.* *[custom_data~{grand_totem:true}] run tag @s add ec._sghide
execute if entity @s[tag=ec._a] if predicate evercraft:health_below_6 unless score @s ec.cd_phoenix matches 1.. unless score @s ec.difficulty matches 1 unless items entity @s container.* *[custom_data~{grand_totem:true}] unless items entity @s weapon.offhand *[custom_data~{grand_totem:true}] if entity @s[tag=ec.sat_grand_totem] run tag @s add ec._sghide
execute if entity @s[tag=ec._a] if predicate evercraft:health_below_6 unless score @s ec.cd_phoenix matches 1.. unless score @s ec.difficulty matches 1 if items entity @s weapon.offhand *[custom_data~{grand_totem:true}] run tag @s add ec._sghide
execute if entity @s[tag=ec._a] if predicate evercraft:health_below_6 unless score @s ec.cd_phoenix matches 1.. unless score @s ec.difficulty matches 1 if items entity @s container.* *[custom_data~{soulguard_aegis:true}] run tag @s add ec._sghide
execute if entity @s[tag=ec._a] if predicate evercraft:health_below_6 unless score @s ec.cd_phoenix matches 1.. unless score @s ec.difficulty matches 1 unless items entity @s container.* *[custom_data~{soulguard_aegis:true}] unless items entity @s weapon.offhand *[custom_data~{soulguard_aegis:true}] if entity @s[tag=ec.sat_soulguard_aegis] run tag @s add ec._sghide
execute if entity @s[tag=ec._a] if predicate evercraft:health_below_6 unless score @s ec.cd_phoenix matches 1.. unless score @s ec.difficulty matches 1 if items entity @s weapon.offhand *[custom_data~{soulguard_aegis:true}] run tag @s add ec._sghide
execute if entity @s[tag=ec._a] if predicate evercraft:health_below_6 unless score @s ec.cd_phoenix matches 1.. unless entity @s[tag=ec._sghide] run function evercraft:artifacts/abilities/phoenix_totem_save
tag @s remove ec._sghide
tag @s remove ec._a

# Fireforged 4pc — Phoenix Rebirth Death Save (1 hour cd) — exquisite armor-SET 4pc marquee (Wave 3 §2D)
# The 4pc headline ("Set 4pc: revive on a fatal blow") was notify-only; this wires the REAL save. On a fatal
# blow (health_below_6) while wearing the full Fireforged set (tag fireforged_4pc, maintained by sets/check_sets:
# bonus_4pc adds it, remove_4pc strips it), fire the SHARED phoenix rebirth body (full heal + totem buffs +
# visuals) — REUSES phoenix_totem_save_inner, NO duplicated save logic — and set its OWN long cooldown
# (ec.fireforged_cd, 3600s = 1 hour, so it does NOT cheaply stack with a held Phoenix
# Totem/Feather). Decremented in the cd_* tick-down block above (one writer beside this source-set; 1s
# cadence -> VALUE = SECONDS). Newcomer-exempt (ec.difficulty 1). Single gated call into fireforged_4pc_save
# (mirror of phoenix_feather_save): it runs the shared body THEN sets the cd in one fn, so the heal can't
# de-arm the health_below_6 gate before the cooldown lands (which would chain-revive). Cooldown-gated +
# multi-fire-safe by construction (cd SET after the first fire).
execute if entity @s[tag=fireforged_4pc] if predicate evercraft:health_below_6 unless score @s ec.fireforged_cd matches 1.. unless score @s ec.difficulty matches 1 run function evercraft:artifacts/abilities/fireforged_4pc_save

# Soulguard Aegis tree — CONSOLIDATED DEATH SAVE (cap-D, G6: ONE shared bucket for ALL D revives).
# When ANY Soulguard death-save-bearing node is held (Grand Totem / Lifewarden / grand Soulguard Aegis)
# and the player drops to a fatal blow (health_below_6) while the SHARED ec.cd_save bucket is off
# cooldown, fire ONE consolidated rebirth (soulguard_save) — the strongest of the absorbed saves, with
# Absorption SET (max-not-sum). This REPLACES the three independent leaf saves for a fused player: the
# loose-member saves above are suppressed (m4 Layer-1, Newcomer-exempt) when their absorbing node is
# held, so a Soulguard player gets exactly ONE revive through one cooldown. ec._a single-scan over the
# three nodes (container.* + offhand). Multi-copy-safe: the ec.cd_save SET after the first fire means
# two copies of any node still grant ONE revive, never two.
execute if items entity @s container.* *[custom_data~{grand_totem:true}] run tag @s add ec._a
execute unless items entity @s container.* *[custom_data~{grand_totem:true}] unless items entity @s weapon.offhand *[custom_data~{grand_totem:true}] if entity @s[tag=ec.sat_grand_totem] run tag @s add ec._a
execute unless entity @s[tag=ec._a] if items entity @s weapon.offhand *[custom_data~{grand_totem:true}] run tag @s add ec._a
execute unless entity @s[tag=ec._a] if items entity @s container.* *[custom_data~{lifewarden:true}] run tag @s add ec._a
execute unless entity @s[tag=ec._a] unless items entity @s container.* *[custom_data~{lifewarden:true}] unless items entity @s weapon.offhand *[custom_data~{lifewarden:true}] if entity @s[tag=ec.sat_lifewarden] run tag @s add ec._a
execute unless entity @s[tag=ec._a] if items entity @s weapon.offhand *[custom_data~{lifewarden:true}] run tag @s add ec._a
execute unless entity @s[tag=ec._a] if items entity @s container.* *[custom_data~{soulguard_aegis:true}] run tag @s add ec._a
execute unless entity @s[tag=ec._a] unless items entity @s container.* *[custom_data~{soulguard_aegis:true}] unless items entity @s weapon.offhand *[custom_data~{soulguard_aegis:true}] if entity @s[tag=ec.sat_soulguard_aegis] run tag @s add ec._a
execute unless entity @s[tag=ec._a] if items entity @s weapon.offhand *[custom_data~{soulguard_aegis:true}] run tag @s add ec._a
execute if entity @s[tag=ec._a] if predicate evercraft:health_below_6 unless score @s ec.cd_save matches 1.. run function evercraft:artifacts/abilities/soulguard_save
tag @s remove ec._a

# Ring of Undying — custom death save (Absorption IV revive, 2min cd) — art / death-save build
# On an otherwise-lethal blow (health_below_6) with the Ring carried, fire ring_of_undying_save (heal +
# Absorption IV 30s) and set a 2-minute cooldown so it can't chain-revive. Death-save cooldown-gated per
# id (m4 / G6): the ec.cd_undying_rev gate is idempotent + multi-copy-safe (cooldown SET after the first
# fire). ec._a single-scan (container.* + satchel + offhand), same idiom as phoenix above. Newcomer-exempt.
execute if items entity @s container.* *[custom_data~{artifact:"ring_of_undying"}] run tag @s add ec._a
execute unless items entity @s container.* *[custom_data~{artifact:"ring_of_undying"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"ring_of_undying"}] if entity @s[tag=ec.sat_ring_of_undying] run tag @s add ec._a
execute unless entity @s[tag=ec._a] if items entity @s weapon.offhand *[custom_data~{artifact:"ring_of_undying"}] run tag @s add ec._a
execute if entity @s[tag=ec._a] if predicate evercraft:health_below_6 unless score @s ec.cd_undying_rev matches 1.. unless score @s ec.difficulty matches 1 run function evercraft:artifacts/abilities/ring_of_undying_save
tag @s remove ec._a

# Temporal Hourglass — Chrono Rewind death save (Absorption IV revive, 4min cd) — art / death-save build
# Replaces the infeasible "50% damage negate / -50% all cooldowns" claims: on an otherwise-lethal blow
# (health_below_6) with the Hourglass carried, fire temporal_hourglass_save (heal + Absorption IV 30s) and
# set a 4-minute cooldown. Same death-save idiom as the Ring above with its own UNIQUE ec.cd_chrono id;
# idempotent + multi-copy-safe (cooldown SET after the first fire). Newcomer-exempt.
execute if items entity @s container.* *[custom_data~{artifact:"temporal_hourglass"}] run tag @s add ec._a
execute unless items entity @s container.* *[custom_data~{artifact:"temporal_hourglass"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"temporal_hourglass"}] if entity @s[tag=ec.sat_temporal_hourglass] run tag @s add ec._a
execute unless entity @s[tag=ec._a] if items entity @s weapon.offhand *[custom_data~{artifact:"temporal_hourglass"}] run tag @s add ec._a
# Chrono Rewind fires on EVERY difficulty (Joseph 2026-06-10 — the old `unless ec.difficulty
# matches 1` Newcomer exclusion was inverted/unwanted; a mythical's death-save is for everyone).
execute if entity @s[tag=ec._a] if predicate evercraft:health_below_6 unless score @s ec.cd_chrono matches 1.. run function evercraft:artifacts/abilities/temporal_hourglass_save
tag @s remove ec._a

# Dragon's Tear — Damage aura + Strength I
# OPT: Tag consolidation (was 4 item scans → 2)
execute if items entity @s container.* *[custom_data~{artifact:"dragons_tear"}] run tag @s add ec._a
execute unless items entity @s container.* *[custom_data~{artifact:"dragons_tear"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"dragons_tear"}] if entity @s[tag=ec.sat_dragons_tear] run tag @s add ec._a
execute unless entity @s[tag=ec._a] if items entity @s weapon.offhand *[custom_data~{artifact:"dragons_tear"}] run tag @s add ec._a
execute if entity @s[tag=ec._a] as @e[type=#evercraft:hostile_mobs,distance=..4,limit=5] run damage @s 1 evercraft:bonus_strike
execute if entity @s[tag=ec._a] if score @s ec.h_str matches ..1 run effect give @s strength 5 0 false
tag @s remove ec._a

# Nether Star Shard — Star Power party aura (Haste II + Speed I + Regen I) + self +2 Dream Rate
# OPT: Tag consolidation (was 4 item scans → 2)
# Star Power: the movement-buff party aura (P1 healer-lotus idiom) — Haste II + Speed I to allies AND
# companions in 16b, plus Regen I; allies/pets ungated (the harmonize counter is the holder's, P9). The
# undocumented Resistance was dropped (not in lore). Self carries +2 Dream Rate via a stripped luck modifier.
# Regen fallback: instant heal for any nearby player already at Regen II+
execute if items entity @s container.* *[custom_data~{artifact:"nether_star_shard"}] run tag @s add ec._a
execute unless items entity @s container.* *[custom_data~{artifact:"nether_star_shard"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"nether_star_shard"}] if entity @s[tag=ec.sat_nether_star_shard] run tag @s add ec._a
execute unless entity @s[tag=ec._a] if items entity @s weapon.offhand *[custom_data~{artifact:"nether_star_shard"}] run tag @s add ec._a
execute if entity @s[tag=ec._a] at @s run effect give @a[distance=..16] haste 5 1 false
execute if entity @s[tag=ec._a] at @s run effect give @a[distance=..16] speed 5 0 false
execute if entity @s[tag=ec._a] at @s run effect give @a[distance=..16] regeneration 5 0 false
execute if entity @s[tag=ec._a] at @s run effect give @e[type=#evercraft:tameable_companions,distance=..16,tag=ec.tame_protected] haste 5 1 true
execute if entity @s[tag=ec._a] at @s run effect give @e[type=#evercraft:tameable_companions,distance=..16,tag=ec.tame_protected] speed 5 0 true
execute if entity @s[tag=ec._a] at @s run effect give @e[type=#evercraft:tameable_companions,distance=..16,tag=ec.tame_protected] regeneration 5 0 true
execute if entity @s[tag=ec._a] run attribute @s luck modifier add evercraft:nether_star_shard_luck 2.0 add_value
# OPT: Predicate check replaces 2 NBT active_effects deep scans per nearby player
execute if entity @s[tag=ec._a] as @a[distance=..16] if predicate evercraft:has_regen_above_0 run function evercraft:artifacts/accessories/regen_fallback
tag @s remove ec._a

# Blaze Core — Fire Resistance + fire particle trail
# Inferno Mastery (+3 fire dmg) handled by advancement trigger (blaze_core_hit_trigger)
# OPT: Tag consolidation (was 4 item scans → 2)
execute if items entity @s container.* *[custom_data~{artifact:"blaze_core"}] run tag @s add ec._a
execute unless items entity @s container.* *[custom_data~{artifact:"blaze_core"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"blaze_core"}] if entity @s[tag=ec.sat_blaze_core] run tag @s add ec._a
execute unless entity @s[tag=ec._a] if items entity @s weapon.offhand *[custom_data~{artifact:"blaze_core"}] run tag @s add ec._a
execute if entity @s[tag=ec._a] run effect give @s fire_resistance 15 0 false
execute if entity @s[tag=ec._a] run particle flame ~ ~0.1 ~ 0.2 0 0.2 0.01 1
tag @s remove ec._a

# Phantom Charm — Slow Falling + Elytra durability protection
# OPT: Tag consolidation
execute if items entity @s container.* *[custom_data~{artifact:"phantom_charm"}] run tag @s add ec._a
execute unless items entity @s container.* *[custom_data~{artifact:"phantom_charm"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"phantom_charm"}] if entity @s[tag=ec.sat_phantom_charm] run tag @s add ec._a
execute unless entity @s[tag=ec._a] if items entity @s weapon.offhand *[custom_data~{artifact:"phantom_charm"}] run tag @s add ec._a
execute if entity @s[tag=ec._a] unless score @s ec.t_phantom matches 1 run effect give @s slow_falling 5 0 false
# Phantom Glide: 50% fall-damage reduction (the featherscale_down fall_damage_multiplier idiom; half of its -1.0).
execute if entity @s[tag=ec._a] run attribute @s fall_damage_multiplier modifier add evercraft:phantom_charm_fall -0.5 add_multiplied_base
# Phantom Glide: Keep elytra at full durability
execute if entity @s[tag=ec._a] if items entity @s armor.chest minecraft:elytra run item modify entity @s armor.chest evercraft:repair_elytra
tag @s remove ec._a

# Sea Heart Relic — Water Breathing + Dolphin's Grace + Conduit Power
# OPT: Tag consolidation (was 6 item scans → 2)
execute if items entity @s container.* *[custom_data~{artifact:"sea_heart_relic"}] run tag @s add ec._a
execute unless items entity @s container.* *[custom_data~{artifact:"sea_heart_relic"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"sea_heart_relic"}] if entity @s[tag=ec.sat_sea_heart_relic] run tag @s add ec._a
execute unless entity @s[tag=ec._a] if items entity @s weapon.offhand *[custom_data~{artifact:"sea_heart_relic"}] run tag @s add ec._a
execute if entity @s[tag=ec._a] run effect give @s water_breathing 15 0 false
execute if entity @s[tag=ec._a] run effect give @s dolphins_grace 5 0 false
execute if entity @s[tag=ec._a] run effect give @s conduit_power 5 0 false
execute if entity @s[tag=ec._a] run attribute @s submerged_mining_speed modifier add evercraft:sea_heart_mining 0.30 add_multiplied_base
tag @s remove ec._a

# Berserker Totem — constant Strength I + Haste I floor + Passive: +25% attack speed + Slowness immunity
# OPT: Tag consolidation (was 4 item scans → 2)
# The after-kill Berserker Frenzy (Strength II + Speed II, 10s, stacking) is an on-kill PROC handled by
# artifacts/abilities/berserker_totem_kill (the player_killed_entity advancement reward fn) — NOT here.
# This passive block keeps the always-on floor (Str I + Haste I) and adds the lore-claimed passives:
#   +25% attack speed → attack_speed modifier (unique id, stripped in accessory_cleanup on removal).
#   immune to Slowness → effect clear @s slowness while held (the wither_rose_crown effect-clear idiom).
execute if items entity @s container.* *[custom_data~{artifact:"berserker_totem"}] run tag @s add ec._a
execute unless items entity @s container.* *[custom_data~{artifact:"berserker_totem"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"berserker_totem"}] if entity @s[tag=ec.sat_berserker_totem] run tag @s add ec._a
execute unless entity @s[tag=ec._a] if items entity @s weapon.offhand *[custom_data~{artifact:"berserker_totem"}] run tag @s add ec._a
execute if entity @s[tag=ec._a] run effect give @s strength 5 0 false
execute if entity @s[tag=ec._a] run effect give @s haste 5 0 false
execute if entity @s[tag=ec._a] run attribute @s attack_speed modifier add evercraft:berserker_totem_as 0.25 add_multiplied_base
execute if entity @s[tag=ec._a] run effect clear @s slowness
tag @s remove ec._a

# Sculk Heart — +1.5 Dream Rate
execute if items entity @s container.* *[custom_data~{artifact:"sculk_heart"}] unless score @s ec.t_sculkhrt matches 1 run attribute @s luck modifier add evercraft:sculk_heart_luck 1.5 add_value
execute unless items entity @s container.* *[custom_data~{artifact:"sculk_heart"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"sculk_heart"}] if entity @s[tag=ec.sat_sculk_heart] unless score @s ec.t_sculkhrt matches 1 run attribute @s luck modifier add evercraft:sculk_heart_luck 1.5 add_value
execute if items entity @s weapon.offhand *[custom_data~{artifact:"sculk_heart"}] unless score @s ec.t_sculkhrt matches 1 run attribute @s luck modifier add evercraft:sculk_heart_luck 1.5 add_value

# Conditional Cache-Eye — CONDITIONAL +2 Dream Rate ONLY while mining/harvesting (Family B new
# leaf — art-B; re-homed conditional-DR craft charm). Reads the SAME craft/mine activity window as
# Geologist's Loupe (ec.cf_actwin — set by grant_verb on every qualifying verb, which covers mine,
# chop, dig, till AND the crop-harvest processors that call grant_verb). Remove-then-conditional-
# add (band_luck idiom): held + window open -> +2.0; bare remove handles not-held + idle (~5s
# decay). Fixed-id modifier (idempotent, m4 Layer-2). Detect held into ec._a (single scan).
execute if items entity @s container.* *[custom_data~{artifact:"cache_eye"}] run tag @s add ec._a
execute unless items entity @s container.* *[custom_data~{artifact:"cache_eye"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"cache_eye"}] if entity @s[tag=ec.sat_cache_eye] run tag @s add ec._a
execute unless entity @s[tag=ec._a] if items entity @s weapon.offhand *[custom_data~{artifact:"cache_eye"}] run tag @s add ec._a
execute if entity @s[tag=ec._a] run attribute @s luck modifier remove evercraft:cache_eye_luck
execute if entity @s[tag=ec._a] if score @s ec.cf_actwin matches 1.. run attribute @s luck modifier add evercraft:cache_eye_luck 2.0 add_value
tag @s remove ec._a

# ============================================================
# === MYTHICAL ACCESSORIES ===
# ============================================================

# Dream Aegis — +2 Dream Rate + tag for per-tick iframe detection
# OPT: Tag consolidation (was 4 item scans → 2)
tag @s remove ec.has_aegis
execute if items entity @s container.* *[custom_data~{artifact:"dream_aegis"}] run tag @s add ec.has_aegis
execute unless items entity @s container.* *[custom_data~{artifact:"dream_aegis"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"dream_aegis"}] if entity @s[tag=ec.sat_dream_aegis] run tag @s add ec.has_aegis
execute unless entity @s[tag=ec.has_aegis] if items entity @s weapon.offhand *[custom_data~{artifact:"dream_aegis"}] run tag @s add ec.has_aegis
execute if entity @s[tag=ec.has_aegis] run attribute @s luck modifier add evercraft:dream_aegis_luck 2.0 add_value

# Codex of Everything — Luck III # OPT: Tag consolidation
execute if items entity @s container.* *[custom_data~{artifact:"codex_of_everything"}] run tag @s add ec._a
execute unless items entity @s container.* *[custom_data~{artifact:"codex_of_everything"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"codex_of_everything"}] if entity @s[tag=ec.sat_codex_of_everything] run tag @s add ec._a
execute unless entity @s[tag=ec._a] if items entity @s weapon.offhand *[custom_data~{artifact:"codex_of_everything"}] run tag @s add ec._a
execute if entity @s[tag=ec._a] run attribute @s luck modifier add evercraft:codex_of_everything_luck 3.0 add_value
tag @s remove ec._a

# Dreamspun Crown of Ages — +12 Dream Rate (consolidated, ONE modifier) + Strength I + Speed I
# auras (Family B new leaf — art-B; the mythical DR head, primary home B per Open-Decision 5). The
# +12 is a single fixed-id modifier (idempotent — two copies overwrite, m4 Layer-2; the DR cap
# rose to 100 per DECISIONS so this fits). Auras respect the harmonize gates (ec.h_str/ec.h_speed
# matches ..1) exactly like Claude's Gift / Beacon so the Crown never double-stacks a harmonizable
# buff. Detect held into ec._a (single scan); cleanup strips the modifier on removal.
execute if items entity @s container.* *[custom_data~{artifact:"dreamspun_crown"}] run tag @s add ec._a
execute unless items entity @s container.* *[custom_data~{artifact:"dreamspun_crown"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"dreamspun_crown"}] if entity @s[tag=ec.sat_dreamspun_crown] run tag @s add ec._a
execute unless entity @s[tag=ec._a] if items entity @s weapon.offhand *[custom_data~{artifact:"dreamspun_crown"}] run tag @s add ec._a
execute if entity @s[tag=ec._a] run attribute @s luck modifier add evercraft:dreamspun_crown_luck 12.0 add_value
execute if entity @s[tag=ec._a] if score @s ec.h_str matches ..1 run effect give @s strength 5 0 false
execute if entity @s[tag=ec._a] if score @s ec.h_speed matches ..1 run effect give @s speed 5 0 false
tag @s remove ec._a

# Worldforge Ember — CONDITIONAL +3 Dream Rate for a short while after crafting (Family B new leaf
# — art-B; re-homed cross-craft DR latch, parked in B as its DR home). The DR uses the SAME craft/
# mine activity window (ec.cf_actwin — grant_verb fires on every craft-affinity verb, so a recent
# craft keeps the window open). Remove-then-conditional-add (band_luck idiom): held + window open
# -> +3.0; bare remove handles not-held + idle (~5s decay). Fixed-id modifier (idempotent, m4
# Layer-2). The Ember's +2.0 Craft Rate lever is applied SEPARATELY inside craftforever/craft_rate/
# calculate.mcfunction (the ONE writer of ec.cr_temp — m4 HANDOFF #7: do NOT add a second cr_temp
# writer from player_tick), gated `if items` while held. Detect held into ec._a (single scan).
execute if items entity @s container.* *[custom_data~{artifact:"worldforge_ember"}] run tag @s add ec._a
execute unless items entity @s container.* *[custom_data~{artifact:"worldforge_ember"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"worldforge_ember"}] if entity @s[tag=ec.sat_worldforge_ember] run tag @s add ec._a
execute unless entity @s[tag=ec._a] if items entity @s weapon.offhand *[custom_data~{artifact:"worldforge_ember"}] run tag @s add ec._a
execute if entity @s[tag=ec._a] run attribute @s luck modifier remove evercraft:worldforge_ember_luck
execute if entity @s[tag=ec._a] if score @s ec.cf_actwin matches 1.. run attribute @s luck modifier add evercraft:worldforge_ember_luck 3.0 add_value
tag @s remove ec._a

# Temporal Hourglass — Resistance II + Speed II
# OPT: Tag consolidation (was 4 item scans → 2)
execute if items entity @s container.* *[custom_data~{artifact:"temporal_hourglass"}] run tag @s add ec._a
execute unless items entity @s container.* *[custom_data~{artifact:"temporal_hourglass"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"temporal_hourglass"}] if entity @s[tag=ec.sat_temporal_hourglass] run tag @s add ec._a
execute unless entity @s[tag=ec._a] if items entity @s weapon.offhand *[custom_data~{artifact:"temporal_hourglass"}] run tag @s add ec._a
execute if entity @s[tag=ec._a] run effect give @s resistance 5 1 false
execute if entity @s[tag=ec._a] run effect give @s speed 5 1 false
tag @s remove ec._a

# Heart of the Void — Resistance I + Slow Falling + Night Vision + Entropy Field + Void Blink
# OPT: Tag consolidation (was 6 item scans → 2)
# Entropy Field (P2 hunter-AoE idiom): hostile mobs in 8b take Wither II + Slowness II (the short-range
# hard-CC counterpart to prism_of_light's wide damage aura). Void Blink: the feasible substitute for the
# impossible "phase through blocks" — a sneak-gated forward dash with brief near-invuln (Resistance V),
# cooldown ec.cd_void_blink (5s, decremented in the one-writer cooldown block above). Durations >=3s to
# bridge the 1s player_tick cadence.
execute if items entity @s container.* *[custom_data~{artifact:"heart_of_the_void"}] run tag @s add ec._a
execute unless items entity @s container.* *[custom_data~{artifact:"heart_of_the_void"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"heart_of_the_void"}] if entity @s[tag=ec.sat_heart_of_the_void] run tag @s add ec._a
execute unless entity @s[tag=ec._a] if items entity @s weapon.offhand *[custom_data~{artifact:"heart_of_the_void"}] run tag @s add ec._a
execute if entity @s[tag=ec._a] run effect give @s resistance 5 0 false
execute if entity @s[tag=ec._a] run effect give @s slow_falling 5 0 false
execute if entity @s[tag=ec._a] run effect give @s night_vision 15 0 false
# Entropy Field — 8b hostile Wither II + Slowness II
execute if entity @s[tag=ec._a] at @s run effect give @e[type=#evercraft:hostile_mobs,distance=..8] wither 3 1 false
execute if entity @s[tag=ec._a] at @s run effect give @e[type=#evercraft:hostile_mobs,distance=..8] slowness 3 1 false
# Void Blink — sneak + look-DOWN dash (brief invuln + forward leap), 5s cooldown. The deliberate
# pitch gesture (looking_down predicate, x_rotation>=50) keeps a normal level-look crouch from blinking.
execute if entity @s[tag=ec._a] if predicate evercraft:sneaking if predicate evercraft:looking_down unless score @s ec.cd_void_blink matches 1.. run effect give @s resistance 3 4 true
execute if entity @s[tag=ec._a] if predicate evercraft:sneaking if predicate evercraft:looking_down unless score @s ec.cd_void_blink matches 1.. at @s run particle reverse_portal ~ ~1 ~ 0.4 0.6 0.4 0.05 30
execute if entity @s[tag=ec._a] if predicate evercraft:sneaking if predicate evercraft:looking_down unless score @s ec.cd_void_blink matches 1.. if score @s ec.fx_snd matches 1.. at @s run playsound minecraft:entity.enderman.teleport player @s ~ ~ ~ 0.8 0.8
execute if entity @s[tag=ec._a] if predicate evercraft:sneaking if predicate evercraft:looking_down unless score @s ec.cd_void_blink matches 1.. at @s rotated ~ 0 run tp @s ^ ^ ^4
execute if entity @s[tag=ec._a] if predicate evercraft:sneaking if predicate evercraft:looking_down unless score @s ec.cd_void_blink matches 1.. run scoreboard players set @s ec.cd_void_blink 5
tag @s remove ec._a

# Beacon of Ancients — Full beacon (Str/Haste/Speed/Regen/Resist) to allies + companions in 32b + Luck III + Efficiency +2
# OPT: Tag consolidation (was 14 item scans → 2)
# Ancient Aura (P1): the 5 beacon effects now reach allies AND companions in 32b (the widest aura in the
# pack — an exquisite capstone). HOLDER lines keep the harmonize gates (P9); allies/pets get the raw
# effect ungated (the harmonize counter is the holder's). Self is excluded from the broadcast via the
# scratch ec.boa_self tag so the holder's harmonize gates stay authoritative. Builder's Legacy: a real
# held mining_efficiency +2 (the whetstone_charm idiom) — stripped in accessory_cleanup.
execute if items entity @s container.* *[custom_data~{artifact:"beacon_of_ancients"}] run tag @s add ec._a
execute unless items entity @s container.* *[custom_data~{artifact:"beacon_of_ancients"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"beacon_of_ancients"}] if entity @s[tag=ec.sat_beacon_of_ancients] run tag @s add ec._a
execute unless entity @s[tag=ec._a] if items entity @s weapon.offhand *[custom_data~{artifact:"beacon_of_ancients"}] run tag @s add ec._a
# HOLDER (harmonize-gated, P9)
execute if entity @s[tag=ec._a] if score @s ec.h_speed matches ..1 run effect give @s speed 5 0 false
execute if entity @s[tag=ec._a] if score @s ec.h_haste matches ..1 run effect give @s haste 5 0 false
execute if entity @s[tag=ec._a] if score @s ec.h_resist matches ..1 run effect give @s resistance 5 0 false
execute if entity @s[tag=ec._a] if score @s ec.h_jump matches ..1 run effect give @s jump_boost 5 0 false
execute if entity @s[tag=ec._a] if score @s ec.h_str matches ..1 run effect give @s strength 5 0 false
execute if entity @s[tag=ec._a] if score @s ec.h_regen matches ..1 unless entity @s[tag=ec.regen_capped] run effect give @s regeneration 5 0 false
execute if entity @s[tag=ec._a] if score @s ec.h_regen matches ..1 if entity @s[tag=ec.regen_capped] run function evercraft:artifacts/accessories/regen_fallback
# ALLIES (ungated, self-excluded) — 32b Ancient Aura
execute if entity @s[tag=ec._a] run tag @s add ec.boa_self
execute if entity @s[tag=ec._a] at @s run effect give @a[distance=..32,tag=!ec.boa_self] speed 5 0 false
execute if entity @s[tag=ec._a] at @s run effect give @a[distance=..32,tag=!ec.boa_self] haste 5 0 false
execute if entity @s[tag=ec._a] at @s run effect give @a[distance=..32,tag=!ec.boa_self] resistance 5 0 false
execute if entity @s[tag=ec._a] at @s run effect give @a[distance=..32,tag=!ec.boa_self] jump_boost 5 0 false
execute if entity @s[tag=ec._a] at @s run effect give @a[distance=..32,tag=!ec.boa_self] strength 5 0 false
execute if entity @s[tag=ec._a] at @s run effect give @a[distance=..32,tag=!ec.boa_self] regeneration 5 0 false
tag @s remove ec.boa_self
# COMPANIONS (ungated, particles hidden) — 32b Ancient Aura
execute if entity @s[tag=ec._a] at @s run effect give @e[type=#evercraft:tameable_companions,distance=..32,tag=ec.tame_protected] speed 5 0 true
execute if entity @s[tag=ec._a] at @s run effect give @e[type=#evercraft:tameable_companions,distance=..32,tag=ec.tame_protected] haste 5 0 true
execute if entity @s[tag=ec._a] at @s run effect give @e[type=#evercraft:tameable_companions,distance=..32,tag=ec.tame_protected] resistance 5 0 true
execute if entity @s[tag=ec._a] at @s run effect give @e[type=#evercraft:tameable_companions,distance=..32,tag=ec.tame_protected] strength 5 0 true
execute if entity @s[tag=ec._a] at @s run effect give @e[type=#evercraft:tameable_companions,distance=..32,tag=ec.tame_protected] regeneration 5 0 true
execute if entity @s[tag=ec._a] run attribute @s luck modifier add evercraft:beacon_of_ancients_luck 3.0 add_value
execute if entity @s[tag=ec._a] run attribute @s mining_efficiency modifier add evercraft:beacon_of_ancients_eff 2 add_value
tag @s remove ec._a

# Wither Rose Crown — Undead Weakness aura (16b) + Withering Aura (8b Wither II) + Strength I + Wither-immune
# OPT: Tag consolidation (was 4 item scans → 2)
execute if items entity @s container.* *[custom_data~{artifact:"wither_rose_crown"}] run tag @s add ec._a
execute unless items entity @s container.* *[custom_data~{artifact:"wither_rose_crown"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"wither_rose_crown"}] if entity @s[tag=ec.sat_wither_rose_crown] run tag @s add ec._a
execute unless entity @s[tag=ec._a] if items entity @s weapon.offhand *[custom_data~{artifact:"wither_rose_crown"}] run tag @s add ec._a
execute if entity @s[tag=ec._a] run effect give @e[type=#minecraft:undead,distance=..16] weakness 5 4 false
# Withering Aura — enemies within 8 blocks get Wither II (the soul_reaver hostile-aura idiom, #evercraft:
# hostile_mobs so it never touches villagers/pets/the holder). 5s dur on the 1s tick chain so it persists.
execute if entity @s[tag=ec._a] at @s run effect give @e[type=#evercraft:hostile_mobs,distance=..8,limit=8] wither 5 1 false
execute if entity @s[tag=ec._a] if score @s ec.h_str matches ..1 run effect give @s strength 5 0 false
execute if entity @s[tag=ec._a] run effect clear @s wither
tag @s remove ec._a

# Ender Dragon Scale — Strength III + Fire Resistance + Dragon Ascendant (sneak-active) + void-save
# OPT: Tag consolidation (was 4 item scans → 2)
# Dragon Ascendant (the feasible substitute for the impossible "elytra flight without elytra"): a sneak-
# gated launch (Levitation rise) that hands off to Slow Falling + a dragon's-breath trail, on a 15s
# cooldown (ec.cd_dragon, decremented in the cd_* block above — one writer beside the source-set in
# ender_dragon_scale_ascend). Void-save (the voidscale_shard ec._vy idiom): if the bearer is below the
# void floor (Y <= -70), teleport-arrest the fall with Slow Falling + Resistance + Fire Res + a short
# Levitation, fulfilling the "immune to void" lore. ec.dr_vy is read here ONLY (its own one-writer Y, kept
# DISTINCT from voidscale's ec._vy so the two never clobber). The sneak-gate is multi-copy-safe by the
# cooldown set. Keep the working Strength III (harmonize-gated) + Fire Resistance.
execute if items entity @s container.* *[custom_data~{artifact:"ender_dragon_scale"}] run tag @s add ec._a
execute unless items entity @s container.* *[custom_data~{artifact:"ender_dragon_scale"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"ender_dragon_scale"}] if entity @s[tag=ec.sat_ender_dragon_scale] run tag @s add ec._a
execute unless entity @s[tag=ec._a] if items entity @s weapon.offhand *[custom_data~{artifact:"ender_dragon_scale"}] run tag @s add ec._a
execute if entity @s[tag=ec._a] if score @s ec.h_str matches ..1 run effect give @s strength 5 2 false
execute if entity @s[tag=ec._a] run effect give @s fire_resistance 15 0 false
# Dragon Ascendant — sneak + look-UP launch + glide (15s cooldown). The deliberate pitch gesture
# (looking_up predicate, x_rotation<=-50) keeps a normal level-look crouch from launching you skyward.
execute if entity @s[tag=ec._a] if predicate evercraft:sneaking if predicate evercraft:looking_up unless score @s ec.cd_dragon matches 1.. run function evercraft:artifacts/abilities/ender_dragon_scale_ascend
# Void-save — arrest a void fall (Y <= -70) so the bearer is "immune to void"
execute if entity @s[tag=ec._a] store result score @s ec.dr_vy run data get entity @s Pos[1] 1
execute if entity @s[tag=ec._a] if score @s ec.dr_vy matches ..-70 run effect give @s slow_falling 5 0 true
execute if entity @s[tag=ec._a] if score @s ec.dr_vy matches ..-70 run effect give @s levitation 1 4 true
execute if entity @s[tag=ec._a] if score @s ec.dr_vy matches ..-70 run effect give @s resistance 5 4 true
execute if entity @s[tag=ec._a] if score @s ec.dr_vy matches ..-70 run effect give @s fire_resistance 5 0 true
tag @s remove ec._a

# ============================================================
# === FAMILY M — DRAGONHEART LEAVES (Fam11 / cap-M, art-M) ===
# ============================================================
# The 14 NEW dragon/scale leaves (the two SEEDS — Dragon's Tear at :1346 + Ender Dragon Scale above —
# keep their existing blocks). Each leaf grants its ONE distinct perk while held, using the file's
# established idioms (ec._a tag-consolidation single-scan; harmonize-gated effects; remove-then-add
# attribute modifiers with a clear-on-removal strip in accessory_cleanup). The +1% dodge for the agile
# leaves (Wyrmwing Membrane, Stormrider Pinion, Featherscale Down, Breath-Gland Sac) lives in the m1
# ec.acc_dodge LEAF block at the TOP of this file (one writer), NOT here. The on-hit ignite (Cinderclaw
# Grip) fires from its own player_hurt_entity advancement trigger (the blaze_core idiom), NOT here.
# All multi-copy-safe: each is an id-presence gate (two copies grant once) with fixed-level effects /
# fixed-id attribute modifiers that overwrite (the loose-accessory rule, m4 Layer-2). Newcomer-exempt
# blocks are not needed (no DR luck on any leaf; the *_luck consolidation happens only at the cap-M
# sub-cap / grand applies, built downstream).
#
# --- Wyrmscale Plate (rare) — +2 Armor Toughness (set-tank base). Fixed-id armor_toughness add_value,
#     stripped on drop in accessory_cleanup (the stoneward_pebble / bulwark_plate idiom). ---
execute if items entity @s container.* *[custom_data~{artifact:"wyrmscale_plate"}] run tag @s add ec._a
execute unless items entity @s container.* *[custom_data~{artifact:"wyrmscale_plate"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"wyrmscale_plate"}] if entity @s[tag=ec.sat_wyrmscale_plate] run tag @s add ec._a
execute unless entity @s[tag=ec._a] if items entity @s weapon.offhand *[custom_data~{artifact:"wyrmscale_plate"}] run tag @s add ec._a
execute if entity @s[tag=ec._a] run attribute @s armor_toughness modifier add evercraft:wyrmscale_plate_tough 2 add_value
tag @s remove ec._a
# --- Scaled Carapace (ornate) — Resistance I (harmonize-gated, yields to a stronger same-effect). ---
execute if items entity @s container.* *[custom_data~{artifact:"scaled_carapace"}] run tag @s add ec._a
execute unless items entity @s container.* *[custom_data~{artifact:"scaled_carapace"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"scaled_carapace"}] if entity @s[tag=ec.sat_scaled_carapace] run tag @s add ec._a
execute unless entity @s[tag=ec._a] if items entity @s weapon.offhand *[custom_data~{artifact:"scaled_carapace"}] run tag @s add ec._a
execute if entity @s[tag=ec._a] if score @s ec.h_resist matches ..1 run effect give @s resistance 5 0 false
tag @s remove ec._a
# --- Ridgeback Spur (rare) — full Knockback Resistance (set anti-stagger). Fixed-id 1.0 add_value
#     (the striker_kb_resist tier-4+ value), stripped on drop in accessory_cleanup. ---
execute if items entity @s container.* *[custom_data~{artifact:"ridgeback_spur"}] run tag @s add ec._a
execute unless items entity @s container.* *[custom_data~{artifact:"ridgeback_spur"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"ridgeback_spur"}] if entity @s[tag=ec.sat_ridgeback_spur] run tag @s add ec._a
execute unless entity @s[tag=ec._a] if items entity @s weapon.offhand *[custom_data~{artifact:"ridgeback_spur"}] run tag @s add ec._a
execute if entity @s[tag=ec._a] run attribute @s knockback_resistance modifier add evercraft:ridgeback_spur_kb 1.0 add_value
tag @s remove ec._a
# --- Wyrmscale Plate (rare, PARK-fork default) — +0.1 Knockback Resistance (scale-thorns identity). ---
#     Inventory-held accessory/material. Fixed-id add_value (ridgeback_spur idiom, lighter value),
#     stripped on drop in accessory_cleanup. NOTE: this is the parked-fork default (scale-thorns simple).
execute if items entity @s container.* *[custom_data~{artifact:"wyrmscale_plate"}] run tag @s add ec._a
execute unless items entity @s container.* *[custom_data~{artifact:"wyrmscale_plate"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"wyrmscale_plate"}] if entity @s[tag=ec.sat_wyrmscale_plate] run tag @s add ec._a
execute unless entity @s[tag=ec._a] if items entity @s weapon.offhand *[custom_data~{artifact:"wyrmscale_plate"}] run tag @s add ec._a
execute if entity @s[tag=ec._a] run attribute @s knockback_resistance modifier add evercraft:wyrmscale_plate_kb 0.1 add_value
tag @s remove ec._a
# --- Wyrmtooth Fang (ornate) — +2 melee damage. Fixed-id attack_damage add_value (the reavers_knuckle /
#     ascendant_forgeheart idiom; flat, like those precedents), stripped on drop in accessory_cleanup. ---
execute if items entity @s container.* *[custom_data~{artifact:"wyrmtooth_fang"}] run tag @s add ec._a
execute unless items entity @s container.* *[custom_data~{artifact:"wyrmtooth_fang"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"wyrmtooth_fang"}] if entity @s[tag=ec.sat_wyrmtooth_fang] run tag @s add ec._a
execute unless entity @s[tag=ec._a] if items entity @s weapon.offhand *[custom_data~{artifact:"wyrmtooth_fang"}] run tag @s add ec._a
execute if entity @s[tag=ec._a] run attribute @s attack_damage modifier add evercraft:wyrmtooth_fang_atk 2.0 add_value
tag @s remove ec._a
# --- Dragonbone Talon (exquisite) — Strength I (harmonize-gated, folds toward the set Strength III). ---
execute if items entity @s container.* *[custom_data~{artifact:"dragonbone_talon"}] run tag @s add ec._a
execute unless items entity @s container.* *[custom_data~{artifact:"dragonbone_talon"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"dragonbone_talon"}] if entity @s[tag=ec.sat_dragonbone_talon] run tag @s add ec._a
execute unless entity @s[tag=ec._a] if items entity @s weapon.offhand *[custom_data~{artifact:"dragonbone_talon"}] run tag @s add ec._a
execute if entity @s[tag=ec._a] if score @s ec.h_str matches ..1 run effect give @s strength 5 0 false
tag @s remove ec._a
# --- Wyrmwing Membrane (exquisite) — Slow Falling (set-glide base). Its +1% dodge is in the m1 LEAF block. ---
execute if items entity @s container.* *[custom_data~{artifact:"wyrmwing_membrane"}] run tag @s add ec._a
execute unless items entity @s container.* *[custom_data~{artifact:"wyrmwing_membrane"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"wyrmwing_membrane"}] if entity @s[tag=ec.sat_wyrmwing_membrane] run tag @s add ec._a
execute unless entity @s[tag=ec._a] if items entity @s weapon.offhand *[custom_data~{artifact:"wyrmwing_membrane"}] run tag @s add ec._a
execute if entity @s[tag=ec._a] run effect give @s slow_falling 5 0 false
tag @s remove ec._a
# --- Stormrider Pinion (ornate) — Speed I ONLY while airborne (gust dash). Effect-based, conditional on
#     not_on_ground + harmonize-gated. No remove needed (a 1s self-expiring effect that simply stops being
#     refreshed once grounded). Its +1% dodge is in the m1 LEAF block. ---
execute if items entity @s container.* *[custom_data~{artifact:"stormrider_pinion"}] run tag @s add ec._a
execute unless items entity @s container.* *[custom_data~{artifact:"stormrider_pinion"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"stormrider_pinion"}] if entity @s[tag=ec.sat_stormrider_pinion] run tag @s add ec._a
execute unless entity @s[tag=ec._a] if items entity @s weapon.offhand *[custom_data~{artifact:"stormrider_pinion"}] run tag @s add ec._a
execute if entity @s[tag=ec._a] if predicate evercraft:not_on_ground if score @s ec.h_speed matches ..1 run effect give @s speed 2 0 false
tag @s remove ec._a
# --- Featherscale Down (rare) — No fall damage. Fixed-id fall_damage_multiplier 0 (the stride_fall idiom),
#     stripped on drop in accessory_cleanup. Its +1% dodge is in the m1 LEAF block. ---
execute if items entity @s container.* *[custom_data~{artifact:"featherscale_down"}] run tag @s add ec._a
execute unless items entity @s container.* *[custom_data~{artifact:"featherscale_down"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"featherscale_down"}] if entity @s[tag=ec.sat_featherscale_down] run tag @s add ec._a
execute unless entity @s[tag=ec._a] if items entity @s weapon.offhand *[custom_data~{artifact:"featherscale_down"}] run tag @s add ec._a
execute if entity @s[tag=ec._a] run attribute @s fall_damage_multiplier modifier add evercraft:featherscale_down_fall -1.0 add_multiplied_base
tag @s remove ec._a
# --- Dragonheart Ember (exquisite) — Fire Resistance (ungated, like blaze_core / the band's fire res) +
#     Strength I WHILE ON FIRE (Wave 3 §2E differentiator vs blaze_core / dragonheart_mace — the third plain
#     fire-res accessory now has a unique hook). The on-fire check reads the player's Fire tick count into
#     ec.dhe_fire (this block is the ONE writer of that score — the depth_readout idiom) and grants Strength I
#     when Fire > 0. Note the dragon's blood runs hottest in the flames: fire_res prevents the burn DAMAGE but
#     the bearer can still be alight, so the on-fire window is real. harmonize-gated (h_str ..1) like the
#     other Strength accessories so it never stacks past the harmonize cap. ---
execute if items entity @s container.* *[custom_data~{artifact:"dragonheart_ember"}] run tag @s add ec._a
execute unless items entity @s container.* *[custom_data~{artifact:"dragonheart_ember"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"dragonheart_ember"}] if entity @s[tag=ec.sat_dragonheart_ember] run tag @s add ec._a
execute unless entity @s[tag=ec._a] if items entity @s weapon.offhand *[custom_data~{artifact:"dragonheart_ember"}] run tag @s add ec._a
execute if entity @s[tag=ec._a] run effect give @s fire_resistance 15 0 false
execute if entity @s[tag=ec._a] store result score @s ec.dhe_fire run data get entity @s Fire 1
execute if entity @s[tag=ec._a] if score @s ec.dhe_fire matches 1.. if score @s ec.h_str matches ..1 run effect give @s strength 5 0 false
tag @s remove ec._a
# --- Wyrmblood Vial (ornate) — Regeneration I below 6 hearts (last-stand). Health-gated effect (6 hearts
#     = 12 HP -> health_below_12); regen-fallback aware so it does not waste at a Regen cap. ---
execute if items entity @s container.* *[custom_data~{artifact:"wyrmblood_vial"}] run tag @s add ec._a
execute unless items entity @s container.* *[custom_data~{artifact:"wyrmblood_vial"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"wyrmblood_vial"}] if entity @s[tag=ec.sat_wyrmblood_vial] run tag @s add ec._a
execute unless entity @s[tag=ec._a] if items entity @s weapon.offhand *[custom_data~{artifact:"wyrmblood_vial"}] run tag @s add ec._a
execute if entity @s[tag=ec._a] if predicate evercraft:health_below_12 unless entity @s[tag=ec.regen_capped] run effect give @s regeneration 5 0 false
tag @s remove ec._a
# --- Enderscale Eye (exquisite) — Night Vision + Darkness immunity (the warden_ring darkness-clear idiom). ---
execute if items entity @s container.* *[custom_data~{artifact:"enderscale_eye"}] run tag @s add ec._a
execute unless items entity @s container.* *[custom_data~{artifact:"enderscale_eye"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"enderscale_eye"}] if entity @s[tag=ec.sat_enderscale_eye] run tag @s add ec._a
execute unless entity @s[tag=ec._a] if items entity @s weapon.offhand *[custom_data~{artifact:"enderscale_eye"}] run tag @s add ec._a
execute if entity @s[tag=ec._a] run effect give @s night_vision 15 0 false
execute if entity @s[tag=ec._a] run effect clear @s darkness
tag @s remove ec._a
# --- Breath-Gland Sac (exquisite) — crouch-fire breath cone: 3 dmg + 3s ignite to hostiles ≤5 blocks in the
#     look direction, rendered with vanilla dragon_breath + flame particles (the dragons_fury cone idiom, no
#     resource pack). Sneak-gated so it is a deliberate exhale, not a passive aura. Its +1% dodge is in the m1
#     LEAF block. ---
execute if items entity @s container.* *[custom_data~{artifact:"breathgland_sac"}] run tag @s add ec._a
execute unless items entity @s container.* *[custom_data~{artifact:"breathgland_sac"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"breathgland_sac"}] if entity @s[tag=ec.sat_breathgland_sac] run tag @s add ec._a
execute unless entity @s[tag=ec._a] if items entity @s weapon.offhand *[custom_data~{artifact:"breathgland_sac"}] run tag @s add ec._a
execute if entity @s[tag=ec._a] if predicate evercraft:sneaking at @s positioned ^ ^ ^2 as @e[type=#evercraft:hostile_mobs,distance=..3,limit=5] run damage @s 3 minecraft:dragon_breath
execute if entity @s[tag=ec._a] if predicate evercraft:sneaking at @s positioned ^ ^ ^2 as @e[type=#evercraft:hostile_mobs,distance=..3,limit=5] run data merge entity @s {Fire:60s}
execute if entity @s[tag=ec._a] if predicate evercraft:sneaking at @s run particle dragon_breath ^ ^1 ^1 0.3 0.3 0.3 0.02 6
execute if entity @s[tag=ec._a] if predicate evercraft:sneaking at @s run particle flame ^ ^1 ^2 0.5 0.4 0.5 0.02 8
tag @s remove ec._a
# --- Voidscale Shard (exquisite) — Void immunity (no void-fall death). When the bearer has fallen below the
#     world floor (Y ≤ -70, clearly into the void below bedrock -64), arrest the fall with Slow Falling +
#     Resistance V + Fire Resistance and a brief upward Levitation so they cannot reach the death plane —
#     vanilla effects only, NO teleport relocation (additive + bounded, no resource pack). Reads Pos[1] into
#     ec._vy (this file is the one writer of ec._vy) the depth_readout idiom. Its +1% dodge is NOT carried
#     (per the D-DODGE leaf set: rows 1, 8, 9, 10, 14 are the +4 leaves; Voidscale is not among them). ---
execute if items entity @s container.* *[custom_data~{artifact:"voidscale_shard"}] run tag @s add ec._a
execute unless items entity @s container.* *[custom_data~{artifact:"voidscale_shard"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"voidscale_shard"}] if entity @s[tag=ec.sat_voidscale_shard] run tag @s add ec._a
execute unless entity @s[tag=ec._a] if items entity @s weapon.offhand *[custom_data~{artifact:"voidscale_shard"}] run tag @s add ec._a
execute if entity @s[tag=ec._a] store result score @s ec._vy run data get entity @s Pos[1] 1
execute if entity @s[tag=ec._a] if score @s ec._vy matches ..-70 run effect give @s slow_falling 5 0 true
execute if entity @s[tag=ec._a] if score @s ec._vy matches ..-70 run effect give @s resistance 5 4 true
execute if entity @s[tag=ec._a] if score @s ec._vy matches ..-70 run effect give @s fire_resistance 5 0 true
execute if entity @s[tag=ec._a] if score @s ec._vy matches ..-70 run effect give @s levitation 1 4 true
tag @s remove ec._a

# Sculk Singularity — Gravity Well (12b pull, toggle) + Singularity Shield (Slow Falling + projectile deflect)
# OPT: Tag consolidation (was 4 item scans → 2)
# Gravity Well: drag hostiles within 12b toward the bearer (widened 8->12, limit 3->5). Toggle-gated on
# ec.t_singularity (1 = OFF) — the ring_of_undying toggle idiom — so the sometimes-dangerous pull can be
# turned off. Singularity Shield (P3 graviton deflect idiom + P1-style self Slow Falling) stays active
# regardless of the toggle: scatter incoming projectiles within 4b away (tagged sng_deflected, one-shot,
# cleared 3s later) + permanent Slow Falling. Effects >=3s to bridge the 1s player_tick cadence.
execute if items entity @s container.* *[custom_data~{artifact:"sculk_singularity"}] run tag @s add ec._a
execute unless items entity @s container.* *[custom_data~{artifact:"sculk_singularity"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"sculk_singularity"}] if entity @s[tag=ec.sat_sculk_singularity] run tag @s add ec._a
execute unless entity @s[tag=ec._a] if items entity @s weapon.offhand *[custom_data~{artifact:"sculk_singularity"}] run tag @s add ec._a
# Gravity Well (toggle-gated)
execute if entity @s[tag=ec._a] unless score @s ec.t_singularity matches 1 as @e[type=#evercraft:hostile_mobs,distance=2..12,limit=5] at @s facing entity @p feet run tp @s ^ ^ ^0.4
execute if entity @s[tag=ec._a] unless score @s ec.t_singularity matches 1 run particle sculk_soul ~ ~1 ~ 1 0.5 1 0.02 2
# Singularity Shield — self Slow Falling + projectile deflect (always on)
execute if entity @s[tag=ec._a] run effect give @s slow_falling 5 0 false
execute if entity @s[tag=ec._a] at @s as @e[type=arrow,distance=..4,nbt={inGround:0b},tag=!sng_deflected] run function evercraft:artifacts/abilities/sculk_singularity_deflect
execute if entity @s[tag=ec._a] at @s as @e[type=spectral_arrow,distance=..4,nbt={inGround:0b},tag=!sng_deflected] run function evercraft:artifacts/abilities/sculk_singularity_deflect
execute if entity @s[tag=ec._a] at @s as @e[type=fireball,distance=..5,tag=!sng_deflected] run function evercraft:artifacts/abilities/sculk_singularity_deflect
execute if entity @s[tag=ec._a] at @s as @e[type=small_fireball,distance=..4,tag=!sng_deflected] run function evercraft:artifacts/abilities/sculk_singularity_deflect
execute if entity @s[tag=ec._a] at @s as @e[type=wither_skull,distance=..4,tag=!sng_deflected] run function evercraft:artifacts/abilities/sculk_singularity_deflect
execute if entity @s[tag=ec._a] at @s as @e[type=shulker_bullet,distance=..4,tag=!sng_deflected] run function evercraft:artifacts/abilities/sculk_singularity_deflect
execute if entity @s[tag=ec._a] at @s as @e[type=wind_charge,distance=..4,tag=!sng_deflected] run function evercraft:artifacts/abilities/sculk_singularity_deflect
execute if entity @s[tag=ec._a] at @s as @e[type=trident,distance=..4,nbt={DealtDamage:0b},tag=!sng_deflected] run function evercraft:artifacts/abilities/sculk_singularity_deflect
tag @s remove ec._a

# Redstone Heart — Haste III (passive toggle) + Overclock (sneak-active mining burst)
execute if score @s ec.h_haste matches ..1 if items entity @s container.* *[custom_data~{artifact:"redstone_heart"}] unless score @s ec.t_redhrt matches 1 run effect give @s haste 5 2 false
execute if score @s ec.h_haste matches ..1 unless items entity @s container.* *[custom_data~{artifact:"redstone_heart"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"redstone_heart"}] if entity @s[tag=ec.sat_redstone_heart] unless score @s ec.t_redhrt matches 1 run effect give @s haste 5 2 false
execute if score @s ec.h_haste matches ..1 if items entity @s weapon.offhand *[custom_data~{artifact:"redstone_heart"}] unless score @s ec.t_redhrt matches 1 run effect give @s haste 5 2 false
# Overclock — sneak-active Haste IV burst (8s, 30s cooldown). The feasible substitute for the impossible
# "auto-power 32b" / "furnaces 4x" claims: a deliberate sneak-triggered mining surge (Haste IS the vanilla
# break-speed mechanic). ec._a single-scan (container.* + satchel + offhand). Fires regardless of the
# passive Haste III toggle (it's a deliberate action). Cooldown ec.cd_overclock (decremented in the cd_*
# block above) is SET in redstone_heart_overclock — one writer beside the source-set. Multi-copy-safe.
execute if items entity @s container.* *[custom_data~{artifact:"redstone_heart"}] run tag @s add ec._a
execute unless items entity @s container.* *[custom_data~{artifact:"redstone_heart"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"redstone_heart"}] if entity @s[tag=ec.sat_redstone_heart] run tag @s add ec._a
execute unless entity @s[tag=ec._a] if items entity @s weapon.offhand *[custom_data~{artifact:"redstone_heart"}] run tag @s add ec._a
execute if entity @s[tag=ec._a] if predicate evercraft:sneaking if predicate evercraft:looking_down unless score @s ec.cd_overclock matches 1.. run function evercraft:artifacts/abilities/redstone_heart_overclock
# Smeltery Field (Joseph 2026-06-10) — the codex's "furnaces and brewing stands at 4x", now REAL
# via the blacksmith cooking_time_spent idiom: +60 cook ticks/s to lit smelters and -60 BrewTime/s
# to active brewing stands within the 5x5x3 footprint (natural 20/s + 60 boost = 4x).
execute if entity @s[tag=ec._a] at @s run function evercraft:artifacts/abilities/redstone_heart_smeltery
tag @s remove ec._a

# Prism of Light — Absorption IV + Night Vision + Radiance damage aura + projectile deflect + ally light-ward
# OPT: Tag consolidation (was 4 item scans → 2)
# Radiance (P2 soul_reaver direct-damage idiom): all hostiles in 24b take 1 dmg ONCE per second — gated by
# ec.pol_dmgcd (set to 1 here, ticked down in the cd_* block above) so it never fires more than 1/s even if
# the cadence tightens. Prismatic Shield (P3 graviton deflect idiom): scatter incoming projectiles within
# 4b away from the bearer (the feasible substitute for the impossible "100% reflect"), tagged pol_deflected
# so each projectile is only deflected once (cleared 3s later by prism_clear_deflect). Light-ward (P1): allies
# in 16b share Night Vision (particles hidden). Keep self Absorption IV + Night Vision.
execute if items entity @s container.* *[custom_data~{artifact:"prism_of_light"}] run tag @s add ec._a
execute unless items entity @s container.* *[custom_data~{artifact:"prism_of_light"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"prism_of_light"}] if entity @s[tag=ec.sat_prism_of_light] run tag @s add ec._a
execute unless entity @s[tag=ec._a] if items entity @s weapon.offhand *[custom_data~{artifact:"prism_of_light"}] run tag @s add ec._a
execute if entity @s[tag=ec._a] run effect give @s absorption 5 3 false
execute if entity @s[tag=ec._a] run effect give @s night_vision 15 0 false
# Light-ward — ally Night Vision in 16b
execute if entity @s[tag=ec._a] at @s run effect give @a[distance=..16] night_vision 15 0 true
# Radiance — 24b hostiles take 1 dmg once per second
execute if entity @s[tag=ec._a] unless score @s ec.pol_dmgcd matches 1.. at @s as @e[type=#evercraft:hostile_mobs,distance=..24,limit=8] run damage @s 1 minecraft:magic
execute if entity @s[tag=ec._a] unless score @s ec.pol_dmgcd matches 1.. run scoreboard players set @s ec.pol_dmgcd 1
# Prismatic Shield — deflect incoming projectiles within 4b (only those not yet tagged pol_deflected)
execute if entity @s[tag=ec._a] at @s as @e[type=arrow,distance=..4,nbt={inGround:0b},tag=!pol_deflected] run function evercraft:artifacts/abilities/prism_deflect
execute if entity @s[tag=ec._a] at @s as @e[type=spectral_arrow,distance=..4,nbt={inGround:0b},tag=!pol_deflected] run function evercraft:artifacts/abilities/prism_deflect
execute if entity @s[tag=ec._a] at @s as @e[type=fireball,distance=..5,tag=!pol_deflected] run function evercraft:artifacts/abilities/prism_deflect
execute if entity @s[tag=ec._a] at @s as @e[type=small_fireball,distance=..4,tag=!pol_deflected] run function evercraft:artifacts/abilities/prism_deflect
execute if entity @s[tag=ec._a] at @s as @e[type=wither_skull,distance=..4,tag=!pol_deflected] run function evercraft:artifacts/abilities/prism_deflect
execute if entity @s[tag=ec._a] at @s as @e[type=shulker_bullet,distance=..4,tag=!pol_deflected] run function evercraft:artifacts/abilities/prism_deflect
execute if entity @s[tag=ec._a] at @s as @e[type=wind_charge,distance=..4,tag=!pol_deflected] run function evercraft:artifacts/abilities/prism_deflect
execute if entity @s[tag=ec._a] at @s as @e[type=trident,distance=..4,nbt={DealtDamage:0b},tag=!pol_deflected] run function evercraft:artifacts/abilities/prism_deflect
tag @s remove ec._a

# Netherite Nexus — Resistance III + Luck IV
# OPT: Tag consolidation (was 4 item scans → 2)
execute if items entity @s container.* *[custom_data~{artifact:"netherite_nexus"}] run tag @s add ec._a
execute unless items entity @s container.* *[custom_data~{artifact:"netherite_nexus"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"netherite_nexus"}] if entity @s[tag=ec.sat_netherite_nexus] run tag @s add ec._a
execute unless entity @s[tag=ec._a] if items entity @s weapon.offhand *[custom_data~{artifact:"netherite_nexus"}] run tag @s add ec._a
execute if entity @s[tag=ec._a] if score @s ec.h_resist matches ..1 run effect give @s resistance 5 2 false
execute if entity @s[tag=ec._a] run attribute @s luck modifier add evercraft:netherite_nexus_luck 4.0 add_value
execute if entity @s[tag=ec._a] run attribute @s knockback_resistance modifier add evercraft:netherite_nexus_kb 1 add_value
# Nexus Field — the codex's "armor effectiveness doubled", now REAL (Joseph 2026-06-10):
# add_multiplied_total x1.0 on armor + toughness doubles the equipment totals (engine caps
# armor at 30 / toughness at 20). Stripped in accessory_cleanup when the Nexus leaves.
execute if entity @s[tag=ec._a] run attribute @s armor modifier add evercraft:netherite_nexus_armor 1.0 add_multiplied_total
execute if entity @s[tag=ec._a] run attribute @s armor_toughness modifier add evercraft:netherite_nexus_tough 1.0 add_multiplied_total
tag @s remove ec._a

# Claude's Gift — Strength III + Haste III + Speed III + Luck V
# OPT: Tag consolidation (was 10 item scans → 2)
# Skip harmonizable effects when 2+ sources are active
execute if items entity @s container.* *[custom_data~{artifact:"claudes_gift"}] run tag @s add ec._a
execute unless items entity @s container.* *[custom_data~{artifact:"claudes_gift"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"claudes_gift"}] if entity @s[tag=ec.sat_claudes_gift] run tag @s add ec._a
execute unless entity @s[tag=ec._a] if items entity @s weapon.offhand *[custom_data~{artifact:"claudes_gift"}] run tag @s add ec._a
execute if entity @s[tag=ec._a] if score @s ec.h_str matches ..1 run effect give @s strength 5 2 false
execute if entity @s[tag=ec._a] if score @s ec.h_haste matches ..1 run effect give @s haste 5 2 false
execute if entity @s[tag=ec._a] if score @s ec.h_speed matches ..1 run effect give @s speed 5 2 false
execute if entity @s[tag=ec._a] run attribute @s luck modifier add evercraft:claudes_gift_luck 5.0 add_value
# Claude's Touch (Joseph 2026-06-10) — the codex's "all effects enhanced by 1 level", made REAL
# as +1-enchant-level attribute equivalents (no potion-effect inflation): Efficiency +1 (true
# break-speed, not Haste), Swift Sneak +1, Depth Strider +1, Respiration +1. All stripped in
# accessory_cleanup when the Gift leaves. The "all drops doubled" half lives in
# abilities/claudes_gift_double (kill-drop duplication, advancement-driven).
execute if entity @s[tag=ec._a] run attribute @s mining_efficiency modifier add evercraft:claudes_gift_eff 1 add_value
execute if entity @s[tag=ec._a] run attribute @s sneaking_speed modifier add evercraft:claudes_gift_sneak 0.15 add_value
execute if entity @s[tag=ec._a] run attribute @s water_movement_efficiency modifier add evercraft:claudes_gift_dstr 0.33 add_value
execute if entity @s[tag=ec._a] run attribute @s oxygen_bonus modifier add evercraft:claudes_gift_resp 1 add_value
execute if entity @s[tag=ec._a] run particle end_rod ~ ~1 ~ 0.3 0.5 0.3 0.02 1
tag @s remove ec._a

# ============================================================
# === BOSS EXCLUSIVE ACCESSORIES ===
# ============================================================

# Soul Reaver (Hollow King) — Wither aura + 1.5 Dream Rate
# OPT: Tag consolidation (was 4 item scans → 2)
execute if items entity @s container.* *[custom_data~{artifact:"soul_reaver"}] run tag @s add ec._a
execute unless items entity @s container.* *[custom_data~{artifact:"soul_reaver"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"soul_reaver"}] if entity @s[tag=ec.sat_soul_reaver] run tag @s add ec._a
execute unless entity @s[tag=ec._a] if items entity @s weapon.offhand *[custom_data~{artifact:"soul_reaver"}] run tag @s add ec._a
execute if entity @s[tag=ec._a] run effect give @e[type=#evercraft:hostile_mobs,distance=..6,limit=5] wither 3 0 false
execute if entity @s[tag=ec._a] run attribute @s luck modifier add evercraft:soul_reaver_luck 1.5 add_value
tag @s remove ec._a

# Thornheart Bloom (Verdant Warden) — Regen on dirt + Poison aura + 1.5 Dream Rate
# OPT: Tag consolidation (was 6 item scans → 2)
execute if items entity @s container.* *[custom_data~{artifact:"thornheart_bloom"}] run tag @s add ec._a
execute unless items entity @s container.* *[custom_data~{artifact:"thornheart_bloom"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"thornheart_bloom"}] if entity @s[tag=ec.sat_thornheart_bloom] run tag @s add ec._a
execute unless entity @s[tag=ec._a] if items entity @s weapon.offhand *[custom_data~{artifact:"thornheart_bloom"}] run tag @s add ec._a
execute if entity @s[tag=ec._a] if score @s ec.h_regen matches ..1 if block ~ ~-1 ~ #evercraft:natural_ground unless entity @s[tag=ec.regen_capped] run effect give @s regeneration 5 0 false
execute if entity @s[tag=ec._a] if score @s ec.h_regen matches ..1 if block ~ ~-1 ~ #evercraft:natural_ground if entity @s[tag=ec.regen_capped] run function evercraft:artifacts/accessories/regen_fallback
execute if entity @s[tag=ec._a] run effect give @e[type=#evercraft:hostile_mobs,distance=..5,limit=5] poison 3 0 false
execute if entity @s[tag=ec._a] run attribute @s luck modifier add evercraft:thornheart_bloom_luck 1.5 add_value
tag @s remove ec._a

# Thunderstrike Core (Stormforged) — Speed II + Resistance I + 1.5 Dream Rate
# OPT: Tag consolidation (was 6 item scans → 2)
execute if items entity @s container.* *[custom_data~{artifact:"thunderstrike_core"}] run tag @s add ec._a
execute unless items entity @s container.* *[custom_data~{artifact:"thunderstrike_core"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"thunderstrike_core"}] if entity @s[tag=ec.sat_thunderstrike_core] run tag @s add ec._a
execute unless entity @s[tag=ec._a] if items entity @s weapon.offhand *[custom_data~{artifact:"thunderstrike_core"}] run tag @s add ec._a
execute if entity @s[tag=ec._a] if score @s ec.h_speed matches ..1 run effect give @s speed 5 1 false
execute if entity @s[tag=ec._a] if score @s ec.h_resist matches ..1 run effect give @s resistance 5 0 false
execute if entity @s[tag=ec._a] run attribute @s luck modifier add evercraft:thunderstrike_core_luck 1.5 add_value
tag @s remove ec._a

# Abyssal Pearl (Tidecaller) — Water Breathing + Dolphin's Grace + Conduit Power + 1.5 Dream Rate
# OPT: Tag consolidation (was 8 item scans → 2)
execute if items entity @s container.* *[custom_data~{artifact:"abyssal_pearl"}] run tag @s add ec._a
execute unless items entity @s container.* *[custom_data~{artifact:"abyssal_pearl"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"abyssal_pearl"}] if entity @s[tag=ec.sat_abyssal_pearl] run tag @s add ec._a
execute unless entity @s[tag=ec._a] if items entity @s weapon.offhand *[custom_data~{artifact:"abyssal_pearl"}] run tag @s add ec._a
execute if entity @s[tag=ec._a] run effect give @s water_breathing 15 0 false
execute if entity @s[tag=ec._a] run effect give @s dolphins_grace 5 0 false
execute if entity @s[tag=ec._a] run effect give @s conduit_power 5 0 false
execute if entity @s[tag=ec._a] run attribute @s luck modifier add evercraft:abyssal_pearl_luck 1.5 add_value
tag @s remove ec._a

# Earthshaker Core (Earthshaker) — Resistance II + KB Resistance + 1.5 Dream Rate
# OPT: Tag consolidation (was 6 item scans → 2)
execute if items entity @s container.* *[custom_data~{artifact:"earthshaker_core"}] run tag @s add ec._a
execute unless items entity @s container.* *[custom_data~{artifact:"earthshaker_core"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"earthshaker_core"}] if entity @s[tag=ec.sat_earthshaker_core] run tag @s add ec._a
execute unless entity @s[tag=ec._a] if items entity @s weapon.offhand *[custom_data~{artifact:"earthshaker_core"}] run tag @s add ec._a
execute if entity @s[tag=ec._a] if score @s ec.h_resist matches ..1 run effect give @s resistance 5 1 false
execute if entity @s[tag=ec._a] run attribute @s knockback_resistance modifier add evercraft:earthshaker_core_kb 0.5 add_value
execute if entity @s[tag=ec._a] run attribute @s luck modifier add evercraft:earthshaker_core_luck 1.5 add_value
tag @s remove ec._a

# Nightmare Fragment (Nightmare) — Speed I + Invisibility while sneaking + 1.5 Dream Rate
# OPT: Tag consolidation (was 6 item scans → 2)
execute if items entity @s container.* *[custom_data~{artifact:"nightmare_fragment"}] run tag @s add ec._a
execute unless items entity @s container.* *[custom_data~{artifact:"nightmare_fragment"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"nightmare_fragment"}] if entity @s[tag=ec.sat_nightmare_fragment] run tag @s add ec._a
execute unless entity @s[tag=ec._a] if items entity @s weapon.offhand *[custom_data~{artifact:"nightmare_fragment"}] run tag @s add ec._a
execute if entity @s[tag=ec._a] if score @s ec.h_speed matches ..1 run effect give @s speed 5 0 false
execute if entity @s[tag=ec._a] if predicate evercraft:sneaking run effect give @s invisibility 5 0 false
execute if entity @s[tag=ec._a] run attribute @s luck modifier add evercraft:nightmare_fragment_luck 1.5 add_value
tag @s remove ec._a

# Infernal Heart (Infernal Titan) — Fire Resistance + Strength I + fire aura + 1.5 Dream Rate
# OPT: Tag consolidation (was 8 item scans → 2)
execute if items entity @s container.* *[custom_data~{artifact:"infernal_heart"}] run tag @s add ec._a
execute unless items entity @s container.* *[custom_data~{artifact:"infernal_heart"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"infernal_heart"}] if entity @s[tag=ec.sat_infernal_heart] run tag @s add ec._a
execute unless entity @s[tag=ec._a] if items entity @s weapon.offhand *[custom_data~{artifact:"infernal_heart"}] run tag @s add ec._a
execute if entity @s[tag=ec._a] run effect give @s fire_resistance 15 0 false
execute if entity @s[tag=ec._a] if score @s ec.h_str matches ..1 run effect give @s strength 5 0 false
execute if entity @s[tag=ec._a] as @e[type=#evercraft:hostile_mobs,distance=..4,limit=5] run damage @s 1 minecraft:in_fire
execute if entity @s[tag=ec._a] run attribute @s luck modifier add evercraft:infernal_heart_luck 1.5 add_value
tag @s remove ec._a

# Soulkeeper's Ember (Soul Warden) — Strength I + undead pacified + 1.5 Dream Rate
# OPT: Tag consolidation (was 6 item scans → 2)
execute if items entity @s container.* *[custom_data~{artifact:"soulkeepers_ember"}] run tag @s add ec._a
execute unless items entity @s container.* *[custom_data~{artifact:"soulkeepers_ember"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"soulkeepers_ember"}] if entity @s[tag=ec.sat_soulkeepers_ember] run tag @s add ec._a
execute unless entity @s[tag=ec._a] if items entity @s weapon.offhand *[custom_data~{artifact:"soulkeepers_ember"}] run tag @s add ec._a
execute if entity @s[tag=ec._a] if score @s ec.h_str matches ..1 run effect give @s strength 5 0 false
execute if entity @s[tag=ec._a] run effect give @e[type=#minecraft:undead,distance=..12] weakness 5 4 false
execute if entity @s[tag=ec._a] run attribute @s luck modifier add evercraft:soulkeepers_ember_luck 1.5 add_value
tag @s remove ec._a

# Behemoth's Heart (Crimson Behemoth) — Health Boost II + Absorption I + 1.5 Dream Rate
# OPT: Tag consolidation (was 6 item scans → 2)
execute if items entity @s container.* *[custom_data~{artifact:"behemoths_heart"}] run tag @s add ec._a
execute unless items entity @s container.* *[custom_data~{artifact:"behemoths_heart"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"behemoths_heart"}] if entity @s[tag=ec.sat_behemoths_heart] run tag @s add ec._a
execute unless entity @s[tag=ec._a] if items entity @s weapon.offhand *[custom_data~{artifact:"behemoths_heart"}] run tag @s add ec._a
execute if entity @s[tag=ec._a] run effect give @s health_boost 5 1 false
execute if entity @s[tag=ec._a] run effect give @s absorption 5 0 false
execute if entity @s[tag=ec._a] run attribute @s luck modifier add evercraft:behemoths_heart_luck 1.5 add_value
tag @s remove ec._a

# Void Sovereign's Eye (Void Sovereign) — Night Vision + Slow Falling + arcane aura + 2.0 Dream Rate
# OPT: Tag consolidation (was 8 item scans → 2)
execute if items entity @s container.* *[custom_data~{artifact:"void_sovereigns_eye"}] run tag @s add ec._a
execute unless items entity @s container.* *[custom_data~{artifact:"void_sovereigns_eye"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"void_sovereigns_eye"}] if entity @s[tag=ec.sat_void_sovereigns_eye] run tag @s add ec._a
execute unless entity @s[tag=ec._a] if items entity @s weapon.offhand *[custom_data~{artifact:"void_sovereigns_eye"}] run tag @s add ec._a
execute if entity @s[tag=ec._a] run effect give @s night_vision 15 0 false
execute if entity @s[tag=ec._a] run effect give @s slow_falling 5 0 false
execute if entity @s[tag=ec._a] as @e[type=#evercraft:hostile_mobs,distance=..5,limit=5] run damage @s 2 evercraft:bonus_strike
execute if entity @s[tag=ec._a] run attribute @s luck modifier add evercraft:void_sovereigns_eye_luck 2.0 add_value
tag @s remove ec._a

# Architect's Design (Ender Architect) — Night Vision + Speed I + Levitation aura + 2.0 Dream Rate
# OPT: Tag consolidation (was 8 item scans → 2)
execute if items entity @s container.* *[custom_data~{artifact:"architects_design"}] run tag @s add ec._a
execute unless items entity @s container.* *[custom_data~{artifact:"architects_design"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"architects_design"}] if entity @s[tag=ec.sat_architects_design] run tag @s add ec._a
execute unless entity @s[tag=ec._a] if items entity @s weapon.offhand *[custom_data~{artifact:"architects_design"}] run tag @s add ec._a
execute if entity @s[tag=ec._a] run effect give @s night_vision 15 0 false
execute if entity @s[tag=ec._a] if score @s ec.h_speed matches ..1 run effect give @s speed 5 0 false
execute if entity @s[tag=ec._a] run effect give @e[type=#evercraft:hostile_mobs,distance=..6,limit=5] levitation 3 0 false
execute if entity @s[tag=ec._a] run attribute @s luck modifier add evercraft:architects_design_luck 2.0 add_value
tag @s remove ec._a

# ============================================================
# === RING ARTIFACTS ===
# ============================================================

# Amethyst Ring — Night Vision (Common) # OPT: Tag consolidation
execute if items entity @s container.* *[custom_data~{artifact:"ring_amethyst"}] run tag @s add ec._a
execute unless items entity @s container.* *[custom_data~{artifact:"ring_amethyst"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"ring_amethyst"}] if entity @s[tag=ec.sat_ring_amethyst] run tag @s add ec._a
execute unless entity @s[tag=ec._a] if items entity @s weapon.offhand *[custom_data~{artifact:"ring_amethyst"}] run tag @s add ec._a
execute if entity @s[tag=ec._a] run effect give @s night_vision 13 0 true
tag @s remove ec._a

# Lapis Ring — Water Breathing (Common) # OPT: Tag consolidation
execute if items entity @s container.* *[custom_data~{artifact:"ring_lapis"}] run tag @s add ec._a
execute unless items entity @s container.* *[custom_data~{artifact:"ring_lapis"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"ring_lapis"}] if entity @s[tag=ec.sat_ring_lapis] run tag @s add ec._a
execute unless entity @s[tag=ec._a] if items entity @s weapon.offhand *[custom_data~{artifact:"ring_lapis"}] run tag @s add ec._a
execute if entity @s[tag=ec._a] run effect give @s water_breathing 5 0 true
tag @s remove ec._a

# Redstone Ring — Haste (Uncommon)
execute if score @s ec.h_haste matches ..1 if items entity @s container.* *[custom_data~{artifact:"ring_redstone"}] run effect give @s haste 5 0 true
execute if score @s ec.h_haste matches ..1 unless items entity @s container.* *[custom_data~{artifact:"ring_redstone"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"ring_redstone"}] if entity @s[tag=ec.sat_ring_redstone] run effect give @s haste 5 0 true
execute if score @s ec.h_haste matches ..1 if items entity @s weapon.offhand *[custom_data~{artifact:"ring_redstone"}] run effect give @s haste 5 0 true

# Diamond Ring — Speed (Uncommon)
execute if score @s ec.h_speed matches ..1 if items entity @s container.* *[custom_data~{artifact:"ring_diamond"}] run effect give @s speed 5 0 true
execute if score @s ec.h_speed matches ..1 unless items entity @s container.* *[custom_data~{artifact:"ring_diamond"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"ring_diamond"}] if entity @s[tag=ec.sat_ring_diamond] run effect give @s speed 5 0 true
execute if score @s ec.h_speed matches ..1 if items entity @s weapon.offhand *[custom_data~{artifact:"ring_diamond"}] run effect give @s speed 5 0 true

# Slime Ring — Jump Boost (Uncommon)
execute if score @s ec.h_jump matches ..1 if items entity @s container.* *[custom_data~{artifact:"ring_slime"}] run effect give @s jump_boost 5 0 true
execute if score @s ec.h_jump matches ..1 unless items entity @s container.* *[custom_data~{artifact:"ring_slime"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"ring_slime"}] if entity @s[tag=ec.sat_ring_slime] run effect give @s jump_boost 5 0 true
execute if score @s ec.h_jump matches ..1 if items entity @s weapon.offhand *[custom_data~{artifact:"ring_slime"}] run effect give @s jump_boost 5 0 true

# Emerald Ring — Hero of the Village (Rare) # OPT: Tag consolidation
execute if items entity @s container.* *[custom_data~{artifact:"ring_emerald"}] run tag @s add ec._a
execute unless items entity @s container.* *[custom_data~{artifact:"ring_emerald"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"ring_emerald"}] if entity @s[tag=ec.sat_ring_emerald] run tag @s add ec._a
execute unless entity @s[tag=ec._a] if items entity @s weapon.offhand *[custom_data~{artifact:"ring_emerald"}] run tag @s add ec._a
execute if entity @s[tag=ec._a] run effect give @s hero_of_the_village 5 0 true
tag @s remove ec._a

# Bone Ring — Weakness Aura (Rare) # OPT: Tag consolidation
execute if items entity @s container.* *[custom_data~{artifact:"ring_bone"}] run tag @s add ec._a
execute unless items entity @s container.* *[custom_data~{artifact:"ring_bone"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"ring_bone"}] if entity @s[tag=ec.sat_ring_bone] run tag @s add ec._a
execute unless entity @s[tag=ec._a] if items entity @s weapon.offhand *[custom_data~{artifact:"ring_bone"}] run tag @s add ec._a
execute if entity @s[tag=ec._a] run effect give @e[type=#evercraft:hostile_mobs,distance=..5] weakness 2 0 true
tag @s remove ec._a

# Honey Ring — Slowness Aura (Rare) # OPT: Tag consolidation
execute if items entity @s container.* *[custom_data~{artifact:"ring_honey"}] run tag @s add ec._a
execute unless items entity @s container.* *[custom_data~{artifact:"ring_honey"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"ring_honey"}] if entity @s[tag=ec.sat_ring_honey] run tag @s add ec._a
execute unless entity @s[tag=ec._a] if items entity @s weapon.offhand *[custom_data~{artifact:"ring_honey"}] run tag @s add ec._a
execute if entity @s[tag=ec._a] run effect give @e[type=#evercraft:hostile_mobs,distance=..5] slowness 2 0 true
tag @s remove ec._a

# Nether Ring — Resistance II (Ornate)
execute if score @s ec.h_resist matches ..1 if items entity @s container.* *[custom_data~{artifact:"ring_nether"}] run effect give @s resistance 5 1 true
execute if score @s ec.h_resist matches ..1 unless items entity @s container.* *[custom_data~{artifact:"ring_nether"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"ring_nether"}] if entity @s[tag=ec.sat_ring_nether] run effect give @s resistance 5 1 true
execute if score @s ec.h_resist matches ..1 if items entity @s weapon.offhand *[custom_data~{artifact:"ring_nether"}] run effect give @s resistance 5 1 true

# Trial Ring — +2 Dream Rate (Ornate) # OPT: Tag consolidation
execute if items entity @s container.* *[custom_data~{artifact:"ring_trial"}] run tag @s add ec._a
execute unless items entity @s container.* *[custom_data~{artifact:"ring_trial"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"ring_trial"}] if entity @s[tag=ec.sat_ring_trial] run tag @s add ec._a
execute unless entity @s[tag=ec._a] if items entity @s weapon.offhand *[custom_data~{artifact:"ring_trial"}] run tag @s add ec._a
execute if entity @s[tag=ec._a] run attribute @s luck modifier add evercraft:trial_ring_luck 2.0 add_value
tag @s remove ec._a

# Ominous Ring — Health Boost II (Exquisite) # OPT: Tag consolidation
execute if items entity @s container.* *[custom_data~{artifact:"ring_ominous"}] run tag @s add ec._a
execute unless items entity @s container.* *[custom_data~{artifact:"ring_ominous"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"ring_ominous"}] if entity @s[tag=ec.sat_ring_ominous] run tag @s add ec._a
execute unless entity @s[tag=ec._a] if items entity @s weapon.offhand *[custom_data~{artifact:"ring_ominous"}] run tag @s add ec._a
execute if entity @s[tag=ec._a] run effect give @s health_boost 5 1 true
tag @s remove ec._a

# Warden Ring — Strength II + Darkness Immunity (Exquisite)
# OPT: Tag consolidation (was 4 item scans → 2)
execute if items entity @s container.* *[custom_data~{artifact:"ring_warden"}] run tag @s add ec._a
execute unless items entity @s container.* *[custom_data~{artifact:"ring_warden"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"ring_warden"}] if entity @s[tag=ec.sat_ring_warden] run tag @s add ec._a
execute unless entity @s[tag=ec._a] if items entity @s weapon.offhand *[custom_data~{artifact:"ring_warden"}] run tag @s add ec._a
execute if entity @s[tag=ec._a] if score @s ec.h_str matches ..1 run effect give @s strength 5 1 true
execute if entity @s[tag=ec._a] run effect clear @s darkness
tag @s remove ec._a

# Void Ring — Resistance II + Fire Resistance + Slow Falling (Mythical)
# OPT: Tag consolidation (was 6 item scans → 2)
execute if items entity @s container.* *[custom_data~{artifact:"ring_void"}] run tag @s add ec._a
execute unless items entity @s container.* *[custom_data~{artifact:"ring_void"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"ring_void"}] if entity @s[tag=ec.sat_ring_void] run tag @s add ec._a
execute unless entity @s[tag=ec._a] if items entity @s weapon.offhand *[custom_data~{artifact:"ring_void"}] run tag @s add ec._a
execute if entity @s[tag=ec._a] if score @s ec.h_resist matches ..1 run effect give @s resistance 5 1 true
execute if entity @s[tag=ec._a] run effect give @s fire_resistance 5 0 true
execute if entity @s[tag=ec._a] run effect give @s slow_falling 5 0 true
tag @s remove ec._a

# Copper Ring — Conduit Power (Uncommon) [art-E NEW leaf; backfills the frozen 5/5/5 sub-band shape —
# NOT in a band recipe (bands frozen at 15), ships as a standalone held effect-tier ring per the ring
# idiom] # OPT: Tag consolidation
execute if items entity @s container.* *[custom_data~{artifact:"ring_copper"}] run tag @s add ec._a
execute unless items entity @s container.* *[custom_data~{artifact:"ring_copper"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"ring_copper"}] if entity @s[tag=ec.sat_ring_copper] run tag @s add ec._a
execute unless entity @s[tag=ec._a] if items entity @s weapon.offhand *[custom_data~{artifact:"ring_copper"}] run tag @s add ec._a
execute if entity @s[tag=ec._a] run effect give @s conduit_power 5 0 false
tag @s remove ec._a

# Quartz Ring — Regeneration (Exquisite) [art-E NEW leaf; potent-tier backfill of the frozen 5/5/5
# shape — standalone held ring, not a band ingredient]. Gated by the harmonize regen ceiling
# (ec.h_regen) + the regen_capped fallback (Heartstone/Healer's-Salve idiom) so it never over-stacks
# a stronger regen source. # OPT: Tag consolidation
execute if items entity @s container.* *[custom_data~{artifact:"ring_quartz"}] run tag @s add ec._a
execute unless items entity @s container.* *[custom_data~{artifact:"ring_quartz"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"ring_quartz"}] if entity @s[tag=ec.sat_ring_quartz] run tag @s add ec._a
execute unless entity @s[tag=ec._a] if items entity @s weapon.offhand *[custom_data~{artifact:"ring_quartz"}] run tag @s add ec._a
execute if entity @s[tag=ec._a] if score @s ec.h_regen matches ..1 unless entity @s[tag=ec.regen_capped] run effect give @s regeneration 5 0 true
execute if entity @s[tag=ec._a] if score @s ec.h_regen matches ..1 if entity @s[tag=ec.regen_capped] run function evercraft:artifacts/accessories/regen_fallback
tag @s remove ec._a

# --- Ladle (common, LOW-PRI twist) — Soft-Soil Shuffle: Speed I while standing on tilled/soft ground. ---
# Held-mainhand passive (a shovel, so it lives here not in worn_tick). Distinct tiny identity for a
# common starter tool: faster on farmland and the dirt/sand/soul-soil family it's made to dig.
execute if items entity @s weapon.mainhand *[custom_data~{artifact:"common_ladle"}] if block ~ ~-1 ~ farmland run effect give @s speed 3 0 true
execute if items entity @s weapon.mainhand *[custom_data~{artifact:"common_ladle"}] if block ~ ~-1 ~ #minecraft:dirt run effect give @s speed 3 0 true
execute if items entity @s weapon.mainhand *[custom_data~{artifact:"common_ladle"}] if block ~ ~-1 ~ soul_soil run effect give @s speed 3 0 true

# --- Truthseeker (exquisite) — "nearby invisible mobs glow" passive. PERF-GATED HARD: the expensive
# NBT-filtered selector (active_effects invisibility) runs ONLY when truthseeker is actually held in
# mainhand AND a cheap presence check finds any hostile within range first. The cheap gate (held + one
# hostile in 16b, limit=1) short-circuits for the common case (no truthseeker / no mobs nearby) so the
# deep NBT scan never runs on an empty area. Glowing 2s self-refreshes each 1s tick. ---
execute if items entity @s weapon.mainhand *[custom_data~{artifact:"truthseeker"}] at @s if entity @e[type=#evercraft:hostile_mobs,distance=..16,limit=1] run effect give @e[type=#evercraft:hostile_mobs,distance=..16,nbt={active_effects:[{id:"minecraft:invisibility"}]}] glowing 2 0 true

# ============================================================
# === MOB VISION ACTIVATION (Sneak + Mainhand) ===
# ============================================================

# Seer's Compass — sneak + mainhand to reveal hostile mobs (16 blocks, 10s, 30s cd)
execute if predicate evercraft:sneaking if items entity @s weapon.mainhand *[custom_data~{artifact:"seers_compass"}] run function evercraft:artifacts/accessories/activate_seers

# Warden's Echo — sneak + mainhand to sense all mobs (24 blocks, 10s, 30s cd)
execute if predicate evercraft:sneaking if items entity @s weapon.mainhand *[custom_data~{artifact:"wardens_echo"}] run function evercraft:artifacts/accessories/activate_warden_echo

# Claude's Eye — sneak + mainhand for omniscience (32 blocks, 15s, 45s cd)
execute if predicate evercraft:sneaking if items entity @s weapon.mainhand *[custom_data~{artifact:"claudes_eye"}] run function evercraft:artifacts/accessories/activate_claudes_eye

# Warden Totem — sneak + mainhand for sculk sense (48 blocks, 15s, 45s cd)
execute if predicate evercraft:sneaking if items entity @s weapon.mainhand *[custom_data~{artifact:"warden_totem"}] run function evercraft:artifacts/accessories/activate_warden_totem

# Codex of Everything — sneak + mainhand shows dimension teleport menu
execute if predicate evercraft:sneaking if items entity @s weapon.mainhand *[custom_data~{artifact:"codex_of_everything"}] run function evercraft:artifacts/accessories/activate_codex

# ============================================================
# === WAYFARER SNEAK-TRIGGERED SURVEY / CYCLE (Family C, art-C) ===
# ============================================================
# Sneak + mainhand to activate, matching the Seer/Warden/Codex on-demand idiom (deliberate: hold the
# item in hand + sneak so a buried-in-inventory readout never fires by accident). Each handler is
# bounded (data read / locate / lazy-eval cycle) + self-debounced by its own cooldown. NO scan, NO
# block-glow; the survey ping uses vanilla `locate structure` + a <=12-particle burst (<=36 budget).
#
# U7 Wanderer's Whetcompass — bearing + distance to respawn point.
execute if predicate evercraft:sneaking if items entity @s weapon.mainhand *[custom_data~{artifact:"wanderers_whetcompass"}] run function evercraft:artifacts/accessories/wayfarer/bed_bearing
# Cartographer's Lens — Trailblazer's Mark home-bearing ping ("points you home"). Sneak + hold in hand to
# read the 8-point bearing + distance to your respawn point (reuses the wayfarer bed_bearing readout; it
# self-handles the no-respawn case). The sprint-Speed + trail half is passive in the ec._a block above.
execute if predicate evercraft:sneaking if items entity @s weapon.mainhand *[custom_data~{artifact:"cartographers_lens"}] run function evercraft:artifacts/accessories/wayfarer/bed_bearing
# U17 Wayfarer's Sextant — cycle home-bearing / biome / day-night clock.
execute if predicate evercraft:sneaking if items entity @s weapon.mainhand *[custom_data~{artifact:"wayfarers_sextant"}] run function evercraft:artifacts/accessories/wayfarer/sextant_cycle
# U23 Voyager's Far-Lens — sneak survey ping (nearest-structure bearing; waypoint range is passive above).
execute if predicate evercraft:sneaking if items entity @s weapon.mainhand *[custom_data~{artifact:"voyagers_far_lens"}] run function evercraft:artifacts/accessories/wayfarer/structure_ping
# U24 Loremaster's Omni-Codex — cycle coords / depth / bearing / biome / Dream Rate (lazy-eval).
execute if predicate evercraft:sneaking if items entity @s weapon.mainhand *[custom_data~{artifact:"loremasters_omni_codex"}] run function evercraft:artifacts/accessories/wayfarer/codex_cycle
# #5 Cartographer's Astrolabe — sneak survey ping (Surveyor's Kit head; coord readout is passive above).
execute if predicate evercraft:sneaking if items entity @s weapon.mainhand *[custom_data~{artifact:"cartographers_astrolabe"}] run function evercraft:artifacts/accessories/wayfarer/structure_ping
# ------------------------------------------------------------
# WAYFARER'S LENS tree sneak-triggered halves (cap-C) — the capstone nodes re-grant the ON-DEMAND
# survey/mob-vision halves of their absorbed members via the SAME dispatch fns (the on-demand idiom).
# Each is `if predicate sneaking if items weapon.mainhand` — hold the node in hand + sneak. The grand
# Wayfarer's Lens grants PASSIVE max-range mob-vision in its apply (always-on glowing), so it needs NO
# sneak mob-vision gate — only the survey/cycle gates below. The Far Sight Lens + Oracle Lens get the
# sneak mob-vision (the wider Warden's Echo 24 b all-mob reveal = "max sense range" for the bundle).
# Far Sight Lens — sneak mob-vision (absorbed Seer's Compass + Warden's Echo -> the wider Warden reveal).
execute if predicate evercraft:sneaking if items entity @s weapon.mainhand *[custom_data~{far_sight_lens:true}] run function evercraft:artifacts/accessories/activate_warden_echo
# Oracle Lens — sneak mob-vision (absorbed the sense ladder incl. Seer + Warden -> the wider reveal).
execute if predicate evercraft:sneaking if items entity @s weapon.mainhand *[custom_data~{oracle_lens:true}] run function evercraft:artifacts/accessories/activate_warden_echo
# Surveyor's Kit — sneak survey: the locate-structure ping (Far-Lens/Astrolabe) + the 5-way readout
# cycle (Omni-Codex coords/depth/bearing/biome/DR). Both fire on one press (different cooldown lanes).
execute if predicate evercraft:sneaking if items entity @s weapon.mainhand *[custom_data~{surveyors_kit:true}] run function evercraft:artifacts/accessories/wayfarer/structure_ping
execute if predicate evercraft:sneaking if items entity @s weapon.mainhand *[custom_data~{surveyors_kit:true}] run function evercraft:artifacts/accessories/wayfarer/codex_cycle
# Wayfarer's Lens (grand) — sneak survey: the locate ping + the full readout cycle (passive mob-vision
# is in the apply, so no mob-vision gate here). Every survey/cycle perk the bundle absorbs, on demand.
execute if predicate evercraft:sneaking if items entity @s weapon.mainhand *[custom_data~{wayfarers_lens:true}] run function evercraft:artifacts/accessories/wayfarer/structure_ping
execute if predicate evercraft:sneaking if items entity @s weapon.mainhand *[custom_data~{wayfarers_lens:true}] run function evercraft:artifacts/accessories/wayfarer/codex_cycle
# ------------------------------------------------------------
# U16 Steady-Hand Caliper (art-F -> K Surveyor) — sneak + mainhand-hold renders a faint placement-ghost
# outline at the targeted cell (bounded ray, ≤12 dust particles, force @s, no block-glow). On-demand.
execute if predicate evercraft:sneaking if items entity @s weapon.mainhand *[custom_data~{artifact:"steady_hand_caliper"}] run function evercraft:artifacts/accessories/wayfarer/caliper_ghost

# ============================================================
# === FAMILY K — PROSPECTOR SNEAK-TRIGGERED SURVEY / GATHERING QoL (art-K) ===
# ============================================================
# Sneak + mainhand-hold to activate (the same on-demand idiom as the Wayfarer survey items — hold in
# hand + sneak so a buried-in-inventory readout never fires by accident). Each handler is BOUNDED per
# UTILITY-FEASIBILITY's hard rule: action-bar readouts (U6), 6-12 bounded RAYS to the nearest air gap
# (U10 — no block-glow), a small sample+ping (U13), `locate structure` ping + a tiny local cavity ray
# (U19 — no wall-outline), and a stackable-materials-only sort pulse (U21). NO O(r^3) volume scan, NO
# block-glow (blocks can't glow — particles/sound only). Each is self-debounced by its own cooldown.
# C7 Wayfinder's Dowsing Rod also exposes a sneak node-ping here (its passive +50% despawn lives in
# nodes/check_despawn).
#
# U6 Plumb-Bob Token — action-bar depth gauge (blocks-to-bedrock) + "cave below" air-pocket hint.
execute if predicate evercraft:sneaking if items entity @s weapon.mainhand *[custom_data~{artifact:"plumb_bob_token"}] run function evercraft:artifacts/accessories/prospector/plumb_depth
# U10 Echolocator Shard — 8-ray echo pulse toward the nearest large air cavity (≤24 b), particle ping.
execute if predicate evercraft:sneaking if items entity @s weapon.mainhand *[custom_data~{artifact:"echolocator_shard"}] run function evercraft:artifacts/accessories/prospector/echo_pulse
# U13 Quartzlight Loupe — sample nearby stone for ore, directional ping toward the nearest buried ore.
execute if predicate evercraft:sneaking if items entity @s weapon.mainhand *[custom_data~{artifact:"quartzlight_loupe"}] run function evercraft:artifacts/accessories/prospector/loupe_sample
# U19 Spelunker's Resonator — `locate structure` long-range bearing ping + a tiny local cavity ray.
execute if predicate evercraft:sneaking if items entity @s weapon.mainhand *[custom_data~{artifact:"spelunkers_resonator"}] run function evercraft:artifacts/accessories/prospector/resonator_ping
# C7 Wayfinder's Dowsing Rod — sneak node-ping (faint particle toward nearest craft-node ≤100 b).
execute if predicate evercraft:sneaking if items entity @s weapon.mainhand *[custom_data~{artifact:"wayfinders_dowsing_rod"}] run function evercraft:artifacts/accessories/prospector/dowsing_ping
# U21 Loadmaster's Sortstone — sneak tidy pulse: merge partial stacks of stackable materials only.
execute if predicate evercraft:sneaking if items entity @s weapon.mainhand *[custom_data~{artifact:"loadmasters_sortstone"}] run function evercraft:artifacts/accessories/prospector/sort_pulse
#
# cap-K — the Surveyor Line sub-cap + the Demiurge's Spirit Artifact consolidate the WHOLE sneak-survey
# kit (Plumb-Bob depth, Echolocator cavity, Resonator locate, Sortstone collapse — Surveyor's four) +
# (the grand also folds the Deepdig Quartzlight ore sample + the Node Mastery Dowsing node-ping). Sneak +
# hold the NODE in mainhand to fire the consolidated kit (the same on-demand idiom). Each handler is the
# SAME bounded read-only ping the loose leaf calls — re-running them under the node is idempotent (the
# Sortstone collapse is self-debounced by ec.pr_pingcd, like the loose). The loose survey leaves are
# absorbed into the node, so this restores the surveys to a node holder who no longer carries them. No
# double-fire risk: a node holder does NOT carry the loose survey items (they were consumed in the fusion).
# Surveyor Line (or grand) in mainhand -> the four survey pings.
execute if predicate evercraft:sneaking if items entity @s weapon.mainhand *[custom_data~{surveyor_line:true}] run function evercraft:artifacts/accessories/prospector/plumb_depth
execute if predicate evercraft:sneaking if items entity @s weapon.mainhand *[custom_data~{surveyor_line:true}] run function evercraft:artifacts/accessories/prospector/echo_pulse
execute if predicate evercraft:sneaking if items entity @s weapon.mainhand *[custom_data~{surveyor_line:true}] run function evercraft:artifacts/accessories/prospector/resonator_ping
execute if predicate evercraft:sneaking if items entity @s weapon.mainhand *[custom_data~{surveyor_line:true}] run function evercraft:artifacts/accessories/prospector/sort_pulse
# Deepdig Line in mainhand -> the Quartzlight Loupe ore sample.
execute if predicate evercraft:sneaking if items entity @s weapon.mainhand *[custom_data~{deepdig_line:true}] run function evercraft:artifacts/accessories/prospector/loupe_sample
# Node Mastery in mainhand -> the Dowsing node-ping.
execute if predicate evercraft:sneaking if items entity @s weapon.mainhand *[custom_data~{node_mastery:true}] run function evercraft:artifacts/accessories/prospector/dowsing_ping
# The Demiurge's Spirit Artifact in mainhand -> the FULL consolidated survey kit (all six).
execute if predicate evercraft:sneaking if items entity @s weapon.mainhand *[custom_data~{demiurges_capstone:true}] run function evercraft:artifacts/accessories/prospector/plumb_depth
execute if predicate evercraft:sneaking if items entity @s weapon.mainhand *[custom_data~{demiurges_capstone:true}] run function evercraft:artifacts/accessories/prospector/echo_pulse
execute if predicate evercraft:sneaking if items entity @s weapon.mainhand *[custom_data~{demiurges_capstone:true}] run function evercraft:artifacts/accessories/prospector/loupe_sample
execute if predicate evercraft:sneaking if items entity @s weapon.mainhand *[custom_data~{demiurges_capstone:true}] run function evercraft:artifacts/accessories/prospector/resonator_ping
execute if predicate evercraft:sneaking if items entity @s weapon.mainhand *[custom_data~{demiurges_capstone:true}] run function evercraft:artifacts/accessories/prospector/dowsing_ping
execute if predicate evercraft:sneaking if items entity @s weapon.mainhand *[custom_data~{demiurges_capstone:true}] run function evercraft:artifacts/accessories/prospector/sort_pulse

# ============================================================
# === GEARWRIGHT SYSTEM ACCESSORIES (Chest-Node §6 / §14.2) ===
# ============================================================
# Four read-only boolean flags the chest engine SUMS with the matching Gearwright perk (one-writer
# = THIS block; the chest engine only ever READS them `matches 1`). Each flag is set if the player
# holds the matching system accessory (container.* OR offhand) OR the combined Tinker's Omnitool
# (which sets ALL four). Clear-then-set re-sum (same idiom as the ec.acc_dodge lane above): zero all
# four first, then add presence. Because this runs past the ec.has_accessory early-exit, a player
# holding ONLY non-system accessories correctly lands all four at 0. A player who drops their last
# accessory runs this once more with nothing to set (lands at 0), then early-exits with it 0.
#   crate_luck_charm  -> ec.acc_cratepct  (do_open_success += #caff_gw_crateodds)
#   prospectors_dowser-> ec.acc_spawn     (check_spawn raises the gate / reset_timer shortens timer)
#   master_key_fob    -> ec.acc_openpct   (keyless_gate += #caff_gw_openpct, clamped <=95)
#   pocket_ender_anchor-> ec.acc_ender    (shift-RC places the temp ender_chest)
# The Omnitool's per-ability counters {crate_lvl,spawn_lvl,open_lvl,ender_lvl} (capped 3) are a
# re-stack/progression record bumped by the consume-merge handler; the deeper magnitude is conferred
# via ec.gw_sigtier (read by read_sig_tier — the spirit-item tier-7 row), NOT a per-flag scalar here.
scoreboard players set @s ec.acc_cratepct 0
scoreboard players set @s ec.acc_spawn 0
scoreboard players set @s ec.acc_openpct 0
scoreboard players set @s ec.acc_ender 0
# --- crate_luck_charm -> ec.acc_cratepct ---
execute if items entity @s container.* *[custom_data~{artifact:"crate_luck_charm"}] run scoreboard players set @s ec.acc_cratepct 1
execute unless items entity @s container.* *[custom_data~{artifact:"crate_luck_charm"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"crate_luck_charm"}] if entity @s[tag=ec.sat_crate_luck_charm] run scoreboard players set @s ec.acc_cratepct 1
execute unless score @s ec.acc_cratepct matches 1 if items entity @s weapon.offhand *[custom_data~{artifact:"crate_luck_charm"}] run scoreboard players set @s ec.acc_cratepct 1
# --- prospectors_dowser -> ec.acc_spawn ---
execute if items entity @s container.* *[custom_data~{artifact:"prospectors_dowser"}] run scoreboard players set @s ec.acc_spawn 1
execute unless items entity @s container.* *[custom_data~{artifact:"prospectors_dowser"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"prospectors_dowser"}] if entity @s[tag=ec.sat_prospectors_dowser] run scoreboard players set @s ec.acc_spawn 1
execute unless score @s ec.acc_spawn matches 1 if items entity @s weapon.offhand *[custom_data~{artifact:"prospectors_dowser"}] run scoreboard players set @s ec.acc_spawn 1
# --- master_key_fob -> ec.acc_openpct ---
execute if items entity @s container.* *[custom_data~{artifact:"master_key_fob"}] run scoreboard players set @s ec.acc_openpct 1
execute unless items entity @s container.* *[custom_data~{artifact:"master_key_fob"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"master_key_fob"}] if entity @s[tag=ec.sat_master_key_fob] run scoreboard players set @s ec.acc_openpct 1
execute unless score @s ec.acc_openpct matches 1 if items entity @s weapon.offhand *[custom_data~{artifact:"master_key_fob"}] run scoreboard players set @s ec.acc_openpct 1
# --- pocket_ender_anchor -> ec.acc_ender ---
execute if items entity @s container.* *[custom_data~{artifact:"pocket_ender_anchor"}] run scoreboard players set @s ec.acc_ender 1
execute unless items entity @s container.* *[custom_data~{artifact:"pocket_ender_anchor"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"pocket_ender_anchor"}] if entity @s[tag=ec.sat_pocket_ender_anchor] run scoreboard players set @s ec.acc_ender 1
execute unless score @s ec.acc_ender matches 1 if items entity @s weapon.offhand *[custom_data~{artifact:"pocket_ender_anchor"}] run scoreboard players set @s ec.acc_ender 1
# --- tinkers_omnitool -> ALL FOUR flags (the combined spirit-item, A2/§6) ---
execute if items entity @s container.* *[custom_data~{artifact:"tinkers_omnitool"}] run function evercraft:artifacts/accessories/omnitool_apply
execute unless items entity @s container.* *[custom_data~{artifact:"tinkers_omnitool"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"tinkers_omnitool"}] if entity @s[tag=ec.sat_tinkers_omnitool] run function evercraft:artifacts/accessories/omnitool_apply
execute unless score @s ec.acc_ender matches 1 if items entity @s weapon.offhand *[custom_data~{artifact:"tinkers_omnitool"}] run function evercraft:artifacts/accessories/omnitool_apply

# ============================================================
# === CLEANUP ===
# ============================================================
tag @s remove ec.regen_capped
function evercraft:artifacts/abilities/accessory_cleanup

# Update tracking flag based on current inventory state
tag @s remove ec.has_accessory
execute if items entity @s container.* *[custom_data~{accessory:true}] run tag @s add ec.has_accessory
execute unless entity @s[tag=ec.has_accessory] if items entity @s weapon.offhand *[custom_data~{accessory:true}] run tag @s add ec.has_accessory
execute unless entity @s[tag=ec.has_accessory] if items entity @s container.* *[custom_data~{ring:true}] run tag @s add ec.has_accessory
execute unless entity @s[tag=ec.has_accessory] if items entity @s weapon.offhand *[custom_data~{ring:true}] run tag @s add ec.has_accessory
execute unless entity @s[tag=ec.has_accessory] if items entity @s container.* *[custom_data~{boss_exclusive:true}] run tag @s add ec.has_accessory
execute unless entity @s[tag=ec.has_accessory] if items entity @s weapon.offhand *[custom_data~{boss_exclusive:true}] run tag @s add ec.has_accessory
# (2026-06-06) The worn-armor armor-tag line + the worn_tick_player dispatch were MOVED OUT of player_tick
# into accessories/tick's own armor-gated @a scan (ec.has_worn_armor keep-alive). Worn-armor abilities and
# their 1-extra-tick attribute cleanup now live entirely in worn_tick_player, reached only from that tick.
