# Wayfarer — Wayfarer's Sextant sneak-cycle dispatch (U17)
# Run as @s = player, at @s. Sneak-triggered (the sneak+hold gate lives at the call site). A held
# sneak debounces via ec.wf_cyccd (16t) so one press = one advance. Cycles ec.wf_scyc through
# 1..3 = home-bearing / biome / day-night clock, and runs ONLY the active readout (lazy-eval — never
# computes all three per pulse). Each sub-readout is itself bounded/cheap. No scan, no particles.
execute if score @s ec.wf_cyccd matches 1.. run return 0
scoreboard players set @s ec.wf_cyccd 16
# Advance 1..3 (wrap).
scoreboard players add @s ec.wf_scyc 1
execute unless score @s ec.wf_scyc matches 1..3 run scoreboard players set @s ec.wf_scyc 1
# Run only the active readout.
execute if score @s ec.wf_scyc matches 1 run function evercraft:artifacts/accessories/wayfarer/bed_bearing
execute if score @s ec.wf_scyc matches 2 run function evercraft:artifacts/accessories/wayfarer/biome_readout
execute if score @s ec.wf_scyc matches 3 run function evercraft:artifacts/accessories/wayfarer/clock_readout
