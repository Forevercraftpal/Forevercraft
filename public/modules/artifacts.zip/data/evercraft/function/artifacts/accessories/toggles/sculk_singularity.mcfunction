# Sculk Singularity — Toggle the Gravity Well pull (the ring_of_undying toggle idiom).
# 0 = ON (default, mobs are pulled in), 1 = OFF (pull suspended; the Singularity Shield stays active).

execute unless score @s ec.t_singularity matches 0..1 run scoreboard players set @s ec.t_singularity 0

# Flip the toggle
scoreboard players operation #temp ec.t_singularity = @s ec.t_singularity
execute if score #temp ec.t_singularity matches 0 run scoreboard players set @s ec.t_singularity 1
execute if score #temp ec.t_singularity matches 1 run scoreboard players set @s ec.t_singularity 0

# Feedback
data modify storage evercraft:notify stage.c set value [{text:"Gravity Well: ",color:"gray"},{text:"ENABLED",color:"green",bold:true}]
scoreboard players set #ndur ec.temp 45
execute if score @s ec.t_singularity matches 0 run function evercraft:util/notify/emit
execute if score @s ec.t_singularity matches 0 if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.chime master @s ~ ~ ~ 1 1.5
data modify storage evercraft:notify stage.c set value [{text:"Gravity Well: ",color:"gray"},{text:"DISABLED",color:"red",bold:true}]
scoreboard players set #ndur ec.temp 45
execute if score @s ec.t_singularity matches 1 run function evercraft:util/notify/emit
execute if score @s ec.t_singularity matches 1 if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.chime master @s ~ ~ ~ 1 0.5
