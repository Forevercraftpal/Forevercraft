# Iai Draw — Cancel charging (stopped sneaking or weapon changed)
# OPT: Consolidates 2 operations (tag remove + score reset) into 1 function
tag @s remove ec.iai_charging
scoreboard players set @s ec.iai_charge 0
