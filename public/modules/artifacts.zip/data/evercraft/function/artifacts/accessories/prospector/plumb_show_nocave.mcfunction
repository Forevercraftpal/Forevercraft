# U6 Plumb-Bob Token — readout (no cave below). MACRO. Call:
#   function evercraft:artifacts/accessories/prospector/plumb_show_nocave with storage evercraft:pr_temp
#   $(depth) = blocks-to-bedrock-floor (Pos[1] + 64).
$execute unless entity @s[tag=ab_q] run title @s actionbar [{text:"⊻ ",color:"blue"},{text:"Depth: ",color:"#9AB8E0"},{text:"$(depth) to the floor",color:"white"},{text:"  •  no cave below",color:"dark_gray"}]
