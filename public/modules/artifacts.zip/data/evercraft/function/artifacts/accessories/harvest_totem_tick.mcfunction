# Harvest Totem (#4, Family J — art-J) — Crop-growth tick (the agriculture head)
# Run as @s = player, at @s (positioned by the caller in player_tick). The agriculture capstone-seed
# (BLUEPRINT §C #4): a STRONGER crop-growth pulse than Farmer's Almanac (which is ~5%/sec), so the
# Totem is the farming HEAD of the Harvest Knot line, not a copy of the Almanac. ~15%/sec chance to
# bone-meal a random nearby crop, reusing the Almanac's proven try_bone_meal dispatch (9x3x9 scan,
# per-player pid isolation). The two stack additively if a player holds both (farming build payoff).
# DR=0 (no luck modifier). id-presence single-scan into ec._a handled by the caller (one item scan).

execute store result score @s ec.artifact_roll run random value 1..20
execute if score @s ec.artifact_roll matches 1..3 positioned ~-4 ~-1 ~-4 run function evercraft:artifacts/accessories/try_bone_meal
