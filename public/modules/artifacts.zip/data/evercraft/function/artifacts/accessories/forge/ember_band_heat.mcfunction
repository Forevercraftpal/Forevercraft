# === EMBER-FORGED BAND (B8) — NEAR-HEAT DETECTOR (Family G, art-G) ===
# Run as @s = player, at @s. Caller (player_tick) gates this on the band being held (the ec._a
# scan) so non-holders never reach here. Sets #g_heat ec.temp = 1 if a heat source sits within a
# tight 3x3x3 cube around the player (forge/lava/fire/campfire/magma OR a lit furnace family block),
# else leaves it 0 (caller zeroes it before this call). Short-circuits via `return run` on the first
# match (the cooking/check_campfire idiom). 27 always-hot checks (#evercraft:heat_sources block tag)
# + 27 lit-furnace-family checks, all guarded by the held gate so the cost is paid only by a band
# holder. The band's +1 Armor + 8% break-speed are added/removed by the caller off #g_heat.

# --- Always-hot blocks via the #evercraft:heat_sources tag (lava/fire/soul_fire/magma/campfires) ---
# Y = -1 (heat below — forge floor / lava / campfire on the ground)
execute if block ~ ~-1 ~ #evercraft:heat_sources run return run scoreboard players set #g_heat ec.temp 1
execute if block ~1 ~-1 ~ #evercraft:heat_sources run return run scoreboard players set #g_heat ec.temp 1
execute if block ~-1 ~-1 ~ #evercraft:heat_sources run return run scoreboard players set #g_heat ec.temp 1
execute if block ~ ~-1 ~1 #evercraft:heat_sources run return run scoreboard players set #g_heat ec.temp 1
execute if block ~ ~-1 ~-1 #evercraft:heat_sources run return run scoreboard players set #g_heat ec.temp 1
execute if block ~1 ~-1 ~1 #evercraft:heat_sources run return run scoreboard players set #g_heat ec.temp 1
execute if block ~1 ~-1 ~-1 #evercraft:heat_sources run return run scoreboard players set #g_heat ec.temp 1
execute if block ~-1 ~-1 ~1 #evercraft:heat_sources run return run scoreboard players set #g_heat ec.temp 1
execute if block ~-1 ~-1 ~-1 #evercraft:heat_sources run return run scoreboard players set #g_heat ec.temp 1
# Y = 0 (heat at feet level)
execute if block ~ ~ ~ #evercraft:heat_sources run return run scoreboard players set #g_heat ec.temp 1
execute if block ~1 ~ ~ #evercraft:heat_sources run return run scoreboard players set #g_heat ec.temp 1
execute if block ~-1 ~ ~ #evercraft:heat_sources run return run scoreboard players set #g_heat ec.temp 1
execute if block ~ ~ ~1 #evercraft:heat_sources run return run scoreboard players set #g_heat ec.temp 1
execute if block ~ ~ ~-1 #evercraft:heat_sources run return run scoreboard players set #g_heat ec.temp 1
execute if block ~1 ~ ~1 #evercraft:heat_sources run return run scoreboard players set #g_heat ec.temp 1
execute if block ~1 ~ ~-1 #evercraft:heat_sources run return run scoreboard players set #g_heat ec.temp 1
execute if block ~-1 ~ ~1 #evercraft:heat_sources run return run scoreboard players set #g_heat ec.temp 1
execute if block ~-1 ~ ~-1 #evercraft:heat_sources run return run scoreboard players set #g_heat ec.temp 1
# Y = +1 (heat on a bench/anvil-height above the floor)
execute if block ~ ~1 ~ #evercraft:heat_sources run return run scoreboard players set #g_heat ec.temp 1
execute if block ~1 ~1 ~ #evercraft:heat_sources run return run scoreboard players set #g_heat ec.temp 1
execute if block ~-1 ~1 ~ #evercraft:heat_sources run return run scoreboard players set #g_heat ec.temp 1
execute if block ~ ~1 ~1 #evercraft:heat_sources run return run scoreboard players set #g_heat ec.temp 1
execute if block ~ ~1 ~-1 #evercraft:heat_sources run return run scoreboard players set #g_heat ec.temp 1
execute if block ~1 ~1 ~1 #evercraft:heat_sources run return run scoreboard players set #g_heat ec.temp 1
execute if block ~1 ~1 ~-1 #evercraft:heat_sources run return run scoreboard players set #g_heat ec.temp 1
execute if block ~-1 ~1 ~1 #evercraft:heat_sources run return run scoreboard players set #g_heat ec.temp 1
execute if block ~-1 ~1 ~-1 #evercraft:heat_sources run return run scoreboard players set #g_heat ec.temp 1

# --- Lit furnace family (forge proper) — checked separately because a block tag cannot carry the
# [lit=true] state. furnace[lit=true] is the confirmed idiom (advantage/blacksmith/try_boost). We
# check all three smelting blocks at the player cube's centre column + the 4 cardinals at feet level
# (a smith stands beside a lit forge), short-circuiting on the first lit block. ---
execute if block ~ ~ ~ minecraft:furnace[lit=true] run return run scoreboard players set #g_heat ec.temp 1
execute if block ~1 ~ ~ minecraft:furnace[lit=true] run return run scoreboard players set #g_heat ec.temp 1
execute if block ~-1 ~ ~ minecraft:furnace[lit=true] run return run scoreboard players set #g_heat ec.temp 1
execute if block ~ ~ ~1 minecraft:furnace[lit=true] run return run scoreboard players set #g_heat ec.temp 1
execute if block ~ ~ ~-1 minecraft:furnace[lit=true] run return run scoreboard players set #g_heat ec.temp 1
execute if block ~ ~ ~ minecraft:blast_furnace[lit=true] run return run scoreboard players set #g_heat ec.temp 1
execute if block ~1 ~ ~ minecraft:blast_furnace[lit=true] run return run scoreboard players set #g_heat ec.temp 1
execute if block ~-1 ~ ~ minecraft:blast_furnace[lit=true] run return run scoreboard players set #g_heat ec.temp 1
execute if block ~ ~ ~1 minecraft:blast_furnace[lit=true] run return run scoreboard players set #g_heat ec.temp 1
execute if block ~ ~ ~-1 minecraft:blast_furnace[lit=true] run return run scoreboard players set #g_heat ec.temp 1
execute if block ~ ~ ~ minecraft:smoker[lit=true] run return run scoreboard players set #g_heat ec.temp 1
execute if block ~1 ~ ~ minecraft:smoker[lit=true] run return run scoreboard players set #g_heat ec.temp 1
execute if block ~-1 ~ ~ minecraft:smoker[lit=true] run return run scoreboard players set #g_heat ec.temp 1
execute if block ~ ~ ~1 minecraft:smoker[lit=true] run return run scoreboard players set #g_heat ec.temp 1
execute if block ~ ~ ~-1 minecraft:smoker[lit=true] run return run scoreboard players set #g_heat ec.temp 1
