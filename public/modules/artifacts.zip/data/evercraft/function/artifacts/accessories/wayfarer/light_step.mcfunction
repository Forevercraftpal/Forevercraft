# Wayfarer — Lantern-Lichen Clasp local light (U5)
# Run as @s = player, at @s. Called from player_tick ONLY when the player holds the item (the
# item-gate lives at the call site). Casts a real, transient light[level=10] block at the player's
# foot cell and CLEANS the previous cell every time the player moves to a new block — strict single-
# prev-cell tracking (UTILITY-FEASIBILITY mandate: "must clean the old light block every move or you
# litter the world"). light[level=N] is the PROVEN transient-light idiom (blueprints/trials). NOT a
# scan, NOT a particle; one setblock + one macro setblock-air per move. The prev cell is stored in
# ec.wf_plx/ply/plz and ec.wf_lhas marks whether we actually own a light block there.

# Read the current foot-block cell into scores (truncated integer = the block we stand in).
execute store result score @s ec.wf_lx run data get entity @s Pos[0] 1
execute store result score @s ec.wf_ly run data get entity @s Pos[1] 1
execute store result score @s ec.wf_lz run data get entity @s Pos[2] 1

# Have we moved to a NEW block since last placement? Compare to the stored prev cell.
scoreboard players set @s ec.wf_lmoved 0
execute unless score @s ec.wf_lx = @s ec.wf_plx run scoreboard players set @s ec.wf_lmoved 1
execute unless score @s ec.wf_ly = @s ec.wf_ply run scoreboard players set @s ec.wf_lmoved 1
execute unless score @s ec.wf_lz = @s ec.wf_plz run scoreboard players set @s ec.wf_lmoved 1

# If we have NOT moved and we still own a light at the current cell, nothing to do (idle, cheapest).
execute if score @s ec.wf_lmoved matches 0 if score @s ec.wf_lhas matches 1 if block ~ ~ ~ minecraft:light[level=10] run return 0

# On a move (or first hold / post-reload re-place): clean the OLD cell first — but ONLY if we own a
# light block there (ec.wf_lhas==1), so we never stomp a real block a player built since. The clean
# is a coord-pinned macro positioned at the stored prev cell.
execute if score @s ec.wf_lmoved matches 1 if score @s ec.wf_lhas matches 1 run function evercraft:artifacts/accessories/wayfarer/light_clean_dispatch

# Store the new cell as the prev cell.
scoreboard players operation @s ec.wf_plx = @s ec.wf_lx
scoreboard players operation @s ec.wf_ply = @s ec.wf_ly
scoreboard players operation @s ec.wf_plz = @s ec.wf_lz

# Place a new light ONLY into air / replaceable plant cells — never overwrite a solid block.
scoreboard players set @s ec.wf_lhas 0
execute if block ~ ~ ~ #minecraft:replaceable run setblock ~ ~ ~ minecraft:light[level=10] replace
execute if block ~ ~ ~ minecraft:light[level=10] run scoreboard players set @s ec.wf_lhas 1
