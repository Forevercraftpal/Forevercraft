# Iai Draw — Cancel stance (weapon changed)
# OPT: Consolidates 2 @a scans into 1 function call
tag @s remove ec.iai_ready
tag @s remove ec.iai_fired
