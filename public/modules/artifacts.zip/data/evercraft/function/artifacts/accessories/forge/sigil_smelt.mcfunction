# === SMELTER'S SIGIL (C13) — PER-BREAK ACCESSORY AUTO-SMELT (Family G, art-G) ===
# Run as @s = player, at @s. Called from craft_affinity/detect_ordinary_tool ON a mining-delta
# event (already break-gated) when the player holds the Smelter's Sigil accessory + a pickaxe.
# Charge-FREE + no tick-loop scan: it rides the break event and transforms the raw ore that just
# dropped at the player's position to its smelted output. Reuses the proven per-item transform
# (craft_affinity/abilities/ss_smelt_one) which rewrites Item.id in-place (count-preserving ->
# Fortune respected) + spawns approximate furnace XP + tiny VFX. ss_smelt_one's charge-decrement
# line is keyed to players with ec.caff_smelt_chg>=1, so a Sigil holder with 0 charges decrements
# nothing (no charge consumed — the Sigil is its own free path, distinct from Smelter's Vein).
#
# Smeltable list mirrors the canonical Smelter's Vein (RESOLVED #8 — ores + sand only; food stays
# uncooked). One nearest item per type per break (a single ore drop) so this stays per-break, not a
# region sweep. distance=..4 = the just-dropped item at the player (not a 6-block scan).

# Stacking guard: suppress any same-tick advantage mining double-drop on these blocks (the same
# convenience-not-yield-multiplier LAW the Smelter's Vein follows — balance seat R-smelt).
scoreboard players set @s ec.caff_mult_fired 1

# --- RAW IRON ---
execute as @e[type=item,distance=..4,nbt={Item:{id:"minecraft:raw_iron"}},limit=1,sort=nearest] run function evercraft:craft_affinity/abilities/ss_smelt_one {target:"minecraft:iron_ingot",sand:0}
# --- RAW GOLD ---
execute as @e[type=item,distance=..4,nbt={Item:{id:"minecraft:raw_gold"}},limit=1,sort=nearest] run function evercraft:craft_affinity/abilities/ss_smelt_one {target:"minecraft:gold_ingot",sand:0}
# --- RAW COPPER ---
execute as @e[type=item,distance=..4,nbt={Item:{id:"minecraft:raw_copper"}},limit=1,sort=nearest] run function evercraft:craft_affinity/abilities/ss_smelt_one {target:"minecraft:copper_ingot",sand:0}
# --- SAND -> GLASS ---
execute as @e[type=item,distance=..4,nbt={Item:{id:"minecraft:sand"}},limit=1,sort=nearest] run function evercraft:craft_affinity/abilities/ss_smelt_one {target:"minecraft:glass",sand:1}
# --- RED SAND -> GLASS ---
execute as @e[type=item,distance=..4,nbt={Item:{id:"minecraft:red_sand"}},limit=1,sort=nearest] run function evercraft:craft_affinity/abilities/ss_smelt_one {target:"minecraft:glass",sand:1}
