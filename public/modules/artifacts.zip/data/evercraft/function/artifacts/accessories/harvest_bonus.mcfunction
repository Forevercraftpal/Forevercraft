# === ACCESSORY HARVEST BONUS — ROLL (D-FORTUNE-REWRITE, m2) ===
# Call (MACRO): function evercraft:artifacts/accessories/harvest_bonus {drop:"<item>", n:N}
#   $(drop) = the harvested ITEM id to potentially double (e.g. "wheat","carrot","oak_log").
#             MUST be a valid ITEM id (NOT a block id — e.g. crops pass "carrot", not "carrots").
#   $(n)    = how many of that item were harvested this break event (>=1).
# Run as @s = player, at @s. Called from the LIVE harvested-block drop hooks (crop process,
# log/tree break, prospect/gather/forage win).
#
# Two item-gated rolls (replacing the dropped Fortune-on-tool inject):
#   (a) DOUBLE HARVEST — per harvested item, #hb_dbl% chance to give +1 of $(drop).
#   (b) EXTRA CRATE    — one additive #hb_crate% roll for a crafting crate on the break.
# Both odds come from harvest_bonus_read (the one writer); zero unless the player holds a
# rewritten harvest accessory -> early-exit costs one comparison.

# Read this player's current harvest-bonus odds (sets #hb_crate / #hb_dbl / ec.hb_active).
function evercraft:artifacts/accessories/harvest_bonus_read
# Early-exit: no harvest accessory held -> nothing to roll.
execute unless score @s ec.hb_active matches 1 run return 0

# --- (a) DOUBLE HARVEST: roll once per harvested item, clamp n to a safe ceiling ---
$scoreboard players set #hb_n ec.temp $(n)
execute if score #hb_n ec.temp matches 64.. run scoreboard players set #hb_n ec.temp 64
$execute if score #hb_dbl ec.temp matches 1.. if score #hb_n ec.temp matches 1.. run function evercraft:artifacts/accessories/harvest_dbl_loop {drop:"$(drop)"}

# --- (b) EXTRA CRATE: one additive roll out of 100 ---
execute if score #hb_crate ec.temp matches 1.. store result score #hb_croll ec.temp run random value 1..100
execute if score #hb_crate ec.temp matches 1.. if score #hb_croll ec.temp <= #hb_crate ec.temp run function evercraft:craft_affinity/give_crafting_crate
