# Wayfarer — Biome Action-bar Readout (U17 Sextant · U24 Omni-Codex)
# Run as @s = player, at @s. Sneak-triggered on-demand (gate at the call site). Vanilla has no "get
# current biome name" command, so this is a FINITE `if biome` ladder over the common biome groups
# (the journal q-biome idiom: `execute at @s if biome ~ ~ ~ <id>`). Bounded — one test per named
# group, not a scan. Reports a coarse biome family on the action bar; unknown -> "Wilds".
execute at @s if biome ~ ~ ~ #minecraft:is_ocean unless entity @s[tag=ab_q] run title @s actionbar [{"text":"⌖ Biome: ","color":"yellow"},{"text":"Ocean","color":"aqua"}]
execute at @s if biome ~ ~ ~ #minecraft:is_river unless entity @s[tag=ab_q] run title @s actionbar [{"text":"⌖ Biome: ","color":"yellow"},{"text":"River","color":"aqua"}]
execute at @s if biome ~ ~ ~ #minecraft:is_beach unless entity @s[tag=ab_q] run title @s actionbar [{"text":"⌖ Biome: ","color":"yellow"},{"text":"Beach","color":"aqua"}]
execute at @s if biome ~ ~ ~ #minecraft:is_jungle unless entity @s[tag=ab_q] run title @s actionbar [{"text":"⌖ Biome: ","color":"yellow"},{"text":"Jungle","color":"green"}]
execute at @s if biome ~ ~ ~ #minecraft:is_forest unless entity @s[tag=ab_q] run title @s actionbar [{"text":"⌖ Biome: ","color":"yellow"},{"text":"Forest","color":"dark_green"}]
execute at @s if biome ~ ~ ~ #minecraft:is_taiga unless entity @s[tag=ab_q] run title @s actionbar [{"text":"⌖ Biome: ","color":"yellow"},{"text":"Taiga","color":"dark_aqua"}]
execute at @s if biome ~ ~ ~ #minecraft:is_savanna unless entity @s[tag=ab_q] run title @s actionbar [{"text":"⌖ Biome: ","color":"yellow"},{"text":"Savanna","color":"gold"}]
execute at @s if biome ~ ~ ~ #minecraft:is_badlands unless entity @s[tag=ab_q] run title @s actionbar [{"text":"⌖ Biome: ","color":"yellow"},{"text":"Badlands","color":"gold"}]
execute at @s if biome ~ ~ ~ #minecraft:is_hill unless entity @s[tag=ab_q] run title @s actionbar [{"text":"⌖ Biome: ","color":"yellow"},{"text":"Hills","color":"dark_green"}]
execute at @s if biome ~ ~ ~ #minecraft:is_mountain unless entity @s[tag=ab_q] run title @s actionbar [{"text":"⌖ Biome: ","color":"yellow"},{"text":"Mountains","color":"white"}]
execute at @s if biome ~ ~ ~ minecraft:desert unless entity @s[tag=ab_q] run title @s actionbar [{"text":"⌖ Biome: ","color":"yellow"},{"text":"Desert","color":"yellow"}]
execute at @s if biome ~ ~ ~ minecraft:swamp unless entity @s[tag=ab_q] run title @s actionbar [{"text":"⌖ Biome: ","color":"yellow"},{"text":"Swamp","color":"dark_green"}]
execute at @s if biome ~ ~ ~ minecraft:mangrove_swamp unless entity @s[tag=ab_q] run title @s actionbar [{"text":"⌖ Biome: ","color":"yellow"},{"text":"Mangrove Swamp","color":"dark_green"}]
execute at @s if biome ~ ~ ~ minecraft:plains unless entity @s[tag=ab_q] run title @s actionbar [{"text":"⌖ Biome: ","color":"yellow"},{"text":"Plains","color":"green"}]
execute at @s if biome ~ ~ ~ minecraft:sunflower_plains unless entity @s[tag=ab_q] run title @s actionbar [{"text":"⌖ Biome: ","color":"yellow"},{"text":"Plains","color":"green"}]
execute at @s if biome ~ ~ ~ minecraft:mushroom_fields unless entity @s[tag=ab_q] run title @s actionbar [{"text":"⌖ Biome: ","color":"yellow"},{"text":"Mushroom Fields","color":"light_purple"}]
execute at @s if biome ~ ~ ~ #minecraft:is_nether unless entity @s[tag=ab_q] run title @s actionbar [{"text":"⌖ Biome: ","color":"yellow"},{"text":"Nether","color":"red"}]
execute at @s if biome ~ ~ ~ #minecraft:is_end unless entity @s[tag=ab_q] run title @s actionbar [{"text":"⌖ Biome: ","color":"yellow"},{"text":"The End","color":"light_purple"}]
execute at @s if biome ~ ~ ~ minecraft:deep_dark unless entity @s[tag=ab_q] run title @s actionbar [{"text":"⌖ Biome: ","color":"yellow"},{"text":"Deep Dark","color":"dark_aqua"}]
