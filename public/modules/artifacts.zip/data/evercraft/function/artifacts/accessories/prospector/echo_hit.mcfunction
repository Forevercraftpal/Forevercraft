# U10 Echolocator Shard — cavity echo (Family K Prospector — art-K)
# Run AT a detected cavity cell; @s = the player. Renders a small soul-particle wisp at the cavity and
# a soft echo chime, force @s (per-player render, ≤8 particles, well under the 36 budget). No
# block-glow — this is the particle ping the RESCOPE mandates in place of the impossible cave outline.
particle minecraft:sculk_soul ~ ~ ~ 0.3 0.3 0.3 0.01 8 force @s
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.sculk_sensor.clicking player @s ~ ~ ~ 0.5 0.7
