# === ACCESSORY HARVEST BONUS — CRATE-ONLY ROLL (D-FORTUNE-REWRITE, m2) ===
# Call: function evercraft:artifacts/accessories/harvest_bonus_crate
# Run as @s = player, at @s. The crate half of the harvest-bonus mechanic for break events
# where the dropped item is a VARIED loot table (prospect / forage / gather node WIN) and so a
# double-harvest of one specific item id doesn't apply. Rolls ONLY the extra-crate odds.
# (Trees/logs/crops route through harvest_bonus instead, which knows the exact item id.)

# Read this player's current harvest-bonus odds (sets #hb_crate / ec.hb_active).
function evercraft:artifacts/accessories/harvest_bonus_read
execute unless score @s ec.hb_active matches 1 run return 0

# EXTRA CRATE: one additive roll out of 100.
execute if score #hb_crate ec.temp matches 1.. store result score #hb_croll ec.temp run random value 1..100
execute if score #hb_crate ec.temp matches 1.. if score #hb_croll ec.temp <= #hb_crate ec.temp run function evercraft:craft_affinity/give_crafting_crate
