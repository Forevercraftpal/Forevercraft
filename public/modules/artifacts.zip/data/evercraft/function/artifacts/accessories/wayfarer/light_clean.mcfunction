# Wayfarer — Lantern-Lichen Clasp: revert the previous foot cell to air (macro).
# Called with storage evercraft:wf_temp {x:X, y:Y, z:Z} = the stored prev cell. Positions at that
# exact cell and sets it to air ONLY IF it still holds our light[level=10] block (the `if block`
# guard means we never delete a real block a player has since placed there). Single setblock, no scan.
$execute positioned $(x) $(y) $(z) if block ~ ~ ~ minecraft:light[level=10] run setblock ~ ~ ~ minecraft:air replace
