# Macro inner for try_bone_meal — writes the random x/z into a per-pid storage slot
# so two simultaneous Almanac holders never overwrite each other's coordinates.
# Macro: {pid:<int>}

$execute store result storage evercraft:artifacts crop_$(pid).x int 1 run random value 0..8
$execute store result storage evercraft:artifacts crop_$(pid).z int 1 run random value 0..8
$function evercraft:artifacts/accessories/try_bone_meal_at with storage evercraft:artifacts crop_$(pid)
