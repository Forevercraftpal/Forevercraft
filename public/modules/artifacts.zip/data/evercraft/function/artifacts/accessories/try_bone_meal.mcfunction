# Try to bone meal a random crop nearby
# Called positioned ~-4 ~-1 ~-4 from crop_boost (already offset)
# Scans 9x3x9 area from positioned origin
# AR-P2-6: per-player scope via $(pid) so the random write→macro chain stays
# isolated even if a schedule is ever inserted between writer and consumer.

execute store result storage evercraft:artifacts crop_dispatch.pid int 1 run scoreboard players get @s companion.id
function evercraft:artifacts/accessories/try_bone_meal_inner with storage evercraft:artifacts crop_dispatch
