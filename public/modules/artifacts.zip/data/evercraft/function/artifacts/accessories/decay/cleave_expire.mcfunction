# Cleave stacks expired — reset stacks and sentinel cooldown
scoreboard players set @s ec.cleave_stacks 0
scoreboard players set @s ec.cleave_cd -1
