# U10 Echolocator Shard — one ray (Family K Prospector — art-K)
# Run AT the ray origin (rotated to the cast direction by echo_pulse); @s = the player (for force @s
# particles + sound). Resets the per-ray step counter, then walks forward via echo_step. Bounded:
# echo_step caps at 12 strides of 2 b ≈ 24 b reach (the directive's ray bound). No block-glow.
scoreboard players set #echo_step ec.temp 0
execute positioned ^ ^ ^2 run function evercraft:artifacts/accessories/prospector/echo_step
