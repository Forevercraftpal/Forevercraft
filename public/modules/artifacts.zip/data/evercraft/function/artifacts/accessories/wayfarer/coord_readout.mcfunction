# Wayfarer — Coordinate + Facing Action-bar Readout (U1 Wayworn Tally · #5 Cartographer's Astrolabe)
# Run as @s = player, at @s. Called from player_tick ONLY when the player holds the item AND is
# NOT sneaking (the sneak-suppress gate lives at the call site, matching U1's "toggles off when
# sneaking" + giving the cycle items the sneak key for their own use). Pure read: data get Pos +
# Rotation -> scores -> ONE title actionbar line. No loops, no particles, no scan. Cheapest possible.

# Read truncated-integer coords (scale 1 = block coords, as quests/depth/calculate + raids do).
execute store result score @s ec.wf_x run data get entity @s Pos[0] 1
execute store result score @s ec.wf_y run data get entity @s Pos[1] 1
execute store result score @s ec.wf_z run data get entity @s Pos[2] 1

# Read yaw (-180..180) and derive a cardinal facing. Vanilla yaw: 0 = +Z (South), 90 = -X (West),
# 180/-180 = -Z (North), -90 = +X (East). Eight-point compass via yaw bands.
execute store result score @s ec.wf_yaw run data get entity @s Rotation[0] 1
scoreboard players set @s ec.wf_face 0
execute if score @s ec.wf_yaw matches -22..22 run scoreboard players set @s ec.wf_face 1
execute if score @s ec.wf_yaw matches 23..67 run scoreboard players set @s ec.wf_face 2
execute if score @s ec.wf_yaw matches 68..112 run scoreboard players set @s ec.wf_face 3
execute if score @s ec.wf_yaw matches 113..157 run scoreboard players set @s ec.wf_face 4
execute if score @s ec.wf_yaw matches 158..180 run scoreboard players set @s ec.wf_face 5
execute if score @s ec.wf_yaw matches -180..-158 run scoreboard players set @s ec.wf_face 5
execute if score @s ec.wf_yaw matches -157..-113 run scoreboard players set @s ec.wf_face 6
execute if score @s ec.wf_yaw matches -112..-68 run scoreboard players set @s ec.wf_face 7
execute if score @s ec.wf_yaw matches -67..-23 run scoreboard players set @s ec.wf_face 8

# Render the facing glyph + the coords on ONE action-bar line.
execute if score @s ec.wf_face matches 1 unless entity @s[tag=ab_q] run title @s actionbar [{"text":"S  ","color":"aqua"},{"text":"X ","color":"gray"},{"score":{"name":"@s","objective":"ec.wf_x"},"color":"white"},{"text":"  Y ","color":"gray"},{"score":{"name":"@s","objective":"ec.wf_y"},"color":"white"},{"text":"  Z ","color":"gray"},{"score":{"name":"@s","objective":"ec.wf_z"},"color":"white"}]
execute if score @s ec.wf_face matches 2 unless entity @s[tag=ab_q] run title @s actionbar [{"text":"SW ","color":"aqua"},{"text":"X ","color":"gray"},{"score":{"name":"@s","objective":"ec.wf_x"},"color":"white"},{"text":"  Y ","color":"gray"},{"score":{"name":"@s","objective":"ec.wf_y"},"color":"white"},{"text":"  Z ","color":"gray"},{"score":{"name":"@s","objective":"ec.wf_z"},"color":"white"}]
execute if score @s ec.wf_face matches 3 unless entity @s[tag=ab_q] run title @s actionbar [{"text":"W  ","color":"aqua"},{"text":"X ","color":"gray"},{"score":{"name":"@s","objective":"ec.wf_x"},"color":"white"},{"text":"  Y ","color":"gray"},{"score":{"name":"@s","objective":"ec.wf_y"},"color":"white"},{"text":"  Z ","color":"gray"},{"score":{"name":"@s","objective":"ec.wf_z"},"color":"white"}]
execute if score @s ec.wf_face matches 4 unless entity @s[tag=ab_q] run title @s actionbar [{"text":"NW ","color":"aqua"},{"text":"X ","color":"gray"},{"score":{"name":"@s","objective":"ec.wf_x"},"color":"white"},{"text":"  Y ","color":"gray"},{"score":{"name":"@s","objective":"ec.wf_y"},"color":"white"},{"text":"  Z ","color":"gray"},{"score":{"name":"@s","objective":"ec.wf_z"},"color":"white"}]
execute if score @s ec.wf_face matches 5 unless entity @s[tag=ab_q] run title @s actionbar [{"text":"N  ","color":"aqua"},{"text":"X ","color":"gray"},{"score":{"name":"@s","objective":"ec.wf_x"},"color":"white"},{"text":"  Y ","color":"gray"},{"score":{"name":"@s","objective":"ec.wf_y"},"color":"white"},{"text":"  Z ","color":"gray"},{"score":{"name":"@s","objective":"ec.wf_z"},"color":"white"}]
execute if score @s ec.wf_face matches 6 unless entity @s[tag=ab_q] run title @s actionbar [{"text":"NE ","color":"aqua"},{"text":"X ","color":"gray"},{"score":{"name":"@s","objective":"ec.wf_x"},"color":"white"},{"text":"  Y ","color":"gray"},{"score":{"name":"@s","objective":"ec.wf_y"},"color":"white"},{"text":"  Z ","color":"gray"},{"score":{"name":"@s","objective":"ec.wf_z"},"color":"white"}]
execute if score @s ec.wf_face matches 7 unless entity @s[tag=ab_q] run title @s actionbar [{"text":"E  ","color":"aqua"},{"text":"X ","color":"gray"},{"score":{"name":"@s","objective":"ec.wf_x"},"color":"white"},{"text":"  Y ","color":"gray"},{"score":{"name":"@s","objective":"ec.wf_y"},"color":"white"},{"text":"  Z ","color":"gray"},{"score":{"name":"@s","objective":"ec.wf_z"},"color":"white"}]
execute if score @s ec.wf_face matches 8 unless entity @s[tag=ab_q] run title @s actionbar [{"text":"SE ","color":"aqua"},{"text":"X ","color":"gray"},{"score":{"name":"@s","objective":"ec.wf_x"},"color":"white"},{"text":"  Y ","color":"gray"},{"score":{"name":"@s","objective":"ec.wf_y"},"color":"white"},{"text":"  Z ","color":"gray"},{"score":{"name":"@s","objective":"ec.wf_z"},"color":"white"}]
execute if score @s ec.wf_face matches 0 unless entity @s[tag=ab_q] run title @s actionbar [{"text":"?  ","color":"aqua"},{"text":"X ","color":"gray"},{"score":{"name":"@s","objective":"ec.wf_x"},"color":"white"},{"text":"  Y ","color":"gray"},{"score":{"name":"@s","objective":"ec.wf_y"},"color":"white"},{"text":"  Z ","color":"gray"},{"score":{"name":"@s","objective":"ec.wf_z"},"color":"white"}]
