# Accessory Artifacts — Tick (1s self-scheduling)
# OPT: All per-accessory checks moved to player_tick, reducing ~250 @a scans to 1.
# OPT (2026-06-06): worn artifact-ARMOR abilities split back into their own armor-gated @a dispatch
# (worn_tick_player) so armor-only players skip player_tick's full ~474-line accessory scan.
#
# ============================================================
# TICK-ORDER INVARIANT (D-MULTICOPY / m4) — DO NOT REORDER
# ============================================================
# The capstone-supersedes-piece multi-copy strips (Knot, Band-15, Wardband, Voidband, and the
# Pebble's consolidate step 2) all RELY on the LOOSE accessory lines having already run THIS tick,
# so that the capstone's later strip overwrites the loose member's just-added *_luck modifier.
# Therefore the ordering below is LOAD-BEARING and must be preserved:
#   1) LOOSE lines first:  player_tick (:19) runs every loose accessory's own *_luck add lines
#      AND the inline Band-15 consolidate+strip block (player_tick also hosts the Band).
#   2) CAPSTONE consolidate SECOND: the satchel chain (:25) → satchel/check_and_apply →
#      hero_satchel/apply_held → apply_consolidated_luck → consolidate/{pebble,aegis,astral},
#      which strip the boss-trinket loose *_luck the loose lines added in step 1.
# The Knot/Hand/sub-band apply fns are dispatched from WITHIN player_tick's consolidated fusion
# block (player_tick :42-174), which itself runs AFTER the loose *_luck add lines earlier in the
# same player_tick pass — so their strips also win. CAPSTONE CONSOLIDATE MUST RUN AFTER LOOSE
# ACCESSORY LINES. Reordering (e.g. moving the satchel chain or the fusion block ahead of the
# loose adds) would silently re-open every capstone-vs-piece DR double-dip.

# Reschedule first (guarantees we keep ticking regardless of gate)
schedule function evercraft:artifacts/accessories/tick 1s

# Gate: skip logic if no players online
execute unless entity @a run return 0

# === TOGGLE DETECTION (F8) ===
function evercraft:artifacts/accessories/toggle_check

# === TOGGLE-OFF: Remove luck attribute modifiers when disabled ===
# OPT: 7 @a scans → 1 per-player function call (only runs for players with any toggle active)
execute as @a[tag=ec.has_accessory] run function evercraft:artifacts/accessories/remove_toggled_luck

# === PER-PLAYER PROCESSING (all accessory checks + cleanup + satchels) ===
# OPT: full ~474-line accessory scan. Gated by player_tick's own early-exit so accessory-less players
# (incl. armor-only wearers) skip it entirely.
# INVARIANT (m4): this runs the LOOSE *_luck adds + the inline Band-15/Knot/sub-band strips FIRST.
execute as @a at @s run function evercraft:artifacts/accessories/player_tick

# === WORN ARTIFACT-ARMOR ABILITIES (own lightweight @a scan) ===
# (2026-06-06) PERF: split out of player_tick so an armor-only player (worn artifact armor, NO accessory/
# ring/boss-exclusive) runs ONLY the ~20 armor-ability checks in worn_tick_player instead of the full
# ~474 accessory scan. Gated INDEPENDENT of the accessory early-exit on TWO conditions, OR'd via two lines:
#   (1) any armor slot currently holds an artifact (is_artifact:true) — the live wearers, AND
#   (2) tag=ec.has_worn_armor — the 1-extra-tick keep-alive so the strip-on-last-piece-removal pass still
#       fires (worn_tick_player's attribute strips are player-attached and must run one tick AFTER the last
#       piece leaves; see the cleanup-persistence note in worn_tick_player).
# Line (2) is checked first; line (1) is guarded by `unless tag=ec.has_worn_armor` so a wearer caught by
# the tag never also runs via the armor-present line in the same tick (no double-run of the abilities).
execute as @a[tag=ec.has_worn_armor] at @s run function evercraft:artifacts/accessories/worn_tick_player
execute as @a[tag=!ec.has_worn_armor] at @s if items entity @s armor.* *[custom_data~{is_artifact:true}] run function evercraft:artifacts/accessories/worn_tick_player

# === SATCHEL DREAM RATE: Re-apply satchel artifact modifiers AFTER cleanup ===
# Cleanup removes luck modifiers for artifacts not in inventory, but satchel-stored
# artifacts aren't in inventory. Apply satchel effects here so they always survive cleanup.
# OPT: Gate to players with satchel-related items (tag set on acquire, never cleared — safe)
# INVARIANT (m4): the Pebble consolidate strip runs HERE, AFTER the loose lines above — do not reorder.
execute as @a[tag=ec.satchel_owner] run function evercraft:satchel/check_and_apply

# === COOLDOWN DECREMENTS ===
scoreboard players remove @a[scores={ec.monocle_cd=1..}] ec.monocle_cd 1
scoreboard players remove @a[scores={ec.seers_cd=1..}] ec.seers_cd 1
scoreboard players remove @a[scores={ec.wecho_cd=1..}] ec.wecho_cd 1
scoreboard players remove @a[scores={ec.ceye_cd=1..}] ec.ceye_cd 1
scoreboard players remove @a[scores={ec.wtotem_cd=1..}] ec.wtotem_cd 1

# === COMBAT MACE ARMOR-SHRED MARK DECAY (Wave 1-B) ===
# The shred mark lives on the target MOB (ec.shred, set in shield_breaker). Existence-gated: only scan
# mobs at all if at least one carries an active decay window. Tick the window down; when it lapses,
# clear the mob's stacks so the vulnerability doesn't persist forever after the mace stops hitting it.
execute if entity @e[scores={ec.shred_cd=1..}] run scoreboard players remove @e[scores={ec.shred_cd=1..}] ec.shred_cd 1
execute if entity @e[scores={ec.shred_cd=0,ec.shred=1..}] as @e[scores={ec.shred_cd=0,ec.shred=1..}] run scoreboard players set @s ec.shred 0

# === PER-PLAYER ABILITY DECAY TIMERS ===
# OPT: Consolidated cooldown-zero checks — was 11 duplicate @a scans, now 5 decrements + 5 single-scan calls
# Cleave stacks (3s)
scoreboard players remove @a[scores={ec.cleave_cd=1..}] ec.cleave_cd 1
execute as @a[scores={ec.cleave_cd=0}] run function evercraft:artifacts/accessories/decay/cleave_expire
# Kill Chain (10s)
scoreboard players remove @a[scores={ec.chain_cd=1..}] ec.chain_cd 1
execute as @a[scores={ec.chain_cd=0}] run function evercraft:artifacts/accessories/decay/chain_expire
# Berserker Frenzy (10s) — DISTINCT from Kill Chain (berserker_totem on-kill stack)
scoreboard players remove @a[scores={ec.berserk_cd=1..}] ec.berserk_cd 1
execute as @a[scores={ec.berserk_cd=0}] run function evercraft:artifacts/accessories/decay/berserk_expire
# Warriors Crown Kill Chain (10s) — DISTINCT from the Caliburn Kill Chain (own ec.wc_chain counter)
scoreboard players remove @a[scores={ec.wc_chain_cd=1..}] ec.wc_chain_cd 1
execute as @a[scores={ec.wc_chain_cd=0}] run function evercraft:artifacts/accessories/decay/wc_chain_expire
# Soul Harvest (15s)
scoreboard players remove @a[scores={ec.soul_cd=1..}] ec.soul_cd 1
execute as @a[scores={ec.soul_cd=0}] run function evercraft:artifacts/accessories/decay/soul_expire
# Titan Momentum (5s)
scoreboard players remove @a[scores={ec.titan_cd=1..}] ec.titan_cd 1
execute as @a[scores={ec.titan_cd=0}] run function evercraft:artifacts/accessories/decay/titan_expire
# Crimson Tempo (5s) — also removes attribute modifier
scoreboard players remove @a[scores={ec.crimson_cd=1..}] ec.crimson_cd 1
execute as @a[scores={ec.crimson_cd=0}] run function evercraft:artifacts/accessories/decay/crimson_expire
# BUG-002 FIX: Battle Tempo (3s) — per-player cooldown replaces global schedule
scoreboard players remove @a[scores={ec.tempo_cd=1..}] ec.tempo_cd 1
execute as @a[scores={ec.tempo_cd=0}] run function evercraft:artifacts/accessories/decay/tempo_expire
# BUG-003 FIX: Flowing Strikes (3s) — per-player cooldown replaces global schedule
scoreboard players remove @a[scores={ec.flow_cd=1..}] ec.flow_cd 1
execute as @a[scores={ec.flow_cd=0}] run function evercraft:artifacts/accessories/decay/flow_expire
# BUG-004 FIX: Mjolnir Worthy (60s) — per-player cooldown replaces global schedule
scoreboard players remove @a[scores={ec.worthy_cd=1..}] ec.worthy_cd 1
execute as @a[scores={ec.worthy_cd=0}] run function evercraft:artifacts/accessories/decay/worthy_expire

# === DIMENSIONAL RIFT — Portal Staff trap processing ===
execute if entity @e[tag=ec.rift] run function evercraft:artifacts/abilities/rift_tick

# === IAI DRAW — Katana sneak stance detection (1s tick = 2 ticks needed for 2s) ===
# OPT: Gate entire block — skip all 6 @a scans when nobody is charging/ready/has katana
# Most ticks nobody has a katana, so this saves 6 selector evaluations/second
execute if entity @a[tag=ec.iai_charging,limit=1] run function evercraft:artifacts/accessories/iai_tick_active
execute if entity @a[tag=ec.iai_ready,limit=1] unless entity @a[tag=ec.iai_charging,limit=1] run function evercraft:artifacts/accessories/iai_tick_active
# New charger detection: only scan sneaking players when nobody is already in the Iai pipeline
execute unless entity @a[tag=ec.iai_charging,limit=1] unless entity @a[tag=ec.iai_ready,limit=1] as @a[predicate=evercraft:is_sneaking] if items entity @s weapon.mainhand *[custom_data~{ability:"critical_edge"}] run tag @s add ec.iai_charging
