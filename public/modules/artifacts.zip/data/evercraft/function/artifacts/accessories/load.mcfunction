# Accessories System - Load Function
# Bootstraps the self-scheduling tick system

# Mob Vision cooldown scoreboards (activation-based, not passive)
scoreboard objectives add ec.monocle_cd dummy "Monocle Cooldown"

# Dream Aegis iframe cooldown
scoreboard objectives add ec.aegis_cd dummy "Dream Aegis Cooldown"
scoreboard objectives add ec.wrc_souls dummy "Wither Crown Souls"
scoreboard objectives add ec.wrc_t dummy "Wither Crown Soul Window"

# Armor ability scoreboards
scoreboard objectives add ec.double_jump_cd dummy "Double Jump Cooldown"
scoreboard objectives add ec.seers_cd dummy "Seers Compass Cooldown"
scoreboard objectives add ec.wecho_cd dummy "Wardens Echo Cooldown"
scoreboard objectives add ec.ceye_cd dummy "Claudes Eye Cooldown"
scoreboard objectives add ec.wtotem_cd dummy "Warden Totem Cooldown"
scoreboard objectives add ec.codex_cd dummy "Codex Cooldown"

# === ACCESSORY TOGGLE SYSTEM (F8) ===
# Sneak timer and cooldown for toggle detection
scoreboard objectives add ec.t_sneak dummy "Toggle Sneak Timer"
scoreboard objectives add ec.t_cooldown dummy "Toggle Cooldown"

# Per-artifact toggle state (0 = ON default, 1 = OFF)
scoreboard objectives add ec.t_pebble dummy "Toggle Pebble"
scoreboard objectives add ec.t_traveler dummy "Toggle Traveler"
scoreboard objectives add ec.t_wcompass dummy "Toggle W.Compass"
scoreboard objectives add ec.t_glowpend dummy "Toggle Glowpend"
scoreboard objectives add ec.t_irontali dummy "Toggle IronTali"
scoreboard objectives add ec.t_feather dummy "Toggle Feather"
scoreboard objectives add ec.t_dring dummy "Toggle D.Ring"
scoreboard objectives add ec.t_rwatch dummy "Toggle RuinWatch"
scoreboard objectives add ec.t_heart dummy "Toggle Heartstone"
scoreboard objectives add ec.t_storm dummy "Toggle Storm"
scoreboard objectives add ec.t_merchant dummy "Toggle Merchant"
scoreboard objectives add ec.t_healer dummy "Toggle Healer"
scoreboard objectives add ec.t_wind dummy "Toggle WindChime"
scoreboard objectives add ec.t_angler dummy "Toggle Angler"
scoreboard objectives add ec.t_phoenix dummy "Toggle Phoenix"
scoreboard objectives add ec.t_undying dummy "Toggle Undying"
scoreboard objectives add ec.t_voidhrt dummy "Toggle VoidHeart"
scoreboard objectives add ec.t_phantom dummy "Toggle Phantom"
scoreboard objectives add ec.t_sculkhrt dummy "Toggle SculkHrt"
scoreboard objectives add ec.t_redhrt dummy "Toggle RedHeart"
scoreboard objectives add ec.t_singularity dummy "Toggle Singularity"

# === WEAPON ABILITY SCOREBOARDS ===
# Battle Tempo (Mauler) — 5-hit combo counter
scoreboard objectives add ec.battle_tempo dummy "Battle Tempo"
# Primal Roar (Boneclub) — 10-hit roar counter
scoreboard objectives add ec.primal_roar dummy "Primal Roar"
# Flowing Strikes (Battlestaff) — 3-hit Haste stacking
scoreboard objectives add ec.flow_hits dummy "Flow Hits"
# Mjolnir Worthy — lightning chain counter
scoreboard objectives add ec.mjolnir_chain dummy "Mjolnir Chain"
# Momentum Cleave (Claymore) — sweep damage stacking
scoreboard objectives add ec.cleave_stacks dummy "Cleave Stacks"
# Kill Chain (Caliburn/Excalibur) — consecutive kill counter
scoreboard objectives add ec.kill_chain dummy "Kill Chain"
# Berserker Frenzy (Berserker Totem) — on-kill frenzy stack counter (DISTINCT from the weapon
# Kill Chain so the two never clobber; one writer each). SET/incremented in artifacts/abilities/
# berserker_totem_kill, reset in accessories/decay/berserk_expire.
scoreboard objectives add ec.berserk_chain dummy "Berserk Frenzy"
# Eyelander Souls — stacking soul counter
scoreboard objectives add ec.eyelander_souls dummy "Eyelander Souls"
# Voltaic Chains (Sinister Sword) — hit counter for chain lightning
scoreboard objectives add ec.voltaic_hits dummy "Voltaic Hits"
# Titan Momentum (Golden Goliath) — consecutive hit chain without taking damage
scoreboard objectives add ec.titan_hits dummy "Titan Hits"
# Tidal Rush (Prismarine Gauntlet) — hit counter in water/rain
scoreboard objectives add ec.tidal_hits dummy "Tidal Hits"
# Crimson Tempo (Red Gauntlet) — heal proc stacking attack speed
scoreboard objectives add ec.crimson_stacks dummy "Crimson Stacks"
# Per-player decay countdown timers (decremented in 1s tick)
scoreboard objectives add ec.cleave_cd dummy "Cleave Decay CD"
scoreboard objectives add ec.chain_cd dummy "Kill Chain Decay CD"
# Berserker Frenzy decay countdown (10s) — DISTINCT from ec.chain_cd. Decremented in accessories/tick.
scoreboard objectives add ec.berserk_cd dummy "Berserk Decay CD"
scoreboard objectives add ec.soul_cd dummy "Soul Harvest Decay CD"
scoreboard objectives add ec.titan_cd dummy "Titan Decay CD"
scoreboard objectives add ec.crimson_cd dummy "Crimson Decay CD"
# BUG-002/003/004 FIX: Per-player decay cooldowns (replaces global schedule+@a)
scoreboard objectives add ec.tempo_cd dummy "Battle Tempo Decay CD"
scoreboard objectives add ec.flow_cd dummy "Flowing Strikes Decay CD"
scoreboard objectives add ec.worthy_cd dummy "Worthy Decay CD"
# Dedicated persistent counters (avoid ec.artifact_roll collisions)
scoreboard objectives add ec.iai_charge dummy "Iai Draw Charge"
scoreboard objectives add ec.fury_hits dummy "Dragon Fury Hits"
scoreboard objectives add ec.zant_hits dummy "Zantetsuken Hits"
scoreboard objectives add ec.rift_ticks dummy "Rift Marker Ticks"
# Regen fallback cooldown (instant heal when Regen II+ already active)
scoreboard objectives add ec.regen_ih_cd dummy "Regen Fallback CD"

# Death-save cooldowns (Soul Protection 3min, Void Heart 5min, Phoenix Totem 5min)
scoreboard objectives add ec.cd_soul dummy "Soul Protection CD"
scoreboard objectives add ec.cd_void dummy "Void Heart CD"
scoreboard objectives add ec.cd_phoenix dummy "Phoenix Totem CD"
# Soulguard Aegis SHARED death-save bucket (cap-D, G6: ONE bucket for ALL D revives, 5min). SET by
# artifacts/abilities/soulguard_save, decremented in player_tick (the same source-set + tick-decrement
# cooldown idiom as the three above). 10 chars <=16.
scoreboard objectives add ec.cd_save dummy "Soulguard Save CD"
# Heart of the Void — Void Blink dash cooldown (5s). SET to 5 in artifacts/accessories/player_tick's
# heart_of_the_void block, decremented in the cd_* tick-down block there (one writer besides the source-set).
scoreboard objectives add ec.cd_void_blink dummy "Void Blink CD"
# Prism of Light — Radiance once-per-second damage cadence. SET to 1 in player_tick's prism_of_light
# block, decremented in the cd_* tick-down block there (one writer besides the source-set).
scoreboard objectives add ec.pol_dmgcd dummy "Prism Radiance CD"
# Ring of Undying — custom death-save revive cooldown (2min). SET in artifacts/abilities/ring_of_undying_save,
# decremented in the cd_* tick-down block in player_tick (one writer besides the source-set). VALUE = SECONDS.
scoreboard objectives add ec.cd_undying_rev dummy "Ring Undying Revive CD"
# Temporal Hourglass — Chrono Rewind death-save cooldown (4min). SET in artifacts/abilities/temporal_hourglass_save,
# decremented in the cd_* tick-down block in player_tick (one writer besides the source-set). VALUE = SECONDS.
scoreboard objectives add ec.cd_chrono dummy "Chrono Rewind CD"
# Phoenix Feather — ornate Rebirth death-save cooldown (10min). SET in artifacts/abilities/phoenix_feather_save,
# decremented in the cd_* tick-down block in player_tick (one writer besides the source-set). VALUE = SECONDS.
scoreboard objectives add ec.cd_feather dummy "Phoenix Feather CD"
# Fireforged 4pc — "Phoenix Rebirth" exquisite armor-SET death-save cooldown (3600s = 1 hour). The objective
# ec.fireforged_cd is ALREADY registered in artifacts/sets/load.mcfunction (the orphaned "Fireforged Revive
# Cooldown" from the never-built original revive — now adopted). SET in artifacts/abilities/fireforged_4pc_save,
# decremented in the cd_* tick-down block in player_tick (one writer besides the source-set). VALUE = SECONDS.
# (No registration here — it lives in sets/load to avoid a duplicate objective.)
# Ninja 4pc — "Shadow Step" sneak-blink cooldown (5s). SET in artifacts/sets/ninja/bonus_4pc, decremented
# in the cd_* tick-down block in player_tick (one writer besides the source-set). VALUE = SECONDS.
scoreboard objectives add ec.cd_ninja dummy "Ninja Shadow Step CD"
# Space 4pc — "Meteor Strike" sneak-active cooldown (8s). SET in artifacts/sets/space/bonus_4pc, decremented
# in the cd_* tick-down block in player_tick (one writer besides the source-set). VALUE = SECONDS.
scoreboard objectives add ec.cd_space dummy "Space Meteor CD"
# Ender Dragon Scale — "Dragon Ascendant" sneak-active cooldown (15s). SET in artifacts/abilities/ender_dragon_scale_ascend,
# decremented in the cd_* tick-down block in player_tick (one writer besides the source-set). VALUE = SECONDS.
scoreboard objectives add ec.cd_dragon dummy "Dragon Ascendant CD"
# Redstone Heart — "Overclock" sneak-active cooldown (30s). SET in artifacts/abilities/redstone_heart_overclock,
# decremented in the cd_* tick-down block in player_tick (one writer besides the source-set). VALUE = SECONDS.
scoreboard objectives add ec.cd_overclock dummy "Overclock CD"
# Ender Dragon Scale — void-save Y reader (Pos[1]). WRITTEN ONLY in player_tick's ender_dragon_scale block
# (one writer). DISTINCT from voidscale's ec._vy so the two void-readers never clobber. 6 chars <=16.
scoreboard objectives add ec.dr_vy dummy "Dragon Scale Y"
# Dragonheart Ember — on-fire reader (Fire tick count). WRITTEN ONLY in player_tick's dragonheart_ember
# block (one writer); read same line to gate Strength-while-on-fire. The depth_readout idiom, like dr_vy.
scoreboard objectives add ec.dhe_fire dummy "Dragonheart Fire"
# ===== Wave 1-B armor identities =====
# Titan's Plate — "Titan's Bulwark" sneak-active cooldown (12s). SET in artifacts/abilities/titans_brace,
# decremented in the cd_* tick-down block in player_tick (one writer besides the source-set). VALUE = SECONDS.
scoreboard objectives add ec.cd_titan dummy "Titan Bulwark CD"
# Leggings of Fortitude — "Bulwark's Footing" stationary tick counter. WRITTEN ONLY in worn_tick_player
# (incremented while still, reset on move). One writer.
scoreboard objectives add ec.lof_still dummy "Fortitude Still"
# Leggings of Fortitude — last-tick Pos[0]/Pos[2] (x10) for the movement delta read. WRITTEN ONLY in
# worn_tick_player (one writer). Compared then overwritten each 1s tick to detect movement.
scoreboard objectives add ec.lof_px dummy "Fortitude PrevX"
scoreboard objectives add ec.lof_pz dummy "Fortitude PrevZ"
# Warriors Crown — "Kill Chain" counter + 10s decay sentinel. DISTINCT from the Caliburn ec.kill_chain.
# ec.wc_chain SET/added in warriors_crown_kill; ec.wc_chain_cd decremented in accessories/tick (one writer).
scoreboard objectives add ec.wc_chain dummy "Crown Kill Chain"
scoreboard objectives add ec.wc_chain_cd dummy "Crown Chain Decay"
# Combat Mace — armor-shred mark, stored ON the target MOB (not the player). ec.shred = stack count
# (0-5, +1 dmg/stack), SET/added in shield_breaker; ec.shred_cd = 5s decay window, SET in shield_breaker
# and ticked down in accessories/tick (one writer beside the source-set). Lives on mobs so the
# vulnerability persists across attackers; cleared when the window lapses unre-hit.
scoreboard objectives add ec.shred dummy "Armor Shred Mark"
scoreboard objectives add ec.shred_cd dummy "Armor Shred Decay"

# === ACCESSORY DODGE LANE (D-DODGE) ===
# Additive dodge-points lane, re-summed every tick in player_tick (1% = 4 pts; 0.25%/pt).
# DISTINCT from the Dancer's single-writer ec.dn_evasion_add — accessories accumulate so they
# STACK. Summed into advantage/tick/evasion_check (#chance += ec.acc_dodge) and OR-ed into the
# advantage/dodge_eligible predicate so an accessory-only build still HP-snapshot-cancels the hit.
scoreboard objectives add ec.acc_dodge dummy "Accessory Dodge Pts"

# === FAMILY M — DRAGONHEART void-immunity Y-reader (Voidscale Shard, art-M) ===
# Per-player temp lane holding the bearer's current Y (Pos[1]) so the Voidscale Shard's void-immunity
# block in player_tick can gate its no-void-fall rescue (Y ≤ -70) without a deep NBT compare each line.
# WRITTEN ONLY in artifacts/accessories/player_tick (the Family M leaf block) — one writer. DISTINCT from
# ec.wf_y (the Wayfarer depth readout's own one-writer Y), so the two never clobber. 6 chars <=16.
scoreboard objectives add ec._vy dummy "Voidscale Y"

# === ACCESSORY HARVEST BONUS (D-FORTUNE-REWRITE, m2) ===
# Per-player flag: 1 while the player holds any rewritten harvest accessory (Forester's Tally /
# Master Smith's Crystal axe-part / Tiller's Knot / Gleaner's Twine + siblings). Set ON each
# harvest break by artifacts/accessories/harvest_bonus_read (the one writer), read as the early-
# exit gate by harvest_bonus / harvest_bonus_crate. Replaces the dropped Fortune-on-tool inject:
# instead of an enchant, a harvest break rolls extra-crate odds + a double-harvest chance.
scoreboard objectives add ec.hb_active dummy "Harvest Bonus Active"

# === CRAFT/MINE ACTIVITY WINDOW (Family B conditional-DR leaves — art-B) ===
# Per-player countdown ticks-remaining window: >0 means the player has mined/chopped/dug/tilled
# or completed a craft-affinity verb within the last few seconds. SET to a refresh value (100t =
# 5s) by craft_affinity/grant_verb (the one SET-source, fired on every qualifying verb), and
# DECREMENTED by 1 each tick in artifacts/accessories/player_tick (exactly the ec.cd_soul /
# ec.regen_ih_cd cooldown idiom: one ability-source sets, player_tick counts down). Read (never
# written) by the conditional-DR Family-B leaves — Geologist's Loupe (+2 DR while mining),
# Conditional Cache-Eye (+2 DR while mining/harvesting), Worldforge Ember (+3 DR after crafting) —
# to grant/strip their luck modifier. 12 chars <=16.
scoreboard objectives add ec.cf_actwin dummy "Craft Activity Win"

# === FAMILY C — WAYFARER (Sense & Travel) readout/light/survey scratch (art-C) ===
# Per-player temp lane for the 7 new Wayfarer leaves (U1/U5/U7/U17/U23/U24 + #5 Astrolabe). ALL
# written by the artifacts/accessories/wayfarer/* readout family ONLY (one logical writer per name —
# the readout fns are the sole writers; player_tick just gates the calls). No DR (balance-neutral
# bundle). Coord/facing readout:
scoreboard objectives add ec.wf_x dummy "Wayfarer X"
scoreboard objectives add ec.wf_y dummy "Wayfarer Y"
scoreboard objectives add ec.wf_z dummy "Wayfarer Z"
scoreboard objectives add ec.wf_yaw dummy "Wayfarer Yaw"
scoreboard objectives add ec.wf_face dummy "Wayfarer Facing"
# Lantern-Lichen Clasp local-light tracking (current cell, stored prev cell, moved flag, own-light flag):
scoreboard objectives add ec.wf_lx dummy "Wayfarer LightX"
scoreboard objectives add ec.wf_ly dummy "Wayfarer LightY"
scoreboard objectives add ec.wf_lz dummy "Wayfarer LightZ"
scoreboard objectives add ec.wf_plx dummy "Wayfarer PrevX"
scoreboard objectives add ec.wf_ply dummy "Wayfarer PrevY"
scoreboard objectives add ec.wf_plz dummy "Wayfarer PrevZ"
scoreboard objectives add ec.wf_lmoved dummy "Wayfarer Moved"
scoreboard objectives add ec.wf_lhas dummy "Wayfarer HasLight"
# Respawn-bearing readout (bed coords, deltas, abs deltas, distance, ratio test, 8-pt bearing):
scoreboard objectives add ec.wf_bx dummy "Wayfarer BedX"
scoreboard objectives add ec.wf_bz dummy "Wayfarer BedZ"
scoreboard objectives add ec.wf_dx dummy "Wayfarer DX"
scoreboard objectives add ec.wf_dz dummy "Wayfarer DZ"
scoreboard objectives add ec.wf_adx dummy "Wayfarer AbsDX"
scoreboard objectives add ec.wf_adz dummy "Wayfarer AbsDZ"
scoreboard objectives add ec.wf_dist dummy "Wayfarer Dist"
scoreboard objectives add ec.wf_min dummy "Wayfarer MinAxis"
scoreboard objectives add ec.wf_min2 dummy "Wayfarer Min2"
scoreboard objectives add ec.wf_bear dummy "Wayfarer Bearing"
# Sextant clock + biome phase:
scoreboard objectives add ec.wf_time dummy "Wayfarer Daytime"
scoreboard objectives add ec.wf_phase dummy "Wayfarer Phase"
# Omni-Codex depth + Dream-Rate readout:
scoreboard objectives add ec.wf_depth dummy "Wayfarer Depth"
scoreboard objectives add ec.wf_dr dummy "Wayfarer DR"
scoreboard objectives add ec.wf_drw dummy "Wayfarer DRwhole"
scoreboard objectives add ec.wf_drt dummy "Wayfarer DRtenth"
# Survey-ping + cycle cooldowns / cycle indices:
scoreboard objectives add ec.wf_pingcd dummy "Wayfarer PingCD"
scoreboard objectives add ec.wf_cyccd dummy "Wayfarer CycleCD"
scoreboard objectives add ec.wf_scyc dummy "Wayfarer SextCyc"
scoreboard objectives add ec.wf_ccyc dummy "Wayfarer CodxCyc"
# Steady-Hand Caliper (U16) placement-ghost debounce cooldown (art-F):
scoreboard objectives add ec.cal_ghostcd dummy "Caliper GhostCD"

# === FAMILY H — CHEMISTRY TRADE (Alchemist's Magnum Opus) — Alembic Heart held-flag (art-H) ===
# Per-player flag: 1 while the player holds an Alembic Heart (C21) during a brew. SET in
# craftforever/alchemy/minigame/resolve (the ONE writer — set to 0 then 1 if held, every brew) and
# READ in the result step (result_dilute/potent/sublime) to bump #ff_duration_mod by +50 (the +50%
# brew-duration lever). 11 chars <=16. NOT a tick objective — only touched inside the brew funnel.
scoreboard objectives add ec.h_alembic dummy "Alembic Heart Held"

# === FAMILY K — PROSPECTOR (Demiurge's Spirit Artifact) sneak-survey debounce cooldown (art-K) ===
# Per-player countdown for the K sneak-triggered survey/QoL items (U6 Plumb-Bob, U10 Echolocator, U13
# Quartzlight Loupe, U19 Spelunker's Resonator, C7 Dowsing ping, U21 Sortstone). SET to a debounce
# value (40-60t) by each survey fn when it fires, DECREMENTED by 1 each tick in player_tick (the
# cd_soul / cal_ghostcd cooldown idiom). A clean lane distinct from ec.wf_pingcd / ec.wf_cyccd (the
# Wayfarer survey/cycle debounces — those were SET-but-never-decremented in art-C, a latent bug FIXED
# in cap-C by adding their tick-decrements beside this one in player_tick). 11 chars <=16.
scoreboard objectives add ec.pr_pingcd dummy "Prospector PingCD"

# === PROXIMITY-PING RE-PING COOLDOWNS (Wave 1, Joseph 2026-06-10 — actionbar-priority program) ===
# Per-player countdowns for the two PASSIVE proximity cues, which are now edge-triggered through
# the notify queue (emit_now + TTL) instead of repainting the bar every loop pass. UNITS = passes
# of the 1s accessories loop, NOT ticks (decremented at the top of each ping fn — the fn is its
# objective's sole writer). 10 passes ≈ 10s between re-pings while a node stays in range.
scoreboard objectives add ec.ping_tf dummy "Tidefinder RePing"
scoreboard objectives add ec.ping_al dummy "Astrolabe RePing"

# Start the accessory tick loop
schedule function evercraft:artifacts/accessories/tick 1s replace

# Start the double jump tick loop (fast, 2 ticks for responsiveness)
schedule function evercraft:artifacts/abilities/double_jump_tick 2t replace
