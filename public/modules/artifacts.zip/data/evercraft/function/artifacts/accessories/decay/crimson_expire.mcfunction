# Crimson Tempo expired — remove speed modifier, reset stacks and sentinel cooldown
attribute @s attack_speed modifier remove evercraft:crimson_tempo
scoreboard players set @s ec.crimson_stacks 0
scoreboard players set @s ec.crimson_cd -1
