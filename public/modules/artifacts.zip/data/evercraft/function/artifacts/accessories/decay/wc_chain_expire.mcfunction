# Warriors Crown Kill Chain expired — reset chain count and decay sentinel
scoreboard players set @s ec.wc_chain 0
scoreboard players set @s ec.wc_chain_cd -1
