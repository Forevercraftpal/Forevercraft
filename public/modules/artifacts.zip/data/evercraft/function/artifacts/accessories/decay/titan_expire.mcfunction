# Titan Momentum expired — reset hit count and sentinel cooldown
scoreboard players set @s ec.titan_hits 0
scoreboard players set @s ec.titan_cd -1
