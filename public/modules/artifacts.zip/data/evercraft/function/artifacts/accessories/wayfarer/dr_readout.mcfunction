# Wayfarer — Dream Rate Total Action-bar Readout (U24 Omni-Codex)
# Run as @s = player. Sneak-triggered on-demand (gate at the call site). Reads the player's total
# luck attribute (= Dream Rate, the same `attribute @s luck get 10` the Dreams system reads in
# dreams/check) at the ×10 fixed-point scale, then prints the whole + tenths. Pure read, no scan.
execute store result score @s ec.wf_dr run attribute @s luck get 10
# Whole part + tenths (the value is luck*10; e.g. 185 -> +18.5).
scoreboard players operation @s ec.wf_drw = @s ec.wf_dr
scoreboard players operation @s ec.wf_drw /= #10 ec.const
scoreboard players operation @s ec.wf_drt = @s ec.wf_dr
scoreboard players operation @s ec.wf_drt %= #10 ec.const
execute if score @s ec.wf_drt matches ..-1 run scoreboard players operation @s ec.wf_drt *= #-1 ec.const
execute unless entity @s[tag=ab_q] run title @s actionbar [{"text":"✦ Dream Rate: ","color":"yellow"},{"text":"+","color":"light_purple"},{"score":{"name":"@s","objective":"ec.wf_drw"},"color":"light_purple"},{"text":".","color":"light_purple"},{"score":{"name":"@s","objective":"ec.wf_drt"},"color":"light_purple"}]
