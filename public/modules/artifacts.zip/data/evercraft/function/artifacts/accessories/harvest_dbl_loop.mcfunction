# === ACCESSORY HARVEST BONUS — DOUBLE-HARVEST LOOP (D-FORTUNE-REWRITE, m2) ===
# Call (MACRO): function evercraft:artifacts/accessories/harvest_dbl_loop {drop:"<item>"}
# Run as @s = player. Rolls the double-harvest chance ONCE per remaining harvested item:
# #hb_n ec.temp = items left to roll (set by harvest_bonus, clamped <=64); #hb_dbl ec.temp =
# the per-item double% (read by harvest_bonus_read). For each item, on a winning roll, give +1
# of $(drop). Self-schedules down to 0 (bounded: at most 64 iterations, the harvest_bonus clamp).
# ONE writer of #hb_n is this loop (decrement) — harvest_bonus only SETS it before the first call.

# Decrement the remaining-item counter first (one roll per item).
scoreboard players remove #hb_n ec.temp 1

# Roll this item: 1..100 <= #hb_dbl wins a duplicate.
execute store result score #hb_droll ec.temp run random value 1..100
$execute if score #hb_droll ec.temp <= #hb_dbl ec.temp run give @s $(drop) 1

# Recurse while items remain (bounded by the <=64 clamp in harvest_bonus).
$execute if score #hb_n ec.temp matches 1.. run function evercraft:artifacts/accessories/harvest_dbl_loop {drop:"$(drop)"}
