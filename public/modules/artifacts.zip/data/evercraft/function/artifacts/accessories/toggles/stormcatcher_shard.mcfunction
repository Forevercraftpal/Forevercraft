# Stormcatcher Shard — Toggle Effect (Haste I)
# 0 = ON (default), 1 = OFF

execute unless score @s ec.t_storm matches 0..1 run scoreboard players set @s ec.t_storm 0

# Flip the toggle
scoreboard players operation #temp ec.t_storm = @s ec.t_storm
execute if score #temp ec.t_storm matches 0 run scoreboard players set @s ec.t_storm 1
execute if score #temp ec.t_storm matches 1 run scoreboard players set @s ec.t_storm 0

# Feedback
data modify storage evercraft:notify stage.c set value [{text:"Effect: ",color:"gray"},{text:"ENABLED",color:"green",bold:true},{text:" (Haste I)",color:"gray"}]
scoreboard players set #ndur ec.temp 45
execute if score @s ec.t_storm matches 0 run function evercraft:util/notify/emit
execute if score @s ec.t_storm matches 0 if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.chime master @s ~ ~ ~ 1 1.5
data modify storage evercraft:notify stage.c set value [{text:"Effect: ",color:"gray"},{text:"DISABLED",color:"red",bold:true},{text:" (Haste I)",color:"gray"}]
scoreboard players set #ndur ec.temp 45
execute if score @s ec.t_storm matches 1 run function evercraft:util/notify/emit
execute if score @s ec.t_storm matches 1 if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.chime master @s ~ ~ ~ 1 0.5
