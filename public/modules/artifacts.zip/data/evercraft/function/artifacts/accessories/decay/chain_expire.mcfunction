# Kill Chain expired — reset chain count and sentinel cooldown
scoreboard players set @s ec.kill_chain 0
scoreboard players set @s ec.chain_cd -1
