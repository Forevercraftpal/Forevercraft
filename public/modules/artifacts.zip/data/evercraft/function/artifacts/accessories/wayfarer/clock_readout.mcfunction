# Wayfarer — Day / Night Clock Action-bar Readout (U17 Sextant · U24 Omni-Codex)
# Run as @s = player. Sneak-triggered on-demand (gate at the call site). Reads `time query minecraft:day`
# (0..23999, 0 = dawn/06:00, 6000 = noon, 12000 = dusk/18:00, 18000 = midnight) into a temp score and
# reports a coarse phase of day on the action bar. Pure read, no loop.
execute store result score @s ec.wf_time run time query minecraft:day
scoreboard players set @s ec.wf_phase 0
execute if score @s ec.wf_time matches 0..2999 run scoreboard players set @s ec.wf_phase 1
execute if score @s ec.wf_time matches 3000..8999 run scoreboard players set @s ec.wf_phase 2
execute if score @s ec.wf_time matches 9000..11999 run scoreboard players set @s ec.wf_phase 3
execute if score @s ec.wf_time matches 12000..13999 run scoreboard players set @s ec.wf_phase 4
execute if score @s ec.wf_time matches 14000..21999 run scoreboard players set @s ec.wf_phase 5
execute if score @s ec.wf_time matches 22000..23999 run scoreboard players set @s ec.wf_phase 6
execute if score @s ec.wf_phase matches 1 unless entity @s[tag=ab_q] run title @s actionbar [{"text":"☼ ","color":"yellow"},{"text":"Dawn","color":"gold"},{"text":"  (safe — mobs burning soon)","color":"gray"}]
execute if score @s ec.wf_phase matches 2 unless entity @s[tag=ab_q] run title @s actionbar [{"text":"☼ ","color":"yellow"},{"text":"Morning","color":"gold"},{"text":"  (safe)","color":"gray"}]
execute if score @s ec.wf_phase matches 3 unless entity @s[tag=ab_q] run title @s actionbar [{"text":"☼ ","color":"yellow"},{"text":"Afternoon","color":"gold"},{"text":"  (safe)","color":"gray"}]
execute if score @s ec.wf_phase matches 4 unless entity @s[tag=ab_q] run title @s actionbar [{"text":"☾ ","color":"aqua"},{"text":"Dusk","color":"blue"},{"text":"  (mobs spawning)","color":"gray"}]
execute if score @s ec.wf_phase matches 5 unless entity @s[tag=ab_q] run title @s actionbar [{"text":"☾ ","color":"aqua"},{"text":"Night","color":"dark_blue"},{"text":"  (hostile)","color":"red"}]
execute if score @s ec.wf_phase matches 6 unless entity @s[tag=ab_q] run title @s actionbar [{"text":"☾ ","color":"aqua"},{"text":"Late Night","color":"blue"},{"text":"  (dawn approaching)","color":"gray"}]
execute if score @s ec.wf_phase matches 0 unless entity @s[tag=ab_q] run title @s actionbar [{"text":"☼ ","color":"yellow"},{"text":"Day","color":"gold"}]
