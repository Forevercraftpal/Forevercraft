# Wayfarer / Surveyor — Steady-Hand Caliper ghost cell (U16)
# Run AT the would-be placement cell's block-corner (the caller did `align xyz`, so the execution
# position is already this cell's NW-bottom corner). @s = the player (still the executor — `positioned`
# / `align` change only the position, not @s). Draws a faint cyan dust outline of the unit cube at this
# cell — 12 particles (the 8 cube corners + 4 vertical-edge accents), `force @s` so ONLY this player
# sees their own ghost. dust{color:[0.4,0.85,1.0]} is the architect's-cyan hue. Particle budget = 12,
# well under the ≤36 cap. No block-glow. Each `positioned ~dx ~dy ~dz` offsets from the inherited cell
# corner (NOT from @s), so the box lands on the targeted cell, not on the player.
# 8 cube corners:
execute positioned ~0.05 ~0.05 ~0.05 run particle minecraft:dust{color:[0.4,0.85,1.0],scale:0.7} ~ ~ ~ 0 0 0 0 1 force @s
execute positioned ~0.95 ~0.05 ~0.05 run particle minecraft:dust{color:[0.4,0.85,1.0],scale:0.7} ~ ~ ~ 0 0 0 0 1 force @s
execute positioned ~0.05 ~0.05 ~0.95 run particle minecraft:dust{color:[0.4,0.85,1.0],scale:0.7} ~ ~ ~ 0 0 0 0 1 force @s
execute positioned ~0.95 ~0.05 ~0.95 run particle minecraft:dust{color:[0.4,0.85,1.0],scale:0.7} ~ ~ ~ 0 0 0 0 1 force @s
execute positioned ~0.05 ~0.95 ~0.05 run particle minecraft:dust{color:[0.4,0.85,1.0],scale:0.7} ~ ~ ~ 0 0 0 0 1 force @s
execute positioned ~0.95 ~0.95 ~0.05 run particle minecraft:dust{color:[0.4,0.85,1.0],scale:0.7} ~ ~ ~ 0 0 0 0 1 force @s
execute positioned ~0.05 ~0.95 ~0.95 run particle minecraft:dust{color:[0.4,0.85,1.0],scale:0.7} ~ ~ ~ 0 0 0 0 1 force @s
execute positioned ~0.95 ~0.95 ~0.95 run particle minecraft:dust{color:[0.4,0.85,1.0],scale:0.7} ~ ~ ~ 0 0 0 0 1 force @s
# 4 vertical-edge-center accents (so the cube reads as a box, not 8 loose dots):
execute positioned ~0.05 ~0.5 ~0.05 run particle minecraft:dust{color:[0.4,0.85,1.0],scale:0.5} ~ ~ ~ 0 0 0 0 1 force @s
execute positioned ~0.95 ~0.5 ~0.05 run particle minecraft:dust{color:[0.4,0.85,1.0],scale:0.5} ~ ~ ~ 0 0 0 0 1 force @s
execute positioned ~0.05 ~0.5 ~0.95 run particle minecraft:dust{color:[0.4,0.85,1.0],scale:0.5} ~ ~ ~ 0 0 0 0 1 force @s
execute positioned ~0.95 ~0.5 ~0.95 run particle minecraft:dust{color:[0.4,0.85,1.0],scale:0.5} ~ ~ ~ 0 0 0 0 1 force @s
