# U10 Echolocator Shard (Family K Prospector — art-K) — bounded echo pulse toward open cavities
# Run as @s = player, at @s. Sneak-triggered on-demand (gate at the call site). UTILITY-FEASIBILITY
# RESCOPE: blocks CANNOT glow (entity-only) and a 24 b spherical air scan is infeasible (~thousands of
# `if block`). So this casts a small set of BOUNDED RAYS (8 cardinal/diagonal directions, ≤12 steps of
# 2 b each ≈ 24 b reach) and pings a sound + a particle wisp at the FIRST large air gap each ray finds
# — the "echo" of the nearest open cavity. NO block-glow, NO volume scan (≤8×12 = 96 bounded `if block`
# tests max, the directive's hard ray bound). Debounced by ec.pr_pingcd (40t = 2s).

# Cooldown gate (debounce). If still recharging, bail quietly.
execute if score @s ec.pr_pingcd matches 1.. run return 0
scoreboard players set @s ec.pr_pingcd 40

# Soft "ping out" cue at the player.
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.sculk_sensor.clicking player @s ~ ~ ~ 0.7 1.4
particle minecraft:sculk_soul ~ ~1 ~ 0.2 0.2 0.2 0.0 6 force @s

# Cast 8 rays from the player's feet (+1 up = eye-ish), each a bounded 12-step walk in 2 b strides.
# +X / -X / +Z / -Z (cardinals) + the 4 diagonals. Each resets the per-ray step counter then recurses.
execute positioned ~ ~1 ~ rotated 90 0 run function evercraft:artifacts/accessories/prospector/echo_cast
execute positioned ~ ~1 ~ rotated -90 0 run function evercraft:artifacts/accessories/prospector/echo_cast
execute positioned ~ ~1 ~ rotated 0 0 run function evercraft:artifacts/accessories/prospector/echo_cast
execute positioned ~ ~1 ~ rotated 180 0 run function evercraft:artifacts/accessories/prospector/echo_cast
execute positioned ~ ~1 ~ rotated 45 0 run function evercraft:artifacts/accessories/prospector/echo_cast
execute positioned ~ ~1 ~ rotated 135 0 run function evercraft:artifacts/accessories/prospector/echo_cast
execute positioned ~ ~1 ~ rotated -45 0 run function evercraft:artifacts/accessories/prospector/echo_cast
execute positioned ~ ~1 ~ rotated -135 0 run function evercraft:artifacts/accessories/prospector/echo_cast
