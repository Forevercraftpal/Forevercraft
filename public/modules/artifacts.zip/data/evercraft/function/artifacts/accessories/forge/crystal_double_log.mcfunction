# === MASTER SMITH'S CRYSTAL (C16) — DOUBLE-LOG ROLL (Family G, art-G) ===
# Run as @s = player, at @s. Called from craft_affinity/detect_ordinary_tool on a LOG delta with an
# axe + the Crystal held. FORTUNE-REWRITE m2 double-LOG half (the tree-crate half is already rolled
# by grant_verb class 2 -> harvest_bonus_crate; this does NOT roll the crate again -> no double crate).
# Reads the player's harvest-bonus odds (sets #hb_dbl), rolls ONE 1..100, and on a win gives a
# duplicate of the LOG that just dropped at the player's feet (read its Item.id into storage, then a
# macro give). One roll per break (not per log of the stack) — keeps it a per-break charm, not a sweep.

# Read odds: harvest_bonus_read is the ONE writer of #hb_dbl / ec.hb_active. The Crystal sets both.
function evercraft:artifacts/accessories/harvest_bonus_read
execute unless score @s ec.hb_active matches 1 run return 0
execute unless score #hb_dbl ec.temp matches 1.. run return 0

# Roll the double-log chance once.
execute store result score #hb_droll ec.temp run random value 1..100
execute unless score #hb_droll ec.temp <= #hb_dbl ec.temp run return 0

# WIN: read the nearest fresh dropped item's id into storage, then macro-give one more of it. This
# fires ONLY on the LUMBERFELL axe class-2 path (a confirmed log/stem delta — a log was just broken),
# so the nearest ground drop at the player IS that log; we don't need (and 26.1 doesn't support) a
# #tag inside an item-entity NBT id selector. Guard: only if a fresh item drop is actually nearby
# (the break may have routed the drop straight to inventory at point-blank — distance=..4 catches the
# ground drop). The duplicate matches the broken log's exact id (read from the drop itself).
execute store success score #g_haslog ec.temp if entity @e[type=item,distance=..4,limit=1]
execute if score #g_haslog ec.temp matches 1 run data modify storage evercraft:forge_temp log_id set from entity @e[type=item,distance=..4,limit=1,sort=nearest] Item.id
execute if score #g_haslog ec.temp matches 1 run function evercraft:artifacts/accessories/forge/crystal_give_log with storage evercraft:forge_temp
