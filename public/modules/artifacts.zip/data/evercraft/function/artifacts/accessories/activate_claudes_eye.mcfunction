# Claude's Eye — Mob Vision Activation (sneak + mainhand)
# Exquisite: 32 blocks all entities, 15s glow, 45s cooldown (900 ticks)

# Check cooldown
data modify storage evercraft:notify stage.c set value [{text:"Recharging... ",color:"gray"},{text:"(",color:"dark_gray"},{score:{name:"@s",objective:"ec.ceye_cd"},color:"dark_gray"},{text:" ticks)",color:"dark_gray"}]
scoreboard players set #ndur ec.temp 45
execute if score @s ec.ceye_cd matches 1.. run function evercraft:util/notify/emit
execute if score @s ec.ceye_cd matches 1.. run return 0

# Apply glowing to all non-player entities within 32 blocks for 15s
execute at @s run effect give @e[type=!player,distance=..32] glowing 15 0 false

# Set cooldown
scoreboard players set @s ec.ceye_cd 45

# Feedback
data modify storage evercraft:notify stage.c set value [{text:"Omniscience activated! ",color:"light_purple"},{text:"(15s)",color:"gray"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute at @s run particle end_rod ~ ~1 ~ 1.5 1.5 1.5 0.05 13
execute at @s if score @s ec.fx_snd matches 1.. run playsound minecraft:block.beacon.activate player @s ~ ~ ~ 0.7 2.0
