# Berserker Frenzy expired — reset the frenzy stack count and sentinel cooldown
# (the chain_expire idiom, on the berserker_totem's OWN dedicated counters).
scoreboard players set @s ec.berserk_chain 0
scoreboard players set @s ec.berserk_cd -1
