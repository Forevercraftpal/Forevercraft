# BUG-002 FIX: Per-player Battle Tempo decay (replaces global schedule+@a)
scoreboard players set @s ec.battle_tempo 0
scoreboard players set @s ec.tempo_cd -1
