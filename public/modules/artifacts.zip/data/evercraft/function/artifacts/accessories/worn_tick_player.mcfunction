# Worn Artifact Abilities — Per-player check
# Run as @s (player) at @s
# OPT: Extracted from worn_tick to avoid 17 @a selector evaluations

# OPT: Early exit if no armor slot has custom_data AND the 1-extra-tick keep-alive tag is clear.
# 4 quick checks vs 20+ specific artifact checks for players in vanilla gear.
# (2026-06-06) CLEANUP-PERSISTENCE: the worn-armor attribute modifiers below (cloudstep_boots_fall,
# wolf/creed_boots_sprint, titan_boots_wme, verdant/dragonmaster/ender_dragon/infernal *_fall/_kb) are
# PLAYER-attached (added via `attribute @s modifier add`) and only ever stripped by the `unless items ...
# remove` lines further down. Those strips sit BEHIND this early-exit, so on the tick a player removes
# their LAST custom-data armor piece a bare `return 0` here would bounce out before the strip and the
# modifier would linger forever. ec.has_worn_armor (set at the tail of this fn whenever artifact armor is
# worn) persists exactly ONE extra tick after removal — like ec.has_accessory does for the loose strips —
# so the post-removal pass still flows PAST this gate, reaches every `unless ... remove`, strips the
# lingering modifiers, and only THEN (next tick) early-exits with everything already clean.
execute unless entity @s[tag=ec.has_worn_armor] unless items entity @s armor.head *[custom_data~{}] unless items entity @s armor.chest *[custom_data~{}] unless items entity @s armor.legs *[custom_data~{}] unless items entity @s armor.feet *[custom_data~{}] run return 0

# Shadowstep Boots — Invisibility while sneaking
execute if predicate evercraft:is_sneaking if items entity @s armor.feet *[custom_data~{ability:"shadow_walk"}] run effect give @s invisibility 3 0 false
execute if predicate evercraft:is_sneaking if items entity @s armor.feet *[custom_data~{ability:"shadow_walk"}] run particle smoke ~ ~0.1 ~ 0.2 0 0.2 0.01 1

# Warden Helm — Night Vision + Darkness immunity when worn (enderscale_eye darkness-clear idiom).
execute if items entity @s armor.head *[custom_data~{ability:"warden_affinity"}] run effect give @s night_vision 15 0 false
execute if items entity @s armor.head *[custom_data~{ability:"warden_affinity"}] run effect clear @s darkness

# Dark Helmet (Helm of Shadows) — Night Vision passive + Invisibility while sneaking
execute if items entity @s armor.head *[custom_data~{ability:"shadow_veil"}] run effect give @s night_vision 15 0 false
execute if predicate evercraft:is_sneaking if items entity @s armor.head *[custom_data~{ability:"shadow_veil"}] run effect give @s invisibility 3 0 false
execute if predicate evercraft:is_sneaking if items entity @s armor.head *[custom_data~{ability:"shadow_veil"}] run particle smoke ~ ~1.5 ~ 0.3 0.3 0.3 0.01 1

# Phoenix Helm/Plate — Absorption I (rebirth buffer)
execute if items entity @s armor.head *[custom_data~{ability:"rebirth"}] run effect give @s absorption 5 0 false
execute if items entity @s armor.chest *[custom_data~{ability:"rebirth"}] run effect give @s absorption 5 1 false

# Cloudstep Boots — Jump Boost III (pseudo double jump)
execute if items entity @s armor.feet *[custom_data~{ability:"double_jump"}] run effect give @s jump_boost 5 2 false
# AR-P2-1: tag-write for double_jump_tick (lets the 2t cadence skip non-wearers via tag-filter).
execute if items entity @s armor.feet *[custom_data~{ability:"double_jump"}] run tag @s add ec.has_dj_boots
execute unless items entity @s armor.feet *[custom_data~{ability:"double_jump"}] run tag @s remove ec.has_dj_boots
# No fall damage — fall_damage_multiplier -1.0 (featherscale_down idiom; remove-then-add self-strips here
# on removal — dragonmaster_boots_fall pattern). ability:"double_jump" is unique to cloudstep_boots so the key is safe.
execute unless items entity @s armor.feet *[custom_data~{ability:"double_jump"}] run attribute @s fall_damage_multiplier modifier remove evercraft:cloudstep_boots_fall
execute if items entity @s armor.feet *[custom_data~{ability:"double_jump"}] run attribute @s fall_damage_multiplier modifier add evercraft:cloudstep_boots_fall -1.0 add_value

# Elderguard Legs — Thorns aura (damage nearby attackers) + Dolphin's Grace in water
execute if items entity @s armor.legs *[custom_data~{ability:"damage_reflect"}] as @e[type=#evercraft:hostile_mobs,distance=..2,nbt={HurtTime:0s}] run damage @s 1 minecraft:thorns
execute if predicate evercraft:in_water if items entity @s armor.legs *[custom_data~{ability:"damage_reflect"}] run effect give @s dolphins_grace 5 0 false

# ============================================
# JOURNEY SET — Per-piece Mining Abilities
# ============================================
execute if items entity @s armor.head *[custom_data~{artifact:"journey_helmet"}] run effect give @s night_vision 15 0 false
execute if items entity @s armor.chest *[custom_data~{artifact:"journey_chestplate"}] run effect give @s resistance 5 0 false
execute if items entity @s armor.legs *[custom_data~{artifact:"journey_leggings"}] run effect give @s haste 5 0 false
execute if items entity @s armor.feet *[custom_data~{artifact:"journey_boots"}] run effect give @s slow_falling 5 0 false

# ============================================
# SPELUNKER SET — Per-piece Explorer Abilities
# ============================================
execute if items entity @s armor.head *[custom_data~{artifact:"spelunker_helmet"}] run effect give @s night_vision 15 0 false
execute if items entity @s armor.chest *[custom_data~{artifact:"spelunker_chestplate"}] run effect give @s resistance 5 0 false
execute if items entity @s armor.legs *[custom_data~{artifact:"spelunker_leggings"}] run effect give @s speed 5 0 false
execute if items entity @s armor.feet *[custom_data~{artifact:"spelunker_boots"}] run effect give @s jump_boost 5 0 false

# ============================================
# COMMON — Per-piece Passives
# ============================================
# Fox Chestplate — Fox's Cunning: Speed I while sneaking
execute if predicate evercraft:is_sneaking if items entity @s armor.chest *[custom_data~{artifact:"common_fox_chestplate"}] run effect give @s speed 3 0 false

# Thief Helmet — Keen Eye: Hostile mobs within 12b glow (passive while worn)
execute if items entity @s armor.head *[custom_data~{artifact:"common_thief_helmet"}] as @e[type=#evercraft:hostile_mobs,distance=..12] run effect give @s glowing 3 0 false

# Wolf Boots — Pack Runner: +8% Speed while sprinting (sprinters_anklet idiom, slot-keyed)
execute if items entity @s armor.feet *[custom_data~{artifact:"common_wolf_boots"}] run attribute @s movement_speed modifier remove evercraft:wolf_boots_sprint
execute if predicate evercraft:sprinting if items entity @s armor.feet *[custom_data~{artifact:"common_wolf_boots"}] run attribute @s movement_speed modifier add evercraft:wolf_boots_sprint 0.08 add_multiplied_base
execute unless items entity @s armor.feet *[custom_data~{artifact:"common_wolf_boots"}] run attribute @s movement_speed modifier remove evercraft:wolf_boots_sprint

# Ocelot Leggings — Cat's Grace: +6 safe_fall_distance (baked attr in loot table; no tick needed)
# Ore Helmet — Ore Sense: +1 mining_efficiency (baked attr in loot table; no tick needed)

# Guard Helmet — Watchman's Vigil: Hostile mobs within 10b glow while NOT sneaking
execute unless predicate evercraft:is_sneaking if items entity @s armor.head *[custom_data~{artifact:"uncommon_guard_helmet"}] as @e[type=#evercraft:hostile_mobs,distance=..10] run effect give @s glowing 3 0 false

# Dark Chestplate — Night Sight: Night Vision while sneaking
execute if predicate evercraft:is_sneaking if items entity @s armor.chest *[custom_data~{artifact:"uncommon_dark_chestplate"}] run effect give @s night_vision 15 0 false

# Creed Boots — Unfaltering Charge: +8% Speed while sprinting (sprinters_anklet idiom, slot-keyed)
execute if items entity @s armor.feet *[custom_data~{artifact:"uncommon_creed_boots"}] run attribute @s movement_speed modifier remove evercraft:creed_boots_sprint
execute if predicate evercraft:sprinting if items entity @s armor.feet *[custom_data~{artifact:"uncommon_creed_boots"}] run attribute @s movement_speed modifier add evercraft:creed_boots_sprint 0.08 add_multiplied_base
execute unless items entity @s armor.feet *[custom_data~{artifact:"uncommon_creed_boots"}] run attribute @s movement_speed modifier remove evercraft:creed_boots_sprint

# Royal Leggings — Regal Poise: +1% dodge (ec.acc_dodge lane; runs AFTER player_tick's reset-to-0 at :23)
execute if items entity @s armor.legs *[custom_data~{artifact:"uncommon_royal_leggings"}] run scoreboard players add @s ec.acc_dodge 4

# ============================================
# RARE — Per-piece Identities (Wave 1-B)
# ============================================
# Dragon Boots — Warm Scale: freeze-immune step (clear freeze buildup while standing in powder snow).
# The -0.3 fall_damage_multiplier half is a baked static attr in the loot table (always-on, no tick).
execute if items entity @s armor.feet *[custom_data~{artifact:"dragon_boots"}] if block ~ ~ ~ powder_snow run data merge entity @s {TicksFrozen:0}

# Highland Leggings — Mountaineer: sneak grants brief Slow Falling + Jump Boost I (nimble in the high passes)
execute if predicate evercraft:is_sneaking if items entity @s armor.legs *[custom_data~{artifact:"highland_leggings"}] run effect give @s slow_falling 2 0 true
execute if predicate evercraft:is_sneaking if items entity @s armor.legs *[custom_data~{artifact:"highland_leggings"}] run effect give @s jump_boost 2 0 true

# Opulent Chestplate — Merchant's Fortune: +2 Dream Rate (baked static luck attr in loot table; no tick)
# Plate Chestplate — Bulwark: +0.15 knockback_resistance (baked static attr in loot table; no tick)

# Piglin Helmet — Bastion Ward: Fire Resistance pulse while in the Nether (salvaged bastion helm)
execute if items entity @s armor.head *[custom_data~{artifact:"piglin_helmet"}] if dimension the_nether run effect give @s fire_resistance 5 0 false

# ============================================
# ORNATE — Per-piece Identities (Wave 1-B)
# ============================================
# Leggings of Fortitude — Bulwark's Footing: Resistance I while stationary >=1s, lost on move.
# (artifact id is "leggings_fortitude".) worn_tick runs at 1s cadence: store this tick's Pos[0]/Pos[2]
# (x10, int) and compare to last tick's stored value. Unchanged on both axes => didn't move this second.
# ec.lof_still counts up while still and resets on move; Resistance I (harmonize-gated) once >=1 still tick.
execute if items entity @s armor.legs *[custom_data~{artifact:"leggings_fortitude"}] store result score #lof_x ec.var run data get entity @s Pos[0] 10
execute if items entity @s armor.legs *[custom_data~{artifact:"leggings_fortitude"}] store result score #lof_z ec.var run data get entity @s Pos[2] 10
execute if items entity @s armor.legs *[custom_data~{artifact:"leggings_fortitude"}] unless score #lof_x ec.var = @s ec.lof_px run scoreboard players set @s ec.lof_still 0
execute if items entity @s armor.legs *[custom_data~{artifact:"leggings_fortitude"}] unless score #lof_z ec.var = @s ec.lof_pz run scoreboard players set @s ec.lof_still 0
execute if items entity @s armor.legs *[custom_data~{artifact:"leggings_fortitude"}] if score #lof_x ec.var = @s ec.lof_px if score #lof_z ec.var = @s ec.lof_pz run scoreboard players add @s ec.lof_still 1
execute if items entity @s armor.legs *[custom_data~{artifact:"leggings_fortitude"}] if score @s ec.lof_still matches 1.. if score @s ec.h_resist matches ..1 run effect give @s resistance 3 0 true
execute if items entity @s armor.legs *[custom_data~{artifact:"leggings_fortitude"}] run scoreboard players operation @s ec.lof_px = #lof_x ec.var
execute if items entity @s armor.legs *[custom_data~{artifact:"leggings_fortitude"}] run scoreboard players operation @s ec.lof_pz = #lof_z ec.var
execute unless items entity @s armor.legs *[custom_data~{artifact:"leggings_fortitude"}] run scoreboard players set @s ec.lof_still 0

# Titan's Plate — Titan's Bulwark: sneak + look-down braces a Resistance II + Slowness I stance (8s, 12s cd).
# Passive +0.1 knockback_resistance is a baked static attr in the loot table (always-on, no tick).
execute if predicate evercraft:is_sneaking if predicate evercraft:looking_down if items entity @s armor.chest *[custom_data~{artifact:"titans_plate"}] unless score @s ec.cd_titan matches 1.. run function evercraft:artifacts/abilities/titans_brace

# Windwalker Boots — Skyrunner: pseudo double-jump (Jump Boost III) + tag the 2t cadence. Keeps +15% Speed
# via the baked movement_speed attr in the loot table. Keyed by artifact id (not ability:"double_jump")
# so the +15% speed and the jump can coexist on the same boots.
execute if items entity @s armor.feet *[custom_data~{artifact:"windwalker_boots"}] run effect give @s jump_boost 5 2 false
execute if items entity @s armor.feet *[custom_data~{artifact:"windwalker_boots"}] run tag @s add ec.has_dj_boots

# Warriors Crown — Kill Chain: strength chain via bare player_killed_entity trigger + artifact-id early-exit
# (handler: artifacts/abilities/warriors_crown_kill). Keeps the +10% damage attr. No worn_tick line needed.

# ============================================
# ORNATE — Blood/Scarlet Set Per-piece Passives
# ============================================
# Helmet: Night Vision in dark areas (always on for simplicity)
execute if items entity @s armor.head *[custom_data~{artifact:"blood_helmet"}] run effect give @s night_vision 15 0 false
# Chestplate: +1 damage to withered targets
execute if items entity @s armor.chest *[custom_data~{artifact:"blood_chestplate"}] at @s as @e[type=!player,distance=..5,limit=1,sort=nearest,nbt={HurtTime:10s,active_effects:[{id:"minecraft:wither"}]}] run damage @s 1 minecraft:mob_attack
# Leggings: red particle trail while sprinting
execute unless predicate evercraft:is_sneaking if items entity @s armor.legs *[custom_data~{artifact:"blood_leggings"}] run particle dust{color:[0.8,0.1,0.1],scale:0.6} ~ ~0.1 ~ 0.2 0 0.2 0 1
# Boots: (stat piece — no active passive needed)

# ============================================
# ORNATE — Celestial/Star Shield Set Per-piece Passives
# ============================================
execute if items entity @s armor.head *[custom_data~{artifact:"celestial_helmet"}] run effect give @s night_vision 15 0 false
# Chestplate: Absorption I at night (DayTime 13000-23000)
execute if items entity @s armor.chest *[custom_data~{artifact:"celestial_chestplate"}] if score #visual_time ec.var matches 13000..23000 run effect give @s absorption 5 0 false
# Leggings: +5% speed at night
execute if items entity @s armor.legs *[custom_data~{artifact:"celestial_leggings"}] if score #visual_time ec.var matches 13000..23000 run effect give @s speed 5 0 false
# Boots: Slow Falling from Y>100
execute positioned ~ 100 ~ if entity @s[dy=255] if items entity @s armor.feet *[custom_data~{artifact:"celestial_boots"}] run effect give @s slow_falling 3 0 false

# ============================================
# ORNATE — Crystal/Emerald Set Per-piece Passives
# ============================================
# Helmet: (projectile protection — attribute, skip active)
# Chestplate: (armor toughness in water — attribute, skip active)
# Leggings: KB resistance (attribute, skip active)
# Boots: Speed I on ice/snow
execute if items entity @s armor.feet *[custom_data~{artifact:"crystal_boots"}] if block ~ ~-1 ~ #minecraft:ice run effect give @s speed 3 0 false

# ============================================
# ORNATE — Dragonslayer Set Per-piece Passives
# ============================================
execute if items entity @s armor.head *[custom_data~{artifact:"dragonslayer_helmet"}] run effect give @s fire_resistance 15 0 false
# Leggings: KB resistance (attribute, skip active)
# Boots: No fall damage (handled via safe_fall attribute, skip active)

# ============================================
# ORNATE — Ender Set Per-piece Passives
# ============================================
# Helmet: Endermen don't aggro (already set bonus, skip)
# Chestplate: Resistance I in End
execute if items entity @s armor.chest *[custom_data~{artifact:"ender_chestplate"}] if dimension the_end run effect give @s resistance 5 0 false
# Leggings: Speed I in End
execute if items entity @s armor.legs *[custom_data~{artifact:"ender_leggings"}] if dimension the_end run effect give @s speed 5 0 false
# Boots: Safe fall (attribute, skip active)

# ============================================
# ORNATE — Frost Set Per-piece Passives
# ============================================
execute if items entity @s armor.head *[custom_data~{artifact:"frost_helmet"}] run effect give @s water_breathing 15 0 false
# Chestplate: Mobs within 2b get Slowness I
execute if items entity @s armor.chest *[custom_data~{artifact:"frost_chestplate"}] as @e[type=#evercraft:hostile_mobs,distance=..2] run effect give @s slowness 3 0 false
# Leggings: Speed I on snow/ice
execute if items entity @s armor.legs *[custom_data~{artifact:"frost_leggings"}] if block ~ ~-1 ~ #minecraft:ice run effect give @s speed 3 0 false
execute if items entity @s armor.legs *[custom_data~{artifact:"frost_leggings"}] if block ~ ~-1 ~ snow_block run effect give @s speed 3 0 false
# Boots: Jump Boost I on snow
execute if items entity @s armor.feet *[custom_data~{artifact:"frost_boots"}] if block ~ ~-1 ~ snow_block run effect give @s jump_boost 3 0 false

# ============================================
# ORNATE — Golem/Stalwart Set Per-piece Passives
# ============================================
# Helmet: Mining Fatigue immunity
execute if items entity @s armor.head *[custom_data~{artifact:"golem_helmet"}] run effect clear @s mining_fatigue
# Chestplate: KB resistance (attribute, skip active)
# Leggings: Haste I while on stone
execute if items entity @s armor.legs *[custom_data~{artifact:"golem_leggings"}] if block ~ ~-1 ~ #minecraft:base_stone_overworld run effect give @s haste 3 0 false
# Boots: No fall damage (attribute, skip active)

# ============================================
# ORNATE — Nature/Sakura Set Per-piece Passives
# ============================================
# Helmet: Regen I on natural ground
execute if items entity @s armor.head *[custom_data~{artifact:"nature_helmet"}] if block ~ ~-1 ~ #evercraft:natural_ground run effect give @s regeneration 3 0 false
# Chestplate: Poison immunity
execute if items entity @s armor.chest *[custom_data~{artifact:"nature_chestplate"}] run effect clear @s poison
# Leggings: Speed I in forests (simplified — on grass)
execute if items entity @s armor.legs *[custom_data~{artifact:"nature_leggings"}] if block ~ ~-1 ~ grass_block run effect give @s speed 3 0 false
# Boots: No crop trampling (can't prevent in datapack — skip)

# ============================================
# ORNATE — Netherwalker Set Per-piece Passives
# ============================================
execute if items entity @s armor.head *[custom_data~{artifact:"netherwalker_helmet"}] run effect give @s fire_resistance 15 0 false
# Leggings: Speed I in Nether
execute if items entity @s armor.legs *[custom_data~{artifact:"netherwalker_leggings"}] if dimension the_nether run effect give @s speed 5 0 false
# Boots: Fire Resistance (covered by helmet, skip)

# ============================================
# ORNATE — Ocean/Prismarine Set Per-piece Passives
# ============================================
execute if items entity @s armor.head *[custom_data~{artifact:"ocean_helmet"}] run effect give @s water_breathing 15 0 false
# Chestplate: Conduit Power in rain
execute if predicate evercraft:is_raining if items entity @s armor.chest *[custom_data~{artifact:"ocean_chestplate"}] run effect give @s conduit_power 5 0 false
# Leggings: Dolphin's Grace
execute if predicate evercraft:in_water if items entity @s armor.legs *[custom_data~{artifact:"ocean_leggings"}] run effect give @s dolphins_grace 5 0 false
# Boots: Depth Strider (attribute, skip active)

# ============================================
# ORNATE — Sculk/Romeo's Set Per-piece Passives
# ============================================
# Helmet: Darkness immunity
execute if items entity @s armor.head *[custom_data~{artifact:"sculk_helmet"}] run effect clear @s darkness
# Chestplate: Vibration sense (mobs glow when they attack nearby)
execute if items entity @s armor.chest *[custom_data~{artifact:"sculk_chestplate"}] as @e[type=#evercraft:hostile_mobs,distance=..16,nbt={HurtTime:10s}] run effect give @s glowing 3 0 false
# Leggings: Speed I underground (below Y=50)
execute positioned ~ 50 ~ unless entity @s[dy=255] if items entity @s armor.legs *[custom_data~{artifact:"sculk_leggings"}] run effect give @s speed 3 0 false
# Boots: (sculk sensor suppression not possible — skip)

# ============================================
# ORNATE — Storm/Petra's Set Per-piece Passives
# ============================================
# Helmet: Lightning immunity (via Fire Resistance during storms)
execute if predicate evercraft:is_raining if items entity @s armor.head *[custom_data~{artifact:"storm_helmet"}] run effect give @s fire_resistance 5 0 false
# Chestplate: Mobs within 3b get Weakness I during thunderstorms
execute if predicate evercraft:is_raining if items entity @s armor.chest *[custom_data~{artifact:"storm_chestplate"}] as @e[type=#evercraft:hostile_mobs,distance=..3] run effect give @s weakness 3 0 false
# Leggings: Speed II during rain
execute if predicate evercraft:is_raining if items entity @s armor.legs *[custom_data~{artifact:"storm_leggings"}] run effect give @s speed 3 1 false
# Boots: Jump Boost I during storms
execute if predicate evercraft:is_raining if items entity @s armor.feet *[custom_data~{artifact:"storm_boots"}] run effect give @s jump_boost 3 0 false

# ============================================
# ORNATE — Phantom Set Per-piece Passives
# ============================================
execute if items entity @s armor.head *[custom_data~{artifact:"phantom_helmet"}] run effect give @s night_vision 15 0 false
execute if items entity @s armor.chest *[custom_data~{artifact:"phantom_chestplate"}] run effect give @s slow_falling 5 0 false
# Leggings: Invisibility while sneaking at night
execute if predicate evercraft:is_sneaking if items entity @s armor.legs *[custom_data~{artifact:"phantom_leggings"}] if score #visual_time ec.var matches 13000..23000 run effect give @s invisibility 3 0 false
# Boots: No fall damage (attribute, skip active)

# ============================================
# ORNATE — Shadow Walker Set Per-piece Passives
# ============================================
execute if items entity @s armor.head *[custom_data~{artifact:"shadow_helmet"}] run effect give @s night_vision 15 0 false
# Chestplate: Invisibility while sneaking (2pc bonus handles this, skip)
# Leggings: +15% speed at night
execute if items entity @s armor.legs *[custom_data~{artifact:"shadow_leggings"}] if score #visual_time ec.var matches 13000..23000 run effect give @s speed 3 0 false
# Boots: (no step particles not possible — skip)

# ============================================
# ORNATE — Wither Set Per-piece Passives
# ============================================
# Helmet: Wither immunity
execute if items entity @s armor.head *[custom_data~{artifact:"wither_helmet"}] run effect clear @s wither
# Boots: Wither rose immunity (clear wither effect — same as helmet)
# Leggings/Chestplate: Wither reduction (covered by helmet immunity)

# ============================================
# EXQUISITE — Cloaked Skull Set Per-piece Passives
# ============================================
# Helmet: Undead mobs within 8b don't aggro (simplified: give them Weakness)
execute if items entity @s armor.head *[custom_data~{artifact:"cloaked_skull_helmet"}] as @e[type=#minecraft:undead,distance=..8] run effect give @s weakness 3 0 false
# Chestplate: Wither immunity
execute if items entity @s armor.chest *[custom_data~{artifact:"cloaked_skull_chestplate"}] run effect clear @s wither
# Leggings: Invisibility while sneaking
execute if predicate evercraft:is_sneaking if items entity @s armor.legs *[custom_data~{artifact:"cloaked_skull_leggings"}] run effect give @s invisibility 3 0 false
# Boots: Speed I at night
execute if items entity @s armor.feet *[custom_data~{artifact:"cloaked_skull_boots"}] if score #visual_time ec.var matches 13000..23000 run effect give @s speed 3 0 false

# ============================================
# EXQUISITE — Ember Set Per-piece Passives
# ============================================
execute if items entity @s armor.head *[custom_data~{artifact:"ember_helmet"}] run effect give @s fire_resistance 15 0 false
# Chestplate: Fire aura — hostile mobs within 2b catch fire
execute if items entity @s armor.chest *[custom_data~{artifact:"ember_chestplate"}] as @e[type=#evercraft:hostile_mobs,distance=..2] run data merge entity @s {Fire:40s}
# Leggings: Speed I in Nether
execute if items entity @s armor.legs *[custom_data~{artifact:"ember_leggings"}] if dimension the_nether run effect give @s speed 5 0 false
# Boots: Walk on magma safely (Fire Resistance covers this)

# ============================================
# EXQUISITE — Fireforged/Phoenix Set Per-piece Passives
# ============================================
# Helmet + Chestplate: Already have rebirth ability (handled above)
# Leggings: Speed I + fire particles while sprinting
execute unless predicate evercraft:is_sneaking if items entity @s armor.legs *[custom_data~{artifact:"phoenix_leggings"}] run effect give @s speed 5 0 false
execute unless predicate evercraft:is_sneaking if items entity @s armor.legs *[custom_data~{artifact:"phoenix_leggings"}] run particle flame ~ ~0.1 ~ 0.1 0 0.1 0.01 1
# Boots: No fall damage (attribute, skip active)

# ============================================
# EXQUISITE — Ninja Set Per-piece Passives
# ============================================
# Helmet: Night Vision in dark areas
execute if items entity @s armor.head *[custom_data~{artifact:"ninja_helmet"}] run effect give @s night_vision 15 0 false
# Chestplate: Invisibility while sneaking (2pc handles this)
# Leggings: +20% speed at night
execute if items entity @s armor.legs *[custom_data~{artifact:"ninja_leggings"}] if score #visual_time ec.var matches 13000..23000 run effect give @s speed 3 1 false
# Boots: No fall damage + silent (attribute, skip active)

# ============================================
# EXQUISITE — Space Set Per-piece Passives
# ============================================
execute if items entity @s armor.head *[custom_data~{artifact:"space_helmet"}] run effect give @s water_breathing 15 0 false
execute if items entity @s armor.chest *[custom_data~{artifact:"space_chestplate"}] run effect give @s slow_falling 5 0 false
execute if items entity @s armor.legs *[custom_data~{artifact:"space_leggings"}] run effect give @s jump_boost 5 2 false
# Boots: No fall damage (attribute, skip active)

# ============================================
# MYTHICAL — Dragonmaster/Wyrmrider Set Per-piece Passives
# ============================================
execute if items entity @s armor.head *[custom_data~{artifact:"dragonmaster_helmet"}] run effect give @s fire_resistance 15 0 false
# Chestplate: +10% damage to mobs on fire (check target has Fire)
execute if items entity @s armor.chest *[custom_data~{artifact:"dragonmaster_chestplate"}] at @s as @e[type=!player,distance=..5,limit=1,sort=nearest,nbt={HurtTime:10s}] if data entity @s {Fire:1s} run damage @s 1 minecraft:on_fire
# Leggings: Fire Immunity — leggings-keyed Fire Resistance (delivers the "Fire Immunity" headline).
execute if items entity @s armor.legs *[custom_data~{artifact:"dragonmaster_leggings"}] run effect give @s fire_resistance 5 0 true
# Chestplate: Knockback Immunity — knockback_resistance 1.0 (remove-then-add; stripped when not worn).
execute unless items entity @s armor.chest *[custom_data~{artifact:"dragonmaster_chestplate"}] run attribute @s knockback_resistance modifier remove evercraft:dragonmaster_chestplate_kb
execute if items entity @s armor.chest *[custom_data~{artifact:"dragonmaster_chestplate"}] run attribute @s knockback_resistance modifier add evercraft:dragonmaster_chestplate_kb 1.0 add_value
# Boots: No Fall Damage — fall_damage_multiplier -1.0 (remove-then-add) + flame trail particles.
execute unless items entity @s armor.feet *[custom_data~{artifact:"dragonmaster_boots"}] run attribute @s fall_damage_multiplier modifier remove evercraft:dragonmaster_boots_fall
execute if items entity @s armor.feet *[custom_data~{artifact:"dragonmaster_boots"}] run attribute @s fall_damage_multiplier modifier add evercraft:dragonmaster_boots_fall -1.0 add_value
execute unless predicate evercraft:is_sneaking if items entity @s armor.feet *[custom_data~{artifact:"dragonmaster_boots"}] run particle flame ~ ~0.1 ~ 0.1 0 0.1 0.01 1

# ============================================
# MYTHICAL — Ender Dragon/Voidscale Set Per-piece Passives
# ============================================
execute if items entity @s armor.head *[custom_data~{artifact:"ender_dragon_helmet"}] run effect give @s night_vision 15 0 false
execute if items entity @s armor.head *[custom_data~{artifact:"ender_dragon_helmet"}] run effect clear @s darkness
# Chestplate: Knockback Immunity — knockback_resistance 1.0 (remove-then-add; was previously skipped).
execute unless items entity @s armor.chest *[custom_data~{artifact:"ender_dragon_chestplate"}] run attribute @s knockback_resistance modifier remove evercraft:ender_dragon_chestplate_kb
execute if items entity @s armor.chest *[custom_data~{artifact:"ender_dragon_chestplate"}] run attribute @s knockback_resistance modifier add evercraft:ender_dragon_chestplate_kb 1.0 add_value
# Leggings: Speed I in End
execute if items entity @s armor.legs *[custom_data~{artifact:"ender_dragon_leggings"}] if dimension the_end run effect give @s speed 5 0 false
# Boots: No Fall Damage — fall_damage_multiplier -1.0 (remove-then-add) + Slow Falling for the glide.
execute unless items entity @s armor.feet *[custom_data~{artifact:"ender_dragon_boots"}] run attribute @s fall_damage_multiplier modifier remove evercraft:ender_dragon_boots_fall
execute if items entity @s armor.feet *[custom_data~{artifact:"ender_dragon_boots"}] run attribute @s fall_damage_multiplier modifier add evercraft:ender_dragon_boots_fall -1.0 add_value
execute if items entity @s armor.feet *[custom_data~{artifact:"ender_dragon_boots"}] run effect give @s slow_falling 5 0 false

# ============================================
# MYTHICAL — Infernal/Lava Warrior Set Per-piece Passives
# ============================================
execute if items entity @s armor.head *[custom_data~{artifact:"infernal_helmet"}] run effect give @s fire_resistance 15 0 false
# Chestplate: Knockback Immunity — knockback_resistance 1.0 (remove-then-add) + fire aura below.
execute unless items entity @s armor.chest *[custom_data~{artifact:"infernal_chestplate"}] run attribute @s knockback_resistance modifier remove evercraft:infernal_chestplate_kb
execute if items entity @s armor.chest *[custom_data~{artifact:"infernal_chestplate"}] run attribute @s knockback_resistance modifier add evercraft:infernal_chestplate_kb 1.0 add_value
# Chestplate: Mobs within 3b take 1 fire damage/sec
execute if items entity @s armor.chest *[custom_data~{artifact:"infernal_chestplate"}] as @e[type=#evercraft:hostile_mobs,distance=..3] run damage @s 1 minecraft:on_fire
# Leggings: Speed I in Nether
execute if items entity @s armor.legs *[custom_data~{artifact:"infernal_leggings"}] if dimension the_nether run effect give @s speed 5 0 false
# Boots: No Fall Damage — fall_damage_multiplier -1.0 (remove-then-add). Fire Resistance covered by set helmet.
execute unless items entity @s armor.feet *[custom_data~{artifact:"infernal_boots"}] run attribute @s fall_damage_multiplier modifier remove evercraft:infernal_boots_fall
execute if items entity @s armor.feet *[custom_data~{artifact:"infernal_boots"}] run attribute @s fall_damage_multiplier modifier add evercraft:infernal_boots_fall -1.0 add_value

# ============================================
# MYTHICAL — Titan/Tempest Set Per-piece Passives
# ============================================
execute if items entity @s armor.head *[custom_data~{artifact:"titan_helmet"}] run effect give @s water_breathing 15 0 false
execute if items entity @s armor.head *[custom_data~{artifact:"titan_helmet"}] run effect give @s conduit_power 5 0 false
# Chestplate: Resistance I in water/rain
execute if predicate evercraft:in_water if items entity @s armor.chest *[custom_data~{artifact:"titan_chestplate"}] run effect give @s resistance 5 0 false
execute if predicate evercraft:is_raining if items entity @s armor.chest *[custom_data~{artifact:"titan_chestplate"}] run effect give @s resistance 5 0 false
# Leggings: Dolphin's Grace
execute if predicate evercraft:in_water if items entity @s armor.legs *[custom_data~{artifact:"titan_leggings"}] run effect give @s dolphins_grace 5 0 false
# Boots: Deep Strider — water_movement_efficiency +1.0 (26.1 Depth-Strider successor; full underwater
# walk-speed = the "Depth Strider III" headline). remove-then-add self-strips here on removal (the
# dragonmaster_boots_fall worn-armor idiom; the 1-extra-tick keep-alive at player_tick's tail fires it).
execute unless items entity @s armor.feet *[custom_data~{artifact:"titan_boots"}] run attribute @s water_movement_efficiency modifier remove evercraft:titan_boots_wme
execute if items entity @s armor.feet *[custom_data~{artifact:"titan_boots"}] run attribute @s water_movement_efficiency modifier add evercraft:titan_boots_wme 1.0 add_value

# ============================================
# MYTHICAL — Verdant/Grove Set Per-piece Passives
# ============================================
execute if items entity @s armor.head *[custom_data~{artifact:"verdant_helmet"}] if block ~ ~-1 ~ #evercraft:natural_ground run effect give @s regeneration 3 0 false
execute if items entity @s armor.chest *[custom_data~{artifact:"verdant_chestplate"}] run effect clear @s poison
# Leggings: Speed I in forests (on grass)
execute if items entity @s armor.legs *[custom_data~{artifact:"verdant_leggings"}] if block ~ ~-1 ~ grass_block run effect give @s speed 3 0 false
# Boots: Tilled Stride — Speed I while on tilled/natural ground (farmland + the dirt/grass/moss/mud family)
# + a -0.3 fall_damage_multiplier (verdant_boots has no attr array to bake into, so the fall modifier rides
# the remove-then-add worn idiom and self-strips here on removal — the dragonmaster_boots_fall pattern).
execute if items entity @s armor.feet *[custom_data~{artifact:"verdant_boots"}] if block ~ ~-1 ~ farmland run effect give @s speed 3 0 true
execute if items entity @s armor.feet *[custom_data~{artifact:"verdant_boots"}] if block ~ ~-1 ~ #evercraft:natural_ground run effect give @s speed 3 0 true
execute unless items entity @s armor.feet *[custom_data~{artifact:"verdant_boots"}] run attribute @s fall_damage_multiplier modifier remove evercraft:verdant_boots_fall
execute if items entity @s armor.feet *[custom_data~{artifact:"verdant_boots"}] run attribute @s fall_damage_multiplier modifier add evercraft:verdant_boots_fall -0.3 add_multiplied_base

# ============================================
# MYTHICAL — Hero/Eternal Set Per-piece Passives
# ============================================
execute if items entity @s armor.head *[custom_data~{artifact:"hero_helmet"}] run effect give @s night_vision 15 0 false
execute if items entity @s armor.chest *[custom_data~{artifact:"hero_chestplate"}] run effect give @s absorption 5 0 false
execute if items entity @s armor.legs *[custom_data~{artifact:"hero_leggings"}] run effect give @s speed 5 0 false
execute if items entity @s armor.feet *[custom_data~{artifact:"hero_boots"}] run effect give @s jump_boost 5 0 false

# ============================================
# === CLEANUP-PERSISTENCE KEEP-ALIVE TAG ===
# ============================================
# (2026-06-06) ec.has_worn_armor mirrors the ec.has_accessory 1-extra-tick idiom for WORN ARMOR.
# Set it whenever any armor slot holds an artifact (is_artifact:true), clear it otherwise. Because this
# runs at the TAIL of the fn, on the tick a player removes their last armor piece the tag is STILL set
# from the prior tick (this fn was reached via the tag), all the `unless ... remove` strips above already
# ran this pass, and we now clear the tag — so the NEXT tick the early-exit at the top fires cleanly.
# The dispatch in accessories/tick gates on (armor.* is_artifact:true) OR tag=ec.has_worn_armor, so the
# post-removal pass is guaranteed to be scheduled even though no artifact armor remains in any slot.
tag @s remove ec.has_worn_armor
execute if items entity @s armor.* *[custom_data~{is_artifact:true}] run tag @s add ec.has_worn_armor
