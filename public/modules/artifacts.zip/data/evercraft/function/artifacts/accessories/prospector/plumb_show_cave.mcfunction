# U6 Plumb-Bob Token — readout (cave/air pocket detected below). MACRO. Call:
#   function evercraft:artifacts/accessories/prospector/plumb_show_cave with storage evercraft:pr_temp
#   $(depth) = blocks-to-bedrock-floor (Pos[1] + 64).
$execute unless entity @s[tag=ab_q] run title @s actionbar [{text:"⊻ ",color:"blue"},{text:"Depth: ",color:"#9AB8E0"},{text:"$(depth) to the floor",color:"white"},{text:"  •  cave below!",color:"gold"}]
