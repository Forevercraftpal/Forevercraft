# Javelin Class — On Melee Hit
# Called from on_hit router (trident in mainhand)

# === MOMENTUM: Grant Throw Momentum (5s = 100 ticks) ===
scoreboard players set @s ec.jv_thrown 100

# === STRIKE MOMENTUM BONUS (melee hit during ec.jv_melee window) ===
# Tiers 2-4: +2 bonus damage, Tiers 5-6: +3 bonus damage
execute if score @s ec.jv_melee matches 1.. if score @s ec.jv_tier matches 2..4 at @s run damage @e[type=!player,distance=..5,limit=1,sort=nearest,nbt={HurtTime:10s}] 2 evercraft:bonus_strike
execute if score @s ec.jv_melee matches 1.. if score @s ec.jv_tier matches 5..6 at @s run damage @e[type=!player,distance=..5,limit=1,sort=nearest,nbt={HurtTime:10s}] 3 evercraft:bonus_strike

# === COOLDOWN CHECK — skip ability if on cooldown ===
data modify storage evercraft:notify stage.c set value [{text:"Ability cooldown: ",color:"gray"},{score:{name:"@s",objective:"ec.jv_cd"},color:"aqua"},{text:"s",color:"gray"}]
scoreboard players set #ndur ec.temp 45
execute if score @s ec.jv_cd matches 1.. run return run function evercraft:util/notify/emit

# === ROUTE TO ARTIFACT-SPECIFIC MELEE ABILITY ===
execute if score @s ec.jv_id matches 1 run function evercraft:artifacts/javelin/melee/norroen
execute if score @s ec.jv_id matches 2 run function evercraft:artifacts/javelin/melee/ancient
execute if score @s ec.jv_id matches 3 run function evercraft:artifacts/javelin/melee/royal
execute if score @s ec.jv_id matches 4 run function evercraft:artifacts/javelin/melee/fantasy
execute if score @s ec.jv_id matches 5 run function evercraft:artifacts/javelin/melee/shuriken
execute if score @s ec.jv_id matches 6 run function evercraft:artifacts/javelin/melee/crucible
execute if score @s ec.jv_id matches 7 run function evercraft:artifacts/javelin/melee/mjolnir
execute if score @s ec.jv_id matches 8 run function evercraft:artifacts/javelin/melee/ninja
execute if score @s ec.jv_id matches 9 run function evercraft:artifacts/javelin/melee/master_bolt
execute if score @s ec.jv_id matches 10 run function evercraft:artifacts/javelin/melee/gungnir

# Generic tier-FX layer (common→rare; ornate+ no-ops for the bespoke preset below). Channel-gated.
# Only reached when off cooldown (the ability actually procs — cooldown branch returns above).
scoreboard players operation #fx_tier ec.var = @s ec.jv_tier
execute at @s run function evercraft:fx/tier/proc
# Bespoke "Valor's Reach" — a clean bronze spear-thrust gleam punched forward (ornate+).
execute if score #fx_tier ec.var matches 4.. at @s anchored eyes run function evercraft:fx/bespoke/javelin/on_melee_hit
