# Javelin Class — Remove / Cleanup
# Run as player who unequipped javelin trident

tag @s remove ec.jv_active
# Strip Skirmish combat modifiers (C1 melee, C3 attack speed) — active-gated.
attribute @s minecraft:attack_damage modifier remove evercraft:bough_jv_c1
attribute @s minecraft:attack_speed modifier remove evercraft:bough_jv_c3
# Strip Hoplite Formation modifiers (C2/C9 armor, C4 melee) — Hoplite is the javelin+shield stance.
attribute @s minecraft:armor modifier remove evercraft:bough_hp_c2
attribute @s minecraft:armor modifier remove evercraft:bough_hp_c9
attribute @s minecraft:attack_damage modifier remove evercraft:bough_hp_c4
scoreboard players set @s ec.jv_tier 0
scoreboard players set @s ec.jv_id 0
scoreboard players set @s ec.jv_thrown 0
scoreboard players set @s ec.jv_melee 0
scoreboard players set @s ec.jv_hoplite 0
scoreboard players set @s ec.jv_hoplite_prev 0
scoreboard players set @s ec.jv_aegis 0
scoreboard players set @s ec.jv_aegis_w 0
# Keep ec.jv_cd and ec.jv_aegis_cd running — prevent cooldown exploit by unequipping
