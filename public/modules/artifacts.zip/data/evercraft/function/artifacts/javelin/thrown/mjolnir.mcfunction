# Mjolnir (Exquisite) — Thrown: Chain Lightning
# 3 lightning damage to 3 targets in 6-block radius at impact
# Cooldown: 18s

scoreboard players set @s ec.jv_cd 18

# Affinity boost
tag @s add ec.aff_attacker
# Wiring Audit #5 W3a: stamp owner-id surrogate; mirror to #Search aff.id for the predicate filter.
scoreboard players operation @s ec.aff_owner_id = @s adv.gui_session
scoreboard players operation #Search aff.id = @s ec.aff_owner_id
scoreboard players set #aff_base ec.temp 3
function evercraft:affinity/boost_damage
data modify storage evercraft:affinity temp.damage_type set value "minecraft:lightning_bolt"

execute at @s at @e[type=!player,type=!item,distance=..50,limit=1,sort=nearest,nbt={HurtTime:10s}] as @e[type=!player,type=!item,distance=..6,limit=3,sort=nearest] run function evercraft:affinity/deal_damage_typed with storage evercraft:affinity temp
execute at @s at @e[type=!player,type=!item,distance=..50,limit=1,sort=nearest,nbt={HurtTime:10s}] run summon lightning_bolt ~ ~ ~
execute at @s run particle electric_spark ~ ~1 ~ 1.5 1 1.5 0.2 15
execute as @a[distance=..30] if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.lightning_bolt.impact player @s ~ ~ ~ 0.8 1.2
tag @s remove ec.aff_attacker

scoreboard players add @s ach.weapon_abilities 1
