# Aegis Burst — Hoplite Active Ability
# Absorption II (4 golden hearts) for 5s after taking 3 hits within 5s
# Cooldown: 15s

# Reset hit tracking
scoreboard players set @s ec.jv_aegis 0
scoreboard players set @s ec.jv_aegis_w 0

# Set cooldown (15s)
scoreboard players set @s ec.jv_aegis_cd 15

# Apply Absorption II
effect give @s absorption 5 1 false

# Feedback
execute at @s run particle enchanted_hit ~ ~1 ~ 0.5 0.5 0.5 0.5 8
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:item.shield.block player @s ~ ~ ~ 1.0 0.8
data modify storage evercraft:notify stage.c set value [{text:"Aegis Burst!",color:"#5B9BD5",bold:true}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit

# Generic tier-FX layer (common→rare; ornate+ no-ops for the bespoke preset below). Channel-gated.
scoreboard players operation #fx_tier ec.var = @s ec.jv_tier
execute at @s run function evercraft:fx/tier/proc
# Bespoke "Valor's Reach" — a cyan aegis shield-wall dome shimmering up (ornate+).
execute if score #fx_tier ec.var matches 4.. at @s run function evercraft:fx/bespoke/javelin/aegis_burst
