# Javelin Class — Hoplite Counter Thrust
# Called from shield block handler — sets 3s window for bonus melee damage

# Only fires for javelin players with Hoplite active
execute unless entity @s[tag=ec.jv_active] run return 0
execute unless score @s ec.jv_hoplite matches 1 run return 0

# Set 3-second counter thrust window (60 ticks)
scoreboard players set @s ec.jv_counter 60
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:item.shield.block player @s ~ ~ ~ 0.8 1.5
data modify storage evercraft:notify stage.c set value [{text:"Counter Thrust!",color:"gold",bold:true}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit

# Generic tier-FX layer (common→rare; ornate+ no-ops for the bespoke preset below). Channel-gated.
scoreboard players operation #fx_tier ec.var = @s ec.jv_tier
execute at @s run function evercraft:fx/tier/proc
# Bespoke "Valor's Reach" — a sharp bronze counter-flash snapping forward off the guard (ornate+).
execute if score #fx_tier ec.var matches 4.. at @s anchored eyes run function evercraft:fx/bespoke/javelin/hoplite_counter
