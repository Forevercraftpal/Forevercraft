# Sabrewing — TEMPEST (Exquisite)
# Arrow Rain: 12 arrows rain in 6-block radius after 1s delay
# @s = player

# Store impact location in storage for the delayed rain
execute as @e[type=!player,sort=nearest,limit=1,distance=..100,nbt={HurtTime:10s}] at @s run function evercraft:artifacts/archer/overcharge/tempest_mark

# Feedback
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.lightning_bolt.thunder master @s ~ ~ ~ 0.8 1.5
data modify storage evercraft:notify stage.c set value [{text:"Tempest ",color:"yellow",bold:true},{text:"— Arrow rain incoming!",color:"gold"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
