# Tempest — Mark impact location and schedule arrow rain
# @s = hit entity, position = hit entity location

# Summon marker at impact point
summon marker ~ ~10 ~ {Tags:["ec.ar_tempest"]}

# Schedule the rain (20 ticks = 1 second delay).
# Wiring Audit #5 R-P0-5: append mode so multiple archers' Tempests do not cancel each other.
schedule function evercraft:artifacts/archer/overcharge/tempest_rain 20t append
