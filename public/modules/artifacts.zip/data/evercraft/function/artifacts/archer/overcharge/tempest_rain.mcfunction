# Tempest — Arrow Rain
# Spawns 12 arrows raining down from the marker location

execute as @e[type=marker,tag=ec.ar_tempest,limit=1] at @s run function evercraft:artifacts/archer/overcharge/tempest_volley

# Schedule poison/wither effects after arrows land (10 ticks).
# Wiring Audit #5 R-P0-5: append mode (was missing → defaults to replace) so multiple archers
# firing Tempest within 10t do not cancel each other's callback.
schedule function evercraft:artifacts/archer/overcharge/tempest_effects 10t append
