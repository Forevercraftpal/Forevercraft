# Nocturnal Bow — WHISPER (Mythical)
# Phantom Arrow: Blindness 3s + Slowness III 4s + smoke cloud on target
# Archer gains Invisibility 3s
# @s = player

# Apply debuffs to hit entity
execute as @e[type=!player,sort=nearest,limit=1,distance=..100,nbt={HurtTime:10s}] run effect give @s blindness 60 0 false
execute as @e[type=!player,sort=nearest,limit=1,distance=..100,nbt={HurtTime:10s}] run effect give @s slowness 80 2 false

# Instant Health V — devastating to undead (heals living mobs)
execute as @e[type=!player,sort=nearest,limit=1,distance=..100,nbt={HurtTime:10s}] run effect give @s instant_health 1 4 false

# Smoke cloud at target location
execute as @e[type=!player,sort=nearest,limit=1,distance=..100,nbt={HurtTime:10s}] at @s run particle large_smoke ~ ~0.5 ~ 2 1 2 0.02 20
execute as @e[type=!player,sort=nearest,limit=1,distance=..100,nbt={HurtTime:10s}] at @s run particle campfire_cosy_smoke ~ ~0.5 ~ 1 0.5 1 0.01 8

# Archer goes invisible
effect give @s invisibility 60 0 true

# Sound effects
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.wind_charge.wind_burst master @s ~ ~ ~ 1 0.5
execute as @a if score @s ec.fx_snd matches 1.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.5 1.5

# Feedback
data modify storage evercraft:notify stage.c set value [{text:"Whisper ",color:"dark_gray",bold:true},{text:"— Vanished into shadow!",color:"gray"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
