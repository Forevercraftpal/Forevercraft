# Uplift — AoE Levitation + Knockback
# @s = hit entity, position = hit entity location

# Levitation III for 7 seconds to all mobs in 4-block radius
effect give @e[type=!player,distance=..4] levitation 140 2 false

# Wind burst particles
particle cloud ~ ~0.5 ~ 4 0.5 4 0.1 20
particle poof ~ ~1 ~ 3 1 3 0.1 15
execute as @a if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.wind_charge.wind_burst master @s ~ ~ ~ 1.5 0.8
execute as @a if score @s ec.fx_snd matches 1.. run playsound minecraft:item.trident.thunder master @s ~ ~ ~ 0.5 2.0

# Feedback to archer
data modify storage evercraft:notify stage.c set value [{text:"Uplift ",color:"white",bold:true},{text:"— Enemies launched skyward!",color:"yellow"}]
scoreboard players set #ndur ec.temp 45
execute as @p run function evercraft:util/notify/emit
