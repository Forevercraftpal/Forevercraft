# Frostfang — AoE Frost Zone
# @s = hit entity, position = hit entity location

# Apply effects to all entities in 5-block radius
effect give @e[type=!player,distance=..5] slowness 120 3 false
effect give @e[type=!player,distance=..5] mining_fatigue 120 1 false

# Frost particles
particle snowflake ~ ~0.5 ~ 5 1 5 0.02 30
particle block{block_state:"minecraft:packed_ice"} ~ ~0.5 ~ 5 0.5 5 0.1 20
execute as @a if score @s ec.fx_snd matches 1.. run playsound minecraft:block.glass.break master @s ~ ~ ~ 1.5 0.5
execute as @a if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.chime master @s ~ ~ ~ 1 2.0

# Feedback to archer
data modify storage evercraft:notify stage.c set value [{text:"Frostfang ",color:"blue",bold:true},{text:"— Frost zone deployed!",color:"dark_aqua"}]
scoreboard players set #ndur ec.temp 45
execute as @p run function evercraft:util/notify/emit
