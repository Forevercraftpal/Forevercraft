# Call of the Void — SOULSTRING (Exquisite)
# Siphon Arrow: Wither II + Weakness II for 6s, soul tether heals archer for 8s
# Kill while tethered = Absorption II (4 hearts) for 10s
# @s = player

# Apply debuffs to hit entity
execute as @e[type=!player,sort=nearest,limit=1,distance=..100,nbt={HurtTime:10s}] run effect give @s wither 120 1 false
execute as @e[type=!player,sort=nearest,limit=1,distance=..100,nbt={HurtTime:10s}] run effect give @s weakness 120 1 false
execute as @e[type=!player,sort=nearest,limit=1,distance=..100,nbt={HurtTime:10s}] run effect give @s glowing 160 0 false

# Tag tethered entity for tracking
tag @e[tag=ec.ar_tethered] remove ec.ar_tethered
execute as @e[type=!player,sort=nearest,limit=1,distance=..100,nbt={HurtTime:10s}] run tag @s add ec.ar_tethered

# Grant archer Regeneration I for 8 seconds (represents life drain)
effect give @s regeneration 160 0 false

# Soul tether particles
execute as @e[type=!player,sort=nearest,limit=1,distance=..100,nbt={HurtTime:10s}] at @s run particle soul ~ ~0.5 ~ 0.3 0.5 0.3 0.02 8
execute at @s run particle soul ~ ~1 ~ 0.3 0.5 0.3 0.02 5

# Sound
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 1 0.5
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.sculk_catalyst.bloom master @s ~ ~ ~ 1 1.2

# Feedback
data modify storage evercraft:notify stage.c set value [{text:"Soulstring ",color:"dark_purple",bold:true},{text:"— Soul tether bound!",color:"light_purple"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
