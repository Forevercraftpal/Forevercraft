# Oblivion — Create Void Zone
# @s = hit entity, position = hit entity location

# Apply devastating effects to all entities in 7-block radius
effect give @e[type=!player,distance=..7] wither 100 2 false
effect give @e[type=!player,distance=..7] levitation 100 1 false
effect give @e[type=!player,distance=..7] slowness 100 3 false
effect give @e[type=!player,distance=..7] glowing 100 0 false

# Summon marker for collapse burst
summon marker ~ ~ ~ {Tags:["ec.ar_oblivion"]}

# Massive void particles
particle dragon_breath ~ ~1 ~ 7 2 7 0.02 40
particle portal ~ ~1 ~ 7 2 7 0.5 50
particle reverse_portal ~ ~2 ~ 5 1 5 0.3 25
particle end_rod ~ ~3 ~ 3 2 3 0.01 10

# Sound
execute as @a if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 2 0.3
execute as @a if score @s ec.fx_snd matches 1.. run playsound minecraft:block.amethyst_block.resonate master @s ~ ~ ~ 2 0.5
execute as @a if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.didgeridoo master @s ~ ~ ~ 1 0.4

# Schedule collapse burst (100 ticks = 5 seconds).
# Wiring Audit #5 R-P0-5: append mode so multiple archers' Oblivion zones do not cancel each other.
schedule function evercraft:artifacts/archer/overcharge/oblivion_collapse 100t append

# Feedback
data modify storage evercraft:notify stage.c set value [{text:"OBLIVION ",color:"dark_purple",bold:true},{text:"— The void consumes all!",color:"light_purple"}]
scoreboard players set #ndur ec.temp 45
execute as @a run function evercraft:util/notify/emit
