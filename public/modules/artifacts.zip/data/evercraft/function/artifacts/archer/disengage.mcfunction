# Archer Bow — Disengage Leap
# Shift + right-click with any archer bow to leap backward
# Grants brief Slow Falling to prevent fall damage

# Set cooldown (4 seconds)
scoreboard players set @s ec.ar_disengage 4

# Leap backward (8 blocks behind facing + 2 blocks up)
execute at @s run tp @s ^ ^2 ^-8

# Slow Falling to cushion landing
effect give @s slow_falling 3 0 true

# Feedback
execute at @s as @a if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.wind_charge.wind_burst master @s ~ ~ ~ 1 1.2
execute at @s run particle cloud ~ ~ ~ 0.5 0.3 0.5 0.1 10
execute at @s run particle end_rod ~ ~0.5 ~ 0.3 0.5 0.3 0.05 5
data modify storage evercraft:notify stage.c set value [{text:"Disengage!",color:"aqua",bold:true}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit

# Reset draw state (disengage interrupts overcharge)
scoreboard players set @s ec.ar_draw 0
scoreboard players set @s ec.ar_charged 0
