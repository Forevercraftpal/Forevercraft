# Mechanical Shortbow — STEADY (Common)
# Heavy Arrow: 2x damage (Instant Damage I) + Slowness II for 3 seconds
# @s = player

# Apply heavy hit effects to the just-hit entity
execute as @e[type=!player,sort=nearest,limit=1,distance=..100,nbt={HurtTime:10s}] run effect give @s slowness 60 1 false
execute as @e[type=!player,sort=nearest,limit=1,distance=..100,nbt={HurtTime:10s}] run effect give @s instant_damage 1 0 false

# Feedback
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.anvil.land master @s ~ ~ ~ 1 0.6
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 1 0.6
execute as @e[type=!player,sort=nearest,limit=1,distance=..100,nbt={HurtTime:10s}] at @s run particle crit ~ ~0.5 ~ 0.3 0.5 0.3 0.5 8
data modify storage evercraft:notify stage.c set value [{text:"Steady ",color:"gray",bold:true},{text:"— Heavy impact!",color:"white"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
