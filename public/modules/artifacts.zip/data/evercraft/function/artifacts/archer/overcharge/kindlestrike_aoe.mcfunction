# Kindlestrike — AoE Fire Burst
# @s = hit entity, position = hit entity location

# Set all mobs in 4-block radius on fire (8 seconds = 160 ticks)
execute as @e[type=!player,distance=..4] run data modify entity @s Fire set value 160s

# Fire particles
particle flame ~ ~0.5 ~ 4 1 4 0.05 30
particle lava ~ ~0.5 ~ 4 0.5 4 0.1 10
particle smoke ~ ~1 ~ 3 1 3 0.05 15
execute as @a if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.blaze.shoot master @s ~ ~ ~ 1.5 0.6
execute as @a if score @s ec.fx_snd matches 1.. run playsound minecraft:item.firecharge.use master @s ~ ~ ~ 1 1.0

# Feedback to archer
data modify storage evercraft:notify stage.c set value [{text:"Kindlestrike ",color:"gold",bold:true},{text:"— Inferno unleashed!",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute as @p run function evercraft:util/notify/emit
