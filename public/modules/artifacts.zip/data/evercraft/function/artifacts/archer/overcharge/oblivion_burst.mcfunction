# Oblivion — Collapse Burst
# @s = marker, position = void zone center

# Final damage burst to all entities in 7-block radius
effect give @e[type=!player,distance=..7] instant_damage 1 1 false

# Collapse particles
particle explosion ~ ~1 ~ 5 2 5 0.1 10
particle sonic_boom ~ ~1 ~ 0 0 0 0 1
particle dragon_breath ~ ~1 ~ 7 2 7 0.05 50
particle flash{color:[1.000,1.000,1.000,1.00]} ~ ~1 ~ 3 1 3 0.1 3

# Sound
execute as @a if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.generic.explode master @s ~ ~ ~ 2 0.5
execute as @a if score @s ec.fx_snd matches 1.. run playsound minecraft:block.amethyst_block.resonate master @s ~ ~ ~ 1.5 1.0
