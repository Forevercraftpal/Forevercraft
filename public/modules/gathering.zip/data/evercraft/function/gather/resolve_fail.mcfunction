# === GATHER — RESOLVE: FAIL (fails 1 or 2 — node survives, retry) ===
# Run as @s from gather/resolve on a lost roll that did NOT reach the crumble ceiling.
# ec.gth_fails was ALREADY incremented by resolve (it now reads 1 or 2). @s ec.gth_base
# holds baseXP.

# Quarter XP (fail). grant_xp reads ec.gth_win (=0) -> grants floor(baseXP/4), un-multiplied,
# and stores it in ec.gth_halfxp for any consolation copy.
function evercraft:gather/grant_xp

# Outcome = FAIL. Node stays; charges untouched (no decrement on a fail). No despawn.
scoreboard players set @s ec.gth_outcome 2

# Fail line (lore L5) — names the half-the-lesson consolation.
function evercraft:gather/lines/fail

# Outcome FX — light "not yet" puff, channel-gated. One-shot at the node.
function evercraft:fx/gather/fail
