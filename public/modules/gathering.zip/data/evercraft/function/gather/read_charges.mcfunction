# === GATHER — READ NODE CHARGES (coord-pinned, default 2) ===
# Run as @s; caller has stored the pinned node coords + dtag in evercraft:gth_temp.
# Reads the marker's data.charges into @s ec.gth_charges, defaulting to 2 (a node yields
# 2 successful harvests) when the marker has no data.charges stamped.
#
# TODO(B-wire): stamp data.charges:2 at place_node. Until then every node reads default 2.
scoreboard players operation @s ec.gth_charges = #gth_charges_default ec.var
function evercraft:gather/read_charges_pinned with storage evercraft:gth_temp
