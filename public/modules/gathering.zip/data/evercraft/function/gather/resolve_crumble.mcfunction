# === GATHER — RESOLVE: CRUMBLE (3rd consecutive fail — node spent) ===
# Run as @s from gather/resolve when this loss is the 3rd consecutive fail. ec.gth_fails
# already reads 3. @s ec.gth_base holds baseXP.

# Quarter XP (this fail still pays — "harvesting regardless of success increases your XP").
# grant_xp reads ec.gth_win (=0) and also fills ec.gth_halfxp for the crumble line.
function evercraft:gather/grant_xp

# Outcome = CRUMBLE; signal the caller to despawn the spent node. A success-OR-crumble are
# the ONLY despawn paths (crossplay C1) — never on a 1st/2nd fail.
scoreboard players set @s ec.gth_outcome 3
scoreboard players set @s ec.gth_despawn 1

# Crumble line for this source (lore L1): 1=prospect, 2=forage, 3=fishing. May reference
# ec.gth_halfxp (set by grant_xp above) if a line wants to name the banked total.
execute if score @s ec.gth_src matches 1 run function evercraft:gather/lines/crumble_1
execute if score @s ec.gth_src matches 2 run function evercraft:gather/lines/crumble_2
execute if score @s ec.gth_src matches 3 run function evercraft:gather/lines/crumble_3
# Nest family (PLAN-nest-family §2, ADDITIVE — R3): 4=nest (Lamentor).
execute if score @s ec.gth_src matches 4 run function evercraft:gather/lines/crumble_4
# Chest-Node family (PLAN-chest-nodes §1/§14.1, ADDITIVE): 5=chest (Gearwright).
execute if score @s ec.gth_src matches 5 run function evercraft:gather/lines/crumble_5
# Buried Cache family (Wiring Audit #37 W2, ADDITIVE): 7=cache (Terrawarp). src 6 (timberfall/
# Lumberfell) is intentionally absent — it computes win/fail via compute_success directly and a
# miss routes through resolve_miss, so it NEVER reaches resolve_crumble (no crumble_6 needed).
execute if score @s ec.gth_src matches 7 run function evercraft:gather/lines/crumble_7

# Reset THIS player's fail count now the node is gone (so a fresh node starts clean).
scoreboard players set @s ec.gth_fails 0

# Outcome FX — the "node spent" collapse, channel-gated. One-shot at the node, before despawn.
function evercraft:fx/gather/crumble

# Wave D2: maybe_rescue — a 10% chance for a "rescue" Dreamy Pull that pays the node's
# PRIMARY loot table (crossplay C6). Fires HERE, on the crumble, BEFORE the caller despawns
# the node (despawn happens after resolve returns, on the ec.gth_despawn signal), so the
# marker is still alive + coord-pinned in gth_temp for the primary-loot read. INSTANT (no
# minigame) → it does NOT route through give_good_find, so it gets no 2× Dreamy XP (correct;
# its value is the saved loot). No node-level lock needed: resolve_crumble only runs for the
# tick's claim-winner and the crumble despawns the node, so two players can't both rescue it.
function evercraft:dreamy_pull/maybe_rescue
