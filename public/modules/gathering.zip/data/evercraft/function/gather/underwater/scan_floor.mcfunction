# === GATHER · UNDERWATER — SCAN DOWN TO A RIVER/OCEAN FLOOR ===
# Run as: a temp marker, at: that temp marker.
# The cheap INVERSE of evercraft:fishing/splash_nodes/scan_surface — instead of
# "air here, liquid below" (the splashable surface), this finds "water here, solid
# floor directly below" (a node sits in the water just ABOVE the floor block).
#
# Uses: #uw_scan ec.temp  (recursion budget; the CALLER seeds it to 24 before the first call).
# Returns: 1 if a water-over-floor block is found (marker TPed to that water block — place the
#          node HERE, in the water just above the floor), else 0 (budget exhausted / nothing).
#
# Recursion cap = 24 (perf-seat P0-2): underwater the marker starts at-or-near the floor, so a
# 24-deep walk is plenty and a 50-deep one (the surface prospect scan) would waste iterations.
#
# Floor test uses #evercraft:water_floor — an EXPLICIT 26.1-split-safe tag (sand/gravel/dirt/
# clay/mud/sandstone/stone/deepslate/moss_block/rooted_dirt). NEVER #minecraft:dirt: the 26.1
# split removed mud/moss from #dirt, so #minecraft:dirt would MISS mud riverbeds (compliance C4/R4).

scoreboard players remove #uw_scan ec.temp 1
execute if score #uw_scan ec.temp matches ..0 run return 0

# Found it: water block sitting directly on a solid floor -> place the node HERE (in the water).
execute if block ~ ~ ~ minecraft:water if block ~ ~-1 ~ #evercraft:water_floor run return 1

# Keep scanning down.
tp @s ~ ~-1 ~
execute at @s run function evercraft:gather/underwater/scan_floor
