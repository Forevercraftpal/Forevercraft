# === THE GATHERER'S PATH — SHARED SUCCESS-CHECK ENGINE (Wave B core) ===
# Reusable evercraft:gather/* decision engine. Every harvest node-click runs a
# RuneScape-style success/fail roll whose odds rise with the driving Crafting-Class
# level (Wave A's ec.caffl_*). This file declares the engine's scoreboards + claim
# constants; it schedules NOTHING (the engine is event-driven off node clicks). The 3
# completion tails (complete_mine / complete_gather / do_catch) are spliced through
# gather/resolve by a later teammate (B-wire).
#
# Registered from evercraft:init (right after the dreamy_pull load).

# --- Per-(player, CURRENT node) CONSECUTIVE FAILS (race seat "Shape β"). ---
# Counts THIS player's retries on the node they're currently attempting. Reset on
# win + on crumble + on NODE-CHANGE (gather/resolve compares the click's pinned coords
# against the node the streak belongs to). PER-PLAYER, never on the marker — one player's
# success/crumble must not touch another's accumulated fails. SINGLE WRITER = gather/resolve.
scoreboard objectives add ec.gth_fails dummy "Gather Consecutive Fails (per-player, current node)"
# The node coords the current fail-streak belongs to. When a click's pinned coords differ
# from these, the streak is stale (player moved to a different node) and resets to 0.
# SINGLE WRITER = gather/resolve.
scoreboard objectives add ec.gth_fnx dummy "Gather Fail-Streak Node X"
scoreboard objectives add ec.gth_fny dummy "Gather Fail-Streak Node Y"
scoreboard objectives add ec.gth_fnz dummy "Gather Fail-Streak Node Z"
# Scratch for the current click's pinned node coords (compared against the fail-streak node).
scoreboard objectives add ec.gth_nx dummy "Gather Current Node X (scratch)"
scoreboard objectives add ec.gth_ny dummy "Gather Current Node Y (scratch)"
scoreboard objectives add ec.gth_nz dummy "Gather Current Node Z (scratch)"

# --- @s scratch (race B3): every value that survives a `function` call is @s-scoped, ---
# NEVER #...ec.temp — the grant path churns the shared ec.temp namespace
# (#aff_total/#new_stage/#new_boost) and two concurrent harvesters would clobber it.
scoreboard objectives add ec.gth_succ dummy "Gather Success% (computed)"
scoreboard objectives add ec.gth_floor dummy "Gather Success Floor (Wave-E S3 raises)"
scoreboard objectives add ec.gth_base dummy "Gather baseXP (rarity band)"
scoreboard objectives add ec.gth_xp dummy "Gather XP to grant this resolution"
scoreboard objectives add ec.gth_halfxp dummy "Gather quarter-XP consolation (lore line)"
scoreboard objectives add ec.gth_win dummy "Gather roll won this tick (0/1)"
scoreboard objectives add ec.gth_outcome dummy "Gather outcome (1=win 2=fail 3=crumble)"
scoreboard objectives add ec.gth_despawn dummy "Gather despawn-needed signal (0/1)"
scoreboard objectives add ec.gth_src dummy "Gather node source (1=prospect 2=forage 3=splash 4=nest 5=chest)"
scoreboard objectives add ec.gth_claimed dummy "Gather claim winner this tick (0/1)"
scoreboard objectives add ec.gth_charges dummy "Gather node charges (read/decrement scratch)"
scoreboard objectives add ec.gth_roll dummy "Gather success roll (1-100, @s)"
# Tool-Material harvest bonus (Joseph 2026-06-04): the flat +0/+1/+2/+3/+5 added to ec.gth_succ
# when the player holds the APPROPRIATE tool class of iron/gold/diamond/netherite. @s scratch,
# recomputed each harvest in compute_success. SINGLE WRITER = compute_success.
scoreboard objectives add ec.gth_toolmat dummy "Gather tool-material success bonus (@s)"
# --- Wave D2 (2× XP on a landed Dreamy Pull): snapshot of the LAST WIN's granted XP. ---
# Set by grant_xp on a WIN (before the fail-overwrite) = baseXP × areaMult × familiar (already
# area-multiplicative). maybe_trigger snapshots it into the Dreamy session (ec.dp_bonusxp) so a
# second harvest mid-minigame can't corrupt the 2× re-grant. SINGLE WRITER = gather/grant_xp.
scoreboard objectives add ec.gth_lastxp dummy "Gather last WIN XP (for the Dreamy 2x re-grant)"
# --- Wave D1 (Dreamy retune): the over-level trigger flag + the Dreamy odds penalty. ---
# Both are HARVEST-scratch (@s, recomputed each harvest in compute_success). The penalty is
# SNAPSHOTTED into the Dreamy session (ec.dp_penalty) by maybe_trigger so a second harvest
# mid-minigame can't corrupt the odds resolve reads. SINGLE WRITER = compute_success.
# ec.gth_overlvl = 1 when (level - effReqLv) >= 25 (zone is over-leveled -> 3% trigger).
scoreboard objectives add ec.gth_overlvl dummy "Gather over-level flag (0/1, >=25 above reqLv)"
# ec.gth_dppenalty = Dreamy odds penalty factor 0-100: min(100, succ*100/32). In-tier/over
# (succ>=32) -> 100 (no penalty); under-level craters it (succ 5 -> 15).
scoreboard objectives add ec.gth_dppenalty dummy "Gather Dreamy odds penalty x100 (default 100)"
# ec.gth_overscratch = (level - effReqLv) scratch for the over-level compare (vs 25). @s.
scoreboard objectives add ec.gth_overscratch dummy "Gather over-level scratch (level - effReqLv)"
# --- Wave C1 (EQ2 tiers): area difficulty + area XP multiplier, read off the node marker. ---
# ec.gth_reqlv = the node's AREA reqLv (data.reqlv, default 0). compute_success subtracts it
# from the player's level before the success curve (the soft under-level penalty).
scoreboard objectives add ec.gth_reqlv dummy "Gather node area reqLv (data.reqlv, default 0)"
# ec.gth_areamult = the node's AREA win-XP multiplier ×100 (data.areamult, default 100).
# grant_xp multiplies the WIN XP by this /100 (fail consolation stays un-multiplied, R7).
scoreboard objectives add ec.gth_areamult dummy "Gather node area XP mult x100 (default 100)"
# --- Wave C2 (Home Turf): scoped reqLv shave + familiarity XP-mult, both keyed off ec.bm_level. ---
# ec.gth_shave = compute_reqlv scratch (bm_level*4, subtracted from ec.gth_reqlv, clamped >=0).
scoreboard objectives add ec.gth_shave dummy "Gather Home-Turf reqLv shave scratch"
# ec.gth_familiar = familiarity factor ×100 from biome_mastery/gather_familiarity (100 + bm_level*5,
# so L0->100 ... L5->125). grant_xp folds it into ec.gth_areamult; familiar<=125 IS the XP clamp.
scoreboard objectives add ec.gth_familiar dummy "Gather Home-Turf familiarity x100 (default 100)"

# --- Engine constants (success-curve integer math). ---
# success% = clamp(32 + level*66/100, floor, 95). 66 and 100 are the curve constants;
# 32 is the L0 base, 95 the cap. Held as #gth_* fakeplayers (read-only consumers — never
# a one-writer hazard; set once here at load).
scoreboard players set #gth_c66 ec.var 66
scoreboard players set #gth_c100 ec.var 100
# Harvest-timer duration knobs (calc_hdur): target = 100 - level*7/10 ticks, floored 30 (5s->1.5s @ L100).
scoreboard players set #gth_c7 ec.var 7
scoreboard players set #gth_c10 ec.var 10
scoreboard players set #gth_base32 ec.var 32
scoreboard players set #gth_cap95 ec.var 95
# Default success floor (5%). Left as a per-player score so Wave-E S3 (spirit/Awakened
# tool floor) can raise ec.gth_floor before compute_success. NOT implemented now.
scoreboard players set #gth_floor_default ec.var 5
# Default node charges (2 successful harvests/node) when the marker has no data.charges
# (B-wire stamps it at spawn; the default keeps the engine usable today).
scoreboard players set #gth_charges_default ec.var 2
# Default rarity band (1 -> baseXP 4) when the marker has no data.rarity.
scoreboard players set #gth_rarity_default ec.var 1
# Fail counter ceiling: the 3rd consecutive fail crumbles the node.
scoreboard players set #gth_fail_max ec.var 3
# Divisor for the fail quarter-XP consolation (floor(baseXP/4), balance R7).
scoreboard players set #gth_4 ec.var 4
# Constant 1 for the marker charge decrement (read-subtract-write under the claim).
scoreboard players set #gth_1 ec.var 1
# Wave D1: over-level threshold (relative). (level - effReqLv) >= 25 -> over-leveled zone
# (Dreamy triggers at 3% not 7%). Matches the EPIC Open-Gap #2 "relative yourLevel >= reqLv+25".
scoreboard players set #gth_overlvl_thresh ec.var 25
# Wave C2 (Home Turf) knobs — both read ec.bm_level (Biome Mastery's current-biome level 0-5):
#   shave    = bm_level * #gth_shave_per      (4 -> L5 shaves reqLv by 20, eases the success roll)
#   familiar = #gth_c100 + bm_level * #gth_familiar_per  (5 -> L5 = 125 = ×1.25 XP, the cap)
scoreboard players set #gth_shave_per ec.var 4
scoreboard players set #gth_familiar_per ec.var 5

# --- Tool-Material harvest bonus (Joseph 2026-06-04): a FLAT additive on the success% (1..100). ---
# Holding the APPROPRIATE tool class for this source, of one of these materials, adds: iron +1,
# gold +2, diamond +3, netherite +5 (wood/stone/wrong-class = +0). Applied AFTER the level-curve
# clamp + the Dreamy feeds in compute_success (so it only sweetens the actual win roll), then the
# bonused result is re-clamped to <=100. Read-only consumers (#gth_tm_*) — set once here at load.
scoreboard players set #gth_tm_iron ec.var 1
scoreboard players set #gth_tm_gold ec.var 2
scoreboard players set #gth_tm_diamond ec.var 3
scoreboard players set #gth_tm_neth ec.var 5
# Absolute success cap once the tool bonus is folded in (the base curve still caps at 95; the
# tool bonus is the ONLY thing allowed to push a maxed harvester past 95, toward certainty).
scoreboard players set #gth_cap100 ec.var 100

# --- Wave E1 (underwater nodes): the class-level UNLOCK threshold for the floor-spawn branch. ---
# Prospect/forage/splash each grow a GATED underwater branch off their EXISTING per-player
# check_spawn (NO new tick loop). A player runs the river/ocean-FLOOR scan only when BOTH:
#   (a) `if predicate evercraft:in_water`  (dry-land players never touch the liquid scan), AND
#   (b) their driving class level `ec.caffl_<ss|gs|sc>` >= this threshold.
# TUNABLE. Set to 30 = river reqLv: underwater gathering OPENS once you're river-competent.
# Ocean-floor nodes still gate SUCCESS at reqLv 40 via the inherited area tier (data.reqlv 40,
# stamped by gather/tier/stamp_* off the is_ocean predicate at the floor) — so an L30..39 player
# can SPAWN ocean-floor nodes but mostly FAILS the success roll until L40+, exactly as designed.
scoreboard players set #gth_uw_unlock ec.var 30
