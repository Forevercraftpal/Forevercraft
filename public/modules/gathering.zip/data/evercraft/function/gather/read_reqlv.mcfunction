# === GATHER — READ AREA reqLv FROM THE NODE MARKER (Wave C1) ===
# Run as @s; caller has stored the pinned node coords + dtag in evercraft:gth_temp.
# Reads the marker's data.reqlv (the EQ2 area difficulty) into @s ec.gth_reqlv, defaulting
# to 0 (Normal — no penalty) when the marker has no data.reqlv stamped (e.g. a node that
# predates the C1-tier stamp). Mirrors gather/read_rarity exactly.
#
# data.reqlv is stamped at spawn by gather/tier/stamp_{prospect,forage,splash} from the LOCKED
# v2 area table (0 Normal / 20 rare-biome / 30 deepslate+river / 40 ocean+sky / 50 End /
# 60 Nether / 70 Deep Dark). compute_success subtracts this from the player's level before the
# success curve, so an under-levelled harvester craters toward ec.gth_floor (the soft penalty).

# Default reqLv 0 — seed first, then the pinned macro's `execute store result` only overwrites
# when the marker actually has data.reqlv (a pre-C1 node keeps the 0 default = no penalty).
scoreboard players set @s ec.gth_reqlv 0
function evercraft:gather/read_reqlv_pinned with storage evercraft:gth_temp
