# === GATHER — CRUMBLE LINE: BURIED CACHE (Terrawarp) — Wiring Audit #37 W2 ===
# Run as @s on the 3rd consecutive fail (cache spent). Names the work learned. Mirrors crumble_4/5.
# Terrawarp dig motif + the geode teal (#9FD8C8) used by the cache's success/Geode-Dust lines.
data modify storage evercraft:notify stage.c set value [{text:"🜨 ",color:"#9FD8C8"},{text:"The cache collapsed into the earth",color:"white"},{text:" — the find slipped back into the dark before you could lift it, but your shovel learned the ground. ",color:"gray"},{text:"The craft sticks with you.",color:"green",italic:true}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
