# === GATHER — SPENT-FOR-YOU LINE (per-player exhausted cue, named by node type) ===
# Run as @s when the exhausted gate blocks a click (the player has spent all THEIR charges on
# this node). Soft/gray, mirrors chest_nodes/exhausted_gate's "nothing left here" cue — names
# the node by source (Joseph's ask) so it reads naturally. The node stays fully live for others;
# this is purely "you, personally, have taken all this one will give you." gth_src: 1=prospect
# vein / 2=forage bush / 3=splash shoal / 4=nest / 7=cache. A soft chain-fall thunk on block.

execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.chain.fall master @s ~ ~ ~ 0.4 0.9
execute if score @s ec.gth_src matches 1 run data modify storage evercraft:notify stage.c set value [{text:"⛏ ",color:"gray"},{text:"This vein has nothing left to offer you.",color:"gray"}]
execute if score @s ec.gth_src matches 2 run data modify storage evercraft:notify stage.c set value [{text:"✿ ",color:"gray"},{text:"You've gathered all this bush will give you.",color:"gray"}]
execute if score @s ec.gth_src matches 3 run data modify storage evercraft:notify stage.c set value [{text:"🎣 ",color:"gray"},{text:"This shoal is fished out for you.",color:"gray"}]
execute if score @s ec.gth_src matches 4 run data modify storage evercraft:notify stage.c set value [{text:"🐝 ",color:"gray"},{text:"This nest holds nothing more for you.",color:"gray"}]
execute if score @s ec.gth_src matches 7 run data modify storage evercraft:notify stage.c set value [{text:"🜨 ",color:"gray"},{text:"This cache is emptied for you.",color:"gray"}]
# Generic fallback for any source not in {1,2,3,4,7}.
execute unless score @s ec.gth_src matches 1 unless score @s ec.gth_src matches 2 unless score @s ec.gth_src matches 3 unless score @s ec.gth_src matches 4 unless score @s ec.gth_src matches 7 run data modify storage evercraft:notify stage.c set value [{text:"You've taken all this holds for you.",color:"gray"}]
scoreboard players set #ndur ec.temp 55
function evercraft:util/notify/emit
