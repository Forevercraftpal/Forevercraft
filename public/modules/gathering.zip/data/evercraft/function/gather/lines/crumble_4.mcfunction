# === GATHER — CRUMBLE LINE: NEST (Lamentor) — PLAN-nest-family §2 ===
# Run as @s on the 3rd consecutive fail (nest spent). Names the work learned. Mirrors crumble_2.
data modify storage evercraft:notify stage.c set value [{text:"🐝 ",color:"gold"},{text:"The comb crumbled to nothing",color:"white"},{text:" — the nest emptied before you could draw it out, but your shears found their rhythm. ",color:"gray"},{text:"The craft sticks with you.",color:"green",italic:true}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
