# === GATHER — CRUMBLE LINE: CHEST (Gearwright) — PLAN-chest-nodes §1/§14.1 ===
# Run as @s on the 3rd consecutive fail (chest node spent). Names the work learned. Mirrors crumble_4.
data modify storage evercraft:notify stage.c set value [{text:"⚙ ",color:"#B87333"},{text:"The lock seized and the lid stuck fast",color:"white"},{text:" — the chest gave up nothing, but your hands learned its workings. ",color:"gray"},{text:"The craft sticks with you.",color:"green",italic:true}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
