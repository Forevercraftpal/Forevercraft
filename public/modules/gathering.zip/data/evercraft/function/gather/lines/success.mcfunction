# === GATHER — SUCCESS LINE (lore.md §4 L5, shared across all 3 sources) ===
# Run as @s on a won harvest roll. Full progress earned. Terse, celebratory.
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"Clean harvest!",color:"green"},{text:" Full progress earned.",color:"gray"},{text:" ✦",color:"gold"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
