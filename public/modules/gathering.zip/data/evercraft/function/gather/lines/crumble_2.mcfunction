# === GATHER — CRUMBLE LINE: FORAGE (Growseer) — lore.md §4 L1 ===
# Run as @s on the 3rd consecutive fail (node spent). Names the work learned.
data modify storage evercraft:notify stage.c set value [{text:"✿ ",color:"green"},{text:"The stem slipped your grasp",color:"white"},{text:" — the roots kept the crop, but your hands learned the work. ",color:"gray"},{text:"Progress earned all the same.",color:"green",italic:true},{text:" ✿",color:"green"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
