# === GATHER — CRUMBLE LINE: PROSPECT (Stonestrike) — lore.md §4 L1 ===
# Run as @s on the 3rd consecutive fail (node spent). Celebratory-adjacent: leads with the
# silver lining, names the practice banked. The player already earned quarter-XP each fail.
data modify storage evercraft:notify stage.c set value [{text:"⛏ ",color:"gold"},{text:"The seam finally gave out",color:"white"},{text:" — but the stone taught you plenty. ",color:"gray"},{text:"The practice stays with you.",color:"green",italic:true}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
