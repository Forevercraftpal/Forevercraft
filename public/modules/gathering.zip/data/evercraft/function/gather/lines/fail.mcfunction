# === GATHER — FAIL LINE (lore.md §4 L5, shared; node survives, retry) ===
# Run as @s on a failed roll that did NOT crumble the node (fails 1 or 2). Names the
# half-the-lesson consolation EVERY time so the crumble line at fail #3 can stay short.
data modify storage evercraft:notify stage.c set value [{text:"⟳ ",color:"yellow"},{text:"Not quite",color:"white"},{text:" — but you still learned half the lesson. Try again.",color:"gray"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
