# === GATHER — CRUMBLE LINE: FISHING (Siren Call) — lore.md §4 L1 ===
# Run as @s on the 3rd consecutive fail (node spent). Names the lesson; no bait is consumed.
data modify storage evercraft:notify stage.c set value [{text:"🎣 ",color:"aqua"},{text:"That one wriggled free",color:"white"},{text:" — bait and all. Still, you read the water a little better now. ",color:"gray"},{text:"The lesson holds.",color:"green",italic:true}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
