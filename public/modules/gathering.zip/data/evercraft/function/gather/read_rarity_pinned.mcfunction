# === GATHER — READ RARITY BAND (coord-pinned macro) ===
# Macro — called with storage evercraft:gth_temp {x:X, y:Y, z:Z, dtag:"ec.<type>_data"}.
# Run as @s. Overwrites @s ec.gth_base with the pinned marker's data.rarity IFF present.
# `execute store result` only writes when the `data get` succeeds, so when the marker has
# no data.rarity the seeded default-band-1 from read_rarity survives untouched.
$execute positioned $(x) $(y) $(z) store result score @s ec.gth_base run data get entity @e[type=marker,tag=$(dtag),distance=..2,limit=1,sort=nearest] data.rarity
