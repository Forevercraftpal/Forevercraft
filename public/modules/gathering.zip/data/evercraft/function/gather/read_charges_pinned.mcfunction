# === GATHER — READ NODE CHARGES (coord-pinned macro) ===
# Macro — called with storage evercraft:gth_temp {x:X, y:Y, z:Z, dtag:"ec.<type>_data"}.
# Overwrites @s ec.gth_charges with the marker's data.charges IFF present; otherwise the
# seeded default (2) from read_charges survives.
# BUGFIX (Joseph 2026-06-05): the `if data` GUARD is load-bearing. A bare `store result ...
# run data get <missing path>` writes 0 on failure in 26.1 (it does NOT "leave the score
# untouched") — so unstamped nodes (prospect / forage / nests / buried_cache / fishing — every
# type EXCEPT chest, which stamps its own charges) read 0, decrement to -1, and DESPAWN AFTER
# ONE harvest instead of two. Reading only when data.charges exists preserves the default-2.
$execute positioned $(x) $(y) $(z) if data entity @e[type=marker,tag=$(dtag),distance=..2,limit=1,sort=nearest] data.charges store result score @s ec.gth_charges run data get entity @e[type=marker,tag=$(dtag),distance=..2,limit=1,sort=nearest] data.charges
