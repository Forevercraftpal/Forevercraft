# === GATHER — CLAIM NODE (race C1 — same-tick single-writer claim) ===
# Run as @s (the clicking player), positioned at the player; the caller has ALREADY
# stored the attempted node's coords in evercraft:gth_temp {x,y,z} (the coord-pin,
# mirroring prospect's ec.pr_sx/sy/sz). Outputs @s ec.gth_claimed = 1 IFF this player
# won the coord-pinned marker this tick, else 0.
#
# WHY: under co-op two players can click the same node in the same tick. A count-based
# read-modify-write on the shared marker over-yields / double-crumbles (race R1). Instead
# we tag the marker ec.gth_claimed (idempotent set) IFF untagged, then read back whether
# WE are the claimant — the single tick-winner proceeds to roll + decrement charges; the
# loser's click is dropped (re-click next tick = the "click again to retry" UX). The tag
# is released 1t later by gather/release_claims (scheduled below) so the next click claims.
#
# This is the reusable shape any future persisting-node feature inherits (concurrency §10).

scoreboard players set @s ec.gth_claimed 0
function evercraft:gather/claim_node_pinned with storage evercraft:gth_temp

# Arm the 1t end-of-tick release of the claim tag (only when we actually claimed, so the
# release tick stays non-resident otherwise). `replace` collapses duplicate same-tick arms
# from co-op claimants into one scheduled run; the release is existence-gated regardless.
execute if score @s ec.gth_claimed matches 1 run schedule function evercraft:gather/release_claims 1t replace
