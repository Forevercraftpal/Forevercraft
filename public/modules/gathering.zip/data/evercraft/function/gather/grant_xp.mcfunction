# === GATHER — GRANT CLASS XP (per resolution) ===
# Run as @s AFTER read_rarity + rarity_xp have set @s ec.gth_base to the baseXP, and
# ec.gth_win is set (1=win full XP, 0=fail quarter XP). Maps ec.gth_src -> class_id
# (1->1 ss, 2->3 gs, 3->5 sc) and grants the XP into that Crafting-Class.
#
# Win:  delta = baseXP * areaMult/100 * dreamyMult(=1)   [Wave C1 applies areaMult; Wave D the Dreamy 2×]
# Fail: delta = floor(baseXP / 4), UN-multiplied by anything (balance R7). Also stored in
#       ec.gth_halfxp for the crumble lore line.
#
# DESIGN NOTE: grant PER RESOLUTION (each success/fail grants immediately). The council
# floated "accumulate + once-on-despawn" as a perf optimization — DEFERRED here because
# the 2-charge accumulation across multiplayer claims is stateful/racy. Per-resolution is
# correct + simple now.
# PERF-FOLLOWUP: accumulate ec.gth_xp on the player across charges and flush a single grant
# on despawn (win-or-crumble), once the claim/charge bookkeeping proves stable.
#
# RACE B3: ec.gth_xp is @s-scoped and survives across nothing; #delta ec.temp is set
# IMMEDIATELY before internal_grant (the grant_verb pattern) with no intervening function
# call, so it's consumed before any concurrent harvester's grant can clobber it.

# --- Build the XP for this resolution into @s ec.gth_xp. ---
# Area + Dreamy multipliers layer on here; kept as explicit named scratch so Wave D
# multiplies the Dreamy factor in without touching this contract.
scoreboard players operation @s ec.gth_xp = @s ec.gth_base
# Wave C1 (EQ2 area XP mult): read the node's data.areamult (×100, default 100) and multiply
# the WIN XP by it. gth_temp coord-pin is still the resolution's node (resolve set it). On a
# FAIL the consolation overwrites ec.gth_xp below BEFORE the grant, so the area mult never
# touches fail XP (balance R7) — the order matters: areamult here, then fail-overwrite after.
function evercraft:gather/read_areamult
# Wave C2: clamp areaMult × familiarity here. Home-Turf folds a Biome-Mastery familiarity
# factor (capped so areaMult×familiarity never exceeds the area's ceiling +25%) into
# ec.gth_areamult BEFORE this multiply. Dreamy's 2× (Wave D) stays multiplicative AFTER.
# Curve owned by Biome Mastery (it owns ec.bm_level): gather_familiarity outputs ec.gth_familiar
# = 100 + bm_level*5 (L0->100 ... L5->125). Fold it in: areaMult = areaMult * familiar / 100.
# Because familiar <= 125, the combined areaMult*familiar is INHERENTLY capped at areaMult*1.25
# (the area's ceiling +25%) — that single cap IS the clamp EPIC §8 requires; no extra clamp
# logic. This runs on EVERY grant_xp call, BUT the WIN/FAIL split is preserved by the
# fail-overwrite at the bottom: on a FAIL, ec.gth_xp is overwritten by the un-multiplied quarter
# consolation (ec.gth_halfxp, derived from RAW ec.gth_base) AFTER this multiply, so folding
# familiarity into ec.gth_areamult never touches fail XP (balance R7). Win path only, by order.
function evercraft:biome_mastery/gather_familiarity
scoreboard players operation @s ec.gth_areamult *= @s ec.gth_familiar
scoreboard players operation @s ec.gth_areamult /= #gth_c100 ec.var
scoreboard players operation @s ec.gth_xp *= @s ec.gth_areamult
scoreboard players operation @s ec.gth_xp /= #gth_c100 ec.var

# Wave D2 (2× XP on a landed Dreamy Pull): on a WIN, snapshot the granted win-XP NOW —
# this is baseXP × areaMult × familiar (the full area-multiplicative win value), captured
# BEFORE the fail-overwrite below so it never holds the quarter consolation. maybe_trigger
# copies it into the Dreamy session (ec.dp_bonusxp); give_good_find re-grants it on a won
# minigame to achieve 2× (original 1× + this 1×). Gated on WIN: a fail leaves the prior
# snapshot untouched, but a Dreamy Pull only ever follows a WIN (maybe_trigger fires from the
# _success tails) so the snapshot read by give_good_find always belongs to that winning node.
execute if score @s ec.gth_win matches 1 run scoreboard players operation @s ec.gth_lastxp = @s ec.gth_xp

# Quarter-XP consolation (fail). floor(baseXP/4); stored for the lore line either way.
# Computed from ec.gth_base (the RAW baseXP, NOT the area-multiplied ec.gth_xp) so the fail
# consolation is UN-multiplied by area/Dreamy (balance R7).
scoreboard players operation @s ec.gth_halfxp = @s ec.gth_base
scoreboard players operation @s ec.gth_halfxp /= #gth_4 ec.var

# On a FAIL, the granted delta is the quarter consolation, UN-multiplied (balance R7). This
# overwrites the area-multiplied ec.gth_xp above, so a fail never gets the area bonus.
execute if score @s ec.gth_win matches 0 run scoreboard players operation @s ec.gth_xp = @s ec.gth_halfxp

# --- Map source -> class_id and grant via internal_grant (grant_verb pattern). ---
execute if score @s ec.gth_src matches 1 run scoreboard players set @s ec.caff_class 1
execute if score @s ec.gth_src matches 2 run scoreboard players set @s ec.caff_class 3
execute if score @s ec.gth_src matches 3 run scoreboard players set @s ec.caff_class 5
# Nest family (PLAN-nest-family §2, ADDITIVE — R3 blast-radius guard): gth_src=4 -> Lamentor
# (the shears Craft-Affinity class, class_id 6). The #caff_node cap-flag below + internal_grant
# are reached unchanged, so the 50k/day cap applies to nests too (R8 cap-leak guard).
execute if score @s ec.gth_src matches 4 run scoreboard players set @s ec.caff_class 6
# Chest-Node family (PLAN-chest-nodes §1/§14.1, ADDITIVE — never touch src 1-4): gth_src=5 -> Gearwright
# (the 7th Craft-Affinity class, class_id 7). The #caff_node cap-flag below + internal_grant are reached
# unchanged. NOTE: Gearwright has NO daily cap (§14.5) — internal_grant's daily_cap pass is a no-op for
# class 7 (no cdaff write, no class-7 row), so the node flag is harmless here (it just gates the unused
# cap path). Chest XP's real limiter is the ~3/MC-day node spawn, not a per-class counter.
execute if score @s ec.gth_src matches 5 run scoreboard players set @s ec.caff_class 7
# Buried Cache family (Terrawarp dig node, ADDITIVE — never touch src 1-5): gth_src=7 -> Terrawarp
# (the 4th Craft-Affinity class, class_id 4 -> ec.caffl_tw). The #caff_node cap-flag below +
# internal_grant are reached unchanged, so the 50k/day node cap applies to Terrawarp too. Terrawarp
# IS the only gather class that lacked a node until now, so this completes the per-class node set.
execute if score @s ec.gth_src matches 7 run scoreboard players set @s ec.caff_class 4

# delta = the resolution XP. Set #delta immediately before the grant (no function call
# between this and internal_grant) so the shared ec.temp can't be clobbered mid-grant.
scoreboard players operation #delta ec.temp = @s ec.gth_xp
# node:1b (balance #11): NODE XP must respect the 50k/day cap EVEN for spirit-tool holders —
# area multipliers make node grinding too lucrative to let spirit-holders bypass. internal_grant
# applies daily_cap `unless @s[tag=ec.st_held] OR #caff_node matches 1`. We set the flag here,
# immediately before the grant (no intervening function call → the shared ec.temp can't be
# clobbered between set + read), then internal_grant resets it to 0 so OTHER grant callers (who
# never set it → default 0) keep the old spirit-bypass behaviour untouched.
scoreboard players set #caff_node ec.temp 1
function evercraft:craft_affinity/internal_grant
