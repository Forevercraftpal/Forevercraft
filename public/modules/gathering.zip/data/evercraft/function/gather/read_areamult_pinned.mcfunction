# === GATHER — READ AREA XP MULTIPLIER (coord-pinned macro) ===
# Macro — called with storage evercraft:gth_temp {x:X, y:Y, z:Z, dtag:"ec.<type>_data"}.
# Run as @s. Overwrites @s ec.gth_areamult with the pinned marker's data.areamult IFF present.
# `execute store result` only writes when the `data get` succeeds, so when the marker has no
# data.areamult the seeded default-100 (×1.0) from read_areamult survives untouched. Mirrors
# read_rarity_pinned.
$execute positioned $(x) $(y) $(z) store result score @s ec.gth_areamult run data get entity @e[type=marker,tag=$(dtag),distance=..2,limit=1,sort=nearest] data.areamult
