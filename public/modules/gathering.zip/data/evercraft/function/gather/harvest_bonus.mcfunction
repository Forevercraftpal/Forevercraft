# === GATHER — UNIFIED HARVEST BONUS (the lucky-bonus layer, shared by EVERY node) ===========
# Run as @s on ANY node's SUCCESS (prospect / forage / nest / fishing / chest / timberfall / buried
# cache). Rolls INDEPENDENT small chances for: (a) a Forever Coin, (b) a generic bonus crate, (c) a
# cross-node custom (random glyph, else a bonus potion ingredient). The DREAMY is NOT rolled here —
# it stays each node's own per-node maybe_trigger (already universal). This is purely the coin/crate/
# customs layer the SPEC unifies. inv-full honored (loot give vs loot spawn @s) like the nodes.
#
# ---- TUNABLE INPUTS (caller may pre-set on ec.temp; all default if unset) -----------------------
#   #hb_crate_thresh ec.temp: crate fires on `random 1..700 <= thresh` (so thresh 7 = 1/100, the old
#       per-node rate; thresh 1 = 1/700, forage's ocean/kelp anti-farm nerf). 0 = NO crate (a node
#       whose crate is owned by another channel — chest/fishing — passes 0). 700-roll basis mirrors
#       forage/complete_gather_success's existing crate roll EXACTLY (literal bound; `random value`
#       cannot take a score, so we keep the fixed 1..700 basis + a threshold score).
#   #hb_coin_pct ec.temp    : Forever-Coin chance %. Default 3 (forage's old 3%). 0 = no coin.
#   #hb_custom_pct ec.temp  : cross-node-custom chance %. Default 2. 0 = no custom.
# A caller that wants the defaults sets NONE of them + leaves #hb_cfg 0 — the seed block fills the
# defaults. A caller that wants non-default values sets #hb_cfg 1 + ALL three scores itself
# (grant_verb: set immediately before the call, no intervening fn). The forage/prospect/nest
# migrations set #hb_cfg 1 + their values; fishing/chest/timberfall/cache use #hb_cfg 0 (defaults).
execute unless score #hb_cfg ec.temp matches 1 run scoreboard players set #hb_crate_thresh ec.temp 7
execute unless score #hb_cfg ec.temp matches 1 run scoreboard players set #hb_coin_pct ec.temp 3
execute unless score #hb_cfg ec.temp matches 1 run scoreboard players set #hb_custom_pct ec.temp 2

# ========================= (a) FOREVER COIN ========================================
# RATE: #hb_coin_pct % per success (default 3%). Gives forever_coin_1..3 (1..3 amethyst-shard coins),
# weighted toward the smallest (a coin is a steady trickle, never a jackpot). inv-full guarded.
execute if score #hb_coin_pct ec.temp matches 1.. store result score #hb_coin_roll ec.temp run random value 1..100
execute if score #hb_coin_pct ec.temp matches 1.. if score #hb_coin_roll ec.temp <= #hb_coin_pct ec.temp run function evercraft:gather/harvest_bonus_coin

# ========================= (b) BONUS CRATE =========================================
# RATE: random 1..700 <= #hb_crate_thresh (default 7 = 1/100; forage ocean thresh 1 = 1/700). inv-full
# guarded. The roll basis (1..700) is FIXED — only the threshold varies per node (literal-bound rule).
scoreboard players set #hb_crate_hit ec.temp 0
execute if score #hb_crate_thresh ec.temp matches 1.. store result score #hb_crate_roll ec.temp run random value 1..700
execute if score #hb_crate_thresh ec.temp matches 1.. if score #hb_crate_roll ec.temp <= #hb_crate_thresh ec.temp run scoreboard players set #hb_crate_hit ec.temp 1
execute if score #hb_crate_hit ec.temp matches 1 store result score #inv_full ec.var run function evercraft:util/check_inv_full
execute if score #hb_crate_hit ec.temp matches 1 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:cooking/bonus_crate
execute if score #hb_crate_hit ec.temp matches 1 if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:cooking/bonus_crate
data modify storage evercraft:notify stage.c set value [{text:"A crate turned up with your haul!",color:"yellow"}]
scoreboard players set #ndur ec.temp 45
execute if score #hb_crate_hit ec.temp matches 1 run function evercraft:util/notify/emit
execute if score #hb_crate_hit ec.temp matches 1 if score #inv_full ec.var matches 1 if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bass player @s ~ ~ ~ 1 0.5

# ========================= (c) CROSS-NODE CUSTOM ===================================
# RATE: #hb_custom_pct % per success (default 2%). On a hit: 50/50 a random Glyph vs a bonus potion
# ingredient — the non-node-specific drops the Dreamy already grants, surfaced as a direct chance.
# grant_random_glyph + bonus_potion_ingredient each handle their own give/inv-full internally.
execute if score #hb_custom_pct ec.temp matches 1.. store result score #hb_cust_roll ec.temp run random value 1..100
execute if score #hb_custom_pct ec.temp matches 1.. if score #hb_cust_roll ec.temp <= #hb_custom_pct ec.temp store result score #hb_cust_pick ec.temp run random value 1..2
execute if score #hb_custom_pct ec.temp matches 1.. if score #hb_cust_roll ec.temp <= #hb_custom_pct ec.temp if score #hb_cust_pick ec.temp matches 1 run function evercraft:gacha/pull/grant_random_glyph
execute if score #hb_custom_pct ec.temp matches 1.. if score #hb_cust_roll ec.temp <= #hb_custom_pct ec.temp if score #hb_cust_pick ec.temp matches 2 run function evercraft:forage/bonus_potion_ingredient

# --- Reset the config flag so the NEXT caller (which may not set it) starts from defaults. The three
# value scores are re-seeded at the top of every call, so they don't need resetting here. ---
scoreboard players set #hb_cfg ec.temp 0
