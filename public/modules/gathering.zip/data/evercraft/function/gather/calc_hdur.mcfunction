# === GATHER — HARVEST-TIMER DURATION (skill-scaled, Joseph 2026-06-03) ===
# Input:  #gd ec.temp = the driving gather-class level (ec.caffl_*, 0-100).
# Output: #gd ec.temp = harvest-channel length in ticks: 100t (5s) at L0 -> 30t (1.5s) at L100
#         (-7t per 10 levels), floored at 30t. Shared by forage / prospect / nest / splash starts.
# #gd is the OUTPUT and is copied out immediately by the caller; nothing here churns ec.temp across a
# function call (unlike resolve/grant), so this scratch use is safe.
scoreboard players operation #gd ec.temp *= #gth_c7 ec.var
scoreboard players operation #gd ec.temp /= #gth_c10 ec.var
scoreboard players operation #gd2 ec.temp = #gd ec.temp
scoreboard players operation #gd ec.temp = #gth_c100 ec.var
scoreboard players operation #gd ec.temp -= #gd2 ec.temp
execute if score #gd ec.temp matches ..30 run scoreboard players set #gd ec.temp 30
