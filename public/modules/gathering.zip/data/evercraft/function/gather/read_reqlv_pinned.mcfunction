# === GATHER — READ AREA reqLv (coord-pinned macro) ===
# Macro — called with storage evercraft:gth_temp {x:X, y:Y, z:Z, dtag:"ec.<type>_data"}.
# Run as @s. Overwrites @s ec.gth_reqlv with the pinned marker's data.reqlv IFF present.
# `execute store result` only writes when the `data get` succeeds, so when the marker has no
# data.reqlv the seeded default-0 from read_reqlv survives untouched. Mirrors read_rarity_pinned.
$execute positioned $(x) $(y) $(z) store result score @s ec.gth_reqlv run data get entity @e[type=marker,tag=$(dtag),distance=..2,limit=1,sort=nearest] data.reqlv
