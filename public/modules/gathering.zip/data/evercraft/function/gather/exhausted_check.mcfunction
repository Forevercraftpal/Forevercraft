# === GATHER — EXHAUSTED GATE (per-player click-START lock) ===
# Run as @s = the harvesting player, at the player, from each family's START fn AFTER it has
# coord-pinned THIS node into evercraft:gth_temp {x,y,z,dtag} AND set ec.gth_src (1=prospect /
# 2=forage / 3=splash / 4=nest / 7=cache). Mirrors chest_nodes/exhausted_gate: a player who has
# spent all their per-player charges on this node (or crumbled it) gets nothing more here — we
# block the channel BEFORE the boss bar / progress begins so a spent-FOR-YOU node is truly inert,
# while it stays fully live for everyone else (the node despawns only on its own time-despawn).
#
# Output: #gth_exhausted ec.temp = 1 -> the caller must `return 0` (do NOT start the channel).
# First touch (no entry yet): seed @s's per-player charges to the node's base count and let the
# harvest proceed (#gth_exhausted 0). SINGLE writer of #gth_exhausted = here.

scoreboard players set #gth_exhausted ec.temp 0

# Build the per-player payload (coords + dtag + @s UUID) from the caller's gth_temp pin.
function evercraft:gather/pp/prep
function evercraft:gather/pp/get with storage evercraft:gth_pp

# First touch -> seed this player's charges to the node's base count (read the marker's
# data.charges via the existing read_charges idiom; default 2 when unstamped). No block.
execute if score #gth_pp_has ec.temp matches 0 run function evercraft:gather/read_charges
execute if score #gth_pp_has ec.temp matches 0 store result storage evercraft:gth_pp left int 1 run scoreboard players get @s ec.gth_charges
execute if score #gth_pp_has ec.temp matches 0 run function evercraft:gather/pp/init with storage evercraft:gth_pp

# Already have an entry AND it is spent (left <= 0) -> BLOCK + the per-source flavor line.
execute if score #gth_pp_has ec.temp matches 1 if score #gth_pp_left ec.temp matches ..0 run scoreboard players set #gth_exhausted ec.temp 1
execute if score #gth_exhausted ec.temp matches 1 run function evercraft:gather/lines/spent
