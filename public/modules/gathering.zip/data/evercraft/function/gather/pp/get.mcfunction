# === GATHER — PER-PLAYER GET (read @s's remaining charges off the pinned node) ===
# Macro `function ... with storage evercraft:gth_pp`. The caller MUST have run gather/pp/prep
# (x,y,z,dtag,u0..u3). Outputs:
#   #gth_pp_has  ec.temp = 1 iff @s already has an entry in this node's data.pp list, else 0.
#   #gth_pp_left ec.temp = @s's remaining charges (their entry's .left) when present, else -1.
# SINGLE writer of #gth_pp_has / #gth_pp_left = here. Coord-pinned (positioned $(x) $(y) $(z),
# distance=..2) — never a racy sort across the field; this is THIS node.
#
# Membership: data.pp[{u:[I;u0,u1,u2,u3]}] is a compound-list element filter — it matches the
# element whose u array equals @s's UUID (the same [{...}] selector the codebase uses to read/
# write a specific Items[{Slot:N}] element). A missing list / absent entry simply never matches,
# leaving has=0 + left=-1 (the "first touch" sentinel the init path keys off).

scoreboard players set #gth_pp_has ec.temp 0
scoreboard players set #gth_pp_left ec.temp -1
$execute positioned $(x) $(y) $(z) if data entity @e[type=marker,tag=$(dtag),distance=..2,limit=1,sort=nearest] data.pp[{u:[I;$(u0),$(u1),$(u2),$(u3)]}] run scoreboard players set #gth_pp_has ec.temp 1
$execute positioned $(x) $(y) $(z) if score #gth_pp_has ec.temp matches 1 store result score #gth_pp_left ec.temp run data get entity @e[type=marker,tag=$(dtag),distance=..2,limit=1,sort=nearest] data.pp[{u:[I;$(u0),$(u1),$(u2),$(u3)]}].left
