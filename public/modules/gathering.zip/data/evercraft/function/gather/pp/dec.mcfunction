# === GATHER — PER-PLAYER DECREMENT (@s spends one charge on the pinned node) ===
# Run as @s. Requires gather/pp/prep already populated gth_pp (x,y,z,dtag,u0..u3). Reads @s's
# current remaining charges, subtracts 1, writes it back. Run ONLY by the per-tick claim winner
# inside resolve_win, so the read-subtract-write is single-writer-safe (the claim guarantees no
# other harvester decrements THIS player's entry this tick — and entries are per-UUID anyway).
#
# Idempotency / safety: get reports #gth_pp_has + #gth_pp_left. If @s somehow has no entry yet
# (resolve reached before the exhausted_check init — should not happen, the gate inits on first
# touch), seed it at base-1 via append so the win still counts a spent charge. Otherwise rewrite.
# All scratch in ec.temp (the per-resolution churn namespace); #gth_pp_left is republished for
# resolve_win to branch on <=0.

function evercraft:gather/pp/get with storage evercraft:gth_pp
# No entry yet -> seed #gth_pp_left to the base charge count so the -1 below lands at base-1.
execute if score #gth_pp_has ec.temp matches 0 run scoreboard players operation #gth_pp_left ec.temp = #gth_charges_default ec.var
# Decrement (floored at 0 so a stray double-dec can't go negative).
scoreboard players remove #gth_pp_left ec.temp 1
execute if score #gth_pp_left ec.temp matches ..-1 run scoreboard players set #gth_pp_left ec.temp 0
execute store result storage evercraft:gth_pp left int 1 run scoreboard players get #gth_pp_left ec.temp
# Existing entry -> rewrite its .left; first-touch fallback -> append a fresh entry.
execute if score #gth_pp_has ec.temp matches 1 run function evercraft:gather/pp/set_left with storage evercraft:gth_pp
execute if score #gth_pp_has ec.temp matches 0 run function evercraft:gather/pp/init with storage evercraft:gth_pp
