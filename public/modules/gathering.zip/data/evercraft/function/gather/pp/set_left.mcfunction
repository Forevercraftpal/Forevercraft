# === GATHER — PER-PLAYER SET-LEFT (write @s's remaining charges on the pinned node) ===
# Macro `function ... with storage evercraft:gth_pp`. The caller MUST have run gather/pp/prep
# AND set gth_pp.left = the new value to store. Overwrites @s's existing entry's .left on the
# pinned marker (the [{u:...}] compound-list element filter targets exactly @s's entry — the
# same idiom the codebase uses for Items[{Slot:N}].count writes). Coord-pinned, distance=..2.
#
# Caller-guaranteed: @s already HAS an entry (gather/pp/get reported #gth_pp_has 1). Used by
# the resolve win/exhaust paths, which only run for the per-tick claim winner — so this write
# is single-writer-safe relative to any other harvester on the same node this tick.

$execute positioned $(x) $(y) $(z) run data modify entity @e[type=marker,tag=$(dtag),distance=..2,limit=1,sort=nearest] data.pp[{u:[I;$(u0),$(u1),$(u2),$(u3)]}].left set value $(left)
