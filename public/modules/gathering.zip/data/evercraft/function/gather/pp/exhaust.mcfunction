# === GATHER — PER-PLAYER EXHAUST (mark @s spent on the pinned node) ===
# Run as @s. Requires gather/pp/prep already populated gth_pp (x,y,z,dtag,u0..u3). Forces @s's
# remaining charges to 0 so the next click's exhausted_check blocks them (the node stays fully
# live for everyone else). Used by resolve_crumble (the 3rd-fail spend-out is per-player now —
# the node is NOT despawned globally). Run only for the per-tick claim winner.
#
# If @s has no entry yet (a crumble before any win — possible: 3 straight fails on first touch),
# the exhausted_check already inited the entry at base charges before the channel started, so an
# entry exists; set_left to 0 rewrites it. The append-fallback covers the should-not-happen
# no-entry case so a crumbling node still records the player as spent.

function evercraft:gather/pp/get with storage evercraft:gth_pp
data modify storage evercraft:gth_pp left set value 0
execute if score #gth_pp_has ec.temp matches 1 run function evercraft:gather/pp/set_left with storage evercraft:gth_pp
execute if score #gth_pp_has ec.temp matches 0 run function evercraft:gather/pp/init with storage evercraft:gth_pp
scoreboard players set #gth_pp_left ec.temp 0
