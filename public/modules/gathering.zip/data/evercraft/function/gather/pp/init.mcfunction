# === GATHER — PER-PLAYER INIT (first-touch: seed @s's charge entry on the node) ===
# Macro `function ... with storage evercraft:gth_pp`. The caller MUST have run gather/pp/prep
# AND set gth_pp.left = the node's BASE charge count for this player (the seed). Appends
# {u:[I;u0,u1,u2,u3], left:<seed>} to the pinned marker's data.pp list — `append` AUTO-CREATES
# the list if absent, so no spawn-time init is needed.
#
# IDEMPOTENCY IS THE CALLER'S JOB: only call init when gather/pp/get reported #gth_pp_has 0
# (no existing entry). Coord-pinned (positioned $(x) $(y) $(z), distance=..2) so a crowd never
# seeds the wrong node. Single-writer note: under the per-tick claim only the claim winner ever
# reaches the resolve path; the exhausted_check init runs at click-START (no claim yet) — two
# players first-touching the SAME node in the same tick run their init macros SERIALLY (function
# bodies never interleave mid-body), so each appends its own distinct UUID entry. They cannot
# clobber one another (different u arrays), and a player re-touching after their own init is
# gated out by the get-has check, so no duplicate entry is ever appended for the same player.

$execute positioned $(x) $(y) $(z) run data modify entity @e[type=marker,tag=$(dtag),distance=..2,limit=1,sort=nearest] data.pp append value {u:[I;$(u0),$(u1),$(u2),$(u3)],left:$(left)}
