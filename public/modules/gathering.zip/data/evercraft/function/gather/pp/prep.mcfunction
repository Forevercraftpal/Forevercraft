# === GATHER — PER-PLAYER PREP (populate the per-player charge macro payload) ===
# Run as @s, positioned AT THE PLAYER, AFTER the caller has coord-pinned THIS node into
# evercraft:gth_temp {x,y,z,dtag:"ec.<type>_data"}. Builds storage evercraft:gth_pp
# {x,y,z,dtag,u0..u3} = the pinned node coords + tag + the harvester's UUID ints.
#
# This is the shared payload every gather/pp/{get,init,dec,exhaust} macro reads — populate
# ONCE per attempt (the exhausted_check / resolve paths call it right after their coord-pin).
# Mirrors chest_nodes/claim/prep exactly (the proven per-player marker idiom), but carries
# dtag too so the macros bind to the right family's node tag.
#
# The per-player charge STATE lives on the marker as data.pp:[{u:[I;u0,u1,u2,u3],left:N}]
# (a compound list; @s's entry is matched by {u:[I;u0,u1,u2,u3]} in the get/dec/exhaust
# macros). gth_pp is just the per-call scratch carrying coords + tag + UUID into the macro.
# ONE writer of storage gth_pp = here.

# Node coords + tag from the caller's coord-pin (gth_temp).
data modify storage evercraft:gth_pp x set from storage evercraft:gth_temp x
data modify storage evercraft:gth_pp y set from storage evercraft:gth_temp y
data modify storage evercraft:gth_pp z set from storage evercraft:gth_temp z
data modify storage evercraft:gth_pp dtag set from storage evercraft:gth_temp dtag
# The harvester's UUID as four ints (the [I;u0,u1,u2,u3] array form used in data.pp[].u).
execute store result storage evercraft:gth_pp u0 int 1 run data get entity @s UUID[0]
execute store result storage evercraft:gth_pp u1 int 1 run data get entity @s UUID[1]
execute store result storage evercraft:gth_pp u2 int 1 run data get entity @s UUID[2]
execute store result storage evercraft:gth_pp u3 int 1 run data get entity @s UUID[3]
