# === GATHER — WRITE NODE CHARGES BACK (coord-pinned macro) ===
# Macro — called with storage evercraft:gth_temp {x:X, y:Y, z:Z, dtag:"ec.<type>_data",
# charges:N}. Writes data.charges = N onto the pinned marker. Called ONLY by the claim
# winner inside resolve, so the read-subtract-write is single-writer-safe (the claim tag
# guarantees no other player decrements this marker this tick — race R1a reduced to one
# guarded decrement). Marker NBT writes are legal (forage/apply_variant precedent).
$execute positioned $(x) $(y) $(z) run data modify entity @e[type=marker,tag=$(dtag),distance=..2,limit=1,sort=nearest] data.charges set value $(charges)
