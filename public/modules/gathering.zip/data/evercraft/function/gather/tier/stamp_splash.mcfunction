# === GATHER · C1-TIER — STAMP SPLASH NODE AREA TIER (reqLv + areaMult) ===
# Called from evercraft:fishing/splash_nodes/place_node, right after gather/rarity/stamp_splash,
# while the just-spawned marker still carries the ec.splash_new tag AND we are positioned at
# the surface. Stamps data.reqlv (int) + data.areamult (int ×100) on the SAME ec.splash_data
# marker that gather/read_reqlv + gather/read_areamult read at harvest.
#
# Splash nodes are only ever overworld water (dim 1) or nether lava (dim 2) — there is no sky/
# end/deep-dark splash placement — so the tier set here is the small relevant subset:
#   dim 2 (nether lava)        -> Nether 60 / 250  (keyed off spl_temp.node_dim, like rarity)
#   dim 1 + ocean biome        -> Ocean  40 / 200
#   dim 1 + river biome        -> River  30 / 175
#   dim 1 + anything else (pond)-> Normal 0 / 100  (the default below)
#
# PRECEDENCE: default Normal, then ocean/river overwrite (only one biome matches at a given
# surface), then the nether-dim row overwrites both (it sits last + can't coexist with an
# overworld biome anyway). Mirrors gather/tier/stamp_prospect's low->high overwrite shape.
#
# Verify: nether lava node -> 60/250 ; ocean splash -> 40/200 ; river splash -> 30/175 ;
# pond/lake splash -> 0/100.

# --- Tier 0: Normal pond/lake (default). ---
data modify entity @e[type=marker,tag=ec.splash_new,limit=1,distance=..1] data.reqlv set value 0
data modify entity @e[type=marker,tag=ec.splash_new,limit=1,distance=..1] data.areamult set value 100

# --- Tier: River 30 / 175 (overworld water in a river biome). ---
execute if predicate evercraft:biome/is_river run data modify entity @e[type=marker,tag=ec.splash_new,limit=1,distance=..1] data.reqlv set value 30
execute if predicate evercraft:biome/is_river run data modify entity @e[type=marker,tag=ec.splash_new,limit=1,distance=..1] data.areamult set value 175

# --- Tier: Ocean 40 / 200 (overworld water in an ocean biome). ---
execute if predicate evercraft:biome/is_ocean run data modify entity @e[type=marker,tag=ec.splash_new,limit=1,distance=..1] data.reqlv set value 40
execute if predicate evercraft:biome/is_ocean run data modify entity @e[type=marker,tag=ec.splash_new,limit=1,distance=..1] data.areamult set value 200

# --- Tier: Nether lava node 60 / 250 (dim 2 — overwrites any overworld biome match). ---
# Keyed off the dim flag the caller stamped (spl_temp.node_dim 2), matching the rarity stamp,
# rather than a nether biome predicate — a lava node IS the nether tier by construction.
execute if data storage evercraft:spl_temp {node_dim:2} run data modify entity @e[type=marker,tag=ec.splash_new,limit=1,distance=..1] data.reqlv set value 60
execute if data storage evercraft:spl_temp {node_dim:2} run data modify entity @e[type=marker,tag=ec.splash_new,limit=1,distance=..1] data.areamult set value 250
