# === GATHER · C1-TIER — STAMP PROSPECT NODE AREA TIER (reqLv + areaMult) ===
# Called from evercraft:prospect/place_node, right after gather/rarity/stamp_prospect,
# while the just-spawned marker still carries the ec.prospect_new tag AND we are positioned
# at the node block. Stamps data.reqlv (int) + data.areamult (int ×100) on the SAME
# ec.prospect_data marker that gather/read_reqlv + gather/read_areamult read at harvest.
#
# AREA tier = the EQ2 difficulty of WHERE the node spawned (LOCKED v2 table). This is the
# orthogonal axis to data.rarity (which is the drop-POOL item rarity) — a node carries BOTH:
#   data.rarity  -> baseXP band  (gather/rarity/stamp_prospect)
#   data.reqlv   -> success-roll difficulty subtraction (this file)
#   data.areamult-> win-XP area multiplier ×100        (this file)
#
# PRECEDENCE (highest tier wins). The `execute if` chain runs LOW -> HIGH so the strongest
# match writes last and overwrites weaker ones — mirroring the place_node biome cascade.
# Special care: Deep Dark sits INSIDE the Y-64..0 deepslate band, so the deepslate row is
# gated `unless is_deep_dark`; dimension End/Nether + biome Deep Dark sit at the BOTTOM of
# the chain so they overwrite any Y-band / biome that also matched.
#
# Inputs: positioned at the node block (predicates test biome/dim/Y here). pale_garden has
# its OWN predicate now (was lumped into is_dark_forest), so the rare-biome gate never leaks
# onto ordinary Dark Forest. mushroom = craftforever/biome/mushroom (mushroom_fields).
#
# Verify (precedence): End node -> 50/350 ; Deep-Dark node -> 70/300 ; ordinary Y=-30 stone
# node -> 30/150 ; plains-surface node -> 0/100.

# --- Tier 0: Normal (default — everything else). ---
data modify entity @e[type=marker,tag=ec.prospect_new,limit=1,distance=..1] data.reqlv set value 0
data modify entity @e[type=marker,tag=ec.prospect_new,limit=1,distance=..1] data.areamult set value 100

# --- Tier: Rare biomes (mushroom / pale_garden / lush_caves / dripstone_caves) 20 / 150. ---
execute if predicate evercraft:craftforever/biome/mushroom run data modify entity @e[type=marker,tag=ec.prospect_new,limit=1,distance=..1] data.reqlv set value 20
execute if predicate evercraft:craftforever/biome/mushroom run data modify entity @e[type=marker,tag=ec.prospect_new,limit=1,distance=..1] data.areamult set value 150
execute if predicate evercraft:biome/is_pale_garden run data modify entity @e[type=marker,tag=ec.prospect_new,limit=1,distance=..1] data.reqlv set value 20
execute if predicate evercraft:biome/is_pale_garden run data modify entity @e[type=marker,tag=ec.prospect_new,limit=1,distance=..1] data.areamult set value 150
execute if predicate evercraft:biome/is_lush_caves run data modify entity @e[type=marker,tag=ec.prospect_new,limit=1,distance=..1] data.reqlv set value 20
execute if predicate evercraft:biome/is_lush_caves run data modify entity @e[type=marker,tag=ec.prospect_new,limit=1,distance=..1] data.areamult set value 150
execute if predicate evercraft:biome/is_dripstone_caves run data modify entity @e[type=marker,tag=ec.prospect_new,limit=1,distance=..1] data.reqlv set value 20
execute if predicate evercraft:biome/is_dripstone_caves run data modify entity @e[type=marker,tag=ec.prospect_new,limit=1,distance=..1] data.areamult set value 150

# --- Tier: Generic deepslate band (Y -64..0, NOT deep_dark) 30 / 150. ---
# Gated `unless is_deep_dark` so the Deep-Dark row (bottom) wins inside the same Y band.
# Placed BEFORE River so a deep river bed (Y<0 river) reads the higher river 175 mult, not 150
# (same reqLv 30, but river is the stronger area-mult tier — "highest tier wins").
execute if predicate evercraft:position/deepslate_band unless predicate evercraft:biome/is_deep_dark run data modify entity @e[type=marker,tag=ec.prospect_new,limit=1,distance=..1] data.reqlv set value 30
execute if predicate evercraft:position/deepslate_band unless predicate evercraft:biome/is_deep_dark run data modify entity @e[type=marker,tag=ec.prospect_new,limit=1,distance=..1] data.areamult set value 150

# --- Tier: River 30 / 175 (writes after deepslate so a Y<0 river bed wins the 175 mult). ---
execute if predicate evercraft:biome/is_river run data modify entity @e[type=marker,tag=ec.prospect_new,limit=1,distance=..1] data.reqlv set value 30
execute if predicate evercraft:biome/is_river run data modify entity @e[type=marker,tag=ec.prospect_new,limit=1,distance=..1] data.areamult set value 175

# --- Tier: Ocean 40 / 200. ---
execute if predicate evercraft:biome/is_ocean run data modify entity @e[type=marker,tag=ec.prospect_new,limit=1,distance=..1] data.reqlv set value 40
execute if predicate evercraft:biome/is_ocean run data modify entity @e[type=marker,tag=ec.prospect_new,limit=1,distance=..1] data.areamult set value 200

# --- Tier: Sky (Y >= 128) 40 / 200. ---
execute if predicate evercraft:position/sky_128 run data modify entity @e[type=marker,tag=ec.prospect_new,limit=1,distance=..1] data.reqlv set value 40
execute if predicate evercraft:position/sky_128 run data modify entity @e[type=marker,tag=ec.prospect_new,limit=1,distance=..1] data.areamult set value 200

# --- Tier: The End 50 / 350 (D2: masterable). Dimension overwrites any Y/biome match. ---
execute if predicate evercraft:in_end run data modify entity @e[type=marker,tag=ec.prospect_new,limit=1,distance=..1] data.reqlv set value 50
execute if predicate evercraft:in_end run data modify entity @e[type=marker,tag=ec.prospect_new,limit=1,distance=..1] data.areamult set value 350

# --- Tier: Nether (any nether biome / dimension) 60 / 250. ---
execute if predicate evercraft:in_nether run data modify entity @e[type=marker,tag=ec.prospect_new,limit=1,distance=..1] data.reqlv set value 60
execute if predicate evercraft:in_nether run data modify entity @e[type=marker,tag=ec.prospect_new,limit=1,distance=..1] data.areamult set value 250

# --- Tier: Deep Dark 70 / 300 (highest — overrides the deepslate Y-band it sits inside). ---
execute if predicate evercraft:biome/is_deep_dark run data modify entity @e[type=marker,tag=ec.prospect_new,limit=1,distance=..1] data.reqlv set value 70
execute if predicate evercraft:biome/is_deep_dark run data modify entity @e[type=marker,tag=ec.prospect_new,limit=1,distance=..1] data.areamult set value 300
