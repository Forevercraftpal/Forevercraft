# === GATHER · C1-TIER — STAMP FORAGE BUSH AREA TIER (reqLv + areaMult) ===
# Called from evercraft:forage/place_bush, right after gather/rarity/stamp_forage, while the
# just-spawned marker still carries the ec.forage_new tag AND we are positioned at the bush.
# Stamps data.reqlv (int) + data.areamult (int ×100) on the SAME ec.forage_data marker that
# gather/read_reqlv + gather/read_areamult read at harvest. Same area axis + precedence as
# gather/tier/stamp_prospect — see that file's header for the full design.
#
# Forage bushes spawn in the 14 overworld biomes today (no nether/end placement), so the
# nether/end/deep-dark rows below are inert at present — kept for symmetry + Wave-E underwater
# forage (ocean/river-bottom bushes), where ocean/river rows DO fire. Default 0/100 covers
# every plains-tier surface bush.
#
# PRECEDENCE: low -> high; highest match overwrites. Deep-Dark gates the deepslate Y-band off.
#
# Verify: ocean-floor bush -> 40/200 ; river-floor bush -> 30/175 ; plains bush -> 0/100.

# --- Tier 0: Normal (default). ---
data modify entity @e[type=marker,tag=ec.forage_new,limit=1,distance=..1] data.reqlv set value 0
data modify entity @e[type=marker,tag=ec.forage_new,limit=1,distance=..1] data.areamult set value 100

# --- Tier: Rare biomes (mushroom / pale_garden / lush_caves / dripstone_caves) 20 / 150. ---
execute if predicate evercraft:craftforever/biome/mushroom run data modify entity @e[type=marker,tag=ec.forage_new,limit=1,distance=..1] data.reqlv set value 20
execute if predicate evercraft:craftforever/biome/mushroom run data modify entity @e[type=marker,tag=ec.forage_new,limit=1,distance=..1] data.areamult set value 150
execute if predicate evercraft:biome/is_pale_garden run data modify entity @e[type=marker,tag=ec.forage_new,limit=1,distance=..1] data.reqlv set value 20
execute if predicate evercraft:biome/is_pale_garden run data modify entity @e[type=marker,tag=ec.forage_new,limit=1,distance=..1] data.areamult set value 150
execute if predicate evercraft:biome/is_lush_caves run data modify entity @e[type=marker,tag=ec.forage_new,limit=1,distance=..1] data.reqlv set value 20
execute if predicate evercraft:biome/is_lush_caves run data modify entity @e[type=marker,tag=ec.forage_new,limit=1,distance=..1] data.areamult set value 150
execute if predicate evercraft:biome/is_dripstone_caves run data modify entity @e[type=marker,tag=ec.forage_new,limit=1,distance=..1] data.reqlv set value 20
execute if predicate evercraft:biome/is_dripstone_caves run data modify entity @e[type=marker,tag=ec.forage_new,limit=1,distance=..1] data.areamult set value 150

# --- Tier: Generic deepslate band (Y -64..0, NOT deep_dark) 30 / 150. ---
# Gated `unless is_deep_dark`; placed BEFORE River so a Y<0 river bed wins the higher 175 mult.
execute if predicate evercraft:position/deepslate_band unless predicate evercraft:biome/is_deep_dark run data modify entity @e[type=marker,tag=ec.forage_new,limit=1,distance=..1] data.reqlv set value 30
execute if predicate evercraft:position/deepslate_band unless predicate evercraft:biome/is_deep_dark run data modify entity @e[type=marker,tag=ec.forage_new,limit=1,distance=..1] data.areamult set value 150

# --- Tier: River 30 / 175 (writes after deepslate so a Y<0 river bed wins the 175 mult). ---
execute if predicate evercraft:biome/is_river run data modify entity @e[type=marker,tag=ec.forage_new,limit=1,distance=..1] data.reqlv set value 30
execute if predicate evercraft:biome/is_river run data modify entity @e[type=marker,tag=ec.forage_new,limit=1,distance=..1] data.areamult set value 175

# --- Tier: Ocean 40 / 200. ---
execute if predicate evercraft:biome/is_ocean run data modify entity @e[type=marker,tag=ec.forage_new,limit=1,distance=..1] data.reqlv set value 40
execute if predicate evercraft:biome/is_ocean run data modify entity @e[type=marker,tag=ec.forage_new,limit=1,distance=..1] data.areamult set value 200

# --- Tier: Sky (Y >= 128) 40 / 200. ---
execute if predicate evercraft:position/sky_128 run data modify entity @e[type=marker,tag=ec.forage_new,limit=1,distance=..1] data.reqlv set value 40
execute if predicate evercraft:position/sky_128 run data modify entity @e[type=marker,tag=ec.forage_new,limit=1,distance=..1] data.areamult set value 200

# --- Tier: The End 50 / 350. ---
execute if predicate evercraft:in_end run data modify entity @e[type=marker,tag=ec.forage_new,limit=1,distance=..1] data.reqlv set value 50
execute if predicate evercraft:in_end run data modify entity @e[type=marker,tag=ec.forage_new,limit=1,distance=..1] data.areamult set value 350

# --- Tier: Nether 60 / 250. ---
execute if predicate evercraft:in_nether run data modify entity @e[type=marker,tag=ec.forage_new,limit=1,distance=..1] data.reqlv set value 60
execute if predicate evercraft:in_nether run data modify entity @e[type=marker,tag=ec.forage_new,limit=1,distance=..1] data.areamult set value 250

# --- Tier: Deep Dark 70 / 300 (highest). ---
execute if predicate evercraft:biome/is_deep_dark run data modify entity @e[type=marker,tag=ec.forage_new,limit=1,distance=..1] data.reqlv set value 70
execute if predicate evercraft:biome/is_deep_dark run data modify entity @e[type=marker,tag=ec.forage_new,limit=1,distance=..1] data.areamult set value 300
