# === GATHER — HOME TURF S1: SCOPED reqLv SHAVE (Wave C2) ==============================
# Run as @s, AFTER gather/read_reqlv has seeded @s ec.gth_reqlv from the node marker and
# BEFORE compute_success does the (level - effReqLv) math. Eases the SUCCESS ROLL on the
# player's "home turf": a Biome-Master shaves the node's reqLv — but ONLY for the biome
# they actually mastered, because we read ec.bm_level (Biome Mastery's CURRENT-biome level,
# 0-5, maintained every 5s by biome_mastery/player_tick). Standing in the Deep Dark,
# ec.bm_level == your Deep-Dark mastery, so Master-of-Deep-Dark eases Deep-Dark nodes only;
# a Master-of-Plains gets nothing here. That inherent scoping is the whole point (crossplay
# S1 / EPIC D1): generic biome-time can never trivialise an unrelated zone's EQ2 gate.
#
#   shave   = ec.bm_level * 4     (L0 -> 0 ... L5 -> 20)
#   effReqLv = max(0, ec.gth_reqlv - shave)
#
# Sanity: Master-of-Deep-Dark (bm_level 5) at a Deep-Dark node (reqLv 70) -> shave 20 ->
#   effReqLv 50. An L100 Stone Strike there: compute_success gives 32 + (100-50)*66/100 = 65%
#   (vs 56% un-shaved). A non-master (bm_level 0) -> shave 0 -> reqLv stays 70, EQ2 gate bites.
#
# RACE B3: @s-scoped scratch only (ec.gth_shave). ec.gth_reqlv is already @s-scoped; this
# helper makes NO function call, so nothing is parked in the churned #...ec.temp namespace.

# shave = bm_level * 4. (ec.bm_level defaults 0 for any player, so an un-mastered/unknown
# biome yields shave 0 = no easing — the gate is untouched.)
scoreboard players operation @s ec.gth_shave = @s ec.bm_level
scoreboard players operation @s ec.gth_shave *= #gth_shave_per ec.var

# effReqLv = reqLv - shave, clamped at >= 0 (never raise success above the in-tier baseline).
scoreboard players operation @s ec.gth_reqlv -= @s ec.gth_shave
execute if score @s ec.gth_reqlv matches ..-1 run scoreboard players set @s ec.gth_reqlv 0
