# === GATHER — RESOLVE: WIN ===
# Run as @s from gather/resolve when the roll won. @s ec.gth_base already holds baseXP;
# the coord-pin + dtag are in evercraft:gth_temp. We are the claim winner this tick, so the
# charge read-subtract-write is single-writer-safe.

# Full XP (win). grant_xp reads ec.gth_win (=1) + ec.gth_src.
function evercraft:gather/grant_xp

# Outcome = WIN; a success resets THIS player's consecutive-fail count.
scoreboard players set @s ec.gth_outcome 1
scoreboard players set @s ec.gth_fails 0

# PER-PLAYER charge decrement (2026-06-22 per-player retrofit): instead of a SHARED node
# charge, spend ONE of THIS player's own charges on this node. The node stays fully live for
# everyone else; it despawns ONLY on its time-despawn (no ec.gth_despawn from charge-exhaust).
# pp/dec reads @s's entry, subtracts 1, writes it back, and republishes #gth_pp_left = the
# post-decrement remaining (under the claim, so single-writer-safe). pp/prep builds the payload
# from gth_temp (coords + dtag); the harvester's UUID keys their entry.
function evercraft:gather/pp/prep
function evercraft:gather/pp/dec

# Success line (lore L5).
function evercraft:gather/lines/success

# Outcome FX — source-flavoured win burst, channel-gated (Off/Reduced/Full/Cracked).
# Positioned at the node, run as the player. One-shot; honours the codex Settings off-switch.
function evercraft:fx/gather/win

# Accessory harvest bonus (D-FORTUNE-REWRITE, m2): a won prospect/forage/gather node rolls the
# rewritten harvest accessory's EXTRA-CRATE odds (the gather-node crate half — C4 Forester's
# Tally + C43 Resonant Geode Heart route to Family K Prospector). Crate-only: the node loot is a
# varied loot table, so a single-item double-harvest doesn't apply. Early-exits for non-holders.
function evercraft:artifacts/accessories/harvest_bonus_crate

# U20 Prospector's Dice (D-RENAME from "Divining-Glass"; Family K Prospector — art-K): an EXTRA
# independent node-crate roll on a won node, ADDITIVE on the harvest_bonus_crate above (a SECOND
# dreamy draw, mirroring the lapis-trim / Charm-2x extra-roll precedent). 2% (1..100 -> 1..2) item-
# gated give_crafting_crate — the same generic Crafting Crate the gather-node crate path gives — so
# the Dice's "extra parallel node crate roll" stacks on the base. id-presence -> two copies fire one
# roll (m4 multi-copy-safe). NOT raw DR (per EXPANSION-IDEAS U20). Non-holders pay one comparison.
execute if items entity @s container.* *[custom_data~{artifact:"prospectors_dice"}] store result score #pdice_roll ec.temp run random value 1..100
execute unless items entity @s container.* *[custom_data~{artifact:"prospectors_dice"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"prospectors_dice"}] if entity @s[tag=ec.sat_prospectors_dice] store result score #pdice_roll ec.temp run random value 1..100
execute unless items entity @s container.* *[custom_data~{artifact:"prospectors_dice"}] if items entity @s weapon.offhand *[custom_data~{artifact:"prospectors_dice"}] store result score #pdice_roll ec.temp run random value 1..100
execute if items entity @s container.* *[custom_data~{artifact:"prospectors_dice"}] if score #pdice_roll ec.temp matches 1..2 at @s run function evercraft:craft_affinity/give_crafting_crate
execute unless items entity @s container.* *[custom_data~{artifact:"prospectors_dice"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"prospectors_dice"}] if entity @s[tag=ec.sat_prospectors_dice] if score #pdice_roll ec.temp matches 1..2 at @s run function evercraft:craft_affinity/give_crafting_crate
execute unless items entity @s container.* *[custom_data~{artifact:"prospectors_dice"}] if items entity @s weapon.offhand *[custom_data~{artifact:"prospectors_dice"}] if score #pdice_roll ec.temp matches 1..2 at @s run function evercraft:craft_affinity/give_crafting_crate

# cap-K (m4): the Surveyor Line sub-cap + the Demiurge's Spirit Artifact consolidate the Prospector's Dice
# extra node-crate roll — re-roll it gated on either held flag, but ONLY when the loose Dice is NOT held
# (so a re-acquired loose Dice never double-rolls; exactly one path runs). Same independent 2% (1..100 ->
# 1..2) give_crafting_crate, ADDITIVE on the base harvest_bonus_crate above. #pdice_cap is a distinct fake
# so it never clobbers the loose Dice's #pdice_roll in the same win. (The loose Dice always rolls when held
# — a Newcomer who re-holds the loose charm keeps it; the node only ADDS when the loose is absent.)
execute unless items entity @s container.* *[custom_data~{artifact:"prospectors_dice"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"prospectors_dice"}] unless entity @s[tag=ec.sat_prospectors_dice] if items entity @s container.* *[custom_data~{demiurges_capstone:true}] store result score #pdice_cap ec.temp run random value 1..100
execute unless items entity @s container.* *[custom_data~{artifact:"prospectors_dice"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"prospectors_dice"}] unless entity @s[tag=ec.sat_prospectors_dice] unless items entity @s container.* *[custom_data~{demiurges_capstone:true}] unless items entity @s weapon.offhand *[custom_data~{demiurges_capstone:true}] if entity @s[tag=ec.sat_demiurges_capstone] store result score #pdice_cap ec.temp run random value 1..100
execute unless items entity @s container.* *[custom_data~{artifact:"prospectors_dice"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"prospectors_dice"}] unless entity @s[tag=ec.sat_prospectors_dice] unless items entity @s container.* *[custom_data~{demiurges_capstone:true}] if items entity @s weapon.offhand *[custom_data~{demiurges_capstone:true}] store result score #pdice_cap ec.temp run random value 1..100
execute unless items entity @s container.* *[custom_data~{artifact:"prospectors_dice"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"prospectors_dice"}] unless entity @s[tag=ec.sat_prospectors_dice] unless items entity @s container.* *[custom_data~{demiurges_capstone:true}] unless items entity @s weapon.offhand *[custom_data~{demiurges_capstone:true}] if items entity @s container.* *[custom_data~{surveyor_line:true}] store result score #pdice_cap ec.temp run random value 1..100
execute unless items entity @s container.* *[custom_data~{artifact:"prospectors_dice"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"prospectors_dice"}] unless entity @s[tag=ec.sat_prospectors_dice] unless items entity @s container.* *[custom_data~{demiurges_capstone:true}] unless items entity @s weapon.offhand *[custom_data~{demiurges_capstone:true}] unless items entity @s container.* *[custom_data~{surveyor_line:true}] unless items entity @s weapon.offhand *[custom_data~{surveyor_line:true}] if entity @s[tag=ec.sat_surveyor_line] store result score #pdice_cap ec.temp run random value 1..100
execute unless items entity @s container.* *[custom_data~{artifact:"prospectors_dice"}] unless items entity @s weapon.offhand *[custom_data~{artifact:"prospectors_dice"}] unless entity @s[tag=ec.sat_prospectors_dice] unless items entity @s container.* *[custom_data~{demiurges_capstone:true}] unless items entity @s weapon.offhand *[custom_data~{demiurges_capstone:true}] unless items entity @s container.* *[custom_data~{surveyor_line:true}] if items entity @s weapon.offhand *[custom_data~{surveyor_line:true}] store result score #pdice_cap ec.temp run random value 1..100
execute if score #pdice_cap ec.temp matches 1..2 at @s run function evercraft:craft_affinity/give_crafting_crate

# PER-PLAYER exhaust (2026-06-22): when THIS player's charges hit 0, the node is spent FOR
# THEM — but it is NOT despawned globally (others keep their own charges). pp/dec already wrote
# left=0 onto their entry, so the NEXT click's exhausted_check blocks them with the spent line.
# ec.gth_despawn is left at 0 here — the node despawns only on its time-despawn (no charge-exhaust
# despawn anymore). Loot is success-only (crossplay C1), gated on outcome 1 by the caller.

# === Biome Crates — shared node-win hook (harvest affinity gain + affinity-boosted local crate drop) ===
# Win-only, cold (no tick / no @a scan). Extracted to biome_crates/on_node_win so the timberfall (lumber)
# win paths — which bypass resolve_win by calling gather/compute_success directly — call the SAME logic.
# This is the canonical "any node in this biome" hook for the 6 resolve-routed nodes. See that file's header.
function evercraft:biome_crates/on_node_win
