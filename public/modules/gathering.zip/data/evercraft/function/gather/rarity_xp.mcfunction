# === GATHER — RARITY BAND -> baseXP (D3 ÷5, 6 bands) ===
# Run as @s AFTER read_rarity has set @s ec.gth_base to a rarity BAND (1-6, default 1).
# Maps the band to its baseXP and writes it back into @s ec.gth_base:
#   band 1 -> 4   band 2 -> 8   band 3 -> 12   band 4 -> 16   band 5 -> 20   band 6 -> 25
# (common / uncommon / rare / ornate / exquisite / mythical, baseXP ÷5 per council D3.)
# A typical band-1 node ~= today's 10-15 XP after area/Dreamy mults layer on in Waves C/D.

# Clamp the band into [1,6] so a missing/garbage data.rarity never reads off-table.
execute if score @s ec.gth_base matches ..0 run scoreboard players set @s ec.gth_base 1
execute if score @s ec.gth_base matches 7.. run scoreboard players set @s ec.gth_base 6

# Snapshot the band, then resolve baseXP from it (highest-only match -> set, so order is safe).
scoreboard players operation #gth_band ec.temp = @s ec.gth_base
execute if score #gth_band ec.temp matches 1 run scoreboard players set @s ec.gth_base 4
execute if score #gth_band ec.temp matches 2 run scoreboard players set @s ec.gth_base 8
execute if score #gth_band ec.temp matches 3 run scoreboard players set @s ec.gth_base 12
execute if score #gth_band ec.temp matches 4 run scoreboard players set @s ec.gth_base 16
execute if score #gth_band ec.temp matches 5 run scoreboard players set @s ec.gth_base 20
execute if score #gth_band ec.temp matches 6 run scoreboard players set @s ec.gth_base 25
