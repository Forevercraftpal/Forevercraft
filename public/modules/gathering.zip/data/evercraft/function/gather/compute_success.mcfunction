# === GATHER — COMPUTE SUCCESS% (Wave C1: reqLv-gated soft penalty) ===
# Run as @s, given ec.gth_src (1=prospect 2=forage 3=splash) + the coord-pin in
# evercraft:gth_temp (caller-set). Reads the driving Crafting-Class level (Wave A's
# ec.caffl_*) by source AND the node's AREA reqLv (Wave C1's data.reqlv), then computes:
#   success% = clamp(32 + (level - reqLv)*66/100, floor, 95)
# where floor defaults to 5 (ec.gth_floor). Integer math, all in @s-scoped scratch (race
# B3) — compute_success runs inside resolve which DOES call grant (churns ec.temp), so we
# never park the result in #...ec.temp.
#
# Sanity (in-tier, reqLv 0): L0 -> 32 ; L50 -> 32+33=65 ; L100 -> 32+66=98 -> clamp 95.
# Sanity (tiered): L50 in a reqLv-40 zone -> 32+(10*66/100)=38 ; L100 End (reqLv 50) ->
#   32+(50*66/100)=65 (D2's "masterable End ≈ 65%" lands exactly).
# SOFT PENALTY (under-levelled, level < reqLv): the (level-reqLv) intermediate goes NEGATIVE.
#   Trace L0 End (reqLv 50): (0-50)*66 = -3300 ; /100 = -33 (no remainder, floor==trunc) ;
#   +32 = -1 ; clamp < floor(5) -> 5. That 5% IS the locked soft penalty ("you may still
#   attempt"). NOTE: scoreboard `/=` is FLOORED division (toward -inf), not truncated; for a
#   negative intermediate with a remainder (e.g. L0 ocean reqLv40: -2640/100 floors to -27,
#   +32 = 5) the floor only pushes the result LOWER, which the clamp catches at 5 anyway — so
#   floored division is safe here and never inflates the penalty.
#
# Wave E (S3): a spirit/Awakened tool raises ec.gth_floor BEFORE this runs — the caller
# (gather/resolve) seeds the default floor (5) into ec.gth_floor, then S3 may raise it,
# THEN compute_success reads it. So this file does NOT touch ec.gth_floor — it only
# CONSUMES it in the clamp below. Keeps the S3 lever a one-line insertion in resolve; do
# NOT implement S3 now.

# Read the node's AREA reqLv off the marker (default 0 = Normal, no penalty). Coord-pin is
# already in gth_temp (resolve set it before calling compute_success), so this is a clean read.
# Wave C2 (Home-Turf S1): a Biome-Master-of-this-biome shaves ec.gth_reqlv for THIS biome only
# (gather/compute_reqlv reads ec.bm_level + ec.biome_id) — insert that shave AFTER this read.
function evercraft:gather/read_reqlv
# Home Turf (S1): shave the node's reqLv by ec.bm_level*4 (max -20 at L5), clamped >=0. Scoped
# to the CURRENT biome via ec.bm_level, so it eases ONLY a hard zone the player actually
# mastered — a non-master gets no shave and the EQ2 gate below still bites.
function evercraft:gather/compute_reqlv

# Pull the driving level for this source into ec.gth_succ.
scoreboard players set @s ec.gth_succ 0
execute if score @s ec.gth_src matches 1 run scoreboard players operation @s ec.gth_succ = @s ec.caffl_ss
execute if score @s ec.gth_src matches 2 run scoreboard players operation @s ec.gth_succ = @s ec.caffl_gs
execute if score @s ec.gth_src matches 3 run scoreboard players operation @s ec.gth_succ = @s ec.caffl_sc
# Nest family (PLAN-nest-family §2, ADDITIVE — R3): gth_src=4 -> Lamentor (caffl_lm) drives success%.
execute if score @s ec.gth_src matches 4 run scoreboard players operation @s ec.gth_succ = @s ec.caffl_lm
# Chest-Node family (PLAN-chest-nodes §1/§14.1, ADDITIVE): gth_src=5 -> Gearwright (caffl_gw) drives the
# success-curve read. HARMLESS even though the chest engine (P2) bypasses this with a flat 50/50 + a
# gth_src==5 skip of the level-curve — the read just stages the level here; the engine overwrites it.
execute if score @s ec.gth_src matches 5 run scoreboard players operation @s ec.gth_succ = @s ec.caffl_gw
# Timberfall family (Lumberfell channeled chop, ADDITIVE — never touch src 1-5): gth_src=6 ->
# Lumberfell (caffl_lf) drives the per-block win%. The caller pins gth_temp to a no-node dtag so
# read_reqlv keeps its 0 default (a tree has no placed node reqLv) -> success = clamp(32 +
# level*66/100, floor..95), the pure level-based base. No tool-material bonus (src != 1-5).
execute if score @s ec.gth_src matches 6 run scoreboard players operation @s ec.gth_succ = @s ec.caffl_lf
# Buried Cache family (Terrawarp dig node, ADDITIVE — never touch src 1-6): gth_src=7 -> Terrawarp
# (caffl_tw, craft class 4) drives the per-dig win%. The caller pins gth_temp to the node's real
# coords + dtag "ec.cache_data", so read_reqlv reads the node's data.reqlv like prospect (a placed
# node, area-difficulty scaled). success = clamp(32 + (level - reqLv)*66/100, floor..95). The
# TOOL-MATERIAL bonus block below is keyed to src 1/2/4 only, so src 7 lands +0 there (a shovel has
# no dedicated tool-class slot in that block — its level curve IS the harvest odds, like src 6).
execute if score @s ec.gth_src matches 7 run scoreboard players operation @s ec.gth_succ = @s ec.caffl_tw

# success = (level - reqLv)*66/100 + 32. The reqLv subtraction is the EQ2 difficulty gate:
# under-levelled (level < reqLv) drives the intermediate negative -> craters to the floor.
scoreboard players operation @s ec.gth_succ -= @s ec.gth_reqlv
# Wave D1: snapshot (level - effReqLv) BEFORE the *66 scaling destroys it — drives the
# over-level trigger flag below (set after the success clamp).
scoreboard players operation @s ec.gth_overscratch = @s ec.gth_succ
scoreboard players operation @s ec.gth_succ *= #gth_c66 ec.var
scoreboard players operation @s ec.gth_succ /= #gth_c100 ec.var
scoreboard players operation @s ec.gth_succ += #gth_base32 ec.var

# clamp to [floor, 95]
execute if score @s ec.gth_succ < @s ec.gth_floor run scoreboard players operation @s ec.gth_succ = @s ec.gth_floor
execute if score @s ec.gth_succ > #gth_cap95 ec.var run scoreboard players operation @s ec.gth_succ = #gth_cap95 ec.var

# === Chest-Node family (PLAN-chest-nodes §2/§14.1): gth_src=5 SKIPS the level-curve above. =====
# A chest is a flat 50/50 HARVEST (Joseph), NOT a level-scaled gather. The level read above (caffl_gw)
# + the reqLv curve are harmless (they just staged a value), but the canonical harvest odds for a chest
# are a flat 50 — overwrite ec.gth_succ here AFTER the normal clamp so src 1-4 are untouched. The
# OPEN gate (key/keyless + the ≤95 open clamp) is separate and lives in chest_nodes/do_open (§14.9);
# this 50 is only the post-open harvest roll. 50 >= 32 so the Dreamy ladder below stays at full (100).
execute if score @s ec.gth_src matches 5 run scoreboard players set @s ec.gth_succ 50

# === Wave D1: Dreamy-retune feeds (computed AFTER the success clamp) ====================
# Both are HARVEST-scratch (@s, overwritten next harvest). maybe_trigger snapshots
# ec.gth_dppenalty into the Dreamy session (ec.dp_penalty) so a later harvest mid-minigame
# can't corrupt the odds resolve reads.
#
# 1) OVER-LEVEL flag: 1 when (level - effReqLv) >= 25 (zone is over-leveled for you ->
#    Dreamy triggers at 3% not 7%). overscratch was snapshotted above before the *66 scale.
scoreboard players set @s ec.gth_overlvl 0
execute if score @s ec.gth_overscratch >= #gth_overlvl_thresh ec.var run scoreboard players set @s ec.gth_overlvl 1
#
# 2) DREAMY ODDS PENALTY factor (0-100): min(100, gth_succ*100/32) — the clamped success vs
#    the in-tier 32% baseline. In-tier/over (succ>=32) -> 100 (no penalty, full 50/65/80/100
#    ladder); under-level craters it (succ 5 -> 15, so the ladder weakens proportionally).
#    Integer floor is fine here (it only ever lowers a too-hard zone's bonus odds). gth_succ is
#    already clamped >= floor(5) above, so this is always >= 1 (never a /0 in resolve).
scoreboard players operation @s ec.gth_dppenalty = @s ec.gth_succ
scoreboard players operation @s ec.gth_dppenalty *= #gth_c100 ec.var
scoreboard players operation @s ec.gth_dppenalty /= #gth_base32 ec.var
execute if score @s ec.gth_dppenalty matches 101.. run scoreboard players set @s ec.gth_dppenalty 100

# === TOOL-MATERIAL harvest bonus (Joseph 2026-06-04, live playtest) =====================
# Holding the APPROPRIATE tool class for THIS source, of a high-tier material, adds a flat
# % to the win odds: iron +1, gold +2, diamond +3, netherite +5 (wood/stone = +0). Computed
# LAST so it sweetens ONLY the actual win roll — the Dreamy feeds above (overlvl + dppenalty)
# read the un-bonused level-curve success on purpose (they gate on level-vs-reqLv, not gear).
# Appropriate tool class per source (mirrors the start-gate item checks in start_mine /
# start_gather + the splash on_click rod check):
#   src 1 prospect -> pickaxe       src 2 forage -> axe OR hoe
#   src 3 splash   -> fishing rod   src 4 nest (Lamentor, forage-spliced) -> axe OR hoe
# src 5 chest is a key-opened flat 50/50 (NOT a tool harvest) -> no bonus (gated out below).
# Vanilla fishing rods have only ONE material tier (no iron/gold/diamond/netherite rod
# exists), so src 3 structurally always lands +0 — the block is kept symmetric/cheap, not
# wired for rods. Mainhand-only: the harvesting tool IS the mainhand (resolve header §55).
scoreboard players set @s ec.gth_toolmat 0
# src 1 (prospect / pickaxe).
execute if score @s ec.gth_src matches 1 if items entity @s weapon.mainhand minecraft:iron_pickaxe run scoreboard players operation @s ec.gth_toolmat = #gth_tm_iron ec.var
execute if score @s ec.gth_src matches 1 if items entity @s weapon.mainhand minecraft:golden_pickaxe run scoreboard players operation @s ec.gth_toolmat = #gth_tm_gold ec.var
execute if score @s ec.gth_src matches 1 if items entity @s weapon.mainhand minecraft:diamond_pickaxe run scoreboard players operation @s ec.gth_toolmat = #gth_tm_diamond ec.var
execute if score @s ec.gth_src matches 1 if items entity @s weapon.mainhand minecraft:netherite_pickaxe run scoreboard players operation @s ec.gth_toolmat = #gth_tm_neth ec.var
# src 2 forage + src 4 nest (Lamentor) — both accept axe OR hoe (matches start_gather's gate).
execute if score @s ec.gth_src matches 2 if items entity @s weapon.mainhand #evercraft:gather_forage_iron run scoreboard players operation @s ec.gth_toolmat = #gth_tm_iron ec.var
execute if score @s ec.gth_src matches 2 if items entity @s weapon.mainhand #evercraft:gather_forage_gold run scoreboard players operation @s ec.gth_toolmat = #gth_tm_gold ec.var
execute if score @s ec.gth_src matches 2 if items entity @s weapon.mainhand #evercraft:gather_forage_diamond run scoreboard players operation @s ec.gth_toolmat = #gth_tm_diamond ec.var
execute if score @s ec.gth_src matches 2 if items entity @s weapon.mainhand #evercraft:gather_forage_neth run scoreboard players operation @s ec.gth_toolmat = #gth_tm_neth ec.var
execute if score @s ec.gth_src matches 4 if items entity @s weapon.mainhand #evercraft:gather_forage_iron run scoreboard players operation @s ec.gth_toolmat = #gth_tm_iron ec.var
execute if score @s ec.gth_src matches 4 if items entity @s weapon.mainhand #evercraft:gather_forage_gold run scoreboard players operation @s ec.gth_toolmat = #gth_tm_gold ec.var
execute if score @s ec.gth_src matches 4 if items entity @s weapon.mainhand #evercraft:gather_forage_diamond run scoreboard players operation @s ec.gth_toolmat = #gth_tm_diamond ec.var
execute if score @s ec.gth_src matches 4 if items entity @s weapon.mainhand #evercraft:gather_forage_neth run scoreboard players operation @s ec.gth_toolmat = #gth_tm_neth ec.var
# src 7 (buried cache / shovel) — shovels HAVE material tiers (unlike rods), so the same iron/gold/
# diamond/netherite sweetener applies. The dig start-gate (buried_cache/start_dig) requires an
# iron+ shovel; wood/stone shovels never reach here, so only the high tiers ever match. Mirrors the
# src-1 pickaxe block.
execute if score @s ec.gth_src matches 7 if items entity @s weapon.mainhand minecraft:iron_shovel run scoreboard players operation @s ec.gth_toolmat = #gth_tm_iron ec.var
execute if score @s ec.gth_src matches 7 if items entity @s weapon.mainhand minecraft:golden_shovel run scoreboard players operation @s ec.gth_toolmat = #gth_tm_gold ec.var
execute if score @s ec.gth_src matches 7 if items entity @s weapon.mainhand minecraft:diamond_shovel run scoreboard players operation @s ec.gth_toolmat = #gth_tm_diamond ec.var
execute if score @s ec.gth_src matches 7 if items entity @s weapon.mainhand minecraft:netherite_shovel run scoreboard players operation @s ec.gth_toolmat = #gth_tm_neth ec.var
# Fold the bonus in (src 5 chest excluded — its flat 50 set above is the canonical chest harvest
# odds), then re-clamp to <=100. The tool bonus is the only path past the base 95 curve cap.
execute unless score @s ec.gth_src matches 5 run scoreboard players operation @s ec.gth_succ += @s ec.gth_toolmat
execute if score @s ec.gth_succ > #gth_cap100 ec.var run scoreboard players operation @s ec.gth_succ = #gth_cap100 ec.var
