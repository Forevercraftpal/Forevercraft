# === GATHER — RESOLVE (the 4-way decision core — the heart) ===========================
# Run as @s (the clicking player), positioned at the node click. The CALLER (B-wire, from
# complete_mine / complete_gather / do_catch) must set BEFORE calling:
#   - ec.gth_src           : 1=prospect, 2=forage, 3=splash (drives level + class + crumble line)
#   - storage evercraft:gth_temp {x:X, y:Y, z:Z, dtag:"ec.<type>_data"}  (the coord-pin +
#       marker tag; coords come from the per-skill start-pin: ec.pr_sx/sy/sz / ec.fg_sx/sy/sz
#       / a splash coord-pin B-wire adds. dtag is "ec.prospect_data" / "ec.forage_data" /
#       "ec.splash_data".)
#
# AFTER calling, the caller reads:
#   - ec.gth_outcome : 1=WIN, 2=FAIL (node survives), 3=CRUMBLE (3rd fail, node spent)
#   - ec.gth_despawn : 1 when the node should be despawned (WIN that hit 0 charges, OR
#                      CRUMBLE). The caller runs its own node-specific despawn (despawn_node
#                      / despawn_bush / splash despawn_node) + gives loot ONLY on outcome 1.
#   - ec.gth_win     : 1 on a won roll, 0 otherwise (also reflected in outcome).
# On a dropped click (lost the same-tick claim) resolve sets outcome 0 + despawn 0 and
# returns 0 — the caller awards NOTHING and the player re-clicks next tick.
#
# RACE: claim-then-act (claim_node), coord-pinned everything, all cross-call state @s-scoped,
# fails per-(player, CURRENT node) — ec.gth_fails resets on win, on crumble, AND on node-change
# (this fn compares the click's pinned coords against ec.gth_fn{x,y,z}). Charges node-side under
# the claim. See gather/load header.

# Reset this resolution's outputs.
scoreboard players set @s ec.gth_outcome 0
scoreboard players set @s ec.gth_despawn 0
scoreboard players set @s ec.gth_win 0

# 1) CLAIM the node for this tick. If we lost the claim, drop the click (return 0).
function evercraft:gather/claim_node
execute if score @s ec.gth_claimed matches 0 run return 0

# Per-(player,node) fail streak (race Shape β): reset if this node differs from the
# node the current streak belongs to. Pinned coords are in gth_temp (caller-set), so a
# player who fails on node A then walks to node B starts B's streak fresh — without this
# the carried-over count could crumble B on the first attempt. (A new node spawning at the
# exact despawned coords is negligible — spawns are randomized.)
execute store result score @s ec.gth_nx run data get storage evercraft:gth_temp x
execute store result score @s ec.gth_ny run data get storage evercraft:gth_temp y
execute store result score @s ec.gth_nz run data get storage evercraft:gth_temp z
execute unless score @s ec.gth_nx = @s ec.gth_fnx run scoreboard players set @s ec.gth_fails 0
execute unless score @s ec.gth_ny = @s ec.gth_fny run scoreboard players set @s ec.gth_fails 0
execute unless score @s ec.gth_nz = @s ec.gth_fnz run scoreboard players set @s ec.gth_fails 0
scoreboard players operation @s ec.gth_fnx = @s ec.gth_nx
scoreboard players operation @s ec.gth_fny = @s ec.gth_ny
scoreboard players operation @s ec.gth_fnz = @s ec.gth_nz

# 2) COMPUTE success% and ROLL 1..100. roll <= success => win.
# Seed the success floor (default 5) for this resolution. compute_success consumes it.
scoreboard players operation @s ec.gth_floor = #gth_floor_default ec.var
# Wave E2 S3 (crossplay C3 S3): a spirit/Awakened APEX tool raises the success floor so an
# under-levelled player wielding it in a hard zone (§3) doesn't crater to 5% — the tool feels
# like mastery exactly where the gates bite. read_sig_tier refreshes ec.caff_sigtier from the
# CURRENT mainhand (the harvesting tool — you can't mine/forage with a rod, so the mainhand IS
# the right tool for the source). Cheap pure reader, safe per-harvest. Tiers 4/5/6 (awakened
# NORMAL tools) get NO raise — the floor is reserved for spirit (7) / Awakened-Spirit (8) only.
function evercraft:craft_affinity/abilities/read_sig_tier
execute if score @s ec.caff_sigtier matches 7 run scoreboard players set @s ec.gth_floor 40
execute if score @s ec.caff_sigtier matches 8 run scoreboard players set @s ec.gth_floor 55
function evercraft:gather/compute_success

# Pity bonus (Joseph 2026-06-12): non-Pioneer modes get +25 success per
# consecutive fail already on THIS node, so a fail streak that would otherwise
# crumble the node almost always wins on the 3rd attempt. ec.gth_fails is the
# pre-attempt count (0 on the first try, 2 going into the would-be-crumble try
# — see lines below). Pioneer mode (ec.difficulty=3) stays strict — the wall is
# the wall, that's the Pioneer covenant. Capped at 100 below.
execute unless score @s ec.difficulty matches 3 if score @s ec.gth_fails matches 1.. store result score #gth_pity ec.temp run scoreboard players get @s ec.gth_fails
execute unless score @s ec.difficulty matches 3 if score @s ec.gth_fails matches 1.. run scoreboard players operation #gth_pity ec.temp *= #25 ec.const
execute unless score @s ec.difficulty matches 3 if score @s ec.gth_fails matches 1.. run scoreboard players operation @s ec.gth_succ += #gth_pity ec.temp
execute if score @s ec.gth_succ matches 101.. run scoreboard players set @s ec.gth_succ 100

execute store result score @s ec.gth_roll run random value 1..100
execute if score @s ec.gth_roll <= @s ec.gth_succ run scoreboard players set @s ec.gth_win 1

# --- Resolve the rarity/baseXP up front (used by both win + fail grants). ---
function evercraft:gather/read_rarity
function evercraft:gather/rarity_xp

# =========================== 3) WIN ===========================
execute if score @s ec.gth_win matches 1 run function evercraft:gather/resolve_win

# =========================== 4/5) FAIL / CRUMBLE ===========================
# On a loss, increment THIS player's fail count, then branch on whether it hit the ceiling.
execute if score @s ec.gth_win matches 0 run scoreboard players add @s ec.gth_fails 1
# 5) 3rd consecutive fail -> CRUMBLE. 4) fails 1 or 2 -> plain FAIL (node survives).
execute if score @s ec.gth_win matches 0 if score @s ec.gth_fails >= #gth_fail_max ec.var run function evercraft:gather/resolve_crumble
execute if score @s ec.gth_win matches 0 if score @s ec.gth_fails < #gth_fail_max ec.var run function evercraft:gather/resolve_fail

# Bonus-round chance (Joseph 2026-06-12): 5% base + 0.02% per class level
# adds +1 charge to the node ("extra round"). Win always rolls; fail only rolls
# at class level >= 25; crumble skipped (gth_outcome 3, node already despawned).
execute if score @s ec.gth_outcome matches 1..2 run function evercraft:gather/bonus_round_check
