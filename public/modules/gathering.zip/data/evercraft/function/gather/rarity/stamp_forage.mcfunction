# === GATHER · B-RARITY — STAMP FORAGE BUSH RARITY BAND (single source of truth) ===
# Called from evercraft:forage/place_bush, right after apply_variant stamps data.biome,
# while the just-spawned marker still carries the ec.forage_new tag. Stamps data.rarity
# (1-6) on the SAME ec.forage_data marker that gather/read_rarity reads at harvest.
# Band = the representative ITEM rarity of the bush's drop POOL (rarity-canon 1=common..6),
# NOT the biome/area tier (area is the separate Wave-C areaMult).
#
# ---------------------------------------------------------------------------------------
# BAND TABLE — grounded in data/evercraft/loot_table/forage/drops/*.json (2026-05-31).
#   All 14 forage biomes (plains desert badlands ice swamp forest flower_forest dark_forest
#   jungle taiga mountain ocean mushroom savanna) share ONE pool shape:
#     ~95% band-1 by weight — common herbs/flowers/saplings/seeds/crops (wheat_seeds, poppy,
#       oak_sapling, cocoa_beans, kelp, brown_mushroom, …) + ONE biome-flavored cooking
#       INGREDIENT reagent (meadow_thyme, woodland_truffle, frostmint, …) which carries NO
#       minecraft:rarity component = common-tier.
#     ~5% band-3 splash — golden_root + starbloom_petal (cooking/rare), weights 3 & 2 out of
#       ~80-100. A rare splash, not the characteristic drop.
#   => Median band = 1 for EVERY forage biome. Characteristic forage drop is a common plant.
#   No forage pool is characteristically uncommon/rare, so none reaches band 2+. The band is
#   uniform, so this is an unconditional stamp (no biome chain needed) — but it is documented
#   here as the forage source-of-truth so future per-biome tuning is a one-file edit.
# ---------------------------------------------------------------------------------------

# Band 1 — all forage biomes (common plant matter). Uniform, so stamped unconditionally.
data modify entity @e[type=marker,tag=ec.forage_new,limit=1,distance=..1] data.rarity set value 1
