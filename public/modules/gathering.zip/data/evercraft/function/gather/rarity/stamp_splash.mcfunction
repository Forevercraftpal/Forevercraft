# === GATHER · B-RARITY — STAMP SPLASH NODE RARITY BAND (single source of truth) ===
# Called from evercraft:fishing/splash_nodes/place_node, right after apply_data stamps
# data.biome + data.dim, while the just-spawned marker still carries the ec.splash_new tag.
# Stamps data.rarity (1-6) on the SAME ec.splash_data marker that gather/read_rarity reads
# at harvest. Band keyed on the DIM (1=overworld water, 2=nether lava) because the dim routes
# to two genuinely different CATCH POOLS — the band reflects the POOL CONTENTS' rarity, not
# the dimension as an area multiplier (a water vs lava node difference here IS a different
# loot table, not the same pool in a richer area).
#
# ---------------------------------------------------------------------------------------
# BAND TABLE — grounded in fishing/splash_nodes/catch_overworld.json + catch_nether.json
#   (2026-05-31). These are tiered ALCHEMY-REAGENT fish (Aquatic Reagent T1-T6), NOT vanilla
#   cod/salmon — so they skew well above ordinary food fish. (Per-item minecraft:rarity below
#   uses the vanilla 4-step scale; mapped onto the pack 6-tier canon: epic≈ornate-tier.)
#
#   dim 1 — catch_overworld -> band 2 (uncommon). Weighted catch mix: 15% common, 35%
#       uncommon, 35% rare, 16% epic (Silverscale Minnow … Emberfin Snapper). Mass is
#       centered on uncommon/rare reagents; weighted median lands at rare but the
#       CHARACTERISTIC catch is uncommon-to-rare -> band 2 (honest median, not the max).
#   dim 2 — catch_nether -> band 3 (rare). Drops the two common minnows, adds blaze_rod /
#       magma_cream / glowstone nether mats, and skews the fish to rare/epic: 9% uncommon,
#       39% rare, 23% epic = ~62% rare-or-better by weight. A clear notch above the water
#       pool; characteristic nether catch IS rare -> band 3.
#   Neither catch pool is apex/mythical (T7 spirit fish are excluded per the table comment),
#   so neither reaches band 4-6.
# ---------------------------------------------------------------------------------------

# Band 3 — nether lava node (rare/epic-skewed reagent fish + nether mats).
execute if data storage evercraft:spl_temp {node_dim:2} run data modify entity @e[type=marker,tag=ec.splash_new,limit=1,distance=..1] data.rarity set value 3

# Band 2 — overworld water node (uncommon/rare aquatic reagent fish). Default for dim 1
# (and any non-2 dim), so an unexpected dim value never falls through to the engine's
# default band 1 — splash catches are never plain commons.
execute unless data storage evercraft:spl_temp {node_dim:2} run data modify entity @e[type=marker,tag=ec.splash_new,limit=1,distance=..1] data.rarity set value 2
