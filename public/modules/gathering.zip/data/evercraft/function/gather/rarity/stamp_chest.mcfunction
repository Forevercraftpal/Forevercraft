# === GATHER · B-RARITY — STAMP CHEST NODE RARITY BAND (single source of truth) ===
# Called from evercraft:chest_nodes/place_node, right after data.ctype is stamped, while the
# just-spawned marker still carries the ec.chest_new tag. Stamps data.rarity (1-6) on the SAME
# ec.chest_data marker that gather/read_rarity reads at open -> baseXP for the Gearwright XP grant.
# Band = the representative VALUE of the chest's loot channel (a keyed chest is richer), NOT an area
# multiplier. Read data.ctype off the marker (1=Crafting, 2=Adventurer, 3=plain).

# Default plain chest -> band 2 (a notch above common — chest nodes are a deliberate find, not ambient
# plant matter). Seeded first, then keyed chests bump to band 3 (Crafting/Adventurer = richer pools).
data modify entity @e[type=marker,tag=ec.chest_new,limit=1,distance=..1] data.rarity set value 2

# Keyed chests (Crafting / Adventurer) carry a richer pool -> band 3.
execute store result score #cn_band_ct ec.temp run data get entity @e[type=marker,tag=ec.chest_new,limit=1,distance=..1] data.ctype
execute if score #cn_band_ct ec.temp matches 1 run data modify entity @e[type=marker,tag=ec.chest_new,limit=1,distance=..1] data.rarity set value 3
execute if score #cn_band_ct ec.temp matches 2 run data modify entity @e[type=marker,tag=ec.chest_new,limit=1,distance=..1] data.rarity set value 3
