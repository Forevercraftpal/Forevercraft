# === GATHER · B-RARITY — STAMP PROSPECT NODE RARITY BAND (single source of truth) ===
# Called from evercraft:prospect/place_node, right after apply_variant stamps data.biome,
# while the just-spawned marker still carries the ec.prospect_new tag. Reads node_biome
# from evercraft:pr_temp and stamps data.rarity (1-6) on the SAME ec.prospect_data marker
# that gather/read_rarity later reads at harvest. Band = the representative ITEM rarity of
# the biome's drop POOL (rarity-canon 1=common..6=mythical), NOT the area/dimension tier
# (area is a separate Wave-C areaMult — banding by area would double-count it).
#
# NOT a macro: these are literal `if data storage {node_biome:"X"}` NBT matches, so this is
# a plain function (run with `function ... with storage evercraft:pr_temp` is unnecessary —
# place_node just calls it directly; pr_temp.node_biome is already set).
#
# Default band 1 is seeded by gather/read_rarity, so an unmapped biome silently reads as a
# common (baseXP 4). Every one of the 23 prospect biomes IS mapped below, so default-1 only
# ever fires for a genuinely common pool — never for a missing mapping.
#
# ---------------------------------------------------------------------------------------
# BAND TABLE — grounded in data/evercraft/loot_table/prospect/drops/*.json (2026-05-31).
#   Most biomes route to prospect/drops/overworld (iron/copper/coal/lapis/redstone bulk +
#   ~6% diamond/amethyst + 2 low-weight cooking/rare reagents) => characteristically COMMON.
#
#   band 1 (common — 21 biomes): plains desert badlands ice swamp forest flower_forest
#       dark_forest jungle taiga mountain ocean mushroom savanna  -> share the `overworld`
#       table (83% band-1 bulk ore). Plus the three lava/cave pools whose median drop is
#       still common bulk: dripstone_caves (88% band-1 copper/iron/coal/calcite), lush_caves
#       (76% band-1 moss/copper/glow_berries) and ALL FIVE nether biomes nether_wastes /
#       crimson_forest / warped_forest / soul_sand_valley / basalt_deltas (83-95% band-1:
#       quartz/gold_nugget/basalt/blackstone bulk; their reagents are common-tier cooking
#       ingredients; only a 5-8% cooking/rare splash). Nether = band 1 by CONTENT, not dim.
#   band 2 (uncommon — 1 biome): the_end  -> 76% band-1 end_stone/chorus but a characteristic
#       ender_pearl (14% band-2) topping + void_shard reagent (10% band-3); the most
#       uncommon-topped overworld-tier pool, a genuine notch above plains ore.
#   band 3 (rare — 1 biome): deep_dark  -> 50% band-3+ by weight (diamond + amethyst_shard +
#       echo_shard + sculk_catalyst + 2 cooking/rare reagents). The only genuinely
#       rare-gem-heavy prospect pool; characteristic drop IS rare. (Median band = 3.)
#   No prospect pool reaches band 4-6: none is apex/mythical-reagent characteristic.
# ---------------------------------------------------------------------------------------

# Band 3 — Deep Dark (rare-gem-heavy: echo shard / diamond / sculk catalyst).
execute if data storage evercraft:pr_temp {node_biome:"deep_dark"} run data modify entity @e[type=marker,tag=ec.prospect_new,limit=1,distance=..1] data.rarity set value 3

# Band 2 — The End (uncommon-topped end materials: ender pearl / void shard).
execute if data storage evercraft:pr_temp {node_biome:"the_end"} run data modify entity @e[type=marker,tag=ec.prospect_new,limit=1,distance=..1] data.rarity set value 2

# Band 1 — every other detected biome (common ore/bulk). Stamped explicitly so the marker is
# self-describing and an audit never confuses a common pool with a missing mapping.
execute unless data storage evercraft:pr_temp {node_biome:"deep_dark"} unless data storage evercraft:pr_temp {node_biome:"the_end"} run data modify entity @e[type=marker,tag=ec.prospect_new,limit=1,distance=..1] data.rarity set value 1
