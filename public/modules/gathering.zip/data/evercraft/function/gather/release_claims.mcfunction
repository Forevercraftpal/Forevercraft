# === GATHER — RELEASE CLAIM TAGS (1t end-of-tick sweep) ===
# Self-scheduling 1t loop. Existence-gated: returns immediately unless at least one
# gather marker currently holds the ec.gth_claimed tag (claims are only live for the
# single tick a player resolved on a node, so this is a no-op virtually every tick).
# When claims exist, clears them so the NEXT tick's click can re-claim (the loser's
# dropped click re-fires and can now win) — this is the "1t-later release" the race
# seat's Shape β specifies.
#
# Scheduled from gather/load via init? No — claim_node arms it on demand so the tick
# isn't permanently resident. See gather/claim_node (it schedules this 1t when a claim
# is taken). The existence gate makes a stray extra run free.

# Existence gate: bail unless a claim is live.
execute unless entity @e[type=marker,tag=ec.gth_claimed,limit=1] run return 0

# Clear the claim tag from every gather marker so next tick is fresh.
tag @e[type=marker,tag=ec.gth_claimed] remove ec.gth_claimed
