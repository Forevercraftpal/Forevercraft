# === GATHER — CLAIM NODE (coord-pinned macro) ===
# Macro — called with storage evercraft:gth_temp {x:X, y:Y, z:Z, dtag:"ec.<type>_data"}.
# Run as @s (the clicking player), at the player. Coord-pin mirrors prospect/target_node's
# selector (distance=..2, limit=1, sort=nearest) so we operate on the EXACT node the player
# attempted, never "nearest at click time" (race R3).
#
# Single-writer-under-claim. Minecraft executes function bodies SERIALLY within a tick — two
# players clicking the same node in the same tick run their claim_node calls one after the
# other, never interleaved mid-body. So a test-then-set on the marker's claim tag is atomic
# relative to the other player's call:
#   - Player A (first to run): the nearest pinned marker is fresh -> A stamps it + wins.
#   - Player B (runs after A completes): the nearest marker already carries the tag -> B
#     does NOT win; its dropped click re-fires next tick (the tag is cleared 1t later by
#     release_claims), matching the "click again to retry" UX.
#
# To make the "is THE pinned node already claimed?" test exact (never a farther adjacent
# marker), we bind to the single nearest pinned marker (limit=1, sort=nearest) and add the
# claim tag ONLY to a marker that lacks it. We then read back whether the nearest pinned
# marker carries the tag AND whether THIS player is the one who set it this tick — done by
# stamping the player's own scoreboard win directly in the same conditional that does the
# tag (player stays the executor, so @s is the player throughout).

# 1) If the nearest pinned marker is currently unclaimed, claim it (tag the marker) AND
#    record our win in one conditional — both gated on the SAME nearest-unclaimed selector,
#    so we only ever win when we are the executor that flips the tag.
$execute positioned $(x) $(y) $(z) if entity @e[type=marker,tag=$(dtag),tag=!ec.gth_claimed,distance=..2,limit=1,sort=nearest] run scoreboard players set @s ec.gth_claimed 1
$execute if score @s ec.gth_claimed matches 1 positioned $(x) $(y) $(z) run tag @e[type=marker,tag=$(dtag),tag=!ec.gth_claimed,distance=..2,limit=1,sort=nearest] add ec.gth_claimed
