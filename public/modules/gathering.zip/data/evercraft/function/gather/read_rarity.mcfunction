# === GATHER — READ RARITY BAND FROM THE NODE MARKER ===
# Run as @s; caller has stored the pinned node coords + dtag in evercraft:gth_temp.
# Reads the marker's data.rarity (1-6) into @s ec.gth_base as a raw BAND number,
# defaulting to band 1 when the marker has no data.rarity stamped.
#
# B-rarity (2026-05-31, DONE): data.rarity is now stamped at spawn by the three domain
# stampers gather/rarity/stamp_{prospect,forage,splash} (called from each place_node/
# place_bush right after the biome/dim stamp). Band = the representative ITEM rarity of the
# node's drop POOL per rarity-canon (NOT area — area is the separate Wave-C areaMult). An
# unmapped node still reads as band 1 via the default below, so the engine stays robust.
# This file ONLY does the read-with-default; rarity_xp then maps band -> baseXP.

# Default band 1 (the `execute store result` below leaves ec.gth_base untouched if the
# marker has no data.rarity, so seed it first).
scoreboard players operation @s ec.gth_base = #gth_rarity_default ec.var
function evercraft:gather/read_rarity_pinned with storage evercraft:gth_temp
