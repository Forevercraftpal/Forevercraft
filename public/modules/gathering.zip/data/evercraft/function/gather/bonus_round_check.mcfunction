# ══════════════════════════════════════════════════════════════
# Gather — Bonus Round Roll (Joseph 2026-06-12)
# Run as @s = the gathering player, after resolve dispatches win/fail.
# ──────────────────────────────────────────────────────────────
# Adds an extra round (+1 charge) to the node entity on a rare roll.
#   Base chance: 5.00%  (500 bps)
#   Class scaling: +0.02% per class level (level 100 = 7%)
#   Eligibility: ALWAYS on WIN; only on FAIL when class level >= 25
#   Crumble (gth_outcome=3) skipped — node already despawned
# Stacks naturally — each call adds +1, so back-to-back rolls compound.
# ══════════════════════════════════════════════════════════════

# Resolve the active class's level (the gather pipeline sets ec.caff_class
# 1..7 in caller B-wires; mirrors update_level.mcfunction's write map).
scoreboard players set #gth_lvl ec.temp 0
execute if score @s ec.caff_class matches 1 store result score #gth_lvl ec.temp run scoreboard players get @s ec.caffl_ss
execute if score @s ec.caff_class matches 2 store result score #gth_lvl ec.temp run scoreboard players get @s ec.caffl_lf
execute if score @s ec.caff_class matches 3 store result score #gth_lvl ec.temp run scoreboard players get @s ec.caffl_gs
execute if score @s ec.caff_class matches 4 store result score #gth_lvl ec.temp run scoreboard players get @s ec.caffl_tw
execute if score @s ec.caff_class matches 5 store result score #gth_lvl ec.temp run scoreboard players get @s ec.caffl_sc
execute if score @s ec.caff_class matches 6 store result score #gth_lvl ec.temp run scoreboard players get @s ec.caffl_lm
execute if score @s ec.caff_class matches 7 store result score #gth_lvl ec.temp run scoreboard players get @s ec.caffl_gw

# Fail-eligibility gate: skip if outcome is FAIL and class level < 25.
execute if score @s ec.gth_outcome matches 2 unless score #gth_lvl ec.temp matches 25.. run return 0

# Compute chance in basis points (1 bps = 0.01%): 500 + level × 2.
# At level 0 → 500 (5%). At level 100 → 700 (7%).
scoreboard players set #gth_chance ec.temp 500
scoreboard players operation #gth_lvl_2x ec.temp = #gth_lvl ec.temp
scoreboard players operation #gth_lvl_2x ec.temp *= #2 ec.const
scoreboard players operation #gth_chance ec.temp += #gth_lvl_2x ec.temp

# Roll 1..10000; trigger if roll <= chance.
execute store result score #gth_roll_b ec.temp run random value 1..10000
execute if score #gth_roll_b ec.temp > #gth_chance ec.temp run return 0

# Triggered — increment node charges via the pinned read/write idiom (single-
# writer-safe because the gather claim is still in effect this tick).
function evercraft:gather/read_charges
scoreboard players add @s ec.gth_charges 1
execute store result storage evercraft:gth_temp charges int 1 run scoreboard players get @s ec.gth_charges
function evercraft:gather/write_charges_pinned with storage evercraft:gth_temp

# Cancel a same-tick despawn — a winning final-charge harvest sets ec.gth_despawn
# to 1; we just put a charge back, so the node should stay around.
scoreboard players set @s ec.gth_despawn 0

# Feedback — gold chime + sparkle + actionbar note. Channel-gated.
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.6 1.8
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.chime master @s ~ ~ ~ 0.4 2.0
execute if score @s ec.fx_vis matches 1.. at @s run particle minecraft:wax_on ~ ~1 ~ 0.4 0.4 0.4 0.05 12
data modify storage evercraft:notify stage.c set value [{text:"✦ Bonus Round ",color:"gold",bold:true},{text:"— the node holds one more harvest.",color:"yellow",italic:true}]
scoreboard players set #ndur ec.temp 35
function evercraft:util/notify/emit
