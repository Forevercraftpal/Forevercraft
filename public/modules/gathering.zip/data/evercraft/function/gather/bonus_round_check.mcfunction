# ══════════════════════════════════════════════════════════════
# Gather — Bonus Round Roll (Joseph 2026-06-12)
# Run as @s = the gathering player, after resolve dispatches win/fail.
# ──────────────────────────────────────────────────────────────
# Adds an extra round (+1 charge) to the node entity on a rare roll.
#   Base chance: 5.00%  (500 bps)
#   Class scaling: +0.02% per class level (level 100 = 7%)
#   Eligibility: ALWAYS on WIN; only on FAIL when class level >= 25
#   Crumble (gth_outcome=3) skipped — node already despawned
# Stacks naturally — each call adds +1, so back-to-back rolls compound.
# ══════════════════════════════════════════════════════════════

# Resolve the active class's level (the gather pipeline sets ec.caff_class
# 1..7 in caller B-wires; mirrors update_level.mcfunction's write map).
scoreboard players set #gth_lvl ec.temp 0
execute if score @s ec.caff_class matches 1 store result score #gth_lvl ec.temp run scoreboard players get @s ec.caffl_ss
execute if score @s ec.caff_class matches 2 store result score #gth_lvl ec.temp run scoreboard players get @s ec.caffl_lf
execute if score @s ec.caff_class matches 3 store result score #gth_lvl ec.temp run scoreboard players get @s ec.caffl_gs
execute if score @s ec.caff_class matches 4 store result score #gth_lvl ec.temp run scoreboard players get @s ec.caffl_tw
execute if score @s ec.caff_class matches 5 store result score #gth_lvl ec.temp run scoreboard players get @s ec.caffl_sc
execute if score @s ec.caff_class matches 6 store result score #gth_lvl ec.temp run scoreboard players get @s ec.caffl_lm
execute if score @s ec.caff_class matches 7 store result score #gth_lvl ec.temp run scoreboard players get @s ec.caffl_gw

# Fail-eligibility gate: skip if outcome is FAIL and class level < 25.
execute if score @s ec.gth_outcome matches 2 unless score #gth_lvl ec.temp matches 25.. run return 0

# Compute chance in basis points (1 bps = 0.01%): 500 + level × 2.
# At level 0 → 500 (5%). At level 100 → 700 (7%).
scoreboard players set #gth_chance ec.temp 500
scoreboard players operation #gth_lvl_2x ec.temp = #gth_lvl ec.temp
scoreboard players operation #gth_lvl_2x ec.temp *= #2 ec.const
scoreboard players operation #gth_chance ec.temp += #gth_lvl_2x ec.temp

# Roll 1..10000; trigger if roll <= chance.
execute store result score #gth_roll_b ec.temp run random value 1..10000
execute if score #gth_roll_b ec.temp > #gth_chance ec.temp run return 0

# Triggered — add +1 to THIS player's PER-PLAYER remaining charges on the node (2026-06-22
# per-player retrofit). pp/prep rebuilds the payload from gth_temp (a FAIL path reaches here
# without resolve_win's prep, so prep here is load-bearing); pp/get reads @s's current left
# (or seeds base when somehow absent), then set_left writes left+1. Single-writer-safe under
# the claim. The node was never despawned on exhaust anymore, so there is no despawn to cancel.
function evercraft:gather/pp/prep
function evercraft:gather/pp/get with storage evercraft:gth_pp
execute if score #gth_pp_has ec.temp matches 0 run scoreboard players operation #gth_pp_left ec.temp = #gth_charges_default ec.var
scoreboard players add #gth_pp_left ec.temp 1
execute store result storage evercraft:gth_pp left int 1 run scoreboard players get #gth_pp_left ec.temp
execute if score #gth_pp_has ec.temp matches 1 run function evercraft:gather/pp/set_left with storage evercraft:gth_pp
execute if score #gth_pp_has ec.temp matches 0 run function evercraft:gather/pp/init with storage evercraft:gth_pp

# Feedback — gold chime + sparkle + actionbar note. Channel-gated.
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.6 1.8
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.chime master @s ~ ~ ~ 0.4 2.0
execute if score @s ec.fx_vis matches 1.. at @s run particle minecraft:wax_on ~ ~1 ~ 0.4 0.4 0.4 0.05 12
data modify storage evercraft:notify stage.c set value [{text:"✦ Bonus Round ",color:"gold",bold:true},{text:"— the node holds one more harvest.",color:"yellow",italic:true}]
scoreboard players set #ndur ec.temp 35
function evercraft:util/notify/emit
