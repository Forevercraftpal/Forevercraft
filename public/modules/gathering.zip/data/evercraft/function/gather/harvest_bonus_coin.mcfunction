# === GATHER — HARVEST BONUS: give a Forever Coin (low amount) ===
# Run as @s from harvest_bonus when the coin roll hits. Gives a PHYSICAL Forever Coin item
# (evercraft:gacha/forever_coin_1..3 = 1..3 amethyst-shard coins) — picked up, it converts to
# ec.coins via gacha/coin/on_pickup. Amount weighted toward the smallest: 70% x1, 25% x2, 5% x3
# (a steady trickle, never a jackpot — SPEC "pick a low amount"). inv-full guarded (give vs spawn).
execute store result score #inv_full ec.var run function evercraft:util/check_inv_full
scoreboard players set #hb_coin_amt ec.temp 1
execute store result score #hb_coin_amtroll ec.temp run random value 1..100
execute if score #hb_coin_amtroll ec.temp matches 71..95 run scoreboard players set #hb_coin_amt ec.temp 2
execute if score #hb_coin_amtroll ec.temp matches 96..100 run scoreboard players set #hb_coin_amt ec.temp 3

# Give the matching coin table (inv-full -> spawn at feet).
execute if score #hb_coin_amt ec.temp matches 1 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:gacha/forever_coin_1
execute if score #hb_coin_amt ec.temp matches 1 if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:gacha/forever_coin_1
execute if score #hb_coin_amt ec.temp matches 2 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:gacha/forever_coin_2
execute if score #hb_coin_amt ec.temp matches 2 if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:gacha/forever_coin_2
execute if score #hb_coin_amt ec.temp matches 3 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:gacha/forever_coin_3
execute if score #hb_coin_amt ec.temp matches 3 if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:gacha/forever_coin_3

# Feedback (one terse line; the physical coin's pickup runs its own notify on collect).
data modify storage evercraft:notify stage.c set value [{text:"★ ",color:"#E0B0FF"},{text:"A Forever Coin glints in your haul!",color:"#E0B0FF"},{text:" ★",color:"#E0B0FF"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.experience_orb.pickup player @s ~ ~ ~ 0.3 1.5
