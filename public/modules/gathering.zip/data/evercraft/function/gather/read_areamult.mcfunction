# === GATHER — READ AREA XP MULTIPLIER FROM THE NODE MARKER (Wave C1) ===
# Run as @s; caller has stored the pinned node coords + dtag in evercraft:gth_temp.
# Reads the marker's data.areamult (×100 integer) into @s ec.gth_areamult, defaulting to
# 100 (×1.0 — no boost) when the marker has no data.areamult stamped (e.g. a node that
# predates the C1-tier stamp). Mirrors gather/read_rarity exactly.
#
# data.areamult is stamped at spawn by gather/tier/stamp_{prospect,forage,splash} from the
# LOCKED v2 table (100 Normal / 150 rare-biome+deepslate / 175 river / 200 ocean+sky /
# 250 Nether / 300 Deep Dark / 350 End). grant_xp multiplies the WIN XP by this /100 (fail
# consolation stays UN-multiplied, balance R7). Named factor so Wave C2 can further multiply
# it by Home-Turf familiarity before the /100.

# Default ×1.0 (areamult 100) — seed first, then the pinned macro's `execute store result`
# only overwrites when the marker actually has data.areamult (a pre-C1 node keeps ×1.0).
scoreboard players set @s ec.gth_areamult 100
function evercraft:gather/read_areamult_pinned with storage evercraft:gth_temp
