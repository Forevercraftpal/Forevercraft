# === CHEST-NODE — CLAIM APPEND (record @s into data.<list> on the node marker) ===
# Macro `function ... with storage evercraft:cn_claim`. The caller MUST have run claim/prep (x,y,z +
# u0..u3) AND set cn_claim.list = the target list ("w1_claimed"/"w1_locked"/"w2_claimed"/"opened_by").
# Appends @s's UUID array to the pinned marker's data.<list> — `append` AUTO-CREATES the list if absent,
# so no init is needed on spawn. Coord-pinned (positioned $(x) $(y) $(z), distance=..2) so a multiplayer
# crowd never writes the wrong node. This is the per-(player,chest) "claimed/locked" record the next
# open attempt reads via claim/has.

$execute positioned $(x) $(y) $(z) run data modify entity @e[type=marker,tag=ec.chest_data,distance=..2,sort=nearest,limit=1] data.$(list) append value [I;$(u0),$(u1),$(u2),$(u3)]
