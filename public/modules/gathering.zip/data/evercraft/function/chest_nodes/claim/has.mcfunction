# === CHEST-NODE — CLAIM MEMBERSHIP TEST (is @s's UUID already in data.<list>?) ===
# Macro `function ... with storage evercraft:cn_claim`. The caller MUST have run claim/prep (x,y,z +
# u0..u3) AND set cn_claim.list = the list name ("w1_claimed"/"w1_locked"/"w2_claimed"/"opened_by").
# Sets #cn_inlist ec.temp = 1 iff the pinned marker's data.<list> already contains @s's exact UUID
# array. SINGLE writer of #cn_inlist = here. (Existence-gated: a missing/empty list simply never
# matches, leaving #cn_inlist 0.)
#
# The [[I;u0,u1,u2,u3]] single-element list in the selector nbt is CONTAINS-semantics — an NBT list
# match passes iff every element of the test list appears in the target list, so a one-element test
# list is exactly "the target list holds this UUID array". Coord-pinned (positioned $(x) $(y) $(z),
# distance=..2) — NEVER a racy sort across the whole field; this is THIS node.

scoreboard players set #cn_inlist ec.temp 0
$execute positioned $(x) $(y) $(z) if entity @e[type=marker,tag=ec.chest_data,distance=..2,sort=nearest,limit=1,nbt={data:{$(list):[[I;$(u0),$(u1),$(u2),$(u3)]]}}] run scoreboard players set #cn_inlist ec.temp 1
