# === CHEST-NODE — CLAIM PREP (populate the per-player claim macro payload) ===
# Run as @s, positioned AT THE NODE, AFTER do_open's head coord-pin (so gth_temp.x/y/z is THIS node).
# Builds storage evercraft:cn_claim {x,y,z,u0..u3} = the pinned node coords + the opener's UUID ints.
# This is the shared payload every claim/has + claim/add macro reads — populate ONCE per open attempt
# (do_open / struct gate_player both call this right after their coord-pin), then the caller sets
# cn_claim.list = the list to check/append ("w1_claimed"/"w1_locked"/"w2_claimed"/"opened_by").
#
# The per-player claim STATE lives on the marker as UUID int-array lists (membership = an NBT list
# selector match in claim/has); cn_claim is just the per-call scratch that carries coords + UUID into
# the macro. ONE writer of storage cn_claim's x/y/z/u0..u3 = here (the list field is set by callers).

# Node coords from the open-time coord-pin (do_open's head / gate_player's pin set gth_temp.x/y/z).
data modify storage evercraft:cn_claim x set from storage evercraft:gth_temp x
data modify storage evercraft:cn_claim y set from storage evercraft:gth_temp y
data modify storage evercraft:cn_claim z set from storage evercraft:gth_temp z
# The opener's UUID as four ints (the [I;u0,u1,u2,u3] array form used in the marker's claim lists).
execute store result storage evercraft:cn_claim u0 int 1 run data get entity @s UUID[0]
execute store result storage evercraft:cn_claim u1 int 1 run data get entity @s UUID[1]
execute store result storage evercraft:cn_claim u2 int 1 run data get entity @s UUID[2]
execute store result storage evercraft:cn_claim u3 int 1 run data get entity @s UUID[3]
