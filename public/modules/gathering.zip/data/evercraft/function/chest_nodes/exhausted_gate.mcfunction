# === CHEST-NODE — EXHAUSTION GATE (overworld re-interaction lock) ===
# Run as @s = the clicking player, AT THE NODE (on_click calls this `as @p[..3] at @s` before crack/begin).
# Sets #cn_exhausted ec.temp = 1 iff @s can gain NOTHING more from this OVERWORLD chest: they have taken
# the key vault (data.w2_claimed) AND finished the hand track (data.w1_claimed = won, OR data.w1_locked =
# 3-fail lock). At that point the chest must not even start a crack channel — re-cracking it yields no
# loot and no XP (do_open's dispatch already returns 0), but it would still flash the Gearwright bar and
# feel "farmable". Block it here so a spent chest is truly inert for that player (Joseph 2026-06-07).
#
# Struct nodes never carry w1/w2 claims (their once-per-player gate is data.opened_by in struct/gate_player,
# and they single-use despawn), so this gate is a no-op for them — but on_click only calls it on the
# overworld path anyway (the struct route returns earlier in on_click). Self-contained coord-pin + claim/prep
# so it does not depend on do_open's head (which runs LATER, after the crack channel).

scoreboard players set #cn_exhausted ec.temp 0

# Coord-pin THIS node (nearest ec.chest_data within ~4) into gth_temp, then build the per-player claim payload.
data modify storage evercraft:gth_temp dtag set value "ec.chest_data"
execute store result storage evercraft:gth_temp x int 1 run data get entity @e[type=marker,tag=ec.chest_data,distance=..4,limit=1,sort=nearest] Pos[0]
execute store result storage evercraft:gth_temp y int 1 run data get entity @e[type=marker,tag=ec.chest_data,distance=..4,limit=1,sort=nearest] Pos[1]
execute store result storage evercraft:gth_temp z int 1 run data get entity @e[type=marker,tag=ec.chest_data,distance=..4,limit=1,sort=nearest] Pos[2]
execute unless entity @e[type=marker,tag=ec.chest_data,distance=..4,limit=1] run return 0
function evercraft:chest_nodes/claim/prep

# Took the key vault? (membership of @s's UUID in data.w2_claimed)
data modify storage evercraft:cn_claim list set value "w2_claimed"
function evercraft:chest_nodes/claim/has with storage evercraft:cn_claim
scoreboard players operation #cn_ex_w2 ec.temp = #cn_inlist ec.temp

# Hand track done? (won wave 1 -> w1_claimed, OR hand-locked after 3 fails -> w1_locked)
data modify storage evercraft:cn_claim list set value "w1_claimed"
function evercraft:chest_nodes/claim/has with storage evercraft:cn_claim
scoreboard players operation #cn_ex_hand ec.temp = #cn_inlist ec.temp
data modify storage evercraft:cn_claim list set value "w1_locked"
function evercraft:chest_nodes/claim/has with storage evercraft:cn_claim
execute if score #cn_inlist ec.temp matches 1 run scoreboard players set #cn_ex_hand ec.temp 1

# Exhausted iff BOTH the key vault and the hand track are spent for this player.
execute if score #cn_ex_w2 ec.temp matches 1 if score #cn_ex_hand ec.temp matches 1 run scoreboard players set #cn_exhausted ec.temp 1

# Blocked cue (only on a real block) — a soft "nothing left here" so the dead click is legible.
execute if score #cn_exhausted ec.temp matches 1 if score @s ec.fx_snd matches 1.. run playsound minecraft:block.chain.fall master @s ~ ~ ~ 0.4 0.9
execute if score #cn_exhausted ec.temp matches 1 run data modify storage evercraft:notify stage.c set value [{text:"⚙ ",color:"#B87333"},{text:"You've taken all this chest holds for you",color:"gray"},{text:" — its lock won't turn again.",color:"gray"}]
execute if score #cn_exhausted ec.temp matches 1 run scoreboard players set #ndur ec.temp 55
execute if score #cn_exhausted ec.temp matches 1 run function evercraft:util/notify/emit
