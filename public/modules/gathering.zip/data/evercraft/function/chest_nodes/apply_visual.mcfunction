# Chest Node: Summon the scaled container-block item_display + record data.block. Run at the node
# position, while ec.chest_new + ec.chest_vis_new are the freshly-spawned marker/visual tags.
# Picks the block from #cn_bvar ec.temp (1..17). EXCLUDES all shulker boxes (§2). Scaled to ~0.85 so it
# reads as a "mini" node; billboard:fixed sits it on the ground (does not rotate to face the player).
# The visual's item is swapped via `data modify ... item set value` (the item_display NBT idiom,
# mirroring forage/apply_variant which sets the item field from storage).
#
# Variant pool (17) — ALL chest/container block variants present in 26.1, INCLUDING the copper chests
# (a recent addition; all 8 oxidation/waxed forms confirmed as item ids in tags/item/stash/amenities +
# the #minecraft:copper_chests block tag). Shulker boxes are deliberately excluded.
#   1 chest · 2 trapped_chest · 3 barrel · 4 copper_chest · 5 exposed_copper_chest ·
#   6 weathered_copper_chest · 7 oxidized_copper_chest · 8 waxed_copper_chest ·
#   9 waxed_exposed_copper_chest · 10 waxed_weathered_copper_chest · 11 waxed_oxidized_copper_chest ·
#   12 decorated_pot · 13 hopper · 14 dispenser · 15 dropper · 16 blast_furnace · 17 smoker  (furnace removed, Joseph 2026-06-03)

# Summon the visual as a plain chest first (variant 1 default), then override item + data.block by roll.
data modify entity @e[type=marker,tag=ec.chest_new,limit=1,distance=..1] data.block set value "chest"
summon item_display ~ ~0.0 ~ {Tags:["ec.chest","ec.chest_visual","ec.chest_vis_new"],item:{id:"minecraft:chest",count:1},item_display:"fixed",transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0.5f,0.5f,0.5f],scale:[0.85f,0.85f,0.85f]},billboard:"fixed"}

# Variant 2: trapped_chest.
execute if score #cn_bvar ec.temp matches 2 run data modify entity @e[type=marker,tag=ec.chest_new,limit=1,distance=..1] data.block set value "trapped_chest"
execute if score #cn_bvar ec.temp matches 2 run data modify entity @e[type=item_display,tag=ec.chest_vis_new,limit=1,distance=..1] item set value {id:"minecraft:trapped_chest",count:1}
# Variant 3: barrel.
execute if score #cn_bvar ec.temp matches 3 run data modify entity @e[type=marker,tag=ec.chest_new,limit=1,distance=..1] data.block set value "barrel"
execute if score #cn_bvar ec.temp matches 3 run data modify entity @e[type=item_display,tag=ec.chest_vis_new,limit=1,distance=..1] item set value {id:"minecraft:barrel",count:1}
# Variant 4: copper_chest (un-oxidized).
execute if score #cn_bvar ec.temp matches 4 run data modify entity @e[type=marker,tag=ec.chest_new,limit=1,distance=..1] data.block set value "copper_chest"
execute if score #cn_bvar ec.temp matches 4 run data modify entity @e[type=item_display,tag=ec.chest_vis_new,limit=1,distance=..1] item set value {id:"minecraft:copper_chest",count:1}
# Variant 5: exposed_copper_chest.
execute if score #cn_bvar ec.temp matches 5 run data modify entity @e[type=marker,tag=ec.chest_new,limit=1,distance=..1] data.block set value "exposed_copper_chest"
execute if score #cn_bvar ec.temp matches 5 run data modify entity @e[type=item_display,tag=ec.chest_vis_new,limit=1,distance=..1] item set value {id:"minecraft:exposed_copper_chest",count:1}
# Variant 6: weathered_copper_chest.
execute if score #cn_bvar ec.temp matches 6 run data modify entity @e[type=marker,tag=ec.chest_new,limit=1,distance=..1] data.block set value "weathered_copper_chest"
execute if score #cn_bvar ec.temp matches 6 run data modify entity @e[type=item_display,tag=ec.chest_vis_new,limit=1,distance=..1] item set value {id:"minecraft:weathered_copper_chest",count:1}
# Variant 7: oxidized_copper_chest.
execute if score #cn_bvar ec.temp matches 7 run data modify entity @e[type=marker,tag=ec.chest_new,limit=1,distance=..1] data.block set value "oxidized_copper_chest"
execute if score #cn_bvar ec.temp matches 7 run data modify entity @e[type=item_display,tag=ec.chest_vis_new,limit=1,distance=..1] item set value {id:"minecraft:oxidized_copper_chest",count:1}
# Variant 8: waxed_copper_chest.
execute if score #cn_bvar ec.temp matches 8 run data modify entity @e[type=marker,tag=ec.chest_new,limit=1,distance=..1] data.block set value "waxed_copper_chest"
execute if score #cn_bvar ec.temp matches 8 run data modify entity @e[type=item_display,tag=ec.chest_vis_new,limit=1,distance=..1] item set value {id:"minecraft:waxed_copper_chest",count:1}
# Variant 9: waxed_exposed_copper_chest.
execute if score #cn_bvar ec.temp matches 9 run data modify entity @e[type=marker,tag=ec.chest_new,limit=1,distance=..1] data.block set value "waxed_exposed_copper_chest"
execute if score #cn_bvar ec.temp matches 9 run data modify entity @e[type=item_display,tag=ec.chest_vis_new,limit=1,distance=..1] item set value {id:"minecraft:waxed_exposed_copper_chest",count:1}
# Variant 10: waxed_weathered_copper_chest.
execute if score #cn_bvar ec.temp matches 10 run data modify entity @e[type=marker,tag=ec.chest_new,limit=1,distance=..1] data.block set value "waxed_weathered_copper_chest"
execute if score #cn_bvar ec.temp matches 10 run data modify entity @e[type=item_display,tag=ec.chest_vis_new,limit=1,distance=..1] item set value {id:"minecraft:waxed_weathered_copper_chest",count:1}
# Variant 11: waxed_oxidized_copper_chest.
execute if score #cn_bvar ec.temp matches 11 run data modify entity @e[type=marker,tag=ec.chest_new,limit=1,distance=..1] data.block set value "waxed_oxidized_copper_chest"
execute if score #cn_bvar ec.temp matches 11 run data modify entity @e[type=item_display,tag=ec.chest_vis_new,limit=1,distance=..1] item set value {id:"minecraft:waxed_oxidized_copper_chest",count:1}
# Variant 12: decorated_pot.
execute if score #cn_bvar ec.temp matches 12 run data modify entity @e[type=marker,tag=ec.chest_new,limit=1,distance=..1] data.block set value "decorated_pot"
execute if score #cn_bvar ec.temp matches 12 run data modify entity @e[type=item_display,tag=ec.chest_vis_new,limit=1,distance=..1] item set value {id:"minecraft:decorated_pot",count:1}
# Variant 13: hopper.
execute if score #cn_bvar ec.temp matches 13 run data modify entity @e[type=marker,tag=ec.chest_new,limit=1,distance=..1] data.block set value "hopper"
execute if score #cn_bvar ec.temp matches 13 run data modify entity @e[type=item_display,tag=ec.chest_vis_new,limit=1,distance=..1] item set value {id:"minecraft:hopper",count:1}
# Variant 14: dispenser.
execute if score #cn_bvar ec.temp matches 14 run data modify entity @e[type=marker,tag=ec.chest_new,limit=1,distance=..1] data.block set value "dispenser"
execute if score #cn_bvar ec.temp matches 14 run data modify entity @e[type=item_display,tag=ec.chest_vis_new,limit=1,distance=..1] item set value {id:"minecraft:dispenser",count:1}
# Variant 15: dropper.
execute if score #cn_bvar ec.temp matches 15 run data modify entity @e[type=marker,tag=ec.chest_new,limit=1,distance=..1] data.block set value "dropper"
execute if score #cn_bvar ec.temp matches 15 run data modify entity @e[type=item_display,tag=ec.chest_vis_new,limit=1,distance=..1] item set value {id:"minecraft:dropper",count:1}
# Variant 16: blast_furnace.
execute if score #cn_bvar ec.temp matches 16 run data modify entity @e[type=marker,tag=ec.chest_new,limit=1,distance=..1] data.block set value "blast_furnace"
execute if score #cn_bvar ec.temp matches 16 run data modify entity @e[type=item_display,tag=ec.chest_vis_new,limit=1,distance=..1] item set value {id:"minecraft:blast_furnace",count:1}
# Variant 17: smoker.
execute if score #cn_bvar ec.temp matches 17 run data modify entity @e[type=marker,tag=ec.chest_new,limit=1,distance=..1] data.block set value "smoker"
execute if score #cn_bvar ec.temp matches 17 run data modify entity @e[type=item_display,tag=ec.chest_vis_new,limit=1,distance=..1] item set value {id:"minecraft:smoker",count:1}
