# === CHEST-NODE — WAVE 1 OPEN (bare-hands keyless PASS, per-player) ===
# Run as @s, positioned AT THE NODE, AFTER do_open's coord-pin + claim/prep, ONCE the keyless gate
# passed (#cn_openpass=1, hands win). Grants the player's WAVE 1 loot (standard chest, NO rich boost),
# records the per-(player,chest) w1_claimed claim, and clears the hand-attempt streak. Per-player: this
# fires once per (player, chest) — the keyless gate is only reached for a player who is neither
# w1_claimed nor w1_locked (do_open enforces that), so re-entry is impossible.

# --- Gearwright XP (full WIN grant): the exact chain gather/resolve uses for a chest win (src 5 ->
#     class 7). read_rarity + rarity_xp set ec.gth_base from the node's rarity band; gth_win 1 = full XP.
function evercraft:gather/read_rarity
function evercraft:gather/rarity_xp
scoreboard players set @s ec.gth_win 1
scoreboard players set @s ec.gth_src 5
function evercraft:gather/grant_xp

# --- Loot: standard chest (NO rich boost — wave 1 is the bare-hands wave). #cn_richbonus 0 leaves
#     do_open_success's crate-threshold untouched. do_open_success owns the resolve + sounds + map +
#     harvest-bonus + Dreamy Pull. ---
scoreboard players set #cn_richbonus ec.temp 0
function evercraft:chest_nodes/do_open_success

# --- Record the wave-1 claim on the marker (UUID appended to data.w1_claimed). ---
data modify storage evercraft:cn_claim list set value "w1_claimed"
function evercraft:chest_nodes/claim/add with storage evercraft:cn_claim

# --- Hand track is done for this chest: w1_claimed (appended above) makes every future hand-click here
#     hit the "already opened by hand" early-return in dispatch_hands — no streak state to clear. ---

# --- Themed success line (non-bold actionbar via the notify queue). ---
data modify storage evercraft:notify stage.c set value [{text:"⚙ ",color:"#B87333"},{text:"Your hands win out",color:"aqua"},{text:" — the chest yields! ",color:"gray"},{text:"(Wave 1)",color:"aqua"}]
scoreboard players set #ndur ec.temp 55
function evercraft:util/notify/emit
