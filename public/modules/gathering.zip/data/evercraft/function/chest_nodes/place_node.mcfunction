# Chest Node: Summon node entities on the ground surface. Run at the surface position (air block
# just above solid ground). Reads the placer's dominant key type from storage evercraft:cn_temp
# {keytype:N} (0=plain/1=crafting/2=dungeon) — global storage, so a plain function (no macro) reads it.
# Mirrors fishing/splash_nodes/place_node: data marker + scaled item_display (the container block) +
# interaction hitbox, then stamps data.{ctype,block,charges,rarity} + fires the on-spawn Loot Sense.

# Read the placer's dominant key type into a score for the ctype weighting below (default 0=plain).
scoreboard players set #cn_keytype ec.temp 0
execute store result score #cn_keytype ec.temp run data get storage evercraft:cn_temp keytype

# --- Data marker (stores spawn gametime for the 60s despawn calc + node state) ---
summon marker ~ ~ ~ {Tags:["ec.chest","ec.chest_data","ec.chest_new"]}
execute store result entity @e[type=marker,tag=ec.chest_new,limit=1,distance=..1] data.spawn_time long 1 run time query gametime
# Charges = 1 (one open despawns the node, §2). gather/read_charges_pinned reads data.charges.
data modify entity @e[type=marker,tag=ec.chest_new,limit=1,distance=..1] data.charges set value 1

# --- Roll the chest TYPE (data.ctype): 1=Crafting, 2=Adventurer, 3=plain — weighted by the
#     placer's carried key ($(keytype): 0=none/1=trial/2=dungeon, §2). Dungeon Key -> Adventurer-
#     leaning (70/30); Trial Pass -> Crafting-leaning (70/30); no key -> always plain. Stamped on the
#     marker for do_open + the loot resolver to read. Default plain (3) first, then override by roll. ---
data modify entity @e[type=marker,tag=ec.chest_new,limit=1,distance=..1] data.ctype set value 3
execute store result score #cn_ctroll ec.temp run random value 1..100
# Trial Pass (keytype 1) -> 70% Crafting (ctype 1), else plain.
execute if score #cn_keytype ec.temp matches 1 if score #cn_ctroll ec.temp matches 1..70 run data modify entity @e[type=marker,tag=ec.chest_new,limit=1,distance=..1] data.ctype set value 1
# Dungeon Key (keytype 2) -> 70% Adventurer (ctype 2), else plain.
execute if score #cn_keytype ec.temp matches 2 if score #cn_ctroll ec.temp matches 1..70 run data modify entity @e[type=marker,tag=ec.chest_new,limit=1,distance=..1] data.ctype set value 2

# --- Pick a container-block VARIANT (item_display item) — EXCLUDE all shulker boxes (§2). ---
# Roll 1..17 over the full 26.1 container pool (chest / trapped_chest / barrel / the 8 copper-chest
# oxidation+waxed forms / decorated_pot / hopper / dispenser / dropper / blast_furnace /
# smoker). The chosen item is summoned as a scaled item_display + recorded in data.block.
execute store result score #cn_bvar ec.temp run random value 1..17
function evercraft:chest_nodes/apply_visual

# --- Interaction entity (right-click target, sized to cover the block) ---
summon interaction ~0.5 ~0.05 ~0.5 {Tags:["ec.chest","ec.chest_click"],width:0.95f,height:0.95f,response:1b}

# B-rarity: stamp data.rarity (1-6) on the SAME marker (drives gather/read_rarity baseXP at open).
function evercraft:gather/rarity/stamp_chest

# Clean up temporary tags.
tag @e[type=marker,tag=ec.chest_new,limit=1,distance=..1] remove ec.chest_new
tag @e[type=item_display,tag=ec.chest_vis_new,limit=1,distance=..1] remove ec.chest_vis_new

# Spawn particle burst (a coppery sparkle befitting the Gearwright theme).
particle minecraft:wax_on ~ ~0.5 ~ 0.3 0.3 0.3 0.05 12
particle dust{color:[0.722,0.451,0.2],scale:1.0} ~ ~0.5 ~ 0.25 0.3 0.25 0 8

# --- ★ LOOT SENSE (P1 headline ability) — fire the on-spawn sense for nearby Gearwright players. ---
# Existence-gated to the just-spawned node's vicinity; abilities/loot_sense self-gates per tier.
execute at @e[type=marker,tag=ec.chest_data,distance=..2,limit=1,sort=nearest] as @a[distance=..48,gamemode=!spectator] at @s run function evercraft:chest_nodes/abilities/loot_sense
