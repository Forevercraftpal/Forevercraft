# === CHEST-NODE — KEY-CARRY DETECTION (every 5s, self-correcting) ===
# Mirrors dungeon/unknown/key_detect:16-20. Maintains ec.cn_haskey (1 if the player carries any
# USABLE/fresh key) + ec.cn_keytype (dominant type: 0=none, 1=trial/crafting, 2=dungeon/adventurer)
# on every player. These influence the chest spawn rate + type (try_spawn/check_spawn read them).
# Scans container.* + offhand for a FRESH (un-worn) Trial Pass / Dungeon Key, AND the key-bag's
# on-item FRESH counts (ks_cfresh/ks_dfresh, §4) — ONLY fresh keys boost spawn/open (worn keys can't
# open chests). The key-bag fields land in P4; this scan tolerates their absence (the bag checks just
# don't match until then). Cadence 5s (the tag is self-correcting + the engine reads it cheaply).

# Early exit if no players online.
execute unless entity @a run return run schedule function evercraft:chest_nodes/key_detect 5s replace

# --- Reset every player's flags, then re-detect (self-correcting, like the dungeon sweep). ---
scoreboard players set @a ec.cn_haskey 0
scoreboard players set @a ec.cn_keytype 0

# Trial Pass (fresh = no worn flag) in inventory/offhand -> crafting key (keytype 1).
execute as @a if items entity @s container.* *[custom_data~{trial_pass:1b}] unless items entity @s container.* *[custom_data~{trial_pass:1b,worn:1b}] run scoreboard players set @s ec.cn_keytype 1
execute as @a if items entity @s weapon.offhand *[custom_data~{trial_pass:1b}] unless items entity @s weapon.offhand *[custom_data~{trial_pass:1b,worn:1b}] run scoreboard players set @s ec.cn_keytype 1

# Dungeon Key (fresh) in inventory/offhand -> adventurer key (keytype 2). Dungeon dominates a tie
# (a player carrying both leans Adventurer), so it is checked AFTER the trial check (later write wins).
execute as @a if items entity @s container.* *[custom_data~{dungeon_key:true}] unless items entity @s container.* *[custom_data~{dungeon_key:true,worn:1b}] run scoreboard players set @s ec.cn_keytype 2
execute as @a if items entity @s weapon.offhand *[custom_data~{dungeon_key:true}] unless items entity @s weapon.offhand *[custom_data~{dungeon_key:true,worn:1b}] run scoreboard players set @s ec.cn_keytype 2

# --- Key-bag (Key Ring / Bag of Keys, §4) FRESH counts on the held bag item (P4 stamps these). ---
# Reading on-item custom_data needs a per-player macro (the field path is fixed but the read is a
# `data get` off the held item). For P2a we detect the bag's PRESENCE with a fresh count > 0 via an
# item predicate on the count fields; the precise dominant-count comparison lands with the bag in P4.
# A Key Ring / Bag of Keys carrying fresh crafting keys -> keytype 1 (if not already 2).
execute as @a[scores={ec.cn_keytype=0}] if items entity @s container.* *[custom_data~{key_bag:true}] run function evercraft:chest_nodes/key_bag_scan
execute as @a[scores={ec.cn_keytype=0}] if items entity @s weapon.offhand *[custom_data~{key_bag:true}] run function evercraft:chest_nodes/key_bag_scan

# Set the haskey flag from the resolved keytype (1 or 2 -> has a usable key).
scoreboard players set @a[scores={ec.cn_keytype=1..}] ec.cn_haskey 1

# Reschedule.
schedule function evercraft:chest_nodes/key_detect 5s replace
