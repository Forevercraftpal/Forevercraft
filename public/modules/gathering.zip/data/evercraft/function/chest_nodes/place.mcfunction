# Chest Node: PUBLIC "place a chest node near me" entry. Run as the player, at the player.
# Seeds the multi-candidate search budget + success flag, then runs the recursive candidate search.
# Used by: try_spawn (the ambient ~3/day spawn), §9 archaeology 5% brush-spawn (P6), and P2.5
# structure-chest batches (each candidate gated by a structure predicate there). Callers that need
# a specific ctype pre-stamp `storage evercraft:cn_temp keytype` BEFORE calling; otherwise it
# defaults to the player's carried key type (try_spawn stamps it; standalone callers may set 0=plain).

# Seed the candidate budget + the placed flag (consumed/written by place_attempt).
scoreboard players set #cn_placed ec.temp 0
scoreboard players set #cn_tries ec.temp 8

# Default the keytype to plain (0) if the caller did not stamp one (so cn_temp.keytype always exists).
execute unless data storage evercraft:cn_temp keytype run data modify storage evercraft:cn_temp keytype set value 0

# Run the recursive candidate search (places at the first solid ground surface found).
function evercraft:chest_nodes/place_attempt
