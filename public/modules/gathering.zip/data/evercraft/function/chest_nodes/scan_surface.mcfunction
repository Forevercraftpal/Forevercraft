# Chest Node: Scan downward to find a solid GROUND surface (air-above-solid, never on liquid).
# Run as: temp marker, at: temp marker. Uses: #cn_scan ec.temp (decremented each call).
# Returns: 1 if found (marker TPed to the air block just above solid ground), else 0.
# Mirrors evercraft:common/scan_down but explicitly EXCLUDES liquids + non-collidable blocks so a
# chest never lands floating on water/lava or buried inside foliage.

scoreboard players remove #cn_scan ec.temp 1
execute if score #cn_scan ec.temp matches ..0 run return 0

# Surface = spawnable-air here, a solid (non-air, non-water, non-lava) block directly below.
execute if block ~ ~ ~ #evercraft:spawnable_air unless block ~ ~-1 ~ #evercraft:spawnable_air unless block ~ ~-1 ~ minecraft:water unless block ~ ~-1 ~ minecraft:lava run return 1

# Keep scanning down (works through both air and solid).
tp @s ~ ~-1 ~
execute at @s run function evercraft:chest_nodes/scan_surface
