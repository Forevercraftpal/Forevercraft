# Chest Node: Per-player spawn timer management. Run as each eligible player, at player position.
# Mirrors fishing/splash_nodes/check_spawn (decrement-then-fire), but the chest cadence is the
# ~3/MC-day probabilistic model (§10.2): a long base timer + a per-expiry probabilistic gate, with
# key-carry + ec.acc_spawn + the Gearwright spawn perk shortening the timer (more nodes for keyed
# players, never a hard daily counter).

# Decrement the spawn timer by 20 ticks (1 second).
scoreboard players remove @s ec.cn_timer 20

# Not yet expired -> nothing to do this second.
execute if score @s ec.cn_timer matches 0.. run return 0

# --- Timer expired: roll the per-MC-day probabilistic spawn gate, then attempt a spawn. ---
# Build the effective gate (1..100 success window): base 50, +keyed bonus, +accessory/perk bonus.
# Keyed players + ec.acc_spawn carriers + Gearwright spawn-perk holders are MORE likely to spawn.
scoreboard players operation #cn_gate ec.temp = #cn_spawn_gate ec.var
execute if score @s ec.cn_haskey matches 1 run scoreboard players add #cn_gate ec.temp 25
execute if score @s ec.acc_spawn matches 1 run scoreboard players add #cn_gate ec.temp 15
# Gearwright spawn perk: a leveled Gearwright (L25+) nudges the gate up (the secondary spawn-boost perk).
execute if score @s ec.caffl_gw matches 25.. run scoreboard players add #cn_gate ec.temp 10

# Roll the gate. On a miss, just reset the timer (no spawn this cycle) — the ~3/day limiter.
execute store result score #cn_roll ec.temp run random value 1..100
execute if score #cn_roll ec.temp > #cn_gate ec.temp run return run function evercraft:chest_nodes/reset_timer

# Gate passed -> attempt to place a node near the player.
function evercraft:chest_nodes/try_spawn
