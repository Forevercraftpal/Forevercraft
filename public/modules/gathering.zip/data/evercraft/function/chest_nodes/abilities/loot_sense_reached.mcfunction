# Gearwright Loot Sense T1 — ARRIVAL: the player reached a chest node during the 15s follow window
# (run as @s at @s, within ~4 blocks of a node). The chase paid off — whether the sense was genuine or
# a hallucination that happened to land on a real chest, reaching it closes the window with a satisfying
# confirm (a chest-bound chime + a brief copper sparkle). No "imagination" line on a successful find.
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.8 1.5
data modify storage evercraft:notify stage.c set value [{text:"⚙ ",color:"#B87333"},{text:"Your sense was true — a chest is here.",color:"#B87333",italic:true}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute if score @s ec.fx_vis matches 1.. run particle minecraft:wax_on ~ ~1.0 ~ 0.25 0.4 0.25 0.04 10
function evercraft:chest_nodes/abilities/loot_sense_clear
