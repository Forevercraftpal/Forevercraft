# Gearwright Loot Sense T1 — close the follow window (run as @s). Clears the follow tag + zeroes the
# per-player follow state so loot_sense_follow stops picking the player up. Called on arrival, on
# expiry, and defensively when a follower has crossed into L10+ (T2 has no follow window).
tag @s remove ec.gw_following
scoreboard players set @s ec.gw_lsfol 0
scoreboard players set @s ec.gw_lsreal 0
