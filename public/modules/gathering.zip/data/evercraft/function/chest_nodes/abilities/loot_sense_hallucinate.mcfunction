# Gearwright Loot Sense T1 — the "…or it was just your imagination" hallucination tail. Run as @s at @s
# from loot_sense_step when a FALSE follow window (ec.gw_lsreal 0) runs out its full 15s without the
# player reaching a chest. T1 has genuine false-positives, so the wry tail + a fizzle give the
# unreliable T1 sense character (genuine senses at T2+ never open a window, so never reach here).
# loot_sense_step clears the follow state right after this call.
data modify storage evercraft:notify stage.c set value [{text:"⚙ ",color:"#B87333"},{text:"…or it was just your imagination.",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 0.4 0.6
execute if score @s ec.fx_vis matches 1.. run particle minecraft:smoke ~ ~1.0 ~ 0.2 0.3 0.2 0.01 8
