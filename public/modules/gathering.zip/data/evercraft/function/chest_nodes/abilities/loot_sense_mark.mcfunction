# Gearwright Loot Sense T4-T6 — LOCATION MARKER over the sensed chest. Run as @s (the sensing player,
# L50+), positioned at the player. Draws a glowing marker column at the nearest chest node so the player
# can SEE where to go. Duration scales by tier (T4 L50 = 5s, T5 L75 = 15s, T6 L100 = the node's full
# lifetime); here the marker is a tier-scaled particle beacon fired at the node now + re-pulsed by a
# short self-schedule, with the pulse count scaled by tier. Existence-gated (the node must still exist).
#
# The marker rides the node's own render loop for longevity: we tag the nearest node with a per-tier
# marker-duration so render_node (the existing per-node 10t loop) draws the waypoint glow for that long.
# This reuses the node's existence-gated render (no new per-player tick) — the right perf shape.

# Find the nearest chest node and stamp a marker-glow countdown on it (in 10t render frames).
# T4 (L50-74): 100t = ~5s -> 10 frames. T5 (L75-99): 300t = ~15s -> 30 frames. T6 (L100): the node's
# full remaining lifetime -> a large frame count (the despawn watchdog kills the node first anyway).
execute if score @s ec.caffl_gw matches 50..74 run data modify entity @e[type=marker,tag=ec.chest_data,distance=..48,limit=1,sort=nearest] data.mark_glow set value 10
execute if score @s ec.caffl_gw matches 75..99 run data modify entity @e[type=marker,tag=ec.chest_data,distance=..48,limit=1,sort=nearest] data.mark_glow set value 30
execute if score @s ec.caffl_gw matches 100.. run data modify entity @e[type=marker,tag=ec.chest_data,distance=..48,limit=1,sort=nearest] data.mark_glow set value 600

# An immediate marker burst so the cue is instant (the render loop sustains it).
execute if score @s ec.fx_vis matches 1.. at @e[type=marker,tag=ec.chest_data,distance=..48,limit=1,sort=nearest] run particle minecraft:glow ~ ~1.2 ~ 0.1 0.6 0.1 0.02 18
execute if score @s ec.fx_vis matches 1.. at @e[type=marker,tag=ec.chest_data,distance=..48,limit=1,sort=nearest] run particle minecraft:end_rod ~ ~1.5 ~ 0.05 0.7 0.05 0.01 10
