# === GEARWRIGHT — LOOT SENSE T1 FOLLOW WINDOW (the 15s directional chase; PLAN §1) ===
# Self-scheduled 10t loop. Existence-gated on @a[tag=ec.gw_following] so it is near-free when no one is
# following (mirrors the other chest_nodes tick loops). For each following player (a sub-L10 Gearwright
# who just got a T1 sense): play a DIRECTIONAL chest sound toward the nearest node so they can chase it,
# count the 15s window down (ec.gw_lsfol frames, 30 = 15s, ONE writer = here), and resolve:
#   • REACHED a chest node (within ~4 blocks)  -> close the window: a confirm chime, end the chase.
#   • Window ran out (ec.gw_lsfol hits 0):
#       - hallucination (ec.gw_lsreal 0) -> "…or it was just your imagination." + a fizzle.
#       - genuine (ec.gw_lsreal 1) but un-reached -> close quietly (the sense was real; they just
#         didn't go — no false "imagination" line for a true sense).
# The directional cue: a chest sound played POSITIONALLY at the nearest node pans toward it for the
# listener (the same positional-audio idiom T3 uses for its note-block direction cue).

schedule function evercraft:chest_nodes/abilities/loot_sense_follow 10t replace

# Existence-gate: nothing to do unless at least one player is mid-follow.
execute unless entity @a[tag=ec.gw_following,limit=1] run return 0

# Per-following-player, positioned at the player.
execute as @a[tag=ec.gw_following] at @s run function evercraft:chest_nodes/abilities/loot_sense_step
