# Gearwright Loot Sense T1 — ONE following player's per-frame step (run as @s at @s from
# loot_sense_follow, every 10t). Plays the directional chase-sound, checks for arrival, ticks the 15s
# window down, and resolves on arrival or expiry. @s is a sub-L10 Gearwright tagged ec.gw_following.

# Safety: a player who has since reached L10+ (T2) should not be in a T1 follow — close it silently.
execute if score @s ec.caffl_gw matches 10.. run function evercraft:chest_nodes/abilities/loot_sense_clear
execute if score @s ec.caffl_gw matches 10.. run return 0

# --- REACHED a chest node? Within ~4 blocks of any node = arrival: close the window with a confirm. ---
execute if entity @e[type=marker,tag=ec.chest_data,distance=..4,limit=1] run function evercraft:chest_nodes/abilities/loot_sense_reached
execute if entity @e[type=marker,tag=ec.chest_data,distance=..4,limit=1] run return 0

# --- DIRECTIONAL chase-sound: a single soft note-block bell (F#5 — the chest-node "treasure" key,
#     matching the do_open_success chord sparkle) played AT the nearest node so the positional audio
#     pans toward it for the listener (the cue to follow). Joseph 2026-06-09: was a chest-open creak,
#     which fired up to 30× per 15s follow and grated; one quiet tonal ping localizes better and stays
#     pleasant on repeat. Gated to a node still existing within sense range; if none remains, the cue
#     simply goes silent this frame (the window still counts down). ---
execute if score @s ec.fx_snd matches 2.. at @e[type=marker,tag=ec.chest_data,distance=..64,limit=1,sort=nearest] run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.55 2.0

# --- Tick the 15s window down (ONE writer of ec.gw_lsfol). ---
scoreboard players remove @s ec.gw_lsfol 1

# --- Window expired (<=0): resolve. Hallucination -> imagination tail; genuine -> close quietly. ---
execute if score @s ec.gw_lsfol matches ..0 if score @s ec.gw_lsreal matches 0 run function evercraft:chest_nodes/abilities/loot_sense_hallucinate
execute if score @s ec.gw_lsfol matches ..0 run function evercraft:chest_nodes/abilities/loot_sense_clear
