# === GEARWRIGHT — LOOT SENSE (the headline ability, 6 tiers; PLAN §1) ===
# Run as @s = a player within 48 blocks of a JUST-SPAWNED chest node (place_node calls this `as @a
# [distance=..48] at @s` after the node lands). Positioned at the player. The node is the nearest
# ec.chest_data marker. Picks the highest unlocked tier off ec.caffl_gw (P1 constants #caff_gw_ls_*)
# and fires the matching sense. Self-gating: a player who never reached T1 (no Gearwright XP) gets
# NOTHING (so non-Gearwright players aren't spammed by every spawn).
#
#   T1 (unlock, any Gearwright XP): actionbar "a chest is sensed nearby" + a sense-sound; then a
#       follow-chest-sound for 15s (a directional cue) — BUT it MAY be a hallucination. ~30% of T1
#       senses are FALSE: if 15s elapse without reaching a chest, it resolves as imagination ("…or it
#       was just your imagination." + a fizzle). The window is driven by loot_sense_follow.
#   T2 (L10): genuine notification only — no hallucinations.
#   T3 (L25): + a directional note-block sound toward the chest.
#   T4 (L50): + a 5s location marker.
#   T5 (L75): + 15s marker + Speed I.
#   T6 (L100): + full-lifetime marker + Speed III (Speed V if already Speed III).

# T1 GATE: only players who have ANY Gearwright level (caffl_gw>=1) sense at all.
execute unless score @s ec.caffl_gw matches 1.. run return 0

# Skip spectators (already filtered by the caller, defensive) + creative-quiet is fine (they still see).

# --- Base sense cue (every tier T1+): actionbar + a soft chime. ---
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.amethyst_block.hit master @s ~ ~ ~ 0.6 1.6
data modify storage evercraft:notify stage.c set value [{text:"⚙ ",color:"#B87333"},{text:"A chest is sensed nearby.",color:"#B87333",italic:true}]
scoreboard players set #ndur ec.temp 50
function evercraft:util/notify/emit

# --- T1-only FOLLOW window (caffl_gw 1..9): open a 15s window in which the player chases a directional
#     chest sound (loot_sense_follow plays it + resolves the window). ~30% of T1 senses are FALSE — a
#     hallucination that fizzles into "…or it was just your imagination." if 15s pass without reaching a
#     chest. The genuine 70% really point at the nearby node (reaching it closes the window early). At
#     L10+ (T2) NO window opens — those senses are genuine notification only. ---
#   ec.gw_lsfol = 30 ten-tick frames (= 15s). ec.gw_lsreal = 1 genuine / 0 hallucination. Tag the
#   player ec.gw_following so the existence-gated loot_sense_follow loop picks them up next frame.
execute if score @s ec.caffl_gw matches 1..9 run scoreboard players set @s ec.gw_lsfol 30
execute if score @s ec.caffl_gw matches 1..9 run scoreboard players set @s ec.gw_lsreal 1
execute if score @s ec.caffl_gw matches 1..9 store result score #ls_fake ec.temp run random value 1..100
execute if score @s ec.caffl_gw matches 1..9 if score #ls_fake ec.temp matches 1..30 run scoreboard players set @s ec.gw_lsreal 0
execute if score @s ec.caffl_gw matches 1..9 run tag @s add ec.gw_following

# --- T3 (L25+): a directional note-block sound played toward the chest. Approximated by playing the
#     note-block AT the node so the positional audio pans toward it for the listener. ---
execute if score @s ec.caffl_gw matches 25.. if score @s ec.fx_snd matches 1.. at @e[type=marker,tag=ec.chest_data,distance=..48,limit=1,sort=nearest] run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.8 1.2

# --- T4 (L50+): a 5s location marker (a glow/particle column at the node). T5 (L75+): 15s + Speed I.
#     T6 (L100+): full-node-lifetime marker + Speed III (V if already III). The marker is a glowing
#     particle beacon driven by a short scheduled pulse; duration scales by tier. ---
execute if score @s ec.caffl_gw matches 50.. run function evercraft:chest_nodes/abilities/loot_sense_mark

# Speed buffs by tier (T5 Speed I, T6 Speed III/V).
execute if score @s ec.caffl_gw matches 75..99 run effect give @s minecraft:speed 15 0 true
execute if score @s ec.caffl_gw matches 100.. unless predicate evercraft:chest_nodes/has_speed3 run effect give @s minecraft:speed 30 2 true
execute if score @s ec.caffl_gw matches 100.. if predicate evercraft:chest_nodes/has_speed3 run effect give @s minecraft:speed 30 4 true
