# === GEARWRIGHT — APPRAISE PREVIEW (A1, L5; PLAN §1 / §14.11) ===
# Run as @s (a sneaking Gearwright L5+), positioned at the node (on_click routed sneak-RC here). Reads
# the nearest chest node's data.ctype (1=Crafting/2=Adventurer/3=plain) + data.rarity (1-6 band) and
# shows a PREVIEW actionbar — WITHOUT opening (no key wear, no harvest, no trap). The +good-outcome
# boost (A1+), player-inspection (A2), hide-from-inspect (A3), and improve-loot (A4) are the OTHER
# Appraise tiers: the boost + trap-disarm are wired in do_open / do_open_success; A2's inspect GUI +
# A3's hide flag live in chest_nodes/inspect/ (entered from the Gearwright codex page, render7/panel).

# Pin the node we appraised (nearest within ~4 blocks).
execute unless entity @e[type=marker,tag=ec.chest_data,distance=..4,limit=1] run return 0
execute store result score #cn_pv_ct ec.temp run data get entity @e[type=marker,tag=ec.chest_data,distance=..4,limit=1,sort=nearest] data.ctype
execute store result score #cn_pv_band ec.temp run data get entity @e[type=marker,tag=ec.chest_data,distance=..4,limit=1,sort=nearest] data.rarity

# A reading-the-mechanism sound.
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.amethyst_block.step master @s ~ ~ ~ 0.7 0.8
execute if score @s ec.fx_vis matches 1.. run particle minecraft:wax_on ~ ~1 ~ 0.3 0.3 0.3 0.02 8

# --- Type line. ---
execute if score #cn_pv_ct ec.temp matches 1 run data modify storage evercraft:notify stage.c set value [{text:"⚙ Appraise: ",color:"#B87333"},{text:"a Crafting chest",color:"aqua"},{text:" — the lock favors a Trial Pass.",color:"gray"}]
execute if score #cn_pv_ct ec.temp matches 2 run data modify storage evercraft:notify stage.c set value [{text:"⚙ Appraise: ",color:"#B87333"},{text:"an Adventurer chest",color:"gold"},{text:" — the lock favors a Dungeon Key.",color:"gray"}]
execute if score #cn_pv_ct ec.temp matches 3 run data modify storage evercraft:notify stage.c set value [{text:"⚙ Appraise: ",color:"#B87333"},{text:"a plain chest",color:"white"},{text:" — no key needed if your craft is keen.",color:"gray"}]
scoreboard players set #ndur ec.temp 60
function evercraft:util/notify/emit

# --- Tier hint (A4 L100 also gets the improve-loot chance; here just the read). ---
execute if score #cn_pv_band ec.temp matches ..2 run tellraw @s [{text:"  ◆ ",color:"#B87333"},{text:"A modest cache.",color:"gray",italic:true}]
execute if score #cn_pv_band ec.temp matches 3 run tellraw @s [{text:"  ◆ ",color:"#B87333"},{text:"A worthwhile cache.",color:"yellow",italic:true}]
execute if score #cn_pv_band ec.temp matches 4.. run tellraw @s [{text:"  ◆ ",color:"#B87333"},{text:"A rich cache — well worth the lock.",color:"gold",italic:true}]
