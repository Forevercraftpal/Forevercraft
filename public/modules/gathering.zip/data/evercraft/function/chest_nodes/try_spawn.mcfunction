# Chest Node: Attempt to spawn a ground node near the player. Run as player, at player position.
# Mirrors fishing/splash_nodes/try_spawn (cap-check -> multi-candidate placement -> timer reset).
# Chest nodes sit on a SOLID ground surface (billboard:fixed item_display), not water.

# --- Cap: skip if too many active chest nodes already within ~48 blocks of the player. ---
# (store result + terminal `if entity` = the match COUNT — the standard count idiom.)
execute store result score #cn_count ec.temp if entity @e[type=marker,tag=ec.chest_data,distance=..48]
execute if score #cn_count ec.temp >= #cn_nearby_cap ec.var run return run function evercraft:chest_nodes/reset_timer

# Stamp this player's dominant key type into spawn-temp storage so place_node weights data.ctype
# (1=Crafting/2=Adventurer/3=plain) by what they carry. key_detect set ec.cn_keytype.
execute store result storage evercraft:cn_temp keytype int 1 run scoreboard players get @s ec.cn_keytype

# --- Multi-candidate placement: try up to 8 nearby ground spots, placing at the first solid
#     surface found. #cn_placed flags success. (Shared scratch set here, consumed by place_attempt.) ---
function evercraft:chest_nodes/place

# Reset the timer for the next cycle (whether or not a node landed — a miss just retries next cycle).
function evercraft:chest_nodes/reset_timer
