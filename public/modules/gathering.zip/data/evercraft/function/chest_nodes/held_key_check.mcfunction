# === CHEST-NODE — HELD-KEY CHECK (detection only, NO wear) ===
# Run as @s. Sets #cn_keyed ec.temp = 1 iff @s HOLDS a FRESH (un-worn) Trial Pass OR Dungeon Key in the
# mainhand OR offhand. Detection ONLY — never marks worn, never breaks (do_open owns the cracked-key
# BREAK; wear is do_open_wave2 / do_open_struct via wear_held_key, and only when a key actually opens).
# SINGLE writer of #cn_keyed = here (do_open / crack/begin / struct gate_player all call this then read).
#
# A "fresh" key matches the type tag but NOT {<type>,worn:1b} (a worn key can't open). Mirrors the
# detection half of do_open's old key block — both key types, both hands, no item modification.

scoreboard players set #cn_keyed ec.temp 0
# Mainhand fresh Trial Pass / Dungeon Key.
execute if items entity @s weapon.mainhand *[custom_data~{trial_pass:1b}] unless items entity @s weapon.mainhand *[custom_data~{trial_pass:1b,worn:1b}] run scoreboard players set #cn_keyed ec.temp 1
execute if items entity @s weapon.mainhand *[custom_data~{dungeon_key:true}] unless items entity @s weapon.mainhand *[custom_data~{dungeon_key:true,worn:1b}] run scoreboard players set #cn_keyed ec.temp 1
# Offhand fresh Trial Pass / Dungeon Key.
execute if items entity @s weapon.offhand *[custom_data~{trial_pass:1b}] unless items entity @s weapon.offhand *[custom_data~{trial_pass:1b,worn:1b}] run scoreboard players set #cn_keyed ec.temp 1
execute if items entity @s weapon.offhand *[custom_data~{dungeon_key:true}] unless items entity @s weapon.offhand *[custom_data~{dungeon_key:true,worn:1b}] run scoreboard players set #cn_keyed ec.temp 1
