# === CHEST-NODE — WEAR THE HELD KEY (degrade exactly ONE fresh key on a grant) ===
# Run as @s. Marks WORN exactly ONE held fresh key — mainhand first, else offhand; Trial Pass before
# Dungeon Key within a hand. Call this ONLY when a key actually grants a wave/open (do_open_wave2 /
# do_open_struct on a real, non-preunlocked open) — never on a fail or a preunlocked struct open.
#
# STACK-SAFE (2026-06-18 fix). Keys STACK: trial_pass / dungeon_key are both minecraft:trial_key with no
# max_stack_size override, so a player can hold several in ONE slot. `item modify entity @s weapon.<slot>
# <modifier>` rewrites the WHOLE stack in that slot, so the old "mark the slot worn" wore EVERY key the
# player held in that hand at once. A stack is homogeneous (fresh and worn keys differ in components, so
# they can't share a stack), so the picked slot is a pure stack of FRESH keys. We now degrade exactly
# ONE, mirroring the trial-start lifecycle (craftforever/trials/consume_key):
#   • SINGLE held key (count 1) -> mark it worn IN PLACE (it stays in the hand, old behavior).
#   • STACK (count >= 2) -> PEEL one off (items/decrement_stack) + re-mint ONE byte-identical WORN copy
#     into the inventory (inv-full-safe), leaving the rest of the held stack FRESH.
#
# #cn_wore latches the winning (slot,type) so only one key is ever degraded per call (a key in EACH hand
# loses only one). A fresh key = the type tag but NOT {<type>,worn:1b}.

# ---------- Pick the winning slot (#cn_wslot 1=mainhand 2=offhand) + type (#cn_wtype 1=trial 2=dungeon),
#            mainhand-first, Trial Pass before Dungeon Key, latched by #cn_wore. ----------
scoreboard players set #cn_wore ec.temp 0
scoreboard players set #cn_wslot ec.temp 0
scoreboard players set #cn_wtype ec.temp 0
# Mainhand fresh Trial Pass.
execute if score #cn_wore ec.temp matches 0 if items entity @s weapon.mainhand *[custom_data~{trial_pass:1b}] unless items entity @s weapon.mainhand *[custom_data~{trial_pass:1b,worn:1b}] run scoreboard players set #cn_wslot ec.temp 1
execute if score #cn_wore ec.temp matches 0 if items entity @s weapon.mainhand *[custom_data~{trial_pass:1b}] unless items entity @s weapon.mainhand *[custom_data~{trial_pass:1b,worn:1b}] run scoreboard players set #cn_wtype ec.temp 1
execute if score #cn_wore ec.temp matches 0 if items entity @s weapon.mainhand *[custom_data~{trial_pass:1b}] unless items entity @s weapon.mainhand *[custom_data~{trial_pass:1b,worn:1b}] run scoreboard players set #cn_wore ec.temp 1
# Mainhand fresh Dungeon Key (only if a Trial Pass didn't already claim the wear).
execute if score #cn_wore ec.temp matches 0 if items entity @s weapon.mainhand *[custom_data~{dungeon_key:true}] unless items entity @s weapon.mainhand *[custom_data~{dungeon_key:true,worn:1b}] run scoreboard players set #cn_wslot ec.temp 1
execute if score #cn_wore ec.temp matches 0 if items entity @s weapon.mainhand *[custom_data~{dungeon_key:true}] unless items entity @s weapon.mainhand *[custom_data~{dungeon_key:true,worn:1b}] run scoreboard players set #cn_wtype ec.temp 2
execute if score #cn_wore ec.temp matches 0 if items entity @s weapon.mainhand *[custom_data~{dungeon_key:true}] unless items entity @s weapon.mainhand *[custom_data~{dungeon_key:true,worn:1b}] run scoreboard players set #cn_wore ec.temp 1
# Offhand fresh Trial Pass (only when the mainhand supplied no key).
execute if score #cn_wore ec.temp matches 0 if items entity @s weapon.offhand *[custom_data~{trial_pass:1b}] unless items entity @s weapon.offhand *[custom_data~{trial_pass:1b,worn:1b}] run scoreboard players set #cn_wslot ec.temp 2
execute if score #cn_wore ec.temp matches 0 if items entity @s weapon.offhand *[custom_data~{trial_pass:1b}] unless items entity @s weapon.offhand *[custom_data~{trial_pass:1b,worn:1b}] run scoreboard players set #cn_wtype ec.temp 1
execute if score #cn_wore ec.temp matches 0 if items entity @s weapon.offhand *[custom_data~{trial_pass:1b}] unless items entity @s weapon.offhand *[custom_data~{trial_pass:1b,worn:1b}] run scoreboard players set #cn_wore ec.temp 1
# Offhand fresh Dungeon Key (only when neither mainhand nor offhand-trial supplied one).
execute if score #cn_wore ec.temp matches 0 if items entity @s weapon.offhand *[custom_data~{dungeon_key:true}] unless items entity @s weapon.offhand *[custom_data~{dungeon_key:true,worn:1b}] run scoreboard players set #cn_wslot ec.temp 2
execute if score #cn_wore ec.temp matches 0 if items entity @s weapon.offhand *[custom_data~{dungeon_key:true}] unless items entity @s weapon.offhand *[custom_data~{dungeon_key:true,worn:1b}] run scoreboard players set #cn_wtype ec.temp 2
execute if score #cn_wore ec.temp matches 0 if items entity @s weapon.offhand *[custom_data~{dungeon_key:true}] unless items entity @s weapon.offhand *[custom_data~{dungeon_key:true,worn:1b}] run scoreboard players set #cn_wore ec.temp 1

# No fresh key found (a despawn/swap raced the grant) -> nothing to wear.
execute if score #cn_wore ec.temp matches 0 run return 0

# ---------- Read the winning slot's stack count (default 1 = treat as a single key). ----------
scoreboard players set #cn_wcount ec.temp 1
execute if score #cn_wslot ec.temp matches 1 store result score #cn_wcount ec.temp run data get entity @s SelectedItem.count
execute if score #cn_wslot ec.temp matches 2 store result score #cn_wcount ec.temp run data get entity @s Inventory[{Slot:-106b}].count

# ---------- SINGLE key (count <= 1): mark it worn IN PLACE — it stays in the hand (old behavior). ----------
execute if score #cn_wcount ec.temp matches ..1 if score #cn_wslot ec.temp matches 1 run item modify entity @s weapon.mainhand evercraft:chest_nodes/mark_worn
execute if score #cn_wcount ec.temp matches ..1 if score #cn_wslot ec.temp matches 2 run item modify entity @s weapon.offhand evercraft:chest_nodes/mark_worn
execute if score #cn_wcount ec.temp matches ..1 run return 0

# ---------- STACK (count >= 2): peel ONE fresh key off, re-mint it WORN (rest stay fresh, in hand). ----------
execute if score #cn_wslot ec.temp matches 1 run item modify entity @s weapon.mainhand evercraft:items/decrement_stack
execute if score #cn_wslot ec.temp matches 2 run item modify entity @s weapon.offhand evercraft:items/decrement_stack
# Re-mint exactly ONE byte-identical WORN copy of the worn type (inv-full-safe: drop at feet if full).
execute store result score #inv_full ec.var run function evercraft:util/check_inv_full
execute if score #cn_wtype ec.temp matches 1 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:craftforever/trials/trial_pass_worn
execute if score #cn_wtype ec.temp matches 1 if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:craftforever/trials/trial_pass_worn
execute if score #cn_wtype ec.temp matches 2 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:dungeon/key_worn
execute if score #cn_wtype ec.temp matches 2 if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:dungeon/key_worn
