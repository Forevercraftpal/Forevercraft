# === CHEST-NODE — DO_OPEN (per-player open dispatch, §2 rework 2026-06-05) ===
# Run as the opening player, positioned AT THE NODE (crack/finish ran `execute at <marker> run`). Pins
# the clicked node, then routes the open through the PER-PLAYER model — two INDEPENDENT overworld tracks
# (hands = wave 1, key = wave 2) plus a single per-player struct key-open. Per-player claim state lives
# on the marker as UUID int-array lists: the 3-fail ladder (w1_t1 -> w1_t2 -> w1_locked) + w1_claimed /
# w2_claimed / opened_by. All per-(player,chest) on the node — interleave-proof, no player-side streak.
#
# ORDER:
#   HEAD  coord-pin the clicked node into gth_temp; bail if no node within reach.
#   PREP  claim/prep -> storage cn_claim {x,y,z,u0..u3} (the shared claim macro payload).
#   STRUCT a struct_bound node routes to do_open_struct (key already verified by gate_player).
#   (1)   5% trap-on-attempt -> traps/dispatch (fires regardless of open outcome). KEEP.
#   KEY   cracked-held-key BREAK (a worn+cracked held key shatters on attempt). KEEP.
#         held_key_check -> #cn_keyed (detection only, NO wear here).
#   DISPATCH
#     #cn_keyed=1 (held key) -> wave 2 once per player (else "already claimed the key vault").
#     #cn_keyed=0 (hands)    -> wave 1: gate on w1_claimed / w1_locked, else roll keyless_gate;
#                              pass -> wave 1; fail -> bump the 0..3 hand streak, lock at 3.
# The node NEVER despawns from opening — the 7-min timer (tick_despawn) is the only despawn. No charges.

# ---------- HEAD: coord-pin the clicked node (nearest chest marker within ~4 blocks). ----------
# Read its data into gth_temp so the engine + loot resolver operate on THIS exact node.
data modify storage evercraft:gth_temp dtag set value "ec.chest_data"
execute store result storage evercraft:gth_temp x int 1 run data get entity @e[type=marker,tag=ec.chest_data,distance=..4,limit=1,sort=nearest] Pos[0]
execute store result storage evercraft:gth_temp y int 1 run data get entity @e[type=marker,tag=ec.chest_data,distance=..4,limit=1,sort=nearest] Pos[1]
execute store result storage evercraft:gth_temp z int 1 run data get entity @e[type=marker,tag=ec.chest_data,distance=..4,limit=1,sort=nearest] Pos[2]
# Stash the node's ctype (1=Crafting/2=Adventurer/3=plain) for the loot resolver (survives resolve()).
data modify storage evercraft:gth_temp ctype set value 3
execute store result storage evercraft:gth_temp ctype int 1 run data get entity @e[type=marker,tag=ec.chest_data,distance=..4,limit=1,sort=nearest] data.ctype

# No node within reach (a despawn raced the click) -> nothing to open.
execute unless entity @e[type=marker,tag=ec.chest_data,distance=..4,limit=1] run return 0

# ---------- PREP: build the per-player claim macro payload (coords + @s UUID ints). ----------
# Every claim/has + claim/add macro below reads storage cn_claim; populate it ONCE here (after the pin).
function evercraft:chest_nodes/claim/prep

# ---------- STRUCT detection: classify the node now; the struct ROUTE is deferred past the trap below ----------
# so STRUCTURE chests still spring the 5% trap-on-attempt like overworld (Joseph 2026-06-05). The key /
# preunlock + the once-per-player opened_by were already validated by struct/gate_player; #cn_preun
# (1 = preunlocked) carries to do_open_struct. Set the classification flags here, route after the trap.
scoreboard players set #cn_structb ec.temp 0
execute if data entity @e[type=marker,tag=ec.chest_data,distance=..4,limit=1,sort=nearest] {data:{struct_bound:1b}} run scoreboard players set #cn_structb ec.temp 1
scoreboard players set #cn_preun ec.temp 0
execute if data entity @e[type=marker,tag=ec.chest_data,distance=..4,limit=1,sort=nearest] {data:{preunlocked:1b}} run scoreboard players set #cn_preun ec.temp 1

# ---------- (1) 5% TRAP-ON-ATTEMPT (any open attempt, §7). Fires regardless of open success. ----------
# Appraise A3 (Gearwright L50) disarms 50% of traps; A4 (L100) disarms ALL traps. The dispatcher
# itself applies the no-kill _hp_gate; here we just roll the 5% and the Appraise disarm gate.
execute store result score #cn_traproll ec.temp run random value 1..100
scoreboard players set #cn_trap ec.temp 0
execute if score #cn_traproll ec.temp matches 1..5 run scoreboard players set #cn_trap ec.temp 1
# Appraise A4 (L100): disarm ALL traps at every harvest.
execute if score @s ec.caffl_gw matches 100.. run scoreboard players set #cn_trap ec.temp 0
# Appraise A3 (L50-99): disarm 50% of traps (re-roll; on <=50 the trap is disarmed).
execute if score @s ec.caffl_gw matches 50..99 if score #cn_trap ec.temp matches 1 store result score #cn_dis ec.temp run random value 1..100
execute if score @s ec.caffl_gw matches 50..99 if score #cn_trap ec.temp matches 1 if score #cn_dis ec.temp matches 1..50 run scoreboard players set #cn_trap ec.temp 0
execute if score #cn_trap ec.temp matches 1 run function evercraft:chest_nodes/traps/dispatch

# ---------- STRUCT route (deferred to here so the 5% trap above fires for struct chests too). ----------
# A struct_bound node is per-player key-only — run the struct open now that the shared trap has rolled.
execute if score #cn_structb ec.temp matches 1 run return run function evercraft:chest_nodes/do_open_struct

# ---------- KEY: cracked-held-key BREAK (§3), then held-key DETECTION (NO wear here). ----------
# BREAK rule (§3): a held key that is ALREADY cracked breaks NOW rather than being used — do_open is the
# BREAK setter. STACK-SAFE (2026-06-18): keys stack, so `items/decrement_stack` shatters exactly ONE
# cracked key from the held slot (count 1 -> slot empties, same as the old `replace with air`; count >= 2
# -> one shatters, the rest stay) instead of nuking the whole held stack at once. A small "snap" cue
# sells the break. A broken key no longer matches the fresh checks in held_key_check -> the player falls
# to the hands track (correct).
scoreboard players set #cn_broke ec.temp 0
execute if items entity @s weapon.mainhand *[custom_data~{cracked:1b}] unless items entity @s weapon.mainhand *[custom_data~{worn:1b}] if items entity @s weapon.mainhand minecraft:trial_key run scoreboard players set #cn_broke ec.temp 1
execute if score #cn_broke ec.temp matches 1 run item modify entity @s weapon.mainhand evercraft:items/decrement_stack
execute if score #cn_broke ec.temp matches 0 if items entity @s weapon.offhand *[custom_data~{cracked:1b}] unless items entity @s weapon.offhand *[custom_data~{worn:1b}] if items entity @s weapon.offhand minecraft:trial_key run scoreboard players set #cn_broke ec.temp 1
execute if score #cn_broke ec.temp matches 1 if items entity @s weapon.offhand *[custom_data~{cracked:1b}] unless items entity @s weapon.offhand *[custom_data~{worn:1b}] run item modify entity @s weapon.offhand evercraft:items/decrement_stack
execute if score #cn_broke ec.temp matches 1 if score @s ec.fx_snd matches 1.. run playsound minecraft:block.glass.break master @s ~ ~ ~ 0.8 0.9
execute if score #cn_broke ec.temp matches 1 run data modify storage evercraft:notify stage.c set value [{text:"⚙ ",color:"#B87333"},{text:"The key shattered",color:"red"},{text:" — worn and cracked, it gave its last turn.",color:"gray"}]
execute if score #cn_broke ec.temp matches 1 run scoreboard players set #ndur ec.temp 45
execute if score #cn_broke ec.temp matches 1 run function evercraft:util/notify/emit

# Held-key detection (NO wear): #cn_keyed=1 iff a FRESH key is held in either hand. Wear happens ONLY
# inside do_open_wave2 / do_open_struct, exactly when a key grants a wave/open.
function evercraft:chest_nodes/held_key_check

# ================================ DISPATCH ================================
# ---------- KEYED -> WAVE 2 (richer), once per player. ----------
execute if score #cn_keyed ec.temp matches 1 run function evercraft:chest_nodes/dispatch_keyed
execute if score #cn_keyed ec.temp matches 1 run return 0

# ---------- HANDS -> WAVE 1 (gate on prior claim / lock, else roll the keyless gate). ----------
function evercraft:chest_nodes/dispatch_hands
