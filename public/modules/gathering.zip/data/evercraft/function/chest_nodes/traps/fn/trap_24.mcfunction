# STING — "Lifting Draft" : an updraft floats you up — then gently sets you down. Brief Levitation I,
# ALWAYS paired with Slow Falling so the descent is survivable (no fall damage). _hp_gate floors to
# cosmetic at/below 3 hearts (no lift at all) so the trap can never combine with a fall.
function evercraft:chest_nodes/traps/_hp_gate
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.phantom.flap master @s ~ ~ ~ 1.0 1.2
execute if score @s ec.fx_vis matches 1.. run particle minecraft:cloud ~ ~0.5 ~ 0.4 0.2 0.4 0.05 24
# Harmful branch: a SHORT, gentle lift + a LONGER slow-fall chaser so the player always drifts down safe.
execute if score #cn_safe ec.temp matches 1 run effect give @s minecraft:levitation 3 0 true
execute if score #cn_safe ec.temp matches 1 run effect give @s minecraft:slow_falling 12 0 true
execute if score #cn_safe ec.temp matches 0 if score @s ec.fx_vis matches 1.. run particle minecraft:gust ~ ~1 ~ 0.3 0.4 0.3 0.05 6
data modify storage evercraft:notify stage.c set value [{text:"⚙ ",color:"#B87333"},{text:"A lifting draft",color:"aqua"},{text:" — the cache breathed you skyward, then let you drift.",color:"gray"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
