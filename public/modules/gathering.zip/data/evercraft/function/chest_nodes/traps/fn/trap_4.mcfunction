# PRANK — "Jack-in-the-Box" : a comedic boing + a harmless armor-stand "puppet" that vanishes.
# Guardrail: the puppet is no-loot, persistent-tagged, killed on its own next tick; no damage to player.
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.banjo master @s ~ ~ ~ 1.0 0.6
execute if score @s ec.fx_vis matches 1.. run particle minecraft:note ~ ~1.5 ~ 0.3 0.3 0.3 1 12
summon armor_stand ~ ~ ~ {Tags:["ec.cn_trap_puppet"],Marker:1b,Invisible:1b,NoGravity:1b,PersistenceRequired:1b}
schedule function evercraft:chest_nodes/traps/fn/cleanup_puppet 30t replace
data modify storage evercraft:notify stage.c set value [{text:"⚙ ",color:"#B87333"},{text:"Jack-in-the-box!",color:"yellow"},{text:" — the lid sprang open at you.",color:"gray"}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit
