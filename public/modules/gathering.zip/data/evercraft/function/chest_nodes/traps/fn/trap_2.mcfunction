# PRANK — "Glitter Bomb" : a harmless burst of glittering dust. Cosmetic only.
# Guardrail: particle + sound only, zero effect/damage.
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.firework_rocket.blast master @s ~ ~ ~ 0.6 1.6
execute if score @s ec.fx_vis matches 1.. run particle minecraft:totem_of_undying ~ ~1 ~ 0.4 0.6 0.4 0.1 40
execute if score @s ec.fx_vis matches 1.. run particle minecraft:end_rod ~ ~1 ~ 0.3 0.4 0.3 0.02 18
data modify storage evercraft:notify stage.c set value [{text:"⚙ ",color:"#B87333"},{text:"A glitter bomb",color:"light_purple"},{text:" — you are now extremely sparkly.",color:"gray"}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit
