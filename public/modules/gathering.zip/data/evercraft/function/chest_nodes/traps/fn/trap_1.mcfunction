# PRANK — "The Snap" : a startling tripwire snap + smoke poof. Pure cosmetic, no damage.
# Guardrail: no effect/damage at all — sound + particle only. Always safe at any health.
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.tripwire.click_on master @s ~ ~ ~ 0.9 1.2
execute if score @s ec.fx_vis matches 1.. run particle minecraft:smoke ~ ~1 ~ 0.3 0.5 0.3 0.02 14
execute if score @s ec.fx_vis matches 1.. run particle minecraft:crit ~ ~1 ~ 0.3 0.5 0.3 0.05 10
data modify storage evercraft:notify stage.c set value [{text:"⚙ ",color:"#B87333"},{text:"A trap snapped shut",color:"red"},{text:" — but it was only a startle.",color:"gray"}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit
