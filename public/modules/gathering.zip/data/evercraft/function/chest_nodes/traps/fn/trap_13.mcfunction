# PRANK — "Cobweb Veil" : sticky old cobwebs drape over you — a brief slow crawl. Cosmetic + tiny slow.
# Guardrail: Slowness I for 2s is the SOFTEST movement nudge (no health cost). No _hp_gate needed.
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.wool.place master @s ~ ~ ~ 1.0 0.7
execute if score @s ec.fx_vis matches 1.. run particle minecraft:item_cobweb ~ ~1 ~ 0.4 0.6 0.4 0.05 18
effect give @s minecraft:slowness 2 0 true
data modify storage evercraft:notify stage.c set value [{text:"⚙ ",color:"#B87333"},{text:"A cobweb veil",color:"gray"},{text:" — ancient webs cling to your boots.",color:"gray"}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit
