# PRANK — "Bubble Burst" : a fizzing geyser of bubbles. Cosmetic only.
# Guardrail: particle + sound only, zero effect/damage.
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.player.splash master @s ~ ~ ~ 1.0 1.3
execute if score @s ec.fx_vis matches 1.. run particle minecraft:bubble_pop ~ ~1 ~ 0.4 0.6 0.4 0.1 40
execute if score @s ec.fx_vis matches 1.. run particle minecraft:splash ~ ~1 ~ 0.4 0.4 0.4 0.1 24
data modify storage evercraft:notify stage.c set value [{text:"⚙ ",color:"#B87333"},{text:"A bubble burst",color:"aqua"},{text:" — the cache foamed over like shaken cider.",color:"gray"}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit
