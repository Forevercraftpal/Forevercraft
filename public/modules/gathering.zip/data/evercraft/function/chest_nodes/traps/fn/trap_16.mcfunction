# PRANK — "Dust Devil" : a swirling cloud of dust spins around you. Cosmetic; a brief Speed nudge (no harm).
# Guardrail: Speed I is a BENEFICIAL nudge (the "prank" is the dizzy spin); zero health cost.
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.horse.gallop master @s ~ ~ ~ 0.7 1.4
execute if score @s ec.fx_vis matches 1.. run particle minecraft:gust ~ ~1 ~ 0.4 0.6 0.4 0.05 8
execute if score @s ec.fx_vis matches 1.. run particle minecraft:sweep_attack ~ ~1 ~ 0.5 0.5 0.5 0 4
effect give @s minecraft:speed 4 0 true
data modify storage evercraft:notify stage.c set value [{text:"⚙ ",color:"#B87333"},{text:"A dust devil",color:"gray"},{text:" — it spun you up and shoved you along.",color:"gray"}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit
