# PRANK — "Creeper Hiss" : the dreaded hiss... then nothing. Pure fake-out, no explosion, no damage.
# Guardrail: sound + particle only; explicitly NO explosion (the joke is that nothing happens).
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.creeper.primed master @s ~ ~ ~ 1.0 1.0
execute if score @s ec.fx_vis matches 1.. run particle minecraft:smoke ~ ~0.5 ~ 0.3 0.3 0.3 0.01 10
data modify storage evercraft:notify stage.c set value [{text:"⚙ ",color:"#B87333"},{text:"A creeper hiss",color:"green"},{text:" — you flinched... but it was only a recording.",color:"gray"}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit
