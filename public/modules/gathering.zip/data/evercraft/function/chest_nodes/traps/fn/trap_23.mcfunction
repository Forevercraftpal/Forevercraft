# STING — "Tar Pit" : a gush of sticky tar roots your boots. Strong but brief Slowness III (no health
# cost) — _hp_gate floors to cosmetic at/below 3 hearts for consistency.
function evercraft:chest_nodes/traps/_hp_gate
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.honey_block.place master @s ~ ~ ~ 1.0 0.6
execute if score @s ec.fx_vis matches 1.. run particle minecraft:dripping_obsidian_tear ~ ~0.5 ~ 0.4 0.2 0.4 0.05 20
execute if score #cn_safe ec.temp matches 1 run effect give @s minecraft:slowness 6 2 true
execute if score #cn_safe ec.temp matches 0 if score @s ec.fx_vis matches 1.. run particle minecraft:smoke ~ ~0.5 ~ 0.3 0.2 0.3 0.02 10
data modify storage evercraft:notify stage.c set value [{text:"⚙ ",color:"#B87333"},{text:"A tar pit",color:"dark_gray"},{text:" — black pitch welled up around your boots.",color:"gray"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
