# STING — "Venom Needle" : a quick pin-prick of weak venom. Brief Poison I (cannot kill: vanilla poison
# floors at 1 HP) AND _hp_gate-floored so a low-health player only gets the cosmetic hiss.
function evercraft:chest_nodes/traps/_hp_gate
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.sweet_berry_bush.pick master @s ~ ~ ~ 1.0 1.2
execute if score @s ec.fx_vis matches 1.. run particle minecraft:entity_effect{color:-12793796} ~ ~1 ~ 0.3 0.5 0.3 0.05 14
# Harmful branch (above 3 hearts): a short Poison I. Cosmetic branch (at/below): just a green puff.
execute if score #cn_safe ec.temp matches 1 run effect give @s minecraft:poison 4 0 true
execute if score #cn_safe ec.temp matches 0 if score @s ec.fx_vis matches 1.. run particle minecraft:composter ~ ~1 ~ 0.3 0.4 0.3 0.05 10
data modify storage evercraft:notify stage.c set value [{text:"⚙ ",color:"#B87333"},{text:"A venom needle",color:"dark_green"},{text:" — the latch nicked you with old poison.",color:"gray"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
