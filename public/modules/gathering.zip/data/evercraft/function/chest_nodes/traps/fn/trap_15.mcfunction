# PRANK — "Mocking Echo" : a chorus of villager "hrmphs" laughing at you. Cosmetic only.
# Guardrail: sound + particle only.
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.villager.no master @s ~ ~ ~ 1.0 0.8
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.villager.no master @s ~ ~ ~ 0.9 1.2
execute if score @s ec.fx_vis matches 1.. run particle minecraft:angry_villager ~ ~2 ~ 0.4 0.4 0.4 0.5 10
data modify storage evercraft:notify stage.c set value [{text:"⚙ ",color:"#B87333"},{text:"A mocking echo",color:"red"},{text:" — the cache seems to be laughing at you.",color:"gray"}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit
