# PRANK — "Dizzy Spell" : a swirl of enchant glyphs + a brief wobble. Cosmetic; brief nausea (no harm).
# Guardrail: nausea is a screen effect with NO health cost. No _hp_gate needed.
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.enchantment_table.use master @s ~ ~ ~ 1.0 0.7
execute if score @s ec.fx_vis matches 1.. run particle minecraft:enchant ~ ~2 ~ 0.5 1 0.5 1 40
effect give @s minecraft:nausea 5 0 true
data modify storage evercraft:notify stage.c set value [{text:"⚙ ",color:"#B87333"},{text:"A dizzy spell",color:"light_purple"},{text:" — the runes on the lid spun your head.",color:"gray"}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit
