# PRANK — "Confetti Spring" : a festive pop of colored confetti. Cosmetic only.
# Guardrail: particle + sound only, zero effect/damage.
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.firework_rocket.twinkle master @s ~ ~ ~ 0.8 1.4
execute if score @s ec.fx_vis matches 1.. run particle minecraft:firework ~ ~1.5 ~ 0.5 0.5 0.5 0.2 50
execute if score @s ec.fx_vis matches 1.. run particle minecraft:happy_villager ~ ~1 ~ 0.4 0.5 0.4 0.5 16
data modify storage evercraft:notify stage.c set value [{text:"⚙ ",color:"#B87333"},{text:"Confetti!",color:"aqua"},{text:" — the cache celebrates being opened.",color:"gray"}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit
