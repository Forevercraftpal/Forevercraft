# === CHEST-NODE TRAPS — MACRO ROUTER ===
# Run as @s with storage evercraft:gth_temp {trap_id:<1..35>}. _table resolved the id and stored it;
# this macro $function-routes to the chosen trap body. Split out so _table stays a plain (non-$) file.
$function evercraft:chest_nodes/traps/fn/trap_$(trap_id)
