# STING — "Bat Flurry" : a cloud of harmless bats explodes out, startling you. The bats deal no damage
# at all (passive) — the "sting" is the brief Nausea + Darkness disorientation. No _hp_gate needed for the
# bats; we still call it so the disorient downgrades cleanly for parity with the band.
function evercraft:chest_nodes/traps/_hp_gate
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.bat.takeoff master @s ~ ~ ~ 1.0 1.0
execute if score @s ec.fx_vis matches 1.. run particle minecraft:smoke ~ ~1 ~ 0.4 0.5 0.4 0.05 18
summon bat ~ ~1 ~ {Tags:["ec.cn_trap_mob"],PersistenceRequired:1b,DeathLootTable:"minecraft:empty"}
summon bat ~1 ~1 ~ {Tags:["ec.cn_trap_mob"],PersistenceRequired:1b,DeathLootTable:"minecraft:empty"}
effect give @s minecraft:nausea 4 0 true
execute if score #cn_safe ec.temp matches 1 run effect give @s minecraft:darkness 3 0 true
data modify storage evercraft:notify stage.c set value [{text:"⚙ ",color:"#B87333"},{text:"A bat flurry",color:"dark_gray"},{text:" — they burst past your face in a black cloud.",color:"gray"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
