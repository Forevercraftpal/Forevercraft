# NASTY — "Withering Curse" : a creeping necrotic curse. Sustained Wither I + Weakness II. Vanilla wither,
# like poison, NEVER kills (it floors at 1 HP), and _hp_gate downgrades the whole curse to a cosmetic
# shadow-wisp at/below 3 hearts. Real bite for a healthy player, mathematically non-lethal.
function evercraft:chest_nodes/traps/_hp_gate
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.wither.shoot master @s ~ ~ ~ 0.8 0.6
execute if score @s ec.fx_vis matches 1.. run particle minecraft:soul ~ ~1 ~ 0.4 0.6 0.4 0.05 24
execute if score @s ec.fx_vis matches 1.. run particle minecraft:smoke ~ ~1 ~ 0.4 0.5 0.4 0.02 18
execute if score #cn_safe ec.temp matches 1 run effect give @s minecraft:wither 6 0 true
execute if score #cn_safe ec.temp matches 1 run effect give @s minecraft:weakness 12 1 true
execute if score #cn_safe ec.temp matches 0 if score @s ec.fx_vis matches 1.. run particle minecraft:ash ~ ~1 ~ 0.3 0.4 0.3 0.02 14
data modify storage evercraft:notify stage.c set value [{text:"⚙ ",color:"#B87333"},{text:"A withering curse!",color:"dark_gray"},{text:" — cold rot seeped from the lock into your bones.",color:"gray"}]
scoreboard players set #ndur ec.temp 50
function evercraft:util/notify/emit
