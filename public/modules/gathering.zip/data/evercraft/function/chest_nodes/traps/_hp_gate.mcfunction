# === CHEST-NODE TRAPS — UNIVERSAL NO-KILL GUARD (§7 / §14) ===
# Run as @s (the trapped player). THE single safety primitive every harmful trap calls before it bites.
# Reads Health x100 (the engine idiom: `data get ... Health 100`) into #cn_hp, then sets #cn_safe:
#   #cn_safe = 1  -> the player is ABOVE 3 hearts (>600 = >6.00 HP) -> the harmful branch may fire.
#   #cn_safe = 0  -> the player is AT/BELOW 3 hearts -> the trap MUST downgrade to its cosmetic branch
#                    (sound + particle only). This makes EVERY trap mathematically incapable of a kill:
#                    the worst harmful effect can never start below the 3-heart floor, and the effects
#                    chosen below are all bounded well under 6 HP of damage over their (short) duration.
# Poison / wither (which tick toward but never past 1 HP in vanilla) STILL pass through this floor so a
# low-health player only ever gets the cosmetic version. No banned damage types are used anywhere.
scoreboard players set #cn_safe ec.temp 0
execute store result score #cn_hp ec.temp run data get entity @s Health 100
execute if score #cn_hp ec.temp matches 601.. run scoreboard players set #cn_safe ec.temp 1
