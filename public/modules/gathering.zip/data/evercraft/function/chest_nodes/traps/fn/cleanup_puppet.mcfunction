# Trap helper — remove the harmless Jack-in-the-box puppet armor stands (trap_4). Existence-gated.
execute if entity @e[type=armor_stand,tag=ec.cn_trap_puppet,limit=1] run kill @e[type=armor_stand,tag=ec.cn_trap_puppet]
