# NASTY — "Plague Vapor" : a thick burst of plague gas. Sustained Poison II + Hunger II + Nausea — a real
# cost, but vanilla poison NEVER kills (floors at 1 HP) and _hp_gate downgrades the whole thing to a
# cosmetic cough at/below 3 hearts. So it can hurt a healthy player meaningfully yet never be lethal.
function evercraft:chest_nodes/traps/_hp_gate
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.zombie.infect master @s ~ ~ ~ 1.0 0.7
execute if score @s ec.fx_vis matches 1.. run particle minecraft:sneeze ~ ~1 ~ 0.5 0.6 0.5 0.1 30
execute if score @s ec.fx_vis matches 1.. run particle minecraft:entity_effect{color:-8216536} ~ ~1 ~ 0.4 0.5 0.4 0.05 20
execute if score #cn_safe ec.temp matches 1 run effect give @s minecraft:poison 8 1 true
execute if score #cn_safe ec.temp matches 1 run effect give @s minecraft:hunger 12 1 true
effect give @s minecraft:nausea 8 0 true
execute if score #cn_safe ec.temp matches 0 if score @s ec.fx_vis matches 1.. run particle minecraft:smoke ~ ~1 ~ 0.3 0.4 0.3 0.02 12
data modify storage evercraft:notify stage.c set value [{text:"⚙ ",color:"#B87333"},{text:"Plague vapor!",color:"dark_green"},{text:" — a sickly cloud roiled out of the cache.",color:"gray"}]
scoreboard players set #ndur ec.temp 50
function evercraft:util/notify/emit
