# NASTY — "The Warden's Snare" (the single NASTIEST trap, weight 8/1000) : the full ordeal — a deep
# sculk shriek, a sustained Poison II + Slowness II + Mining Fatigue II + Darkness, a ground-safe scatter
# (spreadplayers + slow_falling), AND a lone weak no-loot ambush. It is the harshest open in the game,
# yet EVERY piece is non-lethal: poison floors at 1 HP, all else is debuff/cosmetic, and _hp_gate
# downgrades the ENTIRE thing to a single ominous shriek at/below 3 hearts (no damage, no mob, no
# teleport). Trap-Ward (Gearwright L68) re-rolls this whole band down to a mild Sting before it ever fires.
function evercraft:chest_nodes/traps/_hp_gate
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.warden.sonic_boom master @s ~ ~ ~ 1.0 0.7
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.sculk_shrieker.shriek master @s ~ ~ ~ 1.0 0.8
execute if score @s ec.fx_vis matches 1.. run particle minecraft:sculk_soul ~ ~1 ~ 0.5 0.8 0.5 0.05 40
execute if score @s ec.fx_vis matches 1.. run particle minecraft:sonic_boom ~ ~1 ~ 0 0 0 0 1
# Cosmetic-only at/below 3 hearts: just the shriek above — return before any harm.
execute if score #cn_safe ec.temp matches 0 run function evercraft:chest_nodes/traps/fn/trap_35_cosmetic
execute if score #cn_safe ec.temp matches 0 run return 0
# Harmful branch (healthy player): the layered ordeal, all non-lethal.
effect give @s minecraft:poison 8 1 true
effect give @s minecraft:slowness 8 1 true
effect give @s minecraft:mining_fatigue 10 1 true
effect give @s minecraft:darkness 6 0 true
# Slow-fall BEFORE the scatter so any drop from the (ground-safe) landing is harmless.
effect give @s minecraft:slow_falling 12 0 true
execute at @s run spreadplayers ~ ~ 5 9 false @s
# One lone weak no-loot defender (low health) — beatable, cleaned up by the trap-mob sweep.
execute positioned ~2 ~ ~ run summon husk ~ ~ ~ {Tags:["ec.cn_trap_mob"],PersistenceRequired:1b,DeathLootTable:"minecraft:empty",Health:12.0f,Attributes:[{id:"minecraft:max_health",base:12.0d}],CanPickUpLoot:0b}
data modify storage evercraft:notify stage.c set value [{text:"⚙ ",color:"#B87333"},{text:"The Warden's Snare!",color:"dark_aqua"},{text:" — the deep itself woke to guard this hoard. Flee!",color:"gray"}]
scoreboard players set #ndur ec.temp 55
function evercraft:util/notify/emit
