# STING — "Itching Powder" : a faceful of itching powder. Brief Nausea + Blindness + a single light
# Poison I tick (poison floors at 1 HP). _hp_gate floors the poison out at/below 3 hearts.
function evercraft:chest_nodes/traps/_hp_gate
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.cat.hiss master @s ~ ~ ~ 1.0 0.8
execute if score @s ec.fx_vis matches 1.. run particle minecraft:effect ~ ~1 ~ 0.4 0.5 0.4 0.05 18
effect give @s minecraft:nausea 4 0 true
effect give @s minecraft:blindness 2 0 true
execute if score #cn_safe ec.temp matches 1 run effect give @s minecraft:poison 3 0 true
data modify storage evercraft:notify stage.c set value [{text:"⚙ ",color:"#B87333"},{text:"Itching powder",color:"green"},{text:" — a faceful of the stuff, and now you itch all over.",color:"gray"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
