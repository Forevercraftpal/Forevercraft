# Trap 35 cosmetic downgrade (fired by _hp_gate when the player is at/below 3 hearts). The ominous shriek
# already played in trap_35; here we only add the actionbar flavor so a low-health player is warned, not
# harmed. NO damage, NO mob, NO teleport.
execute if score @s ec.fx_vis matches 1.. run particle minecraft:sculk_charge_pop ~ ~1 ~ 0.3 0.4 0.3 0.02 12
data modify storage evercraft:notify stage.c set value [{text:"⚙ ",color:"#B87333"},{text:"Something deep stirred",color:"dark_aqua"},{text:" — but, weak as you are, it let you be.",color:"gray"}]
scoreboard players set #ndur ec.temp 50
function evercraft:util/notify/emit
