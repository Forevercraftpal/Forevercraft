# NASTY — "Guardian Husk" : a single weak, no-loot husk claws up to defend the cache. It hits harder than
# the Sting mobs but is alone and beatable. _hp_gate gates the spawn so a low-health player only gets the
# ground-rumble cosmetic (no mob) — the husk can never deliver a killing blow.
function evercraft:chest_nodes/traps/_hp_gate
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.husk.ambient master @s ~ ~ ~ 1.0 0.8
execute if score @s ec.fx_vis matches 1.. run particle minecraft:block{block_state:"minecraft:sand"} ~ ~0.3 ~ 0.5 0.2 0.5 0.1 30
# Weak: low health, no equipment, no loot, persistent so it cleans up via the trap-mob despawn sweep.
execute if score #cn_safe ec.temp matches 1 positioned ~2 ~ ~ run summon husk ~ ~ ~ {Tags:["ec.cn_trap_mob"],PersistenceRequired:1b,DeathLootTable:"minecraft:empty",Health:10.0f,Attributes:[{id:"minecraft:max_health",base:10.0d}],CanPickUpLoot:0b}
execute if score #cn_safe ec.temp matches 0 if score @s ec.fx_vis matches 1.. run particle minecraft:smoke ~ ~0.5 ~ 0.3 0.2 0.3 0.02 12
data modify storage evercraft:notify stage.c set value [{text:"⚙ ",color:"#B87333"},{text:"A guardian husk!",color:"gold"},{text:" — a dry sentinel rose to guard its hoard.",color:"gray"}]
scoreboard players set #ndur ec.temp 50
function evercraft:util/notify/emit
