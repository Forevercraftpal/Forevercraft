# STING — "Sapping Coil" : a draining hum saps your strength. Brief Weakness II (no health cost at all,
# only weaker swings) — _hp_gate still floors it to cosmetic at/below 3 hearts for consistency.
function evercraft:chest_nodes/traps/_hp_gate
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.beacon.deactivate master @s ~ ~ ~ 0.7 0.8
execute if score @s ec.fx_vis matches 1.. run particle minecraft:witch ~ ~1 ~ 0.3 0.5 0.3 0.05 16
execute if score #cn_safe ec.temp matches 1 run effect give @s minecraft:weakness 12 1 true
execute if score #cn_safe ec.temp matches 0 if score @s ec.fx_vis matches 1.. run particle minecraft:smoke ~ ~1 ~ 0.3 0.4 0.3 0.02 10
data modify storage evercraft:notify stage.c set value [{text:"⚙ ",color:"#B87333"},{text:"A sapping coil",color:"dark_purple"},{text:" — a cold hum bled the strength from your arms.",color:"gray"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
