# STING — "Snare Wire" : a hidden wire yanks tight, rooting you in place. Strong Slowness IV (no health
# cost) + Mining Fatigue I for a short bind. _hp_gate floors to cosmetic at/below 3 hearts for parity.
function evercraft:chest_nodes/traps/_hp_gate
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.tripwire.attach master @s ~ ~ ~ 1.0 0.8
execute if score @s ec.fx_vis matches 1.. run particle minecraft:crit ~ ~0.5 ~ 0.4 0.2 0.4 0.1 16
execute if score #cn_safe ec.temp matches 1 run effect give @s minecraft:slowness 4 3 true
execute if score #cn_safe ec.temp matches 1 run effect give @s minecraft:mining_fatigue 4 0 true
execute if score #cn_safe ec.temp matches 0 if score @s ec.fx_vis matches 1.. run particle minecraft:smoke ~ ~0.5 ~ 0.3 0.2 0.3 0.02 8
data modify storage evercraft:notify stage.c set value [{text:"⚙ ",color:"#B87333"},{text:"A snare wire",color:"red"},{text:" — a hidden cord snapped taut around your legs.",color:"gray"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
