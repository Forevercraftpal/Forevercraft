# === CHEST-NODE TRAPS — CUMULATIVE-THRESHOLD TABLE (1..1000 -> trap id 1..35) ===
# Run as @s. dispatch already rolled #cn_traproll (1..1000) and applied the Gearwright trap perks.
# This file is the SOLE writer of ec.cn_trap_id. It maps the roll to a trap id with cumulative
# thresholds, then $function-routes to traps/fn/trap_$(id). Pattern mirrors the cumulative-band tables
# used across the pack (lowest band first; each row claims the next slice of the 1..1000 range).
#
# WEIGHT BANDS (PLAN §7 — Prank dominant bulk / Sting mild / Nasty rare ~120, the nastiest <=10):
#   PRANK  (ids  1-18): rolls   1..620  (620 total)  — harmless cosmetic: sounds, particles, fake-outs.
#   STING  (ids 19-30): rolls 621..880  (260 total)  — mild + brief: short slowness/nausea/weakness/etc.
#   NASTY  (ids 31-35): rolls 881..1000 (120 total)  — a real (but bounded, gated) cost. id 35 = the
#                       single nastiest at weight 8 (<=10). Trap-Ward (L68) re-rolls this whole band down.
# Each harmful trap (Sting/Nasty) calls _hp_gate and downgrades to cosmetic when at/below 3 hearts.

# ---------- PRANK band (1..620) — 18 cosmetic pranks, ~34-35 wide each. ----------
execute if score #cn_traproll ec.temp matches 1..35 run scoreboard players set @s ec.cn_trap_id 1
execute if score #cn_traproll ec.temp matches 36..69 run scoreboard players set @s ec.cn_trap_id 2
execute if score #cn_traproll ec.temp matches 70..103 run scoreboard players set @s ec.cn_trap_id 3
execute if score #cn_traproll ec.temp matches 104..137 run scoreboard players set @s ec.cn_trap_id 4
execute if score #cn_traproll ec.temp matches 138..171 run scoreboard players set @s ec.cn_trap_id 5
execute if score #cn_traproll ec.temp matches 172..205 run scoreboard players set @s ec.cn_trap_id 6
execute if score #cn_traproll ec.temp matches 206..240 run scoreboard players set @s ec.cn_trap_id 7
execute if score #cn_traproll ec.temp matches 241..275 run scoreboard players set @s ec.cn_trap_id 8
execute if score #cn_traproll ec.temp matches 276..309 run scoreboard players set @s ec.cn_trap_id 9
execute if score #cn_traproll ec.temp matches 310..343 run scoreboard players set @s ec.cn_trap_id 10
execute if score #cn_traproll ec.temp matches 344..377 run scoreboard players set @s ec.cn_trap_id 11
execute if score #cn_traproll ec.temp matches 378..411 run scoreboard players set @s ec.cn_trap_id 12
execute if score #cn_traproll ec.temp matches 412..445 run scoreboard players set @s ec.cn_trap_id 13
execute if score #cn_traproll ec.temp matches 446..480 run scoreboard players set @s ec.cn_trap_id 14
execute if score #cn_traproll ec.temp matches 481..514 run scoreboard players set @s ec.cn_trap_id 15
execute if score #cn_traproll ec.temp matches 515..548 run scoreboard players set @s ec.cn_trap_id 16
execute if score #cn_traproll ec.temp matches 549..583 run scoreboard players set @s ec.cn_trap_id 17
execute if score #cn_traproll ec.temp matches 584..620 run scoreboard players set @s ec.cn_trap_id 18

# ---------- STING band (621..880) — 12 mild/brief stings, ~21-22 wide each. ----------
execute if score #cn_traproll ec.temp matches 621..642 run scoreboard players set @s ec.cn_trap_id 19
execute if score #cn_traproll ec.temp matches 643..664 run scoreboard players set @s ec.cn_trap_id 20
execute if score #cn_traproll ec.temp matches 665..686 run scoreboard players set @s ec.cn_trap_id 21
execute if score #cn_traproll ec.temp matches 687..708 run scoreboard players set @s ec.cn_trap_id 22
execute if score #cn_traproll ec.temp matches 709..730 run scoreboard players set @s ec.cn_trap_id 23
execute if score #cn_traproll ec.temp matches 731..752 run scoreboard players set @s ec.cn_trap_id 24
execute if score #cn_traproll ec.temp matches 753..773 run scoreboard players set @s ec.cn_trap_id 25
execute if score #cn_traproll ec.temp matches 774..794 run scoreboard players set @s ec.cn_trap_id 26
execute if score #cn_traproll ec.temp matches 795..815 run scoreboard players set @s ec.cn_trap_id 27
execute if score #cn_traproll ec.temp matches 816..837 run scoreboard players set @s ec.cn_trap_id 28
execute if score #cn_traproll ec.temp matches 838..858 run scoreboard players set @s ec.cn_trap_id 29
execute if score #cn_traproll ec.temp matches 859..880 run scoreboard players set @s ec.cn_trap_id 30

# ---------- NASTY band (881..1000) — 5 rare real-cost traps; id 35 = the nastiest (weight 8). ----------
execute if score #cn_traproll ec.temp matches 881..910 run scoreboard players set @s ec.cn_trap_id 31
execute if score #cn_traproll ec.temp matches 911..940 run scoreboard players set @s ec.cn_trap_id 32
execute if score #cn_traproll ec.temp matches 941..968 run scoreboard players set @s ec.cn_trap_id 33
execute if score #cn_traproll ec.temp matches 969..992 run scoreboard players set @s ec.cn_trap_id 34
execute if score #cn_traproll ec.temp matches 993..1000 run scoreboard players set @s ec.cn_trap_id 35

# --- Route to the chosen trap fn via macro. Store the id into the macro storage, then $function. ---
execute store result storage evercraft:gth_temp trap_id int 1 run scoreboard players get @s ec.cn_trap_id
function evercraft:chest_nodes/traps/_route with storage evercraft:gth_temp
