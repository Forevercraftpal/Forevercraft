# PRANK — "Pollen Cloud" : a sneeze-inducing puff of pollen + a bee buzz. Cosmetic only.
# Guardrail: particle + sound only, zero effect/damage.
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.bee.loop master @s ~ ~ ~ 0.9 1.0
execute if score @s ec.fx_vis matches 1.. run particle minecraft:falling_spore_blossom ~ ~2 ~ 0.5 0.5 0.5 0.05 30
execute if score @s ec.fx_vis matches 1.. run particle minecraft:composter ~ ~1 ~ 0.4 0.5 0.4 0.05 14
data modify storage evercraft:notify stage.c set value [{text:"⚙ ",color:"#B87333"},{text:"A pollen cloud",color:"yellow"},{text:" — bless you. The cache was full of flowers.",color:"gray"}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit
