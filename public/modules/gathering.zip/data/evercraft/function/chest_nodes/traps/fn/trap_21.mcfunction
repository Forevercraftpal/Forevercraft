# STING — "Rust Grease" : sticky grease gums up your tools. Brief Mining Fatigue II (no health cost) —
# _hp_gate floors to cosmetic at/below 3 hearts for consistency.
function evercraft:chest_nodes/traps/_hp_gate
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.honey_block.slide master @s ~ ~ ~ 1.0 0.7
execute if score @s ec.fx_vis matches 1.. run particle minecraft:dripping_honey ~ ~1 ~ 0.3 0.5 0.3 0.05 16
execute if score #cn_safe ec.temp matches 1 run effect give @s minecraft:mining_fatigue 12 1 true
execute if score #cn_safe ec.temp matches 0 if score @s ec.fx_vis matches 1.. run particle minecraft:item_slime ~ ~1 ~ 0.3 0.4 0.3 0.02 10
data modify storage evercraft:notify stage.c set value [{text:"⚙ ",color:"#B87333"},{text:"Rust grease",color:"gold"},{text:" — gunk fouled your tools for a spell.",color:"gray"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
