# PRANK — "Spectral Whoosh" : an eerie ghostly moan + soul particles. Cosmetic; brief darkness (no harm).
# Guardrail: darkness is a vision effect with NO health cost. No _hp_gate needed.
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:ambient.cave master @s ~ ~ ~ 1.0 0.6
execute if score @s ec.fx_vis matches 1.. run particle minecraft:soul ~ ~1 ~ 0.4 0.6 0.4 0.02 24
effect give @s minecraft:darkness 3 0 true
data modify storage evercraft:notify stage.c set value [{text:"⚙ ",color:"#B87333"},{text:"A spectral whoosh",color:"dark_aqua"},{text:" — something old breathed past you.",color:"gray"}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit
