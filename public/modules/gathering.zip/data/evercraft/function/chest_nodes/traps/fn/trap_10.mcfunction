# PRANK — "Ink Splash" : a squid-ink splatter + a wet pop. Cosmetic; brief blindness (no harm).
# Guardrail: blindness is a vision effect with NO health cost. Kept short. No _hp_gate needed.
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.squid.squirt master @s ~ ~ ~ 1.0 0.9
execute if score @s ec.fx_vis matches 1.. run particle minecraft:squid_ink ~ ~1 ~ 0.4 0.5 0.4 0.05 30
effect give @s minecraft:blindness 3 0 true
data modify storage evercraft:notify stage.c set value [{text:"⚙ ",color:"#B87333"},{text:"An ink splash",color:"dark_gray"},{text:" — the lock spat ink in your eyes.",color:"gray"}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit
