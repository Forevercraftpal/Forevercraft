# PRANK — "Squeaky Floor" : a chorus of comedic squeaks underfoot. Cosmetic only.
# Guardrail: sound + particle only.
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.bat.takeoff master @s ~ ~ ~ 1.0 0.5
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bit master @s ~ ~ ~ 0.7 0.5
execute if score @s ec.fx_vis matches 1.. run particle minecraft:item_slime ~ ~0.2 ~ 0.5 0.1 0.5 0.05 16
data modify storage evercraft:notify stage.c set value [{text:"⚙ ",color:"#B87333"},{text:"A squeaky floor",color:"green"},{text:" — every board under you cried out.",color:"gray"}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit
