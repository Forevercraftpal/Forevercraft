# PRANK — "Ghost Chime" : a phantom amethyst chime from nowhere + a shiver. Cosmetic only.
# Guardrail: sound + particle only.
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 1.2 0.6
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.amethyst_block.resonate master @s ~ ~ ~ 1.0 1.4
execute if score @s ec.fx_vis matches 1.. run particle minecraft:glow ~ ~1.2 ~ 0.5 0.6 0.5 0.02 20
data modify storage evercraft:notify stage.c set value [{text:"⚙ ",color:"#B87333"},{text:"A ghost chime",color:"light_purple"},{text:" — a bell rang that you cannot see.",color:"gray"}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit
