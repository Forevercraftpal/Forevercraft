# PRANK — "Flash Pop" : a blinding camera-flash pop + a click. Cosmetic; brief glowing outline (no harm).
# Guardrail: glowing is purely visual (outline), zero health cost. No _hp_gate needed.
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.firework_rocket.launch master @s ~ ~ ~ 0.7 2.0
execute if score @s ec.fx_vis matches 1.. run particle minecraft:flash{color:[1.0,1.0,1.0,1.0]} ~ ~1 ~ 0 0 0 0 1
effect give @s minecraft:glowing 6 0 true
data modify storage evercraft:notify stage.c set value [{text:"⚙ ",color:"#B87333"},{text:"A flash pop",color:"yellow"},{text:" — say cheese! The cache took your portrait.",color:"gray"}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit
