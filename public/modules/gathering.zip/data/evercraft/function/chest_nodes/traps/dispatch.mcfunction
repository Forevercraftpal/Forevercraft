# === CHEST-NODE — TRAP DISPATCHER (P2b — the full 35-trap data-driven table) ===
# Run as @s (the opener), at the node. Reached from TWO call-sites:
#   (1) do_open's 5%-on-attempt roll (do_open already applied Appraise A3 50%-disarm + A4 disarm-all
#       BEFORE calling here — a disarmed attempt never reaches this function).
#   (2) tinkering/chest_drop/goodies_channel's 8% in-loot prank-trap (the 70% loot bucket; that caller
#       gates Appraise A4 disarm-all before calling).
# Contract: reaching this function means a trap FIRES. We pick the trap, apply the Gearwright trap
# perks the dispatcher owns, and route to traps/fn/trap_$(id) through traps/_table.
#
# GEARWRIGHT TRAP PERKS WIRED HERE (read ec.caffl_gw — the Gearwright level 0-100 from P1):
#   - Appraise A4 (L100): disarm ALL traps. Redundant safety vs the call-sites (a master never reaches
#     here), but kept so any future caller is automatically covered — a L100 Gearwright is NEVER trapped.
#   - Trap-Ward (L68): re-rolls a NASTY result down to a MILD one. We roll, and if the result lands in
#     the Nasty band (881..1000) we re-roll ONCE into 501..880 (top of the PRANK band 501..620 + the full
#     STING band 621..880) so the cost is softened to a harmless prank or a mild sting.
#     The single-nastiest traps (id<=10 weight band) are exactly what this spares a high-level player.

# --- Appraise A4 (L100) disarm-all — final safety; a mastered Gearwright is never trapped. ---
execute if score @s ec.caffl_gw matches 100.. run return 0

# --- Roll the trap (1..1000 cumulative-threshold table picks the id). ---
execute store result score #cn_traproll ec.temp run random value 1..1000

# --- Trap-Ward (Gearwright L68+): a Nasty roll (881..1000) re-rolls ONCE into 501..880 (top of the PRANK
#     band 501..620 + the full STING band 621..880), softening the worst outcomes to a harmless prank or a
#     mild sting. Below L68 the original Nasty roll stands. ---
# NOTE: the first re-roll line below already overwrites #cn_traproll out of 881..1000, so the second guarded
#     line can never re-match 881..1000 and is DEAD (kept as documented; if ever cleaned, delete the LAST line
#     here, not the re-roll line).
execute if score @s ec.caffl_gw matches 68.. if score #cn_traproll ec.temp matches 881..1000 store result score #cn_traproll ec.temp run random value 501..880
execute if score @s ec.caffl_gw matches 68.. if score #cn_traproll ec.temp matches 881..1000 run scoreboard players set #cn_traproll ec.temp 700

# --- Resolve the roll -> ec.cn_trap_id, then $function the chosen trap fn. ---
function evercraft:chest_nodes/traps/_table
