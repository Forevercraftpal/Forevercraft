# PRANK — "Stink Cloud" : a puff of green stink + a wet squelch. Cosmetic; brief nausea (non-damaging).
# Guardrail: nausea is a SCREEN effect (no health cost). No _hp_gate needed.
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.fox.spit master @s ~ ~ ~ 0.8 0.8
execute if score @s ec.fx_vis matches 1.. run particle minecraft:composter ~ ~1 ~ 0.5 0.6 0.5 0.1 30
effect give @s minecraft:nausea 4 0 true
data modify storage evercraft:notify stage.c set value [{text:"⚙ ",color:"#B87333"},{text:"A stink cloud",color:"dark_green"},{text:" — phew! That cache has been sealed a while.",color:"gray"}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit
