# PRANK — "False Bottom" : the chest looks empty with a hollow wooden knock. Pure fake-out, no effect.
# Guardrail: sound + particle only.
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.wood.hit master @s ~ ~ ~ 1.0 0.7
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.barrel.close master @s ~ ~ ~ 0.8 1.0
execute if score @s ec.fx_vis matches 1.. run particle minecraft:dust_plume ~ ~0.5 ~ 0.4 0.2 0.4 0.05 20
data modify storage evercraft:notify stage.c set value [{text:"⚙ ",color:"#B87333"},{text:"A false bottom",color:"gray"},{text:" — the cache rattles, hollow and bare.",color:"gray"}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit
