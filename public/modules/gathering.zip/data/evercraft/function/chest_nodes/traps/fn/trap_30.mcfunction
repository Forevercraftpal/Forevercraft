# STING — "Sting Swarm" : a single weak no-loot bee zips out and buzzes you angrily. The bee can sting
# once (tiny) but is easily swatted. _hp_gate gates the spawn so a low-health player only hears the buzz.
function evercraft:chest_nodes/traps/_hp_gate
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.bee.sting master @s ~ ~ ~ 1.0 1.1
execute if score @s ec.fx_vis matches 1.. run particle minecraft:angry_villager ~ ~1.5 ~ 0.3 0.3 0.3 0.5 8
execute if score #cn_safe ec.temp matches 1 positioned ~ ~1 ~ run summon bee ~ ~ ~ {Tags:["ec.cn_trap_mob"],PersistenceRequired:1b,DeathLootTable:"minecraft:empty",anger:200}
execute if score #cn_safe ec.temp matches 0 if score @s ec.fx_vis matches 1.. run particle minecraft:falling_nectar ~ ~1 ~ 0.3 0.4 0.3 0.05 10
data modify storage evercraft:notify stage.c set value [{text:"⚙ ",color:"#B87333"},{text:"A sting swarm",color:"yellow"},{text:" — you disturbed something with a temper.",color:"gray"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
