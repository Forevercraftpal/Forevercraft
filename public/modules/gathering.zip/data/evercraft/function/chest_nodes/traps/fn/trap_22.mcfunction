# STING — "Hunger Pang" : a musty spore-cloud sours your stomach. Brief Hunger II (drains food, never
# health) — _hp_gate floors to cosmetic at/below 3 hearts for consistency.
function evercraft:chest_nodes/traps/_hp_gate
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.player.burp master @s ~ ~ ~ 1.0 0.8
execute if score @s ec.fx_vis matches 1.. run particle minecraft:mycelium ~ ~1 ~ 0.4 0.5 0.4 0.05 20
execute if score #cn_safe ec.temp matches 1 run effect give @s minecraft:hunger 10 1 true
execute if score #cn_safe ec.temp matches 0 if score @s ec.fx_vis matches 1.. run particle minecraft:composter ~ ~1 ~ 0.3 0.4 0.3 0.02 10
data modify storage evercraft:notify stage.c set value [{text:"⚙ ",color:"#B87333"},{text:"A hunger pang",color:"yellow"},{text:" — musty spores left your belly grumbling.",color:"gray"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
