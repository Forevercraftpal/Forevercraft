# NASTY — "Banishment Rune" : the cache rejects you and flings you a short distance away (ground-safe).
# spreadplayers is the ONLY teleport used (it always lands you on solid ground — never void/lava/wall),
# paired with Slow Falling in case it drops you off a ledge. _hp_gate gates the scatter so a low-health
# player is only shaken (no teleport) — removing any chance the relocation strands them somewhere worse.
function evercraft:chest_nodes/traps/_hp_gate
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.respawn_anchor.deplete master @s ~ ~ ~ 1.0 0.6
execute if score @s ec.fx_vis matches 1.. run particle minecraft:reverse_portal ~ ~1 ~ 0.5 0.8 0.5 0.1 40
# Slow-fall first so any drop from the new (ground-safe) spot is harmless, THEN scatter ~6-10 blocks.
execute if score #cn_safe ec.temp matches 1 run effect give @s minecraft:slow_falling 10 0 true
execute if score #cn_safe ec.temp matches 1 at @s run spreadplayers ~ ~ 6 10 false @s
execute if score #cn_safe ec.temp matches 0 if score @s ec.fx_vis matches 1.. run particle minecraft:portal ~ ~1 ~ 0.3 0.4 0.3 0.05 16
data modify storage evercraft:notify stage.c set value [{text:"⚙ ",color:"#B87333"},{text:"A banishment rune!",color:"dark_purple"},{text:" — the cache spat you out across the way.",color:"gray"}]
scoreboard players set #ndur ec.temp 50
function evercraft:util/notify/emit
