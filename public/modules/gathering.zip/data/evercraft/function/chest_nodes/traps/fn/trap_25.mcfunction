# STING — "Frost Bite" : a blast of frost numbs you. Brief Slowness II + Mining Fatigue I (no health
# cost) — the chilled-stiff combo. _hp_gate floors to cosmetic at/below 3 hearts for consistency.
function evercraft:chest_nodes/traps/_hp_gate
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.glass.break master @s ~ ~ ~ 0.7 1.5
execute if score @s ec.fx_vis matches 1.. run particle minecraft:snowflake ~ ~1 ~ 0.4 0.5 0.4 0.05 24
execute if score #cn_safe ec.temp matches 1 run effect give @s minecraft:slowness 6 1 true
execute if score #cn_safe ec.temp matches 1 run effect give @s minecraft:mining_fatigue 6 0 true
execute if score #cn_safe ec.temp matches 0 if score @s ec.fx_vis matches 1.. run particle minecraft:item_snowball ~ ~1 ~ 0.3 0.4 0.3 0.02 8
data modify storage evercraft:notify stage.c set value [{text:"⚙ ",color:"#B87333"},{text:"A frost bite",color:"aqua"},{text:" — a rime of cold seized your limbs.",color:"gray"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
