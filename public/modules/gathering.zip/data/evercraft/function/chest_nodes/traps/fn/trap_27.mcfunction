# STING — "Silverfish Swarm" : a couple of skittering silverfish boil out of the cache. Weak, no-loot,
# persistent-tagged ambush mobs; they nip but a player easily handles them. _hp_gate gates the spawn so a
# low-health player gets only the cosmetic skitter (no mobs) — they can never be the killing blow.
function evercraft:chest_nodes/traps/_hp_gate
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.silverfish.ambient master @s ~ ~ ~ 1.0 1.0
execute if score @s ec.fx_vis matches 1.. run particle minecraft:block{block_state:"minecraft:stone"} ~ ~0.5 ~ 0.4 0.2 0.4 0.1 20
# Harmful branch: summon 2 weak no-loot silverfish next to the player (DeathLootTable empty -> no drops).
execute if score #cn_safe ec.temp matches 1 positioned ~1 ~ ~ run summon silverfish ~ ~ ~ {Tags:["ec.cn_trap_mob"],PersistenceRequired:1b,DeathLootTable:"minecraft:empty",CanPickUpLoot:0b}
execute if score #cn_safe ec.temp matches 1 positioned ~-1 ~ ~ run summon silverfish ~ ~ ~ {Tags:["ec.cn_trap_mob"],PersistenceRequired:1b,DeathLootTable:"minecraft:empty",CanPickUpLoot:0b}
execute if score #cn_safe ec.temp matches 0 if score @s ec.fx_vis matches 1.. run particle minecraft:crit ~ ~0.5 ~ 0.3 0.2 0.3 0.05 10
data modify storage evercraft:notify stage.c set value [{text:"⚙ ",color:"#B87333"},{text:"A silverfish swarm",color:"gray"},{text:" — the cache was crawling with them!",color:"gray"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
