# === CHEST-NODE ENGINE — LOAD (PLAN-chest-nodes §2, gth_src=5) ===
# Spawned chest nodes a player right-clicks for an instant 50/50 harvest, routed through the
# shared gather engine (gth_src=5 -> Gearwright, class 7). ~85% a clone of fishing/splash_nodes/.
# Cloned design: instant right-click node (no minigame), per-second self-sched spawn loop,
# existence-gated particle + despawn loops. Marker family ec.chest_* (ec.chest_data holding
# data.{ctype, block, charges:1}, ec.chest_visual scaled item_display, ec.chest_click interaction).
#
# Registered from evercraft:init (after fishing/splash_nodes/load). The Gearwright class (class 7),
# the keyless/appraise/loot-sense constants, and the gth_src=5 gather wiring were established in P1.

# --- Spawn / key scoreboards (instant-open design: no minigame state needed) ---
# ec.cn_timer  : per-player spawn countdown (decremented by check_spawn). ONE writer = check_spawn.
scoreboard objectives add ec.cn_timer dummy "Chest Node Spawn Timer"
# ec.cn_haskey : 1 if the player carries any usable key (inv/offhand/key-bag fresh count). ONE
#                writer = chest_nodes/key_detect.
scoreboard objectives add ec.cn_haskey dummy "Chest Node Key-Carry Flag"
# ec.cn_keytype: dominant key type the player carries (0=none, 1=trial/crafting, 2=dungeon/adventurer).
#                ONE writer = chest_nodes/key_detect.
scoreboard objectives add ec.cn_keytype dummy "Chest Node Dominant Key Type"
# (Per-player hand-attempt + open state is recorded on the NODE MARKER as UUID int-array lists —
#  data.w1_t1 / w1_t2 (the 3-fail ladder) + w1_claimed / w1_locked / w2_claimed / opened_by — appended via
#  chest_nodes/claim/add and tested via claim/has. Interleave-proof, so NO player-side streak objective.)
# ec.cn_trap_id: which of the 35 traps the cumulative-threshold table resolved this fire (1..35).
#                ONE writer = chest_nodes/traps/_table (read only as the $(id) macro arg in dispatch path).
scoreboard objectives add ec.cn_trap_id dummy "Chest Node Trap ID"
# ec.cn_mob_age: per-trap-mob age (in ~5s ticks) for the abandoned-ambush age-out. ONE writer =
#                chest_nodes/tick_despawn (kills the mob at age 8 = ~40s).
scoreboard objectives add ec.cn_mob_age dummy "Chest Node Trap Mob Age"
# ec.cn_crack / _max / _typ : the timed-open channel — remaining ticks / total (for the bar fill %) /
#   type (1=keyed harvest timer, 2=keyless crack). ONE writer = crack/begin (seed) + crack/tick_one
#   (decrement). Drives the pooled boss bar (reuses the live-XP-bar pool) + the deferred do_open resolve.
scoreboard objectives add ec.cn_crack dummy "Chest Node Open Channel"
scoreboard objectives add ec.cn_crack_max dummy "Chest Node Channel Total"
scoreboard objectives add ec.cn_crack_typ dummy "Chest Node Channel Type"
# ec.cn_keyworn: snapshot — 1 if the dungeon key the player just consumed for a dungeon was ALREADY
#                worn (§3 key lifecycle). SET by the dungeon/use_key_worn advancement reward
#                (dungeon/mark_key_worn); RESET by the consumer dungeon/start after the cracked-re-give
#                decision. Set-by-event / reset-by-consumer flag pair (the sanctioned flag idiom).
scoreboard objectives add ec.cn_keyworn dummy "Dungeon Key Worn-On-Consume Snapshot"
# ec.gw_lsfol : Loot Sense T1 FOLLOW-window countdown, in 10t frames (30 = 15s). A sub-L10 sense opens
#               a 15s window in which the player chases a directional chest sound; reaching a node (or
#               the timer hitting 0) closes it. Recurring (tick-chain) writer = loot_sense_step (the
#               per-frame decrement); seeded once by loot_sense on the sense, zeroed by loot_sense_clear
#               on close (the sanctioned seed / tick-decrement / terminal-reset idiom, like ec.cn_timer).
scoreboard objectives add ec.gw_lsfol dummy "Gearwright Loot Sense Follow Timer"
# ec.gw_lsreal: 1 if THIS T1 follow points at a genuine nearby node, 0 if it is a hallucination (a
#               false positive — ~30% of T1 senses fizzle into "…or your imagination"). At L10+ (T2)
#               there are no hallucinations. ONE writer = chest_nodes/abilities/loot_sense (set once
#               when the window opens).
scoreboard objectives add ec.gw_lsreal dummy "Gearwright Loot Sense Genuine Flag"
# ec.gw_hide_insp: APPRAISE A3 (Gearwright L50). 1 = this player has hidden their profile from
#                  inspection by STRANGERS (friends + same-party members are exempt, checked live in
#                  chest_nodes/inspect/show). 0/unset = inspectable by anyone with Appraise A2. ONE
#                  writer = chest_nodes/inspect/toggle_hide (the Gearwright codex toggle button).
scoreboard objectives add ec.gw_hide_insp dummy "Gearwright Hide From Inspection"
# ec.gw_insp_cd: per-player inspect-button cooldown (in ticks, decremented in chest_nodes/tick_spawn's
#                existence-gated sweep) — debounces the codex [Inspect] chat button so a double-click
#                fires one raycast. ONE writer pair = inspect/raycast (seeds) + tick_spawn (decrements).
scoreboard objectives add ec.gw_insp_cd dummy "Gearwright Inspect Button Cooldown"

# --- Engine constants (read-only #cn_* ec.var fakeplayers; set once here at load) ---
# ~3 chest nodes / MC-day baseline (§10.2): a per-MC-day PROBABILISTIC spawn, NOT a hard counter.
# Base per-second spawn chance is tuned so an eligible player averages ~3 successful spawns across
# a 20-minute (24000-tick) MC day. The timer-decrement model (mirrors splash) gives the cadence;
# #cn_timer_base seeds the countdown each cycle. Keyed players + ec.acc_spawn + the Gearwright
# spawn perk SHORTEN the timer (push spawns ABOVE the ~3/day baseline). Unopened nodes despawn 60s.
#   ~24000t/day, target ~3 spawns -> a fresh attempt window roughly every ~8000t; with the close
#   multi-candidate search succeeding most cycles we seed the base timer at 7200t (~6 MC-min) and
#   roll a 1-in-2 gate per expiry so the realized average lands near ~3/day (probabilistic, not fixed).
scoreboard players set #cn_timer_base ec.var 7200
# Keyed players spawn faster (shorter timer): subtract this from the seeded timer when ec.cn_haskey=1.
scoreboard players set #cn_timer_keyed ec.var 3000
# ec.acc_spawn accessory + the Gearwright spawn perk each shorten the timer by this (folded in check_spawn).
scoreboard players set #cn_timer_acc ec.var 1500
# Per-expiry probabilistic gate (1..100): only spawn when the roll is <= this (the ~3/day limiter
# beyond the timer cadence). Keyed/accessory carriers raise their effective gate via a separate add.
scoreboard players set #cn_spawn_gate ec.var 63
# Despawn lifetime for an overworld node: 7 MIN = 8400 ticks (Joseph 2026-06-05, bumped from 60s/1200t).
# The per-player open model never despawns-on-open (every player opens individually) — this timer is the
# ONLY despawn, so it's lengthened to give several players time to work their hand/key opens before it expires.
scoreboard players set #cn_despawn_ticks ec.var 8400
# Nearby-node cap (skip a spawn if this many chest nodes already sit within ~48 blocks of the player).
scoreboard players set #cn_nearby_cap ec.var 4
# Divisor 10 — folds the per-mille Appraise good-outcome constants (#caff_gw_apprz_*, P1) down to
# percent points for the crate-threshold boost in do_open_success. Read-only.
scoreboard players set #cn_c10 ec.var 10
# Channel-duration math constants: 100 (percent), 7 (harvest -7t/lv), 2 (crack -2t/lv).
scoreboard players set #cn_c100 ec.var 100
scoreboard players set #cn_c7 ec.var 7
scoreboard players set #cn_c2 ec.var 2
# Constant 80 for the chime gametime-pulse modulo (declared globally as #80 in init; re-set here
# so a standalone chest_nodes/load is self-sufficient — idempotent, read-only).
scoreboard players set #80 ec.const 80
# Chime cadence slowed 7× (Joseph 2026-06-12): 80t pulse was a drone in dense
# chest-node zones; 560t (~28s) is a beacon. Used by render_node's gametime
# modulo chime gate.
scoreboard players set #560 ec.const 560

# --- Start scheduled loops (mirrors fishing/splash_nodes/load exactly) ---
schedule function evercraft:chest_nodes/tick_spawn 1s replace
schedule function evercraft:chest_nodes/tick_particles 10t replace
schedule function evercraft:chest_nodes/tick_despawn 100t replace
# Timed-open channel tick (2t for a smooth bar; existence-gated on @a[tag=ec.cn_cracking]).
schedule function evercraft:chest_nodes/crack/tick 2t replace

# --- Loot Sense T1 FOLLOW window (10t, existence-gated on @a[tag=ec.gw_following]). Plays the
#     directional chase-sound + resolves the 15s window (reached / imagination). Idle when no one is
#     following — the gate inside makes it a near-free self-schedule (mirrors the other tick loops). ---
schedule function evercraft:chest_nodes/abilities/loot_sense_follow 10t replace

# --- Key-carry detection sweep (5s, existence-gated, mirrors dungeon/unknown/key_detect cadence) ---
schedule function evercraft:chest_nodes/key_detect 5s replace

# --- Structure-bound chest batch (§11 / §14.6, P2.5): first-visit player-bound nodes inside big
#     structures. Its load sets the re-spawn cooldown constant + starts the struct owner tick. ---
function evercraft:chest_nodes/struct/load
