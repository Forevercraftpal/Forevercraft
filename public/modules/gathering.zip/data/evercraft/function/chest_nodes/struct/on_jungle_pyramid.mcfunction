# === STRUCTURE CHEST — thin location handler: jungle_pyramid (§11 / §14.6, P2.5) ===
# Fired by advancement evercraft:chest_nodes/struct/jungle_pyramid (minecraft:location trigger on minecraft:jungle_pyramid).
# quests/explore lacked a handler for this structure, so this is a NEW minimal first-visit hook: revoke
# to re-arm for future visits, then call the per-struct stamp wrapper (which dedupes + spawns the batch).
# Run as @s = player (advancement reward context).
advancement revoke @s only evercraft:chest_nodes/struct/jungle_pyramid
function evercraft:chest_nodes/struct/enter/jungle_pyramid
