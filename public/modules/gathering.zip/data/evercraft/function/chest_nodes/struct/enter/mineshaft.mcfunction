# === STRUCTURE CHEST — per-structure stamp wrapper: mineshaft (§11 / §14.6) ===
# Run as @s = player. Sets the dedupe struct-id + the candidate-gate predicate name, then calls the
# shared first-visit hook. Wired as the LAST line of the mineshaft location handler (explore handler for
# the structures explore already covered; a thin chest_nodes/struct/on_<struct> handler otherwise).
# struct = the predicate basename under predicate/structures/structure/ (the candidate gate).
scoreboard players set #cs_struct ec.var 4
data modify storage evercraft:cn_temp struct set value "mineshaft"
function evercraft:chest_nodes/struct/on_enter
