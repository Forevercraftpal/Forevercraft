# === STRUCTURE CHEST — ONE placement candidate (recursive, predicate-gated) ===
# Run as @s = player, at player position. Reads storage evercraft:cn_temp.struct (the predicate
# basename) and passes it to the macro worker place_one. Tries a spot within a 24-block radius for a
# solid GROUND surface that ALSO satisfies the structure predicate (node lands INSIDE the structure).
# On a miss it recurses until the target count is met OR the candidate budget (#cs_btries) runs out.
# Mirrors chest_nodes/place_attempt but: wider radius, the structure-predicate gate, the per-player
# owner flags on the node, and a target/floor stop condition.

# Stop: target met, or budget exhausted.
execute if score #cs_placed_struct ec.var >= #cs_target ec.var run return 0
execute if score #cs_btries ec.temp matches ..0 run return 0
scoreboard players remove #cs_btries ec.temp 1

# Player block coords + a random nearby offset (-24..24 on X/Z), starting 5 blocks above so the
# downward scan begins in air over the ground (matches the overworld place_attempt shape).
execute store result score #cs_tx ec.temp run data get entity @s Pos[0] 1
execute store result score #cs_ty ec.temp run data get entity @s Pos[1] 1
execute store result score #cs_tz ec.temp run data get entity @s Pos[2] 1
execute store result score #cs_ox ec.temp run random value -24..24
execute store result score #cs_oz ec.temp run random value -24..24
scoreboard players operation #cs_tx ec.temp += #cs_ox ec.temp
scoreboard players operation #cs_tz ec.temp += #cs_oz ec.temp
scoreboard players add #cs_ty ec.temp 5

# Summon a candidate marker and move it to (offsetX, playerY+5, offsetZ).
summon marker ~ ~ ~ {Tags:["ec.chest_temp"]}
execute store result entity @e[type=marker,tag=ec.chest_temp,limit=1] Pos[0] double 1 run scoreboard players get #cs_tx ec.temp
execute store result entity @e[type=marker,tag=ec.chest_temp,limit=1] Pos[1] double 1 run scoreboard players get #cs_ty ec.temp
execute store result entity @e[type=marker,tag=ec.chest_temp,limit=1] Pos[2] double 1 run scoreboard players get #cs_tz ec.temp

# Scan DOWN (up to 14) for an air-block-over-solid-ground surface (reuse the engine's surface scanner).
scoreboard players set #cn_scan ec.temp 14
execute as @e[type=marker,tag=ec.chest_temp,limit=1] at @s store success score #cs_found ec.temp run function evercraft:chest_nodes/scan_surface

# No surface here -> drop the candidate and try another.
execute if score #cs_found ec.temp matches 0 run kill @e[type=marker,tag=ec.chest_temp]
execute if score #cs_found ec.temp matches 0 run return run function evercraft:chest_nodes/struct/place_attempt

# Found a surface — verify the structure predicate holds AT the candidate (so the node is INSIDE the
# structure). The predicate name is dynamic -> the macro worker place_one applies the gate + places.
execute at @e[type=marker,tag=ec.chest_temp,limit=1] run function evercraft:chest_nodes/struct/place_one with storage evercraft:cn_temp

# Clean up the candidate marker and recurse for the next node.
kill @e[type=marker,tag=ec.chest_temp]
return run function evercraft:chest_nodes/struct/place_attempt
