# === STRUCTURE CHEST — spawn a player-bound batch INSIDE the structure (§11 / §14.6) ===
# Run as @s = player, at player position. storage evercraft:cn_temp.struct = the candidate-gate
# predicate basename. Rolls a target of 3..8 nodes and places each ONLY where the structure predicate
# holds at the candidate (so every node lands INSIDE the structure bounds). 24-block search radius, a
# recursive tries-budget like splash place_attempt, and a FLOOR of 3 (the batch keeps trying until it
# has placed at least 3, even if the random target rolled higher than the budget could satisfy).
# Outputs #cs_placed_struct ec.var = how many nodes actually landed (read by on_enter).

# Roll the batch size target (3..8).
execute store result score #cs_target ec.var run random value 3..8
# NEARBY CAP (Joseph 2026-06-05 spam fix): clamp the target to the headroom under #cs_struct_cap TOTAL
# chest nodes within 48 blocks. If already at the cap, place nothing this fire (no unbounded re-spawn).
execute store result score #cs_nearby ec.var if entity @e[type=marker,tag=ec.chest_data,distance=..48]
scoreboard players operation #cs_head ec.var = #cs_struct_cap ec.var
scoreboard players operation #cs_head ec.var -= #cs_nearby ec.var
execute if score #cs_head ec.var < #cs_target ec.var run scoreboard players operation #cs_target ec.var = #cs_head ec.var
execute if score #cs_target ec.var matches ..0 run scoreboard players set #cs_placed_struct ec.var 0
execute if score #cs_target ec.var matches ..0 run return 0
# Placed counter + the per-batch candidate-tries budget (generous: many candidates fall OUTSIDE the
# predicate, so the budget must exceed the target by a wide margin).
scoreboard players set #cs_placed_struct ec.var 0
scoreboard players set #cs_btries ec.temp 64

# Stamp the owner UUID into spawn-temp storage so struct/place_node can read it (per-player gating).
data modify storage evercraft:cn_temp owner_uuid set from entity @s UUID
# Stamp this player's dominant key type so the struct node's data.ctype is weighted like overworld nodes.
execute store result storage evercraft:cn_temp keytype int 1 run scoreboard players get @s ec.cn_keytype

# Run the recursive candidate sampler (it self-recurses until the target is met OR the budget runs out).
function evercraft:chest_nodes/struct/place_attempt

# FLOOR of 3: if fewer than 3 landed but the budget ran out, grant a small extra budget and retry once
# more so a legitimate (if cramped) structure still yields the minimum batch. Bounded: one extra pass.
execute if score #cs_placed_struct ec.var matches ..2 run scoreboard players set #cs_btries ec.temp 48
execute if score #cs_placed_struct ec.var matches ..2 run function evercraft:chest_nodes/struct/place_attempt
