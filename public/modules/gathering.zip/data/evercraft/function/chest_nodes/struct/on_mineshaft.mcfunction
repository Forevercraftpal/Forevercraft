# === STRUCTURE CHEST — thin location handler: mineshaft (§11 / §14.6, P2.5) ===
# Fired by advancement evercraft:chest_nodes/struct/mineshaft (minecraft:location trigger on minecraft:mineshaft).
# quests/explore lacked a handler for this structure, so this is a NEW minimal first-visit hook: revoke
# to re-arm for future visits, then call the per-struct stamp wrapper (which dedupes + spawns the batch).
# Run as @s = player (advancement reward context).
advancement revoke @s only evercraft:chest_nodes/struct/mineshaft
function evercraft:chest_nodes/struct/enter/mineshaft
