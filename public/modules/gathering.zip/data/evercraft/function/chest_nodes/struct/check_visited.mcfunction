# === STRUCTURE CHEST — per-instance dedupe + cooldown check (§11 / §14.6) ===
# Run as @s = player, at player position. The caller (struct/on_enter) has already set #cs_struct
# ec.var = the integer structure-id for the structure just entered. Mirrors quests/explore/check_visited
# (96-block proximity = "same instance") but ALSO keys on the structure TYPE and applies a 30-hour
# (2,160,000t) cooldown so a re-visit inside the cooldown does NOT re-spawn a batch.
#
# Outputs (ec.var fakeplayers):
#   #cs_spawn = 1 -> spawn a fresh batch (no owner-marker for this player+struct OR the cooldown elapsed)
#   #cs_spawn = 0 -> skip (an owner-marker exists for this instance and the cooldown has not elapsed)

scoreboard players set #cs_visited ec.var 0
scoreboard players set #cs_last_at ec.var 0
scoreboard players set #cs_spawn ec.var 0

# Stash the player's UUID for the as-marker comparison (4 ints, like the explore dedupe).
execute store result score #cs_p0 ec.var run data get entity @s UUID[0]
execute store result score #cs_p1 ec.var run data get entity @s UUID[1]
execute store result score #cs_p2 ec.var run data get entity @s UUID[2]
execute store result score #cs_p3 ec.var run data get entity @s UUID[3]

# Scan nearby owner-markers; _uuid_match sets #cs_visited=1 + #cs_last_at on a full (player+struct) match.
execute as @e[type=marker,tag=ec.cn_struct,distance=..96] run function evercraft:chest_nodes/struct/_uuid_match

# No prior visit by this player at this structure type within 96 blocks -> spawn.
execute if score #cs_visited ec.var matches 0 run scoreboard players set #cs_spawn ec.var 1

# A prior visit exists -> spawn only if the 30-hour cooldown has elapsed since that marker's spawn time.
execute store result score #cs_now ec.var run time query gametime
scoreboard players operation #cs_now ec.var -= #cs_last_at ec.var
execute if score #cs_visited ec.var matches 1 if score #cs_now ec.var >= #cs_cooldown ec.var run scoreboard players set #cs_spawn ec.var 1
