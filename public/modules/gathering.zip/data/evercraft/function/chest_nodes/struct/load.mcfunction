# === STRUCTURE CHEST — LOAD (§11 / §14.6, P2.5) ===
# Registered from evercraft:chest_nodes/load (after the engine's own loops). The structure-bound chest
# batch: a player's FIRST visit to a big structure spawns 3..8 player-bound, persistent chest nodes
# INSIDE the structure. These reuse the entire P2a engine (do_open / despawn / render / on_click) via the
# shared ec.chest_data tag, plus the struct-variant flags (struct_bound / owner_uuid / preunlocked).
# No new scoreboard OBJECTIVES are needed — the family is driven by entity NBT flags + #cs_* ec.var/temp
# scratch fakeplayers (existing objectives). Only one read-only constant + the struct tick schedule here.

# 30-HOUR re-spawn cooldown (2,160,000 ticks = 30h of server gametime at 20 t/s): a re-visit inside this
# window does NOT re-spawn a batch. Read by struct/check_visited. (Joseph 2026-06-21: bumped from the old
# 1-MC-day/24000t — that was ~20 real minutes, so camping in a structure or, for a Pioneer, dying and
# trekking back re-seeded crates far too readily. 30h means crates replenish only over ~1.25 real days.)
# Read-only #cs_* ec.var.
scoreboard players set #cs_cooldown ec.var 2160000

# NEARBY CAP (Joseph 2026-06-05 spam fix): the struct batch had NO upper bound — a re-fire (the ~1/s
# location-advancement re-arm) or a large structure (player crosses the 96-block dedupe window) could
# spam unbounded (Joseph saw ~30). spawn_batch clamps each batch to the headroom under this many TOTAL
# chest nodes within 48 blocks of the player. Read-only #cs_* ec.var.
scoreboard players set #cs_struct_cap ec.var 10

# Constant 80 for the owner-chime gametime-pulse modulo (declared globally as #80 in init + re-set in
# chest_nodes/load; re-set here so a standalone struct/load is self-sufficient — idempotent, read-only).
scoreboard players set #80 ec.const 80

# Start the struct-node owner tick (owner-gated chime at 10 + the 20% auto-unlock proximity roll).
schedule function evercraft:chest_nodes/struct/tick 10t replace
