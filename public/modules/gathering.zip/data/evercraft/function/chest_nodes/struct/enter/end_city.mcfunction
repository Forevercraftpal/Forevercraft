# === STRUCTURE CHEST — per-structure stamp wrapper: end_city (§11 / §14.6) ===
# Run as @s = player. Sets the dedupe struct-id + the candidate-gate predicate name, then calls the
# shared first-visit hook. Wired as the LAST line of the end_city location handler (explore handler for
# the structures explore already covered; a thin chest_nodes/struct/on_<struct> handler otherwise).
# struct = the predicate basename under predicate/structures/structure/ (the candidate gate).
scoreboard players set #cs_struct ec.var 12
data modify storage evercraft:cn_temp struct set value "end_city"
function evercraft:chest_nodes/struct/on_enter
