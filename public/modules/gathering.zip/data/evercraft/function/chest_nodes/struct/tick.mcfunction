# === STRUCTURE CHEST — per-node owner tick (chime gate 10 + 20% auto-unlock roll) ===
# Self-scheduling 10t loop (matches the engine's tick_particles cadence). Existence-gated on the
# struct-node tag so it is free when no struct nodes are loaded. Per node it: (a) owner-gated chime
# within 10 blocks (struct nodes are QUIET vs 25 for overworld), and (b) the once-per-chest 20%
# auto-unlock roll when the OWNER approaches within 3 blocks (§11 / §14.6).
schedule function evercraft:chest_nodes/struct/tick 10t replace

# Existence-gate: only work when a struct node AND a player are loaded.
execute if entity @e[type=marker,tag=ec.chest_struct,limit=1] if entity @a[limit=1] as @e[type=marker,tag=ec.chest_struct] at @s run function evercraft:chest_nodes/struct/node_tick
