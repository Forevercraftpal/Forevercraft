# === STRUCTURE CHEST — thin location handler: ocean_ruin (§11 / §14.6, P2.5) ===
# Fired by advancement evercraft:chest_nodes/struct/ocean_ruin (minecraft:location trigger on minecraft:ocean_ruin_cold).
# quests/explore lacked a handler for this structure, so this is a NEW minimal first-visit hook: revoke
# to re-arm for future visits, then call the per-struct stamp wrapper (which dedupes + spawns the batch).
# Run as @s = player (advancement reward context).
advancement revoke @s only evercraft:chest_nodes/struct/ocean_ruin
function evercraft:chest_nodes/struct/enter/ocean_ruin
