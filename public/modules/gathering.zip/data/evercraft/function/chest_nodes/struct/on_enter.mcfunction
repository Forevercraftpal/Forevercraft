# === STRUCTURE CHEST — first-visit hook (the §11 / §14.6 entry point) ===
# Run as @s = player, at player position. Called from each per-structure stamp wrapper
# (struct/enter/<struct>) which has ALREADY set:
#   - #cs_struct ec.var = the integer dedupe-id for this structure type, AND
#   - storage evercraft:cn_temp {struct:"<predicate-name>"} (the candidate-gate predicate basename
#     under predicate/structures/structure/).
# The wrapper is invoked near the top of each quests/explore/on_<struct> handler — before that
# handler's quest-completion branches and any early return — and from the new thin location
# handlers for the structures explore lacked.
#
# Flow: per-instance dedupe + 30-hour cooldown (see struct/load:14) -> (if eligible) spawn a player-bound batch of 3..8 nodes
# that land INSIDE the structure (each candidate gated by `if predicate evercraft:structures/structure/
# $(struct)`), then stamp the owner-marker. These nodes PERSIST until gathered (struct_bound skips the
# 60s despawn) and do NOT touch the ~3/MC-day overworld spawn counter (a wholly separate path).

# (1) Dedupe + cooldown: writes #cs_spawn (1 = spawn a fresh batch / 0 = skip).
function evercraft:chest_nodes/struct/check_visited
execute if score #cs_spawn ec.var matches 0 run return 0

# (2) Spawn the player-bound batch (3..8 nodes placed INSIDE the structure). spawn_batch reads
#     storage evercraft:cn_temp.struct as the candidate-gate predicate name; it returns the placed count.
function evercraft:chest_nodes/struct/spawn_batch

# (3) A batch with at least one placed node -> stamp the owner-marker so the next visit dedupes/cools
#     down. If the search placed nothing (rare — a tiny/blocked structure), do NOT stamp, so the player
#     gets another try next visit rather than being permanently locked out of this instance's bonus.
execute if score #cs_placed_struct ec.var matches 1.. run function evercraft:chest_nodes/struct/mark_visited

# (4) A first-time arrival cue (only when a batch actually landed) — quiet, owner-only.
execute if score #cs_placed_struct ec.var matches 1.. if score @s ec.fx_snd matches 1.. run playsound minecraft:block.amethyst_block.resonate master @s ~ ~ ~ 0.5 1.1
execute if score #cs_placed_struct ec.var matches 1.. run data modify storage evercraft:notify stage.c set value [{text:"⚙ ",color:"#B87333"},{text:"This place hides chests for you to find.",color:"#B87333",italic:true}]
execute if score #cs_placed_struct ec.var matches 1.. run scoreboard players set #ndur ec.temp 55
execute if score #cs_placed_struct ec.var matches 1.. run function evercraft:util/notify/emit
