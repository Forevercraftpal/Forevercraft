# === STRUCTURE CHEST — owner UUID-match leaf (run as a nearby player) ===
# Compares this player's UUID against the node's owner UUID stashed in #cs_o0..o3 by node_tick. On a
# full 4-int match, tags the player ec.cs_is_owner so node_tick can owner-gate the chime + unlock roll.
# Mirrors quests/explore/_uuid_match (score comparison), but the stash is the marker's owner_uuid.

execute store result score #cs_q0 ec.var run data get entity @s UUID[0]
execute store result score #cs_q1 ec.var run data get entity @s UUID[1]
execute store result score #cs_q2 ec.var run data get entity @s UUID[2]
execute store result score #cs_q3 ec.var run data get entity @s UUID[3]

execute if score #cs_q0 ec.var = #cs_o0 ec.var if score #cs_q1 ec.var = #cs_o1 ec.var if score #cs_q2 ec.var = #cs_o2 ec.var if score #cs_q3 ec.var = #cs_o3 ec.var run tag @s add ec.cs_is_owner
