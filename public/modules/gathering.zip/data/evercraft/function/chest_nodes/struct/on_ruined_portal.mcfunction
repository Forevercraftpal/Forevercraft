# === STRUCTURE CHEST — thin location handler: ruined_portal (§11 / §14.6, P2.5) ===
# Fired by advancement evercraft:chest_nodes/struct/ruined_portal (minecraft:location trigger on minecraft:ruined_portal).
# quests/explore lacked a handler for this structure, so this is a NEW minimal first-visit hook: revoke
# to re-arm for future visits, then call the per-struct stamp wrapper (which dedupes + spawns the batch).
# Run as @s = player (advancement reward context).
advancement revoke @s only evercraft:chest_nodes/struct/ruined_portal
function evercraft:chest_nodes/struct/enter/ruined_portal
