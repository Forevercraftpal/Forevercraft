# === STRUCTURE CHEST — per-instance owner+struct match leaf (run as an ec.cn_struct marker) ===
# §11 / §14.6. Mirrors quests/explore/_uuid_match but ALSO matches the structure TYPE (data.struct) so
# a village marker never satisfies a co-located pillager_outpost (the two can overlap within 96 blocks).
# Compares the marker's stored player_uuid against #cs_p0..p3 AND its data.struct against #cs_struct
# (the caller stashed both). On a full match, records the marker's data.spawned_at into #cs_last_at so
# the caller can apply the 1-MC-day cooldown (re-spawn only after the cooldown elapses).
# Called from struct/check_visited (player UUID + struct-id already stashed by the caller).

execute store result score #cs_m0 ec.var run data get entity @s data.player_uuid[0]
execute store result score #cs_m1 ec.var run data get entity @s data.player_uuid[1]
execute store result score #cs_m2 ec.var run data get entity @s data.player_uuid[2]
execute store result score #cs_m3 ec.var run data get entity @s data.player_uuid[3]
execute store result score #cs_mstruct ec.var run data get entity @s data.struct_id

# Full match (same player AND same structure type within 96 blocks = "this instance, this player").
execute if score #cs_m0 ec.var = #cs_p0 ec.var if score #cs_m1 ec.var = #cs_p1 ec.var if score #cs_m2 ec.var = #cs_p2 ec.var if score #cs_m3 ec.var = #cs_p3 ec.var if score #cs_mstruct ec.var = #cs_struct ec.var run scoreboard players set #cs_visited ec.var 1
# Record the most recent matching marker's spawn gametime (for the cooldown check in the caller).
execute if score #cs_m0 ec.var = #cs_p0 ec.var if score #cs_m1 ec.var = #cs_p1 ec.var if score #cs_m2 ec.var = #cs_p2 ec.var if score #cs_m3 ec.var = #cs_p3 ec.var if score #cs_mstruct ec.var = #cs_struct ec.var store result score #cs_last_at ec.var run data get entity @s data.spawned_at
