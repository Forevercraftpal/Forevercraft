# === STRUCTURE CHEST — summon a STRUCT-BOUND node (§11 / §14.6) ===
# Run positioned at the candidate ground surface (struct/place_one verified the structure predicate
# holds here). Clones chest_nodes/place_node's entity set (data marker + scaled item_display + the
# interaction hitbox + rarity stamp + Loot Sense), but stamps the STRUCT-VARIANT flags so the engine
# treats this node as player-bound + persistent:
#   data.struct_bound:1b  -> check_despawn skips the 60s timer (persists until gathered).
#   data.owner_uuid       -> render/chime/interaction are OWNER-gated (others don't see/open it).
#   data.unlock_rolled    -> (seeded absent) the once-per-chest 20% auto-unlock roll guard (struct/tick).
#   data.preunlocked      -> (seeded absent) set on a winning 20% roll: opens with no key/wear/gate/trap.
# These nodes do NOT touch the overworld ~3/MC-day spawn counter (a separate path; nothing here writes it).

# Read the placer's dominant key type for the ctype weighting (default 0=plain).
scoreboard players set #cn_keytype ec.temp 0
execute store result score #cn_keytype ec.temp run data get storage evercraft:cn_temp keytype

# --- Data marker (spawn gametime + node state). Same tag family as overworld nodes (the engine reuses
#     all of do_open / despawn / render / on_click on it) plus the struct flags. ---
# (ec.chest_struct is the cheap existence-gate tag for the struct tick; ec.cs_locked = un-rolled flag
#  so the 20% auto-unlock roll fires exactly once per node — removed when rolled.)
summon marker ~ ~ ~ {Tags:["ec.chest","ec.chest_data","ec.chest_struct","ec.cs_locked","ec.chest_new"]}
execute store result entity @e[type=marker,tag=ec.chest_new,limit=1,distance=..1] data.spawn_time long 1 run time query gametime
data modify entity @e[type=marker,tag=ec.chest_new,limit=1,distance=..1] data.charges set value 1
# STRUCT-VARIANT flags: struct-bound (skip 60s despawn) + owner UUID (per-player render/open gating).
data modify entity @e[type=marker,tag=ec.chest_new,limit=1,distance=..1] data.struct_bound set value 1b
data modify entity @e[type=marker,tag=ec.chest_new,limit=1,distance=..1] data.owner_uuid set from storage evercraft:cn_temp owner_uuid

# --- Roll the chest TYPE (data.ctype): 1=Crafting, 2=Adventurer, 3=plain — weighted by the placer's
#     carried key, identical to the overworld place_node weighting. ---
data modify entity @e[type=marker,tag=ec.chest_new,limit=1,distance=..1] data.ctype set value 3
execute store result score #cn_ctroll ec.temp run random value 1..100
execute if score #cn_keytype ec.temp matches 1 if score #cn_ctroll ec.temp matches 1..70 run data modify entity @e[type=marker,tag=ec.chest_new,limit=1,distance=..1] data.ctype set value 1
execute if score #cn_keytype ec.temp matches 2 if score #cn_ctroll ec.temp matches 1..70 run data modify entity @e[type=marker,tag=ec.chest_new,limit=1,distance=..1] data.ctype set value 2

# --- Pick a container-block VARIANT (item_display item) — EXCLUDE all shulker boxes (reuse the engine
#     apply_visual; it reads #cn_bvar + stamps data.block + summons the scaled ec.chest_visual). ---
execute store result score #cn_bvar ec.temp run random value 1..18
function evercraft:chest_nodes/apply_visual

# --- Interaction entity (right-click target). on_click owner-gates struct-bound nodes (§14.6). ---
summon interaction ~0.5 ~0.05 ~0.5 {Tags:["ec.chest","ec.chest_click"],width:0.95f,height:0.95f,response:1b}

# B-rarity: stamp data.rarity (1-6) on the SAME marker (drives the Gearwright open XP).
function evercraft:gather/rarity/stamp_chest

# Clean up temporary tags.
tag @e[type=marker,tag=ec.chest_new,limit=1,distance=..1] remove ec.chest_new
tag @e[type=item_display,tag=ec.chest_vis_new,limit=1,distance=..1] remove ec.chest_vis_new

# A coppery placement sparkle (struct nodes are QUIET — no chime until the owner is within 10 blocks).
particle minecraft:wax_on ~ ~0.5 ~ 0.3 0.3 0.3 0.05 10
particle dust{color:[0.722,0.451,0.2],scale:1.0} ~ ~0.5 ~ 0.25 0.3 0.25 0 6
