# === STRUCTURE CHEST — stamp the owner-marker for this player+instance (§11 / §14.6) ===
# Run as @s = player, at player position (called from struct/on_enter AFTER check_visited returned
# #cs_spawn=1 and AFTER the batch placed). Mirrors quests/explore/mark_visited: summon an ec.cn_struct
# marker stamped with the player's UUID + the structure-id + the spawn gametime, so the next visit's
# check_visited dedupe + cooldown read it. The caller has #cs_struct ec.var = the integer structure-id.

# Summon the owner-marker at the player position with a transient new-tag for the data-stamp step.
summon marker ~ ~ ~ {Tags:["ec.cn_struct","ec.cn_struct_new","smithed.entity"]}

# Stamp the player UUID, the structure-id, and the spawn gametime onto the new marker.
data modify entity @e[type=marker,tag=ec.cn_struct_new,limit=1] data.player_uuid set from entity @s UUID
execute store result entity @e[type=marker,tag=ec.cn_struct_new,limit=1] data.struct_id int 1 run scoreboard players get #cs_struct ec.var
execute store result entity @e[type=marker,tag=ec.cn_struct_new,limit=1] data.spawned_at long 1 run time query gametime

# Clear the transient tag — marker stays tagged ec.cn_struct for future dedupe scans.
tag @e[type=marker,tag=ec.cn_struct_new] remove ec.cn_struct_new
