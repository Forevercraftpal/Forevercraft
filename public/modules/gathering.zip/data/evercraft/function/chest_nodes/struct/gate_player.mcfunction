# === STRUCTURE CHEST — PER-PLAYER KEY GATE (the click dispatch for a struct node) ===
# Run as @s = the clicking player, AT THE NODE (owner_gate delegates here: `as @p[distance=..3] at @s`).
# Struct chests are PER-PLAYER + key-only (no waves, no keyless, no single-owner lock): every player
# opens individually with a fresh key, ONCE each. A data.preunlocked:1b node opens WITHOUT a key (still
# once per player). This gate validates the key/preunlock + the once-per-player claim, then starts the
# crack channel (-> do_open -> struct route -> do_open_struct). It NEVER opens directly — the channel
# is the bar + the resolve, exactly like the overworld path.

# --- Sneak + Appraise preview FIRST (mirrors on_click): a sneaking Gearwright L5+ previews, never opens.
execute at @s if predicate evercraft:is_sneaking if score @s ec.caffl_gw matches 5.. run return run function evercraft:chest_nodes/abilities/appraise_preview

# --- Coord-pin THIS struct node into gth_temp (mirror do_open's head; struct markers carry ec.chest_data).
data modify storage evercraft:gth_temp dtag set value "ec.chest_data"
execute store result storage evercraft:gth_temp x int 1 run data get entity @e[type=marker,tag=ec.chest_data,distance=..4,limit=1,sort=nearest] Pos[0]
execute store result storage evercraft:gth_temp y int 1 run data get entity @e[type=marker,tag=ec.chest_data,distance=..4,limit=1,sort=nearest] Pos[1]
execute store result storage evercraft:gth_temp z int 1 run data get entity @e[type=marker,tag=ec.chest_data,distance=..4,limit=1,sort=nearest] Pos[2]
data modify storage evercraft:gth_temp ctype set value 3
execute store result storage evercraft:gth_temp ctype int 1 run data get entity @e[type=marker,tag=ec.chest_data,distance=..4,limit=1,sort=nearest] data.ctype

# No node within reach (a race) -> nothing to open.
execute unless entity @e[type=marker,tag=ec.chest_data,distance=..4,limit=1] run return 0

# --- Preunlocked read: a data.preunlocked:1b struct node opens with NO key (#cn_preun carries to do_open_struct).
scoreboard players set #cn_preun ec.temp 0
execute if data entity @e[type=marker,tag=ec.chest_data,distance=..4,limit=1,sort=nearest] {data:{preunlocked:1b}} run scoreboard players set #cn_preun ec.temp 1

# --- Held fresh key? (#cn_keyed). ---
function evercraft:chest_nodes/held_key_check

# --- No key AND not preunlocked -> a soft "this vault needs a key" cue + STOP (no channel). ---
execute if score #cn_keyed ec.temp matches 0 if score #cn_preun ec.temp matches 0 if score @s ec.fx_snd matches 1.. run playsound minecraft:block.chain.fall master @s ~ ~ ~ 0.5 0.7
execute if score #cn_keyed ec.temp matches 0 if score #cn_preun ec.temp matches 0 run data modify storage evercraft:notify stage.c set value [{text:"⚙ ",color:"#B87333"},{text:"This vault is sealed",color:"gray"},{text:" — it needs a fresh key.",color:"gray"}]
execute if score #cn_keyed ec.temp matches 0 if score #cn_preun ec.temp matches 0 run scoreboard players set #ndur ec.temp 50
execute if score #cn_keyed ec.temp matches 0 if score #cn_preun ec.temp matches 0 run function evercraft:util/notify/emit
execute if score #cn_keyed ec.temp matches 0 if score #cn_preun ec.temp matches 0 run return 0

# --- Already-claimed test: is @s in this node's data.opened_by? ---
function evercraft:chest_nodes/claim/prep
data modify storage evercraft:cn_claim list set value "opened_by"
function evercraft:chest_nodes/claim/has with storage evercraft:cn_claim
execute if score #cn_inlist ec.temp matches 1 if score @s ec.fx_snd matches 1.. run playsound minecraft:block.chain.fall master @s ~ ~ ~ 0.4 0.9
execute if score #cn_inlist ec.temp matches 1 run data modify storage evercraft:notify stage.c set value [{text:"⚙ ",color:"#B87333"},{text:"You have already claimed this vault.",color:"gray"}]
execute if score #cn_inlist ec.temp matches 1 run scoreboard players set #ndur ec.temp 50
execute if score #cn_inlist ec.temp matches 1 run function evercraft:util/notify/emit
execute if score #cn_inlist ec.temp matches 1 run return 0

# --- Eligible: start the timed crack channel (-> do_open -> struct route -> do_open_struct). ---
function evercraft:chest_nodes/crack/begin
