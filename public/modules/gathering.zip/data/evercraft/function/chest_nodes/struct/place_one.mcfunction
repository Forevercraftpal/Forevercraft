# === STRUCTURE CHEST — predicate gate + place ONE struct-bound node (§11 / §14.6) ===
# MACRO. Run positioned AT the candidate ground surface (place_attempt ran `at @e[ec.chest_temp] run …
# with storage evercraft:cn_temp`). $(struct) = the predicate basename. Places a node here ONLY when
# the structure predicate holds at this exact position — so the node lands INSIDE the structure. On a
# successful place, increments #cs_placed_struct (the batch counter).

# Gate: the structure predicate MUST hold here, or this candidate is outside the structure -> no place.
$execute unless predicate evercraft:structures/structure/$(struct) run return 0

# Predicate held -> place the struct-variant node at this surface, then bump the placed counter.
function evercraft:chest_nodes/struct/place_node
scoreboard players add #cs_placed_struct ec.var 1
