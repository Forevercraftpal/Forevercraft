# === STRUCTURE CHEST — per-structure stamp wrapper: swamp_hut (§11 / §14.6) ===
# Run as @s = player. Sets the dedupe struct-id + the candidate-gate predicate name, then calls the
# shared first-visit hook. Wired as the LAST line of the swamp_hut location handler (explore handler for
# the structures explore already covered; a thin chest_nodes/struct/on_<struct> handler otherwise).
# struct = the predicate basename under predicate/structures/structure/ (the candidate gate).
scoreboard players set #cs_struct ec.var 9
data modify storage evercraft:cn_temp struct set value "swamp_hut"
function evercraft:chest_nodes/struct/on_enter
