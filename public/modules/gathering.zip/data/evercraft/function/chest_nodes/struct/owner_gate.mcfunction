# === STRUCTURE CHEST — per-player click dispatch (§11 rework 2026-06-05) ===
# Run as the interaction entity, at the node (on_click delegates here when the co-located node is
# struct-bound). The struct chest is no longer OWNER-bound — it is PER-PLAYER + key-only: EVERY player
# may open it individually with a fresh key (or a preunlocked node, no key), ONCE each. The single-owner
# gate is gone (owner_match / _uuid_match remain on disk, now unused). Delegate to gate_player as the
# nearest clicking player, at the node — gate_player does the sneak-preview / key check / once-per-player
# opened_by claim test, then starts the crack channel (-> do_open -> struct route -> do_open_struct).
execute as @p[distance=..3] at @s run function evercraft:chest_nodes/struct/gate_player
