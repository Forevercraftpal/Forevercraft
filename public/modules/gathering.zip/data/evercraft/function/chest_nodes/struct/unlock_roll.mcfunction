# === STRUCTURE CHEST — 20% auto-unlock roll (once per chest, §11 / §14.6) ===
# Run as @s = the OWNER, positioned AT the node (node_tick kept the marker position). Fires the FIRST
# time the owner comes within 3 blocks of a still-locked struct node. Removing the node's ec.cs_locked
# tag makes this once-per-chest. On a 1..20 hit -> stamp data.preunlocked:1b on the node + actionbar
# "It seems the chest is already unlocked." + a sound. A preunlocked node (do_open reads the flag)
# opens with NO key / no wear / no keyless-gate / NO trap, but STILL rolls the 50/50 harvest.

# Consume the once-per-chest guard: remove ec.cs_locked from THIS node (co-located within ~1.5).
tag @e[type=marker,tag=ec.chest_struct,tag=ec.cs_locked,distance=..1.5,limit=1,sort=nearest] remove ec.cs_locked

# Roll 1..100; on <=20 the node is pre-unlocked.
execute store result score #cs_unlock ec.temp run random value 1..100
execute if score #cs_unlock ec.temp matches 1..20 run data modify entity @e[type=marker,tag=ec.chest_struct,distance=..1.5,limit=1,sort=nearest] data.preunlocked set value 1b

# Owner cue on a successful pre-unlock (actionbar + a soft click).
execute if score #cs_unlock ec.temp matches 1..20 if score @s ec.fx_snd matches 1.. run playsound minecraft:block.copper_trapdoor.open master @s ~ ~ ~ 0.6 1.3
execute if score #cs_unlock ec.temp matches 1..20 run data modify storage evercraft:notify stage.c set value [{text:"⚙ ",color:"#B87333"},{text:"It seems the chest is already unlocked.",color:"#B87333",italic:true}]
execute if score #cs_unlock ec.temp matches 1..20 run scoreboard players set #ndur ec.temp 50
execute if score #cs_unlock ec.temp matches 1..20 run function evercraft:util/notify/emit
