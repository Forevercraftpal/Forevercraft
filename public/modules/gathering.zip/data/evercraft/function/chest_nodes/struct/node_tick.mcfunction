# === STRUCTURE CHEST — one node's owner tick (run as the ec.chest_struct marker, at the marker) ===
# (a) Owner-gated chime: a struct node is QUIET (no chime/sense) UNLESS its OWNER is within 10 blocks
#     (§11). (b) The 20% auto-unlock: when the OWNER first comes within 3 blocks of a still-locked node
#     (tag ec.cs_locked), roll once -> on a hit stamp data.preunlocked:1b + actionbar + sound.
# Owner-match uses the explore dedupe idiom (compare UUID ints via scores in a leaf), NOT a predicate
# (a predicate cannot compare a player's UUID against an arbitrary stashed value).

# No player within 10 -> nothing to do this node (the cheap early-out before the UUID stash).
execute unless entity @a[distance=..10,limit=1] run return 0

# Stash this node's owner UUID for the per-player comparison leaf.
execute store result score #cs_o0 ec.var run data get entity @s data.owner_uuid[0]
execute store result score #cs_o1 ec.var run data get entity @s data.owner_uuid[1]
execute store result score #cs_o2 ec.var run data get entity @s data.owner_uuid[2]
execute store result score #cs_o3 ec.var run data get entity @s data.owner_uuid[3]

# Tag the OWNER among players within 10 (owner_match sets ec.cs_is_owner on a full UUID match). Clear the
# transient owner tag first so a stale tag from another node never leaks.
tag @a remove ec.cs_is_owner
execute as @a[distance=..10] run function evercraft:chest_nodes/struct/owner_match

# --- (a) OWNER chime within 10 blocks (the only player who hears/sees a struct node). Pulsed on the
#     gametime %80 (~every 4s) so it is a beacon, not a drone — matches render_node's chime idiom. ---
execute store result score #cs_pulse ec.temp run time query gametime
scoreboard players operation #cs_pulse ec.temp %= #80 ec.const
execute if score #cs_pulse ec.temp matches ..2 if entity @a[tag=ec.cs_is_owner,distance=..10,limit=1] as @a[tag=ec.cs_is_owner,distance=..10] if score @s ec.fx_snd matches 2.. at @s run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.5 1.45
# A small owner-visible sparkle on the pulse so the eye + ear cue together (drawn at the node).
execute if score #cs_pulse ec.temp matches ..2 if entity @a[tag=ec.cs_is_owner,distance=..10,limit=1] run particle minecraft:wax_on ~ ~0.5 ~ 0.28 0.4 0.28 0.05 10

# --- (b) 20% AUTO-UNLOCK roll: only for a still-locked node (ec.cs_locked) when the OWNER is within 3
#     blocks. Run AS the owner (the unlock leaf rolls + stamps + cues). Removing ec.cs_locked makes the
#     roll once-per-chest. ---
execute if entity @s[tag=ec.cs_locked] as @a[tag=ec.cs_is_owner,distance=..3] run function evercraft:chest_nodes/struct/unlock_roll

# Clear the transient owner tag (housekeeping; the next node re-tags fresh).
tag @a remove ec.cs_is_owner
