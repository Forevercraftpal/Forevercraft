# Chest Node: Handle node right-click. Run as the interaction entity, at the node position.
# Mirrors fishing/splash_nodes/on_click — but a chest opens on ANY right-click (no tool gate; a key
# is checked inside do_open, not as a precondition). The 5% trap, key-wear, keyless gate, and 50/50
# harvest all live in do_open. Detected from tick.mcfunction's existence-gated interaction scan.

# Clear the interaction data (consume the click).
data remove entity @s interaction

# Struct-bound nodes (§11 / §14.6) are OWNER-bound: only the owner may interact. If the co-located node
# is struct-bound, gate the click on the clicker being the owner (others can't open it). owner_gate
# returns 0 (and plays a soft "not yours" cue) for a non-owner -> we stop before do_open/appraise.
execute if entity @e[type=marker,tag=ec.chest_struct,distance=..1.5,limit=1] run return run function evercraft:chest_nodes/struct/owner_gate

# The nearest player within ~3 blocks is the actor. Two intents:
#   - SNEAK + Appraise unlocked (Gearwright L5+, A1): PREVIEW the chest (type/tier) — does NOT open it.
#   - otherwise: START THE TIMED OPEN (crack/begin) — a boss-bar channel that resolves into do_open when
#     it fills (keyed = the 5s->1.5s harvest timer, keyless = the 15s->5s crack). Both run positioned AT
#     THE NODE (at @s), so the nearest-marker (distance=..4) coord-pin resolves to THIS node.
execute as @p[distance=..3] at @s if predicate evercraft:is_sneaking if score @s ec.caffl_gw matches 5.. run return run function evercraft:chest_nodes/abilities/appraise_preview
# Exhaustion gate (Joseph 2026-06-07): a player who has claimed the key vault AND finished the hand track
# (won or 3-fail-locked) gets nothing more — don't even start the channel (no re-crack flashing the
# Gearwright bar / inviting an XP-farm read). exhausted_gate plays its own "nothing left" cue on a block.
scoreboard players set #cn_exhausted ec.temp 0
execute as @p[distance=..3] at @s run function evercraft:chest_nodes/exhausted_gate
execute if score #cn_exhausted ec.temp matches 1 run return 0
execute as @p[distance=..3] at @s run function evercraft:chest_nodes/crack/begin
