# Chest Node: open FAIL — either a keyless-gate "lock held" OR a harvest fail/crumble (outcome 2/3).
# Run as @s, at the player (positioned at the node). The engine already granted quarter Gearwright XP +
# played the fail/crumble line on a harvest fail; the keyless "lock held" path reaches here BEFORE the
# harvest (no engine grant). Either way: no loot, no crate, no key consumed beyond the worn mark, no
# Dreamy. A distinct tactile cue so a fail still feels physical.

# A heavy "the lid won't budge" thunk — quiet, so a passer-by isn't spammed.
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.barrel.close master @s ~ ~ ~ 0.6 0.7
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.chain.fall master @s ~ ~ ~ 0.4 0.8
