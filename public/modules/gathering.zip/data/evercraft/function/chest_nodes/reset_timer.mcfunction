# Chest Node: Reset this player's spawn timer to the next cycle. Run as the player.
# Mirrors fishing/splash_nodes/reset_timer. The base timer is shortened for keyed players +
# ec.acc_spawn carriers + a leveled Gearwright (more frequent spawns, never a hard counter).
scoreboard players operation @s ec.cn_timer = #cn_timer_base ec.var

# Keyed players spawn faster (shorter wait).
execute if score @s ec.cn_haskey matches 1 run scoreboard players operation @s ec.cn_timer -= #cn_timer_keyed ec.var
# ec.acc_spawn accessory (Boosted Spawn Rate, §6) shortens the wait.
execute if score @s ec.acc_spawn matches 1 run scoreboard players operation @s ec.cn_timer -= #cn_timer_acc ec.var
# Gearwright spawn perk (L25+) shortens the wait.
execute if score @s ec.caffl_gw matches 25.. run scoreboard players operation @s ec.cn_timer -= #cn_timer_acc ec.var

# Never below a 30s floor (so spawns can't machine-gun even at full stacking).
execute if score @s ec.cn_timer matches ..600 run scoreboard players set @s ec.cn_timer 600
