# DEPRECATED 2026-06-05: superseded by the per-player open model (do_open_wave1/2 + do_open_struct); no caller.
# Chest Node: Despawn the EXACT pinned node (charges-exhausted win OR crumble). Run as @s, at the
# player, from do_open on the gth_despawn signal. Coord-pinned from gth_temp.x/y/z (set at open time)
# — NOT sort=nearest, so a multiplayer crowd never despawns the wrong node. Mirrors splash do_catch_despawn.
function evercraft:chest_nodes/do_open_despawn_pinned with storage evercraft:gth_temp
