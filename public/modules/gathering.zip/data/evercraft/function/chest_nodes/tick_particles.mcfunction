# Chest Node: Per-node ambient render (every 10 ticks, existence-gated). Mirrors splash/tick_particles.
schedule function evercraft:chest_nodes/tick_particles 10t replace

# Existence-gate: skip the entity scan entirely when no chest nodes exist.
execute if entity @e[type=marker,tag=ec.chest_data,limit=1] as @e[type=marker,tag=ec.chest_data] at @s run function evercraft:chest_nodes/render_node
