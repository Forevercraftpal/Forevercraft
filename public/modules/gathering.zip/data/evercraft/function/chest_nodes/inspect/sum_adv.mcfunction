# === GEARWRIGHT — INSPECT: ADVANTAGE-TREE PROGRESS SUMMARY (Appraise A2) ===
# Run as @s = the inspector. Reads the TARGET's (tag=ec.gw_insp_tgt) 15 advantage-tree levels
# (adv.* objectives, each 0-25), sums them into #insp_advsum, and tracks the single highest tree
# (#insp_advtop + storage insp.top_name) for the "Strongest" line. The sum (max 375) is the headline
# "advantage-tree progress" figure shown in inspect/show. All reads cross to the target via the tag
# selector; #insp_* ec.temp scratch is serial-@s race-fenced (mirrors codex profile's calc_top_skills).

scoreboard players set #insp_advsum ec.temp 0
scoreboard players set #insp_advtop ec.temp 0
data modify storage evercraft:cn_temp insp.top_name set value "—"

# Helper: for each tree, add its level to the running sum and, if it beats the current top, record it.
# Pattern repeated per tree (one #t scratch read each). Ties keep the first (listed) tree.
execute store result score #insp_t ec.temp run scoreboard players get @a[tag=ec.gw_insp_tgt,limit=1] adv.agility
scoreboard players operation #insp_advsum ec.temp += #insp_t ec.temp
execute if score #insp_t ec.temp > #insp_advtop ec.temp if score #insp_t ec.temp matches 1.. run data modify storage evercraft:cn_temp insp.top_name set value "Agility"
execute if score #insp_t ec.temp > #insp_advtop ec.temp run scoreboard players operation #insp_advtop ec.temp = #insp_t ec.temp

execute store result score #insp_t ec.temp run scoreboard players get @a[tag=ec.gw_insp_tgt,limit=1] adv.dexterity
scoreboard players operation #insp_advsum ec.temp += #insp_t ec.temp
execute if score #insp_t ec.temp > #insp_advtop ec.temp if score #insp_t ec.temp matches 1.. run data modify storage evercraft:cn_temp insp.top_name set value "Dexterity"
execute if score #insp_t ec.temp > #insp_advtop ec.temp run scoreboard players operation #insp_advtop ec.temp = #insp_t ec.temp

execute store result score #insp_t ec.temp run scoreboard players get @a[tag=ec.gw_insp_tgt,limit=1] adv.evasion
scoreboard players operation #insp_advsum ec.temp += #insp_t ec.temp
execute if score #insp_t ec.temp > #insp_advtop ec.temp if score #insp_t ec.temp matches 1.. run data modify storage evercraft:cn_temp insp.top_name set value "Evasion"
execute if score #insp_t ec.temp > #insp_advtop ec.temp run scoreboard players operation #insp_advtop ec.temp = #insp_t ec.temp

execute store result score #insp_t ec.temp run scoreboard players get @a[tag=ec.gw_insp_tgt,limit=1] adv.stealth
scoreboard players operation #insp_advsum ec.temp += #insp_t ec.temp
execute if score #insp_t ec.temp > #insp_advtop ec.temp if score #insp_t ec.temp matches 1.. run data modify storage evercraft:cn_temp insp.top_name set value "Stealth"
execute if score #insp_t ec.temp > #insp_advtop ec.temp run scoreboard players operation #insp_advtop ec.temp = #insp_t ec.temp

execute store result score #insp_t ec.temp run scoreboard players get @a[tag=ec.gw_insp_tgt,limit=1] adv.vitality
scoreboard players operation #insp_advsum ec.temp += #insp_t ec.temp
execute if score #insp_t ec.temp > #insp_advtop ec.temp if score #insp_t ec.temp matches 1.. run data modify storage evercraft:cn_temp insp.top_name set value "Vitality"
execute if score #insp_t ec.temp > #insp_advtop ec.temp run scoreboard players operation #insp_advtop ec.temp = #insp_t ec.temp

execute store result score #insp_t ec.temp run scoreboard players get @a[tag=ec.gw_insp_tgt,limit=1] adv.taskmaster
scoreboard players operation #insp_advsum ec.temp += #insp_t ec.temp
execute if score #insp_t ec.temp > #insp_advtop ec.temp if score #insp_t ec.temp matches 1.. run data modify storage evercraft:cn_temp insp.top_name set value "Taskmaster"
execute if score #insp_t ec.temp > #insp_advtop ec.temp run scoreboard players operation #insp_advtop ec.temp = #insp_t ec.temp

execute store result score #insp_t ec.temp run scoreboard players get @a[tag=ec.gw_insp_tgt,limit=1] adv.beastmaster
scoreboard players operation #insp_advsum ec.temp += #insp_t ec.temp
execute if score #insp_t ec.temp > #insp_advtop ec.temp if score #insp_t ec.temp matches 1.. run data modify storage evercraft:cn_temp insp.top_name set value "Beastmaster"
execute if score #insp_t ec.temp > #insp_advtop ec.temp run scoreboard players operation #insp_advtop ec.temp = #insp_t ec.temp

execute store result score #insp_t ec.temp run scoreboard players get @a[tag=ec.gw_insp_tgt,limit=1] adv.victorian
scoreboard players operation #insp_advsum ec.temp += #insp_t ec.temp
execute if score #insp_t ec.temp > #insp_advtop ec.temp if score #insp_t ec.temp matches 1.. run data modify storage evercraft:cn_temp insp.top_name set value "Victorian"
execute if score #insp_t ec.temp > #insp_advtop ec.temp run scoreboard players operation #insp_advtop ec.temp = #insp_t ec.temp

execute store result score #insp_t ec.temp run scoreboard players get @a[tag=ec.gw_insp_tgt,limit=1] adv.fishing
scoreboard players operation #insp_advsum ec.temp += #insp_t ec.temp
execute if score #insp_t ec.temp > #insp_advtop ec.temp if score #insp_t ec.temp matches 1.. run data modify storage evercraft:cn_temp insp.top_name set value "Fishing"
execute if score #insp_t ec.temp > #insp_advtop ec.temp run scoreboard players operation #insp_advtop ec.temp = #insp_t ec.temp

execute store result score #insp_t ec.temp run scoreboard players get @a[tag=ec.gw_insp_tgt,limit=1] adv.mining
scoreboard players operation #insp_advsum ec.temp += #insp_t ec.temp
execute if score #insp_t ec.temp > #insp_advtop ec.temp if score #insp_t ec.temp matches 1.. run data modify storage evercraft:cn_temp insp.top_name set value "Mining"
execute if score #insp_t ec.temp > #insp_advtop ec.temp run scoreboard players operation #insp_advtop ec.temp = #insp_t ec.temp

execute store result score #insp_t ec.temp run scoreboard players get @a[tag=ec.gw_insp_tgt,limit=1] adv.gathering
scoreboard players operation #insp_advsum ec.temp += #insp_t ec.temp
execute if score #insp_t ec.temp > #insp_advtop ec.temp if score #insp_t ec.temp matches 1.. run data modify storage evercraft:cn_temp insp.top_name set value "Gathering"
execute if score #insp_t ec.temp > #insp_advtop ec.temp run scoreboard players operation #insp_advtop ec.temp = #insp_t ec.temp

execute store result score #insp_t ec.temp run scoreboard players get @a[tag=ec.gw_insp_tgt,limit=1] adv.blacksmith
scoreboard players operation #insp_advsum ec.temp += #insp_t ec.temp
execute if score #insp_t ec.temp > #insp_advtop ec.temp if score #insp_t ec.temp matches 1.. run data modify storage evercraft:cn_temp insp.top_name set value "Blacksmith"
execute if score #insp_t ec.temp > #insp_advtop ec.temp run scoreboard players operation #insp_advtop ec.temp = #insp_t ec.temp

execute store result score #insp_t ec.temp run scoreboard players get @a[tag=ec.gw_insp_tgt,limit=1] adv.explorer
scoreboard players operation #insp_advsum ec.temp += #insp_t ec.temp
execute if score #insp_t ec.temp > #insp_advtop ec.temp if score #insp_t ec.temp matches 1.. run data modify storage evercraft:cn_temp insp.top_name set value "Explorer"
execute if score #insp_t ec.temp > #insp_advtop ec.temp run scoreboard players operation #insp_advtop ec.temp = #insp_t ec.temp

execute store result score #insp_t ec.temp run scoreboard players get @a[tag=ec.gw_insp_tgt,limit=1] adv.culinary
scoreboard players operation #insp_advsum ec.temp += #insp_t ec.temp
execute if score #insp_t ec.temp > #insp_advtop ec.temp if score #insp_t ec.temp matches 1.. run data modify storage evercraft:cn_temp insp.top_name set value "Culinary"
execute if score #insp_t ec.temp > #insp_advtop ec.temp run scoreboard players operation #insp_advtop ec.temp = #insp_t ec.temp

execute store result score #insp_t ec.temp run scoreboard players get @a[tag=ec.gw_insp_tgt,limit=1] adv.chemistry
scoreboard players operation #insp_advsum ec.temp += #insp_t ec.temp
execute if score #insp_t ec.temp > #insp_advtop ec.temp if score #insp_t ec.temp matches 1.. run data modify storage evercraft:cn_temp insp.top_name set value "Chemistry"
execute if score #insp_t ec.temp > #insp_advtop ec.temp run scoreboard players operation #insp_advtop ec.temp = #insp_t ec.temp
