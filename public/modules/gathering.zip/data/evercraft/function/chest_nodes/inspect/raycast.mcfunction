# === GEARWRIGHT — INSPECT: RAYCAST TO TARGET PLAYER (Appraise A2, L25; PLAN §1 A2) ===
# @s = a Gearwright L25+ player who clicked the [⚙ Inspect a nearby player] button on their Gearwright
# codex page (a /function chat button — the housing/difficulty precedent; no new trigger). Look at a
# nearby player and the raycast pins them; inspect/show reads THAT player's main-class (ec.dream_rank),
# crafting-class (ec.cf_rank), and advantage-tree progress into THIS viewer's chat display. Mirrors
# friends/invite/raycast (the canonical look-at-a-player line-of-sight scan).

# A2 gate — Appraise A2 unlocks at Gearwright Level 25. (caffl_gw is READ-ONLY here.)
execute unless score @s ec.caffl_gw matches 25.. run return run tellraw @s [{text:"⚙ ",color:"#B87333"},{text:"Inspect unlocks with Appraise A2 — Gearwright Level 25.",color:"gray"}]

# Debounce: the chat button can fire twice on a held click. One raycast per ~1s (cooldown ticked down
# in chest_nodes/tick_spawn). Silently ignore the echo click.
execute if score @s ec.gw_insp_cd matches 1.. run return 0
scoreboard players set @s ec.gw_insp_cd 20

# Unified UI-click FX (Joseph 2026-06-05): tellraw-option click — play the gated cue once per real raycast
# (after the debounce return, so the echo click stays silent).
function evercraft:fx/ui/click

# Defensively clear stale inspect tags (mirror friends/invite/raycast W3 belt-and-suspenders).
tag @a remove ec.gw_insp_tgt
tag @s remove ec.gw_inspector
tag @s add ec.gw_inspector

# Line-of-sight scan: 10 steps (0.5..5 blocks) out from the eyes; first player hit becomes the target.
# Exclude self, spectators, creative (mirror friends raycast exactly).
execute anchored eyes positioned ^ ^ ^0.5 as @a[distance=..2.5,tag=!ec.gw_inspector,gamemode=!spectator,gamemode=!creative,limit=1,sort=nearest] run tag @s add ec.gw_insp_tgt
execute unless entity @a[tag=ec.gw_insp_tgt] anchored eyes positioned ^ ^ ^1 as @a[distance=..2.5,tag=!ec.gw_inspector,gamemode=!spectator,gamemode=!creative,limit=1,sort=nearest] run tag @s add ec.gw_insp_tgt
execute unless entity @a[tag=ec.gw_insp_tgt] anchored eyes positioned ^ ^ ^1.5 as @a[distance=..2.5,tag=!ec.gw_inspector,gamemode=!spectator,gamemode=!creative,limit=1,sort=nearest] run tag @s add ec.gw_insp_tgt
execute unless entity @a[tag=ec.gw_insp_tgt] anchored eyes positioned ^ ^ ^2 as @a[distance=..2.5,tag=!ec.gw_inspector,gamemode=!spectator,gamemode=!creative,limit=1,sort=nearest] run tag @s add ec.gw_insp_tgt
execute unless entity @a[tag=ec.gw_insp_tgt] anchored eyes positioned ^ ^ ^2.5 as @a[distance=..2.5,tag=!ec.gw_inspector,gamemode=!spectator,gamemode=!creative,limit=1,sort=nearest] run tag @s add ec.gw_insp_tgt
execute unless entity @a[tag=ec.gw_insp_tgt] anchored eyes positioned ^ ^ ^3 as @a[distance=..2.5,tag=!ec.gw_inspector,gamemode=!spectator,gamemode=!creative,limit=1,sort=nearest] run tag @s add ec.gw_insp_tgt
execute unless entity @a[tag=ec.gw_insp_tgt] anchored eyes positioned ^ ^ ^3.5 as @a[distance=..2.5,tag=!ec.gw_inspector,gamemode=!spectator,gamemode=!creative,limit=1,sort=nearest] run tag @s add ec.gw_insp_tgt
execute unless entity @a[tag=ec.gw_insp_tgt] anchored eyes positioned ^ ^ ^4 as @a[distance=..2.5,tag=!ec.gw_inspector,gamemode=!spectator,gamemode=!creative,limit=1,sort=nearest] run tag @s add ec.gw_insp_tgt
execute unless entity @a[tag=ec.gw_insp_tgt] anchored eyes positioned ^ ^ ^4.5 as @a[distance=..2.5,tag=!ec.gw_inspector,gamemode=!spectator,gamemode=!creative,limit=1,sort=nearest] run tag @s add ec.gw_insp_tgt
execute unless entity @a[tag=ec.gw_insp_tgt] anchored eyes positioned ^ ^ ^5 as @a[distance=..2.5,tag=!ec.gw_inspector,gamemode=!spectator,gamemode=!creative,limit=1,sort=nearest] run tag @s add ec.gw_insp_tgt

# Found -> render the profile (handles the A3 hide-from-strangers gate inside).
execute if entity @a[tag=ec.gw_insp_tgt] run function evercraft:chest_nodes/inspect/show

# No target -> a hint (mirror friends raycast no-target message).
execute unless entity @a[tag=ec.gw_insp_tgt] run tellraw @s [{text:"⚙ ",color:"#B87333"},{text:"Look directly at a nearby player, then click ",color:"gray"},{text:"Inspect",color:"#B87333"},{text:" again.",color:"gray"}]

# Cleanup tags.
tag @s remove ec.gw_inspector
tag @a remove ec.gw_insp_tgt
