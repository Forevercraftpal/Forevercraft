# === GEARWRIGHT — INSPECT: HIDE-FROM-STRANGERS TOGGLE (Appraise A3, L50; PLAN §1 A3) ===
# @s = a Gearwright L50+ player who clicked the [Hide from strangers: ON/OFF] button on their
# Gearwright codex page (a /function chat button — housing/difficulty precedent; no new trigger).
# Flips ec.gw_hide_insp (the ONLY writer of that objective). When 1, strangers can't inspect this
# player (inspect/show refuses); friends + same-party members stay exempt (checked in inspect/show).

# A3 gate — hide-from-inspection unlocks at Gearwright Level 50. (caffl_gw is READ-ONLY here.)
execute unless score @s ec.caffl_gw matches 50.. run return run tellraw @s [{text:"⚙ ",color:"#B87333"},{text:"Hide from inspection unlocks with Appraise A3 — Gearwright Level 50.",color:"gray"}]

# Unified UI-click FX (Joseph 2026-06-05): tellraw-option click — play the gated cue once on a valid toggle
# (after the level gate). The copper-trapdoor sound below stays as the toggle's thematic confirm.
function evercraft:fx/ui/click

# Flip the flag (default/unset = 0 = visible). Snapshot into temp FIRST so the second set can't re-read
# a value the first set just wrote (the classic toggle race): if was hidden -> show, else hide.
scoreboard players set #insp_was ec.temp 0
execute if score @s ec.gw_hide_insp matches 1.. run scoreboard players set #insp_was ec.temp 1
execute if score #insp_was ec.temp matches 1 run scoreboard players set @s ec.gw_hide_insp 0
execute if score #insp_was ec.temp matches 0 run scoreboard players set @s ec.gw_hide_insp 1

# Confirm + light cue.
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.copper_trapdoor.open master @s ~ ~ ~ 0.7 1.0
execute if score @s ec.gw_hide_insp matches 1 run tellraw @s [{text:"⚙ ",color:"#B87333"},{text:"Hidden from inspection. ",color:"green"},{text:"Strangers can no longer view your profile (friends & party still can).",color:"gray"}]
execute unless score @s ec.gw_hide_insp matches 1 run tellraw @s [{text:"⚙ ",color:"#B87333"},{text:"Visible to inspection. ",color:"yellow"},{text:"Any Gearwright with Appraise can view your profile.",color:"gray"}]
