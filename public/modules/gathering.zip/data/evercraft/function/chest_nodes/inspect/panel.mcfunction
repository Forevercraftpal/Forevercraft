# === GEARWRIGHT — APPRAISE A2/A3 CODEX ACTION PANEL ===
# Run as @s when the Gearwright class-detail codex page (detail/render7) is opened. Emits the two
# Appraise player-tools as clickable chat buttons (the housing/difficulty /function-button precedent
# — usable by normal players, NO new /trigger). Each row is gated by the player's Gearwright level so
# it only appears once unlocked. Pure chat output; the 3D detail page itself is untouched.

# --- A2 INSPECT (Gearwright L25) ---
execute if score @s ec.caffl_gw matches 25.. run tellraw @s [{text:"⚙ ",color:"#B87333"},{text:"[Inspect a nearby player]",color:"#B87333",bold:true,click_event:{action:run_command,command:"/function evercraft:chest_nodes/inspect/raycast"},hover_event:{action:show_text,value:{text:"Look at a nearby player, then click — read their class ranks + advantage progress.",color:"gray"}}}]
execute if score @s ec.caffl_gw matches 5..24 run tellraw @s [{text:"⚙ ",color:"#B87333"},{text:"Inspect other players",color:"dark_gray"},{text:" — unlocks at Gearwright Level 25 (Appraise A2)",color:"dark_gray",italic:true}]

# --- A3 HIDE-FROM-INSPECTION TOGGLE (Gearwright L50) ---
execute if score @s ec.caffl_gw matches 50.. if score @s ec.gw_hide_insp matches 1 run tellraw @s [{text:"⚙ ",color:"#B87333"},{text:"Hide from strangers: ",color:"gray"},{text:"[ ON ]",color:"green",bold:true,click_event:{action:run_command,command:"/function evercraft:chest_nodes/inspect/toggle_hide"},hover_event:{action:show_text,value:{text:"Strangers can't inspect you. Click to allow inspection again (friends & party always can).",color:"gray"}}}]
execute if score @s ec.caffl_gw matches 50.. unless score @s ec.gw_hide_insp matches 1 run tellraw @s [{text:"⚙ ",color:"#B87333"},{text:"Hide from strangers: ",color:"gray"},{text:"[ OFF ]",color:"red",bold:true,click_event:{action:run_command,command:"/function evercraft:chest_nodes/inspect/toggle_hide"},hover_event:{action:show_text,value:{text:"Any Gearwright with Appraise can inspect you. Click to hide from strangers.",color:"gray"}}}]
execute if score @s ec.caffl_gw matches 25..49 run tellraw @s [{text:"⚙ ",color:"#B87333"},{text:"Hide from inspection",color:"dark_gray"},{text:" — unlocks at Gearwright Level 50 (Appraise A3)",color:"dark_gray",italic:true}]
