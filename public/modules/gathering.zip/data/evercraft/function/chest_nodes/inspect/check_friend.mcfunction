# === GEARWRIGHT — INSPECT: FRIEND-MEMBERSHIP LOOKUP (macro; Appraise A3 exemption) ===
# Macro args: self_u3 (inspector UUID[3]), tgt_u3 (target UUID[3]).
# Mirrors the friends/invite/do_accept membership idiom: the inspector's friend list lives at
# storage evercraft:friends "u<self_u3>".friends as a list of {uuid3:...} entries. If the target's
# UUID[3] is in that list, they are family -> set #insp_allow=1 (exempt from the A3 hide gate).
# Read-only on the friends storage (single shared scratch read, serial @s — race-safe like friends/).
$execute if data storage evercraft:friends "u$(self_u3)".friends[{uuid3:$(tgt_u3)}] run scoreboard players set #insp_allow ec.temp 1
