# === GEARWRIGHT — INSPECT: RENDER TARGET PROFILE (Appraise A2, L25; PLAN §1 A2) ===
# @s = the inspector (Gearwright L25+). The target is tagged ec.gw_insp_tgt (exactly one, set by
# inspect/raycast). Reads the TARGET's scores into ec.temp fakeplayers, then tellraws a profile-style
# view to the inspector: main-class rank (ec.dream_rank), crafting-class rank (ec.cf_rank), Gearwright
# level, and an advantage-tree progress summary (sum of the 15 adv.* tree levels + the top tree).
#
# A3 (PLAN §1) — HIDE FROM INSPECTION: if the target set ec.gw_hide_insp=1, STRANGERS are refused.
# Friends (friends storage) and same-party members (matching ec.party_id) are EXEMPT.

# --- A3 hide gate. Read the target's hide flag. ---
scoreboard players set #insp_hidden ec.temp 0
execute store result score #insp_hidden ec.temp run scoreboard players get @a[tag=ec.gw_insp_tgt,limit=1] ec.gw_hide_insp

# Resolve exemption (friend OR same-party). #insp_allow=1 means "may view a hidden profile".
scoreboard players set #insp_allow ec.temp 0

# Same party: both share a non-zero ec.party_id. Compare viewer's party_id to the target's.
scoreboard players set #insp_my_pty ec.temp 0
execute store result score #insp_my_pty ec.temp run scoreboard players get @s ec.party_id
scoreboard players set #insp_tg_pty ec.temp 0
execute store result score #insp_tg_pty ec.temp run scoreboard players get @a[tag=ec.gw_insp_tgt,limit=1] ec.party_id
execute if score #insp_my_pty ec.temp matches 1.. if score #insp_my_pty ec.temp = #insp_tg_pty ec.temp run scoreboard players set #insp_allow ec.temp 1

# Friend: is the target in the viewer's friends storage? Store both UUID[3]s + run the lookup macro.
execute store result score #insp_self_u3 ec.temp run data get entity @s UUID[3]
execute store result score #insp_tgt_u3 ec.temp run data get entity @a[tag=ec.gw_insp_tgt,limit=1] UUID[3]
execute store result storage evercraft:cn_temp insp.self_u3 int 1 run scoreboard players get #insp_self_u3 ec.temp
execute store result storage evercraft:cn_temp insp.tgt_u3 int 1 run scoreboard players get #insp_tgt_u3 ec.temp
function evercraft:chest_nodes/inspect/check_friend with storage evercraft:cn_temp insp

# Refuse if hidden AND not exempt.
execute if score #insp_hidden ec.temp matches 1 unless score #insp_allow ec.temp matches 1 if score @s ec.fx_snd matches 1.. run playsound minecraft:block.copper_trapdoor.close master @s ~ ~ ~ 0.6 0.8
execute if score #insp_hidden ec.temp matches 1 unless score #insp_allow ec.temp matches 1 run return run tellraw @s [{text:"⚙ ",color:"#B87333"},{text:"That player has hidden their profile from strangers.",color:"gray",italic:true}]

# --- Read the target's scores into ec.temp fakeplayers (cross-player read via the tag selector). ---
scoreboard players set #insp_drank ec.temp 0
execute store result score #insp_drank ec.temp run scoreboard players get @a[tag=ec.gw_insp_tgt,limit=1] ec.dream_rank
scoreboard players set #insp_crank ec.temp 0
execute store result score #insp_crank ec.temp run scoreboard players get @a[tag=ec.gw_insp_tgt,limit=1] ec.cf_rank
scoreboard players set #insp_gwlvl ec.temp 0
execute store result score #insp_gwlvl ec.temp run scoreboard players get @a[tag=ec.gw_insp_tgt,limit=1] ec.caffl_gw

# Advantage-tree progress = sum of the 15 tree levels (each 0-25, max 375). Computed on the TARGET.
function evercraft:chest_nodes/inspect/sum_adv

# --- Render: a profile-style chat block addressed to the inspector. ---
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.7 1.1
tellraw @s ""
tellraw @s [{text:"⚙ ",color:"#B87333"},{text:"Appraise — Player Profile",color:"#B87333",bold:true}]
tellraw @s [{text:"  ",color:"gray"},{selector:"@a[tag=ec.gw_insp_tgt,limit=1]",color:"white",bold:true}]
tellraw @s [{text:"  Main class rank: ",color:"gray"},{score:{name:"#insp_drank",objective:"ec.temp"},color:"gold",bold:true},{text:"  (Dreaming)",color:"dark_gray"}]
tellraw @s [{text:"  Crafting class rank: ",color:"gray"},{score:{name:"#insp_crank",objective:"ec.temp"},color:"aqua",bold:true},{text:"  (Artisan)",color:"dark_gray"}]
tellraw @s [{text:"  Gearwright level: ",color:"gray"},{score:{name:"#insp_gwlvl",objective:"ec.temp"},color:"#B87333",bold:true},{text:"/100",color:"dark_gray"}]
tellraw @s [{text:"  Advantage trees: ",color:"gray"},{score:{name:"#insp_advsum",objective:"ec.temp"},color:"green",bold:true},{text:" total tree levels",color:"dark_gray"}]
execute if score #insp_advtop ec.temp matches 1.. run tellraw @s [{text:"   Strongest: ",color:"gray"},{storage:"evercraft:cn_temp",nbt:"insp.top_name",interpret:false,color:"green"},{text:" — ",color:"dark_gray"},{score:{name:"#insp_advtop",objective:"ec.temp"},color:"green"},{text:"/25",color:"dark_gray"}]
execute if score #insp_hidden ec.temp matches 1 run tellraw @s [{text:"  ",color:"gray"},{text:"(profile hidden from strangers — shown because you are family/party)",color:"dark_gray",italic:true}]
tellraw @s ""
