# Chest Node: Per-node particle render + 25-block chime. Run as node marker, at node position.
# Mirrors fishing/splash_nodes/render_node (sparkle + a gametime-pulsed chime). Findability cue:
# a gold sparkle + a chime (block.amethyst_block.chime) audible to players within 25 blocks, pulsed
# on a gametime modulo (~every 4s) so it never spams. Perf-safe: existence-gated (tick_particles) +
# distance-gated (only nodes within 48 blocks of a player do the per-frame particle).

# Distance-gate the per-frame particle: only render when a player is within 48 blocks of THIS node.
execute unless entity @a[distance=..48,limit=1] run return 0

# Struct-bound nodes (§11 / §14.6) are PLAYER-BOUND + QUIET: their chime/sparkle is OWNER-gated to 10
# blocks by chest_nodes/struct/node_tick, NOT the public 25-block render here. Skip the whole public
# render for them so non-owners never see/hear a struct node (this file stays the overworld render).
execute if data entity @s {data:{struct_bound:1b}} run return 0

# Gold sparkle bob over the chest.
particle minecraft:wax_on ~0.5 ~0.55 ~0.5 0.18 0.25 0.18 0.02 4
particle minecraft:end_rod ~0.5 ~0.4 ~0.5 0.1 0.15 0.1 0.01 2

# --- 25-block CHIME, pulsed on gametime % 560 (~every 28s, Joseph 2026-06-12 — 7× slower). ---
# Was %80 (~4s), which droned in dense chest-node zones. Now a beacon at ~28s cadence.
# (Same splash render_node modulo idiom, just a longer period; #560 ec.const is seeded at load.)
execute store result score #cn_pulse ec.temp run time query gametime
scoreboard players operation #cn_pulse ec.temp %= #560 ec.const
# Pulse retuned 1.4 -> 1.498 (C#5, the fifth of F#) so the ambient chime sits inside the chest-node
# F#-major treasure identity (the do_open_success chord + the loot-sense F#5 bell; 2026-06-09).
execute if score #cn_pulse ec.temp matches ..2 as @a[distance=..25] if score @s ec.fx_snd matches 2.. at @s run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.6 1.498
# A bigger sparkle burst on the chime pulse so the eye + ear cue together.
execute if score #cn_pulse ec.temp matches ..2 run particle minecraft:wax_on ~0.5 ~0.5 ~0.5 0.3 0.4 0.3 0.06 14

# --- Loot Sense T4-T6 LOCATION-MARKER glow column (data.mark_glow frames, set by abilities/loot_sense_
#     mark). When >=1, draw a tall glowing waypoint this frame + decrement the frame counter; this rides
#     the node's own existence-gated 10t render so the marker needs no per-player tick (right perf shape).
#     Default 0 if absent (store result leaves #cn_glow untouched -> seed it first). ---
scoreboard players set #cn_glow ec.temp 0
execute store result score #cn_glow ec.temp run data get entity @s data.mark_glow
execute if score #cn_glow ec.temp matches 1.. run particle minecraft:glow ~0.5 ~1.4 ~0.5 0.06 0.9 0.06 0.01 6
execute if score #cn_glow ec.temp matches 1.. run particle minecraft:end_rod ~0.5 ~1.8 ~0.5 0.04 0.5 0.04 0.005 3
execute if score #cn_glow ec.temp matches 1.. run scoreboard players remove #cn_glow ec.temp 1
execute if score #cn_glow ec.temp matches 1.. store result entity @s data.mark_glow int 1 run scoreboard players get #cn_glow ec.temp

# Zone-claim highlight (Joseph #73 2026-06-13) — gold for guild, pink for house, both 24b
function evercraft:fx/zone_node_highlight
