# Chest Node: open SUCCESS — the harvest roll won (outcome 1). Run as @s, at the player (positioned at
# the node). The engine already granted FULL Gearwright XP + played the success line. This file is the
# success-only reward: the loot resolve (30% crate / 70% goodies-pranks-traps + materials), the +5%
# located-map roll, and the Dreamy Pull launch (which boosts the crate threshold on a landed pull).

# Satisfying open sound — the F#-major "treasure lift" (Joseph 2026-06-09: note-block palette, replaces
# the chest creak + copper clack that grated on repeat). One chord = the recognizable "chest!" signature;
# THREE randomized voicings of it so the 1000th open still lands fresh (micro-variation defeats fatigue,
# the shared chord keeps the identity). Soft timbres on purpose: harp lead + harmony, one quiet chime/bell
# sparkle on top, and the familiar XP-orb glint kept underneath. All pitches are F# major (F#4 1.0 /
# A#4 1.26 / C#5 1.498 / F#5 2.0). #cn_jingle = shared scratch, written + consumed only here.
execute if score @s ec.fx_snd matches 1.. store result score #cn_jingle ec.temp run random value 1..3
# Voicing 1 — root position (warm, grounded)
execute if score @s ec.fx_snd matches 1.. if score #cn_jingle ec.temp matches 1 run playsound minecraft:block.note_block.harp master @s ~ ~ ~ 0.7 1.0
execute if score @s ec.fx_snd matches 1.. if score #cn_jingle ec.temp matches 1 run playsound minecraft:block.note_block.harp master @s ~ ~ ~ 0.5 1.26
execute if score @s ec.fx_snd matches 1.. if score #cn_jingle ec.temp matches 1 run playsound minecraft:block.note_block.chime master @s ~ ~ ~ 0.35 2.0
# Voicing 2 — lifted (brighter, "good find" lean)
execute if score @s ec.fx_snd matches 1.. if score #cn_jingle ec.temp matches 2 run playsound minecraft:block.note_block.harp master @s ~ ~ ~ 0.7 1.26
execute if score @s ec.fx_snd matches 1.. if score #cn_jingle ec.temp matches 2 run playsound minecraft:block.note_block.harp master @s ~ ~ ~ 0.5 1.498
execute if score @s ec.fx_snd matches 1.. if score #cn_jingle ec.temp matches 2 run playsound minecraft:block.note_block.chime master @s ~ ~ ~ 0.35 2.0
# Voicing 3 — open fifth (airier; bell sparkle instead of chime)
execute if score @s ec.fx_snd matches 1.. if score #cn_jingle ec.temp matches 3 run playsound minecraft:block.note_block.harp master @s ~ ~ ~ 0.7 1.0
execute if score @s ec.fx_snd matches 1.. if score #cn_jingle ec.temp matches 3 run playsound minecraft:block.note_block.harp master @s ~ ~ ~ 0.5 1.498
execute if score @s ec.fx_snd matches 1.. if score #cn_jingle ec.temp matches 3 run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.3 2.0
# The familiar XP-orb glint beneath the chord (kept from the original mix).
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.experience_orb.pickup master @s ~ ~ ~ 0.5 1.2

# --- Compute the crate-threshold BOOST for this open (Dreamy + Appraise), used by resolve. ---
# Base crate channel = 30% (resolve owns the literal). The boost RAISES that 30 threshold. Two feeds:
#   (a) Dreamy Pull about to fire (over-level zones trigger it less; here we use the resolved overlvl
#       flag as a proxy that a Dreamy good-find is in play) -> +10 to the threshold.
#   (b) Appraise good-outcome boost (#caff_gw_apprz_*, stored per-mille /10): folded into the threshold.
# #cn_cratebost is the single boost score the resolver reads. Single writer = here.
scoreboard players set #cn_cratebost ec.temp 0
# Dreamy good-find proxy: a won harvest in a normal (non-over-leveled) zone is the rich case -> +10.
execute unless score @s ec.gth_overlvl matches 1 run scoreboard players add #cn_cratebost ec.temp 10
# Appraise good-outcome boost by Gearwright level (per-mille constants /10 -> percent points).
execute if score @s ec.caffl_gw matches 5..24 run scoreboard players set #cn_apprz ec.temp 10
execute if score @s ec.caffl_gw matches 25..49 run scoreboard players set #cn_apprz ec.temp 25
execute if score @s ec.caffl_gw matches 50..99 run scoreboard players set #cn_apprz ec.temp 50
execute if score @s ec.caffl_gw matches 100.. run scoreboard players set #cn_apprz ec.temp 100
execute if score @s ec.caffl_gw matches 5.. run scoreboard players operation #cn_apprz ec.temp /= #cn_c10 ec.var
execute if score @s ec.caffl_gw matches 5.. run scoreboard players operation #cn_cratebost ec.temp += #cn_apprz ec.temp
# Crate Luck Charm (ec.acc_cratepct, §6) adds its OWN dedicated +8% (lore "+8% chance a chest yields a
# crate") — a literal, NOT the shared #caff_gw_crateodds (=5, also used by the Gearwright L50 perk
# below). The Gearwright crate-odds perk keeps its own +5 via the shared constant.
execute if score @s ec.acc_cratepct matches 1 run scoreboard players add #cn_cratebost ec.temp 8
execute if score @s ec.caffl_gw matches 50.. run scoreboard players operation #cn_cratebost ec.temp += #caff_gw_crateodds ec.var
# Per-player WAVE richness (§2 rework): the caller (do_open_wave1/2 / do_open_struct) sets #cn_richbonus
# — 0 for a standard open, 50 for the wave-2 key vault — to push this open toward the crate channel.
# Folded in here so the rich wave lands more crates (resolve caps the realized threshold at 80).
execute if score #cn_richbonus ec.temp matches 1.. run scoreboard players operation #cn_cratebost ec.temp += #cn_richbonus ec.temp

# --- Resolve the loot (30%+boost crate channel / else 70% goodies-pranks-traps + materials). ---
function evercraft:tinkering/chest_drop/resolve

# --- +5% independent located-map roll (§5 / §14.10). SHIPPED: a landed roll gives a REAL located map
#     (map_roll -> map_grant -> map_select -> map_award) with per-player hard no-repeat + global
#     soft-avoid. 6 per-structure tables under evercraft:tinkering/chest_drop/maps/<struct>. ---
function evercraft:tinkering/chest_drop/map_roll

# --- UNIFIED harvest bonus (Part C): the coin + cross-node-custom layer. CRATE CHANNEL OFF
#     (#hb_crate_thresh 0) — the chest already owns its crate channel via resolve above (a bonus_crate
#     here would DOUBLE-dip), so harvest_bonus contributes ONLY the Forever-Coin (3%) + custom (2%)
#     layer chests previously lacked. #hb_cfg 1 = caller configures all three. ---
scoreboard players set #hb_crate_thresh ec.temp 0
scoreboard players set #hb_coin_pct ec.temp 3
scoreboard players set #hb_custom_pct ec.temp 2
scoreboard players set #hb_cfg ec.temp 1
function evercraft:gather/harvest_bonus

# --- Launch the Dreamy Pull bonus mini-game (source 5 = chest). Base loot already awarded, so this
#     never gates the open. A landed Dreamy good-find is the "boosts the crate threshold" payoff (§2). ---
scoreboard players set @s ec.dp_source 5
function evercraft:dreamy_pull/maybe_trigger

# --- Reset the per-open wave richness so a LATER normal open (or a non-wave caller) isn't accidentally
#     rich. #cn_richbonus is set per-open by the wave callers; clear it here, the single consumer. ---
scoreboard players set #cn_richbonus ec.temp 0

# --- ADDITIVE decor drop (Joseph 2026-06-14): ~30% bonus build-free Blueprint on top of the loot above
#     (+ small idea chance). Decor IDEAS come only from structure nodes now; chests/crates give Blueprints. ---
function evercraft:chest_nodes/decor_roll
