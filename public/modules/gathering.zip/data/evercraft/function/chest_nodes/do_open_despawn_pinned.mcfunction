# RE-WIRED 2026-06-05: called by do_open_struct — a struct vault is SINGLE-USE and VANISHES on opening
# (the intended feature). Overworld nodes still persist + despawn on the 7-min timer instead.
# Chest Node: coord-pinned despawn macro. Called with storage evercraft:gth_temp {x:X, y:Y, z:Z}
# (the open-time coord-pin). Positions at the pinned coords and runs despawn_node AS the marker there
# (despawn_node kills the co-located visual + interaction + the marker self). distance=..2 tolerance;
# NEVER a racy distance=..4 sort=nearest. Mirrors splash do_catch_despawn_pinned.
$execute positioned $(x) $(y) $(z) as @e[type=marker,tag=ec.chest_data,distance=..2,limit=1,sort=nearest] at @s run function evercraft:chest_nodes/despawn_node
