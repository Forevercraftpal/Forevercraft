# Chest Node: Remove node entities with a fadeout. Run as node marker, at node position.
# Mirrors fishing/splash_nodes/despawn_node (fadeout particles, kill the visual + interaction + marker).

# Fadeout particles.
particle minecraft:smoke ~ ~0.4 ~ 0.25 0.2 0.25 0.01 8
particle minecraft:wax_off ~ ~0.4 ~ 0.2 0.2 0.2 0.02 6

# Kill the visual item_display + interaction hitbox co-located with this node.
kill @e[type=item_display,tag=ec.chest_visual,distance=..1.5]
kill @e[type=interaction,tag=ec.chest_click,distance=..1.5]

# Kill self (the data marker).
kill @s
