# Chest Node: ONE placement candidate (recursive). Run as the player, at the player.
# Tries a nearby spot for a solid GROUND surface (air-above-solid, never on liquid); on a miss it
# recurses until #cn_tries runs out. Mirrors fishing/splash_nodes/place_attempt, but scans for solid
# ground (chests sit on the floor) instead of a liquid surface.
# Shared scratch (set by place): #cn_tries (budget), #cn_placed (success flag), #cn_scan (scan state).

# Out of tries — give up this cycle.
execute if score #cn_tries ec.temp matches ..0 run return 0
scoreboard players remove #cn_tries ec.temp 1

# Player block coords + a random nearby offset (-9..9 on X/Z), starting 4 blocks above so the
# downward scan begins in air over the ground (matches splash's start-above approach).
execute store result score #cn_tx ec.temp run data get entity @s Pos[0] 1
execute store result score #cn_ty ec.temp run data get entity @s Pos[1] 1
execute store result score #cn_tz ec.temp run data get entity @s Pos[2] 1
execute store result score #cn_ox ec.temp run random value -9..9
execute store result score #cn_oz ec.temp run random value -9..9
scoreboard players operation #cn_tx ec.temp += #cn_ox ec.temp
scoreboard players operation #cn_tz ec.temp += #cn_oz ec.temp
scoreboard players add #cn_ty ec.temp 4

# Summon a candidate marker and move it to (offsetX, playerY+4, offsetZ).
summon marker ~ ~ ~ {Tags:["ec.chest_temp"]}
execute store result entity @e[type=marker,tag=ec.chest_temp,limit=1] Pos[0] double 1 run scoreboard players get #cn_tx ec.temp
execute store result entity @e[type=marker,tag=ec.chest_temp,limit=1] Pos[1] double 1 run scoreboard players get #cn_ty ec.temp
execute store result entity @e[type=marker,tag=ec.chest_temp,limit=1] Pos[2] double 1 run scoreboard players get #cn_tz ec.temp

# Scan DOWN (up to 12) for an air-block-over-solid-ground surface — but ONLY if the start (playerY+4)
# is OPEN AIR. If the random offset landed inside terrain (a hill/cliff), scanning down would punch
# through solid into a CAVE and bury the node out of sight; reject such candidates (Joseph 2026-06-03).
scoreboard players set #cn_scan ec.temp 12
scoreboard players set #cn_found ec.temp 0
execute as @e[type=marker,tag=ec.chest_temp,limit=1] at @s if block ~ ~ ~ #evercraft:spawnable_air store success score #cn_found ec.temp run function evercraft:chest_nodes/scan_surface

# No surface at this candidate — drop it and try another.
execute if score #cn_found ec.temp matches 0 run kill @e[type=marker,tag=ec.chest_temp]
execute if score #cn_found ec.temp matches 0 run return run function evercraft:chest_nodes/place_attempt

# Found a surface — place the node here, clean up, flag success.
execute at @e[type=marker,tag=ec.chest_temp,limit=1] run function evercraft:chest_nodes/place_node
kill @e[type=marker,tag=ec.chest_temp]
scoreboard players set #cn_placed ec.temp 1
