# === CHEST-NODE — WAVE 2 OPEN (held-key RICH wave, per-player overworld) ===
# Run as @s, positioned AT THE NODE, AFTER do_open's coord-pin + claim/prep, when @s HELD a fresh key
# (#cn_keyed=1) and is not yet w2_claimed (do_open enforces the once-per-player gate). Grants the RICHER
# wave-2 loot, WEARS the key (only here — the key is consumed exactly when it grants the wave), and
# records the per-(player,chest) w2_claimed claim. Independent of the hand track: a key-carrier gets
# wave 2 with the key AND can still bare-hand wave 1 on the same node.

# --- Wear the key NOW (a key grants wave 2 -> it's consumed). One key, mainhand priority. ---
function evercraft:chest_nodes/wear_held_key

# --- Gearwright XP (full WIN grant): src 5 -> class 7, same chain as a chest win. ---
function evercraft:gather/read_rarity
function evercraft:gather/rarity_xp
scoreboard players set @s ec.gth_win 1
scoreboard players set @s ec.gth_src 5
function evercraft:gather/grant_xp

# --- Loot: RICHER wave. #cn_richbonus 50 pushes do_open_success's crate-threshold toward the crate
#     channel (resolve caps the realized threshold at 80). do_open_success folds it into #cn_cratebost. ---
scoreboard players set #cn_richbonus ec.temp 50
function evercraft:chest_nodes/do_open_success

# --- Record the wave-2 claim on the marker (UUID appended to data.w2_claimed). ---
data modify storage evercraft:cn_claim list set value "w2_claimed"
function evercraft:chest_nodes/claim/add with storage evercraft:cn_claim

# --- Themed success line (non-bold actionbar via the notify queue). ---
data modify storage evercraft:notify stage.c set value [{text:"⚙ ",color:"#B87333"},{text:"The key turns",color:"gold"},{text:" — the vault gives its richest wave! ",color:"gray"},{text:"(Wave 2)",color:"gold"}]
scoreboard players set #ndur ec.temp 55
function evercraft:util/notify/emit
