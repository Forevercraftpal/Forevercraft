# === CHEST-NODE — KEYLESS OPEN GATE (§2 step 3, §14.9 open clamp) ===
# Run as @s (no usable key this attempt). Computes the keyless open chance, rolls it, and sets
# #cn_openpass (1=open proceeds / 0=lock held). SINGLE WRITER of #cn_openpct ec.temp (the open%).
#
# open% = 1 (flat 1/100 base for any player) -> the Gearwright keyless table (10..40% at L10/25/50/75/
# 100, P1 constants #caff_gw_keyless_*) + the secondary open perk (#caff_gw_openpct, L-gated) +
# ec.acc_openpct accessory (Master Key Fob, §6). Clamped <=95 (§14.9, mirrors compute_success #gth_cap95)
# — never a 100% keyless open.

# Base 1% (the no-class/no-key fallback, §2).
scoreboard players set #cn_openpct ec.temp 1

# --- Gearwright keyless table: pick the HIGHEST unlocked row <= the player's level (L10 unlocks). ---
execute if score @s ec.caffl_gw matches 10..24 run scoreboard players operation #cn_openpct ec.temp = #caff_gw_keyless_10 ec.var
execute if score @s ec.caffl_gw matches 25..49 run scoreboard players operation #cn_openpct ec.temp = #caff_gw_keyless_25 ec.var
execute if score @s ec.caffl_gw matches 50..74 run scoreboard players operation #cn_openpct ec.temp = #caff_gw_keyless_50 ec.var
execute if score @s ec.caffl_gw matches 75..99 run scoreboard players operation #cn_openpct ec.temp = #caff_gw_keyless_75 ec.var
execute if score @s ec.caffl_gw matches 100.. run scoreboard players operation #cn_openpct ec.temp = #caff_gw_keyless_100 ec.var

# --- Secondary open perk: a leveled Gearwright (L50+) adds the +open% magnitude (#caff_gw_openpct). ---
execute if score @s ec.caffl_gw matches 50.. run scoreboard players operation #cn_openpct ec.temp += #caff_gw_openpct ec.var

# --- ec.acc_openpct accessory (Master Key Fob, §6) adds its OWN dedicated +10% open chance (lore "+10%
#     chance to open a chest successfully") — a literal, NOT the shared #caff_gw_openpct (=5, also used by
#     the Gearwright L50 perk above). The flag is 0/1; when set, add the dedicated accessory magnitude. ---
execute if score @s ec.acc_openpct matches 1 run scoreboard players add #cn_openpct ec.temp 10

# --- ≤95 open clamp (§14.9): never a 100% keyless open. Single-writer clamp, mirrors #gth_cap95. ---
execute if score #cn_openpct ec.temp > #gth_cap95 ec.var run scoreboard players operation #cn_openpct ec.temp = #gth_cap95 ec.var

# Roll the open gate. roll <= open% -> the lock yields.
execute store result score #cn_openroll ec.temp run random value 1..100
scoreboard players set #cn_openpass ec.temp 0
execute if score #cn_openroll ec.temp <= #cn_openpct ec.temp run scoreboard players set #cn_openpass ec.temp 1
