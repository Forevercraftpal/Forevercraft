# Chest Node: Read a held key-bag's FRESH-key presence to set ec.cn_keytype. Run as @s (player holding
# a {key_bag:true} item). Mirrors the dungeon key-tally read but for the bag's on-item presence flags
# (§4). ONLY fresh keys boost spawn/open (worn/cracked are bagged but inert for chests). Dungeon
# dominates a tie (checked last).
#
# The key_satchel deposit/withdraw flow (P4b) stamps a BOOLEAN presence flag whenever a fresh count
# crosses 0: ks_dhas=1 while any fresh dungeon key is bagged, ks_chas=1 while any fresh trial pass is
# bagged (item predicates can range-match an int count only via such a boolean — they cannot test
# `>=1` on a custom_data int directly). So this scan keys on ks_dhas:1 / ks_chas:1, set/cleared by the
# bag handlers in lock-step with the actual fresh counts.

# Crafting-key bag stock (a fresh trial pass inside the bag) -> keytype 1.
execute if items entity @s container.* *[custom_data~{key_bag:true,ks_chas:1}] run scoreboard players set @s ec.cn_keytype 1
execute if items entity @s weapon.offhand *[custom_data~{key_bag:true,ks_chas:1}] run scoreboard players set @s ec.cn_keytype 1

# Dungeon-key bag stock (a fresh dungeon key inside the bag) -> keytype 2 (dominates a tie, checked last).
execute if items entity @s container.* *[custom_data~{key_bag:true,ks_dhas:1}] run scoreboard players set @s ec.cn_keytype 2
execute if items entity @s weapon.offhand *[custom_data~{key_bag:true,ks_dhas:1}] run scoreboard players set @s ec.cn_keytype 2
