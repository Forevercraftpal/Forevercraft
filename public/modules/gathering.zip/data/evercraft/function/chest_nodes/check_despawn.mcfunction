# Chest Node: Check if this node should despawn (60s unopened-node watchdog). Run as node marker.
# Mirrors splash/check_despawn, but the chest lifetime is 60s (#cn_despawn_ticks = 1200t, §10.2).
# Structure-bound nodes (data.struct_bound:1b, set by P2.5) PERSIST until gathered — they skip the
# 60s timer entirely. Guarded here so the P2.5 phase needs no edit to this file.

# Structure-bound nodes never auto-despawn (they wait for their owner to gather them, §11 / §14.6).
execute if data entity @s {data:{struct_bound:1b}} run return 0

# Elapsed ticks since spawn.
execute store result score #cn_now ec.temp run time query gametime
execute store result score #cn_spawn ec.temp run data get entity @s data.spawn_time
scoreboard players operation #cn_elapsed ec.temp = #cn_now ec.temp
scoreboard players operation #cn_elapsed ec.temp -= #cn_spawn ec.temp

# Despawn an unopened overworld node after 60s (1200 ticks).
execute if score #cn_elapsed ec.temp >= #cn_despawn_ticks ec.var at @s run function evercraft:chest_nodes/despawn_node
