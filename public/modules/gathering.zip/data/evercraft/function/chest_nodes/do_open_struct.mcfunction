# === CHEST-NODE — STRUCTURE OPEN (per-player single key-open, NO waves) ===
# Run as @s, positioned AT THE NODE, from do_open's struct route. The KEY (or preunlocked status) was
# already verified by struct/gate_player before the channel started, AND gate_player confirmed @s is not
# yet in data.opened_by — so this is the once-per-player open of a struct vault. NO keyless, NO wave 2:
# a struct chest is a single standard-loot open per player. Persists (no despawn timer, as today).
#
# #cn_preun ec.temp (set by gate_player, re-read in do_open) = 1 for a data.preunlocked:1b node: those
# open WITHOUT a key (and so WITHOUT wearing one). A keyed open (preun 0) wears exactly one held key.

# --- Re-verify a HELD key at channel FINISH (anti-swap, Joseph 2026-06-05). The struct route in do_open
#     returns BEFORE do_open's held_key_check, so confirm a fresh key is STILL held here (unless preunlocked):
#     a player who swapped the key to their bag during the ~1.5-5s channel must not get a free struct open.
#     (Overworld wave 2 is already immune — do_open re-checks the held key at finish before dispatching.) ---
function evercraft:chest_nodes/held_key_check
execute if score #cn_preun ec.temp matches 0 if score #cn_keyed ec.temp matches 0 if score @s ec.fx_snd matches 1.. run playsound minecraft:block.chain.fall master @s ~ ~ ~ 0.4 0.8
execute if score #cn_preun ec.temp matches 0 if score #cn_keyed ec.temp matches 0 run data modify storage evercraft:notify stage.c set value [{text:"⚙ ",color:"#B87333"},{text:"The key slipped from your hand",color:"gray"},{text:" — the vault stays sealed.",color:"gray"}]
execute if score #cn_preun ec.temp matches 0 if score #cn_keyed ec.temp matches 0 run scoreboard players set #ndur ec.temp 50
execute if score #cn_preun ec.temp matches 0 if score #cn_keyed ec.temp matches 0 run function evercraft:util/notify/emit
execute if score #cn_preun ec.temp matches 0 if score #cn_keyed ec.temp matches 0 run return 0

# --- Wear the key only on a real keyed open (NOT a preunlocked node — nothing was held / consumed). ---
execute if score #cn_preun ec.temp matches 0 run function evercraft:chest_nodes/wear_held_key

# --- Gearwright XP (full WIN grant): src 5 -> class 7, same chain as a chest win. ---
function evercraft:gather/read_rarity
function evercraft:gather/rarity_xp
scoreboard players set @s ec.gth_win 1
scoreboard players set @s ec.gth_src 5
function evercraft:gather/grant_xp

# --- Loot: standard chest ("just the key open" — no rich boost, no waves). #cn_richbonus 0. ---
scoreboard players set #cn_richbonus ec.temp 0
function evercraft:chest_nodes/do_open_success

# --- Themed success line (non-bold actionbar via the notify queue). ---
data modify storage evercraft:notify stage.c set value [{text:"⚙ ",color:"#B87333"},{text:"You unseal the vault.",color:"gold"},{text:" ",color:"gray"},{text:"(Structure Chest)",color:"gold"}]
scoreboard players set #ndur ec.temp 55
function evercraft:util/notify/emit

# --- SINGLE-USE DESPAWN (Joseph 2026-06-05): a struct vault is opened ONCE and VANISHES — that is the
# intended feature, full stop. No persist, no per-player re-open, no opened_by dedup (the §2 rework's
# persist+dedup model leaked and let crates be reopened forever). Coord-pinned despawn of THIS exact
# node via gth_temp (set by gate_player/do_open's HEAD pin) — kills the marker + visual + interaction. ---
function evercraft:chest_nodes/do_open_despawn_pinned with storage evercraft:gth_temp
