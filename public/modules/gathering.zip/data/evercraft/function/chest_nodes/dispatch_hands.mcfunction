# === CHEST-NODE — HANDS DISPATCH (overworld wave-1 / keyless track) ===
# Run as @s, AT THE NODE, from do_open when NO fresh key is held (#cn_keyed=0) on an OVERWORLD node.
# Wave 1 = bare hands: up to 3 keyless attempts; a pass grants wave 1 (once per player); 3 fails ->
# the player is hand-locked on this chest (wave 1 lost — only a key reveals wave 2). Per-(player,chest)
# state on the marker: w1_claimed (won the wave) / the 3-fail ladder w1_t1 -> w1_t2 -> w1_locked. The
# rung is set-membership on the NODE (not a player-side counter), so leaving and returning can't reset
# it — a player truly gets 3 hand attempts per chest, then needs a key. claim/prep already ran in do_open.

# --- Already WON wave 1 here? -> a "a key would reveal a deeper wave" cue (no re-open). ---
data modify storage evercraft:cn_claim list set value "w1_claimed"
function evercraft:chest_nodes/claim/has with storage evercraft:cn_claim
execute if score #cn_inlist ec.temp matches 1 if score @s ec.fx_snd matches 1.. run playsound minecraft:block.chain.fall master @s ~ ~ ~ 0.4 0.9
execute if score #cn_inlist ec.temp matches 1 run data modify storage evercraft:notify stage.c set value [{text:"⚙ ",color:"#B87333"},{text:"Your hands have already opened this",color:"gray"},{text:" — a key would reveal a deeper wave.",color:"gray"}]
execute if score #cn_inlist ec.temp matches 1 run scoreboard players set #ndur ec.temp 55
execute if score #cn_inlist ec.temp matches 1 run function evercraft:util/notify/emit
execute if score #cn_inlist ec.temp matches 1 run return 0

# --- Already hand-LOCKED here (3 fails)? -> a "only a key will open it now" cue (no attempt). ---
data modify storage evercraft:cn_claim list set value "w1_locked"
function evercraft:chest_nodes/claim/has with storage evercraft:cn_claim
execute if score #cn_inlist ec.temp matches 1 if score @s ec.fx_snd matches 1.. run playsound minecraft:block.chain.fall master @s ~ ~ ~ 0.4 0.9
execute if score #cn_inlist ec.temp matches 1 run data modify storage evercraft:notify stage.c set value [{text:"⚙ ",color:"#B87333"},{text:"The lock has beaten your hands",color:"gray"},{text:" — only a key will open it now.",color:"gray"}]
execute if score #cn_inlist ec.temp matches 1 run scoreboard players set #ndur ec.temp 55
execute if score #cn_inlist ec.temp matches 1 run function evercraft:util/notify/emit
execute if score #cn_inlist ec.temp matches 1 run return 0

# --- Roll the keyless open gate (sets #cn_openpass: 1=hands win, 0=lock held). ---
function evercraft:chest_nodes/keyless_gate

# --- PASS -> wave 1 (clears the streak inside do_open_wave1). ---
execute if score #cn_openpass ec.temp matches 1 run return run function evercraft:chest_nodes/do_open_wave1

# --- FAIL -> advance the per-(player,chest) attempt LADDER on the MARKER (interleave-proof). ---
# A player-side streak counter would reset when the player walks to another chest, so 3 fails could be
# dodged by interleaving. Instead the rung is recorded on THIS node as set-membership: not-yet-tried ->
# w1_t1 (fail 1) -> w1_t2 (fail 2) -> w1_locked (fail 3). Leaving and returning can't lower a rung, so a
# player truly gets 3 hand attempts on a given chest, then needs a key. The lock-held cue fires first.
function evercraft:chest_nodes/do_open_fail

# Read this player's current rung: rung2 = already in w1_t2 (=> this is fail #3); rung1 = in w1_t1
# (=> at least fail #2). claim/has overwrites #cn_inlist, so snapshot each before the next call.
data modify storage evercraft:cn_claim list set value "w1_t2"
function evercraft:chest_nodes/claim/has with storage evercraft:cn_claim
scoreboard players operation #cn_rung2 ec.temp = #cn_inlist ec.temp
data modify storage evercraft:cn_claim list set value "w1_t1"
function evercraft:chest_nodes/claim/has with storage evercraft:cn_claim
scoreboard players operation #cn_rung1 ec.temp = #cn_inlist ec.temp

# Fail #3 (was on rung 2) -> HAND-LOCK this chest for this player + a firm line.
execute if score #cn_rung2 ec.temp matches 1 run data modify storage evercraft:cn_claim list set value "w1_locked"
execute if score #cn_rung2 ec.temp matches 1 run function evercraft:chest_nodes/claim/add with storage evercraft:cn_claim
execute if score #cn_rung2 ec.temp matches 1 run data modify storage evercraft:notify stage.c set value [{text:"⚙ ",color:"#B87333"},{text:"The lock holds fast",color:"red"},{text:" — your hands have failed it (3/3). Only a key will open it now.",color:"gray"}]
execute if score #cn_rung2 ec.temp matches 1 run scoreboard players set #ndur ec.temp 55
execute if score #cn_rung2 ec.temp matches 1 run function evercraft:util/notify/emit

# Fail #2 (was on rung 1, not rung 2) -> climb to rung 2 + a (2/3) line.
execute if score #cn_rung2 ec.temp matches 0 if score #cn_rung1 ec.temp matches 1 run data modify storage evercraft:cn_claim list set value "w1_t2"
execute if score #cn_rung2 ec.temp matches 0 if score #cn_rung1 ec.temp matches 1 run function evercraft:chest_nodes/claim/add with storage evercraft:cn_claim
execute if score #cn_rung2 ec.temp matches 0 if score #cn_rung1 ec.temp matches 1 run data modify storage evercraft:notify stage.c set value [{text:"⚙ ",color:"#B87333"},{text:"The lock resists your hands…",color:"gray"},{text:" (2/3)",color:"gray"}]
execute if score #cn_rung2 ec.temp matches 0 if score #cn_rung1 ec.temp matches 1 run scoreboard players set #ndur ec.temp 50
execute if score #cn_rung2 ec.temp matches 0 if score #cn_rung1 ec.temp matches 1 run function evercraft:util/notify/emit

# Fail #1 (on neither rung) -> climb to rung 1 + a (1/3) line.
execute if score #cn_rung2 ec.temp matches 0 if score #cn_rung1 ec.temp matches 0 run data modify storage evercraft:cn_claim list set value "w1_t1"
execute if score #cn_rung2 ec.temp matches 0 if score #cn_rung1 ec.temp matches 0 run function evercraft:chest_nodes/claim/add with storage evercraft:cn_claim
execute if score #cn_rung2 ec.temp matches 0 if score #cn_rung1 ec.temp matches 0 run data modify storage evercraft:notify stage.c set value [{text:"⚙ ",color:"#B87333"},{text:"The lock resists your hands…",color:"gray"},{text:" (1/3)",color:"gray"}]
execute if score #cn_rung2 ec.temp matches 0 if score #cn_rung1 ec.temp matches 0 run scoreboard players set #ndur ec.temp 50
execute if score #cn_rung2 ec.temp matches 0 if score #cn_rung1 ec.temp matches 0 run function evercraft:util/notify/emit
