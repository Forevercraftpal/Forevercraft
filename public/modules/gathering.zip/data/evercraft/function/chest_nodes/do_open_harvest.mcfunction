# DEPRECATED 2026-06-05: superseded by the per-player open model (do_open_wave1/2 + do_open_struct); no caller.
# === CHEST-NODE — HARVEST TAIL (steps 4+5 of the open flow) ===
# Run as the opening player, positioned AT THE NODE, AFTER the open gates passed (do_open). Extracted so
# BOTH the normal keyed/keyless path AND the §11 PREUNLOCKED struct path reuse the EXACT same 50/50
# harvest + outcome branch + despawn-on-signal. gth_temp.x/y/z were coord-pinned by do_open's head.

# ---------- (4) 50/50 HARVEST through the shared gather engine (gth_src=5). ----------
# compute_success forces a flat 50 for src 5 (the level-curve skip, §14.1). gather/resolve does the
# claim -> roll -> win/fail/crumble, grants Gearwright XP (full/quarter), plays the line, frees charges.
scoreboard players set @s ec.gth_src 5
function evercraft:gather/resolve

# Dropped claim (another player won this node this tick) -> award nothing, the player re-clicks.
execute if score @s ec.gth_outcome matches 0 run return 0

# Branch on the harvest outcome.
execute if score @s ec.gth_outcome matches 1 run function evercraft:chest_nodes/do_open_success
execute if score @s ec.gth_outcome matches 2.. run function evercraft:chest_nodes/do_open_fail

# ---------- (5) Despawn on signal (charges-exhausted win OR crumble) — marker + visual + interaction. ----------
execute if score @s ec.gth_despawn matches 1 run function evercraft:chest_nodes/do_open_despawn
