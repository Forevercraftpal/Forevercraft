# === CHEST-NODE CHANNEL — TICK (self-sched 2t, existence-gated) ===
# Cheap when idle: two @a checks then self-reschedule. Mirrors the other chest_nodes tick loops.
schedule function evercraft:chest_nodes/crack/tick 2t replace
execute unless entity @a[tag=ec.cn_cracking] run return 0
execute as @a[tag=ec.cn_cracking] at @s run function evercraft:chest_nodes/crack/tick_one
