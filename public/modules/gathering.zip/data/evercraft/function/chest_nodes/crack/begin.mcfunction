# === CHEST-NODE INTERACTION CHANNEL — BEGIN (timed open; resolves into do_open) ===
# Run as @s = opening player, at the node (on_click: as @p[..3] at @s). Carrying a usable key (or a
# pre-unlocked struct node) => the HARVEST TIMER (5s @ Gearwright L0 -> 1.5s @ L100). No key => the
# 15s CRACK (-> ~5s @ L100; higher Tinker cracks faster). The keyless %/key-wear/trap/50-50 harvest all
# stay in do_open, which runs UNCHANGED when the channel completes (crack/finish) — so a cancelled
# channel consumes nothing. Boss bar = the live-bar pool slot (hands off to the Gearwright XP bar on resolve).

# Debounce: ignore re-clicks while already channeling.
execute if score @s ec.cn_crack matches 1.. run return 0

# Claim / re-assert a pooled bossbar slot (the bar we already use).
execute if score @s ec.caff_bar_slot matches 1.. run function evercraft:craft_affinity/live_bar/reassert_slot
execute unless score @s ec.caff_bar_slot matches 1.. run function evercraft:craft_affinity/live_bar/claim_slot
# Pool full (no slot) -> skip the timer, resolve immediately (never soft-lock the open).
execute unless score @s ec.caff_bar_slot matches 1.. run return run function evercraft:chest_nodes/crack/finish

# Type: 1 = keyed/pre-unlocked (harvest timer), 2 = keyless (the crack). The hands-vs-key choice is
# DELIBERATE now (per-player rework §2): the channel type follows the HELD key, not the 5s inventory-wide
# ec.cn_haskey sweep — a player carrying a key in their bag but bare-handed still gets the keyless crack.
scoreboard players set @s ec.cn_crack_typ 2
function evercraft:chest_nodes/held_key_check
execute if score #cn_keyed ec.temp matches 1 run scoreboard players set @s ec.cn_crack_typ 1
execute if data entity @e[type=marker,tag=ec.chest_data,distance=..4,limit=1,sort=nearest] {data:{preunlocked:1b}} run scoreboard players set @s ec.cn_crack_typ 1

# --- Duration by type + Gearwright (Tinker) level. ---
# Keyed HARVEST TIMER: 100t (5s) at L0, -7t per level (=-0.35s/10lv), floored 30t (1.5s) at L100.
execute if score @s ec.cn_crack_typ matches 1 run scoreboard players operation #ck_d ec.temp = @s ec.caffl_gw
execute if score @s ec.cn_crack_typ matches 1 run scoreboard players operation #ck_d ec.temp *= #cn_c7 ec.var
execute if score @s ec.cn_crack_typ matches 1 run scoreboard players operation #ck_d ec.temp /= #cn_c10 ec.var
execute if score @s ec.cn_crack_typ matches 1 run scoreboard players set @s ec.cn_crack 100
execute if score @s ec.cn_crack_typ matches 1 run scoreboard players operation @s ec.cn_crack -= #ck_d ec.temp
execute if score @s ec.cn_crack_typ matches 1 if score @s ec.cn_crack matches ..30 run scoreboard players set @s ec.cn_crack 30
# Keyless CRACK: 300t (15s) at L0, -2t per level, floored 100t (5s) at L100.
execute if score @s ec.cn_crack_typ matches 2 run scoreboard players operation #ck_d ec.temp = @s ec.caffl_gw
execute if score @s ec.cn_crack_typ matches 2 run scoreboard players operation #ck_d ec.temp *= #cn_c2 ec.var
execute if score @s ec.cn_crack_typ matches 2 run scoreboard players set @s ec.cn_crack 300
execute if score @s ec.cn_crack_typ matches 2 run scoreboard players operation @s ec.cn_crack -= #ck_d ec.temp
execute if score @s ec.cn_crack_typ matches 2 if score @s ec.cn_crack matches ..100 run scoreboard players set @s ec.cn_crack 100

# Class chest bonus: Rogue (ec.rg_active, dual-blade) and Dual Swordsman
# (ec.ds_active) crack 50% faster: cn_crack *= 2/3. Apply BEFORE the
# cn_crack_max copy so the bossbar fill stays accurate. Floor of 20t (~1s).
scoreboard players set #cls_boost ec.temp 0
execute if entity @s[tag=ec.rg_active] run scoreboard players set #cls_boost ec.temp 1
execute if entity @s[tag=ec.ds_active] run scoreboard players set #cls_boost ec.temp 1
execute if score #cls_boost ec.temp matches 1 run scoreboard players operation @s ec.cn_crack *= #tf_2 ec.var
execute if score #cls_boost ec.temp matches 1 run scoreboard players operation @s ec.cn_crack /= #tf_3 ec.var
execute if score #cls_boost ec.temp matches 1 if score @s ec.cn_crack matches ..20 run scoreboard players set @s ec.cn_crack 20

# Engage: total (for the fill %), tag for the tick loop, soft cue, initial bar.
scoreboard players operation @s ec.cn_crack_max = @s ec.cn_crack
tag @s add ec.cn_cracking
# Channel-begins cue (gated): a soft copper-trapdoor open marking the lock engaging.
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.copper_trapdoor.open master @s ~ ~ ~ 0.5 1.0
function evercraft:chest_nodes/crack/render
