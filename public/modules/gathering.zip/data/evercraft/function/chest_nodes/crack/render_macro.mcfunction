# === CHEST-NODE CHANNEL — RENDER MACRO (writes the pooled bossbar) ===
# Call with storage {barslot, pct, label}. Run as @s = the viewing player (sole viewer of this slot).
$bossbar set evercraft:caffbar_$(barslot) max 100
$bossbar set evercraft:caffbar_$(barslot) value $(pct)
$bossbar set evercraft:caffbar_$(barslot) color yellow
$bossbar set evercraft:caffbar_$(barslot) name ["",{text:"⚙ ",color:"#B87333"},{text:"$(label)",color:"#B87333",bold:true},{text:"  ",color:"gray"},{text:"$(pct)",color:"white"},{text:"%",color:"gray"}]
$bossbar set evercraft:caffbar_$(barslot) players @s
$bossbar set evercraft:caffbar_$(barslot) visible true
