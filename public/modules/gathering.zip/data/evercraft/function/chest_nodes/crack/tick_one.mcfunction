# === CHEST-NODE CHANNEL — PER-PLAYER STEP (cancel / advance / finish) ===
# Run as @s = a channeling player, at @s. Cancel if they walked off the node (no chest node within ~4)
# or it despawned. Otherwise advance 2 ticks; finish when the bar fills.
execute unless entity @e[type=marker,tag=ec.chest_data,distance=..4] run return run function evercraft:chest_nodes/crack/cancel
scoreboard players remove @s ec.cn_crack 2
execute if score @s ec.cn_crack matches ..0 run return run function evercraft:chest_nodes/crack/finish
function evercraft:chest_nodes/crack/render
# Channeling cue (gated FX preset — a pling click ~every 20t, rising pitch via #ck_pct from render).
# A keyed-harvest start can be ODD (integer division), and the countdown steps by 2 — so an odd start
# only ever visits odd values and would NEVER hit a multiple of 10. Fire on a 2-wide window (%20 == 0..1)
# that ANY 2-step countdown must land in regardless of parity: even starts land on 0, odd starts on 1.
scoreboard players operation #cn_fxstep ec.temp = @s ec.cn_crack
scoreboard players operation #cn_fxstep ec.temp %= #20 ec.const
execute if score #cn_fxstep ec.temp matches 0..1 run function evercraft:fx/node/channel_chest
