# === CHEST-NODE CHANNEL — HIDE MACRO (release the pooled bar on cancel) ===
# Call with storage {barslot}. The slot stays claimed (held for the session, like the XP bar).
$bossbar set evercraft:caffbar_$(barslot) visible false
