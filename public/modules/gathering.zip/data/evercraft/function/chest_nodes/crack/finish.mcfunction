# === CHEST-NODE CHANNEL — FINISH (channel filled -> resolve the open) ===
# Run as @s. Untag, then run do_open UNCHANGED at the node (trap / key-wear / keyless roll / 50-50
# harvest). Then reveal the Gearwright XP bar on the same pooled slot — on success OR fail, even if the
# class isn't being tracked (live_bar/update bypasses the track-gate that on_grant applies).
tag @s remove ec.cn_cracking
scoreboard players set @s ec.cn_crack 0
execute at @e[type=marker,tag=ec.chest_data,distance=..4,limit=1,sort=nearest] run function evercraft:chest_nodes/do_open
function evercraft:craft_affinity/live_bar/update {abbrev:"gw",class_id:7,name:"Gearwright",color:"#B87333",bar_color:"yellow"}
