# === CHEST-NODE CHANNEL — CANCEL (walked off / node despawned) ===
# Run as @s. Untag, hide the pooled bar, soft cue. do_open never ran -> key un-worn, nothing consumed.
tag @s remove ec.cn_cracking
scoreboard players set @s ec.cn_crack 0
execute store result storage evercraft:cn_crackbar barslot int 1 run scoreboard players get @s ec.caff_bar_slot
function evercraft:chest_nodes/crack/hide_macro with storage evercraft:cn_crackbar
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.copper_trapdoor.close master @s ~ ~ ~ 0.5 0.8
data modify storage evercraft:notify stage.c set value [{text:"⚙ ",color:"#B87333"},{text:"You stopped",color:"gray"},{text:" working the lock.",color:"gray"}]
scoreboard players set #ndur ec.temp 30
function evercraft:util/notify/emit
