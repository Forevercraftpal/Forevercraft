# === CHEST-NODE CHANNEL — RENDER the pooled boss bar (progress %) ===
# Run as @s. Percent = elapsed*100/max. Pushes {barslot, pct, label} to the render macro.
scoreboard players operation #ck_el ec.temp = @s ec.cn_crack_max
scoreboard players operation #ck_el ec.temp -= @s ec.cn_crack
scoreboard players operation #ck_pct ec.temp = #ck_el ec.temp
scoreboard players operation #ck_pct ec.temp *= #cn_c100 ec.var
scoreboard players operation #ck_pct ec.temp /= @s ec.cn_crack_max
execute store result storage evercraft:cn_crackbar barslot int 1 run scoreboard players get @s ec.caff_bar_slot
execute store result storage evercraft:cn_crackbar pct int 1 run scoreboard players get #ck_pct ec.temp
data modify storage evercraft:cn_crackbar label set value "Opening the lock"
execute if score @s ec.cn_crack_typ matches 2 run data modify storage evercraft:cn_crackbar label set value "Cracking the lock"
function evercraft:chest_nodes/crack/render_macro with storage evercraft:cn_crackbar
