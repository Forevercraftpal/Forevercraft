# === CHEST-NODE — KEYED DISPATCH (overworld wave-2 gate) ===
# Run as @s, AT THE NODE, from do_open when @s HELD a fresh key (#cn_keyed=1) on an OVERWORLD node.
# A held key ALWAYS grants WAVE 2 (richer), ONCE per player — independent of the hand (wave-1) track.
# Gate on the per-(player,chest) data.w2_claimed list: already claimed -> a soft "only your hands remain
# for the first wave" cue (no open, no wear); else grant wave 2. claim/prep already ran in do_open.

# Already took wave 2 from this chest? (membership of @s's UUID in data.w2_claimed).
data modify storage evercraft:cn_claim list set value "w2_claimed"
function evercraft:chest_nodes/claim/has with storage evercraft:cn_claim
execute if score #cn_inlist ec.temp matches 1 if score @s ec.fx_snd matches 1.. run playsound minecraft:block.chain.fall master @s ~ ~ ~ 0.4 0.9
execute if score #cn_inlist ec.temp matches 1 run data modify storage evercraft:notify stage.c set value [{text:"⚙ ",color:"#B87333"},{text:"You have already claimed the key vault",color:"gray"},{text:" — only your hands remain for the first wave.",color:"gray"}]
execute if score #cn_inlist ec.temp matches 1 run scoreboard players set #ndur ec.temp 55
execute if score #cn_inlist ec.temp matches 1 run function evercraft:util/notify/emit
execute if score #cn_inlist ec.temp matches 1 run return 0

# Fresh for this player -> grant wave 2 (wears the key inside do_open_wave2).
function evercraft:chest_nodes/do_open_wave2
