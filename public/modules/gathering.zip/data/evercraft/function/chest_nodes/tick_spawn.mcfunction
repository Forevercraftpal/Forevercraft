# Chest Node: Per-second spawn timer check (self-scheduling 1s loop, mirrors splash/tick_spawn)
schedule function evercraft:chest_nodes/tick_spawn 1s replace

# Gate: skip entirely if no players online.
execute unless entity @a run return 0

# Chest nodes are UNIVERSAL (any survival/adventure player can find one — unlike splash, which gates
# on the Sirencall class). No class gate: a brand-new player with no Gearwright level still finds
# nodes (they just open keyless at the flat 1/100, §2). Skip spectators/creative (survival gameplay).
execute as @a[gamemode=!spectator,gamemode=!creative] at @s run function evercraft:chest_nodes/check_spawn

# Appraise A2: tick down the inspect-button cooldown (existence-gated). Sole decrement writer of
# ec.gw_insp_cd; inspect/raycast seeds it. Free when no one is on cooldown.
execute as @a[scores={ec.gw_insp_cd=1..}] run scoreboard players remove @s ec.gw_insp_cd 1
