# Chest-node ADDITIVE decor drop (Joseph 2026-06-14). On a successful open, ~30% chance of a build-free
# Blueprint dropped ON TOP of the node's normal loot (never in place of it — this runs after resolve).
# When a blueprint lands, a small (12%) bonus chance of a loose Idea on top of it. Run as @s, positioned
# at the node (the player). `loot give @s` spills to the ground if the inventory is full.

# Heirloom Brass — the chest-node Antique Material (independent ~4%; saw it into antique furnishings).
execute store result score #cn_heir ec.temp run random value 1..100
execute if score #cn_heir ec.temp matches 1..4 run loot give @s loot evercraft:antique_mat/heirloom
execute if score #cn_heir ec.temp matches 1..4 if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.4 1.6

execute store result score #cn_decor ec.temp run random value 1..100
execute if score #cn_decor ec.temp matches 31.. run return 0

# Band-weighted blueprint (common 60 / uncommon 30 / rare 10).
loot give @s loot evercraft:decor/chest_bp

# Small bonus Idea on top of the blueprint.
execute store result score #cn_decor2 ec.temp run random value 1..100
execute if score #cn_decor2 ec.temp matches 1..12 run loot give @s loot evercraft:decor/chest_idea

# Soft "drafting table" cue — note-block palette, FX-gated.
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bit master @s ~ ~ ~ 0.5 1.4
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.chime master @s ~ ~ ~ 0.4 1.8
