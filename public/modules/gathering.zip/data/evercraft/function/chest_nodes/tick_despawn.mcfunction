# Chest Node: Check node lifetimes (every 5 seconds, existence-gated). Mirrors splash/tick_despawn.
schedule function evercraft:chest_nodes/tick_despawn 100t replace

# Existence-gate: skip the scan entirely when no chest nodes exist.
execute if entity @e[type=marker,tag=ec.chest_data,limit=1] as @e[type=marker,tag=ec.chest_data] run function evercraft:chest_nodes/check_despawn

# Trap-mob age-out (the ambush mobs from traps/fn/trap_27/28/30/32/35). They are PersistenceRequired so
# they never despawn naturally — age each ~5s tick and kill at ~40s so an abandoned ambush self-cleans.
# Existence-gated: no work unless a trap mob is loaded. ec.cn_mob_age sole writer = this line.
execute if entity @e[tag=ec.cn_trap_mob,limit=1] as @e[tag=ec.cn_trap_mob] run scoreboard players add @s ec.cn_mob_age 1
execute if entity @e[tag=ec.cn_trap_mob,limit=1] run kill @e[tag=ec.cn_trap_mob,scores={ec.cn_mob_age=8..}]
