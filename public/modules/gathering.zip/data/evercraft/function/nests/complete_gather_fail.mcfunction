# Nest Family: Harvest FAIL (outcome 2) OR CRUMBLE (outcome 3) — mirror forage/complete_gather_fail.
# Run as @s, from complete_gather. The engine already granted quarter Lamentor XP + played the
# fail/crumble line. No loot, no crate, no coin, no crossover (crossplay C1).

# +2 Harvest tree progress (HALF of the success +4).
scoreboard players add @s adv.stat_harvest 2

# Artisan XP: Foraging skill (HALF — 1 of the success 3). Nests route to the Foraging artisan cat
# (cat 4) like the other gather nodes — shears-harvest is a foraging discipline.
scoreboard players set #cf_xp_amount ec.cf_temp 1
scoreboard players set #cf_xp_cat ec.cf_temp 4
function evercraft:craftforever/artisan/add_xp

# Gentle "miss" cue (gather-FX identity pass, 2026-06-09 — fails used to be SILENT, which read as a
# bug). A quiet A-MINOR dyad in the nest iron-xylophone voice: the nest kept its secrets.
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.iron_xylophone master @s ~ ~ ~ 0.4 1.189
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.iron_xylophone master @s ~ ~ ~ 0.3 1.414
