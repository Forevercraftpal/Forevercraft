# Nest Family: Reset spawn timer based on movement state (mirror forage/reset_timer).
# Reads the shared ec.moving signal directly (no per-nest moving mirror — one fewer objective).
# Spawn rate HALVED (2026-06-04, Joseph) — intervals doubled: moving 350->700t (17.5s->35s),
# standing 3500->7000t. Fewer nests per session; keeps them a rare faucet.
execute if score @s ec.moving matches 1.. run scoreboard players set @s ec.nest_timer 700
execute if score @s ec.moving matches ..0 run scoreboard players set @s ec.nest_timer 7000
