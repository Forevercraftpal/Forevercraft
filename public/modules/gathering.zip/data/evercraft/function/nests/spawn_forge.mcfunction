# Nest: Spawn the nest_type's forge-material crossover roll on the ground (inv-full fallback).
# Macro — called with storage evercraft:nest_temp {nest_type:"..."}.
$loot spawn ~ ~ ~ loot evercraft:nests/crossover/forge_$(nest_type)
