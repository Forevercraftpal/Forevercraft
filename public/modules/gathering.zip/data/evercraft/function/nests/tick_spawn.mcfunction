# Nest Family: Per-second spawn timer check (PLAN-nest-family §3 — ONE dim-routed scanner)
# Self-scheduling 1s loop. Mirrors forage/tick_spawn but runs in ALL dimensions (nest_type is
# routed per-dimension inside place.mcfunction), so no in_overworld gate — a single scanner.
schedule function evercraft:nests/tick_spawn 1s replace

# Gate: skip if no players online (R2 perf).
execute unless entity @a run return 0

# Process each online player in every dimension. place.mcfunction routes nest_type by predicate.
execute as @a at @s run function evercraft:nests/check_spawn
