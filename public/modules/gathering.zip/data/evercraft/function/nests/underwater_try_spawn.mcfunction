# === NEST · UNDERWATER (RIVER/OCEAN FLOOR) SPAWN BRANCH (mirror forage/underwater_try_spawn) ===
# Run as the player, at the player position. Called ONLY from nests/check_spawn under the gate
# `if predicate in_water if predicate nests/water_biome if score @s ec.caffl_lm matches 5..`.
# Places a NORMAL ec.nest_data nest on the river/ocean FLOOR (place routes nest_type=water there).
# NO spreadplayers (it shuns water) — multi-candidate random-offset floor search.

# --- Cap: share the land cap (max 7 ec.nest_data within 120 blocks). NO cap bloat. ---
execute store result score #nest_count ec.temp if entity @e[type=marker,tag=ec.nest_data,distance=..120]
execute if score #nest_count ec.temp matches 7.. run return run function evercraft:nests/reset_timer

# --- Multi-candidate floor search (random offsets; can land IN water). ---
scoreboard players set #nest_placed ec.temp 0
scoreboard players set #nest_tries ec.temp 8
function evercraft:nests/underwater_place_attempt

# Reset the spawn timer (success or miss).
function evercraft:nests/reset_timer
