# Nest (UNDERWATER): ONE floor-placement candidate (recursive). Run as the player.
# Mirror forage/underwater_place_attempt — NO spreadplayers, random offset, scan down via
# gather/underwater/scan_floor for the river/ocean bottom. Recurses until #nest_tries runs out.
# Shared scratch: #nest_tries, #nest_placed, #uw_scan.

# Out of tries — give up this cycle.
execute if score #nest_tries ec.temp matches ..0 run return 0
scoreboard players remove #nest_tries ec.temp 1

# Player block coords + a random nearby offset (-15..15 on X/Z), start 2 blocks up.
execute store result score #nest_tx ec.temp run data get entity @s Pos[0] 1
execute store result score #nest_ty ec.temp run data get entity @s Pos[1] 1
execute store result score #nest_tz ec.temp run data get entity @s Pos[2] 1
execute store result score #nest_ox ec.temp run random value -15..15
execute store result score #nest_oz ec.temp run random value -15..15
scoreboard players operation #nest_tx ec.temp += #nest_ox ec.temp
scoreboard players operation #nest_tz ec.temp += #nest_oz ec.temp
scoreboard players add #nest_ty ec.temp 2

# Summon a candidate marker and move it to (offsetX, playerY+2, offsetZ).
summon marker ~ ~ ~ {Tags:["ec.nest_temp","ec.spawn_temp"]}
execute store result entity @e[type=marker,tag=ec.nest_temp,limit=1] Pos[0] double 1 run scoreboard players get #nest_tx ec.temp
execute store result entity @e[type=marker,tag=ec.nest_temp,limit=1] Pos[1] double 1 run scoreboard players get #nest_ty ec.temp
execute store result entity @e[type=marker,tag=ec.nest_temp,limit=1] Pos[2] double 1 run scoreboard players get #nest_tz ec.temp

# Scan DOWN (up to 30) for a water-block-over-solid-floor (shared gather helper).
scoreboard players set #uw_scan ec.temp 30
execute as @e[type=marker,tag=ec.nest_temp,limit=1] at @s store success score #nest_found ec.temp run function evercraft:gather/underwater/scan_floor

# No floor at this candidate — drop it and try another.
execute if score #nest_found ec.temp matches 0 run kill @e[type=marker,tag=ec.nest_temp]
execute if score #nest_found ec.temp matches 0 run return run function evercraft:nests/underwater_place_attempt

# Found a floor — place the nest in the water just above it.
tag @e[type=marker,tag=ec.nest_temp] remove ec.spawn_temp
execute at @e[type=marker,tag=ec.nest_temp,limit=1] run function evercraft:nests/place
kill @e[type=marker,tag=ec.nest_temp]
scoreboard players set #nest_placed ec.temp 1
