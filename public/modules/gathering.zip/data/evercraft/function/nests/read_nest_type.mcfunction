# Nest: Read the pinned nest's nest_type into nest_temp WITHOUT despawning it.
# Macro — called with storage evercraft:nest_temp {nx:X, ny:Y, nz:Z}. Coord-pinned (NEVER
# sort=nearest in a multiplayer cluster). The nest survives a fail; despawn is handled separately
# on the gth_despawn signal. Falls back to the caller-seeded "forest".
$execute positioned $(nx) $(ny) $(nz) run data modify storage evercraft:nest_temp nest_type set from entity @e[type=marker,tag=ec.nest_data,distance=..2,limit=1,sort=nearest] data.nest_type
