# Nest Family: Harvest SUCCESS — primary nest loot + crossover fan-outs + the FULL side of the
# harvest/artisan feeds. Run as @s, at the player, from complete_gather on outcome 1.
# (Engine already granted FULL Lamentor XP + played the success line.)

# Read the pinned nest's nest_type NON-destructively (coord-pinned; the nest survives — despawn
# is handled separately on the gth_despawn signal). Fallback "forest".
execute store result storage evercraft:nest_temp nx int 1 run scoreboard players get @s ec.nest_sx
execute store result storage evercraft:nest_temp ny int 1 run scoreboard players get @s ec.nest_sy
execute store result storage evercraft:nest_temp nz int 1 run scoreboard players get @s ec.nest_sz
data modify storage evercraft:nest_temp nest_type set value "forest"
function evercraft:nests/read_nest_type with storage evercraft:nest_temp

# --- Primary loot (nest_type-routed; inv-full guarded) ---
execute store result score #inv_full ec.var run function evercraft:util/check_inv_full
execute if score #inv_full ec.var matches 0 run function evercraft:nests/give_loot with storage evercraft:nest_temp
execute if score #inv_full ec.var matches 1 at @s run function evercraft:nests/spawn_loot with storage evercraft:nest_temp

# Warn if inventory full.
data modify storage evercraft:notify stage.c set value [{text:"Inventory full! Your comb was dropped at your feet.",color:"yellow"}]
scoreboard players set #ndur ec.temp 45
execute if score #inv_full ec.var matches 1 run function evercraft:util/notify/emit
execute if score #inv_full ec.var matches 1 if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bass player @s ~ ~ ~ 1 0.5

# +4 Harvest tree progress (FULL on success; complete_gather_fail grants the +2 half).
scoreboard players add @s adv.stat_harvest 4

# --- Crossover fan-outs (PLAN-nest-family §4) — tier-windowed redirect tables into EXISTING
# reagent/material leaf tables (no new reagents/materials minted). inv-full guarded each. ---
# Alchemy reagents (botanical/mineral/visceral, tier-windowed per nest_type).
execute store result score #inv_full ec.var run function evercraft:util/check_inv_full
execute if score #inv_full ec.var matches 0 run function evercraft:nests/give_alchemy with storage evercraft:nest_temp
execute if score #inv_full ec.var matches 1 at @s run function evercraft:nests/spawn_alchemy with storage evercraft:nest_temp
# Forge materials (ore_drop tier leaves, tier-windowed per nest_type).
execute store result score #inv_full ec.var run function evercraft:util/check_inv_full
execute if score #inv_full ec.var matches 0 run function evercraft:nests/give_forge with storage evercraft:nest_temp
execute if score #inv_full ec.var matches 1 at @s run function evercraft:nests/spawn_forge with storage evercraft:nest_temp

# --- Family parity (reuse the proven forage crossover faucets) ---
# Cooking artifact material roll (0.5% base).
execute store result score #inv_full ec.var run function evercraft:util/check_inv_full
execute if score #inv_full ec.var matches 0 run loot give @s loot evercraft:cooking/artifacts/materials/forage_drop
execute if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:cooking/artifacts/materials/forage_drop
# UNIFIED harvest bonus (Part C migration): the old inline 1/100 bonus crate is now harvest_bonus's
# crate channel (default thresh 7 = 1/100 — SAME rate, NOT doubled). It ALSO adds the unified Forever-
# Coin (3%) + custom (2%) layer nests lacked. Defaults used (#hb_cfg 0). Node-specific nest loot +
# alchemy/forge crossover fan-outs above stay untouched.
function evercraft:gather/harvest_bonus

# Artisan XP: Foraging (+3 per harvest — FULL on success).
scoreboard players set #cf_xp_amount ec.cf_temp 3
scoreboard players set #cf_xp_cat ec.cf_temp 4
function evercraft:craftforever/artisan/add_xp

# Track for achievements (reuse the shared forages counter — shears-harvest is a foraging act).
scoreboard players add @s ach.forages_done 1

# Completion effects — the A-MAJOR nest "hive lift" (gather-FX identity pass, 2026-06-09): keeps the
# established iron-xylophone hive identity (start/cancel notes E4/G#3 are the dominant + leading tone
# of A, so the whole nest interaction is one key now). Beehive foley kept quiet as the material accent;
# THREE randomized chord voicings defeat repeat-fatigue. A major pitches: A4 1.189 / C#5 1.498 /
# E5 1.782. #fx_voice scratch, local to this file.
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.beehive.exit master @s ~ ~ ~ 0.5 1.2
execute if score @s ec.fx_snd matches 1.. store result score #fx_voice ec.temp run random value 1..3
execute if score @s ec.fx_snd matches 1.. if score #fx_voice ec.temp matches 1 run playsound minecraft:block.note_block.iron_xylophone master @s ~ ~ ~ 0.6 1.189
execute if score @s ec.fx_snd matches 1.. if score #fx_voice ec.temp matches 1 run playsound minecraft:block.note_block.iron_xylophone master @s ~ ~ ~ 0.45 1.498
execute if score @s ec.fx_snd matches 1.. if score #fx_voice ec.temp matches 1 run playsound minecraft:block.note_block.harp master @s ~ ~ ~ 0.35 1.782
execute if score @s ec.fx_snd matches 1.. if score #fx_voice ec.temp matches 2 run playsound minecraft:block.note_block.iron_xylophone master @s ~ ~ ~ 0.6 1.498
execute if score @s ec.fx_snd matches 1.. if score #fx_voice ec.temp matches 2 run playsound minecraft:block.note_block.iron_xylophone master @s ~ ~ ~ 0.45 1.782
execute if score @s ec.fx_snd matches 1.. if score #fx_voice ec.temp matches 2 run playsound minecraft:block.note_block.harp master @s ~ ~ ~ 0.35 1.189
execute if score @s ec.fx_snd matches 1.. if score #fx_voice ec.temp matches 3 run playsound minecraft:block.note_block.iron_xylophone master @s ~ ~ ~ 0.6 1.189
execute if score @s ec.fx_snd matches 1.. if score #fx_voice ec.temp matches 3 run playsound minecraft:block.note_block.iron_xylophone master @s ~ ~ ~ 0.45 1.782
execute if score @s ec.fx_snd matches 1.. if score #fx_voice ec.temp matches 3 run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.25 1.782
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.experience_orb.pickup master @s ~ ~ ~ 0.5 0.8
execute if score @s ec.fx_vis matches 1.. run particle minecraft:happy_villager ~ ~1 ~ 0.3 0.5 0.3 0 8

# Dreamy Pull: 7% chance for an optional bonus mini-game (base loot already given above).
# Source 4 = nest (Lamentor); success-only. Mirrors forage/complete_gather_success. maybe_trigger
# reads ec.gth_overlvl/dppenalty/lastxp set THIS tick by gather/compute_success in the head (this
# harvest routes through gather/ with gth_src=4), so the snapshots are valid here.
scoreboard players set @s ec.dp_source 4
function evercraft:dreamy_pull/maybe_trigger
