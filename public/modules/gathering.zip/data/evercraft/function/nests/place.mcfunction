# Nest Family: Summon nest entities at current position + route nest_type by dimension/biome.
# Run at the ground-level position where the nest should appear (mirror forage/place_bush +
# prospect/place_node's dim split). One marker family (ec.nest_data), one despawn, one tick.

# Data marker (stores spawn gametime for despawn calculation).
summon marker ~ ~ ~ {Tags:["ec.nest","ec.nest_data","ec.nest_new"]}
execute store result entity @e[type=marker,tag=ec.nest_new,limit=1,distance=..1] data.spawn_time long 1 run time query gametime

# --- nest_type routing (PLAN-nest-family §3, predicate PRIORITY: end > nether > water > forest).
# Written to nest-isolated storage (evercraft:nest_temp) to avoid multiplayer races, then stamped
# onto the marker by apply_variant. Default forest (the common OW hive). ---
data modify storage evercraft:nest_temp nest_type set value "forest"
execute if predicate evercraft:in_water if predicate evercraft:nests/water_biome run data modify storage evercraft:nest_temp nest_type set value "water"
execute if predicate evercraft:in_nether run data modify storage evercraft:nest_temp nest_type set value "nether"
execute if predicate evercraft:in_end run data modify storage evercraft:nest_temp nest_type set value "end"

# Item display (visual nest — placeholder; apply_variant overrides with the per-type block).
summon item_display ~ ~0.1 ~ {Tags:["ec.nest","ec.nest_visual","ec.nest_vis_new"],item:{id:"minecraft:bee_nest",count:1},item_display:"fixed",transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0.2f,0f],scale:[0.6f,0.6f,0.6f]},billboard:"center"}

# Interaction entity (right-click target, slightly above ground).
summon interaction ~ ~0.2 ~ {Tags:["ec.nest","ec.nest_click"],width:1.0f,height:0.8f,response:1b}

# Apply visual item + stamp nest_type on the marker (macro).
function evercraft:nests/apply_variant with storage evercraft:nest_temp

# --- B-rarity: stamp data.rarity (drives baseXP via rarity_xp: 1->4 2->8 3->12 4->16 5->20 6->25).
# Per-nest Lamentor baseXP bands (§1): Forest=1, Water=2, Nether=3, End=5. Must run while the
# ec.nest_new tag is still present. ---
data modify entity @e[type=marker,tag=ec.nest_new,limit=1,distance=..1] data.rarity set value 1
execute if data storage evercraft:nest_temp {nest_type:"water"} run data modify entity @e[type=marker,tag=ec.nest_new,limit=1,distance=..1] data.rarity set value 2
execute if data storage evercraft:nest_temp {nest_type:"nether"} run data modify entity @e[type=marker,tag=ec.nest_new,limit=1,distance=..1] data.rarity set value 3
execute if data storage evercraft:nest_temp {nest_type:"end"} run data modify entity @e[type=marker,tag=ec.nest_new,limit=1,distance=..1] data.rarity set value 5

# --- C1-tier: stamp data.reqlv + data.areamult (×100) per nest area difficulty (EQ2). Mirrors
# tier/stamp_forage's dim bands so the reqLv 5% success floor (R5) gates under-leveled players in
# the harder dims. Default forest 0/100. ---
data modify entity @e[type=marker,tag=ec.nest_new,limit=1,distance=..1] data.reqlv set value 0
data modify entity @e[type=marker,tag=ec.nest_new,limit=1,distance=..1] data.areamult set value 100
execute if data storage evercraft:nest_temp {nest_type:"water"} run data modify entity @e[type=marker,tag=ec.nest_new,limit=1,distance=..1] data.reqlv set value 40
execute if data storage evercraft:nest_temp {nest_type:"water"} run data modify entity @e[type=marker,tag=ec.nest_new,limit=1,distance=..1] data.areamult set value 200
execute if data storage evercraft:nest_temp {nest_type:"nether"} run data modify entity @e[type=marker,tag=ec.nest_new,limit=1,distance=..1] data.reqlv set value 60
execute if data storage evercraft:nest_temp {nest_type:"nether"} run data modify entity @e[type=marker,tag=ec.nest_new,limit=1,distance=..1] data.areamult set value 250
execute if data storage evercraft:nest_temp {nest_type:"end"} run data modify entity @e[type=marker,tag=ec.nest_new,limit=1,distance=..1] data.reqlv set value 50
execute if data storage evercraft:nest_temp {nest_type:"end"} run data modify entity @e[type=marker,tag=ec.nest_new,limit=1,distance=..1] data.areamult set value 350

# Clean up temporary tags.
tag @e[type=marker,tag=ec.nest_new,limit=1,distance=..1] remove ec.nest_new
tag @e[type=item_display,tag=ec.nest_vis_new,limit=1,distance=..1] remove ec.nest_vis_new

# Spawn particle burst (golden — nectar theme).
particle dust{color:[0.95,0.78,0.25],scale:0.8} ~ ~0.3 ~ 0.2 0.2 0.2 0 4
particle minecraft:happy_villager ~ ~0.5 ~ 0.1 0.3 0.1 0 3
