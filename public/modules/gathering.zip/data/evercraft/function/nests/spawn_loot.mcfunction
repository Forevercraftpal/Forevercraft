# Nest: Spawn nest-type-specific loot on ground (inventory-full fallback) — mirror
# forage/spawn_biome_loot. Macro — called with storage evercraft:nest_temp {nest_type:"..."}.
$loot spawn ~ ~ ~ loot evercraft:nests/drops/$(nest_type)
