# Nest Family: Per-nest particle rendering (mirror forage/render_bush).
# Run as nest marker, at nest position.

# Gentle golden nectar particles + occasional sparkle.
particle dust{color:[0.95,0.78,0.25],scale:0.5} ~ ~0.4 ~ 0.15 0.15 0.15 0 1
particle minecraft:happy_villager ~ ~0.5 ~ 0.2 0.2 0.2 0 1

# Pulse effect every ~3 seconds (gametime % 60, pulse when < 10).
execute store result score #nest_pulse ec.temp run time query gametime
scoreboard players operation #nest_pulse ec.temp %= #60 ec.const
execute if score #nest_pulse ec.temp matches ..9 run particle dust{color:[1.0,0.85,0.35],scale:0.8} ~ ~0.5 ~ 0.3 0.3 0.3 0 3

# Faint ambient bee-buzz (2026-06-04, Joseph). Gated: only when a player is within 6 blocks AND a
# low per-tick roll passes, so it stays subtle. render_nest runs every 10t (0.5s) only near players,
# so a ~15% roll averages one faint buzz every ~3-4s per nest — atmospheric, never spammy.
execute if entity @p[distance=..6] store result score #nest_buzz ec.temp run random value 1..100
execute if entity @p[distance=..6] if score #nest_buzz ec.temp matches ..15 as @p[distance=..6] if score @s ec.fx_snd matches 2.. at @s run playsound minecraft:entity.bee.loop ambient @s ~ ~ ~ 0.25 1.0
