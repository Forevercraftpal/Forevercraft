# Nest Family: Check nest lifetimes (every 5 seconds) — mirror forage/tick_despawn.
schedule function evercraft:nests/tick_despawn 100t replace

# Existence-gate: skip the scan entirely when no nests exist (mirrors splash/chest tick_despawn).
execute if entity @e[type=marker,tag=ec.nest_data,limit=1] as @e[type=marker,tag=ec.nest_data] run function evercraft:nests/check_despawn
