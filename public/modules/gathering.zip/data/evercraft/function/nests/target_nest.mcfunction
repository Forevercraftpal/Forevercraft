# Nest Family: Despawn the EXACT pinned nest (charges-exhausted win OR crumble).
# Macro — called with storage evercraft:nest_temp {nx:X, ny:Y, nz:Z}. Mirrors forage/target_bush:
# coord-pinned to the nest the player started harvesting, NEVER sort=nearest within 8 blocks.
$execute positioned $(nx) $(ny) $(nz) as @e[type=marker,tag=ec.nest_data,distance=..2,limit=1,sort=nearest] at @s run function evercraft:nests/despawn
