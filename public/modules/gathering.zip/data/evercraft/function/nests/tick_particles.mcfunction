# Nest Family: Render nest particles (10-tick schedule) — mirror forage/tick_particles.
schedule function evercraft:nests/tick_particles 10t replace

# Gate: skip if no players online.
execute unless entity @a run return 0

# Only render for nests near players (performance optimization). Existence-gated to skip an empty scan.
execute if entity @e[type=marker,tag=ec.nest_data,limit=1] as @e[type=marker,tag=ec.nest_data] at @s if entity @a[distance=..48] run function evercraft:nests/render_nest
