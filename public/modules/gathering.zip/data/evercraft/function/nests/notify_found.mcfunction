# Nest Family: First-harvest discovery breadcrumb (PLAN-nest-family §6/§7).
# Run as @s from complete_gather on EVERY real resolution (win/fail/crumble — onboarding must NOT
# gate behind RNG, R7). Reads the pinned nest's nest_type, then per type: emits a one-time
# "You discovered a <X> Nest!" notify (gated on the cf_nest_found bit being UNSET) + lights the
# Node Map + almanac cat9 via almanac/mark_found {field:"cf_nest_found",bit:N} (idempotent
# first-fire). bit map: 1=Forest 2=Water 4=Nether 8=End. Mirrors on_shear_hive:14 + cook_dispatch.

# Coord-pin -> nest_type (the start-pin coords are still in ec.nest_sx/sy/sz this tick).
execute store result storage evercraft:nest_temp nx int 1 run scoreboard players get @s ec.nest_sx
execute store result storage evercraft:nest_temp ny int 1 run scoreboard players get @s ec.nest_sy
execute store result storage evercraft:nest_temp nz int 1 run scoreboard players get @s ec.nest_sz
data modify storage evercraft:nest_temp nest_type set value "forest"
function evercraft:nests/read_nest_type with storage evercraft:nest_temp

# Resolve this nest's bit (1/2/4/8) into #nest_bit, then test if cf_nest_found already has it set
# (#nest_seen). The first-harvest notify fires ONLY when unset; mark_found then flips it (idempotent).
scoreboard players set #nest_bit ec.temp 1
execute if data storage evercraft:nest_temp {nest_type:"water"} run scoreboard players set #nest_bit ec.temp 2
execute if data storage evercraft:nest_temp {nest_type:"nether"} run scoreboard players set #nest_bit ec.temp 4
execute if data storage evercraft:nest_temp {nest_type:"end"} run scoreboard players set #nest_bit ec.temp 8
# Zero scratch FIRST: post-Pioneer-wipe ec.cf_nest_found can be ABSENT (strip's reset @s removes
# the entry, not re-set), so the `= @s` FAILS and #nest_seen keeps a PRIOR call's value (stale) →
# a stale "already seen" would SUPPRESS the legit first-discovery notify. Init to 0 so a missing
# bitfield reads as unset → the breadcrumb fires (mark_found is idempotent).
scoreboard players set #nest_seen ec.temp 0
scoreboard players operation #nest_seen ec.temp = @s ec.cf_nest_found
scoreboard players operation #nest_seen ec.temp /= #nest_bit ec.temp
scoreboard players operation #nest_seen ec.temp %= #2 ec.const

# First-harvest notify (only when the bit was unset). Per-type copy — house-law arcane/ancient/
# astral/ember/tidal wording only.
execute if score #nest_seen ec.temp matches 0 if data storage evercraft:nest_temp {nest_type:"forest"} run data modify storage evercraft:notify stage.c set value [{text:"🐝 ",color:"gold"},{text:"You discovered a Forest Hive!",color:"green"},{text:" Check the Node Map.",color:"gray",italic:true}]
execute if score #nest_seen ec.temp matches 0 if data storage evercraft:nest_temp {nest_type:"water"} run data modify storage evercraft:notify stage.c set value [{text:"🐚 ",color:"aqua"},{text:"You discovered a Tidal Nest!",color:"aqua"},{text:" Check the Node Map.",color:"gray",italic:true}]
execute if score #nest_seen ec.temp matches 0 if data storage evercraft:nest_temp {nest_type:"nether"} run data modify storage evercraft:notify stage.c set value [{text:"🔥 ",color:"red"},{text:"You discovered an Ember Nest!",color:"red"},{text:" Check the Node Map.",color:"gray",italic:true}]
execute if score #nest_seen ec.temp matches 0 if data storage evercraft:nest_temp {nest_type:"end"} run data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"light_purple"},{text:"You discovered an Astral Nest!",color:"light_purple"},{text:" Check the Node Map.",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 45
execute if score #nest_seen ec.temp matches 0 run function evercraft:util/notify/emit
execute if score #nest_seen ec.temp matches 0 if score @s ec.fx_snd matches 1.. run playsound minecraft:item.book.page_turn master @s ~ ~ ~ 0.7 1.1

# Light the Node Map + almanac cat9 (idempotent; flips the cf_nest_found bit on first fire).
execute if data storage evercraft:nest_temp {nest_type:"forest"} run function evercraft:craftforever/codex/hub/almanac/mark_found {field:"cf_nest_found",bit:1}
execute if data storage evercraft:nest_temp {nest_type:"water"} run function evercraft:craftforever/codex/hub/almanac/mark_found {field:"cf_nest_found",bit:2}
execute if data storage evercraft:nest_temp {nest_type:"nether"} run function evercraft:craftforever/codex/hub/almanac/mark_found {field:"cf_nest_found",bit:4}
execute if data storage evercraft:nest_temp {nest_type:"end"} run function evercraft:craftforever/codex/hub/almanac/mark_found {field:"cf_nest_found",bit:8}
