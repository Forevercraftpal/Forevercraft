# Nest Family: Despawn the EXACT pinned nest (charges-exhausted win OR crumble) — mirror
# forage/complete_gather_despawn. Run as @s, from complete_gather on the gth_despawn signal.
# Coord-pinned from the start-stored ec.nest_sx/sy/sz via nests/target_nest — NEVER sort=nearest.
execute store result storage evercraft:nest_temp nx int 1 run scoreboard players get @s ec.nest_sx
execute store result storage evercraft:nest_temp ny int 1 run scoreboard players get @s ec.nest_sy
execute store result storage evercraft:nest_temp nz int 1 run scoreboard players get @s ec.nest_sz
function evercraft:nests/target_nest with storage evercraft:nest_temp
