# Nest: Give the nest_type's tier-windowed forge-material crossover roll (PLAN-nest-family §4).
# Macro — called with storage evercraft:nest_temp {nest_type:"..."}.
# Inv-full guard: drop at the player's feet rather than void on a full inventory.
execute store result score #inv_full ec.var run function evercraft:util/check_inv_full
$execute if score #inv_full ec.var matches 0 run loot give @s loot evercraft:nests/crossover/forge_$(nest_type)
$execute if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:nests/crossover/forge_$(nest_type)
