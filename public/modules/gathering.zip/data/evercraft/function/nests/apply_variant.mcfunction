# Nest: Apply per-type visual + stamp nest_type on the marker (mirror forage/apply_variant).
# Macro — called with storage evercraft:nest_temp {nest_type:"forest|water|nether|end"}.
$data modify entity @e[type=marker,tag=ec.nest_new,limit=1,distance=..1] data.nest_type set value "$(nest_type)"
$data modify entity @e[type=item_display,tag=ec.nest_vis_new,limit=1,distance=..1] item set from storage evercraft:node_variants nests.$(nest_type)
