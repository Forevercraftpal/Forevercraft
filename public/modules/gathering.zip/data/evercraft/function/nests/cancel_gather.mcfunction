# Nest Family: Cancel active harvest (moved too far) — mirror forage/cancel_gather.
# Run as player.

bossbar set evercraft:nest_gather visible false
scoreboard players set @s ec.nest_picking 0
scoreboard players set @s ec.nest_progress 0
data modify storage evercraft:notify stage.c set value [{text:"You moved too far away...",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
# Cancel cue — one low interrupted iron_xylophone note (hive identity), channel-gated.
# Replaces the old ungated entity.sheep.shear (a mob-vocal PALETTE VIOLATION). Off/Reduced/Full/Cracked.
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.iron_xylophone master @s ~ ~ ~ 0.3 0.595
