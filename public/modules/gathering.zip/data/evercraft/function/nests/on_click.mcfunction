# Nest Family: Handle nest interaction click (mirror forage/on_click).
# Run as interaction entity, at nest position.

# Clear the interaction data.
data remove entity @s interaction

# Start harvesting for the nearest player within 3 blocks.
execute as @p[distance=..3] at @s run function evercraft:nests/start_gather
