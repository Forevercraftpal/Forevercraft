# Nest Family: Remove nest entities with fadeout effect (mirror forage/despawn_bush).
# Run as nest marker, at nest position.

# Fadeout particles.
particle dust{color:[0.95,0.78,0.25],scale:0.4} ~ ~0.3 ~ 0.3 0.3 0.3 0 5
particle minecraft:enchant ~ ~0.5 ~ 0.2 0.2 0.2 0.5 4

# Kill visual item_display at this location.
kill @e[type=item_display,tag=ec.nest_visual,distance=..1]

# Kill interaction entity at this location.
kill @e[type=interaction,tag=ec.nest_click,distance=..1]

# Kill self (the data marker).
kill @s
