# Nest Family: Attempt to spawn ONE nest near the player (mirror forage/try_spawn, NO cluster).
# Run as player, at player position. Single placement keeps nests a BONUS faucet (§3 structural
# brake #1: one nest per dimension — no cluster grind).

# Cap: max 7 active nests within 120 blocks (R2).
execute store result score #nest_count ec.temp if entity @e[type=marker,tag=ec.nest_data,distance=..120]
execute if score #nest_count ec.temp matches 7.. run return run function evercraft:nests/reset_timer

# Summon temp marker at player position.
summon marker ~ ~ ~ {Tags:["ec.nest_temp","ec.spawn_temp"]}

# Spread to random ground position within 80 blocks (min 15). Nether: cap under Y=128 to avoid
# the bedrock roof (mirror prospect/try_spawn's nether split).
execute if predicate evercraft:in_nether store success score #nest_spread ec.temp run spreadplayers ~ ~ 15 80 under 128 false @e[type=marker,tag=ec.nest_temp,limit=1]
execute unless predicate evercraft:in_nether store success score #nest_spread ec.temp run spreadplayers ~ ~ 15 80 false @e[type=marker,tag=ec.nest_temp,limit=1]

# If spread failed (no valid position), clean up and skip.
execute if score #nest_spread ec.temp matches 0 run kill @e[type=marker,tag=ec.nest_temp]
execute if score #nest_spread ec.temp matches 0 run return run function evercraft:nests/reset_timer

# Y-level adjustment: spawn near player's depth when underground.
execute store result score #surface_y ec.temp run data get entity @e[type=marker,tag=ec.nest_temp,limit=1] Pos[1]
execute store result score #player_y ec.temp run data get entity @s Pos[1]
scoreboard players operation #player_y ec.temp -= #surface_y ec.temp
execute if score #player_y ec.temp matches ..-5 run function evercraft:common/try_adjust_y
execute if score #player_y ec.temp matches ..-5 if score #scan_ok ec.temp matches 0 run kill @e[type=marker,tag=ec.nest_temp]
execute if score #player_y ec.temp matches ..-5 if score #scan_ok ec.temp matches 0 run return run function evercraft:nests/reset_timer
tag @e[type=marker,tag=ec.nest_temp] remove ec.spawn_temp

# Place the nest at the spread position (place.mcfunction routes nest_type by dimension/biome).
execute at @e[type=marker,tag=ec.nest_temp,limit=1] run function evercraft:nests/place

# Clean up temp marker.
kill @e[type=marker,tag=ec.nest_temp]

# Reset timer.
function evercraft:nests/reset_timer
