# Nest Family: Timer management + spawn attempt (mirror forage/check_spawn). Run as each
# player, at player position, in any dimension.

# --- Sync movement from shared detection (read-only of ec.moving; we write only ec.nest_*). ---
# Reuse ec.gth_* read-only is fine; we don't keep a per-nest moving flag (reset_timer reads
# ec.moving directly, the canonical shared signal — one fewer objective, one-writer preserved).

# --- Decrement timer by 20 ticks (1 second) ---
scoreboard players remove @s ec.nest_timer 20

# --- When timer expires, attempt spawn ---
# Water Nest: in_water + (ocean OR river) + a LOW Lamentor gate (caffl_lm matches 5..) routes to
# the floor-placement attempt (§3 — "gate its unlock on a low ec.caffl_lm"). The `matches 5..`
# literal is the nest water-unlock (lower than Growseer's 30, per plan). underwater_try_spawn
# shares the cap + resets the timer itself, so the land branch is skipped on a water route.
execute if score @s ec.nest_timer matches ..-1 if predicate evercraft:in_water if predicate evercraft:nests/water_biome if score @s ec.caffl_lm matches 5.. run return run function evercraft:nests/underwater_try_spawn
execute if score @s ec.nest_timer matches ..-1 run function evercraft:nests/try_spawn
