# Nest Family: Check if this nest should despawn (5-minute lifetime) — mirror forage/check_despawn.
# Run as nest marker.

# Calculate elapsed ticks since spawn.
execute store result score #nest_now ec.temp run time query gametime
execute store result score #nest_spawn ec.temp run data get entity @s data.spawn_time
scoreboard players operation #nest_elapsed ec.temp = #nest_now ec.temp
scoreboard players operation #nest_elapsed ec.temp -= #nest_spawn ec.temp

# Despawn after 6000 ticks (5 minutes at 20 tps).
execute if score #nest_elapsed ec.temp matches 6000.. at @s run function evercraft:nests/despawn
