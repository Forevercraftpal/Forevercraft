# === NEST FAMILY SYSTEM (PLAN-nest-family) ===
# One forage-engine "Nest" node per dimension, harvested with SHEARS -> Lamentor (gth_src=4).
# Single ec.nest_data marker family, dim-routed nest_type (forest/water/nether/end). Mirrors
# forage/load exactly (objectives + boss bar + self-scheduling loops).

# --- Core spawning scoreboards (one-writer each; mirror ec.fg_*) ---
scoreboard objectives add ec.nest_timer dummy "Nest Spawn Timer"

# --- Gathering mechanic scoreboards ---
# NOTE (one-writer law > objective-count tidiness): the plan's §3 lists 5 nest_* objectives, but
# the gather LOOP needs its own progress counter distinct from the spawn timer (forage splits
# ec.fg_timer / ec.fg_progress for exactly this reason). Adding ec.nest_progress keeps every
# objective single-writer; reusing nest_timer for both would create a 2nd writer. <16 chars.
scoreboard objectives add ec.nest_picking dummy "Nest Gathering Active"
scoreboard objectives add ec.nest_progress dummy "Nest Gathering Progress"
scoreboard objectives add ec.nest_sx dummy "Nest X"
scoreboard objectives add ec.nest_sy dummy "Nest Y"
scoreboard objectives add ec.nest_sz dummy "Nest Z"
scoreboard objectives add ec.nest_target dummy "Nest Harvest Target"

# --- Discovery bitfield (1=Forest 2=Water 4=Nether 8=End). Sole writer: almanac/mark_found
#     via nests/notify_found. ---
scoreboard objectives add ec.cf_nest_found dummy "CF Nests Found"

# --- Boss bar for gathering progress (reuse forage's notched_6 idiom on its own bar) ---
# evercraft:nest_gather is now a PER-PLAYER bar pool (WA62-CHANNEL-BAR, 2026-06-22):
# each channeler drives their own evercraft:nest_gather.<id> (see bossbar/chanbar/), so
# there is no shared global bar to create here. The id is allocated lazily on first open.

# --- Start scheduled loops (existence-gated inside; mirror forage/prospect cadence) ---
schedule function evercraft:nests/tick_spawn 1s replace
schedule function evercraft:nests/tick_particles 10t replace
schedule function evercraft:nests/tick_despawn 100t replace
