# Nest: Give nest-type-specific loot to player (mirror forage/give_biome_loot).
# Macro — called with storage evercraft:nest_temp {nest_type:"..."}.
# Inv-full guard: drop at the player's feet rather than void on a full inventory.
execute store result score #inv_full ec.var run function evercraft:util/check_inv_full
$execute if score #inv_full ec.var matches 0 run loot give @s loot evercraft:nests/drops/$(nest_type)
$execute if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:nests/drops/$(nest_type)
