# Nest: Spawn the nest_type's alchemy-reagent crossover roll on the ground (inv-full fallback).
# Macro — called with storage evercraft:nest_temp {nest_type:"..."}.
$loot spawn ~ ~ ~ loot evercraft:nests/crossover/alchemy_$(nest_type)
