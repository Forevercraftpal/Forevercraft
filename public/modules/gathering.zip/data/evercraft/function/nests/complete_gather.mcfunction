# Nest Family: Harvest complete — run the harvest success-check, then branch (mirror
# forage/complete_gather, spliced through evercraft:gather/ with gth_src=4 = Lamentor).
# Run as player, at player position.

# ---------- HEAD (always — runs every completed harvest, even a dropped claim) ----------
# Hide boss bar and reset picking state (the click resolved either way).
bossbar set evercraft:nest_gather visible false
scoreboard players set @s ec.nest_picking 0
scoreboard players set @s ec.nest_progress 0

# Success-check setup: source 4 (nest/Lamentor) + coord-pin (from the start-stored ec.nest_sx/sy/sz).
scoreboard players set @s ec.gth_src 4
execute store result storage evercraft:gth_temp x int 1 run scoreboard players get @s ec.nest_sx
execute store result storage evercraft:gth_temp y int 1 run scoreboard players get @s ec.nest_sy
execute store result storage evercraft:gth_temp z int 1 run scoreboard players get @s ec.nest_sz
data modify storage evercraft:gth_temp dtag set value "ec.nest_data"

# Roll the harvest (engine: claim -> success% -> win/fail/crumble, grants Lamentor XP (full/quarter),
# plays the success/fail/crumble line, manages charges + per-node fails).
function evercraft:gather/resolve

# Dropped claim (another player won the nest this tick) -> award nothing, player re-clicks.
execute if score @s ec.gth_outcome matches 0 run return 0

# ALWAYS on a real resolution (win OR fail OR crumble): light the per-nest discovery breadcrumb on
# the FIRST INTERACTION (onboarding must NOT gate behind RNG — R7). notify_found reads nest_type
# off the pinned marker + lights the Node Map + almanac cat9 + first-harvest notify.
function evercraft:nests/notify_found

# Lifetime nests-completed counter — once per SUCCESSFUL nest harvest (outcome 1 only;
# outcome 0 dropped-claim already returned above, outcome 2.. is a fail/crumble, not a completion).
execute if score @s ec.gth_outcome matches 1 run scoreboard players add @s ec.nests_done 1

# Branch.
execute if score @s ec.gth_outcome matches 1 run function evercraft:nests/complete_gather_success
execute if score @s ec.gth_outcome matches 2.. run function evercraft:nests/complete_gather_fail

# Despawn on signal (charges-exhausted win OR crumble) — coord-pinned, NEVER sort=nearest.
execute if score @s ec.gth_despawn matches 1 run function evercraft:nests/complete_gather_despawn
