# Nest Family: Per-tick harvest progress (mirror forage/progress_step).
# Run as player with active harvest, at player position.

# --- Range + existence check: cancel if too far from nest or nest gone ---
execute unless entity @e[type=marker,tag=ec.nest_data,distance=..5] run return run function evercraft:nests/cancel_gather

# --- Increment progress ---
scoreboard players add @s ec.nest_progress 1

# --- Update boss bar (this player's own evercraft:nest_gather.<id>) ---
data modify storage evercraft:chanbar bar set value "nest_gather"
execute store result storage evercraft:chanbar id int 1 run scoreboard players get @s ec.chanbar_id
execute store result storage evercraft:chanbar val int 1 run scoreboard players get @s ec.nest_progress
function evercraft:bossbar/chanbar/op_value with storage evercraft:chanbar

# --- Periodic channeling cue (gated FX preset — soft iron_xylophone nectar hum that rises) ---
# (Replaces the old entity.sheep.shear taps — a mob-vocal palette violation.)
execute if score @s ec.nest_progress matches 15 run function evercraft:fx/node/channel_hive
execute if score @s ec.nest_progress matches 30 run function evercraft:fx/node/channel_hive
execute if score @s ec.nest_progress matches 45 run function evercraft:fx/node/channel_hive

# --- Complete at 60 ticks (3 seconds) ---
execute if score @s ec.nest_progress >= @s ec.nest_target run function evercraft:nests/complete_gather
