# Nest Family: Begin 3-second harvest progress (mirror forage/start_gather, SHEARS-gated).
# Run as the player who clicked, at player position.

# If already harvesting another nest, ignore.
execute if score @s ec.nest_picking matches 1 run return 0

# Require SHEARS in inventory (any tier — shears are the Lamentor tool, §3 R4 "Bring shears").
data modify storage evercraft:notify stage.c set value [{text:"You need ",color:"red"},{text:"shears",color:"white"},{text:" to harvest a nest.",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute unless items entity @s container.* minecraft:shears run function evercraft:util/notify/emit
execute unless items entity @s container.* minecraft:shears run return 0

# Mark player as harvesting.
scoreboard players set @s ec.nest_picking 1
scoreboard players set @s ec.nest_progress 0

# Skill-scaled harvest duration (5s @ Lamentor L0 -> 1.5s @ L100), stored as the completion target.
scoreboard players operation #gd ec.temp = @s ec.caffl_lm
function evercraft:gather/calc_hdur
scoreboard players operation @s ec.nest_target = #gd ec.temp
# Class nest bonus: Beastlord (ec.bl_active, companion-bond), Healer (any
# healer artifact carried — flagged custom_data.healer:true) and Dual Swordsman
# (ec.ds_active) harvest nests 50% faster: target *= 2/3. Floor of 20t (~1s).
scoreboard players set #cls_boost ec.temp 0
execute if entity @s[tag=ec.bl_active] run scoreboard players set #cls_boost ec.temp 1
execute if items entity @s container.* *[custom_data~{healer:true}] run scoreboard players set #cls_boost ec.temp 1
execute if entity @s[tag=ec.ds_active] run scoreboard players set #cls_boost ec.temp 1
execute if score #cls_boost ec.temp matches 1 run scoreboard players operation @s ec.nest_target *= #tf_2 ec.var
execute if score #cls_boost ec.temp matches 1 run scoreboard players operation @s ec.nest_target /= #tf_3 ec.var
execute if score #cls_boost ec.temp matches 1 if score @s ec.nest_target matches ..20 run scoreboard players set @s ec.nest_target 20
execute store result bossbar evercraft:nest_gather max run scoreboard players get @s ec.nest_target

# Store nest position for range checking during harvest (coord-pin).
execute store result score @s ec.nest_sx run data get entity @e[type=marker,tag=ec.nest_data,distance=..5,limit=1,sort=nearest] Pos[0] 1
execute store result score @s ec.nest_sy run data get entity @e[type=marker,tag=ec.nest_data,distance=..5,limit=1,sort=nearest] Pos[1] 1
execute store result score @s ec.nest_sz run data get entity @e[type=marker,tag=ec.nest_data,distance=..5,limit=1,sort=nearest] Pos[2] 1

# Show boss bar.
bossbar set evercraft:nest_gather value 0
bossbar set evercraft:nest_gather visible true
bossbar set evercraft:nest_gather players @s
# Safety auto-dismiss: clear the bar if it lingers 30s (e.g. interrupted mid-harvest by death).
schedule function evercraft:bossbar/autodismiss/clear/nest_gather 30s replace

# Start cue — a soft single rising iron_xylophone "begin" note (hive identity), channel-gated.
# Replaces the old ungated entity.sheep.shear (a mob-vocal PALETTE VIOLATION). Off/Reduced/Full/Cracked.
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.iron_xylophone master @s ~ ~ ~ 0.4 0.891
# A couple of soft amber glow motes on harvest start (Full+). Reduced is sound-only.
execute if score @s ec.fx_vis matches 2.. run particle falling_nectar ~ ~0.8 ~ 0.25 0.25 0.25 0 3

# Disturbed-hive buzz on interact (2026-06-04, Joseph) — slightly louder one-shot than the faint
# proximity ambient (render_nest, vol 0.25), played once at harvest start. Not looped, so no spam.
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.bee.loop player @s ~ ~ ~ 0.45 1.0
