# Satchel — Ensure the carried bag is in the player's apply-registry (macro, self-heal)
# Args: id (player satchel ID), bid (bag ID of the satchel being opened)
#
# WHY: the satchel MENU reads contents straight from bags.<bag_id> (the item's stamped id), but
# passive effects are applied by iterating registry.<satchel_id> in apply_effects. A bag is only
# added to that registry inside stamp_bag_id, which runs ONLY when bag_id == 0 (the first stamp).
# So a bag that has contents but is missing from the registry — an older satchel from a prior
# build, a storage/migration reset, etc. — shows its items in the menu but grants NO effects
# (e.g. an Amethyst Ring that stores fine but never gives Night Vision). This re-links the bag,
# guarded by the per-bag owner_sid marker so a normally-registered bag is never appended twice.
$execute unless data storage evercraft:satchel registry.$(id) run data modify storage evercraft:satchel registry.$(id) set value []
$execute unless data storage evercraft:satchel bags.$(bid).owner_sid run data modify storage evercraft:satchel registry.$(id) append value $(bid)
$data modify storage evercraft:satchel bags.$(bid).owner_sid set value $(id)
