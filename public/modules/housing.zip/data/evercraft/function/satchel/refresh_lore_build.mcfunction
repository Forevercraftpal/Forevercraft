# Satchel — Build dynamic "Contents:" lore array into storage
# Macro args: $(bid), $(slots)
# Output: storage evercraft:satchel temp.lore_dynamic (array of lore lines)
#
# Layout:
#   [0] header "Contents:"
#   [1..slots] one per slot: "Slot N: <Artifact Name>"  or  "Slot N: Empty"
#
# NAME BAKING (2026-06-19): the artifact name must be BAKED into the lore as a literal component. The old
# build used a live {nbt:"bags...name",storage:...,interpret:true} source — but item tooltips render
# client-side and the client can't read server storage, so the name showed BLANK ("Slot 1: " with nothing
# after). For each occupied slot we append the "Slot N: " skeleton (with an empty extra[0] placeholder),
# then COPY the stored custom_name component into that placeholder server-side. One appended line per slot
# either way, so refresh_lore_strip's (1 header + slots) removal count is unchanged.

# Stage slots count into a temp score so per-slot conditionals can gate on it
$scoreboard players set #lore_slots ec.temp $(slots)

# Reset target array
data modify storage evercraft:satchel temp.lore_dynamic set value []

# Header
data modify storage evercraft:satchel temp.lore_dynamic append value {text:"Contents:",color:"gold",italic:false}

# Slot 0 — always present (every satchel has at least 2 slots)
$execute if data storage evercraft:satchel bags.$(bid).s0.artifact run data modify storage evercraft:satchel temp.lore_dynamic append value {text:"Slot 1: ",color:"gray",italic:false,extra:[{text:"",color:"yellow",italic:false}]}
$execute if data storage evercraft:satchel bags.$(bid).s0.artifact run data modify storage evercraft:satchel temp.lore_dynamic[-1].extra[0] set from storage evercraft:satchel bags.$(bid).s0.name
$execute unless data storage evercraft:satchel bags.$(bid).s0.artifact run data modify storage evercraft:satchel temp.lore_dynamic append value {text:"Slot 1: Empty",color:"dark_gray",italic:false}

# Slot 1
$execute if data storage evercraft:satchel bags.$(bid).s1.artifact run data modify storage evercraft:satchel temp.lore_dynamic append value {text:"Slot 2: ",color:"gray",italic:false,extra:[{text:"",color:"yellow",italic:false}]}
$execute if data storage evercraft:satchel bags.$(bid).s1.artifact run data modify storage evercraft:satchel temp.lore_dynamic[-1].extra[0] set from storage evercraft:satchel bags.$(bid).s1.name
$execute unless data storage evercraft:satchel bags.$(bid).s1.artifact run data modify storage evercraft:satchel temp.lore_dynamic append value {text:"Slot 2: Empty",color:"dark_gray",italic:false}

# Slot 2 — only if slots >= 3
$execute if score #lore_slots ec.temp matches 3.. if data storage evercraft:satchel bags.$(bid).s2.artifact run data modify storage evercraft:satchel temp.lore_dynamic append value {text:"Slot 3: ",color:"gray",italic:false,extra:[{text:"",color:"yellow",italic:false}]}
$execute if score #lore_slots ec.temp matches 3.. if data storage evercraft:satchel bags.$(bid).s2.artifact run data modify storage evercraft:satchel temp.lore_dynamic[-1].extra[0] set from storage evercraft:satchel bags.$(bid).s2.name
$execute if score #lore_slots ec.temp matches 3.. unless data storage evercraft:satchel bags.$(bid).s2.artifact run data modify storage evercraft:satchel temp.lore_dynamic append value {text:"Slot 3: Empty",color:"dark_gray",italic:false}

# Slot 3 — only if slots >= 4
$execute if score #lore_slots ec.temp matches 4.. if data storage evercraft:satchel bags.$(bid).s3.artifact run data modify storage evercraft:satchel temp.lore_dynamic append value {text:"Slot 4: ",color:"gray",italic:false,extra:[{text:"",color:"yellow",italic:false}]}
$execute if score #lore_slots ec.temp matches 4.. if data storage evercraft:satchel bags.$(bid).s3.artifact run data modify storage evercraft:satchel temp.lore_dynamic[-1].extra[0] set from storage evercraft:satchel bags.$(bid).s3.name
$execute if score #lore_slots ec.temp matches 4.. unless data storage evercraft:satchel bags.$(bid).s3.artifact run data modify storage evercraft:satchel temp.lore_dynamic append value {text:"Slot 4: Empty",color:"dark_gray",italic:false}

# Slot 4 — only if slots >= 5
$execute if score #lore_slots ec.temp matches 5.. if data storage evercraft:satchel bags.$(bid).s4.artifact run data modify storage evercraft:satchel temp.lore_dynamic append value {text:"Slot 5: ",color:"gray",italic:false,extra:[{text:"",color:"yellow",italic:false}]}
$execute if score #lore_slots ec.temp matches 5.. if data storage evercraft:satchel bags.$(bid).s4.artifact run data modify storage evercraft:satchel temp.lore_dynamic[-1].extra[0] set from storage evercraft:satchel bags.$(bid).s4.name
$execute if score #lore_slots ec.temp matches 5.. unless data storage evercraft:satchel bags.$(bid).s4.artifact run data modify storage evercraft:satchel temp.lore_dynamic append value {text:"Slot 5: Empty",color:"dark_gray",italic:false}

# Slot 5 — only if slots >= 6
$execute if score #lore_slots ec.temp matches 6.. if data storage evercraft:satchel bags.$(bid).s5.artifact run data modify storage evercraft:satchel temp.lore_dynamic append value {text:"Slot 6: ",color:"gray",italic:false,extra:[{text:"",color:"yellow",italic:false}]}
$execute if score #lore_slots ec.temp matches 6.. if data storage evercraft:satchel bags.$(bid).s5.artifact run data modify storage evercraft:satchel temp.lore_dynamic[-1].extra[0] set from storage evercraft:satchel bags.$(bid).s5.name
$execute if score #lore_slots ec.temp matches 6.. unless data storage evercraft:satchel bags.$(bid).s5.artifact run data modify storage evercraft:satchel temp.lore_dynamic append value {text:"Slot 6: Empty",color:"dark_gray",italic:false}

# Slot 6 — only if slots >= 7
$execute if score #lore_slots ec.temp matches 7.. if data storage evercraft:satchel bags.$(bid).s6.artifact run data modify storage evercraft:satchel temp.lore_dynamic append value {text:"Slot 7: ",color:"gray",italic:false,extra:[{text:"",color:"yellow",italic:false}]}
$execute if score #lore_slots ec.temp matches 7.. if data storage evercraft:satchel bags.$(bid).s6.artifact run data modify storage evercraft:satchel temp.lore_dynamic[-1].extra[0] set from storage evercraft:satchel bags.$(bid).s6.name
$execute if score #lore_slots ec.temp matches 7.. unless data storage evercraft:satchel bags.$(bid).s6.artifact run data modify storage evercraft:satchel temp.lore_dynamic append value {text:"Slot 7: Empty",color:"dark_gray",italic:false}
