# Satchel Upgrade — 9 Uncommon → 1 Rare
advancement revoke @s only evercraft:satchel_upgrade/uncommon
clear @s minecraft:leather[custom_data~{satchel_upgrade_token:true}]
function evercraft:satchel/give_tier {tier:"rare"}
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.smithing_table.use master @s ~ ~ ~ 0.9 1.2
