# Satchel Upgrade — 9 Common → 1 Uncommon
# Fired by advancement evercraft:satchel_upgrade/common (recipe_crafted with
# 9-same-tier-satchel ingredient predicate). The recipe output is a placeholder
# leather token; clear it and grant the upgraded tier.
advancement revoke @s only evercraft:satchel_upgrade/common
clear @s minecraft:leather[custom_data~{satchel_upgrade_token:true}]
function evercraft:satchel/give_tier {tier:"uncommon"}
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.smithing_table.use master @s ~ ~ ~ 0.9 1.2
