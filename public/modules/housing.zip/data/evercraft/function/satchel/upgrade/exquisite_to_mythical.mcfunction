# Satchel Upgrade — 9 Exquisite → 1 Mythical
advancement revoke @s only evercraft:satchel_upgrade/exquisite
clear @s minecraft:leather[custom_data~{satchel_upgrade_token:true}]
function evercraft:satchel/give_tier {tier:"mythical"}
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.smithing_table.use master @s ~ ~ ~ 0.9 1.2
