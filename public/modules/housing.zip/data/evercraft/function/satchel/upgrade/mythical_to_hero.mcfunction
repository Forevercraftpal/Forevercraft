# Satchel Upgrade — 9 Mythical → 1 Hero's Satchel
# Parallel path to the 6-different-tier beacon ritual at satchel_forge.
advancement revoke @s only evercraft:satchel_upgrade/mythical
clear @s minecraft:leather[custom_data~{satchel_upgrade_token:true}]
loot give @s loot evercraft:hero_satchel/hero_satchel
tag @s add ec.satchel_owner
data modify storage evercraft:notify stage.c set value [{text:"Nine Mythical Satchels fuse into a ",color:"gray"},{text:"Hero's Satchel",color:"light_purple",bold:true},{text:"!",color:"gray"}]
scoreboard players set #ndur ec.temp 60
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.beacon.activate master @s ~ ~ ~ 1.0 1.4
