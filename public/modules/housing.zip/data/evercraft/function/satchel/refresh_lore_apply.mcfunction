# Satchel — rewrite the CARTED satchel's "Contents:" lore (macro {slots}).
# Runs after refresh_lore_swap has pulled the item onto the ec.satchel_lcart hopper-minecart. Editing the
# item ON the cart works where `data modify entity @s Inventory[...]` is read-only in 1.21.5+.
#
# The dynamic block is always the LAST (1 header + slots) lines of the item's lore, appended after the
# tier's static base lore. So on a re-refresh we strip that many lines before appending the fresh block.
#
# Steps:
#  1. Read lore_init off the carted item (1 if previously refreshed, else 0).
#  2. If lore_init=1, strip the previous dynamic block (slots+1 lines) from the end.
#  3. Append the fresh dynamic block from temp.lore_dynamic.
#  4. Mark lore_init=1.

# Step 1: read lore_init flag from the carted item (pre-zero first: #lore_init is a shared fake-player
# score, and a failed/missing read must not inherit a stale 1 and trigger a strip on a fresh item)
scoreboard players set #lore_init ec.temp 0
execute store result score #lore_init ec.temp run data get entity @e[type=hopper_minecart,tag=ec.satchel_lcart,limit=1] Items[0].components."minecraft:custom_data".lore_init
execute unless score #lore_init ec.temp matches 1.. run scoreboard players set #lore_init ec.temp 0

# Step 2: if previously initialized, strip prior dynamic block (slots+1 lines from end)
$execute if score #lore_init ec.temp matches 1.. run function evercraft:satchel/refresh_lore_strip {slots:$(slots)}

# Step 3: append fresh dynamic block, line by line (append-from-array would append the array as one
# element; the first 3 lines [header + 2 slots] always exist, the rest are gated on existence)
data modify entity @e[type=hopper_minecart,tag=ec.satchel_lcart,limit=1] Items[0].components."minecraft:lore" append from storage evercraft:satchel temp.lore_dynamic[0]
data modify entity @e[type=hopper_minecart,tag=ec.satchel_lcart,limit=1] Items[0].components."minecraft:lore" append from storage evercraft:satchel temp.lore_dynamic[1]
data modify entity @e[type=hopper_minecart,tag=ec.satchel_lcart,limit=1] Items[0].components."minecraft:lore" append from storage evercraft:satchel temp.lore_dynamic[2]
execute if data storage evercraft:satchel temp.lore_dynamic[3] run data modify entity @e[type=hopper_minecart,tag=ec.satchel_lcart,limit=1] Items[0].components."minecraft:lore" append from storage evercraft:satchel temp.lore_dynamic[3]
execute if data storage evercraft:satchel temp.lore_dynamic[4] run data modify entity @e[type=hopper_minecart,tag=ec.satchel_lcart,limit=1] Items[0].components."minecraft:lore" append from storage evercraft:satchel temp.lore_dynamic[4]
execute if data storage evercraft:satchel temp.lore_dynamic[5] run data modify entity @e[type=hopper_minecart,tag=ec.satchel_lcart,limit=1] Items[0].components."minecraft:lore" append from storage evercraft:satchel temp.lore_dynamic[5]
execute if data storage evercraft:satchel temp.lore_dynamic[6] run data modify entity @e[type=hopper_minecart,tag=ec.satchel_lcart,limit=1] Items[0].components."minecraft:lore" append from storage evercraft:satchel temp.lore_dynamic[6]
execute if data storage evercraft:satchel temp.lore_dynamic[7] run data modify entity @e[type=hopper_minecart,tag=ec.satchel_lcart,limit=1] Items[0].components."minecraft:lore" append from storage evercraft:satchel temp.lore_dynamic[7]

# Step 4: mark lore_init=1 on the carted item
data modify entity @e[type=hopper_minecart,tag=ec.satchel_lcart,limit=1] Items[0].components."minecraft:custom_data".lore_init set value 1b
