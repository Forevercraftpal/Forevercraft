# Satchel & Hero Satchel — Per-player effect application
# Checks hotbar → inventory → bundle contents (early exit on first match)
# Satchel must be on the player to apply stored artifact buffs
# OPT: Sets ec.satchel_owner tag on first find — parent gates on this tag

# === Regular Satchel ===
# Detect whether a regular satchel is currently carried (hotbar > inventory > bundle).
# ec._satcarry is an ephemeral this-tick tag; the short-circuit below preserves the
# prior early-exit so a held regular satchel still skips the hero block.
tag @s remove ec._satcarry
execute if items entity @s hotbar.* *[custom_data~{satchel:true}] run tag @s add ec._satcarry
execute unless entity @s[tag=ec._satcarry] if items entity @s inventory.* *[custom_data~{satchel:true}] run tag @s add ec._satcarry
execute unless entity @s[tag=ec._satcarry] if data entity @s Inventory[{components:{"minecraft:bundle_contents":[{components:{"minecraft:custom_data":{satchel:1b}}}]}}] run tag @s add ec._satcarry

# Marker lifecycle: rebuild the "virtually-held" markers the tick carrying BEGINS,
# clear them the tick it ENDS. Both are transition-gated (ec.sat_carrying latch),
# so the rebuild/clear runs at most once per carry/uncarry — never every tick.
# (Store/withdraw while carrying re-run recompute_marks directly — see the menu fns.)
execute if entity @s[tag=ec._satcarry] unless score @s ec.sat_carrying matches 1 run function evercraft:satchel/recompute_marks
execute unless entity @s[tag=ec._satcarry] if score @s ec.sat_carrying matches 1 run function evercraft:satchel/recompute_clear
execute if entity @s[tag=ec._satcarry] run scoreboard players set @s ec.sat_carrying 1
execute unless entity @s[tag=ec._satcarry] run scoreboard players set @s ec.sat_carrying 0

# Apply stored-artifact passive effects, then short-circuit (held satchel ends here).
# NOTE (2026-06-04): this satchel/effects dispatch now OVERLAPS the ec.sat_<id> marker path (player_tick
# + profession sites grant the same effects from the same markers). The overlap is HARMLESS — both add
# the SAME named luck modifiers / status effects (idempotent: attribute-modifier-add replaces, status
# refreshes) and NO satchel/effects file touches the acc_dodge accumulator (verified), so there is no
# double-dip. Kept as belt-and-suspenders; retiring it is deferred to a future cleanup that first proves
# every satchel/effects/<id> has a player_tick marker equivalent (coverage proof) to avoid regressions.
execute if entity @s[tag=ec._satcarry] run function evercraft:satchel/apply_effects
tag @s remove ec._satcarry
# KNOWN EDGE (flag for #7 race-seat): this return masks the entire hero block while a regular satchel
# is ALSO carried. If a player carries BOTH a Pebble and a regular satchel and then drops ONLY the
# Pebble, ec.peb_carry stays 1 and the Pebble's ec.sat_<id> markers linger until the regular satchel
# is also dropped (then the hero block runs and recompute_pebble_clear fires) — i.e. a narrow
# stale-effect window, self-healing on full uncarry. Proper fix = run the Pebble MARKER lifecycle
# above this return and mask only apply_held; deferred to the council pass to avoid disturbing the
# proven regular-satchel masking here.
execute if score @s ec.sat_carrying matches 1 run return 0

# === Hero Satchel ===
# Detect whether a hero satchel is currently carried (hotbar > inventory > bundle), into an
# ephemeral this-tick tag — same pattern as the regular satchel above.
tag @s remove ec._herocarry
execute if items entity @s hotbar.* *[custom_data~{hero_satchel:true}] run tag @s add ec._herocarry
execute unless entity @s[tag=ec._herocarry] if items entity @s inventory.* *[custom_data~{hero_satchel:true}] run tag @s add ec._herocarry
execute unless entity @s[tag=ec._herocarry] if data entity @s Inventory[{components:{"minecraft:bundle_contents":[{components:{"minecraft:custom_data":{hero_satchel:1b}}}]}}] run tag @s add ec._herocarry

# Pebble spirit-vessel marker lifecycle (parallel to the regular satchel's): rebuild the ec.sat_<id>
# markers for Pebble-stored NORMAL accessories the tick carrying BEGINS, clear them the tick it ENDS.
# Transition-gated on ec.peb_carry so it runs at most once per carry/uncarry — never every tick.
# (A store/withdraw while carrying re-runs recompute_pebble_marks directly — see handle_click.)
execute if entity @s[tag=ec._herocarry] unless score @s ec.peb_carry matches 1 run function evercraft:hero_satchel/recompute_pebble_marks
execute unless entity @s[tag=ec._herocarry] if score @s ec.peb_carry matches 1 run function evercraft:hero_satchel/recompute_pebble_clear
execute if entity @s[tag=ec._herocarry] run scoreboard players set @s ec.peb_carry 1
execute unless entity @s[tag=ec._herocarry] run scoreboard players set @s ec.peb_carry 0

# Apply hero satchel effects (bag-loop boss union + Fusion Wave 1 consolidated capstones) when carried.
execute if entity @s[tag=ec._herocarry] run function evercraft:hero_satchel/apply_held
tag @s remove ec._herocarry
