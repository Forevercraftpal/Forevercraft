# Satchel — Give specific tier (macro)
# Usage: function evercraft:satchel/give_tier {tier:"rare"}
$loot give @s loot evercraft:satchel/$(tier)
tag @s add ec.satchel_owner
$data modify storage evercraft:notify stage.c set value [{text:"You received a $(tier) Essentials Satchel!",color:"yellow"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
