# Satchel — Remove ALL of this player's stored-accessory markers (no rebuild)
# Used on the transition OUT of carrying any satchel: the stored accessories are
# no longer "virtually held", so every ec.sat_<id> tag we set must come off.
# Run as the player (@s).

execute unless score @s ec.satchel_id matches 1.. run return 0
execute store result storage evercraft:satchel temp.id int 1 run scoreboard players get @s ec.satchel_id
function evercraft:satchel/marks/clear_prev with storage evercraft:satchel temp
# Empty the persisted set — nothing is marked now.
data modify storage evercraft:satchel temp.newmarks set value []
function evercraft:satchel/marks/commit with storage evercraft:satchel temp
