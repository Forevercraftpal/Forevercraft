# Satchel — refresh the satchel item's "Contents:" lore so its tooltip lists the artifacts stored inside.
# Run as: the player (during a store / retrieve — NOT during open).
#
# MC 26.2 (1.21.5+): a player's inventory is READ-ONLY via `data modify entity @s Inventory[...]`, so the
# old in-place lore write SILENTLY no-op'd and the satchel tooltip never showed its contents. Fixed
# 2026-06-19 by mirroring forever_sack: locate the satchel's slot, pull the item into a hopper-minecart
# (a writable container), rewrite its lore there, then `item replace` it back into the same slot.
#
# NEVER call this from menu/open: at open the satchel IS the selected (mainhand) slot and the using_item
# open trigger is mid-flight, so swapping the item would race that trigger (the forever_sack reopen bug).
# The floating menu (menu/refresh) already shows live contents while open — the tooltip only needs to be
# rebuilt when contents actually CHANGE, i.e. from try_store_artifact and retrieve_artifact.

# Safety: skip if no bag context
execute unless score @s ec.bag_id matches 1.. run return 0
execute unless score @s ec.satchel_slots matches 1..7 run return 0

# Stage macro args
execute store result storage evercraft:satchel temp.bid int 1 run scoreboard players get @s ec.bag_id
execute store result storage evercraft:satchel temp.slots int 1 run scoreboard players get @s ec.satchel_slots

# Locate the satchel slot (sets temp.slotref + #ss_found). Bail if it isn't anywhere in the inventory.
function evercraft:satchel/find_slot with storage evercraft:satchel temp
execute unless score #ss_found ec.temp matches 1 run return 0

# Build the dynamic "Contents:" block into storage path: evercraft:satchel temp.lore_dynamic
function evercraft:satchel/refresh_lore_build with storage evercraft:satchel temp

# Cart-swap: pull the satchel from its slot, rewrite the lore on the cart, swap it back into the slot
function evercraft:satchel/refresh_lore_swap with storage evercraft:satchel temp

# Clean up temp.lore_dynamic
data remove storage evercraft:satchel temp.lore_dynamic
data remove storage evercraft:satchel temp.lore_old
