# Satchel — cart-swap helper (macro {slots, slotref}). Pull the satchel out of $(slotref) into a writable
# hopper-minecart, rewrite its "Contents:" lore on the cart (refresh_lore_apply), then copy it back into
# the same slot. Mirrors satchel/stamp_bag_id's proven cart trick + forever_sack/refresh_lore. Writing the
# item ON the cart works where `data modify entity @s Inventory[...]` is read-only in 1.21.5+.
#
# Fresh cart first (clear + kill any stale one so a prior failed write can't leak an item on kill).
data modify entity @e[type=hopper_minecart,tag=ec.satchel_lcart,limit=1] Items set value []
kill @e[type=hopper_minecart,tag=ec.satchel_lcart]
execute at @s run summon hopper_minecart ~ ~ ~ {Tags:["ec.satchel_lcart"],Enabled:0b}
$item replace entity @e[type=hopper_minecart,tag=ec.satchel_lcart,limit=1,sort=nearest] container.0 from entity @s $(slotref)

# Rewrite the carted satchel's lore (strip the prior Contents block, append the fresh one).
function evercraft:satchel/refresh_lore_apply with storage evercraft:satchel temp

# Copy the updated item back into the satchel's slot, then clear + kill the cart (item replace is a COPY).
$item replace entity @s $(slotref) from entity @e[type=hopper_minecart,tag=ec.satchel_lcart,limit=1,sort=nearest] container.0
data modify entity @e[type=hopper_minecart,tag=ec.satchel_lcart,limit=1] Items set value []
kill @e[type=hopper_minecart,tag=ec.satchel_lcart]
