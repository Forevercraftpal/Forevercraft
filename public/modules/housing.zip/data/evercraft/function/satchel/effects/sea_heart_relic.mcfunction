# Sea Heart Relic — Water Breathing + Dolphin's Grace + Conduit Power
effect give @s water_breathing 15 0 true
effect give @s dolphins_grace 5 0 true
effect give @s conduit_power 5 0 true
