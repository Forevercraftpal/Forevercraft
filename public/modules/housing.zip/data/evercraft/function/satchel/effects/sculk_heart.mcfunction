# Sculk Heart — +1.5 Dream Rate
execute unless score @s ec.t_sculkhrt matches 1 run attribute @s luck modifier add evercraft:sculk_heart_luck 1.5 add_value
