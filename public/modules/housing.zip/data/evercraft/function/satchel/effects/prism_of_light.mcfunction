# Prism of Light — Absorption IV + Night Vision
effect give @s absorption 5 3 true
effect give @s night_vision 15 0 true
