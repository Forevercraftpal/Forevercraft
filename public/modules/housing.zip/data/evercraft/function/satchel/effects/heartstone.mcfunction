# Heartstone — Regeneration I (unconditional)
execute unless score @s ec.t_heart matches 1 run effect give @s regeneration 5 0 true
