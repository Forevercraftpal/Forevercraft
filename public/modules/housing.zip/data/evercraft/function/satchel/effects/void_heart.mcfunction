# Void Heart — Resistance I
execute unless score @s ec.t_voidhrt matches 1 run effect give @s resistance 5 0 true
