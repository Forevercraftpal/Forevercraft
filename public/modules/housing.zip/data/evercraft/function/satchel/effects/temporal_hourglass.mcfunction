# Temporal Hourglass — Resistance II + Speed II
effect give @s resistance 5 1 true
effect give @s speed 5 1 true
