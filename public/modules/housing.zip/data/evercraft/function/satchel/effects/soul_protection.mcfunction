# Soul Protection — Resistance I + Absorption I
effect give @s resistance 5 0 true
effect give @s absorption 5 0 true
