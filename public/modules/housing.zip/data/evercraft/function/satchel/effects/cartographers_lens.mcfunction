# Cartographer's Lens — Speed I + Saturation
effect give @s speed 5 0 true
effect give @s saturation 3 0 true
