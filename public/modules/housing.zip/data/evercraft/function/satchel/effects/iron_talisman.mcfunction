# Iron Talisman — +1 Armor
# Handled as a fixed-id armor attribute modifier in artifacts/accessories/player_tick (the
# ec.sat_iron_talisman branch covers satchel-held) + stripped in accessory_cleanup, mirroring the
# stoneward_pebble idiom (which likewise has no satchel/effects grant). No effect granted here — doing
# so would double-dip on satchel-held copies. Intentionally a no-op.
