# Heart of the Void — Resistance I + Slow Falling + Night Vision
effect give @s resistance 5 0 true
effect give @s slow_falling 5 0 true
effect give @s night_vision 15 0 true
