# Merchant's Coin — +0.5 Dream Rate
execute unless score @s ec.t_merchant matches 1 run attribute @s luck modifier add evercraft:merchants_coin_luck 0.5 add_value
