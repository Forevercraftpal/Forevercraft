# Satchel — strip the previous "Contents:" dynamic block from the CARTED satchel's lore (macro {slots}).
# Runs on the ec.satchel_lcart hopper-minecart item (refresh_lore_apply pulled it there). Cart NBT is
# writable where `data modify entity @s Inventory[...]` is read-only in 1.21.5+.
#
# The dynamic block is always (1 header + slots) lines at the END. We remove that many. Since slots <= 7
# we unroll the removes with conditional gates on $(slots).
#
# This MUST mirror exactly what refresh_lore_apply appended last time. The contract: nothing else writes
# to a satchel's lore array after refresh_lore_apply marks lore_init=1.

# Ensure #lore_slots reflects this call's slot count
$scoreboard players set #lore_slots ec.temp $(slots)

# Always remove the header (1 line) + the first 2 slot lines (every satchel has >= 2 slots)
data remove entity @e[type=hopper_minecart,tag=ec.satchel_lcart,limit=1] Items[0].components."minecraft:lore"[-1]
data remove entity @e[type=hopper_minecart,tag=ec.satchel_lcart,limit=1] Items[0].components."minecraft:lore"[-1]
data remove entity @e[type=hopper_minecart,tag=ec.satchel_lcart,limit=1] Items[0].components."minecraft:lore"[-1]

# Remove the remaining slot lines, gated on slot count
execute if score #lore_slots ec.temp matches 3.. run data remove entity @e[type=hopper_minecart,tag=ec.satchel_lcart,limit=1] Items[0].components."minecraft:lore"[-1]
execute if score #lore_slots ec.temp matches 4.. run data remove entity @e[type=hopper_minecart,tag=ec.satchel_lcart,limit=1] Items[0].components."minecraft:lore"[-1]
execute if score #lore_slots ec.temp matches 5.. run data remove entity @e[type=hopper_minecart,tag=ec.satchel_lcart,limit=1] Items[0].components."minecraft:lore"[-1]
execute if score #lore_slots ec.temp matches 6.. run data remove entity @e[type=hopper_minecart,tag=ec.satchel_lcart,limit=1] Items[0].components."minecraft:lore"[-1]
execute if score #lore_slots ec.temp matches 7.. run data remove entity @e[type=hopper_minecart,tag=ec.satchel_lcart,limit=1] Items[0].components."minecraft:lore"[-1]
