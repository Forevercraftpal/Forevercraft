# Satchel — Rebuild the player's "virtually-held" accessory markers
# ============================================================================
# Sets one tag  ec.sat_<artifact_id>  per accessory currently stored in ANY of
# this player's registered bags. Downstream detection (player_tick passives +
# profession sites) accepts these tags as an "is-held" source, so a stored
# accessory grants its effect exactly as if it were loose in the inventory.
#
# DRIFT-FREE: we first remove the EXACT set of tags we added last time (kept in
# pmarks.<sid>), then re-scan and re-add — so no stale marker survives a
# withdraw, and we never need a hand-maintained "all known ids" clear list.
#
# COST: runs ONLY on a content/carry change (store, withdraw, or the tick a
# player starts carrying a satchel) — never every tick. See check_and_apply.
# Run as the player (@s).
# ----------------------------------------------------------------------------

# Need a satchel id to locate this player's registry + prev-marks.
execute unless score @s ec.satchel_id matches 1.. run return 0
execute store result storage evercraft:satchel temp.id int 1 run scoreboard players get @s ec.satchel_id

# 1) Remove the markers we set on the previous rebuild (exact, drift-free).
function evercraft:satchel/marks/clear_prev with storage evercraft:satchel temp

# 2) Fresh accumulator for the markers we are about to set.
data modify storage evercraft:satchel temp.newmarks set value []

# 3) Walk every registered bag's slots, tagging each stored id + recording it.
function evercraft:satchel/copy_registry with storage evercraft:satchel temp
function evercraft:satchel/marks/scan_next_bag

# 4) Persist the new marker set so the next rebuild can clear it exactly.
function evercraft:satchel/marks/commit with storage evercraft:satchel temp
