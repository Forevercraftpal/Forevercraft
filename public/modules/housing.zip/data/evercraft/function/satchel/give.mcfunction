# Satchel — Give (defaults to common, use /function evercraft:satchel/give_tier {tier:"uncommon"} etc.)
loot give @s loot evercraft:satchel/common
tag @s add ec.satchel_owner
data modify storage evercraft:notify stage.c set value [{text:"You received a Common Essentials Satchel!",color:"yellow"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
