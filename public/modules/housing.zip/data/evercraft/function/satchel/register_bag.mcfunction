# Satchel — Register bag_id to player's registry (macro)
# Args: id (player satchel ID), new_bid (bag ID to register)

# Ensure player's registry list exists
$execute unless data storage evercraft:satchel registry.$(id) run data modify storage evercraft:satchel registry.$(id) set value []

# Append the new bag_id to the registry
$data modify storage evercraft:satchel registry.$(id) append value $(new_bid)

# Mark this bag as registered under this satchel ID — the idempotency anchor ensure_registered
# checks so a normally-stamped bag is never appended to the registry a second time.
$data modify storage evercraft:satchel bags.$(new_bid).owner_sid set value $(id)
