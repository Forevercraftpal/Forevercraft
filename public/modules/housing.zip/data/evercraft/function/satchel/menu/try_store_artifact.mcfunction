# Satchel Menu — Try to store artifact from mainhand into slot (macro)
# Run as player. Args from storage: bid, slot
# Validates: mainhand has is_artifact, NOT excluded type

# Check mainhand has an artifact. is_artifact:true is the primary gate — any
# artifact (accessory, tool, weapon, armor, spyglass-base, etc.) is storable.
# Removed 2026-06-10: the #evercraft:satchel_excluded vanilla-tool/armor
# blacklist used to also gate here, but it blocked legitimate artifact-tools
# (e.g. Surveyor's Reach-Glass, weapon artifacts, armor artifacts).
# Also accept accessory:true (2026-06-20): the Hand of Creation build PARTS (reach/level/palette/
# refund/scaffold/steady) are accessories but were never given is_artifact, so they failed this gate.
# They carry no custom_data.artifact, so they store cleanly by name and the marker scan skips them
# (scan_bag_slots guards on .artifact) — exactly the storage-only behaviour intended for them.
data modify storage evercraft:notify stage.c set value [{text:"Hold an artifact in your mainhand!",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute unless items entity @s weapon.mainhand *[custom_data~{is_artifact:true}] unless items entity @s weapon.mainhand *[custom_data~{accessory:true}] run function evercraft:util/notify/emit
execute unless items entity @s weapon.mainhand *[custom_data~{is_artifact:true}] unless items entity @s weapon.mainhand *[custom_data~{accessory:true}] run return 0

# Copy artifact custom_data and display name to temp
data modify storage evercraft:satchel temp.mainhand set from entity @s SelectedItem.components."minecraft:custom_data"
data modify storage evercraft:satchel temp.item_name set from entity @s SelectedItem.components."minecraft:custom_name"

# Write artifact ID, display name, and full item to the bag's storage slot
$data modify storage evercraft:satchel bags.$(bid).$(slot).artifact set from storage evercraft:satchel temp.mainhand.artifact
$data modify storage evercraft:satchel bags.$(bid).$(slot).name set from storage evercraft:satchel temp.item_name
$data modify storage evercraft:satchel bags.$(bid).$(slot).item set from entity @s SelectedItem

# Remove item from mainhand
item replace entity @s weapon.mainhand with air

# Increment stored count
scoreboard players add @s ec.satchel_count 1

# Sound + feedback
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:item.bundle.insert master @s ~ ~ ~ 0.8 1.0
data modify storage evercraft:notify stage.c set value [{text:"Artifact stored!",color:"green"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit

# Refresh held satchel's lore so the new contents are reflected on the item itself
function evercraft:satchel/refresh_lore

# Refresh the "virtually-held" markers so the just-stored accessory's effect applies
# immediately (the carry latch is already 1, so check_and_apply won't rebuild on its own).
function evercraft:satchel/recompute_marks
