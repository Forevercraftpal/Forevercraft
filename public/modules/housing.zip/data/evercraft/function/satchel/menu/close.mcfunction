# Satchel Menu — Close
# Run as the player

# Final sweep for unstamped duplicates before closing
# Menu Core: Y-displacement close anchor
tag @s remove ec.menu_active
scoreboard players reset @s ec.menu_open_y

clear @s minecraft:leather[custom_data~{satchel:true,bag_id:0}]

# Kill all menu elements
scoreboard players operation #gui_check ec.temp = @s adv.gui_session
execute as @e[type=text_display,tag=ec.satchel_el,distance=..5] if score @s adv.gui_session = #gui_check ec.temp run kill @s
execute as @e[type=interaction,tag=ec.satchel_el,distance=..5] if score @s adv.gui_session = #gui_check ec.temp run kill @s
execute as @e[type=item_display,tag=ec.satchel_el,distance=..5] if score @s adv.gui_session = #gui_check ec.temp run kill @s

# Remove tags
tag @s remove ec.satchel_in_menu

# Revoke advancement so next right-click can re-trigger
advancement revoke @s only evercraft:satchel/open

# Sound
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.chest.close master @s ~ ~ ~ 0.5 1.2
