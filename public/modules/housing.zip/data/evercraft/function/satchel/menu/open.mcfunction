# Satchel Menu — Open
# Run as the player at their position

# Safety: kill any orphaned menu elements from a previous session
# Menu Core: Y-displacement close anchor
# One-menu-at-a-time (2026-06-15): close any other open menu before this one claims
# ec.menu_active. Two overlapping menus share the @s adv.gui_session slot; the newer
# open orphans the older menu's session, so it can never consume its click -> stuck
# interaction NBT -> click-sound spam. force_close is idempotent (no-op when nothing open).
execute if entity @s[tag=ec.menu_active] run function evercraft:menu_core/force_close
tag @s add ec.menu_active
execute store result score @s ec.menu_open_y run data get entity @s Pos[1] 100
# Sneak-position polish (MP-P3.5): when crouching, lower spawn anchor by 0.20m so
# menu sits at a comfortable view-angle for the lowered eye height. Tag is read by
# every summon line below (paired unless/if) and removed at end-of-file.
tag @s remove ec.menu_sneak_open
execute if predicate evercraft:player_crouching run tag @s add ec.menu_sneak_open


execute at @s run kill @e[type=text_display,tag=ec.satchel_el,distance=..5]
execute at @s run kill @e[type=interaction,tag=ec.satchel_el,distance=..5]
execute at @s run kill @e[type=item_display,tag=ec.satchel_el,distance=..5]

# Tag player as in menu
tag @s add ec.satchel_in_menu

# Copy bag_id to temp for macro access (set by on_open)
execute store result storage evercraft:satchel temp.bid int 1 run scoreboard players get @s ec.bag_id

# Spawn background panel
execute unless entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^ ^2 ^1.8 run summon item_display ~ ~ ~ { Tags:["ec.satchel_el","ec.satchel_bg"], billboard:"center", item:{id:"black_stained_glass_pane",count:1}, item_display:"fixed", transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,-0.02f],scale:[3.0f,2.8f,0.01f]} }
execute if entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^ ^1.8 ^1.8 run summon item_display ~ ~ ~ { Tags:["ec.satchel_el","ec.satchel_bg"], billboard:"center", item:{id:"black_stained_glass_pane",count:1}, item_display:"fixed", transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,-0.02f],scale:[3.0f,2.8f,0.01f]} }

# Spawn title — dynamic based on tier
# Ownership-header label (MP-P3.6): foreign viewers see whose menu this is
# 26.1: {selector:} renders blank in text_display — bake @s's name to a $(owner) literal.
function evercraft:util/gui/owner_name
execute at @s rotated ~ 0 positioned ^ ^2.88 ^1.78 run function evercraft:satchel/menu/open_nm with storage evercraft:scorebake args
execute unless entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^ ^2.7 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f, Tags:["ec.satchel_el","ec.satchel_title"], billboard:"center", text:[{text:"\u2726 ",color:"dark_purple"},{text:"Essentials Satchel",color:"gold",bold:true},{text:" \u2726",color:"dark_purple"}], background:1, shadow:1b, transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.54f,0.54f,0.54f]} }
execute if entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^ ^2.5 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f, Tags:["ec.satchel_el","ec.satchel_title"], billboard:"center", text:[{text:"\u2726 ",color:"dark_purple"},{text:"Essentials Satchel",color:"gold",bold:true},{text:" \u2726",color:"dark_purple"}], background:1, shadow:1b, transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.54f,0.54f,0.54f]} }

# Spawn instruction text
execute unless entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^ ^1.4 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f, Tags:["ec.satchel_el","ec.satchel_hint"], billboard:"center", text:[{text:"Hold artifact + click slot to store",color:"gray",italic:true}], background:0, shadow:1b, transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.338f,0.338f,0.338f]} }
execute if entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^ ^1.2 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f, Tags:["ec.satchel_el","ec.satchel_hint"], billboard:"center", text:[{text:"Hold artifact + click slot to store",color:"gray",italic:true}], background:0, shadow:1b, transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.338f,0.338f,0.338f]} }

# Spawn [Close] button
execute unless entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^ ^1.25 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f, Tags:["ec.satchel_el","ec.satchel_close_txt"], billboard:"center", text:[{text:"[ ",color:"dark_gray"},{text:"Close",color:"gray",bold:true},{text:" ]",color:"dark_gray"}], background:1, shadow:1b, transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.405f,0.405f,0.405f]} }
execute if entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^ ^1.05 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f, Tags:["ec.satchel_el","ec.satchel_close_txt"], billboard:"center", text:[{text:"[ ",color:"dark_gray"},{text:"Close",color:"gray",bold:true},{text:" ]",color:"dark_gray"}], background:1, shadow:1b, transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.405f,0.405f,0.405f]} }
# [strip] ec.satchel_el: 0.5w split into 5 x 0.12 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute unless entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^-0.19 ^1.15 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.satchel_el","ec.satchel_close_btn"], width:0.12f,height:0.12f, response:1b }
execute unless entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^-0.095 ^1.15 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.satchel_el","ec.satchel_close_btn"], width:0.12f,height:0.12f, response:1b }
execute unless entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^0 ^1.15 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.satchel_el","ec.satchel_close_btn"], width:0.12f,height:0.12f, response:1b }
execute unless entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^0.095 ^1.15 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.satchel_el","ec.satchel_close_btn"], width:0.12f,height:0.12f, response:1b }
execute unless entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^0.19 ^1.15 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.satchel_el","ec.satchel_close_btn"], width:0.12f,height:0.12f, response:1b }
# [strip] ec.satchel_el: 0.5w split into 5 x 0.12 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute if entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^-0.19 ^0.95 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.satchel_el","ec.satchel_close_btn"], width:0.12f,height:0.12f, response:1b }
execute if entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^-0.095 ^0.95 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.satchel_el","ec.satchel_close_btn"], width:0.12f,height:0.12f, response:1b }
execute if entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^0 ^0.95 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.satchel_el","ec.satchel_close_btn"], width:0.12f,height:0.12f, response:1b }
execute if entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^0.095 ^0.95 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.satchel_el","ec.satchel_close_btn"], width:0.12f,height:0.12f, response:1b }
execute if entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^0.19 ^0.95 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.satchel_el","ec.satchel_close_btn"], width:0.12f,height:0.12f, response:1b }

# Spawn slot displays (up to 7 — we show max_slots worth)
# Slot 0 — Y offset ^2.65
execute unless entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^ ^2.5 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f, Tags:["ec.satchel_el","ec.satchel_slot_txt","ec.satchel_s0_txt"], billboard:"center", text:[{text:"1. ",color:"gray"},{text:"[Empty]",color:"dark_gray"}], background:0, shadow:1b, transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.405f,0.405f,0.405f]} }
execute if entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^ ^2.3 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f, Tags:["ec.satchel_el","ec.satchel_slot_txt","ec.satchel_s0_txt"], billboard:"center", text:[{text:"1. ",color:"gray"},{text:"[Empty]",color:"dark_gray"}], background:0, shadow:1b, transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.405f,0.405f,0.405f]} }
# [strip] ec.satchel_el: 0.8w split into 5 x 0.17 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute unless entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^-0.315 ^2.415 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.satchel_el","ec.satchel_slot","ec.satchel_s0"], width:0.17f,height:0.17f, response:1b }
execute unless entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^-0.1575 ^2.415 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.satchel_el","ec.satchel_slot","ec.satchel_s0"], width:0.17f,height:0.17f, response:1b }
execute unless entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^0 ^2.415 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.satchel_el","ec.satchel_slot","ec.satchel_s0"], width:0.17f,height:0.17f, response:1b }
execute unless entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^0.1575 ^2.415 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.satchel_el","ec.satchel_slot","ec.satchel_s0"], width:0.17f,height:0.17f, response:1b }
execute unless entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^0.315 ^2.415 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.satchel_el","ec.satchel_slot","ec.satchel_s0"], width:0.17f,height:0.17f, response:1b }
# [strip] ec.satchel_el: 0.8w split into 5 x 0.17 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute if entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^-0.315 ^2.215 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.satchel_el","ec.satchel_slot","ec.satchel_s0"], width:0.17f,height:0.17f, response:1b }
execute if entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^-0.1575 ^2.215 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.satchel_el","ec.satchel_slot","ec.satchel_s0"], width:0.17f,height:0.17f, response:1b }
execute if entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^0 ^2.215 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.satchel_el","ec.satchel_slot","ec.satchel_s0"], width:0.17f,height:0.17f, response:1b }
execute if entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^0.1575 ^2.215 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.satchel_el","ec.satchel_slot","ec.satchel_s0"], width:0.17f,height:0.17f, response:1b }
execute if entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^0.315 ^2.215 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.satchel_el","ec.satchel_slot","ec.satchel_s0"], width:0.17f,height:0.17f, response:1b }

# Slot 1 — Y offset ^2.48
execute unless entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^ ^2.33 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f, Tags:["ec.satchel_el","ec.satchel_slot_txt","ec.satchel_s1_txt"], billboard:"center", text:[{text:"2. ",color:"gray"},{text:"[Empty]",color:"dark_gray"}], background:0, shadow:1b, transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.405f,0.405f,0.405f]} }
execute if entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^ ^2.13 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f, Tags:["ec.satchel_el","ec.satchel_slot_txt","ec.satchel_s1_txt"], billboard:"center", text:[{text:"2. ",color:"gray"},{text:"[Empty]",color:"dark_gray"}], background:0, shadow:1b, transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.405f,0.405f,0.405f]} }
# [strip] ec.satchel_el: 0.8w split into 5 x 0.17 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute unless entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^-0.315 ^2.245 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.satchel_el","ec.satchel_slot","ec.satchel_s1"], width:0.17f,height:0.17f, response:1b }
execute unless entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^-0.1575 ^2.245 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.satchel_el","ec.satchel_slot","ec.satchel_s1"], width:0.17f,height:0.17f, response:1b }
execute unless entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^0 ^2.245 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.satchel_el","ec.satchel_slot","ec.satchel_s1"], width:0.17f,height:0.17f, response:1b }
execute unless entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^0.1575 ^2.245 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.satchel_el","ec.satchel_slot","ec.satchel_s1"], width:0.17f,height:0.17f, response:1b }
execute unless entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^0.315 ^2.245 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.satchel_el","ec.satchel_slot","ec.satchel_s1"], width:0.17f,height:0.17f, response:1b }
# [strip] ec.satchel_el: 0.8w split into 5 x 0.17 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute if entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^-0.315 ^2.045 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.satchel_el","ec.satchel_slot","ec.satchel_s1"], width:0.17f,height:0.17f, response:1b }
execute if entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^-0.1575 ^2.045 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.satchel_el","ec.satchel_slot","ec.satchel_s1"], width:0.17f,height:0.17f, response:1b }
execute if entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^0 ^2.045 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.satchel_el","ec.satchel_slot","ec.satchel_s1"], width:0.17f,height:0.17f, response:1b }
execute if entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^0.1575 ^2.045 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.satchel_el","ec.satchel_slot","ec.satchel_s1"], width:0.17f,height:0.17f, response:1b }
execute if entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^0.315 ^2.045 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.satchel_el","ec.satchel_slot","ec.satchel_s1"], width:0.17f,height:0.17f, response:1b }

# Slot 2 — Y offset ^2.31
execute unless entity @s[tag=ec.menu_sneak_open] if score @s ec.satchel_slots matches 3.. at @s rotated ~ 0 positioned ^ ^2.16 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f, Tags:["ec.satchel_el","ec.satchel_slot_txt","ec.satchel_s2_txt"], billboard:"center", text:[{text:"3. ",color:"gray"},{text:"[Empty]",color:"dark_gray"}], background:0, shadow:1b, transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.405f,0.405f,0.405f]} }
execute if entity @s[tag=ec.menu_sneak_open] if score @s ec.satchel_slots matches 3.. at @s rotated ~ 0 positioned ^ ^1.96 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f, Tags:["ec.satchel_el","ec.satchel_slot_txt","ec.satchel_s2_txt"], billboard:"center", text:[{text:"3. ",color:"gray"},{text:"[Empty]",color:"dark_gray"}], background:0, shadow:1b, transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.405f,0.405f,0.405f]} }
# [strip] ec.satchel_el: 0.8w split into 5 x 0.17 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute unless entity @s[tag=ec.menu_sneak_open] if score @s ec.satchel_slots matches 3.. at @s rotated ~ 0 positioned ^-0.315 ^2.075 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.satchel_el","ec.satchel_slot","ec.satchel_s2"], width:0.17f,height:0.17f, response:1b }
execute unless entity @s[tag=ec.menu_sneak_open] if score @s ec.satchel_slots matches 3.. at @s rotated ~ 0 positioned ^-0.1575 ^2.075 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.satchel_el","ec.satchel_slot","ec.satchel_s2"], width:0.17f,height:0.17f, response:1b }
execute unless entity @s[tag=ec.menu_sneak_open] if score @s ec.satchel_slots matches 3.. at @s rotated ~ 0 positioned ^0 ^2.075 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.satchel_el","ec.satchel_slot","ec.satchel_s2"], width:0.17f,height:0.17f, response:1b }
execute unless entity @s[tag=ec.menu_sneak_open] if score @s ec.satchel_slots matches 3.. at @s rotated ~ 0 positioned ^0.1575 ^2.075 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.satchel_el","ec.satchel_slot","ec.satchel_s2"], width:0.17f,height:0.17f, response:1b }
execute unless entity @s[tag=ec.menu_sneak_open] if score @s ec.satchel_slots matches 3.. at @s rotated ~ 0 positioned ^0.315 ^2.075 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.satchel_el","ec.satchel_slot","ec.satchel_s2"], width:0.17f,height:0.17f, response:1b }
# [strip] ec.satchel_el: 0.8w split into 5 x 0.17 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute if entity @s[tag=ec.menu_sneak_open] if score @s ec.satchel_slots matches 3.. at @s rotated ~ 0 positioned ^-0.315 ^1.875 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.satchel_el","ec.satchel_slot","ec.satchel_s2"], width:0.17f,height:0.17f, response:1b }
execute if entity @s[tag=ec.menu_sneak_open] if score @s ec.satchel_slots matches 3.. at @s rotated ~ 0 positioned ^-0.1575 ^1.875 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.satchel_el","ec.satchel_slot","ec.satchel_s2"], width:0.17f,height:0.17f, response:1b }
execute if entity @s[tag=ec.menu_sneak_open] if score @s ec.satchel_slots matches 3.. at @s rotated ~ 0 positioned ^0 ^1.875 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.satchel_el","ec.satchel_slot","ec.satchel_s2"], width:0.17f,height:0.17f, response:1b }
execute if entity @s[tag=ec.menu_sneak_open] if score @s ec.satchel_slots matches 3.. at @s rotated ~ 0 positioned ^0.1575 ^1.875 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.satchel_el","ec.satchel_slot","ec.satchel_s2"], width:0.17f,height:0.17f, response:1b }
execute if entity @s[tag=ec.menu_sneak_open] if score @s ec.satchel_slots matches 3.. at @s rotated ~ 0 positioned ^0.315 ^1.875 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.satchel_el","ec.satchel_slot","ec.satchel_s2"], width:0.17f,height:0.17f, response:1b }

# Slot 3 — Y offset ^2.14
execute unless entity @s[tag=ec.menu_sneak_open] if score @s ec.satchel_slots matches 4.. at @s rotated ~ 0 positioned ^ ^1.99 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f, Tags:["ec.satchel_el","ec.satchel_slot_txt","ec.satchel_s3_txt"], billboard:"center", text:[{text:"4. ",color:"gray"},{text:"[Empty]",color:"dark_gray"}], background:0, shadow:1b, transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.405f,0.405f,0.405f]} }
execute if entity @s[tag=ec.menu_sneak_open] if score @s ec.satchel_slots matches 4.. at @s rotated ~ 0 positioned ^ ^1.79 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f, Tags:["ec.satchel_el","ec.satchel_slot_txt","ec.satchel_s3_txt"], billboard:"center", text:[{text:"4. ",color:"gray"},{text:"[Empty]",color:"dark_gray"}], background:0, shadow:1b, transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.405f,0.405f,0.405f]} }
# [strip] ec.satchel_el: 0.8w split into 5 x 0.17 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute unless entity @s[tag=ec.menu_sneak_open] if score @s ec.satchel_slots matches 4.. at @s rotated ~ 0 positioned ^-0.315 ^1.905 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.satchel_el","ec.satchel_slot","ec.satchel_s3"], width:0.17f,height:0.17f, response:1b }
execute unless entity @s[tag=ec.menu_sneak_open] if score @s ec.satchel_slots matches 4.. at @s rotated ~ 0 positioned ^-0.1575 ^1.905 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.satchel_el","ec.satchel_slot","ec.satchel_s3"], width:0.17f,height:0.17f, response:1b }
execute unless entity @s[tag=ec.menu_sneak_open] if score @s ec.satchel_slots matches 4.. at @s rotated ~ 0 positioned ^0 ^1.905 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.satchel_el","ec.satchel_slot","ec.satchel_s3"], width:0.17f,height:0.17f, response:1b }
execute unless entity @s[tag=ec.menu_sneak_open] if score @s ec.satchel_slots matches 4.. at @s rotated ~ 0 positioned ^0.1575 ^1.905 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.satchel_el","ec.satchel_slot","ec.satchel_s3"], width:0.17f,height:0.17f, response:1b }
execute unless entity @s[tag=ec.menu_sneak_open] if score @s ec.satchel_slots matches 4.. at @s rotated ~ 0 positioned ^0.315 ^1.905 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.satchel_el","ec.satchel_slot","ec.satchel_s3"], width:0.17f,height:0.17f, response:1b }
# [strip] ec.satchel_el: 0.8w split into 5 x 0.17 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute if entity @s[tag=ec.menu_sneak_open] if score @s ec.satchel_slots matches 4.. at @s rotated ~ 0 positioned ^-0.315 ^1.705 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.satchel_el","ec.satchel_slot","ec.satchel_s3"], width:0.17f,height:0.17f, response:1b }
execute if entity @s[tag=ec.menu_sneak_open] if score @s ec.satchel_slots matches 4.. at @s rotated ~ 0 positioned ^-0.1575 ^1.705 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.satchel_el","ec.satchel_slot","ec.satchel_s3"], width:0.17f,height:0.17f, response:1b }
execute if entity @s[tag=ec.menu_sneak_open] if score @s ec.satchel_slots matches 4.. at @s rotated ~ 0 positioned ^0 ^1.705 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.satchel_el","ec.satchel_slot","ec.satchel_s3"], width:0.17f,height:0.17f, response:1b }
execute if entity @s[tag=ec.menu_sneak_open] if score @s ec.satchel_slots matches 4.. at @s rotated ~ 0 positioned ^0.1575 ^1.705 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.satchel_el","ec.satchel_slot","ec.satchel_s3"], width:0.17f,height:0.17f, response:1b }
execute if entity @s[tag=ec.menu_sneak_open] if score @s ec.satchel_slots matches 4.. at @s rotated ~ 0 positioned ^0.315 ^1.705 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.satchel_el","ec.satchel_slot","ec.satchel_s3"], width:0.17f,height:0.17f, response:1b }

# Slot 4 — Y offset ^1.97
execute unless entity @s[tag=ec.menu_sneak_open] if score @s ec.satchel_slots matches 5.. at @s rotated ~ 0 positioned ^ ^1.82 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f, Tags:["ec.satchel_el","ec.satchel_slot_txt","ec.satchel_s4_txt"], billboard:"center", text:[{text:"5. ",color:"gray"},{text:"[Empty]",color:"dark_gray"}], background:0, shadow:1b, transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.405f,0.405f,0.405f]} }
execute if entity @s[tag=ec.menu_sneak_open] if score @s ec.satchel_slots matches 5.. at @s rotated ~ 0 positioned ^ ^1.62 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f, Tags:["ec.satchel_el","ec.satchel_slot_txt","ec.satchel_s4_txt"], billboard:"center", text:[{text:"5. ",color:"gray"},{text:"[Empty]",color:"dark_gray"}], background:0, shadow:1b, transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.405f,0.405f,0.405f]} }
# [strip] ec.satchel_el: 0.8w split into 5 x 0.17 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute unless entity @s[tag=ec.menu_sneak_open] if score @s ec.satchel_slots matches 5.. at @s rotated ~ 0 positioned ^-0.315 ^1.735 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.satchel_el","ec.satchel_slot","ec.satchel_s4"], width:0.17f,height:0.17f, response:1b }
execute unless entity @s[tag=ec.menu_sneak_open] if score @s ec.satchel_slots matches 5.. at @s rotated ~ 0 positioned ^-0.1575 ^1.735 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.satchel_el","ec.satchel_slot","ec.satchel_s4"], width:0.17f,height:0.17f, response:1b }
execute unless entity @s[tag=ec.menu_sneak_open] if score @s ec.satchel_slots matches 5.. at @s rotated ~ 0 positioned ^0 ^1.735 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.satchel_el","ec.satchel_slot","ec.satchel_s4"], width:0.17f,height:0.17f, response:1b }
execute unless entity @s[tag=ec.menu_sneak_open] if score @s ec.satchel_slots matches 5.. at @s rotated ~ 0 positioned ^0.1575 ^1.735 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.satchel_el","ec.satchel_slot","ec.satchel_s4"], width:0.17f,height:0.17f, response:1b }
execute unless entity @s[tag=ec.menu_sneak_open] if score @s ec.satchel_slots matches 5.. at @s rotated ~ 0 positioned ^0.315 ^1.735 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.satchel_el","ec.satchel_slot","ec.satchel_s4"], width:0.17f,height:0.17f, response:1b }
# [strip] ec.satchel_el: 0.8w split into 5 x 0.17 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute if entity @s[tag=ec.menu_sneak_open] if score @s ec.satchel_slots matches 5.. at @s rotated ~ 0 positioned ^-0.315 ^1.535 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.satchel_el","ec.satchel_slot","ec.satchel_s4"], width:0.17f,height:0.17f, response:1b }
execute if entity @s[tag=ec.menu_sneak_open] if score @s ec.satchel_slots matches 5.. at @s rotated ~ 0 positioned ^-0.1575 ^1.535 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.satchel_el","ec.satchel_slot","ec.satchel_s4"], width:0.17f,height:0.17f, response:1b }
execute if entity @s[tag=ec.menu_sneak_open] if score @s ec.satchel_slots matches 5.. at @s rotated ~ 0 positioned ^0 ^1.535 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.satchel_el","ec.satchel_slot","ec.satchel_s4"], width:0.17f,height:0.17f, response:1b }
execute if entity @s[tag=ec.menu_sneak_open] if score @s ec.satchel_slots matches 5.. at @s rotated ~ 0 positioned ^0.1575 ^1.535 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.satchel_el","ec.satchel_slot","ec.satchel_s4"], width:0.17f,height:0.17f, response:1b }
execute if entity @s[tag=ec.menu_sneak_open] if score @s ec.satchel_slots matches 5.. at @s rotated ~ 0 positioned ^0.315 ^1.535 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.satchel_el","ec.satchel_slot","ec.satchel_s4"], width:0.17f,height:0.17f, response:1b }

# Slot 5 — Y offset ^1.80
execute unless entity @s[tag=ec.menu_sneak_open] if score @s ec.satchel_slots matches 6.. at @s rotated ~ 0 positioned ^ ^1.65 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f, Tags:["ec.satchel_el","ec.satchel_slot_txt","ec.satchel_s5_txt"], billboard:"center", text:[{text:"6. ",color:"gray"},{text:"[Empty]",color:"dark_gray"}], background:0, shadow:1b, transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.405f,0.405f,0.405f]} }
execute if entity @s[tag=ec.menu_sneak_open] if score @s ec.satchel_slots matches 6.. at @s rotated ~ 0 positioned ^ ^1.45 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f, Tags:["ec.satchel_el","ec.satchel_slot_txt","ec.satchel_s5_txt"], billboard:"center", text:[{text:"6. ",color:"gray"},{text:"[Empty]",color:"dark_gray"}], background:0, shadow:1b, transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.405f,0.405f,0.405f]} }
# [strip] ec.satchel_el: 0.8w split into 5 x 0.17 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute unless entity @s[tag=ec.menu_sneak_open] if score @s ec.satchel_slots matches 6.. at @s rotated ~ 0 positioned ^-0.315 ^1.565 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.satchel_el","ec.satchel_slot","ec.satchel_s5"], width:0.17f,height:0.17f, response:1b }
execute unless entity @s[tag=ec.menu_sneak_open] if score @s ec.satchel_slots matches 6.. at @s rotated ~ 0 positioned ^-0.1575 ^1.565 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.satchel_el","ec.satchel_slot","ec.satchel_s5"], width:0.17f,height:0.17f, response:1b }
execute unless entity @s[tag=ec.menu_sneak_open] if score @s ec.satchel_slots matches 6.. at @s rotated ~ 0 positioned ^0 ^1.565 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.satchel_el","ec.satchel_slot","ec.satchel_s5"], width:0.17f,height:0.17f, response:1b }
execute unless entity @s[tag=ec.menu_sneak_open] if score @s ec.satchel_slots matches 6.. at @s rotated ~ 0 positioned ^0.1575 ^1.565 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.satchel_el","ec.satchel_slot","ec.satchel_s5"], width:0.17f,height:0.17f, response:1b }
execute unless entity @s[tag=ec.menu_sneak_open] if score @s ec.satchel_slots matches 6.. at @s rotated ~ 0 positioned ^0.315 ^1.565 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.satchel_el","ec.satchel_slot","ec.satchel_s5"], width:0.17f,height:0.17f, response:1b }
# [strip] ec.satchel_el: 0.8w split into 5 x 0.17 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute if entity @s[tag=ec.menu_sneak_open] if score @s ec.satchel_slots matches 6.. at @s rotated ~ 0 positioned ^-0.315 ^1.365 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.satchel_el","ec.satchel_slot","ec.satchel_s5"], width:0.17f,height:0.17f, response:1b }
execute if entity @s[tag=ec.menu_sneak_open] if score @s ec.satchel_slots matches 6.. at @s rotated ~ 0 positioned ^-0.1575 ^1.365 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.satchel_el","ec.satchel_slot","ec.satchel_s5"], width:0.17f,height:0.17f, response:1b }
execute if entity @s[tag=ec.menu_sneak_open] if score @s ec.satchel_slots matches 6.. at @s rotated ~ 0 positioned ^0 ^1.365 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.satchel_el","ec.satchel_slot","ec.satchel_s5"], width:0.17f,height:0.17f, response:1b }
execute if entity @s[tag=ec.menu_sneak_open] if score @s ec.satchel_slots matches 6.. at @s rotated ~ 0 positioned ^0.1575 ^1.365 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.satchel_el","ec.satchel_slot","ec.satchel_s5"], width:0.17f,height:0.17f, response:1b }
execute if entity @s[tag=ec.menu_sneak_open] if score @s ec.satchel_slots matches 6.. at @s rotated ~ 0 positioned ^0.315 ^1.365 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.satchel_el","ec.satchel_slot","ec.satchel_s5"], width:0.17f,height:0.17f, response:1b }

# Slot 6 — Y offset ^1.63
execute unless entity @s[tag=ec.menu_sneak_open] if score @s ec.satchel_slots matches 7 at @s rotated ~ 0 positioned ^ ^1.48 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f, Tags:["ec.satchel_el","ec.satchel_slot_txt","ec.satchel_s6_txt"], billboard:"center", text:[{text:"7. ",color:"gray"},{text:"[Empty]",color:"dark_gray"}], background:0, shadow:1b, transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.405f,0.405f,0.405f]} }
execute if entity @s[tag=ec.menu_sneak_open] if score @s ec.satchel_slots matches 7 at @s rotated ~ 0 positioned ^ ^1.28 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f, Tags:["ec.satchel_el","ec.satchel_slot_txt","ec.satchel_s6_txt"], billboard:"center", text:[{text:"7. ",color:"gray"},{text:"[Empty]",color:"dark_gray"}], background:0, shadow:1b, transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.405f,0.405f,0.405f]} }
# [strip] ec.satchel_el: 0.8w split into 7 x 0.12 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute unless entity @s[tag=ec.menu_sneak_open] if score @s ec.satchel_slots matches 7 at @s rotated ~ 0 positioned ^-0.34 ^1.36 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.satchel_el","ec.satchel_slot","ec.satchel_s6"], width:0.12f,height:0.08f, response:1b }
execute unless entity @s[tag=ec.menu_sneak_open] if score @s ec.satchel_slots matches 7 at @s rotated ~ 0 positioned ^-0.2267 ^1.36 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.satchel_el","ec.satchel_slot","ec.satchel_s6"], width:0.12f,height:0.08f, response:1b }
execute unless entity @s[tag=ec.menu_sneak_open] if score @s ec.satchel_slots matches 7 at @s rotated ~ 0 positioned ^-0.1133 ^1.36 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.satchel_el","ec.satchel_slot","ec.satchel_s6"], width:0.12f,height:0.08f, response:1b }
execute unless entity @s[tag=ec.menu_sneak_open] if score @s ec.satchel_slots matches 7 at @s rotated ~ 0 positioned ^0 ^1.36 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.satchel_el","ec.satchel_slot","ec.satchel_s6"], width:0.12f,height:0.08f, response:1b }
execute unless entity @s[tag=ec.menu_sneak_open] if score @s ec.satchel_slots matches 7 at @s rotated ~ 0 positioned ^0.1133 ^1.36 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.satchel_el","ec.satchel_slot","ec.satchel_s6"], width:0.12f,height:0.08f, response:1b }
execute unless entity @s[tag=ec.menu_sneak_open] if score @s ec.satchel_slots matches 7 at @s rotated ~ 0 positioned ^0.2267 ^1.36 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.satchel_el","ec.satchel_slot","ec.satchel_s6"], width:0.12f,height:0.08f, response:1b }
execute unless entity @s[tag=ec.menu_sneak_open] if score @s ec.satchel_slots matches 7 at @s rotated ~ 0 positioned ^0.34 ^1.36 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.satchel_el","ec.satchel_slot","ec.satchel_s6"], width:0.12f,height:0.08f, response:1b }
# [strip] ec.satchel_el: 0.8w split into 7 x 0.12 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute if entity @s[tag=ec.menu_sneak_open] if score @s ec.satchel_slots matches 7 at @s rotated ~ 0 positioned ^-0.34 ^1.16 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.satchel_el","ec.satchel_slot","ec.satchel_s6"], width:0.12f,height:0.08f, response:1b }
execute if entity @s[tag=ec.menu_sneak_open] if score @s ec.satchel_slots matches 7 at @s rotated ~ 0 positioned ^-0.2267 ^1.16 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.satchel_el","ec.satchel_slot","ec.satchel_s6"], width:0.12f,height:0.08f, response:1b }
execute if entity @s[tag=ec.menu_sneak_open] if score @s ec.satchel_slots matches 7 at @s rotated ~ 0 positioned ^-0.1133 ^1.16 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.satchel_el","ec.satchel_slot","ec.satchel_s6"], width:0.12f,height:0.08f, response:1b }
execute if entity @s[tag=ec.menu_sneak_open] if score @s ec.satchel_slots matches 7 at @s rotated ~ 0 positioned ^0 ^1.16 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.satchel_el","ec.satchel_slot","ec.satchel_s6"], width:0.12f,height:0.08f, response:1b }
execute if entity @s[tag=ec.menu_sneak_open] if score @s ec.satchel_slots matches 7 at @s rotated ~ 0 positioned ^0.1133 ^1.16 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.satchel_el","ec.satchel_slot","ec.satchel_s6"], width:0.12f,height:0.08f, response:1b }
execute if entity @s[tag=ec.menu_sneak_open] if score @s ec.satchel_slots matches 7 at @s rotated ~ 0 positioned ^0.2267 ^1.16 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.satchel_el","ec.satchel_slot","ec.satchel_s6"], width:0.12f,height:0.08f, response:1b }
execute if entity @s[tag=ec.menu_sneak_open] if score @s ec.satchel_slots matches 7 at @s rotated ~ 0 positioned ^0.34 ^1.16 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.satchel_el","ec.satchel_slot","ec.satchel_s6"], width:0.12f,height:0.08f, response:1b }

# Refresh slot displays with actual contents from storage
function evercraft:satchel/menu/refresh

# NOTE (2026-06-19): do NOT refresh the held satchel's lore here. At open the satchel is the selected
# (mainhand) slot and the using_item open trigger is mid-flight; the lore refresh now does a real
# item-swap (cart pull + item replace), and swapping the held item on the open tick races that trigger
# (the forever_sack reopen bug). The floating slot displays above (menu/refresh) already show live
# contents while the menu is open, and the item tooltip is rebuilt on every store/retrieve — so the
# tooltip stays current without touching the held item during open.

# Start menu tick for click responsiveness
schedule function evercraft:satchel/menu_tick 2t replace

# Sound

# Session isolation
scoreboard players add #gui_session ec.var 1
scoreboard players operation @s adv.gui_session = #gui_session ec.var
scoreboard players operation #gui_stamp ec.temp = @s adv.gui_session
execute as @e[type=text_display,tag=ec.satchel_el,distance=..5] unless score @s adv.gui_session matches 1.. run scoreboard players operation @s adv.gui_session = #gui_stamp ec.temp
execute as @e[type=item_display,tag=ec.satchel_el,distance=..5] unless score @s adv.gui_session matches 1.. run scoreboard players operation @s adv.gui_session = #gui_stamp ec.temp
execute as @e[type=interaction,tag=ec.satchel_el,distance=..5] unless score @s adv.gui_session matches 1.. run scoreboard players operation @s adv.gui_session = #gui_stamp ec.temp

execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.chest.open master @s ~ ~ ~ 0.5 1.2

# Sneak-position polish cleanup
tag @s remove ec.menu_sneak_open
