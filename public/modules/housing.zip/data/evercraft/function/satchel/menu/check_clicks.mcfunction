# Satchel Menu — Check Clicks
# Run as the player with menu open, at their position

scoreboard players operation #gui_owner ec.temp = @s adv.gui_session

# Close button
execute as @e[type=interaction,tag=ec.satchel_close_btn,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction on target run function evercraft:satchel/menu/close
execute as @e[type=interaction,tag=ec.satchel_close_btn,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction
execute unless entity @s[tag=ec.satchel_in_menu] run return 0

# Slot 0
execute as @e[type=interaction,tag=ec.satchel_s0,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction on target run function evercraft:satchel/menu/on_slot_click {slot:"s0",num:1}
execute as @e[type=interaction,tag=ec.satchel_s0,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction

# Slot 1
execute as @e[type=interaction,tag=ec.satchel_s1,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction on target run function evercraft:satchel/menu/on_slot_click {slot:"s1",num:1}
execute as @e[type=interaction,tag=ec.satchel_s1,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction

# Slot 2
execute as @e[type=interaction,tag=ec.satchel_s2,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction on target run function evercraft:satchel/menu/on_slot_click {slot:"s2",num:1}
execute as @e[type=interaction,tag=ec.satchel_s2,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction

# Slot 3
execute as @e[type=interaction,tag=ec.satchel_s3,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction on target run function evercraft:satchel/menu/on_slot_click {slot:"s3",num:1}
execute as @e[type=interaction,tag=ec.satchel_s3,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction

# Slot 4
execute as @e[type=interaction,tag=ec.satchel_s4,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction on target run function evercraft:satchel/menu/on_slot_click {slot:"s4",num:1}
execute as @e[type=interaction,tag=ec.satchel_s4,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction

# Slot 5
execute as @e[type=interaction,tag=ec.satchel_s5,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction on target run function evercraft:satchel/menu/on_slot_click {slot:"s5",num:1}
execute as @e[type=interaction,tag=ec.satchel_s5,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction

# Slot 6
execute as @e[type=interaction,tag=ec.satchel_s6,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction on target run function evercraft:satchel/menu/on_slot_click {slot:"s6",num:1}
execute as @e[type=interaction,tag=ec.satchel_s6,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction

# ===== INSPECT (left-click = what does this button do?) — gui/inspect pattern 2026-06-11 =====
execute as @e[type=interaction,tag=ec.satchel_close_btn,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Close",b:"Closes the satchel."}
execute as @e[type=interaction,tag=ec.satchel_close_btn,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=ec.satchel_s0,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"First Satchel Pocket",b:"Satchel pocket 1. Right-click filled to take the artifact out, or right-click empty to store the artifact you are holding. Stored pieces keep granting their powers."}
execute as @e[type=interaction,tag=ec.satchel_s0,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=ec.satchel_s1,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Second Satchel Pocket",b:"Satchel pocket 2. Right-click filled to take the artifact out, or right-click empty to store the artifact you are holding. Stored pieces keep granting their powers."}
execute as @e[type=interaction,tag=ec.satchel_s1,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=ec.satchel_s2,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Third Satchel Pocket",b:"Satchel pocket 3. Right-click filled to take the artifact out, or right-click empty to store the artifact you are holding. Stored pieces keep granting their powers."}
execute as @e[type=interaction,tag=ec.satchel_s2,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=ec.satchel_s3,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Fourth Satchel Pocket",b:"Satchel pocket 4. Right-click filled to take the artifact out, or right-click empty to store the artifact you are holding. Stored pieces keep granting their powers."}
execute as @e[type=interaction,tag=ec.satchel_s3,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=ec.satchel_s4,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Fifth Satchel Pocket",b:"Satchel pocket 5. Right-click filled to take the artifact out, or right-click empty to store the artifact you are holding. Stored pieces keep granting their powers."}
execute as @e[type=interaction,tag=ec.satchel_s4,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=ec.satchel_s5,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Sixth Satchel Pocket",b:"Satchel pocket 6. Right-click filled to take the artifact out, or right-click empty to store the artifact you are holding. Stored pieces keep granting their powers."}
execute as @e[type=interaction,tag=ec.satchel_s5,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=ec.satchel_s6,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Seventh Satchel Pocket",b:"Satchel pocket 7. Right-click filled to take the artifact out, or right-click empty to store the artifact you are holding. Stored pieces keep granting their powers."}
execute as @e[type=interaction,tag=ec.satchel_s6,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack run data remove entity @s attack
