# Satchel marks — Mark every stored artifact in one bag's 7 slots (macro)
# Args: current_bid (bag ID). Mirrors apply_bag_slots, but marks instead of applies.
$execute if data storage evercraft:satchel bags.$(current_bid).s0.artifact run data modify storage evercraft:satchel temp.artifact set from storage evercraft:satchel bags.$(current_bid).s0.artifact
execute if data storage evercraft:satchel temp.artifact run function evercraft:satchel/marks/mark_one with storage evercraft:satchel temp
data remove storage evercraft:satchel temp.artifact

$execute if data storage evercraft:satchel bags.$(current_bid).s1.artifact run data modify storage evercraft:satchel temp.artifact set from storage evercraft:satchel bags.$(current_bid).s1.artifact
execute if data storage evercraft:satchel temp.artifact run function evercraft:satchel/marks/mark_one with storage evercraft:satchel temp
data remove storage evercraft:satchel temp.artifact

$execute if data storage evercraft:satchel bags.$(current_bid).s2.artifact run data modify storage evercraft:satchel temp.artifact set from storage evercraft:satchel bags.$(current_bid).s2.artifact
execute if data storage evercraft:satchel temp.artifact run function evercraft:satchel/marks/mark_one with storage evercraft:satchel temp
data remove storage evercraft:satchel temp.artifact

$execute if data storage evercraft:satchel bags.$(current_bid).s3.artifact run data modify storage evercraft:satchel temp.artifact set from storage evercraft:satchel bags.$(current_bid).s3.artifact
execute if data storage evercraft:satchel temp.artifact run function evercraft:satchel/marks/mark_one with storage evercraft:satchel temp
data remove storage evercraft:satchel temp.artifact

$execute if data storage evercraft:satchel bags.$(current_bid).s4.artifact run data modify storage evercraft:satchel temp.artifact set from storage evercraft:satchel bags.$(current_bid).s4.artifact
execute if data storage evercraft:satchel temp.artifact run function evercraft:satchel/marks/mark_one with storage evercraft:satchel temp
data remove storage evercraft:satchel temp.artifact

$execute if data storage evercraft:satchel bags.$(current_bid).s5.artifact run data modify storage evercraft:satchel temp.artifact set from storage evercraft:satchel bags.$(current_bid).s5.artifact
execute if data storage evercraft:satchel temp.artifact run function evercraft:satchel/marks/mark_one with storage evercraft:satchel temp
data remove storage evercraft:satchel temp.artifact

$execute if data storage evercraft:satchel bags.$(current_bid).s6.artifact run data modify storage evercraft:satchel temp.artifact set from storage evercraft:satchel bags.$(current_bid).s6.artifact
execute if data storage evercraft:satchel temp.artifact run function evercraft:satchel/marks/mark_one with storage evercraft:satchel temp
data remove storage evercraft:satchel temp.artifact
