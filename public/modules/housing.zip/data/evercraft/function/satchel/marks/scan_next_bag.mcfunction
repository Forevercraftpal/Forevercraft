# Satchel marks — Walk the next registered bag (recursive; mirrors apply_next_bag)
execute unless data storage evercraft:satchel temp.bag_iter[0] run return 0
data modify storage evercraft:satchel temp.current_bid set from storage evercraft:satchel temp.bag_iter[0]
data remove storage evercraft:satchel temp.bag_iter[0]
function evercraft:satchel/marks/scan_bag_slots with storage evercraft:satchel temp
function evercraft:satchel/marks/scan_next_bag
