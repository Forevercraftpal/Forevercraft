# Satchel marks — Persist the freshly-built marker set for this player (macro)
# Args: id (player satchel ID). Stored so the next rebuild can clear it exactly.
$data modify storage evercraft:satchel pmarks.$(id) set from storage evercraft:satchel temp.newmarks
