# Satchel marks — Recursively remove one previous marker tag at a time
execute unless data storage evercraft:satchel temp.clear_iter[0] run return 0
data modify storage evercraft:satchel temp.clear_one set from storage evercraft:satchel temp.clear_iter[0]
data remove storage evercraft:satchel temp.clear_iter[0]
function evercraft:satchel/marks/clear_one with storage evercraft:satchel temp
function evercraft:satchel/marks/clear_next
