# Satchel marks — Load the previous marker set into an iteration list (macro)
# Args: id (player satchel ID). Copies the persisted pmarks list, then recurses
# removing one tag per element. A missing pmarks list is a no-op (empty iter).
$data modify storage evercraft:satchel temp.clear_iter set from storage evercraft:satchel pmarks.$(id)
function evercraft:satchel/marks/clear_next
