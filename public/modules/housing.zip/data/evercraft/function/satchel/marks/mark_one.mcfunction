# Satchel marks — Set the marker for one stored artifact + record it (macro)
# Args: artifact (artifact id string). The tag add is macro'd; the record append
# reads temp.artifact straight from storage (no macro needed).
$tag @s add ec.sat_$(artifact)
data modify storage evercraft:satchel temp.newmarks append from storage evercraft:satchel temp.artifact
