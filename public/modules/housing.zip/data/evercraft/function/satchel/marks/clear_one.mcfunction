# Satchel marks — Remove a single stored-accessory marker tag (macro)
# Args: clear_one (artifact id string)
$tag @s remove ec.sat_$(clear_one)
