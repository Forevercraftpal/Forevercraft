# Ingredient Binder — On right-click (consume_item trigger)
# consume_item fires BEFORE the game removes the item.
# Tag for 1-tick delayed restore, then handle menu logic.

advancement revoke @s only evercraft:alch_binder/open

# Tag for delayed restore (next tick restores the binder item)
# Detect which hand held the binder for correct restore
tag @s remove ec.binder_mainhand
execute if items entity @s weapon.mainhand *[custom_data~{alch_binder:true}] run tag @s add ec.binder_mainhand
tag @s add ec.binder_restore

# If already in menu, toggle close
execute if entity @s[tag=ec.binder_in_menu] run function evercraft:alch_binder/menu/close
execute if entity @s[tag=ec.binder_in_menu] run return 0

# Ensure player has a binder ID
execute unless score @s ec.binder_id matches 1.. run function evercraft:alch_binder/assign_id

# Read binder_id from held item (still present this tick, before removal)
execute store result score @s ec.abid run data get entity @s SelectedItem.components."minecraft:custom_data".binder_id

# If binder_id is 0, stamp a new one via hopper minecart intermediary
execute if score @s ec.abid matches 0 run function evercraft:alch_binder/stamp_id

# Clear any unstamped duplicate
clear @s minecraft:book[custom_data~{alch_binder:true,binder_id:0b}]

# Store binder_id to temp for menu macros
execute store result storage evercraft:alch_binder temp.pid int 1 run scoreboard players get @s ec.abid

# Save item data for restore (preserves stamped binder_id)
data modify storage evercraft:alch_binder temp.restore_item set from entity @s SelectedItem
# Migrate legacy items: drop max_stack_size:1 so the binder shares a bundle (weight 1, like the satchels)
data remove storage evercraft:alch_binder temp.restore_item.components."minecraft:max_stack_size"

# Initialize storage if missing
function evercraft:alch_binder/init_if_missing with storage evercraft:alch_binder temp

# Open the menu
function evercraft:alch_binder/menu/open
