# Ingredient Binder — Assign unique ID to player
scoreboard players add #next_binder_id ec.var 1
scoreboard players operation @s ec.binder_id = #next_binder_id ec.var
