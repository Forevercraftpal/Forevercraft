# Ingredient Binder — Restore item after consume_item removal (1 tick delayed)
tag @s remove ec.binder_restore

# Restore via hopper minecart intermediary (preserves stamped binder_id + all NBT)
summon hopper_minecart ~ 320 ~ {Tags:["ec.binder_cart"],Enabled:0b,Items:[{Slot:0b,id:"minecraft:stone",count:1}]}
data modify entity @e[type=hopper_minecart,tag=ec.binder_cart,limit=1] Items[0] merge from storage evercraft:alch_binder temp.restore_item

# Restore to correct hand
execute if entity @s[tag=ec.binder_mainhand] run item replace entity @s weapon.mainhand from entity @e[type=hopper_minecart,tag=ec.binder_cart,limit=1] container.0
execute unless entity @s[tag=ec.binder_mainhand] run item replace entity @s weapon.offhand from entity @e[type=hopper_minecart,tag=ec.binder_cart,limit=1] container.0
tag @s remove ec.binder_mainhand

data modify entity @e[type=hopper_minecart,tag=ec.binder_cart,limit=1] Items set value []
kill @e[type=hopper_minecart,tag=ec.binder_cart]
