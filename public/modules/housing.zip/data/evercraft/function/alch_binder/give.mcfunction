# Ingredient Binder — Give binder item to player
# Inv-full guard: drop at the player's feet rather than void on a full inventory.
execute store result score #inv_full ec.var run function evercraft:util/check_inv_full
execute if score #inv_full ec.var matches 0 run loot give @s loot evercraft:alch_binder/alch_binder
execute if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:alch_binder/alch_binder
scoreboard players set @s ec.has_binder 1
data modify storage evercraft:notify stage.c set value [{text:"⚗ ",color:"#9B59B6"},{text:"You received an ",color:"green"},{text:"Ingredient Binder",color:"#9B59B6",bold:true},{text:"! Store chemistry reagents inside.",color:"green"},{text:" ⚗",color:"#9B59B6"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 0.8 1.4
