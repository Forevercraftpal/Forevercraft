# ============================================================
# INGREDIENT BINDER SYSTEM — Load
# ============================================================
# Portable alchemy storage: reagents and alchemy materials.

# Scoreboards
scoreboard objectives add ec.binder_id dummy "Binder Player ID"
scoreboard objectives add ec.has_binder dummy "Has Binder"
scoreboard objectives add ec.binder_page dummy "Binder GUI Page"
scoreboard objectives add ec.abid dummy "Active Binder ID"

# Global binder ID counter
execute unless score #next_binder_id ec.var matches 1.. run scoreboard players set #next_binder_id ec.var 0
