# Binder Menu — Retrieve item from slot (macro)
# Args: pid, slot

# Summon temp item entity, copy stored item data
# --- Volume stacking (Joseph 2026-06-20): pull up to one stack (64), decrement qty, clear at 0 ---
# Amount to pull: min(qty,64). Legacy slots without qty default to 1.
scoreboard players set #binder_q ec.temp 1
$execute store result score #binder_q ec.temp run data get storage evercraft:alch_binder bags.$(pid).$(slot).qty
scoreboard players operation #binder_give ec.temp = #binder_q ec.temp
execute if score #binder_give ec.temp matches 65.. run scoreboard players set #binder_give ec.temp 64

# Summon the stack, set its count, hand it to the player
execute at @s run summon item ~ ~1 ~ {Tags:["ec.binder_tmp"],PickupDelay:0,Item:{id:"minecraft:stone",count:1}}
$data modify entity @e[type=item,tag=ec.binder_tmp,limit=1] Item set from storage evercraft:alch_binder bags.$(pid).$(slot).item
execute store result entity @e[type=item,tag=ec.binder_tmp,limit=1] Item.count int 1 run scoreboard players get #binder_give ec.temp
tp @e[type=item,tag=ec.binder_tmp,limit=1] @s
tag @e[type=item,tag=ec.binder_tmp,limit=1] remove ec.binder_tmp

# Decrement remaining qty; clear the slot when it hits 0
scoreboard players operation #binder_q ec.temp -= #binder_give ec.temp
$execute if score #binder_q ec.temp matches ..0 run data modify storage evercraft:alch_binder bags.$(pid).$(slot) set value {}
$execute if score #binder_q ec.temp matches 1.. store result storage evercraft:alch_binder bags.$(pid).$(slot).qty int 1 run scoreboard players get #binder_q ec.temp

# Sound + feedback
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:item.bundle.remove_one master @s ~ ~ ~ 0.8 1.0
data modify storage evercraft:notify stage.c set value [{text:"Item retrieved!",color:"yellow"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit_keyed {key:18}
