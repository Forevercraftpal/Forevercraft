# Binder Menu — Refresh Slots (macro)
# Args from temp.rargs: pid, s0-s8 (slot names for this page)
# Updates each of the 9 slot text_displays with stored item name or [Empty]

# Slot 0
$execute if data storage evercraft:alch_binder bags.$(pid).$(s0).item run data modify storage evercraft:alch_binder temp._r0 set value [{text:"",color:"#9B59B6",extra:[{storage:"evercraft:alch_binder",nbt:"bags.$(pid).$(s0).name",interpret:true}]},{text:" \u00d7",color:"dark_gray"},{storage:"evercraft:alch_binder",nbt:"bags.$(pid).$(s0).qty",color:"white"},{text:" ⚗",color:"dark_purple"}]
$execute if data storage evercraft:alch_binder bags.$(pid).$(s0).item at @a[tag=ec.binder_in_menu] as @e[type=text_display,tag=ec.binder_s0_txt,distance=..5] run data modify entity @s text set from storage evercraft:alch_binder temp._r0
$execute unless data storage evercraft:alch_binder bags.$(pid).$(s0).item at @a[tag=ec.binder_in_menu] as @e[type=text_display,tag=ec.binder_s0_txt,distance=..5] run data modify entity @s text set value [{text:"[Empty]",color:"dark_gray"}]

# Slot 1
$execute if data storage evercraft:alch_binder bags.$(pid).$(s1).item run data modify storage evercraft:alch_binder temp._r1 set value [{text:"",color:"#9B59B6",extra:[{storage:"evercraft:alch_binder",nbt:"bags.$(pid).$(s1).name",interpret:true}]},{text:" \u00d7",color:"dark_gray"},{storage:"evercraft:alch_binder",nbt:"bags.$(pid).$(s1).qty",color:"white"},{text:" ⚗",color:"dark_purple"}]
$execute if data storage evercraft:alch_binder bags.$(pid).$(s1).item at @a[tag=ec.binder_in_menu] as @e[type=text_display,tag=ec.binder_s1_txt,distance=..5] run data modify entity @s text set from storage evercraft:alch_binder temp._r1
$execute unless data storage evercraft:alch_binder bags.$(pid).$(s1).item at @a[tag=ec.binder_in_menu] as @e[type=text_display,tag=ec.binder_s1_txt,distance=..5] run data modify entity @s text set value [{text:"[Empty]",color:"dark_gray"}]

# Slot 2
$execute if data storage evercraft:alch_binder bags.$(pid).$(s2).item run data modify storage evercraft:alch_binder temp._r2 set value [{text:"",color:"#9B59B6",extra:[{storage:"evercraft:alch_binder",nbt:"bags.$(pid).$(s2).name",interpret:true}]},{text:" \u00d7",color:"dark_gray"},{storage:"evercraft:alch_binder",nbt:"bags.$(pid).$(s2).qty",color:"white"},{text:" ⚗",color:"dark_purple"}]
$execute if data storage evercraft:alch_binder bags.$(pid).$(s2).item at @a[tag=ec.binder_in_menu] as @e[type=text_display,tag=ec.binder_s2_txt,distance=..5] run data modify entity @s text set from storage evercraft:alch_binder temp._r2
$execute unless data storage evercraft:alch_binder bags.$(pid).$(s2).item at @a[tag=ec.binder_in_menu] as @e[type=text_display,tag=ec.binder_s2_txt,distance=..5] run data modify entity @s text set value [{text:"[Empty]",color:"dark_gray"}]

# Slot 3
$execute if data storage evercraft:alch_binder bags.$(pid).$(s3).item run data modify storage evercraft:alch_binder temp._r3 set value [{text:"",color:"#9B59B6",extra:[{storage:"evercraft:alch_binder",nbt:"bags.$(pid).$(s3).name",interpret:true}]},{text:" \u00d7",color:"dark_gray"},{storage:"evercraft:alch_binder",nbt:"bags.$(pid).$(s3).qty",color:"white"},{text:" ⚗",color:"dark_purple"}]
$execute if data storage evercraft:alch_binder bags.$(pid).$(s3).item at @a[tag=ec.binder_in_menu] as @e[type=text_display,tag=ec.binder_s3_txt,distance=..5] run data modify entity @s text set from storage evercraft:alch_binder temp._r3
$execute unless data storage evercraft:alch_binder bags.$(pid).$(s3).item at @a[tag=ec.binder_in_menu] as @e[type=text_display,tag=ec.binder_s3_txt,distance=..5] run data modify entity @s text set value [{text:"[Empty]",color:"dark_gray"}]

# Slot 4
$execute if data storage evercraft:alch_binder bags.$(pid).$(s4).item run data modify storage evercraft:alch_binder temp._r4 set value [{text:"",color:"#9B59B6",extra:[{storage:"evercraft:alch_binder",nbt:"bags.$(pid).$(s4).name",interpret:true}]},{text:" \u00d7",color:"dark_gray"},{storage:"evercraft:alch_binder",nbt:"bags.$(pid).$(s4).qty",color:"white"},{text:" ⚗",color:"dark_purple"}]
$execute if data storage evercraft:alch_binder bags.$(pid).$(s4).item at @a[tag=ec.binder_in_menu] as @e[type=text_display,tag=ec.binder_s4_txt,distance=..5] run data modify entity @s text set from storage evercraft:alch_binder temp._r4
$execute unless data storage evercraft:alch_binder bags.$(pid).$(s4).item at @a[tag=ec.binder_in_menu] as @e[type=text_display,tag=ec.binder_s4_txt,distance=..5] run data modify entity @s text set value [{text:"[Empty]",color:"dark_gray"}]

# Slot 5
$execute if data storage evercraft:alch_binder bags.$(pid).$(s5).item run data modify storage evercraft:alch_binder temp._r5 set value [{text:"",color:"#9B59B6",extra:[{storage:"evercraft:alch_binder",nbt:"bags.$(pid).$(s5).name",interpret:true}]},{text:" \u00d7",color:"dark_gray"},{storage:"evercraft:alch_binder",nbt:"bags.$(pid).$(s5).qty",color:"white"},{text:" ⚗",color:"dark_purple"}]
$execute if data storage evercraft:alch_binder bags.$(pid).$(s5).item at @a[tag=ec.binder_in_menu] as @e[type=text_display,tag=ec.binder_s5_txt,distance=..5] run data modify entity @s text set from storage evercraft:alch_binder temp._r5
$execute unless data storage evercraft:alch_binder bags.$(pid).$(s5).item at @a[tag=ec.binder_in_menu] as @e[type=text_display,tag=ec.binder_s5_txt,distance=..5] run data modify entity @s text set value [{text:"[Empty]",color:"dark_gray"}]

# Slot 6
$execute if data storage evercraft:alch_binder bags.$(pid).$(s6).item run data modify storage evercraft:alch_binder temp._r6 set value [{text:"",color:"#9B59B6",extra:[{storage:"evercraft:alch_binder",nbt:"bags.$(pid).$(s6).name",interpret:true}]},{text:" \u00d7",color:"dark_gray"},{storage:"evercraft:alch_binder",nbt:"bags.$(pid).$(s6).qty",color:"white"},{text:" ⚗",color:"dark_purple"}]
$execute if data storage evercraft:alch_binder bags.$(pid).$(s6).item at @a[tag=ec.binder_in_menu] as @e[type=text_display,tag=ec.binder_s6_txt,distance=..5] run data modify entity @s text set from storage evercraft:alch_binder temp._r6
$execute unless data storage evercraft:alch_binder bags.$(pid).$(s6).item at @a[tag=ec.binder_in_menu] as @e[type=text_display,tag=ec.binder_s6_txt,distance=..5] run data modify entity @s text set value [{text:"[Empty]",color:"dark_gray"}]

# Slot 7
$execute if data storage evercraft:alch_binder bags.$(pid).$(s7).item run data modify storage evercraft:alch_binder temp._r7 set value [{text:"",color:"#9B59B6",extra:[{storage:"evercraft:alch_binder",nbt:"bags.$(pid).$(s7).name",interpret:true}]},{text:" \u00d7",color:"dark_gray"},{storage:"evercraft:alch_binder",nbt:"bags.$(pid).$(s7).qty",color:"white"},{text:" ⚗",color:"dark_purple"}]
$execute if data storage evercraft:alch_binder bags.$(pid).$(s7).item at @a[tag=ec.binder_in_menu] as @e[type=text_display,tag=ec.binder_s7_txt,distance=..5] run data modify entity @s text set from storage evercraft:alch_binder temp._r7
$execute unless data storage evercraft:alch_binder bags.$(pid).$(s7).item at @a[tag=ec.binder_in_menu] as @e[type=text_display,tag=ec.binder_s7_txt,distance=..5] run data modify entity @s text set value [{text:"[Empty]",color:"dark_gray"}]

# Slot 8
$execute if data storage evercraft:alch_binder bags.$(pid).$(s8).item run data modify storage evercraft:alch_binder temp._r8 set value [{text:"",color:"#9B59B6",extra:[{storage:"evercraft:alch_binder",nbt:"bags.$(pid).$(s8).name",interpret:true}]},{text:" \u00d7",color:"dark_gray"},{storage:"evercraft:alch_binder",nbt:"bags.$(pid).$(s8).qty",color:"white"},{text:" ⚗",color:"dark_purple"}]
$execute if data storage evercraft:alch_binder bags.$(pid).$(s8).item at @a[tag=ec.binder_in_menu] as @e[type=text_display,tag=ec.binder_s8_txt,distance=..5] run data modify entity @s text set from storage evercraft:alch_binder temp._r8
$execute unless data storage evercraft:alch_binder bags.$(pid).$(s8).item at @a[tag=ec.binder_in_menu] as @e[type=text_display,tag=ec.binder_s8_txt,distance=..5] run data modify entity @s text set value [{text:"[Empty]",color:"dark_gray"}]
