# Binder Menu — Try Store (macro)
# Args: pid, slot
# Validates mainhand is an alchemy material, stores it to the binder slot

# Check mainhand has an alchemy material
scoreboard players set #binder_valid ec.temp 0
execute if data entity @s SelectedItem.components."minecraft:custom_data".alch_mat run scoreboard players set #binder_valid ec.temp 1

data modify storage evercraft:notify stage.c set value [{text:"Hold an chemistry reagent in your mainhand!",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute if score #binder_valid ec.temp matches 0 run function evercraft:util/notify/emit_keyed {key:17}
execute if score #binder_valid ec.temp matches 0 run return 0

# --- Volume stacking (Joseph 2026-06-20): merge same-type items into one growing slot ---
# Held stack count
execute store result score #binder_count ec.temp run data get entity @s SelectedItem.count

# Build the stacking key: item id + "#" + sub-id (alch_mat if present, else "")
data modify storage evercraft:alch_binder temp.kb.id set from entity @s SelectedItem.id
data modify storage evercraft:alch_binder temp.kb.sub set value ""
execute if data entity @s SelectedItem.components."minecraft:custom_data".alch_mat run data modify storage evercraft:alch_binder temp.kb.sub set from entity @s SelectedItem.components."minecraft:custom_data".alch_mat
function evercraft:alch_binder/menu/mk_key with storage evercraft:alch_binder temp.kb

# Find an existing slot holding this key (#fk + temp.tgt) or the lowest empty slot (#fe)
data modify storage evercraft:alch_binder temp.fa.pid set from storage evercraft:alch_binder temp.pid
data modify storage evercraft:alch_binder temp.fa.hk set from storage evercraft:alch_binder temp.held_key
function evercraft:alch_binder/menu/find_slot with storage evercraft:alch_binder temp.fa

# Target slot = matching slot if found, else the clicked (empty) slot
execute if score #fk ec.temp matches 1 run data modify storage evercraft:alch_binder temp.write_slot set from storage evercraft:alch_binder temp.tgt
$execute if score #fk ec.temp matches 0 run data modify storage evercraft:alch_binder temp.write_slot set value "$(slot)"

# qty to add = held stack count
execute store result storage evercraft:alch_binder temp.qty_add int 1 run scoreboard players get #binder_count ec.temp

# Commit (merge or fresh) then remove the whole held stack from mainhand
function evercraft:alch_binder/menu/do_store with storage evercraft:alch_binder temp
item replace entity @s weapon.mainhand with air

# Craftforever milestone tracking
scoreboard players add @s ec.binder_stored 1

# Sound + feedback
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:item.bundle.insert master @s ~ ~ ~ 0.8 1.0
data modify storage evercraft:notify stage.c set value [{text:"Item stored!",color:"green"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit_keyed {key:16}
