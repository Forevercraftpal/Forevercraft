# Binder Menu — Check Clicks
# Run as the player with menu open, at their position

scoreboard players operation #gui_owner ec.temp = @s adv.gui_session

# Close button
execute as @e[type=interaction,tag=ec.binder_close_btn,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction on target run function evercraft:alch_binder/menu/close
execute as @e[type=interaction,tag=ec.binder_close_btn,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction
execute unless entity @s[tag=ec.binder_in_menu] run return 0

# Prev page [<]
execute as @e[type=interaction,tag=ec.binder_prev_btn,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction on target run function evercraft:alch_binder/menu/prev_page
execute as @e[type=interaction,tag=ec.binder_prev_btn,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction

# Next page [>]
execute as @e[type=interaction,tag=ec.binder_next_btn,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction on target run function evercraft:alch_binder/menu/next_page
execute as @e[type=interaction,tag=ec.binder_next_btn,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction

# Slot 0
execute as @e[type=interaction,tag=ec.binder_s0,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction on target run function evercraft:alch_binder/menu/on_slot_click {local_slot:0}
execute as @e[type=interaction,tag=ec.binder_s0,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction

# Slot 1
execute as @e[type=interaction,tag=ec.binder_s1,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction on target run function evercraft:alch_binder/menu/on_slot_click {local_slot:1}
execute as @e[type=interaction,tag=ec.binder_s1,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction

# Slot 2
execute as @e[type=interaction,tag=ec.binder_s2,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction on target run function evercraft:alch_binder/menu/on_slot_click {local_slot:2}
execute as @e[type=interaction,tag=ec.binder_s2,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction

# Slot 3
execute as @e[type=interaction,tag=ec.binder_s3,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction on target run function evercraft:alch_binder/menu/on_slot_click {local_slot:3}
execute as @e[type=interaction,tag=ec.binder_s3,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction

# Slot 4
execute as @e[type=interaction,tag=ec.binder_s4,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction on target run function evercraft:alch_binder/menu/on_slot_click {local_slot:4}
execute as @e[type=interaction,tag=ec.binder_s4,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction

# Slot 5
execute as @e[type=interaction,tag=ec.binder_s5,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction on target run function evercraft:alch_binder/menu/on_slot_click {local_slot:5}
execute as @e[type=interaction,tag=ec.binder_s5,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction

# Slot 6
execute as @e[type=interaction,tag=ec.binder_s6,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction on target run function evercraft:alch_binder/menu/on_slot_click {local_slot:6}
execute as @e[type=interaction,tag=ec.binder_s6,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction

# Slot 7
execute as @e[type=interaction,tag=ec.binder_s7,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction on target run function evercraft:alch_binder/menu/on_slot_click {local_slot:7}
execute as @e[type=interaction,tag=ec.binder_s7,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction

# Slot 8
execute as @e[type=interaction,tag=ec.binder_s8,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction on target run function evercraft:alch_binder/menu/on_slot_click {local_slot:8}
execute as @e[type=interaction,tag=ec.binder_s8,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction

# ===== INSPECT (left-click = what does this button do?) — gui/inspect pattern 2026-06-11 =====
execute as @e[type=interaction,tag=ec.binder_close_btn,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Close",b:"Closes the binder."}
execute as @e[type=interaction,tag=ec.binder_close_btn,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=ec.binder_prev_btn,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Previous Page",b:"Flips to the previous page of binder sleeves."}
execute as @e[type=interaction,tag=ec.binder_prev_btn,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=ec.binder_next_btn,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Next Page",b:"Flips to the next page of binder sleeves."}
execute as @e[type=interaction,tag=ec.binder_next_btn,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=ec.binder_s0,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"First Sleeve",b:"Binder sleeve 1. Right-click filled to take the stored brew back, or right-click empty to store the brew you are holding."}
execute as @e[type=interaction,tag=ec.binder_s0,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=ec.binder_s1,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Second Sleeve",b:"Binder sleeve 2. Right-click filled to take the stored brew back, or right-click empty to store the brew you are holding."}
execute as @e[type=interaction,tag=ec.binder_s1,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=ec.binder_s2,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Third Sleeve",b:"Binder sleeve 3. Right-click filled to take the stored brew back, or right-click empty to store the brew you are holding."}
execute as @e[type=interaction,tag=ec.binder_s2,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=ec.binder_s3,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Fourth Sleeve",b:"Binder sleeve 4. Right-click filled to take the stored brew back, or right-click empty to store the brew you are holding."}
execute as @e[type=interaction,tag=ec.binder_s3,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=ec.binder_s4,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Fifth Sleeve",b:"Binder sleeve 5. Right-click filled to take the stored brew back, or right-click empty to store the brew you are holding."}
execute as @e[type=interaction,tag=ec.binder_s4,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=ec.binder_s5,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Sixth Sleeve",b:"Binder sleeve 6. Right-click filled to take the stored brew back, or right-click empty to store the brew you are holding."}
execute as @e[type=interaction,tag=ec.binder_s5,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=ec.binder_s6,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Seventh Sleeve",b:"Binder sleeve 7. Right-click filled to take the stored brew back, or right-click empty to store the brew you are holding."}
execute as @e[type=interaction,tag=ec.binder_s6,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=ec.binder_s7,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Eighth Sleeve",b:"Binder sleeve 8. Right-click filled to take the stored brew back, or right-click empty to store the brew you are holding."}
execute as @e[type=interaction,tag=ec.binder_s7,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=ec.binder_s8,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Ninth Sleeve",b:"Binder sleeve 9. Right-click filled to take the stored brew back, or right-click empty to store the brew you are holding."}
execute as @e[type=interaction,tag=ec.binder_s8,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack run data remove entity @s attack
