# Binder Menu — On Slot Click (macro)
# Args: local_slot (0-8, display position on current page)
# Calculates actual storage slot from page * 9 + local_slot

# Calculate actual slot index: page * 9 + local_slot
$scoreboard players set #binder_local ec.temp $(local_slot)
scoreboard players operation #binder_abs ec.temp = @s ec.binder_page
scoreboard players set #binder_9 ec.temp 9
scoreboard players operation #binder_abs ec.temp *= #binder_9 ec.temp
scoreboard players operation #binder_abs ec.temp += #binder_local ec.temp

# Store pid and absolute slot name to temp storage
execute store result storage evercraft:alch_binder temp.pid int 1 run scoreboard players get @s ec.abid

# Map absolute index (0-26) to slot name (s0-s26) via dispatch
function evercraft:alch_binder/menu/resolve_slot
