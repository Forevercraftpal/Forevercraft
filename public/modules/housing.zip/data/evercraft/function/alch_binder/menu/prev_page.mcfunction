# Binder Menu — Prev Page
data modify storage evercraft:notify stage.c set value [{text:"Already on first page!",color:"gray"}]
scoreboard players set #ndur ec.temp 45
execute if score @s ec.binder_page matches 0 run return run function evercraft:util/notify/emit
scoreboard players remove @s ec.binder_page 1
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.hat master @s ~ ~ ~ 0.5 1.8
function evercraft:alch_binder/menu/refresh
