# Binder Menu — Tick (runs every 2t for players with menu open)
# Called from menu_tick, run as each player with ec.binder_in_menu tag

# Close if player walked too far from menu entities
execute unless entity @e[type=item_display,tag=ec.binder_bg,distance=..5] run function evercraft:alch_binder/menu/close
execute unless entity @s[tag=ec.binder_in_menu] run return 0

# Close if binder no longer anywhere on player (inventory, hotbar, or bundle)
execute unless items entity @s inventory.* *[custom_data~{alch_binder:true}] unless items entity @s hotbar.* *[custom_data~{alch_binder:true}] unless data entity @s Inventory[{components:{"minecraft:bundle_contents":[{components:{"minecraft:custom_data":{alch_binder:1b}}}]}}] run function evercraft:alch_binder/menu/close
execute unless entity @s[tag=ec.binder_in_menu] run return 0

# Unified UI-click FX (Joseph 2026-06-05): play the gated cue ONCE if any ec.binder_el element registered
# a click this tick, before check_clicks consumes it.
execute if entity @e[type=interaction,tag=ec.binder_el,distance=..6,nbt={interaction:{}},limit=1] run function evercraft:fx/ui/click

# Check for clicks
function evercraft:alch_binder/menu/check_clicks
