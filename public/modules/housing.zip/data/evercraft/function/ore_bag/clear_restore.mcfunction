# Ore Bag — Clear this player's consumed restore key (macro).
# WA59-P0-RACE (2026-06-22). Caller (restore_item) must set temp.uuid from entity @s UUID.
$data remove storage evercraft:ore_bag restore."$(uuid)"
