# Ore Bag — Assign unique ID to player
scoreboard players add #next_orebag_id ec.var 1
scoreboard players operation @s ec.orebag_id = #next_orebag_id ec.var
