# Ore Bag — Give ore bag item to player
# Inv-full guard: drop at the player's feet rather than void on a full inventory.
execute store result score #inv_full ec.var run function evercraft:util/check_inv_full
execute if score #inv_full ec.var matches 0 run loot give @s loot evercraft:ore_bag/ore_bag
execute if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:ore_bag/ore_bag
scoreboard players set @s ec.has_orebag 1
data modify storage evercraft:notify stage.c set value [{text:"\u2692 ",color:"#C0C0C0"},{text:"You received an ",color:"green"},{text:"Ore Bag",color:"#C0C0C0",bold:true},{text:"! Store forge materials inside.",color:"green"},{text:" \u2692",color:"#C0C0C0"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 0.8 1.4
