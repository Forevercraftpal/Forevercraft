# ============================================================
# ORE BAG SYSTEM — Load
# ============================================================
# Portable forge storage: forge materials for crafting.

# Scoreboards
scoreboard objectives add ec.orebag_id dummy "Ore Bag Player ID"
scoreboard objectives add ec.has_orebag dummy "Has Ore Bag"
scoreboard objectives add ec.orebag_page dummy "Ore Bag GUI Page"
scoreboard objectives add ec.obid dummy "Active Ore Bag ID"

# Global ore bag ID counter
execute unless score #next_orebag_id ec.var matches 1.. run scoreboard players set #next_orebag_id ec.var 0
