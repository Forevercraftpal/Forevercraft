# Ore Bag — Store pending restore item under the player's UUID (macro).
# WA59-P0-RACE (2026-06-22): per-UUID key prevents same-tick RC cross-clobber.
# Caller (on_use) must set: temp.restore_item (the item) + temp.uuid (set from entity @s UUID).
$data modify storage evercraft:ore_bag restore."$(uuid)".item set from storage evercraft:ore_bag temp.restore_item
