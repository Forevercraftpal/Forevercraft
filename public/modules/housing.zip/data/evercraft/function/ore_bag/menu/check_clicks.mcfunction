# Ore Bag Menu — Check Clicks
# Run as the player with menu open, at their position

scoreboard players operation #gui_owner ec.temp = @s adv.gui_session

# Close button
execute as @e[type=interaction,tag=ec.orebag_close_btn,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction on target run function evercraft:ore_bag/menu/close
execute as @e[type=interaction,tag=ec.orebag_close_btn,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction
execute unless entity @s[tag=ec.orebag_in_menu] run return 0

# Prev page [<]
execute as @e[type=interaction,tag=ec.orebag_prev_btn,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction on target run function evercraft:ore_bag/menu/prev_page
execute as @e[type=interaction,tag=ec.orebag_prev_btn,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction

# Next page [>]
execute as @e[type=interaction,tag=ec.orebag_next_btn,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction on target run function evercraft:ore_bag/menu/next_page
execute as @e[type=interaction,tag=ec.orebag_next_btn,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction

# Slot 0
execute as @e[type=interaction,tag=ec.orebag_s0,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction on target run function evercraft:ore_bag/menu/on_slot_click {local_slot:0}
execute as @e[type=interaction,tag=ec.orebag_s0,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction

# Slot 1
execute as @e[type=interaction,tag=ec.orebag_s1,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction on target run function evercraft:ore_bag/menu/on_slot_click {local_slot:1}
execute as @e[type=interaction,tag=ec.orebag_s1,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction

# Slot 2
execute as @e[type=interaction,tag=ec.orebag_s2,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction on target run function evercraft:ore_bag/menu/on_slot_click {local_slot:2}
execute as @e[type=interaction,tag=ec.orebag_s2,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction

# Slot 3
execute as @e[type=interaction,tag=ec.orebag_s3,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction on target run function evercraft:ore_bag/menu/on_slot_click {local_slot:3}
execute as @e[type=interaction,tag=ec.orebag_s3,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction

# Slot 4
execute as @e[type=interaction,tag=ec.orebag_s4,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction on target run function evercraft:ore_bag/menu/on_slot_click {local_slot:4}
execute as @e[type=interaction,tag=ec.orebag_s4,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction

# Slot 5
execute as @e[type=interaction,tag=ec.orebag_s5,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction on target run function evercraft:ore_bag/menu/on_slot_click {local_slot:5}
execute as @e[type=interaction,tag=ec.orebag_s5,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction

# Slot 6
execute as @e[type=interaction,tag=ec.orebag_s6,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction on target run function evercraft:ore_bag/menu/on_slot_click {local_slot:6}
execute as @e[type=interaction,tag=ec.orebag_s6,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction

# Slot 7
execute as @e[type=interaction,tag=ec.orebag_s7,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction on target run function evercraft:ore_bag/menu/on_slot_click {local_slot:7}
execute as @e[type=interaction,tag=ec.orebag_s7,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction

# Slot 8
execute as @e[type=interaction,tag=ec.orebag_s8,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction on target run function evercraft:ore_bag/menu/on_slot_click {local_slot:8}
execute as @e[type=interaction,tag=ec.orebag_s8,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction

# ===== INSPECT (left-click = what does this button do?) — gui/inspect pattern 2026-06-11 =====
execute as @e[type=interaction,tag=ec.orebag_close_btn,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Close",b:"Closes the ore bag."}
execute as @e[type=interaction,tag=ec.orebag_close_btn,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=ec.orebag_prev_btn,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Previous Page",b:"Flips to the previous page of ore pouches."}
execute as @e[type=interaction,tag=ec.orebag_prev_btn,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=ec.orebag_next_btn,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Next Page",b:"Flips to the next page of ore pouches."}
execute as @e[type=interaction,tag=ec.orebag_next_btn,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=ec.orebag_s0,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"First Pouch",b:"Ore pouch 1. Right-click filled to take the stored ore back, or right-click empty to store the ore you are holding."}
execute as @e[type=interaction,tag=ec.orebag_s0,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=ec.orebag_s1,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Second Pouch",b:"Ore pouch 2. Right-click filled to take the stored ore back, or right-click empty to store the ore you are holding."}
execute as @e[type=interaction,tag=ec.orebag_s1,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=ec.orebag_s2,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Third Pouch",b:"Ore pouch 3. Right-click filled to take the stored ore back, or right-click empty to store the ore you are holding."}
execute as @e[type=interaction,tag=ec.orebag_s2,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=ec.orebag_s3,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Fourth Pouch",b:"Ore pouch 4. Right-click filled to take the stored ore back, or right-click empty to store the ore you are holding."}
execute as @e[type=interaction,tag=ec.orebag_s3,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=ec.orebag_s4,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Fifth Pouch",b:"Ore pouch 5. Right-click filled to take the stored ore back, or right-click empty to store the ore you are holding."}
execute as @e[type=interaction,tag=ec.orebag_s4,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=ec.orebag_s5,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Sixth Pouch",b:"Ore pouch 6. Right-click filled to take the stored ore back, or right-click empty to store the ore you are holding."}
execute as @e[type=interaction,tag=ec.orebag_s5,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=ec.orebag_s6,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Seventh Pouch",b:"Ore pouch 7. Right-click filled to take the stored ore back, or right-click empty to store the ore you are holding."}
execute as @e[type=interaction,tag=ec.orebag_s6,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=ec.orebag_s7,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Eighth Pouch",b:"Ore pouch 8. Right-click filled to take the stored ore back, or right-click empty to store the ore you are holding."}
execute as @e[type=interaction,tag=ec.orebag_s7,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=ec.orebag_s8,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Ninth Pouch",b:"Ore pouch 9. Right-click filled to take the stored ore back, or right-click empty to store the ore you are holding."}
execute as @e[type=interaction,tag=ec.orebag_s8,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack run data remove entity @s attack
