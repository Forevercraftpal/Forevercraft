# Ore Bag Menu — Tick (runs every 2t for players with menu open)
# Called from menu_tick, run as each player with ec.orebag_in_menu tag

# Close if player walked too far from menu entities
execute unless entity @e[type=item_display,tag=ec.orebag_bg,distance=..5] run function evercraft:ore_bag/menu/close
execute unless entity @s[tag=ec.orebag_in_menu] run return 0

# Close if ore bag no longer anywhere on player (inventory, hotbar, or bundle)
execute unless items entity @s inventory.* *[custom_data~{ore_bag:true}] unless items entity @s hotbar.* *[custom_data~{ore_bag:true}] unless data entity @s Inventory[{components:{"minecraft:bundle_contents":[{components:{"minecraft:custom_data":{ore_bag:1b}}}]}}] run function evercraft:ore_bag/menu/close
execute unless entity @s[tag=ec.orebag_in_menu] run return 0

# Unified UI-click FX (Joseph 2026-06-05): play the gated cue ONCE if any ec.orebag_el element registered
# a click this tick, before check_clicks consumes it.
execute if entity @e[type=interaction,tag=ec.orebag_el,distance=..6,nbt={interaction:{}},limit=1] run function evercraft:fx/ui/click

# Check for clicks
function evercraft:ore_bag/menu/check_clicks
