# Ore Bag Menu — Handle Click (macro)
# Args from storage: pid, slot (s0-s26)
# Checks if slot is occupied, dispatches to retrieve or store

# Snapshot whether slot has an item BEFORE either branch mutates it
$execute store success score #satch_op ec.temp if data storage evercraft:ore_bag bags.$(pid).$(slot).item
execute if score #satch_op ec.temp matches 1 run function evercraft:ore_bag/menu/retrieve with storage evercraft:ore_bag temp
execute if score #satch_op ec.temp matches 0 run function evercraft:ore_bag/menu/try_store with storage evercraft:ore_bag temp

# Refresh display
function evercraft:ore_bag/menu/refresh
