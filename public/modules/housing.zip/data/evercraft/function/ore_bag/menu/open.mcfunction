# Ore Bag Menu — Open
# Run as the player at their position

# Safety: kill any orphaned menu elements from a previous session
# Menu Core: Y-displacement close anchor
# One-menu-at-a-time (2026-06-15): close any other open menu before this one claims
# ec.menu_active. Two overlapping menus share the @s adv.gui_session slot; the newer
# open orphans the older menu's session, so it can never consume its click -> stuck
# interaction NBT -> click-sound spam. force_close is idempotent (no-op when nothing open).
execute if entity @s[tag=ec.menu_active] run function evercraft:menu_core/force_close
tag @s add ec.menu_active
execute store result score @s ec.menu_open_y run data get entity @s Pos[1] 100
# Sneak-position polish (MP-P3.5): when crouching, lower spawn anchor by 0.20m so
# menu sits at a comfortable view-angle for the lowered eye height. Tag is read by
# every summon line below (paired unless/if) and removed at end-of-file.
tag @s remove ec.menu_sneak_open
execute if predicate evercraft:player_crouching run tag @s add ec.menu_sneak_open


execute at @s run kill @e[type=text_display,tag=ec.orebag_el,distance=..5]
execute at @s run kill @e[type=interaction,tag=ec.orebag_el,distance=..5]
execute at @s run kill @e[type=item_display,tag=ec.orebag_el,distance=..5]

# Tag player as in menu, set page to 0
tag @s add ec.orebag_in_menu
scoreboard players set @s ec.orebag_page 0

# Copy ore_bag_id to temp for macro access
execute store result storage evercraft:ore_bag temp.pid int 1 run scoreboard players get @s ec.obid

# Spawn background panel
execute unless entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^ ^2 ^1.8 run summon item_display ~ ~ ~ { Tags:["ec.orebag_el","ec.orebag_bg"], billboard:"center", item:{id:"gray_stained_glass_pane",count:1}, item_display:"fixed", transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,-0.02f],scale:[3.0f,3.4f,0.01f]} }
execute if entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^ ^1.8 ^1.8 run summon item_display ~ ~ ~ { Tags:["ec.orebag_el","ec.orebag_bg"], billboard:"center", item:{id:"gray_stained_glass_pane",count:1}, item_display:"fixed", transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,-0.02f],scale:[3.0f,3.4f,0.01f]} }

# Spawn title
# Ownership-header label (MP-P3.6): foreign viewers see whose menu this is
# 26.1: {selector:} renders blank in text_display — bake @s's name to a $(owner) literal.
function evercraft:util/gui/owner_name
execute at @s rotated ~ 0 positioned ^ ^3.08 ^1.78 run function evercraft:ore_bag/menu/open_nm with storage evercraft:scorebake args
execute unless entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^ ^2.9 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f, Tags:["ec.orebag_el","ec.orebag_title"], billboard:"center", text:[{text:"\u2692 ",color:"dark_gray"},{text:"Ore Bag",color:"#C0C0C0",bold:true},{text:" \u2692",color:"dark_gray"}], background:1, shadow:1b, transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.54f,0.54f,0.54f]} }
execute if entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^ ^2.7 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f, Tags:["ec.orebag_el","ec.orebag_title"], billboard:"center", text:[{text:"\u2692 ",color:"dark_gray"},{text:"Ore Bag",color:"#C0C0C0",bold:true},{text:" \u2692",color:"dark_gray"}], background:1, shadow:1b, transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.54f,0.54f,0.54f]} }

# Spawn instruction text
execute unless entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^ ^1.1 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f, Tags:["ec.orebag_el","ec.orebag_hint"], billboard:"center", text:[{text:"Hold forge material + click slot to store",color:"gray",italic:true}], background:0, shadow:1b, transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.338f,0.338f,0.338f]} }
execute if entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^ ^0.9 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f, Tags:["ec.orebag_el","ec.orebag_hint"], billboard:"center", text:[{text:"Hold forge material + click slot to store",color:"gray",italic:true}], background:0, shadow:1b, transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.338f,0.338f,0.338f]} }

# Spawn [Close] button
execute unless entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^ ^0.95 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f, Tags:["ec.orebag_el","ec.orebag_close_txt"], billboard:"center", text:[{text:"[ ",color:"dark_gray"},{text:"Close",color:"gray",bold:true},{text:" ]",color:"dark_gray"}], background:1, shadow:1b, transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.405f,0.405f,0.405f]} }
execute if entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^ ^0.75 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f, Tags:["ec.orebag_el","ec.orebag_close_txt"], billboard:"center", text:[{text:"[ ",color:"dark_gray"},{text:"Close",color:"gray",bold:true},{text:" ]",color:"dark_gray"}], background:1, shadow:1b, transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.405f,0.405f,0.405f]} }
# [strip] ec.orebag_el: 0.5w split into 5 x 0.12 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute unless entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^-0.19 ^0.85 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.orebag_el","ec.orebag_close_btn"], width:0.12f,height:0.12f, response:1b }
execute unless entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^-0.095 ^0.85 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.orebag_el","ec.orebag_close_btn"], width:0.12f,height:0.12f, response:1b }
execute unless entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^0 ^0.85 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.orebag_el","ec.orebag_close_btn"], width:0.12f,height:0.12f, response:1b }
execute unless entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^0.095 ^0.85 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.orebag_el","ec.orebag_close_btn"], width:0.12f,height:0.12f, response:1b }
execute unless entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^0.19 ^0.85 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.orebag_el","ec.orebag_close_btn"], width:0.12f,height:0.12f, response:1b }
# [strip] ec.orebag_el: 0.5w split into 5 x 0.12 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute if entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^-0.19 ^0.65 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.orebag_el","ec.orebag_close_btn"], width:0.12f,height:0.12f, response:1b }
execute if entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^-0.095 ^0.65 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.orebag_el","ec.orebag_close_btn"], width:0.12f,height:0.12f, response:1b }
execute if entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^0 ^0.65 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.orebag_el","ec.orebag_close_btn"], width:0.12f,height:0.12f, response:1b }
execute if entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^0.095 ^0.65 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.orebag_el","ec.orebag_close_btn"], width:0.12f,height:0.12f, response:1b }
execute if entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^0.19 ^0.65 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.orebag_el","ec.orebag_close_btn"], width:0.12f,height:0.12f, response:1b }

# (2026-06-10 GUI pass: prev/next x-signs were REVERSED — [<] rendered screen-right.
#  ^+x = screen LEFT; prev now +0.25, next -0.25.)
# Spawn navigation buttons — [<] Page X/3 [>]
execute unless entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^ ^1.25 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f, Tags:["ec.orebag_el","ec.orebag_page_txt"], billboard:"center", text:[{text:"Page 1/3",color:"white"}], background:0, shadow:1b, transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.338f,0.338f,0.338f]} }
execute if entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^ ^1.05 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f, Tags:["ec.orebag_el","ec.orebag_page_txt"], billboard:"center", text:[{text:"Page 1/3",color:"white"}], background:0, shadow:1b, transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.338f,0.338f,0.338f]} }

# [<] prev button
execute unless entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^0.25 ^1.13 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f, Tags:["ec.orebag_el","ec.orebag_prev_txt"], billboard:"center", text:[{text:"[<]",color:"#C0C0C0",bold:true}], background:1, shadow:1b, transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.405f,0.405f,0.405f]} }
execute if entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^0.25 ^0.93 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f, Tags:["ec.orebag_el","ec.orebag_prev_txt"], billboard:"center", text:[{text:"[<]",color:"#C0C0C0",bold:true}], background:1, shadow:1b, transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.405f,0.405f,0.405f]} }
execute unless entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^0.25 ^1.03 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.orebag_el","ec.orebag_prev_btn"], width:0.3f, height:0.12f, response:1b }
execute if entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^0.25 ^0.83 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.orebag_el","ec.orebag_prev_btn"], width:0.3f, height:0.12f, response:1b }

# [>] next button
execute unless entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^-0.25 ^1.13 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f, Tags:["ec.orebag_el","ec.orebag_next_txt"], billboard:"center", text:[{text:"[>]",color:"#C0C0C0",bold:true}], background:1, shadow:1b, transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.405f,0.405f,0.405f]} }
execute if entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^-0.25 ^0.93 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f, Tags:["ec.orebag_el","ec.orebag_next_txt"], billboard:"center", text:[{text:"[>]",color:"#C0C0C0",bold:true}], background:1, shadow:1b, transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.405f,0.405f,0.405f]} }
execute unless entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^-0.25 ^1.03 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.orebag_el","ec.orebag_next_btn"], width:0.3f, height:0.12f, response:1b }
execute if entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^-0.25 ^0.83 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.orebag_el","ec.orebag_next_btn"], width:0.3f, height:0.12f, response:1b }

# Spawn 9 slot displays + interactions
# Slot 0 — Y ^2.85
execute unless entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^ ^2.7 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f, Tags:["ec.orebag_el","ec.orebag_slot_txt","ec.orebag_s0_txt"], billboard:"center", text:[{text:"1. ",color:"gray"},{text:"[Empty]",color:"dark_gray"}], background:0, shadow:1b, transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.405f,0.405f,0.405f]} }
execute if entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^ ^2.5 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f, Tags:["ec.orebag_el","ec.orebag_slot_txt","ec.orebag_s0_txt"], billboard:"center", text:[{text:"1. ",color:"gray"},{text:"[Empty]",color:"dark_gray"}], background:0, shadow:1b, transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.405f,0.405f,0.405f]} }
# [strip] ec.orebag_el: 0.8w split into 5 x 0.17 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute unless entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^-0.315 ^2.615 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.orebag_el","ec.orebag_slot","ec.orebag_s0"], width:0.17f,height:0.17f, response:1b }
execute unless entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^-0.1575 ^2.615 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.orebag_el","ec.orebag_slot","ec.orebag_s0"], width:0.17f,height:0.17f, response:1b }
execute unless entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^0 ^2.615 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.orebag_el","ec.orebag_slot","ec.orebag_s0"], width:0.17f,height:0.17f, response:1b }
execute unless entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^0.1575 ^2.615 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.orebag_el","ec.orebag_slot","ec.orebag_s0"], width:0.17f,height:0.17f, response:1b }
execute unless entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^0.315 ^2.615 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.orebag_el","ec.orebag_slot","ec.orebag_s0"], width:0.17f,height:0.17f, response:1b }
# [strip] ec.orebag_el: 0.8w split into 5 x 0.17 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute if entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^-0.315 ^2.415 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.orebag_el","ec.orebag_slot","ec.orebag_s0"], width:0.17f,height:0.17f, response:1b }
execute if entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^-0.1575 ^2.415 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.orebag_el","ec.orebag_slot","ec.orebag_s0"], width:0.17f,height:0.17f, response:1b }
execute if entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^0 ^2.415 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.orebag_el","ec.orebag_slot","ec.orebag_s0"], width:0.17f,height:0.17f, response:1b }
execute if entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^0.1575 ^2.415 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.orebag_el","ec.orebag_slot","ec.orebag_s0"], width:0.17f,height:0.17f, response:1b }
execute if entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^0.315 ^2.415 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.orebag_el","ec.orebag_slot","ec.orebag_s0"], width:0.17f,height:0.17f, response:1b }

# Slot 1 — Y ^2.68
execute unless entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^ ^2.53 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f, Tags:["ec.orebag_el","ec.orebag_slot_txt","ec.orebag_s1_txt"], billboard:"center", text:[{text:"2. ",color:"gray"},{text:"[Empty]",color:"dark_gray"}], background:0, shadow:1b, transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.405f,0.405f,0.405f]} }
execute if entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^ ^2.33 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f, Tags:["ec.orebag_el","ec.orebag_slot_txt","ec.orebag_s1_txt"], billboard:"center", text:[{text:"2. ",color:"gray"},{text:"[Empty]",color:"dark_gray"}], background:0, shadow:1b, transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.405f,0.405f,0.405f]} }
# [strip] ec.orebag_el: 0.8w split into 5 x 0.17 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute unless entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^-0.315 ^2.445 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.orebag_el","ec.orebag_slot","ec.orebag_s1"], width:0.17f,height:0.17f, response:1b }
execute unless entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^-0.1575 ^2.445 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.orebag_el","ec.orebag_slot","ec.orebag_s1"], width:0.17f,height:0.17f, response:1b }
execute unless entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^0 ^2.445 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.orebag_el","ec.orebag_slot","ec.orebag_s1"], width:0.17f,height:0.17f, response:1b }
execute unless entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^0.1575 ^2.445 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.orebag_el","ec.orebag_slot","ec.orebag_s1"], width:0.17f,height:0.17f, response:1b }
execute unless entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^0.315 ^2.445 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.orebag_el","ec.orebag_slot","ec.orebag_s1"], width:0.17f,height:0.17f, response:1b }
# [strip] ec.orebag_el: 0.8w split into 5 x 0.17 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute if entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^-0.315 ^2.245 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.orebag_el","ec.orebag_slot","ec.orebag_s1"], width:0.17f,height:0.17f, response:1b }
execute if entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^-0.1575 ^2.245 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.orebag_el","ec.orebag_slot","ec.orebag_s1"], width:0.17f,height:0.17f, response:1b }
execute if entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^0 ^2.245 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.orebag_el","ec.orebag_slot","ec.orebag_s1"], width:0.17f,height:0.17f, response:1b }
execute if entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^0.1575 ^2.245 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.orebag_el","ec.orebag_slot","ec.orebag_s1"], width:0.17f,height:0.17f, response:1b }
execute if entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^0.315 ^2.245 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.orebag_el","ec.orebag_slot","ec.orebag_s1"], width:0.17f,height:0.17f, response:1b }

# Slot 2 — Y ^2.51
execute unless entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^ ^2.36 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f, Tags:["ec.orebag_el","ec.orebag_slot_txt","ec.orebag_s2_txt"], billboard:"center", text:[{text:"3. ",color:"gray"},{text:"[Empty]",color:"dark_gray"}], background:0, shadow:1b, transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.405f,0.405f,0.405f]} }
execute if entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^ ^2.16 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f, Tags:["ec.orebag_el","ec.orebag_slot_txt","ec.orebag_s2_txt"], billboard:"center", text:[{text:"3. ",color:"gray"},{text:"[Empty]",color:"dark_gray"}], background:0, shadow:1b, transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.405f,0.405f,0.405f]} }
# [strip] ec.orebag_el: 0.8w split into 5 x 0.17 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute unless entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^-0.315 ^2.275 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.orebag_el","ec.orebag_slot","ec.orebag_s2"], width:0.17f,height:0.17f, response:1b }
execute unless entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^-0.1575 ^2.275 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.orebag_el","ec.orebag_slot","ec.orebag_s2"], width:0.17f,height:0.17f, response:1b }
execute unless entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^0 ^2.275 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.orebag_el","ec.orebag_slot","ec.orebag_s2"], width:0.17f,height:0.17f, response:1b }
execute unless entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^0.1575 ^2.275 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.orebag_el","ec.orebag_slot","ec.orebag_s2"], width:0.17f,height:0.17f, response:1b }
execute unless entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^0.315 ^2.275 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.orebag_el","ec.orebag_slot","ec.orebag_s2"], width:0.17f,height:0.17f, response:1b }
# [strip] ec.orebag_el: 0.8w split into 5 x 0.17 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute if entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^-0.315 ^2.075 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.orebag_el","ec.orebag_slot","ec.orebag_s2"], width:0.17f,height:0.17f, response:1b }
execute if entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^-0.1575 ^2.075 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.orebag_el","ec.orebag_slot","ec.orebag_s2"], width:0.17f,height:0.17f, response:1b }
execute if entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^0 ^2.075 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.orebag_el","ec.orebag_slot","ec.orebag_s2"], width:0.17f,height:0.17f, response:1b }
execute if entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^0.1575 ^2.075 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.orebag_el","ec.orebag_slot","ec.orebag_s2"], width:0.17f,height:0.17f, response:1b }
execute if entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^0.315 ^2.075 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.orebag_el","ec.orebag_slot","ec.orebag_s2"], width:0.17f,height:0.17f, response:1b }

# Slot 3 — Y ^2.34
execute unless entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^ ^2.19 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f, Tags:["ec.orebag_el","ec.orebag_slot_txt","ec.orebag_s3_txt"], billboard:"center", text:[{text:"4. ",color:"gray"},{text:"[Empty]",color:"dark_gray"}], background:0, shadow:1b, transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.405f,0.405f,0.405f]} }
execute if entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^ ^1.99 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f, Tags:["ec.orebag_el","ec.orebag_slot_txt","ec.orebag_s3_txt"], billboard:"center", text:[{text:"4. ",color:"gray"},{text:"[Empty]",color:"dark_gray"}], background:0, shadow:1b, transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.405f,0.405f,0.405f]} }
# [strip] ec.orebag_el: 0.8w split into 5 x 0.17 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute unless entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^-0.315 ^2.105 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.orebag_el","ec.orebag_slot","ec.orebag_s3"], width:0.17f,height:0.17f, response:1b }
execute unless entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^-0.1575 ^2.105 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.orebag_el","ec.orebag_slot","ec.orebag_s3"], width:0.17f,height:0.17f, response:1b }
execute unless entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^0 ^2.105 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.orebag_el","ec.orebag_slot","ec.orebag_s3"], width:0.17f,height:0.17f, response:1b }
execute unless entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^0.1575 ^2.105 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.orebag_el","ec.orebag_slot","ec.orebag_s3"], width:0.17f,height:0.17f, response:1b }
execute unless entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^0.315 ^2.105 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.orebag_el","ec.orebag_slot","ec.orebag_s3"], width:0.17f,height:0.17f, response:1b }
# [strip] ec.orebag_el: 0.8w split into 5 x 0.17 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute if entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^-0.315 ^1.905 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.orebag_el","ec.orebag_slot","ec.orebag_s3"], width:0.17f,height:0.17f, response:1b }
execute if entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^-0.1575 ^1.905 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.orebag_el","ec.orebag_slot","ec.orebag_s3"], width:0.17f,height:0.17f, response:1b }
execute if entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^0 ^1.905 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.orebag_el","ec.orebag_slot","ec.orebag_s3"], width:0.17f,height:0.17f, response:1b }
execute if entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^0.1575 ^1.905 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.orebag_el","ec.orebag_slot","ec.orebag_s3"], width:0.17f,height:0.17f, response:1b }
execute if entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^0.315 ^1.905 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.orebag_el","ec.orebag_slot","ec.orebag_s3"], width:0.17f,height:0.17f, response:1b }

# Slot 4 — Y ^2.17
execute unless entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^ ^2.02 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f, Tags:["ec.orebag_el","ec.orebag_slot_txt","ec.orebag_s4_txt"], billboard:"center", text:[{text:"5. ",color:"gray"},{text:"[Empty]",color:"dark_gray"}], background:0, shadow:1b, transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.405f,0.405f,0.405f]} }
execute if entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^ ^1.82 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f, Tags:["ec.orebag_el","ec.orebag_slot_txt","ec.orebag_s4_txt"], billboard:"center", text:[{text:"5. ",color:"gray"},{text:"[Empty]",color:"dark_gray"}], background:0, shadow:1b, transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.405f,0.405f,0.405f]} }
# [strip] ec.orebag_el: 0.8w split into 5 x 0.17 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute unless entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^-0.315 ^1.935 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.orebag_el","ec.orebag_slot","ec.orebag_s4"], width:0.17f,height:0.17f, response:1b }
execute unless entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^-0.1575 ^1.935 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.orebag_el","ec.orebag_slot","ec.orebag_s4"], width:0.17f,height:0.17f, response:1b }
execute unless entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^0 ^1.935 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.orebag_el","ec.orebag_slot","ec.orebag_s4"], width:0.17f,height:0.17f, response:1b }
execute unless entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^0.1575 ^1.935 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.orebag_el","ec.orebag_slot","ec.orebag_s4"], width:0.17f,height:0.17f, response:1b }
execute unless entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^0.315 ^1.935 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.orebag_el","ec.orebag_slot","ec.orebag_s4"], width:0.17f,height:0.17f, response:1b }
# [strip] ec.orebag_el: 0.8w split into 5 x 0.17 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute if entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^-0.315 ^1.735 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.orebag_el","ec.orebag_slot","ec.orebag_s4"], width:0.17f,height:0.17f, response:1b }
execute if entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^-0.1575 ^1.735 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.orebag_el","ec.orebag_slot","ec.orebag_s4"], width:0.17f,height:0.17f, response:1b }
execute if entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^0 ^1.735 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.orebag_el","ec.orebag_slot","ec.orebag_s4"], width:0.17f,height:0.17f, response:1b }
execute if entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^0.1575 ^1.735 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.orebag_el","ec.orebag_slot","ec.orebag_s4"], width:0.17f,height:0.17f, response:1b }
execute if entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^0.315 ^1.735 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.orebag_el","ec.orebag_slot","ec.orebag_s4"], width:0.17f,height:0.17f, response:1b }

# Slot 5 — Y ^2.00
execute unless entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^ ^1.85 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f, Tags:["ec.orebag_el","ec.orebag_slot_txt","ec.orebag_s5_txt"], billboard:"center", text:[{text:"6. ",color:"gray"},{text:"[Empty]",color:"dark_gray"}], background:0, shadow:1b, transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.405f,0.405f,0.405f]} }
execute if entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^ ^1.65 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f, Tags:["ec.orebag_el","ec.orebag_slot_txt","ec.orebag_s5_txt"], billboard:"center", text:[{text:"6. ",color:"gray"},{text:"[Empty]",color:"dark_gray"}], background:0, shadow:1b, transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.405f,0.405f,0.405f]} }
# [strip] ec.orebag_el: 0.8w split into 5 x 0.17 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute unless entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^-0.315 ^1.765 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.orebag_el","ec.orebag_slot","ec.orebag_s5"], width:0.17f,height:0.17f, response:1b }
execute unless entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^-0.1575 ^1.765 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.orebag_el","ec.orebag_slot","ec.orebag_s5"], width:0.17f,height:0.17f, response:1b }
execute unless entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^0 ^1.765 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.orebag_el","ec.orebag_slot","ec.orebag_s5"], width:0.17f,height:0.17f, response:1b }
execute unless entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^0.1575 ^1.765 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.orebag_el","ec.orebag_slot","ec.orebag_s5"], width:0.17f,height:0.17f, response:1b }
execute unless entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^0.315 ^1.765 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.orebag_el","ec.orebag_slot","ec.orebag_s5"], width:0.17f,height:0.17f, response:1b }
# [strip] ec.orebag_el: 0.8w split into 5 x 0.17 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute if entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^-0.315 ^1.565 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.orebag_el","ec.orebag_slot","ec.orebag_s5"], width:0.17f,height:0.17f, response:1b }
execute if entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^-0.1575 ^1.565 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.orebag_el","ec.orebag_slot","ec.orebag_s5"], width:0.17f,height:0.17f, response:1b }
execute if entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^0 ^1.565 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.orebag_el","ec.orebag_slot","ec.orebag_s5"], width:0.17f,height:0.17f, response:1b }
execute if entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^0.1575 ^1.565 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.orebag_el","ec.orebag_slot","ec.orebag_s5"], width:0.17f,height:0.17f, response:1b }
execute if entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^0.315 ^1.565 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.orebag_el","ec.orebag_slot","ec.orebag_s5"], width:0.17f,height:0.17f, response:1b }

# Slot 6 — Y ^1.83
execute unless entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^ ^1.68 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f, Tags:["ec.orebag_el","ec.orebag_slot_txt","ec.orebag_s6_txt"], billboard:"center", text:[{text:"7. ",color:"gray"},{text:"[Empty]",color:"dark_gray"}], background:0, shadow:1b, transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.405f,0.405f,0.405f]} }
execute if entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^ ^1.48 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f, Tags:["ec.orebag_el","ec.orebag_slot_txt","ec.orebag_s6_txt"], billboard:"center", text:[{text:"7. ",color:"gray"},{text:"[Empty]",color:"dark_gray"}], background:0, shadow:1b, transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.405f,0.405f,0.405f]} }
# [strip] ec.orebag_el: 0.8w split into 5 x 0.17 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute unless entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^-0.315 ^1.595 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.orebag_el","ec.orebag_slot","ec.orebag_s6"], width:0.17f,height:0.17f, response:1b }
execute unless entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^-0.1575 ^1.595 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.orebag_el","ec.orebag_slot","ec.orebag_s6"], width:0.17f,height:0.17f, response:1b }
execute unless entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^0 ^1.595 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.orebag_el","ec.orebag_slot","ec.orebag_s6"], width:0.17f,height:0.17f, response:1b }
execute unless entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^0.1575 ^1.595 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.orebag_el","ec.orebag_slot","ec.orebag_s6"], width:0.17f,height:0.17f, response:1b }
execute unless entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^0.315 ^1.595 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.orebag_el","ec.orebag_slot","ec.orebag_s6"], width:0.17f,height:0.17f, response:1b }
# [strip] ec.orebag_el: 0.8w split into 5 x 0.17 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute if entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^-0.315 ^1.395 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.orebag_el","ec.orebag_slot","ec.orebag_s6"], width:0.17f,height:0.17f, response:1b }
execute if entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^-0.1575 ^1.395 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.orebag_el","ec.orebag_slot","ec.orebag_s6"], width:0.17f,height:0.17f, response:1b }
execute if entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^0 ^1.395 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.orebag_el","ec.orebag_slot","ec.orebag_s6"], width:0.17f,height:0.17f, response:1b }
execute if entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^0.1575 ^1.395 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.orebag_el","ec.orebag_slot","ec.orebag_s6"], width:0.17f,height:0.17f, response:1b }
execute if entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^0.315 ^1.395 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.orebag_el","ec.orebag_slot","ec.orebag_s6"], width:0.17f,height:0.17f, response:1b }

# Slot 7 — Y ^1.66
execute unless entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^ ^1.51 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f, Tags:["ec.orebag_el","ec.orebag_slot_txt","ec.orebag_s7_txt"], billboard:"center", text:[{text:"8. ",color:"gray"},{text:"[Empty]",color:"dark_gray"}], background:0, shadow:1b, transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.405f,0.405f,0.405f]} }
execute if entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^ ^1.31 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f, Tags:["ec.orebag_el","ec.orebag_slot_txt","ec.orebag_s7_txt"], billboard:"center", text:[{text:"8. ",color:"gray"},{text:"[Empty]",color:"dark_gray"}], background:0, shadow:1b, transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.405f,0.405f,0.405f]} }
# [strip] ec.orebag_el: 0.8w split into 5 x 0.17 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute unless entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^-0.315 ^1.425 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.orebag_el","ec.orebag_slot","ec.orebag_s7"], width:0.17f,height:0.17f, response:1b }
execute unless entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^-0.1575 ^1.425 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.orebag_el","ec.orebag_slot","ec.orebag_s7"], width:0.17f,height:0.17f, response:1b }
execute unless entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^0 ^1.425 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.orebag_el","ec.orebag_slot","ec.orebag_s7"], width:0.17f,height:0.17f, response:1b }
execute unless entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^0.1575 ^1.425 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.orebag_el","ec.orebag_slot","ec.orebag_s7"], width:0.17f,height:0.17f, response:1b }
execute unless entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^0.315 ^1.425 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.orebag_el","ec.orebag_slot","ec.orebag_s7"], width:0.17f,height:0.17f, response:1b }
# [strip] ec.orebag_el: 0.8w split into 5 x 0.17 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute if entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^-0.315 ^1.225 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.orebag_el","ec.orebag_slot","ec.orebag_s7"], width:0.17f,height:0.17f, response:1b }
execute if entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^-0.1575 ^1.225 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.orebag_el","ec.orebag_slot","ec.orebag_s7"], width:0.17f,height:0.17f, response:1b }
execute if entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^0 ^1.225 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.orebag_el","ec.orebag_slot","ec.orebag_s7"], width:0.17f,height:0.17f, response:1b }
execute if entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^0.1575 ^1.225 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.orebag_el","ec.orebag_slot","ec.orebag_s7"], width:0.17f,height:0.17f, response:1b }
execute if entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^0.315 ^1.225 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.orebag_el","ec.orebag_slot","ec.orebag_s7"], width:0.17f,height:0.17f, response:1b }

# Slot 8 — Y ^1.49
execute unless entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^ ^1.34 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f, Tags:["ec.orebag_el","ec.orebag_slot_txt","ec.orebag_s8_txt"], billboard:"center", text:[{text:"9. ",color:"gray"},{text:"[Empty]",color:"dark_gray"}], background:0, shadow:1b, transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.405f,0.405f,0.405f]} }
execute if entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^ ^1.14 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f, Tags:["ec.orebag_el","ec.orebag_slot_txt","ec.orebag_s8_txt"], billboard:"center", text:[{text:"9. ",color:"gray"},{text:"[Empty]",color:"dark_gray"}], background:0, shadow:1b, transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.405f,0.405f,0.405f]} }
# [strip] ec.orebag_el: 0.8w split into 6 x 0.15 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute unless entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^-0.325 ^1.175 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.orebag_el","ec.orebag_slot","ec.orebag_s8"], width:0.15f,height:0.15f, response:1b }
execute unless entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^-0.195 ^1.175 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.orebag_el","ec.orebag_slot","ec.orebag_s8"], width:0.15f,height:0.15f, response:1b }
execute unless entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^-0.065 ^1.175 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.orebag_el","ec.orebag_slot","ec.orebag_s8"], width:0.15f,height:0.15f, response:1b }
execute unless entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^0.065 ^1.175 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.orebag_el","ec.orebag_slot","ec.orebag_s8"], width:0.15f,height:0.15f, response:1b }
execute unless entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^0.195 ^1.175 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.orebag_el","ec.orebag_slot","ec.orebag_s8"], width:0.15f,height:0.15f, response:1b }
execute unless entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^0.325 ^1.175 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.orebag_el","ec.orebag_slot","ec.orebag_s8"], width:0.15f,height:0.15f, response:1b }
# [strip] ec.orebag_el: 0.8w split into 6 x 0.15 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute if entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^-0.325 ^0.975 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.orebag_el","ec.orebag_slot","ec.orebag_s8"], width:0.15f,height:0.15f, response:1b }
execute if entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^-0.195 ^0.975 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.orebag_el","ec.orebag_slot","ec.orebag_s8"], width:0.15f,height:0.15f, response:1b }
execute if entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^-0.065 ^0.975 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.orebag_el","ec.orebag_slot","ec.orebag_s8"], width:0.15f,height:0.15f, response:1b }
execute if entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^0.065 ^0.975 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.orebag_el","ec.orebag_slot","ec.orebag_s8"], width:0.15f,height:0.15f, response:1b }
execute if entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^0.195 ^0.975 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.orebag_el","ec.orebag_slot","ec.orebag_s8"], width:0.15f,height:0.15f, response:1b }
execute if entity @s[tag=ec.menu_sneak_open] at @s rotated ~ 0 positioned ^0.325 ^0.975 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.orebag_el","ec.orebag_slot","ec.orebag_s8"], width:0.15f,height:0.15f, response:1b }

# Refresh slot displays with actual contents from storage
function evercraft:ore_bag/menu/refresh

# Start menu tick
schedule function evercraft:ore_bag/menu_tick 2t replace

# Sound

# Session isolation
scoreboard players add #gui_session ec.var 1
scoreboard players operation @s adv.gui_session = #gui_session ec.var
scoreboard players operation #gui_stamp ec.temp = @s adv.gui_session
execute as @e[type=text_display,tag=ec.orebag_el,distance=..5] unless score @s adv.gui_session matches 1.. run scoreboard players operation @s adv.gui_session = #gui_stamp ec.temp
execute as @e[type=item_display,tag=ec.orebag_el,distance=..5] unless score @s adv.gui_session matches 1.. run scoreboard players operation @s adv.gui_session = #gui_stamp ec.temp
execute as @e[type=interaction,tag=ec.orebag_el,distance=..5] unless score @s adv.gui_session matches 1.. run scoreboard players operation @s adv.gui_session = #gui_stamp ec.temp

execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.barrel.open master @s ~ ~ ~ 0.5 1.2

# Sneak-position polish cleanup
tag @s remove ec.menu_sneak_open
