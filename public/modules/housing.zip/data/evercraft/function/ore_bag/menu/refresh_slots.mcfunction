# Ore Bag Menu — Refresh Slots (macro)
# Args from temp.rargs: pid, s0-s8 (slot names for this page)
# Updates each of the 9 slot text_displays with stored item name or [Empty]

# Slot 0
$execute if data storage evercraft:ore_bag bags.$(pid).$(s0).item run data modify storage evercraft:ore_bag temp._r0 set value [{text:"",color:"#C0C0C0",extra:[{storage:"evercraft:ore_bag",nbt:"bags.$(pid).$(s0).name",interpret:true}]},{text:" \u00d7",color:"dark_gray"},{storage:"evercraft:ore_bag",nbt:"bags.$(pid).$(s0).qty",color:"white"},{text:" \u2692",color:"#C0C0C0"}]
$execute if data storage evercraft:ore_bag bags.$(pid).$(s0).item at @s as @e[type=text_display,tag=ec.orebag_s0_txt,distance=..5] run data modify entity @s text set from storage evercraft:ore_bag temp._r0
$execute unless data storage evercraft:ore_bag bags.$(pid).$(s0).item at @s as @e[type=text_display,tag=ec.orebag_s0_txt,distance=..5] run data modify entity @s text set value [{text:"[Empty]",color:"dark_gray"}]

# Slot 1
$execute if data storage evercraft:ore_bag bags.$(pid).$(s1).item run data modify storage evercraft:ore_bag temp._r1 set value [{text:"",color:"#C0C0C0",extra:[{storage:"evercraft:ore_bag",nbt:"bags.$(pid).$(s1).name",interpret:true}]},{text:" \u00d7",color:"dark_gray"},{storage:"evercraft:ore_bag",nbt:"bags.$(pid).$(s1).qty",color:"white"},{text:" \u2692",color:"#C0C0C0"}]
$execute if data storage evercraft:ore_bag bags.$(pid).$(s1).item at @s as @e[type=text_display,tag=ec.orebag_s1_txt,distance=..5] run data modify entity @s text set from storage evercraft:ore_bag temp._r1
$execute unless data storage evercraft:ore_bag bags.$(pid).$(s1).item at @s as @e[type=text_display,tag=ec.orebag_s1_txt,distance=..5] run data modify entity @s text set value [{text:"[Empty]",color:"dark_gray"}]

# Slot 2
$execute if data storage evercraft:ore_bag bags.$(pid).$(s2).item run data modify storage evercraft:ore_bag temp._r2 set value [{text:"",color:"#C0C0C0",extra:[{storage:"evercraft:ore_bag",nbt:"bags.$(pid).$(s2).name",interpret:true}]},{text:" \u00d7",color:"dark_gray"},{storage:"evercraft:ore_bag",nbt:"bags.$(pid).$(s2).qty",color:"white"},{text:" \u2692",color:"#C0C0C0"}]
$execute if data storage evercraft:ore_bag bags.$(pid).$(s2).item at @s as @e[type=text_display,tag=ec.orebag_s2_txt,distance=..5] run data modify entity @s text set from storage evercraft:ore_bag temp._r2
$execute unless data storage evercraft:ore_bag bags.$(pid).$(s2).item at @s as @e[type=text_display,tag=ec.orebag_s2_txt,distance=..5] run data modify entity @s text set value [{text:"[Empty]",color:"dark_gray"}]

# Slot 3
$execute if data storage evercraft:ore_bag bags.$(pid).$(s3).item run data modify storage evercraft:ore_bag temp._r3 set value [{text:"",color:"#C0C0C0",extra:[{storage:"evercraft:ore_bag",nbt:"bags.$(pid).$(s3).name",interpret:true}]},{text:" \u00d7",color:"dark_gray"},{storage:"evercraft:ore_bag",nbt:"bags.$(pid).$(s3).qty",color:"white"},{text:" \u2692",color:"#C0C0C0"}]
$execute if data storage evercraft:ore_bag bags.$(pid).$(s3).item at @s as @e[type=text_display,tag=ec.orebag_s3_txt,distance=..5] run data modify entity @s text set from storage evercraft:ore_bag temp._r3
$execute unless data storage evercraft:ore_bag bags.$(pid).$(s3).item at @s as @e[type=text_display,tag=ec.orebag_s3_txt,distance=..5] run data modify entity @s text set value [{text:"[Empty]",color:"dark_gray"}]

# Slot 4
$execute if data storage evercraft:ore_bag bags.$(pid).$(s4).item run data modify storage evercraft:ore_bag temp._r4 set value [{text:"",color:"#C0C0C0",extra:[{storage:"evercraft:ore_bag",nbt:"bags.$(pid).$(s4).name",interpret:true}]},{text:" \u00d7",color:"dark_gray"},{storage:"evercraft:ore_bag",nbt:"bags.$(pid).$(s4).qty",color:"white"},{text:" \u2692",color:"#C0C0C0"}]
$execute if data storage evercraft:ore_bag bags.$(pid).$(s4).item at @s as @e[type=text_display,tag=ec.orebag_s4_txt,distance=..5] run data modify entity @s text set from storage evercraft:ore_bag temp._r4
$execute unless data storage evercraft:ore_bag bags.$(pid).$(s4).item at @s as @e[type=text_display,tag=ec.orebag_s4_txt,distance=..5] run data modify entity @s text set value [{text:"[Empty]",color:"dark_gray"}]

# Slot 5
$execute if data storage evercraft:ore_bag bags.$(pid).$(s5).item run data modify storage evercraft:ore_bag temp._r5 set value [{text:"",color:"#C0C0C0",extra:[{storage:"evercraft:ore_bag",nbt:"bags.$(pid).$(s5).name",interpret:true}]},{text:" \u00d7",color:"dark_gray"},{storage:"evercraft:ore_bag",nbt:"bags.$(pid).$(s5).qty",color:"white"},{text:" \u2692",color:"#C0C0C0"}]
$execute if data storage evercraft:ore_bag bags.$(pid).$(s5).item at @s as @e[type=text_display,tag=ec.orebag_s5_txt,distance=..5] run data modify entity @s text set from storage evercraft:ore_bag temp._r5
$execute unless data storage evercraft:ore_bag bags.$(pid).$(s5).item at @s as @e[type=text_display,tag=ec.orebag_s5_txt,distance=..5] run data modify entity @s text set value [{text:"[Empty]",color:"dark_gray"}]

# Slot 6
$execute if data storage evercraft:ore_bag bags.$(pid).$(s6).item run data modify storage evercraft:ore_bag temp._r6 set value [{text:"",color:"#C0C0C0",extra:[{storage:"evercraft:ore_bag",nbt:"bags.$(pid).$(s6).name",interpret:true}]},{text:" \u00d7",color:"dark_gray"},{storage:"evercraft:ore_bag",nbt:"bags.$(pid).$(s6).qty",color:"white"},{text:" \u2692",color:"#C0C0C0"}]
$execute if data storage evercraft:ore_bag bags.$(pid).$(s6).item at @s as @e[type=text_display,tag=ec.orebag_s6_txt,distance=..5] run data modify entity @s text set from storage evercraft:ore_bag temp._r6
$execute unless data storage evercraft:ore_bag bags.$(pid).$(s6).item at @s as @e[type=text_display,tag=ec.orebag_s6_txt,distance=..5] run data modify entity @s text set value [{text:"[Empty]",color:"dark_gray"}]

# Slot 7
$execute if data storage evercraft:ore_bag bags.$(pid).$(s7).item run data modify storage evercraft:ore_bag temp._r7 set value [{text:"",color:"#C0C0C0",extra:[{storage:"evercraft:ore_bag",nbt:"bags.$(pid).$(s7).name",interpret:true}]},{text:" \u00d7",color:"dark_gray"},{storage:"evercraft:ore_bag",nbt:"bags.$(pid).$(s7).qty",color:"white"},{text:" \u2692",color:"#C0C0C0"}]
$execute if data storage evercraft:ore_bag bags.$(pid).$(s7).item at @s as @e[type=text_display,tag=ec.orebag_s7_txt,distance=..5] run data modify entity @s text set from storage evercraft:ore_bag temp._r7
$execute unless data storage evercraft:ore_bag bags.$(pid).$(s7).item at @s as @e[type=text_display,tag=ec.orebag_s7_txt,distance=..5] run data modify entity @s text set value [{text:"[Empty]",color:"dark_gray"}]

# Slot 8
$execute if data storage evercraft:ore_bag bags.$(pid).$(s8).item run data modify storage evercraft:ore_bag temp._r8 set value [{text:"",color:"#C0C0C0",extra:[{storage:"evercraft:ore_bag",nbt:"bags.$(pid).$(s8).name",interpret:true}]},{text:" \u00d7",color:"dark_gray"},{storage:"evercraft:ore_bag",nbt:"bags.$(pid).$(s8).qty",color:"white"},{text:" \u2692",color:"#C0C0C0"}]
$execute if data storage evercraft:ore_bag bags.$(pid).$(s8).item at @s as @e[type=text_display,tag=ec.orebag_s8_txt,distance=..5] run data modify entity @s text set from storage evercraft:ore_bag temp._r8
$execute unless data storage evercraft:ore_bag bags.$(pid).$(s8).item at @s as @e[type=text_display,tag=ec.orebag_s8_txt,distance=..5] run data modify entity @s text set value [{text:"[Empty]",color:"dark_gray"}]
