# Ore Bag — On right-click (consume_item trigger)
# consume_item fires BEFORE the game removes the item.
# Tag for 1-tick delayed restore, then handle menu logic.

advancement revoke @s only evercraft:ore_bag/open

# Tag for delayed restore (next tick restores the ore bag item)
# Detect which hand held the ore bag for correct restore
tag @s remove ec.orebag_mainhand
execute if items entity @s weapon.mainhand *[custom_data~{ore_bag:true}] run tag @s add ec.orebag_mainhand
tag @s add ec.orebag_restore

# If already in menu, toggle close
execute if entity @s[tag=ec.orebag_in_menu] run function evercraft:ore_bag/menu/close
execute if entity @s[tag=ec.orebag_in_menu] run return 0

# Ensure player has an ore bag ID
execute unless score @s ec.orebag_id matches 1.. run function evercraft:ore_bag/assign_id

# Read ore_bag_id from held item (still present this tick, before removal)
execute store result score @s ec.obid run data get entity @s SelectedItem.components."minecraft:custom_data".ore_bag_id

# If ore_bag_id is 0, stamp a new one via hopper minecart intermediary
execute if score @s ec.obid matches 0 run function evercraft:ore_bag/stamp_id

# Clear any unstamped duplicate
clear @s minecraft:leather[custom_data~{ore_bag:true,ore_bag_id:0b}]

# Store ore_bag_id to temp for menu macros
execute store result storage evercraft:ore_bag temp.pid int 1 run scoreboard players get @s ec.obid

# Save item data for restore (preserves stamped ore_bag_id)
data modify storage evercraft:ore_bag temp.restore_item set from entity @s SelectedItem
# Migrate legacy items: drop max_stack_size:1 so the ore bag shares a bundle (weight 1, like the satchels)
data remove storage evercraft:ore_bag temp.restore_item.components."minecraft:max_stack_size"

# Initialize storage if missing
function evercraft:ore_bag/init_if_missing with storage evercraft:ore_bag temp

# Open the menu
function evercraft:ore_bag/menu/open
