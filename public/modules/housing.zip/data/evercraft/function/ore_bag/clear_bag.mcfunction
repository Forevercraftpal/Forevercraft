# Ore Bag — Clear stored bag contents for a given pid (macro)
# Called from strip flow with: function evercraft:ore_bag/clear_bag with storage evercraft:strip temp
# Storage path mirrors init_if_missing.mcfunction (bags.<pid>)
$data remove storage evercraft:ore_bag bags.$(pid)
