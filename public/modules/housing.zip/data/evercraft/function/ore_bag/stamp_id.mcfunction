# Ore Bag — Stamp unique ore_bag_id onto held item
# Run as the player holding the ore bag in mainhand

# 1. Assign new ore bag ID
scoreboard players add #next_orebag_id ec.var 1
scoreboard players operation @s ec.obid = #next_orebag_id ec.var
execute store result storage evercraft:ore_bag temp.new_pid int 1 run scoreboard players get @s ec.obid

# 2. Hopper minecart intermediary to modify the held item
summon hopper_minecart ~ ~ ~ {Tags:["ec.temp_cart"],Enabled:0b}
item replace entity @e[type=hopper_minecart,tag=ec.temp_cart,limit=1,sort=nearest] container.0 from entity @s weapon.mainhand

# 3. Stamp ore_bag_id onto the cart's item via macro
function evercraft:ore_bag/set_orebag_id with storage evercraft:ore_bag temp

# 4. Copy stamped item back to player mainhand
item replace entity @s weapon.mainhand from entity @e[type=hopper_minecart,tag=ec.temp_cart,limit=1,sort=nearest] container.0

# 5. Clear cart inventory then kill
data modify entity @e[type=hopper_minecart,tag=ec.temp_cart,limit=1,sort=nearest] Items set value []
kill @e[type=hopper_minecart,tag=ec.temp_cart]
