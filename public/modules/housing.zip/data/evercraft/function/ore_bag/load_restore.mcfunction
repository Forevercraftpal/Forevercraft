# Ore Bag — Load this player's pending restore item into temp.restore_item (macro).
# WA59-P0-RACE (2026-06-22). Caller (restore_item) must set temp.uuid from entity @s UUID.
$data modify storage evercraft:ore_bag temp.restore_item set from storage evercraft:ore_bag restore."$(uuid)".item
