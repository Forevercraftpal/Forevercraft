# Hero's Satchel — On right-click (using_item trigger)
# DO NOT revoke advancement here — using_item fires every tick while held.
# Revoked in menu/close instead.

# If already in menu, do nothing
execute if entity @s[tag=ec.hsatch_in_menu] run return 0

# Ensure this player is in the satchel apply-loop. The shared ec.satchel_owner tag gates the
# per-tick effect pass (artifacts/accessories/tick → satchel/check_and_apply, which handles BOTH
# satchels), but is only set on /give-style grants — a Hero's Satchel obtained another way (or a
# player whose tag was wiped) would store + display trinkets yet receive no effects. Holding it
# open here proves ownership, so (re)tag idempotently.
tag @s add ec.satchel_owner

# Ensure player has a hero satchel ID (for registry)
execute unless score @s ec.hsatch_id matches 1.. run function evercraft:hero_satchel/assign_id

# Copy player ID to temp
execute store result storage evercraft:hero_satchel temp.id int 1 run scoreboard players get @s ec.hsatch_id

# Read bag_id from held item (0 = unregistered, needs stamping)
execute store result score @s ec.hbag_id run data get entity @s SelectedItem.components."minecraft:custom_data".bag_id

# === Fusion Wave 1 (Family A) — title-variant flags from the held capstone ===
# Read once here (SelectedItem is the satchel being opened); the menu title branches on these
# tags so a Pebble of Creation / Aegis Half / Astral Half shows its own name. The satchel storage
# menu is otherwise unchanged (it still keys on hero_satchel:true). Tags cleared in menu/close.
tag @s remove ec.hsatch_pebble
tag @s remove ec.hsatch_aegis
tag @s remove ec.hsatch_astral
execute if data entity @s SelectedItem.components."minecraft:custom_data"{pebble_of_creation:1b} run tag @s add ec.hsatch_pebble
execute if data entity @s SelectedItem.components."minecraft:custom_data"{aegis_half:1b} run tag @s add ec.hsatch_aegis
execute if data entity @s SelectedItem.components."minecraft:custom_data"{astral_half:1b} run tag @s add ec.hsatch_astral

# If bag_id is 0, stamp a new one via hopper minecart intermediary
execute if score @s ec.hbag_id matches 0 run function evercraft:hero_satchel/stamp_bag_id

# Clear any unstamped duplicate that use-item mechanic may restore after stamp
clear @s minecraft:leather[custom_data~{hero_satchel:true,bag_id:0}]

# Hero's Satchel always has 11 slots
scoreboard players set @s ec.hsatch_slots 11

# Store bag_id to temp for menu macros
execute store result storage evercraft:hero_satchel temp.bid int 1 run scoreboard players get @s ec.hbag_id

# Safety: initialize bag storage if somehow missing
function evercraft:hero_satchel/init_bag_if_missing with storage evercraft:hero_satchel temp

# Self-heal: re-link an already-stamped bag that's missing from the apply-registry. Without this a
# Hero's Satchel carried over from an older build (or any registry desync) shows its contents in the
# menu but grants no passive/AoE effects — same class as the Amethyst-Ring-no-effect bug. Idempotent.
function evercraft:hero_satchel/ensure_registered with storage evercraft:hero_satchel temp

# Pebble of Creation spirit-vessel migration: recover .realart for any accessory stored before this
# feature (its id was lost to the "_pebblenorm" sentinel), then rebuild the ec.sat_<id> markers so
# already-filled Pebbles grant each stored accessory's full real effect (passive + profession + real
# Dream Rate), not just a banked rarity approximation.
execute if entity @s[tag=ec.hsatch_pebble] run function evercraft:hero_satchel/menu/backfill_realart with storage evercraft:hero_satchel temp
execute if entity @s[tag=ec.hsatch_pebble] run function evercraft:hero_satchel/recompute_pebble_marks

# Open the menu
function evercraft:hero_satchel/menu/open
