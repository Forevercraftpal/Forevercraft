# Hero's Satchel — rewrite the CARTED satchel's "Contents:" lore. Runs after refresh_lore_swap pulled the
# item onto the ec.hsatch_lcart hopper-minecart. Editing the item ON the cart works where
# `data modify entity @s Inventory[...]` is read-only in 1.21.5+. 11 fixed slots -> the dynamic block is
# always 12 lines (1 header + 11 slot lines), appended after the item's static base lore.
#
# Steps: read lore_init off the cart; if set, strip the prior 12-line block; append the fresh 12 lines;
# mark lore_init=1. No macro args (the cart holds exactly one item — no bag_id match needed).

# Step 1: read lore_init off the carted item (pre-zero first: #lore_init is a shared fake-player score,
# and a failed/missing read must not inherit a stale 1 and trigger a strip on a fresh item)
scoreboard players set #lore_init ec.temp 0
execute store result score #lore_init ec.temp run data get entity @e[type=hopper_minecart,tag=ec.hsatch_lcart,limit=1] Items[0].components."minecraft:custom_data".lore_init
execute unless score #lore_init ec.temp matches 1.. run scoreboard players set #lore_init ec.temp 0

# Step 2: strip prior 12-line block from end if previously initialized
execute if score #lore_init ec.temp matches 1.. run function evercraft:hero_satchel/refresh_lore_strip

# Step 3: append fresh 12 lines
data modify entity @e[type=hopper_minecart,tag=ec.hsatch_lcart,limit=1] Items[0].components."minecraft:lore" append from storage evercraft:hero_satchel temp.lore_dynamic[0]
data modify entity @e[type=hopper_minecart,tag=ec.hsatch_lcart,limit=1] Items[0].components."minecraft:lore" append from storage evercraft:hero_satchel temp.lore_dynamic[1]
data modify entity @e[type=hopper_minecart,tag=ec.hsatch_lcart,limit=1] Items[0].components."minecraft:lore" append from storage evercraft:hero_satchel temp.lore_dynamic[2]
data modify entity @e[type=hopper_minecart,tag=ec.hsatch_lcart,limit=1] Items[0].components."minecraft:lore" append from storage evercraft:hero_satchel temp.lore_dynamic[3]
data modify entity @e[type=hopper_minecart,tag=ec.hsatch_lcart,limit=1] Items[0].components."minecraft:lore" append from storage evercraft:hero_satchel temp.lore_dynamic[4]
data modify entity @e[type=hopper_minecart,tag=ec.hsatch_lcart,limit=1] Items[0].components."minecraft:lore" append from storage evercraft:hero_satchel temp.lore_dynamic[5]
data modify entity @e[type=hopper_minecart,tag=ec.hsatch_lcart,limit=1] Items[0].components."minecraft:lore" append from storage evercraft:hero_satchel temp.lore_dynamic[6]
data modify entity @e[type=hopper_minecart,tag=ec.hsatch_lcart,limit=1] Items[0].components."minecraft:lore" append from storage evercraft:hero_satchel temp.lore_dynamic[7]
data modify entity @e[type=hopper_minecart,tag=ec.hsatch_lcart,limit=1] Items[0].components."minecraft:lore" append from storage evercraft:hero_satchel temp.lore_dynamic[8]
data modify entity @e[type=hopper_minecart,tag=ec.hsatch_lcart,limit=1] Items[0].components."minecraft:lore" append from storage evercraft:hero_satchel temp.lore_dynamic[9]
data modify entity @e[type=hopper_minecart,tag=ec.hsatch_lcart,limit=1] Items[0].components."minecraft:lore" append from storage evercraft:hero_satchel temp.lore_dynamic[10]
data modify entity @e[type=hopper_minecart,tag=ec.hsatch_lcart,limit=1] Items[0].components."minecraft:lore" append from storage evercraft:hero_satchel temp.lore_dynamic[11]

# Step 4: mark lore_init=1 on the carted item
data modify entity @e[type=hopper_minecart,tag=ec.hsatch_lcart,limit=1] Items[0].components."minecraft:custom_data".lore_init set value 1b
