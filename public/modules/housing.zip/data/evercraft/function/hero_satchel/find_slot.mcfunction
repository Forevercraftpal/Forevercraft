# Hero's Satchel — locate which inventory slot holds bag_id $(bid); write its /item slot ref to
# temp.slotref. (macro {bid}) Sets #ss_found ec.temp = 1 if located, else 0.
#
# The /item command (the only writable held-item path in 26.2) needs a CONCRETE slot ref; try_store
# clears the mainhand to air before refreshing, so the satchel can be anywhere. We scan the 27 main + 9
# hotbar slots + offhand (weapon.mainhand omitted: the selected hotbar slot is covered by its hotbar.N
# index). Keyed on hero_satchel:true so a regular Essentials Satchel sharing the same numeric bag_id
# (separate counter) can't be matched.
scoreboard players set #ss_found ec.temp 0
data modify storage evercraft:hero_satchel temp.slotref set value ""
$execute if items entity @s weapon.offhand *[custom_data~{hero_satchel:true,bag_id:$(bid)}] run data modify storage evercraft:hero_satchel temp.slotref set value "weapon.offhand"
$execute if items entity @s hotbar.0 *[custom_data~{hero_satchel:true,bag_id:$(bid)}] run data modify storage evercraft:hero_satchel temp.slotref set value "hotbar.0"
$execute if items entity @s hotbar.1 *[custom_data~{hero_satchel:true,bag_id:$(bid)}] run data modify storage evercraft:hero_satchel temp.slotref set value "hotbar.1"
$execute if items entity @s hotbar.2 *[custom_data~{hero_satchel:true,bag_id:$(bid)}] run data modify storage evercraft:hero_satchel temp.slotref set value "hotbar.2"
$execute if items entity @s hotbar.3 *[custom_data~{hero_satchel:true,bag_id:$(bid)}] run data modify storage evercraft:hero_satchel temp.slotref set value "hotbar.3"
$execute if items entity @s hotbar.4 *[custom_data~{hero_satchel:true,bag_id:$(bid)}] run data modify storage evercraft:hero_satchel temp.slotref set value "hotbar.4"
$execute if items entity @s hotbar.5 *[custom_data~{hero_satchel:true,bag_id:$(bid)}] run data modify storage evercraft:hero_satchel temp.slotref set value "hotbar.5"
$execute if items entity @s hotbar.6 *[custom_data~{hero_satchel:true,bag_id:$(bid)}] run data modify storage evercraft:hero_satchel temp.slotref set value "hotbar.6"
$execute if items entity @s hotbar.7 *[custom_data~{hero_satchel:true,bag_id:$(bid)}] run data modify storage evercraft:hero_satchel temp.slotref set value "hotbar.7"
$execute if items entity @s hotbar.8 *[custom_data~{hero_satchel:true,bag_id:$(bid)}] run data modify storage evercraft:hero_satchel temp.slotref set value "hotbar.8"
$execute if items entity @s inventory.0 *[custom_data~{hero_satchel:true,bag_id:$(bid)}] run data modify storage evercraft:hero_satchel temp.slotref set value "inventory.0"
$execute if items entity @s inventory.1 *[custom_data~{hero_satchel:true,bag_id:$(bid)}] run data modify storage evercraft:hero_satchel temp.slotref set value "inventory.1"
$execute if items entity @s inventory.2 *[custom_data~{hero_satchel:true,bag_id:$(bid)}] run data modify storage evercraft:hero_satchel temp.slotref set value "inventory.2"
$execute if items entity @s inventory.3 *[custom_data~{hero_satchel:true,bag_id:$(bid)}] run data modify storage evercraft:hero_satchel temp.slotref set value "inventory.3"
$execute if items entity @s inventory.4 *[custom_data~{hero_satchel:true,bag_id:$(bid)}] run data modify storage evercraft:hero_satchel temp.slotref set value "inventory.4"
$execute if items entity @s inventory.5 *[custom_data~{hero_satchel:true,bag_id:$(bid)}] run data modify storage evercraft:hero_satchel temp.slotref set value "inventory.5"
$execute if items entity @s inventory.6 *[custom_data~{hero_satchel:true,bag_id:$(bid)}] run data modify storage evercraft:hero_satchel temp.slotref set value "inventory.6"
$execute if items entity @s inventory.7 *[custom_data~{hero_satchel:true,bag_id:$(bid)}] run data modify storage evercraft:hero_satchel temp.slotref set value "inventory.7"
$execute if items entity @s inventory.8 *[custom_data~{hero_satchel:true,bag_id:$(bid)}] run data modify storage evercraft:hero_satchel temp.slotref set value "inventory.8"
$execute if items entity @s inventory.9 *[custom_data~{hero_satchel:true,bag_id:$(bid)}] run data modify storage evercraft:hero_satchel temp.slotref set value "inventory.9"
$execute if items entity @s inventory.10 *[custom_data~{hero_satchel:true,bag_id:$(bid)}] run data modify storage evercraft:hero_satchel temp.slotref set value "inventory.10"
$execute if items entity @s inventory.11 *[custom_data~{hero_satchel:true,bag_id:$(bid)}] run data modify storage evercraft:hero_satchel temp.slotref set value "inventory.11"
$execute if items entity @s inventory.12 *[custom_data~{hero_satchel:true,bag_id:$(bid)}] run data modify storage evercraft:hero_satchel temp.slotref set value "inventory.12"
$execute if items entity @s inventory.13 *[custom_data~{hero_satchel:true,bag_id:$(bid)}] run data modify storage evercraft:hero_satchel temp.slotref set value "inventory.13"
$execute if items entity @s inventory.14 *[custom_data~{hero_satchel:true,bag_id:$(bid)}] run data modify storage evercraft:hero_satchel temp.slotref set value "inventory.14"
$execute if items entity @s inventory.15 *[custom_data~{hero_satchel:true,bag_id:$(bid)}] run data modify storage evercraft:hero_satchel temp.slotref set value "inventory.15"
$execute if items entity @s inventory.16 *[custom_data~{hero_satchel:true,bag_id:$(bid)}] run data modify storage evercraft:hero_satchel temp.slotref set value "inventory.16"
$execute if items entity @s inventory.17 *[custom_data~{hero_satchel:true,bag_id:$(bid)}] run data modify storage evercraft:hero_satchel temp.slotref set value "inventory.17"
$execute if items entity @s inventory.18 *[custom_data~{hero_satchel:true,bag_id:$(bid)}] run data modify storage evercraft:hero_satchel temp.slotref set value "inventory.18"
$execute if items entity @s inventory.19 *[custom_data~{hero_satchel:true,bag_id:$(bid)}] run data modify storage evercraft:hero_satchel temp.slotref set value "inventory.19"
$execute if items entity @s inventory.20 *[custom_data~{hero_satchel:true,bag_id:$(bid)}] run data modify storage evercraft:hero_satchel temp.slotref set value "inventory.20"
$execute if items entity @s inventory.21 *[custom_data~{hero_satchel:true,bag_id:$(bid)}] run data modify storage evercraft:hero_satchel temp.slotref set value "inventory.21"
$execute if items entity @s inventory.22 *[custom_data~{hero_satchel:true,bag_id:$(bid)}] run data modify storage evercraft:hero_satchel temp.slotref set value "inventory.22"
$execute if items entity @s inventory.23 *[custom_data~{hero_satchel:true,bag_id:$(bid)}] run data modify storage evercraft:hero_satchel temp.slotref set value "inventory.23"
$execute if items entity @s inventory.24 *[custom_data~{hero_satchel:true,bag_id:$(bid)}] run data modify storage evercraft:hero_satchel temp.slotref set value "inventory.24"
$execute if items entity @s inventory.25 *[custom_data~{hero_satchel:true,bag_id:$(bid)}] run data modify storage evercraft:hero_satchel temp.slotref set value "inventory.25"
$execute if items entity @s inventory.26 *[custom_data~{hero_satchel:true,bag_id:$(bid)}] run data modify storage evercraft:hero_satchel temp.slotref set value "inventory.26"
execute unless data storage evercraft:hero_satchel temp{slotref:""} run scoreboard players set #ss_found ec.temp 1
