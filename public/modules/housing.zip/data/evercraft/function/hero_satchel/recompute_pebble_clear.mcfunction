# Hero Satchel — Drop ALL Pebble-stored-accessory markers (the tick carrying ENDS)
# ============================================================================
# Removes the exact set added by the last recompute_pebble_marks (kept in hpmarks.<id>) and persists
# an empty set, so a stored accessory's effect stops the moment the hero satchel leaves the inventory.
# Mirrors satchel/recompute_clear. Run as the player (@s).
# ----------------------------------------------------------------------------
execute unless score @s ec.hsatch_id matches 1.. run return 0
execute store result storage evercraft:hero_satchel temp.id int 1 run scoreboard players get @s ec.hsatch_id
function evercraft:hero_satchel/marks/clear_prev with storage evercraft:hero_satchel temp
data modify storage evercraft:hero_satchel temp.newmarks set value []
function evercraft:hero_satchel/marks/commit with storage evercraft:hero_satchel temp
