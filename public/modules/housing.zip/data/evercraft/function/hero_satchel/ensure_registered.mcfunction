# Hero's Satchel — Ensure the carried bag is in the player's apply-registry (macro, self-heal)
# Args: id (player hero satchel ID), bid (bag ID of the hero satchel being opened)
#
# WHY: identical to evercraft:satchel/ensure_registered, for the Hero's Satchel. The menu reads
# contents from bags.<bag_id> (the item's stamped id), but passive/AoE effects are applied by
# iterating registry.<hsatch_id> in apply_effects. A bag is only added to that registry inside
# stamp_bag_id, which runs ONLY when bag_id == 0 (the first stamp). A bag that has contents but is
# missing from the registry — an older satchel from a prior build, a storage/migration reset — shows
# its boss trinkets in the menu but grants NO effects. This re-links the bag, guarded by the per-bag
# owner_sid marker so a normally-registered bag is never appended twice.
$execute unless data storage evercraft:hero_satchel registry.$(id) run data modify storage evercraft:hero_satchel registry.$(id) set value []
$execute unless data storage evercraft:hero_satchel bags.$(bid).owner_sid run data modify storage evercraft:hero_satchel registry.$(id) append value $(bid)
$data modify storage evercraft:hero_satchel bags.$(bid).owner_sid set value $(id)
