# Hero's Satchel — Build dynamic "Contents:" lore array into storage
# Macro args: $(bid)
# Output: storage evercraft:hero_satchel temp.lore_dynamic (array of lore lines)
#
# Layout:
#   [0] header "Contents:"
#   [1..11] one per slot: "Slot N: <Boss Artifact Name>" or "Slot N: Empty"
#
# NAME BAKING (2026-06-19): the artifact name must be BAKED as a literal. The old build used a live
# {nbt:"bags...name",storage:...,interpret:true} source, but item tooltips render client-side and the
# client can't read server storage, so the name showed BLANK. For each occupied slot we append the
# "Slot N: " skeleton (empty extra[0] placeholder), then COPY the stored custom_name into it server-side.
# One appended line per slot, so refresh_lore_strip's 12-line removal count is unchanged.

# Reset target array
data modify storage evercraft:hero_satchel temp.lore_dynamic set value []

# Header
data modify storage evercraft:hero_satchel temp.lore_dynamic append value {text:"Contents:",color:"gold",italic:false}

# Slot 0..10 (fixed 11 slots) — occupied: skeleton + bake name; empty: literal "Empty"
$execute if data storage evercraft:hero_satchel bags.$(bid).s0.artifact run data modify storage evercraft:hero_satchel temp.lore_dynamic append value {text:"Slot 1: ",color:"gray",italic:false,extra:[{text:"",color:"#FF8C42",italic:false}]}
$execute if data storage evercraft:hero_satchel bags.$(bid).s0.artifact run data modify storage evercraft:hero_satchel temp.lore_dynamic[-1].extra[0] set from storage evercraft:hero_satchel bags.$(bid).s0.name
$execute unless data storage evercraft:hero_satchel bags.$(bid).s0.artifact run data modify storage evercraft:hero_satchel temp.lore_dynamic append value {text:"Slot 1: Empty",color:"dark_gray",italic:false}

$execute if data storage evercraft:hero_satchel bags.$(bid).s1.artifact run data modify storage evercraft:hero_satchel temp.lore_dynamic append value {text:"Slot 2: ",color:"gray",italic:false,extra:[{text:"",color:"#FF8C42",italic:false}]}
$execute if data storage evercraft:hero_satchel bags.$(bid).s1.artifact run data modify storage evercraft:hero_satchel temp.lore_dynamic[-1].extra[0] set from storage evercraft:hero_satchel bags.$(bid).s1.name
$execute unless data storage evercraft:hero_satchel bags.$(bid).s1.artifact run data modify storage evercraft:hero_satchel temp.lore_dynamic append value {text:"Slot 2: Empty",color:"dark_gray",italic:false}

$execute if data storage evercraft:hero_satchel bags.$(bid).s2.artifact run data modify storage evercraft:hero_satchel temp.lore_dynamic append value {text:"Slot 3: ",color:"gray",italic:false,extra:[{text:"",color:"#FF8C42",italic:false}]}
$execute if data storage evercraft:hero_satchel bags.$(bid).s2.artifact run data modify storage evercraft:hero_satchel temp.lore_dynamic[-1].extra[0] set from storage evercraft:hero_satchel bags.$(bid).s2.name
$execute unless data storage evercraft:hero_satchel bags.$(bid).s2.artifact run data modify storage evercraft:hero_satchel temp.lore_dynamic append value {text:"Slot 3: Empty",color:"dark_gray",italic:false}

$execute if data storage evercraft:hero_satchel bags.$(bid).s3.artifact run data modify storage evercraft:hero_satchel temp.lore_dynamic append value {text:"Slot 4: ",color:"gray",italic:false,extra:[{text:"",color:"#FF8C42",italic:false}]}
$execute if data storage evercraft:hero_satchel bags.$(bid).s3.artifact run data modify storage evercraft:hero_satchel temp.lore_dynamic[-1].extra[0] set from storage evercraft:hero_satchel bags.$(bid).s3.name
$execute unless data storage evercraft:hero_satchel bags.$(bid).s3.artifact run data modify storage evercraft:hero_satchel temp.lore_dynamic append value {text:"Slot 4: Empty",color:"dark_gray",italic:false}

$execute if data storage evercraft:hero_satchel bags.$(bid).s4.artifact run data modify storage evercraft:hero_satchel temp.lore_dynamic append value {text:"Slot 5: ",color:"gray",italic:false,extra:[{text:"",color:"#FF8C42",italic:false}]}
$execute if data storage evercraft:hero_satchel bags.$(bid).s4.artifact run data modify storage evercraft:hero_satchel temp.lore_dynamic[-1].extra[0] set from storage evercraft:hero_satchel bags.$(bid).s4.name
$execute unless data storage evercraft:hero_satchel bags.$(bid).s4.artifact run data modify storage evercraft:hero_satchel temp.lore_dynamic append value {text:"Slot 5: Empty",color:"dark_gray",italic:false}

$execute if data storage evercraft:hero_satchel bags.$(bid).s5.artifact run data modify storage evercraft:hero_satchel temp.lore_dynamic append value {text:"Slot 6: ",color:"gray",italic:false,extra:[{text:"",color:"#FF8C42",italic:false}]}
$execute if data storage evercraft:hero_satchel bags.$(bid).s5.artifact run data modify storage evercraft:hero_satchel temp.lore_dynamic[-1].extra[0] set from storage evercraft:hero_satchel bags.$(bid).s5.name
$execute unless data storage evercraft:hero_satchel bags.$(bid).s5.artifact run data modify storage evercraft:hero_satchel temp.lore_dynamic append value {text:"Slot 6: Empty",color:"dark_gray",italic:false}

$execute if data storage evercraft:hero_satchel bags.$(bid).s6.artifact run data modify storage evercraft:hero_satchel temp.lore_dynamic append value {text:"Slot 7: ",color:"gray",italic:false,extra:[{text:"",color:"#FF8C42",italic:false}]}
$execute if data storage evercraft:hero_satchel bags.$(bid).s6.artifact run data modify storage evercraft:hero_satchel temp.lore_dynamic[-1].extra[0] set from storage evercraft:hero_satchel bags.$(bid).s6.name
$execute unless data storage evercraft:hero_satchel bags.$(bid).s6.artifact run data modify storage evercraft:hero_satchel temp.lore_dynamic append value {text:"Slot 7: Empty",color:"dark_gray",italic:false}

$execute if data storage evercraft:hero_satchel bags.$(bid).s7.artifact run data modify storage evercraft:hero_satchel temp.lore_dynamic append value {text:"Slot 8: ",color:"gray",italic:false,extra:[{text:"",color:"#FF8C42",italic:false}]}
$execute if data storage evercraft:hero_satchel bags.$(bid).s7.artifact run data modify storage evercraft:hero_satchel temp.lore_dynamic[-1].extra[0] set from storage evercraft:hero_satchel bags.$(bid).s7.name
$execute unless data storage evercraft:hero_satchel bags.$(bid).s7.artifact run data modify storage evercraft:hero_satchel temp.lore_dynamic append value {text:"Slot 8: Empty",color:"dark_gray",italic:false}

$execute if data storage evercraft:hero_satchel bags.$(bid).s8.artifact run data modify storage evercraft:hero_satchel temp.lore_dynamic append value {text:"Slot 9: ",color:"gray",italic:false,extra:[{text:"",color:"#FF8C42",italic:false}]}
$execute if data storage evercraft:hero_satchel bags.$(bid).s8.artifact run data modify storage evercraft:hero_satchel temp.lore_dynamic[-1].extra[0] set from storage evercraft:hero_satchel bags.$(bid).s8.name
$execute unless data storage evercraft:hero_satchel bags.$(bid).s8.artifact run data modify storage evercraft:hero_satchel temp.lore_dynamic append value {text:"Slot 9: Empty",color:"dark_gray",italic:false}

$execute if data storage evercraft:hero_satchel bags.$(bid).s9.artifact run data modify storage evercraft:hero_satchel temp.lore_dynamic append value {text:"Slot 10: ",color:"gray",italic:false,extra:[{text:"",color:"#FF8C42",italic:false}]}
$execute if data storage evercraft:hero_satchel bags.$(bid).s9.artifact run data modify storage evercraft:hero_satchel temp.lore_dynamic[-1].extra[0] set from storage evercraft:hero_satchel bags.$(bid).s9.name
$execute unless data storage evercraft:hero_satchel bags.$(bid).s9.artifact run data modify storage evercraft:hero_satchel temp.lore_dynamic append value {text:"Slot 10: Empty",color:"dark_gray",italic:false}

$execute if data storage evercraft:hero_satchel bags.$(bid).s10.artifact run data modify storage evercraft:hero_satchel temp.lore_dynamic append value {text:"Slot 11: ",color:"gray",italic:false,extra:[{text:"",color:"#FF8C42",italic:false}]}
$execute if data storage evercraft:hero_satchel bags.$(bid).s10.artifact run data modify storage evercraft:hero_satchel temp.lore_dynamic[-1].extra[0] set from storage evercraft:hero_satchel bags.$(bid).s10.name
$execute unless data storage evercraft:hero_satchel bags.$(bid).s10.artifact run data modify storage evercraft:hero_satchel temp.lore_dynamic append value {text:"Slot 11: Empty",color:"dark_gray",italic:false}
