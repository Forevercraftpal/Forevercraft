# ============================================================
# Hero's Satchel — CONSOLIDATED Dream-Rate (Fusion Wave 1, Family A)
# ============================================================
# Runs as @s = player, called from hero_satchel/apply_held AFTER hero_satchel/apply_effects (the
# bag loop). For a plain Hero Satchel none of the branches below fire, so the bag-loop output is
# left INTACT (legacy behavior). For a FUSED capstone (Pebble of Creation, or either half-bag
# sub-binding) the matched consolidate/* sub-fn self-grants the member union (AoE + status) and
# presents ONE consolidated luck modifier in place of the per-trinket ones:
#
#   • Pebble of Creation  → remove the 11 boss *_luck + pebble_of_dreams_luck,
#                           add ONE evercraft:pebble_of_creation_luck = +18.5  (9*1.5 + 2*2.0 + 1.0)
#   • Aegis Half (6)      → remove the 6 bruiser *_luck,
#                           add ONE evercraft:pebble_aegis_luck = +9.0   (6*1.5)
#   • Astral Half (5)     → remove the 5 mobility/sense *_luck,
#                           add ONE evercraft:pebble_astral_luck = +8.5   (3*1.5 + 2*2.0)
#
# ADDITIVE: the AoE auras / status effects from the bag loop are NEVER stripped (zero-loss, T#3).
# Only the per-trinket *_luck DR modifiers are folded into the single consolidated number. The
# satchel storage menu is untouched — the result keeps custom_data{hero_satchel:true}, so all the
# menu/* code keys on it exactly as before.
#
# Idempotent per tick: the same removes + add run every second; an attribute modifier id can only
# exist once, so re-adding the consolidated id is a no-op-value-set, and the per-trinket ids stay
# removed for as long as the capstone is held.
#
# Detection is by the HELD capstone flag (custom_data{pebble_of_creation:true} /
# {aegis_half:true} / {astral_half:true}), scanned across container.* + weapon.offhand — the same
# slot coverage the rest of the satchel/accessory chain uses.
#
# Player-facing wording stays arcane / ancient / potent / power (house law).
# ------------------------------------------------------------

# === PEBBLE OF CREATION (Spirit Artifact) — consolidated +18.5 ===
execute if items entity @s container.* *[custom_data~{pebble_of_creation:true}] run function evercraft:hero_satchel/consolidate/pebble
execute unless items entity @s container.* *[custom_data~{pebble_of_creation:true}] if items entity @s weapon.offhand *[custom_data~{pebble_of_creation:true}] run function evercraft:hero_satchel/consolidate/pebble
# Cleanup: strip the stored-accessory DR modifier when no Pebble is held (consolidate/pebble re-adds it
# while held). Mirrors the per-trinket strips' not-held idiom so it never lingers after the Pebble leaves.
execute unless items entity @s container.* *[custom_data~{pebble_of_creation:true}] unless items entity @s weapon.offhand *[custom_data~{pebble_of_creation:true}] run attribute @s luck modifier remove evercraft:pebble_normals_luck

# === AEGIS HALF (bruiser/aura sub-binding) — consolidated +9.0 ===
# Guarded `unless` a Pebble is also held: the Pebble already grants the full 11-boss union (which
# includes Aegis's 6), so running the half on top would double-count its DR. Pebble supersedes.
execute unless items entity @s container.* *[custom_data~{pebble_of_creation:true}] unless items entity @s weapon.offhand *[custom_data~{pebble_of_creation:true}] if items entity @s container.* *[custom_data~{aegis_half:true}] run function evercraft:hero_satchel/consolidate/aegis
execute unless items entity @s container.* *[custom_data~{pebble_of_creation:true}] unless items entity @s weapon.offhand *[custom_data~{pebble_of_creation:true}] unless items entity @s container.* *[custom_data~{aegis_half:true}] if items entity @s weapon.offhand *[custom_data~{aegis_half:true}] run function evercraft:hero_satchel/consolidate/aegis

# === ASTRAL HALF (mobility/sense sub-binding) — consolidated +8.5 ===
# Same Pebble guard as Aegis (the Pebble's union already covers Astral's 5).
execute unless items entity @s container.* *[custom_data~{pebble_of_creation:true}] unless items entity @s weapon.offhand *[custom_data~{pebble_of_creation:true}] if items entity @s container.* *[custom_data~{astral_half:true}] run function evercraft:hero_satchel/consolidate/astral
execute unless items entity @s container.* *[custom_data~{pebble_of_creation:true}] unless items entity @s weapon.offhand *[custom_data~{pebble_of_creation:true}] unless items entity @s container.* *[custom_data~{astral_half:true}] if items entity @s weapon.offhand *[custom_data~{astral_half:true}] run function evercraft:hero_satchel/consolidate/astral
