# Hero Satchel — Rebuild the player's "virtually-held" markers for Pebble-stored normal accessories
# ============================================================================
# Sets one tag  ec.sat_<realart>  per NORMAL accessory currently stored in ANY of this player's
# registered hero bags (Pebble of Creation slots banked under the "_pebblenorm" sentinel + a .realart
# id). Downstream detection (player_tick passives + profession sites) accepts these tags as an
# "is-held" source, so a Pebble-stored accessory grants its full effect exactly as a loose copy —
# this is what makes the Pebble a true spirit vessel and not just a Dream-Rate bank.
#
# Boss trinkets keep flowing through apply_effects / consolidate/pebble (they have .artifact, never
# .realart, so the slot scan skips them here). Shares the regular satchel's ec.sat_<id> tag namespace
# on purpose — the same 269 detection branches light up for either storage.
#
# DRIFT-FREE: removes the EXACT set added last rebuild (kept in hpmarks.<id>), then re-scans/re-adds.
# COST: runs ONLY on a carry-transition (see satchel/check_and_apply) or a store/withdraw (handle_click)
# — never every tick. Run as the player (@s).
# ----------------------------------------------------------------------------

# Need a hero satchel id to locate this player's registry + prev-marks.
execute unless score @s ec.hsatch_id matches 1.. run return 0
execute store result storage evercraft:hero_satchel temp.id int 1 run scoreboard players get @s ec.hsatch_id

# 1) Remove the markers we set on the previous rebuild (exact, drift-free).
function evercraft:hero_satchel/marks/clear_prev with storage evercraft:hero_satchel temp

# 2) Fresh accumulator for the markers we are about to set.
data modify storage evercraft:hero_satchel temp.newmarks set value []

# 3) Walk every registered bag's slots, tagging each stored normal accessory + recording it.
function evercraft:hero_satchel/copy_registry with storage evercraft:hero_satchel temp
function evercraft:hero_satchel/marks/scan_next_bag

# 4) Persist the new marker set so the next rebuild can clear it exactly.
function evercraft:hero_satchel/marks/commit with storage evercraft:hero_satchel temp

# 5) Spirit-vessel: keep each stored toggleable accessory's ACTIVE ability ON (#9). The marker grants
# the effect gated on the toggle, which defaults to ON — this resets any explicit toggle-off so a
# Pebble-stored active stays "permanently activated."
function evercraft:hero_satchel/pebble_activate_toggles
