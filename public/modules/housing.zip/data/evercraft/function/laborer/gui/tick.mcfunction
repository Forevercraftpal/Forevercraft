# Laborer GUI tick — placeholder for future text_display menu implementation
# Currently using chat-based info display (gui/show_info.mcfunction)
# This function is called per-tick for players with tag ec.lb_placeholder
# When text_display GUI is implemented, click detection logic goes here
