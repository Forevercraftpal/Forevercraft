# Restore contract item to player (1 tick after consume_item destroyed it)
# Dispatches to loot give based on the hire type score
tag @s remove ec.lb_restore

# Give back the correct contract type using loot give
# Inv-full guard: drop at the player's feet rather than void on a full inventory.
execute store result score #inv_full ec.var run function evercraft:util/check_inv_full
execute if score @s ec.lb_hire_type matches 1 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:laborer/contracts/miner
execute if score @s ec.lb_hire_type matches 1 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:laborer/contracts/miner
execute if score @s ec.lb_hire_type matches 2 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:laborer/contracts/farmer
execute if score @s ec.lb_hire_type matches 2 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:laborer/contracts/farmer
execute if score @s ec.lb_hire_type matches 3 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:laborer/contracts/fisher
execute if score @s ec.lb_hire_type matches 3 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:laborer/contracts/fisher
execute if score @s ec.lb_hire_type matches 4 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:laborer/contracts/woodcutter
execute if score @s ec.lb_hire_type matches 4 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:laborer/contracts/woodcutter
execute if score @s ec.lb_hire_type matches 5 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:laborer/contracts/forager
execute if score @s ec.lb_hire_type matches 5 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:laborer/contracts/forager
execute if score @s ec.lb_hire_type matches 6 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:laborer/contracts/prospector
execute if score @s ec.lb_hire_type matches 6 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:laborer/contracts/prospector
