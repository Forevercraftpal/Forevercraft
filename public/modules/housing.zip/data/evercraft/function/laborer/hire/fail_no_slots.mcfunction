# Contract failed — no available laborer slots. Refund contract.
data modify storage evercraft:notify stage.c set value [{text:"You have no available laborer slots! (",color:"red"},{score:{name:"@s",objective:"ec.lb_count"},color:"yellow"},{text:"/",color:"red"},{score:{name:"@s",objective:"ec.lb_max"},color:"yellow"},{text:")",color:"red"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.villager.no master @s ~ ~ ~ 1 1
