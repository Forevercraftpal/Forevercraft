# Contract failed — Artisan Rank too low. Refund contract.
data modify storage evercraft:notify stage.c set value [{text:"Your Artisan Rank is too low to hire this laborer!",color:"red"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.villager.no master @s ~ ~ ~ 1 1
