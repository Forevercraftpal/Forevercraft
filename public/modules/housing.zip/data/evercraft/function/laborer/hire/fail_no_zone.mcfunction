# Contract failed — player not in home zone. Refund contract.
data modify storage evercraft:notify stage.c set value [{text:"You must be inside your home zone to hire a laborer!",color:"red"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.villager.no master @s ~ ~ ~ 1 1
