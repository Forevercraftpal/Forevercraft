# Adventure: Cave Discovery (Miner/Prospector)
data modify storage evercraft:notify stage.c set value [{text:"Laborer Adventure",color:"yellow",bold:true}]
scoreboard players set #ndur ec.temp 50
execute as @a[distance=..64] run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"\"I found a hidden cave system deep",color:"white",italic:true}]
scoreboard players set #ndur ec.temp 40
execute as @a[distance=..64] run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"beneath the hills... the walls glittered",color:"white",italic:true}]
scoreboard players set #ndur ec.temp 40
execute as @a[distance=..64] run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"with ore I've never seen before.\"",color:"white",italic:true}]
scoreboard players set #ndur ec.temp 40
execute as @a[distance=..64] run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:">> ",color:"gold"},{text:"Bonus emeralds found!",color:"green"}]
scoreboard players set #ndur ec.temp 40
execute as @a[distance=..64] run function evercraft:util/notify/emit
# Reward: bonus emeralds
give @a[tag=ec.lb_owner,limit=1] minecraft:emerald 8
playsound minecraft:ui.toast.challenge_complete master @a[distance=..64,scores={ec.fx_snd=1..}] ~ ~ ~ 0.7 1.2
