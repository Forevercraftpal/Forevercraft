# Adventure: Weather Warning (Fisher/Forager)
data modify storage evercraft:notify stage.c set value [{text:"Laborer Adventure",color:"yellow",bold:true}]
scoreboard players set #ndur ec.temp 50
execute as @a[distance=..64] run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"\"The sky had a strange color today.",color:"white",italic:true}]
scoreboard players set #ndur ec.temp 40
execute as @a[distance=..64] run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Old sailors say that means a storm's coming.\"",color:"white",italic:true}]
scoreboard players set #ndur ec.temp 40
execute as @a[distance=..64] run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:">> ",color:"gold"},{text:"Weather wisdom! +250 Artisan XP",color:"green"}]
scoreboard players set #ndur ec.temp 40
execute as @a[distance=..64] run function evercraft:util/notify/emit
# Resolved at collect (via adventure/resolve), so granting the owner directly here is action-gated.
scoreboard players add @a[tag=ec.lb_owner,limit=1] ec.cf_xp 250
execute as @a[tag=ec.lb_owner,limit=1] run function evercraft:craftforever/artisan/check_levelup
playsound minecraft:ui.toast.challenge_complete master @a[distance=..64,scores={ec.fx_snd=1..}] ~ ~ ~ 0.7 1.2
