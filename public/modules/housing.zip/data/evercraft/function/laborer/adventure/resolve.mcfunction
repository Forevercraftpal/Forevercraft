# Laborer Adventure — Resolve on collect
# RE-P4 fix (Joseph verdict 2026-06-10): grant the PLACEABLE crate item (crates/items/<tier>)
# instead of inlining contents via `loot give` — `loot give` has no opener context, so the
# difficulty-gated accessory pools silently collapsed to the 5% Pioneer branch for everyone.
# The crate item resolves its container_loot at PLACEMENT, where `this` = the real opener.
# Runs as: laborer entity (@s), called from expedition/collect. @a[tag=ec.lb_owner] = owner.
# The adventure rolled at expedition return was stashed (ec.lb_pend_adv 1-12, ec.lb_pend_tp 0/1)
# so NOTHING is granted passively at return — the story, themed loot, XP, a quality-scaled REWARD
# CRATE (real datapack loot, not just vanilla items) and the Trial Pass all play out HERE, gated
# by the player's collect-click. #lb_qtier (0-4, computed near the top of expedition/collect)
# scales the crate rarity. 2026-06-05.

# Establish the owner context. The adventure handlers + crate below grant to @a[tag=ec.lb_owner];
# the tick loop normally sets that tag via find_owner before an adventure runs, but the collect
# path (handle_click) does not — so we set it here exactly as tick_single does, and clear it at
# the end. find_owner runs as the laborer (@s) and tags the true owner by companion.id. 2026-06-05.
function evercraft:laborer/find_owner

# 1) Dispatch the stashed adventure handler (each plays its own narrative + grants its themed
#    flavor loot/XP directly to the owner — action-gated now that this runs on the collect-click).
execute if score @s ec.lb_pend_adv matches 1 run function evercraft:laborer/adventure/cave_discovery
execute if score @s ec.lb_pend_adv matches 2 run function evercraft:laborer/adventure/fishing_hole
execute if score @s ec.lb_pend_adv matches 3 run function evercraft:laborer/adventure/hidden_garden
execute if score @s ec.lb_pend_adv matches 4 run function evercraft:laborer/adventure/rare_specimen
execute if score @s ec.lb_pend_adv matches 5 run function evercraft:laborer/adventure/ancient_cache
execute if score @s ec.lb_pend_adv matches 6 run function evercraft:laborer/adventure/travelers_tale
execute if score @s ec.lb_pend_adv matches 7 run function evercraft:laborer/adventure/monster_encounter
execute if score @s ec.lb_pend_adv matches 8 run function evercraft:laborer/adventure/weather_warning
execute if score @s ec.lb_pend_adv matches 9 run function evercraft:laborer/adventure/lost_recipe
execute if score @s ec.lb_pend_adv matches 10 run function evercraft:laborer/adventure/ore_vein_mapped
execute if score @s ec.lb_pend_adv matches 11 run function evercraft:laborer/adventure/strange_egg
execute if score @s ec.lb_pend_adv matches 12 run function evercraft:laborer/adventure/masters_wisdom

# 2) Quality-scaled REWARD CRATE — the real datapack loot (custom items via crates/<rarity>).
#    Rarity from the laborer's expedition quality tier #lb_qtier: 0 meager->common, 1 decent->
#    uncommon, 2 bountiful->rare, 3 abundant->ornate, 4 legendary->exquisite. inv-full -> spawn
#    at the owner's feet (loot tables void into a full inventory, so we must guard).
execute as @a[tag=ec.lb_owner,limit=1] store result score #inv_full ec.var run function evercraft:util/check_inv_full
execute if score #lb_qtier ec.lb_temp matches 0 if score #inv_full ec.var matches 0 as @a[tag=ec.lb_owner,limit=1] run loot give @s loot evercraft:crates/items/common
execute if score #lb_qtier ec.lb_temp matches 0 if score #inv_full ec.var matches 1 as @a[tag=ec.lb_owner,limit=1] at @s run loot spawn ~ ~ ~ loot evercraft:crates/items/common
execute if score #lb_qtier ec.lb_temp matches 1 if score #inv_full ec.var matches 0 as @a[tag=ec.lb_owner,limit=1] run loot give @s loot evercraft:crates/items/uncommon
execute if score #lb_qtier ec.lb_temp matches 1 if score #inv_full ec.var matches 1 as @a[tag=ec.lb_owner,limit=1] at @s run loot spawn ~ ~ ~ loot evercraft:crates/items/uncommon
execute if score #lb_qtier ec.lb_temp matches 2 if score #inv_full ec.var matches 0 as @a[tag=ec.lb_owner,limit=1] run loot give @s loot evercraft:crates/items/rare
execute if score #lb_qtier ec.lb_temp matches 2 if score #inv_full ec.var matches 1 as @a[tag=ec.lb_owner,limit=1] at @s run loot spawn ~ ~ ~ loot evercraft:crates/items/rare
execute if score #lb_qtier ec.lb_temp matches 3 if score #inv_full ec.var matches 0 as @a[tag=ec.lb_owner,limit=1] run loot give @s loot evercraft:crates/items/ornate
execute if score #lb_qtier ec.lb_temp matches 3 if score #inv_full ec.var matches 1 as @a[tag=ec.lb_owner,limit=1] at @s run loot spawn ~ ~ ~ loot evercraft:crates/items/ornate
execute if score #lb_qtier ec.lb_temp matches 4 if score #inv_full ec.var matches 0 as @a[tag=ec.lb_owner,limit=1] run loot give @s loot evercraft:crates/items/exquisite
execute if score #lb_qtier ec.lb_temp matches 4 if score #inv_full ec.var matches 1 as @a[tag=ec.lb_owner,limit=1] at @s run loot spawn ~ ~ ~ loot evercraft:crates/items/exquisite
data modify storage evercraft:notify stage.c set value [{text:">> ",color:"gold"},{text:"Expedition spoils recovered!",color:"aqua"}]
scoreboard players set #ndur ec.temp 45
execute as @a[tag=ec.lb_owner,limit=1] run function evercraft:util/notify/emit

# 3) Trial Pass bonus (1-in-3, rolled at return) — to the owner, inv-full -> spawn at feet.
execute if score @s ec.lb_pend_tp matches 1.. as @a[tag=ec.lb_owner,limit=1] store result score #inv_full ec.var run function evercraft:util/check_inv_full
execute if score @s ec.lb_pend_tp matches 1.. if score #inv_full ec.var matches 0 as @a[tag=ec.lb_owner,limit=1] run loot give @s loot evercraft:craftforever/trials/trial_pass
execute if score @s ec.lb_pend_tp matches 1.. if score #inv_full ec.var matches 1 as @a[tag=ec.lb_owner,limit=1] at @s run loot spawn ~ ~ ~ loot evercraft:craftforever/trials/trial_pass
execute if score @s ec.lb_pend_tp matches 1.. run data modify storage evercraft:notify stage.c set value [{text:">> ",color:"gold"},{text:"Trial Pass",color:"#FFD700",bold:true},{text:" recovered from the satchel.",color:"gray"}]
execute if score @s ec.lb_pend_tp matches 1.. run scoreboard players set #ndur ec.temp 45
execute if score @s ec.lb_pend_tp matches 1.. as @a[tag=ec.lb_owner,limit=1] run function evercraft:util/notify/emit

# 4) Clear pending + the owner tag (mirrors tick_single's cleanup so it never lingers)
scoreboard players set @s ec.lb_pend_adv 0
scoreboard players set @s ec.lb_pend_tp 0
tag @a[tag=ec.lb_owner] remove ec.lb_owner
