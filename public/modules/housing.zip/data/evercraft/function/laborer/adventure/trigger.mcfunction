# An adventure event has been triggered!
# Pick a random adventure type (1-12)
# Runs as: laborer entity

scoreboard players add @s ec.lb_adventures 1

# Pick adventure type
execute store result score #lb_adv_type ec.lb_temp run random value 1..12

# Master's Wisdom (12) only available at quality 13+, re-roll if not
execute if score #lb_adv_type ec.lb_temp matches 12 unless score @s ec.lb_quality matches 13.. store result score #lb_adv_type ec.lb_temp run random value 1..11

# Stash the rolled adventure on the laborer — it is RESOLVED (narrative + themed loot + XP + a
# quality-scaled reward crate + Trial Pass) when the player COLLECTS the expedition
# (evercraft:laborer/expedition/collect -> adventure/resolve). Nothing is granted at return.
# @s = laborer entity. 2026-06-05.
scoreboard players operation @s ec.lb_pend_adv = #lb_adv_type ec.lb_temp

# Trial Pass bonus: 1-in-3 chance the adventure also yields a Trial Pass — stashed too, handed
# over in adventure/resolve at collect.
execute store result score #lb_tp_roll ec.lb_temp run random value 1..3
execute if score #lb_tp_roll ec.lb_temp matches 1 run scoreboard players set @s ec.lb_pend_tp 1
