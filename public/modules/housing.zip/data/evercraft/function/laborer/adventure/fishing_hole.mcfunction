# Adventure: Fishing Hole (Fisher)
data modify storage evercraft:notify stage.c set value [{text:"Laborer Adventure",color:"yellow",bold:true}]
scoreboard players set #ndur ec.temp 50
execute as @a[distance=..64] run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"\"I discovered a hidden fishing hole",color:"white",italic:true}]
scoreboard players set #ndur ec.temp 40
execute as @a[distance=..64] run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"teeming with rare fish!\"",color:"white",italic:true}]
scoreboard players set #ndur ec.temp 40
execute as @a[distance=..64] run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:">> ",color:"gold"},{text:"Bonus nautilus shells!",color:"green"}]
scoreboard players set #ndur ec.temp 40
execute as @a[distance=..64] run function evercraft:util/notify/emit
give @a[tag=ec.lb_owner,limit=1] minecraft:nautilus_shell 3
playsound minecraft:ui.toast.challenge_complete master @a[distance=..64,scores={ec.fx_snd=1..}] ~ ~ ~ 0.7 1.2
