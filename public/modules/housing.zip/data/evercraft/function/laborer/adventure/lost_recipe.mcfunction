# Adventure: Lost Recipe (Farmer/Forager)
data modify storage evercraft:notify stage.c set value [{text:"Laborer Adventure",color:"yellow",bold:true}]
scoreboard players set #ndur ec.temp 50
execute as @a[distance=..64] run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"\"I found an old journal with a recipe",color:"white",italic:true}]
scoreboard players set #ndur ec.temp 40
execute as @a[distance=..64] run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"written in faded ink. Someone once made",color:"white",italic:true}]
scoreboard players set #ndur ec.temp 40
execute as @a[distance=..64] run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"wonderful things with these ingredients.\"",color:"white",italic:true}]
scoreboard players set #ndur ec.temp 40
execute as @a[distance=..64] run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:">> ",color:"gold"},{text:"Rare cooking ingredients found!",color:"green"}]
scoreboard players set #ndur ec.temp 40
execute as @a[distance=..64] run function evercraft:util/notify/emit
give @a[tag=ec.lb_owner,limit=1] minecraft:golden_carrot 4
give @a[tag=ec.lb_owner,limit=1] minecraft:honey_bottle 4
playsound minecraft:ui.toast.challenge_complete master @a[distance=..64,scores={ec.fx_snd=1..}] ~ ~ ~ 0.7 1.2
