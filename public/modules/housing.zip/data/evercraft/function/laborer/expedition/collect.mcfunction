# Collect expedition loot from a RETURNED laborer
# Runs as: laborer entity (state 3), at laborer position. Player = @p

# Determine quality tier name and dispatch to loot table
# Quality 0-3: meager, 4-6: decent, 7-9: bountiful, 10-12: abundant, 13+: legendary

# Store quality for branching
scoreboard players set #lb_qtier ec.lb_temp 0
execute if score @s ec.lb_quality matches 4..6 run scoreboard players set #lb_qtier ec.lb_temp 1
execute if score @s ec.lb_quality matches 7..9 run scoreboard players set #lb_qtier ec.lb_temp 2
execute if score @s ec.lb_quality matches 10..12 run scoreboard players set #lb_qtier ec.lb_temp 3
execute if score @s ec.lb_quality matches 13.. run scoreboard players set #lb_qtier ec.lb_temp 4

# Inv-full guard for the @p loot dispatch (drop at the player's feet rather than void on a full inventory).
execute as @p store result score #inv_full ec.var run function evercraft:util/check_inv_full
# Dispatch to type-specific loot based on quality tier
execute if score @s ec.lb_type matches 1 run function evercraft:laborer/expedition/loot_miner
execute if score @s ec.lb_type matches 2 run function evercraft:laborer/expedition/loot_farmer
execute if score @s ec.lb_type matches 3 run function evercraft:laborer/expedition/loot_fisher
execute if score @s ec.lb_type matches 4 run function evercraft:laborer/expedition/loot_woodcutter
execute if score @s ec.lb_type matches 5 run function evercraft:laborer/expedition/loot_forager
execute if score @s ec.lb_type matches 6 run function evercraft:laborer/expedition/loot_prospector

# Coin reward (quality-scaled)
function evercraft:coins/laborer_reward

# Legendary expedition: 15% chance bonus Rare artifact (single roll)
execute if score #lb_qtier ec.lb_temp matches 4 store success score #lb_bonus ec.lb_temp if predicate {"condition":"minecraft:random_chance","chance":0.15}
# Recompute inv-full as @p (the main loot dispatch above may have filled the last slot) before the bonus artifact.
execute if score #lb_bonus ec.lb_temp matches 1 as @p store result score #inv_full ec.var run function evercraft:util/check_inv_full
execute if score #lb_bonus ec.lb_temp matches 1 if score #inv_full ec.var matches 0 as @p run loot give @s loot evercraft:artifacts/rare/main
execute if score #lb_bonus ec.lb_temp matches 1 if score #inv_full ec.var matches 1 as @p at @s run loot spawn ~ ~ ~ loot evercraft:artifacts/rare/main
execute if score #lb_bonus ec.lb_temp matches 1 run data modify storage evercraft:notify stage.c set value [{text:"★ ",color:"aqua"},{text:"Rare Artifact",color:"aqua",bold:true},{text:" — Legendary Find!",color:"gold"},{text:" ★",color:"aqua"}]
execute if score #lb_bonus ec.lb_temp matches 1 run scoreboard players set #ndur ec.temp 45
execute if score #lb_bonus ec.lb_temp matches 1 as @p run function evercraft:util/notify/emit

# Reset to IDLE state and record return time for cooldown
scoreboard players set @s ec.lb_state 0
execute store result score @s ec.lb_exp_start run time query gametime

# Feedback
playsound minecraft:entity.item.pickup master @p[scores={ec.fx_snd=1..}] ~ ~ ~ 1 1
tellraw @p [{"text":"[Laborer] ","color":"gold"},{"text":"Loot collected! ","color":"green"},{"text":"(Quality: ","color":"gray"},{"score":{"name":"@s","objective":"ec.lb_quality"},"color":"yellow"},{"text":")","color":"gray"}]

# Count this expedition on the PLAYER (total across all laborers). This is the
# score Dream Rank, the Expeditionist trophy, the s108/s109 milestones, story
# ch26 and nav all read — the per-laborer count in check_return lives on the
# villager entity and never reached the owner. Tying it to collect makes it
# action-gated (no idle-timer inflation) and repairs those downstream systems.
scoreboard players add @p ec.lb_expeditions 1

# Grant base Artisan XP for collection
scoreboard players add @p ec.cf_xp 25
execute as @p run function evercraft:craftforever/artisan/check_levelup

# Resolve any adventure the laborer rolled on this expedition — its narrative + ALL themed loot,
# XP, a quality-scaled REWARD CRATE (real datapack loot, not just vanilla), and the Trial Pass
# play out NOW, gated by the collect-click instead of granted passively at return. #lb_qtier
# (set near the top of this file) scales the crate rarity. 2026-06-05.
execute if score @s ec.lb_pend_adv matches 1.. run function evercraft:laborer/adventure/resolve
