# ============================================================
# Housing — Enqueue a deferred reset for an offline / non-player break (β)
# Run as: @s = the HS.Marker (in on_break, after check_owner_reset found no
# online owner). Reads the marker's stored owner UUID + this home's gs_id and
# appends {u0..u3, gs:<gs_id>} to storage evercraft:housing pending_reset.
# login/reconcile drains it on the owner's next join (clears the ghost slot +
# snapshots the home to recovery just before clearing). Survives restart.
#
# Guard: the marker MUST carry data.owner_uuid (set at setup_hearthstone /
# confirm_relocate). A legacy / pending marker without it is skipped — there
# is no owner to reconcile to.
# ============================================================

# No owner UUID on the marker -> nothing to enqueue.
execute unless data entity @s data.owner_uuid run return 0

# Build the queue entry from the marker's owner_uuid (4-int array) + gs_id.
data modify storage evercraft:housing pr_new set value {u0:0,u1:0,u2:0,u3:0,gs:0}
execute store result storage evercraft:housing pr_new.u0 int 1 run data get entity @s data.owner_uuid[0]
execute store result storage evercraft:housing pr_new.u1 int 1 run data get entity @s data.owner_uuid[1]
execute store result storage evercraft:housing pr_new.u2 int 1 run data get entity @s data.owner_uuid[2]
execute store result storage evercraft:housing pr_new.u3 int 1 run data get entity @s data.owner_uuid[3]
execute store result storage evercraft:housing pr_new.gs int 1 run scoreboard players get @s ec.gs_id

# De-dupe: drop any prior queue entry for the SAME (owner, gs_id) so a
# repeated poll (the 2s marker tick can fire on_break more than once before
# the marker is killed) never stacks duplicates.
function evercraft:housing/dedupe_pending_reset with storage evercraft:housing pr_new

# Append.
data modify storage evercraft:housing pending_reset append from storage evercraft:housing pr_new
