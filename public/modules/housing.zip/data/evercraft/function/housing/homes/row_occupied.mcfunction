# ============================================================
# Manage Homes — render an OCCUPIED row label
# Run as: player, at player. Macro arg: {n:<1-5>}
# Label: «Name»  T<tier> · <dim>   (★ prefix if this slot is active)
# Pulls the home's display name from the guidestone registry by gs_id.
# ============================================================

# Resolve this slot's gs_id into the name-lookup input + run the lookup.
$execute store result score #hm_look_gs hs.temp run scoreboard players get @s hs.h$(n)_gs
function evercraft:housing/homes/lookup_name

# Tier + dim into the row macro storage
$execute store result storage evercraft:housing hrow.tier int 1 run scoreboard players get @s hs.h$(n)_tier
data modify storage evercraft:housing hrow.dim set value "OW"
$execute if score @s hs.h$(n)_dim matches 1 run data modify storage evercraft:housing hrow.dim set value "Nether"
$execute if score @s hs.h$(n)_dim matches 2 run data modify storage evercraft:housing hrow.dim set value "End"

# Active-slot star prefix
data modify storage evercraft:housing hrow.star set value ""
$execute if score @s hs.active matches $(n) run data modify storage evercraft:housing hrow.star set value "★ "

# Slot number into the macro (targets HS.HmRow<n>); name was left in
# hrow.name by lookup_name.
$data modify storage evercraft:housing hrow.n set value "$(n)"

# Render the label (one generic macro targets HS.HmRow$(n))
function evercraft:housing/homes/set_row_label with storage evercraft:housing hrow
