# ============================================================
# Manage Homes Sub-Menu — Close, return to main menu
# Run as: player with HS.InMenu + HS.InHomes
# Mirrors laborers/close_laborers.
# ============================================================

# Remove manage-homes tag
tag @s remove HS.InHomes

# Kill ALL manage-homes sub-menu elements
kill @e[type=text_display,tag=HS.HomesEl,distance=..7]
kill @e[type=interaction,tag=HS.HomesEl,distance=..7]
kill @e[type=item_display,tag=HS.HomesBG,distance=..7]

# Re-open main menu (which spawns fresh elements)
# First remove HS.InMenu so open doesn't toggle-close
tag @s remove HS.InMenu
execute at @s run function evercraft:housing/gui/open
