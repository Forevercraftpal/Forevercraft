# ============================================================
# Manage Homes — [Set active] make home N the active slot
# Run as: @s = the player (called `on target` from check_clicks)
# Macro arg: {n:<1-5>}
# Delegates to Agent A's slot/set_active (the SOLE writer of hs.active on
# this path): it flushes the current mirror, points hs.active=N, reloads the
# mirror, and forces a clean zone re-entry. Re-points zone buffs, codex-tp
# default, laborer home, remote-stash target, and the cross-system readers.
# ============================================================

# Feed the target slot into set_active's input score
$scoreboard players set #hs_set_slot hs.temp $(n)
function evercraft:housing/slot/set_active

# Feedback (set_active returns fail for empty/locked targets — refresh anyway)
$execute if score @s hs.active matches $(n) run data modify entity @e[type=text_display,tag=HS.HmStatus,distance=..7,limit=1] text set value [{text:"Active home set to slot $(n).",color:"green"}]
$execute unless score @s hs.active matches $(n) run data modify entity @e[type=text_display,tag=HS.HmStatus,distance=..7,limit=1] text set value {text:"That home slot is empty.",color:"yellow"}
execute if score @s hs.active matches 1.. if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.5 1.5

# Refresh the panel (re-stars the active row, re-greys its [Set])
execute at @s run function evercraft:housing/homes/refresh
