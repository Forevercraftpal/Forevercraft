# ============================================================
# Manage Homes Sub-Menu — Check for clicks
# Run as: player with HS.InHomes, at player
# Every handler is session-gated on #gui_check (set by gui/tick to this
# player's adv.gui_session) so a click can't resolve against a nearby
# player's homes menu. Entities are stamped in homes/open.
# Buttons carry the slot number in their tag (HS.HmGo1..5 etc.); each row's
# handler is called with {n:N} so the action functions take a clean slot arg.
# ============================================================

# --- [Go] teleport to home N ---
execute as @e[type=interaction,tag=HS.HmGo1,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction on target run function evercraft:housing/homes/go {n:1}
execute as @e[type=interaction,tag=HS.HmGo1,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=HS.HmGo2,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction on target run function evercraft:housing/homes/go {n:2}
execute as @e[type=interaction,tag=HS.HmGo2,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=HS.HmGo3,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction on target run function evercraft:housing/homes/go {n:3}
execute as @e[type=interaction,tag=HS.HmGo3,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=HS.HmGo4,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction on target run function evercraft:housing/homes/go {n:4}
execute as @e[type=interaction,tag=HS.HmGo4,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=HS.HmGo5,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction on target run function evercraft:housing/homes/go {n:5}
execute as @e[type=interaction,tag=HS.HmGo5,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction run data remove entity @s interaction

# --- [Set] make home N active ---
execute as @e[type=interaction,tag=HS.HmSet1,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction on target run function evercraft:housing/homes/row_set_active {n:1}
execute as @e[type=interaction,tag=HS.HmSet1,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=HS.HmSet2,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction on target run function evercraft:housing/homes/row_set_active {n:2}
execute as @e[type=interaction,tag=HS.HmSet2,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=HS.HmSet3,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction on target run function evercraft:housing/homes/row_set_active {n:3}
execute as @e[type=interaction,tag=HS.HmSet3,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=HS.HmSet4,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction on target run function evercraft:housing/homes/row_set_active {n:4}
execute as @e[type=interaction,tag=HS.HmSet4,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=HS.HmSet5,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction on target run function evercraft:housing/homes/row_set_active {n:5}
execute as @e[type=interaction,tag=HS.HmSet5,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction run data remove entity @s interaction

# --- [Name] rename home N (Home Deed book) ---
execute as @e[type=interaction,tag=HS.HmRen1,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction on target run function evercraft:housing/slot/rename/give_deed {n:1}
execute as @e[type=interaction,tag=HS.HmRen1,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=HS.HmRen2,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction on target run function evercraft:housing/slot/rename/give_deed {n:2}
execute as @e[type=interaction,tag=HS.HmRen2,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=HS.HmRen3,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction on target run function evercraft:housing/slot/rename/give_deed {n:3}
execute as @e[type=interaction,tag=HS.HmRen3,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=HS.HmRen4,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction on target run function evercraft:housing/slot/rename/give_deed {n:4}
execute as @e[type=interaction,tag=HS.HmRen4,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=HS.HmRen5,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction on target run function evercraft:housing/slot/rename/give_deed {n:5}
execute as @e[type=interaction,tag=HS.HmRen5,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction run data remove entity @s interaction

# --- [Move] arm relocate for home N ---
execute as @e[type=interaction,tag=HS.HmMov1,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction on target run function evercraft:housing/homes/arm_relocate {n:1}
execute as @e[type=interaction,tag=HS.HmMov1,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=HS.HmMov2,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction on target run function evercraft:housing/homes/arm_relocate {n:2}
execute as @e[type=interaction,tag=HS.HmMov2,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=HS.HmMov3,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction on target run function evercraft:housing/homes/arm_relocate {n:3}
execute as @e[type=interaction,tag=HS.HmMov3,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=HS.HmMov4,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction on target run function evercraft:housing/homes/arm_relocate {n:4}
execute as @e[type=interaction,tag=HS.HmMov4,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=HS.HmMov5,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction on target run function evercraft:housing/homes/arm_relocate {n:5}
execute as @e[type=interaction,tag=HS.HmMov5,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction run data remove entity @s interaction

# --- [Drop] abandon home N (confirm step) ---
execute as @e[type=interaction,tag=HS.HmDrop1,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction on target run function evercraft:housing/homes/abandon {n:1}
execute as @e[type=interaction,tag=HS.HmDrop1,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=HS.HmDrop2,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction on target run function evercraft:housing/homes/abandon {n:2}
execute as @e[type=interaction,tag=HS.HmDrop2,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=HS.HmDrop3,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction on target run function evercraft:housing/homes/abandon {n:3}
execute as @e[type=interaction,tag=HS.HmDrop3,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=HS.HmDrop4,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction on target run function evercraft:housing/homes/abandon {n:4}
execute as @e[type=interaction,tag=HS.HmDrop4,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=HS.HmDrop5,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction on target run function evercraft:housing/homes/abandon {n:5}
execute as @e[type=interaction,tag=HS.HmDrop5,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction run data remove entity @s interaction

# --- confirm-abandon buttons (only spawned after a [Drop] press; per-slot) ---
execute as @e[type=interaction,tag=HS.HmCf1,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction on target run function evercraft:housing/homes/confirm_abandon {n:1}
execute as @e[type=interaction,tag=HS.HmCf1,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=HS.HmCf2,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction on target run function evercraft:housing/homes/confirm_abandon {n:2}
execute as @e[type=interaction,tag=HS.HmCf2,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=HS.HmCf3,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction on target run function evercraft:housing/homes/confirm_abandon {n:3}
execute as @e[type=interaction,tag=HS.HmCf3,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=HS.HmCf4,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction on target run function evercraft:housing/homes/confirm_abandon {n:4}
execute as @e[type=interaction,tag=HS.HmCf4,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=HS.HmCf5,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction on target run function evercraft:housing/homes/confirm_abandon {n:5}
execute as @e[type=interaction,tag=HS.HmCf5,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction run data remove entity @s interaction

# --- Cancel an armed abandon ---
execute as @e[type=interaction,tag=HS.HmCancel,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction on target run function evercraft:housing/homes/cancel_abandon
execute as @e[type=interaction,tag=HS.HmCancel,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction run data remove entity @s interaction

# --- Back button ---
execute as @e[type=interaction,tag=HS.HmBackBtn,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction on target run function evercraft:housing/homes/on_back_click
execute as @e[type=interaction,tag=HS.HmBackBtn,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction run data remove entity @s interaction

# ===== INSPECT (left-click = what does this button do?) — gui/inspect pattern 2026-06-11 =====
execute as @e[type=interaction,tag=HS.HmGo1,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Travel to First Home",b:"Right-click to warp to your first claimed home (row 1). The home name is on the row label."}
execute as @e[type=interaction,tag=HS.HmGo1,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=HS.HmGo2,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Travel to Second Home",b:"Right-click to warp to your second claimed home (row 2). The home name is on the row label."}
execute as @e[type=interaction,tag=HS.HmGo2,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=HS.HmGo3,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Travel to Third Home",b:"Right-click to warp to your third claimed home (row 3). The home name is on the row label."}
execute as @e[type=interaction,tag=HS.HmGo3,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=HS.HmGo4,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Travel to Fourth Home",b:"Right-click to warp to your fourth claimed home (row 4). The home name is on the row label."}
execute as @e[type=interaction,tag=HS.HmGo4,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=HS.HmGo5,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Travel to Fifth Home",b:"Right-click to warp to your fifth claimed home (row 5). The home name is on the row label."}
execute as @e[type=interaction,tag=HS.HmGo5,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=HS.HmDrop1,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Abandon First Home",b:"Right-click to begin abandoning your first home claim (row 1) — you will be asked to confirm."}
execute as @e[type=interaction,tag=HS.HmDrop1,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=HS.HmDrop2,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Abandon Second Home",b:"Right-click to begin abandoning your second home claim (row 2) — you will be asked to confirm."}
execute as @e[type=interaction,tag=HS.HmDrop2,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=HS.HmDrop3,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Abandon Third Home",b:"Right-click to begin abandoning your third home claim (row 3) — you will be asked to confirm."}
execute as @e[type=interaction,tag=HS.HmDrop3,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=HS.HmDrop4,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Abandon Fourth Home",b:"Right-click to begin abandoning your fourth home claim (row 4) — you will be asked to confirm."}
execute as @e[type=interaction,tag=HS.HmDrop4,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=HS.HmDrop5,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Abandon Fifth Home",b:"Right-click to begin abandoning your fifth home claim (row 5) — you will be asked to confirm."}
execute as @e[type=interaction,tag=HS.HmDrop5,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=HS.HmCf1,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Confirm Abandon First Home",b:"Right-click to confirm — your first home claim (row 1) is released for good."}
execute as @e[type=interaction,tag=HS.HmCf1,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=HS.HmCf2,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Confirm Abandon Second Home",b:"Right-click to confirm — your second home claim (row 2) is released for good."}
execute as @e[type=interaction,tag=HS.HmCf2,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=HS.HmCf3,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Confirm Abandon Third Home",b:"Right-click to confirm — your third home claim (row 3) is released for good."}
execute as @e[type=interaction,tag=HS.HmCf3,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=HS.HmCf4,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Confirm Abandon Fourth Home",b:"Right-click to confirm — your fourth home claim (row 4) is released for good."}
execute as @e[type=interaction,tag=HS.HmCf4,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=HS.HmCf5,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Confirm Abandon Fifth Home",b:"Right-click to confirm — your fifth home claim (row 5) is released for good."}
execute as @e[type=interaction,tag=HS.HmCf5,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=HS.HmCancel,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Cancel",b:"Keeps the home — stops the abandon."}
execute as @e[type=interaction,tag=HS.HmCancel,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=HS.HmBackBtn,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Back",b:"Returns to the hearthstone menu."}
execute as @e[type=interaction,tag=HS.HmBackBtn,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack run data remove entity @s attack

# Catch-all (2026-06-14): clear any leftover HS-menu interaction so the unified UI-click sfx
# (housing/gui/tick) can't loop forever on an element whose tag has no handler above.
execute as @e[type=interaction,tag=HS.MenuEl,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction run data remove entity @s interaction
