# ============================================================
# Manage Homes Sub-Menu — Back button clicked
# Run as: @s = the player (called `on target` from check_clicks)
# ============================================================
execute at @s run function evercraft:housing/homes/close_homes
