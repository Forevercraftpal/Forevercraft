# ============================================================
# Manage Homes — light + arm the 5 action buttons for an OCCUPIED row
# Run as: player, at player. Macro arg: {n:<1-5>}
# refresh_row hides+disables every button first; this re-shows them only
# for occupied slots. The [Set] button is greyed (and left disabled) for the
# slot that is ALREADY active (switching to it would be a no-op).
# ============================================================

# [Go] — teleport to this home
$data modify entity @e[type=text_display,tag=HS.HmGoT$(n),distance=..7,limit=1] text set value [{text:"[",color:"dark_gray"},{text:"Go",color:"#4FC3F7"},{text:"]",color:"dark_gray"}]
$data modify entity @e[type=interaction,tag=HS.HmGo$(n),distance=..7,limit=1] response set value true

# [Name] — rename via Home Deed book
$data modify entity @e[type=text_display,tag=HS.HmRenT$(n),distance=..7,limit=1] text set value [{text:"[",color:"dark_gray"},{text:"Name",color:"#CE93D8"},{text:"]",color:"dark_gray"}]
$data modify entity @e[type=interaction,tag=HS.HmRen$(n),distance=..7,limit=1] response set value true

# [Move] — arm relocate for this slot
$data modify entity @e[type=text_display,tag=HS.HmMovT$(n),distance=..7,limit=1] text set value [{text:"[",color:"dark_gray"},{text:"Move",color:"#FFB74D"},{text:"]",color:"dark_gray"}]
$data modify entity @e[type=interaction,tag=HS.HmMov$(n),distance=..7,limit=1] response set value true

# [Drop] — abandon (confirm gate)
$data modify entity @e[type=text_display,tag=HS.HmDropT$(n),distance=..7,limit=1] text set value [{text:"[",color:"dark_gray"},{text:"Drop",color:"#EF5350"},{text:"]",color:"dark_gray"}]
$data modify entity @e[type=interaction,tag=HS.HmDrop$(n),distance=..7,limit=1] response set value true

# [Set] — set active. Lit + armed UNLESS this slot is already active.
$execute unless score @s hs.active matches $(n) run data modify entity @e[type=text_display,tag=HS.HmSetT$(n),distance=..7,limit=1] text set value [{text:"[",color:"dark_gray"},{text:"Set",color:"#FFD54F"},{text:"]",color:"dark_gray"}]
$execute unless score @s hs.active matches $(n) run data modify entity @e[type=interaction,tag=HS.HmSet$(n),distance=..7,limit=1] response set value true
# Already-active slot: show a static star marker instead of a clickable [Set]
$execute if score @s hs.active matches $(n) run data modify entity @e[type=text_display,tag=HS.HmSetT$(n),distance=..7,limit=1] text set value {text:"★",color:"gold"}
