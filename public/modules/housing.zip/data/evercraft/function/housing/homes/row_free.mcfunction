# Manage Homes — render a FREE (unlocked, empty) row label
# Run as: player. Macro arg: {n:<1-5>}
$data modify entity @e[type=text_display,tag=HS.HmRow$(n),distance=..7,limit=1] text set value [{text:"[$(n)] ",color:"dark_gray"},{text:"(empty — place a Hearthstone to claim)",color:"gray",italic:true}]
