# Manage Homes — locked row label for slot 5 (unlocks at Rank S)
data modify entity @e[type=text_display,tag=HS.HmRow5,distance=..7,limit=1] text set value [{text:"[5] ",color:"dark_gray"},{text:"🔒 ",color:"dark_gray"},{text:"Unlocks at Rank S",color:"gray",italic:true}]
