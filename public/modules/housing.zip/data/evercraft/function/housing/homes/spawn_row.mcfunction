# ============================================================
# Manage Homes — spawn one home row (label + 5 action buttons)
# Run as: player, rotated/positioned by caller (homes/open)
# Macro args:
#   n  = slot number 1-5  (baked into each button tag: HS.HmGo$(n) etc.)
#   ly = label Y offset    (e.g. "1.54")
#   by = button-row Y      (label of the action buttons)
#   iy = interaction Y     (slightly behind the button labels)
# The slot number is BAKED into the tag so homes/check_clicks dispatches
# per-slot with no macro (HS.HmGo1..5, HS.HmSet1..5, etc.).
# refresh fills the label text + greys/hides buttons for empty/locked rows.
# ============================================================

# === ROW LABEL (name + tier/dim — filled by refresh) ===
$execute rotated ~ 0 positioned ^-0.95 ^$(ly) ^1.78 run summon text_display ~ ~ ~ { brightness:{block:15,sky:15},shadow_radius:0f, Tags:["HS.MenuEl","HS.HomesEl","HS.HmRow$(n)"], billboard:"center", text:{text:"",color:"gray"}, background:0,shadow:1b, transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.27f,0.27f,0.27f]} }

# === ACTION BUTTONS (5 small text buttons in a strip) ===
# Columns: Go ^0.05 · Set ^0.45 · Name ^0.85 · Move ^1.25 · Drop ^1.65
# (relative to the panel centre; the row label sits at the far left)

# [Go]
$execute rotated ~ 0 positioned ^0.05 ^$(by) ^1.78 run summon text_display ~ ~ ~ { brightness:{block:15,sky:15},shadow_radius:0f, Tags:["HS.MenuEl","HS.HomesEl","HS.HmGoT$(n)"], billboard:"center", text:[{text:"[",color:"dark_gray"},{text:"Go",color:"#4FC3F7"},{text:"]",color:"dark_gray"}], background:1,shadow:1b, transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.22f,0.22f,0.22f]} }
$execute rotated ~ 0 positioned ^0.05 ^$(iy) ^1.8 run summon interaction ~ ~ ~ { Tags:["HS.MenuEl","HS.HomesEl","HS.HmGo$(n)"], width:0.16f,height:0.1f,response:1b }

# [Set] (set active)
$execute rotated ~ 0 positioned ^0.45 ^$(by) ^1.78 run summon text_display ~ ~ ~ { brightness:{block:15,sky:15},shadow_radius:0f, Tags:["HS.MenuEl","HS.HomesEl","HS.HmSetT$(n)"], billboard:"center", text:[{text:"[",color:"dark_gray"},{text:"Set",color:"#FFD54F"},{text:"]",color:"dark_gray"}], background:1,shadow:1b, transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.22f,0.22f,0.22f]} }
$execute rotated ~ 0 positioned ^0.45 ^$(iy) ^1.8 run summon interaction ~ ~ ~ { Tags:["HS.MenuEl","HS.HomesEl","HS.HmSet$(n)"], width:0.16f,height:0.1f,response:1b }

# [Name] (rename via Home Deed book)
$execute rotated ~ 0 positioned ^0.85 ^$(by) ^1.78 run summon text_display ~ ~ ~ { brightness:{block:15,sky:15},shadow_radius:0f, Tags:["HS.MenuEl","HS.HomesEl","HS.HmRenT$(n)"], billboard:"center", text:[{text:"[",color:"dark_gray"},{text:"Name",color:"#CE93D8"},{text:"]",color:"dark_gray"}], background:1,shadow:1b, transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.22f,0.22f,0.22f]} }
$execute rotated ~ 0 positioned ^0.85 ^$(iy) ^1.8 run summon interaction ~ ~ ~ { Tags:["HS.MenuEl","HS.HomesEl","HS.HmRen$(n)"], width:0.2f,height:0.1f,response:1b }

# [Move] (arm relocate for this slot)
$execute rotated ~ 0 positioned ^1.27 ^$(by) ^1.78 run summon text_display ~ ~ ~ { brightness:{block:15,sky:15},shadow_radius:0f, Tags:["HS.MenuEl","HS.HomesEl","HS.HmMovT$(n)"], billboard:"center", text:[{text:"[",color:"dark_gray"},{text:"Move",color:"#FFB74D"},{text:"]",color:"dark_gray"}], background:1,shadow:1b, transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.22f,0.22f,0.22f]} }
$execute rotated ~ 0 positioned ^1.27 ^$(iy) ^1.8 run summon interaction ~ ~ ~ { Tags:["HS.MenuEl","HS.HomesEl","HS.HmMov$(n)"], width:0.2f,height:0.1f,response:1b }

# [Drop] (abandon — confirm gate)
$execute rotated ~ 0 positioned ^1.67 ^$(by) ^1.78 run summon text_display ~ ~ ~ { brightness:{block:15,sky:15},shadow_radius:0f, Tags:["HS.MenuEl","HS.HomesEl","HS.HmDropT$(n)"], billboard:"center", text:[{text:"[",color:"dark_gray"},{text:"Drop",color:"#EF5350"},{text:"]",color:"dark_gray"}], background:1,shadow:1b, transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.22f,0.22f,0.22f]} }
$execute rotated ~ 0 positioned ^1.67 ^$(iy) ^1.8 run summon interaction ~ ~ ~ { Tags:["HS.MenuEl","HS.HomesEl","HS.HmDrop$(n)"], width:0.2f,height:0.1f,response:1b }
