# ============================================================
# Manage Homes — Refresh the 5 rows + slots header
# Run as: player with HS.InHomes, at player
# Reads hs.h<N>_tier / hs.h<N>_dim / hs.h<N>_gs + the guidestone-registry
# name; stars the active slot; greys locked rows with their unlock-rank text.
# One-writer: the panel only mutates state via the explicit action handlers
# (this function is display-only — it never changes hs.* slot data).
# ============================================================

# === SLOTS HEADER (occupied / unlocked) ===
execute store result storage evercraft:housing hsd.homes int 1 run scoreboard players get @s hs.homes
execute store result storage evercraft:housing hsd.slots int 1 run scoreboard players get @s hs.slots
function evercraft:housing/homes/set_slots_display with storage evercraft:housing hsd

# === PER-ROW REFRESH ===
# Each call decides: occupied (name+tier+actions) / free-unlocked / locked.
function evercraft:housing/homes/refresh_row {n:1}
function evercraft:housing/homes/refresh_row {n:2}
function evercraft:housing/homes/refresh_row {n:3}
function evercraft:housing/homes/refresh_row {n:4}
function evercraft:housing/homes/refresh_row {n:5}
