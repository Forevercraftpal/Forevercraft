# ============================================================
# Manage Homes Sub-Menu — Open (multi-home panel)
# Run as: player with HS.InMenu, at player
# Kills main menu elements, spawns the 5-row home list.
# Modeled exactly on laborers/open_laborers (own wider BG, HS.InHomes tag,
# 5 fixed list rows, Back button, session-stamped interactions).
# ============================================================

# Kill ALL main menu elements (including background — homes uses its own)
kill @e[type=text_display,tag=HS.MenuEl,distance=..7]
kill @e[type=interaction,tag=HS.MenuEl,distance=..7]
kill @e[type=item_display,tag=HS.MenuEl,distance=..7]

# Tag player as in manage-homes sub-menu
tag @s add HS.InHomes

# === BACKGROUND PANEL (wider for home list) ===
execute rotated ~ 0 positioned ^ ^1.65 ^1.8 run summon item_display ~ ~ ~ { Tags:["HS.MenuEl","HS.HomesBG","HS.HomesEl"], billboard:"center", item:{id:"black_stained_glass_pane",count:1}, item_display:"fixed", transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,-0.02f],scale:[3.6f,3.0f,0.01f]} }

# === TITLE ===
execute rotated ~ 0 positioned ^ ^2.85 ^1.78 run summon text_display ~ ~ ~ { brightness:{block:15,sky:15},shadow_radius:0f, Tags:["HS.MenuEl","HS.HomesEl"], billboard:"center", text:[{text:"⌂ ",color:"gold"},{text:"Manage Homes",color:"yellow",bold:true},{text:" ⌂",color:"gold"}], background:1,shadow:1b, transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.54f,0.54f,0.54f]} }

# === SLOTS LINE (refreshable — shows X / Y unlocked) ===
execute rotated ~ 0 positioned ^ ^2.65 ^1.78 run summon text_display ~ ~ ~ { brightness:{block:15,sky:15},shadow_radius:0f, Tags:["HS.MenuEl","HS.HomesEl","HS.HmSlots"], billboard:"center", text:{text:"Loading...",color:"gray"}, background:0,shadow:1b, transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.405f,0.405f,0.405f]} }

# === SECTION HEADER ===
execute rotated ~ 0 positioned ^ ^2.47 ^1.78 run summon text_display ~ ~ ~ { brightness:{block:15,sky:15},shadow_radius:0f, Tags:["HS.MenuEl","HS.HomesEl"], billboard:"center", text:{text:"— Your Homes —",color:"gray",italic:true}, background:0,shadow:1b, transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.338f,0.338f,0.338f]} }

# === 5 HOME ROWS ===
# Each row = a name/info label (HS.HmRow<N>) + 5 per-row action buttons.
# Row vertical anchors: 1.54 / 1.30 / 1.06 / 0.82 / 0.58
# Action buttons are placed in a horizontal strip just below each label.
# refresh greys/hides buttons for empty + locked rows; only labels show then.

# --- ROW 1 (Y 1.54) ---
function evercraft:housing/homes/spawn_row {n:1,ly:"1.54",by:"1.45",iy:"1.44"}
# --- ROW 2 (Y 1.30) ---
function evercraft:housing/homes/spawn_row {n:2,ly:"1.30",by:"1.21",iy:"1.20"}
# --- ROW 3 (Y 1.06) ---
function evercraft:housing/homes/spawn_row {n:3,ly:"1.06",by:"0.97",iy:"0.96"}
# --- ROW 4 (Y 0.82) ---
function evercraft:housing/homes/spawn_row {n:4,ly:"0.82",by:"0.73",iy:"0.72"}
# --- ROW 5 (Y 0.58) ---
function evercraft:housing/homes/spawn_row {n:5,ly:"0.58",by:"0.49",iy:"0.48"}

# === STATUS LINE (refreshable — feedback messages) ===
execute rotated ~ 0 positioned ^ ^1.07 ^1.78 run summon text_display ~ ~ ~ { brightness:{block:15,sky:15},shadow_radius:0f, Tags:["HS.MenuEl","HS.HomesEl","HS.HmStatus"], billboard:"center", text:{text:"",color:"gray"}, background:0,shadow:1b, transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.297f,0.297f,0.297f]} }

# === BACK BUTTON (centered below) ===
execute rotated ~ 0 positioned ^ ^0.9 ^1.78 run summon text_display ~ ~ ~ { brightness:{block:15,sky:15},shadow_radius:0f, Tags:["HS.MenuEl","HS.HomesEl","HS.HmBackTxt"], billboard:"center", text:[{text:"[ ",color:"dark_gray"},{text:"Back",color:"gray",bold:true},{text:" ]",color:"dark_gray"}], background:1,shadow:1b, transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.405f,0.405f,0.405f]} }
# [strip] ?: 0.4w split into 4 x 0.12 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute rotated ~ 0 positioned ^-0.14 ^0.8 ^1.8 run summon interaction ~ ~ ~ { Tags:["HS.MenuEl","HS.HomesEl","HS.HmBackBtn"], width:0.12f,height:0.12f,response:1b }
execute rotated ~ 0 positioned ^-0.0467 ^0.8 ^1.8 run summon interaction ~ ~ ~ { Tags:["HS.MenuEl","HS.HomesEl","HS.HmBackBtn"], width:0.12f,height:0.12f,response:1b }
execute rotated ~ 0 positioned ^0.0467 ^0.8 ^1.8 run summon interaction ~ ~ ~ { Tags:["HS.MenuEl","HS.HomesEl","HS.HmBackBtn"], width:0.12f,height:0.12f,response:1b }
execute rotated ~ 0 positioned ^0.14 ^0.8 ^1.8 run summon interaction ~ ~ ~ { Tags:["HS.MenuEl","HS.HomesEl","HS.HmBackBtn"], width:0.12f,height:0.12f,response:1b }

# Stamp these sub-menu interaction entities with the opening player's GUI
# session so a click can't cross-fire to a nearby player's homes menu
# (mirrors laborers/open_laborers:90-94).
scoreboard players operation #gui_stamp ec.temp = @s adv.gui_session
execute as @e[type=interaction,tag=HS.HomesEl,distance=..7] unless score @s adv.gui_session matches 1.. run scoreboard players operation @s adv.gui_session = #gui_stamp ec.temp

# Refresh to fill the rows from slot data + registry names
execute at @s run function evercraft:housing/homes/refresh

# Sound
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.4 1.0
