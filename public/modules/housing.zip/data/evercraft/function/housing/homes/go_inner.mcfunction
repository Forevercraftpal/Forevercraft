# Manage Homes — [Go] macro inner (cross-dimension tp + feedback)
# Run as: @s = the player. Macro args: dim, x, y, z.
# Mirrors artifacts/codex_tp/overworld_home_inner but dimension-aware.
$execute in $(dim) run tp @s $(x) $(y) $(z)
$data modify storage evercraft:notify stage.c set value [{text:"Hearthstone",color:"gold",bold:true},{text:" warped you to your ",color:"gray"},{text:"home",color:"green",bold:true},{text:" ($(x), $(y), $(z))",color:"green"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.enderman.teleport master @s ~ ~ ~ 1 0.8
particle minecraft:reverse_portal ~ ~1 ~ 0.5 1 0.5 0.1 25
