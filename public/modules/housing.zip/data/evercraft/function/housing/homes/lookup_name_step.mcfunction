# Manage Homes — name-lookup recursive step
# Pops rn_scan[0], copies its name into hrow.name if its id matches
# #hm_look_gs, then recurses. Stops on match or empty buffer.

execute unless data storage evercraft:housing rn_scan[0] run return 0

execute store result score #hm_scan_id hs.temp run data get storage evercraft:housing rn_scan[0].id
execute if score #hm_scan_id hs.temp = #hm_look_gs hs.temp run data modify storage evercraft:housing hrow.name set from storage evercraft:housing rn_scan[0].name
# Found it — stop (leave hrow.name set)
execute if score #hm_scan_id hs.temp = #hm_look_gs hs.temp run return 1

data remove storage evercraft:housing rn_scan[0]
function evercraft:housing/homes/lookup_name_step
