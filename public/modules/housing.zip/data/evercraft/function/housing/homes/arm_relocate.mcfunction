# ============================================================
# Manage Homes — [Move] arm a relocate for home N
# Run as: @s = the player (called `on target` from check_clicks)
# Macro arg: {n:<1-5>}
# Sets hs.reloc_n = N (Manage-Homes is the SOLE writer that arms it;
# confirm_relocate consumes + disarms it). The NEXT hearthstone the player
# places within range re-homes slot N at the new spot (confirm_relocate
# resolves target = hs.reloc_n when armed). Closes the menu.
# ============================================================

# Guard: the slot must be occupied to relocate it
$execute unless score @s hs.h$(n)_tier matches 1.. run return fail

# Arm the relocate pointer for this slot
$scoreboard players set @s hs.reloc_n $(n)

# Close the menu so the player can go place the new hearthstone
execute at @s run function evercraft:housing/gui/close

# Tell them what to do next
$data modify storage evercraft:notify stage.c set value [{text:"Relocate armed for home slot $(n). ",color:"yellow"},{text:"Place a Hearthstone",color:"green",bold:true},{text:" where you want to move it.",color:"yellow"}]
scoreboard players set #ndur ec.temp 60
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.5 1.3
