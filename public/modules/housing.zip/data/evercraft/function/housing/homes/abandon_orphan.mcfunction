# ============================================================
# Manage Homes — abandon a home whose marker wasn't loaded
# Run as: @s = the player. Macro arg: {n:<1-5>}
# If on_break found no live HS.Marker for this slot (home in an unloaded
# chunk / lost marker), clear the slot columns directly + fix the pointer so
# the GUI never shows a phantom home. Mirrors check_owner_reset's slot-side:
# clear_slot -> recount -> repoint if it was the active slot.
# The registry entry + forceload of an unloaded home are reconciled by the
# normal break path if the marker ever reloads; here we only fix the owner's
# slot bookkeeping so Manage-Homes stays truthful.
# ============================================================

# Capture whether this was the active slot before clearing
scoreboard players set #hs_orph_active hs.temp 0
$execute if score @s hs.active matches $(n) run scoreboard players set #hs_orph_active hs.temp 1

# Clear the slot columns via A's macro (cor.n is A's clear_slot dispatch key)
$data modify storage evercraft:housing cor.n set value $(n)
function evercraft:housing/slot/clear_slot with storage evercraft:housing cor

# Recount + repoint if needed
function evercraft:housing/slot/recount
execute if score #hs_orph_active hs.temp matches 1 run function evercraft:housing/slot/repoint_after_clear
