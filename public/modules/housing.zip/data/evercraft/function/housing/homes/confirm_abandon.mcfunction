# ============================================================
# Manage Homes — [Confirm Drop] abandon home N (step 2: teardown)
# Run as: @s = the player (called `on target` from check_clicks)
# Macro arg: {n:<1-5>}
# Tears down slot N's home by running the existing on_break on its marker:
#   on_break drops the lodestone loot, removes the guidestone-registry entry,
#   drops home companions, forceload-removes that home's region, kills the
#   marker, AND runs check_owner_reset per-player — which (for THIS player)
#   finds the matched slot via find_by_gs, clears its columns, recounts, and
#   (if it was the active slot) repoints active to the lowest survivor.
# We are NOT tagged HS.Relocating, so check_owner_reset DOES clear the slot.
# After the break we re-assert forceload for survivors (overlap safety).
# ============================================================

# Guard: the slot must be occupied
$execute unless score @s hs.h$(n)_tier matches 1.. run return fail

# Resolve the slot's gs_id (this is the unique key shared with the marker)
$execute store result score #hs_aband_gs hs.temp run scoreboard players get @s hs.h$(n)_gs
execute if score #hs_aband_gs hs.temp matches 0 run return fail

# Snapshot this home into the name-keyed recovery store BEFORE teardown (so a
# GUI-dropped home is recoverable too — place + rename to the same name).
# Runs while the slot is still populated; skips the default "Home". on_break's
# own check_owner_reset would re-snapshot the same record (idempotent via the
# dedupe), but doing it here also covers the unloaded-marker safety-net path
# below where on_break never runs. (AU31-Q2)
$function evercraft:housing/slot/snapshot_to_recovery {n:$(n)}

# Find the marker for this home (any dimension) and run the full break on it.
# on_break runs as the marker, at the marker — it handles the per-player slot
# clear (via check_owner_reset), registry removal, forceload remove, and
# companion drop. We must NOT be HS.Relocating here so the slot gets cleared.
execute as @e[type=marker,tag=HS.Marker,tag=!HS.Pending] if score @s ec.gs_id = #hs_aband_gs hs.temp at @s run function evercraft:housing/on_break

# Safety net: if no live marker existed (e.g. the home was in an unloaded
# chunk), clear the slot directly so the GUI doesn't show a phantom home.
$execute if score @s hs.h$(n)_tier matches 1.. run function evercraft:housing/homes/abandon_orphan {n:$(n)}

# Re-assert forceload for any surviving homes (overlap safety per spec 2.4:
# the removed region's forceload-remove could have unloaded chunks a nearby
# survivor needs; forceload_all is idempotent + cheap).
function evercraft:housing/slot/forceload_all

# Tidy the confirm buttons + refresh the panel
execute at @s run kill @e[type=interaction,tag=HS.HmConfirmEl,distance=..7]
execute at @s run kill @e[type=text_display,tag=HS.HmConfirmEl,distance=..7]
data modify entity @e[type=text_display,tag=HS.HmStatus,distance=..7,limit=1] text set value {text:"Home abandoned.",color:"green"}
execute at @s run function evercraft:housing/homes/refresh

execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.amethyst_block.break master @s ~ ~ ~ 0.6 0.7
