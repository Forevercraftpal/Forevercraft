# ============================================================
# Manage Homes — [Go] teleport to home N
# Run as: @s = the player (called `on target` from check_clicks)
# Macro arg: {n:<1-5>}
# Reuses the codex-tp idiom (stash coords -> macro inner) but feeds the
# slot's hs.h<N>_x/y/z/dim instead of the active mirror, so you can warp to
# a NON-active home directly. Per-dimension (slots may live in N/End).
# ============================================================

# Guard: the slot must be occupied
$execute unless score @s hs.h$(n)_tier matches 1.. run return fail

# Stash this slot's coords into a dedicated macro storage
$execute store result storage evercraft:housing hgo.x int 1 run scoreboard players get @s hs.h$(n)_x
$execute store result storage evercraft:housing hgo.y int 1 run scoreboard players get @s hs.h$(n)_y
$execute store result storage evercraft:housing hgo.z int 1 run scoreboard players get @s hs.h$(n)_z

# Pick the destination dimension string from hs.h<N>_dim
data modify storage evercraft:housing hgo.dim set value "minecraft:overworld"
$execute if score @s hs.h$(n)_dim matches 1 run data modify storage evercraft:housing hgo.dim set value "minecraft:the_nether"
$execute if score @s hs.h$(n)_dim matches 2 run data modify storage evercraft:housing hgo.dim set value "minecraft:the_end"

# Close the menu first so the player isn't holding an open GUI mid-warp
execute at @s run function evercraft:housing/gui/close

# Perform the cross-dimension tp + feedback via the macro inner
function evercraft:housing/homes/go_inner with storage evercraft:housing hgo
