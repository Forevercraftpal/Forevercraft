# Manage Homes — locked row label for slot 4 (unlocks at Rank A)
data modify entity @e[type=text_display,tag=HS.HmRow4,distance=..7,limit=1] text set value [{text:"[4] ",color:"dark_gray"},{text:"🔒 ",color:"dark_gray"},{text:"Unlocks at Rank A",color:"gray",italic:true}]
