# ============================================================
# Manage Homes — cancel an armed abandon
# Run as: @s = the player (called `on target` from check_clicks)
# Kills the confirm/cancel buttons + clears the status line.
# ============================================================
execute at @s run kill @e[type=interaction,tag=HS.HmConfirmEl,distance=..7]
execute at @s run kill @e[type=text_display,tag=HS.HmConfirmEl,distance=..7]
data modify entity @e[type=text_display,tag=HS.HmStatus,distance=..7,limit=1] text set value {text:"",color:"gray"}
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.hat master @s ~ ~ ~ 0.4 1.2
