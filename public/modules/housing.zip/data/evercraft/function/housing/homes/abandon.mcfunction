# ============================================================
# Manage Homes — [Drop] abandon home N (step 1: confirm prompt)
# Run as: @s = the player (called `on target` from check_clicks)
# Macro arg: {n:<1-5>}
# Abandoning is destructive (tears down the marker, registry entry, forceload
# region, home companions), so this only ARMS a confirm. A second click on
# the spawned [Confirm Drop] button (tag HS.HmCf<N>) runs confirm_abandon.
# ============================================================

# Guard: the slot must be occupied
$execute unless score @s hs.h$(n)_tier matches 1.. run return fail

# Clear any stale confirm buttons from a previous [Drop] press
kill @e[type=interaction,tag=HS.HmConfirmEl,distance=..7]
kill @e[type=text_display,tag=HS.HmConfirmEl,distance=..7]

# Status-line warning
$data modify entity @e[type=text_display,tag=HS.HmStatus,distance=..7,limit=1] text set value [{text:"Abandon home slot $(n)? This is permanent.",color:"red"}]

# Spawn the [Confirm Drop] button (per-slot tag) just above the Back button
$execute at @s rotated ~ 0 positioned ^-0.5 ^1.07 ^1.78 run summon text_display ~ ~ ~ { brightness:{block:15,sky:15},shadow_radius:0f, Tags:["HS.MenuEl","HS.HomesEl","HS.HmConfirmEl"], billboard:"center", text:[{text:"[ ",color:"dark_gray"},{text:"Confirm Drop $(n)",color:"red",bold:true},{text:" ]",color:"dark_gray"}], background:1,shadow:1b, transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.27f,0.27f,0.27f]} }
# [strip] ?: 0.5w split into 5 x 0.12 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
$execute at @s rotated ~ 0 positioned ^-0.69 ^0.99 ^1.8 run summon interaction ~ ~ ~ { Tags:["HS.MenuEl","HS.HomesEl","HS.HmConfirmEl","HS.HmCf$(n)"], width:0.12f,height:0.12f,response:1b }
$execute at @s rotated ~ 0 positioned ^-0.595 ^0.99 ^1.8 run summon interaction ~ ~ ~ { Tags:["HS.MenuEl","HS.HomesEl","HS.HmConfirmEl","HS.HmCf$(n)"], width:0.12f,height:0.12f,response:1b }
$execute at @s rotated ~ 0 positioned ^-0.5 ^0.99 ^1.8 run summon interaction ~ ~ ~ { Tags:["HS.MenuEl","HS.HomesEl","HS.HmConfirmEl","HS.HmCf$(n)"], width:0.12f,height:0.12f,response:1b }
$execute at @s rotated ~ 0 positioned ^-0.405 ^0.99 ^1.8 run summon interaction ~ ~ ~ { Tags:["HS.MenuEl","HS.HomesEl","HS.HmConfirmEl","HS.HmCf$(n)"], width:0.12f,height:0.12f,response:1b }
$execute at @s rotated ~ 0 positioned ^-0.31 ^0.99 ^1.8 run summon interaction ~ ~ ~ { Tags:["HS.MenuEl","HS.HomesEl","HS.HmConfirmEl","HS.HmCf$(n)"], width:0.12f,height:0.12f,response:1b }

# Spawn a [Cancel] button beside it
execute at @s rotated ~ 0 positioned ^0.5 ^1.07 ^1.78 run summon text_display ~ ~ ~ { brightness:{block:15,sky:15},shadow_radius:0f, Tags:["HS.MenuEl","HS.HomesEl","HS.HmConfirmEl"], billboard:"center", text:[{text:"[ ",color:"dark_gray"},{text:"Cancel",color:"gray",bold:true},{text:" ]",color:"dark_gray"}], background:1,shadow:1b, transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.27f,0.27f,0.27f]} }
# [strip] ?: 0.4w split into 4 x 0.12 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute at @s rotated ~ 0 positioned ^0.36 ^0.99 ^1.8 run summon interaction ~ ~ ~ { Tags:["HS.MenuEl","HS.HomesEl","HS.HmConfirmEl","HS.HmCancel"], width:0.12f,height:0.12f,response:1b }
execute at @s rotated ~ 0 positioned ^0.4533 ^0.99 ^1.8 run summon interaction ~ ~ ~ { Tags:["HS.MenuEl","HS.HomesEl","HS.HmConfirmEl","HS.HmCancel"], width:0.12f,height:0.12f,response:1b }
execute at @s rotated ~ 0 positioned ^0.5467 ^0.99 ^1.8 run summon interaction ~ ~ ~ { Tags:["HS.MenuEl","HS.HomesEl","HS.HmConfirmEl","HS.HmCancel"], width:0.12f,height:0.12f,response:1b }
execute at @s rotated ~ 0 positioned ^0.64 ^0.99 ^1.8 run summon interaction ~ ~ ~ { Tags:["HS.MenuEl","HS.HomesEl","HS.HmConfirmEl","HS.HmCancel"], width:0.12f,height:0.12f,response:1b }

# Session-stamp the freshly spawned confirm/cancel entities so they belong
# to THIS player's GUI session (mirrors homes/open stamping).
scoreboard players operation #gui_stamp ec.temp = @s adv.gui_session
execute as @e[type=interaction,tag=HS.HmConfirmEl,distance=..7] unless score @s adv.gui_session matches 1.. run scoreboard players operation @s adv.gui_session = #gui_stamp ec.temp

execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.hat master @s ~ ~ ~ 0.5 0.8
