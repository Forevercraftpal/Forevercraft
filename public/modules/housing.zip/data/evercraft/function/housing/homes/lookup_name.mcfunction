# ============================================================
# Manage Homes — look up a home's display name by gs_id
# Run as: player. INPUT: #hm_look_gs hs.temp = the gs_id to find.
# OUTPUT: storage evercraft:housing hrow.name = the registry name string
#         (defaults to "Home" if the entry has no name / isn't found).
# Iterates a COPY of the guidestone registry in evercraft:housing rn_scan
# so it never disturbs guidestone's own working/temp_registry storage.
# Cold path (GUI refresh only) — recursion over <= a few dozen entries.
# ============================================================

# Default name
data modify storage evercraft:housing hrow.name set value "Home"

# Never match gs_id 0 (empty slot sentinel)
execute if score #hm_look_gs hs.temp matches 0 run return 0

# Snapshot the registry into our own scan buffer
data modify storage evercraft:housing rn_scan set from storage evercraft:guidestone registry

# Walk it
function evercraft:housing/homes/lookup_name_step
