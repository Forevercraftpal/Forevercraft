# Manage Homes — locked row label for slot 3 (unlocks at Rank C)
data modify entity @e[type=text_display,tag=HS.HmRow3,distance=..7,limit=1] text set value [{text:"[3] ",color:"dark_gray"},{text:"🔒 ",color:"dark_gray"},{text:"Unlocks at Rank C",color:"gray",italic:true}]
