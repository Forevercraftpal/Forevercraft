# Manage Homes — render an occupied row label (macro)
# Macro args: n (slot), star ("★ " or ""), name (home name string), tier, dim
# Targets HS.HmRow<n>. Name comes from the guidestone registry.
$data modify entity @e[type=text_display,tag=HS.HmRow$(n),distance=..7,limit=1] text set value [{text:"$(star)",color:"gold"},{text:"[$(n)] ",color:"dark_gray"},{text:"«$(name)»",color:"white"},{text:"  T$(tier)",color:"aqua"},{text:" · $(dim)",color:"gray"}]
