# Manage Homes — locked row label for slot 2 (unlocks at Rank E)
data modify entity @e[type=text_display,tag=HS.HmRow2,distance=..7,limit=1] text set value [{text:"[2] ",color:"dark_gray"},{text:"🔒 ",color:"dark_gray"},{text:"Unlocks at Rank E",color:"gray",italic:true}]
