# Manage Homes — slots header line (macro)
# Macro args: homes (occupied count), slots (unlocked count)
$data modify entity @e[type=text_display,tag=HS.HmSlots,distance=..7,limit=1] text set value [{text:"Slots: ",color:"gray"},{text:"$(homes)",color:"yellow"},{text:" / ",color:"gray"},{text:"$(slots)",color:"green"},{text:" unlocked",color:"gray"}]
