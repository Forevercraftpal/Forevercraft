# ============================================================
# Manage Homes — refresh ONE row (label + button visibility)
# Run as: player with HS.InHomes, at player
# Macro arg: {n:<1-5>}
# States:
#   OCCUPIED  (hs.h<N>_tier>=1) -> name + tier + dim, star if active, buttons lit
#   FREE      (tier==0, N<=hs.slots) -> "(empty — place a Hearthstone)", buttons hidden
#   LOCKED    (N>hs.slots) -> lock + unlock-rank text, buttons hidden
# Reads the home's display name from the guidestone registry `name` field
# (single source of truth; no second storage list).
# ============================================================

$execute store result score #hm_n hs.temp run scoreboard players get @s hs.h$(n)_tier

# --- branch on state ---
# OCCUPIED
$execute if score #hm_n hs.temp matches 1.. run function evercraft:housing/homes/row_occupied {n:$(n)}
# FREE (unlocked, empty)
$execute if score #hm_n hs.temp matches 0 if score @s hs.slots matches $(n).. run function evercraft:housing/homes/row_free {n:$(n)}
# LOCKED — render with this slot's unlock-rank text (E/C/A/S per confirmed
# thresholds; slot 1 is always unlocked so never reaches here). One tiny
# file per slot keeps the rank label static (no macro-rank gymnastics).
$execute if score #hm_n hs.temp matches 0 unless score @s hs.slots matches $(n).. run function evercraft:housing/homes/locked_row_$(n)

# Hide ALL action buttons by default (occupied path re-shows them)
$data modify entity @e[type=text_display,tag=HS.HmGoT$(n),distance=..7,limit=1] text set value {text:"",color:"gray"}
$data modify entity @e[type=text_display,tag=HS.HmSetT$(n),distance=..7,limit=1] text set value {text:"",color:"gray"}
$data modify entity @e[type=text_display,tag=HS.HmRenT$(n),distance=..7,limit=1] text set value {text:"",color:"gray"}
$data modify entity @e[type=text_display,tag=HS.HmMovT$(n),distance=..7,limit=1] text set value {text:"",color:"gray"}
$data modify entity @e[type=text_display,tag=HS.HmDropT$(n),distance=..7,limit=1] text set value {text:"",color:"gray"}
$data modify entity @e[type=interaction,tag=HS.HmGo$(n),distance=..7,limit=1] response set value false
$data modify entity @e[type=interaction,tag=HS.HmSet$(n),distance=..7,limit=1] response set value false
$data modify entity @e[type=interaction,tag=HS.HmRen$(n),distance=..7,limit=1] response set value false
$data modify entity @e[type=interaction,tag=HS.HmMov$(n),distance=..7,limit=1] response set value false
$data modify entity @e[type=interaction,tag=HS.HmDrop$(n),distance=..7,limit=1] response set value false

# Re-light + re-arm the buttons only for OCCUPIED rows
$execute if score #hm_n hs.temp matches 1.. run function evercraft:housing/homes/row_buttons_on {n:$(n)}
