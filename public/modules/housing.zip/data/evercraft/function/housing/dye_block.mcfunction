# Hearthstone — Dye Block (right-click with dye)
# Run as: the interaction entity, at its position
# Called from on_interact when player holds a dye


# Detect which dye the player is holding
execute as @p[distance=..6] run function evercraft:dyeing/detect_color

# Azure
execute if data storage evercraft:dyeing {color_id:"azure"} as @e[type=marker,tag=HS.Marker,distance=..2,limit=1] run data modify entity @s data.color set value "hearthstone_azure"
execute if data storage evercraft:dyeing {color_id:"azure"} as @e[type=armor_stand,tag=HS.Stand,distance=..2,limit=1] on passengers run data modify entity @s item.components."minecraft:profile".properties[0].value set value "ewogICJ0aW1lc3RhbXAiIDogMTc3NDM2OTI5ODg3MCwKICAicHJvZmlsZUlkIiA6ICJkODBlMGYyNjU2M2U0NzI3YWNiZDNlMmRlNDkxYzFiZSIsCiAgInByb2ZpbGVOYW1lIiA6ICJMZXZfSXMiLAogICJzaWduYXR1cmVSZXF1aXJlZCIgOiB0cnVlLAogICJ0ZXh0dXJlcyIgOiB7CiAgICAiU0tJTiIgOiB7CiAgICAgICJ1cmwiIDogImh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvMWU5N2VhMjVkN2MxMzMzNzZkYjMwMzVlMDg5NzM4ZDU5ODliNWI1MmJmN2Y2Y2ExZDA5OTNjMTQ0M2Q2ZmVmYSIsCiAgICAgICJtZXRhZGF0YSIgOiB7CiAgICAgICAgIm1vZGVsIiA6ICJzbGltIgogICAgICB9CiAgICB9CiAgfQp9"

# Crimson
execute if data storage evercraft:dyeing {color_id:"crimson"} as @e[type=marker,tag=HS.Marker,distance=..2,limit=1] run data modify entity @s data.color set value "hearthstone_crimson"
execute if data storage evercraft:dyeing {color_id:"crimson"} as @e[type=armor_stand,tag=HS.Stand,distance=..2,limit=1] on passengers run data modify entity @s item.components."minecraft:profile".properties[0].value set value "ewogICJ0aW1lc3RhbXAiIDogMTc3NDM2OTMxMTIwNCwKICAicHJvZmlsZUlkIiA6ICIxN2I5ZDBmOWYxYzE0OTE5ODRkY2Y5ZGM2YzczZDYzYyIsCiAgInByb2ZpbGVOYW1lIiA6ICJuYWJlNDk3NSIsCiAgInNpZ25hdHVyZVJlcXVpcmVkIiA6IHRydWUsCiAgInRleHR1cmVzIiA6IHsKICAgICJTS0lOIiA6IHsKICAgICAgInVybCIgOiAiaHR0cDovL3RleHR1cmVzLm1pbmVjcmFmdC5uZXQvdGV4dHVyZS9mZTUxNGVlMDgxMjQ4YWQ0Y2I1Y2MxOWYxZTBjNmNkM2NiZjk2NDVkYjg1NDdkMTUzOWUyMWY0Yzc5YzhlOGIxIiwKICAgICAgIm1ldGFkYXRhIiA6IHsKICAgICAgICAibW9kZWwiIDogInNsaW0iCiAgICAgIH0KICAgIH0KICB9Cn0="

# Solar
execute if data storage evercraft:dyeing {color_id:"solar"} as @e[type=marker,tag=HS.Marker,distance=..2,limit=1] run data modify entity @s data.color set value "hearthstone_solar"
execute if data storage evercraft:dyeing {color_id:"solar"} as @e[type=armor_stand,tag=HS.Stand,distance=..2,limit=1] on passengers run data modify entity @s item.components."minecraft:profile".properties[0].value set value "ewogICJ0aW1lc3RhbXAiIDogMTc3NDM2OTMyMzk1OSwKICAicHJvZmlsZUlkIiA6ICJiMGQ0YjI4YmMxZDc0ODg5YWYwZTg2NjFjZWU5NmFhYiIsCiAgInByb2ZpbGVOYW1lIiA6ICJNaW5lU2tpbl9vcmciLAogICJzaWduYXR1cmVSZXF1aXJlZCIgOiB0cnVlLAogICJ0ZXh0dXJlcyIgOiB7CiAgICAiU0tJTiIgOiB7CiAgICAgICJ1cmwiIDogImh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvNTVlZDE1ZDExNzQ0NjFiZDIzZTZiODI0MGRkYzNkOGE5M2IwZTViMTAwZDM2YmMxODc1NmEzNzVlZTA1YTUwZiIsCiAgICAgICJtZXRhZGF0YSIgOiB7CiAgICAgICAgIm1vZGVsIiA6ICJzbGltIgogICAgICB9CiAgICB9CiAgfQp9"

# Verdant
execute if data storage evercraft:dyeing {color_id:"verdant"} as @e[type=marker,tag=HS.Marker,distance=..2,limit=1] run data modify entity @s data.color set value "hearthstone_verdant"
execute if data storage evercraft:dyeing {color_id:"verdant"} as @e[type=armor_stand,tag=HS.Stand,distance=..2,limit=1] on passengers run data modify entity @s item.components."minecraft:profile".properties[0].value set value "ewogICJ0aW1lc3RhbXAiIDogMTc3NDM2OTMyOTk4MiwKICAicHJvZmlsZUlkIiA6ICI2NDEwZjRiZjMwNDU0OTdmODBjZDI4NWIyYmJiNTk5NSIsCiAgInByb2ZpbGVOYW1lIiA6ICJNaW5lU2tpbl8xNSIsCiAgInNpZ25hdHVyZVJlcXVpcmVkIiA6IHRydWUsCiAgInRleHR1cmVzIiA6IHsKICAgICJTS0lOIiA6IHsKICAgICAgInVybCIgOiAiaHR0cDovL3RleHR1cmVzLm1pbmVjcmFmdC5uZXQvdGV4dHVyZS9kMmQ0YmM3YWI0OGZiNjA4ZjI0M2NiYThjMGI3NTg5NmI0MGYzYWFjMmFlOWMzYzk1NTE5M2RkMDljODcxZDBjIiwKICAgICAgIm1ldGFkYXRhIiA6IHsKICAgICAgICAibW9kZWwiIDogInNsaW0iCiAgICAgIH0KICAgIH0KICB9Cn0="

# Ivory
execute if data storage evercraft:dyeing {color_id:"ivory"} as @e[type=marker,tag=HS.Marker,distance=..2,limit=1] run data modify entity @s data.color set value "hearthstone_ivory"
execute if data storage evercraft:dyeing {color_id:"ivory"} as @e[type=armor_stand,tag=HS.Stand,distance=..2,limit=1] on passengers run data modify entity @s item.components."minecraft:profile".properties[0].value set value "ewogICJ0aW1lc3RhbXAiIDogMTc3NDM2OTM0MTE5MywKICAicHJvZmlsZUlkIiA6ICJkNGUwNTFjZGRhNDU0NTUxYjk1ZWRiZjdkNTM1ZTA3ZSIsCiAgInByb2ZpbGVOYW1lIiA6ICJFbGVtZW50YWxfTWF4IiwKICAic2lnbmF0dXJlUmVxdWlyZWQiIDogdHJ1ZSwKICAidGV4dHVyZXMiIDogewogICAgIlNLSU4iIDogewogICAgICAidXJsIiA6ICJodHRwOi8vdGV4dHVyZXMubWluZWNyYWZ0Lm5ldC90ZXh0dXJlLzg5M2VmMmQ0YTZiNzQ3OWFmMmU1N2RmOWUwMjFiYTBjODJhYzEzZDM5ODBlNTNmOTNhNjYzOTAxZDJlMDgzY2IiLAogICAgICAibWV0YWRhdGEiIDogewogICAgICAgICJtb2RlbCIgOiAic2xpbSIKICAgICAgfQogICAgfQogIH0KfQ=="

# Obsidian
execute if data storage evercraft:dyeing {color_id:"obsidian"} as @e[type=marker,tag=HS.Marker,distance=..2,limit=1] run data modify entity @s data.color set value "hearthstone_obsidian"
execute if data storage evercraft:dyeing {color_id:"obsidian"} as @e[type=armor_stand,tag=HS.Stand,distance=..2,limit=1] on passengers run data modify entity @s item.components."minecraft:profile".properties[0].value set value "ewogICJ0aW1lc3RhbXAiIDogMTc3NDM2OTM1Mjg0NCwKICAicHJvZmlsZUlkIiA6ICJkMTNmODljZmRiMmY0OTUxOWE4YjgxMTUzN2FmZWU2ZSIsCiAgInByb2ZpbGVOYW1lIiA6ICJ2ZXhsZWhhaGEiLAogICJzaWduYXR1cmVSZXF1aXJlZCIgOiB0cnVlLAogICJ0ZXh0dXJlcyIgOiB7CiAgICAiU0tJTiIgOiB7CiAgICAgICJ1cmwiIDogImh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvYjQ0MDc3NTM0MTg4YmY3YzgwZWI2ODEwNjQzMmE1MjhhZGY0NDcyOGNlNGFjNzczZGI5NTUyMzgyMmY1ODg4ZCIsCiAgICAgICJtZXRhZGF0YSIgOiB7CiAgICAgICAgIm1vZGVsIiA6ICJzbGltIgogICAgICB9CiAgICB9CiAgfQp9"

# Rose
execute if data storage evercraft:dyeing {color_id:"rose"} as @e[type=marker,tag=HS.Marker,distance=..2,limit=1] run data modify entity @s data.color set value "hearthstone_rose"
execute if data storage evercraft:dyeing {color_id:"rose"} as @e[type=armor_stand,tag=HS.Stand,distance=..2,limit=1] on passengers run data modify entity @s item.components."minecraft:profile".properties[0].value set value "ewogICJ0aW1lc3RhbXAiIDogMTc3NDM2OTM2NTE2MywKICAicHJvZmlsZUlkIiA6ICI2NGY0MGFiNzFmM2E0NGZiYjg0N2I5ZWFhOWZjNDRlNSIsCiAgInByb2ZpbGVOYW1lIiA6ICJvZGF2aWRjZXNhciIsCiAgInNpZ25hdHVyZVJlcXVpcmVkIiA6IHRydWUsCiAgInRleHR1cmVzIiA6IHsKICAgICJTS0lOIiA6IHsKICAgICAgInVybCIgOiAiaHR0cDovL3RleHR1cmVzLm1pbmVjcmFmdC5uZXQvdGV4dHVyZS80MWYxNmU2OWFkZDYyMmQ1MDFmYjhmNGQyYmE0Y2YxMmVhNzQ1YTJmNjRiNTgxNzg1YTY1YzQ3N2RjYjE5YWQiLAogICAgICAibWV0YWRhdGEiIDogewogICAgICAgICJtb2RlbCIgOiAic2xpbSIKICAgICAgfQogICAgfQogIH0KfQ=="

# Noir
execute if data storage evercraft:dyeing {color_id:"noir"} as @e[type=marker,tag=HS.Marker,distance=..2,limit=1] run data modify entity @s data.color set value "hearthstone_noir"
execute if data storage evercraft:dyeing {color_id:"noir"} as @e[type=armor_stand,tag=HS.Stand,distance=..2,limit=1] on passengers run data modify entity @s item.components."minecraft:profile".properties[0].value set value "ewogICJ0aW1lc3RhbXAiIDogMTc3NDM2OTM3NjU2NiwKICAicHJvZmlsZUlkIiA6ICI0MDU4NDhjMmJjNTE0ZDhkOThkOTJkMGIwYzhiZDQ0YiIsCiAgInByb2ZpbGVOYW1lIiA6ICJMaWFtX1NhZ2UiLAogICJzaWduYXR1cmVSZXF1aXJlZCIgOiB0cnVlLAogICJ0ZXh0dXJlcyIgOiB7CiAgICAiU0tJTiIgOiB7CiAgICAgICJ1cmwiIDogImh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvNmVjZDgxYzY3ZmNiMDk5YzY2ZDc1MmMxMjUxNjgzNWUyNzE2ZjQ2M2M5YjcwNDJhZGQxNzU3OWE0OTRhNjVlZCIsCiAgICAgICJtZXRhZGF0YSIgOiB7CiAgICAgICAgIm1vZGVsIiA6ICJzbGltIgogICAgICB9CiAgICB9CiAgfQp9"

# Consume 1 dye from player's hand
execute as @p[distance=..6] run item modify entity @s weapon.mainhand {"function":"minecraft:set_count","count":-1,"add":true}

# Effects
function evercraft:dyeing/effects

# Feedback
data modify storage evercraft:notify stage.c set value [{text:"Dyed ",color:"gray",italic:true},{storage:"evercraft:dyeing",nbt:"color_name",interpret:false,color:"#E0B0FF",italic:true},{text:" Hearthstone",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 45
execute as @p[distance=..6] run function evercraft:util/notify/emit
