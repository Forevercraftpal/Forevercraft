# ============================================================
# Housing Zone — Best-Friend comfort sharing (entry)
# Run as: homeowner with hs.tier >= 1, at homeowner. Called every 2s from tick_player.
#
# A homeowner's Best Friends (90+ hearts) receive the home's tier comfort buffs
# (Regen / Saturation / Resistance / Fire Res, scaled to the host's home tier)
# while standing inside any of the owner's home zones (64-block box, per slot).
# The host must be ONLINE (this is an owner-driven scan, like the visitor system).
#
# Toggle: hs.guest_share — 1 = REVOKED (off), 0/absent = ON (default).
# ============================================================

# Owner revoked sharing? Skip.
execute if score @s hs.guest_share matches 1 run return 0

# Exclude self from the guest scan, then only proceed if another player is online at all.
tag @s add hs.owner_check
execute if entity @a[tag=!hs.owner_check,limit=1] run function evercraft:housing/zone/guest_comfort_inner
tag @s remove hs.owner_check
