# Housing Zone — Macro: is the guest inside slot <n>'s 64-block home box?
# Run as: candidate guest (@s). Macro args: n (1-5)   (from {n:"<slot>"})
# Context: #hs_g{x,y,z,d} = guest pos/dim; #hs_s<n>{x,y,z,d,t} = host slot box.
# On a hit, raises #hs_gbest to this slot's tier (keeps the largest = best comfort).

# Dimension must match.
$execute unless score #hs_gd hs.temp = #hs_s$(n)d hs.temp run return 0

# |dx| <= 64
scoreboard players operation #hs_dx hs.temp = #hs_gx hs.temp
$scoreboard players operation #hs_dx hs.temp -= #hs_s$(n)x hs.temp
execute if score #hs_dx hs.temp matches ..-1 run scoreboard players operation #hs_dx hs.temp *= #-1 ec.const
execute unless score #hs_dx hs.temp matches ..64 run return 0

# |dy| <= 64
scoreboard players operation #hs_dy hs.temp = #hs_gy hs.temp
$scoreboard players operation #hs_dy hs.temp -= #hs_s$(n)y hs.temp
execute if score #hs_dy hs.temp matches ..-1 run scoreboard players operation #hs_dy hs.temp *= #-1 ec.const
execute unless score #hs_dy hs.temp matches ..64 run return 0

# |dz| <= 64
scoreboard players operation #hs_dz hs.temp = #hs_gz hs.temp
$scoreboard players operation #hs_dz hs.temp -= #hs_s$(n)z hs.temp
execute if score #hs_dz hs.temp matches ..-1 run scoreboard players operation #hs_dz hs.temp *= #-1 ec.const
execute unless score #hs_dz hs.temp matches ..64 run return 0

# Inside this home box -> remember its tier if it beats the best so far.
$execute if score #hs_s$(n)t hs.temp > #hs_gbest hs.temp run scoreboard players operation #hs_gbest hs.temp = #hs_s$(n)t hs.temp
