# ============================================================
# Protection toggle — mirror ONE slot's prot flag onto its marker (macro)
# Run as: @s = the owner
# Macro arg: storage evercraft:housing flt = {n:<1-5>}
#   Reads hs.h<n>_prot / hs.h<n>_gs.
# Finds the marker whose ec.gs_id == this slot's gs and stamps data.protect
# (1=protected, 0=off) so the hearthstone-restore guard (tick_marker) works
# even while the owner is offline. Mirrors the original single-home write,
# but keyed by the CLICKED slot's gs rather than the active mirror's gs.
# ============================================================

$scoreboard players operation #hp_owner_gs hs.temp = @s hs.h$(n)_gs
$scoreboard players operation #hp_owner_protect hs.temp = @s hs.h$(n)_prot
execute as @e[type=marker,tag=HS.Marker] if score @s ec.gs_id = #hp_owner_gs hs.temp store result entity @s data.protect int 1 run scoreboard players get #hp_owner_protect hs.temp
