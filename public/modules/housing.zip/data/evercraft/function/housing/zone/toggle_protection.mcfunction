# ============================================================
# Housing Zone Protection — Toggle (Wiring Audit #27 Q1, Joseph) · MULTI-HOME
# Run as: the owner (sneak-right-clicked their own hearthstone, verified in on_interact)
# Cycles: Off → Guarded (Mining Fatigue) → Reinforced (Fatigue + Slowness) → Off
#   prot 0=off/1=on · pmode 2=Guarded / 1=Reinforced
#
# MULTI-HOME: the player may have sneak-clicked ANY of their 5 homes, so we
# toggle THAT home's slot columns (hs.h<N>_prot / hs.h<N>_pmode), not the active
# mirror. on_interact passed the clicked marker's gs in #hs_find_gs; resolve the
# slot via find_by_gs, write the slot via the {n} macro, mirror to the marker,
# and (only if the clicked home is the active one) refresh the active mirror so
# the live hs.protect/hs.protect_mode readers stay correct.
# ============================================================

# Resolve which slot the clicked hearthstone is (re-run find_by_gs; #hs_find_gs
# is still the clicked marker's gs, set by on_interact). Bail if no match.
function evercraft:housing/slot/find_by_gs
execute if score #hs_find_slot hs.temp matches 0 run return fail

# Compute + apply the next state into THIS slot's columns (macro on slot N)
execute store result storage evercraft:housing flt.n int 1 run scoreboard players get #hs_find_slot hs.temp
function evercraft:housing/zone/toggle_protection_slot with storage evercraft:housing flt

# If the toggled home is the ACTIVE one, refresh the mirror from it (load_active
# is the sole mirror writer) so hs.protect / hs.protect_mode reflect the change.
execute if score @s hs.active = #hs_find_slot hs.temp run function evercraft:housing/slot/load_active

# Mirror the on/off state onto THIS home's marker (matched by the clicked gs) so
# the hearthstone-restore guard (tick_marker) works even while the owner is
# offline. 1 = protected (Guarded or Reinforced), 0 = off. Read prot from the slot.
execute store result storage evercraft:housing flt.n int 1 run scoreboard players get #hs_find_slot hs.temp
function evercraft:housing/zone/toggle_protection_mark with storage evercraft:housing flt

# Feedback (reads #hp_next set by toggle_protection_slot)
data modify storage evercraft:notify stage.c set value [{text:"Protection: ",color:"gray"},{text:"Guarded",color:"yellow"},{text:" — non-owners get Mining Fatigue in your zone.",color:"gray"}]
scoreboard players set #ndur ec.temp 45
execute if score #hp_next hs.temp matches 1 run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Protection: ",color:"gray"},{text:"Reinforced",color:"aqua"},{text:" — non-owners are fully slowed + cannot mine in your zone.",color:"gray"}]
scoreboard players set #ndur ec.temp 45
execute if score #hp_next hs.temp matches 2 run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Protection: ",color:"red"},{text:"Off",color:"gray"},{text:".",color:"gray"}]
scoreboard players set #ndur ec.temp 45
execute if score #hp_next hs.temp matches 3 run function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.6 1.4
execute at @s run particle minecraft:enchant ~ ~1 ~ 0.4 0.5 0.4 0.3 12
