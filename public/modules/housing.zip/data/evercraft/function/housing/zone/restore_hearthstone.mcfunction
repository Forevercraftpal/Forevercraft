# ============================================================
# Restore a PROTECTED hearthstone's lodestone (Wiring Audit #27 Q2, Joseph).
# Run as: the HS.Marker, at the marker. Called from tick_marker when the lodestone is gone
# AND this home is protected (marker data.protect == 1).
# True owner-only-break: non-owners (Mining-Fatigue-blocked anyway), explosions, pistons, and
# instabreak edge-cases can't destroy a protected hearthstone. To remove it, the OWNER turns
# protection off (sneak-use the hearthstone to cycle to Off), then breaks it normally.
# ============================================================

# Put the lodestone back (the display/interaction/marker entities were never torn down)
setblock ~ ~ ~ minecraft:lodestone

# Confiscate the dropped lodestone from the break so it can't be kept
kill @e[type=item,distance=..3,nbt={Item:{id:"minecraft:lodestone"}}]

# Tell whoever is closest (likely the breaker) how to actually remove it
data modify storage evercraft:notify stage.c set value [{text:"This Hearthstone is protected and cannot be broken. The owner can sneak-use it to turn protection off, then remove it.",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 45
execute as @a[distance=..6,limit=1,sort=nearest] run function evercraft:util/notify/emit
playsound minecraft:block.amethyst_block.place master @a[distance=..16,scores={ec.fx_snd=1..}] ~ ~ ~ 0.6 1.0
execute at @s run particle minecraft:enchant ~ ~1 ~ 0.3 0.5 0.3 0.4 15
