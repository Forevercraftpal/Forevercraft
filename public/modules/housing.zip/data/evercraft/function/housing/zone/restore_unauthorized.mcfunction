# ============================================================
# Hearthstone — revert an UNAUTHORIZED break (AU31-Q2, model β)
# Run as: @s = the HS.Marker, at the marker. Called from check_break_allow
# when the lodestone is gone but neither the owner nor an admin is present —
# i.e. a non-owner griefer broke it, or a non-player removal (TNT / creeper /
# piston / setblock / wither / instabreak) happened with the owner away.
# Mirrors zone/restore_hearthstone (the proven protected-home rail) but with
# the ownership-specific copy. The home's data is untouched (marker / display
# / interaction were never torn down), so nothing leaks.
# ============================================================

# Put the lodestone back (display / interaction / marker were never removed).
setblock ~ ~ ~ minecraft:lodestone

# Confiscate the dropped lodestone so the break can't be kept.
kill @e[type=item,distance=..3,nbt={Item:{id:"minecraft:lodestone"}}]

# Tell whoever is closest (likely the breaker) why it reverted.
data modify storage evercraft:notify stage.c set value [{text:"This Hearthstone belongs to another settler. Only its owner can take it up.",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 50
execute as @a[distance=..6,limit=1,sort=nearest] run function evercraft:util/notify/emit
playsound minecraft:block.amethyst_block.place master @a[distance=..16,scores={ec.fx_snd=1..}] ~ ~ ~ 0.6 1.0
execute at @s run particle minecraft:enchant ~ ~1 ~ 0.3 0.5 0.3 0.4 15
