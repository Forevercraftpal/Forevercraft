# Housing Visitor Leave Check — Remove visiting tag if not near any home
# @s = player with hs.visiting tag, at player position

# Store visitor position (OPT: uses cached ec.pos_x/y/z from movement/detect)
scoreboard players operation #hs_vis_x hs.temp = @s ec.pos_x
scoreboard players operation #hs_vis_y hs.temp = @s ec.pos_y
scoreboard players operation #hs_vis_z hs.temp = @s ec.pos_z
scoreboard players set #hs_vis_dim hs.temp 0
execute if dimension minecraft:the_nether run scoreboard players set #hs_vis_dim hs.temp 1
execute if dimension minecraft:the_end run scoreboard players set #hs_vis_dim hs.temp 2

scoreboard players set #hs_near_any hs.temp 0

# Check distance to every homeowner (skip self)
tag @s add hs.vis_self
execute as @a[scores={hs.tier=1..},tag=!hs.vis_self] run function evercraft:housing/zone/visitor_proximity
tag @s remove hs.vis_self

# If not near any home, remove visiting tag and protection effects
execute if score #hs_near_any hs.temp matches 0 run tag @s remove hs.visiting
execute if score #hs_near_any hs.temp matches 0 if entity @s[tag=hs.in_protected] run effect clear @s minecraft:mining_fatigue
execute if score #hs_near_any hs.temp matches 0 run tag @s remove hs.in_protected
execute if score #hs_near_any hs.temp matches 0 run scoreboard players set @s hs.protect_warned 0
# Best-Friend comfort: drop the welcome dedupe so a future visit greets again (buffs self-expire).
execute if score #hs_near_any hs.temp matches 0 run tag @s remove hs.guest_welcomed
