# ============================================================
# Housing Zone — Best-Friend comfort: grant a welcomed guest the home's comforts
# Run as: the guest (@s). Context: #hs_gbest hs.temp = host's home tier (1-5).
# Mirrors the owner's apply_buffs potion package, scaled to the host tier. The owner's
# tier-3/4 DR (a luck attribute modifier, lifecycle-managed on enter/leave) is translated
# here to a self-expiring Resistance so a guest who logs out mid-visit never strands a
# modifier. All effects: 5s, hidden particles, refreshed every 2s while in the zone.
# ============================================================

# Tier 1+: Regeneration I
execute if score #hs_gbest hs.temp matches 1.. run effect give @s regeneration 5 0 true
# Tier 2+: Saturation I
execute if score #hs_gbest hs.temp matches 2.. run effect give @s saturation 5 0 true
# Tier 3-4: Resistance I  (guest analog of the owner's DR +0.5)
execute if score #hs_gbest hs.temp matches 3..4 run effect give @s resistance 5 0 true
# Tier 4+: Fire Resistance
execute if score #hs_gbest hs.temp matches 4.. run effect give @s fire_resistance 5 0 true
# Tier 5: Resistance II  (guest analog of the owner's DR +1.0 + Resistance I)
execute if score #hs_gbest hs.temp matches 5 run effect give @s resistance 5 1 true

# One-time welcome message per visit (cleared on leave by guest_check_player / visitor_leave_check).
execute unless entity @s[tag=hs.guest_welcomed] run function evercraft:housing/zone/guest_welcome
tag @s add hs.guest_welcomed
