# ============================================================
# Protection toggle — cycle ONE slot's protection state (multi-home macro)
# Run as: @s = the owner
# Macro arg: storage evercraft:housing flt = {n:<1-5>}
#   Reads + writes hs.h<n>_prot / hs.h<n>_pmode.
# OUTPUT: #hp_next hs.temp = 1 (→Guarded) / 2 (→Reinforced) / 3 (→Off)
#         (read by toggle_protection for the feedback message)
#
# Mirrors the original single-home cycle, but on the clicked slot's columns:
#   prot 0=off → Guarded (prot 1, pmode 2)
#   Guarded   → Reinforced (prot 1, pmode 1)
#   Reinforced→ Off (prot 0)
# ============================================================

# Compute the next state into a temp first (so reads aren't disturbed mid-update)
scoreboard players set #hp_next hs.temp 0
$execute if score @s hs.h$(n)_prot matches 0 run scoreboard players set #hp_next hs.temp 1
$execute if score @s hs.h$(n)_prot matches 1 if score @s hs.h$(n)_pmode matches 2 run scoreboard players set #hp_next hs.temp 2
$execute if score @s hs.h$(n)_prot matches 1 if score @s hs.h$(n)_pmode matches 1 run scoreboard players set #hp_next hs.temp 3
# Defensive: prot on but mode unset → treat as Guarded, advance to Reinforced
$execute if score @s hs.h$(n)_prot matches 1 unless score @s hs.h$(n)_pmode matches 1..2 run scoreboard players set #hp_next hs.temp 2

# Apply to the slot columns
$execute if score #hp_next hs.temp matches 1 run scoreboard players set @s hs.h$(n)_prot 1
$execute if score #hp_next hs.temp matches 1 run scoreboard players set @s hs.h$(n)_pmode 2
$execute if score #hp_next hs.temp matches 2 run scoreboard players set @s hs.h$(n)_prot 1
$execute if score #hp_next hs.temp matches 2 run scoreboard players set @s hs.h$(n)_pmode 1
$execute if score #hp_next hs.temp matches 3 run scoreboard players set @s hs.h$(n)_prot 0
