# ============================================================
# Housing Zone Protection — Check individual non-owner player
# Run as: non-owner player, at their position
# Context: #hp_hx/hy/hz = home center · #hp_mode = mode · #hp_hdim = home dim
# ============================================================

# Multi-home: dimension gate. The caller sets #hp_hdim to the home's dimension
# (0=OW, 1=Nether, 2=End). Skip players in a different dimension so a home in
# one dimension can't fatigue a player sharing its X/Y/Z in another. (Single-
# home callers that don't set #hp_hdim leave it at 0 = Overworld.)
execute if score #hp_hdim hs.temp matches 0 unless dimension minecraft:overworld run return 0
execute if score #hp_hdim hs.temp matches 1 unless dimension minecraft:the_nether run return 0
execute if score #hp_hdim hs.temp matches 2 unless dimension minecraft:the_end run return 0

# Calculate distance from this player to the home center
scoreboard players operation #hp_dx hs.temp = @s ec.pos_x
scoreboard players operation #hp_dx hs.temp -= #hp_hx hs.temp
execute if score #hp_dx hs.temp matches ..-1 run scoreboard players operation #hp_dx hs.temp *= #-1 ec.const

scoreboard players operation #hp_dy hs.temp = @s ec.pos_y
scoreboard players operation #hp_dy hs.temp -= #hp_hy hs.temp
execute if score #hp_dy hs.temp matches ..-1 run scoreboard players operation #hp_dy hs.temp *= #-1 ec.const

scoreboard players operation #hp_dz hs.temp = @s ec.pos_z
scoreboard players operation #hp_dz hs.temp -= #hp_hz hs.temp
execute if score #hp_dz hs.temp matches ..-1 run scoreboard players operation #hp_dz hs.temp *= #-1 ec.const

# If within 64 blocks on all axes → in the protected zone
execute unless score #hp_dx hs.temp matches ..64 run return 0
execute unless score #hp_dy hs.temp matches ..64 run return 0
execute unless score #hp_dz hs.temp matches ..64 run return 0

# Player IS in a protected zone they don't own
# Check if they're on the owner's friends list (allow friends to build)
execute if score @s hs.guest_pass matches 1 run return 0

# Apply Mining Fatigue 255 (stops mining-based block breaking) — both modes
effect give @s minecraft:mining_fatigue 4 255 true
# Reinforced (Mode 1, Wiring Audit #27 Q1): also Slowness IV — a fuller lockdown for non-owners
execute if score #hp_mode hs.temp matches 1 run effect give @s minecraft:slowness 4 4 true

# Tag them so we know they're in a protected zone
tag @s add hs.in_protected

# First-time warning (only show once per entry)
data modify storage evercraft:notify stage.c set value [{text:"This area is protected. You cannot break or place blocks here.",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 45
execute unless score @s hs.protect_warned matches 1 run function evercraft:util/notify/emit
execute unless score @s hs.protect_warned matches 1 run scoreboard players set @s hs.protect_warned 1
