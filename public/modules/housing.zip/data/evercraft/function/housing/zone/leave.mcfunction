# ============================================================
# Housing Zone — Player left their home zone
# Run as: player
# ============================================================

scoreboard players set @s hs.in_zone 0

# Remove DR modifier
attribute @s luck modifier remove evercraft:housing_dr

# Remove the gilded-totem network DR boost (re-applied by zone/apply_buffs on re-entry)
attribute @s luck modifier remove evercraft:inscr_home_gg

# Remove home companion abilities
execute if score @s hc.count matches 1.. run function evercraft:companions/handler/home/abilities/reset_all

# Subtle leave notification (actionbar)
data modify storage evercraft:notify stage.c set value [{text:"\u2302 ",color:"gray"},{text:"Left Home Zone",color:"dark_gray"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
