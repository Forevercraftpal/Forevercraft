# ============================================================
# Housing Zone — Player entered their home zone
# Run as: player
# ============================================================

scoreboard players set @s hs.in_zone 1

# Apply DR modifier for tier 3+ (attribute modifier persists, removed on leave)
attribute @s luck modifier remove evercraft:housing_dr
execute if score @s hs.tier matches 3..4 run attribute @s luck modifier add evercraft:housing_dr 0.05 add_value
execute if score @s hs.tier matches 5 run attribute @s luck modifier add evercraft:housing_dr 0.1 add_value

# Apply home companion abilities (if any placed)
execute if score @s hc.count matches 1.. run function evercraft:companions/handler/home/abilities/apply_all

# Subtle enter notification (actionbar)
data modify storage evercraft:notify stage.c set value [{text:"\u2302 ",color:"gold"},{text:"Home Zone",color:"yellow"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.chime player @s ~ ~ ~ 0.3 1.5

# Joseph 2026-06-13 task #74 — house-inside-guild discoverability. The bonus
# is in apply_buffs:11-12 (Regen I -> II) and :21-22 (Tier 5 Resistance I -> II).
# Players had no way to know it was firing. Print a follow-up actionbar so the
# overlap reads visibly on every fresh entry.
execute if score @s ec.guild_in_zone matches 1 run data modify storage evercraft:notify stage.c set value [{text:"⚓ ",color:"gold"},{text:"Home + Guild",color:"green"},{text:" — buffs harmonized.",color:"gray"}]
execute if score @s ec.guild_in_zone matches 1 run scoreboard players set #ndur ec.temp 40
execute if score @s ec.guild_in_zone matches 1 run function evercraft:util/notify/emit

# UX ADDITION 1 \u2014 contextual "name your home" prompt. Fires only on this
# out->in border transition (never while idling inside), and only for an
# UNNAMED active home whose deed has never been handed. Guarded + once-per-home
# inside slot/border_prompt (per-slot hs.h<N>_dg flag + registry-name + held-deed
# checks). No-op for already-named homes and for freshly-placed ones.
function evercraft:housing/slot/border_prompt
