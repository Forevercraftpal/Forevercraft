# ============================================================
# Housing Zone Protection — Anti-Grief System (MULTI-HOME)
# Run as: each player with a home (hs.tier >= 1), every 2s
# Applies Mining Fatigue 255 to non-owners in EACH protected home's zone.
#
# Multi-home: a player may own up to 5 homes, each with its own protection
# toggle. Loop every OCCUPIED + PROTECTED slot and run slot_protect_one for it
# (loads that slot's center/mode/dim, scans non-owners, reuses protection_check).
# Existence-gated per slot on hs.h<N>_tier so a 1-home owner pays for 1 slot,
# and on hs.h<N>_prot so unprotected homes are skipped entirely.
#
# Owner-exclusion + the actual scan live in slot_protect_one (per-home), so the
# owner is correctly excluded from each home individually. A non-owner standing
# in two of the owner's overlapping zones just gets Mining Fatigue applied twice
# (harmless — effect 255 for 4s doesn't meaningfully stack-extend).
# ============================================================

execute if score @s hs.h1_tier matches 1.. if score @s hs.h1_prot matches 1 run data modify storage evercraft:housing flp.n set value 1
execute if score @s hs.h1_tier matches 1.. if score @s hs.h1_prot matches 1 run function evercraft:housing/zone/slot_protect_one with storage evercraft:housing flp

execute if score @s hs.h2_tier matches 1.. if score @s hs.h2_prot matches 1 run data modify storage evercraft:housing flp.n set value 2
execute if score @s hs.h2_tier matches 1.. if score @s hs.h2_prot matches 1 run function evercraft:housing/zone/slot_protect_one with storage evercraft:housing flp

execute if score @s hs.h3_tier matches 1.. if score @s hs.h3_prot matches 1 run data modify storage evercraft:housing flp.n set value 3
execute if score @s hs.h3_tier matches 1.. if score @s hs.h3_prot matches 1 run function evercraft:housing/zone/slot_protect_one with storage evercraft:housing flp

execute if score @s hs.h4_tier matches 1.. if score @s hs.h4_prot matches 1 run data modify storage evercraft:housing flp.n set value 4
execute if score @s hs.h4_tier matches 1.. if score @s hs.h4_prot matches 1 run function evercraft:housing/zone/slot_protect_one with storage evercraft:housing flp

execute if score @s hs.h5_tier matches 1.. if score @s hs.h5_prot matches 1 run data modify storage evercraft:housing flp.n set value 5
execute if score @s hs.h5_tier matches 1.. if score @s hs.h5_prot matches 1 run function evercraft:housing/zone/slot_protect_one with storage evercraft:housing flp
