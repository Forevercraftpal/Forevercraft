# ============================================================
# Housing Zone — Apply tier-based buffs
# Run as: player in their home zone (hs.in_zone = 1)
# Called every 2s from zone/check while in zone
# Potion effects given with 5s duration (2s refresh = always active)
# DR handled by attribute modifier (applied on enter, removed on leave)
# ============================================================

# Tier 1+: Regeneration I (5s) — harmonized to II if also in guild zone
execute unless score @s ec.guild_in_zone matches 1 run effect give @s regeneration 5 0 true
execute if score @s ec.guild_in_zone matches 1 run effect give @s regeneration 5 1 true

# Tier 2+: Saturation (5s)
execute if score @s hs.tier matches 2.. run effect give @s saturation 5 0 true

# Tier 3+: DR bonus handled by attribute modifier in zone/enter (0.05 or 0.1 luck)

# Tier 4+: Fire Resistance (5s)
execute if score @s hs.tier matches 4.. run effect give @s fire_resistance 5 0 true

# Tier 5: Resistance I (5s) — harmonized to II if also in guild zone
execute if score @s hs.tier matches 5 unless score @s ec.guild_in_zone matches 1 run effect give @s resistance 5 0 true
execute if score @s hs.tier matches 5 if score @s ec.guild_in_zone matches 1 run effect give @s resistance 5 1 true

# SP9 Hearth Comfort: while a companion is placed at home, the owner gets a MODEST comfort buff that
# scales with the best placed companion's TIER + BOND (cached in companion.hcomfort 0..11 by
# companions/handler/home/abilities/comfort_score, recomputed on every place/retrieve/zone-enter). Gated
# on hcomfort>=1 so it costs nothing when no companion is placed. Short-refresh (5s = the 2s tick keeps
# it live) → it lapses cleanly the instant the player leaves the zone. Regen amplifier picks the highest,
# so it harmonizes with (never double-stacks) the tier/guild regen above.
#   1..5  → Regeneration I            6..8 → Regeneration I + Saturation I    9..11 → Regeneration II + Saturation I
execute if score @s companion.hcomfort matches 1..8 run effect give @s regeneration 5 0 true
execute if score @s companion.hcomfort matches 9.. run effect give @s regeneration 5 1 true
execute if score @s companion.hcomfort matches 6.. run effect give @s saturation 5 0 true

# Calendar + Housing: Active calendar event grants bonus home buff
# Harvest Festival (1): +Saturation II at home (stacks with tier 2 saturation I)
execute if score #cal_event_id ec.var matches 1 run effect give @s saturation 5 1 true
# Prosperity Tide (7): +Luck of the Sea feel — bonus Hero of the Village at home
execute if score #cal_event_id ec.var matches 7 run effect give @s hero_of_the_village 5 0 true

# Home Ecosystem: Passive advantage XP while at home (called every 2s, 20% chance = ~1 per 10s)
# Tier 2+: +1 Cooking progress (home cooking practice)
# Tier 3+: +1 Gathering progress (home garden tending)
# Tier 4+: +1 XP level (passive rest XP)
execute if score @s hs.tier matches 2.. if predicate {"condition":"minecraft:random_chance","chance":0.2} run scoreboard players add @s adv.stat_cook 1
execute if score @s hs.tier matches 3.. if predicate {"condition":"minecraft:random_chance","chance":0.2} run scoreboard players add @s adv.stat_harvest 1
execute if score @s hs.tier matches 4.. if predicate {"condition":"minecraft:random_chance","chance":0.1} run experience add @s 3 points

# Tier 3+: Pet Warp Strike — home pets defend the homestead (every 10s = 5 cycles of 2s tick)
execute if score @s hs.tier matches 3.. run scoreboard players remove @s hs.warp_cd 1
execute if score @s hs.tier matches 3.. if score @s hs.warp_cd matches ..0 run function evercraft:housing/pet_warp/strike_home
execute if score @s hs.tier matches 3.. if score @s hs.warp_cd matches ..0 run scoreboard players set @s hs.warp_cd 5

# Zone Protection: Tamed cats, dogs, and parrots owned by homeowner get Regen I + Resistance I (5s)
tag @s add ec.zone_owner
execute at @s as @e[type=#evercraft:zone_protected_pets,tag=ec.tame_protected,distance=..64] run function evercraft:housing/zone/buff_owner_pets
tag @s remove ec.zone_owner

# House passive proc (Hearth's Blessing): while home, cache which buff-totem TYPES are
# placed in the house so the 5-min proc can fire ANYWHERE off the cache (the buff
# travels with the player — LOCKED event-push pattern, no scanning of unloaded chunks).
function evercraft:inscription/procs/house/cache_types

# Gilded totem network — persistent, zone-wide Dream Rate boost. A Gilded (Gold Greed)
# totem placed at home ALWAYS provides its DR while the owner is in the home zone, across
# the WHOLE zone rather than just the 12-block totem aura. +0.25 luck per gilded home
# totem (cap 7 = +1.75), from the count cached by cache_types above (evercraft:inscr_home_gg).
# Remove-then-add each cycle so the value tracks totems added/removed live (mirrors the
# housing_dr pattern in zone/enter). Removed in zone/leave. NOTE: this modifier is
# intentionally NOT in the dreams/peak/_compute_stable temporary-luck denylist, so it
# counts toward the owner's permanent Dream Rank (per design — the wild/guild proximity
# aura evercraft:inscr_gold_greed IS denylisted, since that one is transient).
attribute @s luck modifier remove evercraft:inscr_home_gg
execute if score @s ec.home_gg_ct matches 1 run attribute @s luck modifier add evercraft:inscr_home_gg 0.25 add_value
execute if score @s ec.home_gg_ct matches 2 run attribute @s luck modifier add evercraft:inscr_home_gg 0.5 add_value
execute if score @s ec.home_gg_ct matches 3 run attribute @s luck modifier add evercraft:inscr_home_gg 0.75 add_value
execute if score @s ec.home_gg_ct matches 4 run attribute @s luck modifier add evercraft:inscr_home_gg 1.0 add_value
execute if score @s ec.home_gg_ct matches 5 run attribute @s luck modifier add evercraft:inscr_home_gg 1.25 add_value
execute if score @s ec.home_gg_ct matches 6 run attribute @s luck modifier add evercraft:inscr_home_gg 1.5 add_value
execute if score @s ec.home_gg_ct matches 7.. run attribute @s luck modifier add evercraft:inscr_home_gg 1.75 add_value
