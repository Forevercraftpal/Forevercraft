# Housing Visitor Log — Notify homeowner and increment counters
# @s = visitor player, owner = @a[tag=hs.owner_check]

# Notify homeowner (gray, subtle)
# §5b: actor-named broadcast — render directly in the visitor's (@s) context so {selector:"@s"}
# resolves to the visitor, not the recipient owner.
function evercraft:util/notify/whoami
data modify storage evercraft:notify stage.c set value [{text:"",color:"yellow"},{text:" is visiting your home!",color:"gray"}]
data modify storage evercraft:notify stage.c[0].text set from storage evercraft:notify named.who
scoreboard players set #ndur ec.temp 50
execute as @a[tag=hs.owner_check] run scoreboard players set #nttl ec.temp 600
execute as @a[tag=hs.owner_check] run function evercraft:util/notify/emit_keep

# Increment visitor counters on homeowner
scoreboard players add @a[tag=hs.owner_check] hs.visitors 1
scoreboard players add @a[tag=hs.owner_check] hs.visit_today 1

# Set cooldown on homeowner (150 = 5 minutes at 2s tick interval)
scoreboard players set @a[tag=hs.owner_check] hs.visit_cd 150
