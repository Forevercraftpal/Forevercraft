# Housing Visitor Check — Detect non-owners in a homeowner's zones (MULTI-HOME)
# Run as: homeowner with hs.tier >= 1, at homeowner
# Loops EVERY occupied slot and detects non-owners near that home. Visitor
# stats (hs.visitors/hs.visit_today/hs.visit_cd) are AGGREGATE per-player (not
# per-slot), so the cooldown decrement/gate + owner-exclusion tag run ONCE
# around the whole slot loop; only the proximity detection iterates slots.

# Decrement visit cooldown for this homeowner (aggregate)
execute if score @s hs.visit_cd matches 1.. run scoreboard players remove @s hs.visit_cd 1

# Skip if cooldown active
execute if score @s hs.visit_cd matches 1.. run return 0

# Tag self once to exclude from every per-slot search
tag @s add hs.owner_check

# For each OCCUPIED slot, scan non-owners near that home (existence-gated)
execute if score @s hs.h1_tier matches 1.. run data modify storage evercraft:housing flv.n set value 1
execute if score @s hs.h1_tier matches 1.. run function evercraft:housing/zone/slot_visitor_one with storage evercraft:housing flv

execute if score @s hs.h2_tier matches 1.. run data modify storage evercraft:housing flv.n set value 2
execute if score @s hs.h2_tier matches 1.. run function evercraft:housing/zone/slot_visitor_one with storage evercraft:housing flv

execute if score @s hs.h3_tier matches 1.. run data modify storage evercraft:housing flv.n set value 3
execute if score @s hs.h3_tier matches 1.. run function evercraft:housing/zone/slot_visitor_one with storage evercraft:housing flv

execute if score @s hs.h4_tier matches 1.. run data modify storage evercraft:housing flv.n set value 4
execute if score @s hs.h4_tier matches 1.. run function evercraft:housing/zone/slot_visitor_one with storage evercraft:housing flv

execute if score @s hs.h5_tier matches 1.. run data modify storage evercraft:housing flv.n set value 5
execute if score @s hs.h5_tier matches 1.. run function evercraft:housing/zone/slot_visitor_one with storage evercraft:housing flv

# Cleanup
tag @s remove hs.owner_check
