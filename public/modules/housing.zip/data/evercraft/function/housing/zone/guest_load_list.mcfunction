# Housing Zone — Macro: load the owner's friends list for guest-comfort iteration.
# Macro args: self_uuid3   (from storage evercraft:housing gst)
# If the owner has no registry entry, the path is absent and temp.guest_list stays
# cleared (the caller removed it first) -> guest_friend_loop returns immediately.
$data modify storage evercraft:friends temp.guest_list set from storage evercraft:friends "u$(self_uuid3)".friends
