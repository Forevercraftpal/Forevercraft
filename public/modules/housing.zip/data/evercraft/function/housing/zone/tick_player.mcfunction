# Housing Zone — Per-player tick (zone check + visitor detection + protection)
# OPT: Consolidates 2 @a[scores={hs.tier=1..}] at @s scans into 1
function evercraft:housing/zone/check
function evercraft:housing/zone/visitor_check
function evercraft:housing/zone/protection_tick
# Best-Friend comfort sharing: buff the owner's Best Friends who are inside the plot
function evercraft:housing/zone/guest_comfort
