# Visitor proximity — is the visitor (#hs_vis_*) inside ONE slot's home zone?
# Run as: @s = the homeowner (from visitor_proximity's slot loop)
# Macro arg: storage evercraft:housing flv = {n:<1-5>}
#   Reads hs.h<n>_x/y/z (home center) + hs.h<n>_dim.
# Mirrors the original single-home visitor_proximity body (64-block box + dim
# check), but against THIS slot. Sets #hs_near_any=1 if the visitor is inside.

# Dimension check vs this slot's dim
$execute unless score #hs_vis_dim hs.temp = @s hs.h$(n)_dim run return 0

# X check
scoreboard players operation #hs_chk hs.temp = #hs_vis_x hs.temp
$scoreboard players operation #hs_chk hs.temp -= @s hs.h$(n)_x
execute if score #hs_chk hs.temp matches ..-1 run scoreboard players operation #hs_chk hs.temp *= #-1 ec.const
execute if score #hs_chk hs.temp matches 65.. run return 0

# Y check
scoreboard players operation #hs_chk hs.temp = #hs_vis_y hs.temp
$scoreboard players operation #hs_chk hs.temp -= @s hs.h$(n)_y
execute if score #hs_chk hs.temp matches ..-1 run scoreboard players operation #hs_chk hs.temp *= #-1 ec.const
execute if score #hs_chk hs.temp matches 65.. run return 0

# Z check
scoreboard players operation #hs_chk hs.temp = #hs_vis_z hs.temp
$scoreboard players operation #hs_chk hs.temp -= @s hs.h$(n)_z
execute if score #hs_chk hs.temp matches ..-1 run scoreboard players operation #hs_chk hs.temp *= #-1 ec.const
execute if score #hs_chk hs.temp matches 65.. run return 0

# Within this home's zone
scoreboard players set #hs_near_any hs.temp 1
