# ============================================================
# Hearthstone break gate — owner-presence test (per present player)
# Run as: @s = a player within 6 blocks of the broken marker.
# Compares @s's UUID to the marker owner UUID in #hs_brk_ou0/ou1 hs.temp
# (set by check_break_allow). On a full match (both 32-bit halves), sets
# #hs_brk_ok hs.temp = 1 → the caller routes the break through on_break as
# legitimate. UUID idiom mirrors tamed_bond/check_owner.
# ============================================================

# UUID[0] half.
execute store result score @s hs.temp run data get entity @s UUID[0]
execute unless score @s hs.temp = #hs_brk_ou0 hs.temp run return 0

# UUID[1] half — both must match.
execute store result score @s hs.temp run data get entity @s UUID[1]
execute unless score @s hs.temp = #hs_brk_ou1 hs.temp run return 0

# This present player IS the owner — the break is legitimate.
scoreboard players set #hs_brk_ok hs.temp 1
