# Housing Visitor Proximity — Is the visitor (in #hs_vis_*) near ANY of @s's homes?
# @s = a homeowner (from `as @a[scores={hs.tier=1..}]` in visitor_leave_check)
# Multi-home: the visitor keeps the hs.visiting tag while inside ANY of this
# owner's occupied homes, so we must test every slot — not just the active
# mirror — or the tag would drop while they're still inside a non-active home.

# Already found near someone? Skip
execute if score #hs_near_any hs.temp matches 1 run return 0

# Test each occupied slot; first hit sets #hs_near_any and short-circuits.
execute if score @s hs.h1_tier matches 1.. if score #hs_near_any hs.temp matches 0 run data modify storage evercraft:housing flv.n set value 1
execute if score @s hs.h1_tier matches 1.. if score #hs_near_any hs.temp matches 0 run function evercraft:housing/zone/slot_proximity_one with storage evercraft:housing flv

execute if score @s hs.h2_tier matches 1.. if score #hs_near_any hs.temp matches 0 run data modify storage evercraft:housing flv.n set value 2
execute if score @s hs.h2_tier matches 1.. if score #hs_near_any hs.temp matches 0 run function evercraft:housing/zone/slot_proximity_one with storage evercraft:housing flv

execute if score @s hs.h3_tier matches 1.. if score #hs_near_any hs.temp matches 0 run data modify storage evercraft:housing flv.n set value 3
execute if score @s hs.h3_tier matches 1.. if score #hs_near_any hs.temp matches 0 run function evercraft:housing/zone/slot_proximity_one with storage evercraft:housing flv

execute if score @s hs.h4_tier matches 1.. if score #hs_near_any hs.temp matches 0 run data modify storage evercraft:housing flv.n set value 4
execute if score @s hs.h4_tier matches 1.. if score #hs_near_any hs.temp matches 0 run function evercraft:housing/zone/slot_proximity_one with storage evercraft:housing flv

execute if score @s hs.h5_tier matches 1.. if score #hs_near_any hs.temp matches 0 run data modify storage evercraft:housing flv.n set value 5
execute if score @s hs.h5_tier matches 1.. if score #hs_near_any hs.temp matches 0 run function evercraft:housing/zone/slot_proximity_one with storage evercraft:housing flv
