# ============================================================
# Protection — scan non-owners near ONE slot's home (multi-home)
# Run as: @s = the homeowner, every 2s (dispatched from protection_tick)
# Macro arg: storage evercraft:housing flp = {n:<1-5>}
#   Reads hs.h<n>_x/y/z (home center), hs.h<n>_pmode (mode), hs.h<n>_dim.
#
# Loads the per-check scratch (#hp_hx/hy/hz/#hp_mode/#hp_hdim) from THIS slot,
# then reuses the EXISTING protection_check body for every non-owner. Owner-
# exclusion is by the temporary hs.owner_match tag (mirrors the single-home
# protection_tick). protection_check now dim-gates on #hp_hdim, so a Nether
# home never fatigues an Overworld player who shares its X/Y/Z.
# ============================================================

# Pull this slot's home center + mode + dim into the check scratch
$scoreboard players operation #hp_hx hs.temp = @s hs.h$(n)_x
$scoreboard players operation #hp_hy hs.temp = @s hs.h$(n)_y
$scoreboard players operation #hp_hz hs.temp = @s hs.h$(n)_z
$scoreboard players operation #hp_mode hs.temp = @s hs.h$(n)_pmode
$scoreboard players operation #hp_hdim hs.temp = @s hs.h$(n)_dim

# Exclude the owner from their own protection scan
tag @s add hs.owner_match
# Check all OTHER players near this home (protection_check self-gates dimension)
execute as @a[tag=!hs.owner_match] at @s run function evercraft:housing/zone/protection_check
tag @s remove hs.owner_match
