# ============================================================
# Housing Zone — Best-Friend comfort: test ONE candidate against the host's homes
# Run as: candidate player (@s, a non-owner), at @s.
# Context: #hs_gf_u3 hs.temp = the friend-entry UUID3 we're matching this pass;
#          #hs_s<n>{x,y,z,d,t} hs.temp = the host's occupied home boxes.
# If @s matches the entry and is inside a home box, applies that home's tier comforts.
# ============================================================

# Must be the player this friend-entry refers to.
execute store result score #hs_cu3 hs.temp run data get entity @s UUID[3]
execute unless score #hs_cu3 hs.temp = #hs_gf_u3 hs.temp run return 0

# Cache the guest's position + dimension (ec.pos_* maintained for all players by movement/detect).
scoreboard players operation #hs_gx hs.temp = @s ec.pos_x
scoreboard players operation #hs_gy hs.temp = @s ec.pos_y
scoreboard players operation #hs_gz hs.temp = @s ec.pos_z
scoreboard players set #hs_gd hs.temp 0
execute if dimension minecraft:the_nether run scoreboard players set #hs_gd hs.temp 1
execute if dimension minecraft:the_end run scoreboard players set #hs_gd hs.temp 2

# Highest-tier home box the guest is standing inside (0 = none).
scoreboard players set #hs_gbest hs.temp 0
execute if score #hs_s1t hs.temp matches 1.. run function evercraft:housing/zone/guest_check_slot {n:"1"}
execute if score #hs_s2t hs.temp matches 1.. run function evercraft:housing/zone/guest_check_slot {n:"2"}
execute if score #hs_s3t hs.temp matches 1.. run function evercraft:housing/zone/guest_check_slot {n:"3"}
execute if score #hs_s4t hs.temp matches 1.. run function evercraft:housing/zone/guest_check_slot {n:"4"}
execute if score #hs_s5t hs.temp matches 1.. run function evercraft:housing/zone/guest_check_slot {n:"5"}

# Inside at least one home zone -> grant comforts (else clear the welcome dedupe so re-entry re-greets).
execute if score #hs_gbest hs.temp matches 1.. run function evercraft:housing/zone/guest_apply_buffs
execute if score #hs_gbest hs.temp matches 0 run tag @s remove hs.guest_welcomed
