# Housing Zone — Best-Friend comfort: one-time welcome message to the guest.
# Run as: the guest (@s).
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"You feel at home here",color:"green"},{text:" — a dear friend's hearth shares its comforts with you.",color:"gray"}]
scoreboard players set #ndur ec.temp 60
function evercraft:util/notify/emit
