# ============================================================
# Housing Zone — Best-Friend comfort sharing (per-owner body)
# Run as: homeowner (tagged hs.owner_check), at homeowner.
# Stages the owner's friends list + every occupied slot's home box, then iterates.
# ============================================================

# Stage owner UUID3 (friends registry key) and reload the owner's friends list.
# Clear first so an owner with NO registry entry can't inherit the previous owner's list.
data remove storage evercraft:friends temp.guest_list
execute store result storage evercraft:housing gst.self_uuid3 int 1 run data get entity @s UUID[3]
function evercraft:housing/zone/guest_load_list with storage evercraft:housing gst

# Stage occupied slots' home box (coords/dim/tier) into scratch (#hs_s<n>{x,y,z,d,t}).
# tier 0 = slot unused -> guest_check_slot skips it.
scoreboard players set #hs_s1t hs.temp 0
scoreboard players set #hs_s2t hs.temp 0
scoreboard players set #hs_s3t hs.temp 0
scoreboard players set #hs_s4t hs.temp 0
scoreboard players set #hs_s5t hs.temp 0
execute if score @s hs.h1_tier matches 1.. run function evercraft:housing/zone/guest_stage_slot {n:"1"}
execute if score @s hs.h2_tier matches 1.. run function evercraft:housing/zone/guest_stage_slot {n:"2"}
execute if score @s hs.h3_tier matches 1.. run function evercraft:housing/zone/guest_stage_slot {n:"3"}
execute if score @s hs.h4_tier matches 1.. run function evercraft:housing/zone/guest_stage_slot {n:"4"}
execute if score @s hs.h5_tier matches 1.. run function evercraft:housing/zone/guest_stage_slot {n:"5"}

# Walk the owner's friends list; buff each Best Friend found inside a home zone.
function evercraft:housing/zone/guest_friend_loop
