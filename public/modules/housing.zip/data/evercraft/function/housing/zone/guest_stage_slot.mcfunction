# Housing Zone — Macro: stage one occupied home slot's box into scratch for guest checks.
# Run as: homeowner. Macro args: n (1-5)   (from {n:"<slot>"})
# Copies hs.h<n>_{x,y,z,dim,tier} into the per-slot scratch the guest-side reads.
$scoreboard players operation #hs_s$(n)x hs.temp = @s hs.h$(n)_x
$scoreboard players operation #hs_s$(n)y hs.temp = @s hs.h$(n)_y
$scoreboard players operation #hs_s$(n)z hs.temp = @s hs.h$(n)_z
$scoreboard players operation #hs_s$(n)d hs.temp = @s hs.h$(n)_dim
$scoreboard players operation #hs_s$(n)t hs.temp = @s hs.h$(n)_tier
