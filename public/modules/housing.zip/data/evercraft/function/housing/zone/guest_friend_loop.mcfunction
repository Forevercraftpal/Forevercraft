# ============================================================
# Housing Zone — Best-Friend comfort: iterate the owner's friends list
# Run as: homeowner (tagged hs.owner_check), at homeowner.
# Consumes storage evercraft:friends temp.guest_list. Reuses the friends-system
# entry schema ({uuid3, hearts, ...}). Best Friend = hearts >= #fr_best ec.const (90).
# ============================================================

execute unless data storage evercraft:friends temp.guest_list[0] run return 0

# Read this entry's friend UUID3 + heart count.
execute store result score #hs_gf_u3 hs.temp run data get storage evercraft:friends temp.guest_list[0].uuid3
execute store result score #hs_gf_h hs.temp run data get storage evercraft:friends temp.guest_list[0].hearts

# Best Friends only: find the matching online non-owner and try to buff them. Non-qualifying
# entries cost no entity scan (the @a scan only runs when hearts >= #fr_best).
execute if score #hs_gf_h hs.temp >= #fr_best ec.const as @a[tag=!hs.owner_check,gamemode=!spectator] at @s run function evercraft:housing/zone/guest_check_player

# Pop and recurse.
data remove storage evercraft:friends temp.guest_list[0]
function evercraft:housing/zone/guest_friend_loop
