# ============================================================
# Visitor — detect non-owners near ONE slot's home (multi-home)
# Run as: @s = the homeowner (dispatched from visitor_check)
# Macro arg: storage evercraft:housing flv = {n:<1-5>}
#   Reads hs.h<n>_x/y/z (home center) + hs.h<n>_dim.
#
# Loads this slot's coords/dim into the visitor scratch (#hs_vx/vy/vz/vdim),
# then reuses the EXISTING visitor_test body for every non-owner. The owner is
# excluded via the hs.owner_check tag (set ONCE by visitor_check around the
# whole slot loop). visitor_test already dimension-checks against #hs_vdim and
# de-dupes via the hs.visiting tag, so a visitor near multiple of the owner's
# homes is logged once (and the aggregate hs.visit_cd cooldown gates spam).
# ============================================================

$scoreboard players operation #hs_vx hs.temp = @s hs.h$(n)_x
$scoreboard players operation #hs_vy hs.temp = @s hs.h$(n)_y
$scoreboard players operation #hs_vz hs.temp = @s hs.h$(n)_z
$scoreboard players operation #hs_vdim hs.temp = @s hs.h$(n)_dim

# Check each other player against THIS home (visitor_test de-dupes + dim-checks)
execute as @a[tag=!hs.owner_check] at @s run function evercraft:housing/zone/visitor_test
