# ============================================================
# Hearthstone — break-authorization gate (AU31-Q2, model β: owner may mine)
# Run as: @s = the HS.Marker, at the marker. Called from tick_marker when an
# UNPROTECTED stone's lodestone is missing on the 2s poll.
#
# β rule (Joseph-locked 2026-06-02): a break is LEGITIMATE only if the OWNER
# (standing within ~6 blocks) or an ADMIN broke it. There is no break event,
# so we can't key on the breaker directly — instead we check who is PRESENT:
#   - A player within 6 blocks whose UUID == this marker's data.owner_uuid, OR
#   - A player within 6 blocks carrying admin authority (tag ec.hsadmin), OR
#   - This marker is admin-force-break tagged (HS.AdminBreak).
# -> fall through to on_break (the present owner's check_owner_reset resets
#    cleanly; non-present owners go through the deferred-reset queue).
# Otherwise the break is UNAUTHORIZED (a non-owner griefer, or a non-player
# removal with the owner away): restore the lodestone, confiscate the drop,
# and notify — the proven restore_hearthstone rail, generalized to all stones.
# ============================================================

# Legacy safety: a marker with NO owner_uuid predates ownership tracking — we
# can't authorize anyone against it, so fall back to the old unconditional
# teardown rather than trapping the owner forever. (All stones placed via
# setup_hearthstone / confirm_relocate carry owner_uuid; this is belt-only.)
execute unless data entity @s data.owner_uuid run return run function evercraft:housing/on_break

# Read this marker's owner UUID (high 2 ints uniquely identify the owner).
# Zero first so a missing index can never leave a stale prior-marker value.
scoreboard players set #hs_brk_ou0 hs.temp 0
scoreboard players set #hs_brk_ou1 hs.temp 0
execute store result score #hs_brk_ou0 hs.temp run data get entity @s data.owner_uuid[0]
execute store result score #hs_brk_ou1 hs.temp run data get entity @s data.owner_uuid[1]

# AUTHORIZED if the marker is admin-force-break tagged.
execute if entity @s[tag=HS.AdminBreak] run return run function evercraft:housing/on_break

# AUTHORIZED if an admin (ec.hsadmin) is present within 6 blocks.
execute if entity @a[distance=..6,tag=ec.hsadmin,limit=1] run return run function evercraft:housing/on_break

# AUTHORIZED if the OWNER is present within 6 blocks (UUID idiom: match both
# 32-bit halves — tamed_bond/check_owner). check_break_owner runs as each
# present player, compares their UUID to #hs_brk_ou0/ou1, sets #hs_brk_ok.
scoreboard players set #hs_brk_ok hs.temp 0
execute as @a[distance=..6] run function evercraft:housing/zone/check_break_owner
execute if score #hs_brk_ok hs.temp matches 1 run return run function evercraft:housing/on_break

# UNAUTHORIZED — revert the break + confiscate the dropped stone + notify.
function evercraft:housing/zone/restore_unauthorized
