# Hearthstone Marker Tick — runs as marker, at marker
# OPT: Consolidates 3 @e scans into 1 per-marker function call

# OPT: Skip all processing when no player is within 64 blocks (unloaded homes)
execute unless entity @a[distance=..64] run return 0

# Break detection: if the lodestone is gone, branch on authorization.
#  - PROTECTED (data.protect:1) -> restore unconditionally (Wiring Audit #27 Q2).
#  - UNPROTECTED -> check_break_allow (AU31-Q2, β): route to on_break ONLY if
#    the owner (within ~6) or an admin broke it; otherwise revert + confiscate
#    (kills the grief vector for ALL stones, not just protected ones, while
#    still letting the owner physically mine their own stone). The marker
#    carries data.protect + data.owner_uuid, so this works owner-offline too.
execute unless block ~ ~ ~ minecraft:lodestone if data entity @s {data:{protect:1}} run return run function evercraft:housing/zone/restore_hearthstone
execute unless block ~ ~ ~ minecraft:lodestone run return run function evercraft:housing/zone/check_break_allow

# Ambient particles (only if a player is within render distance)
execute if entity @a[distance=..48] run particle minecraft:flame ~0 ~1.1 ~0 0.15 0.08 0.15 0.005 1
execute if entity @a[distance=..48] run particle minecraft:small_flame ~0 ~1.3 ~0 0.1 0.1 0.1 0.01 1

# Garden growth boost (tier 3+ hearthstones accelerate nearby crops)
# OPT: Single score check instead of 3 NBT reads
execute store result score #hs_tier ec.temp run data get entity @s data.owner_tier
execute if score #hs_tier ec.temp matches 3.. run function evercraft:housing/garden/tick
