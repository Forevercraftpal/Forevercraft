# ============================================================
# Player Housing System — Load
# Place a Hearthstone (lodestone) → claims 64x64 area
# Right-click → entity GUI for tier upgrades (netherite ingots)
# Tier buffs while in your home zone + 3x3 chunk loading
# Auto-registers as Guidestone destination
# ============================================================

# Per-player home state
scoreboard objectives add hs.tier dummy "Home Tier (0=none, 1-5)"
scoreboard objectives add hs.home_x dummy "Home X"
scoreboard objectives add hs.home_y dummy "Home Y"
scoreboard objectives add hs.home_z dummy "Home Z"
scoreboard objectives add hs.home_dim dummy "Home Dim (0=OW,1=N,2=E)"
scoreboard objectives add hs.in_zone dummy "In Home Zone"
scoreboard objectives add hs.gs_id dummy "Home Guidestone ID"
scoreboard objectives add hs.temp dummy "Housing Temp"
scoreboard objectives add hs.decor dummy "Decoration Score"
scoreboard objectives add hs.stashed dummy "Items Stashed"
scoreboard objectives add hs.failed dummy "Items Failed"
scoreboard objectives add hs.menu_time dummy "Hearthstone Menu Inactivity"
scoreboard objectives add hs.warp_cd dummy "Home Pet Warp Cooldown"
scoreboard objectives add hs.def_msg_t dummy "Pet-Defend Notify Time (gametime)"
scoreboard objectives add hs.visitors dummy "Total Unique Visitors"
scoreboard objectives add hs.visit_today dummy "Visitors Today"
scoreboard objectives add hs.visit_cd dummy "Visitor Notify Cooldown"
scoreboard objectives add hs.protect dummy "Home Protection (0=off, 1=on)"
scoreboard objectives add hs.protect_mode dummy "Home Protection Mode (1=Reinforced, 2=Guarded)"
scoreboard objectives add hs.protect_warned dummy "Protection Warning Shown"
scoreboard objectives add hs.guest_pass dummy "Guest Pass (friends can build)"
# Best-Friend comfort sharing. SEMANTICS: 1 = REVOKED (sharing off); 0/absent = ON (default).
# A homeowner's Best Friends (90+ hearts) receive the home's tier comfort buffs while in the
# plot — see housing/zone/guest_comfort. Owner toggles via the Hearthstone menu.
scoreboard objectives add hs.guest_share dummy "Best-Friend Comfort Sharing (1=revoked)"

# ============================================================
# MULTI-HOME — per-slot home state + pointers (CAP=5)
# Data model: per-slot scoreboard columns (h1..h5) + an active-slot
# pointer. The legacy hs.tier / hs.home_* / hs.gs_id / hs.decor /
# hs.protect / hs.protect_mode fields above are kept as a LIVE MIRROR
# of the ACTIVE slot (hs.h<active>_*), so ~40 cross-system readers stay
# unchanged. Only forceload + the zone iterators + setup/relocate/break
# loop all slots; home display names live in the guidestone registry
# `name` field (no second storage list).
#
# Mirror invariant (ONE WRITER each):
#   hs.home_*/hs.tier/hs.gs_id/hs.decor/hs.protect/hs.protect_mode
#     <- evercraft:housing/slot/load_active ONLY  (copies active slot -> mirror)
#   hs.h<N>_*  <- that slot's writer (setup/relocate/break/migrate/save_active)
#   hs.active  <- set_active (GUI switch) | migrate (first bind) |
#                 repoint_after_clear (active-home removal). Mutually
#                 exclusive event paths; never two in one frame.
#   hs.slots   <- slot/unlock_check ONLY (Agent D)
#   hs.homes   <- slot/recount (shared writer; call after any add/remove)
#   hs.reloc_n <- Manage-Homes [Relocate] arms it; confirm_relocate consumes it
# ============================================================

# Slot 1 columns
scoreboard objectives add hs.h1_tier dummy "Home1 Tier"
scoreboard objectives add hs.h1_x dummy "Home1 X"
scoreboard objectives add hs.h1_y dummy "Home1 Y"
scoreboard objectives add hs.h1_z dummy "Home1 Z"
scoreboard objectives add hs.h1_dim dummy "Home1 Dim"
scoreboard objectives add hs.h1_gs dummy "Home1 Guidestone ID"
scoreboard objectives add hs.h1_decor dummy "Home1 Decor"
scoreboard objectives add hs.h1_prot dummy "Home1 Protect"
scoreboard objectives add hs.h1_pmode dummy "Home1 Protect Mode"
scoreboard objectives add hs.h1_dg dummy "Home1 Deed Given"

# Slot 2 columns
scoreboard objectives add hs.h2_tier dummy "Home2 Tier"
scoreboard objectives add hs.h2_x dummy "Home2 X"
scoreboard objectives add hs.h2_y dummy "Home2 Y"
scoreboard objectives add hs.h2_z dummy "Home2 Z"
scoreboard objectives add hs.h2_dim dummy "Home2 Dim"
scoreboard objectives add hs.h2_gs dummy "Home2 Guidestone ID"
scoreboard objectives add hs.h2_decor dummy "Home2 Decor"
scoreboard objectives add hs.h2_prot dummy "Home2 Protect"
scoreboard objectives add hs.h2_pmode dummy "Home2 Protect Mode"
scoreboard objectives add hs.h2_dg dummy "Home2 Deed Given"

# Slot 3 columns
scoreboard objectives add hs.h3_tier dummy "Home3 Tier"
scoreboard objectives add hs.h3_x dummy "Home3 X"
scoreboard objectives add hs.h3_y dummy "Home3 Y"
scoreboard objectives add hs.h3_z dummy "Home3 Z"
scoreboard objectives add hs.h3_dim dummy "Home3 Dim"
scoreboard objectives add hs.h3_gs dummy "Home3 Guidestone ID"
scoreboard objectives add hs.h3_decor dummy "Home3 Decor"
scoreboard objectives add hs.h3_prot dummy "Home3 Protect"
scoreboard objectives add hs.h3_pmode dummy "Home3 Protect Mode"
scoreboard objectives add hs.h3_dg dummy "Home3 Deed Given"

# Slot 4 columns
scoreboard objectives add hs.h4_tier dummy "Home4 Tier"
scoreboard objectives add hs.h4_x dummy "Home4 X"
scoreboard objectives add hs.h4_y dummy "Home4 Y"
scoreboard objectives add hs.h4_z dummy "Home4 Z"
scoreboard objectives add hs.h4_dim dummy "Home4 Dim"
scoreboard objectives add hs.h4_gs dummy "Home4 Guidestone ID"
scoreboard objectives add hs.h4_decor dummy "Home4 Decor"
scoreboard objectives add hs.h4_prot dummy "Home4 Protect"
scoreboard objectives add hs.h4_pmode dummy "Home4 Protect Mode"
scoreboard objectives add hs.h4_dg dummy "Home4 Deed Given"

# Slot 5 columns
scoreboard objectives add hs.h5_tier dummy "Home5 Tier"
scoreboard objectives add hs.h5_x dummy "Home5 X"
scoreboard objectives add hs.h5_y dummy "Home5 Y"
scoreboard objectives add hs.h5_z dummy "Home5 Z"
scoreboard objectives add hs.h5_dim dummy "Home5 Dim"
scoreboard objectives add hs.h5_gs dummy "Home5 Guidestone ID"
scoreboard objectives add hs.h5_decor dummy "Home5 Decor"
scoreboard objectives add hs.h5_prot dummy "Home5 Protect"
scoreboard objectives add hs.h5_pmode dummy "Home5 Protect Mode"
scoreboard objectives add hs.h5_dg dummy "Home5 Deed Given"

# ------------------------------------------------------------
# UX ADDITION 1 (2026-06-02) — contextual naming of migrated homes
# hs.h<N>_dg : per-slot "Home Deed already handed out" flag (0=not yet,
#   1=given/named). Shared writer (disjoint event paths, like hs.homes):
#   slot/migrate_home sets a migrated slot to 0 (needs naming) · slot/stamp_dg
#   + rename/give_deed + slot/border_prompt_stamp set 1 once a deed is handed
#   (or the home is found already-named). So the contextual home-zone border
#   prompt fires EXACTLY ONCE per migrated home and never for in-place claims.
# Guidestone Deeds (ADDITION 3) carry their target as the registry gs_id baked
#   into the book's custom_data — no scoreboard column needed (scratch only:
#   #gs_deed_id ec.gs_temp, #hs_deed_gs hs.temp).
# ------------------------------------------------------------

# Pointers & cap
scoreboard objectives add hs.active dummy "Active Home Slot (1-5, 0=none)"
scoreboard objectives add hs.slots dummy "Unlocked Home Slots (1-5)"
scoreboard objectives add hs.homes dummy "Occupied Home Slots (count)"
scoreboard objectives add hs.next_slot dummy "Next-Free Slot output (Agent D)"
scoreboard objectives add hs.reloc_n dummy "Armed Relocate Slot (0=none)"

# Home-slot CAP constant (5). One-writer here; read by next_free / unlock_check / GUI.
scoreboard players set #hs_cap ec.const 5

# Hearthstone player_head texture (custom fireplace skin via MineSkin)
data modify storage evercraft:housing temp_skin set value "ewogICJ0aW1lc3RhbXAiIDogMTc3MzAxMTIwNDE3MywKICAicHJvZmlsZUlkIiA6ICJhYjNkNTgwMjVkOWM0NTcyODNkNTFlYTcwYTY4N2U1NiIsCiAgInByb2ZpbGVOYW1lIiA6ICJsdWN5X2ludGhlc2t5XyIsCiAgInNpZ25hdHVyZVJlcXVpcmVkIiA6IHRydWUsCiAgInRleHR1cmVzIiA6IHsKICAgICJTS0lOIiA6IHsKICAgICAgInVybCIgOiAiaHR0cDovL3RleHR1cmVzLm1pbmVjcmFmdC5uZXQvdGV4dHVyZS8xOGZhOTk2ODU5MzM4NTExNmNmM2E0NWM2MDQ3OTY3NDU2YjcyYzgxNTA2OGE0ODA1ZGE5ZjE0MTcxZTcwZTlmIiwKICAgICAgIm1ldGFkYXRhIiA6IHsKICAgICAgICAibW9kZWwiIDogInNsaW0iCiAgICAgIH0KICAgIH0KICB9Cn0="

# Bootstrap tick schedule (2s self-schedule)
schedule function evercraft:housing/tick 2s replace
