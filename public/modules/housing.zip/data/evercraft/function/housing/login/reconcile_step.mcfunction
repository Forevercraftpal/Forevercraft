# ============================================================
# Housing — Login reconcile: deferred-reset queue step (recursive)
# Run as: @s = the just-joined player. Walks a COPY of the deferred-reset
# queue (evercraft:housing pr_scan) and rebuilds the surviving queue in
# evercraft:housing pending_reset, draining ONLY the entries that belong to
# @s (matched by stored owner UUID). Foreign entries are copied through
# untouched so another player's orphan survives until THEY log in.
#
# Each entry: {u0,u1,u2,u3 (owner uuid ints), gs:<broken gs_id>}.
# On a UUID match: resolve which of @s's 5 slots still holds that gs_id and
# clear it (clear_slot -> recount -> repoint_after_clear), exactly like the
# slot-side abandon_orphan, then DROP the entry (not copied to the rebuild).
# If no slot holds it (already reconciled), still drop it. Bounded recursion.
# Caller (reconcile) snapshots pending_reset -> pr_scan and empties
# pending_reset before the first step; this step refills pending_reset with
# the keepers.
# ============================================================

# End of the scan buffer -> done (surviving entries already rebuilt).
execute unless data storage evercraft:housing pr_scan[0] run return 0

# Compare the head entry's owner UUID against @s (UUID[0] then UUID[1] — the
# tamed_bond/check_owner idiom; two 32-bit halves uniquely identify a player).
execute store result score #hs_pr_pu0 hs.temp run data get entity @s UUID[0]
execute store result score #hs_pr_pu1 hs.temp run data get entity @s UUID[1]
execute store result score #hs_pr_eu0 hs.temp run data get storage evercraft:housing pr_scan[0].u0
execute store result score #hs_pr_eu1 hs.temp run data get storage evercraft:housing pr_scan[0].u1

scoreboard players set #hs_pr_mine hs.temp 0
execute if score #hs_pr_pu0 hs.temp = #hs_pr_eu0 hs.temp if score #hs_pr_pu1 hs.temp = #hs_pr_eu1 hs.temp run scoreboard players set #hs_pr_mine hs.temp 1

# MINE -> reconcile this orphan into @s's slots (do NOT keep the entry).
execute if score #hs_pr_mine hs.temp matches 1 run function evercraft:housing/login/reconcile_slot

# FOREIGN -> copy the entry through to the rebuilt (surviving) queue.
execute if score #hs_pr_mine hs.temp matches 0 run data modify storage evercraft:housing pending_reset append from storage evercraft:housing pr_scan[0]

# Advance and recurse.
data remove storage evercraft:housing pr_scan[0]
function evercraft:housing/login/reconcile_step
