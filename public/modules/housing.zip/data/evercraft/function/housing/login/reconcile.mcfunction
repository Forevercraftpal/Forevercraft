# ============================================================
# Housing — Login reconcile (ghost-home cleanup, AU31-Q2)
# Run as: @s = the player, AT the player. Called from dreams/on_join.
#
# Two jobs:
#   1. Drain the deferred-reset queue (storage evercraft:housing pending_reset):
#      a non-player / offline-owner / admin break enqueued THIS player's
#      orphaned gs_id while they were offline. Match by stored owner UUID,
#      then clear the matched slot (clear_slot -> recount -> repoint) so no
#      ghost columns survive. Mirrors the slot-side abandon_orphan teardown.
#   2. Tier-0 self-heal: belt-and-suspenders for ghosts already on the file
#      (and for any future leak the queue misses). If THIS player carries the
#      leaked hs.in_zone / housing_dr while owning no home (hs.tier=0), strip
#      both. This is the SOLE writer of the tier-0 partition (every online
#      writer — zone/enter, zone/leave, repoint_after_clear — runs on
#      tier>=1 players, so there is no one-writer conflict).
# ============================================================

# ─── 1. Deferred-reset queue drain (β: offline-owner orphan) ───
# Only walk the queue when it is non-empty (cheap existence gate). Snapshot
# it into pr_scan, empty the live queue, then rebuild the live queue with the
# entries that DON'T belong to @s (reconcile_step copies foreigners through,
# drains @s's own). Survives restart (storage).
execute if data storage evercraft:housing pending_reset[0] run data modify storage evercraft:housing pr_scan set from storage evercraft:housing pending_reset
execute if data storage evercraft:housing pr_scan[0] run data modify storage evercraft:housing pending_reset set value []
execute if data storage evercraft:housing pr_scan[0] run function evercraft:housing/login/reconcile_step

# ─── 2. Tier-0 self-heal (retro-fix existing ghosts) ───
# A player with NO home (hs.tier=0) must not carry the home-zone state. The
# stuck hs.in_zone leaks into cooking's Home-Kitchen +1 (cooking/minigame/
# resolve), alchemy/forging resolve, guild buffs, bandit suppression; the
# orphaned housing_dr luck modifier inflates loot. Strip both, here only.
execute if score @s hs.tier matches 0 if score @s hs.in_zone matches 1.. run scoreboard players set @s hs.in_zone 0
execute if score @s hs.tier matches 0 run attribute @s luck modifier remove evercraft:housing_dr
