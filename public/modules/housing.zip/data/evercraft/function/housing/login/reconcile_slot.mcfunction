# ============================================================
# Housing — Login reconcile: clear @s's slot for a matched orphan
# Run as: @s = the just-joined owner. The orphan entry is pr_scan[0]; its
# broken gs_id is pr_scan[0].gs. Find which of @s's 5 slots still holds that
# gs_id and tear down ITS bookkeeping (the marker + registry + forceload were
# already cleaned by on_break when the stone was destroyed — only the owner's
# offline columns are left). Mirrors the slot-side abandon_orphan:
#   find_by_gs -> clear_slot -> recount -> repoint_after_clear (if active).
# repoint_after_clear also zeroes hs.in_zone + removes housing_dr, so the
# ghost-buff leak is closed even when the cleared slot was the active one.
# ============================================================

# Resolve the broken gs_id from the queue entry into the find input.
execute store result score #hs_find_gs hs.temp run data get storage evercraft:housing pr_scan[0].gs

# Which slot holds it? (0 = none — already reconciled, nothing to do.)
function evercraft:housing/slot/find_by_gs
execute if score #hs_find_slot hs.temp matches 0 run return 0

# Capture whether the matched slot is the ACTIVE one (repoint only if so).
scoreboard players set #hs_rc_active hs.temp 0
execute if score @s hs.active = #hs_find_slot hs.temp run scoreboard players set #hs_rc_active hs.temp 1

# The break happened while @s was OFFLINE, so on_break could not snapshot this
# home into the recovery store (its tier/decor live on @s's file, out of scope
# then). @s is online NOW and the columns are still populated — snapshot here,
# BEFORE the clear, so the offline-orphan case is recoverable too. Skips the
# default "Home". (cor.n is set below for clear_slot; set it now for both.)
execute store result storage evercraft:housing cor.n int 1 run scoreboard players get #hs_find_slot hs.temp
function evercraft:housing/slot/snapshot_to_recovery with storage evercraft:housing cor

# Clear that slot's columns (clear_slot macro reads cor.n).
function evercraft:housing/slot/clear_slot with storage evercraft:housing cor

# Recount occupied homes, then re-point if the active home was the orphan.
function evercraft:housing/slot/recount
execute if score #hs_rc_active hs.temp matches 1 run function evercraft:housing/slot/repoint_after_clear

# Belt-and-suspenders: if the cleared slot was NOT active (so repoint didn't
# run) the player still might carry the leaked zone state from this orphan —
# strip it here too. (No-op if they're legitimately in another home's zone,
# because that home would re-set hs.in_zone on the next zone tick.)
execute if score #hs_rc_active hs.temp matches 0 run scoreboard players set @s hs.in_zone 0
execute if score #hs_rc_active hs.temp matches 0 run attribute @s luck modifier remove evercraft:housing_dr

# Gentle pull-back notify: the home's tier/comfort were snapshotted to the
# recovery store on break, so offer the recover-by-rename path.
data modify storage evercraft:notify stage.c set value [{text:"A Hearthstone of yours was taken up while you were away. Place a new one and give it the same name to settle back in.",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 60
function evercraft:util/notify/emit
