# ============================================================
# Player Housing System — Tick (2s self-schedule)
# Handles: interaction detection, break detection, zone checks, particles
# ============================================================

# Self-schedule first so loop never dies
schedule function evercraft:housing/tick 2s replace

# Detect right-click on hearthstone interaction entities
# OPT: Existence gate — skip entity scan + NBT read when no hearthstones exist
execute if entity @e[type=interaction,tag=HS.Interact,limit=1] as @e[type=interaction,tag=HS.Interact] at @s if data entity @s interaction run function evercraft:housing/on_interact
execute if entity @e[type=interaction,tag=HS.Interact,limit=1] as @e[type=interaction,tag=HS.Interact] at @s if data entity @s interaction run data remove entity @s interaction

# OPT: All marker checks (break, particles) consolidated into 1 entity scan
# OPT-77: Proximity gate — skip markers with no player within 64 blocks
execute as @e[type=marker,tag=HS.Marker] at @s if entity @a[distance=..64,limit=1] run function evercraft:housing/tick_marker

# Validate stash barrel markers (clean up if barrel block broken)
# OPT-77: Existence gate + proximity gate — only check near players (barrels don't break unloaded)
execute if entity @e[type=marker,tag=HS.Stash,limit=1] as @e[type=marker,tag=HS.Stash] at @s if entity @a[distance=..64,limit=1] run function evercraft:housing/stash/validate_containers

# Multi-home one-time migration (legacy single home -> slot 1).
# Existence-gated on a homeowner whose hs.active pointer is still unset
# (un-migrated). slot/migrate self-disables (sets hs.active), so once every
# legacy homeowner has been touched this scan matches nobody. Home-less
# players never enter this @a scan and are initialised lazily when they
# first place a Hearthstone (setup_hearthstone sets hs.active).
execute as @a[scores={hs.tier=1..}] unless score @s hs.active matches 0..5 run function evercraft:housing/slot/migrate

# Zone checks + visitor detection for all players with homes
# OPT: 2 @a[scores={hs.tier=1..}] scans → 1
execute as @a[scores={hs.tier=1..}] at @s run function evercraft:housing/zone/tick_player

# House passive proc — Hearth's Blessing (10s buff every 5 min, per-player gametime
# checkpoint). Rides this existing per-home tick (no new scheduler). Gate the gametime
# read + per-player loop on a homeowner existing so it's free on a home-less world.
# OPT: 1 time-query + 1 @a scan, only when someone owns a home.
execute if entity @a[scores={hs.tier=1..},limit=1] store result score #hb_now ec.var run time query gametime
execute if entity @a[scores={hs.tier=1..},limit=1] as @a[scores={hs.tier=1..}] at @s run function evercraft:inscription/procs/house/proc

# Clear visiting tag from players no longer near any home (checked per-player)
execute as @a[tag=hs.visiting] at @s run function evercraft:housing/zone/visitor_leave_check

# Tag new snow/iron golems (OPT: throttled to every 5th tick = ~10s, golem construction is rare)
scoreboard players add #hs_golem_cd ec.var 1
execute if score #hs_golem_cd ec.var matches 5.. run scoreboard players set #hs_golem_cd ec.var 0
execute if score #hs_golem_cd ec.var matches 0 if entity @e[type=snow_golem,tag=!hs.checked,limit=1] run function evercraft:housing/golem/tag_new
execute if score #hs_golem_cd ec.var matches 0 if entity @e[type=snow_golem,tag=!gs.checked,limit=1] run function evercraft:guild/golem/tag_new
execute if score #hs_golem_cd ec.var matches 0 if entity @e[type=iron_golem,tag=!hs.ig_checked,limit=1] run function evercraft:housing/iron_guard/tag_new
execute if score #hs_golem_cd ec.var matches 0 if entity @e[type=iron_golem,tag=!gs.ig_checked,limit=1] run function evercraft:guild/iron_guard/tag_new

# Iron guard creeper handling (one-shot + explosion disable)
execute if entity @e[type=iron_golem,tag=hs.iron_guard,limit=1] run function evercraft:housing/iron_guard/tick
execute if entity @e[type=iron_golem,tag=gs.iron_guard,limit=1] run function evercraft:guild/iron_guard/tick

# Home companion tick (wandering, interactions, passive RP)
execute if entity @e[type=chicken, tag=HomeCompanion, limit=1] run function evercraft:companions/handler/home/tick

# SP5 placed-companion tick (sit/wander toggle, interactions). Existence-gated like the home tick.
execute if entity @e[type=chicken, tag=PlacedCompanion, limit=1] run function evercraft:companions/handler/placed/tick

# Stash label visibility — show only when a player holds the labeler
# OPT: Gate entire block — skip all stash display scans when no StashDisplay entities exist
execute if entity @e[type=text_display,tag=HS.StashDisplay,limit=1] run function evercraft:housing/stash/label_visibility_tick
