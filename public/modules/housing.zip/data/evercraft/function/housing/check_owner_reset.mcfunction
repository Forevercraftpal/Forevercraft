# ============================================================
# Check if this player owns the broken hearthstone — clear THAT slot
# Run as: each player with hs.tier >= 1 (called per-player from on_break)
# The broken marker's gs_id is in storage evercraft:guidestone remove_id.
#
# MULTI-HOME: a player may own up to 5 homes; the broken one can be in ANY
# slot, not just the active mirror. Find the slot whose hs.h<N>_gs matches,
# clear that slot's columns, then fix up the active pointer + mirror so the
# ~40 cross-system readers stay consistent.
# ============================================================

# Skip the player who is mid-relocate: confirm_relocate tears down the old
# marker on purpose and rewrites that slot itself, so we must NOT clear or
# re-point their slot here (it would corrupt the in-progress relocation).
execute if entity @s[tag=HS.Relocating] run return fail

# Get the remove_id into the find input score
execute store result score #hs_find_gs hs.temp run data get storage evercraft:guidestone remove_id

# Which of THIS player's slots holds the broken home? (0 = none -> not the owner)
function evercraft:housing/slot/find_by_gs
execute if score #hs_find_slot hs.temp matches 0 run return fail

# Online owner matched — flag it so on_break does NOT also enqueue a deferred
# reset (the offline-orphan queue is only for breaks no online owner caught).
scoreboard players set #hs_cor_hit hs.temp 1

# This player owns the broken home in slot #hs_find_slot. Snapshot it into the
# name-keyed recovery store BEFORE the columns are zeroed (AU31-Q2), so the
# owner can place + rename a fresh Hearthstone to the same name and recover
# the home's tier + comfort. Skips the default "Home" + sets hrow.name (the
# display name) for the notify below. Sits AFTER the relocate-guard (above) so
# an in-progress relocation never tombstones its own home.
execute store result storage evercraft:housing cor.n int 1 run scoreboard players get #hs_find_slot hs.temp
function evercraft:housing/slot/snapshot_to_recovery with storage evercraft:housing cor

# Clear that slot.
function evercraft:housing/slot/clear_slot with storage evercraft:housing cor

# Recount occupied homes after the clear
function evercraft:housing/slot/recount

# If the cleared slot was the ACTIVE one, the mirror is now stale — re-point
# active to the lowest remaining occupied slot (or 0 if none) + refresh mirror.
execute if score @s hs.active = #hs_find_slot hs.temp run function evercraft:housing/slot/repoint_after_clear

# If they were in zone, clean up (mirror may have just been zeroed/repointed)
execute if score @s hs.in_zone matches 1 run function evercraft:housing/zone/leave
scoreboard players set @s hs.in_zone 0

# ─── Player-facing copy (AU31-Q2 §3) ───
# NAMED home: its tier + comfort were snapshotted — point the owner at the
# recover-by-rename path. UNNAMED ("Home"): nothing was kept (mass-collision
# guard) — keep it honest, no recovery promise.
# Stash the name into cor.name (a per-flow buffer that lookup_name never
# touches) so the deferred action-bar queue resolves the {nbt:...} at render
# time without a clobber window on the transient hrow.name.
data modify storage evercraft:housing cor.name set from storage evercraft:housing hrow.name
execute unless data storage evercraft:housing {hrow:{name:"Home"}} run data modify storage evercraft:notify stage.c set value [{text:"Your Hearthstone ",color:"gold"},{text:"«",color:"yellow"},{nbt:"cor.name",storage:"evercraft:housing",color:"yellow",bold:true},{text:"»",color:"yellow"},{text:" was taken up. Its tier and comfort are kept safe.",color:"gold"}]
execute unless data storage evercraft:housing {hrow:{name:"Home"}} run scoreboard players set #ndur ec.temp 60
execute unless data storage evercraft:housing {hrow:{name:"Home"}} run function evercraft:util/notify/emit
execute unless data storage evercraft:housing {hrow:{name:"Home"}} run data modify storage evercraft:notify stage.c set value [{text:"Place a new Hearthstone and name it the same to settle back in.",color:"yellow"}]
execute unless data storage evercraft:housing {hrow:{name:"Home"}} run scoreboard players set #ndur ec.temp 60
execute unless data storage evercraft:housing {hrow:{name:"Home"}} run function evercraft:util/notify/emit
execute if data storage evercraft:housing {hrow:{name:"Home"}} run data modify storage evercraft:notify stage.c set value [{text:"Your Hearthstone was taken up. Place a new one to settle in again.",color:"gold"}]
execute if data storage evercraft:housing {hrow:{name:"Home"}} run scoreboard players set #ndur ec.temp 45
execute if data storage evercraft:housing {hrow:{name:"Home"}} run function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.6 1.2
