# Pet-Defend notification — fired by strike_home at most once per 3 minutes (gate lives in
# strike_home via hs.def_msg_t). Shows the action-bar line, plays the cue, and stamps the time.
# Run as @s = player, at player position.
data modify storage evercraft:notify stage.c set value [{text:"Your pets defend the homestead!",color:"yellow",italic:true}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.wolf_puglin.ambient player @s ~ ~ ~ 0.5 1.2
# Stamp last-notify gametime so the next message waits another 3 minutes.
execute store result score @s hs.def_msg_t run time query gametime
