# Home Pet Warp Strike — Housing Zone Orchestrator
# Runs as: player in home zone (Tier 3+)
# All tamed pets in the area warp strike nearby hostiles

# Must have hostiles nearby (skip if peaceful home)
execute unless entity @e[type=#evercraft:combat_targets,distance=..24,limit=1] run return 0

# Must have pets nearby
execute unless entity @e[type=#evercraft:home_pets,distance=..24,limit=1] run return 0

# Calculate damage based on player bonuses (Beastmaster, Wild Trim, Beastlord, Moon)
function evercraft:housing/pet_warp/calc_damage

# Each home pet within 24 blocks performs a warp strike
# Skip sitting pets — only standing pets warp strike
execute at @s as @e[type=#evercraft:home_pets,distance=..24,nbt=!{Sitting:1b}] run function evercraft:housing/pet_warp/pet_strike

# Notify player — throttled to once every 3 minutes (3600t). The strike itself keeps firing on
# its own hs.warp_cd while hostiles linger; without this gate the message spammed the action bar
# every cooldown cycle (Joseph flagged 2026-06-02). Compare gametime against the last-notify stamp.
execute store result score #def_now ec.temp run time query gametime
scoreboard players operation #def_el ec.temp = #def_now ec.temp
scoreboard players operation #def_el ec.temp -= @s hs.def_msg_t
execute if score #def_el ec.temp matches 3600.. run function evercraft:housing/pet_warp/notify_defend
