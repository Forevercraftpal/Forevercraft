# ============================================================
# Slot helper — re-point the active slot after the ACTIVE home was cleared
# Run as: @s = the player
# The active slot's columns were just zeroed, so the mirror is stale.
# Pick the lowest remaining OCCUPIED slot as the new active (or 0 = none),
# then refresh the mirror from it. SOLE non-(set_active/migrate) writer of
# hs.active is gated here behind "active home was removed", which keeps the
# pointer valid; it does not contend with set_active (different code path).
# ============================================================

# Find the lowest occupied slot; default 0 (no homes left)
scoreboard players set @s hs.active 0
execute if score @s hs.h5_tier matches 1.. run scoreboard players set @s hs.active 5
execute if score @s hs.h4_tier matches 1.. run scoreboard players set @s hs.active 4
execute if score @s hs.h3_tier matches 1.. run scoreboard players set @s hs.active 3
execute if score @s hs.h2_tier matches 1.. run scoreboard players set @s hs.active 2
execute if score @s hs.h1_tier matches 1.. run scoreboard players set @s hs.active 1

# Refresh the legacy mirror from the new active slot (clears it if active=0)
function evercraft:housing/slot/load_active

# Drop any lingering home buff so the next zone tick re-evaluates cleanly
scoreboard players set @s hs.in_zone 0
attribute @s luck modifier remove evercraft:housing_dr
