# UX ADDITION 1 — hand the Home Deed for the ACTIVE slot + welcome line.
# Run as: @s = the player (all border_prompt gates already passed).
# Dispatches on hs.active so give_deed targets the right slot. give_deed
# bakes the slot into the book's custom_data and emits the write+sign hint;
# we lead with a one-time contextual welcome so the player understands WHY a
# deed just appeared (their old, now-named-homes feature, home is unnamed).

# Contextual welcome (fires before give_deed's write+sign hint).
data modify storage evercraft:notify stage.c set value [{text:"⌂ ",color:"gold"},{text:"This home doesn't have a name yet.",color:"yellow"},{text:" Take the Home Deed to name it.",color:"gray"}]
scoreboard players set #ndur ec.temp 60
function evercraft:util/notify/emit

# Give the deed for whichever slot is active.
execute if score @s hs.active matches 1 run function evercraft:housing/slot/rename/give_deed {n:1}
execute if score @s hs.active matches 2 run function evercraft:housing/slot/rename/give_deed {n:2}
execute if score @s hs.active matches 3 run function evercraft:housing/slot/rename/give_deed {n:3}
execute if score @s hs.active matches 4 run function evercraft:housing/slot/rename/give_deed {n:4}
execute if score @s hs.active matches 5 run function evercraft:housing/slot/rename/give_deed {n:5}
