# ============================================================
# Home Deed — recover a name-keyed home after rename (AU31-Q2)
# Run as: @s = the player, called from slot/rename/extract AFTER the new name
# is applied (registry + marker). If @s archived a home under THIS name (broke
# / abandoned it earlier), restore its tier + comfort into the freshly-renamed
# slot, then consume the record (one-shot).
#
# INPUT (already set by extract):
#   #hs_deed_slot hs.temp = the renamed slot (1-5)
#   #hs_deed_gs   hs.temp = that slot's gs_id
#   storage evercraft:housing deed.name = the just-applied name
#
# Guards (edge-case checklist §4):
#   - Keyed (owner_uuid, name) — never name-alone (foreign-name theft).
#   - Restore only into a FRESH Tier-1 / decor-0 slot (no overwrite of an
#     upgraded home; tie-break keeps the higher tier + adds decor).
#   - Consume the record on recover (dupe guard).
#   - No first-time grants / no netherite refund (recovery rides this path,
#     NOT setup_hearthstone, so the free Stash Label + place advancement +
#     welcome notifies never fire — re-grant cheese closed by construction).
# ============================================================

# Never recover the default "Home" (it was never snapshotted; mass-collision).
execute if data storage evercraft:housing {deed:{name:"Home"}} run return 0

# Recovery store empty -> nothing to do.
execute unless data storage evercraft:housing recovery[0] run return 0

# The renamed slot must be a FRESH home: Tier 1, decor 0. An upgraded/decorated
# slot is NOT overwritten here (the tie-break path inside recover_apply handles
# tier> archived). Read the slot's current tier + decor via a tiny macro.
execute store result storage evercraft:housing tr.n int 1 run scoreboard players get #hs_deed_slot hs.temp
function evercraft:housing/slot/rename/read_slot with storage evercraft:housing tr
# read_slot sets #hs_tr_tier / #hs_tr_decor hs.temp from the slot columns.
# Only a Tier-1 slot is a recovery candidate (a higher tier means the player
# upgraded this fresh stone before signing the deed — leave it, tie-break in
# recover_apply still keeps the higher tier).
execute unless score #hs_tr_tier hs.temp matches 1 run return 0

# Find @s's archived record for this name. Stash the key (uuid + name) and walk.
data modify storage evercraft:housing tr_key set value {u0:0,u1:0,u2:0,u3:0,name:"Home"}
execute store result storage evercraft:housing tr_key.u0 int 1 run data get entity @s UUID[0]
execute store result storage evercraft:housing tr_key.u1 int 1 run data get entity @s UUID[1]
execute store result storage evercraft:housing tr_key.u2 int 1 run data get entity @s UUID[2]
execute store result storage evercraft:housing tr_key.u3 int 1 run data get entity @s UUID[3]
data modify storage evercraft:housing tr_key.name set from storage evercraft:housing deed.name

# Pull the matching record (if any) into tr_match, then apply + consume it.
data remove storage evercraft:housing tr_match
function evercraft:housing/slot/rename/find_record with storage evercraft:housing tr_key
execute if data storage evercraft:housing tr_match run function evercraft:housing/slot/rename/recover_apply
