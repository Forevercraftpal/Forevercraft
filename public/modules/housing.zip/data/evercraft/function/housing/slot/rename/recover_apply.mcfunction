# ============================================================
# Home Deed recovery — apply a consumed recovery record to the renamed slot
# Run as: @s = the player. INPUT:
#   storage evercraft:housing tr_match = {u0..u3,name,tier,decor,pmode}
#   #hs_deed_slot hs.temp = the renamed slot (fresh, Tier 1 / decor 0)
#   #hs_deed_gs   hs.temp = that slot's gs_id (live marker key)
#
# Writes the archived tier / comfort / protection-mode into the slot, re-syncs
# the mirror if it's the active home, re-stamps the live marker, and notifies.
# Tie-break (§5.3): keep the HIGHER of (current slot tier, archived tier) +
# ADDITIVELY merge decor. The slot is a fresh Tier-1/decor-0 home here, so the
# result is simply the archived tier + archived decor — but the max/add form
# is future-proof if a player upgraded the stone before signing the deed.
# Protection (§5.4): restore the chosen pmode, but leave protection itself OFF
# (_prot = 0) so a Reinforced lockdown never silently re-engages.
# No first-time grants / no netherite refund (this is NOT setup_hearthstone).
# ============================================================

# Pull the archived values into scratch scores.
execute store result score #hs_tr_atier hs.temp run data get storage evercraft:housing tr_match.tier
execute store result score #hs_tr_adecor hs.temp run data get storage evercraft:housing tr_match.decor
execute store result score #hs_tr_apmode hs.temp run data get storage evercraft:housing tr_match.pmode

# Tie-break: result tier = max(current slot tier, archived tier).
# (current = #hs_tr_tier, captured in try_recover; = 1 for a fresh slot.)
scoreboard players operation #hs_tr_rtier hs.temp = #hs_tr_tier hs.temp
execute if score #hs_tr_atier hs.temp > #hs_tr_rtier hs.temp run scoreboard players operation #hs_tr_rtier hs.temp = #hs_tr_atier hs.temp

# Result decor = current decor + archived decor (additive merge).
scoreboard players operation #hs_tr_rdecor hs.temp = #hs_tr_decor hs.temp
scoreboard players operation #hs_tr_rdecor hs.temp += #hs_tr_adecor hs.temp

# Write the restored values into the renamed slot's columns (macro on slot N).
data modify storage evercraft:housing tr.n set value 0
execute store result storage evercraft:housing tr.n int 1 run scoreboard players get #hs_deed_slot hs.temp
execute store result storage evercraft:housing tr.tier int 1 run scoreboard players get #hs_tr_rtier hs.temp
execute store result storage evercraft:housing tr.decor int 1 run scoreboard players get #hs_tr_rdecor hs.temp
execute store result storage evercraft:housing tr.pmode int 1 run scoreboard players get #hs_tr_apmode hs.temp
function evercraft:housing/slot/rename/write_slot with storage evercraft:housing tr

# If the renamed slot is the ACTIVE home, re-sync the legacy mirror so the ~40
# cross-system readers see the restored tier/comfort immediately.
execute if score @s hs.active = #hs_deed_slot hs.temp run function evercraft:housing/slot/load_active

# Re-stamp the live marker's owner_tier + protect (protection OFF on restore).
execute as @e[type=marker,tag=HS.Marker,tag=!HS.Pending] if score @s ec.gs_id = #hs_deed_gs hs.temp run function evercraft:housing/slot/rename/restamp_marker with storage evercraft:housing tr

# ─── Recovery-success copy (§3) ───
# Render the name from deed.name (the just-applied name == tr_match.name by
# construction) — it is STABLE storage, so the deferred action-bar queue
# resolves the {nbt:...} at render time even after tr_match is removed below.
data modify storage evercraft:notify stage.c set value [{text:"Welcome home! ",color:"green"},{text:"«",color:"gold"},{nbt:"deed.name",storage:"evercraft:housing",color:"gold",bold:true},{text:"» remembers you.",color:"green"}]
scoreboard players set #ndur ec.temp 60
function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Tier ",color:"gold"},{score:{name:"#hs_tr_rtier",objective:"hs.temp"},color:"gold",bold:true},{text:" and Comfort ",color:"gold"},{score:{name:"#hs_tr_rdecor",objective:"hs.temp"},color:"gold",bold:true},{text:" restored.",color:"gold"}]
scoreboard players set #ndur ec.temp 60
function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"« ",color:"gold"},{nbt:"deed.name",storage:"evercraft:housing",color:"gold"},{text:" » restored",color:"gold"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.beacon.activate master @s ~ ~ ~ 0.6 1.2
execute at @s run particle minecraft:enchant ~ ~1 ~ 0.4 0.6 0.4 0.5 25

# Tidy the consumed record buffer.
data remove storage evercraft:housing tr_match
