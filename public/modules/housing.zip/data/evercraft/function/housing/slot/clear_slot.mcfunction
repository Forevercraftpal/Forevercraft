# ============================================================
# Slot helper — zero out slot N's columns (home removed/abandoned)
# Run as: @s = the player
# Macro arg: {n:<1-5>}  (the slot to clear)
# Clears the persistent columns ONLY. Caller is responsible for recount,
# active-pointer fixup (slot/repoint_after_clear), forceload remove, and
# any marker/registry teardown. Used by check_owner_reset + GUI [Abandon].
# ============================================================

$scoreboard players set @s hs.h$(n)_tier 0
$scoreboard players set @s hs.h$(n)_x 0
$scoreboard players set @s hs.h$(n)_y 0
$scoreboard players set @s hs.h$(n)_z 0
$scoreboard players set @s hs.h$(n)_dim 0
$scoreboard players set @s hs.h$(n)_gs 0
$scoreboard players set @s hs.h$(n)_decor 0
$scoreboard players set @s hs.h$(n)_prot 0
$scoreboard players set @s hs.h$(n)_pmode 0
