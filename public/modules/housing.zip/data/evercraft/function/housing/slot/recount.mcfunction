# ============================================================
# Slot helper — recompute hs.homes (count of OCCUPIED slots)
# Run as: @s = the player
# hs.homes = number of slots N with hs.h<N>_tier >= 1.
# Cheap (5 conditional adds); call after any slot add/remove so the GUI
# header + next-free logic stay in sync. Shared writer of hs.homes.
# ============================================================

scoreboard players set @s hs.homes 0
execute if score @s hs.h1_tier matches 1.. run scoreboard players add @s hs.homes 1
execute if score @s hs.h2_tier matches 1.. run scoreboard players add @s hs.homes 1
execute if score @s hs.h3_tier matches 1.. run scoreboard players add @s hs.homes 1
execute if score @s hs.h4_tier matches 1.. run scoreboard players add @s hs.homes 1
execute if score @s hs.h5_tier matches 1.. run scoreboard players add @s hs.homes 1
