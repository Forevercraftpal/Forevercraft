# ============================================================
# Slot helper — stamp slot N's deed-given flag = 1 (macro)
# Run as: @s = the player. Macro arg: {n:<1-5>}
# Marks slot N as "already handed a Home Deed / no contextual prompt needed".
# Called by setup_hearthstone (fresh in-place claim) and by the contextual
# border prompt after it gives a deed. Shared writer of hs.h<N>_dg.
# ============================================================
$scoreboard players set @s hs.h$(n)_dg 1
