# Home Deed — duplicate-name rejection (AU31-Q2 §4)
# Run as: @s = the player. The proposed name already belongs to one of @s's
# other homes, which would make name-keyed recovery ambiguous. The deed is NOT
# consumed (so the player can re-sign with a different name) — only a notify.
data modify storage evercraft:notify stage.c set value [{text:"You already have a home with that name. Give this one a different name.",color:"yellow"}]
scoreboard players set #ndur ec.temp 55
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 0.6 0.8
