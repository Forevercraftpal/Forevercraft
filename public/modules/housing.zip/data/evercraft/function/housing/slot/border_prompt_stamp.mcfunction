# UX ADDITION 1 — stamp the ACTIVE slot's deed-given flag = 1.
# Run as: @s = the player. Dispatches on hs.active. This is the persistent
# once-per-home guard: after a contextual prompt (or the discovery that the
# home is already named), the border prompt never fires for this home again.
# Shared writer of hs.h<N>_dg with slot/stamp_dg (mutually exclusive paths).
execute if score @s hs.active matches 1 run scoreboard players set @s hs.h1_dg 1
execute if score @s hs.active matches 2 run scoreboard players set @s hs.h2_dg 1
execute if score @s hs.active matches 3 run scoreboard players set @s hs.h3_dg 1
execute if score @s hs.active matches 4 run scoreboard players set @s hs.h4_dg 1
execute if score @s hs.active matches 5 run scoreboard players set @s hs.h5_dg 1
