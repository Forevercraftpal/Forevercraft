# Home Deed recovery — write restored tier/decor/pmode into slot N (macro)
# Run as: @s = the player. Macro args: {n,tier,decor,pmode}.
# Restores the home stats into the slot columns. Protection itself stays OFF
# (_prot = 0, set fresh) per §5.4 — only the chosen pmode is carried, so a
# Reinforced lockdown never silently re-engages on recovery.
$scoreboard players set @s hs.h$(n)_tier $(tier)
$scoreboard players set @s hs.h$(n)_decor $(decor)
$scoreboard players set @s hs.h$(n)_pmode $(pmode)
$scoreboard players set @s hs.h$(n)_prot 0
