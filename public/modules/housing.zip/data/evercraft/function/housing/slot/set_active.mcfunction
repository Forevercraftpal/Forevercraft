# ============================================================
# Slot helper — make slot N the ACTIVE home (re-point the mirror)
# Run as: @s = the player
# INPUT: #hs_set_slot hs.temp = the slot (1-5) to activate
# Flow (spec 2.5 [Set active]):
#   1. save_active  — flush current mirror -> the OLD active slot
#   2. hs.active = N
#   3. load_active  — pull slot N -> the mirror (re-points zone buffs,
#      codex-tp default, laborer home, remote-stash target, and all
#      cross-system tier/decor readers to home N)
#   4. clean zone re-entry so the new home's buffs + DR re-apply
# SOLE WRITER of hs.active alongside slot/migrate. One-writer respected:
# set_active + migrate are the only two functions that write hs.active.
# ============================================================

# Guard: target must be an OCCUPIED slot (don't point at an empty/locked one)
execute unless score #hs_set_slot hs.temp matches 1..5 run return fail

# Pick the column to test by the requested slot
scoreboard players set #hs_set_ok hs.temp 0
execute if score #hs_set_slot hs.temp matches 1 if score @s hs.h1_tier matches 1.. run scoreboard players set #hs_set_ok hs.temp 1
execute if score #hs_set_slot hs.temp matches 2 if score @s hs.h2_tier matches 1.. run scoreboard players set #hs_set_ok hs.temp 1
execute if score #hs_set_slot hs.temp matches 3 if score @s hs.h3_tier matches 1.. run scoreboard players set #hs_set_ok hs.temp 1
execute if score #hs_set_slot hs.temp matches 4 if score @s hs.h4_tier matches 1.. run scoreboard players set #hs_set_ok hs.temp 1
execute if score #hs_set_slot hs.temp matches 5 if score @s hs.h5_tier matches 1.. run scoreboard players set #hs_set_ok hs.temp 1
execute if score #hs_set_ok hs.temp matches 0 run return fail

# 1. Flush the current mirror into the OLD active slot
function evercraft:housing/slot/save_active

# 2. Re-point the active pointer
scoreboard players operation @s hs.active = #hs_set_slot hs.temp

# 3. Refresh the mirror from the new active slot
function evercraft:housing/slot/load_active

# 4. Force a clean zone re-entry (mirror confirm_relocate:82-83) so the
#    new home's tier buffs + housing_dr re-apply on the next zone tick.
scoreboard players set @s hs.in_zone 0
attribute @s luck modifier remove evercraft:housing_dr

return 1
