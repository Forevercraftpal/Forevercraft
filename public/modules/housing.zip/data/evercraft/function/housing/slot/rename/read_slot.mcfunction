# Home Deed recovery — read slot N's current tier + decor (macro)
# Run as: @s = the player. Macro arg: {n:<1-5>}.
# OUTPUT: #hs_tr_tier / #hs_tr_decor hs.temp = the slot's columns.
$execute store result score #hs_tr_tier hs.temp run scoreboard players get @s hs.h$(n)_tier
$execute store result score #hs_tr_decor hs.temp run scoreboard players get @s hs.h$(n)_decor
