# ============================================================
# Home Deed — write the new name into the guidestone registry entry
# Run as: @s = the player.
# INPUT: #hs_deed_gs hs.temp = the gs_id (registry entry id) to rename;
#        storage evercraft:housing deed.name = the new name string.
# Rebuilds evercraft:guidestone registry, swapping the `name` field on the
# entry whose id == #hs_deed_gs. Mirrors guidestone/remove_from_registry's
# rebuild idiom, but iterates a COPY in evercraft:housing rn_scan so it never
# disturbs guidestone's own temp_registry/check_entry buffers. Cold path.
# ============================================================

# Snapshot the registry into our scan buffer; clear the destination
data modify storage evercraft:housing rn_scan set from storage evercraft:guidestone registry
data modify storage evercraft:guidestone registry set value []

# Walk + rebuild
function evercraft:housing/slot/rename/registry_step
