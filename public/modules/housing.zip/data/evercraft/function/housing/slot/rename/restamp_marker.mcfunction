# Home Deed recovery — re-stamp the live marker after a recover (macro)
# Run as: @s = the matched HS.Marker. Macro args: {tier,...}.
# The recovered home's tier drives marker-side reads (garden boost gate in
# tick_marker, etc.), so refresh data.owner_tier. Protection re-arms OFF on
# recovery (§5.4), so data.protect is forced 0 — matching write_slot's _prot.
$data modify entity @s data.owner_tier set value $(tier)
data modify entity @s data.protect set value 0
