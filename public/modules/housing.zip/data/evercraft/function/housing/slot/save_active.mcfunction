# ============================================================
# Slot helper — flush the legacy MIRROR back into the ACTIVE slot
# Run as: @s = the player
# Reads hs.active (1-5); copies hs.tier/hs.home_*/etc. -> hs.h<active>_*.
# Called before re-pointing the active slot (set_active) so any in-zone
# mutations to the mirror persist on the slot they belong to. No-op if
# hs.active=0 (nothing bound to flush).
# ============================================================

execute unless score @s hs.active matches 1..5 run return 0

execute store result storage evercraft:housing ld.n int 1 run scoreboard players get @s hs.active
function evercraft:housing/slot/save_one with storage evercraft:housing ld
