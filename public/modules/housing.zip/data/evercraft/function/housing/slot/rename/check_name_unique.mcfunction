# ============================================================
# Home Deed — per-owner name-uniqueness check (AU31-Q2 §4)
# Run as: @s = the player. Reads the proposed name from
#   storage evercraft:housing deed.name
# and scans @s's 5 home slots (skipping the slot being renamed,
# #hs_deed_slot hs.temp). If ANOTHER occupied slot already carries this exact
# name, sets #hs_name_dup hs.temp = 1 (caller rejects + leaves the deed).
#
# The default "Home" is exempt — it's the unnamed sentinel, allowed to repeat,
# and is never recoverable, so two "Home"s create no recovery ambiguity.
# Cold path (rename only): 5 registry name lookups via homes/lookup_name.
# ============================================================

scoreboard players set #hs_name_dup hs.temp 0

# "Home" repeats are fine — skip the whole check.
execute if data storage evercraft:housing {deed:{name:"Home"}} run return 0

# Stash the proposed name for the per-slot macro comparison.
data modify storage evercraft:housing nu.name set from storage evercraft:housing deed.name

# Walk the 5 slots; compare each occupied OTHER slot's registry name.
execute store result storage evercraft:housing nu.self int 1 run scoreboard players get #hs_deed_slot hs.temp
data modify storage evercraft:housing nu.slot set value 1
function evercraft:housing/slot/rename/check_name_step with storage evercraft:housing nu
data modify storage evercraft:housing nu.slot set value 2
function evercraft:housing/slot/rename/check_name_step with storage evercraft:housing nu
data modify storage evercraft:housing nu.slot set value 3
function evercraft:housing/slot/rename/check_name_step with storage evercraft:housing nu
data modify storage evercraft:housing nu.slot set value 4
function evercraft:housing/slot/rename/check_name_step with storage evercraft:housing nu
data modify storage evercraft:housing nu.slot set value 5
function evercraft:housing/slot/rename/check_name_step with storage evercraft:housing nu
