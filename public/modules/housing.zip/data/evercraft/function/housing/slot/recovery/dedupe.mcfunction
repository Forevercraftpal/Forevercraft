# ============================================================
# Housing recovery — drop any existing record for (owner, name) == rec_new
# Run as: @s = the owner. Reads the key off storage evercraft:housing rec_new
# ({u0..u3,name,...}) and removes a prior record with the SAME (uuid, name)
# so a fresh snapshot supersedes it (most-recent wins; no duplicate stacking
# that could be recovered twice). Rebuild-into-fresh-list idiom (mirrors
# guidestone/remove_from_registry): snapshot -> empty -> copy keepers back.
# ============================================================

# Nothing to scan -> done.
execute unless data storage evercraft:housing recovery[0] run return 0

# Pull the match key into macro storage. The 4 uuid ints + the name string
# together form the (owner, name) key; reuse rec_new's own fields.
data modify storage evercraft:housing rd_key set value {u0:0,u1:0,u2:0,u3:0,name:"Home"}
data modify storage evercraft:housing rd_key.u0 set from storage evercraft:housing rec_new.u0
data modify storage evercraft:housing rd_key.u1 set from storage evercraft:housing rec_new.u1
data modify storage evercraft:housing rd_key.u2 set from storage evercraft:housing rec_new.u2
data modify storage evercraft:housing rd_key.u3 set from storage evercraft:housing rec_new.u3
data modify storage evercraft:housing rd_key.name set from storage evercraft:housing rec_new.name

# Snapshot -> empty -> walk + copy keepers.
data modify storage evercraft:housing rec_scan set from storage evercraft:housing recovery
data modify storage evercraft:housing recovery set value []
function evercraft:housing/slot/recovery/dedupe_step with storage evercraft:housing rd_key
