# ============================================================
# Home Deed — give the writable book to rename home N
# Run as: @s = the player (called `on target` from homes/check_clicks)
# Macro arg: {n:<1-5>}
# Mirrors the buddy/guild signed-book idiom: give a writable_book, the player
# writes the name + signs, an advancement (evercraft:housing/signed_deed)
# fires extract. The target slot is BAKED into the book's custom_data so
# extract knows which home to rename (custom_data.slot).
# ============================================================

# Guard: the slot must be occupied
$execute unless score @s hs.h$(n)_tier matches 1.. run return fail

# UX ADDITION 1 — handing a deed for this slot means the player now has the
# means to name it: stamp the per-slot deed-given flag so the contextual
# home-zone border prompt never also fires for it. (Manage-Homes [Rename] and
# the border prompt both route through here, so the flag is set on either
# path.) The advancement still gates re-fires on holding a signed hs_deed.
$scoreboard players set @s hs.h$(n)_dg 1

# Give the Home Deed (writable book). evercraft_item:1b marks it as a pack
# item; hs_deed:1b is the signed-trigger key; slot carries the target home.
$give @s minecraft:writable_book[custom_name={text:"Home Deed",color:"gold",italic:false},custom_data={hs_deed:1b,evercraft_item:1b,slot:$(n)},writable_book_content={pages:["Write your home's name on this page and sign the deed!"]}] 1

# Close the menu so the player can open + write the book
execute at @s run function evercraft:housing/gui/close

data modify storage evercraft:notify stage.c set value [{text:"Write your home's name on page 1 of the deed and ",color:"yellow"},{text:"sign it",color:"green",bold:true},{text:" to rename it!",color:"yellow"}]
scoreboard players set #ndur ec.temp 60
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.experience_orb.pickup master @s ~ ~ ~ 0.5 1.5
