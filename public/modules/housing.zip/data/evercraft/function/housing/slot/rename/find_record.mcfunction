# ============================================================
# Home Deed recovery — find + consume the (owner, name) recovery record
# Macro args: {u0,u1,u2,u3,name} = the (owner, name) key.
# Copies the FIRST matching record into evercraft:housing tr_match, then
# REMOVES it from recovery (one-shot consume — dupe guard §4). Both the copy
# and the remove key on the same list-filter, so they hit the same element.
# If no record matches, tr_match stays unset (caller no-ops).
#
# (owner_uuid, name) match — never name-alone — closes foreign-name theft:
# typing another settler's home name finds no record under YOUR uuid.
# ============================================================

# Copy the first matching record out (leaves tr_match unset if none match).
$data modify storage evercraft:housing tr_match set from storage evercraft:housing recovery[{u0:$(u0),u1:$(u1),u2:$(u2),u3:$(u3),name:"$(name)"}]

# Consume it from the store (removes the first match — same element).
$data remove storage evercraft:housing recovery[{u0:$(u0),u1:$(u1),u2:$(u2),u3:$(u3),name:"$(name)"}]
