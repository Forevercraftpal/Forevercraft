# ============================================================
# UX ADDITION 3 — Guidestone Deed: extract the signed name + apply it to the
# guidestone's registry entry (the portal-menu label).
# Run as: @s = player who just signed a Guidestone Deed.
# Reached ONLY from slot/rename/extract (the dispatcher) when the held signed
# book carries custom_data.gs_deed. The advancement was already revoked there.
#
# Flow:
#   1. Read the target gs_id from the book's custom_data.gs_id.
#   2. Validate the id is real (>0) and still exists in the registry.
#   3. Pull page 1 raw text -> evercraft:housing deed.name.
#   4. Rewrite the registry entry's `name` (single source of truth for the
#      portal-menu label) via the SAME apply_registry rebuild the home deed
#      uses — keyed by #hs_deed_gs hs.temp = this gs_id.
#   5. Consume the book + feedback.
# Guidestones have no in-world name entity (their label is the registry name
# rendered in the menu), so there is no marker CustomName to update — unlike
# the home deed, which also stamps the HS.Marker CustomName.
# ============================================================

# 1. Read the target registry id from the book.
execute store result score #hs_deed_gs hs.temp run data get entity @s SelectedItem.components."minecraft:custom_data".gs_id
execute unless score #hs_deed_gs hs.temp matches 1.. run return fail

# 3. Extract page 1 raw text into the shared rename storage (reuses the home
#    deed's deed.name slot — both paths are single-threaded per player).
data modify storage evercraft:housing deed.name set from entity @s SelectedItem.components."minecraft:written_book_content".pages[0].raw

# Guard: refuse an empty name (player signed a blank page) — leave it unnamed.
execute if data storage evercraft:housing {deed:{name:""}} run return run function evercraft:housing/slot/rename/feedback_blank

# 4. Rewrite the matching registry entry's name (shared rebuild helper; it
#    keys on #hs_deed_gs hs.temp + reads deed.name).
function evercraft:housing/slot/rename/apply_registry

# 5. Consume the deed + feedback.
clear @s minecraft:written_book[custom_data~{gs_deed:1b}] 1
function evercraft:housing/slot/rename/feedback_gs with storage evercraft:housing deed
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.6 1.4
