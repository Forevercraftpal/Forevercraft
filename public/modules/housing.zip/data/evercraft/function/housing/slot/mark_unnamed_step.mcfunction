# one-time migration — registry blank-name rebuild step (recursive)
# Pops un_scan[0]; if its id == #hs_unnamed_gs, set its name to "";
# append the (possibly-modified) entry back onto the live registry; recurse.
# Mirrors slot/rename/registry_step exactly but writes an empty name.

execute unless data storage evercraft:housing un_scan[0] run return 0

# Move the head entry into a single-entry work slot
data modify storage evercraft:housing un_one set from storage evercraft:housing un_scan[0]
data remove storage evercraft:housing un_scan[0]

# If this is the target entry, blank its name
execute store result score #hs_un_id hs.temp run data get storage evercraft:housing un_one.id
execute if score #hs_un_id hs.temp = #hs_unnamed_gs hs.temp run data modify storage evercraft:housing un_one.name set value ""

# Append it back (modified or not) and recurse
data modify storage evercraft:guidestone registry append from storage evercraft:housing un_one
function evercraft:housing/slot/mark_unnamed_step
