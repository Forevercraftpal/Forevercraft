# ============================================================
# Slot helper — sum home tier + decor across ALL occupied slots
# Run as: @s = the player
# OUTPUT:
#   #hs_dr_tier  hs.temp = sum of hs.h<N>_tier  over occupied slots (1..5)
#   #hs_dr_decor hs.temp = sum of hs.h<N>_decor over occupied slots (1..5)
# Used by dream_rank/calculate so progression rewards EVERY home a player
# keeps, not just the active one (Joseph: DR sums across all occupied homes).
# Empty slots hold 0 in their tier/decor columns, so a plain add of all five
# is correct — but we existence-gate on tier>=1 anyway to skip stale decor on
# a (defensively) zeroed-tier-but-nonzero-decor slot.
# ============================================================

# --- Tier sum ---
scoreboard players set #hs_dr_tier hs.temp 0
execute if score @s hs.h1_tier matches 1.. run scoreboard players operation #hs_dr_tier hs.temp += @s hs.h1_tier
execute if score @s hs.h2_tier matches 1.. run scoreboard players operation #hs_dr_tier hs.temp += @s hs.h2_tier
execute if score @s hs.h3_tier matches 1.. run scoreboard players operation #hs_dr_tier hs.temp += @s hs.h3_tier
execute if score @s hs.h4_tier matches 1.. run scoreboard players operation #hs_dr_tier hs.temp += @s hs.h4_tier
execute if score @s hs.h5_tier matches 1.. run scoreboard players operation #hs_dr_tier hs.temp += @s hs.h5_tier

# --- Decor sum (only count decor on slots that actually hold a home) ---
scoreboard players set #hs_dr_decor hs.temp 0
execute if score @s hs.h1_tier matches 1.. run scoreboard players operation #hs_dr_decor hs.temp += @s hs.h1_decor
execute if score @s hs.h2_tier matches 1.. run scoreboard players operation #hs_dr_decor hs.temp += @s hs.h2_decor
execute if score @s hs.h3_tier matches 1.. run scoreboard players operation #hs_dr_decor hs.temp += @s hs.h3_decor
execute if score @s hs.h4_tier matches 1.. run scoreboard players operation #hs_dr_decor hs.temp += @s hs.h4_decor
execute if score @s hs.h5_tier matches 1.. run scoreboard players operation #hs_dr_decor hs.temp += @s hs.h5_decor
