# ============================================================
# Housing recovery — dedupe walk (recursive, macro-keyed)
# Macro args: {u0,u1,u2,u3,name} = the (owner, name) key to DROP.
# Walks rec_scan; copies every entry EXCEPT the one matching all five key
# fields back into recovery. Bounded recursion (<= 5-per-owner cap, small).
# ============================================================

# End of scan -> done.
execute unless data storage evercraft:housing rec_scan[0] run return 0

# Keep the head entry UNLESS it matches (u0,u1,u2,u3,name) exactly.
$execute unless data storage evercraft:housing rec_scan[0]{u0:$(u0),u1:$(u1),u2:$(u2),u3:$(u3),name:"$(name)"} run data modify storage evercraft:housing recovery append from storage evercraft:housing rec_scan[0]

# Advance + recurse.
data remove storage evercraft:housing rec_scan[0]
function evercraft:housing/slot/recovery/dedupe_step with storage evercraft:housing rd_key
