# ============================================================
# UX ADDITION 1 — contextual "name your home" prompt on zone entry
# Run as: @s = the player who JUST entered their own home zone.
# Called once from zone/enter (the out->in border transition), so it never
# runs while merely standing inside the zone.
#
# Fires the Home Deed give for the ACTIVE home IFF that home still needs a
# name. ONCE-PER-HOME guard (three independent gates, any one blocks):
#   1. hs.h<active>_dg == 0   -> a deed has never been handed for this slot.
#   2. the active home's guidestone-registry name is still ""  (unnamed) —
#      a named home is never re-prompted even if its flag were reset.
#   3. the player isn't already holding an unsigned Home Deed (inventory
#      check) — avoids stacking a 2nd deed if they re-enter before signing.
# After giving the deed we stamp hs.h<active>_dg = 1, so the prompt is
# strictly once per home (the flag is the persistent guard; gates 2+3 are
# belt-and-braces for forged/edge states).
# ============================================================

# Must have an active home slot.
execute unless score @s hs.active matches 1..5 run return fail

# GATE 3 — already holding an unsigned Home Deed? then don't hand another.
execute if items entity @s container.* writable_book[custom_data~{hs_deed:1b}] run return fail
execute if items entity @s weapon.* writable_book[custom_data~{hs_deed:1b}] run return fail

# GATE 1 — has a deed already been handed for the active slot? Dispatch on
# the active pointer to read that slot's flag; bail unless it is still 0.
execute if score @s hs.active matches 1 unless score @s hs.h1_dg matches 0 run return fail
execute if score @s hs.active matches 2 unless score @s hs.h2_dg matches 0 run return fail
execute if score @s hs.active matches 3 unless score @s hs.h3_dg matches 0 run return fail
execute if score @s hs.active matches 4 unless score @s hs.h4_dg matches 0 run return fail
execute if score @s hs.active matches 5 unless score @s hs.h5_dg matches 0 run return fail

# GATE 2 — confirm the active home's registry name is still blank (unnamed).
# Resolve the active slot's gs_id, then look it up in the guidestone registry.
scoreboard players set #hs_bp_named hs.temp 0
execute if score @s hs.active matches 1 run scoreboard players operation #hs_bp_gs hs.temp = @s hs.h1_gs
execute if score @s hs.active matches 2 run scoreboard players operation #hs_bp_gs hs.temp = @s hs.h2_gs
execute if score @s hs.active matches 3 run scoreboard players operation #hs_bp_gs hs.temp = @s hs.h3_gs
execute if score @s hs.active matches 4 run scoreboard players operation #hs_bp_gs hs.temp = @s hs.h4_gs
execute if score @s hs.active matches 5 run scoreboard players operation #hs_bp_gs hs.temp = @s hs.h5_gs
function evercraft:housing/slot/border_prompt_named
# border_prompt_named sets #hs_bp_named = 1 if the registry entry already has
# a non-empty name -> in that case do NOT prompt (stamp flag so we stop checking).
execute if score #hs_bp_named hs.temp matches 1 run function evercraft:housing/slot/border_prompt_stamp
execute if score #hs_bp_named hs.temp matches 1 run return 0

# All gates passed: hand the Home Deed for the active slot, then stamp the
# flag so this never fires again for this home.
function evercraft:housing/slot/border_prompt_give
function evercraft:housing/slot/border_prompt_stamp
