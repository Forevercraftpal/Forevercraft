# ============================================================
# Slot helper — refresh the legacy MIRROR from the ACTIVE slot
# Run as: @s = the player
# Reads hs.active (1-5); copies hs.h<active>_* -> hs.tier/hs.home_*/etc.
# SOLE WRITER of the mirror fields (via load_one). After this runs, all
# ~40 cross-system readers see the active home. No-op if hs.active=0.
# ============================================================

# No active home -> clear the mirror so readers see "no home"
execute unless score @s hs.active matches 1..5 run scoreboard players set @s hs.tier 0
execute unless score @s hs.active matches 1..5 run scoreboard players set @s hs.gs_id 0
execute unless score @s hs.active matches 1..5 run return 0

# Stamp the active slot index into per-player storage for the macro arg
execute store result storage evercraft:housing ld.n int 1 run scoreboard players get @s hs.active
function evercraft:housing/slot/load_one with storage evercraft:housing ld
