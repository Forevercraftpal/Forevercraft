# UX ADDITION 3 — Guidestone rename confirmation notify (macro)
# Run as: @s = the player. Macro arg: name (the applied name).
$data modify storage evercraft:notify stage.c set value [{text:"Guidestone labeled ",color:"green"},{text:"«$(name)»",color:"aqua",bold:true},{text:" on the network.",color:"green"}]
scoreboard players set #ndur ec.temp 50
function evercraft:util/notify/emit
