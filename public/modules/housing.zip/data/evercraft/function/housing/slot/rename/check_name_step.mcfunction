# ============================================================
# Home Deed — name-uniqueness per-slot step (macro)
# Run as: @s = the player. Macro args: {slot, self, name}.
#   slot = the slot to test (1-5); self = the slot being renamed (skip it);
#   name = the proposed name.
# If `slot` != `self`, is occupied, and its registry name == the proposed
# name, set #hs_name_dup hs.temp = 1.
# ============================================================

# Skip the slot being renamed (you may keep your own name on it).
$execute if score #hs_deed_slot hs.temp matches $(slot) run return 0

# Skip empty slots.
$execute unless score @s hs.h$(slot)_tier matches 1.. run return 0

# Look up this slot's name into hrow.name, then macro-compare to the proposal.
$execute store result score #hm_look_gs hs.temp run scoreboard players get @s hs.h$(slot)_gs
function evercraft:housing/homes/lookup_name
$execute if data storage evercraft:housing {hrow:{name:"$(name)"}} run scoreboard players set #hs_name_dup hs.temp 1
