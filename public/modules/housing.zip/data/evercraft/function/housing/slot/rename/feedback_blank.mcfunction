# UX ADDITION 3 — Guidestone Deed signed with a blank page.
# Run as: @s = the player. The registry keeps its existing default name
# (the anvil name or "Waypoint #N" from registration). Consume the deed so it
# doesn't linger, and tell the player nothing was changed.
clear @s minecraft:written_book[custom_data~{gs_deed:1b}] 1
data modify storage evercraft:notify stage.c set value [{text:"No name written — this guidestone kept its default label.",color:"gray"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
