# ============================================================
# Housing recovery — count walk (recursive, macro-keyed)
# Macro args: {u0,u1,u2,u3} = the owner UUID to count.
# Walks cnt_scan; increments #hs_rec_cnt hs.temp per entry whose UUID matches,
# then consumes the head. Bounded by store size.
# ============================================================

execute unless data storage evercraft:housing cnt_scan[0] run return 0

$execute if data storage evercraft:housing cnt_scan[0]{u0:$(u0),u1:$(u1),u2:$(u2),u3:$(u3)} run scoreboard players add #hs_rec_cnt hs.temp 1

data remove storage evercraft:housing cnt_scan[0]
function evercraft:housing/slot/recovery/count_step with storage evercraft:housing rc_key
