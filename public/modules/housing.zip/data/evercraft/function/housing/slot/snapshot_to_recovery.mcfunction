# ============================================================
# Housing — Snapshot a slot's home into the name-keyed recovery store
# Run as: @s = the owner. Macro arg: {n:<1-5>} = the slot about to be cleared.
# Appends {u0..u3 (owner uuid), name, tier, decor, pmode} to
#   storage evercraft:housing recovery
# so the owner can later place a fresh Hearthstone, rename it to the SAME
# name, and recover this home's tier + comfort (slot/rename/try_recover).
#
# Keyed (owner_uuid, name) — NEVER name-alone (closes foreign-name theft).
# SKIPS the default name "Home" (mass-collision guard: every unnamed home
# shares it). Caps the store at the last 5 records per owner (matches the
# 5-home slot cap) — oldest of THIS owner's records is evicted on overflow.
#
# Called from check_owner_reset (legitimate owner break) + homes/confirm_
# abandon (GUI drop). Both run with @s = the owner and the slot still
# populated, so tier/decor/pmode are read straight from the columns.
# ============================================================

# Resolve the slot's gs_id, then its display name (registry single source).
$execute store result score #hm_look_gs hs.temp run scoreboard players get @s hs.h$(n)_gs
function evercraft:housing/homes/lookup_name
# hrow.name now holds the name (defaults to "Home" if unnamed/not found).

# SKIP default "Home" — mass-collision guard. An unnamed home is not worth a
# recovery record (any new "Home" would collide with everyone's). The owner
# can still rebuild; only NAMED homes are recoverable.
execute if data storage evercraft:housing {hrow:{name:"Home"}} run return 0

# Build the recovery record in a temp object.
data modify storage evercraft:housing rec_new set value {u0:0,u1:0,u2:0,u3:0,name:"Home",tier:1,decor:0,pmode:0}
data modify storage evercraft:housing rec_new.name set from storage evercraft:housing hrow.name
execute store result storage evercraft:housing rec_new.u0 int 1 run data get entity @s UUID[0]
execute store result storage evercraft:housing rec_new.u1 int 1 run data get entity @s UUID[1]
execute store result storage evercraft:housing rec_new.u2 int 1 run data get entity @s UUID[2]
execute store result storage evercraft:housing rec_new.u3 int 1 run data get entity @s UUID[3]
$execute store result storage evercraft:housing rec_new.tier int 1 run scoreboard players get @s hs.h$(n)_tier
$execute store result storage evercraft:housing rec_new.decor int 1 run scoreboard players get @s hs.h$(n)_decor
$execute store result storage evercraft:housing rec_new.pmode int 1 run scoreboard players get @s hs.h$(n)_pmode

# De-dupe: if a record for (this owner, this name) already exists, drop it
# first so the fresh snapshot supersedes it (most-recent wins; no stacking).
function evercraft:housing/slot/recovery/dedupe

# Append the new record.
data modify storage evercraft:housing recovery append from storage evercraft:housing rec_new

# Cap @s's records at the last 5 (evict this owner's OLDEST on overflow).
function evercraft:housing/slot/recovery/cap
