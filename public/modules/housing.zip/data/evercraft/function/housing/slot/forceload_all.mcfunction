# ============================================================
# Forceload helper — (re)assert forceload for EVERY occupied slot
# Run as: @s = the player (owner of the homes)
# No args. For each slot N with hs.h<N>_tier>=1, dispatch forceload_one
# (per-dim, 9-chunk). Existence-gated per slot so a 1-home player only
# pays for 1 slot. Budget: CAP 5 * 9 = 45 chunks max per player.
#
# Idempotent — safe to call on load, on any home add/remove/relocate, and
# to RE-ASSERT survivors after an abandon. `forceload add` on already-loaded
# chunks is a no-op, so overlapping 3x3 regions are handled correctly: a
# `forceload remove` of one home's block (in on_break) can clip chunks a
# neighbour still needs, so on_break re-runs forceload_all right after to
# re-load any shared chunks the survivors require.
#
# Called by: slot/migrate, confirm_relocate, on_break (after a remove),
#            GUI [Abandon] (after clearing the slot).
# ============================================================

execute if score @s hs.h1_tier matches 1.. run data modify storage evercraft:housing flc.n set value 1
execute if score @s hs.h1_tier matches 1.. run function evercraft:housing/slot/forceload_one with storage evercraft:housing flc

execute if score @s hs.h2_tier matches 1.. run data modify storage evercraft:housing flc.n set value 2
execute if score @s hs.h2_tier matches 1.. run function evercraft:housing/slot/forceload_one with storage evercraft:housing flc

execute if score @s hs.h3_tier matches 1.. run data modify storage evercraft:housing flc.n set value 3
execute if score @s hs.h3_tier matches 1.. run function evercraft:housing/slot/forceload_one with storage evercraft:housing flc

execute if score @s hs.h4_tier matches 1.. run data modify storage evercraft:housing flc.n set value 4
execute if score @s hs.h4_tier matches 1.. run function evercraft:housing/slot/forceload_one with storage evercraft:housing flc

execute if score @s hs.h5_tier matches 1.. run data modify storage evercraft:housing flc.n set value 5
execute if score @s hs.h5_tier matches 1.. run function evercraft:housing/slot/forceload_one with storage evercraft:housing flc
