# Home Deed — rename confirmation notify (macro)
# Run as: @s = the player. Macro arg: name (the applied name).
$data modify storage evercraft:notify stage.c set value [{text:"Home renamed to ",color:"green"},{text:"«$(name)»",color:"gold",bold:true},{text:".",color:"green"}]
scoreboard players set #ndur ec.temp 50
function evercraft:util/notify/emit
