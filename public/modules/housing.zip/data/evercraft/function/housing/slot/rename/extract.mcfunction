# ============================================================
# Signed Deed — extract the signed name + apply it (DISPATCHER)
# Run as: @s = player who just signed a Home Deed OR a Guidestone Deed
# (shared evercraft:housing/signed_deed advancement reward).
# Mirrors guild/create + buddy/naming/extract_name.
#
# Two deed kinds, distinguished by the signed book's custom_data key:
#   {hs_deed:1b, slot:<N>}   -> a HOME deed   -> rename home slot N (below)
#   {gs_deed:1b, gs_id:<ID>} -> a GUIDESTONE deed -> rename registry id ID
#     (routed to slot/rename/extract_gs; ADDITION 3).
#
# Home flow:
#   1. Revoke the advancement so it can re-fire on the next rename.
#   2. Read the target slot from the signed book's custom_data.slot.
#   3. Validate that slot is occupied (guard against a stale/forged book).
#   4. Pull page 1 raw text -> evercraft:housing deed.name.
#   5. Write the name into the guidestone registry entry keyed by the slot's
#      hs.h<slot>_gs, and onto the home marker's CustomName.
#   6. Consume the book.
# ============================================================

# 1. Revoke for re-fire (covers both deed kinds — they share the advancement)
advancement revoke @s only evercraft:housing/signed_deed

# DISPATCH — a Guidestone Deed routes to its own extractor and stops here.
execute if data entity @s SelectedItem.components."minecraft:custom_data".gs_deed run return run function evercraft:housing/slot/rename/extract_gs

# Guard: otherwise must actually be holding a signed Home Deed
execute unless data entity @s SelectedItem.components."minecraft:custom_data".hs_deed run return fail

# 2. Read the target slot from the book's custom_data
execute store result score #hs_deed_slot hs.temp run data get entity @s SelectedItem.components."minecraft:custom_data".slot
execute unless score #hs_deed_slot hs.temp matches 1..5 run return fail

# 3. Resolve that slot's gs_id; validate the slot is occupied. Reuse the
#    slot-table by stashing the gs into the rename storage via a tiny macro
#    that branches on the slot number.
data modify storage evercraft:housing deed.slot set value 0
execute store result storage evercraft:housing deed.slot int 1 run scoreboard players get #hs_deed_slot hs.temp
function evercraft:housing/slot/rename/resolve_gs with storage evercraft:housing deed
# resolve_gs sets #hs_deed_gs hs.temp; 0 = empty slot -> abort
execute if score #hs_deed_gs hs.temp matches 0 run return fail

# 4. Extract page 1 raw text into the rename storage (reset first so a missing/empty page resolves to "" and is caught below)
data modify storage evercraft:housing deed.name set value ""
data modify storage evercraft:housing deed.name set from entity @s SelectedItem.components."minecraft:written_book_content".pages[0].raw
# Guard: a blank page-1 would un-name the home — bail to the blank-page feedback (mirrors extract_gs); deed is NOT consumed, so the player can re-sign with a real name
execute if data storage evercraft:housing {deed:{name:""}} run return run function evercraft:housing/slot/rename/feedback_blank

# Guard: per-owner name uniqueness (AU31-Q2 §4). If @s ALREADY has ANOTHER
# occupied home with this exact name, reject — two same-named homes would make
# recovery ambiguous (which home does "«Name»" restore?). check_name_unique
# sets #hs_name_dup hs.temp=1 on collision; the deed is NOT consumed so the
# player can re-sign with a different name. Skips "Home" (the unnamed default
# is allowed to repeat — it's never recoverable anyway).
function evercraft:housing/slot/rename/check_name_unique
execute if score #hs_name_dup hs.temp matches 1 run return run function evercraft:housing/slot/rename/feedback_dup

# 5a. Update the guidestone registry entry (single source of truth for the
#     display name). Rebuild the registry, swapping name on the matching id.
function evercraft:housing/slot/rename/apply_registry

# 5b. Update the live marker's CustomName (if its chunk is loaded)
execute as @e[type=marker,tag=HS.Marker,tag=!HS.Pending] if score @s ec.gs_id = #hs_deed_gs hs.temp run function evercraft:housing/slot/rename/apply_marker with storage evercraft:housing deed

# 6. Consume the deed
clear @s minecraft:written_book[custom_data~{hs_deed:1b}] 1

# 7. Name-keyed recovery (AU31-Q2): if @s archived a home under this exact name
#    (broke / abandoned it earlier), restore its tier + comfort into this
#    freshly-renamed slot now + consume the record. No-op if no record matches.
#    Runs AFTER the name is applied so deed.name + the slot's gs_id are final.
function evercraft:housing/slot/rename/try_recover

# Feedback
function evercraft:housing/slot/rename/feedback with storage evercraft:housing deed
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.6 1.4
