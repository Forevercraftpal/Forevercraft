# Home Deed — resolve slot N's gs_id (macro)
# Run as: @s = the player. Macro arg: slot (1-5).
# OUTPUT: #hs_deed_gs hs.temp = hs.h<slot>_gs (0 if the slot is empty).
$execute store result score #hs_deed_gs hs.temp run scoreboard players get @s hs.h$(slot)_gs
