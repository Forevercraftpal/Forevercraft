# UX ADDITION 1 — is the active home already named? (registry scan)
# INPUT:  #hs_bp_gs hs.temp = the active home's gs_id.
# OUTPUT: #hs_bp_named hs.temp = 1 if that registry entry has a non-empty
#         name, else left at 0.
# Cold path (only on a border-entry where the deed flag is still 0). Scans a
# private copy of the registry so it never disturbs the menu's working buffers.

execute if score #hs_bp_gs hs.temp matches 0 run return fail
data modify storage evercraft:housing bp_scan set from storage evercraft:guidestone registry
function evercraft:housing/slot/border_prompt_named_step
