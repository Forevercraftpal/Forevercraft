# ============================================================
# Slot helper — copy the active MIRROR -> slot N columns
# Run as: @s = the player
# Macro arg: {n:<1-5>}  (the slot to flush the mirror into)
# This is how the active slot's persistent columns absorb any in-zone
# mutations to the mirror (tier upgrade, decor recalc, protection toggle
# done while bound to this slot). Called by save_active before switching.
# ============================================================

$scoreboard players operation @s hs.h$(n)_tier = @s hs.tier
$scoreboard players operation @s hs.h$(n)_x = @s hs.home_x
$scoreboard players operation @s hs.h$(n)_y = @s hs.home_y
$scoreboard players operation @s hs.h$(n)_z = @s hs.home_z
$scoreboard players operation @s hs.h$(n)_dim = @s hs.home_dim
$scoreboard players operation @s hs.h$(n)_gs = @s hs.gs_id
$scoreboard players operation @s hs.h$(n)_decor = @s hs.decor
$scoreboard players operation @s hs.h$(n)_prot = @s hs.protect
$scoreboard players operation @s hs.h$(n)_pmode = @s hs.protect_mode
