# ============================================================
# one-time migration — blank the migrated home's registry name
# Run as: @s = the player.
# INPUT: #hs_unnamed_gs hs.temp = the gs_id (registry entry id) to blank.
# Sets that registry entry's `name` to "" so the home reads as UNNAMED.
# Mirrors slot/rename/apply_registry's rebuild idiom (cold path), but writes
# an empty string rather than a deed name. The empty name is what the
# contextual border prompt + Manage-Homes treat as "needs naming".
#
# Header marker "one-time migration" allowlists this for the dead-code audit
# (it is only ever reached from slot/migrate_home).
# ============================================================

# A gs_id of 0 is "no home" — nothing to blank.
execute if score #hs_unnamed_gs hs.temp matches 0 run return fail

# Snapshot the registry into a private scan buffer; clear the destination.
data modify storage evercraft:housing un_scan set from storage evercraft:guidestone registry
data modify storage evercraft:guidestone registry set value []

# Walk + rebuild, blanking the matched entry's name.
function evercraft:housing/slot/mark_unnamed_step
