# ============================================================
# Slot helper — highest OCCUPIED home-slot index (0 = none)
# Run as: @s = the player. Sets #hs_hi_occ hs.temp to the largest N (1-5)
# whose hs.h<N>_tier >= 1, else 0. Sequential ifs -> the highest wins.
# Used by unlock_check to floor hs.slots so a reborn Pioneer (homes restored
# by the Hearthstone safe space, but Dream Rank wiped) never has a home
# orphaned in a slot the dream-rank formula would otherwise re-lock.
# ============================================================
scoreboard players set #hs_hi_occ hs.temp 0
execute if score @s hs.h1_tier matches 1.. run scoreboard players set #hs_hi_occ hs.temp 1
execute if score @s hs.h2_tier matches 1.. run scoreboard players set #hs_hi_occ hs.temp 2
execute if score @s hs.h3_tier matches 1.. run scoreboard players set #hs_hi_occ hs.temp 3
execute if score @s hs.h4_tier matches 1.. run scoreboard players set #hs_hi_occ hs.temp 4
execute if score @s hs.h5_tier matches 1.. run scoreboard players set #hs_hi_occ hs.temp 5
