# ============================================================
# Slot helper — announce a newly-unlocked home slot
# Run as: @s = the player
# Called by unlock_check ONLY when #hs_new_slots hs.temp > hs.slots.
# #hs_new_slots holds the freshly-earned slot count (2..5 here, since an
# increase past the base of 1 is the only way to reach this function).
# Uses the standard notify queue (evercraft:util/notify/emit), per
# house-law: no /trigger prompts, GUI-driven from here on.
# ============================================================

execute if score @s ec.fx_snd matches 1.. run playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 0.8 1.2
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 1.0 1.0

data modify storage evercraft:notify stage.c set value [{text:"⌂ ",color:"gold"},{text:"A new Hearthstone slot is available!",bold:true,color:"gold"}]
scoreboard players set #ndur ec.temp 50
function evercraft:util/notify/emit

# Ordinal line — name the slot the player just earned (the freshly-earned count)
execute if score #hs_new_slots hs.temp matches 2 run data modify storage evercraft:notify stage.c set value [{text:"You may now claim a ",color:"gray"},{text:"2nd home",color:"yellow"},{text:" — place a Hearthstone to settle it.",color:"gray"}]
execute if score #hs_new_slots hs.temp matches 3 run data modify storage evercraft:notify stage.c set value [{text:"You may now claim a ",color:"gray"},{text:"3rd home",color:"yellow"},{text:" — place a Hearthstone to settle it.",color:"gray"}]
execute if score #hs_new_slots hs.temp matches 4 run data modify storage evercraft:notify stage.c set value [{text:"You may now claim a ",color:"gray"},{text:"4th home",color:"yellow"},{text:" — place a Hearthstone to settle it.",color:"gray"}]
execute if score #hs_new_slots hs.temp matches 5 run data modify storage evercraft:notify stage.c set value [{text:"You may now claim a ",color:"gray"},{text:"5th home",color:"yellow"},{text:" — place a Hearthstone to settle it.",color:"gray"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit

# Pointer to where they manage homes (GUI-only, no trigger commands)
data modify storage evercraft:notify stage.c set value [{text:"Right-click your Hearthstone → ",color:"dark_gray"},{text:"Manage Homes",color:"aqua"},{text:" to review your slots.",color:"dark_gray"}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit
