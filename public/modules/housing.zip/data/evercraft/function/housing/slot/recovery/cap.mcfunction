# ============================================================
# Housing recovery — cap @s's records at the last 5 (evict oldest on overflow)
# Run as: @s = the owner. Counts how many recovery records belong to @s
# (matched by UUID). While that count exceeds 5, drop @s's OLDEST record
# (lowest index = earliest appended). Matches the 5-home slot cap; bounds the
# store against grief bloat. Other owners' records are never touched.
# ============================================================

# Stash @s's UUID ints for the macro-keyed count/evict.
data modify storage evercraft:housing rc_key set value {u0:0,u1:0,u2:0,u3:0}
execute store result storage evercraft:housing rc_key.u0 int 1 run data get entity @s UUID[0]
execute store result storage evercraft:housing rc_key.u1 int 1 run data get entity @s UUID[1]
execute store result storage evercraft:housing rc_key.u2 int 1 run data get entity @s UUID[2]
execute store result storage evercraft:housing rc_key.u3 int 1 run data get entity @s UUID[3]

# Count @s's records (rebuild a count over a copy), then evict while > 5.
function evercraft:housing/slot/recovery/cap_check with storage evercraft:housing rc_key
