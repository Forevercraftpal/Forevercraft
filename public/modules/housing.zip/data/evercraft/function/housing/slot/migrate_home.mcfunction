# ============================================================
# one-time migration — copy the legacy home into slot 1
# Run as: @s = the player (only reached when hs.tier>=1 and un-migrated)
# Splits the column copy out of slot/migrate so the audit's
# "one-time migration" marker covers both halves.
# ============================================================

scoreboard players operation @s hs.h1_tier = @s hs.tier
scoreboard players operation @s hs.h1_x = @s hs.home_x
scoreboard players operation @s hs.h1_y = @s hs.home_y
scoreboard players operation @s hs.h1_z = @s hs.home_z
scoreboard players operation @s hs.h1_dim = @s hs.home_dim
scoreboard players operation @s hs.h1_gs = @s hs.gs_id
scoreboard players operation @s hs.h1_decor = @s hs.decor
scoreboard players operation @s hs.h1_prot = @s hs.protect
scoreboard players operation @s hs.h1_pmode = @s hs.protect_mode

# UX ADDITION 1 — the migrated home is UNNAMED. Leave its deed-given flag
# at 0 (needs-naming) so the contextual border prompt fires exactly once on
# the player's next home-zone entry, and blank its guidestone-registry name
# so Manage-Homes + the portal menu show it as unnamed until the deed is set.
scoreboard players set @s hs.h1_dg 0
scoreboard players operation #hs_unnamed_gs hs.temp = @s hs.h1_gs
function evercraft:housing/slot/mark_unnamed

# Bind the mirror to slot 1
scoreboard players set @s hs.active 1
function evercraft:housing/slot/recount
