# ============================================================
# Housing recovery — count @s's records; evict oldest while > 5 (recursive)
# Macro args: {u0,u1,u2,u3} = @s's UUID ints.
# Counts how many records in evercraft:housing recovery belong to this owner
# by walking a copy; if the count exceeds 5, drops the owner's OLDEST record
# (first match by index) and recurses until back within cap.
# ============================================================

# Count this owner's records over a copy buffer.
data modify storage evercraft:housing cnt_scan set from storage evercraft:housing recovery
scoreboard players set #hs_rec_cnt hs.temp 0
function evercraft:housing/slot/recovery/count_step with storage evercraft:housing rc_key

# Within cap -> done.
execute if score #hs_rec_cnt hs.temp matches ..5 run return 0

# Over cap -> evict the owner's oldest (first-indexed) record, then re-check.
function evercraft:housing/slot/recovery/evict_oldest with storage evercraft:housing rc_key
function evercraft:housing/slot/recovery/cap_check with storage evercraft:housing rc_key
