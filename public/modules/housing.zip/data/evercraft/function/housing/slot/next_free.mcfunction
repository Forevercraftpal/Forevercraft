# ============================================================
# Slot helper — find the lowest FREE unlocked home slot
# Run as: @s = the player
# OUTPUT: hs.next_slot = lowest N (1..hs.slots) with hs.h<N>_tier == 0,
#         or 0 if every unlocked slot is occupied.
# A slot is claimable iff:  N <= hs.slots (unlocked)  AND  hs.h<N>_tier 0.
# Used by setup_hearthstone (place -> claim next free) and by B's empty-row
# display. Pure read of slot columns + hs.slots; writes only hs.next_slot.
# ============================================================

# Default: no free slot
scoreboard players set @s hs.next_slot 0

# Walk slots HIGH -> LOW so the LOWEST free unlocked slot wins the final write.
# Each slot is eligible only if it is unlocked (N <= hs.slots) AND empty.
execute if score @s hs.slots matches 5.. if score @s hs.h5_tier matches 0 run scoreboard players set @s hs.next_slot 5
execute if score @s hs.slots matches 4.. if score @s hs.h4_tier matches 0 run scoreboard players set @s hs.next_slot 4
execute if score @s hs.slots matches 3.. if score @s hs.h3_tier matches 0 run scoreboard players set @s hs.next_slot 3
execute if score @s hs.slots matches 2.. if score @s hs.h2_tier matches 0 run scoreboard players set @s hs.next_slot 2
execute if score @s hs.slots matches 1.. if score @s hs.h1_tier matches 0 run scoreboard players set @s hs.next_slot 1
