# UX ADDITION 1 — registry "is named" scan step (recursive)
# Pops bp_scan[0]; if its id == #hs_bp_gs and its name is non-empty, sets
# #hs_bp_named = 1 and stops. Otherwise recurses through the list.

execute unless data storage evercraft:housing bp_scan[0] run return 0

# Head entry id
execute store result score #hs_bp_id hs.temp run data get storage evercraft:housing bp_scan[0].id

# Matched id with a non-empty name -> already named. (An empty "" name has
# string length 0, so data ...{name:""} matches the unnamed case; we invert.)
scoreboard players set #hs_bp_nlen hs.temp 0
execute if score #hs_bp_id hs.temp = #hs_bp_gs hs.temp if data storage evercraft:housing bp_scan[0].name store result score #hs_bp_nlen hs.temp run data get storage evercraft:housing bp_scan[0].name
execute if score #hs_bp_id hs.temp = #hs_bp_gs hs.temp if score #hs_bp_nlen hs.temp matches 1.. run scoreboard players set #hs_bp_named hs.temp 1
execute if score #hs_bp_id hs.temp = #hs_bp_gs hs.temp run data remove storage evercraft:housing bp_scan
execute if score #hs_bp_id hs.temp = #hs_bp_gs hs.temp run return 0

# Not the target -> drop head and recurse
data remove storage evercraft:housing bp_scan[0]
function evercraft:housing/slot/border_prompt_named_step
