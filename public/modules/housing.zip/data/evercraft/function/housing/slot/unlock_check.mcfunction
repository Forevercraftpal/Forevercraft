# ============================================================
# Slot helper — set hs.slots (unlocked home-slot count) from dream_rank
# Run as: @s = the player
# ONE-WRITER of hs.slots (Agent D). Slots unlock by Dream Rank:
#   slot 1 = always (start)        -> base 1
#   slot 2 = rank E (dream_rank>=3)
#   slot 3 = rank C (dream_rank>=5)
#   slot 4 = rank A (dream_rank>=7)
#   slot 5 = rank S (dream_rank>=8)
# Clamped to the CAP constant (#hs_cap ec.const = 5). On an INCREASE we emit
# a one-shot notify so the player knows a new home can be claimed.
#
# Called from:
#   - dream_rank/rank_up        (on every rank gain)
#   - slot/migrate              (retro-fit existing players to correct count)
# ============================================================

# --- Compute the freshly-earned unlock count into a temp ---
scoreboard players set #hs_new_slots hs.temp 1
execute if score @s ec.dream_rank matches 3.. run scoreboard players set #hs_new_slots hs.temp 2
execute if score @s ec.dream_rank matches 5.. run scoreboard players set #hs_new_slots hs.temp 3
execute if score @s ec.dream_rank matches 7.. run scoreboard players set #hs_new_slots hs.temp 4
execute if score @s ec.dream_rank matches 8.. run scoreboard players set #hs_new_slots hs.temp 5

# Clamp to CAP (never grant more slots than the cap, even if thresholds drift)
execute if score #hs_new_slots hs.temp > #hs_cap ec.const run scoreboard players operation #hs_new_slots hs.temp = #hs_cap ec.const

# Floor at the highest OCCUPIED slot so a reborn Pioneer (homes restored by the
# Hearthstone safe space, Dream Rank wiped) never has a home re-locked / orphaned
# in the Manage-Homes GUI. No-op for everyone else: a non-Pioneer can never have
# occupied > slots (you cannot claim a home in a locked slot, and Dream Rank only
# rises), so highest-occupied <= the dream-rank count already.
function evercraft:housing/slot/highest_occupied
execute if score #hs_hi_occ hs.temp > #hs_new_slots hs.temp run scoreboard players operation #hs_new_slots hs.temp = #hs_hi_occ hs.temp

# --- Detect an INCREASE vs the current stored count (notify only then) ---
# First-ever call: hs.slots is unset. Treat unset as "no notify" (silent
# baseline) so migration doesn't spam; just seed the count.
execute unless score @s hs.slots matches 0.. run scoreboard players operation @s hs.slots = #hs_new_slots hs.temp
execute unless score @s hs.slots matches 0.. run return 0

# If the new count is strictly higher than the stored one, announce it.
execute if score #hs_new_slots hs.temp > @s hs.slots run function evercraft:housing/slot/unlock_notify

# --- Commit the new count (one-writer of hs.slots) ---
scoreboard players operation @s hs.slots = #hs_new_slots hs.temp
