# ============================================================
# Housing recovery — remove the owner's OLDEST record (macro-keyed)
# Macro args: {u0,u1,u2,u3} = the owner UUID.
# `data remove` on a list[{filter}] path removes the FIRST (lowest-index)
# matching element — and records append at the tail, so the first match is
# this owner's oldest. One command; called by cap_check on overflow.
# ============================================================

$data remove storage evercraft:housing recovery[{u0:$(u0),u1:$(u1),u2:$(u2),u3:$(u3)}]
