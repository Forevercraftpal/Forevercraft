# Home Deed — apply the new name to the home marker (macro)
# Run as: @s = the matched HS.Marker entity. Macro arg: name (the new name).
# Mirrors buddy/naming/apply_name (sets the entity CustomName from the deed).
$data modify entity @s CustomName set value {text:"$(name)",color:"gold"}
