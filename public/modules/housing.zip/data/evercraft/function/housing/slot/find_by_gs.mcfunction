# ============================================================
# Slot helper — find which slot (1-5) holds a given guidestone ID
# Run as: @s = the player who owns the homes
# INPUT:  #hs_find_gs hs.temp   = the gs_id to look up
# OUTPUT: #hs_find_slot hs.temp = matched slot N (1-5), or 0 if none
# Used by: relocate / abandon / rename / toggle_protection — any action
# that targets a specific hearthstone by its marker ec.gs_id.
# ============================================================

scoreboard players set #hs_find_slot hs.temp 0

# A gs_id of 0 is "no home" — never match it (slots default to 0 when empty)
execute if score #hs_find_gs hs.temp matches 0 run return fail

execute if score @s hs.h1_tier matches 1.. if score @s hs.h1_gs = #hs_find_gs hs.temp run scoreboard players set #hs_find_slot hs.temp 1
execute if score @s hs.h2_tier matches 1.. if score @s hs.h2_gs = #hs_find_gs hs.temp run scoreboard players set #hs_find_slot hs.temp 2
execute if score @s hs.h3_tier matches 1.. if score @s hs.h3_gs = #hs_find_gs hs.temp run scoreboard players set #hs_find_slot hs.temp 3
execute if score @s hs.h4_tier matches 1.. if score @s hs.h4_gs = #hs_find_gs hs.temp run scoreboard players set #hs_find_slot hs.temp 4
execute if score @s hs.h5_tier matches 1.. if score @s hs.h5_gs = #hs_find_gs hs.temp run scoreboard players set #hs_find_slot hs.temp 5

# Return 1 when a slot matched, 0 otherwise (callers may branch on result)
execute if score #hs_find_slot hs.temp matches 1.. run return 1
return 0
