# ============================================================
# one-time migration — legacy single home -> slot 1
# Run as: @s = the player (called from the guarded first-tick hook)
# Gate (caller side): player has un-set hs.active. We re-check here so the
# function is safe to call directly. Idempotent: after it runs hs.active
# is 1 (had a home) or 0 (had none), so the first-tick gate skips forever.
#
# Header marker "one-time migration" allowlists this for the dead-code audit.
# ============================================================

# Already migrated (active is 0..5) -> nothing to do.
execute if score @s hs.active matches 0..5 run return 0

# --- CASE A: player has a legacy home (hs.tier>=1) -> copy into slot 1 ---
execute if score @s hs.tier matches 1.. run function evercraft:housing/slot/migrate_home

# --- CASE B: player has no home -> initialise empty pointers ---
execute unless score @s hs.tier matches 1.. run scoreboard players set @s hs.active 0
execute unless score @s hs.tier matches 1.. run scoreboard players set @s hs.homes 0

# Both cases: set unlocked-slot count from current dream_rank (Agent D),
# then (re)assert forceload for any occupied slot (Agent C).
function evercraft:housing/slot/unlock_check
function evercraft:housing/slot/forceload_all
