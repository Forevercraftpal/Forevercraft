# ============================================================
# Slot helper — copy slot N columns -> the active MIRROR
# Run as: @s = the player
# Macro arg: {n:<1-5>}  (the slot to pull into the mirror)
# Writes the legacy mirror fields ONLY (this is the sole writer of the
# mirror via load_active). Mirror = hs.tier/hs.home_*/hs.gs_id/hs.decor/
# hs.protect/hs.protect_mode reflecting hs.h<n>_*.
# ============================================================

$scoreboard players operation @s hs.tier = @s hs.h$(n)_tier
$scoreboard players operation @s hs.home_x = @s hs.h$(n)_x
$scoreboard players operation @s hs.home_y = @s hs.h$(n)_y
$scoreboard players operation @s hs.home_z = @s hs.h$(n)_z
$scoreboard players operation @s hs.home_dim = @s hs.h$(n)_dim
$scoreboard players operation @s hs.gs_id = @s hs.h$(n)_gs
$scoreboard players operation @s hs.decor = @s hs.h$(n)_decor
$scoreboard players operation @s hs.protect = @s hs.h$(n)_prot
$scoreboard players operation @s hs.protect_mode = @s hs.h$(n)_pmode
