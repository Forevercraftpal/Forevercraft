# Home Deed — registry rebuild step (recursive)
# Pops rn_scan[0]; if its id == #hs_deed_gs, swap its name to deed.name;
# append (possibly-modified) entry back onto the live registry; recurse.

execute unless data storage evercraft:housing rn_scan[0] run return 0

# Move the head entry into a single-entry work slot
data modify storage evercraft:housing rn_one set from storage evercraft:housing rn_scan[0]
data remove storage evercraft:housing rn_scan[0]

# If this is the target entry, overwrite its name
execute store result score #hs_step_id hs.temp run data get storage evercraft:housing rn_one.id
execute if score #hs_step_id hs.temp = #hs_deed_gs hs.temp run data modify storage evercraft:housing rn_one.name set from storage evercraft:housing deed.name

# Append it back (modified or not) and recurse
data modify storage evercraft:guidestone registry append from storage evercraft:housing rn_one
function evercraft:housing/slot/rename/registry_step
