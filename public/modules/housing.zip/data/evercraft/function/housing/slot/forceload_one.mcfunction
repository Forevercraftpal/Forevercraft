# ============================================================
# Forceload helper — (re)assert the 3x3 / 9-chunk block for ONE slot
# Run as: @s = the player (owner of the homes)
# Macro arg: storage evercraft:housing flc = {n:<1-5>}
#   (the slot to forceload — reads hs.h<n>_x / hs.h<n>_z / hs.h<n>_dim)
#
# THE 9-CHUNK CONSTANT LIVES HERE AND ONLY HERE.
# Forceload is per-dimension, so we wrap the add in `execute in <dim>`
# selected by the slot's stored hs.h<n>_dim (0=OW, 1=Nether, 2=End).
# Chunk-align math: offset +480000 (dodge negative-floor division), /16*16
# to land on the chunk origin, then expand to a true 3x3:
#   min corner = origin - 16
#   max corner = (origin - 16) + 47 = origin + 31
# In CHUNK units that spans [origin/16 - 1 .. origin/16 + 1] = 3 chunks/axis,
# i.e. 3 * 3 = 9 chunks (a true 3x3). NOTE the +47 is applied to the register
# AFTER the -16, so it NETS origin+31 — this is the 9-chunk case, NOT 16. (The
# spec's "+47 = 16 chunks, change to +31" note misread the -16 step; +31 would
# net origin+15 = 2x2 = 4 chunks, too small. Verified by chunk-floor math.)
#
# Idempotent: `forceload add` on already-loaded chunks is a no-op, so callers
# may re-run forceload_all freely (on load, mutation, abandon survivor re-assert).
# ============================================================

# Pull this slot's stored block coords into scratch (NOT marker Pos — the
# marker may be in another dimension / unloaded; the slot columns are truth).
$scoreboard players operation #hs_fl_x hs.temp = @s hs.h$(n)_x
$scoreboard players operation #hs_fl_z hs.temp = @s hs.h$(n)_z

# Chunk-align X/Z
scoreboard players add #hs_fl_x hs.temp 480000
scoreboard players add #hs_fl_z hs.temp 480000
scoreboard players set #16 hs.temp 16
scoreboard players operation #hs_fl_x hs.temp /= #16 hs.temp
scoreboard players operation #hs_fl_z hs.temp /= #16 hs.temp
scoreboard players operation #hs_fl_x hs.temp *= #16 hs.temp
scoreboard players operation #hs_fl_z hs.temp *= #16 hs.temp
scoreboard players remove #hs_fl_x hs.temp 480000
scoreboard players remove #hs_fl_z hs.temp 480000

# Min corner = origin - 16
scoreboard players remove #hs_fl_x hs.temp 16
scoreboard players remove #hs_fl_z hs.temp 16
execute store result storage evercraft:housing temp.x1 int 1 run scoreboard players get #hs_fl_x hs.temp
execute store result storage evercraft:housing temp.z1 int 1 run scoreboard players get #hs_fl_z hs.temp
# Max corner = (origin - 16) + 47 = origin + 31  → 3 chunks/axis = true 3x3 (9)
scoreboard players add #hs_fl_x hs.temp 47
scoreboard players add #hs_fl_z hs.temp 47
execute store result storage evercraft:housing temp.x2 int 1 run scoreboard players get #hs_fl_x hs.temp
execute store result storage evercraft:housing temp.z2 int 1 run scoreboard players get #hs_fl_z hs.temp

# Apply in the slot's own dimension (forceload add is per-dimension).
$execute if score @s hs.h$(n)_dim matches 0 in minecraft:overworld run function evercraft:housing/forceload_add with storage evercraft:housing temp
$execute if score @s hs.h$(n)_dim matches 1 in minecraft:the_nether run function evercraft:housing/forceload_add with storage evercraft:housing temp
$execute if score @s hs.h$(n)_dim matches 2 in minecraft:the_end run function evercraft:housing/forceload_add with storage evercraft:housing temp
