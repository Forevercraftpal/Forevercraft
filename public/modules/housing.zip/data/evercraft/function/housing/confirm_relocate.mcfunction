# ============================================================
# Hearthstone — Confirm Relocation (multi-home, per-slot)
# Run as: the player (via clickEvent or armed [Relocate] from Manage-Homes)
# Tears down the OLD marker of the TARGET slot, then finishes setup at the
# pending marker, writing the result into that slot's columns.
#
# TARGET SLOT resolution:
#   - If hs.reloc_n is armed (1-5) -> relocate THAT slot (Manage-Homes path).
#   - Else -> relocate the current ACTIVE slot (legacy / "all slots full"
#     fallback from setup_hearthstone). hs.active is guaranteed 1-5 here
#     because the player already owns a home (gate below).
# After a relocate the target slot becomes the ACTIVE home (you moved in).
# ============================================================

# Verify player actually has a pending hearthstone nearby
data modify storage evercraft:notify stage.c set value [{text:"No pending Hearthstone found nearby. The offer may have expired.",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute unless entity @e[type=marker,tag=HS.Pending,distance=..64] run function evercraft:util/notify/emit
execute unless entity @e[type=marker,tag=HS.Pending,distance=..64] run return fail

# Unified UI-click FX (Joseph 2026-06-05): tellraw-option click — play the gated cue once on a real
# relocate (after the no-pending guard).
function evercraft:fx/ui/click

# ═══ RESOLVE TARGET SLOT N ═══
# Default = armed relocate slot; fall back to the active slot if unarmed.
scoreboard players operation #hs_reloc_slot hs.temp = @s hs.reloc_n
execute unless score #hs_reloc_slot hs.temp matches 1..5 run scoreboard players operation #hs_reloc_slot hs.temp = @s hs.active
execute unless score #hs_reloc_slot hs.temp matches 1..5 run scoreboard players set #hs_reloc_slot hs.temp 1
# Disarm the relocate flag now that we've consumed it
scoreboard players set @s hs.reloc_n 0

# ═══ BIND THE MIRROR TO THE TARGET SLOT ═══
# Flush whatever is currently mirrored back into the OLD active slot so we
# don't lose it, then re-point the mirror at the target slot's stored data.
function evercraft:housing/slot/save_active
scoreboard players operation @s hs.active = #hs_reloc_slot hs.temp
function evercraft:housing/slot/load_active

# ═══ TEAR DOWN THE TARGET SLOT'S OLD HOME ═══
# (mirror now reflects the target slot; gs_id/tier are that slot's)
execute store result score #hs_relocate_id hs.temp run scoreboard players get @s hs.gs_id
# Carry the prior tier across relocate. We rewrite the slot ourselves after
# on_break, so capture tier FIRST and restore it into the mirror below.
scoreboard players operation #hs_keep_tier hs.temp = @s hs.tier
execute unless score #hs_keep_tier hs.temp matches 1..5 run scoreboard players set #hs_keep_tier hs.temp 1
# Guard: mark self so on_break -> check_owner_reset skips clearing this slot
# (we rewrite it ourselves below). The marker teardown / forceload-remove /
# companion-drop side of on_break still runs as intended.
tag @s add HS.Relocating
execute as @e[type=marker,tag=HS.Marker,tag=!HS.Pending] if score @s ec.gs_id = #hs_relocate_id hs.temp at @s run function evercraft:housing/on_break
tag @s remove HS.Relocating

# ═══ SET UP NEW HOME ═══
# Promote the pending marker to the real hearthstone
tag @e[type=marker,tag=HS.Pending,limit=1] add HS.New
tag @e[type=marker,tag=HS.Pending,limit=1] remove HS.Pending

# Set mirror home data — carry the prior tier over
scoreboard players operation @s hs.tier = #hs_keep_tier hs.temp

# Store home coordinates from the new marker
execute store result score @s hs.home_x run data get entity @e[type=marker,tag=HS.New,limit=1] Pos[0]
execute store result score @s hs.home_y run data get entity @e[type=marker,tag=HS.New,limit=1] Pos[1]
execute store result score @s hs.home_z run data get entity @e[type=marker,tag=HS.New,limit=1] Pos[2]

# Store dimension
scoreboard players set @s hs.home_dim 0
execute if dimension minecraft:the_nether run scoreboard players set @s hs.home_dim 1
execute if dimension minecraft:the_end run scoreboard players set @s hs.home_dim 2

# Prepare owner data
data modify storage evercraft:housing temp.owner_uuid set from entity @s UUID
execute store result storage evercraft:housing temp.uuid0 int 1 run data get entity @s UUID[0]
execute store result storage evercraft:housing temp.uuid1 int 1 run data get entity @s UUID[1]
execute store result storage evercraft:housing temp.uuid2 int 1 run data get entity @s UUID[2]
execute store result storage evercraft:housing temp.uuid3 int 1 run data get entity @s UUID[3]
data modify storage evercraft:housing temp.owner_name set value "Unknown"

# Copy owner UUID and tier to the marker
execute as @e[type=marker,tag=HS.New,limit=1] run data modify entity @s data.owner_uuid set from storage evercraft:housing temp.owner_uuid
execute as @e[type=marker,tag=HS.New,limit=1] store result entity @s data.owner_tier int 1 run scoreboard players get #hs_keep_tier hs.temp

# Register in guidestone network
execute as @e[type=marker,tag=HS.New,limit=1] at @s run function evercraft:housing/register_guidestone

# Store guidestone ID
execute store result score @s hs.gs_id run scoreboard players get @e[type=marker,tag=HS.New,limit=1] ec.gs_id

# ═══ PERSIST THE MIRROR INTO THE TARGET SLOT + RE-ASSERT FORCELOAD ═══
# The target slot is active, so flush mirror -> hs.h<active>_* and re-run the
# all-slots forceloader (Agent C; 9-chunk/3x3, idempotent, handles overlap).
function evercraft:housing/slot/save_active
function evercraft:housing/slot/recount
function evercraft:housing/slot/forceload_all

# Force a clean zone re-entry so the carried tier's buffs + DR re-apply at the
# new home (in_zone may be stale from the old location).
scoreboard players set @s hs.in_zone 0
attribute @s luck modifier remove evercraft:housing_dr

# Cleanup
tag @e[type=marker,tag=HS.New] remove HS.New

# Effects
execute at @s run particle minecraft:flame ~ ~1.2 ~ 0.3 0.3 0.3 0.02 15
execute at @s run particle minecraft:enchant ~ ~1.5 ~ 0.5 0.5 0.5 0.5 25
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.amethyst_block.place master @s ~ ~ ~ 1 0.7
playsound minecraft:block.beacon.activate master @a[distance=..16,scores={ec.fx_snd=1..}] ~ ~ ~ 0.5 1.2

data modify storage evercraft:notify stage.c set value [{text:"Hearthstone relocated! Your new home is now claimed.",color:"green"}]
scoreboard players set #ndur ec.temp 50
function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Your home tier and upgrades carried over",color:"yellow"},{text:" to the new location.",color:"gray"}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"3x3 chunks around your Hearthstone are now permanently loaded.",color:"dark_gray"}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit

# Give a Stash Label if they don't have one
function evercraft:housing/stash/label/give
