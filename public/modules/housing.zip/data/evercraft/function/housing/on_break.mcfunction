# ============================================================
# Hearthstone — Broken (lodestone block removed)
# Run as: the HS.Marker entity, at its position
# Clean up marker, interaction, registry entry, player data
# ============================================================

# Close any open menus for nearby players
execute as @a[tag=HS.InMenu,distance=..10] at @s run function evercraft:housing/gui/close

# Kill the interaction entity and visual overlay
kill @e[type=interaction,tag=HS.Interact,distance=..2]
kill @e[type=armor_stand,tag=HS.Stand,distance=..2]
kill @e[type=item_display,tag=HS.Display,distance=..2]

# Kill all stash barrel markers and displays within 32 blocks
kill @e[type=marker,tag=HS.Stash,distance=..32]
kill @e[type=text_display,tag=HS.StashDisplay,distance=..32]

# ═══ COLOR-AWARE LOOT DROP ═══
# Kill vanilla lodestone drop
kill @e[type=item,nbt={Item:{id:"minecraft:lodestone"}},distance=..2]

# Drop correct color variant
execute if data entity @s {data:{color:"hearthstone_azure"}} run loot spawn ~ ~0.5 ~ loot evercraft:housing/hearthstone_drop_azure
execute if data entity @s {data:{color:"hearthstone_crimson"}} run loot spawn ~ ~0.5 ~ loot evercraft:housing/hearthstone_drop_crimson
execute if data entity @s {data:{color:"hearthstone_solar"}} run loot spawn ~ ~0.5 ~ loot evercraft:housing/hearthstone_drop_solar
execute if data entity @s {data:{color:"hearthstone_verdant"}} run loot spawn ~ ~0.5 ~ loot evercraft:housing/hearthstone_drop_verdant
execute if data entity @s {data:{color:"hearthstone_ivory"}} run loot spawn ~ ~0.5 ~ loot evercraft:housing/hearthstone_drop_ivory
execute if data entity @s {data:{color:"hearthstone_obsidian"}} run loot spawn ~ ~0.5 ~ loot evercraft:housing/hearthstone_drop_obsidian
execute if data entity @s {data:{color:"hearthstone_rose"}} run loot spawn ~ ~0.5 ~ loot evercraft:housing/hearthstone_drop_rose
execute if data entity @s {data:{color:"hearthstone_noir"}} run loot spawn ~ ~0.5 ~ loot evercraft:housing/hearthstone_drop_noir
execute unless data entity @s {data:{color:"hearthstone_azure"}} unless data entity @s {data:{color:"hearthstone_crimson"}} unless data entity @s {data:{color:"hearthstone_solar"}} unless data entity @s {data:{color:"hearthstone_verdant"}} unless data entity @s {data:{color:"hearthstone_ivory"}} unless data entity @s {data:{color:"hearthstone_obsidian"}} unless data entity @s {data:{color:"hearthstone_rose"}} unless data entity @s {data:{color:"hearthstone_noir"}} run loot spawn ~ ~0.5 ~ loot evercraft:housing/hearthstone_drop

# Store the ID for guidestone registry removal
execute store result storage evercraft:guidestone remove_id int 1 run scoreboard players get @s ec.gs_id

# Remove from guidestone registry
function evercraft:guidestone/remove_from_registry

# Drop home companions as items and clean up before resetting owner data
execute store result score #hs_break_id hc.slot run scoreboard players get @s ec.gs_id
execute as @a[scores={hs.tier=1..}] if score @s hs.gs_id = #hs_break_id hc.slot run function evercraft:companions/handler/home/on_hearthstone_break

# ═══ Tag the owner BEFORE the slot is cleared (multi-home forceload re-assert) ═══
# The broken home may be in ANY of the owner's 5 slots, not just the active
# mirror — so match by scanning all slots (slot/find_by_gs), not hs.gs_id. Tag
# the matched owner so we can re-assert their SURVIVORS' forceload after the
# clear (their hs.active/gs_id may shift when check_owner_reset re-points).
# Skipped during relocate — confirm_relocate owns its own forceload re-assert.
scoreboard players operation #hs_find_gs hs.temp = #hs_break_id hc.slot
execute unless entity @a[tag=HS.Relocating,limit=1] as @a[scores={hs.tier=1..}] if function evercraft:housing/slot/find_by_gs run tag @s add HS.FlReassert

# Reset the owner's home data
# Find the owner by matching the stored UUID
# Since we can't easily match UUID, find the nearest player and check their hs.gs_id
scoreboard players set #hs_cor_hit hs.temp 0
execute as @a[scores={hs.tier=1..}] run function evercraft:housing/check_owner_reset

# ═══ Deferred-reset enqueue (AU31-Q2, β) ═══
# If NO online owner matched (the owner was offline, or this was a non-player
# removal — TNT/creeper/piston/setblock/wither/instabreak/admin force-break),
# the orphaned columns are still on the owner's file. Queue {owner uuid, gs_id}
# to storage evercraft:housing pending_reset (survives restart); login/reconcile
# drains it on the owner's next join. Owner UUID is read from the marker
# (@s data.owner_uuid). Skipped during relocate (the relocator owns its slot).
execute unless score #hs_cor_hit hs.temp matches 1 unless entity @a[tag=HS.Relocating,limit=1] run function evercraft:housing/enqueue_pending_reset

# ═══ Remove THIS home's 3x3 / 9-chunk forceload (multi-home) ═══
# Runs as the marker, at its position → already in the marker's dimension, so
# `forceload remove` lands in the right dimension without an `execute in`.
# True 3x3 (9 chunks): min corner = origin-16, then +47 on that register →
# origin+31 max → chunks [origin/16-1 .. origin/16+1] = 3 per axis = 9 total.
# (The +47 is applied AFTER the -16, so it nets origin+31, NOT origin+47 — the
# "+47=16chunks" note in the spec misread this; the live add region in
# slot/forceload_one is identical, so the remove region MUST match it exactly,
# else removal leaves an orphan forceloaded ring. Verified: -16/+47 = 9 chunks.)
# This teardown is the only forceload-REMOVE, and removes ONLY this home's block.
execute store result score #hs_fl_x hs.temp run data get entity @s Pos[0]
execute store result score #hs_fl_z hs.temp run data get entity @s Pos[2]
scoreboard players add #hs_fl_x hs.temp 480000
scoreboard players add #hs_fl_z hs.temp 480000
scoreboard players set #16 hs.temp 16
scoreboard players operation #hs_fl_x hs.temp /= #16 hs.temp
scoreboard players operation #hs_fl_z hs.temp /= #16 hs.temp
scoreboard players operation #hs_fl_x hs.temp *= #16 hs.temp
scoreboard players operation #hs_fl_z hs.temp *= #16 hs.temp
scoreboard players remove #hs_fl_x hs.temp 480000
scoreboard players remove #hs_fl_z hs.temp 480000
scoreboard players remove #hs_fl_x hs.temp 16
scoreboard players remove #hs_fl_z hs.temp 16
execute store result storage evercraft:housing temp.x1 int 1 run scoreboard players get #hs_fl_x hs.temp
execute store result storage evercraft:housing temp.z1 int 1 run scoreboard players get #hs_fl_z hs.temp
scoreboard players add #hs_fl_x hs.temp 47
scoreboard players add #hs_fl_z hs.temp 47
execute store result storage evercraft:housing temp.x2 int 1 run scoreboard players get #hs_fl_x hs.temp
execute store result storage evercraft:housing temp.z2 int 1 run scoreboard players get #hs_fl_z hs.temp
function evercraft:housing/forceload_remove with storage evercraft:housing temp

# ═══ Re-assert SURVIVORS' forceload (overlap-safe) ═══
# This home's 9-chunk block may have shared chunks with another of the owner's
# homes (overlapping 3x3 regions). The `forceload remove` above could clip a
# chunk a survivor still needs, so re-run the all-slots forceloader for the
# owner so any shared chunks are re-loaded. Idempotent (`forceload add` no-ops
# on already-loaded chunks). Owner = the HS.FlReassert-tagged player (matched
# across ALL slots BEFORE the clear; gate filters to those who still own a
# home, i.e. multi-home survivors). Tag is cleaned up regardless.
execute as @a[tag=HS.FlReassert,scores={hs.tier=1..}] run function evercraft:housing/slot/forceload_all
tag @a[tag=HS.FlReassert] remove HS.FlReassert

# Notify nearby players
data modify storage evercraft:notify stage.c set value [{text:"A Hearthstone was destroyed.",color:"gray"}]
scoreboard players set #ndur ec.temp 45
execute as @a[distance=..16] run function evercraft:util/notify/emit
playsound minecraft:block.amethyst_block.break master @a[distance=..16,scores={ec.fx_snd=1..}] ~ ~ ~ 1 0.5
particle minecraft:happy_villager ~ ~0.5 ~ 0.3 0.3 0.3 0.03 10

# Kill this marker
kill @s
