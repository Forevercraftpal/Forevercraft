# ============================================================
# Hearthstone — Interaction detected (right-click)
# Run as: the interaction entity, at its position
# ============================================================

# Clear interaction data so it can fire again
data remove entity @s interaction

# --- Protection toggle (Wiring Audit #27 Q1, Joseph): owner SNEAK-right-clicks their own
# hearthstone to cycle protection Off -> Guarded (Mining Fatigue) -> Reinforced -> Off.
# MULTI-HOME: gate on the player owning THIS hearthstone in ANY of their 5 slots
# (slot/find_by_gs), not just the active mirror — so a non-active home can be
# toggled too. The clicked marker's gs is passed via #hs_find_gs; toggle_protection
# re-resolves the slot from it. ---
execute store result score #hs_this_gs hs.temp run scoreboard players get @e[type=marker,tag=HS.Marker,distance=..3,limit=1] ec.gs_id
scoreboard players operation #hs_find_gs hs.temp = #hs_this_gs hs.temp
execute as @p[distance=..6,predicate=evercraft:is_sneaking] if function evercraft:housing/slot/find_by_gs run return run function evercraft:housing/zone/toggle_protection

# --- Dye intercept ---
execute as @p[distance=..6] if items entity @s weapon.mainhand #evercraft:dyes run return run function evercraft:housing/dye_block
execute as @p[distance=..6] if items entity @s weapon.mainhand minecraft:water_bucket run return run function evercraft:housing/wash_block

# If nearest player already has menu open, close it first (respawn on re-click)
execute as @p[distance=..6,tag=HS.InMenu] at @s run function evercraft:housing/gui/close

# Open GUI for the nearest player
execute as @p[distance=..6] at @s run function evercraft:housing/gui/open
