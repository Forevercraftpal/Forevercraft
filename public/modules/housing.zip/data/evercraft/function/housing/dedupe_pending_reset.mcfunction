# ============================================================
# Housing — drop a prior pending_reset entry for (owner, gs_id) == pr_new
# Macro args: {u0,u1,u2,u3,gs} = the entry about to be appended.
# `data remove` on a list[{filter}] path removes the FIRST match; the marker's
# 2s poll can re-enter on_break before kill @s lands, so guard against the
# same orphan being queued twice. One command (at most one prior dup exists,
# since this runs on every enqueue).
# ============================================================

$data remove storage evercraft:housing pending_reset[{u0:$(u0),u1:$(u1),u2:$(u2),u3:$(u3),gs:$(gs)}]
