# ============================================================
# Stash Settings — Flip the crate handling tag
# Run as: player with HS.InSettings
# ------------------------------------------------------------
# Mirrors do_toggle, but flips the single hs.crate_open boolean
# instead of a keep-category. set = "open + sort", unset = "stash
# whole" (the suggested default state is unset).
# ============================================================

# Read current state before modifying.
scoreboard players set #hs_crate hs.temp 0
execute if entity @s[tag=hs.crate_open] run scoreboard players set #hs_crate hs.temp 1

# Toggle.
execute if score #hs_crate hs.temp matches 1 run tag @s remove hs.crate_open
execute if score #hs_crate hs.temp matches 0 run tag @s add hs.crate_open

# Refresh all displays.
execute at @s run function evercraft:housing/stash/keep/refresh_settings

# Sound (matches do_toggle).
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.hat master @s ~ ~ ~ 0.5 1.8
