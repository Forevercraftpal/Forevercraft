# ============================================================
# Quick Stash — Find container for category + insert item (macro)
# Run as: player (with hs.stashing tag), at player
# Args: slot (inventory slot), category (container category)
# ============================================================

# Check keep — player wants to keep this category
$execute if entity @s[tag=hs.keep_$(category)] run return 0

# Remote mode: delegate to cross-dimension barrel finder
$execute if entity @s[tag=hs.remote_stash] run return run function evercraft:housing/stash/find_barrel_remote {slot:"$(slot)",category:"$(category)"}

# Try to find a container with matching category within 32 blocks
scoreboard players set #hs_insert hs.temp 0
$execute at @s positioned as @e[type=marker,tag=HS.Stash,distance=..32,nbt={data:{category:"$(category)"}},limit=1] align xyz store result score #hs_insert hs.temp run function evercraft:housing/stash/try_insert {slot:"$(slot)"}
execute if score #hs_insert hs.temp matches 1 run return 1

# Category barrel full/absent (would spill to overflow). For a LARGE single-item
# haul (>256), a clean home is preferred over the shared overflow barrel:
#   1. an empty Baúl block (the single-item bulk store) — chosen FIRST, since a
#      Baúl IS the natural home for a big single-item haul. Locks it + funnels
#      the whole haul into its 9,999 count.
#   2. else a clean empty labeled container (real-slot chest/barrel).
# Both move the WHOLE haul of this id in one shot (dwindling-count fix) and run
# only on this category-miss, so cost is bounded. Non-remote by construction —
# remote stashing already returned at the hs.remote_stash delegate above. (Joseph 2026-05-29)
scoreboard players set #bb_claimed hs.temp 0
$execute store result score #bb_claimed hs.temp run function evercraft:housing/stash/claim_empty_baul {slot:"$(slot)"}
execute if score #bb_claimed hs.temp matches 1.. run return 1

scoreboard players set #hs_prefer hs.temp 0
$execute store result score #hs_prefer hs.temp run function evercraft:housing/stash/prefer_empty_labeled {slot:"$(slot)"}
execute if score #hs_prefer hs.temp matches 1.. run return 1

# Primary container full or not found → try overflow fallback
$execute at @s positioned as @e[type=marker,tag=HS.Stash,distance=..32,nbt={data:{category:"overflow"}},limit=1] align xyz store result score #hs_insert hs.temp run function evercraft:housing/stash/try_insert {slot:"$(slot)"}
execute if score #hs_insert hs.temp matches 1 run return 1

# No space anywhere — increment failed counter
scoreboard players add @s hs.failed 1
