# ============================================================
# Quick Stash — Empty-container preference: count, pick, move (macro)
# Run as: the stashing player (@s), at @s. Args: id (the haul item id).
# Sets #hs_pref_placed hs.temp = 1 if at least one stack was placed into
# an empty labeled container, else 0. (Read back by prefer_empty_labeled.)
# ============================================================

scoreboard players set #hs_pref_placed hs.temp 0

# --- Step 1: how many of this id does the player hold? (dry-run clear) ---
# Same count-0 idiom as bulk_route: "clear @s <id> 0" reports the total
# held without removing anything.
$execute store result score #hs_haul_have hs.temp run clear @s $(id) 0

# --- Step 2: threshold gate (HS_LARGE_HAUL = 256) -----------------------
# Small hauls (<= 256) route exactly as today: bail with placed=0 so
# find_barrel falls straight through to its overflow attempt.
# *** Retune the haul threshold by editing the literal 256 here. ***
execute if score #hs_haul_have hs.temp matches ..256 run return 0

# --- Step 3: pick + lock onto ONE empty labeled container ---------------
# #hs_pick is a guard so only the FIRST (nearest) empty container is
# tagged HS.EmptyTarget. Forking "positioned as @e[multi]" keeps @s = the
# player (needed for try_insert / do_insert's "from entity @s").
# Defensive: clear any stale lock tag before picking (in case a prior run
# was interrupted before its step-5 cleanup).
tag @e[type=marker,tag=HS.EmptyTarget] remove HS.EmptyTarget
scoreboard players set #hs_pick hs.temp 0
# "align xyz positioned ~0.5 ~ ~0.5" mirrors label/raycast: HS.Stash markers
# are summoned at block-center-X/Z, floor-Y, so re-centering puts the marker
# at distance 0 for the distance=..0.5 re-select inside tag_first_empty while
# block ~ ~ ~ container.N reads still resolve to this same container block.
execute at @s positioned as @e[type=marker,tag=HS.Stash,distance=..32,sort=nearest] align xyz positioned ~0.5 ~ ~0.5 run function evercraft:housing/stash/tag_first_empty

# No empty labeled container found -> let find_barrel use overflow. Nothing
# was tagged, so there is no HS.EmptyTarget to clean up.
execute if score #hs_pick hs.temp matches 0 run return 0

# --- Step 4: move ALL of this id's stacks into the tagged container -----
# empty_move_loop iterates player slots 9-35; each matching stack is
# try_insert'ed into the HS.EmptyTarget container until it fills or the
# player has no more of this id. Counts land via try_insert's hs.stashed.
# #hs_target_full latches when the container fills (then the remainder
# falls through find_barrel's overflow path — nothing is voided).
scoreboard players set #hs_target_full hs.temp 0
$function evercraft:housing/stash/empty_move_loop {id:"$(id)"}

# --- Step 5: ALWAYS clear the transient lock tag -----------------------
tag @e[type=marker,tag=HS.EmptyTarget] remove HS.EmptyTarget

# Report success if any stack actually moved into the empty container.
return run scoreboard players get #hs_pref_placed hs.temp
