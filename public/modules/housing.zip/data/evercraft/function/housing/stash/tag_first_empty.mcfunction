# ============================================================
# Quick Stash — Tag the first empty labeled container (fork body)
# Run as: the stashing player (@s), positioned at one HS.Stash container
#         block CENTER (caller did align xyz positioned ~0.5 ~ ~0.5).
#         Forked once per HS.Stash marker, nearest-first, by
#         prefer_empty_labeled_do step 3.
# ------------------------------------------------------------
# Marks the FIRST (nearest) fully-empty labeled container with the
# transient HS.EmptyTarget tag, guarded by #hs_pick so only one wins.
# The marker sits at this block center, so it is the marker within
# distance ..0.5 of here. We tag the MARKER (not @s). The block ~ ~ ~
# container.N reads still resolve to this container block.
#
# "Fully empty" proxy: container.0 AND container.26 both empty. A clean,
# unused 27-slot container has every slot empty, so checking the first and
# last slot is a cheap stand-in for "nothing stored here yet" without
# scanning all 27. (A partially-filled container fails one of the two and
# is correctly skipped — we only want pristine containers for the haul.)
# The container's category label does not matter: an empty barrel of any
# category (including an empty overflow) is eligible.
# ============================================================

# Already locked onto an empty container (a nearer fork won) -> stop. This
# early-out guarantees the guard is still 0 below, so the tag only ever
# lands on the block this very fork just detected as empty.
execute if score #hs_pick hs.temp matches 1 run return 0

# Only act when THIS block is fully empty (cheap first+last slot proxy).
# Tag its marker AND raise the guard together so exactly one container wins.
execute unless items block ~ ~ ~ container.0 * unless items block ~ ~ ~ container.26 * run scoreboard players set #hs_pick hs.temp 1
execute if score #hs_pick hs.temp matches 1 run tag @e[type=marker,tag=HS.Stash,distance=..0.5,limit=1] add HS.EmptyTarget
