# ============================================================
# Quick Stash — Big-haul claim into an EMPTY Baúl block (macro)
# Run as: the stashing player (@s), at @s. Args: slot.
# ------------------------------------------------------------
# A large single-item haul (>256 = >4 stacks) whose category barrel is full or
# absent (find_barrel reached here) claims the nearest EMPTY (unlocked) Baúl
# block in range: locks it to the item + funnels the whole haul into its 9,999
# count. Preferred over a generic empty chest and over overflow — a Baúl IS the
# single-item bulk home, so an un-homed big haul belongs there. The Baúl's own
# ec.bb_marker (auto-created on placement) is its intrinsic, non-relabelable
# label, so no Stash Label is involved (which would corrupt the count store).
# Returns 1 if it placed the haul, else 0. (Joseph 2026-05-29)
# ============================================================

# Read the slot's item id + full template.
$data modify storage evercraft:bb_route id set from entity @s Inventory[{Slot:$(slot)b}].id
$data modify storage evercraft:bb_route claim_item set from entity @s Inventory[{Slot:$(slot)b}]

# Count the player's total of this id; only big hauls (>256) qualify.
function evercraft:housing/stash/bulk_count with storage evercraft:bb_route
execute unless score #bb_have ec.var matches 257.. run return 0

# Find the nearest EMPTY (unlocked) Baúl in range and tag it, so the lock +
# deposit operate on exactly that one (re-selecting by bb_locked:0b would drift
# the instant we lock it). Atomic within this synchronous call — multiplayer-safe.
tag @e[tag=ec.bb_claim] remove ec.bb_claim
execute as @e[type=marker,tag=ec.bb_marker,distance=..32,nbt={data:{bb_locked:0b}},sort=nearest,limit=1] run tag @s add ec.bb_claim
execute unless entity @e[tag=ec.bb_claim,limit=1] run return 0

# Lock the claimed Baúl to this item (id + template normalized to a single, slot-less unit).
data modify entity @e[tag=ec.bb_claim,limit=1] data.bb_id set from storage evercraft:bb_route id
data modify entity @e[tag=ec.bb_claim,limit=1] data.bb_item set from storage evercraft:bb_route claim_item
data remove entity @e[tag=ec.bb_claim,limit=1] data.bb_item.Slot
data modify entity @e[tag=ec.bb_claim,limit=1] data.bb_item.count set value 1
data modify entity @e[tag=ec.bb_claim,limit=1] data.bb_locked set value 1b

# Deposit min(have, 9999) into the count.
scoreboard players set #bb_take ec.var 9999
execute if score #bb_have ec.var < #bb_take ec.var run scoreboard players operation #bb_take ec.var = #bb_have ec.var
execute store result entity @e[tag=ec.bb_claim,limit=1] data.bb_count int 1 run scoreboard players get #bb_take ec.var

# Remove that many of the item from the player.
execute store result storage evercraft:bb_route n int 1 run scoreboard players get #bb_take ec.var
function evercraft:housing/stash/bulk_take with storage evercraft:bb_route

# Refresh the claimed Baúl's front display, then release the claim tag.
execute at @e[tag=ec.bb_claim,limit=1] run function evercraft:bulk_barrel/update_display
tag @e[tag=ec.bb_claim] remove ec.bb_claim

# Count toward the stash report + report placed.
scoreboard players add @s hs.stashed 1
return 1
