# ============================================================
# Quick Stash — Categorize + route ONE buffer slot (macro)
# Run as: player (with hs.stashing tag), with the buffer within ..1.
# Args: bslot (chest_minecart buffer slot 0-26)
# ------------------------------------------------------------
# Buffer-sourced mirror of housing/stash/route_slot's category
# chain (same precedence order). Tests the buffer entity's slot via
# the items predicate, then hands the matched category to
# find_cat_barrel which inserts FROM the buffer slot into that
# category's labeled barrel. No category match -> overflow fallback
# (same as route_slot). hs.keep_* is intentionally NOT honored here:
# opened-crate contents are new loot being sorted into storage, not
# items the player is choosing to keep in their inventory.
# ============================================================

# Skip empty buffer slots.
$execute unless items entity @e[type=chest_minecart,tag=ec.cd_buffer,distance=..1,sort=nearest,limit=1] container.$(bslot) * run return 0

# Artifacts (custom_data check — before item tags)
$execute if items entity @e[type=chest_minecart,tag=ec.cd_buffer,distance=..1,sort=nearest,limit=1] container.$(bslot) *[custom_data~{is_artifact:true}] run return run function evercraft:housing/stash/crate_open/find_cat_barrel {bslot:"$(bslot)",category:"artifacts"}

# Potions (before weapons)
$execute if items entity @e[type=chest_minecart,tag=ec.cd_buffer,distance=..1,sort=nearest,limit=1] container.$(bslot) #evercraft:stash/potions run return run function evercraft:housing/stash/crate_open/find_cat_barrel {bslot:"$(bslot)",category:"potions"}

# Weapons (before tools)
$execute if items entity @e[type=chest_minecart,tag=ec.cd_buffer,distance=..1,sort=nearest,limit=1] container.$(bslot) #evercraft:stash/weapons run return run function evercraft:housing/stash/crate_open/find_cat_barrel {bslot:"$(bslot)",category:"weapons"}

# Tools
$execute if items entity @e[type=chest_minecart,tag=ec.cd_buffer,distance=..1,sort=nearest,limit=1] container.$(bslot) #evercraft:stash/tools run return run function evercraft:housing/stash/crate_open/find_cat_barrel {bslot:"$(bslot)",category:"tools"}

# Armor
$execute if items entity @e[type=chest_minecart,tag=ec.cd_buffer,distance=..1,sort=nearest,limit=1] container.$(bslot) #evercraft:stash/armor run return run function evercraft:housing/stash/crate_open/find_cat_barrel {bslot:"$(bslot)",category:"armor"}

# Food
$execute if items entity @e[type=chest_minecart,tag=ec.cd_buffer,distance=..1,sort=nearest,limit=1] container.$(bslot) #evercraft:stash/food run return run function evercraft:housing/stash/crate_open/find_cat_barrel {bslot:"$(bslot)",category:"food"}

# Mob Drops (before materials)
$execute if items entity @e[type=chest_minecart,tag=ec.cd_buffer,distance=..1,sort=nearest,limit=1] container.$(bslot) #evercraft:stash/mob_drops run return run function evercraft:housing/stash/crate_open/find_cat_barrel {bslot:"$(bslot)",category:"mob_drops"}

# Garden (before blocks)
$execute if items entity @e[type=chest_minecart,tag=ec.cd_buffer,distance=..1,sort=nearest,limit=1] container.$(bslot) #evercraft:stash/garden run return run function evercraft:housing/stash/crate_open/find_cat_barrel {bslot:"$(bslot)",category:"garden"}

# Redstone (before materials)
$execute if items entity @e[type=chest_minecart,tag=ec.cd_buffer,distance=..1,sort=nearest,limit=1] container.$(bslot) #evercraft:stash/redstone run return run function evercraft:housing/stash/crate_open/find_cat_barrel {bslot:"$(bslot)",category:"redstone"}

# Amenities (before blocks)
$execute if items entity @e[type=chest_minecart,tag=ec.cd_buffer,distance=..1,sort=nearest,limit=1] container.$(bslot) #evercraft:stash/amenities run return run function evercraft:housing/stash/crate_open/find_cat_barrel {bslot:"$(bslot)",category:"amenities"}

# Materials
$execute if items entity @e[type=chest_minecart,tag=ec.cd_buffer,distance=..1,sort=nearest,limit=1] container.$(bslot) #evercraft:stash/materials run return run function evercraft:housing/stash/crate_open/find_cat_barrel {bslot:"$(bslot)",category:"materials"}

# Blocks
$execute if items entity @e[type=chest_minecart,tag=ec.cd_buffer,distance=..1,sort=nearest,limit=1] container.$(bslot) #evercraft:stash/blocks run return run function evercraft:housing/stash/crate_open/find_cat_barrel {bslot:"$(bslot)",category:"blocks"}

# No category match -> overflow
$function evercraft:housing/stash/crate_open/find_cat_barrel {bslot:"$(bslot)",category:"overflow"}
