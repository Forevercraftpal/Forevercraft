# ============================================================
# Quick Stash — Execute item transfer (macro)
# Run as: player, positioned at barrel block (aligned)
# Args: slot (player inventory slot), barrel_slot (barrel container slot)
# Returns: 1 on success
# ============================================================

# Copy item from player inventory to barrel
$execute store success score #stash_ok ec.temp run item replace block ~ ~ ~ container.$(barrel_slot) from entity @s container.$(slot)

# Clear the player's inventory slot (only if the copy succeeded)
$execute if score #stash_ok ec.temp matches 1 run item replace entity @s container.$(slot) with minecraft:air

# Track count
scoreboard players add @s hs.stashed 1

return 1
