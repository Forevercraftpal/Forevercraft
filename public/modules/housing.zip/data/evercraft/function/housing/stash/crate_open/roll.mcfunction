# ============================================================
# Quick Stash — Roll the crate loot into the buffer (macro)
# Run as: player, with the buffer (tag=ec.cd_buffer) within ..1.
# Macro args: loot_table (the crate's container_loot table id)
# ------------------------------------------------------------
# loot replace entity fills all 27 buffer slots and never voids
# overflow (cf. crates/dump_into_container/deposit).
# ============================================================
$loot replace entity @e[type=chest_minecart,tag=ec.cd_buffer,distance=..1,sort=nearest,limit=1] container.0 27 loot $(loot_table)
