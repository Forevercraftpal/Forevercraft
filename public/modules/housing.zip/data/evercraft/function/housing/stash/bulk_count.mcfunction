# ============================================================
# Quick Stash — count the player's total of an item id (macro)
# Run as: the stashing player (@s). Args: id (item id string).
# Sets #bb_have ec.var via dry-run clear (count 0 reports without removing).
# ============================================================
$execute store result score #bb_have ec.var run clear @s $(id) 0
