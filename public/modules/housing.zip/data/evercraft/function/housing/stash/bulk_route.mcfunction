# ============================================================
# Quick Stash — Baúl funnel (macro)
# Run as: the stashing player (@s), at @s. Args: id (the slot item's id string).
# ------------------------------------------------------------
# A locked Baúl "inherently labels" itself by the item it holds, so
# Quick-Stash funnels matching items into its 9,999 count before the generic
# category barrels. Sets #bb_routed hs.temp = 1 if ANY amount was deposited
# (route_slot then returns the slot once it is empty). If no matching barrel
# exists, or it is full, leaves #bb_routed 0 so the item falls through to the
# normal category chain. (Joseph 2026-05-29)
# ============================================================

# No locked Baúl within 32 blocks holds this id -> nothing to do.
$execute unless entity @e[type=marker,tag=ec.bb_marker,distance=..32,nbt={data:{bb_locked:1b,bb_id:"$(id)"}},limit=1] run return 0

# Remaining capacity of the nearest matching barrel.
$execute store result score #bb_count ec.var run data get entity @e[type=marker,tag=ec.bb_marker,distance=..32,nbt={data:{bb_locked:1b,bb_id:"$(id)"}},sort=nearest,limit=1] data.bb_count
scoreboard players set #bb_cap ec.var 9999
scoreboard players operation #bb_cap ec.var -= #bb_count ec.var
execute if score #bb_cap ec.var matches ..0 run return 0

# How many of this id the player holds (dry-run clear returns the total).
$execute store result score #bb_have ec.var run clear @s $(id) 0
execute if score #bb_have ec.var matches ..0 run return 0

# Take min(have, remaining cap).
scoreboard players operation #bb_take ec.var = #bb_have ec.var
execute if score #bb_take ec.var > #bb_cap ec.var run scoreboard players operation #bb_take ec.var = #bb_cap ec.var

# Remove exactly that many from the player.
execute store result storage evercraft:bb_route n int 1 run scoreboard players get #bb_take ec.var
function evercraft:housing/stash/bulk_take with storage evercraft:bb_route

# Add to the barrel's stored count + persist on the nearest matching marker.
scoreboard players operation #bb_count ec.var += #bb_take ec.var
$execute store result entity @e[type=marker,tag=ec.bb_marker,distance=..32,nbt={data:{bb_locked:1b,bb_id:"$(id)"}},sort=nearest,limit=1] data.bb_count int 1 run scoreboard players get #bb_count ec.var

# Refresh that barrel's front display (run AT the marker so update_display's
# distance=..1 reads resolve to this barrel's icon/count entities).
$execute at @e[type=marker,tag=ec.bb_marker,distance=..32,nbt={data:{bb_locked:1b,bb_id:"$(id)"}},sort=nearest,limit=1] run function evercraft:bulk_barrel/update_display

# Mark routed + count it toward the stash report.
scoreboard players set #bb_routed hs.temp 1
scoreboard players add @s hs.stashed 1
