# ============================================================
# Quick Stash — Move buffer slot -> empty barrel slot (macro)
# Run as: player, positioned + aligned AT the barrel block (the
#         buffer was teleported onto this block; selected ..1).
# Args: bslot (buffer slot), cslot (empty barrel slot)
# Returns: 1 on success.
# ------------------------------------------------------------
# Buffer-sourced mirror of housing/stash/do_insert + Feature-B
# do_place. Copies the buffer stack into the barrel, clears the
# buffer slot, and bumps the stashed counter for the report.
# ============================================================
$item replace block ~ ~ ~ container.$(cslot) from entity @e[type=chest_minecart,tag=ec.cd_buffer,distance=..1,sort=nearest,limit=1] container.$(bslot)
$data remove entity @e[type=chest_minecart,tag=ec.cd_buffer,distance=..1,sort=nearest,limit=1] Items[{Slot:$(bslot)b}]
scoreboard players add @s hs.stashed 1
return 1
