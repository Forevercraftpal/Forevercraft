# ============================================================
# Quick Stash — Move the whole haul into the tagged empty container (macro)
# Run as: the stashing player (@s), at @s. Args: id (the haul item id).
# ------------------------------------------------------------
# Iterates player inventory slots 9-35 (mirrors iterate_slots) and hands
# each one to empty_move_slot, which moves it into the HS.EmptyTarget
# container only if its item id matches the haul id. Moving EVERY matching
# stack here (not just the slot that triggered the preference) is what
# prevents the dwindling-count bug: the entire haul lands together, so
# later route_slot iterations find empty player slots for this id and skip.
# Stops early (per-slot) once the target container reports full; the
# remainder then falls through find_barrel's normal overflow path.
# ============================================================
$function evercraft:housing/stash/empty_move_slot {slot:"9",id:"$(id)"}
$function evercraft:housing/stash/empty_move_slot {slot:"10",id:"$(id)"}
$function evercraft:housing/stash/empty_move_slot {slot:"11",id:"$(id)"}
$function evercraft:housing/stash/empty_move_slot {slot:"12",id:"$(id)"}
$function evercraft:housing/stash/empty_move_slot {slot:"13",id:"$(id)"}
$function evercraft:housing/stash/empty_move_slot {slot:"14",id:"$(id)"}
$function evercraft:housing/stash/empty_move_slot {slot:"15",id:"$(id)"}
$function evercraft:housing/stash/empty_move_slot {slot:"16",id:"$(id)"}
$function evercraft:housing/stash/empty_move_slot {slot:"17",id:"$(id)"}
$function evercraft:housing/stash/empty_move_slot {slot:"18",id:"$(id)"}
$function evercraft:housing/stash/empty_move_slot {slot:"19",id:"$(id)"}
$function evercraft:housing/stash/empty_move_slot {slot:"20",id:"$(id)"}
$function evercraft:housing/stash/empty_move_slot {slot:"21",id:"$(id)"}
$function evercraft:housing/stash/empty_move_slot {slot:"22",id:"$(id)"}
$function evercraft:housing/stash/empty_move_slot {slot:"23",id:"$(id)"}
$function evercraft:housing/stash/empty_move_slot {slot:"24",id:"$(id)"}
$function evercraft:housing/stash/empty_move_slot {slot:"25",id:"$(id)"}
$function evercraft:housing/stash/empty_move_slot {slot:"26",id:"$(id)"}
$function evercraft:housing/stash/empty_move_slot {slot:"27",id:"$(id)"}
$function evercraft:housing/stash/empty_move_slot {slot:"28",id:"$(id)"}
$function evercraft:housing/stash/empty_move_slot {slot:"29",id:"$(id)"}
$function evercraft:housing/stash/empty_move_slot {slot:"30",id:"$(id)"}
$function evercraft:housing/stash/empty_move_slot {slot:"31",id:"$(id)"}
$function evercraft:housing/stash/empty_move_slot {slot:"32",id:"$(id)"}
$function evercraft:housing/stash/empty_move_slot {slot:"33",id:"$(id)"}
$function evercraft:housing/stash/empty_move_slot {slot:"34",id:"$(id)"}
$function evercraft:housing/stash/empty_move_slot {slot:"35",id:"$(id)"}
