# ============================================================
# Stash Label — Container Found
# Run as: player, positioned at container block center (aligned)
# Checks for existing label and creates/cycles category
# ============================================================
tag @s add HS.BarrelFound

# Baúles are self-labeling — Quick-Stash funnels matching items into them
# automatically, and they store a count (not real slots), so a Stash Label would
# corrupt them. Refuse to label one. (Joseph 2026-05-29)
data modify storage evercraft:notify stage.c set value [{text:"A Ba\u00fal already sorts its own item automatically — no label needed.",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 45
execute if entity @e[type=marker,tag=ec.bb_marker,distance=..0.8,limit=1] run return run function evercraft:util/notify/emit

# If this container already has a stash marker → cycle category
execute if entity @e[type=marker,tag=HS.Stash,distance=..0.5,limit=1] run return run function evercraft:housing/stash/label/cycle_category

# === New label — assign "Tools" (first category) ===
summon marker ~ ~ ~ {Tags:["HS.Stash","smithed.entity"],data:{category:"tools"}}
execute positioned ~ ~1.05 ~ run function evercraft:housing/stash/label/spawn_display {title:"Tools",color:"yellow"}

# Feedback
data modify storage evercraft:notify stage.c set value [{text:"Container labeled: ",color:"gray"},{text:"Tools",color:"yellow"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
playsound minecraft:block.note_block.bell master @a[distance=..5,scores={ec.fx_snd=1..}] ~ ~ ~ 0.5 1.4
