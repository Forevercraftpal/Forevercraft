# ============================================================
# Quick Stash — Categorize + route one inventory slot (macro)
# Run as: player (with hs.stashing tag)
# Args: slot (inventory slot number 9-35)
# ============================================================

# Skip empty slots
$execute unless items entity @s container.$(slot) * run return 0

# Never stash the label item itself
$execute if items entity @s container.$(slot) *[custom_data~{stash_label:true}] run return 0

# === Crate handling (before the normal category chain) ===
# A crate is any item carrying a minecraft:container_loot component (a
# deferred loot-table ref). Detection is component-presence, type-agnostic
# (cf. the *[minecraft:trim] / *[minecraft:custom_name] idiom elsewhere).
# Player setting hs.crate_open chooses the behavior:
#   unset  -> "stash whole": file the crate item into a crates barrel as-is
#   set    -> "open + sort": roll it open + route each item to its category
# Open+sort needs LOCAL barrels (it rolls into a buffer at the player and
# teleports it onto barrels within 32 blocks), so it is gated to non-remote
# stashing. In remote (satchel) mode a crate is always filed WHOLE to the
# remote crates barrel.
$execute if items entity @s container.$(slot) *[minecraft:container_loot] if entity @s[tag=hs.remote_stash] run return run function evercraft:housing/stash/find_barrel {slot:"$(slot)",category:"crates"}
$execute if items entity @s container.$(slot) *[minecraft:container_loot] unless entity @s[tag=hs.crate_open] run return run function evercraft:housing/stash/find_barrel {slot:"$(slot)",category:"crates"}
$execute if items entity @s container.$(slot) *[minecraft:container_loot] if entity @s[tag=hs.crate_open] run return run function evercraft:housing/stash/crate_open {slot:"$(slot)"}

# === Baúl funnel (after crates, before categories) ===
# A locked Baúl auto-acts as a Quick-Stash sink for its OWN item — it is
# "inherently labeled" by what it holds, so matching items funnel into its
# 9,999 count before any generic category barrel. No manual Stash Label needed
# (and labeling one is refused — it would corrupt the count-based store). If the
# barrel is absent/full it leaves #bb_routed 0 and the item falls through; if it
# filled mid-deposit, the slot's leftover also falls through. (Joseph 2026-05-29)
$data modify storage evercraft:bb_route id set from entity @s Inventory[{Slot:$(slot)b}].id
scoreboard players set #bb_routed hs.temp 0
function evercraft:housing/stash/bulk_route with storage evercraft:bb_route
$execute if score #bb_routed hs.temp matches 1 unless items entity @s container.$(slot) * run return 0

# === Category detection (first match wins) ===

# Artifacts (custom_data check — before item tags)
$execute if items entity @s container.$(slot) *[custom_data~{is_artifact:true}] run return run function evercraft:housing/stash/find_barrel {slot:"$(slot)",category:"artifacts"}

# Potions (before weapons — catch potion items early)
$execute if items entity @s container.$(slot) #evercraft:stash/potions run return run function evercraft:housing/stash/find_barrel {slot:"$(slot)",category:"potions"}

# Weapons (before tools — swords are in both)
$execute if items entity @s container.$(slot) #evercraft:stash/weapons run return run function evercraft:housing/stash/find_barrel {slot:"$(slot)",category:"weapons"}

# Tools
$execute if items entity @s container.$(slot) #evercraft:stash/tools run return run function evercraft:housing/stash/find_barrel {slot:"$(slot)",category:"tools"}

# Armor
$execute if items entity @s container.$(slot) #evercraft:stash/armor run return run function evercraft:housing/stash/find_barrel {slot:"$(slot)",category:"armor"}

# Food
$execute if items entity @s container.$(slot) #evercraft:stash/food run return run function evercraft:housing/stash/find_barrel {slot:"$(slot)",category:"food"}

# Mob Drops (before materials — many moved from materials)
$execute if items entity @s container.$(slot) #evercraft:stash/mob_drops run return run function evercraft:housing/stash/find_barrel {slot:"$(slot)",category:"mob_drops"}

# Garden (before blocks — plants could be blocks)
$execute if items entity @s container.$(slot) #evercraft:stash/garden run return run function evercraft:housing/stash/find_barrel {slot:"$(slot)",category:"garden"}

# Redstone (before materials — redstone dust moved from materials)
$execute if items entity @s container.$(slot) #evercraft:stash/redstone run return run function evercraft:housing/stash/find_barrel {slot:"$(slot)",category:"redstone"}

# Amenities (before blocks — furniture items)
$execute if items entity @s container.$(slot) #evercraft:stash/amenities run return run function evercraft:housing/stash/find_barrel {slot:"$(slot)",category:"amenities"}

# Materials
$execute if items entity @s container.$(slot) #evercraft:stash/materials run return run function evercraft:housing/stash/find_barrel {slot:"$(slot)",category:"materials"}

# Blocks
$execute if items entity @s container.$(slot) #evercraft:stash/blocks run return run function evercraft:housing/stash/find_barrel {slot:"$(slot)",category:"blocks"}

# No category match → overflow
$function evercraft:housing/stash/find_barrel {slot:"$(slot)",category:"overflow"}
