# ============================================================
# Quick Stash — Large-haul preference: empty labeled container (macro)
# Run as: the stashing player (@s), at @s. Args: slot (inventory slot).
# Returns: 1 if it placed at least one stack of the haul into an empty
#          labeled container, else 0 (caller then tries overflow as today).
# ------------------------------------------------------------
# Only reached on a CATEGORY MISS in find_barrel — i.e. the item's own
# category barrel was full or absent and the route would otherwise spill
# to the overflow barrel. When the player is carrying a LARGE single-item
# haul (more than HS_LARGE_HAUL of one id, see below), we'd rather keep
# that haul together in a clean, unused labeled container than scatter it
# into the shared overflow. So: find the nearest fully-empty labeled stash
# container and dump the WHOLE haul of this id into it. If no empty one
# exists, return 0 and let find_barrel fall to overflow unchanged.
#
# Threshold: HS_LARGE_HAUL = 256 (more than 4 stacks of a 64-stackable).
#   Joseph 2026-05-29 picked >256; >512 was also considered. To retune,
#   change the single literal "256" on the matches line in step 2 below.
#
# DWINDLING-COUNT FIX: find_barrel is called once per inventory slot, and
# try_insert moves only one stack per call. If we placed just the current
# stack and re-tested "remaining > 256" next slot, the count would drop
# below threshold after the first stack and the rest would wrongly spill to
# overflow. So once the preference fires we move ALL of this id's stacks
# into the SAME chosen container in one operation (empty_move_loop). Later
# route_slot iterations then find empty player slots for this id and skip.
# ============================================================

# Read this slot's item id into storage so we can carry it as a macro arg.
$data modify storage evercraft:hs_haul id set from entity @s Inventory[{Slot:$(slot)b}].id

# Defensive: empty slot -> nothing to prefer.
$execute unless items entity @s container.$(slot) * run return 0

# Hand the id to the count-and-place macro.
function evercraft:housing/stash/prefer_empty_labeled_do with storage evercraft:hs_haul
return run scoreboard players get #hs_pref_placed hs.temp
