# ============================================================
# Quick Stash — Move ONE matching slot into the tagged empty container
# Run as: the stashing player (@s), at @s. Args: slot, id.
# ------------------------------------------------------------
# Moves player inventory slot $(slot) into the HS.EmptyTarget container
# ONLY if it holds the haul id and the target is not already full. Uses
# the same positioned-as-marker + align xyz + try_insert idiom as
# find_barrel; try_insert moves the stack into the first empty container
# slot and returns 1, or 0 when the container is full. @s stays the player
# the whole way (try_insert / do_insert need "from entity @s").
#
# #hs_target_full (set by prefer_empty_labeled_do before the loop) latches
# once the container fills, so the remaining matching stacks are left in the
# inventory and fall through find_barrel's normal overflow path next pass —
# nothing is voided.
# ============================================================

# Target already full -> leave this stack for the overflow fallback.
execute if score #hs_target_full hs.temp matches 1 run return 0

# Skip slots that do not hold the haul id (other items keep their own routing).
$execute unless items entity @s container.$(slot) $(id) run return 0

# Insert this stack into the locked empty container. #hs_ins = try_insert's
# return (1 placed, 0 container full). Mirrors find_barrel's call site.
scoreboard players set #hs_ins hs.temp 0
$execute at @s positioned as @e[type=marker,tag=HS.EmptyTarget,limit=1] align xyz store result score #hs_ins hs.temp run function evercraft:housing/stash/try_insert {slot:"$(slot)"}

# Placed -> remember the preference fired (so the caller returns 1).
execute if score #hs_ins hs.temp matches 1 run scoreboard players set #hs_pref_placed hs.temp 1

# Container full -> latch the guard so later slots skip and spill to overflow.
execute if score #hs_ins hs.temp matches 0 run scoreboard players set #hs_target_full hs.temp 1
