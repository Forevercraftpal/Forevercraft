# ============================================================
# Quick Stash — Drop any unplaced buffer items at the player
# Run as: player, at player, buffer teleported back to @s (..2).
# ------------------------------------------------------------
# Anything still in the buffer found no labeled barrel (no matching
# category barrel, no overflow, or both full). It must NOT be voided
# when the buffer is killed, so eject each remaining stack as an item
# entity at the player's feet. One unrolled call per buffer slot.
# ============================================================
function evercraft:housing/stash/crate_open/drop_slot {bslot:"0"}
function evercraft:housing/stash/crate_open/drop_slot {bslot:"1"}
function evercraft:housing/stash/crate_open/drop_slot {bslot:"2"}
function evercraft:housing/stash/crate_open/drop_slot {bslot:"3"}
function evercraft:housing/stash/crate_open/drop_slot {bslot:"4"}
function evercraft:housing/stash/crate_open/drop_slot {bslot:"5"}
function evercraft:housing/stash/crate_open/drop_slot {bslot:"6"}
function evercraft:housing/stash/crate_open/drop_slot {bslot:"7"}
function evercraft:housing/stash/crate_open/drop_slot {bslot:"8"}
function evercraft:housing/stash/crate_open/drop_slot {bslot:"9"}
function evercraft:housing/stash/crate_open/drop_slot {bslot:"10"}
function evercraft:housing/stash/crate_open/drop_slot {bslot:"11"}
function evercraft:housing/stash/crate_open/drop_slot {bslot:"12"}
function evercraft:housing/stash/crate_open/drop_slot {bslot:"13"}
function evercraft:housing/stash/crate_open/drop_slot {bslot:"14"}
function evercraft:housing/stash/crate_open/drop_slot {bslot:"15"}
function evercraft:housing/stash/crate_open/drop_slot {bslot:"16"}
function evercraft:housing/stash/crate_open/drop_slot {bslot:"17"}
function evercraft:housing/stash/crate_open/drop_slot {bslot:"18"}
function evercraft:housing/stash/crate_open/drop_slot {bslot:"19"}
function evercraft:housing/stash/crate_open/drop_slot {bslot:"20"}
function evercraft:housing/stash/crate_open/drop_slot {bslot:"21"}
function evercraft:housing/stash/crate_open/drop_slot {bslot:"22"}
function evercraft:housing/stash/crate_open/drop_slot {bslot:"23"}
function evercraft:housing/stash/crate_open/drop_slot {bslot:"24"}
function evercraft:housing/stash/crate_open/drop_slot {bslot:"25"}
function evercraft:housing/stash/crate_open/drop_slot {bslot:"26"}
