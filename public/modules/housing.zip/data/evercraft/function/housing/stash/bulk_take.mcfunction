# ============================================================
# Quick Stash — Baúl funnel: remove n of an item (macro)
# Run as: the stashing player (@s). Args: id (item id string), n (amount).
# ============================================================
$clear @s $(id) $(n)
