# ============================================================
# Stash Label — Process (1 tick after consume)
# Run as: player, at player
# Restores label item + raycasts to find a container
# ============================================================
tag @s remove HS.Labeling

# Restore the consumed label item
function evercraft:housing/stash/label/give

# Refresh zone check (housing tick is 2s — score can be stale)
function evercraft:housing/zone/check

# Must be in hearthstone zone
data modify storage evercraft:notify stage.c set value [{text:"Must be near your Hearthstone.",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute unless score @s hs.in_zone matches 1 run return run function evercraft:util/notify/emit

# Raycast from eyes to find a container (max 5 blocks = 25 steps at 0.2)
scoreboard players set @s hs.temp 0
execute anchored eyes positioned ^ ^ ^0.2 run function evercraft:housing/stash/label/raycast

# If no container found, give feedback
data modify storage evercraft:notify stage.c set value [{text:"No container found. Look at a barrel or chest and try again.",color:"gray"}]
scoreboard players set #ndur ec.temp 45
execute unless entity @s[tag=HS.BarrelFound] run function evercraft:util/notify/emit
tag @s remove HS.BarrelFound
scoreboard players set @s hs.temp 0
