# ============================================================
# Quick Stash — Place one buffer slot into the first empty barrel
#               slot (macro)
# Run as: player, positioned + aligned AT the barrel block (the
#         buffer was teleported onto this block; selected ..1).
# Args: bslot (buffer slot 0-26)
# Returns: 1 on success, 0 if the barrel is full.
# ------------------------------------------------------------
# Buffer-sourced mirror of housing/stash/try_insert + Feature-B
# try_place. All container blocks expose 27 slots per block.
# ============================================================
$execute unless items block ~ ~ ~ container.0 * run return run function evercraft:housing/stash/crate_open/place_buffer {bslot:"$(bslot)",cslot:"0"}
$execute unless items block ~ ~ ~ container.1 * run return run function evercraft:housing/stash/crate_open/place_buffer {bslot:"$(bslot)",cslot:"1"}
$execute unless items block ~ ~ ~ container.2 * run return run function evercraft:housing/stash/crate_open/place_buffer {bslot:"$(bslot)",cslot:"2"}
$execute unless items block ~ ~ ~ container.3 * run return run function evercraft:housing/stash/crate_open/place_buffer {bslot:"$(bslot)",cslot:"3"}
$execute unless items block ~ ~ ~ container.4 * run return run function evercraft:housing/stash/crate_open/place_buffer {bslot:"$(bslot)",cslot:"4"}
$execute unless items block ~ ~ ~ container.5 * run return run function evercraft:housing/stash/crate_open/place_buffer {bslot:"$(bslot)",cslot:"5"}
$execute unless items block ~ ~ ~ container.6 * run return run function evercraft:housing/stash/crate_open/place_buffer {bslot:"$(bslot)",cslot:"6"}
$execute unless items block ~ ~ ~ container.7 * run return run function evercraft:housing/stash/crate_open/place_buffer {bslot:"$(bslot)",cslot:"7"}
$execute unless items block ~ ~ ~ container.8 * run return run function evercraft:housing/stash/crate_open/place_buffer {bslot:"$(bslot)",cslot:"8"}
$execute unless items block ~ ~ ~ container.9 * run return run function evercraft:housing/stash/crate_open/place_buffer {bslot:"$(bslot)",cslot:"9"}
$execute unless items block ~ ~ ~ container.10 * run return run function evercraft:housing/stash/crate_open/place_buffer {bslot:"$(bslot)",cslot:"10"}
$execute unless items block ~ ~ ~ container.11 * run return run function evercraft:housing/stash/crate_open/place_buffer {bslot:"$(bslot)",cslot:"11"}
$execute unless items block ~ ~ ~ container.12 * run return run function evercraft:housing/stash/crate_open/place_buffer {bslot:"$(bslot)",cslot:"12"}
$execute unless items block ~ ~ ~ container.13 * run return run function evercraft:housing/stash/crate_open/place_buffer {bslot:"$(bslot)",cslot:"13"}
$execute unless items block ~ ~ ~ container.14 * run return run function evercraft:housing/stash/crate_open/place_buffer {bslot:"$(bslot)",cslot:"14"}
$execute unless items block ~ ~ ~ container.15 * run return run function evercraft:housing/stash/crate_open/place_buffer {bslot:"$(bslot)",cslot:"15"}
$execute unless items block ~ ~ ~ container.16 * run return run function evercraft:housing/stash/crate_open/place_buffer {bslot:"$(bslot)",cslot:"16"}
$execute unless items block ~ ~ ~ container.17 * run return run function evercraft:housing/stash/crate_open/place_buffer {bslot:"$(bslot)",cslot:"17"}
$execute unless items block ~ ~ ~ container.18 * run return run function evercraft:housing/stash/crate_open/place_buffer {bslot:"$(bslot)",cslot:"18"}
$execute unless items block ~ ~ ~ container.19 * run return run function evercraft:housing/stash/crate_open/place_buffer {bslot:"$(bslot)",cslot:"19"}
$execute unless items block ~ ~ ~ container.20 * run return run function evercraft:housing/stash/crate_open/place_buffer {bslot:"$(bslot)",cslot:"20"}
$execute unless items block ~ ~ ~ container.21 * run return run function evercraft:housing/stash/crate_open/place_buffer {bslot:"$(bslot)",cslot:"21"}
$execute unless items block ~ ~ ~ container.22 * run return run function evercraft:housing/stash/crate_open/place_buffer {bslot:"$(bslot)",cslot:"22"}
$execute unless items block ~ ~ ~ container.23 * run return run function evercraft:housing/stash/crate_open/place_buffer {bslot:"$(bslot)",cslot:"23"}
$execute unless items block ~ ~ ~ container.24 * run return run function evercraft:housing/stash/crate_open/place_buffer {bslot:"$(bslot)",cslot:"24"}
$execute unless items block ~ ~ ~ container.25 * run return run function evercraft:housing/stash/crate_open/place_buffer {bslot:"$(bslot)",cslot:"25"}
$execute unless items block ~ ~ ~ container.26 * run return run function evercraft:housing/stash/crate_open/place_buffer {bslot:"$(bslot)",cslot:"26"}

# Barrel is full — no empty slot found.
return 0
