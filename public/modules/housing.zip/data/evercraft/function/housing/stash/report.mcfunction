# ============================================================
# Quick Stash — Report results to player
# Run as: player
# ============================================================

# Stashed items, no failures
execute if score @s hs.stashed matches 1.. if score @s hs.failed matches 0 run data modify storage evercraft:notify stage.c set value [{text:"Stashed ",color:"green"},{score:{name:"@s",objective:"hs.stashed"}},{text:" items!",color:"green"}]
execute if score @s hs.stashed matches 1.. if score @s hs.failed matches 0 run scoreboard players set #ndur ec.temp 45
execute if score @s hs.stashed matches 1.. if score @s hs.failed matches 0 run function evercraft:util/notify/emit

# Stashed some, some failed
execute if score @s hs.stashed matches 1.. if score @s hs.failed matches 1.. run data modify storage evercraft:notify stage.c set value [{text:"Stashed ",color:"green"},{score:{name:"@s",objective:"hs.stashed"}},{text:" items ",color:"green"},{text:"| ",color:"dark_gray"},{score:{name:"@s",objective:"hs.failed"}},{text:" had nowhere to go",color:"red"}]
execute if score @s hs.stashed matches 1.. if score @s hs.failed matches 1.. run scoreboard players set #ndur ec.temp 45
execute if score @s hs.stashed matches 1.. if score @s hs.failed matches 1.. run function evercraft:util/notify/emit

# None stashed, some failed
execute if score @s hs.stashed matches 0 if score @s hs.failed matches 1.. run data modify storage evercraft:notify stage.c set value [{text:"No containers matched your items!",color:"red"}]
execute if score @s hs.stashed matches 0 if score @s hs.failed matches 1.. run scoreboard players set #ndur ec.temp 45
execute if score @s hs.stashed matches 0 if score @s hs.failed matches 1.. run function evercraft:util/notify/emit

# Nothing to stash at all
execute if score @s hs.stashed matches 0 if score @s hs.failed matches 0 run data modify storage evercraft:notify stage.c set value [{text:"Nothing to stash!",color:"gray"}]
execute if score @s hs.stashed matches 0 if score @s hs.failed matches 0 run scoreboard players set #ndur ec.temp 45
execute if score @s hs.stashed matches 0 if score @s hs.failed matches 0 run function evercraft:util/notify/emit

# Sound
execute if score @s hs.stashed matches 1.. if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.item.pickup master @s ~ ~ ~ 0.5 0.7
execute if score @s hs.stashed matches 0 if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.villager.no master @s ~ ~ ~ 0.5 1.0
