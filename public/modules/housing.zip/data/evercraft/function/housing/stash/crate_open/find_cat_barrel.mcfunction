# ============================================================
# Quick Stash — Find labeled barrel for a category + insert from
#               the buffer slot (macro)
# Run as: player (with hs.stashing tag), at player, buffer nearby.
# Args: bslot (buffer slot), category (target category)
# ------------------------------------------------------------
# Buffer-sourced mirror of housing/stash/find_barrel. Locates the
# nearest marker labeled for this category within 32 blocks,
# teleports the buffer onto it (so the Feature-B distance=..1
# selectors line up), aligns to the barrel block, and inserts the
# buffer stack into the first empty barrel slot. Falls back to an
# overflow-labeled barrel. If neither has room, the stack stays in
# the buffer (never voided — dropped at the player by
# crate_open/drop_remaining before the buffer is killed) and
# hs.failed is bumped for the report.
# ============================================================

# --- Try the category's labeled barrel ---
scoreboard players set #hs_insert hs.temp 0
$execute if entity @e[type=marker,tag=HS.Stash,distance=..32,nbt={data:{category:"$(category)"}},limit=1] run tp @e[type=chest_minecart,tag=ec.cd_buffer,sort=nearest,limit=1] @e[type=marker,tag=HS.Stash,distance=..32,nbt={data:{category:"$(category)"}},limit=1]
$execute at @s positioned as @e[type=marker,tag=HS.Stash,distance=..32,nbt={data:{category:"$(category)"}},limit=1] align xyz store result score #hs_insert hs.temp run function evercraft:housing/stash/crate_open/insert_buffer {bslot:"$(bslot)"}
execute if score #hs_insert hs.temp matches 1 run return 1

# --- Overflow fallback ---
execute if entity @e[type=marker,tag=HS.Stash,distance=..32,nbt={data:{category:"overflow"}},limit=1] run tp @e[type=chest_minecart,tag=ec.cd_buffer,sort=nearest,limit=1] @e[type=marker,tag=HS.Stash,distance=..32,nbt={data:{category:"overflow"}},limit=1]
$execute at @s positioned as @e[type=marker,tag=HS.Stash,distance=..32,nbt={data:{category:"overflow"}},limit=1] align xyz store result score #hs_insert hs.temp run function evercraft:housing/stash/crate_open/insert_buffer {bslot:"$(bslot)"}
execute if score #hs_insert hs.temp matches 1 run return 1

# --- No space anywhere — leave it in the buffer (dropped later, never voided) ---
scoreboard players add @s hs.failed 1
