# ============================================================
# Stash Settings — Toggle crate handling mode
# Run as: the interaction entity (HS.CrateModeBtn)
# ------------------------------------------------------------
# Flips the per-player hs.crate_open tag, which Quick-Stash reads in
# route_slot when it hits a crate item:
#   unset -> "stash whole": file the crate into a crates barrel as-is
#   set   -> "open + sort": roll it open + sort each item by category
# Mirrors toggle_category -> do_toggle, but this is a single boolean
# setting (not a keep-category), so the flip lives here inline.
# ============================================================

# Clear interaction
data remove entity @s interaction

# Find the settings player and flip the tag.
execute as @p[tag=HS.InSettings,distance=..5] run function evercraft:housing/stash/keep/do_toggle_crate
