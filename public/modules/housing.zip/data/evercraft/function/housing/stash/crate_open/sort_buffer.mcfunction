# ============================================================
# Quick Stash — Sort every rolled buffer slot into category barrels
# Run as: player (with hs.stashing tag), with the buffer within ..1.
# ------------------------------------------------------------
# One unrolled call per buffer slot (mirrors iterate_slots /
# drain_loop). Each occupied slot is categorized then placed into
# its properly-labeled barrel.
# ============================================================
function evercraft:housing/stash/crate_open/route_buffer_slot {bslot:"0"}
function evercraft:housing/stash/crate_open/route_buffer_slot {bslot:"1"}
function evercraft:housing/stash/crate_open/route_buffer_slot {bslot:"2"}
function evercraft:housing/stash/crate_open/route_buffer_slot {bslot:"3"}
function evercraft:housing/stash/crate_open/route_buffer_slot {bslot:"4"}
function evercraft:housing/stash/crate_open/route_buffer_slot {bslot:"5"}
function evercraft:housing/stash/crate_open/route_buffer_slot {bslot:"6"}
function evercraft:housing/stash/crate_open/route_buffer_slot {bslot:"7"}
function evercraft:housing/stash/crate_open/route_buffer_slot {bslot:"8"}
function evercraft:housing/stash/crate_open/route_buffer_slot {bslot:"9"}
function evercraft:housing/stash/crate_open/route_buffer_slot {bslot:"10"}
function evercraft:housing/stash/crate_open/route_buffer_slot {bslot:"11"}
function evercraft:housing/stash/crate_open/route_buffer_slot {bslot:"12"}
function evercraft:housing/stash/crate_open/route_buffer_slot {bslot:"13"}
function evercraft:housing/stash/crate_open/route_buffer_slot {bslot:"14"}
function evercraft:housing/stash/crate_open/route_buffer_slot {bslot:"15"}
function evercraft:housing/stash/crate_open/route_buffer_slot {bslot:"16"}
function evercraft:housing/stash/crate_open/route_buffer_slot {bslot:"17"}
function evercraft:housing/stash/crate_open/route_buffer_slot {bslot:"18"}
function evercraft:housing/stash/crate_open/route_buffer_slot {bslot:"19"}
function evercraft:housing/stash/crate_open/route_buffer_slot {bslot:"20"}
function evercraft:housing/stash/crate_open/route_buffer_slot {bslot:"21"}
function evercraft:housing/stash/crate_open/route_buffer_slot {bslot:"22"}
function evercraft:housing/stash/crate_open/route_buffer_slot {bslot:"23"}
function evercraft:housing/stash/crate_open/route_buffer_slot {bslot:"24"}
function evercraft:housing/stash/crate_open/route_buffer_slot {bslot:"25"}
function evercraft:housing/stash/crate_open/route_buffer_slot {bslot:"26"}
