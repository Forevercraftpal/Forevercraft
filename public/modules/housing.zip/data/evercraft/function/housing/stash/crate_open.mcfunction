# ============================================================
# Quick Stash — Open a crate + sort its contents (macro)
# Run as: player (with hs.stashing tag), at player
# Args: slot (inventory slot holding the crate)
# ------------------------------------------------------------
# "Open + sort" mode (player set hs.crate_open). Rolls the crate's
# container_loot.loot_table into a temporary 27-slot chest_minecart
# buffer (same never-voids approach as the crate->chest dump), shows
# the shared "what you got" hover line, then routes EACH rolled item
# through the existing category detection into its PROPERLY-LABELED
# barrel (diamond -> materials, artifact -> artifacts, etc.) — not
# dumped into one container. The crate item is then consumed.
# Multiplayer-safe: the buffer is summoned AT this player and picked
# by a tight distance; per-slot inserts teleport the buffer onto the
# target barrel and select it distance=..1 (Feature-B pattern). The
# whole stash runs to completion as @s, so only one buffer exists at
# a time and the tight selector never cross-fires.
# ============================================================

# Read the crate's deferred loot table from the inventory slot.
$data modify storage evercraft:crate_loot open.loot_table set from entity @s container.$(slot).components."minecraft:container_loot".loot_table

# Bail if it somehow lost its container_loot (defensive — route_slot already gated).
execute unless data storage evercraft:crate_loot open.loot_table run return fail

# Summon a fresh 27-slot buffer at the player and roll the table into it.
# loot replace entity (NOT loot insert) keeps all 27 slots — never voids.
summon chest_minecart ~ ~ ~ {Tags:["ec.cd_buffer"],NoGravity:1b,Invulnerable:1b,Silent:1b,Items:[]}
function evercraft:housing/stash/crate_open/roll with storage evercraft:crate_loot open

# Reveal the shared "what you got" hover line (begin -> scan -> show),
# while the buffer is still full.
function evercraft:crates/loot_log/capture_and_show

# Route every rolled stack into its category's labeled barrel. Each
# insert teleports the buffer onto the chosen barrel; afterwards the
# buffer is back wherever the last insert left it, so pull it home.
function evercraft:housing/stash/crate_open/sort_buffer

# Bring the buffer back to the player, then drop anything that found no
# home (never voided), then remove the now-empty buffer.
tp @e[type=chest_minecart,tag=ec.cd_buffer,sort=nearest,limit=1] @s
function evercraft:housing/stash/crate_open/drop_remaining
kill @e[type=chest_minecart,tag=ec.cd_buffer,distance=..2,sort=nearest,limit=1]

# Consume exactly one crate from the inventory slot it came from.
$item replace entity @s container.$(slot) with minecraft:air
