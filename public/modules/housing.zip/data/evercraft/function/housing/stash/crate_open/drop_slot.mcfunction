# ============================================================
# Quick Stash — Drop one unplaced buffer slot at the player (macro)
# Run as: player, at player, buffer within ..2.
# Args: bslot (buffer slot 0-26)
# ------------------------------------------------------------
# If the buffer slot still holds a stack, eject it as an item entity
# at the player (never voided). Summon-then-populate idiom (cf.
# crates/dump_into_container/drain_slot).
# ============================================================
$execute unless items entity @e[type=chest_minecart,tag=ec.cd_buffer,distance=..2,sort=nearest,limit=1] container.$(bslot) * run return 0

summon item ~ ~0.2 ~ {Tags:["ec.co_drop_new"],PickupDelay:10s,Item:{id:"minecraft:stone",count:1}}
$data modify entity @e[type=item,tag=ec.co_drop_new,limit=1] Item set from entity @e[type=chest_minecart,tag=ec.cd_buffer,distance=..2,sort=nearest,limit=1] Items[{Slot:$(bslot)b}]
data remove entity @e[type=item,tag=ec.co_drop_new,limit=1] Item.Slot
tag @e[type=item,tag=ec.co_drop_new] remove ec.co_drop_new
$data remove entity @e[type=chest_minecart,tag=ec.cd_buffer,distance=..2,sort=nearest,limit=1] Items[{Slot:$(bslot)b}]
