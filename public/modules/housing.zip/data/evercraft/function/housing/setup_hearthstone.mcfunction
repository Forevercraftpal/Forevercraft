# ============================================================
# Set up a newly placed Hearthstone
# Run at: the block-aligned position of the lodestone
# Run as: the player who placed it
# ============================================================

# Stop raycast / fallback scan
scoreboard players set @s hs.temp 99
tag @s remove ec.searching

# Spawn marker at block center
summon marker ~0.5 ~ ~0.5 {Tags:["HS.Marker","HS.New","ec.lodestone_registered","smithed.entity"]}

# Store color on marker
data modify entity @e[type=marker,tag=HS.New,limit=1] data.color set from storage evercraft:housing temp_color

# Spawn interaction entity on top (clickable)
summon interaction ~0.5 ~1.0 ~0.5 {Tags:["HS.Interact","smithed.entity"],width:0.9f,height:0.5f,response:1b}

# Spawn visual overlay (player_head texture on item_display, guidestone pattern)
# Set default skin if no color variant was detected
execute if data storage evercraft:housing {temp_color:"hearthstone"} run data modify storage evercraft:housing temp_skin set value "ewogICJ0aW1lc3RhbXAiIDogMTc3MzAxMTIwNDE3MywKICAicHJvZmlsZUlkIiA6ICJhYjNkNTgwMjVkOWM0NTcyODNkNTFlYTcwYTY4N2U1NiIsCiAgInByb2ZpbGVOYW1lIiA6ICJsdWN5X2ludGhlc2t5XyIsCiAgInNpZ25hdHVyZVJlcXVpcmVkIiA6IHRydWUsCiAgInRleHR1cmVzIiA6IHsKICAgICJTS0lOIiA6IHsKICAgICAgInVybCIgOiAiaHR0cDovL3RleHR1cmVzLm1pbmVjcmFmdC5uZXQvdGV4dHVyZS8xOGZhOTk2ODU5MzM4NTExNmNmM2E0NWM2MDQ3OTY3NDU2YjcyYzgxNTA2OGE0ODA1ZGE5ZjE0MTcxZTcwZTlmIiwKICAgICAgIm1ldGFkYXRhIiA6IHsKICAgICAgICAibW9kZWwiIDogInNsaW0iCiAgICAgIH0KICAgIH0KICB9Cn0="
function evercraft:housing/spawn_display with storage evercraft:housing

# ════════════════════════════════════════════════════════════
# MULTI-HOME PLACEMENT DISPATCH (Agent D)
# Three outcomes when a Hearthstone is placed:
#   1. RELOCATE armed (hs.reloc_n 1..5) -> promote to pending + relocate that
#      slot (Manage-Homes [Relocate] path). confirm_relocate handles the rest.
#   2. A FREE unlocked slot exists -> claim the lowest one (next_free) and
#      fall through to the home-data write below.
#   3. All unlocked slots FULL -> display-only prompt: relocate the ACTIVE
#      home onto this spot, or break to keep the current set.
# Legacy "already have a home" hard-return is REPLACED by this dispatch.
# ════════════════════════════════════════════════════════════

# --- 1. RELOCATE ARMED: route to confirm_relocate (it reads hs.reloc_n) ---
execute if score @s hs.reloc_n matches 1..5 run tag @e[type=marker,tag=HS.New,limit=1] add HS.Pending
execute if score @s hs.reloc_n matches 1..5 run tag @e[type=marker,tag=HS.New] remove HS.New
execute if score @s hs.reloc_n matches 1..5 run function evercraft:housing/confirm_relocate
execute if score @s hs.reloc_n matches 1..5 run return 0

# --- Seed hs.slots for a never-migrated player (home-less players skip the
#     tick migrate sweep, so their unlocked-slot count is still unset here).
#     unlock_check is the one-writer of hs.slots and is idempotent. ---
execute unless score @s hs.slots matches 0..5 run function evercraft:housing/slot/unlock_check

# --- Compute the lowest FREE unlocked slot (output: hs.next_slot) ---
function evercraft:housing/slot/next_free

# --- 3. NO FREE SLOT (all unlocked slots full): relocate/abandon prompt ---
execute if score @s hs.next_slot matches 0 run tag @e[type=marker,tag=HS.New,limit=1] add HS.Pending
execute if score @s hs.next_slot matches 0 if score @s ec.fx_snd matches 1.. run playsound minecraft:block.amethyst_block.place master @s ~ ~ ~ 1 0.7
execute if score @s hs.next_slot matches 0 run data modify storage evercraft:notify stage.c set value [{text:"All of your Hearthstone slots are full!",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute if score @s hs.next_slot matches 0 run function evercraft:util/notify/emit
execute if score @s hs.next_slot matches 0 run tellraw @s [{text:"  ",color:"gray"},{text:"[Click to Relocate here]",color:"green",bold:true,click_event:{action:run_command,command:"/function evercraft:housing/confirm_relocate"},hover_event:{action:show_text,value:{text:"Move your ACTIVE home to this spot",color:"gray"}}},{text:" — or open ",color:"gray"},{text:"Manage Homes",color:"aqua"},{text:" to abandon one first.",color:"gray"}]
execute if score @s hs.next_slot matches 0 run tag @e[type=marker,tag=HS.New] remove HS.New
execute if score @s hs.next_slot matches 0 run return 0

# ════════════════════════════════════════════════════════════
# 2. CLAIM THE FREE SLOT (hs.next_slot = target N). Compose the new home in
# the legacy MIRROR, then flush it into slot N via save_one. If this is the
# player's FIRST home, the new slot becomes ACTIVE so the mirror is valid.
# ════════════════════════════════════════════════════════════

# Set mirror home data — Tier 1 (Settler)
scoreboard players set @s hs.tier 1
# Fresh home: no decoration / no protection yet (clear stale mirror carry-over)
scoreboard players set @s hs.decor 0
scoreboard players set @s hs.protect 0
scoreboard players set @s hs.protect_mode 0

# Store home coordinates from the block position
execute store result score @s hs.home_x run data get entity @e[type=marker,tag=HS.New,limit=1] Pos[0]
execute store result score @s hs.home_y run data get entity @e[type=marker,tag=HS.New,limit=1] Pos[1]
execute store result score @s hs.home_z run data get entity @e[type=marker,tag=HS.New,limit=1] Pos[2]

# Store dimension
scoreboard players set @s hs.home_dim 0
execute if dimension minecraft:the_nether run scoreboard players set @s hs.home_dim 1
execute if dimension minecraft:the_end run scoreboard players set @s hs.home_dim 2

# Prepare owner data in temp storage (we ARE the player right now)
data modify storage evercraft:housing temp.owner_uuid set from entity @s UUID
execute store result storage evercraft:housing temp.uuid0 int 1 run data get entity @s UUID[0]
execute store result storage evercraft:housing temp.uuid1 int 1 run data get entity @s UUID[1]
execute store result storage evercraft:housing temp.uuid2 int 1 run data get entity @s UUID[2]
execute store result storage evercraft:housing temp.uuid3 int 1 run data get entity @s UUID[3]
data modify storage evercraft:housing temp.owner_name set value "Unknown"

# Copy owner UUID and tier to the marker entity
execute as @e[type=marker,tag=HS.New,limit=1] run data modify entity @s data.owner_uuid set from storage evercraft:housing temp.owner_uuid
execute as @e[type=marker,tag=HS.New,limit=1] run data modify entity @s data.owner_tier set value 1

# Register in the guidestone network (adds to guidestone registry for teleportation)
# Runs as the marker so it can read its own position
execute as @e[type=marker,tag=HS.New,limit=1] at @s run function evercraft:housing/register_guidestone

# Store the assigned guidestone ID on the player for later removal
execute store result score @s hs.gs_id run scoreboard players get @e[type=marker,tag=HS.New,limit=1] ec.gs_id

# ════════════════════════════════════════════════════════════
# PERSIST THE NEW HOME INTO ITS SLOT (target N = hs.next_slot)
# The mirror now holds the freshly-composed home. Flush it into slot N's
# columns. If this is the player's FIRST home, make slot N the ACTIVE one so
# the mirror invariant holds (mirror == active slot). Otherwise the mirror
# still reflects whatever slot was active before — which is correct, because
# placing a 2nd+ home does NOT switch you onto it (use Manage-Homes [Set
# active] for that). Re-load the mirror from the active slot afterwards so we
# don't leave the freshly-claimed slot's data bleeding into the active mirror.
# ════════════════════════════════════════════════════════════

# Flush the composed mirror into the claimed slot via the macro save_one.
execute store result storage evercraft:housing ld.n int 1 run scoreboard players get @s hs.next_slot
function evercraft:housing/slot/save_one with storage evercraft:housing ld

# UX ADDITION 1 — a freshly-placed home is claimed IN PLACE: the player is
# standing on it and the placement notify already points them at Manage Homes
# to name it. Stamp this slot's deed-given flag so the contextual home-zone
# border prompt (slot/border_prompt) NEVER also fires for it. Only legacy
# MIGRATED homes (flag left 0 by slot/migrate_home) trigger the border prompt.
execute store result storage evercraft:housing ld.n int 1 run scoreboard players get @s hs.next_slot
function evercraft:housing/slot/stamp_dg with storage evercraft:housing ld

# First home? -> this slot becomes active (mirror already matches it).
execute unless score @s hs.active matches 1..5 run scoreboard players operation @s hs.active = @s hs.next_slot

# Re-sync the mirror to the (possibly unchanged) active slot so a 2nd+ home
# placement doesn't leave the active mirror pointing at the new slot's data.
function evercraft:housing/slot/load_active

# Recompute occupied-home count for the GUI / next-free logic.
function evercraft:housing/slot/recount

# Re-assert forceload for EVERY occupied slot (Agent C; per-dim, 9-chunk 3x3,
# idempotent, handles overlap). Replaces the old inline chunk-align math.
function evercraft:housing/slot/forceload_all

# Cleanup
tag @e[type=marker,tag=HS.New] remove HS.New

# Effects
particle minecraft:flame ~0.5 ~1.2 ~0.5 0.3 0.3 0.3 0.02 15
particle minecraft:enchant ~0.5 ~1.5 ~0.5 0.5 0.5 0.5 0.5 25
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.amethyst_block.place master @s ~ ~ ~ 1 0.7
playsound minecraft:block.beacon.activate master @a[distance=..16,scores={ec.fx_snd=1..}] ~ ~ ~ 0.5 1.2

data modify storage evercraft:notify stage.c set value [{text:"Hearthstone placed! Your home is now claimed.",color:"green"}]
scoreboard players set #ndur ec.temp 50
function evercraft:util/notify/emit
# Multi-home: tell the player which slot they just settled (and how many left).
execute if score @s hs.homes matches 2.. run data modify storage evercraft:notify stage.c set value [{text:"This is home ",color:"gray"},{score:{name:"@s",objective:"hs.homes"},color:"yellow"},{text:" of ",color:"gray"},{score:{name:"@s",objective:"hs.slots"},color:"yellow"},{text:" — name it from ",color:"gray"},{text:"Manage Homes",color:"aqua"},{text:".",color:"gray"}]
execute if score @s hs.homes matches 2.. run scoreboard players set #ndur ec.temp 40
execute if score @s hs.homes matches 2.. run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Tier 1: Settler",color:"yellow"},{text:" — Regeneration I while in your 64x64 zone.",color:"gray"}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"3x3 chunks around your Hearthstone are now permanently loaded.",color:"dark_gray"}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Right-click the Hearthstone to upgrade with Netherite Ingots.",color:"dark_gray"}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit

# Give the player a Stash Label for barrel labeling
function evercraft:housing/stash/label/give
data modify storage evercraft:notify stage.c set value [{text:"You received a ",color:"dark_gray"},{text:"Stash Label",color:"gold"},{text:" — sneak+use on barrels to organize your storage!",color:"dark_gray"}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit
