# ============================================================
# Hearthstone GUI — Open
# Run as: player, at player position
# ============================================================

# Toggle — if already open, close instead
execute if entity @s[tag=HS.InMenu] run return run function evercraft:housing/gui/close

# Menu Core: Y-displacement close anchor
# One-menu-at-a-time (2026-06-15): close any other open menu before this one claims
# ec.menu_active. Two overlapping menus share the @s adv.gui_session slot; the newer
# open orphans the older menu's session, so it can never consume its click -> stuck
# interaction NBT -> click-sound spam. force_close is idempotent (no-op when nothing open).
execute if entity @s[tag=ec.menu_active] run function evercraft:menu_core/force_close
tag @s add ec.menu_active
execute store result score @s ec.menu_open_y run data get entity @s Pos[1] 100

# Safety: kill orphaned menu elements
execute at @s run kill @e[type=text_display,tag=HS.MenuEl,distance=..5]
execute at @s run kill @e[type=interaction,tag=HS.MenuEl,distance=..5]
execute at @s run kill @e[type=item_display,tag=HS.MenuEl,distance=..5]
# Safety: also reap orphaned Ideas-&-Blueprints-catalogue elements (distinct DEC prefix)
execute at @s run kill @e[type=text_display,tag=DEC.MenuEl,distance=..5]
execute at @s run kill @e[type=interaction,tag=DEC.MenuEl,distance=..5]
execute at @s run kill @e[type=item_display,tag=DEC.BG,distance=..5]
execute at @s run kill @e[type=#evercraft:decor_displays,tag=DEC.PrevMini,distance=..10]
execute at @s run kill @e[type=marker,tag=DEC.RenderAnchor,distance=..8]

# Auto-repair: if player's hs.tier is 0 but a marker exists, recover tier from marker data
execute if score @s hs.tier matches ..0 at @s store result score @s hs.tier run data get entity @e[type=marker,tag=HS.Marker,distance=..5,limit=1] data.owner_tier
# Guard: if tier is still 0 (player doesn't own a hearthstone), don't open the menu
data modify storage evercraft:notify stage.c set value [{text:"You don't own this Hearthstone.",color:"gray"}]
scoreboard players set #ndur ec.temp 45
execute if score @s hs.tier matches ..0 run function evercraft:util/notify/emit
execute if score @s hs.tier matches ..0 if score @s ec.fx_snd matches 1.. run playsound minecraft:block.anvil.land player @s ~ ~ ~ 0.3 1.5
execute if score @s hs.tier matches ..0 run return 0

# Disable the hearthstone interaction entity so it can't be re-triggered
execute at @s run data modify entity @e[type=interaction,tag=HS.Interact,distance=..5,limit=1] height set value 0.0f

# Tag player
tag @s add HS.InMenu
scoreboard players set @s hs.menu_time 0

# === BACKGROUND PANEL ===
# (2026-06-19: widened to landscape so the action buttons can sit in 2 columns instead of
#  one cramped vertical stack — info lines stay centred up top)
execute rotated ~ 0 positioned ^ ^1.95 ^1.8 run summon item_display ~ ~ ~ { Tags:["HS.MenuEl","HS.BG"], billboard:"center", item:{id:"black_stained_glass_pane",count:1}, item_display:"fixed", transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,-0.02f],scale:[3.6f,2.9f,0.01f]} }

# === TITLE ===
# Ownership-header label (MP-P3.6): foreign viewers see whose menu this is
# 26.1: {selector:} renders blank in text_display — bake @s's name to a $(owner) literal.
function evercraft:util/gui/owner_name
execute rotated ~ 0 positioned ^ ^3.23 ^1.78 run function evercraft:housing/gui/open_nm with storage evercraft:scorebake args
execute rotated ~ 0 positioned ^ ^3.05 ^1.78 run summon text_display ~ ~ ~ { brightness:{block:15,sky:15},shadow_radius:0f, Tags:["HS.MenuEl","HS.Title"], billboard:"center", text:[{text:"\u2726 ",color:"gold"},{text:"Hearthstone",color:"yellow",bold:true},{text:" \u2726",color:"gold"}], background:1,shadow:1b, transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.608f,0.608f,0.608f]} }

# === TIER LINE (refreshable) ===
execute rotated ~ 0 positioned ^ ^2.82 ^1.78 run summon text_display ~ ~ ~ { brightness:{block:15,sky:15},shadow_radius:0f, Tags:["HS.MenuEl","HS.Tier"], billboard:"center", text:{text:"Loading...",color:"gray"}, background:0,shadow:1b, transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.473f,0.473f,0.473f]} }

# === BUFFS LINE (refreshable — shows current zone buffs) ===
execute rotated ~ 0 positioned ^ ^2.61 ^1.78 run summon text_display ~ ~ ~ { brightness:{block:15,sky:15},shadow_radius:0f, Tags:["HS.MenuEl","HS.Buffs"], billboard:"center", text:{text:"",color:"gray"}, background:0,shadow:1b, transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.405f,0.405f,0.405f]} }

# === DECORATION SCORE (refreshable) ===
execute rotated ~ 0 positioned ^ ^2.40 ^1.78 run summon text_display ~ ~ ~ { brightness:{block:15,sky:15},shadow_radius:0f, Tags:["HS.MenuEl","HS.Decor"], billboard:"center", text:{text:"",color:"gray"}, background:0,shadow:1b, transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.405f,0.405f,0.405f]} }

# === TIER HELP [?] (left of comfort line — leaderboard) ===
execute rotated ~ 0 positioned ^0.7 ^2.40 ^1.78 run summon text_display ~ ~ ~ { brightness:{block:15,sky:15},shadow_radius:0f, Tags:["HS.MenuEl","HS.TierHelp"], billboard:"center", text:{text:"[?]",color:"yellow"}, background:0,shadow:1b, transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.338f,0.338f,0.338f]} }
execute rotated ~ 0 positioned ^0.7 ^2.32 ^1.8 run summon interaction ~ ~ ~ { Tags:["HS.MenuEl","HS.TierHelpBtn"], width:0.2f,height:0.1f,response:1b }

# === COMFORT HELP [?] (right of comfort line — how to increase) ===
execute rotated ~ 0 positioned ^-0.7 ^2.40 ^1.78 run summon text_display ~ ~ ~ { brightness:{block:15,sky:15},shadow_radius:0f, Tags:["HS.MenuEl","HS.ComfortHelp"], billboard:"center", text:{text:"[?]",color:"yellow"}, background:0,shadow:1b, transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.338f,0.338f,0.338f]} }
execute rotated ~ 0 positioned ^-0.7 ^2.32 ^1.8 run summon interaction ~ ~ ~ { Tags:["HS.MenuEl","HS.ComfortHelpBtn"], width:0.2f,height:0.1f,response:1b }

# === VISITORS LINE (refreshable) ===
execute rotated ~ 0 positioned ^ ^2.20 ^1.78 run summon text_display ~ ~ ~ { brightness:{block:15,sky:15},shadow_radius:0f, Tags:["HS.MenuEl","HS.Visitors"], billboard:"center", text:{text:"",color:"gray"}, background:0,shadow:1b, transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.338f,0.338f,0.338f]} }

# === NEXT TIER INFO (refreshable — shows what upgrade gives) ===
execute rotated ~ 0 positioned ^ ^1.99 ^1.78 run summon text_display ~ ~ ~ { brightness:{block:15,sky:15},shadow_radius:0f, Tags:["HS.MenuEl","HS.Next"], billboard:"center", text:{text:"",color:"gray"}, background:0,shadow:1b, transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.405f,0.405f,0.405f]} }

# === COST LINE (refreshable — shows netherite ingot cost) ===
execute rotated ~ 0 positioned ^ ^1.78 ^1.78 run summon text_display ~ ~ ~ { brightness:{block:15,sky:15},shadow_radius:0f, Tags:["HS.MenuEl","HS.Cost"], billboard:"center", text:{text:"",color:"gray"}, background:0,shadow:1b, transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.405f,0.405f,0.405f]} }

# === ROW 1: UPGRADE (left) | QUICK STASH (right) ===
execute rotated ~ 0 positioned ^0.7 ^1.62 ^1.78 run summon text_display ~ ~ ~ { brightness:{block:15,sky:15},shadow_radius:0f, Tags:["HS.MenuEl","HS.UpgradeTxt"], billboard:"center", text:[{text:"[ ",color:"dark_gray"},{text:"Upgrade",color:"dark_gray"},{text:" ]",color:"dark_gray"}], background:1,shadow:1b, transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.4f,0.4f,0.4f]} }
# [strip] 0.6w split into 3 x 0.2 cubes, centered on the left column (^0.7)
execute rotated ~ 0 positioned ^0.5 ^1.52 ^1.8 run summon interaction ~ ~ ~ { Tags:["HS.MenuEl","HS.UpgradeBtn"], width:0.2f,height:0.12f,response:1b }
execute rotated ~ 0 positioned ^0.7 ^1.52 ^1.8 run summon interaction ~ ~ ~ { Tags:["HS.MenuEl","HS.UpgradeBtn"], width:0.2f,height:0.12f,response:1b }
execute rotated ~ 0 positioned ^0.9 ^1.52 ^1.8 run summon interaction ~ ~ ~ { Tags:["HS.MenuEl","HS.UpgradeBtn"], width:0.2f,height:0.12f,response:1b }

execute rotated ~ 0 positioned ^-0.7 ^1.62 ^1.78 run summon text_display ~ ~ ~ { brightness:{block:15,sky:15},shadow_radius:0f, Tags:["HS.MenuEl","HS.StashTxt"], billboard:"center", text:[{text:"[ ",color:"dark_gray"},{text:"Quick Stash",color:"green"},{text:" ]",color:"dark_gray"}], background:1,shadow:1b, transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.4f,0.4f,0.4f]} }
# [strip] 0.6w split into 3 x 0.2 cubes, centered on the right column (^-0.7)
execute rotated ~ 0 positioned ^-0.9 ^1.52 ^1.8 run summon interaction ~ ~ ~ { Tags:["HS.MenuEl","HS.StashBtn"], width:0.2f,height:0.12f,response:1b }
execute rotated ~ 0 positioned ^-0.7 ^1.52 ^1.8 run summon interaction ~ ~ ~ { Tags:["HS.MenuEl","HS.StashBtn"], width:0.2f,height:0.12f,response:1b }
execute rotated ~ 0 positioned ^-0.5 ^1.52 ^1.8 run summon interaction ~ ~ ~ { Tags:["HS.MenuEl","HS.StashBtn"], width:0.2f,height:0.12f,response:1b }

# === ROW 2: STASH SETTINGS (left) | LABORERS (right) ===
execute rotated ~ 0 positioned ^0.7 ^1.32 ^1.78 run summon text_display ~ ~ ~ { brightness:{block:15,sky:15},shadow_radius:0f, Tags:["HS.MenuEl","HS.SettingsTxt"], billboard:"center", text:[{text:"[ ",color:"dark_gray"},{text:"Stash Settings",color:"gray"},{text:" ]",color:"dark_gray"}], background:1,shadow:1b, transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.4f,0.4f,0.4f]} }
# [strip] 0.6w split into 3 x 0.2 cubes, centered on the left column (^0.7)
execute rotated ~ 0 positioned ^0.5 ^1.22 ^1.8 run summon interaction ~ ~ ~ { Tags:["HS.MenuEl","HS.SettingsBtn"], width:0.2f,height:0.12f,response:1b }
execute rotated ~ 0 positioned ^0.7 ^1.22 ^1.8 run summon interaction ~ ~ ~ { Tags:["HS.MenuEl","HS.SettingsBtn"], width:0.2f,height:0.12f,response:1b }
execute rotated ~ 0 positioned ^0.9 ^1.22 ^1.8 run summon interaction ~ ~ ~ { Tags:["HS.MenuEl","HS.SettingsBtn"], width:0.2f,height:0.12f,response:1b }

execute rotated ~ 0 positioned ^-0.7 ^1.32 ^1.78 run summon text_display ~ ~ ~ { brightness:{block:15,sky:15},shadow_radius:0f, Tags:["HS.MenuEl","HS.LaborersTxt"], billboard:"center", text:[{text:"[ ",color:"dark_gray"},{text:"Laborers",color:"#AB47BC"},{text:" ]",color:"dark_gray"}], background:1,shadow:1b, transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.4f,0.4f,0.4f]} }
# [strip] 0.6w split into 3 x 0.2 cubes, centered on the right column (^-0.7)
execute rotated ~ 0 positioned ^-0.9 ^1.22 ^1.8 run summon interaction ~ ~ ~ { Tags:["HS.MenuEl","HS.LaborersBtn"], width:0.2f,height:0.12f,response:1b }
execute rotated ~ 0 positioned ^-0.7 ^1.22 ^1.8 run summon interaction ~ ~ ~ { Tags:["HS.MenuEl","HS.LaborersBtn"], width:0.2f,height:0.12f,response:1b }
execute rotated ~ 0 positioned ^-0.5 ^1.22 ^1.8 run summon interaction ~ ~ ~ { Tags:["HS.MenuEl","HS.LaborersBtn"], width:0.2f,height:0.12f,response:1b }

# === ROW 3: MANAGE HOMES (left) | IDEAS & BLUEPRINTS (right) ===
execute rotated ~ 0 positioned ^0.7 ^1.02 ^1.78 run summon text_display ~ ~ ~ { brightness:{block:15,sky:15},shadow_radius:0f, Tags:["HS.MenuEl","HS.ManageHomesTxt"], billboard:"center", text:[{text:"[ ",color:"dark_gray"},{text:"⌂ Manage Homes",color:"#FFD54F"},{text:" ]",color:"dark_gray"}], background:1,shadow:1b, transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.4f,0.4f,0.4f]} }
# [strip] 0.6w split into 3 x 0.2 cubes, centered on the left column (^0.7)
execute rotated ~ 0 positioned ^0.5 ^0.92 ^1.8 run summon interaction ~ ~ ~ { Tags:["HS.MenuEl","HS.ManageHomesBtn"], width:0.2f,height:0.12f,response:1b }
execute rotated ~ 0 positioned ^0.7 ^0.92 ^1.8 run summon interaction ~ ~ ~ { Tags:["HS.MenuEl","HS.ManageHomesBtn"], width:0.2f,height:0.12f,response:1b }
execute rotated ~ 0 positioned ^0.9 ^0.92 ^1.8 run summon interaction ~ ~ ~ { Tags:["HS.MenuEl","HS.ManageHomesBtn"], width:0.2f,height:0.12f,response:1b }

execute rotated ~ 0 positioned ^-0.7 ^1.02 ^1.78 run summon text_display ~ ~ ~ { brightness:{block:15,sky:15},shadow_radius:0f, Tags:["HS.MenuEl","HS.FurnishTxt"], billboard:"center", text:[{text:"[ ",color:"dark_gray"},{text:"✎ Ideas & Blueprints",color:"#80DEEA"},{text:" ]",color:"dark_gray"}], background:1,shadow:1b, transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.4f,0.4f,0.4f]} }
# [strip] 0.6w split into 3 x 0.2 cubes, centered on the right column (^-0.7)
execute rotated ~ 0 positioned ^-0.9 ^0.92 ^1.8 run summon interaction ~ ~ ~ { Tags:["HS.MenuEl","HS.FurnishBtn"], width:0.2f,height:0.12f,response:1b }
execute rotated ~ 0 positioned ^-0.7 ^0.92 ^1.8 run summon interaction ~ ~ ~ { Tags:["HS.MenuEl","HS.FurnishBtn"], width:0.2f,height:0.12f,response:1b }
execute rotated ~ 0 positioned ^-0.5 ^0.92 ^1.8 run summon interaction ~ ~ ~ { Tags:["HS.MenuEl","HS.FurnishBtn"], width:0.2f,height:0.12f,response:1b }

# === BEST-FRIEND COMFORT SHARING TOGGLE (centered, between the button rows and Close) ===
execute rotated ~ 0 positioned ^ ^0.84 ^1.78 run summon text_display ~ ~ ~ { brightness:{block:15,sky:15},shadow_radius:0f, Tags:["HS.MenuEl","HS.GuestShareTxt"], billboard:"center", text:{text:"Loading...",color:"gray"}, background:1,shadow:1b, transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.4f,0.4f,0.4f]} }
# [strip] 0.6w split into 3 x 0.2 cubes, centered (^0)
execute rotated ~ 0 positioned ^-0.2 ^0.74 ^1.8 run summon interaction ~ ~ ~ { Tags:["HS.MenuEl","HS.GuestShareBtn"], width:0.2f,height:0.12f,response:1b }
execute rotated ~ 0 positioned ^0 ^0.74 ^1.8 run summon interaction ~ ~ ~ { Tags:["HS.MenuEl","HS.GuestShareBtn"], width:0.2f,height:0.12f,response:1b }
execute rotated ~ 0 positioned ^0.2 ^0.74 ^1.8 run summon interaction ~ ~ ~ { Tags:["HS.MenuEl","HS.GuestShareBtn"], width:0.2f,height:0.12f,response:1b }

# === CLOSE BUTTON ===
execute rotated ~ 0 positioned ^ ^0.65 ^1.78 run summon text_display ~ ~ ~ { brightness:{block:15,sky:15},shadow_radius:0f, Tags:["HS.MenuEl","HS.CloseTxt"], billboard:"center", text:[{text:"[ ",color:"dark_gray"},{text:"Close",color:"gray",bold:true},{text:" ]",color:"dark_gray"}], background:1,shadow:1b, transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.405f,0.405f,0.405f]} }
# [strip] ?: 0.4w split into 4 x 0.12 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute rotated ~ 0 positioned ^-0.14 ^0.55 ^1.8 run summon interaction ~ ~ ~ { Tags:["HS.MenuEl","HS.CloseBtn"], width:0.12f,height:0.12f,response:1b }
execute rotated ~ 0 positioned ^-0.0467 ^0.55 ^1.8 run summon interaction ~ ~ ~ { Tags:["HS.MenuEl","HS.CloseBtn"], width:0.12f,height:0.12f,response:1b }
execute rotated ~ 0 positioned ^0.0467 ^0.55 ^1.8 run summon interaction ~ ~ ~ { Tags:["HS.MenuEl","HS.CloseBtn"], width:0.12f,height:0.12f,response:1b }
execute rotated ~ 0 positioned ^0.14 ^0.55 ^1.8 run summon interaction ~ ~ ~ { Tags:["HS.MenuEl","HS.CloseBtn"], width:0.12f,height:0.12f,response:1b }

# Initial refresh to set tier/buffs/cost text
execute at @s run function evercraft:housing/gui/refresh

# Sound

# Session isolation
scoreboard players add #gui_session ec.var 1
scoreboard players operation @s adv.gui_session = #gui_session ec.var
scoreboard players operation #gui_stamp ec.temp = @s adv.gui_session
execute as @e[type=text_display,tag=HS.MenuEl,distance=..5] unless score @s adv.gui_session matches 1.. run scoreboard players operation @s adv.gui_session = #gui_stamp ec.temp
execute as @e[type=item_display,tag=HS.MenuEl,distance=..5] unless score @s adv.gui_session matches 1.. run scoreboard players operation @s adv.gui_session = #gui_stamp ec.temp
execute as @e[type=interaction,tag=HS.MenuEl,distance=..5] unless score @s adv.gui_session matches 1.. run scoreboard players operation @s adv.gui_session = #gui_stamp ec.temp

execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.4 1.2
