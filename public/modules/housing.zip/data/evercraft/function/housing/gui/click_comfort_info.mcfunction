# ============================================================
# Hearthstone GUI — Comfort [?] clicked
# Run as: the interaction entity
# ============================================================
data remove entity @s interaction

execute as @p[distance=..6,tag=HS.InMenu] run function evercraft:housing/gui/show_comfort_info

playsound minecraft:block.note_block.hat master @p[distance=..6,scores={ec.fx_snd=1..}] ~ ~ ~ 0.3 1.6
