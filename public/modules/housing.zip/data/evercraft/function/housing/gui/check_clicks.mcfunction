# ============================================================
# Hearthstone GUI — Check Clicks
# Run as: player with HS.InMenu
# ============================================================

# Close button
scoreboard players operation #gui_check ec.temp = @s adv.gui_session
execute as @e[type=interaction,tag=HS.CloseBtn,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction on target run function evercraft:housing/gui/click_close
execute as @e[type=interaction,tag=HS.CloseBtn,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction run data remove entity @s interaction

# Upgrade button
execute as @e[type=interaction,tag=HS.UpgradeBtn,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction on target run function evercraft:housing/gui/click_upgrade
execute as @e[type=interaction,tag=HS.UpgradeBtn,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction run data remove entity @s interaction

# Quick Stash button
execute as @e[type=interaction,tag=HS.StashBtn,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction on target run function evercraft:housing/stash/gui/click_stash
execute as @e[type=interaction,tag=HS.StashBtn,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction run data remove entity @s interaction

# Stash Settings button
execute as @e[type=interaction,tag=HS.SettingsBtn,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction on target run function evercraft:housing/stash/gui/click_settings
execute as @e[type=interaction,tag=HS.SettingsBtn,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction run data remove entity @s interaction

# Tier help [?] button
execute as @e[type=interaction,tag=HS.TierHelpBtn,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction on target run function evercraft:housing/gui/click_tier_info
execute as @e[type=interaction,tag=HS.TierHelpBtn,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction run data remove entity @s interaction

# Comfort help [?] button
execute as @e[type=interaction,tag=HS.ComfortHelpBtn,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction on target run function evercraft:housing/gui/click_comfort_info
execute as @e[type=interaction,tag=HS.ComfortHelpBtn,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction run data remove entity @s interaction

# Laborers button
execute as @e[type=interaction,tag=HS.LaborersBtn,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction on target run function evercraft:housing/gui/click_laborers
execute as @e[type=interaction,tag=HS.LaborersBtn,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction run data remove entity @s interaction

# Manage Homes button (multi-home panel)
execute as @e[type=interaction,tag=HS.ManageHomesBtn,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction on target run function evercraft:housing/gui/click_managehomes
execute as @e[type=interaction,tag=HS.ManageHomesBtn,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction run data remove entity @s interaction

# Furnishings catalogue button (decor crafting panel)
execute as @e[type=interaction,tag=HS.FurnishBtn,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction on target run function evercraft:housing/gui/click_furnishings
execute as @e[type=interaction,tag=HS.FurnishBtn,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction run data remove entity @s interaction

# Best-Friend comfort sharing toggle
execute as @e[type=interaction,tag=HS.GuestShareBtn,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction on target run function evercraft:housing/gui/click_guest_share
execute as @e[type=interaction,tag=HS.GuestShareBtn,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction run data remove entity @s interaction

# ===== INSPECT (left-click = what does this button do?) — gui/inspect pattern 2026-06-11 =====
execute as @e[type=interaction,tag=HS.CloseBtn,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Close",b:"Closes the hearthstone menu."}
execute as @e[type=interaction,tag=HS.CloseBtn,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=HS.UpgradeBtn,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Upgrade Home",b:"Upgrades your home to the next tier — costs materials shown on the page."}
execute as @e[type=interaction,tag=HS.UpgradeBtn,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=HS.FurnishBtn,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Furnishings",b:"Opens the furnishings catalogue — decor to craft and place."}
execute as @e[type=interaction,tag=HS.FurnishBtn,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=HS.LaborersBtn,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Laborers",b:"Opens your laborers — who works your plot and at what."}
execute as @e[type=interaction,tag=HS.LaborersBtn,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=HS.ManageHomesBtn,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Manage Homes",b:"Opens your homes list — travel to or release your claims."}
execute as @e[type=interaction,tag=HS.ManageHomesBtn,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=HS.StashBtn,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Home Stash",b:"Opens the home stash — shared storage that lives with your plot."}
execute as @e[type=interaction,tag=HS.StashBtn,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=HS.SettingsBtn,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Stash Settings",b:"Opens the stash settings."}
execute as @e[type=interaction,tag=HS.SettingsBtn,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=HS.ComfortHelpBtn,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Comfort",b:"Prints how Comfort works in chat."}
execute as @e[type=interaction,tag=HS.ComfortHelpBtn,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=HS.TierHelpBtn,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Home Tiers",b:"Prints how home tiers work in chat."}
execute as @e[type=interaction,tag=HS.TierHelpBtn,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=HS.GuestShareBtn,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Best-Friend Comforts",b:"When ON, your Best Friends (90+ hearts) get your home's comfort buffs while inside your plot. Click to toggle — revoke any time."}
execute as @e[type=interaction,tag=HS.GuestShareBtn,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack run data remove entity @s attack

# Catch-all (2026-06-14): clear any leftover HS-menu interaction so the unified UI-click sfx
# (housing/gui/tick) can't loop forever on an element whose tag has no handler above.
execute as @e[type=interaction,tag=HS.MenuEl,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction run data remove entity @s interaction
