# Hearthstone GUI — Best-Friend comfort sharing toggle clicked
# Run as: the interaction entity
data remove entity @s interaction
execute as @p[distance=..6,tag=HS.InMenu] at @s run function evercraft:housing/gui/do_toggle_guest_share
