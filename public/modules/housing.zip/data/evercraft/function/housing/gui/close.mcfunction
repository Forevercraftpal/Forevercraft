# ============================================================
# Hearthstone GUI — Close
# Run as: player
# ============================================================

execute unless entity @s[tag=HS.InMenu] run return 0

# Menu Core: Y-displacement close anchor
tag @s remove ec.menu_active
scoreboard players reset @s ec.menu_open_y

# Kill all menu elements near the player
scoreboard players operation #gui_check ec.temp = @s adv.gui_session
execute as @e[type=item_display,tag=HS.MenuEl,distance=..7] if score @s adv.gui_session = #gui_check ec.temp run kill @s
execute as @e[type=text_display,tag=HS.MenuEl,distance=..7] if score @s adv.gui_session = #gui_check ec.temp run kill @s
execute as @e[type=interaction,tag=HS.MenuEl,distance=..7] if score @s adv.gui_session = #gui_check ec.temp run kill @s

# Kill Furnishings-catalogue sub-menu elements (distinct DEC.MenuEl/DEC.BG prefix —
# NOT caught by the HS.MenuEl sweep above; cleaned here so a parent auto-close
# (distance/inactivity) doesn't orphan the catalogue panel).
execute as @e[type=item_display,tag=DEC.BG,distance=..7] if score @s adv.gui_session = #gui_check ec.temp run kill @s
execute as @e[type=text_display,tag=DEC.MenuEl,distance=..7] if score @s adv.gui_session = #gui_check ec.temp run kill @s
execute as @e[type=interaction,tag=DEC.MenuEl,distance=..7] if score @s adv.gui_session = #gui_check ec.temp run kill @s
# The View hologram carries no gui_session score — reap by tag (transient, one per viewer).
execute at @s run kill @e[type=#evercraft:decor_displays,tag=DEC.PrevMini,distance=..10]
# The catalogue's frozen render anchor (marker — not caught by display-type sweeps).
execute at @s run kill @e[type=marker,tag=DEC.RenderAnchor,distance=..8]

# Re-enable the hearthstone interaction entity
execute at @s run data modify entity @e[type=interaction,tag=HS.Interact,distance=..7,limit=1] height set value 0.5f

# Remove tags
tag @s remove HS.InMenu
tag @s remove HS.InSettings
tag @s remove HS.InLaborers
tag @s remove HS.InHomes
tag @s remove HS.InFurnish

# Sound
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.3 0.8
