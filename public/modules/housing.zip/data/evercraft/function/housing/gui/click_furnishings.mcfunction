# ============================================================
# Hearthstone GUI — Furnishings catalogue button clicked
# Run as: the interaction entity, at its position
# Mirrors gui/click_managehomes.
# ============================================================

# Clear interaction data
data remove entity @s interaction

# Open the Furnishings catalogue sub-menu for the nearest player with menu open
execute as @p[tag=HS.InMenu,distance=..5] at @s run function evercraft:decor/gui/open
