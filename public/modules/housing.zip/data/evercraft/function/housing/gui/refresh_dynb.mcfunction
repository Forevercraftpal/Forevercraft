# AUTO (refresh.mcfunction): data-modify text_display rows with {score} baked as macro args (26.1 fix, cat B).
# Invoked `with storage evercraft:scorebake bargs` from the parent.
$execute if score @s hs.decor matches 1..99 run data modify entity @e[type=text_display,tag=HS.Decor,distance=..7,limit=1] text set value [{text:"Comfort: ",color:"dark_gray"},{text:"$(v1)",color:"white"},{text:" — Keep decorating!",color:"dark_gray",italic:true}]
$data modify entity @e[type=text_display,tag=HS.Visitors,distance=..7,limit=1] text set value [{text:"Visitors: ",color:"dark_gray"},{text:"$(v2)",color:"white"},{text:" total",color:"dark_gray"},{text:" (",color:"dark_gray"},{text:"$(v3)",color:"yellow"},{text:" today)",color:"dark_gray"}]
