# ============================================================
# Hearthstone GUI — Manage Homes button clicked
# Run as: the interaction entity, at its position
# Mirrors gui/click_laborers.
# ============================================================

# Clear interaction data
data remove entity @s interaction

# Open the manage-homes sub-menu for the nearest player with menu open
execute as @p[tag=HS.InMenu,distance=..5] at @s run function evercraft:housing/homes/open
