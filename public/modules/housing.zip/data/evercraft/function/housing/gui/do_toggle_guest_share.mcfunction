# Hearthstone GUI — flip Best-Friend comfort sharing
# Run as: the owner (HS.InMenu), at the owner (near the menu elements).
# hs.guest_share: 1 = REVOKED (off), 0/absent = ON (default).

# Atomic flip: default to REVOKE (1); if already revoked, switch back ON (0).
scoreboard players set #hs_gs_new hs.temp 1
execute if score @s hs.guest_share matches 1 run scoreboard players set #hs_gs_new hs.temp 0
scoreboard players operation @s hs.guest_share = #hs_gs_new hs.temp

# Repaint the toggle label.
function evercraft:housing/gui/refresh

# Feedback.
execute if score @s hs.guest_share matches 1 run data modify storage evercraft:notify stage.c set value [{text:"Best friends will no longer share your home's comforts.",color:"gray"}]
execute unless score @s hs.guest_share matches 1 run data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"Best friends now share your home's comforts.",color:"green"}]
scoreboard players set #ndur ec.temp 50
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.4 1.3
