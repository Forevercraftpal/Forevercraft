# Housing Decoration — Show Score in GUI (Macro)
# Called `with storage evercraft:housing temp` = {decor_score:int, rank:"Name", rank_color:"color"}
# 26.1: {score:} renders blank in text_display, so the comfort number is baked as $(decor_score).

$data modify entity @e[type=text_display,tag=HS.Decor,distance=..7,limit=1] text set value [{text:"Comfort: ",color:"dark_gray"},{text:"$(decor_score)",color:"white"},{text:" — ",color:"dark_gray"},{text:"$(rank)",color:"$(rank_color)",bold:true}]
