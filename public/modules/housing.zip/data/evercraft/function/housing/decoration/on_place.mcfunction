# Housing Decoration — Block Placed
# Fires when a player places any decorative block (advancement reward)
# Only counts if player is in their home zone

# Revoke for reuse
advancement revoke @s only evercraft:housing/place_decoration

# Only count if player is in their home zone
execute unless score @s hs.in_zone matches 1 run return 0

# Credit the decoration (hs.decor++, milestones, Building XP). Extracted to a shared one-writer
# function (SPEC §6) so custom furnishings (decor/use/confirm) credit through the SAME path.
function evercraft:housing/decoration/credit
