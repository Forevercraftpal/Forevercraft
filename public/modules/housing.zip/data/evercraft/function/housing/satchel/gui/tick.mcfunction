# ============================================================
# House Key GUI — Tick
# Called every tick for players with HS.InSatchel tag
# Run as: player, at player position
# ============================================================

execute unless entity @s[tag=HS.InSatchel] run return 0

# Auto-close after 20 seconds of inactivity (400 ticks)
scoreboard players add @s hs.menu_time 1
execute if score @s hs.menu_time matches 400.. run return run function evercraft:housing/satchel/gui/close

# Close if player switched away from House Key (grace period for consume restore)
execute if score @s hs.menu_time matches 5.. unless items entity @s weapon.mainhand minecraft:ominous_trial_key run return run function evercraft:housing/satchel/gui/close

# Reset inactivity timer if any menu button was clicked this tick
scoreboard players operation #gui_check ec.temp = @s adv.gui_session
execute as @e[type=interaction,tag=HS.MenuEl,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction run scoreboard players set @a[predicate=evercraft:housing/satchel/gui/check_menu_session,limit=1] hs.menu_time 0

# Unified UI-click FX (Joseph 2026-06-05): play the gated cue ONCE if any HS.MenuEl registered a click.
execute if entity @e[type=interaction,tag=HS.MenuEl,distance=..6,nbt={interaction:{}},limit=1] run function evercraft:fx/ui/click

# Check for clicks (settings sub-menu has its own click handler)
# Wiring Audit #27 RC-2: set #gui_check from this player BEFORE dispatching keep/check_clicks
# (housing/gui/tick does this for the Hearthstone parent; the satchel parent must too, or the
# session gate added to keep/check_clicks would read a stale #gui_check and kill the toggles).
scoreboard players operation #gui_check ec.temp = @s adv.gui_session
execute if entity @s[tag=HS.InSettings] run return run function evercraft:housing/stash/keep/check_clicks
function evercraft:housing/satchel/gui/check_clicks
