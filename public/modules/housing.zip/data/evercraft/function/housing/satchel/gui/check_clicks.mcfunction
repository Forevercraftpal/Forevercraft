# ============================================================
# House Key GUI — Check Clicks
# Run as: player with HS.InSatchel
# ============================================================

scoreboard players operation #gui_owner ec.temp = @s adv.gui_session

# Close button
execute as @e[type=interaction,tag=HS.SatchelCloseBtn,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction on target run function evercraft:housing/satchel/gui/click_close
execute as @e[type=interaction,tag=HS.SatchelCloseBtn,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction

# Quick Stash button
execute as @e[type=interaction,tag=HS.SatchelStashBtn,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction on target run function evercraft:housing/satchel/gui/click_stash
execute as @e[type=interaction,tag=HS.SatchelStashBtn,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction

# Stash Settings button
execute as @e[type=interaction,tag=HS.SatchelSettingsBtn,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction on target run function evercraft:housing/satchel/gui/click_settings
execute as @e[type=interaction,tag=HS.SatchelSettingsBtn,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction

# ===== INSPECT (left-click = what does this button do?) — gui/inspect pattern 2026-06-11 =====
execute as @e[type=interaction,tag=HS.SatchelCloseBtn,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Close",b:"Closes the satchel menu."}
execute as @e[type=interaction,tag=HS.SatchelCloseBtn,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=HS.SatchelSettingsBtn,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Settings",b:"Opens the stash settings."}
execute as @e[type=interaction,tag=HS.SatchelSettingsBtn,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=HS.SatchelStashBtn,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Quick-Stash",b:"Sweeps matching goods from your bags into the home stash."}
execute as @e[type=interaction,tag=HS.SatchelStashBtn,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack run data remove entity @s attack
