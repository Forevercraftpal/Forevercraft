# ============================================================
# House Key GUI — Close
# Run as: player
# ============================================================

execute unless entity @s[tag=HS.InSatchel] run return 0

# Menu Core: Y-displacement close anchor
tag @s remove ec.menu_active
scoreboard players reset @s ec.menu_open_y

# Kill all satchel menu elements near the player
scoreboard players operation #gui_check ec.temp = @s adv.gui_session
execute as @e[type=item_display,tag=HS.SatchelEl,distance=..7] if score @s adv.gui_session = #gui_check ec.temp run kill @s
execute as @e[type=text_display,tag=HS.SatchelEl,distance=..7] if score @s adv.gui_session = #gui_check ec.temp run kill @s
execute as @e[type=interaction,tag=HS.SatchelEl,distance=..7] if score @s adv.gui_session = #gui_check ec.temp run kill @s

# Remove tags
tag @s remove HS.InSatchel
tag @s remove HS.InSettings

# Sound
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.3 0.8
