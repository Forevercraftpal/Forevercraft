# ============================================================
# Crate → Container Dump — Entry point
# Triggered by: advancement evercraft:crates/dump_into_container
#   (default_block_use: opened a chest/barrel while holding a crate)
# Run as: the player who opened the container
# ------------------------------------------------------------
# Reads the held crate's container_loot table, rolls it straight
# into the opened container block, plays the reveal FX (particles
# + sound only — NO animation barrel), then consumes one crate.
# Overflow that does not fit drops at the container (never voided).
# ============================================================

# Re-arm the trigger so the next crate-on-chest works
advancement revoke @s only evercraft:crates/dump_into_container

# Capture the crate item from the player's hand into storage so we can
# read its loot table even after the hand is cleared.
data modify storage evercraft:crate_dump held set from entity @s SelectedItem

# Bail if the hand item lost its container_loot between trigger and reward
# (e.g. the player swapped items in the same tick).
execute unless data storage evercraft:crate_dump held.components."minecraft:container_loot" run return fail

# Stage the loot table reference as a macro arg for the deposit step.
data modify storage evercraft:crate_dump args.loot_table set from storage evercraft:crate_dump held.components."minecraft:container_loot".loot_table

# Reset per-run state and raycast from the eyes to the opened container.
tag @s remove ec.cd_found
scoreboard players set #cd_steps ec.temp 0
execute anchored eyes positioned ^ ^ ^ run function evercraft:crates/dump_into_container/raycast

# Cleanup (the deposit, if any, ran inside the aligned raycast hit).
tag @s remove ec.cd_found
data remove storage evercraft:crate_dump held
data remove storage evercraft:crate_dump args
