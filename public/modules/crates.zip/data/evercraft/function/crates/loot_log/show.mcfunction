# ============================================================
# Crate Loot Log — Reveal "what you got" to the player
# Run as: player (the opener)
# ------------------------------------------------------------
# Emits ONE subtle tellraw line. Hovering it reveals the captured
# loot list (built by begin -> scan_buffer -> here) via a
# hover_event show_text — instant, zero tick/trigger cost. Shared
# by the homestead open+sort path and the crate->chest dump path.
# Player-facing text is vocab-safe (no banned words).
# ============================================================

# Nothing rolled (empty table or already-empty buffer) — quiet line, no hover.
execute if score #cl_count ec.temp matches 0 run tellraw @s [{text:"[Forevercraft] ",color:"gold"},{text:"✦ Crate opened — it held nothing.",color:"gray",italic:true}]
execute if score #cl_count ec.temp matches 0 run return 0

# Stage the count for the macro header, then emit the hover line.
execute store result storage evercraft:crate_loot view.count int 1 run scoreboard players get #cl_count ec.temp
data modify storage evercraft:crate_loot view.summary set from storage evercraft:crate_loot summary
function evercraft:crates/loot_log/show_line with storage evercraft:crate_loot view
