# ============================================================
# Crate Loot Log — Append one line to the rolling summary (macro)
# Macro args (from storage evercraft:crate_loot row):
#   prev  (the summary string built so far)
#   count (stack size, plain int)
#   id    (item id, e.g. minecraft:diamond)
# ------------------------------------------------------------
# Rewrites the summary as "<prev>\n  <count>x <id>". The leading
# newline+indent makes the hover tooltip read as a tidy list. The
# item id is shown verbatim (always present on a rolled stack) —
# reliable for every item with no translation-key lookup needed.
# ============================================================
$data modify storage evercraft:crate_loot summary set value "$(prev)\n  $(count)× $(id)"
