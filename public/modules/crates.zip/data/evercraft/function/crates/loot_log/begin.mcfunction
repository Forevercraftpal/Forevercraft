# ============================================================
# Crate Loot Log — Begin a fresh capture
# Run as: player (any context)
# ------------------------------------------------------------
# Shared by BOTH crate-open-into-storage paths:
#   - homestead Quick-Stash "open + sort" (housing/stash/route_slot)
#   - crate -> chest dump (crates/dump_into_container/deposit)
# Resets the per-player rolling summary so a new open starts clean.
# The summary is a single newline-joined string accumulated one
# stack at a time (see scan_slot / append_line), then shown via a
# hover_event on a subtle tellraw line (crates/loot_log/show).
# ============================================================
data modify storage evercraft:crate_loot summary set value ""
scoreboard players set #cl_count ec.temp 0
