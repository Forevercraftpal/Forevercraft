# ============================================================
# Crate Loot Log — Scan the rolled buffer into the summary
# Run as: player, positioned within ..1 of the chest_minecart
#         buffer entity (tag=ec.cd_buffer) used by the roll step.
# ------------------------------------------------------------
# Walks the buffer's 27 slots; each occupied slot appends one
# "<count>x <item id>" line to the rolling summary string. Call
# begin first to reset, then show after to reveal via hover.
# One unrolled call per buffer slot (mirrors drain_loop).
# ============================================================
function evercraft:crates/loot_log/scan_slot {bslot:"0"}
function evercraft:crates/loot_log/scan_slot {bslot:"1"}
function evercraft:crates/loot_log/scan_slot {bslot:"2"}
function evercraft:crates/loot_log/scan_slot {bslot:"3"}
function evercraft:crates/loot_log/scan_slot {bslot:"4"}
function evercraft:crates/loot_log/scan_slot {bslot:"5"}
function evercraft:crates/loot_log/scan_slot {bslot:"6"}
function evercraft:crates/loot_log/scan_slot {bslot:"7"}
function evercraft:crates/loot_log/scan_slot {bslot:"8"}
function evercraft:crates/loot_log/scan_slot {bslot:"9"}
function evercraft:crates/loot_log/scan_slot {bslot:"10"}
function evercraft:crates/loot_log/scan_slot {bslot:"11"}
function evercraft:crates/loot_log/scan_slot {bslot:"12"}
function evercraft:crates/loot_log/scan_slot {bslot:"13"}
function evercraft:crates/loot_log/scan_slot {bslot:"14"}
function evercraft:crates/loot_log/scan_slot {bslot:"15"}
function evercraft:crates/loot_log/scan_slot {bslot:"16"}
function evercraft:crates/loot_log/scan_slot {bslot:"17"}
function evercraft:crates/loot_log/scan_slot {bslot:"18"}
function evercraft:crates/loot_log/scan_slot {bslot:"19"}
function evercraft:crates/loot_log/scan_slot {bslot:"20"}
function evercraft:crates/loot_log/scan_slot {bslot:"21"}
function evercraft:crates/loot_log/scan_slot {bslot:"22"}
function evercraft:crates/loot_log/scan_slot {bslot:"23"}
function evercraft:crates/loot_log/scan_slot {bslot:"24"}
function evercraft:crates/loot_log/scan_slot {bslot:"25"}
function evercraft:crates/loot_log/scan_slot {bslot:"26"}
