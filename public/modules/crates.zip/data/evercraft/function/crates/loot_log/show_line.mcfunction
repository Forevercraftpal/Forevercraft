# ============================================================
# Crate Loot Log — Emit the hover line (macro)
# Run as: player (the opener)
# Macro args (from storage evercraft:crate_loot view):
#   count   (number of stacks revealed, plain int)
#   summary (newline-joined "<count>x <id>" list)
# ------------------------------------------------------------
# One tellraw line. Hover reveals the full loot list. No click is
# needed — hover is instant and costs no tick/trigger. Vocab-safe.
# ============================================================
$tellraw @s [{text:"[Forevercraft] ",color:"gold"},{text:"✦ Crate opened — ",color:"yellow"},{text:"hover to see what you got",color:"aqua",italic:true,hover_event:{action:"show_text",value:[{text:"What the crate held:",color:"gold",bold:true},{text:"$(summary)",color:"white"}]}},{text:" ($(count) stacks)",color:"dark_gray"}]
