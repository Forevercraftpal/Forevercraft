# ============================================================
# Crate Loot Log — One-shot capture + reveal
# Run as: player, positioned within ..1 of the rolled buffer
#         (chest_minecart tag=ec.cd_buffer), BEFORE the buffer is
#         drained/emptied.
# ------------------------------------------------------------
# Convenience entry so a caller can wire the whole loot log with a
# SINGLE function call: reset -> scan the full buffer -> reveal the
# hover line. Used by the crate->chest dump (one-line retrofit) and
# the homestead open+sort path.
# ============================================================
function evercraft:crates/loot_log/begin
function evercraft:crates/loot_log/scan_buffer
function evercraft:crates/loot_log/show
