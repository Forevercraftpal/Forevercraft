# ============================================================
# Crate Loot Log — Capture one buffer slot into the summary (macro)
# Run as: player, positioned within ..1 of the buffer entity.
# Macro args: bslot (chest_minecart buffer slot 0-26)
# ------------------------------------------------------------
# If the slot is occupied, read its count + id, then macro-append a
# "<count>x <id>" line onto the rolling summary string. The buffer
# is selected by the same tight-distance tag the roll step used, so
# this is multiplayer-safe (one buffer per open, commands serialized).
# ============================================================

# Skip empty buffer slots.
$execute unless items entity @e[type=chest_minecart,tag=ec.cd_buffer,distance=..1,sort=nearest,limit=1] container.$(bslot) * run return 0

# Stage this stack's count + id as macro args for the append step.
# Count is stored as a plain int (read via store result) so the macro
# string renders "5" — not the raw NBT byte form "5b".
$execute store result storage evercraft:crate_loot row.count int 1 run data get entity @e[type=chest_minecart,tag=ec.cd_buffer,distance=..1,sort=nearest,limit=1] Items[{Slot:$(bslot)b}].count
$data modify storage evercraft:crate_loot row.id set from entity @e[type=chest_minecart,tag=ec.cd_buffer,distance=..1,sort=nearest,limit=1] Items[{Slot:$(bslot)b}].id

# Carry the current summary forward so the append macro can prepend it.
data modify storage evercraft:crate_loot row.prev set from storage evercraft:crate_loot summary

# Append "<count>x <id>\n" to the summary.
function evercraft:crates/loot_log/append_line with storage evercraft:crate_loot row

# Track how many stacks we have shown (cap displayed lines is fine; count is for the header).
scoreboard players add #cl_count ec.temp 1
