# ============================================================
# Crate → Container Dump — Move one buffer slot into the container
# Run as: player, positioned + aligned AT the container block.
# Macro args: bslot (chest_minecart buffer slot 0-26)
# ------------------------------------------------------------
# If the buffer slot is empty, do nothing. Otherwise place it into
# the first empty container slot. If the container has no room, drop
# the item at the block (never voided).
# ============================================================

# Skip empty buffer slots.
$execute unless items entity @e[type=chest_minecart,tag=ec.cd_buffer,distance=..1,sort=nearest,limit=1] container.$(bslot) * run return 0

# Phase 1 (Wave 38): try to merge with existing same-item stacks first.
# try_merge_pass internally checks custom_data / max_damage filters and
# scans all 27 container slots; the buffer slot may end up empty (fully
# merged) or partial (overflow remains).
$function evercraft:crates/dump_into_container/try_merge_pass {bslot:"$(bslot)"}

# If merge consumed the whole buffer slot, we're done — skip the
# empty-slot placement entirely.
$execute unless items entity @e[type=chest_minecart,tag=ec.cd_buffer,distance=..1,sort=nearest,limit=1] container.$(bslot) * run return 0

# Phase 2: any remaining content goes to the first empty container slot
# (returns 1 on success).
$execute store result score #cd_placed ec.temp run function evercraft:crates/dump_into_container/try_place {bslot:"$(bslot)"}

# Container was full — drop this item at the block instead of voiding it.
# Summon a placeholder item, copy the buffer slot's stack onto it, then clear
# the buffer slot (summon-then-populate idiom, cf. tamed_bond/check_owner).
execute if score #cd_placed ec.temp matches 0 run summon item ~0.5 ~1.1 ~0.5 {Tags:["ec.cd_drop_new"],PickupDelay:10s,Item:{id:"minecraft:stone",count:1}}
$execute if score #cd_placed ec.temp matches 0 run data modify entity @e[type=item,tag=ec.cd_drop_new,limit=1] Item set from entity @e[type=chest_minecart,tag=ec.cd_buffer,distance=..1,sort=nearest,limit=1] Items[{Slot:$(bslot)b}]
execute if score #cd_placed ec.temp matches 0 run data remove entity @e[type=item,tag=ec.cd_drop_new,limit=1] Item.Slot
execute if score #cd_placed ec.temp matches 0 run tag @e[type=item,tag=ec.cd_drop_new] remove ec.cd_drop_new
$execute if score #cd_placed ec.temp matches 0 run data remove entity @e[type=chest_minecart,tag=ec.cd_buffer,distance=..1,sort=nearest,limit=1] Items[{Slot:$(bslot)b}]
