# ============================================================
# Crate → Container Dump — Try to merge buffer slot into existing
#                         same-item stacks before falling through
#                         to empty-slot placement.
# Run as: player, positioned + aligned AT the container block.
# Macro args: bslot (chest_minecart buffer slot 0-26)
# Returns: 0 (caller checks buffer slot emptiness after).
# ------------------------------------------------------------
# Filters: only vanilla stackables get merged.
#   - Items with custom_data → skip (artifact merging needs deeper
#     match logic than this pass implements).
#   - Items with max_damage component → skip (tools/armor stack to 1).
# Everything else is treated as stack-to-64 (vanilla 16-stack items
# may overstack — accepted edge case).
# ============================================================

# Skip empty buffer slots.
$execute unless items entity @e[type=chest_minecart,tag=ec.cd_buffer,distance=..1,sort=nearest,limit=1] container.$(bslot) * run return 0

# Skip items with custom_data (artifact stacks, lore items).
$execute if items entity @e[type=chest_minecart,tag=ec.cd_buffer,distance=..1,sort=nearest,limit=1] container.$(bslot) *[custom_data~{}] run return 0

# Skip tools/armor (max_damage component present → 1-stack item).
$execute if data entity @e[type=chest_minecart,tag=ec.cd_buffer,distance=..1,sort=nearest,limit=1] Items[{Slot:$(bslot)b}].components."minecraft:max_damage" run return 0

# Stage the buffer's item id + slot for the scan macro.
$data modify storage evercraft:crates dump.item_id set from entity @e[type=chest_minecart,tag=ec.cd_buffer,distance=..1,sort=nearest,limit=1] Items[{Slot:$(bslot)b}].id
$data modify storage evercraft:crates dump.bslot set value "$(bslot)"

# Iterate container slots — merge first match, repeat until buffer empty or
# all slots scanned.
function evercraft:crates/dump_into_container/try_merge_scan with storage evercraft:crates dump
