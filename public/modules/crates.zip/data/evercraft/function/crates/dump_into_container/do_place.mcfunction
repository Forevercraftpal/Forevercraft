# ============================================================
# Crate → Container Dump — Move buffer slot → empty container slot
# Run as: player, positioned + aligned AT the container block.
# Macro args: bslot (buffer slot), cslot (empty container slot)
# Returns: 1 on success.
# Modeled on evercraft:housing/stash/do_insert.
# ============================================================

# Copy the buffer stack into the empty container slot.
$item replace block ~ ~ ~ container.$(cslot) from entity @e[type=chest_minecart,tag=ec.cd_buffer,distance=..1,sort=nearest,limit=1] container.$(bslot)

# Clear the buffer slot now that it has moved.
$data remove entity @e[type=chest_minecart,tag=ec.cd_buffer,distance=..1,sort=nearest,limit=1] Items[{Slot:$(bslot)b}]

return 1
