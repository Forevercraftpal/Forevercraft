# ============================================================
# Crate → Container Dump — Scan container slots for same-item
#                         merge targets.
# Run as: player, positioned + aligned AT the container block.
# Macro args: bslot (buffer slot), item_id (vanilla item id)
# ------------------------------------------------------------
# For each of the 27 container slots: if it holds the same item id
# WITHOUT custom_data, attempt to merge. After each attempt, if the
# buffer slot is empty, return — there is nothing left to merge.
# The buffer-empty short-circuit means we don't waste 26 more checks
# on a slot that already consumed everything.
# ============================================================
$execute if items block ~ ~ ~ container.0 $(item_id)[!custom_data~{}] run function evercraft:crates/dump_into_container/try_merge_at {bslot:"$(bslot)",cslot:"0"}
$execute unless items entity @e[type=chest_minecart,tag=ec.cd_buffer,distance=..1,sort=nearest,limit=1] container.$(bslot) * run return 0
$execute if items block ~ ~ ~ container.1 $(item_id)[!custom_data~{}] run function evercraft:crates/dump_into_container/try_merge_at {bslot:"$(bslot)",cslot:"1"}
$execute unless items entity @e[type=chest_minecart,tag=ec.cd_buffer,distance=..1,sort=nearest,limit=1] container.$(bslot) * run return 0
$execute if items block ~ ~ ~ container.2 $(item_id)[!custom_data~{}] run function evercraft:crates/dump_into_container/try_merge_at {bslot:"$(bslot)",cslot:"2"}
$execute unless items entity @e[type=chest_minecart,tag=ec.cd_buffer,distance=..1,sort=nearest,limit=1] container.$(bslot) * run return 0
$execute if items block ~ ~ ~ container.3 $(item_id)[!custom_data~{}] run function evercraft:crates/dump_into_container/try_merge_at {bslot:"$(bslot)",cslot:"3"}
$execute unless items entity @e[type=chest_minecart,tag=ec.cd_buffer,distance=..1,sort=nearest,limit=1] container.$(bslot) * run return 0
$execute if items block ~ ~ ~ container.4 $(item_id)[!custom_data~{}] run function evercraft:crates/dump_into_container/try_merge_at {bslot:"$(bslot)",cslot:"4"}
$execute unless items entity @e[type=chest_minecart,tag=ec.cd_buffer,distance=..1,sort=nearest,limit=1] container.$(bslot) * run return 0
$execute if items block ~ ~ ~ container.5 $(item_id)[!custom_data~{}] run function evercraft:crates/dump_into_container/try_merge_at {bslot:"$(bslot)",cslot:"5"}
$execute unless items entity @e[type=chest_minecart,tag=ec.cd_buffer,distance=..1,sort=nearest,limit=1] container.$(bslot) * run return 0
$execute if items block ~ ~ ~ container.6 $(item_id)[!custom_data~{}] run function evercraft:crates/dump_into_container/try_merge_at {bslot:"$(bslot)",cslot:"6"}
$execute unless items entity @e[type=chest_minecart,tag=ec.cd_buffer,distance=..1,sort=nearest,limit=1] container.$(bslot) * run return 0
$execute if items block ~ ~ ~ container.7 $(item_id)[!custom_data~{}] run function evercraft:crates/dump_into_container/try_merge_at {bslot:"$(bslot)",cslot:"7"}
$execute unless items entity @e[type=chest_minecart,tag=ec.cd_buffer,distance=..1,sort=nearest,limit=1] container.$(bslot) * run return 0
$execute if items block ~ ~ ~ container.8 $(item_id)[!custom_data~{}] run function evercraft:crates/dump_into_container/try_merge_at {bslot:"$(bslot)",cslot:"8"}
$execute unless items entity @e[type=chest_minecart,tag=ec.cd_buffer,distance=..1,sort=nearest,limit=1] container.$(bslot) * run return 0
$execute if items block ~ ~ ~ container.9 $(item_id)[!custom_data~{}] run function evercraft:crates/dump_into_container/try_merge_at {bslot:"$(bslot)",cslot:"9"}
$execute unless items entity @e[type=chest_minecart,tag=ec.cd_buffer,distance=..1,sort=nearest,limit=1] container.$(bslot) * run return 0
$execute if items block ~ ~ ~ container.10 $(item_id)[!custom_data~{}] run function evercraft:crates/dump_into_container/try_merge_at {bslot:"$(bslot)",cslot:"10"}
$execute unless items entity @e[type=chest_minecart,tag=ec.cd_buffer,distance=..1,sort=nearest,limit=1] container.$(bslot) * run return 0
$execute if items block ~ ~ ~ container.11 $(item_id)[!custom_data~{}] run function evercraft:crates/dump_into_container/try_merge_at {bslot:"$(bslot)",cslot:"11"}
$execute unless items entity @e[type=chest_minecart,tag=ec.cd_buffer,distance=..1,sort=nearest,limit=1] container.$(bslot) * run return 0
$execute if items block ~ ~ ~ container.12 $(item_id)[!custom_data~{}] run function evercraft:crates/dump_into_container/try_merge_at {bslot:"$(bslot)",cslot:"12"}
$execute unless items entity @e[type=chest_minecart,tag=ec.cd_buffer,distance=..1,sort=nearest,limit=1] container.$(bslot) * run return 0
$execute if items block ~ ~ ~ container.13 $(item_id)[!custom_data~{}] run function evercraft:crates/dump_into_container/try_merge_at {bslot:"$(bslot)",cslot:"13"}
$execute unless items entity @e[type=chest_minecart,tag=ec.cd_buffer,distance=..1,sort=nearest,limit=1] container.$(bslot) * run return 0
$execute if items block ~ ~ ~ container.14 $(item_id)[!custom_data~{}] run function evercraft:crates/dump_into_container/try_merge_at {bslot:"$(bslot)",cslot:"14"}
$execute unless items entity @e[type=chest_minecart,tag=ec.cd_buffer,distance=..1,sort=nearest,limit=1] container.$(bslot) * run return 0
$execute if items block ~ ~ ~ container.15 $(item_id)[!custom_data~{}] run function evercraft:crates/dump_into_container/try_merge_at {bslot:"$(bslot)",cslot:"15"}
$execute unless items entity @e[type=chest_minecart,tag=ec.cd_buffer,distance=..1,sort=nearest,limit=1] container.$(bslot) * run return 0
$execute if items block ~ ~ ~ container.16 $(item_id)[!custom_data~{}] run function evercraft:crates/dump_into_container/try_merge_at {bslot:"$(bslot)",cslot:"16"}
$execute unless items entity @e[type=chest_minecart,tag=ec.cd_buffer,distance=..1,sort=nearest,limit=1] container.$(bslot) * run return 0
$execute if items block ~ ~ ~ container.17 $(item_id)[!custom_data~{}] run function evercraft:crates/dump_into_container/try_merge_at {bslot:"$(bslot)",cslot:"17"}
$execute unless items entity @e[type=chest_minecart,tag=ec.cd_buffer,distance=..1,sort=nearest,limit=1] container.$(bslot) * run return 0
$execute if items block ~ ~ ~ container.18 $(item_id)[!custom_data~{}] run function evercraft:crates/dump_into_container/try_merge_at {bslot:"$(bslot)",cslot:"18"}
$execute unless items entity @e[type=chest_minecart,tag=ec.cd_buffer,distance=..1,sort=nearest,limit=1] container.$(bslot) * run return 0
$execute if items block ~ ~ ~ container.19 $(item_id)[!custom_data~{}] run function evercraft:crates/dump_into_container/try_merge_at {bslot:"$(bslot)",cslot:"19"}
$execute unless items entity @e[type=chest_minecart,tag=ec.cd_buffer,distance=..1,sort=nearest,limit=1] container.$(bslot) * run return 0
$execute if items block ~ ~ ~ container.20 $(item_id)[!custom_data~{}] run function evercraft:crates/dump_into_container/try_merge_at {bslot:"$(bslot)",cslot:"20"}
$execute unless items entity @e[type=chest_minecart,tag=ec.cd_buffer,distance=..1,sort=nearest,limit=1] container.$(bslot) * run return 0
$execute if items block ~ ~ ~ container.21 $(item_id)[!custom_data~{}] run function evercraft:crates/dump_into_container/try_merge_at {bslot:"$(bslot)",cslot:"21"}
$execute unless items entity @e[type=chest_minecart,tag=ec.cd_buffer,distance=..1,sort=nearest,limit=1] container.$(bslot) * run return 0
$execute if items block ~ ~ ~ container.22 $(item_id)[!custom_data~{}] run function evercraft:crates/dump_into_container/try_merge_at {bslot:"$(bslot)",cslot:"22"}
$execute unless items entity @e[type=chest_minecart,tag=ec.cd_buffer,distance=..1,sort=nearest,limit=1] container.$(bslot) * run return 0
$execute if items block ~ ~ ~ container.23 $(item_id)[!custom_data~{}] run function evercraft:crates/dump_into_container/try_merge_at {bslot:"$(bslot)",cslot:"23"}
$execute unless items entity @e[type=chest_minecart,tag=ec.cd_buffer,distance=..1,sort=nearest,limit=1] container.$(bslot) * run return 0
$execute if items block ~ ~ ~ container.24 $(item_id)[!custom_data~{}] run function evercraft:crates/dump_into_container/try_merge_at {bslot:"$(bslot)",cslot:"24"}
$execute unless items entity @e[type=chest_minecart,tag=ec.cd_buffer,distance=..1,sort=nearest,limit=1] container.$(bslot) * run return 0
$execute if items block ~ ~ ~ container.25 $(item_id)[!custom_data~{}] run function evercraft:crates/dump_into_container/try_merge_at {bslot:"$(bslot)",cslot:"25"}
$execute unless items entity @e[type=chest_minecart,tag=ec.cd_buffer,distance=..1,sort=nearest,limit=1] container.$(bslot) * run return 0
$execute if items block ~ ~ ~ container.26 $(item_id)[!custom_data~{}] run function evercraft:crates/dump_into_container/try_merge_at {bslot:"$(bslot)",cslot:"26"}
