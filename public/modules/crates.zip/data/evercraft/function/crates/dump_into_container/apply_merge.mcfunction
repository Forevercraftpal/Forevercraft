# ============================================================
# Crate → Container Dump — Apply a computed merge: bump the
#                         container slot's count, then either
#                         clear or trim the buffer slot.
# Run as: player, positioned + aligned AT the container block.
# Macro args: bslot, cslot, new_c, new_b
# ------------------------------------------------------------
# Caller (try_merge_at) staged all four values into the
# evercraft:crates dump path. apply_merge is the macro-only
# tail that writes them.
# ============================================================
$data modify block ~ ~ ~ Items[{Slot:$(cslot)b}].count set value $(new_c)
$execute if data storage evercraft:crates dump{new_b:0} run data remove entity @e[type=chest_minecart,tag=ec.cd_buffer,distance=..1,sort=nearest,limit=1] Items[{Slot:$(bslot)b}]
$execute unless data storage evercraft:crates dump{new_b:0} run data modify entity @e[type=chest_minecart,tag=ec.cd_buffer,distance=..1,sort=nearest,limit=1] Items[{Slot:$(bslot)b}].count set value $(new_b)
