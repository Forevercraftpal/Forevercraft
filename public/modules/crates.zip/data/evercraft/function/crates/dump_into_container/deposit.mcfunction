# ============================================================
# Crate → Container Dump — Deposit core (macro)
# Run as: player, positioned + aligned AT the container block.
# Macro args: loot_table (the crate's container_loot table id)
# ------------------------------------------------------------
# Rolls the crate's loot table into a temporary chest_minecart
# buffer (27 slots — never voids), then drains the buffer into
# the container block's free slots, dropping any overflow at the
# container. Plays a reveal FX (particles + sound only — NO
# animation barrel), then consumes one crate from the hand.
# ============================================================

# --- Roll the crate loot into a fresh 27-slot buffer entity ---
# A chest_minecart summoned AT the container block (invisible for the one
# tick it lives). Selecting by a tight distance keeps it multiplayer-safe:
# the container position is unique per dump, and commands are serialized so
# two players cannot share one buffer. We use `loot replace entity` (NOT
# `loot insert`, which is block-only and voids overflow) to roll the whole
# table into the minecart's 27 slots, then hand-drain into the container so
# overflow drops instead of being lost.
summon chest_minecart ~0.5 ~ ~0.5 {Tags:["ec.cd_buffer"],NoGravity:1b,Invulnerable:1b,Silent:1b,Items:[]}
$loot replace entity @e[type=chest_minecart,tag=ec.cd_buffer,distance=..1,sort=nearest,limit=1] container.0 27 loot $(loot_table)

# --- Loot log: reveal "what you got" (shared helper, hover line) ---
# Runs while the buffer is still full, before the drain empties it.
function evercraft:crates/loot_log/capture_and_show

# --- Drain the buffer's 27 slots into the container, dropping overflow ---
function evercraft:crates/dump_into_container/drain_loop

# Remove the buffer entity
kill @e[type=chest_minecart,tag=ec.cd_buffer,distance=..1,sort=nearest,limit=1]

# --- Reveal FX at the container (particles + sound only) ---
particle minecraft:firework ~0.5 ~0.6 ~0.5 0.5 0.5 0.5 0 50 force
particle minecraft:totem_of_undying ~0.5 ~0.6 ~0.5 0.3 0.3 0.3 0.2 18 force
particle minecraft:happy_villager ~0.5 ~0.6 ~0.5 0.4 0.4 0.4 0 15 force
playsound minecraft:entity.firework_rocket.blast ambient @a[distance=..20,scores={ec.fx_snd=1..}] ~ ~ ~
playsound minecraft:entity.firework_rocket.twinkle ambient @a[distance=..20,scores={ec.fx_snd=1..}] ~ ~ ~ 0.7 1.4
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.player.levelup master @s ~ ~ ~ 0.5 1.5

# --- Consume exactly one crate from the player's selected hand slot ---
item modify entity @s weapon.mainhand evercraft:decrease_count

# --- Subtle confirmation ---
data modify storage evercraft:notify stage.c set value [{text:"The crate's contents spill into the container.",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
