# ============================================================
# Crate → Container Dump — Drain buffer into the container
# Run as: player, positioned + aligned AT the container block.
# Buffer = chest_minecart tagged ec.cd_buffer (27 slots).
# For each buffer slot 0-26, move its item into the first empty
# container slot; if the container is full, drop it at the block
# (never voided). One unrolled call per buffer slot.
# ============================================================
function evercraft:crates/dump_into_container/drain_slot {bslot:"0"}
function evercraft:crates/dump_into_container/drain_slot {bslot:"1"}
function evercraft:crates/dump_into_container/drain_slot {bslot:"2"}
function evercraft:crates/dump_into_container/drain_slot {bslot:"3"}
function evercraft:crates/dump_into_container/drain_slot {bslot:"4"}
function evercraft:crates/dump_into_container/drain_slot {bslot:"5"}
function evercraft:crates/dump_into_container/drain_slot {bslot:"6"}
function evercraft:crates/dump_into_container/drain_slot {bslot:"7"}
function evercraft:crates/dump_into_container/drain_slot {bslot:"8"}
function evercraft:crates/dump_into_container/drain_slot {bslot:"9"}
function evercraft:crates/dump_into_container/drain_slot {bslot:"10"}
function evercraft:crates/dump_into_container/drain_slot {bslot:"11"}
function evercraft:crates/dump_into_container/drain_slot {bslot:"12"}
function evercraft:crates/dump_into_container/drain_slot {bslot:"13"}
function evercraft:crates/dump_into_container/drain_slot {bslot:"14"}
function evercraft:crates/dump_into_container/drain_slot {bslot:"15"}
function evercraft:crates/dump_into_container/drain_slot {bslot:"16"}
function evercraft:crates/dump_into_container/drain_slot {bslot:"17"}
function evercraft:crates/dump_into_container/drain_slot {bslot:"18"}
function evercraft:crates/dump_into_container/drain_slot {bslot:"19"}
function evercraft:crates/dump_into_container/drain_slot {bslot:"20"}
function evercraft:crates/dump_into_container/drain_slot {bslot:"21"}
function evercraft:crates/dump_into_container/drain_slot {bslot:"22"}
function evercraft:crates/dump_into_container/drain_slot {bslot:"23"}
function evercraft:crates/dump_into_container/drain_slot {bslot:"24"}
function evercraft:crates/dump_into_container/drain_slot {bslot:"25"}
function evercraft:crates/dump_into_container/drain_slot {bslot:"26"}
