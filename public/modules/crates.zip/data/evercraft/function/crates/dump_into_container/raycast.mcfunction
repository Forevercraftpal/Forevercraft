# ============================================================
# Crate → Container Dump — Raycast for the opened container
# Run as: player, positioned along the eye look direction
# Steps forward 0.2 blocks per call, max 30 steps = 6 blocks.
# On a hit, runs the deposit while positioned + aligned at the
# container block (so deposit's ~ ~ ~ is the container).
# Modeled on evercraft:housing/stash/label/raycast
# ============================================================
scoreboard players add #cd_steps ec.temp 1

# Hit a container block — mark found, align to the block grid, deposit there.
execute if block ~ ~ ~ #evercraft:stash_containers run tag @s add ec.cd_found
execute if entity @s[tag=ec.cd_found] align xyz run return run function evercraft:crates/dump_into_container/deposit with storage evercraft:crate_dump args

# Continue while under the step limit and no container hit yet.
execute if score #cd_steps ec.temp matches ..30 unless entity @s[tag=ec.cd_found] positioned ^ ^ ^0.2 run function evercraft:crates/dump_into_container/raycast
