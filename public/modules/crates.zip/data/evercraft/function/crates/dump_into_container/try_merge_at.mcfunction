# ============================================================
# Crate → Container Dump — Merge buffer slot into a specific
#                         container slot (same item id assured
#                         by the scan caller).
# Run as: player, positioned + aligned AT the container block.
# Macro args: bslot (buffer slot), cslot (container slot)
# Returns: 1 on partial/full merge, 0 if container slot was at max.
# ------------------------------------------------------------
# Reads both counts, computes new_c = min(b+c, max) and
# new_b = max(0, b+c-max). max defaults to 64 unless the buffer
# item carries an explicit max_stack_size component (custom items
# with bespoke caps). Applies via apply_merge macro.
# ============================================================

# Read buffer count + container count.
$execute store result score #cd_b ec.temp run data get entity @e[type=chest_minecart,tag=ec.cd_buffer,distance=..1,sort=nearest,limit=1] Items[{Slot:$(bslot)b}].count
$execute store result score #cd_c ec.temp run data get block ~ ~ ~ Items[{Slot:$(cslot)b}].count

# Determine max stack: default 64, override from component if present.
scoreboard players set #cd_max ec.temp 64
$execute store result score #cd_max ec.temp run data get entity @e[type=chest_minecart,tag=ec.cd_buffer,distance=..1,sort=nearest,limit=1] Items[{Slot:$(bslot)b}].components."minecraft:max_stack_size"
execute if score #cd_max ec.temp matches ..0 run scoreboard players set #cd_max ec.temp 64

# Container slot already at max → no room.
execute if score #cd_c ec.temp >= #cd_max ec.temp run return 0

# Compute new counts.
scoreboard players operation #cd_total ec.temp = #cd_b ec.temp
scoreboard players operation #cd_total ec.temp += #cd_c ec.temp
scoreboard players operation #cd_new_c ec.temp = #cd_total ec.temp
execute if score #cd_new_c ec.temp > #cd_max ec.temp run scoreboard players operation #cd_new_c ec.temp = #cd_max ec.temp
scoreboard players operation #cd_new_b ec.temp = #cd_total ec.temp
scoreboard players operation #cd_new_b ec.temp -= #cd_max ec.temp
execute if score #cd_new_b ec.temp matches ..-1 run scoreboard players set #cd_new_b ec.temp 0

# Stage all 4 values for the apply macro.
$data modify storage evercraft:crates dump.bslot set value "$(bslot)"
$data modify storage evercraft:crates dump.cslot set value "$(cslot)"
execute store result storage evercraft:crates dump.new_c int 1 run scoreboard players get #cd_new_c ec.temp
execute store result storage evercraft:crates dump.new_b int 1 run scoreboard players get #cd_new_b ec.temp

function evercraft:crates/dump_into_container/apply_merge with storage evercraft:crates dump

return 1
