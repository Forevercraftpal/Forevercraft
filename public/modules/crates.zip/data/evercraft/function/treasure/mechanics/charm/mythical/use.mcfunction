advancement revoke @s only evercraft:treasure/mechanics/charm/mythical

advancement revoke @s only evercraft:treasure/mechanics/charm/timer
scoreboard players add @s ec.charm_timer 12000
data modify storage evercraft:notify stage.c set value [{color:"gray",text:"Activated Mythical Charm!"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
playsound minecraft:ui.toast.challenge_complete ambient @a[distance=..7,scores={ec.fx_snd=1..}] ~ ~ ~0.5 0 1