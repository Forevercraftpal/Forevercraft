tag @s remove ec.reach
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bass player @s ~ ~ ~ 0.2 2

attribute @s block_interaction_range modifier remove ec.reach
attribute @s entity_interaction_range modifier remove ec.reach

scoreboard players set @s ec.reach 0