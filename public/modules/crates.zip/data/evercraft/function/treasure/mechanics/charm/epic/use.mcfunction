advancement revoke @s only evercraft:treasure/mechanics/charm/epic


advancement revoke @s only evercraft:treasure/mechanics/charm/timer

scoreboard players add @s ec.charm_timer 6000

data modify storage evercraft:notify stage.c set value [{color:"gray",text:"Activated Epic Charm!"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit

playsound minecraft:block.respawn_anchor.set_spawn ambient @a[distance=..7,scores={ec.fx_snd=1..}] ~ ~ ~1 0.5 1