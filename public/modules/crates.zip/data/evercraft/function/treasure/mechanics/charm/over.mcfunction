data modify storage evercraft:notify stage.c set value [{color:"gray",text:"Your charm ran out!"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit

scoreboard players set @s ec.charm_timer 0

# Restore base rates (RE-P5 2026-06-10: shared one-writer path — the old inline block
# restored only 4 tiers with mythical doubled; this covers all six + the Dream-Rate ramp).
function evercraft:treasure/apply_player_rates

execute if score @s ec.fx_snd matches 1.. run playsound block.beacon.deactivate player @s ~ ~ ~ 1 2 1