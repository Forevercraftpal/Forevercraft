advancement revoke @s only evercraft:treasure/mechanics/charm/common

advancement revoke @s only evercraft:treasure/mechanics/charm/timer

scoreboard players add @s ec.charm_timer 600

# Re-base through the shared path (RE-P5 2026-06-10) so the ×1.25 charm boost stacks ON the
# Dream-Rate ramp instead of silently wiping it for the charm window.
function evercraft:treasure/apply_player_rates

scoreboard players operation @s ec.common_chance *= #5 ec.const
scoreboard players operation @s ec.common_chance /= #4 ec.const

scoreboard players operation @s ec.rare_chance *= #5 ec.const
scoreboard players operation @s ec.rare_chance /= #4 ec.const

scoreboard players operation @s ec.epic_chance *= #5 ec.const
scoreboard players operation @s ec.epic_chance /= #4 ec.const

scoreboard players operation @s ec.mythical_chance *= #5 ec.const
scoreboard players operation @s ec.mythical_chance /= #4 ec.const

data modify storage evercraft:notify stage.c set value [{color:"gray",text:"Activated Common Charm!"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit

playsound minecraft:block.note_block.bell ambient @a[distance=..7,scores={ec.fx_snd=1..}] ~ ~ ~0.5 0 1