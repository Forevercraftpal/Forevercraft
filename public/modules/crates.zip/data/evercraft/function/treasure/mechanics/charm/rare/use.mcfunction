advancement revoke @s only evercraft:treasure/mechanics/charm/rare

advancement revoke @s only evercraft:treasure/mechanics/charm/timer

scoreboard players add @s ec.charm_timer 2400

data modify storage evercraft:notify stage.c set value [{color:"gray",text:"Activated Rare Charm!"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit

playsound minecraft:entity.firework_rocket.launch ambient @a[distance=..7,scores={ec.fx_snd=1..}] ~ ~ ~1 1.2 1