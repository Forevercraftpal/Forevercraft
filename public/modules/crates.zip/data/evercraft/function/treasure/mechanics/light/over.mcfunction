tag @s remove ec.light
attribute @s gravity modifier remove ec.light
attribute @s safe_fall_distance modifier remove ec.light

execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.amethyst_block.chime player @s ~ ~ ~ 0.2 2

scoreboard players set @s ec.light 0