# Treasure - Tick
# Early exit if no players online
execute unless entity @a run return 0

# OPT: Tag-gated flat scan — check unchecked items only (no @a×@e cross-product)
# Tag persists so each item is only NBT-checked once (like mob_crates pattern)
# OPT: limit=10 caps per-tick processing — prevents lag spikes with many dropped items
execute as @e[type=item,tag=!ec.head_checked,limit=10] at @s if entity @a[distance=..20] run function evercraft:treasure/check_head

# execute as every player
execute as @a at @s run function evercraft:treasure/tick_player

# execute as every entity (only if tagged entities exist)
# Audit #3 W7.6: limit=20 caps adversarial spray scenarios (admin test markers, etc).
# Normal peak is ~5-20 entities (display markers + gilded-rune cooldowns).
execute if entity @e[type=#evercraft:treasure/targets,tag=ec.entity,limit=1] as @e[type=#evercraft:treasure/targets,tag=ec.entity,limit=20] at @s run function evercraft:treasure/tick_entity

# Flower Veil — verdant helmet aura (existence-gated on ec.flower_helmet tag)
execute if entity @a[tag=ec.flower_helmet,limit=1] as @a[tag=ec.flower_helmet] run function evercraft:treasure/particles/flower_veil/tick

# Gust — sprint-jump airburst (existence-gated)
# Path 1: Sprint-jumping players with no active animation kick off a new gust.
#         Selector excludes players with an active timer so they don't double-tick.
execute if entity @a[predicate=evercraft:treasure/is_airborne_sprinting,limit=1] as @a[predicate=evercraft:treasure/is_airborne_sprinting] unless score @s ec.gust_timer matches 1.. run function evercraft:treasure/particles/gust/tick
# Path 2: Players in mid-animation: continue ticking down regardless of current ground state.
execute as @a[scores={ec.gust_timer=1..}] run function evercraft:treasure/particles/gust/tick

# Audit #3 W7.2: previous comment claimed a 5s schedule for ghost cleanup, but no
# treasure/cleanup/tick or its scheduler exists. Removed stale claim.