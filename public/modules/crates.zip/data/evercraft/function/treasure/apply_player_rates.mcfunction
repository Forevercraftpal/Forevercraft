# ============================================================
# Treasure — Apply Per-Player Mining Rates (RE-P5, 2026-06-10)
# ============================================================
# Run as @s = the player. THE one writer path for the per-player ec.<tier>_chance
# scores the mining loot tables roll against (random_chance × scale 1.6e-07 in
# loot_table/treasure/technical/*). Replaces the five scattered copy blocks
# (player_load, player_update, database/name/check, frequency/update_rates,
# charm/over) — which between them missed exquisite (player_update) and
# uncommon+exquisite (charm/over).
#
# 1) Base copy from the frequency-preset globals (all SIX tiers).
# 2) RE-P5 progression ramp: preset-global odds used to be identical at hour 1
#    and hour 200. The find RATE now ramps with Dream Rate (the tier-QUALITY
#    gates at DR 5/15/25 in treasure/luck/gate_* already existed):
#      $tr_ramp ec.var 0 = Off       (×1.00 everywhere — the old behavior)
#                      1 = Standard  (DR≥15 ×1.25 · DR≥25 ×1.50)  [default]
#                      2 = Strong    (DR≥15 ×1.50 · DR≥25 ×2.00)
#    Bands mirror the mob-crate DR splits from the 2026-06-10 re-pacing.
#    $tr_ramp default is affirmed in treasure/init (declare-anywhere safe);
#    the admin Treasure Settings panel is its writer (settings/panel_ramp).
# Charm composition: charm/common/use re-bases THROUGH this fn then applies its
# ×1.25 on top, and charm/over restores through it — charms stack on the ramp
# instead of silently wiping it.

# --- 1) Base copy (the frequency presets' globals) ---
scoreboard players operation @s ec.common_chance = #chance_common ec.var
scoreboard players operation @s ec.uncommon_chance = #chance_uncommon ec.var
scoreboard players operation @s ec.rare_chance = #chance_rare ec.var
scoreboard players operation @s ec.epic_chance = #chance_epic ec.var
scoreboard players operation @s ec.exquisite_chance = #chance_exquisite ec.var
scoreboard players operation @s ec.mythical_chance = #chance_mythical ec.var

# --- 2) Dream-Rate ramp (luck attr ×10, same scale as the gate_* thresholds) ---
execute store result score #tr_dr ec.temp run attribute @s luck get 10
scoreboard players set #tr_mul ec.temp 100
execute if score $tr_ramp ec.var matches 1 if score #tr_dr ec.temp matches 150.. run scoreboard players set #tr_mul ec.temp 125
execute if score $tr_ramp ec.var matches 1 if score #tr_dr ec.temp matches 250.. run scoreboard players set #tr_mul ec.temp 150
execute if score $tr_ramp ec.var matches 2 if score #tr_dr ec.temp matches 150.. run scoreboard players set #tr_mul ec.temp 150
execute if score $tr_ramp ec.var matches 2 if score #tr_dr ec.temp matches 250.. run scoreboard players set #tr_mul ec.temp 200

# --- 2b) Stonestrike class scaling (Joseph 2026-06-10: "scale mining treasure odds with
# stonestrike"). The mining class's EARNED boost % (ec.caffb_ss: 2/4/6/8/11/13/16 by stage,
# 20 mastered — written by craft_affinity/update_stage) multiplies ON TOP of the DR ramp
# (max ×2.0 × ×1.20 = ×2.4 at Strong + mastered). Re-synced on ss stage-up (stage_up hook)
# since these scores are event-cached. Gated by the Treasure Settings panel's "Affinity
# crate scaling" toggle (#disable_aff_scale — also gates the fishing/mob-crate analogues).
scoreboard players set #tr_caffmul ec.temp 100
execute if score #disable_aff_scale ec.constant matches 0 if score @s ec.caffb_ss matches 1.. run scoreboard players operation #tr_caffmul ec.temp += @s ec.caffb_ss
scoreboard players operation #tr_mul ec.temp *= #tr_caffmul ec.temp
scoreboard players operation #tr_mul ec.temp /= #100 ec.const

execute if score #tr_mul ec.temp matches 100 run return 0
scoreboard players operation @s ec.common_chance *= #tr_mul ec.temp
scoreboard players operation @s ec.common_chance /= #100 ec.const
scoreboard players operation @s ec.uncommon_chance *= #tr_mul ec.temp
scoreboard players operation @s ec.uncommon_chance /= #100 ec.const
scoreboard players operation @s ec.rare_chance *= #tr_mul ec.temp
scoreboard players operation @s ec.rare_chance /= #100 ec.const
scoreboard players operation @s ec.epic_chance *= #tr_mul ec.temp
scoreboard players operation @s ec.epic_chance /= #100 ec.const
scoreboard players operation @s ec.exquisite_chance *= #tr_mul ec.temp
scoreboard players operation @s ec.exquisite_chance /= #100 ec.const
scoreboard players operation @s ec.mythical_chance *= #tr_mul ec.temp
scoreboard players operation @s ec.mythical_chance /= #100 ec.const
