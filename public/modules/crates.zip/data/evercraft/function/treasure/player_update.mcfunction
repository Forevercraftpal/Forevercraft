# Treasure — per-player rate re-sync (advancement-rewarded; see advancement/treasure/player_update).
# RE-P5 2026-06-10: routed through the shared one-writer path (base copy + Dream-Rate ramp).
# The old inline block silently MISSED ec.exquisite_chance — apply_player_rates covers all six.
function evercraft:treasure/apply_player_rates
