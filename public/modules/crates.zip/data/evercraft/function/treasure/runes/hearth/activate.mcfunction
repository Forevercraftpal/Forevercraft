tag @s add ec.rune_activated

playsound minecraft:block.note_block.bell master @a[distance=..20,scores={ec.fx_snd=1..}] ~ ~ ~ 0.2 2 1

execute as @e[type=#evercraft:treasure/ridable,distance=..10] run function evercraft:treasure/runes/hearth/as

advancement revoke @s only evercraft:treasure/runes/hearth_glyph

function evercraft:treasure/runes/hearth/particles