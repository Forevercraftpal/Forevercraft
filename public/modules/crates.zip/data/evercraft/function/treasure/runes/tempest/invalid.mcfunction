data modify storage evercraft:notify stage.c set value [{text:"Invalid use — put an enchantable item in your offhand!",color:"red"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit

# Inv-full guard: drop at the player's feet rather than void on a full inventory.
execute store result score #inv_full ec.var run function evercraft:util/check_inv_full
execute if score #inv_full ec.var matches 0 run loot give @s loot evercraft:treasure/runes/tempest
execute if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:treasure/runes/tempest