execute at @s[scores={ec.tick=15}] run particle minecraft:snowflake ~ ~ ~ 0.5 0.5 0.5 0.2 50 force

execute at @s run setblock ~ ~-1 ~ blue_ice keep

execute at @s[scores={ec.ember_rune=1}] if score @s ec.fx_snd matches 1.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.5 2 1

scoreboard players remove @s ec.ember_rune 1