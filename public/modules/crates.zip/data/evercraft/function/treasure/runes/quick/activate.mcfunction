tag @s add ec.rune_activated

scoreboard players set @s ec.quick_rune_t 200

# Defensive remove-before-add (Audit #3 W1.3): prevents stacked permanent modifiers.
attribute @s attack_damage modifier remove ec.quick_rune
attribute @s movement_speed modifier remove ec.quick_rune
attribute @s attack_damage modifier add ec.quick_rune 0.2 add_multiplied_total
attribute @s movement_speed modifier add ec.quick_rune 0.1 add_multiplied_total

playsound minecraft:block.note_block.bass master @a[distance=..20,scores={ec.fx_snd=1..}] ~ ~ ~ 1 0.6 1

particle minecraft:smoke ~ ~ ~ 0.2 0.200 0.2 0.1 200 force @a

function evercraft:treasure/runes/quick/particles

advancement revoke @s only evercraft:treasure/runes/quick_glyph