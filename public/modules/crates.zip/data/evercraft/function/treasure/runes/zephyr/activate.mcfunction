tag @s add ec.rune_activated

scoreboard players set @s ec.zephyr_rune 160

# Defensive remove-before-add (Audit #3 W1.3): prevents stacked permanent modifiers
# if a re-activation sneaks in around timer expiry (single-tick race window).
attribute @s knockback_resistance modifier remove ec.zephyr_rune
attribute @s attack_damage modifier remove ec.zephyr_rune
attribute @s knockback_resistance modifier add ec.zephyr_rune 1000 add_value
attribute @s attack_damage modifier add ec.zephyr_rune 0.1 add_multiplied_total

playsound minecraft:block.amethyst_block.resonate master @a[distance=..20,scores={ec.fx_snd=1..}] ~ ~ ~ 1 0.6 1

particle minecraft:end_rod ~ ~ ~ 0.2 0.200 0.2 0.1 50 force @a

function evercraft:treasure/runes/zephyr/particles

advancement revoke @s only evercraft:treasure/runes/zephyr_glyph