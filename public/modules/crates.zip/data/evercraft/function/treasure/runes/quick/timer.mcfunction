execute at @s[scores={ec.tick=15}] run particle dust{color:[0.894,0.176,0.176],scale:1.5} ~ ~0.8 ~ 0.2 0.4 0.2 0.5 10 force @a

attribute @s[scores={ec.quick_rune_t=1}] attack_damage modifier remove ec.quick_rune
attribute @s[scores={ec.quick_rune_t=1}] movement_speed modifier remove ec.quick_rune

execute at @s[scores={ec.quick_rune_t=1}] if score @s ec.fx_snd matches 1.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.5 2 1

scoreboard players remove @s ec.quick_rune_t 1