attribute @s armor modifier remove ec.gilded_rune_debuff
attribute @s armor_toughness modifier remove ec.gilded_rune_debuff

tag @s remove ec.absorb_taken
# Audit #3 W7.1: tag was previously never cleared (leaf doc gotcha). Symmetry with score-side clear.
tag @s remove ec.absorb_steal
