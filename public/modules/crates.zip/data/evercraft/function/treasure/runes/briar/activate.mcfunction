tag @s add ec.rune_activated

scoreboard players set @s ec.briar_rune 200

# Defensive remove-before-add (Audit #3 W1.3): prevents stacked permanent modifiers.
attribute @s movement_speed modifier remove ec.briar_rune
attribute @s attack_speed modifier remove ec.briar_rune
attribute @s movement_speed modifier add ec.briar_rune 0.4 add_multiplied_total
attribute @s attack_speed modifier add ec.briar_rune 0.2 add_multiplied_total

playsound minecraft:block.note_block.bass master @a[distance=..20,scores={ec.fx_snd=1..}] ~ ~ ~ 1 0.2 1

particle minecraft:sneeze ~ ~ ~ 0.2 0.200 0.2 0.1 50 force @a

advancement revoke @s only evercraft:treasure/runes/briar_glyph


function evercraft:treasure/runes/briar/particles