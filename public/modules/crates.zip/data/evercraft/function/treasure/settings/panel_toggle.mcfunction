# Treasure Settings panel — flip a #disable_* register (macro). Args: {const,store}
#   const = the ec.constant fake-player name (e.g. disable_rune, disable_indestructible)
#   store = the evercraft:treasure/settings storage key (e.g. runes, bedrock) — kept in
#           sync for the settings/set data-layer contract (its .initial field).
# Flip idiom: store result of an if-score (1 when currently 0, else 0) = the new value.
# Run as: the admin player (gate re-checked — /function click_events replay from history).
execute unless entity @s[tag=ec.admin] run return 0
$execute store result score #tr_flip ec.temp if score #$(const) ec.constant matches 0
$scoreboard players operation #$(const) ec.constant = #tr_flip ec.temp
$execute store result storage evercraft:treasure/settings $(store).initial int 1 run scoreboard players get #$(const) ec.constant
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.hat master @s ~ ~ ~ 0.6 1.2
function evercraft:treasure/settings/panel
