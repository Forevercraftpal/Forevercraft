# Treasure Settings panel — set the RE-P5 Dream-Rate ramp mode (macro). Args: {level}
#   level = 0 Off · 1 Standard (DR≥15 ×1.25, DR≥25 ×1.5) · 2 Strong (×1.5/×2.0)
# Re-applies rates to every online player immediately (joiners get it via player_load).
# Run as: the admin player (gate re-checked — /function click_events replay from history).
execute unless entity @s[tag=ec.admin] run return 0
$scoreboard players set $tr_ramp ec.var $(level)
execute as @a run function evercraft:treasure/apply_player_rates
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.6 1.6
function evercraft:treasure/settings/panel
