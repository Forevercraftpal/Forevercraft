# Treasure — push the current frequency globals to every online player.
# RE-P5 2026-06-10: per-player routing through the shared apply_player_rates one-writer
# path (base copy + Dream-Rate progression ramp) instead of the old flat @a copies.
execute as @a run function evercraft:treasure/apply_player_rates
