# Treasure Settings panel — apply a preset (macro). Args: {kind,name,level}
#   kind  = progression | frequency | despawn   (the settings/ sub-folder)
#   name  = the preset fn name (minimal/low/standard/high/extreme · sloth..hypersonic)
#   level = 1-5, recorded on the $<kind> ec.var display score (mirrors settings/set)
# Run as: the admin player (panel buttons only render inside the gated panel, but
# the gate is re-checked here — /function click_events are replayable from history).
execute unless entity @s[tag=ec.admin] run return 0
$scoreboard players set $$(kind) ec.var $(level)
$function evercraft:treasure/settings/$(kind)/$(name)
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.6 1.4
function evercraft:treasure/settings/panel
