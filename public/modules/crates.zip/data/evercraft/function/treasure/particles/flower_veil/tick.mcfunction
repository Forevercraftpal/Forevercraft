# Flower Veil — Per-player tick
# Called as @a from treasure/tick when at least one player has ec.flower_helmet tag.
# Wired 2026-05-26 per treasure council convening.
#
# Design:
#   - Helmet wearer gets a periodic verdant aura (18-frame spiral, ~0.9s render window).
#   - Cooldown ec.veil_timer ticks down (1 unit / tick). When it reaches 0, the next
#     aura kicks off (sets timer back to 100 = 5 sec) and ec.veil resets to 0.
#   - During the aura, ec.veil counts 0..17 (one frame per tick) and is dispatched
#     via l1_0. Once ec.veil exceeds 17, we let the cooldown finish.
#   - Gives 2 sec of regen-1 on aura start.
#
# Sole writer of ec.veil + ec.veil_timer. One-writer law preserved.

# Bootstrap: if timer not yet set, start the cycle
execute unless score @s ec.veil_timer matches 1.. run scoreboard players set @s ec.veil_timer 100
execute unless score @s ec.veil_timer matches 1.. run scoreboard players set @s ec.veil 0
execute unless score @s ec.veil_timer matches 1.. at @s run effect give @s minecraft:regeneration 2 0 true
execute unless score @s ec.veil_timer matches 1.. at @s run playsound minecraft:block.azalea_leaves.place ambient @a[distance=..12,scores={ec.fx_snd=1..}] ~ ~ ~ 0.4 1.4

# Render frames while ec.veil is in [0..17]
execute if score @s ec.veil matches 0..17 at @s run function evercraft:treasure/particles/flower_veil/l1_0
scoreboard players add @s[scores={ec.veil=0..17}] ec.veil 1

# Tick down cooldown; when it hits 0, the bootstrap above re-fires next tick
scoreboard players remove @s ec.veil_timer 1
