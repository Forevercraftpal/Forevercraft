execute if score @s ec.veil matches 0 run function evercraft:treasure/particles/flower_veil/frames/f0
execute if score @s ec.veil matches 1 run function evercraft:treasure/particles/flower_veil/frames/f1
execute if score @s ec.veil matches 2 run function evercraft:treasure/particles/flower_veil/frames/f2
execute if score @s ec.veil matches 3 run function evercraft:treasure/particles/flower_veil/frames/f3
execute if score @s ec.veil matches 4 run function evercraft:treasure/particles/flower_veil/frames/f4
execute if score @s ec.veil matches 5 run function evercraft:treasure/particles/flower_veil/frames/f5
execute if score @s ec.veil matches 6 run function evercraft:treasure/particles/flower_veil/frames/f6
execute if score @s ec.veil matches 7 run function evercraft:treasure/particles/flower_veil/frames/f7