# Crate fanfare T3 RARE — C-major pling + first bell (crate-reveal identity pass, 2026-06-09).
# Replaces the generic entity.player.levelup at rare reveals.
playsound minecraft:block.note_block.pling master @a[distance=..20,scores={ec.fx_snd=1..}] ~ ~ ~ 0.55 1.414
playsound minecraft:block.note_block.pling master @a[distance=..20,scores={ec.fx_snd=1..}] ~ ~ ~ 0.4 1.782
playsound minecraft:block.note_block.bell master @a[distance=..20,scores={ec.fx_snd=1..}] ~ ~ ~ 0.3 1.414
