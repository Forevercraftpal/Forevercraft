# Harvester's Dreamy Seed — rare drop notification
# Run as animation armor_stand, at the barrel position
# Called when per-tier chance hits — gives the seed + sets earn-pity flag

# Inv-full guard: drop the seed at the barrel rather than void this rare find on a full inventory.
execute as @p[distance=..16] store result score #inv_full ec.var run function evercraft:util/check_inv_full
execute if score #inv_full ec.var matches 0 run loot give @p[distance=..16] loot evercraft:items/harvesters_dreamy_seed
execute if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:items/harvesters_dreamy_seed
scoreboard players set @p[distance=..16] ec.seed_count 1
