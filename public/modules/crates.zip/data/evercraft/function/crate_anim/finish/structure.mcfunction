# Structure Crate Finish — All Tiers
# Run as animation armor_stand, at the barrel position
# Unlock barrel and play tier-appropriate effects based on ec.crate_tier score

# Unlock barrel and set tier-appropriate name
data remove block ~ ~ ~ lock
execute if score @s ec.crate_tier matches 1 run data merge block ~ ~ ~ {CustomName:{text:"Common Structure Crate",color:"white",italic:false}}
execute if score @s ec.crate_tier matches 2 run data merge block ~ ~ ~ {CustomName:{text:"Uncommon Structure Crate",color:"green",italic:false}}
execute if score @s ec.crate_tier matches 3 run data merge block ~ ~ ~ {CustomName:{text:"Rare Structure Crate",color:"aqua",italic:false}}
execute if score @s ec.crate_tier matches 4 run data merge block ~ ~ ~ {CustomName:{text:"Ornate Structure Crate",color:"light_purple",italic:false}}
execute if score @s ec.crate_tier matches 5 run data merge block ~ ~ ~ {CustomName:{text:"Exquisite Structure Crate",color:"light_purple",italic:false}}
execute if score @s ec.crate_tier matches 6 run data merge block ~ ~ ~ {CustomName:{text:"Mythical Structure Crate",color:"gold",italic:false}}

# Tier-specific effects
# Common (tier 1)
execute if score @s ec.crate_tier matches 1 run particle minecraft:firework ~ ~0.5 ~ 0.5 0.5 0.5 0 50 force
execute if score @s ec.crate_tier matches 1 run playsound minecraft:entity.firework_rocket.blast ambient @a[distance=..16,scores={ec.fx_snd=1..}] ~ ~ ~
execute if score @s ec.crate_tier matches 1 run function evercraft:crate_anim/finish/fanfare/common

# Uncommon (tier 2)
execute if score @s ec.crate_tier matches 2 run particle minecraft:firework ~ ~0.5 ~ 0.5 0.5 0.5 0 50 force
execute if score @s ec.crate_tier matches 2 run particle minecraft:happy_villager ~ ~0.5 ~ 0.3 0.3 0.3 0 15 force
execute if score @s ec.crate_tier matches 2 run playsound minecraft:entity.firework_rocket.blast ambient @a[distance=..16,scores={ec.fx_snd=1..}] ~ ~ ~
execute if score @s ec.crate_tier matches 2 run function evercraft:crate_anim/finish/fanfare/uncommon

# Rare (tier 3)
execute if score @s ec.crate_tier matches 3 run particle minecraft:firework ~ ~0.5 ~ 0.5 0.5 0.5 0 50 force
execute if score @s ec.crate_tier matches 3 run particle minecraft:soul_fire_flame ~ ~0.5 ~ 0.3 0.3 0.3 0.02 20 force
execute if score @s ec.crate_tier matches 3 run playsound minecraft:entity.firework_rocket.blast ambient @a[distance=..20,scores={ec.fx_snd=1..}] ~ ~ ~
execute if score @s ec.crate_tier matches 3 run function evercraft:crate_anim/finish/fanfare/rare

# Ornate (tier 4)
execute if score @s ec.crate_tier matches 4 run particle minecraft:firework ~ ~0.5 ~ 0.5 0.5 0.5 0 50 force
execute if score @s ec.crate_tier matches 4 run particle minecraft:flame ~ ~0.5 ~ 0.3 0.3 0.3 0.01 30 force
execute if score @s ec.crate_tier matches 4 run playsound minecraft:entity.firework_rocket.blast ambient @a[distance=..32,scores={ec.fx_snd=1..}] ~ ~ ~
execute if score @s ec.crate_tier matches 4 run function evercraft:crate_anim/finish/fanfare/ornate
data modify storage evercraft:notify stage.c set value [{text:"An Ornate Structure Crate has appeared!",color:"light_purple",italic:true}]
scoreboard players set #ndur ec.temp 45
execute if score @s ec.crate_tier matches 4 as @a[distance=..64] run function evercraft:util/notify/emit_keep

# Exquisite (tier 5) — purple #8c0691
execute if score @s ec.crate_tier matches 5 run particle flash{color:[1.000,1.000,1.000,1.00]} ~ ~0.5 ~ 0.5 0.5 0.5 0 50 force
execute if score @s ec.crate_tier matches 5 run particle minecraft:totem_of_undying ~ ~0.5 ~ 0.5 0.5 0.5 0.3 40 force
execute if score @s ec.crate_tier matches 5 run particle minecraft:enchant ~ ~0.5 ~ 0.5 0.5 0.5 1 50 force
execute if score @s ec.crate_tier matches 5 run playsound minecraft:block.end_portal.spawn master @a[scores={ec.fx_snd=1..}] ~ ~ ~ 1 1.2 1
execute if score @s ec.crate_tier matches 5 run function evercraft:crate_anim/finish/fanfare/exquisite
execute if score @s ec.crate_tier matches 5 run playsound minecraft:ui.toast.challenge_complete master @a[distance=..48,scores={ec.fx_snd=1..}] ~ ~ ~ 0.7 1.2
# (AB-1 sticky-times sweep 2026-06-10: explicit stamp — `title times` is sticky per player and this sequence set none, so it inherited whatever ran last.)
execute if score @s ec.crate_tier matches 5 run title @p[distance=..32] times 10 60 20
execute if score @s ec.crate_tier matches 5 run title @p[distance=..32] subtitle {text:"Exquisite Structure Crate!",color:"#8c0691",bold:true}
execute if score @s ec.crate_tier matches 5 run title @p[distance=..32] title {text:"⚡",color:"#8c0691",bold:true}
execute if score @s ec.crate_tier matches 5 as @p[distance=..32] run function evercraft:util/notify/whoami
data modify storage evercraft:notify stage.c set value [{text:""},{text:" found an "},{text:"Exquisite Structure Crate",color:"#8c0691",bold:true},{text:"!"}]
data modify storage evercraft:notify stage.c[0].text set from storage evercraft:notify named.who
scoreboard players set #ndur ec.temp 50
execute if score @s ec.crate_tier matches 5 as @p[distance=..32] run execute as @a run scoreboard players set #nttl ec.temp 600
execute if score @s ec.crate_tier matches 5 as @p[distance=..32] run execute as @a run function evercraft:util/notify/emit_keep

# Mythical (tier 6) — gold
execute if score @s ec.crate_tier matches 6 run particle flash{color:[1.000,1.000,1.000,1.00]} ~ ~0.5 ~ 0.5 0.5 0.5 0 50 force
execute if score @s ec.crate_tier matches 6 run particle minecraft:totem_of_undying ~ ~0.5 ~ 0.6 0.6 0.6 0.5 60 force
execute if score @s ec.crate_tier matches 6 run particle minecraft:end_rod ~ ~0.5 ~ 0.5 0.5 0.5 0.1 30 force
execute if score @s ec.crate_tier matches 6 run particle minecraft:enchant ~ ~1 ~ 0.5 0.5 0.5 2 100 force
execute if score @s ec.crate_tier matches 6 run playsound minecraft:block.end_portal.spawn master @a[scores={ec.fx_snd=1..}] ~ ~ ~ 1 1.2 1
execute if score @s ec.crate_tier matches 6 run function evercraft:crate_anim/finish/fanfare/mythical
execute if score @s ec.crate_tier matches 6 run playsound minecraft:block.anvil.land master @a[scores={ec.fx_snd=1..}] ~ ~ ~ 1 0.5 1
execute if score @s ec.crate_tier matches 6 run playsound minecraft:block.anvil.land master @a[scores={ec.fx_snd=1..}] ~ ~ ~ 1 0.75 1
execute if score @s ec.crate_tier matches 6 run playsound minecraft:block.anvil.land master @a[scores={ec.fx_snd=1..}] ~ ~ ~ 1 1.0 1
execute if score @s ec.crate_tier matches 6 run playsound minecraft:ui.toast.challenge_complete master @a[scores={ec.fx_snd=1..}] ~ ~ ~ 1 0.8
execute if score @s ec.crate_tier matches 6 run title @p[distance=..32] subtitle {text:"MYTHICAL Structure Crate!",color:"gold",bold:true}
execute if score @s ec.crate_tier matches 6 run title @p[distance=..32] title {text:"⚡",color:"gold",bold:true}
execute if score @s ec.crate_tier matches 6 as @p[distance=..32] run function evercraft:util/notify/whoami
data modify storage evercraft:notify stage.c set value [{text:""},{text:" found a "},{text:"MYTHICAL Structure Crate",color:"gold",bold:true},{text:"!"}]
data modify storage evercraft:notify stage.c[0].text set from storage evercraft:notify named.who
scoreboard players set #ndur ec.temp 50
execute if score @s ec.crate_tier matches 6 as @p[distance=..32] run execute as @a run scoreboard players set #nttl ec.temp 600
execute if score @s ec.crate_tier matches 6 as @p[distance=..32] run execute as @a run function evercraft:util/notify/emit_keep

# Campfire Stories — record mythical find
execute if score @s ec.crate_tier matches 6 run data modify storage evercraft:campfire temp.artifact set value "a Mythical Structure Crate"
execute if score @s ec.crate_tier matches 6 as @p[distance=..32] run function evercraft:campfire_stories/record/mythical_find

# Companion memory: Treasure Found + Mythical Discovery (mythical structure crate)
execute if score @s ec.crate_tier matches 6 as @p[distance=..32,tag=companion.activepet] run function evercraft:companions/memories/on_mythical_crate
execute if score @s ec.crate_tier matches 6 as @p[distance=..32,tag=companion.activepet] run function evercraft:companions/memories/on_mythical_artifact

# Dream Echo — permanent wisp at mythical find location
execute if score @s ec.crate_tier matches 6 run function evercraft:dream_echoes/spawn

# World Milestones — mythical artifact found
execute if score @s ec.crate_tier matches 6 as @p[distance=..32] run function evercraft:milestones/increment/mythical_found

# Achievement tracking
scoreboard players add @p[distance=..16] ach.crates_structure 1
scoreboard players add @p[distance=..16] ach.crates_opened 1
execute if score @s ec.crate_tier matches 6 run scoreboard players operation @p[distance=..16] ec.last_mythical_at = @p[distance=..16] ach.crates_opened

# Cooking Utensil discovery — once per player, low chance (tier-scaled), give-or-drop guarded.
# ec.crate_tier lives on the animation armor_stand (@s here); switch to @p only after the tier gate.
execute if score @s ec.crate_tier matches 1 as @p[distance=..16] if score @s ec.found_utensil matches 0 if predicate {"condition":"minecraft:random_chance","chance":0.015} run function evercraft:crate_anim/finish/give_utensil
execute if score @s ec.crate_tier matches 2 as @p[distance=..16] if score @s ec.found_utensil matches 0 if predicate {"condition":"minecraft:random_chance","chance":0.02} run function evercraft:crate_anim/finish/give_utensil
execute if score @s ec.crate_tier matches 3 as @p[distance=..16] if score @s ec.found_utensil matches 0 if predicate {"condition":"minecraft:random_chance","chance":0.03} run function evercraft:crate_anim/finish/give_utensil
execute if score @s ec.crate_tier matches 4 as @p[distance=..16] if score @s ec.found_utensil matches 0 if predicate {"condition":"minecraft:random_chance","chance":0.04} run function evercraft:crate_anim/finish/give_utensil
execute if score @s ec.crate_tier matches 5 as @p[distance=..16] if score @s ec.found_utensil matches 0 if predicate {"condition":"minecraft:random_chance","chance":0.05} run function evercraft:crate_anim/finish/give_utensil
execute if score @s ec.crate_tier matches 6 as @p[distance=..16] if score @s ec.found_utensil matches 0 if predicate {"condition":"minecraft:random_chance","chance":0.06} run function evercraft:crate_anim/finish/give_utensil
