# Crate fanfare T6 MYTHICAL — the full C-major cascade (crate-reveal pass, 2026-06-09). Layers UNDER
# the existing end_portal.spawn + anvil DUN-DUN-DUN ladder + toast (all kept — Joseph: occasional
# anvils are a treat). This is the only fanfare with the full bass-to-chime spread.
playsound minecraft:block.note_block.bass master @a[distance=..48,scores={ec.fx_snd=1..}] ~ ~ ~ 0.6 0.707
playsound minecraft:block.note_block.pling master @a[distance=..48,scores={ec.fx_snd=1..}] ~ ~ ~ 0.5 1.059
playsound minecraft:block.note_block.pling master @a[distance=..48,scores={ec.fx_snd=1..}] ~ ~ ~ 0.6 1.414
playsound minecraft:block.note_block.pling master @a[distance=..48,scores={ec.fx_snd=1..}] ~ ~ ~ 0.5 1.782
playsound minecraft:block.note_block.bell master @a[distance=..48,scores={ec.fx_snd=1..}] ~ ~ ~ 0.45 1.414
playsound minecraft:block.note_block.bell master @a[distance=..48,scores={ec.fx_snd=1..}] ~ ~ ~ 0.4 1.782
playsound minecraft:block.note_block.chime master @a[distance=..48,scores={ec.fx_snd=1..}] ~ ~ ~ 0.35 1.782
