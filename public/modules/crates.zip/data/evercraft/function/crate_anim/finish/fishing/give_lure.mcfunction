# Fisherman's Dozing Lure — rare drop notification
# Run as animation armor_stand, at the barrel position
# Called when 0.1% chance hits — gives the lure + announces it

# Inv-full guard: drop the lure at the barrel rather than void this legendary find on a full inventory.
execute as @p[distance=..16] store result score #inv_full ec.var run function evercraft:util/check_inv_full
execute if score #inv_full ec.var matches 0 run loot give @p[distance=..16] loot evercraft:items/fishermans_dozing_lure
execute if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:items/fishermans_dozing_lure
scoreboard players set @p[distance=..16] ec.lure_count 1

# Global announcement — this is a legendary find
execute as @p[distance=..16] run function evercraft:util/notify/whoami
data modify storage evercraft:notify stage.c set value [{text:""},{text:" found the legendary "},{text:"Fisherman's Dozing Lure",color:"gold",bold:true},{text:"! (+1 permanent Dream Rate)"}]
data modify storage evercraft:notify stage.c[0].text set from storage evercraft:notify named.who
scoreboard players set #ndur ec.temp 50
execute as @p[distance=..16] run execute as @a run scoreboard players set #nttl ec.temp 600
execute as @p[distance=..16] run execute as @a run function evercraft:util/notify/emit_keep
playsound minecraft:ui.toast.challenge_complete master @p[distance=..16,scores={ec.fx_snd=1..}] ~ ~ ~ 1 1.0
# (AB-1 sticky-times sweep 2026-06-10: explicit stamp — `title times` is sticky per player and this sequence set none, so it inherited whatever ran last.)
title @p[distance=..16] times 10 60 20
title @p[distance=..16] subtitle {text:"Fisherman's Dozing Lure!",color:"gold"}
title @p[distance=..16] title {text:"🎣",color:"gold"}
