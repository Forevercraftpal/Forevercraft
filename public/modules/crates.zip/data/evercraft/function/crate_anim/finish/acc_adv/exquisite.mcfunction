# Accessory Crate Finish - Exquisite Adventurer Accessory Crate
data remove block ~ ~ ~ lock
data merge block ~ ~ ~ {CustomName:{text:"Exquisite Adventurer Accessory Crate",color:"light_purple",italic:false}}
particle flash{color:[1.000,1.000,1.000,1.00]} ~ ~0.5 ~ 0.5 0.5 0.5 0 50 force
particle minecraft:totem_of_undying ~ ~0.5 ~ 0.5 0.5 0.5 0.3 40 force
particle minecraft:enchant ~ ~0.5 ~ 0.5 0.5 0.5 1 50 force
playsound minecraft:block.end_portal.spawn master @a[scores={ec.fx_snd=1..}] ~ ~ ~ 1 1.2 1
function evercraft:crate_anim/finish/fanfare/exquisite
playsound minecraft:ui.toast.challenge_complete master @a[distance=..48,scores={ec.fx_snd=1..}] ~ ~ ~ 0.7 1.2

# Crate statistics tracking (accessories count as artifacts)
scoreboard players add @p[distance=..16] ec.crate_art 1
scoreboard players add @p[distance=..16] ach.crates_opened 1

# Cooking Utensil discovery — once per player, low chance, give-or-drop guarded.
execute as @p[distance=..16] if score @s ec.found_utensil matches 0 if predicate {"condition":"minecraft:random_chance","chance":0.05} run function evercraft:crate_anim/finish/give_utensil
