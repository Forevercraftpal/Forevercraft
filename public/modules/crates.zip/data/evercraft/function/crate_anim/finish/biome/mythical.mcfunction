# Biome Crate finish (premium animation). Run as the animation armor_stand, AT the barrel position.
# Unlocks the barrel; ALL loot lives in its container_loot (Joseph J3 2026-06-06): guaranteed DR-scaled
# gear + signature + themed bonus + jackpot + the Baul, rolled to whoever opens the barrel. The gear TIER
# is stamped at EARN time (biome_crates/give_item), so nothing is function-granted to the player here.
data remove block ~ ~ ~ lock
data merge block ~ ~ ~ {CustomName:{text:"Biome Crate",color:"aqua",italic:false}}
particle minecraft:firework ~ ~0.5 ~ 0.5 0.5 0.5 0 50 force
particle minecraft:glow ~ ~0.5 ~ 0.4 0.4 0.4 0.01 30 force
playsound minecraft:entity.firework_rocket.blast ambient @a[distance=..32,scores={ec.fx_snd=1..}] ~ ~ ~
function evercraft:crate_anim/finish/fanfare/mythical
playsound minecraft:block.conduit.activate master @a[distance=..32,scores={ec.fx_snd=1..}] ~ ~ ~ 0.8 1.1
data modify storage evercraft:notify stage.c set value [{text:"A Biome Crate breaks open!",color:"aqua",italic:true}]
scoreboard players set #ndur ec.temp 45
execute as @a[distance=..64] run function evercraft:util/notify/emit_keep

# Achievement tracking
scoreboard players add @p[distance=..16] ach.crates_opened 1

# (Gear is no longer function-granted here — it lives in the barrel's container_loot, earn-time DR-tiered.)

# Cooking Utensil discovery — once per player, low chance, give-or-drop guarded.
execute as @p[distance=..16] if score @s ec.found_utensil matches 0 if predicate {"condition":"minecraft:random_chance","chance":0.06} run function evercraft:crate_anim/finish/give_utensil
