# Artifact Crate Finish — Common
data remove block ~ ~ ~ lock
data merge block ~ ~ ~ {CustomName:{text:"Common Artifact Crate",color:"white",italic:false}}
particle minecraft:firework ~ ~0.5 ~ 0.5 0.5 0.5 0 50 force
playsound minecraft:entity.firework_rocket.blast ambient @a[distance=..16,scores={ec.fx_snd=1..}] ~ ~ ~
function evercraft:crate_anim/finish/fanfare/common

# Crate statistics tracking
scoreboard players add @p[distance=..16] ec.crate_art 1
scoreboard players add @p[distance=..16] ach.crates_opened 1

# Cooking Utensil discovery — once per player, low chance, give-or-drop guarded.
execute as @p[distance=..16] if score @s ec.found_utensil matches 0 if predicate {"condition":"minecraft:random_chance","chance":0.015} run function evercraft:crate_anim/finish/give_utensil
