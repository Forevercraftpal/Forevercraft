# Harvest Crate Finish — Exquisite
# Run as animation armor_stand, at the barrel position
# Exquisite = purple #8c0691

data remove block ~ ~ ~ lock
data merge block ~ ~ ~ {CustomName:{text:"Exquisite Harvest Crate",color:"light_purple",italic:false}}
particle flash{color:[1.000,1.000,1.000,1.00]} ~ ~0.5 ~ 0.5 0.5 0.5 0 50 force
particle minecraft:totem_of_undying ~ ~0.5 ~ 0.5 0.5 0.5 0.3 40 force
particle minecraft:enchant ~ ~0.5 ~ 0.5 0.5 0.5 1 50 force
playsound minecraft:block.end_portal.spawn master @a[scores={ec.fx_snd=1..}] ~ ~ ~ 1 1.2 1
function evercraft:crate_anim/finish/fanfare/exquisite
playsound minecraft:ui.toast.challenge_complete master @a[distance=..48,scores={ec.fx_snd=1..}] ~ ~ ~ 0.7 1.2

# Title for nearest player
# (AB-1 sticky-times sweep 2026-06-10: explicit stamp — `title times` is sticky per player and this sequence set none, so it inherited whatever ran last.)
title @p[distance=..32] times 10 60 20
title @p[distance=..32] subtitle {text:"Exquisite Harvest Crate!",color:"#8c0691"}
title @p[distance=..32] title {text:"⚡",color:"#8c0691"}

# Global announcement
execute as @p[distance=..32] run function evercraft:util/notify/whoami
data modify storage evercraft:notify stage.c set value [{text:""},{text:" found an "},{text:"Exquisite Harvest Crate",color:"#8c0691",bold:true},{text:"!"}]
data modify storage evercraft:notify stage.c[0].text set from storage evercraft:notify named.who
scoreboard players set #ndur ec.temp 50
execute as @p[distance=..32] run execute as @a run scoreboard players set #nttl ec.temp 600
execute as @p[distance=..32] run execute as @a run function evercraft:util/notify/emit_keep

# Achievement tracking
scoreboard players add @p[distance=..16] ach.crates_harvest 1
scoreboard players add @p[distance=..16] ach.crates_opened 1

# 0.1% chance to drop Harvester's Dreamy Seed (+1 permanent DR)
execute unless score @p[distance=..16] ec.seed_count matches 1.. if predicate {"condition":"minecraft:random_chance","chance":0.035} run function evercraft:crate_anim/finish/harvest/give_seed

# Anecdote: Elder's (once per player)
execute as @p[distance=..16] unless score @s ec.anec_elder matches 1 run function evercraft:anecdotes/give_elders

# Cooking Utensil discovery — once per player, low chance, give-or-drop guarded.
execute as @p[distance=..16] if score @s ec.found_utensil matches 0 if predicate {"condition":"minecraft:random_chance","chance":0.05} run function evercraft:crate_anim/finish/give_utensil
