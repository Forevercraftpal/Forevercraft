# Accessory Crate Finish - Mythical Adventurer Accessory Crate
data remove block ~ ~ ~ lock
data merge block ~ ~ ~ {CustomName:{text:"Mythical Adventurer Accessory Crate",color:"gold",italic:false}}
particle flash{color:[1.000,1.000,1.000,1.00]} ~ ~0.5 ~ 0.5 0.5 0.5 0 50 force
particle minecraft:totem_of_undying ~ ~0.5 ~ 0.6 0.6 0.6 0.5 60 force
particle minecraft:end_rod ~ ~0.5 ~ 0.5 0.5 0.5 0.1 30 force
particle minecraft:enchant ~ ~1 ~ 0.5 0.5 0.5 2 100 force
playsound minecraft:block.end_portal.spawn master @a[scores={ec.fx_snd=1..}] ~ ~ ~ 1 1.2 1
function evercraft:crate_anim/finish/fanfare/mythical
playsound minecraft:block.anvil.land master @a[scores={ec.fx_snd=1..}] ~ ~ ~ 1 0.75 1
playsound minecraft:ui.toast.challenge_complete master @a[scores={ec.fx_snd=1..}] ~ ~ ~ 1 0.8

# Crate statistics tracking (accessories count as artifacts)
scoreboard players add @p[distance=..16] ec.crate_art 1
scoreboard players add @p[distance=..16] ach.crates_opened 1

# Cooking Utensil discovery — once per player, low chance, give-or-drop guarded.
execute as @p[distance=..16] if score @s ec.found_utensil matches 0 if predicate {"condition":"minecraft:random_chance","chance":0.06} run function evercraft:crate_anim/finish/give_utensil
