# Harvest Crate Finish — Mythical
# Run as animation armor_stand, at the barrel position
# Mythical = gold

data remove block ~ ~ ~ lock
data merge block ~ ~ ~ {CustomName:{text:"Mythical Harvest Crate",color:"gold",italic:false}}
particle flash{color:[1.000,1.000,1.000,1.00]} ~ ~0.5 ~ 0.5 0.5 0.5 0 50 force
particle minecraft:totem_of_undying ~ ~0.5 ~ 0.6 0.6 0.6 0.5 60 force
particle minecraft:end_rod ~ ~0.5 ~ 0.5 0.5 0.5 0.1 30 force
particle minecraft:enchant ~ ~1 ~ 0.5 0.5 0.5 2 100 force
playsound minecraft:block.end_portal.spawn master @a[scores={ec.fx_snd=1..}] ~ ~ ~ 1 1.2 1
function evercraft:crate_anim/finish/fanfare/mythical
playsound minecraft:block.anvil.land master @a[scores={ec.fx_snd=1..}] ~ ~ ~ 1 0.5 1
playsound minecraft:block.anvil.land master @a[scores={ec.fx_snd=1..}] ~ ~ ~ 1 0.75 1
playsound minecraft:block.anvil.land master @a[scores={ec.fx_snd=1..}] ~ ~ ~ 1 1.0 1
playsound minecraft:ui.toast.challenge_complete master @a[scores={ec.fx_snd=1..}] ~ ~ ~ 1 0.8

# Title for nearest player
# (AB-1 sticky-times sweep 2026-06-10: explicit stamp — `title times` is sticky per player and this sequence set none, so it inherited whatever ran last.)
title @p[distance=..32] times 10 60 20
title @p[distance=..32] subtitle {text:"MYTHICAL Harvest Crate!",color:"gold"}
title @p[distance=..32] title {text:"⚡",color:"gold"}

# Global announcement
execute as @p[distance=..32] run function evercraft:util/notify/whoami
data modify storage evercraft:notify stage.c set value [{text:""},{text:" found a "},{text:"MYTHICAL Harvest Crate",color:"gold",bold:true},{text:"!"}]
data modify storage evercraft:notify stage.c[0].text set from storage evercraft:notify named.who
scoreboard players set #ndur ec.temp 50
execute as @p[distance=..32] run execute as @a run scoreboard players set #nttl ec.temp 600
execute as @p[distance=..32] run execute as @a run function evercraft:util/notify/emit_keep

# Achievement tracking
scoreboard players add @p[distance=..16] ach.crates_harvest 1
scoreboard players add @p[distance=..16] ach.crates_opened 1
scoreboard players operation @p[distance=..16] ec.last_mythical_at = @p[distance=..16] ach.crates_opened

# 0.1% chance to drop Harvester's Dreamy Seed (+1 permanent DR)
execute unless score @p[distance=..16] ec.seed_count matches 1.. if predicate {"condition":"minecraft:random_chance","chance":0.05} run function evercraft:crate_anim/finish/harvest/give_seed

# Campfire Stories — record mythical find
data modify storage evercraft:campfire temp.artifact set value "a Mythical Harvest Crate"
execute as @p[distance=..32] run function evercraft:campfire_stories/record/mythical_find

# Companion memory: Treasure Found + Mythical Discovery
execute as @p[distance=..32,tag=companion.activepet] run function evercraft:companions/memories/on_mythical_crate
execute as @p[distance=..32,tag=companion.activepet] run function evercraft:companions/memories/on_mythical_artifact

# Dream Echo — permanent wisp at this mythical find location
function evercraft:dream_echoes/spawn

# World Milestones — mythical artifact found
execute as @p[distance=..32] run function evercraft:milestones/increment/mythical_found

# Anecdote: Elder's (once per player)
execute as @p[distance=..16] unless score @s ec.anec_elder matches 1 run function evercraft:anecdotes/give_elders

# Cooking Utensil discovery — once per player, low chance, give-or-drop guarded.
execute as @p[distance=..16] if score @s ec.found_utensil matches 0 if predicate {"condition":"minecraft:random_chance","chance":0.06} run function evercraft:crate_anim/finish/give_utensil
