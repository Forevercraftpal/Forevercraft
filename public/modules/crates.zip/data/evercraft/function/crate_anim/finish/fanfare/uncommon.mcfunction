# Crate fanfare T2 UNCOMMON — full C-major harp triad (crate-reveal identity pass, 2026-06-09).
playsound minecraft:block.note_block.harp master @a[distance=..16,scores={ec.fx_snd=1..}] ~ ~ ~ 0.45 1.059
playsound minecraft:block.note_block.harp master @a[distance=..16,scores={ec.fx_snd=1..}] ~ ~ ~ 0.5 1.414
playsound minecraft:block.note_block.harp master @a[distance=..16,scores={ec.fx_snd=1..}] ~ ~ ~ 0.35 1.782
