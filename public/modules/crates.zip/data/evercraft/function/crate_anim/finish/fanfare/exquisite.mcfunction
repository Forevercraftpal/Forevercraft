# Crate fanfare T5 EXQUISITE — bass-rooted C-major with bell + chime (crate-reveal pass, 2026-06-09).
# Layers UNDER the existing end_portal.spawn + toast (those stay — they're the epic identity).
playsound minecraft:block.note_block.bass master @a[distance=..32,scores={ec.fx_snd=1..}] ~ ~ ~ 0.55 0.707
playsound minecraft:block.note_block.pling master @a[distance=..32,scores={ec.fx_snd=1..}] ~ ~ ~ 0.55 1.414
playsound minecraft:block.note_block.pling master @a[distance=..32,scores={ec.fx_snd=1..}] ~ ~ ~ 0.45 1.782
playsound minecraft:block.note_block.bell master @a[distance=..32,scores={ec.fx_snd=1..}] ~ ~ ~ 0.4 1.414
playsound minecraft:block.note_block.chime master @a[distance=..32,scores={ec.fx_snd=1..}] ~ ~ ~ 0.3 1.782
