# Cooking Utensil — crate discovery drop (once per player, give-or-drop guarded)
# Run AS @s = the player (callers do `execute as @p[distance=..16] ... run function ...`).
# Mirrors the anecdote give_* pattern: gives the item, sets a permanent once-per-player flag,
# and emits one action-bar notify (white body, not bold — popup law). The utensil is a
# keep-forever cooking tool; a player who already owns/crafted one never gets a crate dupe.
# Gate (ec.found_utensil != 1) is enforced by the caller; we set the flag here so re-entry is safe.

# Re-assert the gate defensively (caller already checked, but keep idempotent).
execute if score @s ec.found_utensil matches 1 run return fail

# Mark discovered FIRST so any mid-tick re-roll can't double-give.
scoreboard players set @s ec.found_utensil 1

# Give-or-drop: never void on a full inventory.
execute store result score #inv_full ec.var run function evercraft:util/check_inv_full
execute if score #inv_full ec.var matches 0 run loot give @s loot evercraft:cooking/cooking_utensil
execute if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:cooking/cooking_utensil

# Notify (action-bar, white body, not bold — mirrors anecdote notify style).
data modify storage evercraft:notify stage.c set value [{text:"You found a ",color:"gray",italic:true},{text:"Cooking Utensil",color:"gold",italic:false},{text:" — cook meals at any campfire.",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit_keep
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.campfire.crackle master @s ~ ~ ~ 1 1.0
