# Quest Crate Finish — Ornate
data remove block ~ ~ ~ lock
data merge block ~ ~ ~ {CustomName:{text:"Ornate Quest Crate",color:"light_purple",italic:false}}
particle minecraft:firework ~ ~0.5 ~ 0.5 0.5 0.5 0 50 force
particle minecraft:flame ~ ~0.5 ~ 0.3 0.3 0.3 0.01 30 force
playsound minecraft:entity.firework_rocket.blast ambient @a[distance=..32,scores={ec.fx_snd=1..}] ~ ~ ~
function evercraft:crate_anim/finish/fanfare/ornate
data modify storage evercraft:notify stage.c set value [{text:"An Ornate Quest Crate has appeared!",color:"light_purple",italic:true}]
scoreboard players set #ndur ec.temp 45
execute as @a[distance=..64] run function evercraft:util/notify/emit_keep

# Crate statistics tracking
scoreboard players add @p[distance=..16] ec.crate_quest 1
scoreboard players add @p[distance=..16] ach.crates_opened 1

# Cooking Utensil discovery — once per player, low chance, give-or-drop guarded.
execute as @p[distance=..16] if score @s ec.found_utensil matches 0 if predicate {"condition":"minecraft:random_chance","chance":0.04} run function evercraft:crate_anim/finish/give_utensil
