# Crate fanfare T1 COMMON — C-MAJOR harp dyad (crate-reveal identity pass, 2026-06-09; C major is the
# shared "reward" key, distinct from every gather-family key). Run AS the crate armor stand AT the
# barrel; audible to nearby players, per-listener fx_snd-gated in the selector.
playsound minecraft:block.note_block.harp master @a[distance=..16,scores={ec.fx_snd=1..}] ~ ~ ~ 0.5 1.414
playsound minecraft:block.note_block.harp master @a[distance=..16,scores={ec.fx_snd=1..}] ~ ~ ~ 0.35 1.782
