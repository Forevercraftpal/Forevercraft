# Furnishings Crate Finish — Common (standard pipeline, 2026-06-10)
data remove block ~ ~ ~ lock
data merge block ~ ~ ~ {CustomName:{text:"Common Furnishings Crate",color:"white",italic:false}}
particle minecraft:firework ~ ~0.5 ~ 0.5 0.5 0.5 0 50 force
playsound minecraft:entity.firework_rocket.blast ambient @a[distance=..16,scores={ec.fx_snd=1..}] ~ ~ ~
function evercraft:crate_anim/finish/fanfare/common

# Crate statistics tracking
scoreboard players add @p[distance=..16] ach.crates_opened 1

# Antique quality source window (Phase D): blueprints taken from this common crate stamp as Poor (75). Cleared after ~15s by the tick (ec.antq_src_t).
scoreboard players set @p[distance=..16] ec.antq_src 75
scoreboard players set @p[distance=..16] ec.antq_src_t 300

# Reveal feedback (no "magic" — furnishings language)
data modify storage evercraft:notify stage.c set value [{text:"The crate spills open — new ",color:"gray"},{text:"furnishings",color:"aqua"},{text:" for your home!",color:"gray"}]
scoreboard players set #ndur ec.temp 50
execute as @p[distance=..16] run function evercraft:util/notify/emit
