# Crate fanfare T4 ORNATE — wider C-major pling voicing + high bell (crate-reveal pass, 2026-06-09).
playsound minecraft:block.note_block.pling master @a[distance=..24,scores={ec.fx_snd=1..}] ~ ~ ~ 0.45 1.059
playsound minecraft:block.note_block.pling master @a[distance=..24,scores={ec.fx_snd=1..}] ~ ~ ~ 0.55 1.414
playsound minecraft:block.note_block.pling master @a[distance=..24,scores={ec.fx_snd=1..}] ~ ~ ~ 0.45 1.782
playsound minecraft:block.note_block.bell master @a[distance=..24,scores={ec.fx_snd=1..}] ~ ~ ~ 0.35 1.782
