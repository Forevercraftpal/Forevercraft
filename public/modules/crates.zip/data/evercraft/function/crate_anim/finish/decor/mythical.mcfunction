# Furnishings Crate Finish — Mythical (standard pipeline, 2026-06-10)
data remove block ~ ~ ~ lock
data merge block ~ ~ ~ {CustomName:{text:"Mythical Furnishings Crate",color:"gold",italic:false}}
particle flash{color:[1.000,1.000,1.000,1.00]} ~ ~0.5 ~ 0.5 0.5 0.5 0 50 force
particle minecraft:totem_of_undying ~ ~0.5 ~ 0.6 0.6 0.6 0.5 60 force
particle minecraft:end_rod ~ ~0.5 ~ 0.5 0.5 0.5 0.1 30 force
particle minecraft:enchant ~ ~1 ~ 0.5 0.5 0.5 2 100 force
playsound minecraft:block.end_portal.spawn master @a[scores={ec.fx_snd=1..}] ~ ~ ~ 1 1.2 1
playsound minecraft:block.anvil.land master @a[scores={ec.fx_snd=1..}] ~ ~ ~ 1 0.5 1
playsound minecraft:block.anvil.land master @a[scores={ec.fx_snd=1..}] ~ ~ ~ 1 0.75 1
playsound minecraft:block.anvil.land master @a[scores={ec.fx_snd=1..}] ~ ~ ~ 1 1.0 1
playsound minecraft:ui.toast.challenge_complete master @a[scores={ec.fx_snd=1..}] ~ ~ ~ 1 0.8
function evercraft:crate_anim/finish/fanfare/mythical

# Crate statistics tracking
scoreboard players add @p[distance=..16] ach.crates_opened 1

# Antique quality source window (Phase D): blueprints taken from this mythical crate stamp as Pristine (200). Cleared after ~15s by the tick (ec.antq_src_t).
scoreboard players set @p[distance=..16] ec.antq_src 200
scoreboard players set @p[distance=..16] ec.antq_src_t 300

# Reveal feedback (no "magic" — furnishings language)
data modify storage evercraft:notify stage.c set value [{text:"The crate spills open — new ",color:"gray"},{text:"furnishings",color:"aqua"},{text:" for your home!",color:"gray"}]
scoreboard players set #ndur ec.temp 50
execute as @p[distance=..16] run function evercraft:util/notify/emit
