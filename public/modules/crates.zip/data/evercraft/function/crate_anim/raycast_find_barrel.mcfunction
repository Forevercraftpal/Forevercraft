# Raycast forward to find a placed crate barrel (max 7 blocks, 70 steps at 0.1)
# Macro args: $(tier), $(system_tag), $(plot_start), $(skin), $(nbt_key), $(nbt_val)
# Run as: player with tag ec.searching, positioned along look direction
#
# Wiring fix (2026-05-30, crate-lands-on-wrong-barrel): added OCCLUSION. The ray now stops at
# the first solid block, so it can no longer tunnel PAST the crate you placed to a same-tier
# barrel further along your line of sight (the "lands further away" case). A freshly-placed
# crate is the first solid block under your crosshair, so it is hit first. Step tightened
# 0.2 -> 0.1 to stop glancing-angle corner-skip.
scoreboard players add @s cf.temp 1

# Hit-test: is THIS sample the correct, not-yet-animating barrel? If so, animate it (stops the ray).
$execute if block ~ ~ ~ minecraft:barrel if data block ~ ~ ~ {components:{"minecraft:custom_data":{$(nbt_key):"$(nbt_val)"}}} align xyz unless entity @n[type=armor_stand,tag=ec.crate_anim,distance=..0.5] run function evercraft:crate_anim/lock_and_animate {tier:"$(tier)",system_tag:"$(system_tag)",plot_start:$(plot_start),skin:"$(skin)"}

# Continue ONLY through air (occlusion). Any solid block — the placed crate, a wall, the floor,
# or an already-animating barrel — stops the ray, so it can't reach a barrel behind it.
$execute if entity @s[tag=ec.searching] if block ~ ~ ~ minecraft:air if score @s cf.temp matches ..70 positioned ^ ^ ^0.1 run function evercraft:crate_anim/raycast_find_barrel {tier:"$(tier)",system_tag:"$(system_tag)",plot_start:$(plot_start),skin:"$(skin)",nbt_key:"$(nbt_key)",nbt_val:"$(nbt_val)"}

# Reset counter when done
execute if score @s cf.temp matches 71.. run scoreboard players set @s cf.temp 0
