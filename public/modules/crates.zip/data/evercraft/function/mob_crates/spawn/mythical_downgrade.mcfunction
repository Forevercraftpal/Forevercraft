# Mob Crates - Downgrade Mythical → cascade through Exquisite gate (Dream Rate < 25)
data modify storage evercraft:notify stage.c set value [{text:"★ ",color:"gold"},{text:"A mythical mob crate flickered but dimmed... your dreams aren't powerful enough.",color:"gray",italic:true},{text:" ★",color:"gold"}]
scoreboard players set #ndur ec.temp 50
execute as @p[distance=..16] run function evercraft:util/notify/emit_keep
data modify storage evercraft:notify stage.c set value [{text:"Requires ",color:"gray"},{text:"Dream Rate 25",color:"gold",bold:true},{text:" for Mythical mob crates.",color:"gray"}]
scoreboard players set #ndur ec.temp 40
execute as @p[distance=..16] run function evercraft:util/notify/emit
playsound minecraft:block.amethyst_block.break master @p[distance=..16,scores={ec.fx_snd=1..}] ~ ~ ~ 1 0.3

# Cascade: check if player qualifies for Exquisite (Dream Rate >= 15), otherwise Ornate (bounded — same player as the gate read)
execute if score @p[distance=..16] ec.temp matches 150.. run function evercraft:mob_crates/spawn/exquisite_grant
execute unless score @p[distance=..16] ec.temp matches 150.. run function evercraft:mob_crates/spawn/exquisite_downgrade
