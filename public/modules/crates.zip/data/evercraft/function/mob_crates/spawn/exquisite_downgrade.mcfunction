# Mob Crates - Downgrade Exquisite → cascade through Ornate gate (Dream Rate < 15)
# Barrel already placed by spawn/exquisite.mcfunction or mythical_downgrade cascade

data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"dark_purple"},{text:"An exquisite mob crate dimmed... your dreams aren't strong enough yet.",color:"gray",italic:true},{text:" ✦",color:"dark_purple"}]
scoreboard players set #ndur ec.temp 50
execute as @p[distance=..16] run function evercraft:util/notify/emit_keep
data modify storage evercraft:notify stage.c set value [{text:"Requires ",color:"gray"},{text:"Dream Rate 15",color:"gold",bold:true},{text:" for Exquisite mob crates.",color:"gray"}]
scoreboard players set #ndur ec.temp 40
execute as @p[distance=..16] run function evercraft:util/notify/emit

# Cascade: check if player qualifies for Ornate (Dream Rate >= 5), otherwise Rare (bounded — same player as the gate read)
execute if score @p[distance=..16] ec.temp matches 50.. run function evercraft:mob_crates/spawn/ornate_grant
execute unless score @p[distance=..16] ec.temp matches 50.. run function evercraft:mob_crates/spawn/ornate_downgrade
