# Mob Crates - Spawn Exquisite (Legendary) Crate
# Requires nearest player to have Dream Rate >= 15, otherwise downgrade to Ornate

# Place barrel first — grant/downgrade functions fill it with loot and set name
execute align xyz run setblock ~ ~ ~ minecraft:barrel{lock:{items:"minecraft:air"}}

# Check nearest player's dream rate (bounded ..16 — PATH B runs at the item; ec.temp + cascade reads all use the same player)
execute as @p[distance=..16] store result score @s ec.temp run attribute @s luck get 10
execute if score @p[distance=..16] ec.temp matches 150.. run function evercraft:mob_crates/spawn/exquisite_grant
execute unless score @p[distance=..16] ec.temp matches 150.. run function evercraft:mob_crates/spawn/exquisite_downgrade

# Achievement tracking (bounded — credit the player who earned the crate, not a far bystander)
scoreboard players add @p[distance=..16] ach.crates_mob 1
scoreboard players add @p[distance=..16] ach.crates_opened 1
