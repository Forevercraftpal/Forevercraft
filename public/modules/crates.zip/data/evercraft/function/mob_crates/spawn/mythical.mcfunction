# Mob Crates - Spawn Mythical Crate
# Requires nearest player to have Dream Rate >= 25, otherwise downgrade to Exquisite

# Place barrel first — grant/downgrade functions fill it with loot and set name
execute align xyz run setblock ~ ~ ~ minecraft:barrel{lock:{items:"minecraft:air"}}

# Check nearest player's dream rate (bounded ..16 — PATH B runs at the item; ec.temp + cascade reads all use the same player)
execute as @p[distance=..16] store result score @s ec.temp run attribute @s luck get 10
execute if score @p[distance=..16] ec.temp matches 250.. run function evercraft:mob_crates/spawn/mythical_grant
execute unless score @p[distance=..16] ec.temp matches 250.. run function evercraft:mob_crates/spawn/mythical_downgrade

# Achievement tracking (bounded — credit the player who earned the crate, not a far bystander)
scoreboard players add @p[distance=..16] ach.crates_mob 1
scoreboard players add @p[distance=..16] ach.crates_opened 1
# Watermark — only advance "last mythical opened" on an ACTUAL mythical grant (DR>=250), not on a downgrade (F5)
execute if score @p[distance=..16] ec.temp matches 250.. run scoreboard players operation @p[distance=..16] ec.last_mythical_at = @p[distance=..16] ach.crates_opened
