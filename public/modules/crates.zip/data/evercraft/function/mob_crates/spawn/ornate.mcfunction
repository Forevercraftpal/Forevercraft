# Mob Crates - Spawn Ornate Crate
# Requires nearest player to have Dream Rate >= 5, otherwise downgrade to Rare

# Place barrel first — grant/downgrade functions fill it with loot and set name
execute align xyz run setblock ~ ~ ~ minecraft:barrel{lock:{items:"minecraft:air"}}

# Check nearest player's dream rate (bounded ..16 — PATH B runs at the item; ec.temp + cascade reads all use the same player)
execute as @p[distance=..16] store result score @s ec.temp run attribute @s luck get 10
execute if score @p[distance=..16] ec.temp matches 50.. run function evercraft:mob_crates/spawn/ornate_grant
execute unless score @p[distance=..16] ec.temp matches 50.. run function evercraft:mob_crates/spawn/ornate_downgrade

# Achievement tracking (bounded — credit the player who earned the crate, not a far bystander)
scoreboard players add @p[distance=..16] ach.crates_mob 1
scoreboard players add @p[distance=..16] ach.crates_opened 1
