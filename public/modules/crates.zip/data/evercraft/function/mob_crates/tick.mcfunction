# Mob Crates - Tick Function (self-scheduling, runs every 10 ticks)
# Detects mob crate marker items dropped by rarity mobs and spawns crates

# OPT: Existence-gate — only run the scan when at least one unchecked item exists (no-op on empty tick)
# OPT: Tag-based scan — only check unchecked items (avoids deep NBT scan on ALL items)
execute if entity @e[type=item,tag=!ec.crate_checked,limit=1] as @e[type=item,tag=!ec.crate_checked,limit=10] run function evercraft:mob_crates/check_item

# Self-schedule (0.5s is fast enough — items have pickup_delay anyway)
schedule function evercraft:mob_crates/tick 10t replace
