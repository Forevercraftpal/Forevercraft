# Mob Crates - goat kill (1 in 83 chance)
advancement revoke @s only evercraft:mob_crates/kill/goat
function evercraft:bestiary/track/on_kill {score:"bs.k_goat",dscore:"bs.d_goat",threshold:5000,pow:"#pow17",field:"lo",mob:"goat",smob:"goat",group:2}
data modify storage evercraft:mob_crates chance set value "0.012"
data modify storage evercraft:mob_crates dscore set value "bs.d_goat"
function evercraft:mob_crates/drop/regular with storage evercraft:mob_crates

# Forever Coin — 1/2500 flat chance (no DR scaling)
function evercraft:coins/mob_drop

# Council #4 wire — alchemy visceral reagent roll
function evercraft:craftforever/alchemy/mob_drops/on_kill
