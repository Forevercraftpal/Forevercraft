# Mob Crates - horse kill (1 in 83 chance)
advancement revoke @s only evercraft:mob_crates/kill/horse
data modify storage evercraft:mob_crates chance set value "0.012"
function evercraft:mob_crates/drop/regular with storage evercraft:mob_crates

# Forever Coin — 1/2500 flat chance (no DR scaling)
function evercraft:coins/mob_drop

# Council #4 wire — alchemy visceral reagent roll
function evercraft:craftforever/alchemy/mob_drops/on_kill

# === ADDITIVE: D-MOBDROP Wayfarer's Lens — extremely-rare per-piece drop (Artifact-Fusion w2) ===
data modify storage evercraft:amd args set value {lt:"artifacts/common/travelers_charm",name:"Travelers Charm",color:"white",chance:"0.0002"}
function evercraft:artifacts/give/mob_drop with storage evercraft:amd args
