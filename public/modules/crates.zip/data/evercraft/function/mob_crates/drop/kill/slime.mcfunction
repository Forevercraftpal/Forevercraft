# Mob Crates - slime kill (1 in 42 chance)
advancement revoke @s only evercraft:mob_crates/kill/slime
function evercraft:bestiary/track/on_kill {score:"bs.k_slime",dscore:"bs.d_slime",threshold:5000,pow:"#pow6",field:"hi",mob:"slime",smob:"slime",group:1}
data modify storage evercraft:mob_crates chance set value "0.018"
data modify storage evercraft:mob_crates dscore set value "bs.d_slime"
function evercraft:mob_crates/drop/regular with storage evercraft:mob_crates

# Forever Coin — 1/2500 flat chance (no DR scaling)
function evercraft:coins/mob_drop

# Council #4 wire — alchemy visceral reagent roll
function evercraft:craftforever/alchemy/mob_drops/on_kill

# === ADDITIVE: D-MOBDROP Wayfarer's Lens — extremely-rare per-piece drop (Artifact-Fusion w2) ===
data modify storage evercraft:amd args set value {lt:"artifacts/uncommon/lantern_lichen_clasp",name:"Lantern-Lichen Clasp",color:"blue",chance:"0.0002"}
function evercraft:artifacts/give/mob_drop with storage evercraft:amd args

# === LIVING BOUGH: U12 Greensong (Lumberfell, Wave 29, crown-independent node hook) — a
# forest mob felled IN A TREE grants +1 Iron Resonance. "In a tree" proxy = forest-family
# biome (forest/dark-forest/jungle) + killer above Y60 (the surface-canopy band — excludes
# the sub-Y40 slime-chunk and cave kills that are nowhere near a tree). The victim's own
# perch isn't readable post-mortem (advancement rewards run as the killer). Biome
# predicates are mutually exclusive — one kill never double-grants.
execute if score @s ec.lf_n_u12 matches 1.. store result score #lf_ky ec.temp run data get entity @s Pos[1]
execute if score @s ec.lf_n_u12 matches 1.. if score #lf_ky ec.temp matches 61.. at @s if predicate evercraft:biome/is_forest run function evercraft:bough/mastery/find_xp {cls:"lf",amount:200}
execute if score @s ec.lf_n_u12 matches 1.. if score #lf_ky ec.temp matches 61.. at @s if predicate evercraft:biome/is_dark_forest run function evercraft:bough/mastery/find_xp {cls:"lf",amount:200}
execute if score @s ec.lf_n_u12 matches 1.. if score #lf_ky ec.temp matches 61.. at @s if predicate evercraft:biome/is_jungle run function evercraft:bough/mastery/find_xp {cls:"lf",amount:200}
