# Mob Crates - husk kill (1 in 25 chance)
advancement revoke @s only evercraft:mob_crates/kill/husk
function evercraft:bestiary/track/on_kill {score:"bs.k_husk",dscore:"bs.d_husk",threshold:5000,pow:"#pow20",field:"lo",mob:"husk",smob:"husk",group:1}
data modify storage evercraft:mob_crates chance set value "0.03"
data modify storage evercraft:mob_crates dscore set value "bs.d_husk"
function evercraft:mob_crates/drop/regular with storage evercraft:mob_crates

# Forever Coin — 1/2500 flat chance (no DR scaling)
function evercraft:coins/mob_drop

# Council #4 wire — alchemy visceral reagent roll
function evercraft:craftforever/alchemy/mob_drops/on_kill

# === ADDITIVE: D-MOBDROP Wayfarer's Lens — extremely-rare per-piece drop (Artifact-Fusion w2) ===
data modify storage evercraft:amd args set value {lt:"artifacts/mythical/cartographers_astrolabe",name:"Cartographer's Astrolabe",color:"gold",chance:"0.00007"}
function evercraft:artifacts/give/mob_drop with storage evercraft:amd args

# === LIVING BOUGH: U12 Dustsong (Terrawarp, Wave 29, crown-independent node hook) — a
# husk/zombie felled ON A DIRT PATH grants +1 Iron Resonance. Block read ~ ~-0.5 ~ =
# the SUPPORT block for the 15/16-tall path (the path_speed_tick precedent); read at
# the KILLER (rewards run as the player — the corpse position isn't readable post-mortem).
execute if score @s ec.tw_n_u12 matches 1.. at @s if block ~ ~-0.5 ~ minecraft:dirt_path run function evercraft:bough/mastery/find_xp {cls:"tw",amount:200}
