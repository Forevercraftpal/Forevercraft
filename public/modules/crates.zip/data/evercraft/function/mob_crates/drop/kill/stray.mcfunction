# Mob Crates - stray kill (1 in 25 chance)
advancement revoke @s only evercraft:mob_crates/kill/stray
function evercraft:bestiary/track/on_kill {score:"bs.k_stray",dscore:"bs.d_stray",threshold:5000,pow:"#pow8",field:"hi",mob:"stray",smob:"stray",group:2}
data modify storage evercraft:mob_crates chance set value "0.03"
data modify storage evercraft:mob_crates dscore set value "bs.d_stray"
function evercraft:mob_crates/drop/regular with storage evercraft:mob_crates

# Forever Coin — 1/2500 flat chance (no DR scaling)
function evercraft:coins/mob_drop

# Council #4 wire — alchemy visceral reagent roll
function evercraft:craftforever/alchemy/mob_drops/on_kill

# === ADDITIVE: D-MOBDROP Wayfarer's Lens — extremely-rare per-piece drop (Artifact-Fusion w2) ===
data modify storage evercraft:amd args set value {lt:"artifacts/common/wayworn_tally",name:"Wayworn Tally",color:"white",chance:"0.0002"}
function evercraft:artifacts/give/mob_drop with storage evercraft:amd args
