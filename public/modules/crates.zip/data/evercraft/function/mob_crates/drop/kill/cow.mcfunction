# Mob Crates - cow kill (1 in 83 chance)
advancement revoke @s only evercraft:mob_crates/kill/cow
data modify storage evercraft:mob_crates chance set value "0.012"
function evercraft:mob_crates/drop/regular with storage evercraft:mob_crates

# Forever Coin — 1/2500 flat chance (no DR scaling)
function evercraft:coins/mob_drop

# Council #4 wire — alchemy visceral reagent roll
function evercraft:craftforever/alchemy/mob_drops/on_kill

# === ADDITIVE: D-PASSIVE-MOB Harvest Censer (Cow) — extremely-rare per-piece drop (Artifact-Fusion w2) ===
data modify storage evercraft:amd args set value {lt:"artifacts/rare/harvest_censer",name:"Harvest Censer",color:"aqua",chance:"0.00013"}
function evercraft:artifacts/give/mob_drop with storage evercraft:amd args

# === LIVING BOUGH: U12 Greensong (Growseer, Wave 29, crown-independent node hook) — a
# chicken/cow/pig kill grants +1 Iron Resonance, max 1/day (day-stamp watermark logic
# lives in bough/growseer/u12_kill — one writer, three call sites).
execute if score @s ec.gs_n_u12 matches 1.. run function evercraft:bough/growseer/u12_kill
