# Mob Crates - warden kill (100% chance)
advancement revoke @s only evercraft:mob_crates/kill/warden
function evercraft:bestiary/track/on_kill {score:"bs.k_warden",dscore:"bs.d_warden",threshold:100,pow:"#pow12",field:"hi",mob:"warden",smob:"warden",group:4}
data modify storage evercraft:mob_crates chance set value "1.0"
data modify storage evercraft:mob_crates dscore set value "bs.d_warden"
function evercraft:mob_crates/drop/regular with storage evercraft:mob_crates

# Forever Coin — 1/2500 flat chance (no DR scaling)
function evercraft:coins/mob_drop

# Council #4 wire — alchemy visceral reagent roll
function evercraft:craftforever/alchemy/mob_drops/on_kill

# === ADDITIVE: D-MOBDROP Soulguard Aegis — extremely-rare per-piece drop (Artifact-Fusion w2) ===
data modify storage evercraft:amd args set value {lt:"artifacts/exquisite/warden_totem",name:"Warden Totem",color:"light_purple",chance:"0.0001"}
function evercraft:artifacts/give/mob_drop with storage evercraft:amd args
