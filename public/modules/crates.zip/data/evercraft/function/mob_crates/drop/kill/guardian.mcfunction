# Mob Crates - guardian kill (1 in 17 chance)
advancement revoke @s only evercraft:mob_crates/kill/guardian
function evercraft:bestiary/track/on_kill {score:"bs.k_guardian",dscore:"bs.d_guardian",threshold:5000,pow:"#pow18",field:"lo",mob:"guardian",smob:"guardian",group:3}
data modify storage evercraft:mob_crates chance set value "0.045"
data modify storage evercraft:mob_crates dscore set value "bs.d_guardian"
function evercraft:mob_crates/drop/regular with storage evercraft:mob_crates

# Forever Coin — 1/2500 flat chance (no DR scaling)
function evercraft:coins/mob_drop

# Council #4 wire — alchemy visceral reagent roll
function evercraft:craftforever/alchemy/mob_drops/on_kill

# === ADDITIVE: D-MOBDROP Dragonheart (Fam11/M) — extremely-rare per-piece drop (Artifact-Fusion D2) ===
# (remapped from Enderman — Enderman is Soulguard's mob; distinct-source lock. See DECISIONS.md 2026-06-02.)
data modify storage evercraft:amd args set value {lt:"artifacts/exquisite/enderscale_eye",name:"Enderscale Eye",color:"light_purple",chance:"0.0001"}
function evercraft:artifacts/give/mob_drop with storage evercraft:amd args

# === LIVING BOUGH: U12 Reefsong (Sirencall, Wave 29, crown-independent node hook) —
# killing a guardian/drowned grants +1 Iron Resonance (no biome gate — the node text
# names the mobs only).
execute if score @s ec.sc_n_u12 matches 1.. run function evercraft:bough/mastery/find_xp {cls:"sc",amount:200}
