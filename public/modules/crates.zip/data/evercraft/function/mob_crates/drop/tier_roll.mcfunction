# Mob Crates — shared DR-scaled tier roll + spawn dispatch (reward re-pacing 2026-06-10)
# Run AT the crate-spawn position (executor identity not required — DR is read from the
# nearest player ≤16, same convention as spawn/{ornate,exquisite,mythical}; defaults to the
# base band when no player is in range).
# Sets #mc_tier ec.var (1=common .. 6=mythical) for callers that need it (bestiary bits),
# then spawns the rolled crate at the execution position.
#
#   DR<15 (base): Common 58% · Uncommon 25% · Rare 10% · Ornate 5% · Exquisite 1.5% · Mythical 0.5%
#   DR>=15:       Common 40% · Uncommon 30% · Rare 16% · Ornate 9% · Exquisite 4%   · Mythical 1%
#   DR>=25:       Common 30% · Uncommon 30% · Rare 20% · Ornate 13% · Exquisite 5%  · Mythical 2%
#
# spawn/{ornate,exquisite,mythical} keep their own DR clamps (50/150/250 on luck×10) — the
# shifted splits only re-weight kills for players who have ALREADY unlocked those bands, so
# late-game kills stop paying 58% common while early-game odds are untouched.

execute store result score #mob_tier ec.var run random value 1..1000
scoreboard players set #mc_dr ec.var 0
execute store result score #mc_dr ec.var run attribute @p[distance=..16] luck get 10
scoreboard players set #mc_band ec.var 0
execute if score #mc_dr ec.var matches 150.. run scoreboard players set #mc_band ec.var 1
execute if score #mc_dr ec.var matches 250.. run scoreboard players set #mc_band ec.var 2

# band 0 — base split (58/25/10/5/1.5/0.5)
execute if score #mc_band ec.var matches 0 if score #mob_tier ec.var matches 1..580 run scoreboard players set #mc_tier ec.var 1
execute if score #mc_band ec.var matches 0 if score #mob_tier ec.var matches 581..830 run scoreboard players set #mc_tier ec.var 2
execute if score #mc_band ec.var matches 0 if score #mob_tier ec.var matches 831..930 run scoreboard players set #mc_tier ec.var 3
execute if score #mc_band ec.var matches 0 if score #mob_tier ec.var matches 931..980 run scoreboard players set #mc_tier ec.var 4
execute if score #mc_band ec.var matches 0 if score #mob_tier ec.var matches 981..995 run scoreboard players set #mc_tier ec.var 5
execute if score #mc_band ec.var matches 0 if score #mob_tier ec.var matches 996..1000 run scoreboard players set #mc_tier ec.var 6

# band 1 — DR>=15 split (40/30/16/9/4/1)
execute if score #mc_band ec.var matches 1 if score #mob_tier ec.var matches 1..400 run scoreboard players set #mc_tier ec.var 1
execute if score #mc_band ec.var matches 1 if score #mob_tier ec.var matches 401..700 run scoreboard players set #mc_tier ec.var 2
execute if score #mc_band ec.var matches 1 if score #mob_tier ec.var matches 701..860 run scoreboard players set #mc_tier ec.var 3
execute if score #mc_band ec.var matches 1 if score #mob_tier ec.var matches 861..950 run scoreboard players set #mc_tier ec.var 4
execute if score #mc_band ec.var matches 1 if score #mob_tier ec.var matches 951..990 run scoreboard players set #mc_tier ec.var 5
execute if score #mc_band ec.var matches 1 if score #mob_tier ec.var matches 991..1000 run scoreboard players set #mc_tier ec.var 6

# band 2 — DR>=25 split (30/30/20/13/5/2)
execute if score #mc_band ec.var matches 2 if score #mob_tier ec.var matches 1..300 run scoreboard players set #mc_tier ec.var 1
execute if score #mc_band ec.var matches 2 if score #mob_tier ec.var matches 301..600 run scoreboard players set #mc_tier ec.var 2
execute if score #mc_band ec.var matches 2 if score #mob_tier ec.var matches 601..800 run scoreboard players set #mc_tier ec.var 3
execute if score #mc_band ec.var matches 2 if score #mob_tier ec.var matches 801..930 run scoreboard players set #mc_tier ec.var 4
execute if score #mc_band ec.var matches 2 if score #mob_tier ec.var matches 931..980 run scoreboard players set #mc_tier ec.var 5
execute if score #mc_band ec.var matches 2 if score #mob_tier ec.var matches 981..1000 run scoreboard players set #mc_tier ec.var 6

# dispatch
execute if score #mc_tier ec.var matches 1 run function evercraft:mob_crates/spawn/common
execute if score #mc_tier ec.var matches 2 run function evercraft:mob_crates/spawn/uncommon
execute if score #mc_tier ec.var matches 3 run function evercraft:mob_crates/spawn/rare
execute if score #mc_tier ec.var matches 4 run function evercraft:mob_crates/spawn/ornate
execute if score #mc_tier ec.var matches 5 run function evercraft:mob_crates/spawn/exquisite
execute if score #mc_tier ec.var matches 6 run function evercraft:mob_crates/spawn/mythical
