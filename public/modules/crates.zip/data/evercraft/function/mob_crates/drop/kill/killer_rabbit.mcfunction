# Mob Crates - killer rabbit kill (~30% — elite jackpot for an ultra-rare spawn)
advancement revoke @s only evercraft:mob_crates/kill/killer_rabbit
data modify storage evercraft:mob_crates chance set value "0.3"
function evercraft:mob_crates/drop/regular with storage evercraft:mob_crates

# Forever Coin — 1/2500 flat chance (no DR scaling)
function evercraft:coins/mob_drop

# Council #4 wire — alchemy visceral reagent roll
function evercraft:craftforever/alchemy/mob_drops/on_kill
