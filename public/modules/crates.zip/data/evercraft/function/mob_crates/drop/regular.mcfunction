# Mob Crates - Regular Mob Kill Drop
# Macro function — called with {chance: <float>} from per-mob kill functions
# Debug mode (#debug_mob_drops ec.debug 1) bypasses the random chance roll

# Artifact kill tracking
function evercraft:artifacts/kill_track

# Roll chance — hit-flag form (2026-06-10, affinity scaling). Debug mode = auto-hit.
scoreboard players set #mc_hit ec.var 0
execute if score #debug_mob_drops ec.debug matches 1 run scoreboard players set #mc_hit ec.var 1
$execute unless score #mc_hit ec.var matches 1 if predicate {"condition":"minecraft:random_chance","chance":$(chance)} run scoreboard players set #mc_hit ec.var 1
# Charm 2x: second roll — only when a charm is active and the first missed
$execute unless score #mc_hit ec.var matches 1 if score @s ec.charm_timer matches 1.. if predicate {"condition":"minecraft:random_chance","chance":$(chance)} run scoreboard players set #mc_hit ec.var 1
# COMBAT-CLASS SCALING (Joseph 2026-06-10: crates scale with their class): one more
# base-chance attempt, gated boost% — ec.aff_boost is the HELD class weapon's boost
# (affinity/detect_class; 0 when no class weapon), so the bonus follows the class you
# actually fought with: ~+boost% relative drop rate. Gated by the Treasure Settings
# panel's "Affinity crate scaling" toggle (shared with the mining ss + fishing sc analogues).
scoreboard players set #mc_aff ec.temp 101
execute unless score #mc_hit ec.var matches 1 if score #disable_aff_scale ec.constant matches 0 if score @s ec.aff_boost matches 1.. store result score #mc_aff ec.temp run random value 1..100
$execute unless score #mc_hit ec.var matches 1 if score #mc_aff ec.temp <= @s ec.aff_boost if predicate {"condition":"minecraft:random_chance","chance":$(chance)} run scoreboard players set #mc_hit ec.var 1
execute unless score #mc_hit ec.var matches 1 run return 0

# Tier roll — DR-scaled shared roll (reward re-pacing 2026-06-10; splits documented in tier_roll)
# Sets #mc_tier ec.var (1=common..6=mythical) and spawns the crate at this position.
function evercraft:mob_crates/drop/tier_roll

# Newcomer bonus: 5% chance for an extra common crate (re-pacing 2026-06-10, was 10%)
execute if score @s ec.difficulty matches 1 if predicate {"condition":"minecraft:random_chance","chance":0.05} at @s run function evercraft:mob_crates/spawn/common

# Bestiary — record which crate tier dropped for this mob
# Only runs if dscore was set by the per-mob kill function (bestiary-hooked mobs)
execute unless data storage evercraft:mob_crates dscore run return 0
execute if score #mc_tier ec.var matches 1 run scoreboard players set #bs_tier_bit bs.temp 1
execute if score #mc_tier ec.var matches 2 run scoreboard players set #bs_tier_bit bs.temp 2
execute if score #mc_tier ec.var matches 3 run scoreboard players set #bs_tier_bit bs.temp 4
execute if score #mc_tier ec.var matches 4 run scoreboard players set #bs_tier_bit bs.temp 8
execute if score #mc_tier ec.var matches 5 run scoreboard players set #bs_tier_bit bs.temp 16
execute if score #mc_tier ec.var matches 6 run scoreboard players set #bs_tier_bit bs.temp 32
function evercraft:bestiary/track/on_drop with storage evercraft:mob_crates
data remove storage evercraft:mob_crates dscore
