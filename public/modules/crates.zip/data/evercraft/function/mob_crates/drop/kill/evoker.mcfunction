# Mob Crates - evoker kill (1 in 3 chance)
advancement revoke @s only evercraft:mob_crates/kill/evoker
function evercraft:bestiary/track/on_kill {score:"bs.k_evoker",dscore:"bs.d_evoker",threshold:500,pow:"#pow14",field:"lo",mob:"evoker",smob:"evoker",group:4}
data modify storage evercraft:mob_crates chance set value "0.3"
data modify storage evercraft:mob_crates dscore set value "bs.d_evoker"
function evercraft:mob_crates/drop/regular with storage evercraft:mob_crates

# Forever Coin — 1/2500 flat chance (no DR scaling)
function evercraft:coins/mob_drop

# Council #4 wire — alchemy visceral reagent roll
function evercraft:craftforever/alchemy/mob_drops/on_kill

# === ADDITIVE: D-MOBDROP Wayfarer's Lens — extremely-rare per-piece drop (Artifact-Fusion w2) ===
data modify storage evercraft:amd args set value {lt:"artifacts/mythical/loremasters_omni_codex",name:"Loremaster's Omni-Codex",color:"gold",chance:"0.00007"}
function evercraft:artifacts/give/mob_drop with storage evercraft:amd args
