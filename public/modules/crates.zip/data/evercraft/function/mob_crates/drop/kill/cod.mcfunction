# Fishing Crate - cod kill (uses fishing crate table, not mob crate)
advancement revoke @s only evercraft:mob_crates/kill/cod
function evercraft:fishing/ref/check_crate

# Forever Coin — 1/2500 flat chance (no DR scaling)
function evercraft:coins/mob_drop

# Council #4 wire — alchemy visceral reagent roll
function evercraft:craftforever/alchemy/mob_drops/on_kill
