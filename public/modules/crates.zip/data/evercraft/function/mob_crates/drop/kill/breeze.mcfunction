# Mob Crates - breeze kill (1 in 8 chance)
advancement revoke @s only evercraft:mob_crates/kill/breeze
function evercraft:bestiary/track/on_kill {score:"bs.k_breeze",dscore:"bs.d_breeze",threshold:5000,pow:"#pow3",field:"lo",mob:"breeze",smob:"breeze",group:3}
data modify storage evercraft:mob_crates chance set value "0.09"
data modify storage evercraft:mob_crates dscore set value "bs.d_breeze"
function evercraft:mob_crates/drop/regular with storage evercraft:mob_crates

# Forever Coin — 1/2500 flat chance (no DR scaling)
function evercraft:coins/mob_drop

# Council #4 wire — alchemy visceral reagent roll
function evercraft:craftforever/alchemy/mob_drops/on_kill

# === ADDITIVE: D-MOBDROP Dragonheart (Fam11/M) — extremely-rare per-piece drop (Artifact-Fusion D2) ===
# (remapped from Phantom — Phantom is Soulguard's mob; distinct-source lock. See DECISIONS.md 2026-06-02.)
data modify storage evercraft:amd args set value {lt:"artifacts/exquisite/wyrmwing_membrane",name:"Wyrmwing Membrane",color:"light_purple",chance:"0.0001"}
function evercraft:artifacts/give/mob_drop with storage evercraft:amd args
