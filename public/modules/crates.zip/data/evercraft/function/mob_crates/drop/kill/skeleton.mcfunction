# Mob Crates - skeleton kill (1 in 33 chance)
advancement revoke @s only evercraft:mob_crates/kill/skeleton
function evercraft:bestiary/track/on_kill {score:"bs.k_skeleton",dscore:"bs.d_skeleton",threshold:5000,pow:"#pow5",field:"hi",mob:"skeleton",smob:"skeleton",group:1}
data modify storage evercraft:mob_crates chance set value "0.022"
data modify storage evercraft:mob_crates dscore set value "bs.d_skeleton"
function evercraft:mob_crates/drop/regular with storage evercraft:mob_crates

# Forever Coin — 1/2500 flat chance (no DR scaling)
function evercraft:coins/mob_drop

# Council #4 wire — alchemy visceral reagent roll
function evercraft:craftforever/alchemy/mob_drops/on_kill

# === ADDITIVE: D-MOBDROP Dragonheart (Fam11/M) — extremely-rare per-piece drop (Artifact-Fusion D2) ===
# (remapped from Wither Skeleton — that mob is Soulguard's; distinct-source lock. See DECISIONS.md 2026-06-02.)
data modify storage evercraft:amd args set value {lt:"artifacts/exquisite/dragonbone_talon",name:"Dragonbone Talon",color:"light_purple",chance:"0.0001"}
function evercraft:artifacts/give/mob_drop with storage evercraft:amd args

# === LIVING BOUGH: U12 Veinsong pivot (Stonestrike, Wave 31, 2026-06-12) — pickaxe-kill grant.
execute if score @s ec.ss_n_u12 matches 1.. run function evercraft:bough/stonestrike/u12_kill
