# Mob Crates - endermite kill (1 in 51 chance)
advancement revoke @s only evercraft:mob_crates/kill/endermite
function evercraft:bestiary/track/on_kill {score:"bs.k_endmite",dscore:"bs.d_endmite",threshold:5000,pow:"#pow12",field:"lo",mob:"endermite",smob:"endmite",group:1}
data modify storage evercraft:mob_crates chance set value "0.0198"
data modify storage evercraft:mob_crates dscore set value "bs.d_endmite"
function evercraft:mob_crates/drop/regular with storage evercraft:mob_crates

# Forever Coin — 1/2500 flat chance (no DR scaling)
function evercraft:coins/mob_drop

# Council #4 wire — alchemy visceral reagent roll
function evercraft:craftforever/alchemy/mob_drops/on_kill

# === ADDITIVE: D-MOBDROP Wayfarer's Lens — extremely-rare per-piece drop (Artifact-Fusion w2) ===
data modify storage evercraft:amd args set value {lt:"artifacts/mythical/voyagers_far_lens",name:"Voyager's Far-Lens",color:"gold",chance:"0.00007"}
function evercraft:artifacts/give/mob_drop with storage evercraft:amd args
