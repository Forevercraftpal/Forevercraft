# Mob Crates - zombie kill (1 in 42 chance)
advancement revoke @s only evercraft:mob_crates/kill/zombie
function evercraft:bestiary/track/on_kill {score:"bs.k_zombie",dscore:"bs.d_zombie",threshold:5000,pow:"#pow18",field:"hi",mob:"zombie",smob:"zombie",group:1}
data modify storage evercraft:mob_crates chance set value "0.018"
data modify storage evercraft:mob_crates dscore set value "bs.d_zombie"
function evercraft:mob_crates/drop/regular with storage evercraft:mob_crates

# Forever Coin — 1/2500 flat chance (no DR scaling)
function evercraft:coins/mob_drop

# Council #4 wire — alchemy visceral reagent roll
function evercraft:craftforever/alchemy/mob_drops/on_kill

# === LIVING BOUGH: U12 Dustsong (Terrawarp, Wave 29, crown-independent node hook) — a
# husk/zombie felled ON A DIRT PATH grants +1 Iron Resonance. Block read ~ ~-0.5 ~ =
# the SUPPORT block for the 15/16-tall path (the path_speed_tick precedent); read at
# the KILLER (rewards run as the player — the corpse position isn't readable post-mortem).
execute if score @s ec.tw_n_u12 matches 1.. at @s if block ~ ~-0.5 ~ minecraft:dirt_path run function evercraft:bough/mastery/find_xp {cls:"tw",amount:200}

# === LIVING BOUGH: U12 Veinsong pivot (Stonestrike, Wave 31, 2026-06-12) — pickaxe-kill grant.
# Pivot from "killing a stone golem" (no such mob exists). Cap 5/day.
execute if score @s ec.ss_n_u12 matches 1.. run function evercraft:bough/stonestrike/u12_kill
