# Mob Crates - spider kill (1 in 33 chance)
advancement revoke @s only evercraft:mob_crates/kill/spider
function evercraft:bestiary/track/on_kill {score:"bs.k_spider",dscore:"bs.d_spider",threshold:5000,pow:"#pow7",field:"hi",mob:"spider",smob:"spider",group:1}
data modify storage evercraft:mob_crates chance set value "0.022"
data modify storage evercraft:mob_crates dscore set value "bs.d_spider"
function evercraft:mob_crates/drop/regular with storage evercraft:mob_crates

# Forever Coin — 1/2500 flat chance (no DR scaling)
function evercraft:coins/mob_drop

# Council #4 wire — alchemy visceral reagent roll
function evercraft:craftforever/alchemy/mob_drops/on_kill

# === ADDITIVE: D-MOBDROP Wayfarer's Lens — extremely-rare per-piece drop (Artifact-Fusion w2) ===
data modify storage evercraft:amd args set value {lt:"artifacts/ornate/seers_compass",name:"Seers Compass",color:"dark_purple",chance:"0.00013"}
function evercraft:artifacts/give/mob_drop with storage evercraft:amd args

# === LIVING BOUGH: U12 Greensong (Lumberfell, Wave 29, crown-independent node hook) — a
# forest mob felled IN A TREE grants +1 Iron Resonance. "In a tree" proxy = forest-family
# biome (forest/dark-forest/jungle) + killer above Y60 (the surface-canopy band — excludes
# cave-level kills nowhere near a tree). The victim's own perch isn't readable post-mortem
# (advancement rewards run as the killer).
execute if score @s ec.lf_n_u12 matches 1.. store result score #lf_ky ec.temp run data get entity @s Pos[1]
execute if score @s ec.lf_n_u12 matches 1.. if score #lf_ky ec.temp matches 61.. at @s if predicate evercraft:biome/is_forest run function evercraft:bough/mastery/find_xp {cls:"lf",amount:200}
execute if score @s ec.lf_n_u12 matches 1.. if score #lf_ky ec.temp matches 61.. at @s if predicate evercraft:biome/is_dark_forest run function evercraft:bough/mastery/find_xp {cls:"lf",amount:200}
execute if score @s ec.lf_n_u12 matches 1.. if score #lf_ky ec.temp matches 61.. at @s if predicate evercraft:biome/is_jungle run function evercraft:bough/mastery/find_xp {cls:"lf",amount:200}

# === LIVING BOUGH: U12 Silksong (Lamentor, Wave 29, crown-independent node hook) — a
# spider felled in a CLOTH biome (plains/savanna, the sheep-herding band — the pack's
# "cloth biome" proxy) grants +1 Iron Resonance. Mutually exclusive with the forest
# gates above (biome families don't overlap), so a single kill never double-grants.
execute if score @s ec.lm_n_u12 matches 1.. at @s if predicate evercraft:biome/is_plains run function evercraft:bough/mastery/find_xp {cls:"lm",amount:200}
execute if score @s ec.lm_n_u12 matches 1.. at @s if predicate evercraft:biome/is_savanna run function evercraft:bough/mastery/find_xp {cls:"lm",amount:200}

# === LIVING BOUGH: U12 Veinsong pivot (Stonestrike, Wave 31, 2026-06-12) — pickaxe-kill grant.
execute if score @s ec.ss_n_u12 matches 1.. run function evercraft:bough/stonestrike/u12_kill
