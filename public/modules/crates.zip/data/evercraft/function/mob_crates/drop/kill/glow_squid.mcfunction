# Fishing Crate - glow_squid kill (uses fishing crate table, not mob crate)
advancement revoke @s only evercraft:mob_crates/kill/glow_squid
function evercraft:fishing/ref/check_crate

# Forever Coin — 1/2500 flat chance (no DR scaling)
function evercraft:coins/mob_drop

# Council #4 wire — alchemy visceral reagent roll
function evercraft:craftforever/alchemy/mob_drops/on_kill

# === ADDITIVE: D-MOBDROP Wayfarer's Lens — extremely-rare per-piece drop (Artifact-Fusion w2) ===
data modify storage evercraft:amd args set value {lt:"artifacts/uncommon/glowstone_pendant",name:"Glowstone Pendant",color:"blue",chance:"0.0002"}
function evercraft:artifacts/give/mob_drop with storage evercraft:amd args
