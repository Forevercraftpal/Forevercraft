# Mob Crates - iron_golem kill (1 in 83 chance)
advancement revoke @s only evercraft:mob_crates/kill/iron_golem
function evercraft:bestiary/track/on_kill {score:"bs.k_ironglm",dscore:"bs.d_ironglm",threshold:500,pow:"#pow22",field:"lo",mob:"iron_golem",smob:"ironglm",group:2}
data modify storage evercraft:mob_crates chance set value "0.012"
data modify storage evercraft:mob_crates dscore set value "bs.d_ironglm"
function evercraft:mob_crates/drop/regular with storage evercraft:mob_crates

# Forever Coin — 1/2500 flat chance (no DR scaling)
function evercraft:coins/mob_drop

# Council #4 wire — alchemy visceral reagent roll
function evercraft:craftforever/alchemy/mob_drops/on_kill

# === ADDITIVE: D-MOBDROP Soulguard Aegis — extremely-rare per-piece drop (Artifact-Fusion w2) ===
data modify storage evercraft:amd args set value {lt:"artifacts/uncommon/iron_talisman",name:"Iron Talisman",color:"blue",chance:"0.0002"}
function evercraft:artifacts/give/mob_drop with storage evercraft:amd args

# === LIVING BOUGH: U12 Gearsong (Wave 11 + Wave 29, crown-independent node hook) — ANY
# iron-golem kill grants +1 Iron Resonance (the Wave-29 base half); felled in the Deep Dark
# it ALSO drops +1 redstone block (the golem's heart, returned as mechanism — the Wave-11
# reqlv-70 flourish). /give drops overflow at the feet on a full inventory (the Heartfall
# sapling precedent).
execute if score @s ec.gw_n_u12 matches 1.. run function evercraft:bough/mastery/find_xp {cls:"gw",amount:200}
execute if score @s ec.gw_n_u12 matches 1.. at @s if predicate evercraft:biome/is_deep_dark run give @s minecraft:redstone_block 1
execute if score @s ec.gw_n_u12 matches 1.. at @s if predicate evercraft:biome/is_deep_dark if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.iron_xylophone master @s ~ ~ ~ 0.4 1.0
