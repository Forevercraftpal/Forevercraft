# Mob Crates - cave_spider kill (1 in 25 chance)
advancement revoke @s only evercraft:mob_crates/kill/cave_spider
function evercraft:bestiary/track/on_kill {score:"bs.k_cavespdr",dscore:"bs.d_cavespdr",threshold:5000,pow:"#pow5",field:"lo",mob:"cave_spider",smob:"cavespdr",group:1}
data modify storage evercraft:mob_crates chance set value "0.03"
data modify storage evercraft:mob_crates dscore set value "bs.d_cavespdr"
function evercraft:mob_crates/drop/regular with storage evercraft:mob_crates

# Forever Coin — 1/2500 flat chance (no DR scaling)
function evercraft:coins/mob_drop

# Council #4 wire — alchemy visceral reagent roll
function evercraft:craftforever/alchemy/mob_drops/on_kill

# === ADDITIVE: D-MOBDROP Dragonheart (Fam11/M) — extremely-rare per-piece drop (Artifact-Fusion D2) ===
# (remapped from Ravager — Ravager is Soulguard's mob; distinct-source lock. See DECISIONS.md 2026-06-02.)
data modify storage evercraft:amd args set value {lt:"artifacts/ornate/wyrmtooth_fang",name:"Wyrmtooth Fang",color:"dark_purple",chance:"0.00013"}
function evercraft:artifacts/give/mob_drop with storage evercraft:amd args
