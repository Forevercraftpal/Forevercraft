# Mob Crates - ghast kill (1 in 8 chance)
advancement revoke @s only evercraft:mob_crates/kill/ghast
function evercraft:bestiary/track/on_kill {score:"bs.k_ghast",dscore:"bs.d_ghast",threshold:5000,pow:"#pow16",field:"lo",mob:"ghast",smob:"ghast",group:3}
data modify storage evercraft:mob_crates chance set value "0.09"
data modify storage evercraft:mob_crates dscore set value "bs.d_ghast"
function evercraft:mob_crates/drop/regular with storage evercraft:mob_crates

# Forever Coin — 1/2500 flat chance (no DR scaling)
function evercraft:coins/mob_drop

# Council #4 wire — alchemy visceral reagent roll
function evercraft:craftforever/alchemy/mob_drops/on_kill

# === ADDITIVE: D-MOBDROP Soulguard Aegis — extremely-rare per-piece drop (Artifact-Fusion w2) ===
data modify storage evercraft:amd args set value {lt:"artifacts/mythical/phoenix_totem",name:"Phoenix Totem",color:"gold",chance:"0.00007"}
function evercraft:artifacts/give/mob_drop with storage evercraft:amd args
