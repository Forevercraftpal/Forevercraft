# Mob Crates - hoglin kill (1 in 13 chance)
advancement revoke @s only evercraft:mob_crates/kill/hoglin
function evercraft:bestiary/track/on_kill {score:"bs.k_hoglin",dscore:"bs.d_hoglin",threshold:5000,pow:"#pow19",field:"lo",mob:"hoglin",smob:"hoglin",group:1}
data modify storage evercraft:mob_crates chance set value "0.06"
data modify storage evercraft:mob_crates dscore set value "bs.d_hoglin"
function evercraft:mob_crates/drop/regular with storage evercraft:mob_crates

# Forever Coin — 1/2500 flat chance (no DR scaling)
function evercraft:coins/mob_drop

# Council #4 wire — alchemy visceral reagent roll
function evercraft:craftforever/alchemy/mob_drops/on_kill

# === ADDITIVE: D-MOBDROP Dragonheart (Fam11/M) — extremely-rare per-piece drop (Artifact-Fusion D2) ===
# (remapped from Blaze — Blaze is Soulguard's mob; distinct-source lock. See DECISIONS.md 2026-06-02.)
data modify storage evercraft:amd args set value {lt:"artifacts/rare/cinderclaw_grip",name:"Cinderclaw Grip",color:"aqua",chance:"0.00013"}
function evercraft:artifacts/give/mob_drop with storage evercraft:amd args
