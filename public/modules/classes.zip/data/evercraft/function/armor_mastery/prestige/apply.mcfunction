# Macro: $(slot) = head, chest, legs, or feet
# Prestige the armor piece via hopper minecart
data modify entity @e[type=hopper_minecart,tag=am_temp,limit=1] Items set value []
kill @e[type=hopper_minecart,tag=am_temp]
summon hopper_minecart ~ 320 ~ {Tags:["am_temp"],Items:[]}
$item replace entity @e[type=hopper_minecart,tag=am_temp,limit=1] container.0 from entity @s armor.$(slot)

# Reset XP and level to 0
scoreboard players set #am_zero ec.var 0
scoreboard players set #am_xp ec.var 0
scoreboard players set #am_level ec.var 0
execute store result entity @e[type=hopper_minecart,tag=am_temp,limit=1] Items[0].components."minecraft:custom_data".weapon_xp int 1 run scoreboard players get #am_zero ec.var
execute store result entity @e[type=hopper_minecart,tag=am_temp,limit=1] Items[0].components."minecraft:custom_data".weapon_level int 1 run scoreboard players get #am_zero ec.var

# Increment prestige
scoreboard players add #am_prestige ec.var 1
execute store result entity @e[type=hopper_minecart,tag=am_temp,limit=1] Items[0].components."minecraft:custom_data".weapon_prestige int 1 run scoreboard players get #am_prestige ec.var

# Prestige enchant reconciliation: pure mastery enchants reset to the new floor (they
# regrow as the armor re-levels); the player's own enchants are kept and grow +1 per
# prestige (clamp 10). classify_armor reads current_slot.
$data modify storage evercraft:armor_mastery current_slot set value "$(slot)"
function evercraft:armor_mastery/classify_armor
function evercraft:armor_mastery/prestige/reconcile
# Re-seat mastery enchants at the new floor (level 0 + prestige) so they start at the
# prestige level instead of blank; set_enchant_if_higher leaves kept player enchants alone.
function evercraft:armor_mastery/apply_enchants

# Update mastery lore line (reset to Lv.0 with new prestige)
function evercraft:armor_mastery/get_xp_cost
execute store result storage evercraft:armor_mastery lore.level int 1 run scoreboard players get #am_level ec.var
execute store result storage evercraft:armor_mastery lore.xp int 1 run scoreboard players get #am_xp ec.var
execute store result storage evercraft:armor_mastery lore.cost int 1 run scoreboard players get #am_xp_cost ec.var
execute store result storage evercraft:armor_mastery lore.max_level int 1 run scoreboard players get #am_max_level ec.var
execute store result storage evercraft:armor_mastery lore.prestige int 1 run scoreboard players get #am_prestige ec.var
function evercraft:armor_mastery/update_mastery_lore with storage evercraft:armor_mastery lore

# Copy back to player
$item replace entity @s armor.$(slot) from entity @e[type=hopper_minecart,tag=am_temp,limit=1] container.0
data modify entity @e[type=hopper_minecart,tag=am_temp,limit=1] Items set value []
kill @e[type=hopper_minecart,tag=am_temp]

# Effects
data modify storage evercraft:notify stage.c set value [{text:"PRESTIGE! ",color:"light_purple",bold:true},{text:"(",color:"gold"},{score:{name:"#am_prestige",objective:"ec.var"},color:"gold"},{text:") ",color:"gold"},{text:"Enchantment cap increased! Your armor hungers for more power...",color:"yellow"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 1.0 1.0
execute if score @s ec.fx_vis matches 1.. run particle minecraft:totem_of_undying ~ ~1 ~ 0.5 1 0.5 0.5 100 force @s

# Award Blacksmith's Dreaming Ember (+1 permanent DR) at prestige 3
# Inv-full guard: drop at the player's feet rather than void on a full inventory.
execute store result score #inv_full ec.var run function evercraft:util/check_inv_full
execute if score #am_prestige ec.var matches 3 unless score @s ec.ember_count matches 1.. if score #inv_full ec.var matches 0 run loot give @s loot evercraft:items/blacksmiths_dreaming_ember
execute if score #am_prestige ec.var matches 3 unless score @s ec.ember_count matches 1.. at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:items/blacksmiths_dreaming_ember
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"red"},{text:"Blacksmith's Dreaming Ember",color:"red",bold:true},{text:" received! (+1 Dream Rate)",color:"yellow"},{text:" ✦",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute if score #am_prestige ec.var matches 3 unless score @s ec.ember_count matches 1.. run function evercraft:util/notify/emit