# Prestige enchant reconciliation for the armor piece in am_temp.
# Requires #am_armor_type ec.var (1=head 2=chest 3=legs 4=feet, from classify_armor).
# Pure mastery enchants reset (removed -> regrow from the new floor on re-level); a player-boosted
# level is kept and grown +1 (clamp 10). Manual enchants mastery doesn't grant ride through untouched.
# KEY LISTS BELOW MUST MIRROR evercraft:armor_mastery/enchants/<slot>.

# Ceiling = max_level + OLD prestige. #am_prestige is already incremented here, so subtract 1.
function evercraft:armor_mastery/get_max_level
scoreboard players operation #mr_ceil ec.var = #am_max_level ec.var
scoreboard players operation #mr_ceil ec.var += #am_prestige ec.var
scoreboard players remove #mr_ceil ec.var 1

# --- helmet (head) ---
execute if score #am_armor_type ec.var matches 1 run function evercraft:mastery/prestige_reconcile_key {key:"protection",tag:"am_temp"}
execute if score #am_armor_type ec.var matches 1 run function evercraft:mastery/prestige_reconcile_key {key:"fire_protection",tag:"am_temp"}
execute if score #am_armor_type ec.var matches 1 run function evercraft:mastery/prestige_reconcile_key {key:"blast_protection",tag:"am_temp"}
execute if score #am_armor_type ec.var matches 1 run function evercraft:mastery/prestige_reconcile_key {key:"projectile_protection",tag:"am_temp"}
execute if score #am_armor_type ec.var matches 1 run function evercraft:mastery/prestige_reconcile_key {key:"respiration",tag:"am_temp"}
execute if score #am_armor_type ec.var matches 1 run function evercraft:mastery/prestige_reconcile_key {key:"aqua_affinity",tag:"am_temp"}
execute if score #am_armor_type ec.var matches 1 run function evercraft:mastery/prestige_reconcile_key {key:"thorns",tag:"am_temp"}
execute if score #am_armor_type ec.var matches 1 run function evercraft:mastery/prestige_reconcile_key {key:"mending",tag:"am_temp"}
execute if score #am_armor_type ec.var matches 1 run function evercraft:mastery/prestige_reconcile_key {key:"unbreaking",tag:"am_temp"}

# --- chestplate (chest) ---
execute if score #am_armor_type ec.var matches 2 run function evercraft:mastery/prestige_reconcile_key {key:"protection",tag:"am_temp"}
execute if score #am_armor_type ec.var matches 2 run function evercraft:mastery/prestige_reconcile_key {key:"fire_protection",tag:"am_temp"}
execute if score #am_armor_type ec.var matches 2 run function evercraft:mastery/prestige_reconcile_key {key:"blast_protection",tag:"am_temp"}
execute if score #am_armor_type ec.var matches 2 run function evercraft:mastery/prestige_reconcile_key {key:"projectile_protection",tag:"am_temp"}
execute if score #am_armor_type ec.var matches 2 run function evercraft:mastery/prestige_reconcile_key {key:"thorns",tag:"am_temp"}
execute if score #am_armor_type ec.var matches 2 run function evercraft:mastery/prestige_reconcile_key {key:"mending",tag:"am_temp"}
execute if score #am_armor_type ec.var matches 2 run function evercraft:mastery/prestige_reconcile_key {key:"unbreaking",tag:"am_temp"}

# --- leggings (legs) ---
execute if score #am_armor_type ec.var matches 3 run function evercraft:mastery/prestige_reconcile_key {key:"protection",tag:"am_temp"}
execute if score #am_armor_type ec.var matches 3 run function evercraft:mastery/prestige_reconcile_key {key:"fire_protection",tag:"am_temp"}
execute if score #am_armor_type ec.var matches 3 run function evercraft:mastery/prestige_reconcile_key {key:"blast_protection",tag:"am_temp"}
execute if score #am_armor_type ec.var matches 3 run function evercraft:mastery/prestige_reconcile_key {key:"projectile_protection",tag:"am_temp"}
execute if score #am_armor_type ec.var matches 3 run function evercraft:mastery/prestige_reconcile_key {key:"swift_sneak",tag:"am_temp"}
execute if score #am_armor_type ec.var matches 3 run function evercraft:mastery/prestige_reconcile_key {key:"thorns",tag:"am_temp"}
execute if score #am_armor_type ec.var matches 3 run function evercraft:mastery/prestige_reconcile_key {key:"mending",tag:"am_temp"}
execute if score #am_armor_type ec.var matches 3 run function evercraft:mastery/prestige_reconcile_key {key:"unbreaking",tag:"am_temp"}

# --- boots (feet) ---
execute if score #am_armor_type ec.var matches 4 run function evercraft:mastery/prestige_reconcile_key {key:"protection",tag:"am_temp"}
execute if score #am_armor_type ec.var matches 4 run function evercraft:mastery/prestige_reconcile_key {key:"fire_protection",tag:"am_temp"}
execute if score #am_armor_type ec.var matches 4 run function evercraft:mastery/prestige_reconcile_key {key:"blast_protection",tag:"am_temp"}
execute if score #am_armor_type ec.var matches 4 run function evercraft:mastery/prestige_reconcile_key {key:"projectile_protection",tag:"am_temp"}
execute if score #am_armor_type ec.var matches 4 run function evercraft:mastery/prestige_reconcile_key {key:"feather_falling",tag:"am_temp"}
execute if score #am_armor_type ec.var matches 4 run function evercraft:mastery/prestige_reconcile_key {key:"depth_strider",tag:"am_temp"}
execute if score #am_armor_type ec.var matches 4 run function evercraft:mastery/prestige_reconcile_key {key:"soul_speed",tag:"am_temp"}
execute if score #am_armor_type ec.var matches 4 run function evercraft:mastery/prestige_reconcile_key {key:"thorns",tag:"am_temp"}
execute if score #am_armor_type ec.var matches 4 run function evercraft:mastery/prestige_reconcile_key {key:"mending",tag:"am_temp"}
execute if score #am_armor_type ec.var matches 4 run function evercraft:mastery/prestige_reconcile_key {key:"unbreaking",tag:"am_temp"}
