# Macro: $(slot) = head, chest, legs, or feet
# Awaken armor piece in specified slot (reuses weapon mastery item modifier)
$item modify entity @s armor.$(slot) evercraft:weapon_mastery/awaken

# Lifetime milestone counter: +1 per gear piece awakened (combined weapon+armor tally — see
# weapon_mastery/stones/awaken.mcfunction for the disjoint-writer note). The caller (try_awaken_*)
# gates on `unless ...armor.<slot> ...awakened:1b`, so this only fires on a genuinely new awakening.
scoreboard players add @s ec.wm_maxed 1

# Append mastery lore line to item (so write_back can update lore[-1])
summon hopper_minecart ~ 320 ~ {Tags:["am_temp"],Items:[]}
$item replace entity @e[type=hopper_minecart,tag=am_temp,limit=1] container.0 from entity @s armor.$(slot)
data modify entity @e[type=hopper_minecart,tag=am_temp,limit=1] Items[0].components."minecraft:lore" append value ""
data modify entity @e[type=hopper_minecart,tag=am_temp,limit=1] Items[0].components."minecraft:lore" append value {text:"◆ Mastery: Lv.0 (0/5 XP)",color:"yellow",italic:false}
$item replace entity @s armor.$(slot) from entity @e[type=hopper_minecart,tag=am_temp,limit=1] container.0
data modify entity @e[type=hopper_minecart,tag=am_temp,limit=1] Items set value []
kill @e[type=hopper_minecart,tag=am_temp]

# Feedback
data modify storage evercraft:notify stage.c set value [{text:"Your armor stirs with newfound power!",color:"light_purple"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.enchantment_table.use master @s ~ ~ ~ 1.0 1.5
particle minecraft:enchant ~ ~1 ~ 0.5 0.5 0.5 1 30 force @s