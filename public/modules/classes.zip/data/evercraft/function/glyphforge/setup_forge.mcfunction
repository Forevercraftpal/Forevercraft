# Glyphforge — Setup placed block
# Spawns marker at block center, interaction entity on top, and display overlay

# Stop raycast / fallback scan
tag @s remove ec.searching

# Spawn marker at block center with timer data
summon marker ~0.5 ~ ~0.5 {Tags:["RF.Marker","ec.lodestone_registered"],data:{rf_state:0,rf_rune_id:0,forge_started_at:0L,rf_forger:""}}

# Store color on marker
data modify entity @e[type=marker,tag=RF.Marker,distance=..5,limit=1,sort=nearest] data.color set from storage evercraft:glyphforge temp_color

# Spawn interaction entity on top of block for right-click detection
summon interaction ~0.5 ~1.0 ~0.5 {Tags:["RF.Interact"],width:0.9f,height:0.5f,response:1b}

# Spawn overlay display (anvil texture)
# Default skin (used when no color variant was detected — temp_skin unchanged)
execute unless data storage evercraft:glyphforge {temp_color:"glyphforge_azure"} unless data storage evercraft:glyphforge {temp_color:"glyphforge_crimson"} unless data storage evercraft:glyphforge {temp_color:"glyphforge_solar"} unless data storage evercraft:glyphforge {temp_color:"glyphforge_verdant"} unless data storage evercraft:glyphforge {temp_color:"glyphforge_ivory"} unless data storage evercraft:glyphforge {temp_color:"glyphforge_obsidian"} unless data storage evercraft:glyphforge {temp_color:"glyphforge_rose"} unless data storage evercraft:glyphforge {temp_color:"glyphforge_noir"} run data modify storage evercraft:glyphforge temp_skin set value "ewogICJ0aW1lc3RhbXAiIDogMTc3MzAxNTEzMDc1MiwKICAicHJvZmlsZUlkIiA6ICJkYzA5MjA4MTM2ZDg0Y2Y5OWIwMzFmMGI1NzM4OTdmNSIsCiAgInByb2ZpbGVOYW1lIiA6ICJLRUlUSF8wMzAyIiwKICAic2lnbmF0dXJlUmVxdWlyZWQiIDogdHJ1ZSwKICAidGV4dHVyZXMiIDogewogICAgIlNLSU4iIDogewogICAgICAidXJsIiA6ICJodHRwOi8vdGV4dHVyZXMubWluZWNyYWZ0Lm5ldC90ZXh0dXJlLzhiMjY3Mjg4ZjQ4YjY2YjVmNjg3OWZiNTViZGIzZjMzZWRlZWZmNDcwMTljYzZhYTU0OTQ4MDE0YzUwNTQ0ZjYiCiAgICB9CiAgfQp9"
function evercraft:glyphforge/spawn_display with storage evercraft:glyphforge

# Feedback
data modify storage evercraft:notify stage.c set value [{text:"Glyphforge placed! ",color:"red"},{text:"Right-click to open.",color:"gray"}]
scoreboard players set #ndur ec.temp 45
execute as @p[distance=..8] run function evercraft:util/notify/emit
playsound minecraft:block.anvil.place master @a[distance=..16,scores={ec.fx_snd=1..}] ~ ~ ~ 0.8 0.8
particle minecraft:flame ~0.5 ~1.2 ~0.5 0.3 0.2 0.3 0.02 6
