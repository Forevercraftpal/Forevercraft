# Glyphforge — On Break (lodestone removed)
# Close any open menus and clean up entities

# Close menu for nearby players
execute as @a[distance=..8,tag=RF.InMenu] run function evercraft:glyphforge/gui/close

# Kill interaction entity
execute as @e[type=interaction,tag=RF.Interact,distance=..2] run kill @s

# Kill display overlay (armor_stand + item_display passenger)
execute as @e[type=armor_stand,tag=RF.Stand,distance=..2] run kill @s
execute as @e[type=item_display,tag=RF.Display,distance=..2] run kill @s

# ═══ COLOR-AWARE LOOT DROP ═══
# Kill vanilla lodestone drop
kill @e[type=item,nbt={Item:{id:"minecraft:lodestone"}},distance=..2]

# Drop correct color variant
execute if data entity @s {data:{color:"glyphforge_azure"}} run loot spawn ~ ~0.5 ~ loot evercraft:glyphforge/glyphforge_drop_azure
execute if data entity @s {data:{color:"glyphforge_crimson"}} run loot spawn ~ ~0.5 ~ loot evercraft:glyphforge/glyphforge_drop_crimson
execute if data entity @s {data:{color:"glyphforge_solar"}} run loot spawn ~ ~0.5 ~ loot evercraft:glyphforge/glyphforge_drop_solar
execute if data entity @s {data:{color:"glyphforge_verdant"}} run loot spawn ~ ~0.5 ~ loot evercraft:glyphforge/glyphforge_drop_verdant
execute if data entity @s {data:{color:"glyphforge_ivory"}} run loot spawn ~ ~0.5 ~ loot evercraft:glyphforge/glyphforge_drop_ivory
execute if data entity @s {data:{color:"glyphforge_obsidian"}} run loot spawn ~ ~0.5 ~ loot evercraft:glyphforge/glyphforge_drop_obsidian
execute if data entity @s {data:{color:"glyphforge_rose"}} run loot spawn ~ ~0.5 ~ loot evercraft:glyphforge/glyphforge_drop_rose
execute if data entity @s {data:{color:"glyphforge_noir"}} run loot spawn ~ ~0.5 ~ loot evercraft:glyphforge/glyphforge_drop_noir
execute unless data entity @s {data:{color:"glyphforge_azure"}} unless data entity @s {data:{color:"glyphforge_crimson"}} unless data entity @s {data:{color:"glyphforge_solar"}} unless data entity @s {data:{color:"glyphforge_verdant"}} unless data entity @s {data:{color:"glyphforge_ivory"}} unless data entity @s {data:{color:"glyphforge_obsidian"}} unless data entity @s {data:{color:"glyphforge_rose"}} unless data entity @s {data:{color:"glyphforge_noir"}} run loot spawn ~ ~0.5 ~ loot evercraft:glyphforge/glyphforge_drop

# ═══ GLYPH REFUND (custody — Wiring Audit #51 W1) ═══
# If a glyph is deposited (state 1) or forging (state 2), the real item was consumed
# at deposit (deposit_rune clears it, persisting only the int rf_rune_id on this marker).
# Breaking the lodestone would otherwise destroy it permanently. Re-mint the exact glyph
# back at the marker via its canonical rune loot table so the player can recover it.
# rf_rune_id 1..13 maps 1:1 to evercraft:treasure/runes/<glyph> (same item deposit consumed).
execute store result score #rf_refund ec.temp run data get entity @s data.rf_rune_id
execute if score #rf_refund ec.temp matches 1 run loot spawn ~ ~0.5 ~ loot evercraft:treasure/runes/emberheart
execute if score #rf_refund ec.temp matches 2 run loot spawn ~ ~0.5 ~ loot evercraft:treasure/runes/verdant
execute if score #rf_refund ec.temp matches 3 run loot spawn ~ ~0.5 ~ loot evercraft:treasure/runes/quicksilver
execute if score #rf_refund ec.temp matches 4 run loot spawn ~ ~0.5 ~ loot evercraft:treasure/runes/obsidian
execute if score #rf_refund ec.temp matches 5 run loot spawn ~ ~0.5 ~ loot evercraft:treasure/runes/zephyr
execute if score #rf_refund ec.temp matches 6 run loot spawn ~ ~0.5 ~ loot evercraft:treasure/runes/briar
execute if score #rf_refund ec.temp matches 7 run loot spawn ~ ~0.5 ~ loot evercraft:treasure/runes/stalwart
execute if score #rf_refund ec.temp matches 8 run loot spawn ~ ~0.5 ~ loot evercraft:treasure/runes/gilded
execute if score #rf_refund ec.temp matches 9 run loot spawn ~ ~0.5 ~ loot evercraft:treasure/runes/tidecall
execute if score #rf_refund ec.temp matches 10 run loot spawn ~ ~0.5 ~ loot evercraft:treasure/runes/hearthstone
execute if score #rf_refund ec.temp matches 11 run loot spawn ~ ~0.5 ~ loot evercraft:treasure/runes/prism
execute if score #rf_refund ec.temp matches 12 run loot spawn ~ ~0.5 ~ loot evercraft:treasure/runes/tempest
execute if score #rf_refund ec.temp matches 13 run loot spawn ~ ~0.5 ~ loot evercraft:treasure/runes/arcanum

# Kill this marker
kill @s
