# Glyphforge — Wash Block (right-click with water bucket)
# Removes dye and restores default appearance
# Run as: player, at: interaction entity position

# Reset marker color to default
execute as @e[type=marker,tag=RF.Marker,distance=..2,limit=1] run data modify entity @s data.color set value "glyphforge"

# Reset display skin to default
execute as @e[type=armor_stand,tag=RF.Stand,distance=..2,limit=1] on passengers run data modify entity @s item.components."minecraft:profile".properties[0].value set value "ewogICJ0aW1lc3RhbXAiIDogMTc3MzAxNTEzMDc1MiwKICAicHJvZmlsZUlkIiA6ICJkYzA5MjA4MTM2ZDg0Y2Y5OWIwMzFmMGI1NzM4OTdmNSIsCiAgInByb2ZpbGVOYW1lIiA6ICJLRUlUSF8wMzAyIiwKICAic2lnbmF0dXJlUmVxdWlyZWQiIDogdHJ1ZSwKICAidGV4dHVyZXMiIDogewogICAgIlNLSU4iIDogewogICAgICAidXJsIiA6ICJodHRwOi8vdGV4dHVyZXMubWluZWNyYWZ0Lm5ldC90ZXh0dXJlLzhiMjY3Mjg4ZjQ4YjY2YjVmNjg3OWZiNTViZGIzZjMzZWRlZWZmNDcwMTljYzZhYTU0OTQ4MDE0YzUwNTQ0ZjYiCiAgICB9CiAgfQp9"

# Effects
playsound minecraft:item.bucket.empty master @a[distance=..16,scores={ec.fx_snd=1..}] ~ ~ ~ 1 1.2
particle minecraft:splash ~0.5 ~1.0 ~0.5 0.3 0.2 0.3 0.05 9

# Feedback
data modify storage evercraft:notify stage.c set value [{text:"Washed ",color:"gray",italic:true},{text:"Glyphforge",color:"#E0B0FF",italic:true},{text:" back to default",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
