# Macro — Notify the forger that their glyph is ready to collect
$data modify storage evercraft:notify stage.c set value [{text:"Your ",color:"gold"},{text:"$(glyph) Glyph",color:"yellow",bold:true},{text:" has finished forging! Return to collect it.",color:"gold"}]
scoreboard players set #ndur ec.temp 45
$execute as $(forger) run function evercraft:util/notify/emit
$execute if score $(forger) ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bell master $(forger) ~ ~ ~ 1.0 1.2
$title $(forger) times 5 50 15
$title $(forger) title {text:" "}
$title $(forger) subtitle [{text:"Glyph Forge Complete!",color:"green",bold:true}]

# Gearwright XP (Joseph 2026-06-06): a completed glyph forge is a T4 tinkering act (+7) + a
# first-time-forging-THIS-glyph bonus (+25). Runs as the forger; on_glyph reads $(glyph) from the same notify storage.
$execute as $(forger) run function evercraft:craft_affinity/on_glyph with storage evercraft:glyphforge notify
