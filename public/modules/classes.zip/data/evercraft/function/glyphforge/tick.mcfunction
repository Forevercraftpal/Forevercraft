# Glyphforge — Tick (1s schedule)
# Detect interactions, break detection, ambient particles, forge completion

schedule function evercraft:glyphforge/tick 1s replace

# Perf retrofit M1 (2026-06-14): nothing here matters with nobody online — skip the whole body
# (still reschedules above). Sheds the per-marker scan + interaction sweep on an empty server.
execute unless entity @a run return 0

# Detect right-click on any glyphforge interaction entity
execute as @e[type=interaction,tag=RF.Interact] at @s if data entity @s interaction run function evercraft:glyphforge/on_interact
execute as @e[type=interaction,tag=RF.Interact] at @s if data entity @s interaction run data remove entity @s interaction

# Tick open menus (check clicks, distance)
execute as @a[tag=RF.InMenu] at @s run function evercraft:glyphforge/gui/tick

# OPT: All marker checks (break, forge, particles) consolidated into 1 entity scan (was 6)
# Particles proximity-gated (skip if no player within 48 blocks)
# Perf M1: only run the per-marker scan for markers within 64b of a player — a far structure
# isn't being broken by anyone, so its break-detection needn't run every second.
execute as @e[type=marker,tag=RF.Marker] at @s if entity @a[distance=..64] run function evercraft:glyphforge/tick_marker
