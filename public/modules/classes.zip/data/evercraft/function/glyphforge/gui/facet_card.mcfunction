# Glyphforge GUI — Facet inspect card (macro {f:1|2|3})
# Punching a facet button explains EXACTLY what the deposited glyph does in that
# facet (gui/inspect doctrine: punch = learn, right-click = act). Run as the player.
# Reads @s rf.rune_id (set at open/deposit from the marker).
$scoreboard players set #rf_fc rf.temp $(f)

execute if score #rf_fc rf.temp matches 1 run tellraw @s [{text:"[",color:"dark_gray"},{text:"?",color:"gold"},{text:"] ",color:"dark_gray"},{text:"── ",color:"dark_gray"},{text:"⚔ Offensive Facet",color:"gold",bold:true},{text:" ──",color:"dark_gray"}]
execute if score #rf_fc rf.temp matches 1 if score @s rf.rune_id matches 1 run tellraw @s [{text:"  Bound to the striking edge: +1.5 Attack Damage while equipped.",color:"gray"}]
execute if score #rf_fc rf.temp matches 1 if score @s rf.rune_id matches 2 run tellraw @s [{text:"  Living wood lends its weight: +1 Attack Damage while equipped.",color:"gray"}]
execute if score #rf_fc rf.temp matches 1 if score @s rf.rune_id matches 3 run tellraw @s [{text:"  The metal that never settles: +20% Attack Speed while equipped.",color:"gray"}]
execute if score #rf_fc rf.temp matches 1 if score @s rf.rune_id matches 4 run tellraw @s [{text:"  A dark glass edge, heavier than it looks: +2.5 Attack Damage while equipped.",color:"gray"}]
execute if score #rf_fc rf.temp matches 1 if score @s rf.rune_id matches 5 run tellraw @s [{text:"  The wind leans into every blow: +0.5 Attack Knockback while equipped.",color:"gray"}]
execute if score #rf_fc rf.temp matches 1 if score @s rf.rune_id matches 6 run tellraw @s [{text:"  A barbed edge that bites deeper: +1.5 Attack Damage while equipped.",color:"gray"}]
execute if score #rf_fc rf.temp matches 1 if score @s rf.rune_id matches 7 run tellraw @s [{text:"  An unyielding advance: +2 Attack Damage and +1 Armor while equipped.",color:"gray"}]
execute if score #rf_fc rf.temp matches 1 if score @s rf.rune_id matches 8 run tellraw @s [{text:"  A gold-chased edge: +1 Attack Damage while equipped.",color:"gray"}]
execute if score #rf_fc rf.temp matches 1 if score @s rf.rune_id matches 9 run tellraw @s [{text:"  The tide strikes in sets: +1 Attack Damage and +10% Attack Speed while equipped.",color:"gray"}]
execute if score #rf_fc rf.temp matches 1 if score @s rf.rune_id matches 10 run tellraw @s [{text:"  Hearth-tempered and even-handed: +1 Attack Damage and +1 Armor while equipped.",color:"gray"}]
execute if score #rf_fc rf.temp matches 1 if score @s rf.rune_id matches 11 run tellraw @s [{text:"  Light focused to a point: +1 Attack Damage while equipped.",color:"gray"}]
execute if score #rf_fc rf.temp matches 1 if score @s rf.rune_id matches 12 run tellraw @s [{text:"  The storm front arrives first: +1.5 Attack Damage while equipped.",color:"gray"}]
execute if score #rf_fc rf.temp matches 1 if score @s rf.rune_id matches 13 run tellraw @s [{text:"  Wild forces favor the bold: striking an enemy grants a random brief boon (3s cooldown).",color:"gray"}]

execute if score #rf_fc rf.temp matches 2 run tellraw @s [{text:"[",color:"dark_gray"},{text:"?",color:"gold"},{text:"] ",color:"dark_gray"},{text:"── ",color:"dark_gray"},{text:"🛡 Defensive Facet",color:"gold",bold:true},{text:" ──",color:"dark_gray"}]
execute if score #rf_fc rf.temp matches 2 if score @s rf.rune_id matches 1 run tellraw @s [{text:"  The ember answers fire with fire: any burn on you fades 30% faster.",color:"gray"}]
execute if score #rf_fc rf.temp matches 2 if score @s rf.rune_id matches 2 run tellraw @s [{text:"  Roots hold the body together: +4 Max Health (2 hearts) while equipped.",color:"gray"}]
execute if score #rf_fc rf.temp matches 2 if score @s rf.rune_id matches 3 run tellraw @s [{text:"  Blows slide off a moving target: +20% Knockback Resistance while equipped.",color:"gray"}]
execute if score #rf_fc rf.temp matches 2 if score @s rf.rune_id matches 4 run tellraw @s [{text:"  Cooled lava holds its shape: +2 Armor and +1 Armor Toughness while equipped.",color:"gray"}]
execute if score #rf_fc rf.temp matches 2 if score @s rf.rune_id matches 5 run tellraw @s [{text:"  A pocket of wind breaks the landing: 25% less fall damage while equipped.",color:"gray"}]
execute if score #rf_fc rf.temp matches 2 if score @s rf.rune_id matches 6 run tellraw @s [{text:"  The bramble bites back: +3 Armor, and attackers take a thorn bite in return.",color:"gray"}]
execute if score #rf_fc rf.temp matches 2 if score @s rf.rune_id matches 7 run tellraw @s [{text:"  Planted like a keystone: +2 Armor and +20% Knockback Resistance while equipped.",color:"gray"}]
execute if score #rf_fc rf.temp matches 2 if score @s rf.rune_id matches 8 run tellraw @s [{text:"  Gold-chased plate turns the blow aside: +2 Armor while equipped.",color:"gray"}]
execute if score #rf_fc rf.temp matches 2 if score @s rf.rune_id matches 9 run tellraw @s [{text:"  The sea sustains its own: +6 Max Health (3 hearts) while equipped.",color:"gray"}]
execute if score #rf_fc rf.temp matches 2 if score @s rf.rune_id matches 10 run tellraw @s [{text:"  The warmth of home holds the line: +3 Armor and +1 Armor Toughness while equipped.",color:"gray"}]
execute if score #rf_fc rf.temp matches 2 if score @s rf.rune_id matches 11 run tellraw @s [{text:"  Facets shed the heaviest blows: +5 Armor Toughness while equipped.",color:"gray"}]
execute if score #rf_fc rf.temp matches 2 if score @s rf.rune_id matches 12 run tellraw @s [{text:"  Grounded in the gale: +1 Armor and half of all explosion knockback shrugged off.",color:"gray"}]
execute if score #rf_fc rf.temp matches 2 if score @s rf.rune_id matches 13 run tellraw @s [{text:"  Wild forces flinch on your behalf: being struck grants a random brief ward (8s cooldown).",color:"gray"}]

execute if score #rf_fc rf.temp matches 3 run tellraw @s [{text:"[",color:"dark_gray"},{text:"?",color:"gold"},{text:"] ",color:"dark_gray"},{text:"── ",color:"dark_gray"},{text:"✦ Passive Facet",color:"gold",bold:true},{text:" ──",color:"dark_gray"}]
execute if score #rf_fc rf.temp matches 3 if score @s rf.rune_id matches 1 run tellraw @s [{text:"  Forge-heat runs down the haft: +1 Mining Efficiency while equipped.",color:"gray"}]
execute if score #rf_fc rf.temp matches 3 if score @s rf.rune_id matches 2 run tellraw @s [{text:"  Vines catch what falls: you can drop 2 blocks farther before taking damage.",color:"gray"}]
execute if score #rf_fc rf.temp matches 3 if score @s rf.rune_id matches 3 run tellraw @s [{text:"  Restless hands work faster: +15% Block Break Speed while equipped.",color:"gray"}]
execute if score #rf_fc rf.temp matches 3 if score @s rf.rune_id matches 4 run tellraw @s [{text:"  The dark glass extends the hand: +1 block of reach when placing and breaking.",color:"gray"}]
execute if score #rf_fc rf.temp matches 3 if score @s rf.rune_id matches 5 run tellraw @s [{text:"  A tailwind that never turns: +15% Movement Speed while equipped.",color:"gray"}]
execute if score #rf_fc rf.temp matches 3 if score @s rf.rune_id matches 6 run tellraw @s [{text:"  At home in the undergrowth: +20% movement speed while sneaking.",color:"gray"}]
execute if score #rf_fc rf.temp matches 3 if score @s rf.rune_id matches 7 run tellraw @s [{text:"  A steady stride that ignores small ledges: +0.5 Step Height while equipped.",color:"gray"}]
execute if score #rf_fc rf.temp matches 3 if score @s rf.rune_id matches 8 run tellraw @s [{text:"  Fortune clings to gilded things: +0.5 Dream Rate while equipped.",color:"gray"}]
execute if score #rf_fc rf.temp matches 3 if score @s rf.rune_id matches 9 run tellraw @s [{text:"  The sea makes way: +25% mining speed underwater and +15% swim efficiency.",color:"gray"}]
execute if score #rf_fc rf.temp matches 3 if score @s rf.rune_id matches 10 run tellraw @s [{text:"  A welcoming reach: interact with creatures from 1 block farther away.",color:"gray"}]
execute if score #rf_fc rf.temp matches 3 if score @s rf.rune_id matches 11 run tellraw @s [{text:"  Light finds what hides: hostile creatures within 8 blocks briefly glow, pulsing every 10 seconds.",color:"gray"}]
execute if score #rf_fc rf.temp matches 3 if score @s rf.rune_id matches 12 run tellraw @s [{text:"  Ride the updraft: noticeably higher jumps while equipped.",color:"gray"}]
execute if score #rf_fc rf.temp matches 3 if score @s rf.rune_id matches 13 run tellraw @s [{text:"  Wild forces drift alongside: a small random boon settles on you every 60 seconds.",color:"gray"}]

tellraw @s [{text:"  Right-click this choice to bind it.",color:"dark_gray",italic:true}]
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.hat master @s ~ ~ ~ 0.3 2
