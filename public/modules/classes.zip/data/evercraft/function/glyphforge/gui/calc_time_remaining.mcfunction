# Glyphforge GUI — Calculate remaining forge time (dynamic duration)
# Duration stored on marker as forge_duration (ticks)

# Get current gametime
execute store result score #rf_now rf.timer run time query gametime

# Get forge_started_at from nearest marker
execute store result score #rf_started rf.timer run data get entity @e[type=marker,tag=RF.Marker,distance=..6,limit=1,sort=nearest] data.forge_started_at

# elapsed = now - started
scoreboard players operation #rf_elapsed rf.timer = #rf_now rf.timer
scoreboard players operation #rf_elapsed rf.timer -= #rf_started rf.timer

# Get dynamic forge_duration from marker (instead of hardcoded 216000)
execute store result score #rf_total rf.timer run data get entity @e[type=marker,tag=RF.Marker,distance=..6,limit=1,sort=nearest] data.forge_duration

# remaining = total - elapsed
scoreboard players operation #rf_remaining rf.timer = #rf_total rf.timer
scoreboard players operation #rf_remaining rf.timer -= #rf_elapsed rf.timer

# Check if complete (remaining <= 0) — auto-transition to state 3
execute if score #rf_remaining rf.timer matches ..0 run data modify entity @e[type=marker,tag=RF.Marker,distance=..6,limit=1,sort=nearest] data.rf_state set value 3
execute if score #rf_remaining rf.timer matches ..0 run scoreboard players set @s rf.state 3
execute if score #rf_remaining rf.timer matches ..0 run return 0

# REAL hours = remaining / 72000 (72000 ticks = exactly 1 real hour at 20 tps)
# (2026-06-11 unit fix: the old display called 72000-tick units "days" and 3000-tick
# units "hours" — neither was a real unit. Players now see true wall-clock time.)
scoreboard players operation #rf_hours rf.timer = #rf_remaining rf.timer
scoreboard players set #rf_div rf.timer 72000
scoreboard players operation #rf_hours rf.timer /= #rf_div rf.timer

# remaining_after_hours = remaining - (hours * 72000)
scoreboard players operation #rf_min_ticks rf.timer = #rf_remaining rf.timer
scoreboard players operation #rf_temp rf.timer = #rf_hours rf.timer
scoreboard players operation #rf_temp rf.timer *= #rf_div rf.timer
scoreboard players operation #rf_min_ticks rf.timer -= #rf_temp rf.timer

# REAL minutes = remainder / 1200 (1200 ticks = 1 real minute)
scoreboard players set #rf_div rf.timer 1200
scoreboard players operation #rf_mins rf.timer = #rf_min_ticks rf.timer
scoreboard players operation #rf_mins rf.timer /= #rf_div rf.timer

# Store for macro display
execute store result storage evercraft:glyphforge temp_hours int 1 run scoreboard players get #rf_hours rf.timer
execute store result storage evercraft:glyphforge temp_mins int 1 run scoreboard players get #rf_mins rf.timer

# Update info text with countdown via macro
function evercraft:glyphforge/gui/set_timer_text with storage evercraft:glyphforge
