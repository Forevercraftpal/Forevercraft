# Glyphforge GUI — Shared target validation (TRI-FACET rework 2026-06-11)
# Run as the player (RF.InMenu). Sets #rf_valid rf.temp 1 when the MAINHAND item can
# take the deposited glyph: eligible (#evercraft:glyphable — weapons/armor+shield/tools),
# free glyph capacity, and not already carrying this glyph (any facet).
# Notifies the player on each failure. CALLERS must zero #rf_valid before calling.
# Reads @s rf.rune_id (caller refreshes it from the marker first).

# Eligible equipment?
data modify storage evercraft:notify stage.c set value [{text:"Hold eligible equipment in your mainhand!",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute unless items entity @s weapon.mainhand #evercraft:glyphable run function evercraft:util/notify/emit
execute unless items entity @s weapon.mainhand #evercraft:glyphable run return 0

# --- Tiered multi-glyph capacity (default 1; ornate 3, exquisite 6, mythical 13) ---
scoreboard players set #rf_max rf.temp 1
execute if items entity @s weapon.mainhand *[custom_data~{tier:"ornate"}] run scoreboard players set #rf_max rf.temp 3
execute if items entity @s weapon.mainhand *[custom_data~{tier:"exquisite"}] run scoreboard players set #rf_max rf.temp 6
execute if items entity @s weapon.mainhand *[custom_data~{tier:"mythical"}] run scoreboard players set #rf_max rf.temp 13
scoreboard players set #rf_count rf.temp 0
execute store result score #rf_count rf.temp run data get entity @s SelectedItem.components."minecraft:custom_data".rf_count
data modify storage evercraft:notify stage.c set value [{text:"This item is fully glyphforged!",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute if score #rf_count rf.temp >= #rf_max rf.temp run function evercraft:util/notify/emit
execute if score #rf_count rf.temp >= #rf_max rf.temp run return 0

# --- Duplicate glyph check (same glyph twice, regardless of facet) ---
scoreboard players set #rf_dup rf.temp 0
execute if score @s rf.rune_id matches 1 if items entity @s weapon.mainhand *[custom_data~{rf_emberheart:1b}] run scoreboard players set #rf_dup rf.temp 1
execute if score @s rf.rune_id matches 2 if items entity @s weapon.mainhand *[custom_data~{rf_verdant:1b}] run scoreboard players set #rf_dup rf.temp 1
execute if score @s rf.rune_id matches 3 if items entity @s weapon.mainhand *[custom_data~{rf_quicksilver:1b}] run scoreboard players set #rf_dup rf.temp 1
execute if score @s rf.rune_id matches 4 if items entity @s weapon.mainhand *[custom_data~{rf_obsidian:1b}] run scoreboard players set #rf_dup rf.temp 1
execute if score @s rf.rune_id matches 5 if items entity @s weapon.mainhand *[custom_data~{rf_zephyr:1b}] run scoreboard players set #rf_dup rf.temp 1
execute if score @s rf.rune_id matches 6 if items entity @s weapon.mainhand *[custom_data~{rf_briar:1b}] run scoreboard players set #rf_dup rf.temp 1
execute if score @s rf.rune_id matches 7 if items entity @s weapon.mainhand *[custom_data~{rf_stalwart:1b}] run scoreboard players set #rf_dup rf.temp 1
execute if score @s rf.rune_id matches 8 if items entity @s weapon.mainhand *[custom_data~{rf_gilded:1b}] run scoreboard players set #rf_dup rf.temp 1
execute if score @s rf.rune_id matches 9 if items entity @s weapon.mainhand *[custom_data~{rf_tidecall:1b}] run scoreboard players set #rf_dup rf.temp 1
execute if score @s rf.rune_id matches 10 if items entity @s weapon.mainhand *[custom_data~{rf_hearthstone:1b}] run scoreboard players set #rf_dup rf.temp 1
execute if score @s rf.rune_id matches 11 if items entity @s weapon.mainhand *[custom_data~{rf_prism:1b}] run scoreboard players set #rf_dup rf.temp 1
execute if score @s rf.rune_id matches 12 if items entity @s weapon.mainhand *[custom_data~{rf_tempest:1b}] run scoreboard players set #rf_dup rf.temp 1
execute if score @s rf.rune_id matches 13 if items entity @s weapon.mainhand *[custom_data~{rf_arcanum:1b}] run scoreboard players set #rf_dup rf.temp 1
data modify storage evercraft:notify stage.c set value [{text:"This item already has this glyph!",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute if score #rf_dup rf.temp matches 1 run function evercraft:util/notify/emit
execute if score #rf_dup rf.temp matches 1 run return 0

scoreboard players set #rf_valid rf.temp 1
