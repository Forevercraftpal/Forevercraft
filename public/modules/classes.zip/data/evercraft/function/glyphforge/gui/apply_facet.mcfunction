# Glyphforge GUI — Bind the glyph in the chosen facet — TRI-FACET 2026-06-11
# Run as the player, at their position. Expects: #rf_f rf.temp = 1|2|3 (validated by
# click_facet just before this call), @s rf.rune_id = the deposited glyph.
# This is the old collect tail: item modifier + count + marker reset + fx + records.

# Map rune_id → glyph id string for the macro modifier path (<glyph>_f<facet>)
execute if score @s rf.rune_id matches 1 run data modify storage evercraft:glyphforge bind.g set value "emberheart"
execute if score @s rf.rune_id matches 2 run data modify storage evercraft:glyphforge bind.g set value "verdant"
execute if score @s rf.rune_id matches 3 run data modify storage evercraft:glyphforge bind.g set value "quicksilver"
execute if score @s rf.rune_id matches 4 run data modify storage evercraft:glyphforge bind.g set value "obsidian"
execute if score @s rf.rune_id matches 5 run data modify storage evercraft:glyphforge bind.g set value "zephyr"
execute if score @s rf.rune_id matches 6 run data modify storage evercraft:glyphforge bind.g set value "briar"
execute if score @s rf.rune_id matches 7 run data modify storage evercraft:glyphforge bind.g set value "stalwart"
execute if score @s rf.rune_id matches 8 run data modify storage evercraft:glyphforge bind.g set value "gilded"
execute if score @s rf.rune_id matches 9 run data modify storage evercraft:glyphforge bind.g set value "tidecall"
execute if score @s rf.rune_id matches 10 run data modify storage evercraft:glyphforge bind.g set value "hearthstone"
execute if score @s rf.rune_id matches 11 run data modify storage evercraft:glyphforge bind.g set value "prism"
execute if score @s rf.rune_id matches 12 run data modify storage evercraft:glyphforge bind.g set value "tempest"
execute if score @s rf.rune_id matches 13 run data modify storage evercraft:glyphforge bind.g set value "arcanum"
execute store result storage evercraft:glyphforge bind.f int 1 run scoreboard players get #rf_f rf.temp

# Read current rf_count BEFORE the modifier (the facet modifier merges custom_data)
scoreboard players set #rf_count rf.temp 0
execute store result score #rf_count rf.temp run data get entity @s SelectedItem.components."minecraft:custom_data".rf_count

# Apply the facet modifier (custom_data flags + facet lore line with the effect text)
function evercraft:glyphforge/gui/apply_modifier with storage evercraft:glyphforge bind

# --- Increment rf_count ---
scoreboard players add #rf_count rf.temp 1
execute if score #rf_count rf.temp matches 1 run item modify entity @s weapon.mainhand evercraft:glyphforge/count/1
execute if score #rf_count rf.temp matches 2 run item modify entity @s weapon.mainhand evercraft:glyphforge/count/2
execute if score #rf_count rf.temp matches 3 run item modify entity @s weapon.mainhand evercraft:glyphforge/count/3
execute if score #rf_count rf.temp matches 4 run item modify entity @s weapon.mainhand evercraft:glyphforge/count/4
execute if score #rf_count rf.temp matches 5 run item modify entity @s weapon.mainhand evercraft:glyphforge/count/5
execute if score #rf_count rf.temp matches 6 run item modify entity @s weapon.mainhand evercraft:glyphforge/count/6
execute if score #rf_count rf.temp matches 7 run item modify entity @s weapon.mainhand evercraft:glyphforge/count/7
execute if score #rf_count rf.temp matches 8 run item modify entity @s weapon.mainhand evercraft:glyphforge/count/8
execute if score #rf_count rf.temp matches 9 run item modify entity @s weapon.mainhand evercraft:glyphforge/count/9
execute if score #rf_count rf.temp matches 10 run item modify entity @s weapon.mainhand evercraft:glyphforge/count/10
execute if score #rf_count rf.temp matches 11 run item modify entity @s weapon.mainhand evercraft:glyphforge/count/11
execute if score #rf_count rf.temp matches 12 run item modify entity @s weapon.mainhand evercraft:glyphforge/count/12
execute if score #rf_count rf.temp matches 13 run item modify entity @s weapon.mainhand evercraft:glyphforge/count/13

# Reset marker state (forge bed empty again)
data modify entity @e[type=marker,tag=RF.Marker,distance=..6,limit=1,sort=nearest] data.rf_state set value 0
data modify entity @e[type=marker,tag=RF.Marker,distance=..6,limit=1,sort=nearest] data.rf_rune_id set value 0
data modify entity @e[type=marker,tag=RF.Marker,distance=..6,limit=1,sort=nearest] data.forge_started_at set value 0L
data modify entity @e[type=marker,tag=RF.Marker,distance=..6,limit=1,sort=nearest] data.rf_forger set value ""
scoreboard players set @s rf.state 0
scoreboard players set @s rf.rune_id 0
scoreboard players set @s rf.fsel 0

# Epic effects
playsound minecraft:block.anvil.use master @a[distance=..16,scores={ec.fx_snd=1..}] ~ ~ ~ 0.8 0.8
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.player.levelup master @s ~ ~ ~ 0.5 1.5
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.enchantment_table.use master @s ~ ~ ~ 0.8 1.0
execute if score @s ec.fx_vis matches 1.. run particle minecraft:totem_of_undying ~ ~1 ~ 0.5 0.5 0.5 0.3 19

# Title
title @s times 5 40 10
title @s title {text:" "}
title @s subtitle [{text:"Glyph Bound!",color:"red"}]

execute if score #rf_f rf.temp matches 1 run data modify storage evercraft:notify stage.c set value [{text:"Glyph bound in its ",color:"green"},{text:"⚔ Offensive",color:"#FF6666",bold:true},{text:" facet — check the item's lore!",color:"green"}]
execute if score #rf_f rf.temp matches 2 run data modify storage evercraft:notify stage.c set value [{text:"Glyph bound in its ",color:"green"},{text:"🛡 Defensive",color:"#6699FF",bold:true},{text:" facet — check the item's lore!",color:"green"}]
execute if score #rf_f rf.temp matches 3 run data modify storage evercraft:notify stage.c set value [{text:"Glyph bound in its ",color:"green"},{text:"✦ Passive",color:"#44BB44",bold:true},{text:" facet — check the item's lore!",color:"green"}]
scoreboard players set #ndur ec.temp 60
function evercraft:util/notify/emit

# Track for achievements
scoreboard players add @s ach.runes_forged 1
scoreboard players add #news_glyphs ec.var 1

# Spirit progression: check if all glyph slots are filled
# (runes_forged >= 6 is a reasonable proxy for "all slots filled")
execute if score @s ach.runes_forged matches 6.. run scoreboard players set @s ec.sp_glyphs_full 1
# Check at Exquisite+ tier for the harder objective
execute if score @s ach.runes_forged matches 6.. if score @s ec.sp_tier matches 5.. run scoreboard players set @s ec.sp_glyphs_exq 1

# Apply the effects immediately (don't wait for the next 1s engine tick)
execute if entity @s[tag=!ec.rf_active] run function evercraft:glyphforge/effects/activate

# Close menu
function evercraft:glyphforge/gui/close
