# Glyphforge GUI — Facet choice row (TRI-FACET rework 2026-06-11)
# Run as the player (RF.InMenu), at their position. Replaces the [Collect] button with
# three facet buttons: ⚔ Offensive / 🛡 Defensive / ✦ Passive. The held item's NATURAL
# facet (rf.fnat) renders bold in its facet color; the other two render gray.
# Punch a button = facet_card (the deposited glyph's exact effect in that facet);
# right-click = bind (click_facet — unnatural pairings arm a confirm).
# Layout: ^+x = screen LEFT (menu caret-frame convention); buttons mirror the state-1
# [Start Forging] band at ^1.15/^1.1.

# Remove the [Collect] action row (session-scoped — never touches a neighbor's menu)
scoreboard players operation #gui_check ec.temp = @s adv.gui_session
execute as @e[type=text_display,tag=RF.ForgeText,distance=..7] if score @s adv.gui_session = #gui_check ec.temp run kill @s
execute as @e[type=interaction,tag=RF.ForgeBtn,distance=..7] if score @s adv.gui_session = #gui_check ec.temp run kill @s

# Status + info lines → choice prompt
execute at @s run data modify entity @e[type=text_display,tag=RF.RuneStatus,distance=..7,limit=1] text set value [{text:"Choose the glyph's facet",color:"gold",bold:true}]
execute at @s run data modify entity @e[type=text_display,tag=RF.Info,distance=..7,limit=1] text set value [{text:"Punch a choice to inspect it — right-click to bind",color:"gray"}]

# ⚔ Offensive (screen left, ^+0.85)
execute rotated ~ 0 positioned ^0.85 ^1.15 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["RF.MenuEl","RF.FacetTxt1"],billboard:"center",text:{text:"[ ⚔ Offensive ]",color:"gray"},background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.44f,0.44f,0.44f]}}
# [strip] ?: 0.45w split into 4 x 0.12 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute rotated ~ 0 positioned ^-0.14 ^1.1 ^1.8 positioned ^0.85 ^0 ^0 run summon interaction ~ ~ ~ {Tags:["RF.MenuEl","RF.Facet1"],width:0.12f,height:0.07f,response:1b}
execute rotated ~ 0 positioned ^-0.0467 ^1.1 ^1.8 positioned ^0.85 ^0 ^0 run summon interaction ~ ~ ~ {Tags:["RF.MenuEl","RF.Facet1"],width:0.12f,height:0.07f,response:1b}
execute rotated ~ 0 positioned ^0.0467 ^1.1 ^1.8 positioned ^0.85 ^0 ^0 run summon interaction ~ ~ ~ {Tags:["RF.MenuEl","RF.Facet1"],width:0.12f,height:0.07f,response:1b}
execute rotated ~ 0 positioned ^0.14 ^1.1 ^1.8 positioned ^0.85 ^0 ^0 run summon interaction ~ ~ ~ {Tags:["RF.MenuEl","RF.Facet1"],width:0.12f,height:0.07f,response:1b}

# 🛡 Defensive (center)
execute rotated ~ 0 positioned ^ ^1.15 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["RF.MenuEl","RF.FacetTxt2"],billboard:"center",text:{text:"[ 🛡 Defensive ]",color:"gray"},background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.44f,0.44f,0.44f]}}
execute rotated ~ 0 positioned ^-0.14 ^1.1 ^1.8 run summon interaction ~ ~ ~ {Tags:["RF.MenuEl","RF.Facet2"],width:0.12f,height:0.07f,response:1b}
execute rotated ~ 0 positioned ^-0.0467 ^1.1 ^1.8 run summon interaction ~ ~ ~ {Tags:["RF.MenuEl","RF.Facet2"],width:0.12f,height:0.07f,response:1b}
execute rotated ~ 0 positioned ^0.0467 ^1.1 ^1.8 run summon interaction ~ ~ ~ {Tags:["RF.MenuEl","RF.Facet2"],width:0.12f,height:0.07f,response:1b}
execute rotated ~ 0 positioned ^0.14 ^1.1 ^1.8 run summon interaction ~ ~ ~ {Tags:["RF.MenuEl","RF.Facet2"],width:0.12f,height:0.07f,response:1b}

# ✦ Passive (screen right, ^-0.85)
execute rotated ~ 0 positioned ^-0.85 ^1.15 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["RF.MenuEl","RF.FacetTxt3"],billboard:"center",text:{text:"[ ✦ Passive ]",color:"gray"},background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.44f,0.44f,0.44f]}}
execute rotated ~ 0 positioned ^-0.14 ^1.1 ^1.8 positioned ^-0.85 ^0 ^0 run summon interaction ~ ~ ~ {Tags:["RF.MenuEl","RF.Facet3"],width:0.12f,height:0.07f,response:1b}
execute rotated ~ 0 positioned ^-0.0467 ^1.1 ^1.8 positioned ^-0.85 ^0 ^0 run summon interaction ~ ~ ~ {Tags:["RF.MenuEl","RF.Facet3"],width:0.12f,height:0.07f,response:1b}
execute rotated ~ 0 positioned ^0.0467 ^1.1 ^1.8 positioned ^-0.85 ^0 ^0 run summon interaction ~ ~ ~ {Tags:["RF.MenuEl","RF.Facet3"],width:0.12f,height:0.07f,response:1b}
execute rotated ~ 0 positioned ^0.14 ^1.1 ^1.8 positioned ^-0.85 ^0 ^0 run summon interaction ~ ~ ~ {Tags:["RF.MenuEl","RF.Facet3"],width:0.12f,height:0.07f,response:1b}

# Stamp the newly spawned entities with this menu's session
execute as @e[type=text_display,tag=RF.MenuEl,distance=..7] unless score @s adv.gui_session matches 1.. run scoreboard players operation @s adv.gui_session = #gui_check ec.temp
execute as @e[type=interaction,tag=RF.MenuEl,distance=..7] unless score @s adv.gui_session matches 1.. run scoreboard players operation @s adv.gui_session = #gui_check ec.temp

# Natural-facet highlight (bold, facet color)
scoreboard players operation #rf_nat rf.temp = @s rf.fnat
execute at @s as @e[type=text_display,tag=RF.FacetTxt1,distance=..7] if score @s adv.gui_session = #gui_check ec.temp if score #rf_nat rf.temp matches 1 run data modify entity @s text set value {text:"[ ⚔ Offensive ]",color:"#FF6666",bold:true}
execute at @s as @e[type=text_display,tag=RF.FacetTxt2,distance=..7] if score @s adv.gui_session = #gui_check ec.temp if score #rf_nat rf.temp matches 2 run data modify entity @s text set value {text:"[ 🛡 Defensive ]",color:"#6699FF",bold:true}
execute at @s as @e[type=text_display,tag=RF.FacetTxt3,distance=..7] if score @s adv.gui_session = #gui_check ec.temp if score #rf_nat rf.temp matches 3 run data modify entity @s text set value {text:"[ ✦ Passive ]",color:"#44BB44",bold:true}

execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.4 1.4
