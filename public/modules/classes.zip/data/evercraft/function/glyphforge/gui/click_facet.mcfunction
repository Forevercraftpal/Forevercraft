# Glyphforge GUI — Right-click a facet button (macro {f:1|2|3}) — TRI-FACET 2026-06-11
# Run as the player (RF.InMenu), at their position.
# Natural facet → bind immediately. Unnatural pairing → first click arms a confirm
# (rf.fsel latch + the button turns gold), second click on the SAME button binds.
# Re-validates the held item on every click — it may have changed since the row opened.
$scoreboard players set #rf_f rf.temp $(f)

# Only meaningful while the forge is complete and the choice row is up
execute unless score @s rf.state matches 3 run return 0

# Re-validate the mainhand target (notifies on failure)
scoreboard players set #rf_valid rf.temp 0
function evercraft:glyphforge/gui/validate_target
execute unless score #rf_valid rf.temp matches 1 run return 0

# Natural facet may have changed with the held item — recompute
scoreboard players set @s rf.fnat 3
execute if items entity @s weapon.mainhand #evercraft:glyph_armor run scoreboard players set @s rf.fnat 2
execute if items entity @s weapon.mainhand #evercraft:glyph_weapons run scoreboard players set @s rf.fnat 1

# Natural choice, or this button's confirm already armed → bind now
execute if score @s rf.fnat = #rf_f rf.temp run return run function evercraft:glyphforge/gui/apply_facet
execute if score @s rf.fsel = #rf_f rf.temp run return run function evercraft:glyphforge/gui/apply_facet

# --- Unnatural pairing: arm the confirm on this button ---
scoreboard players operation @s rf.fsel = #rf_f rf.temp

# Reset all three button texts, re-highlight the natural one, then gold the armed one
scoreboard players operation #gui_check ec.temp = @s adv.gui_session
scoreboard players operation #rf_nat rf.temp = @s rf.fnat
execute at @s as @e[type=text_display,tag=RF.FacetTxt1,distance=..7] if score @s adv.gui_session = #gui_check ec.temp run data modify entity @s text set value {text:"[ ⚔ Offensive ]",color:"gray"}
execute at @s as @e[type=text_display,tag=RF.FacetTxt2,distance=..7] if score @s adv.gui_session = #gui_check ec.temp run data modify entity @s text set value {text:"[ 🛡 Defensive ]",color:"gray"}
execute at @s as @e[type=text_display,tag=RF.FacetTxt3,distance=..7] if score @s adv.gui_session = #gui_check ec.temp run data modify entity @s text set value {text:"[ ✦ Passive ]",color:"gray"}
execute at @s as @e[type=text_display,tag=RF.FacetTxt1,distance=..7] if score @s adv.gui_session = #gui_check ec.temp if score #rf_nat rf.temp matches 1 run data modify entity @s text set value {text:"[ ⚔ Offensive ]",color:"#FF6666",bold:true}
execute at @s as @e[type=text_display,tag=RF.FacetTxt2,distance=..7] if score @s adv.gui_session = #gui_check ec.temp if score #rf_nat rf.temp matches 2 run data modify entity @s text set value {text:"[ 🛡 Defensive ]",color:"#6699FF",bold:true}
execute at @s as @e[type=text_display,tag=RF.FacetTxt3,distance=..7] if score @s adv.gui_session = #gui_check ec.temp if score #rf_nat rf.temp matches 3 run data modify entity @s text set value {text:"[ ✦ Passive ]",color:"#44BB44",bold:true}
execute at @s as @e[type=text_display,tag=RF.FacetTxt1,distance=..7] if score @s adv.gui_session = #gui_check ec.temp if score #rf_f rf.temp matches 1 run data modify entity @s text set value {text:"[ ⚔ Click again to bind! ]",color:"gold",bold:true}
execute at @s as @e[type=text_display,tag=RF.FacetTxt2,distance=..7] if score @s adv.gui_session = #gui_check ec.temp if score #rf_f rf.temp matches 2 run data modify entity @s text set value {text:"[ 🛡 Click again to bind! ]",color:"gold",bold:true}
execute at @s as @e[type=text_display,tag=RF.FacetTxt3,distance=..7] if score @s adv.gui_session = #gui_check ec.temp if score #rf_f rf.temp matches 3 run data modify entity @s text set value {text:"[ ✦ Click again to bind! ]",color:"gold",bold:true}

# Cheeky pairing-specific warning (6 unnatural combos)
execute if score #rf_f rf.temp matches 1 if score @s rf.fnat matches 2 run data modify storage evercraft:notify stage.c set value [{text:"An offensive glyph on armor? Bold. ",color:"yellow"},{text:"Click again to confirm.",color:"gray"}]
execute if score #rf_f rf.temp matches 1 if score @s rf.fnat matches 3 run data modify storage evercraft:notify stage.c set value [{text:"An offensive glyph on a humble tool? ",color:"yellow"},{text:"Click again to confirm.",color:"gray"}]
execute if score #rf_f rf.temp matches 2 if score @s rf.fnat matches 1 run data modify storage evercraft:notify stage.c set value [{text:"A defensive glyph on a weapon? Unorthodox. ",color:"yellow"},{text:"Click again to confirm.",color:"gray"}]
execute if score #rf_f rf.temp matches 2 if score @s rf.fnat matches 3 run data modify storage evercraft:notify stage.c set value [{text:"A defensive glyph on a tool? Unorthodox. ",color:"yellow"},{text:"Click again to confirm.",color:"gray"}]
execute if score #rf_f rf.temp matches 3 if score @s rf.fnat matches 1 run data modify storage evercraft:notify stage.c set value [{text:"A passive glyph on a weapon? Waste of an edge? ",color:"yellow"},{text:"Click again to confirm.",color:"gray"}]
execute if score #rf_f rf.temp matches 3 if score @s rf.fnat matches 2 run data modify storage evercraft:notify stage.c set value [{text:"A passive glyph on armor? As you wish. ",color:"yellow"},{text:"Click again to confirm.",color:"gray"}]
scoreboard players set #ndur ec.temp 60
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 0.5 0.8
