# Macro — Display forge started message (REAL time: hours + minutes, 2026-06-11 unit fix)
$data modify storage evercraft:notify stage.c set value [{text:"Your glyph is being forged... Return in ",color:"gold"},{text:"$(forge_hours)h $(forge_mins)m",color:"yellow",bold:true},{text:" (real time)!",color:"gold"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
