# Glyphforge GUI — Set timer display text (macro)
# Displays remaining forge time on the Info text_display — REAL hours + minutes
# (2026-06-11 unit fix: 72000 ticks = 1 real hour; the old "days" label was wrong)

$data modify entity @e[type=text_display,tag=RF.Info,distance=..7,limit=1] text set value [{text:"Time Remaining: ",color:"gold"},{text:"$(temp_hours)h $(temp_mins)m",color:"yellow"},{text:" (real time)",color:"gray"}]
