# Glyphforge GUI — Check Clicks (state-aware)

# Close button (always available)
scoreboard players operation #gui_check ec.temp = @s adv.gui_session
execute as @e[type=interaction,tag=RF.CloseBtn,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction on target run function evercraft:glyphforge/gui/click_close
execute as @e[type=interaction,tag=RF.CloseBtn,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction run data remove entity @s interaction

# Deposit button (state 0 only)
execute as @e[type=interaction,tag=RF.DepositBtn,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction on target run function evercraft:glyphforge/gui/click_deposit
execute as @e[type=interaction,tag=RF.DepositBtn,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction run data remove entity @s interaction

# Forge button — routes based on state
# State 0: no rune, show error
# State 1: start forging
# State 3: collect finished rune
execute as @e[type=interaction,tag=RF.ForgeBtn,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction on target run function evercraft:glyphforge/gui/click_forge
execute as @e[type=interaction,tag=RF.ForgeBtn,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction run data remove entity @s interaction

# Facet choice buttons (state 3, after Collect — TRI-FACET 2026-06-11)
execute as @e[type=interaction,tag=RF.Facet1,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction on target at @s run function evercraft:glyphforge/gui/click_facet {f:1}
execute as @e[type=interaction,tag=RF.Facet1,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=RF.Facet2,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction on target at @s run function evercraft:glyphforge/gui/click_facet {f:2}
execute as @e[type=interaction,tag=RF.Facet2,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=RF.Facet3,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction on target at @s run function evercraft:glyphforge/gui/click_facet {f:3}
execute as @e[type=interaction,tag=RF.Facet3,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction run data remove entity @s interaction

# ===== INSPECT (left-click = what does this button do?) — gui/inspect pattern 2026-06-11 =====
execute as @e[type=interaction,tag=RF.CloseBtn,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Close",b:"Closes the Glyphforge."}
execute as @e[type=interaction,tag=RF.CloseBtn,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=RF.DepositBtn,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Deposit",b:"Sets the glyph you are holding into the forge bed."}
execute as @e[type=interaction,tag=RF.DepositBtn,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=RF.ForgeBtn,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Forge",b:"Starts the forging once a glyph is set — and when the work is done, opens the facet choice: bind the glyph Offensive, Defensive, or Passive. Your call, any item."}
execute as @e[type=interaction,tag=RF.ForgeBtn,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack run data remove entity @s attack
# Facet buttons: punch = the deposited glyph's exact effect in that facet (facet_card)
execute as @e[type=interaction,tag=RF.Facet1,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack on attacker run function evercraft:glyphforge/gui/facet_card {f:1}
execute as @e[type=interaction,tag=RF.Facet1,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=RF.Facet2,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack on attacker run function evercraft:glyphforge/gui/facet_card {f:2}
execute as @e[type=interaction,tag=RF.Facet2,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=RF.Facet3,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack on attacker run function evercraft:glyphforge/gui/facet_card {f:3}
execute as @e[type=interaction,tag=RF.Facet3,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack run data remove entity @s attack
