# Glyphforge GUI — Collect (TRI-FACET rework 2026-06-11)
# The glyph no longer auto-binds on collect. This validates the held target, then
# replaces the [Collect] row with the FACET CHOICE row (⚔ Offensive / 🛡 Defensive /
# ✦ Passive). The bind itself happens in click_facet → apply_facet — an unnatural
# pairing (e.g. an offensive glyph on a fishing rod) asks for a confirming second click.
# Run as player with RF.InMenu tag, at player position.

# Verify state is 3 (forge complete)
data modify storage evercraft:notify stage.c set value [{text:"The forge isn't ready yet!",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute unless score @s rf.state matches 3 run function evercraft:util/notify/emit
execute unless score @s rf.state matches 3 run return 0

# Refresh rune_id from the marker (dup-check + facet cards read it)
execute store result score @s rf.rune_id run data get entity @e[type=marker,tag=RF.Marker,distance=..6,limit=1,sort=nearest] data.rf_rune_id

# Shared validation: eligible + capacity + duplicate (notifies on failure)
scoreboard players set #rf_valid rf.temp 0
function evercraft:glyphforge/gui/validate_target
execute unless score #rf_valid rf.temp matches 1 run return 0

# Natural facet of the held item: 1 weapon / 2 armor+shield / 3 tool
# (weapons checked LAST so axes — in both vanilla mining + our weapon lists — land as weapons)
scoreboard players set @s rf.fnat 3
execute if items entity @s weapon.mainhand #evercraft:glyph_armor run scoreboard players set @s rf.fnat 2
execute if items entity @s weapon.mainhand #evercraft:glyph_weapons run scoreboard players set @s rf.fnat 1

# Clear any stale confirm latch, then show the choice row
scoreboard players set @s rf.fsel 0
function evercraft:glyphforge/gui/open_fsel
