# Glyphforge GUI — Start Forging (dynamic timer based on rune count)
# Run as player with RF.InMenu tag, at player position

# Verify state is 1 (glyph deposited)
execute unless score @s rf.state matches 1 run return 0

# --- Calculate forge duration based on item's current rf_count ---
# Formula: (rf_count + 3) * 72000 ticks. 72000 ticks = exactly 1 REAL HOUR (20 tps),
# so: 1st glyph (rf_count=0) = 3 real hours, 2nd = 4h, ..., 13th (rf_count=12) = 15h —
# before reductions (world event −25%, Mining 15+ −10%, Blacksmith up to −50%).
# (2026-06-11 display fix: the GUI used to call these units "days" — they were never
# days of any kind. All player-facing copy now says hours/minutes, real time.)
scoreboard players set #rf_count rf.temp 0
execute store result score #rf_count rf.temp run data get entity @s SelectedItem.components."minecraft:custom_data".rf_count
scoreboard players add #rf_count rf.temp 3
scoreboard players set #rf_ticks rf.temp 72000
scoreboard players operation #rf_count rf.temp *= #rf_ticks rf.temp
# #rf_count now holds the forge_duration in ticks

# Gathering Pipeline: World event active → 25% forge time reduction
execute if score #we_active ec.var matches 1 run scoreboard players set #rf_mult rf.temp 75
execute if score #we_active ec.var matches 1 run scoreboard players operation #rf_count rf.temp *= #rf_mult rf.temp
execute if score #we_active ec.var matches 1 run scoreboard players operation #rf_count rf.temp /= #100 ec.const
data modify storage evercraft:notify stage.c set value [{text:"Forge time reduced by 25%!",color:"yellow"}]
scoreboard players set #ndur ec.temp 45
execute if score #we_active ec.var matches 1 run function evercraft:util/notify/emit

# Gathering Pipeline: Mining level 15+ → 10% forge time reduction
execute if score @s adv.mining matches 15.. run scoreboard players set #rf_mult rf.temp 90
execute if score @s adv.mining matches 15.. run scoreboard players operation #rf_count rf.temp *= #rf_mult rf.temp
execute if score @s adv.mining matches 15.. run scoreboard players operation #rf_count rf.temp /= #100 ec.const
data modify storage evercraft:notify stage.c set value [{text:"Expert Mining speeds the forge (-10%)",color:"white"}]
scoreboard players set #ndur ec.temp 45
execute if score @s adv.mining matches 15.. run function evercraft:util/notify/emit

# Blacksmith (the forging class): -2% forge time per level, up to -50% at 25
# (Joseph 2026-06-11: "the forging class stuff needs to be able to speed up the
# process of the glyph forging" — multiplicative with the event/mining cuts above)
scoreboard players set #rf_bs rf.temp 0
execute if score @s adv.blacksmith matches 1.. run scoreboard players operation #rf_bs rf.temp = @s adv.blacksmith
execute if score #rf_bs rf.temp matches 26.. run scoreboard players set #rf_bs rf.temp 25
scoreboard players operation #rf_pct rf.temp = #rf_bs rf.temp
scoreboard players operation #rf_pct rf.temp += #rf_bs rf.temp
scoreboard players set #rf_mult rf.temp 100
scoreboard players operation #rf_mult rf.temp -= #rf_pct rf.temp
execute if score #rf_bs rf.temp matches 1.. run scoreboard players operation #rf_count rf.temp *= #rf_mult rf.temp
execute if score #rf_bs rf.temp matches 1.. run scoreboard players operation #rf_count rf.temp /= #100 ec.const
data modify storage evercraft:notify stage.c set value [{text:"Blacksmith hands quicken the forge (-",color:"white"},{score:{name:"#rf_pct",objective:"rf.temp"},color:"gold"},{text:"%)",color:"white"}]
scoreboard players set #ndur ec.temp 45
execute if score #rf_bs rf.temp matches 1.. run function evercraft:util/notify/emit

# Store forge_duration on marker
execute store result storage evercraft:glyphforge temp_duration int 1 run scoreboard players get #rf_count rf.temp
data modify entity @e[type=marker,tag=RF.Marker,distance=..6,limit=1,sort=nearest] data.forge_duration set from storage evercraft:glyphforge temp_duration

# Store current gametime as forge_started_at on the nearest marker
execute store result storage evercraft:glyphforge temp_gametime long 1 run time query gametime
data modify entity @e[type=marker,tag=RF.Marker,distance=..6,limit=1,sort=nearest] data.forge_started_at set from storage evercraft:glyphforge temp_gametime

# Owner-stamp the in-progress forge (Wiring #51): bind THIS forge to its initiator's
# NAME so check_forge_complete's `execute as $(forger)` macro (notify_complete) pings the
# right player, and so two adjacent forges never cross-target their in-progress STATE.
# Collection stays SHARED/open — only the forging-in-progress binding is scoped here.
# rf_forger MUST be a BARE name STRING (a UUID int-array does not stringify to a valid
# `execute as` selector — Wiring #51 CLOSED W2). Capture it via the PROVEN player-head
# profile.name idiom (treasure/database/name/check): run as @s = the player, summon a
# throwaway head item_display, fill it with this player's profile (entity:this = the
# executing player), read its profile.name as a string, then kill the helper.
summon item_display ~ ~ ~ {UUID:[I;0,0,0,2],view_range:0f,width:0f,height:0f,item:{id:"minecraft:player_head",count:1}}
item modify entity 0-0-0-0-2 container.0 {function:fill_player_head,entity:this}
data modify storage evercraft:glyphforge temp_forger set from entity 0-0-0-0-2 item.components.minecraft:profile.name
kill 0-0-0-0-2
data modify entity @e[type=marker,tag=RF.Marker,distance=..6,limit=1,sort=nearest] data.rf_forger set from storage evercraft:glyphforge temp_forger

# Set state to 2 (forging in progress)
data modify entity @e[type=marker,tag=RF.Marker,distance=..6,limit=1,sort=nearest] data.rf_state set value 2
scoreboard players set @s rf.state 2

# Calculate REAL hours + minutes for the display message (72000 ticks = 1 real hour)
scoreboard players operation #rf_hours rf.temp = #rf_count rf.temp
scoreboard players set #rf_div rf.temp 72000
scoreboard players operation #rf_hours rf.temp /= #rf_div rf.temp
scoreboard players operation #rf_mins rf.temp = #rf_count rf.temp
scoreboard players operation #rf_tmp2 rf.temp = #rf_hours rf.temp
scoreboard players operation #rf_tmp2 rf.temp *= #rf_div rf.temp
scoreboard players operation #rf_mins rf.temp -= #rf_tmp2 rf.temp
scoreboard players set #rf_div rf.temp 1200
scoreboard players operation #rf_mins rf.temp /= #rf_div rf.temp

# Effects
playsound minecraft:block.anvil.use master @a[distance=..16,scores={ec.fx_snd=1..}] ~ ~ ~ 0.8 0.6
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.enchantment_table.use master @s ~ ~ ~ 0.8 1.0
particle minecraft:flame ~ ~1 ~ 0.3 0.2 0.3 0.02 8

# Title notification
title @s times 5 40 10
title @s title {text:" "}
title @s subtitle [{text:"Forging Begun!",color:"gold"}]

# Display real hours/minutes via storage macro
execute store result storage evercraft:glyphforge forge_hours int 1 run scoreboard players get #rf_hours rf.temp
execute store result storage evercraft:glyphforge forge_mins int 1 run scoreboard players get #rf_mins rf.temp
function evercraft:glyphforge/gui/forge_started_msg with storage evercraft:glyphforge

# Close menu — forging is hands-off, player should leave
function evercraft:glyphforge/gui/close
