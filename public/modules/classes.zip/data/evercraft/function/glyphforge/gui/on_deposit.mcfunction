# Glyphforge GUI — On Deposit (persist rune to marker, set state 1)
# Called after rune is consumed and rf.rune_id is set

# Store rune_id on the marker for persistence
execute store result storage evercraft:glyphforge temp_rune_id int 1 run scoreboard players get @s rf.rune_id
data modify entity @e[type=marker,tag=RF.Marker,distance=..6,limit=1,sort=nearest] data.rf_rune_id set from storage evercraft:glyphforge temp_rune_id

# Set marker state to 1 (rune deposited)
data modify entity @e[type=marker,tag=RF.Marker,distance=..6,limit=1,sort=nearest] data.rf_state set value 1
scoreboard players set @s rf.state 1

# Sound feedback
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.5 1.2

# --- Re-layout action buttons for state 1 ---
# State 0 spawned [Deposit Glyph] (left) + [Forge] (right). State 1 wants a single
# CENTERED [Start Forging]. Because the deposit transition only refreshes text (never
# re-spawns), the stale [Deposit Glyph] lingered on the left and the right button was
# merely re-texted to [Start Forging] — two wide labels colliding mid-panel. Remove the
# state-0 action buttons (session-scoped so a nearby player's menu is never touched),
# then spawn the centered button so the layout matches a fresh state-1 open.
scoreboard players operation #gui_check ec.temp = @s adv.gui_session
execute as @e[type=text_display,tag=RF.DepositText,distance=..7] if score @s adv.gui_session = #gui_check ec.temp run kill @s
execute as @e[type=interaction,tag=RF.DepositBtn,distance=..7] if score @s adv.gui_session = #gui_check ec.temp run kill @s
execute as @e[type=text_display,tag=RF.ForgeText,distance=..7] if score @s adv.gui_session = #gui_check ec.temp run kill @s
execute as @e[type=interaction,tag=RF.ForgeBtn,distance=..7] if score @s adv.gui_session = #gui_check ec.temp run kill @s

# Spawn centered [Start Forging] button (mirrors the state-1 block in gui/open)
execute at @s rotated ~ 0 positioned ^ ^1.15 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["RF.MenuEl","RF.ForgeText"],billboard:"center",text:{text:"[ Start Forging ]",color:"red",bold:true},background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.473f,0.473f,0.473f]}}
# [strip] ?: 0.5w split into 5 x 0.12 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute at @s rotated ~ 0 positioned ^-0.19 ^1.1 ^1.8 run summon interaction ~ ~ ~ {Tags:["RF.MenuEl","RF.ForgeBtn"],width:0.12f,height:0.07f,response:1b}
execute at @s rotated ~ 0 positioned ^-0.095 ^1.1 ^1.8 run summon interaction ~ ~ ~ {Tags:["RF.MenuEl","RF.ForgeBtn"],width:0.12f,height:0.07f,response:1b}
execute at @s rotated ~ 0 positioned ^0 ^1.1 ^1.8 run summon interaction ~ ~ ~ {Tags:["RF.MenuEl","RF.ForgeBtn"],width:0.12f,height:0.07f,response:1b}
execute at @s rotated ~ 0 positioned ^0.095 ^1.1 ^1.8 run summon interaction ~ ~ ~ {Tags:["RF.MenuEl","RF.ForgeBtn"],width:0.12f,height:0.07f,response:1b}
execute at @s rotated ~ 0 positioned ^0.19 ^1.1 ^1.8 run summon interaction ~ ~ ~ {Tags:["RF.MenuEl","RF.ForgeBtn"],width:0.12f,height:0.07f,response:1b}

# Stamp the newly spawned entities with this menu's session
execute as @e[type=text_display,tag=RF.MenuEl,distance=..7] unless score @s adv.gui_session matches 1.. run scoreboard players operation @s adv.gui_session = #gui_check ec.temp
execute as @e[type=interaction,tag=RF.MenuEl,distance=..7] unless score @s adv.gui_session matches 1.. run scoreboard players operation @s adv.gui_session = #gui_check ec.temp

# Refresh GUI (updates rune-status line, forge button text, etc.)
function evercraft:glyphforge/gui/refresh
