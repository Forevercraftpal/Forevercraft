# Glyphforge GUI — Apply the facet item modifier (macro {g:"<glyph>",f:1|2|3})
# TRI-FACET 2026-06-11. One line instead of 39: the modifier files are generated as
# item_modifier/glyphforge/<glyph>_f<facet>.json (see /tmp/gen_glyph_facets.py — they
# merge {glyphforge:1b, rf_<g>:1b, rf_f_<g>:<f>} and append the facet lore line).
$item modify entity @s weapon.mainhand evercraft:glyphforge/$(g)_f$(f)
