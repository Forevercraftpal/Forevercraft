# Glyphforge — Dye Block (right-click with dye)
# Run as: the interaction entity, at its position
# Called from on_interact when player holds a dye


# Detect which dye the player is holding
execute as @p[distance=..6] run function evercraft:dyeing/detect_color

# Azure
execute if data storage evercraft:dyeing {color_id:"azure"} as @e[type=marker,tag=RF.Marker,distance=..2,limit=1] run data modify entity @s data.color set value "glyphforge_azure"
execute if data storage evercraft:dyeing {color_id:"azure"} as @e[type=armor_stand,tag=RF.Stand,distance=..2,limit=1] on passengers run data modify entity @s item.components."minecraft:profile".properties[0].value set value "ewogICJ0aW1lc3RhbXAiIDogMTc3NDM2OTE5OTY3NiwKICAicHJvZmlsZUlkIiA6ICI1MDMyYTA2NWQ5MWQ0NTgyYjZmODM0MDRlMGYyOTA4MiIsCiAgInByb2ZpbGVOYW1lIiA6ICJNYWNCb29rUHJvTTIiLAogICJzaWduYXR1cmVSZXF1aXJlZCIgOiB0cnVlLAogICJ0ZXh0dXJlcyIgOiB7CiAgICAiU0tJTiIgOiB7CiAgICAgICJ1cmwiIDogImh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvN2UxYmNlYzk0N2NiYjYzZjY0ZWIwNmMxOGJjNTlkMTA4MDJiOTIxMzdhNDA1NTA4NmUzODEwOGM5ZTc1OTI1YiIsCiAgICAgICJtZXRhZGF0YSIgOiB7CiAgICAgICAgIm1vZGVsIiA6ICJzbGltIgogICAgICB9CiAgICB9CiAgfQp9"

# Crimson
execute if data storage evercraft:dyeing {color_id:"crimson"} as @e[type=marker,tag=RF.Marker,distance=..2,limit=1] run data modify entity @s data.color set value "glyphforge_crimson"
execute if data storage evercraft:dyeing {color_id:"crimson"} as @e[type=armor_stand,tag=RF.Stand,distance=..2,limit=1] on passengers run data modify entity @s item.components."minecraft:profile".properties[0].value set value "ewogICJ0aW1lc3RhbXAiIDogMTc3NDM2OTIxMTQ1MiwKICAicHJvZmlsZUlkIiA6ICJhZWY5YmQ1YTIyMTc0NjljODYwZDAzYWE1YWNkNWQwOCIsCiAgInByb2ZpbGVOYW1lIiA6ICJjb3JydXB0ZWRrZXkiLAogICJzaWduYXR1cmVSZXF1aXJlZCIgOiB0cnVlLAogICJ0ZXh0dXJlcyIgOiB7CiAgICAiU0tJTiIgOiB7CiAgICAgICJ1cmwiIDogImh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvMWVlMWU2M2UzN2Y4N2VlYWYwOTYxZjgyYWI4MzgyZTQxYjFkOTM0Y2IxMzRjYTQxZGQ3NDJiOGU2YWZkNGQ0YyIsCiAgICAgICJtZXRhZGF0YSIgOiB7CiAgICAgICAgIm1vZGVsIiA6ICJzbGltIgogICAgICB9CiAgICB9CiAgfQp9"

# Solar
execute if data storage evercraft:dyeing {color_id:"solar"} as @e[type=marker,tag=RF.Marker,distance=..2,limit=1] run data modify entity @s data.color set value "glyphforge_solar"
execute if data storage evercraft:dyeing {color_id:"solar"} as @e[type=armor_stand,tag=RF.Stand,distance=..2,limit=1] on passengers run data modify entity @s item.components."minecraft:profile".properties[0].value set value "ewogICJ0aW1lc3RhbXAiIDogMTc3NDM2OTIyNDE5MiwKICAicHJvZmlsZUlkIiA6ICJjOTQ0MTdlMTY5M2M0NDQyOWNiNDhlMzU2YWE3NWJjNyIsCiAgInByb2ZpbGVOYW1lIiA6ICJBSlhYVEhFQkVBU1QiLAogICJzaWduYXR1cmVSZXF1aXJlZCIgOiB0cnVlLAogICJ0ZXh0dXJlcyIgOiB7CiAgICAiU0tJTiIgOiB7CiAgICAgICJ1cmwiIDogImh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvOTk4NzA1MzNmMTQwYjQ2ODIyZGI2ZmQ4Y2E3YTM5NjgzYTQ0MWYwYjczYzE4NDI5Y2I1Njc4NDU5ZGE1Nzg4MiIsCiAgICAgICJtZXRhZGF0YSIgOiB7CiAgICAgICAgIm1vZGVsIiA6ICJzbGltIgogICAgICB9CiAgICB9CiAgfQp9"

# Verdant
execute if data storage evercraft:dyeing {color_id:"verdant"} as @e[type=marker,tag=RF.Marker,distance=..2,limit=1] run data modify entity @s data.color set value "glyphforge_verdant"
execute if data storage evercraft:dyeing {color_id:"verdant"} as @e[type=armor_stand,tag=RF.Stand,distance=..2,limit=1] on passengers run data modify entity @s item.components."minecraft:profile".properties[0].value set value "ewogICJ0aW1lc3RhbXAiIDogMTc3NDM2OTIzNTg5MSwKICAicHJvZmlsZUlkIiA6ICJhZTQyMTU2N2QzODg0YWUxOTJhNmNiNTY4ZmZkNGZhMiIsCiAgInByb2ZpbGVOYW1lIiA6ICJ0aW1vdGh5ZGVvZG9yYW50IiwKICAic2lnbmF0dXJlUmVxdWlyZWQiIDogdHJ1ZSwKICAidGV4dHVyZXMiIDogewogICAgIlNLSU4iIDogewogICAgICAidXJsIiA6ICJodHRwOi8vdGV4dHVyZXMubWluZWNyYWZ0Lm5ldC90ZXh0dXJlLzdkY2I5MWUxZDZhMzIyNDRlZTM5ZDc5OTlmMjQ4MTExNjA3NTZjY2UyNTZmYzJjMTM5OTRjODZkNzBiNTg5MzYiLAogICAgICAibWV0YWRhdGEiIDogewogICAgICAgICJtb2RlbCIgOiAic2xpbSIKICAgICAgfQogICAgfQogIH0KfQ=="

# Ivory
execute if data storage evercraft:dyeing {color_id:"ivory"} as @e[type=marker,tag=RF.Marker,distance=..2,limit=1] run data modify entity @s data.color set value "glyphforge_ivory"
execute if data storage evercraft:dyeing {color_id:"ivory"} as @e[type=armor_stand,tag=RF.Stand,distance=..2,limit=1] on passengers run data modify entity @s item.components."minecraft:profile".properties[0].value set value "ewogICJ0aW1lc3RhbXAiIDogMTc3NDM2OTI0ODc2NSwKICAicHJvZmlsZUlkIiA6ICJkMWU5ODViZGYyMTg0OWQwYmFlZTNlYjBiNDM2ZmExYiIsCiAgInByb2ZpbGVOYW1lIiA6ICJSb3NleUNoYW40MjAiLAogICJzaWduYXR1cmVSZXF1aXJlZCIgOiB0cnVlLAogICJ0ZXh0dXJlcyIgOiB7CiAgICAiU0tJTiIgOiB7CiAgICAgICJ1cmwiIDogImh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvOWJlYzQ0OGE4ODRlNzJlYjdhYzgzMzJlZmE4MWY1OWZjYTBiNTE5ZGM2NTMwZmI4MGU5ZTdlNGUyMGQ0ODNkZSIsCiAgICAgICJtZXRhZGF0YSIgOiB7CiAgICAgICAgIm1vZGVsIiA6ICJzbGltIgogICAgICB9CiAgICB9CiAgfQp9"

# Obsidian
execute if data storage evercraft:dyeing {color_id:"obsidian"} as @e[type=marker,tag=RF.Marker,distance=..2,limit=1] run data modify entity @s data.color set value "glyphforge_obsidian"
execute if data storage evercraft:dyeing {color_id:"obsidian"} as @e[type=armor_stand,tag=RF.Stand,distance=..2,limit=1] on passengers run data modify entity @s item.components."minecraft:profile".properties[0].value set value "ewogICJ0aW1lc3RhbXAiIDogMTc3NDM2OTI2MTgwOCwKICAicHJvZmlsZUlkIiA6ICIwNTljODIxYzhhODU0NGJiOWJiODVhOGMxNjVhYTc5YiIsCiAgInByb2ZpbGVOYW1lIiA6ICJoZWxsc3RydWNrZWR6IiwKICAic2lnbmF0dXJlUmVxdWlyZWQiIDogdHJ1ZSwKICAidGV4dHVyZXMiIDogewogICAgIlNLSU4iIDogewogICAgICAidXJsIiA6ICJodHRwOi8vdGV4dHVyZXMubWluZWNyYWZ0Lm5ldC90ZXh0dXJlL2VkOWM2NGQ1YTg0OWNjYmU5N2U1YjJhOTRjMGI2MmI3MmJmMjMwNGRmNGFmMTZmNjQ1NGFiNmQ3NjBjMGY3ZDMiLAogICAgICAibWV0YWRhdGEiIDogewogICAgICAgICJtb2RlbCIgOiAic2xpbSIKICAgICAgfQogICAgfQogIH0KfQ=="

# Rose
execute if data storage evercraft:dyeing {color_id:"rose"} as @e[type=marker,tag=RF.Marker,distance=..2,limit=1] run data modify entity @s data.color set value "glyphforge_rose"
execute if data storage evercraft:dyeing {color_id:"rose"} as @e[type=armor_stand,tag=RF.Stand,distance=..2,limit=1] on passengers run data modify entity @s item.components."minecraft:profile".properties[0].value set value "ewogICJ0aW1lc3RhbXAiIDogMTc3NDM2OTI3NTA4NCwKICAicHJvZmlsZUlkIiA6ICI1ODAwZjIzNWQyYjQ0MDc5OTcxZTM3ZDhmNmY0OTc2ZiIsCiAgInByb2ZpbGVOYW1lIiA6ICJYZW55cmlhIiwKICAic2lnbmF0dXJlUmVxdWlyZWQiIDogdHJ1ZSwKICAidGV4dHVyZXMiIDogewogICAgIlNLSU4iIDogewogICAgICAidXJsIiA6ICJodHRwOi8vdGV4dHVyZXMubWluZWNyYWZ0Lm5ldC90ZXh0dXJlLzRkMGMxN2QwN2JiYjMzMDM4Yjg0ZDMxYTNkYTk4NWRkNTY5ZTAzMDI3ZDVmZjlkMjk2OGM4NTI1OTM4MzMxZCIsCiAgICAgICJtZXRhZGF0YSIgOiB7CiAgICAgICAgIm1vZGVsIiA6ICJzbGltIgogICAgICB9CiAgICB9CiAgfQp9"

# Noir
execute if data storage evercraft:dyeing {color_id:"noir"} as @e[type=marker,tag=RF.Marker,distance=..2,limit=1] run data modify entity @s data.color set value "glyphforge_noir"
execute if data storage evercraft:dyeing {color_id:"noir"} as @e[type=armor_stand,tag=RF.Stand,distance=..2,limit=1] on passengers run data modify entity @s item.components."minecraft:profile".properties[0].value set value "ewogICJ0aW1lc3RhbXAiIDogMTc3NDM2OTI4Njk3MSwKICAicHJvZmlsZUlkIiA6ICJlMjc5NjliODYyNWY0NDg1YjkyNmM5NTBhMDljMWMwMSIsCiAgInByb2ZpbGVOYW1lIiA6ICJNaVp6YVgwIiwKICAic2lnbmF0dXJlUmVxdWlyZWQiIDogdHJ1ZSwKICAidGV4dHVyZXMiIDogewogICAgIlNLSU4iIDogewogICAgICAidXJsIiA6ICJodHRwOi8vdGV4dHVyZXMubWluZWNyYWZ0Lm5ldC90ZXh0dXJlLzRmMjI2ZjU4OWNjYWIxYTU1MDg3ZjVlMGQyNWIxMGQzZjFlZDcyMjdjYWJhYjVjYTY2ZDRhZTExZWFiOTM3NGMiLAogICAgICAibWV0YWRhdGEiIDogewogICAgICAgICJtb2RlbCIgOiAic2xpbSIKICAgICAgfQogICAgfQogIH0KfQ=="

# Consume 1 dye from player's hand
execute as @p[distance=..6] run item modify entity @s weapon.mainhand {"function":"minecraft:set_count","count":-1,"add":true}

# Effects
function evercraft:dyeing/effects

# Feedback
data modify storage evercraft:notify stage.c set value [{text:"Dyed ",color:"gray",italic:true},{storage:"evercraft:dyeing",nbt:"color_name",interpret:false,color:"#E0B0FF",italic:true},{text:" Glyphforge",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 45
execute as @p[distance=..6] run function evercraft:util/notify/emit
