# Glyphforge Effects — Tick (1s schedule) — TRI-FACET rework 2026-06-11
# Activation now covers EVERY equipped slot: mainhand, worn armor, offhand SHIELD
# (offhand is shield-only — no dual-wield glyph stacking). Facet-aware apply runs
# every second for active players (the old mainhand-slot dirty flag can't see armor
# swaps; active players are few and player_tick already dwarfs this cost).

execute unless entity @a run return run schedule function evercraft:glyphforge/effects/tick 1s replace

# Players with a glyphforged item equipped anywhere: tag + apply (one call max via the !ec.rf_active guard)
execute as @a[tag=!ec.rf_active] if items entity @s weapon.mainhand *[custom_data~{glyphforge:1b}] run function evercraft:glyphforge/effects/activate
execute as @a[tag=!ec.rf_active] if items entity @s armor.* *[custom_data~{glyphforge:1b}] run function evercraft:glyphforge/effects/activate
execute as @a[tag=!ec.rf_active] if items entity @s weapon.offhand minecraft:shield[custom_data~{glyphforge:1b}] run function evercraft:glyphforge/effects/activate

# Players who HAD glyphforge modifiers but unequipped everything: strip only
execute as @a[tag=ec.rf_was_active,tag=!ec.rf_active] run function evercraft:glyphforge/effects/strip

# Hearthstone Glyph: Pet Warp Strike — the glyph's signature, fires in ANY facet
# from any equipped slot (one call per player per tick via the ec.rf_hs gate)
execute as @a[tag=ec.rf_active] if items entity @s weapon.mainhand *[custom_data~{rf_hearthstone:1b}] run tag @s add ec.rf_hs
execute as @a[tag=ec.rf_active,tag=!ec.rf_hs] if items entity @s armor.* *[custom_data~{rf_hearthstone:1b}] run tag @s add ec.rf_hs
execute as @a[tag=ec.rf_active,tag=!ec.rf_hs] if items entity @s weapon.offhand minecraft:shield[custom_data~{rf_hearthstone:1b}] run tag @s add ec.rf_hs
execute as @a[tag=ec.rf_hs] at @s run function evercraft:glyphforge/effects/hearthstone_tick
tag @a[tag=ec.rf_hs] remove ec.rf_hs

# Passive-facet procs (Prism ✦ reveal pulse / Arcanum ✦ periodic boon) — paced by a
# per-player counter that only runs while glyph-active
scoreboard players add @a[tag=ec.rf_active] rf.ptime 1
execute as @a[tag=ec.rf_active] at @s run function evercraft:glyphforge/effects/passive_tick

# Update state: current holders get was_active for next tick
tag @a[tag=ec.rf_was_active] remove ec.rf_was_active
tag @a[tag=ec.rf_active] add ec.rf_was_active
tag @a[tag=ec.rf_active] remove ec.rf_active

schedule function evercraft:glyphforge/effects/tick 1s replace
