# Glyphforge Effects — Arcanum ✦ periodic boon (run as glyph-active player, at @s)
# TRI-FACET 2026-06-11. Called from passive_tick every second (it gates on the 60s
# beat itself so the prism return-split never starves it). Wild Forces as a drift:
# a small random boon every 60 seconds while an Arcanum ✦ item is equipped.

scoreboard players set #rf_m60 rf.timer 60
scoreboard players operation #rf_mod rf.timer = @s rf.ptime
scoreboard players operation #rf_mod rf.timer %= #rf_m60 rf.timer
execute unless score #rf_mod rf.timer matches 0 run return 0

execute if items entity @s weapon.mainhand *[custom_data~{rf_f_arcanum:3}] run tag @s add ec.rf_ar
execute if entity @s[tag=!ec.rf_ar] if items entity @s armor.* *[custom_data~{rf_f_arcanum:3}] run tag @s add ec.rf_ar
execute if entity @s[tag=!ec.rf_ar] if items entity @s weapon.offhand minecraft:shield[custom_data~{rf_f_arcanum:3}] run tag @s add ec.rf_ar
execute unless entity @s[tag=ec.rf_ar] run return 0
tag @s remove ec.rf_ar

# Roll one of 4 small boons (8s, amp 0)
execute store result score #rf_arc_roll ec.temp run random value 1..4
execute if score #rf_arc_roll ec.temp matches 1 run effect give @s speed 8 0 true
execute if score #rf_arc_roll ec.temp matches 2 run effect give @s haste 8 0 true
execute if score #rf_arc_roll ec.temp matches 3 run effect give @s regeneration 8 0 true
execute if score #rf_arc_roll ec.temp matches 4 run effect give @s absorption 8 0 true

# Subtle drift feedback
execute if score @s ec.fx_vis matches 1.. run particle minecraft:witch ~ ~1 ~ 0.3 0.5 0.3 0.05 4
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.3 1.2
