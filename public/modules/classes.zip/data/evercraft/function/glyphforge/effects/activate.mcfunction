# Glyphforge Effects — Activate — TRI-FACET rework 2026-06-11
# Tag + full facet-aware apply. Guarded by tick's @a[tag=!ec.rf_active] selectors so it
# runs at most once per player per engine tick (the old mainhand dirty-flag/check_apply
# is retired — it couldn't see armor swaps; apply is idempotent and cheap at this scale).
tag @s add ec.rf_active
function evercraft:glyphforge/effects/apply
