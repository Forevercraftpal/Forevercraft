# Glyphforge Effects — Apply per-player (TRI-FACET rework 2026-06-11)
# Strip all glyph modifiers, then re-apply from EVERY equipped slot:
#   mainhand (held), armor.* (worn), offhand SHIELD only (no dual-wield stacking).
# Facet field rf_f_<glyph>: 1=Offensive 2=Defensive 3=Passive — chosen at the forge.
# LEGACY items (forged before facets, no rf_f_ field) keep their old effect: the
# glyph's legacy-facet block below also fires on a mainhand item that has the rf_
# flag but NO facet field (3 unless-clauses). Legacy uses the SAME modifier id as
# its facet twin, so an item carrying both forms can never double-stack.
# The same glyph+facet on two worn pieces does NOT stack (same modifier id; the
# second add is a silent no-op) — one echo per glyph per facet.
# Proc-only facets (Briar D thorns, Prism P reveal, Arcanum O/D/P) live in the
# advancement handlers + tick — no attribute lines here.

# Strip all modifiers first (includes pre-facet legacy ids)
function evercraft:glyphforge/effects/strip

# Emberheart Offensive — +1.5 Attack Damage
execute if items entity @s weapon.mainhand *[custom_data~{rf_f_emberheart:1}] run tag @s add ec.rfx
execute if items entity @s armor.* *[custom_data~{rf_f_emberheart:1}] run tag @s add ec.rfx
execute if items entity @s weapon.offhand minecraft:shield[custom_data~{rf_f_emberheart:1}] run tag @s add ec.rfx
# legacy (pre-facet) Emberheart item in mainhand — same effect, same modifier ids
execute if items entity @s weapon.mainhand *[custom_data~{rf_emberheart:1b}] unless items entity @s weapon.mainhand *[custom_data~{rf_f_emberheart:1}] unless items entity @s weapon.mainhand *[custom_data~{rf_f_emberheart:2}] unless items entity @s weapon.mainhand *[custom_data~{rf_f_emberheart:3}] run tag @s add ec.rfx
execute if entity @s[tag=ec.rfx] run attribute @s attack_damage modifier add ec_rf_emberheart_f1 1.5 add_value
tag @s remove ec.rfx

# Emberheart Defensive — Burns fade 30% faster
execute if items entity @s weapon.mainhand *[custom_data~{rf_f_emberheart:2}] run tag @s add ec.rfx
execute if items entity @s armor.* *[custom_data~{rf_f_emberheart:2}] run tag @s add ec.rfx
execute if items entity @s weapon.offhand minecraft:shield[custom_data~{rf_f_emberheart:2}] run tag @s add ec.rfx
execute if entity @s[tag=ec.rfx] run attribute @s burning_time modifier add ec_rf_emberheart_f2 -0.30 add_multiplied_total
tag @s remove ec.rfx

# Emberheart Passive — +1 Mining Efficiency
execute if items entity @s weapon.mainhand *[custom_data~{rf_f_emberheart:3}] run tag @s add ec.rfx
execute if items entity @s armor.* *[custom_data~{rf_f_emberheart:3}] run tag @s add ec.rfx
execute if items entity @s weapon.offhand minecraft:shield[custom_data~{rf_f_emberheart:3}] run tag @s add ec.rfx
execute if entity @s[tag=ec.rfx] run attribute @s mining_efficiency modifier add ec_rf_emberheart_f3 1 add_value
tag @s remove ec.rfx

# Verdant Offensive — +1 Attack Damage
execute if items entity @s weapon.mainhand *[custom_data~{rf_f_verdant:1}] run tag @s add ec.rfx
execute if items entity @s armor.* *[custom_data~{rf_f_verdant:1}] run tag @s add ec.rfx
execute if items entity @s weapon.offhand minecraft:shield[custom_data~{rf_f_verdant:1}] run tag @s add ec.rfx
execute if entity @s[tag=ec.rfx] run attribute @s attack_damage modifier add ec_rf_verdant_f1 1.0 add_value
tag @s remove ec.rfx

# Verdant Defensive — +2 Hearts
execute if items entity @s weapon.mainhand *[custom_data~{rf_f_verdant:2}] run tag @s add ec.rfx
execute if items entity @s armor.* *[custom_data~{rf_f_verdant:2}] run tag @s add ec.rfx
execute if items entity @s weapon.offhand minecraft:shield[custom_data~{rf_f_verdant:2}] run tag @s add ec.rfx
# legacy (pre-facet) Verdant item in mainhand — same effect, same modifier ids
execute if items entity @s weapon.mainhand *[custom_data~{rf_verdant:1b}] unless items entity @s weapon.mainhand *[custom_data~{rf_f_verdant:1}] unless items entity @s weapon.mainhand *[custom_data~{rf_f_verdant:2}] unless items entity @s weapon.mainhand *[custom_data~{rf_f_verdant:3}] run tag @s add ec.rfx
execute if entity @s[tag=ec.rfx] run attribute @s max_health modifier add ec_rf_verdant_f2 4.0 add_value
tag @s remove ec.rfx

# Verdant Passive — +2 Safe Fall Distance
execute if items entity @s weapon.mainhand *[custom_data~{rf_f_verdant:3}] run tag @s add ec.rfx
execute if items entity @s armor.* *[custom_data~{rf_f_verdant:3}] run tag @s add ec.rfx
execute if items entity @s weapon.offhand minecraft:shield[custom_data~{rf_f_verdant:3}] run tag @s add ec.rfx
execute if entity @s[tag=ec.rfx] run attribute @s safe_fall_distance modifier add ec_rf_verdant_f3 2.0 add_value
tag @s remove ec.rfx

# Quicksilver Offensive — +20% Attack Speed
execute if items entity @s weapon.mainhand *[custom_data~{rf_f_quicksilver:1}] run tag @s add ec.rfx
execute if items entity @s armor.* *[custom_data~{rf_f_quicksilver:1}] run tag @s add ec.rfx
execute if items entity @s weapon.offhand minecraft:shield[custom_data~{rf_f_quicksilver:1}] run tag @s add ec.rfx
# legacy (pre-facet) Quicksilver item in mainhand — same effect, same modifier ids
execute if items entity @s weapon.mainhand *[custom_data~{rf_quicksilver:1b}] unless items entity @s weapon.mainhand *[custom_data~{rf_f_quicksilver:1}] unless items entity @s weapon.mainhand *[custom_data~{rf_f_quicksilver:2}] unless items entity @s weapon.mainhand *[custom_data~{rf_f_quicksilver:3}] run tag @s add ec.rfx
execute if entity @s[tag=ec.rfx] run attribute @s attack_speed modifier add ec_rf_quicksilver_f1 0.2 add_multiplied_total
tag @s remove ec.rfx

# Quicksilver Defensive — +20% Knockback Resistance
execute if items entity @s weapon.mainhand *[custom_data~{rf_f_quicksilver:2}] run tag @s add ec.rfx
execute if items entity @s armor.* *[custom_data~{rf_f_quicksilver:2}] run tag @s add ec.rfx
execute if items entity @s weapon.offhand minecraft:shield[custom_data~{rf_f_quicksilver:2}] run tag @s add ec.rfx
execute if entity @s[tag=ec.rfx] run attribute @s knockback_resistance modifier add ec_rf_quicksilver_f2 0.2 add_value
tag @s remove ec.rfx

# Quicksilver Passive — +15% Break Speed
execute if items entity @s weapon.mainhand *[custom_data~{rf_f_quicksilver:3}] run tag @s add ec.rfx
execute if items entity @s armor.* *[custom_data~{rf_f_quicksilver:3}] run tag @s add ec.rfx
execute if items entity @s weapon.offhand minecraft:shield[custom_data~{rf_f_quicksilver:3}] run tag @s add ec.rfx
execute if entity @s[tag=ec.rfx] run attribute @s block_break_speed modifier add ec_rf_quicksilver_f3 0.15 add_multiplied_base
tag @s remove ec.rfx

# Obsidian Offensive — +2.5 Attack Damage
execute if items entity @s weapon.mainhand *[custom_data~{rf_f_obsidian:1}] run tag @s add ec.rfx
execute if items entity @s armor.* *[custom_data~{rf_f_obsidian:1}] run tag @s add ec.rfx
execute if items entity @s weapon.offhand minecraft:shield[custom_data~{rf_f_obsidian:1}] run tag @s add ec.rfx
# legacy (pre-facet) Obsidian item in mainhand — same effect, same modifier ids
execute if items entity @s weapon.mainhand *[custom_data~{rf_obsidian:1b}] unless items entity @s weapon.mainhand *[custom_data~{rf_f_obsidian:1}] unless items entity @s weapon.mainhand *[custom_data~{rf_f_obsidian:2}] unless items entity @s weapon.mainhand *[custom_data~{rf_f_obsidian:3}] run tag @s add ec.rfx
execute if entity @s[tag=ec.rfx] run attribute @s attack_damage modifier add ec_rf_obsidian_f1 2.5 add_value
tag @s remove ec.rfx

# Obsidian Defensive — +2 Armor, +1 Toughness
execute if items entity @s weapon.mainhand *[custom_data~{rf_f_obsidian:2}] run tag @s add ec.rfx
execute if items entity @s armor.* *[custom_data~{rf_f_obsidian:2}] run tag @s add ec.rfx
execute if items entity @s weapon.offhand minecraft:shield[custom_data~{rf_f_obsidian:2}] run tag @s add ec.rfx
execute if entity @s[tag=ec.rfx] run attribute @s armor modifier add ec_rf_obsidian_f2a 2.0 add_value
execute if entity @s[tag=ec.rfx] run attribute @s armor_toughness modifier add ec_rf_obsidian_f2b 1.0 add_value
tag @s remove ec.rfx

# Obsidian Passive — +1 Block Reach
execute if items entity @s weapon.mainhand *[custom_data~{rf_f_obsidian:3}] run tag @s add ec.rfx
execute if items entity @s armor.* *[custom_data~{rf_f_obsidian:3}] run tag @s add ec.rfx
execute if items entity @s weapon.offhand minecraft:shield[custom_data~{rf_f_obsidian:3}] run tag @s add ec.rfx
execute if entity @s[tag=ec.rfx] run attribute @s block_interaction_range modifier add ec_rf_obsidian_f3 1.0 add_value
tag @s remove ec.rfx

# Zephyr Offensive — +0.5 Attack Knockback
execute if items entity @s weapon.mainhand *[custom_data~{rf_f_zephyr:1}] run tag @s add ec.rfx
execute if items entity @s armor.* *[custom_data~{rf_f_zephyr:1}] run tag @s add ec.rfx
execute if items entity @s weapon.offhand minecraft:shield[custom_data~{rf_f_zephyr:1}] run tag @s add ec.rfx
execute if entity @s[tag=ec.rfx] run attribute @s attack_knockback modifier add ec_rf_zephyr_f1 0.5 add_value
tag @s remove ec.rfx

# Zephyr Defensive — 25% less fall damage
execute if items entity @s weapon.mainhand *[custom_data~{rf_f_zephyr:2}] run tag @s add ec.rfx
execute if items entity @s armor.* *[custom_data~{rf_f_zephyr:2}] run tag @s add ec.rfx
execute if items entity @s weapon.offhand minecraft:shield[custom_data~{rf_f_zephyr:2}] run tag @s add ec.rfx
execute if entity @s[tag=ec.rfx] run attribute @s fall_damage_multiplier modifier add ec_rf_zephyr_f2 -0.25 add_multiplied_total
tag @s remove ec.rfx

# Zephyr Passive — +15% Movement Speed
execute if items entity @s weapon.mainhand *[custom_data~{rf_f_zephyr:3}] run tag @s add ec.rfx
execute if items entity @s armor.* *[custom_data~{rf_f_zephyr:3}] run tag @s add ec.rfx
execute if items entity @s weapon.offhand minecraft:shield[custom_data~{rf_f_zephyr:3}] run tag @s add ec.rfx
# legacy (pre-facet) Zephyr item in mainhand — same effect, same modifier ids
execute if items entity @s weapon.mainhand *[custom_data~{rf_zephyr:1b}] unless items entity @s weapon.mainhand *[custom_data~{rf_f_zephyr:1}] unless items entity @s weapon.mainhand *[custom_data~{rf_f_zephyr:2}] unless items entity @s weapon.mainhand *[custom_data~{rf_f_zephyr:3}] run tag @s add ec.rfx
execute if entity @s[tag=ec.rfx] run attribute @s movement_speed modifier add ec_rf_zephyr_f3 0.15 add_multiplied_total
tag @s remove ec.rfx

# Briar Offensive — +1.5 Attack Damage
execute if items entity @s weapon.mainhand *[custom_data~{rf_f_briar:1}] run tag @s add ec.rfx
execute if items entity @s armor.* *[custom_data~{rf_f_briar:1}] run tag @s add ec.rfx
execute if items entity @s weapon.offhand minecraft:shield[custom_data~{rf_f_briar:1}] run tag @s add ec.rfx
execute if entity @s[tag=ec.rfx] run attribute @s attack_damage modifier add ec_rf_briar_f1 1.5 add_value
tag @s remove ec.rfx

# Briar Defensive — +3 Armor + thorn reflect
execute if items entity @s weapon.mainhand *[custom_data~{rf_f_briar:2}] run tag @s add ec.rfx
execute if items entity @s armor.* *[custom_data~{rf_f_briar:2}] run tag @s add ec.rfx
execute if items entity @s weapon.offhand minecraft:shield[custom_data~{rf_f_briar:2}] run tag @s add ec.rfx
# legacy (pre-facet) Briar item in mainhand — same effect, same modifier ids
execute if items entity @s weapon.mainhand *[custom_data~{rf_briar:1b}] unless items entity @s weapon.mainhand *[custom_data~{rf_f_briar:1}] unless items entity @s weapon.mainhand *[custom_data~{rf_f_briar:2}] unless items entity @s weapon.mainhand *[custom_data~{rf_f_briar:3}] run tag @s add ec.rfx
execute if entity @s[tag=ec.rfx] run attribute @s armor modifier add ec_rf_briar_f2 3.0 add_value
tag @s remove ec.rfx

# Briar Passive — +20% Sneak Speed
execute if items entity @s weapon.mainhand *[custom_data~{rf_f_briar:3}] run tag @s add ec.rfx
execute if items entity @s armor.* *[custom_data~{rf_f_briar:3}] run tag @s add ec.rfx
execute if items entity @s weapon.offhand minecraft:shield[custom_data~{rf_f_briar:3}] run tag @s add ec.rfx
execute if entity @s[tag=ec.rfx] run attribute @s sneaking_speed modifier add ec_rf_briar_f3 0.20 add_multiplied_total
tag @s remove ec.rfx

# Stalwart Offensive — +2 Attack, +1 Armor
execute if items entity @s weapon.mainhand *[custom_data~{rf_f_stalwart:1}] run tag @s add ec.rfx
execute if items entity @s armor.* *[custom_data~{rf_f_stalwart:1}] run tag @s add ec.rfx
execute if items entity @s weapon.offhand minecraft:shield[custom_data~{rf_f_stalwart:1}] run tag @s add ec.rfx
# legacy (pre-facet) Stalwart item in mainhand — same effect, same modifier ids
execute if items entity @s weapon.mainhand *[custom_data~{rf_stalwart:1b}] unless items entity @s weapon.mainhand *[custom_data~{rf_f_stalwart:1}] unless items entity @s weapon.mainhand *[custom_data~{rf_f_stalwart:2}] unless items entity @s weapon.mainhand *[custom_data~{rf_f_stalwart:3}] run tag @s add ec.rfx
execute if entity @s[tag=ec.rfx] run attribute @s attack_damage modifier add ec_rf_stalwart_f1a 2.0 add_value
execute if entity @s[tag=ec.rfx] run attribute @s armor modifier add ec_rf_stalwart_f1b 1.0 add_value
tag @s remove ec.rfx

# Stalwart Defensive — +2 Armor, +20% KB Resist
execute if items entity @s weapon.mainhand *[custom_data~{rf_f_stalwart:2}] run tag @s add ec.rfx
execute if items entity @s armor.* *[custom_data~{rf_f_stalwart:2}] run tag @s add ec.rfx
execute if items entity @s weapon.offhand minecraft:shield[custom_data~{rf_f_stalwart:2}] run tag @s add ec.rfx
execute if entity @s[tag=ec.rfx] run attribute @s armor modifier add ec_rf_stalwart_f2a 2.0 add_value
execute if entity @s[tag=ec.rfx] run attribute @s knockback_resistance modifier add ec_rf_stalwart_f2b 0.2 add_value
tag @s remove ec.rfx

# Stalwart Passive — +0.5 Step Height
execute if items entity @s weapon.mainhand *[custom_data~{rf_f_stalwart:3}] run tag @s add ec.rfx
execute if items entity @s armor.* *[custom_data~{rf_f_stalwart:3}] run tag @s add ec.rfx
execute if items entity @s weapon.offhand minecraft:shield[custom_data~{rf_f_stalwart:3}] run tag @s add ec.rfx
execute if entity @s[tag=ec.rfx] run attribute @s step_height modifier add ec_rf_stalwart_f3 0.5 add_value
tag @s remove ec.rfx

# Gilded Offensive — +1 Attack Damage
execute if items entity @s weapon.mainhand *[custom_data~{rf_f_gilded:1}] run tag @s add ec.rfx
execute if items entity @s armor.* *[custom_data~{rf_f_gilded:1}] run tag @s add ec.rfx
execute if items entity @s weapon.offhand minecraft:shield[custom_data~{rf_f_gilded:1}] run tag @s add ec.rfx
execute if entity @s[tag=ec.rfx] run attribute @s attack_damage modifier add ec_rf_gilded_f1 1.0 add_value
tag @s remove ec.rfx

# Gilded Defensive — +2 Armor
execute if items entity @s weapon.mainhand *[custom_data~{rf_f_gilded:2}] run tag @s add ec.rfx
execute if items entity @s armor.* *[custom_data~{rf_f_gilded:2}] run tag @s add ec.rfx
execute if items entity @s weapon.offhand minecraft:shield[custom_data~{rf_f_gilded:2}] run tag @s add ec.rfx
execute if entity @s[tag=ec.rfx] run attribute @s armor modifier add ec_rf_gilded_f2 2.0 add_value
tag @s remove ec.rfx

# Gilded Passive — +0.5 Dream Rate
execute if items entity @s weapon.mainhand *[custom_data~{rf_f_gilded:3}] run tag @s add ec.rfx
execute if items entity @s armor.* *[custom_data~{rf_f_gilded:3}] run tag @s add ec.rfx
execute if items entity @s weapon.offhand minecraft:shield[custom_data~{rf_f_gilded:3}] run tag @s add ec.rfx
# legacy (pre-facet) Gilded item in mainhand — same effect, same modifier ids
execute if items entity @s weapon.mainhand *[custom_data~{rf_gilded:1b}] unless items entity @s weapon.mainhand *[custom_data~{rf_f_gilded:1}] unless items entity @s weapon.mainhand *[custom_data~{rf_f_gilded:2}] unless items entity @s weapon.mainhand *[custom_data~{rf_f_gilded:3}] run tag @s add ec.rfx
execute if entity @s[tag=ec.rfx] run attribute @s luck modifier add ec_rf_gilded_f3 0.5 add_value
tag @s remove ec.rfx

# Tidecall Offensive — +1 Attack, +10% Attack Speed
execute if items entity @s weapon.mainhand *[custom_data~{rf_f_tidecall:1}] run tag @s add ec.rfx
execute if items entity @s armor.* *[custom_data~{rf_f_tidecall:1}] run tag @s add ec.rfx
execute if items entity @s weapon.offhand minecraft:shield[custom_data~{rf_f_tidecall:1}] run tag @s add ec.rfx
execute if entity @s[tag=ec.rfx] run attribute @s attack_damage modifier add ec_rf_tidecall_f1a 1.0 add_value
execute if entity @s[tag=ec.rfx] run attribute @s attack_speed modifier add ec_rf_tidecall_f1b 0.10 add_multiplied_total
tag @s remove ec.rfx

# Tidecall Defensive — +3 Hearts
execute if items entity @s weapon.mainhand *[custom_data~{rf_f_tidecall:2}] run tag @s add ec.rfx
execute if items entity @s armor.* *[custom_data~{rf_f_tidecall:2}] run tag @s add ec.rfx
execute if items entity @s weapon.offhand minecraft:shield[custom_data~{rf_f_tidecall:2}] run tag @s add ec.rfx
# legacy (pre-facet) Tidecall item in mainhand — same effect, same modifier ids
execute if items entity @s weapon.mainhand *[custom_data~{rf_tidecall:1b}] unless items entity @s weapon.mainhand *[custom_data~{rf_f_tidecall:1}] unless items entity @s weapon.mainhand *[custom_data~{rf_f_tidecall:2}] unless items entity @s weapon.mainhand *[custom_data~{rf_f_tidecall:3}] run tag @s add ec.rfx
execute if entity @s[tag=ec.rfx] run attribute @s max_health modifier add ec_rf_tidecall_f2 6.0 add_value
tag @s remove ec.rfx

# Tidecall Passive — +25% underwater mining, +15% swim
execute if items entity @s weapon.mainhand *[custom_data~{rf_f_tidecall:3}] run tag @s add ec.rfx
execute if items entity @s armor.* *[custom_data~{rf_f_tidecall:3}] run tag @s add ec.rfx
execute if items entity @s weapon.offhand minecraft:shield[custom_data~{rf_f_tidecall:3}] run tag @s add ec.rfx
execute if entity @s[tag=ec.rfx] run attribute @s submerged_mining_speed modifier add ec_rf_tidecall_f3a 0.25 add_multiplied_base
execute if entity @s[tag=ec.rfx] run attribute @s water_movement_efficiency modifier add ec_rf_tidecall_f3b 0.15 add_value
tag @s remove ec.rfx

# Hearthstone Offensive — +1 Attack, +1 Armor
execute if items entity @s weapon.mainhand *[custom_data~{rf_f_hearthstone:1}] run tag @s add ec.rfx
execute if items entity @s armor.* *[custom_data~{rf_f_hearthstone:1}] run tag @s add ec.rfx
execute if items entity @s weapon.offhand minecraft:shield[custom_data~{rf_f_hearthstone:1}] run tag @s add ec.rfx
execute if entity @s[tag=ec.rfx] run attribute @s attack_damage modifier add ec_rf_hearthstone_f1a 1.0 add_value
execute if entity @s[tag=ec.rfx] run attribute @s armor modifier add ec_rf_hearthstone_f1b 1.0 add_value
tag @s remove ec.rfx

# Hearthstone Defensive — +3 Armor, +1 Toughness
execute if items entity @s weapon.mainhand *[custom_data~{rf_f_hearthstone:2}] run tag @s add ec.rfx
execute if items entity @s armor.* *[custom_data~{rf_f_hearthstone:2}] run tag @s add ec.rfx
execute if items entity @s weapon.offhand minecraft:shield[custom_data~{rf_f_hearthstone:2}] run tag @s add ec.rfx
# legacy (pre-facet) Hearthstone item in mainhand — same effect, same modifier ids
execute if items entity @s weapon.mainhand *[custom_data~{rf_hearthstone:1b}] unless items entity @s weapon.mainhand *[custom_data~{rf_f_hearthstone:1}] unless items entity @s weapon.mainhand *[custom_data~{rf_f_hearthstone:2}] unless items entity @s weapon.mainhand *[custom_data~{rf_f_hearthstone:3}] run tag @s add ec.rfx
execute if entity @s[tag=ec.rfx] run attribute @s armor modifier add ec_rf_hearthstone_f2a 3.0 add_value
execute if entity @s[tag=ec.rfx] run attribute @s armor_toughness modifier add ec_rf_hearthstone_f2b 1.0 add_value
tag @s remove ec.rfx

# Hearthstone Passive — +1 Entity Reach
execute if items entity @s weapon.mainhand *[custom_data~{rf_f_hearthstone:3}] run tag @s add ec.rfx
execute if items entity @s armor.* *[custom_data~{rf_f_hearthstone:3}] run tag @s add ec.rfx
execute if items entity @s weapon.offhand minecraft:shield[custom_data~{rf_f_hearthstone:3}] run tag @s add ec.rfx
execute if entity @s[tag=ec.rfx] run attribute @s entity_interaction_range modifier add ec_rf_hearthstone_f3 1.0 add_value
tag @s remove ec.rfx

# Prism Offensive — +1 Attack Damage
execute if items entity @s weapon.mainhand *[custom_data~{rf_f_prism:1}] run tag @s add ec.rfx
execute if items entity @s armor.* *[custom_data~{rf_f_prism:1}] run tag @s add ec.rfx
execute if items entity @s weapon.offhand minecraft:shield[custom_data~{rf_f_prism:1}] run tag @s add ec.rfx
execute if entity @s[tag=ec.rfx] run attribute @s attack_damage modifier add ec_rf_prism_f1 1.0 add_value
tag @s remove ec.rfx

# Prism Defensive — +5 Armor Toughness
execute if items entity @s weapon.mainhand *[custom_data~{rf_f_prism:2}] run tag @s add ec.rfx
execute if items entity @s armor.* *[custom_data~{rf_f_prism:2}] run tag @s add ec.rfx
execute if items entity @s weapon.offhand minecraft:shield[custom_data~{rf_f_prism:2}] run tag @s add ec.rfx
# legacy (pre-facet) Prism item in mainhand — same effect, same modifier ids
execute if items entity @s weapon.mainhand *[custom_data~{rf_prism:1b}] unless items entity @s weapon.mainhand *[custom_data~{rf_f_prism:1}] unless items entity @s weapon.mainhand *[custom_data~{rf_f_prism:2}] unless items entity @s weapon.mainhand *[custom_data~{rf_f_prism:3}] run tag @s add ec.rfx
execute if entity @s[tag=ec.rfx] run attribute @s armor_toughness modifier add ec_rf_prism_f2 5.0 add_value
tag @s remove ec.rfx

# Tempest Offensive — +1.5 Attack Damage
execute if items entity @s weapon.mainhand *[custom_data~{rf_f_tempest:1}] run tag @s add ec.rfx
execute if items entity @s armor.* *[custom_data~{rf_f_tempest:1}] run tag @s add ec.rfx
execute if items entity @s weapon.offhand minecraft:shield[custom_data~{rf_f_tempest:1}] run tag @s add ec.rfx
# legacy (pre-facet) Tempest item in mainhand — same effect, same modifier ids
execute if items entity @s weapon.mainhand *[custom_data~{rf_tempest:1b}] unless items entity @s weapon.mainhand *[custom_data~{rf_f_tempest:1}] unless items entity @s weapon.mainhand *[custom_data~{rf_f_tempest:2}] unless items entity @s weapon.mainhand *[custom_data~{rf_f_tempest:3}] run tag @s add ec.rfx
execute if entity @s[tag=ec.rfx] run attribute @s attack_damage modifier add ec_rf_tempest_f1 1.5 add_value
tag @s remove ec.rfx

# Tempest Defensive — +1 Armor, blast-steady
execute if items entity @s weapon.mainhand *[custom_data~{rf_f_tempest:2}] run tag @s add ec.rfx
execute if items entity @s armor.* *[custom_data~{rf_f_tempest:2}] run tag @s add ec.rfx
execute if items entity @s weapon.offhand minecraft:shield[custom_data~{rf_f_tempest:2}] run tag @s add ec.rfx
execute if entity @s[tag=ec.rfx] run attribute @s armor modifier add ec_rf_tempest_f2a 1.0 add_value
execute if entity @s[tag=ec.rfx] run attribute @s explosion_knockback_resistance modifier add ec_rf_tempest_f2b 0.5 add_value
tag @s remove ec.rfx

# Tempest Passive — Higher jumps
execute if items entity @s weapon.mainhand *[custom_data~{rf_f_tempest:3}] run tag @s add ec.rfx
execute if items entity @s armor.* *[custom_data~{rf_f_tempest:3}] run tag @s add ec.rfx
execute if items entity @s weapon.offhand minecraft:shield[custom_data~{rf_f_tempest:3}] run tag @s add ec.rfx
execute if entity @s[tag=ec.rfx] run attribute @s jump_strength modifier add ec_rf_tempest_f3 0.08 add_value
tag @s remove ec.rfx
