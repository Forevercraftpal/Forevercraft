# ============================================================
# Glyphforge — Arcanum ⚔ On-Hit Boon (W5; TRI-FACET facet-gate 2026-06-11)
# Fires on the player_hurt_entity advancement when ANY equipped slot carries
# rf_arcanum:1b. Gates here on the OFFENSIVE facet: explicit rf_f_arcanum:1 in any
# equipped slot, OR a legacy pre-facet mainhand item (legacy Arcanum = Offensive).
# Grants a random MINOR self-buff for a few seconds — the unpredictable "Wild
# Forces" theme expressed as the on-hit boon. A short internal cooldown
# (ec.rf_arcanum_cd, gametime-keyed) keeps it from refreshing on every swing.
# Run as: the attacking player.
# ============================================================

# Re-arm the advancement so it can fire again on the next qualifying hit.
advancement revoke @s only evercraft:glyphforge/arcanum_on_hit

# Offensive-facet gate
execute if items entity @s weapon.mainhand *[custom_data~{rf_f_arcanum:1}] run tag @s add ec.rf_ao
execute if entity @s[tag=!ec.rf_ao] if items entity @s armor.* *[custom_data~{rf_f_arcanum:1}] run tag @s add ec.rf_ao
execute if entity @s[tag=!ec.rf_ao] if items entity @s weapon.offhand minecraft:shield[custom_data~{rf_f_arcanum:1}] run tag @s add ec.rf_ao
# legacy (pre-facet) Arcanum in mainhand
execute if entity @s[tag=!ec.rf_ao] if items entity @s weapon.mainhand *[custom_data~{rf_arcanum:1b}] unless items entity @s weapon.mainhand *[custom_data~{rf_f_arcanum:1}] unless items entity @s weapon.mainhand *[custom_data~{rf_f_arcanum:2}] unless items entity @s weapon.mainhand *[custom_data~{rf_f_arcanum:3}] run tag @s add ec.rf_ao
execute unless entity @s[tag=ec.rf_ao] run return 0
tag @s remove ec.rf_ao

# Cooldown gate (~3s): only roll a new boon if past the stored gametime checkpoint.
execute store result score #rf_now ec.temp run time query gametime
execute if score @s ec.rf_arcanum_cd matches 1.. if score #rf_now ec.temp < @s ec.rf_arcanum_cd run return 0
scoreboard players operation @s ec.rf_arcanum_cd = #rf_now ec.temp
scoreboard players add @s ec.rf_arcanum_cd 60

# Roll one of 6 minor positive boons (5s, amp 0).
execute store result score #rf_arc_roll ec.temp run random value 1..6
execute if score #rf_arc_roll ec.temp matches 1 run effect give @s speed 5 0 true
execute if score #rf_arc_roll ec.temp matches 2 run effect give @s strength 5 0 true
execute if score #rf_arc_roll ec.temp matches 3 run effect give @s regeneration 5 0 true
execute if score #rf_arc_roll ec.temp matches 4 run effect give @s haste 5 0 true
execute if score #rf_arc_roll ec.temp matches 5 run effect give @s resistance 5 0 true
execute if score #rf_arc_roll ec.temp matches 6 run effect give @s absorption 5 0 true

# Subtle feedback (player-facing text stays within the banned-word law).
particle minecraft:witch ~ ~1 ~ 0.3 0.5 0.3 0.05 6
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.4 1.4
