# Glyphforge Effects — Passive-facet procs (1s, run as glyph-active player, at @s)
# TRI-FACET 2026-06-11. Paced by @s rf.ptime (incremented by effects/tick):
#   Prism ✦  — every 10s: hostile creatures within 8 blocks briefly glow ("light finds what hides")
#   Arcanum ✦ — every 60s: a small random boon settles on the bearer
# Proc facets are EXPLICIT-ONLY (rf_f_<g>:3) — no legacy form exists for these (legacy
# Prism = Defensive toughness, legacy Arcanum = Offensive on-hit).

# --- Prism ✦ reveal pulse (every 10s) ---
scoreboard players set #rf_m10 rf.timer 10
scoreboard players operation #rf_mod rf.timer = @s rf.ptime
scoreboard players operation #rf_mod rf.timer %= #rf_m10 rf.timer
execute unless score #rf_mod rf.timer matches 0 run return run function evercraft:glyphforge/effects/passive_arcanum
execute if items entity @s weapon.mainhand *[custom_data~{rf_f_prism:3}] run tag @s add ec.rf_pr
execute if entity @s[tag=!ec.rf_pr] if items entity @s armor.* *[custom_data~{rf_f_prism:3}] run tag @s add ec.rf_pr
execute if entity @s[tag=!ec.rf_pr] if items entity @s weapon.offhand minecraft:shield[custom_data~{rf_f_prism:3}] run tag @s add ec.rf_pr
execute if entity @s[tag=ec.rf_pr] run effect give @e[type=#evercraft:hostile_mobs,distance=..8] glowing 4 0 true
execute if entity @s[tag=ec.rf_pr] if entity @e[type=#evercraft:hostile_mobs,distance=..8,limit=1] if score @s ec.fx_vis matches 1.. run particle minecraft:end_rod ~ ~1.2 ~ 0.4 0.4 0.4 0.01 5
execute if entity @s[tag=ec.rf_pr] if entity @e[type=#evercraft:hostile_mobs,distance=..8,limit=1] if score @s ec.fx_snd matches 1.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.3 1.8
tag @s remove ec.rf_pr

function evercraft:glyphforge/effects/passive_arcanum
