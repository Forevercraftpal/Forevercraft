# Glyphforge Effects — Strip all modifiers (TRI-FACET rework 2026-06-11)
# Removes every facet modifier id + the pre-facet legacy ids (transition safety:
# players who carried old modifiers across the /reload get cleaned here too).

attribute @s attack_damage modifier remove ec_rf_emberheart_f1
attribute @s burning_time modifier remove ec_rf_emberheart_f2
attribute @s mining_efficiency modifier remove ec_rf_emberheart_f3
attribute @s attack_damage modifier remove ec_rf_verdant_f1
attribute @s max_health modifier remove ec_rf_verdant_f2
attribute @s safe_fall_distance modifier remove ec_rf_verdant_f3
attribute @s attack_speed modifier remove ec_rf_quicksilver_f1
attribute @s knockback_resistance modifier remove ec_rf_quicksilver_f2
attribute @s block_break_speed modifier remove ec_rf_quicksilver_f3
attribute @s attack_damage modifier remove ec_rf_obsidian_f1
attribute @s armor modifier remove ec_rf_obsidian_f2a
attribute @s armor_toughness modifier remove ec_rf_obsidian_f2b
attribute @s block_interaction_range modifier remove ec_rf_obsidian_f3
attribute @s attack_knockback modifier remove ec_rf_zephyr_f1
attribute @s fall_damage_multiplier modifier remove ec_rf_zephyr_f2
attribute @s movement_speed modifier remove ec_rf_zephyr_f3
attribute @s attack_damage modifier remove ec_rf_briar_f1
attribute @s armor modifier remove ec_rf_briar_f2
attribute @s sneaking_speed modifier remove ec_rf_briar_f3
attribute @s attack_damage modifier remove ec_rf_stalwart_f1a
attribute @s armor modifier remove ec_rf_stalwart_f1b
attribute @s armor modifier remove ec_rf_stalwart_f2a
attribute @s knockback_resistance modifier remove ec_rf_stalwart_f2b
attribute @s step_height modifier remove ec_rf_stalwart_f3
attribute @s attack_damage modifier remove ec_rf_gilded_f1
attribute @s armor modifier remove ec_rf_gilded_f2
attribute @s luck modifier remove ec_rf_gilded_f3
attribute @s attack_damage modifier remove ec_rf_tidecall_f1a
attribute @s attack_speed modifier remove ec_rf_tidecall_f1b
attribute @s max_health modifier remove ec_rf_tidecall_f2
attribute @s submerged_mining_speed modifier remove ec_rf_tidecall_f3a
attribute @s water_movement_efficiency modifier remove ec_rf_tidecall_f3b
attribute @s attack_damage modifier remove ec_rf_hearthstone_f1a
attribute @s armor modifier remove ec_rf_hearthstone_f1b
attribute @s armor modifier remove ec_rf_hearthstone_f2a
attribute @s armor_toughness modifier remove ec_rf_hearthstone_f2b
attribute @s entity_interaction_range modifier remove ec_rf_hearthstone_f3
attribute @s attack_damage modifier remove ec_rf_prism_f1
attribute @s armor_toughness modifier remove ec_rf_prism_f2
attribute @s attack_damage modifier remove ec_rf_tempest_f1
attribute @s armor modifier remove ec_rf_tempest_f2a
attribute @s explosion_knockback_resistance modifier remove ec_rf_tempest_f2b
attribute @s jump_strength modifier remove ec_rf_tempest_f3

# pre-facet legacy ids (items forged before 2026-06-11 applied these)
attribute @s attack_damage modifier remove ec_rf_emberheart
attribute @s max_health modifier remove ec_rf_verdant
attribute @s attack_speed modifier remove ec_rf_quicksilver
attribute @s attack_damage modifier remove ec_rf_obsidian
attribute @s movement_speed modifier remove ec_rf_zephyr
attribute @s armor modifier remove ec_rf_briar
attribute @s attack_damage modifier remove ec_rf_stalwart_dmg
attribute @s armor modifier remove ec_rf_stalwart_arm
attribute @s luck modifier remove ec_rf_gilded
attribute @s max_health modifier remove ec_rf_tidecall
attribute @s armor modifier remove ec_rf_hearth_arm
attribute @s armor_toughness modifier remove ec_rf_hearth_tgh
attribute @s armor_toughness modifier remove ec_rf_prism
attribute @s attack_damage modifier remove ec_rf_tempest
