# ============================================================
# Glyphforge — Arcanum 🛡 Ward (TRI-FACET 2026-06-11)
# Fires on the entity_hurt_player advancement when ANY equipped slot carries
# rf_arcanum:1b. Gates here on the Defensive facet (rf_f_arcanum:2 — explicit-only,
# legacy Arcanum is Offensive) + an ~8s internal cooldown, then grants a random
# brief ward. "Wild forces flinch on your behalf."
# Run as: the hurt player.
# ============================================================

# Re-arm the advancement so it can fire on the next hit taken.
advancement revoke @s only evercraft:glyphforge/arcanum_ward

# Defensive-facet gate (any equipped slot)
execute if items entity @s weapon.mainhand *[custom_data~{rf_f_arcanum:2}] run tag @s add ec.rf_aw
execute if entity @s[tag=!ec.rf_aw] if items entity @s armor.* *[custom_data~{rf_f_arcanum:2}] run tag @s add ec.rf_aw
execute if entity @s[tag=!ec.rf_aw] if items entity @s weapon.offhand minecraft:shield[custom_data~{rf_f_arcanum:2}] run tag @s add ec.rf_aw
execute unless entity @s[tag=ec.rf_aw] run return 0
tag @s remove ec.rf_aw

# Cooldown gate (~8s): only roll a new ward past the stored gametime checkpoint.
execute store result score #rf_now ec.temp run time query gametime
execute if score @s ec.rf_arcward_cd matches 1.. if score #rf_now ec.temp < @s ec.rf_arcward_cd run return 0
scoreboard players operation @s ec.rf_arcward_cd = #rf_now ec.temp
scoreboard players add @s ec.rf_arcward_cd 160

# Roll one of 3 brief wards (4s, amp 0)
execute store result score #rf_arc_roll ec.temp run random value 1..3
execute if score #rf_arc_roll ec.temp matches 1 run effect give @s resistance 4 0 true
execute if score #rf_arc_roll ec.temp matches 2 run effect give @s absorption 4 0 true
execute if score #rf_arc_roll ec.temp matches 3 run effect give @s speed 4 0 true

# Subtle feedback
execute at @s if score @s ec.fx_vis matches 1.. run particle minecraft:witch ~ ~1 ~ 0.3 0.5 0.3 0.05 6
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.4 0.9
