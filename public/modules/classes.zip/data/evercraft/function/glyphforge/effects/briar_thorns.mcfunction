# ============================================================
# Glyphforge — Briar Thorns Reflect (W5; TRI-FACET facet-gate 2026-06-11)
# Briar is the natural thorns home (Obsidian's "Thornmail" was a fake Resistance
# proxy and has been renamed to Bulwark). When a player wearing/holding a Briar 🛡
# Defensive piece is hurt by a hostile mob, the bramble retaliates: a small reflect
# of thorn damage to the nearest hostile mob.
# Thorns belongs to Briar's DEFENSIVE facet: explicit rf_f_briar:2 in any equipped
# slot, OR a legacy pre-facet mainhand item (rf_briar with no rf_f_briar field —
# legacy Briar = Defensive). The advancement gates broadly on rf_briar anywhere;
# the precise facet check lives here.
# Run as: the hurt player (from the entity_hurt_player advancement). At @s.
# ============================================================

# Re-arm the advancement so it can fire on the next hit taken.
advancement revoke @s only evercraft:glyphforge/briar_thorns

# Defensive-facet gate
execute if items entity @s weapon.mainhand *[custom_data~{rf_f_briar:2}] run tag @s add ec.rf_br
execute if entity @s[tag=!ec.rf_br] if items entity @s armor.* *[custom_data~{rf_f_briar:2}] run tag @s add ec.rf_br
execute if entity @s[tag=!ec.rf_br] if items entity @s weapon.offhand minecraft:shield[custom_data~{rf_f_briar:2}] run tag @s add ec.rf_br
# legacy (pre-facet) Briar in mainhand
execute if entity @s[tag=!ec.rf_br] if items entity @s weapon.mainhand *[custom_data~{rf_briar:1b}] unless items entity @s weapon.mainhand *[custom_data~{rf_f_briar:1}] unless items entity @s weapon.mainhand *[custom_data~{rf_f_briar:2}] unless items entity @s weapon.mainhand *[custom_data~{rf_f_briar:3}] run tag @s add ec.rf_br
execute unless entity @s[tag=ec.rf_br] run return 0
tag @s remove ec.rf_br

# Reflect a small thorn bite to the nearest hostile mob within 4 blocks.
execute at @s run damage @e[type=#evercraft:hostile_mobs,distance=..4,limit=1,sort=nearest] 3 minecraft:thorns by @s

# Bramble feedback (nature theme; player text stays within the banned-word law).
execute at @s if entity @e[type=#evercraft:hostile_mobs,distance=..4,limit=1] run particle minecraft:composter ~ ~1 ~ 0.4 0.5 0.4 0.02 8
execute at @s if entity @e[type=#evercraft:hostile_mobs,distance=..4,limit=1] if score @s ec.fx_snd matches 1.. run playsound minecraft:block.sweet_berry_bush.break master @s ~ ~ ~ 0.5 1.0
