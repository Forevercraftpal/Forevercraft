# Single weapon-mastery level-up notification — fired once by the orchestrator after the silent
# loop, showing the FINAL level reached. Debounced (key:3) like the original. Run as @s = player.
data modify storage evercraft:notify stage.c set value [{text:"Your weapon reached ",color:"yellow"},{text:"Level ",color:"gold"},{score:{name:"#wm_level",objective:"ec.var"},color:"gold",bold:true},{text:"!",color:"yellow"}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit_keyed {key:3}
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.player.levelup master @s ~ ~ ~ 0.7 1.5
particle minecraft:enchant ~ ~1 ~ 0.3 0.3 0.3 1 20 force @s
