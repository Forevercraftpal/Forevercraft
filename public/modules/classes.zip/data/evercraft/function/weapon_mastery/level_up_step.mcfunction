# Silent recursive level-up loop (no notification — the orchestrator level_up.mcfunction notifies
# once at the end with the final level). Mirrors the original per-level logic minus the emit/effects.
# Get XP cost for current level
function evercraft:weapon_mastery/get_xp_cost
# Stop if not enough XP for the next level
execute if score #wm_xp ec.var < #wm_xp_cost ec.var run return 0
# Consume XP for this level
scoreboard players operation #wm_xp ec.var -= #wm_xp_cost ec.var
scoreboard players add #wm_level ec.var 1
# Cap at max level
execute if score #wm_level ec.var > #wm_max_level ec.var run scoreboard players operation #wm_level ec.var = #wm_max_level ec.var
execute if score #wm_level ec.var >= #wm_max_level ec.var run scoreboard players set #wm_xp ec.var 0
# Mark enchants as needing update
scoreboard players set #wm_enchants_dirty ec.var 1
# One-time max-level effect when the cap is hit
execute if score #wm_level ec.var >= #wm_max_level ec.var run function evercraft:weapon_mastery/max_level_reached
# Recurse for additional banked level-ups
execute if score #wm_level ec.var < #wm_max_level ec.var run function evercraft:weapon_mastery/level_up_step
