# Give prestige token
# Inv-full guard: drop at the player's feet rather than void on a full inventory.
execute store result score #inv_full ec.var run function evercraft:util/check_inv_full
execute if score #inv_full ec.var matches 0 run loot give @s loot evercraft:weapon_mastery/prestige_token
execute if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:weapon_mastery/prestige_token

# Announcement
data modify storage evercraft:notify stage.c set value [{text:"MAXIMUM POWER! ",color:"light_purple",bold:true},{text:"You received a ",color:"yellow"},{text:"Prestige Token",color:"gold",bold:true},{text:"!",color:"yellow"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 1.0 1.0
