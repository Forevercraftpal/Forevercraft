# Re-give the consumed token
# Inv-full guard: drop at the player's feet rather than void on a full inventory.
execute store result score #inv_full ec.var run function evercraft:util/check_inv_full
execute if score #inv_full ec.var matches 0 run loot give @s loot evercraft:weapon_mastery/prestige_token
execute if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:weapon_mastery/prestige_token
data modify storage evercraft:notify stage.c set value [{text:"No gear ready for prestige! Need a max-level awakened weapon or armor.",color:"red"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 0.8 0.5
