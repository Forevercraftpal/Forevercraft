# Prestige enchant reconciliation for the weapon in wm_temp.
# Requires #wm_weapon_type ec.var (classify_weapon / classify_weapon_slot).
# For each mastery enchant of this weapon type: pure mastery resets (removed -> regrows from the
# new floor on re-level); a player-boosted level is kept and grown +1 (clamp 10). Manual enchants
# mastery doesn't grant (silk_touch, curses, …) aren't listed, so they ride through untouched.
# KEY LISTS BELOW MUST MIRROR evercraft:weapon_mastery/enchants/<type>.

# Ceiling = max_level + OLD prestige. #wm_prestige is already incremented here, so subtract 1.
function evercraft:weapon_mastery/get_max_level
scoreboard players operation #mr_ceil ec.var = #wm_max_level ec.var
scoreboard players operation #mr_ceil ec.var += #wm_prestige ec.var
scoreboard players remove #mr_ceil ec.var 1

# Normalize shared key-sets into a strip class:
#   1 = swordlike (sword 1, dagger 10, gauntlet 12, spear 13)
#   2 = axe   3 = mining (pickaxe 3, hoe 8, shovel 9)
#   4 = bow   5 = crossbow   6 = fishing_rod   7 = trident   11 = shield   14 = mace
scoreboard players operation #wm_strip ec.var = #wm_weapon_type ec.var
execute if score #wm_weapon_type ec.var matches 10 run scoreboard players set #wm_strip ec.var 1
execute if score #wm_weapon_type ec.var matches 12 run scoreboard players set #wm_strip ec.var 1
execute if score #wm_weapon_type ec.var matches 13 run scoreboard players set #wm_strip ec.var 1
execute if score #wm_weapon_type ec.var matches 8 run scoreboard players set #wm_strip ec.var 3
execute if score #wm_weapon_type ec.var matches 9 run scoreboard players set #wm_strip ec.var 3

# --- swordlike (sword / dagger / gauntlet / spear) ---
execute if score #wm_strip ec.var matches 1 run function evercraft:mastery/prestige_reconcile_key {key:"sharpness",tag:"wm_temp"}
execute if score #wm_strip ec.var matches 1 run function evercraft:mastery/prestige_reconcile_key {key:"smite",tag:"wm_temp"}
execute if score #wm_strip ec.var matches 1 run function evercraft:mastery/prestige_reconcile_key {key:"bane_of_arthropods",tag:"wm_temp"}
execute if score #wm_strip ec.var matches 1 run function evercraft:mastery/prestige_reconcile_key {key:"fire_aspect",tag:"wm_temp"}
execute if score #wm_strip ec.var matches 1 run function evercraft:mastery/prestige_reconcile_key {key:"knockback",tag:"wm_temp"}
execute if score #wm_strip ec.var matches 1 run function evercraft:mastery/prestige_reconcile_key {key:"sweeping_edge",tag:"wm_temp"}
execute if score #wm_strip ec.var matches 1 run function evercraft:mastery/prestige_reconcile_key {key:"looting",tag:"wm_temp"}
execute if score #wm_strip ec.var matches 1 run function evercraft:mastery/prestige_reconcile_key {key:"mending",tag:"wm_temp"}
execute if score #wm_strip ec.var matches 1 run function evercraft:mastery/prestige_reconcile_key {key:"unbreaking",tag:"wm_temp"}

# --- axe ---
execute if score #wm_strip ec.var matches 2 run function evercraft:mastery/prestige_reconcile_key {key:"sharpness",tag:"wm_temp"}
execute if score #wm_strip ec.var matches 2 run function evercraft:mastery/prestige_reconcile_key {key:"smite",tag:"wm_temp"}
execute if score #wm_strip ec.var matches 2 run function evercraft:mastery/prestige_reconcile_key {key:"bane_of_arthropods",tag:"wm_temp"}
execute if score #wm_strip ec.var matches 2 run function evercraft:mastery/prestige_reconcile_key {key:"fire_aspect",tag:"wm_temp"}
execute if score #wm_strip ec.var matches 2 run function evercraft:mastery/prestige_reconcile_key {key:"efficiency",tag:"wm_temp"}
execute if score #wm_strip ec.var matches 2 run function evercraft:mastery/prestige_reconcile_key {key:"fortune",tag:"wm_temp"}
execute if score #wm_strip ec.var matches 2 run function evercraft:mastery/prestige_reconcile_key {key:"looting",tag:"wm_temp"}
execute if score #wm_strip ec.var matches 2 run function evercraft:mastery/prestige_reconcile_key {key:"mending",tag:"wm_temp"}
execute if score #wm_strip ec.var matches 2 run function evercraft:mastery/prestige_reconcile_key {key:"unbreaking",tag:"wm_temp"}

# --- mining (pickaxe / hoe / shovel) ---
execute if score #wm_strip ec.var matches 3 run function evercraft:mastery/prestige_reconcile_key {key:"efficiency",tag:"wm_temp"}
execute if score #wm_strip ec.var matches 3 run function evercraft:mastery/prestige_reconcile_key {key:"fortune",tag:"wm_temp"}
execute if score #wm_strip ec.var matches 3 run function evercraft:mastery/prestige_reconcile_key {key:"mending",tag:"wm_temp"}
execute if score #wm_strip ec.var matches 3 run function evercraft:mastery/prestige_reconcile_key {key:"unbreaking",tag:"wm_temp"}

# --- bow ---
execute if score #wm_strip ec.var matches 4 run function evercraft:mastery/prestige_reconcile_key {key:"power",tag:"wm_temp"}
execute if score #wm_strip ec.var matches 4 run function evercraft:mastery/prestige_reconcile_key {key:"punch",tag:"wm_temp"}
execute if score #wm_strip ec.var matches 4 run function evercraft:mastery/prestige_reconcile_key {key:"flame",tag:"wm_temp"}
execute if score #wm_strip ec.var matches 4 run function evercraft:mastery/prestige_reconcile_key {key:"infinity",tag:"wm_temp"}
execute if score #wm_strip ec.var matches 4 run function evercraft:mastery/prestige_reconcile_key {key:"looting",tag:"wm_temp"}
execute if score #wm_strip ec.var matches 4 run function evercraft:mastery/prestige_reconcile_key {key:"mending",tag:"wm_temp"}
execute if score #wm_strip ec.var matches 4 run function evercraft:mastery/prestige_reconcile_key {key:"unbreaking",tag:"wm_temp"}

# --- crossbow ---
execute if score #wm_strip ec.var matches 5 run function evercraft:mastery/prestige_reconcile_key {key:"multishot",tag:"wm_temp"}
execute if score #wm_strip ec.var matches 5 run function evercraft:mastery/prestige_reconcile_key {key:"piercing",tag:"wm_temp"}
execute if score #wm_strip ec.var matches 5 run function evercraft:mastery/prestige_reconcile_key {key:"quick_charge",tag:"wm_temp"}
execute if score #wm_strip ec.var matches 5 run function evercraft:mastery/prestige_reconcile_key {key:"looting",tag:"wm_temp"}
execute if score #wm_strip ec.var matches 5 run function evercraft:mastery/prestige_reconcile_key {key:"mending",tag:"wm_temp"}
execute if score #wm_strip ec.var matches 5 run function evercraft:mastery/prestige_reconcile_key {key:"unbreaking",tag:"wm_temp"}

# --- fishing_rod ---
execute if score #wm_strip ec.var matches 6 run function evercraft:mastery/prestige_reconcile_key {key:"luck_of_the_sea",tag:"wm_temp"}
execute if score #wm_strip ec.var matches 6 run function evercraft:mastery/prestige_reconcile_key {key:"lure",tag:"wm_temp"}
execute if score #wm_strip ec.var matches 6 run function evercraft:mastery/prestige_reconcile_key {key:"mending",tag:"wm_temp"}
execute if score #wm_strip ec.var matches 6 run function evercraft:mastery/prestige_reconcile_key {key:"unbreaking",tag:"wm_temp"}

# --- trident ---
execute if score #wm_strip ec.var matches 7 run function evercraft:mastery/prestige_reconcile_key {key:"impaling",tag:"wm_temp"}
execute if score #wm_strip ec.var matches 7 run function evercraft:mastery/prestige_reconcile_key {key:"loyalty",tag:"wm_temp"}
execute if score #wm_strip ec.var matches 7 run function evercraft:mastery/prestige_reconcile_key {key:"riptide",tag:"wm_temp"}
execute if score #wm_strip ec.var matches 7 run function evercraft:mastery/prestige_reconcile_key {key:"channeling",tag:"wm_temp"}
execute if score #wm_strip ec.var matches 7 run function evercraft:mastery/prestige_reconcile_key {key:"mending",tag:"wm_temp"}
execute if score #wm_strip ec.var matches 7 run function evercraft:mastery/prestige_reconcile_key {key:"unbreaking",tag:"wm_temp"}

# --- shield ---
execute if score #wm_strip ec.var matches 11 run function evercraft:mastery/prestige_reconcile_key {key:"looting",tag:"wm_temp"}
execute if score #wm_strip ec.var matches 11 run function evercraft:mastery/prestige_reconcile_key {key:"mending",tag:"wm_temp"}
execute if score #wm_strip ec.var matches 11 run function evercraft:mastery/prestige_reconcile_key {key:"unbreaking",tag:"wm_temp"}

# --- mace ---
execute if score #wm_strip ec.var matches 14 run function evercraft:mastery/prestige_reconcile_key {key:"density",tag:"wm_temp"}
execute if score #wm_strip ec.var matches 14 run function evercraft:mastery/prestige_reconcile_key {key:"breach",tag:"wm_temp"}
execute if score #wm_strip ec.var matches 14 run function evercraft:mastery/prestige_reconcile_key {key:"wind_burst",tag:"wm_temp"}
execute if score #wm_strip ec.var matches 14 run function evercraft:mastery/prestige_reconcile_key {key:"smite",tag:"wm_temp"}
execute if score #wm_strip ec.var matches 14 run function evercraft:mastery/prestige_reconcile_key {key:"bane_of_arthropods",tag:"wm_temp"}
execute if score #wm_strip ec.var matches 14 run function evercraft:mastery/prestige_reconcile_key {key:"fire_aspect",tag:"wm_temp"}
execute if score #wm_strip ec.var matches 14 run function evercraft:mastery/prestige_reconcile_key {key:"knockback",tag:"wm_temp"}
execute if score #wm_strip ec.var matches 14 run function evercraft:mastery/prestige_reconcile_key {key:"looting",tag:"wm_temp"}
execute if score #wm_strip ec.var matches 14 run function evercraft:mastery/prestige_reconcile_key {key:"mending",tag:"wm_temp"}
execute if score #wm_strip ec.var matches 14 run function evercraft:mastery/prestige_reconcile_key {key:"unbreaking",tag:"wm_temp"}
