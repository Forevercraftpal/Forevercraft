# Weapon-mastery level-up orchestrator: silently apply ALL banked level-ups, then notify ONCE
# with the FINAL level. Banked XP can grant several levels at once — show only the result, not a
# per-level crawl (debounce previously collapsed the crawl to the FIRST level; this shows the LAST).
# Run as @s = the player.
scoreboard players operation #wm_lvl_start ec.var = #wm_level ec.var
function evercraft:weapon_mastery/level_up_step
execute if score #wm_level ec.var > #wm_lvl_start ec.var run function evercraft:weapon_mastery/level_up_notify
# Bough Mastery (2026-06-14): a real MAINHAND weapon level-up also feeds the
# active class's bough level. Gated on #wm_is_mainhand (set by xp_check_all) so
# inventory/armor level-ups don't mis-credit the held class.
execute if score #wm_level ec.var > #wm_lvl_start ec.var if score #wm_is_mainhand ec.temp matches 1 run function evercraft:bough/mastery/wm_hook
