# Awakening Stone — Exquisite tier

advancement revoke @s only evercraft:weapon_mastery/stones/consume_exquisite

# Priority 1: Check mainhand
execute if items entity @s weapon.mainhand *[custom_data~{is_artifact:true,tier:"exquisite"}] unless items entity @s weapon.mainhand *[custom_data~{awakened:1b}] run return run function evercraft:weapon_mastery/stones/awaken
execute if items entity @s weapon.mainhand *[custom_data~{is_artifact:true,tier:"exquisite",awakened:1b}] run return run function evercraft:weapon_mastery/stones/fail_already_awakened {tier:"exquisite"}

# Priority 2: Check offhand (for functional weapons: rods, bows, shields, tridents)
execute if items entity @s weapon.offhand *[custom_data~{is_artifact:true,tier:"exquisite"}] unless items entity @s weapon.offhand *[custom_data~{awakened:1b}] run return run function evercraft:weapon_mastery/stones/awaken_offhand
execute if items entity @s weapon.offhand *[custom_data~{is_artifact:true,tier:"exquisite",awakened:1b}] run return run function evercraft:weapon_mastery/stones/fail_already_awakened {tier:"exquisite"}

# Priority 3: Check armor slots
execute if items entity @s armor.head *[custom_data~{is_artifact:true,tier:"exquisite"}] unless items entity @s armor.head *[custom_data~{awakened:1b}] run return run function evercraft:armor_mastery/awaken {slot:"head"}
execute if items entity @s armor.chest *[custom_data~{is_artifact:true,tier:"exquisite"}] unless items entity @s armor.chest *[custom_data~{awakened:1b}] run return run function evercraft:armor_mastery/awaken {slot:"chest"}
execute if items entity @s armor.legs *[custom_data~{is_artifact:true,tier:"exquisite"}] unless items entity @s armor.legs *[custom_data~{awakened:1b}] run return run function evercraft:armor_mastery/awaken {slot:"legs"}
execute if items entity @s armor.feet *[custom_data~{is_artifact:true,tier:"exquisite"}] unless items entity @s armor.feet *[custom_data~{awakened:1b}] run return run function evercraft:armor_mastery/awaken {slot:"feet"}

# Priority 4: Plain gathering tool already tagged tier:"exquisite". (Classes Enhancement Ship A 2026-05-28.)
execute if items entity @s weapon.mainhand #evercraft:gathering_tools[custom_data~{tier:"exquisite"}] unless items entity @s weapon.mainhand *[custom_data~{is_artifact:true}] unless items entity @s weapon.mainhand *[custom_data~{awakened:1b}] run return run function evercraft:weapon_mastery/stones/awaken

# Priority 5: Plain UNTIERED gathering tool — stamp tier:"exquisite" + awakened:1b.
execute if items entity @s weapon.mainhand #evercraft:gathering_tools unless items entity @s weapon.mainhand *[custom_data~{is_artifact:true}] unless items entity @s weapon.mainhand *[custom_data~{awakened:1b}] unless items entity @s weapon.mainhand *[custom_data~{tier:"common"}] unless items entity @s weapon.mainhand *[custom_data~{tier:"uncommon"}] unless items entity @s weapon.mainhand *[custom_data~{tier:"rare"}] unless items entity @s weapon.mainhand *[custom_data~{tier:"ornate"}] unless items entity @s weapon.mainhand *[custom_data~{tier:"exquisite"}] unless items entity @s weapon.mainhand *[custom_data~{tier:"mythical"}] run return run function evercraft:weapon_mastery/stones/awaken_plain_exquisite

function evercraft:weapon_mastery/stones/fail_wrong_weapon {tier:"exquisite"}
