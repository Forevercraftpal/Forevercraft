# Apply awakening to mainhand weapon via item modifier
item modify entity @s weapon.mainhand evercraft:weapon_mastery/awaken

# Lifetime milestone counter: +1 per gear piece awakened. Combined weapon+armor tally (ec.wm_maxed).
# This is the one allowed exception to single-writer: weapon awaken-apply files + armor_mastery/awaken
# are disjoint event sites feeding the same lifetime counter. Upstream try_awaken_* gates on
# `unless ...awakened:1b`, so this only fires on a genuinely new awakening (never re-awaken).
scoreboard players add @s ec.wm_maxed 1

# Append mastery lore line to item (so write_back can update lore[-1])
summon hopper_minecart ~ 320 ~ {Tags:["wm_temp"],Items:[]}
item replace entity @e[type=hopper_minecart,tag=wm_temp,limit=1] container.0 from entity @s weapon.mainhand
data modify entity @e[type=hopper_minecart,tag=wm_temp,limit=1] Items[0].components."minecraft:lore" append value ""
data modify entity @e[type=hopper_minecart,tag=wm_temp,limit=1] Items[0].components."minecraft:lore" append value {text:"◆ Mastery: Lv.0 (0/5 XP)",color:"yellow",italic:false}
item replace entity @s weapon.mainhand from entity @e[type=hopper_minecart,tag=wm_temp,limit=1] container.0
data modify entity @e[type=hopper_minecart,tag=wm_temp,limit=1] Items set value []
kill @e[type=hopper_minecart,tag=wm_temp]

# Feedback
data modify storage evercraft:notify stage.c set value [{text:"Your weapon stirs with newfound power!",color:"light_purple"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.enchantment_table.use master @s ~ ~ ~ 1.0 1.5
particle minecraft:enchant ~ ~1 ~ 0.5 0.5 0.5 1 30 force @s