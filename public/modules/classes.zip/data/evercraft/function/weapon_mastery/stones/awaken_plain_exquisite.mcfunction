# === AWAKEN A PLAIN (UNTIERED) GATHERING TOOL — Exquisite (Classes Enhancement Ship A, 2026-05-28) ===
# See awaken_plain_ornate.mcfunction for the design notes.

item modify entity @s weapon.mainhand evercraft:weapon_mastery/awaken_plain_exquisite

# Lifetime milestone counter: +1 per gear piece awakened (combined weapon+armor tally — see
# stones/awaken.mcfunction for the disjoint-writer note). Gated upstream by `unless ...awakened:1b`.
scoreboard players add @s ec.wm_maxed 1

summon hopper_minecart ~ 320 ~ {Tags:["wm_temp"],Items:[]}
item replace entity @e[type=hopper_minecart,tag=wm_temp,limit=1] container.0 from entity @s weapon.mainhand
data modify entity @e[type=hopper_minecart,tag=wm_temp,limit=1] Items[0].components."minecraft:lore" append value ""
data modify entity @e[type=hopper_minecart,tag=wm_temp,limit=1] Items[0].components."minecraft:lore" append value {text:"◆ Mastery: Lv.0 (0/5 XP)",color:"yellow",italic:false}
item replace entity @s weapon.mainhand from entity @e[type=hopper_minecart,tag=wm_temp,limit=1] container.0
data modify entity @e[type=hopper_minecart,tag=wm_temp,limit=1] Items set value []
kill @e[type=hopper_minecart,tag=wm_temp]

data modify storage evercraft:notify stage.c set value [{text:"Your tool stirs with crafting power!",color:"aqua"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.enchantment_table.use master @s ~ ~ ~ 1.0 1.3
particle minecraft:enchant ~ ~1 ~ 0.5 0.5 0.5 1 30 force @s
