# Macro function — $(tier) is the stone tier
# Re-give the consumed stone
# Inv-full guard: drop at the player's feet rather than void on a full inventory.
execute store result score #inv_full ec.var run function evercraft:util/check_inv_full
$execute if score #inv_full ec.var matches 0 run loot give @s loot evercraft:weapon_mastery/stones/$(tier)_stone
$execute if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:weapon_mastery/stones/$(tier)_stone
$data modify storage evercraft:notify stage.c set value [{text:"This stone can only awaken ",color:"red"},{text:"$(tier)",color:"yellow"},{text:" artifacts. Hold a weapon or wear matching armor!",color:"red"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 0.8 0.5
