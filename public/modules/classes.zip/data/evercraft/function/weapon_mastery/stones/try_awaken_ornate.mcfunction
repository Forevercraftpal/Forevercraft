# Awakening Stone — Ornate tier

advancement revoke @s only evercraft:weapon_mastery/stones/consume_ornate

# Priority 1: Check mainhand
execute if items entity @s weapon.mainhand *[custom_data~{is_artifact:true,tier:"ornate"}] unless items entity @s weapon.mainhand *[custom_data~{awakened:1b}] run return run function evercraft:weapon_mastery/stones/awaken
execute if items entity @s weapon.mainhand *[custom_data~{is_artifact:true,tier:"ornate",awakened:1b}] run return run function evercraft:weapon_mastery/stones/fail_already_awakened {tier:"ornate"}

# Priority 2: Check offhand (for functional weapons: rods, bows, shields, tridents)
execute if items entity @s weapon.offhand *[custom_data~{is_artifact:true,tier:"ornate"}] unless items entity @s weapon.offhand *[custom_data~{awakened:1b}] run return run function evercraft:weapon_mastery/stones/awaken_offhand
execute if items entity @s weapon.offhand *[custom_data~{is_artifact:true,tier:"ornate",awakened:1b}] run return run function evercraft:weapon_mastery/stones/fail_already_awakened {tier:"ornate"}

# Priority 3: Check armor slots
execute if items entity @s armor.head *[custom_data~{is_artifact:true,tier:"ornate"}] unless items entity @s armor.head *[custom_data~{awakened:1b}] run return run function evercraft:armor_mastery/awaken {slot:"head"}
execute if items entity @s armor.chest *[custom_data~{is_artifact:true,tier:"ornate"}] unless items entity @s armor.chest *[custom_data~{awakened:1b}] run return run function evercraft:armor_mastery/awaken {slot:"chest"}
execute if items entity @s armor.legs *[custom_data~{is_artifact:true,tier:"ornate"}] unless items entity @s armor.legs *[custom_data~{awakened:1b}] run return run function evercraft:armor_mastery/awaken {slot:"legs"}
execute if items entity @s armor.feet *[custom_data~{is_artifact:true,tier:"ornate"}] unless items entity @s armor.feet *[custom_data~{awakened:1b}] run return run function evercraft:armor_mastery/awaken {slot:"feet"}

# Priority 4: Plain gathering tool already tagged tier:"ornate" (no awakened, no is_artifact).
# Stamps awakened:1b via the existing awaken modifier (merge:true preserves tier).
# Classes Enhancement Ship A (2026-05-28) — RESOLVED #6: extend stones to plain gathering tools.
execute if items entity @s weapon.mainhand #evercraft:gathering_tools[custom_data~{tier:"ornate"}] unless items entity @s weapon.mainhand *[custom_data~{is_artifact:true}] unless items entity @s weapon.mainhand *[custom_data~{awakened:1b}] run return run function evercraft:weapon_mastery/stones/awaken

# Priority 5: Plain UNTIERED gathering tool (no tier of any kind, no awakened, no is_artifact).
# Stamps awakened:1b + tier:"ornate" so read_sig_tier resolves to 4 (Ornate signature scale).
execute if items entity @s weapon.mainhand #evercraft:gathering_tools unless items entity @s weapon.mainhand *[custom_data~{is_artifact:true}] unless items entity @s weapon.mainhand *[custom_data~{awakened:1b}] unless items entity @s weapon.mainhand *[custom_data~{tier:"common"}] unless items entity @s weapon.mainhand *[custom_data~{tier:"uncommon"}] unless items entity @s weapon.mainhand *[custom_data~{tier:"rare"}] unless items entity @s weapon.mainhand *[custom_data~{tier:"ornate"}] unless items entity @s weapon.mainhand *[custom_data~{tier:"exquisite"}] unless items entity @s weapon.mainhand *[custom_data~{tier:"mythical"}] run return run function evercraft:weapon_mastery/stones/awaken_plain_ornate

function evercraft:weapon_mastery/stones/fail_wrong_weapon {tier:"ornate"}
