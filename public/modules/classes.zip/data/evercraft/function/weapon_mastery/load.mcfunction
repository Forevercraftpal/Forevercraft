# Weapon Mastery — Load/Init
# Register scoreboards
scoreboard objectives add wm.prev_xp dummy
scoreboard objectives add wm.curr_xp dummy
scoreboard objectives add wm.xp_gained dummy

# Lifetime milestone counter: total gear pieces awakened (weapon + armor combined; armor_mastery
# reuses this system, so it's declared here once). Monotonic +1 at each awaken-apply site.
scoreboard objectives add ec.wm_maxed dummy "Gear Pieces Awakened"

# Start XP tick schedule (10t = 0.5s — XP changes aren't time-critical)
schedule function evercraft:weapon_mastery/xp_tick 10t
