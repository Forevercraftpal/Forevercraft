# === BOUGH STRIKER — QUAKE TICK (1s) ===
# C1 Heavy Strike melee attribute (reconciled, active-gated; stripped on unequip in
# artifacts/striker/remove) + C12 Tireless Stride slow-immunity. The combat riders themselves
# are event-driven (artifacts/striker/on_hit → bough/striker/quake/hit); this tick only carries
# the always-on bits.
execute unless entity @a[tag=ec.sk_active,scores={ec.sk_b_combat=1..}] run return run schedule function evercraft:bough/striker/quake/tick 20t

# C1 Heavy Strike (+2 mace damage) — reconciled while active.
execute as @a[scores={ec.sk_n_c1=1..},tag=ec.sk_active] run attribute @s minecraft:attack_damage modifier remove evercraft:bough_sk_c1
execute as @a[scores={ec.sk_n_c1=1..},tag=ec.sk_active] run attribute @s minecraft:attack_damage modifier add evercraft:bough_sk_c1 2 add_value
execute as @a unless score @s ec.sk_n_c1 matches 1.. run attribute @s minecraft:attack_damage modifier remove evercraft:bough_sk_c1
execute as @a[tag=!ec.sk_active] run attribute @s minecraft:attack_damage modifier remove evercraft:bough_sk_c1

# C12 Tireless Stride — cannot be slowed (clear Slowness each second).
execute as @a[scores={ec.sk_n_c12=1..},tag=ec.sk_active] run effect clear @s minecraft:slowness

schedule function evercraft:bough/striker/quake/tick 20t
