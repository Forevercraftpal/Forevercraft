# === BOUGH STRIKER — TECTONIC STRIDE (C8) ===
# @s = the striker, at @s, on the 5th strike. A small Ground Slam: 5 magic damage in a 3-block
# AoE (Cleaving Mace C10 adds +3 to ALL mace AoE). ec.aff_attacker + sk.quake_src are already
# set by quake/hit (nested-reward suppression + attribution).
scoreboard players set @s ec.sk_tec_count 0
scoreboard players set #sk_tec ec.temp 5
execute if score @s ec.sk_n_c10 matches 1.. run scoreboard players add #sk_tec ec.temp 3
execute store result storage evercraft:bough_combat dmg int 1 run scoreboard players get #sk_tec ec.temp
execute at @s as @e[type=#evercraft:aoe_targets,distance=..3] run function evercraft:bough/striker/quake/tectonic_deal with storage evercraft:bough_combat
execute at @s run particle minecraft:explosion ~ ~0.3 ~ 1.2 0.2 1.2 0.1 6
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.anvil.land master @s ~ ~ ~ 0.6 0.6
