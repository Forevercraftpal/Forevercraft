# === BOUGH STRIKER — CROWN APPLY (Earthbreak) ===
# Run as @s = active striker owning the Crown, IN COMBAT (RETUNE 2). Called by
# crown_tick only while ec.sk_combat is 1.. (artifacts/striker combat timer —
# set to 100t on hit/block/kill, drained 1/t). Applies the -30% movement speed,
# reconciled idempotently each second while combat lasts; crown_tick strips the
# modifier the second the combat timer expires, so out-of-combat speed is normal.
#
# Wave 13 damage-event hooks (2026-06-11) — ledger:
#   - [DONE Wave 13] every-5th-strike free Ground Slam: ec.sk_strike_count
#     (declared in load, reset in crown_remove) increments per REAL mace strike
#     in artifacts/striker/on_hit — the striker player_hurt_entity seam. The
#     `unless ec.aff_attacker` guard there excludes nested slam/ability AoE
#     rewards (affinity damage is dealt `by` the player, so AoE hits re-fire
#     on_hit) — without it a 5-target slam would chain-arm the next slam.
#     At 5 → bough/striker/crown_strike: fires artifacts/striker/ground_slam,
#     then restores Impact + cooldown (free = no Impact cost, no cd; magnitude
#     still scales with CURRENT Impact, min 3-block slam below 25). RETUNE 2
#     honored: the proc is NOT combat-gated — only the movement penalty is.
#   - [TODO] M5 Crown's Mountain is unwired on both halves: "+1 block slam
#     range" (ground_slam radii are hardcoded 3/5/7 — needs a radius-param
#     variant) and "movement penalty -20%" (this file applies flat -0.3).
#     Attribute-side work, not damage-event wiring — future wave.
attribute @s minecraft:movement_speed modifier remove evercraft:earthbreak_slow
attribute @s minecraft:movement_speed modifier add evercraft:earthbreak_slow -0.3 add_multiplied_base
