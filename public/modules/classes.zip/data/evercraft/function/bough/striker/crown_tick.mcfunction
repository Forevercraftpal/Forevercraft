# === BOUGH STRIKER — CROWN TICK (1s) ===
# Earthbreak: every 5th strike triggers a free Ground Slam — WIRED (Wave 13)
# event-side in artifacts/striker/on_hit → bough/striker/crown_strike (this
# tick only owns the movement penalty). The -30% movement speed is IN-COMBAT-ONLY
# (RETUNE 2): while ec.sk_combat is 1.. (artifacts/striker combat timer)
# crown_apply reconciles the modifier on each second; when the timer hits 0
# the modifier is stripped here, so out-of-combat speed is normal.
execute unless entity @a[tag=ec.sk_active,scores={ec.sk_b_crown=1}] run return run schedule function evercraft:bough/striker/crown_tick 20t
execute as @a[tag=ec.sk_active,scores={ec.sk_b_crown=1,ec.sk_combat=1..}] at @s run function evercraft:bough/striker/crown_apply
execute as @a[tag=ec.sk_active,scores={ec.sk_b_crown=1}] unless score @s ec.sk_combat matches 1.. run attribute @s minecraft:movement_speed modifier remove evercraft:earthbreak_slow
schedule function evercraft:bough/striker/crown_tick 20t
