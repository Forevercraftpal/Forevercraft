# === BOUGH STRIKER — M2 PEBBLE HANDS (Wave 37, stone-pickup adv reward) ===
# Pivot: spec's "double prospect-charge to your next ore strike" refers to a
# Prospector resource that was never wired in the Striker codepath (only U12
# Cornerstone text mentions it). Replacement effect: mining stone-tier blocks
# while the mace is active grants +3 Impact (capped at 100 — same ceiling as
# the on_hit accumulator), so the smith "charges off the rock" before slamming.
advancement revoke @s only evercraft:bough/sk_m2_stone
execute unless score @s ec.sk_n_m2 matches 1.. run return 0
execute unless entity @s[tag=ec.sk_active] run return 0
scoreboard players add @s ec.sk_impact 3
# Mirror the on_hit cap branches (ec.sk_sentinel = lower cap).
execute if entity @s[tag=!ec.sk_sentinel] if score @s ec.sk_impact matches 101.. run scoreboard players set @s ec.sk_impact 100
execute if entity @s[tag=ec.sk_sentinel] if score @s ec.sk_impact matches 76.. run scoreboard players set @s ec.sk_impact 75
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.stone.hit master @s ~ ~ ~ 0.3 0.6
