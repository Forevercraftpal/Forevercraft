# === BOUGH STRIKER — CROWN STRIKE (Earthbreak 5th strike, Wave 13) ===
# @s = active striker, mace verified by caller (artifacts/striker/on_hit fires
# this via `return run` on the 5th counted strike, superseding the same-hit
# paid fortress/slam checks — no same-hit double-slam). FREE Ground Slam:
# reuses artifacts/striker/ground_slam for the magnitude branches / FX /
# voidshatter, then restores the Impact + cooldown it consumed. Magnitude
# still scales with CURRENT Impact (below 25 = the minimum 3-block slam).
# NOTE: nested slam-hit Impact refunds (+8/target via re-fired on_hit) are
# wiped by the snapshot restore — the free slam leaves Impact exactly as it
# found it, by design.

# Reset the counter FIRST: nested on_hit rewards fired by the slam's AoE
# damage must see 0 (they're also increment-guarded by ec.aff_attacker).
scoreboard players set @s ec.sk_strike_count 0

# Snapshot the resources ground_slam consumes/sets
scoreboard players operation #sk_cs_imp ec.var = @s ec.sk_impact
scoreboard players operation #sk_cs_cd ec.var = @s ec.sk_cd

execute at @s run function evercraft:artifacts/striker/ground_slam

# Restore — free slam: no Impact cost, no cooldown
scoreboard players operation @s ec.sk_impact = #sk_cs_imp ec.var
scoreboard players operation @s ec.sk_cd = #sk_cs_cd ec.var

# Re-apply the Impact caps the superseded on_hit tail would have applied
execute if entity @s[tag=!ec.sk_sentinel] if score @s ec.sk_impact matches 101.. run scoreboard players set @s ec.sk_impact 100
execute if entity @s[tag=ec.sk_sentinel] if score @s ec.sk_impact matches 76.. run scoreboard players set @s ec.sk_impact 75
