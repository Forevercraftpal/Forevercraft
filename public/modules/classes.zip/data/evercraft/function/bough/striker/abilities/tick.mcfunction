# === BOUGH STRIKER — WAR-PREP TICK (1s) ===
# Drains the per-class war-prep duration/cooldown, applies the active mode's SUSTAINED
# effect (class-only via the active gate), announces the fade. Rider signatures detonate
# in the combat hit path (see bough/abilities/on_melee_hit or the class projectile hook).
execute unless entity @a[scores={ec.sk_abil_cd=1..}] unless entity @a[scores={ec.sk_abil_id=1..}] run return run schedule function evercraft:bough/striker/abilities/tick 20t
scoreboard players remove @a[scores={ec.sk_abil_cd=1..}] ec.sk_abil_cd 1
scoreboard players remove @a[scores={ec.sk_abil_dur=1..}] ec.sk_abil_dur 1
execute as @a[scores={ec.sk_abil_dur=0,ec.sk_abil_id=1..}] run tellraw @s [{text:"⚔ ",color:"gray"},{text:"War-prep faded.",color:"gray",italic:true}]
scoreboard players set @a[scores={ec.sk_abil_dur=0,ec.sk_abil_id=1..}] ec.sk_abil_id 0
# id 2 Tremorlord
execute as @a[tag=ec.sk_active,scores={ec.sk_abil_id=2,ec.sk_abil_dur=1..}] run effect give @s minecraft:strength 2 1 true
# id 3 Stoneblood
execute as @a[tag=ec.sk_active,scores={ec.sk_abil_id=3,ec.sk_abil_dur=1..}] run effect give @s minecraft:resistance 2 1 true
# id 11 Earthwrath
execute as @a[tag=ec.sk_active,scores={ec.sk_abil_id=11,ec.sk_abil_dur=1..}] run effect give @s minecraft:strength 2 1 true
# id 12 Stoneguard
execute as @a[tag=ec.sk_active,scores={ec.sk_abil_id=12,ec.sk_abil_dur=1..}] run effect give @s minecraft:resistance 2 0 true
# id 13 Quaketrack
execute as @a[tag=ec.sk_active,scores={ec.sk_abil_id=13,ec.sk_abil_dur=1..}] run effect give @s minecraft:speed 2 1 true
# id 14 Lithify
execute as @a[tag=ec.sk_active,scores={ec.sk_abil_id=14,ec.sk_abil_dur=1..}] run effect give @s minecraft:resistance 2 2 true
execute as @a[tag=ec.sk_active,scores={ec.sk_abil_id=14,ec.sk_abil_dur=1..}] run effect give @s minecraft:absorption 2 1 true
schedule function evercraft:bough/striker/abilities/tick 20t
