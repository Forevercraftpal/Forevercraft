# === BOUGH STRIKER — M4 LITHIFY (Wave 37, fired from mastery_tick) ===
# Triggered when an M4-unlocked Striker with mace active drops to ≤5 HP and
# cooldown is ready. Grants Resistance II + Absorption + 3-block AoE knockback
# (the "earth pulls them under" beat). Sets 60s cooldown. Spec pivot: the
# original "become a stone, can't move/attack, AoE on exit" needed a control-
# lock surface (no vanilla freeze) — Resistance II + Absorption + slam-pulse
# captures the "smith goes stoneward, the earth pushes" beat without the
# cancel-control layer.
effect give @s minecraft:resistance 3 1 true
effect give @s minecraft:absorption 5 1 true

# AoE knockback via tag-source: tag the smith so the inner @e damage finds
# them as the attacker (vanilla knockback emanates from `by` target's pos).
# Tag is sequential within this function — safe even if multiple smiths proc
# in the same /reload tick (mastery_tick iterates serially).
tag @s add ec.sk_m4_lith_src
execute at @s as @e[type=#evercraft:aoe_targets,distance=..3] run damage @s 1 minecraft:explosion by @e[tag=ec.sk_m4_lith_src,limit=1]
tag @s remove ec.sk_m4_lith_src

particle minecraft:explosion ~ ~0.5 ~ 1.0 0.2 1.0 0.05 5
title @s actionbar [{text:"⛰ Lithify ",color:"dark_gray",bold:true},{text:"— the earth holds you",color:"gray",italic:true}]
execute as @a[distance=..16] if score @s ec.fx_snd matches 1.. run playsound minecraft:block.anvil.land master @s ~ ~ ~ 0.6 0.4
execute as @a[distance=..16] if score @s ec.fx_snd matches 1.. run playsound minecraft:block.stone.break master @s ~ ~ ~ 0.7 0.5
scoreboard players set @s ec.sk_m4_cd 60
