# === BOUGH STRIKER — CROWN REMOVE ===
# Strips the Earthbreak movement-speed modifier from @s. Idempotent.
attribute @s minecraft:movement_speed modifier remove evercraft:earthbreak_slow
# Wave 13: clear the 5th-strike counter so a re-bought Crown starts fresh.
scoreboard players set @s ec.sk_strike_count 0
