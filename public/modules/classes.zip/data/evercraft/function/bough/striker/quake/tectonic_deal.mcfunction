# === BOUGH STRIKER — TECTONIC SLAM DEAL (macro) ===
# @s = an aoe_target in the Tectonic Stride zone. Clear i-frames so the slam lands through the
# triggering hit's fresh invulnerability, then deal $(dmg) magic credited to the striker.
data modify entity @s HurtTime set value 0s
$damage @s $(dmg) minecraft:magic by @e[tag=sk.quake_src,limit=1,sort=nearest]
