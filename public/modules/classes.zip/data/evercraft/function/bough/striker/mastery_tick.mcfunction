# === BOUGH STRIKER — MASTERY TICK (1s, Wave 37) ===
# Per-tick consumers for unlocked Mastery nodes. M1/M2/M3/M5 fire inline in
# ground_slam.mcfunction / inventory_changed; only M4 needs a tick surface
# (HP-threshold panic save with cooldown).
#
# Existence-gate: stop scheduling when no eligible player has M4 unlocked.
execute unless entity @a[scores={ec.sk_n_m4=1..}] run return run schedule function evercraft:bough/striker/mastery_tick 20t

# Decrement M4 cooldown for everyone with active timer (1s cadence = 1 unit/s).
scoreboard players remove @a[scores={ec.sk_m4_cd=1..}] ec.sk_m4_cd 1

# M4 Lithify (pivot): Health ≤ 5 + mace active + cooldown ready → Resistance II
# 3s + Absorption 5s, then 60s cooldown. Spec's "become a stone for 3s, on
# exit AoE knockback" required a damage-immunity stance + custom-control lock
# that doesn't exist as a surface; the resistance + absorption + slam-knockback
# proxy reads as "earth holds you under" without the cancel-control layer.
execute as @a[scores={ec.sk_n_m4=1..,ec.sk_m4_cd=..0},tag=ec.sk_active] store result score @s ec.sk_m4_hp run data get entity @s Health 1
execute as @a[scores={ec.sk_n_m4=1..,ec.sk_m4_cd=..0,ec.sk_m4_hp=..5},tag=ec.sk_active] at @s run function evercraft:bough/striker/m4_lithify

schedule function evercraft:bough/striker/mastery_tick 20t
