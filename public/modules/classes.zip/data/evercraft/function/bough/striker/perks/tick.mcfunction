# === BOUGH STRIKER — PERMANENT PERK TICK (1s, ACCOUNT-WIDE) ===
# Striker utility perks are PERMANENT + CROSS-CLASS: gated on the node-bought flag, NOT the
# class — kept while playing anything (multiclass reward). Gate: any striker progress
# (ec.sk_lvl>=1). Theme = the earthshaper (mining Haste + stone armor + sturdiness). Attribute
# perks: remove-for-all then add-for-owners. Probe ec.sk_phealth. Pollen U3/U5/U6 untouched.
# U7 Stoneskin is conditional on low HP.
execute unless entity @a[scores={ec.sk_lvl=1..}] run return run schedule function evercraft:bough/striker/perks/tick 20t

# --- MINING (U1 Ore-finder Haste I · U12 Cornerstone Haste I) ---
execute as @a[scores={ec.sk_n_u1=1..}] run effect give @s minecraft:haste 2 0 true
execute as @a[scores={ec.sk_n_u12=1..}] run effect give @s minecraft:haste 2 0 true

# --- ARMOR (U2 Stonecut +1 · U4 Earthwarden +1) ---
execute as @a[scores={ec.sk_lvl=1..}] run attribute @s minecraft:armor modifier remove evercraft:sk_perk_u2
execute as @a[scores={ec.sk_n_u2=1..}] run attribute @s minecraft:armor modifier add evercraft:sk_perk_u2 1 add_value
execute as @a[scores={ec.sk_lvl=1..}] run attribute @s minecraft:armor modifier remove evercraft:sk_perk_u4
execute as @a[scores={ec.sk_n_u4=1..}] run attribute @s minecraft:armor modifier add evercraft:sk_perk_u4 1 add_value

# --- STONESKIN (U7): +2 armor while below 30% HP (≤6) — conditional, account-wide ---
execute as @a[scores={ec.sk_lvl=1..}] store result score @s ec.sk_phealth run data get entity @s Health 1
execute as @a[scores={ec.sk_lvl=1..}] run attribute @s minecraft:armor modifier remove evercraft:sk_perk_u7
execute as @a[scores={ec.sk_n_u7=1..,ec.sk_phealth=..6}] run attribute @s minecraft:armor modifier add evercraft:sk_perk_u7 2 add_value

# --- KNOCKBACK RESISTANCE (U8 Ironfooted · U10 Grounded = +0.2 each) ---
execute as @a[scores={ec.sk_lvl=1..}] run attribute @s minecraft:knockback_resistance modifier remove evercraft:sk_perk_u8
execute as @a[scores={ec.sk_n_u8=1..}] run attribute @s minecraft:knockback_resistance modifier add evercraft:sk_perk_u8 0.2 add_value
execute as @a[scores={ec.sk_lvl=1..}] run attribute @s minecraft:knockback_resistance modifier remove evercraft:sk_perk_u10
execute as @a[scores={ec.sk_n_u10=1..}] run attribute @s minecraft:knockback_resistance modifier add evercraft:sk_perk_u10 0.2 add_value

# --- HEALTH (U9 Bedrock · U11 Mountain Heart · U12 Cornerstone = +1 heart each) ---
execute as @a[scores={ec.sk_lvl=1..}] run attribute @s minecraft:max_health modifier remove evercraft:sk_perk_u9
execute as @a[scores={ec.sk_n_u9=1..}] run attribute @s minecraft:max_health modifier add evercraft:sk_perk_u9 2 add_value
execute as @a[scores={ec.sk_lvl=1..}] run attribute @s minecraft:max_health modifier remove evercraft:sk_perk_u11
execute as @a[scores={ec.sk_n_u11=1..}] run attribute @s minecraft:max_health modifier add evercraft:sk_perk_u11 2 add_value
execute as @a[scores={ec.sk_lvl=1..}] run attribute @s minecraft:max_health modifier remove evercraft:sk_perk_u12
execute as @a[scores={ec.sk_n_u12=1..}] run attribute @s minecraft:max_health modifier add evercraft:sk_perk_u12 2 add_value

# === MILESTONE PASSIVES (lvl 1/6/12, account-wide, earth-thematic) ===
# Lvl 1 Tremorproof — Knockback Resistance +0.1.
execute as @a[scores={ec.sk_lvl=1..}] run attribute @s minecraft:knockback_resistance modifier remove evercraft:sk_ms1
execute as @a[scores={ec.sk_lvl=1..}] run attribute @s minecraft:knockback_resistance modifier add evercraft:sk_ms1 0.1 add_value
# Lvl 6 Granite — +1 armor.
execute as @a[scores={ec.sk_lvl=6..}] run attribute @s minecraft:armor modifier remove evercraft:sk_ms6
execute as @a[scores={ec.sk_lvl=6..}] run attribute @s minecraft:armor modifier add evercraft:sk_ms6 1 add_value
# Lvl 12 Tectonic — +1 heart + +1 armor.
execute as @a[scores={ec.sk_lvl=12..}] run attribute @s minecraft:max_health modifier remove evercraft:sk_ms12
execute as @a[scores={ec.sk_lvl=12..}] run attribute @s minecraft:max_health modifier add evercraft:sk_ms12 2 add_value
execute as @a[scores={ec.sk_lvl=12..}] run attribute @s minecraft:armor modifier remove evercraft:sk_ms12a
execute as @a[scores={ec.sk_lvl=12..}] run attribute @s minecraft:armor modifier add evercraft:sk_ms12a 1 add_value

# Milestone unlock chat (one-time each)
execute as @a[scores={ec.sk_lvl=1..}] unless score @s ec.sk_msn1 matches 1 run tellraw @s [{text:"✦ Striker Mastery 1 — ",color:"gray"},{text:"Tremorproof",color:"white",bold:true},{text:" unlocked. Knockback resistance. Permanent, all classes.",color:"gray"}]
scoreboard players set @a[scores={ec.sk_lvl=1..}] ec.sk_msn1 1
execute as @a[scores={ec.sk_lvl=6..}] unless score @s ec.sk_msn6 matches 1 run tellraw @s [{text:"✦ Striker Mastery 6 — ",color:"gray"},{text:"Granite",color:"white",bold:true},{text:" unlocked. +1 armor. Permanent, all classes.",color:"gray"}]
scoreboard players set @a[scores={ec.sk_lvl=6..}] ec.sk_msn6 1
execute as @a[scores={ec.sk_lvl=12..}] unless score @s ec.sk_msn12 matches 1 run tellraw @s [{text:"✦ Striker Mastery 12 — ",color:"gray"},{text:"Tectonic",color:"white",bold:true},{text:" unlocked. +1 heart and +1 armor. Permanent, all classes.",color:"gray"}]
scoreboard players set @a[scores={ec.sk_lvl=12..}] ec.sk_msn12 1

schedule function evercraft:bough/striker/perks/tick 20t
