# === BOUGH STRIKER — BLEED TICK (1s) ===
# Stoneblood (C4) bleed DoT. Existence-gated. Bleeding entities lose 1 HP/s (magic, i-frames
# cleared so it always lands); ec.sk_bleed counts down the remaining seconds. Dealt with NO
# attacker (chip DoT — recursion-free, no kill-credit needed).
execute unless entity @e[tag=sk.bleed] run return run schedule function evercraft:bough/striker/quake/bleed_tick 20t
execute as @e[tag=sk.bleed] run data modify entity @s HurtTime set value 0s
execute as @e[tag=sk.bleed] run damage @s 1 minecraft:magic
scoreboard players remove @e[tag=sk.bleed] ec.sk_bleed 1
execute as @e[tag=sk.bleed,scores={ec.sk_bleed=..0}] run tag @s remove sk.bleed
schedule function evercraft:bough/striker/quake/bleed_tick 20t
