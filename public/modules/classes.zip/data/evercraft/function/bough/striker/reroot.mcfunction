# === BOUGH STRIKER — REROOT ===
scoreboard players set @s ec.sk_b_combat 0
scoreboard players set @s ec.sk_b_util 0
scoreboard players set @s ec.sk_b_mast 0
scoreboard players set @s ec.sk_b_crown 0
scoreboard players set @s ec.sk_n_c1 0
scoreboard players set @s ec.sk_n_c2 0
scoreboard players set @s ec.sk_n_c3 0
scoreboard players set @s ec.sk_n_c4 0
scoreboard players set @s ec.sk_n_c5 0
scoreboard players set @s ec.sk_n_c6 0
scoreboard players set @s ec.sk_n_c7 0
scoreboard players set @s ec.sk_n_c8 0
scoreboard players set @s ec.sk_n_c9 0
scoreboard players set @s ec.sk_n_c10 0
scoreboard players set @s ec.sk_n_c11 0
scoreboard players set @s ec.sk_n_c12 0
scoreboard players set @s ec.sk_n_u1 0
scoreboard players set @s ec.sk_n_u2 0
scoreboard players set @s ec.sk_n_u3 0
scoreboard players set @s ec.sk_n_u4 0
scoreboard players set @s ec.sk_n_u5 0
scoreboard players set @s ec.sk_n_u6 0
scoreboard players set @s ec.sk_n_u7 0
scoreboard players set @s ec.sk_n_u8 0
scoreboard players set @s ec.sk_n_u9 0
scoreboard players set @s ec.sk_n_u10 0
scoreboard players set @s ec.sk_n_u11 0
scoreboard players set @s ec.sk_n_u12 0
scoreboard players set @s ec.sk_n_m1 0
scoreboard players set @s ec.sk_n_m2 0
scoreboard players set @s ec.sk_n_m3 0
scoreboard players set @s ec.sk_n_m4 0
scoreboard players set @s ec.sk_n_m5 0
# Mastery consumer state reset (Wave 37).
scoreboard players set @s ec.sk_m4_cd 0
function evercraft:bough/striker/crown_remove
