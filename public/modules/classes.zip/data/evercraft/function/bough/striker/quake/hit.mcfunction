# === BOUGH STRIKER — QUAKE ON-HIT RIDERS ===
# Called from artifacts/striker/on_hit (gated: holding striker mace, ec.sk_b_combat>=1, and
# `unless ec.aff_attacker` so it skips the nested re-fires from AoE damage). @s = the striker,
# at @s. We set ec.aff_attacker for the whole rider block so OUR own bonus-damage `by @s` can't
# recursively re-arm on_hit (the slam/affinity guard pattern). Fresh-hit target = the HurtTime
# entity within melee range, tagged sk.hit_tgt up front.
execute as @e[type=!player,sort=nearest,limit=1,distance=..6,nbt={HurtTime:10s}] run tag @s add sk.hit_tgt
execute unless entity @e[tag=sk.hit_tgt] run return 0
tag @s add ec.aff_attacker
tag @s add sk.quake_src

# --- TARGET DEBUFFS (C2 Concussive Force Slowness I · C6 Hammerfist Slowness II stun) ---
execute if score @s ec.sk_n_c2 matches 1.. as @e[tag=sk.hit_tgt] run effect give @s minecraft:slowness 2 0 true
execute if score @s ec.sk_n_c6 matches 1.. as @e[tag=sk.hit_tgt] run effect give @s minecraft:slowness 2 1 true

# --- SPLASH (C3 Crater Step ≤3 · C7 Tremor ≤4) — magic ripple around the target ---
execute if score @s ec.sk_n_c3 matches 1.. at @e[tag=sk.hit_tgt] as @e[type=#evercraft:hostile_mobs,distance=..3] run damage @s 1 minecraft:magic by @e[tag=sk.quake_src,limit=1,sort=nearest]
execute if score @s ec.sk_n_c7 matches 1.. at @e[tag=sk.hit_tgt] as @e[type=#evercraft:hostile_mobs,distance=..4] run damage @s 1 minecraft:magic by @e[tag=sk.quake_src,limit=1,sort=nearest]

# --- C11 Granite Edge: +3 armor-piercing magic on the target (clear i-frames first) ---
execute if score @s ec.sk_n_c11 matches 1.. as @e[tag=sk.hit_tgt] run data modify entity @s HurtTime set value 0s
execute if score @s ec.sk_n_c11 matches 1.. as @e[tag=sk.hit_tgt] run damage @s 3 minecraft:magic by @e[tag=sk.quake_src,limit=1,sort=nearest]

# --- C4 Stoneblood: apply Bleed (DoT) to the target — 1 magic/s for 5s (bleed_tick) ---
execute if score @s ec.sk_n_c4 matches 1.. as @e[tag=sk.hit_tgt] run tag @s add sk.bleed
execute if score @s ec.sk_n_c4 matches 1.. as @e[tag=sk.hit_tgt] run scoreboard players set @s ec.sk_bleed 5

# --- C9 Earthen Wrath: surrounded by 3+ foes → Resistance I ---
scoreboard players set #sk_foes ec.temp 0
execute if score @s ec.sk_n_c9 matches 1.. as @e[type=#evercraft:hostile_mobs,distance=..5] run scoreboard players add #sk_foes ec.temp 1
execute if score @s ec.sk_n_c9 matches 1.. if score #sk_foes ec.temp matches 3.. run effect give @s minecraft:resistance 2 0 true

# --- C8 Tectonic Stride: every 5th strike → a small Ground Slam ---
execute if score @s ec.sk_n_c8 matches 1.. run scoreboard players add @s ec.sk_tec_count 1
execute if score @s ec.sk_n_c8 matches 1.. if score @s ec.sk_tec_count matches 5.. run function evercraft:bough/striker/quake/tectonic

tag @s remove sk.quake_src
tag @s remove ec.aff_attacker
execute as @e[tag=sk.hit_tgt] run tag @s remove sk.hit_tgt
