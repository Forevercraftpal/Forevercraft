# === BOUGH STRIKER — LOAD ===
scoreboard objectives add ec.sk_b_combat dummy "Bough SK Combat Points"
scoreboard objectives add ec.sk_b_util dummy "Bough SK Utility Points"
scoreboard objectives add ec.sk_b_mast dummy "Bough SK Mastery Points"
scoreboard objectives add ec.sk_b_crown dummy "Bough SK Crown Owned"
# Wave 13: Earthbreak 5th-strike counter. Incremented per real mace strike in
# artifacts/striker/on_hit (crown-gated, ec.aff_attacker-guarded); reset by
# bough/striker/crown_strike on proc and by crown_remove on crown loss.
scoreboard objectives add ec.sk_strike_count dummy "Bough SK Crown Strike Count"
scoreboard objectives add ec.sk_bough_view dummy "Bough SK Codex View"
scoreboard objectives add ec.sk_lx dummy "Bough SK Last X"
scoreboard objectives add ec.sk_lz dummy "Bough SK Last Z"
scoreboard objectives add ec.sk_lyaw dummy "Bough SK Last Yaw"
scoreboard objectives add ec.sk_n_c1 dummy "SK C1"
scoreboard objectives add ec.sk_n_c2 dummy "SK C2"
scoreboard objectives add ec.sk_n_c3 dummy "SK C3"
scoreboard objectives add ec.sk_n_c4 dummy "SK C4"
scoreboard objectives add ec.sk_n_c5 dummy "SK C5"
scoreboard objectives add ec.sk_n_c6 dummy "SK C6"
scoreboard objectives add ec.sk_n_c7 dummy "SK C7"
scoreboard objectives add ec.sk_n_c8 dummy "SK C8"
scoreboard objectives add ec.sk_n_c9 dummy "SK C9"
scoreboard objectives add ec.sk_n_c10 dummy "SK C10"
scoreboard objectives add ec.sk_n_c11 dummy "SK C11"
scoreboard objectives add ec.sk_n_c12 dummy "SK C12"
scoreboard objectives add ec.sk_n_u1 dummy "SK U1"
scoreboard objectives add ec.sk_n_u2 dummy "SK U2"
scoreboard objectives add ec.sk_n_u3 dummy "SK U3"
scoreboard objectives add ec.sk_n_u4 dummy "SK U4"
scoreboard objectives add ec.sk_n_u5 dummy "SK U5"
scoreboard objectives add ec.sk_n_u6 dummy "SK U6"
scoreboard objectives add ec.sk_n_u7 dummy "SK U7"
scoreboard objectives add ec.sk_n_u8 dummy "SK U8"
scoreboard objectives add ec.sk_n_u9 dummy "SK U9"
scoreboard objectives add ec.sk_n_u10 dummy "SK U10"
scoreboard objectives add ec.sk_n_u11 dummy "SK U11"
scoreboard objectives add ec.sk_n_u12 dummy "SK U12"
scoreboard objectives add ec.sk_n_m1 dummy "SK M1"
scoreboard objectives add ec.sk_n_m2 dummy "SK M2"
scoreboard objectives add ec.sk_n_m3 dummy "SK M3"
scoreboard objectives add ec.sk_n_m4 dummy "SK M4"
scoreboard objectives add ec.sk_n_m5 dummy "SK M5"
# Mastery consumers (Wave 37): M4 panic-save HP probe + cooldown.
scoreboard objectives add ec.sk_m4_hp dummy "SK M4 HP Probe"
scoreboard objectives add ec.sk_m4_cd dummy "SK M4 Cooldown"
# Quake (combat-tree rewrite 2026-06-21): on-hit riders (artifacts/striker/on_hit →
# quake/hit) + C1 melee attribute & C12 slow-immunity in quake/tick + Stoneblood bleed DoT
# (quake/bleed_tick, entity tag sk.bleed + timer ec.sk_bleed) + C8 Tectonic 5th-strike slam
# (ec.sk_tec_count). C5/C10 boost the class-wide ground_slam. bough_sk_c1 stripped on unequip
# in artifacts/striker/remove.
scoreboard objectives add ec.sk_bleed dummy "SK Bleed Timer (entity)"
scoreboard objectives add ec.sk_tec_count dummy "SK Tectonic Strike Count"
# PERMANENT account-wide perks + lvl 1/6/12 milestones (util-tree rewrite 2026-06-21).
scoreboard objectives add ec.sk_phealth dummy "SK Perk HP Probe"
scoreboard objectives add ec.sk_msn1 dummy "SK Milestone 1 Seen"
scoreboard objectives add ec.sk_msn6 dummy "SK Milestone 6 Seen"
scoreboard objectives add ec.sk_msn12 dummy "SK Milestone 12 Seen"
# War-prep abilities (2026-06-22): one armed mode at a time + shared recovery cooldown.
scoreboard objectives add ec.sk_abil_id dummy "SK War-Prep Mode"
scoreboard objectives add ec.sk_abil_dur dummy "SK War-Prep Duration"
scoreboard objectives add ec.sk_abil_cd dummy "SK War-Prep Cooldown"
schedule function evercraft:bough/striker/crown_tick 20t
schedule function evercraft:bough/striker/mastery_tick 20t
schedule function evercraft:bough/striker/quake/tick 20t
schedule function evercraft:bough/striker/quake/bleed_tick 20t
schedule function evercraft:bough/striker/perks/tick 20t
schedule function evercraft:bough/striker/abilities/tick 20t
