# === BOUGH TANK — M3 FOUNDATION (Wave 37, kill adv reward) ===
# Pivot: spec's "3s stillness → Resistance I" needed Sentinel-style position
# tracking that Tank doesn't carry. Replacement: 5% chance per kill → +1 Iron
# Resonance. The foundation deepens.
advancement revoke @s only evercraft:bough/tk_m3_kill
execute unless score @s ec.tk_n_m3 matches 1.. run return 0
execute store result score #tk_m3_roll ec.temp run random value 1..20
execute unless score #tk_m3_roll ec.temp matches 1 run return 0
function evercraft:bough/mastery/find_xp {cls:"tk",amount:200}
title @s actionbar [{text:"✦ Foundation ",color:"blue",bold:true},{text:"— +200 Mastery XP",color:"gray",italic:true}]
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.5 0.8
