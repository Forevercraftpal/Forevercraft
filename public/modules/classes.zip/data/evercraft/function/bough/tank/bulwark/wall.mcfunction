# === BOUGH TANK — UNBREAKABLE WALL (C12 capstone) ===
# @s = the Tank, at @s, with a foe within 6. The wall holds: Resistance II + Absorption while
# every nearby foe is rooted (Slowness III) and battered (2 magic thorns). 30s cooldown.
scoreboard players set @s ec.tk_wall_cd 30
effect give @s minecraft:resistance 6 1 true
effect give @s minecraft:absorption 6 1 true
effect give @e[type=#evercraft:hostile_mobs,distance=..6] minecraft:slowness 4 2 true
tag @s add tk.bulwark_src
execute as @e[type=#evercraft:hostile_mobs,distance=..6] run damage @s 2 minecraft:magic by @e[tag=tk.bulwark_src,limit=1,sort=nearest]
tag @s remove tk.bulwark_src
data modify storage evercraft:notify stage.c set value [{text:"⛨ ",color:"gray"},{text:"Unbreakable Wall",color:"white",bold:true},{text:" — none shall pass.",color:"gray"}]
scoreboard players set #ndur ec.temp 50
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.anvil.land master @s ~ ~ ~ 0.5 0.6
