# === BOUGH TANK — CROWN APPLY (Bulwark) ===
# Run as @s = active tank (ec.kt_active tag + ec.kt_fencer=0 — Knight shield
# stance) owning the Crown, at @s. At full HP: knockback immune + Resistance
# III. Drawback: healing is 50% slower (ec.tk_heal_slow flag, read by the
# healing system) — on whenever the Crown is owned and the stance is active.
# Reconciled idempotently each second (Wrathblood pattern).
#
# NOTE: knockback immunity is the minecraft:knockback_resistance ATTRIBUTE at
# 1.0 (full immunity) — there is no knockback_resistance status effect (that
# would be a /reload breaker); the Standfast (Sentinel) modifier pattern is
# reused here.
scoreboard players set @s ec.tk_heal_slow 1

# Fresh full-HP sample each second (berserker check_low_hp pattern): Health
# and max_health both ×100 so regen fractions compare cleanly; absorption can
# push Health past max, hence >=.
execute store result score @s ec.tk_hp run data get entity @s Health 100
execute store result score @s ec.tk_maxhp run attribute @s max_health get 100
execute if score @s ec.tk_hp >= @s ec.tk_maxhp run scoreboard players set @s ec.tk_bulwark_active 1
execute if score @s ec.tk_hp < @s ec.tk_maxhp run scoreboard players set @s ec.tk_bulwark_active 0

# Fresh re-application each tick: strip the KB modifier, re-add only at full
# HP. Resistance III (amplifier 2) is re-given at 5s each second while at
# full HP and simply lapses after the owner drops below full.
attribute @s minecraft:knockback_resistance modifier remove evercraft:bulwark_kb
execute if score @s ec.tk_bulwark_active matches 1 run attribute @s minecraft:knockback_resistance modifier add evercraft:bulwark_kb 1.0 add_value
execute if score @s ec.tk_bulwark_active matches 1 run effect give @s minecraft:resistance 5 2 true

# Pollen · pollen_bl_taunt (Beastlord C4 Beast Cry → Tank) — Living Bough
# Wave 17 consumer: the beast's cry hardens the wall. +1 armor riding the
# Bulwark full-HP gate (Bulwark has no armor modifier of its own — this is the
# sentinel bk_warcry idiom on the Tank's engaged state). Reconciled
# idempotently each second; stripped in crown_remove. Flag read LIVE
# (pollen_tick single writer).
attribute @s minecraft:armor modifier remove evercraft:pollen_bl_taunt
execute if score @s ec.tk_bulwark_active matches 1 if score @s ec.pollen_bl_taunt matches 1.. run attribute @s minecraft:armor modifier add evercraft:pollen_bl_taunt 1 add_value

# Pollen · pollen_ss_pact (Stonestrike U7 Quarry Pact → Tank) — Living Bough
# Wave 18 consumer: the quarry's pact sets the stone. +1 armor riding the same
# Bulwark full-HP gate, stacking with the Beast Cry rider above (separate
# modifier id, same idempotent reconcile each second; stripped in
# crown_remove). Flag read LIVE (pollen_tick single writer).
attribute @s minecraft:armor modifier remove evercraft:pollen_ss_pact
execute if score @s ec.tk_bulwark_active matches 1 if score @s ec.pollen_ss_pact matches 1.. run attribute @s minecraft:armor modifier add evercraft:pollen_ss_pact 1 add_value

# Pollen · pollen_hp_drum (Hoplite U4 Wall Beats → Tank) — Living Bough
# Wave 19 consumer: the wall's beat keeps the shield true. +1 armor riding the
# same Bulwark full-HP gate, stacking with the Beast Cry and Quarry Pact
# riders above (separate modifier id, same idempotent reconcile each second;
# stripped in crown_remove). Flag read LIVE (pollen_tick single writer).
attribute @s minecraft:armor modifier remove evercraft:pollen_hp_drum
execute if score @s ec.tk_bulwark_active matches 1 if score @s ec.pollen_hp_drum matches 1.. run attribute @s minecraft:armor modifier add evercraft:pollen_hp_drum 1 add_value
