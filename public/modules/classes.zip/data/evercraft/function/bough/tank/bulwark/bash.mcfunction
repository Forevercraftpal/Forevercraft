# === BOUGH TANK — SHIELD BASH (C5) ===
# @s = the Tank, at @s, with a foe within 3. Shove foes back (player_attack knockback) and
# Slowness II (the stun). 4s cooldown.
scoreboard players set @s ec.tk_bash_cd 4
tag @s add tk.bulwark_src
execute as @e[type=#evercraft:hostile_mobs,distance=..3] run damage @s 1 minecraft:player_attack by @e[tag=tk.bulwark_src,limit=1,sort=nearest]
tag @s remove tk.bulwark_src
effect give @e[type=#evercraft:hostile_mobs,distance=..3] minecraft:slowness 2 1 true
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:item.shield.block master @s ~ ~ ~ 0.7 0.8
