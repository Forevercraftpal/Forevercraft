# === BOUGH TANK — BULWARK TICK (1s) ===
# Tank shares the Knight active tag (ec.kt_active) gated to the shield stance (ec.kt_fencer=0).
# Runs bulwark/pulse for any Tank with >=1 combat point. C1/C2/C3 attributes reconciled here
# (fencer-gated, mirroring mastery's tk_m1; also stripped on unequip in artifacts/knight/
# deactivate). Shield Bash + Unbreakable Wall cooldowns burn here.
execute unless entity @a[tag=ec.kt_active,scores={ec.kt_fencer=0,ec.tk_b_combat=1..}] run return run schedule function evercraft:bough/tank/bulwark/tick 20t
scoreboard players remove @a[scores={ec.tk_bash_cd=1..}] ec.tk_bash_cd 1
scoreboard players remove @a[scores={ec.tk_wall_cd=1..}] ec.tk_wall_cd 1

# C1 Iron Wall (+2 armor) — reconciled while in shield stance.
execute as @a[scores={ec.tk_n_c1=1..,ec.kt_fencer=..0},tag=ec.kt_active] run attribute @s minecraft:armor modifier remove evercraft:bough_tk_c1
execute as @a[scores={ec.tk_n_c1=1..,ec.kt_fencer=..0},tag=ec.kt_active] run attribute @s minecraft:armor modifier add evercraft:bough_tk_c1 2 add_value
execute as @a unless score @s ec.tk_n_c1 matches 1.. run attribute @s minecraft:armor modifier remove evercraft:bough_tk_c1
execute as @a[tag=!ec.kt_active] run attribute @s minecraft:armor modifier remove evercraft:bough_tk_c1
execute as @a[scores={ec.kt_fencer=1..}] run attribute @s minecraft:armor modifier remove evercraft:bough_tk_c1

# C2 Heavy Strike (+2 melee) — same reconcile.
execute as @a[scores={ec.tk_n_c2=1..,ec.kt_fencer=..0},tag=ec.kt_active] run attribute @s minecraft:attack_damage modifier remove evercraft:bough_tk_c2
execute as @a[scores={ec.tk_n_c2=1..,ec.kt_fencer=..0},tag=ec.kt_active] run attribute @s minecraft:attack_damage modifier add evercraft:bough_tk_c2 2 add_value
execute as @a unless score @s ec.tk_n_c2 matches 1.. run attribute @s minecraft:attack_damage modifier remove evercraft:bough_tk_c2
execute as @a[tag=!ec.kt_active] run attribute @s minecraft:attack_damage modifier remove evercraft:bough_tk_c2
execute as @a[scores={ec.kt_fencer=1..}] run attribute @s minecraft:attack_damage modifier remove evercraft:bough_tk_c2

# C3 Stalwart (+0.2 knockback resistance) — same reconcile.
execute as @a[scores={ec.tk_n_c3=1..,ec.kt_fencer=..0},tag=ec.kt_active] run attribute @s minecraft:knockback_resistance modifier remove evercraft:bough_tk_c3
execute as @a[scores={ec.tk_n_c3=1..,ec.kt_fencer=..0},tag=ec.kt_active] run attribute @s minecraft:knockback_resistance modifier add evercraft:bough_tk_c3 0.2 add_value
execute as @a unless score @s ec.tk_n_c3 matches 1.. run attribute @s minecraft:knockback_resistance modifier remove evercraft:bough_tk_c3
execute as @a[tag=!ec.kt_active] run attribute @s minecraft:knockback_resistance modifier remove evercraft:bough_tk_c3
execute as @a[scores={ec.kt_fencer=1..}] run attribute @s minecraft:knockback_resistance modifier remove evercraft:bough_tk_c3

execute as @a[tag=ec.kt_active,scores={ec.kt_fencer=0,ec.tk_b_combat=1..}] at @s run function evercraft:bough/tank/bulwark/pulse
schedule function evercraft:bough/tank/bulwark/tick 20t
