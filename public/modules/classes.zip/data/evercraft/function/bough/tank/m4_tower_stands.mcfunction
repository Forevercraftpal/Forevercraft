# === BOUGH TANK — M4 TOWER STANDS (Wave 37, mastery_tick branch) ===
# At HP ≤ 5 + Tank active (Knight non-fencer) + cd ready → Resistance V 3s +
# Absorption 5s, 60s cooldown. The tower stands.
effect give @s minecraft:resistance 3 4 true
effect give @s minecraft:absorption 5 1 true
title @s actionbar [{text:"🗿 Tower Stands ",color:"blue",bold:true},{text:"— immovable",color:"gray",italic:true}]
execute as @a[distance=..16] if score @s ec.fx_snd matches 1.. run playsound minecraft:block.anvil.land master @s ~ ~ ~ 0.8 0.4
scoreboard players set @s ec.tk_m4_cd 60
