# === BOUGH TANK — MASTERY TICK (1s, Wave 37) ===
# Tank shares the Knight active tag (ec.kt_active) but is gated to non-fencer
# mode (kt_fencer=0). M3 fires from kill adv. This tick handles M1/M5 passive
# armor + M2 (low-HP resistance) + M4 (panic save).
execute unless entity @a[tag=ec.kt_active] run return run schedule function evercraft:bough/tank/mastery_tick 20t

scoreboard players remove @a[scores={ec.tk_m4_cd=1..}] ec.tk_m4_cd 1

# M1 Tank Mastery (pivot): passive +1 armor while Tank active.
execute as @a[scores={ec.tk_n_m1=1..,ec.kt_fencer=..0},tag=ec.kt_active] run attribute @s minecraft:armor modifier remove evercraft:bough_tk_m1
execute as @a[scores={ec.tk_n_m1=1..,ec.kt_fencer=..0},tag=ec.kt_active] run attribute @s minecraft:armor modifier add evercraft:bough_tk_m1 1 add_value
execute as @a unless score @s ec.tk_n_m1 matches 1.. run attribute @s minecraft:armor modifier remove evercraft:bough_tk_m1
execute as @a[tag=!ec.kt_active] run attribute @s minecraft:armor modifier remove evercraft:bough_tk_m1
execute as @a[scores={ec.kt_fencer=1..}] run attribute @s minecraft:armor modifier remove evercraft:bough_tk_m1

# M5 Crown's Anvil (pivot): passive +1 armor while Tank active.
execute as @a[scores={ec.tk_n_m5=1..,ec.kt_fencer=..0},tag=ec.kt_active] run attribute @s minecraft:armor modifier remove evercraft:bough_tk_m5
execute as @a[scores={ec.tk_n_m5=1..,ec.kt_fencer=..0},tag=ec.kt_active] run attribute @s minecraft:armor modifier add evercraft:bough_tk_m5 1 add_value
execute as @a unless score @s ec.tk_n_m5 matches 1.. run attribute @s minecraft:armor modifier remove evercraft:bough_tk_m5
execute as @a[tag=!ec.kt_active] run attribute @s minecraft:armor modifier remove evercraft:bough_tk_m5
execute as @a[scores={ec.kt_fencer=1..}] run attribute @s minecraft:armor modifier remove evercraft:bough_tk_m5

# HP probe for M2 / M4.
execute as @a[scores={ec.tk_n_m2=1..,ec.kt_fencer=..0},tag=ec.kt_active] store result score @s ec.tk_hp run data get entity @s Health 1
execute as @a[scores={ec.tk_n_m4=1..,ec.tk_m4_cd=..0,ec.kt_fencer=..0},tag=ec.kt_active] store result score @s ec.tk_hp run data get entity @s Health 1

# M2 Anvil Skin (pivot): below 50% HP (10 of base 20) → Resistance I.
execute as @a[scores={ec.tk_n_m2=1..,ec.tk_hp=..10,ec.kt_fencer=..0},tag=ec.kt_active] run effect give @s minecraft:resistance 2 0 true

# M4 Tower Stands: HP ≤ 5 + cd ready → panic.
execute as @a[scores={ec.tk_n_m4=1..,ec.tk_m4_cd=..0,ec.tk_hp=..5,ec.kt_fencer=..0},tag=ec.kt_active] at @s run function evercraft:bough/tank/m4_tower_stands

schedule function evercraft:bough/tank/mastery_tick 20t
