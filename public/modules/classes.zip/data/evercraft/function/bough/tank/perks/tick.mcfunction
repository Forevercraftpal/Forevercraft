# === BOUGH TANK — PERMANENT PERK TICK (1s, ACCOUNT-WIDE) ===
# Tank utility perks are PERMANENT + CROSS-CLASS: gated on the node-bought flag, NOT the class
# — kept while playing anything (multiclass reward). Gate: any tank progress (ec.tk_lvl>=1).
# Theme = the immovable fortress (armor + health + poise). Attribute perks: remove-for-all then
# add-for-owners. Probe ec.tk_phealth. Pollen U3/U6/U7 untouched. U5 Aegis is conditional on
# low HP. The anti-fun "can't move" nodes (old C4/U10) were cut.
execute unless entity @a[scores={ec.tk_lvl=1..}] run return run schedule function evercraft:bough/tank/perks/tick 20t

# --- ARMOR (U1 Ironhide +1 · U4 Granite Skin +1 · U12 Last Wall +1) ---
execute as @a[scores={ec.tk_lvl=1..}] run attribute @s minecraft:armor modifier remove evercraft:tk_perk_u1
execute as @a[scores={ec.tk_n_u1=1..}] run attribute @s minecraft:armor modifier add evercraft:tk_perk_u1 1 add_value
execute as @a[scores={ec.tk_lvl=1..}] run attribute @s minecraft:armor modifier remove evercraft:tk_perk_u4
execute as @a[scores={ec.tk_n_u4=1..}] run attribute @s minecraft:armor modifier add evercraft:tk_perk_u4 1 add_value
execute as @a[scores={ec.tk_lvl=1..}] run attribute @s minecraft:armor modifier remove evercraft:tk_perk_u12
execute as @a[scores={ec.tk_n_u12=1..}] run attribute @s minecraft:armor modifier add evercraft:tk_perk_u12 1 add_value

# --- AEGIS (U5): +2 armor while below 50% HP (≤10) — conditional, account-wide ---
execute as @a[scores={ec.tk_lvl=1..}] store result score @s ec.tk_phealth run data get entity @s Health 1
execute as @a[scores={ec.tk_lvl=1..}] run attribute @s minecraft:armor modifier remove evercraft:tk_perk_u5
execute as @a[scores={ec.tk_n_u5=1..,ec.tk_phealth=..10}] run attribute @s minecraft:armor modifier add evercraft:tk_perk_u5 2 add_value

# --- KNOCKBACK RESISTANCE (U8 Hold Fast · U10 Immovable = +0.2 each) ---
execute as @a[scores={ec.tk_lvl=1..}] run attribute @s minecraft:knockback_resistance modifier remove evercraft:tk_perk_u8
execute as @a[scores={ec.tk_n_u8=1..}] run attribute @s minecraft:knockback_resistance modifier add evercraft:tk_perk_u8 0.2 add_value
execute as @a[scores={ec.tk_lvl=1..}] run attribute @s minecraft:knockback_resistance modifier remove evercraft:tk_perk_u10
execute as @a[scores={ec.tk_n_u10=1..}] run attribute @s minecraft:knockback_resistance modifier add evercraft:tk_perk_u10 0.2 add_value

# --- HEALTH (U2 Burly · U9 Ironbound · U11 Steady Heart · U12 Last Wall = +1 heart each) ---
execute as @a[scores={ec.tk_lvl=1..}] run attribute @s minecraft:max_health modifier remove evercraft:tk_perk_u2
execute as @a[scores={ec.tk_n_u2=1..}] run attribute @s minecraft:max_health modifier add evercraft:tk_perk_u2 2 add_value
execute as @a[scores={ec.tk_lvl=1..}] run attribute @s minecraft:max_health modifier remove evercraft:tk_perk_u9
execute as @a[scores={ec.tk_n_u9=1..}] run attribute @s minecraft:max_health modifier add evercraft:tk_perk_u9 2 add_value
execute as @a[scores={ec.tk_lvl=1..}] run attribute @s minecraft:max_health modifier remove evercraft:tk_perk_u11
execute as @a[scores={ec.tk_n_u11=1..}] run attribute @s minecraft:max_health modifier add evercraft:tk_perk_u11 2 add_value
execute as @a[scores={ec.tk_lvl=1..}] run attribute @s minecraft:max_health modifier remove evercraft:tk_perk_u12h
execute as @a[scores={ec.tk_n_u12=1..}] run attribute @s minecraft:max_health modifier add evercraft:tk_perk_u12h 2 add_value

# === MILESTONE PASSIVES (lvl 1/6/12, account-wide, fortress-thematic) ===
# Lvl 1 Braced — Knockback Resistance +0.1.
execute as @a[scores={ec.tk_lvl=1..}] run attribute @s minecraft:knockback_resistance modifier remove evercraft:tk_ms1
execute as @a[scores={ec.tk_lvl=1..}] run attribute @s minecraft:knockback_resistance modifier add evercraft:tk_ms1 0.1 add_value
# Lvl 6 Fortified — +1 armor.
execute as @a[scores={ec.tk_lvl=6..}] run attribute @s minecraft:armor modifier remove evercraft:tk_ms6
execute as @a[scores={ec.tk_lvl=6..}] run attribute @s minecraft:armor modifier add evercraft:tk_ms6 1 add_value
# Lvl 12 Bastion — +1 heart + +1 armor.
execute as @a[scores={ec.tk_lvl=12..}] run attribute @s minecraft:max_health modifier remove evercraft:tk_ms12
execute as @a[scores={ec.tk_lvl=12..}] run attribute @s minecraft:max_health modifier add evercraft:tk_ms12 2 add_value
execute as @a[scores={ec.tk_lvl=12..}] run attribute @s minecraft:armor modifier remove evercraft:tk_ms12a
execute as @a[scores={ec.tk_lvl=12..}] run attribute @s minecraft:armor modifier add evercraft:tk_ms12a 1 add_value

# Milestone unlock chat (one-time each)
execute as @a[scores={ec.tk_lvl=1..}] unless score @s ec.tk_msn1 matches 1 run tellraw @s [{text:"✦ Tank Mastery 1 — ",color:"gray"},{text:"Braced",color:"white",bold:true},{text:" unlocked. Knockback resistance. Permanent, all classes.",color:"gray"}]
scoreboard players set @a[scores={ec.tk_lvl=1..}] ec.tk_msn1 1
execute as @a[scores={ec.tk_lvl=6..}] unless score @s ec.tk_msn6 matches 1 run tellraw @s [{text:"✦ Tank Mastery 6 — ",color:"gray"},{text:"Fortified",color:"white",bold:true},{text:" unlocked. +1 armor. Permanent, all classes.",color:"gray"}]
scoreboard players set @a[scores={ec.tk_lvl=6..}] ec.tk_msn6 1
execute as @a[scores={ec.tk_lvl=12..}] unless score @s ec.tk_msn12 matches 1 run tellraw @s [{text:"✦ Tank Mastery 12 — ",color:"gray"},{text:"Bastion",color:"white",bold:true},{text:" unlocked. +1 heart and +1 armor. Permanent, all classes.",color:"gray"}]
scoreboard players set @a[scores={ec.tk_lvl=12..}] ec.tk_msn12 1

schedule function evercraft:bough/tank/perks/tick 20t
