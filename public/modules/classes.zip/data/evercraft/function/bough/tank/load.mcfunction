# === BOUGH TANK — LOAD ===
scoreboard objectives add ec.tk_b_combat dummy "Bough TK Combat Points"
scoreboard objectives add ec.tk_b_util dummy "Bough TK Utility Points"
scoreboard objectives add ec.tk_b_mast dummy "Bough TK Mastery Points"
scoreboard objectives add ec.tk_b_crown dummy "Bough TK Crown Owned"
scoreboard objectives add ec.tk_bough_view dummy "Bough TK Codex View"
scoreboard objectives add ec.tk_lx dummy "Bough TK Last X"
scoreboard objectives add ec.tk_lz dummy "Bough TK Last Z"
scoreboard objectives add ec.tk_lyaw dummy "Bough TK Last Yaw"
scoreboard objectives add ec.tk_hp dummy "Bough TK HP Sample"
scoreboard objectives add ec.tk_maxhp dummy "Bough TK MaxHP Sample"
scoreboard objectives add ec.tk_bulwark_active dummy "Bough TK Bulwark Active"
scoreboard objectives add ec.tk_heal_slow dummy "Bough TK Heal Slow Flag"
# Wave 19 (pollen consumer): pollen_ds_vow iron-spirit heartbeat cooldown in
# ticks (pollen_vow_pulse arms 100 = 5s; crown_tick burns 20t per 1s tick).
scoreboard objectives add ec.tk_pln_vow_cd dummy "Bough TK Pollen Vow CD"
scoreboard objectives add ec.tk_n_c1 dummy "TK C1"
scoreboard objectives add ec.tk_n_c2 dummy "TK C2"
scoreboard objectives add ec.tk_n_c3 dummy "TK C3"
scoreboard objectives add ec.tk_n_c4 dummy "TK C4"
scoreboard objectives add ec.tk_n_c5 dummy "TK C5"
scoreboard objectives add ec.tk_n_c6 dummy "TK C6"
scoreboard objectives add ec.tk_n_c7 dummy "TK C7"
scoreboard objectives add ec.tk_n_c8 dummy "TK C8"
scoreboard objectives add ec.tk_n_c9 dummy "TK C9"
scoreboard objectives add ec.tk_n_c10 dummy "TK C10"
scoreboard objectives add ec.tk_n_c11 dummy "TK C11"
scoreboard objectives add ec.tk_n_c12 dummy "TK C12"
scoreboard objectives add ec.tk_n_u1 dummy "TK U1"
scoreboard objectives add ec.tk_n_u2 dummy "TK U2"
scoreboard objectives add ec.tk_n_u3 dummy "TK U3"
scoreboard objectives add ec.tk_n_u4 dummy "TK U4"
scoreboard objectives add ec.tk_n_u5 dummy "TK U5"
scoreboard objectives add ec.tk_n_u6 dummy "TK U6"
scoreboard objectives add ec.tk_n_u7 dummy "TK U7"
scoreboard objectives add ec.tk_n_u8 dummy "TK U8"
scoreboard objectives add ec.tk_n_u9 dummy "TK U9"
scoreboard objectives add ec.tk_n_u10 dummy "TK U10"
scoreboard objectives add ec.tk_n_u11 dummy "TK U11"
scoreboard objectives add ec.tk_n_u12 dummy "TK U12"
scoreboard objectives add ec.tk_n_m1 dummy "TK M1"
scoreboard objectives add ec.tk_n_m2 dummy "TK M2"
scoreboard objectives add ec.tk_n_m3 dummy "TK M3"
scoreboard objectives add ec.tk_n_m4 dummy "TK M4"
scoreboard objectives add ec.tk_n_m5 dummy "TK M5"
# Mastery consumers (Wave 37): HP probe + M4 cooldown.
scoreboard objectives add ec.tk_hp dummy "TK HP Probe"
scoreboard objectives add ec.tk_m4_cd dummy "TK M4 Cooldown"
# Bulwark (combat-tree rewrite 2026-06-21): solo fortress aura (foe control + thorns + hold-
# the-line buffs + low-HP rally + Shield Bash + Unbreakable Wall capstone). Gate = shield
# stance (ec.kt_active + ec.kt_fencer=0) + ec.tk_b_combat>=1. Engine = bulwark/tick → pulse.
# C1/C2/C3 attributes (bough_tk_c1/c2/c3) stripped on unequip in artifacts/knight/deactivate.
scoreboard objectives add ec.tk_hp_b dummy "TK Bulwark HP Probe"
scoreboard objectives add ec.tk_bash_cd dummy "TK Shield Bash CD"
scoreboard objectives add ec.tk_wall_cd dummy "TK Unbreakable Wall CD"
# PERMANENT account-wide perks + lvl 1/6/12 milestones (util-tree rewrite 2026-06-21).
scoreboard objectives add ec.tk_phealth dummy "TK Perk HP Probe"
scoreboard objectives add ec.tk_msn1 dummy "TK Milestone 1 Seen"
scoreboard objectives add ec.tk_msn6 dummy "TK Milestone 6 Seen"
scoreboard objectives add ec.tk_msn12 dummy "TK Milestone 12 Seen"
# War-prep abilities (2026-06-22): one armed mode at a time + shared recovery cooldown.
scoreboard objectives add ec.tk_abil_id dummy "TK War-Prep Mode"
scoreboard objectives add ec.tk_abil_dur dummy "TK War-Prep Duration"
scoreboard objectives add ec.tk_abil_cd dummy "TK War-Prep Cooldown"
schedule function evercraft:bough/tank/crown_tick 20t
schedule function evercraft:bough/tank/mastery_tick 20t
schedule function evercraft:bough/tank/bulwark/tick 20t
schedule function evercraft:bough/tank/perks/tick 20t
schedule function evercraft:bough/tank/abilities/tick 20t
