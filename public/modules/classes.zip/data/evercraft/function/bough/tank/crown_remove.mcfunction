# === BOUGH TANK — CROWN REMOVE ===
# Strips the Bulwark state from @s: heal-slow drawback flag, full-HP latch,
# the KB-immunity attribute modifier, and the Resistance buff. Idempotent.
scoreboard players set @s ec.tk_heal_slow 0
scoreboard players set @s ec.tk_bulwark_active 0
attribute @s minecraft:knockback_resistance modifier remove evercraft:bulwark_kb
# Wave 17: the Beast Cry pollen armor bonus rides the Bulwark surface — strip
# it with the rest of the state.
attribute @s minecraft:armor modifier remove evercraft:pollen_bl_taunt
# Wave 18: the Quarry Pact pollen armor bonus rides the same surface — strip it too.
attribute @s minecraft:armor modifier remove evercraft:pollen_ss_pact
# Wave 19: the Wall Beats pollen armor bonus rides the same surface — strip it too.
attribute @s minecraft:armor modifier remove evercraft:pollen_hp_drum
effect clear @s minecraft:resistance
