# === BOUGH TANK — CROWN TICK (1s) ===
# Bulwark: at full HP the owner is knockback immune + Resistance III; healing
# is 50% slower while owned (ec.tk_heal_slow, read by the healing system).
# Active-state gate: Tank is the Knight shield stance → ec.kt_active tag +
# ec.kt_fencer=0 (knight/tick uses the same selector for the stance shield).
# Pollen · pollen_ds_vow (DS U5 Twin Vow → Tank) — Living Bough Wave 19
# consumer: the twin vow beats in the iron. While Bulwark is engaged and the
# vow flag is owned, a Resistance I 1s heartbeat fires every 5s
# (pollen_vow_pulse arms ec.tk_pln_vow_cd 100 = 5s). Burn the cooldown down
# 20t per 1s tick for everyone holding a score — BEFORE the early return —
# so the heartbeat tracks real time across stance swaps (the Knight
# heal_warn_cd / DS ICD pattern).
scoreboard players remove @a[scores={ec.tk_pln_vow_cd=1..}] ec.tk_pln_vow_cd 20
execute as @a[scores={ec.tk_pln_vow_cd=..-1}] run scoreboard players set @s ec.tk_pln_vow_cd 0
# 0. Strip lingering Bulwark state (KB modifier / heal-slow flag) from owners
#    who left the Tank stance since the last tick. ec.tk_heal_slow=1 is the
#    "Bulwark engaged" latch — set every apply, cleared by crown_remove.
execute as @a[scores={ec.tk_b_crown=1,ec.tk_heal_slow=1}] unless entity @s[tag=ec.kt_active,scores={ec.kt_fencer=0}] at @s run function evercraft:bough/tank/crown_remove
execute unless entity @a[tag=ec.kt_active,scores={ec.kt_fencer=0,ec.tk_b_crown=1}] run return run schedule function evercraft:bough/tank/crown_tick 20t
execute as @a[tag=ec.kt_active,scores={ec.kt_fencer=0,ec.tk_b_crown=1}] at @s run function evercraft:bough/tank/crown_apply
# Wave 19 vow heartbeat — fires after crown_apply so ec.tk_bulwark_active is
# this second's fresh sample. Health-gated per the death-screen @a law.
execute as @a[scores={ec.tk_b_crown=1..,ec.tk_pln_vow_cd=..0,ec.tk_bulwark_active=1..}] if score @s ec.pollen_ds_vow matches 1.. at @s unless data entity @s {Health:0.0f} run function evercraft:bough/tank/pollen_vow_pulse
schedule function evercraft:bough/tank/crown_tick 20t
