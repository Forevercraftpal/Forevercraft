# === BOUGH TANK — WAR-PREP TICK (1s) ===
# Drains the per-class war-prep duration/cooldown, applies the active mode's SUSTAINED
# effect (class-only via the active gate), announces the fade. Rider signatures detonate
# in the combat hit path (see bough/abilities/on_melee_hit or the class projectile hook).
execute unless entity @a[scores={ec.tk_abil_cd=1..}] unless entity @a[scores={ec.tk_abil_id=1..}] run return run schedule function evercraft:bough/tank/abilities/tick 20t
scoreboard players remove @a[scores={ec.tk_abil_cd=1..}] ec.tk_abil_cd 1
scoreboard players remove @a[scores={ec.tk_abil_dur=1..}] ec.tk_abil_dur 1
execute as @a[scores={ec.tk_abil_dur=0,ec.tk_abil_id=1..}] run tellraw @s [{text:"⚔ ",color:"gray"},{text:"War-prep faded.",color:"gray",italic:true}]
scoreboard players set @a[scores={ec.tk_abil_dur=0,ec.tk_abil_id=1..}] ec.tk_abil_id 0
# id 1 Bulwark Slam
execute as @a[tag=ec.kt_active,scores={ec.kt_fencer=..0,ec.tk_abil_id=1,ec.tk_abil_dur=1..}] run effect give @s minecraft:resistance 2 0 true
# id 2 Immovable
execute as @a[tag=ec.kt_active,scores={ec.kt_fencer=..0,ec.tk_abil_id=2,ec.tk_abil_dur=1..}] run effect give @s minecraft:resistance 2 1 true
execute as @a[tag=ec.kt_active,scores={ec.kt_fencer=..0,ec.tk_abil_id=2,ec.tk_abil_dur=1..}] run effect give @s minecraft:absorption 2 0 true
# id 3 Rally
execute as @a[tag=ec.kt_active,scores={ec.kt_fencer=..0,ec.tk_abil_id=3,ec.tk_abil_dur=1..}] run effect give @s minecraft:resistance 2 0 true
execute as @a[tag=ec.kt_active,scores={ec.kt_fencer=..0,ec.tk_abil_id=3,ec.tk_abil_dur=1..}] at @s as @a[distance=..8] run effect give @s minecraft:resistance 2 0 true
execute as @a[tag=ec.kt_active,scores={ec.kt_fencer=..0,ec.tk_abil_id=3,ec.tk_abil_dur=1..}] at @s as @a[distance=..8] run effect give @s minecraft:regeneration 2 0 true
# id 11 Ironhide
execute as @a[tag=ec.kt_active,scores={ec.kt_fencer=..0,ec.tk_abil_id=11,ec.tk_abil_dur=1..}] run effect give @s minecraft:resistance 2 1 true
# id 12 Anvil
execute as @a[tag=ec.kt_active,scores={ec.kt_fencer=..0,ec.tk_abil_id=12,ec.tk_abil_dur=1..}] run effect give @s minecraft:resistance 2 0 true
# id 13 Foundation
execute as @a[tag=ec.kt_active,scores={ec.kt_fencer=..0,ec.tk_abil_id=13,ec.tk_abil_dur=1..}] run effect give @s minecraft:resistance 2 0 true
# id 14 Tower Stands
execute as @a[tag=ec.kt_active,scores={ec.kt_fencer=..0,ec.tk_abil_id=14,ec.tk_abil_dur=1..}] run effect give @s minecraft:resistance 2 2 true
execute as @a[tag=ec.kt_active,scores={ec.kt_fencer=..0,ec.tk_abil_id=14,ec.tk_abil_dur=1..}] run effect give @s minecraft:absorption 2 1 true
schedule function evercraft:bough/tank/abilities/tick 20t
