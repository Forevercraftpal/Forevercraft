# === BOUGH TANK — POLLEN VOW PULSE (Living Bough Wave 19 pollen consumer) ===
# pollen_ds_vow (DS U5 Twin Vow → Tank): the twin vow beats in the iron. Run
# as/at the Tank from crown_tick every 5s while Bulwark is engaged
# (ec.tk_bulwark_active=1) and the vow flag is owned: a Resistance I 1s
# heartbeat. While the owner sits at full HP the Bulwark's own Resistance III
# shadows the pulse (vanilla keeps the stronger effect) — the heartbeat is the
# iron-spirit FLAVOR beat, audible below, and covers the engaged edge moments.
# Flag read LIVE (pollen_tick single writer) — zero cleanup wiring.
effect give @s minecraft:resistance 1 0 true
scoreboard players set @s ec.tk_pln_vow_cd 100
# Iron-spirit heartbeat — low basedrum thump (musical note-block palette law).
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.basedrum master @s ~ ~ ~ 0.4 0.561
