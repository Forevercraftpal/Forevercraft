# === BOUGH TANK — BULWARK PULSE ===
# @s = a Tank (ec.kt_active, kt_fencer=0) with >=1 combat point, at @s. Solo fortress: foe
# control + thorns + hold-the-line self-buffs + low-HP rally + capstone. Radius 3/4/5/6. Combat
# HP probe ec.tk_hp_b (mastery owns ec.tk_hp). C1/C2/C3 attributes reconciled in bulwark/tick.
execute store result score @s ec.tk_hp_b run data get entity @s Health 1

# --- FOE CONTROL / THORNS (C4 Anchor Slowness ≤4 · C6 Bramble Guard 1 magic/s ≤3 · C7 Counter Strike 2 magic/s ≤4) ---
execute if score @s ec.tk_n_c4 matches 1.. run effect give @e[type=#evercraft:hostile_mobs,distance=..4] minecraft:slowness 2 0 true
tag @s add tk.bulwark_src
execute if score @s ec.tk_n_c6 matches 1.. as @e[type=#evercraft:hostile_mobs,distance=..3] run damage @s 1 minecraft:magic by @e[tag=tk.bulwark_src,limit=1,sort=nearest]
execute if score @s ec.tk_n_c7 matches 1.. as @e[type=#evercraft:hostile_mobs,distance=..4] run damage @s 2 minecraft:magic by @e[tag=tk.bulwark_src,limit=1,sort=nearest]
tag @s remove tk.bulwark_src

# --- SELF (C8 Stonewall Resist near foe · C9 Bulwark Charge Strength+Speed near foe · C10 Rally Absorption low-HP) ---
execute if score @s ec.tk_n_c8 matches 1.. if entity @e[type=#evercraft:hostile_mobs,distance=..5] run effect give @s minecraft:resistance 2 0 true
execute if score @s ec.tk_n_c9 matches 1.. if entity @e[type=#evercraft:hostile_mobs,distance=..4] run effect give @s minecraft:strength 2 0 true
execute if score @s ec.tk_n_c9 matches 1.. if entity @e[type=#evercraft:hostile_mobs,distance=..4] run effect give @s minecraft:speed 2 0 true
execute if score @s ec.tk_n_c10 matches 1.. if score @s ec.tk_hp_b matches ..10 run effect give @s minecraft:absorption 2 0 true

# --- IRON MIND (C11): unflinching — clear Slowness and Mining Fatigue each second ---
execute if score @s ec.tk_n_c11 matches 1.. run effect clear @s minecraft:slowness
execute if score @s ec.tk_n_c11 matches 1.. run effect clear @s minecraft:mining_fatigue

# --- TIMED (C5 Shield Bash 4s · C12 Unbreakable Wall 30s capstone) ---
execute if score @s ec.tk_n_c5 matches 1.. if score @s ec.tk_bash_cd matches ..0 if entity @e[type=#evercraft:hostile_mobs,distance=..3] run function evercraft:bough/tank/bulwark/bash
execute if score @s ec.tk_n_c12 matches 1.. if score @s ec.tk_wall_cd matches ..0 if entity @e[type=#evercraft:hostile_mobs,distance=..6] run function evercraft:bough/tank/bulwark/wall
