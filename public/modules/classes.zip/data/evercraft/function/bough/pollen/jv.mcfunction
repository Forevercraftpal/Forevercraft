# Javelin pollen self-reconcile (C2 Lent Spear / U6 Sea Sense / U4 Skyseed). Single writer for ec.pollen_jv_*. Dispatched from bough/pollen_tick when any online player has ec.jv_lvl>=1.
execute as @a[scores={ec.jv_n_c2=1..}] run scoreboard players set @s ec.pollen_jv_lend 1
execute as @a[scores={ec.pollen_jv_lend=1..}] unless score @s ec.jv_n_c2 matches 1.. run scoreboard players set @s ec.pollen_jv_lend 0
execute as @a[scores={ec.jv_n_u6=1..}] run scoreboard players set @s ec.pollen_jv_tide 1
execute as @a[scores={ec.pollen_jv_tide=1..}] unless score @s ec.jv_n_u6 matches 1.. run scoreboard players set @s ec.pollen_jv_tide 0
execute as @a[scores={ec.jv_n_u4=1..}] run scoreboard players set @s ec.pollen_jv_throw 1
execute as @a[scores={ec.pollen_jv_throw=1..}] unless score @s ec.jv_n_u4 matches 1.. run scoreboard players set @s ec.pollen_jv_throw 0
