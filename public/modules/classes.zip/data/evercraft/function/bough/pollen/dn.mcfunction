# Dancer pollen self-reconcile (U1 Breath-step / U8 Twist / U7 Tempo). Single writer for ec.pollen_dn_*. Dispatched from bough/pollen_tick when any online player has ec.dn_lvl>=1.
execute as @a[scores={ec.dn_n_u1=1..}] run scoreboard players set @s ec.pollen_dn_breath 1
execute as @a[scores={ec.pollen_dn_breath=1..}] unless score @s ec.dn_n_u1 matches 1.. run scoreboard players set @s ec.pollen_dn_breath 0
execute as @a[scores={ec.dn_n_u8=1..}] run scoreboard players set @s ec.pollen_dn_pivot 1
execute as @a[scores={ec.pollen_dn_pivot=1..}] unless score @s ec.dn_n_u8 matches 1.. run scoreboard players set @s ec.pollen_dn_pivot 0
execute as @a[scores={ec.dn_n_u7=1..}] run scoreboard players set @s ec.pollen_dn_tempo 1
execute as @a[scores={ec.pollen_dn_tempo=1..}] unless score @s ec.dn_n_u7 matches 1.. run scoreboard players set @s ec.pollen_dn_tempo 0
