# Hoplite pollen self-reconcile (U1 Phalanx Throw / U3 Banner Call / U4 Wall Beats). Single writer for ec.pollen_hp_*. Dispatched from bough/pollen_tick when any online player has ec.hp_lvl>=1.
execute as @a[scores={ec.hp_n_u1=1..}] run scoreboard players set @s ec.pollen_hp_pass 1
execute as @a[scores={ec.pollen_hp_pass=1..}] unless score @s ec.hp_n_u1 matches 1.. run scoreboard players set @s ec.pollen_hp_pass 0
execute as @a[scores={ec.hp_n_u3=1..}] run scoreboard players set @s ec.pollen_hp_call 1
execute as @a[scores={ec.pollen_hp_call=1..}] unless score @s ec.hp_n_u3 matches 1.. run scoreboard players set @s ec.pollen_hp_call 0
execute as @a[scores={ec.hp_n_u4=1..}] run scoreboard players set @s ec.pollen_hp_drum 1
execute as @a[scores={ec.pollen_hp_drum=1..}] unless score @s ec.hp_n_u4 matches 1.. run scoreboard players set @s ec.pollen_hp_drum 0
