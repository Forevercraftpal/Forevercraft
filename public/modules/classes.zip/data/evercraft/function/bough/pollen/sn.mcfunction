# Sentinel pollen self-reconcile (U3 Bulwark Vow / U6 Steady Witness / U2 Iron Refrain). Single writer for ec.pollen_sn_*. Dispatched from bough/pollen_tick when any online player has ec.sn_lvl>=1.
execute as @a[scores={ec.sn_n_u3=1..}] run scoreboard players set @s ec.pollen_sn_wall 1
execute as @a[scores={ec.pollen_sn_wall=1..}] unless score @s ec.sn_n_u3 matches 1.. run scoreboard players set @s ec.pollen_sn_wall 0
execute as @a[scores={ec.sn_n_u6=1..}] run scoreboard players set @s ec.pollen_sn_focus 1
execute as @a[scores={ec.pollen_sn_focus=1..}] unless score @s ec.sn_n_u6 matches 1.. run scoreboard players set @s ec.pollen_sn_focus 0
execute as @a[scores={ec.sn_n_u2=1..}] run scoreboard players set @s ec.pollen_sn_calm 1
execute as @a[scores={ec.pollen_sn_calm=1..}] unless score @s ec.sn_n_u2 matches 1.. run scoreboard players set @s ec.pollen_sn_calm 0
