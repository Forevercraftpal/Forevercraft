# Lamentor pollen self-reconcile (U1 Tailor / U6 Banner Pact / U11 Silkweaver Pact). Single writer for ec.pollen_lm_*. Dispatched from bough/pollen_tick when any online player has ec.lm_lvl>=1.
execute as @a[scores={ec.lm_n_u1=1..}] run scoreboard players set @s ec.pollen_lm_tailor 1
execute as @a[scores={ec.pollen_lm_tailor=1..}] unless score @s ec.lm_n_u1 matches 1.. run scoreboard players set @s ec.pollen_lm_tailor 0
execute as @a[scores={ec.lm_n_u6=1..}] run scoreboard players set @s ec.pollen_lm_banner 1
execute as @a[scores={ec.pollen_lm_banner=1..}] unless score @s ec.lm_n_u6 matches 1.. run scoreboard players set @s ec.pollen_lm_banner 0
execute as @a[scores={ec.lm_n_u11=1..}] run scoreboard players set @s ec.pollen_lm_weave 1
execute as @a[scores={ec.pollen_lm_weave=1..}] unless score @s ec.lm_n_u11 matches 1.. run scoreboard players set @s ec.pollen_lm_weave 0
