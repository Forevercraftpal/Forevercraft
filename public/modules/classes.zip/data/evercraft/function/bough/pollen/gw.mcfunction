# Gearwright pollen self-reconcile (U1 Tinker / U6 Wire Pact / U11 Tinkermind Pact). Single writer for ec.pollen_gw_*. Dispatched from bough/pollen_tick when any online player has ec.gw_lvl>=1.
execute as @a[scores={ec.gw_n_u1=1..}] run scoreboard players set @s ec.pollen_gw_tinker 1
execute as @a[scores={ec.pollen_gw_tinker=1..}] unless score @s ec.gw_n_u1 matches 1.. run scoreboard players set @s ec.pollen_gw_tinker 0
execute as @a[scores={ec.gw_n_u6=1..}] run scoreboard players set @s ec.pollen_gw_wire 1
execute as @a[scores={ec.pollen_gw_wire=1..}] unless score @s ec.gw_n_u6 matches 1.. run scoreboard players set @s ec.pollen_gw_wire 0
execute as @a[scores={ec.gw_n_u11=1..}] run scoreboard players set @s ec.pollen_gw_mind 1
execute as @a[scores={ec.pollen_gw_mind=1..}] unless score @s ec.gw_n_u11 matches 1.. run scoreboard players set @s ec.pollen_gw_mind 0
