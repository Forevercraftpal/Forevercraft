# Knight pollen self-reconcile (U2 Crest Bond / U4 Duelist Pact / U6 Noble Light). Single writer for ec.pollen_kt_*. Dispatched from bough/pollen_tick when any online player has ec.kt_lvl>=1.
execute as @a[scores={ec.kt_n_u2=1..}] run scoreboard players set @s ec.pollen_kt_oath 1
execute as @a[scores={ec.pollen_kt_oath=1..}] unless score @s ec.kt_n_u2 matches 1.. run scoreboard players set @s ec.pollen_kt_oath 0
execute as @a[scores={ec.kt_n_u4=1..}] run scoreboard players set @s ec.pollen_kt_duel 1
execute as @a[scores={ec.pollen_kt_duel=1..}] unless score @s ec.kt_n_u4 matches 1.. run scoreboard players set @s ec.pollen_kt_duel 0
execute as @a[scores={ec.kt_n_u6=1..}] run scoreboard players set @s ec.pollen_kt_radiance 1
execute as @a[scores={ec.pollen_kt_radiance=1..}] unless score @s ec.kt_n_u6 matches 1.. run scoreboard players set @s ec.pollen_kt_radiance 0
