# Striker pollen self-reconcile (U6 Earthsong / U3 Quarryman / U5 Tremor Sense). Single writer for ec.pollen_sk_*. Dispatched from bough/pollen_tick when any online player has ec.sk_lvl>=1.
execute as @a[scores={ec.sk_n_u6=1..}] run scoreboard players set @s ec.pollen_sk_quake 1
execute as @a[scores={ec.pollen_sk_quake=1..}] unless score @s ec.sk_n_u6 matches 1.. run scoreboard players set @s ec.pollen_sk_quake 0
execute as @a[scores={ec.sk_n_u3=1..}] run scoreboard players set @s ec.pollen_sk_ore 1
execute as @a[scores={ec.pollen_sk_ore=1..}] unless score @s ec.sk_n_u3 matches 1.. run scoreboard players set @s ec.pollen_sk_ore 0
execute as @a[scores={ec.sk_n_u5=1..}] run scoreboard players set @s ec.pollen_sk_pulse 1
execute as @a[scores={ec.pollen_sk_pulse=1..}] unless score @s ec.sk_n_u5 matches 1.. run scoreboard players set @s ec.pollen_sk_pulse 0
