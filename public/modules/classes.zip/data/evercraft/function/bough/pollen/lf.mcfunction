# Lumberfell pollen self-reconcile (U1 Forester / U7 Forest Pact / U11 Heartfall Pact). Single writer for ec.pollen_lf_*. Dispatched from bough/pollen_tick when any online player has ec.lf_lvl>=1.
execute as @a[scores={ec.lf_n_u1=1..}] run scoreboard players set @s ec.pollen_lf_forest 1
execute as @a[scores={ec.pollen_lf_forest=1..}] unless score @s ec.lf_n_u1 matches 1.. run scoreboard players set @s ec.pollen_lf_forest 0
execute as @a[scores={ec.lf_n_u7=1..}] run scoreboard players set @s ec.pollen_lf_pact 1
execute as @a[scores={ec.pollen_lf_pact=1..}] unless score @s ec.lf_n_u7 matches 1.. run scoreboard players set @s ec.pollen_lf_pact 0
execute as @a[scores={ec.lf_n_u11=1..}] run scoreboard players set @s ec.pollen_lf_heart 1
execute as @a[scores={ec.pollen_lf_heart=1..}] unless score @s ec.lf_n_u11 matches 1.. run scoreboard players set @s ec.pollen_lf_heart 0
