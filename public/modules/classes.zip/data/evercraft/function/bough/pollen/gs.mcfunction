# Growseer pollen self-reconcile (U1 Gardener / U7 Bloom Pact / U11 Greenheart Pact). Single writer for ec.pollen_gs_*. Dispatched from bough/pollen_tick when any online player has ec.gs_lvl>=1.
execute as @a[scores={ec.gs_n_u1=1..}] run scoreboard players set @s ec.pollen_gs_garden 1
execute as @a[scores={ec.pollen_gs_garden=1..}] unless score @s ec.gs_n_u1 matches 1.. run scoreboard players set @s ec.pollen_gs_garden 0
execute as @a[scores={ec.gs_n_u7=1..}] run scoreboard players set @s ec.pollen_gs_bloom 1
execute as @a[scores={ec.pollen_gs_bloom=1..}] unless score @s ec.gs_n_u7 matches 1.. run scoreboard players set @s ec.pollen_gs_bloom 0
execute as @a[scores={ec.gs_n_u11=1..}] run scoreboard players set @s ec.pollen_gs_heart 1
execute as @a[scores={ec.pollen_gs_heart=1..}] unless score @s ec.gs_n_u11 matches 1.. run scoreboard players set @s ec.pollen_gs_heart 0
