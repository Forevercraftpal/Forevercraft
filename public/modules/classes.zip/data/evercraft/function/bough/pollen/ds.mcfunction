# Dual Swordsman pollen self-reconcile (U2 Mirror Heart / U4 Spiritwind / U5 Twin Vow). Single writer for ec.pollen_ds_*. Dispatched from bough/pollen_tick when any online player has ec.ds_lvl>=1.
execute as @a[scores={ec.ds_n_u2=1..}] run scoreboard players set @s ec.pollen_ds_twin 1
execute as @a[scores={ec.pollen_ds_twin=1..}] unless score @s ec.ds_n_u2 matches 1.. run scoreboard players set @s ec.pollen_ds_twin 0
execute as @a[scores={ec.ds_n_u4=1..}] run scoreboard players set @s ec.pollen_ds_wind 1
execute as @a[scores={ec.pollen_ds_wind=1..}] unless score @s ec.ds_n_u4 matches 1.. run scoreboard players set @s ec.pollen_ds_wind 0
execute as @a[scores={ec.ds_n_u5=1..}] run scoreboard players set @s ec.pollen_ds_vow 1
execute as @a[scores={ec.pollen_ds_vow=1..}] unless score @s ec.ds_n_u5 matches 1.. run scoreboard players set @s ec.pollen_ds_vow 0
