# Beastlord pollen self-reconcile (U2 Pack Pulse / C4 Beast Cry / U6 Mythkin Bond). Single writer for ec.pollen_bl_*. Dispatched from bough/pollen_tick when any online player has ec.bl_lvl>=1.
execute as @a[scores={ec.bl_n_u2=1..}] run scoreboard players set @s ec.pollen_bl_howl 1
execute as @a[scores={ec.pollen_bl_howl=1..}] unless score @s ec.bl_n_u2 matches 1.. run scoreboard players set @s ec.pollen_bl_howl 0
execute as @a[scores={ec.bl_n_c4=1..}] run scoreboard players set @s ec.pollen_bl_taunt 1
execute as @a[scores={ec.pollen_bl_taunt=1..}] unless score @s ec.bl_n_c4 matches 1.. run scoreboard players set @s ec.pollen_bl_taunt 0
execute as @a[scores={ec.bl_n_u6=1..}] run scoreboard players set @s ec.pollen_bl_myth 1
execute as @a[scores={ec.pollen_bl_myth=1..}] unless score @s ec.bl_n_u6 matches 1.. run scoreboard players set @s ec.pollen_bl_myth 0
