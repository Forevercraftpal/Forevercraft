# Rogue pollen self-reconcile (U7 Soft Step / U11 Wet Work / U8 Shadow Pact). Single writer for ec.pollen_rg_*. Dispatched from bough/pollen_tick when any online player has ec.rg_lvl>=1.
execute as @a[scores={ec.rg_n_u7=1..}] run scoreboard players set @s ec.pollen_rg_silent 1
execute as @a[scores={ec.pollen_rg_silent=1..}] unless score @s ec.rg_n_u7 matches 1.. run scoreboard players set @s ec.pollen_rg_silent 0
execute as @a[scores={ec.rg_n_u11=1..}] run scoreboard players set @s ec.pollen_rg_poison 1
execute as @a[scores={ec.pollen_rg_poison=1..}] unless score @s ec.rg_n_u11 matches 1.. run scoreboard players set @s ec.pollen_rg_poison 0
execute as @a[scores={ec.rg_n_u8=1..}] run scoreboard players set @s ec.pollen_rg_shadow 1
execute as @a[scores={ec.pollen_rg_shadow=1..}] unless score @s ec.rg_n_u8 matches 1.. run scoreboard players set @s ec.pollen_rg_shadow 0
