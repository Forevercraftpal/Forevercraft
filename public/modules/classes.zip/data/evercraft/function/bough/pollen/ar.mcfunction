# Archer pollen self-reconcile (U7 Wind Read / U6 Hawk Bond / U5 Range Vow). Single writer for ec.pollen_ar_*. Dispatched from bough/pollen_tick when any online player has ec.ar_lvl>=1.
execute as @a[scores={ec.ar_n_u7=1..}] run scoreboard players set @s ec.pollen_ar_wind 1
execute as @a[scores={ec.pollen_ar_wind=1..}] unless score @s ec.ar_n_u7 matches 1.. run scoreboard players set @s ec.pollen_ar_wind 0
execute as @a[scores={ec.ar_n_u6=1..}] run scoreboard players set @s ec.pollen_ar_eye 1
execute as @a[scores={ec.pollen_ar_eye=1..}] unless score @s ec.ar_n_u6 matches 1.. run scoreboard players set @s ec.pollen_ar_eye 0
execute as @a[scores={ec.ar_n_u5=1..}] run scoreboard players set @s ec.pollen_ar_range 1
execute as @a[scores={ec.pollen_ar_range=1..}] unless score @s ec.ar_n_u5 matches 1.. run scoreboard players set @s ec.pollen_ar_range 0
