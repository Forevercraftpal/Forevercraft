# Terrawarp pollen self-reconcile (U1 Pathwalker / U7 Pathwalker Pact / U11 Trailwalk Pact). Single writer for ec.pollen_tw_*. Dispatched from bough/pollen_tick when any online player has ec.tw_lvl>=1.
execute as @a[scores={ec.tw_n_u1=1..}] run scoreboard players set @s ec.pollen_tw_path 1
execute as @a[scores={ec.pollen_tw_path=1..}] unless score @s ec.tw_n_u1 matches 1.. run scoreboard players set @s ec.pollen_tw_path 0
execute as @a[scores={ec.tw_n_u7=1..}] run scoreboard players set @s ec.pollen_tw_pact 1
execute as @a[scores={ec.pollen_tw_pact=1..}] unless score @s ec.tw_n_u7 matches 1.. run scoreboard players set @s ec.pollen_tw_pact 0
execute as @a[scores={ec.tw_n_u11=1..}] run scoreboard players set @s ec.pollen_tw_walk 1
execute as @a[scores={ec.pollen_tw_walk=1..}] unless score @s ec.tw_n_u11 matches 1.. run scoreboard players set @s ec.pollen_tw_walk 0
