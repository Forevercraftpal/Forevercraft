# Sirencall pollen self-reconcile (U1 Fisher / U6 Pearl Pact / U11 Tidecaller Pact). Single writer for ec.pollen_sc_*. Dispatched from bough/pollen_tick when any online player has ec.sc_lvl>=1.
execute as @a[scores={ec.sc_n_u1=1..}] run scoreboard players set @s ec.pollen_sc_fisher 1
execute as @a[scores={ec.pollen_sc_fisher=1..}] unless score @s ec.sc_n_u1 matches 1.. run scoreboard players set @s ec.pollen_sc_fisher 0
execute as @a[scores={ec.sc_n_u6=1..}] run scoreboard players set @s ec.pollen_sc_pearl 1
execute as @a[scores={ec.pollen_sc_pearl=1..}] unless score @s ec.sc_n_u6 matches 1.. run scoreboard players set @s ec.pollen_sc_pearl 0
execute as @a[scores={ec.sc_n_u11=1..}] run scoreboard players set @s ec.pollen_sc_call 1
execute as @a[scores={ec.pollen_sc_call=1..}] unless score @s ec.sc_n_u11 matches 1.. run scoreboard players set @s ec.pollen_sc_call 0
