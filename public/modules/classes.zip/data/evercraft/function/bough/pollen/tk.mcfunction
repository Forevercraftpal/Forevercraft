# Tank pollen self-reconcile (U3 Iron Anchor / U7 Stone Brother / U6 Bulwark Beat). Single writer for ec.pollen_tk_*. Dispatched from bough/pollen_tick when any online player has ec.tk_lvl>=1.
execute as @a[scores={ec.tk_n_u3=1..}] run scoreboard players set @s ec.pollen_tk_root 1
execute as @a[scores={ec.pollen_tk_root=1..}] unless score @s ec.tk_n_u3 matches 1.. run scoreboard players set @s ec.pollen_tk_root 0
execute as @a[scores={ec.tk_n_u7=1..}] run scoreboard players set @s ec.pollen_tk_share 1
execute as @a[scores={ec.pollen_tk_share=1..}] unless score @s ec.tk_n_u7 matches 1.. run scoreboard players set @s ec.pollen_tk_share 0
execute as @a[scores={ec.tk_n_u6=1..}] run scoreboard players set @s ec.pollen_tk_drum 1
execute as @a[scores={ec.pollen_tk_drum=1..}] unless score @s ec.tk_n_u6 matches 1.. run scoreboard players set @s ec.pollen_tk_drum 0
