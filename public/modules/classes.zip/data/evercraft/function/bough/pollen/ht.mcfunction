# Hunter pollen self-reconcile (U2 Bloodline / U8 Quiet Mark / U5 Open Hunt). Single writer for ec.pollen_ht_*. Dispatched from bough/pollen_tick when any online player has ec.ht_lvl>=1.
execute as @a[scores={ec.ht_n_u2=1..}] run scoreboard players set @s ec.pollen_ht_track 1
execute as @a[scores={ec.pollen_ht_track=1..}] unless score @s ec.ht_n_u2 matches 1.. run scoreboard players set @s ec.pollen_ht_track 0
execute as @a[scores={ec.ht_n_u8=1..}] run scoreboard players set @s ec.pollen_ht_silent 1
execute as @a[scores={ec.pollen_ht_silent=1..}] unless score @s ec.ht_n_u8 matches 1.. run scoreboard players set @s ec.pollen_ht_silent 0
execute as @a[scores={ec.ht_n_u5=1..}] run scoreboard players set @s ec.pollen_ht_share 1
execute as @a[scores={ec.pollen_ht_share=1..}] unless score @s ec.ht_n_u5 matches 1.. run scoreboard players set @s ec.pollen_ht_share 0
