# Healer pollen self-reconcile (U10 Hearth Bond / U3 Calm Step / U7 Mercy Mark). Single writer for ec.pollen_hl_*. Dispatched from bough/pollen_tick when any online player has ec.hl_lvl>=1.
execute as @a[scores={ec.hl_n_u10=1..}] run scoreboard players set @s ec.pollen_hl_warmth 1
execute as @a[scores={ec.pollen_hl_warmth=1..}] unless score @s ec.hl_n_u10 matches 1.. run scoreboard players set @s ec.pollen_hl_warmth 0
execute as @a[scores={ec.hl_n_u3=1..}] run scoreboard players set @s ec.pollen_hl_steady 1
execute as @a[scores={ec.pollen_hl_steady=1..}] unless score @s ec.hl_n_u3 matches 1.. run scoreboard players set @s ec.pollen_hl_steady 0
execute as @a[scores={ec.hl_n_u7=1..}] run scoreboard players set @s ec.pollen_hl_mark 1
execute as @a[scores={ec.pollen_hl_mark=1..}] unless score @s ec.hl_n_u7 matches 1.. run scoreboard players set @s ec.pollen_hl_mark 0
