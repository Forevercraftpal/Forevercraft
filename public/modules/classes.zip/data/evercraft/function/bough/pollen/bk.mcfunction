# Berserker pollen self-reconcile (U3 Bloodroot / U4 Battle Hymn / U11 Twin Edge). Single writer for ec.pollen_bk_*. Dispatched from bough/pollen_tick when any online player has ec.bk_lvl>=1.
execute as @a[scores={ec.bk_n_u3=1..}] run scoreboard players set @s ec.pollen_bk_bleed 1
execute as @a[scores={ec.pollen_bk_bleed=1..}] unless score @s ec.bk_n_u3 matches 1.. run scoreboard players set @s ec.pollen_bk_bleed 0
execute as @a[scores={ec.bk_n_u4=1..}] run scoreboard players set @s ec.pollen_bk_warcry 1
execute as @a[scores={ec.pollen_bk_warcry=1..}] unless score @s ec.bk_n_u4 matches 1.. run scoreboard players set @s ec.pollen_bk_warcry 0
execute as @a[scores={ec.bk_n_u11=1..}] run scoreboard players set @s ec.pollen_bk_twin 1
execute as @a[scores={ec.pollen_bk_twin=1..}] unless score @s ec.bk_n_u11 matches 1.. run scoreboard players set @s ec.pollen_bk_twin 0
