# Stonestrike pollen self-reconcile (U1 Quarryman / U7 Quarry Pact / U11 Cornerstone Pact). Single writer for ec.pollen_ss_*. Dispatched from bough/pollen_tick when any online player has ec.ss_lvl>=1.
execute as @a[scores={ec.ss_n_u1=1..}] run scoreboard players set @s ec.pollen_ss_quarry 1
execute as @a[scores={ec.pollen_ss_quarry=1..}] unless score @s ec.ss_n_u1 matches 1.. run scoreboard players set @s ec.pollen_ss_quarry 0
execute as @a[scores={ec.ss_n_u7=1..}] run scoreboard players set @s ec.pollen_ss_pact 1
execute as @a[scores={ec.pollen_ss_pact=1..}] unless score @s ec.ss_n_u7 matches 1.. run scoreboard players set @s ec.pollen_ss_pact 0
execute as @a[scores={ec.ss_n_u11=1..}] run scoreboard players set @s ec.pollen_ss_corner 1
execute as @a[scores={ec.pollen_ss_corner=1..}] unless score @s ec.ss_n_u11 matches 1.. run scoreboard players set @s ec.pollen_ss_corner 0
