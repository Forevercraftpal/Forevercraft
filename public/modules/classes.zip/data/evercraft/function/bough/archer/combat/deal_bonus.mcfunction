# === BOUGH ARCHER — BONUS DAMAGE (macro) ===
# @s = the freshly-hit target (HurtTime already cleared by the caller). $(dmg) = summed combat
# bonus from bough/archer/combat/hit. Dealt as minecraft:magic so it can't re-fire the arrow-hit
# advancement (no recursion) while still crediting the archer (ar.shot_src) for kills/XP.
$damage @s $(dmg) minecraft:magic by @e[tag=ar.shot_src,limit=1,sort=nearest]
