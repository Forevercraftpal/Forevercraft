# === BOUGH ARCHER — COMBAT ON-ARROW-HIT RIDERS ===
# Called from artifacts/archer/on_hit (after its ec.ar_bow_id gate), gated ec.ar_b_combat>=1.
# @s = the archer, at @s. Every combat node rides the arrow-hit event: debuffs/self-effects
# (no damage = no recursion) + one summed bonus-damage deal + the C12 hail AoE. Bonus damage
# is dealt as minecraft:magic so it can't re-fire the hit advancement (filtered to
# direct_entity=minecraft:arrow) → no recursion, and HurtTime is cleared first to bypass the
# fresh i-frames from the arrow (kinetic-system precedent). Fresh-hit target = the HurtTime:10s
# entity (the passive_hit idiom), tagged once up front so later steps survive HurtTime clears.
tag @s add ar.shot_src
execute as @e[type=!player,sort=nearest,limit=1,distance=..100,nbt={HurtTime:10s}] run tag @s add ar.hit_tgt
execute unless entity @e[tag=ar.hit_tgt] run tag @s remove ar.shot_src
execute unless entity @e[tag=ar.hit_tgt] run return 0

# --- DEBUFFS ON TARGET (C3 Staggering Arrow · C8 Marked Shot · C5 Arrow Storm volley) ---
execute if score @s ec.ar_n_c3 matches 1.. as @e[tag=ar.hit_tgt] run effect give @s minecraft:slowness 3 1 true
execute if score @s ec.ar_n_c8 matches 1.. as @e[tag=ar.hit_tgt] run effect give @s minecraft:glowing 5 0 true
execute if score @s ec.ar_n_c5 matches 1.. at @e[tag=ar.hit_tgt] run effect give @e[type=#evercraft:hostile_mobs,distance=..4] minecraft:weakness 4 0 true

# --- SELF EFFECTS (C2 Snap Shot Speed · C7 Lifefletch heal) ---
execute if score @s ec.ar_n_c2 matches 1.. run effect give @s minecraft:speed 3 0 true
execute if score @s ec.ar_n_c7 matches 1.. run effect give @s minecraft:instant_health 1 0 true

# --- SUMMED BONUS DAMAGE (magic, ignores armor; one deal): C1 +1 · C4 +2 · C6 +2 · C11 +3 ·
#     C9 +4 if target ≥30 blocks · C10 +4 if target wounded (Health ≤10) ---
scoreboard players set #ar_bonus ec.temp 0
execute if score @s ec.ar_n_c1 matches 1.. run scoreboard players add #ar_bonus ec.temp 1
execute if score @s ec.ar_n_c4 matches 1.. run scoreboard players add #ar_bonus ec.temp 2
execute if score @s ec.ar_n_c6 matches 1.. run scoreboard players add #ar_bonus ec.temp 2
execute if score @s ec.ar_n_c11 matches 1.. run scoreboard players add #ar_bonus ec.temp 3
execute if score @s ec.ar_n_c9 matches 1.. if entity @e[tag=ar.hit_tgt,distance=30..] run scoreboard players add #ar_bonus ec.temp 4
scoreboard players set #ar_tgt_hp ec.temp 999
execute as @e[tag=ar.hit_tgt] store result score #ar_tgt_hp ec.temp run data get entity @s Health 1
execute if score @s ec.ar_n_c10 matches 1.. if score #ar_tgt_hp ec.temp matches 1..10 run scoreboard players add #ar_bonus ec.temp 4
execute store result storage evercraft:bough_combat dmg int 1 run scoreboard players get #ar_bonus ec.temp
execute if score #ar_bonus ec.temp matches 1.. as @e[tag=ar.hit_tgt] run data modify entity @s HurtTime set value 0s
execute if score #ar_bonus ec.temp matches 1.. as @e[tag=ar.hit_tgt] run function evercraft:bough/archer/combat/deal_bonus with storage evercraft:bough_combat

# --- C12 Hailstorm capstone: the arrow shatters into hail — 3 magic to all foes within 4 of the target ---
execute if score @s ec.ar_n_c12 matches 1.. as @e[tag=ar.hit_tgt] run data modify entity @s HurtTime set value 0s
execute if score @s ec.ar_n_c12 matches 1.. at @e[tag=ar.hit_tgt] as @e[type=#evercraft:hostile_mobs,distance=..4] run damage @s 3 minecraft:magic by @e[tag=ar.shot_src,limit=1,sort=nearest]

execute as @e[tag=ar.hit_tgt] run tag @s remove ar.hit_tgt
tag @s remove ar.shot_src
