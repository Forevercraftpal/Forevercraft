# === BOUGH ARCHER — PERMANENT PERK TICK (1s, ACCOUNT-WIDE) ===
# Archer utility perks are PERMANENT + CROSS-CLASS: gated on the node-bought flag, NOT the
# class — kept while playing anything (multiclass reward). Gate: any archer progress
# (ec.ar_lvl>=1). Theme = mobility + precision + light. Attribute perks: remove-for-all then
# add-for-owners (ids can't double-add). Probe ec.ar_phealth (mastery owns ec.ar_hp). Pollen
# U5/U6/U7 are support anchors — untouched.
execute unless entity @a[scores={ec.ar_lvl=1..}] run return run schedule function evercraft:bough/archer/perks/tick 20t

# --- MOVEMENT (U1 Lightstep · U3 Fleetfoot · U10 Wind-Walker · U12 Featherwake = +5% each) ---
execute as @a[scores={ec.ar_lvl=1..}] run attribute @s minecraft:movement_speed modifier remove evercraft:ar_perk_u1
execute as @a[scores={ec.ar_n_u1=1..}] run attribute @s minecraft:movement_speed modifier add evercraft:ar_perk_u1 0.05 add_multiplied_base
execute as @a[scores={ec.ar_lvl=1..}] run attribute @s minecraft:movement_speed modifier remove evercraft:ar_perk_u3
execute as @a[scores={ec.ar_n_u3=1..}] run attribute @s minecraft:movement_speed modifier add evercraft:ar_perk_u3 0.05 add_multiplied_base
execute as @a[scores={ec.ar_lvl=1..}] run attribute @s minecraft:movement_speed modifier remove evercraft:ar_perk_u10
execute as @a[scores={ec.ar_n_u10=1..}] run attribute @s minecraft:movement_speed modifier add evercraft:ar_perk_u10 0.05 add_multiplied_base

# --- GATHER (U2 Keen Eye = Luck I) ---
execute as @a[scores={ec.ar_n_u2=1..}] run effect give @s minecraft:luck 2 0 true

# --- KNOCKBACK RESISTANCE (U8 Nimble · U9 Steady Hand = +0.2 each) ---
execute as @a[scores={ec.ar_lvl=1..}] run attribute @s minecraft:knockback_resistance modifier remove evercraft:ar_perk_u8
execute as @a[scores={ec.ar_n_u8=1..}] run attribute @s minecraft:knockback_resistance modifier add evercraft:ar_perk_u8 0.2 add_value
execute as @a[scores={ec.ar_lvl=1..}] run attribute @s minecraft:knockback_resistance modifier remove evercraft:ar_perk_u9
execute as @a[scores={ec.ar_n_u9=1..}] run attribute @s minecraft:knockback_resistance modifier add evercraft:ar_perk_u9 0.2 add_value

# --- HEALTH (U4 Hardy Quiver · U11 Marksman's Vigor · U12 Featherwake = +1 heart each) ---
execute as @a[scores={ec.ar_lvl=1..}] run attribute @s minecraft:max_health modifier remove evercraft:ar_perk_u4
execute as @a[scores={ec.ar_n_u4=1..}] run attribute @s minecraft:max_health modifier add evercraft:ar_perk_u4 2 add_value
execute as @a[scores={ec.ar_lvl=1..}] run attribute @s minecraft:max_health modifier remove evercraft:ar_perk_u11
execute as @a[scores={ec.ar_n_u11=1..}] run attribute @s minecraft:max_health modifier add evercraft:ar_perk_u11 2 add_value
execute as @a[scores={ec.ar_lvl=1..}] run attribute @s minecraft:max_health modifier remove evercraft:ar_perk_u12
execute as @a[scores={ec.ar_n_u12=1..}] run attribute @s minecraft:max_health modifier add evercraft:ar_perk_u12 2 add_value
# U12 Featherwake capstone also grants +5% movement speed.
execute as @a[scores={ec.ar_lvl=1..}] run attribute @s minecraft:movement_speed modifier remove evercraft:ar_perk_u12s
execute as @a[scores={ec.ar_n_u12=1..}] run attribute @s minecraft:movement_speed modifier add evercraft:ar_perk_u12s 0.05 add_multiplied_base

# === MILESTONE PASSIVES (lvl 1/6/12, account-wide, precision-thematic) ===
# Lvl 1 Surefoot — Knockback Resistance +0.1.
execute as @a[scores={ec.ar_lvl=1..}] run attribute @s minecraft:knockback_resistance modifier remove evercraft:ar_ms1
execute as @a[scores={ec.ar_lvl=1..}] run attribute @s minecraft:knockback_resistance modifier add evercraft:ar_ms1 0.1 add_value
# Lvl 6 Eagle-Eyed — +1 heart.
execute as @a[scores={ec.ar_lvl=6..}] run attribute @s minecraft:max_health modifier remove evercraft:ar_ms6
execute as @a[scores={ec.ar_lvl=6..}] run attribute @s minecraft:max_health modifier add evercraft:ar_ms6 2 add_value
# Lvl 12 Deadeye — +1 heart + Luck II (the master forager).
execute as @a[scores={ec.ar_lvl=12..}] run attribute @s minecraft:max_health modifier remove evercraft:ar_ms12
execute as @a[scores={ec.ar_lvl=12..}] run attribute @s minecraft:max_health modifier add evercraft:ar_ms12 2 add_value
execute as @a[scores={ec.ar_lvl=12..}] run effect give @s minecraft:luck 2 1 true

# Milestone unlock chat (one-time each)
execute as @a[scores={ec.ar_lvl=1..}] unless score @s ec.ar_msn1 matches 1 run tellraw @s [{text:"✦ Archer Mastery 1 — ",color:"gray"},{text:"Surefoot",color:"white",bold:true},{text:" unlocked. Knockback resistance. Permanent, all classes.",color:"gray"}]
scoreboard players set @a[scores={ec.ar_lvl=1..}] ec.ar_msn1 1
execute as @a[scores={ec.ar_lvl=6..}] unless score @s ec.ar_msn6 matches 1 run tellraw @s [{text:"✦ Archer Mastery 6 — ",color:"gray"},{text:"Eagle-Eyed",color:"white",bold:true},{text:" unlocked. +1 heart. Permanent, all classes.",color:"gray"}]
scoreboard players set @a[scores={ec.ar_lvl=6..}] ec.ar_msn6 1
execute as @a[scores={ec.ar_lvl=12..}] unless score @s ec.ar_msn12 matches 1 run tellraw @s [{text:"✦ Archer Mastery 12 — ",color:"gray"},{text:"Deadeye",color:"white",bold:true},{text:" unlocked. +1 heart and Luck II. Permanent, all classes.",color:"gray"}]
scoreboard players set @a[scores={ec.ar_lvl=12..}] ec.ar_msn12 1

schedule function evercraft:bough/archer/perks/tick 20t
