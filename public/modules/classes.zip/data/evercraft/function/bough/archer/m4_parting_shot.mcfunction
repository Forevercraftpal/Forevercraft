# === BOUGH ARCHER — M4 PARTING SHOT (Wave 37, mastery_tick branch) ===
# Pivot: spec's "blink + next-arrow auto-crit on lethal hit" needed pre-damage
# interception + per-arrow crit-mark surfaces that don't exist. Replacement:
# below 30% HP → Speed III + Strength II for 5s, 60s cooldown. The hawk flees
# to strike again.
effect give @s minecraft:speed 5 2 true
effect give @s minecraft:strength 5 1 true
title @s actionbar [{text:"🏹 Parting Shot ",color:"aqua",bold:true},{text:"— the hawk flees to strike again",color:"gray",italic:true}]
execute as @a[distance=..16] if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.arrow.shoot master @s ~ ~ ~ 0.6 1.8
scoreboard players set @s ec.ar_m4_cd 60
