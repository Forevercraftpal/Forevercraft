# === BOUGH ARCHER — CROWN REMOVE ===
# Clears the Hawk Eye armor-pierce and arrow-vulnerability flags on @s. Idempotent.
scoreboard players set @s ec.ar_armor_pierce 0
scoreboard players set @s ec.ar_arrow_vuln 0
# Wave 15: the Steady Witness pollen rider is an attribute, not a flag — strip
# it with the Hawk Eye state.
attribute @s minecraft:attack_speed modifier remove evercraft:pollen_sn_focus
# Wave 17: the Sea Sense underwater-draw rider is an attribute too — strip it.
attribute @s minecraft:attack_speed modifier remove evercraft:pollen_jv_tide
# Wave 18: the Wire Pact attack-speed rider is an attribute too — strip it.
attribute @s minecraft:attack_speed modifier remove evercraft:pollen_gw_wire
