# === BOUGH ARCHER — M3 WIND MASTERY (Wave 37, kill adv reward) ===
# Pivot: spec's "outdoor shots ignore cover" needed line-of-sight / sky-access
# detection per shot — too expensive at server scale. Replacement: 5% chance
# per kill → +200 Mastery XP. The wind remembers each arrow.
advancement revoke @s only evercraft:bough/ar_m3_kill
execute unless score @s ec.ar_n_m3 matches 1.. run return 0
execute store result score #ar_m3_roll ec.temp run random value 1..20
execute unless score #ar_m3_roll ec.temp matches 1 run return 0
function evercraft:bough/mastery/find_xp {cls:"ar",amount:200}
title @s actionbar [{text:"✦ Wind Mastery ",color:"aqua",bold:true},{text:"— +200 Mastery XP",color:"gray",italic:true}]
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.arrow.shoot master @s ~ ~ ~ 0.3 1.6
