# === BOUGH ARCHER — WAR-PREP TICK (1s) ===
# Drains every armed Archer's war-prep duration (ec.ar_abil_dur) + shared recovery
# cooldown (ec.ar_abil_cd), applies the active mode's SUSTAINED effect (class-only:
# tag ec.ar_active), and announces the fade. Modes (ec.ar_abil_id):
#   1 Explosive Volley · 2 Eagle Eye · 3 Quickdraw (combat)
#   11 Hawk's Ascendance · 12 Windless Stance · 13 Galewind · 14 Parting Shot · 15 Crown's Hawk
# Explosive Volley (1) + Galewind (13) ride arrow hits in bough/archer/combat/hit — no
# sustained effect here. Cooldown/duration drain for ALL players (even out of stance, the
# berserker spin_cd precedent); only the sustained effects gate on ec.ar_active.
# Cheap idle gate: nothing armed and nothing recovering → reschedule and bail.
execute unless entity @a[scores={ec.ar_abil_cd=1..}] unless entity @a[scores={ec.ar_abil_id=1..}] run return run schedule function evercraft:bough/archer/abilities/tick 20t

# Recovery cooldown always drains.
scoreboard players remove @a[scores={ec.ar_abil_cd=1..}] ec.ar_abil_cd 1

# Duration drains; the 1->0 transition announces the fade once, then clears the mode id.
scoreboard players remove @a[scores={ec.ar_abil_dur=1..}] ec.ar_abil_dur 1
execute as @a[scores={ec.ar_abil_dur=0,ec.ar_abil_id=1..}] run tellraw @s [{text:"⚔ ",color:"gray"},{text:"War-prep faded.",color:"gray",italic:true}]
scoreboard players set @a[scores={ec.ar_abil_dur=0,ec.ar_abil_id=1..}] ec.ar_abil_id 0

# --- SUSTAINED EFFECTS (class-only: must be wielding the bow) ---
# 2 Eagle Eye — hunter's focus.
execute as @a[tag=ec.ar_active,scores={ec.ar_abil_id=2,ec.ar_abil_dur=1..}] run effect give @s minecraft:strength 2 0 true
execute as @a[tag=ec.ar_active,scores={ec.ar_abil_id=2,ec.ar_abil_dur=1..}] run effect give @s minecraft:night_vision 2 0 true
# 3 Quickdraw — fleet repositioning.
execute as @a[tag=ec.ar_active,scores={ec.ar_abil_id=3,ec.ar_abil_dur=1..}] run effect give @s minecraft:speed 2 1 true
execute as @a[tag=ec.ar_active,scores={ec.ar_abil_id=3,ec.ar_abil_dur=1..}] run effect give @s minecraft:haste 2 1 true
execute as @a[tag=ec.ar_active,scores={ec.ar_abil_id=3,ec.ar_abil_dur=1..}] run effect give @s minecraft:jump_boost 2 0 true
# 11 Hawk's Ascendance.
execute as @a[tag=ec.ar_active,scores={ec.ar_abil_id=11,ec.ar_abil_dur=1..}] run effect give @s minecraft:strength 2 1 true
# 12 Windless Stance.
execute as @a[tag=ec.ar_active,scores={ec.ar_abil_id=12,ec.ar_abil_dur=1..}] run effect give @s minecraft:slow_falling 2 0 true
execute as @a[tag=ec.ar_active,scores={ec.ar_abil_id=12,ec.ar_abil_dur=1..}] run effect give @s minecraft:resistance 2 0 true
# 13 Galewind — Speed (gale knockback rides arrow hits).
execute as @a[tag=ec.ar_active,scores={ec.ar_abil_id=13,ec.ar_abil_dur=1..}] run effect give @s minecraft:speed 2 1 true
# 14 Parting Shot (manual).
execute as @a[tag=ec.ar_active,scores={ec.ar_abil_id=14,ec.ar_abil_dur=1..}] run effect give @s minecraft:speed 2 2 true
execute as @a[tag=ec.ar_active,scores={ec.ar_abil_id=14,ec.ar_abil_dur=1..}] run effect give @s minecraft:strength 2 1 true
# (M5 Crown's Hawk is now a CROSS-CLASS Crown ultimate — handled in bough/abilities/ult_tick.)

schedule function evercraft:bough/archer/abilities/tick 20t
