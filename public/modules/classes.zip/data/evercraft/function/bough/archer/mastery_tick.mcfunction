# === BOUGH ARCHER — MASTERY TICK (1s, Wave 37) ===
# M3 fires from kill adv. This tick handles M1 (+5% attack damage), M2
# (passive Slow Falling), M4 (panic save), M5 (+5% attack damage).
execute unless entity @a[tag=ec.ar_active] run return run schedule function evercraft:bough/archer/mastery_tick 20t

scoreboard players remove @a[scores={ec.ar_m4_cd=1..}] ec.ar_m4_cd 1

# M1 Hawk Mastery (pivot): passive +5% attack_damage while ar_active. Spec's
# "bow crit +10%" needed a bow-crit surface that 26.1 doesn't expose.
execute as @a[scores={ec.ar_n_m1=1..},tag=ec.ar_active] run attribute @s minecraft:attack_damage modifier remove evercraft:bough_ar_m1
execute as @a[scores={ec.ar_n_m1=1..},tag=ec.ar_active] run attribute @s minecraft:attack_damage modifier add evercraft:bough_ar_m1 0.05 add_multiplied_base
execute as @a unless score @s ec.ar_n_m1 matches 1.. run attribute @s minecraft:attack_damage modifier remove evercraft:bough_ar_m1
execute as @a[tag=!ec.ar_active] run attribute @s minecraft:attack_damage modifier remove evercraft:bough_ar_m1

# M5 Crown's Hawk (pivot): passive +5% attack_damage while ar_active. Spec's
# "armor-pierce +50%" needed an armor-pierce surface that doesn't exist.
execute as @a[scores={ec.ar_n_m5=1..},tag=ec.ar_active] run attribute @s minecraft:attack_damage modifier remove evercraft:bough_ar_m5
execute as @a[scores={ec.ar_n_m5=1..},tag=ec.ar_active] run attribute @s minecraft:attack_damage modifier add evercraft:bough_ar_m5 0.05 add_multiplied_base
execute as @a unless score @s ec.ar_n_m5 matches 1.. run attribute @s minecraft:attack_damage modifier remove evercraft:bough_ar_m5
execute as @a[tag=!ec.ar_active] run attribute @s minecraft:attack_damage modifier remove evercraft:bough_ar_m5

# M2 Drawn Calm (pivot): passive Slow Falling I while ar_active. Spec's "bow-
# drawn 2s" required a drawn-state timer.
execute as @a[scores={ec.ar_n_m2=1..},tag=ec.ar_active] run effect give @s minecraft:slow_falling 2 0 true

# M4 Parting Shot: HP ≤ 5 + ar_active + cd ready → panic.
execute as @a[scores={ec.ar_n_m4=1..,ec.ar_m4_cd=..0},tag=ec.ar_active] store result score @s ec.ar_hp run data get entity @s Health 1
execute as @a[scores={ec.ar_n_m4=1..,ec.ar_m4_cd=..0,ec.ar_hp=..5},tag=ec.ar_active] at @s run function evercraft:bough/archer/m4_parting_shot

schedule function evercraft:bough/archer/mastery_tick 20t
