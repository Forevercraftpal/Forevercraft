# === BOUGH ARCHER — LOAD ===
scoreboard objectives add ec.ar_b_combat dummy "Bough AR Combat Points"
scoreboard objectives add ec.ar_b_util dummy "Bough AR Utility Points"
scoreboard objectives add ec.ar_b_mast dummy "Bough AR Mastery Points"
scoreboard objectives add ec.ar_b_crown dummy "Bough AR Crown Owned"
scoreboard objectives add ec.ar_bough_view dummy "Bough AR Codex View"
scoreboard objectives add ec.ar_lx dummy "Bough AR Last X"
scoreboard objectives add ec.ar_lz dummy "Bough AR Last Z"
scoreboard objectives add ec.ar_lyaw dummy "Bough AR Last Yaw"
scoreboard objectives add ec.ar_armor_pierce dummy "Bough AR Armor Pierce"
scoreboard objectives add ec.ar_arrow_vuln dummy "Bough AR Arrow Vuln"
scoreboard objectives add ec.ar_n_c1 dummy "AR C1"
scoreboard objectives add ec.ar_n_c2 dummy "AR C2"
scoreboard objectives add ec.ar_n_c3 dummy "AR C3"
scoreboard objectives add ec.ar_n_c4 dummy "AR C4"
scoreboard objectives add ec.ar_n_c5 dummy "AR C5"
scoreboard objectives add ec.ar_n_c6 dummy "AR C6"
scoreboard objectives add ec.ar_n_c7 dummy "AR C7"
scoreboard objectives add ec.ar_n_c8 dummy "AR C8"
scoreboard objectives add ec.ar_n_c9 dummy "AR C9"
scoreboard objectives add ec.ar_n_c10 dummy "AR C10"
scoreboard objectives add ec.ar_n_c11 dummy "AR C11"
scoreboard objectives add ec.ar_n_c12 dummy "AR C12"
scoreboard objectives add ec.ar_n_u1 dummy "AR U1"
scoreboard objectives add ec.ar_n_u2 dummy "AR U2"
scoreboard objectives add ec.ar_n_u3 dummy "AR U3"
scoreboard objectives add ec.ar_n_u4 dummy "AR U4"
scoreboard objectives add ec.ar_n_u5 dummy "AR U5"
scoreboard objectives add ec.ar_n_u6 dummy "AR U6"
scoreboard objectives add ec.ar_n_u7 dummy "AR U7"
scoreboard objectives add ec.ar_n_u8 dummy "AR U8"
scoreboard objectives add ec.ar_n_u9 dummy "AR U9"
scoreboard objectives add ec.ar_n_u10 dummy "AR U10"
scoreboard objectives add ec.ar_n_u11 dummy "AR U11"
scoreboard objectives add ec.ar_n_u12 dummy "AR U12"
scoreboard objectives add ec.ar_n_m1 dummy "AR M1"
scoreboard objectives add ec.ar_n_m2 dummy "AR M2"
scoreboard objectives add ec.ar_n_m3 dummy "AR M3"
scoreboard objectives add ec.ar_n_m4 dummy "AR M4"
scoreboard objectives add ec.ar_n_m5 dummy "AR M5"
# Mastery consumers (Wave 37): HP probe + M4 cooldown.
scoreboard objectives add ec.ar_hp dummy "AR HP Probe"
scoreboard objectives add ec.ar_m4_cd dummy "AR M4 Cooldown"
# War-prep abilities (2026-06-22): one armed mode at a time + shared recovery cooldown.
# Armed by right-clicking an owned ability node (C2/C5/C8 + M1-M5) → bough/abilities/arm.
scoreboard objectives add ec.ar_abil_id dummy "AR War-Prep Mode"
scoreboard objectives add ec.ar_abil_dur dummy "AR War-Prep Duration"
scoreboard objectives add ec.ar_abil_cd dummy "AR War-Prep Cooldown"
# Combat tree (rewrite 2026-06-21): every combat node is an on-arrow-hit rider, wired in
# artifacts/archer/on_hit → bough/archer/combat/hit (event-driven; no combat tick needed).
# PERMANENT account-wide perks + lvl 1/6/12 milestones (util-tree rewrite 2026-06-21).
scoreboard objectives add ec.ar_phealth dummy "AR Perk HP Probe"
scoreboard objectives add ec.ar_msn1 dummy "AR Milestone 1 Seen"
scoreboard objectives add ec.ar_msn6 dummy "AR Milestone 6 Seen"
scoreboard objectives add ec.ar_msn12 dummy "AR Milestone 12 Seen"
schedule function evercraft:bough/archer/crown_tick 20t
schedule function evercraft:bough/archer/mastery_tick 20t
schedule function evercraft:bough/archer/perks/tick 20t
schedule function evercraft:bough/archer/abilities/tick 20t
