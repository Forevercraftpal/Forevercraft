# === BOUGH ARCHER — CROWN TICK (1s) ===
# Hawk Eye: arrows ignore 50% armor; you take double damage from arrows.
# The flags (ec.ar_armor_pierce / ec.ar_arrow_vuln) ARE live: crown_apply
# reconciles them each second while owned and the class is active
# (ec.ar_bow_id score, NOT a tag).
execute unless entity @a[scores={ec.ar_bow_id=1..,ec.ar_b_crown=1}] run return run schedule function evercraft:bough/archer/crown_tick 20t
execute as @a[scores={ec.ar_bow_id=1..,ec.ar_b_crown=1}] at @s run function evercraft:bough/archer/crown_apply
schedule function evercraft:bough/archer/crown_tick 20t
