# === BOUGH ARCHER — CROWN APPLY (Hawk Eye) ===
# Run as @s = active archer owning the Crown. Arrows ignore 50% armor
# (ec.ar_armor_pierce read by the bow-shot event hook); you take double damage
# from arrows (ec.ar_arrow_vuln read by the incoming-arrow handler), reconciled
# idempotently each second (Wrathblood pattern).
scoreboard players set @s ec.ar_armor_pierce 1
scoreboard players set @s ec.ar_arrow_vuln 1

# Pollen · pollen_sn_focus (Sentinel U6 Steady Witness → Archer) — Living Bough
# Wave 15 consumer: the witness steadies the draw hand. +5% attack speed while
# the flag is owned. NOTE: no bow-charge-speed surface exists (vanilla bow draw
# is fixed-rate and the pack has no dedicated draw-speed state) — attack_speed
# is the Wave 15 brief's sanctioned wiring (quicker strike recovery between
# shots). Reconciled idempotently each 1s apply; stripped in crown_remove.
attribute @s minecraft:attack_speed modifier remove evercraft:pollen_sn_focus
execute if score @s ec.pollen_sn_focus matches 1.. run attribute @s minecraft:attack_speed modifier add evercraft:pollen_sn_focus 0.05 add_multiplied_base

# Pollen · pollen_jv_tide (Javelin U6 Sea Sense → Archer) — Living Bough Wave 17
# consumer: the sea-sense steadies the draw beneath the surface. +25% attack
# speed while the flag is owned AND the archer is in water (the "underwater
# draw" — no bow-charge-speed surface exists, the same attack_speed fallback as
# sn_focus above). The unconditional remove strips it within 1s of leaving the
# water or losing the flag; stripped for good in crown_remove.
attribute @s minecraft:attack_speed modifier remove evercraft:pollen_jv_tide
execute if score @s ec.pollen_jv_tide matches 1.. if entity @s[predicate=evercraft:in_water] run attribute @s minecraft:attack_speed modifier add evercraft:pollen_jv_tide 0.25 add_multiplied_base

# Pollen · pollen_gw_wire (Gearwright U6 Wire Pact → Archer) — Living Bough
# Wave 18 consumer: wire-trued limbs snap back quicker. +5% attack speed while
# the flag is owned, stacking with sn_focus's +5% above (separate modifier id;
# the same attack_speed fallback — no bow-charge-speed surface exists).
# Reconciled idempotently each 1s apply; stripped in crown_remove.
attribute @s minecraft:attack_speed modifier remove evercraft:pollen_gw_wire
execute if score @s ec.pollen_gw_wire matches 1.. run attribute @s minecraft:attack_speed modifier add evercraft:pollen_gw_wire 0.05 add_multiplied_base
