# === BOUGH — Resonance Grant (macro) — DEPRECATED 2026-06-14 ===
# The resonance economy was replaced by Mastery XP (bough/mastery/*). Nothing in
# the live game calls this anymore (earning sites now grant XP via
# evercraft:bough/mastery/find_xp; the affinity chokepoints feed levels). Kept
# only so the legacy admin give_iron/steel/myth/ancient fixtures don't error;
# ec.res_* is registered-but-deprecated and zeroed by bough/mastery/migrate.
# Usage (legacy): function evercraft:bough/grant {cls:"bk",tier:"iron",amount:1}

$scoreboard players add @s ec.res_$(tier)_$(cls) $(amount)
