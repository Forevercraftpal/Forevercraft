# === LIVING BOUGH — FOUNDATION LOAD ===
# Joseph 2026-06-10. Design: _council/2026-06-10-living-bough/DESIGN.md.
# Declares per-player Resonance scoreboards (4 tiers × 14 classes) and the
# universal bough infrastructure. Per-class boughs (e.g. bough/berserker/load)
# declare their own node/branch/crown scoreboards and chain from here.
#
# Resonance scoreboards naming: ec.res_<tier>_<cls>, tiers iron/steel/myth/anci,
# classes bk/rg/dn/sk/sn/hl/bl/jv/hp/ar/ht/kt/tk/ds.

# === MASTERY XP ENGINE (2026-06-14) — replaces the resonance economy ===
# Per-class usage XP → Level → Bough Points + the shared cross-training pool.
# The ec.res_* pools below are DEPRECATED (zeroed by bough/mastery/migrate; kept
# registered during cutover so partially-migrated readouts don't error). Spends
# now drain ec.<cls>_pts with a level-gate; see bough/mastery/load.
function evercraft:bough/mastery/load

# --- Berserker pool (Iron, Steel, Mythril, Ancient) [DEPRECATED — see above] ---
scoreboard objectives add ec.res_iron_bk dummy "Iron Resonance · Berserker"
scoreboard objectives add ec.res_steel_bk dummy "Steel Resonance · Berserker"
scoreboard objectives add ec.res_myth_bk dummy "Mythril Resonance · Berserker"
scoreboard objectives add ec.res_anci_bk dummy "Ancient Resonance · Berserker"

# --- Rogue pool ---
scoreboard objectives add ec.res_iron_rg dummy "Iron Resonance · Rogue"
scoreboard objectives add ec.res_steel_rg dummy "Steel Resonance · Rogue"
scoreboard objectives add ec.res_myth_rg dummy "Mythril Resonance · Rogue"
scoreboard objectives add ec.res_anci_rg dummy "Ancient Resonance · Rogue"

# --- Dancer pool ---
scoreboard objectives add ec.res_iron_dn dummy "Iron Resonance · Dancer"
scoreboard objectives add ec.res_steel_dn dummy "Steel Resonance · Dancer"
scoreboard objectives add ec.res_myth_dn dummy "Mythril Resonance · Dancer"
scoreboard objectives add ec.res_anci_dn dummy "Ancient Resonance · Dancer"

# --- Striker pool ---
scoreboard objectives add ec.res_iron_sk dummy "Iron Resonance · Striker"
scoreboard objectives add ec.res_steel_sk dummy "Steel Resonance · Striker"
scoreboard objectives add ec.res_myth_sk dummy "Mythril Resonance · Striker"
scoreboard objectives add ec.res_anci_sk dummy "Ancient Resonance · Striker"

# --- Sentinel pool ---
scoreboard objectives add ec.res_iron_sn dummy "Iron Resonance · Sentinel"
scoreboard objectives add ec.res_steel_sn dummy "Steel Resonance · Sentinel"
scoreboard objectives add ec.res_myth_sn dummy "Mythril Resonance · Sentinel"
scoreboard objectives add ec.res_anci_sn dummy "Ancient Resonance · Sentinel"

# --- Healer pool ---
scoreboard objectives add ec.res_iron_hl dummy "Iron Resonance · Healer"
scoreboard objectives add ec.res_steel_hl dummy "Steel Resonance · Healer"
scoreboard objectives add ec.res_myth_hl dummy "Mythril Resonance · Healer"
scoreboard objectives add ec.res_anci_hl dummy "Ancient Resonance · Healer"

# --- Beastlord pool ---
scoreboard objectives add ec.res_iron_bl dummy "Iron Resonance · Beastlord"
scoreboard objectives add ec.res_steel_bl dummy "Steel Resonance · Beastlord"
scoreboard objectives add ec.res_myth_bl dummy "Mythril Resonance · Beastlord"
scoreboard objectives add ec.res_anci_bl dummy "Ancient Resonance · Beastlord"

# --- Javelin pool ---
scoreboard objectives add ec.res_iron_jv dummy "Iron Resonance · Javelin"
scoreboard objectives add ec.res_steel_jv dummy "Steel Resonance · Javelin"
scoreboard objectives add ec.res_myth_jv dummy "Mythril Resonance · Javelin"
scoreboard objectives add ec.res_anci_jv dummy "Ancient Resonance · Javelin"

# --- Hoplite pool ---
scoreboard objectives add ec.res_iron_hp dummy "Iron Resonance · Hoplite"
scoreboard objectives add ec.res_steel_hp dummy "Steel Resonance · Hoplite"
scoreboard objectives add ec.res_myth_hp dummy "Mythril Resonance · Hoplite"
scoreboard objectives add ec.res_anci_hp dummy "Ancient Resonance · Hoplite"

# --- Archer pool ---
scoreboard objectives add ec.res_iron_ar dummy "Iron Resonance · Archer"
scoreboard objectives add ec.res_steel_ar dummy "Steel Resonance · Archer"
scoreboard objectives add ec.res_myth_ar dummy "Mythril Resonance · Archer"
scoreboard objectives add ec.res_anci_ar dummy "Ancient Resonance · Archer"

# --- Hunter pool ---
scoreboard objectives add ec.res_iron_ht dummy "Iron Resonance · Hunter"
scoreboard objectives add ec.res_steel_ht dummy "Steel Resonance · Hunter"
scoreboard objectives add ec.res_myth_ht dummy "Mythril Resonance · Hunter"
scoreboard objectives add ec.res_anci_ht dummy "Ancient Resonance · Hunter"

# --- Tank pool ---
scoreboard objectives add ec.res_iron_tk dummy "Iron Resonance · Tank"
scoreboard objectives add ec.res_steel_tk dummy "Steel Resonance · Tank"
scoreboard objectives add ec.res_myth_tk dummy "Mythril Resonance · Tank"
scoreboard objectives add ec.res_anci_tk dummy "Ancient Resonance · Tank"

# --- Knight pool ---
scoreboard objectives add ec.res_iron_kt dummy "Iron Resonance · Knight"
scoreboard objectives add ec.res_steel_kt dummy "Steel Resonance · Knight"
scoreboard objectives add ec.res_myth_kt dummy "Mythril Resonance · Knight"
scoreboard objectives add ec.res_anci_kt dummy "Ancient Resonance · Knight"

# --- Dual Swordsman pool (hidden until ec.ds_discovered) ---
scoreboard objectives add ec.res_iron_ds dummy "Iron Resonance · DS"
scoreboard objectives add ec.res_steel_ds dummy "Steel Resonance · DS"
scoreboard objectives add ec.res_myth_ds dummy "Mythril Resonance · DS"
scoreboard objectives add ec.res_anci_ds dummy "Ancient Resonance · DS"

# --- Other class pools land as each class bough is authored. Stub names listed
# here so the convention is visible at-a-glance; future PRs uncomment. ---
# scoreboard objectives add ec.res_iron_rg / _steel / _myth / _anci (Rogue)
# scoreboard objectives add ec.res_iron_dn / ...                    (Dancer)
# ...etc for sk, sn, hl, bl, jv, hp, ar, ht, kt, tk, ds.

# === CRAFTFOREVER CRAFTING-CLASS POOLS — Wave 7 (2026-06-11) ===
# Design: _council/2026-06-11-craftforever-bough/DESIGN.md §1/§5. Seven crafting
# classes get the same 4-tier Resonance pools as the 14 combat classes. Codes:
# ss/lf/gs/tw/sc/lm/gw (no clash with combat codes sk/sn/hl/...). Tier suffix is
# `anci` (NOT `anc`) — the universal spend/grant/click_crown_generic macros
# expand ec.res_$(tier)_$(cls) with tier values iron/steel/myth/anci.

# --- Stonestrike pool ---
scoreboard objectives add ec.res_iron_ss dummy "Iron Resonance · Stonestrike"
scoreboard objectives add ec.res_steel_ss dummy "Steel Resonance · Stonestrike"
scoreboard objectives add ec.res_myth_ss dummy "Mythril Resonance · Stonestrike"
scoreboard objectives add ec.res_anci_ss dummy "Ancient Resonance · Stonestrike"

# --- Lumberfell pool ---
scoreboard objectives add ec.res_iron_lf dummy "Iron Resonance · Lumberfell"
scoreboard objectives add ec.res_steel_lf dummy "Steel Resonance · Lumberfell"
scoreboard objectives add ec.res_myth_lf dummy "Mythril Resonance · Lumberfell"
scoreboard objectives add ec.res_anci_lf dummy "Ancient Resonance · Lumberfell"

# --- Growseer pool ---
scoreboard objectives add ec.res_iron_gs dummy "Iron Resonance · Growseer"
scoreboard objectives add ec.res_steel_gs dummy "Steel Resonance · Growseer"
scoreboard objectives add ec.res_myth_gs dummy "Mythril Resonance · Growseer"
scoreboard objectives add ec.res_anci_gs dummy "Ancient Resonance · Growseer"

# --- Terrawarp pool ---
scoreboard objectives add ec.res_iron_tw dummy "Iron Resonance · Terrawarp"
scoreboard objectives add ec.res_steel_tw dummy "Steel Resonance · Terrawarp"
scoreboard objectives add ec.res_myth_tw dummy "Mythril Resonance · Terrawarp"
scoreboard objectives add ec.res_anci_tw dummy "Ancient Resonance · Terrawarp"

# --- Sirencall pool ---
scoreboard objectives add ec.res_iron_sc dummy "Iron Resonance · Sirencall"
scoreboard objectives add ec.res_steel_sc dummy "Steel Resonance · Sirencall"
scoreboard objectives add ec.res_myth_sc dummy "Mythril Resonance · Sirencall"
scoreboard objectives add ec.res_anci_sc dummy "Ancient Resonance · Sirencall"

# --- Lamentor pool ---
scoreboard objectives add ec.res_iron_lm dummy "Iron Resonance · Lamentor"
scoreboard objectives add ec.res_steel_lm dummy "Steel Resonance · Lamentor"
scoreboard objectives add ec.res_myth_lm dummy "Mythril Resonance · Lamentor"
scoreboard objectives add ec.res_anci_lm dummy "Ancient Resonance · Lamentor"

# --- Gearwright pool ---
scoreboard objectives add ec.res_iron_gw dummy "Iron Resonance · Gearwright"
scoreboard objectives add ec.res_steel_gw dummy "Steel Resonance · Gearwright"
scoreboard objectives add ec.res_myth_gw dummy "Mythril Resonance · Gearwright"
scoreboard objectives add ec.res_anci_gw dummy "Ancient Resonance · Gearwright"

# Pending class_id snapshot for the CraftForever codex → bough handoff (set by
# bough/codex/craft_open<N> shims, read by bough/codex/open_craft_class — the
# crafting-class twin of ec.bough_pending_cls in bough/codex/load).
scoreboard objectives add ec.bough_craft_pending_cls dummy "Bough Craft Pending Class ID"

# First-time Reroot tutorial flag (Wave 37, 2026-06-12). One-shot per player:
# bough/codex/reroot_tutorial sets 1 on first hub open + skips on subsequent opens.
scoreboard objectives add ec.bough_reroot_seen dummy "Bough Reroot Tutorial Seen"

# === POLLEN SLOT ANCHORS — Wave 2 (2026-06-11) ===
# DESIGN §3.2/§4: 42 cross-class pollen flags, 3 anchors per class. A Pollen
# Anchor is a NORMAL bough node bought with normal Resonance; owning it holds
# ec.pollen_<cls>_<key> at 1 on the owner. Flags are stamped/unstamped ONLY by
# evercraft:bough/pollen_tick (single writer, 1s sweep — handles Reroot/strips).
# Receiving-class consumers land in incremental waves — Wave 14 (2026-06-11)
# wired the first 10; catalog in _council/2026-06-10-living-bough/DESIGN.md §10.
scoreboard objectives add ec.pollen_bk_bleed dummy "Pollen BK Bloodroot"
scoreboard objectives add ec.pollen_bk_warcry dummy "Pollen BK Battle Hymn"
scoreboard objectives add ec.pollen_bk_twin dummy "Pollen BK Twin Edge"
scoreboard objectives add ec.pollen_rg_silent dummy "Pollen RG Soft Step"
scoreboard objectives add ec.pollen_rg_poison dummy "Pollen RG Wet Work"
scoreboard objectives add ec.pollen_rg_shadow dummy "Pollen RG Shadow Pact"
scoreboard objectives add ec.pollen_dn_breath dummy "Pollen DN Breath-step"
scoreboard objectives add ec.pollen_dn_pivot dummy "Pollen DN Twist"
scoreboard objectives add ec.pollen_dn_tempo dummy "Pollen DN Tempo"
scoreboard objectives add ec.pollen_sk_quake dummy "Pollen SK Earthsong"
scoreboard objectives add ec.pollen_sk_ore dummy "Pollen SK Quarryman"
scoreboard objectives add ec.pollen_sk_pulse dummy "Pollen SK Tremor Sense"
scoreboard objectives add ec.pollen_sn_wall dummy "Pollen SN Bulwark Vow"
scoreboard objectives add ec.pollen_sn_focus dummy "Pollen SN Steady Witness"
scoreboard objectives add ec.pollen_sn_calm dummy "Pollen SN Iron Refrain"
scoreboard objectives add ec.pollen_hl_warmth dummy "Pollen HL Hearth Bond"
scoreboard objectives add ec.pollen_hl_steady dummy "Pollen HL Calm Step"
scoreboard objectives add ec.pollen_hl_mark dummy "Pollen HL Mercy Mark"
scoreboard objectives add ec.pollen_bl_howl dummy "Pollen BL Pack Pulse"
scoreboard objectives add ec.pollen_bl_taunt dummy "Pollen BL Beast Cry"
scoreboard objectives add ec.pollen_bl_myth dummy "Pollen BL Mythkin Bond"
scoreboard objectives add ec.pollen_jv_lend dummy "Pollen JV Lent Spear"
scoreboard objectives add ec.pollen_jv_tide dummy "Pollen JV Sea Sense"
scoreboard objectives add ec.pollen_jv_throw dummy "Pollen JV Skyseed"
scoreboard objectives add ec.pollen_hp_pass dummy "Pollen HP Phalanx Throw"
scoreboard objectives add ec.pollen_hp_call dummy "Pollen HP Banner Call"
scoreboard objectives add ec.pollen_hp_drum dummy "Pollen HP Wall Beats"
scoreboard objectives add ec.pollen_ar_wind dummy "Pollen AR Wind Read"
scoreboard objectives add ec.pollen_ar_eye dummy "Pollen AR Hawk Bond"
scoreboard objectives add ec.pollen_ar_range dummy "Pollen AR Range Vow"
scoreboard objectives add ec.pollen_ht_track dummy "Pollen HT Bloodline"
scoreboard objectives add ec.pollen_ht_silent dummy "Pollen HT Quiet Mark"
scoreboard objectives add ec.pollen_ht_share dummy "Pollen HT Open Hunt"
scoreboard objectives add ec.pollen_tk_root dummy "Pollen TK Iron Anchor"
scoreboard objectives add ec.pollen_tk_share dummy "Pollen TK Stone Brother"
scoreboard objectives add ec.pollen_tk_drum dummy "Pollen TK Bulwark Beat"
scoreboard objectives add ec.pollen_kt_oath dummy "Pollen KT Crest Bond"
scoreboard objectives add ec.pollen_kt_duel dummy "Pollen KT Duelist Pact"
scoreboard objectives add ec.pollen_kt_radiance dummy "Pollen KT Noble Light"
scoreboard objectives add ec.pollen_ds_twin dummy "Pollen DS Mirror Heart"
scoreboard objectives add ec.pollen_ds_wind dummy "Pollen DS Spiritwind"
scoreboard objectives add ec.pollen_ds_vow dummy "Pollen DS Twin Vow"

# === POLLEN SLOT ANCHORS — Wave 7 crafting classes (2026-06-11) ===
# Craftforever-bough DESIGN §7: 21 cross-class flags, 3 anchors per crafting
# class (U1/U7-or-U6/U11), partnering each crafting class with combat classes.
# Same single-writer contract: stamped/cleared ONLY by evercraft:bough/pollen_tick.
scoreboard objectives add ec.pollen_ss_quarry dummy "Pollen SS Quarryman"
scoreboard objectives add ec.pollen_ss_pact dummy "Pollen SS Quarry Pact"
scoreboard objectives add ec.pollen_ss_corner dummy "Pollen SS Cornerstone Pact"
scoreboard objectives add ec.pollen_lf_forest dummy "Pollen LF Forester"
scoreboard objectives add ec.pollen_lf_pact dummy "Pollen LF Forest Pact"
scoreboard objectives add ec.pollen_lf_heart dummy "Pollen LF Heartfall Pact"
scoreboard objectives add ec.pollen_gs_garden dummy "Pollen GS Gardener"
scoreboard objectives add ec.pollen_gs_bloom dummy "Pollen GS Bloom Pact"
scoreboard objectives add ec.pollen_gs_heart dummy "Pollen GS Greenheart Pact"
scoreboard objectives add ec.pollen_tw_path dummy "Pollen TW Pathwalker"
scoreboard objectives add ec.pollen_tw_pact dummy "Pollen TW Pathwalker Pact"
scoreboard objectives add ec.pollen_tw_walk dummy "Pollen TW Trailwalk Pact"
scoreboard objectives add ec.pollen_sc_fisher dummy "Pollen SC Fisher"
scoreboard objectives add ec.pollen_sc_pearl dummy "Pollen SC Pearl Pact"
scoreboard objectives add ec.pollen_sc_call dummy "Pollen SC Tidecaller Pact"
scoreboard objectives add ec.pollen_lm_tailor dummy "Pollen LM Tailor"
scoreboard objectives add ec.pollen_lm_banner dummy "Pollen LM Banner Pact"
scoreboard objectives add ec.pollen_lm_weave dummy "Pollen LM Silkweaver Pact"
scoreboard objectives add ec.pollen_gw_tinker dummy "Pollen GW Tinker"
scoreboard objectives add ec.pollen_gw_wire dummy "Pollen GW Wire Pact"
scoreboard objectives add ec.pollen_gw_mind dummy "Pollen GW Tinkermind Pact"

# Pollen flag sweep — 5s heartbeat (self-reschedules; default schedule = replace).
schedule function evercraft:bough/pollen_tick 100t

# === SOUL-ECHO REROOT — Wave 26 (2026-06-11) ===
# 2-click confirmation: hub [ Reroot ] button → bough/reroot/confirm {cls_id}
# arms a 5s window (ec.bough_reroot_arm=100, burned by reroot/tick); second
# click within window → bough/reroot/dispatch → bough/<cls>/reroot.
# NOTE: Reroot hub buttons authored for Berserker only (Wave 26). Other 20
# classes' hubs need the same pattern added — TODO future wave.
scoreboard objectives add ec.bough_reroot_target dummy "Bough Reroot Target Class ID"
scoreboard objectives add ec.bough_reroot_arm dummy "Bough Reroot Arm Window"
schedule function evercraft:bough/reroot/tick 1s replace

# --- Per-class bough loaders ---
function evercraft:bough/berserker/load
function evercraft:bough/rogue/load
function evercraft:bough/dancer/load
function evercraft:bough/striker/load
function evercraft:bough/sentinel/load
function evercraft:bough/healer/load
function evercraft:bough/beastlord/load
function evercraft:bough/javelin/load
function evercraft:bough/hoplite/load
function evercraft:bough/archer/load
function evercraft:bough/hunter/load
function evercraft:bough/tank/load
function evercraft:bough/knight/load
function evercraft:bough/dual_swordsman/load

# --- CraftForever crafting-class bough loaders (Wave 7) ---
# Only Stonestrike is authored so far; the other six rows soft-fail (missing
# function = no-op at runtime) until each class's authoring wave lands.
function evercraft:bough/stonestrike/load
function evercraft:bough/lumberfell/load
function evercraft:bough/growseer/load
function evercraft:bough/terrawarp/load
function evercraft:bough/sirencall/load
function evercraft:bough/lamentor/load
function evercraft:bough/gearwright/load

# --- Bough GUI infrastructure ---
function evercraft:bough/codex/load
