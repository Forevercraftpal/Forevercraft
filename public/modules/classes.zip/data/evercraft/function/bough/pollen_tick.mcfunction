# === LIVING BOUGH — POLLEN ANCHOR TICK (5s) ===
# Wave 2 (2026-06-11). Design: _council/2026-06-10-living-bough/DESIGN.md §3.2/§4/§8.6.
# Per-class gated sweep deriving every ec.pollen_<cls>_<key> flag from Pollen-
# Anchor node ownership (3 anchors per class × 14 classes = 42 flags). This
# function is the SINGLE WRITER for all ec.pollen_* objectives: it stamps 1 while
# the anchor node is owned and clears to 0 when it is not — so Reroot wipes and
# admin strips (which zero ec.<cls>_n_* flags) propagate automatically with no
# extra wiring.
#
# OPT (2026-06-21): cadence dropped from 20t to 100t and the 21 inline class
# self-reconcile blocks were split into bough/pollen/<abbrev> sub-files. Each is
# dispatched ONLY when some online player has invested in that class
# (ec.<cls>_lvl=1..). Buying any Pollen node requires a level gate (>=1), so a
# node-owner always passes ec.<cls>_lvl=1.. — the gate never skips a player who
# owns a node. Classes nobody has touched cost one entity-test, not ~8 scans.
# The WAVE 14-24 DERIVED CONSUMER rows below stay INLINE and ungated: a gated-out
# class leaves its pollen flag at 0 (never set), so every derived row reading it
# computes the same 0 it would have before — correctness preserved.
#
# Receiving-class consumers land in incremental waves. Wave 14 (2026-06-11,
# first consumer wave) wired 10: seven read their flag at a live partner-class
# surface (timberfall/start, prospect/start_mine, artifacts/healer/pollen_amp,
# sentinel crown_apply ×2, beastlord tick_1s) and three are derived bonus
# scoreboards in the WAVE 14 section at the bottom of this sweep. Wave 15
# (2026-06-11, second consumer wave) wired 10 more: nine live (rogue/berserker/
# archer/sentinel crown surfaces, dancer flurry cooldown, prospect channel,
# healer pollen_amp ×2, beastlord warmth pulse) plus one derived row (WAVE 15
# section). Wave 16 (2026-06-11, third consumer wave) wired 12 more: eight live
# (healer pollen_amp ×3, DS crown_tick ICD burn, rogue/sentinel crown_apply,
# dancer crown_dodge + flurry cooldown) plus four derived rows (WAVE 16
# section). Wave 17 (2026-06-11, fourth consumer wave) wired 12 more: six live
# (tank/archer/rogue crown_apply, dancer crown_dodge, DS crown_tick ICD burn,
# prospect channel) plus six derived rows (WAVE 17 section). Wave 18
# (2026-06-11, fifth consumer wave — crafting-side) wired 12 more: eight live
# (tank/sentinel/archer crown_apply, beastlord tick_1s heart pulse, dancer
# flurry cooldown, prospect channel, healer pollen_amp, DS crown_tick ICD
# burn) plus four derived rows (WAVE 18 section). Wave 19 (2026-06-11, sixth
# and final ANCHOR-coverage wave) wired the last 7: five live (sentinel/tank
# crown_apply armor riders, prospect channel Stonestrike-side stack, healer
# pollen_amp saturation rider, tank crown_tick vow heartbeat) plus two derived
# rows (WAVE 19 section). 63/63 consumed — every Pollen Slot Anchor is
# accounted for; catalog: _council/2026-06-10-living-bough/DESIGN.md §10.
# Wave 20 (2026-06-11, Hunter Mark of Death) promoted five of the derived
# rows to LIVE: ec.ht_pln_mark/dmg/pulse/mercy/walk now have readers in
# bough/hunter/mark/* (the mark-event hook landed) — 48 live, 15 derived.
# Wave 22 (2026-06-11, Beastlord tamed-pet reframe) promoted two more:
# ec.bl_pln_pact/ec.bl_pln_call now have readers in
# bough/beastlord/cheat_death_tick (per-pet max_health reconcile — vanilla
# tameables ARE attribute-addressable; the "no strip path" objection was the
# companions-are-item_displays mistake) — 54 live, 9 derived.
#
# Scheduled from bough/load. Self-reschedules.

# OPT: empty server — skip the sweep, keep the heartbeat.
execute unless entity @a run return run schedule function evercraft:bough/pollen_tick 100t

# --- Per-class gated dispatch (combat) ---
# Each sub-file self-reconciles that class's 3 pollen flags. Gated on "someone
# online has invested in the class" via ec.<cls>_lvl=1.. — node purchase carries
# a level>=1 gate so any node-owner passes. Off when nobody has touched the class.
execute if entity @a[scores={ec.bk_lvl=1..}] run function evercraft:bough/pollen/bk
execute if entity @a[scores={ec.rg_lvl=1..}] run function evercraft:bough/pollen/rg
execute if entity @a[scores={ec.dn_lvl=1..}] run function evercraft:bough/pollen/dn
execute if entity @a[scores={ec.sk_lvl=1..}] run function evercraft:bough/pollen/sk
execute if entity @a[scores={ec.sn_lvl=1..}] run function evercraft:bough/pollen/sn
execute if entity @a[scores={ec.hl_lvl=1..}] run function evercraft:bough/pollen/hl
execute if entity @a[scores={ec.bl_lvl=1..}] run function evercraft:bough/pollen/bl
execute if entity @a[scores={ec.jv_lvl=1..}] run function evercraft:bough/pollen/jv
execute if entity @a[scores={ec.hp_lvl=1..}] run function evercraft:bough/pollen/hp
execute if entity @a[scores={ec.ar_lvl=1..}] run function evercraft:bough/pollen/ar
execute if entity @a[scores={ec.ht_lvl=1..}] run function evercraft:bough/pollen/ht
execute if entity @a[scores={ec.tk_lvl=1..}] run function evercraft:bough/pollen/tk
execute if entity @a[scores={ec.kt_lvl=1..}] run function evercraft:bough/pollen/kt
execute if entity @a[scores={ec.ds_lvl=1..}] run function evercraft:bough/pollen/ds

# --- Per-class gated dispatch (CraftForever crafting classes — Wave 7) ---
# Same contract as the combat dispatches above. A crafting class whose nodes
# aren't declared yet leaves its flags at 0 (the sub-file's selectors no-match),
# which is exactly the pre-split behavior — derived rows below read the same 0.
execute if entity @a[scores={ec.ss_lvl=1..}] run function evercraft:bough/pollen/ss
execute if entity @a[scores={ec.lf_lvl=1..}] run function evercraft:bough/pollen/lf
execute if entity @a[scores={ec.gs_lvl=1..}] run function evercraft:bough/pollen/gs
execute if entity @a[scores={ec.tw_lvl=1..}] run function evercraft:bough/pollen/tw
execute if entity @a[scores={ec.sc_lvl=1..}] run function evercraft:bough/pollen/sc
execute if entity @a[scores={ec.lm_lvl=1..}] run function evercraft:bough/pollen/lm
execute if entity @a[scores={ec.gw_lvl=1..}] run function evercraft:bough/pollen/gw

# === WAVE 14 — DERIVED CONSUMER BONUSES (published-only) ===
# First consumer wave (2026-06-11). Where the partner class has a LIVE effect
# surface, the consumer reads the pollen flag at that surface directly
# (timberfall/start, prospect/start_mine, healer pollen_amp, sentinel
# crown_apply, beastlord tick_1s). The three rows below are the pairs whose
# partner-side effect has NO live surface yet — this sweep derives a small
# per-player bonus scoreboard (same stamp/clear shape as the flags above;
# single writer = this function) so the future effect code just reads it:
#   ec.jv_pln_range → +1.0x Skyspear throw range (pollen_sc_fisher). LIVE
#     since Wave 25: read at bough/javelin/crown_apply (the ec.jv_spear_range
#     tenths recompute, 30→40), applied at the throw edge by spear_boost.
#   ec.hp_pln_rad   → +1 banner radius block (pollen_lm_banner). LIVE since
#     Wave 21: read at bough/hoplite/banner/rally (U9 Bannerwatch planted
#     banner — rally radius 5→6).
#   ec.kt_pln_eye   → +2 Duelist's Eye reveal blocks (pollen_gw_tinker).
#     LIVE since Wave 24: read at bough/knight/duel/get_reveal_range
#     (reveal ring 8→10, 12 with ec.kt_pln_myth too).
execute as @a[scores={ec.pollen_sc_fisher=1..}] run scoreboard players set @s ec.jv_pln_range 1
execute as @a[scores={ec.jv_pln_range=1..}] unless score @s ec.pollen_sc_fisher matches 1.. run scoreboard players set @s ec.jv_pln_range 0
execute as @a[scores={ec.pollen_lm_banner=1..}] run scoreboard players set @s ec.hp_pln_rad 1
execute as @a[scores={ec.hp_pln_rad=1..}] unless score @s ec.pollen_lm_banner matches 1.. run scoreboard players set @s ec.hp_pln_rad 0
execute as @a[scores={ec.pollen_gw_tinker=1..}] run scoreboard players set @s ec.kt_pln_eye 2
execute as @a[scores={ec.kt_pln_eye=1..}] unless score @s ec.pollen_gw_tinker matches 1.. run scoreboard players set @s ec.kt_pln_eye 0

# === WAVE 15 — DERIVED CONSUMER BONUSES ===
# Second consumer wave (2026-06-11). Same contract as the Wave 14 rows above.
#   ec.ht_pln_mark → +1 Mark of Death reach block (pollen_ar_eye). LIVE since
#     Wave 20: read at bough/hunter/mark/apply (32→33 victim-locate ring on
#     the sneak-hit mark SET).
execute as @a[scores={ec.pollen_ar_eye=1..}] run scoreboard players set @s ec.ht_pln_mark 1
execute as @a[scores={ec.ht_pln_mark=1..}] unless score @s ec.pollen_ar_eye matches 1.. run scoreboard players set @s ec.ht_pln_mark 0

# === WAVE 16 — DERIVED CONSUMER BONUSES ===
# Third consumer wave (2026-06-11). Same contract as the Wave 14/15 rows above.
#   ec.ht_pln_dmg   → +5% Hunter marked-target damage (pollen_bk_bleed). LIVE
#     since Wave 20: read at bough/hunter/mark/on_hit_marked (+1 bonus_strike
#     rider on the Crown's marked-hit amp — the +5% at damage resolution).
#   ec.ht_pln_pulse → +2 mark detection range blocks (pollen_sk_pulse). LIVE
#     since Wave 20: read at bough/hunter/mark/glow_owner (glow-pulse ring
#     24→26 blocks, +1s glow).
#   ec.hp_pln_wall  → +1 Spearwall path-around radius block (pollen_sn_wall).
#     LIVE since Wave 21: read at bough/hoplite/spearwall/tick — pure
#     terrain-blend invisibility has no radius surface, so the wall lingers
#     +1s instead (2s→3s), the design-sanctioned fallback (DESIGN §10.1h).
#   ec.bl_pln_pact  → +1 tamed-pet max HP in forest biome (pollen_lf_pact).
#     LIVE since Wave 22: read at bough/beastlord/cheat_death_tick (1s
#     reconcile — stamp/strip the evercraft:pollen_lf_pact max_health
#     modifier on owned loaded pets; the tag-marked strip pass IS the strip
#     path the old note said was missing).
execute as @a[scores={ec.pollen_bk_bleed=1..}] run scoreboard players set @s ec.ht_pln_dmg 1
execute as @a[scores={ec.ht_pln_dmg=1..}] unless score @s ec.pollen_bk_bleed matches 1.. run scoreboard players set @s ec.ht_pln_dmg 0
execute as @a[scores={ec.pollen_sk_pulse=1..}] run scoreboard players set @s ec.ht_pln_pulse 2
execute as @a[scores={ec.ht_pln_pulse=1..}] unless score @s ec.pollen_sk_pulse matches 1.. run scoreboard players set @s ec.ht_pln_pulse 0
execute as @a[scores={ec.pollen_sn_wall=1..}] run scoreboard players set @s ec.hp_pln_wall 1
execute as @a[scores={ec.hp_pln_wall=1..}] unless score @s ec.pollen_sn_wall matches 1.. run scoreboard players set @s ec.hp_pln_wall 0
execute as @a[scores={ec.pollen_lf_pact=1..}] run scoreboard players set @s ec.bl_pln_pact 1
execute as @a[scores={ec.bl_pln_pact=1..}] unless score @s ec.pollen_lf_pact matches 1.. run scoreboard players set @s ec.bl_pln_pact 0

# === WAVE 17 — DERIVED CONSUMER BONUSES ===
# Fourth consumer wave (2026-06-11). Same contract as the Wave 14/15/16 rows.
#   ec.kt_pln_myth  → +2 Duelist's Eye reveal blocks (pollen_bl_myth). LIVE
#     since Wave 24: read at bough/knight/duel/get_reveal_range (stacks with
#     ec.kt_pln_eye above — 8/10/12).
#   ec.ht_pln_mercy → marks heal allies 1 HP on the marked target's death
#     (pollen_hl_mark). LIVE since Wave 20: read at
#     bough/hunter/mark/grant_mark_resonance (nearest other player within
#     16 blocks of the kill).
#   ec.hp_pln_lend  → +5% Wall of Spears damage (pollen_jv_lend). LIVE since
#     Wave 21: read at bough/hoplite/wall/tick (+1 bonus_strike on the Wall's
#     1 dmg/s — the +5% at damage resolution, the pack's rounding idiom).
#   ec.jv_pln_pass  → +1.0x more Skyspear throw range (pollen_hp_pass). LIVE
#     since Wave 25: read at bough/javelin/crown_apply (the ec.jv_spear_range
#     tenths recompute — 50 with ec.jv_pln_range too), applied by spear_boost.
#   ec.sn_pln_range → derived row kept for the single-writer contract
#     (pollen_ar_range). LIVE since Wave 28 as a PIVOT — no radius logic
#     exists in binary Standfast, so the consumer reads the FLAG directly:
#     bough/sentinel/crown_tick slows hostiles within 3 blocks of an engaged
#     Sentinel (Slowness I 2s/1s refresh — "still as terrain, slow as
#     terrain").
#   ec.hp_pln_drum  → formation-march Speed I within 5 blocks of another
#     Hoplite-Crown holder (pollen_tk_drum). LIVE since Wave 21: read at
#     bough/hoplite/phalanx/tick (the drum keeps the march — the flag owner
#     marches with the phalanx, no Crown of their own needed).
execute as @a[scores={ec.pollen_bl_myth=1..}] run scoreboard players set @s ec.kt_pln_myth 2
execute as @a[scores={ec.kt_pln_myth=1..}] unless score @s ec.pollen_bl_myth matches 1.. run scoreboard players set @s ec.kt_pln_myth 0
execute as @a[scores={ec.pollen_hl_mark=1..}] run scoreboard players set @s ec.ht_pln_mercy 1
execute as @a[scores={ec.ht_pln_mercy=1..}] unless score @s ec.pollen_hl_mark matches 1.. run scoreboard players set @s ec.ht_pln_mercy 0
execute as @a[scores={ec.pollen_jv_lend=1..}] run scoreboard players set @s ec.hp_pln_lend 1
execute as @a[scores={ec.hp_pln_lend=1..}] unless score @s ec.pollen_jv_lend matches 1.. run scoreboard players set @s ec.hp_pln_lend 0
execute as @a[scores={ec.pollen_hp_pass=1..}] run scoreboard players set @s ec.jv_pln_pass 1
execute as @a[scores={ec.jv_pln_pass=1..}] unless score @s ec.pollen_hp_pass matches 1.. run scoreboard players set @s ec.jv_pln_pass 0
execute as @a[scores={ec.pollen_ar_range=1..}] run scoreboard players set @s ec.sn_pln_range 2
execute as @a[scores={ec.sn_pln_range=1..}] unless score @s ec.pollen_ar_range matches 1.. run scoreboard players set @s ec.sn_pln_range 0
execute as @a[scores={ec.pollen_tk_drum=1..}] run scoreboard players set @s ec.hp_pln_drum 1
execute as @a[scores={ec.hp_pln_drum=1..}] unless score @s ec.pollen_tk_drum matches 1.. run scoreboard players set @s ec.hp_pln_drum 0

# === WAVE 18 — DERIVED CONSUMER BONUSES ===
# Fifth consumer wave (2026-06-11, crafting-side). Same contract as the Wave
# 14-17 rows above.
#   ec.ht_pln_walk   → +1 Hunter mark slot (pollen_tw_walk). LIVE since
#     Wave 20: read at bough/hunter/mark/get_max_slots (1 base · +1 M5
#     Crown's Mark · +1 this flag).
#   ec.bl_pln_call   → +1 aquatic-pet max HP (pollen_sc_call): kept axolotls
#     (FromBucket:1b — axolotls have no Owner NBT; bucketed-then-placed is
#     the kept-pet signal). LIVE since Wave 22: read at
#     bough/beastlord/cheat_death_tick (same reconcile as ec.bl_pln_pact).
#   ec.dn_pln_tailor → derived row kept for the single-writer contract
#     (pollen_lm_tailor). LIVE since Wave 28 as a PIVOT — the Dancer dodge
#     is an instant pre-hit cancel with no i-frame duration to stretch, so
#     the consumer reads the FLAG directly: bough/dancer/crown_dodge grants
#     2s Speed I on every perfect dodge (rides next to the gs_bloom/ar_wind
#     riders, before the dual-wield gate).
#   ec.kt_pln_weave  → +5t Riposte parry window (pollen_lm_weave). LIVE since
#     Wave 24: read at the bough/knight/crown_tick parry-window recompute
#     (ec.kt_parry_win 8 → 13; 18 with ec.kt_pln_vow too). The window itself
#     is the published contract — parry DETECTION still waits on a
#     damage-event windup seam vanilla doesn't expose.
execute as @a[scores={ec.pollen_tw_walk=1..}] run scoreboard players set @s ec.ht_pln_walk 1
execute as @a[scores={ec.ht_pln_walk=1..}] unless score @s ec.pollen_tw_walk matches 1.. run scoreboard players set @s ec.ht_pln_walk 0
execute as @a[scores={ec.pollen_sc_call=1..}] run scoreboard players set @s ec.bl_pln_call 1
execute as @a[scores={ec.bl_pln_call=1..}] unless score @s ec.pollen_sc_call matches 1.. run scoreboard players set @s ec.bl_pln_call 0
execute as @a[scores={ec.pollen_lm_tailor=1..}] run scoreboard players set @s ec.dn_pln_tailor 5
execute as @a[scores={ec.dn_pln_tailor=1..}] unless score @s ec.pollen_lm_tailor matches 1.. run scoreboard players set @s ec.dn_pln_tailor 0
execute as @a[scores={ec.pollen_lm_weave=1..}] run scoreboard players set @s ec.kt_pln_weave 5
execute as @a[scores={ec.kt_pln_weave=1..}] unless score @s ec.pollen_lm_weave matches 1.. run scoreboard players set @s ec.kt_pln_weave 0

# === WAVE 19 — DERIVED CONSUMER BONUSES ===
# Sixth consumer wave (2026-06-11). Same contract as the Wave 14-18 rows
# above. With these two rows all 63 anchors are accounted for.
#   ec.bl_pln_share → derived row kept for the single-writer contract
#     (pollen_ht_share). LIVE since Wave 28 as a PIVOT — pet hits fire no
#     player advancement, so the pets SET the mark instead of riding it:
#     artifacts/beastlord/tick_1s → pollen_share_pulse (2s cadence, flag
#     read directly) marks hostiles within 5 blocks of any owned pet with a
#     3s ec.ht_marked, consumed by the Wave 20 mark system.
#   ec.bk_pln_wind  → +5% Berserker Whirlwind spin damage (pollen_ds_wind).
#     LIVE since Wave 25: read at bough/berserker/spin/fire (the Wrathblood
#     sneak-hit full-circle spin authored that wave).
execute as @a[scores={ec.pollen_ht_share=1..}] run scoreboard players set @s ec.bl_pln_share 1
execute as @a[scores={ec.bl_pln_share=1..}] unless score @s ec.pollen_ht_share matches 1.. run scoreboard players set @s ec.bl_pln_share 0
execute as @a[scores={ec.pollen_ds_wind=1..}] run scoreboard players set @s ec.bk_pln_wind 1
execute as @a[scores={ec.bk_pln_wind=1..}] unless score @s ec.pollen_ds_wind matches 1.. run scoreboard players set @s ec.bk_pln_wind 0

# === WAVE 24 — DERIVED CONSUMER BONUSES (Knight Duelist wave) ===
# Same contract as the Wave 14-19 rows above. One new row — the FIRST anchor
# to carry TWO live consumers (63 anchors, 64 consumer rows):
#   ec.kt_pln_vow → +5t Riposte parry window (pollen_ds_vow — the DS U5 Twin
#     Vow anchor's SECOND consumer, alongside its Wave 19 Tank iron-spirit
#     heartbeat). LIVE at birth: read at the bough/knight/crown_tick
#     parry-window recompute (ec.kt_parry_win 8 → 13; 18 with kt_pln_weave).
execute as @a[scores={ec.pollen_ds_vow=1..}] run scoreboard players set @s ec.kt_pln_vow 5
execute as @a[scores={ec.kt_pln_vow=1..}] unless score @s ec.pollen_ds_vow matches 1.. run scoreboard players set @s ec.kt_pln_vow 0
schedule function evercraft:bough/pollen_tick 100t
