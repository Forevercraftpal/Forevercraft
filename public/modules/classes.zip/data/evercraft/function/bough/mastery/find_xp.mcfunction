# === BOUGH MASTERY — NODE "FIND" XP (macro {cls, amount}) ===
# Small bonus Mastery XP from bough node procs that used to award resonance —
# the M3 "listen/spoor/find" abilities and the U12/C12 kill/gather bonuses. These
# all fire from USING the class's item, so they now feed that class's level.
# Run as @s. Banks a cross-training slice like any other gain.
$scoreboard players set #bough_amt ec.temp $(amount)
scoreboard players set #bough_nobank ec.temp 0
scoreboard players set #bough_silent ec.temp 0
$function evercraft:bough/mastery/add_xp {cls:"$(cls)"}
