# === BOUGH MASTERY — COMBAT XP TAP ===
# Called at the tail of affinity/internal_grant (run as @s, ec.aff_class 1-14 set,
# #delta = the post-cap, difficulty-scaled XP just granted). Funnels that XP into
# the matching bough class via the shared route_combat map.
execute unless score #delta ec.temp matches 1.. run return 0
scoreboard players operation #bough_amt ec.temp = #delta ec.temp
scoreboard players set #bough_nobank ec.temp 0
scoreboard players set #bough_silent ec.temp 0
function evercraft:bough/mastery/route_combat

# Usage-driven patina: fighting with the mainhand wears it (feeds ec.pd0, the
# mainhand patina accumulator the patina tick reads — was equip-time, now use).
# GATE (2026-06-21): the affinity passive tick (just HOLDING a class weapon, every
# 3.6s) also funnels its 7/14 XP through internal_grant -> here. Feeding pd0 on that
# path re-introduced equip-time aging (axe/morning-star "patina too fast"). Only the
# active-combat path adds wear; passive_grant_player sets #pat_nowear around its grant.
execute unless score #pat_nowear ec.temp matches 1 run scoreboard players add @s ec.pd0 25
