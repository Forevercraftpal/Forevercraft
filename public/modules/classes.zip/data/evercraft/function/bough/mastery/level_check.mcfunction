# === BOUGH MASTERY — LEVEL CHECK (macro {cls}) ===
# Re-derives ec.<cls>_lvl from ec.<cls>_xp using the curve total_xp(L)=base*L^2.
# Recurses to handle multi-level jumps (e.g. migration seeding a huge XP value).
# Grants +1 Bough Point (ec.<cls>_pts) + mirrors ec.<cls>_pte on each level gained,
# and fires a toast unless #bough_silent. Run as @s. Sole writer of ec.<cls>_lvl.

$scoreboard players operation #b_xp ec.temp = @s ec.$(cls)_xp
$scoreboard players operation #b_lvl ec.temp = @s ec.$(cls)_lvl

# Threshold for the NEXT level = base * (lvl+1)^2
scoreboard players operation #b_nl ec.temp = #b_lvl ec.temp
scoreboard players add #b_nl ec.temp 1
scoreboard players operation #b_thr ec.temp = #b_nl ec.temp
scoreboard players operation #b_thr ec.temp *= #b_nl ec.temp
scoreboard players operation #b_thr ec.temp *= #b_base ec.const

# Not enough XP for the next level — done.
execute if score #b_xp ec.temp < #b_thr ec.temp run return 0

# Level up: bump level + grant a point (and record it as earned)
$scoreboard players add @s ec.$(cls)_lvl 1
$scoreboard players add @s ec.$(cls)_pts 1
$scoreboard players add @s ec.$(cls)_pte 1
$execute if score #bough_silent ec.temp matches 0 run function evercraft:bough/mastery/notify_levelup {cls:"$(cls)"}

# Recurse in case multiple levels were crossed at once.
$function evercraft:bough/mastery/level_check {cls:"$(cls)"}
