# === BOUGH MASTERY — GATHER XP TAP ===
# Called after the class-add in craft_affinity/internal_grant (run as @s,
# ec.caff_class 1-7 set, #delta = post-cap difficulty-scaled XP). Routes that XP
# into the matching crafting bough class. The caller gates this `unless
# ec.caff_xfeed` so re-entrant artisan cross-feed calls don't double-count.
execute unless score #delta ec.temp matches 1.. run return 0
scoreboard players operation #bough_amt ec.temp = #delta ec.temp
scoreboard players set #bough_nobank ec.temp 0
scoreboard players set #bough_silent ec.temp 0

execute if score @s ec.caff_class matches 1 run function evercraft:bough/mastery/add_xp {cls:"ss"}
execute if score @s ec.caff_class matches 2 run function evercraft:bough/mastery/add_xp {cls:"lf"}
execute if score @s ec.caff_class matches 3 run function evercraft:bough/mastery/add_xp {cls:"gs"}
execute if score @s ec.caff_class matches 4 run function evercraft:bough/mastery/add_xp {cls:"tw"}
execute if score @s ec.caff_class matches 5 run function evercraft:bough/mastery/add_xp {cls:"sc"}
execute if score @s ec.caff_class matches 6 run function evercraft:bough/mastery/add_xp {cls:"lm"}
execute if score @s ec.caff_class matches 7 run function evercraft:bough/mastery/add_xp {cls:"gw"}

# Usage-driven patina: working with the mainhand tool wears it (feeds ec.pd0).
scoreboard players add @s ec.pd0 25
