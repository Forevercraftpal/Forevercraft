# === BOUGH MASTERY — ADD XP (macro {cls}) ===
# The SOLE writer of ec.<cls>_xp. Run as @s.
# Inputs (scratch on ec.temp, set by the caller):
#   #bough_amt    — XP to add (required, must be >0)
#   #bough_nobank — 1 = skip the cross-training bank slice (used by the trickle
#                   re-entry in spread_drain so drips don't re-bank → no loop)
#   #bough_silent — 1 = suppress the level-up toast (used by migration)
# Callers: affinity/internal_grant, craft_affinity/internal_grant, wm_hook,
#          patina/upgrade, spread_drain, migrate.

execute unless score #bough_amt ec.temp matches 1.. run return 0

# 1. Add to lifetime XP
$scoreboard players operation @s ec.$(cls)_xp += #bough_amt ec.temp

# 2. Cross-training bank slice (difficulty-scaled), unless suppressed
execute if score #bough_nobank ec.temp matches 0 run function evercraft:bough/mastery/bank_slice

# 3. Re-derive level; grant points + toast on each level crossed
$function evercraft:bough/mastery/level_check {cls:"$(cls)"}

# 4. Living Codex — stamp this as the most-recently-used class (the resolved cls handles
# the mace Sentinel/Striker split + Knight merge). Gated on #bough_nobank==0 so the
# automatic spread-drain trickle (a drip, not a use) never moves the marker. Combat vs
# craft routes to its own slot via map presence (absent key = no-op).
$execute if score #bough_nobank ec.temp matches 0 if data storage evercraft:ecodex clscmb.$(cls) store result score @s ec.ec_lastcmb run data get storage evercraft:ecodex clscmb.$(cls)
$execute if score #bough_nobank ec.temp matches 0 if data storage evercraft:ecodex clscft.$(cls) store result score @s ec.ec_lastcft run data get storage evercraft:ecodex clscft.$(cls)
