# === BOUGH MASTERY — CROSS-TRAINING DRIP (1s) ===
# Drains each player's shared bank into ONE of their classes per second via a
# rotating cursor (spread_drain) — O(1) work per player per tick, never a
# 21-class loop. The scores-selector is the existence gate: only players whose
# bank has reached the drip floor (20) do any work. Self-reschedules.
execute as @a[scores={ec.bough_bank=20..}] run function evercraft:bough/mastery/spread_drain
schedule function evercraft:bough/mastery/spread_tick 20t replace
