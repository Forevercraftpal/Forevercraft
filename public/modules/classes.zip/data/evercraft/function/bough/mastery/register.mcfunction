# === BOUGH MASTERY — OBJECTIVE REGISTRATION ===
# Per-class: _xp (lifetime Mastery XP), _lvl (derived level), _pts (spendable
# Bough Points), _pte (points earned lifetime, for reroot refund). 21×4 = 84.
# Called once from bough/mastery/load.

scoreboard objectives add ec.bk_xp dummy "Mastery XP · Berserker"
scoreboard objectives add ec.bk_lvl dummy "Mastery Lvl · Berserker"
scoreboard objectives add ec.bk_pts dummy "Bough Points · Berserker"
scoreboard objectives add ec.bk_pte dummy "Points Earned · Berserker"

scoreboard objectives add ec.rg_xp dummy "Mastery XP · Rogue"
scoreboard objectives add ec.rg_lvl dummy "Mastery Lvl · Rogue"
scoreboard objectives add ec.rg_pts dummy "Bough Points · Rogue"
scoreboard objectives add ec.rg_pte dummy "Points Earned · Rogue"

scoreboard objectives add ec.dn_xp dummy "Mastery XP · Dancer"
scoreboard objectives add ec.dn_lvl dummy "Mastery Lvl · Dancer"
scoreboard objectives add ec.dn_pts dummy "Bough Points · Dancer"
scoreboard objectives add ec.dn_pte dummy "Points Earned · Dancer"

scoreboard objectives add ec.sk_xp dummy "Mastery XP · Striker"
scoreboard objectives add ec.sk_lvl dummy "Mastery Lvl · Striker"
scoreboard objectives add ec.sk_pts dummy "Bough Points · Striker"
scoreboard objectives add ec.sk_pte dummy "Points Earned · Striker"

scoreboard objectives add ec.sn_xp dummy "Mastery XP · Sentinel"
scoreboard objectives add ec.sn_lvl dummy "Mastery Lvl · Sentinel"
scoreboard objectives add ec.sn_pts dummy "Bough Points · Sentinel"
scoreboard objectives add ec.sn_pte dummy "Points Earned · Sentinel"

scoreboard objectives add ec.hl_xp dummy "Mastery XP · Healer"
scoreboard objectives add ec.hl_lvl dummy "Mastery Lvl · Healer"
scoreboard objectives add ec.hl_pts dummy "Bough Points · Healer"
scoreboard objectives add ec.hl_pte dummy "Points Earned · Healer"

scoreboard objectives add ec.bl_xp dummy "Mastery XP · Beastlord"
scoreboard objectives add ec.bl_lvl dummy "Mastery Lvl · Beastlord"
scoreboard objectives add ec.bl_pts dummy "Bough Points · Beastlord"
scoreboard objectives add ec.bl_pte dummy "Points Earned · Beastlord"

scoreboard objectives add ec.jv_xp dummy "Mastery XP · Javelin"
scoreboard objectives add ec.jv_lvl dummy "Mastery Lvl · Javelin"
scoreboard objectives add ec.jv_pts dummy "Bough Points · Javelin"
scoreboard objectives add ec.jv_pte dummy "Points Earned · Javelin"

scoreboard objectives add ec.hp_xp dummy "Mastery XP · Hoplite"
scoreboard objectives add ec.hp_lvl dummy "Mastery Lvl · Hoplite"
scoreboard objectives add ec.hp_pts dummy "Bough Points · Hoplite"
scoreboard objectives add ec.hp_pte dummy "Points Earned · Hoplite"

scoreboard objectives add ec.ar_xp dummy "Mastery XP · Archer"
scoreboard objectives add ec.ar_lvl dummy "Mastery Lvl · Archer"
scoreboard objectives add ec.ar_pts dummy "Bough Points · Archer"
scoreboard objectives add ec.ar_pte dummy "Points Earned · Archer"

scoreboard objectives add ec.ht_xp dummy "Mastery XP · Hunter"
scoreboard objectives add ec.ht_lvl dummy "Mastery Lvl · Hunter"
scoreboard objectives add ec.ht_pts dummy "Bough Points · Hunter"
scoreboard objectives add ec.ht_pte dummy "Points Earned · Hunter"

scoreboard objectives add ec.kt_xp dummy "Mastery XP · Knight"
scoreboard objectives add ec.kt_lvl dummy "Mastery Lvl · Knight"
scoreboard objectives add ec.kt_pts dummy "Bough Points · Knight"
scoreboard objectives add ec.kt_pte dummy "Points Earned · Knight"

scoreboard objectives add ec.tk_xp dummy "Mastery XP · Tank"
scoreboard objectives add ec.tk_lvl dummy "Mastery Lvl · Tank"
scoreboard objectives add ec.tk_pts dummy "Bough Points · Tank"
scoreboard objectives add ec.tk_pte dummy "Points Earned · Tank"

scoreboard objectives add ec.ds_xp dummy "Mastery XP · Dual Swordsman"
scoreboard objectives add ec.ds_lvl dummy "Mastery Lvl · Dual Swordsman"
scoreboard objectives add ec.ds_pts dummy "Bough Points · Dual Swordsman"
scoreboard objectives add ec.ds_pte dummy "Points Earned · Dual Swordsman"

scoreboard objectives add ec.ss_xp dummy "Mastery XP · Stonestrike"
scoreboard objectives add ec.ss_lvl dummy "Mastery Lvl · Stonestrike"
scoreboard objectives add ec.ss_pts dummy "Bough Points · Stonestrike"
scoreboard objectives add ec.ss_pte dummy "Points Earned · Stonestrike"

scoreboard objectives add ec.lf_xp dummy "Mastery XP · Lumberfell"
scoreboard objectives add ec.lf_lvl dummy "Mastery Lvl · Lumberfell"
scoreboard objectives add ec.lf_pts dummy "Bough Points · Lumberfell"
scoreboard objectives add ec.lf_pte dummy "Points Earned · Lumberfell"

scoreboard objectives add ec.gs_xp dummy "Mastery XP · Growseer"
scoreboard objectives add ec.gs_lvl dummy "Mastery Lvl · Growseer"
scoreboard objectives add ec.gs_pts dummy "Bough Points · Growseer"
scoreboard objectives add ec.gs_pte dummy "Points Earned · Growseer"

scoreboard objectives add ec.tw_xp dummy "Mastery XP · Terrawarp"
scoreboard objectives add ec.tw_lvl dummy "Mastery Lvl · Terrawarp"
scoreboard objectives add ec.tw_pts dummy "Bough Points · Terrawarp"
scoreboard objectives add ec.tw_pte dummy "Points Earned · Terrawarp"

scoreboard objectives add ec.sc_xp dummy "Mastery XP · Sirencall"
scoreboard objectives add ec.sc_lvl dummy "Mastery Lvl · Sirencall"
scoreboard objectives add ec.sc_pts dummy "Bough Points · Sirencall"
scoreboard objectives add ec.sc_pte dummy "Points Earned · Sirencall"

scoreboard objectives add ec.lm_xp dummy "Mastery XP · Lamentor"
scoreboard objectives add ec.lm_lvl dummy "Mastery Lvl · Lamentor"
scoreboard objectives add ec.lm_pts dummy "Bough Points · Lamentor"
scoreboard objectives add ec.lm_pte dummy "Points Earned · Lamentor"

scoreboard objectives add ec.gw_xp dummy "Mastery XP · Gearwright"
scoreboard objectives add ec.gw_lvl dummy "Mastery Lvl · Gearwright"
scoreboard objectives add ec.gw_pts dummy "Bough Points · Gearwright"
scoreboard objectives add ec.gw_pte dummy "Points Earned · Gearwright"
