# === BOUGH MASTERY — ROUTE COMBAT XP TO CLASS ===
# Shared 14-branch map: ec.aff_class → bough class → add_xp. Run as @s with
# #bough_amt / #bough_nobank / #bough_silent already set by the caller.
# The mace (aff_class 4) splits by mode: shield up (ec.sk_sentinel) → Sentinel,
# else Striker. aff_class 13 (knight:true item w/o ec.kt_active) merges into Knight.
execute if score @s ec.aff_class matches 1 run function evercraft:bough/mastery/add_xp {cls:"rg"}
execute if score @s ec.aff_class matches 2 run function evercraft:bough/mastery/add_xp {cls:"bk"}
execute if score @s ec.aff_class matches 3 run function evercraft:bough/mastery/add_xp {cls:"dn"}
execute if score @s ec.aff_class matches 4 if entity @s[tag=ec.sk_sentinel] run function evercraft:bough/mastery/add_xp {cls:"sn"}
execute if score @s ec.aff_class matches 4 unless entity @s[tag=ec.sk_sentinel] run function evercraft:bough/mastery/add_xp {cls:"sk"}
execute if score @s ec.aff_class matches 5 run function evercraft:bough/mastery/add_xp {cls:"kt"}
execute if score @s ec.aff_class matches 6 run function evercraft:bough/mastery/add_xp {cls:"hl"}
execute if score @s ec.aff_class matches 7 run function evercraft:bough/mastery/add_xp {cls:"bl"}
execute if score @s ec.aff_class matches 8 run function evercraft:bough/mastery/add_xp {cls:"jv"}
execute if score @s ec.aff_class matches 9 run function evercraft:bough/mastery/add_xp {cls:"hp"}
execute if score @s ec.aff_class matches 10 run function evercraft:bough/mastery/add_xp {cls:"ar"}
execute if score @s ec.aff_class matches 11 run function evercraft:bough/mastery/add_xp {cls:"ht"}
execute if score @s ec.aff_class matches 12 run function evercraft:bough/mastery/add_xp {cls:"tk"}
execute if score @s ec.aff_class matches 13 run function evercraft:bough/mastery/add_xp {cls:"kt"}
execute if score @s ec.aff_class matches 14 run function evercraft:bough/mastery/add_xp {cls:"ds"}
