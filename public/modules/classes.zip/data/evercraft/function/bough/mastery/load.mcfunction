# === BOUGH MASTERY — LOAD (Mastery XP → Level → Bough Points) ===
# Joseph 2026-06-14. Replaces the old "material resonance" earning/currency.
# Plan: ~/.claude/plans/tranquil-leaping-cerf.md
#
# The loop: USE a class's item → that class earns Mastery XP (tapped from the
# existing affinity / craft_affinity / weapon_mastery / patina usage signals) →
# crossing a level threshold grants Bough Points → spent in the class's tree
# (the old iron/steel/myth/anci tiers are now LEVEL-GATES, not currencies).
# A slice of every gain banks to a shared pool that drips into the player's
# other classes (cross-training).
#
# Roster (21): bk rg dn sk sn hl bl jv hp ar ht kt tk ds | ss lf gs tw sc lm gw
#
# ONE-WRITER CONTRACT:
#   ec.<cls>_xp  — sole writer bough/mastery/add_xp (tick-chain safe)
#   ec.<cls>_lvl — sole writer bough/mastery/level_check
#   ec.<cls>_pts — event-driven writers only (level_check grants, the spend
#                  chokepoints deduct, reroot refunds) — never same-tick.
#   ec.<cls>_pte — points-earned-lifetime; written beside _pts on level-up +
#                  migration; read by reroot to refund precisely.
#   ec.bough_bank — add_xp adds the slice, spread_tick drains (disjoint phases).
function evercraft:bough/mastery/register

# === TUNABLE CONSTANTS (on ec.const — balance-council adjustable) ===
# XP→level curve: total XP for level L = base * L^2  (base=1000)
scoreboard players set #b_base ec.const 1000
scoreboard players set #b_100 ec.const 100
# Cross-training bank slice % by difficulty (Newcomer/Adventurer/Pioneer)
scoreboard players set #b_rate_new ec.const 15
scoreboard players set #b_rate_adv ec.const 10
scoreboard players set #b_rate_pio ec.const 5
# Shared-bank drip divisor (each drip = bank / div) + min bank to bother dripping
scoreboard players set #b_drip_div ec.const 20
# Static XP rewards
scoreboard players set #b_wm ec.const 500
scoreboard players set #b_patina ec.const 2000
# Tier → level-gate (read by bough/spend; replaces affinity 1/25/50/75 contract)
scoreboard players set #b_gate_iron ec.const 1
scoreboard players set #b_gate_steel ec.const 10
scoreboard players set #b_gate_myth ec.const 25
scoreboard players set #b_gate_anci ec.const 40
scoreboard players set #b_gate_crown ec.const 50
# Toggle C/U nodes: a bought node whose #tog_<cls>_<node> const is 1 flips on right-click
# (calls bough/toggle/<cls>_<node>) instead of the "already owned" nudge in bough/spend.
scoreboard players set #tog_ss_c2 ec.const 1
# War-prep ability nodes (2026-06-22): right-click an OWNED node → bough/abilities/arm.
# Archer: C2 Quickdraw · C5 Explosive Volley · C8 Eagle Eye + all five mastery ultimates.
scoreboard players set #tog_ar_c2 ec.const 1
scoreboard players set #tog_ar_c5 ec.const 1
scoreboard players set #tog_ar_c8 ec.const 1
scoreboard players set #tog_ar_m1 ec.const 1
scoreboard players set #tog_ar_m2 ec.const 1
scoreboard players set #tog_ar_m3 ec.const 1
scoreboard players set #tog_ar_m4 ec.const 1
scoreboard players set #tog_ar_m5 ec.const 1
# War-prep ability nodes per combat class (2026-06-22) — right-click owned node → arm.
# striker
scoreboard players set #tog_sk_c5 ec.const 1
scoreboard players set #tog_sk_c7 ec.const 1
scoreboard players set #tog_sk_c4 ec.const 1
scoreboard players set #tog_sk_m1 ec.const 1
scoreboard players set #tog_sk_m2 ec.const 1
scoreboard players set #tog_sk_m3 ec.const 1
scoreboard players set #tog_sk_m4 ec.const 1
scoreboard players set #tog_sk_m5 ec.const 1
# tank
scoreboard players set #tog_tk_c5 ec.const 1
scoreboard players set #tog_tk_c8 ec.const 1
scoreboard players set #tog_tk_c10 ec.const 1
scoreboard players set #tog_tk_m1 ec.const 1
scoreboard players set #tog_tk_m2 ec.const 1
scoreboard players set #tog_tk_m3 ec.const 1
scoreboard players set #tog_tk_m4 ec.const 1
scoreboard players set #tog_tk_m5 ec.const 1
# javelin
scoreboard players set #tog_jv_c8 ec.const 1
scoreboard players set #tog_jv_c7 ec.const 1
scoreboard players set #tog_jv_c4 ec.const 1
scoreboard players set #tog_jv_m1 ec.const 1
scoreboard players set #tog_jv_m2 ec.const 1
scoreboard players set #tog_jv_m3 ec.const 1
scoreboard players set #tog_jv_m4 ec.const 1
scoreboard players set #tog_jv_m5 ec.const 1
# hunter
scoreboard players set #tog_ht_c10 ec.const 1
scoreboard players set #tog_ht_c5 ec.const 1
scoreboard players set #tog_ht_c8 ec.const 1
scoreboard players set #tog_ht_m1 ec.const 1
scoreboard players set #tog_ht_m2 ec.const 1
scoreboard players set #tog_ht_m3 ec.const 1
scoreboard players set #tog_ht_m4 ec.const 1
scoreboard players set #tog_ht_m5 ec.const 1
# dual_swordsman
scoreboard players set #tog_ds_c12 ec.const 1
scoreboard players set #tog_ds_c6 ec.const 1
scoreboard players set #tog_ds_c7 ec.const 1
scoreboard players set #tog_ds_m1 ec.const 1
scoreboard players set #tog_ds_m2 ec.const 1
scoreboard players set #tog_ds_m3 ec.const 1
scoreboard players set #tog_ds_m4 ec.const 1
scoreboard players set #tog_ds_m5 ec.const 1
# dancer
scoreboard players set #tog_dn_c5 ec.const 1
scoreboard players set #tog_dn_c7 ec.const 1
scoreboard players set #tog_dn_c10 ec.const 1
scoreboard players set #tog_dn_m1 ec.const 1
scoreboard players set #tog_dn_m2 ec.const 1
scoreboard players set #tog_dn_m3 ec.const 1
scoreboard players set #tog_dn_m4 ec.const 1
scoreboard players set #tog_dn_m5 ec.const 1
# rogue
scoreboard players set #tog_rg_c9 ec.const 1
scoreboard players set #tog_rg_c5 ec.const 1
scoreboard players set #tog_rg_c6 ec.const 1
scoreboard players set #tog_rg_m1 ec.const 1
scoreboard players set #tog_rg_m2 ec.const 1
scoreboard players set #tog_rg_m3 ec.const 1
scoreboard players set #tog_rg_m4 ec.const 1
scoreboard players set #tog_rg_m5 ec.const 1
# sentinel
scoreboard players set #tog_sn_c12 ec.const 1
scoreboard players set #tog_sn_c10 ec.const 1
scoreboard players set #tog_sn_c7 ec.const 1
scoreboard players set #tog_sn_m1 ec.const 1
scoreboard players set #tog_sn_m2 ec.const 1
scoreboard players set #tog_sn_m3 ec.const 1
scoreboard players set #tog_sn_m4 ec.const 1
scoreboard players set #tog_sn_m5 ec.const 1
# hoplite
scoreboard players set #tog_hp_c12 ec.const 1
scoreboard players set #tog_hp_c8 ec.const 1
scoreboard players set #tog_hp_c9 ec.const 1
scoreboard players set #tog_hp_m1 ec.const 1
scoreboard players set #tog_hp_m2 ec.const 1
scoreboard players set #tog_hp_m3 ec.const 1
scoreboard players set #tog_hp_m4 ec.const 1
scoreboard players set #tog_hp_m5 ec.const 1
# knight
scoreboard players set #tog_kt_c12 ec.const 1
scoreboard players set #tog_kt_c5 ec.const 1
scoreboard players set #tog_kt_c7 ec.const 1
scoreboard players set #tog_kt_m1 ec.const 1
scoreboard players set #tog_kt_m2 ec.const 1
scoreboard players set #tog_kt_m3 ec.const 1
scoreboard players set #tog_kt_m4 ec.const 1
scoreboard players set #tog_kt_m5 ec.const 1
# beastlord
scoreboard players set #tog_bl_c6 ec.const 1
scoreboard players set #tog_bl_c7 ec.const 1
scoreboard players set #tog_bl_c8 ec.const 1
scoreboard players set #tog_bl_m1 ec.const 1
scoreboard players set #tog_bl_m2 ec.const 1
scoreboard players set #tog_bl_m3 ec.const 1
scoreboard players set #tog_bl_m4 ec.const 1
scoreboard players set #tog_bl_m5 ec.const 1
# healer
scoreboard players set #tog_hl_c9 ec.const 1
scoreboard players set #tog_hl_c11 ec.const 1
scoreboard players set #tog_hl_c10 ec.const 1
scoreboard players set #tog_hl_m1 ec.const 1
scoreboard players set #tog_hl_m2 ec.const 1
scoreboard players set #tog_hl_m3 ec.const 1
scoreboard players set #tog_hl_m4 ec.const 1
scoreboard players set #tog_hl_m5 ec.const 1
# berserker
scoreboard players set #tog_bk_c4 ec.const 1
scoreboard players set #tog_bk_c5 ec.const 1
scoreboard players set #tog_bk_c11 ec.const 1
scoreboard players set #tog_bk_m1 ec.const 1
scoreboard players set #tog_bk_m2 ec.const 1
scoreboard players set #tog_bk_m3 ec.const 1
scoreboard players set #tog_bk_m4 ec.const 1
scoreboard players set #tog_bk_m5 ec.const 1

# Cross-class Crown ultimate (M5) — GLOBAL one-at-a-time track. Armed from any class's M5
# node (bough/abilities/arm_ult), applies while playing ANY class (bough/abilities/ult_tick),
# lasts 5 minutes. One ultimate at a time across all classes.
scoreboard objectives add ec.bough_ult_id dummy "Bough Crown Ultimate Mode"
scoreboard objectives add ec.bough_ult_dur dummy "Bough Crown Ultimate Duration"
scoreboard objectives add ec.bough_ult_cd dummy "Bough Crown Ultimate Cooldown"
schedule function evercraft:bough/abilities/ult_tick 20t

# === CLASS DISPLAY NAMES (for the level-up toast; pulled by notify_levelup) ===
data modify storage evercraft:bough name.bk set value "Berserker"
data modify storage evercraft:bough name.rg set value "Rogue"
data modify storage evercraft:bough name.dn set value "Dancer"
data modify storage evercraft:bough name.sk set value "Striker"
data modify storage evercraft:bough name.sn set value "Sentinel"
data modify storage evercraft:bough name.hl set value "Healer"
data modify storage evercraft:bough name.bl set value "Beastlord"
data modify storage evercraft:bough name.jv set value "Javelin"
data modify storage evercraft:bough name.hp set value "Hoplite"
data modify storage evercraft:bough name.ar set value "Archer"
data modify storage evercraft:bough name.ht set value "Hunter"
data modify storage evercraft:bough name.kt set value "Knight"
data modify storage evercraft:bough name.tk set value "Tank"
data modify storage evercraft:bough name.ds set value "Dual Swordsman"
data modify storage evercraft:bough name.ss set value "Stonestrike"
data modify storage evercraft:bough name.lf set value "Lumberfell"
data modify storage evercraft:bough name.gs set value "Growseer"
data modify storage evercraft:bough name.tw set value "Terrawarp"
data modify storage evercraft:bough name.sc set value "Sirencall"
data modify storage evercraft:bough name.lm set value "Lamentor"
data modify storage evercraft:bough name.gw set value "Gearwright"

# === SHARED STATE ===
scoreboard objectives add ec.bough_bank dummy "Bough Cross-Training Bank"
scoreboard objectives add ec.bough_spread_cur dummy "Bough Spread Cursor"
scoreboard objectives add ec.bough_migrated dummy "Bough Mastery Migrated"

# Cross-training drip — 1s heartbeat (self-reschedules in spread_tick).
schedule function evercraft:bough/mastery/spread_tick 20t replace

# One-shot migration sweep 2s after load — cuts over players who were online at
# the resonance→mastery /reload. Delayed so all #minecraft:load functions (incl.
# affinity/craft_affinity objective registration) have finished first. Joiners
# are migrated by reconnect/dispatch; operator fallback in bough/mastery/migrate.
schedule function evercraft:bough/mastery/migrate_all 40t
