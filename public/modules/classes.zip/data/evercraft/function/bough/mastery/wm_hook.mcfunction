# === BOUGH MASTERY — WEAPON-MASTERY LEVEL-UP HOOK ===
# Called from weapon_mastery/level_up when a MAINHAND weapon really leveled up
# (gated there on #wm_is_mainhand so inventory/armor level-ups don't mis-credit).
# Grants #b_wm Mastery XP per weapon-level gained this event to the active class
# (ec.aff_class, kept current by affinity/detect_class). Run as @s.
scoreboard players operation #bough_amt ec.temp = #wm_level ec.var
scoreboard players operation #bough_amt ec.temp -= #wm_lvl_start ec.var
scoreboard players operation #bough_amt ec.temp *= #b_wm ec.const
execute unless score #bough_amt ec.temp matches 1.. run return 0
scoreboard players set #bough_nobank ec.temp 0
scoreboard players set #bough_silent ec.temp 0
function evercraft:bough/mastery/route_combat
