# === BOUGH MASTERY — MIGRATE ONE CLASS (macro {cls}) ===
# Called by bough/mastery/migrate for each class, run as @s, with the class's
# ec.<cls>_xp already seeded from its old affinity total and #bough_silent=1.
# Derives the level, grants retroactive points (already-bought nodes count as
# paid), and zeroes the deprecated resonance pools.

# Derive level from the seeded XP (silent — no toast storm on a huge seed)
$function evercraft:bough/mastery/level_check {cls:"$(cls)"}

# Points earned lifetime = level
$scoreboard players operation @s ec.$(cls)_pte = @s ec.$(cls)_lvl

# Already-spent = sum of branch counters (owned nodes were "paid for")
$scoreboard players operation #b_spent ec.temp = @s ec.$(cls)_b_combat
$scoreboard players operation #b_spent ec.temp += @s ec.$(cls)_b_util
$scoreboard players operation #b_spent ec.temp += @s ec.$(cls)_b_mast
$scoreboard players operation #b_spent ec.temp += @s ec.$(cls)_b_crown

# Spendable points = level - already-spent, clamped to >= 0
$scoreboard players operation @s ec.$(cls)_pts = @s ec.$(cls)_lvl
$scoreboard players operation @s ec.$(cls)_pts -= #b_spent ec.temp
$execute if score @s ec.$(cls)_pts matches ..-1 run scoreboard players set @s ec.$(cls)_pts 0

# Retire the deprecated resonance pools for this class
$scoreboard players set @s ec.res_iron_$(cls) 0
$scoreboard players set @s ec.res_steel_$(cls) 0
$scoreboard players set @s ec.res_myth_$(cls) 0
$scoreboard players set @s ec.res_anci_$(cls) 0
