# === BOUGH MASTERY — CROSS-TRAINING BANK SLICE ===
# Banks a difficulty-scaled % of the just-earned XP (#bough_amt) into the shared
# ec.bough_bank pool, which spread_tick later drips into the player's other
# classes. Run as @s. Rate: Newcomer 15% / Adventurer 10% / Pioneer 5%
# (ec.difficulty 1 / 2 / 3-or-unset). NOTE: #bough_amt is ALREADY difficulty-
# scaled upstream at the affinity chokepoint — here difficulty only picks the %,
# it does NOT re-scale the XP.

# Default to Pioneer rate (covers difficulty 3 / 0 / unset)
scoreboard players operation #b_slice ec.temp = #bough_amt ec.temp
scoreboard players operation #b_slice ec.temp *= #b_rate_pio ec.const
execute if score @s ec.difficulty matches 1 run scoreboard players operation #b_slice ec.temp = #bough_amt ec.temp
execute if score @s ec.difficulty matches 1 run scoreboard players operation #b_slice ec.temp *= #b_rate_new ec.const
execute if score @s ec.difficulty matches 2 run scoreboard players operation #b_slice ec.temp = #bough_amt ec.temp
execute if score @s ec.difficulty matches 2 run scoreboard players operation #b_slice ec.temp *= #b_rate_adv ec.const
scoreboard players operation #b_slice ec.temp /= #b_100 ec.const

scoreboard players operation @s ec.bough_bank += #b_slice ec.temp
