# === BOUGH MASTERY — MAINHAND PATINA STAGE-UP → CLASS XP ===
# Called from patina/upgrade when a MAINHAND artifact advances a patina stage
# (worn→seasoned→…). A tool that grows storied with use is a tool mastered —
# grant the active class a chunk of Mastery XP. Run as @s. Routes by ec.aff_class
# (no match for a non-class mainhand → no XP, which is correct).
scoreboard players operation #bough_amt ec.temp = #b_patina ec.const
scoreboard players set #bough_nobank ec.temp 0
scoreboard players set #bough_silent ec.temp 0
function evercraft:bough/mastery/route_combat
