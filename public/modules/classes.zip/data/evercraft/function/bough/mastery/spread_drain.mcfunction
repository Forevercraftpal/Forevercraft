# === BOUGH MASTERY — DRAIN ONE DRIP (run as @s) ===
# Moves a slice of the shared bank into the cursor-selected class. Drip XP does
# NOT re-bank (#bough_nobank=1 → no feedback loop) and is silent (alts level up
# quietly; the player finds out in the codex). Cursor order matches the 21-roster.

# Advance + wrap the rotating cursor (0..20)
scoreboard players add @s ec.bough_spread_cur 1
execute if score @s ec.bough_spread_cur matches 21.. run scoreboard players set @s ec.bough_spread_cur 0

# Drip = bank / div (>=1, since the bank floor is 20 and div is 20)
scoreboard players operation #b_drip ec.temp = @s ec.bough_bank
scoreboard players operation #b_drip ec.temp /= #b_drip_div ec.const
execute unless score #b_drip ec.temp matches 1.. run scoreboard players set #b_drip ec.temp 1
scoreboard players operation @s ec.bough_bank -= #b_drip ec.temp

# Hand the drip to add_xp for the selected class
scoreboard players operation #bough_amt ec.temp = #b_drip ec.temp
scoreboard players set #bough_nobank ec.temp 1
scoreboard players set #bough_silent ec.temp 1
execute if score @s ec.bough_spread_cur matches 0 run function evercraft:bough/mastery/add_xp {cls:"bk"}
execute if score @s ec.bough_spread_cur matches 1 run function evercraft:bough/mastery/add_xp {cls:"rg"}
execute if score @s ec.bough_spread_cur matches 2 run function evercraft:bough/mastery/add_xp {cls:"dn"}
execute if score @s ec.bough_spread_cur matches 3 run function evercraft:bough/mastery/add_xp {cls:"sk"}
execute if score @s ec.bough_spread_cur matches 4 run function evercraft:bough/mastery/add_xp {cls:"sn"}
execute if score @s ec.bough_spread_cur matches 5 run function evercraft:bough/mastery/add_xp {cls:"hl"}
execute if score @s ec.bough_spread_cur matches 6 run function evercraft:bough/mastery/add_xp {cls:"bl"}
execute if score @s ec.bough_spread_cur matches 7 run function evercraft:bough/mastery/add_xp {cls:"jv"}
execute if score @s ec.bough_spread_cur matches 8 run function evercraft:bough/mastery/add_xp {cls:"hp"}
execute if score @s ec.bough_spread_cur matches 9 run function evercraft:bough/mastery/add_xp {cls:"ar"}
execute if score @s ec.bough_spread_cur matches 10 run function evercraft:bough/mastery/add_xp {cls:"ht"}
execute if score @s ec.bough_spread_cur matches 11 run function evercraft:bough/mastery/add_xp {cls:"kt"}
execute if score @s ec.bough_spread_cur matches 12 run function evercraft:bough/mastery/add_xp {cls:"tk"}
execute if score @s ec.bough_spread_cur matches 13 run function evercraft:bough/mastery/add_xp {cls:"ds"}
execute if score @s ec.bough_spread_cur matches 14 run function evercraft:bough/mastery/add_xp {cls:"ss"}
execute if score @s ec.bough_spread_cur matches 15 run function evercraft:bough/mastery/add_xp {cls:"lf"}
execute if score @s ec.bough_spread_cur matches 16 run function evercraft:bough/mastery/add_xp {cls:"gs"}
execute if score @s ec.bough_spread_cur matches 17 run function evercraft:bough/mastery/add_xp {cls:"tw"}
execute if score @s ec.bough_spread_cur matches 18 run function evercraft:bough/mastery/add_xp {cls:"sc"}
execute if score @s ec.bough_spread_cur matches 19 run function evercraft:bough/mastery/add_xp {cls:"lm"}
execute if score @s ec.bough_spread_cur matches 20 run function evercraft:bough/mastery/add_xp {cls:"gw"}
