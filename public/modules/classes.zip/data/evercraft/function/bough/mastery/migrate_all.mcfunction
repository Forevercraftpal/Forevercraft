# === BOUGH MASTERY — POST-LOAD MIGRATION SWEEP (one-shot) ===
# Scheduled 40t after bough/mastery/load. Migrates any online player not yet
# cut over — covers players who were online at the cutover /reload (joiners are
# handled by reconnect/dispatch). Runs after all #minecraft:load functions have
# completed, so the affinity/craft_affinity source objectives are guaranteed to
# exist. Idempotent (each migrate is guarded by ec.bough_migrated).
execute as @a unless score @s ec.bough_migrated matches 1 run function evercraft:bough/mastery/migrate
