# === BOUGH MASTERY — ONE-TIME MIGRATION (per player) ===
# one-time migration — Run as: /execute as @a run function evercraft:bough/mastery/migrate
# Cuts a player over from the old resonance economy to Mastery XP. Idempotent
# (guarded by ec.bough_migrated). Auto-runs from bough/mastery/load (catches
# players online at the cutover /reload) and reconnect/dispatch (later joiners);
# the operator command above is the manual belt-and-suspenders.
#
# Seeds each class's Mastery XP from its accumulated affinity so veterans keep
# progress, derives levels, grants retroactive points (already-bought nodes are
# treated as paid), and zeroes the deprecated ec.res_* pools.

execute if score @s ec.bough_migrated matches 1 run return 0
scoreboard players set @s ec.bough_migrated 1

# 1. Seed Mastery XP from old affinity totals (combat classes)
scoreboard players operation @s ec.bk_xp = @s ec.aff_bk
scoreboard players operation @s ec.rg_xp = @s ec.aff_rg
scoreboard players operation @s ec.dn_xp = @s ec.aff_dn
scoreboard players operation @s ec.sk_xp = @s ec.aff_sk
# Sentinel is the mace's shield-mode — share the mace (Striker) history as a seed
scoreboard players operation @s ec.sn_xp = @s ec.aff_sk
scoreboard players operation @s ec.kt_xp = @s ec.aff_kt
scoreboard players operation @s ec.hl_xp = @s ec.aff_hl
scoreboard players operation @s ec.bl_xp = @s ec.aff_bl
scoreboard players operation @s ec.jv_xp = @s ec.aff_jv
scoreboard players operation @s ec.hp_xp = @s ec.aff_hp
scoreboard players operation @s ec.ar_xp = @s ec.aff_ar
scoreboard players operation @s ec.ht_xp = @s ec.aff_ht
scoreboard players operation @s ec.tk_xp = @s ec.aff_tk
scoreboard players operation @s ec.ds_xp = @s ec.aff_ds
# Crafting classes
scoreboard players operation @s ec.ss_xp = @s ec.caff_ss
scoreboard players operation @s ec.lf_xp = @s ec.caff_lf
scoreboard players operation @s ec.gs_xp = @s ec.caff_gs
scoreboard players operation @s ec.tw_xp = @s ec.caff_tw
scoreboard players operation @s ec.sc_xp = @s ec.caff_sc
scoreboard players operation @s ec.lm_xp = @s ec.caff_lm
scoreboard players operation @s ec.gw_xp = @s ec.caff_gw

# 2+3. Derive levels (silent) + retroactive points + zero deprecated resonance
scoreboard players set #bough_silent ec.temp 1
function evercraft:bough/mastery/migrate_finalize {cls:"bk"}
function evercraft:bough/mastery/migrate_finalize {cls:"rg"}
function evercraft:bough/mastery/migrate_finalize {cls:"dn"}
function evercraft:bough/mastery/migrate_finalize {cls:"sk"}
function evercraft:bough/mastery/migrate_finalize {cls:"sn"}
function evercraft:bough/mastery/migrate_finalize {cls:"hl"}
function evercraft:bough/mastery/migrate_finalize {cls:"bl"}
function evercraft:bough/mastery/migrate_finalize {cls:"jv"}
function evercraft:bough/mastery/migrate_finalize {cls:"hp"}
function evercraft:bough/mastery/migrate_finalize {cls:"ar"}
function evercraft:bough/mastery/migrate_finalize {cls:"ht"}
function evercraft:bough/mastery/migrate_finalize {cls:"kt"}
function evercraft:bough/mastery/migrate_finalize {cls:"tk"}
function evercraft:bough/mastery/migrate_finalize {cls:"ds"}
function evercraft:bough/mastery/migrate_finalize {cls:"ss"}
function evercraft:bough/mastery/migrate_finalize {cls:"lf"}
function evercraft:bough/mastery/migrate_finalize {cls:"gs"}
function evercraft:bough/mastery/migrate_finalize {cls:"tw"}
function evercraft:bough/mastery/migrate_finalize {cls:"sc"}
function evercraft:bough/mastery/migrate_finalize {cls:"lm"}
function evercraft:bough/mastery/migrate_finalize {cls:"gw"}
