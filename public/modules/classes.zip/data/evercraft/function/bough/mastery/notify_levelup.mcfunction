# === BOUGH MASTERY — LEVEL-UP TOAST (macro {cls}) ===
# Run as @s on each level gained (unless suppressed). Pulls the class display
# name from storage evercraft:bough name.<cls> and shows the new level.
# FX gated on ec.fx_snd per the pack's sound convention (note-block palette).

$tellraw @s [{text:"✦ ",color:"gold",bold:true},{nbt:"name.$(cls)",storage:"evercraft:bough",color:"gold",bold:true},{text:" Mastery — ",color:"gray"},{text:"Level ",color:"yellow"},{score:{name:"@s",objective:"ec.$(cls)_lvl"},color:"yellow",bold:true}]
execute if score @s ec.fx_snd matches 1.. at @s run playsound minecraft:block.note_block.chime master @s ~ ~ ~ 0.6 1.6
execute if score @s ec.fx_snd matches 1.. at @s run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.4 1.8
