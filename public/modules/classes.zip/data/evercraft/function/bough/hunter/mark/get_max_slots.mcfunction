# === BOUGH HUNTER — MARK OF DEATH · MAX SLOTS (Wave 20) ===
# @s = hunter. Writes #ht_mk_max ec.var = simultaneous marks this hunter may
# hold: 1 base · +1 with M5 Crown's Mark ("Mark of Death allows 2 simultaneous
# marks instead of 1") · +1 with ec.ht_pln_walk (pollen_tw_walk, Terrawarp U11
# Trail Pact — the +1 mark slot, read LIVE per the pollen contract).
scoreboard players set #ht_mk_max ec.var 1
execute if score @s ec.ht_n_m5 matches 1.. run scoreboard players add #ht_mk_max ec.var 1
execute if score @s ec.ht_pln_walk matches 1.. run scoreboard players add #ht_mk_max ec.var 1
