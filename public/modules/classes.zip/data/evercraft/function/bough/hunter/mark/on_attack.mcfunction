# === BOUGH HUNTER — MARK OF DEATH · ON-ATTACK ROUTER (Wave 20) ===
# Called from evercraft:advantage/track/on_attack (the pack's generic
# player_hurt_entity dispatcher) for EVERY landed player hit. @s = attacker,
# at @s. Two branches, both self-gating:
#
#   HIT — the just-hit entity carries ec.ht_marked → bonus damage + duration
#         refresh + same-tick death resolve. Gated on #ht_marks ec.var
#         (recounted each 1s by bough/hunter/crown_tick, set >=1 at apply) so
#         the global @e scan never runs while no marks exist anywhere.
#   APPLY — attacker is a sneaking active Hunter (ec.ht_active = hunter
#         crossbow in mainhand; sneaking = the class's Steady Aim posture) →
#         the hit SETS a mark instead of riding one. Runs second so the
#         mark-setting hit never also collects the marked-hit bonus.
#
# Recursion safety: all rider damage downstream is UNATTRIBUTED
# evercraft:bonus_strike (no `by`), so it cannot re-fire player_hurt_entity.
# Nested artifact-AoE rewards (ec.aff_attacker up) are allowed through — the
# Crown's amp applies to every player-attributed source by design.

# --- HIT branch: locate a just-hit marked victim (HurtTime:10s = damaged this tick) ---
execute if score #ht_marks ec.var matches 1.. as @e[tag=ec.ht_marked,nbt={HurtTime:10s},distance=..100,sort=nearest,limit=1] run tag @s add ec.ht_mk_victim
execute if entity @e[tag=ec.ht_mk_victim,limit=1] run function evercraft:bough/hunter/mark/on_hit_marked

# --- APPLY branch: sneaking active Hunter sets a mark with this hit ---
execute if entity @s[tag=ec.ht_active,predicate=evercraft:is_sneaking] run function evercraft:bough/hunter/mark/apply
