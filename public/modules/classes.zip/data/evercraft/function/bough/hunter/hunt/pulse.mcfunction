# === BOUGH HUNTER — HUNT PULSE ===
# @s = a Hunter (ec.ht_active) with >=1 combat point, at @s. Solo tracker value: reveal/harry
# foes + self pursuit buffs + capstone. The mark synergy (C7/C11) lives in the mark system.
# Radius 6/8; marked-foe slowing reaches 24.
# --- FOE DEBUFFS (C3 Marked Target Glowing · C5 Predator's Strike Mining Fatigue · C10 Storm Bolt Weakness · C9 marked Slowness) ---
execute if score @s ec.ht_n_c3 matches 1.. run effect give @e[type=#evercraft:hostile_mobs,distance=..6] minecraft:glowing 2 0 true
execute if score @s ec.ht_n_c5 matches 1.. run effect give @e[type=#evercraft:hostile_mobs,distance=..6] minecraft:mining_fatigue 2 0 true
execute if score @s ec.ht_n_c10 matches 1.. run effect give @e[type=#evercraft:hostile_mobs,distance=..6] minecraft:weakness 2 0 true
execute if score @s ec.ht_n_c9 matches 1.. run effect give @e[tag=ec.ht_marked,distance=..24] minecraft:slowness 2 0 true
tag @s add ht.hunt_src
execute if score @s ec.ht_n_c6 matches 1.. as @e[type=#evercraft:hostile_mobs,distance=..6] run damage @s 1 minecraft:magic by @e[tag=ht.hunt_src,limit=1,sort=nearest]
tag @s remove ht.hunt_src

# --- SELF (C1 Tracker's Aim Speed · C4 Full Quiver Regen · C8 Steady Stalker Strength while sneaking) ---
execute if score @s ec.ht_n_c1 matches 1.. if entity @e[type=#evercraft:hostile_mobs,distance=..8] run effect give @s minecraft:speed 2 0 true
execute if score @s ec.ht_n_c4 matches 1.. if entity @e[type=#evercraft:hostile_mobs,distance=..8] run effect give @s minecraft:regeneration 2 0 true
execute if score @s ec.ht_n_c8 matches 1.. if entity @s[predicate=evercraft:is_sneaking] run effect give @s minecraft:strength 2 0 true

# --- HEADHUNTER capstone (C12): every 30s near a foe, the hunt closes ---
execute if score @s ec.ht_n_c12 matches 1.. if score @s ec.ht_hunt_cd matches ..0 if entity @e[type=#evercraft:hostile_mobs,distance=..8] run function evercraft:bough/hunter/hunt/headhunter
