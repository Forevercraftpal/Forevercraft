# === BOUGH HUNTER — UTILITY PERK TICK (1s) ===
# Utility scoping (2026-06-22): U1/U6/U12 (non-pollen) are ACCOUNT-WIDE (multiclass reward);
# every other utility node applies ONLY while this class is active. Pollen nodes also carry an
# active-gated SOLO buff (their multiplayer synergy stays in bough/pollen/<pfx>). Gate: any hunter progress
# (ec.ht_lvl>=1). Theme = tracker (mobility + a tracker's luck). Attribute perks: remove-for-all
# then add-for-owners. Pollen U2/U5/U8, the working U12 Bloodthread, and U3 Bestiary are
# untouched.
execute unless entity @a[scores={ec.ht_lvl=1..}] run return run schedule function evercraft:bough/hunter/perks/tick 20t

# --- MOVEMENT (U6 Predator's Walk · U7 Lithe Step · U10 Wind-Walker = +5% each) ---
execute as @a[scores={ec.ht_lvl=1..}] run attribute @s minecraft:movement_speed modifier remove evercraft:ht_perk_u6
execute as @a[scores={ec.ht_n_u6=1..}] run attribute @s minecraft:movement_speed modifier add evercraft:ht_perk_u6 0.05 add_multiplied_base
execute as @a[scores={ec.ht_lvl=1..}] run attribute @s minecraft:movement_speed modifier remove evercraft:ht_perk_u7
execute as @a[tag=ec.ht_active,scores={ec.ht_n_u7=1..}] run attribute @s minecraft:movement_speed modifier add evercraft:ht_perk_u7 0.05 add_multiplied_base
execute as @a[scores={ec.ht_lvl=1..}] run attribute @s minecraft:movement_speed modifier remove evercraft:ht_perk_u10
execute as @a[tag=ec.ht_active,scores={ec.ht_n_u10=1..}] run attribute @s minecraft:movement_speed modifier add evercraft:ht_perk_u10 0.05 add_multiplied_base

# --- GATHER (U1 Forager's Hunt = Luck I) ---
execute as @a[scores={ec.ht_n_u1=1..}] run effect give @s minecraft:luck 2 0 true

# --- KNOCKBACK RESISTANCE (U11 Pathfinder +0.2) ---
execute as @a[scores={ec.ht_lvl=1..}] run attribute @s minecraft:knockback_resistance modifier remove evercraft:ht_perk_u11
execute as @a[tag=ec.ht_active,scores={ec.ht_n_u11=1..}] run attribute @s minecraft:knockback_resistance modifier add evercraft:ht_perk_u11 0.2 add_value

# --- HEALTH (U4 Hardy · U9 Survivor = +1 heart each) ---
execute as @a[scores={ec.ht_lvl=1..}] run attribute @s minecraft:max_health modifier remove evercraft:ht_perk_u4
execute as @a[tag=ec.ht_active,scores={ec.ht_n_u4=1..}] run attribute @s minecraft:max_health modifier add evercraft:ht_perk_u4 2 add_value
execute as @a[scores={ec.ht_lvl=1..}] run attribute @s minecraft:max_health modifier remove evercraft:ht_perk_u9
execute as @a[tag=ec.ht_active,scores={ec.ht_n_u9=1..}] run attribute @s minecraft:max_health modifier add evercraft:ht_perk_u9 2 add_value


# === POLLEN SOLO BUFFS (active-gated) — multiplayer synergy stays in bough/pollen/ht ===
execute as @a[scores={ec.ht_lvl=1..}] run attribute @s minecraft:movement_speed modifier remove evercraft:ht_pln_u2
execute as @a[tag=ec.ht_active,scores={ec.ht_n_u2=1..}] run attribute @s minecraft:movement_speed modifier add evercraft:ht_pln_u2 0.05 add_multiplied_base
execute as @a[scores={ec.ht_lvl=1..}] run attribute @s minecraft:attack_damage modifier remove evercraft:ht_pln_u5
execute as @a[tag=ec.ht_active,scores={ec.ht_n_u5=1..}] run attribute @s minecraft:attack_damage modifier add evercraft:ht_pln_u5 1 add_value
execute as @a[scores={ec.ht_lvl=1..}] run attribute @s minecraft:attack_speed modifier remove evercraft:ht_pln_u8
execute as @a[tag=ec.ht_active,scores={ec.ht_n_u8=1..}] run attribute @s minecraft:attack_speed modifier add evercraft:ht_pln_u8 0.08 add_multiplied_base

# === MILESTONE PASSIVES (lvl 1/6/12, account-wide, tracker-thematic) ===
# Lvl 1 Keen — +5% movement speed.
execute as @a[scores={ec.ht_lvl=1..}] run attribute @s minecraft:movement_speed modifier remove evercraft:ht_ms1
execute as @a[scores={ec.ht_lvl=1..}] run attribute @s minecraft:movement_speed modifier add evercraft:ht_ms1 0.05 add_multiplied_base
# Lvl 6 Tracker — +1 heart.
execute as @a[scores={ec.ht_lvl=6..}] run attribute @s minecraft:max_health modifier remove evercraft:ht_ms6
execute as @a[scores={ec.ht_lvl=6..}] run attribute @s minecraft:max_health modifier add evercraft:ht_ms6 2 add_value
# Lvl 12 Apex Hunter — +1 heart + Luck I.
execute as @a[scores={ec.ht_lvl=12..}] run attribute @s minecraft:max_health modifier remove evercraft:ht_ms12
execute as @a[scores={ec.ht_lvl=12..}] run attribute @s minecraft:max_health modifier add evercraft:ht_ms12 2 add_value
execute as @a[scores={ec.ht_lvl=12..}] unless score @s ec.ht_n_u1 matches 1.. run effect give @s minecraft:luck 2 0 true

# Milestone unlock chat (one-time each)
execute as @a[scores={ec.ht_lvl=1..}] unless score @s ec.ht_msn1 matches 1 run tellraw @s [{text:"✦ Hunter Mastery 1 — ",color:"gray"},{text:"Keen",color:"white",bold:true},{text:" unlocked. +movement speed. Permanent, all classes.",color:"gray"}]
scoreboard players set @a[scores={ec.ht_lvl=1..}] ec.ht_msn1 1
execute as @a[scores={ec.ht_lvl=6..}] unless score @s ec.ht_msn6 matches 1 run tellraw @s [{text:"✦ Hunter Mastery 6 — ",color:"gray"},{text:"Tracker",color:"white",bold:true},{text:" unlocked. +1 heart. Permanent, all classes.",color:"gray"}]
scoreboard players set @a[scores={ec.ht_lvl=6..}] ec.ht_msn6 1
execute as @a[scores={ec.ht_lvl=12..}] unless score @s ec.ht_msn12 matches 1 run tellraw @s [{text:"✦ Hunter Mastery 12 — ",color:"gray"},{text:"Apex Hunter",color:"white",bold:true},{text:" unlocked. +1 heart and Luck. Permanent, all classes.",color:"gray"}]
scoreboard players set @a[scores={ec.ht_lvl=12..}] ec.ht_msn12 1

schedule function evercraft:bough/hunter/perks/tick 20t
