# === BOUGH HUNTER — M2 FIELD DRESSING (Wave 37, kill adv reward) ===
# Pivot: spec's "refund heart cost + double drops on marked kill" needed mark-
# state read + loot-table mutation per kill. Player-side replacement: each
# kill heals 2 HP (instant_health amp 0 = 4 HP, but the lore-facing "1 heart"
# stays). The field hand knows the muscle.
advancement revoke @s only evercraft:bough/ht_m2_kill
execute unless score @s ec.ht_n_m2 matches 1.. run return 0
effect give @s minecraft:instant_health 1 0 true
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.chime master @s ~ ~ ~ 0.4 1.2
