# === BOUGH HUNTER — MARK OF DEATH · ON HIT MARKED (Wave 20) ===
# @s = attacker (any player), at @s. Victim = the marked entity tagged
# ec.ht_mk_victim by the on_attack router. Resolves the attacker against the
# mark's owner and rides the hit:
#
#   OWNER hit  — duration refreshed to 60s (an actively hunted mark never
#     expires). With the Crown (ec.ht_mark_self, RETUNE 1): +6 bonus_strike —
#     the 2× amp in the pack's additive-rider form (calibrated to the typical
#     ~6-damage hit, the party marked_damage precedent; /damage cannot read
#     the landed amount, so the doubling is flat-equivalent, documented).
#     ec.ht_pln_dmg (pollen_bk_bleed, Berserker U3 Bloodroot) adds +1 more —
#     the +5% rounded up to damage resolution, the pack's rounding idiom.
#   ALLY hit   — any OTHER player striking the mark while the owner holds the
#     Crown party-share flag (ec.ht_mark_allybuff): +2 bonus_strike (+25% of
#     the typical hit — the exact party/combos/marked_damage calibration).
#
# All rider damage is UNATTRIBUTED evercraft:bonus_strike (bypasses the hurt
# cooldown so it lands the same tick, no knockback, cannot re-fire
# player_hurt_entity → no dispatcher recursion).

# --- resolve mark owner vs attacker (sentinels guard unset scores) ---
scoreboard players set #ht_mk_own ec.var -1
scoreboard players operation #ht_mk_own ec.var = @e[tag=ec.ht_mk_victim,limit=1] ec.ht_mark_owner
scoreboard players set #ht_mk_me ec.var -2
scoreboard players operation #ht_mk_me ec.var = @s ec.ht_mark_id

# --- OWNER branch: refresh + Crown amp (+ bleed rider) ---
execute if score #ht_mk_me ec.var = #ht_mk_own ec.var run scoreboard players set @e[tag=ec.ht_mk_victim,limit=1] ec.ht_mark_dur 1200
execute if score #ht_mk_me ec.var = #ht_mk_own ec.var if score @s ec.ht_mark_self matches 1.. run damage @e[tag=ec.ht_mk_victim,limit=1] 6 evercraft:bonus_strike
execute if score #ht_mk_me ec.var = #ht_mk_own ec.var if score @s ec.ht_mark_self matches 1.. if score @s ec.ht_pln_dmg matches 1.. run damage @e[tag=ec.ht_mk_victim,limit=1] 1 evercraft:bonus_strike
# C7 Marked Hunt (combat node): +20% to your marks (~+2 in the additive-rider form), with or
# without the Crown. Same unattributed bonus_strike → no recursion.
execute if score #ht_mk_me ec.var = #ht_mk_own ec.var if score @s ec.ht_n_c7 matches 1.. run damage @e[tag=ec.ht_mk_victim,limit=1] 2 evercraft:bonus_strike
execute if score #ht_mk_me ec.var = #ht_mk_own ec.var if score @s ec.ht_mark_self matches 1.. if score @s ec.fx_vis matches 1.. at @e[tag=ec.ht_mk_victim,limit=1] run particle minecraft:crit ~ ~1 ~ 0.4 0.5 0.4 0.3 8

# --- ALLY branch: owner elsewhere holds the party-share flag ---
scoreboard players set #ht_mk_ally ec.var 0
execute unless score #ht_mk_me ec.var = #ht_mk_own ec.var as @a[scores={ec.ht_mark_id=1..}] if score @s ec.ht_mark_id = #ht_mk_own ec.var if score @s ec.ht_mark_allybuff matches 1.. run scoreboard players set #ht_mk_ally ec.var 1
execute if score #ht_mk_ally ec.var matches 1 run damage @e[tag=ec.ht_mk_victim,limit=1] 2 evercraft:bonus_strike
execute if score #ht_mk_ally ec.var matches 1 if score @s ec.fx_vis matches 1.. at @e[tag=ec.ht_mk_victim,limit=1] run particle minecraft:crit ~ ~1 ~ 0.3 0.4 0.3 0.2 5

# --- same-tick death resolve (the riders above may have been lethal) ---
execute as @e[tag=ec.ht_mk_victim] if data entity @s {Health:0.0f} at @s run function evercraft:bough/hunter/mark/on_death

# --- cleanup ---
tag @e[tag=ec.ht_mk_victim] remove ec.ht_mk_victim
