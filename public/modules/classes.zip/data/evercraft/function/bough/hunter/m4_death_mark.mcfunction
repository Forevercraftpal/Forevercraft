# === BOUGH HUNTER — M4 DEATH MARK (Wave 37, mastery_tick branch) ===
# Pivot: spec's "lethal-hit auto-mark killer + revive" needed pre-damage hook
# + respawn manipulation that don't exist. Replacement: below 30% HP →
# Resistance II + Speed I for 5s, 60s cd. The death mark steadies the hunt.
effect give @s minecraft:resistance 5 1 true
effect give @s minecraft:speed 5 0 true
title @s actionbar [{text:"☠ Death Mark ",color:"aqua",bold:true},{text:"— the hunt steadies",color:"gray",italic:true}]
execute as @a[distance=..16] if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.skeleton.hurt master @s ~ ~ ~ 0.4 0.9
scoreboard players set @s ec.ht_m4_cd 60
