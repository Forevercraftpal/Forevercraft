# === BOUGH HUNTER — MARK OF DEATH · APPLY (Wave 20) ===
# @s = sneaking active Hunter (caller gates: ec.ht_active + is_sneaking), at @s.
# The hit that just landed SETS a mark on its victim. Victim = the hostile mob
# damaged this tick (HurtTime:10s idiom), unmarked, within mark reach:
#   base 32 blocks · 33 with ec.ht_pln_mark (pollen_ar_eye, Archer U6 Hawk
#   Bond — the +1 reach block, wired as a score-gated selector pair).
# A target already marked (by anyone) cannot be re-marked or stolen; the
# owner's own hits refresh duration in on_hit_marked instead.

# --- locate the victim (score-gated reach pair) ---
execute unless score @s ec.ht_pln_mark matches 1.. as @e[type=#evercraft:hostile_mobs,tag=!ec.ht_marked,nbt={HurtTime:10s},distance=..32,sort=nearest,limit=1] run tag @s add ec.ht_mk_newmark
execute if score @s ec.ht_pln_mark matches 1.. as @e[type=#evercraft:hostile_mobs,tag=!ec.ht_marked,nbt={HurtTime:10s},distance=..33,sort=nearest,limit=1] run tag @s add ec.ht_mk_newmark
execute unless entity @e[tag=ec.ht_mk_newmark,limit=1] run return 0

# --- Crown toll gate: "Marking costs 1 heart" (ec.ht_mark_cost, crown-only).
# Below 1.5 hearts the toll would be lethal — the hunt refuses the hand too
# weak to pay it (no free marks at the bottom of the bar).
execute if score @s ec.ht_mark_cost matches 1.. unless entity @s[predicate=evercraft:bough/ht_mark_toll_ok] run tag @e[tag=ec.ht_mk_newmark] remove ec.ht_mk_newmark
execute unless entity @e[tag=ec.ht_mk_newmark,limit=1] if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 0.4 0.5
execute unless entity @e[tag=ec.ht_mk_newmark,limit=1] run return 0

# --- slot check: active marks I own vs max slots ---
function evercraft:bough/hunter/mark/get_max_slots
scoreboard players set #ht_mk_cnt ec.var 0
scoreboard players set #ht_mk_id ec.var -1
scoreboard players operation #ht_mk_id ec.var = @s ec.ht_mark_id
execute as @e[tag=ec.ht_marked] if score @s ec.ht_mark_owner = #ht_mk_id ec.var run scoreboard players add #ht_mk_cnt ec.var 1
execute if score #ht_mk_cnt ec.var >= #ht_mk_max ec.var run tag @e[tag=ec.ht_mk_newmark] remove ec.ht_mk_newmark
execute unless entity @e[tag=ec.ht_mk_newmark,limit=1] if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 0.4 0.5
execute unless entity @e[tag=ec.ht_mk_newmark,limit=1] run return 0

# --- lazily assign my unique mark id (global counter = fake player #ht_mark_next
# on the SAME objective — no extra objective, ≤16-char house convention kept) ---
execute unless score @s ec.ht_mark_id matches 1.. run scoreboard players add #ht_mark_next ec.ht_mark_id 1
execute unless score @s ec.ht_mark_id matches 1.. run scoreboard players operation @s ec.ht_mark_id = #ht_mark_next ec.ht_mark_id

# --- stamp the mark on the victim ---
scoreboard players operation @e[tag=ec.ht_mk_newmark,limit=1] ec.ht_mark_owner = @s ec.ht_mark_id
scoreboard players set @e[tag=ec.ht_mk_newmark,limit=1] ec.ht_mark_dur 1200
tag @e[tag=ec.ht_mk_newmark,limit=1] add ec.ht_marked
# arm the on_attack HIT-branch gate immediately (crown_tick recounts each 1s)
scoreboard players set #ht_marks ec.var 1

# --- pay the Crown toll (1 heart; unattributed bonus_strike = no recursion,
# no knockback; survivability guaranteed by the toll gate above) ---
execute if score @s ec.ht_mark_cost matches 1.. run damage @s 2 evercraft:bonus_strike

# --- the quarry is read: immediate glow blip (mark/tick sustains it in range) ---
effect give @e[tag=ec.ht_mk_newmark,limit=1] minecraft:glowing 2 0 true

# --- FX: the low hunting-horn reads the mark (musical note-block identity) ---
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.didgeridoo master @s ~ ~ ~ 0.7 0.561
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 0.4 0.749
execute if score @s ec.fx_vis matches 1.. at @e[tag=ec.ht_mk_newmark,limit=1] run particle dust{color:[0.85,0.2,0.15],scale:1.1} ~ ~1.2 ~ 0.3 0.4 0.3 0 8
execute if score @s ec.fx_vis matches 2.. at @e[tag=ec.ht_mk_newmark,limit=1] run particle minecraft:crit ~ ~1 ~ 0.3 0.4 0.3 0.2 6

tag @e[tag=ec.ht_mk_newmark] remove ec.ht_mk_newmark
