# === BOUGH HUNTER — LOAD ===
scoreboard objectives add ec.ht_b_combat dummy "Bough HT Combat Points"
scoreboard objectives add ec.ht_b_util dummy "Bough HT Utility Points"
scoreboard objectives add ec.ht_b_mast dummy "Bough HT Mastery Points"
scoreboard objectives add ec.ht_b_crown dummy "Bough HT Crown Owned"
scoreboard objectives add ec.ht_bough_view dummy "Bough HT Codex View"
scoreboard objectives add ec.ht_lx dummy "Bough HT Last X"
scoreboard objectives add ec.ht_lz dummy "Bough HT Last Z"
scoreboard objectives add ec.ht_lyaw dummy "Bough HT Last Yaw"
scoreboard objectives add ec.ht_mark_self dummy "Bough HT Mark 2x Self"
scoreboard objectives add ec.ht_mark_allybuff dummy "Bough HT Mark Ally +25%"
scoreboard objectives add ec.ht_mark_cost dummy "Bough HT Mark Cost"
# === Wave 20: Mark of Death mechanic state (the mark-event hook is LIVE) ===
# Per-target mark state lives ON the marked entity (tag ec.ht_marked):
#   ec.ht_mark_owner = the marking hunter's id · ec.ht_mark_dur = ticks left
#   (1200 = 60s; burned 20/s in mark/tick, refreshed by the owner's hits).
# Hunters get a lazily-assigned unique ec.ht_mark_id; the global counter is
# the fake player #ht_mark_next ON THE SAME objective (no 17-char counter
# objective — ≤16-char house convention). Hook seam: advantage/track/on_attack
# → bough/hunter/mark/on_attack.
scoreboard objectives add ec.ht_mark_id dummy "Bough HT Mark Owner Id"
scoreboard objectives add ec.ht_mark_owner dummy "Bough HT Marked-By Id"
scoreboard objectives add ec.ht_mark_dur dummy "Bough HT Mark Duration"
# Wave 15 pollen consumer, LIVE since Wave 20: +1 Mark of Death reach block
# while ec.pollen_ar_eye is owned (derived by bough/pollen_tick, single
# writer). Read at bough/hunter/mark/apply (32→33 victim-locate ring).
scoreboard objectives add ec.ht_pln_mark dummy "Bough HT Pollen Mark Radius"
# Wave 16 pollen consumers, LIVE since Wave 20: +5% marked-target damage
# (ec.pollen_bk_bleed → +1 bonus_strike rider, read at
# bough/hunter/mark/on_hit_marked) and +2 mark detection range blocks
# (ec.pollen_sk_pulse, read at bough/hunter/mark/glow_owner, 24→26 + 1s glow).
# Derived by bough/pollen_tick (single writer).
scoreboard objectives add ec.ht_pln_dmg dummy "Bough HT Pollen Mark Dmg"
scoreboard objectives add ec.ht_pln_pulse dummy "Bough HT Pollen Mark Sense"
# Wave 17 pollen consumer, LIVE since Wave 20: marks heal the nearest other
# player 1 HP on the marked target's death while ec.pollen_hl_mark is owned.
# Derived by bough/pollen_tick (single writer); read at
# bough/hunter/mark/grant_mark_resonance.
scoreboard objectives add ec.ht_pln_mercy dummy "Bough HT Pollen Mercy Heal"
# Wave 18 pollen consumer, LIVE since Wave 20: +1 mark slot while
# ec.pollen_tw_walk is owned. Derived by bough/pollen_tick (single writer);
# read at bough/hunter/mark/get_max_slots.
scoreboard objectives add ec.ht_pln_walk dummy "Bough HT Pollen Mark Slot"
scoreboard objectives add ec.ht_n_c1 dummy "HT C1"
scoreboard objectives add ec.ht_n_c2 dummy "HT C2"
scoreboard objectives add ec.ht_n_c3 dummy "HT C3"
scoreboard objectives add ec.ht_n_c4 dummy "HT C4"
scoreboard objectives add ec.ht_n_c5 dummy "HT C5"
scoreboard objectives add ec.ht_n_c6 dummy "HT C6"
scoreboard objectives add ec.ht_n_c7 dummy "HT C7"
scoreboard objectives add ec.ht_n_c8 dummy "HT C8"
scoreboard objectives add ec.ht_n_c9 dummy "HT C9"
scoreboard objectives add ec.ht_n_c10 dummy "HT C10"
scoreboard objectives add ec.ht_n_c11 dummy "HT C11"
scoreboard objectives add ec.ht_n_c12 dummy "HT C12"
scoreboard objectives add ec.ht_n_u1 dummy "HT U1"
scoreboard objectives add ec.ht_n_u2 dummy "HT U2"
scoreboard objectives add ec.ht_n_u3 dummy "HT U3"
scoreboard objectives add ec.ht_n_u4 dummy "HT U4"
scoreboard objectives add ec.ht_n_u5 dummy "HT U5"
scoreboard objectives add ec.ht_n_u6 dummy "HT U6"
scoreboard objectives add ec.ht_n_u7 dummy "HT U7"
scoreboard objectives add ec.ht_n_u8 dummy "HT U8"
scoreboard objectives add ec.ht_n_u9 dummy "HT U9"
scoreboard objectives add ec.ht_n_u10 dummy "HT U10"
scoreboard objectives add ec.ht_n_u11 dummy "HT U11"
scoreboard objectives add ec.ht_n_u12 dummy "HT U12"
scoreboard objectives add ec.ht_n_m1 dummy "HT M1"
scoreboard objectives add ec.ht_n_m2 dummy "HT M2"
scoreboard objectives add ec.ht_n_m3 dummy "HT M3"
scoreboard objectives add ec.ht_n_m4 dummy "HT M4"
scoreboard objectives add ec.ht_n_m5 dummy "HT M5"
# Mastery consumers (Wave 37): HP probe + M4 cooldown.
scoreboard objectives add ec.ht_hp dummy "HT HP Probe"
scoreboard objectives add ec.ht_m4_cd dummy "HT M4 Cooldown"
# Hunt (combat-tree rewrite 2026-06-21): solo tracker aura (reveal/harry foes + pursuit buffs +
# Headhunter capstone). Engine = hunt/tick → pulse. C2 attack_speed (bough_ht_c2) stripped on
# unequip in artifacts/hunter/aim_check. The "vs marked" nodes C7/C11 ride the existing mark
# system (mark/on_hit_marked, mark/on_death).
scoreboard objectives add ec.ht_hunt_cd dummy "HT Headhunter CD"
# PERMANENT account-wide perks + lvl 1/6/12 milestones (util-tree rewrite 2026-06-21).
scoreboard objectives add ec.ht_phealth dummy "HT Perk HP Probe"
scoreboard objectives add ec.ht_msn1 dummy "HT Milestone 1 Seen"
scoreboard objectives add ec.ht_msn6 dummy "HT Milestone 6 Seen"
scoreboard objectives add ec.ht_msn12 dummy "HT Milestone 12 Seen"
schedule function evercraft:bough/hunter/crown_tick 20t
schedule function evercraft:bough/hunter/mastery_tick 20t
schedule function evercraft:bough/hunter/hunt/tick 20t
schedule function evercraft:bough/hunter/perks/tick 20t
