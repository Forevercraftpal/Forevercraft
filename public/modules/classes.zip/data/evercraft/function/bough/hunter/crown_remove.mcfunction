# === BOUGH HUNTER — CROWN REMOVE ===
# Clears the Mark of Death flags on @s: hunter-only 2× (ec.ht_mark_self),
# ally +25% (ec.ht_mark_allybuff) and mark-cost. Idempotent. Called from
# Reroot AND each second by crown_tick for any flag-holder who is no longer
# active+crowned (Wave 20 stale-flag reconcile). Live marks are NOT dissolved
# here — they simply lose the amp and expire on their own 60s clock.
scoreboard players set @s ec.ht_mark_self 0
scoreboard players set @s ec.ht_mark_allybuff 0
scoreboard players set @s ec.ht_mark_cost 0
