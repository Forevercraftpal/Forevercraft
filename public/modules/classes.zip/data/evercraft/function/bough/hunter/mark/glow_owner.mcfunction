# === BOUGH HUNTER — MARK OF DEATH · OWNER GLOW PULSE (Wave 20) ===
# @s = a hunter with a mark id, at @s (caller: mark/tick, 1s). The hunter's
# own marks pulse Glowing while inside sense range:
#   base 24 blocks / 2s pulse · 26 blocks / 3s with ec.ht_pln_pulse
#   (pollen_sk_pulse, Striker U5 Tremor Sense — the +2 detection range
#   blocks, wired as a score-gated selector pair; the +1s glow rides it).
scoreboard players operation #ht_mk_gid ec.var = @s ec.ht_mark_id
execute unless score @s ec.ht_pln_pulse matches 1.. as @e[tag=ec.ht_marked,distance=..24] if score @s ec.ht_mark_owner = #ht_mk_gid ec.var run effect give @s minecraft:glowing 2 0 true
execute if score @s ec.ht_pln_pulse matches 1.. as @e[tag=ec.ht_marked,distance=..26] if score @s ec.ht_mark_owner = #ht_mk_gid ec.var run effect give @s minecraft:glowing 3 0 true
