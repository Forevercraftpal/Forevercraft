# === BOUGH HUNTER — MASTERY TICK (1s, Wave 37) ===
# M2/M3 fire from kill advs. This tick handles M1 (passive attack damage),
# M4 (panic save), M5 (passive attack damage).
execute unless entity @a[tag=ec.ht_active] run return run schedule function evercraft:bough/hunter/mastery_tick 20t

scoreboard players remove @a[scores={ec.ht_m4_cd=1..}] ec.ht_m4_cd 1

# M1 Hunt Mastery (pivot): passive +5% attack_damage.
execute as @a[scores={ec.ht_n_m1=1..},tag=ec.ht_active] run attribute @s minecraft:attack_damage modifier remove evercraft:bough_ht_m1
execute as @a[scores={ec.ht_n_m1=1..},tag=ec.ht_active] run attribute @s minecraft:attack_damage modifier add evercraft:bough_ht_m1 0.05 add_multiplied_base
execute as @a unless score @s ec.ht_n_m1 matches 1.. run attribute @s minecraft:attack_damage modifier remove evercraft:bough_ht_m1
execute as @a[tag=!ec.ht_active] run attribute @s minecraft:attack_damage modifier remove evercraft:bough_ht_m1

# M5 Crown's Mark (pivot): passive +5% attack_damage.
execute as @a[scores={ec.ht_n_m5=1..},tag=ec.ht_active] run attribute @s minecraft:attack_damage modifier remove evercraft:bough_ht_m5
execute as @a[scores={ec.ht_n_m5=1..},tag=ec.ht_active] run attribute @s minecraft:attack_damage modifier add evercraft:bough_ht_m5 0.05 add_multiplied_base
execute as @a unless score @s ec.ht_n_m5 matches 1.. run attribute @s minecraft:attack_damage modifier remove evercraft:bough_ht_m5
execute as @a[tag=!ec.ht_active] run attribute @s minecraft:attack_damage modifier remove evercraft:bough_ht_m5

# M4 Death Mark: HP ≤ 5 + ht_active + cd ready → panic.
execute as @a[scores={ec.ht_n_m4=1..,ec.ht_m4_cd=..0},tag=ec.ht_active] store result score @s ec.ht_hp run data get entity @s Health 1
execute as @a[scores={ec.ht_n_m4=1..,ec.ht_m4_cd=..0,ec.ht_hp=..5},tag=ec.ht_active] at @s run function evercraft:bough/hunter/m4_death_mark

schedule function evercraft:bough/hunter/mastery_tick 20t
