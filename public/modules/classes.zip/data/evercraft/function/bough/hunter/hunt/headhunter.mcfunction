# === BOUGH HUNTER — HEADHUNTER (C12 capstone) ===
# @s = the Hunter, at @s, with a foe within 8. The hunt closes: Strength II + Speed II while
# every nearby foe is exposed (Glowing) and shaken (Weakness). 30s cooldown.
scoreboard players set @s ec.ht_hunt_cd 30
effect give @s minecraft:strength 6 1 true
effect give @s minecraft:speed 6 1 true
effect give @e[type=#evercraft:hostile_mobs,distance=..8] minecraft:glowing 6 0 true
effect give @e[type=#evercraft:hostile_mobs,distance=..8] minecraft:weakness 6 0 true
data modify storage evercraft:notify stage.c set value [{text:"➶ ",color:"green"},{text:"Headhunter",color:"green",bold:true},{text:" — the quarry is yours.",color:"gray"}]
scoreboard players set #ndur ec.temp 50
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:item.crossbow.shoot master @s ~ ~ ~ 0.7 0.8
