# === BOUGH HUNTER — CROWN TICK (1s) ===
# Mark of Death (RETUNE 1, mechanic LIVE since Wave 20): marked enemies take
# 2× damage from the HUNTER only; allies deal +25% to marked targets; marking
# costs 1 heart. Flags (ec.ht_mark_self / ec.ht_mark_allybuff / ec.ht_mark_cost)
# are reconciled here each second and READ by bough/hunter/mark/on_hit_marked +
# mark/apply, fed from the advantage/track/on_attack dispatcher.

# Mark maintenance runs for ALL hunters' marks (crowned or not) — recount the
# global mark population (also the on_attack HIT-branch gate), dispatch the
# 1s mark tick, and do it BEFORE the crown early-return below.
execute store result score #ht_marks ec.var if entity @e[tag=ec.ht_marked]
execute if score #ht_marks ec.var matches 1.. run function evercraft:bough/hunter/mark/tick

# Strip stale Crown flags from hunters who are no longer active+crowned —
# crown_apply only ever sets them; without this reconcile a hunter who
# holstered the crossbow would keep the 2×/toll flags until Reroot.
execute as @a[scores={ec.ht_mark_self=1..}] unless entity @s[tag=ec.ht_active,scores={ec.ht_b_crown=1}] run function evercraft:bough/hunter/crown_remove

execute unless entity @a[tag=ec.ht_active,scores={ec.ht_b_crown=1}] run return run schedule function evercraft:bough/hunter/crown_tick 20t
execute as @a[tag=ec.ht_active,scores={ec.ht_b_crown=1}] at @s run function evercraft:bough/hunter/crown_apply
schedule function evercraft:bough/hunter/crown_tick 20t
