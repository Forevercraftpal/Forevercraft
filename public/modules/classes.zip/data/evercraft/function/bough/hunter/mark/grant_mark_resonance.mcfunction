# === BOUGH HUNTER — MARK OF DEATH · RESOLVE GRANTS (Wave 20) ===
# @s = the Hunter who owned the mark; POSITION = the dead target (caller:
# mark/on_death keeps the corpse position so the mercy radius is measured
# from the kill, not the killer).
#
#   U12 Bloodthread (ec.ht_n_u12): +200 Mastery XP + the heart refund the
#     codex copy promises ("...grants +200 Mastery XP and refunds the
#     mark's heart cost") — refund only fires while the Crown toll is live
#     (ec.ht_mark_cost), since an uncrowned mark cost nothing. NOTE: codex
#     copy scopes Bloodthread to champion kills; Wave 20 grants on every
#     marked kill per the wave brief — the general §2.1 "marked-target kills"
#     Iron source stays with the future resonance-grant wave.
#   Mercy mark (ec.ht_pln_mercy / pollen_hl_mark, Healer U7): the nearest
#     OTHER player within 16 blocks of the kill is healed 1 HP.

# --- U12 Bloodthread ---
execute if score @s ec.ht_n_u12 matches 1.. run function evercraft:bough/mastery/find_xp {cls:"ht",amount:200}
execute if score @s ec.ht_n_u12 matches 1.. if score @s ec.ht_mark_cost matches 1.. run effect give @s minecraft:instant_health 1 0 true

# --- mercy mark: heal the nearest ally at the kill site (owner excluded) ---
execute if score @s ec.ht_pln_mercy matches 1.. run tag @s add ec.ht_mk_ownr
execute if score @s ec.ht_pln_mercy matches 1.. run effect give @a[tag=!ec.ht_mk_ownr,distance=..16,sort=nearest,limit=1] minecraft:instant_health 1 0 true
tag @s remove ec.ht_mk_ownr

# --- FX: the hunt resolves — low horn settles, heard at the hunter ---
execute if score @s ec.fx_snd matches 1.. at @s run playsound minecraft:block.note_block.didgeridoo master @s ~ ~ ~ 0.5 0.749
