# === BOUGH HUNTER — CROWN APPLY (Mark of Death) ===
# Run as @s = active hunter owning the Crown. RETUNE 1, mechanic LIVE since
# Wave 20: marked enemies take 2× damage from the HUNTER ONLY (ec.ht_mark_self,
# read by bough/hunter/mark/on_hit_marked when resolving the owner's hits);
# allies deal +25% damage to marked targets (ec.ht_mark_allybuff, read by the
# same hook for non-owner hits). Marking costs 1 heart (ec.ht_mark_cost, read
# by bough/hunter/mark/apply when a mark is placed), reconciled idempotently
# each second (Wrathblood pattern); crown_tick strips the flags within 1s of
# the hunter leaving active+crowned state.
scoreboard players set @s ec.ht_mark_self 1
scoreboard players set @s ec.ht_mark_allybuff 1
scoreboard players set @s ec.ht_mark_cost 1
