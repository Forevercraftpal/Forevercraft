# === BOUGH HUNTER — HUNT TICK (1s) ===
# Runs hunt/pulse for any Hunter (tag ec.ht_active) with >=1 combat point. C2 attack-speed is
# reconciled here (active-gated; stripped on unequip in artifacts/hunter/aim_check). C12
# Headhunter cooldown burns here. The "vs marked" nodes (C7/C11) ride the existing mark system
# (mark/on_hit_marked, mark/on_death) — not this tick.
execute unless entity @a[tag=ec.ht_active,scores={ec.ht_b_combat=1..}] run return run schedule function evercraft:bough/hunter/hunt/tick 20t
scoreboard players remove @a[scores={ec.ht_hunt_cd=1..}] ec.ht_hunt_cd 1

# C2 Quick Reload (+10% attack speed) — reconciled while active.
execute as @a[scores={ec.ht_n_c2=1..},tag=ec.ht_active] run attribute @s minecraft:attack_speed modifier remove evercraft:bough_ht_c2
execute as @a[scores={ec.ht_n_c2=1..},tag=ec.ht_active] run attribute @s minecraft:attack_speed modifier add evercraft:bough_ht_c2 0.1 add_multiplied_base
execute as @a unless score @s ec.ht_n_c2 matches 1.. run attribute @s minecraft:attack_speed modifier remove evercraft:bough_ht_c2
execute as @a[tag=!ec.ht_active] run attribute @s minecraft:attack_speed modifier remove evercraft:bough_ht_c2

execute as @a[tag=ec.ht_active,scores={ec.ht_b_combat=1..}] at @s run function evercraft:bough/hunter/hunt/pulse
schedule function evercraft:bough/hunter/hunt/tick 20t
