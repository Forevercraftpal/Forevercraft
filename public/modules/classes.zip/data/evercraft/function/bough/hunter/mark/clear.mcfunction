# === BOUGH HUNTER — MARK OF DEATH · CLEAR ONE MARK (Wave 20) ===
# @s = a marked entity. Dissolves the mark in place: scores first, tag last
# (callers select on the tag). Shared by expiry (mark/tick), death resolve
# (mark/on_death) and Reroot (hunter/reroot). Silent — no player context.
scoreboard players reset @s ec.ht_mark_owner
scoreboard players reset @s ec.ht_mark_dur
tag @s remove ec.ht_marked
# Wave 28: pack-set marks (Beastlord pollen_share_pulse) carry an extra tag so
# the pulse's refresh line only tops up its OWN marks — strip it here too so
# it never lingers on a long-lived mob after the mark dissolves.
tag @s remove ec.bl_share_mark
