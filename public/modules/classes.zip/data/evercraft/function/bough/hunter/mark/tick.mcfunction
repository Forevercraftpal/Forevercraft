# === BOUGH HUNTER — MARK OF DEATH · TICK (1s, Wave 20) ===
# Dispatched by bough/hunter/crown_tick BEFORE its crown early-return (marks
# from uncrowned hunters must still burn), gated there on #ht_marks ec.var 1..
# (the same recount that arms the on_attack HIT branch). Order is load-bearing:
# dead marks resolve before they could burn/glow.

# 1) death-scan backstop — catches kills the player_hurt_entity seam can't
#    (fall/fire/rider/pet); the corpse lingers ~20t, one 20t cadence catches it
execute as @e[tag=ec.ht_marked] if data entity @s {Health:0.0f} at @s run function evercraft:bough/hunter/mark/on_death

# 2) burn duration 20t per second (60s = 1200t from apply; owner hits refresh)
execute as @e[tag=ec.ht_marked] run scoreboard players remove @s ec.ht_mark_dur 20

# 3) expire idle marks — the slot frees up
execute as @e[tag=ec.ht_marked,scores={ec.ht_mark_dur=..0}] run function evercraft:bough/hunter/mark/clear

# 4) detection glow: each owner's marks pulse Glowing while in sense range
#    (vanilla glowing is globally visible — accepted; no per-player scoping
#    short of a team plumb the pack doesn't have)
execute as @a[scores={ec.ht_mark_id=1..}] at @s run function evercraft:bough/hunter/mark/glow_owner
