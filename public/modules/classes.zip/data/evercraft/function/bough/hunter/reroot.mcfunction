# === BOUGH HUNTER — REROOT ===
scoreboard players set @s ec.ht_b_combat 0
scoreboard players set @s ec.ht_b_util 0
scoreboard players set @s ec.ht_b_mast 0
scoreboard players set @s ec.ht_b_crown 0
scoreboard players set @s ec.ht_n_c1 0
scoreboard players set @s ec.ht_n_c2 0
scoreboard players set @s ec.ht_n_c3 0
scoreboard players set @s ec.ht_n_c4 0
scoreboard players set @s ec.ht_n_c5 0
scoreboard players set @s ec.ht_n_c6 0
scoreboard players set @s ec.ht_n_c7 0
scoreboard players set @s ec.ht_n_c8 0
scoreboard players set @s ec.ht_n_c9 0
scoreboard players set @s ec.ht_n_c10 0
scoreboard players set @s ec.ht_n_c11 0
scoreboard players set @s ec.ht_n_c12 0
scoreboard players set @s ec.ht_n_u1 0
scoreboard players set @s ec.ht_n_u2 0
scoreboard players set @s ec.ht_n_u3 0
scoreboard players set @s ec.ht_n_u4 0
scoreboard players set @s ec.ht_n_u5 0
scoreboard players set @s ec.ht_n_u6 0
scoreboard players set @s ec.ht_n_u7 0
scoreboard players set @s ec.ht_n_u8 0
scoreboard players set @s ec.ht_n_u9 0
scoreboard players set @s ec.ht_n_u10 0
scoreboard players set @s ec.ht_n_u11 0
scoreboard players set @s ec.ht_n_u12 0
scoreboard players set @s ec.ht_n_m1 0
scoreboard players set @s ec.ht_n_m2 0
scoreboard players set @s ec.ht_n_m3 0
scoreboard players set @s ec.ht_n_m4 0
scoreboard players set @s ec.ht_n_m5 0
# Mastery consumer state reset (Wave 37).
scoreboard players set @s ec.ht_m4_cd 0
attribute @s minecraft:attack_damage modifier remove evercraft:bough_ht_m1
attribute @s minecraft:attack_damage modifier remove evercraft:bough_ht_m5
function evercraft:bough/hunter/crown_remove
# Wave 20: dissolve any live marks this hunter owns — mark state is bough-born
# (ec.ht_mark_id itself persists; it is an identity, not progression)
scoreboard players set #ht_mk_rr ec.var -1
scoreboard players operation #ht_mk_rr ec.var = @s ec.ht_mark_id
execute as @e[tag=ec.ht_marked] if score @s ec.ht_mark_owner = #ht_mk_rr ec.var run function evercraft:bough/hunter/mark/clear
