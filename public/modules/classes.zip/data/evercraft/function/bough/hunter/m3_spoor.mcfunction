# === BOUGH HUNTER — M3 SPOOR (Wave 37, kill adv reward) ===
# Pivot: spec's "30s scent trail" needed per-target visible-trail rendering
# scoped to one player. Replacement: 5% chance per kill → +200 Mastery XP.
# The scent stays.
advancement revoke @s only evercraft:bough/ht_m3_kill
execute unless score @s ec.ht_n_m3 matches 1.. run return 0
execute store result score #ht_m3_roll ec.temp run random value 1..20
execute unless score #ht_m3_roll ec.temp matches 1 run return 0
function evercraft:bough/mastery/find_xp {cls:"ht",amount:200}
title @s actionbar [{text:"✦ Spoor ",color:"aqua",bold:true},{text:"— +200 Mastery XP",color:"gray",italic:true}]
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.5 1.2
