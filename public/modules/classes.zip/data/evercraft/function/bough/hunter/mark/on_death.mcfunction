# === BOUGH HUNTER — MARK OF DEATH · ON DEATH (Wave 20) ===
# @s = the marked entity at the moment its Health hit 0.0f, at @s. Reached
# from two seams: the same-tick check in mark/on_hit_marked (player kills —
# the common case) and the 1s scanner backstop in mark/tick (environmental /
# rider / pet deaths). The mark resolves: the owning Hunter collects the
# Bloodthread grant + mercy ripple, then the slot frees up.

# --- snapshot the owner id, then dissolve the mark FIRST (no double-resolve
# if the corpse lingers into the next scanner pass) ---
scoreboard players set #ht_mk_own ec.var -1
scoreboard players operation #ht_mk_own ec.var = @s ec.ht_mark_owner
function evercraft:bough/hunter/mark/clear

# --- resolve the owning Hunter (position stays AT the corpse for the mercy
# radius; an offline owner simply forfeits the resolve) ---
execute as @a[scores={ec.ht_mark_id=1..}] if score @s ec.ht_mark_id = #ht_mk_own ec.var run function evercraft:bough/hunter/mark/grant_mark_resonance
# C11 Killshot (combat node): a marked-target kill grants the owner Strength I 5s.
execute as @a[scores={ec.ht_mark_id=1..}] if score @s ec.ht_mark_id = #ht_mk_own ec.var if score @s ec.ht_n_c11 matches 1.. run effect give @s minecraft:strength 5 0 true
