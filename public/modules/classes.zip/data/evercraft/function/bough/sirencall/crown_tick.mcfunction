# === BOUGH SIRENCALL — CROWN TICK (1s) ===
# Tidecaller's Vow: every fish caught comes with a Tidecaller token (1/8
# trades for a free aquatic accessory; stockpiles in ec.sc_tide_tokens) while
# owned; the vow bans fishing in still water (consumer hooks TODO — see
# crown_apply). Active-state gate: Sirencall has no stance tag — the class
# condition is ANY Sirencall crafting affinity (ec.caff_sc 1.., CraftForever
# rod XP). Knight stance-exit pattern:
# 0. Strip lingering Tidecaller state from owners whose Sirencall condition
#    was cleared since the last tick (Pioneer wipe / admin affinity strip).
#    ec.sc_vow=1 is the "Vow engaged" latch — set every apply, cleared by
#    crown_remove.
execute as @a[scores={ec.sc_b_crown=1,ec.sc_vow=1}] unless score @s ec.caff_sc matches 1.. at @s run function evercraft:bough/sirencall/crown_remove
execute unless entity @a[scores={ec.sc_b_crown=1,ec.caff_sc=1..}] run return run schedule function evercraft:bough/sirencall/crown_tick 20t
execute as @a[scores={ec.sc_b_crown=1,ec.caff_sc=1..}] at @s run function evercraft:bough/sirencall/crown_apply
schedule function evercraft:bough/sirencall/crown_tick 20t
