# === BOUGH SIRENCALL — VOW BREAK (Tidecaller's Vow still-water refusal) ===
# Run as @s = the Crown-owning catcher, POSITIONED AT the clicked node marker, from
# fishing/splash_nodes/do_catch (BEFORE the engine roll — the refused click burns no
# node charge and grants no XP; the player can walk to flowing water and re-click).
# The vow (ec.sc_no_still) bans still-water fishing: a full source block
# (water[level=0]) at/under the node, outside ocean biomes.
data modify storage evercraft:notify stage.c set value [{text:"✗ ",color:"red"},{text:"Still water rejects the Tidecaller's vow",color:"gray"}]
scoreboard players set #ndur ec.temp 30
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.bubble_column.bubble_pop master @s ~ ~ ~ 0.4 0.6
