# === BOUGH SIRENCALL — TIDE TOKEN MILESTONE (bundle nudge) ===
# Run as @s = the Crown-owning catcher, at the player, from the splash-node success
# path (fishing/splash_nodes/do_catch_success) right after the +1 ec.sc_tide_tokens
# mint. Fires the redeem nudge once per FULL 8-token bundle (tokens >= 8 AND
# tokens % 8 == 0), so it pings at 8, 16, 24… — not on every catch past 8.
# Does NOT reset/deduct the counter: the codex redeem GUI (later wave) owns the
# spend (8 tokens = 1 aquatic accessory; 4 with M5 Crown's Tide, ec.sc_n_m5 —
# the M5 halving lands with the redeem GUI, not here).
execute unless score @s ec.sc_tide_tokens matches 8.. run return 0
scoreboard players set #sc_tok8 ec.temp 8
scoreboard players operation #sc_tokmod ec.temp = @s ec.sc_tide_tokens
scoreboard players operation #sc_tokmod ec.temp %= #sc_tok8 ec.temp
execute unless score #sc_tokmod ec.temp matches 0 run return 0
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"aqua"},{text:"Tidecaller token earned — 1 redeemable at the codex",color:"gray"}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.bubble_column.bubble_pop master @s ~ ~ ~ 0.5 1.0
