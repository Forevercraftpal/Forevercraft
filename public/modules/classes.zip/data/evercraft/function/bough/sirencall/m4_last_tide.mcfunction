# === BOUGH SIRENCALL — M4 LAST TIDE (mastery_tick branch, 2026-06-21) ===
# Pivot: spec's "summon a 3-block water-pocket + Water Breathing 30s" needed a
# structure-place at lethal HP. Replacement (mirrors the lf/gs/tw M4 pattern):
# below 30% HP -> Water Breathing 30s + Resistance I + Regen II for 5s, 60s
# cooldown. The tide carries you under.
effect give @s minecraft:water_breathing 30 0 true
effect give @s minecraft:resistance 5 0 true
effect give @s minecraft:regeneration 5 1 true
title @s actionbar [{text:"🌊 Last Tide ",color:"aqua",bold:true},{text:"— the tide carries you",color:"gray",italic:true}]
execute as @a[distance=..16] if score @s ec.fx_snd matches 1.. run playsound minecraft:ambient.underwater.enter master @s ~ ~ ~ 0.6 1.2
scoreboard players set @s ec.sc_m4_cd 60
