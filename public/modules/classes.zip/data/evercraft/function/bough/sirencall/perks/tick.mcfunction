# === BOUGH SIRENCALL — UTILITY PERK TICK (1s) ===
# Utility scoping (2026-06-22): the U4/U8/U10 gatherer perks stay ACCOUNT-WIDE (multiclass reward); Gate: any Sirencall
# progress (ec.sc_lvl>=1). Light gatherer set on the dead refine slots (U4 movement / U8
# Luck / U10 +heart) + 3 milestones. Wired refine nodes (pollen, *song kill-XP, *eye/
# *sense detection) are untouched. Attribute perks: remove-for-all then add-for-owners.
execute unless entity @a[scores={ec.sc_lvl=1..}] run return run schedule function evercraft:bough/sirencall/perks/tick 20t

# U4 Sure Step (+5% movement speed)
execute as @a[scores={ec.sc_lvl=1..}] run attribute @s minecraft:movement_speed modifier remove evercraft:sc_perk_u4
execute as @a[scores={ec.sc_n_u4=1..}] run attribute @s minecraft:movement_speed modifier add evercraft:sc_perk_u4 0.05 add_multiplied_base
# U8 Lucky Find (Luck I)
execute as @a[scores={ec.sc_n_u8=1..}] run effect give @s minecraft:luck 2 0 true
# U10 Hardy (+1 heart)
execute as @a[scores={ec.sc_lvl=1..}] run attribute @s minecraft:max_health modifier remove evercraft:sc_perk_u10
execute as @a[scores={ec.sc_n_u10=1..}] run attribute @s minecraft:max_health modifier add evercraft:sc_perk_u10 2 add_value


# === POLLEN SOLO BUFFS (active-gated) — multiplayer synergy stays in bough/pollen/sc ===
execute as @a[scores={ec.caff_class=5,ec.sc_n_u1=1..}] run effect give @s minecraft:luck 2 0 true
execute as @a[scores={ec.sc_lvl=1..}] run attribute @s minecraft:movement_speed modifier remove evercraft:sc_pln_u6
execute as @a[scores={ec.caff_class=5,ec.sc_n_u6=1..}] run attribute @s minecraft:movement_speed modifier add evercraft:sc_pln_u6 0.05 add_multiplied_base
execute as @a[scores={ec.sc_lvl=1..}] run attribute @s minecraft:knockback_resistance modifier remove evercraft:sc_pln_u11
execute as @a[scores={ec.caff_class=5,ec.sc_n_u11=1..}] run attribute @s minecraft:knockback_resistance modifier add evercraft:sc_pln_u11 0.2 add_value

# === MILESTONE PASSIVES (lvl 1/6/12, account-wide) ===
# Lvl 1 Sure-Handed — +5% movement speed.
execute as @a[scores={ec.sc_lvl=1..}] run attribute @s minecraft:movement_speed modifier remove evercraft:sc_ms1
execute as @a[scores={ec.sc_lvl=1..}] run attribute @s minecraft:movement_speed modifier add evercraft:sc_ms1 0.05 add_multiplied_base
# Lvl 6 Hardy Hands — +1 heart.
execute as @a[scores={ec.sc_lvl=6..}] run attribute @s minecraft:max_health modifier remove evercraft:sc_ms6
execute as @a[scores={ec.sc_lvl=6..}] run attribute @s minecraft:max_health modifier add evercraft:sc_ms6 2 add_value
# Lvl 12 Master Gatherer — +1 heart + Luck I.
execute as @a[scores={ec.sc_lvl=12..}] run attribute @s minecraft:max_health modifier remove evercraft:sc_ms12
execute as @a[scores={ec.sc_lvl=12..}] run attribute @s minecraft:max_health modifier add evercraft:sc_ms12 2 add_value
execute as @a[scores={ec.sc_lvl=12..}] unless score @s ec.sc_n_u8 matches 1.. run effect give @s minecraft:luck 2 0 true

execute as @a[scores={ec.sc_lvl=1..}] unless score @s ec.sc_msn1 matches 1 run tellraw @s [{text:"✦ Sirencall Mastery 1 — ",color:"gray"},{text:"Sure-Handed",color:"white",bold:true},{text:" unlocked. +movement speed. Permanent, all classes.",color:"gray"}]
scoreboard players set @a[scores={ec.sc_lvl=1..}] ec.sc_msn1 1
execute as @a[scores={ec.sc_lvl=6..}] unless score @s ec.sc_msn6 matches 1 run tellraw @s [{text:"✦ Sirencall Mastery 6 — ",color:"gray"},{text:"Hardy Hands",color:"white",bold:true},{text:" unlocked. +1 heart. Permanent, all classes.",color:"gray"}]
scoreboard players set @a[scores={ec.sc_lvl=6..}] ec.sc_msn6 1
execute as @a[scores={ec.sc_lvl=12..}] unless score @s ec.sc_msn12 matches 1 run tellraw @s [{text:"✦ Sirencall Mastery 12 — ",color:"gray"},{text:"Master Gatherer",color:"white",bold:true},{text:" unlocked. +1 heart and Luck. Permanent, all classes.",color:"gray"}]
scoreboard players set @a[scores={ec.sc_lvl=12..}] ec.sc_msn12 1

schedule function evercraft:bough/sirencall/perks/tick 20t
