# === BOUGH SIRENCALL — CROWN REMOVE ===
# Strips the Tidecaller's Vow state from @s: the token identity flag and the
# still-water-ban vow flag. No attribute modifiers to clear. Idempotent.
# The token stockpile (ec.sc_tide_tokens) is deliberately KEPT — earned
# tokens survive Crown loss/Reroot the same way spent Resonance does not
# refund.
scoreboard players set @s ec.sc_vow 0
scoreboard players set @s ec.sc_no_still 0
