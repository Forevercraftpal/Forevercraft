# === BOUGH SIRENCALL — LOAD ===
# Fifth CraftForever crafting-class bough (Wave 7, mirrors the Stonestrike
# canonical template). Design: _council/2026-06-11-craftforever-bough/DESIGN.md
# §4 Sirencall. Branch suffixes stay _b_combat/_b_util (universal-macro
# contract) — the GUI labels them "Craft" and "Refine".
scoreboard objectives add ec.sc_b_combat dummy "Bough SC Craft Points"
scoreboard objectives add ec.sc_b_util dummy "Bough SC Refine Points"
scoreboard objectives add ec.sc_b_mast dummy "Bough SC Mastery Points"
scoreboard objectives add ec.sc_b_crown dummy "Bough SC Crown Owned"
scoreboard objectives add ec.sc_bough_view dummy "Bough SC Codex View"
scoreboard objectives add ec.sc_lx dummy "Bough SC Last X"
scoreboard objectives add ec.sc_lz dummy "Bough SC Last Z"
scoreboard objectives add ec.sc_lyaw dummy "Bough SC Last Yaw"
scoreboard objectives add ec.sc_vow dummy "Bough SC Tidecaller Vow Active"
scoreboard objectives add ec.sc_no_still dummy "Bough SC Still-Water Ban Flag"
# Tidecaller's vow TOGGLE (right-click owned Crown): 1=vow enforced (still-water fishing
# refused), 0=vow lifted. Latched so crown_apply's 1s reconcile can't clobber the choice.
scoreboard objectives add ec.sc_vow_on dummy "Bough SC Vow Toggle"
scoreboard objectives add ec.sc_vow_pr dummy "Bough SC Vow Toggle Primed"
scoreboard objectives add ec.sc_tide_tokens dummy "Bough SC Tidecaller Tokens"
scoreboard objectives add ec.sc_n_c1 dummy "SC C1"
scoreboard objectives add ec.sc_n_c2 dummy "SC C2"
scoreboard objectives add ec.sc_n_c3 dummy "SC C3"
scoreboard objectives add ec.sc_n_c4 dummy "SC C4"
scoreboard objectives add ec.sc_n_c5 dummy "SC C5"
scoreboard objectives add ec.sc_n_c6 dummy "SC C6"
scoreboard objectives add ec.sc_n_c7 dummy "SC C7"
scoreboard objectives add ec.sc_n_c8 dummy "SC C8"
scoreboard objectives add ec.sc_n_c9 dummy "SC C9"
scoreboard objectives add ec.sc_n_c10 dummy "SC C10"
scoreboard objectives add ec.sc_n_c11 dummy "SC C11"
scoreboard objectives add ec.sc_n_c12 dummy "SC C12"
scoreboard objectives add ec.sc_n_u1 dummy "SC U1"
scoreboard objectives add ec.sc_n_u2 dummy "SC U2"
scoreboard objectives add ec.sc_n_u3 dummy "SC U3"
scoreboard objectives add ec.sc_n_u4 dummy "SC U4"
scoreboard objectives add ec.sc_n_u5 dummy "SC U5"
scoreboard objectives add ec.sc_n_u6 dummy "SC U6"
scoreboard objectives add ec.sc_n_u7 dummy "SC U7"
scoreboard objectives add ec.sc_n_u8 dummy "SC U8"
scoreboard objectives add ec.sc_n_u9 dummy "SC U9"
scoreboard objectives add ec.sc_n_u10 dummy "SC U10"
scoreboard objectives add ec.sc_n_u11 dummy "SC U11"
scoreboard objectives add ec.sc_n_u12 dummy "SC U12"
scoreboard objectives add ec.sc_n_m1 dummy "SC M1"
scoreboard objectives add ec.sc_n_m2 dummy "SC M2"
scoreboard objectives add ec.sc_n_m3 dummy "SC M3"
scoreboard objectives add ec.sc_n_m4 dummy "SC M4"
scoreboard objectives add ec.sc_n_m5 dummy "SC M5"
scoreboard objectives add ec.sc_m4_cd dummy "SC M4 Last Tide Cooldown"
scoreboard objectives add ec.sc_m4_hp dummy "SC M4 HP Probe"
schedule function evercraft:bough/sirencall/crown_tick 20t
schedule function evercraft:bough/sirencall/mastery_tick 20t
# Pollen anchors U1/U6/U11 publish through the shared sweep (already scheduled
# from bough/load; default schedule = replace, so this re-arm is harmless).
schedule function evercraft:bough/pollen_tick 100t

# PERMANENT account-wide perks + lvl 1/6/12 milestones (craft util pass 2026-06-21).
scoreboard objectives add ec.sc_phealth dummy "SC Perk HP Probe"
scoreboard objectives add ec.sc_msn1 dummy "SC Milestone 1 Seen"
scoreboard objectives add ec.sc_msn6 dummy "SC Milestone 6 Seen"
scoreboard objectives add ec.sc_msn12 dummy "SC Milestone 12 Seen"
schedule function evercraft:bough/sirencall/perks/tick 20t
