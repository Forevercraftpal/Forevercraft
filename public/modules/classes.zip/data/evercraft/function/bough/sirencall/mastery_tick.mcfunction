# === BOUGH SIRENCALL — MASTERY TICK (1s) ===
# Wave-58 follow-up (2026-06-21): M4 Last Tide (m4_last_tide.mcfunction) was
# authored but had NO tick surface and no caller — a player who owned M4 never
# triggered it (BO-VERIFY-MASTERYTICK). This tick supplies the missing surface,
# mirroring the lf/gs/tw M4 panic-save pattern. sirencall's only tick-driven
# Mastery node is M4 (M1/M2/M3/M5 are handled outside this tick), so the whole
# sweep gates on M4 ownership.
execute unless entity @a[scores={ec.sc_n_m4=1..,ec.caff_sc=1..}] run return run schedule function evercraft:bough/sirencall/mastery_tick 20t
scoreboard players remove @a[scores={ec.sc_m4_cd=1..}] ec.sc_m4_cd 1
# M4 Last Tide: below 30% HP (<=6 of base 20) + off cooldown -> the tide save.
execute as @a[scores={ec.sc_n_m4=1..,ec.sc_m4_cd=..0,ec.caff_sc=1..}] store result score @s ec.sc_m4_hp run data get entity @s Health 1
execute as @a[scores={ec.sc_n_m4=1..,ec.sc_m4_cd=..0,ec.sc_m4_hp=..6,ec.caff_sc=1..}] at @s run function evercraft:bough/sirencall/m4_last_tide
schedule function evercraft:bough/sirencall/mastery_tick 20t
