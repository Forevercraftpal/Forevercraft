# === BOUGH SIRENCALL — CROWN APPLY (Tidecaller's Vow) ===
# Run as @s = Sirencall (any ec.caff_sc affinity XP) owning the Crown, at @s.
# Identity-flag-driven — no attribute modifier (no combat stats). Reconciled
# idempotently each second (Wrathblood pattern):
#   ec.sc_vow=1 → every fish caught comes with a Tidecaller token; 8 tokens
#     trade for a free aquatic accessory (1/4 with M5 Crown's Tide,
#     ec.sc_n_m5). Tokens stockpile in ec.sc_tide_tokens (declared in load).
#   ec.sc_no_still=1 → the vow: you cannot fish in still water (flowing
#     water or open ocean only).
#
# Wave 9 consumer hooks (2026-06-11) — WIRED:
#   - [DONE] token-on-catch: fishing/splash_nodes/do_catch_success mints +1
#     ec.sc_tide_tokens per successful splash catch (ec.sc_b_crown +
#     ec.caff_sc gate) and fires bough/sirencall/tide_token_milestone (a
#     once-per-8-token bundle nudge). The redeem itself (8 tokens -> aquatic
#     accessory; 4 with ec.sc_n_m5) is the codex GUI's job — a later wave;
#     tokens stockpile untouched until then.
#   - [DONE] still-water ban: fishing/splash_nodes/do_catch refuses the
#     catch BEFORE the engine roll (no claim/charge/XP) when the node's
#     liquid is a full source block (water[level=0]) outside ocean biomes ->
#     bough/sirencall/vow_break (notify + pop). Checked at the clicked
#     MARKER (~ ~-1 ~ surface / ~ ~ ~ underwater), not the player's feet.
#     Ocean is exempt per the vow contract above ("flowing water or open
#     ocean only" — ocean surface is all source blocks).
#   - [DONE] biome-aware C10/C12 (lava): do_catch_success — C10 lava catch
#     yields +1 nether quartz (loot evercraft:bough/sirencall/
#     lava_quartz_bonus); C12 lava catch grants +1 ec.res_myth_sc. Lava
#     gate = gth_temp.dim==2 (NOT ec.gth_reqlv==60 — the Home-Turf shave in
#     gather/compute_reqlv mutates gth_reqlv in place, so a Biome-Master's
#     lava node reads 40-56). GAP: no champion-fish predicate exists yet,
#     so every lava catch counts as champion for C12; C10's ocean +1
#     prismarine and C12's +1 Iron (non-lava champion) wire in a later wave.
#
# Wave 29 champion hooks (2026-06-11) — ledger:
#   - [DONE] U12 Reefsong: mob_crates/drop/kill/{guardian,drowned} — a kill
#     grants +1 ec.res_iron_sc (no biome gate; the node text names the mobs).
#   - [UNCHANGED] C12 Tide Master: lava-Mythril half live since Wave 9 (above);
#     the +1 Iron non-lava-champion half still waits on a champion-fish signal.
scoreboard players set @s ec.sc_vow 1
scoreboard players set @s ec.sc_no_still 1
# Default the vow toggle ON once (latch survives the 1s reconcile).
execute unless score @s ec.sc_vow_pr matches 1 run scoreboard players set @s ec.sc_vow_on 1
scoreboard players set @s ec.sc_vow_pr 1
