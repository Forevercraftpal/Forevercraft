# === BOUGH SIRENCALL — TIDECALLER'S VOW TOGGLE ===
# Right-clicking the OWNED Tidecaller's Vow Crown suspends/restores it:
#   ON  → the vow holds: no fishing in still water (flowing water / open ocean only).
#   OFF → vow lifted: you may fish anywhere (Tidecaller bonuses stay active).
# Flips the latched ec.sc_vow_on; fishing/splash_nodes/do_catch gates on it. Page
# rebuilds this tick (the right-click set ec.bough_dirty), so the Crown recolors.
scoreboard players operation #sc_tog ec.temp = @s ec.sc_vow_on
execute if score #sc_tog ec.temp matches 1.. run scoreboard players set @s ec.sc_vow_on 0
execute if score #sc_tog ec.temp matches ..0 run scoreboard players set @s ec.sc_vow_on 1
execute if score #sc_tog ec.temp matches 1.. run data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"aqua"},{text:"Tidecaller's vow ",color:"gray"},{text:"LIFTED",color:"green",bold:true},{text:" — you may fish still water again.",color:"gray"}]
execute if score #sc_tog ec.temp matches ..0 run data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"aqua"},{text:"Tidecaller's vow ",color:"gray"},{text:"RESTORED",color:"red",bold:true},{text:" — flowing water or open ocean only.",color:"gray"}]
scoreboard players set #ndur ec.temp 60
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.5 1.4
