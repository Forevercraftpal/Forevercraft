# === BOUGH — UNIVERSAL SPEND (macro) ===
# Mastery economy (2026-06-14): nodes cost Bough Points (ec.<cls>_pts), and the
# old iron/steel/myth/anci "tier" is now a LEVEL-GATE (minimum ec.<cls>_lvl),
# not a separate currency. Points come from leveling via bough/mastery.
#
# Usage: function evercraft:bough/spend {cls:"rg",branch:"combat",tier:"iron",cost:"1",node:"c1",label:"Quick Blade",color:"red"}
#   cls:    class code (bk/rg/dn/sk/sn/hl/bl/jv/hp/ar/ht/kt/tk/ds + ss/lf/gs/tw/sc/lm/gw)
#   branch: combat / util / mast  — increments ec.<cls>_b_<branch>
#   tier:   iron / steel / myth / anci — gates on ec.<cls>_lvl >= #b_gate_<tier>
#   cost:   Bough Points to spend
#   node:   node suffix (c1..c12, u1..u12, m1..m5)
#   label/color: notify text
#
# Handles flag-only nodes (most). Per-class spends layer attribute/tag effects.

# 1. Already owned? Toggle nodes (#tog_<cls>_<node> ec.const == 1) flip on right-click;
#    every other node just nudges "already owned". The #tog check is false for non-toggle
#    nodes (the fake-player is unset), so this branch is inert for them.
$execute if score @s ec.$(cls)_n_$(node) matches 1.. if score #tog_$(cls)_$(node) ec.const matches 1 run function evercraft:bough/toggle/$(cls)_$(node)
$execute if score @s ec.$(cls)_n_$(node) matches 1.. if score #tog_$(cls)_$(node) ec.const matches 1 run return 0
$execute if score @s ec.$(cls)_n_$(node) matches 1.. run tellraw @s [{text:"[Tree] ",color:"gray"},{text:"$(label) ",color:"$(color)"},{text:"already owned.",color:"yellow"}]
$execute if score @s ec.$(cls)_n_$(node) matches 1.. run return 0

# 2. Level gate for this tier
$scoreboard players operation #b_need ec.temp = #b_gate_$(tier) ec.const
$execute unless score @s ec.$(cls)_lvl >= #b_need ec.temp run tellraw @s [{text:"[Tree] ",color:"gray"},{text:"$(label)",color:"$(color)"},{text:" needs Level ",color:"red"},{score:{name:"#b_need",objective:"ec.temp"},color:"red",bold:true},{text:".",color:"red"}]
$execute unless score @s ec.$(cls)_lvl >= #b_need ec.temp run return 0

# 3. Enough Bough Points?
$execute unless score @s ec.$(cls)_pts matches $(cost).. run tellraw @s [{text:"[Tree] ",color:"gray"},{text:"Not enough Bough Points.",color:"red"}]
$execute unless score @s ec.$(cls)_pts matches $(cost).. run return 0

# 4. Deduct, stamp flag, bump branch
$scoreboard players remove @s ec.$(cls)_pts $(cost)
$scoreboard players set @s ec.$(cls)_n_$(node) 1
$scoreboard players add @s ec.$(cls)_b_$(branch) 1

# 5. Notify + cue
$tellraw @s [{text:"[Tree] ",color:"gray"},{text:"$(label)",color:"$(color)",bold:true},{text:" — purchased.",color:"white"}]
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.5 1.4
