# === BOUGH — UNIVERSAL INFO (macro) ===
# Usage: function evercraft:bough/info {label:"C1 Quick Blade",tier:"Iron",cost:"1",desc:"..."}
# Shows the node description as a CHAT tellraw (mirrors gui/inspect/card) — needs
# no rebuild, so left-clicking a node never flickers the menu, and it reads on
# every page. Runs as the clicking player (handlers route via `on attacker`).
# Does NOT touch the description panel — that stays on the standing "Left-click
# any node for more info!" hint so the info never replaces it.

$tellraw @s [{text:"[",color:"dark_gray"},{text:"❀",color:"yellow"},{text:"] ",color:"dark_gray"},{text:"$(label)",color:"yellow",bold:true},{text:"   $(tier) · $(cost) pt",color:"gray"}]
$tellraw @s [{text:"  $(desc)",color:"white"}]
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:ui.button.click master @s ~ ~ ~ 0.3 1.8
