# === BOUGH JAVELIN — SKYSPEAR THROW-RANGE BOOST (Wave 25, per-tick) ===
# Run as each active Skyspear owner (ec.jv_spear_range 1..) at @s, hooked from
# artifacts/javelin/tick STEP 1.5. Catches the throw EDGE: while the javelin
# trident is in mainhand the latch stays armed (0); on the first tick the
# mainhand goes empty (= the trident was just loosed — tick_player keeps
# ec.jv_active on an empty mainhand for exactly this reason) the latch burns
# and the freshly-spawned trident within 6 blocks gets its Motion scaled by
# ec.jv_spear_range/10 (30/40/50 tenths = 3.0x/4.0x/5.0x). The edge-latch +
# ec.jv_rng_b tag + ..6 ring means returning/foreign tridents are never
# scaled (a loyalty return arrives many ticks after the edge — no-op scan).
#
# Physics note (documented choice): velocity scaling ~= range scaling for
# spear arcs (drag is per-tick multiplicative) — "triple range" rides a 3x
# launch speed rather than a Life-NBT stretch.

# Holding (any mainhand item while jv_active = the javelin trident) → arm latch, done.
execute if items entity @s weapon.mainhand * run scoreboard players set @s ec.jv_throw_l 0
execute if items entity @s weapon.mainhand * run return 0

# Not the throw edge (latch already burned, or never armed) → done.
execute unless score @s ec.jv_throw_l matches 0 run return 0
scoreboard players set @s ec.jv_throw_l 1

# Wave 34 (infinite return): lazy-assign the thrower's unique id (the
# spirit/detect ec.sp_uid idiom — single writer is THIS function) and hand
# uid + infinite flag to spear_boost_apply via temps, so the fresh trident
# can be owner-stamped for spear_return_check's owner resolution.
execute unless score @s ec.jv_uid matches 1.. run scoreboard players add #uid ec.jv_uid 1
execute unless score @s ec.jv_uid matches 1.. run scoreboard players operation @s ec.jv_uid = #uid ec.jv_uid
scoreboard players operation #jv_pid ec.temp = @s ec.jv_uid
scoreboard players set #jv_inf ec.temp 0
execute if score @s ec.jv_spear_infinite matches 1.. run scoreboard players set #jv_inf ec.temp 1

# Throw edge: scale the just-spawned trident (nearest unscaled, in flight).
scoreboard players operation #jv_rng ec.temp = @s ec.jv_spear_range
execute as @e[type=trident,tag=!ec.jv_rng_b,distance=..6,nbt={inGround:0b},limit=1,sort=nearest] run function evercraft:bough/javelin/spear_boost_apply
