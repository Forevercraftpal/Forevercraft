# === BOUGH JAVELIN — SKYSPEAR BOOST APPLY (Wave 25) ===
# Run as @s = the freshly-loosed javelin trident. #jv_rng ec.temp = the
# thrower's ec.jv_spear_range in TENTHS (30/40/50). Reads each Motion axis as
# an integer scaled x1000, multiplies by the tenths, writes back x0.0001
# (= original x range/10). Same store-result-to-Motion idiom as
# artifacts/slingshot/scale_arrow. Tagged so it is never re-scaled.
tag @s add ec.jv_rng_b

# X
execute store result score #jv_m ec.temp run data get entity @s Motion[0] 1000
scoreboard players operation #jv_m ec.temp *= #jv_rng ec.temp
execute store result entity @s Motion[0] double 0.0001 run scoreboard players get #jv_m ec.temp
# Y
execute store result score #jv_m ec.temp run data get entity @s Motion[1] 1000
scoreboard players operation #jv_m ec.temp *= #jv_rng ec.temp
execute store result entity @s Motion[1] double 0.0001 run scoreboard players get #jv_m ec.temp
# Z
execute store result score #jv_m ec.temp run data get entity @s Motion[2] 1000
scoreboard players operation #jv_m ec.temp *= #jv_rng ec.temp
execute store result entity @s Motion[2] double 0.0001 run scoreboard players get #jv_m ec.temp

# === Wave 34 — Skyspear infinite return: owner-stamp the spear ===
# #jv_inf/#jv_pid set by spear_boost at the same throw edge. ec.jv_inf-tagged
# tridents are scanned 1/s by crown_tick → spear_return_check: on landing
# (inGround), after dealing damage (dealtDamage), or after 6 airborne cycles,
# the spear flies home — the item stack is copied off the entity and handed
# back at the thrower's feet (spear_return_give). No reader = no cost here.
execute unless score #jv_inf ec.temp matches 1 run return 0
tag @s add ec.jv_inf
scoreboard players operation @s ec.jv_owner = #jv_pid ec.temp
scoreboard players set @s ec.jv_air 0
