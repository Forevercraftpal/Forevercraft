# === BOUGH JAVELIN — CROWN APPLY (Skyspear) ===
# Run as @s = active javelin owning the Crown. Thrown spears gain infinite
# return + triple range; melee damage is halved, reconciled idempotently each
# second (Wrathblood pattern).
#
# Wave 25: ec.jv_spear_range is now a REAL multiplier in TENTHS, recomputed
# here each second (set-then-add, no drift — the Knight parry-window shape):
# Crown base 30 (3.0x), +10 (+1.0x) per Skyspear range pollen flag —
# ec.jv_pln_range (Sirencall U1 Fisher) / ec.jv_pln_pass (Hoplite U1 Phalanx
# Throw), both derived by bough/pollen_tick (single writer). Read at the
# throw edge by bough/javelin/spear_boost (hooked from artifacts/javelin/tick
# STEP 1.5), which scales the fresh trident's Motion by range/10.
# Wave 34: ec.jv_spear_infinite is CONSUMED at the throw edge — spear_boost
# copies it to #jv_inf, spear_boost_apply tags+owner-stamps the trident, and
# crown_tick's spear_return_check flies it home on land/hit/6s failsafe.
scoreboard players set @s ec.jv_spear_infinite 1
scoreboard players set @s ec.jv_spear_range 30
execute if score @s ec.jv_pln_range matches 1.. run scoreboard players add @s ec.jv_spear_range 10
execute if score @s ec.jv_pln_pass matches 1.. run scoreboard players add @s ec.jv_spear_range 10
attribute @s minecraft:attack_damage modifier remove evercraft:long_throw_melee
attribute @s minecraft:attack_damage modifier add evercraft:long_throw_melee -0.5 add_multiplied_base
