# === BOUGH JAVELIN — SPEARSTORM (C12 capstone) ===
# @s = the Javelin, at @s, with a foe within 6. A storm of spears: Strength II + Speed II while
# every nearby foe is struck (3 magic) and slowed. 30s cooldown.
scoreboard players set @s ec.jv_storm_cd 30
effect give @s minecraft:strength 6 1 true
effect give @s minecraft:speed 6 1 true
effect give @e[type=#evercraft:hostile_mobs,distance=..6] minecraft:slowness 4 1 true
tag @s add jv.skirmish_src
execute as @e[type=#evercraft:hostile_mobs,distance=..6] run damage @s 3 minecraft:magic by @e[tag=jv.skirmish_src,limit=1,sort=nearest]
tag @s remove jv.skirmish_src
data modify storage evercraft:notify stage.c set value [{text:"➴ ",color:"aqua"},{text:"Spearstorm",color:"aqua",bold:true},{text:" — the sky rains steel.",color:"gray"}]
scoreboard players set #ndur ec.temp 50
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:item.trident.throw master @s ~ ~ ~ 0.7 1.0
