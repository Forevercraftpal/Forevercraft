# === BOUGH JAVELIN — CROWN TICK (1s) ===
# Skyspear: thrown spears have infinite return + triple range; melee damage
# halved. crown_apply reconciles the melee modifier and recomputes the Wave 25
# ec.jv_spear_range tenths multiplier (30 base, +10 per range pollen flag)
# each second while owned; spear_boost applies it at the throw edge.
# Wave 34: infinite return is LIVE — spear_boost_apply owner-stamps boosted
# tridents (ec.jv_inf tag), and the scan below flies them home on landing /
# hit / 6s failsafe (spear_return_check → spear_return_give).

# Infinite-return scan — ABOVE the no-owner early-return on purpose: a spear
# in flight must come home even if its thrower switched weapons (dropping
# ec.jv_active) or lost the Crown mid-flight. Type-indexed selector = cheap
# no-op when no marked spear is loaded.
execute as @e[type=trident,tag=ec.jv_inf] at @s run function evercraft:bough/javelin/spear_return_check

execute unless entity @a[tag=ec.jv_active,scores={ec.jv_b_crown=1}] run return run schedule function evercraft:bough/javelin/crown_tick 20t
execute as @a[tag=ec.jv_active,scores={ec.jv_b_crown=1}] at @s run function evercraft:bough/javelin/crown_apply
schedule function evercraft:bough/javelin/crown_tick 20t
