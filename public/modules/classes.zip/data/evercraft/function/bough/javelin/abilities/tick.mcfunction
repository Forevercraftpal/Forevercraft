# === BOUGH JAVELIN — WAR-PREP TICK (1s) ===
# Drains the per-class war-prep duration/cooldown, applies the active mode's SUSTAINED
# effect (class-only via the active gate), announces the fade. Rider signatures detonate
# in the combat hit path (see bough/abilities/on_melee_hit or the class projectile hook).
execute unless entity @a[scores={ec.jv_abil_cd=1..}] unless entity @a[scores={ec.jv_abil_id=1..}] run return run schedule function evercraft:bough/javelin/abilities/tick 20t
scoreboard players remove @a[scores={ec.jv_abil_cd=1..}] ec.jv_abil_cd 1
scoreboard players remove @a[scores={ec.jv_abil_dur=1..}] ec.jv_abil_dur 1
execute as @a[scores={ec.jv_abil_dur=0,ec.jv_abil_id=1..}] run tellraw @s [{text:"⚔ ",color:"gray"},{text:"War-prep faded.",color:"gray",italic:true}]
scoreboard players set @a[scores={ec.jv_abil_dur=0,ec.jv_abil_id=1..}] ec.jv_abil_id 0
# id 2 Trident's Wrath
execute as @a[tag=ec.jv_active,scores={ec.jv_abil_id=2,ec.jv_abil_dur=1..}] run effect give @s minecraft:strength 2 1 true
# id 3 Quick Throw
execute as @a[tag=ec.jv_active,scores={ec.jv_abil_id=3,ec.jv_abil_dur=1..}] run effect give @s minecraft:haste 2 1 true
execute as @a[tag=ec.jv_active,scores={ec.jv_abil_id=3,ec.jv_abil_dur=1..}] run effect give @s minecraft:speed 2 0 true
# id 11 Skyfury
execute as @a[tag=ec.jv_active,scores={ec.jv_abil_id=11,ec.jv_abil_dur=1..}] run effect give @s minecraft:strength 2 1 true
# id 12 Tideguard
execute as @a[tag=ec.jv_active,scores={ec.jv_abil_id=12,ec.jv_abil_dur=1..}] run effect give @s minecraft:resistance 2 0 true
execute as @a[tag=ec.jv_active,scores={ec.jv_abil_id=12,ec.jv_abil_dur=1..}] run effect give @s minecraft:regeneration 2 0 true
# id 13 Skyspear Tracking
execute as @a[tag=ec.jv_active,scores={ec.jv_abil_id=13,ec.jv_abil_dur=1..}] run effect give @s minecraft:speed 2 1 true
# id 14 Parting Throw
execute as @a[tag=ec.jv_active,scores={ec.jv_abil_id=14,ec.jv_abil_dur=1..}] run effect give @s minecraft:speed 2 2 true
execute as @a[tag=ec.jv_active,scores={ec.jv_abil_id=14,ec.jv_abil_dur=1..}] run effect give @s minecraft:strength 2 1 true
schedule function evercraft:bough/javelin/abilities/tick 20t
