# === BOUGH JAVELIN — SKYSPEAR INFINITE RETURN · GIVE (Wave 34) ===
# Run as @s = the spear's owner, at @s (resolved by spear_return_check; the
# spear itself is the ec.jv_ret_now-tagged trident — possibly in another
# dimension, which is fine: the selectors below carry no positional filter).
# The artifact stack is copied OFF the trident entity (thrown tridents carry
# their full item under `item` — custom_data/name/lore all survive) onto a
# 0-delay item entity at the owner's feet, then the thrown entity dies. An
# instant hoover that works with a full inventory too (the item just waits
# at your feet) — no item mutation, no Loyalty enchant stamped on the
# artifact (Option A over Option B: B would bake loyalty into the picked-up
# stack permanently).
summon item ~ ~0.3 ~ {PickupDelay:0s,Tags:["ec.jv_ret_i"],Item:{id:"minecraft:trident",count:1}}
data modify entity @e[type=item,tag=ec.jv_ret_i,limit=1,distance=..2] Item set from entity @e[type=trident,tag=ec.jv_ret_now,limit=1] item
tag @e[type=item,tag=ec.jv_ret_i,distance=..2] remove ec.jv_ret_i
kill @e[type=trident,tag=ec.jv_ret_now,limit=1]

# The return chime — the trident's own homing voice, owner-only, Off-gated.
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:item.trident.return player @s ~ ~ ~ 0.8 1.2
