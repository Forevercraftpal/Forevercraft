# === BOUGH JAVELIN — MASTERY TICK (1s, Wave 37) ===
# M3 fires from kill adv. This tick handles M1 (passive +5% movement_speed),
# M2 (low-HP pickup buff — simplified to passive Speed I while low HP), M4
# (panic save), M5 (passive +5% attack_damage). All pivots are player-side
# since the spear/trident throw-state surfaces are unwired.
execute unless entity @a[tag=ec.jv_active] run return run schedule function evercraft:bough/javelin/mastery_tick 20t

scoreboard players remove @a[scores={ec.jv_m4_cd=1..}] ec.jv_m4_cd 1

# M1 Throwing Mastery (pivot): passive +5% movement_speed while jv_active.
execute as @a[scores={ec.jv_n_m1=1..},tag=ec.jv_active] run attribute @s minecraft:movement_speed modifier remove evercraft:bough_jv_m1
execute as @a[scores={ec.jv_n_m1=1..},tag=ec.jv_active] run attribute @s minecraft:movement_speed modifier add evercraft:bough_jv_m1 0.05 add_multiplied_base
execute as @a unless score @s ec.jv_n_m1 matches 1.. run attribute @s minecraft:movement_speed modifier remove evercraft:bough_jv_m1
execute as @a[tag=!ec.jv_active] run attribute @s minecraft:movement_speed modifier remove evercraft:bough_jv_m1

# M5 Crown's Skyspear (pivot): passive +5% attack_damage while jv_active.
execute as @a[scores={ec.jv_n_m5=1..},tag=ec.jv_active] run attribute @s minecraft:attack_damage modifier remove evercraft:bough_jv_m5
execute as @a[scores={ec.jv_n_m5=1..},tag=ec.jv_active] run attribute @s minecraft:attack_damage modifier add evercraft:bough_jv_m5 0.05 add_multiplied_base
execute as @a unless score @s ec.jv_n_m5 matches 1.. run attribute @s minecraft:attack_damage modifier remove evercraft:bough_jv_m5
execute as @a[tag=!ec.jv_active] run attribute @s minecraft:attack_damage modifier remove evercraft:bough_jv_m5

# HP probe for M2/M4.
execute as @a[scores={ec.jv_n_m2=1..},tag=ec.jv_active] store result score @s ec.jv_hp run data get entity @s Health 1
execute as @a[scores={ec.jv_n_m4=1..,ec.jv_m4_cd=..0},tag=ec.jv_active] store result score @s ec.jv_hp run data get entity @s Health 1

# M2 Returning Tide (pivot): HP ≤ 5 → Speed I 2s ("the tide carries her home").
execute as @a[scores={ec.jv_n_m2=1..,ec.jv_hp=..5},tag=ec.jv_active] run effect give @s minecraft:speed 2 0 true

# M4 Parting Throw: HP ≤ 5 + cd ready → panic.
execute as @a[scores={ec.jv_n_m4=1..,ec.jv_m4_cd=..0,ec.jv_hp=..5},tag=ec.jv_active] at @s run function evercraft:bough/javelin/m4_parting_throw

schedule function evercraft:bough/javelin/mastery_tick 20t
