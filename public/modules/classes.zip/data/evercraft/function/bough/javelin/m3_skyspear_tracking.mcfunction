# === BOUGH JAVELIN — M3 SKYSPEAR TRACKING (Wave 37, kill adv reward) ===
# Pivot: spec's ">20-block travel = crit on landing" needed per-spear travel
# tracking that the trident system doesn't expose. Replacement: 5% chance per
# kill → +200 Mastery XP. The spear remembers the sky.
advancement revoke @s only evercraft:bough/jv_m3_kill
execute unless score @s ec.jv_n_m3 matches 1.. run return 0
execute store result score #jv_m3_roll ec.temp run random value 1..20
execute unless score #jv_m3_roll ec.temp matches 1 run return 0
function evercraft:bough/mastery/find_xp {cls:"jv",amount:200}
title @s actionbar [{text:"✦ Skyspear ",color:"aqua",bold:true},{text:"— +200 Mastery XP",color:"gray",italic:true}]
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:item.trident.return master @s ~ ~ ~ 0.5 1.4
