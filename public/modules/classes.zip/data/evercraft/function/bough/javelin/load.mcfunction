# === BOUGH JAVELIN — LOAD ===
scoreboard objectives add ec.jv_b_combat dummy "Bough JV Combat Points"
scoreboard objectives add ec.jv_b_util dummy "Bough JV Utility Points"
scoreboard objectives add ec.jv_b_mast dummy "Bough JV Mastery Points"
scoreboard objectives add ec.jv_b_crown dummy "Bough JV Crown Owned"
scoreboard objectives add ec.jv_bough_view dummy "Bough JV Codex View"
scoreboard objectives add ec.jv_lx dummy "Bough JV Last X"
scoreboard objectives add ec.jv_lz dummy "Bough JV Last Z"
scoreboard objectives add ec.jv_lyaw dummy "Bough JV Last Yaw"
scoreboard objectives add ec.jv_spear_infinite dummy "Bough JV Spear Infinite"
# Wave 34: infinite-return wiring (ec.jv_spear_infinite's first reader).
# ec.jv_uid = lazy per-player unique id (counter at #uid ec.jv_uid — the
# spirit/detect ec.sp_uid idiom; single writer = spear_boost at the throw
# edge). ec.jv_owner = the thrower's uid stamped onto the boosted trident.
# ec.jv_air = per-trident 1s cycle counter (6-cycle failsafe return for
# spears that never land). Consumed by spear_return_check/spear_return_give,
# scanned from crown_tick (the scan line sits ABOVE the no-owner early-return
# so a thrower who switched weapons still gets the spear back).
scoreboard objectives add ec.jv_uid dummy "Bough JV Player UID"
scoreboard objectives add ec.jv_owner dummy "Bough JV Spear Owner"
scoreboard objectives add ec.jv_air dummy "Bough JV Spear Air Cycles"
# Wave 25: throw-range multiplier in TENTHS (30 Crown base / +10 per range
# pollen flag = 30/40/50), recomputed 1s in crown_apply, applied at the throw
# edge by spear_boost (fresh-trident Motion scale).
scoreboard objectives add ec.jv_spear_range dummy "Bough JV Spear Range"
# Wave 25: throw edge-latch — 0 (armed) while the javelin is in mainhand,
# burned to 1 on the first empty-mainhand tick after spear_boost fires once.
scoreboard objectives add ec.jv_throw_l dummy "Bough JV Throw Latch"
# Wave 14 (pollen consumer): +1.0x Skyspear throw range while
# ec.pollen_sc_fisher is owned. Derived by bough/pollen_tick (single writer).
# LIVE since Wave 25: read at bough/javelin/crown_apply (range recompute).
scoreboard objectives add ec.jv_pln_range dummy "Bough JV Pollen Range Bonus"
# Wave 17 (pollen consumer): +1.0x more Skyspear throw range while
# ec.pollen_hp_pass is owned. Derived by bough/pollen_tick (single writer).
# LIVE since Wave 25: read at bough/javelin/crown_apply (range recompute).
scoreboard objectives add ec.jv_pln_pass dummy "Bough JV Pollen Pass Range"
scoreboard objectives add ec.jv_n_c1 dummy "JV C1"
scoreboard objectives add ec.jv_n_c2 dummy "JV C2"
scoreboard objectives add ec.jv_n_c3 dummy "JV C3"
scoreboard objectives add ec.jv_n_c4 dummy "JV C4"
scoreboard objectives add ec.jv_n_c5 dummy "JV C5"
scoreboard objectives add ec.jv_n_c6 dummy "JV C6"
scoreboard objectives add ec.jv_n_c7 dummy "JV C7"
scoreboard objectives add ec.jv_n_c8 dummy "JV C8"
scoreboard objectives add ec.jv_n_c9 dummy "JV C9"
scoreboard objectives add ec.jv_n_c10 dummy "JV C10"
scoreboard objectives add ec.jv_n_c11 dummy "JV C11"
scoreboard objectives add ec.jv_n_c12 dummy "JV C12"
scoreboard objectives add ec.jv_n_u1 dummy "JV U1"
scoreboard objectives add ec.jv_n_u2 dummy "JV U2"
scoreboard objectives add ec.jv_n_u3 dummy "JV U3"
scoreboard objectives add ec.jv_n_u4 dummy "JV U4"
scoreboard objectives add ec.jv_n_u5 dummy "JV U5"
scoreboard objectives add ec.jv_n_u6 dummy "JV U6"
scoreboard objectives add ec.jv_n_u7 dummy "JV U7"
scoreboard objectives add ec.jv_n_u8 dummy "JV U8"
scoreboard objectives add ec.jv_n_u9 dummy "JV U9"
scoreboard objectives add ec.jv_n_u10 dummy "JV U10"
scoreboard objectives add ec.jv_n_u11 dummy "JV U11"
scoreboard objectives add ec.jv_n_u12 dummy "JV U12"
scoreboard objectives add ec.jv_n_m1 dummy "JV M1"
scoreboard objectives add ec.jv_n_m2 dummy "JV M2"
scoreboard objectives add ec.jv_n_m3 dummy "JV M3"
scoreboard objectives add ec.jv_n_m4 dummy "JV M4"
scoreboard objectives add ec.jv_n_m5 dummy "JV M5"
# Mastery consumers (Wave 37): HP probe + M4 cooldown.
scoreboard objectives add ec.jv_hp dummy "JV HP Probe"
scoreboard objectives add ec.jv_m4_cd dummy "JV M4 Cooldown"
# Skirmish (combat-tree rewrite 2026-06-21): solo skirmisher aura (foe control/DoT + mobility
# buffs + Riftspear execute + Spearstorm capstone). Engine = skirmish/tick → pulse. C1/C3
# attributes (bough_jv_c1/c3) stripped on unequip in artifacts/javelin/remove.
scoreboard objectives add ec.jv_storm_cd dummy "JV Spearstorm CD"
# PERMANENT account-wide perks + lvl 1/6/12 milestones (util-tree rewrite 2026-06-21).
scoreboard objectives add ec.jv_phealth dummy "JV Perk HP Probe"
scoreboard objectives add ec.jv_msn1 dummy "JV Milestone 1 Seen"
scoreboard objectives add ec.jv_msn6 dummy "JV Milestone 6 Seen"
scoreboard objectives add ec.jv_msn12 dummy "JV Milestone 12 Seen"
# War-prep abilities (2026-06-22): one armed mode at a time + shared recovery cooldown.
scoreboard objectives add ec.jv_abil_id dummy "JV War-Prep Mode"
scoreboard objectives add ec.jv_abil_dur dummy "JV War-Prep Duration"
scoreboard objectives add ec.jv_abil_cd dummy "JV War-Prep Cooldown"
schedule function evercraft:bough/javelin/crown_tick 20t
schedule function evercraft:bough/javelin/mastery_tick 20t
schedule function evercraft:bough/javelin/skirmish/tick 20t
schedule function evercraft:bough/javelin/perks/tick 20t
schedule function evercraft:bough/javelin/abilities/tick 20t
