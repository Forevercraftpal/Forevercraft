# === BOUGH JAVELIN — CROWN REMOVE ===
# Clears the Skyspear flags (incl. the Wave 25 tenths range multiplier — the
# spear_boost hook gates on ec.jv_spear_range 1.., so zeroing kills the boost)
# and strips the melee-damage modifier from @s. Idempotent.
scoreboard players set @s ec.jv_spear_infinite 0
scoreboard players set @s ec.jv_spear_range 0
attribute @s minecraft:attack_damage modifier remove evercraft:long_throw_melee
