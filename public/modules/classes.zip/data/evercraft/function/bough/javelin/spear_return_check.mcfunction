# === BOUGH JAVELIN — SKYSPEAR INFINITE RETURN · CHECK (Wave 34, 1s) ===
# Run as @s = an ec.jv_inf-tagged thrown javelin trident, at @s, scanned from
# crown_tick (above the no-owner early-return, so the loop keeps serving
# spears whose thrower has since switched weapons / lost the Crown).
#
# Return condition — any of:
#   inGround:1b     — landed (catches the 60s in-ground despawn well early)
#   dealtDamage:1b  — struck a target (vanilla Loyalty returns on hit too)
#   6 airborne 1s cycles — failsafe for never-landing states (water columns,
#   slow 5x arcs); ec.jv_air only ticks while the spear's chunk is loaded, so
#   a spear frozen in unloaded chunks simply returns when it loads back in
#   (documented engine limit — entities outside simulation don't exist to @e).
scoreboard players add @s ec.jv_air 1
execute unless entity @s[nbt={inGround:1b}] unless entity @s[nbt={dealtDamage:1b}] unless score @s ec.jv_air matches 6.. run return 0

# Owner resolution: trident's stamped uid → the matching player (the spirit
# ec.sp_owner reverse-lookup idiom). Death-screen players are gated out on
# LIVE entity Health (the @a death-screen law) — a dead owner's spear waits
# and returns to their respawn position next cycle, not their corpse. Owner
# offline → tag stays, retry next cycle; the spear waits where it lies.
# ec.jv_ret_now is exclusive: the as-@e loop in crown_tick fully processes
# one spear before the next iteration, and the tag dies with the kill in
# spear_return_give (the remove below is the owner-offline/dead path only).
scoreboard players operation #jv_ret ec.temp = @s ec.jv_owner
tag @s add ec.jv_ret_now
execute as @a unless data entity @s {Health:0.0f} if score @s ec.jv_uid = #jv_ret ec.temp at @s run function evercraft:bough/javelin/spear_return_give
tag @s remove ec.jv_ret_now
