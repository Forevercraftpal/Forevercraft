# === BOUGH JAVELIN — SKIRMISH PULSE ===
# @s = a Javelin (ec.jv_active) with >=1 combat point, at @s. Solo skirmisher value: foe
# control/DoT + mobility self-buffs + execute + capstone. Radius 4/5/8. C1/C3 attributes
# reconciled in skirmish/tick.
# --- FOE CONTROL / DoT (C5 Whirlwind Throw Slowness ≤4 · C8 Storm Spear Glowing ≤5 · C6 Piercing Strike 1 magic/s ≤4) ---
execute if score @s ec.jv_n_c5 matches 1.. run effect give @e[type=#evercraft:hostile_mobs,distance=..4] minecraft:slowness 2 0 true
execute if score @s ec.jv_n_c8 matches 1.. run effect give @e[type=#evercraft:hostile_mobs,distance=..5] minecraft:glowing 2 0 true
tag @s add jv.skirmish_src
execute if score @s ec.jv_n_c6 matches 1.. as @e[type=#evercraft:hostile_mobs,distance=..4] run damage @s 1 minecraft:magic by @e[tag=jv.skirmish_src,limit=1,sort=nearest]
tag @s remove jv.skirmish_src

# --- EXECUTE (C9 Riftspear): wounded foes ≤4 are run through ---
execute if score @s ec.jv_n_c9 matches 1.. as @e[type=#evercraft:hostile_mobs,distance=..4] run function evercraft:bough/javelin/skirmish/execute

# --- SELF (C4 Quick Throw Speed · C7 Trident's Wrath Strength · C10 Spear Cascade Regen · C11 Throwblade Speed II+Strength) — while a foe is near ---
execute if score @s ec.jv_n_c4 matches 1.. if entity @e[type=#evercraft:hostile_mobs,distance=..6] run effect give @s minecraft:speed 2 0 true
execute if score @s ec.jv_n_c7 matches 1.. if entity @e[type=#evercraft:hostile_mobs,distance=..6] run effect give @s minecraft:strength 2 0 true
execute if score @s ec.jv_n_c10 matches 1.. if entity @e[type=#evercraft:hostile_mobs,distance=..6] run effect give @s minecraft:regeneration 2 0 true
execute if score @s ec.jv_n_c11 matches 1.. if entity @e[type=#evercraft:hostile_mobs,distance=..8] run effect give @s minecraft:speed 2 1 true
execute if score @s ec.jv_n_c11 matches 1.. if entity @e[type=#evercraft:hostile_mobs,distance=..8] run effect give @s minecraft:strength 2 0 true

# --- SPEARSTORM capstone (C12): every 30s near a foe, a storm of spears ---
execute if score @s ec.jv_n_c12 matches 1.. if score @s ec.jv_storm_cd matches ..0 if entity @e[type=#evercraft:hostile_mobs,distance=..6] run function evercraft:bough/javelin/skirmish/spearstorm
