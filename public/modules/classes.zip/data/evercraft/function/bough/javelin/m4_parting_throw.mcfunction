# === BOUGH JAVELIN — M4 PARTING THROW (Wave 37, mastery_tick branch) ===
# Pivot: spec's "auto-throw skyspear at attacker on lethal hit" needs damage
# interception + attacker reference that the engine doesn't expose. Player-
# side replacement: below 30% HP → Strength II + Speed I 5s, 60s cooldown.
# The parting throw is the smith's last breath.
effect give @s minecraft:strength 5 1 true
effect give @s minecraft:speed 5 0 true
title @s actionbar [{text:"⚔ Parting Throw ",color:"aqua",bold:true},{text:"— one last spear",color:"gray",italic:true}]
execute as @a[distance=..16] if score @s ec.fx_snd matches 1.. run playsound minecraft:item.trident.throw master @s ~ ~ ~ 0.6 1.2
scoreboard players set @s ec.jv_m4_cd 60
