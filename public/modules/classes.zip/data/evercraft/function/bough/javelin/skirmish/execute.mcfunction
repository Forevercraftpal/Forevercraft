# === BOUGH JAVELIN — RIFTSPEAR EXECUTE (C9) ===
# @s = a hostile foe within 4 of a Riftspear javelin (jv.skirmish_src). Run it through if
# wounded (Health ≤6). Clears HurtTime so the strike lands through the aura's fresh i-frames.
execute store result score #jv_fhp ec.temp run data get entity @s Health 1
execute if score #jv_fhp ec.temp matches 1..6 run data modify entity @s HurtTime set value 0s
execute if score #jv_fhp ec.temp matches 1..6 run damage @s 4 minecraft:magic by @e[tag=jv.skirmish_src,limit=1,sort=nearest]
