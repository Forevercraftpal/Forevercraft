# === BOUGH JAVELIN — SKIRMISH TICK (1s) ===
# Runs skirmish/pulse for any Javelin (tag ec.jv_active) with >=1 combat point. C1 melee and C3
# attack-speed are reconciled here (active-gated; stripped on unequip in artifacts/javelin/
# remove). C12 Spearstorm cooldown burns here. Does NOT touch the Crown Skyspear throw.
execute unless entity @a[tag=ec.jv_active,scores={ec.jv_b_combat=1..}] run return run schedule function evercraft:bough/javelin/skirmish/tick 20t
scoreboard players remove @a[scores={ec.jv_storm_cd=1..}] ec.jv_storm_cd 1

# C1 Spear Throw (+2 spear damage).
execute as @a[scores={ec.jv_n_c1=1..},tag=ec.jv_active] run attribute @s minecraft:attack_damage modifier remove evercraft:bough_jv_c1
execute as @a[scores={ec.jv_n_c1=1..},tag=ec.jv_active] run attribute @s minecraft:attack_damage modifier add evercraft:bough_jv_c1 2 add_value
execute as @a unless score @s ec.jv_n_c1 matches 1.. run attribute @s minecraft:attack_damage modifier remove evercraft:bough_jv_c1
execute as @a[tag=!ec.jv_active] run attribute @s minecraft:attack_damage modifier remove evercraft:bough_jv_c1

# C3 Trident Mastery (+10% attack speed).
execute as @a[scores={ec.jv_n_c3=1..},tag=ec.jv_active] run attribute @s minecraft:attack_speed modifier remove evercraft:bough_jv_c3
execute as @a[scores={ec.jv_n_c3=1..},tag=ec.jv_active] run attribute @s minecraft:attack_speed modifier add evercraft:bough_jv_c3 0.1 add_multiplied_base
execute as @a unless score @s ec.jv_n_c3 matches 1.. run attribute @s minecraft:attack_speed modifier remove evercraft:bough_jv_c3
execute as @a[tag=!ec.jv_active] run attribute @s minecraft:attack_speed modifier remove evercraft:bough_jv_c3

execute as @a[tag=ec.jv_active,scores={ec.jv_b_combat=1..}] at @s run function evercraft:bough/javelin/skirmish/pulse
schedule function evercraft:bough/javelin/skirmish/tick 20t
