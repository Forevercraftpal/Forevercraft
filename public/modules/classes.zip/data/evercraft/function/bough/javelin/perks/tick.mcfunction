# === BOUGH JAVELIN — UTILITY PERK TICK (1s) ===
# Utility scoping (2026-06-22): U1/U6/U12 (non-pollen) are ACCOUNT-WIDE (multiclass reward);
# every other utility node applies ONLY while this class is active. Pollen nodes also carry an
# active-gated SOLO buff (their multiplayer synergy stays in bough/pollen/<pfx>). Gate: any javelin progress
# (ec.jv_lvl>=1). Theme = the skirmisher (mobility + a caster's luck + sturdiness) — re-themed
# off the old aquatic tree. Attribute perks: remove-for-all then add-for-owners. Pollen U4/U6
# untouched.
execute unless entity @a[scores={ec.jv_lvl=1..}] run return run schedule function evercraft:bough/javelin/perks/tick 20t

# --- MOVEMENT (U3 Fleet · U5 Swift · U12 Skyward Reach = +5% each) ---
execute as @a[scores={ec.jv_lvl=1..}] run attribute @s minecraft:movement_speed modifier remove evercraft:jv_perk_u3
execute as @a[tag=ec.jv_active,scores={ec.jv_n_u3=1..}] run attribute @s minecraft:movement_speed modifier add evercraft:jv_perk_u3 0.05 add_multiplied_base
execute as @a[scores={ec.jv_lvl=1..}] run attribute @s minecraft:movement_speed modifier remove evercraft:jv_perk_u5
execute as @a[tag=ec.jv_active,scores={ec.jv_n_u5=1..}] run attribute @s minecraft:movement_speed modifier add evercraft:jv_perk_u5 0.05 add_multiplied_base

# --- GATHER (U1 Spear-fisher Luck I · U10 Spear Master Luck I) ---
execute as @a[scores={ec.jv_n_u1=1..}] unless score @s ec.jv_n_u10 matches 1.. run effect give @s minecraft:luck 2 0 true
execute as @a[tag=ec.jv_active,scores={ec.jv_n_u10=1..}] run effect give @s minecraft:luck 2 0 true

# --- KNOCKBACK RESISTANCE (U7 Sure-Footed · U9 Anchored = +0.2 each) ---
execute as @a[scores={ec.jv_lvl=1..}] run attribute @s minecraft:knockback_resistance modifier remove evercraft:jv_perk_u7
execute as @a[tag=ec.jv_active,scores={ec.jv_n_u7=1..}] run attribute @s minecraft:knockback_resistance modifier add evercraft:jv_perk_u7 0.2 add_value
execute as @a[scores={ec.jv_lvl=1..}] run attribute @s minecraft:knockback_resistance modifier remove evercraft:jv_perk_u9
execute as @a[tag=ec.jv_active,scores={ec.jv_n_u9=1..}] run attribute @s minecraft:knockback_resistance modifier add evercraft:jv_perk_u9 0.2 add_value

# --- HEALTH (U2 Hardy · U8 Stalwart · U11 Vigor · U12 Skyward Reach = +1 heart each) ---
execute as @a[scores={ec.jv_lvl=1..}] run attribute @s minecraft:max_health modifier remove evercraft:jv_perk_u2
execute as @a[tag=ec.jv_active,scores={ec.jv_n_u2=1..}] run attribute @s minecraft:max_health modifier add evercraft:jv_perk_u2 2 add_value
execute as @a[scores={ec.jv_lvl=1..}] run attribute @s minecraft:max_health modifier remove evercraft:jv_perk_u8
execute as @a[tag=ec.jv_active,scores={ec.jv_n_u8=1..}] run attribute @s minecraft:max_health modifier add evercraft:jv_perk_u8 2 add_value
execute as @a[scores={ec.jv_lvl=1..}] run attribute @s minecraft:max_health modifier remove evercraft:jv_perk_u11
execute as @a[tag=ec.jv_active,scores={ec.jv_n_u11=1..}] run attribute @s minecraft:max_health modifier add evercraft:jv_perk_u11 2 add_value
execute as @a[scores={ec.jv_lvl=1..}] run attribute @s minecraft:max_health modifier remove evercraft:jv_perk_u12
execute as @a[scores={ec.jv_n_u12=1..}] run attribute @s minecraft:max_health modifier add evercraft:jv_perk_u12 2 add_value
# U12 Skyward Reach capstone also grants +5% movement speed.
execute as @a[scores={ec.jv_lvl=1..}] run attribute @s minecraft:movement_speed modifier remove evercraft:jv_perk_u12s
execute as @a[scores={ec.jv_n_u12=1..}] run attribute @s minecraft:movement_speed modifier add evercraft:jv_perk_u12s 0.05 add_multiplied_base


# === POLLEN SOLO BUFFS (active-gated) — multiplayer synergy stays in bough/pollen/jv ===
execute as @a[scores={ec.jv_lvl=1..}] run attribute @s minecraft:attack_speed modifier remove evercraft:jv_pln_u4
execute as @a[tag=ec.jv_active,scores={ec.jv_n_u4=1..}] run attribute @s minecraft:attack_speed modifier add evercraft:jv_pln_u4 0.08 add_multiplied_base
execute as @a[scores={ec.jv_lvl=1..}] run attribute @s minecraft:movement_speed modifier remove evercraft:jv_pln_u6
execute as @a[tag=ec.jv_active,scores={ec.jv_n_u6=1..}] run attribute @s minecraft:movement_speed modifier add evercraft:jv_pln_u6 0.05 add_multiplied_base

# === MILESTONE PASSIVES (lvl 1/6/12, account-wide, skirmisher-thematic) ===
# Lvl 1 Skirmisher — +5% movement speed.
execute as @a[scores={ec.jv_lvl=1..}] run attribute @s minecraft:movement_speed modifier remove evercraft:jv_ms1
execute as @a[scores={ec.jv_lvl=1..}] run attribute @s minecraft:movement_speed modifier add evercraft:jv_ms1 0.05 add_multiplied_base
# Lvl 6 Seasoned — +1 heart.
execute as @a[scores={ec.jv_lvl=6..}] run attribute @s minecraft:max_health modifier remove evercraft:jv_ms6
execute as @a[scores={ec.jv_lvl=6..}] run attribute @s minecraft:max_health modifier add evercraft:jv_ms6 2 add_value
# Lvl 12 Spearmaster — +1 heart + Luck I.
execute as @a[scores={ec.jv_lvl=12..}] run attribute @s minecraft:max_health modifier remove evercraft:jv_ms12
execute as @a[scores={ec.jv_lvl=12..}] run attribute @s minecraft:max_health modifier add evercraft:jv_ms12 2 add_value
execute as @a[scores={ec.jv_lvl=12..}] unless score @s ec.jv_n_u1 matches 1.. unless score @s ec.jv_n_u10 matches 1.. run effect give @s minecraft:luck 2 0 true

# Milestone unlock chat (one-time each)
execute as @a[scores={ec.jv_lvl=1..}] unless score @s ec.jv_msn1 matches 1 run tellraw @s [{text:"✦ Javelin Mastery 1 — ",color:"gray"},{text:"Skirmisher",color:"white",bold:true},{text:" unlocked. +movement speed. Permanent, all classes.",color:"gray"}]
scoreboard players set @a[scores={ec.jv_lvl=1..}] ec.jv_msn1 1
execute as @a[scores={ec.jv_lvl=6..}] unless score @s ec.jv_msn6 matches 1 run tellraw @s [{text:"✦ Javelin Mastery 6 — ",color:"gray"},{text:"Seasoned",color:"white",bold:true},{text:" unlocked. +1 heart. Permanent, all classes.",color:"gray"}]
scoreboard players set @a[scores={ec.jv_lvl=6..}] ec.jv_msn6 1
execute as @a[scores={ec.jv_lvl=12..}] unless score @s ec.jv_msn12 matches 1 run tellraw @s [{text:"✦ Javelin Mastery 12 — ",color:"gray"},{text:"Spearmaster",color:"white",bold:true},{text:" unlocked. +1 heart and Luck. Permanent, all classes.",color:"gray"}]
scoreboard players set @a[scores={ec.jv_lvl=12..}] ec.jv_msn12 1

schedule function evercraft:bough/javelin/perks/tick 20t
