# === BOUGH CODEX — UNIVERSAL BRANCH BUTTON SCAN (macro) ===
# Hub-page combat/utility buttons. Routes right-click to per-class view setters
# and left-click to canned descriptions.
# Usage: function evercraft:bough/codex/check_branch_btns {cls_path:"dancer"}

$execute as @e[type=interaction,tag=ec.bough_btn_combat,distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s interaction on target run function evercraft:bough/codex/$(cls_path)/click_view_combat
execute as @e[type=interaction,tag=ec.bough_btn_combat,distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=ec.bough_btn_combat,distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Combat Branch",b:"Twelve nodes from Iron to Mythril. Right-click to open."}
execute as @e[type=interaction,tag=ec.bough_btn_combat,distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s attack run data remove entity @s attack

$execute as @e[type=interaction,tag=ec.bough_btn_util,distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s interaction on target run function evercraft:bough/codex/$(cls_path)/click_view_util
execute as @e[type=interaction,tag=ec.bough_btn_util,distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=ec.bough_btn_util,distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Utility Branch",b:"Twelve support and survival nodes. Right-click to open."}
execute as @e[type=interaction,tag=ec.bough_btn_util,distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s attack run data remove entity @s attack
