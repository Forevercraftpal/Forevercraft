# === BOUGH CODEX — READOUT STAT EXPLAINERS (shared) ===
# Left-click the Lvl / XP / Pts / Pool readout chips -> a chat card explaining each.
# Class-agnostic (ec.bough_stat_* tags). Called from every class check_clicks_hub.
# Needs #bough_cc_sess (set by the dispatcher / hub before calling).
execute as @e[type=interaction,tag=ec.bough_stat_lvl,distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Class Level",b:"Earned by USING this class. Each Level grants a Bough Point and unlocks higher node tiers."}
execute as @e[type=interaction,tag=ec.bough_stat_lvl,distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=ec.bough_stat_xp,distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Mastery XP",b:"Your progress toward the next Class Level."}
execute as @e[type=interaction,tag=ec.bough_stat_xp,distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=ec.bough_stat_pts,distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Bough Points",b:"Spend these on nodes in this tree. You earn 1 per Class Level."}
execute as @e[type=interaction,tag=ec.bough_stat_pts,distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=ec.bough_stat_pool,distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Shared Pool",b:"A slice of all your gains; it slowly levels your OTHER classes (cross-training)."}
execute as @e[type=interaction,tag=ec.bough_stat_pool,distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s attack run data remove entity @s attack