scoreboard players operation #bough_cc_sess ec.temp = @s ec.bough_sess
function evercraft:bough/codex/check_stat_btns
function evercraft:bough/codex/check_mast_node {cls:"tk",tier:"myth",cost:"1",node:"m1",label_short:"Tank Mastery",label_full:"M1 Tank Mastery",tier_full:"Mythril",desc:"While Tank is active, gain +1 armor passively. ⚡ Right-click to arm Ironhide — Resistance II, 60s active · 60s cooldown."}
function evercraft:bough/codex/check_mast_node {cls:"tk",tier:"myth",cost:"1",node:"m2",label_short:"Anvil Skin",label_full:"M2 Anvil Skin",tier_full:"Mythril",desc:"Below 50% HP, gain Resistance I. The anvil hardens. ⚡ Right-click to arm Anvil — Resistance I, 60s active · 60s cooldown."}
function evercraft:bough/codex/check_mast_node {cls:"tk",tier:"anci",cost:"1",node:"m3",label_short:"Foundation",label_full:"M3 Foundation",tier_full:"Ancient",desc:"5% chance per kill to grant +200 Mastery XP. ⚡ Right-click to arm Foundation — Resistance I (rooted), 45s active · 10s cooldown."}
function evercraft:bough/codex/check_mast_node {cls:"tk",tier:"anci",cost:"1",node:"m4",label_short:"Tower Stands",label_full:"M4 Tower Stands",tier_full:"Ancient",desc:"Below 30% HP, gain Resistance V + Absorption for 3s. 60s cooldown. Immovable. ⚡ Right-click to arm Tower Stands — Resistance III + Absorption II, 30s active · 40s cooldown."}
function evercraft:bough/codex/check_mast_node {cls:"tk",tier:"anci",cost:"1",node:"m5",label_short:"Crown's Anvil",label_full:"M5 Crown's Anvil",tier_full:"Ancient",desc:"While Tank is active, gain +1 armor passively. The anvil thickens. ✦ Right-click to arm Crown's Anvil (CROSS-CLASS ultimate) — Resistance + Absorption, lasts 5 min, 180s cooldown."}
function evercraft:bough/codex/check_crown_node {cls_path:"tank",crown_name:"Bulwark",cost_line:"Level 50 · 10 Mastery pts",effect_line:"At full HP: knockback immune, Resistance III.",permanence:"Healing is 50% slower. Until Reroot."}
function evercraft:bough/codex/check_branch_btns {cls_path:"tank"}

# ===== REROOT (Wave 26 — Soul-Echo, 2-click confirm; cls_id 12 = Tank) =====
execute as @e[type=interaction,tag=ec.bough_btn_reroot,distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s interaction on target run function evercraft:bough/reroot/confirm {cls_id:12}
execute as @e[type=interaction,tag=ec.bough_btn_reroot,distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=ec.bough_btn_reroot,distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Reroot (Soul-Echo)",b:"Wipes all nodes and refunds your spent points. Right-click twice within 5s to commit."}
execute as @e[type=interaction,tag=ec.bough_btn_reroot,distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s attack run data remove entity @s attack
# ===== RESONANCE (Wave 36 — balance readout; left-click = what is Resonance) =====
execute as @e[type=interaction,tag=ec.bough_btn_resonance,distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s interaction on target run function evercraft:bough/resonance/show {cls:"tk",class_name:"Tank",color:"blue"}
execute as @e[type=interaction,tag=ec.bough_btn_resonance,distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=ec.bough_btn_resonance,distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s attack on attacker run function evercraft:bough/resonance/info
execute as @e[type=interaction,tag=ec.bough_btn_resonance,distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s attack run data remove entity @s attack

# ===== RESONANCE LABEL RE-PAINT (Wave 36b — reflects hub spends without waiting for a rebuild) =====
function evercraft:bough/resonance/paint_label {cls:"tk",color:"blue"}
