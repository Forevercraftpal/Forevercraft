scoreboard players set @s ec.sc_bough_view 1
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:item.book.page_turn master @s ~ ~ ~ 0.7 1.4
