# === BOUGH LUMBERFELL — REFINE SUB-PAGE (internal: utility view) ===
# Layout: low numbers (U1-U6) on player's LEFT (+X), high (U7-U12) on RIGHT (-X).
# ✿ = Pollen Anchor (U1 Forester / U7 Forest Pact / U11 Heartfall Pact).

execute positioned ^ ^1.40 ^ run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["ec.bough_el","ec.bough_class_lf"],billboard:"center",text:{text:"Lumberfell",color:"dark_green",bold:true},background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.46f,0.46f,0.46f]}}
execute positioned ^ ^1.18 ^ run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["ec.bough_el","ec.bough_class_lf"],billboard:"center",text:{text:"✎  Refine",color:"green",bold:true},background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.40f,0.40f,0.40f]}}

$execute positioned ^ ^1.00 ^ run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["ec.bough_el","ec.bough_class_lf","ec.bough_dyn"],billboard:"center",text:[{text:"Lvl  ",color:"gray"},{text:"$(lvl)",color:"yellow"},{text:"      XP  ",color:"gray"},{text:"$(xp)",color:"aqua"},{text:"      Pts  ",color:"gray"},{text:"$(pts)",color:"light_purple"}],background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.28f,0.28f,0.28f]}}

execute positioned ^0.70 ^0.70 ^ run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["ec.bough_el","ec.bough_class_lf"],billboard:"center",text:{text:"── Iron / Steel ──",color:"gray",italic:true},background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.24f,0.24f,0.24f]}}
execute positioned ^-0.70 ^0.70 ^ run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["ec.bough_el","ec.bough_class_lf"],billboard:"center",text:{text:"── Steel / Myth ──",color:"gray",italic:true},background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.24f,0.24f,0.24f]}}

# === LEFT COLUMN (U1-U6) ===
execute positioned ^0.70 ^0.50 ^ run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["ec.bough_el","ec.bough_class_lf","ec.bn_u1"],billboard:"center",text:[{text:"U1 ",color:"yellow",bold:true},{text:"✿ ",color:"gold"},{text:"Forester",color:"white"}],background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.26f,0.26f,0.26f]}}
# [strip] wide hitbox split into codex-style shallow cubes
execute positioned ^0.3812 ^0.50 ^-0.02 run summon interaction ~ ~ ~ {Tags:["ec.bough_el","ec.bough_class_lf","ec.bough_node_u1"],width:0.2125f,height:0.16f,response:1b}
execute positioned ^0.5938 ^0.50 ^-0.02 run summon interaction ~ ~ ~ {Tags:["ec.bough_el","ec.bough_class_lf","ec.bough_node_u1"],width:0.2125f,height:0.16f,response:1b}
execute positioned ^0.8062 ^0.50 ^-0.02 run summon interaction ~ ~ ~ {Tags:["ec.bough_el","ec.bough_class_lf","ec.bough_node_u1"],width:0.2125f,height:0.16f,response:1b}
execute positioned ^1.0188 ^0.50 ^-0.02 run summon interaction ~ ~ ~ {Tags:["ec.bough_el","ec.bough_class_lf","ec.bough_node_u1"],width:0.2125f,height:0.16f,response:1b}
execute positioned ^0.70 ^0.30 ^ run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["ec.bough_el","ec.bough_class_lf","ec.bn_u2"],billboard:"center",text:[{text:"U2 ",color:"yellow",bold:true},{text:"Sap-cart",color:"white"}],background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.26f,0.26f,0.26f]}}
# [strip] wide hitbox split into codex-style shallow cubes
execute positioned ^0.3812 ^0.30 ^-0.02 run summon interaction ~ ~ ~ {Tags:["ec.bough_el","ec.bough_class_lf","ec.bough_node_u2"],width:0.2125f,height:0.16f,response:1b}
execute positioned ^0.5938 ^0.30 ^-0.02 run summon interaction ~ ~ ~ {Tags:["ec.bough_el","ec.bough_class_lf","ec.bough_node_u2"],width:0.2125f,height:0.16f,response:1b}
execute positioned ^0.8062 ^0.30 ^-0.02 run summon interaction ~ ~ ~ {Tags:["ec.bough_el","ec.bough_class_lf","ec.bough_node_u2"],width:0.2125f,height:0.16f,response:1b}
execute positioned ^1.0188 ^0.30 ^-0.02 run summon interaction ~ ~ ~ {Tags:["ec.bough_el","ec.bough_class_lf","ec.bough_node_u2"],width:0.2125f,height:0.16f,response:1b}
execute positioned ^0.70 ^0.10 ^ run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["ec.bough_el","ec.bough_class_lf","ec.bn_u3"],billboard:"center",text:[{text:"U3 ",color:"yellow",bold:true},{text:"Tree Eye",color:"white"}],background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.26f,0.26f,0.26f]}}
# [strip] wide hitbox split into codex-style shallow cubes
execute positioned ^0.3812 ^0.10 ^-0.02 run summon interaction ~ ~ ~ {Tags:["ec.bough_el","ec.bough_class_lf","ec.bough_node_u3"],width:0.2125f,height:0.16f,response:1b}
execute positioned ^0.5938 ^0.10 ^-0.02 run summon interaction ~ ~ ~ {Tags:["ec.bough_el","ec.bough_class_lf","ec.bough_node_u3"],width:0.2125f,height:0.16f,response:1b}
execute positioned ^0.8062 ^0.10 ^-0.02 run summon interaction ~ ~ ~ {Tags:["ec.bough_el","ec.bough_class_lf","ec.bough_node_u3"],width:0.2125f,height:0.16f,response:1b}
execute positioned ^1.0188 ^0.10 ^-0.02 run summon interaction ~ ~ ~ {Tags:["ec.bough_el","ec.bough_class_lf","ec.bough_node_u3"],width:0.2125f,height:0.16f,response:1b}
execute positioned ^0.70 ^-0.10 ^ run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["ec.bough_el","ec.bough_class_lf","ec.bn_u4"],billboard:"center",text:[{text:"U4 ",color:"yellow",bold:true},{text:"Sure Step",color:"white"}],background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.26f,0.26f,0.26f]}}
# [strip] wide hitbox split into codex-style shallow cubes
execute positioned ^0.3812 ^-0.10 ^-0.02 run summon interaction ~ ~ ~ {Tags:["ec.bough_el","ec.bough_class_lf","ec.bough_node_u4"],width:0.2125f,height:0.16f,response:1b}
execute positioned ^0.5938 ^-0.10 ^-0.02 run summon interaction ~ ~ ~ {Tags:["ec.bough_el","ec.bough_class_lf","ec.bough_node_u4"],width:0.2125f,height:0.16f,response:1b}
execute positioned ^0.8062 ^-0.10 ^-0.02 run summon interaction ~ ~ ~ {Tags:["ec.bough_el","ec.bough_class_lf","ec.bough_node_u4"],width:0.2125f,height:0.16f,response:1b}
execute positioned ^1.0188 ^-0.10 ^-0.02 run summon interaction ~ ~ ~ {Tags:["ec.bough_el","ec.bough_class_lf","ec.bough_node_u4"],width:0.2125f,height:0.16f,response:1b}
execute positioned ^0.70 ^-0.30 ^ run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["ec.bough_el","ec.bough_class_lf","ec.bn_u5"],billboard:"center",text:[{text:"U5 ",color:"aqua",bold:true},{text:"Axemark",color:"white"}],background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.26f,0.26f,0.26f]}}
# [strip] wide hitbox split into codex-style shallow cubes
execute positioned ^0.3812 ^-0.30 ^-0.02 run summon interaction ~ ~ ~ {Tags:["ec.bough_el","ec.bough_class_lf","ec.bough_node_u5"],width:0.2125f,height:0.16f,response:1b}
execute positioned ^0.5938 ^-0.30 ^-0.02 run summon interaction ~ ~ ~ {Tags:["ec.bough_el","ec.bough_class_lf","ec.bough_node_u5"],width:0.2125f,height:0.16f,response:1b}
execute positioned ^0.8062 ^-0.30 ^-0.02 run summon interaction ~ ~ ~ {Tags:["ec.bough_el","ec.bough_class_lf","ec.bough_node_u5"],width:0.2125f,height:0.16f,response:1b}
execute positioned ^1.0188 ^-0.30 ^-0.02 run summon interaction ~ ~ ~ {Tags:["ec.bough_el","ec.bough_class_lf","ec.bough_node_u5"],width:0.2125f,height:0.16f,response:1b}
execute positioned ^0.70 ^-0.50 ^ run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["ec.bough_el","ec.bough_class_lf","ec.bn_u6"],billboard:"center",text:[{text:"U6 ",color:"aqua",bold:true},{text:"Charburn",color:"white"}],background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.26f,0.26f,0.26f]}}
# [strip] wide hitbox split into codex-style shallow cubes
execute positioned ^0.3812 ^-0.50 ^-0.02 run summon interaction ~ ~ ~ {Tags:["ec.bough_el","ec.bough_class_lf","ec.bough_node_u6"],width:0.2125f,height:0.16f,response:1b}
execute positioned ^0.5938 ^-0.50 ^-0.02 run summon interaction ~ ~ ~ {Tags:["ec.bough_el","ec.bough_class_lf","ec.bough_node_u6"],width:0.2125f,height:0.16f,response:1b}
execute positioned ^0.8062 ^-0.50 ^-0.02 run summon interaction ~ ~ ~ {Tags:["ec.bough_el","ec.bough_class_lf","ec.bough_node_u6"],width:0.2125f,height:0.16f,response:1b}
execute positioned ^1.0188 ^-0.50 ^-0.02 run summon interaction ~ ~ ~ {Tags:["ec.bough_el","ec.bough_class_lf","ec.bough_node_u6"],width:0.2125f,height:0.16f,response:1b}

# === RIGHT COLUMN (U7-U12) ===
execute positioned ^-0.70 ^0.50 ^ run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["ec.bough_el","ec.bough_class_lf","ec.bn_u7"],billboard:"center",text:[{text:"U7 ",color:"aqua",bold:true},{text:"✿ ",color:"gold"},{text:"Forest Pact",color:"white"}],background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.26f,0.26f,0.26f]}}
# [strip] wide hitbox split into codex-style shallow cubes
execute positioned ^-1.0188 ^0.50 ^-0.02 run summon interaction ~ ~ ~ {Tags:["ec.bough_el","ec.bough_class_lf","ec.bough_node_u7"],width:0.2125f,height:0.16f,response:1b}
execute positioned ^-0.8063 ^0.50 ^-0.02 run summon interaction ~ ~ ~ {Tags:["ec.bough_el","ec.bough_class_lf","ec.bough_node_u7"],width:0.2125f,height:0.16f,response:1b}
execute positioned ^-0.5938 ^0.50 ^-0.02 run summon interaction ~ ~ ~ {Tags:["ec.bough_el","ec.bough_class_lf","ec.bough_node_u7"],width:0.2125f,height:0.16f,response:1b}
execute positioned ^-0.3812 ^0.50 ^-0.02 run summon interaction ~ ~ ~ {Tags:["ec.bough_el","ec.bough_class_lf","ec.bough_node_u7"],width:0.2125f,height:0.16f,response:1b}
execute positioned ^-0.70 ^0.30 ^ run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["ec.bough_el","ec.bough_class_lf","ec.bn_u8"],billboard:"center",text:[{text:"U8 ",color:"aqua",bold:true},{text:"Lucky Find",color:"white"}],background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.26f,0.26f,0.26f]}}
# [strip] wide hitbox split into codex-style shallow cubes
execute positioned ^-1.0188 ^0.30 ^-0.02 run summon interaction ~ ~ ~ {Tags:["ec.bough_el","ec.bough_class_lf","ec.bough_node_u8"],width:0.2125f,height:0.16f,response:1b}
execute positioned ^-0.8063 ^0.30 ^-0.02 run summon interaction ~ ~ ~ {Tags:["ec.bough_el","ec.bough_class_lf","ec.bough_node_u8"],width:0.2125f,height:0.16f,response:1b}
execute positioned ^-0.5938 ^0.30 ^-0.02 run summon interaction ~ ~ ~ {Tags:["ec.bough_el","ec.bough_class_lf","ec.bough_node_u8"],width:0.2125f,height:0.16f,response:1b}
execute positioned ^-0.3812 ^0.30 ^-0.02 run summon interaction ~ ~ ~ {Tags:["ec.bough_el","ec.bough_class_lf","ec.bough_node_u8"],width:0.2125f,height:0.16f,response:1b}
execute positioned ^-0.70 ^0.10 ^ run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["ec.bough_el","ec.bough_class_lf","ec.bn_u9"],billboard:"center",text:[{text:"U9 ",color:"light_purple",bold:true},{text:"Forest Master",color:"white"}],background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.26f,0.26f,0.26f]}}
# [strip] wide hitbox split into codex-style shallow cubes
execute positioned ^-1.0188 ^0.10 ^-0.02 run summon interaction ~ ~ ~ {Tags:["ec.bough_el","ec.bough_class_lf","ec.bough_node_u9"],width:0.2125f,height:0.16f,response:1b}
execute positioned ^-0.8063 ^0.10 ^-0.02 run summon interaction ~ ~ ~ {Tags:["ec.bough_el","ec.bough_class_lf","ec.bough_node_u9"],width:0.2125f,height:0.16f,response:1b}
execute positioned ^-0.5938 ^0.10 ^-0.02 run summon interaction ~ ~ ~ {Tags:["ec.bough_el","ec.bough_class_lf","ec.bough_node_u9"],width:0.2125f,height:0.16f,response:1b}
execute positioned ^-0.3812 ^0.10 ^-0.02 run summon interaction ~ ~ ~ {Tags:["ec.bough_el","ec.bough_class_lf","ec.bough_node_u9"],width:0.2125f,height:0.16f,response:1b}
execute positioned ^-0.70 ^-0.10 ^ run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["ec.bough_el","ec.bough_class_lf","ec.bn_u10"],billboard:"center",text:[{text:"U10 ",color:"light_purple",bold:true},{text:"Hardy",color:"white"}],background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.26f,0.26f,0.26f]}}
# [strip] wide hitbox split into codex-style shallow cubes
execute positioned ^-1.0188 ^-0.10 ^-0.02 run summon interaction ~ ~ ~ {Tags:["ec.bough_el","ec.bough_class_lf","ec.bough_node_u10"],width:0.2125f,height:0.16f,response:1b}
execute positioned ^-0.8063 ^-0.10 ^-0.02 run summon interaction ~ ~ ~ {Tags:["ec.bough_el","ec.bough_class_lf","ec.bough_node_u10"],width:0.2125f,height:0.16f,response:1b}
execute positioned ^-0.5938 ^-0.10 ^-0.02 run summon interaction ~ ~ ~ {Tags:["ec.bough_el","ec.bough_class_lf","ec.bough_node_u10"],width:0.2125f,height:0.16f,response:1b}
execute positioned ^-0.3812 ^-0.10 ^-0.02 run summon interaction ~ ~ ~ {Tags:["ec.bough_el","ec.bough_class_lf","ec.bough_node_u10"],width:0.2125f,height:0.16f,response:1b}
execute positioned ^-0.70 ^-0.30 ^ run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["ec.bough_el","ec.bough_class_lf","ec.bn_u11"],billboard:"center",text:[{text:"U11 ",color:"light_purple",bold:true},{text:"✿ ",color:"gold"},{text:"Heartfall Pact",color:"white"}],background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.26f,0.26f,0.26f]}}
# [strip] wide hitbox split into codex-style shallow cubes
execute positioned ^-1.0188 ^-0.30 ^-0.02 run summon interaction ~ ~ ~ {Tags:["ec.bough_el","ec.bough_class_lf","ec.bough_node_u11"],width:0.2125f,height:0.16f,response:1b}
execute positioned ^-0.8063 ^-0.30 ^-0.02 run summon interaction ~ ~ ~ {Tags:["ec.bough_el","ec.bough_class_lf","ec.bough_node_u11"],width:0.2125f,height:0.16f,response:1b}
execute positioned ^-0.5938 ^-0.30 ^-0.02 run summon interaction ~ ~ ~ {Tags:["ec.bough_el","ec.bough_class_lf","ec.bough_node_u11"],width:0.2125f,height:0.16f,response:1b}
execute positioned ^-0.3812 ^-0.30 ^-0.02 run summon interaction ~ ~ ~ {Tags:["ec.bough_el","ec.bough_class_lf","ec.bough_node_u11"],width:0.2125f,height:0.16f,response:1b}
execute positioned ^-0.70 ^-0.50 ^ run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["ec.bough_el","ec.bough_class_lf","ec.bn_u12"],billboard:"center",text:[{text:"U12 ",color:"light_purple",bold:true},{text:"Greensong",color:"white"}],background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.26f,0.26f,0.26f]}}
# [strip] wide hitbox split into codex-style shallow cubes
execute positioned ^-1.0188 ^-0.50 ^-0.02 run summon interaction ~ ~ ~ {Tags:["ec.bough_el","ec.bough_class_lf","ec.bough_node_u12"],width:0.2125f,height:0.16f,response:1b}
execute positioned ^-0.8063 ^-0.50 ^-0.02 run summon interaction ~ ~ ~ {Tags:["ec.bough_el","ec.bough_class_lf","ec.bough_node_u12"],width:0.2125f,height:0.16f,response:1b}
execute positioned ^-0.5938 ^-0.50 ^-0.02 run summon interaction ~ ~ ~ {Tags:["ec.bough_el","ec.bough_class_lf","ec.bough_node_u12"],width:0.2125f,height:0.16f,response:1b}
execute positioned ^-0.3812 ^-0.50 ^-0.02 run summon interaction ~ ~ ~ {Tags:["ec.bough_el","ec.bough_class_lf","ec.bough_node_u12"],width:0.2125f,height:0.16f,response:1b}

# --- COUNTER ---
$execute positioned ^ ^-0.80 ^ run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["ec.bough_el","ec.bough_class_lf","ec.bough_dyn"],billboard:"center",text:[{text:"Refine  ",color:"gray"},{text:"$(bu)",color:"green"},{text:"/12 owned",color:"dark_gray"}],background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.28f,0.28f,0.28f]}}

# --- DESCRIPTION PANEL ---
execute positioned ^ ^-1.10 ^ run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["ec.bough_el","ec.bough_class_lf","ec.bough_dyn"],billboard:"center",text:{nbt:"info",storage:"evercraft:bough",interpret:true,separator:"\n"},background:1073741824,shadow:1b,line_width:200,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.28f,0.28f,0.28f]}}

# --- BACK + CLOSE ---
execute positioned ^0.40 ^-1.50 ^ run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["ec.bough_el","ec.bough_class_lf"],billboard:"center",text:{text:"[ < Back ]",color:"yellow"},background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.28f,0.28f,0.28f]}}
# [strip] wide hitbox split into codex-style shallow cubes
execute positioned ^0.275 ^-1.50 ^-0.02 run summon interaction ~ ~ ~ {Tags:["ec.bough_el","ec.bough_class_lf","ec.bough_btn_back"],width:0.25f,height:0.15f,response:1b}
execute positioned ^0.525 ^-1.50 ^-0.02 run summon interaction ~ ~ ~ {Tags:["ec.bough_el","ec.bough_class_lf","ec.bough_btn_back"],width:0.25f,height:0.15f,response:1b}
execute positioned ^-0.40 ^-1.50 ^ run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["ec.bough_el","ec.bough_class_lf"],billboard:"center",text:{text:"[ Close ]",color:"yellow"},background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.28f,0.28f,0.28f]}}
# [strip] wide hitbox split into codex-style shallow cubes
execute positioned ^-0.525 ^-1.50 ^-0.02 run summon interaction ~ ~ ~ {Tags:["ec.bough_el","ec.bough_class_lf","ec.bough_close_btn"],width:0.25f,height:0.15f,response:1b}
execute positioned ^-0.275 ^-1.50 ^-0.02 run summon interaction ~ ~ ~ {Tags:["ec.bough_el","ec.bough_class_lf","ec.bough_close_btn"],width:0.25f,height:0.15f,response:1b}

# === HIGHLIGHT PASS (auto-generated by gen_bough_highlight.py) ===
# bought -> gold; affordable (not owned + level-gate met + >=1 pt) -> gold.
# runs at the class anchor (see spawn.mcfunction), so nearest-by-tag is class-scoped.
execute if score @s ec.lf_n_u1 matches 1.. run data modify entity @e[type=text_display,tag=ec.bn_u1,distance=..8,limit=1,sort=nearest] text set value [{text:"U1 ",color:"gold",bold:true},{text:"✿ ",color:"gold"},{text:"Forester",color:"gold"}]
execute if score @s ec.lf_n_u1 matches 0 if score @s ec.lf_pts matches 1.. if score @s ec.lf_lvl >= #b_gate_iron ec.const run data modify entity @e[type=text_display,tag=ec.bn_u1,distance=..8,limit=1,sort=nearest] text set value [{text:"U1 ",color:"gold",bold:true},{text:"✿ ",color:"gold"},{text:"Forester",color:"gold"}]
execute if score @s ec.lf_n_u2 matches 1.. run data modify entity @e[type=text_display,tag=ec.bn_u2,distance=..8,limit=1,sort=nearest] text set value [{text:"U2 ",color:"gold",bold:true},{text:"Sap-cart",color:"gold"}]
execute if score @s ec.lf_n_u2 matches 0 if score @s ec.lf_pts matches 1.. if score @s ec.lf_lvl >= #b_gate_iron ec.const run data modify entity @e[type=text_display,tag=ec.bn_u2,distance=..8,limit=1,sort=nearest] text set value [{text:"U2 ",color:"gold",bold:true},{text:"Sap-cart",color:"gold"}]
execute if score @s ec.lf_n_u3 matches 1.. run data modify entity @e[type=text_display,tag=ec.bn_u3,distance=..8,limit=1,sort=nearest] text set value [{text:"U3 ",color:"gold",bold:true},{text:"Tree Eye",color:"gold"}]
execute if score @s ec.lf_n_u3 matches 0 if score @s ec.lf_pts matches 1.. if score @s ec.lf_lvl >= #b_gate_iron ec.const run data modify entity @e[type=text_display,tag=ec.bn_u3,distance=..8,limit=1,sort=nearest] text set value [{text:"U3 ",color:"gold",bold:true},{text:"Tree Eye",color:"gold"}]
execute if score @s ec.lf_n_u4 matches 1.. run data modify entity @e[type=text_display,tag=ec.bn_u4,distance=..8,limit=1,sort=nearest] text set value [{text:"U4 ",color:"gold",bold:true},{text:"Sure Step",color:"gold"}]
execute if score @s ec.lf_n_u4 matches 0 if score @s ec.lf_pts matches 1.. if score @s ec.lf_lvl >= #b_gate_iron ec.const run data modify entity @e[type=text_display,tag=ec.bn_u4,distance=..8,limit=1,sort=nearest] text set value [{text:"U4 ",color:"gold",bold:true},{text:"Sure Step",color:"gold"}]
execute if score @s ec.lf_n_u5 matches 1.. run data modify entity @e[type=text_display,tag=ec.bn_u5,distance=..8,limit=1,sort=nearest] text set value [{text:"U5 ",color:"gold",bold:true},{text:"Axemark",color:"gold"}]
execute if score @s ec.lf_n_u5 matches 0 if score @s ec.lf_pts matches 1.. if score @s ec.lf_lvl >= #b_gate_steel ec.const run data modify entity @e[type=text_display,tag=ec.bn_u5,distance=..8,limit=1,sort=nearest] text set value [{text:"U5 ",color:"gold",bold:true},{text:"Axemark",color:"gold"}]
execute if score @s ec.lf_n_u6 matches 1.. run data modify entity @e[type=text_display,tag=ec.bn_u6,distance=..8,limit=1,sort=nearest] text set value [{text:"U6 ",color:"gold",bold:true},{text:"Charburn",color:"gold"}]
execute if score @s ec.lf_n_u6 matches 0 if score @s ec.lf_pts matches 1.. if score @s ec.lf_lvl >= #b_gate_steel ec.const run data modify entity @e[type=text_display,tag=ec.bn_u6,distance=..8,limit=1,sort=nearest] text set value [{text:"U6 ",color:"gold",bold:true},{text:"Charburn",color:"gold"}]
execute if score @s ec.lf_n_u7 matches 1.. run data modify entity @e[type=text_display,tag=ec.bn_u7,distance=..8,limit=1,sort=nearest] text set value [{text:"U7 ",color:"gold",bold:true},{text:"✿ ",color:"gold"},{text:"Forest Pact",color:"gold"}]
execute if score @s ec.lf_n_u7 matches 0 if score @s ec.lf_pts matches 1.. if score @s ec.lf_lvl >= #b_gate_steel ec.const run data modify entity @e[type=text_display,tag=ec.bn_u7,distance=..8,limit=1,sort=nearest] text set value [{text:"U7 ",color:"gold",bold:true},{text:"✿ ",color:"gold"},{text:"Forest Pact",color:"gold"}]
execute if score @s ec.lf_n_u8 matches 1.. run data modify entity @e[type=text_display,tag=ec.bn_u8,distance=..8,limit=1,sort=nearest] text set value [{text:"U8 ",color:"gold",bold:true},{text:"Lucky Find",color:"gold"}]
execute if score @s ec.lf_n_u8 matches 0 if score @s ec.lf_pts matches 1.. if score @s ec.lf_lvl >= #b_gate_steel ec.const run data modify entity @e[type=text_display,tag=ec.bn_u8,distance=..8,limit=1,sort=nearest] text set value [{text:"U8 ",color:"gold",bold:true},{text:"Lucky Find",color:"gold"}]
execute if score @s ec.lf_n_u9 matches 1.. run data modify entity @e[type=text_display,tag=ec.bn_u9,distance=..8,limit=1,sort=nearest] text set value [{text:"U9 ",color:"gold",bold:true},{text:"Forest Master",color:"gold"}]
execute if score @s ec.lf_n_u9 matches 0 if score @s ec.lf_pts matches 1.. if score @s ec.lf_lvl >= #b_gate_myth ec.const run data modify entity @e[type=text_display,tag=ec.bn_u9,distance=..8,limit=1,sort=nearest] text set value [{text:"U9 ",color:"gold",bold:true},{text:"Forest Master",color:"gold"}]
execute if score @s ec.lf_n_u10 matches 1.. run data modify entity @e[type=text_display,tag=ec.bn_u10,distance=..8,limit=1,sort=nearest] text set value [{text:"U10 ",color:"gold",bold:true},{text:"Hardy",color:"gold"}]
execute if score @s ec.lf_n_u10 matches 0 if score @s ec.lf_pts matches 1.. if score @s ec.lf_lvl >= #b_gate_myth ec.const run data modify entity @e[type=text_display,tag=ec.bn_u10,distance=..8,limit=1,sort=nearest] text set value [{text:"U10 ",color:"gold",bold:true},{text:"Hardy",color:"gold"}]
execute if score @s ec.lf_n_u11 matches 1.. run data modify entity @e[type=text_display,tag=ec.bn_u11,distance=..8,limit=1,sort=nearest] text set value [{text:"U11 ",color:"gold",bold:true},{text:"✿ ",color:"gold"},{text:"Heartfall Pact",color:"gold"}]
execute if score @s ec.lf_n_u11 matches 0 if score @s ec.lf_pts matches 1.. if score @s ec.lf_lvl >= #b_gate_myth ec.const run data modify entity @e[type=text_display,tag=ec.bn_u11,distance=..8,limit=1,sort=nearest] text set value [{text:"U11 ",color:"gold",bold:true},{text:"✿ ",color:"gold"},{text:"Heartfall Pact",color:"gold"}]
execute if score @s ec.lf_n_u12 matches 1.. run data modify entity @e[type=text_display,tag=ec.bn_u12,distance=..8,limit=1,sort=nearest] text set value [{text:"U12 ",color:"gold",bold:true},{text:"Greensong",color:"gold"}]
execute if score @s ec.lf_n_u12 matches 0 if score @s ec.lf_pts matches 1.. if score @s ec.lf_lvl >= #b_gate_myth ec.const run data modify entity @e[type=text_display,tag=ec.bn_u12,distance=..8,limit=1,sort=nearest] text set value [{text:"U12 ",color:"gold",bold:true},{text:"Greensong",color:"gold"}]
