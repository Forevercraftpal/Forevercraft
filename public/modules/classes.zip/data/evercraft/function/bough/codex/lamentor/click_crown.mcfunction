# Owned Crown → right-click toggles the Silkwoven vow instead of "already owned".
execute if score @s ec.lm_b_crown matches 1.. run function evercraft:bough/lamentor/crown_toggle
execute if score @s ec.lm_b_crown matches 1.. run return 0
function evercraft:bough/codex/click_crown_generic {cls:"lm",crown_name:"Silkwoven",color_hex:"light_purple"}
