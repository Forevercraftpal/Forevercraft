scoreboard players operation #bough_cc_sess ec.temp = @s ec.bough_sess
function evercraft:bough/codex/check_stat_btns
function evercraft:bough/codex/check_mast_node {cls:"kt",tier:"myth",cost:"1",node:"m1",label_short:"Honor Mastery",label_full:"M1 Honor Mastery",tier_full:"Mythril",desc:"While Knight is active, attack damage +5%. The trained wrist waits. ⚡ Right-click to arm Honorbound — Strength II, 60s active · 60s cooldown."}
function evercraft:bough/codex/check_mast_node {cls:"kt",tier:"myth",cost:"1",node:"m2",label_short:"Code Duello",label_full:"M2 Code Duello",tier_full:"Mythril",desc:"While Knight is active, attack speed +5%. The duelist's tempo. ⚡ Right-click to arm Code Duello — Speed + Strength, 60s active · 60s cooldown."}
function evercraft:bough/codex/check_mast_node {cls:"kt",tier:"anci",cost:"1",node:"m3",label_short:"Honor Read",label_full:"M3 Honor Read",tier_full:"Ancient",desc:"5% chance per kill to grant +200 Mastery XP. ⚡ Right-click to arm Honor Read — Speed II, 45s active · 10s cooldown."}
function evercraft:bough/codex/check_mast_node {cls:"kt",tier:"anci",cost:"1",node:"m4",label_short:"Death Before Dishonor",label_full:"M4 Death Before Dishonor",tier_full:"Ancient",desc:"Below 30% HP, gain Resistance II + Strength II for 5s. 60s cooldown. Honor's last breath. ⚡ Right-click to arm Death Before Dishonor — Resistance III + Strength II, 30s active · 40s cooldown."}
function evercraft:bough/codex/check_mast_node {cls:"kt",tier:"anci",cost:"1",node:"m5",label_short:"Crown's Honor",label_full:"M5 Crown's Honor",tier_full:"Ancient",desc:"While Knight is active, gain +1 armor passively. ✦ Right-click to arm Crown's Honor (CROSS-CLASS ultimate) — Strength + Resistance, lasts 5 min, 180s cooldown."}
function evercraft:bough/codex/check_crown_node {cls_path:"knight",crown_name:"Riposte",cost_line:"Level 50 · 10 Mastery pts",effect_line:"Perfectly-timed parries reflect 100% damage.",permanence:"Only one healing artifact allowed (hotbar slot 9). Until Reroot."}
function evercraft:bough/codex/check_branch_btns {cls_path:"knight"}

# ===== REROOT (Wave 26 — Soul-Echo, 2-click confirm; cls_id 13 = Knight) =====
execute as @e[type=interaction,tag=ec.bough_btn_reroot,distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s interaction on target run function evercraft:bough/reroot/confirm {cls_id:13}
execute as @e[type=interaction,tag=ec.bough_btn_reroot,distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=ec.bough_btn_reroot,distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Reroot (Soul-Echo)",b:"Wipes all nodes and refunds your spent points. Right-click twice within 5s to commit."}
execute as @e[type=interaction,tag=ec.bough_btn_reroot,distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s attack run data remove entity @s attack
# ===== RESONANCE (Wave 36 — balance readout; left-click = what is Resonance) =====
execute as @e[type=interaction,tag=ec.bough_btn_resonance,distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s interaction on target run function evercraft:bough/resonance/show {cls:"kt",class_name:"Knight",color:"gold"}
execute as @e[type=interaction,tag=ec.bough_btn_resonance,distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=ec.bough_btn_resonance,distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s attack on attacker run function evercraft:bough/resonance/info
execute as @e[type=interaction,tag=ec.bough_btn_resonance,distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s attack run data remove entity @s attack

# ===== RESONANCE LABEL RE-PAINT (Wave 36b — reflects hub spends without waiting for a rebuild) =====
function evercraft:bough/resonance/paint_label {cls:"kt",color:"gold"}
