# === BOUGH CODEX — OPEN CLASS DISPATCHER ===
# Run as @s = the player. Reads ec.bough_pending_cls (set by the codex
# tree_click handler) and opens the matching class's bough page.
#
# All 13 visible classes (1-13) are full, working page-opens. Dual Swordsman
# (class 14) is the hidden 14th class: it routes here too, but ONLY when
# ec.bough_pending_cls=14 is produced by the spoiler-gated DS card in the
# Page-1 grid (the card renders only for tag=ec.ds_discovered holders).
# open_dual_swordsman carries its own ec.ds_discovered backstop, so a routed
# 14 from any other source is a silent no-op.

# First-time tutorial (one-shot via ec.bough_reroot_seen — Wave 37, 2026-06-12).
function evercraft:bough/codex/reroot_tutorial

# 1. Rogue — Crown: Long Knife  (fully authored)
execute if score @s ec.bough_pending_cls matches 1 run function evercraft:bough/codex/open_rogue

# 2. Berserker — Crown: Wrathblood  (fully authored)
execute if score @s ec.bough_pending_cls matches 2 run function evercraft:bough/codex/open_berserker

# 3. Dancer — Crown: Cloudstep
execute if score @s ec.bough_pending_cls matches 3 run function evercraft:bough/codex/open_dancer

# 4. Striker — Crown: Earthbreak
execute if score @s ec.bough_pending_cls matches 4 run function evercraft:bough/codex/open_striker

# 5. Sentinel — Crown: Standfast
execute if score @s ec.bough_pending_cls matches 5 run function evercraft:bough/codex/open_sentinel

# 6. Healer — Crown: Lifebound
execute if score @s ec.bough_pending_cls matches 6 run function evercraft:bough/codex/open_healer

# 7. Beastlord — Crown: Pack Lord
execute if score @s ec.bough_pending_cls matches 7 run function evercraft:bough/codex/open_beastlord

# 8. Javelin — Crown: Skyspear
execute if score @s ec.bough_pending_cls matches 8 run function evercraft:bough/codex/open_javelin

# 9. Hoplite — Crown: Phalanx
execute if score @s ec.bough_pending_cls matches 9 run function evercraft:bough/codex/open_hoplite

# 10. Archer — Crown: Hawk Eye
execute if score @s ec.bough_pending_cls matches 10 run function evercraft:bough/codex/open_archer

# 11. Hunter — Crown: Mark of Death
execute if score @s ec.bough_pending_cls matches 11 run function evercraft:bough/codex/open_hunter

# 12. Tank — Crown: Bulwark
execute if score @s ec.bough_pending_cls matches 12 run function evercraft:bough/codex/open_tank

# 13. Knight — Crown: Riposte (Fencer)
execute if score @s ec.bough_pending_cls matches 13 run function evercraft:bough/codex/open_knight

# 14. Dual Swordsman — Crown: Bladestorm (hidden 14th class; spoiler-gated)
execute if score @s ec.bough_pending_cls matches 14 run function evercraft:bough/codex/open_dual_swordsman

# Soft page-turn cue for every open EXCEPT Berserker (which plays its own cue
# in open_berserker). Not a stub marker — no class is a stub.
execute unless score @s ec.bough_pending_cls matches 2 if score @s ec.fx_snd matches 1.. run playsound minecraft:item.book.page_turn master @s ~ ~ ~ 0.5 0.9

# Reset the pending slot.
scoreboard players set @s ec.bough_pending_cls 0
