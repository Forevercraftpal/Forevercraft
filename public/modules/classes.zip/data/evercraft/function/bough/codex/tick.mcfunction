# === BOUGH CODEX — TICK (2t) ===
# Self-rescheduling 2t loop. Catches clicks, auto-closes off-anchor viewers, and
# rebuilds a clicked page IN PLACE at its fixed anchor. The page is ANCHORED — it
# no longer follows the player's line of sight (like the Craftforever codex). The
# anchor marker keeps its open-time position + yaw; only clicks trigger a rebuild.
#
# rotated ~ 0 on click detection keeps caret math on a clean horizontal frame.

execute unless entity @a[tag=ec.bough_viewing] run return run schedule function evercraft:bough/codex/tick 2t

# 1. Mark dirty ONLY on a RIGHT-click (interaction) — a purchase/view-switch
#    changes the page, so it must rebuild. LEFT-clicks (attack) are info-only:
#    they no longer flag dirty, so reading a node never flickers the page; the
#    info shows as an actionbar tooltip instead (see bough/info). check_clicks
#    still runs every tick and consumes the attack data.
execute as @a[tag=ec.bough_viewing] at @s if entity @e[type=interaction,tag=ec.bough_el,distance=..6,nbt={interaction:{}}] run scoreboard players set @s ec.bough_dirty 1

# 1b. Bough doesn't route clicks through fx/ui/click, so reset its menu idle timer here on any
#     click (right OR left) so cleanup/menu_idle never closes a bough page that's being used.
execute as @a[tag=ec.bough_viewing] at @s if entity @e[type=interaction,tag=ec.bough_el,distance=..6,nbt={interaction:{}}] run scoreboard players set @s ec.menu_idle 0
execute as @a[tag=ec.bough_viewing] at @s if entity @e[type=interaction,tag=ec.bough_el,distance=..6,nbt={attack:{}}] run scoreboard players set @s ec.menu_idle 0

# 2. Click detection — processes clicks (purchase / view-switch / info / close).
execute as @a[tag=ec.bough_viewing] at @s rotated ~ 0 run function evercraft:bough/codex/check_clicks

# 3. Close pages whose viewer walked off THEIR OWN anchor (>6 blocks from the fixed
#    anchor with a MATCHING ec.bough_sess). Session-aware (BO-P2-CLOSE 2026-06-22):
#    the old "any ec.bough_anchor within 6" test left a viewer orphaned when they
#    wandered off their own anchor but stayed near another viewer's anchor.
execute as @a[tag=ec.bough_viewing] at @s run function evercraft:bough/codex/close_check

# 4. Rebuild any dirty page in place at its fixed anchor, then clear the flag.
execute as @a[tag=ec.bough_viewing] at @s if score @s ec.bough_dirty matches 1 run function evercraft:bough/codex/rebuild
scoreboard players set @a[tag=ec.bough_viewing] ec.bough_dirty 0

schedule function evercraft:bough/codex/tick 2t
