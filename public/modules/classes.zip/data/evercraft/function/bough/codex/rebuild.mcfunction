# === BOUGH CODEX — REBUILD PAGE IN PLACE (2026-06-14) ===
# Run as @s = the viewer, at @s. Kills this session's page entities and re-renders
# at the EXISTING anchor marker (which keeps its open-time position+yaw — the page
# no longer tracks the player's line of sight; it's anchored like the Craftforever
# codex). Called from codex/tick when ec.bough_dirty is set by a click.
# The anchor marker is NOT touched, so the page stays fixed where it opened.

scoreboard players operation #rb_sess ec.temp = @s ec.bough_sess
# Kill the page CONTENT but spare the background panel (ec.bough_bg) so the page
# rebuilds smoothly inside the same backdrop instead of flashing closed/open.
execute as @e[tag=ec.bough_el,tag=!ec.bough_bg] if score @s ec.bough_sess = #rb_sess ec.temp run kill @s

# Re-render via the class's spawn dispatcher (it anchors at @e[bough_anchor_<cls>]).
execute if entity @s[tag=ec.bough_class_bk] run function evercraft:bough/codex/berserker/spawn
execute if entity @s[tag=ec.bough_class_rg] run function evercraft:bough/codex/rogue/spawn
execute if entity @s[tag=ec.bough_class_dn] run function evercraft:bough/codex/dancer/spawn
execute if entity @s[tag=ec.bough_class_sk] run function evercraft:bough/codex/striker/spawn
execute if entity @s[tag=ec.bough_class_sn] run function evercraft:bough/codex/sentinel/spawn
execute if entity @s[tag=ec.bough_class_hl] run function evercraft:bough/codex/healer/spawn
execute if entity @s[tag=ec.bough_class_bl] run function evercraft:bough/codex/beastlord/spawn
execute if entity @s[tag=ec.bough_class_jv] run function evercraft:bough/codex/javelin/spawn
execute if entity @s[tag=ec.bough_class_hp] run function evercraft:bough/codex/hoplite/spawn
execute if entity @s[tag=ec.bough_class_ar] run function evercraft:bough/codex/archer/spawn
execute if entity @s[tag=ec.bough_class_ht] run function evercraft:bough/codex/hunter/spawn
execute if entity @s[tag=ec.bough_class_tk] run function evercraft:bough/codex/tank/spawn
execute if entity @s[tag=ec.bough_class_kt] run function evercraft:bough/codex/knight/spawn
execute if entity @s[tag=ec.bough_class_ds] run function evercraft:bough/codex/dual_swordsman/spawn
execute if entity @s[tag=ec.bough_class_ss] run function evercraft:bough/codex/stonestrike/spawn
execute if entity @s[tag=ec.bough_class_lf] run function evercraft:bough/codex/lumberfell/spawn
execute if entity @s[tag=ec.bough_class_gs] run function evercraft:bough/codex/growseer/spawn
execute if entity @s[tag=ec.bough_class_tw] run function evercraft:bough/codex/terrawarp/spawn
execute if entity @s[tag=ec.bough_class_sc] run function evercraft:bough/codex/sirencall/spawn
execute if entity @s[tag=ec.bough_class_lm] run function evercraft:bough/codex/lamentor/spawn
execute if entity @s[tag=ec.bough_class_gw] run function evercraft:bough/codex/gearwright/spawn
