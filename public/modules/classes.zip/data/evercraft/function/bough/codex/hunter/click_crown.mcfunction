function evercraft:bough/codex/click_crown_generic {cls:"ht",crown_name:"Mark of Death",color_hex:"aqua"}
