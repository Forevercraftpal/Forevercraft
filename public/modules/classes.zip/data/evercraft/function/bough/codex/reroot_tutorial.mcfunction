# === BOUGH CODEX — REROOT FIRST-WARNING TUTORIAL ===
# Run as @s = the player. Fires once per player when they first open ANY bough hub
# (combat or crafting). One-shot via the persistent ec.bough_reroot_seen scoreboard
# (no advancement — survives /reload, doesn't survive Pioneer wipe by design).
#
# The Reroot button sits at ^-0.80 ^-1.40 on every hub (Wave 27). Without this
# tutorial a curious player could right-click it twice without realizing it
# clears all their node choices for that class (points are refunded, not lost).

# Already seen the tutorial → no-op.
execute if score @s ec.bough_reroot_seen matches 1.. run return 0

# Mark seen.
scoreboard players set @s ec.bough_reroot_seen 1

# Tutorial tellraw block.
tellraw @s [{text:"━━━━━━ ",color:"gray"},{text:"Welcome to the Bough",color:"#B87333",bold:true},{text:" ━━━━━━",color:"gray"}]
tellraw @s {text:"Each class has its own bough — a small tree of nodes you grow by spending Bough Points.",color:"gray"}
tellraw @s {text:" "}
tellraw @s [{text:"◈ Mastery",color:"gold",bold:true},{text:" — USE the class to earn XP; each Level grants a Bough Point. The hub button shows your Level, XP and Points.",color:"gray"}]
tellraw @s [{text:"⚑ Crown",color:"gold",bold:true},{text:" — the apex node of each bough, unlocked at Level 50. Permanent vow, can only be undone by Reroot.",color:"gray"}]
tellraw @s [{text:"☘ Soul-Echo Reroot",color:"dark_red",bold:true},{text:" — the bottom button. Click ",color:"gray"},{text:"twice within 5 seconds",color:"red"},{text:" to confirm. Reroot ",color:"gray"},{text:"clears every node for that class and refunds all your Bough Points",color:"red",bold:true},{text:" to respend. Your Level and XP are kept.",color:"gray"}]
tellraw @s {text:" "}
tellraw @s {text:"This message will only appear once.",color:"dark_gray",italic:true}

# Soft chime so the player notices.
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:item.book.put master @s ~ ~ ~ 0.7 1.0
