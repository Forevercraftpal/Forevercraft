# Owned Crown → right-click toggles the Tinkermind vow instead of "already owned".
execute if score @s ec.gw_b_crown matches 1.. run function evercraft:bough/gearwright/crown_toggle
execute if score @s ec.gw_b_crown matches 1.. run return 0
function evercraft:bough/codex/click_crown_generic {cls:"gw",crown_name:"Tinkermind",color_hex:"#FFA85C"}
