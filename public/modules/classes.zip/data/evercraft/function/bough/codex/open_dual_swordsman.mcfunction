# === BOUGH CODEX — OPEN DUAL SWORDSMAN (SPOILER-GATED) ===
# Dual Swordsman is the hidden 14th class. Players who have never activated it
# (dual_swordsman/detect sets the persistent ec.ds_discovered tag on first
# activation) must see NOTHING — silent no-op, no sound, no page. Do not
# remove or reorder this gate.
execute unless entity @s[tag=ec.ds_discovered] run return 0
execute if entity @s[tag=ec.bough_viewing] run function evercraft:bough/codex/close
scoreboard players add #bough_next_sess ec.var 1
scoreboard players operation @s ec.bough_sess = #bough_next_sess ec.var
scoreboard players set @s ec.ds_bough_view 0
data modify storage evercraft:bough info set value [{text:"Left-click any node for more info! ",color:"gray",italic:true},{text:"Right-click to purchase!",color:"gray",italic:true}]
tag @s add ec.bough_viewing
tag @s add ec.bough_class_ds
# Per-opener session+yaw (BO-P1-RACE fix, 2026-06-21): summon the anchor with a
# transient unique tag, then source session + yaw from THE OPENER (@s) — NOT
# @p[distance=..3], which proximity-picks and lets two nearby DS openers steal
# each other's session. The opener is snapshotted to a fakeplayer + a transient
# self-tag so the uniquely-tagged marker reads only from this player.
scoreboard players operation #bough_ds_open ec.var = @s ec.bough_sess
tag @s add ec.bough_ds_opener
execute at @s anchored eyes rotated ~ 0 positioned ^ ^ ^2.0 run summon marker ~ ~ ~ {Tags:["ec.bough_anchor","ec.bough_anchor_ds","ec.bough_anchor_ds_new"]}
execute as @e[type=marker,tag=ec.bough_anchor_ds_new,limit=1] run scoreboard players operation @s ec.bough_sess = #bough_ds_open ec.var
execute as @e[type=marker,tag=ec.bough_anchor_ds_new,limit=1] run data modify entity @s Rotation[0] set from entity @p[tag=ec.bough_ds_opener,limit=1] Rotation[0]
execute at @e[type=marker,tag=ec.bough_anchor_ds_new,limit=1] run function evercraft:bough/codex/spawn_bg {cls:"ds"}
tag @s remove ec.bough_ds_opener
tag @e[type=marker,tag=ec.bough_anchor_ds_new] remove ec.bough_anchor_ds_new
function evercraft:bough/codex/dual_swordsman/spawn
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:item.book.page_turn master @s ~ ~ ~ 0.7 1.2
