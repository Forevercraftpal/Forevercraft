# === BOUGH CODEX — OPEN BERSERKER PAGE ===
# Run as @s = the player. Opens the Berserker bough at the Hub view.

# Reject if already viewing — close current page first, then re-open.
execute if entity @s[tag=ec.bough_viewing] run function evercraft:bough/codex/close

# Assign a fresh session id so entity selectors don't collide with prior pages.
scoreboard players add #bough_next_sess ec.var 1
scoreboard players operation @s ec.bough_sess = #bough_next_sess ec.var

# Reset view to Hub. Sub-page navigation is via the in-page branch buttons.
scoreboard players set @s ec.bk_bough_view 0

# Reset the description panel to the hint message.
data modify storage evercraft:bough info set value [{text:"Left-click any node for more info! ",color:"gray",italic:true},{text:"Right-click to purchase!",color:"gray",italic:true}]

# Stamp viewer tag — click tick now picks this player up.
tag @s add ec.bough_viewing
tag @s add ec.bough_class_bk

# Anchor: a marker 2 blocks in front of @s at eye height.
execute at @s anchored eyes rotated ~ 0 positioned ^ ^ ^2.0 run summon marker ~ ~ ~ {Tags:["ec.bough_anchor","ec.bough_anchor_bk"]}
execute as @e[type=marker,tag=ec.bough_anchor_bk,limit=1,sort=nearest] run scoreboard players operation @s ec.bough_sess = @p[distance=..3] ec.bough_sess
# Bake the opening yaw into the marker (pitch stays 0) so the whole page lays out
# squared-up to the player instead of along world axes — fixes the diagonal/off-
# center sub-pages, slanted Mastery/Reroot buttons, and sideways M-node rows.
execute as @e[type=marker,tag=ec.bough_anchor_bk,limit=1,sort=nearest] run data modify entity @s Rotation[0] set from entity @p[distance=..3] Rotation[0]

# Background panel — spawned ONCE here (not in spawn) so it persists across view
# switches and rebuilds; only the inner content swaps, for a smooth no-flash feel.
execute at @e[type=marker,tag=ec.bough_anchor_bk,limit=1,sort=nearest] run function evercraft:bough/codex/spawn_bg {cls:"bk"}

# Spawn (dispatches based on ec.bk_bough_view).
function evercraft:bough/codex/berserker/spawn

# Soft open cue.
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:item.book.page_turn master @s ~ ~ ~ 0.7 1.2
