scoreboard players operation #bough_cc_sess ec.temp = @s ec.bough_sess
function evercraft:bough/codex/check_stat_btns
function evercraft:bough/codex/check_mast_node {cls:"lm",tier:"myth",cost:"1",node:"m1",label_short:"Silkroot",label_full:"M1 Silkroot",tier_full:"Mythril",desc:"Shearing 50 wool in 10 minutes grants Speed I for 5 minutes."}
function evercraft:bough/codex/check_mast_node {cls:"lm",tier:"myth",cost:"1",node:"m2",label_short:"Silkmend",label_full:"M2 Silkmend",tier_full:"Mythril",desc:"Shears auto-repair at noon if string is in your inventory."}
function evercraft:bough/codex/check_mast_node {cls:"lm",tier:"anci",cost:"1",node:"m3",label_short:"Silk Listen",label_full:"M3 Silk Listen",tier_full:"Ancient",desc:"Crafting a champion banner reveals all sheep within 10 blocks."}
function evercraft:bough/codex/check_mast_node {cls:"lm",tier:"anci",cost:"1",node:"m4",label_short:"Last Shroud",label_full:"M4 Last Shroud",tier_full:"Ancient",desc:"If lethal HP, wrap yourself in a silk shroud (Resistance V 3s, knock yourself back 5 blocks). 1/min."}
function evercraft:bough/codex/check_mast_node {cls:"lm",tier:"anci",cost:"1",node:"m5",label_short:"Crown's Silkwoven",label_full:"M5 Crown's Silkwoven",tier_full:"Ancient",desc:"Silkwoven's doubling extends to bed/banner durability."}
function evercraft:bough/codex/check_crown_node {cls_path:"lamentor",crown_name:"Silkwoven",cost_line:"Level 50 · 10 Mastery pts",effect_line:"All cloth-tier crafting (wool, string, silk) yields are doubled. Banners crafted are unbreakable.",permanence:"You cannot dye items — no dye crafting, no dyed-block placement. Until Reroot."}
function evercraft:bough/codex/check_branch_btns {cls_path:"lamentor"}

# ===== REROOT (Wave 26 — Soul-Echo, 2-click confirm; cls_id 20 = Lamentor) =====
execute as @e[type=interaction,tag=ec.bough_btn_reroot,distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s interaction on target run function evercraft:bough/reroot/confirm {cls_id:20}
execute as @e[type=interaction,tag=ec.bough_btn_reroot,distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=ec.bough_btn_reroot,distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Reroot (Soul-Echo)",b:"Wipes all nodes and refunds your spent points. Right-click twice within 5s to commit."}
execute as @e[type=interaction,tag=ec.bough_btn_reroot,distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s attack run data remove entity @s attack
# ===== RESONANCE (Wave 36 — balance readout; left-click = what is Resonance) =====
execute as @e[type=interaction,tag=ec.bough_btn_resonance,distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s interaction on target run function evercraft:bough/resonance/show {cls:"lm",class_name:"Lamentor",color:"light_purple"}
execute as @e[type=interaction,tag=ec.bough_btn_resonance,distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=ec.bough_btn_resonance,distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s attack on attacker run function evercraft:bough/resonance/info
execute as @e[type=interaction,tag=ec.bough_btn_resonance,distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s attack run data remove entity @s attack

# ===== RESONANCE LABEL RE-PAINT (Wave 36b — reflects hub spends without waiting for a rebuild) =====
function evercraft:bough/resonance/paint_label {cls:"lm",color:"light_purple"}
