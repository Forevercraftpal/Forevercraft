scoreboard players operation #bough_sp_sess ec.temp = @s ec.bough_sess
execute if score @s ec.gw_bough_view matches 0 run function evercraft:bough/codex/gearwright/stage_hub_disp
execute if score @s ec.gw_bough_view matches 0 at @e[type=marker,tag=ec.bough_anchor_gw,limit=1,sort=nearest] run function evercraft:bough/codex/gearwright/spawn_hub_inner with storage evercraft:bough disp
execute if score @s ec.gw_bough_view matches 1 run function evercraft:bough/codex/gearwright/stage_hub_disp
execute if score @s ec.gw_bough_view matches 1 at @e[type=marker,tag=ec.bough_anchor_gw,limit=1,sort=nearest] run function evercraft:bough/codex/gearwright/spawn_combat_inner with storage evercraft:bough disp
execute if score @s ec.gw_bough_view matches 2 run function evercraft:bough/codex/gearwright/stage_hub_disp
execute if score @s ec.gw_bough_view matches 2 at @e[type=marker,tag=ec.bough_anchor_gw,limit=1,sort=nearest] run function evercraft:bough/codex/gearwright/spawn_utility_inner with storage evercraft:bough disp
execute as @e[tag=ec.bough_el,tag=ec.bough_class_gw] unless score @s ec.bough_sess matches 1.. run scoreboard players operation @s ec.bough_sess = #bough_sp_sess ec.temp

# Hub view: paint the Resonance button label (Wave 36b — gold ★ while any unspent Resonance).
execute if score @s ec.gw_bough_view matches 0 run function evercraft:bough/resonance/paint_label {cls:"gw",color:"#FFA85C"}
