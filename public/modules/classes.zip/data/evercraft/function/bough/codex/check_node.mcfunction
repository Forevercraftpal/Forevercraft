# === BOUGH CODEX — UNIVERSAL NODE CHECK (macro) ===
# Scans one node tag for right-click (spend) and left-click (info).
# Usage: function evercraft:bough/codex/check_node {cls:"rg",branch:"combat",tier:"iron",cost:"1",node:"c1",label_short:"Quick Blade",color_short:"red",label_full:"C1 Quick Blade",tier_full:"Iron",desc:"+1 attack speed with daggers."}
#
# Called from per-class check_clicks_combat/utility. Reads #bough_cc_sess from caller.

$execute as @e[type=interaction,tag=ec.bough_node_$(node),distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s interaction on target run function evercraft:bough/spend {cls:"$(cls)",branch:"$(branch)",tier:"$(tier)",cost:"$(cost)",node:"$(node)",label:"$(label_short)",color:"$(color_short)"}
$execute as @e[type=interaction,tag=ec.bough_node_$(node),distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s interaction run data remove entity @s interaction
$execute as @e[type=interaction,tag=ec.bough_node_$(node),distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s attack on attacker run function evercraft:bough/info {label:"$(label_full)",tier:"$(tier_full)",cost:"$(cost)",desc:"$(desc)"}
$execute as @e[type=interaction,tag=ec.bough_node_$(node),distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s attack run data remove entity @s attack
