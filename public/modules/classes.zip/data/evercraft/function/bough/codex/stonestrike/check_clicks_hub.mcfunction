scoreboard players operation #bough_cc_sess ec.temp = @s ec.bough_sess
function evercraft:bough/codex/check_stat_btns
function evercraft:bough/codex/check_mast_node {cls:"ss",tier:"myth",cost:"1",node:"m1",label_short:"Quarrysong",label_full:"M1 Quarrysong",tier_full:"Mythril",desc:"Every 50 ore mined grants Haste II for 60 seconds. The vein sings."}
function evercraft:bough/codex/check_mast_node {cls:"ss",tier:"myth",cost:"1",node:"m2",label_short:"Quarrysmith",label_full:"M2 Quarrysmith",tier_full:"Mythril",desc:"Every 60 stone-tier blocks mined grants +200 Mastery XP. The hand learns the weight of stone."}
function evercraft:bough/codex/check_mast_node {cls:"ss",tier:"anci",cost:"1",node:"m3",label_short:"Vein Echo",label_full:"M3 Vein Echo",tier_full:"Ancient",desc:"Mining an ore grants Night Vision for 10 seconds. The stone remembers its kin."}
function evercraft:bough/codex/check_mast_node {cls:"ss",tier:"anci",cost:"1",node:"m4",label_short:"Last Vein",label_full:"M4 Last Vein",tier_full:"Ancient",desc:"Below 30% HP while holding a pickaxe, gain Resistance I. The mountain shields its smith."}
function evercraft:bough/codex/check_mast_node {cls:"ss",tier:"anci",cost:"1",node:"m5",label_short:"Crown's Mountain",label_full:"M5 Crown's Mountain",tier_full:"Ancient",desc:"Veinkeeper's stone-tier bonus increases to +2 per block."}
function evercraft:bough/codex/check_crown_node {cls_path:"stonestrike",crown_name:"Veinkeeper",cost_line:"Level 50 · 10 Mastery pts",effect_line:"Ore drops pre-smelted; stone-tier blocks drop +1 stone.",permanence:"You cannot use furnaces or blast furnaces. Until Reroot."}
function evercraft:bough/codex/check_branch_btns {cls_path:"stonestrike"}

# ===== REROOT (Wave 26 — Soul-Echo, 2-click confirm; cls_id 15 = Stonestrike) =====
execute as @e[type=interaction,tag=ec.bough_btn_reroot,distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s interaction on target run function evercraft:bough/reroot/confirm {cls_id:15}
execute as @e[type=interaction,tag=ec.bough_btn_reroot,distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=ec.bough_btn_reroot,distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Reroot (Soul-Echo)",b:"Wipes all nodes and refunds your spent points. Right-click twice within 5s to commit."}
execute as @e[type=interaction,tag=ec.bough_btn_reroot,distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s attack run data remove entity @s attack
# ===== RESONANCE (Wave 36 — balance readout; left-click = what is Resonance) =====
execute as @e[type=interaction,tag=ec.bough_btn_resonance,distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s interaction on target run function evercraft:bough/resonance/show {cls:"ss",class_name:"Stonestrike",color:"gold"}
execute as @e[type=interaction,tag=ec.bough_btn_resonance,distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=ec.bough_btn_resonance,distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s attack on attacker run function evercraft:bough/resonance/info
execute as @e[type=interaction,tag=ec.bough_btn_resonance,distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s attack run data remove entity @s attack

# ===== RESONANCE LABEL RE-PAINT (Wave 36b — reflects hub spends without waiting for a rebuild) =====
function evercraft:bough/resonance/paint_label {cls:"ss",color:"gold"}
