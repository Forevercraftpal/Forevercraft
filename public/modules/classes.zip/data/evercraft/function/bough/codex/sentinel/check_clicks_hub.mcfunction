scoreboard players operation #bough_cc_sess ec.temp = @s ec.bough_sess
function evercraft:bough/codex/check_stat_btns
function evercraft:bough/codex/check_mast_node {cls:"sn",tier:"myth",cost:"1",node:"m1",label_short:"Stonebound",label_full:"M1 Stonebound",tier_full:"Mythril",desc:"Standfast engages twice as fast — terrain after 1s still. ⚡ Right-click to arm Stonebound — Resistance + Regen, 60s active · 60s cooldown."}
function evercraft:bough/codex/check_mast_node {cls:"sn",tier:"myth",cost:"1",node:"m2",label_short:"Worn Stone",label_full:"M2 Worn Stone",tier_full:"Mythril",desc:"Below 30% HP while holding a shield, gain Resistance I. The stone hardens under pressure. ⚡ Right-click to arm Worn Stone — Resistance I, 60s active · 60s cooldown."}
function evercraft:bough/codex/check_mast_node {cls:"sn",tier:"anci",cost:"1",node:"m3",label_short:"Granite Watch",label_full:"M3 Granite Watch",tier_full:"Ancient",desc:"Raising your shield reveals nearby hostiles with Glow for 5s. 10s cooldown. The granite watches the line. ⚡ Right-click to arm Granite Watch — Absorption, 45s active · 10s cooldown."}
function evercraft:bough/codex/check_mast_node {cls:"sn",tier:"anci",cost:"1",node:"m4",label_short:"Last Bastion",label_full:"M4 Last Bastion",tier_full:"Ancient",desc:"Below 30% HP with an ally within 5 blocks, gain Resistance II and grant the ally Absorption for 5s. 60s cooldown. The line holds. ⚡ Right-click to arm Last Bastion — Resistance III + Absorption II, 30s active · 40s cooldown."}
function evercraft:bough/codex/check_mast_node {cls:"sn",tier:"anci",cost:"1",node:"m5",label_short:"Crown's Watch",label_full:"M5 Crown's Watch",tier_full:"Ancient",desc:"Standfast's terrain-effect range +3 blocks. ✦ Right-click to arm Crown's Watch (CROSS-CLASS ultimate) — Resistance + Absorption, lasts 5 min, 180s cooldown."}
function evercraft:bough/codex/check_crown_node {cls_path:"sentinel",crown_name:"Standfast",cost_line:"Level 50 · 10 Mastery pts",effect_line:"Stationary 2s+ → +10 armor and mobs path around you.",permanence:"Until Reroot."}
function evercraft:bough/codex/check_branch_btns {cls_path:"sentinel"}

# ===== REROOT (Wave 26 — Soul-Echo, 2-click confirm; cls_id 5 = Sentinel) =====
execute as @e[type=interaction,tag=ec.bough_btn_reroot,distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s interaction on target run function evercraft:bough/reroot/confirm {cls_id:5}
execute as @e[type=interaction,tag=ec.bough_btn_reroot,distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=ec.bough_btn_reroot,distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Reroot (Soul-Echo)",b:"Wipes all nodes and refunds your spent points. Right-click twice within 5s to commit."}
execute as @e[type=interaction,tag=ec.bough_btn_reroot,distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s attack run data remove entity @s attack
# ===== RESONANCE (Wave 36 — balance readout; left-click = what is Resonance) =====
execute as @e[type=interaction,tag=ec.bough_btn_resonance,distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s interaction on target run function evercraft:bough/resonance/show {cls:"sn",class_name:"Sentinel",color:"red"}
execute as @e[type=interaction,tag=ec.bough_btn_resonance,distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=ec.bough_btn_resonance,distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s attack on attacker run function evercraft:bough/resonance/info
execute as @e[type=interaction,tag=ec.bough_btn_resonance,distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s attack run data remove entity @s attack

# ===== RESONANCE LABEL RE-PAINT (Wave 36b — reflects hub spends without waiting for a rebuild) =====
function evercraft:bough/resonance/paint_label {cls:"sn",color:"red"}
