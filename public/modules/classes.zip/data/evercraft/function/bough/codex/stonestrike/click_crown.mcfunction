# Owned Crown → right-click toggles Veinkeeper mode (auto-smelt + furnace vow)
# instead of the "already owned" nudge. Unowned → normal purchase path.
execute if score @s ec.ss_b_crown matches 1.. run function evercraft:bough/stonestrike/crown_toggle
execute if score @s ec.ss_b_crown matches 1.. run return 0
function evercraft:bough/codex/click_crown_generic {cls:"ss",crown_name:"Veinkeeper",color_hex:"gold"}
