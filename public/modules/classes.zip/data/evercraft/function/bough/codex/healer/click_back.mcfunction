scoreboard players set @s ec.hl_bough_view 0
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:item.book.page_turn master @s ~ ~ ~ 0.7 0.9
