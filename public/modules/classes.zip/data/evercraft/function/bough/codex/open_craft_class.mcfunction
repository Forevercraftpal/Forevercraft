# === BOUGH CODEX — OPEN CRAFTING CLASS DISPATCHER ===
# Run as @s = the player. Crafting-class twin of open_class.mcfunction. Reads
# ec.bough_craft_pending_cls (set by the CraftForever codex craft_open<N> shims)
# and opens the matching crafting class's bough page.
#
# All 7 crafting classes have full boughs authored: Stonestrike (1),
# Lumberfell (2), Growseer (3), Terrawarp (4), Sirencall (5), Lamentor (6),
# Gearwright (7).

# First-time tutorial (one-shot via ec.bough_reroot_seen — Wave 37, 2026-06-12).
function evercraft:bough/codex/reroot_tutorial

# 1. Stonestrike — Crown: Veinkeeper (fully authored)
execute if score @s ec.bough_craft_pending_cls matches 1 run function evercraft:bough/codex/open_stonestrike

# 2. Lumberfell — Crown: Heartfall (fully authored)
execute if score @s ec.bough_craft_pending_cls matches 2 run function evercraft:bough/codex/open_lumberfell

# 3. Growseer — Crown: Eternal Bloom (fully authored)
execute if score @s ec.bough_craft_pending_cls matches 3 run function evercraft:bough/codex/open_growseer

# 4. Terrawarp — Crown: Pathwalker (fully authored)
execute if score @s ec.bough_craft_pending_cls matches 4 run function evercraft:bough/codex/open_terrawarp

# 5. Sirencall — Crown: Tidecaller's Vow (fully authored)
execute if score @s ec.bough_craft_pending_cls matches 5 run function evercraft:bough/codex/open_sirencall

# 6. Lamentor — Crown: Silkwoven (fully authored)
execute if score @s ec.bough_craft_pending_cls matches 6 run function evercraft:bough/codex/open_lamentor

# 7. Gearwright — Crown: Tinkermind (fully authored)
execute if score @s ec.bough_craft_pending_cls matches 7 run function evercraft:bough/codex/open_gearwright

# Reset the pending slot.
scoreboard players set @s ec.bough_craft_pending_cls 0
