function evercraft:bough/codex/click_crown_generic {cls:"kt",crown_name:"Riposte",color_hex:"gold"}
