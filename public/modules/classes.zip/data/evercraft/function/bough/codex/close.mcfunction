# === BOUGH CODEX — CLOSE ===
# Run as @s = the viewer. Despawns the bough page entities and clears tags.

scoreboard players operation #bough_close_sess ec.temp = @s ec.bough_sess

# Kill all bough entities matching this session. Each page tags its entities
# with both ec.bough_el (universal) and ec.bough_class_<x> (per-class). The
# session scoreboard on the entities lets us scope cleanup precisely.
execute as @e[tag=ec.bough_el] if score @s ec.bough_sess = #bough_close_sess ec.temp run kill @s
execute as @e[tag=ec.bough_anchor] if score @s ec.bough_sess = #bough_close_sess ec.temp run kill @s

# Clear the page-dirty flag so a stale click doesn't force a rebuild on reopen.
scoreboard players set @s ec.bough_dirty 0

tag @s remove ec.bough_viewing
tag @s remove ec.bough_class_bk
tag @s remove ec.bough_class_rg
tag @s remove ec.bough_class_dn
tag @s remove ec.bough_class_sk
tag @s remove ec.bough_class_sn
tag @s remove ec.bough_class_hl
tag @s remove ec.bough_class_bl
tag @s remove ec.bough_class_jv
tag @s remove ec.bough_class_hp
tag @s remove ec.bough_class_ar
tag @s remove ec.bough_class_ht
tag @s remove ec.bough_class_tk
tag @s remove ec.bough_class_kt
tag @s remove ec.bough_class_ds
tag @s remove ec.bough_class_ss
tag @s remove ec.bough_class_lf
tag @s remove ec.bough_class_gs
tag @s remove ec.bough_class_tw
tag @s remove ec.bough_class_sc
tag @s remove ec.bough_class_lm
tag @s remove ec.bough_class_gw

execute if score @s ec.fx_snd matches 1.. run playsound minecraft:item.book.put master @s ~ ~ ~ 0.5 0.9
