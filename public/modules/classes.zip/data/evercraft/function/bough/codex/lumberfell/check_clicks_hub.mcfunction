scoreboard players operation #bough_cc_sess ec.temp = @s ec.bough_sess
function evercraft:bough/codex/check_stat_btns
function evercraft:bough/codex/check_mast_node {cls:"lf",tier:"myth",cost:"1",node:"m1",label_short:"Greenroot",label_full:"M1 Greenroot",tier_full:"Mythril",desc:"Every 30 logs gathered grants Strength I for 60 seconds. The forest hums."}
function evercraft:bough/codex/check_mast_node {cls:"lf",tier:"myth",cost:"1",node:"m2",label_short:"Heartmend",label_full:"M2 Heartmend",tier_full:"Mythril",desc:"While Lumberfell is active, gain Saturation. Hunger never slows the swing."}
function evercraft:bough/codex/check_mast_node {cls:"lf",tier:"anci",cost:"1",node:"m3",label_short:"Forest Listen",label_full:"M3 Forest Listen",tier_full:"Ancient",desc:"5% chance per log to grant +200 Mastery XP."}
function evercraft:bough/codex/check_mast_node {cls:"lf",tier:"anci",cost:"1",node:"m4",label_short:"Last Branch",label_full:"M4 Last Branch",tier_full:"Ancient",desc:"Below 30% HP, gain Resistance II + Strength I for 5s. 60s cooldown. The branch holds."}
function evercraft:bough/codex/check_mast_node {cls:"lf",tier:"anci",cost:"1",node:"m5",label_short:"Crown's Forest",label_full:"M5 Crown's Forest",tier_full:"Ancient",desc:"While Lumberfell is active, movement speed +5%. The forest steward strides."}
function evercraft:bough/codex/check_crown_node {cls_path:"lumberfell",crown_name:"Heartfall",cost_line:"Level 50 · 10 Mastery pts",effect_line:"Felling a tree node drops +1 sapling (always) and a 25% chance of a heartwood log.",permanence:"You cannot place log blocks. Until Reroot."}
function evercraft:bough/codex/check_branch_btns {cls_path:"lumberfell"}

# ===== REROOT (Wave 26 — Soul-Echo, 2-click confirm; cls_id 16 = Lumberfell) =====
execute as @e[type=interaction,tag=ec.bough_btn_reroot,distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s interaction on target run function evercraft:bough/reroot/confirm {cls_id:16}
execute as @e[type=interaction,tag=ec.bough_btn_reroot,distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=ec.bough_btn_reroot,distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Reroot (Soul-Echo)",b:"Wipes all nodes and refunds your spent points. Right-click twice within 5s to commit."}
execute as @e[type=interaction,tag=ec.bough_btn_reroot,distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s attack run data remove entity @s attack
# ===== RESONANCE (Wave 36 — balance readout; left-click = what is Resonance) =====
execute as @e[type=interaction,tag=ec.bough_btn_resonance,distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s interaction on target run function evercraft:bough/resonance/show {cls:"lf",class_name:"Lumberfell",color:"dark_green"}
execute as @e[type=interaction,tag=ec.bough_btn_resonance,distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=ec.bough_btn_resonance,distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s attack on attacker run function evercraft:bough/resonance/info
execute as @e[type=interaction,tag=ec.bough_btn_resonance,distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s attack run data remove entity @s attack

# ===== RESONANCE LABEL RE-PAINT (Wave 36b — reflects hub spends without waiting for a rebuild) =====
function evercraft:bough/resonance/paint_label {cls:"lf",color:"dark_green"}
