scoreboard players operation #bough_cc_sess ec.temp = @s ec.bough_sess
function evercraft:bough/codex/check_stat_btns
function evercraft:bough/codex/check_mast_node {cls:"hl",tier:"myth",cost:"1",node:"m1",label_short:"Lifegiver",label_full:"M1 Lifegiver",tier_full:"Mythril",desc:"While carrying a healer item, gain a passive Absorption shield. The lifegiver's generosity returns. ⚡ Right-click to arm Lifebloom — Regeneration II, 60s active · 60s cooldown."}
function evercraft:bough/codex/check_mast_node {cls:"hl",tier:"myth",cost:"1",node:"m2",label_short:"Triage",label_full:"M2 Triage",tier_full:"Mythril",desc:"Allies within 8 blocks below 30% HP receive Regeneration II. The triage hand finds the wound first. ⚡ Right-click to arm Triage — Regeneration II, 60s active · 60s cooldown."}
function evercraft:bough/codex/check_mast_node {cls:"hl",tier:"anci",cost:"1",node:"m3",label_short:"Aether's Grace",label_full:"M3 Aether's Grace",tier_full:"Ancient",desc:"5% chance per kill to grant +200 Mastery XP. ⚡ Right-click to arm Aether's Grace — Resistance + Regen, 45s active · 10s cooldown."}
function evercraft:bough/codex/check_mast_node {cls:"hl",tier:"anci",cost:"1",node:"m4",label_short:"Lifegift",label_full:"M4 Lifegift",tier_full:"Ancient",desc:"Below 30% HP with an ally within 5b, gain Resistance II and grant ally Regeneration II 5s. 60s cooldown. The gift flows both ways. ⚡ Right-click to arm Lifegift — big Regeneration to you + allies, 30s active · 40s cooldown."}
function evercraft:bough/codex/check_mast_node {cls:"hl",tier:"anci",cost:"1",node:"m5",label_short:"Crown's Mercy",label_full:"M5 Crown's Mercy",tier_full:"Ancient",desc:"Lifebound's ore-yield penalty eases to -25%. ✦ Right-click to arm Crown's Mercy (CROSS-CLASS ultimate) — Regeneration + Resistance, lasts 5 min, 180s cooldown."}
function evercraft:bough/codex/check_crown_node {cls_path:"healer",crown_name:"Lifebound",cost_line:"Level 50 · 10 Mastery pts",effect_line:"Heals you give are 50% stronger.",permanence:"Heals +50%. Ore yield halved. Until Reroot."}
function evercraft:bough/codex/check_branch_btns {cls_path:"healer"}

# ===== REROOT (Wave 26 — Soul-Echo, 2-click confirm; cls_id 6 = Healer) =====
execute as @e[type=interaction,tag=ec.bough_btn_reroot,distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s interaction on target run function evercraft:bough/reroot/confirm {cls_id:6}
execute as @e[type=interaction,tag=ec.bough_btn_reroot,distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=ec.bough_btn_reroot,distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Reroot (Soul-Echo)",b:"Wipes all nodes and refunds your spent points. Right-click twice within 5s to commit."}
execute as @e[type=interaction,tag=ec.bough_btn_reroot,distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s attack run data remove entity @s attack
# ===== RESONANCE (Wave 36 — balance readout; left-click = what is Resonance) =====
execute as @e[type=interaction,tag=ec.bough_btn_resonance,distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s interaction on target run function evercraft:bough/resonance/show {cls:"hl",class_name:"Healer",color:"green"}
execute as @e[type=interaction,tag=ec.bough_btn_resonance,distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=ec.bough_btn_resonance,distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s attack on attacker run function evercraft:bough/resonance/info
execute as @e[type=interaction,tag=ec.bough_btn_resonance,distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s attack run data remove entity @s attack

# ===== RESONANCE LABEL RE-PAINT (Wave 36b — reflects hub spends without waiting for a rebuild) =====
function evercraft:bough/resonance/paint_label {cls:"hl",color:"green"}
