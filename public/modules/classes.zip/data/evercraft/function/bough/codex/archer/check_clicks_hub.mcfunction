scoreboard players operation #bough_cc_sess ec.temp = @s ec.bough_sess
function evercraft:bough/codex/check_stat_btns
function evercraft:bough/codex/check_mast_node {cls:"ar",tier:"myth",cost:"1",node:"m1",label_short:"Hawk Mastery",label_full:"M1 Hawk Mastery",tier_full:"Mythril",desc:"While Archer is active, attack damage +5%. The hawk does not miss twice."}
function evercraft:bough/codex/check_mast_node {cls:"ar",tier:"myth",cost:"1",node:"m2",label_short:"Drawn Calm",label_full:"M2 Drawn Calm",tier_full:"Mythril",desc:"While Archer is active, gain Slow Falling I. The calm draw."}
function evercraft:bough/codex/check_mast_node {cls:"ar",tier:"anci",cost:"1",node:"m3",label_short:"Wind Mastery",label_full:"M3 Wind Mastery",tier_full:"Ancient",desc:"5% chance per kill to grant +200 Mastery XP."}
function evercraft:bough/codex/check_mast_node {cls:"ar",tier:"anci",cost:"1",node:"m4",label_short:"Parting Shot",label_full:"M4 Parting Shot",tier_full:"Ancient",desc:"Below 30% HP, gain Speed III + Strength II for 5s. 60s cooldown. The hawk flees to strike again."}
function evercraft:bough/codex/check_mast_node {cls:"ar",tier:"anci",cost:"1",node:"m5",label_short:"Crown's Hawk",label_full:"M5 Crown's Hawk",tier_full:"Ancient",desc:"While Archer is active, attack damage +5%. The hawk's stoop sharpens."}
function evercraft:bough/codex/check_crown_node {cls_path:"archer",crown_name:"Hawk Eye",cost_line:"Level 50 · 10 Mastery pts",effect_line:"Arrows ignore 50% armor.",permanence:"You take double damage from arrows. Until Reroot."}
function evercraft:bough/codex/check_branch_btns {cls_path:"archer"}

# ===== REROOT (Wave 26 — Soul-Echo, 2-click confirm; cls_id 10 = Archer) =====
execute as @e[type=interaction,tag=ec.bough_btn_reroot,distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s interaction on target run function evercraft:bough/reroot/confirm {cls_id:10}
execute as @e[type=interaction,tag=ec.bough_btn_reroot,distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=ec.bough_btn_reroot,distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Reroot (Soul-Echo)",b:"Wipes all nodes and refunds your spent points. Right-click twice within 5s to commit."}
execute as @e[type=interaction,tag=ec.bough_btn_reroot,distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s attack run data remove entity @s attack
# ===== RESONANCE (Wave 36 — balance readout; left-click = what is Resonance) =====
execute as @e[type=interaction,tag=ec.bough_btn_resonance,distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s interaction on target run function evercraft:bough/resonance/show {cls:"ar",class_name:"Archer",color:"aqua"}
execute as @e[type=interaction,tag=ec.bough_btn_resonance,distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=ec.bough_btn_resonance,distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s attack on attacker run function evercraft:bough/resonance/info
execute as @e[type=interaction,tag=ec.bough_btn_resonance,distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s attack run data remove entity @s attack

# ===== RESONANCE LABEL RE-PAINT (Wave 36b — reflects hub spends without waiting for a rebuild) =====
function evercraft:bough/resonance/paint_label {cls:"ar",color:"aqua"}
