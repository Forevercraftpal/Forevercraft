scoreboard players operation #bough_cc_sess ec.temp = @s ec.bough_sess
function evercraft:bough/codex/check_stat_btns
function evercraft:bough/codex/check_mast_node {cls:"sc",tier:"myth",cost:"1",node:"m1",label_short:"Tideroot",label_full:"M1 Tideroot",tier_full:"Mythril",desc:"Catching 30 fish in 10 minutes grants Dolphin's Grace for 5 minutes."}
function evercraft:bough/codex/check_mast_node {cls:"sc",tier:"myth",cost:"1",node:"m2",label_short:"Tidemend",label_full:"M2 Tidemend",tier_full:"Mythril",desc:"Rods auto-repair at sunset if a Tidecaller token is in your inventory."}
function evercraft:bough/codex/check_mast_node {cls:"sc",tier:"anci",cost:"1",node:"m3",label_short:"Tide Listen",label_full:"M3 Tide Listen",tier_full:"Ancient",desc:"Catching a champion fish reveals all fish within 10 blocks."}
function evercraft:bough/codex/check_mast_node {cls:"sc",tier:"anci",cost:"1",node:"m4",label_short:"Last Tide",label_full:"M4 Last Tide",tier_full:"Ancient",desc:"If lethal HP, summon a 3-block water-pocket beneath you (Water Breathing 30s). 1/min."}
function evercraft:bough/codex/check_mast_node {cls:"sc",tier:"anci",cost:"1",node:"m5",label_short:"Crown's Tide",label_full:"M5 Crown's Tide",tier_full:"Ancient",desc:"Tidecaller's Vow's token chance increases to 1/4 from 1/8."}
function evercraft:bough/codex/check_crown_node {cls_path:"sirencall",crown_name:"Tidecaller's Vow",cost_line:"Level 50 · 10 Mastery pts",effect_line:"Every fish caught comes with a Tidecaller token (1/8 trades for a free aquatic accessory; stockpiles).",permanence:"You cannot fish in still water — flowing water or open ocean only. Until Reroot."}
function evercraft:bough/codex/check_branch_btns {cls_path:"sirencall"}

# ===== REROOT (Wave 26 — Soul-Echo, 2-click confirm; cls_id 19 = Sirencall) =====
execute as @e[type=interaction,tag=ec.bough_btn_reroot,distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s interaction on target run function evercraft:bough/reroot/confirm {cls_id:19}
execute as @e[type=interaction,tag=ec.bough_btn_reroot,distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=ec.bough_btn_reroot,distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Reroot (Soul-Echo)",b:"Wipes all nodes and refunds your spent points. Right-click twice within 5s to commit."}
execute as @e[type=interaction,tag=ec.bough_btn_reroot,distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s attack run data remove entity @s attack
# ===== RESONANCE (Wave 36 — balance readout; left-click = what is Resonance) =====
execute as @e[type=interaction,tag=ec.bough_btn_resonance,distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s interaction on target run function evercraft:bough/resonance/show {cls:"sc",class_name:"Sirencall",color:"aqua"}
execute as @e[type=interaction,tag=ec.bough_btn_resonance,distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=ec.bough_btn_resonance,distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s attack on attacker run function evercraft:bough/resonance/info
execute as @e[type=interaction,tag=ec.bough_btn_resonance,distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s attack run data remove entity @s attack

# ===== RESONANCE LABEL RE-PAINT (Wave 36b — reflects hub spends without waiting for a rebuild) =====
function evercraft:bough/resonance/paint_label {cls:"sc",color:"aqua"}
