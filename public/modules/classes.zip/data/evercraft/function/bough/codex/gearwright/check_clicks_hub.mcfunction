scoreboard players operation #bough_cc_sess ec.temp = @s ec.bough_sess
function evercraft:bough/codex/check_stat_btns
function evercraft:bough/codex/check_mast_node {cls:"gw",tier:"myth",cost:"1",node:"m1",label_short:"Gearroot",label_full:"M1 Gearroot",tier_full:"Mythril",desc:"Completing 10 tinker fusions in 10 minutes grants Haste I for 5 minutes."}
function evercraft:bough/codex/check_mast_node {cls:"gw",tier:"myth",cost:"1",node:"m2",label_short:"Gearmend",label_full:"M2 Gearmend",tier_full:"Mythril",desc:"Tinker tools auto-repair at noon if redstone is in your inventory."}
function evercraft:bough/codex/check_mast_node {cls:"gw",tier:"anci",cost:"1",node:"m3",label_short:"Gear Listen",label_full:"M3 Gear Listen",tier_full:"Ancient",desc:"Completing a 5-component fusion reveals all chest-nodes within 10 blocks."}
function evercraft:bough/codex/check_mast_node {cls:"gw",tier:"anci",cost:"1",node:"m4",label_short:"Last Mechanism",label_full:"M4 Last Mechanism",tier_full:"Ancient",desc:"If lethal HP, summon a 5-block redstone pulse (knockback all mobs 5 blocks). 1/min."}
function evercraft:bough/codex/check_mast_node {cls:"gw",tier:"anci",cost:"1",node:"m5",label_short:"Crown's Tinkermind",label_full:"M5 Crown's Tinkermind",tier_full:"Ancient",desc:"Tinkermind's XP bonus increases to +75%."}
function evercraft:bough/codex/check_crown_node {cls_path:"gearwright",crown_name:"Tinkermind",cost_line:"Level 50 · 10 Mastery pts",effect_line:"Tinker fusions reveal optimal slot for each component (highlights). Tinker XP gain +50%.",permanence:"You cannot use vanilla anvils. Until Reroot."}
function evercraft:bough/codex/check_branch_btns {cls_path:"gearwright"}

# ===== REROOT (Wave 26 — Soul-Echo, 2-click confirm; cls_id 21 = Gearwright) =====
execute as @e[type=interaction,tag=ec.bough_btn_reroot,distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s interaction on target run function evercraft:bough/reroot/confirm {cls_id:21}
execute as @e[type=interaction,tag=ec.bough_btn_reroot,distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=ec.bough_btn_reroot,distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Reroot (Soul-Echo)",b:"Wipes all nodes and refunds your spent points. Right-click twice within 5s to commit."}
execute as @e[type=interaction,tag=ec.bough_btn_reroot,distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s attack run data remove entity @s attack
# ===== RESONANCE (Wave 36 — balance readout; left-click = what is Resonance) =====
execute as @e[type=interaction,tag=ec.bough_btn_resonance,distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s interaction on target run function evercraft:bough/resonance/show {cls:"gw",class_name:"Gearwright",color:"#FFA85C"}
execute as @e[type=interaction,tag=ec.bough_btn_resonance,distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=ec.bough_btn_resonance,distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s attack on attacker run function evercraft:bough/resonance/info
execute as @e[type=interaction,tag=ec.bough_btn_resonance,distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s attack run data remove entity @s attack

# ===== RESONANCE LABEL RE-PAINT (Wave 36b — reflects hub spends without waiting for a rebuild) =====
function evercraft:bough/resonance/paint_label {cls:"gw",color:"#FFA85C"}
