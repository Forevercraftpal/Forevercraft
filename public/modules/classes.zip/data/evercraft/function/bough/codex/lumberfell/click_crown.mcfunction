# Owned Crown → right-click toggles the Heartfall vow instead of "already owned".
execute if score @s ec.lf_b_crown matches 1.. run function evercraft:bough/lumberfell/crown_toggle
execute if score @s ec.lf_b_crown matches 1.. run return 0
function evercraft:bough/codex/click_crown_generic {cls:"lf",crown_name:"Heartfall",color_hex:"dark_green"}
