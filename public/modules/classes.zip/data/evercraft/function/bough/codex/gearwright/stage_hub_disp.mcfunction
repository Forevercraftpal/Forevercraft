# === BOUGH GEARWRIGHT — Stage hub readout values ===
# {score} renders BLANK in text_display (26.1); bake the numbers as macro args.
# `add 0` first so an absent objective shows 0. spawn_*_inner runs right after
# this with `with storage evercraft:bough disp`.
scoreboard players add @s ec.gw_lvl 0
scoreboard players add @s ec.gw_xp 0
scoreboard players add @s ec.gw_pts 0
scoreboard players add @s ec.bough_bank 0
scoreboard players add @s ec.gw_b_combat 0
scoreboard players add @s ec.gw_b_util 0
scoreboard players add @s ec.gw_b_mast 0
execute store result storage evercraft:bough disp.lvl int 1 run scoreboard players get @s ec.gw_lvl
execute store result storage evercraft:bough disp.xp int 1 run scoreboard players get @s ec.gw_xp
execute store result storage evercraft:bough disp.pts int 1 run scoreboard players get @s ec.gw_pts
execute store result storage evercraft:bough disp.bank int 1 run scoreboard players get @s ec.bough_bank
execute store result storage evercraft:bough disp.bc int 1 run scoreboard players get @s ec.gw_b_combat
execute store result storage evercraft:bough disp.bu int 1 run scoreboard players get @s ec.gw_b_util
execute store result storage evercraft:bough disp.bm int 1 run scoreboard players get @s ec.gw_b_mast