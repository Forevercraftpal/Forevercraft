# === BOUGH KNIGHT — COMBAT SUB-PAGE ===
# Layout: low numbers (C1-C6) on player's LEFT (+X), high (C7-C12) on RIGHT (-X).

execute positioned ^ ^1.40 ^ run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["ec.bough_el","ec.bough_class_kt"],billboard:"center",text:{text:"Knight",color:"gold",bold:true},background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.46f,0.46f,0.46f]}}
execute positioned ^ ^1.18 ^ run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["ec.bough_el","ec.bough_class_kt"],billboard:"center",text:{text:"⚔  Combat",color:"red",bold:true},background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.40f,0.40f,0.40f]}}

$execute positioned ^ ^1.00 ^ run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["ec.bough_el","ec.bough_class_kt","ec.bough_dyn"],billboard:"center",text:[{text:"Lvl  ",color:"gray"},{text:"$(lvl)",color:"yellow"},{text:"      XP  ",color:"gray"},{text:"$(xp)",color:"aqua"},{text:"      Pts  ",color:"gray"},{text:"$(pts)",color:"light_purple"}],background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.28f,0.28f,0.28f]}}

execute positioned ^0.70 ^0.70 ^ run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["ec.bough_el","ec.bough_class_kt"],billboard:"center",text:{text:"── Iron / Steel ──",color:"gray",italic:true},background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.24f,0.24f,0.24f]}}
execute positioned ^-0.70 ^0.70 ^ run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["ec.bough_el","ec.bough_class_kt"],billboard:"center",text:{text:"── Steel / Myth ──",color:"gray",italic:true},background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.24f,0.24f,0.24f]}}

# === LEFT COLUMN (C1-C6) — caret +X ===
execute positioned ^0.70 ^0.50 ^ run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["ec.bough_el","ec.bough_class_kt","ec.bn_c1"],billboard:"center",text:[{text:"C1 ",color:"yellow",bold:true},{text:"Swordsmanship",color:"white"}],background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.26f,0.26f,0.26f]}}
# [strip] wide hitbox split into codex-style shallow cubes
execute positioned ^0.3812 ^0.50 ^-0.02 run summon interaction ~ ~ ~ {Tags:["ec.bough_el","ec.bough_class_kt","ec.bough_node_c1"],width:0.2125f,height:0.16f,response:1b}
execute positioned ^0.5938 ^0.50 ^-0.02 run summon interaction ~ ~ ~ {Tags:["ec.bough_el","ec.bough_class_kt","ec.bough_node_c1"],width:0.2125f,height:0.16f,response:1b}
execute positioned ^0.8062 ^0.50 ^-0.02 run summon interaction ~ ~ ~ {Tags:["ec.bough_el","ec.bough_class_kt","ec.bough_node_c1"],width:0.2125f,height:0.16f,response:1b}
execute positioned ^1.0188 ^0.50 ^-0.02 run summon interaction ~ ~ ~ {Tags:["ec.bough_el","ec.bough_class_kt","ec.bough_node_c1"],width:0.2125f,height:0.16f,response:1b}
execute positioned ^0.70 ^0.30 ^ run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["ec.bough_el","ec.bough_class_kt","ec.bn_c2"],billboard:"center",text:[{text:"C2 ",color:"yellow",bold:true},{text:"Disarming Blow",color:"white"}],background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.26f,0.26f,0.26f]}}
# [strip] wide hitbox split into codex-style shallow cubes
execute positioned ^0.3812 ^0.30 ^-0.02 run summon interaction ~ ~ ~ {Tags:["ec.bough_el","ec.bough_class_kt","ec.bough_node_c2"],width:0.2125f,height:0.16f,response:1b}
execute positioned ^0.5938 ^0.30 ^-0.02 run summon interaction ~ ~ ~ {Tags:["ec.bough_el","ec.bough_class_kt","ec.bough_node_c2"],width:0.2125f,height:0.16f,response:1b}
execute positioned ^0.8062 ^0.30 ^-0.02 run summon interaction ~ ~ ~ {Tags:["ec.bough_el","ec.bough_class_kt","ec.bough_node_c2"],width:0.2125f,height:0.16f,response:1b}
execute positioned ^1.0188 ^0.30 ^-0.02 run summon interaction ~ ~ ~ {Tags:["ec.bough_el","ec.bough_class_kt","ec.bough_node_c2"],width:0.2125f,height:0.16f,response:1b}
execute positioned ^0.70 ^0.10 ^ run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["ec.bough_el","ec.bough_class_kt","ec.bn_c3"],billboard:"center",text:[{text:"C3 ",color:"yellow",bold:true},{text:"Knight's Oath",color:"white"}],background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.26f,0.26f,0.26f]}}
# [strip] wide hitbox split into codex-style shallow cubes
execute positioned ^0.3812 ^0.10 ^-0.02 run summon interaction ~ ~ ~ {Tags:["ec.bough_el","ec.bough_class_kt","ec.bough_node_c3"],width:0.2125f,height:0.16f,response:1b}
execute positioned ^0.5938 ^0.10 ^-0.02 run summon interaction ~ ~ ~ {Tags:["ec.bough_el","ec.bough_class_kt","ec.bough_node_c3"],width:0.2125f,height:0.16f,response:1b}
execute positioned ^0.8062 ^0.10 ^-0.02 run summon interaction ~ ~ ~ {Tags:["ec.bough_el","ec.bough_class_kt","ec.bough_node_c3"],width:0.2125f,height:0.16f,response:1b}
execute positioned ^1.0188 ^0.10 ^-0.02 run summon interaction ~ ~ ~ {Tags:["ec.bough_el","ec.bough_class_kt","ec.bough_node_c3"],width:0.2125f,height:0.16f,response:1b}
execute positioned ^0.70 ^-0.10 ^ run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["ec.bough_el","ec.bough_class_kt","ec.bn_c4"],billboard:"center",text:[{text:"C4 ",color:"yellow",bold:true},{text:"Fencing Stance",color:"white"}],background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.26f,0.26f,0.26f]}}
# [strip] wide hitbox split into codex-style shallow cubes
execute positioned ^0.3812 ^-0.10 ^-0.02 run summon interaction ~ ~ ~ {Tags:["ec.bough_el","ec.bough_class_kt","ec.bough_node_c4"],width:0.2125f,height:0.16f,response:1b}
execute positioned ^0.5938 ^-0.10 ^-0.02 run summon interaction ~ ~ ~ {Tags:["ec.bough_el","ec.bough_class_kt","ec.bough_node_c4"],width:0.2125f,height:0.16f,response:1b}
execute positioned ^0.8062 ^-0.10 ^-0.02 run summon interaction ~ ~ ~ {Tags:["ec.bough_el","ec.bough_class_kt","ec.bough_node_c4"],width:0.2125f,height:0.16f,response:1b}
execute positioned ^1.0188 ^-0.10 ^-0.02 run summon interaction ~ ~ ~ {Tags:["ec.bough_el","ec.bough_class_kt","ec.bough_node_c4"],width:0.2125f,height:0.16f,response:1b}
execute positioned ^0.70 ^-0.30 ^ run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["ec.bough_el","ec.bough_class_kt","ec.bn_c5"],billboard:"center",text:[{text:"C5 ",color:"aqua",bold:true},{text:"Guard Stance",color:"white"}],background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.26f,0.26f,0.26f]}}
# [strip] wide hitbox split into codex-style shallow cubes
execute positioned ^0.3812 ^-0.30 ^-0.02 run summon interaction ~ ~ ~ {Tags:["ec.bough_el","ec.bough_class_kt","ec.bough_node_c5"],width:0.2125f,height:0.16f,response:1b}
execute positioned ^0.5938 ^-0.30 ^-0.02 run summon interaction ~ ~ ~ {Tags:["ec.bough_el","ec.bough_class_kt","ec.bough_node_c5"],width:0.2125f,height:0.16f,response:1b}
execute positioned ^0.8062 ^-0.30 ^-0.02 run summon interaction ~ ~ ~ {Tags:["ec.bough_el","ec.bough_class_kt","ec.bough_node_c5"],width:0.2125f,height:0.16f,response:1b}
execute positioned ^1.0188 ^-0.30 ^-0.02 run summon interaction ~ ~ ~ {Tags:["ec.bough_el","ec.bough_class_kt","ec.bough_node_c5"],width:0.2125f,height:0.16f,response:1b}
execute positioned ^0.70 ^-0.50 ^ run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["ec.bough_el","ec.bough_class_kt","ec.bn_c6"],billboard:"center",text:[{text:"C6 ",color:"aqua",bold:true},{text:"Bladed Guard",color:"white"}],background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.26f,0.26f,0.26f]}}
# [strip] wide hitbox split into codex-style shallow cubes
execute positioned ^0.3812 ^-0.50 ^-0.02 run summon interaction ~ ~ ~ {Tags:["ec.bough_el","ec.bough_class_kt","ec.bough_node_c6"],width:0.2125f,height:0.16f,response:1b}
execute positioned ^0.5938 ^-0.50 ^-0.02 run summon interaction ~ ~ ~ {Tags:["ec.bough_el","ec.bough_class_kt","ec.bough_node_c6"],width:0.2125f,height:0.16f,response:1b}
execute positioned ^0.8062 ^-0.50 ^-0.02 run summon interaction ~ ~ ~ {Tags:["ec.bough_el","ec.bough_class_kt","ec.bough_node_c6"],width:0.2125f,height:0.16f,response:1b}
execute positioned ^1.0188 ^-0.50 ^-0.02 run summon interaction ~ ~ ~ {Tags:["ec.bough_el","ec.bough_class_kt","ec.bough_node_c6"],width:0.2125f,height:0.16f,response:1b}

# === RIGHT COLUMN (C7-C12) — caret -X ===
execute positioned ^-0.70 ^0.50 ^ run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["ec.bough_el","ec.bough_class_kt","ec.bn_c7"],billboard:"center",text:[{text:"C7 ",color:"aqua",bold:true},{text:"Lunge",color:"white"}],background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.26f,0.26f,0.26f]}}
# [strip] wide hitbox split into codex-style shallow cubes
execute positioned ^-1.0188 ^0.50 ^-0.02 run summon interaction ~ ~ ~ {Tags:["ec.bough_el","ec.bough_class_kt","ec.bough_node_c7"],width:0.2125f,height:0.16f,response:1b}
execute positioned ^-0.8063 ^0.50 ^-0.02 run summon interaction ~ ~ ~ {Tags:["ec.bough_el","ec.bough_class_kt","ec.bough_node_c7"],width:0.2125f,height:0.16f,response:1b}
execute positioned ^-0.5938 ^0.50 ^-0.02 run summon interaction ~ ~ ~ {Tags:["ec.bough_el","ec.bough_class_kt","ec.bough_node_c7"],width:0.2125f,height:0.16f,response:1b}
execute positioned ^-0.3812 ^0.50 ^-0.02 run summon interaction ~ ~ ~ {Tags:["ec.bough_el","ec.bough_class_kt","ec.bough_node_c7"],width:0.2125f,height:0.16f,response:1b}
execute positioned ^-0.70 ^0.30 ^ run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["ec.bough_el","ec.bough_class_kt","ec.bn_c8"],billboard:"center",text:[{text:"C8 ",color:"aqua",bold:true},{text:"Counter",color:"white"}],background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.26f,0.26f,0.26f]}}
# [strip] wide hitbox split into codex-style shallow cubes
execute positioned ^-1.0188 ^0.30 ^-0.02 run summon interaction ~ ~ ~ {Tags:["ec.bough_el","ec.bough_class_kt","ec.bough_node_c8"],width:0.2125f,height:0.16f,response:1b}
execute positioned ^-0.8063 ^0.30 ^-0.02 run summon interaction ~ ~ ~ {Tags:["ec.bough_el","ec.bough_class_kt","ec.bough_node_c8"],width:0.2125f,height:0.16f,response:1b}
execute positioned ^-0.5938 ^0.30 ^-0.02 run summon interaction ~ ~ ~ {Tags:["ec.bough_el","ec.bough_class_kt","ec.bough_node_c8"],width:0.2125f,height:0.16f,response:1b}
execute positioned ^-0.3812 ^0.30 ^-0.02 run summon interaction ~ ~ ~ {Tags:["ec.bough_el","ec.bough_class_kt","ec.bough_node_c8"],width:0.2125f,height:0.16f,response:1b}
execute positioned ^-0.70 ^0.10 ^ run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["ec.bough_el","ec.bough_class_kt","ec.bn_c9"],billboard:"center",text:[{text:"C9 ",color:"light_purple",bold:true},{text:"Last Riposte",color:"white"}],background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.26f,0.26f,0.26f]}}
# [strip] wide hitbox split into codex-style shallow cubes
execute positioned ^-1.0188 ^0.10 ^-0.02 run summon interaction ~ ~ ~ {Tags:["ec.bough_el","ec.bough_class_kt","ec.bough_node_c9"],width:0.2125f,height:0.16f,response:1b}
execute positioned ^-0.8063 ^0.10 ^-0.02 run summon interaction ~ ~ ~ {Tags:["ec.bough_el","ec.bough_class_kt","ec.bough_node_c9"],width:0.2125f,height:0.16f,response:1b}
execute positioned ^-0.5938 ^0.10 ^-0.02 run summon interaction ~ ~ ~ {Tags:["ec.bough_el","ec.bough_class_kt","ec.bough_node_c9"],width:0.2125f,height:0.16f,response:1b}
execute positioned ^-0.3812 ^0.10 ^-0.02 run summon interaction ~ ~ ~ {Tags:["ec.bough_el","ec.bough_class_kt","ec.bough_node_c9"],width:0.2125f,height:0.16f,response:1b}
execute positioned ^-0.70 ^-0.10 ^ run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["ec.bough_el","ec.bough_class_kt","ec.bn_c10"],billboard:"center",text:[{text:"C10 ",color:"light_purple",bold:true},{text:"Sword Lord",color:"white"}],background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.26f,0.26f,0.26f]}}
# [strip] wide hitbox split into codex-style shallow cubes
execute positioned ^-1.0188 ^-0.10 ^-0.02 run summon interaction ~ ~ ~ {Tags:["ec.bough_el","ec.bough_class_kt","ec.bough_node_c10"],width:0.2125f,height:0.16f,response:1b}
execute positioned ^-0.8063 ^-0.10 ^-0.02 run summon interaction ~ ~ ~ {Tags:["ec.bough_el","ec.bough_class_kt","ec.bough_node_c10"],width:0.2125f,height:0.16f,response:1b}
execute positioned ^-0.5938 ^-0.10 ^-0.02 run summon interaction ~ ~ ~ {Tags:["ec.bough_el","ec.bough_class_kt","ec.bough_node_c10"],width:0.2125f,height:0.16f,response:1b}
execute positioned ^-0.3812 ^-0.10 ^-0.02 run summon interaction ~ ~ ~ {Tags:["ec.bough_el","ec.bough_class_kt","ec.bough_node_c10"],width:0.2125f,height:0.16f,response:1b}
execute positioned ^-0.70 ^-0.30 ^ run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["ec.bough_el","ec.bough_class_kt","ec.bn_c11"],billboard:"center",text:[{text:"C11 ",color:"light_purple",bold:true},{text:"Honor Mind",color:"white"}],background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.26f,0.26f,0.26f]}}
# [strip] wide hitbox split into codex-style shallow cubes
execute positioned ^-1.0188 ^-0.30 ^-0.02 run summon interaction ~ ~ ~ {Tags:["ec.bough_el","ec.bough_class_kt","ec.bough_node_c11"],width:0.2125f,height:0.16f,response:1b}
execute positioned ^-0.8063 ^-0.30 ^-0.02 run summon interaction ~ ~ ~ {Tags:["ec.bough_el","ec.bough_class_kt","ec.bough_node_c11"],width:0.2125f,height:0.16f,response:1b}
execute positioned ^-0.5938 ^-0.30 ^-0.02 run summon interaction ~ ~ ~ {Tags:["ec.bough_el","ec.bough_class_kt","ec.bough_node_c11"],width:0.2125f,height:0.16f,response:1b}
execute positioned ^-0.3812 ^-0.30 ^-0.02 run summon interaction ~ ~ ~ {Tags:["ec.bough_el","ec.bough_class_kt","ec.bough_node_c11"],width:0.2125f,height:0.16f,response:1b}
execute positioned ^-0.70 ^-0.50 ^ run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["ec.bough_el","ec.bough_class_kt","ec.bn_c12"],billboard:"center",text:[{text:"C12 ",color:"light_purple",bold:true},{text:"Victor's Laurel",color:"white"}],background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.26f,0.26f,0.26f]}}
# [strip] wide hitbox split into codex-style shallow cubes
execute positioned ^-1.0188 ^-0.50 ^-0.02 run summon interaction ~ ~ ~ {Tags:["ec.bough_el","ec.bough_class_kt","ec.bough_node_c12"],width:0.2125f,height:0.16f,response:1b}
execute positioned ^-0.8063 ^-0.50 ^-0.02 run summon interaction ~ ~ ~ {Tags:["ec.bough_el","ec.bough_class_kt","ec.bough_node_c12"],width:0.2125f,height:0.16f,response:1b}
execute positioned ^-0.5938 ^-0.50 ^-0.02 run summon interaction ~ ~ ~ {Tags:["ec.bough_el","ec.bough_class_kt","ec.bough_node_c12"],width:0.2125f,height:0.16f,response:1b}
execute positioned ^-0.3812 ^-0.50 ^-0.02 run summon interaction ~ ~ ~ {Tags:["ec.bough_el","ec.bough_class_kt","ec.bough_node_c12"],width:0.2125f,height:0.16f,response:1b}

# --- COUNTER ---
$execute positioned ^ ^-0.80 ^ run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["ec.bough_el","ec.bough_class_kt","ec.bough_dyn"],billboard:"center",text:[{text:"Combat  ",color:"gray"},{text:"$(bc)",color:"red"},{text:"/12 owned",color:"dark_gray"}],background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.28f,0.28f,0.28f]}}

# --- DESCRIPTION PANEL ---
execute positioned ^ ^-1.10 ^ run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["ec.bough_el","ec.bough_class_kt","ec.bough_dyn"],billboard:"center",text:{nbt:"info",storage:"evercraft:bough",interpret:true,separator:"\n"},background:1073741824,shadow:1b,line_width:200,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.28f,0.28f,0.28f]}}

# --- BACK + CLOSE ---
execute positioned ^0.40 ^-1.50 ^ run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["ec.bough_el","ec.bough_class_kt"],billboard:"center",text:{text:"[ < Back ]",color:"yellow"},background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.28f,0.28f,0.28f]}}
# [strip] wide hitbox split into codex-style shallow cubes
execute positioned ^0.275 ^-1.50 ^-0.02 run summon interaction ~ ~ ~ {Tags:["ec.bough_el","ec.bough_class_kt","ec.bough_btn_back"],width:0.25f,height:0.15f,response:1b}
execute positioned ^0.525 ^-1.50 ^-0.02 run summon interaction ~ ~ ~ {Tags:["ec.bough_el","ec.bough_class_kt","ec.bough_btn_back"],width:0.25f,height:0.15f,response:1b}
execute positioned ^-0.40 ^-1.50 ^ run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["ec.bough_el","ec.bough_class_kt"],billboard:"center",text:{text:"[ Close ]",color:"yellow"},background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.28f,0.28f,0.28f]}}
# [strip] wide hitbox split into codex-style shallow cubes
execute positioned ^-0.525 ^-1.50 ^-0.02 run summon interaction ~ ~ ~ {Tags:["ec.bough_el","ec.bough_class_kt","ec.bough_close_btn"],width:0.25f,height:0.15f,response:1b}
execute positioned ^-0.275 ^-1.50 ^-0.02 run summon interaction ~ ~ ~ {Tags:["ec.bough_el","ec.bough_class_kt","ec.bough_close_btn"],width:0.25f,height:0.15f,response:1b}

# === HIGHLIGHT PASS (auto-generated by gen_bough_highlight.py) ===
# bought -> gold; affordable (not owned + level-gate met + >=1 pt) -> gold.
# runs at the class anchor (see spawn.mcfunction), so nearest-by-tag is class-scoped.
execute if score @s ec.kt_n_c1 matches 1.. run data modify entity @e[type=text_display,tag=ec.bn_c1,distance=..8,limit=1,sort=nearest] text set value [{text:"C1 ",color:"gold",bold:true},{text:"Swordsmanship",color:"gold"}]
execute if score @s ec.kt_n_c1 matches 0 if score @s ec.kt_pts matches 1.. if score @s ec.kt_lvl >= #b_gate_iron ec.const run data modify entity @e[type=text_display,tag=ec.bn_c1,distance=..8,limit=1,sort=nearest] text set value [{text:"C1 ",color:"gold",bold:true},{text:"Swordsmanship",color:"gold"}]
execute if score @s ec.kt_n_c2 matches 1.. run data modify entity @e[type=text_display,tag=ec.bn_c2,distance=..8,limit=1,sort=nearest] text set value [{text:"C2 ",color:"gold",bold:true},{text:"Disarming Blow",color:"gold"}]
execute if score @s ec.kt_n_c2 matches 0 if score @s ec.kt_pts matches 1.. if score @s ec.kt_lvl >= #b_gate_iron ec.const run data modify entity @e[type=text_display,tag=ec.bn_c2,distance=..8,limit=1,sort=nearest] text set value [{text:"C2 ",color:"gold",bold:true},{text:"Disarming Blow",color:"gold"}]
execute if score @s ec.kt_n_c3 matches 1.. run data modify entity @e[type=text_display,tag=ec.bn_c3,distance=..8,limit=1,sort=nearest] text set value [{text:"C3 ",color:"gold",bold:true},{text:"Knight's Oath",color:"gold"}]
execute if score @s ec.kt_n_c3 matches 0 if score @s ec.kt_pts matches 1.. if score @s ec.kt_lvl >= #b_gate_iron ec.const run data modify entity @e[type=text_display,tag=ec.bn_c3,distance=..8,limit=1,sort=nearest] text set value [{text:"C3 ",color:"gold",bold:true},{text:"Knight's Oath",color:"gold"}]
execute if score @s ec.kt_n_c4 matches 1.. run data modify entity @e[type=text_display,tag=ec.bn_c4,distance=..8,limit=1,sort=nearest] text set value [{text:"C4 ",color:"gold",bold:true},{text:"Fencing Stance",color:"gold"}]
execute if score @s ec.kt_n_c4 matches 0 if score @s ec.kt_pts matches 1.. if score @s ec.kt_lvl >= #b_gate_iron ec.const run data modify entity @e[type=text_display,tag=ec.bn_c4,distance=..8,limit=1,sort=nearest] text set value [{text:"C4 ",color:"gold",bold:true},{text:"Fencing Stance",color:"gold"}]
execute if score @s ec.kt_n_c5 matches 1.. run data modify entity @e[type=text_display,tag=ec.bn_c5,distance=..8,limit=1,sort=nearest] text set value [{text:"C5 ",color:"gold",bold:true},{text:"Guard Stance",color:"gold"}]
execute if score @s ec.kt_n_c5 matches 0 if score @s ec.kt_pts matches 1.. if score @s ec.kt_lvl >= #b_gate_steel ec.const run data modify entity @e[type=text_display,tag=ec.bn_c5,distance=..8,limit=1,sort=nearest] text set value [{text:"C5 ",color:"gold",bold:true},{text:"Guard Stance",color:"gold"}]
execute if score @s ec.kt_n_c6 matches 1.. run data modify entity @e[type=text_display,tag=ec.bn_c6,distance=..8,limit=1,sort=nearest] text set value [{text:"C6 ",color:"gold",bold:true},{text:"Bladed Guard",color:"gold"}]
execute if score @s ec.kt_n_c6 matches 0 if score @s ec.kt_pts matches 1.. if score @s ec.kt_lvl >= #b_gate_steel ec.const run data modify entity @e[type=text_display,tag=ec.bn_c6,distance=..8,limit=1,sort=nearest] text set value [{text:"C6 ",color:"gold",bold:true},{text:"Bladed Guard",color:"gold"}]
execute if score @s ec.kt_n_c7 matches 1.. run data modify entity @e[type=text_display,tag=ec.bn_c7,distance=..8,limit=1,sort=nearest] text set value [{text:"C7 ",color:"gold",bold:true},{text:"Lunge",color:"gold"}]
execute if score @s ec.kt_n_c7 matches 0 if score @s ec.kt_pts matches 1.. if score @s ec.kt_lvl >= #b_gate_steel ec.const run data modify entity @e[type=text_display,tag=ec.bn_c7,distance=..8,limit=1,sort=nearest] text set value [{text:"C7 ",color:"gold",bold:true},{text:"Lunge",color:"gold"}]
execute if score @s ec.kt_n_c8 matches 1.. run data modify entity @e[type=text_display,tag=ec.bn_c8,distance=..8,limit=1,sort=nearest] text set value [{text:"C8 ",color:"gold",bold:true},{text:"Counter",color:"gold"}]
execute if score @s ec.kt_n_c8 matches 0 if score @s ec.kt_pts matches 1.. if score @s ec.kt_lvl >= #b_gate_steel ec.const run data modify entity @e[type=text_display,tag=ec.bn_c8,distance=..8,limit=1,sort=nearest] text set value [{text:"C8 ",color:"gold",bold:true},{text:"Counter",color:"gold"}]
execute if score @s ec.kt_n_c9 matches 1.. run data modify entity @e[type=text_display,tag=ec.bn_c9,distance=..8,limit=1,sort=nearest] text set value [{text:"C9 ",color:"gold",bold:true},{text:"Last Riposte",color:"gold"}]
execute if score @s ec.kt_n_c9 matches 0 if score @s ec.kt_pts matches 1.. if score @s ec.kt_lvl >= #b_gate_myth ec.const run data modify entity @e[type=text_display,tag=ec.bn_c9,distance=..8,limit=1,sort=nearest] text set value [{text:"C9 ",color:"gold",bold:true},{text:"Last Riposte",color:"gold"}]
execute if score @s ec.kt_n_c10 matches 1.. run data modify entity @e[type=text_display,tag=ec.bn_c10,distance=..8,limit=1,sort=nearest] text set value [{text:"C10 ",color:"gold",bold:true},{text:"Sword Lord",color:"gold"}]
execute if score @s ec.kt_n_c10 matches 0 if score @s ec.kt_pts matches 1.. if score @s ec.kt_lvl >= #b_gate_myth ec.const run data modify entity @e[type=text_display,tag=ec.bn_c10,distance=..8,limit=1,sort=nearest] text set value [{text:"C10 ",color:"gold",bold:true},{text:"Sword Lord",color:"gold"}]
execute if score @s ec.kt_n_c11 matches 1.. run data modify entity @e[type=text_display,tag=ec.bn_c11,distance=..8,limit=1,sort=nearest] text set value [{text:"C11 ",color:"gold",bold:true},{text:"Honor Mind",color:"gold"}]
execute if score @s ec.kt_n_c11 matches 0 if score @s ec.kt_pts matches 1.. if score @s ec.kt_lvl >= #b_gate_myth ec.const run data modify entity @e[type=text_display,tag=ec.bn_c11,distance=..8,limit=1,sort=nearest] text set value [{text:"C11 ",color:"gold",bold:true},{text:"Honor Mind",color:"gold"}]
execute if score @s ec.kt_n_c12 matches 1.. run data modify entity @e[type=text_display,tag=ec.bn_c12,distance=..8,limit=1,sort=nearest] text set value [{text:"C12 ",color:"gold",bold:true},{text:"Victor's Laurel",color:"gold"}]
execute if score @s ec.kt_n_c12 matches 0 if score @s ec.kt_pts matches 1.. if score @s ec.kt_lvl >= #b_gate_myth ec.const run data modify entity @e[type=text_display,tag=ec.bn_c12,distance=..8,limit=1,sort=nearest] text set value [{text:"C12 ",color:"gold",bold:true},{text:"Victor's Laurel",color:"gold"}]
