function evercraft:bough/codex/click_crown_generic {cls:"sk",crown_name:"Earthbreak",color_hex:"red"}
