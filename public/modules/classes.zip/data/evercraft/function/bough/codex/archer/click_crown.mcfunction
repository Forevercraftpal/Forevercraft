function evercraft:bough/codex/click_crown_generic {cls:"ar",crown_name:"Hawk Eye",color_hex:"aqua"}
