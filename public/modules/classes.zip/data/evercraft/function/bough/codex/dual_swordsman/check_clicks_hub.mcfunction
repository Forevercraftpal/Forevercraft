scoreboard players operation #bough_cc_sess ec.temp = @s ec.bough_sess
function evercraft:bough/codex/check_stat_btns
function evercraft:bough/codex/check_mast_node {cls:"ds",tier:"myth",cost:"1",node:"m1",label_short:"Bladestorm Mastery",label_full:"M1 Bladestorm Mastery",tier_full:"Mythril",desc:"While Dual Swordsman is active, attack speed +5%. ⚡ Right-click to arm Tempest — Strength II, 60s active · 60s cooldown."}
function evercraft:bough/codex/check_mast_node {cls:"ds",tier:"myth",cost:"1",node:"m2",label_short:"Mirror Match",label_full:"M2 Mirror Match",tier_full:"Mythril",desc:"While Dual Swordsman is active, attack speed +5%. The mirrored heart. ⚡ Right-click to arm Mirror Match — Speed II + Resistance (dodge), 60s active · 60s cooldown."}
function evercraft:bough/codex/check_mast_node {cls:"ds",tier:"anci",cost:"1",node:"m3",label_short:"Twin Step",label_full:"M3 Twin Step",tier_full:"Ancient",desc:"5% chance per kill to grant +200 Mastery XP. ⚡ Right-click to arm Twin Step — Speed III + Jump, 45s active · 10s cooldown."}
function evercraft:bough/codex/check_mast_node {cls:"ds",tier:"anci",cost:"1",node:"m4",label_short:"Bladestorm Echo",label_full:"M4 Bladestorm Echo",tier_full:"Ancient",desc:"Below 30% HP, gain Strength II + Speed II for 5s. 60s cooldown. The storm echoes. ⚡ Right-click to arm Bladestorm Echo — Strength II + Speed III, 30s active · 40s cooldown."}
function evercraft:bough/codex/check_mast_node {cls:"ds",tier:"anci",cost:"1",node:"m5",label_short:"Crown's Mirror",label_full:"M5 Crown's Mirror",tier_full:"Ancient",desc:"While Dual Swordsman is active, attack damage +5%. ✦ Right-click to arm Crown's Mirror (CROSS-CLASS ultimate) — Strength + Speed + Haste, lasts 5 min, 180s cooldown."}
function evercraft:bough/codex/check_crown_node {cls_path:"dual_swordsman",crown_name:"Bladestorm",cost_line:"Level 50 · 10 Mastery pts",effect_line:"Twin-blade kills trigger free Whirlwind (8s internal cooldown).",permanence:"No shield, no offhand items, no block. Until Reroot."}
function evercraft:bough/codex/check_branch_btns {cls_path:"dual_swordsman"}

# ===== REROOT (Wave 26 — Soul-Echo, 2-click confirm; cls_id 14 = Dual Swordsman) =====
execute as @e[type=interaction,tag=ec.bough_btn_reroot,distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s interaction on target run function evercraft:bough/reroot/confirm {cls_id:14}
execute as @e[type=interaction,tag=ec.bough_btn_reroot,distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=ec.bough_btn_reroot,distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Reroot (Soul-Echo)",b:"Wipes all nodes and refunds your spent points. Right-click twice within 5s to commit."}
execute as @e[type=interaction,tag=ec.bough_btn_reroot,distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s attack run data remove entity @s attack
# ===== RESONANCE (Wave 36 — balance readout; left-click = what is Resonance) =====
execute as @e[type=interaction,tag=ec.bough_btn_resonance,distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s interaction on target run function evercraft:bough/resonance/show {cls:"ds",class_name:"Dual Swordsman",color:"dark_purple"}
execute as @e[type=interaction,tag=ec.bough_btn_resonance,distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=ec.bough_btn_resonance,distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s attack on attacker run function evercraft:bough/resonance/info
execute as @e[type=interaction,tag=ec.bough_btn_resonance,distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s attack run data remove entity @s attack

# ===== RESONANCE LABEL RE-PAINT (Wave 36b — reflects hub spends without waiting for a rebuild) =====
function evercraft:bough/resonance/paint_label {cls:"ds",color:"dark_purple"}
