# === BOUGH CODEX — SESSION-AWARE OFF-ANCHOR CLOSE CHECK (BO-P2-CLOSE 2026-06-22) ===
# Run as @s = the viewer, at @s. Closes this viewer's page only if THEIR OWN
# anchor (matching ec.bough_sess) is no longer within 6 blocks. Replaces the old
# tick:27 "any ec.bough_anchor within 6 blocks" test, which left a viewer
# orphaned (never auto-closed) whenever they wandered off their own anchor but
# stayed near ANOTHER viewer's anchor of any class.
#
# Mechanism: snapshot the viewer's session, then tag EVERY in-range anchor whose
# session matches this viewer (an interim distance handle bounds the per-entity
# score compare to the ..6 box). Close if none was tagged, then strip the tag.
# The tag matches on session — globally unique per open — so it is correct across
# all 21 classes + DS and never confuses a neighbouring viewer's anchor for ours.

scoreboard players operation #bough_cl_sess ec.temp = @s ec.bough_sess
execute as @e[type=marker,tag=ec.bough_anchor,distance=..6] if score @s ec.bough_sess = #bough_cl_sess ec.temp run tag @s add ec.bough_own_anchor_chk
execute unless entity @e[type=marker,tag=ec.bough_own_anchor_chk] run function evercraft:bough/codex/close
tag @e[type=marker,tag=ec.bough_own_anchor_chk] remove ec.bough_own_anchor_chk
