# === BOUGH CODEX — UNIVERSAL CROWN CLICK (macro) ===
# Per-class click_crown wraps this with their {cls, cls_path, crown_name, crown_color, color_hex}.
# Usage: function evercraft:bough/codex/click_crown_generic {cls:"dn",crown_name:"Cloudstep",color_hex:"light_purple"}

execute if score @s ec.fx_snd matches 1.. run playsound minecraft:ui.button.click master @s ~ ~ ~ 0.5 1.4

$execute if score @s ec.$(cls)_b_crown matches 1.. run tellraw @s [{text:"[Tree] ",color:"gray"},{text:"Crown already owned. $(crown_name) is permanent until Reroot.",color:"yellow"}]
$execute if score @s ec.$(cls)_b_crown matches 1.. run return 0

$execute unless score @s ec.$(cls)_b_mast matches 10.. run tellraw @s [{text:"[Tree] ",color:"gray"},{text:"Crown locked — Mastery branch requires 10 points.",color:"red"}]
$execute unless score @s ec.$(cls)_b_mast matches 10.. run return 0

# Crown unlocks at the class's apex level (no point cost — the level IS the gate)
scoreboard players operation #b_need ec.temp = #b_gate_crown ec.const
$execute unless score @s ec.$(cls)_lvl >= #b_need ec.temp run tellraw @s [{text:"[Tree] ",color:"gray"},{text:"Crown locked — reach Level ",color:"red"},{score:{name:"#b_need",objective:"ec.temp"},color:"red",bold:true},{text:".",color:"red"}]
$execute unless score @s ec.$(cls)_lvl >= #b_need ec.temp run return 0

$scoreboard players set @s ec.$(cls)_b_crown 1

$data modify storage evercraft:notify stage.c set value [{text:"$(crown_name)",color:"$(color_hex)",bold:true,italic:false},{text:" — the bough crowns.",color:"$(color_hex)",italic:true,bold:false}]
scoreboard players set #ndur ec.temp 80
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. at @s run playsound minecraft:item.totem.use master @s ~ ~ ~ 0.6 0.7
