# === BOUGH CODEX — UNIVERSAL CROWN CHECK (macro) ===
# Right-click → per-class click_crown (Crown gate logic). Left-click → info.
# Usage: function evercraft:bough/codex/check_crown_node {cls_path:"dancer",crown_name:"Cloudstep",cost_line:"Level 50 · 10 Mastery pts",effect_line:"...",permanence:"Permanent until Reroot."}

$execute as @e[type=interaction,tag=ec.bough_node_crown,distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s interaction on target run function evercraft:bough/codex/$(cls_path)/click_crown
execute as @e[type=interaction,tag=ec.bough_node_crown,distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s interaction run data remove entity @s interaction
$execute as @e[type=interaction,tag=ec.bough_node_crown,distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"$(crown_name) (Crown)",b:"$(effect_line)"}
execute as @e[type=interaction,tag=ec.bough_node_crown,distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s attack run data remove entity @s attack
