# === CF CODEX → LIVING BOUGH ENTRY SHIM — Lamentor (class 6) ===
# Run as @s = the clicking player (via on target from crafting_classes/check_clicks).
# Mirrors codex/hub/classes/tree_click: snapshot the pending class id, tear the
# CraftForever codex GUI down in-place, then dispatch to the bough opener.
scoreboard players set @s ec.bough_craft_pending_cls 6
execute at @s run function evercraft:craftforever/codex/hub/close
function evercraft:bough/codex/open_craft_class
