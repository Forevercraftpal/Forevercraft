scoreboard players operation #bough_cc_sess ec.temp = @s ec.bough_sess
function evercraft:bough/codex/check_stat_btns
function evercraft:bough/codex/check_mast_node {cls:"sk",tier:"myth",cost:"1",node:"m1",label_short:"Earthtouch",label_full:"M1 Earthtouch",tier_full:"Mythril",desc:"Ground Slam cooldown -10s. ⚡ Right-click to arm Earthwrath — Strength II, 60s active · 60s cooldown."}
function evercraft:bough/codex/check_mast_node {cls:"sk",tier:"myth",cost:"1",node:"m2",label_short:"Pebble Hands",label_full:"M2 Pebble Hands",tier_full:"Mythril",desc:"Mining stone-tier blocks while wielding a mace grants +3 Impact (capped at 100). The pebbles charge your strike. ⚡ Right-click to arm Stoneguard — Resistance I, 60s active · 60s cooldown."}
function evercraft:bough/codex/check_mast_node {cls:"sk",tier:"anci",cost:"1",node:"m3",label_short:"Quake Listen",label_full:"M3 Quake Listen",tier_full:"Ancient",desc:"Ground Slam grants Slow Falling for 5 seconds. The earth holds its breath after the quake. ⚡ Right-click to arm Quaketrack — Speed II, 45s active · 10s cooldown."}
function evercraft:bough/codex/check_mast_node {cls:"sk",tier:"anci",cost:"1",node:"m4",label_short:"Lithify",label_full:"M4 Lithify",tier_full:"Ancient",desc:"Below 30% HP while wielding a mace, gain Resistance II + Absorption with a 3-block AoE pulse. 60s cooldown. The earth pulls you under its skin. ⚡ Right-click to arm Lithify — Resistance III + Absorption II, 30s active · 40s cooldown."}
function evercraft:bough/codex/check_mast_node {cls:"sk",tier:"anci",cost:"1",node:"m5",label_short:"Crown's Mountain",label_full:"M5 Crown's Mountain",tier_full:"Ancient",desc:"Earthbreak's 5th-strike Ground Slam range +1 block; movement penalty reduced to -20%. ✦ Right-click to arm Crown's Mountain (CROSS-CLASS ultimate) — Strength + Resistance, lasts 5 min, 180s cooldown."}
function evercraft:bough/codex/check_crown_node {cls_path:"striker",crown_name:"Earthbreak",cost_line:"Level 50 · 10 Mastery pts",effect_line:"Every 5th strike triggers a free Ground Slam.",permanence:"Movement speed -30% in combat only. Until Reroot."}
function evercraft:bough/codex/check_branch_btns {cls_path:"striker"}

# ===== REROOT (Wave 26 — Soul-Echo, 2-click confirm; cls_id 4 = Striker) =====
execute as @e[type=interaction,tag=ec.bough_btn_reroot,distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s interaction on target run function evercraft:bough/reroot/confirm {cls_id:4}
execute as @e[type=interaction,tag=ec.bough_btn_reroot,distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=ec.bough_btn_reroot,distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Reroot (Soul-Echo)",b:"Wipes all nodes and refunds your spent points. Right-click twice within 5s to commit."}
execute as @e[type=interaction,tag=ec.bough_btn_reroot,distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s attack run data remove entity @s attack
# ===== RESONANCE (Wave 36 — balance readout; left-click = what is Resonance) =====
execute as @e[type=interaction,tag=ec.bough_btn_resonance,distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s interaction on target run function evercraft:bough/resonance/show {cls:"sk",class_name:"Striker",color:"red"}
execute as @e[type=interaction,tag=ec.bough_btn_resonance,distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=ec.bough_btn_resonance,distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s attack on attacker run function evercraft:bough/resonance/info
execute as @e[type=interaction,tag=ec.bough_btn_resonance,distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s attack run data remove entity @s attack

# ===== RESONANCE LABEL RE-PAINT (Wave 36b — reflects hub spends without waiting for a rebuild) =====
function evercraft:bough/resonance/paint_label {cls:"sk",color:"red"}
