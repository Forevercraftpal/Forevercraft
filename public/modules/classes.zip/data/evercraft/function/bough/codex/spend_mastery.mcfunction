# === BOUGH CODEX — UNIVERSAL MASTERY SPEND (macro) ===
# Checks the 5-point unlock gate (5 Combat OR 5 Utility) then calls spend.
# Usage: function evercraft:bough/codex/spend_mastery {cls:"dn",tier:"myth",cost:"1",node:"m1",label:"Storm Step"}

scoreboard players set #mgate ec.temp 0
$execute if score @s ec.$(cls)_b_combat matches 5.. run scoreboard players set #mgate ec.temp 1
$execute if score @s ec.$(cls)_b_util matches 5.. run scoreboard players set #mgate ec.temp 1
execute if score #mgate ec.temp matches 0 run tellraw @s [{text:"[Tree] ",color:"gray"},{text:"Mastery locked — spend 5 in Combat or Utility first.",color:"red"}]
execute if score #mgate ec.temp matches 0 run return 0
$function evercraft:bough/spend {cls:"$(cls)",branch:"mast",tier:"$(tier)",cost:"$(cost)",node:"$(node)",label:"$(label)",color:"light_purple"}
