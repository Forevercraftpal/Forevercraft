scoreboard players operation #bough_sp_sess ec.temp = @s ec.bough_sess
execute if score @s ec.ds_bough_view matches 0 run function evercraft:bough/codex/dual_swordsman/stage_hub_disp
execute if score @s ec.ds_bough_view matches 0 at @e[type=marker,tag=ec.bough_anchor_ds,limit=1,sort=nearest] run function evercraft:bough/codex/dual_swordsman/spawn_hub_inner with storage evercraft:bough disp
execute if score @s ec.ds_bough_view matches 1 run function evercraft:bough/codex/dual_swordsman/stage_hub_disp
execute if score @s ec.ds_bough_view matches 1 at @e[type=marker,tag=ec.bough_anchor_ds,limit=1,sort=nearest] run function evercraft:bough/codex/dual_swordsman/spawn_combat_inner with storage evercraft:bough disp
execute if score @s ec.ds_bough_view matches 2 run function evercraft:bough/codex/dual_swordsman/stage_hub_disp
execute if score @s ec.ds_bough_view matches 2 at @e[type=marker,tag=ec.bough_anchor_ds,limit=1,sort=nearest] run function evercraft:bough/codex/dual_swordsman/spawn_utility_inner with storage evercraft:bough disp
execute at @e[type=marker,tag=ec.bough_anchor_ds,limit=1,sort=nearest] as @e[tag=ec.bough_el,tag=ec.bough_class_ds,distance=..8] unless score @s ec.bough_sess matches 1.. run scoreboard players operation @s ec.bough_sess = #bough_sp_sess ec.temp

# Hub view: paint the Resonance button label (Wave 36b — gold ★ while any unspent Resonance).
execute if score @s ec.ds_bough_view matches 0 run function evercraft:bough/resonance/paint_label {cls:"ds",color:"dark_purple"}
