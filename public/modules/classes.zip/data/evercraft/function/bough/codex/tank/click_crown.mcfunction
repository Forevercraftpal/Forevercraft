function evercraft:bough/codex/click_crown_generic {cls:"tk",crown_name:"Bulwark",color_hex:"blue"}
