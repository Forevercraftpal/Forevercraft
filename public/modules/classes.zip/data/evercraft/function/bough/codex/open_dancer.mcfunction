execute if entity @s[tag=ec.bough_viewing] run function evercraft:bough/codex/close
scoreboard players add #bough_next_sess ec.var 1
scoreboard players operation @s ec.bough_sess = #bough_next_sess ec.var
scoreboard players set @s ec.dn_bough_view 0
data modify storage evercraft:bough info set value [{text:"Left-click any node for more info! ",color:"gray",italic:true},{text:"Right-click to purchase!",color:"gray",italic:true}]
tag @s add ec.bough_viewing
tag @s add ec.bough_class_dn
scoreboard players operation #bough_dn_open ec.var = @s ec.bough_sess
tag @s add ec.bough_dn_opener
execute at @s anchored eyes rotated ~ 0 positioned ^ ^ ^2.0 run summon marker ~ ~ ~ {Tags:["ec.bough_anchor","ec.bough_anchor_dn","ec.bough_anchor_dn_new"]}
execute as @e[type=marker,tag=ec.bough_anchor_dn_new,limit=1] run scoreboard players operation @s ec.bough_sess = #bough_dn_open ec.var
execute as @e[type=marker,tag=ec.bough_anchor_dn_new,limit=1] run data modify entity @s Rotation[0] set from entity @p[tag=ec.bough_dn_opener,limit=1] Rotation[0]
execute at @e[type=marker,tag=ec.bough_anchor_dn_new,limit=1] run function evercraft:bough/codex/spawn_bg {cls:"dn"}
tag @s remove ec.bough_dn_opener
tag @e[type=marker,tag=ec.bough_anchor_dn_new] remove ec.bough_anchor_dn_new
function evercraft:bough/codex/dancer/spawn
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:item.book.page_turn master @s ~ ~ ~ 0.7 1.2
