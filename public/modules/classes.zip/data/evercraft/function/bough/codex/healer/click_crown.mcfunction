function evercraft:bough/codex/click_crown_generic {cls:"hl",crown_name:"Lifebound",color_hex:"green"}
