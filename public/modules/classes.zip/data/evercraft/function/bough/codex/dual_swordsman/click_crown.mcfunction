function evercraft:bough/codex/click_crown_generic {cls:"ds",crown_name:"Bladestorm",color_hex:"dark_purple"}
