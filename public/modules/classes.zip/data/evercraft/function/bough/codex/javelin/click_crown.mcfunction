function evercraft:bough/codex/click_crown_generic {cls:"jv",crown_name:"Skyspear",color_hex:"aqua"}
