# === BOUGH CODEX — UNIVERSAL CLOSE + BACK SCAN (macro) ===
# Handles the Close button (always present) and Back button (sub-pages).
# Usage: function evercraft:bough/codex/check_close_back {cls_path:"dancer"}

execute as @e[type=interaction,tag=ec.bough_close_btn,distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s interaction on target run function evercraft:bough/codex/close
execute as @e[type=interaction,tag=ec.bough_close_btn,distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=ec.bough_close_btn,distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Close",b:"Closes the Tree menu."}
execute as @e[type=interaction,tag=ec.bough_close_btn,distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s attack run data remove entity @s attack
execute unless entity @s[tag=ec.bough_viewing] run return 0

$execute as @e[type=interaction,tag=ec.bough_btn_back,distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s interaction on target run function evercraft:bough/codex/$(cls_path)/click_back
execute as @e[type=interaction,tag=ec.bough_btn_back,distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=ec.bough_btn_back,distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Back",b:"Returns to the Tree hub."}
execute as @e[type=interaction,tag=ec.bough_btn_back,distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s attack run data remove entity @s attack
