# Owned Crown → right-click toggles the Tidecaller's vow instead of "already owned".
execute if score @s ec.sc_b_crown matches 1.. run function evercraft:bough/sirencall/crown_toggle
execute if score @s ec.sc_b_crown matches 1.. run return 0
function evercraft:bough/codex/click_crown_generic {cls:"sc",crown_name:"Tidecaller's Vow",color_hex:"aqua"}
