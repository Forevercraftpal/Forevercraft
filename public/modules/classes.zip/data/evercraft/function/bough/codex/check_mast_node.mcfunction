# === BOUGH CODEX — UNIVERSAL MASTERY NODE CHECK (macro) ===
# Mastery node right-click goes through the gate-aware spend_mastery; left-click
# emits the info macro. Used by every class's check_clicks_hub.
# Usage: function evercraft:bough/codex/check_mast_node {cls:"dn",tier:"myth",cost:"1",node:"m1",label_short:"Storm Step",label_full:"M1 Storm Step",tier_full:"Mythril",desc:"Sprint speed +20%."}

$execute as @e[type=interaction,tag=ec.bough_node_$(node),distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s interaction on target run function evercraft:bough/codex/spend_mastery {cls:"$(cls)",tier:"$(tier)",cost:"$(cost)",node:"$(node)",label:"$(label_short)"}
$execute as @e[type=interaction,tag=ec.bough_node_$(node),distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s interaction run data remove entity @s interaction
$execute as @e[type=interaction,tag=ec.bough_node_$(node),distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s attack on attacker run function evercraft:bough/info {label:"$(label_full)",tier:"$(tier_full)",cost:"$(cost)",desc:"$(desc)"}
$execute as @e[type=interaction,tag=ec.bough_node_$(node),distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s attack run data remove entity @s attack
