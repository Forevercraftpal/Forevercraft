scoreboard players operation #bough_cc_sess ec.temp = @s ec.bough_sess
function evercraft:bough/codex/check_stat_btns
function evercraft:bough/codex/check_mast_node {cls:"ht",tier:"myth",cost:"1",node:"m1",label_short:"Hunt Mastery",label_full:"M1 Hunt Mastery",tier_full:"Mythril",desc:"While Hunter is active, attack damage +5%."}
function evercraft:bough/codex/check_mast_node {cls:"ht",tier:"myth",cost:"1",node:"m2",label_short:"Field Dressing",label_full:"M2 Field Dressing",tier_full:"Mythril",desc:"Each kill restores 1 heart. The field hand knows the muscle."}
function evercraft:bough/codex/check_mast_node {cls:"ht",tier:"anci",cost:"1",node:"m3",label_short:"Spoor",label_full:"M3 Spoor",tier_full:"Ancient",desc:"5% chance per kill to grant +200 Mastery XP."}
function evercraft:bough/codex/check_mast_node {cls:"ht",tier:"anci",cost:"1",node:"m4",label_short:"Death Mark",label_full:"M4 Death Mark",tier_full:"Ancient",desc:"Below 30% HP, gain Resistance II + Speed I for 5s. 60s cooldown. The hunt steadies."}
function evercraft:bough/codex/check_mast_node {cls:"ht",tier:"anci",cost:"1",node:"m5",label_short:"Crown's Mark",label_full:"M5 Crown's Mark",tier_full:"Ancient",desc:"While Hunter is active, attack damage +5%."}
function evercraft:bough/codex/check_crown_node {cls_path:"hunter",crown_name:"Mark of Death",cost_line:"Level 50 · 10 Mastery pts",effect_line:"Marked enemies take 2× damage from you; allies deal +25%.",permanence:"Marking costs 1 heart. Until Reroot."}
function evercraft:bough/codex/check_branch_btns {cls_path:"hunter"}

# ===== REROOT (Wave 26 — Soul-Echo, 2-click confirm; cls_id 11 = Hunter) =====
execute as @e[type=interaction,tag=ec.bough_btn_reroot,distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s interaction on target run function evercraft:bough/reroot/confirm {cls_id:11}
execute as @e[type=interaction,tag=ec.bough_btn_reroot,distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=ec.bough_btn_reroot,distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Reroot (Soul-Echo)",b:"Wipes all nodes and refunds your spent points. Right-click twice within 5s to commit."}
execute as @e[type=interaction,tag=ec.bough_btn_reroot,distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s attack run data remove entity @s attack
# ===== RESONANCE (Wave 36 — balance readout; left-click = what is Resonance) =====
execute as @e[type=interaction,tag=ec.bough_btn_resonance,distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s interaction on target run function evercraft:bough/resonance/show {cls:"ht",class_name:"Hunter",color:"aqua"}
execute as @e[type=interaction,tag=ec.bough_btn_resonance,distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=ec.bough_btn_resonance,distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s attack on attacker run function evercraft:bough/resonance/info
execute as @e[type=interaction,tag=ec.bough_btn_resonance,distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s attack run data remove entity @s attack

# ===== RESONANCE LABEL RE-PAINT (Wave 36b — reflects hub spends without waiting for a rebuild) =====
function evercraft:bough/resonance/paint_label {cls:"ht",color:"aqua"}
