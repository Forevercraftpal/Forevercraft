scoreboard players operation #bough_cc_sess ec.temp = @s ec.bough_sess
function evercraft:bough/codex/check_stat_btns
function evercraft:bough/codex/check_mast_node {cls:"jv",tier:"myth",cost:"1",node:"m1",label_short:"Throwing Mastery",label_full:"M1 Throwing Mastery",tier_full:"Mythril",desc:"While Javelin is active, gain +5% movement speed. The throwing arm is light."}
function evercraft:bough/codex/check_mast_node {cls:"jv",tier:"myth",cost:"1",node:"m2",label_short:"Returning Tide",label_full:"M2 Returning Tide",tier_full:"Mythril",desc:"Below 30% HP, gain Speed I. The tide carries her home."}
function evercraft:bough/codex/check_mast_node {cls:"jv",tier:"anci",cost:"1",node:"m3",label_short:"Skyspear Tracking",label_full:"M3 Skyspear Tracking",tier_full:"Ancient",desc:"5% chance per kill to grant +200 Mastery XP."}
function evercraft:bough/codex/check_mast_node {cls:"jv",tier:"anci",cost:"1",node:"m4",label_short:"Parting Throw",label_full:"M4 Parting Throw",tier_full:"Ancient",desc:"Below 30% HP, gain Strength II + Speed I for 5s. 60s cooldown. One last spear."}
function evercraft:bough/codex/check_mast_node {cls:"jv",tier:"anci",cost:"1",node:"m5",label_short:"Crown's Skyspear",label_full:"M5 Crown's Skyspear",tier_full:"Ancient",desc:"While Javelin is active, attack damage +5%. The spear remembers."}
function evercraft:bough/codex/check_crown_node {cls_path:"javelin",crown_name:"Skyspear",cost_line:"Level 50 · 10 Mastery pts",effect_line:"Thrown spears have infinite return and triple range.",permanence:"Melee damage is halved. Until Reroot."}
function evercraft:bough/codex/check_branch_btns {cls_path:"javelin"}

# ===== REROOT (Wave 26 — Soul-Echo, 2-click confirm; cls_id 8 = Javelin) =====
execute as @e[type=interaction,tag=ec.bough_btn_reroot,distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s interaction on target run function evercraft:bough/reroot/confirm {cls_id:8}
execute as @e[type=interaction,tag=ec.bough_btn_reroot,distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=ec.bough_btn_reroot,distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Reroot (Soul-Echo)",b:"Wipes all nodes and refunds your spent points. Right-click twice within 5s to commit."}
execute as @e[type=interaction,tag=ec.bough_btn_reroot,distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s attack run data remove entity @s attack
# ===== RESONANCE (Wave 36 — balance readout; left-click = what is Resonance) =====
execute as @e[type=interaction,tag=ec.bough_btn_resonance,distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s interaction on target run function evercraft:bough/resonance/show {cls:"jv",class_name:"Javelin",color:"aqua"}
execute as @e[type=interaction,tag=ec.bough_btn_resonance,distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=ec.bough_btn_resonance,distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s attack on attacker run function evercraft:bough/resonance/info
execute as @e[type=interaction,tag=ec.bough_btn_resonance,distance=..6] if score @s ec.bough_sess = #bough_cc_sess ec.temp if data entity @s attack run data remove entity @s attack

# ===== RESONANCE LABEL RE-PAINT (Wave 36b — reflects hub spends without waiting for a rebuild) =====
function evercraft:bough/resonance/paint_label {cls:"jv",color:"aqua"}
