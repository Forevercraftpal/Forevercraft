scoreboard players operation #bough_cc_sess ec.temp = @s ec.bough_sess
function evercraft:bough/codex/check_close_back {cls_path:"striker"}
execute if score @s ec.sk_bough_view matches 0 run function evercraft:bough/codex/striker/check_clicks_hub
execute if score @s ec.sk_bough_view matches 1 run function evercraft:bough/codex/striker/check_clicks_combat
execute if score @s ec.sk_bough_view matches 2 run function evercraft:bough/codex/striker/check_clicks_utility
