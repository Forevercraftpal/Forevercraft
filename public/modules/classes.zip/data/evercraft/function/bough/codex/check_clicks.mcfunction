# === BOUGH CODEX — CHECK CLICKS (per-viewer) ===
# Run as @s = a player with ec.bough_viewing, at @s. Dispatches to the right
# per-class click handler based on which class tag is set.

execute if entity @s[tag=ec.bough_class_bk] run function evercraft:bough/codex/berserker/check_clicks
execute if entity @s[tag=ec.bough_class_rg] run function evercraft:bough/codex/rogue/check_clicks
execute if entity @s[tag=ec.bough_class_dn] run function evercraft:bough/codex/dancer/check_clicks
execute if entity @s[tag=ec.bough_class_sk] run function evercraft:bough/codex/striker/check_clicks
execute if entity @s[tag=ec.bough_class_sn] run function evercraft:bough/codex/sentinel/check_clicks
execute if entity @s[tag=ec.bough_class_hl] run function evercraft:bough/codex/healer/check_clicks
execute if entity @s[tag=ec.bough_class_bl] run function evercraft:bough/codex/beastlord/check_clicks
execute if entity @s[tag=ec.bough_class_jv] run function evercraft:bough/codex/javelin/check_clicks
execute if entity @s[tag=ec.bough_class_hp] run function evercraft:bough/codex/hoplite/check_clicks
execute if entity @s[tag=ec.bough_class_ar] run function evercraft:bough/codex/archer/check_clicks
execute if entity @s[tag=ec.bough_class_ht] run function evercraft:bough/codex/hunter/check_clicks
execute if entity @s[tag=ec.bough_class_tk] run function evercraft:bough/codex/tank/check_clicks
execute if entity @s[tag=ec.bough_class_kt] run function evercraft:bough/codex/knight/check_clicks
execute if entity @s[tag=ec.bough_class_ds] run function evercraft:bough/codex/dual_swordsman/check_clicks
execute if entity @s[tag=ec.bough_class_ss] run function evercraft:bough/codex/stonestrike/check_clicks
execute if entity @s[tag=ec.bough_class_lf] run function evercraft:bough/codex/lumberfell/check_clicks
execute if entity @s[tag=ec.bough_class_gs] run function evercraft:bough/codex/growseer/check_clicks
execute if entity @s[tag=ec.bough_class_tw] run function evercraft:bough/codex/terrawarp/check_clicks
execute if entity @s[tag=ec.bough_class_sc] run function evercraft:bough/codex/sirencall/check_clicks
execute if entity @s[tag=ec.bough_class_lm] run function evercraft:bough/codex/lamentor/check_clicks
execute if entity @s[tag=ec.bough_class_gw] run function evercraft:bough/codex/gearwright/check_clicks
