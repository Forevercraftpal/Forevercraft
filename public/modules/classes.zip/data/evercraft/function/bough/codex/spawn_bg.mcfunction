# === BOUGH CODEX — Background panel (Joseph 2026-06-15) ===
# Macro: $(cls). Run AT the class's anchor marker (so carets match the page
# content). Mirrors the Adv codex's Adv.MenuBG — a flat black_stained_glass_pane
# item_display sitting just behind the page content. Tagged ec.bough_el +
# ec.bough_class_<cls> so it is session-stamped, rebuilt, and closed alongside
# the rest of the page. Centered on the content (~^-0.05) and pushed +0.06 along
# the page's forward axis so every text element renders in front of it.
$execute positioned ^ ^-0.05 ^0.06 run summon item_display ~ ~ ~ {Tags:["ec.bough_el","ec.bough_class_$(cls)","ec.bough_bg"],billboard:"center",item:{id:"black_stained_glass_pane",count:1},item_display:"fixed",transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[3.6f,3.3f,0.01f]}}
