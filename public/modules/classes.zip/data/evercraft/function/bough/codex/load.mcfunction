# === BOUGH CODEX — LOAD ===
# Shared infrastructure for the Living Bough GUI surface. Self-contained from
# the main codex hub (no Adv.MenuAnchor dependency for this slice — the bough
# pages spawn floating in front of the player on demand). Codex-hub integration
# (entering from class detail Page 2) is queued as the next slice.

# Per-viewer session id — increments every open to disambiguate races (two
# players opening at the same time can't share entity selectors).
scoreboard objectives add ec.bough_sess dummy "Bough Viewer Session"

# Pending class_id snapshot — set by codex/hub/classes/tree_click before the
# codex GUI is torn down (which wipes adv.gui_cls_id), then read by
# bough/codex/open_class to route to the right bough opener.
scoreboard objectives add ec.bough_pending_cls dummy "Bough Pending Class ID"

# Page-dirty flag (2026-06-14): the bough page is now ANCHORED (no view-follow).
# A pending click sets this in the tick; the tick then rebuilds the page in place
# at the fixed anchor and clears it. Replaces the old refollow reposition.
scoreboard objectives add ec.bough_dirty dummy "Bough Page Needs Rebuild"

# Schedule the bough click tick (2t cadence — same as satchel menu).
schedule function evercraft:bough/codex/tick 2t
