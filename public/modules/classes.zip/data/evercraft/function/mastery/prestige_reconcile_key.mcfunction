# Reconcile ONE enchant key on a prestiging item (weapon or armor).
# Macro args: $(key) = enchant id without namespace, $(tag) = wm_temp | am_temp
# Caller must set #mr_ceil ec.var = max_level + OLD prestige
#   (= the level a pure mastery enchant sits at when you prestige, since you prestige at max level).
#
# Rule:
#   - level <= ceiling  -> pure mastery -> REMOVE (regrows from the new floor as the item re-levels)
#   - level >  ceiling  -> the player boosted it above mastery -> KEEP and grow +1 (clamp 10)
# Manual BINARY enchants (silk_touch, curses, infinity, channeling, multishot, flame, aqua_affinity)
# are not mastery keys and are never passed here, so they're left untouched — preserved, never grown.
scoreboard players set #mr_cur ec.var 0
$execute store result score #mr_cur ec.var run data get entity @e[type=hopper_minecart,tag=$(tag),limit=1] Items[0].components."minecraft:enchantments"."minecraft:$(key)"
$execute if score #mr_cur ec.var matches 1.. if score #mr_cur ec.var <= #mr_ceil ec.var run data remove entity @e[type=hopper_minecart,tag=$(tag),limit=1] Items[0].components."minecraft:enchantments"."minecraft:$(key)"
execute if score #mr_cur ec.var > #mr_ceil ec.var run scoreboard players add #mr_cur ec.var 1
execute if score #mr_cur ec.var matches 11.. run scoreboard players set #mr_cur ec.var 10
$execute if score #mr_cur ec.var > #mr_ceil ec.var store result entity @e[type=hopper_minecart,tag=$(tag),limit=1] Items[0].components."minecraft:enchantments"."minecraft:$(key)" int 1 run scoreboard players get #mr_cur ec.var
