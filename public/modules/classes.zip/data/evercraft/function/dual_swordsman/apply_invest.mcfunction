# === DUAL SWORDSMAN — BOUGH-INVESTMENT ATTACK SPEED ===
# Joseph 2026-06-19. Class-wide (both the Fencer path and the spirit twins): every Bough point
# SPENT into the Dual Swordsman tree grants +0.1 attack speed. Points spent = lifetime earned
# (ec.ds_pte) minus currently-available (ec.ds_pts). Run as @s (a ds_active player) — called every
# tick from dual_swordsman/tick (cheap: only re-applies the attribute when the count changes) and
# once on activation from detect / detect_fencer.
#
# The matching +0.5-heart-per-point whirlwind damage lives in dual_swordsman/whirlwind_strike.
# SOLE writer of ec.ds_inv_last (the change-guard cache).

# Points invested into DS (clamp at 0 — reroot can momentarily make pte<pts mid-write).
scoreboard players operation #ds_inv ec.temp = @s ec.ds_pte
scoreboard players operation #ds_inv ec.temp -= @s ec.ds_pts
execute if score #ds_inv ec.temp matches ..0 run scoreboard players set #ds_inv ec.temp 0

# No change since last apply -> nothing to do (keeps the per-tick cost to 3 score ops).
execute if score #ds_inv ec.temp = @s ec.ds_inv_last run return 0
scoreboard players operation @s ec.ds_inv_last = #ds_inv ec.temp

# Re-stamp the investment attack-speed modifier (separate id from the spirit-twin one so they stack).
attribute @s minecraft:attack_speed modifier remove evercraft:ds_invest_speed
# 0 invested -> leave it removed (no modifier). Otherwise add invest*0.1 via macro.
execute store result storage evercraft:ds_invest amt double 0.1 run scoreboard players get #ds_inv ec.temp
execute if score #ds_inv ec.temp matches 1.. run function evercraft:dual_swordsman/apply_invest_speed with storage evercraft:ds_invest
