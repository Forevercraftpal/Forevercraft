# === DUAL SWORDSMAN — UNLOCK ??? BAR: UPDATE ===
# Run as @s = a player whose ec.ds_prog just changed (on_kill / grant_boss / the unlock reveal).
# Claims/re-asserts a pool slot, computes fill = ds_prog*100/1000 (clamped 0..100), stamps the 8s
# auto-hide deadline, picks the label (??? while locked, "Dual Swordsman" once earned), and renders.
# Mirrors craft_affinity/live_bar/update but reads a single unlock track instead of per-class XP.

# Ensure a pool slot (claim lazily; re-assert if held so a reload can't double-allocate).
execute if score @s ec.ds_bar_slot matches 1.. run function evercraft:dual_swordsman/unlock/reassert_slot
execute unless score @s ec.ds_bar_slot matches 1.. run function evercraft:dual_swordsman/unlock/claim_slot
# Pool full -> no bar (progress still tracked normally).
execute unless score @s ec.ds_bar_slot matches 1.. run return 0

# Fill 0..100 = ds_prog * 100 / goal (per-player: 1000/5000/10000 by difficulty). Clamp to int range.
function evercraft:dual_swordsman/unlock/calc_goal
scoreboard players operation #ds_fill ec.temp = @s ec.ds_prog
scoreboard players operation #ds_fill ec.temp *= #ds_100 ec.var
scoreboard players operation #ds_fill ec.temp /= #ds_goal ec.temp
execute if score #ds_fill ec.temp matches 101.. run scoreboard players set #ds_fill ec.temp 100
execute if score #ds_fill ec.temp matches ..0 run scoreboard players set #ds_fill ec.temp 0

# Stamp the 8s (160t) auto-hide deadline + live flag (existence gate for the hide-tick).
execute store result score @s ec.ds_bar_until run time query gametime
scoreboard players add @s ec.ds_bar_until 160
scoreboard players set @s ec.ds_bar_live 1

# Label/colors: mysterious "???" (white bar) while locked; "Dual Swordsman" (purple bar) once earned.
data modify storage evercraft:ds_livebar label set value "???"
data modify storage evercraft:ds_livebar lcolor set value "gray"
data modify storage evercraft:ds_livebar bcolor set value "white"
execute if score @s ec.ds_unlocked matches 1.. run data modify storage evercraft:ds_livebar label set value "Dual Swordsman"
execute if score @s ec.ds_unlocked matches 1.. run data modify storage evercraft:ds_livebar lcolor set value "dark_purple"
execute if score @s ec.ds_unlocked matches 1.. run data modify storage evercraft:ds_livebar bcolor set value "purple"

# Push render args to storage, then render the player's pooled bar.
execute store result storage evercraft:ds_livebar barslot int 1 run scoreboard players get @s ec.ds_bar_slot
execute store result storage evercraft:ds_livebar fill int 1 run scoreboard players get #ds_fill ec.temp
function evercraft:dual_swordsman/unlock/render with storage evercraft:ds_livebar
