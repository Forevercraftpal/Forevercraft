# === DUAL SWORDSMAN — UNLOCK: HOSTILE KILL (+1 progress) ===
# Reward fn for advancement evercraft:dual_swordsman/unlock/kill (run as @s = the killer). Revoke-self
# so the advancement re-arms for the next kill. Only SEEKING players (dual-wielding two single-hand
# Fencer swords AND not yet unlocked — tag ec.ds_seeking, set in artifacts/knight/tick) accrue; every
# other killer just pays one cheap revoke + tag check and returns.
advancement revoke @s only evercraft:dual_swordsman/unlock/kill
execute unless entity @s[tag=ec.ds_seeking] run return 0
# Already earned? nothing to grind (seeking is dropped on unlock, but guard against a same-tick race).
execute if score @s ec.ds_unlocked matches 1.. run return 0
# Authoritative dual-wield check — only a kill made while ACTUALLY holding two single-hand Fencer
# swords counts (closes the rare stale-tag window, e.g. logout-relog with different gear).
execute unless items entity @s weapon.mainhand *[custom_data~{knight:true}] run return 0
execute unless items entity @s weapon.offhand *[custom_data~{knight:true}] run return 0

scoreboard players add @s ec.ds_prog 1
function evercraft:dual_swordsman/unlock/calc_goal
execute if score @s ec.ds_prog > #ds_goal ec.temp run scoreboard players operation @s ec.ds_prog = #ds_goal ec.temp
function evercraft:dual_swordsman/unlock/update
function evercraft:dual_swordsman/unlock/check_unlock
