# === DUAL SWORDSMAN — UNLOCK TRACK: LOAD ===
# Called from init.mcfunction (after dual_swordsman/load). Sets up the EARNED "Fencer dual-wield ->
# Dual Swordsman" progression: the ??? bossbar (1000 hostile kills; a world boss = +250 = 25%), the
# persistent unlock flag, and the pooled bar plumbing (a leak-safe clone of craft_affinity/live_bar).
# The DS class kit objectives (ec.ds_active / ec.ds_twin / ec.ds_tier / ec.ds_whirl_cd /
# ec.ds_ability_cd) are declared in spirit/load — do NOT redeclare them here.

# Progress + unlock state (persistent across reload).
#   ec.ds_prog     — ??? progress 0..goal (goal = 1000/5000/10000 by difficulty; see unlock/calc_goal).
#                    SOLE writers: unlock/on_kill (+1) + unlock/grant_boss (+25% of goal).
#   ec.ds_unlocked — 1 once earned; gates the Fencer-sword DS activation. SOLE writer: unlock/check_unlock.
scoreboard objectives add ec.ds_prog dummy "DS Unlock Progress"
scoreboard objectives add ec.ds_unlocked dummy "DS Unlock Earned"

# Per-player ??? bar state (mirror of the caff live-bar state objectives).
#   ec.ds_bar_until — gametime stamp to auto-hide. SOLE writer: unlock/update.
#   ec.ds_bar_live  — 1 while a ??? bar is visible (existence gate for the hide-tick).
#                     Writers: unlock/update (set 1) + unlock/hide_now (set 0).
#   ec.ds_bar_slot  — claimed pool slot 1..8. SOLE writer: unlock/do_claim.
scoreboard objectives add ec.ds_bar_until dummy "DS bar hide-at gametime"
scoreboard objectives add ec.ds_bar_live dummy "DS bar visible flag"
scoreboard objectives add ec.ds_bar_slot dummy "DS bar pool slot"

# Pool-registry objective (0=free, 1=taken). POOL-REGISTRY MULTI-WRITER by design (load reset +
# do_claim + do_reassert + hide-tick release) — exactly like the caff pool. Holds only #dsslot_1..8.
scoreboard objectives add ec.ds_barslot dummy "DS bar pool registry"

# Math constants. The full-bar kill goal is per-player (1000 Newcomer / 5000 Adventurer / 10000
# Pioneer) and computed live by unlock/calc_goal from ec.difficulty; it is NOT a global const.
#   #ds_100 — bar value max (fill is 0..100).
#   #ds_4   — world-boss credit divisor (goal / 4 = 25% of the track).
scoreboard players set #ds_100 ec.var 100
scoreboard players set #ds_4 ec.var 4

# DS-class-wide (both paths): change-guard cache for the bough-investment attack speed
# (ec.ds_pte - ec.ds_pts). SOLE writer: dual_swordsman/apply_invest (+ reset to -1 in remove).
scoreboard objectives add ec.ds_inv_last dummy "DS bough-invest cache"

# 8-bar bossbar pool (far fewer concurrent DS-seekers than crafting gatherers, so 8 < the caff 16).
bossbar add evercraft:dsbar_1 ""
bossbar add evercraft:dsbar_2 ""
bossbar add evercraft:dsbar_3 ""
bossbar add evercraft:dsbar_4 ""
bossbar add evercraft:dsbar_5 ""
bossbar add evercraft:dsbar_6 ""
bossbar add evercraft:dsbar_7 ""
bossbar add evercraft:dsbar_8 ""

# Configure pool (max 100, empty name, hidden) + reset registry to all-free.
function evercraft:dual_swordsman/unlock/init_pool

# Start the ??? bar auto-hide tick (1s). replace so a reload doesn't stack schedules.
schedule function evercraft:dual_swordsman/unlock/tick 1s replace
