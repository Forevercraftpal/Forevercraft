# === DUAL SWORDSMAN — UNLOCK ??? BAR: CLAIM POOL SLOT ===
# Run as @s = player needing a ??? bar slot for the first time this session. Claims the first free
# slot from the 8-bar pool (evercraft:dsbar_1..8). Clone of craft_affinity/live_bar/claim_slot. If
# the pool is full the player simply gets no bar (progress still tracked) — update bails on the
# unset ec.ds_bar_slot. 8 concurrent DS-seekers comfortably exceeds any realm's real count.
execute if score #dsslot_1 ec.ds_barslot matches 0 run function evercraft:dual_swordsman/unlock/do_claim {slot:1}
execute if score @s ec.ds_bar_slot matches 1.. run return 0
execute if score #dsslot_2 ec.ds_barslot matches 0 run function evercraft:dual_swordsman/unlock/do_claim {slot:2}
execute if score @s ec.ds_bar_slot matches 1.. run return 0
execute if score #dsslot_3 ec.ds_barslot matches 0 run function evercraft:dual_swordsman/unlock/do_claim {slot:3}
execute if score @s ec.ds_bar_slot matches 1.. run return 0
execute if score #dsslot_4 ec.ds_barslot matches 0 run function evercraft:dual_swordsman/unlock/do_claim {slot:4}
execute if score @s ec.ds_bar_slot matches 1.. run return 0
execute if score #dsslot_5 ec.ds_barslot matches 0 run function evercraft:dual_swordsman/unlock/do_claim {slot:5}
execute if score @s ec.ds_bar_slot matches 1.. run return 0
execute if score #dsslot_6 ec.ds_barslot matches 0 run function evercraft:dual_swordsman/unlock/do_claim {slot:6}
execute if score @s ec.ds_bar_slot matches 1.. run return 0
execute if score #dsslot_7 ec.ds_barslot matches 0 run function evercraft:dual_swordsman/unlock/do_claim {slot:7}
execute if score @s ec.ds_bar_slot matches 1.. run return 0
execute if score #dsslot_8 ec.ds_barslot matches 0 run function evercraft:dual_swordsman/unlock/do_claim {slot:8}
