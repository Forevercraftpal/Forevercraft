# === DUAL SWORDSMAN — UNLOCK ??? BAR: DO HIDE (MACRO) ===
# Call: function .../do_hide with storage evercraft:ds_livebar   (storage {barslot:N})
# Sets the pooled bossbar invisible. Pure bossbar writer (no scoreboard writes).
$bossbar set evercraft:dsbar_$(barslot) visible false
