# === DUAL SWORDSMAN — UNLOCK ??? BAR: RENDER (MACRO) ===
# Call: function .../render with storage evercraft:ds_livebar
#   storage: {barslot:N, fill:0..100, label:"...", lcolor:"...", bcolor:"..."}
# Run as @s = the viewing player. Writes value/color/name to the pooled bossbar (evercraft:dsbar_N),
# assigns @s as the SOLE viewer, and shows it. Pure macro bossbar writer (no scoreboard writes).
# #ds_fill ec.temp holds the value (set by update just before this call).

$execute store result bossbar evercraft:dsbar_$(barslot) value run scoreboard players get #ds_fill ec.temp
$bossbar set evercraft:dsbar_$(barslot) color $(bcolor)
$bossbar set evercraft:dsbar_$(barslot) name ["",{text:"$(label)",color:"$(lcolor)",bold:true},{text:"   ",color:"gray"},{text:"$(fill)",color:"white"},{text:"%",color:"gray"}]
$bossbar set evercraft:dsbar_$(barslot) players @s
$bossbar set evercraft:dsbar_$(barslot) visible true
