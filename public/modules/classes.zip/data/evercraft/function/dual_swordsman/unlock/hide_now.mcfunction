# === DUAL SWORDSMAN — UNLOCK ??? BAR: HIDE NOW ===
# Run as @s = player whose ??? bar should hide (8s timeout elapsed in tick). Sets the pooled bossbar
# invisible and clears the live flag. The pool SLOT is kept for the session (instant re-show on the
# next kill). Co-writer (with update) of ec.ds_bar_live (sets 0).
execute unless score @s ec.ds_bar_slot matches 1.. run return 0
execute store result storage evercraft:ds_livebar barslot int 1 run scoreboard players get @s ec.ds_bar_slot
function evercraft:dual_swordsman/unlock/do_hide with storage evercraft:ds_livebar
scoreboard players set @s ec.ds_bar_live 0
