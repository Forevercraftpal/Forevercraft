# === DUAL SWORDSMAN — UNLOCK: WORLD BOSS CREDIT ===
# Run as @s = a SEEKING world-boss participant (filtered by the caller @a[tag=wb.participant,
# tag=ec.ds_seeking] in bosses/rewards/on_kill). A single world boss fills 25% of the goal for
# Newcomer / Adventurer (goal / #ds_4 = 250 / 1250); on PIONEER it is a FLAT +250 (~2.5% of the 10k
# goal) so the hardcore grind can't be shortcut by boss farming. For Pioneers this is also the hard
# prerequisite -> check_unlock verifies ach.boss_kills>=1 before unlocking. Caps at the per-player goal.
execute if score @s ec.ds_unlocked matches 1.. run return 0
function evercraft:dual_swordsman/unlock/calc_goal
scoreboard players operation #ds_boss ec.temp = #ds_goal ec.temp
scoreboard players operation #ds_boss ec.temp /= #ds_4 ec.var
execute if score @s ec.difficulty matches 3 run scoreboard players set #ds_boss ec.temp 250
scoreboard players operation @s ec.ds_prog += #ds_boss ec.temp
execute if score @s ec.ds_prog > #ds_goal ec.temp run scoreboard players operation @s ec.ds_prog = #ds_goal ec.temp
function evercraft:dual_swordsman/unlock/update
function evercraft:dual_swordsman/unlock/check_unlock
