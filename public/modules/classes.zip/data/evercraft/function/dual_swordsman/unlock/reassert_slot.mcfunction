# === DUAL SWORDSMAN — UNLOCK ??? BAR: RE-ASSERT SLOT OWNERSHIP ===
# Run as @s = player who already holds a persistent ec.ds_bar_slot. Re-stamps the registry fakeplayer
# to 1 so a /reload (which zeroes #dsslot_N in init_pool) can never let a second player claim this
# same slot. One macro write. Registry is multi-writer by design (do_claim + this + hide release).
execute store result storage evercraft:ds_livebar barslot int 1 run scoreboard players get @s ec.ds_bar_slot
function evercraft:dual_swordsman/unlock/do_reassert with storage evercraft:ds_livebar
