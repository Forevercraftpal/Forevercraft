# === DUAL SWORDSMAN — UNLOCK ??? BAR: DO CLAIM (MACRO) ===
# Call: function .../do_claim {slot:N}   (N = 1..8)
# Run as @s = claiming player. Marks the registry slot taken + records it on the player.
# SOLE writer of ec.ds_bar_slot; co-writer of the #dsslot_N pool registry (sets 1).
$scoreboard players set @s ec.ds_bar_slot $(slot)
$scoreboard players set #dsslot_$(slot) ec.ds_barslot 1
