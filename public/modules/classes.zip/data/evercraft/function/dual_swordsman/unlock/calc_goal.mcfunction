# === DUAL SWORDSMAN — UNLOCK: PER-PLAYER KILL GOAL ===
# Run as @s. Sets #ds_goal ec.temp to the ??? track's full-bar kill goal, scaled by difficulty:
#   Newcomer (ec.difficulty 1 / unset) = 1000; Adventurer (2) = 5000; Pioneer (3) = 10000.
# Called fresh by check_unlock / update / on_kill / grant_boss so the goal always tracks the
# player's CURRENT difficulty (a mid-grind ramp re-targets the bar live). No persistent state.
scoreboard players set #ds_goal ec.temp 1000
execute if score @s ec.difficulty matches 2 run scoreboard players set #ds_goal ec.temp 5000
execute if score @s ec.difficulty matches 3 run scoreboard players set #ds_goal ec.temp 10000
