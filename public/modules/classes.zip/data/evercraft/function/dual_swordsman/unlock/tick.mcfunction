# === DUAL SWORDSMAN — UNLOCK ??? BAR: TICK (auto-hide, 1s) ===
# Self-scheduled at 1s (20t). Only players with a live ??? bar are scanned; hide once past the
# ec.ds_bar_until deadline. Wired from unlock/load. With no bars up this does one @a existence check
# + self-reschedules. Clone of craft_affinity/live_bar/tick (without the toggle-consume half — the
# ??? bar has no opt-in toggle; it shows automatically while a player is grinding the unlock).
execute if entity @a[scores={ec.ds_bar_live=1}] store result score #ds_now ec.temp run time query gametime
execute as @a[scores={ec.ds_bar_live=1}] if score @s ec.ds_bar_until <= #ds_now ec.temp run function evercraft:dual_swordsman/unlock/hide_now

# Self-schedule (1s cadence; never #minecraft:tick).
schedule function evercraft:dual_swordsman/unlock/tick 1s
