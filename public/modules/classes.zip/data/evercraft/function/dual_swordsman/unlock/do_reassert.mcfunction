# === DUAL SWORDSMAN — UNLOCK ??? BAR: DO RE-ASSERT (MACRO) ===
# Call: function .../do_reassert with storage evercraft:ds_livebar   (storage {barslot:N})
# Marks the registry slot taken (idempotent). One of the #dsslot_N pool-registry writers.
$scoreboard players set #dsslot_$(barslot) ec.ds_barslot 1
