# === DUAL SWORDSMAN — UNLOCK ??? BAR: INIT POOL (load-time) ===
# Configure the 8-bar pool (max 100, empty name, hidden) + reset the registry to all-free. Called
# from unlock/load AFTER the bars are created. Per-player ec.ds_bar_slot is intentionally NOT cleared
# (players keep their persistent slot across reload; update/reassert_slot re-stamps the registry on
# the next kill so no two players can collide on a bar after this reset).
bossbar set evercraft:dsbar_1 max 100
bossbar set evercraft:dsbar_1 name ""
bossbar set evercraft:dsbar_1 visible false
bossbar set evercraft:dsbar_2 max 100
bossbar set evercraft:dsbar_2 name ""
bossbar set evercraft:dsbar_2 visible false
bossbar set evercraft:dsbar_3 max 100
bossbar set evercraft:dsbar_3 name ""
bossbar set evercraft:dsbar_3 visible false
bossbar set evercraft:dsbar_4 max 100
bossbar set evercraft:dsbar_4 name ""
bossbar set evercraft:dsbar_4 visible false
bossbar set evercraft:dsbar_5 max 100
bossbar set evercraft:dsbar_5 name ""
bossbar set evercraft:dsbar_5 visible false
bossbar set evercraft:dsbar_6 max 100
bossbar set evercraft:dsbar_6 name ""
bossbar set evercraft:dsbar_6 visible false
bossbar set evercraft:dsbar_7 max 100
bossbar set evercraft:dsbar_7 name ""
bossbar set evercraft:dsbar_7 visible false
bossbar set evercraft:dsbar_8 max 100
bossbar set evercraft:dsbar_8 name ""
bossbar set evercraft:dsbar_8 visible false

# Reset pool registry to free (per-player slot numbers persist; re-stamped on next kill).
scoreboard players set #dsslot_1 ec.ds_barslot 0
scoreboard players set #dsslot_2 ec.ds_barslot 0
scoreboard players set #dsslot_3 ec.ds_barslot 0
scoreboard players set #dsslot_4 ec.ds_barslot 0
scoreboard players set #dsslot_5 ec.ds_barslot 0
scoreboard players set #dsslot_6 ec.ds_barslot 0
scoreboard players set #dsslot_7 ec.ds_barslot 0
scoreboard players set #dsslot_8 ec.ds_barslot 0
