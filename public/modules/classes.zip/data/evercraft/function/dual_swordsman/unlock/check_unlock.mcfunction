# === DUAL SWORDSMAN — UNLOCK: CHECK + FIRE ===
# Run as @s. Unlock when ec.ds_prog hits the per-player goal AND the Pioneer world-boss gate is met:
#   Newcomer (ec.difficulty 1) = 1000 kills / Adventurer (2) = 5000 / Pioneer (3) = 10000.
#   Newcomer / Adventurer -> kills alone are enough.
#   Pioneer -> ALSO needs a world-boss kill on record (ach.boss_kills >= 1).
# SOLE writer of ec.ds_unlocked (set 1). Also stamps the persistent ec.ds_discovered codex flag
# (the spirit-sword path in dual_swordsman/detect is the other writer of that tag).
function evercraft:dual_swordsman/unlock/calc_goal
execute unless score @s ec.ds_prog >= #ds_goal ec.temp run return 0
execute if score @s ec.ds_unlocked matches 1.. run return 0
# Pioneer hard gate: must have slain a world boss.
execute if score @s ec.difficulty matches 3 unless score @s ach.boss_kills matches 1.. run return 0

# === UNLOCK ===
scoreboard players set @s ec.ds_unlocked 1
tag @s add ec.ds_discovered

# Reveal the ??? bar as "Dual Swordsman" (full) for the 8s window, with a celebration.
function evercraft:dual_swordsman/unlock/update
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.warden.emerge player @s ~ ~ ~ 0.8 1.4
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:ui.toast.challenge_complete player @s ~ ~ ~ 1.0 1.0
data modify storage evercraft:notify stage.c set value [{text:"Dual Swordsman",color:"dark_purple",bold:true},{text:" — the twin path is yours!",color:"light_purple",bold:false}]
scoreboard players set #ndur ec.temp 80
function evercraft:util/notify/emit

# If they're holding two Fencer swords right now (they are — seeking requires it), convert the
# Knight stance into the Dual Swordsman class immediately. detect_fencer clears ec.ds_seeking.
execute if items entity @s weapon.mainhand *[custom_data~{knight:true}] if items entity @s weapon.offhand *[custom_data~{knight:true}] run function evercraft:dual_swordsman/detect_fencer
