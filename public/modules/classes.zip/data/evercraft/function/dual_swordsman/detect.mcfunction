# Dual Swordsman Detection — Activate when holding Nite or Deih in mainhand
# Run as player (@s) from detect_all
# Requires: spirit_class:"dual_swordsman" in mainhand custom_data
# Also requires: any sword in offhand (at least one hand must be Nite or Deih)

# Verify offhand has a sword
execute unless items entity @s weapon.offhand #minecraft:swords run return 0

# === ACTIVATE ===
tag @s add ec.ds_active
scoreboard players set @s ec.ds_active 1
# Persistent discovery flag — never cleared. Gates the codex Bough garden so
# DS doesn't spoil itself for players who've never held Nite or Deih (Joseph
# 2026-06-10). Read by bough GUI + pollen check; absence = hide all DS UI.
tag @s add ec.ds_discovered

# === TIER DETECTION (from spirit tier) ===
scoreboard players set @s ec.ds_tier 1
execute if items entity @s weapon.mainhand *[custom_data~{tier:"uncommon"}] run scoreboard players set @s ec.ds_tier 2
execute if items entity @s weapon.mainhand *[custom_data~{tier:"rare"}] run scoreboard players set @s ec.ds_tier 3
execute if items entity @s weapon.mainhand *[custom_data~{tier:"ornate"}] run scoreboard players set @s ec.ds_tier 4
execute if items entity @s weapon.mainhand *[custom_data~{tier:"exquisite"}] run scoreboard players set @s ec.ds_tier 5
execute if items entity @s weapon.mainhand *[custom_data~{tier:"mythical"}] run scoreboard players set @s ec.ds_tier 6
execute if items entity @s weapon.mainhand *[custom_data~{tier:"spirit"}] run scoreboard players set @s ec.ds_tier 7

# === TWIN CHECK (Nite + Deih) ===
scoreboard players set @s ec.ds_twin 0
# Check if offhand is the twin spirit sword
execute if items entity @s weapon.offhand *[custom_data~{spirit_class:"dual_swordsman"}] run scoreboard players set @s ec.ds_twin 1

# === STAT MODIFICATIONS ===
# Base penalty: -5 armor, -5 armor toughness (removed if twins)
execute if score @s ec.ds_twin matches 0 run attribute @s armor modifier add evercraft:spirit_armor_penalty -5.0 add_value
execute if score @s ec.ds_twin matches 0 run attribute @s armor_toughness modifier add evercraft:spirit_toughness_penalty -5.0 add_value

# Twin bonus: attack speed scales with tier (spirit tier = no cooldown)
execute if score @s ec.ds_twin matches 1 if score @s ec.ds_tier matches 1 run attribute @s attack_speed modifier add evercraft:spirit_attack_speed 0.5 add_multiplied_total
execute if score @s ec.ds_twin matches 1 if score @s ec.ds_tier matches 2 run attribute @s attack_speed modifier add evercraft:spirit_attack_speed 0.7 add_multiplied_total
execute if score @s ec.ds_twin matches 1 if score @s ec.ds_tier matches 3 run attribute @s attack_speed modifier add evercraft:spirit_attack_speed 0.9 add_multiplied_total
execute if score @s ec.ds_twin matches 1 if score @s ec.ds_tier matches 4 run attribute @s attack_speed modifier add evercraft:spirit_attack_speed 1.2 add_multiplied_total
execute if score @s ec.ds_twin matches 1 if score @s ec.ds_tier matches 5 run attribute @s attack_speed modifier add evercraft:spirit_attack_speed 1.6 add_multiplied_total
execute if score @s ec.ds_twin matches 1 if score @s ec.ds_tier matches 6 run attribute @s attack_speed modifier add evercraft:spirit_attack_speed 2.0 add_multiplied_total
execute if score @s ec.ds_twin matches 1 if score @s ec.ds_tier matches 7 run attribute @s attack_speed modifier add evercraft:spirit_attack_speed 10.0 add_multiplied_total

# Initialize Whirlwind passive timer (80 ticks = 4 seconds)
scoreboard players set @s ec.ds_whirl_cd 80

# === DUAL SWORDSMAN COMPOSITE BONUSES (Joseph 2026-06-10) ===
# The secret class inherits every class's signature bonus on top of its own
# DS toolkit. Gather speedups (timber/chest/nest/splash/prospect/forage/lore)
# are gated by ec.ds_active in each gather's start function. Stat bonuses:
#   +3 hearts (Tank-tier max HP), +1 entity-interaction range (Knight fencer
#   reach), +20% movement speed (Dancer), 5-heart absorption shield refreshed
#   by knight/tick? — DS has its own tick, so re-apply here on detect and via
#   dual_swordsman/tick. Cleared in dual_swordsman/remove.
attribute @s minecraft:max_health modifier remove evercraft:ds_hearts
attribute @s minecraft:max_health modifier add evercraft:ds_hearts 6 add_value
attribute @s minecraft:entity_interaction_range modifier remove evercraft:ds_reach
attribute @s minecraft:entity_interaction_range modifier add evercraft:ds_reach 1 add_value
attribute @s minecraft:movement_speed modifier remove evercraft:ds_speed
attribute @s minecraft:movement_speed modifier add evercraft:ds_speed 0.2 add_multiplied_base
effect give @s minecraft:absorption 10 4 true

# Initialize ability cooldown
execute unless score @s ec.ds_ability_cd matches 1.. run scoreboard players set @s ec.ds_ability_cd 0

# === FEEDBACK ===
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.warden.emerge player @s ~ ~ ~ 0.6 1.5
execute if score @s ec.ds_twin matches 1 run data modify storage evercraft:notify stage.c set value [{text:"Dual Swordsman",color:"dark_purple",bold:true},{text:" — twin blades united",color:"light_purple",bold:false}]
execute if score @s ec.ds_twin matches 0 run data modify storage evercraft:notify stage.c set value [{text:"Dual Swordsman",color:"dark_purple",bold:true},{text:" — blades drawn",color:"light_purple",bold:false}]
scoreboard players set #ndur ec.temp 45
execute if score @s ec.ds_twin matches 0..1 run function evercraft:util/notify/emit
