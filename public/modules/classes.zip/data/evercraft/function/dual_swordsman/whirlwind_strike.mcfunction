# Dual Swordsman — Whirlwind Strike (360° passive proc)
# Run as @s at @s
# Hits ALL hostile mobs within 3 blocks, deals weapon damage

# Sound + particles
playsound minecraft:entity.player.attack.sweep player @a[scores={ec.fx_snd=1..}] ~ ~ ~ 1.0 1.2
particle sweep_attack ~ ~0.8 ~ 1.5 0.3 1.5 0.5 4

# Damage all nearby hostile entities (with affinity boost)
tag @s add ec.aff_attacker
execute if score @s ec.ds_tier matches 1..2 run scoreboard players set #aff_base ec.temp 6
execute if score @s ec.ds_tier matches 3..4 run scoreboard players set #aff_base ec.temp 8
execute if score @s ec.ds_tier matches 5..6 run scoreboard players set #aff_base ec.temp 10
execute if score @s ec.ds_tier matches 7 run scoreboard players set #aff_base ec.temp 14
# Bough investment (Joseph 2026-06-19): +0.5 heart (=1 dmg) of whirlwind per DS point spent.
# Class-wide — adds on top of the tier base for both the Fencer path (base 6) and spirit twins.
scoreboard players operation #ds_inv ec.temp = @s ec.ds_pte
scoreboard players operation #ds_inv ec.temp -= @s ec.ds_pts
execute if score #ds_inv ec.temp matches 1.. run scoreboard players operation #aff_base ec.temp += #ds_inv ec.temp
function evercraft:affinity/boost_damage
execute as @e[distance=..3,type=#evercraft:aoe_targets] run function evercraft:affinity/deal_damage with storage evercraft:affinity temp
tag @s remove ec.aff_attacker

# Track whirlwind kills for metamorphosis (kills tracked by advancement separately)
# Alternating particle colors (blue/orange) for visual flair
particle dust_color_transition{from_color:[0.2,0.2,0.8],to_color:[1,0.8,0.4],scale:0.2} ~ ~1.0 ~ 2.0 0.5 2.0 0.1 8

# === ABILITY FX (tier-scaled, channel-gated) ===
# Generic tier-FX layer (common→rare; ornate+ no-ops for the bespoke preset below). ec.ds_tier caches rarity
# (custom_data.tier; spirit=7). Runs already AS + AT the player (the whirlwind proc context).
scoreboard players operation #fx_tier ec.var = @s ec.ds_tier
execute at @s run function evercraft:fx/tier/proc
# Bespoke "Crossing Fangs" — twin steel-blue arcs cutting a crossing X with a double-note cut (ornate+).
execute if score #fx_tier ec.var matches 4.. at @s anchored eyes run function evercraft:fx/bespoke/dual_swordsman/whirlwind_strike
