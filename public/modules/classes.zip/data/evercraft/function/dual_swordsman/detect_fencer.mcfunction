# === DUAL SWORDSMAN — FENCER ACTIVATION (the earned path) ===
# Joseph 2026-06-19. An UNLOCKED player (ec.ds_unlocked=1) dual-wielding two single-hand Fencer
# swords (custom_data{knight:true} in BOTH hands) becomes a Dual Swordsman, taking precedence over
# the Knight class. Run as @s. Called from:
#   - artifacts/weapons/detect_all     (fresh equip of two Fencer swords)
#   - artifacts/knight/tick            (a Knight slots a 2nd Fencer sword into the offhand)
#   - dual_swordsman/unlock/check_unlock (the moment the grind completes while holding both)
# Mirrors dual_swordsman/detect's composite kit, but skips the spirit-tier / spirit_class reads
# (Fencer swords carry no spirit custom_data) — twin is always true; attack speed is a flat tier.

# Clear the Knight stance first — we're overriding it. deactivate strips the fencer/tank bonuses
# and removes ec.kt_active so knight/tick stops touching this player.
execute if entity @s[tag=ec.kt_active] run function evercraft:artifacts/knight/deactivate

# === ACTIVATE ===
tag @s add ec.ds_active
tag @s add ec.ds_fencer
scoreboard players set @s ec.ds_active 1
tag @s add ec.ds_discovered
# The grind is over for this player — they are no longer "seeking" the unlock.
tag @s remove ec.ds_seeking

# Two blades = twins (no armor penalty). BASE whirlwind tier (1/8 proc, 6 dmg). The Fencer path
# does NOT inherit the spirit weapons' tier-scaled attack speed — that stays the Nite/Deih payoff.
# Instead, DS power scales with BOUGH INVESTMENT (Joseph 2026-06-19): every point spent into the
# DS class grants +0.1 attack speed (apply_invest) and +0.5 heart of whirlwind damage
# (whirlwind_strike). Spirit twins keep their tier attack speed ON TOP of the same investment.
scoreboard players set @s ec.ds_twin 1
scoreboard players set @s ec.ds_tier 1
# Clear any leftover spirit-twin attack speed (e.g. swapping spirit twins -> Fencer twins).
attribute @s minecraft:attack_speed modifier remove evercraft:spirit_attack_speed

# Whirlwind passive timer (80 ticks = 4 seconds).
scoreboard players set @s ec.ds_whirl_cd 80

# === COMPOSITE BONUSES (identical to dual_swordsman/detect) ===
# +3 hearts, +1 entity-interaction reach, +20% movement speed, 5-heart absorption (refreshed by tick).
attribute @s minecraft:max_health modifier remove evercraft:ds_hearts
attribute @s minecraft:max_health modifier add evercraft:ds_hearts 6 add_value
attribute @s minecraft:entity_interaction_range modifier remove evercraft:ds_reach
attribute @s minecraft:entity_interaction_range modifier add evercraft:ds_reach 1 add_value
attribute @s minecraft:movement_speed modifier remove evercraft:ds_speed
attribute @s minecraft:movement_speed modifier add evercraft:ds_speed 0.2 add_multiplied_base
effect give @s minecraft:absorption 10 4 true

# Ability cooldown init (preserve an in-progress cooldown).
execute unless score @s ec.ds_ability_cd matches 1.. run scoreboard players set @s ec.ds_ability_cd 0

# Apply bough-investment attack speed immediately (force a recompute by clearing the cache first).
scoreboard players set @s ec.ds_inv_last -1
function evercraft:dual_swordsman/apply_invest

# === FEEDBACK ===
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.warden.emerge player @s ~ ~ ~ 0.6 1.5
data modify storage evercraft:notify stage.c set value [{text:"Dual Swordsman",color:"dark_purple",bold:true},{text:" — twin blades drawn",color:"light_purple",bold:false}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
