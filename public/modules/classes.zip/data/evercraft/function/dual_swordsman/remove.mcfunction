# Dual Swordsman — Deactivation
# Run as @s when player no longer holds valid DS weapons

tag @s remove ec.ds_active
# Earned-path marker (set by detect_fencer) — clear it so a reverted player is re-detected as
# Knight next tick instead of being skipped by the Fencer-DS deactivation branch.
tag @s remove ec.ds_fencer
scoreboard players set @s ec.ds_active 0
scoreboard players set @s ec.ds_twin 0

# Remove attribute modifiers
attribute @s armor modifier remove evercraft:spirit_armor_penalty
attribute @s armor_toughness modifier remove evercraft:spirit_toughness_penalty
attribute @s attack_speed modifier remove evercraft:spirit_attack_speed
# Bough-investment attack speed (class-wide) — clear it + reset the change-guard so re-activation
# recomputes from scratch.
attribute @s attack_speed modifier remove evercraft:ds_invest_speed
scoreboard players set @s ec.ds_inv_last -1
# Strip Blade combat modifiers (C1/C3/C9 melee, C2 attack speed) — active-gated.
attribute @s minecraft:attack_damage modifier remove evercraft:bough_ds_c1
attribute @s minecraft:attack_damage modifier remove evercraft:bough_ds_c3
attribute @s minecraft:attack_damage modifier remove evercraft:bough_ds_c9
attribute @s minecraft:attack_speed modifier remove evercraft:bough_ds_c2

# Composite DS bonuses (hearts/reach/speed/absorption) — clear all.
attribute @s minecraft:max_health modifier remove evercraft:ds_hearts
attribute @s minecraft:entity_interaction_range modifier remove evercraft:ds_reach
attribute @s minecraft:movement_speed modifier remove evercraft:ds_speed
effect clear @s minecraft:absorption
