# === DUAL SWORDSMAN — BOUGH-INVESTMENT ATTACK SPEED (MACRO) ===
# Call: function .../apply_invest_speed with storage evercraft:ds_invest   (storage {amt:<invest*0.1>})
# Run as @s. Adds the investment attack-speed modifier (same add_multiplied_total bucket as the
# spirit-twin bonus, so the two simply sum). Caller already removed the old modifier.
$attribute @s minecraft:attack_speed modifier add evercraft:ds_invest_speed $(amt) add_multiplied_total
