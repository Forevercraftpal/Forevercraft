# Dual Swordsman — Per-Tick Processing
# Manages Whirlwind passive timer, ability cooldown, and deactivation

# === DEACTIVATION CHECK — spirit-sword path (Nite/Deih) ===
# Verify player still holds a dual_swordsman spirit weapon in mainhand + sword in offhand.
execute as @a[tag=ec.ds_active,tag=!ec.ds_fencer] unless items entity @s weapon.mainhand *[custom_data~{spirit_class:"dual_swordsman"}] run function evercraft:dual_swordsman/remove
execute as @a[tag=ec.ds_active,tag=!ec.ds_fencer] unless items entity @s weapon.offhand #minecraft:swords run function evercraft:dual_swordsman/remove

# === DEACTIVATION CHECK — earned Fencer path (two knight:true swords, Joseph 2026-06-19) ===
# Revert to ordinary Knight the moment either hand stops holding a single-hand Fencer sword.
# detect_all/knight-tick re-pick up the surviving mainhand sword as Knight next tick.
execute as @a[tag=ec.ds_active,tag=ec.ds_fencer] unless items entity @s weapon.mainhand *[custom_data~{knight:true}] run function evercraft:dual_swordsman/remove
execute as @a[tag=ec.ds_active,tag=ec.ds_fencer] unless items entity @s weapon.offhand *[custom_data~{knight:true}] run function evercraft:dual_swordsman/remove

# === DS ABSORPTION REFRESH ===
# Composite Tank-tier shield (5 hearts) refreshed every tick. 5s buffer; hidden
# particles. Matches knight/tick's Tank refresh so the icons never expire.
effect give @a[tag=ec.ds_active] minecraft:absorption 5 4 true

# === BOUGH-INVESTMENT ATTACK SPEED REFRESH ===
# Keeps the +0.1-per-DS-point attack speed live (so spending a point updates within a tick). The
# change-guard inside apply_invest makes this ~3 score ops/player when the invested count is stable.
execute as @a[tag=ec.ds_active] run function evercraft:dual_swordsman/apply_invest

# === WHIRLWIND PASSIVE ===
# Decrement timer for all active DS players
scoreboard players remove @a[tag=ec.ds_active,scores={ec.ds_whirl_cd=1..}] ec.ds_whirl_cd 1

# When timer hits 0 — roll for Whirlwind proc
execute as @a[tag=ec.ds_active,scores={ec.ds_whirl_cd=..0}] at @s run function evercraft:dual_swordsman/whirlwind_passive

# === ABILITY COOLDOWN ===
scoreboard players remove @a[tag=ec.ds_active,scores={ec.ds_ability_cd=1..}] ec.ds_ability_cd 1
