# ============================================================
# Baúl — Bake the stored contents into the dropped filled item's lore (macro).
# Args (storage evercraft:bulk_barrel lr): count (int), name (item path, "minecraft:" already dropped).
# Run from encode_break, AS the marker, AT the block — the nearest barrel ITEM (..2) is our just-dropped
# filled Baúl (the vanilla barrel drop was killed in on_break first).
# ------------------------------------------------------------
# Replaces line 6 of the filled Baúl's lore (bulk_barrel/item_filled, the "Holds its stored contents…"
# line) with a baked "Holds N× <item> — place to restore them." so the HELD Baúl shows WHAT it holds and
# HOW MANY before you re-place it. BAKED literal: item tooltips render client-side and never resolve live
# {nbt:…} sources, so the count + name are macro-substituted into the component as text here.
# Keep the index in sync with bulk_barrel/item_filled.json if that lore is ever reordered.
# ============================================================
$data modify entity @e[type=item,nbt={Item:{id:"minecraft:barrel"}},distance=..2,sort=nearest,limit=1] Item.components."minecraft:lore"[6] set value {text:"Holds $(count)× $(name) — place to restore them.",color:"aqua",italic:true}
