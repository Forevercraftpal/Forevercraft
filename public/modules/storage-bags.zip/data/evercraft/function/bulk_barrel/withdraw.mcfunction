# ============================================================
# Baúl — Withdraw a stack
# Run as: the clicking player (@s), positioned AT the block center.
# ------------------------------------------------------------
# Gives one stack (up to 64, or the remaining count if less) of the
# stored item, decrements the count. When the count reaches 0 the
# barrel unlocks (empties), so a new type may be stored.
# Reconstructs the item from the marker's stored template (id +
# components) so withdrawals return the exact stored item.
# ============================================================

# Locate this block's marker.
execute unless entity @e[type=marker,tag=ec.bb_marker,distance=..1,sort=nearest,limit=1] run return 0

# Read the stored count.
execute store result score #bb_count ec.var run data get entity @e[type=marker,tag=ec.bb_marker,distance=..1,sort=nearest,limit=1] data.bb_count

# Empty barrel — nothing to withdraw.
data modify storage evercraft:notify stage.c set value [{text:"This Ba\u00fal is empty.",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 45
execute if score #bb_count ec.var matches ..0 run return run function evercraft:bulk_barrel/notify

# --- Rapid-withdraw streak: after 5 stacks pulled in one continuous hold/burst, the NEXT sneak-right-
#     click empties the whole Baúl at once (QoL for big stockpiles). A >10-tick gap since the last pull
#     resets the streak, so deliberate single withdraws never trip it — only a held/rapid run reaches 6. ---
execute store result score #bb_now ec.var run time query gametime
scoreboard players set #bb_wstreak ec.var 0
execute store result score #bb_wstreak ec.var run data get entity @e[type=marker,tag=ec.bb_marker,distance=..1,sort=nearest,limit=1] data.bb_wstreak
scoreboard players set #bb_wprev ec.var 0
execute store result score #bb_wprev ec.var run data get entity @e[type=marker,tag=ec.bb_marker,distance=..1,sort=nearest,limit=1] data.bb_wtime
scoreboard players operation #bb_gap ec.var = #bb_now ec.var
scoreboard players operation #bb_gap ec.var -= #bb_wprev ec.var
execute if score #bb_gap ec.var matches 11.. run scoreboard players set #bb_wstreak ec.var 0
scoreboard players add #bb_wstreak ec.var 1
execute store result entity @e[type=marker,tag=ec.bb_marker,distance=..1,sort=nearest,limit=1] data.bb_wstreak int 1 run scoreboard players get #bb_wstreak ec.var
execute store result entity @e[type=marker,tag=ec.bb_marker,distance=..1,sort=nearest,limit=1] data.bb_wtime int 1 run scoreboard players get #bb_now ec.var
# 6th+ pull in the session (the one AFTER 5 stacks) -> dump everything and stop.
execute if score #bb_wstreak ec.var matches 6.. run return run function evercraft:bulk_barrel/withdraw_all

# Stack to give = min(count, 64).
scoreboard players operation #bb_give ec.var = #bb_count ec.var
scoreboard players set #bb_64 ec.var 64
execute if score #bb_give ec.var > #bb_64 ec.var run scoreboard players operation #bb_give ec.var = #bb_64 ec.var

# Pull the stored template into working storage; set its count to #bb_give,
# then give it to the player via a macro (item-from-storage idiom).
data modify storage evercraft:bulk_barrel give_item set from entity @e[type=marker,tag=ec.bb_marker,distance=..1,sort=nearest,limit=1] data.bb_item
execute store result storage evercraft:bulk_barrel give_item.count int 1 run scoreboard players get #bb_give ec.var
function evercraft:bulk_barrel/give_stack

# Decrement the stored count and persist.
scoreboard players operation #bb_count ec.var -= #bb_give ec.var
execute store result entity @e[type=marker,tag=ec.bb_marker,distance=..1,sort=nearest,limit=1] data.bb_count int 1 run scoreboard players get #bb_count ec.var

# If the barrel is now empty, unlock it (clear id + template).
execute if score #bb_count ec.var matches ..0 run data modify entity @e[type=marker,tag=ec.bb_marker,distance=..1,sort=nearest,limit=1] data.bb_locked set value 0b
execute if score #bb_count ec.var matches ..0 run data modify entity @e[type=marker,tag=ec.bb_marker,distance=..1,sort=nearest,limit=1] data.bb_id set value ""
execute if score #bb_count ec.var matches ..0 run data modify entity @e[type=marker,tag=ec.bb_marker,distance=..1,sort=nearest,limit=1] data.bb_item set value {id:"minecraft:air",count:1}

# Refresh the front displays.
function evercraft:bulk_barrel/update_display

# Feedback.
playsound minecraft:block.barrel.open master @a[distance=..12,scores={ec.fx_snd=1..}] ~ ~ ~ 0.6 1.1
data modify storage evercraft:notify stage.c set value [{text:"Withdrew ",color:"gray"},{score:{name:"#bb_give",objective:"ec.var"},color:"white"},{text:" — ",color:"gray"},{score:{name:"#bb_count",objective:"ec.var"},color:"gold"},{text:" / 9,999 remaining.",color:"gray"}]
scoreboard players set #ndur ec.temp 45
function evercraft:bulk_barrel/notify
