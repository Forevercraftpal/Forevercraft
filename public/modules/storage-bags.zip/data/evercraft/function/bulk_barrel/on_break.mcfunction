# ============================================================
# Baúl — On Break (anchor barrel block removed)
# Run as: the marker entity (ec.bb_marker), at its position.
# Drops the stored contents (in stacks of up to 64) + the Baúl
# item itself, then kills the marker + interaction + displays for this
# block. Never voids stored items.
# Mirrors evercraft:craftforever/forging/on_break + housing/on_break.
# ============================================================

# ── Read the stored count (drives filled-vs-empty drop + the contents smuggle below). ──
execute store result score #bb_count ec.var run data get entity @s data.bb_count

# ── Kill the vanilla barrel drop (the anchor) BEFORE we spawn ours, so the
# plain barrel that the broken block dropped is removed without ever
# catching our custom Baúl item (which we spawn on the NEXT line). ──
kill @e[type=item,nbt={Item:{id:"minecraft:barrel"}},distance=..1.5]

# ── Drop the Baúl item — contents STAY INSIDE it (Joseph 2026-06-06). A Baúl with stock drops the
# "filled" variant (holds-contents lore) and encode_break smuggles the count + template into it via a
# minecraft:container marker; setup -> restore_contents reads it back on re-place. An empty Baúl drops
# the plain item. This REPLACES the old loose drop_contents (no more scattering the whole stockpile). ──
execute if score #bb_count ec.var matches 1.. run loot spawn ~ ~0.5 ~ loot evercraft:bulk_barrel/item_filled
execute if score #bb_count ec.var matches ..0 run loot spawn ~ ~0.5 ~ loot evercraft:bulk_barrel/item
execute if score #bb_count ec.var matches 1.. run function evercraft:bulk_barrel/encode_break

# ── Clean up this block's bulk-barrel entities (tight distance — one of
# each per block; sort=nearest keeps neighbours' displays safe) ──
# Kill the head item_display passenger EXPLICITLY: `kill`-ing the armor_stand
# only EJECTS its passengers (vehicles dismount — they don't cascade-kill), so
# the Baúl skin would otherwise survive the break as a floating orphan.
# `on passengers` targets exactly THIS block's head — no neighbour risk.
execute as @e[type=armor_stand,tag=ec.bb_stand,distance=..1,sort=nearest,limit=1] on passengers run kill @s
kill @e[type=interaction,tag=ec.bb_click,distance=..1,sort=nearest,limit=1]
kill @e[type=armor_stand,tag=ec.bb_stand,distance=..1,sort=nearest,limit=1]
# The float hovers at marker +1.4, OUTSIDE the ..1 used for the other displays — position up to it
# first, then a tight ..0.6 kills only THIS block's float (neighbours, incl. stacked Baúls, are >=1 away).
execute positioned ~ ~1.4 ~ run kill @e[type=item_display,tag=ec.bb_float,distance=..0.6,sort=nearest,limit=1]
kill @e[type=text_display,tag=ec.bb_text,distance=..1,sort=nearest,limit=1]

# ── Feedback ──
playsound minecraft:block.barrel.close master @a[distance=..16,scores={ec.fx_snd=1..}] ~ ~ ~ 1.0 0.7
particle minecraft:happy_villager ~ ~0.5 ~ 0.3 0.3 0.3 0.03 8

# ── Kill self (marker) ──
kill @s
