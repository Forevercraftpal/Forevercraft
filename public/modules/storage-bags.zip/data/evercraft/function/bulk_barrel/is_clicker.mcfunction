# ============================================================
# Baúl — Predicate fn: is @s the clicking player?
# Run as: a candidate player (@s).
# Reads #bb_uuid0..3 ec.var (the clicker's UUID, set by handle_click).
# Returns 1 if @s's UUID matches all four ints, else 0.
# Used via `if function` in handle_click.
# ============================================================

execute store result score #bb_puid0 ec.var run data get entity @s UUID[0]
execute store result score #bb_puid1 ec.var run data get entity @s UUID[1]
execute store result score #bb_puid2 ec.var run data get entity @s UUID[2]
execute store result score #bb_puid3 ec.var run data get entity @s UUID[3]

execute unless score #bb_puid0 ec.var = #bb_uuid0 ec.var run return 0
execute unless score #bb_puid1 ec.var = #bb_uuid1 ec.var run return 0
execute unless score #bb_puid2 ec.var = #bb_uuid2 ec.var run return 0
execute unless score #bb_puid3 ec.var = #bb_uuid3 ec.var run return 0
return 1
