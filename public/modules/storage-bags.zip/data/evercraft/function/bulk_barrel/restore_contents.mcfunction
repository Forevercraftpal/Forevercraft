# ============================================================
# Baúl — Restore stored contents from a broken-Baúl smuggle on re-place.
# Run as: the placing player (@s), AT the block. Called from setup only when the placed barrel block's
# slot 0 holds a marker with custom_data.bb_saved (a Baúl broken with stock, see encode_break).
# ------------------------------------------------------------
# Copies the saved count + template into THIS block's fresh marker, re-locks it, then removes the
# smuggle marker from the barrel slot so it isn't pulled by a hopper / seen by the player.
# ============================================================

# Restore count + template + locked-id onto the just-summoned marker.
data modify entity @e[type=marker,tag=ec.bb_marker,distance=..1,sort=nearest,limit=1] data.bb_count set from block ~ ~ ~ Items[{Slot:0b}].components."minecraft:custom_data".bb_saved.count
data modify entity @e[type=marker,tag=ec.bb_marker,distance=..1,sort=nearest,limit=1] data.bb_item set from block ~ ~ ~ Items[{Slot:0b}].components."minecraft:custom_data".bb_saved.item
data modify entity @e[type=marker,tag=ec.bb_marker,distance=..1,sort=nearest,limit=1] data.bb_id set from block ~ ~ ~ Items[{Slot:0b}].components."minecraft:custom_data".bb_saved.item.id
data modify entity @e[type=marker,tag=ec.bb_marker,distance=..1,sort=nearest,limit=1] data.bb_locked set value 1b

# Remove the smuggle marker from the barrel slot (it has done its job).
data remove block ~ ~ ~ Items[{Slot:0b}]

# Refresh the front count + floating indicator (block center so the +1.4 float is within the ..1 selector).
execute positioned ~ ~0.5 ~ run function evercraft:bulk_barrel/update_display

# Feedback (overrides the generic "placed" line emitted just before in setup).
data modify storage evercraft:notify stage.c set value [{text:"Baúl restored ",color:"gold"},{text:"— its contents are intact.",color:"gray"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
