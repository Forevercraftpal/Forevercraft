# ============================================================
# Baúl — Offset the front count overlay toward the placer
# Run at: the block (aligned), positioned ^ ^ ^1 from on_place.
# Reads #bb_rot ec.var (the placer's yaw bucket) and nudges the count
# text out the front face by ~0.32 in world space so it sits in the
# viewing window instead of inside the head.
# ------------------------------------------------------------
# The overlay is teleported relative to its OWN position (execute as
# the entity at @s), so the nudge is a clean world-space shift along
# the barrel's front axis. Quadrants match set_facing.
# (The contained-item icon that used to be nudged here too was removed
# 2026-06-06 — see setup.mcfunction; the floating ec.bb_float shows contents now.)
# ============================================================

# South-facing barrel — front is +Z.
execute if score #bb_rot ec.var matches -45..44 as @e[tag=ec.bb_text,tag=ec.block_new,distance=..3,limit=1] at @s run tp @s ~ ~ ~0.32

# West-facing barrel — front is -X.
execute if score #bb_rot ec.var matches 45..134 as @e[tag=ec.bb_text,tag=ec.block_new,distance=..3,limit=1] at @s run tp @s ~-0.32 ~ ~

# East-facing barrel — front is +X.
execute if score #bb_rot ec.var matches -134..-45 as @e[tag=ec.bb_text,tag=ec.block_new,distance=..3,limit=1] at @s run tp @s ~0.32 ~ ~

# North-facing barrel — front is -Z.
execute if score #bb_rot ec.var matches 135.. as @e[tag=ec.bb_text,tag=ec.block_new,distance=..3,limit=1] at @s run tp @s ~ ~ ~-0.32
execute if score #bb_rot ec.var matches ..-135 as @e[tag=ec.bb_text,tag=ec.block_new,distance=..3,limit=1] at @s run tp @s ~ ~ ~-0.32
