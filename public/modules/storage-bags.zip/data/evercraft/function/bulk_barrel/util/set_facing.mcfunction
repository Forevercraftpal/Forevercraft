# ============================================================
# Baúl — Set a display's facing quaternion (macro)
# Run as: a freshly-spawned bulk-barrel display entity (ec.block_new).
# Args: q (a left_rotation quaternion list, e.g. "[0f,1f,0f,0f]")
# ------------------------------------------------------------
# The head rides an armor_stand as a passenger; standalone overlays
# (icon, count text) carry their own transformation. Apply to whichever
# this entity is: an armor_stand routes to its passenger, others self.
# ============================================================

# Armor stand: rotate its item_display passenger (the head).
$execute if entity @s[type=armor_stand] on passengers run data modify entity @s transformation.left_rotation set value $(q)

# Standalone item_display / text_display overlays: rotate self.
$execute if entity @s[type=item_display] run data modify entity @s transformation.left_rotation set value $(q)
$execute if entity @s[type=text_display] run data modify entity @s transformation.left_rotation set value $(q)
