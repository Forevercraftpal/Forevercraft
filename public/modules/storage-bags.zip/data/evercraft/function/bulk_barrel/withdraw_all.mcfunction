# ============================================================
# Baúl — Empty the entire Baúl at once (rapid-withdraw payoff)
# Run as: the clicking player (@s), positioned AT the block center
#         (from withdraw.mcfunction once the withdraw streak hits 6).
# ------------------------------------------------------------
# Drops every stored stack at the block (the adjacent player grabs them;
# any overflow lands at their feet — never voided), then zeroes + unlocks
# the barrel and resets the streak. Reuses drop_contents (run AS the marker,
# which decrements bb_count to 0 itself), so the 64-stack loop + never-void
# guarantee are shared with the break path.
# ============================================================

# Dump all contents (drop_contents runs as the marker and zeroes bb_count).
execute as @e[type=marker,tag=ec.bb_marker,distance=..1,sort=nearest,limit=1] at @s run function evercraft:bulk_barrel/drop_contents

# Unlock the now-empty barrel + reset the withdraw streak.
data modify entity @e[type=marker,tag=ec.bb_marker,distance=..1,sort=nearest,limit=1] data.bb_locked set value 0b
data modify entity @e[type=marker,tag=ec.bb_marker,distance=..1,sort=nearest,limit=1] data.bb_id set value ""
data modify entity @e[type=marker,tag=ec.bb_marker,distance=..1,sort=nearest,limit=1] data.bb_item set value {id:"minecraft:air",count:1}
data modify entity @e[type=marker,tag=ec.bb_marker,distance=..1,sort=nearest,limit=1] data.bb_wstreak set value 0

# Refresh the displays (front count -> "Empty", floating indicator -> air).
function evercraft:bulk_barrel/update_display

# Feedback.
playsound minecraft:block.barrel.open master @a[distance=..12,scores={ec.fx_snd=1..}] ~ ~ ~ 0.8 0.9
particle minecraft:happy_villager ~ ~1.1 ~ 0.3 0.2 0.3 0.04 12
data modify storage evercraft:notify stage.c set value [{text:"Baúl emptied ",color:"gold"},{text:"— all contents released.",color:"gray"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
