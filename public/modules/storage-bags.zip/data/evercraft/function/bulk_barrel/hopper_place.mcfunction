# ============================================================
# Baúl — Commit ONE stored item into barrel slot 0 for the hopper below.
# Run as: the marker (@s), AT the block. Caller (hopper_feed) has confirmed
# slot 0 is empty and bb_count > 0.
# ------------------------------------------------------------
# Decrement-on-COMMIT: the count drops the instant an item is placed in the
# slot, so the item is never counted in both places — a mid-dispense break
# can't dupe or lose it (the slot item scatters via vanilla, the count via
# drop_contents, with no overlap).
# ============================================================

# Build a count-1 copy of the stored template, tag it slot 0, append atomically.
# (Set .Slot BEFORE appending — append-then-merge can leave a {Slot:0b} with no id on a chunk save,
# per structures/container/shuffle_set_slot.)
data modify storage evercraft:bulk_barrel hopper_item set from entity @s data.bb_item
data modify storage evercraft:bulk_barrel hopper_item.count set value 1
data modify storage evercraft:bulk_barrel hopper_item.Slot set value 0b
data modify block ~ ~ ~ Items append from storage evercraft:bulk_barrel hopper_item

# Decrement the virtual count (committed to the slot).
execute store result score #bb_hf ec.var run data get entity @s data.bb_count
scoreboard players remove #bb_hf ec.var 1
execute store result entity @s data.bb_count int 1 run scoreboard players get #bb_hf ec.var

# Count exhausted -> unlock so a new type can be stored later. The final item still sits in slot 0
# for the hopper to pull; bb_item was already read above, so clearing it now is safe.
execute if score #bb_hf ec.var matches ..0 run data modify entity @s data.bb_locked set value 0b
execute if score #bb_hf ec.var matches ..0 run data modify entity @s data.bb_id set value ""
execute if score #bb_hf ec.var matches ..0 run data modify entity @s data.bb_item set value {id:"minecraft:air",count:1}

# Refresh the front count + floating indicator (positioned at block CENTER so the +1.4 float is in
# the ..1 selector — the marker sits at block-Y, where the float would be 1.4 away and missed).
execute positioned ~ ~0.5 ~ run function evercraft:bulk_barrel/update_display
