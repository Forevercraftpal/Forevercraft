# ============================================================
# Baúl — Macro: write the count text in the given color
# Run at: the block center (positioned).
# Args: disp_count (the live count int), disp_color (text color)
# Renders "n / 9,999" on the front count text_display.
# ============================================================
$data modify entity @e[type=text_display,tag=ec.bb_text,distance=..1,sort=nearest,limit=1] text set value {text:"$(disp_count) / 9,999",color:"$(disp_color)",italic:false}
