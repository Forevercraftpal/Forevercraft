# ============================================================
# Baúl — Wash Block (right-click holding a water bucket)
# Run as: the clicking player (@s), positioned AT the block center.
# Called from the recolor intercept at the top of deposit.mcfunction.
# Removes the persistent data.bb_color and restores the default Baúl head
# texture (baul_base — identical to the value summoned in setup.mcfunction).
# Marker/stand resolved by distance=..1 (per-block, multiplayer-safe).
# ============================================================

# Reset the marker color back to default (clear the stored field).
execute as @e[type=marker,tag=ec.bb_marker,distance=..1,sort=nearest,limit=1] run data remove entity @s data.bb_color

# Reset the display head to the default Baúl skin (baul_base from setup.mcfunction).
execute as @e[type=armor_stand,tag=ec.bb_stand,distance=..1,sort=nearest,limit=1] on passengers run data modify entity @s item.components."minecraft:profile".properties[0].value set value "ewogICJ0aW1lc3RhbXAiIDogMTc4MDU0OTkzMzgzMCwKICAicHJvZmlsZUlkIiA6ICIwZWQ2MDFlMDhjZTM0YjRkYWUxZmI4MDljZmEwNTM5NiIsCiAgInByb2ZpbGVOYW1lIiA6ICJOZWVkTW9yZUFjY291bnRzIiwKICAic2lnbmF0dXJlUmVxdWlyZWQiIDogdHJ1ZSwKICAidGV4dHVyZXMiIDogewogICAgIlNLSU4iIDogewogICAgICAidXJsIiA6ICJodHRwOi8vdGV4dHVyZXMubWluZWNyYWZ0Lm5ldC90ZXh0dXJlLzgxYWIwOTg0OGQ1MmEzYzUyZDg3NjkzM2UzOWQwNDQ5Nzc0NWJiNWFiNzNjN2EwYWY2OTM5N2JjMzY1YzgzMWEiCiAgICB9CiAgfQp9"

# Effects.
playsound minecraft:item.bucket.empty master @a[distance=..16,scores={ec.fx_snd=1..}] ~ ~ ~ 1 1.2
particle minecraft:splash ~ ~1.1 ~ 0.3 0.2 0.3 0.05 12

# Feedback.
data modify storage evercraft:notify stage.c set value [{text:"Washed ",color:"gray",italic:true},{text:"Ba\u00fal",color:"#E0B0FF",italic:true},{text:" back to default",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
