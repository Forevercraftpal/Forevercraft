# Baúl — Place raycast: find the just-placed barrel (no Baúl marker yet) and set it up.
# Run anchored eyes, positioned ^ ^ ^offset, as the placing player. Mirrors use_raycast.
scoreboard players add #bb_pray ec.var 1

# Hit a barrel with no Baúl marker -> align to the block and build the Baúl there.
execute if score #bb_placed ec.var matches 0 if block ~ ~ ~ minecraft:barrel unless entity @e[type=marker,tag=ec.bb_marker,distance=..1.2,limit=1] align xyz run function evercraft:bulk_barrel/setup

# Keep stepping forward until a (new) barrel, the step cap, or setup ran.
execute if score #bb_placed ec.var matches 0 if score #bb_pray ec.var matches ..40 unless block ~ ~ ~ minecraft:barrel positioned ^ ^ ^0.2 run function evercraft:bulk_barrel/place_raycast

# Step PAST an already-registered Baúl barrel so the ray doesn't stop dead on it.
execute if score #bb_placed ec.var matches 0 if score #bb_pray ec.var matches ..40 if block ~ ~ ~ minecraft:barrel if entity @e[type=marker,tag=ec.bb_marker,distance=..1.2,limit=1] positioned ^ ^ ^0.2 run function evercraft:bulk_barrel/place_raycast
