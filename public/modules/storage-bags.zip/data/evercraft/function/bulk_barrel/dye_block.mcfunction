# ============================================================
# Baúl — Dye Block (right-click holding a dye)
# Run as: the clicking player (@s), positioned AT the block center.
# Called from the recolor intercept at the top of deposit.mcfunction.
# Detects the held dye via the shared dyeing/detect_color mapper, then sets
# the marker's persistent data.bb_color AND live-swaps the display head's
# texture value. Marker/stand resolved by distance=..1 (per-block, MP-safe).
# Texture values inlined from _council/2026-06-04-station-color-variants.
# ============================================================

# Detect which dye the player is holding (writes evercraft:dyeing color_id/name).
function evercraft:dyeing/detect_color

# Azure
execute if data storage evercraft:dyeing {color_id:"azure"} as @e[type=marker,tag=ec.bb_marker,distance=..1,sort=nearest,limit=1] run data modify entity @s data.bb_color set value "azure"
execute if data storage evercraft:dyeing {color_id:"azure"} as @e[type=armor_stand,tag=ec.bb_stand,distance=..1,sort=nearest,limit=1] on passengers run data modify entity @s item.components."minecraft:profile".properties[0].value set value "ewogICJ0aW1lc3RhbXAiIDogMTc4MDU1MDI1NzQ3MywKICAicHJvZmlsZUlkIiA6ICI2YTQ3NjRhZWEwNWY0MTE1OTc0NzFlZjNjYWU4ZTdmZiIsCiAgInByb2ZpbGVOYW1lIiA6ICJiYWRlZW5kamVoIiwKICAic2lnbmF0dXJlUmVxdWlyZWQiIDogdHJ1ZSwKICAidGV4dHVyZXMiIDogewogICAgIlNLSU4iIDogewogICAgICAidXJsIiA6ICJodHRwOi8vdGV4dHVyZXMubWluZWNyYWZ0Lm5ldC90ZXh0dXJlLzgyMzVkNzc1NTQ4ZDc5YzM2ZmViZTI2NGEwNTMyNjkxNGE0Njg0MDY3NDdlZDBhYThjM2U4MWZkYjYwYjJhM2YiCiAgICB9CiAgfQp9"

# Crimson
execute if data storage evercraft:dyeing {color_id:"crimson"} as @e[type=marker,tag=ec.bb_marker,distance=..1,sort=nearest,limit=1] run data modify entity @s data.bb_color set value "crimson"
execute if data storage evercraft:dyeing {color_id:"crimson"} as @e[type=armor_stand,tag=ec.bb_stand,distance=..1,sort=nearest,limit=1] on passengers run data modify entity @s item.components."minecraft:profile".properties[0].value set value "ewogICJ0aW1lc3RhbXAiIDogMTc4MDU1MDI2NzQwOSwKICAicHJvZmlsZUlkIiA6ICI1OWJlOTUyY2EyNjc0OWE4OTM1YmQ5MGQxNmMyN2M4OCIsCiAgInByb2ZpbGVOYW1lIiA6ICJUaGVQZW5zcGlubmV1ciIsCiAgInNpZ25hdHVyZVJlcXVpcmVkIiA6IHRydWUsCiAgInRleHR1cmVzIiA6IHsKICAgICJTS0lOIiA6IHsKICAgICAgInVybCIgOiAiaHR0cDovL3RleHR1cmVzLm1pbmVjcmFmdC5uZXQvdGV4dHVyZS9jYmYxODhiOWZkMmZlZWJkODUxYzM4MzBhNjBjNTQ2YWU4MjEzOTJmODBhNGNhODEzYWVhYmIwMjM4MmUwZmM5IgogICAgfQogIH0KfQ=="

# Solar
execute if data storage evercraft:dyeing {color_id:"solar"} as @e[type=marker,tag=ec.bb_marker,distance=..1,sort=nearest,limit=1] run data modify entity @s data.bb_color set value "solar"
execute if data storage evercraft:dyeing {color_id:"solar"} as @e[type=armor_stand,tag=ec.bb_stand,distance=..1,sort=nearest,limit=1] on passengers run data modify entity @s item.components."minecraft:profile".properties[0].value set value "ewogICJ0aW1lc3RhbXAiIDogMTc4MDU1MDI4MDA5NSwKICAicHJvZmlsZUlkIiA6ICIyZDUxZmI0ZmJjM2Y0MjJjOTMyYzIzMDg5NGU2YmM1MiIsCiAgInByb2ZpbGVOYW1lIiA6ICJGR0ZTX3N0dWRpbyIsCiAgInNpZ25hdHVyZVJlcXVpcmVkIiA6IHRydWUsCiAgInRleHR1cmVzIiA6IHsKICAgICJTS0lOIiA6IHsKICAgICAgInVybCIgOiAiaHR0cDovL3RleHR1cmVzLm1pbmVjcmFmdC5uZXQvdGV4dHVyZS9lZTkzMDZjNGJmNTM5ZjZhMjk5M2I4ZTcxY2JmNjU1YTY1OTI3MTJhZGE2ODY5OTNhNThjNTZhOGFiNWNkMzgxIgogICAgfQogIH0KfQ=="

# Verdant
execute if data storage evercraft:dyeing {color_id:"verdant"} as @e[type=marker,tag=ec.bb_marker,distance=..1,sort=nearest,limit=1] run data modify entity @s data.bb_color set value "verdant"
execute if data storage evercraft:dyeing {color_id:"verdant"} as @e[type=armor_stand,tag=ec.bb_stand,distance=..1,sort=nearest,limit=1] on passengers run data modify entity @s item.components."minecraft:profile".properties[0].value set value "ewogICJ0aW1lc3RhbXAiIDogMTc4MDU1MDI5MjM1MCwKICAicHJvZmlsZUlkIiA6ICJjNGU0ZDY2MWRkMDQ0MDE3ODNhZDM5NGEzMDBjOTFjNiIsCiAgInByb2ZpbGVOYW1lIiA6ICJSNTBrIiwKICAic2lnbmF0dXJlUmVxdWlyZWQiIDogdHJ1ZSwKICAidGV4dHVyZXMiIDogewogICAgIlNLSU4iIDogewogICAgICAidXJsIiA6ICJodHRwOi8vdGV4dHVyZXMubWluZWNyYWZ0Lm5ldC90ZXh0dXJlLzVlOGUyN2JlMWM1MGYwYjZhYjkyMjM4NGZiNmZlZWE3NzFjZjkyNDgwODZmNzc4YWYxODZiZWQ5ZTZlYTJjOTQiCiAgICB9CiAgfQp9"

# Ivory
execute if data storage evercraft:dyeing {color_id:"ivory"} as @e[type=marker,tag=ec.bb_marker,distance=..1,sort=nearest,limit=1] run data modify entity @s data.bb_color set value "ivory"
execute if data storage evercraft:dyeing {color_id:"ivory"} as @e[type=armor_stand,tag=ec.bb_stand,distance=..1,sort=nearest,limit=1] on passengers run data modify entity @s item.components."minecraft:profile".properties[0].value set value "ewogICJ0aW1lc3RhbXAiIDogMTc4MDU1MDMwNDM5OSwKICAicHJvZmlsZUlkIiA6ICIxNDM3N2ZjOGU1NTg0NGQwOTg2ZDkyMjY3ODRiMjQxZiIsCiAgInByb2ZpbGVOYW1lIiA6ICIwVGlja0RlbGF5IiwKICAic2lnbmF0dXJlUmVxdWlyZWQiIDogdHJ1ZSwKICAidGV4dHVyZXMiIDogewogICAgIlNLSU4iIDogewogICAgICAidXJsIiA6ICJodHRwOi8vdGV4dHVyZXMubWluZWNyYWZ0Lm5ldC90ZXh0dXJlLzhhMDg1Y2RlMzkxNTA4Y2I2ZGE2NzUxYWM2ZDJiMjFiN2ExZmE0NWE3NmYzMzVkNjg4MWQ3MDI2M2E2MmU3NWQiCiAgICB9CiAgfQp9"

# Obsidian
execute if data storage evercraft:dyeing {color_id:"obsidian"} as @e[type=marker,tag=ec.bb_marker,distance=..1,sort=nearest,limit=1] run data modify entity @s data.bb_color set value "obsidian"
execute if data storage evercraft:dyeing {color_id:"obsidian"} as @e[type=armor_stand,tag=ec.bb_stand,distance=..1,sort=nearest,limit=1] on passengers run data modify entity @s item.components."minecraft:profile".properties[0].value set value "ewogICJ0aW1lc3RhbXAiIDogMTc4MDU1MDMxNjUwOCwKICAicHJvZmlsZUlkIiA6ICIyZWZmMTQ1MDQzYzI0YzZkOTk3MTgxNGMxMTJjZmJmOSIsCiAgInByb2ZpbGVOYW1lIiA6ICJUZWFtVGVjaG5vYmxhZGUiLAogICJzaWduYXR1cmVSZXF1aXJlZCIgOiB0cnVlLAogICJ0ZXh0dXJlcyIgOiB7CiAgICAiU0tJTiIgOiB7CiAgICAgICJ1cmwiIDogImh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvNmZhNjI5MGFlNDM1NjAwOGY0Y2EyY2RmZDY0MjJlNTEwNTc2MDZkN2IzODU5ODkxNDYzNTkyYTQwMzNmZDY5MyIKICAgIH0KICB9Cn0="

# Rose
execute if data storage evercraft:dyeing {color_id:"rose"} as @e[type=marker,tag=ec.bb_marker,distance=..1,sort=nearest,limit=1] run data modify entity @s data.bb_color set value "rose"
execute if data storage evercraft:dyeing {color_id:"rose"} as @e[type=armor_stand,tag=ec.bb_stand,distance=..1,sort=nearest,limit=1] on passengers run data modify entity @s item.components."minecraft:profile".properties[0].value set value "ewogICJ0aW1lc3RhbXAiIDogMTc4MDU1MDMyODkyMywKICAicHJvZmlsZUlkIiA6ICJkMWU5ODViZGYyMTg0OWQwYmFlZTNlYjBiNDM2ZmExYiIsCiAgInByb2ZpbGVOYW1lIiA6ICJSb3NleUNoYW40MjAiLAogICJzaWduYXR1cmVSZXF1aXJlZCIgOiB0cnVlLAogICJ0ZXh0dXJlcyIgOiB7CiAgICAiU0tJTiIgOiB7CiAgICAgICJ1cmwiIDogImh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvNjUwNTA2NDRlYjQ5MWUwMzNkZDFkNmYyNjI2MDkzYTY4MzJiYjM1ZmY2MzI3Nzg5Y2E5OTY4MzQ4OWQ3YTYwNyIKICAgIH0KICB9Cn0="

# Noir
execute if data storage evercraft:dyeing {color_id:"noir"} as @e[type=marker,tag=ec.bb_marker,distance=..1,sort=nearest,limit=1] run data modify entity @s data.bb_color set value "noir"
execute if data storage evercraft:dyeing {color_id:"noir"} as @e[type=armor_stand,tag=ec.bb_stand,distance=..1,sort=nearest,limit=1] on passengers run data modify entity @s item.components."minecraft:profile".properties[0].value set value "ewogICJ0aW1lc3RhbXAiIDogMTc4MDU1MDMzOTM2MiwKICAicHJvZmlsZUlkIiA6ICI0MDUxNzNiODY0OTM0NTUxOThlOGMzOGJmNmJmNjZiMSIsCiAgInByb2ZpbGVOYW1lIiA6ICJzcGFjZWNhZGV0MTgiLAogICJzaWduYXR1cmVSZXF1aXJlZCIgOiB0cnVlLAogICJ0ZXh0dXJlcyIgOiB7CiAgICAiU0tJTiIgOiB7CiAgICAgICJ1cmwiIDogImh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvZDdkMWQ2MzgwZWIyY2ZiMTU0NzQ5NjBkM2E5M2M0ZDA4ZjZmZjJmZTUyMTgyNzI2NTU5MTlmNzgzNGY4OTJkNyIKICAgIH0KICB9Cn0="

# Consume 1 dye from the player's main hand (guidestone idiom).
item modify entity @s weapon.mainhand {"function":"minecraft:set_count","count":-1,"add":true}

# Effects (sound + dye particles at the block).
function evercraft:dyeing/effects

# Feedback — name the color via the shared color_name field.
data modify storage evercraft:notify stage.c set value [{text:"Dyed ",color:"gray",italic:true},{storage:"evercraft:dyeing",nbt:"color_name",interpret:false,color:"#E0B0FF",italic:true},{text:" Ba\u00fal",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
