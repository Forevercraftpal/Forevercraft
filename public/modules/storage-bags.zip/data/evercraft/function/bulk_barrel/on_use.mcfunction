# ============================================================
# Baúl — Default-use intercept (deposit via the locked-barrel method)
# Run as: the player (@s), at @s — from structures/interact/on_open_barrel,
# BEFORE the black-market / structure checks (mirrors that intercept order).
# ------------------------------------------------------------
# The Baúl is a real (locked) minecraft:barrel, so a plain right-click no
# longer opens the vanilla GUI — it fires the open_barrel advancement, which
# lands here. We raycast to the used barrel; if it carries an ec.bb_marker it
# is a Baúl, so we deposit the held item. (Sneak-right-click bypasses block
# use entirely, so withdraw stays on the interaction-entity tick path.)
# Returns 1 if the used barrel was a Baúl (handled — stop the chain), else 0.
# Mirrors evercraft:black_market/check_barrel + structures/interact/raycast_barrel.
# ============================================================

scoreboard players set #bb_used ec.var 0

# OPT: only raycast when a Baúl is plausibly in reach.
execute unless entity @e[type=marker,tag=ec.bb_marker,distance=..8,limit=1] run return 0

scoreboard players set #bb_ray ec.var 0
execute anchored eyes positioned ^ ^ ^ run function evercraft:bulk_barrel/use_raycast
return run scoreboard players get #bb_used ec.var
