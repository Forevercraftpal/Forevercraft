# ============================================================
# Baúl — Give the withdrawn stack to the player
# Run as: the clicking player (@s), positioned AT the block center.
# Source: storage evercraft:bulk_barrel give_item (full item-stack
#         template incl. count, set by withdraw.mcfunction).
# ------------------------------------------------------------
# Summon-then-populate idiom (cf. crates/dump_into_container/drain_slot):
# spawn an item entity at the player and copy the stored template onto
# it. The player picks it up immediately; if their inventory is full it
# stays on the ground — never voided.
# ============================================================

# Spawn a placeholder item AT the player, tag it, then overwrite its Item
# with the stored template (id + components + count). PickupDelay:0 + Owner
# = the clicker grabs it instantly; if their inventory is full it stays on
# the ground — never voided.
execute at @s run summon item ~ ~0.5 ~ {Tags:["ec.bb_give_new"],PickupDelay:0s,Item:{id:"minecraft:stone",count:1}}
data modify entity @e[type=item,tag=ec.bb_give_new,limit=1] Item set from storage evercraft:bulk_barrel give_item
data modify entity @e[type=item,tag=ec.bb_give_new,limit=1] Owner set from entity @s UUID
tag @e[type=item,tag=ec.bb_give_new] remove ec.bb_give_new
