# ============================================================
# Baúl — Use hit: is this barrel a Baúl? If so, deposit.
# Run as: the player (@s), positioned AT the used barrel's block center.
# ------------------------------------------------------------
# Not a Baúl (no ec.bb_marker) → return 0, let on_open_barrel fall through
# to the black-market / structure checks. A Baúl → claim the interaction
# (#bb_used=1) so those checks don't also fire, then deposit the held item.
# Sneak-right-click withdraws via the interaction-entity tick path, so when
# sneaking we claim-and-stop here without depositing.
# ============================================================
execute unless entity @e[type=marker,tag=ec.bb_marker,distance=..1,limit=1] run return 0

scoreboard players set #bb_used ec.var 1

execute if predicate evercraft:is_sneaking run return 0
function evercraft:bulk_barrel/deposit
