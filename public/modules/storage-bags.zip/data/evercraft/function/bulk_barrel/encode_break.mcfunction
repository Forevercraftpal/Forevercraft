# ============================================================
# Baúl — Encode stored contents into the dropped (filled) Baúl item on break.
# Run as: the marker (@s), AT the block. Called from on_break only when bb_count > 0,
# AFTER the filled Baúl item (bulk_barrel/item_filled) has been loot-spawned and the
# vanilla barrel drop killed (so the nearest barrel item IS our drop).
# ------------------------------------------------------------
# Smuggles the count + template into the item via a minecraft:container marker: when the
# item is re-placed, the barrel block inherits the marker in slot 0, and setup ->
# restore_contents reads it back and restocks. Stored items are always plain (reject_components),
# so the template round-trips cleanly. Replaces the old loose drop_contents.
# ============================================================

# save = {count:<N>, item:<clean template, count 1>} — the payload to restore.
data modify storage evercraft:bulk_barrel save.item set from entity @s data.bb_item
data modify storage evercraft:bulk_barrel save.item.count set value 1
execute store result storage evercraft:bulk_barrel save.count int 1 run data get entity @s data.bb_count

# Smuggle MARKER item = the template carrying custom_data.bb_saved = save.
data modify storage evercraft:bulk_barrel smarker set from storage evercraft:bulk_barrel save.item
data modify storage evercraft:bulk_barrel smarker.components."minecraft:custom_data".bb_saved set from storage evercraft:bulk_barrel save

# Container component value = [{slot:0, item:<smarker>}] (the item-component format — lowercase slot,
# nested item; the block entity turns this into Items[{Slot:0b,…}] when placed).
data modify storage evercraft:bulk_barrel scont set value [{slot:0}]
data modify storage evercraft:bulk_barrel scont[0].item set from storage evercraft:bulk_barrel smarker

# Patch the just-dropped filled Baúl item (nearest barrel item — vanilla drop already killed in on_break).
data modify entity @e[type=item,nbt={Item:{id:"minecraft:barrel"}},distance=..2,sort=nearest,limit=1] Item.components."minecraft:container" set from storage evercraft:bulk_barrel scont

# --- Bake the stored contents into that same dropped item's VISIBLE lore, so the held Baúl shows WHAT it
#     holds and HOW MANY before re-placing it. Name = raw path with "minecraft:" dropped (10 chars),
#     matching report_count's display. encode_lore substitutes count + name into the lore as literal text
#     (item tooltips never resolve live data sources). ---
data modify storage evercraft:bulk_barrel name_id set from storage evercraft:bulk_barrel save.item.id
data modify storage evercraft:bulk_barrel lr.name set string storage evercraft:bulk_barrel name_id 10
data modify storage evercraft:bulk_barrel lr.count set from storage evercraft:bulk_barrel save.count
function evercraft:bulk_barrel/encode_lore with storage evercraft:bulk_barrel lr
