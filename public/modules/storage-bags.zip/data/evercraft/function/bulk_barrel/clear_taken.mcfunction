# ============================================================
# Baúl — Macro: remove exactly n of the deposit item.
# Run as: the clicking player (@s).
# Args: hand_id (item id string), n (amount to remove)
# ============================================================
$clear @s $(hand_id) $(n)
