# ============================================================
# Baúl — Route a right-click (deposit vs withdraw)
# Run as: the clicking player (@s), positioned AT the block center
#         (resolved via handle_click's UUID-match; position preserved).
# ------------------------------------------------------------
# Sneak-right-click  -> withdraw one stack of the stored item.
# Plain right-click  -> deposit the held item (all of that type).
# ============================================================

# Sneaking — withdraw a stack.
execute if predicate evercraft:is_sneaking run return run function evercraft:bulk_barrel/withdraw

# Otherwise — deposit the held item.
function evercraft:bulk_barrel/deposit
