# ============================================================
# Baúl — Hopper-out feed (run as the marker, AT the block; only when a hopper is directly below)
# ------------------------------------------------------------
# Keeps exactly ONE of the stored item in the barrel's slot 0 so a hopper below can pull it at vanilla
# speed. If slot 0 already holds the waiting item, do nothing this tick; otherwise commit one from the
# virtual count (hopper_place). The count is the source of truth; the slot holds at most 1 "in transit".
# ============================================================

# Nothing stored -> nothing to dispense.
execute store result score #bb_hf ec.var run data get entity @s data.bb_count
execute if score #bb_hf ec.var matches ..0 run return 0

# An item is already waiting in slot 0 for the hopper -> wait for it to be pulled.
execute if data block ~ ~ ~ Items[{Slot:0b}] run return 0

# Slot 0 is empty and there is stock -> commit one item.
function evercraft:bulk_barrel/hopper_place
