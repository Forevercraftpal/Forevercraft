# ============================================================
# Baúl — On Place (advancement reward)
# Run as: the placing player.
# Locates the just-placed barrel via a real raycast (+ grid-scan fallback), then builds the
# Baúl AT it (marker/lock/interaction/display) in bulk_barrel/setup.
#
# FIX (2026-06-03): the old locator was `positioned ^ ^ ^1 align xyz` — a single point one
# block straight ahead of the eyes. For a barrel placed on the ground (you look DOWN to place
# it) that point lands in the air OFF the barrel, so the marker + displays spawned off-block.
# Consequences the player saw: (1) the next tick's break-check found no barrel under the
# marker and fired on_break -> the Baúl item dropped back ("place it and it gives it back");
# (2) deposit/withdraw found no marker at the real barrel -> "it doesn't take the block".
# The raycast below mirrors the proven use_raycast + the Plinth/Guidestone place-detection.
# ============================================================

# Revoke so the advancement re-fires on the next placement.
advancement revoke @s only evercraft:bulk_barrel/place

scoreboard players set #bb_placed ec.var 0
scoreboard players set #bb_pray ec.var 0

# Primary: raycast forward from the eyes to the placed barrel (one with no Baúl marker yet).
execute at @s anchored eyes positioned ^ ^ ^ run function evercraft:bulk_barrel/place_raycast

# Fallback: grid-scan the placement zone if the raycast missed (oblique / off-axis angles).
execute if score #bb_placed ec.var matches 0 at @s align xyz run function evercraft:bulk_barrel/place_scan
