# ============================================================
# Baúl — Resolve the clicking player, run deposit/withdraw
# Run as: the clicked interaction entity (@s), positioned AT the block.
# ------------------------------------------------------------
# `execute on target` re-positions to the player, which would break our
# block-relative selectors. Instead we read the clicker's UUID from
# interaction.player, then match the player with `as` (executor swap only
# — execution position is preserved at the block) and run do_interact.
# Each nearby player's own UUID is computed inline (#bb_puid*), so no
# per-player scoreboard objective is needed. Mirrors the tomb UUID-match.
# ============================================================

# The clicker's UUID (4 ints) from the interaction event.
execute store result score #bb_uuid0 ec.var run data get entity @s interaction.player[0]
execute store result score #bb_uuid1 ec.var run data get entity @s interaction.player[1]
execute store result score #bb_uuid2 ec.var run data get entity @s interaction.player[2]
execute store result score #bb_uuid3 ec.var run data get entity @s interaction.player[3]

# Match the player by UUID, running as them but staying anchored at the
# block. `as` swaps the executor only; position remains the interaction's.
execute as @a[distance=..8] if function evercraft:bulk_barrel/is_clicker run function evercraft:bulk_barrel/do_interact
