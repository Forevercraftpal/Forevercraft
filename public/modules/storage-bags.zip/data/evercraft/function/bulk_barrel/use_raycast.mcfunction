# ============================================================
# Baúl — Use raycast step (recursive). Run as: the player, at the step pos.
# Steps forward 0.2/block, max 40 steps (8 blocks), to find the used barrel.
# On the first barrel hit, recenters and branches to use_hit (Baúl check +
# deposit). Stops at the first barrel either way (the used one), so a Baúl
# behind a wall is never falsely hit beyond the block the player used.
# ============================================================
scoreboard players add #bb_ray ec.var 1

# Hit a barrel — recenter on it and run the Baúl check / deposit.
execute if block ~ ~ ~ minecraft:barrel align xyz positioned ~0.5 ~0.5 ~0.5 run function evercraft:bulk_barrel/use_hit

# Otherwise keep stepping (until a barrel, the step cap, or a Baúl is handled).
execute if score #bb_used ec.var matches 0 if score #bb_ray ec.var matches ..40 unless block ~ ~ ~ minecraft:barrel positioned ^ ^ ^0.2 run function evercraft:bulk_barrel/use_raycast
