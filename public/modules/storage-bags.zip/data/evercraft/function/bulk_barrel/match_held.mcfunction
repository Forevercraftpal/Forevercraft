# ============================================================
# Baúl — Macro: reject if held mainhand id != locked id
# Run as: the clicking player (@s).
# Args: locked_id (the barrel's stored item id string)
# Sets #bb_reject ec.var = 1 and tellraws the locked-type message
# when the held item is NOT the locked type.
# ============================================================

# If the held item is NOT the locked type, reject with a clear message.
$execute unless items entity @s weapon.mainhand $(locked_id) run scoreboard players set #bb_reject ec.var 1
# Clean display name: drop the "minecraft:" namespace (10 chars) so it reads "cobblestone", not
# "minecraft:cobblestone". locked_id is already in storage (set by deposit_check_match) \u2014 no macro needed.
data modify storage evercraft:bulk_barrel name_path set string storage evercraft:bulk_barrel locked_id 10
data modify storage evercraft:notify stage.c set value [{text:"This Ba\u00fal only holds ",color:"gray",italic:true},{nbt:"name_path",storage:"evercraft:bulk_barrel",interpret:false,color:"white",italic:true},{text:".",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 45
$execute unless items entity @s weapon.mainhand $(locked_id) run function evercraft:bulk_barrel/notify
