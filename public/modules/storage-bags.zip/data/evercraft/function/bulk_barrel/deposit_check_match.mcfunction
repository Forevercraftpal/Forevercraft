# ============================================================
# Baúl — Reject mismatched deposits (locked barrels)
# Run as: the clicking player (@s), positioned AT the block center.
# Sets #bb_reject ec.var = 1 and messages if the held item id does
# not match the barrel's locked stored id; 0 otherwise.
# ============================================================

scoreboard players set #bb_reject ec.var 0

# Pull the locked id from the marker into working storage, then test the
# held mainhand against it by id via a macro (dynamic-id-safe).
data modify storage evercraft:bulk_barrel locked_id set from entity @e[type=marker,tag=ec.bb_marker,distance=..1,sort=nearest,limit=1] data.bb_id
function evercraft:bulk_barrel/match_held with storage evercraft:bulk_barrel
