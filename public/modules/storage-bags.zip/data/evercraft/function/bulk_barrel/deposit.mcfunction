# ============================================================
# Baúl — Deposit
# Run as: the clicking player (@s), positioned AT the block center.
# ------------------------------------------------------------
# Empty held hand -> nudge message.
# Empty barrel    -> lock the type to the held item, store its template.
# Locked barrel   -> accept only the matching item id; reject others.
# Transfers all of that item type in the player's inventory, capped
# strictly at 9,999. Leftover (over the cap) stays with the player.
# ============================================================

# --- Recolor intercept (before any deposit logic) ---
# Holding a dye -> recolor the Baúl skin (mirrors guidestone). Holding a water
# bucket -> wash back to default. Both `return` so the dye/bucket is never
# deposited, and both interaction paths (do_interact + use_hit) are covered
# here at the single shared chokepoint. Sneak-right-click withdraws and never
# reaches this function, so withdraw is unaffected.
execute if items entity @s weapon.mainhand #evercraft:dyes run return run function evercraft:bulk_barrel/dye_block
execute if items entity @s weapon.mainhand minecraft:water_bucket run return run function evercraft:bulk_barrel/wash_block

# Locate this block's marker (tight distance — multiplayer-safe per block).
execute unless entity @e[type=marker,tag=ec.bb_marker,distance=..1,sort=nearest,limit=1] run return 0

# Nothing in hand — guide the player.
data modify storage evercraft:notify stage.c set value [{text:"Hold an item to deposit it.",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 45
execute unless items entity @s weapon.mainhand * run return run function evercraft:bulk_barrel/notify

# Snapshot the held item id + full template into working storage.
data modify storage evercraft:bulk_barrel hand_item set from entity @s SelectedItem
data modify storage evercraft:bulk_barrel hand_id set from entity @s SelectedItem.id

# GUARD (item-loss): the Baúl flattens deposits to one plain template, so a
# component-bearing item (enchanted/named/custom_data/filled shulker/damaged
# tool) of the locked id would be cleared+counted but only ever withdrawn as
# the plain template -> its components are destroyed. Refuse such items BEFORE
# any lock/clear/count so they stay in the player's inventory untouched.
function evercraft:bulk_barrel/reject_components
execute if score #bb_reject ec.var matches 1 run return 0

# Read this barrel's state into scoreboards.
execute store result score #bb_count ec.var run data get entity @e[type=marker,tag=ec.bb_marker,distance=..1,sort=nearest,limit=1] data.bb_count
execute store result score #bb_locked ec.var run data get entity @e[type=marker,tag=ec.bb_marker,distance=..1,sort=nearest,limit=1] data.bb_locked

# Heal: an empty barrel (count 0) is never really locked. Force it unlocked
# so a stale bb_locked=1 / bb_count=0 marker accepts a fresh item and re-locks
# to whatever is deposited next, instead of rejecting everything forever.
execute if score #bb_count ec.var matches ..0 run scoreboard players set #bb_locked ec.var 0

# If locked, the held id must equal the stored id — else reject.
scoreboard players set #bb_reject ec.var 0
execute if score #bb_locked ec.var matches 1 run function evercraft:bulk_barrel/deposit_check_match
execute if score #bb_reject ec.var matches 1 run return 0

# If empty, lock the type to the held item now (store id + template).
execute if score #bb_locked ec.var matches 0 run function evercraft:bulk_barrel/lock_type

# Compute remaining capacity (9999 - current count).
scoreboard players set #bb_cap ec.var 9999
scoreboard players operation #bb_cap ec.var -= #bb_count ec.var

# Barrel already full.
data modify storage evercraft:notify stage.c set value [{text:"This Ba\u00fal is full (9,999).",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 45
execute if score #bb_cap ec.var matches ..0 run return run function evercraft:bulk_barrel/notify

# Count how many of the locked item the player is holding across their
# inventory (clear with count 0 reports without removing).
execute store result score #bb_have ec.var run function evercraft:bulk_barrel/count_held with storage evercraft:bulk_barrel

# Take min(have, cap) — only deposit up to the remaining capacity.
scoreboard players operation #bb_take ec.var = #bb_have ec.var
execute if score #bb_take ec.var > #bb_cap ec.var run scoreboard players operation #bb_take ec.var = #bb_cap ec.var

# Nothing to take (should not happen after the full check, but guard).
execute if score #bb_take ec.var matches ..0 run return 0

# Remove exactly #bb_take of the item from the player.
execute store result storage evercraft:bulk_barrel n int 1 run scoreboard players get #bb_take ec.var
function evercraft:bulk_barrel/clear_taken with storage evercraft:bulk_barrel

# Add to the stored count and persist on the marker.
scoreboard players operation #bb_count ec.var += #bb_take ec.var
execute store result entity @e[type=marker,tag=ec.bb_marker,distance=..1,sort=nearest,limit=1] data.bb_count int 1 run scoreboard players get #bb_count ec.var

# Refresh the front displays.
function evercraft:bulk_barrel/update_display

# Feedback.
playsound minecraft:block.barrel.close master @a[distance=..12,scores={ec.fx_snd=1..}] ~ ~ ~ 0.6 1.3
particle minecraft:happy_villager ~ ~1.1 ~ 0.3 0.2 0.3 0.02 5
data modify storage evercraft:notify stage.c set value [{text:"Deposited ",color:"gray"},{score:{name:"#bb_take",objective:"ec.var"},color:"white"},{text:" — now holding ",color:"gray"},{score:{name:"#bb_count",objective:"ec.var"},color:"gold"},{text:" / 9,999.",color:"gray"}]
scoreboard players set #ndur ec.temp 45
function evercraft:bulk_barrel/notify
