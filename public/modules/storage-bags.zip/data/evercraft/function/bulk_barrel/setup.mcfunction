# ============================================================
# Baúl — Setup at the placed barrel block
# Run at: the barrel block corner (align xyz), as: the placing player.
# Builds the marker + lock + interaction + head display + the two front overlays,
# faces them to the placer, and announces. Split out of on_place (2026-06-03) so the
# block is found by a real raycast/scan instead of the old `^ ^ ^1` single point that
# missed ground placements — that mislocation spawned the marker off the barrel, which
# made the tick break-check fire (the Baúl 'gave itself back') AND made deposits find
# no marker ('wouldn't take the item'). Now the marker always lands on the barrel.
# ============================================================

# Stop the placement raycast / fallback scan from re-firing once we've built one.
scoreboard players set #bb_placed ec.var 1

# Spawn marker at block center holding the storage state.
#   bb_count  = stored amount (0..9999)
#   bb_locked = 0 empty/unlocked, 1 locked to bb_id
#   bb_id     = stored item id string (e.g. "minecraft:cobblestone")
#   bb_item   = full item-stack template (id + components) for withdrawals
#   bb_color  = dye recolor id ("" = default skin; set by bulk_barrel/dye_block)
summon marker ~0.5 ~ ~0.5 {Tags:["ec.bb_marker","ec.lodestone_registered"],data:{bb_count:0,bb_locked:0b,bb_id:"",bb_item:{id:"minecraft:air",count:1},bb_color:""}}

# Lock the barrel so the vanilla GUI never opens. A plain right-click then
# fires the open_barrel advancement, which bulk_barrel/on_use turns into a
# deposit (the black-market / crate method). No player can hold an ec_bb_key
# item, so the lock is unsatisfiable; the custom_data predicate avoids the
# MC-276956 registry-lookup bug. Sneak-right-click still reaches the
# interaction entity for withdraw (sneaking bypasses block use entirely).
data merge block ~ ~ ~ {lock:{predicates:{"minecraft:custom_data":"{ec_bb_key:1b}"}}}

# Spawn interaction entity at the block (front/top) for right-click detection.
summon interaction ~0.5 ~0.5 ~0.5 {Tags:["ec.bb_click"],width:1.0f,height:1.0f,response:1b}

# Spawn the armor_stand + item_display head passenger (Baúl skin).
summon armor_stand ~0.5 ~ ~0.5 {Tags:["ec.bb_stand","ec.bb_visual","ec.block_new","smithed.entity"],NoGravity:true,Invisible:true,Small:true,Invulnerable:true,DisabledSlots:4144959,Passengers:[{id:"minecraft:item_display",Tags:["ec.bb_visual","smithed.entity"],brightness:{sky:15,block:15},view_range:1f,width:0f,height:0f,item_display:"head",transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0.0f,0.05f,0.0f],scale:[2.05f,2.1f,2.05f]},item:{id:"minecraft:player_head",count:1,components:{"minecraft:profile":{id:[I;-1974477980,147736616,-1635819972,23806684],properties:[{"name":"textures","value":"ewogICJ0aW1lc3RhbXAiIDogMTc4MDU0OTkzMzgzMCwKICAicHJvZmlsZUlkIiA6ICIwZWQ2MDFlMDhjZTM0YjRkYWUxZmI4MDljZmEwNTM5NiIsCiAgInByb2ZpbGVOYW1lIiA6ICJOZWVkTW9yZUFjY291bnRzIiwKICAic2lnbmF0dXJlUmVxdWlyZWQiIDogdHJ1ZSwKICAidGV4dHVyZXMiIDogewogICAgIlNLSU4iIDogewogICAgICAidXJsIiA6ICJodHRwOi8vdGV4dHVyZXMubWluZWNyYWZ0Lm5ldC90ZXh0dXJlLzgxYWIwOTg0OGQ1MmEzYzUyZDg3NjkzM2UzOWQwNDQ5Nzc0NWJiNWFiNzNjN2EwYWY2OTM5N2JjMzY1YzgzMWEiCiAgICB9CiAgfQp9"}]}}}}]}

# Front overlay: count text_display. Empty barrel shows "Empty".
# (A contained-item icon used to sit here at ~0.55 in `item_display:"gui"` mode, but GUI mode never
# rendered in-world behind the 2x head skin — removed 2026-06-06. The floating item_display above the
# lid (ec.bb_float, summoned just below) now shows the contents instead.)
summon text_display ~0.5 ~0.18 ~0.5 {Tags:["ec.bb_text","ec.bb_visual","ec.block_new","smithed.entity"],billboard:"fixed",brightness:{sky:15,block:15},view_range:1f,see_through:false,background:0,text:{text:"Empty",color:"gray",italic:false},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0.0f,0.0f,0.0f],scale:[0.5f,0.5f,0.5f]}}

# Floating contents indicator: an item_display hovering above the lid (like a resource node's floating
# block) that shows WHAT is stored. Renders block contents as a 3D block; billboard:"vertical" keeps any
# item readable from every horizontal angle. Empty on place — update_display mirrors the stored template
# onto it on each deposit/withdraw. NO ec.block_new tag, so the front-face rotation/offset below skip it
# (this is a top, view-from-any-angle cue, not a front overlay). Killed by on_break with the others.
summon item_display ~0.5 ~1.4 ~0.5 {Tags:["ec.bb_float","ec.bb_visual","smithed.entity"],billboard:"vertical",brightness:{sky:15,block:15},view_range:1f,width:0f,height:0f,item_display:"fixed",transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0.0f,0.0f,0.0f],scale:[0.5f,0.5f,0.5f]},item:{id:"minecraft:air",count:1}}

# Rotate all front-facing displays to face the placer (4-quadrant quaternion).
# Mirrors evercraft:craftforever/forging/spawn_display (incl. the North fix).
execute store result score #bb_rot ec.var run data get entity @s Rotation[0]
execute if score #bb_rot ec.var matches -45..44 as @e[tag=ec.bb_visual,tag=ec.block_new,distance=..3] run function evercraft:bulk_barrel/util/set_facing {q:"[0f,1f,0f,0f]"}
execute if score #bb_rot ec.var matches 45..134 as @e[tag=ec.bb_visual,tag=ec.block_new,distance=..3] run function evercraft:bulk_barrel/util/set_facing {q:"[0f,0.7071f,0f,-0.7071f]"}
execute if score #bb_rot ec.var matches -134..-45 as @e[tag=ec.bb_visual,tag=ec.block_new,distance=..3] run function evercraft:bulk_barrel/util/set_facing {q:"[0f,0.7071f,0f,0.7071f]"}
execute if score #bb_rot ec.var matches 135.. as @e[tag=ec.bb_visual,tag=ec.block_new,distance=..3] run function evercraft:bulk_barrel/util/set_facing {q:"[0f,0f,0f,1f]"}
execute if score #bb_rot ec.var matches ..-135 as @e[tag=ec.bb_visual,tag=ec.block_new,distance=..3] run function evercraft:bulk_barrel/util/set_facing {q:"[0f,0f,0f,1f]"}

# Push the icon + text overlays slightly off the front face toward the placer
# so they sit in the viewing window rather than inside the head.
function evercraft:bulk_barrel/util/offset_overlays

# Clear the placement marker tag now that rotation/offset are applied.
# Scoped to bulk-barrel visuals so a concurrently-placed forge/crate's
# transient ec.block_new tag is never touched.
tag @e[tag=ec.bb_visual,tag=ec.block_new] remove ec.block_new

# Feedback.
data modify storage evercraft:notify stage.c set value [{text:"Ba\u00fal placed! ",color:"gold"},{text:"Right-click to deposit, sneak-right-click to withdraw.",color:"gray"}]
scoreboard players set #ndur ec.temp 45
execute as @s run function evercraft:util/notify/emit
playsound minecraft:block.barrel.open master @a[distance=..16,scores={ec.fx_snd=1..}] ~ ~ ~ 0.8 1.0
particle minecraft:happy_villager ~0.5 ~1.2 ~0.5 0.3 0.2 0.3 0.02 8

# ── Restore contents from a broken-Baúl smuggle (Joseph 2026-06-06): a Baúl broken with stock dropped
# the filled item carrying a slot-0 marker (custom_data.bb_saved {count,item}); on re-place the barrel
# block inherits that marker. If present, restock this Baúl + clear the smuggle (restore_contents). ──
execute if data block ~ ~ ~ Items[{Slot:0b}].components."minecraft:custom_data".bb_saved run function evercraft:bulk_barrel/restore_contents
