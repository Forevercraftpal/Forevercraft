# ============================================================
# Baúl — Report stored amount on left-click (attack)
# Run as: the clicked interaction entity (@s), positioned AT the block.
# Reads this block's marker count and tells the ATTACKING player (resolved
# by UUID from the attack event, mirroring handle_click's right-click match).
# The floating item above the lid shows WHAT is stored; this shows HOW MANY.
# ============================================================

# Read this block's stored count.
scoreboard players set #bb_rc ec.var 0
execute store result score #bb_rc ec.var run data get entity @e[type=marker,tag=ec.bb_marker,distance=..1,sort=nearest,limit=1] data.bb_count

# Clean display name from the stored id: drop the "minecraft:" namespace (10 chars) so the message shows
# "cobblestone", not "minecraft:cobblestone". Baúl items are always vanilla/plain, so the namespace is
# always "minecraft:". Only needed when stocked (bb_id is set).
execute if score #bb_rc ec.var matches 1.. run data modify storage evercraft:bulk_barrel name_id set from entity @e[type=marker,tag=ec.bb_marker,distance=..1,sort=nearest,limit=1] data.bb_id
execute if score #bb_rc ec.var matches 1.. run data modify storage evercraft:bulk_barrel name_path set string storage evercraft:bulk_barrel name_id 10

# Build the message — empty vs "holds N / 9,999 <item>".
data modify storage evercraft:notify stage.c set value [{text:"This Baúl is empty.",color:"gray",italic:true}]
execute if score #bb_rc ec.var matches 1.. run data modify storage evercraft:notify stage.c set value [{text:"This Baúl holds ",color:"gray"},{score:{name:"#bb_rc",objective:"ec.var"},color:"gold"},{text:" / 9,999 ",color:"gray"},{nbt:"name_path",storage:"evercraft:bulk_barrel",interpret:false,color:"white"},{text:".",color:"gray"}]
scoreboard players set #ndur ec.temp 45

# Resolve the attacker by UUID (same four-int match is_clicker uses for right-clicks), then emit to them.
execute store result score #bb_uuid0 ec.var run data get entity @s attack.player[0]
execute store result score #bb_uuid1 ec.var run data get entity @s attack.player[1]
execute store result score #bb_uuid2 ec.var run data get entity @s attack.player[2]
execute store result score #bb_uuid3 ec.var run data get entity @s attack.player[3]
execute as @a[distance=..8] if function evercraft:bulk_barrel/is_clicker run function evercraft:bulk_barrel/notify
