# ============================================================
# Baúl — Throttled action-bar notify (drop-in for util/notify/emit in the CLICK handlers).
# Run as @s = the viewer; execution position is at/near the block (the nearest ec.bb_marker, ..1).
# stage.c is preset by the caller (same contract as util/notify/emit).
# ------------------------------------------------------------
# WHY: util/notify/emit QUEUES frames per player and plays them one at a time, so holding a click
# (deposit / withdraw / left-click report) piles up a backlog that keeps playing after you stop.
# This emits at most once per ~20t per BARREL (marker data.bb_ntime) and forces a short ~20t frame
# duration == the throttle window, so frames never out-pace their display and no backlog accrues.
# One-shot messages (place / restore / dye / rapid-empty dump) keep calling util/notify/emit directly.
# data.bb_ntime auto-creates on first use (no marker-summon change).
# ============================================================

execute store result score #bb_now ec.var run time query gametime
scoreboard players set #bb_nlast ec.var 0
execute store result score #bb_nlast ec.var run data get entity @e[type=marker,tag=ec.bb_marker,distance=..1,sort=nearest,limit=1] data.bb_ntime
scoreboard players operation #bb_ngap ec.var = #bb_now ec.var
scoreboard players operation #bb_ngap ec.var -= #bb_nlast ec.var

# Within the throttle window since this barrel's last notify -> suppress (anti hold-click spam).
execute if score #bb_ngap ec.var matches 0..19 run return 0

# Allowed: stamp the time, force a short frame (== throttle window, so the queue never backlogs), emit.
execute store result entity @e[type=marker,tag=ec.bb_marker,distance=..1,sort=nearest,limit=1] data.bb_ntime int 1 run scoreboard players get #bb_now ec.var
scoreboard players set #ndur ec.temp 20
function evercraft:util/notify/emit
