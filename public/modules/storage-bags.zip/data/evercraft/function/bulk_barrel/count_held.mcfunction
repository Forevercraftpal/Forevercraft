# ============================================================
# Baúl — Macro: count how many of the deposit item the player
#                       holds across their whole inventory.
# Run as: the clicking player (@s).
# Args: hand_id (item id string, e.g. "minecraft:cobblestone")
# Returns (via the calling `store result`): the count.
# ------------------------------------------------------------
# `clear` with a count of 0 reports the matching total WITHOUT
# removing anything (vanilla dry-run idiom). MUST use `return run`
# so the count propagates to the caller's `store result` — since MC
# 1.20.3 a function returns NOTHING unless it runs an explicit
# `return` (see black_market/lore_sale/consume for the same idiom).
# ============================================================
$return run clear @s $(hand_id) 0
