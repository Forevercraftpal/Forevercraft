# ============================================================
# Baúl — Tick (called from evercraft:tick, existence-gated)
# Handles right-click interactions + block-break cleanup.
# Mirrors evercraft:craftforever/tick (interaction + break blocks).
# ============================================================

# OPT: Early exit if no Baúl entities exist.
execute unless entity @e[type=interaction,tag=ec.bb_click,limit=1] unless entity @e[type=marker,tag=ec.bb_marker,limit=1] run return 0

# --- Right-click detection ---
# Run AS each clicked interaction, positioned AT the block; handle_click
# resolves the clicking player by UUID and runs deposit/withdraw while
# the execution position stays anchored at the block (NOT the player).
execute as @e[type=interaction,tag=ec.bb_click] if data entity @s interaction at @s run function evercraft:bulk_barrel/handle_click
execute as @e[type=interaction,tag=ec.bb_click] if data entity @s interaction run data remove entity @s interaction

# --- Left-click (attack) detection: report the stored amount to the attacking player. ---
execute as @e[type=interaction,tag=ec.bb_click] if data entity @s attack at @s run function evercraft:bulk_barrel/report_count
execute as @e[type=interaction,tag=ec.bb_click] if data entity @s attack run data remove entity @s attack

# --- Break detection ---
# Run as each marker; if the anchor barrel block is gone, the barrel
# was broken — drop contents + the item, then clean up entities.
execute as @e[type=marker,tag=ec.bb_marker] at @s unless block ~ ~ ~ minecraft:barrel run function evercraft:bulk_barrel/on_break

# --- Hopper-out (Joseph's "replicate one at a time" model) ---
# When a hopper sits directly below a Baúl, keep ONE of the stored item in the barrel's real slot 0 so
# the hopper drains it at vanilla speed; the slot is replenished from the virtual count (one at a time,
# decrement-on-commit) until the count is exhausted. Hoppers bypass the GUI lock, so extraction just works.
execute as @e[type=marker,tag=ec.bb_marker] at @s if block ~ ~-1 ~ minecraft:hopper run function evercraft:bulk_barrel/hopper_feed

# --- Lock self-heal ---
# Ensure every live Baúl barrel is locked so its right-click never opens the
# vanilla GUI (the open is intercepted as a deposit in on_open_barrel). New
# Baúls are locked in on_place; this catches any placed before that change.
# The merge only runs while the lock is absent, so it self-sunsets per block.
execute as @e[type=marker,tag=ec.bb_marker] at @s if block ~ ~ ~ minecraft:barrel unless data block ~ ~ ~ lock run data merge block ~ ~ ~ {lock:{predicates:{"minecraft:custom_data":"{ec_bb_key:1b}"}}}

# ===== INSPECT (left-click = what does this button do?) — gui/inspect pattern 2026-06-11 =====
execute as @e[type=interaction,tag=ec.bb_click] if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Bulk Barrel",b:"Filled hand: pours the stack in. Empty hand: draws a stack back out."}
execute as @e[type=interaction,tag=ec.bb_click] if data entity @s attack run data remove entity @s attack
