# ============================================================
# Baúl — Lock the stored type to the held item (first deposit)
# Run as: the clicking player (@s), positioned AT the block center.
# Persists the held item's id + full template on the marker so
# withdrawals reconstruct the exact item, and flags the barrel locked.
# ============================================================

# Persist id + full item template onto the marker.
data modify entity @e[type=marker,tag=ec.bb_marker,distance=..1,sort=nearest,limit=1] data.bb_id set from storage evercraft:bulk_barrel hand_id
data modify entity @e[type=marker,tag=ec.bb_marker,distance=..1,sort=nearest,limit=1] data.bb_item set from storage evercraft:bulk_barrel hand_item
data modify entity @e[type=marker,tag=ec.bb_marker,distance=..1,sort=nearest,limit=1] data.bb_locked set value 1b

# Normalize the stored template count to 1 (it is a per-item template).
data modify entity @e[type=marker,tag=ec.bb_marker,distance=..1,sort=nearest,limit=1] data.bb_item.count set value 1
