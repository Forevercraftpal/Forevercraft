# ============================================================
# Baúl — Refresh the front overlays (icon + count text)
# Run at: the block center (positioned), after a deposit/withdraw.
# Reads the block's marker (count + template) and updates the
# contained-item icon and the "n / 9,999" count text, color-graded
# white -> gold as the barrel fills.
# ============================================================

execute unless entity @e[type=marker,tag=ec.bb_marker,distance=..1,sort=nearest,limit=1] run return 0
execute store result score #bb_count ec.var run data get entity @e[type=marker,tag=ec.bb_marker,distance=..1,sort=nearest,limit=1] data.bb_count

# ── Empty barrel: blank the floating indicator, show "Empty" ──
execute if score #bb_count ec.var matches ..0 run data modify entity @e[type=item_display,tag=ec.bb_float,distance=..1,sort=nearest,limit=1] item set value {id:"minecraft:air",count:1}
execute if score #bb_count ec.var matches ..0 run data modify entity @e[type=text_display,tag=ec.bb_text,distance=..1,sort=nearest,limit=1] text set value {text:"Empty",color:"gray",italic:false}
execute if score #bb_count ec.var matches ..0 run return 0

# ── Stocked barrel: mirror the stored template onto the floating indicator ──
data modify entity @e[type=item_display,tag=ec.bb_float,distance=..1,sort=nearest,limit=1] item set from entity @e[type=marker,tag=ec.bb_marker,distance=..1,sort=nearest,limit=1] data.bb_item

# Build "n / 9,999" with the live count, then color by fill level.
# Both the count and the color go into the SAME storage source, since a
# macro call takes one source (inline {..} OR `with`, never both).
execute store result storage evercraft:bulk_barrel disp_count int 1 run scoreboard players get #bb_count ec.var

# Color grade: white (<3333) -> yellow (3333..6665) -> gold (6666..9998) -> green at cap.
execute if score #bb_count ec.var matches 9999.. run data modify storage evercraft:bulk_barrel disp_color set value "green"
execute if score #bb_count ec.var matches 6666..9998 run data modify storage evercraft:bulk_barrel disp_color set value "gold"
execute if score #bb_count ec.var matches 3333..6665 run data modify storage evercraft:bulk_barrel disp_color set value "yellow"
execute if score #bb_count ec.var matches 1..3332 run data modify storage evercraft:bulk_barrel disp_color set value "white"
function evercraft:bulk_barrel/set_count_text with storage evercraft:bulk_barrel
