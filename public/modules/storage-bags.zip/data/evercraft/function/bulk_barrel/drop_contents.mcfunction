# ============================================================
# Baúl — Drop stored contents as ground items (recursive)
# Run as: the marker entity (ec.bb_marker), at its position.
# Reads data.bb_count; drops one stack (up to 64) of the stored
# template per pass and recurses until the count is exhausted.
# Bounded: max 9,999 / 64 ≈ 157 passes for a one-time break event.
# Never voids items.
# ============================================================

execute store result score #bb_count ec.var run data get entity @s data.bb_count
execute if score #bb_count ec.var matches ..0 run return 0

# This pass drops min(count, 64).
scoreboard players operation #bb_drop ec.var = #bb_count ec.var
scoreboard players set #bb_64 ec.var 64
execute if score #bb_drop ec.var > #bb_64 ec.var run scoreboard players operation #bb_drop ec.var = #bb_64 ec.var

# Build the drop stack from the stored template with this pass's count.
data modify storage evercraft:bulk_barrel drop_item set from entity @s data.bb_item
execute store result storage evercraft:bulk_barrel drop_item.count int 1 run scoreboard players get #bb_drop ec.var

# Spawn the ground item and populate it from the template (summon-then-populate).
summon item ~ ~0.5 ~ {Tags:["ec.bb_drop_new"],PickupDelay:10s,Item:{id:"minecraft:stone",count:1}}
data modify entity @e[type=item,tag=ec.bb_drop_new,limit=1] Item set from storage evercraft:bulk_barrel drop_item
tag @e[type=item,tag=ec.bb_drop_new] remove ec.bb_drop_new

# Decrement and persist, then recurse for the remainder.
scoreboard players operation #bb_count ec.var -= #bb_drop ec.var
execute store result entity @s data.bb_count int 1 run scoreboard players get #bb_count ec.var
execute if score #bb_count ec.var matches 1.. run function evercraft:bulk_barrel/drop_contents
