# ============================================================
# Baúl — Reject component-bearing (loss-prone) deposits
# Run as: the clicking player (@s). Called only from deposit.mcfunction,
# after the held item is confirmed present (SelectedItem exists).
# ------------------------------------------------------------
# The Baúl matches / counts / clears deposits by BARE ITEM ID and re-mints
# the locked template on withdrawal, so any item carrying data beyond a plain
# commodity (enchants, a custom name, custom_data, a filled container, damage,
# potion contents, …) would be flattened to the template and lose that data.
# Refuse such items BEFORE any lock/clear/count: set #bb_reject ec.var = 1 and
# notify; the caller returns without touching the inventory.
#
# WHY a single `SelectedItem.components` test (not per-component item predicates):
# an `items entity @s …[minecraft:enchantments]` predicate tests the item's
# RESOLVED components — which INCLUDE the vanilla prototype defaults (every item
# reports an empty `minecraft:enchantments`, a `max_stack_size`, a `rarity`, …).
# So the old bare-presence lines matched EVERY item, incl. plain cobblestone, and
# the Baúl rejected all deposits. The item-stack NBT `SelectedItem.components`
# instead holds ONLY the EXPLICITLY-set components (defaults are never serialized
# onto the stack). So: components present == loss-prone (reject); absent == plain,
# stackable goods (accept). Cleaner and strictly more protective (also catches
# potions, fireworks, bundles, …) than the old six-line enumeration.
# ============================================================

# Reject iff the held item carries ANY explicit (non-default) component.
execute store success score #bb_reject ec.var if data entity @s SelectedItem.components

# If flagged, notify and leave (caller returns on reject).
data modify storage evercraft:notify stage.c set value [{text:"The Baúl only holds plain, stackable goods.",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 45
execute if score #bb_reject ec.var matches 1 run function evercraft:bulk_barrel/notify
