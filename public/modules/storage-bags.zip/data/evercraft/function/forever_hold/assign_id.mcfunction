# Forever Hold — Assign unique ID to player
scoreboard players add #next_fhold_id ec.var 1
scoreboard players operation @s ec.fhold_id = #next_fhold_id ec.var
