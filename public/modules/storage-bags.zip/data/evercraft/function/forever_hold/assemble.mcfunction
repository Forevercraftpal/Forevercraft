# Forever Hold — Assemble (run as the player at the Transmutation Stand)
# Consumes the Ore Bag + Ingredient Binder + Pantry, folding each one's PRESERVED storage
# into a tab of a new Forever Hold. Defensive re-check so a stale button can't dupe.

# Re-verify all three bags are present
scoreboard players set #fh_ob ec.temp 0
scoreboard players set #fh_bn ec.temp 0
scoreboard players set #fh_pt ec.temp 0
execute if items entity @s container.* *[custom_data~{ore_bag:true}] run scoreboard players set #fh_ob ec.temp 1
execute if items entity @s container.* *[custom_data~{alch_binder:true}] run scoreboard players set #fh_bn ec.temp 1
execute if items entity @s container.* *[custom_data~{pantry:true}] run scoreboard players set #fh_pt ec.temp 1
data modify storage evercraft:notify stage.c set value [{text:"You need all three bags to assemble a Forever Hold.",color:"red"}]
scoreboard players set #ndur ec.temp 50
execute unless score #fh_ob ec.temp matches 1 run return run function evercraft:util/notify/emit
execute unless score #fh_bn ec.temp matches 1 run return run function evercraft:util/notify/emit
execute unless score #fh_pt ec.temp matches 1 run return run function evercraft:util/notify/emit

# Fresh Hold id (baked into both the storage key and the granted item)
scoreboard players add #next_fhold_id ec.var 1
scoreboard players operation @s ec.fhid = #next_fhold_id ec.var
scoreboard players operation @s ec.fhold_id = #next_fhold_id ec.var
execute store result storage evercraft:forever_hold temp.hid int 1 run scoreboard players get @s ec.fhid
function evercraft:forever_hold/init_if_missing with storage evercraft:forever_hold temp

# Read each bag's stamped storage id straight from inventory NBT
scoreboard players set #fh_obid ec.temp 0
scoreboard players set #fh_bnid ec.temp 0
scoreboard players set #fh_ptid ec.temp 0
execute store result score #fh_obid ec.temp run data get entity @s Inventory[{components:{"minecraft:custom_data":{ore_bag:1b}}}].components."minecraft:custom_data".ore_bag_id
execute store result score #fh_bnid ec.temp run data get entity @s Inventory[{components:{"minecraft:custom_data":{alch_binder:1b}}}].components."minecraft:custom_data".binder_id
execute store result score #fh_ptid ec.temp run data get entity @s Inventory[{components:{"minecraft:custom_data":{pantry:1b}}}].components."minecraft:custom_data".pantry_id

# Fold each present (stamped) bag into its tab — the tab IS the bag's 27-slot shape, so the
# whole store copies in one move; then the source is cleared so it can't be resurrected.
data modify storage evercraft:forever_hold temp.ct.hid set from storage evercraft:forever_hold temp.hid
execute store result storage evercraft:forever_hold temp.ct.sid int 1 run scoreboard players get #fh_obid ec.temp
data modify storage evercraft:forever_hold temp.ct.tab set value "ore"
data modify storage evercraft:forever_hold temp.ct.sns set value "evercraft:ore_bag"
execute if score #fh_obid ec.temp matches 1.. run function evercraft:forever_hold/copy_tab with storage evercraft:forever_hold temp.ct
execute store result storage evercraft:forever_hold temp.ct.sid int 1 run scoreboard players get #fh_bnid ec.temp
data modify storage evercraft:forever_hold temp.ct.tab set value "alch"
data modify storage evercraft:forever_hold temp.ct.sns set value "evercraft:alch_binder"
execute if score #fh_bnid ec.temp matches 1.. run function evercraft:forever_hold/copy_tab with storage evercraft:forever_hold temp.ct
execute store result storage evercraft:forever_hold temp.ct.sid int 1 run scoreboard players get #fh_ptid ec.temp
data modify storage evercraft:forever_hold temp.ct.tab set value "pantry"
data modify storage evercraft:forever_hold temp.ct.sns set value "evercraft:pantry"
execute if score #fh_ptid ec.temp matches 1.. run function evercraft:forever_hold/copy_tab with storage evercraft:forever_hold temp.ct

# Consume the three bag items (leave has_* set so they aren't re-granted later)
clear @s minecraft:leather[custom_data~{ore_bag:true}]
clear @s minecraft:leather[custom_data~{alch_binder:true}]
clear @s minecraft:leather[custom_data~{pantry:true}]

# Grant the pre-stamped Forever Hold + announce
function evercraft:forever_hold/give_stamped with storage evercraft:forever_hold temp
scoreboard players set @s ec.has_fhold 1
data modify storage evercraft:notify stage.c set value [{text:"❖ ",color:"#B19CD9"},{text:"Three become one. The ",color:"gray"},{text:"Forever Hold",color:"#B19CD9",bold:true},{text:" holds your Ore Bag, Binder & Pantry — all preserved.",color:"gray"}]
scoreboard players set #ndur ec.temp 90
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.beacon.activate master @s ~ ~ ~ 0.7 1.2
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.6 1.5
execute at @s run particle minecraft:end_rod ~ ~1 ~ 0.4 0.6 0.4 0.02 40
