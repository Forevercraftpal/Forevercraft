# Forever Hold — Clear stored bag contents for a given pid (macro)
# Called from strip flow with: function evercraft:forever_hold/clear_bag with storage evercraft:strip temp
# Storage path mirrors init_if_missing.mcfunction (bags.<pid>)
$data remove storage evercraft:forever_hold bags.$(pid)
