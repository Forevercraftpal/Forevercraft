# Forever Hold — On right-click (consume_item trigger)
# consume_item fires BEFORE the game removes the item.
# Tag for 1-tick delayed restore, then handle menu logic.

advancement revoke @s only evercraft:forever_hold/open

# Tag for delayed restore (next tick restores the Forever Hold item)
# Detect which hand held the Forever Hold for correct restore
tag @s remove ec.fhold_mainhand
execute if items entity @s weapon.mainhand *[custom_data~{forever_hold:true}] run tag @s add ec.fhold_mainhand
tag @s add ec.fhold_restore

# If already in menu, toggle close
execute if entity @s[tag=ec.fhold_in_menu] run function evercraft:forever_hold/menu/close
execute if entity @s[tag=ec.fhold_in_menu] run return 0

# Ensure player has an Forever Hold ID
execute unless score @s ec.fhold_id matches 1.. run function evercraft:forever_hold/assign_id

# Read forever_hold_id from held item (still present this tick, before removal)
execute store result score @s ec.fhid run data get entity @s SelectedItem.components."minecraft:custom_data".forever_hold_id

# If forever_hold_id is 0, stamp a new one via hopper minecart intermediary
execute if score @s ec.fhid matches 0 run function evercraft:forever_hold/stamp_id

# Clear any unstamped duplicate
clear @s minecraft:leather[custom_data~{forever_hold:true,forever_hold_id:0b}]

# Store forever_hold_id to temp for menu macros (init_if_missing keys on hid)
execute store result storage evercraft:forever_hold temp.pid int 1 run scoreboard players get @s ec.fhid
execute store result storage evercraft:forever_hold temp.hid int 1 run scoreboard players get @s ec.fhid

# Save item data for restore (preserves stamped forever_hold_id)
# WA59-P0-RACE (2026-06-22): per-UUID restore key so two players RC-ing in the same tick
# cannot clobber each other's pending restore item (mirrors tamed_bond mementos."<UUID>").
data modify storage evercraft:forever_hold temp.restore_item set from entity @s SelectedItem
# Migrate legacy items: drop max_stack_size:1 so the Forever Hold shares a bundle (weight 1, like the satchels)
data remove storage evercraft:forever_hold temp.restore_item.components."minecraft:max_stack_size"
data modify storage evercraft:forever_hold temp.uuid set from entity @s UUID
function evercraft:forever_hold/store_restore with storage evercraft:forever_hold temp

# Initialize hub storage if missing (three preserved tabs)
function evercraft:forever_hold/init_if_missing with storage evercraft:forever_hold temp

# Open the menu
function evercraft:forever_hold/menu/open
