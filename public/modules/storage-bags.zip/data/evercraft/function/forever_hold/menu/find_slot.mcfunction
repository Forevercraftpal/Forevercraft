# Forever Hold Menu — Find slot for stacking within a tab (macro)
# Args: hid, tab, hk (held key).  Out: #fk + temp.tgt (matching slot) | #fe (lowest empty).
scoreboard players set #fk ec.temp 0
scoreboard players set #fe ec.temp -1
data modify storage evercraft:forever_hold temp.tgt set value "none"

# Match scan (descending so lowest index wins)
$execute if data storage evercraft:forever_hold holds.$(hid).$(tab).s26{key:"$(hk)"} run scoreboard players set #fk ec.temp 1
$execute if data storage evercraft:forever_hold holds.$(hid).$(tab).s26{key:"$(hk)"} run data modify storage evercraft:forever_hold temp.tgt set value "s26"
$execute if data storage evercraft:forever_hold holds.$(hid).$(tab).s25{key:"$(hk)"} run scoreboard players set #fk ec.temp 1
$execute if data storage evercraft:forever_hold holds.$(hid).$(tab).s25{key:"$(hk)"} run data modify storage evercraft:forever_hold temp.tgt set value "s25"
$execute if data storage evercraft:forever_hold holds.$(hid).$(tab).s24{key:"$(hk)"} run scoreboard players set #fk ec.temp 1
$execute if data storage evercraft:forever_hold holds.$(hid).$(tab).s24{key:"$(hk)"} run data modify storage evercraft:forever_hold temp.tgt set value "s24"
$execute if data storage evercraft:forever_hold holds.$(hid).$(tab).s23{key:"$(hk)"} run scoreboard players set #fk ec.temp 1
$execute if data storage evercraft:forever_hold holds.$(hid).$(tab).s23{key:"$(hk)"} run data modify storage evercraft:forever_hold temp.tgt set value "s23"
$execute if data storage evercraft:forever_hold holds.$(hid).$(tab).s22{key:"$(hk)"} run scoreboard players set #fk ec.temp 1
$execute if data storage evercraft:forever_hold holds.$(hid).$(tab).s22{key:"$(hk)"} run data modify storage evercraft:forever_hold temp.tgt set value "s22"
$execute if data storage evercraft:forever_hold holds.$(hid).$(tab).s21{key:"$(hk)"} run scoreboard players set #fk ec.temp 1
$execute if data storage evercraft:forever_hold holds.$(hid).$(tab).s21{key:"$(hk)"} run data modify storage evercraft:forever_hold temp.tgt set value "s21"
$execute if data storage evercraft:forever_hold holds.$(hid).$(tab).s20{key:"$(hk)"} run scoreboard players set #fk ec.temp 1
$execute if data storage evercraft:forever_hold holds.$(hid).$(tab).s20{key:"$(hk)"} run data modify storage evercraft:forever_hold temp.tgt set value "s20"
$execute if data storage evercraft:forever_hold holds.$(hid).$(tab).s19{key:"$(hk)"} run scoreboard players set #fk ec.temp 1
$execute if data storage evercraft:forever_hold holds.$(hid).$(tab).s19{key:"$(hk)"} run data modify storage evercraft:forever_hold temp.tgt set value "s19"
$execute if data storage evercraft:forever_hold holds.$(hid).$(tab).s18{key:"$(hk)"} run scoreboard players set #fk ec.temp 1
$execute if data storage evercraft:forever_hold holds.$(hid).$(tab).s18{key:"$(hk)"} run data modify storage evercraft:forever_hold temp.tgt set value "s18"
$execute if data storage evercraft:forever_hold holds.$(hid).$(tab).s17{key:"$(hk)"} run scoreboard players set #fk ec.temp 1
$execute if data storage evercraft:forever_hold holds.$(hid).$(tab).s17{key:"$(hk)"} run data modify storage evercraft:forever_hold temp.tgt set value "s17"
$execute if data storage evercraft:forever_hold holds.$(hid).$(tab).s16{key:"$(hk)"} run scoreboard players set #fk ec.temp 1
$execute if data storage evercraft:forever_hold holds.$(hid).$(tab).s16{key:"$(hk)"} run data modify storage evercraft:forever_hold temp.tgt set value "s16"
$execute if data storage evercraft:forever_hold holds.$(hid).$(tab).s15{key:"$(hk)"} run scoreboard players set #fk ec.temp 1
$execute if data storage evercraft:forever_hold holds.$(hid).$(tab).s15{key:"$(hk)"} run data modify storage evercraft:forever_hold temp.tgt set value "s15"
$execute if data storage evercraft:forever_hold holds.$(hid).$(tab).s14{key:"$(hk)"} run scoreboard players set #fk ec.temp 1
$execute if data storage evercraft:forever_hold holds.$(hid).$(tab).s14{key:"$(hk)"} run data modify storage evercraft:forever_hold temp.tgt set value "s14"
$execute if data storage evercraft:forever_hold holds.$(hid).$(tab).s13{key:"$(hk)"} run scoreboard players set #fk ec.temp 1
$execute if data storage evercraft:forever_hold holds.$(hid).$(tab).s13{key:"$(hk)"} run data modify storage evercraft:forever_hold temp.tgt set value "s13"
$execute if data storage evercraft:forever_hold holds.$(hid).$(tab).s12{key:"$(hk)"} run scoreboard players set #fk ec.temp 1
$execute if data storage evercraft:forever_hold holds.$(hid).$(tab).s12{key:"$(hk)"} run data modify storage evercraft:forever_hold temp.tgt set value "s12"
$execute if data storage evercraft:forever_hold holds.$(hid).$(tab).s11{key:"$(hk)"} run scoreboard players set #fk ec.temp 1
$execute if data storage evercraft:forever_hold holds.$(hid).$(tab).s11{key:"$(hk)"} run data modify storage evercraft:forever_hold temp.tgt set value "s11"
$execute if data storage evercraft:forever_hold holds.$(hid).$(tab).s10{key:"$(hk)"} run scoreboard players set #fk ec.temp 1
$execute if data storage evercraft:forever_hold holds.$(hid).$(tab).s10{key:"$(hk)"} run data modify storage evercraft:forever_hold temp.tgt set value "s10"
$execute if data storage evercraft:forever_hold holds.$(hid).$(tab).s9{key:"$(hk)"} run scoreboard players set #fk ec.temp 1
$execute if data storage evercraft:forever_hold holds.$(hid).$(tab).s9{key:"$(hk)"} run data modify storage evercraft:forever_hold temp.tgt set value "s9"
$execute if data storage evercraft:forever_hold holds.$(hid).$(tab).s8{key:"$(hk)"} run scoreboard players set #fk ec.temp 1
$execute if data storage evercraft:forever_hold holds.$(hid).$(tab).s8{key:"$(hk)"} run data modify storage evercraft:forever_hold temp.tgt set value "s8"
$execute if data storage evercraft:forever_hold holds.$(hid).$(tab).s7{key:"$(hk)"} run scoreboard players set #fk ec.temp 1
$execute if data storage evercraft:forever_hold holds.$(hid).$(tab).s7{key:"$(hk)"} run data modify storage evercraft:forever_hold temp.tgt set value "s7"
$execute if data storage evercraft:forever_hold holds.$(hid).$(tab).s6{key:"$(hk)"} run scoreboard players set #fk ec.temp 1
$execute if data storage evercraft:forever_hold holds.$(hid).$(tab).s6{key:"$(hk)"} run data modify storage evercraft:forever_hold temp.tgt set value "s6"
$execute if data storage evercraft:forever_hold holds.$(hid).$(tab).s5{key:"$(hk)"} run scoreboard players set #fk ec.temp 1
$execute if data storage evercraft:forever_hold holds.$(hid).$(tab).s5{key:"$(hk)"} run data modify storage evercraft:forever_hold temp.tgt set value "s5"
$execute if data storage evercraft:forever_hold holds.$(hid).$(tab).s4{key:"$(hk)"} run scoreboard players set #fk ec.temp 1
$execute if data storage evercraft:forever_hold holds.$(hid).$(tab).s4{key:"$(hk)"} run data modify storage evercraft:forever_hold temp.tgt set value "s4"
$execute if data storage evercraft:forever_hold holds.$(hid).$(tab).s3{key:"$(hk)"} run scoreboard players set #fk ec.temp 1
$execute if data storage evercraft:forever_hold holds.$(hid).$(tab).s3{key:"$(hk)"} run data modify storage evercraft:forever_hold temp.tgt set value "s3"
$execute if data storage evercraft:forever_hold holds.$(hid).$(tab).s2{key:"$(hk)"} run scoreboard players set #fk ec.temp 1
$execute if data storage evercraft:forever_hold holds.$(hid).$(tab).s2{key:"$(hk)"} run data modify storage evercraft:forever_hold temp.tgt set value "s2"
$execute if data storage evercraft:forever_hold holds.$(hid).$(tab).s1{key:"$(hk)"} run scoreboard players set #fk ec.temp 1
$execute if data storage evercraft:forever_hold holds.$(hid).$(tab).s1{key:"$(hk)"} run data modify storage evercraft:forever_hold temp.tgt set value "s1"
$execute if data storage evercraft:forever_hold holds.$(hid).$(tab).s0{key:"$(hk)"} run scoreboard players set #fk ec.temp 1
$execute if data storage evercraft:forever_hold holds.$(hid).$(tab).s0{key:"$(hk)"} run data modify storage evercraft:forever_hold temp.tgt set value "s0"

# Empty scan (descending so the lowest empty index wins)
$execute unless data storage evercraft:forever_hold holds.$(hid).$(tab).s26.item run scoreboard players set #fe ec.temp 26
$execute unless data storage evercraft:forever_hold holds.$(hid).$(tab).s25.item run scoreboard players set #fe ec.temp 25
$execute unless data storage evercraft:forever_hold holds.$(hid).$(tab).s24.item run scoreboard players set #fe ec.temp 24
$execute unless data storage evercraft:forever_hold holds.$(hid).$(tab).s23.item run scoreboard players set #fe ec.temp 23
$execute unless data storage evercraft:forever_hold holds.$(hid).$(tab).s22.item run scoreboard players set #fe ec.temp 22
$execute unless data storage evercraft:forever_hold holds.$(hid).$(tab).s21.item run scoreboard players set #fe ec.temp 21
$execute unless data storage evercraft:forever_hold holds.$(hid).$(tab).s20.item run scoreboard players set #fe ec.temp 20
$execute unless data storage evercraft:forever_hold holds.$(hid).$(tab).s19.item run scoreboard players set #fe ec.temp 19
$execute unless data storage evercraft:forever_hold holds.$(hid).$(tab).s18.item run scoreboard players set #fe ec.temp 18
$execute unless data storage evercraft:forever_hold holds.$(hid).$(tab).s17.item run scoreboard players set #fe ec.temp 17
$execute unless data storage evercraft:forever_hold holds.$(hid).$(tab).s16.item run scoreboard players set #fe ec.temp 16
$execute unless data storage evercraft:forever_hold holds.$(hid).$(tab).s15.item run scoreboard players set #fe ec.temp 15
$execute unless data storage evercraft:forever_hold holds.$(hid).$(tab).s14.item run scoreboard players set #fe ec.temp 14
$execute unless data storage evercraft:forever_hold holds.$(hid).$(tab).s13.item run scoreboard players set #fe ec.temp 13
$execute unless data storage evercraft:forever_hold holds.$(hid).$(tab).s12.item run scoreboard players set #fe ec.temp 12
$execute unless data storage evercraft:forever_hold holds.$(hid).$(tab).s11.item run scoreboard players set #fe ec.temp 11
$execute unless data storage evercraft:forever_hold holds.$(hid).$(tab).s10.item run scoreboard players set #fe ec.temp 10
$execute unless data storage evercraft:forever_hold holds.$(hid).$(tab).s9.item run scoreboard players set #fe ec.temp 9
$execute unless data storage evercraft:forever_hold holds.$(hid).$(tab).s8.item run scoreboard players set #fe ec.temp 8
$execute unless data storage evercraft:forever_hold holds.$(hid).$(tab).s7.item run scoreboard players set #fe ec.temp 7
$execute unless data storage evercraft:forever_hold holds.$(hid).$(tab).s6.item run scoreboard players set #fe ec.temp 6
$execute unless data storage evercraft:forever_hold holds.$(hid).$(tab).s5.item run scoreboard players set #fe ec.temp 5
$execute unless data storage evercraft:forever_hold holds.$(hid).$(tab).s4.item run scoreboard players set #fe ec.temp 4
$execute unless data storage evercraft:forever_hold holds.$(hid).$(tab).s3.item run scoreboard players set #fe ec.temp 3
$execute unless data storage evercraft:forever_hold holds.$(hid).$(tab).s2.item run scoreboard players set #fe ec.temp 2
$execute unless data storage evercraft:forever_hold holds.$(hid).$(tab).s1.item run scoreboard players set #fe ec.temp 1
$execute unless data storage evercraft:forever_hold holds.$(hid).$(tab).s0.item run scoreboard players set #fe ec.temp 0
