# Forever Hold Menu — On Slot Click (macro). Args: local_slot (0-8).
$scoreboard players set #fhold_local ec.temp $(local_slot)
scoreboard players operation #fhold_abs ec.temp = @s ec.fhold_page
scoreboard players set #fhold_9 ec.temp 9
scoreboard players operation #fhold_abs ec.temp *= #fhold_9 ec.temp
scoreboard players operation #fhold_abs ec.temp += #fhold_local ec.temp
execute store result storage evercraft:forever_hold temp.hid int 1 run scoreboard players get @s ec.fhid
execute if score @s ec.fhold_tab matches 0 run data modify storage evercraft:forever_hold temp.tab set value "ore"
execute if score @s ec.fhold_tab matches 1 run data modify storage evercraft:forever_hold temp.tab set value "alch"
execute if score @s ec.fhold_tab matches 2 run data modify storage evercraft:forever_hold temp.tab set value "pantry"
function evercraft:forever_hold/menu/resolve_slot
