# Forever Hold Menu — Handle Click (macro). Args: hid, tab, slot.
$execute store success score #fhold_op ec.temp if data storage evercraft:forever_hold holds.$(hid).$(tab).$(slot).item
execute if score #fhold_op ec.temp matches 1 run function evercraft:forever_hold/menu/retrieve with storage evercraft:forever_hold temp
execute if score #fhold_op ec.temp matches 0 run function evercraft:forever_hold/menu/try_store with storage evercraft:forever_hold temp
function evercraft:forever_hold/menu/refresh
