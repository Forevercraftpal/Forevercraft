# Forever Hold Menu — Tick (runs every 2t for players with menu open)
# Called from menu_tick, run as each player with ec.fhold_in_menu tag

# Close if player walked too far from menu entities
execute unless entity @e[type=item_display,tag=ec.fhold_bg,distance=..5] run function evercraft:forever_hold/menu/close
execute unless entity @s[tag=ec.fhold_in_menu] run return 0

# Close if Forever Hold no longer anywhere on player (inventory, hotbar, or bundle)
execute unless items entity @s inventory.* *[custom_data~{forever_hold:true}] unless items entity @s hotbar.* *[custom_data~{forever_hold:true}] unless data entity @s Inventory[{components:{"minecraft:bundle_contents":[{components:{"minecraft:custom_data":{forever_hold:1b}}}]}}] run function evercraft:forever_hold/menu/close
execute unless entity @s[tag=ec.fhold_in_menu] run return 0

# Unified UI-click FX (Joseph 2026-06-05): play the gated cue ONCE if any ec.fhold_el element registered
# a click this tick, before check_clicks consumes it.
execute if entity @e[type=interaction,tag=ec.fhold_el,distance=..6,nbt={interaction:{}},limit=1] run function evercraft:fx/ui/click

# Check for clicks
function evercraft:forever_hold/menu/check_clicks
