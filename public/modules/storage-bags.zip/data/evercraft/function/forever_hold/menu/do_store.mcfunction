# Forever Hold Menu — Commit a stacking store (macro)
# Args: hid, tab, write_slot (+ storage temp.held_key, temp.qty_add) | #fk: 1=merge, 0=fresh.
$execute if score #fk ec.temp matches 0 run data modify storage evercraft:forever_hold holds.$(hid).$(tab).$(write_slot).item set from entity @s SelectedItem
$execute if score #fk ec.temp matches 0 run data modify storage evercraft:forever_hold holds.$(hid).$(tab).$(write_slot).item.count set value 1
$execute if score #fk ec.temp matches 0 run data modify storage evercraft:forever_hold holds.$(hid).$(tab).$(write_slot).name set from entity @s SelectedItem.components."minecraft:custom_name"
$execute if score #fk ec.temp matches 0 run data modify storage evercraft:forever_hold holds.$(hid).$(tab).$(write_slot).key set from storage evercraft:forever_hold temp.held_key
$execute if score #fk ec.temp matches 0 run data modify storage evercraft:forever_hold holds.$(hid).$(tab).$(write_slot).qty set from storage evercraft:forever_hold temp.qty_add
$execute if score #fk ec.temp matches 1 store result score #fhold_qty ec.temp run data get storage evercraft:forever_hold holds.$(hid).$(tab).$(write_slot).qty
execute store result score #fhold_add ec.temp run data get storage evercraft:forever_hold temp.qty_add
execute if score #fk ec.temp matches 1 run scoreboard players operation #fhold_qty ec.temp += #fhold_add ec.temp
$execute if score #fk ec.temp matches 1 store result storage evercraft:forever_hold holds.$(hid).$(tab).$(write_slot).qty int 1 run scoreboard players get #fhold_qty ec.temp
