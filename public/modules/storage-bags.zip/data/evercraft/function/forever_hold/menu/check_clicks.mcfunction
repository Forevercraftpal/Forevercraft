# Forever Hold Menu — Check Clicks
# Run as the player with the menu open. Hub view spawns tab buttons; storage view spawns
# slots + nav + back. Both share this dispatcher — non-spawned tags simply match nothing.

scoreboard players operation #gui_owner ec.temp = @s adv.gui_session

# Close button (both views)
execute as @e[type=interaction,tag=ec.fhold_close_btn,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction on target run function evercraft:forever_hold/menu/close
execute as @e[type=interaction,tag=ec.fhold_close_btn,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction
execute unless entity @s[tag=ec.fhold_in_menu] run return 0

# === HUB: tab buttons ===
execute as @e[type=interaction,tag=ec.fhold_tab0,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction on target run function evercraft:forever_hold/menu/click_tab {t:0}
execute as @e[type=interaction,tag=ec.fhold_tab0,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=ec.fhold_tab1,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction on target run function evercraft:forever_hold/menu/click_tab {t:1}
execute as @e[type=interaction,tag=ec.fhold_tab1,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=ec.fhold_tab2,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction on target run function evercraft:forever_hold/menu/click_tab {t:2}
execute as @e[type=interaction,tag=ec.fhold_tab2,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction

# === STORAGE: back to hub ===
execute as @e[type=interaction,tag=ec.fhold_back_btn,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction on target run function evercraft:forever_hold/menu/back
execute as @e[type=interaction,tag=ec.fhold_back_btn,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction

# === STORAGE: page nav ===
execute as @e[type=interaction,tag=ec.fhold_prev_btn,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction on target run function evercraft:forever_hold/menu/prev_page
execute as @e[type=interaction,tag=ec.fhold_prev_btn,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=ec.fhold_next_btn,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction on target run function evercraft:forever_hold/menu/next_page
execute as @e[type=interaction,tag=ec.fhold_next_btn,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction

# === STORAGE: slot clicks ===
execute as @e[type=interaction,tag=ec.fhold_s0,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction on target run function evercraft:forever_hold/menu/on_slot_click {local_slot:0}
execute as @e[type=interaction,tag=ec.fhold_s0,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=ec.fhold_s1,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction on target run function evercraft:forever_hold/menu/on_slot_click {local_slot:1}
execute as @e[type=interaction,tag=ec.fhold_s1,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=ec.fhold_s2,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction on target run function evercraft:forever_hold/menu/on_slot_click {local_slot:2}
execute as @e[type=interaction,tag=ec.fhold_s2,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=ec.fhold_s3,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction on target run function evercraft:forever_hold/menu/on_slot_click {local_slot:3}
execute as @e[type=interaction,tag=ec.fhold_s3,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=ec.fhold_s4,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction on target run function evercraft:forever_hold/menu/on_slot_click {local_slot:4}
execute as @e[type=interaction,tag=ec.fhold_s4,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=ec.fhold_s5,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction on target run function evercraft:forever_hold/menu/on_slot_click {local_slot:5}
execute as @e[type=interaction,tag=ec.fhold_s5,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=ec.fhold_s6,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction on target run function evercraft:forever_hold/menu/on_slot_click {local_slot:6}
execute as @e[type=interaction,tag=ec.fhold_s6,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=ec.fhold_s7,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction on target run function evercraft:forever_hold/menu/on_slot_click {local_slot:7}
execute as @e[type=interaction,tag=ec.fhold_s7,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=ec.fhold_s8,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction on target run function evercraft:forever_hold/menu/on_slot_click {local_slot:8}
execute as @e[type=interaction,tag=ec.fhold_s8,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction

# ===== INSPECT (left-click = what does this do?) =====
execute as @e[type=interaction,tag=ec.fhold_close_btn,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Close",b:"Closes the Forever Hold."}
execute as @e[type=interaction,tag=ec.fhold_close_btn,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=ec.fhold_back_btn,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Back to Tabs",b:"Returns to the satchel picker."}
execute as @e[type=interaction,tag=ec.fhold_back_btn,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=ec.fhold_tab0,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Ore Bag",b:"Opens your folded-in Ore Bag store."}
execute as @e[type=interaction,tag=ec.fhold_tab0,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=ec.fhold_tab1,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Ingredient Binder",b:"Opens your folded-in Ingredient Binder."}
execute as @e[type=interaction,tag=ec.fhold_tab1,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=ec.fhold_tab2,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Pantry",b:"Opens your folded-in Pantry."}
execute as @e[type=interaction,tag=ec.fhold_tab2,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=ec.fhold_prev_btn,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Previous Page",b:"Flips to the previous page."}
execute as @e[type=interaction,tag=ec.fhold_prev_btn,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=ec.fhold_next_btn,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Next Page",b:"Flips to the next page."}
execute as @e[type=interaction,tag=ec.fhold_next_btn,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack run data remove entity @s attack
