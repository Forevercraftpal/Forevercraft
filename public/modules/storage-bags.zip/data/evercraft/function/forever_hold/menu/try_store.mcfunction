# Forever Hold Menu — Try Store (macro). Args: hid, tab, slot.
# Per-tab gate keeps each tab's source-bag identity (ore=forge, alch=alchemy, pantry=cooking).
scoreboard players set #fhold_valid ec.temp 0
execute if score @s ec.fhold_tab matches 0 if data entity @s SelectedItem.components."minecraft:custom_data".forge_mat run scoreboard players set #fhold_valid ec.temp 1
execute if score @s ec.fhold_tab matches 1 if data entity @s SelectedItem.components."minecraft:custom_data".alch_mat run scoreboard players set #fhold_valid ec.temp 1
execute if score @s ec.fhold_tab matches 2 if data entity @s SelectedItem.components."minecraft:custom_data".ingredient_id run scoreboard players set #fhold_valid ec.temp 1
execute if score @s ec.fhold_tab matches 2 if items entity @s weapon.mainhand *[custom_data~{cooking_utensil:true}] run scoreboard players set #fhold_valid ec.temp 1
execute if score @s ec.fhold_tab matches 2 if items entity @s weapon.mainhand *[custom_data~{ec_meal:true}] run scoreboard players set #fhold_valid ec.temp 1

data modify storage evercraft:notify stage.c set value [{text:"That tab only takes its own kind of material!",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute if score #fhold_valid ec.temp matches 0 run function evercraft:util/notify/emit_keyed {key:11}
execute if score #fhold_valid ec.temp matches 0 run return 0

# Held stack count + stacking key (sub = forge_mat | alch_mat | ingredient_id)
execute store result score #fhold_count ec.temp run data get entity @s SelectedItem.count
data modify storage evercraft:forever_hold temp.kb.id set from entity @s SelectedItem.id
data modify storage evercraft:forever_hold temp.kb.sub set value ""
execute if data entity @s SelectedItem.components."minecraft:custom_data".forge_mat run data modify storage evercraft:forever_hold temp.kb.sub set from entity @s SelectedItem.components."minecraft:custom_data".forge_mat
execute if data entity @s SelectedItem.components."minecraft:custom_data".alch_mat run data modify storage evercraft:forever_hold temp.kb.sub set from entity @s SelectedItem.components."minecraft:custom_data".alch_mat
execute if data entity @s SelectedItem.components."minecraft:custom_data".ingredient_id run data modify storage evercraft:forever_hold temp.kb.sub set from entity @s SelectedItem.components."minecraft:custom_data".ingredient_id
function evercraft:forever_hold/menu/mk_key with storage evercraft:forever_hold temp.kb

# Find a same-key slot in this tab, else use the clicked empty slot
data modify storage evercraft:forever_hold temp.fa.hid set from storage evercraft:forever_hold temp.hid
data modify storage evercraft:forever_hold temp.fa.tab set from storage evercraft:forever_hold temp.tab
data modify storage evercraft:forever_hold temp.fa.hk set from storage evercraft:forever_hold temp.held_key
function evercraft:forever_hold/menu/find_slot with storage evercraft:forever_hold temp.fa
execute if score #fk ec.temp matches 1 run data modify storage evercraft:forever_hold temp.write_slot set from storage evercraft:forever_hold temp.tgt
$execute if score #fk ec.temp matches 0 run data modify storage evercraft:forever_hold temp.write_slot set value "$(slot)"
execute store result storage evercraft:forever_hold temp.qty_add int 1 run scoreboard players get #fhold_count ec.temp

# Commit + remove the whole held stack
function evercraft:forever_hold/menu/do_store with storage evercraft:forever_hold temp
item replace entity @s weapon.mainhand with air

scoreboard players add @s ec.fhold_stored 1
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:item.bundle.insert master @s ~ ~ ~ 0.8 1.0
data modify storage evercraft:notify stage.c set value [{text:"Item stored!",color:"green"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit_keyed {key:10}
