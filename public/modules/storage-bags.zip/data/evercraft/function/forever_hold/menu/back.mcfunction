# Forever Hold Menu — Back to the hub (tab picker)
function evercraft:forever_hold/menu/open
