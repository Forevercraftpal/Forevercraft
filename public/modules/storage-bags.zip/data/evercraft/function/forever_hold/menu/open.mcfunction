# Forever Hold Menu — Open HUB (first page: pick a satchel tab)
# Run as the player at their position. The three tabs each open a preserved bag store.

# One-menu-at-a-time + close anchor
execute if entity @s[tag=ec.menu_active] run function evercraft:menu_core/force_close
tag @s add ec.menu_active
execute store result score @s ec.menu_open_y run data get entity @s Pos[1] 100

# Clear any prior elements
execute at @s run kill @e[type=text_display,tag=ec.fhold_el,distance=..5]
execute at @s run kill @e[type=interaction,tag=ec.fhold_el,distance=..5]
execute at @s run kill @e[type=item_display,tag=ec.fhold_el,distance=..5]

# Tag player as in menu; -1 tab = hub view
tag @s add ec.fhold_in_menu
scoreboard players set @s ec.fhold_tab -1
scoreboard players set @s ec.fhold_page 0

# Background panel
execute at @s rotated ~ 0 positioned ^ ^2 ^1.8 run summon item_display ~ ~ ~ { Tags:["ec.fhold_el","ec.fhold_bg"], billboard:"center", item:{id:"gray_stained_glass_pane",count:1}, item_display:"fixed", transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,-0.02f],scale:[3.0f,3.0f,0.01f]} }

# Title
function evercraft:util/gui/owner_name
execute at @s rotated ~ 0 positioned ^ ^3.05 ^1.78 run function evercraft:forever_hold/menu/open_nm with storage evercraft:scorebake args
execute at @s rotated ~ 0 positioned ^ ^2.87 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f, Tags:["ec.fhold_el","ec.fhold_title"], billboard:"center", text:[{text:"❖ ",color:"#9B7BC0"},{text:"Forever Hold",color:"#B19CD9",bold:true},{text:" ❖",color:"#9B7BC0"}], background:1, shadow:1b, transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.54f,0.54f,0.54f]} }
execute at @s rotated ~ 0 positioned ^ ^2.62 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f, Tags:["ec.fhold_el","ec.fhold_hint"], billboard:"center", text:[{text:"Choose a satchel to open",color:"gray",italic:true}], background:0, shadow:1b, transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.338f,0.338f,0.338f]} }

# === TAB 0: Ore Bag ===
execute at @s rotated ~ 0 positioned ^ ^2.2 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f, Tags:["ec.fhold_el","ec.fhold_tab0_txt"], billboard:"center", text:[{text:"[ ",color:"dark_gray"},{text:"⚒ Ore Bag",color:"#C0C0C0",bold:true},{text:" ]",color:"dark_gray"}], background:1, shadow:1b, transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.473f,0.473f,0.473f]} }
execute at @s rotated ~ 0 positioned ^-0.4 ^2.11 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.fhold_el","ec.fhold_tab0"], width:0.2f,height:0.18f, response:1b }
execute at @s rotated ~ 0 positioned ^-0.2 ^2.11 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.fhold_el","ec.fhold_tab0"], width:0.2f,height:0.18f, response:1b }
execute at @s rotated ~ 0 positioned ^0 ^2.11 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.fhold_el","ec.fhold_tab0"], width:0.2f,height:0.18f, response:1b }
execute at @s rotated ~ 0 positioned ^0.2 ^2.11 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.fhold_el","ec.fhold_tab0"], width:0.2f,height:0.18f, response:1b }
execute at @s rotated ~ 0 positioned ^0.4 ^2.11 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.fhold_el","ec.fhold_tab0"], width:0.2f,height:0.18f, response:1b }

# === TAB 1: Ingredient Binder ===
execute at @s rotated ~ 0 positioned ^ ^1.78 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f, Tags:["ec.fhold_el","ec.fhold_tab1_txt"], billboard:"center", text:[{text:"[ ",color:"dark_gray"},{text:"⚗ Ingredient Binder",color:"#9B59B6",bold:true},{text:" ]",color:"dark_gray"}], background:1, shadow:1b, transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.473f,0.473f,0.473f]} }
execute at @s rotated ~ 0 positioned ^-0.4 ^1.69 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.fhold_el","ec.fhold_tab1"], width:0.2f,height:0.18f, response:1b }
execute at @s rotated ~ 0 positioned ^-0.2 ^1.69 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.fhold_el","ec.fhold_tab1"], width:0.2f,height:0.18f, response:1b }
execute at @s rotated ~ 0 positioned ^0 ^1.69 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.fhold_el","ec.fhold_tab1"], width:0.2f,height:0.18f, response:1b }
execute at @s rotated ~ 0 positioned ^0.2 ^1.69 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.fhold_el","ec.fhold_tab1"], width:0.2f,height:0.18f, response:1b }
execute at @s rotated ~ 0 positioned ^0.4 ^1.69 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.fhold_el","ec.fhold_tab1"], width:0.2f,height:0.18f, response:1b }

# === TAB 2: Pantry ===
execute at @s rotated ~ 0 positioned ^ ^1.36 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f, Tags:["ec.fhold_el","ec.fhold_tab2_txt"], billboard:"center", text:[{text:"[ ",color:"dark_gray"},{text:"✦ Pantry",color:"gold",bold:true},{text:" ]",color:"dark_gray"}], background:1, shadow:1b, transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.473f,0.473f,0.473f]} }
execute at @s rotated ~ 0 positioned ^-0.4 ^1.27 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.fhold_el","ec.fhold_tab2"], width:0.2f,height:0.18f, response:1b }
execute at @s rotated ~ 0 positioned ^-0.2 ^1.27 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.fhold_el","ec.fhold_tab2"], width:0.2f,height:0.18f, response:1b }
execute at @s rotated ~ 0 positioned ^0 ^1.27 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.fhold_el","ec.fhold_tab2"], width:0.2f,height:0.18f, response:1b }
execute at @s rotated ~ 0 positioned ^0.2 ^1.27 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.fhold_el","ec.fhold_tab2"], width:0.2f,height:0.18f, response:1b }
execute at @s rotated ~ 0 positioned ^0.4 ^1.27 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.fhold_el","ec.fhold_tab2"], width:0.2f,height:0.18f, response:1b }

# === CLOSE ===
execute at @s rotated ~ 0 positioned ^ ^0.85 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f, Tags:["ec.fhold_el","ec.fhold_close_txt"], billboard:"center", text:[{text:"[ ",color:"dark_gray"},{text:"Close",color:"gray",bold:true},{text:" ]",color:"dark_gray"}], background:1, shadow:1b, transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.405f,0.405f,0.405f]} }
execute at @s rotated ~ 0 positioned ^-0.19 ^0.76 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.fhold_el","ec.fhold_close_btn"], width:0.12f,height:0.12f, response:1b }
execute at @s rotated ~ 0 positioned ^-0.095 ^0.76 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.fhold_el","ec.fhold_close_btn"], width:0.12f,height:0.12f, response:1b }
execute at @s rotated ~ 0 positioned ^0 ^0.76 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.fhold_el","ec.fhold_close_btn"], width:0.12f,height:0.12f, response:1b }
execute at @s rotated ~ 0 positioned ^0.095 ^0.76 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.fhold_el","ec.fhold_close_btn"], width:0.12f,height:0.12f, response:1b }
execute at @s rotated ~ 0 positioned ^0.19 ^0.76 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.fhold_el","ec.fhold_close_btn"], width:0.12f,height:0.12f, response:1b }

# Start menu tick
schedule function evercraft:forever_hold/menu_tick 2t replace

# Session isolation
scoreboard players add #gui_session ec.var 1
scoreboard players operation @s adv.gui_session = #gui_session ec.var
scoreboard players operation #gui_stamp ec.temp = @s adv.gui_session
execute as @e[type=text_display,tag=ec.fhold_el,distance=..5] unless score @s adv.gui_session matches 1.. run scoreboard players operation @s adv.gui_session = #gui_stamp ec.temp
execute as @e[type=item_display,tag=ec.fhold_el,distance=..5] unless score @s adv.gui_session matches 1.. run scoreboard players operation @s adv.gui_session = #gui_stamp ec.temp
execute as @e[type=interaction,tag=ec.fhold_el,distance=..5] unless score @s adv.gui_session matches 1.. run scoreboard players operation @s adv.gui_session = #gui_stamp ec.temp

execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.barrel.open master @s ~ ~ ~ 0.5 1.2
