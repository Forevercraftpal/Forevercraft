# Forever Hold Menu — Open a tab (macro). Arg: t (0 Ore Bag / 1 Ingredient Binder / 2 Pantry)
# Sets the active tab, then renders that bag's preserved storage view.
$scoreboard players set @s ec.fhold_tab $(t)
function evercraft:forever_hold/menu/open_tab
