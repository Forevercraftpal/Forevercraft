# Forever Hold Menu — Retrieve from a tab slot (macro). Args: hid, tab, slot.
scoreboard players set #fhold_q ec.temp 1
$execute store result score #fhold_q ec.temp run data get storage evercraft:forever_hold holds.$(hid).$(tab).$(slot).qty
scoreboard players operation #fhold_give ec.temp = #fhold_q ec.temp
execute if score #fhold_give ec.temp matches 65.. run scoreboard players set #fhold_give ec.temp 64
execute at @s run summon item ~ ~1 ~ {Tags:["ec.fhold_tmp"],PickupDelay:0,Item:{id:"minecraft:stone",count:1}}
$data modify entity @e[type=item,tag=ec.fhold_tmp,limit=1] Item set from storage evercraft:forever_hold holds.$(hid).$(tab).$(slot).item
execute store result entity @e[type=item,tag=ec.fhold_tmp,limit=1] Item.count int 1 run scoreboard players get #fhold_give ec.temp
tp @e[type=item,tag=ec.fhold_tmp,limit=1] @s
tag @e[type=item,tag=ec.fhold_tmp,limit=1] remove ec.fhold_tmp
scoreboard players operation #fhold_q ec.temp -= #fhold_give ec.temp
$execute if score #fhold_q ec.temp matches ..0 run data modify storage evercraft:forever_hold holds.$(hid).$(tab).$(slot) set value {}
$execute if score #fhold_q ec.temp matches 1.. store result storage evercraft:forever_hold holds.$(hid).$(tab).$(slot).qty int 1 run scoreboard players get #fhold_q ec.temp
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:item.bundle.remove_one master @s ~ ~ ~ 0.8 1.0
data modify storage evercraft:notify stage.c set value [{text:"Item retrieved!",color:"yellow"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit_keyed {key:12}
