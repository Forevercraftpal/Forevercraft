# Forever Hold Menu — Refresh (storage view)
execute store result storage evercraft:forever_hold temp.pid int 1 run scoreboard players get @s ec.fhid
data modify storage evercraft:forever_hold temp.hid set from storage evercraft:forever_hold temp.pid
execute if score @s ec.fhold_tab matches 0 run data modify storage evercraft:forever_hold temp.tab set value "ore"
execute if score @s ec.fhold_tab matches 1 run data modify storage evercraft:forever_hold temp.tab set value "alch"
execute if score @s ec.fhold_tab matches 2 run data modify storage evercraft:forever_hold temp.tab set value "pantry"

# Page indicator
execute if score @s ec.fhold_page matches 0 at @s as @e[type=text_display,tag=ec.fhold_page_txt,distance=..5] run data modify entity @s text set value {text:"Page 1/3",color:"white"}
execute if score @s ec.fhold_page matches 1 at @s as @e[type=text_display,tag=ec.fhold_page_txt,distance=..5] run data modify entity @s text set value {text:"Page 2/3",color:"white"}
execute if score @s ec.fhold_page matches 2 at @s as @e[type=text_display,tag=ec.fhold_page_txt,distance=..5] run data modify entity @s text set value {text:"Page 3/3",color:"white"}

# Tab title (reflects the open bag)
execute if score @s ec.fhold_tab matches 0 at @s as @e[type=text_display,tag=ec.fhold_title,distance=..5] run data modify entity @s text set value [{text:"⚒ ",color:"dark_gray"},{text:"Ore Bag",color:"#C0C0C0",bold:true}]
execute if score @s ec.fhold_tab matches 1 at @s as @e[type=text_display,tag=ec.fhold_title,distance=..5] run data modify entity @s text set value [{text:"⚗ ",color:"#9B59B6"},{text:"Ingredient Binder",color:"#9B59B6",bold:true}]
execute if score @s ec.fhold_tab matches 2 at @s as @e[type=text_display,tag=ec.fhold_title,distance=..5] run data modify entity @s text set value [{text:"✦ ",color:"gold"},{text:"Pantry",color:"gold",bold:true}]

execute if score @s ec.fhold_page matches 0 run data modify storage evercraft:forever_hold temp.rargs set value {s0:"s0",s1:"s1",s2:"s2",s3:"s3",s4:"s4",s5:"s5",s6:"s6",s7:"s7",s8:"s8"}
execute if score @s ec.fhold_page matches 1 run data modify storage evercraft:forever_hold temp.rargs set value {s0:"s9",s1:"s10",s2:"s11",s3:"s12",s4:"s13",s5:"s14",s6:"s15",s7:"s16",s8:"s17"}
execute if score @s ec.fhold_page matches 2 run data modify storage evercraft:forever_hold temp.rargs set value {s0:"s18",s1:"s19",s2:"s20",s3:"s21",s4:"s22",s5:"s23",s6:"s24",s7:"s25",s8:"s26"}

data modify storage evercraft:forever_hold temp.rargs.hid set from storage evercraft:forever_hold temp.hid
data modify storage evercraft:forever_hold temp.rargs.tab set from storage evercraft:forever_hold temp.tab
function evercraft:forever_hold/menu/refresh_slots with storage evercraft:forever_hold temp.rargs
