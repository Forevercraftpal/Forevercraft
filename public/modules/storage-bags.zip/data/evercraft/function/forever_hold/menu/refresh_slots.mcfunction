# Forever Hold Menu — Refresh Slots (macro). Args: hid, tab, s0-s8.

# Slot position 0
$execute if data storage evercraft:forever_hold holds.$(hid).$(tab).$(s0).item run data modify storage evercraft:forever_hold temp._r0 set value [{text:"",color:"#C0C0C0",extra:[{storage:"evercraft:forever_hold",nbt:"holds.$(hid).$(tab).$(s0).name",interpret:true}]},{text:" \u00d7",color:"dark_gray"},{storage:"evercraft:forever_hold",nbt:"holds.$(hid).$(tab).$(s0).qty",color:"white"},{text:" \u2756",color:"#B19CD9"}]
$execute if data storage evercraft:forever_hold holds.$(hid).$(tab).$(s0).item at @a[tag=ec.fhold_in_menu] as @e[type=text_display,tag=ec.fhold_s0_txt,distance=..5] run data modify entity @s text set from storage evercraft:forever_hold temp._r0
$execute unless data storage evercraft:forever_hold holds.$(hid).$(tab).$(s0).item at @a[tag=ec.fhold_in_menu] as @e[type=text_display,tag=ec.fhold_s0_txt,distance=..5] run data modify entity @s text set value [{text:"[Empty]",color:"dark_gray"}]

# Slot position 1
$execute if data storage evercraft:forever_hold holds.$(hid).$(tab).$(s1).item run data modify storage evercraft:forever_hold temp._r1 set value [{text:"",color:"#C0C0C0",extra:[{storage:"evercraft:forever_hold",nbt:"holds.$(hid).$(tab).$(s1).name",interpret:true}]},{text:" \u00d7",color:"dark_gray"},{storage:"evercraft:forever_hold",nbt:"holds.$(hid).$(tab).$(s1).qty",color:"white"},{text:" \u2756",color:"#B19CD9"}]
$execute if data storage evercraft:forever_hold holds.$(hid).$(tab).$(s1).item at @a[tag=ec.fhold_in_menu] as @e[type=text_display,tag=ec.fhold_s1_txt,distance=..5] run data modify entity @s text set from storage evercraft:forever_hold temp._r1
$execute unless data storage evercraft:forever_hold holds.$(hid).$(tab).$(s1).item at @a[tag=ec.fhold_in_menu] as @e[type=text_display,tag=ec.fhold_s1_txt,distance=..5] run data modify entity @s text set value [{text:"[Empty]",color:"dark_gray"}]

# Slot position 2
$execute if data storage evercraft:forever_hold holds.$(hid).$(tab).$(s2).item run data modify storage evercraft:forever_hold temp._r2 set value [{text:"",color:"#C0C0C0",extra:[{storage:"evercraft:forever_hold",nbt:"holds.$(hid).$(tab).$(s2).name",interpret:true}]},{text:" \u00d7",color:"dark_gray"},{storage:"evercraft:forever_hold",nbt:"holds.$(hid).$(tab).$(s2).qty",color:"white"},{text:" \u2756",color:"#B19CD9"}]
$execute if data storage evercraft:forever_hold holds.$(hid).$(tab).$(s2).item at @a[tag=ec.fhold_in_menu] as @e[type=text_display,tag=ec.fhold_s2_txt,distance=..5] run data modify entity @s text set from storage evercraft:forever_hold temp._r2
$execute unless data storage evercraft:forever_hold holds.$(hid).$(tab).$(s2).item at @a[tag=ec.fhold_in_menu] as @e[type=text_display,tag=ec.fhold_s2_txt,distance=..5] run data modify entity @s text set value [{text:"[Empty]",color:"dark_gray"}]

# Slot position 3
$execute if data storage evercraft:forever_hold holds.$(hid).$(tab).$(s3).item run data modify storage evercraft:forever_hold temp._r3 set value [{text:"",color:"#C0C0C0",extra:[{storage:"evercraft:forever_hold",nbt:"holds.$(hid).$(tab).$(s3).name",interpret:true}]},{text:" \u00d7",color:"dark_gray"},{storage:"evercraft:forever_hold",nbt:"holds.$(hid).$(tab).$(s3).qty",color:"white"},{text:" \u2756",color:"#B19CD9"}]
$execute if data storage evercraft:forever_hold holds.$(hid).$(tab).$(s3).item at @a[tag=ec.fhold_in_menu] as @e[type=text_display,tag=ec.fhold_s3_txt,distance=..5] run data modify entity @s text set from storage evercraft:forever_hold temp._r3
$execute unless data storage evercraft:forever_hold holds.$(hid).$(tab).$(s3).item at @a[tag=ec.fhold_in_menu] as @e[type=text_display,tag=ec.fhold_s3_txt,distance=..5] run data modify entity @s text set value [{text:"[Empty]",color:"dark_gray"}]

# Slot position 4
$execute if data storage evercraft:forever_hold holds.$(hid).$(tab).$(s4).item run data modify storage evercraft:forever_hold temp._r4 set value [{text:"",color:"#C0C0C0",extra:[{storage:"evercraft:forever_hold",nbt:"holds.$(hid).$(tab).$(s4).name",interpret:true}]},{text:" \u00d7",color:"dark_gray"},{storage:"evercraft:forever_hold",nbt:"holds.$(hid).$(tab).$(s4).qty",color:"white"},{text:" \u2756",color:"#B19CD9"}]
$execute if data storage evercraft:forever_hold holds.$(hid).$(tab).$(s4).item at @a[tag=ec.fhold_in_menu] as @e[type=text_display,tag=ec.fhold_s4_txt,distance=..5] run data modify entity @s text set from storage evercraft:forever_hold temp._r4
$execute unless data storage evercraft:forever_hold holds.$(hid).$(tab).$(s4).item at @a[tag=ec.fhold_in_menu] as @e[type=text_display,tag=ec.fhold_s4_txt,distance=..5] run data modify entity @s text set value [{text:"[Empty]",color:"dark_gray"}]

# Slot position 5
$execute if data storage evercraft:forever_hold holds.$(hid).$(tab).$(s5).item run data modify storage evercraft:forever_hold temp._r5 set value [{text:"",color:"#C0C0C0",extra:[{storage:"evercraft:forever_hold",nbt:"holds.$(hid).$(tab).$(s5).name",interpret:true}]},{text:" \u00d7",color:"dark_gray"},{storage:"evercraft:forever_hold",nbt:"holds.$(hid).$(tab).$(s5).qty",color:"white"},{text:" \u2756",color:"#B19CD9"}]
$execute if data storage evercraft:forever_hold holds.$(hid).$(tab).$(s5).item at @a[tag=ec.fhold_in_menu] as @e[type=text_display,tag=ec.fhold_s5_txt,distance=..5] run data modify entity @s text set from storage evercraft:forever_hold temp._r5
$execute unless data storage evercraft:forever_hold holds.$(hid).$(tab).$(s5).item at @a[tag=ec.fhold_in_menu] as @e[type=text_display,tag=ec.fhold_s5_txt,distance=..5] run data modify entity @s text set value [{text:"[Empty]",color:"dark_gray"}]

# Slot position 6
$execute if data storage evercraft:forever_hold holds.$(hid).$(tab).$(s6).item run data modify storage evercraft:forever_hold temp._r6 set value [{text:"",color:"#C0C0C0",extra:[{storage:"evercraft:forever_hold",nbt:"holds.$(hid).$(tab).$(s6).name",interpret:true}]},{text:" \u00d7",color:"dark_gray"},{storage:"evercraft:forever_hold",nbt:"holds.$(hid).$(tab).$(s6).qty",color:"white"},{text:" \u2756",color:"#B19CD9"}]
$execute if data storage evercraft:forever_hold holds.$(hid).$(tab).$(s6).item at @a[tag=ec.fhold_in_menu] as @e[type=text_display,tag=ec.fhold_s6_txt,distance=..5] run data modify entity @s text set from storage evercraft:forever_hold temp._r6
$execute unless data storage evercraft:forever_hold holds.$(hid).$(tab).$(s6).item at @a[tag=ec.fhold_in_menu] as @e[type=text_display,tag=ec.fhold_s6_txt,distance=..5] run data modify entity @s text set value [{text:"[Empty]",color:"dark_gray"}]

# Slot position 7
$execute if data storage evercraft:forever_hold holds.$(hid).$(tab).$(s7).item run data modify storage evercraft:forever_hold temp._r7 set value [{text:"",color:"#C0C0C0",extra:[{storage:"evercraft:forever_hold",nbt:"holds.$(hid).$(tab).$(s7).name",interpret:true}]},{text:" \u00d7",color:"dark_gray"},{storage:"evercraft:forever_hold",nbt:"holds.$(hid).$(tab).$(s7).qty",color:"white"},{text:" \u2756",color:"#B19CD9"}]
$execute if data storage evercraft:forever_hold holds.$(hid).$(tab).$(s7).item at @a[tag=ec.fhold_in_menu] as @e[type=text_display,tag=ec.fhold_s7_txt,distance=..5] run data modify entity @s text set from storage evercraft:forever_hold temp._r7
$execute unless data storage evercraft:forever_hold holds.$(hid).$(tab).$(s7).item at @a[tag=ec.fhold_in_menu] as @e[type=text_display,tag=ec.fhold_s7_txt,distance=..5] run data modify entity @s text set value [{text:"[Empty]",color:"dark_gray"}]

# Slot position 8
$execute if data storage evercraft:forever_hold holds.$(hid).$(tab).$(s8).item run data modify storage evercraft:forever_hold temp._r8 set value [{text:"",color:"#C0C0C0",extra:[{storage:"evercraft:forever_hold",nbt:"holds.$(hid).$(tab).$(s8).name",interpret:true}]},{text:" \u00d7",color:"dark_gray"},{storage:"evercraft:forever_hold",nbt:"holds.$(hid).$(tab).$(s8).qty",color:"white"},{text:" \u2756",color:"#B19CD9"}]
$execute if data storage evercraft:forever_hold holds.$(hid).$(tab).$(s8).item at @a[tag=ec.fhold_in_menu] as @e[type=text_display,tag=ec.fhold_s8_txt,distance=..5] run data modify entity @s text set from storage evercraft:forever_hold temp._r8
$execute unless data storage evercraft:forever_hold holds.$(hid).$(tab).$(s8).item at @a[tag=ec.fhold_in_menu] as @e[type=text_display,tag=ec.fhold_s8_txt,distance=..5] run data modify entity @s text set value [{text:"[Empty]",color:"dark_gray"}]
