# Forever Hold — Fold one bag's whole store into a tab, then clear the source (macro)
# Args: hid, tab (ore/alch/pantry), sns (source namespace), sid (source stamped id)
$data modify storage evercraft:forever_hold holds.$(hid).$(tab) set from storage $(sns) bags.$(sid)
$data modify storage $(sns) bags.$(sid) set value {}
