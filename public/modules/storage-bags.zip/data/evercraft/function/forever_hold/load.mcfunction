# ============================================================
# FOREVER HOLD SYSTEM — Load
# ============================================================
# A hub that fuses the Ore Bag, Ingredient Binder, and Pantry: opening it shows three
# preserved tabs (ore/alch/pantry), each that bag's own 27-slot / 3-page store with
# infinite per-slot quantity. Assembled at the Transmutation Stand (button appears only
# when the player carries all three bags). holds.<hid>.{ore,alch,pantry}.

# Scoreboards
scoreboard objectives add ec.fhold_id dummy "Forever Hold Player ID"
scoreboard objectives add ec.has_fhold dummy "Has Forever Hold"
scoreboard objectives add ec.fhold_page dummy "Forever Hold GUI Page"
scoreboard objectives add ec.fhid dummy "Active Forever Hold ID"
scoreboard objectives add ec.fhold_tab dummy "Forever Hold Active Tab (-1 hub/0 ore/1 alch/2 pantry)"
# Assemble trigger — set by the Transmutation Stand's clickable [Assemble] button (combine-codices pattern)
scoreboard objectives add ec.fhold_assemble trigger "Forever Hold Assemble"
scoreboard players enable @a ec.fhold_assemble

# Global Forever Hold ID counter
execute unless score #next_fhold_id ec.var matches 1.. run scoreboard players set #next_fhold_id ec.var 0
