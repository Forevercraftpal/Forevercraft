# Forever Hold — Process the [Assemble] trigger (run as @a with ec.fhold_assemble>=1)
# Consume the trigger, re-enable it, then run the (defensively re-checked) assembly.
execute unless score @s ec.fhold_assemble matches 1.. run return 0
scoreboard players set @s ec.fhold_assemble 0
scoreboard players enable @s ec.fhold_assemble
function evercraft:forever_hold/assemble
