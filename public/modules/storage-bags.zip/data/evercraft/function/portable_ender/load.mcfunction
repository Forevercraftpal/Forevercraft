# === PORTABLE-ENDER HELPER — LOAD (PLAN-chest-nodes §14.8, shared by P4b accessory #4 + P5 dungeon) ===
# The real ender-chest UI CANNOT be opened by command (§6 VERDICT). Mechanism: place a TEMPORARY real
# minecraft:ender_chest at a per-player scratch spot (the vanilla block natively opens the player's
# actual ender inventory on right-click) -> auto-remove on walk-away / timeout (a per-player owner
# stamp + a watchdog tick, R2/R4 grief guard). This helper is built HERE in P2a (§14.8) so P4b (the
# pocket_ender_anchor accessory) AND P5 (dungeon ender-nodes shift-RC) both call ONE shared entry.
#
# Declares the scratch coords + the watchdog cadence. The placed block + its owner marker are tracked
# so cleanup never removes a player's REAL placed ender_chest (we only remove ec.pe_temp-tagged blocks
# at the exact stored scratch coords). Registered from evercraft:init (after chest_nodes/load).

# Per-player scratch-spot coords for the temp ender_chest (where the helper placed it). One writer each
# = portable_ender/open (set on place). Used by cleanup to remove the EXACT block, never a real one.
scoreboard objectives add ec.pe_sx dummy "Portable-Ender Scratch X"
scoreboard objectives add ec.pe_sy dummy "Portable-Ender Scratch Y"
scoreboard objectives add ec.pe_sz dummy "Portable-Ender Scratch Z"
# Watchdog timer (ticks remaining before auto-remove). One writer = open (seed) + cleanup (decrement).
scoreboard objectives add ec.pe_timer dummy "Portable-Ender Auto-Remove Timer"

# Lifetime of a placed temp ender_chest before auto-removal (8s = 160 ticks). Read-only.
scoreboard players set #pe_lifetime ec.var 160
# Walk-away distance: remove the block once the owner is more than this many blocks away. Read-only.
scoreboard players set #pe_walkaway ec.var 6

# Watchdog: a 1s existence-gated sweep that decrements timers + removes walked-away / timed-out blocks.
schedule function evercraft:portable_ender/tick 1s replace
