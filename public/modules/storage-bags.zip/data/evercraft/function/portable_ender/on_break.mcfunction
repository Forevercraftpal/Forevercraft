# === PORTABLE-ENDER — ON BREAK (anti-dupe; mirrors craftforever forge/funnel on_break) ===
# Run as the ec.pe_owner marker, AT the marker (the temp chest's block corner). Reached from the global
# per-tick break-detector ONLY when an owner marker exists but its block is no longer an ender_chest —
# i.e. the player MINED the temp chest (our own walkaway/timeout removal kills the marker in the same
# tick it sets the block to air via remove_at, so this never fires for a clean removal).
#
# The temp block is a REAL minecraft:ender_chest, so mining it drops the vanilla block loot: 8 obsidian
# (no Silk Touch) or 1 ender_chest (with Silk Touch). Left alone that is free infinite obsidian / ender
# chests by spam-placing + mining. Item drops keep a ~10-tick pickup delay, and this detector runs every
# tick, so we destroy the drop well before it can be collected, then remove the orphan marker.

# Destroy the vanilla ender_chest drop (both forms) before pickup.
kill @e[type=item,nbt={Item:{id:"minecraft:obsidian"}},distance=..2]
kill @e[type=item,nbt={Item:{id:"minecraft:ender_chest"}},distance=..2]

# Soft cue + remove the orphan owner marker so the detector stops firing for this spot.
particle minecraft:wax_off ~ ~0.5 ~ 0.3 0.3 0.3 0.02 8
kill @s
