# === PORTABLE-ENDER — OPEN (shared entry; PLAN-chest-nodes §14.8) ===
# Run as @s, at the player. Places a TEMPORARY real minecraft:ender_chest at a per-player scratch spot
# so the player can right-click it to open their ACTUAL ender inventory (the only way — the UI can't be
# command-opened, §6). Records the scratch coords + an owner-stamped marker so the watchdog removes the
# EXACT temp block (never a real placed ender_chest). Callers: P4b pocket_ender_anchor accessory + P5
# dungeon ender-node shift-RC + the Tinker's Omnitool. Grief guard: only ever placed on a spawnable-air
# block 1.5 in front of the player; cleanup keys on the stored coords + the ec.pe_owner marker.

# --- Remove any existing temp ender for this player first (one temp block per player). ---
execute if score @s ec.pe_timer matches 1.. run function evercraft:portable_ender/remove_existing

# --- Pick the scratch spot: 1.5 blocks IN FRONT of the player at foot level. We zero the PITCH
#     (`rotated ~ 0`) so looking up/down can't tilt the local-forward vector below the feet (into the
#     ground) or above them. That tilt was the #1 reason the chest "never spawned": a normal slightly
#     downward look sank the probe into the floor, so the spawnable-air check below always failed and the
#     placement quietly bailed to place_fail. A throwaway marker reads the candidate block.
execute rotated ~ 0 run summon marker ^ ^ ^1.5 {Tags:["ec.pe_probe"]}

# Validate the candidate at the marker's REAL position: spawnable-air at the spot AND solid footing
# directly below (never overwrite a real block, never float).
scoreboard players set #pe_ok ec.temp 0
execute as @e[type=marker,tag=ec.pe_probe,limit=1] at @s if block ~ ~ ~ #evercraft:spawnable_air unless block ~ ~-1 ~ #evercraft:spawnable_air run scoreboard players set #pe_ok ec.temp 1

# Abort if the spot is blocked/floating (don't grief a real block; the caller can turn + retry).
execute if score #pe_ok ec.temp matches 0 run kill @e[type=marker,tag=ec.pe_probe]
execute if score #pe_ok ec.temp matches 0 run return run function evercraft:portable_ender/place_fail

# --- Place the temp ender_chest in the VALIDATED block + a co-located owner-stamped marker. ---
# `align xyz` floors the probe's position to the exact block corner BEFORE we place + record it, so the
# chest lands in the SAME block we just validated. (The old code truncated coords toward zero, which in
# negative coordinates set the block ONE off from the validated spot — risking a real-block overwrite.)
execute at @e[type=marker,tag=ec.pe_probe,limit=1] align xyz run setblock ~ ~ ~ minecraft:ender_chest replace
execute at @e[type=marker,tag=ec.pe_probe,limit=1] align xyz run summon marker ~ ~ ~ {Tags:["ec.pe","ec.pe_owner","ec.pe_new"]}
kill @e[type=marker,tag=ec.pe_probe]
scoreboard players operation @e[type=marker,tag=ec.pe_new,limit=1] ec.st_owner = @s ec.st_owner

# Record the exact scratch block coords on the player (cleanup removes the EXACT block here, never a real
# one). Read from the block-corner marker: its coords are exact integers, so store result needs no
# sign-skew correction.
execute store result score @s ec.pe_sx run data get entity @e[type=marker,tag=ec.pe_new,limit=1] Pos[0] 1
execute store result score @s ec.pe_sy run data get entity @e[type=marker,tag=ec.pe_new,limit=1] Pos[1] 1
execute store result score @s ec.pe_sz run data get entity @e[type=marker,tag=ec.pe_new,limit=1] Pos[2] 1
tag @e[type=marker,tag=ec.pe_new] remove ec.pe_new

# Seed the auto-remove timer.
scoreboard players operation @s ec.pe_timer = #pe_lifetime ec.var

# Cue: a soft resonance + a hint to right-click.
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.ender_chest.open master @s ~ ~ ~ 0.7 1.1
data modify storage evercraft:notify stage.c set value [{text:"⚙ ",color:"#B87333"},{text:"A portable ",color:"gray"},{text:"ender chest",color:"#B87333"},{text:" — right-click to reach your stored goods.",color:"gray"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
