# Portable-Ender — place FAILED (no free spot in front of the player). Run as @s, at the player.
# A quiet "no room" cue. The caller is unharmed; the player just turns to clearer ground + retries.
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 0.6 0.7
data modify storage evercraft:notify stage.c set value [{text:"⚙ ",color:"#B87333"},{text:"No room ahead",color:"yellow"},{text:" — face open ground to set down the ender chest.",color:"gray"}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit
