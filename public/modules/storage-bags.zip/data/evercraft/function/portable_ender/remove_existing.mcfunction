# Portable-Ender — remove THIS player's existing temp ender_chest (one temp block per player). Run as
# @s, at the player. Removes the EXACT block at the player's stored scratch coords (ec.pe_s{x,y,z}) ONLY
# if it is still an ender_chest (never griefs a real block someone placed there since) + kills the
# co-located owner marker. Clears the timer so the player can place a fresh one.

# Stage the player's stored scratch coords into storage, then remove the block at those exact coords.
execute store result storage evercraft:pe_scratch x int 1 run scoreboard players get @s ec.pe_sx
execute store result storage evercraft:pe_scratch y int 1 run scoreboard players get @s ec.pe_sy
execute store result storage evercraft:pe_scratch z int 1 run scoreboard players get @s ec.pe_sz
function evercraft:portable_ender/remove_at with storage evercraft:pe_scratch

scoreboard players set @s ec.pe_timer 0
