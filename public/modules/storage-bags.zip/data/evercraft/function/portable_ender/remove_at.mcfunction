# Portable-Ender — remove the temp ender_chest at exact coords. Macro: called with storage
# evercraft:pe_scratch {x,y,z}. Removes the block ONLY if it is still an ender_chest (grief guard: a
# real block now at those coords is left untouched) + kills the owner marker co-located there.
$execute positioned $(x) $(y) $(z) if block ~ ~ ~ minecraft:ender_chest run setblock ~ ~ ~ minecraft:air replace
$execute positioned $(x) $(y) $(z) run kill @e[type=marker,tag=ec.pe_owner,distance=..1.5]
$execute positioned $(x) $(y) $(z) run particle minecraft:wax_off ~ ~0.5 ~ 0.3 0.3 0.3 0.02 8
