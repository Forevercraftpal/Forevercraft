# === PORTABLE-ENDER — WATCHDOG (1s, existence-gated) ===
# Auto-removes a temp ender_chest on TIMEOUT or WALK-AWAY (R2/R4 grief guard). Mirrors the splash
# despawn cadence. Existence-gated: skip entirely unless a temp ender (an ec.pe_owner marker) exists.
schedule function evercraft:portable_ender/tick 1s replace

# Skip the whole sweep when no temp ender is out.
execute unless entity @e[type=marker,tag=ec.pe_owner,limit=1] run return 0

# Decrement every active player timer; run cleanup for those who still own a temp block.
execute as @a[scores={ec.pe_timer=1..}] at @s run function evercraft:portable_ender/cleanup
