# Portable-Ender — per-owner cleanup. Run as @s (a player with ec.pe_timer>=1), at the player.
# Decrements the timer; removes the temp ender on TIMEOUT (timer hits 0) OR WALK-AWAY (the owner is
# more than #pe_walkaway blocks from the stored scratch coords). Uses remove_existing (the exact-coord,
# grief-guarded removal) so a real block is never touched.

scoreboard players remove @s ec.pe_timer 20

# --- Walk-away check: distance from the owner to the temp block's scratch coords. ---
# Build the squared horizontal distance in integer scratch (cheap, no NBT float math).
scoreboard players operation #pe_dx ec.temp = @s ec.pe_sx
execute store result score #pe_ox ec.temp run data get entity @s Pos[0] 1
scoreboard players operation #pe_dx ec.temp -= #pe_ox ec.temp
scoreboard players operation #pe_dz ec.temp = @s ec.pe_sz
execute store result score #pe_oz ec.temp run data get entity @s Pos[2] 1
scoreboard players operation #pe_dz ec.temp -= #pe_oz ec.temp
# |dx| and |dz| (abs via the -1 multiplier idiom).
execute if score #pe_dx ec.temp matches ..-1 run scoreboard players operation #pe_dx ec.temp *= #caff_neg1 ec.var
execute if score #pe_dz ec.temp matches ..-1 run scoreboard players operation #pe_dz ec.temp *= #caff_neg1 ec.var

# Walked away (Chebyshev distance > walkaway on either axis) -> remove now.
scoreboard players set #pe_far ec.temp 0
execute if score #pe_dx ec.temp > #pe_walkaway ec.var run scoreboard players set #pe_far ec.temp 1
execute if score #pe_dz ec.temp > #pe_walkaway ec.var run scoreboard players set #pe_far ec.temp 1

# Remove on timeout (timer <=0) OR walk-away. remove_existing zeroes the timer (loop-safe).
execute if score @s ec.pe_timer matches ..0 run function evercraft:portable_ender/remove_existing
execute if score #pe_far ec.temp matches 1 run function evercraft:portable_ender/remove_existing
