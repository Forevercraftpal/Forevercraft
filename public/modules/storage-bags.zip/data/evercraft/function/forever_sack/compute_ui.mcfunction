# Forever Sack — compute display values into storage evercraft:forever_sack ui.{bar,pct,dust,tname,tcolor}.
# Run AS the holder. Shared by refresh_lore (item) and menu/refresh (in-world panel).
scoreboard players set #fs_c100 ec.temp 100
scoreboard players set #fs_c10 ec.temp 10
scoreboard players set #fs_cap ec.temp 13824

scoreboard players operation #fs_d ec.temp = @s ec.fsack_dust
execute if score #fs_d ec.temp matches 13824.. run scoreboard players set #fs_d ec.temp 13824

scoreboard players operation #fs_pct ec.temp = #fs_d ec.temp
scoreboard players operation #fs_pct ec.temp *= #fs_c100 ec.temp
scoreboard players operation #fs_pct ec.temp /= #fs_cap ec.temp
scoreboard players operation #fs_seg ec.temp = #fs_d ec.temp
scoreboard players operation #fs_seg ec.temp *= #fs_c10 ec.temp
scoreboard players operation #fs_seg ec.temp /= #fs_cap ec.temp

execute if score #fs_seg ec.temp matches 0 run data modify storage evercraft:forever_sack ui.bar set value "▱▱▱▱▱▱▱▱▱▱"
execute if score #fs_seg ec.temp matches 1 run data modify storage evercraft:forever_sack ui.bar set value "▰▱▱▱▱▱▱▱▱▱"
execute if score #fs_seg ec.temp matches 2 run data modify storage evercraft:forever_sack ui.bar set value "▰▰▱▱▱▱▱▱▱▱"
execute if score #fs_seg ec.temp matches 3 run data modify storage evercraft:forever_sack ui.bar set value "▰▰▰▱▱▱▱▱▱▱"
execute if score #fs_seg ec.temp matches 4 run data modify storage evercraft:forever_sack ui.bar set value "▰▰▰▰▱▱▱▱▱▱"
execute if score #fs_seg ec.temp matches 5 run data modify storage evercraft:forever_sack ui.bar set value "▰▰▰▰▰▱▱▱▱▱"
execute if score #fs_seg ec.temp matches 6 run data modify storage evercraft:forever_sack ui.bar set value "▰▰▰▰▰▰▱▱▱▱"
execute if score #fs_seg ec.temp matches 7 run data modify storage evercraft:forever_sack ui.bar set value "▰▰▰▰▰▰▰▱▱▱"
execute if score #fs_seg ec.temp matches 8 run data modify storage evercraft:forever_sack ui.bar set value "▰▰▰▰▰▰▰▰▱▱"
execute if score #fs_seg ec.temp matches 9 run data modify storage evercraft:forever_sack ui.bar set value "▰▰▰▰▰▰▰▰▰▱"
execute if score #fs_seg ec.temp matches 10.. run data modify storage evercraft:forever_sack ui.bar set value "▰▰▰▰▰▰▰▰▰▰"

data modify storage evercraft:forever_sack ui.tname set value "Common"
data modify storage evercraft:forever_sack ui.tcolor set value "white"
execute if score @s ec.fsack_peak matches 2 run data modify storage evercraft:forever_sack ui.tname set value "Uncommon"
execute if score @s ec.fsack_peak matches 2 run data modify storage evercraft:forever_sack ui.tcolor set value "#7FDB6B"
execute if score @s ec.fsack_peak matches 3 run data modify storage evercraft:forever_sack ui.tname set value "Rare"
execute if score @s ec.fsack_peak matches 3 run data modify storage evercraft:forever_sack ui.tcolor set value "#5B9BE8"
execute if score @s ec.fsack_peak matches 4 run data modify storage evercraft:forever_sack ui.tname set value "Ornate"
execute if score @s ec.fsack_peak matches 4 run data modify storage evercraft:forever_sack ui.tcolor set value "#C77FE8"
execute if score @s ec.fsack_peak matches 5 run data modify storage evercraft:forever_sack ui.tname set value "Exquisite"
execute if score @s ec.fsack_peak matches 5 run data modify storage evercraft:forever_sack ui.tcolor set value "#E8C66B"
execute if score @s ec.fsack_peak matches 6.. run data modify storage evercraft:forever_sack ui.tname set value "Mythical"
execute if score @s ec.fsack_peak matches 6.. run data modify storage evercraft:forever_sack ui.tcolor set value "#E8746B"

execute store result storage evercraft:forever_sack ui.dust int 1 run scoreboard players get @s ec.fsack_dust
execute store result storage evercraft:forever_sack ui.pct int 1 run scoreboard players get #fs_pct ec.temp
