# Forever Sack — macro: create an empty whitelist for this player id if missing. Arg: id.
$execute unless data storage evercraft:forever_sack lists.p$(id).wl run data modify storage evercraft:forever_sack lists.p$(id).wl set value []
