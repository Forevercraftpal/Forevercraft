# Forever Sack — macro: sweep feedback. Args: gain, n.
$data modify storage evercraft:notify stage.c set value [{"text":"❖ ","color":"#B98BD9"},{"text":"Swept ","color":"#D8C28A"},{"text":"$(n)","color":"white"},{"text":" items → ","color":"#D8C28A"},{"text":"$(gain)","color":"#E8C66B"},{"text":" Forever Dust.","color":"#D8C28A"}]
scoreboard players set #ndur ec.temp 50
function evercraft:util/notify/emit
