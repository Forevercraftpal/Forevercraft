# Forever Sack — macro: push the just-built undo_entry onto this player's undo stack.
# Newest is last; capped at 3 (drop the oldest when a 4th would land). Arg: id.
$data modify storage evercraft:forever_sack lists.p$(id).undo append from storage evercraft:forever_sack undo_entry
$execute if data storage evercraft:forever_sack lists.p$(id).undo[3] run data remove storage evercraft:forever_sack lists.p$(id).undo[0]
