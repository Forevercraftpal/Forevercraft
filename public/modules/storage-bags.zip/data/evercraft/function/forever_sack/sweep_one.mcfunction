# Forever Sack — macro: sweep one whitelisted id from the player's inventory. Arg: id2 (item id).
# Protection MUST mirror the TEACH gate (dissolve_offhand #fs_val), which never whitelists an item
# that has is_artifact / evercraft_item / a custom tier / a minecraft:rarity. Two 2026-06-17 bugs:
#   (a) old `[!custom_data~{}]` skipped ANY copy with custom_data — so ordinary trash carrying a
#       benign custom_data tag was whitelisted yet never swept ("doesn't detect the inventory");
#   (b) the first fix `[!custom_data~{evercraft_item:true}]` only spared evercraft_item items — but
#       ARTIFACTS (e.g. the Hellenic Sword) carry is_artifact + a minecraft:rarity, NOT evercraft_item,
#       so the sweep ate them.
# Fix: spare anything with is_artifact OR evercraft_item OR a minecraft:rarity (the same markers the
# teach gate rejects). Artifacts carry is_artifact (+rarity), custom gear/items carry evercraft_item,
# elevated loot carries rarity — while plain or benignly-tagged trash has none (common rarity is unset,
# never serialized) → it sweeps cleanly. Multi-condition item predicate (two custom_data tests + rarity)
# is valid, established syntax (cf. crates `book[custom_data~{...},!custom_data~{bp_free:1b}]`).
$execute store result score #fs_have ec.temp run clear @s $(id2)[!custom_data~{is_artifact:true},!custom_data~{evercraft_item:true},!minecraft:rarity] 0
execute if score #fs_have ec.temp matches ..0 run return 0
$data modify storage evercraft:forever_sack vitem set value {id:"$(id2)"}
function evercraft:forever_sack/value_lookup
scoreboard players operation #fs_add ec.temp = #fs_dv ec.temp
scoreboard players operation #fs_add ec.temp *= #fs_have ec.temp
scoreboard players operation #fs_gain ec.temp += #fs_add ec.temp
scoreboard players operation #fs_cnt ec.temp += #fs_have ec.temp
execute if score #fs_pkv ec.temp > #fs_pk ec.temp run scoreboard players operation #fs_pk ec.temp = #fs_pkv ec.temp
$clear @s $(id2)[!custom_data~{is_artifact:true},!custom_data~{evercraft_item:true},!minecraft:rarity]
