# Forever Sack — sweep EVERY whitelisted item type from the player's inventory into Forever Dust.
# Entry point for Sneak+RC and the GUI [Sweep Now] button. Run AS the player.
execute unless score @s ec.fsack_id matches 1.. run return 0

execute store result storage evercraft:forever_sack k.id int 1 run scoreboard players get @s ec.fsack_id
function evercraft:forever_sack/copy_wl with storage evercraft:forever_sack k

scoreboard players set #fs_gain ec.temp 0
scoreboard players set #fs_cnt ec.temp 0
scoreboard players set #fs_pk ec.temp 0
function evercraft:forever_sack/bulk_eat_next

# Nothing matched -> nudge and stop.
execute if score #fs_cnt ec.temp matches ..0 run return run function evercraft:forever_sack/msg_nothing

# Bank it.
scoreboard players operation @s ec.fsack_dust += #fs_gain ec.temp
scoreboard players operation @s ec.fsack_items += #fs_cnt ec.temp
execute if score #fs_pk ec.temp > @s ec.fsack_peak run scoreboard players operation @s ec.fsack_peak = #fs_pk ec.temp

# Feedback (macro bakes the count + dust).
execute store result storage evercraft:forever_sack msg.gain int 1 run scoreboard players get #fs_gain ec.temp
execute store result storage evercraft:forever_sack msg.n int 1 run scoreboard players get #fs_cnt ec.temp
function evercraft:forever_sack/msg_swept with storage evercraft:forever_sack msg
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.amethyst_block.resonate master @s ~ ~ ~ 0.7 1.0
execute if score @s ec.fx_vis matches 1.. at @s run particle minecraft:witch ~ ~1 ~ 0.4 0.5 0.4 0.08 20

function evercraft:forever_sack/refresh_lore
execute if entity @s[tag=ec.fsack_in_menu] run function evercraft:forever_sack/menu/refresh
execute if score @s ec.fsack_dust matches 13824.. run function evercraft:forever_sack/payout
