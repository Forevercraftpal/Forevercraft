# Forever Sack — right-click handler (minecraft:using_item trigger, proven satchel pattern).
#
# The item is a bundle LOOK-ALIKE that is NEVER consumed: food{can_always_eat} +
# consumable{consume_seconds:999999} means a right-click STARTS a 999999s "use" that never
# finishes, so the Sack always stays in hand — no consume, no restore dance. using_item fires
# the instant RC is pressed (and each tick while held), but an advancement only rewards ONCE
# when it completes, and stays granted while held → no per-tick re-fire. It is revoked in
# menu/close (and after a sweep) so the NEXT press re-triggers.

# Migration safety: ensure this holder has an id + whitelist (older sacks predate it).
execute unless score @s ec.fsack_id matches 1.. run function evercraft:forever_sack/assign_id

# Sneak + Right-Click = sweep every whitelisted type from the inventory.
# ROOT-CAUSE FIX (2026-06-15): use the real shift-key flag (evercraft:sneaking = is_sneaking)
# NOT a pose predicate. During item-use the player's POSE reads as "crouching" even when shift
# isn't held (the brush/use animation lowers the pose), so the old `player_crouching` check sent
# EVERY plain right-click into the sweep branch → return 0 → the menu never opened.
# Debounce (ec.fsack_use_cd) so a HELD sneak-press sweeps once, not every tick; revoke after
# so the next deliberate sneak-press can re-trigger (use_cooldown bounds the overall rate).
execute if predicate evercraft:sneaking if score @s ec.fsack_use_cd matches 1.. run return 0
execute if predicate evercraft:sneaking run scoreboard players set @s ec.fsack_use_cd 12
execute if predicate evercraft:sneaking run function evercraft:forever_sack/bulk_eat
execute if predicate evercraft:sneaking run advancement revoke @s only evercraft:forever_sack/open
execute if predicate evercraft:sneaking run return 0

# Already in the menu AND the panel really exists? Leave it (advancement stays granted while
# held; [Close]/walk-away closes it). But if the in_menu tag is STALE (panel culled without
# menu/close — clean_gui, chunk unload, an older broken build), clearing it here guarantees a
# stale flag can never dead-end the open path into a silent return.
execute if entity @s[tag=ec.fsack_in_menu] at @s if entity @e[type=item_display,tag=ec.fsack_bg,distance=..6] run return 0
tag @s remove ec.fsack_in_menu

# Plain Right-Click = open the menu.
function evercraft:forever_sack/menu/open
# INCONSISTENT-REOPEN FIX (2026-06-18): do NOT refresh_lore here. refresh_lore pulls the sack out of
# the hand into a hopper-minecart and swaps it back — and doing that on the very tick the open
# right-click is still "using" the item RACES the using_item trigger, which is exactly why the menu
# reopened only sometimes. The proven Essentials Satchel (same pattern) never touches the held item
# on open — it only reads SelectedItem — and matching that here is the fix. The item's dust readout
# stays current via refresh_lore on every dissolve/sweep and on menu/close (genuine use-free
# moments); dust can't change merely by opening, so re-stamping here was redundant. The stale-tier
# migration also rides those same refresh_lore calls, so it still runs.
