# Forever Sack — value a NON-rarity (vanilla) item by its id, like the ore/mining-crate value bands.
# Input: storage evercraft:forever_sack vitem = the item stack ({id,count,components,...}).
# Output: #fs_dv ec.temp = per-item Forever Dust; #fs_pkv ec.temp = the crate tier it raises to.
# Anything not listed stays true junk (1 dust, Common). Quality in, quality out.

scoreboard players set #fs_dv ec.temp 1

# --- Band 4 (basic resources -> Common) ---
execute if data storage evercraft:forever_sack vitem{id:"minecraft:coal"} run scoreboard players set #fs_dv ec.temp 4
execute if data storage evercraft:forever_sack vitem{id:"minecraft:charcoal"} run scoreboard players set #fs_dv ec.temp 4
execute if data storage evercraft:forever_sack vitem{id:"minecraft:raw_copper"} run scoreboard players set #fs_dv ec.temp 4
execute if data storage evercraft:forever_sack vitem{id:"minecraft:copper_ingot"} run scoreboard players set #fs_dv ec.temp 4
execute if data storage evercraft:forever_sack vitem{id:"minecraft:redstone"} run scoreboard players set #fs_dv ec.temp 4
execute if data storage evercraft:forever_sack vitem{id:"minecraft:glowstone_dust"} run scoreboard players set #fs_dv ec.temp 4
execute if data storage evercraft:forever_sack vitem{id:"minecraft:quartz"} run scoreboard players set #fs_dv ec.temp 4
execute if data storage evercraft:forever_sack vitem{id:"minecraft:flint"} run scoreboard players set #fs_dv ec.temp 4
execute if data storage evercraft:forever_sack vitem{id:"minecraft:slime_ball"} run scoreboard players set #fs_dv ec.temp 4
execute if data storage evercraft:forever_sack vitem{id:"minecraft:honeycomb"} run scoreboard players set #fs_dv ec.temp 4
execute if data storage evercraft:forever_sack vitem{id:"minecraft:blaze_powder"} run scoreboard players set #fs_dv ec.temp 4
execute if data storage evercraft:forever_sack vitem{id:"minecraft:glow_ink_sac"} run scoreboard players set #fs_dv ec.temp 4

# --- Band 16 (metals & minor treasures -> Uncommon) ---
execute if data storage evercraft:forever_sack vitem{id:"minecraft:iron_ingot"} run scoreboard players set #fs_dv ec.temp 16
execute if data storage evercraft:forever_sack vitem{id:"minecraft:raw_iron"} run scoreboard players set #fs_dv ec.temp 16
execute if data storage evercraft:forever_sack vitem{id:"minecraft:gold_ingot"} run scoreboard players set #fs_dv ec.temp 16
execute if data storage evercraft:forever_sack vitem{id:"minecraft:raw_gold"} run scoreboard players set #fs_dv ec.temp 16
execute if data storage evercraft:forever_sack vitem{id:"minecraft:lapis_lazuli"} run scoreboard players set #fs_dv ec.temp 16
execute if data storage evercraft:forever_sack vitem{id:"minecraft:amethyst_shard"} run scoreboard players set #fs_dv ec.temp 16
execute if data storage evercraft:forever_sack vitem{id:"minecraft:prismarine_shard"} run scoreboard players set #fs_dv ec.temp 16
execute if data storage evercraft:forever_sack vitem{id:"minecraft:prismarine_crystals"} run scoreboard players set #fs_dv ec.temp 16
execute if data storage evercraft:forever_sack vitem{id:"minecraft:ender_pearl"} run scoreboard players set #fs_dv ec.temp 16
execute if data storage evercraft:forever_sack vitem{id:"minecraft:blaze_rod"} run scoreboard players set #fs_dv ec.temp 16
execute if data storage evercraft:forever_sack vitem{id:"minecraft:nautilus_shell"} run scoreboard players set #fs_dv ec.temp 16
execute if data storage evercraft:forever_sack vitem{id:"minecraft:copper_block"} run scoreboard players set #fs_dv ec.temp 16
execute if data storage evercraft:forever_sack vitem{id:"minecraft:ghast_tear"} run scoreboard players set #fs_dv ec.temp 16
execute if data storage evercraft:forever_sack vitem{id:"minecraft:phantom_membrane"} run scoreboard players set #fs_dv ec.temp 16
execute if data storage evercraft:forever_sack vitem{id:"minecraft:shulker_shell"} run scoreboard players set #fs_dv ec.temp 16

# --- Band 64 (gems & rich blocks -> Rare) ---
execute if data storage evercraft:forever_sack vitem{id:"minecraft:diamond"} run scoreboard players set #fs_dv ec.temp 64
execute if data storage evercraft:forever_sack vitem{id:"minecraft:emerald"} run scoreboard players set #fs_dv ec.temp 64
execute if data storage evercraft:forever_sack vitem{id:"minecraft:iron_block"} run scoreboard players set #fs_dv ec.temp 64
execute if data storage evercraft:forever_sack vitem{id:"minecraft:gold_block"} run scoreboard players set #fs_dv ec.temp 64
execute if data storage evercraft:forever_sack vitem{id:"minecraft:redstone_block"} run scoreboard players set #fs_dv ec.temp 64
execute if data storage evercraft:forever_sack vitem{id:"minecraft:lapis_block"} run scoreboard players set #fs_dv ec.temp 64
execute if data storage evercraft:forever_sack vitem{id:"minecraft:heart_of_the_sea"} run scoreboard players set #fs_dv ec.temp 64
execute if data storage evercraft:forever_sack vitem{id:"minecraft:echo_shard"} run scoreboard players set #fs_dv ec.temp 64
execute if data storage evercraft:forever_sack vitem{id:"minecraft:ancient_debris"} run scoreboard players set #fs_dv ec.temp 64
execute if data storage evercraft:forever_sack vitem{id:"minecraft:netherite_scrap"} run scoreboard players set #fs_dv ec.temp 64
execute if data storage evercraft:forever_sack vitem{id:"minecraft:enchanted_book"} run scoreboard players set #fs_dv ec.temp 64

# --- Band 256 (premium -> Ornate) ---
execute if data storage evercraft:forever_sack vitem{id:"minecraft:diamond_block"} run scoreboard players set #fs_dv ec.temp 256
execute if data storage evercraft:forever_sack vitem{id:"minecraft:emerald_block"} run scoreboard players set #fs_dv ec.temp 256
execute if data storage evercraft:forever_sack vitem{id:"minecraft:netherite_ingot"} run scoreboard players set #fs_dv ec.temp 256
execute if data storage evercraft:forever_sack vitem{id:"minecraft:totem_of_undying"} run scoreboard players set #fs_dv ec.temp 256
execute if data storage evercraft:forever_sack vitem{id:"minecraft:enchanted_golden_apple"} run scoreboard players set #fs_dv ec.temp 256
execute if data storage evercraft:forever_sack vitem{id:"minecraft:nether_star"} run scoreboard players set #fs_dv ec.temp 256

# --- Band 1024 (elite -> Exquisite) ---
execute if data storage evercraft:forever_sack vitem{id:"minecraft:netherite_block"} run scoreboard players set #fs_dv ec.temp 1024
execute if data storage evercraft:forever_sack vitem{id:"minecraft:dragon_egg"} run scoreboard players set #fs_dv ec.temp 1024
execute if data storage evercraft:forever_sack vitem{id:"minecraft:dragon_head"} run scoreboard players set #fs_dv ec.temp 1024
execute if data storage evercraft:forever_sack vitem{id:"minecraft:beacon"} run scoreboard players set #fs_dv ec.temp 1024
execute if data storage evercraft:forever_sack vitem{id:"minecraft:elytra"} run scoreboard players set #fs_dv ec.temp 1024

# --- Tools, armor & gear by material (so a diamond pick is never "1 dust") ---
# Iron gear -> 16 (Uncommon)
execute if data storage evercraft:forever_sack vitem{id:"minecraft:iron_sword"} run scoreboard players set #fs_dv ec.temp 16
execute if data storage evercraft:forever_sack vitem{id:"minecraft:iron_pickaxe"} run scoreboard players set #fs_dv ec.temp 16
execute if data storage evercraft:forever_sack vitem{id:"minecraft:iron_axe"} run scoreboard players set #fs_dv ec.temp 16
execute if data storage evercraft:forever_sack vitem{id:"minecraft:iron_shovel"} run scoreboard players set #fs_dv ec.temp 16
execute if data storage evercraft:forever_sack vitem{id:"minecraft:iron_hoe"} run scoreboard players set #fs_dv ec.temp 16
execute if data storage evercraft:forever_sack vitem{id:"minecraft:iron_helmet"} run scoreboard players set #fs_dv ec.temp 16
execute if data storage evercraft:forever_sack vitem{id:"minecraft:iron_chestplate"} run scoreboard players set #fs_dv ec.temp 16
execute if data storage evercraft:forever_sack vitem{id:"minecraft:iron_leggings"} run scoreboard players set #fs_dv ec.temp 16
execute if data storage evercraft:forever_sack vitem{id:"minecraft:iron_boots"} run scoreboard players set #fs_dv ec.temp 16
# Golden gear + ranged/shield -> 16
execute if data storage evercraft:forever_sack vitem{id:"minecraft:golden_sword"} run scoreboard players set #fs_dv ec.temp 16
execute if data storage evercraft:forever_sack vitem{id:"minecraft:golden_pickaxe"} run scoreboard players set #fs_dv ec.temp 16
execute if data storage evercraft:forever_sack vitem{id:"minecraft:golden_axe"} run scoreboard players set #fs_dv ec.temp 16
execute if data storage evercraft:forever_sack vitem{id:"minecraft:golden_shovel"} run scoreboard players set #fs_dv ec.temp 16
execute if data storage evercraft:forever_sack vitem{id:"minecraft:golden_hoe"} run scoreboard players set #fs_dv ec.temp 16
execute if data storage evercraft:forever_sack vitem{id:"minecraft:golden_helmet"} run scoreboard players set #fs_dv ec.temp 16
execute if data storage evercraft:forever_sack vitem{id:"minecraft:golden_chestplate"} run scoreboard players set #fs_dv ec.temp 16
execute if data storage evercraft:forever_sack vitem{id:"minecraft:golden_leggings"} run scoreboard players set #fs_dv ec.temp 16
execute if data storage evercraft:forever_sack vitem{id:"minecraft:golden_boots"} run scoreboard players set #fs_dv ec.temp 16
execute if data storage evercraft:forever_sack vitem{id:"minecraft:bow"} run scoreboard players set #fs_dv ec.temp 16
execute if data storage evercraft:forever_sack vitem{id:"minecraft:crossbow"} run scoreboard players set #fs_dv ec.temp 16
execute if data storage evercraft:forever_sack vitem{id:"minecraft:shield"} run scoreboard players set #fs_dv ec.temp 16
# Diamond gear -> 64 (Rare)
execute if data storage evercraft:forever_sack vitem{id:"minecraft:diamond_sword"} run scoreboard players set #fs_dv ec.temp 64
execute if data storage evercraft:forever_sack vitem{id:"minecraft:diamond_pickaxe"} run scoreboard players set #fs_dv ec.temp 64
execute if data storage evercraft:forever_sack vitem{id:"minecraft:diamond_axe"} run scoreboard players set #fs_dv ec.temp 64
execute if data storage evercraft:forever_sack vitem{id:"minecraft:diamond_shovel"} run scoreboard players set #fs_dv ec.temp 64
execute if data storage evercraft:forever_sack vitem{id:"minecraft:diamond_hoe"} run scoreboard players set #fs_dv ec.temp 64
execute if data storage evercraft:forever_sack vitem{id:"minecraft:diamond_helmet"} run scoreboard players set #fs_dv ec.temp 64
execute if data storage evercraft:forever_sack vitem{id:"minecraft:diamond_chestplate"} run scoreboard players set #fs_dv ec.temp 64
execute if data storage evercraft:forever_sack vitem{id:"minecraft:diamond_leggings"} run scoreboard players set #fs_dv ec.temp 64
execute if data storage evercraft:forever_sack vitem{id:"minecraft:diamond_boots"} run scoreboard players set #fs_dv ec.temp 64
execute if data storage evercraft:forever_sack vitem{id:"minecraft:trident"} run scoreboard players set #fs_dv ec.temp 64
# Netherite gear -> 256 (Ornate)
execute if data storage evercraft:forever_sack vitem{id:"minecraft:netherite_sword"} run scoreboard players set #fs_dv ec.temp 256
execute if data storage evercraft:forever_sack vitem{id:"minecraft:netherite_pickaxe"} run scoreboard players set #fs_dv ec.temp 256
execute if data storage evercraft:forever_sack vitem{id:"minecraft:netherite_axe"} run scoreboard players set #fs_dv ec.temp 256
execute if data storage evercraft:forever_sack vitem{id:"minecraft:netherite_shovel"} run scoreboard players set #fs_dv ec.temp 256
execute if data storage evercraft:forever_sack vitem{id:"minecraft:netherite_hoe"} run scoreboard players set #fs_dv ec.temp 256
execute if data storage evercraft:forever_sack vitem{id:"minecraft:netherite_helmet"} run scoreboard players set #fs_dv ec.temp 256
execute if data storage evercraft:forever_sack vitem{id:"minecraft:netherite_chestplate"} run scoreboard players set #fs_dv ec.temp 256
execute if data storage evercraft:forever_sack vitem{id:"minecraft:netherite_leggings"} run scoreboard players set #fs_dv ec.temp 256
execute if data storage evercraft:forever_sack vitem{id:"minecraft:netherite_boots"} run scoreboard players set #fs_dv ec.temp 256

# --- Enchanted books: scale by the enchantments stored (base 16, +8 per level) ---
execute if data storage evercraft:forever_sack vitem{id:"minecraft:enchanted_book"} run function evercraft:forever_sack/value_enchanted_book

# Derive the crate tier this item raises the fill toward.
scoreboard players set #fs_pkv ec.temp 1
execute if score #fs_dv ec.temp matches 16.. run scoreboard players set #fs_pkv ec.temp 2
execute if score #fs_dv ec.temp matches 64.. run scoreboard players set #fs_pkv ec.temp 3
execute if score #fs_dv ec.temp matches 256.. run scoreboard players set #fs_pkv ec.temp 4
execute if score #fs_dv ec.temp matches 1024.. run scoreboard players set #fs_pkv ec.temp 5
execute if score #fs_dv ec.temp matches 4096.. run scoreboard players set #fs_pkv ec.temp 6
