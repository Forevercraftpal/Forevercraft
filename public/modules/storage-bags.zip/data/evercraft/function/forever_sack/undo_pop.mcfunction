# Forever Sack — macro: drop the most recent (last) entry from this player's undo stack. Arg: id.
$data remove storage evercraft:forever_sack lists.p$(id).undo[-1]
