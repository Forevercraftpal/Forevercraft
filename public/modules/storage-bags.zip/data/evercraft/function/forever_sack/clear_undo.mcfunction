# Forever Sack — macro: wipe this player's undo stack (used when a fresh sack is granted). Arg: id.
$data modify storage evercraft:forever_sack lists.p$(id).undo set value []
