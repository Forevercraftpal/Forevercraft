# Forever Sack — macro: copy this player's undo stack into work.undo. Arg: id.
# Reset first so a missing source can't leave another player's stack in work.undo.
data modify storage evercraft:forever_sack work.undo set value []
$data modify storage evercraft:forever_sack work.undo set from storage evercraft:forever_sack lists.p$(id).undo
