# Forever Sack Menu — macro: preserve (remove) the whitelist entry shown on a row. Arg: row.
# Absolute index = page*5 + row.
scoreboard players operation #fs_idx ec.temp = @s ec.fsack_page
scoreboard players set #fs_5 ec.temp 5
scoreboard players operation #fs_idx ec.temp *= #fs_5 ec.temp
$scoreboard players add #fs_idx ec.temp $(row)
execute store result storage evercraft:forever_sack k.id int 1 run scoreboard players get @s ec.fsack_id
execute store result storage evercraft:forever_sack k.idx int 1 run scoreboard players get #fs_idx ec.temp
function evercraft:forever_sack/copy_wl with storage evercraft:forever_sack k
function evercraft:forever_sack/menu/do_remove with storage evercraft:forever_sack k
function evercraft:forever_sack/menu/refresh
