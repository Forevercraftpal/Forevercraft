# Forever Sack Menu — dissolve the player's OFF-HAND stack into Forever Dust.
# Junk: 1 dust/item, instant. Valuables (artifact/tier/rarity/evercraft item): worth far more,
# raise the crate tier, and need a SECOND confirm click. Every dissolve stashes an Undo.
# Run AS the menu owner, AT their position.

# Empty off-hand?
execute unless items entity @s weapon.offhand * run return run function evercraft:forever_sack/menu/msg_empty
# Don't dissolve the Sack itself.
execute if items entity @s weapon.offhand *[custom_data~{forever_sack:true}] run return run function evercraft:forever_sack/menu/msg_self
# A Baúl (bulk_barrel) is a CONTAINER, never junk: dissolve its stored CONTENTS and keep the Baúl.
# Routes filled AND empty Baúls here so the valuable-item path below can never destroy one for scrap.
execute if items entity @s weapon.offhand *[custom_data~{bulk_barrel:true}] run return run function evercraft:forever_sack/menu/dissolve_baul

# Snapshot the off-hand stack into storage (non-destructive copy via a hopper-minecart).
summon hopper_minecart ~ 320 ~ {Tags:["ec.fsack_dcart"],Enabled:0b,Items:[{Slot:0b,id:"minecraft:stone",count:1}]}
item replace entity @e[type=hopper_minecart,tag=ec.fsack_dcart,limit=1] container.0 from entity @s weapon.offhand
data modify storage evercraft:forever_sack cur set from entity @e[type=hopper_minecart,tag=ec.fsack_dcart,limit=1] Items[0]
# CLEAR the cart's Items BEFORE killing it — a hopper-minecart drops its contents when killed,
# which was raining the "dissolved" item back down on the player from y+320.
data modify entity @e[type=hopper_minecart,tag=ec.fsack_dcart,limit=1] Items set value []
kill @e[type=hopper_minecart,tag=ec.fsack_dcart]

# Count (default 1).
scoreboard players set #fs_c ec.temp 1
execute store result score #fs_c ec.temp run data get storage evercraft:forever_sack cur.count

# Valuable?
scoreboard players set #fs_val ec.temp 0
execute if data storage evercraft:forever_sack cur.components."minecraft:custom_data".is_artifact run scoreboard players set #fs_val ec.temp 1
execute if data storage evercraft:forever_sack cur.components."minecraft:custom_data".tier run scoreboard players set #fs_val ec.temp 1
execute if data storage evercraft:forever_sack cur.components."minecraft:custom_data".evercraft_item run scoreboard players set #fs_val ec.temp 1
execute if data storage evercraft:forever_sack cur.components."minecraft:rarity" run scoreboard players set #fs_val ec.temp 1

# Tier (1..6). custom_data.tier wins; else minecraft:rarity; else default 2 for valuables.
scoreboard players set #fs_t ec.temp 0
execute if data storage evercraft:forever_sack cur.components."minecraft:custom_data"{tier:"common"} run scoreboard players set #fs_t ec.temp 1
execute if data storage evercraft:forever_sack cur.components."minecraft:custom_data"{tier:"uncommon"} run scoreboard players set #fs_t ec.temp 2
execute if data storage evercraft:forever_sack cur.components."minecraft:custom_data"{tier:"rare"} run scoreboard players set #fs_t ec.temp 3
execute if data storage evercraft:forever_sack cur.components."minecraft:custom_data"{tier:"ornate"} run scoreboard players set #fs_t ec.temp 4
execute if data storage evercraft:forever_sack cur.components."minecraft:custom_data"{tier:"exquisite"} run scoreboard players set #fs_t ec.temp 5
execute if data storage evercraft:forever_sack cur.components."minecraft:custom_data"{tier:"mythical"} run scoreboard players set #fs_t ec.temp 6
execute if score #fs_t ec.temp matches 0 if data storage evercraft:forever_sack cur.components{"minecraft:rarity":"common"} run scoreboard players set #fs_t ec.temp 1
execute if score #fs_t ec.temp matches 0 if data storage evercraft:forever_sack cur.components{"minecraft:rarity":"uncommon"} run scoreboard players set #fs_t ec.temp 2
execute if score #fs_t ec.temp matches 0 if data storage evercraft:forever_sack cur.components{"minecraft:rarity":"rare"} run scoreboard players set #fs_t ec.temp 3
execute if score #fs_t ec.temp matches 0 if data storage evercraft:forever_sack cur.components{"minecraft:rarity":"epic"} run scoreboard players set #fs_t ec.temp 4
execute if score #fs_val ec.temp matches 1 if score #fs_t ec.temp matches 0 run scoreboard players set #fs_t ec.temp 2

# Per-item dust value + total gain + the tier this raises the crate to (pkval).
# Non-rarity: value-scaled by id (same bands as the casual digest). Rarity: tier-banded below.
execute if score #fs_val ec.temp matches 0 run data modify storage evercraft:forever_sack vitem set from storage evercraft:forever_sack cur
execute if score #fs_val ec.temp matches 0 run function evercraft:forever_sack/value_lookup
execute if score #fs_val ec.temp matches 1 run scoreboard players operation #fs_pkv ec.temp = #fs_t ec.temp
execute if score #fs_val ec.temp matches 1 if score #fs_t ec.temp matches 1 run scoreboard players set #fs_dv ec.temp 64
execute if score #fs_val ec.temp matches 1 if score #fs_t ec.temp matches 2 run scoreboard players set #fs_dv ec.temp 256
execute if score #fs_val ec.temp matches 1 if score #fs_t ec.temp matches 3 run scoreboard players set #fs_dv ec.temp 512
execute if score #fs_val ec.temp matches 1 if score #fs_t ec.temp matches 4 run scoreboard players set #fs_dv ec.temp 1024
execute if score #fs_val ec.temp matches 1 if score #fs_t ec.temp matches 5 run scoreboard players set #fs_dv ec.temp 2048
execute if score #fs_val ec.temp matches 1 if score #fs_t ec.temp matches 6 run scoreboard players set #fs_dv ec.temp 4096

# Codex duplicate bonus (Joseph 2026-06-15): an artifact ALREADY enshrined in this player's
# Codex Vault dissolves for DOUBLE — owning the catalyzed original makes a second copy a true
# duplicate, worth 2x. Read the art id from the stack's custom_data and test the deposited
# advancement (the same flag the Gallery deposit grants); double the per-item dust on a match,
# so both the confirm prompt and the payout below reflect it. Non-artifacts (no custom_data.
# artifact) and un-enshrined artifacts leave #fs_dup 0 → no change.
scoreboard players set #fs_dup ec.temp 0
data remove storage evercraft:forever_sack dupk
execute if data storage evercraft:forever_sack cur.components."minecraft:custom_data".artifact run data modify storage evercraft:forever_sack dupk.art set from storage evercraft:forever_sack cur.components."minecraft:custom_data".artifact
execute if data storage evercraft:forever_sack dupk.art run function evercraft:forever_sack/dup_artifact_check with storage evercraft:forever_sack dupk
execute if score #fs_dup ec.temp matches 1 run scoreboard players operation #fs_dv ec.temp += #fs_dv ec.temp
data remove storage evercraft:forever_sack dupk

scoreboard players operation #fs_gain ec.temp = #fs_dv ec.temp
scoreboard players operation #fs_gain ec.temp *= #fs_c ec.temp
execute store result storage evercraft:forever_sack msg.gain int 1 run scoreboard players get #fs_gain ec.temp

# Valuable items need a confirm. Use a temp "this is the arming click" flag so it never depends
# on decay timing: FIRST click (dcd==0) arms the window + asks + STOPS; ANY click while already
# armed (dcd>0, any value) falls through to commit. (The old code set dcd to 40 then matched
# dcd==40 in the SAME run → it re-asked forever and NEVER committed — that's why valuables banked
# no dust, stashed no undo, and never whitelisted.)
scoreboard players set #fs_arm ec.temp 0
execute if score #fs_val ec.temp matches 1 if score @s ec.fsack_dcd matches 0 run scoreboard players set #fs_arm ec.temp 1
execute if score #fs_arm ec.temp matches 1 run scoreboard players set @s ec.fsack_dcd 40
execute if score #fs_arm ec.temp matches 1 run return run function evercraft:forever_sack/menu/msg_confirm with storage evercraft:forever_sack msg

# --- Commit the dissolve ---
# Stash undo onto this player's stack (newest last, keeps the last 3; stores the prior peak so
# we can restore it exactly). The stack lives in storage keyed by id, so it survives closing the
# menu. Built BEFORE the peak update below so undo_entry.peak is the pre-dissolve peak.
data modify storage evercraft:forever_sack undo_entry set value {}
data modify storage evercraft:forever_sack undo_entry.item set from storage evercraft:forever_sack cur
execute store result storage evercraft:forever_sack undo_entry.dust int 1 run scoreboard players get #fs_gain ec.temp
execute store result storage evercraft:forever_sack undo_entry.items int 1 run scoreboard players get #fs_c ec.temp
execute store result storage evercraft:forever_sack undo_entry.peak int 1 run scoreboard players get @s ec.fsack_peak
execute if score @s ec.fsack_id matches 1.. store result storage evercraft:forever_sack k.id int 1 run scoreboard players get @s ec.fsack_id
execute if score @s ec.fsack_id matches 1.. run function evercraft:forever_sack/undo_push with storage evercraft:forever_sack k

# Remove the off-hand stack.
item replace entity @s weapon.offhand with air

# Bank it.
scoreboard players operation @s ec.fsack_dust += #fs_gain ec.temp
scoreboard players operation @s ec.fsack_items += #fs_c ec.temp
execute if score #fs_pkv ec.temp > @s ec.fsack_peak run scoreboard players operation @s ec.fsack_peak = #fs_pkv ec.temp
scoreboard players set @s ec.fsack_dcd 0

# Teach the bag: a NON-rarity item's type joins the whitelist (rarity/custom never do).
execute if score #fs_val ec.temp matches 0 if score @s ec.fsack_id matches 1.. store result storage evercraft:forever_sack k.id int 1 run scoreboard players get @s ec.fsack_id
execute if score #fs_val ec.temp matches 0 if score @s ec.fsack_id matches 1.. run data modify storage evercraft:forever_sack k.item set from storage evercraft:forever_sack cur.id
execute if score #fs_val ec.temp matches 0 if score @s ec.fsack_id matches 1.. run function evercraft:forever_sack/add_whitelist with storage evercraft:forever_sack k

# Feedback (macro bakes the dust number so it survives the notify queue). A Codex-duplicate
# artifact (2x) gets its own message so the doubled payout reads as intentional.
execute if score #fs_dup ec.temp matches 1 run function evercraft:forever_sack/menu/msg_dissolved_dup with storage evercraft:forever_sack msg
execute unless score #fs_dup ec.temp matches 1 run function evercraft:forever_sack/menu/msg_dissolved with storage evercraft:forever_sack msg

function evercraft:forever_sack/refresh_lore
function evercraft:forever_sack/menu/refresh
execute if score @s ec.fsack_dust matches 13824.. run function evercraft:forever_sack/payout
