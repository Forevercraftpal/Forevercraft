# Forever Sack — dissolve success feedback (macro). Arg: gain.
$data modify storage evercraft:notify stage.c set value [{"text":"❖ ","color":"#B98BD9"},{"text":"Dissolved for ","color":"#D8C28A"},{"text":"$(gain)","color":"#E8C66B"},{"text":" Forever Dust.","color":"#D8C28A"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.amethyst_block.resonate master @s ~ ~ ~ 0.6 1.1
execute if score @s ec.fx_vis matches 1.. at @s run particle minecraft:witch ~ ~1 ~ 0.3 0.4 0.3 0.05 12
