# Forever Sack — dissolve success feedback for a Codex DUPLICATE artifact (2x value). Arg: gain.
# Replaces the normal msg_dissolved when the dissolved artifact was already enshrined in the
# player's Codex Vault, so the doubled payout reads as intentional. (Joseph 2026-06-15)
$data modify storage evercraft:notify stage.c set value [{"text":"✦ ","color":"#E8C66B"},{"text":"Codex duplicate! Dissolved for ","color":"#D8C28A"},{"text":"$(gain)","color":"#E8C66B"},{"text":" Forever Dust ","color":"#D8C28A"},{"text":"(2×).","color":"#E8C66B"}]
scoreboard players set #ndur ec.temp 50
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.amethyst_block.resonate master @s ~ ~ ~ 0.6 1.3
execute if score @s ec.fx_vis matches 1.. at @s run particle minecraft:witch ~ ~1 ~ 0.3 0.4 0.3 0.05 18
