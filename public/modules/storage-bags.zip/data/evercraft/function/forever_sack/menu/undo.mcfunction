# Forever Sack Menu — undo the MOST RECENT dissolve from this player's stack (keeps the last 3):
# return the item + refund its dust + restore peak. LIFO, so repeated clicks walk back up to 3.
# Run AS the menu owner, AT their position.

# Copy this player's undo stack; bail if it's empty.
execute store result storage evercraft:forever_sack k.id int 1 run scoreboard players get @s ec.fsack_id
function evercraft:forever_sack/copy_undo with storage evercraft:forever_sack k
execute unless data storage evercraft:forever_sack work.undo[0] run return run function evercraft:forever_sack/menu/msg_noundo

# Pull the most recent (last) entry into a working slot.
data modify storage evercraft:forever_sack uwork set from storage evercraft:forever_sack work.undo[-1]

# Clean the stashed item to a bare {id,count,components} stack.
data remove storage evercraft:forever_sack uwork.item.Slot
data remove storage evercraft:forever_sack uwork.item.slot

# Baúl undo: if we're putting back a Baúl and the off-hand currently holds the (regenerable, empty)
# Baúl left by the dissolve, clear that slot first so the FILLED Baúl returns straight to hand
# instead of dropping a second one at the feet.
execute if data storage evercraft:forever_sack uwork.item.components."minecraft:custom_data"{bulk_barrel:true} if items entity @s weapon.offhand *[custom_data~{bulk_barrel:true}] run item replace entity @s weapon.offhand with air

# Give the item back — off-hand if free, else drop at the player's feet (never lost).
scoreboard players set #fs_oh ec.temp 0
execute if items entity @s weapon.offhand * run scoreboard players set #fs_oh ec.temp 1
summon hopper_minecart ~ 320 ~ {Tags:["ec.fsack_ucart"],Enabled:0b,Items:[{Slot:0b,id:"minecraft:stone",count:1}]}
data modify entity @e[type=hopper_minecart,tag=ec.fsack_ucart,limit=1] Items[0] merge from storage evercraft:forever_sack uwork.item
execute if score #fs_oh ec.temp matches 0 run item replace entity @s weapon.offhand from entity @e[type=hopper_minecart,tag=ec.fsack_ucart,limit=1] container.0
execute if score #fs_oh ec.temp matches 1 at @s run summon item ~ ~0.5 ~ {Tags:["ec.fsack_udrop"],PickupDelay:0s}
execute if score #fs_oh ec.temp matches 1 run data modify entity @e[type=item,tag=ec.fsack_udrop,limit=1] Item set from storage evercraft:forever_sack uwork.item
execute if score #fs_oh ec.temp matches 1 run tag @e[type=item,tag=ec.fsack_udrop] remove ec.fsack_udrop
# Empty the cart before killing it — it still holds a copy (item replace COPIES), and a killed
# hopper-minecart drops its contents, which would duplicate the returned item.
data modify entity @e[type=hopper_minecart,tag=ec.fsack_ucart,limit=1] Items set value []
kill @e[type=hopper_minecart,tag=ec.fsack_ucart]

# Refund the dust / items / peak exactly from the popped entry.
execute store result score #fs_ud ec.temp run data get storage evercraft:forever_sack uwork.dust
execute store result score #fs_ui ec.temp run data get storage evercraft:forever_sack uwork.items
scoreboard players operation @s ec.fsack_dust -= #fs_ud ec.temp
execute if score @s ec.fsack_dust matches ..-1 run scoreboard players set @s ec.fsack_dust 0
scoreboard players operation @s ec.fsack_items -= #fs_ui ec.temp
execute if score @s ec.fsack_items matches ..-1 run scoreboard players set @s ec.fsack_items 0
execute store result score @s ec.fsack_peak run data get storage evercraft:forever_sack uwork.peak

# Pop it off the real stack.
function evercraft:forever_sack/undo_pop with storage evercraft:forever_sack k

data modify storage evercraft:notify stage.c set value [{text:"❖ ",color:"#B98BD9"},{text:"Returned — the dust gives it back.",color:"#7FDB6B"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.6 1.4

function evercraft:forever_sack/refresh_lore
function evercraft:forever_sack/menu/refresh
