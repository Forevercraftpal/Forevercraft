# Forever Sack — refuse to dissolve the Sack itself.
data modify storage evercraft:notify stage.c set value [{text:"❖ ",color:"#B98BD9"},{text:"That's the Sack itself — put the ",color:"gray"},{text:"Sack in your main hand",color:"white"},{text:" and the trash in your off-hand.",color:"gray"}]
scoreboard players set #ndur ec.temp 50
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 0.6 0.6
