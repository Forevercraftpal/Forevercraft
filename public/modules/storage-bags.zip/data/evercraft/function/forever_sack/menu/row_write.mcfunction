# Forever Sack Menu — macro: write one whitelist row's text. Args: sid, row, id.
# Name resolution: a vanilla item's display-name translation key is "block.minecraft.<path>" for
# BLOCK items but "item.minecraft.<path>" for everything else (sticks, bones, ingots, gunpowder…).
# The old single "block.minecraft." key only resolved blocks; non-block items fell back to the raw
# id. Render BOTH keys with EMPTY fallbacks: each vanilla id resolves under exactly one prefix, so
# the matching one prints the name and the other prints nothing — clean names for blocks AND items.
$execute if data storage evercraft:forever_sack rr{id:""} run data modify entity @e[type=text_display,tag=ec.fsack_row$(row)_txt,scores={adv.gui_session=$(sid)},limit=1] text set value [{"text":"—","color":"dark_gray"}]
$execute unless data storage evercraft:forever_sack rr{id:""} run data modify entity @e[type=text_display,tag=ec.fsack_row$(row)_txt,scores={adv.gui_session=$(sid)},limit=1] text set value [{"translate":"block.minecraft.$(path)","fallback":"","color":"#D8C28A"},{"translate":"item.minecraft.$(path)","fallback":"","color":"#D8C28A"},{"text":"   ✕","color":"#A85B5B"}]
