# Forever Sack Menu — macro: write live values onto this session's text displays.
# Args: bar, pct, dust, tname, tcolor, ulabel, ucolor, sid, pcur, pages.
$data modify entity @e[type=text_display,tag=ec.fsack_page_txt,scores={adv.gui_session=$(sid)},limit=1] text set value [{"text":"Page $(pcur)/$(pages)","color":"gray"}]
$data modify entity @e[type=text_display,tag=ec.fsack_bar_txt,scores={adv.gui_session=$(sid)},limit=1] text set value [{"text":"$(bar) $(pct)%","color":"#E8C66B"}]
$data modify entity @e[type=text_display,tag=ec.fsack_dust_txt,scores={adv.gui_session=$(sid)},limit=1] text set value [{"text":"Forever Dust: ","color":"gray"},{"text":"$(dust)","color":"#E8C66B"},{"text":" / 13824","color":"dark_gray"}]
$data modify entity @e[type=text_display,tag=ec.fsack_crate_txt,scores={adv.gui_session=$(sid)},limit=1] text set value [{"text":"Next Crate: ","color":"gray"},{"text":"$(tname)","color":"$(tcolor)"}]
$data modify entity @e[type=text_display,tag=ec.fsack_undo_txt,scores={adv.gui_session=$(sid)},limit=1] text set value [{"text":"[ ","color":"dark_gray"},{"text":"$(ulabel)","color":"$(ucolor)","bold":true},{"text":" ]","color":"dark_gray"}]
