# Forever Sack — Baúl is empty: nothing to dissolve (the Baúl itself is never destroyed).
data modify storage evercraft:notify stage.c set value [{text:"❖ ",color:"#B98BD9"},{text:"This Baúl is empty — ",color:"gray"},{text:"fill it",color:"white"},{text:" before dissolving its contents.",color:"gray"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 0.6 0.7
