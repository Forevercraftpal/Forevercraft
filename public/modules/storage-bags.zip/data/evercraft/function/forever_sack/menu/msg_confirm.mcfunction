# Forever Sack — rarity-item confirm prompt (macro; armed ~2s). Arg: gain.
$data modify storage evercraft:notify stage.c set value [{"text":"⚠ ","color":"#E8C66B"},{"text":"This carries rarity. Click ","color":"#D8C28A"},{"text":"Dissolve again","color":"#E8C66B","bold":true},{"text":" to commit it for ","color":"#D8C28A"},{"text":"$(gain)","color":"#E8C66B"},{"text":" dust.","color":"#D8C28A"}]
scoreboard players set #ndur ec.temp 50
function evercraft:util/notify/emit_crit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.pling master @s ~ ~ ~ 0.7 1.3
