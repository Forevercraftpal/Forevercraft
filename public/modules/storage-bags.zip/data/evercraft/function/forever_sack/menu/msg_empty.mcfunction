# Forever Sack — off-hand empty nudge.
data modify storage evercraft:notify stage.c set value [{text:"❖ ",color:"#B98BD9"},{text:"Hold the stack you want to dissolve in your ",color:"gray"},{text:"off-hand",color:"white"},{text:" first.",color:"gray"}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 0.6 0.7
