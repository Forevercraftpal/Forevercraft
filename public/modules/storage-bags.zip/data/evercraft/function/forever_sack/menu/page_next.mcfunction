# Forever Sack Menu — next whitelist page (refresh clamps to last page).
scoreboard players add @s ec.fsack_page 1
function evercraft:forever_sack/menu/refresh
