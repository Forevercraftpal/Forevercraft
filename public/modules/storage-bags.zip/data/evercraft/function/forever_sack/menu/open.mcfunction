# Forever Sack Menu — Open. Run AS the player, AT their position.
# Readout + the learned whitelist (click a row to PRESERVE it) + Dissolve / Sweep / Undo.

# One-menu-at-a-time (2026-06-15): close any other open menu before this one claims
# ec.menu_active. Two overlapping menus share the @s adv.gui_session slot; the newer
# open orphans the older menu's session, so it can never consume its click -> stuck
# interaction NBT -> click-sound spam. force_close is idempotent (no-op when nothing open).
execute if entity @s[tag=ec.menu_active] run function evercraft:menu_core/force_close
tag @s add ec.menu_active
execute store result score @s ec.menu_open_y run data get entity @s Pos[1] 100

execute at @s run kill @e[type=text_display,tag=ec.fsack_el,distance=..6]
execute at @s run kill @e[type=interaction,tag=ec.fsack_el,distance=..6]
execute at @s run kill @e[type=item_display,tag=ec.fsack_el,distance=..6]

tag @s add ec.fsack_in_menu
scoreboard players set @s ec.fsack_page 0

# Background panel.
execute at @s rotated ~ 0 positioned ^ ^1.95 ^1.82 run summon item_display ~ ~ ~ {Tags:["ec.fsack_el","ec.fsack_bg"],billboard:"center",item:{id:"gray_stained_glass_pane",count:1},item_display:"fixed",transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,-0.02f],scale:[2.7f,3.2f,0.01f]}}

# Owner header.
# 26.1: {selector:} renders blank in text_display — bake @s's name to a $(owner) literal.
function evercraft:util/gui/owner_name
execute at @s rotated ~ 0 positioned ^ ^3.16 ^1.78 run function evercraft:forever_sack/menu/open_nm with storage evercraft:scorebake args

# Title.
execute at @s rotated ~ 0 positioned ^ ^3.0 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["ec.fsack_el"],billboard:"center",text:[{text:"❖ ",color:"#B98BD9"},{text:"Forever Sack",color:"#E8C66B",bold:true},{text:" ❖",color:"#B98BD9"}],background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.46f,0.46f,0.46f]}}

# Readout (placeholders -> menu/refresh fills live).
execute at @s rotated ~ 0 positioned ^ ^2.74 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["ec.fsack_el","ec.fsack_bar_txt"],billboard:"center",text:[{text:"…",color:"#E8C66B"}],background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.36f,0.36f,0.36f]}}
execute at @s rotated ~ 0 positioned ^ ^2.60 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["ec.fsack_el","ec.fsack_dust_txt"],billboard:"center",text:[{text:"…",color:"gray"}],background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.3f,0.3f,0.3f]}}
execute at @s rotated ~ 0 positioned ^ ^2.47 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["ec.fsack_el","ec.fsack_crate_txt"],billboard:"center",text:[{text:"…",color:"gray"}],background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.3f,0.3f,0.3f]}}

# Whitelist header.
execute at @s rotated ~ 0 positioned ^ ^2.28 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["ec.fsack_el"],billboard:"center",text:[{text:"Whitelist — click to preserve",color:"#9BB3C9",italic:true}],background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.27f,0.27f,0.27f]}}

# 5 whitelist rows (text + click-to-remove interaction).
execute at @s rotated ~ 0 positioned ^ ^2.12 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["ec.fsack_el","ec.fsack_row0_txt"],billboard:"center",text:[{text:"—",color:"dark_gray"}],background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.32f,0.32f,0.32f]}}
execute at @s rotated ~ 0 positioned ^0.36 ^2.065 ^1.80 run summon interaction ~ ~ ~ {Tags:["ec.fsack_el","ec.fsack_row0"],width:0.12f,height:0.11f,response:1b}
execute at @s rotated ~ 0 positioned ^0.24 ^2.065 ^1.80 run summon interaction ~ ~ ~ {Tags:["ec.fsack_el","ec.fsack_row0"],width:0.12f,height:0.11f,response:1b}
execute at @s rotated ~ 0 positioned ^0.12 ^2.065 ^1.80 run summon interaction ~ ~ ~ {Tags:["ec.fsack_el","ec.fsack_row0"],width:0.12f,height:0.11f,response:1b}
execute at @s rotated ~ 0 positioned ^0 ^2.065 ^1.80 run summon interaction ~ ~ ~ {Tags:["ec.fsack_el","ec.fsack_row0"],width:0.12f,height:0.11f,response:1b}
execute at @s rotated ~ 0 positioned ^-0.12 ^2.065 ^1.80 run summon interaction ~ ~ ~ {Tags:["ec.fsack_el","ec.fsack_row0"],width:0.12f,height:0.11f,response:1b}
execute at @s rotated ~ 0 positioned ^-0.24 ^2.065 ^1.80 run summon interaction ~ ~ ~ {Tags:["ec.fsack_el","ec.fsack_row0"],width:0.12f,height:0.11f,response:1b}
execute at @s rotated ~ 0 positioned ^-0.36 ^2.065 ^1.80 run summon interaction ~ ~ ~ {Tags:["ec.fsack_el","ec.fsack_row0"],width:0.12f,height:0.11f,response:1b}
execute at @s rotated ~ 0 positioned ^ ^1.98 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["ec.fsack_el","ec.fsack_row1_txt"],billboard:"center",text:[{text:"—",color:"dark_gray"}],background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.32f,0.32f,0.32f]}}
execute at @s rotated ~ 0 positioned ^0.36 ^1.925 ^1.80 run summon interaction ~ ~ ~ {Tags:["ec.fsack_el","ec.fsack_row1"],width:0.12f,height:0.11f,response:1b}
execute at @s rotated ~ 0 positioned ^0.24 ^1.925 ^1.80 run summon interaction ~ ~ ~ {Tags:["ec.fsack_el","ec.fsack_row1"],width:0.12f,height:0.11f,response:1b}
execute at @s rotated ~ 0 positioned ^0.12 ^1.925 ^1.80 run summon interaction ~ ~ ~ {Tags:["ec.fsack_el","ec.fsack_row1"],width:0.12f,height:0.11f,response:1b}
execute at @s rotated ~ 0 positioned ^0 ^1.925 ^1.80 run summon interaction ~ ~ ~ {Tags:["ec.fsack_el","ec.fsack_row1"],width:0.12f,height:0.11f,response:1b}
execute at @s rotated ~ 0 positioned ^-0.12 ^1.925 ^1.80 run summon interaction ~ ~ ~ {Tags:["ec.fsack_el","ec.fsack_row1"],width:0.12f,height:0.11f,response:1b}
execute at @s rotated ~ 0 positioned ^-0.24 ^1.925 ^1.80 run summon interaction ~ ~ ~ {Tags:["ec.fsack_el","ec.fsack_row1"],width:0.12f,height:0.11f,response:1b}
execute at @s rotated ~ 0 positioned ^-0.36 ^1.925 ^1.80 run summon interaction ~ ~ ~ {Tags:["ec.fsack_el","ec.fsack_row1"],width:0.12f,height:0.11f,response:1b}
execute at @s rotated ~ 0 positioned ^ ^1.84 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["ec.fsack_el","ec.fsack_row2_txt"],billboard:"center",text:[{text:"—",color:"dark_gray"}],background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.32f,0.32f,0.32f]}}
execute at @s rotated ~ 0 positioned ^0.36 ^1.785 ^1.80 run summon interaction ~ ~ ~ {Tags:["ec.fsack_el","ec.fsack_row2"],width:0.12f,height:0.11f,response:1b}
execute at @s rotated ~ 0 positioned ^0.24 ^1.785 ^1.80 run summon interaction ~ ~ ~ {Tags:["ec.fsack_el","ec.fsack_row2"],width:0.12f,height:0.11f,response:1b}
execute at @s rotated ~ 0 positioned ^0.12 ^1.785 ^1.80 run summon interaction ~ ~ ~ {Tags:["ec.fsack_el","ec.fsack_row2"],width:0.12f,height:0.11f,response:1b}
execute at @s rotated ~ 0 positioned ^0 ^1.785 ^1.80 run summon interaction ~ ~ ~ {Tags:["ec.fsack_el","ec.fsack_row2"],width:0.12f,height:0.11f,response:1b}
execute at @s rotated ~ 0 positioned ^-0.12 ^1.785 ^1.80 run summon interaction ~ ~ ~ {Tags:["ec.fsack_el","ec.fsack_row2"],width:0.12f,height:0.11f,response:1b}
execute at @s rotated ~ 0 positioned ^-0.24 ^1.785 ^1.80 run summon interaction ~ ~ ~ {Tags:["ec.fsack_el","ec.fsack_row2"],width:0.12f,height:0.11f,response:1b}
execute at @s rotated ~ 0 positioned ^-0.36 ^1.785 ^1.80 run summon interaction ~ ~ ~ {Tags:["ec.fsack_el","ec.fsack_row2"],width:0.12f,height:0.11f,response:1b}
execute at @s rotated ~ 0 positioned ^ ^1.70 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["ec.fsack_el","ec.fsack_row3_txt"],billboard:"center",text:[{text:"—",color:"dark_gray"}],background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.32f,0.32f,0.32f]}}
execute at @s rotated ~ 0 positioned ^0.36 ^1.645 ^1.80 run summon interaction ~ ~ ~ {Tags:["ec.fsack_el","ec.fsack_row3"],width:0.12f,height:0.11f,response:1b}
execute at @s rotated ~ 0 positioned ^0.24 ^1.645 ^1.80 run summon interaction ~ ~ ~ {Tags:["ec.fsack_el","ec.fsack_row3"],width:0.12f,height:0.11f,response:1b}
execute at @s rotated ~ 0 positioned ^0.12 ^1.645 ^1.80 run summon interaction ~ ~ ~ {Tags:["ec.fsack_el","ec.fsack_row3"],width:0.12f,height:0.11f,response:1b}
execute at @s rotated ~ 0 positioned ^0 ^1.645 ^1.80 run summon interaction ~ ~ ~ {Tags:["ec.fsack_el","ec.fsack_row3"],width:0.12f,height:0.11f,response:1b}
execute at @s rotated ~ 0 positioned ^-0.12 ^1.645 ^1.80 run summon interaction ~ ~ ~ {Tags:["ec.fsack_el","ec.fsack_row3"],width:0.12f,height:0.11f,response:1b}
execute at @s rotated ~ 0 positioned ^-0.24 ^1.645 ^1.80 run summon interaction ~ ~ ~ {Tags:["ec.fsack_el","ec.fsack_row3"],width:0.12f,height:0.11f,response:1b}
execute at @s rotated ~ 0 positioned ^-0.36 ^1.645 ^1.80 run summon interaction ~ ~ ~ {Tags:["ec.fsack_el","ec.fsack_row3"],width:0.12f,height:0.11f,response:1b}
execute at @s rotated ~ 0 positioned ^ ^1.56 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["ec.fsack_el","ec.fsack_row4_txt"],billboard:"center",text:[{text:"—",color:"dark_gray"}],background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.32f,0.32f,0.32f]}}
execute at @s rotated ~ 0 positioned ^0.36 ^1.505 ^1.80 run summon interaction ~ ~ ~ {Tags:["ec.fsack_el","ec.fsack_row4"],width:0.12f,height:0.11f,response:1b}
execute at @s rotated ~ 0 positioned ^0.24 ^1.505 ^1.80 run summon interaction ~ ~ ~ {Tags:["ec.fsack_el","ec.fsack_row4"],width:0.12f,height:0.11f,response:1b}
execute at @s rotated ~ 0 positioned ^0.12 ^1.505 ^1.80 run summon interaction ~ ~ ~ {Tags:["ec.fsack_el","ec.fsack_row4"],width:0.12f,height:0.11f,response:1b}
execute at @s rotated ~ 0 positioned ^0 ^1.505 ^1.80 run summon interaction ~ ~ ~ {Tags:["ec.fsack_el","ec.fsack_row4"],width:0.12f,height:0.11f,response:1b}
execute at @s rotated ~ 0 positioned ^-0.12 ^1.505 ^1.80 run summon interaction ~ ~ ~ {Tags:["ec.fsack_el","ec.fsack_row4"],width:0.12f,height:0.11f,response:1b}
execute at @s rotated ~ 0 positioned ^-0.24 ^1.505 ^1.80 run summon interaction ~ ~ ~ {Tags:["ec.fsack_el","ec.fsack_row4"],width:0.12f,height:0.11f,response:1b}
execute at @s rotated ~ 0 positioned ^-0.36 ^1.505 ^1.80 run summon interaction ~ ~ ~ {Tags:["ec.fsack_el","ec.fsack_row4"],width:0.12f,height:0.11f,response:1b}

# Page line + [<] [>] (^+x = screen LEFT, so prev=+x / next=-x).
execute at @s rotated ~ 0 positioned ^ ^1.40 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["ec.fsack_el","ec.fsack_page_txt"],billboard:"center",text:[{text:"Page 1/1",color:"gray"}],background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.28f,0.28f,0.28f]}}
execute at @s rotated ~ 0 positioned ^0.45 ^1.40 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["ec.fsack_el","ec.fsack_prev_txt"],billboard:"center",text:[{text:"[<]",color:"#C9B36B",bold:true}],background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.34f,0.34f,0.34f]}}
execute at @s rotated ~ 0 positioned ^0.57 ^1.345 ^1.80 run summon interaction ~ ~ ~ {Tags:["ec.fsack_el","ec.fsack_prev_btn"],width:0.12f,height:0.11f,response:1b}
execute at @s rotated ~ 0 positioned ^0.45 ^1.345 ^1.80 run summon interaction ~ ~ ~ {Tags:["ec.fsack_el","ec.fsack_prev_btn"],width:0.12f,height:0.11f,response:1b}
execute at @s rotated ~ 0 positioned ^0.33 ^1.345 ^1.80 run summon interaction ~ ~ ~ {Tags:["ec.fsack_el","ec.fsack_prev_btn"],width:0.12f,height:0.11f,response:1b}
execute at @s rotated ~ 0 positioned ^-0.45 ^1.40 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["ec.fsack_el","ec.fsack_next_txt"],billboard:"center",text:[{text:"[>]",color:"#C9B36B",bold:true}],background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.34f,0.34f,0.34f]}}
execute at @s rotated ~ 0 positioned ^-0.33 ^1.345 ^1.80 run summon interaction ~ ~ ~ {Tags:["ec.fsack_el","ec.fsack_next_btn"],width:0.12f,height:0.11f,response:1b}
execute at @s rotated ~ 0 positioned ^-0.45 ^1.345 ^1.80 run summon interaction ~ ~ ~ {Tags:["ec.fsack_el","ec.fsack_next_btn"],width:0.12f,height:0.11f,response:1b}
execute at @s rotated ~ 0 positioned ^-0.57 ^1.345 ^1.80 run summon interaction ~ ~ ~ {Tags:["ec.fsack_el","ec.fsack_next_btn"],width:0.12f,height:0.11f,response:1b}

# [Dissolve Off-Hand]
execute at @s rotated ~ 0 positioned ^ ^1.20 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["ec.fsack_el","ec.fsack_diss_txt"],billboard:"center",text:[{text:"[ ",color:"dark_gray"},{text:"Dissolve Off-Hand",color:"#E8C66B",bold:true},{text:" ]",color:"dark_gray"}],background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.37f,0.37f,0.37f]}}
execute at @s rotated ~ 0 positioned ^0.48 ^1.145 ^1.80 run summon interaction ~ ~ ~ {Tags:["ec.fsack_el","ec.fsack_diss_btn"],width:0.12f,height:0.11f,response:1b}
execute at @s rotated ~ 0 positioned ^0.36 ^1.145 ^1.80 run summon interaction ~ ~ ~ {Tags:["ec.fsack_el","ec.fsack_diss_btn"],width:0.12f,height:0.11f,response:1b}
execute at @s rotated ~ 0 positioned ^0.24 ^1.145 ^1.80 run summon interaction ~ ~ ~ {Tags:["ec.fsack_el","ec.fsack_diss_btn"],width:0.12f,height:0.11f,response:1b}
execute at @s rotated ~ 0 positioned ^0.12 ^1.145 ^1.80 run summon interaction ~ ~ ~ {Tags:["ec.fsack_el","ec.fsack_diss_btn"],width:0.12f,height:0.11f,response:1b}
execute at @s rotated ~ 0 positioned ^0 ^1.145 ^1.80 run summon interaction ~ ~ ~ {Tags:["ec.fsack_el","ec.fsack_diss_btn"],width:0.12f,height:0.11f,response:1b}
execute at @s rotated ~ 0 positioned ^-0.12 ^1.145 ^1.80 run summon interaction ~ ~ ~ {Tags:["ec.fsack_el","ec.fsack_diss_btn"],width:0.12f,height:0.11f,response:1b}
execute at @s rotated ~ 0 positioned ^-0.24 ^1.145 ^1.80 run summon interaction ~ ~ ~ {Tags:["ec.fsack_el","ec.fsack_diss_btn"],width:0.12f,height:0.11f,response:1b}
execute at @s rotated ~ 0 positioned ^-0.36 ^1.145 ^1.80 run summon interaction ~ ~ ~ {Tags:["ec.fsack_el","ec.fsack_diss_btn"],width:0.12f,height:0.11f,response:1b}
execute at @s rotated ~ 0 positioned ^-0.48 ^1.145 ^1.80 run summon interaction ~ ~ ~ {Tags:["ec.fsack_el","ec.fsack_diss_btn"],width:0.12f,height:0.11f,response:1b}

# [Sweep Now]
execute at @s rotated ~ 0 positioned ^ ^1.02 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["ec.fsack_el","ec.fsack_sweep_txt"],billboard:"center",text:[{text:"[ ",color:"dark_gray"},{text:"Sweep Whitelist Now",color:"#7FB76B",bold:true},{text:" ]",color:"dark_gray"}],background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.37f,0.37f,0.37f]}}
execute at @s rotated ~ 0 positioned ^0.48 ^0.965 ^1.80 run summon interaction ~ ~ ~ {Tags:["ec.fsack_el","ec.fsack_sweep_btn"],width:0.12f,height:0.11f,response:1b}
execute at @s rotated ~ 0 positioned ^0.36 ^0.965 ^1.80 run summon interaction ~ ~ ~ {Tags:["ec.fsack_el","ec.fsack_sweep_btn"],width:0.12f,height:0.11f,response:1b}
execute at @s rotated ~ 0 positioned ^0.24 ^0.965 ^1.80 run summon interaction ~ ~ ~ {Tags:["ec.fsack_el","ec.fsack_sweep_btn"],width:0.12f,height:0.11f,response:1b}
execute at @s rotated ~ 0 positioned ^0.12 ^0.965 ^1.80 run summon interaction ~ ~ ~ {Tags:["ec.fsack_el","ec.fsack_sweep_btn"],width:0.12f,height:0.11f,response:1b}
execute at @s rotated ~ 0 positioned ^0 ^0.965 ^1.80 run summon interaction ~ ~ ~ {Tags:["ec.fsack_el","ec.fsack_sweep_btn"],width:0.12f,height:0.11f,response:1b}
execute at @s rotated ~ 0 positioned ^-0.12 ^0.965 ^1.80 run summon interaction ~ ~ ~ {Tags:["ec.fsack_el","ec.fsack_sweep_btn"],width:0.12f,height:0.11f,response:1b}
execute at @s rotated ~ 0 positioned ^-0.24 ^0.965 ^1.80 run summon interaction ~ ~ ~ {Tags:["ec.fsack_el","ec.fsack_sweep_btn"],width:0.12f,height:0.11f,response:1b}
execute at @s rotated ~ 0 positioned ^-0.36 ^0.965 ^1.80 run summon interaction ~ ~ ~ {Tags:["ec.fsack_el","ec.fsack_sweep_btn"],width:0.12f,height:0.11f,response:1b}
execute at @s rotated ~ 0 positioned ^-0.48 ^0.965 ^1.80 run summon interaction ~ ~ ~ {Tags:["ec.fsack_el","ec.fsack_sweep_btn"],width:0.12f,height:0.11f,response:1b}

# [Undo]
execute at @s rotated ~ 0 positioned ^ ^0.84 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["ec.fsack_el","ec.fsack_undo_txt"],billboard:"center",text:[{text:"[ ",color:"dark_gray"},{text:"Undo",color:"gray",bold:true},{text:" ]",color:"dark_gray"}],background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.33f,0.33f,0.33f]}}
execute at @s rotated ~ 0 positioned ^0.48 ^0.785 ^1.80 run summon interaction ~ ~ ~ {Tags:["ec.fsack_el","ec.fsack_undo_btn"],width:0.12f,height:0.11f,response:1b}
execute at @s rotated ~ 0 positioned ^0.36 ^0.785 ^1.80 run summon interaction ~ ~ ~ {Tags:["ec.fsack_el","ec.fsack_undo_btn"],width:0.12f,height:0.11f,response:1b}
execute at @s rotated ~ 0 positioned ^0.24 ^0.785 ^1.80 run summon interaction ~ ~ ~ {Tags:["ec.fsack_el","ec.fsack_undo_btn"],width:0.12f,height:0.11f,response:1b}
execute at @s rotated ~ 0 positioned ^0.12 ^0.785 ^1.80 run summon interaction ~ ~ ~ {Tags:["ec.fsack_el","ec.fsack_undo_btn"],width:0.12f,height:0.11f,response:1b}
execute at @s rotated ~ 0 positioned ^0 ^0.785 ^1.80 run summon interaction ~ ~ ~ {Tags:["ec.fsack_el","ec.fsack_undo_btn"],width:0.12f,height:0.11f,response:1b}
execute at @s rotated ~ 0 positioned ^-0.12 ^0.785 ^1.80 run summon interaction ~ ~ ~ {Tags:["ec.fsack_el","ec.fsack_undo_btn"],width:0.12f,height:0.11f,response:1b}
execute at @s rotated ~ 0 positioned ^-0.24 ^0.785 ^1.80 run summon interaction ~ ~ ~ {Tags:["ec.fsack_el","ec.fsack_undo_btn"],width:0.12f,height:0.11f,response:1b}
execute at @s rotated ~ 0 positioned ^-0.36 ^0.785 ^1.80 run summon interaction ~ ~ ~ {Tags:["ec.fsack_el","ec.fsack_undo_btn"],width:0.12f,height:0.11f,response:1b}
execute at @s rotated ~ 0 positioned ^-0.48 ^0.785 ^1.80 run summon interaction ~ ~ ~ {Tags:["ec.fsack_el","ec.fsack_undo_btn"],width:0.12f,height:0.11f,response:1b}

# [Close]
execute at @s rotated ~ 0 positioned ^ ^0.68 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["ec.fsack_el","ec.fsack_close_txt"],billboard:"center",text:[{text:"[ ",color:"dark_gray"},{text:"Close",color:"gray",bold:true},{text:" ]",color:"dark_gray"}],background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.33f,0.33f,0.33f]}}
execute at @s rotated ~ 0 positioned ^0.12 ^0.625 ^1.80 run summon interaction ~ ~ ~ {Tags:["ec.fsack_el","ec.fsack_close_btn"],width:0.12f,height:0.11f,response:1b}
execute at @s rotated ~ 0 positioned ^0 ^0.625 ^1.80 run summon interaction ~ ~ ~ {Tags:["ec.fsack_el","ec.fsack_close_btn"],width:0.12f,height:0.11f,response:1b}
execute at @s rotated ~ 0 positioned ^-0.12 ^0.625 ^1.80 run summon interaction ~ ~ ~ {Tags:["ec.fsack_el","ec.fsack_close_btn"],width:0.12f,height:0.11f,response:1b}

# Session isolation.
scoreboard players add #gui_session ec.var 1
scoreboard players operation @s adv.gui_session = #gui_session ec.var
scoreboard players operation #gui_stamp ec.temp = @s adv.gui_session
execute as @e[type=text_display,tag=ec.fsack_el,distance=..6] unless score @s adv.gui_session matches 1.. run scoreboard players operation @s adv.gui_session = #gui_stamp ec.temp
execute as @e[type=item_display,tag=ec.fsack_el,distance=..6] unless score @s adv.gui_session matches 1.. run scoreboard players operation @s adv.gui_session = #gui_stamp ec.temp
execute as @e[type=interaction,tag=ec.fsack_el,distance=..6] unless score @s adv.gui_session matches 1.. run scoreboard players operation @s adv.gui_session = #gui_stamp ec.temp

function evercraft:forever_sack/menu/refresh
# Open-grace: swallow clicks for the first ~6 ticks so the held opening right-click can't
# phantom-click a button (was opening the menu already advanced to page 2).
scoreboard players set @s ec.fsack_ocd 3
schedule function evercraft:forever_sack/menu_tick 2t replace
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.5 1.2

# First time opened: explain the Sack's abilities in chat (once).
execute unless score @s ec.fsack_seen matches 1 run function evercraft:forever_sack/intro
