# Forever Sack Menu — dissolve a Baúl's STORED CONTENTS into Forever Dust, keeping the (now-empty) Baúl.
# A Baúl (bulk_barrel) is a container, never junk: a filled one carries its stock smuggled in a
# minecraft:container slot-0 marker (custom_data.bb_saved = {count, item}, see bulk_barrel/encode_break).
# We read that payload, credit count × per-item value (same bands as a raw stack), whitelist the type,
# stash an Undo (restoring the ORIGINAL filled Baúl), then swap the off-hand to the EMPTY Baúl item.
# Contents are always plain blocks (bulk barrels reject components) -> value bands, never a rarity confirm.
# Run AS the menu owner, AT their position.

# Snapshot the off-hand Baúl into a cart so we can read its smuggled contents (non-destructive copy).
summon hopper_minecart ~ 320 ~ {Tags:["ec.fsack_bcart"],Enabled:0b,Items:[{Slot:0b,id:"minecraft:stone",count:1}]}
item replace entity @e[type=hopper_minecart,tag=ec.fsack_bcart,limit=1] container.0 from entity @s weapon.offhand
data modify storage evercraft:forever_sack bcur set from entity @e[type=hopper_minecart,tag=ec.fsack_bcart,limit=1] Items[0]
# Empty the cart BEFORE killing it — a killed hopper-minecart drops its contents (would rain the Baúl back).
data modify entity @e[type=hopper_minecart,tag=ec.fsack_bcart,limit=1] Items set value []
kill @e[type=hopper_minecart,tag=ec.fsack_bcart]

# Read the smuggled payload ({count, item}). No payload = an EMPTY Baúl -> nothing to dissolve (kept intact).
data remove storage evercraft:forever_sack bsave
execute if data storage evercraft:forever_sack bcur.components."minecraft:container"[0].item.components."minecraft:custom_data".bb_saved run data modify storage evercraft:forever_sack bsave set from storage evercraft:forever_sack bcur.components."minecraft:container"[0].item.components."minecraft:custom_data".bb_saved
execute unless data storage evercraft:forever_sack bsave.count run return run function evercraft:forever_sack/menu/msg_baul_empty

# Count + per-item value (vitem = the stored block template).
scoreboard players set #fs_c ec.temp 0
execute store result score #fs_c ec.temp run data get storage evercraft:forever_sack bsave.count
data modify storage evercraft:forever_sack vitem set from storage evercraft:forever_sack bsave.item
function evercraft:forever_sack/value_lookup
scoreboard players operation #fs_gain ec.temp = #fs_dv ec.temp
scoreboard players operation #fs_gain ec.temp *= #fs_c ec.temp
execute store result storage evercraft:forever_sack msg.gain int 1 run scoreboard players get #fs_gain ec.temp
execute store result storage evercraft:forever_sack msg.items int 1 run scoreboard players get #fs_c ec.temp

# --- Stash Undo BEFORE banking (so undo_entry.peak is the pre-dissolve peak). Undo restores the
# ORIGINAL FILLED Baúl (bcur) intact, refunds the dust, and rewinds the peak. ---
data modify storage evercraft:forever_sack undo_entry set value {}
data modify storage evercraft:forever_sack undo_entry.item set from storage evercraft:forever_sack bcur
execute store result storage evercraft:forever_sack undo_entry.dust int 1 run scoreboard players get #fs_gain ec.temp
execute store result storage evercraft:forever_sack undo_entry.items int 1 run scoreboard players get #fs_c ec.temp
execute store result storage evercraft:forever_sack undo_entry.peak int 1 run scoreboard players get @s ec.fsack_peak
execute if score @s ec.fsack_id matches 1.. store result storage evercraft:forever_sack k.id int 1 run scoreboard players get @s ec.fsack_id
execute if score @s ec.fsack_id matches 1.. run function evercraft:forever_sack/undo_push with storage evercraft:forever_sack k

# Swap the off-hand to the EMPTY Baúl item — contents leave, the Baúl itself stays in hand.
loot replace entity @s weapon.offhand loot evercraft:bulk_barrel/item

# Bank it.
scoreboard players operation @s ec.fsack_dust += #fs_gain ec.temp
scoreboard players operation @s ec.fsack_items += #fs_c ec.temp
execute if score #fs_pkv ec.temp > @s ec.fsack_peak run scoreboard players operation @s ec.fsack_peak = #fs_pkv ec.temp
scoreboard players set @s ec.fsack_dcd 0

# Teach the bag: the content type joins the whitelist (contents are non-rarity blocks).
execute if score @s ec.fsack_id matches 1.. store result storage evercraft:forever_sack k.id int 1 run scoreboard players get @s ec.fsack_id
execute if score @s ec.fsack_id matches 1.. run data modify storage evercraft:forever_sack k.item set from storage evercraft:forever_sack bsave.item.id
execute if score @s ec.fsack_id matches 1.. run function evercraft:forever_sack/add_whitelist with storage evercraft:forever_sack k

# Feedback (baúl-flavored — the dust + count are baked so they survive the notify queue).
function evercraft:forever_sack/menu/msg_baul_dissolved with storage evercraft:forever_sack msg

function evercraft:forever_sack/refresh_lore
function evercraft:forever_sack/menu/refresh
execute if score @s ec.fsack_dust matches 13824.. run function evercraft:forever_sack/payout
