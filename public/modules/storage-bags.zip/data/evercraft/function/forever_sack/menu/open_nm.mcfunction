# Owner-name header row (macro). 26.1: {selector:} is blank in text_display, so the menu
# opener's profile name is staged to evercraft:scorebake args.owner by util/gui/owner_name
# and baked here as the frozen $(owner) literal. Inherits position/rotation from the call site.
$summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["ec.fsack_el"],billboard:"center",text:[{text:"⟨ ",color:"gray",italic:true},{text:"$(owner)",color:"gray",italic:true},{text:"'s Sack ⟩",color:"gray",italic:true}],background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.26f,0.26f,0.26f]}}
