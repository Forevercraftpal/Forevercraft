# Forever Sack Menu — macro: pull whitelist entry at idx into rr.id (stays "" if absent). Arg: idx.
$data modify storage evercraft:forever_sack rr.id set from storage evercraft:forever_sack work.wl[$(idx)].id
# Derive a clean display path by stripping the 10-char "minecraft:" namespace (e.g. "cobblestone").
# Whitelisted ids are always vanilla (custom/rarity items are never auto-listed), so the prefix is fixed.
data modify storage evercraft:forever_sack rr.path set value ""
execute unless data storage evercraft:forever_sack rr{id:""} run data modify storage evercraft:forever_sack rr.path set string storage evercraft:forever_sack rr.id 10
