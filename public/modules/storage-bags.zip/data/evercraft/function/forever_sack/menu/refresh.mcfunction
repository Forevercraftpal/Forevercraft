# Forever Sack Menu — refresh readout + whitelist rows + page indicator. Run AS the menu owner.
function evercraft:forever_sack/compute_ui

# Undo button label — reflects how many dissolves are still on the stack (cap 3).
execute store result storage evercraft:forever_sack k.id int 1 run scoreboard players get @s ec.fsack_id
function evercraft:forever_sack/copy_undo with storage evercraft:forever_sack k
scoreboard players set #fs_uc ec.temp 0
execute store result score #fs_uc ec.temp run data get storage evercraft:forever_sack work.undo
data modify storage evercraft:forever_sack ui.ulabel set value "Undo"
data modify storage evercraft:forever_sack ui.ucolor set value "dark_gray"
execute if score #fs_uc ec.temp matches 1 run data modify storage evercraft:forever_sack ui.ulabel set value "Undo last dissolve (1)"
execute if score #fs_uc ec.temp matches 2 run data modify storage evercraft:forever_sack ui.ulabel set value "Undo last dissolve (2)"
execute if score #fs_uc ec.temp matches 3.. run data modify storage evercraft:forever_sack ui.ulabel set value "Undo last dissolve (3)"
execute if score #fs_uc ec.temp matches 1.. run data modify storage evercraft:forever_sack ui.ucolor set value "#7FDB6B"

execute store result storage evercraft:forever_sack ui.sid int 1 run scoreboard players get @s adv.gui_session

# Pull this player's whitelist + compute paging (5 rows/page, >=1 page).
execute store result storage evercraft:forever_sack k.id int 1 run scoreboard players get @s ec.fsack_id
function evercraft:forever_sack/copy_wl with storage evercraft:forever_sack k
scoreboard players set #fs_total ec.temp 0
execute store result score #fs_total ec.temp run data get storage evercraft:forever_sack work.wl
scoreboard players set #fs_5 ec.temp 5
scoreboard players operation #fs_pages ec.temp = #fs_total ec.temp
scoreboard players add #fs_pages ec.temp 4
scoreboard players operation #fs_pages ec.temp /= #fs_5 ec.temp
execute if score #fs_pages ec.temp matches ..0 run scoreboard players set #fs_pages ec.temp 1
# Clamp current page into [0, pages-1].
execute if score @s ec.fsack_page matches ..-1 run scoreboard players set @s ec.fsack_page 0
scoreboard players operation #fs_maxpage ec.temp = #fs_pages ec.temp
scoreboard players remove #fs_maxpage ec.temp 1
execute if score @s ec.fsack_page > #fs_maxpage ec.temp run scoreboard players operation @s ec.fsack_page = #fs_maxpage ec.temp
scoreboard players operation #fs_cur ec.temp = @s ec.fsack_page
scoreboard players add #fs_cur ec.temp 1
execute store result storage evercraft:forever_sack ui.pcur int 1 run scoreboard players get #fs_cur ec.temp
execute store result storage evercraft:forever_sack ui.pages int 1 run scoreboard players get #fs_pages ec.temp

function evercraft:forever_sack/menu/refresh_apply with storage evercraft:forever_sack ui

# Render the 5 rows for the current page. base = page*5.
scoreboard players operation #fs_base ec.temp = @s ec.fsack_page
scoreboard players operation #fs_base ec.temp *= #fs_5 ec.temp

scoreboard players operation #fs_idx ec.temp = #fs_base ec.temp
execute store result storage evercraft:forever_sack rr.idx int 1 run scoreboard players get #fs_idx ec.temp
data modify storage evercraft:forever_sack rr.id set value ""
data modify storage evercraft:forever_sack rr.sid set from storage evercraft:forever_sack ui.sid
data modify storage evercraft:forever_sack rr.row set value 0
function evercraft:forever_sack/menu/row_pull with storage evercraft:forever_sack rr
function evercraft:forever_sack/menu/row_write with storage evercraft:forever_sack rr

scoreboard players operation #fs_idx ec.temp = #fs_base ec.temp
scoreboard players add #fs_idx ec.temp 1
execute store result storage evercraft:forever_sack rr.idx int 1 run scoreboard players get #fs_idx ec.temp
data modify storage evercraft:forever_sack rr.id set value ""
data modify storage evercraft:forever_sack rr.row set value 1
function evercraft:forever_sack/menu/row_pull with storage evercraft:forever_sack rr
function evercraft:forever_sack/menu/row_write with storage evercraft:forever_sack rr

scoreboard players operation #fs_idx ec.temp = #fs_base ec.temp
scoreboard players add #fs_idx ec.temp 2
execute store result storage evercraft:forever_sack rr.idx int 1 run scoreboard players get #fs_idx ec.temp
data modify storage evercraft:forever_sack rr.id set value ""
data modify storage evercraft:forever_sack rr.row set value 2
function evercraft:forever_sack/menu/row_pull with storage evercraft:forever_sack rr
function evercraft:forever_sack/menu/row_write with storage evercraft:forever_sack rr

scoreboard players operation #fs_idx ec.temp = #fs_base ec.temp
scoreboard players add #fs_idx ec.temp 3
execute store result storage evercraft:forever_sack rr.idx int 1 run scoreboard players get #fs_idx ec.temp
data modify storage evercraft:forever_sack rr.id set value ""
data modify storage evercraft:forever_sack rr.row set value 3
function evercraft:forever_sack/menu/row_pull with storage evercraft:forever_sack rr
function evercraft:forever_sack/menu/row_write with storage evercraft:forever_sack rr

scoreboard players operation #fs_idx ec.temp = #fs_base ec.temp
scoreboard players add #fs_idx ec.temp 4
execute store result storage evercraft:forever_sack rr.idx int 1 run scoreboard players get #fs_idx ec.temp
data modify storage evercraft:forever_sack rr.id set value ""
data modify storage evercraft:forever_sack rr.row set value 4
function evercraft:forever_sack/menu/row_pull with storage evercraft:forever_sack rr
function evercraft:forever_sack/menu/row_write with storage evercraft:forever_sack rr
