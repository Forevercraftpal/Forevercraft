# Forever Sack Menu — per-player click handling. Run AS the owner, AT their position.

# Auto-close if the player walked away from the panel.
execute unless entity @e[type=item_display,tag=ec.fsack_bg,distance=..5] run function evercraft:forever_sack/menu/close
execute unless entity @s[tag=ec.fsack_in_menu] run return 0

# Auto-close if the sack is no longer on the player.
execute unless items entity @s hotbar.* *[custom_data~{forever_sack:true}] unless items entity @s inventory.* *[custom_data~{forever_sack:true}] unless items entity @s weapon.offhand *[custom_data~{forever_sack:true}] run function evercraft:forever_sack/menu/close
execute unless entity @s[tag=ec.fsack_in_menu] run return 0

# Tick down the rarity-dissolve confirm window.
execute if score @s ec.fsack_dcd matches 1.. run scoreboard players remove @s ec.fsack_dcd 1

# Open-grace: for the first few ticks after opening, the held opening right-click can register
# on freshly-spawned buttons (the consumable keeps "using"). Decrement the window, scrub any
# pending clicks off every button, and skip dispatch — so the menu never "opens onto page 2".
execute if score @s ec.fsack_ocd matches 1.. run scoreboard players remove @s ec.fsack_ocd 1
execute if score @s ec.fsack_ocd matches 1.. at @s as @e[type=interaction,tag=ec.fsack_el,distance=..7] run data remove entity @s interaction
execute if score @s ec.fsack_ocd matches 1.. run return 0

# [Close] — processed BEFORE the click debounce below so a deliberate close press is NEVER swallowed.
# (When close landed inside the debounce window, its interaction got scrubbed and dispatch skipped, so
# menu/close never ran: the in_menu tag + open advancement stayed set and the menu was stuck "open"
# until you walked away — and the stuck advancement also blocked Sneak+RC from re-firing. Close kills
# the panel + drops the tag, so running it pre-debounce is idempotent and can't double-fire.)
scoreboard players operation #gui_owner ec.temp = @s adv.gui_session
execute as @e[type=interaction,tag=ec.fsack_close_btn,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction on target run function evercraft:forever_sack/menu/close
execute as @e[type=interaction,tag=ec.fsack_close_btn,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction
execute unless entity @s[tag=ec.fsack_in_menu] run return 0

# Click debounce: the Sack is a consumable, so HOLDING right-click re-fires the interaction
# under the crosshair EVERY tick — that's what made the page climb on any click and stole the
# dissolve click. While the debounce is active, scrub all pending clicks and skip dispatch;
# otherwise, if there's a fresh click this tick, arm it so the held press can't repeat.
execute if score @s ec.fsack_click_cd matches 1.. run scoreboard players remove @s ec.fsack_click_cd 1
execute if score @s ec.fsack_click_cd matches 1.. at @s as @e[type=interaction,tag=ec.fsack_el,distance=..7] run data remove entity @s interaction
execute if score @s ec.fsack_click_cd matches 1.. run return 0
execute if entity @e[type=interaction,tag=ec.fsack_el,distance=..6,nbt={interaction:{}},limit=1] run scoreboard players set @s ec.fsack_click_cd 4

scoreboard players operation #gui_owner ec.temp = @s adv.gui_session
execute if entity @e[type=interaction,tag=ec.fsack_el,distance=..6,nbt={interaction:{}},limit=1] run function evercraft:fx/ui/click
# ([Close] is handled earlier, before the debounce, so it can never be swallowed.)

# [Dissolve Off-Hand]
execute as @e[type=interaction,tag=ec.fsack_diss_btn,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction on target run function evercraft:forever_sack/menu/dissolve_offhand
execute as @e[type=interaction,tag=ec.fsack_diss_btn,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction

# [Sweep Whitelist Now]
execute as @e[type=interaction,tag=ec.fsack_sweep_btn,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction on target run function evercraft:forever_sack/bulk_eat
execute as @e[type=interaction,tag=ec.fsack_sweep_btn,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction

# [Undo]
execute as @e[type=interaction,tag=ec.fsack_undo_btn,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction on target run function evercraft:forever_sack/menu/undo
execute as @e[type=interaction,tag=ec.fsack_undo_btn,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction

# [<] / [>] paging
execute as @e[type=interaction,tag=ec.fsack_prev_btn,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction on target run function evercraft:forever_sack/menu/page_prev
execute as @e[type=interaction,tag=ec.fsack_prev_btn,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=ec.fsack_next_btn,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction on target run function evercraft:forever_sack/menu/page_next
execute as @e[type=interaction,tag=ec.fsack_next_btn,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction

# Whitelist rows — click to PRESERVE (remove from list).
execute as @e[type=interaction,tag=ec.fsack_row0,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction on target run function evercraft:forever_sack/menu/remove_row {row:0}
execute as @e[type=interaction,tag=ec.fsack_row0,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=ec.fsack_row1,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction on target run function evercraft:forever_sack/menu/remove_row {row:1}
execute as @e[type=interaction,tag=ec.fsack_row1,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=ec.fsack_row2,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction on target run function evercraft:forever_sack/menu/remove_row {row:2}
execute as @e[type=interaction,tag=ec.fsack_row2,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=ec.fsack_row3,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction on target run function evercraft:forever_sack/menu/remove_row {row:3}
execute as @e[type=interaction,tag=ec.fsack_row3,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=ec.fsack_row4,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction on target run function evercraft:forever_sack/menu/remove_row {row:4}
execute as @e[type=interaction,tag=ec.fsack_row4,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction

# Left-click inspect cards.
execute as @e[type=interaction,tag=ec.fsack_diss_btn,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Dissolve Off-Hand",b:"Dissolves the stack in your off-hand into Forever Dust and — if it's a plain item — teaches the bag to sweep that type. Rarity items need a confirm click and are never auto-listed."}
execute as @e[type=interaction,tag=ec.fsack_diss_btn,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=ec.fsack_sweep_btn,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Sweep Whitelist Now",b:"Eats every whitelisted item type from your whole inventory at once (same as Sneak + Right-Click). Custom/rarity items are skipped."}
execute as @e[type=interaction,tag=ec.fsack_sweep_btn,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=ec.fsack_undo_btn,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Undo",b:"Returns the last item you dissolved and refunds its dust."}
execute as @e[type=interaction,tag=ec.fsack_undo_btn,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack run data remove entity @s attack
