# Forever Sack — Baúl emptied feedback (macro). Args: gain, items.
$data modify storage evercraft:notify stage.c set value [{"text":"❖ ","color":"#B98BD9"},{"text":"Emptied the Baúl — ","color":"#D8C28A"},{"text":"$(items)","color":"#E8C66B"},{"text":" stored dissolved for ","color":"#D8C28A"},{"text":"$(gain)","color":"#E8C66B"},{"text":" Forever Dust.","color":"#D8C28A"}]
scoreboard players set #ndur ec.temp 50
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.barrel.close master @s ~ ~ ~ 0.6 1.0
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.amethyst_block.resonate master @s ~ ~ ~ 0.6 1.1
execute if score @s ec.fx_vis matches 1.. at @s run particle minecraft:witch ~ ~1 ~ 0.3 0.4 0.3 0.05 16
