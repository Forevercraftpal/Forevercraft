# Forever Sack Menu — Close. Kill this session's elements, clear state.
tag @s remove ec.menu_active
scoreboard players reset @s ec.menu_open_y

scoreboard players operation #gui_check ec.temp = @s adv.gui_session
execute as @e[type=text_display,tag=ec.fsack_el,distance=..6] if score @s adv.gui_session = #gui_check ec.temp run kill @s
execute as @e[type=interaction,tag=ec.fsack_el,distance=..6] if score @s adv.gui_session = #gui_check ec.temp run kill @s
execute as @e[type=item_display,tag=ec.fsack_el,distance=..6] if score @s adv.gui_session = #gui_check ec.temp run kill @s

tag @s remove ec.fsack_in_menu

# Reset only the transient dissolve-confirm window. The undo stack is NOT cleared here — it's
# per-player storage and deliberately survives closing the bag (remembers your last 3 dissolves).
scoreboard players set @s ec.fsack_dcd 0

# Refresh the held sack's lore on close — a guaranteed use-free moment (the consumable "use" that
# kept the bag in-hand has ended), so the item-replace in refresh_lore reliably takes and the dust
# readout on the item reflects everything dissolved this session. No-ops if the sack isn't in hand.
function evercraft:forever_sack/refresh_lore

# using_item leaves the open advancement GRANTED while held; revoke on close so the next
# right-click re-fires it and re-opens (the proven satchel pattern).
advancement revoke @s only evercraft:forever_sack/open
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.amethyst_block.break master @s ~ ~ ~ 0.4 1.0
