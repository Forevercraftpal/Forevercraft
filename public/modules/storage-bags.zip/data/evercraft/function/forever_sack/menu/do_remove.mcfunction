# Forever Sack Menu — macro: drop whitelist entry [idx] for player id (only if it exists). Args: id, idx.
$execute unless data storage evercraft:forever_sack work.wl[$(idx)] run return 0
$data remove storage evercraft:forever_sack lists.p$(id).wl[$(idx)]
data modify storage evercraft:notify stage.c set value [{"text":"❖ ","color":"#B98BD9"},{"text":"Preserved — it won't be swept anymore.","color":"#7FDB6B"}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.5 1.5
