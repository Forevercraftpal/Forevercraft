# Forever Sack Menu — previous whitelist page (refresh clamps to 0).
scoreboard players remove @s ec.fsack_page 1
function evercraft:forever_sack/menu/refresh
