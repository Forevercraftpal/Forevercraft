# Forever Sack — first-open primer (fires once). Run AS the player.
scoreboard players set @s ec.fsack_seen 1

tellraw @s ["",{"text":"━━━━━ ","color":"#6B5B8A"},{"text":"❖ Forever Sack ❖","color":"#E8C66B","bold":true},{"text":" ━━━━━","color":"#6B5B8A"}]
tellraw @s [{"text":"Your first ","color":"#B6A9C9"},{"text":"spirit vessel","color":"#B98BD9"},{"text":" — it turns what you cast off into ","color":"#B6A9C9"},{"text":"Forever Dust","color":"#E8C66B"},{"text":".","color":"#B6A9C9"}]
tellraw @s [{"text":"  ◆ ","color":"#6B5B8A"},{"text":"Dissolve","color":"#E8C66B"},{"text":" — hold trash in your off-hand and click ","color":"gray"},{"text":"[Dissolve Off-Hand]","color":"#E8C66B"},{"text":". The bag ","color":"gray"},{"text":"learns","color":"#7FB76B"},{"text":" that item type.","color":"gray"}]
tellraw @s [{"text":"  ◆ ","color":"#6B5B8A"},{"text":"Sweep","color":"#7FB76B"},{"text":" — ","color":"gray"},{"text":"Sneak + Right-Click","color":"white"},{"text":" devours every learned type from your whole inventory at once.","color":"gray"}]
tellraw @s [{"text":"  ◆ ","color":"#6B5B8A"},{"text":"Preserve","color":"#6BB7C9"},{"text":" — click any row in this menu to stop the bag eating that item.","color":"gray"}]
tellraw @s [{"text":"  ◆ ","color":"#6B5B8A"},{"text":"Valuables stay safe","color":"#C77FE8"},{"text":" — artifacts & rarities are never swept; dissolve them one at a time (with a confirm). ","color":"gray"},{"text":"Undo","color":"#7FDB6B"},{"text":" reverses your last dissolve.","color":"gray"}]
tellraw @s [{"text":"  ◆ ","color":"#6B5B8A"},{"text":"Fill it","color":"#E8C66B"},{"text":" to ","color":"gray"},{"text":"100%","color":"#E8C66B"},{"text":" and a ","color":"gray"},{"text":"structure crate","color":"#C77FE8"},{"text":" spills out — its tier set by the finest thing you fed it.","color":"gray"}]
tellraw @s [{"text":"Quality in, quality out.","color":"#9B8FB0","italic":true}]

execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.7 0.8
execute if score @s ec.fx_snd matches 2.. run playsound minecraft:block.amethyst_block.resonate master @s ~ ~ ~ 0.4 1.2
