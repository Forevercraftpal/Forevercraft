# Forever Sack — macro: add an item id to a player's whitelist (deduped). Args: id (player id), item (item id).
# Ensure the list EXISTS first: `data modify ... append` SILENTLY no-ops on a missing path, which is
# why dissolving banked dust but never taught the bag — the whitelist stayed empty so Sneak+RC had
# nothing to sweep. (init_list only runs from assign_id/give, which don't fire on a normal dissolve.)
$execute unless data storage evercraft:forever_sack lists.p$(id).wl run data modify storage evercraft:forever_sack lists.p$(id).wl set value []
$execute unless data storage evercraft:forever_sack lists.p$(id).wl[{id:"$(item)"}] run data modify storage evercraft:forever_sack lists.p$(id).wl append value {id:"$(item)"}
