# Forever Sack — GUI self-test (admin/debug). Run as: a player, e.g.
#   execute as <you> at @s run function evercraft:forever_sack/selftest
# Bypasses the right-click trigger and calls menu/open directly, then synchronously asserts
# the background panel entity actually spawned — an objective PASS/FAIL for "does the GUI
# render", separate from "does the trigger fire". The menu is left OPEN so you also see it.
tellraw @s [{text:"[FSack selftest] ","color":"gray"},{text:"opening menu directly…","color":"white"}]

# Clean slate so the open path can't be blocked by stale state.
execute unless score @s ec.fsack_id matches 1.. run function evercraft:forever_sack/assign_id
advancement revoke @s only evercraft:forever_sack/open
tag @s remove ec.fsack_in_menu

# menu/open summons its entities synchronously, so they exist immediately after this returns.
function evercraft:forever_sack/menu/open

execute at @s if entity @e[type=item_display,tag=ec.fsack_bg,distance=..6] run tellraw @s [{text:"[FSack selftest] ","color":"gray"},{text:"✓ PASS","color":"green","bold":true},{text:" — panel rendered. The GUI works; a right-click (or Sneak+RC sweep) will drive it.","color":"green"}]
execute at @s unless entity @e[type=item_display,tag=ec.fsack_bg,distance=..6] run tellraw @s [{text:"[FSack selftest] ","color":"gray"},{text:"✗ FAIL","color":"red","bold":true},{text:" — menu/open ran but spawned no panel. That's a rendering problem, not the trigger.","color":"red"}]
