# Forever Sack — assign a persistent per-player id (once) + ensure an empty whitelist exists.
# The whitelist lives at storage evercraft:forever_sack lists.p<id>.wl = [{id:"..."}, ...].
execute unless score @s ec.fsack_id matches 1.. run scoreboard players add #fsack_idctr ec.var 1
execute unless score @s ec.fsack_id matches 1.. run scoreboard players operation @s ec.fsack_id = #fsack_idctr ec.var
execute store result storage evercraft:forever_sack k.id int 1 run scoreboard players get @s ec.fsack_id
function evercraft:forever_sack/init_list with storage evercraft:forever_sack k
