# Forever Sack — macro: announce the payout crate. Args: disp, color.
title @s title [{"text":"❖ ","color":"#B98BD9"},{"text":"Forever Sack","color":"#E8C66B","bold":false}]
$title @s subtitle [{"text":"A ","color":"gray"},{"text":"$(disp)","color":"$(color)","bold":false},{"text":" crate tumbles free","color":"gray"}]
$data modify storage evercraft:notify stage.c set value [{"text":"❖ ","color":"#B98BD9"},{"text":"The Sack brims over — a ","color":"#D8C28A"},{"text":"$(disp) Crate","color":"$(color)","bold":true},{"text":" spills from the dust!","color":"#D8C28A"}]
scoreboard players set #ndur ec.temp 80
scoreboard players set #nprot ec.temp 1
function evercraft:util/notify/emit_crit
