# Forever Sack — nothing on the whitelist matched.
data modify storage evercraft:notify stage.c set value [{"text":"❖ ","color":"#B98BD9"},{"text":"Nothing on your whitelist to sweep — dissolve an item to teach the bag.","color":"gray"}]
scoreboard players set #ndur ec.temp 55
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 0.5 0.8
