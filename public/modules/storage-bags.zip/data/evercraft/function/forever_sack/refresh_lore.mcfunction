# Forever Sack — rebuild the held sack's lore from the player's fill scores. Run AS holder, AT them.
#
# MC 26.2 (1.21.5+): a player's inventory is READ-ONLY via `data modify entity @s Inventory[...]`,
# so the old in-place lore write SILENTLY no-op'd and the dust readout never changed. Use the proven
# weapon_mastery/write_back trick instead: pull the held sack into a hopper-minecart (a writable
# container), rewrite its lore there, then `item replace` it back into the hand (which also forces
# the client tooltip to refresh). Every refresh_lore caller holds the sack in the MAINHAND.
function evercraft:forever_sack/compute_ui
execute unless items entity @s weapon.mainhand *[custom_data~{forever_sack:true}] run return 0

# Fresh intermediary cart (clear + kill any stale one first so a prior failed write can't leak an item).
data modify entity @e[type=hopper_minecart,tag=ec.fsack_lcart,limit=1] Items set value []
kill @e[type=hopper_minecart,tag=ec.fsack_lcart]
execute at @s run summon hopper_minecart ~ 320 ~ {Tags:["ec.fsack_lcart"],Items:[]}
item replace entity @e[type=hopper_minecart,tag=ec.fsack_lcart,limit=1] container.0 from entity @s weapon.mainhand

# Stamp the computed lore onto the carted sack (macro bakes bar / pct / dust / crate tier).
function evercraft:forever_sack/refresh_lore_apply with storage evercraft:forever_sack ui
# Migration: strip any stale `tier:"mythical"` so an older sack stops reading as mythical combat gear
# to the mob-scaler. Targeted remove (no-op on new sacks, which no longer bake a tier). Cart NBT is writable.
data remove entity @e[type=hopper_minecart,tag=ec.fsack_lcart,limit=1] Items[0].components."minecraft:custom_data".tier

# Swap it back into the hand + clean up the cart (clear Items first so it can't drop them on kill).
item replace entity @s weapon.mainhand from entity @e[type=hopper_minecart,tag=ec.fsack_lcart,limit=1] container.0
data modify entity @e[type=hopper_minecart,tag=ec.fsack_lcart,limit=1] Items set value []
kill @e[type=hopper_minecart,tag=ec.fsack_lcart]
