# Forever Sack — recursively sweep each whitelisted id (work.wl[0]). Run AS the player.
execute unless data storage evercraft:forever_sack work.wl[0] run return 0
data modify storage evercraft:forever_sack k.id2 set from storage evercraft:forever_sack work.wl[0].id
function evercraft:forever_sack/sweep_one with storage evercraft:forever_sack k
data remove storage evercraft:forever_sack work.wl[0]
function evercraft:forever_sack/bulk_eat_next
