# Forever Sack — macro: set #fs_dup ec.temp 1 if artifact $(art) is already enshrined in the
# player's Codex Vault (the deposited advancement — the same flag the Gallery deposit grants).
# Unknown ids make the selector error → the function aborts → the flag stays 0 (caller-safe).
# Mirrors codex_vault/deposit/flag_already. Run as the player.
$execute if entity @s[advancements={evercraft:artifacts/deposited/$(art)=true}] run scoreboard players set #fs_dup ec.temp 1
