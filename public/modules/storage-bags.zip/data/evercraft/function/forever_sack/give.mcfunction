# Forever Sack — grant the item to @s (run AS the player, AT @s for the drop fallback).
# Inv-full guard: drop at the player's feet rather than void on a full inventory.
execute store result score #inv_full ec.var run function evercraft:util/check_inv_full
execute if score #inv_full ec.var matches 0 run loot give @s loot evercraft:forever_sack/forever_sack
execute if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:forever_sack/forever_sack

# Mark granted (one-time gate) + flag as a holder so the digest tick scans them.
scoreboard players set @s ec.fsack_granted 1
tag @s add ec.has_fsack

# Clear any transient menu state so a (re)grant always opens cleanly — a stale in-menu
# tag, opener-cooldown, or a stuck-granted open advancement (using_item stays granted
# while held) would otherwise swallow every right-click.
tag @s remove ec.fsack_in_menu
scoreboard players reset @s ec.fsack_use_cd
advancement revoke @s only evercraft:forever_sack/open

# Fresh fill state.
scoreboard players set @s ec.fsack_dust 0
scoreboard players set @s ec.fsack_peak 0
scoreboard players set @s ec.fsack_items 0

# Per-player id + empty whitelist (the bag learns your trash as you dissolve).
function evercraft:forever_sack/assign_id

# Fresh undo history (a regranted sack shouldn't undo a previous sack's dissolves after the reset).
execute store result storage evercraft:forever_sack k.id int 1 run scoreboard players get @s ec.fsack_id
function evercraft:forever_sack/clear_undo with storage evercraft:forever_sack k

# The "first spirit item" arrival beat — a protected, unhurried notify.
data modify storage evercraft:notify stage.c set value [{text:"❖ ",color:"#B98BD9"},{text:"A ",color:"#D8C28A"},{text:"Forever Sack",color:"#E8C66B",bold:true},{text:" settles into your pack — your first spirit vessel.",color:"#D8C28A"},{text:" ❖",color:"#B98BD9"}]
scoreboard players set #ndur ec.temp 90
scoreboard players set #nprot ec.temp 1
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.8 0.7
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 0.7 1.0
execute if score @s ec.fx_vis matches 1.. at @s run particle minecraft:witch ~ ~1 ~ 0.4 0.6 0.4 0.02 24
