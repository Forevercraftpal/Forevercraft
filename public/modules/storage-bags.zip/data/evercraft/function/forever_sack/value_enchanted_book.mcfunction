# Forever Sack — value an enchanted book by the enchantments it stores (the best one wins).
# Input: storage evercraft:forever_sack vitem. Output: #fs_dv ec.temp.
# 26.1 component form is the direct map: components."minecraft:stored_enchantments"."minecraft:<id>".
# A plain (no-enchant) book stays 16; premium combat/tool enchants 64; treasure enchants 256.
scoreboard players set #fs_dv ec.temp 16

# Premium enchants -> 64 (Rare)
execute if data storage evercraft:forever_sack vitem.components."minecraft:stored_enchantments"."minecraft:sharpness" run scoreboard players set #fs_dv ec.temp 64
execute if data storage evercraft:forever_sack vitem.components."minecraft:stored_enchantments"."minecraft:efficiency" run scoreboard players set #fs_dv ec.temp 64
execute if data storage evercraft:forever_sack vitem.components."minecraft:stored_enchantments"."minecraft:protection" run scoreboard players set #fs_dv ec.temp 64
execute if data storage evercraft:forever_sack vitem.components."minecraft:stored_enchantments"."minecraft:power" run scoreboard players set #fs_dv ec.temp 64
execute if data storage evercraft:forever_sack vitem.components."minecraft:stored_enchantments"."minecraft:fortune" run scoreboard players set #fs_dv ec.temp 64
execute if data storage evercraft:forever_sack vitem.components."minecraft:stored_enchantments"."minecraft:looting" run scoreboard players set #fs_dv ec.temp 64
execute if data storage evercraft:forever_sack vitem.components."minecraft:stored_enchantments"."minecraft:unbreaking" run scoreboard players set #fs_dv ec.temp 64
execute if data storage evercraft:forever_sack vitem.components."minecraft:stored_enchantments"."minecraft:depth_strider" run scoreboard players set #fs_dv ec.temp 64
execute if data storage evercraft:forever_sack vitem.components."minecraft:stored_enchantments"."minecraft:feather_falling" run scoreboard players set #fs_dv ec.temp 64
execute if data storage evercraft:forever_sack vitem.components."minecraft:stored_enchantments"."minecraft:riptide" run scoreboard players set #fs_dv ec.temp 64
execute if data storage evercraft:forever_sack vitem.components."minecraft:stored_enchantments"."minecraft:channeling" run scoreboard players set #fs_dv ec.temp 64

# Mending — the crown jewel -> 5000 dust (carries the top crate tier on its own).
execute if data storage evercraft:forever_sack vitem.components."minecraft:stored_enchantments"."minecraft:mending" run scoreboard players set #fs_dv ec.temp 5000
# Other treasure / top-tier enchants -> 256 (Ornate)
execute if data storage evercraft:forever_sack vitem.components."minecraft:stored_enchantments"."minecraft:silk_touch" run scoreboard players set #fs_dv ec.temp 256
execute if data storage evercraft:forever_sack vitem.components."minecraft:stored_enchantments"."minecraft:infinity" run scoreboard players set #fs_dv ec.temp 256
execute if data storage evercraft:forever_sack vitem.components."minecraft:stored_enchantments"."minecraft:soul_speed" run scoreboard players set #fs_dv ec.temp 256
execute if data storage evercraft:forever_sack vitem.components."minecraft:stored_enchantments"."minecraft:swift_sneak" run scoreboard players set #fs_dv ec.temp 256
