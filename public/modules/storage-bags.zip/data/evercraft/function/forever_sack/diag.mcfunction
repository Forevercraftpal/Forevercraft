# Forever Sack — (admin/debug) self-contained dissolve-commit test.
# Usage: execute as <you> at @s run function evercraft:forever_sack/diag
# WARNING: this OVERWRITES your off-hand with 16 cobblestone, then runs the real
# dissolve commit path directly (no menu) so we can see whether dust banks and the
# whitelist grows — isolating the COMMIT from the menu click/refresh layer.

tellraw @s [{text:"=== FSack diag ===",color:"aqua",bold:true}]

# Ensure this player has an id + whitelist (commit needs id>=1).
execute unless score @s ec.fsack_id matches 1.. run function evercraft:forever_sack/assign_id

tellraw @s [{text:"id=",color:"gray"},{score:{name:"@s",objective:"ec.fsack_id"},color:"yellow"},{text:"   dust(before)=",color:"gray"},{score:{name:"@s",objective:"ec.fsack_dust"},color:"yellow"}]

# LORE TEST PREREQ: refresh_lore only rewrites the sack in your MAIN HAND. Report whether it's there.
execute if items entity @s weapon.mainhand *[custom_data~{forever_sack:true}] run tellraw @s [{text:"sack in main hand: ",color:"gray"},{text:"YES — lore should refresh",color:"green"}]
execute unless items entity @s weapon.mainhand *[custom_data~{forever_sack:true}] run tellraw @s [{text:"sack in main hand: ",color:"gray"},{text:"NO — HOLD the sack and rerun, or lore won't refresh",color:"red"}]

# Put 16 cobblestone in the off-hand (DESTROYS current off-hand — debug only).
item replace entity @s weapon.offhand with minecraft:cobblestone 16

# Run the real commit path (this also calls refresh_lore at the end).
function evercraft:forever_sack/menu/dissolve_offhand

# What did the snapshot capture?
tellraw @s [{text:"cur (snapshot) = ",color:"gray"}]
data get storage evercraft:forever_sack cur

tellraw @s [{text:"dust(after)=",color:"gray"},{score:{name:"@s",objective:"ec.fsack_dust"},color:"green"},{text:"   (expected +16 for junk)",color:"dark_gray"}]
tellraw @s [{text:"whitelist (all players) = ",color:"gray"}]
data get storage evercraft:forever_sack lists

# LORE RESULT: read the held sack's lore back. The "Forever Dust: N / 13824" line should now match
# dust(after). If it does, refresh_lore works; if it shows the old number, the item write failed.
tellraw @s [{text:"held sack lore (Forever Dust line should match dust above):",color:"aqua"}]
data get entity @s SelectedItem.components."minecraft:lore"

# === SWEEP TEST (the "absorbing" half) ===
# The dissolve above whitelisted cobblestone. Now give plain cobblestone to the inventory and run
# the REAL sweep (bulk_eat — same entry point as Sneak+RC and [Sweep Now]). If it absorbs, the
# whitelist→copy_wl→sweep_one→clear chain is sound and "not absorbing" is a stale/empty-whitelist
# or not-/reloaded situation, NOT a code bug. If 8 remain and dust is unchanged, the sweep is broken.
tellraw @s [{text:"--- SWEEP TEST (give 8 cobblestone, run bulk_eat) ---",color:"aqua","bold":true}]
clear @s minecraft:cobblestone[!custom_data~{}]
give @s minecraft:cobblestone 8
scoreboard players operation #diag_pre ec.temp = @s ec.fsack_dust
function evercraft:forever_sack/bulk_eat
execute store result score #diag_rem ec.temp run clear @s minecraft:cobblestone[!custom_data~{}] 0
scoreboard players operation #diag_gain ec.temp = @s ec.fsack_dust
scoreboard players operation #diag_gain ec.temp -= #diag_pre ec.temp
tellraw @s [{text:"cobblestone left after sweep = ",color:"gray"},{score:{name:"#diag_rem",objective:"ec.temp"},color:"green"},{text:"  (expect 0)",color:"dark_gray"}]
tellraw @s [{text:"dust gained by sweep = ",color:"gray"},{score:{name:"#diag_gain",objective:"ec.temp"},color:"green"},{text:"  (expect +8)",color:"dark_gray"}]
tellraw @s [{text:"VERDICT: ",color:"gray"},{text:"sweep WORKS — bug is stale/empty whitelist or not /reloaded",color:"green"}]
tellraw @s ["",{text:"  (the line above only applies if 'left=0' and 'gained=+8')",color:"dark_gray"}]

# === REOPEN NOTE ===
# Functions can't query advancement grant-state, so if the menu won't reopen, the open advancement
# is stuck GRANTED. Un-stick it immediately with the command below (load.mcfunction also does this on
# /reload). If revoking + right-click reopens it, the close path isn't revoking in your scenario.
tellraw @s ["",{text:"REOPEN won't work? run: ",color:"aqua"},{text:"/advancement revoke @s only evercraft:forever_sack/open",color:"white"}]
