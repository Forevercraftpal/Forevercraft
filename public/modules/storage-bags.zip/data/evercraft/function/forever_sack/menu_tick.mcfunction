# Forever Sack Menu — fast tick (every 2t) while any player has the menu open.
execute as @a[tag=ec.fsack_in_menu] at @s run function evercraft:forever_sack/menu/tick
execute if entity @a[tag=ec.fsack_in_menu] run schedule function evercraft:forever_sack/menu_tick 2t replace
