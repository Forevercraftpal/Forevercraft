# Forever Sack — macro: copy this player's whitelist into a working list. Arg: id.
# Reset first so a missing source can't leave another player's list in work.wl.
data modify storage evercraft:forever_sack work.wl set value []
$data modify storage evercraft:forever_sack work.wl set from storage evercraft:forever_sack lists.p$(id).wl
