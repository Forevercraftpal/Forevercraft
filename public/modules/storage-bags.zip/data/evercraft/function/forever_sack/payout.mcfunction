# Forever Sack — the bag brimmed over. Pay out a structure crate whose tier = the best
# rarity fed in this fill (ec.fsack_peak; default Common), then reset with overflow carry.
# Run AS the holder, AT @s.

# Tier name (for give_quest_crate) + display name/color (for the announce).
data modify storage evercraft:forever_sack crate.tier set value "common"
data modify storage evercraft:forever_sack crate.disp set value "Common"
data modify storage evercraft:forever_sack crate.color set value "white"
execute if score @s ec.fsack_peak matches 2 run data modify storage evercraft:forever_sack crate set value {tier:"uncommon",disp:"Uncommon",color:"#7FDB6B"}
execute if score @s ec.fsack_peak matches 3 run data modify storage evercraft:forever_sack crate set value {tier:"rare",disp:"Rare",color:"#5B9BE8"}
execute if score @s ec.fsack_peak matches 4 run data modify storage evercraft:forever_sack crate set value {tier:"ornate",disp:"Ornate",color:"#C77FE8"}
execute if score @s ec.fsack_peak matches 5 run data modify storage evercraft:forever_sack crate set value {tier:"exquisite",disp:"Exquisite",color:"#E8C66B"}
execute if score @s ec.fsack_peak matches 6.. run data modify storage evercraft:forever_sack crate set value {tier:"mythical",disp:"Mythical",color:"#E8746B"}

# Full odds: hand over the crate item of that tier (inv-full safe inside the util).
function evercraft:util/give_quest_crate with storage evercraft:forever_sack crate

# Reset — carry any overflow dust into the next fill.
scoreboard players remove @s ec.fsack_dust 13824
execute if score @s ec.fsack_dust matches ..-1 run scoreboard players set @s ec.fsack_dust 0
scoreboard players set @s ec.fsack_peak 0
scoreboard players set @s ec.fsack_items 0
# Dust is gone into the crate — those dissolves are no longer reversible. Wipe the undo stack.
execute if score @s ec.fsack_id matches 1.. store result storage evercraft:forever_sack k.id int 1 run scoreboard players get @s ec.fsack_id
execute if score @s ec.fsack_id matches 1.. run function evercraft:forever_sack/clear_undo with storage evercraft:forever_sack k

# Celebrate.
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.amethyst_block.resonate master @s ~ ~ ~ 1.0 0.8
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 0.9 1.1
execute if score @s ec.fx_vis matches 1.. at @s run particle minecraft:totem_of_undying ~ ~1 ~ 0.5 0.7 0.5 0.4 60
function evercraft:forever_sack/payout_announce with storage evercraft:forever_sack crate

# Lore back to an empty (or overflow) bar.
function evercraft:forever_sack/refresh_lore
