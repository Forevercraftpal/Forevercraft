# Forever Sack — load (registered in minecraft:load tag).

# ec.xplevel auto-mirrors each player's XP LEVEL via the vanilla "level" criterion.
# Used to grant the sack the first time a player reaches level 30 (a "level-30 enchant" threshold).
scoreboard objectives add ec.xplevel level

# One-time grant gate + per-player id (keys the whitelist storage) + first-open primer flag.
scoreboard objectives add ec.fsack_granted dummy "Forever Sack Granted"
scoreboard objectives add ec.fsack_id dummy "Forever Sack Player Id"
scoreboard objectives add ec.fsack_seen dummy "Forever Sack Primer Seen"

# Fill state (authoritative — the item lore only displays these).
scoreboard objectives add ec.fsack_dust dummy "Forever Dust"
scoreboard objectives add ec.fsack_peak dummy "Forever Sack Peak Tier"
scoreboard objectives add ec.fsack_items dummy "Forever Sack Items Digested"

# Interaction debounce / confirm windows + menu page.
scoreboard objectives add ec.fsack_use_cd dummy "Forever Sack Use Cooldown"
scoreboard objectives add ec.fsack_dcd dummy "Forever Sack Dissolve Confirm"
scoreboard objectives add ec.fsack_page dummy "Forever Sack Whitelist Page"
# Open-grace: ignore clicks for the first few menu ticks so the held opening right-click
# (the consumable keeps "using") can't phantom-click a button on open.
scoreboard objectives add ec.fsack_ocd dummy "Forever Sack Open Grace"
# Click debounce: the Sack is a consumable, so HOLDING right-click re-fires the interaction
# under the crosshair every tick — process at most one click per few ticks.
scoreboard objectives add ec.fsack_click_cd dummy "Forever Sack Click Debounce"

# Undo (last deliberate dissolve).
scoreboard objectives add ec.fsack_undo dummy "Forever Sack Undo Available"
scoreboard objectives add ec.fsack_undo_dust dummy "Forever Sack Undo Dust"
scoreboard objectives add ec.fsack_undo_items dummy "Forever Sack Undo Items"
scoreboard objectives add ec.fsack_undo_peak dummy "Forever Sack Undo Peak"

# FULL menu reset on load — guarantee a clean slate. using_item leaves the open advancement
# GRANTED while held; if a reload (or a culled panel) froze it granted with a lingering
# in_menu tag, every right-click no-ops and "the menu never opens". So nuke ALL menu state:
# revoke the advancement, drop the in_menu tag, kill any orphaned panel entities. The next
# right-click rebuilds the menu fresh (menu/open re-summons everything).
scoreboard players reset @a ec.fsack_use_cd
advancement revoke @a only evercraft:forever_sack/open
tag @a remove ec.fsack_in_menu
kill @e[type=interaction,tag=ec.fsack_el]
kill @e[type=text_display,tag=ec.fsack_el]
kill @e[type=item_display,tag=ec.fsack_el]
