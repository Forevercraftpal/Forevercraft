# === KEY SATCHEL — WRITE DUNGEON COUNTS (macro, Chest-Node §4) ===
# Macro body — called {hand:"mainhand"} or {hand:"offhand"} (the hand holding the bag). Reads the bag's
# current ks_dfresh/ks_dworn/ks_dcrack off the held item, adds the just-deposited #ks_add_f/w/c counts,
# and writes the new totals back IN PLACE via `item modify entity @s weapon.<hand> set_custom_data`
# (the canonical in-place held-item mutation — writing to SelectedItem.components does NOT persist;
# precedent: portal_dial/apply_gs_bind). set_custom_data MERGES, so only the changed dungeon counts +
# the ks_dhas presence flag are written; the crafting counts + bag_tier are left untouched.
#
# The read path is per-hand (SelectedItem for mainhand, Inventory[{Slot:-106b}] for offhand); the write
# uses weapon.$(hand). Counts default to 0 when absent (the temps are pre-zeroed).

# Read current totals into temps (default 0).
scoreboard players set #ks_cur_f ec.temp 0
scoreboard players set #ks_cur_w ec.temp 0
scoreboard players set #ks_cur_c ec.temp 0
execute if items entity @s weapon.mainhand *[custom_data~{key_bag:true}] store result score #ks_cur_f ec.temp run data get entity @s SelectedItem.components."minecraft:custom_data".ks_dfresh
execute if items entity @s weapon.mainhand *[custom_data~{key_bag:true}] store result score #ks_cur_w ec.temp run data get entity @s SelectedItem.components."minecraft:custom_data".ks_dworn
execute if items entity @s weapon.mainhand *[custom_data~{key_bag:true}] store result score #ks_cur_c ec.temp run data get entity @s SelectedItem.components."minecraft:custom_data".ks_dcrack
execute unless items entity @s weapon.mainhand *[custom_data~{key_bag:true}] store result score #ks_cur_f ec.temp run data get entity @s Inventory[{Slot:-106b}].components."minecraft:custom_data".ks_dfresh
execute unless items entity @s weapon.mainhand *[custom_data~{key_bag:true}] store result score #ks_cur_w ec.temp run data get entity @s Inventory[{Slot:-106b}].components."minecraft:custom_data".ks_dworn
execute unless items entity @s weapon.mainhand *[custom_data~{key_bag:true}] store result score #ks_cur_c ec.temp run data get entity @s Inventory[{Slot:-106b}].components."minecraft:custom_data".ks_dcrack

# Add the deposited counts.
scoreboard players operation #ks_cur_f ec.temp += #ks_add_f ec.temp
scoreboard players operation #ks_cur_w ec.temp += #ks_add_w ec.temp
scoreboard players operation #ks_cur_c ec.temp += #ks_add_c ec.temp

# Presence flag for the chest engine's key_bag_scan (ks_dhas = 1 if any fresh dungeon key is bagged).
scoreboard players set #ks_has ec.temp 0
execute if score #ks_cur_f ec.temp matches 1.. run scoreboard players set #ks_has ec.temp 1

# Marshal the new totals + the hand into ONE storage object for the write macro, then apply IN PLACE.
$data modify storage evercraft:ksbag w.hand set value "$(hand)"
execute store result storage evercraft:ksbag w.df int 1 run scoreboard players get #ks_cur_f ec.temp
execute store result storage evercraft:ksbag w.dw int 1 run scoreboard players get #ks_cur_w ec.temp
execute store result storage evercraft:ksbag w.dc int 1 run scoreboard players get #ks_cur_c ec.temp
execute store result storage evercraft:ksbag w.dh int 1 run scoreboard players get #ks_has ec.temp
function evercraft:key_satchel/apply_dungeon with storage evercraft:ksbag w
