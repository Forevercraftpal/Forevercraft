# === KEY SATCHEL — WITHDRAW ONE WORN TRIAL PASS (Wiring #53) ===
# Run as @s = player (from the menu). Mirror of withdraw_dungeon_worn for the crafting key family. If the
# held bag holds at least one worn trial pass, give one worn Trial Pass + decrement ks_cworn by 1. No
# presence flag (only fresh boosts). Writes IN PLACE via set_custom_data (per hand). Inv-full-safe.
# Uses evercraft:craftforever/trials/trial_pass_worn (minted to mirror the chest_nodes/mark_worn form).

# Read the bag's current worn crafting count (mainhand first, else offhand).
scoreboard players set #ks_cur_w ec.temp 0
execute if items entity @s weapon.mainhand *[custom_data~{key_bag:true}] store result score #ks_cur_w ec.temp run data get entity @s SelectedItem.components."minecraft:custom_data".ks_cworn
execute unless items entity @s weapon.mainhand *[custom_data~{key_bag:true}] store result score #ks_cur_w ec.temp run data get entity @s Inventory[{Slot:-106b}].components."minecraft:custom_data".ks_cworn

# Nothing worn to withdraw -> a soft cue + bail.
execute if score #ks_cur_w ec.temp matches ..0 if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 0.5 0.8
execute if score #ks_cur_w ec.temp matches ..0 run return 0

# Give one worn trial pass + decrement.
# Inv-full guard: drop at the player's feet rather than void on a full inventory.
execute store result score #inv_full ec.var run function evercraft:util/check_inv_full
execute if score #inv_full ec.var matches 0 run loot give @s loot evercraft:craftforever/trials/trial_pass_worn
execute if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:craftforever/trials/trial_pass_worn
scoreboard players remove #ks_cur_w ec.temp 1

# Write the decremented worn count back IN PLACE (per hand). MERGE keeps the fresh/cracked crafting counts
# + dungeon counts + bag_tier.
execute if items entity @s weapon.mainhand *[custom_data~{key_bag:true}] run data modify storage evercraft:ksbag w.hand set value "mainhand"
execute unless items entity @s weapon.mainhand *[custom_data~{key_bag:true}] run data modify storage evercraft:ksbag w.hand set value "offhand"
execute store result storage evercraft:ksbag w.cw int 1 run scoreboard players get #ks_cur_w ec.temp
function evercraft:key_satchel/wd_worn_crafting with storage evercraft:ksbag w

execute if score @s ec.fx_snd matches 1.. run playsound minecraft:item.bundle.remove_one master @s ~ ~ ~ 0.8 1.0
function evercraft:key_satchel/menu/refresh
