# === KEY SATCHEL — DEPOSIT ALL TRIAL PASSES (Chest-Node §4) ===
# Run as @s = player (from the menu). Mirror of deposit_dungeon for the crafting key family. Trial Pass
# = minecraft:trial_key[custom_data~{trial_pass:1b}] (SAME base item as the Dungeon Key — they are
# distinguished by custom_data, NOT base item). Pulls every trial pass from the inventory INTO the held
# bag, split cracked / worn / fresh, then writes the new ks_c* totals onto the held item.

scoreboard players set #ks_add_c ec.temp 0
scoreboard players set #ks_add_w ec.temp 0
scoreboard players set #ks_add_f ec.temp 0
execute store result score #ks_add_c ec.temp run clear @s minecraft:trial_key[custom_data~{trial_pass:1b,cracked:1b}]
execute store result score #ks_add_w ec.temp run clear @s minecraft:trial_key[custom_data~{trial_pass:1b,worn:1b}]
execute store result score #ks_add_f ec.temp run clear @s minecraft:trial_key[custom_data~{trial_pass:1b}]

execute if score #ks_add_c ec.temp matches 0 if score #ks_add_w ec.temp matches 0 if score #ks_add_f ec.temp matches 0 if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 0.5 0.8
execute if score #ks_add_c ec.temp matches 0 if score #ks_add_w ec.temp matches 0 if score #ks_add_f ec.temp matches 0 run return 0

execute if items entity @s weapon.mainhand *[custom_data~{key_bag:true}] run function evercraft:key_satchel/write_crafting {hand:"mainhand"}
execute unless items entity @s weapon.mainhand *[custom_data~{key_bag:true}] if items entity @s weapon.offhand *[custom_data~{key_bag:true}] run function evercraft:key_satchel/write_crafting {hand:"offhand"}

execute if score @s ec.fx_snd matches 1.. run playsound minecraft:item.bundle.insert master @s ~ ~ ~ 0.8 1.1
function evercraft:key_satchel/menu/refresh
