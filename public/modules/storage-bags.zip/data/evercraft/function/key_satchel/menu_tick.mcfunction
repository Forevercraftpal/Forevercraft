# Key Satchel Menu — fast tick for click responsiveness (every 2t). Active only while a player has the
# menu open (existence-gated). Mirrors satchel/menu_tick.
execute as @a[tag=ec.ksbag_in_menu] at @s run function evercraft:key_satchel/menu/tick
execute if entity @a[tag=ec.ksbag_in_menu] run schedule function evercraft:key_satchel/menu_tick 2t replace
