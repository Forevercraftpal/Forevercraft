# === KEY SATCHEL — WRITE CRAFTING COUNTS (macro, Chest-Node §4) ===
# Macro body — called {hand:"mainhand"} or {hand:"offhand"}. Mirror of write_dungeon for the crafting
# key family: read ks_cfresh/ks_cworn/ks_ccrack, add the deposited #ks_add_f/w/c, write the new totals
# + the ks_chas presence flag back IN PLACE via set_custom_data (MERGE).

scoreboard players set #ks_cur_f ec.temp 0
scoreboard players set #ks_cur_w ec.temp 0
scoreboard players set #ks_cur_c ec.temp 0
execute if items entity @s weapon.mainhand *[custom_data~{key_bag:true}] store result score #ks_cur_f ec.temp run data get entity @s SelectedItem.components."minecraft:custom_data".ks_cfresh
execute if items entity @s weapon.mainhand *[custom_data~{key_bag:true}] store result score #ks_cur_w ec.temp run data get entity @s SelectedItem.components."minecraft:custom_data".ks_cworn
execute if items entity @s weapon.mainhand *[custom_data~{key_bag:true}] store result score #ks_cur_c ec.temp run data get entity @s SelectedItem.components."minecraft:custom_data".ks_ccrack
execute unless items entity @s weapon.mainhand *[custom_data~{key_bag:true}] store result score #ks_cur_f ec.temp run data get entity @s Inventory[{Slot:-106b}].components."minecraft:custom_data".ks_cfresh
execute unless items entity @s weapon.mainhand *[custom_data~{key_bag:true}] store result score #ks_cur_w ec.temp run data get entity @s Inventory[{Slot:-106b}].components."minecraft:custom_data".ks_cworn
execute unless items entity @s weapon.mainhand *[custom_data~{key_bag:true}] store result score #ks_cur_c ec.temp run data get entity @s Inventory[{Slot:-106b}].components."minecraft:custom_data".ks_ccrack

scoreboard players operation #ks_cur_f ec.temp += #ks_add_f ec.temp
scoreboard players operation #ks_cur_w ec.temp += #ks_add_w ec.temp
scoreboard players operation #ks_cur_c ec.temp += #ks_add_c ec.temp

scoreboard players set #ks_has ec.temp 0
execute if score #ks_cur_f ec.temp matches 1.. run scoreboard players set #ks_has ec.temp 1

$data modify storage evercraft:ksbag w.hand set value "$(hand)"
execute store result storage evercraft:ksbag w.cf int 1 run scoreboard players get #ks_cur_f ec.temp
execute store result storage evercraft:ksbag w.cw int 1 run scoreboard players get #ks_cur_w ec.temp
execute store result storage evercraft:ksbag w.cc int 1 run scoreboard players get #ks_cur_c ec.temp
execute store result storage evercraft:ksbag w.ch int 1 run scoreboard players get #ks_has ec.temp
function evercraft:key_satchel/apply_crafting with storage evercraft:ksbag w
