# === KEY SATCHEL — APPLY WITHDRAWN DUNGEON CRACKED COUNT (macro, Wiring #53) ===
# Macro body — called `with storage evercraft:ksbag w` where w = {hand, dc}. Writes the decremented
# ks_dcrack onto the held bag IN PLACE via set_custom_data (MERGE — the fresh/worn dungeon counts +
# crafting counts + bag_tier survive). No presence flag (only fresh tracks ks_dhas).
$item modify entity @s weapon.$(hand) {"function":"minecraft:set_custom_data","tag":"{ks_dcrack:$(dc)}"}
