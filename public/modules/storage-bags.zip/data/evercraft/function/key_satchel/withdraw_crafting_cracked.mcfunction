# === KEY SATCHEL — WITHDRAW ONE CRACKED TRIAL PASS (Wiring #53) ===
# Run as @s = player (from the menu). Mirror of withdraw_dungeon_cracked for the crafting key family. If
# the held bag holds at least one cracked trial pass, give one cracked Trial Pass + decrement ks_ccrack
# by 1. No presence flag (only fresh boosts). Writes IN PLACE via set_custom_data (per hand). Inv-full-safe.

# Read the bag's current cracked crafting count (mainhand first, else offhand).
scoreboard players set #ks_cur_c ec.temp 0
execute if items entity @s weapon.mainhand *[custom_data~{key_bag:true}] store result score #ks_cur_c ec.temp run data get entity @s SelectedItem.components."minecraft:custom_data".ks_ccrack
execute unless items entity @s weapon.mainhand *[custom_data~{key_bag:true}] store result score #ks_cur_c ec.temp run data get entity @s Inventory[{Slot:-106b}].components."minecraft:custom_data".ks_ccrack

# Nothing cracked to withdraw -> a soft cue + bail.
execute if score #ks_cur_c ec.temp matches ..0 if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 0.5 0.8
execute if score #ks_cur_c ec.temp matches ..0 run return 0

# Give one cracked trial pass + decrement.
# Inv-full guard: drop at the player's feet rather than void on a full inventory.
execute store result score #inv_full ec.var run function evercraft:util/check_inv_full
execute if score #inv_full ec.var matches 0 run loot give @s loot evercraft:craftforever/trials/trial_pass_cracked
execute if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:craftforever/trials/trial_pass_cracked
scoreboard players remove #ks_cur_c ec.temp 1

# Write the decremented cracked count back IN PLACE (per hand). MERGE keeps the fresh/worn crafting counts
# + dungeon counts + bag_tier.
execute if items entity @s weapon.mainhand *[custom_data~{key_bag:true}] run data modify storage evercraft:ksbag w.hand set value "mainhand"
execute unless items entity @s weapon.mainhand *[custom_data~{key_bag:true}] run data modify storage evercraft:ksbag w.hand set value "offhand"
execute store result storage evercraft:ksbag w.cc int 1 run scoreboard players get #ks_cur_c ec.temp
function evercraft:key_satchel/wd_crack_crafting with storage evercraft:ksbag w

execute if score @s ec.fx_snd matches 1.. run playsound minecraft:item.bundle.remove_one master @s ~ ~ ~ 0.8 0.9
function evercraft:key_satchel/menu/refresh
