# === KEY SATCHEL — APPLY WITHDRAWN CRAFTING CRACKED COUNT (macro, Wiring #53) ===
# Macro body — called `with storage evercraft:ksbag w` where w = {hand, cc}. Writes the decremented
# ks_ccrack onto the held bag IN PLACE via set_custom_data (MERGE — the fresh/worn crafting counts +
# dungeon counts + bag_tier survive). No presence flag (only fresh tracks ks_chas).
$item modify entity @s weapon.$(hand) {"function":"minecraft:set_custom_data","tag":"{ks_ccrack:$(cc)}"}
