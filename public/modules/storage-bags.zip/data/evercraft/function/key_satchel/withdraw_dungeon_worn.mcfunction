# === KEY SATCHEL — WITHDRAW ONE WORN DUNGEON KEY (Wiring #53) ===
# Run as @s = player (from the menu). Mirror of withdraw_dungeon for the WORN dungeon form. If the held
# bag holds at least one worn dungeon key, give one worn Dungeon Key item + decrement ks_dworn by 1.
# Worn/cracked have NO presence flag (only fresh boosts chests via ks_dhas), so this only writes the
# decremented count back IN PLACE via set_custom_data (per hand). Inv-full-safe.

# Read the bag's current worn dungeon count (mainhand first, else offhand).
scoreboard players set #ks_cur_w ec.temp 0
execute if items entity @s weapon.mainhand *[custom_data~{key_bag:true}] store result score #ks_cur_w ec.temp run data get entity @s SelectedItem.components."minecraft:custom_data".ks_dworn
execute unless items entity @s weapon.mainhand *[custom_data~{key_bag:true}] store result score #ks_cur_w ec.temp run data get entity @s Inventory[{Slot:-106b}].components."minecraft:custom_data".ks_dworn

# Nothing worn to withdraw -> a soft cue + bail.
execute if score #ks_cur_w ec.temp matches ..0 if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 0.5 0.8
execute if score #ks_cur_w ec.temp matches ..0 run return 0

# Give one worn dungeon key + decrement.
# Inv-full guard: drop at the player's feet rather than void on a full inventory.
execute store result score #inv_full ec.var run function evercraft:util/check_inv_full
execute if score #inv_full ec.var matches 0 run loot give @s loot evercraft:dungeon/key_worn
execute if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:dungeon/key_worn
scoreboard players remove #ks_cur_w ec.temp 1

# Write the decremented worn count back IN PLACE (per hand). Stamp the hand string + the value into ONE
# storage object, then call the apply macro with that storage (single arg source; set_custom_data MERGES
# so the fresh/cracked dungeon counts + crafting counts + bag_tier survive).
execute if items entity @s weapon.mainhand *[custom_data~{key_bag:true}] run data modify storage evercraft:ksbag w.hand set value "mainhand"
execute unless items entity @s weapon.mainhand *[custom_data~{key_bag:true}] run data modify storage evercraft:ksbag w.hand set value "offhand"
execute store result storage evercraft:ksbag w.dw int 1 run scoreboard players get #ks_cur_w ec.temp
function evercraft:key_satchel/wd_worn_dungeon with storage evercraft:ksbag w

execute if score @s ec.fx_snd matches 1.. run playsound minecraft:item.bundle.remove_one master @s ~ ~ ~ 0.8 1.0
function evercraft:key_satchel/menu/refresh
