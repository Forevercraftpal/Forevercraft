# === KEY SATCHEL (Key Ring / Bag of Keys) — LOAD (Chest-Node §4) ===
# The crafted key bag (a minecraft:bundle with custom_data{key_bag:true, bag_tier}). RC opens a
# deposit/use menu (mirror satchel/menu/); shift-RC shows an actionbar key tally. The bag's six on-item
# counts (ks_dfresh/ks_dworn/ks_dcrack/ks_cfresh/ks_cworn/ks_ccrack) + two presence flags
# (ks_dhas/ks_chas, read by chest_nodes/key_bag_scan) live ON the item — NO scoreboards needed (the
# menu uses the shared ec.temp scratch + adv.gui_session for session isolation, like the satchel).
# Registered from evercraft:init.
#
# On reload, clear any orphaned menu entities + drop the in-menu tag so a /reload mid-menu cannot leave
# floating elements or a stuck tick (the menu_tick is existence-gated + only reschedules while a player
# is tagged, so it stops on its own once the tag is gone).
kill @e[type=interaction,tag=ec.ksbag_el]
kill @e[type=text_display,tag=ec.ksbag_el]
kill @e[type=item_display,tag=ec.ksbag_el]
tag @a remove ec.ksbag_in_menu
