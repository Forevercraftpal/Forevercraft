# === KEY SATCHEL — APPLY WITHDRAWN DUNGEON FRESH COUNT (macro, Chest-Node §4) ===
# Macro body — called `with storage evercraft:ksbag w` where w = {hand, df, dh}. Writes the decremented
# ks_dfresh + the ks_dhas presence flag onto the held bag IN PLACE via set_custom_data (MERGE — the
# worn/cracked dungeon counts + crafting counts + bag_tier survive).
$item modify entity @s weapon.$(hand) {"function":"minecraft:set_custom_data","tag":"{ks_dfresh:$(df),ks_dhas:$(dh)}"}
