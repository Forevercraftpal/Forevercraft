# === KEY SATCHEL — DEPOSIT ALL DUNGEON KEYS (Chest-Node §4) ===
# Run as @s = player (from the menu). Pulls every Dungeon Key from the player's inventory INTO the held
# bag, split by form: cracked / worn / fresh. `clear ... <maxCount>` removes matching items AND returns
# the number removed, so we clear each form (most-specific first) and add its count to the matching bag
# counter. Then the bag write-back (per hand) stamps the new ks_d* totals onto the held item; refresh
# updates the labels. ONLY fresh keys later boost spawn/open (worn/cracked are stored but inert for
# chests) — but ALL forms are bagged (Joseph: "bags worn and cracked keys with its counterpart").
#
# Form precedence (a key with both worn+cracked would have broken before reaching the inventory, but we
# still order cracked-before-worn-before-fresh so each form is counted exactly once):
#   cracked  = custom_data{dungeon_key:true, cracked:1b}
#   worn     = custom_data{dungeon_key:true, worn:1b}  (and NOT cracked — cleared above already)
#   fresh    = custom_data{dungeon_key:true}           (and neither worn nor cracked — cleared above)

# Count + remove each form (clear returns the removed count).
scoreboard players set #ks_add_c ec.temp 0
scoreboard players set #ks_add_w ec.temp 0
scoreboard players set #ks_add_f ec.temp 0
execute store result score #ks_add_c ec.temp run clear @s minecraft:trial_key[custom_data~{dungeon_key:true,cracked:1b}]
execute store result score #ks_add_w ec.temp run clear @s minecraft:trial_key[custom_data~{dungeon_key:true,worn:1b}]
execute store result score #ks_add_f ec.temp run clear @s minecraft:trial_key[custom_data~{dungeon_key:true}]

# Nothing deposited -> a soft cue + bail (don't churn the item NBT).
execute if score #ks_add_c ec.temp matches 0 if score #ks_add_w ec.temp matches 0 if score #ks_add_f ec.temp matches 0 if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 0.5 0.8
execute if score #ks_add_c ec.temp matches 0 if score #ks_add_w ec.temp matches 0 if score #ks_add_f ec.temp matches 0 run return 0

# Write the new totals onto the held bag (per hand) — read current, add, write in place.
execute if items entity @s weapon.mainhand *[custom_data~{key_bag:true}] run function evercraft:key_satchel/write_dungeon {hand:"mainhand"}
execute unless items entity @s weapon.mainhand *[custom_data~{key_bag:true}] if items entity @s weapon.offhand *[custom_data~{key_bag:true}] run function evercraft:key_satchel/write_dungeon {hand:"offhand"}

execute if score @s ec.fx_snd matches 1.. run playsound minecraft:item.bundle.insert master @s ~ ~ ~ 0.8 1.1
function evercraft:key_satchel/menu/refresh
