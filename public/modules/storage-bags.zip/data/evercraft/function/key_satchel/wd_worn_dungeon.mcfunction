# === KEY SATCHEL — APPLY WITHDRAWN DUNGEON WORN COUNT (macro, Wiring #53) ===
# Macro body — called `with storage evercraft:ksbag w` where w = {hand, dw}. Writes the decremented
# ks_dworn onto the held bag IN PLACE via set_custom_data (MERGE — the fresh/cracked dungeon counts +
# crafting counts + bag_tier survive). No presence flag (only fresh tracks ks_dhas).
$item modify entity @s weapon.$(hand) {"function":"minecraft:set_custom_data","tag":"{ks_dworn:$(dw)}"}
