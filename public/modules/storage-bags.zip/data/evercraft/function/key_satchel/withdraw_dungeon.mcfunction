# === KEY SATCHEL — WITHDRAW ONE FRESH DUNGEON KEY (Chest-Node §4) ===
# Run as @s = player (from the menu). If the held bag holds at least one FRESH dungeon key, give one
# fresh Dungeon Key item + decrement ks_dfresh by 1 (and clear ks_dhas if that empties the fresh stock).
# Only FRESH keys are withdrawable here (the keys that still open dungeons + chests); worn/cracked are
# bagged but inert. Writes the new count IN PLACE via set_custom_data (per hand).

# Read the bag's current fresh dungeon count (mainhand first, else offhand).
scoreboard players set #ks_cur_f ec.temp 0
execute if items entity @s weapon.mainhand *[custom_data~{key_bag:true}] store result score #ks_cur_f ec.temp run data get entity @s SelectedItem.components."minecraft:custom_data".ks_dfresh
execute unless items entity @s weapon.mainhand *[custom_data~{key_bag:true}] store result score #ks_cur_f ec.temp run data get entity @s Inventory[{Slot:-106b}].components."minecraft:custom_data".ks_dfresh

# Nothing fresh to withdraw -> a soft cue + bail.
execute if score #ks_cur_f ec.temp matches ..0 if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 0.5 0.8
execute if score #ks_cur_f ec.temp matches ..0 run return 0

# Give one fresh dungeon key + decrement.
# Inv-full guard: drop at the player's feet rather than void on a full inventory.
execute store result score #inv_full ec.var run function evercraft:util/check_inv_full
execute if score #inv_full ec.var matches 0 run loot give @s loot evercraft:dungeon/key
execute if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:dungeon/key
scoreboard players remove #ks_cur_f ec.temp 1
scoreboard players set #ks_has ec.temp 0
execute if score #ks_cur_f ec.temp matches 1.. run scoreboard players set #ks_has ec.temp 1

# Write the decremented fresh count + presence flag back IN PLACE (per hand). Stamp the hand string +
# the values into ONE storage object, then call the apply macro with that storage (single arg source).
execute if items entity @s weapon.mainhand *[custom_data~{key_bag:true}] run data modify storage evercraft:ksbag w.hand set value "mainhand"
execute unless items entity @s weapon.mainhand *[custom_data~{key_bag:true}] run data modify storage evercraft:ksbag w.hand set value "offhand"
execute store result storage evercraft:ksbag w.df int 1 run scoreboard players get #ks_cur_f ec.temp
execute store result storage evercraft:ksbag w.dh int 1 run scoreboard players get #ks_has ec.temp
function evercraft:key_satchel/wd_fresh_dungeon with storage evercraft:ksbag w

execute if score @s ec.fx_snd matches 1.. run playsound minecraft:item.bundle.remove_one master @s ~ ~ ~ 0.8 1.2
function evercraft:key_satchel/menu/refresh
