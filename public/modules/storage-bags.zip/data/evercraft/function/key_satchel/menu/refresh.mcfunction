# Key Satchel Menu — refresh the count labels (run as @s, at @s). Reads the held bag's fresh counts +
# updates the Dungeon / Trial-Pass row labels to show "<fresh> fresh". Called by open + after every
# deposit/withdraw so the menu reflects the live on-item counts.

# Read fresh + worn + cracked counts off the held bag (mainhand first, else offhand). Worn/cracked are
# read too now (Wiring #53) so each row label shows what every withdraw button can pull.
scoreboard players set #ksdf ec.temp 0
scoreboard players set #ksdw ec.temp 0
scoreboard players set #ksdc ec.temp 0
scoreboard players set #kscf ec.temp 0
scoreboard players set #kscw ec.temp 0
scoreboard players set #kscc ec.temp 0
execute if items entity @s weapon.mainhand *[custom_data~{key_bag:true}] store result score #ksdf ec.temp run data get entity @s SelectedItem.components."minecraft:custom_data".ks_dfresh
execute if items entity @s weapon.mainhand *[custom_data~{key_bag:true}] store result score #ksdw ec.temp run data get entity @s SelectedItem.components."minecraft:custom_data".ks_dworn
execute if items entity @s weapon.mainhand *[custom_data~{key_bag:true}] store result score #ksdc ec.temp run data get entity @s SelectedItem.components."minecraft:custom_data".ks_dcrack
execute if items entity @s weapon.mainhand *[custom_data~{key_bag:true}] store result score #kscf ec.temp run data get entity @s SelectedItem.components."minecraft:custom_data".ks_cfresh
execute if items entity @s weapon.mainhand *[custom_data~{key_bag:true}] store result score #kscw ec.temp run data get entity @s SelectedItem.components."minecraft:custom_data".ks_cworn
execute if items entity @s weapon.mainhand *[custom_data~{key_bag:true}] store result score #kscc ec.temp run data get entity @s SelectedItem.components."minecraft:custom_data".ks_ccrack
execute unless items entity @s weapon.mainhand *[custom_data~{key_bag:true}] if items entity @s weapon.offhand *[custom_data~{key_bag:true}] store result score #ksdf ec.temp run data get entity @s Inventory[{Slot:-106b}].components."minecraft:custom_data".ks_dfresh
execute unless items entity @s weapon.mainhand *[custom_data~{key_bag:true}] if items entity @s weapon.offhand *[custom_data~{key_bag:true}] store result score #ksdw ec.temp run data get entity @s Inventory[{Slot:-106b}].components."minecraft:custom_data".ks_dworn
execute unless items entity @s weapon.mainhand *[custom_data~{key_bag:true}] if items entity @s weapon.offhand *[custom_data~{key_bag:true}] store result score #ksdc ec.temp run data get entity @s Inventory[{Slot:-106b}].components."minecraft:custom_data".ks_dcrack
execute unless items entity @s weapon.mainhand *[custom_data~{key_bag:true}] if items entity @s weapon.offhand *[custom_data~{key_bag:true}] store result score #kscf ec.temp run data get entity @s Inventory[{Slot:-106b}].components."minecraft:custom_data".ks_cfresh
execute unless items entity @s weapon.mainhand *[custom_data~{key_bag:true}] if items entity @s weapon.offhand *[custom_data~{key_bag:true}] store result score #kscw ec.temp run data get entity @s Inventory[{Slot:-106b}].components."minecraft:custom_data".ks_cworn
execute unless items entity @s weapon.mainhand *[custom_data~{key_bag:true}] if items entity @s weapon.offhand *[custom_data~{key_bag:true}] store result score #kscc ec.temp run data get entity @s Inventory[{Slot:-106b}].components."minecraft:custom_data".ks_ccrack

# Update the row labels, gated to THIS player's session-stamped elements (mirror check_clicks' owner
# stamp so a second player's menu nearby is not clobbered).
scoreboard players operation #gui_owner ec.temp = @s adv.gui_session
# === 26.1 fix: {score} blank in text_display -> bake via storage macro (cat B) ===
scoreboard players add #ksdf ec.temp 0
execute store result storage evercraft:scorebake bargs.v1 int 1 run scoreboard players get #ksdf ec.temp
scoreboard players add #ksdw ec.temp 0
execute store result storage evercraft:scorebake bargs.v2 int 1 run scoreboard players get #ksdw ec.temp
scoreboard players add #ksdc ec.temp 0
execute store result storage evercraft:scorebake bargs.v3 int 1 run scoreboard players get #ksdc ec.temp
scoreboard players add #kscf ec.temp 0
execute store result storage evercraft:scorebake bargs.v4 int 1 run scoreboard players get #kscf ec.temp
scoreboard players add #kscw ec.temp 0
execute store result storage evercraft:scorebake bargs.v5 int 1 run scoreboard players get #kscw ec.temp
scoreboard players add #kscc ec.temp 0
execute store result storage evercraft:scorebake bargs.v6 int 1 run scoreboard players get #kscc ec.temp
function evercraft:key_satchel/menu/refresh_dynb with storage evercraft:scorebake bargs
