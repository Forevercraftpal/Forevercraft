# Key Satchel Menu — close (run as @s, at @s). Kills the menu elements + drops the in-menu tag.
tag @s remove ec.ksbag_in_menu
execute at @s run kill @e[type=text_display,tag=ec.ksbag_el,distance=..6]
execute at @s run kill @e[type=interaction,tag=ec.ksbag_el,distance=..6]
execute at @s run kill @e[type=item_display,tag=ec.ksbag_el,distance=..6]
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.chest.close master @s ~ ~ ~ 0.5 1.1
