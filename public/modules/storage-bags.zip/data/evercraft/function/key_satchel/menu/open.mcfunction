# === KEY SATCHEL MENU — OPEN (Chest-Node §4, mirrors satchel/menu/open) ===
# Run as @s = player, at @s. Spawns a floating deposit/use menu for the held key bag: a Dungeon row
# (deposit all dungeon keys / withdraw one fresh dungeon key) + a Crafting row (deposit all trial
# passes / withdraw one fresh trial pass) + a Close button. The bag's six on-item counts (ks_*) are
# read/written directly off the held item by the deposit/withdraw handlers. Click responsiveness via a
# 2t menu tick gated to players with the menu open (mirrors satchel/menu_tick).

# Mark in-menu + kill any orphaned elements from a prior session.
tag @s add ec.ksbag_in_menu
execute at @s run kill @e[type=text_display,tag=ec.ksbag_el,distance=..5]
execute at @s run kill @e[type=interaction,tag=ec.ksbag_el,distance=..5]
execute at @s run kill @e[type=item_display,tag=ec.ksbag_el,distance=..5]

# Background panel. (Taller — each family now has a fresh row + a worn/cracked sub-row, Wiring #53.)
execute at @s rotated ~ 0 positioned ^ ^1.35 ^1.8 run summon item_display ~ ~ ~ {Tags:["ec.ksbag_el","ec.ksbag_bg"],billboard:"center",item:{id:"black_stained_glass_pane",count:1},item_display:"fixed",transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,-0.02f],scale:[3.0f,3.4f,0.01f]}}

# Title.
execute at @s rotated ~ 0 positioned ^ ^2.45 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["ec.ksbag_el","ec.ksbag_title"],billboard:"center",text:[{text:"⚙ ",color:"#B87333"},{text:"Key Satchel",color:"#B87333",bold:true},{text:" ⚙",color:"#B87333"}],background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.54f,0.54f,0.54f]}}

# Instruction.
execute at @s rotated ~ 0 positioned ^ ^2.20 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["ec.ksbag_el","ec.ksbag_hint"],billboard:"center",text:[{text:"Deposit your keys, or draw one out",color:"gray",italic:true}],background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.32f,0.32f,0.32f]}}

# --- Dungeon family: label + deposit/withdraw-fresh row + worn/cracked sub-row ---
execute at @s rotated ~ 0 positioned ^ ^1.95 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["ec.ksbag_el","ec.ksbag_dlbl"],billboard:"center",text:[{text:"Dungeon Keys",color:"dark_purple",bold:true}],background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.40f,0.40f,0.40f]}}
# Fresh row: Deposit All (left) + Withdraw fresh (right).
execute at @s rotated ~ 0 positioned ^-0.45 ^1.72 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["ec.ksbag_el","ec.ksbag_ddep_txt"],billboard:"center",text:[{text:"[ ",color:"dark_gray"},{text:"Deposit All",color:"green"},{text:" ]",color:"dark_gray"}],background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[-0.45f,0f,0f],scale:[0.36f,0.36f,0.36f]}}
# [strip] ec.ksbag_el: 0.62w split into 4 x 0.16 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute at @s rotated ~ 0 positioned ^-0.68 ^1.80 ^1.80 run summon interaction ~ ~ ~ {Tags:["ec.ksbag_el","ec.ksbag_ddep"],width:0.16f,height:0.16f,response:1b}
execute at @s rotated ~ 0 positioned ^-0.5267 ^1.80 ^1.80 run summon interaction ~ ~ ~ {Tags:["ec.ksbag_el","ec.ksbag_ddep"],width:0.16f,height:0.16f,response:1b}
execute at @s rotated ~ 0 positioned ^-0.3733 ^1.80 ^1.80 run summon interaction ~ ~ ~ {Tags:["ec.ksbag_el","ec.ksbag_ddep"],width:0.16f,height:0.16f,response:1b}
execute at @s rotated ~ 0 positioned ^-0.22 ^1.80 ^1.80 run summon interaction ~ ~ ~ {Tags:["ec.ksbag_el","ec.ksbag_ddep"],width:0.16f,height:0.16f,response:1b}
execute at @s rotated ~ 0 positioned ^0.45 ^1.72 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["ec.ksbag_el","ec.ksbag_dwd_txt"],billboard:"center",text:[{text:"[ ",color:"dark_gray"},{text:"Withdraw Fresh",color:"gold"},{text:" ]",color:"dark_gray"}],background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0.50f,0f,0f],scale:[0.36f,0.36f,0.36f]}}
# [strip] ec.ksbag_el: 0.62w split into 4 x 0.16 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute at @s rotated ~ 0 positioned ^0.22 ^1.80 ^1.80 run summon interaction ~ ~ ~ {Tags:["ec.ksbag_el","ec.ksbag_dwd"],width:0.16f,height:0.16f,response:1b}
execute at @s rotated ~ 0 positioned ^0.3733 ^1.80 ^1.80 run summon interaction ~ ~ ~ {Tags:["ec.ksbag_el","ec.ksbag_dwd"],width:0.16f,height:0.16f,response:1b}
execute at @s rotated ~ 0 positioned ^0.5267 ^1.80 ^1.80 run summon interaction ~ ~ ~ {Tags:["ec.ksbag_el","ec.ksbag_dwd"],width:0.16f,height:0.16f,response:1b}
execute at @s rotated ~ 0 positioned ^0.68 ^1.80 ^1.80 run summon interaction ~ ~ ~ {Tags:["ec.ksbag_el","ec.ksbag_dwd"],width:0.16f,height:0.16f,response:1b}
# Worn/cracked sub-row: Withdraw Worn (left) + Withdraw Cracked (right).
execute at @s rotated ~ 0 positioned ^-0.45 ^1.55 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["ec.ksbag_el","ec.ksbag_dwdw_txt"],billboard:"center",text:[{text:"[ ",color:"dark_gray"},{text:"Worn",color:"#B87333"},{text:" ]",color:"dark_gray"}],background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[-0.45f,0f,0f],scale:[0.32f,0.32f,0.32f]}}
# [strip] ec.ksbag_el: 0.44w split into 4 x 0.13 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute at @s rotated ~ 0 positioned ^-0.605 ^1.62 ^1.80 run summon interaction ~ ~ ~ {Tags:["ec.ksbag_el","ec.ksbag_dwdw"],width:0.13f,height:0.13f,response:1b}
execute at @s rotated ~ 0 positioned ^-0.5017 ^1.62 ^1.80 run summon interaction ~ ~ ~ {Tags:["ec.ksbag_el","ec.ksbag_dwdw"],width:0.13f,height:0.13f,response:1b}
execute at @s rotated ~ 0 positioned ^-0.3983 ^1.62 ^1.80 run summon interaction ~ ~ ~ {Tags:["ec.ksbag_el","ec.ksbag_dwdw"],width:0.13f,height:0.13f,response:1b}
execute at @s rotated ~ 0 positioned ^-0.295 ^1.62 ^1.80 run summon interaction ~ ~ ~ {Tags:["ec.ksbag_el","ec.ksbag_dwdw"],width:0.13f,height:0.13f,response:1b}
execute at @s rotated ~ 0 positioned ^0.45 ^1.55 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["ec.ksbag_el","ec.ksbag_dwdc_txt"],billboard:"center",text:[{text:"[ ",color:"dark_gray"},{text:"Cracked",color:"#8B5A2B"},{text:" ]",color:"dark_gray"}],background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0.45f,0f,0f],scale:[0.32f,0.32f,0.32f]}}
# [strip] ec.ksbag_el: 0.5w split into 4 x 0.13 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute at @s rotated ~ 0 positioned ^0.265 ^1.62 ^1.80 run summon interaction ~ ~ ~ {Tags:["ec.ksbag_el","ec.ksbag_dwdc"],width:0.13f,height:0.13f,response:1b}
execute at @s rotated ~ 0 positioned ^0.3883 ^1.62 ^1.80 run summon interaction ~ ~ ~ {Tags:["ec.ksbag_el","ec.ksbag_dwdc"],width:0.13f,height:0.13f,response:1b}
execute at @s rotated ~ 0 positioned ^0.5117 ^1.62 ^1.80 run summon interaction ~ ~ ~ {Tags:["ec.ksbag_el","ec.ksbag_dwdc"],width:0.13f,height:0.13f,response:1b}
execute at @s rotated ~ 0 positioned ^0.635 ^1.62 ^1.80 run summon interaction ~ ~ ~ {Tags:["ec.ksbag_el","ec.ksbag_dwdc"],width:0.13f,height:0.13f,response:1b}

# --- Crafting family: label + deposit/withdraw-fresh row + worn/cracked sub-row ---
execute at @s rotated ~ 0 positioned ^ ^1.15 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["ec.ksbag_el","ec.ksbag_clbl"],billboard:"center",text:[{text:"Trial Passes",color:"#FFA500",bold:true}],background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.40f,0.40f,0.40f]}}
# Fresh row: Deposit All (left) + Withdraw fresh (right).
execute at @s rotated ~ 0 positioned ^-0.45 ^0.92 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["ec.ksbag_el","ec.ksbag_cdep_txt"],billboard:"center",text:[{text:"[ ",color:"dark_gray"},{text:"Deposit All",color:"green"},{text:" ]",color:"dark_gray"}],background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[-0.45f,0f,0f],scale:[0.36f,0.36f,0.36f]}}
# [strip] ec.ksbag_el: 0.62w split into 4 x 0.16 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute at @s rotated ~ 0 positioned ^-0.68 ^1.00 ^1.80 run summon interaction ~ ~ ~ {Tags:["ec.ksbag_el","ec.ksbag_cdep"],width:0.16f,height:0.16f,response:1b}
execute at @s rotated ~ 0 positioned ^-0.5267 ^1.00 ^1.80 run summon interaction ~ ~ ~ {Tags:["ec.ksbag_el","ec.ksbag_cdep"],width:0.16f,height:0.16f,response:1b}
execute at @s rotated ~ 0 positioned ^-0.3733 ^1.00 ^1.80 run summon interaction ~ ~ ~ {Tags:["ec.ksbag_el","ec.ksbag_cdep"],width:0.16f,height:0.16f,response:1b}
execute at @s rotated ~ 0 positioned ^-0.22 ^1.00 ^1.80 run summon interaction ~ ~ ~ {Tags:["ec.ksbag_el","ec.ksbag_cdep"],width:0.16f,height:0.16f,response:1b}
execute at @s rotated ~ 0 positioned ^0.45 ^0.92 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["ec.ksbag_el","ec.ksbag_cwd_txt"],billboard:"center",text:[{text:"[ ",color:"dark_gray"},{text:"Withdraw Fresh",color:"gold"},{text:" ]",color:"dark_gray"}],background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0.50f,0f,0f],scale:[0.36f,0.36f,0.36f]}}
# [strip] ec.ksbag_el: 0.62w split into 4 x 0.16 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute at @s rotated ~ 0 positioned ^0.22 ^1.00 ^1.80 run summon interaction ~ ~ ~ {Tags:["ec.ksbag_el","ec.ksbag_cwd"],width:0.16f,height:0.16f,response:1b}
execute at @s rotated ~ 0 positioned ^0.3733 ^1.00 ^1.80 run summon interaction ~ ~ ~ {Tags:["ec.ksbag_el","ec.ksbag_cwd"],width:0.16f,height:0.16f,response:1b}
execute at @s rotated ~ 0 positioned ^0.5267 ^1.00 ^1.80 run summon interaction ~ ~ ~ {Tags:["ec.ksbag_el","ec.ksbag_cwd"],width:0.16f,height:0.16f,response:1b}
execute at @s rotated ~ 0 positioned ^0.68 ^1.00 ^1.80 run summon interaction ~ ~ ~ {Tags:["ec.ksbag_el","ec.ksbag_cwd"],width:0.16f,height:0.16f,response:1b}
# Worn/cracked sub-row: Withdraw Worn (left) + Withdraw Cracked (right).
execute at @s rotated ~ 0 positioned ^-0.45 ^0.75 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["ec.ksbag_el","ec.ksbag_cwdw_txt"],billboard:"center",text:[{text:"[ ",color:"dark_gray"},{text:"Worn",color:"#B87333"},{text:" ]",color:"dark_gray"}],background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[-0.45f,0f,0f],scale:[0.32f,0.32f,0.32f]}}
# [strip] ec.ksbag_el: 0.44w split into 4 x 0.13 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute at @s rotated ~ 0 positioned ^-0.605 ^0.82 ^1.80 run summon interaction ~ ~ ~ {Tags:["ec.ksbag_el","ec.ksbag_cwdw"],width:0.13f,height:0.13f,response:1b}
execute at @s rotated ~ 0 positioned ^-0.5017 ^0.82 ^1.80 run summon interaction ~ ~ ~ {Tags:["ec.ksbag_el","ec.ksbag_cwdw"],width:0.13f,height:0.13f,response:1b}
execute at @s rotated ~ 0 positioned ^-0.3983 ^0.82 ^1.80 run summon interaction ~ ~ ~ {Tags:["ec.ksbag_el","ec.ksbag_cwdw"],width:0.13f,height:0.13f,response:1b}
execute at @s rotated ~ 0 positioned ^-0.295 ^0.82 ^1.80 run summon interaction ~ ~ ~ {Tags:["ec.ksbag_el","ec.ksbag_cwdw"],width:0.13f,height:0.13f,response:1b}
execute at @s rotated ~ 0 positioned ^0.45 ^0.75 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["ec.ksbag_el","ec.ksbag_cwdc_txt"],billboard:"center",text:[{text:"[ ",color:"dark_gray"},{text:"Cracked",color:"#8B5A2B"},{text:" ]",color:"dark_gray"}],background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0.45f,0f,0f],scale:[0.32f,0.32f,0.32f]}}
# [strip] ec.ksbag_el: 0.5w split into 4 x 0.13 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute at @s rotated ~ 0 positioned ^0.265 ^0.82 ^1.80 run summon interaction ~ ~ ~ {Tags:["ec.ksbag_el","ec.ksbag_cwdc"],width:0.13f,height:0.13f,response:1b}
execute at @s rotated ~ 0 positioned ^0.3883 ^0.82 ^1.80 run summon interaction ~ ~ ~ {Tags:["ec.ksbag_el","ec.ksbag_cwdc"],width:0.13f,height:0.13f,response:1b}
execute at @s rotated ~ 0 positioned ^0.5117 ^0.82 ^1.80 run summon interaction ~ ~ ~ {Tags:["ec.ksbag_el","ec.ksbag_cwdc"],width:0.13f,height:0.13f,response:1b}
execute at @s rotated ~ 0 positioned ^0.635 ^0.82 ^1.80 run summon interaction ~ ~ ~ {Tags:["ec.ksbag_el","ec.ksbag_cwdc"],width:0.13f,height:0.13f,response:1b}

# --- Close button ---
execute at @s rotated ~ 0 positioned ^ ^0.45 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["ec.ksbag_el","ec.ksbag_close_txt"],billboard:"center",text:[{text:"[ ",color:"dark_gray"},{text:"Close",color:"gray",bold:true},{text:" ]",color:"dark_gray"}],background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.40f,0.40f,0.40f]}}
# [strip] ec.ksbag_el: 0.5w split into 4 x 0.14 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute at @s rotated ~ 0 positioned ^-0.18 ^0.55 ^1.80 run summon interaction ~ ~ ~ {Tags:["ec.ksbag_el","ec.ksbag_close"],width:0.14f,height:0.14f,response:1b}
execute at @s rotated ~ 0 positioned ^-0.06 ^0.55 ^1.80 run summon interaction ~ ~ ~ {Tags:["ec.ksbag_el","ec.ksbag_close"],width:0.14f,height:0.14f,response:1b}
execute at @s rotated ~ 0 positioned ^0.06 ^0.55 ^1.80 run summon interaction ~ ~ ~ {Tags:["ec.ksbag_el","ec.ksbag_close"],width:0.14f,height:0.14f,response:1b}
execute at @s rotated ~ 0 positioned ^0.18 ^0.55 ^1.80 run summon interaction ~ ~ ~ {Tags:["ec.ksbag_el","ec.ksbag_close"],width:0.14f,height:0.14f,response:1b}

# Session isolation (mirror satchel: stamp a unique gui_session on the player + every element).
scoreboard players add #gui_session ec.var 1
scoreboard players operation @s adv.gui_session = #gui_session ec.var
scoreboard players operation #gui_stamp ec.temp = @s adv.gui_session
execute as @e[type=text_display,tag=ec.ksbag_el,distance=..5] unless score @s adv.gui_session matches 1.. run scoreboard players operation @s adv.gui_session = #gui_stamp ec.temp
execute as @e[type=interaction,tag=ec.ksbag_el,distance=..5] unless score @s adv.gui_session matches 1.. run scoreboard players operation @s adv.gui_session = #gui_stamp ec.temp
execute as @e[type=item_display,tag=ec.ksbag_el,distance=..5] unless score @s adv.gui_session matches 1.. run scoreboard players operation @s adv.gui_session = #gui_stamp ec.temp

execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.chest.open master @s ~ ~ ~ 0.5 1.2

# Refresh the count labels + start the click tick.
function evercraft:key_satchel/menu/refresh
schedule function evercraft:key_satchel/menu_tick 2t replace
