# Key Satchel Menu — check clicks (run as @s with the menu open, at @s). Mirrors satchel/menu/
# check_clicks: for each button interaction, if it was clicked (data .interaction present) by the
# session owner, run the handler + consume the click. Session-gated via adv.gui_session.

scoreboard players operation #gui_owner ec.temp = @s adv.gui_session

# Close button.
execute as @e[type=interaction,tag=ec.ksbag_close,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction on target run function evercraft:key_satchel/menu/close
execute as @e[type=interaction,tag=ec.ksbag_close,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction
execute unless entity @s[tag=ec.ksbag_in_menu] run return 0

# Dungeon — Deposit All.
execute as @e[type=interaction,tag=ec.ksbag_ddep,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction on target run function evercraft:key_satchel/deposit_dungeon
execute as @e[type=interaction,tag=ec.ksbag_ddep,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction
execute unless entity @s[tag=ec.ksbag_in_menu] run return 0

# Dungeon — Withdraw (one fresh).
execute as @e[type=interaction,tag=ec.ksbag_dwd,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction on target run function evercraft:key_satchel/withdraw_dungeon
execute as @e[type=interaction,tag=ec.ksbag_dwd,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction
execute unless entity @s[tag=ec.ksbag_in_menu] run return 0

# Dungeon — Withdraw (one worn).
execute as @e[type=interaction,tag=ec.ksbag_dwdw,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction on target run function evercraft:key_satchel/withdraw_dungeon_worn
execute as @e[type=interaction,tag=ec.ksbag_dwdw,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction
execute unless entity @s[tag=ec.ksbag_in_menu] run return 0

# Dungeon — Withdraw (one cracked).
execute as @e[type=interaction,tag=ec.ksbag_dwdc,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction on target run function evercraft:key_satchel/withdraw_dungeon_cracked
execute as @e[type=interaction,tag=ec.ksbag_dwdc,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction
execute unless entity @s[tag=ec.ksbag_in_menu] run return 0

# Crafting — Deposit All.
execute as @e[type=interaction,tag=ec.ksbag_cdep,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction on target run function evercraft:key_satchel/deposit_crafting
execute as @e[type=interaction,tag=ec.ksbag_cdep,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction
execute unless entity @s[tag=ec.ksbag_in_menu] run return 0

# Crafting — Withdraw (one fresh).
execute as @e[type=interaction,tag=ec.ksbag_cwd,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction on target run function evercraft:key_satchel/withdraw_crafting
execute as @e[type=interaction,tag=ec.ksbag_cwd,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction
execute unless entity @s[tag=ec.ksbag_in_menu] run return 0

# Crafting — Withdraw (one worn).
execute as @e[type=interaction,tag=ec.ksbag_cwdw,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction on target run function evercraft:key_satchel/withdraw_crafting_worn
execute as @e[type=interaction,tag=ec.ksbag_cwdw,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction
execute unless entity @s[tag=ec.ksbag_in_menu] run return 0

# Crafting — Withdraw (one cracked).
execute as @e[type=interaction,tag=ec.ksbag_cwdc,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction on target run function evercraft:key_satchel/withdraw_crafting_cracked
execute as @e[type=interaction,tag=ec.ksbag_cwdc,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction

# ===== INSPECT (left-click = what does this button do?) — gui/inspect pattern 2026-06-11 =====
execute as @e[type=interaction,tag=ec.ksbag_close,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Close",b:"Closes the key satchel."}
execute as @e[type=interaction,tag=ec.ksbag_close,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=ec.ksbag_ddep,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Dungeon Keys — Deposit All",b:"Sweeps every dungeon key you carry into the satchel."}
execute as @e[type=interaction,tag=ec.ksbag_ddep,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=ec.ksbag_dwd,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Dungeon Keys — Withdraw Fresh",b:"Takes one fresh dungeon key back out."}
execute as @e[type=interaction,tag=ec.ksbag_dwd,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=ec.ksbag_dwdw,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Dungeon Keys — Withdraw Worn",b:"Takes one worn dungeon key back out."}
execute as @e[type=interaction,tag=ec.ksbag_dwdw,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=ec.ksbag_dwdc,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Dungeon Keys — Withdraw Cracked",b:"Takes one cracked dungeon key back out."}
execute as @e[type=interaction,tag=ec.ksbag_dwdc,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=ec.ksbag_cdep,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Crafting Keys — Deposit All",b:"Sweeps every crafting key you carry into the satchel."}
execute as @e[type=interaction,tag=ec.ksbag_cdep,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=ec.ksbag_cwd,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Crafting Keys — Withdraw Fresh",b:"Takes one fresh crafting key back out."}
execute as @e[type=interaction,tag=ec.ksbag_cwd,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=ec.ksbag_cwdw,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Crafting Keys — Withdraw Worn",b:"Takes one worn crafting key back out."}
execute as @e[type=interaction,tag=ec.ksbag_cwdw,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=ec.ksbag_cwdc,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Crafting Keys — Withdraw Cracked",b:"Takes one cracked crafting key back out."}
execute as @e[type=interaction,tag=ec.ksbag_cwdc,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack run data remove entity @s attack
