# Key Satchel Menu — per-player tick (run as @s with the menu open). Closes the menu if the player
# walked away from the panel OR no longer holds the bag, then checks for clicks. Mirrors
# satchel/menu/tick.

# Close if the player walked too far from the panel.
execute unless entity @e[type=item_display,tag=ec.ksbag_bg,distance=..5] run function evercraft:key_satchel/menu/close
execute unless entity @s[tag=ec.ksbag_in_menu] run return 0

# Close if the bag is no longer held (mainhand or offhand).
execute unless items entity @s weapon.mainhand *[custom_data~{key_bag:true}] unless items entity @s weapon.offhand *[custom_data~{key_bag:true}] run function evercraft:key_satchel/menu/close
execute unless entity @s[tag=ec.ksbag_in_menu] run return 0

# Unified UI-click FX (Joseph 2026-06-05): play the gated cue ONCE if any ec.ksbag_el element registered
# a click this tick, before check_clicks consumes it.
execute if entity @e[type=interaction,tag=ec.ksbag_el,distance=..6,nbt={interaction:{}},limit=1] run function evercraft:fx/ui/click

# Check clicks.
function evercraft:key_satchel/menu/check_clicks
