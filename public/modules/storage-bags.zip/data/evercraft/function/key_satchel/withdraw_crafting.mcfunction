# === KEY SATCHEL — WITHDRAW ONE FRESH TRIAL PASS (Chest-Node §4) ===
# Run as @s = player (from the menu). Mirror of withdraw_dungeon for the crafting key family. If the
# held bag holds at least one FRESH trial pass, give one fresh Trial Pass + decrement ks_cfresh by 1
# (and clear ks_chas if that empties the fresh stock). Writes IN PLACE via set_custom_data (per hand).

scoreboard players set #ks_cur_f ec.temp 0
execute if items entity @s weapon.mainhand *[custom_data~{key_bag:true}] store result score #ks_cur_f ec.temp run data get entity @s SelectedItem.components."minecraft:custom_data".ks_cfresh
execute unless items entity @s weapon.mainhand *[custom_data~{key_bag:true}] store result score #ks_cur_f ec.temp run data get entity @s Inventory[{Slot:-106b}].components."minecraft:custom_data".ks_cfresh

execute if score #ks_cur_f ec.temp matches ..0 if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 0.5 0.8
execute if score #ks_cur_f ec.temp matches ..0 run return 0

# Inv-full guard: drop at the player's feet rather than void on a full inventory.
execute store result score #inv_full ec.var run function evercraft:util/check_inv_full
execute if score #inv_full ec.var matches 0 run loot give @s loot evercraft:craftforever/trials/trial_pass
execute if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:craftforever/trials/trial_pass
scoreboard players remove #ks_cur_f ec.temp 1
scoreboard players set #ks_has ec.temp 0
execute if score #ks_cur_f ec.temp matches 1.. run scoreboard players set #ks_has ec.temp 1

execute if items entity @s weapon.mainhand *[custom_data~{key_bag:true}] run data modify storage evercraft:ksbag w.hand set value "mainhand"
execute unless items entity @s weapon.mainhand *[custom_data~{key_bag:true}] run data modify storage evercraft:ksbag w.hand set value "offhand"
execute store result storage evercraft:ksbag w.cf int 1 run scoreboard players get #ks_cur_f ec.temp
execute store result storage evercraft:ksbag w.ch int 1 run scoreboard players get #ks_has ec.temp
function evercraft:key_satchel/wd_fresh_crafting with storage evercraft:ksbag w

execute if score @s ec.fx_snd matches 1.. run playsound minecraft:item.bundle.remove_one master @s ~ ~ ~ 0.8 1.2
function evercraft:key_satchel/menu/refresh
