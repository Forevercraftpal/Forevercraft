# === KEY SATCHEL — SNEAK-RC TALLY (Chest-Node §4) ===
# Run as @s = player. Shows an actionbar tally of the held key bag's six on-item counts: FRESH
# prominent (the keys that still open chests + boost spawn), with worn/cracked in parentheses. Mirrors
# the SPEC §4 example "Dungeon 4 (+2 worn) · Crafting 3". The bag is in mainhand (SelectedItem) or
# offhand. Read each count into a temp score, then build the actionbar text from storage with the
# numbers stored as ints (a text-component with score refs over fakeplayers).
#
# Counts are read off the SelectedItem first (mainhand); if the held bag is in the offhand instead, the
# offhand read overwrites. ONE-shot read (no scheduling). All six default to 0 when the field is absent.

# Reset the six tally fakeplayers.
scoreboard players set #ksdf ec.temp 0
scoreboard players set #ksdw ec.temp 0
scoreboard players set #ksdc ec.temp 0
scoreboard players set #kscf ec.temp 0
scoreboard players set #kscw ec.temp 0
scoreboard players set #kscc ec.temp 0

# Read from mainhand (SelectedItem) if the bag is held there.
execute if items entity @s weapon.mainhand *[custom_data~{key_bag:true}] store result score #ksdf ec.temp run data get entity @s SelectedItem.components."minecraft:custom_data".ks_dfresh
execute if items entity @s weapon.mainhand *[custom_data~{key_bag:true}] store result score #ksdw ec.temp run data get entity @s SelectedItem.components."minecraft:custom_data".ks_dworn
execute if items entity @s weapon.mainhand *[custom_data~{key_bag:true}] store result score #ksdc ec.temp run data get entity @s SelectedItem.components."minecraft:custom_data".ks_dcrack
execute if items entity @s weapon.mainhand *[custom_data~{key_bag:true}] store result score #kscf ec.temp run data get entity @s SelectedItem.components."minecraft:custom_data".ks_cfresh
execute if items entity @s weapon.mainhand *[custom_data~{key_bag:true}] store result score #kscw ec.temp run data get entity @s SelectedItem.components."minecraft:custom_data".ks_cworn
execute if items entity @s weapon.mainhand *[custom_data~{key_bag:true}] store result score #kscc ec.temp run data get entity @s SelectedItem.components."minecraft:custom_data".ks_ccrack

# Else read from offhand (the bag is held in the offhand).
execute unless items entity @s weapon.mainhand *[custom_data~{key_bag:true}] if items entity @s weapon.offhand *[custom_data~{key_bag:true}] store result score #ksdf ec.temp run data get entity @s Inventory[{Slot:-106b}].components."minecraft:custom_data".ks_dfresh
execute unless items entity @s weapon.mainhand *[custom_data~{key_bag:true}] if items entity @s weapon.offhand *[custom_data~{key_bag:true}] store result score #ksdw ec.temp run data get entity @s Inventory[{Slot:-106b}].components."minecraft:custom_data".ks_dworn
execute unless items entity @s weapon.mainhand *[custom_data~{key_bag:true}] if items entity @s weapon.offhand *[custom_data~{key_bag:true}] store result score #ksdc ec.temp run data get entity @s Inventory[{Slot:-106b}].components."minecraft:custom_data".ks_dcrack
execute unless items entity @s weapon.mainhand *[custom_data~{key_bag:true}] if items entity @s weapon.offhand *[custom_data~{key_bag:true}] store result score #kscf ec.temp run data get entity @s Inventory[{Slot:-106b}].components."minecraft:custom_data".ks_cfresh
execute unless items entity @s weapon.mainhand *[custom_data~{key_bag:true}] if items entity @s weapon.offhand *[custom_data~{key_bag:true}] store result score #kscw ec.temp run data get entity @s Inventory[{Slot:-106b}].components."minecraft:custom_data".ks_cworn
execute unless items entity @s weapon.mainhand *[custom_data~{key_bag:true}] if items entity @s weapon.offhand *[custom_data~{key_bag:true}] store result score #kscc ec.temp run data get entity @s Inventory[{Slot:-106b}].components."minecraft:custom_data".ks_ccrack

# Build + show the actionbar tally. Fresh prominent (copper), worn/cracked muted in parens.
data modify storage evercraft:notify stage.c set value [{text:"⚙ ",color:"#B87333"},{text:"Dungeon ",color:"gray"},{score:{name:"#ksdf",objective:"ec.temp"},color:"#B87333"},{text:" (",color:"dark_gray"},{score:{name:"#ksdw",objective:"ec.temp"},color:"gray"},{text:"w ",color:"dark_gray"},{score:{name:"#ksdc",objective:"ec.temp"},color:"gray"},{text:"c)",color:"dark_gray"},{text:"  ·  ",color:"dark_gray"},{text:"Crafting ",color:"gray"},{score:{name:"#kscf",objective:"ec.temp"},color:"#B87333"},{text:" (",color:"dark_gray"},{score:{name:"#kscw",objective:"ec.temp"},color:"gray"},{text:"w ",color:"dark_gray"},{score:{name:"#kscc",objective:"ec.temp"},color:"gray"},{text:"c)",color:"dark_gray"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:item.bundle.insert master @s ~ ~ ~ 0.7 1.3
