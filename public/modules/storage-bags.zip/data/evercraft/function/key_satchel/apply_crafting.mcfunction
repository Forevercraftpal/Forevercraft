# === KEY SATCHEL — APPLY CRAFTING COUNTS (macro, Chest-Node §4) ===
# Macro body — called `with storage evercraft:ksbag w` where w = {hand, cf, cw, cc, ch}. Mirror of
# apply_dungeon for the crafting key family: write the new crafting counts + the ks_chas presence flag
# onto the held bag IN PLACE via set_custom_data (MERGE, so the dungeon counts + bag_tier survive).
$item modify entity @s weapon.$(hand) {"function":"minecraft:set_custom_data","tag":"{ks_cfresh:$(cf),ks_cworn:$(cw),ks_ccrack:$(cc),ks_chas:$(ch)}"}
