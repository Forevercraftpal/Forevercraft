# === KEY SATCHEL — APPLY WITHDRAWN CRAFTING WORN COUNT (macro, Wiring #53) ===
# Macro body — called `with storage evercraft:ksbag w` where w = {hand, cw}. Writes the decremented
# ks_cworn onto the held bag IN PLACE via set_custom_data (MERGE — the fresh/cracked crafting counts +
# dungeon counts + bag_tier survive). No presence flag (only fresh tracks ks_chas).
$item modify entity @s weapon.$(hand) {"function":"minecraft:set_custom_data","tag":"{ks_cworn:$(cw)}"}
