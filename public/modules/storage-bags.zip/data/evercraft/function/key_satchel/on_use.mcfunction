# === KEY SATCHEL (Key Ring / Bag of Keys) — RC DISPATCH (Chest-Node §4) ===
# Run as @s = player. Fired by the key_satchel/use using_item advancement when the player right-clicks
# a held {key_bag:true} item. Branches on sneak (predicate evercraft:is_sneaking):
#   • SNEAK    -> actionbar key tally (fresh prominent, e.g. "Dungeon 4 (+2 worn) · Crafting 3").
#   • NON-SNEAK-> open the deposit/use menu (mirror satchel/menu/).
# Revoke+re-arm so a single click fires exactly once (clone of the satchel / monocle RC idiom).

advancement revoke @s only evercraft:key_satchel/use

# Only fire from a held slot (mainhand or offhand) — never a stray copy in a container.
execute unless items entity @s weapon.mainhand *[custom_data~{key_bag:true}] unless items entity @s weapon.offhand *[custom_data~{key_bag:true}] run return fail

# SNEAK -> tally; NON-SNEAK -> menu.
execute if predicate evercraft:is_sneaking run function evercraft:key_satchel/tally
execute unless predicate evercraft:is_sneaking at @s run function evercraft:key_satchel/menu/open
