# === KEY SATCHEL — APPLY DUNGEON COUNTS (macro, Chest-Node §4) ===
# Macro body — called `with storage evercraft:ksbag w` where w = {hand, df, dw, dc, dh}. Writes the new
# dungeon counts + the ks_dhas presence flag onto the held bag IN PLACE via set_custom_data (MERGE, so
# the crafting counts + bag_tier survive). The canonical in-place held-item mutation (precedent:
# portal_dial/apply_gs_bind) — writing to SelectedItem.components does not persist.
$item modify entity @s weapon.$(hand) {"function":"minecraft:set_custom_data","tag":"{ks_dfresh:$(df),ks_dworn:$(dw),ks_dcrack:$(dc),ks_dhas:$(dh)}"}
