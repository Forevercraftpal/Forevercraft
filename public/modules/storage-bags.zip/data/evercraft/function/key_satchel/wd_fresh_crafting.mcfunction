# === KEY SATCHEL — APPLY WITHDRAWN CRAFTING FRESH COUNT (macro, Chest-Node §4) ===
# Macro body — called `with storage evercraft:ksbag w` where w = {hand, cf, ch}. Mirror of
# wd_fresh_dungeon for the crafting family: write the decremented ks_cfresh + the ks_chas presence flag
# onto the held bag IN PLACE via set_custom_data (MERGE).
$item modify entity @s weapon.$(hand) {"function":"minecraft:set_custom_data","tag":"{ks_cfresh:$(cf),ks_chas:$(ch)}"}
