# === ACCESSORY-CRATE RESOLVER (P4a — the real 3-set resolver) ===
# Run as @s, at the player. The chest crate channel rolled "Accessory crate" (guaranteed an accessory,
# §6/A3). Loot tables can't read scores, which is WHY this resolver is a function: it picks the SET by
# key/chronicle, rolls a TIER, then hands the player that Accessory Crate ITEM (crates/items/
# accessory_<set>_<tier>) — a barrel they place; crate_anim reveals the accessory. Depth<=1: the crate
# item resolves to an ACCESSORY (never another chest-crate).
#
# Callers (crate_channel / dreamy_crate) pre-set:
#   #cn_ctype  ec.temp  — chest type stamped on the node (1=Crafting / 2=Adventurer / 3=plain), already
#                         weighted by ec.cn_keytype at spawn (Dungeon Key -> 2 / Trial Pass -> 1).
#   #cn_invfull ec.var  — 1 if inventory full (drop) / 0 (give).
#
# SET (#cn_accset ec.temp — sole writer here): Dungeon-Key/Adventurer chest leans Adventurer 70 / craft
# 20 / reg 10; Trial-Pass/Crafting chest leans Crafting 70 / adv 20 / reg 10; plain chest -> Regular
# (the reg set is itself a neutral + 50/50 adventure/craft blend, §6). The 70/30 leaning still allows
# all three sets so cross-chronicle accessories remain possible (§6: "allow any of the three types").

# --- Pick the SET by chest type ---
scoreboard players set #cn_accset ec.temp 3
execute store result score #cn_setroll ec.temp run random value 1..100

# Adventurer-leaning chest (#cn_ctype == 2): 70 adv / 20 craft / 10 reg
execute if score #cn_ctype ec.temp matches 2 if score #cn_setroll ec.temp matches 1..70 run scoreboard players set #cn_accset ec.temp 1
execute if score #cn_ctype ec.temp matches 2 if score #cn_setroll ec.temp matches 71..90 run scoreboard players set #cn_accset ec.temp 2
execute if score #cn_ctype ec.temp matches 2 if score #cn_setroll ec.temp matches 91..100 run scoreboard players set #cn_accset ec.temp 3

# Crafting-leaning chest (#cn_ctype == 1): 70 craft / 20 adv / 10 reg
execute if score #cn_ctype ec.temp matches 1 if score #cn_setroll ec.temp matches 1..70 run scoreboard players set #cn_accset ec.temp 2
execute if score #cn_ctype ec.temp matches 1 if score #cn_setroll ec.temp matches 71..90 run scoreboard players set #cn_accset ec.temp 1
execute if score #cn_ctype ec.temp matches 1 if score #cn_setroll ec.temp matches 91..100 run scoreboard players set #cn_accset ec.temp 3

# Plain chest (#cn_ctype == 3 or 0): Regular set by default. If the player is on EXACTLY one chronicle,
# bias to that chronicle's set; if on both (or neither), keep Regular (its internal 50/50 blend, §14.3).
execute unless score #cn_ctype ec.temp matches 1..2 if score @s ec.dream_rank matches 1.. unless score @s ec.cf_rank matches 1.. run scoreboard players set #cn_accset ec.temp 1
execute unless score #cn_ctype ec.temp matches 1..2 if score @s ec.cf_rank matches 1.. unless score @s ec.dream_rank matches 1.. run scoreboard players set #cn_accset ec.temp 2

# --- Roll the TIER (mirrors the artifact-crate "rare-floor with flourishes" shape) ---
# common 55 / uncommon 25 / rare 12 / ornate 5 / exquisite 2 / mythical 1
execute store result score #cn_acctier ec.temp run random value 1..100

# DR down-roll (crate DR audit 2026-06-06): cap the rolled tier to the opener's Dream Rate, matching
# mob/fishing/harvest gating (Ornate>=5 / Exquisite>=15 / Mythical>=25; luck x10 = 50/150/250). Clamp the
# 1..100 roll down to the TOP of the highest tier they qualify for (rare ..92 / ornate ..97 / exq ..99).
execute store result score #cn_dr ec.temp run attribute @s luck get 10
execute if score #cn_dr ec.temp matches ..49 if score #cn_acctier ec.temp matches 93.. run scoreboard players set #cn_acctier ec.temp 92
execute if score #cn_dr ec.temp matches ..149 if score #cn_acctier ec.temp matches 98.. run scoreboard players set #cn_acctier ec.temp 97
execute if score #cn_dr ec.temp matches ..249 if score #cn_acctier ec.temp matches 100 run scoreboard players set #cn_acctier ec.temp 99

# --- Hand the matching Accessory Crate item (give if inv has room, else drop at feet) ---
# ADV set
execute if score #cn_accset ec.temp matches 1 if score #cn_acctier ec.temp matches 1..55 if score #cn_invfull ec.var matches 0 run loot give @s loot evercraft:crates/items/accessory_adv_common
execute if score #cn_accset ec.temp matches 1 if score #cn_acctier ec.temp matches 1..55 if score #cn_invfull ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:crates/items/accessory_adv_common
execute if score #cn_accset ec.temp matches 1 if score #cn_acctier ec.temp matches 56..80 if score #cn_invfull ec.var matches 0 run loot give @s loot evercraft:crates/items/accessory_adv_uncommon
execute if score #cn_accset ec.temp matches 1 if score #cn_acctier ec.temp matches 56..80 if score #cn_invfull ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:crates/items/accessory_adv_uncommon
execute if score #cn_accset ec.temp matches 1 if score #cn_acctier ec.temp matches 81..92 if score #cn_invfull ec.var matches 0 run loot give @s loot evercraft:crates/items/accessory_adv_rare
execute if score #cn_accset ec.temp matches 1 if score #cn_acctier ec.temp matches 81..92 if score #cn_invfull ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:crates/items/accessory_adv_rare
execute if score #cn_accset ec.temp matches 1 if score #cn_acctier ec.temp matches 93..97 if score #cn_invfull ec.var matches 0 run loot give @s loot evercraft:crates/items/accessory_adv_ornate
execute if score #cn_accset ec.temp matches 1 if score #cn_acctier ec.temp matches 93..97 if score #cn_invfull ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:crates/items/accessory_adv_ornate
execute if score #cn_accset ec.temp matches 1 if score #cn_acctier ec.temp matches 98..99 if score #cn_invfull ec.var matches 0 run loot give @s loot evercraft:crates/items/accessory_adv_exquisite
execute if score #cn_accset ec.temp matches 1 if score #cn_acctier ec.temp matches 98..99 if score #cn_invfull ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:crates/items/accessory_adv_exquisite
execute if score #cn_accset ec.temp matches 1 if score #cn_acctier ec.temp matches 100 if score #cn_invfull ec.var matches 0 run loot give @s loot evercraft:crates/items/accessory_adv_mythical
execute if score #cn_accset ec.temp matches 1 if score #cn_acctier ec.temp matches 100 if score #cn_invfull ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:crates/items/accessory_adv_mythical
# CRAFT set
execute if score #cn_accset ec.temp matches 2 if score #cn_acctier ec.temp matches 1..55 if score #cn_invfull ec.var matches 0 run loot give @s loot evercraft:crates/items/accessory_craft_common
execute if score #cn_accset ec.temp matches 2 if score #cn_acctier ec.temp matches 1..55 if score #cn_invfull ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:crates/items/accessory_craft_common
execute if score #cn_accset ec.temp matches 2 if score #cn_acctier ec.temp matches 56..80 if score #cn_invfull ec.var matches 0 run loot give @s loot evercraft:crates/items/accessory_craft_uncommon
execute if score #cn_accset ec.temp matches 2 if score #cn_acctier ec.temp matches 56..80 if score #cn_invfull ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:crates/items/accessory_craft_uncommon
execute if score #cn_accset ec.temp matches 2 if score #cn_acctier ec.temp matches 81..92 if score #cn_invfull ec.var matches 0 run loot give @s loot evercraft:crates/items/accessory_craft_rare
execute if score #cn_accset ec.temp matches 2 if score #cn_acctier ec.temp matches 81..92 if score #cn_invfull ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:crates/items/accessory_craft_rare
execute if score #cn_accset ec.temp matches 2 if score #cn_acctier ec.temp matches 93..97 if score #cn_invfull ec.var matches 0 run loot give @s loot evercraft:crates/items/accessory_craft_ornate
execute if score #cn_accset ec.temp matches 2 if score #cn_acctier ec.temp matches 93..97 if score #cn_invfull ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:crates/items/accessory_craft_ornate
execute if score #cn_accset ec.temp matches 2 if score #cn_acctier ec.temp matches 98..99 if score #cn_invfull ec.var matches 0 run loot give @s loot evercraft:crates/items/accessory_craft_exquisite
execute if score #cn_accset ec.temp matches 2 if score #cn_acctier ec.temp matches 98..99 if score #cn_invfull ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:crates/items/accessory_craft_exquisite
execute if score #cn_accset ec.temp matches 2 if score #cn_acctier ec.temp matches 100 if score #cn_invfull ec.var matches 0 run loot give @s loot evercraft:crates/items/accessory_craft_mythical
execute if score #cn_accset ec.temp matches 2 if score #cn_acctier ec.temp matches 100 if score #cn_invfull ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:crates/items/accessory_craft_mythical
# REG set
execute if score #cn_accset ec.temp matches 3 if score #cn_acctier ec.temp matches 1..55 if score #cn_invfull ec.var matches 0 run loot give @s loot evercraft:crates/items/accessory_reg_common
execute if score #cn_accset ec.temp matches 3 if score #cn_acctier ec.temp matches 1..55 if score #cn_invfull ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:crates/items/accessory_reg_common
execute if score #cn_accset ec.temp matches 3 if score #cn_acctier ec.temp matches 56..80 if score #cn_invfull ec.var matches 0 run loot give @s loot evercraft:crates/items/accessory_reg_uncommon
execute if score #cn_accset ec.temp matches 3 if score #cn_acctier ec.temp matches 56..80 if score #cn_invfull ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:crates/items/accessory_reg_uncommon
execute if score #cn_accset ec.temp matches 3 if score #cn_acctier ec.temp matches 81..92 if score #cn_invfull ec.var matches 0 run loot give @s loot evercraft:crates/items/accessory_reg_rare
execute if score #cn_accset ec.temp matches 3 if score #cn_acctier ec.temp matches 81..92 if score #cn_invfull ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:crates/items/accessory_reg_rare
execute if score #cn_accset ec.temp matches 3 if score #cn_acctier ec.temp matches 93..97 if score #cn_invfull ec.var matches 0 run loot give @s loot evercraft:crates/items/accessory_reg_ornate
execute if score #cn_accset ec.temp matches 3 if score #cn_acctier ec.temp matches 93..97 if score #cn_invfull ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:crates/items/accessory_reg_ornate
execute if score #cn_accset ec.temp matches 3 if score #cn_acctier ec.temp matches 98..99 if score #cn_invfull ec.var matches 0 run loot give @s loot evercraft:crates/items/accessory_reg_exquisite
execute if score #cn_accset ec.temp matches 3 if score #cn_acctier ec.temp matches 98..99 if score #cn_invfull ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:crates/items/accessory_reg_exquisite
execute if score #cn_accset ec.temp matches 3 if score #cn_acctier ec.temp matches 100 if score #cn_invfull ec.var matches 0 run loot give @s loot evercraft:crates/items/accessory_reg_mythical
execute if score #cn_accset ec.temp matches 3 if score #cn_acctier ec.temp matches 100 if score #cn_invfull ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:crates/items/accessory_reg_mythical

function evercraft:tinkering/chest_drop/crate_flourish
