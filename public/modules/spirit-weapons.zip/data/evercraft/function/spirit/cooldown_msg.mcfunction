# Spirit Artifact — Cooldown message when ability is on CD
# Run as @s (the player)

execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bass player @s ~ ~ ~ 0.5 0.5
data modify storage evercraft:notify stage.c set value [{text:"Ability on cooldown",color:"red"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
