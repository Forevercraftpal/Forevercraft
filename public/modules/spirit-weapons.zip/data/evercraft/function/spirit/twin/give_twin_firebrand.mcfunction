# Dream Storm Crystal — Reveal Aqualoch (Firebrand's Twin)

# VFX — twin revelation
playsound minecraft:entity.lightning_bolt.thunder player @a[scores={ec.fx_snd=1..}] ~ ~ ~ 1.0 0.8
playsound minecraft:entity.warden.sonic_boom player @a[scores={ec.fx_snd=1..}] ~ ~ ~ 0.6 1.8
particle explosion_emitter ~ ~1 ~ 0 0 0 1 1
particle dust{color:[0.2,0.6,1.0],scale:2.0} ~ ~1.5 ~ 2 2 2 0.05 30
particle minecraft:flash{color:[1.0,1.0,1.0,1.0]} ~ ~1 ~ 0 0 0 0 1

# Give the twin weapon
# Inv-full guard: drop at the player's feet rather than void on a full inventory.
execute store result score #inv_full ec.var run function evercraft:util/check_inv_full
execute if score #inv_full ec.var matches 0 run loot give @s loot evercraft:spirit/twin/aqualoch
execute if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:spirit/twin/aqualoch

# Mark the original as having a twin
data modify storage evercraft:temp crystal_offhand set from entity @s equipment.offhand
data modify storage evercraft:temp crystal_offhand.components."minecraft:custom_data".spirit_twin set value true
summon hopper_minecart ~ 320 ~ {Tags:["ec.sp_temp"],Items:[{Slot:0b,id:"minecraft:stone",count:1}]}
data modify entity @e[type=hopper_minecart,tag=ec.sp_temp,limit=1] Items[0] set from storage evercraft:temp crystal_offhand
item replace entity @s weapon.offhand from entity @e[type=hopper_minecart,tag=ec.sp_temp,limit=1] container.0
data modify entity @e[type=hopper_minecart,tag=ec.sp_temp,limit=1] Items set value []
kill @e[type=hopper_minecart,tag=ec.sp_temp]

# (AB-1 sticky-times sweep 2026-06-10: explicit stamp — `title times` is sticky per player and this sequence set none, so it inherited whatever ran last.)
title @s times 10 60 20
title @s title [{"text":"AQUALOCH","color":"aqua"}]
title @s subtitle [{"text":"The twin awakens...","color":"dark_aqua"}]
data modify storage evercraft:notify stage.c set value [{text:"The Firebrand's twin, ",color:"light_purple"},{text:"Aqualoch",color:"aqua",bold:true},{text:", has been revealed!",color:"light_purple"}]
scoreboard players set #ndur ec.temp 50
function evercraft:util/notify/emit

# Server-wide announcement (§5b — names the actor, direct render so {selector:"@s"} resolves once).
# Generic "═══ TWIN AWAKENED ═══" header dropped: the named brag subsumes it and a queued @a
# header would overwrite this same-tick direct title write (Wave 3 precedent).
execute as @s run function evercraft:util/notify/whoami
data modify storage evercraft:notify stage.c set value [{text:"★ TWIN AWAKENED — ",color:"gold"},{text:""},{text:" revealed ",color:"gray"},{text:"Aqualoch",color:"aqua",bold:true},{text:"! ★",color:"gold"}]
data modify storage evercraft:notify stage.c[1].text set from storage evercraft:notify named.who
scoreboard players set #ndur ec.temp 50
execute as @s run execute as @a run scoreboard players set #nttl ec.temp 600
execute as @s run execute as @a run function evercraft:util/notify/emit_keep
tag @s remove ec.sp_crystal_pending
