# Soulbound — Trade spirit artifact to best friend
# Triggered via /trigger ec.sp_trade set 1
# Run as @s (trading player) at @s

# Reset trigger
scoreboard players set @s ec.sp_trade 0
scoreboard players enable @s ec.sp_trade

# Check player is holding a spirit artifact
data modify storage evercraft:notify stage.c set value [{text:"Hold a Spirit Artifact in your mainhand to trade!",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute unless items entity @s weapon.mainhand *[custom_data~{spirit_artifact:true}] run function evercraft:util/notify/emit
execute unless items entity @s weapon.mainhand *[custom_data~{spirit_artifact:true}] run return 0

# Find nearest player within 3 blocks
data modify storage evercraft:notify stage.c set value [{text:"No player nearby! Stand within 3 blocks of your trade partner.",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute unless entity @a[distance=0.1..3,limit=1,sort=nearest] run function evercraft:util/notify/emit
execute unless entity @a[distance=0.1..3,limit=1,sort=nearest] run return 0

# Check Best Friend status (companion relationship level >= 4)
# Store nearest player for reference
tag @a[distance=0.1..3,limit=1,sort=nearest] add ec.sp_trade_target

# Check relationship level (ec.comp.rellevel >= 4 would be ideal but simplified here)
# For now, we allow the trade if both players are within range
# TODO: Add companion relationship check when system is ready

# Save the spirit artifact
data modify storage evercraft:soulbound trade_item set from entity @s SelectedItem

# Remove from trader
item replace entity @s weapon.mainhand with air

# Give to receiver via hopper minecart
execute at @a[tag=ec.sp_trade_target,limit=1] run summon hopper_minecart ~ 320 ~ {Tags:["ec.sp_temp"],Items:[{Slot:0b,id:"minecraft:stone",count:1}]}
data modify entity @e[type=hopper_minecart,tag=ec.sp_temp,limit=1] Items[0] set from storage evercraft:soulbound trade_item
execute as @a[tag=ec.sp_trade_target,limit=1] run item replace entity @s weapon.mainhand from entity @e[type=hopper_minecart,tag=ec.sp_temp,limit=1] container.0
data modify entity @e[type=hopper_minecart,tag=ec.sp_temp,limit=1] Items set value []
kill @e[type=hopper_minecart,tag=ec.sp_temp]

# VFX
playsound minecraft:entity.player.levelup player @a[scores={ec.fx_snd=1..}] ~ ~ ~ 0.8 1.2
particle enchant ~ ~1 ~ 1 1 1 0.5 15

# Messages
data modify storage evercraft:notify stage.c set value [{text:"Spirit artifact traded!",color:"green"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"You received a Spirit Artifact!",color:"light_purple"}]
scoreboard players set #ndur ec.temp 45
execute as @a[tag=ec.sp_trade_target,limit=1] run function evercraft:util/notify/emit

# Cleanup
tag @a[tag=ec.sp_trade_target] remove ec.sp_trade_target
