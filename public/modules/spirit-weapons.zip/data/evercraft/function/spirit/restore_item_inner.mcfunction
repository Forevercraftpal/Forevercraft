# Spirit — Restore consumed item via per-player hopper minecart (macro inner)
# Args from storage evercraft:spirit cart:
#   pid = adv.gui_session (per-player session id)
# Wiring Audit #13 P0-5 / AR-P0-3 spirit-extension — paired with restore_item.mcfunction.
# Mirrors evercraft:artifacts/healer/do_restore_inner:8-19 pattern.
# Per-player cart tag (ec.sp_temp.$(pid)) + per-player storage path eliminate cross-player
# race where two players' carts get swapped when both consume in same tick.
$data modify entity @e[type=hopper_minecart,tag=ec.sp_temp.$(pid),limit=1] Items set value []
$kill @e[type=hopper_minecart,tag=ec.sp_temp.$(pid)]
$summon hopper_minecart ~ 320 ~ {Tags:["ec.sp_temp","ec.sp_temp.$(pid)"],Items:[{Slot:0b,id:"minecraft:stone",count:1}]}
$data modify entity @e[type=hopper_minecart,tag=ec.sp_temp.$(pid),limit=1] Items[0] set from storage evercraft:item_restore spirit_weapon.$(pid)

$execute if entity @s[tag=ec.sp_restore_offhand] run item replace entity @s weapon.offhand from entity @e[type=hopper_minecart,tag=ec.sp_temp.$(pid),limit=1] container.0
$execute unless entity @s[tag=ec.sp_restore_offhand] run item replace entity @s weapon.mainhand from entity @e[type=hopper_minecart,tag=ec.sp_temp.$(pid),limit=1] container.0

$data modify entity @e[type=hopper_minecart,tag=ec.sp_temp.$(pid),limit=1] Items set value []
$kill @e[type=hopper_minecart,tag=ec.sp_temp.$(pid)]
