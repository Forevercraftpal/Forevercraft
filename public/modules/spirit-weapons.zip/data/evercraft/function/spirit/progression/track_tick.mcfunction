# Spirit Progression — Per-Tick Tracking
# Called from spirit/tick.mcfunction for active spirit weapon holders
# Handles: survival timer, kill streak reset, damage taken tracking

# === SURVIVAL TIMER ===
# Increment survive counter every 1200 ticks (1 minute)
scoreboard players add #sp_survive_timer ec.var 1
execute if score #sp_survive_timer ec.var matches 1200.. run scoreboard players set #sp_survive_timer ec.var 0
execute if score #sp_survive_timer ec.var matches 0 as @a[tag=ec.sp_active] run scoreboard players add @s ec.sp_survive 1

# === DAMAGE TAKEN + KILL STREAK (consolidated — single NBT read) ===
# Tag players who just took damage (HurtTime=10s = fresh damage frame)
# OPT: Single NBT scan instead of two separate @a[nbt=] evaluations
tag @a[tag=ec.sp_active,nbt={HurtTime:10s}] add ec.sp_just_hurt
execute as @a[tag=ec.sp_just_hurt] run scoreboard players add @s ec.sp_damage_taken 1
execute as @a[tag=ec.sp_just_hurt] run scoreboard players set @s ec.sp_cur_streak 0
# Flawless-boss latch: if a hurt spirit-wielder is currently in a raid boss fight, mark that
# this fight is no longer damage-free (checked on boss death in raids/boss/on_death).
scoreboard players set @a[tag=ec.sp_just_hurt,tag=ec.rd_participant] ec.sp_boss_hurt 1
tag @a[tag=ec.sp_just_hurt] remove ec.sp_just_hurt

# === DEATHLESS HOURS (Bulwark) ===
# Every 72000 ticks = 1 hour (real time via gametime)
scoreboard players add #sp_deathless_timer ec.var 1
execute if score #sp_deathless_timer ec.var matches 72000.. run scoreboard players set #sp_deathless_timer ec.var 0
execute if score #sp_deathless_timer ec.var matches 0 as @a[tag=ec.sp_active] run scoreboard players add @s ec.sp_deathless_hours 1
