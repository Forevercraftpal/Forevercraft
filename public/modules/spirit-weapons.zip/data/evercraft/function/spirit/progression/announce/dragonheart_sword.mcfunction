# Tier-up announcement — Dragonheart Sword
# (Wave 2, 2026-06-10: evolution brag rides the queue — name baked via whoami, protected, 30s TTL.)
function evercraft:util/notify/whoami
$data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"$(tier_color)"},{text:""},{text:"'s ",color:"gray"},{text:"Dragonheart Sword",color:"red",bold:true},{text:" has evolved to ",color:"gray"},{text:"$(tier_name)",color:"$(tier_color)",bold:true},{text:"!",color:"gray"},{text:" ✦",color:"$(tier_color)"}]
data modify storage evercraft:notify stage.c[1].text set from storage evercraft:notify named.who
scoreboard players set #ndur ec.temp 50
execute as @a run scoreboard players set #nttl ec.temp 600
execute as @a run function evercraft:util/notify/emit_keep
