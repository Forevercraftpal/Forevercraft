# Spirit Progression — raise #sp_bit_val to 2^(#sp_bit_idx) by doubling.
# Helper for mark_ability_used. Recurses, doubling #sp_bit_val and decrementing #sp_bit_idx
# until the index reaches 0. Max depth 27 (bit index for weapon 14 / ability2). INLINE scratch.
execute if score #sp_bit_idx ec.temp matches ..0 run return 0
scoreboard players operation #sp_bit_val ec.temp *= #2 ec.const
scoreboard players remove #sp_bit_idx ec.temp 1
function evercraft:spirit/progression/raise_bit
