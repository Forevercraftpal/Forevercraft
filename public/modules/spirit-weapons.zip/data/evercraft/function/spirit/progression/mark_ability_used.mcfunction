# Spirit Progression — Mark a distinct ability TYPE as used (Ability Variety tracker)
# Run as @s (player). Macro arg $(slot) = 0 for ability1, 1 for ability2.
# Reads ec.sp_weapon (1..14) → computes a bit index (weapon-1)*2 + slot (range 0..27),
# raises 2^bitindex, and OR-sets it into ec.sp_abil_seen ONCE (idempotent). Then recomputes
# ec.sp_ability_variety = popcount(ec.sp_abil_seen) via the shared 31-bit popcount helper.
# Keep INLINE — global ec.temp scratch, serial @s execution is the race fence.

# Guard: only meaningful for a real spirit weapon id.
execute unless score @s ec.sp_weapon matches 1..14 run return 0

# bit index = (weapon - 1) * 2 + slot
scoreboard players operation #sp_bit_idx ec.temp = @s ec.sp_weapon
scoreboard players remove #sp_bit_idx ec.temp 1
scoreboard players operation #sp_bit_idx ec.temp *= #2 ec.const
$scoreboard players add #sp_bit_idx ec.temp $(slot)

# bit value = 2^bitindex, built by doubling #sp_bit_val (from 1) exactly #sp_bit_idx times.
scoreboard players set #sp_bit_val ec.temp 1
function evercraft:spirit/progression/raise_bit

# OR the bit in only if not already present. Working copy modulo (2*val): if the remainder
# is >= val the bit is already set → nothing to do (idempotent, no double-count).
scoreboard players operation #sp_test ec.temp = @s ec.sp_abil_seen
scoreboard players operation #sp_modspan ec.temp = #sp_bit_val ec.temp
scoreboard players operation #sp_modspan ec.temp *= #2 ec.const
scoreboard players operation #sp_test ec.temp %= #sp_modspan ec.temp
execute if score #sp_test ec.temp >= #sp_bit_val ec.temp run return 0

# Bit is clear → set it and recompute the popcount of distinct ability types.
scoreboard players operation @s ec.sp_abil_seen += #sp_bit_val ec.temp
function evercraft:craftforever/codex/hub/popcount {field:"sp_abil_seen"}
scoreboard players operation @s ec.sp_ability_variety = #cf_pc_count ec.temp
