# Spirit — Save held weapon to per-player storage (macro inner)
# Args from storage evercraft:spirit cart:
#   pid = adv.gui_session (per-player session id)
# Wiring Audit #13 P0-5 / AR-P0-3 spirit-extension — paired with on_consume.mcfunction.
# Mirrors evercraft:artifacts/healer/save_held_inner:7-8 pattern.
# Per-player storage path eliminates cross-player race when two players consume same tick.
$execute if entity @s[tag=ec.sp_restore_offhand] run data modify storage evercraft:item_restore spirit_weapon.$(pid) set from entity @s equipment.offhand
$execute unless entity @s[tag=ec.sp_restore_offhand] run data modify storage evercraft:item_restore spirit_weapon.$(pid) set from entity @s SelectedItem
