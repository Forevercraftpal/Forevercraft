# Spirit — Restore offhand twin backup via per-player hopper minecart (macro inner)
# Args from storage evercraft:spirit cart:
#   pid = adv.gui_session (per-player session id)
# Wiring Audit #13 P0-5 / AR-P0-3 spirit-extension — paired with restore_item.mcfunction.
# Per-player cart tag + per-player twin-backup storage path. Skip cleanly if no twin saved.
$execute if data storage evercraft:temp sp_twin_backup.$(pid).id run summon hopper_minecart ~ 320 ~ {Tags:["ec.sp_temp","ec.sp_temp.$(pid)"],Items:[{Slot:0b,id:"minecraft:stone",count:1}]}
$execute if data storage evercraft:temp sp_twin_backup.$(pid).id run data modify entity @e[type=hopper_minecart,tag=ec.sp_temp.$(pid),limit=1] Items[0] set from storage evercraft:temp sp_twin_backup.$(pid)
$execute if data storage evercraft:temp sp_twin_backup.$(pid).id run item replace entity @s weapon.offhand from entity @e[type=hopper_minecart,tag=ec.sp_temp.$(pid),limit=1] container.0
$execute if data storage evercraft:temp sp_twin_backup.$(pid).id run data modify entity @e[type=hopper_minecart,tag=ec.sp_temp.$(pid),limit=1] Items set value []
$execute if data storage evercraft:temp sp_twin_backup.$(pid).id run kill @e[type=hopper_minecart,tag=ec.sp_temp.$(pid)]
