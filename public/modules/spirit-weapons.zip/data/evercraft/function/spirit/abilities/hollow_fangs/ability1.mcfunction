# Hollow Fangs — Shadow Step (Right-click, 8s CD)
# Teleport behind nearest hostile within 15 blocks
# Apply 3s Invisibility + next hit deals 3x damage

# Set cooldown (160 ticks = 8 seconds; spirit tier: 80 ticks = 4 seconds)
execute if score @s ec.sp_tier matches 7 run scoreboard players set @s ec.sp_cd1 80
execute unless score @s ec.sp_tier matches 7 run scoreboard players set @s ec.sp_cd1 160

# Find nearest hostile mob
tag @e[type=#evercraft:aoe_targets,distance=..15,limit=1,sort=nearest] add ec.sp_target

# Check if a target was found
execute unless entity @e[tag=ec.sp_target,limit=1] run return run function evercraft:spirit/abilities/hollow_fangs/shadow_step_fail

# Teleport behind the target (2 blocks behind, facing the target)
execute at @e[tag=ec.sp_target,limit=1] run tp @s ^ ^ ^-2 facing entity @e[tag=ec.sp_target,limit=1]

# Apply Invisibility (3 seconds)
effect give @s invisibility 3 0 true

# Set bonus damage flag (next hit within 3 seconds deals 3x)
tag @s add ec.sp_shadow_bonus
scoreboard players set @s ec.sp_timer 60

# VFX
playsound minecraft:entity.enderman.teleport player @a[scores={ec.fx_snd=1..}] ~ ~ ~ 1.0 1.5
particle reverse_portal ~ ~1 ~ 0.3 0.5 0.3 0.05 15
execute at @e[tag=ec.sp_target,limit=1] run particle smoke ~ ~1 ~ 0.5 0.5 0.5 0.02 10

# Cleanup target tag
tag @e[tag=ec.sp_target] remove ec.sp_target

# Feedback
data modify storage evercraft:notify stage.c set value [{text:"Shadow Step!",color:"dark_purple",bold:true},{text:" — next hit deals 3x damage",color:"light_purple"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit

# Bespoke spirit FX (fires only on the success path — the no-target case returns above)
function evercraft:fx/bespoke/spirit/hollow_fangs/shadow_step
