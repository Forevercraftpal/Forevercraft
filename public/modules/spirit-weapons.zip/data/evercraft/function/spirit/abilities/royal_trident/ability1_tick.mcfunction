# Depthsworn — Aegis Wall Zone Tick
# Run as player at player. Marker entity = ec.sp_aegis_marker.
#
# Wiring Audit #13 P2-A: consolidated 9 redundant `as @e[tag=ec.sp_aegis_marker]` scans
# into a single wrapper that invokes ability1_tick_inner once per owned marker.
# Saves ~112 marker scans/tick at 14p worst-case.

# Set owner check for multiplayer marker filtering
scoreboard players operation #owner_check ec.temp = @s ec.sp_uid

# Damage-tick gate: every 20 ticks based on ec.sp_aegis_active counter.
scoreboard players operation #sp_aegis_dmg_tick ec.temp = @s ec.sp_aegis_active
scoreboard players operation #sp_aegis_dmg_tick ec.temp %= #20 ec.const

# Flags for the inner — read once here, used inside the per-marker inner.
scoreboard players set #aegis_tier_spirit ec.temp 0
execute if score @s ec.sp_tier matches 7 run scoreboard players set #aegis_tier_spirit ec.temp 1
scoreboard players set #aegis_twin ec.temp 0
execute if score @s ec.sp_twin matches 1 run scoreboard players set #aegis_twin ec.temp 1

# Single wrapper scan — run inner once per owned marker.
execute as @e[tag=ec.sp_aegis_marker] if score @s ec.sp_owner = #owner_check ec.temp at @s run function evercraft:spirit/abilities/royal_trident/ability1_tick_inner
