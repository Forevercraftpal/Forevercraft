# Wyrmcleaver — Charge Step
# Run as player at player. Teleport forward 2 blocks, damage nearby, trail particles.
# Called each tick while ec.sp_state > 0

# Decrement state (step counter)
scoreboard players remove @s ec.sp_state 1

# Teleport forward 2 blocks in facing direction. `rotated ~ 0` zeroes PITCH so the charge stays
# horizontal — without it, a downward look tp's you into the floor (tp ignores collision → clipping)
# and an upward look launches you skyward.
execute rotated ~ 0 run tp @s ^ ^ ^2

# Damage all nearby mobs within 3 blocks — 10 damage + knockback
execute as @e[distance=..3,type=#evercraft:aoe_targets] run damage @s 10 minecraft:player_attack by @p[sort=nearest,limit=1]

# VFX — Fire trail
particle flame ~ ~0.5 ~ 0.8 0.5 0.8 0.1 8
particle dust{color:[1.0,0.3,0.0],scale:1.5} ~ ~1 ~ 0.5 0.5 0.5 0.05 4
particle dragon_breath ~ ~0.5 ~ 0.5 0.3 0.5 0.05 3

# SFX — Whoosh per step
playsound minecraft:entity.player.attack.sweep player @a[scores={ec.fx_snd=1..}] ~ ~ ~ 0.8 0.6
playsound minecraft:item.firecharge.use player @a[scores={ec.fx_snd=1..}] ~ ~ ~ 0.4 1.5
