# Zephyr Edge — Zephyr Dance (Sneak+Right-click, 20s CD)
# Gain 5 Wind Charges (spirit: 7). Each attack teleports to random offset from target
# 5th strike calls lightning on target

# Set cooldown (400 ticks = 20 seconds)
scoreboard players set @s ec.sp_cd2 400

# Grant Wind Charges
execute if score @s ec.sp_tier matches 7 run scoreboard players set @s ec.sp_charges 7
execute unless score @s ec.sp_tier matches 7 run scoreboard players set @s ec.sp_charges 5

# Tag for tracking
tag @s add ec.sp_zephyr_dance

# VFX
playsound minecraft:entity.breeze.charge player @a[scores={ec.fx_snd=1..}] ~ ~ ~ 1.0 1.2
particle gust ~ ~1 ~ 0.5 0.5 0.5 0.1 8
data modify storage evercraft:notify stage.c set value [{text:"Zephyr Dance! ",color:"gold",bold:true},{score:{name:"@s",objective:"ec.sp_charges"},color:"yellow"},{text:" charges",color:"yellow"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit

# Bespoke spirit FX
function evercraft:fx/bespoke/spirit/zephyr_edge/dance
