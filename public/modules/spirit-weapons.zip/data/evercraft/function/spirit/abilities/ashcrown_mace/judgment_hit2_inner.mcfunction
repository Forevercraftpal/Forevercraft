# Ashcrown Mace — Judgment Strike Hit 2 (per-player stun-target lookup; macro inner)
# Args from storage evercraft:spirit cart:
#   pid = adv.gui_session (per-player session id)
# Wiring Audit #13 P0-6 / AR-XB-3 RE-TARGETED — paired with judgment_hit2.mcfunction.
# Per-player stun_target tag reads, write to per-player cleanup. Eliminates the cross-player
# race where Player A's judgment could damage Player B's stun-target.

# Check if stunned target exists and deal bonus damage
# Stunned target (tagged): 50 damage (5x base ~10)
$execute at @e[tag=ec.sp_stun_target.$(pid),limit=1] run damage @e[tag=ec.sp_stun_target.$(pid),limit=1] 50 minecraft:player_attack by @s
$execute at @e[tag=ec.sp_stun_target.$(pid),limit=1] run particle explosion ~ ~1 ~ 0.3 0.3 0.3 0.1 3
$execute at @e[tag=ec.sp_stun_target.$(pid),limit=1] run playsound minecraft:entity.player.attack.crit player @a[scores={ec.fx_snd=1..}] ~ ~ ~ 1.0 0.6

# If no stunned target found, deal 2x to nearest (20 damage)
$execute unless entity @e[tag=ec.sp_stun_target.$(pid),limit=1] run damage @e[distance=..4,type=#evercraft:aoe_targets,limit=1,sort=nearest] 20 minecraft:player_attack by @s

# Clean up per-player stun tag
$tag @e[tag=ec.sp_stun_target.$(pid)] remove ec.sp_stun_target.$(pid)
