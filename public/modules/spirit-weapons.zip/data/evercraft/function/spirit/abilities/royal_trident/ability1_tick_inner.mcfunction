# Depthsworn — Aegis Wall Zone Per-Marker Inner
# Run AS each owned ec.sp_aegis_marker AT marker — consolidates 9 redundant scans
# from ability1_tick into a single as @e wrapper.
#
# Wiring Audit #13 P2-A: was 9 sequential `as @e[tag=ec.sp_aegis_marker]` scans;
# now 1 wrapper invokes this inner once per owned marker. Saves ~112 scans/tick at
# 14p worst-case (each marker's owner-filter is checked once instead of 9 times).
#
# Pre-condition (set by ability1_tick outer):
#   #sp_aegis_dmg_tick ec.temp — gametime modulo flag (0 = damage tick due, else skip)
#   #aegis_twin ec.temp         — 1 if twin equipped (for ally heal branch)
#   #aegis_tier_spirit ec.temp  — 1 if tier 7 (for double-damage branch)
# Caller @s context = marker entity (via `as @e ... at @s run function`).

# Allies in 6-block zone — Resistance II for 1s
effect give @a[tag=ec.player,distance=..6] resistance 2 1 true

# Enemies entering zone — Slowness III for 2s
effect give @e[type=#evercraft:aoe_targets,tag=!ec.sp_aegis_marker,distance=..6] slowness 2 2 true

# Damage tick (every 20 ticks) — 2 damage to enemies in zone
execute if score #sp_aegis_dmg_tick ec.temp matches 0 as @e[type=#evercraft:aoe_targets,tag=!ec.sp_aegis_marker,distance=..6] run damage @s 2 minecraft:generic

# Spirit tier: an additional +2 damage tick (effectively 4/s instead of 2/s)
execute if score #aegis_tier_spirit ec.temp matches 1 if score #sp_aegis_dmg_tick ec.temp matches 0 as @e[type=#evercraft:aoe_targets,tag=!ec.sp_aegis_marker,distance=..6] run damage @s 2 minecraft:generic

# Twin bonus: heal allies 1 HP/s (every 20 ticks)
execute if score #aegis_twin ec.temp matches 1 if score #sp_aegis_dmg_tick ec.temp matches 0 run effect give @a[tag=ec.player,distance=..6] instant_health 1 0

# Visual outline — 4 cardinal-edge dust puffs
particle dust{color:[0.6,0.6,0.7],scale:0.8} ~6 ~0.5 ~ 0 0.3 0 0.02 2
particle dust{color:[0.6,0.6,0.7],scale:0.8} ~-6 ~0.5 ~ 0 0.3 0 0.02 2
particle dust{color:[0.6,0.6,0.7],scale:0.8} ~ ~0.5 ~6 0 0.3 0 0.02 2
particle dust{color:[0.6,0.6,0.7],scale:0.8} ~ ~0.5 ~-6 0 0.3 0 0.02 2
