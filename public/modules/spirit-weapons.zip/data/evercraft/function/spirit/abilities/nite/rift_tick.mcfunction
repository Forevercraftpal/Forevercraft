# Nite — Dimensional Rift Per-Tick Processing
# Processes all active rift markers: damage entities, particles, expiry
#
# Wiring Audit #13 P1-A: owner_uid filter eliminates cross-player rift marker pollution
# (closes both race seat R8 + perf seat finding in one edit). Pattern from voidpiercer/tick.
# All 5 marker scans now require matching ec.sp_owner score.

# Set owner check for multiplayer marker filtering.
scoreboard players operation #owner_check ec.temp = @s ec.sp_uid

# Decrement lifetime on owned rift markers
execute as @e[tag=ec.sp_rift_marker] if score @s ec.sp_owner = #owner_check ec.temp run scoreboard players remove @s ec.sp_timer 1

# Kill expired owned markers
execute as @e[tag=ec.sp_rift_marker,scores={ec.sp_timer=..0}] if score @s ec.sp_owner = #owner_check ec.temp at @s run particle reverse_portal ~ ~1 ~ 0.3 0.5 0.3 0.02 3
execute as @e[tag=ec.sp_rift_marker,scores={ec.sp_timer=..0}] if score @s ec.sp_owner = #owner_check ec.temp run kill @s

# Damage entities near each owned marker (1.5 block radius)
execute as @e[tag=ec.sp_rift_marker] if score @s ec.sp_owner = #owner_check ec.temp at @s run function evercraft:spirit/abilities/nite/rift_damage

# Particles on each owned marker
execute as @e[tag=ec.sp_rift_marker] if score @s ec.sp_owner = #owner_check ec.temp at @s run particle reverse_portal ~ ~0.5 ~ 0.3 0.8 0.3 0.02 2
execute as @e[tag=ec.sp_rift_marker] if score @s ec.sp_owner = #owner_check ec.temp at @s run particle dust{color:[0.3,0.0,0.5],scale:1.0} ~ ~0.5 ~ 0.3 0.8 0.3 0.01 1
