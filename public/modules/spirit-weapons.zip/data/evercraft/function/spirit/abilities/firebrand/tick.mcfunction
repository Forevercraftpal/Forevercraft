# Firebrand — Per-Tick Processing
# Run as @s at @s when holding spirit weapon ID 3
# Passives: Tyrant's Rage (below 30% HP), death prevention, Rampage timer

# === TYRANT'S RAGE (below 30% HP: +50% damage, +30% attack speed, 15% lifesteal) ===
# Check HP percentage
execute store result score #fb_hp ec.temp run attribute @s max_health get 100
scoreboard players operation #fb_hp ec.temp *= #30 ec.const
scoreboard players operation #fb_hp ec.temp /= #100 ec.const
execute store result score #fb_cur ec.temp run data get entity @s Health 100
# Spirit tier: threshold is 40% instead of 30%
execute if score @s ec.sp_tier matches 7 store result score #fb_hp ec.temp run attribute @s max_health get 100
execute if score @s ec.sp_tier matches 7 run scoreboard players operation #fb_hp ec.temp *= #40 ec.const
execute if score @s ec.sp_tier matches 7 run scoreboard players operation #fb_hp ec.temp /= #100 ec.const

# Apply/remove Tyrant's Rage based on HP
execute if score #fb_cur ec.temp <= #fb_hp ec.temp unless entity @s[tag=ec.sp_tyrant_rage] run function evercraft:spirit/abilities/firebrand/rage_on
execute if score #fb_cur ec.temp > #fb_hp ec.temp if entity @s[tag=ec.sp_tyrant_rage] run function evercraft:spirit/abilities/firebrand/rage_off

# === UNDYING (death prevention, once per 5m) ===
# On an otherwise-lethal blow (Health <= 2 = 1 heart; #fb_cur is Health*100 from the read above, so
# <=200) while the death-prevention cooldown ec.sp_charges is READY (0), restore the bearer and gate it.
# Spirit-local on-lethal save (the phoenix/void_heart_save shape, but inline + gated on the spirit's own
# ec.sp_charges plumbing initialized in detect.mcfunction and decremented below). ec.sp_charges is in
# game-TICKS (decremented every game tick like the rest of the spirit cooldowns) -> 6000 = 5 minutes.
execute if score #fb_cur ec.temp matches ..200 unless score @s ec.sp_charges matches 1.. run function evercraft:spirit/abilities/firebrand/undying

# === DEATH PREVENTION COOLDOWN ===
execute if score @s ec.sp_charges matches 1.. run scoreboard players remove @s ec.sp_charges 1

# === RAMPAGE TIMER ===
execute if score @s ec.sp_rampage matches 1.. run scoreboard players remove @s ec.sp_rampage 1
execute if entity @s[tag=ec.sp_rampage_active,scores={ec.sp_rampage=..0}] run function evercraft:spirit/abilities/firebrand/rampage_end
