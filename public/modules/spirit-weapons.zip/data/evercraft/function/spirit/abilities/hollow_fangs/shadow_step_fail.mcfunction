# Hollow Fangs — Shadow Step failed (no valid target)
# Refund cooldown

scoreboard players set @s ec.sp_cd1 0
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bass player @s ~ ~ ~ 0.5 0.5
data modify storage evercraft:notify stage.c set value [{text:"No target in range",color:"red"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
