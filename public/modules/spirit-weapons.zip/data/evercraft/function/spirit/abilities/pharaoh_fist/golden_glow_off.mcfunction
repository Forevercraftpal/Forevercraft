# Pharaoh's Fist — Golden Glow Deactivate
# Kill combo dropped below threshold

tag @s remove ec.sp_golden_glow

# Remove damage modifier
attribute @s attack_damage modifier remove evercraft:golden_glow

# Remove glowing
effect clear @s glowing

# VFX
particle poof ~ ~1 ~ 0.3 0.5 0.3 0.05 4
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.experience_orb.pickup player @s ~ ~ ~ 0.5 0.5

data modify storage evercraft:notify stage.c set value [{text:"Golden Glow faded...",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
