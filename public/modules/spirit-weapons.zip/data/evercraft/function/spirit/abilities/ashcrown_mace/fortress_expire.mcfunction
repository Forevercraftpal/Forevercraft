# Ashcrown Mace — Fortress Expire
# Remove fortress zone when timer runs out

# Final burst particles at marker position
execute as @e[tag=ec.sp_fortress_marker,sort=nearest,limit=1,distance=..20] at @s run particle ash ~ ~0.5 ~ 4.0 1.0 4.0 0.1 20
execute as @e[tag=ec.sp_fortress_marker,sort=nearest,limit=1,distance=..20] at @s run particle poof ~ ~0.5 ~ 2.0 0.5 2.0 0.05 8

# Kill fortress marker
kill @e[tag=ec.sp_fortress_marker,sort=nearest,limit=1,distance=..20]

# Remove active tag
tag @s remove ec.sp_fortress_active

# SFX
playsound minecraft:block.anvil.land player @a[scores={ec.fx_snd=1..}] ~ ~ ~ 0.5 1.5

data modify storage evercraft:notify stage.c set value [{text:"Fortress crumbled...",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
