# Wyrmcleaver — Charge Slam (Final overhead slam at end of charge)
# Run as player at player. 8-block AoE cone: 15 damage + ignite 5 seconds

# Remove charging tag
tag @s remove ec.sp_dh_charging

# === DAMAGE — 15 to all mobs in 8-block radius ahead ===
# Use positioned forward to create a cone-like effect
execute positioned ^ ^ ^4 run execute as @e[distance=..6,type=#evercraft:aoe_targets] run damage @s 15 minecraft:player_attack by @p[sort=nearest,limit=1]

# Ignite enemies for 5 seconds (100 ticks)
execute positioned ^ ^ ^4 as @e[distance=..6,type=#evercraft:aoe_targets] run data merge entity @s {Fire:100s}

# === MASSIVE VFX — Dragon breath explosion ===
particle dragon_breath ~ ~0.5 ~ 4.0 1.0 4.0 0.15 40
particle flame ~ ~1 ~ 5.0 2.0 5.0 0.12 30
particle lava ~ ~0.5 ~ 3.0 0.5 3.0 0.08 10
particle explosion ~ ~1 ~ 2.0 1.0 2.0 0.05 3
particle dust{color:[1.0,0.2,0.0],scale:2.5} ~ ~1 ~ 4.0 2.0 4.0 0.08 15

# Forward cone VFX
execute positioned ^ ^ ^4 run particle flame ~ ~1 ~ 3.0 1.5 3.0 0.1 20
execute positioned ^ ^ ^4 run particle dragon_breath ~ ~0.5 ~ 3.0 0.5 3.0 0.1 15

# === SFX — Massive impact ===
playsound minecraft:entity.ender_dragon.growl player @a[scores={ec.fx_snd=1..}] ~ ~ ~ 1.0 0.6
playsound minecraft:entity.generic.explode player @a[scores={ec.fx_snd=1..}] ~ ~ ~ 1.0 0.7
playsound minecraft:entity.player.attack.crit player @a[scores={ec.fx_snd=1..}] ~ ~ ~ 1.0 0.5
playsound minecraft:item.firecharge.use player @a[scores={ec.fx_snd=1..}] ~ ~ ~ 1.0 0.3

data modify storage evercraft:notify stage.c set value [{text:"SLAM!",color:"red",bold:true}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
