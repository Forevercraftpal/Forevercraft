# Voidpiercer — Phase Shot End
# Phase duration expired, remove state

# Remove phase tag
tag @s remove ec.sp_phase_active

# Reset state
scoreboard players set @s ec.sp_state 0
scoreboard players set @s ec.sp_charges 0

# VFX
particle poof ~ ~1 ~ 0.4 0.6 0.4 0.05 6
particle reverse_portal ~ ~1 ~ 0.3 0.5 0.3 0.2 4

# SFX
playsound minecraft:entity.illusioner.mirror_move player @a[scores={ec.fx_snd=1..}] ~ ~ ~ 0.8 1.5

data modify storage evercraft:notify stage.c set value [{text:"Phase faded...",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
