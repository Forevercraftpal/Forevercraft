# Voidpiercer — Rift Collapse
# Final 8 damage burst at center, kill marker
# Run as rift marker, at rift position

# Final damage burst — 8 damage to all nearby entities
execute as @e[distance=..6,type=#evercraft:aoe_targets] run damage @s 8 minecraft:magic

# Explosion VFX
particle explosion ~ ~0.5 ~ 2.0 0.5 2.0 0.1 5
particle reverse_portal ~ ~1 ~ 3.0 1.5 3.0 1.0 30
particle dust{color:[0.2,0.0,0.5],scale:2.0} ~ ~0.5 ~ 3.0 1.0 3.0 0.01 13
particle sonic_boom ~ ~0.5 ~ 0.0 0.0 0.0 0.0 1

# SFX — implosion sound
playsound minecraft:entity.warden.sonic_boom player @a[scores={ec.fx_snd=1..}] ~ ~ ~ 0.7 1.8
playsound minecraft:entity.generic.explode player @a[scores={ec.fx_snd=1..}] ~ ~ ~ 0.8 0.5

# Kill the rift marker
kill @s
