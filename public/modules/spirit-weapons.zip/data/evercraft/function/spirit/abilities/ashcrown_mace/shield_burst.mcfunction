# Ashcrown Mace — Shield Burst
# Triggered when shield charges reach threshold (100 normal, 150 spirit)
# Run as player, at player position

# Apply Resistance III for 5 seconds
effect give @s resistance 5 2 false

# AoE damage + knockback: 10 damage in 5-block radius
# Wiring Audit #13 P0-6 / AR-XB-3 RE-TARGETED: stamp owner-id surrogate; predicate-scope the
# `by` attribution so two ashcrown players in the same AoE don't cross-attribute kills.
# Precedent: evercraft:artifacts/striker/fortress:20-25 (W3a-shipped stamp pattern).
tag @s add ec.sp_burster
scoreboard players operation @s ec.aff_owner_id = @s adv.gui_session
scoreboard players operation #Search aff.id = @s ec.aff_owner_id
execute as @e[distance=..5,type=#evercraft:aoe_targets] run damage @s 10 minecraft:player_attack by @a[tag=ec.sp_burster,predicate=evercraft:artifacts/check_owner,limit=1]
tag @s remove ec.sp_burster

# VFX — shield shatter explosion
particle explosion ~ ~0.5 ~ 2.0 0.5 2.0 0.1 4
particle dust{color:[1.0,0.8,0.2],scale:2.0} ~ ~0.5 ~ 3.0 1.0 3.0 0.01 15
particle sweep_attack ~ ~1 ~ 2.0 0.3 2.0 0.1 5
particle ash ~ ~0.5 ~ 3.0 1.0 3.0 0.1 20

# SFX
playsound minecraft:entity.iron_golem.hurt player @a[scores={ec.fx_snd=1..}] ~ ~ ~ 1.0 0.5
playsound minecraft:entity.generic.explode player @a[scores={ec.fx_snd=1..}] ~ ~ ~ 0.8 1.0
playsound minecraft:block.anvil.land player @a[scores={ec.fx_snd=1..}] ~ ~ ~ 0.7 0.8

data modify storage evercraft:notify stage.c set value [{text:"SHIELD BURST!",color:"gold",bold:true}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
