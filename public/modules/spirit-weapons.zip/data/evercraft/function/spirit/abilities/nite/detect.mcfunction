# Nite — Detection Init
# Run as @s when spirit weapon ID 5 (Dual Swordsman sword) detected in mainhand
# Triggered as second chain from spirit/detect (dual_swordsman class layer fires
# alongside Nite spirit weapon detect — see spirit/detect:69-73). Wiring Audit #13 P0-1.
# This handles spirit-weapon-specific init only

# Nite's passives are handled by the Dual Swordsman class (whirlwind, dual-wield)
# Spirit abilities are Dimensional Rift and Blade Storm
