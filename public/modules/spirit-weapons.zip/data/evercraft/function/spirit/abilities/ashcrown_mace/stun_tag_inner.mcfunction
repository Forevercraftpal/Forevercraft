# Ashcrown Mace — Per-player stun-target tag (macro inner)
# Args from storage evercraft:spirit cart:
#   pid = adv.gui_session (per-player session id)
# Wiring Audit #13 P0-6 / AR-XB-3 RE-TARGETED — paired with ability2.mcfunction.
# Per-player stun_target tag eliminates the cross-player race where two ashcrown
# players' stun-targets collide and judgment_hit2 damages the wrong target.
$tag @e[distance=..4,type=#evercraft:aoe_targets,limit=1,sort=nearest] add ec.sp_stun_target.$(pid)
