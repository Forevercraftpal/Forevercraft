# Pharaoh's Fist — On Hit Processing
# Handles: hit combo tracking, Sandstorm Flurry at 10 hits, chrono boost 2x damage

advancement revoke @s only evercraft:spirit/pharaoh_fist/on_hit

# === HIT COMBO TRACKING ===
scoreboard players add @s ec.sp_hit_combo 1

# === CHRONO BOOST: 2x damage during freeze ===
# If chrono_boost is active, deal bonus damage to the target (find by HurtTime)
execute if entity @s[tag=ec.sp_chrono_boost] run damage @e[type=#evercraft:aoe_targets,distance=..5,limit=1,sort=nearest,nbt={HurtTime:10s}] 6 minecraft:player_attack by @s
execute if entity @s[tag=ec.sp_chrono_boost] run particle dust{color:[1.0,0.85,0.0],scale:1.5} ~ ~1 ~ 0.3 0.5 0.3 0.02 3
execute if entity @s[tag=ec.sp_chrono_boost] run playsound minecraft:block.note_block.harp player @a[scores={ec.fx_snd=1..}] ~ ~ ~ 0.5 1.8

# === SANDSTORM FLURRY at 10 hits ===
# Use tag to gate the flurry effects so the "matches 0" check after reset doesn't false-trigger
execute if score @s ec.sp_hit_combo matches 10.. run tag @s add ec.sp_flurry_proc
execute if score @s ec.sp_hit_combo matches 10.. run scoreboard players set @s ec.sp_hit_combo 0

# Sandstorm Flurry: AoE damage + sand particles
execute if entity @s[tag=ec.sp_flurry_proc] run execute as @e[distance=..4,type=#evercraft:aoe_targets] run damage @s 8 minecraft:player_attack by @p[sort=nearest,limit=1]
execute if entity @s[tag=ec.sp_flurry_proc] run playsound minecraft:entity.player.attack.sweep player @a[scores={ec.fx_snd=1..}] ~ ~ ~ 1.0 0.6
execute if entity @s[tag=ec.sp_flurry_proc] run playsound minecraft:item.trident.thunder player @a[scores={ec.fx_snd=1..}] ~ ~ ~ 0.5 2.0
execute if entity @s[tag=ec.sp_flurry_proc] run particle dust{color:[0.85,0.7,0.3],scale:1.5} ~ ~1 ~ 2.0 1.0 2.0 0.05 13
execute if entity @s[tag=ec.sp_flurry_proc] run particle crit ~ ~1 ~ 2.0 1.0 2.0 0.3 8
data modify storage evercraft:notify stage.c set value [{text:"Sandstorm Flurry!",color:"yellow",bold:true}]
scoreboard players set #ndur ec.temp 45
execute if entity @s[tag=ec.sp_flurry_proc] run function evercraft:util/notify/emit
tag @s remove ec.sp_flurry_proc

# === KILL COMBO TRACKING (for golden glow passive) ===
scoreboard players add @s ec.sp_kill_combo 1

# === PROGRESSION TRACKING ===
scoreboard players add @s ec.sp_kills 1
scoreboard players add @s ec.sp_impact_hits 1
function evercraft:spirit/progression/track_on_hit
