# Soul Piercer — Maelstrom End
# Kill maelstrom marker, final burst of damage + knockback

# Owner check for multiplayer marker filtering
scoreboard players operation #owner_check ec.temp = @s ec.sp_uid

# Final burst: 6 damage to all in radius
execute as @e[tag=ec.sp_maelstrom_marker] if score @s ec.sp_owner = #owner_check ec.temp at @s run execute as @e[distance=..6,type=#evercraft:aoe_targets] run damage @s 6 minecraft:drown

# Launch enemies upward (water eruption)
execute as @e[tag=ec.sp_maelstrom_marker] if score @s ec.sp_owner = #owner_check ec.temp at @s as @e[distance=..6,type=#evercraft:aoe_targets] run data modify entity @s Motion set value [0.0d, 1.2d, 0.0d]

# VFX — water explosion
execute as @e[tag=ec.sp_maelstrom_marker] if score @s ec.sp_owner = #owner_check ec.temp at @s run particle splash ~ ~1 ~ 4.0 2.0 4.0 0.2 30
execute as @e[tag=ec.sp_maelstrom_marker] if score @s ec.sp_owner = #owner_check ec.temp at @s run particle bubble ~ ~2 ~ 3.0 2.0 3.0 0.15 20
execute as @e[tag=ec.sp_maelstrom_marker] if score @s ec.sp_owner = #owner_check ec.temp at @s run playsound minecraft:entity.generic.splash player @a[scores={ec.fx_snd=1..}] ~ ~ ~ 1.2 0.5

# Kill marker
execute as @e[tag=ec.sp_maelstrom_marker] if score @s ec.sp_owner = #owner_check ec.temp run kill @s

# Remove active tag
tag @s remove ec.sp_maelstrom_active

data modify storage evercraft:notify stage.c set value [{text:"Maelstrom dissipates",color:"dark_aqua"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
