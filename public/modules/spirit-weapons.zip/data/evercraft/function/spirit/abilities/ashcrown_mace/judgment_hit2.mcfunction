# Ashcrown Mace — Judgment Strike Hit 2
# Delayed follow-up: 5x damage if stunned, 2x if not + shockwave
#
# Wiring Audit #13 P0-6 / AR-XB-3 RE-TARGETED:
# - Per-player stun_target tag (ec.sp_stun_target.$(pid)) via judgment_hit2_inner.
# - Shockwave `by` attribution uses owner-id stamp + check_owner predicate (no @p mis-attrib).

# Remove judging tag
tag @s remove ec.sp_judging

# === FOLLOW-UP HIT (per-player stun-target lookup via macro inner) ===
execute store result storage evercraft:spirit cart.pid int 1 run scoreboard players get @s adv.gui_session
function evercraft:spirit/abilities/ashcrown_mace/judgment_hit2_inner with storage evercraft:spirit cart

# === SHOCKWAVE ===
# 3-block radius, 6 damage to all enemies — attributed to the judger via check_owner predicate.
# Precedent: evercraft:artifacts/striker/fortress:20-25 (W3a-shipped stamp pattern).
tag @s add ec.sp_judger
scoreboard players operation @s ec.aff_owner_id = @s adv.gui_session
scoreboard players operation #Search aff.id = @s ec.aff_owner_id
execute as @e[distance=..3,type=#evercraft:aoe_targets] run damage @s 6 minecraft:player_attack by @a[tag=ec.sp_judger,predicate=evercraft:artifacts/check_owner,limit=1]
tag @s remove ec.sp_judger

# VFX + SFX
playsound minecraft:entity.generic.explode player @a[scores={ec.fx_snd=1..}] ~ ~ ~ 0.8 1.2
playsound minecraft:entity.player.attack.sweep player @a[scores={ec.fx_snd=1..}] ~ ~ ~ 1.0 0.5
particle explosion ~ ~0.5 ~ 1.5 0.3 1.5 0.1 4
particle dust{color:[1.0,0.6,0.0],scale:2.0} ~ ~0.5 ~ 1.5 0.3 1.5 0.01 8
particle sweep_attack ~ ~1 ~ 1.0 0.3 1.0 0.1 3

data modify storage evercraft:notify stage.c set value [{text:"JUDGMENT!",color:"red",bold:true}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
