# Ashcrown Mace — Judgment Strike (Sneak+Right-click, 18s CD)
# Two-hit combo:
# Hit 1 (immediate): Stun nearest target (Slowness V + Weakness V for 2s; spirit: 3s)
# Hit 2 (after 10 ticks): 5x if stunned, 2x if not + 3-block shockwave (6 damage)

# Set cooldown
scoreboard players set @s ec.sp_cd2 360

# === HIT 1: STUN ===
# Find nearest enemy and stun it
execute if score @s ec.sp_tier matches 7 run effect give @e[distance=..4,type=#evercraft:aoe_targets,limit=1,sort=nearest] slowness 3 4 false
execute if score @s ec.sp_tier matches 7 run effect give @e[distance=..4,type=#evercraft:aoe_targets,limit=1,sort=nearest] weakness 3 4 false
execute unless score @s ec.sp_tier matches 7 run effect give @e[distance=..4,type=#evercraft:aoe_targets,limit=1,sort=nearest] slowness 2 4 false
execute unless score @s ec.sp_tier matches 7 run effect give @e[distance=..4,type=#evercraft:aoe_targets,limit=1,sort=nearest] weakness 2 4 false

# Tag the stunned target — per-player suffix via macro inner.
# Wiring Audit #13 P0-6 / AR-XB-3 RE-TARGETED: was bare ec.sp_stun_target, cross-player race.
execute store result storage evercraft:spirit cart.pid int 1 run scoreboard players get @s adv.gui_session
function evercraft:spirit/abilities/ashcrown_mace/stun_tag_inner with storage evercraft:spirit cart

# Set state machine for hit 2 (10 tick delay)
tag @s add ec.sp_judging
scoreboard players set @s ec.sp_state 10

# VFX + SFX
playsound minecraft:entity.player.attack.knockback player @a[scores={ec.fx_snd=1..}] ~ ~ ~ 1.0 0.6
playsound minecraft:entity.lightning_bolt.thunder player @a[scores={ec.fx_snd=1..}] ~ ~ ~ 0.5 2.0
particle crit ~ ~1 ~ 0.5 0.5 0.5 0.3 8

data modify storage evercraft:notify stage.c set value [{text:"JUDGMENT STRIKE!",color:"gold",bold:true}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
