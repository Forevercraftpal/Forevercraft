# Soul Piercer — Maelstrom (Right-click, 12s CD)
# Summon water vortex at player position — 6-block radius
# Pulls enemies inward + 4 damage/sec + Mining Fatigue II
# Duration: 6s (120 ticks) normal, 10s (200 ticks) spirit

# Set cooldown
scoreboard players set @s ec.sp_cd1 240

# Kill any existing owned maelstrom
scoreboard players operation #owner_check ec.temp = @s ec.sp_uid
execute as @e[tag=ec.sp_maelstrom_marker] if score @s ec.sp_owner = #owner_check ec.temp run kill @s

# Summon vortex at player position
summon marker ~ ~ ~ {Tags:["ec.sp_maelstrom_marker"],PersistenceRequired:true}
scoreboard players operation @e[tag=ec.sp_maelstrom_marker,limit=1,sort=nearest] ec.sp_owner = @s ec.sp_uid

# Set timer
execute if score @s ec.sp_tier matches 7 run scoreboard players set @s ec.sp_timer 200
execute unless score @s ec.sp_tier matches 7 run scoreboard players set @s ec.sp_timer 120

# Tag player
tag @s add ec.sp_maelstrom_active

# VFX + SFX — water surge
playsound minecraft:ambient.underwater.enter player @a[scores={ec.fx_snd=1..}] ~ ~ ~ 1.0 0.5
playsound minecraft:entity.player.splash player @a[scores={ec.fx_snd=1..}] ~ ~ ~ 1.2 0.6
particle bubble ~ ~1 ~ 3.0 1.5 3.0 0.1 20
particle splash ~ ~0.5 ~ 3.0 0.5 3.0 0.1 15
particle rain ~ ~3 ~ 3.0 0.5 3.0 0.05 10

data modify storage evercraft:notify stage.c set value [{text:"MAELSTROM!",color:"dark_aqua",bold:true}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit

# Bespoke spirit FX
function evercraft:fx/bespoke/spirit/ellegaard_trident/maelstrom
