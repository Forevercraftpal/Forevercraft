# Depthsworn — On Hit. Counter Thrust = a melee hit landed while Aegis Wall is up (ec.sp_aegis_active > 0):
# thrusting out from behind the planted shield. SOLE WRITER of ec.sp_counter_hits — the one royal_trident-
# specific counter (sp_kills / sp_shield_block are SHARED, built by any spirit weapon's on_hit). This feeds
# royal_trident progression tiers 3-6 ("Land N counter thrusts") + the royal_trident metamorphosis + story
# ch114, all of which were stuck because royal_trident had no on_hit handler (the weapon previously only
# handled thrown hits). Triggered by advancement spirit/royal_trident/on_hit (player_hurt_entity, spirit_id:14b).
advancement revoke @s only evercraft:spirit/royal_trident/on_hit

# Shared lifetime hit/kill tally — every spirit weapon's on_hit increments this (matches dragonheart_sword etc.).
scoreboard players add @s ec.sp_kills 1

# Counter Thrust: only while the player's own Aegis Wall is active.
execute if score @s ec.sp_aegis_active matches 1.. run scoreboard players add @s ec.sp_counter_hits 1
execute if score @s ec.sp_aegis_active matches 1.. if score @s ec.fx_snd matches 1.. run playsound minecraft:item.trident.hit master @s ~ ~ ~ 0.7 1.3

# Kill-streak progression hook (shared across every weapon's on_hit).
function evercraft:spirit/progression/track_on_hit
