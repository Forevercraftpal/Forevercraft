# Firebrand — "Undying" (Death prevention, once per 5m)
# Fired from firebrand/tick when the bearer drops to <= 1 heart with the cooldown ready. Restores the
# bearer (instant heal) + protective Resistance II + Fire Resistance, then SETs the death-prevention
# cooldown ec.sp_charges (spirit-local one-writer beside the source-set; decremented in firebrand/tick).
# Spirit-local on-lethal save, the phoenix_totem_save / void_heart_save shape (effect give SETs the
# Absorption/Resistance level, never sums). ec.sp_charges is in game-TICKS -> 6000 = 5 minutes.

# Restore the bearer (totem-grade heal) + protective rebirth buffs
effect give @s instant_health 1 4 false
effect give @s resistance 8 1 false
effect give @s fire_resistance 10 0 false

# Visual + audio feedback (Tyrant's molten rebirth)
particle totem_of_undying ~ ~1 ~ 0.5 1 0.5 0.5 40
particle flame ~ ~1 ~ 0.6 1 0.6 0.02 30
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:item.totem.use player @s ~ ~ ~ 1.0 0.8
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.blaze.shoot player @s ~ ~ ~ 0.8 0.7

# Set the death-prevention cooldown (5 minutes = 6000 game-ticks) — decremented in firebrand/tick (one writer)
scoreboard players set @s ec.sp_charges 6000

# Actionbar notification
data modify storage evercraft:notify stage.c set value [{text:"UNDYING!",color:"gold",bold:true}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
