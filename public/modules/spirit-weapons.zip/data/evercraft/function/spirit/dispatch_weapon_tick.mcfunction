# Spirit Weapon Tick Dispatch — Single @a scan with return-on-match
# OPT: Replaces 14 separate @a selector evaluations with 1
# Run as each sp_active player

execute if score @s ec.sp_weapon matches 1 run return run function evercraft:spirit/abilities/hollow_fangs/tick
execute if score @s ec.sp_weapon matches 2 run return run function evercraft:spirit/abilities/voidpiercer/tick
execute if score @s ec.sp_weapon matches 3 run return run function evercraft:spirit/abilities/firebrand/tick
execute if score @s ec.sp_weapon matches 4 run return run function evercraft:spirit/abilities/zephyr_edge/tick
execute if score @s ec.sp_weapon matches 5 run return run function evercraft:spirit/abilities/nite/tick
execute if score @s ec.sp_weapon matches 6 run return run function evercraft:spirit/abilities/whispering_spear/tick
execute if score @s ec.sp_weapon matches 7 run return run function evercraft:spirit/abilities/ashcrown_mace/tick
execute if score @s ec.sp_weapon matches 8 run return run function evercraft:spirit/abilities/ellegaard_trident/tick
execute if score @s ec.sp_weapon matches 9 run return run function evercraft:spirit/abilities/pharaoh_fist/tick
execute if score @s ec.sp_weapon matches 10 run return run function evercraft:spirit/abilities/lifewoven_branch/tick
execute if score @s ec.sp_weapon matches 11 run return run function evercraft:spirit/abilities/sabrewing/tick
execute if score @s ec.sp_weapon matches 12 run return run function evercraft:spirit/abilities/dragonheart_sword/tick
execute if score @s ec.sp_weapon matches 13 run return run function evercraft:spirit/abilities/bulwark_shield/tick
execute if score @s ec.sp_weapon matches 14 run return run function evercraft:spirit/abilities/royal_trident/tick
