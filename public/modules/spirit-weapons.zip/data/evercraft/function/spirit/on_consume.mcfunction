# Spirit Artifact — Right-click consumed (consume_item advancement fired)
# Determines which ability to fire based on sneak state
# Run as @s (the player)

advancement revoke @s only evercraft:spirit/consume

# Wiring Audit #13 P0-5 / AR-P0-3 spirit-extension:
# Derive per-player id (pid = adv.gui_session) BEFORE branching, so save_held_inner sees pid
# for both mainhand and offhand paths. Storage path becomes evercraft:item_restore
# spirit_weapon.$(pid) — eliminates cross-player race when two players consume same tick.
execute store result storage evercraft:spirit cart.pid int 1 run scoreboard players get @s adv.gui_session

# SAFETY: Mark offhand-consume path BEFORE saving (save_held_inner branches on the tag).
# If consumed from offhand, SelectedItem is the WRONG item — save from offhand instead.
execute unless items entity @s weapon.mainhand *[custom_data~{spirit_artifact:true}] run tag @s add ec.sp_restore_offhand

# Save held item to per-player storage path via macro inner.
function evercraft:spirit/save_held_inner with storage evercraft:spirit cart

# Tag for 1-tick delayed restore (restore_item reads ec.sp_restore_offhand to pick slot).
tag @s add ec.sp_restore

# Bail out on offhand-consume path — no ability dispatch (offhand is not the active weapon).
execute unless items entity @s weapon.mainhand *[custom_data~{spirit_artifact:true}] run return 0

# === DETERMINE ABILITY (sneak = ability 2, standing = ability 1) ===
# Route to weapon-specific ability based on ec.sp_weapon ID

# Sneaking → Ability 2
execute if predicate evercraft:spirit/is_sneaking run function evercraft:spirit/use_ability2
# Standing → Ability 1
execute unless predicate evercraft:spirit/is_sneaking run function evercraft:spirit/use_ability1
