# Spirit — Save offhand twin backup to per-player storage (macro inner)
# Args from storage evercraft:spirit cart:
#   pid = adv.gui_session (per-player session id)
# Wiring Audit #13 P0-5 / AR-P0-3 spirit-extension — paired with restore_item.mcfunction.
# Per-player twin-backup storage path eliminates cross-player race when two players
# consume same tick — anti-dupe is per-player from this point forward.
$data remove storage evercraft:temp sp_twin_backup.$(pid)
$execute if items entity @s weapon.offhand *[custom_data~{spirit_artifact:true}] run data modify storage evercraft:temp sp_twin_backup.$(pid) set from entity @s equipment.offhand
