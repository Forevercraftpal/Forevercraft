# Spirit Artifact — Restore consumed item (1-tick delayed)
# consume_item fires BEFORE item removal — must restore next tick via hopper_minecart
# Run as @s at @s (the player who consumed)
#
# Wiring Audit #13 P0-5 / AR-P0-3 spirit-extension: per-player storage path + per-player
# hopper-cart tag (ec.sp_temp.$(pid)) eliminate cross-player race where two players'
# carts get swapped when both consume in same tick. Mirrors artifacts/healer pattern.

# Derive per-player id (pid = adv.gui_session) for cross-system uniformity (4414 artifacts/ callers).
execute store result storage evercraft:spirit cart.pid int 1 run scoreboard players get @s adv.gui_session

# Anti-dupe: game's consume mechanic can restore consumed items on its own
# (same issue the satchel system handles — clear duplicates before we restore)
# Save offhand twin if present (clear may remove it) — per-player storage path.
function evercraft:spirit/restore_twin_save_inner with storage evercraft:spirit cart

# Clear ALL spirit artifact copies from player (inventory, hotbar, equipment)
clear @s *[custom_data~{spirit_artifact:true}]
execute if items entity @s weapon.mainhand *[custom_data~{spirit_artifact:true}] run item replace entity @s weapon.mainhand with minecraft:air
execute if items entity @s weapon.offhand *[custom_data~{spirit_artifact:true}] run item replace entity @s weapon.offhand with minecraft:air

# Restore consumed weapon via per-player hopper minecart at build limit (out of sight).
function evercraft:spirit/restore_item_inner with storage evercraft:spirit cart
tag @s remove ec.sp_restore_offhand

# Restore offhand twin if it was saved (per-player cart + storage).
function evercraft:spirit/restore_twin_backup_inner with storage evercraft:spirit cart
