# Spirit Tome — Replace held tome with updated lore
# Uses item replace pattern (similar to Tome of Experience)
# Race-safety (W14 W6.6): writes evercraft:spirit_tome lore.part (single-key) and immediately
# consumes via `function ... with storage`. Safe because (a) called via sequential
# `as @a[tag=ec.sq_update_tome] run function do_update_tome` in update_tome.mcfunction:5
# (each player's full chain completes before next @a iteration), AND (b) macro args are
# snapshotted at `with storage` call-time. Per AU14 race seat RT3.

tag @s remove ec.sq_update_tome

# Write part number to storage for macro
execute store result storage evercraft:spirit_tome lore.part int 1 run scoreboard players get @s ec.sq_part

# Only update if holding the tome
execute unless items entity @s weapon.mainhand book[custom_data~{spirit_tome:true}] run return fail

# Check if all quests complete (part 101+)
execute if score @s ec.sq_part matches 101.. run return run function evercraft:spirit_tome/replace_tome_complete

# Replace with updated lore showing next quest number
function evercraft:spirit_tome/replace_tome with storage evercraft:spirit_tome lore
