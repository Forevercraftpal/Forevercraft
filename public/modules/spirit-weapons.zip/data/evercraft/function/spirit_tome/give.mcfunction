# Spirit Tome — Bootstrap quest progression (operator/admin only)
# Usage: /function evercraft:spirit_tome/give — sole writer of ec.sq_has_tome; initializes ec.sq_part=1, ec.sq_active=0, ec.sq_progress=0. Programmatic caller: newcomer/grant_spirit_weapon (W14 W1.2).

# Don't give duplicate tomes
execute if score @s ec.sq_has_tome matches 1.. run return fail

# Mark player as having a tome
scoreboard players set @s ec.sq_has_tome 1

# Initialize quest state
scoreboard players set @s ec.sq_part 1
scoreboard players set @s ec.sq_active 0
scoreboard players set @s ec.sq_progress 0

# Give the Spirit Tome item
give @s book[custom_name={text:"Spirit Tome",color:"aqua",italic:false},lore=[{text:"Quest 1 of 100",color:"gray",italic:true},{text:"",italic:false},{text:"A record of your spirit weapon's journey.",color:"dark_aqua",italic:true},{text:"Use to view and activate your next quest.",color:"dark_aqua",italic:true}],custom_data={spirit_tome:true,evercraft_item:true},consumable={consume_seconds:999999,sound:"intentionally_empty",has_consume_particles:false},use_cooldown={seconds:2,cooldown_group:"evercraft:spirit_tome"},max_stack_size=1,rarity=epic,enchantment_glint_override=true] 1

# Feedback
data modify storage evercraft:notify stage.c set value [{text:"A mysterious tome materializes before you...",color:"dark_aqua"}]
scoreboard players set #ndur ec.temp 50
function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"100 challenges await. Use the tome to begin.",color:"gray"}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:item.trident.thunder master @s ~ ~ ~ 0.3 1.5
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.enchantment_table.use master @s ~ ~ ~ 0.8 0.7
