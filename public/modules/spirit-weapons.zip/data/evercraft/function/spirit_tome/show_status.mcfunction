# Spirit Tome — Show current quest status
# Runs as the player who used the tome

tellraw @s [{"text":"  --- ","color":"dark_gray"},{"text":"Spirit Tome","color":"aqua","bold":true},{"text":" ---","color":"dark_gray"}]

# Re-route to populate quest text in storage (per-player path sq_temp player_<pid> after W14 W2.2)
function evercraft:spirit_tome/quests/route

# Show quest part and progress
execute store result storage evercraft:spirit_tome display.part int 1 run scoreboard players get @s ec.sq_part
# W14 W2.2: thread pid via display.pid for display_status to read per-player sq_temp.
data modify storage evercraft:spirit_tome display.pid set from storage evercraft:spirit_tome cart.pid
function evercraft:spirit_tome/quests/show_quest_status with storage evercraft:spirit_tome display

execute if score @s ec.fx_snd matches 1.. run playsound minecraft:item.book.page_turn master @s ~ ~ ~ 0.5 1.0
