# Spirit Tome — Grant N vanilla XP levels in a single command (macro)
# Wiring Audit #19 W2 (AU14-FOLLOWUP.3): replaces 100-deep tail-recursion in grant_xp.mcfunction.
# Drops 200 commands/tick @ quest 100 → 1 command.
# Arg: part (int) — number of levels to grant.
# Caller is responsible for clearing ec.sq_xp_remaining if it still tracks any state
# (we deliberately do not increment-then-drain here — see complete.mcfunction caller site).
# Pioneer mode earns 1/3 of level rewards (floor, min 1) — Joseph 2026-06-11.
$scoreboard players set #xpl ec.temp $(part)
scoreboard players set #xpl3 ec.temp 3
execute unless score @s ec.difficulty matches 1..2 run scoreboard players operation #xpl ec.temp /= #xpl3 ec.temp
execute unless score @s ec.difficulty matches 1..2 if score #xpl ec.temp matches ..0 run scoreboard players set #xpl ec.temp 1
execute store result storage evercraft:args xpl.m int 1 run scoreboard players get #xpl ec.temp
function evercraft:util/xp_levels_do with storage evercraft:args xpl
