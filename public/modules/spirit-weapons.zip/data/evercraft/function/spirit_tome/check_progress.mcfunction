# Spirit Tome — Check quest progress (1s self-schedule)
# Runs for all players with active spirit tome quests

# Tick down use cooldown (prevents using_item spam)
scoreboard players remove @a[scores={ec.sq_cd=1..}] ec.sq_cd 1

# Recovery: re-give tome if player lost it (every check, ~1s)
# W14 W5.1: weapon.* fast-path (2-slot probe) → ec.sq_lost_tome tag → recover.
# Drops steady-state cost from ~574 slot-reads/s @ 14p to ~28 (20× win).
execute as @a[scores={ec.sq_has_tome=1},tag=!ec.sq_lost_tome] unless items entity @s weapon.* book[custom_data~{spirit_tome:true}] unless items entity @s container.* book[custom_data~{spirit_tome:true}] run tag @s add ec.sq_lost_tome
execute as @a[tag=ec.sq_lost_tome] run function evercraft:spirit_tome/recover_tome

execute as @a[scores={ec.sq_active=1}] run function evercraft:spirit_tome/check_player

# Re-schedule
schedule function evercraft:spirit_tome/check_progress 20t replace
