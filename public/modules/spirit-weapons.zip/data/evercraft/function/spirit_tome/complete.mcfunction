# Spirit Tome — Quest Complete!
# Grants XP reward, celebrates, advances to next quest

# Prevent double completion (if already inactive)
execute unless score @s ec.sq_active matches 1 run return fail

# Deactivate quest
scoreboard players set @s ec.sq_active 0

# === XP REWARD: Quest part N = N levels worth of mastery XP ===
# Store part number as XP amount
scoreboard players operation #sq_xp ec.var = @s ec.sq_part

# Grant mastery XP (add to spirit mastery scoreboard)
scoreboard players operation @s ec.sp_mastery += #sq_xp ec.var

# Grant vanilla experience levels as well (tangible reward).
# Wiring Audit #19 W2 (AU14-FOLLOWUP.3): single-command macro grant
# (was 100-deep tail-recursion at quest 100 — see grant_xp.mcfunction header).
# ec.sq_xp_remaining kept zeroed so downstream observers don't read stale state
# from the prior recursion contract (W14 W2.1 per-player score retained).
execute store result storage evercraft:spirit_tome grant_args.part int 1 run scoreboard players get @s ec.sq_part
function evercraft:spirit_tome/grant_xp_macro with storage evercraft:spirit_tome grant_args
scoreboard players set @s ec.sq_xp_remaining 0

# Coin reward (part-scaled)
function evercraft:coins/spirit_tome_reward

# === CELEBRATION ===
# Re-route to populate quest text in storage (per-player path sq_temp player_<pid> after W14 W2.2)
function evercraft:spirit_tome/quests/route
# W14 W2.2: thread pid (set in cart.pid by route) through the `with storage` path via macro outer.
function evercraft:spirit_tome/celebrate_outer with storage evercraft:spirit_tome cart

# Particles + sounds
execute at @s run particle end_rod ~ ~1 ~ 0.5 0.5 0.5 0.1 15
execute at @s run particle witch ~ ~1 ~ 0.3 0.3 0.3 0.05 8
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 1 1.0
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.player.levelup master @s ~ ~ ~ 0.7 1.2

# Milestone crate rewards (Parts 25/50/75/100)
# Inv-full guard: drop at the player's feet rather than void on a full inventory.
execute store result score #inv_full ec.var run function evercraft:util/check_inv_full
execute if score @s ec.sq_part matches 25 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:artifacts/rare/main
execute if score @s ec.sq_part matches 25 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:artifacts/rare/main
data modify storage evercraft:notify stage.c set value [{text:"★ ",color:"aqua"},{text:"Rare Artifact",color:"aqua",bold:true},{text:" — Tome Milestone 25!",color:"gray"},{text:" ★",color:"aqua"}]
scoreboard players set #ndur ec.temp 45
execute if score @s ec.sq_part matches 25 run function evercraft:util/notify/emit
execute if score @s ec.sq_part matches 50 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:artifacts/ornate/main
execute if score @s ec.sq_part matches 50 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:artifacts/ornate/main
data modify storage evercraft:notify stage.c set value [{text:"★ ",color:"dark_purple"},{text:"Ornate Artifact",color:"dark_purple",bold:true},{text:" — Tome Milestone 50!",color:"gray"},{text:" ★",color:"dark_purple"}]
scoreboard players set #ndur ec.temp 45
execute if score @s ec.sq_part matches 50 run function evercraft:util/notify/emit
execute if score @s ec.sq_part matches 75 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:artifacts/exquisite/main
execute if score @s ec.sq_part matches 75 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:artifacts/exquisite/main
data modify storage evercraft:notify stage.c set value [{text:"★ ",color:"gold"},{text:"Exquisite Artifact",color:"gold",bold:true},{text:" — Tome Milestone 75!",color:"gold"},{text:" ★",color:"gold"}]
scoreboard players set #ndur ec.temp 45
execute if score @s ec.sq_part matches 75 run function evercraft:util/notify/emit
execute if score @s ec.sq_part matches 100 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:artifacts/mythical/main
execute if score @s ec.sq_part matches 100 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:artifacts/mythical/main
data modify storage evercraft:notify stage.c set value [{text:"★ ",color:"light_purple"},{text:"Mythical Artifact",color:"light_purple",bold:true},{text:" — Tome Mastery!",color:"gold"},{text:" ★",color:"light_purple"}]
scoreboard players set #ndur ec.temp 45
execute if score @s ec.sq_part matches 100 run function evercraft:util/notify/emit

# === ADVANCE TO NEXT QUEST ===
scoreboard players add @s ec.sq_part 1
scoreboard players set @s ec.sq_progress 0

# Sync to spirit system scoreboard
scoreboard players operation @s ec.sp_quest = @s ec.sq_part

# === UPDATE TOME ITEM LORE ===
# Schedule for next tick (can't modify item during use)
tag @s add ec.sq_update_tome
schedule function evercraft:spirit_tome/update_tome 1t append

# === QUEST 100 SPECIAL FINALE ===
execute if score @s ec.sq_part matches 101 run function evercraft:spirit_tome/finale
