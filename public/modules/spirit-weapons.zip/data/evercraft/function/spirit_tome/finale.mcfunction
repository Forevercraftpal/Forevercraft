# Spirit Tome — Quest 100 Complete! Grand Finale!
# The ultimate celebration for completing all 100 spirit tome quests

# Title sequence
title @s times 20 100 40
title @s subtitle {"text":"All 100 Quests Complete","color":"gold","italic":true}
title @s title [{"text":"SPIRIT TOME","color":"aqua"},{"text":" \u2014 ","color":"dark_gray"},{"text":"MASTERED","color":"gold"}]

# Massive particle burst
execute at @s run particle end_rod ~ ~1 ~ 1 1 1 0.15 50
execute at @s run particle totem_of_undying ~ ~1 ~ 0.8 0.8 0.8 0.5 40
execute at @s run particle dragon_breath ~ ~0.5 ~ 0.5 0.1 0.5 0.02 20

# Sound fanfare
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 1 0.8
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.ender_dragon.death master @s ~ ~ ~ 0.3 1.5
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:item.trident.thunder master @s ~ ~ ~ 0.5 1.2

# Server announcement
execute as @s run function evercraft:util/notify/whoami
data modify storage evercraft:notify stage.c set value [{text:"",color:"aqua",bold:true},{text:" has completed all ",color:"gray"},{text:"100 Spirit Tome quests",color:"aqua",bold:true},{text:"!",color:"gray"}]
data modify storage evercraft:notify stage.c[0].text set from storage evercraft:notify named.who
scoreboard players set #ndur ec.temp 50
execute as @s run execute as @a run scoreboard players set #nttl ec.temp 600
execute as @s run execute as @a run function evercraft:util/notify/emit_keep

# Bonus: grant 100 additional experience levels
function evercraft:util/xp_levels {n:100}
data modify storage evercraft:notify stage.c set value [{text:"+100 BONUS levels ",color:"green",bold:true},{text:"(on top of quest 100 reward) for mastering the Spirit Tome!",color:"green"}]
scoreboard players set #ndur ec.temp 50
function evercraft:util/notify/emit
