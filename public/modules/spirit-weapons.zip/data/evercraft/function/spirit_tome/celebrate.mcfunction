# Spirit Tome — Celebration display (macro function)
# (AB-1 sticky-times sweep 2026-06-10: explicit stamp — `title times` is sticky per player and this sequence set none, so it inherited whatever ran last.)
title @s times 10 60 20
$title @s subtitle {"text":"$(name)","color":"gold"}
title @s title [{"text":"Quest ","color":"aqua"},{"score":{"name":"@s","objective":"ec.sq_part"},"color":"white"},{"text":" Complete!","color":"aqua"}]
$data modify storage evercraft:notify stage.c set value [{text:"Quest complete: ",color:"gray"},{text:"$(name)",color:"gold",bold:true}]
scoreboard players set #ndur ec.temp 50
function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"You gained ",color:"green"},{score:{name:"@s",objective:"ec.sq_part"},color:"green",bold:true},{text:" XP levels!",color:"green"}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit
