# Spirit Tome — Grant vanilla experience levels equal to quest part number
# NOTE: admin/console fallback only — gameplay grants go through grant_xp_macro,
# which applies the Pioneer 1/3 level scaling (2026-06-11). This path is unscaled.
# Tail-recursive: drains @s ec.sq_xp_remaining one level per recursion until 0.
# Per-player score (was #sq_xp_grant ec.var — globally raced) — Wiring Audit #14 W2.1.
#
# SUPERSEDED 2026-05-29 (Wiring Audit #19 W2 / AU14-FOLLOWUP.3): the live caller
# `complete.mcfunction` now invokes `grant_xp_macro with storage grant_args` for a
# single-command grant (200 commands/tick → 1 at quest 100). This file is retained as
# a fallback for any admin/console invocation that pre-sets ec.sq_xp_remaining and
# wants the recursion behavior. Safe to archive in a future cleanup council; not
# auto-archived because the body is still well-defined and the file may be referenced
# from external admin notes.

execute if score @s ec.sq_xp_remaining matches 1.. run experience add @s 1 levels
execute if score @s ec.sq_xp_remaining matches 1.. run scoreboard players remove @s ec.sq_xp_remaining 1
execute if score @s ec.sq_xp_remaining matches 1.. run function evercraft:spirit_tome/grant_xp
