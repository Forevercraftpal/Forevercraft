# Spirit Tome — Route quest part to type/target/subtype and quest text
# Splits into 10 bucket files for performance (binary-style branching)
# Wiring Audit #14 W2.2: derive per-player pid via adv.gui_session, thread through
# macro chain so q/N writes land at storage evercraft:sq_temp player_<pid>.
# Wiring Audit #19 W1 (AU14-FOLLOWUP.2): a shared helper exists at
# `evercraft:_shared/derive_pid` (writes to evercraft:_shared cart.pid). Opt-in
# migration here would change the macro `with storage` target to evercraft:_shared
# cart — kept on the local per-branch path for now since the chain already works
# and the cross-branch refactor for artifacts/spirit/spirit_tome can land later.
execute store result storage evercraft:spirit_tome cart.pid int 1 run scoreboard players get @s adv.gui_session
function evercraft:spirit_tome/quests/route_inner with storage evercraft:spirit_tome cart
