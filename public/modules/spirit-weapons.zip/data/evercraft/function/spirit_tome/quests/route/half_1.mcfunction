# Route parts 1-50 — W14 W2.2 (per-pid macro thread)
$execute if score @s ec.sq_part matches 1..10 run function evercraft:spirit_tome/quests/route/parts_1_10 {pid:$(pid)}
$execute if score @s ec.sq_part matches 11..20 run function evercraft:spirit_tome/quests/route/parts_11_20 {pid:$(pid)}
$execute if score @s ec.sq_part matches 21..30 run function evercraft:spirit_tome/quests/route/parts_21_30 {pid:$(pid)}
$execute if score @s ec.sq_part matches 31..40 run function evercraft:spirit_tome/quests/route/parts_31_40 {pid:$(pid)}
$execute if score @s ec.sq_part matches 41..50 run function evercraft:spirit_tome/quests/route/parts_41_50 {pid:$(pid)}
