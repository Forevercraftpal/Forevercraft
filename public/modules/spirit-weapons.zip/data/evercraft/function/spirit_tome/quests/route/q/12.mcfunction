scoreboard players set @s ec.sq_type 2
scoreboard players set @s ec.sq_target 8
scoreboard players set @s ec.sq_sub 3
$data merge storage evercraft:sq_temp player_$(pid) {name:"Pathfinder",desc:"Visit 8 different biomes.",flavor:"Every horizon hides something new."}
