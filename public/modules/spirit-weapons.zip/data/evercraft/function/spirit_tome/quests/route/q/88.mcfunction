scoreboard players set @s ec.sq_type 1
scoreboard players set @s ec.sq_target 50
scoreboard players set @s ec.sq_sub 11
$data merge storage evercraft:sq_temp player_$(pid) {name:"Enderman Slayer",desc:"Kill 50 endermen.",flavor:"Look them in the eyes. Then look away."}
