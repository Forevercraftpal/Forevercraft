# Spirit Tome — Interact dispatch sub-bucket 4..30 (W14 W6.1 bucket-split)
# Wiring Audit #14 W6.1: 27 branches split 3 ways to reduce per-tick score-cmp from 27 → ~10.

# 4: Cook a meal — check ach.meals_cooked increased since activation
execute if score @s ec.sq_sub matches 4 run function evercraft:spirit_tome/quests/types/interact/cook_meal

# 8: Night Owl — be outside at midnight (DayTime 18000)
execute if score @s ec.sq_sub matches 8 run function evercraft:spirit_tome/quests/types/interact/night_owl

# 13: Arm Yourself — hold an Ornate+ artifact (tier is a string in custom_data)
execute if score @s ec.sq_sub matches 13 if items entity @s weapon.mainhand *[custom_data~{is_artifact:true,tier:"ornate"}] run function evercraft:spirit_tome/complete
execute if score @s ec.sq_sub matches 13 if items entity @s weapon.mainhand *[custom_data~{is_artifact:true,tier:"exquisite"}] run function evercraft:spirit_tome/complete
execute if score @s ec.sq_sub matches 13 if items entity @s weapon.mainhand *[custom_data~{is_artifact:true,tier:"mythical"}] run function evercraft:spirit_tome/complete

# 24: Stay Awhile — stand still for 60 seconds (check sneak time or no movement delta)
execute if score @s ec.sq_sub matches 24 run function evercraft:spirit_tome/quests/types/interact/stay_still

# 26: Cookie Monster — eat a cookie (advancement-based)
execute if score @s ec.sq_sub matches 26 run function evercraft:spirit_tome/quests/types/interact/cookie

# 28: Bonfire — check for nearby campfire
execute if score @s ec.sq_sub matches 28 at @s if block ~ ~-1 ~ campfire run function evercraft:spirit_tome/complete
execute if score @s ec.sq_sub matches 28 at @s if block ~ ~ ~ campfire run function evercraft:spirit_tome/complete

# 29: Nether Tourist — be in the Nether
execute if score @s ec.sq_sub matches 29 in minecraft:the_nether run function evercraft:spirit_tome/complete
