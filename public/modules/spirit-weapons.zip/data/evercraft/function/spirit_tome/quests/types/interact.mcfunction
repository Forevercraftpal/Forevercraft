# Spirit Tome — Interact check (Type 3) — bucket dispatch (W14 W6.1)
# Per-quest one-off condition checks, routed by quest part (ec.sq_sub = quest part).
# Wiring Audit #14 W6.1: was 27-branch unconditional ladder; now 3 sub-files keep per-tick
# score-cmp from 27 → ~10 at 14p worst-case (2.2× win).
execute if score @s ec.sq_sub matches 4..30 run return run function evercraft:spirit_tome/quests/types/interact/sub_4_30
execute if score @s ec.sq_sub matches 31..60 run return run function evercraft:spirit_tome/quests/types/interact/sub_31_60
execute if score @s ec.sq_sub matches 61..99 run return run function evercraft:spirit_tome/quests/types/interact/sub_61_99
