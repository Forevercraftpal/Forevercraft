# Spirit Tome — Show quest status with progress (macro function)
# W14 W2.2: $(pid) threaded through display storage for per-player sq_temp read.
$tellraw @s [{"text":"  "},{"text":"Quest ","color":"gray"},{"text":"$(part)","color":"white"},{"text":" of 100","color":"gray"}]
$function evercraft:spirit_tome/quests/display_status with storage evercraft:sq_temp player_$(pid)
