# Spirit Tome — Per-player route inner (W14 W2.2)
# Args from storage evercraft:spirit_tome cart:
#   pid = adv.gui_session (per-player session id)
# Threads pid through 3-stage routing dispatch so q/N writes land at
# storage evercraft:sq_temp player_<pid> rather than the global single-key.
# Mirrors evercraft:spirit/save_held_inner pattern (AU13 W2.1).
$execute if score @s ec.sq_part matches 1..50 run function evercraft:spirit_tome/quests/route/half_1 {pid:$(pid)}
$execute if score @s ec.sq_part matches 51..100 run function evercraft:spirit_tome/quests/route/half_2 {pid:$(pid)}
