# Spirit Tome — Show-activated outer (W14 W2.2)
# Args from storage evercraft:spirit_tome cart:
#   pid = adv.gui_session (per-player session id, set by quests/route)
# Threads pid into the `with storage` path so show_activated reads per-player sq_temp.
$function evercraft:spirit_tome/quests/show_activated with storage evercraft:sq_temp player_$(pid)
