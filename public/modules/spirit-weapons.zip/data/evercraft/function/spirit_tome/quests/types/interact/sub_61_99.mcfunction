# Spirit Tome — Interact dispatch sub-bucket 61..99 (W14 W6.1 bucket-split)
# Wiring Audit #14 W6.1: 27 branches split 3 ways to reduce per-tick score-cmp from 27 → ~10.

# 61: Snow Day — be in a snowy biome
execute if score @s ec.sq_sub matches 61 at @s if biome ~ ~ ~ minecraft:snowy_plains run function evercraft:spirit_tome/complete
execute if score @s ec.sq_sub matches 61 at @s if biome ~ ~ ~ minecraft:snowy_taiga run function evercraft:spirit_tome/complete
execute if score @s ec.sq_sub matches 61 at @s if biome ~ ~ ~ minecraft:frozen_river run function evercraft:spirit_tome/complete
execute if score @s ec.sq_sub matches 61 at @s if biome ~ ~ ~ minecraft:snowy_beach run function evercraft:spirit_tome/complete
execute if score @s ec.sq_sub matches 61 at @s if biome ~ ~ ~ minecraft:ice_spikes run function evercraft:spirit_tome/complete
execute if score @s ec.sq_sub matches 61 at @s if biome ~ ~ ~ minecraft:frozen_ocean run function evercraft:spirit_tome/complete

# 63: Lightning Rod — be outside during thunderstorm
execute if score @s ec.sq_sub matches 63 at @s if predicate evercraft:spirit_tome/is_thunderstorm run function evercraft:spirit_tome/complete

# 66: Music Box — (auto-complete via jukebox placement — simplified to check nearby jukebox)
execute if score @s ec.sq_sub matches 66 at @s if block ~ ~-1 ~ jukebox run function evercraft:spirit_tome/complete
execute if score @s ec.sq_sub matches 66 at @s if block ~ ~ ~ jukebox run function evercraft:spirit_tome/complete

# 71: Mountain Goat — Y >= 256
execute if score @s ec.sq_sub matches 71 at @s positioned ~ 256 ~ if entity @s[y=256,dy=200] run function evercraft:spirit_tome/complete

# 73: Dark Explorer — be in deep dark biome
execute if score @s ec.sq_sub matches 73 at @s if biome ~ ~ ~ minecraft:deep_dark run function evercraft:spirit_tome/complete

# 83: Convergence — check if Dream Surge event is active
execute if score @s ec.sq_sub matches 83 if score #ec_event_active ec.var matches 1 run function evercraft:spirit_tome/complete
