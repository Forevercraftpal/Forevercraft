# Route parts 51-100 — W14 W2.2 (per-pid macro thread)
$execute if score @s ec.sq_part matches 51..60 run function evercraft:spirit_tome/quests/route/parts_51_60 {pid:$(pid)}
$execute if score @s ec.sq_part matches 61..70 run function evercraft:spirit_tome/quests/route/parts_61_70 {pid:$(pid)}
$execute if score @s ec.sq_part matches 71..80 run function evercraft:spirit_tome/quests/route/parts_71_80 {pid:$(pid)}
$execute if score @s ec.sq_part matches 81..90 run function evercraft:spirit_tome/quests/route/parts_81_90 {pid:$(pid)}
$execute if score @s ec.sq_part matches 91..100 run function evercraft:spirit_tome/quests/route/parts_91_100 {pid:$(pid)}
