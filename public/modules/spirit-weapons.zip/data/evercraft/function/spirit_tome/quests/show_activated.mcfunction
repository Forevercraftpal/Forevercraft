tellraw @s [{"text":"  --- ","color":"dark_gray"},{"text":"Spirit Tome","color":"aqua","bold":true},{"text":" ---","color":"dark_gray"}]
$tellraw @s [{"text":"  "},{"text":"$(name)","color":"gold","bold":true}]
$tellraw @s [{"text":"  "},{"text":"$(desc)","color":"white"}]
$tellraw @s [{"text":"  "},{"text":"$(flavor)","color":"gray","italic":true}]
tellraw @s [{"text":"  -----------------","color":"dark_gray"}]
# (AB-1 sticky-times sweep 2026-06-10: explicit stamp — `title times` is sticky per player and this sequence set none, so it inherited whatever ran last.)
title @s times 10 60 20
$title @s subtitle {"text":"$(name)","color":"gold"}
title @s title {"text":"Quest Activated","color":"aqua"}
