# Stay Awhile — stand still for 60 seconds
# Wiring Audit #14 W3.1: prior implementation snapshot-then-monotonic-delta only matched on tick 1
# (compared a monotonic delta to a 0..60 counter); rewrite uses ec.sq_snap as last-check value
# refreshed each tick. Race-safety: @s-scoped; sequential `as @a … run check_player` protects ordering.
execute if score @s ec.sq_walk = @s ec.sq_snap run scoreboard players add @s ec.sq_progress 1
execute unless score @s ec.sq_walk = @s ec.sq_snap run scoreboard players set @s ec.sq_progress 0
execute store result score @s ec.sq_snap run scoreboard players get @s ec.sq_walk

# Check: 60 seconds = 60 checks at 1/sec
execute if score @s ec.sq_progress matches 60.. run function evercraft:spirit_tome/complete
