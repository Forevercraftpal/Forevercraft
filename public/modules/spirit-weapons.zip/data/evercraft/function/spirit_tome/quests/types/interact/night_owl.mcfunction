# Night Owl — check if it's midnight (DayTime around 18000) and player is in overworld
# Race-safety (W14 W6.3): #sq_time ec.var is shared scratch; `time query` returns the same
# value for all players in the same tick (RT7); sequential `as @a` invariant protects ordering.
execute store result score #sq_time ec.var run time query minecraft:day
execute if score #sq_time ec.var matches 17500..18500 in minecraft:overworld at @s if predicate evercraft:spirit_tome/can_see_sky run function evercraft:spirit_tome/complete
