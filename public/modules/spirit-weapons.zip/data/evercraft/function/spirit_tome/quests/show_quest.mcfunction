# Spirit Tome — Show quest info on activation
# W14 W2.2: route writes per-pid sq_temp; thread pid via cart through outer.
function evercraft:spirit_tome/quests/show_activated_outer with storage evercraft:spirit_tome cart
