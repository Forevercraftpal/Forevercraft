# Spirit Tome — Interact dispatch sub-bucket 31..60 (W14 W6.1 bucket-split)
# Wiring Audit #14 W6.1: 27 branches split 3 ways to reduce per-tick score-cmp from 27 → ~10.

# 31: Splash Zone — (tracked via snowball hit advancement — see interact/snowball)
execute if score @s ec.sq_sub matches 31 run function evercraft:spirit_tome/quests/types/interact/snowball

# 32: Old Reliable — hold artifact for 1 hour (72000 ticks)
execute if score @s ec.sq_sub matches 32 run function evercraft:spirit_tome/quests/types/interact/artifact_hold

# 35: Guild Member — be in a guild (check guild tag)
execute if score @s ec.sq_sub matches 35 if entity @s[tag=ec.guild_member] run function evercraft:spirit_tome/complete

# 37: The Heights — Y >= 200
execute if score @s ec.sq_sub matches 37 at @s positioned ~ 200 ~ if entity @s[y=200,dy=200] run function evercraft:spirit_tome/complete

# 39: Night Fisher — catch a fish at night (check fish caught delta + time)
execute if score @s ec.sq_sub matches 39 run function evercraft:spirit_tome/quests/types/interact/night_fish

# 41: Bed Head — sleeping detection (predicate replaces sleeping_pos NBT scan)
execute if score @s ec.sq_sub matches 41 if predicate evercraft:is_sleeping run function evercraft:spirit_tome/complete

# 44: Lava Walker — stand near lava for 30 seconds
execute if score @s ec.sq_sub matches 44 run function evercraft:spirit_tome/quests/types/interact/lava_walk

# 46: Pumpkin Head — wearing carved pumpkin
execute if score @s ec.sq_sub matches 46 if items entity @s armor.head minecraft:carved_pumpkin run function evercraft:spirit_tome/complete

# 52: End Tourist — be in the End
execute if score @s ec.sq_sub matches 52 in minecraft:the_end run function evercraft:spirit_tome/complete

# 53: Deep Sea Diver — Y <= -40
execute if score @s ec.sq_sub matches 53 at @s positioned ~ -40 ~ if entity @s[y=-64,dy=24] run function evercraft:spirit_tome/complete

# 58: Bookworm — (auto-complete via block placement detection — simplified to always check)
execute if score @s ec.sq_sub matches 58 run function evercraft:spirit_tome/quests/types/interact/bookshelf
