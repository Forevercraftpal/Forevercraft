# Spirit Tome — Recover lost tome (macro inner)
# Wiring Audit #19 W3 (AU14-FOLLOWUP.1): macro form interpolates $(part) into lore
# so the re-given tome shows the player's current quest-part number (e.g. "Quest 47 of 100")
# matching what give.mcfunction does for fresh tomes. Pre-W3 the recover path shipped
# a flat "Quest in progress" lore string — cosmetic drift only; predicate match still held.
# Arg: part (int) — current ec.sq_part value, interpolated into lore[0].
$give @s book[custom_name={text:"Spirit Tome",color:"aqua",italic:false},lore=[{text:"Quest $(part) of 100",color:"gray",italic:true},{text:"",italic:false},{text:"A record of your spirit weapon's journey.",color:"dark_aqua",italic:true},{text:"Use to view and activate your next quest.",color:"dark_aqua",italic:true}],custom_data={spirit_tome:true,evercraft_item:true},consumable={consume_seconds:999999,sound:"intentionally_empty",has_consume_particles:false},use_cooldown={seconds:2,cooldown_group:"evercraft:spirit_tome"},max_stack_size=1,rarity=epic,enchantment_glint_override=true] 1
