# Spirit Tome — Recover lost tome
# Only runs if ec.sq_has_tome=1 but no tome in inventory

# Also check equipment (offhand)
execute if items entity @s weapon.offhand book[custom_data~{spirit_tome:true}] run return fail

# Re-give the tome (don't reset quest state).
# Wiring Audit #19 W3 (AU14-FOLLOWUP.1): macro form — lore reflects current ec.sq_part
# instead of the prior literal "Quest in progress" string (cosmetic drift fix; matches
# give.mcfunction shape for fresh tomes). Race-safety: sequential `as @a[tag=ec.sq_lost_tome]
# run function recover_tome` from check_progress invariant + macro-arg snapshot at
# `with storage` call-time means the per-player part read is atomic per AU14 race seat RT3.
execute store result storage evercraft:spirit_tome recover_args.part int 1 run scoreboard players get @s ec.sq_part
function evercraft:spirit_tome/recover_tome_macro with storage evercraft:spirit_tome recover_args

data modify storage evercraft:notify stage.c set value [{text:"Your tome has been restored.",color:"gray"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit

# W14 W5.1: clear the fast-path tag so steady-state probe resumes.
tag @s remove ec.sq_lost_tome
