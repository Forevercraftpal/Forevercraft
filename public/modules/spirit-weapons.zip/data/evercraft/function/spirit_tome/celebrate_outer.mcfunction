# Spirit Tome — Celebrate outer (W14 W2.2)
# Args from storage evercraft:spirit_tome cart:
#   pid = adv.gui_session (per-player session id, set by quests/route)
# Threads pid into the `with storage` path so celebrate reads per-player sq_temp.
$function evercraft:spirit_tome/celebrate with storage evercraft:sq_temp player_$(pid)
