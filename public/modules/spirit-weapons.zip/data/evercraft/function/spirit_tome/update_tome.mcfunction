# Spirit Tome — Update tome item lore after quest completion
# Scheduled for next tick after completion (can't modify item during use event).
# Schedule mode: `1t append` from complete:55 — intentional so same-tick multi-player
# completions each get their own pending fire. Same-player rapid-fire bounded by
# ec.sq_cd=3 (set in on_use:12) — at most 1 completion per 3-tick window per player.
# Documented per AU14 race seat RT9 (W14 W6.4).

# Process each player tagged for update
execute as @a[tag=ec.sq_update_tome] run function evercraft:spirit_tome/do_update_tome
