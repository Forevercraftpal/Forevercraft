# RETIRED 2026-06-05 (Wiring #39 park): redundant with the GUI exchange.
#
# This was the /trigger ec.ddex-driven Dreamdust exchange (slots 1-8). It is a DUPLICATE of the
# canonical GUI path (fountain menu → gacha/fountain/menu/ex_buy1-8 → confirm/ex_buyN →
# do_buy1-8), which grants the identical 8 trades:
#   1: 3 Dust → 1 Forever Coin        5: 100 Dust → Particle Choice
#   2: 10 Dust → Companion Treat      6: 100 Dust → Title Choice
#   3: 15 Dust → Awakening Stone      7: 200 Dust → Guaranteed Exquisite Pull
#   4: 30 Dust → Tree Token           8: 500 Dust → Guaranteed Mythical Pull
# Verified slot-for-slot against do_buy1-8 (Wiring #39). Keeping a /trigger path violates the
# GUI-only law, so the dispatch (gacha/tick) and the enable (init.mcfunction) were removed; the
# ec.ddex trigger is now only RESET per-tick so a stray set can never accumulate.
#
# NOTE — Convergence half-price gap (reported, not fixed here): this retired path was the ONLY
# caller of set_cost, so it was the only path that halved exchange prices during the Convergence
# of Dreams. The GUI do_buyN files use hardcoded literal costs with NO Convergence discount, yet
# spawn_exchange.mcfunction still shows players a "every wish costs but half its weight" label. So
# the dust-shop half-price promise is currently unfulfilled in the GUI. set_cost is preserved
# (now unused) for a future GUI Convergence wiring. See BIG_BRAIN/10-pending.md (#39 row).
