# Compute the effective Dreamdust cost for an exchange slot into #ddcost ec.temp.
# Macro arg: {base:N} = the slot's normal price.
#
# LIVE caller: the GUI dust-shop handlers gacha/fountain/menu/do_buy1-8 each call this with their
# slot's base price, then check affordability + deduct via #ddcost ec.temp (Wiring #39, 2026-06-05).
# So the spawn_exchange Convergence "half its weight" label now matches real behavior. (The old
# /trigger exchange/buy/process that previously called this is retired/tombstoned.)
# During Convergence of Dreams (#gacha_convergence ec.var matches 1) the price is halved,
# rounded UP so it never drops below the floor and is never free — matching the half-price
# coin pulls (try_pull_animated:10-12). Normal pull halves 5->3; here we halve every slot.
# ceil(base/2) = (base+1)/2 via floor division (#2 ec.const set in gacha/load).
# Runs as @s = player

# Start at full price
$scoreboard players set #ddcost ec.temp $(base)

# Convergence: halve the current value, rounded up (add 1 then floor-divide by 2)
execute if score #gacha_convergence ec.var matches 1 run scoreboard players add #ddcost ec.temp 1
execute if score #gacha_convergence ec.var matches 1 run scoreboard players operation #ddcost ec.temp /= #2 ec.const
