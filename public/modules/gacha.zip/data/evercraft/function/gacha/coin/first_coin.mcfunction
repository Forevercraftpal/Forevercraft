# First Forever Coin — Unlock Fountain of Eternal Dreams
# Runs as @s = player

scoreboard players set @s ec.first_coin 1

# Grant advancement (shows toast)
advancement grant @s only evercraft:gacha/first_wish

# Title notification
# (AB-1 sticky-times sweep 2026-06-10: explicit stamp — `title times` is sticky per player and this sequence set none, so it inherited whatever ran last.)
title @s times 10 60 20
title @s subtitle {"text":"Fountain of Eternal Dreams unlocked!","color":"#E0B0FF"}
title @s title {"text":"First Wish","color":"gold"}

data modify storage evercraft:notify stage.c set value [{text:"The ",color:"gray"},{text:"Fountain of Eternal Dreams",color:"#E0B0FF",bold:true},{text:" is now available! Open the ",color:"gray"},{text:"Codex",color:"gold"},{text:" to place your Fountain.",color:"gray"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
