# Reel animation tick — runs as @s = player with ec.reel_tick score, at @s
# Increments timer and dispatches scramble at decreasing frequency

scoreboard players add @s ec.reel_tick 1

# Safety: if reel entities gone (player walked away), abort
execute unless entity @e[tag=ec.ReelSlot,distance=..20,limit=1] run return run function evercraft:gacha/reel/cleanup

# === PHASE 1 (tick 1-20): Scramble every tick — rapid fire ===
execute if score @s ec.reel_tick matches 1..20 run function evercraft:gacha/reel/scramble

# === PHASE 2 (tick 21-40): Scramble every 2 ticks — slowing ===
execute if score @s ec.reel_tick matches 21..40 run scoreboard players operation #reel_mod ec.temp = @s ec.reel_tick
execute if score @s ec.reel_tick matches 21..40 run scoreboard players operation #reel_mod ec.temp %= #2 ec.const
execute if score @s ec.reel_tick matches 21..40 if score #reel_mod ec.temp matches 0 run function evercraft:gacha/reel/scramble

# === PHASE 3 (tick 41-55): Scramble every 3 ticks — tension building ===
execute if score @s ec.reel_tick matches 41..55 run scoreboard players operation #reel_mod ec.temp = @s ec.reel_tick
execute if score @s ec.reel_tick matches 41..55 run scoreboard players operation #reel_mod ec.temp %= #3 ec.const
execute if score @s ec.reel_tick matches 41..55 if score #reel_mod ec.temp matches 0 run function evercraft:gacha/reel/scramble

# === PHASE 4 (tick 56-70): Scramble every 5 ticks — almost there ===
execute if score @s ec.reel_tick matches 56..70 run scoreboard players operation #reel_mod ec.temp = @s ec.reel_tick
execute if score @s ec.reel_tick matches 56..70 run scoreboard players operation #reel_mod ec.temp %= #5 ec.const
execute if score @s ec.reel_tick matches 56..70 if score #reel_mod ec.temp matches 0 run function evercraft:gacha/reel/scramble

# === PHASE 5 (tick 75): last shift, then SETTLE the reel on the real reward ===
# After the final shift, pre-roll the sub + light the payline cell (set_winning_visual), then
# write the real reward straight into RS4 (reveal_visual) so the reel comes to rest DIRECTLY on
# the correct item. Previously RS4 was written at tick 80, so a random item sat in the slot for
# ~5 ticks and then "blipped" into the reward — Joseph found that dodgy (2026-06-02). The ~1/4 s
# of seeing the prize before the grant is a fine trade for a clean landing.
execute if score @s ec.reel_tick matches 75 run function evercraft:gacha/reel/scramble
execute if score @s ec.reel_tick matches 75 run function evercraft:gacha/reel/set_winning_visual
execute if score @s ec.reel_tick matches 75 run function evercraft:gacha/reel/reveal_visual

# === REVEAL / GRANT at tick 80 ===
# The item already settled at tick 75; tick 80 fires the celebration burst + grants the reward.
execute if score @s ec.reel_tick matches 80 run function evercraft:gacha/reel/reveal

# === TICK 95: Next pull or cleanup ===
# If more pulls remain (10-pull), transition to next animation
execute if score @s ec.reel_tick matches 95 if score @s ec.reel_count matches 1.. run return run function evercraft:gacha/reel/next_pull
# Otherwise, final cleanup
execute if score @s ec.reel_tick matches 95 run return run function evercraft:gacha/reel/cleanup

# Beacon ambient tension sound (plays periodically — tier-agnostic baseline)
execute if score @s ec.reel_tick matches 1 if score @s ec.fx_snd matches 1.. run playsound minecraft:block.beacon.ambient master @s ~ ~ ~ 0.4 0.8
execute if score @s ec.reel_tick matches 30 if score @s ec.fx_snd matches 1.. run playsound minecraft:block.beacon.ambient master @s ~ ~ ~ 0.5 1.0
execute if score @s ec.reel_tick matches 60 if score @s ec.fx_snd matches 1.. run playsound minecraft:block.beacon.ambient master @s ~ ~ ~ 0.6 1.2

# === RARITY TELL — escalating final-stretch build for high tiers (the Genshin two-beat) ===
# A beat BEFORE the lock-in (tick 75) / reveal (tick 80), higher tiers get a building
# aurora + rising chime so the player feels something potent coming. Tiers 1-2 stay calm
# (no extra cues). This hints at RARITY, never the exact item — identity stays hidden
# until tick 80. Single-tick triggers only (no per-tick loops) — cheap.
# Tick 62: first hint for Rare+ (a soft ascending chime)
execute if score @s ec.reel_tick matches 62 if score @s ec.reel_tier matches 3.. if score @s ec.fx_snd matches 1.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.4 1.0
# Tick 68: stronger hint for Ornate+ (chime climbs + a few rising sparks)
execute if score @s ec.reel_tick matches 68 if score @s ec.reel_tier matches 4.. if score @s ec.fx_snd matches 1.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.5 1.3
execute if score @s ec.reel_tick matches 68 if score @s ec.reel_tier matches 4.. if score @s ec.fx_vis matches 1.. run particle minecraft:end_rod ~ ~0.5 ~ 0.6 0.3 0.6 0.04 10 force @s
# Tick 72: the "it's coming" swell for Exquisite+ (high chime + a brighter spark gather)
execute if score @s ec.reel_tick matches 72 if score @s ec.reel_tier matches 5.. if score @s ec.fx_snd matches 1.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.6 1.7
execute if score @s ec.reel_tick matches 72 if score @s ec.reel_tier matches 5.. if score @s ec.fx_vis matches 1.. run particle minecraft:end_rod ~ ~0.8 ~ 0.7 0.5 0.7 0.05 16 force @s
# Tick 72: Mythical only — a deep, building toll layered under the swell ("the deep stirs")
execute if score @s ec.reel_tick matches 72 if score @s ec.reel_tier matches 6 if score @s ec.fx_snd matches 1.. run playsound minecraft:block.beacon.ambient master @s ~ ~ ~ 0.7 0.6

# Safety timeout
execute if score @s ec.reel_tick matches 100.. run function evercraft:gacha/reel/cleanup
