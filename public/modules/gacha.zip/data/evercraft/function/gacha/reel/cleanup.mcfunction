# Clean up reel animation entities and restore fountain menu
# Runs as @s = player, at @s

# Kill all reel entities nearby
kill @e[tag=ec.ReelElement,distance=..20]

# Reset reel scores
scoreboard players reset @s ec.reel_tick
scoreboard players reset @s ec.reel_tier
scoreboard players reset @s ec.reel_count
scoreboard players reset @s ec.reel_pull

# === DEFERRED LUCID-PEAK TITLE (P3-3) ===
# If a pull this reel crossed the Lucid Claim affordability line, spark/check banked the
# chat line + set this pending flag instead of firing the title on the reveal tick. Show
# the full-screen peak title NOW — after the whole reel (and any 10-pull sequence) is
# done — so it never stacks over a reveal title card. Once-only is still owned by
# ec.spark_notified in spark/check; this flag only governs WHEN the title lands.
execute if score @s ec.spark_peak_show matches 1 if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.firework_rocket.blast master @s ~ ~ ~ 1 1
# (AB-1 sticky-times sweep 2026-06-10: explicit stamp — `title times` is sticky per player and this sequence set none, so it inherited whatever ran last.)
execute if score @s ec.spark_peak_show matches 1 run title @s times 10 60 20
execute if score @s ec.spark_peak_show matches 1 run title @s subtitle {"text":"Choose ANY mythical artifact!","color":"gold"}
execute if score @s ec.spark_peak_show matches 1 run title @s title {"text":"★ Your Lucidity has Peaked! ★","color":"gold"}
scoreboard players set @s ec.spark_peak_show 0

# Re-open the fountain menu (player still has ec.InFountain tag)
# Remove the tag first so open.mcfunction doesn't toggle-close
tag @s remove ec.InFountain

# Re-enable fountain interaction
execute as @e[type=interaction,tag=ec.fountain_click,distance=..20] run data modify entity @s height set value 1.5f

# Restore fountain label
execute as @e[type=text_display,tag=ec.fountain_label,distance=..20] run data modify entity @s text set value {text:"\u2726 Fountain of Eternal Dreams \u2726",color:"#E0B0FF",bold:true}

# Reopen the menu
execute at @s run function evercraft:gacha/fountain/menu/open
