# Write the actual winning item into the center slot RS4 — at the SETTLE (tick 75).
# Runs right after set_winning_visual's pre-roll so the reel comes to rest directly on the real
# reward. (Previously ran at tick 80, which left a random item in the slot for ~5 ticks and then
# "blipped" into the reward — Joseph found that dodgy, 2026-06-02. Landing on the correct item up
# front reads far better; the ~1/4 s of foreknowledge before the grant is a fine trade.)
# Sub-reward was already pre-rolled into @s ec.reel_sub by set_winning_visual.
# Runs as @s = player, at @s

# === SET RS4 VISUAL TO MATCH ACTUAL REWARD ===
# Common (tier 1): 1=XP, 2=Awakening Stone, 3=Glyph, 4=Diamonds, 5=Crumb of Dreams, 6=Emeralds, 7=Furnishing Blueprint
execute if score @s ec.reel_tier matches 1 if score @s ec.reel_sub matches 1 as @e[tag=ec.RS4,limit=1,sort=nearest,distance=..20] run data modify entity @s item set value {id:"minecraft:experience_bottle",count:1}
execute if score @s ec.reel_tier matches 1 if score @s ec.reel_sub matches 2 as @e[tag=ec.RS4,limit=1,sort=nearest,distance=..20] run data modify entity @s item set value {id:"minecraft:copper_nugget",count:1}
execute if score @s ec.reel_tier matches 1 if score @s ec.reel_sub matches 3 as @e[tag=ec.RS4,limit=1,sort=nearest,distance=..20] run data modify entity @s item set value {id:"minecraft:globe_banner_pattern",count:1}
execute if score @s ec.reel_tier matches 1 if score @s ec.reel_sub matches 4 as @e[tag=ec.RS4,limit=1,sort=nearest,distance=..20] run data modify entity @s item set value {id:"minecraft:diamond",count:1}
execute if score @s ec.reel_tier matches 1 if score @s ec.reel_sub matches 5 as @e[tag=ec.RS4,limit=1,sort=nearest,distance=..20] run data modify entity @s item set value {id:"minecraft:bread",count:1}
execute if score @s ec.reel_tier matches 1 if score @s ec.reel_sub matches 6 as @e[tag=ec.RS4,limit=1,sort=nearest,distance=..20] run data modify entity @s item set value {id:"minecraft:emerald",count:1}
execute if score @s ec.reel_tier matches 1 if score @s ec.reel_sub matches 7 as @e[tag=ec.RS4,limit=1,sort=nearest,distance=..20] run data modify entity @s item set value {id:"minecraft:crafting_table",count:1}

# Uncommon (tier 2): 1=Awakening Stone, 2=Essentials Satchel, 3=Dungeon Key, 4=Companion Treat, 5=Netherite, 6=Artifact Crate, 7=Furnishings Crate, 8=Accessory Crate
execute if score @s ec.reel_tier matches 2 if score @s ec.reel_sub matches 1 as @e[tag=ec.RS4,limit=1,sort=nearest,distance=..20] run data modify entity @s item set value {id:"minecraft:copper_nugget",count:1}
execute if score @s ec.reel_tier matches 2 if score @s ec.reel_sub matches 2 as @e[tag=ec.RS4,limit=1,sort=nearest,distance=..20] run data modify entity @s item set value {id:"minecraft:leather",count:1}
execute if score @s ec.reel_tier matches 2 if score @s ec.reel_sub matches 3 as @e[tag=ec.RS4,limit=1,sort=nearest,distance=..20] run data modify entity @s item set value {id:"minecraft:trial_key",count:1}
execute if score @s ec.reel_tier matches 2 if score @s ec.reel_sub matches 4 as @e[tag=ec.RS4,limit=1,sort=nearest,distance=..20] run data modify entity @s item set value {id:"minecraft:cookie",count:1}
execute if score @s ec.reel_tier matches 2 if score @s ec.reel_sub matches 5 as @e[tag=ec.RS4,limit=1,sort=nearest,distance=..20] run data modify entity @s item set value {id:"minecraft:netherite_scrap",count:1}
execute if score @s ec.reel_tier matches 2 if score @s ec.reel_sub matches 6 as @e[tag=ec.RS4,limit=1,sort=nearest,distance=..20] run data modify entity @s item set value {id:"minecraft:barrel",count:1}
execute if score @s ec.reel_tier matches 2 if score @s ec.reel_sub matches 7 as @e[tag=ec.RS4,limit=1,sort=nearest,distance=..20] run data modify entity @s item set value {id:"minecraft:barrel",count:1}
execute if score @s ec.reel_tier matches 2 if score @s ec.reel_sub matches 8 as @e[tag=ec.RS4,limit=1,sort=nearest,distance=..20] run data modify entity @s item set value {id:"minecraft:barrel",count:1}

# Rare (tier 3): 1=Artifact Crate, 2=Tree Token, 3=Tree Shard, 4=Potion of Dreams, 5=Coin of Lucidity, 6=Companion Crate, 7=Chrono Shard, 8=Furnishings Crate, 9=Accessory Crate, 10=Furnishing Blueprint
execute if score @s ec.reel_tier matches 3 if score @s ec.reel_sub matches 1 as @e[tag=ec.RS4,limit=1,sort=nearest,distance=..20] run data modify entity @s item set value {id:"minecraft:barrel",count:1}
execute if score @s ec.reel_tier matches 3 if score @s ec.reel_sub matches 2 as @e[tag=ec.RS4,limit=1,sort=nearest,distance=..20] run data modify entity @s item set value {id:"minecraft:prismarine_crystals",count:1}
execute if score @s ec.reel_tier matches 3 if score @s ec.reel_sub matches 3 as @e[tag=ec.RS4,limit=1,sort=nearest,distance=..20] run data modify entity @s item set value {id:"minecraft:prismarine_shard",count:1}
execute if score @s ec.reel_tier matches 3 if score @s ec.reel_sub matches 4 as @e[tag=ec.RS4,limit=1,sort=nearest,distance=..20] run data modify entity @s item set value {id:"minecraft:potion",count:1}
execute if score @s ec.reel_tier matches 3 if score @s ec.reel_sub matches 5 as @e[tag=ec.RS4,limit=1,sort=nearest,distance=..20] run data modify entity @s item set value {id:"minecraft:gold_nugget",count:1}
execute if score @s ec.reel_tier matches 3 if score @s ec.reel_sub matches 6 as @e[tag=ec.RS4,limit=1,sort=nearest,distance=..20] run data modify entity @s item set value {id:"minecraft:barrel",count:1}
execute if score @s ec.reel_tier matches 3 if score @s ec.reel_sub matches 7 as @e[tag=ec.RS4,limit=1,sort=nearest,distance=..20] run data modify entity @s item set value {id:"minecraft:clock",count:1}
execute if score @s ec.reel_tier matches 3 if score @s ec.reel_sub matches 8 as @e[tag=ec.RS4,limit=1,sort=nearest,distance=..20] run data modify entity @s item set value {id:"minecraft:barrel",count:1}
execute if score @s ec.reel_tier matches 3 if score @s ec.reel_sub matches 9 as @e[tag=ec.RS4,limit=1,sort=nearest,distance=..20] run data modify entity @s item set value {id:"minecraft:barrel",count:1}
execute if score @s ec.reel_tier matches 3 if score @s ec.reel_sub matches 10 as @e[tag=ec.RS4,limit=1,sort=nearest,distance=..20] run data modify entity @s item set value {id:"minecraft:crafting_table",count:1}

# Ornate (tier 4): 1=Artifact Crate, 2=Seed of Forgetting, 3=Particle, 4=Title, 5=Companion Crate, 6=Furnishings Crate, 7=Accessory Crate, 8=Poor Antique
execute if score @s ec.reel_tier matches 4 if score @s ec.reel_sub matches 1 as @e[tag=ec.RS4,limit=1,sort=nearest,distance=..20] run data modify entity @s item set value {id:"minecraft:barrel",count:1}
execute if score @s ec.reel_tier matches 4 if score @s ec.reel_sub matches 2 as @e[tag=ec.RS4,limit=1,sort=nearest,distance=..20] run data modify entity @s item set value {id:"minecraft:torchflower_seeds",count:1}
execute if score @s ec.reel_tier matches 4 if score @s ec.reel_sub matches 3 as @e[tag=ec.RS4,limit=1,sort=nearest,distance=..20] run data modify entity @s item set value {id:"minecraft:firework_star",count:1}
execute if score @s ec.reel_tier matches 4 if score @s ec.reel_sub matches 4 as @e[tag=ec.RS4,limit=1,sort=nearest,distance=..20] run data modify entity @s item set value {id:"minecraft:name_tag",count:1}
execute if score @s ec.reel_tier matches 4 if score @s ec.reel_sub matches 5 as @e[tag=ec.RS4,limit=1,sort=nearest,distance=..20] run data modify entity @s item set value {id:"minecraft:barrel",count:1}
execute if score @s ec.reel_tier matches 4 if score @s ec.reel_sub matches 6 as @e[tag=ec.RS4,limit=1,sort=nearest,distance=..20] run data modify entity @s item set value {id:"minecraft:barrel",count:1}
execute if score @s ec.reel_tier matches 4 if score @s ec.reel_sub matches 7 as @e[tag=ec.RS4,limit=1,sort=nearest,distance=..20] run data modify entity @s item set value {id:"minecraft:barrel",count:1}
execute if score @s ec.reel_tier matches 4 if score @s ec.reel_sub matches 8 as @e[tag=ec.RS4,limit=1,sort=nearest,distance=..20] run data modify entity @s item set value {id:"minecraft:smithing_table",count:1}

# Exquisite (tier 5): 1=Artifact Crate, 2=Companion Crate, 3=Lore Piece, 4=Netherite Block, 5=Hearthstone, 6=Guidestone, 7=Glyphforge, 8=Accessory Crate, 9=Antique
execute if score @s ec.reel_tier matches 5 if score @s ec.reel_sub matches 1 as @e[tag=ec.RS4,limit=1,sort=nearest,distance=..20] run data modify entity @s item set value {id:"minecraft:barrel",count:1}
execute if score @s ec.reel_tier matches 5 if score @s ec.reel_sub matches 2 as @e[tag=ec.RS4,limit=1,sort=nearest,distance=..20] run data modify entity @s item set value {id:"minecraft:barrel",count:1}
execute if score @s ec.reel_tier matches 5 if score @s ec.reel_sub matches 3 as @e[tag=ec.RS4,limit=1,sort=nearest,distance=..20] run data modify entity @s item set value {id:"minecraft:book",count:1}
execute if score @s ec.reel_tier matches 5 if score @s ec.reel_sub matches 4 as @e[tag=ec.RS4,limit=1,sort=nearest,distance=..20] run data modify entity @s item set value {id:"minecraft:netherite_block",count:1}
execute if score @s ec.reel_tier matches 5 if score @s ec.reel_sub matches 5 as @e[tag=ec.RS4,limit=1,sort=nearest,distance=..20] run data modify entity @s item set value {id:"minecraft:lodestone",count:1}
execute if score @s ec.reel_tier matches 5 if score @s ec.reel_sub matches 6 as @e[tag=ec.RS4,limit=1,sort=nearest,distance=..20] run data modify entity @s item set value {id:"minecraft:lodestone",count:1}
execute if score @s ec.reel_tier matches 5 if score @s ec.reel_sub matches 7 as @e[tag=ec.RS4,limit=1,sort=nearest,distance=..20] run data modify entity @s item set value {id:"minecraft:lodestone",count:1}
execute if score @s ec.reel_tier matches 5 if score @s ec.reel_sub matches 8 as @e[tag=ec.RS4,limit=1,sort=nearest,distance=..20] run data modify entity @s item set value {id:"minecraft:barrel",count:1}
execute if score @s ec.reel_tier matches 5 if score @s ec.reel_sub matches 9 as @e[tag=ec.RS4,limit=1,sort=nearest,distance=..20] run data modify entity @s item set value {id:"minecraft:smithing_table",count:1}

# Mythical (tier 6): 1-2=Artifact, 3=Companion, 4=Dreamdust Crystal, 5=Wishing Star, 6=Pristine Antique
execute if score @s ec.reel_tier matches 6 if score @s ec.reel_sub matches 1..2 as @e[tag=ec.RS4,limit=1,sort=nearest,distance=..20] run data modify entity @s item set value {id:"minecraft:netherite_sword",count:1}
execute if score @s ec.reel_tier matches 6 if score @s ec.reel_sub matches 3 as @e[tag=ec.RS4,limit=1,sort=nearest,distance=..20] run data modify entity @s item set value {id:"minecraft:barrel",count:1}
execute if score @s ec.reel_tier matches 6 if score @s ec.reel_sub matches 4 as @e[tag=ec.RS4,limit=1,sort=nearest,distance=..20] run data modify entity @s item set value {id:"minecraft:stick",count:1,components:{"minecraft:item_model":"minecraft:amethyst_cluster"}}
execute if score @s ec.reel_tier matches 6 if score @s ec.reel_sub matches 5 as @e[tag=ec.RS4,limit=1,sort=nearest,distance=..20] run data modify entity @s item set value {id:"minecraft:nether_star",count:1}
execute if score @s ec.reel_tier matches 6 if score @s ec.reel_sub matches 6 as @e[tag=ec.RS4,limit=1,sort=nearest,distance=..20] run data modify entity @s item set value {id:"minecraft:smithing_table",count:1}
