# Handle skip button click — runs as @s = the verified clicker (dispatched on target
# from gacha/tick). The interaction record is consumed by the caller (tick line 22).
execute if entity @s[tag=ec.InFountain] at @s run function evercraft:gacha/reel/skip
