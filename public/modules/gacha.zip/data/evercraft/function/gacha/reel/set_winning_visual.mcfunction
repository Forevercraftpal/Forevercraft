# Pre-roll the sub-reward for the current tier (used by reveal to grant) + light the payline cell.
# Called at tick 75 (last scramble). reveal_visual runs right after (also tick 75) to write the
# real item into RS4, so the reel settles DIRECTLY on the correct reward — no tick-80 "blip"
# (Joseph 2026-06-02). The only visual change in THIS file is the rarity cell recolor below.
# Runs as @s = player, at @s
# Stores pre-roll in @s ec.reel_sub — reveal copies this to #reward_roll before granting

# === PRE-ROLL SUB-REWARD BASED ON TIER ===
execute if score @s ec.reel_tier matches 1 store result score @s ec.reel_sub run random value 1..7
execute if score @s ec.reel_tier matches 2 store result score @s ec.reel_sub run random value 1..8
execute if score @s ec.reel_tier matches 3 store result score @s ec.reel_sub run random value 1..10
execute if score @s ec.reel_tier matches 4 store result score @s ec.reel_sub run random value 1..8
execute if score @s ec.reel_tier matches 5 store result score @s ec.reel_sub run random value 1..9
execute if score @s ec.reel_tier matches 6 store result score @s ec.reel_sub run random value 1..6

# === RARITY TELL — lock-in flash keyed to tier (a beat before the reveal) ===
# Low tiers (1-2) stay calm: just the tension-release bell.
# Higher tiers get an escalating colored burst over the winning slot so the player
# feels the rarity coming WITHOUT yet seeing the exact item (B8: identity stays hidden
# until tick 80). Mirrors the Genshin gold-vs-blue / Hearthstone card-glow two-beat.
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.6 1.0

# === LIGHT THE WINNING CELL IN THE RARITY COLOUR (the payline spotlight pops at lock-in) ===
# Recolors the ec.ReelSpot backdrop (transformation/display props persist — only the item swaps).
execute if score @s ec.reel_tier matches 1 as @e[tag=ec.ReelSpot,limit=1,sort=nearest,distance=..20] run data modify entity @s item set value {id:"white_stained_glass_pane",count:1}
execute if score @s ec.reel_tier matches 2 as @e[tag=ec.ReelSpot,limit=1,sort=nearest,distance=..20] run data modify entity @s item set value {id:"lime_stained_glass_pane",count:1}
execute if score @s ec.reel_tier matches 3 as @e[tag=ec.ReelSpot,limit=1,sort=nearest,distance=..20] run data modify entity @s item set value {id:"light_blue_stained_glass_pane",count:1}
execute if score @s ec.reel_tier matches 4 as @e[tag=ec.ReelSpot,limit=1,sort=nearest,distance=..20] run data modify entity @s item set value {id:"purple_stained_glass_pane",count:1}
execute if score @s ec.reel_tier matches 5 as @e[tag=ec.ReelSpot,limit=1,sort=nearest,distance=..20] run data modify entity @s item set value {id:"yellow_stained_glass_pane",count:1}
execute if score @s ec.reel_tier matches 6 as @e[tag=ec.ReelSpot,limit=1,sort=nearest,distance=..20] run data modify entity @s item set value {id:"magenta_stained_glass_pane",count:1}

# Rare (3): a calm aqua shimmer at the center slot
execute if score @s ec.reel_tier matches 3 if score @s ec.fx_vis matches 1.. run particle minecraft:wax_on ~ ~1.4 ~ 0.25 0.4 0.25 0.02 12 force @s
execute if score @s ec.reel_tier matches 3 if score @s ec.fx_snd matches 1.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.5 1.2

# Ornate (4): brighter purple sparkle + a higher chime
execute if score @s ec.reel_tier matches 4 if score @s ec.fx_vis matches 1.. run particle minecraft:witch ~ ~1.4 ~ 0.3 0.5 0.3 0.02 18 force @s
execute if score @s ec.reel_tier matches 4 if score @s ec.fx_snd matches 1.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.6 1.5

# Exquisite (5): golden end_rod gather + a soft ascending bell
execute if score @s ec.reel_tier matches 5 if score @s ec.fx_vis matches 1.. run particle minecraft:end_rod ~ ~1.5 ~ 0.3 0.6 0.3 0.03 24 force @s
execute if score @s ec.reel_tier matches 5 if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.7 1.6

# Mythical (6): dense golden aurora + a distant, building toll — the "something ancient stirs" beat
execute if score @s ec.reel_tier matches 6 if score @s ec.fx_vis matches 1.. run particle minecraft:end_rod ~ ~1.5 ~ 0.4 0.8 0.4 0.05 40 force @s
execute if score @s ec.reel_tier matches 6 if score @s ec.fx_vis matches 1.. run particle minecraft:enchant ~ ~1.2 ~ 0.5 0.8 0.5 1 30 force @s
execute if score @s ec.reel_tier matches 6 if score @s ec.fx_snd matches 1.. run playsound minecraft:block.beacon.power_select master @s ~ ~ ~ 0.8 0.7
