# Lucid Claim — Spawn 9 exclusive artifact items for selection
# Run as the player, at player, facing anchor
# Single centered column layout

# Subtitle instruction
execute rotated ~ 0 positioned ^ ^2.67 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["Adv.MenuElement","Adv.SectionContent"],billboard:"center",text:{text:"Select an artifact, then click again to confirm",color:"gray",italic:true},background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.189f,0.189f,0.189f]}}

# === 9 Spark-Exclusive Mythical Artifacts ===

# Item 0: The Starless Night (Sword)
execute rotated ~ 0 positioned ^ ^2.53 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["Adv.MenuElement","Adv.SectionContent","Adv.ArtItems","Adv.ArtI_the_starless_night"],billboard:"center",text:[{text:"\u2606 ",color:"yellow"},{text:"The Starless Night",color:"gold"}],background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.243f,0.243f,0.243f]}}

# Item 1: Shooting Star (Bow)
execute rotated ~ 0 positioned ^ ^2.45 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["Adv.MenuElement","Adv.SectionContent","Adv.ArtItems","Adv.ArtI_shooting_star"],billboard:"center",text:[{text:"\u2606 ",color:"yellow"},{text:"Shooting Star",color:"gold"}],background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.243f,0.243f,0.243f]}}

# Item 2: Dreamcast Compass (Accessory)
execute rotated ~ 0 positioned ^ ^2.37 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["Adv.MenuElement","Adv.SectionContent","Adv.ArtItems","Adv.ArtI_dreamcast_compass"],billboard:"center",text:[{text:"\u2606 ",color:"yellow"},{text:"Dreamcast Compass",color:"gold"}],background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.243f,0.243f,0.243f]}}

# Item 3: Hero's Helmet (Armor)
execute rotated ~ 0 positioned ^ ^2.29 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["Adv.MenuElement","Adv.SectionContent","Adv.ArtItems","Adv.ArtI_hero_helmet"],billboard:"center",text:[{text:"\u2606 ",color:"yellow"},{text:"Hero's Helmet",color:"gold"}],background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.243f,0.243f,0.243f]}}

# Item 4: Hero's Chestplate (Armor)
execute rotated ~ 0 positioned ^ ^2.21 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["Adv.MenuElement","Adv.SectionContent","Adv.ArtItems","Adv.ArtI_hero_chestplate"],billboard:"center",text:[{text:"\u2606 ",color:"yellow"},{text:"Hero's Chestplate",color:"gold"}],background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.243f,0.243f,0.243f]}}

# Item 5: Hero's Leggings (Armor)
execute rotated ~ 0 positioned ^ ^2.13 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["Adv.MenuElement","Adv.SectionContent","Adv.ArtItems","Adv.ArtI_hero_leggings"],billboard:"center",text:[{text:"\u2606 ",color:"yellow"},{text:"Hero's Leggings",color:"gold"}],background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.243f,0.243f,0.243f]}}

# Item 6: Hero's Boots (Armor)
execute rotated ~ 0 positioned ^ ^2.05 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["Adv.MenuElement","Adv.SectionContent","Adv.ArtItems","Adv.ArtI_hero_boots"],billboard:"center",text:[{text:"\u2606 ",color:"yellow"},{text:"Hero's Boots",color:"gold"}],background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.243f,0.243f,0.243f]}}

# Item 7: Robot Dancer's Sword (Dancer)
execute rotated ~ 0 positioned ^ ^1.97 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["Adv.MenuElement","Adv.SectionContent","Adv.ArtItems","Adv.ArtI_robot_dancers_sword"],billboard:"center",text:[{text:"\u2606 ",color:"yellow"},{text:"Robot Dancer's Sword",color:"gold"}],background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.243f,0.243f,0.243f]}}

# Item 8: Droid Dancer's Sword (Dancer)
execute rotated ~ 0 positioned ^ ^1.89 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["Adv.MenuElement","Adv.SectionContent","Adv.ArtItems","Adv.ArtI_droid_dancers_sword"],billboard:"center",text:[{text:"\u2606 ",color:"yellow"},{text:"Droid Dancer's Sword",color:"gold"}],background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.243f,0.243f,0.243f]}}

# === Click Interaction Entities ===
# Formula: interaction_Y = text_Y - height. Hitbox top aligns with text position.
# [strip] Adv.MenuElement: 0.8w split into 7 x 0.12 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute rotated ~ 0 positioned ^-0.34 ^2.49 ^1.8 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Adv.ArtItems","Adv.ArtIClick0"],width:0.12f,height:0.08f,response:1b}
execute rotated ~ 0 positioned ^-0.2267 ^2.49 ^1.8 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Adv.ArtItems","Adv.ArtIClick0"],width:0.12f,height:0.08f,response:1b}
execute rotated ~ 0 positioned ^-0.1133 ^2.49 ^1.8 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Adv.ArtItems","Adv.ArtIClick0"],width:0.12f,height:0.08f,response:1b}
execute rotated ~ 0 positioned ^0 ^2.49 ^1.8 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Adv.ArtItems","Adv.ArtIClick0"],width:0.12f,height:0.08f,response:1b}
execute rotated ~ 0 positioned ^0.1133 ^2.49 ^1.8 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Adv.ArtItems","Adv.ArtIClick0"],width:0.12f,height:0.08f,response:1b}
execute rotated ~ 0 positioned ^0.2267 ^2.49 ^1.8 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Adv.ArtItems","Adv.ArtIClick0"],width:0.12f,height:0.08f,response:1b}
execute rotated ~ 0 positioned ^0.34 ^2.49 ^1.8 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Adv.ArtItems","Adv.ArtIClick0"],width:0.12f,height:0.08f,response:1b}
# [strip] Adv.MenuElement: 0.8w split into 7 x 0.12 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute rotated ~ 0 positioned ^-0.34 ^2.41 ^1.8 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Adv.ArtItems","Adv.ArtIClick1"],width:0.12f,height:0.08f,response:1b}
execute rotated ~ 0 positioned ^-0.2267 ^2.41 ^1.8 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Adv.ArtItems","Adv.ArtIClick1"],width:0.12f,height:0.08f,response:1b}
execute rotated ~ 0 positioned ^-0.1133 ^2.41 ^1.8 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Adv.ArtItems","Adv.ArtIClick1"],width:0.12f,height:0.08f,response:1b}
execute rotated ~ 0 positioned ^0 ^2.41 ^1.8 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Adv.ArtItems","Adv.ArtIClick1"],width:0.12f,height:0.08f,response:1b}
execute rotated ~ 0 positioned ^0.1133 ^2.41 ^1.8 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Adv.ArtItems","Adv.ArtIClick1"],width:0.12f,height:0.08f,response:1b}
execute rotated ~ 0 positioned ^0.2267 ^2.41 ^1.8 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Adv.ArtItems","Adv.ArtIClick1"],width:0.12f,height:0.08f,response:1b}
execute rotated ~ 0 positioned ^0.34 ^2.41 ^1.8 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Adv.ArtItems","Adv.ArtIClick1"],width:0.12f,height:0.08f,response:1b}
# [strip] Adv.MenuElement: 0.8w split into 7 x 0.12 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute rotated ~ 0 positioned ^-0.34 ^2.33 ^1.8 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Adv.ArtItems","Adv.ArtIClick2"],width:0.12f,height:0.08f,response:1b}
execute rotated ~ 0 positioned ^-0.2267 ^2.33 ^1.8 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Adv.ArtItems","Adv.ArtIClick2"],width:0.12f,height:0.08f,response:1b}
execute rotated ~ 0 positioned ^-0.1133 ^2.33 ^1.8 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Adv.ArtItems","Adv.ArtIClick2"],width:0.12f,height:0.08f,response:1b}
execute rotated ~ 0 positioned ^0 ^2.33 ^1.8 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Adv.ArtItems","Adv.ArtIClick2"],width:0.12f,height:0.08f,response:1b}
execute rotated ~ 0 positioned ^0.1133 ^2.33 ^1.8 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Adv.ArtItems","Adv.ArtIClick2"],width:0.12f,height:0.08f,response:1b}
execute rotated ~ 0 positioned ^0.2267 ^2.33 ^1.8 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Adv.ArtItems","Adv.ArtIClick2"],width:0.12f,height:0.08f,response:1b}
execute rotated ~ 0 positioned ^0.34 ^2.33 ^1.8 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Adv.ArtItems","Adv.ArtIClick2"],width:0.12f,height:0.08f,response:1b}
# [strip] Adv.MenuElement: 0.8w split into 7 x 0.12 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute rotated ~ 0 positioned ^-0.34 ^2.25 ^1.8 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Adv.ArtItems","Adv.ArtIClick3"],width:0.12f,height:0.08f,response:1b}
execute rotated ~ 0 positioned ^-0.2267 ^2.25 ^1.8 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Adv.ArtItems","Adv.ArtIClick3"],width:0.12f,height:0.08f,response:1b}
execute rotated ~ 0 positioned ^-0.1133 ^2.25 ^1.8 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Adv.ArtItems","Adv.ArtIClick3"],width:0.12f,height:0.08f,response:1b}
execute rotated ~ 0 positioned ^0 ^2.25 ^1.8 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Adv.ArtItems","Adv.ArtIClick3"],width:0.12f,height:0.08f,response:1b}
execute rotated ~ 0 positioned ^0.1133 ^2.25 ^1.8 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Adv.ArtItems","Adv.ArtIClick3"],width:0.12f,height:0.08f,response:1b}
execute rotated ~ 0 positioned ^0.2267 ^2.25 ^1.8 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Adv.ArtItems","Adv.ArtIClick3"],width:0.12f,height:0.08f,response:1b}
execute rotated ~ 0 positioned ^0.34 ^2.25 ^1.8 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Adv.ArtItems","Adv.ArtIClick3"],width:0.12f,height:0.08f,response:1b}
# [strip] Adv.MenuElement: 0.8w split into 7 x 0.12 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute rotated ~ 0 positioned ^-0.34 ^2.17 ^1.8 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Adv.ArtItems","Adv.ArtIClick4"],width:0.12f,height:0.08f,response:1b}
execute rotated ~ 0 positioned ^-0.2267 ^2.17 ^1.8 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Adv.ArtItems","Adv.ArtIClick4"],width:0.12f,height:0.08f,response:1b}
execute rotated ~ 0 positioned ^-0.1133 ^2.17 ^1.8 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Adv.ArtItems","Adv.ArtIClick4"],width:0.12f,height:0.08f,response:1b}
execute rotated ~ 0 positioned ^0 ^2.17 ^1.8 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Adv.ArtItems","Adv.ArtIClick4"],width:0.12f,height:0.08f,response:1b}
execute rotated ~ 0 positioned ^0.1133 ^2.17 ^1.8 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Adv.ArtItems","Adv.ArtIClick4"],width:0.12f,height:0.08f,response:1b}
execute rotated ~ 0 positioned ^0.2267 ^2.17 ^1.8 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Adv.ArtItems","Adv.ArtIClick4"],width:0.12f,height:0.08f,response:1b}
execute rotated ~ 0 positioned ^0.34 ^2.17 ^1.8 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Adv.ArtItems","Adv.ArtIClick4"],width:0.12f,height:0.08f,response:1b}
# [strip] Adv.MenuElement: 0.8w split into 7 x 0.12 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute rotated ~ 0 positioned ^-0.34 ^2.09 ^1.8 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Adv.ArtItems","Adv.ArtIClick5"],width:0.12f,height:0.08f,response:1b}
execute rotated ~ 0 positioned ^-0.2267 ^2.09 ^1.8 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Adv.ArtItems","Adv.ArtIClick5"],width:0.12f,height:0.08f,response:1b}
execute rotated ~ 0 positioned ^-0.1133 ^2.09 ^1.8 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Adv.ArtItems","Adv.ArtIClick5"],width:0.12f,height:0.08f,response:1b}
execute rotated ~ 0 positioned ^0 ^2.09 ^1.8 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Adv.ArtItems","Adv.ArtIClick5"],width:0.12f,height:0.08f,response:1b}
execute rotated ~ 0 positioned ^0.1133 ^2.09 ^1.8 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Adv.ArtItems","Adv.ArtIClick5"],width:0.12f,height:0.08f,response:1b}
execute rotated ~ 0 positioned ^0.2267 ^2.09 ^1.8 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Adv.ArtItems","Adv.ArtIClick5"],width:0.12f,height:0.08f,response:1b}
execute rotated ~ 0 positioned ^0.34 ^2.09 ^1.8 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Adv.ArtItems","Adv.ArtIClick5"],width:0.12f,height:0.08f,response:1b}
# [strip] Adv.MenuElement: 0.8w split into 7 x 0.12 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute rotated ~ 0 positioned ^-0.34 ^2.01 ^1.8 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Adv.ArtItems","Adv.ArtIClick6"],width:0.12f,height:0.08f,response:1b}
execute rotated ~ 0 positioned ^-0.2267 ^2.01 ^1.8 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Adv.ArtItems","Adv.ArtIClick6"],width:0.12f,height:0.08f,response:1b}
execute rotated ~ 0 positioned ^-0.1133 ^2.01 ^1.8 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Adv.ArtItems","Adv.ArtIClick6"],width:0.12f,height:0.08f,response:1b}
execute rotated ~ 0 positioned ^0 ^2.01 ^1.8 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Adv.ArtItems","Adv.ArtIClick6"],width:0.12f,height:0.08f,response:1b}
execute rotated ~ 0 positioned ^0.1133 ^2.01 ^1.8 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Adv.ArtItems","Adv.ArtIClick6"],width:0.12f,height:0.08f,response:1b}
execute rotated ~ 0 positioned ^0.2267 ^2.01 ^1.8 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Adv.ArtItems","Adv.ArtIClick6"],width:0.12f,height:0.08f,response:1b}
execute rotated ~ 0 positioned ^0.34 ^2.01 ^1.8 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Adv.ArtItems","Adv.ArtIClick6"],width:0.12f,height:0.08f,response:1b}
# [strip] Adv.MenuElement: 0.8w split into 7 x 0.12 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute rotated ~ 0 positioned ^-0.34 ^1.93 ^1.8 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Adv.ArtItems","Adv.ArtIClick7"],width:0.12f,height:0.08f,response:1b}
execute rotated ~ 0 positioned ^-0.2267 ^1.93 ^1.8 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Adv.ArtItems","Adv.ArtIClick7"],width:0.12f,height:0.08f,response:1b}
execute rotated ~ 0 positioned ^-0.1133 ^1.93 ^1.8 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Adv.ArtItems","Adv.ArtIClick7"],width:0.12f,height:0.08f,response:1b}
execute rotated ~ 0 positioned ^0 ^1.93 ^1.8 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Adv.ArtItems","Adv.ArtIClick7"],width:0.12f,height:0.08f,response:1b}
execute rotated ~ 0 positioned ^0.1133 ^1.93 ^1.8 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Adv.ArtItems","Adv.ArtIClick7"],width:0.12f,height:0.08f,response:1b}
execute rotated ~ 0 positioned ^0.2267 ^1.93 ^1.8 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Adv.ArtItems","Adv.ArtIClick7"],width:0.12f,height:0.08f,response:1b}
execute rotated ~ 0 positioned ^0.34 ^1.93 ^1.8 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Adv.ArtItems","Adv.ArtIClick7"],width:0.12f,height:0.08f,response:1b}
# [strip] Adv.MenuElement: 0.8w split into 7 x 0.12 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute rotated ~ 0 positioned ^-0.34 ^1.85 ^1.8 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Adv.ArtItems","Adv.ArtIClick8"],width:0.12f,height:0.08f,response:1b}
execute rotated ~ 0 positioned ^-0.2267 ^1.85 ^1.8 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Adv.ArtItems","Adv.ArtIClick8"],width:0.12f,height:0.08f,response:1b}
execute rotated ~ 0 positioned ^-0.1133 ^1.85 ^1.8 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Adv.ArtItems","Adv.ArtIClick8"],width:0.12f,height:0.08f,response:1b}
execute rotated ~ 0 positioned ^0 ^1.85 ^1.8 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Adv.ArtItems","Adv.ArtIClick8"],width:0.12f,height:0.08f,response:1b}
execute rotated ~ 0 positioned ^0.1133 ^1.85 ^1.8 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Adv.ArtItems","Adv.ArtIClick8"],width:0.12f,height:0.08f,response:1b}
execute rotated ~ 0 positioned ^0.2267 ^1.85 ^1.8 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Adv.ArtItems","Adv.ArtIClick8"],width:0.12f,height:0.08f,response:1b}
execute rotated ~ 0 positioned ^0.34 ^1.85 ^1.8 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Adv.ArtItems","Adv.ArtIClick8"],width:0.12f,height:0.08f,response:1b}

# Store artifact data for click handler (reuses codex click system)
data modify storage evercraft:codex_gui art_slots set value ["the_starless_night","shooting_star","dreamcast_compass","hero_helmet","hero_chestplate","hero_leggings","hero_boots","robot_dancers_sword","droid_dancers_sword"]
data modify storage evercraft:codex_gui art_tier set value "mythical"

# Refresh to show collected status
function evercraft:gacha/spark/gui/refresh
