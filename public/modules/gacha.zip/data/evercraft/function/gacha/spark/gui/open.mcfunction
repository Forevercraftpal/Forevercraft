# Lucid Claim — Open the artifact selection GUI
# Runs as @s = player, at @s
# Called from fountain menu button click
#
# Cost RAMPS (canonical — Joseph ruling 2026-05-29): 1st=400, 2nd=250, 3rd=125,
# 4th=75, 5th+=50 lucidity. Lucidity is deducted (banked), never wiped.

# === Determine required cost from this player's claim counter ===
scoreboard players set #spark_cost ec.var 50
execute if score @s ec.spark_claims matches 0 run scoreboard players set #spark_cost ec.var 400
execute if score @s ec.spark_claims matches 1 run scoreboard players set #spark_cost ec.var 250
execute if score @s ec.spark_claims matches 2 run scoreboard players set #spark_cost ec.var 125
execute if score @s ec.spark_claims matches 3 run scoreboard players set #spark_cost ec.var 75

# === Validate lucidity meets the ramp cost (not just the 50 notify threshold) ===
scoreboard players operation #spark_check ec.var = @s ec.wish_spark
scoreboard players operation #spark_check ec.var -= #spark_cost ec.var
execute if score #spark_check ec.var matches ..-1 run data modify storage evercraft:notify stage.c set value [{text:"★ ",color:"gray"},{text:"Lucid Claim not ready! ",color:"red"},{text:"You have ",color:"gray"},{score:{name:"@s",objective:"ec.wish_spark"},color:"aqua"},{text:" / ",color:"dark_gray"},{score:{name:"#spark_cost",objective:"ec.var"},color:"gold"},{text:" lucidity needed.",color:"gray"},{text:" ★",color:"gray"}]
execute if score #spark_check ec.var matches ..-1 run scoreboard players set #ndur ec.temp 45
execute if score #spark_check ec.var matches ..-1 run return run function evercraft:util/notify/emit

# Close fountain menu first
function evercraft:gacha/fountain/menu/close

# Tag for lucid claim mode
tag @s add ec.lucid_claim_active

# Open the codex shell — setup_codex will be called at the end of open
function evercraft:codex/hub/open
