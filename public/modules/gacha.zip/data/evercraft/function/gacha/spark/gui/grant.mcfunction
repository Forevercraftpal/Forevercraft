# Lucid Claim — Grant Selected Artifact (Macro)
# Macro args: art (artifact ID), tier (tier name)
# Run as @s = player
#
# Lucidity cost RAMPS (canonical — Joseph ruling 2026-05-29, first step softened to 400
# 2026-05-29): 1st=400, 2nd=250, 3rd=125, 4th=75, 5th+=50. Lucidity is DEDUCTED, never
# wiped — banked progress carries toward the next claim. ec.spark_claims tracks claims made.

# === Determine required cost from claim counter (ec.spark_claims = 0 for first) ===
scoreboard players set #spark_cost ec.var 50
execute if score @s ec.spark_claims matches 0 run scoreboard players set #spark_cost ec.var 400
execute if score @s ec.spark_claims matches 1 run scoreboard players set #spark_cost ec.var 250
execute if score @s ec.spark_claims matches 2 run scoreboard players set #spark_cost ec.var 125
execute if score @s ec.spark_claims matches 3 run scoreboard players set #spark_cost ec.var 75

# === Validate lucidity is sufficient (ec.wish_spark >= required cost) ===
scoreboard players operation #spark_check ec.var = @s ec.wish_spark
scoreboard players operation #spark_check ec.var -= #spark_cost ec.var
execute if score #spark_check ec.var matches ..-1 run data modify storage evercraft:notify stage.c set value [{text:"★ ",color:"gray"},{text:"Lucid Claim requires ",color:"red"},{score:{name:"#spark_cost",objective:"ec.var"},color:"gold"},{text:" lucidity (you have ",color:"red"},{score:{name:"@s",objective:"ec.wish_spark"},color:"gold"},{text:").",color:"red"},{text:" ★",color:"gray"}]
execute if score #spark_check ec.var matches ..-1 run scoreboard players set #ndur ec.temp 45
execute if score #spark_check ec.var matches ..-1 run return run function evercraft:util/notify/emit

# === Deduct lucidity cost (NOT wipe — remainder banks toward next claim) ===
scoreboard players operation @s ec.wish_spark -= #spark_cost ec.var

# === Bump claim counter for next-time ramp ===
scoreboard players add @s ec.spark_claims 1

# Grant the artifact from its loot table
# Inv-full guard: drop at the player's feet rather than void on a full inventory.
execute store result score #inv_full ec.var run function evercraft:util/check_inv_full
$execute if score #inv_full ec.var matches 0 run loot give @s loot evercraft:artifacts/$(tier)/$(art)
$execute if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:artifacts/$(tier)/$(art)

# Celebration effects
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 1 0.8
# "something ancient stirs" — arcane mythical-claim cue (was ender_dragon.growl; dream-themed, not a dragon weapon)
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.beacon.power_select master @s ~ ~ ~ 0.6 0.6
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.amethyst_block.resonate master @s ~ ~ ~ 0.5 0.7
execute if score @s ec.fx_vis matches 1.. run particle totem_of_undying ~ ~1.5 ~ 1 1.5 1 0.5 100 force @s
execute if score @s ec.fx_vis matches 1.. run particle end_rod ~ ~2 ~ 0.5 1 0.5 0.05 50 force @s

# Grant message (use saved display name from storage)
data modify storage evercraft:notify stage.c set value [{text:"\u2605\u2605\u2605 ",color:"gold"},{text:"Lucid Claim granted you: ",color:"gray"},{nbt:"selected_name",storage:"evercraft:lucid_claim",interpret:true,color:"gold",bold:true},{text:"!",color:"gray"},{text:" \u2605\u2605\u2605",color:"gold"}]
scoreboard players set #ndur ec.temp 50
function evercraft:util/notify/emit

# Honest banking message \u2014 show cost paid + remaining lucidity carried forward
data modify storage evercraft:notify stage.c set value [{text:"\u2605 ",color:"gray"},{text:"Spent ",color:"gray"},{score:{name:"#spark_cost",objective:"ec.var"},color:"gold"},{text:" lucidity \u2014 ",color:"gray"},{score:{name:"@s",objective:"ec.wish_spark"},color:"aqua"},{text:" banked toward your next claim.",color:"gray"},{text:" \u2605",color:"gray"}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit

# Broadcast to OTHER players (names the actor \u2192 \u00a75b). Actor tagged out \u2014 they already get the
# personal "Lucid Claim granted you: <item>!" action-bar line + the screen title (fixed 2026-06-02).
tag @s add ec.brag_self
execute as @s run function evercraft:util/notify/whoami
data modify storage evercraft:notify stage.c set value [{text:"\u2605\u2605\u2605 ",color:"gold"},{text:"",color:"gold"},{text:" claimed their ",color:"gray"},{text:"LUCID CLAIM",color:"gold",bold:true},{text:" from the Fountain!",color:"gray"},{text:" \u2605\u2605\u2605",color:"gold"}]
data modify storage evercraft:notify stage.c[1].text set from storage evercraft:notify named.who
scoreboard players set #ndur ec.temp 50
execute as @s run execute as @a[tag=!ec.brag_self] run scoreboard players set #nttl ec.temp 600
execute as @s run execute as @a[tag=!ec.brag_self] run function evercraft:util/notify/emit_keep
tag @s remove ec.brag_self

# Title display
# (AB-1 sticky-times sweep 2026-06-10: explicit stamp — `title times` is sticky per player and this sequence set none, so it inherited whatever ran last.)
title @s times 10 60 20
title @s subtitle {"text":"Lucid Dream Fulfilled!","color":"gold"}
title @s title {"text":"\u2605 CLAIMED \u2605","color":"gold"}

# Lucidity is DEDUCTED above (ramp cost), NOT wiped — banked remainder carries forward.

# Cleanup — remove tag and close codex
tag @s remove ec.lucid_claim_active
function evercraft:advantage/gui/close
