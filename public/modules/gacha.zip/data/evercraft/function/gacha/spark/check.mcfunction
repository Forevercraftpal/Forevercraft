# Check if player can now afford their next Lucid Claim.
# Runs as @s = player
#
# Cost RAMPS (canonical \u2014 Joseph ruling 2026-05-29): 1st=400, 2nd=250, 3rd=125,
# 4th=75, 5th+=50 lucidity. Lucidity (+1 per pull) is deducted, never wiped.
# This notification fires the FIRST time the player can actually afford a claim,
# so it never promises a claim the player can't yet make.

# === Determine this player's next claim cost ===
scoreboard players set #spark_cost ec.var 50
execute if score @s ec.spark_claims matches 0 run scoreboard players set #spark_cost ec.var 400
execute if score @s ec.spark_claims matches 1 run scoreboard players set #spark_cost ec.var 250
execute if score @s ec.spark_claims matches 2 run scoreboard players set #spark_cost ec.var 125
execute if score @s ec.spark_claims matches 3 run scoreboard players set #spark_cost ec.var 75

# Only fire once affordable \u2014 and only on the exact pull that crosses the line,
# so it doesn't spam every pull afterward (ec.spark_notified guards repeats).
scoreboard players operation #spark_check ec.var = @s ec.wish_spark
scoreboard players operation #spark_check ec.var -= #spark_cost ec.var
execute if score #spark_check ec.var matches ..-1 run return run scoreboard players set @s ec.spark_notified 0
execute if score @s ec.spark_notified matches 1.. run return 0
scoreboard players set @s ec.spark_notified 1

data modify storage evercraft:notify stage.c set value [{text:"\u2605\u2605\u2605 ",color:"gold"},{text:"Your Lucidity has Peaked!",color:"gold",bold:true},{text:" \u2605\u2605\u2605",color:"gold"}]
scoreboard players set #ndur ec.temp 50
function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"You've banked ",color:"gray"},{score:{name:"@s",objective:"ec.wish_spark"},color:"aqua"},{text:" lucidity! Spend ",color:"gray"},{score:{name:"#spark_cost",objective:"ec.var"},color:"gold"},{text:" at the Fountain on a Lucid Claim.",color:"gray"}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit

# === DEFER THE FULL-SCREEN PEAK TITLE (P3-3) ===
# The eligibility/notify logic above stays here (chat line + ec.spark_notified once-only
# guard), but the full-screen title/subtitle/firework would otherwise fire on the SAME
# tick as the reel reveal (reveal:36 calls this at tick 80), stacking two title cards on
# one moment (worse mid-10-pull). So instead of showing the title now, we set a pending
# flag; reel/cleanup shows it ONCE after the whole reel sequence finishes. The chat line
# above is fine inline \u2014 only the title collides.
scoreboard players set @s ec.spark_peak_show 1
