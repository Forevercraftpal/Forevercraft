# Lucid Claim — player chose an item via /trigger ec.spark set <1-9>
# Runs as @s = player
# Cost ramps: 1st=400, 2nd=250, 3rd=125, 4th=75, 5th+=50 (lucidity DEDUCTED, not wiped)
#
# deprecated 2026-05-29 — RETIRED, no longer scheduled. The canonical Lucid Claim is
# the GUI path (fountain menu → spark/gui/open → spark/gui/grant), which now owns this
# exact ramp logic. gacha/tick no longer dispatches to this file (the ec.spark trigger
# is zeroed there instead). Kept on disk for reference; do NOT re-wire — having two
# grant paths is the original bug this fix closes.

# Determine required cost from claim counter (ec.spark_claims = 0 for first claim)
scoreboard players set #spark_cost ec.var 50
execute if score @s ec.spark_claims matches 0 run scoreboard players set #spark_cost ec.var 400
execute if score @s ec.spark_claims matches 1 run scoreboard players set #spark_cost ec.var 250
execute if score @s ec.spark_claims matches 2 run scoreboard players set #spark_cost ec.var 125
execute if score @s ec.spark_claims matches 3 run scoreboard players set #spark_cost ec.var 75

# Validate selection BEFORE charging
execute unless score @s ec.spark matches 1..9 run return run tellraw @s [{"text":"★ ","color":"gray"},{"text":"Invalid choice! Use 1-9.","color":"red"}]

# Validate lucidity is sufficient (ec.wish_spark >= required cost)
scoreboard players operation #spark_check ec.var = @s ec.wish_spark
scoreboard players operation #spark_check ec.var -= #spark_cost ec.var
execute if score #spark_check ec.var matches ..-1 run return run tellraw @s [{"text":"★ ","color":"gray"},{"text":"Lucid Claim requires ","color":"red"},{"score":{"name":"#spark_cost","objective":"ec.var"},"color":"gold"},{"text":" lucidity (you have ","color":"red"},{"score":{"name":"@s","objective":"ec.wish_spark"},"color":"gold"},{"text":").","color":"red"}]

# Deduct lucidity cost
scoreboard players operation @s ec.wish_spark -= #spark_cost ec.var

# Grant chosen item
# Inv-full guard: drop at the player's feet rather than void on a full inventory.
execute store result score #inv_full ec.var run function evercraft:util/check_inv_full
execute if score @s ec.spark matches 1 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:artifacts/mythical/the_starless_night
execute if score @s ec.spark matches 1 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:artifacts/mythical/the_starless_night
execute if score @s ec.spark matches 2 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:artifacts/mythical/shooting_star
execute if score @s ec.spark matches 2 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:artifacts/mythical/shooting_star
execute if score @s ec.spark matches 3 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:artifacts/mythical/dreamcast_compass
execute if score @s ec.spark matches 3 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:artifacts/mythical/dreamcast_compass
execute if score @s ec.spark matches 4 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:artifacts/mythical/hero_helmet
execute if score @s ec.spark matches 4 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:artifacts/mythical/hero_helmet
execute if score @s ec.spark matches 5 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:artifacts/mythical/hero_chestplate
execute if score @s ec.spark matches 5 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:artifacts/mythical/hero_chestplate
execute if score @s ec.spark matches 6 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:artifacts/mythical/hero_leggings
execute if score @s ec.spark matches 6 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:artifacts/mythical/hero_leggings
execute if score @s ec.spark matches 7 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:artifacts/mythical/hero_boots
execute if score @s ec.spark matches 7 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:artifacts/mythical/hero_boots
execute if score @s ec.spark matches 8 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:artifacts/mythical/robot_dancers_sword
execute if score @s ec.spark matches 8 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:artifacts/mythical/robot_dancers_sword
execute if score @s ec.spark matches 9 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:artifacts/mythical/droid_dancers_sword
execute if score @s ec.spark matches 9 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:artifacts/mythical/droid_dancers_sword

# Bump claim counter for next-time ramp
scoreboard players add @s ec.spark_claims 1

# Celebration
tellraw @a [{"text":"★★★ ","color":"gold"},{"selector":"@s","color":"gold"},{"text":" claimed their ","color":"gray"},{"text":"LUCID CLAIM","color":"gold","bold":true},{"text":" from the Fountain!","color":"gray"}]
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 1 0.8
execute if score @s ec.fx_vis matches 1.. run particle totem_of_undying ~ ~1.5 ~ 1 1.5 1 0.5 100 force @s
# (AB-1 sticky-times sweep 2026-06-10: explicit stamp — `title times` is sticky per player and this sequence set none, so it inherited whatever ran last.)
title @s times 10 60 20
title @s subtitle {"text":"Lucid Dream Fulfilled!","color":"gold"}
title @s title {"text":"★ CLAIMED ★","color":"gold"}

# Reset trigger
scoreboard players set @s ec.spark 0
scoreboard players enable @s ec.spark
