# Apply Dreamdust Crystal — Permanent +2.5 luck modifier
# Only called if player has NOT already used one

# Mark as used
tag @s add ec.dreamdust_used

# Apply permanent luck modifier
attribute @s luck modifier add evercraft:dreamdust_crystal 2.5 add_value

# Celebration effects
execute if score @s ec.fx_vis matches 1.. run particle minecraft:totem_of_undying ~ ~1.5 ~ 0.5 1 0.5 0.5 50 force @s
execute if score @s ec.fx_vis matches 1.. run particle minecraft:end_rod ~ ~2 ~ 0.3 0.5 0.3 0.05 30 force @s
execute if score @s ec.fx_vis matches 1.. run particle minecraft:witch ~ ~1 ~ 0.3 0.5 0.3 0.02 20 force @s
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 1 1.2
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 1 0.8

# Title
# (AB-1 sticky-times sweep 2026-06-10: explicit stamp — `title times` is sticky per player and this sequence set none, so it inherited whatever ran last.)
title @s times 10 60 20
title @s subtitle {"text":"Permanent +2.5 Dream Rate","color":"aqua"}
title @s title {"text":"Dreamdust Crystal","color":"#E0B0FF"}

# Action-bar notification
data modify storage evercraft:notify stage.c set value [{text:"\u2726\u2726\u2726 ",color:"#E0B0FF"},{text:"Dreamdust Crystal consumed! ",color:"light_purple"},{text:"Permanent +2.5 Dream Rate!",color:"aqua",bold:true},{text:" \u2726\u2726\u2726",color:"#E0B0FF"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
