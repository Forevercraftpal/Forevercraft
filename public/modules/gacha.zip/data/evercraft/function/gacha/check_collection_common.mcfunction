# Collection-completion milestone — Common Artifact Collection (27 items)
# Runs as @s = player. Only invoked from check_achievements while ec.coll_common<=0
# (once-only gate), so this 27-advancement scan is never a per-pull cost after the
# milestone is earned. Mirrors the canonical list in
# codex/hub/artifacts/count/count_common.mcfunction — keep the two in sync.

# Count owned Common artifacts into #coll_cnt ec.temp
scoreboard players set #coll_cnt ec.temp 0
execute if entity @s[advancements={evercraft:artifacts/collected/bone_slingshot=true}] run scoreboard players add #coll_cnt ec.temp 1
execute if entity @s[advancements={evercraft:artifacts/collected/boneclub=true}] run scoreboard players add #coll_cnt ec.temp 1
execute if entity @s[advancements={evercraft:artifacts/collected/broadsword=true}] run scoreboard players add #coll_cnt ec.temp 1
execute if entity @s[advancements={evercraft:artifacts/collected/deku_shield=true}] run scoreboard players add #coll_cnt ec.temp 1
execute if entity @s[advancements={evercraft:artifacts/collected/highland_mace=true}] run scoreboard players add #coll_cnt ec.temp 1
execute if entity @s[advancements={evercraft:artifacts/collected/hunting_bow=true}] run scoreboard players add #coll_cnt ec.temp 1
execute if entity @s[advancements={evercraft:artifacts/collected/norroen_sword=true}] run scoreboard players add #coll_cnt ec.temp 1
execute if entity @s[advancements={evercraft:artifacts/collected/plunger=true}] run scoreboard players add #coll_cnt ec.temp 1
execute if entity @s[advancements={evercraft:artifacts/collected/slingshot=true}] run scoreboard players add #coll_cnt ec.temp 1
execute if entity @s[advancements={evercraft:artifacts/collected/vex_iron_sword=true}] run scoreboard players add #coll_cnt ec.temp 1
execute if entity @s[advancements={evercraft:artifacts/collected/common_thief_helmet=true}] run scoreboard players add #coll_cnt ec.temp 1
execute if entity @s[advancements={evercraft:artifacts/collected/common_fox_chestplate=true}] run scoreboard players add #coll_cnt ec.temp 1
execute if entity @s[advancements={evercraft:artifacts/collected/common_ocelot_leggings=true}] run scoreboard players add #coll_cnt ec.temp 1
execute if entity @s[advancements={evercraft:artifacts/collected/common_wolf_boots=true}] run scoreboard players add #coll_cnt ec.temp 1
execute if entity @s[advancements={evercraft:artifacts/collected/common_renegade_chestplate=true}] run scoreboard players add #coll_cnt ec.temp 1
execute if entity @s[advancements={evercraft:artifacts/collected/pebble_of_dreams=true}] run scoreboard players add #coll_cnt ec.temp 1
execute if entity @s[advancements={evercraft:artifacts/collected/travelers_charm=true}] run scoreboard players add #coll_cnt ec.temp 1
execute if entity @s[advancements={evercraft:artifacts/collected/worn_compass=true}] run scoreboard players add #coll_cnt ec.temp 1
execute if entity @s[advancements={evercraft:artifacts/collected/common_hammer=true}] run scoreboard players add #coll_cnt ec.temp 1
execute if entity @s[advancements={evercraft:artifacts/collected/common_ladle=true}] run scoreboard players add #coll_cnt ec.temp 1
execute if entity @s[advancements={evercraft:artifacts/collected/common_scythe=true}] run scoreboard players add #coll_cnt ec.temp 1
execute if entity @s[advancements={evercraft:artifacts/collected/common_highland_axe=true}] run scoreboard players add #coll_cnt ec.temp 1
execute if entity @s[advancements={evercraft:artifacts/collected/healer_poultice=true}] run scoreboard players add #coll_cnt ec.temp 1
execute if entity @s[advancements={evercraft:artifacts/collected/mauler=true}] run scoreboard players add #coll_cnt ec.temp 1
execute if entity @s[advancements={evercraft:artifacts/collected/healer_bandages=true}] run scoreboard players add #coll_cnt ec.temp 1
execute if entity @s[advancements={evercraft:artifacts/collected/rabbits_dreaming_foot=true}] run scoreboard players add #coll_cnt ec.temp 1
execute if entity @s[advancements={evercraft:artifacts/collected/common_wooden_fishing_rod=true}] run scoreboard players add #coll_cnt ec.temp 1

# Not yet complete (need all 27) — leave the gate open and return
execute if score #coll_cnt ec.temp matches ..26 run return 0

# === MILESTONE COMPLETE — award once, then close the gate forever ===
scoreboard players set @s ec.coll_common 1
function evercraft:gacha/award_collection_common
