# Animated 10-pull — deduct all coins upfront, animate each pull sequentially
# Runs as @s = player, at @s

# Per-pull cost (5 normally, 3 during Convergence)
scoreboard players set #pull_unit ec.temp 5
execute if score #gacha_convergence ec.var matches 1 run scoreboard players set #pull_unit ec.temp 3

# Calculate how many of the 10 pulls are covered by banked bonus (cap at 10).
# Pool = Coin-of-Lucidity bonus (ec.wish_bonus) + daily free wishes (ec.free_pulls),
# both spent here so the generous sources apply to 10-pulls too. Tracked separately
# so each source is decremented by exactly the amount it contributed.
scoreboard players set #bonus_used ec.temp 0
scoreboard players set #daily_used ec.temp 0
execute if score @s ec.wish_bonus matches 1.. run scoreboard players operation #bonus_used ec.temp = @s ec.wish_bonus
execute if score #bonus_used ec.temp matches 11.. run scoreboard players set #bonus_used ec.temp 10
# Remaining free slots after bonus → fill from daily free wishes
scoreboard players set #free_slots ec.temp 10
scoreboard players operation #free_slots ec.temp -= #bonus_used ec.temp
execute if score @s ec.free_pulls matches 1.. run scoreboard players operation #daily_used ec.temp = @s ec.free_pulls
execute if score #daily_used ec.temp > #free_slots ec.temp run scoreboard players operation #daily_used ec.temp = #free_slots ec.temp
# Total free pulls (for messaging + paid-count math)
scoreboard players operation #free_pulls ec.temp = #bonus_used ec.temp
scoreboard players operation #free_pulls ec.temp += #daily_used ec.temp

# Paid pulls = 10 - free pulls
scoreboard players set #paid_pulls ec.temp 10
scoreboard players operation #paid_pulls ec.temp -= #free_pulls ec.temp

# Total coin cost = paid_pulls * per-pull cost
scoreboard players operation #pull10_cost ec.temp = #paid_pulls ec.temp
scoreboard players operation #pull10_cost ec.temp *= #pull_unit ec.temp

# Check balance
execute unless score @s ec.coins >= #pull10_cost ec.temp run data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"#E0B0FF"},{text:"Not enough Forever Coins! ",color:"red"},{text:"Need ",color:"gray"},{score:{name:"#pull10_cost",objective:"ec.temp"},color:"gold"},{text:", have ",color:"gray"},{score:{name:"@s",objective:"ec.coins"},color:"gold"},{text:" ✦",color:"#E0B0FF"}]
execute unless score @s ec.coins >= #pull10_cost ec.temp run scoreboard players set #ndur ec.temp 45
execute unless score @s ec.coins >= #pull10_cost ec.temp run return run function evercraft:util/notify/emit

# Deduct coins and consume banked pulls (each source by its own contribution)
scoreboard players operation @s ec.coins -= #pull10_cost ec.temp
scoreboard players operation @s ec.wish_bonus -= #bonus_used ec.temp
scoreboard players operation @s ec.free_pulls -= #daily_used ec.temp
execute if score #bonus_used ec.temp matches 1.. run data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"Used ",color:"yellow"},{score:{name:"#bonus_used",objective:"ec.temp"},color:"gold"},{text:" bonus pull(s)! ",color:"yellow"},{text:"(",color:"gray"},{score:{name:"@s",objective:"ec.wish_bonus"},color:"gold"},{text:" remaining)",color:"gray"},{text:" ✦",color:"gold"}]
execute if score #bonus_used ec.temp matches 1.. run scoreboard players set #ndur ec.temp 45
execute if score #bonus_used ec.temp matches 1.. run function evercraft:util/notify/emit
execute if score #daily_used ec.temp matches 1.. run data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"#E0B0FF"},{text:"The fountain's gift covered ",color:"#E0B0FF"},{score:{name:"#daily_used",objective:"ec.temp"},color:"#E0B0FF"},{text:" wish(es)! ",color:"#E0B0FF"},{text:"(",color:"gray"},{score:{name:"@s",objective:"ec.free_pulls"},color:"#E0B0FF"},{text:" free wishes waiting)",color:"gray"},{text:" ✦",color:"#E0B0FF"}]
execute if score #daily_used ec.temp matches 1.. run scoreboard players set #ndur ec.temp 45
execute if score #daily_used ec.temp matches 1.. run function evercraft:util/notify/emit

# Set up multi-pull tracking (9 remaining after first)
scoreboard players set @s ec.reel_count 9
scoreboard players set @s ec.reel_pull 1

# First pull: increment pity + roll
scoreboard players add @s ec.wish_pity 1
scoreboard players add @s ec.wish_soft 1
scoreboard players add @s ec.wish_spark 1
scoreboard players add @s ec.wish_total 1
function evercraft:gacha/pull/roll
scoreboard players operation @s ec.reel_tier = #gacha_tier ec.temp

# Initialize reel tick
scoreboard players set @s ec.reel_tick 0

# Kill existing fountain menu entities
kill @e[tag=ec.FountainElement,distance=..20]

# Spawn reel in front of player (player-relative)
execute at @s rotated ~ 0 run function evercraft:gacha/reel/spawn

# Show pull counter
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"#E0B0FF"},{text:"Pull 1/10",color:"gold",bold:true},{text:" ✦",color:"#E0B0FF"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit

# Play start sound
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.beacon.activate master @s ~ ~ ~ 0.7 1.4
