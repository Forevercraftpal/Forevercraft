# Grant Mythical pull reward (2% base rate)
# Runs as @s = player

# Skip roll if pre-rolled by reel animation
execute if score #reward_roll ec.temp matches ..0 store result score #reward_roll ec.temp run random value 1..6

# 1-2: Exclusive Gacha Artifact (9 unique mythicals — random)
execute if score #reward_roll ec.temp matches 1..2 run function evercraft:gacha/pull/grant_mythical_artifact

# 3: Exclusive Gacha Companion (Dreamstag / Starweaver / Somnia)
execute if score #reward_roll ec.temp matches 3 run function evercraft:gacha/pull/grant_mythical_companion

# 4: Dreamdust Crystal (permanent +2.5 DR, once per player)
execute if score #reward_roll ec.temp matches 4 run give @s minecraft:stick[item_model="minecraft:amethyst_cluster",custom_name={"text":"Dreamdust Crystal","color":"gold","italic":false},custom_data={dreamdust_crystal:true},lore=[{"text":"Mythical Item","color":"gold","italic":false},"",{"text":"Pure crystallized fortune, distilled from a","color":"gray","italic":true},{"text":"thousand dreams that dared to come true.","color":"gray","italic":true},"",{"text":"Right-click to consume:","color":"white","italic":false},{"text":"Permanently gain +2.5 Dream Rate","color":"aqua","italic":false},{"text":"(One per player)","color":"dark_gray","italic":false},"",{"text":"\"What you dream becomes what you are.\"","color":"dark_gray","italic":true}],enchantment_glint_override=true,consumable={consume_seconds:0,sound:"intentionally_empty",has_consume_particles:false}] 1
execute if score #reward_roll ec.temp matches 4 run data modify storage evercraft:notify stage.c set value [{text:"✦✦✦ ",color:"gold"},{text:"MYTHICAL: ",color:"gold",bold:true},{text:"Dreamdust Crystal!",color:"yellow"},{text:" ✦✦✦",color:"gold"}]
execute if score #reward_roll ec.temp matches 4 run scoreboard players set #ndur ec.temp 45
execute if score #reward_roll ec.temp matches 4 run function evercraft:util/notify/emit

# 5: Wishing Star (choose ANY artifact)
execute if score #reward_roll ec.temp matches 5 run give @s minecraft:nether_star[custom_name={"text":"Dreamy Star","color":"gold","italic":false},custom_data={wishing_star:true},lore=[{"text":"Mythical Item","color":"gold","italic":false},"",{"text":"A star that fell not from the sky, but from","color":"gray","italic":true},{"text":"the Fountain's deepest, most desperate wish.","color":"gray","italic":true},"",{"text":"Right-click to use:","color":"white","italic":false},{"text":"Choose ANY artifact from the entire pack","color":"aqua","italic":false},"",{"text":"\"The rarest gift is the power to choose.\"","color":"dark_gray","italic":true}],enchantment_glint_override=true,consumable={consume_seconds:0,sound:"intentionally_empty",has_consume_particles:false}] 1
execute if score #reward_roll ec.temp matches 5 run data modify storage evercraft:notify stage.c set value [{text:"✦✦✦ ",color:"gold"},{text:"MYTHICAL: ",color:"gold",bold:true},{text:"Dreamy Star!",color:"yellow"},{text:" ✦✦✦",color:"gold"}]
execute if score #reward_roll ec.temp matches 5 run scoreboard players set #ndur ec.temp 45
execute if score #reward_roll ec.temp matches 5 run function evercraft:util/notify/emit

# 6: Pristine Antique — open a Pristine quality window (eff 200), then give a rare-band blueprint. The
# got_blueprint->quality_sweep pipeline stamps it Pristine (dur x2 + amp +1) and rolls a material infusion.
# (Quality ladder by pull tier: Ornate=Poor, Exquisite=Standard, Mythical=Pristine — Pristine is mythical-only.)
execute if score #reward_roll ec.temp matches 6 store result score #inv_full ec.var run function evercraft:util/check_inv_full
execute if score #reward_roll ec.temp matches 6 run scoreboard players set @s ec.antq_src 200
execute if score #reward_roll ec.temp matches 6 run scoreboard players set @s ec.antq_src_t 300
execute if score #reward_roll ec.temp matches 6 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:decor/crate/pool/bp/rare
execute if score #reward_roll ec.temp matches 6 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:decor/crate/pool/bp/rare
execute if score #reward_roll ec.temp matches 6 run data modify storage evercraft:notify stage.c set value [{text:"✦✦✦ ",color:"gold"},{text:"MYTHICAL: ",color:"gold",bold:true},{text:"Pristine Antique!",color:"yellow"},{text:" ✦✦✦",color:"gold"}]
execute if score #reward_roll ec.temp matches 6 run scoreboard players set #ndur ec.temp 45
execute if score #reward_roll ec.temp matches 6 run function evercraft:util/notify/emit

# "Dreamy Star" achievement — first mythical pull
advancement grant @s only evercraft:gacha/dreamy_star

# Mythical pull celebration
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 1 0.8
# "something ancient stirs" — arcane mythical-pull cue (was ender_dragon.growl; gacha is dream-themed, not a dragon weapon)
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.beacon.power_select master @s ~ ~ ~ 0.6 0.6
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.amethyst_block.resonate master @s ~ ~ ~ 0.5 0.7
execute if score @s ec.fx_vis matches 1.. run particle totem_of_undying ~ ~1.5 ~ 1 1.5 1 0.5 100 force @s
execute if score @s ec.fx_vis matches 1.. run particle end_rod ~ ~2 ~ 0.5 1 0.5 0.05 50 force @s
execute if score @s ec.fx_vis matches 1.. run particle enchant ~ ~1 ~ 1 1 1 2 50 force @s

# Broadcast to OTHER players (names the actor → §5b). The actor is tagged out: they already get
# the personal "MYTHICAL: <item>!" action-bar line + the screen title, so without this they saw
# their own pull announced twice on the bar (fixed 2026-06-02).
tag @s add ec.brag_self
execute as @s run function evercraft:util/notify/whoami
data modify storage evercraft:notify stage.c set value [{text:"✦✦✦ ",color:"gold"},{text:"",color:"yellow"},{text:" pulled a ",color:"gray"},{text:"MYTHICAL",color:"gold",bold:true},{text:" from the Fountain of Eternal Dreams!",color:"gray"},{text:" ✦✦✦",color:"gold"}]
data modify storage evercraft:notify stage.c[1].text set from storage evercraft:notify named.who
scoreboard players set #ndur ec.temp 50
execute as @s run execute as @a[tag=!ec.brag_self] run scoreboard players set #nttl ec.temp 600
execute as @s run execute as @a[tag=!ec.brag_self] run function evercraft:util/notify/emit_keep
tag @s remove ec.brag_self

# Title
# (AB-1 sticky-times sweep 2026-06-10: explicit stamp — `title times` is sticky per player and this sequence set none, so it inherited whatever ran last.)
title @s times 10 60 20
title @s subtitle {"text":"from the Fountain of Eternal Dreams!","color":"yellow"}
title @s title {"text":"✦ MYTHICAL ✦","color":"gold"}
