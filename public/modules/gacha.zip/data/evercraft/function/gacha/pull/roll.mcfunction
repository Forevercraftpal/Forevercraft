# Roll for gacha tier using RNG + pity system
# Sets #gacha_tier ec.temp: 1=common, 2=uncommon, 3=rare, 4=ornate, 5=exquisite, 6=mythical
# Runs as @s = player

# === HARD PITY CHECK (90 pulls without Ornate+) ===
# Pity gates stretched 3x (2026-06-16, "1/3 as good") so the safety nets fire a third as often.
execute if score @s ec.wish_soft matches 90.. run return run function evercraft:gacha/pull/determine_tier_hard_pity

# === 30-PULL PITY CHECK (30 pulls without Rare+) ===
execute if score @s ec.wish_pity matches 30.. run return run function evercraft:gacha/pull/determine_tier_10_pity

# === STANDARD ROLL ===
# Generate random number 1-1000
execute store result score #gacha_roll ec.temp run random value 1..1000

# === DREAM RATE BONUS ===
# Luck attribute = Dream Rate (Crumb of Dreams +1, Dreamdust Crystal +2.5)
# Negligible boost: +1 DR per 5 luck → DR 50 = -10 roll (1% boost)
execute store result score #dr_bonus ec.temp run attribute @s luck get 1
execute if score #dr_bonus ec.temp matches 1.. run scoreboard players operation #dr_bonus ec.temp /= #5 ec.const
execute if score #dr_bonus ec.temp matches 1.. run scoreboard players operation #gacha_roll ec.temp -= #dr_bonus ec.temp
execute if score #gacha_roll ec.temp matches ..0 run scoreboard players set #gacha_roll ec.temp 1

# Check if soft pity active (60+ pulls without Ornate+) — boosted rates
execute if score @s ec.wish_soft matches 60.. run return run function evercraft:gacha/pull/determine_tier_soft

# === BASE RATES (out of 1000) — favorable odds nerfed to ~1/3 (2026-06-16) ===
# Mythical: 0.1% (1), Exquisite: 1.6% (2-17), Ornate: 2.7% (18-44)
# Rare: 5.0% (45-94), Uncommon: 25% (95-344), Common: 65.6% (345-1000)
# Prior Rare+ band was 28.2%; now 9.4% (1/3). Common absorbs the slack; Uncommon unchanged.

# During Convergence: Mythical boosted to 0.2% (1-2)
execute if score #gacha_convergence ec.var matches 1 if score #gacha_roll ec.temp matches 1..2 run return run scoreboard players set #gacha_tier ec.temp 6

execute if score #gacha_roll ec.temp matches 1 run return run scoreboard players set #gacha_tier ec.temp 6
execute if score #gacha_roll ec.temp matches 2..17 run return run scoreboard players set #gacha_tier ec.temp 5
execute if score #gacha_roll ec.temp matches 18..44 run return run scoreboard players set #gacha_tier ec.temp 4
execute if score #gacha_roll ec.temp matches 45..94 run return run scoreboard players set #gacha_tier ec.temp 3
execute if score #gacha_roll ec.temp matches 95..344 run return run scoreboard players set #gacha_tier ec.temp 2
scoreboard players set #gacha_tier ec.temp 1
