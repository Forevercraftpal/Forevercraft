# Grant a random exclusive gacha mythical artifact (9 total)
# Runs as @s = player

execute store result score #artifact_roll ec.temp run random value 1..9

# Inv-full guard: drop at the player's feet rather than void on a full inventory.
execute store result score #inv_full ec.var run function evercraft:util/check_inv_full
execute if score #artifact_roll ec.temp matches 1 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:artifacts/mythical/the_starless_night
execute if score #artifact_roll ec.temp matches 1 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:artifacts/mythical/the_starless_night
execute if score #artifact_roll ec.temp matches 1 run data modify storage evercraft:notify stage.c set value [{text:"✦✦✦ ",color:"gold"},{text:"MYTHICAL: ",color:"gold",bold:true},{text:"The Starless Night",color:"yellow",bold:true},{text:" ✦✦✦",color:"gold"}]
execute if score #artifact_roll ec.temp matches 1 run scoreboard players set #ndur ec.temp 45
execute if score #artifact_roll ec.temp matches 1 run function evercraft:util/notify/emit

execute if score #artifact_roll ec.temp matches 2 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:artifacts/mythical/shooting_star
execute if score #artifact_roll ec.temp matches 2 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:artifacts/mythical/shooting_star
execute if score #artifact_roll ec.temp matches 2 run data modify storage evercraft:notify stage.c set value [{text:"✦✦✦ ",color:"gold"},{text:"MYTHICAL: ",color:"gold",bold:true},{text:"Shooting Star",color:"yellow",bold:true},{text:" ✦✦✦",color:"gold"}]
execute if score #artifact_roll ec.temp matches 2 run scoreboard players set #ndur ec.temp 45
execute if score #artifact_roll ec.temp matches 2 run function evercraft:util/notify/emit

execute if score #artifact_roll ec.temp matches 3 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:artifacts/mythical/dreamcast_compass
execute if score #artifact_roll ec.temp matches 3 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:artifacts/mythical/dreamcast_compass
execute if score #artifact_roll ec.temp matches 3 run data modify storage evercraft:notify stage.c set value [{text:"✦✦✦ ",color:"gold"},{text:"MYTHICAL: ",color:"gold",bold:true},{text:"Dreamcast Compass",color:"yellow",bold:true},{text:" ✦✦✦",color:"gold"}]
execute if score #artifact_roll ec.temp matches 3 run scoreboard players set #ndur ec.temp 45
execute if score #artifact_roll ec.temp matches 3 run function evercraft:util/notify/emit

execute if score #artifact_roll ec.temp matches 4 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:artifacts/mythical/hero_helmet
execute if score #artifact_roll ec.temp matches 4 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:artifacts/mythical/hero_helmet
execute if score #artifact_roll ec.temp matches 4 run data modify storage evercraft:notify stage.c set value [{text:"✦✦✦ ",color:"gold"},{text:"MYTHICAL: ",color:"gold",bold:true},{text:"Hero's Helmet",color:"yellow",bold:true},{text:" ✦✦✦",color:"gold"}]
execute if score #artifact_roll ec.temp matches 4 run scoreboard players set #ndur ec.temp 45
execute if score #artifact_roll ec.temp matches 4 run function evercraft:util/notify/emit

execute if score #artifact_roll ec.temp matches 5 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:artifacts/mythical/hero_chestplate
execute if score #artifact_roll ec.temp matches 5 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:artifacts/mythical/hero_chestplate
execute if score #artifact_roll ec.temp matches 5 run data modify storage evercraft:notify stage.c set value [{text:"✦✦✦ ",color:"gold"},{text:"MYTHICAL: ",color:"gold",bold:true},{text:"Hero's Chestplate",color:"yellow",bold:true},{text:" ✦✦✦",color:"gold"}]
execute if score #artifact_roll ec.temp matches 5 run scoreboard players set #ndur ec.temp 45
execute if score #artifact_roll ec.temp matches 5 run function evercraft:util/notify/emit

execute if score #artifact_roll ec.temp matches 6 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:artifacts/mythical/hero_leggings
execute if score #artifact_roll ec.temp matches 6 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:artifacts/mythical/hero_leggings
execute if score #artifact_roll ec.temp matches 6 run data modify storage evercraft:notify stage.c set value [{text:"✦✦✦ ",color:"gold"},{text:"MYTHICAL: ",color:"gold",bold:true},{text:"Hero's Leggings",color:"yellow",bold:true},{text:" ✦✦✦",color:"gold"}]
execute if score #artifact_roll ec.temp matches 6 run scoreboard players set #ndur ec.temp 45
execute if score #artifact_roll ec.temp matches 6 run function evercraft:util/notify/emit

execute if score #artifact_roll ec.temp matches 7 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:artifacts/mythical/hero_boots
execute if score #artifact_roll ec.temp matches 7 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:artifacts/mythical/hero_boots
execute if score #artifact_roll ec.temp matches 7 run data modify storage evercraft:notify stage.c set value [{text:"✦✦✦ ",color:"gold"},{text:"MYTHICAL: ",color:"gold",bold:true},{text:"Hero's Boots",color:"yellow",bold:true},{text:" ✦✦✦",color:"gold"}]
execute if score #artifact_roll ec.temp matches 7 run scoreboard players set #ndur ec.temp 45
execute if score #artifact_roll ec.temp matches 7 run function evercraft:util/notify/emit

execute if score #artifact_roll ec.temp matches 8 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:artifacts/mythical/robot_dancers_sword
execute if score #artifact_roll ec.temp matches 8 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:artifacts/mythical/robot_dancers_sword
execute if score #artifact_roll ec.temp matches 8 run data modify storage evercraft:notify stage.c set value [{text:"✦✦✦ ",color:"gold"},{text:"MYTHICAL: ",color:"gold",bold:true},{text:"Robot Dancer's Sword",color:"yellow",bold:true},{text:" ✦✦✦",color:"gold"}]
execute if score #artifact_roll ec.temp matches 8 run scoreboard players set #ndur ec.temp 45
execute if score #artifact_roll ec.temp matches 8 run function evercraft:util/notify/emit

execute if score #artifact_roll ec.temp matches 9 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:artifacts/mythical/droid_dancers_sword
execute if score #artifact_roll ec.temp matches 9 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:artifacts/mythical/droid_dancers_sword
execute if score #artifact_roll ec.temp matches 9 run data modify storage evercraft:notify stage.c set value [{text:"✦✦✦ ",color:"gold"},{text:"MYTHICAL: ",color:"gold",bold:true},{text:"Droid Dancer's Sword",color:"yellow",bold:true},{text:" ✦✦✦",color:"gold"}]
execute if score #artifact_roll ec.temp matches 9 run scoreboard players set #ndur ec.temp 45
execute if score #artifact_roll ec.temp matches 9 run function evercraft:util/notify/emit
