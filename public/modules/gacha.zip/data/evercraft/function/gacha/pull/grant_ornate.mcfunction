# Grant Ornate pull reward (8% base rate)
# Runs as @s = player

# Skip roll if pre-rolled by reel animation
execute if score #reward_roll ec.temp matches ..0 store result score #reward_roll ec.temp run random value 1..8

# 1: Ornate Artifact Crate (place to open)
execute if score #reward_roll ec.temp matches 1 run give @s minecraft:barrel[container_loot={loot_table:"evercraft:crates/artifact_ornate"},custom_name={"text":"Ornate Artifact Crate","color":"light_purple","italic":false},lore=[{"text":"Ornamental runes line the lid, sealing","color":"gray","italic":true},{"text":"a treasure meant for worthy hands.","color":"gray","italic":true},"",{"text":"Place to reveal your artifact.","color":"dark_gray","italic":false}],custom_data={artc_rarity:"ornate"},enchantment_glint_override=true] 1
execute if score #reward_roll ec.temp matches 1 run data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"#AA00AA"},{text:"Ornate: ",color:"dark_purple",bold:true},{text:"Ornate Artifact Crate!",color:"light_purple"},{text:" ✦",color:"#AA00AA"}]
execute if score #reward_roll ec.temp matches 1 run scoreboard players set #ndur ec.temp 45
execute if score #reward_roll ec.temp matches 1 run function evercraft:util/notify/emit

# 2: Seed of Forgetting (reset one Advantage Tree)
execute if score #reward_roll ec.temp matches 2 run give @s minecraft:torchflower_seeds[custom_name={"text":"Seed of Forgetting","color":"light_purple","italic":false},custom_data={seed_of_forgetting:true},lore=[{"text":"Ornate Item","color":"dark_purple","italic":false},"",{"text":"Grown in the soil between waking and sleep,","color":"gray","italic":true},{"text":"it unravels what was once learned.","color":"gray","italic":true},"",{"text":"Right-click to use:","color":"white","italic":false},{"text":"Reset one Advantage Tree for a full respec","color":"light_purple","italic":false},"",{"text":"\"To forget is to make room for becoming.\"","color":"dark_gray","italic":true}],enchantment_glint_override=true] 1
execute if score #reward_roll ec.temp matches 2 run data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"#AA00AA"},{text:"Ornate: ",color:"dark_purple",bold:true},{text:"Seed of Forgetting",color:"light_purple"},{text:" ✦",color:"#AA00AA"}]
execute if score #reward_roll ec.temp matches 2 run scoreboard players set #ndur ec.temp 45
execute if score #reward_roll ec.temp matches 2 run function evercraft:util/notify/emit

# 3: Exclusive Particle (random unlock from cosmetic pool)
execute if score #reward_roll ec.temp matches 3 store result score @s adv.temp run random value 1..19
execute if score #reward_roll ec.temp matches 3 run function evercraft:advantage/cosmetics/crate_unlock_particle

# 4: Exclusive Title (random unlock from cosmetic pool)
execute if score #reward_roll ec.temp matches 4 store result score @s adv.temp run random value 19..36
execute if score #reward_roll ec.temp matches 4 run function evercraft:advantage/cosmetics/crate_unlock_title

# 5: Ornate Companion Crate (place to open)
execute if score #reward_roll ec.temp matches 5 run give @s minecraft:barrel[container_loot={loot_table:"evercraft:crates/companion_ornate"},custom_name={"text":"Ornate Companion Crate","color":"light_purple","italic":false},lore=[{"text":"A loyal soul waits within, bound by","color":"gray","italic":true},{"text":"ancient craft to serve a dreamer's will.","color":"gray","italic":true},"",{"text":"Place to reveal your new companion.","color":"dark_gray","italic":false}],custom_data={pc_rarity:"ornate"},enchantment_glint_override=true] 1
execute if score #reward_roll ec.temp matches 5 run data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"#AA00AA"},{text:"Ornate: ",color:"dark_purple",bold:true},{text:"Ornate Companion Crate!",color:"light_purple"},{text:" ✦",color:"#AA00AA"}]
execute if score #reward_roll ec.temp matches 5 run scoreboard players set #ndur ec.temp 45
execute if score #reward_roll ec.temp matches 5 run function evercraft:util/notify/emit

# Inv-full guard for the item rewards below (drop at feet rather than void on a full inventory).
execute store result score #inv_full ec.var run function evercraft:util/check_inv_full

# 6: Ornate Furnishings Crate item (place to open — self-mints blueprints + antiques)
execute if score #reward_roll ec.temp matches 6 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:decor/crate_item/ornate
execute if score #reward_roll ec.temp matches 6 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:decor/crate_item/ornate
execute if score #reward_roll ec.temp matches 6 run data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"#AA00AA"},{text:"Ornate: ",color:"dark_purple",bold:true},{text:"Ornate Furnishings Crate!",color:"light_purple"},{text:" ✦",color:"#AA00AA"}]
execute if score #reward_roll ec.temp matches 6 run scoreboard players set #ndur ec.temp 45
execute if score #reward_roll ec.temp matches 6 run function evercraft:util/notify/emit

# 7: Ornate Accessory Crate item (place to open — reg set)
execute if score #reward_roll ec.temp matches 7 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:crates/items/accessory_reg_ornate
execute if score #reward_roll ec.temp matches 7 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:crates/items/accessory_reg_ornate
execute if score #reward_roll ec.temp matches 7 run data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"#AA00AA"},{text:"Ornate: ",color:"dark_purple",bold:true},{text:"Ornate Accessory Crate!",color:"light_purple"},{text:" ✦",color:"#AA00AA"}]
execute if score #reward_roll ec.temp matches 7 run scoreboard players set #ndur ec.temp 45
execute if score #reward_roll ec.temp matches 7 run function evercraft:util/notify/emit

# 8: Poor Antique — open a Poor quality window (eff 75), then give a rare-band blueprint. The
# got_blueprint->quality_sweep pipeline stamps it Poor (~75% effectiveness). (Quality ladder by pull tier:
# Ornate=Poor, Exquisite=Standard, Mythical=Pristine.) Mirrors decor/crate_anim finish (antq_src / 300t).
execute if score #reward_roll ec.temp matches 8 run scoreboard players set @s ec.antq_src 75
execute if score #reward_roll ec.temp matches 8 run scoreboard players set @s ec.antq_src_t 300
execute if score #reward_roll ec.temp matches 8 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:decor/crate/pool/bp/rare
execute if score #reward_roll ec.temp matches 8 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:decor/crate/pool/bp/rare
execute if score #reward_roll ec.temp matches 8 run data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"#AA00AA"},{text:"Ornate: ",color:"dark_purple",bold:true},{text:"Poor Antique!",color:"light_purple"},{text:" ✦",color:"#AA00AA"}]
execute if score #reward_roll ec.temp matches 8 run scoreboard players set #ndur ec.temp 45
execute if score #reward_roll ec.temp matches 8 run function evercraft:util/notify/emit

execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.player.levelup master @s ~ ~ ~ 1 0.8
execute if score @s ec.fx_vis matches 1.. run particle totem_of_undying ~ ~1.5 ~ 0.5 1 0.5 0.3 30 force @s
