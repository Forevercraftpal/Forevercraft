# Hard pity — guaranteed Exquisite or better at 90 pulls (gate stretched 30->90 on 2026-06-16;
# the floor distribution is unchanged — the "1/3" nerf comes from the rarer gate).
# Roll 1-1000: Mythical 2% (1-20), Exquisite 98% (21-1000)
execute store result score #gacha_roll ec.temp run random value 1..1000
execute if score #gacha_roll ec.temp matches 1..20 run return run scoreboard players set #gacha_tier ec.temp 6
scoreboard players set #gacha_tier ec.temp 5
