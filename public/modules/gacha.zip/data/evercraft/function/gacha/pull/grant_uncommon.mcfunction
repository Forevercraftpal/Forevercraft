# Grant Uncommon pull reward (25% base rate)
# Runs as @s = player

# Skip roll if pre-rolled by reel animation
execute if score #reward_roll ec.temp matches ..0 store result score #reward_roll ec.temp run random value 1..8

# 1: Tier-matched Awakening Stone (from weapon mastery loot table)
# Inv-full guard: drop at the player's feet rather than void on a full inventory.
execute store result score #inv_full ec.var run function evercraft:util/check_inv_full
execute if score #reward_roll ec.temp matches 1 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:weapon_mastery/stones/uncommon_stone
execute if score #reward_roll ec.temp matches 1 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:weapon_mastery/stones/uncommon_stone
execute if score #reward_roll ec.temp matches 1 run data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"#55FF55"},{text:"Uncommon: ",color:"green"},{text:"Awakening Stone",color:"green"},{text:" ✦",color:"#55FF55"}]
execute if score #reward_roll ec.temp matches 1 run scoreboard players set #ndur ec.temp 45
execute if score #reward_roll ec.temp matches 1 run function evercraft:util/notify/emit

# 2: Uncommon Essentials Satchel (from satchel loot table)
execute if score #reward_roll ec.temp matches 2 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:satchel/uncommon
execute if score #reward_roll ec.temp matches 2 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:satchel/uncommon
execute if score #reward_roll ec.temp matches 2 run data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"#55FF55"},{text:"Uncommon: ",color:"green"},{text:"Essentials Satchel",color:"green"},{text:" ✦",color:"#55FF55"}]
execute if score #reward_roll ec.temp matches 2 run scoreboard players set #ndur ec.temp 45
execute if score #reward_roll ec.temp matches 2 run function evercraft:util/notify/emit

# 3: Dungeon Key (from actual dungeon loot table)
execute if score #reward_roll ec.temp matches 3 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:dungeon/key
execute if score #reward_roll ec.temp matches 3 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:dungeon/key
execute if score #reward_roll ec.temp matches 3 run data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"#55FF55"},{text:"Uncommon: ",color:"green"},{text:"Dungeon Key",color:"green"},{text:" ✦",color:"#55FF55"}]
execute if score #reward_roll ec.temp matches 3 run scoreboard players set #ndur ec.temp 45
execute if score #reward_roll ec.temp matches 3 run function evercraft:util/notify/emit

# 4: Companion Treat (from loot table)
execute if score #reward_roll ec.temp matches 4 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:companions/items/companion_treat
execute if score #reward_roll ec.temp matches 4 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:companions/items/companion_treat
execute if score #reward_roll ec.temp matches 4 run data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"#55FF55"},{text:"Uncommon: ",color:"green"},{text:"Companion Treat",color:"green"},{text:" ✦",color:"#55FF55"}]
execute if score #reward_roll ec.temp matches 4 run scoreboard players set #ndur ec.temp 45
execute if score #reward_roll ec.temp matches 4 run function evercraft:util/notify/emit

# 5: Netherite scraps (2-3)
execute if score #reward_roll ec.temp matches 5 run give @s minecraft:netherite_scrap 2
execute if score #reward_roll ec.temp matches 5 run data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"#55FF55"},{text:"Uncommon: ",color:"green"},{text:"Netherite Scraps x2",color:"green"},{text:" ✦",color:"#55FF55"}]
execute if score #reward_roll ec.temp matches 5 run scoreboard players set #ndur ec.temp 45
execute if score #reward_roll ec.temp matches 5 run function evercraft:util/notify/emit

# 6: Uncommon Artifact Crate (place to open)
execute if score #reward_roll ec.temp matches 6 run give @s minecraft:barrel[container_loot={loot_table:"evercraft:crates/artifact_uncommon"},custom_name={"text":"Uncommon Artifact Crate","color":"green","italic":false},lore=[{"text":"Something stirs within — a faint pulse","color":"gray","italic":true},{"text":"of power, waiting to be claimed.","color":"gray","italic":true},"",{"text":"Place to reveal your artifact.","color":"dark_gray","italic":false}],custom_data={artc_rarity:"uncommon"}] 1
execute if score #reward_roll ec.temp matches 6 run data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"#55FF55"},{text:"Uncommon: ",color:"green"},{text:"Uncommon Artifact Crate",color:"green"},{text:" ✦",color:"#55FF55"}]
execute if score #reward_roll ec.temp matches 6 run scoreboard players set #ndur ec.temp 45
execute if score #reward_roll ec.temp matches 6 run function evercraft:util/notify/emit

# 7: Uncommon Furnishings Crate item (place to open — self-mints blueprints + antiques)
execute if score #reward_roll ec.temp matches 7 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:decor/crate_item/uncommon
execute if score #reward_roll ec.temp matches 7 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:decor/crate_item/uncommon
execute if score #reward_roll ec.temp matches 7 run data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"#55FF55"},{text:"Uncommon: ",color:"green"},{text:"Furnishings Crate",color:"green"},{text:" ✦",color:"#55FF55"}]
execute if score #reward_roll ec.temp matches 7 run scoreboard players set #ndur ec.temp 45
execute if score #reward_roll ec.temp matches 7 run function evercraft:util/notify/emit

# 8: Uncommon Accessory Crate item (place to open — reg set)
execute if score #reward_roll ec.temp matches 8 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:crates/items/accessory_reg_uncommon
execute if score #reward_roll ec.temp matches 8 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:crates/items/accessory_reg_uncommon
execute if score #reward_roll ec.temp matches 8 run data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"#55FF55"},{text:"Uncommon: ",color:"green"},{text:"Accessory Crate",color:"green"},{text:" ✦",color:"#55FF55"}]
execute if score #reward_roll ec.temp matches 8 run scoreboard players set #ndur ec.temp 45
execute if score #reward_roll ec.temp matches 8 run function evercraft:util/notify/emit

execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.player.levelup master @s ~ ~ ~ 0.5 1.2
