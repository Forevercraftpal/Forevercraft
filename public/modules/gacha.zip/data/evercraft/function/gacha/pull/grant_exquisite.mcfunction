# Grant Exquisite pull reward (5% base rate)
# Runs as @s = player

# Skip roll if pre-rolled by reel animation
execute if score #reward_roll ec.temp matches ..0 store result score #reward_roll ec.temp run random value 1..9

# 1: Exquisite Artifact Crate (place to open)
execute if score #reward_roll ec.temp matches 1 run give @s minecraft:barrel[container_loot={loot_table:"evercraft:crates/artifact_exquisite"},custom_name={"text":"Exquisite Artifact Crate","color":"light_purple","italic":false},lore=[{"text":"Sealed with dreamlight and ancient sigils,","color":"gray","italic":true},{"text":"something extraordinary sleeps within.","color":"gray","italic":true},"",{"text":"Place to reveal your artifact.","color":"dark_gray","italic":false}],custom_data={artc_rarity:"exquisite"},enchantment_glint_override=true] 1
execute if score #reward_roll ec.temp matches 1 run data modify storage evercraft:notify stage.c set value [{text:"✦✦ ",color:"#E0B0FF"},{text:"EXQUISITE: ",color:"light_purple",bold:true},{text:"Exquisite Artifact Crate!",color:"#E0B0FF"},{text:" ✦✦",color:"#E0B0FF"}]
execute if score #reward_roll ec.temp matches 1 run scoreboard players set #ndur ec.temp 45
execute if score #reward_roll ec.temp matches 1 run function evercraft:util/notify/emit

# 2: Exclusive Gacha Companion (Lunar Moth / Nebula Kit / Twilight Hare)
execute if score #reward_roll ec.temp matches 2 run function evercraft:gacha/pull/grant_exquisite_companion

# 3: Random Lore Piece (context-sensitive collectible)
execute if score #reward_roll ec.temp matches 3 at @s run function evercraft:lore/roll/pick_piece
execute if score #reward_roll ec.temp matches 3 run data modify storage evercraft:notify stage.c set value [{text:"✦✦ ",color:"#E0B0FF"},{text:"EXQUISITE: ",color:"light_purple",bold:true},{text:"Lore Piece!",color:"#E0B0FF"},{text:" ✦✦",color:"#E0B0FF"}]
execute if score #reward_roll ec.temp matches 3 run scoreboard players set #ndur ec.temp 45
execute if score #reward_roll ec.temp matches 3 run function evercraft:util/notify/emit

# 4: Netherite Block
execute if score #reward_roll ec.temp matches 4 run give @s minecraft:netherite_block 1
execute if score #reward_roll ec.temp matches 4 run data modify storage evercraft:notify stage.c set value [{text:"✦✦ ",color:"#E0B0FF"},{text:"EXQUISITE: ",color:"light_purple",bold:true},{text:"Netherite Block!",color:"#E0B0FF"},{text:" ✦✦",color:"#E0B0FF"}]
execute if score #reward_roll ec.temp matches 4 run scoreboard players set #ndur ec.temp 45
execute if score #reward_roll ec.temp matches 4 run function evercraft:util/notify/emit

# 5: Hearthstone (place to claim your home)
execute if score #reward_roll ec.temp matches 5 run give @s minecraft:lodestone[custom_name={"text":"Hearthstone","color":"#E0B0FF","italic":false},custom_data={hearthstone:true},lore=[{"text":"Exquisite Relic","color":"light_purple","italic":false},"",{"text":"Warm to the touch, it remembers the hearth","color":"gray","italic":true},{"text":"you haven't built yet.","color":"gray","italic":true},"",{"text":"Place: ","color":"white","italic":false,"extra":[{"text":"Claim a 64x64 home zone","color":"#E0B0FF"}]},{"text":"Buffs: ","color":"white","italic":false,"extra":[{"text":"Tier-scaling bonuses + chunk loading","color":"#E0B0FF"}]},{"text":"Upgrade: ","color":"white","italic":false,"extra":[{"text":"Feed Netherite Ingots to expand","color":"#E0B0FF"}]},"",{"text":"\"Home is wherever the heart dares to settle.\"","color":"dark_gray","italic":true}],enchantment_glint_override=true,rarity=epic] 1
execute if score #reward_roll ec.temp matches 5 run data modify storage evercraft:notify stage.c set value [{text:"✦✦ ",color:"#E0B0FF"},{text:"EXQUISITE: ",color:"light_purple",bold:true},{text:"Hearthstone!",color:"#E0B0FF",bold:true},{text:" ✦✦",color:"#E0B0FF"}]
execute if score #reward_roll ec.temp matches 5 run scoreboard players set #ndur ec.temp 45
execute if score #reward_roll ec.temp matches 5 run function evercraft:util/notify/emit

# 6: Guidestone (waypoint teleport network)
execute if score #reward_roll ec.temp matches 6 run give @s minecraft:lodestone[custom_name={"text":"Guidestone","color":"#E0B0FF","italic":false},lore=[{"text":"Exquisite Relic","color":"light_purple","italic":false},"",{"text":"An anchor between worlds, humming with","color":"gray","italic":true},{"text":"the paths of those who came before.","color":"gray","italic":true},"",{"text":"Place: ","color":"white","italic":false,"extra":[{"text":"Create a waypoint in the network","color":"#E0B0FF"}]},{"text":"Interact: ","color":"white","italic":false,"extra":[{"text":"Open the teleport menu","color":"#E0B0FF"}]},"",{"text":"\"All roads lead somewhere worth going.\"","color":"dark_gray","italic":true}],custom_data={guidestone:1b,evercraft_item:1b,gs_color:"amethyst"},enchantment_glint_override=true,rarity=epic] 1
execute if score #reward_roll ec.temp matches 6 run data modify storage evercraft:notify stage.c set value [{text:"✦✦ ",color:"#E0B0FF"},{text:"EXQUISITE: ",color:"light_purple",bold:true},{text:"Guidestone!",color:"#E0B0FF",bold:true},{text:" ✦✦",color:"#E0B0FF"}]
execute if score #reward_roll ec.temp matches 6 run scoreboard players set #ndur ec.temp 45
execute if score #reward_roll ec.temp matches 6 run function evercraft:util/notify/emit

# 7: Glyphforge (rune enchantment station)
execute if score #reward_roll ec.temp matches 7 run give @s minecraft:lodestone[custom_name={"text":"Glyphforge","color":"#E0B0FF","italic":false},lore=[{"text":"Exquisite Workstation","color":"light_purple","italic":false},"",{"text":"The anvil of lost runesmiths, reforged","color":"gray","italic":true},{"text":"with dream-fire and iron resolve.","color":"gray","italic":true},"",{"text":"Place: ","color":"white","italic":false,"extra":[{"text":"Create a Glyphforge station","color":"#E0B0FF"}]},{"text":"Use: ","color":"white","italic":false,"extra":[{"text":"Permanently bind rune enchantments","color":"#E0B0FF"}]},{"text":"","italic":false,"extra":[{"text":"to weapons and armor","color":"#E0B0FF"}]},"",{"text":"\"The strongest enchantments are forged in silence.\"","color":"dark_gray","italic":true}],custom_data={glyphforge_block:1b},enchantment_glint_override=true,rarity=epic] 1
execute if score #reward_roll ec.temp matches 7 run data modify storage evercraft:notify stage.c set value [{text:"✦✦ ",color:"#E0B0FF"},{text:"EXQUISITE: ",color:"light_purple",bold:true},{text:"Glyphforge!",color:"#E0B0FF",bold:true},{text:" ✦✦",color:"#E0B0FF"}]
execute if score #reward_roll ec.temp matches 7 run scoreboard players set #ndur ec.temp 45
execute if score #reward_roll ec.temp matches 7 run function evercraft:util/notify/emit

# Inv-full guard for the item rewards below.
execute store result score #inv_full ec.var run function evercraft:util/check_inv_full

# 8: Exquisite Accessory Crate item (place to open — reg set)
execute if score #reward_roll ec.temp matches 8 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:crates/items/accessory_reg_exquisite
execute if score #reward_roll ec.temp matches 8 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:crates/items/accessory_reg_exquisite
execute if score #reward_roll ec.temp matches 8 run data modify storage evercraft:notify stage.c set value [{text:"✦✦ ",color:"#E0B0FF"},{text:"EXQUISITE: ",color:"light_purple",bold:true},{text:"Exquisite Accessory Crate!",color:"#E0B0FF"},{text:" ✦✦",color:"#E0B0FF"}]
execute if score #reward_roll ec.temp matches 8 run scoreboard players set #ndur ec.temp 45
execute if score #reward_roll ec.temp matches 8 run function evercraft:util/notify/emit

# 9: Standard Antique — open a Standard quality window (eff 100), then give a rare-band blueprint. The
# got_blueprint->quality_sweep pipeline stamps it Standard (full base effectiveness). (Quality ladder by
# pull tier: Ornate=Poor, Exquisite=Standard, Mythical=Pristine.)
execute if score #reward_roll ec.temp matches 9 run scoreboard players set @s ec.antq_src 100
execute if score #reward_roll ec.temp matches 9 run scoreboard players set @s ec.antq_src_t 300
execute if score #reward_roll ec.temp matches 9 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:decor/crate/pool/bp/rare
execute if score #reward_roll ec.temp matches 9 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:decor/crate/pool/bp/rare
execute if score #reward_roll ec.temp matches 9 run data modify storage evercraft:notify stage.c set value [{text:"✦✦ ",color:"#E0B0FF"},{text:"EXQUISITE: ",color:"light_purple",bold:true},{text:"Antique!",color:"#E0B0FF",bold:true},{text:" ✦✦",color:"#E0B0FF"}]
execute if score #reward_roll ec.temp matches 9 run scoreboard players set #ndur ec.temp 45
execute if score #reward_roll ec.temp matches 9 run function evercraft:util/notify/emit

execute if score @s ec.fx_snd matches 1.. run playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 1 1
execute if score @s ec.fx_vis matches 1.. run particle totem_of_undying ~ ~1.5 ~ 0.5 1 0.5 0.5 50 force @s
execute if score @s ec.fx_vis matches 1.. run particle end_rod ~ ~2 ~ 0.3 0.5 0.3 0.05 20 force @s
