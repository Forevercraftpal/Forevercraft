# Grant a random Glyph from the 13 available
# Runs as @s = player

execute store result score #glyph_roll ec.temp run random value 1..13
# Inv-full guard: drop at the player's feet rather than void on a full inventory.
execute store result score #inv_full ec.var run function evercraft:util/check_inv_full
execute if score #glyph_roll ec.temp matches 1 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:treasure/runes/emberheart
execute if score #glyph_roll ec.temp matches 1 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:treasure/runes/emberheart
execute if score #glyph_roll ec.temp matches 2 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:treasure/runes/verdant
execute if score #glyph_roll ec.temp matches 2 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:treasure/runes/verdant
execute if score #glyph_roll ec.temp matches 3 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:treasure/runes/quicksilver
execute if score #glyph_roll ec.temp matches 3 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:treasure/runes/quicksilver
execute if score #glyph_roll ec.temp matches 4 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:treasure/runes/obsidian
execute if score #glyph_roll ec.temp matches 4 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:treasure/runes/obsidian
execute if score #glyph_roll ec.temp matches 5 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:treasure/runes/zephyr
execute if score #glyph_roll ec.temp matches 5 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:treasure/runes/zephyr
execute if score #glyph_roll ec.temp matches 6 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:treasure/runes/briar
execute if score #glyph_roll ec.temp matches 6 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:treasure/runes/briar
execute if score #glyph_roll ec.temp matches 7 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:treasure/runes/stalwart
execute if score #glyph_roll ec.temp matches 7 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:treasure/runes/stalwart
execute if score #glyph_roll ec.temp matches 8 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:treasure/runes/gilded
execute if score #glyph_roll ec.temp matches 8 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:treasure/runes/gilded
execute if score #glyph_roll ec.temp matches 9 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:treasure/runes/tidecall
execute if score #glyph_roll ec.temp matches 9 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:treasure/runes/tidecall
execute if score #glyph_roll ec.temp matches 10 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:treasure/runes/hearthstone
execute if score #glyph_roll ec.temp matches 10 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:treasure/runes/hearthstone
execute if score #glyph_roll ec.temp matches 11 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:treasure/runes/prism
execute if score #glyph_roll ec.temp matches 11 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:treasure/runes/prism
execute if score #glyph_roll ec.temp matches 12 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:treasure/runes/tempest
execute if score #glyph_roll ec.temp matches 12 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:treasure/runes/tempest
execute if score #glyph_roll ec.temp matches 13 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:treasure/runes/arcanum
execute if score #glyph_roll ec.temp matches 13 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:treasure/runes/arcanum
