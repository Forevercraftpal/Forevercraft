# Soft pity rates (60+ pulls without Ornate+) — favorable odds nerfed to ~1/3 (2026-06-16)
# Boosted vs base, but a third of the old boost. Out of 1000:
# Mythical: 0.2% (1-2), Exquisite: 2.8% (3-30), Ornate: 4.3% (31-73)
# Rare: 6.3% (74-136), Uncommon: 24% (137-376), Common: 62.4% (377-1000)
# Prior soft Rare+ band was 41%; now 13.6% (1/3). Uncommon unchanged; Common absorbs the slack.

execute if score #gacha_roll ec.temp matches 1..2 run return run scoreboard players set #gacha_tier ec.temp 6
execute if score #gacha_roll ec.temp matches 3..30 run return run scoreboard players set #gacha_tier ec.temp 5
execute if score #gacha_roll ec.temp matches 31..73 run return run scoreboard players set #gacha_tier ec.temp 4
execute if score #gacha_roll ec.temp matches 74..136 run return run scoreboard players set #gacha_tier ec.temp 3
execute if score #gacha_roll ec.temp matches 137..376 run return run scoreboard players set #gacha_tier ec.temp 2
scoreboard players set #gacha_tier ec.temp 1
