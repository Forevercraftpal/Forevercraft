# Wishing Star — Grant Selected Artifact (Macro)
# Macro args: art (artifact ID), tier (tier name)
# Run as @s = player

# Grant the artifact from its loot table
# Inv-full guard: drop at the player's feet rather than void on a full inventory.
execute store result score #inv_full ec.var run function evercraft:util/check_inv_full
$execute if score #inv_full ec.var matches 0 run loot give @s loot evercraft:artifacts/$(tier)/$(art)
$execute if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:artifacts/$(tier)/$(art)

# Celebration effects
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 1 0.8
# "something ancient stirs" — arcane wishing-star cue (was ender_dragon.growl; dream-themed, not a dragon weapon)
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.beacon.power_select master @s ~ ~ ~ 0.6 0.6
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.amethyst_block.resonate master @s ~ ~ ~ 0.5 0.7
execute if score @s ec.fx_vis matches 1.. run particle totem_of_undying ~ ~1.5 ~ 1 1.5 1 0.5 100 force @s
execute if score @s ec.fx_vis matches 1.. run particle end_rod ~ ~2 ~ 0.5 1 0.5 0.05 50 force @s

# Grant message (use saved display name from storage)
data modify storage evercraft:notify stage.c set value [{text:"\u2726\u2726\u2726 ",color:"gold"},{text:"Dreamy Star granted you: ",color:"gray"},{nbt:"selected_name",storage:"evercraft:wishing_star",interpret:true,color:"gold",bold:true},{text:"!",color:"gray"},{text:" \u2726\u2726\u2726",color:"gold"}]
scoreboard players set #ndur ec.temp 50
function evercraft:util/notify/emit

# Cleanup — remove tag and close codex
tag @s remove ec.wishing_star_active
function evercraft:advantage/gui/close
