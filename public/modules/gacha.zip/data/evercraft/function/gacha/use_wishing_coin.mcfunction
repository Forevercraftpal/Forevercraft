# Use Coin of Lucidity - Grants +1 bonus pull on next fountain visit
# Triggered by advancement: evercraft:gacha/use_wishing_coin

# Revoke so it can trigger again
advancement revoke @s only evercraft:gacha/use_wishing_coin

# Grant bonus pull flag
scoreboard players add @s ec.wish_bonus 1

# Visual and audio feedback
execute if score @s ec.fx_vis matches 1.. run particle minecraft:enchant ~ ~1 ~ 0.3 0.5 0.3 1 20 force @s
execute if score @s ec.fx_vis matches 1.. run particle minecraft:end_rod ~ ~1.5 ~ 0.2 0.3 0.2 0.02 15 force @s
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.experience_orb.pickup master @s ~ ~ ~ 0.8 1.2
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.6 0.8

# Notify the player
data modify storage evercraft:notify stage.c set value [{text:"\u2726 ",color:"gold"},{text:"Coin of Lucidity consumed! ",color:"yellow"},{text:"+1 bonus pull",color:"gold",bold:true},{text:" on your next Fountain visit.",color:"gray"},{text:" \u2726",color:"gold"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute store result score #bonus_count ec.temp run scoreboard players get @s ec.wish_bonus
execute if score #bonus_count ec.temp matches 2.. run data modify storage evercraft:notify stage.c set value [{text:"Bonus pulls banked: ",color:"gray"},{score:{name:"@s",objective:"ec.wish_bonus"},color:"gold"}]
execute if score #bonus_count ec.temp matches 2.. run scoreboard players set #ndur ec.temp 40
execute if score #bonus_count ec.temp matches 2.. run function evercraft:util/notify/emit
