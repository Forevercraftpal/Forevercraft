# Collection-completion ceremony — Common Artifact Collection (one-time)
# Runs as @s = player. Called once from check_collection_common when all 27 Common
# artifacts are owned. Pure positive reinforcement — no "buy more to start the next
# set" hook (Kompu-gacha reject-list: never a second randomness layer on the prize).

# === REWARD: Dreamdust grant (meaningful, balanced vs the 1-3/pull consolation) ===
scoreboard players add @s ec.dreamdust 50

# === ADVANCEMENT (toast + chat announce) ===
advancement grant @s only evercraft:gacha/common_collector

# === CELEBRATION ===
data modify storage evercraft:notify stage.c set value [{text:"✦✦✦ ",color:"#E0B0FF"},{text:"Collection Complete!",color:"#E0B0FF",bold:true},{text:" ✦✦✦",color:"#E0B0FF"}]
scoreboard players set #ndur ec.temp 50
function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"You've gathered every Common artifact the fountain holds.",color:"gray"}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"+50 Dreamdust",color:"light_purple",bold:true},{text:" — a gift for your devotion.",color:"gray"}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit

# (AB-1 sticky-times sweep 2026-06-10: explicit stamp — `title times` is sticky per player and this sequence set none, so it inherited whatever ran last.)
title @s times 10 60 20
title @s subtitle {"text":"Every Common artifact, gathered.","color":"#E0B0FF"}
title @s title {"text":"✦ Collection Complete ✦","color":"#E0B0FF"}

execute if score @s ec.fx_snd matches 1.. at @s run playsound minecraft:entity.player.levelup master @s ~ ~ ~ 1 1.2
execute if score @s ec.fx_snd matches 1.. at @s run playsound minecraft:block.amethyst_block.resonate master @s ~ ~ ~ 0.8 1.4
execute if score @s ec.fx_vis matches 1.. at @s run particle end_rod ~ ~1.2 ~ 0.6 1 0.6 0.06 40 force @s
