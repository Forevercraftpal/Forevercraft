# Check gacha achievement milestones
# Called after each pull (or periodically)
# Runs as @s = player

# "First Wish" — handled by first_coin.mcfunction

# "Dreamy Star" — Pull a Mythical (granted inline in grant_mythical)

# "Dedicated Dreamer" — 50 total pulls
execute if score @s ec.wish_total matches 50 run advancement grant @s only evercraft:gacha/dedicated_dreamer

# "Fortune Favors the Bold" — 100 total pulls
execute if score @s ec.wish_total matches 100 run advancement grant @s only evercraft:gacha/fortune_favors

# "Eternal Wisher" — 500 total pulls
execute if score @s ec.wish_total matches 500 run advancement grant @s only evercraft:gacha/eternal_wisher

# "Full Constellation" — 3 constellation fragments
execute if score @s ec.const_frag matches 3 run advancement grant @s only evercraft:gacha/full_constellation

# === COLLECTION-COMPLETION MILESTONE: Common Artifact Collection (27 items) ===
# One-time reward beyond the lifetime-pull milestones above. Existence-gated by the
# once-only flag ec.coll_common so the 27-advancement count only runs while the
# milestone is still unclaimed — never every pull forever.
execute if score @s ec.coll_common matches ..0 run function evercraft:gacha/check_collection_common
