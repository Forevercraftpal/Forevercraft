# Fountain of Eternal Dreams — Break Detection & Cleanup
# Runs as: marker (ec.fountain) at marker position
# Triggered when the player_head block is no longer present

# ═══ COLOR-AWARE LOOT DROP ═══
# Kill vanilla player_head drop
kill @e[type=item,nbt={Item:{id:"minecraft:player_head"}},distance=..2]

# Drop correct color variant
execute if data entity @s {data:{color:"fountain_azure"}} run loot spawn ~ ~0.5 ~ loot evercraft:gacha/fountain_item_azure
execute if data entity @s {data:{color:"fountain_crimson"}} run loot spawn ~ ~0.5 ~ loot evercraft:gacha/fountain_item_crimson
execute if data entity @s {data:{color:"fountain_solar"}} run loot spawn ~ ~0.5 ~ loot evercraft:gacha/fountain_item_solar
execute if data entity @s {data:{color:"fountain_verdant"}} run loot spawn ~ ~0.5 ~ loot evercraft:gacha/fountain_item_verdant
execute if data entity @s {data:{color:"fountain_ivory"}} run loot spawn ~ ~0.5 ~ loot evercraft:gacha/fountain_item_ivory
execute if data entity @s {data:{color:"fountain_obsidian"}} run loot spawn ~ ~0.5 ~ loot evercraft:gacha/fountain_item_obsidian
execute if data entity @s {data:{color:"fountain_rose"}} run loot spawn ~ ~0.5 ~ loot evercraft:gacha/fountain_item_rose
execute if data entity @s {data:{color:"fountain_noir"}} run loot spawn ~ ~0.5 ~ loot evercraft:gacha/fountain_item_noir
execute unless data entity @s {data:{color:"fountain_azure"}} unless data entity @s {data:{color:"fountain_crimson"}} unless data entity @s {data:{color:"fountain_solar"}} unless data entity @s {data:{color:"fountain_verdant"}} unless data entity @s {data:{color:"fountain_ivory"}} unless data entity @s {data:{color:"fountain_obsidian"}} unless data entity @s {data:{color:"fountain_rose"}} unless data entity @s {data:{color:"fountain_noir"}} run loot spawn ~ ~0.5 ~ loot evercraft:gacha/fountain_item

# Decrement fountain counter for nearest player
scoreboard players remove @p[distance=..8] ec.fountains 1

# Particles and sound
particle reverse_portal ~ ~0.5 ~ 0.3 0.3 0.3 0.05 15
playsound minecraft:block.beacon.deactivate master @a[scores={ec.fx_snd=1..}] ~ ~ ~ 1 0.8

# Kill associated entities (interaction + label within 2 blocks of marker)
execute as @e[type=interaction,tag=ec.fountain_click,distance=..2] run kill @s
execute as @e[type=text_display,tag=ec.fountain_label,distance=..2] run kill @s

# Kill self (marker)
kill @s
