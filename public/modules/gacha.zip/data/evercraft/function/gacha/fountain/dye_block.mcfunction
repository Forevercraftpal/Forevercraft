# Fountain — Dye Block (right-click with dye)
# Run as: player, at: interaction entity position
# Called from on_interact when player holds a dye

# Detect which dye the player is holding
function evercraft:dyeing/detect_color

# Azure
execute if data storage evercraft:dyeing {color_id:"azure"} as @e[type=marker,tag=ec.fountain,distance=..3,limit=1] run data modify entity @s data.color set value "fountain_azure"
execute if data storage evercraft:dyeing {color_id:"azure"} as @e[type=text_display,tag=ec.fountain_label,distance=..3,limit=1] run data modify entity @s text set value {text:"\u2726 Fountain of Eternal Dreams \u2726",color:"blue",bold:true}

# Crimson
execute if data storage evercraft:dyeing {color_id:"crimson"} as @e[type=marker,tag=ec.fountain,distance=..3,limit=1] run data modify entity @s data.color set value "fountain_crimson"
execute if data storage evercraft:dyeing {color_id:"crimson"} as @e[type=text_display,tag=ec.fountain_label,distance=..3,limit=1] run data modify entity @s text set value {text:"\u2726 Fountain of Eternal Dreams \u2726",color:"red",bold:true}

# Solar
execute if data storage evercraft:dyeing {color_id:"solar"} as @e[type=marker,tag=ec.fountain,distance=..3,limit=1] run data modify entity @s data.color set value "fountain_solar"
execute if data storage evercraft:dyeing {color_id:"solar"} as @e[type=text_display,tag=ec.fountain_label,distance=..3,limit=1] run data modify entity @s text set value {text:"\u2726 Fountain of Eternal Dreams \u2726",color:"gold",bold:true}

# Verdant
execute if data storage evercraft:dyeing {color_id:"verdant"} as @e[type=marker,tag=ec.fountain,distance=..3,limit=1] run data modify entity @s data.color set value "fountain_verdant"
execute if data storage evercraft:dyeing {color_id:"verdant"} as @e[type=text_display,tag=ec.fountain_label,distance=..3,limit=1] run data modify entity @s text set value {text:"\u2726 Fountain of Eternal Dreams \u2726",color:"green",bold:true}

# Ivory
execute if data storage evercraft:dyeing {color_id:"ivory"} as @e[type=marker,tag=ec.fountain,distance=..3,limit=1] run data modify entity @s data.color set value "fountain_ivory"
execute if data storage evercraft:dyeing {color_id:"ivory"} as @e[type=text_display,tag=ec.fountain_label,distance=..3,limit=1] run data modify entity @s text set value {text:"\u2726 Fountain of Eternal Dreams \u2726",color:"white",bold:true}

# Obsidian
execute if data storage evercraft:dyeing {color_id:"obsidian"} as @e[type=marker,tag=ec.fountain,distance=..3,limit=1] run data modify entity @s data.color set value "fountain_obsidian"
execute if data storage evercraft:dyeing {color_id:"obsidian"} as @e[type=text_display,tag=ec.fountain_label,distance=..3,limit=1] run data modify entity @s text set value {text:"\u2726 Fountain of Eternal Dreams \u2726",color:"dark_gray",bold:true}

# Rose
execute if data storage evercraft:dyeing {color_id:"rose"} as @e[type=marker,tag=ec.fountain,distance=..3,limit=1] run data modify entity @s data.color set value "fountain_rose"
execute if data storage evercraft:dyeing {color_id:"rose"} as @e[type=text_display,tag=ec.fountain_label,distance=..3,limit=1] run data modify entity @s text set value {text:"\u2726 Fountain of Eternal Dreams \u2726",color:"#FFB6C1",bold:true}

# Noir
execute if data storage evercraft:dyeing {color_id:"noir"} as @e[type=marker,tag=ec.fountain,distance=..3,limit=1] run data modify entity @s data.color set value "fountain_noir"
execute if data storage evercraft:dyeing {color_id:"noir"} as @e[type=text_display,tag=ec.fountain_label,distance=..3,limit=1] run data modify entity @s text set value {text:"\u2726 Fountain of Eternal Dreams \u2726",color:"gray",bold:true}

# Consume 1 dye from player's hand
item modify entity @s weapon.mainhand {"function":"minecraft:set_count","count":-1,"add":true}

# Effects
function evercraft:dyeing/effects

# Feedback
data modify storage evercraft:notify stage.c set value [{text:"Dyed ",color:"gray",italic:true},{storage:"evercraft:dyeing",nbt:"color_name",interpret:false,color:"#E0B0FF",italic:true},{text:" Fountain",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
