# Describe items on Page 3 — Remaining Mythical (8) + Chrono Shard (the 7th RARE, slot 8)
# Macro {slot:N}, runs as @s = player

$scoreboard players set #gi_slot ec.temp $(slot)

execute if score #gi_slot ec.temp matches 0 run tellraw @s [{"text":"\u2726 ","color":"gold"},{"text":"Hero's Boots","color":"white","bold":true},{"text":" \u2014 ","color":"dark_gray"},{"text":"Mythical","color":"gold"},{"text":" (0.013%)","color":"dark_gray"}]
execute if score #gi_slot ec.temp matches 0 run tellraw @s [{"text":"Dancer Class","color":"#DA70D6","bold":true},{"text":" \u2014 Netherite Boots. ","color":"gray"},{"text":"Part of the Hero Set (4pc).","color":"dark_aqua"}]

execute if score #gi_slot ec.temp matches 1 run tellraw @s [{"text":"\u2726 ","color":"gold"},{"text":"Robot Dancer's Sword","color":"white","bold":true},{"text":" \u2014 ","color":"dark_gray"},{"text":"Mythical","color":"gold"},{"text":" (0.013%)","color":"dark_gray"}]
execute if score #gi_slot ec.temp matches 1 run tellraw @s [{"text":"Dancer Class","color":"#DA70D6","bold":true},{"text":" \u2014 Netherite Sword. ","color":"gray"},{"text":"Dances through foes with electric precision.","color":"dark_aqua"}]

execute if score #gi_slot ec.temp matches 2 run tellraw @s [{"text":"\u2726 ","color":"gold"},{"text":"Droid Dancer's Sword","color":"white","bold":true},{"text":" \u2014 ","color":"dark_gray"},{"text":"Mythical","color":"gold"},{"text":" (0.013%)","color":"dark_gray"}]
execute if score #gi_slot ec.temp matches 2 run tellraw @s [{"text":"Dancer Class","color":"#DA70D6","bold":true},{"text":" \u2014 Netherite Sword. ","color":"gray"},{"text":"A mechanical blade that mirrors its twin.","color":"dark_aqua"}]

execute if score #gi_slot ec.temp matches 3 run tellraw @s [{"text":"\u2726 ","color":"gold"},{"text":"Dreamstag Crate","color":"white","bold":true},{"text":" \u2014 ","color":"dark_gray"},{"text":"Mythical","color":"gold"},{"text":" (0.020%)","color":"dark_gray"}]
execute if score #gi_slot ec.temp matches 3 run tellraw @s {"text":"Contains the Dreamstag mythical companion.","color":"gray","italic":true}

execute if score #gi_slot ec.temp matches 4 run tellraw @s [{"text":"\u2726 ","color":"gold"},{"text":"Starweaver Crate","color":"white","bold":true},{"text":" \u2014 ","color":"dark_gray"},{"text":"Mythical","color":"gold"},{"text":" (0.020%)","color":"dark_gray"}]
execute if score #gi_slot ec.temp matches 4 run tellraw @s {"text":"Contains the Starweaver mythical companion.","color":"gray","italic":true}

execute if score #gi_slot ec.temp matches 5 run tellraw @s [{"text":"\u2726 ","color":"gold"},{"text":"Somnia Crate","color":"white","bold":true},{"text":" \u2014 ","color":"dark_gray"},{"text":"Mythical","color":"gold"},{"text":" (0.020%)","color":"dark_gray"}]
execute if score #gi_slot ec.temp matches 5 run tellraw @s {"text":"Contains the Somnia mythical companion.","color":"gray","italic":true}

execute if score #gi_slot ec.temp matches 6 run tellraw @s [{"text":"\u2726 ","color":"gold"},{"text":"Dreamdust Crystal","color":"white","bold":true},{"text":" \u2014 ","color":"dark_gray"},{"text":"Mythical","color":"gold"},{"text":" (0.06%)","color":"dark_gray"}]
execute if score #gi_slot ec.temp matches 6 run tellraw @s {"text":"Right-click to consume: permanently gain +2.5 Dream Rate. One per player.","color":"gray","italic":true}

execute if score #gi_slot ec.temp matches 7 run tellraw @s [{"text":"\u2726 ","color":"gold"},{"text":"Dreamy Star","color":"white","bold":true},{"text":" \u2014 ","color":"dark_gray"},{"text":"Mythical","color":"gold"},{"text":" (0.06%)","color":"dark_gray"}]
execute if score #gi_slot ec.temp matches 7 run tellraw @s {"text":"Right-click to use: choose ANY artifact from the entire pack. A dream come true.","color":"gray","italic":true}

# Slot 8: Chrono Shard \u2014 the 7th RARE item (aqua, 2.14%), shown here because Page 1's Rare row is full.
execute if score #gi_slot ec.temp matches 8 run tellraw @s [{"text":"\u23f3 ","color":"dark_aqua"},{"text":"Chrono Shard","color":"white","bold":true},{"text":" \u2014 ","color":"dark_gray"},{"text":"Rare","color":"aqua"},{"text":" (2.14%)","color":"dark_gray"}]
execute if score #gi_slot ec.temp matches 8 run tellraw @s {"text":"Right-click to activate: reset one progression system of your choice. A Reset Token.","color":"gray","italic":true}
