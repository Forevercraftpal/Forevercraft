# Initialize the Gacha Info Browser
# Runs as @s = player with ec.InFountain tag

# Close fountain menu (kill menu entities, keep fountain label hidden)
# Use at @s to ensure distance checks run from the player's position
# Menu Core: Y-displacement close anchor
tag @s add ec.menu_active
execute store result score @s ec.menu_open_y run data get entity @s Pos[1] 100

execute at @s as @e[tag=ec.FountainMenu,distance=..20] if score @s adv.gui_session = @p[tag=ec.InFountain] adv.gui_session run kill @s
execute at @s as @e[type=text_display,tag=ec.fountain_label,distance=..20] run data modify entity @s text set value {text:""}
execute at @s as @e[type=interaction,tag=ec.fountain_click,distance=..20] run data modify entity @s height set value 0.0f

# Swap tags
tag @s remove ec.InFountain
tag @s remove ec.InExchange
tag @s add ec.InGachaInfo

# Set page to 1
scoreboard players set @s ec.gacha_page 1

# Initialize inactivity timer
scoreboard players set @s ec.gi_idle 0

# Spawn anchor in front of player (pet menu v2 pattern)
execute at @s rotated ~ 0 positioned ^ ^1.55 ^1.8 run summon marker ~ ~ ~ {Tags:["ec.GachaInfoAnchor","smithed.entity"]}

# Spawn frame and page 1
execute at @s rotated ~ 0 positioned ^ ^1.55 ^1.8 run function evercraft:gacha/fountain/info/spawn_frame
execute at @s rotated ~ 0 positioned ^ ^1.55 ^1.8 run function evercraft:gacha/fountain/info/page1

execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.enchantment_table.use master @s ~ ~ ~ 0.5 1.2

# === HONEST ODDS + MERCY BRIEFING (chat) ===
# Legible top-of-browser summary (China-2017 / HoYo transparency standard): the true
# per-tier rates, the mercy ladder, and where duplicate rewards pay off. Printed once
# when the player opens the odds page so the whole shape is graspable without a wiki.
tellraw @s ["",{"text":"\n✦ ","color":"#E0B0FF"},{"text":"Fountain Odds — every wish, honestly","color":"#E0B0FF","bold":true},{"text":" ✦","color":"#E0B0FF"}]
tellraw @s [{"text":"  Per wish: ","color":"gray"},{"text":"Mythical 0.1%","color":"gold"},{"text":" · ","color":"dark_gray"},{"text":"Exquisite 1.6%","color":"#E0B0FF"},{"text":" · ","color":"dark_gray"},{"text":"Ornate 2.7%","color":"light_purple"},{"text":" · ","color":"dark_gray"},{"text":"Rare 5%","color":"aqua"},{"text":" · ","color":"dark_gray"},{"text":"Uncommon 25%","color":"green"},{"text":" · ","color":"dark_gray"},{"text":"Common 65.6%","color":"white"}]
tellraw @s [{"text":"  Mercy: ","color":"gray"},{"text":"a Rare or finer is guaranteed within 30 wishes","color":"aqua"},{"text":"; odds rise after 60; an Exquisite or finer is guaranteed by 90.","color":"gray"}]
tellraw @s [{"text":"  So the ","color":"gray"},{"text":"effective top-tier rate is higher than the base","color":"gold"},{"text":" — the mercy ladder lifts it, and your dreams never fade on a timer.","color":"gray"}]
tellraw @s [{"text":"  Lucid Claim: ","color":"gray"},{"text":"banked lucidity (+1 per wish) lets you choose ANY mythical artifact","color":"gold"},{"text":". Cost ramps 400→ 250 → 125 → 75 → 50 and the remainder banks toward the next.","color":"gray"}]
tellraw @s [{"text":"  Duplicates pay off: ","color":"gray"},{"text":"spare cosmetics & companions become shards","color":"light_purple"},{"text":", and spare artifacts can be re-shaped into another at the ","color":"gray"},{"text":"Transmutation Stand","color":"#E0B0FF"},{"text":".","color":"gray"}]
tellraw @s [{"text":"  Dream Rate: ","color":"gray"},{"text":"gently sways your wishes here toward higher dreams","color":"aqua"},{"text":" — and out in the world it is the key that unlocks the rarest crate treasures.","color":"gray"}]
