# Exchange buy: Awakening Stone for 15 Dreamdust
# Runs as @s = player
# Compute the effective cost (set_cost halves it during Convergence of Dreams) into #ddcost ec.temp.
function evercraft:gacha/exchange/buy/set_cost {base:15}
execute unless score @s ec.dreamdust >= #ddcost ec.temp run data modify storage evercraft:notify stage.c set value [{text:"\u25C6 ",color:"gray"},{text:"Not enough Dreamdust! Need ",color:"red"},{score:{name:"#ddcost",objective:"ec.temp"},color:"red"},{text:".",color:"red"},{text:" \u25C6",color:"gray"}]
execute unless score @s ec.dreamdust >= #ddcost ec.temp run scoreboard players set #ndur ec.temp 45
execute unless score @s ec.dreamdust >= #ddcost ec.temp run return run function evercraft:util/notify/emit
scoreboard players operation @s ec.dreamdust -= #ddcost ec.temp
give @s minecraft:stick[item_model="minecraft:amethyst_cluster",custom_name={text:"Awakening Stone",color:"light_purple",italic:false},custom_data={awakening_stone:true,tier:"common"}] 1
data modify storage evercraft:notify stage.c set value [{text:"\u25C6 ",color:"#E0B0FF"},{text:"Purchased ",color:"gray"},{text:"Awakening Stone",color:"light_purple"},{text:"!",color:"gray"},{text:" \u25C6",color:"#E0B0FF"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.experience_orb.pickup master @s ~ ~ ~ 0.5 1.3
