# Exchange buy: Random Particle for 100 Dreamdust
# Runs as @s = player
# Compute the effective cost (set_cost halves it during Convergence of Dreams) into #ddcost ec.temp.
function evercraft:gacha/exchange/buy/set_cost {base:100}
execute unless score @s ec.dreamdust >= #ddcost ec.temp run data modify storage evercraft:notify stage.c set value [{text:"\u25C6 ",color:"gray"},{text:"Not enough Dreamdust! Need ",color:"red"},{score:{name:"#ddcost",objective:"ec.temp"},color:"red"},{text:".",color:"red"},{text:" \u25C6",color:"gray"}]
execute unless score @s ec.dreamdust >= #ddcost ec.temp run scoreboard players set #ndur ec.temp 45
execute unless score @s ec.dreamdust >= #ddcost ec.temp run return run function evercraft:util/notify/emit
scoreboard players operation @s ec.dreamdust -= #ddcost ec.temp

# Roll random particle (1-19) and unlock via crate system
execute store result score @s adv.temp run random value 1..19
function evercraft:advantage/cosmetics/crate_unlock_particle

execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.experience_orb.pickup master @s ~ ~ ~ 0.5 1.3
