# Give player the Fountain of Eternal Dreams placement item
# Called from Codex button
# Runs as @s = player

# Check limit (3 max per player)
execute if score @s ec.fountains matches 3.. run data modify storage evercraft:notify stage.c set value [{text:"\u2726 ",color:"red"},{text:"You already own the maximum of ",color:"gray"},{text:"3 Fountains",color:"gold"},{text:".",color:"gray"},{text:" \u2726",color:"red"}]
execute if score @s ec.fountains matches 3.. run scoreboard players set #ndur ec.temp 45
execute if score @s ec.fountains matches 3.. run return run function evercraft:util/notify/emit

# Inv-full guard: drop at the player's feet rather than void on a full inventory.
execute store result score #inv_full ec.var run function evercraft:util/check_inv_full
execute if score #inv_full ec.var matches 0 run loot give @s loot evercraft:gacha/fountain_item
execute if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:gacha/fountain_item
scoreboard players add @s ec.fountains 1

data modify storage evercraft:notify stage.c set value [{text:"\u2726 ",color:"#E0B0FF"},{text:"Fountain of Eternal Dreams",color:"gold",bold:true},{text:" added to inventory!",color:"gray"},{text:" \u2726",color:"#E0B0FF"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.enchantment_table.use master @s ~ ~ ~ 0.7 1.2

# First fountain: the Gacha option now lives in Codex Settings (Joseph 2026-06-01)
execute if score @s ec.fountains matches 1 run data modify storage evercraft:notify stage.c set value [{text:"\u2726 ",color:"aqua"},{text:"The Gacha option has moved to your Codex ",color:"gray"},{text:"Settings",color:"aqua",bold:true},{text:".",color:"gray"},{text:" \u2726",color:"aqua"}]
execute if score @s ec.fountains matches 1 run scoreboard players set #ndur ec.temp 45
execute if score @s ec.fountains matches 1 run function evercraft:util/notify/emit
