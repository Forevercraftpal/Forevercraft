# Fountain menu — Dreamdust Exchange clicked
# Runs as @s = the verified clicker (dispatched on target from check_clicks)
data remove entity @s interaction
function evercraft:gacha/fountain/menu/open_exchange
