# Fountain menu — Show the Mercy (pity + spark transparency)
# Runs as @s = player. Called from on_click_balance after the balance line.
#
# "Show the mercy" (WP2): a player can see, without any wiki, exactly how close
# their guarantees are. All numbers read the live pity counters:
#   ec.wish_pity → guaranteed Rare+ at 30
#   ec.wish_soft → boosted odds at 60, guaranteed Exquisite+ at 90
#   ec.wish_spark → lucidity (+1 per pull); Lucid Claim costs the ramp (400/250/125/75/50)

# === Wishes until guaranteed Rare+ (30-pity) ===
scoreboard players set #m_pity ec.temp 30
scoreboard players operation #m_pity ec.temp -= @s ec.wish_pity
execute if score #m_pity ec.temp matches ..0 run scoreboard players set #m_pity ec.temp 0
tellraw @s [{"text":"  ☆ ","color":"aqua"},{"score":{"name":"#m_pity","objective":"ec.temp"},"color":"aqua","bold":true},{"text":" wish(es) until a guaranteed Rare or finer.","color":"gray"}]

# === Soft / hard pity status (boosted at 60, guaranteed Exquisite+ at 90) ===
scoreboard players set #m_soft ec.temp 60
scoreboard players operation #m_soft ec.temp -= @s ec.wish_soft
execute if score #m_soft ec.temp matches ..0 run scoreboard players set #m_soft ec.temp 0
scoreboard players set #m_hard ec.temp 90
scoreboard players operation #m_hard ec.temp -= @s ec.wish_soft
execute if score #m_hard ec.temp matches ..0 run scoreboard players set #m_hard ec.temp 0
execute if score @s ec.wish_soft matches 90.. run tellraw @s [{"text":"  ☆ ","color":"light_purple"},{"text":"Your next wish is a guaranteed Exquisite or finer!","color":"light_purple"}]
execute if score @s ec.wish_soft matches 60..89 run tellraw @s [{"text":"  ☆ ","color":"light_purple"},{"text":"Boosted odds active — guaranteed Exquisite+ in ","color":"gray"},{"score":{"name":"#m_hard","objective":"ec.temp"},"color":"light_purple","bold":true},{"text":" wish(es).","color":"gray"}]
execute if score @s ec.wish_soft matches ..59 run tellraw @s [{"text":"  ☆ ","color":"light_purple"},{"text":"Boosted odds begin in ","color":"gray"},{"score":{"name":"#m_soft","objective":"ec.temp"},"color":"light_purple","bold":true},{"text":" wish(es); guaranteed Exquisite+ in ","color":"gray"},{"score":{"name":"#m_hard","objective":"ec.temp"},"color":"light_purple","bold":true},{"text":".","color":"gray"}]

# === Lucid Claim — banked lucidity + next claim cost (ramp) ===
scoreboard players set #spark_cost ec.var 50
execute if score @s ec.spark_claims matches 0 run scoreboard players set #spark_cost ec.var 400
execute if score @s ec.spark_claims matches 1 run scoreboard players set #spark_cost ec.var 250
execute if score @s ec.spark_claims matches 2 run scoreboard players set #spark_cost ec.var 125
execute if score @s ec.spark_claims matches 3 run scoreboard players set #spark_cost ec.var 75
tellraw @s [{"text":"  ★ ","color":"gold"},{"text":"Lucidity ","color":"gray"},{"score":{"name":"@s","objective":"ec.wish_spark"},"color":"aqua","bold":true},{"text":" / ","color":"dark_gray"},{"score":{"name":"#spark_cost","objective":"ec.var"},"color":"gold","bold":true},{"text":" for your next Lucid Claim (choose ANY mythical artifact).","color":"gray"}]
tellraw @s [{"text":"  ☆ ","color":"dark_gray"},{"text":"Your dreams never fade on a timer — every wish counts toward your next guarantee.","color":"dark_gray","italic":true}]
