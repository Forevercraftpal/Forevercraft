# Info browser tick — distance check + click detection
# Runs as @s = player with ec.InGachaInfo, at @s

# Auto-close if player walks too far from anchor
execute unless entity @e[tag=ec.GachaInfoAnchor,distance=..5] run return run function evercraft:gacha/fountain/info/close

# Auto-close after 20 seconds of inactivity (400 ticks)
scoreboard players add @s ec.gi_idle 1
execute if score @s ec.gi_idle matches 400.. run return run function evercraft:gacha/fountain/info/close
execute as @e[type=interaction,tag=ec.GachaInfoSlot,distance=..5] if data entity @s interaction run scoreboard players set @p[tag=ec.InGachaInfo,distance=..5] ec.gi_idle 0
execute as @e[type=interaction,tag=ec.GachaInfoFrame,distance=..5] if data entity @s interaction run scoreboard players set @p[tag=ec.InGachaInfo,distance=..5] ec.gi_idle 0

# Unified UI-click FX (Joseph 2026-06-05): fire the gated cue ONCE if a slot or a frame (nav/close) was
# clicked this tick. One-shot flag avoids a double-blip if both families register a click the same tick.
scoreboard players set #gi_click ec.temp 0
execute if entity @e[type=interaction,tag=ec.GachaInfoSlot,distance=..6,nbt={interaction:{}},limit=1] run scoreboard players set #gi_click ec.temp 1
execute if entity @e[type=interaction,tag=ec.GachaInfoFrame,distance=..6,nbt={interaction:{}},limit=1] run scoreboard players set #gi_click ec.temp 1
execute if score #gi_click ec.temp matches 1 run function evercraft:fx/ui/click

# Check for clicks
function evercraft:gacha/fountain/info/check_clicks
