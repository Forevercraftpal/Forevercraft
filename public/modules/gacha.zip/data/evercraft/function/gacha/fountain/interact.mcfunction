# Fountain interaction — player right-clicked the fountain
# Runs as @s = interaction entity (ec.fountain_click), at @s
# Detected by: if data entity @s interaction

# Clear interaction data
data remove entity @s interaction

# --- Dye intercept ---
execute as @p[distance=..5] if items entity @s weapon.mainhand #evercraft:dyes run return run function evercraft:gacha/fountain/dye_block
execute as @p[distance=..5] if items entity @s weapon.mainhand minecraft:water_bucket run return run function evercraft:gacha/fountain/wash_block

# Find the player who right-clicked via nearest player within range
# (on attacker only works for left-click/attack, not right-click/interaction)
# Guard: skip if player already has a menu open (prevents lucid claim double-open)
execute as @p[distance=..5,tag=!Adv.InMenu,tag=!ec.InFountain] at @s run function evercraft:gacha/fountain/menu/open
