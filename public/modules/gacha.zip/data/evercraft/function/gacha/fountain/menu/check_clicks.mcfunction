# Check Fountain menu button clicks
# Runs as @s = player with ec.InFountain tag, at @s

# ===== SHARED =====
# Balance check (works on both pages)
execute as @e[type=interaction,tag=ec.FountainClickBalance,distance=..20] if data entity @s interaction if score @s adv.gui_session = @p[tag=ec.InFountain,distance=..20] adv.gui_session on target run function evercraft:gacha/fountain/menu/on_click_balance
execute as @e[type=interaction,tag=ec.FountainClickBalance,distance=..20] if data entity @s interaction if score @s adv.gui_session = @p[tag=ec.InFountain,distance=..20] adv.gui_session run data remove entity @s interaction
execute as @e[type=interaction,tag=ec.ExBalance,distance=..20] if data entity @s interaction if score @s adv.gui_session = @p[tag=ec.InFountain,distance=..20] adv.gui_session on target run function evercraft:gacha/fountain/menu/on_click_balance
execute as @e[type=interaction,tag=ec.ExBalance,distance=..20] if data entity @s interaction if score @s adv.gui_session = @p[tag=ec.InFountain,distance=..20] adv.gui_session run data remove entity @s interaction

# Info browser
execute as @e[type=interaction,tag=ec.FountainClickInfo,distance=..20] if data entity @s interaction if score @s adv.gui_session = @p[tag=ec.InFountain,distance=..20] adv.gui_session on target run function evercraft:gacha/fountain/info/open
execute as @e[type=interaction,tag=ec.FountainClickInfo,distance=..20] if data entity @s interaction if score @s adv.gui_session = @p[tag=ec.InFountain,distance=..20] adv.gui_session run data remove entity @s interaction

# ===== PAGE 1: Main Menu =====
# Pull x1
execute as @e[type=interaction,tag=ec.FountainClick1,distance=..20] if data entity @s interaction if score @s adv.gui_session = @p[tag=ec.InFountain,distance=..20] adv.gui_session on target run function evercraft:gacha/fountain/menu/on_click_pull1
execute as @e[type=interaction,tag=ec.FountainClick1,distance=..20] if data entity @s interaction if score @s adv.gui_session = @p[tag=ec.InFountain,distance=..20] adv.gui_session run data remove entity @s interaction

# Pull x10
execute as @e[type=interaction,tag=ec.FountainClick10,distance=..20] if data entity @s interaction if score @s adv.gui_session = @p[tag=ec.InFountain,distance=..20] adv.gui_session on target run function evercraft:gacha/fountain/menu/on_click_pull10
execute as @e[type=interaction,tag=ec.FountainClick10,distance=..20] if data entity @s interaction if score @s adv.gui_session = @p[tag=ec.InFountain,distance=..20] adv.gui_session run data remove entity @s interaction

# Lucid Claim
execute as @e[type=interaction,tag=ec.FountainClickSpark,distance=..20] if data entity @s interaction if score @s adv.gui_session = @p[tag=ec.InFountain,distance=..20] adv.gui_session on target run function evercraft:gacha/fountain/menu/on_click_spark
execute as @e[type=interaction,tag=ec.FountainClickSpark,distance=..20] if data entity @s interaction if score @s adv.gui_session = @p[tag=ec.InFountain,distance=..20] adv.gui_session run data remove entity @s interaction

# Dreamdust Exchange
execute as @e[type=interaction,tag=ec.FountainClickExchange,distance=..20] if data entity @s interaction if score @s adv.gui_session = @p[tag=ec.InFountain,distance=..20] adv.gui_session on target run function evercraft:gacha/fountain/menu/on_click_exchange
execute as @e[type=interaction,tag=ec.FountainClickExchange,distance=..20] if data entity @s interaction if score @s adv.gui_session = @p[tag=ec.InFountain,distance=..20] adv.gui_session run data remove entity @s interaction

# Close (page 1)
execute as @e[type=interaction,tag=ec.FountainClickClose,distance=..20] if data entity @s interaction if score @s adv.gui_session = @p[tag=ec.InFountain,distance=..20] adv.gui_session on target run function evercraft:gacha/fountain/menu/on_click_close
execute as @e[type=interaction,tag=ec.FountainClickClose,distance=..20] if data entity @s interaction if score @s adv.gui_session = @p[tag=ec.InFountain,distance=..20] adv.gui_session run data remove entity @s interaction

# ===== PAGE 2: Exchange =====
execute as @e[type=interaction,tag=ec.ExBuy1,distance=..20] if data entity @s interaction if score @s adv.gui_session = @p[tag=ec.InFountain,distance=..20] adv.gui_session on target run function evercraft:gacha/fountain/menu/ex_buy1
execute as @e[type=interaction,tag=ec.ExBuy1,distance=..20] if data entity @s interaction if score @s adv.gui_session = @p[tag=ec.InFountain,distance=..20] adv.gui_session run data remove entity @s interaction
execute as @e[type=interaction,tag=ec.ExBuy2,distance=..20] if data entity @s interaction if score @s adv.gui_session = @p[tag=ec.InFountain,distance=..20] adv.gui_session on target run function evercraft:gacha/fountain/menu/ex_buy2
execute as @e[type=interaction,tag=ec.ExBuy2,distance=..20] if data entity @s interaction if score @s adv.gui_session = @p[tag=ec.InFountain,distance=..20] adv.gui_session run data remove entity @s interaction
execute as @e[type=interaction,tag=ec.ExBuy3,distance=..20] if data entity @s interaction if score @s adv.gui_session = @p[tag=ec.InFountain,distance=..20] adv.gui_session on target run function evercraft:gacha/fountain/menu/ex_buy3
execute as @e[type=interaction,tag=ec.ExBuy3,distance=..20] if data entity @s interaction if score @s adv.gui_session = @p[tag=ec.InFountain,distance=..20] adv.gui_session run data remove entity @s interaction
execute as @e[type=interaction,tag=ec.ExBuy4,distance=..20] if data entity @s interaction if score @s adv.gui_session = @p[tag=ec.InFountain,distance=..20] adv.gui_session on target run function evercraft:gacha/fountain/menu/ex_buy4
execute as @e[type=interaction,tag=ec.ExBuy4,distance=..20] if data entity @s interaction if score @s adv.gui_session = @p[tag=ec.InFountain,distance=..20] adv.gui_session run data remove entity @s interaction
execute as @e[type=interaction,tag=ec.ExBuy5,distance=..20] if data entity @s interaction if score @s adv.gui_session = @p[tag=ec.InFountain,distance=..20] adv.gui_session on target run function evercraft:gacha/fountain/menu/ex_buy5
execute as @e[type=interaction,tag=ec.ExBuy5,distance=..20] if data entity @s interaction if score @s adv.gui_session = @p[tag=ec.InFountain,distance=..20] adv.gui_session run data remove entity @s interaction
execute as @e[type=interaction,tag=ec.ExBuy6,distance=..20] if data entity @s interaction if score @s adv.gui_session = @p[tag=ec.InFountain,distance=..20] adv.gui_session on target run function evercraft:gacha/fountain/menu/ex_buy6
execute as @e[type=interaction,tag=ec.ExBuy6,distance=..20] if data entity @s interaction if score @s adv.gui_session = @p[tag=ec.InFountain,distance=..20] adv.gui_session run data remove entity @s interaction
execute as @e[type=interaction,tag=ec.ExBuy7,distance=..20] if data entity @s interaction if score @s adv.gui_session = @p[tag=ec.InFountain,distance=..20] adv.gui_session on target run function evercraft:gacha/fountain/menu/ex_buy7
execute as @e[type=interaction,tag=ec.ExBuy7,distance=..20] if data entity @s interaction if score @s adv.gui_session = @p[tag=ec.InFountain,distance=..20] adv.gui_session run data remove entity @s interaction
execute as @e[type=interaction,tag=ec.ExBuy8,distance=..20] if data entity @s interaction if score @s adv.gui_session = @p[tag=ec.InFountain,distance=..20] adv.gui_session on target run function evercraft:gacha/fountain/menu/ex_buy8
execute as @e[type=interaction,tag=ec.ExBuy8,distance=..20] if data entity @s interaction if score @s adv.gui_session = @p[tag=ec.InFountain,distance=..20] adv.gui_session run data remove entity @s interaction

# Back (exchange page)
execute as @e[type=interaction,tag=ec.ExBack,distance=..20] if data entity @s interaction if score @s adv.gui_session = @p[tag=ec.InFountain,distance=..20] adv.gui_session on target run function evercraft:gacha/fountain/menu/ex_back
execute as @e[type=interaction,tag=ec.ExBack,distance=..20] if data entity @s interaction if score @s adv.gui_session = @p[tag=ec.InFountain,distance=..20] adv.gui_session run data remove entity @s interaction

# Close (exchange page)
execute as @e[type=interaction,tag=ec.ExClose,distance=..20] if data entity @s interaction if score @s adv.gui_session = @p[tag=ec.InFountain,distance=..20] adv.gui_session on target run function evercraft:gacha/fountain/menu/ex_close
execute as @e[type=interaction,tag=ec.ExClose,distance=..20] if data entity @s interaction if score @s adv.gui_session = @p[tag=ec.InFountain,distance=..20] adv.gui_session run data remove entity @s interaction

# ===== INSPECT (left-click = what does this button do?) — gui/inspect pattern 2026-06-11 =====
execute as @e[type=interaction,tag=ec.FountainClick1,distance=..20] if data entity @s attack if score @s adv.gui_session = @p[tag=ec.InFountain,distance=..20] adv.gui_session on attacker run function evercraft:gui/inspect/card {t:"Pull x1",b:"Casts one coin into the fountain — first click asks, second confirms the pull."}
execute as @e[type=interaction,tag=ec.FountainClick1,distance=..20] if data entity @s interaction if score @s adv.gui_session = @p[tag=ec.InFountain,distance=..20] adv.gui_session run data remove entity @s interaction
execute as @e[type=interaction,tag=ec.FountainClick10,distance=..20] if data entity @s attack if score @s adv.gui_session = @p[tag=ec.InFountain,distance=..20] adv.gui_session on attacker run function evercraft:gui/inspect/card {t:"Pull x10",b:"Casts ten coins at once — first click asks, second confirms the pull."}
execute as @e[type=interaction,tag=ec.FountainClick10,distance=..20] if data entity @s interaction if score @s adv.gui_session = @p[tag=ec.InFountain,distance=..20] adv.gui_session run data remove entity @s interaction
execute as @e[type=interaction,tag=ec.ExBuy1,distance=..20] if data entity @s attack if score @s adv.gui_session = @p[tag=ec.InFountain,distance=..20] adv.gui_session on attacker run function evercraft:gui/inspect/card {t:"First Exchange Offer",b:"Right-click the exchange offer in row 1 — first click asks to confirm, second click commits. The offer details are on the row label."}
execute as @e[type=interaction,tag=ec.ExBuy1,distance=..20] if data entity @s interaction if score @s adv.gui_session = @p[tag=ec.InFountain,distance=..20] adv.gui_session run data remove entity @s interaction
execute as @e[type=interaction,tag=ec.ExBuy2,distance=..20] if data entity @s attack if score @s adv.gui_session = @p[tag=ec.InFountain,distance=..20] adv.gui_session on attacker run function evercraft:gui/inspect/card {t:"Second Exchange Offer",b:"Right-click the exchange offer in row 2 — first click asks to confirm, second click commits. The offer details are on the row label."}
execute as @e[type=interaction,tag=ec.ExBuy2,distance=..20] if data entity @s interaction if score @s adv.gui_session = @p[tag=ec.InFountain,distance=..20] adv.gui_session run data remove entity @s interaction
execute as @e[type=interaction,tag=ec.ExBuy3,distance=..20] if data entity @s attack if score @s adv.gui_session = @p[tag=ec.InFountain,distance=..20] adv.gui_session on attacker run function evercraft:gui/inspect/card {t:"Third Exchange Offer",b:"Right-click the exchange offer in row 3 — first click asks to confirm, second click commits. The offer details are on the row label."}
execute as @e[type=interaction,tag=ec.ExBuy3,distance=..20] if data entity @s interaction if score @s adv.gui_session = @p[tag=ec.InFountain,distance=..20] adv.gui_session run data remove entity @s interaction
execute as @e[type=interaction,tag=ec.ExBuy4,distance=..20] if data entity @s attack if score @s adv.gui_session = @p[tag=ec.InFountain,distance=..20] adv.gui_session on attacker run function evercraft:gui/inspect/card {t:"Fourth Exchange Offer",b:"Right-click the exchange offer in row 4 — first click asks to confirm, second click commits. The offer details are on the row label."}
execute as @e[type=interaction,tag=ec.ExBuy4,distance=..20] if data entity @s interaction if score @s adv.gui_session = @p[tag=ec.InFountain,distance=..20] adv.gui_session run data remove entity @s interaction
execute as @e[type=interaction,tag=ec.ExBuy5,distance=..20] if data entity @s attack if score @s adv.gui_session = @p[tag=ec.InFountain,distance=..20] adv.gui_session on attacker run function evercraft:gui/inspect/card {t:"Fifth Exchange Offer",b:"Right-click the exchange offer in row 5 — first click asks to confirm, second click commits. The offer details are on the row label."}
execute as @e[type=interaction,tag=ec.ExBuy5,distance=..20] if data entity @s interaction if score @s adv.gui_session = @p[tag=ec.InFountain,distance=..20] adv.gui_session run data remove entity @s interaction
execute as @e[type=interaction,tag=ec.ExBuy6,distance=..20] if data entity @s attack if score @s adv.gui_session = @p[tag=ec.InFountain,distance=..20] adv.gui_session on attacker run function evercraft:gui/inspect/card {t:"Sixth Exchange Offer",b:"Right-click the exchange offer in row 6 — first click asks to confirm, second click commits. The offer details are on the row label."}
execute as @e[type=interaction,tag=ec.ExBuy6,distance=..20] if data entity @s interaction if score @s adv.gui_session = @p[tag=ec.InFountain,distance=..20] adv.gui_session run data remove entity @s interaction
execute as @e[type=interaction,tag=ec.ExBuy7,distance=..20] if data entity @s attack if score @s adv.gui_session = @p[tag=ec.InFountain,distance=..20] adv.gui_session on attacker run function evercraft:gui/inspect/card {t:"Seventh Exchange Offer",b:"Right-click the exchange offer in row 7 — first click asks to confirm, second click commits. The offer details are on the row label."}
execute as @e[type=interaction,tag=ec.ExBuy7,distance=..20] if data entity @s interaction if score @s adv.gui_session = @p[tag=ec.InFountain,distance=..20] adv.gui_session run data remove entity @s interaction
execute as @e[type=interaction,tag=ec.ExBuy8,distance=..20] if data entity @s attack if score @s adv.gui_session = @p[tag=ec.InFountain,distance=..20] adv.gui_session on attacker run function evercraft:gui/inspect/card {t:"Eighth Exchange Offer",b:"Right-click the exchange offer in row 8 — first click asks to confirm, second click commits. The offer details are on the row label."}
execute as @e[type=interaction,tag=ec.ExBuy8,distance=..20] if data entity @s interaction if score @s adv.gui_session = @p[tag=ec.InFountain,distance=..20] adv.gui_session run data remove entity @s interaction
