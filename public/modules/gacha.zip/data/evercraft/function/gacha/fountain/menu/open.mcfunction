# Open the Fountain pull menu
# Runs as @s = player, at @s (player position)
# Uses Pet Menu V2 pattern: text_display + interaction entities with billboard:"center"

# Toggle — if already in fountain menu, close instead
execute if entity @s[tag=ec.InFountain] run return run function evercraft:gacha/fountain/menu/close

# Menu Core: Y-displacement close anchor
# One-menu-at-a-time (2026-06-15): close any other open menu before this one claims
# ec.menu_active. Two overlapping menus share the @s adv.gui_session slot; the newer
# open orphans the older menu's session, so it can never consume its click -> stuck
# interaction NBT -> click-sound spam. force_close is idempotent (no-op when nothing open).
execute if entity @s[tag=ec.menu_active] run function evercraft:menu_core/force_close
tag @s add ec.menu_active
execute store result score @s ec.menu_open_y run data get entity @s Pos[1] 100
# Sneak-position polish (MP-P3.5): when crouching, lower spawn anchor by 0.20m so
# menu sits at a comfortable view-angle for the lowered eye height. Tag is read by
# every summon line below (paired unless/if) and removed at end-of-file.
tag @s remove ec.menu_sneak_open
execute if predicate evercraft:player_crouching run tag @s add ec.menu_sneak_open


# Tag player
tag @s add ec.InFountain

# Hide fountain label while menu is open
execute as @e[type=text_display,tag=ec.fountain_label,distance=..5] run data modify entity @s text set value {text:""}

# Disable fountain interaction to prevent overlap with menu buttons
execute as @e[type=interaction,tag=ec.fountain_click,distance=..5] run data modify entity @s height set value 0.0f

# Initialize inactivity timer
scoreboard players set @s ec.gf_idle 0

# Generate unique session ID for multiplayer isolation
scoreboard players add #gui_session ec.var 1
scoreboard players operation @s adv.gui_session = #gui_session ec.var

# Spawn menu in front of player (player-relative coordinates)
# Background panel (centered at ^2.05 ^1.8, scale 2.6 tall)
execute unless entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^ ^2.05 ^1.8 run summon item_display ~ ~ ~ {Tags:["ec.FountainMenu","ec.FountainElement"],billboard:"center",item:{id:"black_stained_glass_pane",count:1},item_display:"fixed",transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,-0.02f],scale:[3.0f,2.6f,0.01f]}}
execute if entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^ ^1.85 ^1.8 run summon item_display ~ ~ ~ {Tags:["ec.FountainMenu","ec.FountainElement"],billboard:"center",item:{id:"black_stained_glass_pane",count:1},item_display:"fixed",transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,-0.02f],scale:[3.0f,2.6f,0.01f]}}

# Title
# Ownership-header label (MP-P3.6): foreign viewers see whose menu this is
# 26.1: {selector:} renders blank in text_display — bake @s's name to a $(owner) literal.
function evercraft:util/gui/owner_name
execute rotated ~ 0 positioned ^ ^2.93 ^1.78 run function evercraft:gacha/fountain/menu/open_nm with storage evercraft:scorebake args
execute unless entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^ ^2.75 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["ec.FountainMenu","ec.FountainElement"],billboard:"center",text:{text:"\u2726 Fountain of Eternal Dreams \u2726",color:"#E0B0FF",bold:true},background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.675f,0.675f,0.675f]}}
execute if entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^ ^2.55 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["ec.FountainMenu","ec.FountainElement"],billboard:"center",text:{text:"\u2726 Fountain of Eternal Dreams \u2726",color:"#E0B0FF",bold:true},background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.675f,0.675f,0.675f]}}

# Balance check button
execute unless entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^ ^2.55 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["ec.FountainMenu","ec.FountainElement"],billboard:"center",text:{text:"[Balance & Fortune]",color:"#E0B0FF"},background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.405f,0.405f,0.405f]}}
execute if entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^ ^2.35 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["ec.FountainMenu","ec.FountainElement"],billboard:"center",text:{text:"[Balance & Fortune]",color:"#E0B0FF"},background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.405f,0.405f,0.405f]}}
execute unless entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^ ^2.48 ^1.8 run summon interaction ~ ~ ~ {Tags:["ec.FountainMenu","ec.FountainElement","ec.FountainClickBalance"],width:0.21f,height:0.14f,response:1b}
execute if entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^ ^2.28 ^1.8 run summon interaction ~ ~ ~ {Tags:["ec.FountainMenu","ec.FountainElement","ec.FountainClickBalance"],width:0.21f,height:0.14f,response:1b}

# === INFO [?] BUTTON (below balance) ===
execute unless entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^ ^2.4 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["ec.FountainMenu","ec.FountainElement"],billboard:"center",text:{text:"[? Chances & Mercy]",color:"aqua"},background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.338f,0.338f,0.338f]}}
execute if entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^ ^2.2 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["ec.FountainMenu","ec.FountainElement"],billboard:"center",text:{text:"[? Chances & Mercy]",color:"aqua"},background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.338f,0.338f,0.338f]}}
execute unless entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^ ^2.33 ^1.8 run summon interaction ~ ~ ~ {Tags:["ec.FountainMenu","ec.FountainElement","ec.FountainClickInfo"],width:0.23f,height:0.14f,response:1b}
execute if entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^ ^2.13 ^1.8 run summon interaction ~ ~ ~ {Tags:["ec.FountainMenu","ec.FountainElement","ec.FountainClickInfo"],width:0.23f,height:0.14f,response:1b}

# === PULL x1 BUTTON ===
execute unless entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^ ^2.25 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["ec.FountainMenu","ec.FountainElement","ec.FountainBtn1"],billboard:"center",text:{text:"\u2726 Pull x1 (5 Coins) \u2726",color:"light_purple",bold:true},background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.513f,0.513f,0.513f]}}
execute if entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^ ^2.05 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["ec.FountainMenu","ec.FountainElement","ec.FountainBtn1"],billboard:"center",text:{text:"\u2726 Pull x1 (5 Coins) \u2726",color:"light_purple",bold:true},background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.513f,0.513f,0.513f]}}
execute unless entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^ ^2.18 ^1.8 run summon interaction ~ ~ ~ {Tags:["ec.FountainMenu","ec.FountainElement","ec.FountainClick1"],width:0.23f,height:0.14f,response:1b}
execute if entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^ ^1.98 ^1.8 run summon interaction ~ ~ ~ {Tags:["ec.FountainMenu","ec.FountainElement","ec.FountainClick1"],width:0.23f,height:0.14f,response:1b}

# === FREE WISH INDICATOR (only when one or more daily gifts are waiting) ===
# "A gift that waits" — wholesome, FOMO-free: no countdown, just a quiet note that
# the next Pull x1 spends a saved wish instead of coins. Hidden entirely when none.

# === PULL x10 BUTTON ===
execute unless entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^ ^1.9 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["ec.FountainMenu","ec.FountainElement","ec.FountainBtn10"],billboard:"center",text:{text:"\u2726 Pull x10 (50 Coins) \u2726",color:"gold",bold:true},background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.513f,0.513f,0.513f]}}
execute if entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^ ^1.7 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["ec.FountainMenu","ec.FountainElement","ec.FountainBtn10"],billboard:"center",text:{text:"\u2726 Pull x10 (50 Coins) \u2726",color:"gold",bold:true},background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.513f,0.513f,0.513f]}}
execute unless entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^ ^1.92 ^1.8 run summon interaction ~ ~ ~ {Tags:["ec.FountainMenu","ec.FountainElement","ec.FountainClick10"],width:0.23f,height:0.12f,response:1b}
execute if entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^ ^1.72 ^1.8 run summon interaction ~ ~ ~ {Tags:["ec.FountainMenu","ec.FountainElement","ec.FountainClick10"],width:0.23f,height:0.12f,response:1b}

# === CONVERGENCE ABUNDANCE BANNER (P3-6) ===
# When the Convergence of Dreams runs, coin pulls drop to 3/30 (try_pull_animated:22 /
# try_pull_10_animated) and the dust shop halves too. The Pull buttons above still show
# base prices, so this banner is how the player learns wishes cost less right now.
# Wholesome, in-voice, gated on the flag — NOT a countdown. Hidden entirely when off.
execute if score #gacha_convergence ec.var matches 1 unless entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^ ^1.73 ^1.785 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["ec.FountainMenu","ec.FountainElement"],billboard:"center",text:["",{text:"✦ ",color:"#E0B0FF"},{text:"The Convergence is upon us — wishes cost less.",color:"#E0B0FF",italic:true}],background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.27f,0.27f,0.27f]}}
execute if score #gacha_convergence ec.var matches 1 if entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^ ^1.53 ^1.785 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["ec.FountainMenu","ec.FountainElement"],billboard:"center",text:["",{text:"✦ ",color:"#E0B0FF"},{text:"The Convergence is upon us — wishes cost less.",color:"#E0B0FF",italic:true}],background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.27f,0.27f,0.27f]}}

# === LUCID CLAIM BUTTON ===
# Foreshadow the claim cost on the button (P3-5) so the player sees the wall BEFORE
# clicking, and watches it shrink after their first claim (400 -> 250 is a satisfying,
# visible reward). The ramp (400/250/125/75/50) mirrors spark/gui/grant:10-14, keyed off
# ec.spark_claims. The cost is baked into the label as a LITERAL per claim-count (one
# branch each) rather than a live {score} component, because #spark_cost ec.var is a
# global (#) scratch shared with spark/check + spark/gui/* \u2014 a live ref could render
# another player's cost while this menu sits open (multiplayer-safe by baking). The
# player's own banked lucidity (@s ec.wish_spark) stays a live component (player-scoped).
# Bake the cost literal per ec.spark_claims band (default 50 covers 4th+ claim).
# === 26.1 fix: {score} blank in text_display -> bake via storage macro ===
scoreboard players add @s ec.free_pulls 0
execute store result storage evercraft:scorebake args.v1 int 1 run scoreboard players get @s ec.free_pulls
scoreboard players add @s ec.wish_spark 0
execute store result storage evercraft:scorebake args.v2 int 1 run scoreboard players get @s ec.wish_spark
function evercraft:gacha/fountain/menu/open_dyn with storage evercraft:scorebake args
execute unless entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^ ^1.57 ^1.8 run summon interaction ~ ~ ~ {Tags:["ec.FountainMenu","ec.FountainElement","ec.FountainClickSpark"],width:0.23f,height:0.12f,response:1b}
execute if entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^ ^1.37 ^1.8 run summon interaction ~ ~ ~ {Tags:["ec.FountainMenu","ec.FountainElement","ec.FountainClickSpark"],width:0.23f,height:0.12f,response:1b}

# === DREAMDUST EXCHANGE BUTTON ===
execute unless entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^ ^1.2 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["ec.FountainMenu","ec.FountainElement","ec.FountainBtnExchange"],billboard:"center",text:{text:"\u25C6 Dreamdust Exchange \u25C6",color:"#E0B0FF"},background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.473f,0.473f,0.473f]}}
execute if entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^ ^1 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["ec.FountainMenu","ec.FountainElement","ec.FountainBtnExchange"],billboard:"center",text:{text:"\u25C6 Dreamdust Exchange \u25C6",color:"#E0B0FF"},background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.473f,0.473f,0.473f]}}
execute unless entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^ ^1.22 ^1.8 run summon interaction ~ ~ ~ {Tags:["ec.FountainMenu","ec.FountainElement","ec.FountainClickExchange"],width:0.23f,height:0.12f,response:1b}
execute if entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^ ^1.02 ^1.8 run summon interaction ~ ~ ~ {Tags:["ec.FountainMenu","ec.FountainElement","ec.FountainClickExchange"],width:0.23f,height:0.12f,response:1b}

# === CLOSE BUTTON ===
execute unless entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^ ^0.85 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["ec.FountainMenu","ec.FountainElement","ec.FountainBtnClose"],billboard:"center",text:{text:"[Close]",color:"red"},background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.405f,0.405f,0.405f]}}
execute if entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^ ^0.65 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["ec.FountainMenu","ec.FountainElement","ec.FountainBtnClose"],billboard:"center",text:{text:"[Close]",color:"red"},background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.405f,0.405f,0.405f]}}
execute unless entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^ ^0.87 ^1.8 run summon interaction ~ ~ ~ {Tags:["ec.FountainMenu","ec.FountainElement","ec.FountainClickClose"],width:0.16f,height:0.1f,response:1b}
execute if entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^ ^0.67 ^1.8 run summon interaction ~ ~ ~ {Tags:["ec.FountainMenu","ec.FountainElement","ec.FountainClickClose"],width:0.16f,height:0.1f,response:1b}

# Stamp session
execute as @e[type=item_display,tag=ec.FountainMenu,distance=..5] unless score @s adv.gui_session matches 1.. run scoreboard players operation @s adv.gui_session = #gui_session ec.var
execute as @e[type=text_display,tag=ec.FountainMenu,distance=..5] unless score @s adv.gui_session matches 1.. run scoreboard players operation @s adv.gui_session = #gui_session ec.var
execute as @e[type=interaction,tag=ec.FountainMenu,distance=..5] unless score @s adv.gui_session matches 1.. run scoreboard players operation @s adv.gui_session = #gui_session ec.var

execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.enchantment_table.use master @s ~ ~ ~ 0.5 1.2

# Sneak-position polish cleanup
tag @s remove ec.menu_sneak_open
