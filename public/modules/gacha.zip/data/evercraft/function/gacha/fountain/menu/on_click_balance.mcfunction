# Fountain menu — Check Balance clicked
# Runs as @s = the verified clicker (dispatched on target from check_clicks)
# Shows the live currency balance, then surfaces the mercy (pity + spark progress)
# so a player never needs an external wiki to read their guarantees.
data remove entity @s interaction
tellraw @s [{text:"✦ ",color:"#E0B0FF"},{text:"Balance: ",color:"gray"},{"score":{"name":"@s","objective":"ec.coins"},color:"gold"},{text:" Coins",color:"gold"},{text:" | ",color:"dark_gray"},{"score":{"name":"@s","objective":"ec.dreamdust"},color:"light_purple"},{text:" Dreamdust",color:"light_purple"},{text:" | ",color:"dark_gray"},{"score":{"name":"@s","objective":"ec.wish_spark"},color:"aqua"},{text:" Lucidity",color:"aqua"},{text:" ✦",color:"#E0B0FF"}]
function evercraft:gacha/fountain/menu/show_mercy
