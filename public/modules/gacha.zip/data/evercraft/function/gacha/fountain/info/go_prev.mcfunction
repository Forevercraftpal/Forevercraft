# Go to previous page
# Runs as interaction entity

data remove entity @s interaction

# Don't go below page 1
execute as @p[tag=ec.InGachaInfo,distance=..5] if score @s ec.gacha_page matches 1 run return 0

# Decrement page
execute as @p[tag=ec.InGachaInfo,distance=..5] run scoreboard players remove @s ec.gacha_page 1

# Refresh
execute as @p[tag=ec.InGachaInfo,distance=..5] at @s run function evercraft:gacha/fountain/info/refresh_page

playsound minecraft:block.note_block.hat master @p[tag=ec.InGachaInfo,distance=..5,scores={ec.fx_snd=1..}] ~ ~ ~ 0.3 1.6
