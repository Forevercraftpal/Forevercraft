# Fountain — Wash Block (right-click with water bucket)
# Removes dye and restores default appearance
# Run as: player, at: interaction entity position

# Reset marker color to default
execute as @e[type=marker,tag=ec.fountain,distance=..3,limit=1] run data modify entity @s data.color set value "fountain"

# Reset text_display label to default color
execute as @e[type=text_display,tag=ec.fountain_label,distance=..3,limit=1] run data modify entity @s text set value {text:"\u2726 Fountain of Eternal Dreams \u2726",color:"#E0B0FF",bold:true}

# Effects
playsound minecraft:item.bucket.empty master @a[distance=..16,scores={ec.fx_snd=1..}] ~ ~ ~ 1 1.2
particle minecraft:splash ~0.5 ~1.0 ~0.5 0.3 0.2 0.3 0.05 12

# Feedback
data modify storage evercraft:notify stage.c set value [{text:"Washed ",color:"gray",italic:true},{text:"Fountain",color:"#E0B0FF",italic:true},{text:" back to default",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
