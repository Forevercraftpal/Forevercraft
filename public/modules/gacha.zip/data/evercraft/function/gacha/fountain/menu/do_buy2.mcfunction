# Exchange buy: Companion Treat for 10 Dreamdust
# Runs as @s = player
# Compute the effective cost (set_cost halves it during Convergence of Dreams) into #ddcost ec.temp.
function evercraft:gacha/exchange/buy/set_cost {base:10}
execute unless score @s ec.dreamdust >= #ddcost ec.temp run data modify storage evercraft:notify stage.c set value [{text:"\u25C6 ",color:"gray"},{text:"Not enough Dreamdust! Need ",color:"red"},{score:{name:"#ddcost",objective:"ec.temp"},color:"red"},{text:".",color:"red"},{text:" \u25C6",color:"gray"}]
execute unless score @s ec.dreamdust >= #ddcost ec.temp run scoreboard players set #ndur ec.temp 45
execute unless score @s ec.dreamdust >= #ddcost ec.temp run return run function evercraft:util/notify/emit
scoreboard players operation @s ec.dreamdust -= #ddcost ec.temp
# Inv-full guard: drop at the player's feet rather than void on a full inventory.
execute store result score #inv_full ec.var run function evercraft:util/check_inv_full
execute if score #inv_full ec.var matches 0 run loot give @s loot evercraft:companions/items/companion_treat
execute if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:companions/items/companion_treat
data modify storage evercraft:notify stage.c set value [{text:"\u25C6 ",color:"#E0B0FF"},{text:"Purchased ",color:"gray"},{text:"Companion Treat",color:"gold"},{text:"!",color:"gray"},{text:" \u25C6",color:"#E0B0FF"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.experience_orb.pickup master @s ~ ~ ~ 0.5 1.3
