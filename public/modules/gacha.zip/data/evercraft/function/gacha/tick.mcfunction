# Gacha system tick — Fountain interaction detection + menu ticks
# Called from main tick.mcfunction (existence-gated)

# Fountain break detection (player_head removed → clean up entities, drop item)
execute as @e[type=marker,tag=ec.fountain] at @s unless block ~ ~ ~ minecraft:player_head unless block ~ ~ ~ minecraft:player_wall_head run function evercraft:gacha/fountain/on_break

# Fountain interaction detection (right-click on fountain interaction entities)
execute as @e[type=interaction,tag=ec.fountain_click] if data entity @s interaction at @s run function evercraft:gacha/fountain/interact
execute as @e[type=interaction,tag=ec.fountain_click] if data entity @s interaction at @s run data remove entity @s interaction

# Menu tick for players in fountain menu (skip during reel animation)
execute as @a[tag=ec.InFountain] unless score @s ec.reel_tick matches 0.. at @s run function evercraft:gacha/fountain/menu/check_clicks
execute as @a[tag=ec.InFountain] unless score @s ec.reel_tick matches 0.. at @s run function evercraft:gacha/fountain/menu/tick

# Reel animation tick (for players with active reel)
execute as @a[tag=ec.InFountain,scores={ec.reel_tick=0..}] at @s run function evercraft:gacha/reel/tick

# Skip button click detection (during reel). Dispatch on target so the skip runs as
# the verified clicker (matches the menu check_clicks pattern) — never a proximity-
# resolved @p, which could skip a co-located player's reel in a shared fountain.
execute as @e[type=interaction,tag=ec.ReelSkipClick] if data entity @s interaction on target run function evercraft:gacha/reel/on_skip_click
execute as @e[type=interaction,tag=ec.ReelSkipClick] if data entity @s interaction run data remove entity @s interaction

# Info browser tick
execute as @a[tag=ec.InGachaInfo] at @s run function evercraft:gacha/fountain/info/tick

# Spark trigger — RETIRED 2026-05-29. The Lucid Claim now runs through the single
# canonical GUI path (fountain menu → spark/gui/open → spark/gui/grant), which owns
# the 400/250/125/75/50 ramp. The old /trigger ec.spark path (spark/claim) is a dead
# second grant path and is deliberately no longer dispatched. The trigger is still
# reset here so a stray /trigger ec.spark set N can never silently accumulate.
execute as @a[scores={ec.spark=1..}] run scoreboard players set @s ec.spark 0

# Dreamdust Exchange trigger — RETIRED 2026-06-05 (Wiring #39 park). The GUI exchange
# (fountain menu → ex_buy1-8 → confirm → do_buy1-8) is the canonical path and grants the
# identical 8 trades. The old /trigger ec.ddex path (exchange/buy/process) was a redundant
# second grant path (GUI-only law) and is no longer dispatched. Mirroring the ec.spark
# retirement above, the trigger is still RESET here so a stray /trigger ec.ddex set N can
# never silently accumulate.
execute as @a[scores={ec.ddex=1..}] run scoreboard players set @s ec.ddex 0
