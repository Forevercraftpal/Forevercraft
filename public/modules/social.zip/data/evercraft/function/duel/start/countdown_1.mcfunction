# Duel Countdown — "1..."

execute unless score #duel_active ec.var matches 1 run return 0

title @a[tag=ec.duel_active_tag] times 0 25 5
title @a[tag=ec.duel_active_tag] title {text:"1",color:"yellow"}
# Countdown tick (per-listener gated bespoke FX — was: playsound note_block.hat @a[duel])
scoreboard players set #duel_count ec.temp 1
function evercraft:fx/companion/duel_count

schedule function evercraft:duel/start/countdown_go 20t
