# Duel Countdown — "FIGHT!"

execute unless score #duel_active ec.var matches 1 run return 0

title @a[tag=ec.duel_active_tag] times 0 30 10
title @a[tag=ec.duel_active_tag] title {text:"FIGHT!",color:"green"}
# The gate-drop "begin" (per-listener gated bespoke FX — REPLACES entity.ender_dragon.growl)
function evercraft:fx/companion/duel_go

# Remove Resistance — fight begins
effect clear @a[tag=ec.duel_active_tag] minecraft:resistance
effect clear @a[tag=ec.duel_active_tag] minecraft:blindness
