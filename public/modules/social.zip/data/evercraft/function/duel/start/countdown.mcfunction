# Duel Countdown — "3..."
# Runs immediately when duel starts

title @a[tag=ec.duel_active_tag] times 0 25 5
title @a[tag=ec.duel_active_tag] title {text:"3",color:"red"}
# Countdown tick (per-listener gated bespoke FX — was: playsound note_block.hat @a[duel])
scoreboard players set #duel_count ec.temp 3
function evercraft:fx/companion/duel_count

schedule function evercraft:duel/start/countdown_2 20t
