# Duel Spectate — Teleport (runs as the spectating player)

# Check duel is active and arena mode
data modify storage evercraft:notify stage.c set value [{text:"No active duel to watch!",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute unless score #duel_active ec.var matches 1 run return run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"This is an open world duel — no arena to spectate!",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute unless entity @a[tag=ec.duel_active_tag,scores={ec.duel_mode=2}] run return run function evercraft:util/notify/emit

# Block if already a duelist
data modify storage evercraft:notify stage.c set value [{text:"You are in the duel!",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute if entity @s[tag=ec.duel_active_tag] run return run function evercraft:util/notify/emit

# Block if already spectating
data modify storage evercraft:notify stage.c set value [{text:"You are already spectating!",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute if entity @s[tag=ec.duel_spectator] run return run function evercraft:util/notify/emit

# Verify arena center marker exists
data modify storage evercraft:notify stage.c set value [{text:"Arena not found!",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute unless entity @e[type=marker,tag=duel.center,limit=1] run return run function evercraft:util/notify/emit

# Save spectator's return position
execute at @s run summon marker ~ ~ ~ {Tags:["duel.spec_return","duel.spec_new"]}
# Store player's scoreboard ID on the return marker for identification
execute store result score @e[type=marker,tag=duel.spec_new,limit=1] ec.temp run scoreboard players get @s ec.temp
tag @e[type=marker,tag=duel.spec_new] remove duel.spec_new
tag @s add ec.duel_spectator

# Set gamemode spectator
gamemode spectator @s

# Teleport to arena stands area (offset from center)
execute at @e[type=marker,tag=duel.center,limit=1] run tp @s ~0 ~5 ~-13

data modify storage evercraft:notify stage.c set value [{text:"You are now spectating the duel!",color:"aqua"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
# Spectator arrival whoosh (gated)
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.enderman.teleport master @s ~ ~ ~ 0.5 1.2
