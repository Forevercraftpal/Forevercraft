# First-to-X Duel — Tick (called from active/tick when mode=6)
# Check each duelist's health for "kill" detection

# Simultaneous double-KO (#50 W4): if BOTH non-respawning duelists are at <=2 HP THIS tick, the
# per-player check_health->on_kill below would award the kill order-dependently (whoever @a visits
# first). Count critically-wounded duelists up front; if 2, CANCEL the round (credit neither, respawn
# both) — mirrors pet_duel PD-4 — and skip the per-player health pass this tick so neither on_kill runs.
scoreboard players set #ftx_crit ec.temp 0
execute as @a[tag=ec.duel_active_tag,tag=!duel.ftx_respawning] run function evercraft:duel/ftx/count_critical
execute if score #ftx_crit ec.temp matches 2.. run return run function evercraft:duel/ftx/double_ko

execute as @a[tag=ec.duel_active_tag,tag=!duel.ftx_respawning] run function evercraft:duel/ftx/check_health

# Update bossbar with leading player's kills
function evercraft:duel/ftx/update_bossbar

# Disconnect check
scoreboard players set #ftx_online ec.temp 0
execute as @a[tag=ec.duel_active_tag] run scoreboard players add #ftx_online ec.temp 1
execute if score #ftx_online ec.temp matches ..1 run function evercraft:duel/ftx/forfeit_disconnect
