# First-to-X — Win (runs as the winner)
# Tag roles
tag @s add duel.winner
execute as @a[tag=ec.duel_active_tag,tag=!duel.winner] run tag @s add duel.loser

# Winner rewards (same as regular duel)
function evercraft:duel/end/winner

# Loser penalties
execute as @a[tag=duel.loser] run effect give @s minecraft:darkness 7 0 false
execute as @a[tag=duel.loser] run effect give @s minecraft:nausea 7 0 false
execute as @a[tag=duel.loser] run effect give @s minecraft:mining_fatigue 3600 0 false
execute as @a[tag=duel.loser] run effect give @s minecraft:weakness 3600 0 false
execute as @a[tag=duel.loser] run scoreboard players add @s ec.duel_today 1
execute as @a[tag=duel.loser] run title @s times 5 40 15
execute as @a[tag=duel.loser] run title @s title {text:"DEFEATED",color:"red",bold:true}
execute as @a[tag=duel.loser] run title @s subtitle {text:"Better luck next time!",color:"gray"}

# Defeat knell for the loser (gated bespoke FX — the chord falling)
execute as @a[tag=duel.loser] at @s run function evercraft:fx/companion/duel_lose

# Announce final score
# (Wave 2, 2026-06-10: rides the queue — winner name via whoami, both kill counts baked via stage_text.)
function evercraft:util/notify/whoami
data modify storage evercraft:notify stage.c set value [{text:"First-to-X Duel over! ",color:"yellow"},{text:"",color:"green"},{text:" wins ",color:"yellow"},{text:"",color:"white"},{text:" - ",color:"gray"},{text:"",color:"white"},{text:"!",color:"yellow"}]
data modify storage evercraft:notify stage.c[1].text set from storage evercraft:notify named.who
execute store result storage evercraft:notify named.v int 1 run scoreboard players get @s ec.duel_kills
data modify storage evercraft:notify named.i set value 3
function evercraft:util/notify/stage_text with storage evercraft:notify named
execute store result storage evercraft:notify named.v int 1 run scoreboard players get @a[tag=duel.loser,limit=1] ec.duel_kills
data modify storage evercraft:notify named.i set value 5
function evercraft:util/notify/stage_text with storage evercraft:notify named
scoreboard players set #ndur ec.temp 50
execute as @a run scoreboard players set #nttl ec.temp 300
execute as @a run function evercraft:util/notify/emit

# Realm News
scoreboard players add #news_duels ec.var 1

# Milestone
function evercraft:milestones/increment/duel_complete

# Cleanup
function evercraft:duel/ftx/cleanup
