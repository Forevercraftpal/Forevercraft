# First-to-X — Count Critical (#50 W4, runs as each non-respawning duelist)
# Adds 1 to #ftx_crit ec.temp if this duelist is at <=2 HP (1 heart). Mirrors check_health's read.
# Caller (ftx/tick) zeroes #ftx_crit before the @a dispatch; reads it after to detect a same-tick
# simultaneous double-KO (#ftx_crit==2).
execute store result score #ftx_hp ec.temp run data get entity @s Health 1
execute if score #ftx_hp ec.temp matches ..2 run scoreboard players add #ftx_crit ec.temp 1
