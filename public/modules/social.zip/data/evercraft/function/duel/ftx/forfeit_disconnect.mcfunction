# First-to-X — Forfeit/Disconnect
# Not enough players online

# If one player remains, they win
execute if entity @a[tag=ec.duel_active_tag,limit=1] as @a[tag=ec.duel_active_tag,limit=1] run tag @s add duel.winner
execute if entity @a[tag=duel.winner] run function evercraft:duel/end/winner
# (Wave 2, 2026-06-10: rides the queue — winner name baked via whoami run as the tagged winner.)
execute if entity @a[tag=duel.winner] as @a[tag=duel.winner,limit=1] run function evercraft:util/notify/whoami
data modify storage evercraft:notify stage.c set value [{text:"",color:"green"},{text:" wins by forfeit!",color:"yellow"}]
data modify storage evercraft:notify stage.c[0].text set from storage evercraft:notify named.who
scoreboard players set #ndur ec.temp 45
execute if entity @a[tag=duel.winner] as @a run scoreboard players set #nttl ec.temp 300
execute if entity @a[tag=duel.winner] as @a run function evercraft:util/notify/emit

# If nobody remains
data modify storage evercraft:notify stage.c set value [{text:"First-to-X duel ended — both players disconnected.",color:"gray"}]
scoreboard players set #ndur ec.temp 50
execute unless entity @a[tag=ec.duel_active_tag] as @a run function evercraft:util/notify/emit

scoreboard players add #news_duels ec.var 1
function evercraft:duel/ftx/cleanup
