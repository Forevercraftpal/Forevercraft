# First-to-X — Simultaneous Double-KO (#50 W4)
# Both duelists dropped to <=2 HP on the SAME tick. Mirrors pet_duel's PD-4 "neither prevails" rule:
# rather than letting @a iteration order arbitrarily award the kill (the order-dependent mis-credit the
# correctness/race seats flagged), CANCEL the round — credit NEITHER, increment NEITHER's score, respawn
# BOTH to their spawn sides. The first-to-N match simply continues, so this needs no match-level "draw"
# award decision. Called from ftx/tick BEFORE the per-player check_health dispatch when exactly two
# non-respawning duelists are at <=2 HP.

# Totem animation + survival heal for BOTH (no death, no kill credit). Totem particle kept;
# the totem.use + note_block.bass sounds fold into the duel_doubleko two-tone below.
effect give @a[tag=ec.duel_active_tag] minecraft:instant_health 1 5 true
effect give @a[tag=ec.duel_active_tag] minecraft:resistance 3 4 true
particle minecraft:totem_of_undying ~ ~1 ~ 0.5 1 0.5 0.5 50

# Announce the cancelled round (no score change — scores echoed for clarity)
data modify storage evercraft:notify stage.c set value [{text:"Double knockout! ",color:"yellow"},{text:"Round cancelled — no point awarded.",color:"gray"}]
scoreboard players set #ndur ec.temp 45
execute as @a[tag=ec.duel_active_tag] run scoreboard players set #nttl ec.temp 300
execute as @a[tag=ec.duel_active_tag] run function evercraft:util/notify/emit
# No-contest two-tone (per-listener gated bespoke FX — was: totem.use + note_block.bass @a[duel])
function evercraft:fx/companion/duel_doubleko

# Respawn each duelist to their own spawn side (challenger -> spawn_a, accepter -> spawn_b).
# Both are already full-healed above, so they pass next tick's check_health (no respawning-grace needed).
execute as @a[tag=ec.duel_active_tag,tag=duel.challenger_confirmed] at @e[type=marker,tag=duel.ftx_spawn_a,limit=1] run tp @s ~ ~ ~
execute as @a[tag=ec.duel_active_tag,tag=!duel.challenger_confirmed] at @e[type=marker,tag=duel.ftx_spawn_b,limit=1] run tp @s ~ ~ ~

# Top-off heal + saturation (same as on_kill respawn)
effect give @a[tag=ec.duel_active_tag] minecraft:instant_health 1 3 true
effect give @a[tag=ec.duel_active_tag] minecraft:saturation 1 5 true
