# First-to-X — On Kill (runs as the "killed" player)
# Save victim, heal, respawn, credit killer

# Prevent actual death
effect give @s minecraft:instant_health 1 5 true
effect give @s minecraft:resistance 3 4 true

# Totem animation (visual kept; the totem.use sound folds into the duel_ko impact below)
particle minecraft:totem_of_undying ~ ~1 ~ 0.5 1 0.5 0.5 50

# Tag self as victim to identify the killer (handles simultaneous kills correctly)
tag @s add duel.ftx_victim

# Credit the killer (the OTHER duelist — identified by NOT being the victim)
execute as @a[tag=ec.duel_active_tag,tag=!duel.ftx_victim] run scoreboard players add @s ec.duel_kills 1

# Lifetime duel-kills tally on the same killer (accumulates while the per-match ec.duel_kills resets).
execute as @a[tag=ec.duel_active_tag,tag=!duel.ftx_victim] run scoreboard players add @s ec.duel_kills_total 1

# Tag as respawning (skip health checks during respawn grace period)
tag @s add duel.ftx_respawning

# Increment round
execute as @a[tag=ec.duel_active_tag] run scoreboard players add @s ec.ftx_round 1

# Announce kill
# (Wave 2, 2026-06-10: rides the queue — killer name via whoami (run as the non-victim duelist),
# kill count + target baked via stage_text; 5s TTL keeps a mid-duel score from showing stale.)
execute as @a[tag=ec.duel_active_tag,tag=!duel.ftx_victim,limit=1] run function evercraft:util/notify/whoami
data modify storage evercraft:notify stage.c set value [{text:"",color:"green"},{text:" scored a kill! (",color:"yellow"},{text:"",color:"white"},{text:"/",color:"gray"},{text:"",color:"white"},{text:")",color:"yellow"}]
data modify storage evercraft:notify stage.c[0].text set from storage evercraft:notify named.who
execute store result storage evercraft:notify named.v int 1 run scoreboard players get @a[tag=ec.duel_active_tag,tag=!duel.ftx_victim,limit=1] ec.duel_kills
data modify storage evercraft:notify named.i set value 2
function evercraft:util/notify/stage_text with storage evercraft:notify named
execute store result storage evercraft:notify named.v int 1 run scoreboard players get @s ec.duel_target
data modify storage evercraft:notify named.i set value 4
function evercraft:util/notify/stage_text with storage evercraft:notify named
scoreboard players set #ndur ec.temp 45
execute as @a[tag=ec.duel_active_tag] run scoreboard players set #nttl ec.temp 100
execute as @a[tag=ec.duel_active_tag] run function evercraft:util/notify/emit
# KO impact (per-listener gated bespoke FX — was: totem.use + experience_orb.pickup @a[duel]).
# Pass the killer's First-to-N kill count so duel_ko's pip rises with progress.
scoreboard players set #duel_ko_pip ec.temp 0
execute as @a[tag=ec.duel_active_tag,tag=!duel.ftx_victim] run scoreboard players operation #duel_ko_pip ec.temp = @s ec.duel_kills
function evercraft:fx/companion/duel_ko

# Check if killer reached target
execute as @a[tag=ec.duel_active_tag,tag=!duel.ftx_victim] if score @s ec.duel_kills >= @s ec.duel_target run function evercraft:duel/ftx/win
# Bail if duel was resolved (win → cleanup sets #duel_active to 0)
execute unless score #duel_active ec.var matches 1 run return 0

# Clear victim tag
tag @s remove duel.ftx_victim

# Respawn victim: teleport back to their spawn side
# Challenger goes to spawn_a, accepter goes to spawn_b
execute if entity @s[tag=duel.challenger_confirmed] at @e[type=marker,tag=duel.ftx_spawn_a,limit=1] run tp @s ~ ~ ~
execute unless entity @s[tag=duel.challenger_confirmed] at @e[type=marker,tag=duel.ftx_spawn_b,limit=1] run tp @s ~ ~ ~

# Heal both players
effect give @a[tag=ec.duel_active_tag] minecraft:instant_health 1 3 true
effect give @a[tag=ec.duel_active_tag] minecraft:saturation 1 5 true

# Clear respawning tag after brief delay (use resistance duration as grace period)
# Remove immediately — the 3s resistance protects them
tag @s remove duel.ftx_respawning
