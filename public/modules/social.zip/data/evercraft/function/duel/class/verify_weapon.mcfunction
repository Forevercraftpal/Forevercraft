# Class Duel — Verify Weapon (runs as each duelist during class duel tick)
# Check if player still has the correct class weapon equipped
# Uses ec.aff_class which is set by affinity/detect_class every tick

# If player's current class matches required class, clear warn counter
execute if score @s ec.aff_class = @s ec.duel_class run scoreboard players set @s ec.duel_warn 0
execute if score @s ec.aff_class = @s ec.duel_class run return 0

# Wrong weapon equipped — increment warning counter
scoreboard players add @s ec.duel_warn 1

# Warning at 1 tick
data modify storage evercraft:notify stage.c set value [{text:"Re-equip your class weapon! 5 seconds to comply or forfeit!",color:"red",bold:true}]
scoreboard players set #ndur ec.temp 45
execute if score @s ec.duel_warn matches 1 run function evercraft:util/notify/emit
execute if score @s ec.duel_warn matches 1 if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.pling master @s ~ ~ ~ 1 0.5

# Forfeit at 100 ticks (5 seconds)
execute if score @s ec.duel_warn matches 100.. run function evercraft:util/notify/whoami
data modify storage evercraft:notify stage.c set value [{text:"",color:"red"},{text:" forfeited by switching weapons!",color:"yellow"}]
data modify storage evercraft:notify stage.c[0].text set from storage evercraft:notify named.who
scoreboard players set #ndur ec.temp 45
execute if score @s ec.duel_warn matches 100.. run execute as @a[tag=ec.duel_active_tag] run scoreboard players set #nttl ec.temp 300
execute if score @s ec.duel_warn matches 100.. run execute as @a[tag=ec.duel_active_tag] run function evercraft:util/notify/emit
execute if score @s ec.duel_warn matches 100.. run function evercraft:duel/active/forfeit
