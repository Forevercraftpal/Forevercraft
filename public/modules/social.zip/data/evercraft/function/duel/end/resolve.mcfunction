# Duel End — Resolve (called after winner/loser determined)
# Loser penalties already applied in totem_save or on_death
# Idempotency sentinel: 4 entry paths (on_death, disconnect, forfeit, totem_save) can fire
# in unusual sequences (totem+disconnect, forfeit+disconnect). Skip body if already
# resolved this duel. Cleared in evercraft:duel/end/cleanup.
execute if score #duel_resolved ec.var matches 1 run return 0
scoreboard players set #duel_resolved ec.var 1

# Realm News daily counter
scoreboard players add #news_duels ec.var 1

# Process winner
execute as @a[tag=duel.winner] run function evercraft:duel/end/winner

# Announce winner (1v1 only — moved here from duel/end/winner 2026-06-02 so the FTX/team/forfeit
# paths, which announce their own context line, don't double-broadcast this generic win line).
execute as @a[tag=duel.winner] run function evercraft:util/notify/whoami
data modify storage evercraft:notify stage.c set value [{text:"",color:"green",bold:true},{text:" has won the duel! (+5 Victorian Progress)",color:"yellow"}]
data modify storage evercraft:notify stage.c[0].text set from storage evercraft:notify named.who
scoreboard players set #ndur ec.temp 45
execute as @a[tag=duel.winner] run execute as @a run scoreboard players set #nttl ec.temp 300
execute as @a[tag=duel.winner] run execute as @a run function evercraft:util/notify/emit

# Announce loser (penalties already applied)
# (Wave 2, 2026-06-10: rides the queue — loser name baked via whoami run as the tagged loser.)
execute if entity @a[tag=duel.loser] as @a[tag=duel.loser,limit=1] run function evercraft:util/notify/whoami
data modify storage evercraft:notify stage.c set value [{text:"",color:"red"},{text:" has been bested in combat.",color:"gray"}]
data modify storage evercraft:notify stage.c[0].text set from storage evercraft:notify named.who
scoreboard players set #ndur ec.temp 45
execute if entity @a[tag=duel.loser] as @a run scoreboard players set #nttl ec.temp 300
execute if entity @a[tag=duel.loser] as @a run function evercraft:util/notify/emit

# Defeat knell for the loser (gated bespoke FX — the chord falling, counterpoint to duel_win)
execute as @a[tag=duel.loser] at @s run function evercraft:fx/companion/duel_lose

# Realm milestone: duel completed
function evercraft:milestones/increment/duel_complete

# Cleanup
function evercraft:duel/end/cleanup
