# Duel End — Winner Rewards (runs as the winner)

# +5 Victorian tree progress (stat_mobs = mob kills / combat stat)
scoreboard players add @s adv.stat_mobs 5

# Increment daily duel count
scoreboard players add @s ec.duel_today 1

# Spirit progression: lifetime duel wins (Pharaoh's Fist objective "Win 100 duels").
# Shared by every win path (1v1/FTX/team/forfeit) since all route through this sub-fn as @s.
scoreboard players add @s ec.sp_duel_wins 1

# Victory title
title @s times 5 40 15
title @s title {text:"VICTORY",color:"gold"}
title @s subtitle {text:"You won the duel!",color:"yellow"}

# Victory fanfare for the winner + a per-listener arena crowd swell (gated bespoke FX —
# REPLACES ui.toast.challenge_complete). Shared by every win path (1v1/FTX/team/forfeit).
execute at @s run function evercraft:fx/companion/duel_win

# NOTE: the server-wide "has won the duel!" action-bar broadcast was MOVED out of this shared
# sub-fn into duel/end/resolve (the 1v1 path) on 2026-06-02. The FTX, team, and forfeit
# orchestrators that also call winner each broadcast their OWN context line (final score / team
# names / "wins by forfeit"), so emitting here too produced 2–3 redundant win lines per occasion.

# Companion memory: Duelist's Glory
function evercraft:companions/memories/on_duel_win
