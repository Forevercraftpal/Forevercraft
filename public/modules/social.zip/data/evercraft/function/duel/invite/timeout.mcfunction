# Duel Invite — Timeout (runs as target whose invite expired)

scoreboard players set @s ec.duel_inv 0
scoreboard players set @s ec.duel_inv_cd 0
tag @s remove duel.pending_target

# Clean up challenger tag
tag @a[tag=duel.challenger] remove duel.challenger

data modify storage evercraft:notify stage.c set value [{text:"Duel invitation expired.",color:"gray"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
