# Duel Invite — Initiate (runs as challenger looking at another player while sneaking with sword)

# Block if already in a duel
data modify storage evercraft:notify stage.c set value [{text:"You are already in a duel!",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute if score @s ec.duel_active matches 1.. run return run function evercraft:util/notify/emit

# Block if in dreaming realm
data modify storage evercraft:notify stage.c set value [{text:"You cannot duel while in the Dreaming Realm!",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute if entity @s[tag=dr.in_realm] run return run function evercraft:util/notify/emit

# Block if in dungeon
data modify storage evercraft:notify stage.c set value [{text:"You cannot duel while in a dungeon!",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute if entity @s[tag=dg.player] run return run function evercraft:util/notify/emit

# Block if in any GUI menu
data modify storage evercraft:notify stage.c set value [{text:"Close your menu first!",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute if entity @s[tag=Adv.InMenu] run return run function evercraft:util/notify/emit
execute if entity @s[tag=TX.InMenu] run return run function evercraft:util/notify/emit
execute if entity @s[tag=RF.InMenu] run return run function evercraft:util/notify/emit
execute if entity @s[tag=HS.InMenu] run return run function evercraft:util/notify/emit
execute if entity @s[tag=DG.InMenu] run return run function evercraft:util/notify/emit

# Block if another duel is active
data modify storage evercraft:notify stage.c set value [{text:"Another duel is already in progress!",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute if score #duel_active ec.var matches 1.. run return run function evercraft:util/notify/emit

# Daily limit check — reset if new day
execute store result score #current_day ec.temp run time query minecraft:day repetition
execute unless score @s ec.duel_last_day = #current_day ec.temp run scoreboard players set @s ec.duel_today 0
scoreboard players operation @s ec.duel_last_day = #current_day ec.temp

# Block if at daily limit
data modify storage evercraft:notify stage.c set value [{text:"You have reached your daily duel limit (3/3)!",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute if score @s ec.duel_today matches 3.. run return run function evercraft:util/notify/emit

# Send invite to the raycast target (already tagged duel.ray_target by raycast/start)
# duel.challenger tag stays until invite is resolved (accept/decline/timeout)
tag @s add duel.challenger
execute as @a[tag=duel.ray_target,limit=1] run function evercraft:duel/invite/receive
