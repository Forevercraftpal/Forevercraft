# Duel Invite — Decline (runs as target who clicked [Decline] or auto-expired)

scoreboard players set @s ec.duel_inv 0
scoreboard players set @s ec.duel_inv_cd 0
tag @s remove duel.pending_target
scoreboard players set @s ec.duel 0

# Clean up challenger tag
tag @a[tag=duel.challenger] remove duel.challenger

data modify storage evercraft:notify stage.c set value [{text:"You declined the duel.",color:"gray"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit

# Notify all nearby players
function evercraft:util/notify/whoami
data modify storage evercraft:notify stage.c set value [{text:"",color:"aqua"},{text:" declined the duel challenge.",color:"gray"}]
data modify storage evercraft:notify stage.c[0].text set from storage evercraft:notify named.who
scoreboard players set #ndur ec.temp 45
execute as @a[distance=0..64] run scoreboard players set #nttl ec.temp 300
execute as @a[distance=0..64] run function evercraft:util/notify/emit
