# Duel Invite — Abort (challenger not found after accept)
# Runs as the target player who accepted but couldn't find challenger

tag @s remove ec.duel_active_tag
tag @s remove duel.pending_target
scoreboard players set @s ec.duel_active 0
scoreboard players set @s ec.duel_mode 0
scoreboard players set @s ec.duel_inv 0
scoreboard players set @s ec.duel_inv_cd 0

# Clean up challenger tag
tag @a[tag=duel.challenger] remove duel.challenger
tag @a[tag=duel.challenger_confirmed] remove duel.challenger_confirmed

# Release the global mutex (#50 W1) — abort fires only from a failed accept (open/arena) that already
# claimed #duel_active; releasing it here ensures a failed accept can't wedge the duel lock server-wide.
scoreboard players set #duel_active ec.var 0

data modify storage evercraft:notify stage.c set value [{text:"Could not find the challenger! Duel cancelled.",color:"red"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
