# Duel — Orphan Sweep (#50 W3, mirrors dreaming_realm #49)
# Context: server (no @s — the duelists are offline; that is the whole point).
#
# Safety net for the global #duel_active lock. The duel system normally self-heals an all-offline
# duel within one tick: active/tick (driven every tick while #duel_active=1) falls through to the
# disconnect handler when #duelist_count<=1, which resolves + end/cleanup releases the lock. And a
# returning duelist is recovered fast by reconnect/dispatch:10 -> crash_recovery. This sweep is the
# defense-in-depth reclaim for the pathological case where neither fires (e.g. active/tick's chain is
# ever interrupted): when the lock is held but NO online duelist exists, a grace counter advances in
# tick.mcfunction; at ~30s (600t at the 1t duel cadence — comfortably longer than any relogin, so
# crash_recovery always wins the race for a returning player) this runs to release the lock + tear
# down the arena. The counter resets every tick an online duelist exists, so a live duel never trips.

# Reset the grace counter so the next duel starts clean.
scoreboard players set #duel_orphan ec.var 0

# Log the reclaim (ops only — quiet for normal players).
execute as @a[tag=ec.admin] run tellraw @s [{text:"[Duel] ",color:"gold"},{text:"Orphaned duel lock reclaimed — all duelists disconnected and none returned within 30s. Duels are open again.",color:"gray",italic:true}]

# Full teardown: end/cleanup releases #duel_active, restores teams, removes tags, destroys the arena,
# removes the FTX bossbar, and kills every duel marker. Its @a/@s-targeted lines no-op with no online
# duelist; only the global teardown takes effect (mirrors dreaming_realm/exit/orphan_sweep).
function evercraft:duel/end/cleanup
