$# Team Duel — Resolve Win (winning_team=$(winning_team))
# Tag winners and losers based on team number

$execute as @a[tag=ec.duel_active_tag] if score @s ec.duel_team_num matches $(winning_team) run tag @s add duel.winner
$execute as @a[tag=ec.duel_active_tag] unless score @s ec.duel_team_num matches $(winning_team) run tag @s add duel.loser

# Restore eliminated players from spectator
execute as @a[tag=duel.eliminated] run gamemode survival @s

# Winner rewards (same as regular duel — +5 Victorian each)
execute as @a[tag=duel.winner] run function evercraft:duel/end/winner

# Loser penalties (lighter for team duel — just darkness + nausea)
execute as @a[tag=duel.loser] run effect give @s minecraft:darkness 7 0 false
execute as @a[tag=duel.loser] run effect give @s minecraft:nausea 7 0 false
execute as @a[tag=duel.loser] run title @s times 5 40 15
execute as @a[tag=duel.loser] run title @s title {text:"DEFEATED",color:"red",bold:true}
execute as @a[tag=duel.loser] run title @s subtitle {text:"Your team was eliminated!",color:"gray"}
execute as @a[tag=duel.loser] run scoreboard players add @s ec.duel_today 1

# Defeat knell for each loser (gated bespoke FX — the chord falling)
execute as @a[tag=duel.loser] at @s run function evercraft:fx/companion/duel_lose

# Realm News
scoreboard players add #news_duels ec.var 1

# Announce (show winner names)
# (AB-3, 2026-06-10: winning duo rides the queue — names ", "-joined via who_begin/who_add.
# Replaces the earlier deliberate §5b raw keep.)
function evercraft:util/notify/who_begin
execute as @a[tag=duel.winner] run function evercraft:util/notify/who_add
data modify storage evercraft:notify stage.c set value [{text:"",color:"green"},{text:" win the team duel!",color:"yellow"}]
data modify storage evercraft:notify stage.c[0].text set from storage evercraft:notify named.who
scoreboard players set #ndur ec.temp 50
scoreboard players set #nttl ec.temp 300
execute as @a run function evercraft:util/notify/emit

# Milestone
function evercraft:milestones/increment/duel_complete

# Cleanup
function evercraft:duel/team/full_cleanup
