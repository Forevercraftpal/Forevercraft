# Team Duel — Partner B Confirmation Timeout
# Runs as partner_b whose invite timer expired

data modify storage evercraft:notify stage.c set value [{text:"Partner confirmation timed out. Team duel cancelled.",color:"gray"}]
scoreboard players set #ndur ec.temp 50
execute as @a[tag=duel.team_opponent_confirmed] run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Team duel cancelled — partner did not confirm in time.",color:"gray"}]
scoreboard players set #ndur ec.temp 50
execute as @a[tag=duel.team_challenger] run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Team duel partner invite expired.",color:"gray"}]
scoreboard players set #ndur ec.temp 50
function evercraft:util/notify/emit

function evercraft:duel/team/cleanup_tags
