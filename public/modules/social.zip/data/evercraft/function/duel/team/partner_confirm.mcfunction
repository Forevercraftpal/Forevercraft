# Team Duel — Partner B Confirmed (runs as partner_b)
# All 4 players ready — start the duel

execute unless entity @s[tag=duel.partner_b] run return 0

# Mutex gate (#50 W1) — a duel (or another team setup) may have claimed #duel_active on this same tick.
# Team's mutex is set in team/start (the actual start); guard the entry here so a 2nd team duel can't
# tangle 8 players into one match. If the lock is held, abort this team setup cleanly.
execute if score #duel_active ec.var matches 1.. run function evercraft:duel/team/cleanup_tags
execute if score #duel_active ec.var matches 1.. run return 0

# All 4 confirmed — start team duel
# (AB-3, 2026-06-10: rides the queue — each roster slot is a SINGLE tagged player, so four whoami
# captures fill the four name holes in turn. Replaces the earlier deliberate §5b raw keep.)
data modify storage evercraft:notify stage.c set value [{text:"Team Duel: ",color:"gold"},{text:"",color:"aqua"},{text:" & ",color:"yellow"},{text:"",color:"aqua"},{text:" vs ",color:"red"},{text:"",color:"light_purple"},{text:" & ",color:"yellow"},{text:"",color:"light_purple"}]
execute as @a[tag=duel.team_challenger,limit=1] run function evercraft:util/notify/whoami
data modify storage evercraft:notify stage.c[1].text set from storage evercraft:notify named.who
execute as @a[tag=duel.partner_a,limit=1] run function evercraft:util/notify/whoami
data modify storage evercraft:notify stage.c[3].text set from storage evercraft:notify named.who
execute as @a[tag=duel.team_opponent_confirmed,limit=1] run function evercraft:util/notify/whoami
data modify storage evercraft:notify stage.c[5].text set from storage evercraft:notify named.who
execute as @a[tag=duel.partner_b,limit=1] run function evercraft:util/notify/whoami
data modify storage evercraft:notify stage.c[7].text set from storage evercraft:notify named.who
scoreboard players set #ndur ec.temp 50
scoreboard players set #nttl ec.temp 300
execute as @a run function evercraft:util/notify/emit

# Start the duel
function evercraft:duel/team/start
