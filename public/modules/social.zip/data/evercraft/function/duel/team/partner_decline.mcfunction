# Team Duel — Partner B Declined
execute unless entity @s[tag=duel.partner_b] run return 0

function evercraft:util/notify/whoami
data modify storage evercraft:notify stage.c set value [{text:"",color:"red"},{text:" declined to join. Team duel cancelled.",color:"gray"}]
data modify storage evercraft:notify stage.c[0].text set from storage evercraft:notify named.who
scoreboard players set #ndur ec.temp 45
execute as @a[tag=duel.team_opponent_confirmed] run scoreboard players set #nttl ec.temp 300
execute as @a[tag=duel.team_opponent_confirmed] run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Team duel cancelled — opponent's partner declined.",color:"gray"}]
scoreboard players set #ndur ec.temp 50
execute as @a[tag=duel.team_challenger] run function evercraft:util/notify/emit

function evercraft:duel/team/cleanup_tags
