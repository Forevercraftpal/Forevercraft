# Team Duel — Eliminate Player (runs as the eliminated player)
# Save from death + mark as eliminated

# Heal to prevent actual death
effect give @s minecraft:instant_health 1 5 true
effect give @s minecraft:resistance 60 4 true

# Totem animation (visual kept; the totem.use sound folds into the duel_ko impact below)
particle minecraft:totem_of_undying ~ ~1 ~ 0.5 1 0.5 0.5 50

# Mark eliminated
tag @s add duel.eliminated

# Decrement team alive count
execute if score @s ec.duel_team_num matches 1 run scoreboard players remove #duel_t1_alive ec.var 1
execute if score @s ec.duel_team_num matches 2 run scoreboard players remove #duel_t2_alive ec.var 1

# Set spectator so they can watch
gamemode spectator @s

# Effects
title @s times 5 40 15
title @s title {text:"ELIMINATED",color:"red"}
title @s subtitle {text:"Watch your teammate fight on!",color:"gray"}

# Announce
function evercraft:util/notify/whoami
data modify storage evercraft:notify stage.c set value [{text:"",color:"red"},{text:" has been eliminated!",color:"yellow"}]
data modify storage evercraft:notify stage.c[0].text set from storage evercraft:notify named.who
scoreboard players set #ndur ec.temp 45
execute as @a[tag=ec.duel_active_tag] run scoreboard players set #nttl ec.temp 300
execute as @a[tag=ec.duel_active_tag] run function evercraft:util/notify/emit
# KO impact (per-listener gated bespoke FX — REPLACES entity.wither.death). No FTX progress.
scoreboard players set #duel_ko_pip ec.temp 0
function evercraft:fx/companion/duel_ko
