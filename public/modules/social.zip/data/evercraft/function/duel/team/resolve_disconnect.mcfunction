# Team Duel — Resolve Disconnect
# Not enough players remaining

data modify storage evercraft:notify stage.c set value [{text:"Team duel ended — not enough players remaining.",color:"gray"}]
scoreboard players set #ndur ec.temp 50
execute as @a run function evercraft:util/notify/emit

# Restore any eliminated spectators
execute as @a[tag=duel.eliminated] run gamemode survival @s

# No winner/loser rewards on disconnect
function evercraft:duel/team/full_cleanup
