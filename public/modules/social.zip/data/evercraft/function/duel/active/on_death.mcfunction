# Duel — Death Fallback (runs as duelist who somehow died despite health check)
# This should rarely fire — totem_save catches most cases via health monitoring.
# keepInventory is ON so items + XP are preserved. Player respawns at bed automatically.

# Totem pop visual (death intercepted; totem.use sound folds into the duel_ko impact below)
particle minecraft:totem_of_undying ~ ~1 ~ 0.5 1 0.5 0.5 50
# KO impact (per-listener gated bespoke FX — was: item.totem.use @s). No FTX progress.
scoreboard players set #duel_ko_pip ec.temp 0
function evercraft:fx/companion/duel_ko

# Prevent tomb from processing this death
scoreboard players set @s ec.tomb_death 0

# If duel already resolved by totem_save, skip
execute if entity @s[tag=duel.loser] run return 0
execute if entity @s[tag=duel.winner] run return 0

# Tag roles
tag @s add duel.loser
execute as @a[tag=ec.duel_active_tag,tag=!duel.loser] run tag @s add duel.winner

# Apply loser penalties (they'll respawn at bed via vanilla death)
# Darkness + Nausea for 7 seconds (knockout feel)
effect give @s minecraft:darkness 7 0 false
effect give @s minecraft:nausea 7 0 false
# 1-hour Mining Fatigue + Weakness
effect give @s minecraft:mining_fatigue 3600 0 false
effect give @s minecraft:weakness 3600 0 false
scoreboard players add @s ec.duel_today 1

# Defeat title (shows after respawn)
title @s times 5 40 15
title @s title {text:"DEFEATED",color:"red"}
title @s subtitle {text:"Knocked out!",color:"gray"}

data modify storage evercraft:notify stage.c set value [{text:"The nightmare is over! You either had a horrible dream or got knocked out!",color:"dark_purple",italic:true}]
scoreboard players set #ndur ec.temp 50
function evercraft:util/notify/emit

# Resolve
function evercraft:duel/end/resolve
