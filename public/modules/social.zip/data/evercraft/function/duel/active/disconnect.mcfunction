# Duel — Disconnect Handler (fewer than 2 duelists online)

# If 1 duelist remains, they win by default
execute if score #duelist_count ec.temp matches 1 as @a[tag=ec.duel_active_tag] run tag @s add duel.winner
data modify storage evercraft:notify stage.c set value [{text:"Opponent disconnected — duel won by default!",color:"yellow"}]
scoreboard players set #ndur ec.temp 50
execute if score #duelist_count ec.temp matches 1 as @a run function evercraft:util/notify/emit

# If 0 duelists remain (both disconnected), just clean up
data modify storage evercraft:notify stage.c set value [{text:"Both duelists disconnected — duel cancelled.",color:"gray"}]
scoreboard players set #ndur ec.temp 50
execute if score #duelist_count ec.temp matches 0 as @a run function evercraft:util/notify/emit

# Resolve (winner handling will only fire if someone has the tag)
function evercraft:duel/end/resolve
