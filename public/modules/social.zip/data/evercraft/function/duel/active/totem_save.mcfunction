# Duel — Totem Life Save (runs as the duelist who dropped to critical health)
# Simulates totem of undying: save from death, heal, effects, then teleport to bed

# === RE-ENTRY GUARD (#50 W2) ===
# Same-tick mutual KO: active/tick:15 dispatches check_health->totem_save over a SNAPSHOTTED @a list.
# If A's totem_save already resolved+cleaned up this tick, the iterator still visits B (never healed),
# which would re-resolve (the #duel_resolved sentinel was just reset by cleanup). Bail if this duelist
# was already tagged loser/winner by the first resolution. Mirrors on_death:13-14.
execute if entity @s[tag=duel.loser] run return 0
execute if entity @s[tag=duel.winner] run return 0

# === IMMEDIATE SURVIVAL ===
# Full heal + brief invulnerability to prevent death during teleport
effect give @s minecraft:instant_health 1 5 true
effect give @s minecraft:resistance 3 4 true

# === TOTEM ANIMATION ===
# Totem particles kept (the totem.use sound folds into the duel_ko impact below).
particle minecraft:totem_of_undying ~ ~1 ~ 0.5 1 0.5 0.5 50

# === TAG ROLES ===
tag @s add duel.loser
execute as @a[tag=ec.duel_active_tag,tag=!duel.loser] run tag @s add duel.winner

# === LOSER PENALTIES ===
# Darkness + Nausea for 7 seconds (knockout feel)
effect give @s minecraft:darkness 7 0 false
effect give @s minecraft:nausea 7 0 false

# 1-hour Mining Fatigue + Weakness
effect give @s minecraft:mining_fatigue 3600 0 false
effect give @s minecraft:weakness 3600 0 false

# Increment daily duel count
scoreboard players add @s ec.duel_today 1

# Defeat title
title @s times 5 40 15
title @s title {text:"DEFEATED",color:"red"}
title @s subtitle {text:"Knocked out!",color:"gray"}

# KO impact (per-listener gated bespoke FX — REPLACES entity.wither.death). No FTX progress.
scoreboard players set #duel_ko_pip ec.temp 0
function evercraft:fx/companion/duel_ko

# Action-bar message
data modify storage evercraft:notify stage.c set value [{text:"The nightmare is over! You either had a horrible dream or got knocked out!",color:"dark_purple",italic:true}]
scoreboard players set #ndur ec.temp 50
function evercraft:util/notify/emit

# === TELEPORT TO BED/SPAWN ===
# Store spawn coordinates to storage for macro TP
execute if data entity @s respawn run function evercraft:duel/active/tp_to_spawn
# If no respawn point set, teleport to world spawn
execute unless data entity @s respawn run spreadplayers ~ ~ 0 1 false @s

# === RESOLVE DUEL ===
function evercraft:duel/end/resolve
