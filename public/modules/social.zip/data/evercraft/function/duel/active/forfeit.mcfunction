# Duel — Forfeit (runs as the player who forfeited by going OOB or disconnecting)

tag @s add duel.loser

# Tag the other duelist as winner
execute as @a[tag=ec.duel_active_tag,tag=!duel.loser] run tag @s add duel.winner

# Announce
function evercraft:util/notify/whoami
data modify storage evercraft:notify stage.c set value [{text:"",color:"red"},{text:" forfeited the duel!",color:"yellow"}]
data modify storage evercraft:notify stage.c[0].text set from storage evercraft:notify named.who
scoreboard players set #ndur ec.temp 45
execute as @a run scoreboard players set #nttl ec.temp 300
execute as @a run function evercraft:util/notify/emit

# Resolve
function evercraft:duel/end/resolve
