# Clean up all party data for a player leaving/disbanding
# Run as the player being cleaned up

# Wiring Audit #19 W4 (AU18-FOLLOWUP.5): capture color name BEFORE pty_clr is zeroed at line 22.
# Consumed at the closing tellraw via macro form so the leave message reads
# "You have left the Aqua Party." instead of a flat "Party" string.
function evercraft:party/color/get_name

# Remove buffs
attribute @s armor modifier remove evercraft:party_dr
attribute @s luck modifier remove evercraft:party_luck
attribute @s luck modifier remove evercraft:tidal_network

# Reset all party scores
scoreboard players set @s ec.party_id 0
scoreboard players set @s ec.party_role 0
scoreboard players set @s ec.party_nearby 0
scoreboard players set @s ec.party_size 0
scoreboard players set @s ec.party_ldr_dc 0
scoreboard players set @s ec.party_dc 0
scoreboard players set @s ec.party_inv 0
# Wiring Audit #16 polish-wave AU17 (AU16-FOLLOWUP.6): split cooldowns — clear both.
scoreboard players set @s ec.party_inv_sender_cd 0
scoreboard players set @s ec.party_inv_recip_cd 0
# AU16-FOLLOWUP.1: ec.party_inv_from reset stripped (objective removed).
scoreboard players set @s ec.pty_clr 0

# Reset combo flags
scoreboard players set @s ec.pc_pack 0
scoreboard players set @s ec.pc_tidal 0
scoreboard players set @s ec.pc_rally_dr 0
# Wiring Audit #16 polish-wave AU17 (AU16-FOLLOWUP.1): ec.pc_marked reset stripped (objective removed).

# Reset combo cooldowns (prevent carry-over to new party)
scoreboard players set @s ec.pc_mark_cd 0
scoreboard players set @s ec.pc_shield_cd 0
scoreboard players set @s ec.pc_blitz_cd 0
scoreboard players set @s ec.pc_medic_cd 0
scoreboard players set @s ec.pc_rally_cd 0
scoreboard players set @s ec.pc_fortune_cd 0
scoreboard players set @s ec.pc_forge_cd 0
scoreboard players set @s ec.pc_ping_cd 0

# Clear sidebar name cache (re-capture on next party join)
tag @s remove ec.pty_named

# Clear sidebar
function evercraft:party/sidebar/clear

# Leave party sidebar team + restore title team if they have one
team leave @s
execute if score @s wb.title matches 1.. run function evercraft:bosses/titles/apply

# Wiring Audit #19 W4 (AU18-FOLLOWUP.5): macro form interpolates pre-cleanup color name.
function evercraft:party/cleanup_leave_macro with storage evercraft:party temp
