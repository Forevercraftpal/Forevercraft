# Party roster builder — append one member's name (comma-separated) to evercraft:scorebake roster.
# Run AS each party member (execute as @a[party_id=pid] run ...) for the leader's status line. 26.1:
# {selector:} renders blank in text_display, so each name is baked via util/gui/owner_name and copied
# (not live) into the list, which refresh_status splices into the status row. Names + separators yellow.
# #pty_first (ec.temp) = 1 for the first member (no leading ", ").
execute unless score #pty_first ec.temp matches 1 run data modify storage evercraft:scorebake roster append value {text:", ",color:"yellow"}
scoreboard players set #pty_first ec.temp 0
data modify storage evercraft:scorebake args.owner set value ""
function evercraft:util/gui/owner_name
function evercraft:party/gui/roster_append_name with storage evercraft:scorebake args
