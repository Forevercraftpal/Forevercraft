# Append the baked member name (green) to the party member list. Macro: $(owner) from owner_name.
$data modify storage evercraft:scorebake mlist append value {text:"$(owner)",color:"green"}
