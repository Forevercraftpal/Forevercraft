# Party Section — Check Clicks (Section 7)
# Handles nav arrows, management action buttons, and stale state detection
# Run as the player with menu open

# === NAVIGATION ARROWS (page switching: Management / Bonds) ===
execute as @e[type=interaction,tag=Adv.NavLeftClick,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction at @s on target run function evercraft:party/gui/nav_left
execute as @e[type=interaction,tag=Adv.NavLeftClick,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction at @s run data remove entity @s interaction
execute as @e[type=interaction,tag=Adv.NavRightClick,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction at @s on target run function evercraft:party/gui/nav_right
execute as @e[type=interaction,tag=Adv.NavRightClick,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction at @s run data remove entity @s interaction

# === PAGE 1: MANAGEMENT ACTION BUTTONS ===
execute if score @s adv.gui_page matches 1 as @e[type=interaction,tag=Adv.PtyClickCreate,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction on target run function evercraft:party/gui/click_create
execute if score @s adv.gui_page matches 1 as @e[type=interaction,tag=Adv.PtyClickCreate,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction
execute if score @s adv.gui_page matches 1 as @e[type=interaction,tag=Adv.PtyClickInvite,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction on target run function evercraft:party/gui/click_invite
execute if score @s adv.gui_page matches 1 as @e[type=interaction,tag=Adv.PtyClickInvite,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction
execute if score @s adv.gui_page matches 1 as @e[type=interaction,tag=Adv.PtyClickPing,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction on target run function evercraft:party/gui/click_ping
execute if score @s adv.gui_page matches 1 as @e[type=interaction,tag=Adv.PtyClickPing,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction
execute if score @s adv.gui_page matches 1 as @e[type=interaction,tag=Adv.PtyClickDisband,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction on target run function evercraft:party/gui/click_disband
execute if score @s adv.gui_page matches 1 as @e[type=interaction,tag=Adv.PtyClickDisband,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction
execute if score @s adv.gui_page matches 1 as @e[type=interaction,tag=Adv.PtyClickLeave,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction on target run function evercraft:party/gui/click_leave
execute if score @s adv.gui_page matches 1 as @e[type=interaction,tag=Adv.PtyClickLeave,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction
execute if score @s adv.gui_page matches 1 as @e[type=interaction,tag=Adv.PtyClickDRBoard,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction on target run function evercraft:party/gui/click_dr_board
execute if score @s adv.gui_page matches 1 as @e[type=interaction,tag=Adv.PtyClickDRBoard,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s interaction run data remove entity @s interaction

# === PAGE 2: BONDS (informational only — no clicks) ===

# === STALE STATE DETECTION (page 1 only) ===
# Every tick, check if party_size or party_role changed since last spawn
# If so, respawn management page to reflect the new state
# (Handles: someone joins/leaves while GUI is open, leader promotion, etc.)
# Uses per-player cache scores (ec.pty_csz / ec.pty_crl) to avoid cross-player interference
execute if score @s adv.gui_page matches 1 unless score @s ec.pty_csz = @s ec.party_size at @s facing entity @e[type=marker,tag=Adv.MenuAnchor,distance=..5,limit=1,sort=nearest] feet run function evercraft:party/gui/respawn_management
execute if score @s adv.gui_page matches 1 unless score @s ec.pty_crl = @s ec.party_role at @s facing entity @e[type=marker,tag=Adv.MenuAnchor,distance=..5,limit=1,sort=nearest] feet run function evercraft:party/gui/respawn_management

# ===== INSPECT (left-click = what does this button do?) — gui/inspect pattern 2026-06-11 =====
execute as @e[type=interaction,tag=Adv.PtyClickCreate,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Create Party",b:"Founds a new party with you as its leader."}
execute as @e[type=interaction,tag=Adv.PtyClickCreate,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=Adv.PtyClickInvite,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Invite",b:"Invites the nearest adventurer to your party."}
execute as @e[type=interaction,tag=Adv.PtyClickInvite,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=Adv.PtyClickLeave,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Leave Party",b:"Leaves your current party."}
execute as @e[type=interaction,tag=Adv.PtyClickLeave,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=Adv.PtyClickDisband,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Disband",b:"Disbands the whole party — leader only."}
execute as @e[type=interaction,tag=Adv.PtyClickDisband,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=Adv.PtyClickPing,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Ping",b:"Pings your party members to your spot."}
execute as @e[type=interaction,tag=Adv.PtyClickPing,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=Adv.PtyClickDRBoard,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Dream Rank Board",b:"Shows the party Dream Rank board."}
execute as @e[type=interaction,tag=Adv.PtyClickDRBoard,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=Adv.NavLeftClick,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Previous Page",b:"Flips to the previous party page."}
execute as @e[type=interaction,tag=Adv.NavLeftClick,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=Adv.NavRightClick,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Next Page",b:"Flips to the next party page."}
execute as @e[type=interaction,tag=Adv.NavRightClick,distance=..5] if score @s adv.gui_session = #gui_owner ec.temp if data entity @s attack run data remove entity @s attack
