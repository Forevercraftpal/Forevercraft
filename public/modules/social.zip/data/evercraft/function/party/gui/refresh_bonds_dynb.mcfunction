# AUTO (refresh_bonds.mcfunction): data-modify text_display rows with {score} baked as macro args (26.1 fix, cat B).
# Invoked `with storage evercraft:scorebake bargs` from the parent.
$execute if score @s ec.party_role matches 1 run data modify entity @e[type=text_display,tag=Adv.PbStatus,distance=..5,limit=1] text set value [{text:"Status: ",color:"gray"},{text:"Party Leader",color:"gold"},{text:" \u2014 ",color:"dark_gray"},{text:"Nearby: ",color:"gray"},{text:"$(v1)",color:"green"}]
$execute if score @s ec.party_role matches 2 run data modify entity @e[type=text_display,tag=Adv.PbStatus,distance=..5,limit=1] text set value [{text:"Status: ",color:"gray"},{text:"Party Member",color:"green"},{text:" \u2014 ",color:"dark_gray"},{text:"Nearby: ",color:"gray"},{text:"$(v1)",color:"green"}]
