# Party Management — Leader Layout (role = 1)
# Run as the player, at player, facing the anchor

# Status: "Party Leader — X/4"
execute rotated ~ 0 positioned ^ ^1.82 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["Adv.MenuElement","Adv.SectionContent","Adv.PartyPage","Adv.PtyStatus"],billboard:"center",text:{text:"Loading...",color:"gray"},background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.262f,0.262f,0.262f]}}

# Members header
execute rotated ~ 0 positioned ^ ^1.62 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["Adv.MenuElement","Adv.SectionContent","Adv.PartyPage"],billboard:"center",text:{text:"Members",color:"gold",bold:true},background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.286f,0.286f,0.286f]}}

# Leader slot (self)
execute rotated ~ 0 positioned ^ ^1.48 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["Adv.MenuElement","Adv.SectionContent","Adv.PartyPage","Adv.PtyLeader"],billboard:"center",text:{text:"...",color:"yellow"},background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.177f,0.177f,0.177f]}}

# Member slots (up to 3 other members)
execute rotated ~ 0 positioned ^ ^1.36 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["Adv.MenuElement","Adv.SectionContent","Adv.PartyPage","Adv.PtyMemberList"],billboard:"center",text:{text:"  ---",color:"dark_gray"},background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.177f,0.177f,0.177f]}}

# === Action Buttons ===

# Invite Nearby
execute rotated ~ 0 positioned ^ ^1 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["Adv.MenuElement","Adv.SectionContent","Adv.PartyPage"],billboard:"center",text:{text:"[ Invite Nearby ]",color:"green",bold:true},background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.334f,0.334f,0.334f]}}
# [strip] Adv.MenuElement: 0.7w split into 5 x 0.15 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute rotated ~ 0 positioned ^-0.275 ^0.925 ^1.8 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Adv.PartyPage","Adv.PtyClickInvite"],width:0.15f,height:0.15f,response:1b}
execute rotated ~ 0 positioned ^-0.1375 ^0.925 ^1.8 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Adv.PartyPage","Adv.PtyClickInvite"],width:0.15f,height:0.15f,response:1b}
execute rotated ~ 0 positioned ^0 ^0.925 ^1.8 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Adv.PartyPage","Adv.PtyClickInvite"],width:0.15f,height:0.15f,response:1b}
execute rotated ~ 0 positioned ^0.1375 ^0.925 ^1.8 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Adv.PartyPage","Adv.PtyClickInvite"],width:0.15f,height:0.15f,response:1b}
execute rotated ~ 0 positioned ^0.275 ^0.925 ^1.8 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Adv.PartyPage","Adv.PtyClickInvite"],width:0.15f,height:0.15f,response:1b}

# Party Ping
execute rotated ~ 0 positioned ^ ^0.85 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["Adv.MenuElement","Adv.SectionContent","Adv.PartyPage"],billboard:"center",text:{text:"[ Party Ping ]",color:"aqua",bold:true},background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.334f,0.334f,0.334f]}}
# [strip] Adv.MenuElement: 0.7w split into 5 x 0.15 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute rotated ~ 0 positioned ^-0.275 ^0.775 ^1.8 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Adv.PartyPage","Adv.PtyClickPing"],width:0.15f,height:0.15f,response:1b}
execute rotated ~ 0 positioned ^-0.1375 ^0.775 ^1.8 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Adv.PartyPage","Adv.PtyClickPing"],width:0.15f,height:0.15f,response:1b}
execute rotated ~ 0 positioned ^0 ^0.775 ^1.8 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Adv.PartyPage","Adv.PtyClickPing"],width:0.15f,height:0.15f,response:1b}
execute rotated ~ 0 positioned ^0.1375 ^0.775 ^1.8 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Adv.PartyPage","Adv.PtyClickPing"],width:0.15f,height:0.15f,response:1b}
execute rotated ~ 0 positioned ^0.275 ^0.775 ^1.8 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Adv.PartyPage","Adv.PtyClickPing"],width:0.15f,height:0.15f,response:1b}

# Disband Party
execute rotated ~ 0 positioned ^ ^0.7 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["Adv.MenuElement","Adv.SectionContent","Adv.PartyPage"],billboard:"center",text:{text:"[ Disband Party ]",color:"red",bold:true},background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.334f,0.334f,0.334f]}}
# [strip] Adv.MenuElement: 0.7w split into 5 x 0.15 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute rotated ~ 0 positioned ^-0.275 ^0.625 ^1.8 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Adv.PartyPage","Adv.PtyClickDisband"],width:0.15f,height:0.15f,response:1b}
execute rotated ~ 0 positioned ^-0.1375 ^0.625 ^1.8 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Adv.PartyPage","Adv.PtyClickDisband"],width:0.15f,height:0.15f,response:1b}
execute rotated ~ 0 positioned ^0 ^0.625 ^1.8 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Adv.PartyPage","Adv.PtyClickDisband"],width:0.15f,height:0.15f,response:1b}
execute rotated ~ 0 positioned ^0.1375 ^0.625 ^1.8 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Adv.PartyPage","Adv.PtyClickDisband"],width:0.15f,height:0.15f,response:1b}
execute rotated ~ 0 positioned ^0.275 ^0.625 ^1.8 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Adv.PartyPage","Adv.PtyClickDisband"],width:0.15f,height:0.15f,response:1b}

# DR Leaderboard
execute rotated ~ 0 positioned ^ ^0.55 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["Adv.MenuElement","Adv.SectionContent","Adv.PartyPage"],billboard:"center",text:{text:"[ DR Leaderboard ]",color:"light_purple",bold:true},background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.334f,0.334f,0.334f]}}
# [strip] Adv.MenuElement: 0.7w split into 5 x 0.15 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute rotated ~ 0 positioned ^-0.275 ^0.475 ^1.8 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Adv.PartyPage","Adv.PtyClickDRBoard"],width:0.15f,height:0.15f,response:1b}
execute rotated ~ 0 positioned ^-0.1375 ^0.475 ^1.8 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Adv.PartyPage","Adv.PtyClickDRBoard"],width:0.15f,height:0.15f,response:1b}
execute rotated ~ 0 positioned ^0 ^0.475 ^1.8 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Adv.PartyPage","Adv.PtyClickDRBoard"],width:0.15f,height:0.15f,response:1b}
execute rotated ~ 0 positioned ^0.1375 ^0.475 ^1.8 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Adv.PartyPage","Adv.PtyClickDRBoard"],width:0.15f,height:0.15f,response:1b}
execute rotated ~ 0 positioned ^0.275 ^0.475 ^1.8 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Adv.PartyPage","Adv.PtyClickDRBoard"],width:0.15f,height:0.15f,response:1b}

# Update status text and member names via macro (26.1: party_size baked as $(psize) — {score:} blank in text_display)
execute store result storage evercraft:party temp.pid int 1 run scoreboard players get @s ec.party_id
execute store result storage evercraft:party temp.psize int 1 run scoreboard players get @s ec.party_size
function evercraft:party/gui/refresh_status with storage evercraft:party temp
function evercraft:party/gui/refresh_members with storage evercraft:party temp
