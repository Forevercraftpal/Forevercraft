# Party Management — No Party Layout (role = 0)
# Run as the player, at player, facing the anchor

# Status text
execute rotated ~ 0 positioned ^ ^1.82 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["Adv.MenuElement","Adv.SectionContent","Adv.PartyPage","Adv.PtyStatus"],billboard:"center",text:{text:"You are not in a party.",color:"gray"},background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.262f,0.262f,0.262f]}}

# Create Party button
execute rotated ~ 0 positioned ^ ^1.54 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["Adv.MenuElement","Adv.SectionContent","Adv.PartyPage"],billboard:"center",text:{text:"[ Create Party ]",color:"green",bold:true},background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.382f,0.382f,0.382f]}}
# [strip] Adv.MenuElement: 0.7w split into 6 x 0.12 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute rotated ~ 0 positioned ^-0.29 ^1.48 ^1.8 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Adv.PartyPage","Adv.PtyClickCreate"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^-0.174 ^1.48 ^1.8 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Adv.PartyPage","Adv.PtyClickCreate"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^-0.058 ^1.48 ^1.8 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Adv.PartyPage","Adv.PtyClickCreate"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^0.058 ^1.48 ^1.8 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Adv.PartyPage","Adv.PtyClickCreate"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^0.174 ^1.48 ^1.8 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Adv.PartyPage","Adv.PtyClickCreate"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^0.29 ^1.48 ^1.8 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Adv.PartyPage","Adv.PtyClickCreate"],width:0.12f,height:0.12f,response:1b}

# Description
execute rotated ~ 0 positioned ^ ^1.42 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["Adv.MenuElement","Adv.SectionContent","Adv.PartyPage"],billboard:"center",text:{text:"Start a new party and invite nearby players",color:"dark_gray"},background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.215f,0.215f,0.215f]}}

# DR Leaderboard
execute rotated ~ 0 positioned ^ ^1.14 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["Adv.MenuElement","Adv.SectionContent","Adv.PartyPage"],billboard:"center",text:{text:"[ DR Leaderboard ]",color:"light_purple",bold:true},background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.334f,0.334f,0.334f]}}
# [strip] Adv.MenuElement: 0.7w split into 4 x 0.2 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute rotated ~ 0 positioned ^-0.25 ^1.02 ^1.8 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Adv.PartyPage","Adv.PtyClickDRBoard"],width:0.2f,height:0.24f,response:1b}
execute rotated ~ 0 positioned ^-0.0833 ^1.02 ^1.8 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Adv.PartyPage","Adv.PtyClickDRBoard"],width:0.2f,height:0.24f,response:1b}
execute rotated ~ 0 positioned ^0.0833 ^1.02 ^1.8 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Adv.PartyPage","Adv.PtyClickDRBoard"],width:0.2f,height:0.24f,response:1b}
execute rotated ~ 0 positioned ^0.25 ^1.02 ^1.8 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Adv.PartyPage","Adv.PtyClickDRBoard"],width:0.2f,height:0.24f,response:1b}

# Hint: mention the Bonds page
execute rotated ~ 0 positioned ^ ^0.9 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["Adv.MenuElement","Adv.SectionContent","Adv.PartyPage"],billboard:"center",text:[{text:"Use ",color:"dark_gray"},{text:"[ > ]",color:"gray",bold:true},{text:" to view Party Bonds",color:"dark_gray"}],background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.215f,0.215f,0.215f]}}
