# Party Management — Refresh Status Line (macro)
# Args (evercraft:party temp): pid (party ID), psize (ec.party_size, baked — {score:} blank in text_display 26.1)
# Run as the player
# 26.1 selector fix: the leader line's member-name roster (formerly {selector:"@a[...]"}) is now baked
#   to a real string list via party/gui/roster_append (+util/gui/owner_name) — see below.

# Leader status: "Party Leader — X/4" in gold
# 26.1: {selector:} renders blank in text_display — build the comma-separated roster as a baked
# component list (yellow) and splice it into element [2] of the leader status row (copy, no race).
execute if score @s ec.party_role matches 1 run data modify storage evercraft:scorebake roster set value []
execute if score @s ec.party_role matches 1 run scoreboard players set #pty_first ec.temp 1
$execute if score @s ec.party_role matches 1 as @a[scores={ec.party_id=$(pid)}] run function evercraft:party/gui/roster_append
$execute if score @s ec.party_role matches 1 run data modify entity @e[type=text_display,tag=Adv.PtyStatus,distance=..5,limit=1] text set value [{text:"Party Leader",color:"gold",bold:true},{text:" \u2014 ",color:"dark_gray"},{text:"",color:"yellow"},{text:" (",color:"dark_gray"},{text:"$(psize)",color:"white"},{text:"/4)",color:"dark_gray"}]
execute if score @s ec.party_role matches 1 run data modify entity @e[type=text_display,tag=Adv.PtyStatus,distance=..5,limit=1] text[2] set from storage evercraft:scorebake roster

# Member status: "Party Member — X/4" in green
$execute if score @s ec.party_role matches 2 run data modify entity @e[type=text_display,tag=Adv.PtyStatus,distance=..5,limit=1] text set value [{text:"Party Member",color:"green",bold:true},{text:" \u2014 ",color:"dark_gray"},{text:"(",color:"dark_gray"},{text:"$(psize)",color:"white"},{text:"/4)",color:"dark_gray"}]
