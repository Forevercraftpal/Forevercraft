# Party Management — Refresh Member List (macro)
# Arg: pid (party ID)
# Run as the player
# Updates the leader name display and the member list display

# Leader display: show the party leader name with crown
# 26.1: {selector:} renders blank in text_display — bake the leader's name into the row (copy,
# not a live {nbt:storage} read, so concurrent party menus can't clobber each other).
data modify storage evercraft:scorebake args.owner set value ""
$execute as @a[scores={ec.party_id=$(pid),ec.party_role=1},limit=1] run function evercraft:util/gui/owner_name
data modify entity @e[type=text_display,tag=Adv.PtyLeader,distance=..5,limit=1] text set value [{text:"\u2726 ",color:"gold"},{text:"",color:"yellow"},{text:" (Leader)",color:"dark_gray"}]
data modify entity @e[type=text_display,tag=Adv.PtyLeader,distance=..5,limit=1] text[1].text set from storage evercraft:scorebake args.owner

# Members display: show all non-leader members using selector with newline separator
# If no members exist (solo party), selector resolves empty and shows nothing useful
$execute store result score #pty_members ec.temp if entity @a[scores={ec.party_id=$(pid),ec.party_role=2}]
execute if score #pty_members ec.temp matches 0 run data modify entity @e[type=text_display,tag=Adv.PtyMemberList,distance=..5,limit=1] text set value {text:"  ---",color:"dark_gray"}

# If there are members, show them with newline separator
# 26.1: build the member list as a baked component list (bullets gray, names green), then copy it.
data modify storage evercraft:scorebake mlist set value []
scoreboard players set #pty_first ec.temp 1
$execute as @a[scores={ec.party_id=$(pid),ec.party_role=2}] run function evercraft:party/gui/ml_append
execute if score #pty_members ec.temp matches 1.. run data modify entity @e[type=text_display,tag=Adv.PtyMemberList,distance=..5,limit=1] text set from storage evercraft:scorebake mlist
