# Append the baked member name (yellow) to the party roster. Macro: $(owner) from owner_name.
$data modify storage evercraft:scorebake roster append value {text:"$(owner)",color:"yellow"}
