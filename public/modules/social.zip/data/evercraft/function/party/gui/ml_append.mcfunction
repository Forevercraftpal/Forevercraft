# Party member-list builder — append one member's "• name" to evercraft:scorebake mlist.
# Run AS each non-leader member (execute as @a[party_id=pid, party_role=2] run ...). 26.1: {selector:}
# renders blank in text_display, so each name is baked from the player's profile via util/gui/owner_name
# and copied (not live) into the list, which refresh_members then `set from storage` onto the row.
# Bullet is gray; name green. #pty_first (ec.temp) = 1 for the first member (no leading newline).
execute if score #pty_first ec.temp matches 1 run data modify storage evercraft:scorebake mlist append value {text:"• ",color:"gray"}
execute unless score #pty_first ec.temp matches 1 run data modify storage evercraft:scorebake mlist append value {text:"\n• ",color:"gray"}
scoreboard players set #pty_first ec.temp 0
data modify storage evercraft:scorebake args.owner set value ""
function evercraft:util/gui/owner_name
function evercraft:party/gui/ml_append_name with storage evercraft:scorebake args
