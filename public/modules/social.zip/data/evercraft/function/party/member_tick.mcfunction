# Party System — Per-member tick (consolidates 6 @a scans → 1)
# Context: as @a[scores={ec.party_id=1..}] at @s
#
# Wiring Audit #16 W5.1 (race seat) — RACE NOTE: nested macros below all use
# storage evercraft:party temp.pid as per-call scratch (28 writer sites branch-wide).
# Safe today because (1) every write is the line immediately before its `with storage`
# consumer, (2) MC sequential `as @a` semantics atomically complete each player's full chain.
# DO NOT insert `schedule function ... <N>t` between a temp.pid write and its macro consumer.
# See _council/2026-05-29-wiring-dungeon/chat/race.md §3 (temp.max_hp precedent) and
#     _council/2026-05-28-wiring-spirit_tome/chat/race.md RT2 (sq_temp — broke for this reason).

# Proximity check (sets ec.party_nearby for this player)
function evercraft:party/proximity/check

# Apply or remove buffs based on nearby count
execute if score @s ec.party_nearby matches 1.. run function evercraft:party/proximity/apply_buffs
execute if score @s ec.party_nearby matches 0 run function evercraft:party/proximity/remove_buffs

# Combo checks only when near party members
execute if score @s ec.party_nearby matches 1.. run function evercraft:party/combos/check_all

# Cooldown decrements
function evercraft:party/tick_cooldowns

# Sidebar update
function evercraft:party/sidebar/update
