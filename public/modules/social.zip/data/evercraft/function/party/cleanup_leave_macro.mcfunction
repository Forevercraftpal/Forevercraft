# Party Cleanup — leave message (macro)
# Wiring Audit #19 W4 (AU18-FOLLOWUP.5): renders "You have left the Aqua Party." with the
# departing player's pre-cleanup color name. color_name is captured by cleanup_player.mcfunction
# BEFORE pty_clr is zeroed; this macro consumes via `with storage evercraft:party temp`.
# Arg: color_name (e.g. "Aqua Party", "Gold Party", or fallback "Party").
$data modify storage evercraft:notify stage.c set value [{text:"You have left the $(color_name).",color:"gray"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
