# Apply post-death Weakness to players who died during boss fight
# Runs 2 ticks after death (player has respawned by now)

execute as @a[tag=party.boss_death] run effect give @s minecraft:weakness 30 3 false
data modify storage evercraft:notify stage.c set value [{text:"You feel weakened from death... (30s debuff)",color:"gray"}]
scoreboard players set #ndur ec.temp 45
execute as @a[tag=party.boss_death] run function evercraft:util/notify/emit
tag @a remove party.boss_death
