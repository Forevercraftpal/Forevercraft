# Apply Party Proximity Buffs
# Run as each player in a party with 1+ nearby members, at their position
# Buffs scale with ec.party_nearby (1-3)

# === DAMAGE RESISTANCE: +0.5 armor per nearby member (max +1.5) ===
# Remove old modifier first, then re-apply at correct tier
attribute @s armor modifier remove evercraft:party_dr
execute if score @s ec.party_nearby matches 1 run attribute @s armor modifier add evercraft:party_dr 0.5 add_value
execute if score @s ec.party_nearby matches 2 run attribute @s armor modifier add evercraft:party_dr 1.0 add_value
execute if score @s ec.party_nearby matches 3.. run attribute @s armor modifier add evercraft:party_dr 1.5 add_value

# === ABSORPTION: 1 ❤ per nearby party member (max 4 nearby → 8 absorption HP) ===
# Wiring Audit #16 polish-wave AU17 (Joseph 2026-05-29): replaced permanent Regen I
# with absorption scaling per nearby member. Stacks aesthetically (more friends = more
# shield) without piling permanent HP regen on top of Field Medic + dungeon Regen.
# Amplifier 0 = +2HP (1❤), 1 = +4HP (2❤), 2 = +6HP (3❤). ec.party_nearby caps at 3+
# in practice (party size 4 → max 3 others nearby), so amplifier 2 is the natural ceiling.
# Duration 3s covers the 1s tick + 2s grace so the buff never lapses during normal proximity.
execute if score @s ec.party_nearby matches 1 run effect give @s minecraft:absorption 3 0 true
execute if score @s ec.party_nearby matches 2 run effect give @s minecraft:absorption 3 1 true
execute if score @s ec.party_nearby matches 3.. run effect give @s minecraft:absorption 3 2 true

# === DREAM RATE: +0.25 luck per nearby member (max +0.75) ===
# Directly affects structure crate tier rolls via luck attribute
attribute @s luck modifier remove evercraft:party_luck
execute if score @s ec.party_nearby matches 1 run attribute @s luck modifier add evercraft:party_luck 0.25 add_value
execute if score @s ec.party_nearby matches 2 run attribute @s luck modifier add evercraft:party_luck 0.50 add_value
execute if score @s ec.party_nearby matches 3.. run attribute @s luck modifier add evercraft:party_luck 0.75 add_value
