# Remove Party Proximity Buffs
# Run as players in a party but with 0 nearby members
# Clean up attribute modifiers and effects

# Remove DR modifier
attribute @s armor modifier remove evercraft:party_dr

# Remove Dream Rate luck modifier
attribute @s luck modifier remove evercraft:party_luck

# Absorption will expire naturally (3s duration, not refreshed)
# Wiring Audit #16 polish-wave AU17 (2026-05-29): was Regen I; swapped to scaling Absorption.
# No explicit removal needed
