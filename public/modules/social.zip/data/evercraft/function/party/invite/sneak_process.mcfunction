# Sneak Invite — Raycast found a non-party player
# Context: positioned at raycast hit, @s = sneaking party leader
# @n[...] = target non-party player within 1.5 blocks
#
# Wiring Audit #16 polish-wave AU17 (AU16-FOLLOWUP.6, Joseph 2026-05-29): RESOLVED.
# Cooldown split — this site writes the SENDER-side 5s (100t) sneak cooldown to its
# own scoreboard ec.party_inv_sender_cd. The RECIPIENT-side 60s (1200t) chat-invite
# expiration lives at invite/send:14 on ec.party_inv_recip_cd. Different scoreboards,
# different semantics, no more overload.

# Tag self as having found a target (stops raycast)
tag @s add ec.pty_inv_found

# Store our party ID for the invite macro
execute store result storage evercraft:party temp.pid int 1 run scoreboard players get @s ec.party_id

# Wiring Audit #19 W4 (AU18-FOLLOWUP.5): capture leader's color name into temp.color_name
# so the recipient's invite tellraw renders "[Aqua Party Invite]" not a flat header.
# Same race-safety profile as scan.mcfunction — sequential `as @s` from raycast resolution.
function evercraft:party/color/get_name

# Send invite to the target (skip if they already have a pending invite)
execute as @n[distance=..1.5,type=player,scores={ec.party_id=0,ec.party_inv=0},gamemode=!spectator] run function evercraft:party/invite/send with storage evercraft:party temp

# Notify inviter
data modify storage evercraft:notify stage.c set value [{text:"Invitation sent!",color:"green"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.experience_orb.pickup player @s ~ ~ ~ 0.5 1.2

# 5-second cooldown (100 ticks, decremented by 20/s in tick_cooldowns) — sender-side
scoreboard players set @s ec.party_inv_sender_cd 100
