# Accept failed — party is full
scoreboard players set @s ec.party_id 0
scoreboard players set @s ec.party_role 0
scoreboard players set @s ec.party_inv 0
# Wiring Audit #16 polish-wave AU17 (AU16-FOLLOWUP.6 + AU16-FOLLOWUP.1):
# clear recipient-side cooldown; ec.party_inv_from reset stripped (objective removed).
scoreboard players set @s ec.party_inv_recip_cd 0
data modify storage evercraft:notify stage.c set value [{text:"That party is full (4/4).",color:"red"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
