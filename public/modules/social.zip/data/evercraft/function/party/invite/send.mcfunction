# Send Party Invite to a player (macro)
# Args: pid (inviting party's ID), color_name (leader's party color name — W19 W4)
# Run as the invited player
#
# Wiring Audit #16 polish-wave AU17 (AU16-FOLLOWUP.6, Joseph 2026-05-29): split the
# overloaded ec.party_inv_cd. This write is the RECIPIENT-side 60s (1200t) invite-
# expiration timer — now on its own scoreboard ec.party_inv_recip_cd. The sender-side
# 5s (100t) cooldown lives at sneak_process:25 on ec.party_inv_sender_cd.
# Wiring Audit #16 polish-wave AU17 (AU16-FOLLOWUP.1): stripped ec.party_inv_from write
# (objective removed — 0 readers branch-wide).
# Wiring Audit #19 W4 (AU18-FOLLOWUP.5): color_name macro arg is forwarded into show_invite
# (UX richness — recipient tellraw header reads "[Aqua Party Invite]" not flat "[Party Invite]").
# color_name was set on temp.color_name by the SENDER's scan/sneak_process chain prior to fan-out.

# Mark as having a pending invite
scoreboard players set @s ec.party_inv 1
scoreboard players set @s ec.party_inv_recip_cd 1200

# Calculate accept trigger value (10 + party_id)
$scoreboard players set #inv_accept ec.temp $(pid)
scoreboard players add #inv_accept ec.temp 10
execute store result storage evercraft:party temp.accept int 1 run scoreboard players get #inv_accept ec.temp

# Show invite with clickable accept/decline (color_name flows through temp storage unchanged).
function evercraft:party/invite/show_invite with storage evercraft:party temp
