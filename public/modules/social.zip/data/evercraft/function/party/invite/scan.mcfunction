# Invite Scan — Find nearby ungrouped players and send invites
# Run as the party leader, at their position

# Must be a leader
data modify storage evercraft:notify stage.c set value [{text:"Only the party leader can invite.",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute unless score @s ec.party_role matches 1 run return run function evercraft:util/notify/emit

# Check party isn't full
data modify storage evercraft:notify stage.c set value [{text:"Party is full (4/4).",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute if score @s ec.party_size matches 4.. run return run function evercraft:util/notify/emit

# Store party ID for the invite
execute store result storage evercraft:party temp.pid int 1 run scoreboard players get @s ec.party_id

# Wiring Audit #19 W4 (AU18-FOLLOWUP.5): capture leader's color name into temp.color_name so
# the invite tellraw on each recipient can show "[Aqua Party Invite]" rather than a flat header.
# Race-safety: scan runs `as @s` (leader) sequentially per trigger_handler dispatch; the
# get_name write to temp.color_name is consumed atomically by `send … with storage temp` below
# (and forwarded into show_invite by send). Per AU16 W5.1 race-note doctrine.
function evercraft:party/color/get_name

# Find ungrouped players within 64 blocks
execute store result score #inv_count ec.temp if entity @a[scores={ec.party_id=0},distance=..64,gamemode=!spectator]

# Nobody nearby?
data modify storage evercraft:notify stage.c set value [{text:"No ungrouped players within 64 blocks.",color:"yellow"}]
scoreboard players set #ndur ec.temp 45
execute if score #inv_count ec.temp matches 0 run return run function evercraft:util/notify/emit

# Send invite to each nearby ungrouped player
execute as @a[scores={ec.party_id=0},distance=..64,gamemode=!spectator] run function evercraft:party/invite/send with storage evercraft:party temp

data modify storage evercraft:notify stage.c set value [{text:"Invitations sent to nearby players.",color:"green"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
