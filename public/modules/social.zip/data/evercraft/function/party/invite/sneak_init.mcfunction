# Sneak Invite — Raycast Init
# Context: as sneaking party leader, at @s anchored eyes positioned ^ ^ ^0.5

scoreboard players set #pty_ray ec.temp 0
tag @s remove ec.pty_inv_found

function evercraft:party/invite/sneak_raycast

# Wiring Audit #16 W2.4: no-target feedback — match chat-invite scan parity
# If the raycast didn't tag self as inv_found AND we're not on cooldown (so sneak_process didn't fire), say so.
data modify storage evercraft:notify stage.c set value [{text:"No player in sight to invite (look at them within 5 blocks).",color:"yellow"}]
scoreboard players set #ndur ec.temp 45
execute unless entity @s[tag=ec.pty_inv_found] unless score @s ec.party_inv_sender_cd matches 1.. run function evercraft:util/notify/emit

tag @s remove ec.pty_inv_found
