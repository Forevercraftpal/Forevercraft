# Validate party invite acceptance (macro)
# Arg: pid (party ID to join)

# Check if party still has online members
$execute store result score #inv_valid ec.temp if entity @a[scores={ec.party_id=$(pid)}]
execute if score #inv_valid ec.temp matches 0 run return run function evercraft:party/invite/accept_fail

# Check if party is full (4 members)
execute if score #inv_valid ec.temp matches 4.. run return run function evercraft:party/invite/accept_full

# Join the party — set party ID now that validation passed
$scoreboard players set @s ec.party_id $(pid)
scoreboard players set @s ec.party_role 2
scoreboard players set @s ec.party_inv 0
# Wiring Audit #16 polish-wave AU17 (AU16-FOLLOWUP.6 + AU16-FOLLOWUP.1):
# clear recipient-side cooldown; ec.party_inv_from reset stripped (objective removed).
scoreboard players set @s ec.party_inv_recip_cd 0
scoreboard players set @s ec.party_ldr_dc 0

# Copy party color from an existing member and join their team
$execute as @a[scores={ec.party_id=$(pid),ec.pty_clr=1..},limit=1] store result storage evercraft:party temp.clr int 1 run scoreboard players get @s ec.pty_clr
execute store result score @s ec.pty_clr run data get storage evercraft:party temp.clr
function evercraft:party/color/join_team with storage evercraft:party temp

# Announce to party — §5b actor-name broadcast: direct render so {selector:"@s"} resolves once.
# (Wave 2, 2026-06-10: party echo — whoami-baked, 15s TTL.)
function evercraft:util/notify/whoami
data modify storage evercraft:notify stage.c set value [{text:"",color:"yellow"},{text:" joined the party!",color:"green"}]
data modify storage evercraft:notify stage.c[0].text set from storage evercraft:notify named.who
scoreboard players set #ndur ec.temp 45
$execute as @a[scores={ec.party_id=$(pid)}] run scoreboard players set #nttl ec.temp 300
$execute as @a[scores={ec.party_id=$(pid)}] run function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.chime player @s ~ ~ ~ 1 1.5

# Update party size for all members
$execute as @a[scores={ec.party_id=$(pid)}] store result score @s ec.party_size if entity @a[scores={ec.party_id=$(pid)}]
