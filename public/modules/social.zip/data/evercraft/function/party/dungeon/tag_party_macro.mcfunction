# Tag party members for dungeon (macro)
# Arg: pid (= ec.party_id for parties 1..14; same as Audit B per-party pid)
# Audit B (2026-05-29): tag p<pid> alongside dg.player for cross-party selector isolation.

$execute as @a[scores={ec.party_id=$(pid)},distance=..48] run tag @s add dg.player
$execute as @a[scores={ec.party_id=$(pid)},distance=..48] run tag @s add p$(pid)
$execute as @a[scores={ec.party_id=$(pid)},distance=..48] run scoreboard players set @s dg.deaths 0
# §5 static broadcast — stage once, emit per party member (no actor reference in the text).
data modify storage evercraft:notify stage.c set value [{text:"Your party has entered the dungeon!",color:"light_purple"}]
scoreboard players set #ndur ec.temp 45
$execute as @a[scores={ec.party_id=$(pid)},distance=..48] run function evercraft:util/notify/emit
