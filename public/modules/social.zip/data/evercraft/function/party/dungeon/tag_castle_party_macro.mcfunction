# Tag party members for castle (macro)
# Arg: pid (= ec.party_id for parties 1..14; same as Audit B per-party pid)
# AU-B-FOLLOWUP.10 (2026-05-29): tag p<pid> alongside ic.player for cross-party selector
# isolation (mirrors dungeon's `party/dungeon/tag_party_macro` pattern). Cleaner than
# `scores={ec.party_id=$(pid)}` which has a solo defect (party_id=0 for solos never matches).

$execute as @a[scores={ec.party_id=$(pid)},distance=..48] run tag @s add ic.player
$execute as @a[scores={ec.party_id=$(pid)},distance=..48] run tag @s add p$(pid)
$execute as @a[scores={ec.party_id=$(pid)},distance=..48] run scoreboard players set @s ic.deaths 0
$execute as @a[scores={ec.party_id=$(pid)},distance=..48] run scoreboard players set @s ic.coins 0
# §5 static broadcast — stage once, emit per party member (no actor reference in the text).
data modify storage evercraft:notify stage.c set value [{text:"Your party has entered the Infinite Castle!",color:"red"}]
scoreboard players set #ndur ec.temp 45
$execute as @a[scores={ec.party_id=$(pid)},distance=..48] run function evercraft:util/notify/emit
