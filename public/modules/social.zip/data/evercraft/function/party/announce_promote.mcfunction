# Announce leader promotion to party members
# Arg: pid (party ID)
# Run as the newly promoted leader

# §5b actor-name broadcast — render directly in the leader's context so {selector:"@s"}
# resolves once (the staged queue would resolve it per-recipient). No queue/fade.
# (Wave 2, 2026-06-10: party echo — whoami-baked, 15s TTL.)
function evercraft:util/notify/whoami
data modify storage evercraft:notify stage.c set value [{text:"",color:"yellow"},{text:" has been promoted to party leader.",color:"gray"}]
data modify storage evercraft:notify stage.c[0].text set from storage evercraft:notify named.who
scoreboard players set #ndur ec.temp 45
$execute as @a[scores={ec.party_id=$(pid)}] run scoreboard players set #nttl ec.temp 300
$execute as @a[scores={ec.party_id=$(pid)}] run function evercraft:util/notify/emit
