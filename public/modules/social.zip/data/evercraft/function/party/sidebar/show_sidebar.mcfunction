# Party Sidebar — Set all 14 team color display slots to ec.party_hp
# Called once from load. Each party team color gets its own sidebar.team.<color> slot.
scoreboard objectives setdisplay sidebar.team.gold ec.party_hp
scoreboard objectives setdisplay sidebar.team.dark_blue ec.party_hp
scoreboard objectives setdisplay sidebar.team.dark_green ec.party_hp
scoreboard objectives setdisplay sidebar.team.dark_aqua ec.party_hp
scoreboard objectives setdisplay sidebar.team.gray ec.party_hp
scoreboard objectives setdisplay sidebar.team.light_purple ec.party_hp
scoreboard objectives setdisplay sidebar.team.black ec.party_hp
scoreboard objectives setdisplay sidebar.team.aqua ec.party_hp
scoreboard objectives setdisplay sidebar.team.yellow ec.party_hp
scoreboard objectives setdisplay sidebar.team.white ec.party_hp
scoreboard objectives setdisplay sidebar.team.dark_gray ec.party_hp
scoreboard objectives setdisplay sidebar.team.dark_purple ec.party_hp
scoreboard objectives setdisplay sidebar.team.green ec.party_hp
scoreboard objectives setdisplay sidebar.team.blue ec.party_hp
