# Pick a random color from the pool for a new party
# Run as the party creator
#
# Wiring Audit #16 W5.1 (race seat) — RACE NOTE: color_pool storage array is mutated
# sequentially per-player by `as @a` iteration from trigger_handler. Simultaneous multi-player
# /trigger ec.party set 2 in the same tick is SAFE — player A's full pick→pick_random→assign
# chain (including data remove color_pool[$(idx)]) completes atomically before B's iteration.
# DO NOT insert `schedule function ... <N>t` between pick → pick_random → assign.

# Count available colors
execute store result score #pool_sz ec.temp run data get storage evercraft:party color_pool

# Fail if pool empty (7 parties already active)
data modify storage evercraft:notify stage.c set value [{text:"No party colors available! Too many active parties.",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute if score #pool_sz ec.temp matches 0 run return run function evercraft:util/notify/emit

# Random index: 0..(size-1)
scoreboard players remove #pool_sz ec.temp 1
execute store result storage evercraft:party temp.idx int 1 run scoreboard players get #pool_sz ec.temp
function evercraft:party/color/pick_random with storage evercraft:party temp
