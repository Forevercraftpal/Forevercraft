# Party Color → player-facing name dispatch
# Wiring Audit #19 W4 (AU18-FOLLOWUP.5): UX polish — maps @s ec.pty_clr 1..14 to a
# player-facing party-color name and writes it to storage evercraft:party temp.color_name.
# Callers consume via `function ... with storage evercraft:party temp` macro chain.
# Mapping is final per Joseph's 2026-05-29 UX-richness pick:
#   1 gold→Gold  2 dark_blue→Azure  3 dark_green→Forest  4 dark_aqua→Teal
#   5 gray→Ash  6 light_purple→Lilac  7 black→Shadow  8 aqua→Aqua
#   9 yellow→Sunbright  10 white→Snow  11 dark_gray→Iron  12 dark_purple→Royal
#  13 green→Verdant  14 blue→Ocean
# Default (no slot match — should never fire post-W18 since cleanup_player zeroes pty_clr,
# but defensive) → "Party".
data modify storage evercraft:party temp.color_name set value "Party"
execute if score @s ec.pty_clr matches 1 run data modify storage evercraft:party temp.color_name set value "Gold Party"
execute if score @s ec.pty_clr matches 2 run data modify storage evercraft:party temp.color_name set value "Azure Party"
execute if score @s ec.pty_clr matches 3 run data modify storage evercraft:party temp.color_name set value "Forest Party"
execute if score @s ec.pty_clr matches 4 run data modify storage evercraft:party temp.color_name set value "Teal Party"
execute if score @s ec.pty_clr matches 5 run data modify storage evercraft:party temp.color_name set value "Ash Party"
execute if score @s ec.pty_clr matches 6 run data modify storage evercraft:party temp.color_name set value "Lilac Party"
execute if score @s ec.pty_clr matches 7 run data modify storage evercraft:party temp.color_name set value "Shadow Party"
execute if score @s ec.pty_clr matches 8 run data modify storage evercraft:party temp.color_name set value "Aqua Party"
execute if score @s ec.pty_clr matches 9 run data modify storage evercraft:party temp.color_name set value "Sunbright Party"
execute if score @s ec.pty_clr matches 10 run data modify storage evercraft:party temp.color_name set value "Snow Party"
execute if score @s ec.pty_clr matches 11 run data modify storage evercraft:party temp.color_name set value "Iron Party"
execute if score @s ec.pty_clr matches 12 run data modify storage evercraft:party temp.color_name set value "Royal Party"
execute if score @s ec.pty_clr matches 13 run data modify storage evercraft:party temp.color_name set value "Verdant Party"
execute if score @s ec.pty_clr matches 14 run data modify storage evercraft:party temp.color_name set value "Ocean Party"
