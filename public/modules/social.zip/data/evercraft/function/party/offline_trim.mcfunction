# Macro: trim offline members from the party after 10-min timeout
# Arg: pid (party ID)

# Announce to remaining online members — §5 static broadcast (stage once, emit per member).
data modify storage evercraft:notify stage.c set value [{text:"Offline members have been removed.",color:"gray"}]
scoreboard players set #ndur ec.temp 45
$execute as @a[scores={ec.party_id=$(pid)}] run function evercraft:util/notify/emit

# Update party_size to current online count for all online members
$execute as @a[scores={ec.party_id=$(pid)}] store result score @s ec.party_size if entity @a[scores={ec.party_id=$(pid)}]

# Reset disconnect timer for all online members
$execute as @a[scores={ec.party_id=$(pid)}] run scoreboard players set @s ec.party_dc 0

# If only 1 member remains, auto-disband
$execute store result score #trim_ct ec.temp if entity @a[scores={ec.party_id=$(pid)}]
# Return color to pool before auto-disband cleanup
$execute if score #trim_ct ec.temp matches ..1 as @a[scores={ec.party_id=$(pid),ec.pty_clr=1..},limit=1] run function evercraft:party/color/return_from_self
# §5 static broadcast — stage once, fold the gate + selector into one execute.
data modify storage evercraft:notify stage.c set value [{text:"Party has been disbanded (not enough members).",color:"gray"}]
scoreboard players set #ndur ec.temp 45
$execute if score #trim_ct ec.temp matches ..1 as @a[scores={ec.party_id=$(pid)}] run function evercraft:util/notify/emit
$execute if score #trim_ct ec.temp matches ..1 as @a[scores={ec.party_id=$(pid)}] run function evercraft:party/cleanup_player
