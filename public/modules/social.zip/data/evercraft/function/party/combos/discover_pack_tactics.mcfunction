# Pack Tactics — First-time discovery notification
# Set bit 7 (value 128) in unlocked bitfield

# Check if already discovered (bit 7 = 128)
scoreboard players set #disc ec.temp 0
scoreboard players operation #disc ec.temp = @s ec.pc_unlocked
scoreboard players operation #disc ec.temp /= #bit7 ec.const
scoreboard players operation #disc ec.temp %= #bit1 ec.const
execute if score #disc ec.temp matches 1 run return 0

# Mark discovered
scoreboard players add @s ec.pc_unlocked 128

# Lifetime party-combos-discovered counter (gated once-per-combo by the bit-check return above)
scoreboard players add @s ec.pc_count 1

# Wiring Audit #16 polish-wave AU17 (AU16-FOLLOWUP.7, Joseph 2026-05-29): achievement
# parity with active combos. Passive combos fire once-per-discovery (gated by the
# bitfield check above) so this counts the same as active combos' per-event +1 —
# players see passive combos as 'real' achievements toward p15 Party Legend / s38 Combo King.
scoreboard players add @s ach.combos_triggered 1

# Announce
data modify storage evercraft:notify stage.c set value [{text:"COMBO UNLOCKED: ",color:"gold",bold:true},{text:"Pack Tactics",color:"green"}]
scoreboard players set #ndur ec.temp 50
function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"When 2+ Beastmasters (Lv.15+) are nearby, all party pets gain boosted abilities.",color:"gray"}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.experience_orb.pickup player @s ~ ~ ~ 1 1.5
