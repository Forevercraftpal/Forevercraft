# Marked for Death — First-time discovery (bit 1 = value 1)
scoreboard players set #disc ec.temp 0
scoreboard players operation #disc ec.temp = @s ec.pc_unlocked
scoreboard players operation #disc ec.temp %= #2 adv.temp
execute if score #disc ec.temp matches 1.. run return 0

scoreboard players add @s ec.pc_unlocked 1
# Lifetime party-combos-discovered counter (gated once-per-combo by the bit-check return above)
scoreboard players add @s ec.pc_count 1
data modify storage evercraft:notify stage.c set value [{text:"COMBO UNLOCKED: ",color:"gold",bold:true},{text:"Marked for Death",color:"light_purple"}]
scoreboard players set #ndur ec.temp 50
function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Sneak near a mob as Stealth (10+) — Victorian allies deal +25% damage!",color:"gray"}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.experience_orb.pickup player @s ~ ~ ~ 1 1.5
