# Forge Bond — First-time discovery notification (bit 6 = value 64)

scoreboard players set #disc ec.temp 0
scoreboard players operation #disc ec.temp = @s ec.pc_unlocked
scoreboard players operation #disc ec.temp /= #bit6 ec.const
scoreboard players operation #disc ec.temp %= #bit1 ec.const
execute if score #disc ec.temp matches 1 run return 0

# Mark discovered
scoreboard players add @s ec.pc_unlocked 64

# Lifetime party-combos-discovered counter (gated once-per-combo by the bit-check return above)
scoreboard players add @s ec.pc_count 1

# Announce
data modify storage evercraft:notify stage.c set value [{text:"COMBO UNLOCKED: ",color:"gold",bold:true},{text:"Forge Bond",color:"dark_red"}]
scoreboard players set #ndur ec.temp 50
function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Use a smithing table as Blacksmith (15+) — both you and a nearby Dexterity ally gain bonus XP!",color:"gray"}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.experience_orb.pickup player @s ~ ~ ~ 1 1.5
