# Shared Fortunes — Roll for bonus drop
# Run as the potential recipient, at their position
# 20% chance (random 1-5, succeed on 1)

execute store result score #fortune_roll ec.temp run random value 1..5
execute unless score #fortune_roll ec.temp matches 1 run return 0

# Give 3 XP levels as a bonus (simple, meaningful, no item duplication complexity)
function evercraft:util/xp_levels {n:3}
execute if score @s ec.fx_vis matches 1.. run particle minecraft:happy_villager ~ ~1 ~ 0.5 0.5 0.5 0 10 force @s
data modify storage evercraft:notify stage.c set value [{text:"Shared Fortunes! ",color:"aqua"},{text:"+3 XP levels",color:"green"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.experience_orb.pickup player @s ~ ~ ~ 0.5 1.2
