# Marked for Death — +25% damage to a marked target the player just hit
# Wiring Audit #16 W2.3 — was non-functional since party-combos shipped (tag set, no consumer)
# Run as: player, from advantage/track/on_attack (after companions/roar/on_hit).
# Conditions: player in a party with Victorian 10+, target has ec.party_marked tag.

# Gate 1: must be in a party
execute unless score @s ec.party_id matches 1.. run return 0
# Gate 2: must be Victorian 10+ (matches discover_marked tellraw advertised gate)
execute unless score @s adv.victorian matches 10.. run return 0

# Locate the enemy the player just hit that carries the marked tag (nearest within 6 blocks)
tag @e[type=#evercraft:aoe_targets,tag=ec.party_marked,distance=..6,sort=nearest,limit=1] add ec.pty_dmg_target
execute unless entity @e[tag=ec.pty_dmg_target,limit=1] run return 0

# Apply +25% bonus damage (flat +2, matches +25% of typical ~6-damage melee). Attributed to attacker.
execute at @e[tag=ec.pty_dmg_target,limit=1] run damage @e[tag=ec.pty_dmg_target,limit=1] 2 player_attack by @s

# Light VFX cue
execute at @e[tag=ec.pty_dmg_target,limit=1] run particle minecraft:crit ~ ~1 ~ 0.5 0.5 0.5 0.3 8

# Achievement parity: credit Marked for Death combo on hit (event-side credit)
scoreboard players add @s ach.combos_triggered 1

# Cleanup target tag
tag @e[tag=ec.pty_dmg_target] remove ec.pty_dmg_target
