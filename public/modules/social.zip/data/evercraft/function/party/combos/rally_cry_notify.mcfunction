# Rally Cry notification (macro)
# Arg: pid

# §5b actor-name broadcast — direct render so {selector:"@s"} resolves to the triggerer once.
# (The former second `title @a actionbar` flavor line was dropped — it fired on the same tick
#  and instantly overwrote this frame on the action bar; the actor announce is the payload.)
# (Wave 2, 2026-06-10: party combo echo — whoami-baked, 15s TTL.)
function evercraft:util/notify/whoami
data modify storage evercraft:notify stage.c set value [{text:"",color:"dark_aqua"},{text:" triggered Rally Cry! ",color:"yellow"},{text:"+2 Dream Rate for 5 min!",color:"light_purple"}]
data modify storage evercraft:notify stage.c[0].text set from storage evercraft:notify named.who
scoreboard players set #ndur ec.temp 45
$execute as @a[scores={ec.party_id=$(pid)}] run scoreboard players set #nttl ec.temp 300
$execute as @a[scores={ec.party_id=$(pid)}] run function evercraft:util/notify/emit
$playsound minecraft:ui.toast.challenge_complete player @a[scores={ec.party_id=$(pid),ec.fx_snd=1..}] ~ ~ ~ 0.6 1.0
