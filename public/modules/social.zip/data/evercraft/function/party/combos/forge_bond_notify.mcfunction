# Forge Bond notification (macro)
# Arg: pid

# §5b actor-name broadcast — direct render so {selector:"@s"} resolves to the triggerer once.
# (Wave 2, 2026-06-10: party combo echo — whoami-baked, 15s TTL.)
function evercraft:util/notify/whoami
data modify storage evercraft:notify stage.c set value [{text:"",color:"gray"},{text:" activated Forge Bond! ",color:"yellow"},{text:"+50 Advantage XP!",color:"green"}]
data modify storage evercraft:notify stage.c[0].text set from storage evercraft:notify named.who
scoreboard players set #ndur ec.temp 45
$execute as @a[scores={ec.party_id=$(pid)}] run scoreboard players set #nttl ec.temp 300
$execute as @a[scores={ec.party_id=$(pid)}] run function evercraft:util/notify/emit
$playsound minecraft:block.anvil.use player @a[scores={ec.party_id=$(pid),ec.fx_snd=1..},distance=..16] ~ ~ ~ 0.5 1.0
