# Party Menu — Leader Options
# Show invite, disband, ping, and member list
# Wiring Audit #19 W4 (AU18-FOLLOWUP.5): derive player-facing color name before the macro
# so the menu header reads "Aqua Party [N/4]" instead of just "Party [N/4]".

execute store result storage evercraft:party temp.size int 1 run scoreboard players get @s ec.party_size
function evercraft:party/color/get_name
function evercraft:party/menu/show_leader_macro with storage evercraft:party temp
