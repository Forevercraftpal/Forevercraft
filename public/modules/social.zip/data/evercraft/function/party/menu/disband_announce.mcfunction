# Announce party disbanding (macro)
# Arg: pid

# §5 static broadcast — stage once, emit per party member (no actor reference in the text).
data modify storage evercraft:notify stage.c set value [{text:"The party has been disbanded by the leader.",color:"red"}]
scoreboard players set #ndur ec.temp 45
$execute as @a[scores={ec.party_id=$(pid)}] run function evercraft:util/notify/emit
$playsound minecraft:block.note_block.bass player @a[scores={ec.party_id=$(pid),ec.fx_snd=1..}] ~ ~ ~ 1 0.5
