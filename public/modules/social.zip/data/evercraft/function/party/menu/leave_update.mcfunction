# Update party size after a member leaves (macro)
# Arg: pid

# Recount party size
$execute as @a[scores={ec.party_id=$(pid)}] store result score @s ec.party_size if entity @a[scores={ec.party_id=$(pid)}]

# If only 1 member left, auto-disband
$execute store result score #leave_ct ec.temp if entity @a[scores={ec.party_id=$(pid)}]
# Return color to pool before auto-disband cleanup
$execute if score #leave_ct ec.temp matches ..1 as @a[scores={ec.party_id=$(pid),ec.pty_clr=1..},limit=1] run function evercraft:party/color/return_from_self
# Notify before cleanup (cleanup resets party IDs, so the broadcast must come first).
# §5 static broadcast — stage once, fold the gate + selector into one execute.
data modify storage evercraft:notify stage.c set value [{text:"Party has been disbanded (not enough members).",color:"gray"}]
scoreboard players set #ndur ec.temp 45
$execute if score #leave_ct ec.temp matches ..1 as @a[scores={ec.party_id=$(pid)}] run function evercraft:util/notify/emit
$execute if score #leave_ct ec.temp matches ..1 as @a[scores={ec.party_id=$(pid)}] run function evercraft:party/cleanup_player

# Wiring Audit #16 W4.2: leader-only-leave auto-promote
# If party still has 2+ members AND no online leader (the leaving leader cleared their role in cleanup_player),
# auto-promote the first remaining role=2 member instead of waiting 5 min for check_leader_macro:16.
# limit=1 with sequential as @a iteration picks a deterministic single promotee.
$execute if score #leave_ct ec.temp matches 2.. unless entity @a[scores={ec.party_id=$(pid),ec.party_role=1}] as @a[scores={ec.party_id=$(pid),ec.party_role=2},limit=1] run function evercraft:party/promote_self
