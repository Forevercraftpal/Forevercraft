# Disband Party — Leader dissolves the group
# Run as the party leader

# Must be a leader
data modify storage evercraft:notify stage.c set value [{text:"Only the party leader can disband.",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute unless score @s ec.party_role matches 1 run return run function evercraft:util/notify/emit

# Store party ID for announcement
execute store result storage evercraft:party temp.pid int 1 run scoreboard players get @s ec.party_id

# Return party color to pool before cleanup resets scores
function evercraft:party/color/return_from_self

# Announce to all party members
function evercraft:party/menu/disband_announce with storage evercraft:party temp

# Clean up all members
function evercraft:party/menu/disband_cleanup with storage evercraft:party temp
