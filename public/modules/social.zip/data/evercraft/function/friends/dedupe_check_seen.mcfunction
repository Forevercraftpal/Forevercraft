# Friend System — Dedupe step: if uuid3 not in `seen`, keep entry + add uuid3 to `seen`.
# Macro arg: dedupe_cur_uuid3

$execute unless data storage evercraft:friends temp.dedupe_seen[{uuid3:$(dedupe_cur_uuid3)}] run data modify storage evercraft:friends temp.dedupe_out append from storage evercraft:friends temp.dedupe_in[0]
$execute unless data storage evercraft:friends temp.dedupe_seen[{uuid3:$(dedupe_cur_uuid3)}] run data modify storage evercraft:friends temp.dedupe_seen append value {uuid3:$(dedupe_cur_uuid3)}
