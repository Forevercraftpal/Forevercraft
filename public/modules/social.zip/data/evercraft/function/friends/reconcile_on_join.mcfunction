# Friend System — Reconcile player scoreboard caches against authoritative storage (on join)
# Wiring Audit #32 W3 (race F3): ec.fr_married / ec.fr_count are caches of u<self> storage.
# They can drift when the OTHER player is offline at mutation time:
#   - Divorce/remove-spouse clears married_to in storage on both records, but only sets the
#     offline spouse's ec.fr_married=0 if they're online → an offline-divorced player logs back
#     in still flagged married=1 and is permanently blocked from proposing ("already married").
#   - Same-tick mutual accept can over-count ec.fr_count.
# This re-derives both flags from storage so the scoreboards are pure caches.
# @s = the joining player.

execute store result score #fr_rec_self ec.temp run data get entity @s UUID[3]
execute store result storage evercraft:friends temp.rec_self_uuid3 int 1 run scoreboard players get #fr_rec_self ec.temp
function evercraft:friends/reconcile_on_join_do with storage evercraft:friends temp
