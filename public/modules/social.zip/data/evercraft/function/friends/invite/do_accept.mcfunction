# Friend Invite — Macro: perform storage operations for accept
# Macro args: accepter_uuid3, sender_uuid3, accepter_cid, sender_cid

# Initialize both player storages if needed
$execute unless data storage evercraft:friends "u$(accepter_uuid3)" run data modify storage evercraft:friends "u$(accepter_uuid3)" set value {friends:[],married_to:0,friend_count:0,gift_queue:[],last_daily_day:0}
$execute unless data storage evercraft:friends "u$(sender_uuid3)" run data modify storage evercraft:friends "u$(sender_uuid3)" set value {friends:[],married_to:0,friend_count:0,gift_queue:[],last_daily_day:0}

# Capture pre-state: were they already friends? (snapshot BEFORE the appends below)
# #fr_was_dupe=1 means accepter already had sender in their list; skip the realm increment.
scoreboard players set #fr_was_dupe ec.temp 0
$execute if data storage evercraft:friends "u$(accepter_uuid3)".friends[{uuid3:$(sender_uuid3)}] run scoreboard players set #fr_was_dupe ec.temp 1

# Add sender to accepter's friend list (cid = companion.id for selector-based name display)
# Dedupe guard: only append if sender isn't already in the list.
$execute unless data storage evercraft:friends "u$(accepter_uuid3)".friends[{uuid3:$(sender_uuid3)}] run data modify storage evercraft:friends "u$(accepter_uuid3)".friends append value {uuid3:$(sender_uuid3),cid:$(sender_cid),hearts:0,title:"friend",daily_heart:0b,gift_streak:0,sent_gift_today:0b}

# Add accepter to sender's friend list (same dedupe guard)
$execute unless data storage evercraft:friends "u$(sender_uuid3)".friends[{uuid3:$(accepter_uuid3)}] run data modify storage evercraft:friends "u$(sender_uuid3)".friends append value {uuid3:$(accepter_uuid3),cid:$(accepter_cid),hearts:0,title:"friend",daily_heart:0b,gift_streak:0,sent_gift_today:0b}

# Realm milestone: friendship formed — only if this wasn't a re-accept of an existing friendship
execute if score #fr_was_dupe ec.temp matches 0 run function evercraft:milestones/increment/friend_made
