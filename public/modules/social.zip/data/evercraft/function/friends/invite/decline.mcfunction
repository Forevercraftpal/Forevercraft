# Friend Invite — Decline friend request
# @s = declining player

tag @s remove ec.fr_pending
data modify storage evercraft:notify stage.c set value [{text:"Friend request declined.",color:"gray"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
scoreboard players set @s ec.fr_target 0
