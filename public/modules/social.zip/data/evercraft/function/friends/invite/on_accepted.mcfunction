# Friend Invite — Notify sender that their request was accepted
# @s = sender player (found by UUID3 match)

scoreboard players add @s ec.fr_count 1
data modify storage evercraft:notify stage.c set value [{text:"Your friend request was accepted!",color:"green"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.player.levelup master @s ~ ~ ~ 0.5 1.5
