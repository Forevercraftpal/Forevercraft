# Friend System — Per-player tick
# OPT: Consolidates 2 @a[scores={ec.fr_count=1..}] scans into 1
# Run as: player with friends (ec.fr_count=1+), at player

function evercraft:friends/heart/check_proximity
# Wiring Audit #32 W2 (perf F2 / D3): buff/apply runs only every #fr_buff_cadence s (default 5),
# not every 1s — #fr_buff_now is set once per tick in friends/tick. Proximity hearts stay at 1Hz
# (they count consecutive seconds). Idempotent reapply makes the slower cadence safe.
execute if score #fr_buff_now ec.var matches 1 run function evercraft:friends/buff/apply
