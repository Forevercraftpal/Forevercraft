# Friend System — Dedupe macro: walks "u<self_uuid3>".friends and rebuilds it without dupes.
# Macro arg: self_uuid3

# No-op if the player has no storage yet
$execute unless data storage evercraft:friends "u$(self_uuid3)" run return 0
$execute unless data storage evercraft:friends "u$(self_uuid3)".friends[0] run return 0

# Stage the source list into temp.dedupe_in, init empty output + seen set
$data modify storage evercraft:friends temp.dedupe_in set from storage evercraft:friends "u$(self_uuid3)".friends
data modify storage evercraft:friends temp.dedupe_out set value []
data modify storage evercraft:friends temp.dedupe_seen set value []

function evercraft:friends/dedupe_loop

# Write the deduped list back
$data modify storage evercraft:friends "u$(self_uuid3)".friends set from storage evercraft:friends temp.dedupe_out

# Resync ec.fr_count to actual list length (in case duplicates were collapsed)
$execute store result score @s ec.fr_count run data get storage evercraft:friends "u$(self_uuid3)".friends

# Clean temp keys
data remove storage evercraft:friends temp.dedupe_in
data remove storage evercraft:friends temp.dedupe_out
data remove storage evercraft:friends temp.dedupe_seen
