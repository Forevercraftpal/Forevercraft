# Friend System — Tick (runs every 1s via schedule)
# Handles: proximity heart checks, buff application, trigger processing
#
# INVARIANT (race-safety, Wiring Audit #32): every input-handler chain dispatched below
# (trigger_handler / gift/send / marriage/trigger_handler / title/set / remove) runs
# synchronously to completion within ONE tick. The shared single-key temp.* storage scratch
# and #fr_* fake-players are race-safe ONLY because of this. Do NOT add `schedule`/yield inside
# any handler chain — it would let player B clobber player A's scratch mid-chain (live race).

# Gate: skip if no players online
execute unless entity @a run return run schedule function evercraft:friends/tick 1s

# === TRIGGER PROCESSING ===
# Friend invite accept/decline
execute as @a[scores={ec.fr_invite=1..}] run function evercraft:friends/trigger_handler
execute as @a[scores={ec.fr_invite=..-1}] run function evercraft:friends/trigger_handler

# Gift send
execute as @a[scores={ec.fr_gift=1..}] run function evercraft:friends/gift/send

# Marriage propose/accept/divorce
execute as @a[scores={ec.fr_marry=1..}] run function evercraft:friends/marriage/trigger_handler
execute as @a[scores={ec.fr_marry=..-1}] run function evercraft:friends/marriage/trigger_handler

# AU14-X2 (Wave L, 2026-05-31): the ec.fr_title raw-trigger dispatch is RETIRED. The codex
# GUI (codex/friends/do_detail_title) is the canonical entry — it bypasses the trigger decode
# (which was latently broken for UUID3 >= 1,000,000 per AU36-2) by setting post-decode scores
# directly, then calls friends/title/do_set. Removing the trigger path per the no-user-triggers law.

# Remove friend — UUID3 can be negative (signed 32-bit int), so dispatch on both signs.
execute as @a[scores={ec.fr_remove=1..}] run function evercraft:friends/remove
execute as @a[scores={ec.fr_remove=..-1}] run function evercraft:friends/remove

# OPT: Removed blanket enable @a — each trigger handler re-enables @s after processing,
# and load + on_join handle first-time/reconnect enables

# === PROXIMITY HEARTS + BUFFS (proximity every 1s, buffs every #fr_buff_cadence s) ===
# OPT: 2 @a scans → 1 per-player function call.
# Wiring Audit #32 W2 (perf F2 / D3): advance the global buff-cadence counter ONCE per tick
# (before the @a loop) and set #fr_buff_now so every player in this tick agrees on buff-or-not.
# buff/apply is idempotent (remove-before-add) so a 5s reapply cadence is behavior-safe.
scoreboard players add #fr_buff_tick ec.var 1
scoreboard players set #fr_buff_now ec.var 0
execute if score #fr_buff_tick ec.var >= #fr_buff_cadence ec.const run scoreboard players set #fr_buff_now ec.var 1
execute if score #fr_buff_tick ec.var >= #fr_buff_cadence ec.const run scoreboard players set #fr_buff_tick ec.var 0
execute as @a[scores={ec.fr_count=1..}] at @s run function evercraft:friends/player_tick

# === TITLE NOTIFICATION CHECK (1-minute delayed notifications) ===
# Wiring Audit #32 W2 (perf F1): gate behind the global pending counter so the unconditional
# every-1s @a scan only runs when ≥1 title notify is actually outstanding (the common case is 0).
# Steady-state cost: a single `if score` comparison/s instead of O(online-players)/s.
execute if score #fr_pending_notify ec.var matches 1.. run function evercraft:friends/title/check_pending_notify

# Reschedule
schedule function evercraft:friends/tick 1s
