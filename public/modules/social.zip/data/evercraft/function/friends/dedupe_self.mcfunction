# Friend System — Dedupe @s's friends list (auto-runs on join via dreams/on_join).
# Removes duplicate entries (same uuid3 appearing more than once), then resyncs ec.fr_count.

# Skip if storage doesn't exist yet (player hasn't initialized a list)
execute store result score #fr_dedupe_self ec.temp run data get entity @s UUID[3]
execute store result storage evercraft:friends temp.self_uuid3 int 1 run scoreboard players get #fr_dedupe_self ec.temp
function evercraft:friends/dedupe_macro with storage evercraft:friends temp
