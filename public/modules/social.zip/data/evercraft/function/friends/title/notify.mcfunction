# Friend Title — Macro: notify player of title change
# Macro args: new_title
$data modify storage evercraft:notify stage.c set value [{text:"Title set to ",color:"light_purple"},{text:"$(new_title)",color:"yellow"},{text:".",color:"light_purple"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
