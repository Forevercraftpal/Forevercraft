# Friend Title — Evolution notification message
# @s = player, macro args: evo_display
$data modify storage evercraft:notify stage.c set value [{text:"A title you hold has evolved into ",color:"light_purple"},{text:"$(evo_display)",color:"gold",bold:true},{text:"!",color:"light_purple"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
