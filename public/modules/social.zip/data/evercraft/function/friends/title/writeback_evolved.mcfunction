# Friend Title — Write an evolved title back to the SETTER's friends-list copy
# Wiring Audit #32 W1 (D1): title evolution mutates u<receiver>.titles_received[].title,
# but the codex friend-detail panel renders u<setter>.friends[].title — a different store.
# This writes the evolved string back to the setter's copy so the GUI shows the evolved form.
#
# Caller context: evolution_loop, with temp.evo_list[0] = the just-evolved received-title entry
#   (fields: title = evolved string, from_uuid3 = setter's UUID3, granted_day)
#   and storage temp.evo_uuid3 = the receiver's UUID3 (set in check_evolution_player).

# Stage the do_set macro args: setter = from_uuid3 (whose friends-list copy to update),
# receiver = evo_uuid3 (the friend entry to find), new_title = evolved string.
data modify storage evercraft:friends temp.self_uuid3 set from storage evercraft:friends temp.evo_list[0].from_uuid3
data modify storage evercraft:friends temp.title_target_uuid3 set from storage evercraft:friends temp.evo_uuid3
data modify storage evercraft:friends temp.new_title set from storage evercraft:friends temp.evo_list[0].title

# do_set finds the friend entry for title_target_uuid3 in u<self_uuid3>.friends and sets its .title
# to temp.new_title. (Reuses temp.title_list/title_result scratch — distinct from the evo_* keys,
# so the surrounding evolution_loop iteration is unaffected.)
function evercraft:friends/title/do_set with storage evercraft:friends temp
