# Friend System — Dedupe loop: pop one entry, keep it only if its uuid3 isn't already in `seen`.

execute unless data storage evercraft:friends temp.dedupe_in[0] run return 0

# Pull current uuid3 into a macro slot
execute store result score #fr_dedupe_cur ec.temp run data get storage evercraft:friends temp.dedupe_in[0].uuid3
execute store result storage evercraft:friends temp.dedupe_cur_uuid3 int 1 run scoreboard players get #fr_dedupe_cur ec.temp

# If not seen yet → append to output AND mark as seen
function evercraft:friends/dedupe_check_seen with storage evercraft:friends temp

# Pop and recurse
data remove storage evercraft:friends temp.dedupe_in[0]
function evercraft:friends/dedupe_loop
