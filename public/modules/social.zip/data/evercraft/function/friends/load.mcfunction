# ============================================================
# Friend System — Load
# Scoreboards, triggers, storage initialization
# ============================================================

# === PER-PLAYER SCOREBOARDS ===
scoreboard objectives add ec.fr_count dummy "Friend Count"
scoreboard objectives add ec.fr_married dummy "Is Married"
scoreboard objectives add ec.fr_best_nearby dummy "Best Friends Nearby"
scoreboard objectives add ec.fr_spouse_near dummy "Spouse Nearby"
scoreboard objectives add ec.fr_page dummy "Friends Menu Page"
scoreboard objectives add ec.fr_target dummy "Friend Target UUID3"
scoreboard objectives add ec.fr_target_cid dummy "Friend Target CID"
# Wiring Audit #32 W4: declare ec.gift_cd defensively (also declared in admin/init.mcfunction:518).
# Makes the branch self-contained — closes the first-gift cooldown-bypass edge if init load-order ever drifts.
scoreboard objectives add ec.gift_cd dummy "Gift Cooldown"

# === TRIGGERS ===
scoreboard objectives add ec.fr_invite trigger "Friend Invite"
scoreboard objectives add ec.fr_gift trigger "Friend Gift"
scoreboard objectives add ec.fr_marry trigger "Marriage"
# AU14-X2 (Wave L, 2026-05-31): ec.fr_title trigger decl + enable REMOVED. Family titles are
# set exclusively through the codex GUI (codex/friends/do_detail_title -> friends/title/do_set);
# the raw-trigger path (friends/title/set) was latently broken (AU36-2) and is now archived.
scoreboard objectives add ec.fr_remove trigger "Remove Friend"

# Enable triggers for all online players
scoreboard players enable @a ec.fr_invite
scoreboard players enable @a ec.fr_gift
scoreboard players enable @a ec.fr_marry
scoreboard players enable @a ec.fr_remove

# === TEMP SCOREBOARDS ===
# #fr_ray ec.temp — raycast step counter
# #fr_target_uuid3 ec.temp — target's UUID[3]
# #fr_hearts ec.temp — heart count for current pair
# #fr_level ec.temp — friendship level (0-4)

# === CONSTANTS (single source of truth — Wiring Audit #32 D2 wired these LIVE) ===
# All friends/ logic now READS these via score comparison (`if score #x ec.temp >= #fr_best ec.const`).
# Edit a value here + /reload to retune every reader. The #48 range is the ONE exception (selector
# literal — can't read a scoreboard inside @a[distance=...]; each 48-block selector carries a
# `# range = #48` comment so grep still routes here).
scoreboard players set #fr_max_friends ec.const 50
scoreboard players set #fr_good ec.const 7
scoreboard players set #fr_great ec.const 30
scoreboard players set #fr_ultra ec.const 60
scoreboard players set #fr_best ec.const 90
scoreboard players set #fr_prox_time ec.const 60
scoreboard players set #fr_tp_cooldown ec.const 144000
scoreboard players set #48 ec.const 48
# Wiring Audit #32 W4 (correctness F2): dedicated gift cooldown — DO NOT reuse #fr_tp_cooldown
# (that's the showcase-teleport cooldown, a different feature). 144000gt = 2 in-game days.
scoreboard players set #fr_gift_cooldown ec.const 144000
# Wiring Audit #32 W2 (perf F2 / D3): buff/apply cadence in 1s ticks. buff/apply is idempotent
# (removes-before-adds) so a 5s reapply is safe; proximity hearts stay at 1Hz. Single-edit tune.
scoreboard players set #fr_buff_cadence ec.const 5
# Wiring Audit #32 W2 (perf F1): global pending-title-notify counter — gates the unconditional
# every-1s @a notify scan (tick:34) so it only runs when ≥1 notify is actually outstanding.
# Sole writer of pending_title_notify is title/update_unlock; sole clearer is title/check_pending_inner.
scoreboard players set #fr_pending_notify ec.var 0
# Wiring Audit #32 W2 (perf F2): global buff-cadence tick counter (counts up to #fr_buff_cadence)
# and the per-tick "run buffs this tick?" flag (1 on cadence ticks, 0 otherwise).
scoreboard players set #fr_buff_tick ec.var 0
scoreboard players set #fr_buff_now ec.var 0

# === PROXIMITY TIMER ===
# Per-player: tracks consecutive seconds near a friend
scoreboard objectives add ec.fr_prox_timer dummy "Friend Proximity Timer"
scoreboard objectives add ec.temp_uuid3 dummy "Temp UUID3 Match"

# === STORAGE INITIALIZATION ===
# Friends registry: { "u<uuid3>": { friends: [...], married_to: 0, friend_count: 0, gift_queue: [] } }
execute unless data storage evercraft:friends {} run data merge storage evercraft:friends {}

# === SHOWCASE SYSTEM ===
function evercraft:codex/friends/showcase/load

# === START TICK SCHEDULE ===
schedule function evercraft:friends/tick 1s replace
