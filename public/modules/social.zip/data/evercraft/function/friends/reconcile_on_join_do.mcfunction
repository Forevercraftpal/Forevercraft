# Friend System — Reconcile macro (Wiring Audit #32 W3, race F3)
# Macro arg: rec_self_uuid3
# @s = joining player. Re-derives ec.fr_married + ec.fr_count from u<self> storage.

# No storage record yet → both caches are 0 (new player).
$execute unless data storage evercraft:friends "u$(rec_self_uuid3)" run scoreboard players set @s ec.fr_married 0
$execute unless data storage evercraft:friends "u$(rec_self_uuid3)" run scoreboard players set @s ec.fr_count 0
$execute unless data storage evercraft:friends "u$(rec_self_uuid3)" run return 0

# === Reconcile ec.fr_married from storage married_to ===
# Read married_to into a score (absent field → store leaves it untouched, so seed 0 first).
scoreboard players set #fr_rec_married ec.temp 0
$execute store result score #fr_rec_married ec.temp run data get storage evercraft:friends "u$(rec_self_uuid3)".married_to
# married_to is a UUID3 (signed 32-bit, can be negative) or 0/absent. Non-zero ⇒ married.
scoreboard players set @s ec.fr_married 0
execute unless score #fr_rec_married ec.temp matches 0 run scoreboard players set @s ec.fr_married 1

# === Reconcile ec.fr_count from friends list length ===
# `data get` on a list returns its element count (same pattern as dedupe_macro:19).
scoreboard players set @s ec.fr_count 0
$execute if data storage evercraft:friends "u$(rec_self_uuid3)".friends run store result score @s ec.fr_count run data get storage evercraft:friends "u$(rec_self_uuid3)".friends
