# Marriage — Decline proposal
# @s = declining player

tag @s remove ec.fr_marry_pending
data modify storage evercraft:notify stage.c set value [{text:"Proposal declined.",color:"gray"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
scoreboard players set @s ec.fr_target 0
