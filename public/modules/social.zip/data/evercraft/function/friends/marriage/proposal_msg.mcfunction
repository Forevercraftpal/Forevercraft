# Marriage — Macro: display proposal message
# Macro args: proposer_cid
$data modify storage evercraft:notify stage.c set value [{selector:"@a[scores={companion.id=$(proposer_cid)},limit=1]",color:"yellow"},{text:" has proposed marriage!",color:"light_purple"}]
scoreboard players set #ndur ec.temp 50
function evercraft:util/notify/emit
tellraw @s [{text:"  "},{text:"[Accept]",color:"green",bold:true,click_event:{action:"run_command",command:"/trigger ec.fr_marry set 1"},hover_event:{action:"show_text",value:{text:"Accept proposal",color:"green"}}},{text:"  "},{text:"[Decline]",color:"red",bold:true,click_event:{action:"run_command",command:"/trigger ec.fr_marry set -1"},hover_event:{action:"show_text",value:{text:"Decline proposal",color:"red"}}}]
