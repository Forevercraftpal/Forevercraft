# Friend Gift — Deliver gift crate to online recipient
# @s = recipient player, #fr_gift_tier ec.temp = crate tier (1-6)

scoreboard players set #fr_gift_delivered ec.temp 1

# Give crate based on tier
# Inv-full guard: drop at the player's feet rather than void on a full inventory.
execute store result score #inv_full ec.var run function evercraft:util/check_inv_full
execute if score #fr_gift_tier ec.temp matches 1 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:achievements/crates/common
execute if score #fr_gift_tier ec.temp matches 1 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:achievements/crates/common
execute if score #fr_gift_tier ec.temp matches 2 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:achievements/crates/uncommon
execute if score #fr_gift_tier ec.temp matches 2 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:achievements/crates/uncommon
execute if score #fr_gift_tier ec.temp matches 3 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:achievements/crates/rare
execute if score #fr_gift_tier ec.temp matches 3 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:achievements/crates/rare
execute if score #fr_gift_tier ec.temp matches 4 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:achievements/crates/ornate
execute if score #fr_gift_tier ec.temp matches 4 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:achievements/crates/ornate
execute if score #fr_gift_tier ec.temp matches 5 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:achievements/crates/exquisite
execute if score #fr_gift_tier ec.temp matches 5 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:achievements/crates/exquisite
execute if score #fr_gift_tier ec.temp matches 6 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:achievements/crates/mythical
execute if score #fr_gift_tier ec.temp matches 6 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:achievements/crates/mythical

# Get tier name for message
function evercraft:friends/gift/get_tier_name

# Notify recipient
function evercraft:friends/gift/notify_recipient with storage evercraft:friends temp
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.player.levelup master @s ~ ~ ~ 0.5 1.5

# Grant heart to receiver for sender friend
# #fr_self_uuid3 ec.temp = sender's UUID3 (from send.mcfunction context)
execute store result storage evercraft:friends temp.gift_sender_uuid3 int 1 run scoreboard players get #fr_self_uuid3 ec.temp
function evercraft:friends/gift/grant_receiver_heart
