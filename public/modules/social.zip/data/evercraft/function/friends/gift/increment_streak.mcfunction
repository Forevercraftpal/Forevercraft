# Friend Gift — Mark sent_gift_today on sender's entry for the gift target
# AU14-X1 (Wave L, 2026-05-31): the gifts_no_return tracking (sender-increment + recipient-reset)
# was removed with the divorce-path archive. Only the sender-side pass remains — it marks
# sent_gift_today, which daily_reset_streak + login_streak* consume for the mutual gift_streak.
# The recipient-reset pass was a pure gifts_no_return no-op after the archive and is gone.
# Macro args: self_uuid3 (sender), gift_target_uuid3 (recipient)

# === Mark sender's sent_gift_today on their entry for the target ===
$data modify storage evercraft:friends temp.streak_list set from storage evercraft:friends "u$(self_uuid3)".friends
data modify storage evercraft:friends temp.streak_result set value []
$scoreboard players set #fr_streak_find ec.temp $(gift_target_uuid3)
scoreboard players set #fr_streak_mode ec.temp 1
function evercraft:friends/gift/streak_loop
$data modify storage evercraft:friends "u$(self_uuid3)".friends set from storage evercraft:friends temp.streak_result
