# Friend Gift — Streak loop: find sender's friend entry, mark sent_gift_today
# AU14-X1 (Wave L, 2026-05-31): the gifts_no_return increment/reset logic was removed with the
# divorce-path archive. This loop now only ensures the gift_streak field exists + marks
# sent_gift_today on the sender's matched entry. sent_gift_today is consumed by
# daily_reset_streak + login_streak* to maintain the mutual gift_streak reward.
# #fr_streak_find ec.temp = target uuid3 to find
# #fr_streak_mode ec.temp = 1 (only mode passed since the recipient-reset pass was removed)

execute unless data storage evercraft:friends temp.streak_list[0] run return 0

execute store result score #fr_sl_uuid3 ec.temp run data get storage evercraft:friends temp.streak_list[0].uuid3

# If match: copy, ensure gift_streak field, mark sent_gift_today, append
execute if score #fr_sl_uuid3 ec.temp = #fr_streak_find ec.temp run data modify storage evercraft:friends temp.streak_entry set from storage evercraft:friends temp.streak_list[0]
# Ensure gift_streak field exists (for pre-existing friends)
execute if score #fr_sl_uuid3 ec.temp = #fr_streak_find ec.temp unless data storage evercraft:friends temp.streak_entry.gift_streak run data modify storage evercraft:friends temp.streak_entry.gift_streak set value 0
# Mark sent_gift_today on sender side
execute if score #fr_sl_uuid3 ec.temp = #fr_streak_find ec.temp if score #fr_streak_mode ec.temp matches 1 run data modify storage evercraft:friends temp.streak_entry.sent_gift_today set value 1b
# Append modified entry
execute if score #fr_sl_uuid3 ec.temp = #fr_streak_find ec.temp run data modify storage evercraft:friends temp.streak_result append from storage evercraft:friends temp.streak_entry

# If no match: copy as-is, ensuring new fields exist for schema consistency
execute unless score #fr_sl_uuid3 ec.temp = #fr_streak_find ec.temp run data modify storage evercraft:friends temp.streak_pass set from storage evercraft:friends temp.streak_list[0]
execute unless score #fr_sl_uuid3 ec.temp = #fr_streak_find ec.temp unless data storage evercraft:friends temp.streak_pass.gift_streak run data modify storage evercraft:friends temp.streak_pass.gift_streak set value 0
execute unless score #fr_sl_uuid3 ec.temp = #fr_streak_find ec.temp unless data storage evercraft:friends temp.streak_pass.sent_gift_today run data modify storage evercraft:friends temp.streak_pass.sent_gift_today set value 0b
execute unless score #fr_sl_uuid3 ec.temp = #fr_streak_find ec.temp run data modify storage evercraft:friends temp.streak_result append from storage evercraft:friends temp.streak_pass

# Pop and recurse
data remove storage evercraft:friends temp.streak_list[0]
function evercraft:friends/gift/streak_loop
