# Friend Heart — Macro: friendship level up message
# Macro args: level_name, level_color
$data modify storage evercraft:notify stage.c set value [{text:"Friendship Level Up!",color:"$(level_color)",bold:true}]
scoreboard players set #ndur ec.temp 50
function evercraft:util/notify/emit
$data modify storage evercraft:notify stage.c set value [{text:"You reached ",color:"gray"},{text:"$(level_name)",color:"$(level_color)"},{text:" status!",color:"gray"}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit
