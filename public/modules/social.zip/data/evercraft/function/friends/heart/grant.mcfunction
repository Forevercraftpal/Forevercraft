# Friend Heart — Grant a heart to the current friend pair
# @s = player gaining the heart
# #fr_check_uuid3 ec.temp = friend's UUID3
# #fr_heart_idx ec.temp = index in friend list
# #fr_self_uuid3 ec.temp = self UUID3

# Store index and both UUID3s for macro
execute store result storage evercraft:friends temp.heart_idx int 1 run scoreboard players get #fr_heart_idx ec.temp
execute store result storage evercraft:friends temp.friend_uuid3 int 1 run scoreboard players get #fr_check_uuid3 ec.temp

# Increment heart count in self's storage and mark daily
function evercraft:friends/heart/do_grant with storage evercraft:friends temp

# Check for level-up
execute store result score #fr_hearts ec.temp run data get storage evercraft:friends temp.new_hearts
function evercraft:friends/get_level_name

# Get previous heart count to check if level changed
# Wiring Audit #32 W4 (D2): this prev-level table now READS the same #fr_good/great/ultra/best
# constants as get_level_name (de-duped — was a second hardcoded 7/30/60/90 copy). They MUST stay
# in lockstep or level-up notifications fire at the wrong heart count; sharing the source fixes that.
scoreboard players operation #fr_prev_hearts ec.temp = #fr_hearts ec.temp
scoreboard players remove #fr_prev_hearts ec.temp 1
scoreboard players set #fr_prev_level ec.temp 0
execute if score #fr_prev_hearts ec.temp >= #fr_good ec.const run scoreboard players set #fr_prev_level ec.temp 1
execute if score #fr_prev_hearts ec.temp >= #fr_great ec.const run scoreboard players set #fr_prev_level ec.temp 2
execute if score #fr_prev_hearts ec.temp >= #fr_ultra ec.const run scoreboard players set #fr_prev_level ec.temp 3
execute if score #fr_prev_hearts ec.temp >= #fr_best ec.const run scoreboard players set #fr_prev_level ec.temp 4

# Notify if leveled up
execute unless score #fr_level ec.temp = #fr_prev_level ec.temp run function evercraft:friends/heart/level_up_notify

# Show heart gain message (subtle)
data modify storage evercraft:notify stage.c set value [{text:"+1 ",color:"red"},{text:"heart with a friend!",color:"light_purple"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.experience_orb.pickup master @s ~ ~ ~ 0.3 1.8
