# Friend System — Get friendship level name from heart count
# Input: #fr_hearts ec.temp = heart count
# Output: storage evercraft:friends temp.level_name, temp.level_color
# Also sets #fr_level ec.temp (0=Friend, 1=Good, 2=Great, 3=Ultra, 4=Best)

# Wiring Audit #32 W4 (D2): thresholds now READ the #fr_good/great/ultra/best constants
# (load.mcfunction) instead of hardcoded literals. `>= #fr_good` == old `matches 7..` (hearts >= 7).
# Edit a threshold in load + /reload to retune ALL readers (this file + heart/grant share the source).
scoreboard players set #fr_level ec.temp 0
data modify storage evercraft:friends temp.level_name set value "Friend"
data modify storage evercraft:friends temp.level_color set value "gray"

execute if score #fr_hearts ec.temp >= #fr_good ec.const run scoreboard players set #fr_level ec.temp 1
execute if score #fr_hearts ec.temp >= #fr_good ec.const run data modify storage evercraft:friends temp.level_name set value "Good Friend"
execute if score #fr_hearts ec.temp >= #fr_good ec.const run data modify storage evercraft:friends temp.level_color set value "green"

execute if score #fr_hearts ec.temp >= #fr_great ec.const run scoreboard players set #fr_level ec.temp 2
execute if score #fr_hearts ec.temp >= #fr_great ec.const run data modify storage evercraft:friends temp.level_name set value "Great Friend"
execute if score #fr_hearts ec.temp >= #fr_great ec.const run data modify storage evercraft:friends temp.level_color set value "aqua"

execute if score #fr_hearts ec.temp >= #fr_ultra ec.const run scoreboard players set #fr_level ec.temp 3
execute if score #fr_hearts ec.temp >= #fr_ultra ec.const run data modify storage evercraft:friends temp.level_name set value "Ultra Friend"
execute if score #fr_hearts ec.temp >= #fr_ultra ec.const run data modify storage evercraft:friends temp.level_color set value "light_purple"

execute if score #fr_hearts ec.temp >= #fr_best ec.const run scoreboard players set #fr_level ec.temp 4
execute if score #fr_hearts ec.temp >= #fr_best ec.const run data modify storage evercraft:friends temp.level_name set value "Best Friend"
execute if score #fr_hearts ec.temp >= #fr_best ec.const run data modify storage evercraft:friends temp.level_color set value "gold"
