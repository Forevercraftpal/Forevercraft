# Reaper — Announce title change (called when tier changes)
# Run as player. #rp_old_tier and @s rp.tier contain old/new values.

# Reached Villain (tier -5)
# (AB-1 sticky-times sweep 2026-06-10: explicit stamp — `title times` is sticky per player and this sequence set none, so it inherited whatever ran last.)
execute if score @s rp.tier matches -5 unless score #rp_old_tier rp.temp matches -5 run title @s times 10 60 20
execute if score @s rp.tier matches -5 unless score #rp_old_tier rp.temp matches -5 run title @s subtitle {text:"You have become a Villain",color:"dark_red",italic:true}
execute if score @s rp.tier matches -5 unless score #rp_old_tier rp.temp matches -5 run title @s title [{text:"☠ ",color:"dark_red"},{text:"VILLAIN",color:"dark_red",bold:true},{text:" ☠",color:"dark_red"}]
execute if score @s rp.tier matches -5 unless score #rp_old_tier rp.temp matches -5 run function evercraft:util/notify/whoami
data modify storage evercraft:notify stage.c set value [{text:"☠ ",color:"dark_red"},{text:"",color:"red",bold:true},{text:" has embraced the path of villainy!",color:"dark_red"},{text:" ☠",color:"dark_red"}]
data modify storage evercraft:notify stage.c[1].text set from storage evercraft:notify named.who
scoreboard players set #ndur ec.temp 50
execute if score @s rp.tier matches -5 unless score #rp_old_tier rp.temp matches -5 run execute as @a run scoreboard players set #nttl ec.temp 600
execute if score @s rp.tier matches -5 unless score #rp_old_tier rp.temp matches -5 run execute as @a run function evercraft:util/notify/emit_keep
execute if score @s rp.tier matches -5 unless score #rp_old_tier rp.temp matches -5 if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.wither.spawn hostile @s ~ ~ ~ 0.3 0.5

# Reached Peacemonger (tier +5)
execute if score @s rp.tier matches 5 unless score #rp_old_tier rp.temp matches 5 run title @s subtitle {text:"You have become a Peacemonger",color:"green",italic:true}
execute if score @s rp.tier matches 5 unless score #rp_old_tier rp.temp matches 5 run title @s title [{text:"✦ ",color:"green"},{text:"PEACEMONGER",color:"green",bold:true},{text:" ✦",color:"green"}]
execute if score @s rp.tier matches 5 unless score #rp_old_tier rp.temp matches 5 run function evercraft:util/notify/whoami
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"green"},{text:"",color:"green",bold:true},{text:" is now a beacon of peace!",color:"green"},{text:" ✦",color:"green"}]
data modify storage evercraft:notify stage.c[1].text set from storage evercraft:notify named.who
scoreboard players set #ndur ec.temp 50
execute if score @s rp.tier matches 5 unless score #rp_old_tier rp.temp matches 5 run execute as @a run scoreboard players set #nttl ec.temp 600
execute if score @s rp.tier matches 5 unless score #rp_old_tier rp.temp matches 5 run execute as @a run function evercraft:util/notify/emit_keep
execute if score @s rp.tier matches 5 unless score #rp_old_tier rp.temp matches 5 if score @s ec.fx_snd matches 1.. run playsound minecraft:ui.toast.challenge_complete player @s ~ ~ ~ 1.0 1.0

# Any other tier change — subtle chat notification to the player
data modify storage evercraft:notify stage.c set value [{text:"Your reputation shifts... you are now known as a ",color:"gray",italic:true},{score:{name:"@s",objective:"rp.tier"},color:"red"}]
scoreboard players set #ndur ec.temp 45
execute unless score @s rp.tier = #rp_old_tier rp.temp unless score @s rp.tier matches -5 unless score @s rp.tier matches 5 if score @s rp.tier matches ..-1 run function evercraft:util/notify/emit

# Returned to neutral from negative
data modify storage evercraft:notify stage.c set value [{text:"Your infamy has faded. You are ",color:"gray",italic:true},{text:"Neutral",color:"white"},{text:" once more.",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 45
execute if score @s rp.tier matches 0 if score #rp_old_tier rp.temp matches ..-1 run function evercraft:util/notify/emit

# Returned to neutral from positive
data modify storage evercraft:notify stage.c set value [{text:"Your renown has faded. You are ",color:"gray",italic:true},{text:"Neutral",color:"white"},{text:" once more.",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 45
execute if score @s rp.tier matches 0 if score #rp_old_tier rp.temp matches 1.. run function evercraft:util/notify/emit
