# Reaper — Hunting Party Defeated
# Run as player whose hunt party was killed

scoreboard players set @s rp.hunt_active 0

# Reward: reduce infamy by 200 (fighting back earns some redemption)
scoreboard players remove @s rp.infamy 200
execute if score @s rp.infamy matches ..-1 run scoreboard players set @s rp.infamy 0

# Renown bonus for defeating them
scoreboard players add @s rp.renown 50
execute if score @s rp.renown matches 5001.. run scoreboard players set @s rp.renown 5000

data modify storage evercraft:notify stage.c set value [{text:"⚔ ",color:"dark_aqua"},{text:"The bounty hunters have been defeated!",color:"dark_aqua"},{text:" ⚔",color:"dark_aqua"}]
scoreboard players set #ndur ec.temp 50
function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"-200 Infamy · +50 Renown",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:ui.toast.challenge_complete player @s ~ ~ ~ 0.5 1.2
