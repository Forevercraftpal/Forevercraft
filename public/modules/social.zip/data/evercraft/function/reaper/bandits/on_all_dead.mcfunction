# Reaper — Bandits Defeated
# Run as player whose bandits were killed

scoreboard players set @s rp.band_active 0

# Reward: bonus renown for protecting yourself
scoreboard players add @s rp.renown 50
execute if score @s rp.renown matches 5001.. run scoreboard players set @s rp.renown 5000

data modify storage evercraft:notify stage.c set value [{text:"⚔ ",color:"green"},{text:"The bandits have been driven off!",color:"green"},{text:" ⚔",color:"green"}]
scoreboard players set #ndur ec.temp 50
function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"+50 Renown",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:ui.toast.challenge_complete player @s ~ ~ ~ 0.5 1.2
