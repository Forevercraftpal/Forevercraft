# Reaper — World Boss Kill (+200 renown)
# Called from bosses/rewards/give_participant as each participant

scoreboard players add @s rp.renown 200
execute if score @s rp.renown matches 5001.. run scoreboard players set @s rp.renown 5000

data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"green"},{text:"A champion of the realm! ",color:"green",italic:true},{text:"(+200 Renown)",color:"gray"},{text:" ✦",color:"green"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
