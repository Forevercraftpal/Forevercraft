# Reaper Deeds — Delta-detect vanilla stat changes
# Run as each player

# OPT: Early exit if all snapshots match current stats (no kills or trades since last check)
# Uses a fast 4-score comparison — skips 8 scoreboard operations for idle players
execute if score @s rp.stat_pk = @s rp.pk_snap if score @s rp.stat_vk = @s rp.vk_snap if score @s rp.stat_gk = @s rp.gk_snap if score @s rp.stat_trade = @s rp.trade_snap run return 0

# === PLAYER KILLS (infamy +150 per kill, outside duels) ===
scoreboard players operation #rp_delta rp.temp = @s rp.stat_pk
scoreboard players operation #rp_delta rp.temp -= @s rp.pk_snap
execute if score #rp_delta rp.temp matches 1.. unless entity @s[tag=ec.duel_active_tag] run function evercraft:reaper/deeds/on_player_kill
scoreboard players operation @s rp.pk_snap = @s rp.stat_pk

# === VILLAGER KILLS (infamy +100 per kill) ===
scoreboard players operation #rp_delta rp.temp = @s rp.stat_vk
scoreboard players operation #rp_delta rp.temp -= @s rp.vk_snap
execute if score #rp_delta rp.temp matches 1.. run function evercraft:reaper/deeds/on_villager_kill
scoreboard players operation @s rp.vk_snap = @s rp.stat_vk

# === IRON GOLEM KILLS (infamy +50 per kill) ===
scoreboard players operation #rp_delta rp.temp = @s rp.stat_gk
scoreboard players operation #rp_delta rp.temp -= @s rp.gk_snap
execute if score #rp_delta rp.temp matches 1.. run function evercraft:reaper/deeds/on_golem_kill
scoreboard players operation @s rp.gk_snap = @s rp.stat_gk

# === VILLAGER TRADES (renown +10 per trade, cap 100/day) ===
scoreboard players operation #rp_delta rp.temp = @s rp.stat_trade
scoreboard players operation #rp_delta rp.temp -= @s rp.trade_snap
execute if score #rp_delta rp.temp matches 1.. run function evercraft:reaper/deeds/on_trade
scoreboard players operation @s rp.trade_snap = @s rp.stat_trade
