# Reaper — Iron Golem Kill (+50 infamy per kill)
# #rp_delta = number of kills since last check

scoreboard players operation #rp_add rp.temp = #rp_delta rp.temp
scoreboard players operation #rp_add rp.temp *= #50 rp.temp
scoreboard players operation @s rp.infamy += #rp_add rp.temp

# Cap at 5000
execute if score @s rp.infamy matches 5001.. run scoreboard players set @s rp.infamy 5000

data modify storage evercraft:notify stage.c set value [{text:"☠ ",color:"dark_red"},{text:"The iron sentinels mark your transgression... ",color:"red",italic:true},{text:"(+",color:"gray"},{score:{name:"#rp_add",objective:"rp.temp"},color:"gray"},{text:" Infamy)",color:"gray"},{text:" ☠",color:"dark_red"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
