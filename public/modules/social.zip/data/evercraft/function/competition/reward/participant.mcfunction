# Competition Reward — Participant shim (scored but not top 3)
# ============================================================
# Was: a FLAT Common Crate + 50 XP + 1 Coin for every non-podium scorer.
# Now: a thin per-player shim that feeds this player's contribution into the
# reusable contribution-scaled primitive, so the reward matches how much they
# actually worked.
#
# Run AS+AT @s by competition/end for each non-podium scorer. Setting the
# primitive's input (#contrib ec.temp) and dispatching happen inside this one
# per-player context, so the shared fake-player input can't go stale between
# players.
# ============================================================

# Feed this player's competition-only delta (final at end-time) into the primitive.
scoreboard players operation #contrib ec.temp = @s ec.comp_score
# Reference for relative tiers = today's top (1st-place) score, computed by end.mcfunction
# (#comp_1st ec.temp) and still live here. The primitive scales the bands off this.
scoreboard players operation #contrib_max ec.temp = #comp_1st ec.temp

# Grant the contribution-scaled reward (crate + XP + coins + notify).
function evercraft:competition/reward/by_contribution
