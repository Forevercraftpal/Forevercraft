# Competition Reward — 2nd Place
# Reward Crate + 250 XP + 5 Coins

# Reward Crate (animatable, rolled like a chest-node open).
function evercraft:util/give_node_crate

# XP
experience add @s 250 points

# Coins
scoreboard players add @s ec.coins 5
scoreboard players add #rm_coins ec.var 5

# Feedback
data modify storage evercraft:notify stage.c set value [{text:"2nd Place! ",color:"white"},{text:"a Reward Crate + 250 XP + 5 Coins",color:"yellow"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
