# Contribution Tier 3 — Strong contributor (contrib >= 10)
# Reward Crate + 75 XP + 2 Coins
# Approaches the 3rd-place podium (Reward Crate + 100 XP + 3 Coins) without matching it.
# Called by competition/reward/by_contribution AS+AT @s.

# Reward Crate (animatable, rolled like a chest-node open).
function evercraft:util/give_node_crate

# XP
experience add @s 75 points

# Coins
scoreboard players add @s ec.coins 2
scoreboard players add #rm_coins ec.var 2

# Feedback
data modify storage evercraft:notify stage.c set value [{text:"Strong contribution! ",color:"green"},{text:"a Reward Crate + 75 XP + 2 Coins",color:"yellow"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
