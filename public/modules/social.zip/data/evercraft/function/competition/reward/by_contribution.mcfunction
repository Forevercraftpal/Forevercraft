# Competition Reward — Contribution-Scaled (reusable primitive)
# ============================================================
# Grants a crate + XP + Coins reward that SCALES with how much the
# player actually contributed, instead of a flat hand-out.
#
# Reusable across events (Wave 3 co-op): the caller supplies the
# player's contribution metric in a scoreboard, then runs this
# function AS and AT the player.
#
# INTERFACE
#   IN   #contrib ec.temp     — the player's contribution score (int).
#                               Competition callers copy ec.comp_score in.
#   IN   #contrib_max ec.temp — the reference TOP score to scale bands off
#                               (competition = #comp_1st, the 1st-place score).
#   RUN  as @s at @s        — @s is the player to reward; AT @s so the
#                             inv-full fallback drops at their feet.
#   OUT  ec.coins (+mirror #rm_coins ec.var), XP, a crate item, and a
#        non-bold action-bar notify telling them what they earned.
#
# CONTRIBUTION TIERS — RELATIVE to the day's top score (#contrib_max):
#   Tier 3  Strong  contrib >= 25% of top  -> Uncommon Crate + 75 XP + 2 Coins
#   Tier 2  Solid   contrib >= 10% of top  -> Common   Crate + 50 XP + 1 Coin
#   Tier 1  Token   contrib  >= 1 (rest)   -> Common   Crate + 25 XP + 1 Coin
# Self-scales across short/long & easy/hard competitions. At a top score of 40
# the bands collapse to the old fixed 10/4/1 cutoffs. A strong contributor
# APPROACHES (never matches/beats) the 3rd-place podium (Uncommon+100XP+3c);
# a minimal scorer still walks away with a token. Podium is untouched.
# (Band percentages parked as balance Q1 — tunable.)
# ============================================================

# Inv-full guard (shared by every tier): drop at the player's feet
# rather than void the crate on a full inventory.
execute store result score #inv_full ec.var run function evercraft:util/check_inv_full

# Relative band thresholds (integer math on the ec.temp scratch objective).
#   #thr_strong = #contrib_max * 25 / 100   (25% of top)
#   #thr_solid  = #contrib_max * 10 / 100   (10% of top)
scoreboard players set #c100 ec.temp 100
scoreboard players set #c25 ec.temp 25
scoreboard players set #c10 ec.temp 10
scoreboard players operation #thr_strong ec.temp = #contrib_max ec.temp
scoreboard players operation #thr_strong ec.temp *= #c25 ec.temp
scoreboard players operation #thr_strong ec.temp /= #c100 ec.temp
scoreboard players operation #thr_solid ec.temp = #contrib_max ec.temp
scoreboard players operation #thr_solid ec.temp *= #c10 ec.temp
scoreboard players operation #thr_solid ec.temp /= #c100 ec.temp

# Route to exactly one tier. Branches are disjoint via the < / >= guards, and
# every non-podium scorer has contrib >= 1, so nobody falls through.
execute if score #contrib ec.temp matches 1.. if score #contrib ec.temp >= #thr_strong ec.temp run function evercraft:competition/reward/contrib/strong
execute if score #contrib ec.temp matches 1.. if score #contrib ec.temp < #thr_strong ec.temp if score #contrib ec.temp >= #thr_solid ec.temp run function evercraft:competition/reward/contrib/solid
execute if score #contrib ec.temp matches 1.. if score #contrib ec.temp < #thr_solid ec.temp run function evercraft:competition/reward/contrib/token

# === NODE FESTIVAL BONUS (Wave 3c, contained hook) =========================================
# ADDITIVE festival bonus for contributors when the ACTIVE competition is the festival's
# FEATURED node (#comp_active == #nfest_node + 6 while a festival runs). Additive on top of
# the tier reward above (does NOT touch the disjoint tier branches). Inert when #nfest_active=0
# (two score checks fall through). #ftype = featured competition type = node + 6.
execute if score #nfest_active ec.var matches 1 if score #contrib ec.temp matches 1.. run scoreboard players operation #nfest_ftype ec.var = #nfest_node ec.var
execute if score #nfest_active ec.var matches 1 if score #contrib ec.temp matches 1.. run scoreboard players add #nfest_ftype ec.var 6
execute if score #nfest_active ec.var matches 1 if score #contrib ec.temp matches 1.. if score #comp_active ec.var = #nfest_ftype ec.var run function evercraft:node_festival/comp_bonus
