# Competition Reward — 3rd Place
# Reward Crate + 100 XP + 3 Coins

# Reward Crate (animatable, rolled like a chest-node open).
function evercraft:util/give_node_crate

# XP
experience add @s 100 points

# Coins
scoreboard players add @s ec.coins 3
scoreboard players add #rm_coins ec.var 3

# Feedback
data modify storage evercraft:notify stage.c set value [{text:"3rd Place! ",color:"#CD7F32"},{text:"a Reward Crate + 100 XP + 3 Coins",color:"yellow"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
