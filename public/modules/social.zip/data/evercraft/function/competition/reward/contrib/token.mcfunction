# Contribution Tier 1 — Token / minimal scorer (contrib 1..3)
# Reward Crate + 25 XP + 1 Coin
# Even a minimal contributor still walks away with something.
# Called by competition/reward/by_contribution AS+AT @s.

# Reward Crate (animatable, rolled like a chest-node open).
function evercraft:util/give_node_crate

# XP
experience add @s 25 points

# Coins
scoreboard players add @s ec.coins 1
scoreboard players add #rm_coins ec.var 1

# Feedback
data modify storage evercraft:notify stage.c set value [{text:"Thanks for taking part! ",color:"gray"},{text:"a Reward Crate + 25 XP + 1 Coin",color:"yellow"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
