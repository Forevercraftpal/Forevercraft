# Competition Reward — 1st Place
# Reward Crate + 500 XP + 10 Coins + Rare Artifact

# Reward Crate (animatable, rolled like a chest-node open).
function evercraft:util/give_node_crate

# Inv-full guard (for the Rare Artifact below): drop at the player's feet
# rather than void on a full inventory.
execute store result score #inv_full ec.var run function evercraft:util/check_inv_full

# XP
experience add @s 500 points

# Coins
scoreboard players add @s ec.coins 10
scoreboard players add #rm_coins ec.var 10

# Rare Artifact
execute if score #inv_full ec.var matches 0 run loot give @s loot evercraft:artifacts/rare/main
execute if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:artifacts/rare/main

# Feedback
data modify storage evercraft:notify stage.c set value [{text:"1st Place! ",color:"gold"},{text:"a Reward Crate + 500 XP + 10 Coins + Rare Artifact",color:"yellow"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
