# Contribution Tier 2 — Solid contributor (contrib 4..9)
# Reward Crate + 50 XP + 1 Coin  (the former flat participant reward, now the middle band)
# Called by competition/reward/by_contribution AS+AT @s.

# Reward Crate (animatable, rolled like a chest-node open).
function evercraft:util/give_node_crate

# XP
experience add @s 50 points

# Coins
scoreboard players add @s ec.coins 1
scoreboard players add #rm_coins ec.var 1

# Feedback
data modify storage evercraft:notify stage.c set value [{text:"Solid contribution! ",color:"aqua"},{text:"a Reward Crate + 50 XP + 1 Coin",color:"yellow"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
