# Competition — Pick Type (RETIRED — the early dawn announcement was the spam)
# deprecated — no longer scheduled (kept for revert; flagged for a future council)
# ---------------------------------------------------------------------
# This file used to roll #comp_day_type 1..6 AND fire the "Today's Competition:
# <name> — starts at noon!" action-bar to EVERY player at dawn, before any
# eligibility/spacing gate. That early notification is exactly what the Unified
# Event Director removes: selection is now gated in event_director/dawn_decision,
# and the only competition announcement fires at NOON inside competition/start
# (via competition/announce/<type>), AFTER the gate locks a type in.
#
# Intentionally a no-op now. Retained (not archived) per CLAUDE.md dead-code
# protocol — flagged for a future council, not deleted. Zero callers.
