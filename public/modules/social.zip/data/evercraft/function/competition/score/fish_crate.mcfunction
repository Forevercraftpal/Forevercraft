# Competition Score — Fishing Crate rarity bonus (Wave 3a rework, MACRO)
# ============================================================
# Call: function evercraft:competition/score/fish_crate {w:<weight>}  AS the player.
# Hooked into each fished-crate rarity's process.mcfunction (common..mythical). Adds a
# RARITY-WEIGHTED bonus to the Fishing Derby+ (type 6) competition score when a crate is
# fished — rarer fished crates are worth more. This is the "fish type × rarity + crates
# fished" half of the reworked fishing scorer; the +1 per-catch base lives in fish_catch.
#
# WEIGHT LADDER (passed by each process file; rarer crate = bigger bonus):
#   common 1 · uncommon 2 · rare 3 · ornate 5 · exquisite 8 · mythical 12
# (Parked Q2 — exact weights tunable. Ordering matches the crate.json drop-rate ordering
#  common ~1/57 .. mythical ~1/571, i.e. ~10x rarer => ~12x the points.)
#
# Only fires while the Fishing Derby+ (type 6) is the ACTIVE competition. Non-fishing days
# pay one score comparison and return. H2H (type 6) keeps flat per-catch scoring (no crate
# weighting there) — this helper is server-wide-comp only.

# Early-exit if the fishing competition isn't running.
execute unless score #comp_active ec.var matches 6 run return 0

# Add the rarity weight to this player's competition score + mark participation.
$scoreboard players add @s ec.comp_score $(w)
scoreboard players set @s ec.comp_today 1

# Action-bar feedback (non-bold, matches fish_catch). Shows the running total.
$data modify storage evercraft:notify stage.c set value [{text:"+$(w) ",color:"aqua"},{text:"Rare crate! Score: ",color:"gold"},{score:{name:"@s",objective:"ec.comp_score"},color:"white"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.experience_orb.pickup master @s ~ ~ ~ 0.4 1.2
