# Competition Score — Forge Complete (from Artisan Forge minigame)
# Called from resolve.mcfunction when a player finishes forging
# Points scale by material tier + quality bonus

# Only score if forging competition is active (type 3)
# --- Server-wide competition ---
execute unless score #comp_active ec.var matches 3 unless score #h2h_active ec.var matches 3 run return 0

# Base points by material tier
scoreboard players set #cf_comp_pts ec.cf_temp 0
execute if score @s ec.cf_mat_tier matches 0 run scoreboard players set #cf_comp_pts ec.cf_temp 1
execute if score @s ec.cf_mat_tier matches 1 run scoreboard players set #cf_comp_pts ec.cf_temp 2
execute if score @s ec.cf_mat_tier matches 2 run scoreboard players set #cf_comp_pts ec.cf_temp 3
execute if score @s ec.cf_mat_tier matches 3 run scoreboard players set #cf_comp_pts ec.cf_temp 4
execute if score @s ec.cf_mat_tier matches 4 run scoreboard players set #cf_comp_pts ec.cf_temp 5
execute if score @s ec.cf_mat_tier matches 5 run scoreboard players set #cf_comp_pts ec.cf_temp 6

# Artifact forges: +4 base + artifact tier (T1=5, T2=6, T3=7, T4=8, T5=9, T6=10, T7=11)
execute if score @s ec.cf_mat_tier matches 10.. run scoreboard players set #cf_comp_pts ec.cf_temp 4
execute if score @s ec.cf_mat_tier matches 10.. run scoreboard players operation #cf_comp_pts ec.cf_temp += @s ec.cf_art_tier

# Masterwork bonus: +2 extra points
execute if score @s ec.cf_quality matches 12.. run scoreboard players add #cf_comp_pts ec.cf_temp 2

# Failed forges score nothing
execute if score @s ec.cf_quality matches ..3 run scoreboard players set #cf_comp_pts ec.cf_temp 0
execute if score @s ec.cf_quality matches ..3 run return 0

# Apply to server-wide competition
execute if score #comp_active ec.var matches 3 run scoreboard players operation @s ec.comp_score += #cf_comp_pts ec.cf_temp
execute if score #comp_active ec.var matches 3 run scoreboard players set @s ec.comp_today 1
execute if score #comp_active ec.var matches 3 run data modify storage evercraft:notify stage.c set value [{text:"+",color:"green"},{score:{name:"#cf_comp_pts",objective:"ec.cf_temp"},color:"green"},{text:" Forge! Score: ",color:"gold"},{score:{name:"@s",objective:"ec.comp_score"},color:"white"}]
execute if score #comp_active ec.var matches 3 run scoreboard players set #ndur ec.temp 45
execute if score #comp_active ec.var matches 3 run function evercraft:util/notify/emit
execute if score #comp_active ec.var matches 3 if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.experience_orb.pickup master @s ~ ~ ~ 0.3 1.5

# Apply to H2H competition
execute if score #h2h_active ec.var matches 3 if entity @s[tag=h2h.participant] run scoreboard players operation @s ec.h2h_score += #cf_comp_pts ec.cf_temp
execute if score #h2h_active ec.var matches 3 if entity @s[tag=h2h.participant] if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.experience_orb.pickup master @s ~ ~ ~ 0.3 1.5
