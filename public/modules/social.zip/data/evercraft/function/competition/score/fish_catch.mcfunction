# Competition Score — Fishing Catch (BASE catch point)
# Called from fishing/ref/on_catch when any fishing competition is active.
# Runs as the player who caught the fish.
#
# REWORK (Wave 3a): the Fishing Derby+ (type 6) score is now RARITY-WEIGHTED, not flat
# +1/catch. This file contributes the +1 BASE catch point (every catch counts a little).
# The rarity/crate WEIGHT is added separately by competition/score/fish_crate, hooked into
# each fished-crate rarity's process.mcfunction (common..mythical) — so a rarer fished crate
# is worth more. Net per catch = 1 (base) + crate-rarity weight when a crate is fished.
# (The simple per-catch NODE comp — Sirencall, type 10 — keeps the flat count and does NOT
# route through here; it scores via competition/track/sirencall.)

# Server-wide competition scoring — base catch point.
execute if score #comp_active ec.var matches 6 run scoreboard players add @s ec.comp_score 1
execute if score #comp_active ec.var matches 6 run scoreboard players set @s ec.comp_today 1
execute if score #comp_active ec.var matches 6 run data modify storage evercraft:notify stage.c set value [{text:"+1 ",color:"green"},{text:"Catch! Score: ",color:"gold"},{score:{name:"@s",objective:"ec.comp_score"},color:"white"}]
execute if score #comp_active ec.var matches 6 run scoreboard players set #ndur ec.temp 45
execute if score #comp_active ec.var matches 6 run function evercraft:util/notify/emit
execute if score #comp_active ec.var matches 6 if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.experience_orb.pickup master @s ~ ~ ~ 0.3 1.8

# H2H competition scoring (unchanged — H2H fishing stays flat per-catch).
execute if score #h2h_active ec.var matches 6 if entity @s[tag=h2h.participant] run scoreboard players add @s ec.h2h_score 1
execute if score #h2h_active ec.var matches 6 if entity @s[tag=h2h.participant] if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.experience_orb.pickup master @s ~ ~ ~ 0.3 1.8
