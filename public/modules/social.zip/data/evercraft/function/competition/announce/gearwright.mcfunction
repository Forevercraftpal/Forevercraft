# Competition Announce — Gearwright's Tinkering (node comp, type 11)
bossbar set evercraft:competition name [{text:"Gearwright's Tinkering",color:"gold",bold:true},{text:" — Craft items!",color:"yellow"}]

title @a times 10 60 20
title @a title {text:"Gearwright's Tinkering!",color:"gold"}
title @a subtitle {text:"Craft items to score!",color:"yellow"}

data modify storage evercraft:notify stage.c set value [{text:"GEARWRIGHT'S TINKERING",color:"gold"}]
scoreboard players set #ndur ec.temp 50
execute as @a run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Craft and tinker for points!",color:"yellow"}]
scoreboard players set #ndur ec.temp 40
execute as @a run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"+1 per craft action",color:"gray"}]
scoreboard players set #ndur ec.temp 40
execute as @a run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Duration: 5 minutes",color:"dark_gray"}]
scoreboard players set #ndur ec.temp 40
execute as @a run function evercraft:util/notify/emit
