# Competition Announce — Cooking Contest
bossbar set evercraft:competition name [{text:"Cooking Contest",color:"gold",bold:true},{text:" — Cook food items!",color:"yellow"}]

title @a times 10 60 20
title @a title {text:"Cooking Contest!",color:"gold"}
title @a subtitle {text:"Cook as many food items as possible!",color:"yellow"}

data modify storage evercraft:notify stage.c set value [{text:"COOKING CONTEST",color:"gold"}]
scoreboard players set #ndur ec.temp 50
execute as @a run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Smelt food in furnaces and smokers!",color:"yellow"}]
scoreboard players set #ndur ec.temp 40
execute as @a run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"+1 per food item cooked",color:"gray"}]
scoreboard players set #ndur ec.temp 40
execute as @a run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Duration: 5 minutes",color:"dark_gray"}]
scoreboard players set #ndur ec.temp 40
execute as @a run function evercraft:util/notify/emit
