# Competition Announce — Fishing Derby+
bossbar set evercraft:competition name [{text:"Fishing Derby+",color:"gold",bold:true},{text:" — Catch fish!",color:"yellow"}]

title @a times 10 60 20
title @a title {text:"Fishing Derby+!",color:"gold"}
title @a subtitle {text:"Catch as many fish as possible!",color:"yellow"}

data modify storage evercraft:notify stage.c set value [{text:"FISHING DERBY+",color:"gold"}]
scoreboard players set #ndur ec.temp 50
execute as @a run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Catch fish for points!",color:"yellow"}]
scoreboard players set #ndur ec.temp 40
execute as @a run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"+1 per catch, rarer fished crates score more",color:"gray"}]
scoreboard players set #ndur ec.temp 40
execute as @a run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Dream Rate +0.5 while fishing",color:"green"}]
scoreboard players set #ndur ec.temp 40
execute as @a run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Duration: 5 minutes",color:"dark_gray"}]
scoreboard players set #ndur ec.temp 40
execute as @a run function evercraft:util/notify/emit
