# Competition Announce — Terrawarp's Excavation (node comp, type 9)
bossbar set evercraft:competition name [{text:"Terrawarp's Excavation",color:"gold",bold:true},{text:" — Dig blocks!",color:"yellow"}]

title @a times 10 60 20
title @a title {text:"Terrawarp's Excavation!",color:"gold"}
title @a subtitle {text:"Dig soft blocks to score!",color:"yellow"}

data modify storage evercraft:notify stage.c set value [{text:"TERRAWARP'S EXCAVATION",color:"gold"}]
scoreboard players set #ndur ec.temp 50
execute as @a run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Excavate for points!",color:"yellow"}]
scoreboard players set #ndur ec.temp 40
execute as @a run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"+1 per soft block dug (dirt, sand, gravel...)",color:"gray"}]
scoreboard players set #ndur ec.temp 40
execute as @a run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Duration: 5 minutes",color:"dark_gray"}]
scoreboard players set #ndur ec.temp 40
execute as @a run function evercraft:util/notify/emit
