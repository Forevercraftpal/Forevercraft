# Competition Announce — Lumberfell's Felling (node comp, type 8)
bossbar set evercraft:competition name [{text:"Lumberfell's Felling",color:"gold",bold:true},{text:" — Fell trees!",color:"yellow"}]

title @a times 10 60 20
title @a title {text:"Lumberfell's Felling!",color:"gold"}
title @a subtitle {text:"Chop logs to score!",color:"yellow"}

data modify storage evercraft:notify stage.c set value [{text:"LUMBERFELL'S FELLING",color:"gold"}]
scoreboard players set #ndur ec.temp 50
execute as @a run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Fell trees for points!",color:"yellow"}]
scoreboard players set #ndur ec.temp 40
execute as @a run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"+1 per log or stem chopped",color:"gray"}]
scoreboard players set #ndur ec.temp 40
execute as @a run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Duration: 5 minutes",color:"dark_gray"}]
scoreboard players set #ndur ec.temp 40
execute as @a run function evercraft:util/notify/emit
