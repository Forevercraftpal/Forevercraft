# Competition Announce — Prospector's Race
bossbar set evercraft:competition name [{text:"Prospector's Race",color:"gold",bold:true},{text:" — Find rare ores!",color:"yellow"}]

title @a times 10 60 20
title @a title {text:"Prospector's Race!",color:"gold"}
title @a subtitle {text:"Mine ore nodes to score!",color:"yellow"}

data modify storage evercraft:notify stage.c set value [{text:"PROSPECTOR'S RACE",color:"gold"}]
scoreboard players set #ndur ec.temp 50
execute as @a run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Mine ore nodes to earn points!",color:"yellow"}]
scoreboard players set #ndur ec.temp 40
execute as @a run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"+1 per prospect completed",color:"gray"}]
scoreboard players set #ndur ec.temp 40
execute as @a run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Duration: 5 minutes",color:"dark_gray"}]
scoreboard players set #ndur ec.temp 40
execute as @a run function evercraft:util/notify/emit
