# Competition Announce — Forging Championship
bossbar set evercraft:competition name [{text:"Forging Championship",color:"gold",bold:true},{text:" — Forge gear!",color:"yellow"}]

title @a times 10 60 20
title @a title {text:"Forging Championship!",color:"gold"}
title @a subtitle {text:"Use the Artisan Forge to score points!",color:"yellow"}

data modify storage evercraft:notify stage.c set value [{text:"FORGING CHAMPIONSHIP",color:"gold"}]
scoreboard players set #ndur ec.temp 50
execute as @a run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Forge weapons, tools, and armor to score!",color:"yellow"}]
scoreboard players set #ndur ec.temp 40
execute as @a run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Higher tier materials = more points",color:"gray"}]
scoreboard players set #ndur ec.temp 40
execute as @a run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Masterwork quality = +2 bonus!",color:"gray"}]
scoreboard players set #ndur ec.temp 40
execute as @a run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Duration: 5 minutes",color:"dark_gray"}]
scoreboard players set #ndur ec.temp 40
execute as @a run function evercraft:util/notify/emit
