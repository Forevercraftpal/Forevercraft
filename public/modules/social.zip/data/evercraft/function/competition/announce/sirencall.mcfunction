# Competition Announce — Sirencall's Catch (node comp, type 10)
bossbar set evercraft:competition name [{text:"Sirencall's Catch",color:"gold",bold:true},{text:" — Catch fish!",color:"yellow"}]

title @a times 10 60 20
title @a title {text:"Sirencall's Catch!",color:"gold"}
title @a subtitle {text:"Reel in fish to score!",color:"yellow"}

data modify storage evercraft:notify stage.c set value [{text:"SIRENCALL'S CATCH",color:"gold"}]
scoreboard players set #ndur ec.temp 50
execute as @a run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Catch fish for points!",color:"yellow"}]
scoreboard players set #ndur ec.temp 40
execute as @a run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"+1 per fish caught",color:"gray"}]
scoreboard players set #ndur ec.temp 40
execute as @a run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Duration: 5 minutes",color:"dark_gray"}]
scoreboard players set #ndur ec.temp 40
execute as @a run function evercraft:util/notify/emit
