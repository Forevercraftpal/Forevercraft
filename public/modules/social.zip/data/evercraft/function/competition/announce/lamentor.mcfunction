# Competition Announce — Lamentor's Shearing (node comp, type 7)
bossbar set evercraft:competition name [{text:"Lamentor's Shearing",color:"gold",bold:true},{text:" — Shear for points!",color:"yellow"}]

title @a times 10 60 20
title @a title {text:"Lamentor's Shearing!",color:"gold"}
title @a subtitle {text:"Shear sheep, leaves and grass!",color:"yellow"}

data modify storage evercraft:notify stage.c set value [{text:"LAMENTOR'S SHEARING",color:"gold"}]
scoreboard players set #ndur ec.temp 50
execute as @a run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Shear to score points!",color:"yellow"}]
scoreboard players set #ndur ec.temp 40
execute as @a run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"+1 per shear (sheep, leaves, grass)",color:"gray"}]
scoreboard players set #ndur ec.temp 40
execute as @a run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Duration: 5 minutes",color:"dark_gray"}]
scoreboard players set #ndur ec.temp 40
execute as @a run function evercraft:util/notify/emit
