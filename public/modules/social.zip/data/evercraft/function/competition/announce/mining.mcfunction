# Competition Announce — Mining Rush
bossbar set evercraft:competition name [{text:"Mining Rush",color:"gold",bold:true},{text:" — Mine ores!",color:"yellow"}]

title @a times 10 60 20
title @a title {text:"Mining Rush!",color:"gold"}
title @a subtitle {text:"Mine as many ores as possible!",color:"yellow"}

data modify storage evercraft:notify stage.c set value [{text:"MINING RUSH",color:"gold"}]
scoreboard players set #ndur ec.temp 50
execute as @a run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Break ores to score points!",color:"yellow"}]
scoreboard players set #ndur ec.temp 40
execute as @a run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Rarer ores score more (debris > emerald > diamond...)",color:"gray"}]
scoreboard players set #ndur ec.temp 40
execute as @a run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Duration: 5 minutes",color:"dark_gray"}]
scoreboard players set #ndur ec.temp 40
execute as @a run function evercraft:util/notify/emit
