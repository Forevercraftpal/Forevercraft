# Competition Announce — Foraging Frenzy
bossbar set evercraft:competition name [{text:"Foraging Frenzy",color:"gold",bold:true},{text:" — Harvest bushes!",color:"yellow"}]

title @a times 10 60 20
title @a title {text:"Foraging Frenzy!",color:"gold"}
title @a subtitle {text:"Forage bushes to score!",color:"yellow"}

data modify storage evercraft:notify stage.c set value [{text:"FORAGING FRENZY",color:"gold"}]
scoreboard players set #ndur ec.temp 50
execute as @a run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Gather from forage bushes!",color:"yellow"}]
scoreboard players set #ndur ec.temp 40
execute as @a run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"+1 per forage completed",color:"gray"}]
scoreboard players set #ndur ec.temp 40
execute as @a run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Duration: 5 minutes",color:"dark_gray"}]
scoreboard players set #ndur ec.temp 40
execute as @a run function evercraft:util/notify/emit
