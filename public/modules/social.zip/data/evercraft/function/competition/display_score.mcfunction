# Competition — Display Score (actionbar for participants)
execute unless entity @s[tag=ab_q] run title @s actionbar [{text:"Score: ",color:"gold"},{score:{name:"@s",objective:"ec.comp_score"},color:"white"},{text:" pts",color:"yellow"}]
