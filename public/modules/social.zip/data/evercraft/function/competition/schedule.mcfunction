# Competition — Schedule (LEGACY SHIM, superseded by the Unified Event Director)
# deprecated — no longer scheduled (kept for revert; flagged for a future council)
# ---------------------------------------------------------------------
# The old behaviour (40% dawn roll + flat random 1..6 pick + early "Today's
# Competition" announcement) is GONE. Competition selection is now gated by
# evercraft:event_director/dawn_decision (eligibility + 3-day lockout + cadence),
# which is what luck_buffs/dawn_dispatch calls directly.
#
# This shim is retained so the historical entry point still resolves and simply
# delegates to the Director. Do NOT add selection logic here. (Not archived: see
# CLAUDE.md dead-code protocol — flagged for a future council, not deleted.)
execute if score #comp_active ec.var matches 1..11 run return 0
function evercraft:event_director/dawn_decision
