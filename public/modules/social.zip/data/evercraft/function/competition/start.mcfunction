# Competition — Start
# Triggered when DayTime reaches 6000 (noon) and #comp_day_type != 0

# Set active type
scoreboard players operation #comp_active ec.var = #comp_day_type ec.var

# Duration: 6000 ticks of game time (= ~15 min real time at slow DayTime)
scoreboard players set #comp_timer ec.var 6000

# Reset all player scores
scoreboard players set @a ec.comp_score 0
scoreboard players set @a ec.comp_place 0
scoreboard players set @a ec.comp_today 0
scoreboard players set @a ec.comp_baseline 0

# Take baseline snapshots for delta-track types
# Mining (type 2) — RARITY-WEIGHTED rework (Wave 3a): snapshot the Stonestrike WEIGHTED ore
# total (#caff_mine_w from sum_mining_weighted), NOT the flat adv.stat_mine count, so the
# competition delta is the rarity-weighted ore value mined during the window.
execute if score #comp_active ec.var matches 2 as @a run function evercraft:craft_affinity/sum_mining_weighted
execute if score #comp_active ec.var matches 2 as @a run scoreboard players operation @s ec.comp_baseline = #caff_mine_w ec.temp
execute if score #comp_active ec.var matches 4 as @a run scoreboard players operation @s ec.comp_baseline = @s ach.prospects_done
execute if score #comp_active ec.var matches 5 as @a run scoreboard players operation @s ec.comp_baseline = @s ach.forages_done

# Node comps (Wave 3a, types 7..11): snapshot each player's current node harvest count.
# node_count writes #cnode_cur for the active type; copy it into the per-player baseline so
# track/<node> scores only harvests DURING the window. (Same delta-track idiom as mining.)
execute if score #comp_active ec.var matches 7..11 as @a run function evercraft:competition/track/node_count
execute if score #comp_active ec.var matches 7..11 as @a run scoreboard players operation @s ec.comp_baseline = #cnode_cur ec.temp

# Apply event modifiers (type-specific)
execute if score #comp_active ec.var matches 6 run function evercraft:competition/modifiers/fishing_luck

# Bossbar
bossbar set evercraft:competition visible true
bossbar set evercraft:competition max 6000
bossbar set evercraft:competition value 6000
bossbar set evercraft:competition players @a
# Auto-dismiss the competition banner from the HUD after 30s (re-armed on each show).
schedule function evercraft:bossbar/autodismiss/clear/competition 30s replace

# Type-specific bossbar name + announcement
execute if score #comp_active ec.var matches 1 run function evercraft:competition/announce/cooking
execute if score #comp_active ec.var matches 2 run function evercraft:competition/announce/mining
execute if score #comp_active ec.var matches 3 run function evercraft:competition/announce/forging
execute if score #comp_active ec.var matches 4 run function evercraft:competition/announce/prospecting
execute if score #comp_active ec.var matches 5 run function evercraft:competition/announce/foraging
execute if score #comp_active ec.var matches 6 run function evercraft:competition/announce/fishing
# Node comps (Wave 3a, types 7..11).
execute if score #comp_active ec.var matches 7 run function evercraft:competition/announce/lamentor
execute if score #comp_active ec.var matches 8 run function evercraft:competition/announce/lumberfell
execute if score #comp_active ec.var matches 9 run function evercraft:competition/announce/terrawarp
execute if score #comp_active ec.var matches 10 run function evercraft:competition/announce/sirencall
execute if score #comp_active ec.var matches 11 run function evercraft:competition/announce/gearwright

# Sound
playsound minecraft:entity.ender_dragon.growl master @a[scores={ec.fx_snd=1..}] ~ ~ ~ 0.3 1.5
