# H2H Competition — Invite Timeout
# Runs as target whose invite expired

scoreboard players set @s ec.h2h_inv 0
scoreboard players set @s ec.h2h_inv_cd 0
tag @s remove h2h.pending_target

# #14: tear down the floating picker panel.
function evercraft:competition/h2h/panel/despawn

# Clean up challenger tag
tag @a[tag=h2h.challenger] remove h2h.challenger

data modify storage evercraft:notify stage.c set value [{text:"Competition challenge expired.",color:"gray"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
