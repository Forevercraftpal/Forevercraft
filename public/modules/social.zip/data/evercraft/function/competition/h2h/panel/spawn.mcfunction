# #14 H2H picker — spawn the per-player floating panel (Companion-clone). Run AS the target AT the
# target (receive's context). Replaces the 8-line chat picker. 6 type tiles + Decline, each an
# interaction hitbox writing the SAME ec.h2h the typed /trigger used (house-rule fix). Ownership =
# the universal companion.id (DECISIONS D3 — no new objective). Hover descriptions become static
# second-lines. All entities tagged h2h.panel. READ-ONLY of the invite state.
scoreboard players operation #h2h_owner ec.temp = @s companion.id

# Banner (challenger name resolves live while h2h.challenger is set) + subtitle.
# 26.1: {selector:} renders blank in text_display — bake the challenger's name to $(owner) once
# (the challenger is fixed for the panel's life, so no per-tick re-bake is needed).
data modify storage evercraft:scorebake args.owner set value ""
execute as @a[tag=h2h.challenger,limit=1] run function evercraft:util/gui/owner_name
execute rotated ~ 0 positioned ^ ^2.35 ^1.8 run function evercraft:competition/h2h/panel/spawn_nm with storage evercraft:scorebake args
execute rotated ~ 0 positioned ^ ^2.18 ^1.8 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},billboard:"center",Tags:["h2h.panel"],text:{text:"Pick a type · 2.5 min head-to-head",color:"gray"},shadow:true,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.3f,0.3f,0.3f]}}

# === Row A: Cooking (left) · Mining (right) ===
execute rotated ~ 0 positioned ^ ^1.92 ^1.8 positioned ^0.85 ^0 ^0 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},billboard:"center",Tags:["h2h.panel"],text:{text:"[ Cooking ]",color:"yellow",bold:true},background:1073741824,shadow:true,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.4f,0.4f,0.4f]}}
execute rotated ~ 0 positioned ^ ^1.81 ^1.8 positioned ^0.85 ^0 ^0 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},billboard:"center",Tags:["h2h.panel"],text:{text:"Cook the most items!",color:"gray"},shadow:true,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.2f,0.2f,0.2f]}}
# [strip] ?: 0.8w split into 4 x 0.2 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute rotated ~ 0 positioned ^-0.3 ^1.9 ^1.82 positioned ^0.85 ^0 ^0 run summon interaction ~ ~ ~ {Tags:["h2h.panel","h2h.pick1"],width:0.2f,height:0.28f,response:1b}
execute rotated ~ 0 positioned ^-0.1 ^1.9 ^1.82 positioned ^0.85 ^0 ^0 run summon interaction ~ ~ ~ {Tags:["h2h.panel","h2h.pick1"],width:0.2f,height:0.28f,response:1b}
execute rotated ~ 0 positioned ^0.1 ^1.9 ^1.82 positioned ^0.85 ^0 ^0 run summon interaction ~ ~ ~ {Tags:["h2h.panel","h2h.pick1"],width:0.2f,height:0.28f,response:1b}
execute rotated ~ 0 positioned ^0.3 ^1.9 ^1.82 positioned ^0.85 ^0 ^0 run summon interaction ~ ~ ~ {Tags:["h2h.panel","h2h.pick1"],width:0.2f,height:0.28f,response:1b}
execute rotated ~ 0 positioned ^ ^1.92 ^1.8 positioned ^-0.85 ^0 ^0 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},billboard:"center",Tags:["h2h.panel"],text:{text:"[ Mining ]",color:"aqua",bold:true},background:1073741824,shadow:true,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.4f,0.4f,0.4f]}}
execute rotated ~ 0 positioned ^ ^1.81 ^1.8 positioned ^-0.85 ^0 ^0 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},billboard:"center",Tags:["h2h.panel"],text:{text:"Mine the most blocks!",color:"gray"},shadow:true,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.2f,0.2f,0.2f]}}
# [strip] ?: 0.8w split into 4 x 0.2 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute rotated ~ 0 positioned ^-0.3 ^1.9 ^1.82 positioned ^-0.85 ^0 ^0 run summon interaction ~ ~ ~ {Tags:["h2h.panel","h2h.pick2"],width:0.2f,height:0.28f,response:1b}
execute rotated ~ 0 positioned ^-0.1 ^1.9 ^1.82 positioned ^-0.85 ^0 ^0 run summon interaction ~ ~ ~ {Tags:["h2h.panel","h2h.pick2"],width:0.2f,height:0.28f,response:1b}
execute rotated ~ 0 positioned ^0.1 ^1.9 ^1.82 positioned ^-0.85 ^0 ^0 run summon interaction ~ ~ ~ {Tags:["h2h.panel","h2h.pick2"],width:0.2f,height:0.28f,response:1b}
execute rotated ~ 0 positioned ^0.3 ^1.9 ^1.82 positioned ^-0.85 ^0 ^0 run summon interaction ~ ~ ~ {Tags:["h2h.panel","h2h.pick2"],width:0.2f,height:0.28f,response:1b}

# === Row B: Forging (left) · Prospecting (right) ===
execute rotated ~ 0 positioned ^ ^1.57 ^1.8 positioned ^0.85 ^0 ^0 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},billboard:"center",Tags:["h2h.panel"],text:{text:"[ Forging ]",color:"white",bold:true},background:1073741824,shadow:true,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.4f,0.4f,0.4f]}}
execute rotated ~ 0 positioned ^ ^1.46 ^1.8 positioned ^0.85 ^0 ^0 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},billboard:"center",Tags:["h2h.panel"],text:{text:"Craft the most gear!",color:"gray"},shadow:true,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.2f,0.2f,0.2f]}}
# [strip] ?: 0.8w split into 4 x 0.2 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute rotated ~ 0 positioned ^-0.3 ^1.55 ^1.82 positioned ^0.85 ^0 ^0 run summon interaction ~ ~ ~ {Tags:["h2h.panel","h2h.pick3"],width:0.2f,height:0.28f,response:1b}
execute rotated ~ 0 positioned ^-0.1 ^1.55 ^1.82 positioned ^0.85 ^0 ^0 run summon interaction ~ ~ ~ {Tags:["h2h.panel","h2h.pick3"],width:0.2f,height:0.28f,response:1b}
execute rotated ~ 0 positioned ^0.1 ^1.55 ^1.82 positioned ^0.85 ^0 ^0 run summon interaction ~ ~ ~ {Tags:["h2h.panel","h2h.pick3"],width:0.2f,height:0.28f,response:1b}
execute rotated ~ 0 positioned ^0.3 ^1.55 ^1.82 positioned ^0.85 ^0 ^0 run summon interaction ~ ~ ~ {Tags:["h2h.panel","h2h.pick3"],width:0.2f,height:0.28f,response:1b}
execute rotated ~ 0 positioned ^ ^1.57 ^1.8 positioned ^-0.85 ^0 ^0 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},billboard:"center",Tags:["h2h.panel"],text:{text:"[ Prospecting ]",color:"green",bold:true},background:1073741824,shadow:true,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.4f,0.4f,0.4f]}}
execute rotated ~ 0 positioned ^ ^1.46 ^1.8 positioned ^-0.85 ^0 ^0 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},billboard:"center",Tags:["h2h.panel"],text:{text:"Find the most ores!",color:"gray"},shadow:true,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.2f,0.2f,0.2f]}}
# [strip] ?: 0.8w split into 4 x 0.2 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute rotated ~ 0 positioned ^-0.3 ^1.55 ^1.82 positioned ^-0.85 ^0 ^0 run summon interaction ~ ~ ~ {Tags:["h2h.panel","h2h.pick4"],width:0.2f,height:0.28f,response:1b}
execute rotated ~ 0 positioned ^-0.1 ^1.55 ^1.82 positioned ^-0.85 ^0 ^0 run summon interaction ~ ~ ~ {Tags:["h2h.panel","h2h.pick4"],width:0.2f,height:0.28f,response:1b}
execute rotated ~ 0 positioned ^0.1 ^1.55 ^1.82 positioned ^-0.85 ^0 ^0 run summon interaction ~ ~ ~ {Tags:["h2h.panel","h2h.pick4"],width:0.2f,height:0.28f,response:1b}
execute rotated ~ 0 positioned ^0.3 ^1.55 ^1.82 positioned ^-0.85 ^0 ^0 run summon interaction ~ ~ ~ {Tags:["h2h.panel","h2h.pick4"],width:0.2f,height:0.28f,response:1b}

# === Row C: Foraging (left) · Fishing (right) ===
execute rotated ~ 0 positioned ^ ^1.22 ^1.8 positioned ^0.85 ^0 ^0 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},billboard:"center",Tags:["h2h.panel"],text:{text:"[ Foraging ]",color:"dark_green",bold:true},background:1073741824,shadow:true,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.4f,0.4f,0.4f]}}
execute rotated ~ 0 positioned ^ ^1.11 ^1.8 positioned ^0.85 ^0 ^0 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},billboard:"center",Tags:["h2h.panel"],text:{text:"Gather the most plants!",color:"gray"},shadow:true,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.2f,0.2f,0.2f]}}
# [strip] ?: 0.8w split into 4 x 0.2 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute rotated ~ 0 positioned ^-0.3 ^1.2 ^1.82 positioned ^0.85 ^0 ^0 run summon interaction ~ ~ ~ {Tags:["h2h.panel","h2h.pick5"],width:0.2f,height:0.28f,response:1b}
execute rotated ~ 0 positioned ^-0.1 ^1.2 ^1.82 positioned ^0.85 ^0 ^0 run summon interaction ~ ~ ~ {Tags:["h2h.panel","h2h.pick5"],width:0.2f,height:0.28f,response:1b}
execute rotated ~ 0 positioned ^0.1 ^1.2 ^1.82 positioned ^0.85 ^0 ^0 run summon interaction ~ ~ ~ {Tags:["h2h.panel","h2h.pick5"],width:0.2f,height:0.28f,response:1b}
execute rotated ~ 0 positioned ^0.3 ^1.2 ^1.82 positioned ^0.85 ^0 ^0 run summon interaction ~ ~ ~ {Tags:["h2h.panel","h2h.pick5"],width:0.2f,height:0.28f,response:1b}
execute rotated ~ 0 positioned ^ ^1.22 ^1.8 positioned ^-0.85 ^0 ^0 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},billboard:"center",Tags:["h2h.panel"],text:{text:"[ Fishing ]",color:"blue",bold:true},background:1073741824,shadow:true,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.4f,0.4f,0.4f]}}
execute rotated ~ 0 positioned ^ ^1.11 ^1.8 positioned ^-0.85 ^0 ^0 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},billboard:"center",Tags:["h2h.panel"],text:{text:"Catch the most fish!",color:"gray"},shadow:true,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.2f,0.2f,0.2f]}}
# [strip] ?: 0.8w split into 4 x 0.2 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute rotated ~ 0 positioned ^-0.3 ^1.2 ^1.82 positioned ^-0.85 ^0 ^0 run summon interaction ~ ~ ~ {Tags:["h2h.panel","h2h.pick6"],width:0.2f,height:0.28f,response:1b}
execute rotated ~ 0 positioned ^-0.1 ^1.2 ^1.82 positioned ^-0.85 ^0 ^0 run summon interaction ~ ~ ~ {Tags:["h2h.panel","h2h.pick6"],width:0.2f,height:0.28f,response:1b}
execute rotated ~ 0 positioned ^0.1 ^1.2 ^1.82 positioned ^-0.85 ^0 ^0 run summon interaction ~ ~ ~ {Tags:["h2h.panel","h2h.pick6"],width:0.2f,height:0.28f,response:1b}
execute rotated ~ 0 positioned ^0.3 ^1.2 ^1.82 positioned ^-0.85 ^0 ^0 run summon interaction ~ ~ ~ {Tags:["h2h.panel","h2h.pick6"],width:0.2f,height:0.28f,response:1b}

# === Decline + countdown ===
execute rotated ~ 0 positioned ^ ^0.85 ^1.8 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},billboard:"center",Tags:["h2h.panel"],text:{text:"[ ✖ Decline ]",color:"red",bold:true},background:1073741824,shadow:true,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.4f,0.4f,0.4f]}}
# [strip] ?: 0.9w split into 5 x 0.2 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute rotated ~ 0 positioned ^-0.35 ^0.85 ^1.82 run summon interaction ~ ~ ~ {Tags:["h2h.panel","h2h.decline_click"],width:0.2f,height:0.28f,response:1b}
execute rotated ~ 0 positioned ^-0.175 ^0.85 ^1.82 run summon interaction ~ ~ ~ {Tags:["h2h.panel","h2h.decline_click"],width:0.2f,height:0.28f,response:1b}
execute rotated ~ 0 positioned ^0 ^0.85 ^1.82 run summon interaction ~ ~ ~ {Tags:["h2h.panel","h2h.decline_click"],width:0.2f,height:0.28f,response:1b}
execute rotated ~ 0 positioned ^0.175 ^0.85 ^1.82 run summon interaction ~ ~ ~ {Tags:["h2h.panel","h2h.decline_click"],width:0.2f,height:0.28f,response:1b}
execute rotated ~ 0 positioned ^0.35 ^0.85 ^1.82 run summon interaction ~ ~ ~ {Tags:["h2h.panel","h2h.decline_click"],width:0.2f,height:0.28f,response:1b}
# Countdown row: tagged h2h.cd, filled by set_cd (26.1: {score:} renders blank in text_display, so the
# live seconds are baked via macro here and re-baked every tick in panel/tick).
execute rotated ~ 0 positioned ^ ^0.66 ^1.8 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},billboard:"center",Tags:["h2h.panel","h2h.cd"],text:["",{text:"Expires in ",color:"dark_gray"},{text:"…",color:"gray"},{text:"s",color:"dark_gray"}],shadow:true,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.28f,0.28f,0.28f]}}

# Stamp ownership (companion.id) onto every panel entity for the click scan + teardown.
scoreboard players operation @e[tag=h2h.panel,distance=..6] companion.id = #h2h_owner ec.temp
# Seed the countdown display immediately.
scoreboard players operation #h2h_secs ec.var = @s ec.h2h_inv_cd
scoreboard players operation #h2h_secs ec.var /= #20 ec.const
execute store result storage evercraft:scorebake args.secs int 1 run scoreboard players get #h2h_secs ec.var
function evercraft:competition/h2h/panel/set_cd with storage evercraft:scorebake args
