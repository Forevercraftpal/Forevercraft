# H2H Competition — Receive Invite (runs as target)
# Challenger has h2h.challenger tag

# Block if target is in restricted state
execute if entity @s[tag=h2h.participant] run return 0
execute if entity @s[tag=ec.duel_active_tag] run return 0
execute if entity @s[tag=dr.in_realm] run return 0
execute if entity @s[tag=dg.player] run return 0

# Mark invite state
scoreboard players set @s ec.h2h_inv 1
scoreboard players set @s ec.h2h_inv_cd 1200
tag @s add h2h.pending_target

# Enable trigger for target
scoreboard players enable @s ec.h2h

# Notify challenger
data modify storage evercraft:notify stage.c set value [{text:"Competition challenge sent to ",color:"yellow"},{selector:"@a[tag=h2h.pending_target]",color:"aqua"},{text:"!",color:"yellow"}]
scoreboard players set #ndur ec.temp 45
execute as @a[tag=h2h.challenger] run function evercraft:util/notify/emit

# #14 — open the floating picker panel at the target's face (was the 8-line /trigger chat picker).
# The panel's hitboxes write the SAME ec.h2h, so trigger_handler/accept/decline are unchanged.
# `at @s` repositions to the target (receive runs AS the target but AT the challenger's position).
execute at @s run function evercraft:competition/h2h/panel/spawn

# Sound
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 1 1.5
