# H2H Competition — End by Disconnect
# Not enough participants online

data modify storage evercraft:notify stage.c set value [{text:"Head-to-head ended — opponent disconnected.",color:"gray"}]
scoreboard players set #ndur ec.temp 45
execute as @a[tag=h2h.participant] run function evercraft:util/notify/emit

# Give remaining participant participation XP
execute as @a[tag=h2h.participant] at @s run experience add @s 20

function evercraft:competition/h2h/cleanup
