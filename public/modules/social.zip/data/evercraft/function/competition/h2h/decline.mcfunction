# H2H Competition — Decline
# Runs as the target player

execute unless entity @s[tag=h2h.pending_target] run return 0

scoreboard players set @s ec.h2h_inv 0
scoreboard players set @s ec.h2h_inv_cd 0
tag @s remove h2h.pending_target

# #14: tear down the floating picker panel.
function evercraft:competition/h2h/panel/despawn

# Notify challenger
data modify storage evercraft:notify stage.c set value [{selector:"@a[tag=h2h.pending_target]",color:"red"},{text:" declined your competition challenge.",color:"gray"}]
scoreboard players set #ndur ec.temp 45
execute as @a[tag=h2h.challenger] run function evercraft:util/notify/emit

# Clean up challenger tag
tag @a[tag=h2h.challenger] remove h2h.challenger

data modify storage evercraft:notify stage.c set value [{text:"Competition challenge declined.",color:"gray"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
