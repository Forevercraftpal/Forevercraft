# #14 H2H picker — despawn. Run AS the target (from accept/decline/timeout). Kills this target's
# picker entities, scoped by companion.id so a (theoretical) second invitee's panel is untouched.
scoreboard players operation #h2h_owner ec.temp = @s companion.id
execute at @s as @e[tag=h2h.panel,distance=..16] if score @s companion.id = #h2h_owner ec.temp run kill @s
