# #14 H2H picker — per-tick scan. Dispatched from root tick: `as @a[tag=h2h.pending_target] at @s`.
# Run AS the target. Scans the 7 hitboxes → writes the SAME ec.h2h the typed /trigger used (root
# tick:582-583 → trigger_handler → accept/decline, unchanged) + refreshes the countdown. Ownership
# via companion.id (only this target's panel; concurrent invites are blocked server-wide).
scoreboard players operation #h2h_owner ec.temp = @s companion.id
scoreboard players set #h2h_pick ec.temp 0

# Detect which tile / Decline was clicked (one crosshair → at most one has interaction data).
execute as @e[type=interaction,tag=h2h.pick1,distance=..16] if score @s companion.id = #h2h_owner ec.temp if data entity @s interaction run scoreboard players set #h2h_pick ec.temp 1
execute as @e[type=interaction,tag=h2h.pick2,distance=..16] if score @s companion.id = #h2h_owner ec.temp if data entity @s interaction run scoreboard players set #h2h_pick ec.temp 2
execute as @e[type=interaction,tag=h2h.pick3,distance=..16] if score @s companion.id = #h2h_owner ec.temp if data entity @s interaction run scoreboard players set #h2h_pick ec.temp 3
execute as @e[type=interaction,tag=h2h.pick4,distance=..16] if score @s companion.id = #h2h_owner ec.temp if data entity @s interaction run scoreboard players set #h2h_pick ec.temp 4
execute as @e[type=interaction,tag=h2h.pick5,distance=..16] if score @s companion.id = #h2h_owner ec.temp if data entity @s interaction run scoreboard players set #h2h_pick ec.temp 5
execute as @e[type=interaction,tag=h2h.pick6,distance=..16] if score @s companion.id = #h2h_owner ec.temp if data entity @s interaction run scoreboard players set #h2h_pick ec.temp 6
execute as @e[type=interaction,tag=h2h.decline_click,distance=..16] if score @s companion.id = #h2h_owner ec.temp if data entity @s interaction run scoreboard players set #h2h_pick ec.temp -1

# Flush all panel hitboxes that registered a click, then apply the pick to ec.h2h on the target.
execute as @e[type=interaction,tag=h2h.panel,distance=..16] if score @s companion.id = #h2h_owner ec.temp if data entity @s interaction run data remove entity @s interaction
execute unless score #h2h_pick ec.temp matches 0 run scoreboard players operation @s ec.h2h = #h2h_pick ec.temp

# Unified UI-click FX (Joseph 2026-06-05): a non-zero pick this tick means the target clicked a tile or
# Decline — @s is the clicker, so play the gated cue ONCE.
execute unless score #h2h_pick ec.temp matches 0 run function evercraft:fx/ui/click

# Refresh the countdown seconds (ec.h2h_inv_cd is in ticks; #20 ec.const = 20).
scoreboard players operation #h2h_secs ec.var = @s ec.h2h_inv_cd
scoreboard players operation #h2h_secs ec.var /= #20 ec.const
# 26.1: {score:} renders blank in text_display, so re-bake the seconds into the h2h.cd row each tick.
execute store result storage evercraft:scorebake args.secs int 1 run scoreboard players get #h2h_secs ec.var
function evercraft:competition/h2h/panel/set_cd with storage evercraft:scorebake args
