# H2H panel — bake the countdown seconds into the h2h.cd text_display (macro).
# 26.1: {score:} renders blank in text_display, so #h2h_secs is passed as $(secs) via storage.
# Called `with storage evercraft:scorebake args` from panel/spawn (seed) and panel/tick (each second).
# Run at the target; distance-limited so it only touches this target's panel (concurrent invites blocked).
$execute positioned ~ ~ ~ run data modify entity @e[type=text_display,tag=h2h.cd,distance=..16,limit=1,sort=nearest] text set value ["",{text:"Expires in ",color:"dark_gray"},{text:"$(secs)",color:"gray"},{text:"s",color:"dark_gray"}]
