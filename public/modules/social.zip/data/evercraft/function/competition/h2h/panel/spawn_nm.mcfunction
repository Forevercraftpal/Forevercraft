# H2H panel banner (macro). 26.1: {selector:} is blank in text_display, so the challenger's profile
# name is staged to evercraft:scorebake args.owner (by util/gui/owner_name run as @a[tag=h2h.challenger])
# and baked here as the frozen $(owner) literal. The challenger is fixed for the panel's life, so this
# is baked once at spawn (no per-tick re-bake needed). Position inherited from the call site.
$summon text_display ~ ~ ~ {brightness:{block:15,sky:15},billboard:"center",Tags:["h2h.panel"],text:["",{text:"★ ",color:"gold"},{text:"$(owner)",color:"aqua",bold:true},{text:" challenges you!",color:"yellow"}],background:1073741824,shadow:true,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.5f,0.5f,0.5f]}}
