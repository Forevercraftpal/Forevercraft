$# H2H Competition — Accept (runs as target, type=$(type))

# Validate invite exists
execute unless score @s ec.h2h_inv matches 1 run return 0
execute unless entity @s[tag=h2h.pending_target] run return 0

# Clear invite state
scoreboard players set @s ec.h2h_inv 0
scoreboard players set @s ec.h2h_inv_cd 0
tag @s remove h2h.pending_target

# #14: tear down the floating picker panel.
function evercraft:competition/h2h/panel/despawn

# Validate challenger still online
execute unless entity @a[tag=h2h.challenger] run data modify storage evercraft:notify stage.c set value [{text:"Challenger is no longer available.",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute unless entity @a[tag=h2h.challenger] run return run function evercraft:util/notify/emit

# Set active type and timer
$scoreboard players set #h2h_active ec.var $(type)
scoreboard players set #h2h_timer ec.var 3000

# Tag both as participants
tag @s add h2h.participant
execute as @a[tag=h2h.challenger] run tag @s add h2h.participant
tag @a[tag=h2h.challenger] remove h2h.challenger

# Reset scores
execute as @a[tag=h2h.participant] run scoreboard players set @s ec.h2h_score 0
execute as @a[tag=h2h.participant] run scoreboard players set @s ec.h2h_baseline 0

# Take baseline snapshots for delta-track types
execute if score #h2h_active ec.var matches 2 as @a[tag=h2h.participant] run scoreboard players operation @s ec.h2h_baseline = @s adv.stat_mine
execute if score #h2h_active ec.var matches 4 as @a[tag=h2h.participant] run scoreboard players operation @s ec.h2h_baseline = @s ach.prospects_done
execute if score #h2h_active ec.var matches 5 as @a[tag=h2h.participant] run scoreboard players operation @s ec.h2h_baseline = @s ach.forages_done

# Apply fishing luck modifier if fishing type
execute if score #h2h_active ec.var matches 6 as @a[tag=h2h.participant] run attribute @s luck modifier add ec_h2h_fishing 0.5 add_value

# Setup bossbar
bossbar add evercraft:h2h_competition {"text":"Head-to-Head","color":"gold"}
bossbar set evercraft:h2h_competition visible true
bossbar set evercraft:h2h_competition players @a[tag=h2h.participant]
bossbar set evercraft:h2h_competition color yellow
bossbar set evercraft:h2h_competition max 3000
bossbar set evercraft:h2h_competition value 3000

# Type-specific bossbar name
execute if score #h2h_active ec.var matches 1 run bossbar set evercraft:h2h_competition name {"text":"Head-to-Head: Cooking","color":"gold"}
execute if score #h2h_active ec.var matches 2 run bossbar set evercraft:h2h_competition name {"text":"Head-to-Head: Mining","color":"gold"}
execute if score #h2h_active ec.var matches 3 run bossbar set evercraft:h2h_competition name {"text":"Head-to-Head: Forging","color":"gold"}
execute if score #h2h_active ec.var matches 4 run bossbar set evercraft:h2h_competition name {"text":"Head-to-Head: Prospecting","color":"gold"}
execute if score #h2h_active ec.var matches 5 run bossbar set evercraft:h2h_competition name {"text":"Head-to-Head: Foraging","color":"gold"}
execute if score #h2h_active ec.var matches 6 run bossbar set evercraft:h2h_competition name {"text":"Head-to-Head: Fishing","color":"gold"}

# Announce
data modify storage evercraft:notify stage.c set value [{text:"★ HEAD-TO-HEAD COMPETITION ★",color:"gold"}]
scoreboard players set #ndur ec.temp 50
execute as @a[tag=h2h.participant] run function evercraft:util/notify/emit
scoreboard players set #ndur ec.temp 40
execute if score #h2h_active ec.var matches 1 run data modify storage evercraft:notify stage.c set value [{text:"Type: ",color:"gray"},{text:"Cooking",color:"yellow"},{text:" — Cook the most items in 2.5 minutes!",color:"gray"}]
execute if score #h2h_active ec.var matches 1 run execute as @a[tag=h2h.participant] run function evercraft:util/notify/emit
execute if score #h2h_active ec.var matches 2 run data modify storage evercraft:notify stage.c set value [{text:"Type: ",color:"gray"},{text:"Mining",color:"aqua"},{text:" — Mine the most blocks in 2.5 minutes!",color:"gray"}]
execute if score #h2h_active ec.var matches 2 run execute as @a[tag=h2h.participant] run function evercraft:util/notify/emit
execute if score #h2h_active ec.var matches 3 run data modify storage evercraft:notify stage.c set value [{text:"Type: ",color:"gray"},{text:"Forging",color:"white"},{text:" — Craft the most gear in 2.5 minutes!",color:"gray"}]
execute if score #h2h_active ec.var matches 3 run execute as @a[tag=h2h.participant] run function evercraft:util/notify/emit
execute if score #h2h_active ec.var matches 4 run data modify storage evercraft:notify stage.c set value [{text:"Type: ",color:"gray"},{text:"Prospecting",color:"green"},{text:" — Find the most ores in 2.5 minutes!",color:"gray"}]
execute if score #h2h_active ec.var matches 4 run execute as @a[tag=h2h.participant] run function evercraft:util/notify/emit
execute if score #h2h_active ec.var matches 5 run data modify storage evercraft:notify stage.c set value [{text:"Type: ",color:"gray"},{text:"Foraging",color:"dark_green"},{text:" — Gather the most plants in 2.5 minutes!",color:"gray"}]
execute if score #h2h_active ec.var matches 5 run execute as @a[tag=h2h.participant] run function evercraft:util/notify/emit
execute if score #h2h_active ec.var matches 6 run data modify storage evercraft:notify stage.c set value [{text:"Type: ",color:"gray"},{text:"Fishing",color:"blue"},{text:" — Catch the most fish in 2.5 minutes!",color:"gray"}]
execute if score #h2h_active ec.var matches 6 run execute as @a[tag=h2h.participant] run function evercraft:util/notify/emit

# Title
title @a[tag=h2h.participant] times 5 30 10
title @a[tag=h2h.participant] title {"text":"GO!","color":"gold"}
title @a[tag=h2h.participant] subtitle {"text":"Competition started!","color":"yellow"}

# Sound
execute as @a[tag=h2h.participant] at @s if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.ender_dragon.growl master @s ~ ~ ~ 0.3 1.5
