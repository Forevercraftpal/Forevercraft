# Competition Track — Gearwright's Tinkering (NODE comp, type 11, delta-tracking)
# Score = craft/tinker actions during the window (ec.cnode_craft, incremented once per
# craft action by craft_affinity/gw_grant_t1..t5 (+ on_fuse/on_glyph)). Runs as @s = player.
# Current count - baseline = competition-only delta.
function evercraft:competition/track/node_count
scoreboard players operation @s ec.comp_score = #cnode_cur ec.temp
scoreboard players operation @s ec.comp_score -= @s ec.comp_baseline
# Mark as participant
execute if score @s ec.comp_score matches 1.. run scoreboard players set @s ec.comp_today 1
