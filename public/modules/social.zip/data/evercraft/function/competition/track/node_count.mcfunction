# Competition Track — NODE harvest-count helper (Wave 3a)
# ============================================================
# Run as @s = player. Computes THIS player's current LIFETIME successful-harvest
# count for the ACTIVE node competition (#comp_active 7..11) into #cnode_cur ec.temp.
# Node comps are the SIMPLE tier — score = count of successful harvest actions during
# the window (the baseline-subtract pattern, mirroring competition/track/mining).
#
# Used by BOTH:
#   • competition/start  — snapshots #cnode_cur into ec.comp_baseline at noon.
#   • competition/track/<node>  — reads the live count and subtracts the baseline.
# Keeping the per-node count math in ONE place avoids a baseline/live drift bug.
#
# COUNT SOURCES (per Craft-Affinity verb counters; see craft_affinity/load + sum_verbs):
#   7  Lamentor (shearing)   = block-shears stat (ec.caff_st_wool = minecraft.used:shears)
#                              + sheep-shears (ec.cnode_shear, sole writer on_shear_sheep)
#   8  Lumberfell (felling)  = the curated axe log/wood/stem family sum (#caff_log_rt)
#   9  Terrawarp (digging)   = the curated shovel soft-block family sum (#caff_dirt_rt)
#   10 Sirencall (fishing)   = fish-caught stat (ec.caff_st_fish = minecraft.custom:fish_caught)
#   11 Gearwright (tinkering)= craft actions (ec.cnode_craft, writers gw_grant_t1..t5 + on_fuse/on_glyph)
#
# NOTE: ec.caff_st_wool / ec.caff_st_fish are vanilla-stat objectives — auto-incremented
# by the game, read-only here (never violate one-writer). ec.cnode_shear / ec.cnode_craft
# are each written by exactly one craft_affinity handler. #caff_log_rt / #caff_dirt_rt are
# fake-player family sums recomputed per-@s by sum_verbs (called below for types 8/9 only).

scoreboard players set #cnode_cur ec.temp 0

# --- Type 7 — Lamentor (shearing): block-shears + sheep-shears ---
execute if score #comp_active ec.var matches 7 run scoreboard players operation #cnode_cur ec.temp = @s ec.caff_st_wool
execute if score #comp_active ec.var matches 7 run scoreboard players operation #cnode_cur ec.temp += @s ec.cnode_shear

# --- Type 8/9 — Lumberfell / Terrawarp: compute the curated family sums for this player. ---
# sum_verbs sets BOTH #caff_log_rt and #caff_dirt_rt on ec.temp; call it once when needed.
execute if score #comp_active ec.var matches 8..9 run function evercraft:craft_affinity/sum_verbs
# Type 8 — Lumberfell (tree-felling): all axe-gathered log/wood/stem/fungus blocks.
execute if score #comp_active ec.var matches 8 run scoreboard players operation #cnode_cur ec.temp = #caff_log_rt ec.temp
# Type 9 — Terrawarp (excavation/digging): all shovel-mined soft blocks.
execute if score #comp_active ec.var matches 9 run scoreboard players operation #cnode_cur ec.temp = #caff_dirt_rt ec.temp

# --- Type 10 — Sirencall (fishing-class): fish caught (vanilla stat). ---
execute if score #comp_active ec.var matches 10 run scoreboard players operation #cnode_cur ec.temp = @s ec.caff_st_fish

# --- Type 11 — Gearwright (tinkering): craft actions. ---
execute if score #comp_active ec.var matches 11 run scoreboard players operation #cnode_cur ec.temp = @s ec.cnode_craft
