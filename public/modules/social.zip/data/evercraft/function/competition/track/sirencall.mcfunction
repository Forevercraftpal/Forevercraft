# Competition Track — Sirencall's Catch (NODE comp, type 10, delta-tracking)
# Score = fish caught during the window (the fish-caught vanilla stat). This is the
# SIMPLE node tier (flat per-catch count) — distinct from the rarity-weighted Fishing
# Derby+ (type 6). See PARKED Q1 for the Sirencall-vs-Fishing relationship.
# Runs as @s = player. Current count - baseline = competition-only delta.
function evercraft:competition/track/node_count
scoreboard players operation @s ec.comp_score = #cnode_cur ec.temp
scoreboard players operation @s ec.comp_score -= @s ec.comp_baseline
# Mark as participant
execute if score @s ec.comp_score matches 1.. run scoreboard players set @s ec.comp_today 1
