# Competition Track — Mining Rush (RARITY-WEIGHTED, Wave 3a rework)
# ============================================================
# Score = the WEIGHTED ore total mined during the window, where every ore across ALL
# dimensions is weighted by rarity (Ancient Debris = rarest, Deepslate Emerald = 2nd,
# Deepslate Diamond = 3rd, ...). This REUSES the Stonestrike Craft-Affinity XP ore
# weighting (craft_affinity/sum_mining_weighted -> #caff_mine_w ec.temp) rather than
# inventing a second weight table — the comp and the class share ONE rarity ladder.
#
# Runs as @s = player. sum_mining_weighted sets #caff_mine_w = the player's weighted
# LIFETIME ore total (sum of count×weight over the curated ec.break_* family + ancient
# debris). Current weighted total - weighted baseline = competition-only weighted delta.
# (Baseline snapshotted at noon in competition/start, same idiom — see that file.)
function evercraft:craft_affinity/sum_mining_weighted
scoreboard players operation @s ec.comp_score = #caff_mine_w ec.temp
scoreboard players operation @s ec.comp_score -= @s ec.comp_baseline
# Mark as participant
execute if score @s ec.comp_score matches 1.. run scoreboard players set @s ec.comp_today 1
