# Competition Track — Terrawarp's Excavation (NODE comp, type 9, delta-tracking)
# Score = soft blocks dug during the window (the curated shovel family).
# Runs as @s = player. Current count - baseline = competition-only delta.
function evercraft:competition/track/node_count
scoreboard players operation @s ec.comp_score = #cnode_cur ec.temp
scoreboard players operation @s ec.comp_score -= @s ec.comp_baseline
# Mark as participant
execute if score @s ec.comp_score matches 1.. run scoreboard players set @s ec.comp_today 1
