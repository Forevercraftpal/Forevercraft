# === GUILD CARDS — Adventurer Wrong-Village Redirect (v1.1 UX) ===
# Run as the player. Fired by guild_cards/board_prompt when the player IS eligible to
# advance their Adventurer card but is standing at a board whose village is NOT a frontier
# type — so the matching claim prompt can't fire here. Without this the player would get
# pure silence and assume the system is broken. One-shot Steward redirect naming the
# correct village type. Village vocabulary mirrors claim_adventurer:14.

# Arm the shared throttle (~10s) so this fires once per approach, not every tick.
# board_prompt clears ec.gc_prompt_cd to 0 when the player leaves all board range.
scoreboard players set @s ec.gc_prompt_cd 200

execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 0.4 1.0
tellraw @s ["",{text:"[Guild Steward] ",color:"light_purple",bold:true},{text:"Your Adventurer card is ready to advance — but not at this hall. Seek a frontier village (Combat or Exploration).",color:"gray"}]
