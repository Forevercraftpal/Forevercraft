# === GUILD CARDS — Builder Daily Meter, Per-Player Accrual ===
# Run as @s = a seeded Builder-card player (ec.bc_seeded matches 1).
# Reads the GLOBAL #bc_day_now ec.var set by credit/accrue. SOLE writer (with the
# one-time D4 backfill seed) of ec.bc_snap / ec.bc_today / ec.bc_day / ec.bc_credit.
#
# DAILY SOFT CAP = 8000 blocks/day toward card credit (tunable single knob).

# --- 1. DAY BOUNDARY: if the world day changed since we last credited, reset today. ---
#     This is the REAL reset the cdaff cap lacks (R10): ec.bc_today drops to 0 each day.
execute unless score @s ec.bc_day = #bc_day_now ec.var run scoreboard players set @s ec.bc_today 0
scoreboard players operation @s ec.bc_day = #bc_day_now ec.var

# --- 2. FORWARD DELTA: how many blocks placed since our last sample? ---
#     #bc_gain = adv.stat_place - ec.bc_snap. Then advance the snapshot to now.
scoreboard players operation #bc_gain ec.temp = @s adv.stat_place
scoreboard players operation #bc_gain ec.temp -= @s ec.bc_snap
scoreboard players operation @s ec.bc_snap = @s adv.stat_place

# Guard: a negative delta (adv.stat_place was reset by chrono-shard, or snap drift) is
# discarded — we re-anchor the snapshot (done above) and credit nothing this tick.
execute if score #bc_gain ec.temp matches ..0 run return 0

# --- 3. DAILY CLAMP: only credit up to (cap - already-credited-today). ---
#     #bc_room = 8000 - ec.bc_today (remaining headroom today).
scoreboard players set #bc_room ec.temp 8000
scoreboard players operation #bc_room ec.temp -= @s ec.bc_today

# No headroom left today -> bank nothing (the macro-defense; surplus is NOT carried).
execute if score #bc_room ec.temp matches ..0 run return 0

# Clamp the gain to the remaining room: if gain > room, credit only room.
execute if score #bc_gain ec.temp > #bc_room ec.temp run scoreboard players operation #bc_gain ec.temp = #bc_room ec.temp

# --- 4. BANK: add the clamped gain to today's tally AND the lifetime clean meter. ---
scoreboard players operation @s ec.bc_today += #bc_gain ec.temp
scoreboard players operation @s ec.bc_credit += #bc_gain ec.temp

# --- 5. Re-run the eligibility detector now that the meter rose. ---
function evercraft:guild_cards/check_builder
