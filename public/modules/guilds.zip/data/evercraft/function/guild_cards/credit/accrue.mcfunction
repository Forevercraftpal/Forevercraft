# === GUILD CARDS — Builder Card Clean Daily-Capped Block Meter ===
# Self-scheduling 20t accrual. Existence-gated: only does per-player work for players
# who have actually started the Builder card (ec.bc_seeded matches 1) — until the D4
# backfill prompt is answered, there is no meter to accrue into.
# Scheduled (replace) from guild_cards/load; re-kicks itself here.
#
# THE CLEAN METER (the whole point — R1/R10):
#   ec.bc_credit  is the card's prestige counter. It is fed ONLY from the FORWARD
#   delta of adv.stat_place (blocks placed since the last accrual tick), CLAMPED to a
#   REAL per-day soft cap that ACTUALLY resets at the day boundary (unlike the cdaff
#   bug, R10). This is anti-AFK-macro: a player who macros 1M blocks in a day still
#   only banks the daily cap toward their card; the rest is discarded (NOT carried).
#   ec.bc_credit is NEVER touched by tree-credit / party-combo / chrono-shard (those
#   pollute/reset adv.stat_place — we only read its FORWARD delta, never mirror it).
#
# Per-player objectives (one writer = THIS fn, except the one-time D4 backfill seed):
#   ec.bc_snap   last adv.stat_place value we sampled (delta source)
#   ec.bc_today  blocks credited toward the card TODAY (reset at the day boundary)
#   ec.bc_day    the day number we last credited on (per-player dawn-detect)
#   ec.bc_credit the lifetime clean credit (the prestige meter; += clamped daily gain)
#
# DAILY CAP = 8000 blocks/day toward the card (tunable). A genuine builder hits it in a
# real session; it makes the high tiers a long, honest road and defangs AFK macros.

# Existence gate: nobody on the card -> just re-schedule and stop (no @a scan cost).
execute unless entity @a[scores={ec.bc_seeded=1}] run schedule function evercraft:guild_cards/credit/accrue 20t replace
execute unless entity @a[scores={ec.bc_seeded=1}] run return 0

# Resolve the CURRENT world day ONCE (shared global; #bc_day_now ec.var).
execute store result score #bc_day_now ec.var run time query minecraft:day repetition

# Per-seeded-player accrual.
execute as @a[scores={ec.bc_seeded=1}] run function evercraft:guild_cards/credit/accrue_player

# Self-schedule.
schedule function evercraft:guild_cards/credit/accrue 20t replace
