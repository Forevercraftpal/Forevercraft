# === GUILD CARDS — Merchant Eligibility Detector ===
# Hooked from craftforever/artisan/level_up (fires once per artisan rank gained).
# Run as the player.
# Sets ec.mg_eligible 1 when the artisan level (ec.cf_rank) has crossed the next
# merchant-card tier threshold: ec.cf_rank >= (ec.mg_rank + 1) * 10, and the card
# is not already maxed (ec.mg_rank <= 9).
# This is the SOLE writer of ec.mg_eligible / ec.mg_notified outside the claim fn.

# Already maxed — nothing to do
execute if score @s ec.mg_rank matches 10.. run return 0

# Compute the next tier's required artisan level: (mg_rank + 1) * 10
scoreboard players operation #gc_need ec.temp = @s ec.mg_rank
scoreboard players add #gc_need ec.temp 1
scoreboard players operation #gc_need ec.temp *= #10 ec.const

# Eligible if artisan level has reached/passed that threshold
execute store result score #gc_cf ec.temp run scoreboard players get @s ec.cf_rank
execute if score #gc_cf ec.temp >= #gc_need ec.temp run scoreboard players set @s ec.mg_eligible 1

# On the eligibility edge (eligible AND not yet nudged), fire ONE Seven-voice nudge.
execute if score @s ec.mg_eligible matches 1 if score @s ec.mg_notified matches 0 run function evercraft:guild_cards/notify_merchant
