# === GUILD CARDS — Builder Card Rank -> Display Letter ===
# Run as the player. Maps ec.bc_rank (internal 0..12) to its display letter and
# stores it at storage evercraft:guild_cards bc.letter (a string) for tellraw macros.
# Read-only on ec.bc_rank.
#
#   0 ?  · 1 G · 2 F · 3 E · 4 D · 5 C · 6 B · 7 A · 8 S · 9 SS · 10 SSS · 11 X · 12 V
# X = Mastercrafter (special-title ID 14); V = hidden Master-of-Masters (ID 16).

data modify storage evercraft:guild_cards bc.letter set value "?"
execute if score @s ec.bc_rank matches 1 run data modify storage evercraft:guild_cards bc.letter set value "G"
execute if score @s ec.bc_rank matches 2 run data modify storage evercraft:guild_cards bc.letter set value "F"
execute if score @s ec.bc_rank matches 3 run data modify storage evercraft:guild_cards bc.letter set value "E"
execute if score @s ec.bc_rank matches 4 run data modify storage evercraft:guild_cards bc.letter set value "D"
execute if score @s ec.bc_rank matches 5 run data modify storage evercraft:guild_cards bc.letter set value "C"
execute if score @s ec.bc_rank matches 6 run data modify storage evercraft:guild_cards bc.letter set value "B"
execute if score @s ec.bc_rank matches 7 run data modify storage evercraft:guild_cards bc.letter set value "A"
execute if score @s ec.bc_rank matches 8 run data modify storage evercraft:guild_cards bc.letter set value "S"
execute if score @s ec.bc_rank matches 9 run data modify storage evercraft:guild_cards bc.letter set value "SS"
execute if score @s ec.bc_rank matches 10 run data modify storage evercraft:guild_cards bc.letter set value "SSS"
execute if score @s ec.bc_rank matches 11 run data modify storage evercraft:guild_cards bc.letter set value "X"
execute if score @s ec.bc_rank matches 12 run data modify storage evercraft:guild_cards bc.letter set value "V"
