# === GUILD CARDS — Builder Card 13-Tier Blocks Threshold Lookup ===
# Run as the player. Computes the blocks-placed credit (#bc_need ec.temp) required
# to ADVANCE FROM the current claimed rank (ec.bc_rank, internal 0..12) to the next.
# Read-only on ec.bc_rank; writes only the scratch handle #bc_need ec.temp.
#
# The 13 letter-tiers (internal rank -> letter, mirrors the dream_rank ladder but
# tuned for an honest, daily-capped block meter — the BLOCK count to reach each):
#   0  starter (?)    — baseline, granted at first card claim
#   1  G       250
#   2  F       750
#   3  E       2,000
#   4  D       5,000
#   5  C       12,000
#   6  B       30,000
#   7  A       70,000
#   8  S       150,000
#   9  SS      350,000
#   10 SSS     750,000   <- the council "Some"-backfill cap (Decision D4)
#   11 X       2,000,000 <- Mastercrafter (special-title ID 14)
#   12 V       10,000,000<- hidden Master-of-Masters (special-title ID 16)
#
# #bc_need is the credit threshold to reach (rank+1). If already at 12 (max),
# #bc_need is set very high so check_builder never flags eligible.

# Default: a sentinel ceiling so max-rank never re-flags.
scoreboard players set #bc_need ec.temp 2147483647

execute if score @s ec.bc_rank matches 0 run scoreboard players set #bc_need ec.temp 250
execute if score @s ec.bc_rank matches 1 run scoreboard players set #bc_need ec.temp 750
execute if score @s ec.bc_rank matches 2 run scoreboard players set #bc_need ec.temp 2000
execute if score @s ec.bc_rank matches 3 run scoreboard players set #bc_need ec.temp 5000
execute if score @s ec.bc_rank matches 4 run scoreboard players set #bc_need ec.temp 12000
execute if score @s ec.bc_rank matches 5 run scoreboard players set #bc_need ec.temp 30000
execute if score @s ec.bc_rank matches 6 run scoreboard players set #bc_need ec.temp 70000
execute if score @s ec.bc_rank matches 7 run scoreboard players set #bc_need ec.temp 150000
execute if score @s ec.bc_rank matches 8 run scoreboard players set #bc_need ec.temp 350000
execute if score @s ec.bc_rank matches 9 run scoreboard players set #bc_need ec.temp 750000
execute if score @s ec.bc_rank matches 10 run scoreboard players set #bc_need ec.temp 2000000
execute if score @s ec.bc_rank matches 11 run scoreboard players set #bc_need ec.temp 10000000
