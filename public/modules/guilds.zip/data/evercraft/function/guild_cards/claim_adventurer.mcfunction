# === GUILD CARDS — Claim Adventurer Rank-Up ===
# Routed from quests/board/trigger_handler (trigger 41). Run as the player.
# Re-verifies eligibility + that the player is in an ADVENTURER-type village, advances
# ec.ag_rank by 1, dispatches the tier reward, then re-checks eligibility.
# This is the SOLE writer of ec.ag_rank (paired with check_adventurer for the flags).

# Guard: must be flagged eligible
data modify storage evercraft:notify stage.c set value [{text:"You are not yet eligible to advance your Adventurer rank. Raise your Dream Rank first.",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute unless score @s ec.ag_eligible matches 1 run return run function evercraft:util/notify/emit

# Guard: must be standing in an Adventurer-type village (sets #gc_vtype ec.temp)
function evercraft:guild_cards/village_type
data modify storage evercraft:notify stage.c set value [{text:"This is not a frontier village. Seek a Combat or Exploration village's quest board.",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute unless score #gc_vtype ec.temp matches 2 run return run function evercraft:util/notify/emit

# Guard: not already maxed (defensive — eligibility should already gate this)
data modify storage evercraft:notify stage.c set value [{text:"Your Adventurer card is already at the highest rank.",color:"yellow"}]
scoreboard players set #ndur ec.temp 45
execute if score @s ec.ag_rank matches 10.. run return run function evercraft:util/notify/emit

# === ADVANCE THE CLAIMED RANK ===
scoreboard players add @s ec.ag_rank 1

# Rank-up effect
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 1.0 1.0
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.7 1.5
execute at @s if score @s ec.fx_vis matches 1.. run particle minecraft:totem_of_undying ~ ~1.2 ~ 0.4 0.6 0.4 0.2 30
data modify storage evercraft:notify stage.c set value [{text:"ADVENTURER GUILD RANK UP! ",color:"light_purple",bold:true},{score:{name:"@s",objective:"ec.ag_rank"},color:"light_purple",bold:true},{text:"/10",color:"dark_gray"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit

# === DISPATCH TIER REWARD (coins + crate, +cosmetic/title at 4+, +perk at 7+) ===
# Pass card type + new rank to the reward dispatcher via storage (macro args).
data modify storage evercraft:guild_cards args.card set value "adventurer"
execute store result storage evercraft:guild_cards args.new_rank int 1 run scoreboard players get @s ec.ag_rank
execute at @s run function evercraft:guild_cards/rewards/grant with storage evercraft:guild_cards args

# === RE-CHECK ELIGIBILITY ===
# Clear the eligible flag; re-run the detector so a multi-tier catch-up re-arms it
# (one claim per interaction — the player clicks again to take the next tier).
scoreboard players set @s ec.ag_eligible 0
scoreboard players set @s ec.ag_notified 0
function evercraft:guild_cards/check_adventurer
