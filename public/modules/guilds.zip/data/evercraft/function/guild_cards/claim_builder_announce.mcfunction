# === GUILD CARDS — Builder Rank-Up Announcement (macro) ===
# Called: function evercraft:guild_cards/claim_builder_announce with storage evercraft:guild_cards bc
#   bc = {letter:"<G..V or ?>"}  (set by guild_cards/bc/letter)
# Run as the player. Tellraws the new claimed rank with its display letter.

$data modify storage evercraft:notify stage.c set value [{text:"HANDCRAFTER GUILD RANK UP! ",color:"#C49A6C",bold:true},{text:"Tier $(letter)",color:"#E8C9A0",bold:true},{text:"  (",color:"dark_gray"},{score:{name:"@s",objective:"ec.bc_rank"},color:"#C49A6C"},{text:"/12)",color:"dark_gray"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
