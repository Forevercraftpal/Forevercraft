# === GUILD CARDS — Builder Eligibility Detector ===
# Run as the player. Called from credit/accrue (after the daily-capped credit rises)
# and from claim_builder (to re-arm a multi-tier catch-up).
# Sets ec.bc_eligible 1 when the clean, daily-capped block meter (ec.bc_credit) has
# reached the next builder-card tier threshold (bc/threshold -> #bc_need ec.temp),
# and the card is not already at max rank (ec.bc_rank <= 11).
# This is the SOLE writer of ec.bc_eligible / ec.bc_notified outside the claim fn.
#
# NOTE: the card meter ec.bc_credit is a DEDICATED clean counter (written ONLY by
# credit/accrue and the one-time D4 backfill seed) — NOT adv.stat_place. This
# protects card prestige from tree-credit / party-combo pollution + chrono reset (R1).

# Already maxed (internal rank 12 = V) — nothing to do.
execute if score @s ec.bc_rank matches 12.. run return 0

# Must have chosen a backfill amount (D4 latch) before the card can flag eligible.
# Until ec.bc_seeded is set, the Full/Some/None prompt is still pending — seed nothing.
execute unless score @s ec.bc_seeded matches 1 run return 0

# Resolve the credit needed to advance from the current rank (sets #bc_need ec.temp).
function evercraft:guild_cards/bc/threshold

# Eligible if the clean daily-capped credit has reached/passed that threshold.
execute if score @s ec.bc_credit >= #bc_need ec.temp run scoreboard players set @s ec.bc_eligible 1

# On the eligibility edge (eligible AND not yet nudged), fire ONE Seven-voice nudge.
execute if score @s ec.bc_eligible matches 1 if score @s ec.bc_notified matches 0 run function evercraft:guild_cards/notify_builder
