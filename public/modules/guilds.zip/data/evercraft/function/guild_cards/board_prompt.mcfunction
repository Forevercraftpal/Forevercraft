# === GUILD CARDS — Per-Player Board-Proximity Rank-Up Prompt (v1.1) ===
# Replaces the old shared static book rows (which showed BOTH rank-up options to everyone)
# with a per-player clickable chat nudge from the "Guild Steward", shown only to a player
# who is BOTH eligible AND standing at a matching-type village's quest board.
#
# Dispatched from root tick.mcfunction, existence-gated on a quests.board entity existing.
# Run as: each player who is near a board (selector applied by the caller). Run AT @s.
#
# Throttle: ec.gc_prompt_cd is the per-player cooldown (one writer = this fn for arm;
# decremented in tick.mcfunction's cooldown cluster, mirroring ec.ecodex_cd). Fires once
# per approach; cleared to 0 when the player leaves all board range so re-approaching
# re-prompts. The actual claim (trigger 40/41 -> claim_merchant/claim_adventurer) still
# re-verifies eligibility + village type server-side; this only changes the PROMPT surface.

# Is there a quest board within ~6 blocks of this player?
execute unless entity @e[type=armor_stand,tag=quests.board,distance=..6,limit=1] run scoreboard players set @s ec.gc_prompt_cd 0
execute unless entity @e[type=armor_stand,tag=quests.board,distance=..6,limit=1] run return 0

# In range — if still on cooldown, do nothing (one prompt per approach).
execute if score @s ec.gc_prompt_cd matches 1.. run return 0

# Nothing to offer unless eligible for at least one card.
execute unless score @s ec.mg_eligible matches 1 unless score @s ec.ag_eligible matches 1 unless score @s ec.bc_eligible matches 1 run return 0

# Classify this player's CURRENT village type (sets #gc_vtype ec.temp: 0/1 merchant/2 adventurer).
function evercraft:guild_cards/village_type

# Merchant prompt — eligible AND at a crafting-type village board.
execute if score @s ec.mg_eligible matches 1 if score #gc_vtype ec.temp matches 1 run function evercraft:guild_cards/board_prompt_merchant

# Builder (Handcrafter) prompt — eligible AND at a crafting-type village board (vtype 1, R6).
# A builder is a crafting identity, so it shares the crafting-village classification with the
# Merchant. A player eligible for BOTH at a crafting board sees two staggered nudges
# (WAVE-PLAN locked-default; the shared ec.gc_prompt_cd throttle keeps them one-per-approach).
execute if score @s ec.bc_eligible matches 1 if score #gc_vtype ec.temp matches 1 run function evercraft:guild_cards/board_prompt_builder

# Adventurer prompt — eligible AND at a frontier-type village board.
execute if score @s ec.ag_eligible matches 1 if score #gc_vtype ec.temp matches 2 run function evercraft:guild_cards/board_prompt_adventurer

# === Wrong-village redirects (the eligible-but-silent dead-spot fix) ===
# A player eligible for a card but standing at the WRONG board type used to get pure
# silence (the matching branch above never fires) — which reads as broken. Instead, if
# still un-throttled after the matching prompts, surface a one-shot Steward redirect that
# names the correct village type. Same ec.gc_prompt_cd throttle (no new objective, no spam).
# Crafting-card eligible (Merchant or Builder) but NOT at a crafting board -> point to one.
execute if score @s ec.gc_prompt_cd matches ..0 if score @s ec.mg_eligible matches 1 unless score #gc_vtype ec.temp matches 1 run function evercraft:guild_cards/board_redirect_merchant
execute if score @s ec.gc_prompt_cd matches ..0 if score @s ec.bc_eligible matches 1 unless score #gc_vtype ec.temp matches 1 run function evercraft:guild_cards/board_redirect_merchant
# Adventurer eligible but NOT at a frontier board -> point to one.
execute if score @s ec.gc_prompt_cd matches ..0 if score @s ec.ag_eligible matches 1 unless score #gc_vtype ec.temp matches 2 run function evercraft:guild_cards/board_redirect_adventurer
