# === GUILD CARDS — Merchant Permanent Perk (rank >= 7) ===
# Run as the player. Sets ec.cr_guild (CR boost summed into ec.craft_rate by
# craftforever/craft_rate/calculate). One writer of ec.cr_guild lives here.
# CR is stored x10 (so 10 = +1.0 CR). Unified+trimmed ladder (Joseph 2026-06-02 — DECISION-BATCH):
#   rank 7 -> +0.5   rank 8 -> +1.0   rank 9 -> +1.5   rank 10 -> +2.0
#   Clean +0.5/rank line, no capstone spike (was +1.0/+2.0/+3.0/+5.0). Adventurer increments in lockstep.

execute store result score #gc_t ec.temp run data get storage evercraft:guild_cards args.new_rank

execute if score #gc_t ec.temp matches 7 run scoreboard players set @s ec.cr_guild 5
execute if score #gc_t ec.temp matches 8 run scoreboard players set @s ec.cr_guild 10
execute if score #gc_t ec.temp matches 9 run scoreboard players set @s ec.cr_guild 15
execute if score #gc_t ec.temp matches 10 run scoreboard players set @s ec.cr_guild 20

# Recalculate craft rate now so the boost is reflected immediately
function evercraft:craftforever/craft_rate/calculate

data modify storage evercraft:notify stage.c set value [{text:"⚒ ",color:"#DAA520"},{text:"Permanent Perk: ",color:"gray"},{text:"Trade favour — boosted Craft Rate",color:"#DAA520"},{text:" ⚒",color:"#DAA520"}]
scoreboard players set #ndur ec.temp 45
execute unless score #gc_t ec.temp matches 10 run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"⚒ ",color:"gold"},{text:"Capstone Perk: ",color:"gold",bold:true},{text:"+2.0 Craft Rate, permanently",color:"#DAA520"},{text:" ⚒",color:"gold"}]
scoreboard players set #ndur ec.temp 45
execute if score #gc_t ec.temp matches 10 run function evercraft:util/notify/emit
