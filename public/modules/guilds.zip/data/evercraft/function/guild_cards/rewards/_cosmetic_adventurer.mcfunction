# === GUILD CARDS — Adventurer Cosmetic + Title Grant (rank >= 4) ===
# Run as the player. new_rank is the freshly-claimed Adventurer card rank (4..10).
# Records the highest earned rank-title (source-of-truth) AND grants the real equippable
# title (special-title family) + cosmetic tier (adv.cosm_unlock), then announces.
#
# Rank -> title  (special-title ID, see _unlock_special_title for the bit map):
#   rank 4-6  -> ID 11 "Frontier Veteran"
#   rank 7-9  -> ID 12 "Guild Vanguard"
#   rank 10   -> ID 13 "Guild Legend"  (prestige)
# Rank -> cosmetic tier (adv.cosm_unlock bit, see _unlock_cosmetic_tier):
#   rank 4-6  -> Particle Aura (tier 1)
#   rank 7-9  -> Glowing Outline (tier 4)
#   rank 10   -> Crown Particles (tier 5, prestige)

# Title rank source-of-truth (one writer cluster: rewards).
execute store result score #gc_t ec.temp run data get storage evercraft:guild_cards args.new_rank
scoreboard players operation @s ec.ag_title = #gc_t ec.temp

# Cosmetic unlock flag (1 = unlocked; rank 10 = 2 = prestige cosmetic)
scoreboard players set @s ec.ag_cosmetic 1
execute if score #gc_t ec.temp matches 10 run scoreboard players set @s ec.ag_cosmetic 2

# === GRANT THE REAL EQUIPPABLE TITLE (special-title family bitfield) ===
execute if score #gc_t ec.temp matches 4..6 run function evercraft:guild_cards/rewards/_unlock_special_title {tid:11}
execute if score #gc_t ec.temp matches 7..9 run function evercraft:guild_cards/rewards/_unlock_special_title {tid:12}
execute if score #gc_t ec.temp matches 10 run function evercraft:guild_cards/rewards/_unlock_special_title {tid:13}

# === GRANT THE REAL EQUIPPABLE COSMETIC TIER (adv.cosm_unlock bitfield) ===
execute if score #gc_t ec.temp matches 4..6 run function evercraft:guild_cards/rewards/_unlock_cosmetic_tier {tier:1}
execute if score #gc_t ec.temp matches 7..9 run function evercraft:guild_cards/rewards/_unlock_cosmetic_tier {tier:4}
execute if score #gc_t ec.temp matches 10 run function evercraft:guild_cards/rewards/_unlock_cosmetic_tier {tier:5}

# Announce — name the actual unlocked title; point to the equip menu (action-bar frame per band).
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"light_purple"},{text:"Title Unlocked: ",color:"gray"},{text:"Frontier Veteran",color:"light_purple"},{text:" — equip via the Cosmetics menu",color:"dark_gray"},{text:" ✦",color:"light_purple"}]
scoreboard players set #ndur ec.temp 45
execute if score #gc_t ec.temp matches 4..6 run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"light_purple"},{text:"Title Unlocked: ",color:"gray"},{text:"Guild Vanguard",color:"dark_purple"},{text:" — equip via the Cosmetics menu",color:"dark_gray"},{text:" ✦",color:"light_purple"}]
scoreboard players set #ndur ec.temp 45
execute if score #gc_t ec.temp matches 7..9 run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"PRESTIGE: ",color:"gold",bold:true},{text:"Guild Legend",color:"gold",bold:true},{text:" title + prestige cosmetic unlocked!",color:"light_purple"},{text:" ✦",color:"gold"}]
scoreboard players set #ndur ec.temp 45
execute if score #gc_t ec.temp matches 10 run function evercraft:util/notify/emit
