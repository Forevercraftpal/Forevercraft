# === GUILD CARDS — Unlock a Special-Title bit (safe bitfield OR-set) (macro) ===
# Called: function evercraft:guild_cards/rewards/_unlock_special_title {tid:<8..17>}
# Run as the player.
#
# Guild-card titles live in the SHARED special-title family (ec.special_titles bitfield
# / ec.special_title active selection / sp.t_* teams), extending the existing Dream +
# Reputation titles (IDs 1-7, bits 0-6). Guild IDs use bits 7-15:
#   ID  8 (bit 7,  pow 128)   Master Artisan       (Merchant rank 4)
#   ID  9 (bit 8,  pow 256)   Guild Artisan        (Merchant rank 7)
#   ID 10 (bit 9,  pow 512)   Grandmaster Merchant (Merchant rank 10)
#   ID 11 (bit 10, pow 1024)  Frontier Veteran     (Adventurer rank 4)
#   ID 12 (bit 11, pow 2048)  Guild Vanguard       (Adventurer rank 7)
#   ID 13 (bit 12, pow 4096)  Guild Legend         (Adventurer rank 10)
#   ID 14 (bit 13, pow 8192)  Mastercrafter        (Builder rank X / internal 11)  [R4, W2]
#   ID 15 (bit 14, pow 16384) Grand Handcrafter    (Builder rank SSS / internal 10)[R4, W2]
#   ID 16 (bit 15, pow 32768) Hand of the Maker     (Builder rank V / internal 12) [R4, W2]
#   ID 17 (bit 16, pow 65536) Master Tinkerer       (Tinkering line capstone)      [C8]
#   ID 18 (bit 17, pow 131072) Wayfarer             (Wayfarer's Pass capstone)
# Mirrors advantage/cosmetics/crate_unlock_title's safe-set: only OR the bit if unset,
# so re-claiming a tier never double-adds. Does NOT auto-equip; the player selects it in
# the Cosmetics GUI page 6 (do_special_title) like every other special title.
# (Cosmetics GUI page 6 renders IDs 14-17: 4 strings + sp.t_* teams — IDs 14-16 = W3/R4
# Handcrafter sub-task; ID 17 = C8 Master-Tinkerer capstone.)

$scoreboard players set #gc_tid adv.temp $(tid)

# Power-of-2 for this title ID (bit = id-1)
scoreboard players set #gc_pow adv.temp 0
execute if score #gc_tid adv.temp matches 8 run scoreboard players set #gc_pow adv.temp 128
execute if score #gc_tid adv.temp matches 9 run scoreboard players set #gc_pow adv.temp 256
execute if score #gc_tid adv.temp matches 10 run scoreboard players set #gc_pow adv.temp 512
execute if score #gc_tid adv.temp matches 11 run scoreboard players set #gc_pow adv.temp 1024
execute if score #gc_tid adv.temp matches 12 run scoreboard players set #gc_pow adv.temp 2048
execute if score #gc_tid adv.temp matches 13 run scoreboard players set #gc_pow adv.temp 4096
execute if score #gc_tid adv.temp matches 14 run scoreboard players set #gc_pow adv.temp 8192
execute if score #gc_tid adv.temp matches 15 run scoreboard players set #gc_pow adv.temp 16384
execute if score #gc_tid adv.temp matches 16 run scoreboard players set #gc_pow adv.temp 32768
execute if score #gc_tid adv.temp matches 17 run scoreboard players set #gc_pow adv.temp 65536
execute if score #gc_tid adv.temp matches 18 run scoreboard players set #gc_pow adv.temp 131072

# Guard against a bad id (pow still 0 -> nothing to do)
execute if score #gc_pow adv.temp matches 0 run return 0

# Check if bit already set: (special_titles / pow) % 2
scoreboard players set #gc_chk adv.temp 0
scoreboard players operation #gc_chk adv.temp = @s ec.special_titles
scoreboard players operation #gc_chk adv.temp /= #gc_pow adv.temp
scoreboard players operation #gc_chk adv.temp %= #2 adv.temp

# Only OR the bit if not already owned
execute if score #gc_chk adv.temp matches 0 run scoreboard players operation @s ec.special_titles += #gc_pow adv.temp

# Lifetime special-titles-unlocked counter — same not-already-owned gate so re-claiming a tier never double-counts.
execute if score #gc_chk adv.temp matches 0 run scoreboard players add @s ec.titles_count 1
