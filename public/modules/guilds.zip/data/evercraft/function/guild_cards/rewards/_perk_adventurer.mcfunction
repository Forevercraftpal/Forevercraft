# === GUILD CARDS — Adventurer Permanent Perk (rank >= 7) ===
# Run as the player. Applies permanent attribute modifiers keyed by stable namespaced
# ids (remove-then-add = idempotent, stacks cleanly across ranks). Default ladder (tunable):
#   rank 7  -> +1 max health (total)   rank 8  -> +1 (total)
#   rank 9  -> +2 max health (total)   rank 10 -> +2 (total) + +3% movement speed (small explorer flourish)
# Unified+trimmed (Joseph 2026-06-02 — DECISION-BATCH): small, lockstep with Merchant CR; was +1/+2/+3/+4 +6%.
# The max_health modifier uses ONE stable id, re-added at the new total each rank so it
# never double-applies. The speed modifier uses its own stable id (capstone only).

execute store result score #gc_t ec.temp run data get storage evercraft:guild_cards args.new_rank

# Combat survivability — single modifier id, re-applied at the rank's total value
attribute @s max_health modifier remove evercraft:guild_adv_health
execute if score #gc_t ec.temp matches 7 run attribute @s max_health modifier add evercraft:guild_adv_health 1 add_value
execute if score #gc_t ec.temp matches 8 run attribute @s max_health modifier add evercraft:guild_adv_health 1 add_value
execute if score #gc_t ec.temp matches 9 run attribute @s max_health modifier add evercraft:guild_adv_health 2 add_value
execute if score #gc_t ec.temp matches 10 run attribute @s max_health modifier add evercraft:guild_adv_health 2 add_value

# Exploration capstone — permanent movement speed at rank 10
execute if score #gc_t ec.temp matches 10 run attribute @s movement_speed modifier remove evercraft:guild_adv_speed
execute if score #gc_t ec.temp matches 10 run attribute @s movement_speed modifier add evercraft:guild_adv_speed 0.03 add_multiplied_total

data modify storage evercraft:notify stage.c set value [{text:"⚔ ",color:"light_purple"},{text:"Permanent Perk: ",color:"gray"},{text:"Frontier vigor — boosted max health",color:"light_purple"},{text:" ⚔",color:"light_purple"}]
scoreboard players set #ndur ec.temp 45
execute unless score #gc_t ec.temp matches 10 run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"⚔ ",color:"gold"},{text:"Capstone Perk: ",color:"gold",bold:true},{text:"+2 max health & +3% movement speed, permanently",color:"light_purple"},{text:" ⚔",color:"gold"}]
scoreboard players set #ndur ec.temp 45
execute if score #gc_t ec.temp matches 10 run function evercraft:util/notify/emit
