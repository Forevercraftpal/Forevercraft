# === GUILD CARDS — Builder Reward Dispatcher (macro) ===
# Called: function evercraft:guild_cards/rewards/grant_builder with storage evercraft:guild_cards args
#   args = {card:"builder", new_rank:1..12}
# Run as the player, AT the player (crate spawn needs position context).
# Clone of guild_cards/rewards/grant (Merchant), extended to the 12 claimable Builder
# tiers (G..V). Coins = new_rank * 2 (capped 25); crate tier scales; cosmetic+title at rank >= 4
# (_cosmetic_builder, special-title IDs 14-16); reach-perk latch at rank >= 4 +
# CR/refund-tier perks at rank >= 7 (_perk_builder; the PERK EFFECTS themselves are W3).

# Mirror new_rank into a scoreboard so we can run range ladders (#gc_rank ec.temp).
execute store result score #gc_rank ec.temp run data get storage evercraft:guild_cards args.new_rank

# === ALWAYS: scaling Forever Coins (new_rank * 2, +1 capstone at 12, capped 25 — rebalanced 2026-06-21) ===
scoreboard players operation #gc_coins ec.temp = #gc_rank ec.temp
scoreboard players set #gc_two ec.temp 2
scoreboard players operation #gc_coins ec.temp *= #gc_two ec.temp
execute if score #gc_rank ec.temp matches 12 run scoreboard players add #gc_coins ec.temp 1
execute if score #gc_coins ec.temp matches 26.. run scoreboard players set #gc_coins ec.temp 25
scoreboard players operation @s ec.coins += #gc_coins ec.temp
data modify storage evercraft:notify stage.c set value [{text:"★ ",color:"#E0B0FF"},{score:{name:"#gc_coins",objective:"ec.temp"},color:"#E0B0FF"},{text:" Forever Coins",color:"#E0B0FF"},{text:" ★",color:"#E0B0FF"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit

# === ALWAYS: a tiered reward crate (tier scales with rank) ===
execute if score #gc_rank ec.temp matches 1 run function evercraft:util/give_quest_crate {tier:"common"}
execute if score #gc_rank ec.temp matches 2 run function evercraft:util/give_quest_crate {tier:"uncommon"}
execute if score #gc_rank ec.temp matches 3 run function evercraft:util/give_quest_crate {tier:"uncommon"}
execute if score #gc_rank ec.temp matches 4 run function evercraft:util/give_quest_crate {tier:"rare"}
execute if score #gc_rank ec.temp matches 5 run function evercraft:util/give_quest_crate {tier:"rare"}
execute if score #gc_rank ec.temp matches 6 run function evercraft:util/give_quest_crate {tier:"ornate"}
execute if score #gc_rank ec.temp matches 7 run function evercraft:util/give_quest_crate {tier:"ornate"}
execute if score #gc_rank ec.temp matches 8 run function evercraft:util/give_quest_crate {tier:"exquisite"}
execute if score #gc_rank ec.temp matches 9 run function evercraft:util/give_quest_crate {tier:"exquisite"}
execute if score #gc_rank ec.temp matches 10 run function evercraft:util/give_quest_crate {tier:"exquisite"}
execute if score #gc_rank ec.temp matches 11 run function evercraft:util/give_quest_crate {tier:"mythical"}
execute if score #gc_rank ec.temp matches 12 run function evercraft:util/give_quest_crate {tier:"mythical"}

# === RANK >= 4: cosmetic unlock + rank title (special-title IDs 14-16, Crown cosmetic) ===
execute if score #gc_rank ec.temp matches 4.. run function evercraft:guild_cards/rewards/_cosmetic_builder with storage evercraft:guild_cards args

# === RANK >= 4: per-rank building PERK latch (sets ec.bc_reach etc; perks live in W3) ===
execute if score #gc_rank ec.temp matches 4.. run function evercraft:guild_cards/rewards/_perk_builder with storage evercraft:guild_cards args
