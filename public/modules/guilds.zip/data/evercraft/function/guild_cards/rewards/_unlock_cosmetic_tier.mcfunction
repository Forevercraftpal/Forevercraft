# === GUILD CARDS — Unlock an Advantage cosmetic tier (safe bitfield OR-set) (macro) ===
# Called: function evercraft:guild_cards/rewards/_unlock_cosmetic_tier {tier:<1..5>}
# Run as the player.
#
# The 5 Advantage cosmetics (1 Particle Aura / 2 Title Tag / 3 Effect Trail /
# 4 Glowing Outline / 5 Crown Particles) are owned via the adv.cosm_unlock bitfield
# (bit = tier-1), normally unlocked at Advantage-tree levels 5/10/15/20/25 by
# advantage/cosmetics/check_milestones. Guild-card ranks ALSO unlock a tier here, using
# the same safe-set so a re-claim never double-adds and an already-owned tier is a no-op.
# Once owned, the player toggles it from the existing Advantage Trees cosmetics menu.
# adv.cosm_unlock is a shared bitfield (writers: check_milestones, this fn, chrono reset) —
# this is the codebase's standard multi-writer-into-bitfield convention (cf. ec.special_titles).

$scoreboard players set #gc_ctier adv.temp $(tier)

# Power-of-2 for this tier (bit = tier-1): 1/2/4/8/16
scoreboard players set #gc_cpow adv.temp 0
execute if score #gc_ctier adv.temp matches 1 run scoreboard players set #gc_cpow adv.temp 1
execute if score #gc_ctier adv.temp matches 2 run scoreboard players set #gc_cpow adv.temp 2
execute if score #gc_ctier adv.temp matches 3 run scoreboard players set #gc_cpow adv.temp 4
execute if score #gc_ctier adv.temp matches 4 run scoreboard players set #gc_cpow adv.temp 8
execute if score #gc_ctier adv.temp matches 5 run scoreboard players set #gc_cpow adv.temp 16

# Guard against a bad tier
execute if score #gc_cpow adv.temp matches 0 run return 0

# Check if bit already set: (cosm_unlock / pow) % 2
scoreboard players set #gc_cchk adv.temp 0
scoreboard players operation #gc_cchk adv.temp = @s adv.cosm_unlock
scoreboard players operation #gc_cchk adv.temp /= #gc_cpow adv.temp
scoreboard players operation #gc_cchk adv.temp %= #2 adv.temp

# Only OR the bit if not already owned
execute if score #gc_cchk adv.temp matches 0 run scoreboard players operation @s adv.cosm_unlock += #gc_cpow adv.temp

# Auto-assign a cosmetic tree variant if the player has none yet (mirrors check_milestones)
execute if score @s adv.cosm_tree matches 0 run scoreboard players set @s adv.cosm_tree 1
