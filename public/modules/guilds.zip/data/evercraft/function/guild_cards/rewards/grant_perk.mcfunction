# === GUILD CARDS — Permanent Perk Grant (rank >= 7) (macro) ===
# Called: function evercraft:guild_cards/rewards/grant_perk with storage evercraft:guild_cards args
#   args = {card:"merchant"|"adventurer", new_rank:7..10}
# Run as the player.
#
# Merchant perk  -> Craft Rate boost (ec.cr_guild, summed into ec.craft_rate by
#                   craftforever/craft_rate/calculate). +0.5 CR per rank 7-10 -> +2.0 total at 10.
# Adventurer perk -> a permanent attribute modifier (combat survivability + small capstone speed),
#                    keyed by a stable modifier id so it is idempotent and stacks per rank.
#                    +1/+1/+2/+2 max health (ranks 7-10) + +3% speed at 10, lockstep with Merchant.
# (Unified+trimmed Joseph 2026-06-02 — see DECISION-BATCH; was Merchant +5.0 / Adv +4 +6%.)
#
# TUNABLE (FLAGGED): exact perk magnitudes (CR amounts, +health, +speed) are README
# defaults chosen to be small standing bonuses that don't break balance. See SHIPLOG.
$function evercraft:guild_cards/rewards/_perk_$(card) with storage evercraft:guild_cards args
