# === GUILD CARDS — Builder Permanent Perk Latches + EFFECTS (rank-gated) ===
# Run as the player. new_rank is the freshly-claimed Handcrafter card rank (4..12).
# W2 set the LATCHES; W3 added the EFFECT functions (guild_cards/perks/*) and wires the
# reach effect to apply the instant it unlocks (below). One writer of ec.bc_reach here.
#
# Perk ladder (LIVE as of W3):
#   rank >= 7  (A)   -> ec.bc_reach 1 + apply_reach  (block_interaction_range modifier
#                       evercraft:gc_hand_reach, re-applied on death/join via reapply_all)
#   rank >= 8  (S)   -> on-place refund chance (guild_cards/perks/on_place_refund,
#                       piggybacks W1's on_place_tally line — no second hot-path edit)
#   rank >= 9  (SS)  -> slow-fall while holding a placeable block (perks/cadence, 1s)
#   rank >= 10 (SSS) -> Haste while holding a placeable block (perks/cadence, 1s)
# The cadence/refund perks are READ from ec.bc_rank directly by perks/cadence +
# on_place_tally; only ec.bc_reach is a persistent latch (so the attribute re-applies on
# death/join without re-deriving the rank).

execute store result score #gc_t ec.temp run data get storage evercraft:guild_cards args.new_rank

# Reach latch — the only persistent perk-state objective this wave owns. One writer.
execute if score #gc_t ec.temp matches 7.. run scoreboard players set @s ec.bc_reach 1

# W3: APPLY THE REACH EFFECT NOW (the attribute modifier). The latch ec.bc_reach makes
# it survive death/join via advantage/effects/reapply_all; this call makes it live the
# instant the perk is claimed (idempotent remove-then-add inside apply_reach).
execute if score #gc_t ec.temp matches 7.. run function evercraft:guild_cards/perks/apply_reach

# Player-facing acknowledgement of the perk unlock (the EFFECT arrives with W3).
data modify storage evercraft:notify stage.c set value [{text:"⚒ ",color:"#C49A6C"},{text:"Permanent Perk Unlocked: ",color:"gray"},{text:"Builder's Reach",color:"#C49A6C"},{text:" — extended block-placement range",color:"dark_gray"},{text:" ⚒",color:"#C49A6C"}]
scoreboard players set #ndur ec.temp 45
execute if score #gc_t ec.temp matches 7 run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"⚒ ",color:"#C49A6C"},{text:"Permanent Perk Unlocked: ",color:"gray"},{text:"Resourceful Hands",color:"#C49A6C"},{text:" — a chance to refund placed blocks",color:"dark_gray"},{text:" ⚒",color:"#C49A6C"}]
scoreboard players set #ndur ec.temp 45
execute if score #gc_t ec.temp matches 8 run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"⚒ ",color:"#C49A6C"},{text:"Permanent Perk Unlocked: ",color:"gray"},{text:"Sure Footing",color:"#C49A6C"},{text:" — slow-fall while building",color:"dark_gray"},{text:" ⚒",color:"#C49A6C"}]
scoreboard players set #ndur ec.temp 45
execute if score #gc_t ec.temp matches 9 run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"⚒ ",color:"gold"},{text:"Permanent Perk Unlocked: ",color:"gray"},{text:"Tireless Mason",color:"gold"},{text:" — Haste while building",color:"dark_gray"},{text:" ⚒",color:"gold"}]
scoreboard players set #ndur ec.temp 45
execute if score #gc_t ec.temp matches 10 run function evercraft:util/notify/emit
