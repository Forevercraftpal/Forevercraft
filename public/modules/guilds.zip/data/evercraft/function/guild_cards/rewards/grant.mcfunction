# === GUILD CARDS — Reward Dispatcher (macro) ===
# Called: function evercraft:guild_cards/rewards/grant with storage evercraft:guild_cards args
#   args = {card:"merchant"|"adventurer", new_rank:1..10}
# Run as the player, AT the player (crate spawn needs position context).
#
# Reward bands (README default — tunable):
#   ranks 1-3  : coins + small crate
#   ranks 4-6  : coins + medium crate + cosmetic unlock + rank title
#   ranks 7-9  : coins + large crate  + cosmetic + title + permanent per-rank perk
#   rank  10   : capstone payout + prestige cosmetic + capstone title + strongest perk
#
# Coins = new_rank * 2 (so 2..20), +5 capstone bonus at 10, hard-capped at the 25-coin ceiling.
#   Unified + trimmed 2026-06-02 (Joseph) — see _council/2026-06-02-followup-campaign/DECISION-BATCH.md.
#   Deliberately lean to slow gacha-fuelled power-spikes. Was *25/+100, then *10/+50; the coin audit
#   it anticipated landed 2026-06-21 (global 25-coin cap) → now *2/+5.
# Crate tier scales: 1-2 common/uncommon, 3 uncommon, 4-5 rare, 6 ornate, 7-8 exquisite, 9 exquisite, 10 mythical.
# All cosmetic/title grants are stored as flags (ec.{mg,ag}_title) + tellraw — exact
# title-team colour / cosmetic IDs are FLAGGED as tunable for Joseph (SHIPLOG).

# Mirror new_rank into a scoreboard so we can run range ladders (#gc_rank ec.temp).
execute store result score #gc_rank ec.temp run data get storage evercraft:guild_cards args.new_rank

# === ALWAYS: scaling Forever Coins (new_rank * 2, +5 capstone at 10, capped 25 — Merchant/Adventurer; Builder in grant_builder) ===
scoreboard players operation #gc_coins ec.temp = #gc_rank ec.temp
scoreboard players set #gc_two ec.temp 2
scoreboard players operation #gc_coins ec.temp *= #gc_two ec.temp
execute if score #gc_rank ec.temp matches 10 run scoreboard players add #gc_coins ec.temp 5
execute if score #gc_coins ec.temp matches 26.. run scoreboard players set #gc_coins ec.temp 25
scoreboard players operation @s ec.coins += #gc_coins ec.temp
data modify storage evercraft:notify stage.c set value [{text:"★ ",color:"#E0B0FF"},{score:{name:"#gc_coins",objective:"ec.temp"},color:"#E0B0FF"},{text:" Forever Coins",color:"#E0B0FF"},{text:" ★",color:"#E0B0FF"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit

# === ALWAYS: a tiered reward crate (tier scales with rank) ===
execute if score #gc_rank ec.temp matches 1 run function evercraft:util/give_quest_crate {tier:"common"}
execute if score #gc_rank ec.temp matches 2 run function evercraft:util/give_quest_crate {tier:"uncommon"}
execute if score #gc_rank ec.temp matches 3 run function evercraft:util/give_quest_crate {tier:"uncommon"}
execute if score #gc_rank ec.temp matches 4 run function evercraft:util/give_quest_crate {tier:"rare"}
execute if score #gc_rank ec.temp matches 5 run function evercraft:util/give_quest_crate {tier:"rare"}
execute if score #gc_rank ec.temp matches 6 run function evercraft:util/give_quest_crate {tier:"ornate"}
execute if score #gc_rank ec.temp matches 7 run function evercraft:util/give_quest_crate {tier:"exquisite"}
execute if score #gc_rank ec.temp matches 8 run function evercraft:util/give_quest_crate {tier:"exquisite"}
execute if score #gc_rank ec.temp matches 9 run function evercraft:util/give_quest_crate {tier:"exquisite"}
execute if score #gc_rank ec.temp matches 10 run function evercraft:util/give_quest_crate {tier:"mythical"}

# === RANK >= 4: cosmetic unlock + rank title (per card) ===
execute if score #gc_rank ec.temp matches 4.. run function evercraft:guild_cards/rewards/grant_cosmetic_title with storage evercraft:guild_cards args

# === RANK >= 7: permanent per-rank perk (per card) ===
execute if score #gc_rank ec.temp matches 7.. run function evercraft:guild_cards/rewards/grant_perk with storage evercraft:guild_cards args
