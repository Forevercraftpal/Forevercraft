# === GUILD CARDS — Builder Cosmetic + Title Grant (rank >= 4) ===
# Run as the player. new_rank is the freshly-claimed Handcrafter card rank (4..12).
# Records the highest earned rank-title (ec.bc_title, source-of-truth) AND grants the
# real equippable title (special-title family IDs 14-16) + cosmetic tier
# (adv.cosm_unlock), then announces. Clone of _cosmetic_merchant, extended to the
# Builder's 13-tier letter ladder.
#
# Rank (internal) -> letter -> special-title ID (see _unlock_special_title bit map):
#   rank 4-9   (D..SS)  -> ID 15 "Grand Handcrafter"  (mid title)
#   rank 10    (SSS)    -> ID 15 "Grand Handcrafter"  (kept; the council "Some"-cap tier)
#   rank 11    (X)      -> ID 14 "Mastercrafter"      (prestige, R4 / WAVE-PLAN lock)
#   rank 12    (V)      -> ID 16 "Hand of the Maker"  (hidden capstone, >10M blocks)
# Rank -> cosmetic tier (adv.cosm_unlock bit, see _unlock_cosmetic_tier):
#   rank 4-6   -> Particle Aura  (tier 1)
#   rank 7-9   -> Effect Trail   (tier 3)
#   rank 10    -> Glowing Outline(tier 4)
#   rank 11-12 -> Crown Particles(tier 5, prestige — the Mastercrafter Crown, R4)

# Title rank source-of-truth (one writer cluster: rewards). ec.bc_title = highest claimed rank.
execute store result score #gc_t ec.temp run data get storage evercraft:guild_cards args.new_rank
scoreboard players operation @s ec.bc_title = #gc_t ec.temp

# Cosmetic unlock flag (1 = unlocked; rank 11+ = 2 = prestige cosmetic). One writer.
scoreboard players set @s ec.bc_cosmetic 1
execute if score #gc_t ec.temp matches 11.. run scoreboard players set @s ec.bc_cosmetic 2

# === GRANT THE REAL EQUIPPABLE TITLE (special-title family bitfield, safe-OR) ===
execute if score #gc_t ec.temp matches 4..10 run function evercraft:guild_cards/rewards/_unlock_special_title {tid:15}
execute if score #gc_t ec.temp matches 11 run function evercraft:guild_cards/rewards/_unlock_special_title {tid:14}
execute if score #gc_t ec.temp matches 12 run function evercraft:guild_cards/rewards/_unlock_special_title {tid:16}

# === GRANT THE REAL EQUIPPABLE COSMETIC TIER (adv.cosm_unlock bitfield, safe-OR) ===
execute if score #gc_t ec.temp matches 4..6 run function evercraft:guild_cards/rewards/_unlock_cosmetic_tier {tier:1}
execute if score #gc_t ec.temp matches 7..9 run function evercraft:guild_cards/rewards/_unlock_cosmetic_tier {tier:3}
execute if score #gc_t ec.temp matches 10 run function evercraft:guild_cards/rewards/_unlock_cosmetic_tier {tier:4}
execute if score #gc_t ec.temp matches 11.. run function evercraft:guild_cards/rewards/_unlock_cosmetic_tier {tier:5}

# Announce — name the actual unlocked title; point to the equip menu (action-bar frame per band).
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"#C49A6C"},{text:"Title Unlocked: ",color:"gray"},{text:"Grand Handcrafter",color:"#C49A6C"},{text:" — equip via the Cosmetics menu",color:"dark_gray"},{text:" ✦",color:"#C49A6C"}]
scoreboard players set #ndur ec.temp 45
execute if score #gc_t ec.temp matches 4..10 run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"PRESTIGE: ",color:"gold",bold:true},{text:"Mastercrafter",color:"gold",bold:true},{text:" title + Crown cosmetic unlocked!",color:"#C49A6C"},{text:" ✦",color:"gold"}]
scoreboard players set #ndur ec.temp 45
execute if score #gc_t ec.temp matches 11 run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"#FFD27F"},{text:"LEGEND: ",color:"#FFD27F",bold:true},{text:"Hand of the Maker",color:"#FFD27F",bold:true},{text:" — the hidden capstone title is yours.",color:"#C49A6C"},{text:" ✦",color:"#FFD27F"}]
scoreboard players set #ndur ec.temp 45
execute if score #gc_t ec.temp matches 12 run function evercraft:util/notify/emit
