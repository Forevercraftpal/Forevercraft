# === GUILD CARDS — Cosmetic + Title Grant (rank >= 4) (macro) ===
# Called: function evercraft:guild_cards/rewards/grant_cosmetic_title with storage evercraft:guild_cards args
#   args = {card:"merchant"|"adventurer", new_rank:4..10}
# Run as the player.
#
# Stores the earned title rank (ec.mg_title / ec.ag_title = highest rank-title earned)
# and a cosmetic-unlock flag (ec.mg_cosmetic / ec.ag_cosmetic) as source-of-truth, AND
# (v1.1) grants the REAL equippable title into the special-title family (ec.special_titles
# bitfield IDs 8-13) + the matching Advantage cosmetic tier (adv.cosm_unlock), then announces.
# The player equips both from the existing Cosmetics GUI (Advantage Trees menu, page 6 /
# cosmetics page 1). See _cosmetic_merchant / _cosmetic_adventurer for the rank->title/tier map.
$function evercraft:guild_cards/rewards/_cosmetic_$(card) with storage evercraft:guild_cards args
