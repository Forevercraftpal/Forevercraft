# === GUILD CARDS — Claim Handcrafter (Builder) Rank-Up ===
# Routed from quests/board/trigger_handler (trigger 42, R5). Run as the player.
# Re-verifies eligibility + that the player is in a CRAFTING-type village (vtype 1, R6),
# advances ec.bc_rank by 1, dispatches the tier reward, then re-checks eligibility.
# This is the SOLE writer of ec.bc_rank (paired with check_builder for the flags).

# Guard: must be flagged eligible (server-side re-verify so a hand-typed trigger can't cheat).
data modify storage evercraft:notify stage.c set value [{text:"You are not yet eligible to advance your Handcrafter rank. Set more stone true first.",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute unless score @s ec.bc_eligible matches 1 run return run function evercraft:util/notify/emit

# Guard: must be standing in a crafting-type village (sets #gc_vtype ec.temp; reuse vtype 1).
function evercraft:guild_cards/village_type
data modify storage evercraft:notify stage.c set value [{text:"This is not a crafting village. Seek a Mining, Fishing, Farming, or Scholarly village's quest board.",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute unless score #gc_vtype ec.temp matches 1 run return run function evercraft:util/notify/emit

# Guard: not already maxed (defensive — eligibility should already gate this; rank 12 = V).
data modify storage evercraft:notify stage.c set value [{text:"Your Handcrafter card is already at the highest rank.",color:"yellow"}]
scoreboard players set #ndur ec.temp 45
execute if score @s ec.bc_rank matches 12.. run return run function evercraft:util/notify/emit

# === ADVANCE THE CLAIMED RANK ===
scoreboard players add @s ec.bc_rank 1

# Rank-up effect
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 1.0 1.0
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.7 1.5
execute at @s if score @s ec.fx_vis matches 1.. run particle minecraft:totem_of_undying ~ ~1.2 ~ 0.4 0.6 0.4 0.2 30
# Resolve the new rank's display letter for the announcement.
function evercraft:guild_cards/bc/letter
function evercraft:guild_cards/claim_builder_announce with storage evercraft:guild_cards bc

# === DISPATCH TIER REWARD (coins + crate, +cosmetic/title at 4+, +perk at 7+) ===
data modify storage evercraft:guild_cards args.card set value "builder"
execute store result storage evercraft:guild_cards args.new_rank int 1 run scoreboard players get @s ec.bc_rank
execute at @s run function evercraft:guild_cards/rewards/grant_builder with storage evercraft:guild_cards args

# === RE-CHECK ELIGIBILITY ===
# Clear the eligible flag; re-run the detector so a multi-tier catch-up re-arms it
# (one claim per interaction — the player clicks again to take the next tier).
scoreboard players set @s ec.bc_eligible 0
scoreboard players set @s ec.bc_notified 0
function evercraft:guild_cards/check_builder
