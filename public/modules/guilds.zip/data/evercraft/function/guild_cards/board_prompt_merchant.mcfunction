# === GUILD CARDS — Merchant Board Prompt (v1.1) ===
# Run as the player. Fired by guild_cards/board_prompt when the player is eligible to
# advance their Merchant guild rank AND standing at a crafting-type village's board.
# Per-player clickable nudge -> /trigger ec.quest set 40 -> claim_merchant (re-verifies).

# Arm the throttle (~10s, tunable) so this fires once per approach, not every tick.
# Primary re-arm is leaving board range (board_prompt clears it to 0); this cooldown is
# just the loiter-while-standing-here cadence.
scoreboard players set @s ec.gc_prompt_cd 200

execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.4 1.6
tellraw @s ["",{text:"[Guild Steward] ",color:"#DAA520",bold:true},{text:"⬆ Rank Up available! ",color:"#DAA520",bold:true},{text:"Advance your Merchant Guild rank here. ",color:"gray"},{text:"[⬆ Claim]",color:"#DAA520",bold:true,click_event:{action:"run_command",command:"/trigger ec.quest set 40"},hover_event:{action:"show_text",value:{text:"Advance your Merchant guild card rank",color:"gray"}}}]
