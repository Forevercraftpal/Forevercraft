# === GUILD CARDS — Builder Backfill: NONE (D4) ===
# Routed from quests/board/trigger_handler (trigger 45). Run as the player.
# Seeds 0 — start the climb fresh from the first tier (G). All progress is the clean,
# daily-capped forward meter from here on.
# Server-side re-verify: a hand-typed trigger can't re-seed once answered.

# Guard: one-time only — already answered -> ignore.
data modify storage evercraft:notify stage.c set value [{text:"You have already chosen how to credit your card.",color:"yellow"}]
scoreboard players set #ndur ec.temp 45
execute if score @s ec.bc_seeded matches 1 run return run function evercraft:util/notify/emit

# Seed = 0 (SOLE one-time writer of the seed).
scoreboard players set @s ec.bc_credit 0

function evercraft:guild_cards/backfill/finalize
