# === GUILD CARDS — Builder Backfill Finalize (shared, post-choice) ===
# Run as the player. Called by choose_full / choose_some / choose_none AFTER they have
# set ec.bc_credit to the chosen seed (the seed write happens in the choice fn so the
# SOLE one-time writer of the seed value is unambiguous per-choice). This shared tail:
#   - latches ec.bc_seeded 1 (the D4 one-time-answered latch — gates check_builder)
#   - re-anchors ec.bc_snap to NOW so forward accrual starts clean from 0 delta
#   - confirms + runs check_builder so a backfilled veteran is immediately flagged
#     eligible for the ranks their seed already covers (claimed one-per-click at a board)

scoreboard players set @s ec.bc_seeded 1
scoreboard players operation @s ec.bc_snap = @s adv.stat_place

execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.6 1.2
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"#C49A6C"},{text:"Your Handcrafter card is sealed. ",color:"gray"},{text:"Credited: ",color:"gray"},{score:{name:"@s",objective:"ec.bc_credit"},color:"#C49A6C"},{text:" blocks.",color:"gray"},{text:" ✦",color:"#C49A6C"}]
scoreboard players set #ndur ec.temp 50
function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Claim each rank you have earned at a crafting village's quest board.",color:"dark_gray",italic:true}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit

# Re-run the detector now — a backfilled veteran is flagged eligible immediately.
function evercraft:guild_cards/check_builder
