# === GUILD CARDS — Builder Backfill: FULL (D4) ===
# Routed from quests/board/trigger_handler (trigger 43). Run as the player.
# Seeds the ENTIRE lifetime building snapshot into ec.bc_credit — the veteran is
# eligible up to their TRUE rank (incl. X, and V if > 10M blocks).
# Server-side re-verify: a hand-typed trigger can't re-seed once answered.

# Guard: one-time only — already answered -> ignore.
data modify storage evercraft:notify stage.c set value [{text:"You have already chosen how to credit your card.",color:"yellow"}]
scoreboard players set #ndur ec.temp 45
execute if score @s ec.bc_seeded matches 1 run return run function evercraft:util/notify/emit

# Seed = the full lifetime adv.stat_place snapshot (SOLE one-time writer of the seed).
scoreboard players operation @s ec.bc_credit = @s adv.stat_place

function evercraft:guild_cards/backfill/finalize
