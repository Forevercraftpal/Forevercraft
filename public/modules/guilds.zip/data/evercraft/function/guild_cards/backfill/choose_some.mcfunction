# === GUILD CARDS — Builder Backfill: SOME (D4) ===
# Routed from quests/board/trigger_handler (trigger 44). Run as the player.
# Seeds a PARTIAL amount, CAPPED at tier SSS / 750,000 (the council mid-ground). A
# long-time builder gets a meaningful head start, but Mastercrafter (X) still needs
# forward building. The cap is a single tunable knob (#bc_some_cap below).
# Server-side re-verify: a hand-typed trigger can't re-seed once answered.

# Guard: one-time only — already answered -> ignore.
data modify storage evercraft:notify stage.c set value [{text:"You have already chosen how to credit your card.",color:"yellow"}]
scoreboard players set #ndur ec.temp 45
execute if score @s ec.bc_seeded matches 1 run return run function evercraft:util/notify/emit

# Seed = min(lifetime adv.stat_place, 750000). SOLE one-time writer of the seed.
scoreboard players operation @s ec.bc_credit = @s adv.stat_place
scoreboard players set #bc_some_cap ec.temp 750000
execute if score @s ec.bc_credit > #bc_some_cap ec.temp run scoreboard players operation @s ec.bc_credit = #bc_some_cap ec.temp

function evercraft:guild_cards/backfill/finalize
