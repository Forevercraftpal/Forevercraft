# === GUILD CARDS — Builder Card D4 Backfill Offer (Full / Some / None) ===
# Run as the player. The one-time clickable chat prompt offered on FIRST Builder-card
# grant (Decision D4, Joseph 2026-05-31). PUBLIC entry — called by:
#   - handcrafter/on_first_place (W3) AFTER it grants the card baseline (ec.bc_rank 0)
#   - guild_cards/credit/accrue / any re-entry, sticky: re-offered until answered
#
# STICKY: if the player has already chosen (ec.bc_seeded matches 1) this is a no-op —
# the choice is one-time. Until they choose, NOTHING is seeded and the card is NOT
# flagged eligible (check_builder returns early on `unless ec.bc_seeded matches 1`).
#
# The forward-crediting snapshot baseline (ec.bc_snap) is anchored HERE to the player's
# current adv.stat_place, so post-choice accrual starts cleanly from 0 delta REGARDLESS
# of the backfill amount — only the one-time ec.bc_credit seed differs by choice.

# Already answered -> no-op (one-time prompt).
execute if score @s ec.bc_seeded matches 1 run return 0

# Anchor the forward-credit snapshot to NOW (so the daily meter counts only future blocks).
scoreboard players operation @s ec.bc_snap = @s adv.stat_place

# Surface the player's lifetime building (read-only) so the choice is informed.
execute store result score #bc_life ec.temp run scoreboard players get @s adv.stat_place

execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.5 1.3
tellraw @s ""
tellraw @s [{text:"[Guild] ",color:"#C49A6C"},{text:"Your Handcrafter card is open.",color:"#DDF0EE",italic:true}]
tellraw @s [{text:"  You have already set ",color:"gray"},{score:{name:"#bc_life",objective:"ec.temp"},color:"#C49A6C"},{text:" blocks true in your life. ",color:"gray"},{text:"How much shall I credit toward your card?",color:"gray"}]
tellraw @s [{text:"  ",color:"gray"},{text:"[Full]",color:"#7FD17F",bold:true,click_event:{action:"run_command",command:"/trigger ec.quest set 43"},hover_event:{action:"show_text",value:[{text:"Credit your ENTIRE lifetime building. ",color:"gray"},{text:"Eligible up to your true rank (incl. X / V).",color:"#C49A6C"}]}},{text:"   ",color:"gray"},{text:"[Some]",color:"#E8C9A0",bold:true,click_event:{action:"run_command",command:"/trigger ec.quest set 44"},hover_event:{action:"show_text",value:[{text:"A meaningful head start, capped at tier SSS (750,000). ",color:"gray"},{text:"Mastercrafter (X) still needs forward building.",color:"#C49A6C"}]}},{text:"   ",color:"gray"},{text:"[None]",color:"#C0C0C0",bold:true,click_event:{action:"run_command",command:"/trigger ec.quest set 45"},hover_event:{action:"show_text",value:[{text:"Start the climb fresh from the first tier.",color:"gray"}]}}]
tellraw @s ""
