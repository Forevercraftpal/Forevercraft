# ============================================================
# The Handcrafter — per-player building-perk refresh (1s)
# ============================================================
# Run as @s = a rank-8+ Handcrafter (the cadence existence selector already filtered).
# Grants the "while building" effects for one second iff the player is holding a
# placeable block (predicate evercraft:guild_cards/holding_buildable — a broad block-
# item set, distinct from the narrow craftforever evercraft:is_holding_block used by
# the build-trial particles, which is left untouched). Re-granted each cadence tick;
# they decay a second after the player stops holding a block.
#
#   rank >= 9  (SS)  -> Slow Falling (Sure Footing)
#   rank >= 10 (SSS) -> Haste I      (Tireless Mason)
#
# Duration 2s (40t) with a 1s cadence keeps the effect smooth (no flicker between
# refreshes) while still lapsing ~2s after the player sheaths their blocks. ambient
# (true particles hidden via the last `true` = hideParticles? no — show:false) — we
# pass true for the "ambient/hidden particles" flag so the perk is unobtrusive.

# Slow Falling — rank SS (9)+ while holding a placeable block.
execute if score @s ec.bc_rank matches 9.. if predicate evercraft:guild_cards/holding_buildable run effect give @s minecraft:slow_falling 2 0 true

# Haste I — rank SSS (10)+ while holding a placeable block.
execute if score @s ec.bc_rank matches 10.. if predicate evercraft:guild_cards/holding_buildable run effect give @s minecraft:haste 2 0 true
