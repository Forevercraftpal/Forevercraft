# ============================================================
# The Handcrafter — Builder's Reach perk (rank A / 7+) — EFFECT applier
# ============================================================
# Run as @s = the player. Applies the "Builder's Reach" permanent perk: a
# block_interaction_range bonus via a DISTINCT attribute-modifier id
# evercraft:gc_hand_reach — separate from the Dexterity tree's evercraft:adv_dex_block
# and the prestige evercraft:adv_pres_dex* / adv_pres_dex3, so the Builder perk and
# the Dexterity reach STACK additively (each is its own modifier slot) and neither
# clobbers the other. The latch ec.bc_reach (set by guild_cards/rewards/_perk_builder
# at rank 7) gates this; the EFFECT lives HERE (built in W3 per the W2 contract).
#
# CALLERS:
#   - guild_cards/rewards/_perk_builder (the tick the reach perk unlocks at rank 7)
#   - advantage/effects/reapply_all (re-applies on death/join if ec.bc_reach matches 1,
#     alongside the dex/prestige re-applies, so the modifier survives relog/respawn)
#
# IDEMPOTENT: remove-then-add, so re-calling never double-stacks. +1.0 block reach
# (a flat, honest "longer arm for building" — a QoL builder perk, not a combat axis;
# entity_interaction_range is intentionally NOT touched, so this is reach-to-PLACE
# only, never reach-to-HIT).
attribute @s block_interaction_range modifier remove evercraft:gc_hand_reach
attribute @s block_interaction_range modifier add evercraft:gc_hand_reach 1.0 add_value
