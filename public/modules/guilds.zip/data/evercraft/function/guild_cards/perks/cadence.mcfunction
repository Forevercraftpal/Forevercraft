# ============================================================
# The Handcrafter — Building perk cadence (1s, existence-gated)
# ============================================================
# Self-rescheduling 1s loop (kicked from guild_cards/load with `replace`). Grants the
# high-rank "while building" perks:
#   rank >= 9  (SS)  -> Sure Footing    : Slow Falling while holding a placeable block
#   rank >= 10 (SSS) -> Tireless Mason  : Haste I       while holding a placeable block
# Both perks are refreshed every second only while the player holds a placeable block
# (predicate evercraft:is_holding_block) — they lapse naturally a second after the
# player stops building, so they are strictly a building QoL, never an always-on buff.
#
# EXISTENCE GATE (perf law): the scheduler does per-player work ONLY for
# @a[scores={ec.bc_rank=8..}] — with no rank-8+ Handcrafter online it iterates over
# NOTHING (no per-tick @a scan). The S-band (rank 8) has no cadence perk itself (its
# Resourceful-Hands refund rides the place hook), but it is the cheapest single
# existence selector that also covers ranks 9/10; the per-player helper re-gates by
# exact rank. Kicked once from guild_cards/load; re-schedules itself here.

# Existence gate: no rank-8+ Handcrafter online -> just re-schedule and stop.
execute unless entity @a[scores={ec.bc_rank=8..}] run schedule function evercraft:guild_cards/perks/cadence 20t replace
execute unless entity @a[scores={ec.bc_rank=8..}] run return 0

# Per-eligible-player perk refresh.
execute as @a[scores={ec.bc_rank=8..}] run function evercraft:guild_cards/perks/cadence_player

# Self-schedule (1s).
schedule function evercraft:guild_cards/perks/cadence 20t replace
