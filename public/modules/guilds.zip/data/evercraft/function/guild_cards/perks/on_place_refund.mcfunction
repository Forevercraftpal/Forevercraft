# ============================================================
# The Handcrafter — Resourceful Hands refund perk (rank S / 8+)
# ============================================================
# Run as @s = the player who just placed a block. A ~10% chance to refund the placed
# block (give one back), so a high-rank Handcrafter occasionally gets a free block —
# a gentle QoL building economy, never a power axis.
#
# PIGGYBACK (R7 / W3 contract): this rides the EXISTING W1 hot-path tally line — it is
# called from build_quests/on_place_tally (gated there on ec.bc_rank matches 8..), so it
# adds NO SECOND edit to advantage/track/on_place_block. Cheap-gate-first: a sub-rank-8
# player never reaches this file.
#
# KNOWN LIMITATION (followup, not a bug): because it rides on_place_tally, the refund
# only fires while the player is on an active, UNTYPED-incremental Build quest (the only
# condition under which the hot path calls on_place_tally). A rank-8+ builder NOT on a
# Build quest gets no refund. Honoring "no second hot-path edit" (R7) is the locked
# tradeoff; a future wave may promote this to its own cheap-gated hot line if desired.
#
# The refund is balance-neutral by design: it returns the SAME generic block kind the
# tally hook cannot identify (the generic placed_block trigger carries no block type),
# so rather than guess the exact block we award one COBBLESTONE as a stand-in "spare
# material" — honest, never an exploit (cobblestone is near-free), reinforcing the
# "resourceful" flavor without letting players farm rare blocks. Tunable.

# ~10% chance gate (predicate-free RNG via a random score 0..9).
execute store result score #hc_roll ec.temp run random value 0..9
execute unless score #hc_roll ec.temp matches 0 run return 0

# Refund: one spare cobblestone + a soft chime. (Stand-in "spare material" — see header.)
give @s minecraft:cobblestone 1
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.3 1.6
