# === GUILD CARDS — Adventurer Eligibility Detector ===
# Hooked from dream_rank/rank_up (fires once per dream rank gained).
# Run as the player.
# Adventurer card maps 1:1 to dream rank: eligible when ec.dream_rank > ec.ag_rank
# and the card is not already maxed (ec.ag_rank <= 9).
# This is the SOLE writer of ec.ag_eligible / ec.ag_notified outside the claim fn.

# Already maxed — nothing to do
execute if score @s ec.ag_rank matches 10.. run return 0

# Eligible if the underlying dream rank now exceeds the claimed card rank
execute if score @s ec.dream_rank > @s ec.ag_rank run scoreboard players set @s ec.ag_eligible 1

# On the eligibility edge (eligible AND not yet nudged), fire ONE Seven-voice nudge.
execute if score @s ec.ag_eligible matches 1 if score @s ec.ag_notified matches 0 run function evercraft:guild_cards/notify_adventurer
