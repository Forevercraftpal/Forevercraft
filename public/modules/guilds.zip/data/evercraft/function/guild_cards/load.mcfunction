# === GUILD CARDS SYSTEM — Load ===
# Village-gated, claimed-rank mirror of the underlying auto-progressing ranks.
#   Merchant card rank (ec.mg_rank 0-10) mirrors artisan level (ec.cf_rank, every 10 levels).
#   Adventurer card rank (ec.ag_rank 0-10) mirrors dream rank (ec.dream_rank, 1:1).
# Crossing a tier sets an eligible flag (one Seven-voice nudge); the rank only
# advances when the player claims it at a matching-type village's quest board.
# Registered from data/minecraft/tags/function/load.json.

# ═══ CLAIMED CARD RANKS (one writer each: the claim fn) ═══
scoreboard objectives add ec.mg_rank dummy "Merchant Guild Card Rank (0-10)"
scoreboard objectives add ec.ag_rank dummy "Adventurer Guild Card Rank (0-10)"

# ═══ ELIGIBILITY FLAGS (set by the rank-up hooks, cleared by the claim fn) ═══
scoreboard objectives add ec.mg_eligible dummy "Merchant Card Eligible-to-Advance"
scoreboard objectives add ec.ag_eligible dummy "Adventurer Card Eligible-to-Advance"

# ═══ NOTIFY EDGE SENTINELS (latch so the 0->1 nudge fires exactly once per tier) ═══
# Set to 1 the same tick we fire the eligibility notify; cleared once the player
# actually claims the rank (so the next tier crossing nudges again).
scoreboard objectives add ec.mg_notified dummy "Merchant Eligibility Nudge Sent"
scoreboard objectives add ec.ag_notified dummy "Adventurer Eligibility Nudge Sent"

# ═══ REWARD-EARNED FLAGS (one writer: guild_cards/rewards/_cosmetic_*) ═══
# ec.{mg,ag}_title  = highest rank-title earned (4-10); kept as the rank source-of-truth.
#                     v1.1: the title is ALSO granted into the special-title family
#                     (ec.special_titles bitfield bits 7-12 / IDs 8-13) so it is equippable
#                     via the Cosmetics GUI page 6. See guild_cards/rewards/_cosmetic_*.
# ec.{mg,ag}_cosmetic = cosmetic unlock state (0 none / 1 unlocked / 2 prestige@10);
#                     kept as source-of-truth. v1.1: ALSO OR-sets a tier bit into
#                     adv.cosm_unlock so the matching aura/trail/crown cosmetic is equippable.
scoreboard objectives add ec.mg_title dummy "Merchant Guild Rank Title Earned"
scoreboard objectives add ec.ag_title dummy "Adventurer Guild Rank Title Earned"
scoreboard objectives add ec.mg_cosmetic dummy "Merchant Guild Cosmetic Unlock"
scoreboard objectives add ec.ag_cosmetic dummy "Adventurer Guild Cosmetic Unlock"

# ═══ BOARD-PROXIMITY PROMPT COOLDOWN (v1.1) ═══
# Throttles the per-player "Guild Steward" rank-up chat prompt at a quest board so it
# fires once per approach, not every tick. ARM (set ~200t) lives in board_prompt_merchant /
# board_prompt_adventurer; the DECREMENT lives in the root tick.mcfunction cooldown cluster
# (mirrors ec.ecodex_cd). Cleared to 0 when the player leaves board range (guild_cards/
# board_prompt) so re-approaching re-prompts immediately.
scoreboard objectives add ec.gc_prompt_cd dummy "Guild Board Prompt Cooldown"

# ═══ PERMANENT MERCHANT PERK SOURCE (CR) ═══
# Summed into ec.craft_rate by craftforever/craft_rate/calculate. One writer:
# guild_cards/rewards/_perk_merchant (rank>=7 perks).
scoreboard objectives add ec.cr_guild dummy "CR from Guild Card Perk"

# ═══ BUILDER (HANDCRAFTER) CARD — ec.bc_* family (Grand Convergence W2, 2026-05-31) ═══
# A THIRD guild card: the Handcrafter, claimed at crafting-village boards (vtype 1, R6),
# 13 letter-tiers (internal ec.bc_rank 0..12: ? G F E D C B A S SS SSS X V). Unlike the
# Merchant/Adventurer cards (which mirror an existing auto-rank), the Builder card rides a
# DEDICATED clean, daily-capped block meter ec.bc_credit (NOT adv.stat_place) — see
# guild_cards/credit/accrue. One writer per objective (the writer named in each comment).
scoreboard objectives add ec.bc_rank dummy "Handcrafter Card Rank (0-12)"
#   ec.bc_credit — clean, daily-capped lifetime block meter (WRITER: credit/accrue_player
#     + the one-time D4 backfill seed in backfill/choose_*). The card's prestige source.
scoreboard objectives add ec.bc_credit dummy "Handcrafter Clean Block Credit"
#   ec.bc_eligible / ec.bc_notified — eligibility flag + nudge latch (WRITER: check_builder
#     + cleared by claim_builder), mirroring ec.mg_eligible / ec.mg_notified.
scoreboard objectives add ec.bc_eligible dummy "Handcrafter Card Eligible-to-Advance"
scoreboard objectives add ec.bc_notified dummy "Handcrafter Eligibility Nudge Sent"
#   ec.bc_title / ec.bc_cosmetic — highest earned rank-title / cosmetic state (WRITER:
#     rewards/_cosmetic_builder), mirroring ec.mg_title / ec.mg_cosmetic.
scoreboard objectives add ec.bc_title dummy "Handcrafter Rank Title Earned"
scoreboard objectives add ec.bc_cosmetic dummy "Handcrafter Cosmetic Unlock"
#   ec.bc_reach — per-rank reach-perk latch (WRITER: rewards/_perk_builder; the EFFECT
#     re-applies in W3 via advantage/effects/reapply_all).
scoreboard objectives add ec.bc_reach dummy "Handcrafter Reach Perk Latch"
#   Daily-meter bookkeeping (WRITER: credit/accrue_player; one writer each):
#     ec.bc_snap  last adv.stat_place sample (forward-delta source)
#     ec.bc_today blocks credited toward the card TODAY (reset at the day boundary, R10)
#     ec.bc_day   the world-day number we last credited on (per-player dawn detect)
scoreboard objectives add ec.bc_snap dummy "Handcrafter Place-Stat Snapshot"
scoreboard objectives add ec.bc_today dummy "Handcrafter Credit Banked Today"
scoreboard objectives add ec.bc_day dummy "Handcrafter Last Credit Day"
#   ec.bc_seeded — D4 one-time backfill-chosen latch (WRITER: backfill/finalize). Until
#     set, the Full/Some/None prompt is pending: seed nothing, never flag eligible.
scoreboard objectives add ec.bc_seeded dummy "Handcrafter Backfill Chosen Latch"

# ═══ BUILDER DAILY METER SCHEDULER (self-rescheduling, existence-gated) ═══
# credit/accrue only does work for @a[scores={ec.bc_seeded=1}] — no per-tick @a scan
# when nobody is on the card. It snapshots the adv.stat_place forward delta, clamps it to
# a REAL daily cap (resets via time query day — does NOT inherit the cdaff bug, R10), and
# re-runs check_builder. Kick once here; it re-schedules itself.
schedule function evercraft:guild_cards/credit/accrue 20t replace

# ═══ BUILDER PERK CADENCE SCHEDULER (W3, self-rescheduling, existence-gated) ═══
# perks/cadence grants the rank-9/10 "while building" effects (Sure Footing slow-fall /
# Tireless Mason Haste) every second, ONLY for @a[scores={ec.bc_rank=8..}] — no per-tick
# @a scan when no rank-8+ Handcrafter is online. Kick once here; it re-schedules itself.
schedule function evercraft:guild_cards/perks/cadence 20t replace

# ═══ CONSTANTS used by the tier / reward math ═══
# (#10 / #25 ec.const may already exist from other loads; re-set is idempotent.)
scoreboard players set #10 ec.const 10
scoreboard players set #25 ec.const 25
