# === GUILD CARDS — Village Type Classifier ===
# Reads the player's CURRENT village specialization and classifies it as a
# guild-card type. Run as the player.
# Sets #gc_vtype ec.temp = 0 (none / not in a typed village)
#                          1 (Merchant: specs 1 Mining / 2 Fishing / 3 Farming / 6 Scholarly)
#                          2 (Adventurer: specs 4 Combat / 5 Exploration)
#
# Specialization source: village/specialization/get_spec sets #vs_current_spec vs.temp (0-6).

scoreboard players set #gc_vtype ec.temp 0

# Resolve this player's current village specialization (1-6, or 0 if none)
function evercraft:village/specialization/get_spec

# Merchant villages — crafting / gathering / scholarly specs
execute if score #vs_current_spec vs.temp matches 1 run scoreboard players set #gc_vtype ec.temp 1
execute if score #vs_current_spec vs.temp matches 2 run scoreboard players set #gc_vtype ec.temp 1
execute if score #vs_current_spec vs.temp matches 3 run scoreboard players set #gc_vtype ec.temp 1
execute if score #vs_current_spec vs.temp matches 6 run scoreboard players set #gc_vtype ec.temp 1

# Adventurer villages — combat / exploration specs
execute if score #vs_current_spec vs.temp matches 4 run scoreboard players set #gc_vtype ec.temp 2
execute if score #vs_current_spec vs.temp matches 5 run scoreboard players set #gc_vtype ec.temp 2
