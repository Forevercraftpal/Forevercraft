# Run as operator (testing entry until W3's handcrafter/on_first_place ships).
# Usage: execute as <player> run function evercraft:guild_cards/admin/grant_builder_baseline
#
# Establishes the Handcrafter (Builder) card baseline for @s and fires the one-time D4
# Full/Some/None backfill offer. This mirrors what W3's on_first_place will do AFTER
# granting the player's first book (card-baseline -> backfill offer -> build_quests/start,
# ordering per cross-seat contract C1). Provided so W2 is independently testable now.
#
# Dup-guarded on ec.bc_rank: if the card already exists (rank >= 0 AND seeded) it just
# re-fires the (sticky) offer, which is itself a no-op once answered.

# Establish the claimed-rank baseline (one-time; do not clobber an existing rank).
execute unless score @s ec.bc_rank matches 0.. run scoreboard players set @s ec.bc_rank 0

# Fire the sticky D4 backfill offer (no-op if already answered).
function evercraft:guild_cards/backfill/offer
