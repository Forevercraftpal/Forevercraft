# === GUILD CARDS — Merchant Eligibility Nudge (Seven-voice butler) ===
# Fired once on the eligibility 0->1 edge by check_merchant. Run as the player.
# Latches ec.mg_notified so it does not repeat until the rank is actually claimed.

scoreboard players set @s ec.mg_notified 1

execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.6 1.4
data modify storage evercraft:notify stage.c set value [{text:"A word, if I may.",color:"#DDF0EE",italic:true}]
scoreboard players set #ndur ec.temp 50
function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Your craft has outgrown your Merchant Guild card. ",color:"gray"},{text:"You are eligible to advance.",color:"#DAA520"}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Present yourself at a ",color:"gray"},{text:"crafting village",color:"aqua"},{text:"'s quest board — ",color:"gray"},{text:"Mining, Fishing, Farming, or Scholarly",color:"aqua"},{text:".",color:"gray"}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit
