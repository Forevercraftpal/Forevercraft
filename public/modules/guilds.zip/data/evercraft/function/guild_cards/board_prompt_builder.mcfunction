# === GUILD CARDS — Builder Board Prompt (v1.1) ===
# Run as the player. Fired by guild_cards/board_prompt when the player is eligible to
# advance their Handcrafter (Builder) guild rank AND standing at a crafting-type
# village's board (vtype 1, R6 — a builder is a crafting identity).
# Per-player clickable nudge -> /trigger ec.quest set 42 -> claim_builder (re-verifies).
#
# trigger 42 is the plumbing behind this [⬆ Claim] chat button — interaction-driven,
# NOT a player-surfaced /trigger name (immersion law). claim_builder re-verifies
# eligibility + village type + not-maxed server-side (R5).

# Arm the throttle (~10s, tunable) so this fires once per approach, not every tick.
# Shares ec.gc_prompt_cd with the Merchant prompt (staggered double-nudge accepted —
# WAVE-PLAN locked-default; a player eligible for BOTH at a crafting board sees both).
scoreboard players set @s ec.gc_prompt_cd 200

execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.4 1.6
tellraw @s ["",{text:"[Guild Steward] ",color:"#C49A6C",bold:true},{text:"⬆ Rank Up available! ",color:"#C49A6C",bold:true},{text:"Advance your Handcrafter Guild rank here. ",color:"gray"},{text:"[⬆ Claim]",color:"#C49A6C",bold:true,click_event:{action:"run_command",command:"/trigger ec.quest set 42"},hover_event:{action:"show_text",value:{text:"Advance your Handcrafter guild card rank",color:"gray"}}}]
