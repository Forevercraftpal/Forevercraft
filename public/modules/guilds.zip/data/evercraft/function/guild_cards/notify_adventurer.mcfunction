# === GUILD CARDS — Adventurer Eligibility Nudge (Seven-voice butler) ===
# Fired once on the eligibility 0->1 edge by check_adventurer. Run as the player.
# Latches ec.ag_notified so it does not repeat until the rank is actually claimed.

scoreboard players set @s ec.ag_notified 1

execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.6 1.4
data modify storage evercraft:notify stage.c set value [{text:"A word, if I may.",color:"#DDF0EE",italic:true}]
scoreboard players set #ndur ec.temp 50
function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Your deeds have outgrown your Adventurer Guild card. ",color:"gray"},{text:"You are eligible to advance.",color:"light_purple"}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Present yourself at a ",color:"gray"},{text:"frontier village",color:"red"},{text:"'s quest board — ",color:"gray"},{text:"Combat or Exploration",color:"red"},{text:".",color:"gray"}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit
