# Guild — Check if a guild golem snowball hit a mob
# Run as: snowball with gs.snowball tag, at snowball position

execute if entity @e[type=#evercraft:aoe_targets,type=!snow_golem,distance=..1.5,limit=1] run function evercraft:guild/golem/apply_hit
