$damage @e[type=#evercraft:aoe_targets,type=!snow_golem,distance=..1.5,limit=1,sort=nearest] $(gs_dmg) minecraft:mob_attack
