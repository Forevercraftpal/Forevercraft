# Guild — Announce guild creation to all players
# $(name) = guild name
# Called `with storage evercraft:guild temp` from guild/create, run as @s = the founder.
# (Wave 2, 2026-06-10: guild echo — whoami-baked, 15s TTL.)
function evercraft:util/notify/whoami
$data modify storage evercraft:notify stage.c set value [{text:"",color:"green"},{text:" has founded the guild ",color:"gold"},{text:"$(name)",color:"green",bold:true},{text:"!",color:"gold"}]
data modify storage evercraft:notify stage.c[0].text set from storage evercraft:notify named.who
scoreboard players set #ndur ec.temp 45
execute as @a run scoreboard players set #nttl ec.temp 300
execute as @a run function evercraft:util/notify/emit

# Build & Conquer (Chronicles Wave C6, S9): ONE additive gated line — on a guild
# creation, fire the one-time soft "[Begin Build & Conquer →]" offer for an Adventurer/
# Both player who has COMPLETED Adventure-A (ec.ac_active matches 2, the sequenced
# prereq), hasn't started the kingdom line, and hasn't been offered yet. offer_prompt
# re-guards the chron_view lens (1 Adventurer / 3 Both, never 2 Crafter) + the ac_active
# sequencing, latches ec.ak_offer (its sole writer), and routes the alert-class chime
# through notify key "ak_offer". The Adventurer Tier-2 row is the always-available
# fallback. (Plain non-$ line — reads only @s scores, not the macro args.)
execute if score @s ec.ak_offer matches 0 if score @s ec.ak_active matches 0 if score @s ec.ac_active matches 2 run function evercraft:adventure/kingdom/offer_prompt
