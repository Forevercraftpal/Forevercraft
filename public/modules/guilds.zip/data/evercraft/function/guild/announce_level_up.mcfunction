# Guild — Announce level up to all guild members
# $(guild_name) = guild name, $(new_level) = new level
$data modify storage evercraft:notify stage.c set value [{text:"$(guild_name)",color:"green",bold:true},{text:" has reached ",color:"gold"},{text:"Level $(new_level)",color:"yellow",bold:true},{text:"!",color:"gold"}]
scoreboard players set #ndur ec.temp 50
execute as @a[scores={ec.guild_id=1..}] run function evercraft:util/notify/emit
