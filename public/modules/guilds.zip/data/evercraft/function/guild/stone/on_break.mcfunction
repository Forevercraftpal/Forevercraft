# Guild Stone — Break detection
# @s = ec.guildstone marker entity, at its position
# Lodestone block is no longer present — clean up

# Remove from guidestone registry (only if registered)
execute if entity @s[tag=ec.gs_registered] run execute store result storage evercraft:guidestone remove_id int 1 run scoreboard players get @s ec.gs_id
execute if entity @s[tag=ec.gs_registered] run function evercraft:guidestone/remove_from_registry

# Close any open guild menus nearby
execute as @a[tag=ec.guild_in_menu,distance=..8] run function evercraft:guild/gui/menu/close

# Kill nearby interaction entity, armor_stand, and item_display overlay
# (Passengers dismount when parent is killed, so kill item_display explicitly)
kill @e[type=interaction,tag=ec.guildstone_interact,distance=..2]
kill @e[type=item_display,tag=ec.guildstone_display,distance=..2]
kill @e[type=armor_stand,tag=ec.guildstone_stand,distance=..2]

# ═══ COLOR-AWARE LOOT DROP ═══
# Kill vanilla lodestone drop
kill @e[type=item,nbt={Item:{id:"minecraft:lodestone"}},distance=..2]

# Drop correct color variant
execute if data entity @s {data:{color:"guildstone_azure"}} run loot spawn ~ ~ ~ loot evercraft:guild/guild_stone_drop_azure
execute if data entity @s {data:{color:"guildstone_crimson"}} run loot spawn ~ ~ ~ loot evercraft:guild/guild_stone_drop_crimson
execute if data entity @s {data:{color:"guildstone_solar"}} run loot spawn ~ ~ ~ loot evercraft:guild/guild_stone_drop_solar
execute if data entity @s {data:{color:"guildstone_verdant"}} run loot spawn ~ ~ ~ loot evercraft:guild/guild_stone_drop_verdant
execute if data entity @s {data:{color:"guildstone_ivory"}} run loot spawn ~ ~ ~ loot evercraft:guild/guild_stone_drop_ivory
execute if data entity @s {data:{color:"guildstone_obsidian"}} run loot spawn ~ ~ ~ loot evercraft:guild/guild_stone_drop_obsidian
execute if data entity @s {data:{color:"guildstone_rose"}} run loot spawn ~ ~ ~ loot evercraft:guild/guild_stone_drop_rose
execute if data entity @s {data:{color:"guildstone_noir"}} run loot spawn ~ ~ ~ loot evercraft:guild/guild_stone_drop_noir
execute unless data entity @s {data:{color:"guildstone_azure"}} unless data entity @s {data:{color:"guildstone_crimson"}} unless data entity @s {data:{color:"guildstone_solar"}} unless data entity @s {data:{color:"guildstone_verdant"}} unless data entity @s {data:{color:"guildstone_ivory"}} unless data entity @s {data:{color:"guildstone_obsidian"}} unless data entity @s {data:{color:"guildstone_rose"}} unless data entity @s {data:{color:"guildstone_noir"}} run loot spawn ~ ~ ~ loot evercraft:guild/guild_stone_drop

# Notify nearby players
data modify storage evercraft:notify stage.c set value [{text:"A Guild Stone was destroyed!",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute as @a[distance=..16] run function evercraft:util/notify/emit
playsound minecraft:block.beacon.deactivate player @a[distance=..16,scores={ec.fx_snd=1..}] ~ ~ ~ 1 0.5

# Kill self (the marker)
kill @s
