# Guild Stone — Wash Block (right-click with water bucket)
# Removes dye and restores default appearance
# Run as: player, at: interaction entity position

# Reset marker color to default
execute as @e[type=marker,tag=ec.guildstone_marker,distance=..2,limit=1] run data modify entity @s data.color set value "guildstone"

# Reset display skin to default
execute as @e[type=armor_stand,tag=ec.guildstone_stand,distance=..2,limit=1] on passengers run data modify entity @s item.components."minecraft:profile".properties[0].value set value "ewogICJ0aW1lc3RhbXAiIDogMTc3MzUzODcxMDY2NSwKICAicHJvZmlsZUlkIiA6ICJiYzRlZGZiNWYzNmM0OGE3YWM5ZjFhMzlkYzIzZjRmOCIsCiAgInByb2ZpbGVOYW1lIiA6ICI4YWNhNjgwYjIyNDYxMzQwIiwKICAic2lnbmF0dXJlUmVxdWlyZWQiIDogdHJ1ZSwKICAidGV4dHVyZXMiIDogewogICAgIlNLSU4iIDogewogICAgICAidXJsIiA6ICJodHRwOi8vdGV4dHVyZXMubWluZWNyYWZ0Lm5ldC90ZXh0dXJlLzc4NGRmZjMyNTljZGQyMTNmOGU2ZDAzZTQ3YmU1MWE0ZjM0MGVjMzIyZGU4MDUxOGMxZmI3NTViMzYxYzMyZjQiLAogICAgICAibWV0YWRhdGEiIDogewogICAgICAgICJtb2RlbCIgOiAic2xpbSIKICAgICAgfQogICAgfQogIH0KfQ=="

# Effects
playsound minecraft:item.bucket.empty master @a[distance=..16,scores={ec.fx_snd=1..}] ~ ~ ~ 1 1.2
particle minecraft:splash ~0.5 ~1.0 ~0.5 0.3 0.2 0.3 0.05 12

# Feedback
data modify storage evercraft:notify stage.c set value [{text:"Washed ",color:"gray",italic:true},{text:"Guild Stone",color:"#E0B0FF",italic:true},{text:" back to default",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
