# Guild Menu — Announce supply drop (macro)
# $(supply_tier_name) $(supply_target_name)
# @s = the player who sent the supply

# (Wave 2, 2026-06-10: guild echo — whoami-baked, 15s TTL.)
function evercraft:util/notify/whoami
$data modify storage evercraft:notify stage.c set value [{text:"",color:"gray"},{text:" sent ",color:"gray"},{text:"$(supply_tier_name)",color:"gold",bold:true},{text:" to ",color:"gray"},{text:"$(supply_target_name)",color:"gold"},{text:"!",color:"gray"}]
data modify storage evercraft:notify stage.c[0].text set from storage evercraft:notify named.who
scoreboard players set #ndur ec.temp 45
execute as @a[scores={ec.guild_id=1..}] run scoreboard players set #nttl ec.temp 300
execute as @a[scores={ec.guild_id=1..}] run function evercraft:util/notify/emit
