# Guild Menu — Spawn event info rows (macro)
# $(guild_a_name) $(guild_b_name) $(type)
# Anchored to bg entity — positioned below weekly leaderboard
# Per-player session isolation (Wiring #3 W3a): predicate evercraft:guild/check_menu_session filters to @s's bg.
scoreboard players operation #gui_check ec.temp = @s adv.gui_session

# Row 1: Guild names
$execute at @e[type=item_display,tag=ec.guild_menu_bg,distance=..5,predicate=evercraft:guild/check_menu_session,limit=1] positioned ~ ~0.24 ~-0.02 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f, Tags:["ec.guild_menu_el","ec.guild_page_el"], billboard:"center", text:{text:"$(guild_a_name) vs $(guild_b_name)",color:"gold"}, background:1, shadow:1b, transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.177f,0.177f,0.177f]} }

# Row 2: Activity name + [?] button
execute at @e[type=item_display,tag=ec.guild_menu_bg,distance=..5,predicate=evercraft:guild/check_menu_session,limit=1] positioned ~ ~0.15 ~-0.02 run function evercraft:guild/gui/menu/spawn_event_activity with storage evercraft:guild temp

# Row 3: Guild A score (tagged for live updates)

# Row 4: Guild B score (tagged for live updates)
# === 26.1 fix: {score} blank in text_display -> bake via storage macro ===
scoreboard players add #gd_score_a ec.var 0
execute store result storage evercraft:scorebake args.v1 int 1 run scoreboard players get #gd_score_a ec.var
scoreboard players add #gd_score_b ec.var 0
execute store result storage evercraft:scorebake args.v2 int 1 run scoreboard players get #gd_score_b ec.var
function evercraft:guild/gui/menu/spawn_event_rows_dyn with storage evercraft:scorebake args

# Row 5: Status line (winning/losing/tie) — tagged for live updates
execute at @e[type=item_display,tag=ec.guild_menu_bg,distance=..5,predicate=evercraft:guild/check_menu_session,limit=1] positioned ~ ~-0.09 ~-0.02 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f, Tags:["ec.guild_menu_el","ec.guild_page_el","ec.guild_ev_status"], billboard:"center", text:{text:"...",color:"gray"}, background:1, shadow:1b, transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.203f,0.203f,0.203f]} }

# Update status line immediately
function evercraft:guild/gui/menu/update_event_scores
