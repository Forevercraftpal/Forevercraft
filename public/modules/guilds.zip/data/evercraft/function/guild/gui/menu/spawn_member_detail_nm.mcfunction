# Guild member-detail name header (macro). 26.1: {selector:} is blank in text_display, so the viewed
# member's profile name is staged to evercraft:scorebake args.owner (by util/gui/owner_name run as the
# target_cid match) and baked here as the frozen $(owner) literal. Empty = member offline. Position
# inherited from the call site (at the session bg anchor).
$summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f, Tags:["ec.guild_menu_el","ec.guild_page_el"], billboard:"center", text:{text:"$(owner)",color:"white",bold:true}, background:0, shadow:1b, transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.358f,0.358f,0.358f]} }
