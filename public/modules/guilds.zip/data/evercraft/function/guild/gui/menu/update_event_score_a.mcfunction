# Guild Menu — Update guild A score display (macro)
# @s = text_display entity, $(guild_a_name), $(score_a) — score baked (26.1 {score:} blank in text_display)
$data modify entity @s text set value [{text:"$(guild_a_name)",color:"gold"},{text:": ",color:"gray"},{text:"$(score_a)",color:"yellow"}]
