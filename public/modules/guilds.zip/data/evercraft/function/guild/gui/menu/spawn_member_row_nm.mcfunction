# Guild member row (macro). 26.1: {selector:} is blank in text_display, so the member's profile name
# is staged to evercraft:scorebake args.owner (by util/gui/owner_name run as the member_score match)
# and baked here as $(owner); rank_name + member_contrib are re-staged into the same args by the
# caller. Empty owner = member offline (parity with the original selector). Position inherited.
$summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f, Tags:["ec.guild_menu_el","ec.guild_page_el"], billboard:"center", text:[{text:"$(owner)"},{text:" │ ",color:"dark_gray"},{text:"$(rank_name)",color:"gold"},{text:" │ ",color:"dark_gray"},{text:"$(member_contrib)",color:"green"}], background:1, shadow:1b, transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.262f,0.262f,0.262f]} }
