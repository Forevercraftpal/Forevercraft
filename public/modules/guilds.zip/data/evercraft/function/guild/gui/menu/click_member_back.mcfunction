# Guild Menu — Back from member detail to roster
# @s = the interaction entity that was clicked

data remove entity @s interaction

# Return to roster view
execute as @a[predicate=evercraft:guild/check_menu_session,limit=1] run tag @s remove ec.gm_detail_view
execute as @a[predicate=evercraft:guild/check_menu_session,limit=1] run function evercraft:guild/gui/menu/refresh_members
