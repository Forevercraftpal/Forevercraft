# Guild Menu — Nav click: Warp
# @s = interaction entity that was clicked
data remove entity @s interaction
execute as @a[predicate=evercraft:guild/check_menu_session,limit=1] run function evercraft:guild/gui/menu/switch_warp
