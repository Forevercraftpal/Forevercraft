# Guild Menu — Open GUI panel
# Run as the player who right-clicked the guild stone
# Guildstone has 7 tabs: Events, Donate, Warp, Guild, Members, Allies, Manage

# Already in menu? Close first
execute if entity @s[tag=ec.guild_in_menu] run function evercraft:guild/gui/menu/close

# Must be in a guild
data modify storage evercraft:notify stage.c set value [{text:"You are not in a guild!",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute unless score @s ec.guild_id matches 1.. run function evercraft:util/notify/emit
execute unless score @s ec.guild_id matches 1.. run return 0

# Menu Core: Y-displacement close anchor
# One-menu-at-a-time (2026-06-15): close any other open menu before this one claims
# ec.menu_active. Two overlapping menus share the @s adv.gui_session slot; the newer
# open orphans the older menu's session, so it can never consume its click -> stuck
# interaction NBT -> click-sound spam. force_close is idempotent (no-op when nothing open).
execute if entity @s[tag=ec.menu_active] run function evercraft:menu_core/force_close
tag @s add ec.menu_active
execute store result score @s ec.menu_open_y run data get entity @s Pos[1] 100

# Safety: kill any orphaned elements
execute at @s run kill @e[type=text_display,tag=ec.guild_menu_el,distance=..5]
execute at @s run kill @e[type=interaction,tag=ec.guild_menu_el,distance=..5]
execute at @s run kill @e[type=item_display,tag=ec.guild_menu_el,distance=..5]

# Disable the guild stone interaction entity so it can't be re-triggered
execute at @s run data modify entity @e[type=interaction,tag=ec.guildstone_interact,distance=..5,limit=1] height set value 0.0f

# Tag player as in menu
tag @s add ec.guild_in_menu
scoreboard players set @s ec.guild_page 1
scoreboard players set @s ec.guild_menu_time 0

# === SPAWN SHELL ===

# Background panel
execute rotated ~ 0 positioned ^ ^1.95 ^1.8 run summon item_display ~ ~ ~ { Tags:["ec.guild_menu_el","ec.guild_menu_bg"], billboard:"center", item:{id:"black_stained_glass_pane",count:1}, item_display:"fixed", transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,-0.02f],scale:[4.0f,2.8f,0.01f]} }
# Yaw stamp (2026-06-10 GUI pass — ROOT FIX): summoned displays default to Rotation [0,0], so
# every later `at @e[..ec.guild_menu_bg..] positioned ^x` offset (nav arrows, member rows, warp
# buttons — 16 files) resolved in a COMPASS frame, not the viewer's screen frame: sub-elements
# landed on the wrong side unless the menu happened to face south. Stamping the opener's yaw
# (pitch stays 0) makes every local offset screen-correct.
data modify entity @e[type=item_display,tag=ec.guild_menu_bg,distance=..3,limit=1,sort=nearest] Rotation[0] set from entity @s Rotation[0]

# Title (will be updated with guild name by refresh_info)
# Ownership-header label (MP-P3.6): foreign viewers see whose menu this is
# 26.1: {selector:} renders blank in text_display — bake @s's name to a $(owner) literal.
function evercraft:util/gui/owner_name
execute rotated ~ 0 positioned ^ ^2.93 ^1.78 run function evercraft:guild/gui/menu/open_nm with storage evercraft:scorebake args
execute rotated ~ 0 positioned ^ ^2.75 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f, Tags:["ec.guild_menu_el","ec.guild_menu_title"], billboard:"center", text:{text:"Guild",color:"green",bold:true}, background:1, shadow:1b, transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.537f,0.537f,0.537f]} }

# === NAV BUTTONS (7 tabs: Events, Donate, Warp, Guild, Members, Allies, Manage) ===
# Spacing: 0.36 step to match wider panel

# [Events] (page 6)
execute rotated ~ 0 positioned ^1.08 ^1.35 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f, Tags:["ec.guild_menu_el","ec.guild_nav_event_txt"], billboard:"center", text:{text:"Events",color:"gray"}, background:1, shadow:1b, transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.262f,0.262f,0.262f]} }
execute rotated ~ 0 positioned ^1.08 ^1.25 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.guild_menu_el","ec.guild_nav_event"], width:0.28f, height:0.12f, response:1b }

# [Donate] (page 3)
execute rotated ~ 0 positioned ^0.72 ^1.35 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f, Tags:["ec.guild_menu_el","ec.guild_nav_donate_txt"], billboard:"center", text:{text:"Donate",color:"gray"}, background:1, shadow:1b, transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.262f,0.262f,0.262f]} }
execute rotated ~ 0 positioned ^0.72 ^1.25 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.guild_menu_el","ec.guild_nav_donate"], width:0.28f, height:0.12f, response:1b }

# [Warp] (page 5)
execute rotated ~ 0 positioned ^0.36 ^1.35 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f, Tags:["ec.guild_menu_el","ec.guild_nav_warp_txt"], billboard:"center", text:{text:"Warp",color:"gray"}, background:1, shadow:1b, transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.262f,0.262f,0.262f]} }
execute rotated ~ 0 positioned ^0.36 ^1.25 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.guild_menu_el","ec.guild_nav_warp"], width:0.28f, height:0.12f, response:1b }

# [Guild] — center, highlighted by default (page 1)
execute rotated ~ 0 positioned ^ ^1.35 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f, Tags:["ec.guild_menu_el","ec.guild_nav_info_txt"], billboard:"center", text:{text:"Guild",color:"white",bold:true}, background:1, shadow:1b, transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.262f,0.262f,0.262f]} }
execute rotated ~ 0 positioned ^ ^1.25 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.guild_menu_el","ec.guild_nav_info"], width:0.28f, height:0.12f, response:1b }

# [Members] (page 2)
execute rotated ~ 0 positioned ^-0.36 ^1.35 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f, Tags:["ec.guild_menu_el","ec.guild_nav_members_txt"], billboard:"center", text:{text:"Members",color:"gray"}, background:1, shadow:1b, transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.262f,0.262f,0.262f]} }
execute rotated ~ 0 positioned ^-0.36 ^1.25 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.guild_menu_el","ec.guild_nav_members"], width:0.28f, height:0.12f, response:1b }

# [Allies] (page 7)
execute rotated ~ 0 positioned ^-0.72 ^1.35 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f, Tags:["ec.guild_menu_el","ec.guild_nav_allies_txt"], billboard:"center", text:{text:"Allies",color:"gray"}, background:1, shadow:1b, transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.262f,0.262f,0.262f]} }
execute rotated ~ 0 positioned ^-0.72 ^1.25 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.guild_menu_el","ec.guild_nav_allies"], width:0.28f, height:0.12f, response:1b }

# [Manage] (page 4)
execute rotated ~ 0 positioned ^-1.08 ^1.35 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f, Tags:["ec.guild_menu_el","ec.guild_nav_manage_txt"], billboard:"center", text:{text:"Manage",color:"gray"}, background:1, shadow:1b, transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.262f,0.262f,0.262f]} }
execute rotated ~ 0 positioned ^-1.08 ^1.25 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.guild_menu_el","ec.guild_nav_manage"], width:0.28f, height:0.12f, response:1b }

# === CLOSE BUTTON ===
execute rotated ~ 0 positioned ^ ^1.13 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f, Tags:["ec.guild_menu_el","ec.guild_close_txt"], billboard:"center", text:[{text:"[ ",color:"dark_gray"},{text:"Close",color:"gray",bold:true},{text:" ]",color:"dark_gray"}], background:1, shadow:1b, transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.358f,0.358f,0.358f]} }
# [strip] ec.guild_menu_el: 0.4w split into 4 x 0.12 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute rotated ~ 0 positioned ^-0.14 ^1.03 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.guild_menu_el","ec.guild_close_btn"], width:0.12f,height:0.12f, response:1b }
execute rotated ~ 0 positioned ^-0.0467 ^1.03 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.guild_menu_el","ec.guild_close_btn"], width:0.12f,height:0.12f, response:1b }
execute rotated ~ 0 positioned ^0.0467 ^1.03 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.guild_menu_el","ec.guild_close_btn"], width:0.12f,height:0.12f, response:1b }
execute rotated ~ 0 positioned ^0.14 ^1.03 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.guild_menu_el","ec.guild_close_btn"], width:0.12f,height:0.12f, response:1b }

# Load guild info page by default
function evercraft:guild/gui/menu/refresh_info

# Sound

# Session isolation
scoreboard players add #gui_session ec.var 1
scoreboard players operation @s adv.gui_session = #gui_session ec.var
scoreboard players operation #gui_stamp ec.temp = @s adv.gui_session
execute as @e[type=text_display,tag=ec.guild_menu_el,distance=..5] unless score @s adv.gui_session matches 1.. run scoreboard players operation @s adv.gui_session = #gui_stamp ec.temp
execute as @e[type=item_display,tag=ec.guild_menu_el,distance=..5] unless score @s adv.gui_session matches 1.. run scoreboard players operation @s adv.gui_session = #gui_stamp ec.temp
execute as @e[type=interaction,tag=ec.guild_menu_el,distance=..5] unless score @s adv.gui_session matches 1.. run scoreboard players operation @s adv.gui_session = #gui_stamp ec.temp

execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.amethyst_block.step master @s ~ ~ ~ 0.8 1.2
