# Guild Menu — Spawn one member row (macro)
# $(rank_name), $(member_contrib), $(member_score)
# Position = correct row Y (set by caller)
# member_score matches the player's ec.temp score for selector resolution

# 26.1: {selector:} renders blank in text_display — bake the member's name to $(owner) (empty if
# offline) + re-stage the row's other macro args, then render from the sub-fn. Position inherited.
data modify storage evercraft:scorebake args.owner set value ""
$execute as @a[scores={ec.temp=$(member_score)},limit=1] run function evercraft:util/gui/owner_name
$data modify storage evercraft:scorebake args.rank_name set value "$(rank_name)"
$data modify storage evercraft:scorebake args.member_contrib set value "$(member_contrib)"
function evercraft:guild/gui/menu/spawn_member_row_nm with storage evercraft:scorebake args

# Clickable hitbox for this member row
# [strip] 1.4w split into 11 x 0.13 cubes via caret chain (GUI-plane x; anchor carries yaw, pitch 0)
execute positioned ~ ~-0.065 ~0.02 positioned ^-0.635 ^0 ^0 run summon interaction ~ ~ ~ {Tags:["ec.guild_menu_el","ec.guild_page_el","ec.gm_member_click","ec.gm_member_new"], width:0.13f,height:0.13f, response:1b}
execute positioned ~ ~-0.065 ~0.02 positioned ^-0.508 ^0 ^0 run summon interaction ~ ~ ~ {Tags:["ec.guild_menu_el","ec.guild_page_el","ec.gm_member_click","ec.gm_member_new"], width:0.13f,height:0.13f, response:1b}
execute positioned ~ ~-0.065 ~0.02 positioned ^-0.381 ^0 ^0 run summon interaction ~ ~ ~ {Tags:["ec.guild_menu_el","ec.guild_page_el","ec.gm_member_click","ec.gm_member_new"], width:0.13f,height:0.13f, response:1b}
execute positioned ~ ~-0.065 ~0.02 positioned ^-0.254 ^0 ^0 run summon interaction ~ ~ ~ {Tags:["ec.guild_menu_el","ec.guild_page_el","ec.gm_member_click","ec.gm_member_new"], width:0.13f,height:0.13f, response:1b}
execute positioned ~ ~-0.065 ~0.02 positioned ^-0.127 ^0 ^0 run summon interaction ~ ~ ~ {Tags:["ec.guild_menu_el","ec.guild_page_el","ec.gm_member_click","ec.gm_member_new"], width:0.13f,height:0.13f, response:1b}
execute positioned ~ ~-0.065 ~0.02 positioned ^0 ^0 ^0 run summon interaction ~ ~ ~ {Tags:["ec.guild_menu_el","ec.guild_page_el","ec.gm_member_click","ec.gm_member_new"], width:0.13f,height:0.13f, response:1b}
execute positioned ~ ~-0.065 ~0.02 positioned ^0.127 ^0 ^0 run summon interaction ~ ~ ~ {Tags:["ec.guild_menu_el","ec.guild_page_el","ec.gm_member_click","ec.gm_member_new"], width:0.13f,height:0.13f, response:1b}
execute positioned ~ ~-0.065 ~0.02 positioned ^0.254 ^0 ^0 run summon interaction ~ ~ ~ {Tags:["ec.guild_menu_el","ec.guild_page_el","ec.gm_member_click","ec.gm_member_new"], width:0.13f,height:0.13f, response:1b}
execute positioned ~ ~-0.065 ~0.02 positioned ^0.381 ^0 ^0 run summon interaction ~ ~ ~ {Tags:["ec.guild_menu_el","ec.guild_page_el","ec.gm_member_click","ec.gm_member_new"], width:0.13f,height:0.13f, response:1b}
execute positioned ~ ~-0.065 ~0.02 positioned ^0.508 ^0 ^0 run summon interaction ~ ~ ~ {Tags:["ec.guild_menu_el","ec.guild_page_el","ec.gm_member_click","ec.gm_member_new"], width:0.13f,height:0.13f, response:1b}
execute positioned ~ ~-0.065 ~0.02 positioned ^0.635 ^0 ^0 run summon interaction ~ ~ ~ {Tags:["ec.guild_menu_el","ec.guild_page_el","ec.gm_member_click","ec.gm_member_new"], width:0.13f,height:0.13f, response:1b}
