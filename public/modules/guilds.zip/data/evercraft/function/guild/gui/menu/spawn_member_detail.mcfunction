# Guild Menu — Spawn member detail view (macro)
# $(target_cid), $(detail_rank), $(detail_contrib), $(dr_whole), $(dr_dec)
# Per-player session isolation (Wiring #3 W3a): predicate evercraft:guild/check_menu_session filters to @s's bg.
scoreboard players operation #gui_check ec.temp = @s adv.gui_session

# === PLAYER NAME (header) ===
# 26.1: {selector:} renders blank in text_display — bake the target_cid member's name to $(owner).
data modify storage evercraft:scorebake args.owner set value ""
$execute as @a[scores={companion.id=$(target_cid)},limit=1] run function evercraft:util/gui/owner_name
execute at @e[type=item_display,tag=ec.guild_menu_bg,distance=..5,predicate=evercraft:guild/check_menu_session,limit=1] positioned ~ ~0.54 ~-0.02 run function evercraft:guild/gui/menu/spawn_member_detail_nm with storage evercraft:scorebake args

# === RANK ===
$execute at @e[type=item_display,tag=ec.guild_menu_bg,distance=..5,predicate=evercraft:guild/check_menu_session,limit=1] positioned ~ ~0.36 ~-0.02 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f, Tags:["ec.guild_menu_el","ec.guild_page_el"], billboard:"center", text:[{text:"Rank: ",color:"gray"},{text:"$(detail_rank)",color:"gold"}], background:0, shadow:1b, transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.262f,0.262f,0.262f]} }

# === CONTRIBUTION ===
$execute at @e[type=item_display,tag=ec.guild_menu_bg,distance=..5,predicate=evercraft:guild/check_menu_session,limit=1] positioned ~ ~0.23 ~-0.02 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f, Tags:["ec.guild_menu_el","ec.guild_page_el"], billboard:"center", text:[{text:"Contribution: ",color:"gray"},{text:"$(detail_contrib)",color:"green"}], background:0, shadow:1b, transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.262f,0.262f,0.262f]} }

# === DREAM RATE ===
$execute at @e[type=item_display,tag=ec.guild_menu_bg,distance=..5,predicate=evercraft:guild/check_menu_session,limit=1] positioned ~ ~0.10 ~-0.02 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f, Tags:["ec.guild_menu_el","ec.guild_page_el"], billboard:"center", text:[{text:"Dream Rate: ",color:"gray"},{text:"$(dr_whole).$(dr_dec)",color:"aqua"}], background:0, shadow:1b, transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.262f,0.262f,0.262f]} }

# === COMPANION (default: None, updated by caller if pet found) ===
execute at @e[type=item_display,tag=ec.guild_menu_bg,distance=..5,predicate=evercraft:guild/check_menu_session,limit=1] positioned ~ ~-0.03 ~-0.02 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f, Tags:["ec.guild_menu_el","ec.guild_page_el","ec.gm_detail_pet"], billboard:"center", text:[{text:"Companion: ",color:"gray"},{text:"None",color:"dark_gray",italic:true}], background:0, shadow:1b, transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.262f,0.262f,0.262f]} }

# === BACK BUTTON ===
execute at @e[type=item_display,tag=ec.guild_menu_bg,distance=..5,predicate=evercraft:guild/check_menu_session,limit=1] positioned ~ ~-0.25 ~-0.02 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f, Tags:["ec.guild_menu_el","ec.guild_page_el"], billboard:"center", text:[{text:"[ ",color:"dark_gray"},{text:"Back",color:"white"},{text:" ]",color:"dark_gray"}], background:0, shadow:1b, transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.298f,0.298f,0.298f]} }
execute at @e[type=item_display,tag=ec.guild_menu_bg,distance=..5,predicate=evercraft:guild/check_menu_session,limit=1] positioned ~ ~-0.29 ~ run summon interaction ~ ~ ~ {Tags:["ec.guild_menu_el","ec.guild_page_el","ec.gm_detail_back"], width:0.3f, height:0.08f, response:1b}
