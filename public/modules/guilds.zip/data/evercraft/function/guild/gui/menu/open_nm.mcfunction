# Owner-name header row (macro). 26.1: {selector:} is blank in text_display, so the menu
# opener's profile name is staged to evercraft:scorebake args.owner by util/gui/owner_name
# and baked here as the frozen $(owner) literal. Inherits position/rotation from the call site.
$summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["ec.guild_menu_el","ec.menu_owner_label"],billboard:"center",text:[{text:"\u27e8 ",color:"gray",italic:true},{text:"$(owner)",color:"gray",italic:true},{text:"'s Menu \u27e9",color:"gray",italic:true}],background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.27f,0.27f,0.27f]}}
