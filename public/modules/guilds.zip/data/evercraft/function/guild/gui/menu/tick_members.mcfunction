# Guild Menu — Members page tick (click detection)
# @s = player with menu open

# === DETAIL VIEW MODE ===
# If viewing a member's detail, check back button only
execute if entity @s[tag=ec.gm_detail_view] as @e[type=interaction,tag=ec.gm_detail_back,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction on target run function evercraft:guild/gui/menu/click_member_back
execute if entity @s[tag=ec.gm_detail_view] as @e[type=interaction,tag=ec.gm_detail_back,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction run data remove entity @s interaction
execute if entity @s[tag=ec.gm_detail_view] run return 0

# === ROSTER VIEW ===
# Check prev/next page clicks
execute as @e[type=interaction,tag=ec.gm_prev_click,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction on target run function evercraft:guild/gui/menu/click_member_prev
execute as @e[type=interaction,tag=ec.gm_prev_click,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=ec.gm_next_click,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction on target run function evercraft:guild/gui/menu/click_member_next
execute as @e[type=interaction,tag=ec.gm_next_click,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction run data remove entity @s interaction

# Check member row clicks (open detail view)
execute as @e[type=interaction,tag=ec.gm_member_click,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction on target run function evercraft:guild/gui/menu/click_member_row
execute as @e[type=interaction,tag=ec.gm_member_click,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction run data remove entity @s interaction

# ===== INSPECT (left-click = what does this button do?) — gui/inspect pattern 2026-06-11 =====
execute as @e[type=interaction,tag=ec.gm_member_click,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Member",b:"Opens this member — rank, standing, and contributions."}
execute as @e[type=interaction,tag=ec.gm_member_click,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=ec.gm_detail_back,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Back",b:"Returns to the member roster."}
execute as @e[type=interaction,tag=ec.gm_detail_back,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=ec.gm_prev_click,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Previous Page",b:"Flips to the previous page of members."}
execute as @e[type=interaction,tag=ec.gm_prev_click,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=ec.gm_next_click,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Next Page",b:"Flips to the next page of members."}
execute as @e[type=interaction,tag=ec.gm_next_click,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack run data remove entity @s attack
