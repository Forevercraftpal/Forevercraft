# Guild Menu — Update guild B score display (macro)
# @s = text_display entity, $(guild_b_name), $(score_b) — score baked (26.1 {score:} blank in text_display)
$data modify entity @s text set value [{text:"$(guild_b_name)",color:"gold"},{text:": ",color:"gray"},{text:"$(score_b)",color:"yellow"}]
