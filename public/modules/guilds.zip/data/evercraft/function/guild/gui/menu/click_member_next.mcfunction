# Guild Menu — Members page next click
# @s = interaction entity

data remove entity @s interaction
execute as @a[predicate=evercraft:guild/check_menu_session,limit=1] run function evercraft:guild/gui/menu/do_member_next
