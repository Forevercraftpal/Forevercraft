# Guild Menu — Allies page tick
# @s = player on allies page (page 7)

# Check supply button clicks for each slot
scoreboard players set #supply_click ec.temp 0
scoreboard players operation #gui_check ec.temp = @s adv.gui_session
execute at @s store success score #supply_click ec.temp as @e[type=interaction,tag=ec.guild_supply_0,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction run data remove entity @s interaction
execute if score #supply_click ec.temp matches 1 run scoreboard players operation @s ec.gd_supply_tgt = #ally_slot_0 ec.temp
execute if score #supply_click ec.temp matches 1 run function evercraft:guild/gui/menu/click_supply

execute if score #supply_click ec.temp matches 0 at @s store success score #supply_click ec.temp as @e[type=interaction,tag=ec.guild_supply_1,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction run data remove entity @s interaction
execute if score #supply_click ec.temp matches 1 run scoreboard players operation @s ec.gd_supply_tgt = #ally_slot_1 ec.temp
execute if score #supply_click ec.temp matches 1 run function evercraft:guild/gui/menu/click_supply

execute if score #supply_click ec.temp matches 0 at @s store success score #supply_click ec.temp as @e[type=interaction,tag=ec.guild_supply_2,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction run data remove entity @s interaction
execute if score #supply_click ec.temp matches 1 run scoreboard players operation @s ec.gd_supply_tgt = #ally_slot_2 ec.temp
execute if score #supply_click ec.temp matches 1 run function evercraft:guild/gui/menu/click_supply

execute if score #supply_click ec.temp matches 0 at @s store success score #supply_click ec.temp as @e[type=interaction,tag=ec.guild_supply_3,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction run data remove entity @s interaction
execute if score #supply_click ec.temp matches 1 run scoreboard players operation @s ec.gd_supply_tgt = #ally_slot_3 ec.temp
execute if score #supply_click ec.temp matches 1 run function evercraft:guild/gui/menu/click_supply

# Check [X] remove alliance button clicks (rank 5+ only)
scoreboard players set #remove_click ec.temp 0
execute if score @s ec.guild_rank matches 5.. at @s store success score #remove_click ec.temp as @e[type=interaction,tag=ec.guild_remove_ally_0,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction run data remove entity @s interaction
execute if score #remove_click ec.temp matches 1 run scoreboard players operation @s ec.gd_vote_tgt = #ally_slot_0 ec.temp
execute if score #remove_click ec.temp matches 1 run scoreboard players set @s ec.gd_diplo 6

execute if score #remove_click ec.temp matches 0 if score @s ec.guild_rank matches 5.. at @s store success score #remove_click ec.temp as @e[type=interaction,tag=ec.guild_remove_ally_1,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction run data remove entity @s interaction
execute if score #remove_click ec.temp matches 1 run scoreboard players operation @s ec.gd_vote_tgt = #ally_slot_1 ec.temp
execute if score #remove_click ec.temp matches 1 run scoreboard players set @s ec.gd_diplo 6

execute if score #remove_click ec.temp matches 0 if score @s ec.guild_rank matches 5.. at @s store success score #remove_click ec.temp as @e[type=interaction,tag=ec.guild_remove_ally_2,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction run data remove entity @s interaction
execute if score #remove_click ec.temp matches 1 run scoreboard players operation @s ec.gd_vote_tgt = #ally_slot_2 ec.temp
execute if score #remove_click ec.temp matches 1 run scoreboard players set @s ec.gd_diplo 6

execute if score #remove_click ec.temp matches 0 if score @s ec.guild_rank matches 5.. at @s store success score #remove_click ec.temp as @e[type=interaction,tag=ec.guild_remove_ally_3,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction run data remove entity @s interaction
execute if score #remove_click ec.temp matches 1 run scoreboard players operation @s ec.gd_vote_tgt = #ally_slot_3 ec.temp
execute if score #remove_click ec.temp matches 1 run scoreboard players set @s ec.gd_diplo 6

# Rank too low feedback
data modify storage evercraft:notify stage.c set value [{text:"Administrator rank required to remove alliances.",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute unless score @s ec.guild_rank matches 5.. at @s if entity @e[type=interaction,tag=ec.guild_remove_ally_0,distance=..5,nbt={interaction:{}}] run function evercraft:util/notify/emit

# Check supply tier selection buttons (if in supply selection mode)
execute if entity @s[tag=ec.guild_supply_select] run function evercraft:guild/gui/menu/tick_supply_select

# ===== INSPECT (left-click = what does this button do?) — gui/inspect pattern 2026-06-11 =====
execute as @e[type=interaction,tag=ec.guild_supply_0,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Supply Ally (Row 1)",b:"Right-click to send supplies to the allied guild in row 1 — strengthens the pact. The ally name is on the row label."}
execute as @e[type=interaction,tag=ec.guild_supply_0,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=ec.guild_supply_1,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Supply Ally (Row 2)",b:"Right-click to send supplies to the allied guild in row 2 — strengthens the pact. The ally name is on the row label."}
execute as @e[type=interaction,tag=ec.guild_supply_1,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=ec.guild_supply_2,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Supply Ally (Row 3)",b:"Right-click to send supplies to the allied guild in row 3 — strengthens the pact. The ally name is on the row label."}
execute as @e[type=interaction,tag=ec.guild_supply_2,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=ec.guild_supply_3,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Supply Ally (Row 4)",b:"Right-click to send supplies to the allied guild in row 4 — strengthens the pact. The ally name is on the row label."}
execute as @e[type=interaction,tag=ec.guild_supply_3,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=ec.guild_remove_ally_0,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Break Pact (Row 1)",b:"Right-click to end the alliance with the guild in row 1 — irreversible."}
execute as @e[type=interaction,tag=ec.guild_remove_ally_0,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=ec.guild_remove_ally_1,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Break Pact (Row 2)",b:"Right-click to end the alliance with the guild in row 2 — irreversible."}
execute as @e[type=interaction,tag=ec.guild_remove_ally_1,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=ec.guild_remove_ally_2,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Break Pact (Row 3)",b:"Right-click to end the alliance with the guild in row 3 — irreversible."}
execute as @e[type=interaction,tag=ec.guild_remove_ally_2,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=ec.guild_remove_ally_3,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Break Pact (Row 4)",b:"Right-click to end the alliance with the guild in row 4 — irreversible."}
execute as @e[type=interaction,tag=ec.guild_remove_ally_3,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack run data remove entity @s attack
