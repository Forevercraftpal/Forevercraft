# Guild NPC — Start dismiss (from management menu trigger 11)
# @s = player, at their position

# Must be rank 5+ (Administrator)
data modify storage evercraft:notify stage.c set value [{text:"You need Administrator rank or higher to dismiss NPCs!",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute unless score @s ec.guild_rank matches 5.. run function evercraft:util/notify/emit
execute unless score @s ec.guild_rank matches 5.. run return 0

# Find nearest guild NPC within 16 blocks that belongs to this guild
data modify storage evercraft:notify stage.c set value [{text:"No Guild NPC found within 16 blocks!",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute unless entity @e[type=villager,tag=ec.guild_npc,distance=..16,limit=1,sort=nearest] run function evercraft:util/notify/emit
execute unless entity @e[type=villager,tag=ec.guild_npc,distance=..16,limit=1,sort=nearest] run return 0

# Verify NPC belongs to this guild
scoreboard players set #gnpc_match ec.temp 0
execute as @e[type=villager,tag=ec.guild_npc,distance=..16,limit=1,sort=nearest] if score @s ec.guild_id = @p ec.guild_id run scoreboard players set #gnpc_match ec.temp 1
data modify storage evercraft:notify stage.c set value [{text:"That NPC does not belong to your guild!",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute if score #gnpc_match ec.temp matches 0 run function evercraft:util/notify/emit
execute if score #gnpc_match ec.temp matches 0 run return 0

# Dismiss the NPC
execute as @e[type=villager,tag=ec.guild_npc,distance=..16,limit=1,sort=nearest] if score @s ec.guild_id = @p ec.guild_id run function evercraft:guild/npc/dismiss

# Confirm
data modify storage evercraft:notify stage.c set value [{text:"Guild NPC dismissed.",color:"gold"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
