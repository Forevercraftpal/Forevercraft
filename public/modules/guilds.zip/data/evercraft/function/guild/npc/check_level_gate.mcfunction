# Guild NPC — Check if guild level is high enough for this profession
# Reads: #gnpc_guild_lvl ec.temp (guild level), storage evercraft:guild_npc temp.profession
# Sets: #gnpc_level_ok ec.temp (1 = allowed, 0 = too low)

scoreboard players set #gnpc_level_ok ec.temp 0
scoreboard players set #gnpc_req_lvl ec.temp 99

# Level requirements: unlock 1 profession every 2 guild levels
# Lvl 2: Technician (Redstoner) — first, most basic
execute if data storage evercraft:guild_npc {temp:{profession:"circut_board"}} run scoreboard players set #gnpc_req_lvl ec.temp 2
# Lvl 4: Miner
execute if data storage evercraft:guild_npc {temp:{profession:"miner"}} run scoreboard players set #gnpc_req_lvl ec.temp 4
# Lvl 6: Hunter
execute if data storage evercraft:guild_npc {temp:{profession:"hunter"}} run scoreboard players set #gnpc_req_lvl ec.temp 6
# Lvl 8: Beekeeper
execute if data storage evercraft:guild_npc {temp:{profession:"beekeeper"}} run scoreboard players set #gnpc_req_lvl ec.temp 8
# Lvl 10: Bartender
execute if data storage evercraft:guild_npc {temp:{profession:"bartender"}} run scoreboard players set #gnpc_req_lvl ec.temp 10
# Lvl 12: Retired Adventurer
execute if data storage evercraft:guild_npc {temp:{profession:"retired_adventurer"}} run scoreboard players set #gnpc_req_lvl ec.temp 12
# Lvl 14: Artificer
execute if data storage evercraft:guild_npc {temp:{profession:"artificer"}} run scoreboard players set #gnpc_req_lvl ec.temp 14
# Lvl 16: Taskmaster
execute if data storage evercraft:guild_npc {temp:{profession:"taskmaster"}} run scoreboard players set #gnpc_req_lvl ec.temp 16
# Lvl 18: Explorer
execute if data storage evercraft:guild_npc {temp:{profession:"explorer"}} run scoreboard players set #gnpc_req_lvl ec.temp 18
# Lvl 20: Zookeeper
execute if data storage evercraft:guild_npc {temp:{profession:"zookeeper"}} run scoreboard players set #gnpc_req_lvl ec.temp 20
# Lvl 22: Sage (Wise Wanderer)
execute if data storage evercraft:guild_npc {temp:{profession:"wise_wanderer"}} run scoreboard players set #gnpc_req_lvl ec.temp 22
# Lvl 24: Nymph — last, most powerful
execute if data storage evercraft:guild_npc {temp:{profession:"nymph"}} run scoreboard players set #gnpc_req_lvl ec.temp 24

# Check if guild level meets requirement
execute if score #gnpc_guild_lvl ec.temp >= #gnpc_req_lvl ec.temp run scoreboard players set #gnpc_level_ok ec.temp 1
