# Guild NPC — Recruitment trigger (advancement reward)
# @s = player who right-clicked a profession villager
# Fires on EVERY profession villager interaction — must filter for sneak + guild zone

# Always revoke so it can re-fire
advancement revoke @s only evercraft:guild/recruit_npc

# Must be sneaking to recruit (normal right-click = just trading)
execute unless predicate evercraft:companions/is_sneaking run return 0

# Must be in a guild
execute unless score @s ec.guild_id matches 1.. run return 0

# Must be in guild zone
execute unless score @s ec.guild_in_zone matches 1 run return 0

# Must have guild level 2+ to recruit any NPC
execute store result score #gnpc_guild_lvl ec.temp run execute positioned 0 -61 0 as @e[type=marker,tag=ec.guild,distance=..2,predicate=evercraft:guild/check_id,limit=1] run data get entity @s data.level
data modify storage evercraft:notify stage.c set value [{text:"Your guild must be level 2+ to recruit profession NPCs.",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute if score #gnpc_guild_lvl ec.temp matches ..1 run function evercraft:util/notify/emit
execute if score #gnpc_guild_lvl ec.temp matches ..1 run return 0

# Find the nearest profession villager (the one we interacted with)
# Exclude already-recruited NPCs
data modify storage evercraft:notify stage.c set value [{text:"No recruitable profession villager nearby.",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute unless entity @e[type=minecraft:villager,tag=more_professions_verified,tag=!GuildNPC,distance=..6,limit=1,sort=nearest] run function evercraft:util/notify/emit
execute unless entity @e[type=minecraft:villager,tag=more_professions_verified,tag=!GuildNPC,distance=..6,limit=1,sort=nearest] run return 0

# Detect which profession this villager is
execute as @e[type=minecraft:villager,tag=more_professions_verified,tag=!GuildNPC,distance=..6,limit=1,sort=nearest] run function evercraft:guild/npc/detect_profession

# Check guild level gate for this specific profession
function evercraft:guild/npc/check_level_gate
data modify storage evercraft:notify stage.c set value [{text:"Your guild needs level ",color:"red"},{score:{name:"#gnpc_req_lvl",objective:"ec.temp"},color:"yellow"},{text:" to recruit this profession.",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute if score #gnpc_level_ok ec.temp matches 0 run function evercraft:util/notify/emit
execute if score #gnpc_level_ok ec.temp matches 0 run return 0

# Check if this profession already exists in the guild
scoreboard players operation #Search ec.guild_id = @s ec.guild_id
function evercraft:guild/npc/check_duplicate with storage evercraft:guild_npc temp

# If check_duplicate set #gnpc_dup to 1, profession already recruited
data modify storage evercraft:notify stage.c set value [{text:"Your guild already has this profession recruited!",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute if score #gnpc_dup ec.temp matches 1 run function evercraft:util/notify/emit
execute if score #gnpc_dup ec.temp matches 1 run return 0

# All checks passed — recruit the villager
execute as @e[type=minecraft:villager,tag=more_professions_verified,tag=!GuildNPC,distance=..6,limit=1,sort=nearest] run function evercraft:guild/npc/recruit

data modify storage evercraft:notify stage.c set value [{text:"Profession villager recruited to the guild!",color:"yellow"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.player.levelup master @s ~ ~ ~ 0.7 1.5
