# Guild Zone — Player enters guild zone
# @s = player entering zone
scoreboard players set @s ec.guild_in_zone 1
data modify storage evercraft:notify stage.c set value [{text:"You have entered the guild zone.",color:"green"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.beacon.ambient player @s ~ ~ ~ 0.5 1.5

# Apply guild companion pet abilities
function evercraft:guild/pets/abilities/apply_all_zone

# Joseph 2026-06-13 task #74 — guild+house overlap discoverability (companion notify
# to housing/zone/enter.mcfunction). When the player enters their guild zone while
# already standing in their home zone, surface the harmonized Regen/Resistance
# upgrade so they know it's firing.
execute if score @s hs.in_zone matches 1 run data modify storage evercraft:notify stage.c set value [{text:"⚓ ",color:"gold"},{text:"Guild + Home",color:"green"},{text:" — buffs harmonized.",color:"gray"}]
execute if score @s hs.in_zone matches 1 run scoreboard players set #ndur ec.temp 40
execute if score @s hs.in_zone matches 1 run function evercraft:util/notify/emit
