# Guild Zone — Player leaves guild zone
# @s = player leaving zone
scoreboard players set @s ec.guild_in_zone 0
data modify storage evercraft:notify stage.c set value [{text:"You have left the guild zone.",color:"gray"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit

# Remove guild companion pet abilities
function evercraft:guild/pets/abilities/reset_all
