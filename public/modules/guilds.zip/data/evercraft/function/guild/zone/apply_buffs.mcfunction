# ============================================================
# Guild Zone — Apply passive buffs while in zone
# @s = player in guild zone, called every 5s
# Effects given with 7s duration (5s refresh = always active)
# ============================================================

# All members: Regeneration I + Resistance I — harmonized to II if also in housing zone
execute unless score @s hs.in_zone matches 1 run effect give @s regeneration 7 0 true
execute if score @s hs.in_zone matches 1 run effect give @s regeneration 7 1 true
execute unless score @s hs.in_zone matches 1 run effect give @s resistance 7 0 true
execute if score @s hs.in_zone matches 1 if score @s hs.tier matches 5 run effect give @s resistance 7 1 true
execute if score @s hs.in_zone matches 1 unless score @s hs.tier matches 5 run effect give @s resistance 7 0 true

# Guild level 3+: Haste I
scoreboard players operation #Search ec.guild_id = @s ec.guild_id
execute positioned 0 -61 0 as @e[type=marker,tag=ec.guild,distance=..2,predicate=evercraft:guild/check_id,limit=1] store result score #gz_guild_lvl ec.temp run data get entity @s data.level

execute if score #gz_guild_lvl ec.temp matches 3.. run effect give @s haste 7 0 true

# Guild level 7+: Hero of the Village
execute if score #gz_guild_lvl ec.temp matches 7.. run effect give @s hero_of_the_village 7 0 true

# SP9 Hearth Comfort (guild): while a companion is placed at the guild hall, EVERY member in the zone
# gets a MODEST comfort buff scaling with the best guild-placed companion's TIER + BOND (cached in
# companion.gcomfort 0..11 by guild/pets/abilities/comfort_score, recomputed on every place/retrieve/
# zone-enter). Gated on gcomfort>=1 so it costs nothing when no companion is placed. Short-refresh
# (7s = the 5s tick keeps it live) → lapses cleanly on zone-leave. Regen amplifier picks the highest, so
# it harmonizes with (never double-stacks) the member regen above.
#   1..5 → Regeneration I    6..8 → Regeneration I + Saturation I    9..11 → Regeneration II + Saturation I
execute if score @s companion.gcomfort matches 1..8 run effect give @s regeneration 7 0 true
execute if score @s companion.gcomfort matches 9.. run effect give @s regeneration 7 1 true
execute if score @s companion.gcomfort matches 6.. run effect give @s saturation 7 0 true

# Pet Warp Strike — tamed mobs defend the guild hall (every 10s = 2 cycles of 5s tick)
scoreboard players remove @s ec.gs_warp_cd 1
execute if score @s ec.gs_warp_cd matches ..0 run function evercraft:guild/pet_warp/strike_guild
execute if score @s ec.gs_warp_cd matches ..0 run scoreboard players set @s ec.gs_warp_cd 2

# Zone Protection: Tamed cats, dogs, and parrots owned by guild members get Regen I + Resistance I (7s)
execute at @s as @e[type=#evercraft:zone_protected_pets,tag=ec.tame_protected,distance=..128] run function evercraft:guild/zone/buff_member_pets

# Guild passive proc (Standing Resonance): while a member is in the guild zone, cache
# which buff-totem TYPES are placed in the guild (guild-keyed) so the 15-min proc fires
# ANYWHERE off the cache. Buff travels with each member (LOCKED event-push pattern).
function evercraft:inscription/procs/guild/cache_types
