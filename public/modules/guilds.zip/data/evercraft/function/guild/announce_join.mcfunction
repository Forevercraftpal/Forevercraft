# Guild — Announce player joining
function evercraft:util/notify/whoami
data modify storage evercraft:notify stage.c set value [{text:"",color:"green"},{text:" has joined the guild!",color:"gold"}]
data modify storage evercraft:notify stage.c[0].text set from storage evercraft:notify named.who
scoreboard players set #ndur ec.temp 45
execute as @a[scores={ec.guild_id=1..}] run scoreboard players set #nttl ec.temp 300
execute as @a[scores={ec.guild_id=1..}] run function evercraft:util/notify/emit
