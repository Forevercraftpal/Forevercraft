# Guild Scatter Node Reward — Forever Coins
# @s = player who clicked node

scoreboard players add @s ec.coins 2
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.experience_orb.pickup player @s ~ ~ ~ 0.5 1.8
data modify storage evercraft:notify stage.c set value [{text:"You found ",color:"gray"},{text:"2 Forever Coins",color:"#E0B0FF",bold:true},{text:"!",color:"gray"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
function evercraft:guild/contribution/add {amount:10}
