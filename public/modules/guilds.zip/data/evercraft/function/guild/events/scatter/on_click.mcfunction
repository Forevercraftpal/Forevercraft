# Guild Event — Node Scatter: Handle node click
# @s = interaction entity that was right-clicked, at @s context

# Tag the clicking player (nearest within interaction range)
execute as @p[distance=..3.5] run tag @s add ec.ge_collector

# Clear interaction data so it doesn't fire again
data remove entity @s interaction

# Find paired marker at same position and dispatch reward
execute as @e[type=marker,tag=ec.guild_node,distance=..3.5,limit=1,sort=nearest] run function evercraft:guild/events/scatter/dispatch_reward

# Kill both entities (marker + interaction)
kill @e[type=marker,tag=ec.guild_node,distance=..3.5,limit=1,sort=nearest]
kill @s

# Clear collector tag
tag @a remove ec.ge_collector
