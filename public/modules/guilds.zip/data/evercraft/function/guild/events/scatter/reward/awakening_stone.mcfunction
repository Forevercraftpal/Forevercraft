# Guild Scatter Node Reward — Awakening Stone (rare)
# @s = player who clicked node

give @s minecraft:stick[item_model="minecraft:amethyst_cluster",custom_name={text:"Awakening Stone",color:"light_purple",italic:false},custom_data={awakening_stone:true,tier:"common"}] 1
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.amethyst_block.chime player @s ~ ~ ~ 0.8 1.2
data modify storage evercraft:notify stage.c set value [{text:"You found an ",color:"gray"},{text:"Awakening Stone",color:"light_purple"},{text:"!",color:"gray"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
function evercraft:guild/contribution/add {amount:10}
