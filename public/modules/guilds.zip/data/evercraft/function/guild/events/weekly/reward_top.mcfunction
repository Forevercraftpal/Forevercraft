# Guild Event — Weekly: Reward Top Contributor
# @s = top contributing player

# Permanent title tag
tag @s add ec.title_top_contributor

# +125 extra contribution
execute store result storage evercraft:guild temp.amount int 1 run scoreboard players set #ge_reward ec.temp 125
function evercraft:guild/contribution/add {amount:125}

# +50 levels XP
function evercraft:util/xp_levels {n:50}

# +25 Forever Coins
scoreboard players add @s ec.coins 25

# Effects
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:ui.toast.challenge_complete player @s ~ ~ ~ 1.0 1.0
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.firework_rocket.blast player @s ~ ~ ~ 0.5 1.0
execute if score @s ec.fx_vis matches 1.. run particle totem_of_undying ~ ~1 ~ 1 1 1 0.3 25

# Title display
title @s times 10 70 30
title @s title [{text:"TOP CONTRIBUTOR",color:"gold"}]
title @s subtitle [{text:"Your dedication is unmatched.",color:"yellow",italic:true}]

# Personal notification
data modify storage evercraft:notify stage.c set value [{text:"You are this week's Top Contributor! ",color:"gold",bold:true}]
scoreboard players set #ndur ec.temp 50
function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Rewards: ",color:"gray"},{text:"+125 Contribution",color:"aqua"},{text:" + ",color:"gray"},{text:"+50 Levels XP",color:"green"},{text:" + ",color:"gray"},{text:"+25 Forever Coins",color:"#E0B0FF"}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"You earned the permanent title: ",color:"gray"},{text:"Top Contributor",color:"gold",bold:true}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit

# Announce to all guilded players
# (Wave 2, 2026-06-10: rides the queue — name via whoami, score via stage_text, protected.)
function evercraft:util/notify/whoami
data modify storage evercraft:notify stage.c set value [{text:"This week's Top Contributor: ",color:"gold"},{text:"",color:"gold"},{text:" (+",color:"gray"},{text:"",color:"aqua"},{text:" contribution)",color:"gray"}]
data modify storage evercraft:notify stage.c[1].text set from storage evercraft:notify named.who
execute store result storage evercraft:notify named.v int 1 run scoreboard players get #ge_top_score ec.temp
data modify storage evercraft:notify named.i set value 3
function evercraft:util/notify/stage_text with storage evercraft:notify named
scoreboard players set #ndur ec.temp 50
execute as @a[scores={ec.guild_id=1..}] run scoreboard players set #nttl ec.temp 600
execute as @a[scores={ec.guild_id=1..}] run function evercraft:util/notify/emit_keep
