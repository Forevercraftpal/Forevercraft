# Guild Scatter Node Reward — Crate (uncommon-rare tier)
# @s = player who clicked node

# Roll 1-2: 1 = uncommon, 2 = rare
execute unless predicate {"condition":"minecraft:random_chance","chance":0.5} run return run function evercraft:guild/events/scatter/reward/crate_rare

# Uncommon crate
give @s minecraft:barrel[custom_data={qc_rarity:"uncommon"},custom_name={text:"Uncommon Crate",color:"green",italic:false},lore=[{text:"Guild Scatter Reward",color:"gray",italic:false},{text:"Contains: Uncommon tier loot",color:"dark_gray",italic:false},{text:"Right-click to open",color:"yellow",italic:false}],container_loot={loot_table:"evercraft:treasure/chests/default/uncommon",seed:0}] 1
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.chest.open player @s ~ ~ ~ 0.5 1.2
data modify storage evercraft:notify stage.c set value [{text:"You found an ",color:"gray"},{text:"Uncommon Crate",color:"green"},{text:"!",color:"gray"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
function evercraft:guild/contribution/add {amount:8}
