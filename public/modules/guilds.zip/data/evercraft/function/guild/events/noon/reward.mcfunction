# Guild Event — Daily Noon Gathering: Reward
# @s = qualifying player (50%+ presence)

# Grant ~7 levels worth of XP
function evercraft:util/xp_levels {n:7}

# Grant 1 Forever Coin
scoreboard players add @s ec.coins 1

# Effects
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.player.levelup player @s ~ ~ ~ 0.5 1.2
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.experience_orb.pickup player @s ~ ~ ~ 0.5 1.5

# Notify
data modify storage evercraft:notify stage.c set value [{text:"Guild Gathering Reward: ",color:"gold"},{text:"+7 Levels XP",color:"green"},{text:" + ",color:"gray"},{text:"+1 Forever Coin",color:"#E0B0FF"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
