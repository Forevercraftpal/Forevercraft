# Guild Scatter Node Reward — Rare Crate (50% chance from crate roll)
# @s = player who clicked node

give @s minecraft:barrel[custom_data={qc_rarity:"rare"},custom_name={text:"Rare Crate",color:"aqua",italic:false},lore=[{text:"Guild Scatter Reward",color:"gray",italic:false},{text:"Contains: Rare tier loot",color:"dark_gray",italic:false},{text:"Right-click to open",color:"yellow",italic:false}],container_loot={loot_table:"evercraft:treasure/chests/default/rare",seed:0}] 1
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.chest.open player @s ~ ~ ~ 0.5 1.0
data modify storage evercraft:notify stage.c set value [{text:"You found a ",color:"gray"},{text:"Rare Crate",color:"aqua"},{text:"!",color:"gray"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
function evercraft:guild/contribution/add {amount:12}
