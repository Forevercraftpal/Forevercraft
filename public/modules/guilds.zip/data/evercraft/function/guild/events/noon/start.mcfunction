# Guild Event — Daily Noon Gathering: Start
# Lasts 3 minutes (3600 ticks). Players near guildstone for 50%+ get rewards.

# Activate
scoreboard players set #ge_noon_active ec.var 1
scoreboard players set #ge_noon_timer ec.var 3600
scoreboard players operation #ge_last_noon_day ec.var = #visual_day ec.var

# Reset presence tracking for all guilded players
scoreboard players set @a[scores={ec.guild_id=1..}] ec.ge_noon_ticks 0

# Announce to all guilded players
data modify storage evercraft:notify stage.c set value [{text:"☀ The daily guild gathering has begun! ",color:"gold"},{text:"Be near your guildstone for 90 seconds to earn rewards.",color:"yellow"},{text:" ☀",color:"gold"}]
scoreboard players set #ndur ec.temp 50
execute as @a[scores={ec.guild_id=1..}] run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Rewards: ",color:"gray"},{text:"7 Levels XP",color:"green"},{text:" + ",color:"gray"},{text:"1 Forever Coin",color:"#E0B0FF"}]
scoreboard players set #ndur ec.temp 40
execute as @a[scores={ec.guild_id=1..}] run function evercraft:util/notify/emit

# Sound
execute as @a[scores={ec.guild_id=1..}] at @s if score @s ec.fx_snd matches 1.. run playsound minecraft:block.bell.use player @s ~ ~ ~ 0.5 1.0
