# Guild Event — Teleport to guildstone
# @s = player who clicked the teleport option

# Must be in a guild
execute unless score @s ec.guild_id matches 1.. run return 0

# Find guild marker and get zone coordinates
scoreboard players operation #Search ec.guild_id = @s ec.guild_id
data modify storage evercraft:notify stage.c set value [{text:"Could not find your guildstone!",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute unless entity @e[type=marker,tag=ec.guild,predicate=evercraft:guild/check_id,limit=1] run function evercraft:util/notify/emit
execute unless entity @e[type=marker,tag=ec.guild,predicate=evercraft:guild/check_id,limit=1] run return 0

# Verify guild zone data exists on the marker
data modify storage evercraft:notify stage.c set value [{text:"Your guild has no zone set up!",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute unless data entity @e[type=marker,tag=ec.guild,predicate=evercraft:guild/check_id,limit=1] data.zone run function evercraft:util/notify/emit
execute unless data entity @e[type=marker,tag=ec.guild,predicate=evercraft:guild/check_id,limit=1] data.zone run return 0

# Load zone coords into storage for macro teleport
execute store result storage evercraft:guild_events tp.x int 1 run data get entity @e[type=marker,tag=ec.guild,predicate=evercraft:guild/check_id,limit=1] data.zone.x
execute store result storage evercraft:guild_events tp.y int 1 run data get entity @e[type=marker,tag=ec.guild,predicate=evercraft:guild/check_id,limit=1] data.zone.y
execute store result storage evercraft:guild_events tp.z int 1 run data get entity @e[type=marker,tag=ec.guild,predicate=evercraft:guild/check_id,limit=1] data.zone.z

# Convert integer dim (0/1/2) to namespace string for execute in
execute store result score #gs_tp_dim ec.temp run data get entity @e[type=marker,tag=ec.guild,predicate=evercraft:guild/check_id,limit=1] data.zone.dim
data modify storage evercraft:guild_events tp.dim set value "minecraft:overworld"
execute if score #gs_tp_dim ec.temp matches 1 run data modify storage evercraft:guild_events tp.dim set value "minecraft:the_nether"
execute if score #gs_tp_dim ec.temp matches 2 run data modify storage evercraft:guild_events tp.dim set value "minecraft:the_end"

# Teleport
function evercraft:guild/events/do_teleport with storage evercraft:guild_events tp

# Effects
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.enderman.teleport player @s ~ ~ ~ 0.5 1.0
particle reverse_portal ~ ~1 ~ 0.3 0.5 0.3 0.05 15
data modify storage evercraft:notify stage.c set value [{text:"Teleported to your guildstone!",color:"green"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
