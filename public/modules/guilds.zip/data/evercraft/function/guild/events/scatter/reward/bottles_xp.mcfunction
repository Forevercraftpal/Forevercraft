# Guild Scatter Node Reward — Bottles of XP (most common)
# @s = player who clicked node

give @s minecraft:experience_bottle 4
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.experience_orb.pickup player @s ~ ~ ~ 0.5 1.2
data modify storage evercraft:notify stage.c set value [{text:"You found ",color:"gray"},{text:"4 Bottles o' Enchanting",color:"green"},{text:"!",color:"gray"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
function evercraft:guild/contribution/add {amount:3}
