# ============================================================
# Guild Companion — Hearth Comfort: recompute the member's cached guild comfort score (SP9)
# Run as: player (a guild member in the guild zone), called from abilities/apply_all_zone on every
# roster change (zone-enter / place / retrieve). ONE-writer of companion.gcomfort.
# ============================================================
# Caches the BEST guild-placed companion's (tier + bondLvl) into companion.gcomfort 0..11, scanning ALL
# guild companions of this member's guild (a guild buff for every member in the zone, not just the owner).
# Read each 5s by guild/zone/apply_buffs to refresh a modest short-duration effect, so the buff lapses
# cleanly on zone-leave / retrieval. Cached here (not per-tick) to avoid per-tick NBT reads.

# Reset to 0; no guild companions placed → no Hearth Comfort.
scoreboard players set @s companion.gcomfort 0
scoreboard players set #gc_comfort_best companion.calc 0

# Scan every GC.Head in this member's guild, accumulating the max (tier+bondLvl) into #gc_comfort_best.
# #Search ec.guild_id is already this member's guild id (set by apply_all_zone before calling us).
execute as @e[type=item_display, tag=GC.Head] if score @s ec.guild_id = #Search ec.guild_id run function evercraft:guild/pets/abilities/comfort_score_one

# Write the best score onto this member.
scoreboard players operation @s companion.gcomfort = #gc_comfort_best companion.calc
