# ============================================================
# Guild Companion — Hearth Comfort: per-placed-companion contribution (SP9)
# Run as: GC.Head item_display entity (one guild-placed companion of the member's guild)
# Requires: #gc_comfort_best companion.calc = running max, raised in place.
# ============================================================
# Framework-sharing read (same axes as the active companion): TIER ← combat/get_tier_stats keyed on the
# `name` profile property; BOND ← the `relationship` property decoded against #RelLvl1..5. Both travel on
# the placed head's item, so a guild-placed companion's tier + bond are never dropped on place/retrieve.

# --- TIER: copy species name into the tier engine's input slot, then read #pc_tier 1..6 ---
# Same source the journey tier-read uses (read_tier_macro:4): the `name` profile property's .value.
data modify storage evercraft:companion_combat companion_name set from entity @s item.components."minecraft:profile".properties[{name:"name"}].value
function evercraft:companions/combat/get_tier_stats
scoreboard players operation #gc_comfort_one companion.calc = #pc_tier ec.var

# --- BOND: decode relationship RP → bond level 0..5 (same thresholds as load_rp) ---
data modify storage evercraft:companions math.string set string entity @s item.components."minecraft:profile".properties[{name:"relationship"}].value
scoreboard players set #value companion.calc 0
function evercraft:companions/handler/math/string_to_int
scoreboard players set #gc_comfort_bond companion.calc 0
execute if score #value companion.calc >= #RelLvl1 companion.calc run scoreboard players set #gc_comfort_bond companion.calc 1
execute if score #value companion.calc >= #RelLvl2 companion.calc run scoreboard players set #gc_comfort_bond companion.calc 2
execute if score #value companion.calc >= #RelLvl3 companion.calc run scoreboard players set #gc_comfort_bond companion.calc 3
execute if score #value companion.calc >= #RelLvl4 companion.calc run scoreboard players set #gc_comfort_bond companion.calc 4
execute if score #value companion.calc >= #RelLvl5 companion.calc run scoreboard players set #gc_comfort_bond companion.calc 5

# score = tier (1..6) + bondLvl (0..5) → 1..11; keep the running max.
scoreboard players operation #gc_comfort_one companion.calc += #gc_comfort_bond companion.calc
execute if score #gc_comfort_one companion.calc > #gc_comfort_best companion.calc run scoreboard players operation #gc_comfort_best companion.calc = #gc_comfort_one companion.calc
