# Guild Diplomacy — Process a NO vote
# @s = player who voted no (trigger ec.gd_diplo = 5)

# Must have an active vote
execute unless score @s ec.gd_vote_cd matches 1.. run return 0

# Save voter's guild ID for matching
scoreboard players operation #gd_voter_guild ec.temp = @s ec.guild_id

# Increment no counter on ALL same-guild online members with active vote
execute as @a[scores={ec.gd_vote_cd=1..}] if score @s ec.guild_id = #gd_voter_guild ec.temp run scoreboard players add @s ec.gd_vote_no 1
execute as @a[scores={ec.gd_vote_cd=1..}] if score @s ec.guild_id = #gd_voter_guild ec.temp run scoreboard players add @s ec.gd_vote_total 1

# Prevent double voting
scoreboard players set @s ec.gd_vote_cd -1

# Announce vote to guild
function evercraft:util/notify/whoami
data modify storage evercraft:notify stage.c set value [{text:"",color:"gray"},{text:" voted ",color:"gray"},{text:"NO",color:"red"}]
data modify storage evercraft:notify stage.c[0].text set from storage evercraft:notify named.who
scoreboard players set #ndur ec.temp 45
execute as @a[scores={ec.gd_vote_cd=1..}] run scoreboard players set #nttl ec.temp 300
execute as @a[scores={ec.gd_vote_cd=1..}] run function evercraft:util/notify/emit

# Check if vote resolves
function evercraft:guild/diplomacy/propose/check_resolve
