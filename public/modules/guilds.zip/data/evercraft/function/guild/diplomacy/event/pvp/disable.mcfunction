# Guild Diplomacy — Disable PvP, restore team
# @s = player leaving enemy zone or event ending

tag @s remove ec.gd_pvp

# Clear the totem-aura hostile flag set in enable.mcfunction (Council #11 followup #2).
tag @s remove ec.pvp_hostile

# Restore title team (re-apply whatever title they had)
execute if score @s wb.title matches 1.. run function evercraft:bosses/titles/apply
execute if score @s ec.gd_title matches 1.. unless score @s wb.title matches 1.. run function evercraft:guild/diplomacy/titles/apply

# Notify (only during active event, not cleanup)
data modify storage evercraft:notify stage.c set value [{text:"You left enemy territory. PvP disabled.",color:"gray"}]
scoreboard players set #ndur ec.temp 45
execute if score #gd_event_active ec.var matches 1 run function evercraft:util/notify/emit
