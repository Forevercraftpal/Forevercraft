# Guild Diplomacy — Cooldown check gate for new competition/pillage proposals
# Run as: proposer's guild marker entity (selector at call site filters to limit=1 via check_id predicate)
# Macro: $(target_id) = target guild ID being proposed against
# Output: #gd_on_cooldown ec.temp = 1 if proposer's guild is still within the 4-day recovery
#         window against this target, 0 if clear or no prior entry.

scoreboard players set #gd_on_cooldown ec.temp 0
scoreboard players set #gd_cd_avail ec.temp 0
execute store result score #gd_now ec.temp run time query gametime

# Pick the matching cooldown entry (if any) into temp storage — fixes the prior [0]-index bug
# that ignored non-first matches.
data remove storage evercraft:guild temp.cd_match
$data modify storage evercraft:guild temp.cd_match set from entity @s data.cooldowns[{target_id:$(target_id)}]

# If a matching entry exists, read its available_at and compare to current gametime
execute if data storage evercraft:guild temp.cd_match.available_at store result score #gd_cd_avail ec.temp run data get storage evercraft:guild temp.cd_match.available_at
execute if score #gd_cd_avail ec.temp > #gd_now ec.temp run scoreboard players set #gd_on_cooldown ec.temp 1

# Cleanup
data remove storage evercraft:guild temp.cd_match
