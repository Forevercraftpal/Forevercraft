# Guild Diplomacy — Final event start announcement
# $(guild_a_name) $(guild_b_name) $(activity_name)

# Competition announcement
data modify storage evercraft:notify stage.c set value [{text:"COMPETITION STARTED!",color:"yellow",bold:true}]
scoreboard players set #ndur ec.temp 50
execute if score #gd_event_type ec.var matches 1 as @a[scores={ec.gd_event_active=1}] run function evercraft:util/notify/emit
$data modify storage evercraft:notify stage.c set value [{text:"$(guild_a_name)",color:"gold"},{text:" vs ",color:"gray"},{text:"$(guild_b_name)",color:"gold"}]
scoreboard players set #ndur ec.temp 40
execute if score #gd_event_type ec.var matches 1 as @a[scores={ec.gd_event_active=1}] run function evercraft:util/notify/emit
$data modify storage evercraft:notify stage.c set value [{text:"Activity: ",color:"gray"},{text:"$(activity_name)",color:"aqua",bold:true}]
scoreboard players set #ndur ec.temp 40
execute if score #gd_event_type ec.var matches 1 as @a[scores={ec.gd_event_active=1}] run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Duration: ",color:"gray"},{text:"1 In-Game Day",color:"white"}]
scoreboard players set #ndur ec.temp 40
execute if score #gd_event_type ec.var matches 1 as @a[scores={ec.gd_event_active=1}] run function evercraft:util/notify/emit

# Pillage announcement
data modify storage evercraft:notify stage.c set value [{text:"PILLAGE BEGUN!",color:"red",bold:true}]
scoreboard players set #ndur ec.temp 50
execute if score #gd_event_type ec.var matches 2 as @a[scores={ec.gd_event_active=1}] run function evercraft:util/notify/emit
$data modify storage evercraft:notify stage.c set value [{text:"$(guild_a_name)",color:"red"},{text:" vs ",color:"gray"},{text:"$(guild_b_name)",color:"red"}]
scoreboard players set #ndur ec.temp 40
execute if score #gd_event_type ec.var matches 2 as @a[scores={ec.gd_event_active=1}] run function evercraft:util/notify/emit
$data modify storage evercraft:notify stage.c set value [{text:"Activity: ",color:"gray"},{text:"$(activity_name)",color:"aqua",bold:true}]
scoreboard players set #ndur ec.temp 40
execute if score #gd_event_type ec.var matches 2 as @a[scores={ec.gd_event_active=1}] run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"PvP ENABLED in enemy territory!",color:"dark_red",bold:true}]
scoreboard players set #ndur ec.temp 40
execute if score #gd_event_type ec.var matches 2 as @a[scores={ec.gd_event_active=1}] run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Duration: ",color:"gray"},{text:"1 In-Game Day",color:"white"}]
scoreboard players set #ndur ec.temp 40
execute if score #gd_event_type ec.var matches 2 as @a[scores={ec.gd_event_active=1}] run function evercraft:util/notify/emit
