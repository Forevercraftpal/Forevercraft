# Guild Diplomacy — Announce event results
# $(guild_a_name) $(guild_b_name)

# Guild A won
data modify storage evercraft:notify stage.c set value [{text:"EVENT ENDED!",color:"yellow",bold:true}]
scoreboard players set #ndur ec.temp 50
execute if score #gd_score_a ec.var > #gd_score_b ec.var as @a[scores={ec.gd_event_active=1}] run function evercraft:util/notify/emit
$data modify storage evercraft:notify stage.c set value [{text:"WINNER: ",color:"gray"},{text:"$(guild_a_name)",color:"gold",bold:true}]
scoreboard players set #ndur ec.temp 40
execute if score #gd_score_a ec.var > #gd_score_b ec.var as @a[scores={ec.gd_event_active=1}] run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Score: ",color:"gray"},{score:{name:"#gd_score_a",objective:"ec.var"},color:"green"},{text:" — ",color:"dark_gray"},{score:{name:"#gd_score_b",objective:"ec.var"},color:"red"}]
scoreboard players set #ndur ec.temp 40
execute if score #gd_score_a ec.var > #gd_score_b ec.var as @a[scores={ec.gd_event_active=1}] run function evercraft:util/notify/emit

# Guild B won
data modify storage evercraft:notify stage.c set value [{text:"EVENT ENDED!",color:"yellow",bold:true}]
scoreboard players set #ndur ec.temp 50
execute if score #gd_score_b ec.var > #gd_score_a ec.var as @a[scores={ec.gd_event_active=1}] run function evercraft:util/notify/emit
$data modify storage evercraft:notify stage.c set value [{text:"WINNER: ",color:"gray"},{text:"$(guild_b_name)",color:"gold",bold:true}]
scoreboard players set #ndur ec.temp 40
execute if score #gd_score_b ec.var > #gd_score_a ec.var as @a[scores={ec.gd_event_active=1}] run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Score: ",color:"gray"},{score:{name:"#gd_score_b",objective:"ec.var"},color:"green"},{text:" — ",color:"dark_gray"},{score:{name:"#gd_score_a",objective:"ec.var"},color:"red"}]
scoreboard players set #ndur ec.temp 40
execute if score #gd_score_b ec.var > #gd_score_a ec.var as @a[scores={ec.gd_event_active=1}] run function evercraft:util/notify/emit
