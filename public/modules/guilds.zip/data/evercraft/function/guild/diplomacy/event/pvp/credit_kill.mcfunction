# Guild Diplomacy — Credit a PvP kill to the killer
# @s = the killer (nearest enemy participant)

scoreboard players add @s ec.gd_pvp_kills 1

data modify storage evercraft:notify stage.c set value [{text:"Enemy slain! +1 Kill Score",color:"gold"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.experience_orb.pickup master @s ~ ~ ~ 0.8 1.5
