# Guild Diplomacy — Enable PvP for player in enemy territory
# @s = player entering enemy zone during pillage

# Save current team (for restoration later)
# Use the team detection pattern from duel system
tag @s add ec.gd_pvp

# Mark hostile for the totem-aura classifier (Council #11 followup #2): a player
# flagged for guild-pillage PvP is excluded from others' totem buffs while raiding.
tag @s add ec.pvp_hostile

# Leave team to enable PvP (same as duel leave_team pattern)
team leave @s

# Notify
data modify storage evercraft:notify stage.c set value [{text:"You've entered enemy territory! ",color:"red",bold:true},{text:"PvP ENABLED",color:"dark_red",bold:true}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.bell.use master @s ~ ~ ~ 1 0.5
