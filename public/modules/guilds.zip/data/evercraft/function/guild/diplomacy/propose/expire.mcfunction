# Guild Diplomacy — Vote expired (non-queued only, cd hit 0)
# @s = a player whose vote timed out

# Announce to their guild
data modify storage evercraft:notify stage.c set value [{text:"Vote timed out! Proposal failed.",color:"red"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit

# Full cleanup — this cancels the entire proposal for both guilds
function evercraft:guild/diplomacy/propose/cleanup
