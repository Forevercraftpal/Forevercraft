# Guild — Macro: announce rank promotion
$data modify storage evercraft:notify stage.c set value [{text:"You have been promoted to ",color:"gold"},{text:"$(rank_name)",color:"green",bold:true},{text:"!",color:"gold"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
$data modify storage evercraft:notify stage.c set value [{selector:"@p[tag=ec.guild_self]"},{text:" has been promoted to ",color:"gold"},{text:"$(rank_name)",color:"green"},{text:"!",color:"gold"}]
scoreboard players set #ndur ec.temp 45
execute as @a[scores={ec.guild_id=1..}] unless entity @s[tag=ec.guild_self] run function evercraft:util/notify/emit
