# Guild — Donation feedback
$data modify storage evercraft:notify stage.c set value [{text:"Donated! ",color:"green"},{text:"+$(donate_amt) contribution",color:"yellow"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
