# Guild Donation — Apply contribution from donation
# @s = donating player, #guild_donate_amt ec.temp = amount earned

# Show feedback
execute store result storage evercraft:guild temp.donate_amt int 1 run scoreboard players get #guild_donate_amt ec.temp
function evercraft:guild/contribution/donate_tellraw with storage evercraft:guild temp

# Add contribution
execute store result storage evercraft:guild temp.amount int 1 run scoreboard players get #guild_donate_amt ec.temp
function evercraft:guild/contribution/add with storage evercraft:guild temp

# Play sound
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.experience_orb.pickup player @s ~ ~ ~ 0.5 1.2

# Realm milestone bump moved into guild/contribution/add.mcfunction 2026-05-25
# (so quests/patron-kills/journal-regions also feed #rm_guild_contrib, not just donations)
