# Guild Expedition — Announce vote cancelled (macro)
data modify storage evercraft:notify stage.c set value [{text:"Expedition vote cancelled — no votes were cast.",color:"red"}]
scoreboard players set #ndur ec.temp 45
$execute as @a[scores={ec.guild_id=$(guild_id)}] run function evercraft:util/notify/emit
