# Guild Expedition — Notify player of bonus XP
# $(amount) = bonus XP granted
$data modify storage evercraft:notify stage.c set value [{text:"+$(amount) bonus XP",color:"green"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
