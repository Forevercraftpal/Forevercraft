# Guild Expedition — Announce Results (macro)
# Args: guild_id, biome_name, progress, goal, pct

data modify storage evercraft:notify stage.c set value [{text:"Expedition Complete!",color:"gold",bold:true}]
scoreboard players set #ndur ec.temp 50
$execute as @a[scores={ec.guild_id=$(guild_id)}] run function evercraft:util/notify/emit
$data modify storage evercraft:notify stage.c set value [{text:"Biome: ",color:"yellow"},{text:"$(biome_name)",color:"green",bold:true}]
scoreboard players set #ndur ec.temp 40
$execute as @a[scores={ec.guild_id=$(guild_id)}] run function evercraft:util/notify/emit
$data modify storage evercraft:notify stage.c set value [{text:"Progress: ",color:"yellow"},{text:"$(progress)/$(goal) ($(pct)%)",color:"aqua"}]
scoreboard players set #ndur ec.temp 40
$execute as @a[scores={ec.guild_id=$(guild_id)}] run function evercraft:util/notify/emit
$playsound minecraft:ui.toast.challenge_complete master @a[scores={ec.guild_id=$(guild_id),ec.fx_snd=1..}] ~ ~ ~ 1.0 1.2
