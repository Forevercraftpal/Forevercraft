# Guild Expedition — Reward notification (macro)
$data modify storage evercraft:notify stage.c set value [{text:"Rewards: ",color:"gold"},{text:"+$(coins) Coins",color:"yellow"},{text:" | ",color:"gray"},{text:"+$(xp) XP",color:"green"},{text:" | ",color:"gray"},{text:"+10 Contribution",color:"aqua"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
