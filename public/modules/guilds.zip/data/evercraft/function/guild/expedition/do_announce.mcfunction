# Guild Expedition — Macro announce
# $(activity) = activity name, $(mult_int).$(mult_dec) = multiplier display

$data modify storage evercraft:notify stage.c set value [{text:"The Expedition chosen for us today is ",color:"gold"},{text:"$(activity)",color:"yellow",bold:true},{text:"! ",color:"gold"},{text:"($(mult_int).$(mult_dec)x buff)",color:"green"}]
scoreboard players set #ndur ec.temp 50
execute if score #exp_disp_dec ec.temp matches 10.. as @a[scores={ec.guild_id=1..}] run function evercraft:util/notify/emit
$data modify storage evercraft:notify stage.c set value [{text:"The Expedition chosen for us today is ",color:"gold"},{text:"$(activity)",color:"yellow",bold:true},{text:"! ",color:"gold"},{text:"($(mult_int).0$(mult_dec)x buff)",color:"green"}]
scoreboard players set #ndur ec.temp 50
execute if score #exp_disp_dec ec.temp matches ..9 as @a[scores={ec.guild_id=1..}] run function evercraft:util/notify/emit
