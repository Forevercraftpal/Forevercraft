# Guild Expedition — Announce expedition started (macro)
# Args: biome_name, guild_id
data modify storage evercraft:notify stage.c set value [{text:"Expedition Started! ",color:"gold",bold:true}]
scoreboard players set #ndur ec.temp 50
$execute as @a[scores={ec.guild_id=$(guild_id)}] run function evercraft:util/notify/emit
$data modify storage evercraft:notify stage.c set value [{text:"Target: ",color:"yellow"},{text:"$(biome_name)",color:"green",bold:true}]
scoreboard players set #ndur ec.temp 40
$execute as @a[scores={ec.guild_id=$(guild_id)}] run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Explore that biome and kill mobs to earn progress!",color:"gray"}]
scoreboard players set #ndur ec.temp 40
$execute as @a[scores={ec.guild_id=$(guild_id)}] run function evercraft:util/notify/emit
$playsound minecraft:ui.toast.challenge_complete master @a[scores={ec.guild_id=$(guild_id),ec.fx_snd=1..}] ~ ~ ~ 1.0 1.0
