# Guild Expedition — Announce MVP (macro)
# @s = MVP player (from award_mvp.mcfunction context)
# (Wave 2, 2026-06-10: guild echo — whoami-baked, 15s TTL.)
function evercraft:util/notify/whoami
data modify storage evercraft:notify stage.c set value [{text:"MVP: ",color:"gold",bold:true},{text:"",color:"yellow",bold:true},{text:" earned a ",color:"gray"},{text:"Tree Token",color:"aqua"},{text:" for top contribution!",color:"gray"}]
data modify storage evercraft:notify stage.c[1].text set from storage evercraft:notify named.who
scoreboard players set #ndur ec.temp 45
$execute as @a[scores={ec.guild_id=$(guild_id)}] run scoreboard players set #nttl ec.temp 300
$execute as @a[scores={ec.guild_id=$(guild_id)}] run function evercraft:util/notify/emit
