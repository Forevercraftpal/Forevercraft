# Guild Invite — Accept invitation
# @s = player accepting (ec.guild_inv = 1)

# Validate: has a pending invite
data modify storage evercraft:notify stage.c set value [{text:"You don't have a pending guild invite!",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute unless score @s ec.guild_inv_from matches 1.. run function evercraft:util/notify/emit
execute unless score @s ec.guild_inv_from matches 1.. run return 0

# Validate: not already in a guild
data modify storage evercraft:notify stage.c set value [{text:"You are already in a guild! Leave first.",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute if score @s ec.guild_id matches 1.. run function evercraft:util/notify/emit
execute if score @s ec.guild_id matches 1.. run scoreboard players set @s ec.guild_inv_from 0
execute if score @s ec.guild_id matches 1.. run scoreboard players set @s ec.guild_inv_cd 0
execute if score @s ec.guild_id matches 1.. run return 0

# Join the guild
function evercraft:guild/join
