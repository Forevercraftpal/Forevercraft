# Guild Invite — Decline or timeout
# @s = player declining/timing out

# Only process if there's a pending invite
execute unless score @s ec.guild_inv_from matches 1.. run return 0

# Clear invite data
scoreboard players set @s ec.guild_inv_from 0
scoreboard players set @s ec.guild_inv_cd 0

# Notify
data modify storage evercraft:notify stage.c set value [{text:"Guild invite declined.",color:"gray"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
