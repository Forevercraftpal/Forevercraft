# Guild Kick — Process a vote (1=yes, 2=no)
# @s = voting player

# Must have an active kick vote
data modify storage evercraft:notify stage.c set value [{text:"No active kick vote!",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute unless score @s ec.guild_kick_cd matches 1.. run function evercraft:util/notify/emit
execute unless score @s ec.guild_kick_cd matches 1.. run return 0

# Record vote (1=yes, 2=no) — broadcast to all guild members with active vote
execute if score @s ec.guild_kick matches 1 as @a[scores={ec.guild_kick_cd=1..}] if score @s ec.guild_id = @p ec.guild_id run scoreboard players add @s ec.guild_kick_yes 1
execute if score @s ec.guild_kick matches 2 as @a[scores={ec.guild_kick_cd=1..}] if score @s ec.guild_id = @p ec.guild_id run scoreboard players add @s ec.guild_kick_no 1

# Announce the vote
execute if score @s ec.guild_kick matches 1 run function evercraft:util/notify/whoami
data modify storage evercraft:notify stage.c set value [{text:"",color:"gray"},{text:" voted ",color:"gray"},{text:"YES",color:"green"}]
data modify storage evercraft:notify stage.c[0].text set from storage evercraft:notify named.who
scoreboard players set #ndur ec.temp 45
execute if score @s ec.guild_kick matches 1 run execute as @a[scores={ec.guild_kick_cd=1..}] run scoreboard players set #nttl ec.temp 300
execute if score @s ec.guild_kick matches 1 run execute as @a[scores={ec.guild_kick_cd=1..}] run function evercraft:util/notify/emit
execute if score @s ec.guild_kick matches 2 run function evercraft:util/notify/whoami
data modify storage evercraft:notify stage.c set value [{text:"",color:"gray"},{text:" voted ",color:"gray"},{text:"NO",color:"red"}]
data modify storage evercraft:notify stage.c[0].text set from storage evercraft:notify named.who
scoreboard players set #ndur ec.temp 45
execute if score @s ec.guild_kick matches 2 run execute as @a[scores={ec.guild_kick_cd=1..}] run scoreboard players set #nttl ec.temp 300
execute if score @s ec.guild_kick matches 2 run execute as @a[scores={ec.guild_kick_cd=1..}] run function evercraft:util/notify/emit

# Check if majority reached
execute if score @s ec.guild_kick_yes >= @s ec.guild_kick_need run function evercraft:guild/kick/execute
