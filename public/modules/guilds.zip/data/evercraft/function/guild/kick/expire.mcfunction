# Guild Kick — Vote expired without reaching majority
# @s = player with expired kick timer

# Announce failure
data modify storage evercraft:notify stage.c set value [{text:"The kick vote has expired without reaching majority.",color:"gray"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit

# Clear state
scoreboard players set @s ec.guild_kick_cd 0
scoreboard players set @s ec.guild_kick_target 0
scoreboard players set @s ec.guild_kick_yes 0
scoreboard players set @s ec.guild_kick_no 0
scoreboard players set @s ec.guild_kick_need 0
