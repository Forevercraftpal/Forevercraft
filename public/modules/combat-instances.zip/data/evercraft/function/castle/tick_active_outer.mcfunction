# Wiring Audit B (2026-05-29) W7: castle per-party tick dispatcher.
# Called from evercraft:tick:295 fan-out (Shape D-1 + concurrency.md §6).
# @s is the party leader (ec.party_role=1) OR solo (ec.party_id=0).
# Derives pid via dual-key helper, then calls macro inner with storage cart.
function evercraft:_shared/derive_pid_from_party
function evercraft:castle/tick_active with storage evercraft:_shared cart
