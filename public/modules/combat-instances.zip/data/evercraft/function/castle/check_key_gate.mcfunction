# Wiring Audit B (2026-05-29) W7: Infinite Castle — Key Gate Check (per-party MACRO).
# Called with storage evercraft:_shared cart for $(pid). Every 10 floors checks key.
#
# Wiring Audit #45 FIX 2 (2026-06-06): SCAN THE WHOLE PARTY for a key-holder and charge
# ANY ONE of them (was: only the nearest member could pay — a keyed teammate couldn't cover
# a keyless nearest player). Per-member key count → ic.keyheld; pick the nearest holder as
# the payer; only force-fail if NOBODY in the party holds a key.

# Per-member dungeon-key count (single writer: this function only).
$execute as @a[tag=ic.player,tag=p$(pid)] store result score @s ic.keyheld run clear @s trial_key[custom_data~{dungeon_key:true}] 0

# Whole-party key total — drives the pass/fail decision (any holder → pass).
$execute store result score #ic_gate_keys.$(pid) ec.var if entity @a[tag=ic.player,tag=p$(pid),scores={ic.keyheld=1..}]

# Nobody in the party has a key — forced exit.
data modify storage evercraft:notify stage.c set value [{text:"No Dungeon Keys remaining — the castle rejects you!",color:"red"}]
scoreboard players set #ndur ec.temp 45
$execute if score #ic_gate_keys.$(pid) ec.var matches ..0 as @a[tag=ic.player,tag=p$(pid)] run function evercraft:util/notify/emit
$execute if score #ic_gate_keys.$(pid) ec.var matches ..0 run function evercraft:castle/fail with storage evercraft:_shared cart
$execute if score #ic_active.$(pid) ec.var matches 0 run return 0

# Pick ONE key-holder (nearest among holders) as the payer and consume 1 key from them.
# Tag/consume/untag are party-scoped (p$(pid)) and resolve within this same serial call.
$tag @a[tag=ic.player,tag=p$(pid),scores={ic.keyheld=1..},limit=1,sort=nearest] add ic.keypayer
$execute as @a[tag=ic.keypayer,tag=p$(pid)] run clear @s trial_key[custom_data~{dungeon_key:true}] 1
$tag @a[tag=ic.keypayer,tag=p$(pid)] remove ic.keypayer

# Announce (whole party) — show who covered the toll.
data modify storage evercraft:notify stage.c set value [{text:"Key consumed for floor gate.",color:"yellow"}]
scoreboard players set #ndur ec.temp 45
$execute as @a[tag=ic.player,tag=p$(pid)] run function evercraft:util/notify/emit
$playsound minecraft:block.trial_spawner.about_to_spawn_item master @a[tag=ic.player,tag=p$(pid),scores={ec.fx_snd=1..}] ~ ~ ~ 0.6 1.0
