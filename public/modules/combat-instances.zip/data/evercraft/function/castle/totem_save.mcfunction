# Wiring Audit B (2026-05-29) W7: Infinite Castle — Totem Save (per-party MACRO).
# Called with storage evercraft:_shared cart for $(pid). @s is the ic.player at critical HP.
# Saves from death, removes from castle, teleports to bed, -30 levels.

# === IMMEDIATE SURVIVAL ===
effect give @s minecraft:instant_health 1 5 true
effect give @s minecraft:resistance 3 4 true

# === TOTEM ANIMATION ===
particle minecraft:totem_of_undying ~ ~1 ~ 0.5 1 0.5 0.5 50
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:item.totem.use master @s ~ ~ ~ 1 1

# === PENALTIES ===
experience add @s -30 levels

# Brief darkness + nausea (knockout feel)
effect give @s minecraft:darkness 5 0 false
effect give @s minecraft:nausea 5 0 false

# Defeat title
title @s times 5 40 15
title @s title {text:"FALLEN",color:"dark_red"}
title @s subtitle {text:"You have been expelled from the castle.",color:"gray"}

# Sound (palette: defeat power-down, was wither.death)
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.beacon.deactivate master @s ~ ~ ~ 0.5 0.6

# Action-bar message (§1 self ping)
data modify storage evercraft:notify stage.c set value [{text:"The castle has consumed your strength... (-30 levels)",color:"red"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit

# Update record (per-party)
$scoreboard players operation @s ic.record > #ic_floor.$(pid) ec.var

# Announce to other party players (§5b direct render — names the fallen player @s, bypasses queue)
# (Wave 2, 2026-06-10: castle fallen echo — whoami-baked, 10s TTL.)
function evercraft:util/notify/whoami
data modify storage evercraft:notify stage.c set value [{text:"",color:"red"},{text:" has fallen!",color:"red"}]
data modify storage evercraft:notify stage.c[0].text set from storage evercraft:notify named.who
scoreboard players set #ndur ec.temp 45
$execute as @a[tag=ic.player,tag=p$(pid),tag=!ic.fallen] run scoreboard players set #nttl ec.temp 200
$execute as @a[tag=ic.player,tag=p$(pid),tag=!ic.fallen] run function evercraft:util/notify/emit

# Tag as fallen (prevent re-trigger)
tag @s add ic.fallen

# === TELEPORT TO BED/SPAWN FIRST (so dropped crates land at return point) ===
execute if data entity @s respawn run function evercraft:castle/tp_to_spawn
execute unless data entity @s respawn run spreadplayers ~ ~ 0 1 false @s

# Tally crate coins AFTER teleport
function evercraft:castle/tally_coins

# R6 ordering: clear pt.ic_active BEFORE removing ic.player tag
scoreboard players set @s pt.ic_active 0
tag @s remove ic.player
$tag @s remove p$(pid)
tag @s remove ic.fallen
scoreboard players set @s ic.deaths 0

# Recount remaining party players
$execute store result score #ic_players.$(pid) ec.var if entity @a[tag=ic.player,tag=p$(pid)]

# If no party players remain, fail the castle
$execute unless entity @a[tag=ic.player,tag=p$(pid)] run function evercraft:castle/fail with storage evercraft:_shared cart
