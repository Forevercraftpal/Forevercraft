# Wiring Audit B (2026-05-29) W7: Try to convert one mob into a Furia (per-party MACRO).
# Called with storage evercraft:_shared cart for $(pid). 25% chance per wave (floor 5+).

# Roll 1-100, pass on 1-25
$execute store result score #ic_furia_roll.$(pid) ec.var run random value 1..100
$execute unless score #ic_furia_roll.$(pid) ec.var matches 1..25 run return 0

# Pick one random non-boss mob from THIS party's wave
$execute as @e[tag=ic.mob,tag=p$(pid),tag=!ic.boss,tag=!ic.furia,tag=!ic.patron,sort=random,limit=1] run function evercraft:castle/convert_furia with storage evercraft:_shared cart
