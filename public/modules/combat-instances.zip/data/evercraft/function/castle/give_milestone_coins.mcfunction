# Infinite Castle — Give milestone coins (macro)
# Args: coins (amount), floor (floor number)

$scoreboard players add @s ec.coins $(coins)
$scoreboard players add #rm_coins ec.var $(coins)
$data modify storage evercraft:notify stage.c set value [{text:"Floor $(floor) Milestone! ",color:"gold",bold:true},{text:"+$(coins) Forever Coins",color:"yellow"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.experience_orb.pickup player @s ~ ~ ~ 0.5 1.5
