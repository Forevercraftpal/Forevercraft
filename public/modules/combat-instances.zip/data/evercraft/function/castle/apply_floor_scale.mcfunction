# Wiring Audit B (2026-05-29) W7: Infinite Castle — Apply Floor Scaling (macro).
# Macro args: pid, floor_hp, floor_dmg. Scaled mobs filtered by p<pid>.
$execute as @e[tag=ic.mob,tag=p$(pid),tag=!ic.scaled] run attribute @s minecraft:max_health modifier add ic_floor_hp $(floor_hp) add_multiplied_base
$execute as @e[tag=ic.mob,tag=p$(pid),tag=!ic.scaled] run attribute @s minecraft:attack_damage modifier add ic_floor_dmg $(floor_dmg) add_multiplied_base
