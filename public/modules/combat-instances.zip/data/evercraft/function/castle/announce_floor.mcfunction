# Wiring Audit B (2026-05-29) W7: Infinite Castle — Announce Floor (macro).
# Macro args: pid, floor. Called with storage evercraft:_shared cart.
$title @a[tag=ic.player,tag=p$(pid)] times 10 40 20
$title @a[tag=ic.player,tag=p$(pid)] title [{text:"Floor $(floor)",color:"red",bold:true}]
$title @a[tag=ic.player,tag=p$(pid)] subtitle [{text:"Prepare yourself...",color:"dark_red"}]
