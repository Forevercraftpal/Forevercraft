# Infinite Castle — Tally Summary Line (macro)
# Args: tier (display name), color
# Reads count from storage evercraft:castle tally.count

$data modify storage evercraft:notify stage.c set value [{text:"$(tier)",color:"$(color)"},{text:" x",color:"gray"},{storage:"evercraft:castle",nbt:"tally.count",color:"$(color)"}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit
