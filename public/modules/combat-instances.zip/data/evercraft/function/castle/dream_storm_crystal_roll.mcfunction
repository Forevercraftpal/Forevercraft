# Wiring Audit B (2026-05-29) W7: Dream Storm Crystal Drop Roll (per-party MACRO).
# Called as @a[tag=ic.player,tag=p$(pid)] from floor_complete.
# 1% chance per player per floor clear.

# Roll 1-100, crystal drops on 1 (per-party scratch)
$execute store result score #ic_crystal_roll.$(pid) ec.var run random value 1..100
$execute if score #ic_crystal_roll.$(pid) ec.var matches 1 at @s run function evercraft:castle/give_dream_storm_crystal with storage evercraft:_shared cart
