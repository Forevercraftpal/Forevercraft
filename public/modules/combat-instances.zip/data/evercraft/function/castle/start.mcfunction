# Wiring Audit B (2026-05-29) W7: Infinite Castle — Start (entry gate).
# Called from dungeon/start when not at a structure.
# Run as: player who consumed the dungeon key. Per-party gates check pt.ic_active + pt.dg_active.

# Per-party gate: castle already active for THIS player's party (pt.ic_active=1)
# Inv-full guard: drop at the player's feet rather than void on a full inventory.
execute store result score #inv_full ec.var run function evercraft:util/check_inv_full
execute if score @s pt.ic_active matches 1 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:dungeon/key
execute if score @s pt.ic_active matches 1 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:dungeon/key
data modify storage evercraft:notify stage.c set value [{text:"An Infinite Castle run is already in progress for your party! Key returned.",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute if score @s pt.ic_active matches 1 run function evercraft:util/notify/emit
execute if score @s pt.ic_active matches 1 run return 0

# Symmetric block (Joseph Q9 — Audit B): dungeon active for this party blocks castle start
execute if score @s pt.dg_active matches 1 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:dungeon/key
execute if score @s pt.dg_active matches 1 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:dungeon/key
data modify storage evercraft:notify stage.c set value [{text:"A dungeon is in progress for your party! End it first. Key returned.",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute if score @s pt.dg_active matches 1 run function evercraft:util/notify/emit
execute if score @s pt.dg_active matches 1 run return 0

# Daily limit check (3 runs per day) — reset if new day
execute store result score #current_day ec.temp run time query minecraft:day repetition
execute unless score @s ic.last_day = #current_day ec.temp run scoreboard players set @s ic.today 0
scoreboard players operation @s ic.last_day = #current_day ec.temp
execute if score @s ic.today matches 3.. if score #inv_full ec.var matches 0 run loot give @s loot evercraft:dungeon/key
execute if score @s ic.today matches 3.. at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:dungeon/key
data modify storage evercraft:notify stage.c set value [{text:"You've reached your daily castle limit (3/3)! Key returned.",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute if score @s ic.today matches 3.. run function evercraft:util/notify/emit
execute if score @s ic.today matches 3.. run return 0

# Check if player is in a GUI menu
execute if entity @s[tag=Adv.InMenu] if score #inv_full ec.var matches 0 run loot give @s loot evercraft:dungeon/key
execute if entity @s[tag=Adv.InMenu] at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:dungeon/key
data modify storage evercraft:notify stage.c set value [{text:"Close your menu first! Key returned.",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute if entity @s[tag=Adv.InMenu] run function evercraft:util/notify/emit
execute if entity @s[tag=Adv.InMenu] run return 0
execute if entity @s[tag=IC.InMenu] if score #inv_full ec.var matches 0 run loot give @s loot evercraft:dungeon/key
execute if entity @s[tag=IC.InMenu] at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:dungeon/key
data modify storage evercraft:notify stage.c set value [{text:"Close your menu first! Key returned.",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute if entity @s[tag=IC.InMenu] run function evercraft:util/notify/emit
execute if entity @s[tag=IC.InMenu] run return 0

# Return the 1 key consumed by advancement — begin.mcfunction will consume the correct amount
execute if score #inv_full ec.var matches 0 run loot give @s loot evercraft:dungeon/key
execute if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:dungeon/key

# Open the continue/restart menu
execute at @s run function evercraft:castle/menu/open
