# Wiring Audit B (2026-05-29) W7: Milestone Rewards (per-party MACRO).
# Called from floor_complete every 10 floors with storage cart for $(pid).

# Per-player reward distribution (per-party)
$execute as @a[tag=ic.player,tag=p$(pid)] at @s run function evercraft:castle/reward_milestone_player with storage evercraft:_shared cart
