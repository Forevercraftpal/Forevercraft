# Wiring Audit B (2026-05-29) W7: Infinite Castle — HUD stage (per-party MACRO).
# Called with storage evercraft:_shared cart for $(pid). Stage per-party hud fields,
# dispatch to hud_display macro. 10Hz throttle handled by caller (tick_active).

$execute store result storage evercraft:_shared cart.floor int 1 run scoreboard players get #ic_floor.$(pid) ec.var
$execute store result storage evercraft:_shared cart.wave int 1 run scoreboard players get #ic_wave.$(pid) ec.var
$execute store result storage evercraft:_shared cart.mobs int 1 run scoreboard players get #ic_mobs.$(pid) ec.var

function evercraft:castle/hud_display with storage evercraft:_shared cart
