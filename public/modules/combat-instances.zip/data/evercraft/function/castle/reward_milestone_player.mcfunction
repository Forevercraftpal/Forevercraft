# Wiring Audit B (2026-05-29) W7: Milestone Reward Per Player (per-party MACRO).
# Called as @s ic.player at player position with storage cart for $(pid).
# Floor / 10 * 50 forever coins.

# Calculate coin reward: floor / 10 * 50 (per-party)
$scoreboard players operation #ic_coins.$(pid) ec.var = #ic_floor.$(pid) ec.var
$scoreboard players operation #ic_coins.$(pid) ec.var /= #10 ec.const
$scoreboard players operation #ic_coins.$(pid) ec.var *= #50 ec.const

# Stage milestone data to cart for give_milestone_coins macro
$execute store result storage evercraft:_shared cart.coins int 1 run scoreboard players get #ic_coins.$(pid) ec.var
$execute store result storage evercraft:_shared cart.floor int 1 run scoreboard players get #ic_floor.$(pid) ec.var
function evercraft:castle/give_milestone_coins with storage evercraft:_shared cart

# Victory sound
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.player.levelup master @s ~ ~ ~ 0.8 1.0
