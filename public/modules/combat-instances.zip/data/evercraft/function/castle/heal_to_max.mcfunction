# Wiring Audit B (2026-05-29) W7: Heal single entity to max HP (per-party MACRO).
# Called with storage evercraft:_shared cart for $(pid). @s is the entity to heal.
# Per-party storage path avoids cross-party race on shared temp.max_hp.

$execute store result storage evercraft:castle party_$(pid).temp.max_hp float 1 run attribute @s max_health get
$data modify entity @s Health set from storage evercraft:castle party_$(pid).temp.max_hp
