# Infinite Castle — Arena build offset (per-party MACRO).
# Called with storage evercraft:_shared cart for $(pid). Stores cart.offx / cart.offz (block
# deltas) for the begin_inner / advance_floor `positioned ~$(offx) ~172 ~$(offz)` build base.
#
# REVERTED 2026-06-20 to offset 0 (build DIRECTLY overhead, in the player's own column).
# ----------------------------------------------------------------------------------------
# Wiring Audit #45 FIX 1 (2026-06-06) shifted each arena into a per-party 256-block grid cell
# (cell=pid%256; offx=col*256; offz=row*256) to stop concurrent parties overlapping. But that
# moved the build 256+ blocks horizontally — into chunks the player's loading ticket never
# covers (solos land at offset 256,256). The fill/setblock/$summon marker silently no-op in the
# unloaded cell → no ic.center marker → no teleport-in, and the mobs that DO spawn are stranded
# off in unloaded space (the "stuck at floor N wave 1/5 forever" bug). A forceload band was tried
# but forceload's same-tick load is not reliable. Offset 0 keeps the arena, ic.return, and the
# player all in ONE loaded column — the known-good pre-Audit-#45 behavior.
#
# Concurrency trade-off: two parties whose starters stand within ~41 blocks horizontally while
# both running the castle could overlap arenas. Rare in practice (castle runners are spread out).
# If it ever bites, the correct fix is to TP the player up FIRST (force-loading the cell via the
# player ticket) and build around them — NOT to reintroduce a horizontal offset into unloaded
# chunks. See [[project_forevercraft_castle_arena_forceload]].
data modify storage evercraft:_shared cart.offx set value 0
data modify storage evercraft:_shared cart.offz set value 0
