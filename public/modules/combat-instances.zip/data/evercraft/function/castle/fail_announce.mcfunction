# Wiring Audit B (2026-05-29) W7: Infinite Castle — Fail Announcement (macro).
# Macro args: pid, floor. Server-wide announce (tellraw @a — fall is news, no party filter).
$data modify storage evercraft:notify stage.c set value [{text:"The castle claims its victims on Floor $(floor).",color:"red"}]
scoreboard players set #ndur ec.temp 50
execute as @a run function evercraft:util/notify/emit
