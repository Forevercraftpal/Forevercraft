# Spirit Raids — Defeat Exit
# Called when all players die or timer expires

# Defeat title
title @a[tag=rd.player] times 10 60 20
title @a[tag=rd.player] title {text:"RAID FAILED",color:"dark_red"}
title @a[tag=rd.player] subtitle {text:"The darkness claims another...",color:"red"}

# Shame message (§5 staged fan-out — static broadcast, forerunner stripped)
data modify storage evercraft:notify stage.c set value [{text:"The raid party has fallen.",color:"dark_gray",italic:true}]
scoreboard players set #ndur ec.temp 50
execute as @a run function evercraft:util/notify/emit

# Defeat sounds
execute as @a[tag=rd.player,scores={ec.fx_snd=1..}] at @s run playsound minecraft:entity.wither.death master @s ~ ~ ~ 0.5 0.5
execute as @a[tag=rd.player,scores={ec.fx_snd=1..}] at @s run playsound minecraft:entity.lightning_bolt.thunder master @s ~ ~ ~ 0.8 0.3

# Remove ALL experience levels (harsh penalty)
experience set @a[tag=rd.player] 0 levels
experience set @a[tag=rd.player] 0 points
data modify storage evercraft:notify stage.c set value [{text:"All experience levels lost.",color:"red",italic:true}]
scoreboard players set #ndur ec.temp 45
execute as @a[tag=rd.player] run function evercraft:util/notify/emit

# Teleport to bed spawn or world spawn (NOT original position — "sent home")
execute as @a[tag=rd.player] in minecraft:overworld run function evercraft:raids/send_home

# Gear is kept (no item loss)

# Clean up raid room
function evercraft:raids/room/cleanup
