# Spirit Raids — Victory Exit
# Called on boss death or voluntary evacuation after clearing floors

# Victory title
title @a[tag=rd.player] times 10 60 20
title @a[tag=rd.player] title {text:"RAID COMPLETE!",color:"gold"}
title @a[tag=rd.player] subtitle {text:"Victory is yours!",color:"yellow"}

# Victory announcement (§5b direct render — names the raid party; selector resolves once)
# (AB-3, 2026-06-10: roster broadcast rides the queue — names ", "-joined via who_begin/who_add,
# protected frame, 30s TTL. Replaces the earlier deliberate §5b raw keep.)
function evercraft:util/notify/who_begin
execute as @a[tag=rd.player] run function evercraft:util/notify/who_add
data modify storage evercraft:notify stage.c set value [{text:"❖ ",color:"gold"},{text:""},{text:" has conquered the Spirit Raid! ❖",color:"gold"}]
data modify storage evercraft:notify stage.c[1].text set from storage evercraft:notify named.who
scoreboard players set #ndur ec.temp 50
scoreboard players set #nttl ec.temp 600
execute as @a run function evercraft:util/notify/emit_keep

# Victory sounds
execute as @a[tag=rd.player,scores={ec.fx_snd=1..}] at @s run playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 1 1
execute as @a[tag=rd.player,scores={ec.fx_snd=1..}] at @s run playsound minecraft:entity.firework_rocket.blast master @s ~ ~ ~ 1 1
execute as @a[tag=rd.player,scores={ec.fx_snd=1..}] at @s run playsound minecraft:entity.firework_rocket.twinkle master @s ~ ~ ~ 1 0.8

# Victory particles
execute at @e[type=marker,tag=rd.center,limit=1] run particle minecraft:firework ~ ~2 ~ 3 2 3 0.1 200 force
execute at @e[type=marker,tag=rd.center,limit=1] run particle minecraft:totem_of_undying ~ ~2 ~ 2 2 2 0.5 150 force

# === RAID REWARDS ===
# Raid clear credit: +1 per victorious player (canonical one-writer for ach.raids_done).
# Lives ONLY here — exit_win is the sole victory exit (boss death → on_death → exit_win).
# Evacuation (exit_evacuate) is deliberately NOT a clear. Feeds DR (5 pts each), the
# profile "Raid Clears" row, and personal milestones p27/s15.
execute as @a[tag=rd.player] run scoreboard players add @s ach.raids_done 1
# Wayfarer Track: cross-source bonus XP (milestone credit on top of dr.points)
execute as @a[tag=rd.player] run scoreboard players add @s ec.wf_bonus 40

# Exquisite artifact for all raid players (Audit #6: inv-full hygiene)
# Per-player wrapper makes the check + give + drop atomic per player (no #rd_inv_full race).
execute as @a[tag=rd.player] at @s run function evercraft:raids/give_exquisite_one

# Coin reward: 25 per player
execute as @a[tag=rd.player] run scoreboard players add @s ec.coins 25
execute as @a[tag=rd.player] run scoreboard players add #rm_coins ec.var 25
data modify storage evercraft:notify stage.c set value [{text:"★ ",color:"#E0B0FF"},{text:"+25 Forever Coins",color:"#E0B0FF",bold:true},{text:" — Raid Complete!",color:"gold"},{text:" ★",color:"#E0B0FF"}]
scoreboard players set #ndur ec.temp 45
execute as @a[tag=rd.player] run function evercraft:util/notify/emit
execute as @a[tag=rd.player,scores={ec.fx_snd=1..}] run playsound minecraft:entity.experience_orb.pickup player @s ~ ~ ~ 0.5 1.5
execute as @a[tag=rd.player] if score @s ec.guild_id matches 1.. run function evercraft:guild/contribution/add {amount:125}

# Advantage tree credit (Joseph 2026-05-29): a full Spirit Raid victory credits all 15 trees
# (factor 3 — endgame-tier, ~15% of a level-1 requirement per tree, scaling down with level).
scoreboard players set #adv_credit_num ec.var 3
execute as @a[tag=rd.player] run function evercraft:advantage/grant_tree_credit

# Story Mode: raid completion hooks (Ch29, Ch39, Ch48)
execute as @a[tag=rd.player,scores={sm.mode=1,sm.chapter=29}] run function evercraft:story/quest/check_progress
execute as @a[tag=rd.player,scores={sm.mode=1,sm.chapter=39}] run function evercraft:story/quest/check_progress
execute as @a[tag=rd.player,scores={sm.mode=1,sm.chapter=48}] run function evercraft:story/quest/check_progress

# Teleport ALL raid players back to saved positions
execute as @a[tag=rd.player] run function evercraft:raids/restore_position

# Clean up raid room
function evercraft:raids/room/cleanup
