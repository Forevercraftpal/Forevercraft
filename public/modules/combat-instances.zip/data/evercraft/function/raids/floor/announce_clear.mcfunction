# Spirit Raids — Floor Cleared Announcement (macro)
# §5 staged fan-out — static broadcast, forerunner stripped
$data modify storage evercraft:notify stage.c set value [{text:"Floor $(current) Cleared!",color:"gold",bold:true}]
scoreboard players set #ndur ec.temp 50
execute as @a[tag=rd.player] run function evercraft:util/notify/emit
execute as @a[tag=rd.player,scores={ec.fx_snd=1..}] at @s run playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 0.8 1.0
