# Spirit Raids — Announce Floor (macro)
# $() receives floor.current

title @a[tag=rd.player] times 5 40 10
$title @a[tag=rd.player] title {text:"Raid Floor $(current)",color:"dark_red",bold:true}
title @a[tag=rd.player] subtitle {text:"Prepare for combat...",color:"red"}
# §5 staged fan-out — static broadcast, forerunner stripped
$data modify storage evercraft:notify stage.c set value [{text:"Floor $(current)",color:"red"},{text:" — Enemies incoming!",color:"gray"}]
scoreboard players set #ndur ec.temp 50
execute as @a[tag=rd.player] run function evercraft:util/notify/emit
