# Per-player wrapper for the floor-8 ornate-artifact bonus.
# Avoids #rd_inv_full ec.var racing across concurrent rd.player rewardees.
# Run as @s = the player being rewarded, at @s.
execute store result score #rd_inv_full ec.var run function evercraft:util/check_inv_full
execute if score #rd_inv_full ec.var matches 0 run loot give @s loot evercraft:artifacts/ornate/main
execute if score #rd_inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:artifacts/ornate/main
execute if score #rd_inv_full ec.var matches 1 as @e[type=item,nbt={Item:{Age:0s}},distance=..2,sort=nearest,limit=1] run data merge entity @s {Age:2400s}
data modify storage evercraft:notify stage.c set value [{text:"★ ",color:"dark_purple"},{text:"Ornate Artifact",color:"dark_purple",bold:true},{text:" — Floor 8 Bonus!",color:"gray"},{text:" ★",color:"dark_purple"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Inventory full! Crate dropped at your feet.",color:"yellow"}]
scoreboard players set #ndur ec.temp 45
execute if score #rd_inv_full ec.var matches 1 run function evercraft:util/notify/emit
