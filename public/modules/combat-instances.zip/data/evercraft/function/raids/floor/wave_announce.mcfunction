# Spirit Raids — Wave Announcement (macro)
# §5 staged fan-out — static broadcast, forerunner stripped
$data modify storage evercraft:notify stage.c set value [{text:"Wave $(current)",color:"red",bold:true}]
scoreboard players set #ndur ec.temp 50
execute as @a[tag=rd.player] run function evercraft:util/notify/emit
