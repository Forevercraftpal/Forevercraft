# Spirit Raids — Send Player Home (Loss)
# Called as each player, already in overworld context
# Teleports to bed spawn if available, otherwise world spawn

# Try to teleport to bed spawn using spreadplayers as fallback
# 1.21.5+: SpawnX/Y/Z replaced by respawn.pos int array
execute if data entity @s respawn.pos run function evercraft:raids/send_to_bed
execute unless data entity @s respawn.pos run tp @s 0 100 0
execute unless data entity @s respawn.pos run spreadplayers ~ ~ 0 5 false @s
