# Per-player wrapper for the exquisite-artifact reward at raid victory.
# Avoids #rd_inv_full ec.var racing across concurrent rd.player rewardees.
# Run as @s = the player being rewarded, at @s.
execute store result score #rd_inv_full ec.var run function evercraft:util/check_inv_full
execute if score #rd_inv_full ec.var matches 0 run loot give @s loot evercraft:artifacts/exquisite/main
execute if score #rd_inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:artifacts/exquisite/main
execute if score #rd_inv_full ec.var matches 1 as @e[type=item,nbt={Item:{Age:0s}},distance=..2,sort=nearest,limit=1] run data merge entity @s {Age:2400s}
data modify storage evercraft:notify stage.c set value [{text:"★ ",color:"gold"},{text:"Exquisite Artifact",color:"gold",bold:true},{text:" — Raid Victory!",color:"gray"},{text:" ★",color:"gold"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Inventory full! Your exquisite artifact was dropped at your feet.",color:"yellow"}]
scoreboard players set #ndur ec.temp 45
execute if score #rd_inv_full ec.var matches 1 run function evercraft:util/notify/emit
