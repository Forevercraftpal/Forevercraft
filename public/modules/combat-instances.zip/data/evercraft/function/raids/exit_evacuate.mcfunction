# Spirit Raids — Evacuate Exit (Audit #6 Q3 — curtailed rewards)
# Called from vote/process_vote when the party VOTES to evacuate (context 2 floor vote)
# or RETREAT before the boss fight (context 3 boss vote).
# Player keeps coins + crates they already earned across floors; no exit_win full rewards.

# Quiet farewell (§5 staged fan-out — static broadcast, forerunner stripped)
data modify storage evercraft:notify stage.c set value [{text:"Raid evacuated — you keep what you earned.",color:"gold"}]
scoreboard players set #ndur ec.temp 50
execute as @a[tag=rd.player] run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"No exquisite artifact, no victory bonus — this is the safe path.",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 40
execute as @a[tag=rd.player] run function evercraft:util/notify/emit

# Soft completion title
title @a[tag=rd.player] times 10 60 20
title @a[tag=rd.player] title {text:"RAID EVACUATED",color:"gold"}
title @a[tag=rd.player] subtitle {text:"You return with what you earned",color:"yellow"}

# Soft chime (NOT the full firework storm)
execute as @a[tag=rd.player,scores={ec.fx_snd=1..}] at @s run playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 1.0 0.7

# Teleport ALL raid players back to saved positions
execute as @a[tag=rd.player] run function evercraft:raids/restore_position

# Clean up raid room (kills entities + strips rd.player tag + resets state)
function evercraft:raids/room/cleanup
