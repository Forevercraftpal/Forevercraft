# Spirit Raids — Death Intercept
# Called from main tick when a raid player dies (ec.tomb_death=1)
# Respawns player in raid room instead of normal tomb system

# Totem pop visual (death intercepted)
particle minecraft:totem_of_undying ~ ~1 ~ 0.5 1 0.5 0.5 50
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:item.totem.use master @s ~ ~ ~ 1 1

# Increment death counter
scoreboard players add @s ec.rd_deaths 1

# Boss recap deaths (only counts deaths during an active boss fight)
execute if score @s br.active matches 1.. run scoreboard players add @s br.deaths 1

# Audit #6 W8 — reset ec.tomb_death after handling so tomb/ system doesn't double-count per tick
scoreboard players set @s ec.tomb_death 0

# Respawn in raid room
execute in minecraft:overworld run tp @s 0 401 0

# Show death message (§5b direct render — names @s the fallen player; resolves once in actor context)
function evercraft:util/notify/whoami
data modify storage evercraft:notify stage.c set value [{text:"✗ ",color:"dark_red"},{text:""},{text:" has fallen! ✗",color:"red"}]
data modify storage evercraft:notify stage.c[1].text set from storage evercraft:notify named.who
scoreboard players set #ndur ec.temp 50
execute as @a[tag=rd.player] run scoreboard players set #nttl ec.temp 600
execute as @a[tag=rd.player] run function evercraft:util/notify/emit_keep
execute at @s run playsound minecraft:entity.wither.hurt master @a[tag=rd.player,scores={ec.fx_snd=1..}] ~ ~ ~ 0.5 0.8

# Check if ALL raid players are now dead (everyone has died)
# For raids, we allow respawning — total wipe only if no one is alive
# The tick_active disconnect check handles "no players left" scenario
