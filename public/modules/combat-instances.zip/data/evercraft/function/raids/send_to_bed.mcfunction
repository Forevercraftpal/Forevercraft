# Spirit Raids — Send to Bed Spawn
# Called as the player who has respawn.pos data
# 1.21.5+: SpawnX/Y/Z replaced by respawn.pos [I;x,y,z]

execute store result storage evercraft:raids bed.x int 1 run data get entity @s respawn.pos[0]
execute store result storage evercraft:raids bed.y int 1 run data get entity @s respawn.pos[1]
execute store result storage evercraft:raids bed.z int 1 run data get entity @s respawn.pos[2]
function evercraft:raids/do_teleport with storage evercraft:raids bed
