# Gilded Tyrant — Gold Bomb Impact
# Called per tick to check if bomb armor stands have landed (on ground = no gravity drift)
# Armor stands with NoGravity:0b fall, then land and stop — detect via OnGround:1b
# OPT: Tag landed bombs once, then operate on tag (was 4 identical NBT scans → 1)

# Tag bombs that have landed (single NBT scan)
execute as @e[type=armor_stand,tag=ec.rd_gt_bomb,nbt={OnGround:1b}] run tag @s add ec.bomb_landed

# Falling particles while in air (only non-landed bombs)
execute as @e[type=armor_stand,tag=ec.rd_gt_bomb,tag=!ec.bomb_landed] at @s run particle minecraft:dust{color:[1.0,0.84,0.0],scale:1.5} ~ ~ ~ 0.2 0.2 0.2 0 2

# On landing: explode and kill the bomb
execute as @e[type=armor_stand,tag=ec.bomb_landed] at @s as @a[tag=ec.rd_participant,distance=..3] run damage @s 6 minecraft:falling_block
execute as @e[type=armor_stand,tag=ec.bomb_landed] at @s run particle minecraft:dust{color:[1.0,0.84,0.0],scale:2.0} ~ ~ ~ 2 0.5 2 0.1 8
execute as @e[type=armor_stand,tag=ec.bomb_landed] at @s run playsound minecraft:entity.generic.explode hostile @a[tag=ec.rd_participant,distance=..10,scores={ec.fx_snd=1..}] ~ ~ ~ 0.8 0.8
kill @e[type=armor_stand,tag=ec.bomb_landed]
