# The Crimson Bulwark — Summon Elite Guards
# 2 armored vindicators

execute as @e[type=vindicator,tag=ec.rd_boss,limit=1] at @s run summon vindicator ~3 ~ ~0 {Tags:["ec.rd_minion","ec.rd_cb_guard"],PersistenceRequired:1b,equipment:{head:{id:"minecraft:iron_helmet",count:1},chest:{id:"minecraft:iron_chestplate",count:1}}}
execute as @e[type=vindicator,tag=ec.rd_boss,limit=1] at @s run summon vindicator ~-3 ~ ~0 {Tags:["ec.rd_minion","ec.rd_cb_guard"],PersistenceRequired:1b,equipment:{head:{id:"minecraft:iron_helmet",count:1},chest:{id:"minecraft:iron_chestplate",count:1}}}

# VFX
execute as @e[type=vindicator,tag=ec.rd_boss,limit=1] at @s run particle minecraft:dust{color:[0.6,0.1,0.1],scale:1.0} ~ ~1 ~ 3 1 3 0 8
execute as @e[type=vindicator,tag=ec.rd_boss,limit=1] at @s run playsound minecraft:entity.vindicator.ambient master @a[tag=ec.rd_participant,scores={ec.fx_snd=1..}] ~ ~ ~ 1.5 0.8

# §5 staged fan-out — combat ping, forerunner stripped
data modify storage evercraft:notify stage.c set value [{text:"Elite castle guards join the fight!",color:"yellow"}]
scoreboard players set #ndur ec.temp 45
execute as @a[tag=ec.rd_participant] run function evercraft:util/notify/emit
