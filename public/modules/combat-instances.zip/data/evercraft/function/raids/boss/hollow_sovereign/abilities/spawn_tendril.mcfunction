# Hollow Sovereign — Spawn Sculk Tendril
# Spawns an armor stand tendril marker at a random position near the boss

# Spawn at random offset from boss
execute as @e[type=#evercraft:aoe_targets,tag=ec.rd_boss,limit=1] at @s run summon armor_stand ~-3 ~ ~2 {Tags:["ec.rd_tendril","ec.rd_minion"],Small:1b,Invisible:1b,Invulnerable:1b,Marker:1b,NoGravity:1b,CustomName:{text:"Sculk Tendril",color:"dark_aqua"},CustomNameVisible:1b}
execute as @e[type=#evercraft:aoe_targets,tag=ec.rd_boss,limit=1] at @s run summon armor_stand ~3 ~ ~-2 {Tags:["ec.rd_tendril","ec.rd_minion"],Small:1b,Invisible:1b,Invulnerable:1b,Marker:1b,NoGravity:1b,CustomName:{text:"Sculk Tendril",color:"dark_aqua"},CustomNameVisible:1b}

# Spawn VFX at tendril locations
execute as @e[tag=ec.rd_tendril] at @s run particle minecraft:sculk_soul ~ ~0.5 ~ 0.5 0.5 0.5 0.05 8
execute as @e[tag=ec.rd_tendril] at @s run playsound minecraft:block.sculk.spread hostile @a[tag=ec.rd_participant,distance=..20,scores={ec.fx_snd=1..}] ~ ~ ~ 0.8 0.5

# Cap at 8 tendrils max
execute store result score #rd_temp ec.var if entity @e[tag=ec.rd_tendril]
execute if score #rd_temp ec.var matches 9.. as @e[tag=ec.rd_tendril,limit=1,sort=random] run kill @s

# Announcement (§5 staged fan-out — forerunner stripped)
data modify storage evercraft:notify stage.c set value [{text:"Sculk tendrils erupt from the ground!",color:"dark_aqua",italic:true}]
scoreboard players set #ndur ec.temp 45
# (Council Upgrade 2026-06-10, balance MC-1: telegraph promoted emit_now → emit_crit_telegraph (40t TTL) + flash subtitle copy — Off players keep combat-safety warnings, a buried telegraph dies instead of firing post-hit.)
data modify storage evercraft:notify flash.c set from storage evercraft:notify stage.c
execute as @a[tag=ec.rd_participant] run function evercraft:util/notify/emit_crit_telegraph
execute as @a[tag=ec.rd_participant] run function evercraft:util/notify/flash
