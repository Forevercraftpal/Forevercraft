# Grand Illusionist — Death (boss defeated!)
# Drop loot to all participants

# Kill remaining minions
kill @e[tag=ec.rd_gi_fake]
kill @e[tag=ec.rd_gi_vex]
kill @e[tag=ec.rd_gi_totem]
kill @e[tag=ec.rd_gi_ravager]

# Boss-specific death dialogue (§5 staged fan-out — static broadcast)
data modify storage evercraft:notify stage.c set value [{text:"\"It was all... an illusion... even I... was never real...\"",color:"red",italic:true}]
scoreboard players set #ndur ec.temp 50
execute as @a[tag=ec.rd_participant] run function evercraft:util/notify/emit

# Drop loot to each participant
execute as @a[tag=ec.rd_participant] at @s run function evercraft:raids/boss/grand_illusionist/loot

# Audit #6: rd.kills had 0 readers pack-wide — writer archived per W7 dead-scoreboard sweep.
