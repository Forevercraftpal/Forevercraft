# Gilded Tyrant — Death (boss defeated!)
# Drop loot to all participants

# Kill remaining piglins
kill @e[tag=ec.rd_gt_add]
kill @e[tag=ec.rd_gt_bomb]

# Boss-specific death dialogue (§5 staged fan-out — static broadcast)
data modify storage evercraft:notify stage.c set value [{text:"\"My gold... my throne... it was all... for nothing...\"",color:"gold",italic:true}]
scoreboard players set #ndur ec.temp 50
execute as @a[tag=ec.rd_participant] run function evercraft:util/notify/emit

# Audit #6: rd.gold → bonus Forever Coins 1:1 (cap 100). Best-guess minimal interpretation; see Q2 caveat in CLOSED.md.
execute as @a[tag=ec.rd_participant,scores={rd.gold=1..}] run scoreboard players operation @s ec.coins += @s rd.gold
execute as @a[tag=ec.rd_participant,scores={rd.gold=1..}] run scoreboard players operation #rm_coins ec.var += @s rd.gold
data modify storage evercraft:notify stage.c set value [{text:"★ ",color:"gold"},{text:"Gold shards collected: ",color:"yellow"},{score:{name:"@s",objective:"rd.gold"},color:"gold",bold:true},{text:" → +Forever Coins! ★",color:"gold"}]
scoreboard players set #ndur ec.temp 45
execute as @a[tag=ec.rd_participant,scores={rd.gold=1..}] run function evercraft:util/notify/emit

# Drop loot to each participant
execute as @a[tag=ec.rd_participant] at @s run function evercraft:raids/boss/gilded_tyrant/loot
