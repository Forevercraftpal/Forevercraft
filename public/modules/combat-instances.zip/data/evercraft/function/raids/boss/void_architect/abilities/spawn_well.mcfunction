# Void Architect — Spawn Gravity Well at random player position

# Spawn at a random participant's position
execute as @a[tag=ec.rd_participant,sort=random,limit=1] at @s run summon armor_stand ~ ~ ~ {Tags:["ec.rd_well","ec.rd_minion"],Small:1b,Invisible:1b,Invulnerable:1b,Marker:1b,NoGravity:1b,CustomName:{text:"Gravity Well",color:"dark_purple"},CustomNameVisible:1b}

# VFX
execute as @a[tag=ec.rd_participant,sort=random,limit=1] at @s run particle minecraft:reverse_portal ~ ~0.5 ~ 1 0.5 1 0.1 15
execute as @a[tag=ec.rd_participant,sort=random,limit=1] at @s run playsound minecraft:block.respawn_anchor.charge hostile @a[tag=ec.rd_participant,scores={ec.fx_snd=1..}] ~ ~ ~ 0.8 0.4

# Warning (§5 staged fan-out — forerunner stripped)
data modify storage evercraft:notify stage.c set value [{text:"A gravity well forms!",color:"dark_purple",italic:true}]
scoreboard players set #ndur ec.temp 45
# (Council Upgrade 2026-06-10, balance MC-1: telegraph promoted emit_now → emit_crit_telegraph (40t TTL) + flash subtitle copy — Off players keep combat-safety warnings, a buried telegraph dies instead of firing post-hit.)
data modify storage evercraft:notify flash.c set from storage evercraft:notify stage.c
execute as @a[tag=ec.rd_participant] run function evercraft:util/notify/emit_crit_telegraph
execute as @a[tag=ec.rd_participant] run function evercraft:util/notify/flash

# Cap at 3 wells
execute store result score #rd_temp ec.var if entity @e[tag=ec.rd_well]
execute if score #rd_temp ec.var matches 4.. as @e[tag=ec.rd_well,limit=1,sort=random] run kill @s
