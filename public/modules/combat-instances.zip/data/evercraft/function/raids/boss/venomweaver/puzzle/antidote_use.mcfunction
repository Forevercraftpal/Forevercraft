# The Venomweaver — Antidote Flower Use
# Called as a perch marker entity when clicked

# Clear interaction data
data remove entity @s interaction

# Check if this perch has charges remaining (not empty)
execute if entity @s[tag=ec.rd_vw_empty] run return 0

# Track charges via tag cycling: no tags = 3 remaining, c1 = 2, c2 = 1, c3 = empty
# Use return to prevent cascade
execute if entity @s[tag=ec.rd_vw_c2] run tag @s add ec.rd_vw_empty
execute if entity @s[tag=ec.rd_vw_c1,tag=!ec.rd_vw_c2] run tag @s add ec.rd_vw_c2
execute if entity @s[tag=!ec.rd_vw_c1] run tag @s add ec.rd_vw_c1

# Give poison immunity to nearest participant (10 seconds)
# Audit #6: wire rd.antidote countdown + ec.rd_vw_immune tag (was promise-without-mechanic).
execute at @s as @a[tag=ec.rd_participant,sort=nearest,limit=1,distance=..5] run effect clear @s poison
execute at @s as @a[tag=ec.rd_participant,sort=nearest,limit=1,distance=..5] run scoreboard players set @s rd.antidote 200
execute at @s as @a[tag=ec.rd_participant,sort=nearest,limit=1,distance=..5] run tag @s add ec.rd_vw_immune
execute at @s as @a[tag=ec.rd_participant,sort=nearest,limit=1,distance=..5] run effect give @s resistance 10 4 true

# Announce to the user (§5 staged fan-out — forerunner stripped, distance gate preserved via at @s)
data modify storage evercraft:notify stage.c set value [{text:"Antidote flower consumed! Poison immunity for 10 seconds!",color:"green"}]
scoreboard players set #ndur ec.temp 45
execute at @s as @a[tag=ec.rd_participant,sort=nearest,limit=1,distance=..5] run function evercraft:util/notify/emit

# VFX
execute at @s run particle minecraft:happy_villager ~ ~0 ~ 0.5 0.5 0.5 0.1 8
execute at @s run playsound minecraft:entity.generic.eat master @a[tag=ec.rd_participant,scores={ec.fx_snd=1..}] ~ ~ ~ 1.0 1.2
