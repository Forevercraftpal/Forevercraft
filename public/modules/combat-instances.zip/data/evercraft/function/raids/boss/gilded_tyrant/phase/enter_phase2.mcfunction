# Gilded Tyrant — Enter Phase 2: Gold Bombardment

# Reset cooldowns
scoreboard players set #rd_gt_charge_cd ec.var 0
scoreboard players set #rd_gt_slam_cd ec.var 0
scoreboard players set #rd_gt_add_cd ec.var 0
scoreboard players set #rd_gt_gold_bomb_cd ec.var 0

# Dialogue (§5 staged fan-out — indent stripped)
data modify storage evercraft:notify stage.c set value [{text:"\"You dare scratch my gilded armor?! I will BURY you in gold!\"",color:"yellow",italic:true}]
scoreboard players set #ndur ec.temp 50
execute as @a[tag=ec.rd_participant] run function evercraft:util/notify/emit

# VFX — gold eruption
execute as @e[type=#evercraft:aoe_targets,tag=ec.rd_boss,limit=1] at @s run particle minecraft:lava ~ ~1 ~ 3 2 3 0.5 15
execute as @e[type=#evercraft:aoe_targets,tag=ec.rd_boss,limit=1] at @s run playsound minecraft:entity.piglin_brute.angry hostile @a[tag=ec.rd_participant,scores={ec.fx_snd=1..}] ~ ~ ~ 1.0 0.6
