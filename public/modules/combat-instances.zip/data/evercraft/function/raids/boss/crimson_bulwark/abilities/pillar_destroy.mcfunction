# The Crimson Bulwark — Pillar Destroyed
# Called as the pillar entity at its position

particle minecraft:explosion ~ ~1 ~ 0.5 0.5 0.5 0.3 3
particle minecraft:dust{color:[0.5,0.5,0.5],scale:2.0} ~ ~1 ~ 1 1 1 0 10
playsound minecraft:block.stone.break master @a[tag=ec.rd_participant,scores={ec.fx_snd=1..}] ~ ~ ~ 1.5 0.4

# §5 staged fan-out — combat ping, forerunner stripped
data modify storage evercraft:notify stage.c set value [{text:"A pillar crumbles! Cover lost!",color:"gray"}]
scoreboard players set #ndur ec.temp 45
execute as @a[tag=ec.rd_participant] run function evercraft:util/notify/emit

kill @s
