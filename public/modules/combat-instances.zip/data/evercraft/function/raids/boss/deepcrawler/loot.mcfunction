# The Deepcrawler — Loot Drops
# Called as each participant player, at their position
# Drops: 5% Soulstring (Archer), 100% Stalactite Shard Arrow, 100% Deepcrawler's Eye, 100% Crystallized Depths

# Audit #6 — inv-full hygiene: probe before gives so we can warn + age-extend dropped items
execute store result score #rd_inv_full ec.var run function evercraft:util/check_inv_full

# ── 5% Class Artifact: Soulstring (Archer spirit weapon) ──
scoreboard players set @s ec.temp 0
execute store result score @s ec.temp run random value 1..100
execute if score @s ec.temp matches ..5 run give @s bow[custom_name={text:"Soulstring",color:"gray",italic:false},custom_data={spirit_artifact:"sabrewing",spirit_class:"archer",spirit_tier:1},enchantment_glint_override=true,unbreakable={}] 1
execute if score @s ec.temp matches ..5 run function evercraft:util/notify/whoami
data modify storage evercraft:notify stage.c set value [{text:"★ ",color:"gold"},{text:""},{text:" received ",color:"gray"},{text:"Soulstring",color:"gray",bold:true},{text:"! ★",color:"gold"}]
data modify storage evercraft:notify stage.c[1].text set from storage evercraft:notify named.who
scoreboard players set #ndur ec.temp 50
execute if score @s ec.temp matches ..5 run execute as @a[tag=ec.rd_participant] run scoreboard players set #nttl ec.temp 600
execute if score @s ec.temp matches ..5 run execute as @a[tag=ec.rd_participant] run function evercraft:util/notify/emit_keep
execute if score @s ec.fx_snd matches 1.. if score @s ec.temp matches ..5 run playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 1.0 1.0

# ── 100% Artifact A: Stalactite Shard Arrow ──
give @s arrow[custom_name={text:"Stalactite Shard Arrow",color:"gray",italic:false},custom_data={artifact:"stalactite_shard_arrow",tier:"unique"},lore=[{text:"Arrows pierce through 2 entities",color:"gray",italic:false},{text:"",italic:false},{text:"Unique — The Deepcrawler",color:"dark_gray",italic:false}]] 1

# ── 100% Artifact B: Deepcrawler's Eye ──
give @s ender_eye[custom_name={text:"Deepcrawler's Eye",color:"dark_purple",italic:false},custom_data={artifact:"deepcrawlers_eye",tier:"unique"},lore=[{text:"Night vision in caves + ore highlighting",color:"gray",italic:false},{text:"",italic:false},{text:"Unique — The Deepcrawler",color:"dark_gray",italic:false}]] 1

# ── 100% DR Consumable: Crystallized Depths ──
give @s amethyst_shard[custom_name={text:"Crystallized Depths",color:"light_purple",italic:false},consumable={consume_seconds:0},custom_data={dr_consumable:"crystallized_depths",boss_dr_deepcrawler:1b},lore=[{text:"+1 Dream Rate permanently",color:"green",italic:false},{text:"",italic:false},{text:"Consumed on use",color:"dark_gray",italic:false}]] 1

# Loot VFX
particle minecraft:happy_villager ~ ~1 ~ 0.5 0.5 0.5 0.1 5
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.player.levelup master @s ~ ~ ~ 0.8 1.2

# Audit #6 — inv-full warn + age-extend nearby fresh items
execute if score #rd_inv_full ec.var matches 1 at @s as @e[type=item,nbt={Item:{Age:0s}},distance=..3] run data merge entity @s {Age:2400s}
data modify storage evercraft:notify stage.c set value [{text:"Inventory full! Boss loot dropped at your feet.",color:"yellow"}]
scoreboard players set #ndur ec.temp 45
execute if score #rd_inv_full ec.var matches 1 run function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. if score #rd_inv_full ec.var matches 1 run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 1 0.5
