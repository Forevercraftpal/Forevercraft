# The Eternal Pharaoh — Correct Pillar Hit!
# Boss's true form revealed — 75% damage reduction removed for 10 seconds

# Remove boss armor (reveals true form)
execute as @e[type=husk,tag=ec.rd_boss,limit=1] run attribute @s armor modifier remove evercraft:rd_boss/base

# Schedule armor restore in 10 seconds
schedule function evercraft:raids/boss/eternal_pharaoh/puzzle/glyph_restore 200t

# VFX
execute as @e[type=husk,tag=ec.rd_boss,limit=1] at @s run particle minecraft:end_rod ~ ~1 ~ 1 1 1 0.1 15
execute as @e[type=husk,tag=ec.rd_boss,limit=1] at @s run effect give @s glowing 10 0 true
playsound minecraft:entity.player.levelup master @a[tag=ec.rd_participant,scores={ec.fx_snd=1..}] ~ ~ ~ 1.0 1.5

# §5 staged fan-out — combat ping, forerunner stripped
data modify storage evercraft:notify stage.c set value [{text:"CORRECT! The Pharaoh's true form is revealed! Full damage for 10 seconds!",color:"green",bold:true}]
scoreboard players set #ndur ec.temp 45
execute as @a[tag=ec.rd_participant] run function evercraft:util/notify/emit
