# The Deepcrawler — Ground Slam
# AoE attack: 6-block radius, 12 damage

execute as @e[type=silverfish,tag=ec.rd_boss,limit=1] at @s run execute as @a[tag=ec.rd_participant,distance=..6] run damage @s 12 minecraft:mob_attack by @e[type=silverfish,tag=ec.rd_boss,limit=1]

# VFX: ground impact
execute as @e[type=silverfish,tag=ec.rd_boss,limit=1] at @s run particle minecraft:explosion ~ ~0.5 ~ 3 0.5 3 0.5 4
execute as @e[type=silverfish,tag=ec.rd_boss,limit=1] at @s run particle minecraft:dust{color:[0.5,0.4,0.3],scale:2.5} ~ ~0.5 ~ 6 0.5 6 0 30
execute as @e[type=silverfish,tag=ec.rd_boss,limit=1] at @s run playsound minecraft:entity.warden.sonic_boom master @a[tag=ec.rd_participant,scores={ec.fx_snd=1..}] ~ ~ ~ 1.0 0.5
execute as @e[type=silverfish,tag=ec.rd_boss,limit=1] at @s run playsound minecraft:block.anvil.land master @a[tag=ec.rd_participant,scores={ec.fx_snd=1..}] ~ ~ ~ 2.0 0.3

# §5 staged fan-out — combat ping, forerunner stripped
data modify storage evercraft:notify stage.c set value [{text:"The Deepcrawler SLAMS the ground!",color:"red",bold:true}]
scoreboard players set #ndur ec.temp 45
# (Council Upgrade 2026-06-10, balance MC-1: telegraph promoted emit_now → emit_crit_telegraph (40t TTL) + flash subtitle copy — Off players keep combat-safety warnings, a buried telegraph dies instead of firing post-hit.)
data modify storage evercraft:notify flash.c set from storage evercraft:notify stage.c
execute as @a[tag=ec.rd_participant] run function evercraft:util/notify/emit_crit_telegraph
execute as @a[tag=ec.rd_participant] run function evercraft:util/notify/flash
