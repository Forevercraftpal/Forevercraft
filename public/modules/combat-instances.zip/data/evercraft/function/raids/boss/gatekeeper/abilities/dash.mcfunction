# Gatekeeper — Dash Attack
# Boss dashes 8 blocks toward nearest player, leaving ender particle trail

# Dash in 4 steps (2 blocks each)
execute as @e[type=#evercraft:aoe_targets,tag=ec.rd_boss,limit=1] at @s facing entity @a[tag=ec.rd_participant,sort=nearest,limit=1] feet run tp @s ^ ^ ^2
execute as @e[type=#evercraft:aoe_targets,tag=ec.rd_boss,limit=1] at @s run particle minecraft:portal ~ ~1 ~ 0.2 0.5 0.2 0.5 3
execute as @e[type=#evercraft:aoe_targets,tag=ec.rd_boss,limit=1] at @s facing entity @a[tag=ec.rd_participant,sort=nearest,limit=1] feet run tp @s ^ ^ ^2
execute as @e[type=#evercraft:aoe_targets,tag=ec.rd_boss,limit=1] at @s run particle minecraft:portal ~ ~1 ~ 0.2 0.5 0.2 0.5 3
execute as @e[type=#evercraft:aoe_targets,tag=ec.rd_boss,limit=1] at @s facing entity @a[tag=ec.rd_participant,sort=nearest,limit=1] feet run tp @s ^ ^ ^2
execute as @e[type=#evercraft:aoe_targets,tag=ec.rd_boss,limit=1] at @s run particle minecraft:portal ~ ~1 ~ 0.2 0.5 0.2 0.5 3
execute as @e[type=#evercraft:aoe_targets,tag=ec.rd_boss,limit=1] at @s facing entity @a[tag=ec.rd_participant,sort=nearest,limit=1] feet run tp @s ^ ^ ^2

# Damage at destination
execute as @e[type=#evercraft:aoe_targets,tag=ec.rd_boss,limit=1] at @s run execute as @a[tag=ec.rd_participant,distance=..2] run damage @s 8 minecraft:mob_attack by @e[type=#evercraft:aoe_targets,tag=ec.rd_boss,limit=1]

# VFX
execute as @e[type=#evercraft:aoe_targets,tag=ec.rd_boss,limit=1] at @s run playsound minecraft:entity.enderman.teleport hostile @a[tag=ec.rd_participant,scores={ec.fx_snd=1..}] ~ ~ ~ 0.8 1.2
