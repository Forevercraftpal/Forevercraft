# Hollow Sovereign — Re-cloak (return to invisible state)
# Only applies during Phase 1

# Only re-cloak in Phase 1
execute unless score #rd_boss_phase ec.var matches 1 run return 0

# Apply invisibility
execute as @e[type=#evercraft:aoe_targets,tag=ec.rd_boss,limit=1] run effect give @s invisibility infinite 0 true
execute as @e[type=#evercraft:aoe_targets,tag=ec.rd_boss,limit=1] run effect clear @s glowing
execute as @e[type=#evercraft:aoe_targets,tag=ec.rd_boss,limit=1] run effect clear @s speed

# Reset
scoreboard players set #rd_hs_vis_timer ec.var 0
scoreboard players set #rd_hs_hits ec.var 0

# VFX
execute as @e[type=#evercraft:aoe_targets,tag=ec.rd_boss,limit=1] at @s run particle minecraft:large_smoke ~ ~1 ~ 1 1 1 0.05 10
execute as @e[type=#evercraft:aoe_targets,tag=ec.rd_boss,limit=1] at @s run playsound minecraft:entity.enderman.teleport hostile @a[tag=ec.rd_participant,scores={ec.fx_snd=1..}] ~ ~ ~ 0.8 0.4

# §5 staged fan-out — combat ping, forerunner stripped
data modify storage evercraft:notify stage.c set value [{text:"The Sovereign vanishes once more...",color:"dark_gray",italic:true}]
scoreboard players set #ndur ec.temp 45
execute as @a[tag=ec.rd_participant] run function evercraft:util/notify/emit
