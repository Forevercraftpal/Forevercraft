# Hollow Sovereign — Visible Window Countdown
# Boss is currently visible (Phase 1 only). Count down and re-cloak when expired.

# Decrement timer
scoreboard players remove #rd_hs_vis_timer ec.var 1

# Warning at 60 ticks (3 seconds left)
data modify storage evercraft:notify stage.c set value [{text:"The Sovereign fades back into shadow...",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 45
execute if score #rd_hs_vis_timer ec.var matches 60 as @a[tag=ec.rd_participant] run function evercraft:util/notify/emit

# Re-cloak when timer hits 0
execute if score #rd_hs_vis_timer ec.var matches ..0 run function evercraft:raids/boss/hollow_sovereign/abilities/recloak
