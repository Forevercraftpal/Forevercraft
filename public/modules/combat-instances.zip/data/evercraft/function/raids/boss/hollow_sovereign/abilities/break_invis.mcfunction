# Hollow Sovereign — Invisibility Broken! (3 hits reached)
# Boss becomes visible for 200 ticks (10 seconds) with normal melee combat

# Clear invisibility
effect clear @s invisibility

# Apply Glowing so players can see clearly
effect give @s glowing 10 0 true

# Reset hit counter
scoreboard players set #rd_hs_hits ec.var 0

# Set visibility window timer (200 ticks = 10 seconds)
scoreboard players set #rd_hs_vis_timer ec.var 200

# Dramatic reveal (§5 staged fan-out — forerunner stripped)
data modify storage evercraft:notify stage.c set value [{text:"The Sovereign is exposed! ATTACK NOW!",color:"green",bold:true}]
scoreboard players set #ndur ec.temp 45
execute as @a[tag=ec.rd_participant] run function evercraft:util/notify/emit

# VFX burst
particle minecraft:flash{color:[1.0,1.0,1.0,1.0]} ~ ~1 ~ 0 0 0 0 1
particle minecraft:sculk_soul ~ ~1 ~ 2 1 2 0.1 20
playsound minecraft:entity.warden.emerge hostile @a[tag=ec.rd_participant,scores={ec.fx_snd=1..}] ~ ~ ~ 1.0 1.0
playsound minecraft:block.sculk_shrieker.shriek hostile @a[tag=ec.rd_participant,scores={ec.fx_snd=1..}] ~ ~ ~ 1.0 0.6

# Boss becomes aggressive during visibility — Speed II for melee
effect give @s speed 10 1 true
