# Void Architect — Death (boss defeated!)
# Drop loot to all participants

# Kill remaining minions
kill @e[tag=ec.rd_mirror]
kill @e[tag=ec.rd_va_crystal]
kill @e[tag=ec.rd_well]
kill @e[tag=ec.rd_bubble]
kill @e[tag=ec.rd_va_proj]

# Boss-specific death dialogue (§5 staged fan-out — static broadcast)
data modify storage evercraft:notify stage.c set value [{text:"\"The architecture... crumbles... without its... maker...\"",color:"dark_purple",italic:true}]
scoreboard players set #ndur ec.temp 50
execute as @a[tag=ec.rd_participant] run function evercraft:util/notify/emit

# Drop loot to each participant
execute as @a[tag=ec.rd_participant] at @s run function evercraft:raids/boss/void_architect/loot

# Audit #6: rd.kills had 0 readers pack-wide — writer archived per W7 dead-scoreboard sweep.
