# The Ashen Lord — Ambient Effects (every tick, as boss entity at boss position)

# Fire particles around the boss
particle minecraft:flame ~ ~1 ~ 0.5 1 0.5 0.02 2
particle minecraft:smoke ~ ~2 ~ 0.3 0.3 0.3 0.01 1

# Fire aura visual (subtle ember ring)
particle minecraft:lava ~ ~0.5 ~ 1 0.1 1 0 1
