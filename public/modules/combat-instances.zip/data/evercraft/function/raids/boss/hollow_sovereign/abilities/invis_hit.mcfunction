# Hollow Sovereign — Hit While Invisible (called as boss entity when HurtTime:10s)
# Track hits — 3 hits breaks invisibility for 10 seconds

scoreboard players add #rd_hs_hits ec.var 1

# Feedback to attacker
playsound minecraft:block.sculk_sensor.break hostile @a[tag=ec.rd_participant,distance=..10,scores={ec.fx_snd=1..}] ~ ~ ~ 1.0 1.2
particle minecraft:crit ~ ~1.5 ~ 0.3 0.3 0.3 0.1 5

# Hit counter feedback
data modify storage evercraft:notify stage.c set value [{text:"The veil flickers... (1/3)",color:"gray"}]
scoreboard players set #ndur ec.temp 45
execute if score #rd_hs_hits ec.var matches 1 as @a[tag=ec.rd_participant] run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"The veil cracks... (2/3)",color:"yellow"}]
scoreboard players set #ndur ec.temp 45
execute if score #rd_hs_hits ec.var matches 2 as @a[tag=ec.rd_participant] run function evercraft:util/notify/emit

# On 3rd hit: break invisibility!
execute if score #rd_hs_hits ec.var matches 3.. run function evercraft:raids/boss/hollow_sovereign/abilities/break_invis
