# The Deepcrawler — Correct Lever!
# Advance sequence. If all 4 correct: cart slams boss for 200 damage

# Advance to next position
scoreboard players add #rd_dc_lever_seq ec.var 1

# VFX: correct lever
particle minecraft:happy_villager ~ ~1 ~ 0.5 0.5 0.5 0.1 5
playsound minecraft:block.note_block.pling master @a[tag=ec.rd_participant,scores={ec.fx_snd=1..}] ~ ~ ~ 1.0 1.2

# Check if sequence complete (position reached 5 = all 4 correct)
execute if score #rd_dc_lever_seq ec.var matches 5 run function evercraft:raids/boss/deepcrawler/puzzle/lever_slam

# Announce progress
data modify storage evercraft:notify stage.c set value [{text:"Correct lever! Keep going!",color:"green"}]
scoreboard players set #ndur ec.temp 45
execute if score #rd_dc_lever_seq ec.var matches 2..4 as @a[tag=ec.rd_participant] run function evercraft:util/notify/emit
