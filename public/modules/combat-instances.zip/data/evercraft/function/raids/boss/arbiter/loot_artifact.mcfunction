# Arbiter — Class Artifact Drop: Zephyr Edge (Dancer Fan)
# 5% chance — Spirit-capable dancer gauntlet

# Give the artifact
give @s minecraft:iron_sword[minecraft:custom_name={text:"Zephyr Edge",color:"aqua",italic:false},minecraft:lore=[{text:"Spirit Artifact",color:"light_purple",italic:false},{text:"Dancer Fan",color:"gray",italic:false},{text:""},{text:"A blade woven from the",color:"aqua",italic:false},{text:"Arbiter's final breath.",color:"aqua",italic:false},{text:""},{text:"Unbreakable. Pre-unlocked mastery.",color:"gold",italic:false},{text:"Can evolve to Spirit tier.",color:"light_purple",italic:false}],minecraft:rarity=epic,minecraft:unbreakable={},minecraft:enchantment_glint_override=true,minecraft:custom_data={spirit_artifact:1,spirit_class:"dancer",spirit_weapon:"zephyr_edge",spirit_tier:1}] 1

# Server-wide announcement (§5b direct render — names @s; one frame, divider dropped, ★ mirror)
function evercraft:util/notify/whoami
data modify storage evercraft:notify stage.c set value [{text:"★ ",color:"gold"},{text:""},{text:" obtained ",color:"gray"},{text:"Zephyr Edge",color:"aqua"},{text:"! ★",color:"gold"}]
data modify storage evercraft:notify stage.c[1].text set from storage evercraft:notify named.who
scoreboard players set #ndur ec.temp 50
execute as @a run scoreboard players set #nttl ec.temp 600
execute as @a run function evercraft:util/notify/emit_keep

# Dramatic effects
playsound minecraft:ui.toast.challenge_complete master @a[scores={ec.fx_snd=1..}] ~ ~ ~ 1.0 1.0
particle minecraft:totem_of_undying ~ ~1 ~ 0.5 0.5 0.5 0.5 25
title @s times 10 60 20
title @s title {"text":"SPIRIT ARTIFACT","color":"light_purple"}
title @s subtitle [{"text":"Zephyr Edge","color":"aqua"}]
