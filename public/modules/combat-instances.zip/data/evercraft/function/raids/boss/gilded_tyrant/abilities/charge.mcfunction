# Gilded Tyrant — Charge Attack
# Boss charges toward nearest player with Speed II burst

# Warning (§5 staged fan-out — ⚠ mirror)
data modify storage evercraft:notify stage.c set value [{text:"⚠ ",color:"gold"},{text:"The Tyrant charges!",color:"yellow"},{text:" ⚠",color:"gold"}]
scoreboard players set #ndur ec.temp 45
# (Council Upgrade 2026-06-10, balance MC-1: telegraph promoted emit_now → emit_crit_telegraph (40t TTL) + flash subtitle copy — Off players keep combat-safety warnings, a buried telegraph dies instead of firing post-hit.)
data modify storage evercraft:notify flash.c set from storage evercraft:notify stage.c
execute as @a[tag=ec.rd_participant] run function evercraft:util/notify/emit_crit_telegraph
execute as @a[tag=ec.rd_participant] run function evercraft:util/notify/flash

# Apply Speed II for 2 seconds (charge duration)
execute as @e[type=#evercraft:aoe_targets,tag=ec.rd_boss,limit=1] run effect give @s speed 2 1 true

# Teleport toward nearest player in steps (simulated charge)
execute as @e[type=#evercraft:aoe_targets,tag=ec.rd_boss,limit=1] at @s facing entity @a[tag=ec.rd_participant,sort=nearest,limit=1] feet run tp @s ^ ^ ^1.5

# Damage players caught in the charge path (2-block radius)
execute as @e[type=#evercraft:aoe_targets,tag=ec.rd_boss,limit=1] at @s run execute as @a[tag=ec.rd_participant,distance=..2] run damage @s 10 minecraft:mob_attack by @e[type=#evercraft:aoe_targets,tag=ec.rd_boss,limit=1]

# VFX
execute as @e[type=#evercraft:aoe_targets,tag=ec.rd_boss,limit=1] at @s run particle minecraft:dust{color:[1.0,0.84,0.0],scale:1.5} ~ ~0.5 ~ 0.5 0.3 0.5 0.1 5
execute as @e[type=#evercraft:aoe_targets,tag=ec.rd_boss,limit=1] at @s run playsound minecraft:entity.ravager.step hostile @a[tag=ec.rd_participant,scores={ec.fx_snd=1..}] ~ ~ ~ 1.0 0.6
