# Gatekeeper — Enter Phase 3: The Whirlwind
# Spawn portal walls, clear dimension effects

# Clear dimension effects
effect clear @a[tag=ec.rd_participant] jump_boost
execute as @e[type=#evercraft:aoe_targets,tag=ec.rd_boss,limit=1] run effect clear @s fire_resistance

# Kill phase 2 portals
kill @e[tag=ec.rd_gk_portal]

# Spawn portal wall entities (4 walls dividing arena into quadrants)
execute at @e[type=marker,tag=rd.center,limit=1] run summon armor_stand ~8 ~0 ~0 {Tags:["ec.rd_gk_wall","ec.rd_minion"],Small:1b,Invisible:1b,Invulnerable:1b,Marker:1b,NoGravity:1b}
execute at @e[type=marker,tag=rd.center,limit=1] run summon armor_stand ~-8 ~0 ~0 {Tags:["ec.rd_gk_wall","ec.rd_minion"],Small:1b,Invisible:1b,Invulnerable:1b,Marker:1b,NoGravity:1b}
execute at @e[type=marker,tag=rd.center,limit=1] run summon armor_stand ~0 ~0 ~8 {Tags:["ec.rd_gk_wall","ec.rd_minion"],Small:1b,Invisible:1b,Invulnerable:1b,Marker:1b,NoGravity:1b}
execute at @e[type=marker,tag=rd.center,limit=1] run summon armor_stand ~0 ~0 ~-8 {Tags:["ec.rd_gk_wall","ec.rd_minion"],Small:1b,Invisible:1b,Invulnerable:1b,Marker:1b,NoGravity:1b}
execute at @e[type=marker,tag=rd.center,limit=1] run summon armor_stand ~4 ~0 ~4 {Tags:["ec.rd_gk_wall","ec.rd_minion"],Small:1b,Invisible:1b,Invulnerable:1b,Marker:1b,NoGravity:1b}
execute at @e[type=marker,tag=rd.center,limit=1] run summon armor_stand ~-4 ~0 ~4 {Tags:["ec.rd_gk_wall","ec.rd_minion"],Small:1b,Invisible:1b,Invulnerable:1b,Marker:1b,NoGravity:1b}
execute at @e[type=marker,tag=rd.center,limit=1] run summon armor_stand ~4 ~0 ~-4 {Tags:["ec.rd_gk_wall","ec.rd_minion"],Small:1b,Invisible:1b,Invulnerable:1b,Marker:1b,NoGravity:1b}
execute at @e[type=marker,tag=rd.center,limit=1] run summon armor_stand ~-4 ~0 ~-4 {Tags:["ec.rd_gk_wall","ec.rd_minion"],Small:1b,Invisible:1b,Invulnerable:1b,Marker:1b,NoGravity:1b}

# Dialogue (§5 staged fan-out — indent stripped)
data modify storage evercraft:notify stage.c set value [{text:"\"THE GATE CLOSES. THERE IS NO ESCAPE FROM THE WHIRLWIND.\"",color:"dark_red",bold:true}]
scoreboard players set #ndur ec.temp 50
execute as @a[tag=ec.rd_participant] run function evercraft:util/notify/emit

# VFX
execute as @e[type=#evercraft:aoe_targets,tag=ec.rd_boss,limit=1] at @s run particle minecraft:enchant ~ ~1 ~ 5 3 5 1 40
execute as @e[type=#evercraft:aoe_targets,tag=ec.rd_boss,limit=1] at @s run playsound minecraft:entity.wither.spawn hostile @a[tag=ec.rd_participant,scores={ec.fx_snd=1..}] ~ ~ ~ 1.0 0.6
