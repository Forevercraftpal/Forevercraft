# Void Architect — Enter Phase 2: Gravity Wells

# Reset cooldowns
scoreboard players set #rd_va_well_cd ec.var 0
scoreboard players set #rd_va_tp_cd ec.var 0
scoreboard players set #rd_va_proj_cd ec.var 0

# Dialogue (§5 staged fan-out — indent stripped)
data modify storage evercraft:notify stage.c set value [{text:"\"Space bends to my will. You cannot escape the pull of the void.\"",color:"light_purple",italic:true}]
scoreboard players set #ndur ec.temp 50
execute as @a[tag=ec.rd_participant] run function evercraft:util/notify/emit

# VFX — void eruption
execute as @e[type=#evercraft:aoe_targets,tag=ec.rd_boss,limit=1] at @s run particle minecraft:reverse_portal ~ ~1 ~ 3 2 3 0.1 50
execute as @e[type=#evercraft:aoe_targets,tag=ec.rd_boss,limit=1] at @s run playsound minecraft:entity.ender_dragon.flap hostile @a[tag=ec.rd_participant,scores={ec.fx_snd=1..}] ~ ~ ~ 1.0 0.4

# Spawn initial gravity well
function evercraft:raids/boss/void_architect/abilities/spawn_well
