# The Ashen Lord — Extinguish Soul Lantern
# Called as the lantern entity being extinguished

tag @s remove ec.rd_al_lantern_on
tag @s add ec.rd_al_lantern_off

# VFX
particle minecraft:smoke ~ ~1 ~ 0.3 0.5 0.3 0.02 5
playsound minecraft:block.respawn_anchor.deplete master @a[tag=ec.rd_participant,scores={ec.fx_snd=1..}] ~ ~ ~ 1.0 0.8

# Notify (§5 staged fan-out — forerunner stripped)
data modify storage evercraft:notify stage.c set value [{text:"A soul lantern dims. Nearby players gain fire protection.",color:"yellow"}]
scoreboard players set #ndur ec.temp 45
execute as @a[tag=ec.rd_participant] run function evercraft:util/notify/emit
