# Hollow Sovereign — Check Shadow Respawn
# Respawn any dead fakes near the real boss

# Only run if there are dead fakes
execute unless entity @e[tag=ec.rd_hs_fake_dead] run return 0

# Teleport dead fakes back near the real boss and restore them
execute at @e[type=#evercraft:aoe_targets,tag=ec.rd_hs_real,limit=1] as @e[tag=ec.rd_hs_fake_dead] run tp @s ~3 ~ ~3
execute as @e[tag=ec.rd_hs_fake_dead] run effect clear @s invisibility
execute as @e[tag=ec.rd_hs_fake_dead] run tag @s remove ec.rd_hs_fake_dead

# VFX at respawn
execute as @e[tag=ec.rd_hs_fake] at @s run particle minecraft:reverse_portal ~ ~1 ~ 0.5 0.5 0.5 0.1 10
execute as @e[tag=ec.rd_hs_fake] at @s run playsound minecraft:entity.enderman.teleport hostile @a[tag=ec.rd_participant,distance=..15,scores={ec.fx_snd=1..}] ~ ~ ~ 0.8 0.6

# §5 staged fan-out — combat ping, forerunner stripped
data modify storage evercraft:notify stage.c set value [{text:"The shadows reform...",color:"dark_purple",italic:true}]
scoreboard players set #ndur ec.temp 45
execute as @a[tag=ec.rd_participant] run function evercraft:util/notify/emit
