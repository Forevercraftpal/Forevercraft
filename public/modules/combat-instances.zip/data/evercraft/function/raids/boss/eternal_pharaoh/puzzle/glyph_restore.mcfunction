# The Eternal Pharaoh — Restore Armor After Glyph Reveal
# Guard: only restore if Eternal Pharaoh is still the active boss
execute unless score #rd_active ec.var matches 1 run return 0
execute unless score #rd_boss_id ec.var matches 9 run return 0
execute as @e[type=husk,tag=ec.rd_boss,limit=1] run attribute @s armor modifier add evercraft:rd_boss/base 10 add_value
execute as @e[type=husk,tag=ec.rd_boss,limit=1] run effect clear @s glowing
# §5 staged fan-out — combat ping, forerunner stripped
data modify storage evercraft:notify stage.c set value [{text:"The Pharaoh's defenses reform.",color:"gold"}]
scoreboard players set #ndur ec.temp 45
execute as @a[tag=ec.rd_participant] run function evercraft:util/notify/emit
