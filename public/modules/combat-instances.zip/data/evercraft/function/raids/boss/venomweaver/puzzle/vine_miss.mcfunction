# The Venomweaver — Missed the vine window
# Time expired without hitting any vine — minor punishment

# Clear the glow color
scoreboard players set #rd_vw_glow_color ec.var 0

# Mild poison nova (less punishing than wrong answer)
effect give @a[tag=ec.rd_participant] poison 3 0

# VFX
execute as @e[type=cave_spider,tag=ec.rd_boss,limit=1] at @s run particle minecraft:item_slime ~ ~1 ~ 4 2 4 0.1 15

# Announce (§5 staged fan-out — forerunner stripped)
data modify storage evercraft:notify stage.c set value [{text:"Too slow! The venom spreads...",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 45
execute as @a[tag=ec.rd_participant] run function evercraft:util/notify/emit
