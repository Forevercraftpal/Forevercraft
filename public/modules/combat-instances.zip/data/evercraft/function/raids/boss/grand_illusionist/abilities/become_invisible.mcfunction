# Grand Illusionist — Become Invisible (Phase 2)
# Boss vanishes again, teleports to new position

execute as @e[type=#evercraft:aoe_targets,tag=ec.rd_boss,limit=1] run effect give @s invisibility infinite 0 true
execute as @e[type=#evercraft:aoe_targets,tag=ec.rd_boss,limit=1] run effect clear @s glowing

# Teleport to random position
execute as @e[type=#evercraft:aoe_targets,tag=ec.rd_boss,limit=1] at @e[type=marker,tag=rd.center,limit=1] run spreadplayers ~ ~ 3 15 false @s

# §5 staged fan-out — combat ping, indent stripped
data modify storage evercraft:notify stage.c set value [{text:"The Illusionist vanishes into the shadows...",color:"dark_gray",italic:true}]
scoreboard players set #ndur ec.temp 45
execute as @a[tag=ec.rd_participant] run function evercraft:util/notify/emit

execute as @e[type=#evercraft:aoe_targets,tag=ec.rd_boss,limit=1] at @s run particle minecraft:witch ~ ~1 ~ 1 0.5 1 0.1 8
execute as @e[type=#evercraft:aoe_targets,tag=ec.rd_boss,limit=1] at @s run playsound minecraft:entity.enderman.teleport hostile @a[tag=ec.rd_participant,scores={ec.fx_snd=1..}] ~ ~ ~ 0.6 1.5
