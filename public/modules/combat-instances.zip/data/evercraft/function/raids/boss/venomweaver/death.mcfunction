# The Venomweaver — Death Handler
# Drops loot, cleans up boss-specific entities

# Boss-specific cleanup
kill @e[tag=ec.rd_vw_perch]
kill @e[tag=ec.rd_vw_spider]
kill @e[tag=ec.rd_vw_egg]
kill @e[tag=ec.rd_vw_web]
kill @e[tag=ec.rd_vw_cloud]

# Victory dialogue (§5 staged fan-out — static broadcast)
data modify storage evercraft:notify stage.c set value [{text:"The Venomweaver",color:"green",bold:true},{text:" shrivels, the vines releasing their grip at last.",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 50
execute as @a[tag=ec.rd_participant] run function evercraft:util/notify/emit

# Loot drops to all participants
execute as @a[tag=ec.rd_participant] at @s run function evercraft:raids/boss/venomweaver/loot
