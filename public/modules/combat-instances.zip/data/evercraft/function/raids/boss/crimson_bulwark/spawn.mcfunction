# The Crimson Bulwark (#13) — Spawn
# Castle floor 25 raid boss — Tank class artifact (Bulwark Shield)

scoreboard players set #rd_boss_id ec.var 13

# Audit #6: Group B HP scaling parity — DR/party scaling like Group A.
execute as @a[tag=ec.rd_participant,limit=1,sort=random] run function evercraft:raids/boss/setup/scale

# Summon vindicator (massive shielded warrior)
execute anchored eyes positioned ^ ^ ^5 run summon vindicator ~ ~ ~ {Tags:["ec.rd_boss","ec.rd_cb"],Silent:1b,PersistenceRequired:1b,CanPickUpLoot:0b}

# HP: base 2200 × hp_scale / 100 — THE tankiest boss (1100 hearts base)
scoreboard players set #rd_temp ec.var 2200
scoreboard players operation #rd_temp ec.var *= #rd_hp_scale ec.var
scoreboard players operation #rd_temp ec.var /= #100 adv.temp
scoreboard players operation #rd_boss_hp_max ec.var = #rd_temp ec.var
scoreboard players operation #rd_p2_threshold ec.var = #rd_boss_hp_max ec.var
scoreboard players set #rd_temp ec.var 66
scoreboard players operation #rd_p2_threshold ec.var *= #rd_temp ec.var
scoreboard players operation #rd_p2_threshold ec.var /= #100 adv.temp
scoreboard players operation #rd_p3_threshold ec.var = #rd_boss_hp_max ec.var
scoreboard players set #rd_temp ec.var 33
scoreboard players operation #rd_p3_threshold ec.var *= #rd_temp ec.var
scoreboard players operation #rd_p3_threshold ec.var /= #100 adv.temp

# Audit #6: Set max HP via apply_hp macro
execute store result storage evercraft:raids tmp.hp_mod int 1 run scoreboard players get #rd_boss_hp_max ec.var
execute as @e[type=vindicator,tag=ec.rd_boss,limit=1] run function evercraft:raids/boss/setup/apply_hp with storage evercraft:raids tmp
execute as @e[type=vindicator,tag=ec.rd_boss,limit=1] run attribute @s scale base set 2.0
execute as @e[type=vindicator,tag=ec.rd_boss,limit=1] run attribute @s armor modifier add evercraft:rd_boss/base 20 add_value
execute as @e[type=vindicator,tag=ec.rd_boss,limit=1] run attribute @s movement_speed modifier add evercraft:rd_boss/base -0.2 add_multiplied_base
execute as @e[type=vindicator,tag=ec.rd_boss,limit=1] run attribute @s attack_damage modifier add evercraft:rd_boss/base 2.0 add_multiplied_base
execute as @e[type=vindicator,tag=ec.rd_boss,limit=1] run attribute @s knockback_resistance modifier add evercraft:rd_boss/base 1.0 add_value
# Audit #6: damage scaling parity
scoreboard players operation #rd_temp ec.var = #rd_dmg_scale ec.var
scoreboard players remove #rd_temp ec.var 100
execute if score #rd_temp ec.var matches 1.. store result storage evercraft:raids tmp.dmg_pct double 0.01 run scoreboard players get #rd_temp ec.var
execute if score #rd_temp ec.var matches 1.. as @e[type=vindicator,tag=ec.rd_boss,limit=1] run function evercraft:raids/boss/setup/apply_dmg with storage evercraft:raids tmp

# Custom name
execute as @e[type=vindicator,tag=ec.rd_boss,limit=1] run data modify entity @s CustomName set value [{text:"\u2620 ",color:"dark_red"},{text:"The Crimson Bulwark",color:"red",bold:true},{text:" \u2620",color:"dark_red"}]
execute as @e[type=vindicator,tag=ec.rd_boss,limit=1] run data modify entity @s CustomNameVisible set value 1b

# Bossbar
bossbar remove evercraft:raid_boss
bossbar add evercraft:raid_boss [{text:"\u2620 ",color:"dark_red"},{text:"The Crimson Bulwark",color:"red",bold:true},{text:" \u2620",color:"dark_red"}]
bossbar set evercraft:raid_boss color red
execute store result bossbar evercraft:raid_boss max run scoreboard players get #rd_boss_hp_max ec.var
execute store result bossbar evercraft:raid_boss value run scoreboard players get #rd_boss_hp_max ec.var
bossbar set evercraft:raid_boss visible true
bossbar set evercraft:raid_boss players @a[tag=ec.rd_participant]

# State (Audit #6: #rd_active=1 redundant — enter.mcfunction set it)
scoreboard players set #rd_boss_phase ec.var 1
scoreboard players set #rd_timer ec.var 0
scoreboard players set #rd_phase_lock ec.var 0
scoreboard players set #rd_ability_cd ec.var 0
scoreboard players set #rd_cb_slam_cd ec.var 0
scoreboard players set #rd_cb_guard_cd ec.var 0
scoreboard players set #rd_cb_reflect ec.var 0
scoreboard players set #rd_cb_spin_cd ec.var 0
scoreboard players set #rd_cb_throw_cd ec.var 0
scoreboard players set #rd_cb_pillar_hp1 ec.var 3
scoreboard players set #rd_cb_pillar_hp2 ec.var 3
scoreboard players set #rd_cb_pillar_hp3 ec.var 3
scoreboard players set #rd_cb_pillar_hp4 ec.var 3

# Spawn 4 destructible pillar interactions (cover for shield throws)
execute at @e[type=vindicator,tag=ec.rd_boss,limit=1] run summon interaction ~10 ~1 ~0 {Tags:["ec.rd_mechanic","ec.rd_cb_pillar","ec.rd_cb_pillar1"],width:2.0f,height:3.0f,response:1b}
execute at @e[type=vindicator,tag=ec.rd_boss,limit=1] run summon interaction ~-10 ~1 ~0 {Tags:["ec.rd_mechanic","ec.rd_cb_pillar","ec.rd_cb_pillar2"],width:2.0f,height:3.0f,response:1b}
execute at @e[type=vindicator,tag=ec.rd_boss,limit=1] run summon interaction ~0 ~1 ~10 {Tags:["ec.rd_mechanic","ec.rd_cb_pillar","ec.rd_cb_pillar3"],width:2.0f,height:3.0f,response:1b}
execute at @e[type=vindicator,tag=ec.rd_boss,limit=1] run summon interaction ~0 ~1 ~-10 {Tags:["ec.rd_mechanic","ec.rd_cb_pillar","ec.rd_cb_pillar4"],width:2.0f,height:3.0f,response:1b}

# Spawn 4 banner interactions (puzzle)
execute at @e[type=vindicator,tag=ec.rd_boss,limit=1] run summon interaction ~14 ~1 ~0 {Tags:["ec.rd_mechanic","ec.rd_cb_banner"],width:1.5f,height:2.5f,response:1b}
execute at @e[type=vindicator,tag=ec.rd_boss,limit=1] run summon interaction ~-14 ~1 ~0 {Tags:["ec.rd_mechanic","ec.rd_cb_banner"],width:1.5f,height:2.5f,response:1b}
execute at @e[type=vindicator,tag=ec.rd_boss,limit=1] run summon interaction ~0 ~1 ~14 {Tags:["ec.rd_mechanic","ec.rd_cb_banner"],width:1.5f,height:2.5f,response:1b}
execute at @e[type=vindicator,tag=ec.rd_boss,limit=1] run summon interaction ~0 ~1 ~-14 {Tags:["ec.rd_mechanic","ec.rd_cb_banner"],width:1.5f,height:2.5f,response:1b}

# Audit #6: redundant `schedule sync_hp 2t` removed (apply_hp already schedules).
# Audit #6: redundant `tag @s add ec.rd_participant` removed (boss/spawn:9 already tagged all rd.player).
data modify storage evercraft:raids active set value {boss_name:"The Crimson Bulwark",boss_color:"red"}

# VFX
execute at @e[type=vindicator,tag=ec.rd_boss,limit=1] run particle minecraft:dust{color:[0.8,0.1,0.1],scale:1.5} ~ ~1 ~ 3 1 3 0 20
execute at @e[type=vindicator,tag=ec.rd_boss,limit=1] run playsound minecraft:entity.vindicator.ambient master @a[scores={ec.fx_snd=1..}] ~ ~ ~ 2.0 0.3
execute at @e[type=vindicator,tag=ec.rd_boss,limit=1] run playsound minecraft:entity.wither.spawn master @a[scores={ec.fx_snd=1..}] ~ ~ ~ 0.8 0.8

# \u00a75 staged fan-out \u2014 boss spawn banner, dividers dropped, \u2620 mirror
data modify storage evercraft:notify stage.c set value [{text:"\u2620 ",color:"dark_red"},{text:"The Crimson Bulwark",color:"red",bold:true},{text:" rises from the throne!",color:"dark_red"},{text:" \u2620",color:"dark_red"}]
scoreboard players set #ndur ec.temp 50
execute as @a run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"It guards the concept of walls.",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 40
execute as @a run function evercraft:util/notify/emit

# --- Boss intro cinematic (lifted from Council #8 Plan 8 retirement, 2026-05-27) ---
data modify storage evercraft:spectator boss set value {name:"Crimson Bulwark",subtitle:"Castle Floor 25 Gatekeeper"}
execute as @a[tag=ec.rd_participant] run function evercraft:spectator/boss_intro/play
