# Arbiter — Enter Phase 2: Trial by Agility

# Reset cooldowns
scoreboard players set #rd_arb_blast_cd ec.var 0
scoreboard players set #rd_arb_zone_timer ec.var 0
scoreboard players set #rd_arb_zone_radius ec.var 15

# Dialogue (§5 staged fan-out — indent stripped)
data modify storage evercraft:notify stage.c set value [{text:"\"Combat alone does not prove your worth. Now face the winds of judgment.\"",color:"aqua",italic:true}]
scoreboard players set #ndur ec.temp 50
execute as @a[tag=ec.rd_participant] run function evercraft:util/notify/emit

# VFX — wind eruption
execute as @e[type=#evercraft:aoe_targets,tag=ec.rd_boss,limit=1] at @s run particle minecraft:cloud ~ ~1 ~ 4 2 4 0.2 25
execute as @e[type=#evercraft:aoe_targets,tag=ec.rd_boss,limit=1] at @s run playsound minecraft:entity.wind_charge.wind_burst hostile @a[tag=ec.rd_participant,scores={ec.fx_snd=1..}] ~ ~ ~ 1.5 0.6
