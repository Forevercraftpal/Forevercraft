# The Leviathan — Tidal Wave
# Knockback + 4 damage to all participants (simulates wave sweeping across room)

# Warning
playsound minecraft:entity.generic.splash master @a[tag=ec.rd_participant,scores={ec.fx_snd=1..}] ~ ~ ~ 2.0 0.5
# §5 staged fan-out — combat ping, forerunner stripped
data modify storage evercraft:notify stage.c set value [{text:"A massive wave surges through the chamber!",color:"aqua"}]
scoreboard players set #ndur ec.temp 45
# (Council Upgrade 2026-06-10, balance MC-1: telegraph promoted emit_now → emit_crit_telegraph (40t TTL) + flash subtitle copy — Off players keep combat-safety warnings, a buried telegraph dies instead of firing post-hit.)
data modify storage evercraft:notify flash.c set from storage evercraft:notify stage.c
execute as @a[tag=ec.rd_participant] run function evercraft:util/notify/emit_crit_telegraph
execute as @a[tag=ec.rd_participant] run function evercraft:util/notify/flash

# Damage + knockback to all participants
execute as @a[tag=ec.rd_participant] at @s run damage @s 4 minecraft:drown by @e[type=guardian,tag=ec.rd_boss,limit=1]

# Heavy knockback (push away from boss)
execute as @e[type=guardian,tag=ec.rd_boss,limit=1] at @s run execute as @a[tag=ec.rd_participant,distance=..25] at @s facing entity @e[type=guardian,tag=ec.rd_boss,limit=1] feet positioned ^ ^ ^0 run tp @s ~ ~ ~ ~ ~
execute as @a[tag=ec.rd_participant] at @s run tp @s ~ ~ ~ ~ ~

# Wave VFX
execute as @e[type=guardian,tag=ec.rd_boss,limit=1] at @s run particle minecraft:splash ~ ~1 ~ 10 1 10 0.5 50
execute as @e[type=guardian,tag=ec.rd_boss,limit=1] at @s run particle minecraft:bubble ~ ~1 ~ 8 1 8 0.3 25
