# The Eternal Pharaoh — Altar Cleanse
# Called as the altar entity at its position

# Get the player who clicked (nearest participant)
execute as @a[tag=ec.rd_participant,distance=..3,limit=1,sort=nearest] run effect clear @s slowness
execute as @a[tag=ec.rd_participant,distance=..3,limit=1,sort=nearest] run effect clear @s weakness
execute as @a[tag=ec.rd_participant,distance=..3,limit=1,sort=nearest] run effect clear @s blindness
execute as @a[tag=ec.rd_participant,distance=..3,limit=1,sort=nearest] run effect clear @s wither

# Clear interaction
data remove entity @s interaction

# Start cooldown
scoreboard players set #rd_ep_altar_cd ec.var 300

# VFX
particle minecraft:end_rod ~ ~2 ~ 0.5 1 0.5 0.1 10
playsound minecraft:block.beacon.activate master @a[tag=ec.rd_participant,scores={ec.fx_snd=1..}] ~ ~ ~ 1.0 1.5

# §5 staged fan-out — combat ping, forerunner stripped
data modify storage evercraft:notify stage.c set value [{text:"The altar cleanses curses! (15s cooldown)",color:"green"}]
scoreboard players set #ndur ec.temp 45
execute as @a[tag=ec.rd_participant] run function evercraft:util/notify/emit
