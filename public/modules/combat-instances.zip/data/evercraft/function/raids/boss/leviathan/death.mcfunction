# The Leviathan — Death Handler

# Boss-specific cleanup
kill @e[tag=ec.rd_lv_whirlpool]
kill @e[tag=ec.rd_lv_guard]
kill @e[tag=ec.rd_lv_sponge]

# Victory dialogue (§5 staged fan-out — static broadcast)
data modify storage evercraft:notify stage.c set value [{text:"The Leviathan",color:"dark_aqua",bold:true},{text:" sinks into the abyss, the waters calming at last.",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 50
execute as @a[tag=ec.rd_participant] run function evercraft:util/notify/emit

# Loot drops
execute as @a[tag=ec.rd_participant] at @s run function evercraft:raids/boss/leviathan/loot
