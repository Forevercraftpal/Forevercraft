# The Mossheart Warden — Core Destroyed
# Called as the core entity

scoreboard players remove #rd_mw_cores_active ec.var 1

# VFX: core explosion
particle minecraft:explosion ~ ~1 ~ 0.5 0.5 0.5 0.3 3
particle minecraft:happy_villager ~ ~1 ~ 1 1 1 0.1 10
playsound minecraft:block.respawn_anchor.deplete master @a[tag=ec.rd_participant,scores={ec.fx_snd=1..}] ~ ~ ~ 1.5 0.6

# §5 staged fan-out — combat ping, forerunner stripped
data modify storage evercraft:notify stage.c set value [{text:"Spawner core destroyed!",color:"green",bold:true}]
scoreboard players set #ndur ec.temp 45
execute as @a[tag=ec.rd_participant] run function evercraft:util/notify/emit

# Convert position to safe zone marker for Phase 3
summon marker ~ ~ ~ {Tags:["ec.rd_mechanic","ec.rd_mw_safe_zone"]}

# Kill the core
kill @s
