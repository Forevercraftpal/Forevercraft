# The Crimson Bulwark — Banner Pulled During Shield Spin
# Punishes the puller with 6 damage

# Damage nearest participant to the banner
execute at @e[tag=ec.rd_cb_banner,limit=1,sort=nearest] run damage @a[tag=ec.rd_participant,sort=nearest,limit=1,distance=..3] 6 minecraft:mob_attack

# VFX
execute at @e[tag=ec.rd_cb_banner,limit=1,sort=nearest] run particle minecraft:dust{color:[0.9,0.1,0.1],scale:2.0} ~ ~1 ~ 0.5 0.5 0.5 0 8
execute at @e[tag=ec.rd_cb_banner,limit=1,sort=nearest] run playsound minecraft:entity.item.break master @a[tag=ec.rd_participant,scores={ec.fx_snd=1..}] ~ ~ ~ 1.0 0.5

# §5 staged fan-out — combat ping, forerunner stripped
data modify storage evercraft:notify stage.c set value [{text:"Bad timing! The banner shreds apart!",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute as @a[tag=ec.rd_participant] run function evercraft:util/notify/emit
