# The Venomweaver (#10) — Spawn
# Jungle Pyramid raid boss — Healer class artifact (Lifewoven Branch)

scoreboard players set #rd_boss_id ec.var 10

# Audit #6: Group B HP scaling parity — DR/party scaling like Group A.
execute as @a[tag=ec.rd_participant,limit=1,sort=random] run function evercraft:raids/boss/setup/scale

# Summon cave spider (supersized)
execute anchored eyes positioned ^ ^ ^5 run summon cave_spider ~ ~ ~ {Tags:["ec.rd_boss","ec.rd_vw"],Silent:1b,PersistenceRequired:1b,CanPickUpLoot:0b}

# HP: base 1300 × hp_scale / 100
scoreboard players set #rd_temp ec.var 1300
scoreboard players operation #rd_temp ec.var *= #rd_hp_scale ec.var
scoreboard players operation #rd_temp ec.var /= #100 adv.temp
scoreboard players operation #rd_boss_hp_max ec.var = #rd_temp ec.var
scoreboard players operation #rd_p2_threshold ec.var = #rd_boss_hp_max ec.var
scoreboard players set #rd_temp ec.var 66
scoreboard players operation #rd_p2_threshold ec.var *= #rd_temp ec.var
scoreboard players operation #rd_p2_threshold ec.var /= #100 adv.temp
scoreboard players operation #rd_p3_threshold ec.var = #rd_boss_hp_max ec.var
scoreboard players set #rd_temp ec.var 33
scoreboard players operation #rd_p3_threshold ec.var *= #rd_temp ec.var
scoreboard players operation #rd_p3_threshold ec.var /= #100 adv.temp

# Audit #6: Set max HP via apply_hp macro
execute store result storage evercraft:raids tmp.hp_mod int 1 run scoreboard players get #rd_boss_hp_max ec.var
execute as @e[type=cave_spider,tag=ec.rd_boss,limit=1] run function evercraft:raids/boss/setup/apply_hp with storage evercraft:raids tmp
execute as @e[type=cave_spider,tag=ec.rd_boss,limit=1] run attribute @s scale base set 4.0
execute as @e[type=cave_spider,tag=ec.rd_boss,limit=1] run attribute @s armor modifier add evercraft:rd_boss/base 8 add_value
execute as @e[type=cave_spider,tag=ec.rd_boss,limit=1] run attribute @s movement_speed modifier add evercraft:rd_boss/base 0.4 add_multiplied_base
execute as @e[type=cave_spider,tag=ec.rd_boss,limit=1] run attribute @s attack_damage modifier add evercraft:rd_boss/base 2.0 add_multiplied_base
execute as @e[type=cave_spider,tag=ec.rd_boss,limit=1] run attribute @s knockback_resistance modifier add evercraft:rd_boss/base 0.5 add_value
# Audit #6: damage scaling parity
scoreboard players operation #rd_temp ec.var = #rd_dmg_scale ec.var
scoreboard players remove #rd_temp ec.var 100
execute if score #rd_temp ec.var matches 1.. store result storage evercraft:raids tmp.dmg_pct double 0.01 run scoreboard players get #rd_temp ec.var
execute if score #rd_temp ec.var matches 1.. as @e[type=cave_spider,tag=ec.rd_boss,limit=1] run function evercraft:raids/boss/setup/apply_dmg with storage evercraft:raids tmp

# Custom name
execute as @e[type=cave_spider,tag=ec.rd_boss,limit=1] run data modify entity @s CustomName set value [{text:"☠ ",color:"dark_red"},{text:"The Venomweaver",color:"dark_green",bold:true},{text:" ☠",color:"dark_red"}]
execute as @e[type=cave_spider,tag=ec.rd_boss,limit=1] run data modify entity @s CustomNameVisible set value 1b

# Bossbar
bossbar remove evercraft:raid_boss
bossbar add evercraft:raid_boss [{text:"☠ ",color:"dark_red"},{text:"The Venomweaver",color:"dark_green",bold:true},{text:" ☠",color:"dark_red"}]
bossbar set evercraft:raid_boss color green
execute store result bossbar evercraft:raid_boss max run scoreboard players get #rd_boss_hp_max ec.var
execute store result bossbar evercraft:raid_boss value run scoreboard players get #rd_boss_hp_max ec.var
bossbar set evercraft:raid_boss visible true
bossbar set evercraft:raid_boss players @a[tag=ec.rd_participant]

# State (Audit #6: #rd_active=1 redundant — enter.mcfunction set it)
scoreboard players set #rd_boss_phase ec.var 1
scoreboard players set #rd_timer ec.var 0
scoreboard players set #rd_phase_lock ec.var 0
scoreboard players set #rd_ability_cd ec.var 0
scoreboard players set #rd_vw_perch_cd ec.var 100
scoreboard players set #rd_vw_spit_cd ec.var 0
scoreboard players set #rd_vw_web_cd ec.var 0
scoreboard players set #rd_vw_rage ec.var 0
scoreboard players set #rd_vw_cloud_cd ec.var 0
scoreboard players set #rd_vw_color_cd ec.var 200
scoreboard players set #rd_vw_glow_color ec.var 0

# Spawn 3 vine perch positions (interaction entities — clickable for puzzle)
execute at @e[type=cave_spider,tag=ec.rd_boss,limit=1] run summon interaction ~10 ~5 ~10 {Tags:["ec.rd_mechanic","ec.rd_vw_perch","ec.rd_vw_perch1"],width:2.5f,height:3.0f,response:1b}
execute at @e[type=cave_spider,tag=ec.rd_boss,limit=1] run summon interaction ~-10 ~5 ~-10 {Tags:["ec.rd_mechanic","ec.rd_vw_perch","ec.rd_vw_perch2"],width:2.5f,height:3.0f,response:1b}
execute at @e[type=cave_spider,tag=ec.rd_boss,limit=1] run summon interaction ~ ~5 ~12 {Tags:["ec.rd_mechanic","ec.rd_vw_perch","ec.rd_vw_perch3"],width:2.5f,height:3.0f,response:1b}

# Audit #6: redundant `schedule sync_hp 2t` removed (apply_hp already schedules).
# Audit #6: redundant `tag @s add ec.rd_participant` removed (boss/spawn:9 already tagged all rd.player).
data modify storage evercraft:raids active set value {boss_name:"The Venomweaver",boss_color:"dark_green"}

# VFX
execute at @e[type=cave_spider,tag=ec.rd_boss,limit=1] run particle minecraft:item_slime ~ ~1 ~ 2 1 2 0.1 15
execute at @e[type=cave_spider,tag=ec.rd_boss,limit=1] run playsound minecraft:entity.spider.ambient master @a[scores={ec.fx_snd=1..}] ~ ~ ~ 1.5 0.4
execute at @e[type=cave_spider,tag=ec.rd_boss,limit=1] run playsound minecraft:entity.wither.spawn master @a[scores={ec.fx_snd=1..}] ~ ~ ~ 0.8 0.8

# §5 staged fan-out — boss spawn banner, dividers dropped, ☠ mirror
data modify storage evercraft:notify stage.c set value [{text:"☠ ",color:"dark_red"},{text:"The Venomweaver",color:"dark_green",bold:true},{text:" descends from the canopy!",color:"green"},{text:" ☠",color:"dark_red"}]
scoreboard players set #ndur ec.temp 50
execute as @a run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"The vines tighten...",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 40
execute as @a run function evercraft:util/notify/emit

# --- Boss intro cinematic (lifted from Council #8 Plan 8 retirement, 2026-05-27) ---
data modify storage evercraft:spectator boss set value {name:"Venomweaver",subtitle:"Master of Poisons"}
execute as @a[tag=ec.rd_participant] run function evercraft:spectator/boss_intro/play
