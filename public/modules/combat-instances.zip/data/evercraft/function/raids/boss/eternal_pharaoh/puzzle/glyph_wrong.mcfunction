# The Eternal Pharaoh — Wrong Pillar Hit
# Sand trap: Slowness V + Blindness 3s to nearby player

# Punish the player who clicked (nearest to this pillar)
effect give @a[tag=ec.rd_participant,distance=..3,limit=1,sort=nearest] slowness 3 4
effect give @a[tag=ec.rd_participant,distance=..3,limit=1,sort=nearest] blindness 3 0

# VFX
particle minecraft:dust{color:[0.9,0.7,0.1],scale:2.0} ~ ~1 ~ 1 1 1 0.1 10
playsound minecraft:entity.husk.hurt master @a[tag=ec.rd_participant,scores={ec.fx_snd=1..}] ~ ~ ~ 1.0 0.4

# §5 staged fan-out — combat ping, forerunner stripped
data modify storage evercraft:notify stage.c set value [{text:"Wrong pillar! Sand trap triggered!",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute as @a[tag=ec.rd_participant] run function evercraft:util/notify/emit
