# Hollow Sovereign — End Silence
scoreboard players set #rd_hs_silence ec.var 0
scoreboard players set #rd_hs_silence_timer ec.var 0

# Remove glowing
execute as @e[type=#evercraft:aoe_targets,tag=ec.rd_boss,limit=1] run effect clear @s glowing

# Feedback (§5 staged fan-out — forerunner stripped)
data modify storage evercraft:notify stage.c set value [{text:"The silence lifts — resume attacking!",color:"green"}]
scoreboard players set #ndur ec.temp 45
execute as @a[tag=ec.rd_participant] run function evercraft:util/notify/emit
execute as @e[type=#evercraft:aoe_targets,tag=ec.rd_boss,limit=1] at @s run playsound minecraft:block.respawn_anchor.deplete hostile @a[tag=ec.rd_participant,scores={ec.fx_snd=1..}] ~ ~ ~ 0.8 1.2
