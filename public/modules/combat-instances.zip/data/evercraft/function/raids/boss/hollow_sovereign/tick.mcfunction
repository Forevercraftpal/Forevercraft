# Hollow Sovereign — Per-Tick AI
# Called from raids/boss/tick.mcfunction when #rd_boss_id = 1

# Ambient particles — sculk theme (always active)
execute as @e[type=wither_skeleton,tag=ec.rd_boss,limit=1] at @s run particle minecraft:sculk_soul ~ ~1.5 ~ 0.5 0.5 0.5 0.02 1
execute as @e[type=wither_skeleton,tag=ec.rd_boss,limit=1] at @s run particle minecraft:sculk_charge_pop ~ ~0.5 ~ 0.3 0.2 0.3 0.01 1

# Route to current phase behavior
execute if score #rd_boss_phase ec.var matches 1 run function evercraft:raids/boss/hollow_sovereign/phase/phase1
execute if score #rd_boss_phase ec.var matches 2 run function evercraft:raids/boss/hollow_sovereign/phase/phase2
execute if score #rd_boss_phase ec.var matches 3 run function evercraft:raids/boss/hollow_sovereign/phase/phase3
