# Gatekeeper — Enter Phase 2: Dimensional Shift

# Reset cooldowns
scoreboard players set #rd_gk_combo ec.var 0
scoreboard players set #rd_gk_dash_cd ec.var 0
scoreboard players set #rd_gk_portal_cd ec.var 0
scoreboard players set #rd_gk_dim ec.var 0
scoreboard players set #rd_gk_dim_timer ec.var 0

# Kill any phase 1 portals
kill @e[tag=ec.rd_gk_portal]

# Dialogue (§5 staged fan-out — indent stripped)
data modify storage evercraft:notify stage.c set value [{text:"\"You have seen one realm. Now face them all.\"",color:"green",italic:true}]
scoreboard players set #ndur ec.temp 50
execute as @a[tag=ec.rd_participant] run function evercraft:util/notify/emit

# VFX — dimensional rift
execute as @e[type=#evercraft:aoe_targets,tag=ec.rd_boss,limit=1] at @s run particle minecraft:portal ~ ~1 ~ 3 2 3 1 25
execute as @e[type=#evercraft:aoe_targets,tag=ec.rd_boss,limit=1] at @s run playsound minecraft:entity.enderman.teleport hostile @a[tag=ec.rd_participant,scores={ec.fx_snd=1..}] ~ ~ ~ 1.5 0.5
