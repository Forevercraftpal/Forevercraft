# The Deepcrawler — Death Handler

# Boss-specific cleanup
kill @e[tag=ec.rd_dc_wall_pos]
kill @e[tag=ec.rd_dc_lever]
kill @e[tag=ec.rd_dc_spider]

# Victory dialogue (§5 staged fan-out — static broadcast)
data modify storage evercraft:notify stage.c set value [{text:"The Deepcrawler",color:"gray",bold:true},{text:" collapses, the tunnels falling silent at last.",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 50
execute as @a[tag=ec.rd_participant] run function evercraft:util/notify/emit

# Loot drops to all participants
execute as @a[tag=ec.rd_participant] at @s run function evercraft:raids/boss/deepcrawler/loot
