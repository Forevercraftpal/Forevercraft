# Grand Illusionist — Fake Hit Tracking
# Called when a fake copy takes a hit — accumulate tag-based damage, "die" after 5 hits

# Accumulate hit tags
execute unless entity @s[tag=ec.rd_gi_h1] run tag @s add ec.rd_gi_h1
execute if entity @s[tag=ec.rd_gi_h1] unless entity @s[tag=ec.rd_gi_h2] run tag @s add ec.rd_gi_h2
execute if entity @s[tag=ec.rd_gi_h2] unless entity @s[tag=ec.rd_gi_h3] run tag @s add ec.rd_gi_h3
execute if entity @s[tag=ec.rd_gi_h3] unless entity @s[tag=ec.rd_gi_h4] run tag @s add ec.rd_gi_h4
execute if entity @s[tag=ec.rd_gi_h4] unless entity @s[tag=ec.rd_gi_h5] run tag @s add ec.rd_gi_h5

# On 5th hit: "die" (teleport away + invisible for 300 ticks then respawn)
execute if entity @s[tag=ec.rd_gi_h5] at @s run particle minecraft:witch ~ ~1 ~ 0.5 0.5 0.5 0.2 8
execute if entity @s[tag=ec.rd_gi_h5] at @s run playsound minecraft:entity.evoker.death hostile @a[tag=ec.rd_participant,distance=..15,scores={ec.fx_snd=1..}] ~ ~ ~ 0.8 1.0
data modify storage evercraft:notify stage.c set value [{text:"An illusion shatters!",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 45
execute if entity @s[tag=ec.rd_gi_h5] as @a[tag=ec.rd_participant] run function evercraft:util/notify/emit
execute if entity @s[tag=ec.rd_gi_h5] run tp @s ~ -100 ~
execute if entity @s[tag=ec.rd_gi_h5] run tag @s add ec.rd_gi_dead
execute if entity @s[tag=ec.rd_gi_h5] run tag @s remove ec.rd_gi_h1
execute if entity @s[tag=ec.rd_gi_h5] run tag @s remove ec.rd_gi_h2
execute if entity @s[tag=ec.rd_gi_h5] run tag @s remove ec.rd_gi_h3
execute if entity @s[tag=ec.rd_gi_h5] run tag @s remove ec.rd_gi_h4
execute if entity @s[tag=ec.rd_gi_h5] run tag @s remove ec.rd_gi_h5

# Feedback
execute unless entity @s[tag=ec.rd_gi_dead] at @s run particle minecraft:crit ~ ~1 ~ 0.3 0.3 0.3 0.1 3
