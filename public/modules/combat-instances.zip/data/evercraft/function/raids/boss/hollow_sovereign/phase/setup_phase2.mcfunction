# Hollow Sovereign — Phase 2 Setup: The Sculk Tendrils
# Boss becomes permanently visible. Clear invis state, start tendril + silence mechanics.

# Remove invisibility permanently
execute as @e[type=#evercraft:aoe_targets,tag=ec.rd_boss,limit=1] run effect clear @s invisibility
execute as @e[type=#evercraft:aoe_targets,tag=ec.rd_boss,limit=1] run effect clear @s glowing
execute as @e[type=#evercraft:aoe_targets,tag=ec.rd_boss,limit=1] run effect clear @s speed

# Reset Phase 1 state
scoreboard players set #rd_hs_vis_timer ec.var 0
scoreboard players set #rd_hs_hits ec.var 0

# Initialize Phase 2 state
scoreboard players set #rd_hs_silence ec.var 0
scoreboard players set #rd_hs_silence_timer ec.var 0
scoreboard players set #rd_hs_tendril_cd ec.var 0

# Dialogue (§5 staged fan-out — indent stripped)
data modify storage evercraft:notify stage.c set value [{text:"\"You see me now... but you cannot silence what the sculk speaks.\"",color:"aqua",italic:true}]
scoreboard players set #ndur ec.temp 50
execute as @a[tag=ec.rd_participant] run function evercraft:util/notify/emit

# Dramatic VFX — sculk eruption
execute as @e[type=#evercraft:aoe_targets,tag=ec.rd_boss,limit=1] at @s run particle minecraft:sculk_soul ~ ~0.5 ~ 5 0.5 5 0.05 40
execute as @e[type=#evercraft:aoe_targets,tag=ec.rd_boss,limit=1] at @s run playsound minecraft:block.sculk_catalyst.bloom hostile @a[tag=ec.rd_participant,scores={ec.fx_snd=1..}] ~ ~ ~ 1.0 0.4

# Spawn initial tendrils
function evercraft:raids/boss/hollow_sovereign/abilities/spawn_tendril
