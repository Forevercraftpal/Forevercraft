# Arbiter — Outside-Zone Warning cue (run as @s = an outside-the-zone participant; called from
# zone_damage's banded checks via the #rd_outz dedup latch — exactly once per 20t beat per player).
# Wave 1 (Joseph 2026-06-10): was an ungated raw repaint that buried every other message during
# the fight. Now: critical subtitle FLASH (lower-center, re-stamped each beat while outside — reads
# as a continuous warning) + a PREEMPTIVE bar copy via emit_crit_beat (AB-6 wrapper): renders
# ≤1 tick even mid-queue, and the wrapper derives #nttl from the beat (#nbeat+15) so a salvaged/
# queued stale copy dies silently instead of accumulating as the beats repeat.
data modify storage evercraft:notify flash.c set value [{text:"OUTSIDE THE SAFE ZONE!",color:"red"}]
function evercraft:util/notify/flash
data modify storage evercraft:notify stage.c set value [{text:"OUTSIDE THE SAFE ZONE!",color:"red"}]
scoreboard players set #ndur ec.temp 30
scoreboard players set #nbeat ec.temp 20
function evercraft:util/notify/emit_crit_beat
