# The Venomweaver — Poison Cloud (Phase 3)
# Massive AoE poison cloud at boss position

# Spawn area effect cloud with Poison II, lingering 8 seconds
execute as @e[type=cave_spider,tag=ec.rd_boss,limit=1] at @s run summon area_effect_cloud ~ ~0.5 ~ {Tags:["ec.rd_mechanic","ec.rd_vw_cloud"],Radius:6.0f,RadiusOnUse:0.0f,RadiusPerTick:-0.003f,Duration:160,WaitTime:0,custom_particle:{type:"minecraft:entity_effect"},potion_contents:{custom_color:5149489,custom_effects:[{id:"minecraft:poison",amplifier:1b,duration:100,show_particles:1b}]}}

# VFX: massive poison burst
execute as @e[type=cave_spider,tag=ec.rd_boss,limit=1] at @s run particle minecraft:item_slime ~ ~1 ~ 6 2 6 0.05 40
execute as @e[type=cave_spider,tag=ec.rd_boss,limit=1] at @s run playsound minecraft:entity.evoker_fangs.attack master @a[tag=ec.rd_participant,scores={ec.fx_snd=1..}] ~ ~ ~ 1.5 0.4
execute as @e[type=cave_spider,tag=ec.rd_boss,limit=1] at @s run playsound minecraft:entity.spider.ambient master @a[tag=ec.rd_participant,scores={ec.fx_snd=1..}] ~ ~ ~ 2.0 0.3

# Announce (§5 staged fan-out — forerunner stripped)
data modify storage evercraft:notify stage.c set value [{text:"Poison cloud spreading! Find an antidote flower!",color:"dark_purple"}]
scoreboard players set #ndur ec.temp 45
# (Council Upgrade 2026-06-10, balance MC-1: telegraph promoted emit_now → emit_crit_telegraph (40t TTL) + flash subtitle copy — Off players keep combat-safety warnings, a buried telegraph dies instead of firing post-hit.)
data modify storage evercraft:notify flash.c set from storage evercraft:notify stage.c
execute as @a[tag=ec.rd_participant] run function evercraft:util/notify/emit_crit_telegraph
execute as @a[tag=ec.rd_participant] run function evercraft:util/notify/flash
