# The Ashen Lord — Light Soul Lantern
# Called as the lantern entity being lit

tag @s remove ec.rd_al_lantern_off
tag @s add ec.rd_al_lantern_on
tag @s add ec.rd_al_lantern_just_lit

# VFX
particle minecraft:soul_fire_flame ~ ~1 ~ 0.3 0.5 0.3 0.05 8
playsound minecraft:block.respawn_anchor.charge master @a[tag=ec.rd_participant,scores={ec.fx_snd=1..}] ~ ~ ~ 1.0 1.2

# Notify (§5 staged fan-out — forerunner stripped)
data modify storage evercraft:notify stage.c set value [{text:"A soul lantern ignites! The Ashen Lord's fire immunity weakens...",color:"aqua"}]
scoreboard players set #ndur ec.temp 45
execute as @a[tag=ec.rd_participant] run function evercraft:util/notify/emit
