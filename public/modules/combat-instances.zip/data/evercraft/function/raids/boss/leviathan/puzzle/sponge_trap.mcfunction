# The Leviathan — Trap Sponge Slot (spawns guardians)
# Runs as the sponge slot interaction entity

# VFX: ominous rumble
particle minecraft:angry_villager ~ ~1 ~ 0.5 0.5 0.5 0.1 5
particle minecraft:bubble ~ ~1 ~ 1 1 1 0.2 15
playsound minecraft:entity.elder_guardian.curse master @a[tag=ec.rd_participant,scores={ec.fx_snd=1..}] ~ ~ ~ 1.0 1.2

# Warning (§5 staged fan-out — ✖ mirror)
data modify storage evercraft:notify stage.c set value [{text:"✖ ",color:"red"},{text:"TRAP! ",color:"dark_red",bold:true},{text:"Guardians emerge from the walls!",color:"red"},{text:" ✖",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute as @a[tag=ec.rd_participant] run function evercraft:util/notify/emit

# Spawn 3 guardians near the trap
execute positioned ~ ~ ~ run summon guardian ~1 ~1 ~ {Tags:["ec.rd_lv_guard"],PersistenceRequired:1b,Silent:1b}
execute positioned ~ ~ ~ run summon guardian ~-1 ~1 ~ {Tags:["ec.rd_lv_guard"],PersistenceRequired:1b,Silent:1b}
execute positioned ~ ~ ~ run summon guardian ~ ~1 ~1 {Tags:["ec.rd_lv_guard"],PersistenceRequired:1b,Silent:1b}

# Damage nearby players
execute positioned ~ ~ ~ run effect give @a[tag=ec.rd_participant,distance=..4] mining_fatigue 10 1 false
