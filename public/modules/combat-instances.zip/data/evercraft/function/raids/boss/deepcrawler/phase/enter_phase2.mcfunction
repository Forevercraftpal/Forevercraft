# The Deepcrawler — Enter Phase 2: The Rail Storm
# Minecarts activate, spider swarms begin

# Boss dialogue (§5 staged fan-out)
data modify storage evercraft:notify stage.c set value [{text:"The Deepcrawler",color:"gray",bold:true},{text:" screeches — the rails begin to rattle!",color:"dark_gray",italic:true}]
scoreboard players set #ndur ec.temp 50
execute as @a[tag=ec.rd_participant] run function evercraft:util/notify/emit

# Phase 2 VFX
execute as @e[type=silverfish,tag=ec.rd_boss,limit=1] at @s run particle minecraft:dust{color:[0.8,0.5,0.2],scale:2.0} ~ ~1 ~ 4 2 4 0 30
execute as @e[type=silverfish,tag=ec.rd_boss,limit=1] at @s run playsound minecraft:entity.silverfish.hurt master @a[tag=ec.rd_participant,scores={ec.fx_snd=1..}] ~ ~ ~ 2.0 0.3

# Force boss above ground
scoreboard players set #rd_dc_above ec.var 1
execute as @e[type=silverfish,tag=ec.rd_boss,limit=1] run effect clear @s invisibility
execute as @e[type=silverfish,tag=ec.rd_boss,limit=1] run effect clear @s resistance

# Boss speed increase
execute as @e[type=silverfish,tag=ec.rd_boss,limit=1] run attribute @s movement_speed modifier add evercraft:rd_boss/phase2 0.2 add_multiplied_base
execute as @e[type=silverfish,tag=ec.rd_boss,limit=1] run attribute @s attack_damage modifier add evercraft:rd_boss/phase2 0.5 add_multiplied_base

# Start first lever sequence opportunity
function evercraft:raids/boss/deepcrawler/puzzle/lever_sequence

# Announce (§5 staged fan-out — forerunner stripped)
data modify storage evercraft:notify stage.c set value [{text:"The rail system activates! Watch for incoming carts!",color:"yellow",bold:true}]
scoreboard players set #ndur ec.temp 40
execute as @a[tag=ec.rd_participant] run function evercraft:util/notify/emit
