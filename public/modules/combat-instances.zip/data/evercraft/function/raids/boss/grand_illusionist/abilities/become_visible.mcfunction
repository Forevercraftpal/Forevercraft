# Grand Illusionist — Become Visible (Phase 2)
# Boss briefly appears to attack

execute as @e[type=#evercraft:aoe_targets,tag=ec.rd_boss,limit=1] run effect clear @s invisibility
execute as @e[type=#evercraft:aoe_targets,tag=ec.rd_boss,limit=1] run effect give @s glowing 5 0 true

# §5 staged fan-out — combat ping, ✦ mirror
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"The Illusionist reveals itself!",color:"red"},{text:" ✦",color:"gold"}]
scoreboard players set #ndur ec.temp 45
execute as @a[tag=ec.rd_participant] run function evercraft:util/notify/emit

execute as @e[type=#evercraft:aoe_targets,tag=ec.rd_boss,limit=1] at @s run playsound minecraft:entity.evoker.ambient hostile @a[tag=ec.rd_participant,scores={ec.fx_snd=1..}] ~ ~ ~ 1.0 0.8
execute as @e[type=#evercraft:aoe_targets,tag=ec.rd_boss,limit=1] at @s run particle minecraft:flash{color:[1.0,1.0,1.0,1.0]} ~ ~1 ~ 0 0 0 0 1
