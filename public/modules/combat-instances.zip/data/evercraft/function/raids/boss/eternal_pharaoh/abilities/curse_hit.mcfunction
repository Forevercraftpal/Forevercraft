# The Eternal Pharaoh — Curse Hit
# Called as the cursed player at their position
# Randomly applies one of 3 curses

# Roll 1-3 for curse type
execute store result score #rd_temp ec.var run random value 1..3

# Curse of Slowness: Slowness III for 10 seconds
execute if score #rd_temp ec.var matches 1 run effect give @s slowness 10 2
data modify storage evercraft:notify stage.c set value [{text:"Curse of Slowness!",color:"dark_purple",bold:true},{text:" Use the altar to cleanse!",color:"gray"}]
scoreboard players set #ndur ec.temp 45
execute if score #rd_temp ec.var matches 1 run function evercraft:util/notify/emit

# Curse of Weakness: Weakness II for 10 seconds
execute if score #rd_temp ec.var matches 2 run effect give @s weakness 10 1
data modify storage evercraft:notify stage.c set value [{text:"Curse of Weakness!",color:"dark_purple",bold:true},{text:" Use the altar to cleanse!",color:"gray"}]
scoreboard players set #ndur ec.temp 45
execute if score #rd_temp ec.var matches 2 run function evercraft:util/notify/emit

# Curse of Blindness: Blindness for 8 seconds
execute if score #rd_temp ec.var matches 3 run effect give @s blindness 8 0
data modify storage evercraft:notify stage.c set value [{text:"Curse of Blindness!",color:"dark_purple",bold:true},{text:" Use the altar to cleanse!",color:"gray"}]
scoreboard players set #ndur ec.temp 45
execute if score #rd_temp ec.var matches 3 run function evercraft:util/notify/emit

# VFX on cursed player
particle minecraft:witch ~ ~1 ~ 0.5 0.5 0.5 0.05 8
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.evoker.prepare_attack master @s ~ ~ ~ 1.0 0.5
