# Gilded Tyrant — Gold Bombardment
# Summon a marker above a random player, it falls via tick and explodes on landing
# Uses armor_stand instead of falling_block to avoid placing real gold blocks

# Pick a random participant position and summon bomb marker above them
execute as @a[tag=ec.rd_participant,limit=1,sort=random] at @s run summon armor_stand ~ ~12 ~ {Tags:["ec.rd_gt_bomb","ec.rd_minion"],Small:1b,Invisible:1b,Invulnerable:1b,NoGravity:0b,CustomName:{text:"Gold Bomb",color:"gold"},CustomNameVisible:1b}

# VFX
execute as @e[type=#evercraft:aoe_targets,tag=ec.rd_boss,limit=1] at @s run playsound minecraft:entity.arrow.shoot hostile @a[tag=ec.rd_participant,scores={ec.fx_snd=1..}] ~ ~ ~ 1.0 0.4
# §5 staged fan-out — warning, ⚠ mirror
data modify storage evercraft:notify stage.c set value [{text:"⚠ ",color:"gold"},{text:"Golden bombardment incoming!",color:"yellow"},{text:" ⚠",color:"gold"}]
scoreboard players set #ndur ec.temp 45
# (Council Upgrade 2026-06-10, balance MC-1: telegraph promoted emit_now → emit_crit_telegraph (40t TTL) + flash subtitle copy — Off players keep combat-safety warnings, a buried telegraph dies instead of firing post-hit.)
data modify storage evercraft:notify flash.c set from storage evercraft:notify stage.c
execute as @a[tag=ec.rd_participant] run function evercraft:util/notify/emit_crit_telegraph
execute as @a[tag=ec.rd_participant] run function evercraft:util/notify/flash
