# Hollow Sovereign — Begin Silence (damage reflection period)
# Boss glows for 5 seconds. ALL damage dealt to it is reflected back to the attacker.

scoreboard players set #rd_hs_silence ec.var 1
scoreboard players set #rd_hs_silence_timer ec.var 100

# Apply Glowing as visual cue
execute as @e[type=#evercraft:aoe_targets,tag=ec.rd_boss,limit=1] run effect give @s glowing 5 0 true

# Warning (§5 staged fan-out — forerunner stripped)
data modify storage evercraft:notify stage.c set value [{text:"The Sovereign goes SILENT — stop attacking!",color:"red",bold:true}]
scoreboard players set #ndur ec.temp 45
execute as @a[tag=ec.rd_participant] run function evercraft:util/notify/emit

# Sound cue
execute as @e[type=#evercraft:aoe_targets,tag=ec.rd_boss,limit=1] at @s run playsound minecraft:block.sculk_shrieker.shriek hostile @a[tag=ec.rd_participant,scores={ec.fx_snd=1..}] ~ ~ ~ 1.0 0.3
execute as @e[type=#evercraft:aoe_targets,tag=ec.rd_boss,limit=1] at @s run particle minecraft:enchanted_hit ~ ~1 ~ 1 1 1 0.5 15
