# Gatekeeper — Whirlwind Attack (Phase 3)
# 360° slash hitting all entities in 5-block radius, 10 damage

# Warning (§5 staged fan-out — ⚠ mirror)
data modify storage evercraft:notify stage.c set value [{text:"⚠ ",color:"red"},{text:"The Gatekeeper unleashes a whirlwind!",color:"dark_green",bold:true},{text:" ⚠",color:"red"}]
scoreboard players set #ndur ec.temp 45
# (Council Upgrade 2026-06-10, balance MC-1: telegraph promoted emit_now → emit_crit_telegraph (40t TTL) + flash subtitle copy — Off players keep combat-safety warnings, a buried telegraph dies instead of firing post-hit.)
data modify storage evercraft:notify flash.c set from storage evercraft:notify stage.c
execute as @a[tag=ec.rd_participant] run function evercraft:util/notify/emit_crit_telegraph
execute as @a[tag=ec.rd_participant] run function evercraft:util/notify/flash

# AoE damage — 5 block radius
execute as @e[type=#evercraft:aoe_targets,tag=ec.rd_boss,limit=1] at @s run execute as @a[tag=ec.rd_participant,distance=..5] run damage @s 10 minecraft:mob_attack by @e[type=#evercraft:aoe_targets,tag=ec.rd_boss,limit=1]

# Heavy knockback away from boss
execute as @e[type=#evercraft:aoe_targets,tag=ec.rd_boss,limit=1] at @s as @a[tag=ec.rd_participant,distance=..5] at @s facing entity @e[type=#evercraft:aoe_targets,tag=ec.rd_boss,limit=1] feet run tp @s ^ ^ ^-3

# VFX — whirlwind
execute as @e[type=#evercraft:aoe_targets,tag=ec.rd_boss,limit=1] at @s run particle minecraft:sweep_attack ~ ~1 ~ 3 0.5 3 0 5
execute as @e[type=#evercraft:aoe_targets,tag=ec.rd_boss,limit=1] at @s run particle minecraft:cloud ~ ~1 ~ 4 1 4 0.2 15
execute as @e[type=#evercraft:aoe_targets,tag=ec.rd_boss,limit=1] at @s run playsound minecraft:entity.player.attack.sweep hostile @a[tag=ec.rd_participant,scores={ec.fx_snd=1..}] ~ ~ ~ 1.5 0.4
