# The Venomweaver — Egg Sac Hit (Destroyed by Player)
# Called as the egg sac entity

# Clear interaction data
data remove entity @s interaction

# Increase Venomweaver rage (+5% damage per egg destroyed, max 20%)
execute if score #rd_vw_rage ec.var matches ..15 run scoreboard players add #rd_vw_rage ec.var 5

# Apply rage damage modifier to boss (remove old, add new)
execute as @e[type=cave_spider,tag=ec.rd_boss,limit=1] run attribute @s attack_damage modifier remove evercraft:rd_boss/vw_rage

# Calculate rage modifier: rage / 100 (5 = 0.05, 10 = 0.10, etc.)
# Apply via multiply base: +5% per stack
execute if score #rd_vw_rage ec.var matches 5 as @e[type=cave_spider,tag=ec.rd_boss,limit=1] run attribute @s attack_damage modifier add evercraft:rd_boss/vw_rage 0.05 add_multiplied_base
execute if score #rd_vw_rage ec.var matches 10 as @e[type=cave_spider,tag=ec.rd_boss,limit=1] run attribute @s attack_damage modifier add evercraft:rd_boss/vw_rage 0.10 add_multiplied_base
execute if score #rd_vw_rage ec.var matches 15 as @e[type=cave_spider,tag=ec.rd_boss,limit=1] run attribute @s attack_damage modifier add evercraft:rd_boss/vw_rage 0.15 add_multiplied_base
execute if score #rd_vw_rage ec.var matches 20 as @e[type=cave_spider,tag=ec.rd_boss,limit=1] run attribute @s attack_damage modifier add evercraft:rd_boss/vw_rage 0.20 add_multiplied_base

# VFX: egg destroyed
particle minecraft:item_cobweb ~ ~1 ~ 0.5 0.5 0.5 0.1 10
particle minecraft:crit ~ ~1 ~ 0.3 0.3 0.3 0.2 5
playsound minecraft:entity.spider.death master @a[tag=ec.rd_participant,scores={ec.fx_snd=1..}] ~ ~ ~ 1.0 1.2

# Announce
data modify storage evercraft:notify stage.c set value [{text:"Egg sac destroyed! The Venomweaver grows enraged!",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute if score #rd_vw_rage ec.var matches 1.. as @a[tag=ec.rd_participant] run function evercraft:util/notify/emit

# Kill this egg
kill @s
