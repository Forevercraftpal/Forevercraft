# The Deepcrawler — Wrong Lever!
# Carts come from all 4 directions — devastating if players are on rails

# Reset sequence
scoreboard players set #rd_dc_lever_seq ec.var 0

# Damage all participants (10 damage) — Audit #6: add boss attribution
execute as @a[tag=ec.rd_participant] run damage @s 10 minecraft:mob_attack by @e[tag=ec.rd_boss,limit=1]

# VFX: chaotic cart impacts
execute at @e[tag=ec.rd_dc_lever1,limit=1] run particle minecraft:explosion ~ ~0.5 ~ 1 0.5 1 0.3 2
execute at @e[tag=ec.rd_dc_lever2,limit=1] run particle minecraft:explosion ~ ~0.5 ~ 1 0.5 1 0.3 2
execute at @e[tag=ec.rd_dc_lever3,limit=1] run particle minecraft:explosion ~ ~0.5 ~ 1 0.5 1 0.3 2
execute at @e[tag=ec.rd_dc_lever4,limit=1] run particle minecraft:explosion ~ ~0.5 ~ 1 0.5 1 0.3 2
playsound minecraft:entity.minecart.riding master @a[tag=ec.rd_participant,scores={ec.fx_snd=1..}] ~ ~ ~ 2.0 0.2
playsound minecraft:entity.generic.explode master @a[tag=ec.rd_participant,scores={ec.fx_snd=1..}] ~ ~ ~ 1.5 0.5

# Announce
# §5 staged fan-out — combat ping, forerunner stripped
data modify storage evercraft:notify stage.c set value [{text:"WRONG SEQUENCE! Carts from all directions!",color:"dark_red",bold:true}]
scoreboard players set #ndur ec.temp 45
execute as @a[tag=ec.rd_participant] run function evercraft:util/notify/emit_now
