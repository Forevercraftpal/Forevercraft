# Arbiter — Shrink Safe Zone (Phase 2)
# Reduces safe zone radius by 2 blocks (minimum 5)

execute if score #rd_arb_zone_radius ec.var matches ..5 run return 0

scoreboard players remove #rd_arb_zone_radius ec.var 2

# Warning (§5 staged fan-out — ⚠ mirror)
data modify storage evercraft:notify stage.c set value [{text:"⚠ ",color:"aqua"},{text:"The safe zone shrinks! Stay close to the center!",color:"white"},{text:" ⚠",color:"aqua"}]
scoreboard players set #ndur ec.temp 45
# (Council Upgrade 2026-06-10, balance MC-1: telegraph promoted emit_now → emit_crit_telegraph (40t TTL) + flash subtitle copy — Off players keep combat-safety warnings, a buried telegraph dies instead of firing post-hit.)
data modify storage evercraft:notify flash.c set from storage evercraft:notify stage.c
execute as @a[tag=ec.rd_participant] run function evercraft:util/notify/emit_crit_telegraph
execute as @a[tag=ec.rd_participant] run function evercraft:util/notify/flash

# VFX
execute at @e[type=marker,tag=rd.center,limit=1] run playsound minecraft:entity.wind_charge.wind_burst hostile @a[tag=ec.rd_participant,scores={ec.fx_snd=1..}] ~ ~ ~ 1.0 1.0
execute at @e[type=marker,tag=rd.center,limit=1] run particle minecraft:cloud ~ ~1 ~ 8 0.5 8 0.1 10
