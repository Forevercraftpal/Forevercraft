# Spirit Raids — No-Boss Exit (Audit #6 fail-fast for unmapped struct IDs)
# Called from boss/spawn when #rd_boss_id == 0 (struct 14 pillager_outpost / struct 18 ruined_portal)
# Player cleared 10 floors but the structure has no Raid Boss authored.
# Floor-only victory: keep what they earned, skip exit_win full rewards (no exquisite, no +25 coins, no 125 guild, no story hooks, no 120k affinity XP).

# Announce the floor-only finish (§5 staged fan-out — static broadcast, forerunner stripped)
data modify storage evercraft:notify stage.c set value [{text:"This structure holds no Raid Boss. The raid ends in your favor.",color:"gold"}]
scoreboard players set #ndur ec.temp 50
execute as @a[tag=ec.rd_participant] run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"You keep the coins and crates you earned across the 10 floors.",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 40
execute as @a[tag=ec.rd_participant] run function evercraft:util/notify/emit

# Title display
title @a[tag=ec.rd_participant] times 10 60 20
title @a[tag=ec.rd_participant] title {text:"RAID COMPLETE",color:"gold"}
title @a[tag=ec.rd_participant] subtitle {text:"No Raid Boss for this structure",color:"yellow"}

# Soft victory sounds (NOT the full challenge_complete + firework storm of exit_win)
playsound minecraft:ui.toast.challenge_complete master @a[tag=ec.rd_participant,scores={ec.fx_snd=1..}] ~ ~ ~ 1.0 0.8

# Reset boss-alive flag (defensive — was set to 1 in boss/spawn:6)
scoreboard players set #rd_boss_alive ec.var 0

# Teleport players back to saved positions
execute as @a[tag=rd.player] run function evercraft:raids/restore_position

# Cleanup boss-fight state (kills entities, strips tags, resets state)
function evercraft:raids/boss/cleanup
# Cleanup raid room (fills arena with air, removes rd.player tag)
function evercraft:raids/room/cleanup
