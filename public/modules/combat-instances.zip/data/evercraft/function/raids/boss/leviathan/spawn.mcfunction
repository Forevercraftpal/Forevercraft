# The Leviathan (#8) — Spawn
# Ocean Monument raid boss — Javelin class artifact (Soul Piercer)

scoreboard players set #rd_boss_id ec.var 8

# Audit #6: Group B HP scaling parity — DR/party scaling like Group A.
execute as @a[tag=ec.rd_participant,limit=1,sort=random] run function evercraft:raids/boss/setup/scale

# Summon elder guardian variant (guardian with heavy attributes)
execute anchored eyes positioned ^ ^ ^5 run summon guardian ~ ~ ~ {Tags:["ec.rd_boss","ec.rd_lv"],Silent:1b,PersistenceRequired:1b,CanPickUpLoot:0b}

# HP: base 1500 (750 hearts) × hp_scale / 100
scoreboard players set #rd_temp ec.var 1500
scoreboard players operation #rd_temp ec.var *= #rd_hp_scale ec.var
scoreboard players operation #rd_temp ec.var /= #100 adv.temp
scoreboard players operation #rd_boss_hp_max ec.var = #rd_temp ec.var
scoreboard players operation #rd_p2_threshold ec.var = #rd_boss_hp_max ec.var
scoreboard players set #rd_temp ec.var 66
scoreboard players operation #rd_p2_threshold ec.var *= #rd_temp ec.var
scoreboard players operation #rd_p2_threshold ec.var /= #100 adv.temp
scoreboard players operation #rd_p3_threshold ec.var = #rd_boss_hp_max ec.var
scoreboard players set #rd_temp ec.var 33
scoreboard players operation #rd_p3_threshold ec.var *= #rd_temp ec.var
scoreboard players operation #rd_p3_threshold ec.var /= #100 adv.temp

# Audit #6: Set max HP via apply_hp macro (Group A path)
execute store result storage evercraft:raids tmp.hp_mod int 1 run scoreboard players get #rd_boss_hp_max ec.var
execute as @e[type=guardian,tag=ec.rd_boss,limit=1] run function evercraft:raids/boss/setup/apply_hp with storage evercraft:raids tmp
execute as @e[type=guardian,tag=ec.rd_boss,limit=1] run attribute @s scale base set 3.0
execute as @e[type=guardian,tag=ec.rd_boss,limit=1] run attribute @s armor modifier add evercraft:rd_boss/base 12 add_value
execute as @e[type=guardian,tag=ec.rd_boss,limit=1] run attribute @s movement_speed modifier add evercraft:rd_boss/base 0.2 add_multiplied_base
execute as @e[type=guardian,tag=ec.rd_boss,limit=1] run attribute @s attack_damage modifier add evercraft:rd_boss/base 4.0 add_multiplied_base
execute as @e[type=guardian,tag=ec.rd_boss,limit=1] run attribute @s knockback_resistance modifier add evercraft:rd_boss/base 0.8 add_value
# Audit #6: damage scaling parity
scoreboard players operation #rd_temp ec.var = #rd_dmg_scale ec.var
scoreboard players remove #rd_temp ec.var 100
execute if score #rd_temp ec.var matches 1.. store result storage evercraft:raids tmp.dmg_pct double 0.01 run scoreboard players get #rd_temp ec.var
execute if score #rd_temp ec.var matches 1.. as @e[type=guardian,tag=ec.rd_boss,limit=1] run function evercraft:raids/boss/setup/apply_dmg with storage evercraft:raids tmp

# Custom name
execute as @e[type=guardian,tag=ec.rd_boss,limit=1] run data modify entity @s CustomName set value [{text:"☠ ",color:"dark_red"},{text:"The Leviathan",color:"dark_aqua",bold:true},{text:" ☠",color:"dark_red"}]
execute as @e[type=guardian,tag=ec.rd_boss,limit=1] run data modify entity @s CustomNameVisible set value 1b

# Bossbar
bossbar remove evercraft:raid_boss
bossbar add evercraft:raid_boss [{text:"☠ ",color:"dark_red"},{text:"The Leviathan",color:"dark_aqua",bold:true},{text:" ☠",color:"dark_red"}]
bossbar set evercraft:raid_boss color blue
execute store result bossbar evercraft:raid_boss max run scoreboard players get #rd_boss_hp_max ec.var
execute store result bossbar evercraft:raid_boss value run scoreboard players get #rd_boss_hp_max ec.var
bossbar set evercraft:raid_boss visible true
bossbar set evercraft:raid_boss players @a[tag=ec.rd_participant]

# Initialize state (Audit #6: #rd_active=1 redundant — already set by enter.mcfunction)
scoreboard players set #rd_boss_phase ec.var 1
scoreboard players set #rd_timer ec.var 0
scoreboard players set #rd_phase_lock ec.var 0
scoreboard players set #rd_ability_cd ec.var 0

# Boss-specific state
scoreboard players set #rd_lv_laser_cd ec.var 60
scoreboard players set #rd_lv_wave_cd ec.var 240
scoreboard players set #rd_lv_burrow_cd ec.var 0
scoreboard players set #rd_lv_water_level ec.var 0
scoreboard players set #rd_lv_whirl_timer ec.var 0
scoreboard players set #rd_lv_sponges ec.var 0

# Sponge puzzle slots — 6 total: 4 valid, 2 traps
# Spread around arena edges at varied positions
execute anchored eyes positioned ^ ^ ^5 run summon interaction ~12 ~-1 ~8 {Tags:["ec.rd_lv_sponge","ec.rd_lv_sponge_valid","ec.rd_puzzle"],width:1.0f,height:1.0f,response:1b}
execute anchored eyes positioned ^ ^ ^5 run summon interaction ~-10 ~-1 ~14 {Tags:["ec.rd_lv_sponge","ec.rd_lv_sponge_valid","ec.rd_puzzle"],width:1.0f,height:1.0f,response:1b}
execute anchored eyes positioned ^ ^ ^5 run summon interaction ~-15 ~-1 ~-6 {Tags:["ec.rd_lv_sponge","ec.rd_lv_sponge_valid","ec.rd_puzzle"],width:1.0f,height:1.0f,response:1b}
execute anchored eyes positioned ^ ^ ^5 run summon interaction ~8 ~-1 ~-12 {Tags:["ec.rd_lv_sponge","ec.rd_lv_sponge_valid","ec.rd_puzzle"],width:1.0f,height:1.0f,response:1b}
execute anchored eyes positioned ^ ^ ^5 run summon interaction ~-5 ~-1 ~-15 {Tags:["ec.rd_lv_sponge","ec.rd_lv_sponge_trap","ec.rd_puzzle"],width:1.0f,height:1.0f,response:1b}
execute anchored eyes positioned ^ ^ ^5 run summon interaction ~14 ~-1 ~-4 {Tags:["ec.rd_lv_sponge","ec.rd_lv_sponge_trap","ec.rd_puzzle"],width:1.0f,height:1.0f,response:1b}

# Audit #6: redundant `schedule sync_hp 2t` removed (apply_hp already schedules).
# Audit #6: redundant `tag @s add ec.rd_participant` removed (boss/spawn:9 already tagged all rd.player).

# Storage
data modify storage evercraft:raids active set value {boss_name:"The Leviathan",boss_color:"dark_aqua"}

# VFX
execute at @e[type=guardian,tag=ec.rd_boss,limit=1] run particle minecraft:bubble ~ ~1 ~ 2 2 2 0.1 25
execute at @e[type=guardian,tag=ec.rd_boss,limit=1] run particle minecraft:dolphin ~ ~1 ~ 1 1 1 0.05 15
execute at @e[type=guardian,tag=ec.rd_boss,limit=1] run playsound minecraft:entity.elder_guardian.curse master @a[scores={ec.fx_snd=1..}] ~ ~ ~ 1.0 0.6
execute at @e[type=guardian,tag=ec.rd_boss,limit=1] run playsound minecraft:entity.elder_guardian.ambient master @a[scores={ec.fx_snd=1..}] ~ ~ ~ 1.0 0.8

# Announce
# §5 staged fan-out — boss spawn banner, dividers dropped, ☠ mirror
data modify storage evercraft:notify stage.c set value [{text:"☠ ",color:"dark_red"},{text:"The Leviathan",color:"dark_aqua",bold:true},{text:" rises from the depths!",color:"blue"},{text:" ☠",color:"dark_red"}]
scoreboard players set #ndur ec.temp 50
execute as @a run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"The water pressure should have killed you...",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 40
execute as @a run function evercraft:util/notify/emit

# --- Boss intro cinematic (lifted from Council #8 Plan 8 retirement, 2026-05-27) ---
data modify storage evercraft:spectator boss set value {name:"Leviathan",subtitle:"The Ocean Given Form"}
execute as @a[tag=ec.rd_participant] run function evercraft:spectator/boss_intro/play
