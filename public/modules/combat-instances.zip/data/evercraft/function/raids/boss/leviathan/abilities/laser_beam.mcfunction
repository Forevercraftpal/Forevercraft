# The Leviathan — Laser Beam Attack
# Targets random participant, 2-second charge warning, then 15 damage

# Pick a target
execute as @a[tag=ec.rd_participant,sort=random,limit=1] run tag @s add ec.rd_lv_target

# Warning particles + sound (beam windup visual)
execute as @e[type=guardian,tag=ec.rd_boss,limit=1] at @s run particle minecraft:electric_spark ~ ~1 ~ 0.3 0.3 0.3 0.1 5
execute as @e[type=guardian,tag=ec.rd_boss,limit=1] at @s run playsound minecraft:entity.guardian.attack master @a[tag=ec.rd_participant,scores={ec.fx_snd=1..}] ~ ~ ~ 1.5 0.5

# Announce target (§5 staged fan-out — forerunner stripped)
data modify storage evercraft:notify stage.c set value [{text:"The Leviathan locks its gaze on you!",color:"aqua",bold:true}]
scoreboard players set #ndur ec.temp 45
# (Council Upgrade 2026-06-10, balance MC-1: telegraph promoted emit_now → emit_crit_telegraph (40t TTL) + flash subtitle copy — Off players keep combat-safety warnings, a buried telegraph dies instead of firing post-hit.)
data modify storage evercraft:notify flash.c set from storage evercraft:notify stage.c
execute as @a[tag=ec.rd_lv_target] run function evercraft:util/notify/emit_crit_telegraph
execute as @a[tag=ec.rd_lv_target] run function evercraft:util/notify/flash

# Schedule the beam impact 2 seconds later
schedule function evercraft:raids/boss/leviathan/abilities/laser_impact 40t
