# The Mossheart Warden — Activate Spawner Core
# Activates one inactive core

# Tag a random inactive core
execute as @e[tag=ec.rd_mw_core,tag=!ec.rd_mw_core_active,sort=random,limit=1] run tag @s add ec.rd_mw_core_active
scoreboard players add #rd_mw_cores_active ec.var 1

# VFX
execute as @e[tag=ec.rd_mw_core,tag=ec.rd_mw_core_active,limit=1,sort=nearest] at @s run particle minecraft:flame ~ ~1 ~ 0.5 0.5 0.5 0.1 10
execute as @e[tag=ec.rd_mw_core,tag=ec.rd_mw_core_active,limit=1,sort=nearest] at @s run playsound minecraft:block.respawn_anchor.charge master @a[tag=ec.rd_participant,scores={ec.fx_snd=1..}] ~ ~ ~ 1.0 0.8

# §5 staged fan-out — combat ping, forerunner stripped
data modify storage evercraft:notify stage.c set value [{text:"A spawner core activates! Destroy it to stop the mob flow!",color:"yellow"}]
scoreboard players set #ndur ec.temp 45
execute as @a[tag=ec.rd_participant] run function evercraft:util/notify/emit
