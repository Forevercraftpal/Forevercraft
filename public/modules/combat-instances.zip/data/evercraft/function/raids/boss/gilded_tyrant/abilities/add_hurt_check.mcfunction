# Gilded Tyrant — Piglin Add Death Check (Phase 2 mechanic)
# Called when a piglin add takes damage — if health low, kill and heal boss

# Check if piglin health is critically low (6 HP or less — about to die)
execute store result score #rd_temp ec.var run data get entity @s Health
execute unless score #rd_temp ec.var matches ..6 run return 0

# Kill the piglin and heal boss
kill @s

# Heal boss 10 HP
execute as @e[type=#evercraft:aoe_targets,tag=ec.rd_boss,limit=1] run effect give @s instant_health 1 0 true

# Feedback — boss heals from piglin death
execute as @e[type=#evercraft:aoe_targets,tag=ec.rd_boss,limit=1] at @s run particle minecraft:happy_villager ~ ~1.5 ~ 0.5 0.5 0.5 0.1 3
# §5 staged fan-out — combat ping, indent stripped
data modify storage evercraft:notify stage.c set value [{text:"The Tyrant absorbs fallen piglin essence!",color:"red",italic:true}]
scoreboard players set #ndur ec.temp 45
execute as @a[tag=ec.rd_participant] run function evercraft:util/notify/emit
# Audit #6: gold-shard mechanic — piglin death drops +5 rd.gold (cap 100) per participant
scoreboard players add @a[tag=ec.rd_participant,scores={rd.gold=..95}] rd.gold 5
scoreboard players set @a[tag=ec.rd_participant,scores={rd.gold=96..}] rd.gold 100
execute as @e[type=#evercraft:aoe_targets,tag=ec.rd_boss,limit=1] at @s run playsound minecraft:entity.witch.drink hostile @a[tag=ec.rd_participant,scores={ec.fx_snd=1..}] ~ ~ ~ 0.8 1.2
