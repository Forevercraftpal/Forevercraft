# Arbiter — Start Calm (Eye of the Storm)
# 40-tick window where boss is vulnerable (3x damage)

# Visual indicator — boss glows
execute as @e[type=#evercraft:aoe_targets,tag=ec.rd_boss,limit=1] run effect give @s glowing 3 0 true

# Remove boss armor temporarily (3x vulnerability)
execute as @e[type=#evercraft:aoe_targets,tag=ec.rd_boss,limit=1] run attribute @s armor modifier add evercraft:raid_boss/calm -20.0 add_value

# Announce (§5 staged fan-out — ✦ mirror)
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"green"},{text:"The Eye of the Storm! Strike now!",color:"green",bold:true},{text:" ✦",color:"green"}]
scoreboard players set #ndur ec.temp 45
execute as @a[tag=ec.rd_participant] run function evercraft:util/notify/emit

# VFX — calm
execute as @e[type=#evercraft:aoe_targets,tag=ec.rd_boss,limit=1] at @s run particle minecraft:happy_villager ~ ~1 ~ 2 1 2 0.1 5
execute as @e[type=#evercraft:aoe_targets,tag=ec.rd_boss,limit=1] at @s run playsound minecraft:block.beacon.activate hostile @a[tag=ec.rd_participant,scores={ec.fx_snd=1..}] ~ ~ ~ 1.0 1.2
