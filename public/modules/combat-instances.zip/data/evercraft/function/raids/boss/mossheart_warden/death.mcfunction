# The Mossheart Warden — Death Handler

# Boss-specific cleanup
kill @e[tag=ec.rd_mw_core]
kill @e[tag=ec.rd_mw_gate]
kill @e[tag=ec.rd_mw_mob]
kill @e[tag=ec.rd_mw_safe_zone]

# Victory dialogue (§5 staged fan-out — static broadcast)
data modify storage evercraft:notify stage.c set value [{text:"The Mossheart Warden",color:"green",bold:true},{text:" crumbles, the moss retreating into the stone.",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 50
execute as @a[tag=ec.rd_participant] run function evercraft:util/notify/emit

# Loot drops to all participants
execute as @a[tag=ec.rd_participant] at @s run function evercraft:raids/boss/mossheart_warden/loot
