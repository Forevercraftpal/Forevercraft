# The Venomweaver — Egg Sac Hatch
# Called as the egg sac entity at its position — spawns 4 baby cave spiders

# Spawn 4 small cave spiders
summon cave_spider ~ ~ ~ {Tags:["ec.rd_minion","ec.rd_vw_spider"],PersistenceRequired:1b}
summon cave_spider ~1 ~ ~ {Tags:["ec.rd_minion","ec.rd_vw_spider"],PersistenceRequired:1b}
summon cave_spider ~ ~ ~1 {Tags:["ec.rd_minion","ec.rd_vw_spider"],PersistenceRequired:1b}
summon cave_spider ~-1 ~ ~-1 {Tags:["ec.rd_minion","ec.rd_vw_spider"],PersistenceRequired:1b}

# VFX: hatch burst
particle minecraft:item_cobweb ~ ~0.5 ~ 0.8 0.5 0.8 0.1 13
particle minecraft:item_slime ~ ~0.5 ~ 0.5 0.3 0.5 0.05 8
playsound minecraft:entity.spider.ambient master @a[tag=ec.rd_participant,scores={ec.fx_snd=1..}] ~ ~ ~ 1.5 1.8

# Announce (§5 staged fan-out — forerunner stripped)
data modify storage evercraft:notify stage.c set value [{text:"An egg sac has hatched!",color:"red",italic:true}]
scoreboard players set #ndur ec.temp 45
execute as @a[tag=ec.rd_participant] run function evercraft:util/notify/emit

# Kill egg sac
kill @s
