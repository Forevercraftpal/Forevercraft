# Hollow Sovereign — Death (boss defeated!)
# Drop loot to all participants

# Kill shadow copies
kill @e[tag=ec.rd_hs_fake]
kill @e[tag=ec.rd_tendril]

# Boss-specific death dialogue (§5 staged fan-out — static broadcast)
data modify storage evercraft:notify stage.c set value [{text:"\"The Hollow Throne... stands empty once more...\"",color:"dark_aqua",italic:true}]
scoreboard players set #ndur ec.temp 50
execute as @a[tag=ec.rd_participant] run function evercraft:util/notify/emit

# Drop loot to each participant
execute as @a[tag=ec.rd_participant] at @s run function evercraft:raids/boss/hollow_sovereign/loot

# Audit #6: rd.kills had 0 readers pack-wide — writer archived per W7 dead-scoreboard sweep.
