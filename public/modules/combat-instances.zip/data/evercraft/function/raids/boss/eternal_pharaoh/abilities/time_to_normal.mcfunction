# The Eternal Pharaoh — Enter Normal State
# Boss empowered, players slowed

scoreboard players set #rd_ep_time_state ec.var 0
scoreboard players set #rd_ep_time_timer ec.var 200

# Boss: Speed III
execute as @e[type=husk,tag=ec.rd_boss,limit=1] run effect clear @s slowness
execute as @e[type=husk,tag=ec.rd_boss,limit=1] run effect give @s speed 12 2 true

# VFX: gold shimmer
execute as @e[type=husk,tag=ec.rd_boss,limit=1] at @s run particle minecraft:dust{color:[0.9,0.7,0.1],scale:2.0} ~ ~1 ~ 2 1 2 0.1 8
playsound minecraft:block.beacon.deactivate master @a[tag=ec.rd_participant,scores={ec.fx_snd=1..}] ~ ~ ~ 1.0 0.8

# §5 staged fan-out — combat ping, forerunner stripped
data modify storage evercraft:notify stage.c set value [{text:"Time reverts! ",color:"gold",bold:true},{text:"The Pharaoh is empowered!",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute as @a[tag=ec.rd_participant] run function evercraft:util/notify/emit
