# Gatekeeper — Death (boss defeated!)
# Drop loot to all participants

# Kill remaining minions
kill @e[tag=ec.rd_gk_portal]
kill @e[tag=ec.rd_gk_wall]

# Clear dimension effects
effect clear @a[tag=ec.rd_participant] jump_boost

# Boss-specific death dialogue (§5 staged fan-out — static broadcast)
data modify storage evercraft:notify stage.c set value [{text:"\"The gate... opens... at last...\"",color:"dark_green",italic:true}]
scoreboard players set #ndur ec.temp 50
execute as @a[tag=ec.rd_participant] run function evercraft:util/notify/emit

# Drop loot to each participant
execute as @a[tag=ec.rd_participant] at @s run function evercraft:raids/boss/gatekeeper/loot

# Audit #6: rd.kills had 0 readers pack-wide — writer archived per W7 dead-scoreboard sweep.
