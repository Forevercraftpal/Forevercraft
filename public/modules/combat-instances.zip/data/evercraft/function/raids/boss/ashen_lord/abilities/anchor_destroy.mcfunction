# The Ashen Lord — Fire Anchor Destroyed
# Called as the anchor entity that reached 5 hits

# Reduce remaining anchor count
scoreboard players remove #rd_al_anchors ec.var 1

# Destruction VFX
particle minecraft:explosion ~ ~1 ~ 0.5 0.5 0.5 0.5 3
particle minecraft:soul_fire_flame ~ ~1 ~ 1 1 1 0.1 15
playsound minecraft:entity.generic.explode master @a[tag=ec.rd_participant,scores={ec.fx_snd=1..}] ~ ~ ~ 1.0 0.8
playsound minecraft:block.beacon.deactivate master @a[tag=ec.rd_participant,scores={ec.fx_snd=1..}] ~ ~ ~ 1.0 1.0

# Announce (§5 staged fan-out — forerunner stripped)
data modify storage evercraft:notify stage.c set value [{text:"Fire anchor destroyed! 3 remaining — heat reduced!",color:"green"}]
scoreboard players set #ndur ec.temp 45
execute if score #rd_al_anchors ec.var matches 3 as @a[tag=ec.rd_participant] run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Fire anchor destroyed! 2 remaining!",color:"green"}]
scoreboard players set #ndur ec.temp 45
execute if score #rd_al_anchors ec.var matches 2 as @a[tag=ec.rd_participant] run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Fire anchor destroyed! 1 remaining!",color:"yellow"}]
scoreboard players set #ndur ec.temp 45
execute if score #rd_al_anchors ec.var matches 1 as @a[tag=ec.rd_participant] run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"All fire anchors destroyed! The heat subsides!",color:"green",bold:true}]
scoreboard players set #ndur ec.temp 45
execute if score #rd_al_anchors ec.var matches 0 as @a[tag=ec.rd_participant] run function evercraft:util/notify/emit

# Kill the anchor entity
kill @s
