# The Deepcrawler (#11) — Spawn
# Mineshaft raid boss — Archer class artifact (Soulstring)

scoreboard players set #rd_boss_id ec.var 11

# Audit #6: Group B HP scaling parity — DR/party scaling like Group A.
execute as @a[tag=ec.rd_participant,limit=1,sort=random] run function evercraft:raids/boss/setup/scale

# Summon silverfish (massive)
execute anchored eyes positioned ^ ^ ^5 run summon silverfish ~ ~ ~ {Tags:["ec.rd_boss","ec.rd_dc"],Silent:1b,PersistenceRequired:1b,CanPickUpLoot:0b}

# HP: base 1400 × hp_scale / 100
scoreboard players set #rd_temp ec.var 1400
scoreboard players operation #rd_temp ec.var *= #rd_hp_scale ec.var
scoreboard players operation #rd_temp ec.var /= #100 adv.temp
scoreboard players operation #rd_boss_hp_max ec.var = #rd_temp ec.var
scoreboard players operation #rd_p2_threshold ec.var = #rd_boss_hp_max ec.var
scoreboard players set #rd_temp ec.var 66
scoreboard players operation #rd_p2_threshold ec.var *= #rd_temp ec.var
scoreboard players operation #rd_p2_threshold ec.var /= #100 adv.temp
scoreboard players operation #rd_p3_threshold ec.var = #rd_boss_hp_max ec.var
scoreboard players set #rd_temp ec.var 33
scoreboard players operation #rd_p3_threshold ec.var *= #rd_temp ec.var
scoreboard players operation #rd_p3_threshold ec.var /= #100 adv.temp

# Audit #6: Set max HP via apply_hp macro
execute store result storage evercraft:raids tmp.hp_mod int 1 run scoreboard players get #rd_boss_hp_max ec.var
execute as @e[type=silverfish,tag=ec.rd_boss,limit=1] run function evercraft:raids/boss/setup/apply_hp with storage evercraft:raids tmp
execute as @e[type=silverfish,tag=ec.rd_boss,limit=1] run attribute @s scale base set 5.0
execute as @e[type=silverfish,tag=ec.rd_boss,limit=1] run attribute @s armor modifier add evercraft:rd_boss/base 10 add_value
execute as @e[type=silverfish,tag=ec.rd_boss,limit=1] run attribute @s movement_speed modifier add evercraft:rd_boss/base 0.6 add_multiplied_base
execute as @e[type=silverfish,tag=ec.rd_boss,limit=1] run attribute @s attack_damage modifier add evercraft:rd_boss/base 3.0 add_multiplied_base
execute as @e[type=silverfish,tag=ec.rd_boss,limit=1] run attribute @s knockback_resistance modifier add evercraft:rd_boss/base 0.8 add_value
# Audit #6: damage scaling parity
scoreboard players operation #rd_temp ec.var = #rd_dmg_scale ec.var
scoreboard players remove #rd_temp ec.var 100
execute if score #rd_temp ec.var matches 1.. store result storage evercraft:raids tmp.dmg_pct double 0.01 run scoreboard players get #rd_temp ec.var
execute if score #rd_temp ec.var matches 1.. as @e[type=silverfish,tag=ec.rd_boss,limit=1] run function evercraft:raids/boss/setup/apply_dmg with storage evercraft:raids tmp

# Custom name
execute as @e[type=silverfish,tag=ec.rd_boss,limit=1] run data modify entity @s CustomName set value [{text:"\u2620 ",color:"dark_gray"},{text:"The Deepcrawler",color:"gray",bold:true},{text:" \u2620",color:"dark_gray"}]
execute as @e[type=silverfish,tag=ec.rd_boss,limit=1] run data modify entity @s CustomNameVisible set value 1b

# Bossbar
bossbar remove evercraft:raid_boss
bossbar add evercraft:raid_boss [{text:"\u2620 ",color:"dark_gray"},{text:"The Deepcrawler",color:"gray",bold:true},{text:" \u2620",color:"dark_gray"}]
bossbar set evercraft:raid_boss color white
execute store result bossbar evercraft:raid_boss max run scoreboard players get #rd_boss_hp_max ec.var
execute store result bossbar evercraft:raid_boss value run scoreboard players get #rd_boss_hp_max ec.var
bossbar set evercraft:raid_boss visible true
bossbar set evercraft:raid_boss players @a[tag=ec.rd_participant]

# State (Audit #6: #rd_active=1 redundant — enter.mcfunction set it)
scoreboard players set #rd_boss_phase ec.var 1
scoreboard players set #rd_timer ec.var 0
scoreboard players set #rd_phase_lock ec.var 0
scoreboard players set #rd_ability_cd ec.var 0
scoreboard players set #rd_dc_burrow_cd ec.var 60
scoreboard players set #rd_dc_stala_cd ec.var 0
scoreboard players set #rd_dc_above ec.var 1
scoreboard players set #rd_dc_cart_cd ec.var 0
scoreboard players set #rd_dc_dark_timer ec.var 0
scoreboard players set #rd_dc_lever_seq ec.var 0

# Spawn 8 wall emergence positions (markers around arena perimeter)
execute at @e[type=silverfish,tag=ec.rd_boss,limit=1] run summon marker ~15 ~1 ~0 {Tags:["ec.rd_mechanic","ec.rd_dc_wall_pos"]}
execute at @e[type=silverfish,tag=ec.rd_boss,limit=1] run summon marker ~-15 ~1 ~0 {Tags:["ec.rd_mechanic","ec.rd_dc_wall_pos"]}
execute at @e[type=silverfish,tag=ec.rd_boss,limit=1] run summon marker ~0 ~1 ~15 {Tags:["ec.rd_mechanic","ec.rd_dc_wall_pos"]}
execute at @e[type=silverfish,tag=ec.rd_boss,limit=1] run summon marker ~0 ~1 ~-15 {Tags:["ec.rd_mechanic","ec.rd_dc_wall_pos"]}
execute at @e[type=silverfish,tag=ec.rd_boss,limit=1] run summon marker ~10 ~1 ~10 {Tags:["ec.rd_mechanic","ec.rd_dc_wall_pos"]}
execute at @e[type=silverfish,tag=ec.rd_boss,limit=1] run summon marker ~-10 ~1 ~10 {Tags:["ec.rd_mechanic","ec.rd_dc_wall_pos"]}
execute at @e[type=silverfish,tag=ec.rd_boss,limit=1] run summon marker ~10 ~1 ~-10 {Tags:["ec.rd_mechanic","ec.rd_dc_wall_pos"]}
execute at @e[type=silverfish,tag=ec.rd_boss,limit=1] run summon marker ~-10 ~1 ~-10 {Tags:["ec.rd_mechanic","ec.rd_dc_wall_pos"]}

# Spawn 4 rail lever interactions (at cardinal directions)
execute at @e[type=silverfish,tag=ec.rd_boss,limit=1] run summon interaction ~18 ~1 ~0 {Tags:["ec.rd_mechanic","ec.rd_dc_lever","ec.rd_dc_lever1"],width:1.5f,height:2.0f,response:1b}
execute at @e[type=silverfish,tag=ec.rd_boss,limit=1] run summon interaction ~-18 ~1 ~0 {Tags:["ec.rd_mechanic","ec.rd_dc_lever","ec.rd_dc_lever2"],width:1.5f,height:2.0f,response:1b}
execute at @e[type=silverfish,tag=ec.rd_boss,limit=1] run summon interaction ~0 ~1 ~18 {Tags:["ec.rd_mechanic","ec.rd_dc_lever","ec.rd_dc_lever3"],width:1.5f,height:2.0f,response:1b}
execute at @e[type=silverfish,tag=ec.rd_boss,limit=1] run summon interaction ~0 ~1 ~-18 {Tags:["ec.rd_mechanic","ec.rd_dc_lever","ec.rd_dc_lever4"],width:1.5f,height:2.0f,response:1b}

# Audit #6: redundant `schedule sync_hp 2t` removed (apply_hp already schedules).
# Audit #6: redundant `tag @s add ec.rd_participant` removed (boss/spawn:9 already tagged all rd.player).
data modify storage evercraft:raids active set value {boss_name:"The Deepcrawler",boss_color:"gray"}

# VFX
execute at @e[type=silverfish,tag=ec.rd_boss,limit=1] run particle minecraft:dust{color:[0.5,0.5,0.5],scale:1.5} ~ ~1 ~ 3 1 3 0 20
execute at @e[type=silverfish,tag=ec.rd_boss,limit=1] run playsound minecraft:entity.silverfish.ambient master @a[scores={ec.fx_snd=1..}] ~ ~ ~ 2.0 0.3
execute at @e[type=silverfish,tag=ec.rd_boss,limit=1] run playsound minecraft:entity.wither.spawn master @a[scores={ec.fx_snd=1..}] ~ ~ ~ 0.8 0.8

# \u00a75 staged fan-out \u2014 boss spawn banner, dividers dropped, \u2620 mirror
data modify storage evercraft:notify stage.c set value [{text:"\u2620 ",color:"dark_gray"},{text:"The Deepcrawler",color:"gray",bold:true},{text:" erupts from the stone!",color:"dark_gray"},{text:" \u2620",color:"dark_gray"}]
scoreboard players set #ndur ec.temp 50
execute as @a run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"The rails lead down. Always down...",color:"dark_gray",italic:true}]
scoreboard players set #ndur ec.temp 40
execute as @a run function evercraft:util/notify/emit

# --- Boss intro cinematic (lifted from Council #8 Plan 8 retirement, 2026-05-27) ---
data modify storage evercraft:spectator boss set value {name:"Deepcrawler",subtitle:"Terror of the Mines"}
execute as @a[tag=ec.rd_participant] run function evercraft:spectator/boss_intro/play
