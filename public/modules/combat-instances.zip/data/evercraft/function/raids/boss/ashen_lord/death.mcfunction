# The Ashen Lord — Death Handler
# Drops loot, cleans up boss-specific entities

# Boss-specific cleanup
kill @e[tag=ec.rd_al_spawner]
kill @e[tag=ec.rd_al_blaze]
kill @e[tag=ec.rd_al_lantern]
kill @e[tag=ec.rd_al_safe]
kill @e[tag=ec.rd_al_anchor]

# Victory dialogue (§5 staged fan-out — static broadcast)
data modify storage evercraft:notify stage.c set value [{text:"The Ashen Lord",color:"red",bold:true},{text:" crumbles to ash, the eternal fire extinguished at last.",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 50
execute as @a[tag=ec.rd_participant] run function evercraft:util/notify/emit

# Loot drops to all participants
execute as @a[tag=ec.rd_participant] at @s run function evercraft:raids/boss/ashen_lord/loot
