# The Eternal Pharaoh — Death Handler

kill @e[tag=ec.rd_ep_mummy]
kill @e[tag=ec.rd_ep_altar]
kill @e[tag=ec.rd_ep_pillar]

# §5 staged fan-out — static broadcast
data modify storage evercraft:notify stage.c set value [{text:"The Eternal Pharaoh",color:"gold",bold:true},{text:" crumbles to sand, the dynasty's curse finally broken.",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 50
execute as @a[tag=ec.rd_participant] run function evercraft:util/notify/emit

execute as @a[tag=ec.rd_participant] at @s run function evercraft:raids/boss/eternal_pharaoh/loot
