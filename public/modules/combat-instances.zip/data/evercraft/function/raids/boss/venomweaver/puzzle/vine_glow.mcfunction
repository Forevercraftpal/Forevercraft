# The Venomweaver — Vine Glow (pick a random color)
# Colors: 1=red, 2=blue, 3=green

# Pick random color
execute store result score #rd_vw_glow_color ec.var run random value 1..3

# Apply Glowing to boss (visual cue)
execute as @e[type=cave_spider,tag=ec.rd_boss,limit=1] run effect give @s glowing 5 0 true

# Boss particles matching the chosen color
execute if score #rd_vw_glow_color ec.var matches 1 as @e[type=cave_spider,tag=ec.rd_boss,limit=1] at @s run particle minecraft:dust{color:[1.0,0.2,0.2],scale:2.0} ~ ~1 ~ 1 1 1 0 15
execute if score #rd_vw_glow_color ec.var matches 2 as @e[type=cave_spider,tag=ec.rd_boss,limit=1] at @s run particle minecraft:dust{color:[0.2,0.4,1.0],scale:2.0} ~ ~1 ~ 1 1 1 0 15
execute if score #rd_vw_glow_color ec.var matches 3 as @e[type=cave_spider,tag=ec.rd_boss,limit=1] at @s run particle minecraft:dust{color:[0.2,1.0,0.2],scale:2.0} ~ ~1 ~ 1 1 1 0 15

# Announce (§5 staged fan-out — forerunner stripped)
data modify storage evercraft:notify stage.c set value [{text:"The Venomweaver glows ",color:"gray"},{text:"RED",color:"red",bold:true},{text:"! Hit the matching vine!",color:"gray"}]
scoreboard players set #ndur ec.temp 45
execute if score #rd_vw_glow_color ec.var matches 1 as @a[tag=ec.rd_participant] run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"The Venomweaver glows ",color:"gray"},{text:"BLUE",color:"blue",bold:true},{text:"! Hit the matching vine!",color:"gray"}]
scoreboard players set #ndur ec.temp 45
execute if score #rd_vw_glow_color ec.var matches 2 as @a[tag=ec.rd_participant] run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"The Venomweaver glows ",color:"gray"},{text:"GREEN",color:"green",bold:true},{text:"! Hit the matching vine!",color:"gray"}]
scoreboard players set #ndur ec.temp 45
execute if score #rd_vw_glow_color ec.var matches 3 as @a[tag=ec.rd_participant] run function evercraft:util/notify/emit

# Sound
execute as @e[type=cave_spider,tag=ec.rd_boss,limit=1] at @s run playsound minecraft:block.note_block.chime master @a[tag=ec.rd_participant,scores={ec.fx_snd=1..}] ~ ~ ~ 1.5 1.0
