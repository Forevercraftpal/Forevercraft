# The Mossheart Warden — Gate Stun
# Boss charged into a gate — stunned for 2 seconds

execute as @e[type=iron_golem,tag=ec.rd_boss,limit=1] run effect give @s slowness 2 4 true
execute as @e[type=iron_golem,tag=ec.rd_boss,limit=1] run effect give @s weakness 2 4 true

# VFX
execute as @e[type=iron_golem,tag=ec.rd_boss,limit=1] at @s run particle minecraft:crit ~ ~1 ~ 1 1 1 0.3 10
execute as @e[type=iron_golem,tag=ec.rd_boss,limit=1] at @s run playsound minecraft:entity.iron_golem.damage master @a[tag=ec.rd_participant,scores={ec.fx_snd=1..}] ~ ~ ~ 1.5 0.6

# §5 staged fan-out — combat ping, forerunner stripped
data modify storage evercraft:notify stage.c set value [{text:"The Warden is stunned by the gate!",color:"green",bold:true}]
scoreboard players set #ndur ec.temp 45
execute as @a[tag=ec.rd_participant] run function evercraft:util/notify/emit
