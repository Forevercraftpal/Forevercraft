# Grand Illusionist — Ravager Died (Phase 3 panic trigger)
# Boss drops all illusions, panics, attacks recklessly

scoreboard players set #rd_gi_ravager_dead ec.var 1

# Remove all copies and totems
kill @e[tag=ec.rd_gi_fake]
kill @e[tag=ec.rd_gi_totem]

# Boss panics — reduce armor (vulnerability)
execute as @e[type=#evercraft:aoe_targets,tag=ec.rd_boss,limit=1] run attribute @s armor modifier add evercraft:raid_boss/panic -8.0 add_value

# Increase attack speed via movement speed
execute as @e[type=#evercraft:aoe_targets,tag=ec.rd_boss,limit=1] run attribute @s movement_speed modifier add evercraft:raid_boss/panic 0.5 add_multiplied_base

# Dialogue (§5 staged fan-out — indent stripped)
data modify storage evercraft:notify stage.c set value [{text:"\"NO! MY BEAST! YOU WILL PAY FOR THIS!\"",color:"red",bold:true}]
scoreboard players set #ndur ec.temp 50
execute as @a[tag=ec.rd_participant] run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"The Illusionist panics — no more tricks!",color:"green",italic:true}]
scoreboard players set #ndur ec.temp 40
execute as @a[tag=ec.rd_participant] run function evercraft:util/notify/emit

# VFX
execute as @e[type=#evercraft:aoe_targets,tag=ec.rd_boss,limit=1] at @s run particle minecraft:explosion ~ ~1 ~ 1 1 1 0.1 2
execute as @e[type=#evercraft:aoe_targets,tag=ec.rd_boss,limit=1] at @s run playsound minecraft:entity.evoker.hurt hostile @a[tag=ec.rd_participant,scores={ec.fx_snd=1..}] ~ ~ ~ 1.5 0.5
