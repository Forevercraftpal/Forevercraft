# Spirit Raids — Boss Room Entry (Floor 10)
# Called when raid floor advances to 10

# Announce boss floor (\u00a75 staged fan-out \u2014 static broadcast, forerunner stripped)
data modify storage evercraft:notify stage.c set value [{text:"Floor 10 \u2014 ",color:"red"},{text:"The Boss Awaits",color:"dark_red",bold:true,italic:true}]
scoreboard players set #ndur ec.temp 50
execute as @a[tag=rd.player] run function evercraft:util/notify/emit

# #12: the per-boss flavor prompt now renders INSIDE the vote panel (raids/vote/panel/fill, by
# #rd_struct) — start_boss_vote → panel/spawn draws it. The 15 raids/boss/prompts/* chat emitters
# are now orphaned dead code (DECISIONS D3 council cluster, with start_entry_vote). The dg.player
# tag dance is removed with them (it existed only so the prompts' dg.player selector resolved).

# Start boss entry vote (spawns the world-anchored vote panel with the boss flavor + buttons + tally)
function evercraft:raids/vote/start_boss_vote

# Sound effect — ominous
execute as @a[tag=rd.player,scores={ec.fx_snd=1..}] at @s run playsound minecraft:entity.warden.heartbeat master @s ~ ~ ~ 1 0.3
execute as @a[tag=rd.player,scores={ec.fx_snd=1..}] at @s run playsound minecraft:entity.elder_guardian.curse master @s ~ ~ ~ 0.5 0.5
