# Spirit Raids — Boss Timeout (10 minutes elapsed)
# Boss enrages and wipes the raid — routes through exit_lose for proper cleanup

# §5 staged fan-out — static broadcast, forerunner stripped
data modify storage evercraft:notify stage.c set value [{text:"Time has run out. The boss consumes all...",color:"dark_red",bold:true}]
scoreboard players set #ndur ec.temp 50
execute as @a[tag=ec.rd_participant] run function evercraft:util/notify/emit

# Disable boss alive flag to prevent on_death re-trigger
scoreboard players set #rd_boss_alive ec.var 0

# Boss cleanup (kill boss entities, remove bossbar)
function evercraft:raids/boss/cleanup

# Route through exit_lose for proper XP penalty, teleport home, and room cleanup
function evercraft:raids/exit_lose
