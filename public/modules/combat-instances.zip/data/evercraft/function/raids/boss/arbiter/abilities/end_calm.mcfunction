# Arbiter — End Calm (Storm resumes)
# Boss returns to full defense, tornado resumes

# Remove vulnerability modifier
execute as @e[type=#evercraft:aoe_targets,tag=ec.rd_boss,limit=1] run attribute @s armor modifier remove evercraft:raid_boss/calm

# Remove glowing
execute as @e[type=#evercraft:aoe_targets,tag=ec.rd_boss,limit=1] run effect clear @s glowing

# Announce (§5 staged fan-out — ⚠ mirror)
data modify storage evercraft:notify stage.c set value [{text:"⚠ ",color:"red"},{text:"The storm returns!",color:"red"},{text:" ⚠",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute as @a[tag=ec.rd_participant] run function evercraft:util/notify/emit

# VFX — storm resumption
execute as @e[type=#evercraft:aoe_targets,tag=ec.rd_boss,limit=1] at @s run particle minecraft:cloud ~ ~1 ~ 3 2 3 0.3 15
execute as @e[type=#evercraft:aoe_targets,tag=ec.rd_boss,limit=1] at @s run playsound minecraft:entity.lightning_bolt.impact hostile @a[tag=ec.rd_participant,scores={ec.fx_snd=1..}] ~ ~ ~ 1.0 0.8
