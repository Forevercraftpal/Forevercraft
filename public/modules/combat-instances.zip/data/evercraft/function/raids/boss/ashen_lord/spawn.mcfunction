# The Ashen Lord (#7) — Spawn
# Called as the summoning player, at their position
# Nether Fortress raid boss — Sentinel class artifact (Ashcrown Mace)

# Set boss ID
scoreboard players set #rd_boss_id ec.var 7

# Audit #6: Group B HP scaling parity — run DR/party scaling like Group A castle bosses do.
# Sets #rd_hp_scale (100..300) + #rd_dmg_scale (100..220).
execute as @a[tag=ec.rd_participant,limit=1,sort=random] run function evercraft:raids/boss/setup/scale

# ── Summon the boss entity ──
# Wither skeleton with fire-themed equipment
execute anchored eyes positioned ^ ^ ^5 run summon wither_skeleton ~ ~ ~ {Tags:["ec.rd_boss","ec.rd_al"],Silent:1b,PersistenceRequired:1b,CanPickUpLoot:0b,equipment:{mainhand:{id:"minecraft:netherite_sword",components:{"minecraft:enchantments":{"minecraft:fire_aspect":2},"minecraft:custom_name":{text:"Ashen Blade",color:"red",italic:false}}}}}

# ── HP Calculation ──
# Base: 1800 HP (900 hearts) — highest in Group B after Crimson Bulwark
# Audit #6: scale by #rd_hp_scale (DR + party) for parity with castle Group A bosses.
scoreboard players set #rd_temp ec.var 1800
scoreboard players operation #rd_temp ec.var *= #rd_hp_scale ec.var
scoreboard players operation #rd_temp ec.var /= #100 adv.temp
scoreboard players operation #rd_boss_hp_max ec.var = #rd_temp ec.var

# Phase thresholds: P2 at 66%, P3 at 33% — derived from scaled HP
scoreboard players operation #rd_p2_threshold ec.var = #rd_boss_hp_max ec.var
scoreboard players set #rd_temp ec.var 66
scoreboard players operation #rd_p2_threshold ec.var *= #rd_temp ec.var
scoreboard players operation #rd_p2_threshold ec.var /= #100 adv.temp
scoreboard players operation #rd_p3_threshold ec.var = #rd_boss_hp_max ec.var
scoreboard players set #rd_temp ec.var 33
scoreboard players operation #rd_p3_threshold ec.var *= #rd_temp ec.var
scoreboard players operation #rd_p3_threshold ec.var /= #100 adv.temp

# ── Apply attributes ──
# Audit #6: Set max HP via setup/apply_hp macro (matches Group A castle bosses).
# Macro sets max_health base + tag ec.rd_initializing + schedules sync_hp 2t.
execute store result storage evercraft:raids tmp.hp_mod int 1 run scoreboard players get #rd_boss_hp_max ec.var
execute as @e[type=wither_skeleton,tag=ec.rd_boss,limit=1] run function evercraft:raids/boss/setup/apply_hp with storage evercraft:raids tmp
# (apply_hp already adds ec.rd_initializing tag + schedules sync_hp 2t — do not duplicate)
execute as @e[type=wither_skeleton,tag=ec.rd_boss,limit=1] run attribute @s scale base set 2.0
execute as @e[type=wither_skeleton,tag=ec.rd_boss,limit=1] run attribute @s armor modifier add evercraft:rd_boss/base 15 add_value
execute as @e[type=wither_skeleton,tag=ec.rd_boss,limit=1] run attribute @s movement_speed modifier add evercraft:rd_boss/base 0.3 add_multiplied_base
execute as @e[type=wither_skeleton,tag=ec.rd_boss,limit=1] run attribute @s attack_damage modifier add evercraft:rd_boss/base 3.0 add_multiplied_base
execute as @e[type=wither_skeleton,tag=ec.rd_boss,limit=1] run attribute @s knockback_resistance modifier add evercraft:rd_boss/base 0.7 add_value
# Audit #6: damage scaling parity — apply #rd_dmg_scale as additional modifier (matches castle path).
scoreboard players operation #rd_temp ec.var = #rd_dmg_scale ec.var
scoreboard players remove #rd_temp ec.var 100
execute if score #rd_temp ec.var matches 1.. store result storage evercraft:raids tmp.dmg_pct double 0.01 run scoreboard players get #rd_temp ec.var
execute if score #rd_temp ec.var matches 1.. as @e[type=wither_skeleton,tag=ec.rd_boss,limit=1] run function evercraft:raids/boss/setup/apply_dmg with storage evercraft:raids tmp

# Fire resistance (immune to fire/lava — thematic)
execute as @e[type=wither_skeleton,tag=ec.rd_boss,limit=1] run effect give @s fire_resistance infinite 0 true

# Custom name
execute as @e[type=wither_skeleton,tag=ec.rd_boss,limit=1] run data modify entity @s CustomName set value [{text:"☠ ",color:"dark_red"},{text:"The Ashen Lord",color:"red",bold:true},{text:" ☠",color:"dark_red"}]
execute as @e[type=wither_skeleton,tag=ec.rd_boss,limit=1] run data modify entity @s CustomNameVisible set value 1b

# ── Bossbar ──
bossbar remove evercraft:raid_boss
bossbar add evercraft:raid_boss [{text:"☠ ",color:"dark_red"},{text:"The Ashen Lord",color:"red",bold:true},{text:" ☠",color:"dark_red"}]
bossbar set evercraft:raid_boss color red
execute store result bossbar evercraft:raid_boss max run scoreboard players get #rd_boss_hp_max ec.var
execute store result bossbar evercraft:raid_boss value run scoreboard players get #rd_boss_hp_max ec.var
bossbar set evercraft:raid_boss visible true
bossbar set evercraft:raid_boss players @a[tag=ec.rd_participant]

# ── Initialize state ── (Audit #6: #rd_active=1 already set by enter.mcfunction — redundant set removed)
scoreboard players set #rd_boss_phase ec.var 1
scoreboard players set #rd_timer ec.var 0
scoreboard players set #rd_phase_lock ec.var 0
scoreboard players set #rd_ability_cd ec.var 0

# Boss-specific state
scoreboard players set #rd_al_fire_cd ec.var 0
scoreboard players set #rd_al_skull_cd ec.var 0
scoreboard players set #rd_al_spawner_cd ec.var 0
scoreboard players set #rd_al_safe_timer ec.var 0
scoreboard players set #rd_al_heat_timer ec.var 0
scoreboard players set #rd_al_anchors ec.var 4
scoreboard players set #rd_al_lanterns_lit ec.var 0

# ── Spawn 4 blaze spawner pillars (marker entities) ──
execute at @e[type=wither_skeleton,tag=ec.rd_boss,limit=1] run summon marker ~10 ~ ~10 {Tags:["ec.rd_mechanic","ec.rd_al_spawner","ec.rd_al_sp1"]}
execute at @e[type=wither_skeleton,tag=ec.rd_boss,limit=1] run summon marker ~-10 ~ ~10 {Tags:["ec.rd_mechanic","ec.rd_al_spawner","ec.rd_al_sp2"]}
execute at @e[type=wither_skeleton,tag=ec.rd_boss,limit=1] run summon marker ~10 ~ ~-10 {Tags:["ec.rd_mechanic","ec.rd_al_spawner","ec.rd_al_sp3"]}
execute at @e[type=wither_skeleton,tag=ec.rd_boss,limit=1] run summon marker ~-10 ~ ~-10 {Tags:["ec.rd_mechanic","ec.rd_al_spawner","ec.rd_al_sp4"]}

# ── Spawn 4 soul lanterns (interaction entities for puzzle) ──
execute at @e[type=wither_skeleton,tag=ec.rd_boss,limit=1] run summon interaction ~15 ~1 ~15 {Tags:["ec.rd_puzzle","ec.rd_al_lantern","ec.rd_al_lantern_off"],width:1.5f,height:2.0f,response:1b}
execute at @e[type=wither_skeleton,tag=ec.rd_boss,limit=1] run summon interaction ~-15 ~1 ~15 {Tags:["ec.rd_puzzle","ec.rd_al_lantern","ec.rd_al_lantern_off"],width:1.5f,height:2.0f,response:1b}
execute at @e[type=wither_skeleton,tag=ec.rd_boss,limit=1] run summon interaction ~15 ~1 ~-15 {Tags:["ec.rd_puzzle","ec.rd_al_lantern","ec.rd_al_lantern_off"],width:1.5f,height:2.0f,response:1b}
execute at @e[type=wither_skeleton,tag=ec.rd_boss,limit=1] run summon interaction ~-15 ~1 ~-15 {Tags:["ec.rd_puzzle","ec.rd_al_lantern","ec.rd_al_lantern_off"],width:1.5f,height:2.0f,response:1b}

# Audit #6: redundant `tag @s add ec.rd_participant` removed (boss/spawn:9 already tagged all rd.player).

# ── Boss storage for announcements ──
data modify storage evercraft:raids active set value {boss_name:"The Ashen Lord",boss_color:"red"}

# Audit #6: redundant `schedule sync_hp 2t` removed (setup/apply_hp already schedules it).

# ── Spawn VFX ──
execute at @e[type=wither_skeleton,tag=ec.rd_boss,limit=1] run particle minecraft:explosion ~ ~1 ~ 1 1 1 0.5 10
execute at @e[type=wither_skeleton,tag=ec.rd_boss,limit=1] run particle minecraft:flame ~ ~1 ~ 1 2 1 0.1 50
execute at @e[type=wither_skeleton,tag=ec.rd_boss,limit=1] run particle minecraft:lava ~ ~1 ~ 1 1 1 0.5 15
execute at @e[type=wither_skeleton,tag=ec.rd_boss,limit=1] run playsound minecraft:entity.wither.spawn master @a[scores={ec.fx_snd=1..}] ~ ~ ~ 1.0 0.6
execute at @e[type=wither_skeleton,tag=ec.rd_boss,limit=1] run playsound minecraft:entity.blaze.shoot master @a[scores={ec.fx_snd=1..}] ~ ~ ~ 1.0 0.4

# ── Announce ──
# §5 staged fan-out — boss spawn banner, dividers dropped, ☠ mirror
data modify storage evercraft:notify stage.c set value [{text:"☠ ",color:"dark_red"},{text:"The Ashen Lord",color:"red",bold:true},{text:" has awakened!",color:"gold"},{text:" ☠",color:"dark_red"}]
scoreboard players set #ndur ec.temp 50
execute as @a run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"The fortress burns from within...",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 40
execute as @a run function evercraft:util/notify/emit

# --- Boss intro cinematic (lifted from Council #8 Plan 8 retirement, 2026-05-27) ---
data modify storage evercraft:spectator boss set value {name:"Ashen Lord",subtitle:"Born from Wither Ash"}
execute as @a[tag=ec.rd_participant] run function evercraft:spectator/boss_intro/play
