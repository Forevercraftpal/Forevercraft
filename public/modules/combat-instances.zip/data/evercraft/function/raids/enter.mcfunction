# Wiring Audit B (2026-05-29) W8: Spirit Raids — Enter Raid Room (per-party handoff MACRO).
# Called with storage evercraft:_shared cart for $(pid) from spirit_raid/confirm_descend OR
# raids/check_entry (Floor 10 ceremony). Saves positions, cleans up THIS PARTY's dungeon state,
# teleports to raid room.

# Announce entry (this party's participants) — §5 staged fan-out, forerunner stripped
data modify storage evercraft:notify stage.c set value [{text:"The raid begins...",color:"red"}]
scoreboard players set #ndur ec.temp 50
$execute as @a[tag=dg.player,tag=p$(pid)] run function evercraft:util/notify/emit
$execute as @a[tag=dg.player,tag=p$(pid),scores={ec.fx_snd=1..}] at @s run playsound minecraft:entity.warden.emerge master @s ~ ~ ~ 0.8 0.5
$execute as @a[tag=dg.player,tag=p$(pid),scores={ec.fx_snd=1..}] at @s run playsound minecraft:block.end_portal.spawn master @s ~ ~ ~ 0.5 0.3

# Save each participant's original position (for win teleport back)
$execute as @a[tag=dg.player,tag=p$(pid)] at @s run function evercraft:raids/save_position

# Tag this party's dungeon players as raid players
$tag @a[tag=dg.player,tag=p$(pid)] add rd.player
$tag @a[tag=dg.player,tag=p$(pid)] add ec.rd_participant

# Clean up THIS party's dungeon mobs + center (preserve dg.player + p<pid> tags for transition; cleared below)
$kill @e[tag=dg.mob,tag=p$(pid)]
$kill @e[type=marker,tag=dg.center,tag=p$(pid)]

# Set raid state (raid is single-active globally pre-Phase 5 per Joseph Q2 — globals safe)
scoreboard players set #rd_active ec.var 1
scoreboard players set #rd_floor ec.var 0
scoreboard players set #rd_wave ec.var 0
scoreboard players set #rd_boss_alive ec.var 0
scoreboard players set #rd_boss_phase ec.var 0

# Map structure ID to boss ID
# Audit #6 (2026-05-28): struct/boss IDs are NOT 1:1 — explicit mapping required.
scoreboard players set #rd_boss_id ec.var 0
execute if score #rd_struct ec.var matches 1 run scoreboard players set #rd_boss_id ec.var 1
execute if score #rd_struct ec.var matches 2 run scoreboard players set #rd_boss_id ec.var 2
execute if score #rd_struct ec.var matches 3 run scoreboard players set #rd_boss_id ec.var 3
execute if score #rd_struct ec.var matches 4 run scoreboard players set #rd_boss_id ec.var 4
execute if score #rd_struct ec.var matches 5 run scoreboard players set #rd_boss_id ec.var 5
execute if score #rd_struct ec.var matches 6 run scoreboard players set #rd_boss_id ec.var 6
execute if score #rd_struct ec.var matches 7 run scoreboard players set #rd_boss_id ec.var 7
execute if score #rd_struct ec.var matches 8 run scoreboard players set #rd_boss_id ec.var 8
execute if score #rd_struct ec.var matches 9 run scoreboard players set #rd_boss_id ec.var 9
execute if score #rd_struct ec.var matches 10 run scoreboard players set #rd_boss_id ec.var 10
execute if score #rd_struct ec.var matches 11 run scoreboard players set #rd_boss_id ec.var 11
execute if score #rd_struct ec.var matches 12 run scoreboard players set #rd_boss_id ec.var 12
execute if score #rd_struct ec.var matches 13 run scoreboard players set #rd_boss_id ec.var 13
execute if score #rd_struct ec.var matches 17 run scoreboard players set #rd_boss_id ec.var 11
execute if score #rd_struct ec.var matches 19 run scoreboard players set #rd_boss_id ec.var 12
# Structs 14, 18 unmapped: boss_id = 0 sentinel → boss/spawn returns no_boss_exit

# Build raid room and teleport players
function evercraft:raids/room/build

# Reset THIS party's dungeon per-party state (R6: pt.dg_active before dg.player/p<pid> tag remove)
$scoreboard players set #dg_wave.$(pid) ec.var 0
$scoreboard players set #dg_timer.$(pid) ec.var 0
$scoreboard players set #dg_type.$(pid) ec.var 0
$scoreboard players set #dg_floor.$(pid) ec.var 0
$scoreboard players set #dg_instance.$(pid) ec.var 0
$scoreboard players set #dg_difficulty.$(pid) ec.var 0
$scoreboard players set #dg_modifier.$(pid) ec.var 0
$scoreboard players set #dg_descent_timer.$(pid) ec.var 0
$scoreboard players set #dg_players.$(pid) ec.var 0
$scoreboard players set #dg_struct_id.$(pid) ec.var 0

# Clear per-party affixes (clears all #dg_afx_*.<pid> scratches via macro)
function evercraft:dungeon/affix/clear with storage evercraft:_shared cart

# R6: pt.dg_active cleared BEFORE tag removal
$scoreboard players set @a[tag=dg.player,tag=p$(pid)] pt.dg_active 0
$tag @a[tag=dg.player,tag=p$(pid)] remove dg.player
$tag @a[tag=p$(pid)] remove p$(pid)
$tag @a[tag=p$(pid)] remove dg.awaiting_descent

# Aggregate I3: clear #dg_any_active only if no other party still has a participant active
execute unless entity @a[scores={pt.dg_active=1}] run scoreboard players set #dg_any_active ec.var 0

# Start first raid floor
function evercraft:raids/floor/advance
