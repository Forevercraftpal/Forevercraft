# Spirit Raids — Check Entry (DR Gate) — Wiring Audit B (2026-05-29) W8 per-party MACRO.
# Called from dungeon/complete with storage evercraft:_shared cart for $(pid) when floor 10 cleared.
# Checks if a participant meets DR requirement, then runs the Spirit Realm ceremony OR falls back
# to normal dungeon completion.

# Read participant DR from luck attribute (DR = luck * 10, stored as integer) — this party only.
$execute store result score #rd_dr_check ec.var run attribute @a[tag=dg.player,tag=p$(pid),limit=1] minecraft:luck get 10

# Floor-10 dungeon reward — granted UP-FRONT, exactly once per party, for EVERY Floor-10 clear regardless
# of the DR/descent choice (Council #6, 2026-06-02). Runs while #dg_*.$(pid) are still live (they're only
# zeroed downstream in raids/enter). Removes the old XOR where descenders forfeited the crate for the raid
# gamble — they now keep the Floor-10 crate AND earn the raid reward. The two former downstream calls
# (check_entry low-DR + check_prompt decline/timeout) are deleted; this single up-front call covers them.
function evercraft:dungeon/reward with storage evercraft:_shared cart

# DR < 50 (DR 5): deny entry, run normal dungeon completion — §5 staged fan-out, forerunner stripped
data modify storage evercraft:notify stage.c set value [{text:"Floor 10 Cleared!",color:"gold",bold:true}]
scoreboard players set #ndur ec.temp 50
$execute if score #rd_dr_check ec.var matches ..49 as @a[tag=dg.player,tag=p$(pid)] run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"The depths stir beyond this point, but your Dream Rate is too low.",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 40
$execute if score #rd_dr_check ec.var matches ..49 as @a[tag=dg.player,tag=p$(pid)] run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Reach ",color:"gray"},{text:"DR 5",color:"gold",bold:true},{text:" to enter the Raid Room.",color:"gray"}]
scoreboard players set #ndur ec.temp 40
$execute if score #rd_dr_check ec.var matches ..49 as @a[tag=dg.player,tag=p$(pid)] run function evercraft:util/notify/emit
# Fall through to normal dungeon complete for sub-DR participants. Reward already granted up-front above;
# only cleanup + return remain here (Council #6, 2026-06-02 — old reward call removed to fire-once).
execute if score #rd_dr_check ec.var matches ..49 run function evercraft:dungeon/cleanup with storage evercraft:_shared cart
execute if score #rd_dr_check ec.var matches ..49 run return 0

# DR >= 50 (DR 5+): eligible for the Spirit Raid.
# Floor-10 reward = the Spirit Realm ceremony + descent prompt (Joseph 2026-05-29). Each participant
# gets the per-party prompt; spirit_raid/check_prompt polls sr.prompted (with per-party filter via
# tick_active dispatch).
$execute as @a[tag=dg.player,tag=p$(pid)] run function evercraft:spirit_raid/unlock_check
