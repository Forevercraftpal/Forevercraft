# Spirit Raids — Start Boss Vote (Floor 10 — boss room entry)
# Same mechanics as floor vote but with dramatic styling

# Audit #6: refresh headcount so auto-quorum tracks DCs (was set once at entry, never refreshed)
execute store result score #rd_players ec.var if entity @a[tag=rd.player]

# Set vote state
scoreboard players set #rd_vote_active ec.var 1
scoreboard players set #rd_vote_timer ec.var 600
scoreboard players set #rd_votes_yes ec.var 0
scoreboard players set #rd_votes_no ec.var 0
scoreboard players set #rd_vote_context ec.var 3

# Enable vote trigger for all raid players
scoreboard players enable @a[tag=rd.player] ec.rd_vote
scoreboard players set @a[tag=rd.player] ec.rd_vote 0

# #12 \u2014 show the world-anchored boss-vote panel (was the typed-/trigger chat buttons). The panel's
# hitboxes write the SAME ec.rd_vote, so the resolve path (trigger_handler/process_vote) is unchanged.
# The `enable ec.rd_vote` lines above are now vestigial but harmless \u2014 left per presentation-swap discipline.
function evercraft:raids/vote/panel/spawn
