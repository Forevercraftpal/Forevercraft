# #12 Boss-vote panel — build (run AT rd.center). Per-boss banner + flavor (fill) + the two vote
# buttons (interaction hitboxes — the house-rule fix for the typed /trigger) + a LIVE tally row.
# All rows tagged rd.vote_panel. billboard:center text reads for every party member; the hitboxes
# are fixed boxes sized generously so any clustered party member can aim + right-click.

# Per-boss banner + 3 flavor lines.
function evercraft:raids/vote/panel/fill

# [ Face the Boss ] — west side (−X), generous hitbox.
summon text_display ~-2 ~3.6 ~ {brightness:{block:15,sky:15},billboard:"center",Tags:["rd.vote_panel"],text:{text:"[ Face the Boss ]",color:"dark_red",bold:true},background:1073741824,shadow:true,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.95f,0.95f,0.95f]}}
summon interaction ~-2 ~3.1 ~ {Tags:["rd.vote_panel","rd.vote_yes_click"],width:2.6f,height:1.2f,response:1b}

# [ Retreat ] — east side (+X).
summon text_display ~2 ~3.6 ~ {brightness:{block:15,sky:15},billboard:"center",Tags:["rd.vote_panel"],text:{text:"[ Retreat ]",color:"gray",bold:true},background:1073741824,shadow:true,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.95f,0.95f,0.95f]}}
summon interaction ~2 ~3.1 ~ {Tags:["rd.vote_panel","rd.vote_no_click"],width:2.6f,height:1.2f,response:1b}

# Live tally — placeholder; set_tally bakes the numbers (26.1: {score:} renders blank in text_display),
# and panel/tick re-bakes them each second.
summon text_display ~ ~2.85 ~ {brightness:{block:15,sky:15},billboard:"center",Tags:["rd.vote_panel","rd.vote_tally"],text:["",{text:"Continue: ",color:"gray"},{text:"0",color:"green",bold:true},{text:"   Evacuate: ",color:"gray"},{text:"0",color:"red",bold:true},{text:"   ·   ",color:"dark_gray"},{text:"…",color:"yellow",bold:true},{text:"s left",color:"dark_gray"}],shadow:true,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.8f,0.8f,0.8f]}}
scoreboard players add #rd_votes_yes ec.var 0
scoreboard players add #rd_votes_no ec.var 0
scoreboard players add #rd_vote_secs ec.var 0
execute store result storage evercraft:scorebake args.yes int 1 run scoreboard players get #rd_votes_yes ec.var
execute store result storage evercraft:scorebake args.no int 1 run scoreboard players get #rd_votes_no ec.var
execute store result storage evercraft:scorebake args.secs int 1 run scoreboard players get #rd_vote_secs ec.var
function evercraft:raids/vote/panel/set_tally with storage evercraft:scorebake args
