# Raid vote panel — bake the live tally into the rd.vote_tally text_display (macro).
# 26.1: {score:} renders blank in text_display, so votes/seconds are passed as $(yes)/$(no)/$(secs)
# via storage. Called `with storage evercraft:scorebake args` from panel/build, build_floor and tick.
# Only one vote panel is ever active, so the global limit=1 selector is unambiguous.
$data modify entity @e[type=text_display,tag=rd.vote_tally,limit=1] text set value ["",{text:"Continue: ",color:"gray"},{text:"$(yes)",color:"green",bold:true},{text:"   Evacuate: ",color:"gray"},{text:"$(no)",color:"red",bold:true},{text:"   ·   ",color:"dark_gray"},{text:"$(secs)",color:"yellow",bold:true},{text:"s left",color:"dark_gray"}]
