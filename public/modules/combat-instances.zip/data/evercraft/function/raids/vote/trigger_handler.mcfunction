# Spirit Raids — Vote Trigger Handler
# Called per player when they vote (ec.rd_vote = 1 or 2)

# Vote 1 = continue/enter, Vote 2 = evacuate/turn back
# Tellraw targets both dg.player (entry vote) and rd.player (floor/boss vote)
# Only one tag is active at a time, so no double-send
# §5b direct render — names @s the voter; resolves once in actor context (each tag set is the active audience)
execute if score @s ec.rd_vote matches 1 run scoreboard players add #rd_votes_yes ec.var 1
execute if score @s ec.rd_vote matches 1 run function evercraft:util/notify/whoami
data modify storage evercraft:notify stage.c set value [{text:""},{text:" votes to ",color:"gray"},{text:"continue",color:"green",bold:true}]
data modify storage evercraft:notify stage.c[0].text set from storage evercraft:notify named.who
scoreboard players set #ndur ec.temp 50
execute if score @s ec.rd_vote matches 1 run execute as @a[tag=dg.player] run scoreboard players set #nttl ec.temp 600
execute if score @s ec.rd_vote matches 1 run execute as @a[tag=dg.player] run function evercraft:util/notify/emit_keep
execute if score @s ec.rd_vote matches 1 run function evercraft:util/notify/whoami
data modify storage evercraft:notify stage.c set value [{text:""},{text:" votes to ",color:"gray"},{text:"continue",color:"green",bold:true}]
data modify storage evercraft:notify stage.c[0].text set from storage evercraft:notify named.who
scoreboard players set #ndur ec.temp 50
execute if score @s ec.rd_vote matches 1 run execute as @a[tag=rd.player] run scoreboard players set #nttl ec.temp 600
execute if score @s ec.rd_vote matches 1 run execute as @a[tag=rd.player] run function evercraft:util/notify/emit_keep

execute if score @s ec.rd_vote matches 2 run scoreboard players add #rd_votes_no ec.var 1
execute if score @s ec.rd_vote matches 2 run function evercraft:util/notify/whoami
data modify storage evercraft:notify stage.c set value [{text:""},{text:" votes to ",color:"gray"},{text:"evacuate",color:"red",bold:true}]
data modify storage evercraft:notify stage.c[0].text set from storage evercraft:notify named.who
scoreboard players set #ndur ec.temp 50
execute if score @s ec.rd_vote matches 2 run execute as @a[tag=dg.player] run scoreboard players set #nttl ec.temp 600
execute if score @s ec.rd_vote matches 2 run execute as @a[tag=dg.player] run function evercraft:util/notify/emit_keep
execute if score @s ec.rd_vote matches 2 run function evercraft:util/notify/whoami
data modify storage evercraft:notify stage.c set value [{text:""},{text:" votes to ",color:"gray"},{text:"evacuate",color:"red",bold:true}]
data modify storage evercraft:notify stage.c[0].text set from storage evercraft:notify named.who
scoreboard players set #ndur ec.temp 50
execute if score @s ec.rd_vote matches 2 run execute as @a[tag=rd.player] run scoreboard players set #nttl ec.temp 600
execute if score @s ec.rd_vote matches 2 run execute as @a[tag=rd.player] run function evercraft:util/notify/emit_keep

# Reset trigger and disable for this player (can't vote again)
scoreboard players set @s ec.rd_vote 0
tag @s add rd.voted

# Check if all players have voted — process immediately if so
execute store result score #rd_votes_cast ec.var if entity @a[tag=rd.voted]
execute if score #rd_votes_cast ec.var >= #rd_players ec.var run function evercraft:raids/vote/process_vote
