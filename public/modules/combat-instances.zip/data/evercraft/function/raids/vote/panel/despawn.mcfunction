# #12 Boss-vote panel — despawn. Called from process_vote (after the vote resolves) and from the
# raids/load reload cleanup. Single shared panel → one kill clears it.
kill @e[tag=rd.vote_panel]
