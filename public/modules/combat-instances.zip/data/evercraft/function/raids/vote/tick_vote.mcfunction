# Spirit Raids — Vote Timer Tick
# Called every tick when #rd_vote_active == 1

# Decrement timer
scoreboard players remove #rd_vote_timer ec.var 1

# Drive the vote panel (hitbox scan + countdown refresh) for BOTH the floor vote (context 2, #1
# out-of-scope followup) and the boss vote (context 3, #12). The entry vote (context 1) is retired.
execute if score #rd_vote_context ec.var matches 2..3 run function evercraft:raids/vote/panel/tick

# Timer expired — process vote (no-votes count as evacuate)
execute if score #rd_vote_timer ec.var matches ..0 run function evercraft:raids/vote/process_vote
