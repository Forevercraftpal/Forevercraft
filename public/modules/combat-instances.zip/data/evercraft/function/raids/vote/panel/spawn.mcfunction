# #12 Boss-vote panel — spawn (Option A: ONE world-anchored panel at the arena center, shared by
# the whole party; no per-player session — the vote state is already server-shared). Called from
# start_boss_vote, replacing the typed-/trigger chat buttons. Anchored to rd.center (0 401 0).
execute at @e[type=marker,tag=rd.center,limit=1] run function evercraft:raids/vote/panel/build
