# #12 Boss-vote panel — per-second scan + countdown refresh. Called from tick_vote while
# #rd_vote_active=1 AND #rd_vote_context=3. Input + display ONLY — the tally/quorum/resolve math
# stays in trigger_handler/process_vote. Each button click writes the SAME ec.rd_vote the typed
# /trigger used, so raids/tick:12-14 → trigger_handler counts it unchanged (the house-rule fix).

# [ Face the Boss ] hitbox → ec.rd_vote 1 on the actual clicker (on target), if an un-voted raider.
execute as @e[type=interaction,tag=rd.vote_yes_click] if data entity @s interaction on target if entity @s[tag=rd.player,tag=!rd.voted] run scoreboard players set @s ec.rd_vote 1
# Unified UI-click FX (Joseph 2026-06-05): blip on the clicker (on target) when they cast a Face-the-Boss vote.
execute as @e[type=interaction,tag=rd.vote_yes_click] if data entity @s interaction on target if entity @s[tag=rd.player,tag=!rd.voted] run function evercraft:fx/ui/click
execute as @e[type=interaction,tag=rd.vote_yes_click] if data entity @s interaction run data remove entity @s interaction
# [ Retreat ] hitbox → ec.rd_vote 2.
execute as @e[type=interaction,tag=rd.vote_no_click] if data entity @s interaction on target if entity @s[tag=rd.player,tag=!rd.voted] run scoreboard players set @s ec.rd_vote 2
execute as @e[type=interaction,tag=rd.vote_no_click] if data entity @s interaction on target if entity @s[tag=rd.player,tag=!rd.voted] run function evercraft:fx/ui/click
execute as @e[type=interaction,tag=rd.vote_no_click] if data entity @s interaction run data remove entity @s interaction

# Countdown seconds for the live tally (#rd_vote_timer is in ticks; #20 ec.const = 20).
scoreboard players operation #rd_vote_secs ec.var = #rd_vote_timer ec.var
scoreboard players operation #rd_vote_secs ec.var /= #20 ec.const
# 26.1: {score:} renders blank in text_display, so re-bake the tally (votes + seconds) each second.
execute store result storage evercraft:scorebake args.yes int 1 run scoreboard players get #rd_votes_yes ec.var
execute store result storage evercraft:scorebake args.no int 1 run scoreboard players get #rd_votes_no ec.var
execute store result storage evercraft:scorebake args.secs int 1 run scoreboard players get #rd_vote_secs ec.var
function evercraft:raids/vote/panel/set_tally with storage evercraft:scorebake args

# ===== INSPECT (left-click = what does this button do?) — gui/inspect pattern 2026-06-11 =====
execute as @e[type=interaction,tag=rd.vote_yes_click] if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Vote Yes",b:"Casts your vote to start the raid."}
execute as @e[type=interaction,tag=rd.vote_yes_click] if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=rd.vote_no_click] if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Vote No",b:"Casts your vote against starting the raid."}
execute as @e[type=interaction,tag=rd.vote_no_click] if data entity @s attack run data remove entity @s attack
