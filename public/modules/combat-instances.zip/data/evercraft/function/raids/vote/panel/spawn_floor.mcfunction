# Floor-vote panel — spawn (context 2, between floors 1-9). Twin of panel/spawn but with a generic
# "continue deeper / evacuate" frame instead of boss flavor. Shared party panel at rd.center; reuses
# the SAME rd.vote_yes_click/no_click hitboxes + tally + panel/tick scan as the boss vote. Called from
# start_floor_vote (replaces its typed-/trigger chat buttons — the last raid-vote house-law gap).
execute at @e[type=marker,tag=rd.center,limit=1] run function evercraft:raids/vote/panel/build_floor
