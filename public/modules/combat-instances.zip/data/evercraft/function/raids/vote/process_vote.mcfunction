# Spirit Raids — Process Vote Results
# Called when timer expires OR all players have voted
# #rd_vote_context: 1=entry vote (from dungeon), 2=floor vote, 3=boss vote

# Disable vote state
scoreboard players set #rd_vote_active ec.var 0
scoreboard players set #rd_vote_timer ec.var 0
tag @a remove rd.voted

# #12: tear down the boss-vote panel (no-op for non-boss contexts — there is no panel then).
function evercraft:raids/vote/panel/despawn

# === ENTRY VOTE (context 1): DEPRECATED by Joseph 2026-05-29 — replaced by unlock_check + descent
# prompt at floor 10 (see raids/check_entry). This branch never fires in current flow (no caller
# initiates context=1 vote anymore). If revived, callers must derive pid via _shared/derive_pid_from_party
# AS the triggering dg.player participant and pass cart to raids/enter + dungeon/reward + dungeon/cleanup.
# Wiring Audit B (2026-05-29) W8: AU-B-FOLLOWUP — convert these to per-party form if entry vote ever re-enables.
execute if score #rd_vote_context ec.var matches 1 if score #rd_votes_yes ec.var >= #rd_votes_no ec.var run tellraw @a[limit=1] [{text:"[Raid] ",color:"dark_red"},{text:"[deprecated entry-vote path; see AU-B-FOLLOWUP]",color:"red",italic:true}]
execute if score #rd_vote_context ec.var matches 1 run return 0

# === FLOOR VOTE (context 2): continue to next floor or evacuate ===
execute if score #rd_vote_context ec.var matches 2 if score #rd_votes_yes ec.var >= #rd_votes_no ec.var run function evercraft:raids/floor/advance
execute if score #rd_vote_context ec.var matches 2 if score #rd_votes_yes ec.var >= #rd_votes_no ec.var run return 0
# Evacuate — Audit #6 Q3: curtailed rewards (no exquisite, no +25c, no 125 guild, no story hooks)
data modify storage evercraft:notify stage.c set value [{text:"The party chose to evacuate.",color:"gray"}]
scoreboard players set #ndur ec.temp 45
execute if score #rd_vote_context ec.var matches 2 as @a[tag=rd.player] run function evercraft:util/notify/emit
execute if score #rd_vote_context ec.var matches 2 run function evercraft:raids/exit_evacuate
execute if score #rd_vote_context ec.var matches 2 run return 0

# === BOSS VOTE (context 3): face the boss or retreat ===
execute if score #rd_vote_context ec.var matches 3 if score #rd_votes_yes ec.var >= #rd_votes_no ec.var run function evercraft:raids/boss/spawn
execute if score #rd_vote_context ec.var matches 3 if score #rd_votes_yes ec.var >= #rd_votes_no ec.var run return 0
# Retreat — Audit #6 Q3: curtailed rewards (no exquisite, no +25c, no 125 guild, no story hooks)
data modify storage evercraft:notify stage.c set value [{text:"The party chose to retreat.",color:"gray"}]
scoreboard players set #ndur ec.temp 45
execute if score #rd_vote_context ec.var matches 3 as @a[tag=rd.player] run function evercraft:util/notify/emit
execute if score #rd_vote_context ec.var matches 3 run function evercraft:raids/exit_evacuate
