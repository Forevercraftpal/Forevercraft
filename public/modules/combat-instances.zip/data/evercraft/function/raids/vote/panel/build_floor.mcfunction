# Floor-vote panel — build (run AT rd.center). Banner + [Continue]/[Evacuate] hitbox buttons + live
# tally. The hitbox tags (rd.vote_yes_click → ec.rd_vote 1 = continue, rd.vote_no_click → 2 = evacuate)
# + tally + panel/tick are SHARED with the boss vote (panel/build); only the banner + labels differ.
# Banner
summon text_display ~ ~4.6 ~ {brightness:{block:15,sky:15},billboard:"center",Tags:["rd.vote_panel"],text:["",{text:"⚔ ",color:"gold"},{text:"Floor Cleared",color:"white",bold:true},{text:" ⚔",color:"gold"}],background:1073741824,shadow:true,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[1.3f,1.3f,1.3f]}}
summon text_display ~ ~4.3 ~ {brightness:{block:15,sky:15},billboard:"center",Tags:["rd.vote_panel"],text:{text:"Descend to the next floor, or leave with your spoils?",color:"gray",italic:true},shadow:true,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.65f,0.65f,0.65f]}}

# [ Continue ] — west (−X), writes ec.rd_vote 1 via rd.vote_yes_click.
summon text_display ~-2 ~3.6 ~ {brightness:{block:15,sky:15},billboard:"center",Tags:["rd.vote_panel"],text:{text:"[ Continue ]",color:"green",bold:true},background:1073741824,shadow:true,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.95f,0.95f,0.95f]}}
summon interaction ~-2 ~3.1 ~ {Tags:["rd.vote_panel","rd.vote_yes_click"],width:2.6f,height:1.2f,response:1b}

# [ Evacuate ] — east (+X), writes ec.rd_vote 2 via rd.vote_no_click.
summon text_display ~2 ~3.6 ~ {brightness:{block:15,sky:15},billboard:"center",Tags:["rd.vote_panel"],text:{text:"[ Evacuate ]",color:"red",bold:true},background:1073741824,shadow:true,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.95f,0.95f,0.95f]}}
summon interaction ~2 ~3.1 ~ {Tags:["rd.vote_panel","rd.vote_no_click"],width:2.6f,height:1.2f,response:1b}

# Live tally (same as the boss panel) — placeholder; set_tally bakes numbers (26.1 {score:} blank),
# panel/tick re-bakes each second.
summon text_display ~ ~2.85 ~ {brightness:{block:15,sky:15},billboard:"center",Tags:["rd.vote_panel","rd.vote_tally"],text:["",{text:"Continue: ",color:"gray"},{text:"0",color:"green",bold:true},{text:"   Evacuate: ",color:"gray"},{text:"0",color:"red",bold:true},{text:"   ·   ",color:"dark_gray"},{text:"…",color:"yellow",bold:true},{text:"s left",color:"dark_gray"}],shadow:true,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.8f,0.8f,0.8f]}}
scoreboard players add #rd_votes_yes ec.var 0
scoreboard players add #rd_votes_no ec.var 0
scoreboard players add #rd_vote_secs ec.var 0
execute store result storage evercraft:scorebake args.yes int 1 run scoreboard players get #rd_votes_yes ec.var
execute store result storage evercraft:scorebake args.no int 1 run scoreboard players get #rd_votes_no ec.var
execute store result storage evercraft:scorebake args.secs int 1 run scoreboard players get #rd_vote_secs ec.var
function evercraft:raids/vote/panel/set_tally with storage evercraft:scorebake args
