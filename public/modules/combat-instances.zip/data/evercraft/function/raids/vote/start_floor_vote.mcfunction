# Spirit Raids — Start Floor Vote (between raid floors 1-9)
# Simpler prompt than boss entry

# Audit #6: refresh headcount so auto-quorum tracks DCs (was set once at entry, never refreshed)
execute store result score #rd_players ec.var if entity @a[tag=rd.player]

# Set vote state
scoreboard players set #rd_vote_active ec.var 1
scoreboard players set #rd_vote_timer ec.var 600
scoreboard players set #rd_votes_yes ec.var 0
scoreboard players set #rd_votes_no ec.var 0
scoreboard players set #rd_vote_context ec.var 2

# Enable vote trigger for all raid players
scoreboard players enable @a[tag=rd.player] ec.rd_vote
scoreboard players set @a[tag=rd.player] ec.rd_vote 0

# Show the world-anchored floor-vote panel (was the typed-/trigger chat buttons \u2014 house-law fix,
# mirrors the #12 boss-vote conversion). The panel's hitboxes write the SAME ec.rd_vote, so the
# resolve path (trigger_handler/process_vote, context 2) is unchanged.
function evercraft:raids/vote/panel/spawn_floor
