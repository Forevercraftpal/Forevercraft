# Wiring Audit B (2026-05-29) W6: Announce floor descent (per-party MACRO).
# Called with storage cart for $(pid) + $(current).
$title @a[tag=dg.player,tag=p$(pid)] times 10 60 20
$title @a[tag=dg.player,tag=p$(pid)] title {text:"FLOOR $(current)",color:"dark_red",bold:true}
$title @a[tag=dg.player,tag=p$(pid)] subtitle {text:"Descending deeper...",color:"red"}
# Action-bar echo of the floor-clear title dropped 2026-06-03 (Joseph) — the title above already
# announces the floor; the duplicate action-bar frame just restated it on a second channel (the
# Infinity Castle sibling shows the title only).
