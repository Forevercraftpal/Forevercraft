# Wiring Audit B (2026-05-29) W6: Show descent prompt (per-party MACRO).
# Called with storage cart for $(pid) + $(next).
$tellraw @a[tag=dg.player,tag=p$(pid)] [{text:"  Descend to Floor $(next)? ",color:"yellow"},{text:"[YES]",color:"green",bold:true,click_event:{action:"run_command",command:"/trigger ec.dg_descend set 1"}},{text:" ",color:"gray"},{text:"[NO]",color:"red",bold:true,click_event:{action:"run_command",command:"/trigger ec.dg_descend set 2"}}]
$tellraw @a[tag=dg.player,tag=p$(pid)] [{text:"  Warning: ",color:"gray",italic:true},{text:"Mobs will be significantly stronger!",color:"red",italic:true}]
