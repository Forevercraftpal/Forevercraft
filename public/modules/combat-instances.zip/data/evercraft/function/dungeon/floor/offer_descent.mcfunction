# Wiring Audit B (2026-05-29) W6: Multi-Floor Dungeon — Offer descent (per-party MACRO).
# Called instead of dungeon/complete when floor < 10, with storage cart for $(pid).
# Shows clickable text prompt to this party's participants.

# Floor cleared announcement (per-party)
data modify storage evercraft:notify stage.c set value [{text:"Floor Cleared!",color:"gold",bold:true}]
scoreboard players set #ndur ec.temp 50
$execute as @a[tag=dg.player,tag=p$(pid)] run function evercraft:util/notify/emit

# Calculate next floor number for display (per-party)
$scoreboard players operation #dg_floor_next.$(pid) ec.var = #dg_floor.$(pid) ec.var
$scoreboard players add #dg_floor_next.$(pid) ec.var 1

# Show descent option — stage next-floor int into cart for macro
$execute store result storage evercraft:_shared cart.next int 1 run scoreboard players get #dg_floor_next.$(pid) ec.var
function evercraft:dungeon/floor/show_prompt with storage evercraft:_shared cart

# Start 15-second timer for decision (auto-complete if no descent)
$scoreboard players set #dg_descent_timer.$(pid) ec.var 300
$tag @a[tag=dg.player,tag=p$(pid)] add dg.awaiting_descent

# Re-arm the descend trigger for THIS prompt (per-party). MC auto-disables trigger on use;
# enable at dungeon/load:63 only works for first-ever click — reset to 0 + re-enable each prompt.
$scoreboard players set @a[tag=dg.player,tag=p$(pid)] ec.dg_descend 0
$scoreboard players enable @a[tag=dg.player,tag=p$(pid)] ec.dg_descend
