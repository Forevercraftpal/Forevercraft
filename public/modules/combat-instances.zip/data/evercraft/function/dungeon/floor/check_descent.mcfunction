# Wiring Audit B (2026-05-29) W6: Multi-Floor Dungeon — Check for descent trigger responses (per-party MACRO).
# Called from tick_active when dg.awaiting_descent is active, with storage cart for $(pid).

# Decrement timer (per-party)
$scoreboard players remove #dg_descent_timer.$(pid) ec.var 1

# Check if anyone in this party chose YES (trigger = 1)
$execute if entity @a[tag=dg.player,tag=p$(pid),scores={ec.dg_descend=1}] run function evercraft:dungeon/floor/descend with storage evercraft:_shared cart
$execute if entity @a[tag=dg.player,tag=p$(pid),scores={ec.dg_descend=1}] run return 0

# Check if anyone chose NO (trigger = 2)
$execute if entity @a[tag=dg.player,tag=p$(pid),scores={ec.dg_descend=2}] run function evercraft:dungeon/floor/finish_run with storage evercraft:_shared cart
$execute if entity @a[tag=dg.player,tag=p$(pid),scores={ec.dg_descend=2}] run return 0

# Timer expired — auto-complete (they didn't descend)
$execute if score #dg_descent_timer.$(pid) ec.var matches ..0 run function evercraft:dungeon/floor/finish_run with storage evercraft:_shared cart
