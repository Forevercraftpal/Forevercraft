# Wiring Audit B (2026-05-29) W6: Multi-Floor Dungeon — Descend to next floor (per-party MACRO).
# Called with storage cart for $(pid). Resets waves, scales mobs harder, continues the run.

# Advance floor (per-party)
$scoreboard players add #dg_floor.$(pid) ec.var 1

# Dungeon ender-node (PLAN-chest-nodes §8 / §14.12): a GUARANTEED per-party node on floors 3/5/7/9
# (floor 10 is hooked in dungeon/complete BEFORE the raid handoff). Per-party MACRO -> the spawn uses
# $...@a[tag=dg.player,tag=p$(pid)] selectors (§14.12), reading #dg_floor.$(pid) for the just-advanced
# floor. Each party member claims one PRIVATE pull (dgec.<floor>.looted) + can shift-RC for their ender.
$execute if score #dg_floor.$(pid) ec.var matches 3 run function evercraft:dungeon/ender_node/spawn with storage evercraft:_shared cart
$execute if score #dg_floor.$(pid) ec.var matches 5 run function evercraft:dungeon/ender_node/spawn with storage evercraft:_shared cart
$execute if score #dg_floor.$(pid) ec.var matches 7 run function evercraft:dungeon/ender_node/spawn with storage evercraft:_shared cart
$execute if score #dg_floor.$(pid) ec.var matches 9 run function evercraft:dungeon/ender_node/spawn with storage evercraft:_shared cart

# Track daily floor count for 30-floor daily limit (per-party participants)
$scoreboard players add @a[tag=dg.player,tag=p$(pid)] ec.dg_floors_today 1

# Clear descent state (per-party participants)
$tag @a[tag=p$(pid)] remove dg.awaiting_descent
$scoreboard players set @a[tag=p$(pid)] ec.dg_descend 0
$scoreboard players set #dg_descent_timer.$(pid) ec.var 0

# Reset wave counter (per-party)
$scoreboard players set #dg_wave.$(pid) ec.var 0
$scoreboard players set #dg_timer.$(pid) ec.var 60

# Kill remaining mobs (safety, this party only)
$kill @e[tag=dg.mob,tag=p$(pid)]

# Pick new instance theme for this floor
$execute store result score #dg_instance.$(pid) ec.var run random value 1..16

# Announce floor descent (per-party — show_prompt uses cart.current + cart.pid)
$execute store result storage evercraft:_shared cart.current int 1 run scoreboard players get #dg_floor.$(pid) ec.var
function evercraft:dungeon/floor/announce_descent with storage evercraft:_shared cart

# Effects (per-party)
$playsound minecraft:block.end_portal.spawn master @a[tag=dg.player,tag=p$(pid),scores={ec.fx_snd=1..}] ~ ~ ~ 0.6 0.6
$playsound minecraft:entity.warden.emerge master @a[tag=dg.player,tag=p$(pid),scores={ec.fx_snd=1..}] ~ ~ ~ 0.4 0.8
$execute at @e[type=marker,tag=dg.center,tag=p$(pid),limit=1] run particle minecraft:reverse_portal ~ ~1 ~ 2 1 2 0.05 150 force
