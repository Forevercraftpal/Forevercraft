# Wiring Audit B (2026-05-29) W6: Multi-Floor Dungeon — Finish the run (per-party MACRO).
# Called with storage cart for $(pid) when participant chose not to descend (or timed out).

# Clear descent state (per-party participants)
$tag @a[tag=p$(pid)] remove dg.awaiting_descent
$scoreboard players set @a[tag=p$(pid)] ec.dg_descend 0
$scoreboard players set #dg_descent_timer.$(pid) ec.var 0

# Run normal completion flow (per-party)
function evercraft:dungeon/complete with storage evercraft:_shared cart
