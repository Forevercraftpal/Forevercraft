# Wiring Audit B (2026-05-29) W6: Village Defense — Begin (per-party MACRO).
# Called via village/start with storage cart for $(pid). @s = the player who used the horn.

# Set per-party state — type 2 = village defense
$scoreboard players set #dg_wave.$(pid) ec.var 0
$scoreboard players set #dg_timer.$(pid) ec.var 60
$scoreboard players set #dg_type.$(pid) ec.var 2
$scoreboard players set #dg_floor.$(pid) ec.var 1
$scoreboard players set #dg_descent_timer.$(pid) ec.var 0

# DR difficulty scaling (per-party)
$execute store result score #dg_dr.$(pid) ec.var run attribute @s minecraft:luck get
$scoreboard players set #dg_difficulty.$(pid) ec.var 0
$execute if score #dg_dr.$(pid) ec.var matches 7..17 run scoreboard players set #dg_difficulty.$(pid) ec.var 1
$execute if score #dg_dr.$(pid) ec.var matches 18..29 run scoreboard players set #dg_difficulty.$(pid) ec.var 2
$execute if score #dg_dr.$(pid) ec.var matches 30.. run scoreboard players set #dg_difficulty.$(pid) ec.var 3

# Aggregate gate (I3: 0→1 unconditional)
scoreboard players set #dg_any_active ec.var 1

# Tag the player (single-player village defense — no party fan-out per village's solo design)
tag @s add dg.player
$tag @s add p$(pid)
scoreboard players set @s pt.dg_active 1

# Per-party participant count (always 1 for village defense)
$scoreboard players set #dg_players.$(pid) ec.var 1

# Reset death counter
scoreboard players set @s dg.deaths 0

# Deathless-clear flag (milestone p52): 1 at enter (solo village defense); cleared to 0 by
# dungeon/on_death_outer on death; read at dungeon/reward_player completion.
scoreboard players set @s ec.dng_deathless 1

# Place center marker at player position with p<pid> tag
$execute at @s run summon marker ~ ~ ~ {Tags:["dg.center","ec.entity","p$(pid)"]}

# Stage per-party scratches for downstream
$scoreboard players set #dg_struct_id.$(pid) ec.var 0
$scoreboard players set #dg_is_daily.$(pid) ec.var 0

# Title announcement (single player)
title @s times 5 40 10
title @s title {text:"VILLAGE DEFENSE",color:"dark_green"}
title @s subtitle {text:"The raiders are coming!",color:"green"}

# Sound effects — war horn
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:event.raid.horn master @s ~ ~ ~ 1 1
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.evoker.prepare_wololo master @s ~ ~ ~ 0.5 0.8

# Action-bar announcement (server-news)
function evercraft:util/notify/whoami
data modify storage evercraft:notify stage.c set value [{text:""},{text:" has rallied the village defense!",color:"green"}]
data modify storage evercraft:notify stage.c[0].text set from storage evercraft:notify named.who
scoreboard players set #ndur ec.temp 50
execute as @a run scoreboard players set #nttl ec.temp 600
execute as @a run function evercraft:util/notify/emit_keep

# Leaderboard: record start time
execute store result score @s dg.start_time run time query gametime

# Particles
execute at @s run particle minecraft:happy_villager ~ ~1 ~ 3 1 3 0.1 50 force
execute at @s run particle minecraft:angry_villager ~ ~2 ~ 2 1 2 0.1 30 force
