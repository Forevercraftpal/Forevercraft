# Wiring Audit B (2026-05-29) W6: Village Defense — Complete (per-party MACRO).
# Called with storage cart for $(pid) from tick_active. All 5 waves of raiders defeated.
# Grants reputation + Hero of the Village to this party's participant(s).

# Victory title (per-party)
$title @a[tag=dg.player,tag=p$(pid)] times 10 60 20
$title @a[tag=dg.player,tag=p$(pid)] title {text:"VILLAGE SAVED!",color:"green",bold:true}
$title @a[tag=dg.player,tag=p$(pid)] subtitle {text:"The raiders have been defeated!",color:"dark_green"}

# Action-bar announcement (server-news)
# (Wave 2, 2026-06-10: village-defense brag — actor name baked from the instance player, protected, 30s TTL.)
$execute as @a[tag=dg.player,tag=p$(pid),limit=1] run function evercraft:util/notify/whoami
data modify storage evercraft:notify stage.c set value [{text:""},{text:" has defended the village from raiders!",color:"green",bold:true}]
data modify storage evercraft:notify stage.c[0].text set from storage evercraft:notify named.who
scoreboard players set #ndur ec.temp 50
execute as @a run scoreboard players set #nttl ec.temp 600
execute as @a run function evercraft:util/notify/emit_keep

# Victory sounds (per-party)
$execute as @a[tag=dg.player,tag=p$(pid),scores={ec.fx_snd=1..}] at @s run playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 1 1
$execute as @a[tag=dg.player,tag=p$(pid),scores={ec.fx_snd=1..}] at @s run playsound minecraft:entity.firework_rocket.blast master @s ~ ~ ~ 1 1
$execute as @a[tag=dg.player,tag=p$(pid),scores={ec.fx_snd=1..}] at @s run playsound minecraft:entity.villager.celebrate master @s ~ ~ ~ 1 1

# Victory particles at this party's center
$execute at @e[type=marker,tag=dg.center,tag=p$(pid),limit=1] run particle minecraft:firework ~ ~2 ~ 3 2 3 0.1 200 force
$execute at @e[type=marker,tag=dg.center,tag=p$(pid),limit=1] run particle minecraft:happy_villager ~ ~1 ~ 5 2 5 0.1 100 force

# === REPUTATION REWARD ===
# Grant 200 reputation (between Tier 3 Contract +150 and Tier 4 Commission +250)
$scoreboard players add @a[tag=dg.player,tag=p$(pid)] ec.village_rep 200
$execute as @a[tag=dg.player,tag=p$(pid)] run function evercraft:quests/reputation/save_village_rep
$execute as @a[tag=dg.player,tag=p$(pid)] run function evercraft:quests/reputation/check_rank
data modify storage evercraft:notify stage.c set value [{text:"+200 Village Reputation!",color:"gold"}]
scoreboard players set #ndur ec.temp 50
$execute as @a[tag=dg.player,tag=p$(pid)] run function evercraft:util/notify/emit

# === HERO OF THE VILLAGE (7 minutes = 8400 ticks) ===
$effect give @a[tag=dg.player,tag=p$(pid)] hero_of_the_village 420 0 false
data modify storage evercraft:notify stage.c set value [{text:"Hero of the Village for 7 minutes!",color:"light_purple"}]
scoreboard players set #ndur ec.temp 50
$execute as @a[tag=dg.player,tag=p$(pid)] run function evercraft:util/notify/emit

# === LOOT REWARD (DR-scaled like structure dungeons) ===
function evercraft:dungeon/reward with storage evercraft:_shared cart

# Set village defense 7-day lockout (per-party participants)
# Wiring Audit #15 W5.6: direct multi-target store works because gametime returns same value for
# all participants in one tick.
$execute store result score @a[tag=dg.player,tag=p$(pid)] dg.lo_v run time query gametime
$scoreboard players set @a[tag=dg.player,tag=p$(pid)] dg.lo_any 1

# Leaderboard: compute completion time and check personal best (per-party participants)
$execute as @a[tag=dg.player,tag=p$(pid)] run function evercraft:dungeon/leaderboard/check_time with storage evercraft:_shared cart

# Cleanup (per-party)
function evercraft:dungeon/cleanup with storage evercraft:_shared cart
