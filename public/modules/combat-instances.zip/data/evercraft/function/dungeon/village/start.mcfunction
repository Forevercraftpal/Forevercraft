# Wiring Audit B (2026-05-29) W6: Village Defense — Start (entry shell).
# Called as @s the player who used the horn (advancement evercraft:dungeon/use_horn).
# Performs all entry gates AS @S (need @s scoreboards, predicates), then derives pid
# and dispatches the per-party begin_inner.

# Revoke advancement for reuse
advancement revoke @s only evercraft:dungeon/use_horn

# Check if THIS player's party already has a dungeon active (per-party gate)
data modify storage evercraft:notify stage.c set value [{text:"A dungeon is already in progress for your party!",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute if score @s pt.dg_active matches 1 run function evercraft:util/notify/emit
execute if score @s pt.dg_active matches 1 run return 0

# Symmetric Castle block (Joseph Q9 / AU-B-FOLLOWUP.8): castle/start blocks pt.dg_active; mirror here.
data modify storage evercraft:notify stage.c set value [{text:"You're already in an Infinite Castle run!",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute if score @s pt.ic_active matches 1 run function evercraft:util/notify/emit
execute if score @s pt.ic_active matches 1 run return 0

# Check village-specific 7-day lockout (dg.lo_v) — uses bare globals (sequential entry, safe)
execute store result score #dg_now ec.var run time query gametime
scoreboard players operation #dg_elapsed ec.var = #dg_now ec.var
scoreboard players operation #dg_elapsed ec.var -= @s dg.lo_v
data modify storage evercraft:notify stage.c set value [{text:"You must wait before defending another village!",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute if score @s dg.lo_v matches 1.. if score #dg_elapsed ec.var matches ..503999 run function evercraft:util/notify/emit
execute if score @s dg.lo_v matches 1.. if score #dg_elapsed ec.var matches ..503999 run scoreboard players set #dg_struct_id ec.var 20
execute if score @s dg.lo_v matches 1.. if score #dg_elapsed ec.var matches ..503999 run scoreboard players operation #dg_lockout_val ec.var = @s dg.lo_v
execute if score @s dg.lo_v matches 1.. if score #dg_elapsed ec.var matches ..503999 run function evercraft:dungeon/lockout_info
execute if score @s dg.lo_v matches 1.. if score #dg_elapsed ec.var matches ..503999 run return 0

# Check if player is at a village
data modify storage evercraft:notify stage.c set value [{text:"You must be inside a village to use this!",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute at @s unless predicate evercraft:dungeon/at_village run function evercraft:util/notify/emit
execute at @s unless predicate evercraft:dungeon/at_village run return 0

# Check if horn matches THIS village
execute store result score #dg_horn_vid ec.var run data get entity @s SelectedItem.components."minecraft:custom_data".village_id
data modify storage evercraft:notify stage.c set value [{text:"This horn belongs to a different village!",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute unless score #dg_horn_vid ec.var = @s ec.current_village run function evercraft:util/notify/emit
execute unless score #dg_horn_vid ec.var = @s ec.current_village run return 0

# Check if player is in a GUI menu
data modify storage evercraft:notify stage.c set value [{text:"Close your menu first!",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute if entity @s[tag=Adv.InMenu] run function evercraft:util/notify/emit
execute if entity @s[tag=Adv.InMenu] run return 0
execute if entity @s[tag=TX.InMenu] run function evercraft:util/notify/emit
execute if entity @s[tag=TX.InMenu] run return 0
execute if entity @s[tag=RF.InMenu] run function evercraft:util/notify/emit
execute if entity @s[tag=RF.InMenu] run return 0
execute if entity @s[tag=HS.InMenu] run function evercraft:util/notify/emit
execute if entity @s[tag=HS.InMenu] run return 0

# === BEGIN VILLAGE DEFENSE — derive pid and dispatch inner ===

# Consume the horn (clear 1 from player)
clear @s goat_horn[custom_data~{village_defense:true}] 1

# Derive pid and dispatch
function evercraft:_shared/derive_pid_from_party
function evercraft:dungeon/village/start_inner with storage evercraft:_shared cart
