# Wiring Audit B (2026-05-29) W6: Dungeon — Reward Dispatcher (per-party MACRO).
# Called with storage cart for $(pid). Stages this party's state into globals, then
# runs per-player reward so each participant gets their own DR-based tier.
# Sequential per-tick — race-free because tick_active dispatch is sequential per @s.

# Stage per-pid party state → globals so reward_player reads them
$scoreboard players operation #dg_difficulty ec.var = #dg_difficulty.$(pid) ec.var
$scoreboard players operation #dg_modifier ec.var = #dg_modifier.$(pid) ec.var
$scoreboard players operation #dg_afx_count ec.var = #dg_afx_count.$(pid) ec.var
$scoreboard players operation #dg_floor ec.var = #dg_floor.$(pid) ec.var
$scoreboard players operation #dg_is_daily ec.var = #dg_is_daily.$(pid) ec.var
$scoreboard players operation #dg_struct_id ec.var = #dg_struct_id.$(pid) ec.var
$scoreboard players operation #dg_omen ec.var = #dg_omen.$(pid) ec.var

# Per-participant reward (reward_player overwrites #dg_dr per @s — race-free within sequential exec)
$execute as @a[tag=dg.player,tag=p$(pid)] at @s run function evercraft:dungeon/reward_player

# Advantage tree credit (Joseph 2026-05-29): every dungeon/village completion nudges all 15 trees.
# Factor = dungeon difficulty (per-party 1/2/3 = Normal/Hard/Brutal); default 1 if unset.
scoreboard players set #adv_credit_num ec.var 1
$execute if score #dg_difficulty.$(pid) ec.var matches 1.. run scoreboard players operation #adv_credit_num ec.var = #dg_difficulty.$(pid) ec.var
$execute as @a[tag=dg.player,tag=p$(pid)] run function evercraft:advantage/grant_tree_credit
