# Wiring Audit B (2026-05-29) W6: Dungeon Instance — Per-Party Death Intercept Dispatcher (Shape D-1).
# Called from tick.mcfunction death gate as @s the dying participant (pt.dg_active=1 + ec.tomb_death=1..).
# Derives pid from @s's party then dispatches dungeon/fail_death as per-party macro.

# Deathless-clear flag (milestone p52): this participant died mid-run → they can no longer
# earn ach.dungeon_no_death for this run. @s is the dying participant.
scoreboard players set @s ec.dng_deathless 0

function evercraft:_shared/derive_pid_from_party
function evercraft:dungeon/fail_death with storage evercraft:_shared cart
