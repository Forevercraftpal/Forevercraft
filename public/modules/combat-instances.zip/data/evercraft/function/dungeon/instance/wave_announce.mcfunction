# Wiring Audit B (2026-05-29) W6: Dungeon Instance — Wave Title Announcement (per-party MACRO).
# Called with storage evercraft:_shared cart for $(pid) after spawn_wave (post-scaling).
# Scopes title/sound to @a[tag=dg.player,tag=p$(pid)] — this party only.

$execute if score #dg_wave.$(pid) ec.var matches 1 run title @a[tag=dg.player,tag=p$(pid)] times 5 30 10
$execute if score #dg_wave.$(pid) ec.var matches 1 run title @a[tag=dg.player,tag=p$(pid)] title {text:"Wave 1",color:"gold",bold:true}
$execute if score #dg_wave.$(pid) ec.var matches 2 run title @a[tag=dg.player,tag=p$(pid)] times 5 30 10
$execute if score #dg_wave.$(pid) ec.var matches 2 run title @a[tag=dg.player,tag=p$(pid)] title {text:"Wave 2",color:"gold",bold:true}
$execute if score #dg_wave.$(pid) ec.var matches 3 run title @a[tag=dg.player,tag=p$(pid)] times 5 30 10
$execute if score #dg_wave.$(pid) ec.var matches 3 run title @a[tag=dg.player,tag=p$(pid)] title {text:"Wave 3",color:"gold",bold:true}
$execute if score #dg_wave.$(pid) ec.var matches 4 run title @a[tag=dg.player,tag=p$(pid)] times 5 30 10
$execute if score #dg_wave.$(pid) ec.var matches 4 run title @a[tag=dg.player,tag=p$(pid)] title {text:"Wave 4",color:"gold",bold:true}
$execute if score #dg_wave.$(pid) ec.var matches 5 run title @a[tag=dg.player,tag=p$(pid)] times 5 40 10
$execute if score #dg_wave.$(pid) ec.var matches 5 run title @a[tag=dg.player,tag=p$(pid)] title {text:"FINAL WAVE",color:"dark_red",bold:true}

$playsound minecraft:entity.ender_dragon.growl master @a[tag=dg.player,tag=p$(pid),scores={ec.fx_snd=1..}] ~ ~ ~ 0.4 1.5
$execute if score #dg_wave.$(pid) ec.var matches 5 run playsound minecraft:entity.wither.spawn master @a[tag=dg.player,tag=p$(pid),scores={ec.fx_snd=1..}] ~ ~ ~ 0.6 0.6
