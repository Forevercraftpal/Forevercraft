# Dungeon Instance — Heal single mob to full
# Context: @s = a dg.mob that needs healing
# Wiring Audit #15 W5.4: RACE NOTE — storage evercraft:dungeon temp.max_hp is GLOBAL.
# Lines 9-10 below write-then-read sequentially. DO NOT insert a schedule/delay between them —
# would apply wrong mob's max_hp under sequential per-entity `as @e[tag=dg.needs_heal]` iteration.

# Primary: instant effects heal through the game engine (most reliable)
execute if entity @s[type=#minecraft:undead] run effect give @s instant_damage 1 10 true
execute unless entity @s[type=#minecraft:undead] run effect give @s instant_health 1 10 true

# Backup: data modify via storage — per-entity so each mob gets its own max_hp
execute store result storage evercraft:dungeon temp.max_hp float 1 run attribute @s max_health get
data modify entity @s Health set from storage evercraft:dungeon temp.max_hp
