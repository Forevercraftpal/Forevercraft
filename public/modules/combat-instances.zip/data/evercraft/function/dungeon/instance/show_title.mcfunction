# Wiring Audit B (2026-05-29) W6: Dungeon Instance — Show Title (per-party MACRO).
# Called from dungeon/begin_inner with storage evercraft:_shared cart for $(pid),$(name),$(subtitle).
$title @a[tag=dg.player,tag=p$(pid)] times 5 40 10
$title @a[tag=dg.player,tag=p$(pid)] title {text:"$(name)",color:"dark_purple",bold:true}
$title @a[tag=dg.player,tag=p$(pid)] subtitle {text:"$(subtitle)",color:"light_purple"}
