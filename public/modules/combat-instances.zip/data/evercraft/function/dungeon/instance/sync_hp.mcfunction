# Dungeon Instance — Heal mobs to full (runs 2 ticks after scaling)
# Attribute modifiers need time to apply before health can sync — same as world boss pattern

# Per-entity heal: calls sync_hp_single as each mob to avoid shared storage bug
execute as @e[tag=dg.needs_heal] run function evercraft:dungeon/instance/sync_hp_single

# Clean up
tag @e[tag=dg.needs_heal] remove dg.needs_heal
