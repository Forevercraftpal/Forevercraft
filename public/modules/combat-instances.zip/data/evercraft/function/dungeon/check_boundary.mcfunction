# Wiring Audit B (2026-05-29) W6: Dungeon — Boundary Check (per-party MACRO).
# Called from tick_active once per second with storage cart for $(pid).
# Structure dungeons: 64-block radius | Village defense: 128-block radius

# === VILLAGE DEFENSE (type 2) — 128 block boundary ===
data modify storage evercraft:notify stage.c set value [{text:"You're leaving the village! Return to the center!",color:"red"}]
scoreboard players set #ndur ec.temp 45
$execute if score #dg_type.$(pid) ec.var matches 2 at @e[type=marker,tag=dg.center,tag=p$(pid),limit=1] as @a[tag=dg.player,tag=p$(pid),distance=96..128] run function evercraft:util/notify/emit
$execute if score #dg_type.$(pid) ec.var matches 2 at @e[type=marker,tag=dg.center,tag=p$(pid),limit=1] as @a[tag=dg.player,tag=p$(pid),distance=96..128,scores={ec.fx_snd=1..}] at @s run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 1 0.5
$execute if score #dg_type.$(pid) ec.var matches 2 at @e[type=marker,tag=dg.center,tag=p$(pid),limit=1] run tag @a[tag=dg.player,tag=p$(pid),distance=128..] add dg.oob

# === STRUCTURE DUNGEON (type 1) — 64 block boundary ===
data modify storage evercraft:notify stage.c set value [{text:"You're leaving the dungeon area! Return to the center!",color:"red"}]
scoreboard players set #ndur ec.temp 45
$execute if score #dg_type.$(pid) ec.var matches 1 at @e[type=marker,tag=dg.center,tag=p$(pid),limit=1] as @a[tag=dg.player,tag=p$(pid),distance=48..64] run function evercraft:util/notify/emit
$execute if score #dg_type.$(pid) ec.var matches 1 at @e[type=marker,tag=dg.center,tag=p$(pid),limit=1] as @a[tag=dg.player,tag=p$(pid),distance=48..64,scores={ec.fx_snd=1..}] at @s run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 1 0.5
$execute if score #dg_type.$(pid) ec.var matches 1 at @e[type=marker,tag=dg.center,tag=p$(pid),limit=1] run tag @a[tag=dg.player,tag=p$(pid),distance=64..] add dg.oob

# === TELEPORT OUT-OF-BOUNDS PARTICIPANTS BACK TO THIS PARTY'S CENTER ===
$tp @a[tag=dg.oob,tag=p$(pid)] @e[type=marker,tag=dg.center,tag=p$(pid),limit=1]
data modify storage evercraft:notify stage.c set value [{text:"You've been pulled back to the dungeon!",color:"red"}]
scoreboard players set #ndur ec.temp 45
$execute as @a[tag=dg.oob,tag=p$(pid)] run function evercraft:util/notify/emit
$execute as @a[tag=dg.oob,tag=p$(pid),scores={ec.fx_snd=1..}] at @s run playsound minecraft:entity.enderman.teleport master @s ~ ~ ~ 1 1
$effect give @a[tag=dg.oob,tag=p$(pid)] slowness 3 1 true

# Cleanup tag (per-party)
$tag @a[tag=dg.oob,tag=p$(pid)] remove dg.oob
