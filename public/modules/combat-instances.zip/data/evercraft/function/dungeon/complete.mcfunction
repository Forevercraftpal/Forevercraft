# Wiring Audit B (2026-05-29) W6: Dungeon Instance — Complete (per-party MACRO).
# Called with storage evercraft:_shared cart for $(pid) from tick_active on wave-5-cleared.
# All 5 waves cleared. Celebrate and reward!

# Dungeon ender-node (PLAN-chest-nodes §8 / §14.12): floor-10 GUARANTEED per-party node. Spawned HERE,
# BEFORE the raids/check_entry handoff below — the `return 0` short-circuits the rest of complete, so the
# floor-10 node MUST be placed ahead of it. (Floors 3/5/7/9 are hooked in dungeon/floor/descend.) The
# node persists through the raid prompt + is killed by dungeon/cleanup's per-party p$(pid) sweep.
$execute if score #dg_floor.$(pid) ec.var matches 10 run function evercraft:dungeon/ender_node/spawn with storage evercraft:_shared cart

# Floor 10 completion → check raid entry instead of normal completion
# raids/check_entry needs cart.pid (it will call dungeon/reward + dungeon/cleanup with cart)
$execute if score #dg_floor.$(pid) ec.var matches 10 run function evercraft:raids/check_entry with storage evercraft:_shared cart
$execute if score #dg_floor.$(pid) ec.var matches 10 run return 0

# Victory title (per-party)
$title @a[tag=dg.player,tag=p$(pid)] times 10 60 20
$title @a[tag=dg.player,tag=p$(pid)] title {text:"DUNGEON CLEARED!",color:"gold",bold:true}
$title @a[tag=dg.player,tag=p$(pid)] subtitle {text:"Victory is yours!",color:"yellow"}

# Action-bar announcement (server-news to all)
# (Wave 2, 2026-06-10: dungeon-clear brag — actor name baked from the instance player, protected, 30s TTL.)
$execute as @a[tag=dg.player,tag=p$(pid),limit=1] run function evercraft:util/notify/whoami
data modify storage evercraft:notify stage.c set value [{text:""},{text:" has conquered the Dungeon Challenge!",color:"gold",bold:true}]
data modify storage evercraft:notify stage.c[0].text set from storage evercraft:notify named.who
scoreboard players set #ndur ec.temp 50
execute as @a run scoreboard players set #nttl ec.temp 600
execute as @a run function evercraft:util/notify/emit_keep

# Victory sounds (per-party)
$execute as @a[tag=dg.player,tag=p$(pid),scores={ec.fx_snd=1..}] at @s run playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 1 1
$execute as @a[tag=dg.player,tag=p$(pid),scores={ec.fx_snd=1..}] at @s run playsound minecraft:entity.firework_rocket.blast master @s ~ ~ ~ 1 1
$execute as @a[tag=dg.player,tag=p$(pid),scores={ec.fx_snd=1..}] at @s run playsound minecraft:entity.firework_rocket.twinkle master @s ~ ~ ~ 1 1

# Victory particles at this party's center
$execute at @e[type=marker,tag=dg.center,tag=p$(pid),limit=1] run particle minecraft:firework ~ ~2 ~ 3 2 3 0.1 200 force
$execute at @e[type=marker,tag=dg.center,tag=p$(pid),limit=1] run particle minecraft:totem_of_undying ~ ~2 ~ 2 2 2 0.5 150 force
$execute at @e[type=marker,tag=dg.center,tag=p$(pid),limit=1] run particle minecraft:happy_villager ~ ~1 ~ 3 1 3 0.1 50 force

# Set lockout: known structures use 7-day scoreboard, unknown uses 2-week position markers.
# Stage #dg_struct_id global for lockout/set + unknown/set_lockout to read.
$scoreboard players operation #dg_struct_id ec.var = #dg_struct_id.$(pid) ec.var
$execute unless score #dg_struct_id.$(pid) ec.var matches 20 run function evercraft:dungeon/lockout/set with storage evercraft:_shared cart
$execute if score #dg_struct_id.$(pid) ec.var matches 20 as @a[tag=dg.player,tag=p$(pid)] at @e[type=marker,tag=dg.center,tag=p$(pid),limit=1] run function evercraft:dungeon/unknown/set_lockout

# Leaderboard: compute completion time and check personal best (per-party participants)
$execute as @a[tag=dg.player,tag=p$(pid)] run function evercraft:dungeon/leaderboard/check_time with storage evercraft:_shared cart

# Announce affix clear if active (per-party)
data modify storage evercraft:notify stage.c set value [{text:"Dungeon cleared with ",color:"gold"},{text:"1 affix",color:"yellow"},{text:"! Loot multiplier: ",color:"gold"},{text:"1.25x",color:"gold",bold:true}]
scoreboard players set #ndur ec.temp 50
$execute if score #dg_afx_count.$(pid) ec.var matches 1 as @a[tag=dg.player,tag=p$(pid)] run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Dungeon cleared with ",color:"gold"},{text:"2 affixes",color:"yellow"},{text:"! Loot multiplier: ",color:"gold"},{text:"1.5x",color:"gold",bold:true}]
scoreboard players set #ndur ec.temp 50
$execute if score #dg_afx_count.$(pid) ec.var matches 2 as @a[tag=dg.player,tag=p$(pid)] run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Dungeon cleared with ",color:"gold"},{text:"3 affixes",color:"yellow"},{text:"! Loot multiplier: ",color:"gold"},{text:"2.0x",color:"gold",bold:true}]
scoreboard players set #ndur ec.temp 50
$execute if score #dg_afx_count.$(pid) ec.var matches 3 as @a[tag=dg.player,tag=p$(pid)] run function evercraft:util/notify/emit

# === SPIRIT PROGRESSION TRACKING ===
$execute as @a[tag=dg.player,tag=p$(pid),tag=ec.sp_active] run scoreboard players add @s ec.sp_dungeon_runs 1
$execute as @a[tag=dg.player,tag=p$(pid),tag=ec.sp_active] run scoreboard players add @s ec.sp_total_floors 1
$execute as @a[tag=dg.player,tag=p$(pid),tag=ec.sp_active] run scoreboard players operation @s ec.sp_floor_max > #dg_floor.$(pid) ec.var

# Class Affinity XP — dungeon complete
scoreboard players set #delta ec.temp 60000
$execute as @a[tag=dg.player,tag=p$(pid)] run function evercraft:affinity/grant_current

# Grant reward based on Dream Rate
function evercraft:dungeon/reward with storage evercraft:_shared cart

# === STORY HOOK ===
$execute as @a[tag=dg.player,tag=p$(pid),scores={sm.mode=1,sm.chapter=20}] run function evercraft:story/quest/check_progress

# Spirit Raid is gated to Floor 10 (handled at complete:5 -> raids/check_entry -> the Floor-10
# ceremony). Floors 1-9 finish cleanly here — no premature Spirit Raid prompt. (Joseph 2026-05-29)
function evercraft:dungeon/cleanup with storage evercraft:_shared cart
