# Wiring Audit B (2026-05-29) W6: Dungeon Instance — Begin (per-party MACRO).
# Called via dungeon/begin with storage evercraft:_shared cart for $(pid).
# @s = the triggering player. Expects: #dg_difficulty already set by menu/select.

# Read triggering player's DR for DR scaling layer (per-party)
$execute store result score #dg_dr.$(pid) ec.var run attribute @s minecraft:luck get

# Read difficulty from pre-dungeon menu staging (still global at menu staging time)
$scoreboard players operation #dg_difficulty.$(pid) ec.var = #dg_difficulty ec.var

# Set per-party state
$scoreboard players set #dg_wave.$(pid) ec.var 0
$scoreboard players set #dg_timer.$(pid) ec.var 60
$scoreboard players set #dg_type.$(pid) ec.var 1
$scoreboard players set #dg_floor.$(pid) ec.var 1
$scoreboard players set #dg_descent_timer.$(pid) ec.var 0

# Pick random instance (1-16) — determines mob composition theme
$execute store result score #dg_instance.$(pid) ec.var run random value 1..16

# Set per-party participation flag (R7 ordering: AFTER tag fan-out below)
# Aggregate gate (I3: 0→1 unconditional)
scoreboard players set #dg_any_active ec.var 1

# Tag the player (and nearby party members)
tag @s add dg.player
$tag @s add p$(pid)
scoreboard players set @s dg.deaths 0

# Party integration: also tag nearby party members as dungeon participants (adds dg.player + p<pid>)
execute if score @s ec.party_id matches 1.. run function evercraft:party/dungeon/tag_party

# Wiring Audit #18 W3.2 / Audit B W6: pt.dg_active parallel write (R7: AFTER tag fan-out)
# Scoped to THIS party's participants only via p<pid> tag.
$scoreboard players set @a[tag=dg.player,tag=p$(pid)] pt.dg_active 1

# Deathless-clear flag (milestone p52): 1 at enter for ALL participants; cleared to 0 by
# dungeon/on_death_outer if any participant dies; read at dungeon/reward_player completion.
$scoreboard players set @a[tag=dg.player,tag=p$(pid)] ec.dng_deathless 1

# Count total dungeon participants for mob scaling (per-party)
$execute store result score #dg_players.$(pid) ec.var if entity @a[tag=dg.player,tag=p$(pid)]

# Place center marker at player position with p<pid> tag for cross-party isolation
$execute at @s run summon marker ~ ~ ~ {Tags:["dg.center","ec.entity","p$(pid)"]}

# Store center coordinates for boundary checking (per-party)
$execute store result score #dg_center_x.$(pid) ec.var run data get entity @e[type=marker,tag=dg.center,tag=p$(pid),limit=1] Pos[0]
$execute store result score #dg_center_z.$(pid) ec.var run data get entity @e[type=marker,tag=dg.center,tag=p$(pid),limit=1] Pos[2]

# Stage instance name + subtitle into cart for title macro
function evercraft:dungeon/instance/get_name with storage evercraft:_shared cart

# Title announcement (per-party — show_title reads cart.pid + cart.name + cart.subtitle)
function evercraft:dungeon/instance/show_title with storage evercraft:_shared cart

# Sound effects (per-party participants)
$playsound minecraft:entity.wither.spawn master @a[tag=dg.player,tag=p$(pid),scores={ec.fx_snd=1..}] ~ ~ ~ 0.5 0.8
$playsound minecraft:block.end_portal.spawn master @a[tag=dg.player,tag=p$(pid),scores={ec.fx_snd=1..}] ~ ~ ~ 0.3 1.2

# Roll dungeon modifier — daily challenge locks in the featured modifier, otherwise random
# #dg_is_daily is a pre-dungeon scratch from start.mcfunction (still global, sequential safe)
execute if score #dg_is_daily ec.var matches 1 run function evercraft:dungeon/modifiers/apply_from_daily with storage evercraft:_shared cart
execute unless score #dg_is_daily ec.var matches 1 run function evercraft:dungeon/modifiers/roll with storage evercraft:_shared cart

# Stage #dg_is_daily into per-party for downstream (complete/cleanup/reward read this)
$scoreboard players operation #dg_is_daily.$(pid) ec.var = #dg_is_daily ec.var
$scoreboard players operation #dg_struct_id.$(pid) ec.var = #dg_struct_id ec.var

# Omens + Dungeons: Bad Omen consumed → "Cursed Run" (guaranteed rare+ drop)
$scoreboard players set #dg_omen.$(pid) ec.var 0
$execute if entity @s[nbt={active_effects:[{id:"minecraft:bad_omen"}]}] run scoreboard players set #dg_omen.$(pid) ec.var 1
$execute if score #dg_omen.$(pid) ec.var matches 1 run effect clear @s minecraft:bad_omen
data modify storage evercraft:notify stage.c set value [{text:"Cursed Run! ",color:"dark_red",bold:true},{text:"Bad Omen consumed — guaranteed Rare+ rewards!",color:"red"}]
scoreboard players set #ndur ec.temp 50
$execute if score #dg_omen.$(pid) ec.var matches 1 as @a[tag=dg.player,tag=p$(pid)] run function evercraft:util/notify/emit
$execute if score #dg_omen.$(pid) ec.var matches 1 run playsound minecraft:entity.elder_guardian.curse master @a[tag=dg.player,tag=p$(pid),scores={ec.fx_snd=1..}] ~ ~ ~ 0.6 0.8

# Action-bar announcement (server-news — intentionally unfiltered to all players)
function evercraft:util/notify/whoami
data modify storage evercraft:notify stage.c set value [{text:""},{text:" has begun a Dungeon Challenge!",color:"light_purple"}]
data modify storage evercraft:notify stage.c[0].text set from storage evercraft:notify named.who
scoreboard players set #ndur ec.temp 50
execute as @a run scoreboard players set #nttl ec.temp 600
execute as @a run function evercraft:util/notify/emit_keep

# Disclaimer: self-revive paused
data modify storage evercraft:notify stage.c set value [{text:"All self-revive functions have been paused for the duration of this challenge.",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 40
$execute as @a[tag=dg.player,tag=p$(pid)] run function evercraft:util/notify/emit

# Leaderboard: record start time for all participants
$execute store result score @a[tag=dg.player,tag=p$(pid)] dg.start_time run time query gametime

# Track dungeon attempt count for all participants
$scoreboard players add @a[tag=dg.player,tag=p$(pid)] ec.dng_attempts 1
data modify storage evercraft:notify stage.c set value [{text:"Attempt #",color:"dark_gray",italic:true},{score:{name:"@s",objective:"ec.dng_attempts"},color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 40
$execute as @a[tag=dg.player,tag=p$(pid)] run function evercraft:util/notify/emit

# Inscription + Dungeons: Check for nearby inscription zones — grant 30s buff
$execute as @a[tag=dg.player,tag=p$(pid)] at @s if entity @e[type=marker,tag=ec.inscr_stone,distance=..16,limit=1] run effect give @s strength 30 0
$execute as @a[tag=dg.player,tag=p$(pid)] at @s if entity @e[type=marker,tag=ec.inscr_stone,distance=..16,limit=1] run effect give @s resistance 30 0
data modify storage evercraft:notify stage.c set value [{text:"Inscription stones empower you! ",color:"#87CEEB"},{text:"(+Strength, +Resistance 30s)",color:"aqua"}]
scoreboard players set #ndur ec.temp 45
$execute as @a[tag=dg.player,tag=p$(pid)] at @s if entity @e[type=marker,tag=ec.inscr_stone,distance=..16,limit=1] run function evercraft:util/notify/emit

# Trim + Dungeons: Players with trimmed armor get bonus dungeon XP (tracked via tag)
$execute as @a[tag=dg.player,tag=p$(pid),tag=ec.has_any_trim] run tag @s add dg.trim_bonus
data modify storage evercraft:notify stage.c set value [{text:"Trimmed armor detected — +50% bonus XP on completion!",color:"yellow"}]
scoreboard players set #ndur ec.temp 45
$execute as @a[tag=dg.player,tag=p$(pid),tag=dg.trim_bonus] run function evercraft:util/notify/emit

# Party Dungeon Affixes: Roll affixes if 2+ party members
$scoreboard players set #dg_afx_count.$(pid) ec.var 0
$execute if score #dg_players.$(pid) ec.var matches 2.. run function evercraft:dungeon/affix/roll with storage evercraft:_shared cart

# Particle burst at center
execute at @s run particle minecraft:reverse_portal ~ ~1 ~ 1 1 1 0.05 100 force
execute at @s run particle minecraft:witch ~ ~1 ~ 1 1 1 0.05 50 force
