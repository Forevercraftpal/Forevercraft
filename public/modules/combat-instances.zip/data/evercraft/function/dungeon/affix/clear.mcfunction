# Wiring Audit B (2026-05-29) W6: Party Dungeon Affixes — Clear all affixes (per-party MACRO).
# Called from cleanup with storage cart for $(pid).

# Remove this party's participant attribute modifiers
$execute as @a[tag=dg.player,tag=p$(pid)] run attribute @s attack_damage modifier remove evercraft:dg_affix
$execute as @a[tag=dg.player,tag=p$(pid)] run attribute @s armor modifier remove evercraft:dg_affix_armor
$execute as @a[tag=dg.player,tag=p$(pid)] run attribute @s max_health modifier remove evercraft:dg_affix_hp

# Clear per-party affix state
$scoreboard players set #dg_afx_count.$(pid) ec.var 0
$scoreboard players set #dg_afx1.$(pid) ec.var 0
$scoreboard players set #dg_afx2.$(pid) ec.var 0
$scoreboard players set #dg_afx3.$(pid) ec.var 0
$scoreboard players set #dg_afx_timer.$(pid) ec.var 0
