# Wiring Audit B (2026-05-29) W6: Party Dungeon Affixes — Roll affixes (per-party MACRO).
# Called with storage cart for $(pid) from begin_inner when #dg_players.<pid> >= 2.
# Affixes: 1=Glass Cannon, 2=Speed Demon, 3=Armored, 4=Darkness,
#          5=Timer, 6=Vulnerability, 7=No Healing, 8=Reinforcements

# Determine affix count based on party size (per-party)
$scoreboard players set #dg_afx_count.$(pid) ec.var 1
$execute if score #dg_players.$(pid) ec.var matches 3 run scoreboard players set #dg_afx_count.$(pid) ec.var 2
$execute if score #dg_players.$(pid) ec.var matches 4.. run scoreboard players set #dg_afx_count.$(pid) ec.var 3

# Roll first affix (always)
$execute store result score #dg_afx1.$(pid) ec.var run random value 1..8
$scoreboard players set #dg_afx2.$(pid) ec.var 0
$scoreboard players set #dg_afx3.$(pid) ec.var 0

# Roll second affix if count >= 2 (re-roll if duplicate)
$execute if score #dg_afx_count.$(pid) ec.var matches 2.. store result score #dg_afx2.$(pid) ec.var run random value 1..8
$execute if score #dg_afx_count.$(pid) ec.var matches 2.. if score #dg_afx2.$(pid) ec.var = #dg_afx1.$(pid) ec.var store result score #dg_afx2.$(pid) ec.var run random value 1..8
$execute if score #dg_afx_count.$(pid) ec.var matches 2.. if score #dg_afx2.$(pid) ec.var = #dg_afx1.$(pid) ec.var store result score #dg_afx2.$(pid) ec.var run random value 1..8

# Roll third affix if count >= 3 (re-roll if duplicate)
$execute if score #dg_afx_count.$(pid) ec.var matches 3.. store result score #dg_afx3.$(pid) ec.var run random value 1..8
$execute if score #dg_afx_count.$(pid) ec.var matches 3.. if score #dg_afx3.$(pid) ec.var = #dg_afx1.$(pid) ec.var store result score #dg_afx3.$(pid) ec.var run random value 1..8
$execute if score #dg_afx_count.$(pid) ec.var matches 3.. if score #dg_afx3.$(pid) ec.var = #dg_afx2.$(pid) ec.var store result score #dg_afx3.$(pid) ec.var run random value 1..8
$execute if score #dg_afx_count.$(pid) ec.var matches 3.. if score #dg_afx3.$(pid) ec.var = #dg_afx1.$(pid) ec.var store result score #dg_afx3.$(pid) ec.var run random value 1..8

# Announce affixes (per-party)
function evercraft:dungeon/affix/announce with storage evercraft:_shared cart

# Apply immediate effects to participants (per-party)
function evercraft:dungeon/affix/apply_players with storage evercraft:_shared cart
