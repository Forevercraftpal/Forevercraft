# Wiring Audit B (2026-05-29) W6: Party Dungeon Affixes — Announce (per-party MACRO).
# Called with storage cart for $(pid) from affix/roll.
data modify storage evercraft:notify stage.c set value [{text:"Party Affixes Active!",color:"gold",bold:true}]
scoreboard players set #ndur ec.temp 50
$execute as @a[tag=dg.player,tag=p$(pid)] run function evercraft:util/notify/emit

# Affix 1
data modify storage evercraft:notify stage.c set value [{text:"▸ ",color:"dark_red"},{text:"Glass Cannon",color:"red",bold:true},{text:" — +50% damage dealt and taken",color:"gray"}]
scoreboard players set #ndur ec.temp 40
$execute if score #dg_afx1.$(pid) ec.var matches 1 as @a[tag=dg.player,tag=p$(pid)] run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"▸ ",color:"dark_aqua"},{text:"Speed Demon",color:"aqua",bold:true},{text:" — All mobs have Speed II",color:"gray"}]
scoreboard players set #ndur ec.temp 40
$execute if score #dg_afx1.$(pid) ec.var matches 2 as @a[tag=dg.player,tag=p$(pid)] run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"▸ ",color:"blue"},{text:"Armored",color:"blue",bold:true},{text:" — All mobs have +8 armor",color:"gray"}]
scoreboard players set #ndur ec.temp 40
$execute if score #dg_afx1.$(pid) ec.var matches 3 as @a[tag=dg.player,tag=p$(pid)] run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"▸ ",color:"dark_gray"},{text:"Darkness",color:"dark_gray",bold:true},{text:" — Permanent darkness effect",color:"gray"}]
scoreboard players set #ndur ec.temp 40
$execute if score #dg_afx1.$(pid) ec.var matches 4 as @a[tag=dg.player,tag=p$(pid)] run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"▸ ",color:"yellow"},{text:"Timer",color:"yellow",bold:true},{text:" — 3-minute time limit",color:"gray"}]
scoreboard players set #ndur ec.temp 40
$execute if score #dg_afx1.$(pid) ec.var matches 5 as @a[tag=dg.player,tag=p$(pid)] run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"▸ ",color:"dark_purple"},{text:"Vulnerability",color:"dark_purple",bold:true},{text:" — Players have -30% max health",color:"gray"}]
scoreboard players set #ndur ec.temp 40
$execute if score #dg_afx1.$(pid) ec.var matches 6 as @a[tag=dg.player,tag=p$(pid)] run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"▸ ",color:"dark_green"},{text:"No Healing",color:"green",bold:true},{text:" — Natural regeneration disabled",color:"gray"}]
scoreboard players set #ndur ec.temp 40
$execute if score #dg_afx1.$(pid) ec.var matches 7 as @a[tag=dg.player,tag=p$(pid)] run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"▸ ",color:"light_purple"},{text:"Reinforcements",color:"light_purple",bold:true},{text:" — Extra mobs each wave",color:"gray"}]
scoreboard players set #ndur ec.temp 40
$execute if score #dg_afx1.$(pid) ec.var matches 8 as @a[tag=dg.player,tag=p$(pid)] run function evercraft:util/notify/emit

# Affix 2
data modify storage evercraft:notify stage.c set value [{text:"▸ ",color:"dark_red"},{text:"Glass Cannon",color:"red",bold:true},{text:" — +50% damage dealt and taken",color:"gray"}]
scoreboard players set #ndur ec.temp 40
$execute if score #dg_afx2.$(pid) ec.var matches 1 as @a[tag=dg.player,tag=p$(pid)] run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"▸ ",color:"dark_aqua"},{text:"Speed Demon",color:"aqua",bold:true},{text:" — All mobs have Speed II",color:"gray"}]
scoreboard players set #ndur ec.temp 40
$execute if score #dg_afx2.$(pid) ec.var matches 2 as @a[tag=dg.player,tag=p$(pid)] run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"▸ ",color:"blue"},{text:"Armored",color:"blue",bold:true},{text:" — All mobs have +8 armor",color:"gray"}]
scoreboard players set #ndur ec.temp 40
$execute if score #dg_afx2.$(pid) ec.var matches 3 as @a[tag=dg.player,tag=p$(pid)] run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"▸ ",color:"dark_gray"},{text:"Darkness",color:"dark_gray",bold:true},{text:" — Permanent darkness effect",color:"gray"}]
scoreboard players set #ndur ec.temp 40
$execute if score #dg_afx2.$(pid) ec.var matches 4 as @a[tag=dg.player,tag=p$(pid)] run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"▸ ",color:"yellow"},{text:"Timer",color:"yellow",bold:true},{text:" — 3-minute time limit",color:"gray"}]
scoreboard players set #ndur ec.temp 40
$execute if score #dg_afx2.$(pid) ec.var matches 5 as @a[tag=dg.player,tag=p$(pid)] run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"▸ ",color:"dark_purple"},{text:"Vulnerability",color:"dark_purple",bold:true},{text:" — Players have -30% max health",color:"gray"}]
scoreboard players set #ndur ec.temp 40
$execute if score #dg_afx2.$(pid) ec.var matches 6 as @a[tag=dg.player,tag=p$(pid)] run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"▸ ",color:"dark_green"},{text:"No Healing",color:"green",bold:true},{text:" — Natural regeneration disabled",color:"gray"}]
scoreboard players set #ndur ec.temp 40
$execute if score #dg_afx2.$(pid) ec.var matches 7 as @a[tag=dg.player,tag=p$(pid)] run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"▸ ",color:"light_purple"},{text:"Reinforcements",color:"light_purple",bold:true},{text:" — Extra mobs each wave",color:"gray"}]
scoreboard players set #ndur ec.temp 40
$execute if score #dg_afx2.$(pid) ec.var matches 8 as @a[tag=dg.player,tag=p$(pid)] run function evercraft:util/notify/emit

# Affix 3
data modify storage evercraft:notify stage.c set value [{text:"▸ ",color:"dark_red"},{text:"Glass Cannon",color:"red",bold:true},{text:" — +50% damage dealt and taken",color:"gray"}]
scoreboard players set #ndur ec.temp 40
$execute if score #dg_afx3.$(pid) ec.var matches 1 as @a[tag=dg.player,tag=p$(pid)] run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"▸ ",color:"dark_aqua"},{text:"Speed Demon",color:"aqua",bold:true},{text:" — All mobs have Speed II",color:"gray"}]
scoreboard players set #ndur ec.temp 40
$execute if score #dg_afx3.$(pid) ec.var matches 2 as @a[tag=dg.player,tag=p$(pid)] run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"▸ ",color:"blue"},{text:"Armored",color:"blue",bold:true},{text:" — All mobs have +8 armor",color:"gray"}]
scoreboard players set #ndur ec.temp 40
$execute if score #dg_afx3.$(pid) ec.var matches 3 as @a[tag=dg.player,tag=p$(pid)] run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"▸ ",color:"dark_gray"},{text:"Darkness",color:"dark_gray",bold:true},{text:" — Permanent darkness effect",color:"gray"}]
scoreboard players set #ndur ec.temp 40
$execute if score #dg_afx3.$(pid) ec.var matches 4 as @a[tag=dg.player,tag=p$(pid)] run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"▸ ",color:"yellow"},{text:"Timer",color:"yellow",bold:true},{text:" — 3-minute time limit",color:"gray"}]
scoreboard players set #ndur ec.temp 40
$execute if score #dg_afx3.$(pid) ec.var matches 5 as @a[tag=dg.player,tag=p$(pid)] run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"▸ ",color:"dark_purple"},{text:"Vulnerability",color:"dark_purple",bold:true},{text:" — Players have -30% max health",color:"gray"}]
scoreboard players set #ndur ec.temp 40
$execute if score #dg_afx3.$(pid) ec.var matches 6 as @a[tag=dg.player,tag=p$(pid)] run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"▸ ",color:"dark_green"},{text:"No Healing",color:"green",bold:true},{text:" — Natural regeneration disabled",color:"gray"}]
scoreboard players set #ndur ec.temp 40
$execute if score #dg_afx3.$(pid) ec.var matches 7 as @a[tag=dg.player,tag=p$(pid)] run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"▸ ",color:"light_purple"},{text:"Reinforcements",color:"light_purple",bold:true},{text:" — Extra mobs each wave",color:"gray"}]
scoreboard players set #ndur ec.temp 40
$execute if score #dg_afx3.$(pid) ec.var matches 8 as @a[tag=dg.player,tag=p$(pid)] run function evercraft:util/notify/emit

# Loot multiplier announcement
data modify storage evercraft:notify stage.c set value [{text:"Loot Multiplier: ",color:"gray"},{text:"1.25x",color:"gold",bold:true}]
scoreboard players set #ndur ec.temp 40
$execute if score #dg_afx_count.$(pid) ec.var matches 1 as @a[tag=dg.player,tag=p$(pid)] run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Loot Multiplier: ",color:"gray"},{text:"1.5x",color:"gold",bold:true}]
scoreboard players set #ndur ec.temp 40
$execute if score #dg_afx_count.$(pid) ec.var matches 2 as @a[tag=dg.player,tag=p$(pid)] run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Loot Multiplier: ",color:"gray"},{text:"2.0x",color:"gold",bold:true}]
scoreboard players set #ndur ec.temp 40
$execute if score #dg_afx_count.$(pid) ec.var matches 3 as @a[tag=dg.player,tag=p$(pid)] run function evercraft:util/notify/emit

$playsound minecraft:block.note_block.pling master @a[tag=dg.player,tag=p$(pid),scores={ec.fx_snd=1..}] ~ ~ ~ 0.8 0.5
