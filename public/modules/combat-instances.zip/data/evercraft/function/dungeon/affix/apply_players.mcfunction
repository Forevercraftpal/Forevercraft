# Wiring Audit B (2026-05-29) W6: Party Dungeon Affixes — Apply to players (per-party MACRO).
# Called with storage cart for $(pid) from affix/roll.

# Glass Cannon (1): +50% attack damage, -2 armor on this party's participants
$execute if score #dg_afx1.$(pid) ec.var matches 1 as @a[tag=dg.player,tag=p$(pid)] run attribute @s attack_damage modifier add evercraft:dg_affix 0.5 add_multiplied_base
$execute if score #dg_afx2.$(pid) ec.var matches 1 as @a[tag=dg.player,tag=p$(pid)] run attribute @s attack_damage modifier add evercraft:dg_affix 0.5 add_multiplied_base
$execute if score #dg_afx3.$(pid) ec.var matches 1 as @a[tag=dg.player,tag=p$(pid)] run attribute @s attack_damage modifier add evercraft:dg_affix 0.5 add_multiplied_base
$execute if score #dg_afx1.$(pid) ec.var matches 1 as @a[tag=dg.player,tag=p$(pid)] run attribute @s armor modifier add evercraft:dg_affix_armor -2 add_value
$execute if score #dg_afx2.$(pid) ec.var matches 1 as @a[tag=dg.player,tag=p$(pid)] run attribute @s armor modifier add evercraft:dg_affix_armor -2 add_value
$execute if score #dg_afx3.$(pid) ec.var matches 1 as @a[tag=dg.player,tag=p$(pid)] run attribute @s armor modifier add evercraft:dg_affix_armor -2 add_value

# Timer (5): reduce combat timer to 3600 ticks (3 minutes) (per-party)
$execute if score #dg_afx1.$(pid) ec.var matches 5 run scoreboard players set #dg_afx_timer.$(pid) ec.var 1
$execute if score #dg_afx2.$(pid) ec.var matches 5 run scoreboard players set #dg_afx_timer.$(pid) ec.var 1
$execute if score #dg_afx3.$(pid) ec.var matches 5 run scoreboard players set #dg_afx_timer.$(pid) ec.var 1

# Vulnerability (6): -30% max health on this party's participants
$execute if score #dg_afx1.$(pid) ec.var matches 6 as @a[tag=dg.player,tag=p$(pid)] run attribute @s max_health modifier add evercraft:dg_affix_hp -0.3 add_multiplied_base
$execute if score #dg_afx2.$(pid) ec.var matches 6 as @a[tag=dg.player,tag=p$(pid)] run attribute @s max_health modifier add evercraft:dg_affix_hp -0.3 add_multiplied_base
$execute if score #dg_afx3.$(pid) ec.var matches 6 as @a[tag=dg.player,tag=p$(pid)] run attribute @s max_health modifier add evercraft:dg_affix_hp -0.3 add_multiplied_base
