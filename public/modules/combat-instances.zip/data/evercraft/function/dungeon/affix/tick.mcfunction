# Wiring Audit B (2026-05-29) W6: Party Dungeon Affixes — Tick effects (per-party MACRO).
# Called from tick_active every 5s with storage cart for $(pid). Only runs when #dg_afx_count.<pid> >= 1.

# Darkness (4): permanent darkness on this party's participants (refresh 8s)
$execute if score #dg_afx1.$(pid) ec.var matches 4 run effect give @a[tag=dg.player,tag=p$(pid)] darkness 8 0 false
$execute if score #dg_afx2.$(pid) ec.var matches 4 run effect give @a[tag=dg.player,tag=p$(pid)] darkness 8 0 false
$execute if score #dg_afx3.$(pid) ec.var matches 4 run effect give @a[tag=dg.player,tag=p$(pid)] darkness 8 0 false

# No Healing (7): prevent natural regen by applying hunger effect (per-party)
$execute if score #dg_afx1.$(pid) ec.var matches 7 run effect give @a[tag=dg.player,tag=p$(pid)] hunger 8 9 true
$execute if score #dg_afx2.$(pid) ec.var matches 7 run effect give @a[tag=dg.player,tag=p$(pid)] hunger 8 9 true
$execute if score #dg_afx3.$(pid) ec.var matches 7 run effect give @a[tag=dg.player,tag=p$(pid)] hunger 8 9 true

# Reinforcements (8): spawn 3 extra zombies at center (checked in instance/spawn_wave instead)
