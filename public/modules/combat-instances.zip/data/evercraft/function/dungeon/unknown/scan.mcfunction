# Unknown Structure Dungeon — Passive scan (every 2s)
# Detects players holding a Dungeon Key near unknown structures with crate markers

# Early exit if no players
execute unless entity @a run return run schedule function evercraft:dungeon/unknown/scan 2s replace

# Check all players holding a Dungeon Key in main hand
# Wiring Audit #15 polish-wave AU17 (AU15-FOLLOWUP.4): pre-gate on dg.has_key tag
# (maintained by unknown/key_detect every 5s). Skips ~93% of the NBT-mainhand scan
# load — only key-holders ever hit the slow `items entity @s weapon.mainhand` check.
execute as @a[tag=dg.has_key] if items entity @s weapon.mainhand *[custom_data~{dungeon_key:true}] at @s run function evercraft:dungeon/unknown/scan_player

# Reschedule
schedule function evercraft:dungeon/unknown/scan 2s replace
