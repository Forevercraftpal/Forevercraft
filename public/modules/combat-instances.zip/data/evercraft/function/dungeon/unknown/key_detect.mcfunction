# Dungeon Unknown — Key-holder Tag Detection (every 5s, self-correcting)
# Wiring Audit #15 polish-wave AU17 (AU15-FOLLOWUP.4, Joseph 2026-05-29):
# Periodic sweep that maintains the dg.has_key tag on players currently holding a
# Dungeon Key anywhere in their inventory. This lets unknown/scan gate its expensive
# NBT-mainhand check on `tag=dg.has_key`, dropping ~6.5 NBT-scans/s at 14p.
#
# Cadence: 5s (vs scan's 2s) — slower because the tag is self-correcting and the
# scan-side gate already filters non-key-holders out cheaply. Acts as the 30s
# validate-sweep called out in the followup (5s × 6 = 30s effective lag for orphan
# tag clear if a key is dropped without an explicit consume event firing).
#
# Early exit if no players
execute unless entity @a run return run schedule function evercraft:dungeon/unknown/key_detect 5s replace

# Mark every player who holds a key (any inventory slot OR offhand)
execute as @a if items entity @s container.* *[custom_data~{dungeon_key:true}] run tag @s add dg.has_key
execute as @a if items entity @s weapon.offhand *[custom_data~{dungeon_key:true}] run tag @s add dg.has_key

# Clear tag from players who NO LONGER hold a key (orphan-cleanup)
execute as @a[tag=dg.has_key] unless items entity @s container.* *[custom_data~{dungeon_key:true}] unless items entity @s weapon.offhand *[custom_data~{dungeon_key:true}] run tag @s remove dg.has_key

# Reschedule
schedule function evercraft:dungeon/unknown/key_detect 5s replace
