# Wiring Audit B (2026-05-29) W6: Dungeon Instance — Fail (Player Disconnected) (per-party MACRO).
# Called with storage evercraft:_shared cart for $(pid) from tick_active when no participant online.
# No messages (no participant here to read them); just cleanup.

function evercraft:dungeon/cleanup with storage evercraft:_shared cart
