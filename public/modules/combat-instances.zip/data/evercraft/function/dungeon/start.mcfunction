# Dungeon Instance System — Start (Key Consumed)
# Called when player consumes a Dungeon Key (advancement reward)
# Validates conditions, then opens difficulty selection menu
# Run as: the player who consumed the key

# Revoke advancement for reuse
advancement revoke @s only evercraft:dungeon/use_key

# Wiring Audit B (2026-05-29) W6: Per-party gate — block if THIS player's party already in a dungeon.
# Inv-full guard: drop at the player's feet rather than void on a full inventory.
execute store result score #inv_full ec.var run function evercraft:util/check_inv_full
execute if score @s pt.dg_active matches 1 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:dungeon/key
execute if score @s pt.dg_active matches 1 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:dungeon/key
data modify storage evercraft:notify stage.c set value [{text:"Your party is already in a dungeon! Key returned.",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute if score @s pt.dg_active matches 1 run function evercraft:util/notify/emit
execute if score @s pt.dg_active matches 1 run return 0

# Symmetric Castle block (Joseph Q9 / AU-B-FOLLOWUP.8): castle/start blocks pt.dg_active; mirror here.
execute if score @s pt.ic_active matches 1 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:dungeon/key
execute if score @s pt.ic_active matches 1 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:dungeon/key
data modify storage evercraft:notify stage.c set value [{text:"You're already in an Infinite Castle run! Key returned.",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute if score @s pt.ic_active matches 1 run function evercraft:util/notify/emit
execute if score @s pt.ic_active matches 1 run return 0

# Check if player is at a known structure OR an unknown structure with crate markers
scoreboard players set #dg_struct_id ec.var 0
execute at @s if predicate evercraft:dungeon/at_structure run function evercraft:dungeon/detect_structure

# If not at a known structure, check for unknown structure (passive scan tag)
execute if score #dg_struct_id ec.var matches 0 if entity @s[tag=dg.unknown_detected] run scoreboard players set #dg_struct_id ec.var 20
data modify storage evercraft:notify stage.c set value [{text:"Unknown Structure ",color:"#87CEEB",bold:true},{text:"— uncharted territory!",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 45
execute if score #dg_struct_id ec.var matches 0 if entity @s[tag=dg.unknown_detected] run function evercraft:util/notify/emit

# If neither known nor unknown structure — offer Infinite Castle instead
execute if score #dg_struct_id ec.var matches 0 run function evercraft:castle/start
execute if score #dg_struct_id ec.var matches 0 run return 0

# Daily Challenge check — bypass lockout if this structure is today's challenge
# Unknown structures (20) excluded — daily roll only targets known structures (1-19)
scoreboard players set #dg_is_daily ec.var 0
# Wiring Audit #15 W4.1: closes cross-system daily double-claim shield — matches craftforever/trials/start:24 parity.
# Pre-fix, a player could claim daily-trial AM then daily-dungeon PM same day (or vice versa) for double rewards.
execute unless score #dg_struct_id ec.var matches 20 if score #dg_struct_id ec.var = #dc_struct ec.var unless score @s ec.daily_done matches 1 run scoreboard players set #dg_is_daily ec.var 1
data modify storage evercraft:notify stage.c set value [{text:"Daily Challenge! ",color:"gold",bold:true},{text:"Lockout bypassed — double rewards await!",color:"yellow"}]
scoreboard players set #ndur ec.temp 45
execute if score #dg_is_daily ec.var matches 1 run function evercraft:util/notify/emit

# === LOCKOUT CHECKS ===
# Known structures (1-19): scoreboard-based 7-day lockout
# Unknown structures (20): position-based marker 2-week lockout
# Daily challenge structures: lockout bypassed entirely

# Known structure lockout (skip if daily challenge or unknown)
execute unless score #dg_is_daily ec.var matches 1 unless score #dg_struct_id ec.var matches 20 run function evercraft:dungeon/lockout/get
execute unless score #dg_is_daily ec.var matches 1 unless score #dg_struct_id ec.var matches 20 store result score #dg_now ec.var run time query gametime
execute unless score #dg_is_daily ec.var matches 1 unless score #dg_struct_id ec.var matches 20 run scoreboard players operation #dg_elapsed ec.var = #dg_now ec.var
execute unless score #dg_is_daily ec.var matches 1 unless score #dg_struct_id ec.var matches 20 run scoreboard players operation #dg_elapsed ec.var -= #dg_lockout_val ec.var
execute unless score #dg_is_daily ec.var matches 1 unless score #dg_struct_id ec.var matches 20 if score #dg_lockout_val ec.var matches 1.. if score #dg_elapsed ec.var matches ..503999 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:dungeon/key
execute unless score #dg_is_daily ec.var matches 1 unless score #dg_struct_id ec.var matches 20 if score #dg_lockout_val ec.var matches 1.. if score #dg_elapsed ec.var matches ..503999 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:dungeon/key
data modify storage evercraft:notify stage.c set value [{text:"You must wait before running another dungeon here! Key returned.",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute unless score #dg_is_daily ec.var matches 1 unless score #dg_struct_id ec.var matches 20 if score #dg_lockout_val ec.var matches 1.. if score #dg_elapsed ec.var matches ..503999 run function evercraft:util/notify/emit
execute unless score #dg_is_daily ec.var matches 1 unless score #dg_struct_id ec.var matches 20 if score #dg_lockout_val ec.var matches 1.. if score #dg_elapsed ec.var matches ..503999 run function evercraft:dungeon/lockout_info
execute unless score #dg_is_daily ec.var matches 1 unless score #dg_struct_id ec.var matches 20 if score #dg_lockout_val ec.var matches 1.. if score #dg_elapsed ec.var matches ..503999 run return 0

# Unknown structure lockout (2-week, position-based markers)
execute if score #dg_struct_id ec.var matches 20 at @s run function evercraft:dungeon/unknown/check_lockout
execute if score #dg_struct_id ec.var matches 20 if score #dg_unknown_locked ec.var matches 1 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:dungeon/key
execute if score #dg_struct_id ec.var matches 20 if score #dg_unknown_locked ec.var matches 1 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:dungeon/key
data modify storage evercraft:notify stage.c set value [{text:"This unknown site hasn't recovered yet — return in a fortnight! Key returned.",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute if score #dg_struct_id ec.var matches 20 if score #dg_unknown_locked ec.var matches 1 run function evercraft:util/notify/emit
execute if score #dg_struct_id ec.var matches 20 if score #dg_unknown_locked ec.var matches 1 run return 0

# Check if player is in a GUI menu — return key
data modify storage evercraft:notify stage.c set value [{text:"Close your menu first! Key returned.",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute if entity @s[tag=Adv.InMenu] if score #inv_full ec.var matches 0 run loot give @s loot evercraft:dungeon/key
execute if entity @s[tag=Adv.InMenu] at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:dungeon/key
execute if entity @s[tag=Adv.InMenu] run function evercraft:util/notify/emit
execute if entity @s[tag=Adv.InMenu] run return 0
execute if entity @s[tag=TX.InMenu] if score #inv_full ec.var matches 0 run loot give @s loot evercraft:dungeon/key
execute if entity @s[tag=TX.InMenu] at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:dungeon/key
execute if entity @s[tag=TX.InMenu] run function evercraft:util/notify/emit
execute if entity @s[tag=TX.InMenu] run return 0
execute if entity @s[tag=RF.InMenu] if score #inv_full ec.var matches 0 run loot give @s loot evercraft:dungeon/key
execute if entity @s[tag=RF.InMenu] at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:dungeon/key
execute if entity @s[tag=RF.InMenu] run function evercraft:util/notify/emit
execute if entity @s[tag=RF.InMenu] run return 0
execute if entity @s[tag=HS.InMenu] if score #inv_full ec.var matches 0 run loot give @s loot evercraft:dungeon/key
execute if entity @s[tag=HS.InMenu] at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:dungeon/key
execute if entity @s[tag=HS.InMenu] run function evercraft:util/notify/emit
execute if entity @s[tag=HS.InMenu] run return 0
execute if entity @s[tag=DG.InMenu] if score #inv_full ec.var matches 0 run loot give @s loot evercraft:dungeon/key
execute if entity @s[tag=DG.InMenu] at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:dungeon/key
execute if entity @s[tag=DG.InMenu] run function evercraft:util/notify/emit
execute if entity @s[tag=DG.InMenu] run return 0

# === 30-FLOOR DAILY LIMIT ===
execute if score @s ec.dg_floors_today matches 30.. if score #inv_full ec.var matches 0 run loot give @s loot evercraft:dungeon/key
execute if score @s ec.dg_floors_today matches 30.. at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:dungeon/key
data modify storage evercraft:notify stage.c set value [{text:"You've completed 30 dungeon floors today. Return tomorrow!",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute if score @s ec.dg_floors_today matches 30.. run function evercraft:util/notify/emit
execute if score @s ec.dg_floors_today matches 30.. run return 0

# === OPEN DIFFICULTY SELECTION MENU ===
execute at @s run function evercraft:dungeon/menu/open

# === CHEST-NODE §3 — CRACKED KEY RE-GIVE (deferred 1t for the worn-snapshot race) ===
# The dungeon key was vanilla-consumed on RC; a SUCCESSFUL launch re-gives a CRACKED copy (§3) so the
# player can keep using it on chests (where, if it is ALSO worn, do_open's break rule shatters it). If
# the consumed key was ALREADY worn it is now worn AND cracked -> it BREAKS (no copy re-given). Whether
# the consumed key was worn is snapshotted into ec.cn_keyworn by the dungeon/use_key_worn advancement
# reward (dungeon/mark_key_worn), which fires the SAME tick as this dungeon/start but in an unspecified
# order — so the decision is DEFERRED 1 tick (tag + schedule) to read a settled flag. The deferred
# dungeon/key_handback reads ec.cn_keyworn, hands back the cracked copy or plays the shatter cue, then
# resets the flag + the tag.
tag @s add dg.key_handback
schedule function evercraft:dungeon/key_handback 1t replace
