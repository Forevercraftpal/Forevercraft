# === DUNGEON KEY — CRACKED RE-GIVE / BREAK (Chest-Node §3, deferred 1t from dungeon/start) ===
# Scheduled 1 tick after a successful dungeon launch (dungeon/start tagged dg.key_handback). By now
# the worn-snapshot (ec.cn_keyworn, set by dungeon/mark_key_worn) has settled — both advancement
# rewards for this consume fired last tick. Runs as @a, gated to the tagged players only (existence-
# gated: returns immediately if no player is awaiting a handback).
#
# Decision (§3 key lifecycle):
#   • consumed key was FRESH (ec.cn_keyworn=0) -> re-give a CRACKED copy (dungeon/key_cracked). The
#     player keeps a usable-for-dungeons key that is now cracked; if they later open a chest with it,
#     do_open marks it worn -> worn AND cracked -> it breaks on that next chest attempt.
#   • consumed key was WORN (ec.cn_keyworn=1) -> it is now worn AND cracked -> it BREAKS. No copy is
#     re-given; a shatter cue tells the player the key gave its last turn.
# Then reset ec.cn_keyworn (consumer side of the set-by-event / reset-by-consumer flag pair) + the tag.

# Existence gate — nothing to do unless a tagged player is awaiting a handback.
execute unless entity @a[tag=dg.key_handback] run return 0

# FRESH consumed key -> re-give a cracked copy.
execute as @a[tag=dg.key_handback] unless score @s ec.cn_keyworn matches 1 store result score #inv_full ec.var run function evercraft:util/check_inv_full
execute as @a[tag=dg.key_handback] unless score @s ec.cn_keyworn matches 1 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:dungeon/key_cracked
execute as @a[tag=dg.key_handback] unless score @s ec.cn_keyworn matches 1 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:dungeon/key_cracked

# WORN consumed key -> worn AND cracked = broke. No re-give; play the shatter cue + a line.
execute as @a[tag=dg.key_handback,scores={ec.fx_snd=1..}] if score @s ec.cn_keyworn matches 1 at @s run playsound minecraft:block.glass.break master @s ~ ~ ~ 0.8 0.9
data modify storage evercraft:notify stage.c set value [{text:"⚙ ",color:"#B87333"},{text:"The key shattered",color:"red"},{text:" — worn and cracked, it gave its last turn.",color:"gray"}]
scoreboard players set #ndur ec.temp 50
execute as @a[tag=dg.key_handback] if score @s ec.cn_keyworn matches 1 run function evercraft:util/notify/emit

# Reset the snapshot flag (consumer side) + clear the tag.
scoreboard players set @a[tag=dg.key_handback] ec.cn_keyworn 0
tag @a[tag=dg.key_handback] remove dg.key_handback
