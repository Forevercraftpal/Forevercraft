# Wiring Audit B (2026-05-29) W6: Dungeon HUD — Display (per-party MACRO, seconds < 10, zero-padded).
# Macro args: $(pid), $(wave), $(mobs), $(min), $(sec)
$title @a[tag=dg.player,tag=p$(pid),tag=!ab_q] actionbar [{text:"⚔ Wave ",color:"gold"},{text:"$(wave)",color:"yellow"},{text:"/5 ",color:"gold"},{text:"☠ ",color:"red"},{text:"$(mobs)",color:"yellow"},{text:" left ",color:"red"},{text:"⏱ ",color:"aqua"},{text:"$(min):0$(sec)",color:"yellow"}]
