# === DUNGEON ENDER-NODE — ONE NODE'S RENDER (run AS the ec.dgec_data marker, AT the marker) ===
# Distance-gated: only draw when a player is within ~24 blocks of THIS node (no work for a node on an
# empty/abandoned floor). A soft portal + coppery sparkle befitting the Gearwright theme.
execute unless entity @a[distance=..24,limit=1] run return 0
particle minecraft:portal ~ ~0.55 ~ 0.14 0.22 0.14 0.01 5
particle minecraft:wax_on ~ ~0.5 ~ 0.16 0.22 0.16 0.02 3
