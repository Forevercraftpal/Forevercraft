# === DUNGEON ENDER-NODE — AMBIENT RENDER (10t self-sched, existence-gated, PLAN-chest-nodes §8) ===
# A faint portal shimmer over each dungeon ender-node so players spot the reward on the floor. Mirrors
# chest_nodes/tick_particles' shape: a 10t self-scheduling loop that does NO work unless a node exists.
# No chime (the spawn announce + the node sitting at party center is cue enough inside a dungeon).
schedule function evercraft:dungeon/ender_node/tick_render 10t replace

# Existence-gate: skip the entity scan entirely when no dungeon ender-node is loaded.
execute if entity @e[type=marker,tag=ec.dgec_data,limit=1] as @e[type=marker,tag=ec.dgec_data] at @s run function evercraft:dungeon/ender_node/render_one
