# === DUNGEON ENDER-NODE — PER-NODE SWAP CHECK (run AS ec.dgec_data marker, AT it; C1-ender-swap) ===
# Decides this node's display<->real-block state from owner proximity. "Owner" = any dg.player sharing
# this node's party (the data marker carries the same p<pid> tag the party members do — but matching the
# pid literal would need a macro; the dungeon instance is per-party-isolated in space, so a plain
# dg.player within range of THIS node IS a party member here — no foreign party shares a node spot).
# State lives on the marker as the tag ec.dgec_swapped (set = a real block is currently placed here).
#
# CONFLICT GUARD (decision, see issues[]): a live ec.dgec_click interaction sits on the node cell and
# would intercept the right-click meant for a swapped-in real block. So:
#   * swap-IN fires only once a nearby owner has CLAIMED their private loot pull (dgec.<floor>.looted) —
#     the node first serves its loot purpose (the interaction), THEN becomes that player's one-click
#     ender chest (the real block; the interaction is suppressed while swapped, restored on swap-out).
#   * swap-IN is BLOCKED while ANY not-yet-looted owner is within 3.5, so a party member who still owes a
#     loot pull always keeps the live interaction to claim it (multi-player fairness).
#   * swap-OUT fires when every owner leaves (>3.5) OR a NOT-yet-looted owner steps in (<=2.5) — handing
#     the loot interaction back. Hysteresis (2.5 in / 3.5 out) avoids boundary flicker.

# This node's floor (stamped at spawn) selects the per-player looted tag literal we test against.
scoreboard players set #dgec_floor ec.var 0
execute store result score #dgec_floor ec.var run data get entity @s data.floor

# An unlooted owner near THIS node (<=3.5 for the in-block, <=2.5 for the out-trigger). Per floor: a
# dg.player within range who does NOT carry this floor's looted tag. (#dgec_unl_in blocks swap-in;
# #dgec_unl_out forces swap-out so they regain the interaction.)
scoreboard players set #dgec_unl_in ec.temp 0
scoreboard players set #dgec_unl_out ec.temp 0
execute if score #dgec_floor ec.var matches 3 if entity @a[tag=dg.player,tag=!dgec.3.looted,distance=..3.5,limit=1] run scoreboard players set #dgec_unl_in ec.temp 1
execute if score #dgec_floor ec.var matches 5 if entity @a[tag=dg.player,tag=!dgec.5.looted,distance=..3.5,limit=1] run scoreboard players set #dgec_unl_in ec.temp 1
execute if score #dgec_floor ec.var matches 7 if entity @a[tag=dg.player,tag=!dgec.7.looted,distance=..3.5,limit=1] run scoreboard players set #dgec_unl_in ec.temp 1
execute if score #dgec_floor ec.var matches 9 if entity @a[tag=dg.player,tag=!dgec.9.looted,distance=..3.5,limit=1] run scoreboard players set #dgec_unl_in ec.temp 1
execute if score #dgec_floor ec.var matches 10 if entity @a[tag=dg.player,tag=!dgec.10.looted,distance=..3.5,limit=1] run scoreboard players set #dgec_unl_in ec.temp 1
execute if score #dgec_floor ec.var matches 3 if entity @a[tag=dg.player,tag=!dgec.3.looted,distance=..2.5,limit=1] run scoreboard players set #dgec_unl_out ec.temp 1
execute if score #dgec_floor ec.var matches 5 if entity @a[tag=dg.player,tag=!dgec.5.looted,distance=..2.5,limit=1] run scoreboard players set #dgec_unl_out ec.temp 1
execute if score #dgec_floor ec.var matches 7 if entity @a[tag=dg.player,tag=!dgec.7.looted,distance=..2.5,limit=1] run scoreboard players set #dgec_unl_out ec.temp 1
execute if score #dgec_floor ec.var matches 9 if entity @a[tag=dg.player,tag=!dgec.9.looted,distance=..2.5,limit=1] run scoreboard players set #dgec_unl_out ec.temp 1
execute if score #dgec_floor ec.var matches 10 if entity @a[tag=dg.player,tag=!dgec.10.looted,distance=..2.5,limit=1] run scoreboard players set #dgec_unl_out ec.temp 1

# --- SWAP IN: no real block yet + a LOOTED owner within ~2.5 + NO unlooted owner within 3.5 + placeable.
execute unless entity @s[tag=ec.dgec_swapped] if score #dgec_unl_in ec.temp matches 0 if score #dgec_floor ec.var matches 3 if entity @a[tag=dg.player,tag=dgec.3.looted,distance=..2.5,limit=1] run function evercraft:dungeon/ender_node/swap_in
execute unless entity @s[tag=ec.dgec_swapped] if score #dgec_unl_in ec.temp matches 0 if score #dgec_floor ec.var matches 5 if entity @a[tag=dg.player,tag=dgec.5.looted,distance=..2.5,limit=1] run function evercraft:dungeon/ender_node/swap_in
execute unless entity @s[tag=ec.dgec_swapped] if score #dgec_unl_in ec.temp matches 0 if score #dgec_floor ec.var matches 7 if entity @a[tag=dg.player,tag=dgec.7.looted,distance=..2.5,limit=1] run function evercraft:dungeon/ender_node/swap_in
execute unless entity @s[tag=ec.dgec_swapped] if score #dgec_unl_in ec.temp matches 0 if score #dgec_floor ec.var matches 9 if entity @a[tag=dg.player,tag=dgec.9.looted,distance=..2.5,limit=1] run function evercraft:dungeon/ender_node/swap_in
execute unless entity @s[tag=ec.dgec_swapped] if score #dgec_unl_in ec.temp matches 0 if score #dgec_floor ec.var matches 10 if entity @a[tag=dg.player,tag=dgec.10.looted,distance=..2.5,limit=1] run function evercraft:dungeon/ender_node/swap_in

# --- SWAP OUT: a real block is placed + (every owner left >3.5 OR a not-yet-looted owner stepped in). ---
execute if entity @s[tag=ec.dgec_swapped] unless entity @a[tag=dg.player,distance=..3.5,limit=1] run function evercraft:dungeon/ender_node/swap_out
execute if entity @s[tag=ec.dgec_swapped] if score #dgec_unl_out ec.temp matches 1 run function evercraft:dungeon/ender_node/swap_out
