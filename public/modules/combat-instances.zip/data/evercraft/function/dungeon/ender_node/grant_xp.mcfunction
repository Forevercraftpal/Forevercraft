# === DUNGEON ENDER-NODE — GRANT GEARWRIGHT XP (PLAN-chest-nodes §8 / §14.12) ===
# Run AS the opening dungeon player. Opening an ender-node levels Gearwright (the 7th Craft-Affinity
# class, id 7) — the SAME XP grant the overworld nodes give (§8: "they share only the Tinkering-XP
# grant + the shift-RC ender mechanism"). A direct craft_affinity/grant {class_id:7, ...} is the clean
# path here (the node isn't routed through the gather harvest engine, so no gth_src=5 round-trip needed).
# A guaranteed dungeon reward is worth more than a single overworld pull -> grant a generous 40 XP/open.
function evercraft:craft_affinity/grant {class_id:7, delta:40}
