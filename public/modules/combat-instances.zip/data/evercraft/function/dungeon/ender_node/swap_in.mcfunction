# === DUNGEON ENDER-NODE — SWAP IN (run AS ec.dgec_data marker, AT it; C1-ender-swap) ===
# An owner has stepped close: replace the from-afar display with a REAL minecraft:ender_chest at the node
# block so the player opens their native ender inventory in ONE right-click. Validate the cell is
# spawnable-air with solid footing (never overwrite a real block, never float). On success: stamp the
# EXACT block coords onto the data marker (data.real.{x,y,z} — what swap_out / cleanup remove, NEVER a
# block-type scan), drop a co-located ec.dgec_real owner marker, hide the display, suppress the loot
# interaction, set the swapped flag.

# The data marker sits ~0.3 above the floor (spawn raised it); the real-block cell is the marker's
# block-aligned position. Validate: spawnable-air at the cell AND solid footing directly below.
scoreboard players set #dgec_ok ec.temp 0
execute if block ~ ~ ~ #evercraft:spawnable_air unless block ~ ~-1 ~ #evercraft:spawnable_air run scoreboard players set #dgec_ok ec.temp 1
# Spot blocked or floating -> leave the display up; the owner can approach from clearer footing (the
# sneak-RC portable-ender fallback in on_click still works while no swap is placed).
execute if score #dgec_ok ec.temp matches 0 run return 0

# Place the real ender_chest at the block-aligned cell + a co-located owner marker AT the cell CENTER.
# `align xyz` floors the position to the block grid on every axis sign (no negative-coord off-by-one), so
# place + the coords we read back from the centered marker name the SAME cell swap_out / cleanup remove.
execute align xyz run setblock ~ ~ ~ minecraft:ender_chest replace
execute align xyz run summon marker ~0.5 ~0.5 ~0.5 {Tags:["ec.dgec","ec.dgec_real","ec.dgec_real_new"]}

# Stamp the block coords on the data marker (data.real) — the cleanup GATE + the documented exact-coord
# key. The AUTHORITATIVE removal target is the co-located ec.dgec_real marker itself (remove_real runs AT
# it, exact on every coord sign); data.real records the same cell + lets cleanup detect "is this node
# swapped?" without a block scan. Read from the centered owner marker's Pos.
execute store result entity @s data.real.x int 1 run data get entity @e[type=marker,tag=ec.dgec_real_new,limit=1] Pos[0] 1
execute store result entity @s data.real.y int 1 run data get entity @e[type=marker,tag=ec.dgec_real_new,limit=1] Pos[1] 1
execute store result entity @s data.real.z int 1 run data get entity @e[type=marker,tag=ec.dgec_real_new,limit=1] Pos[2] 1
tag @e[type=marker,tag=ec.dgec_real_new] remove ec.dgec_real_new

# Hide the from-afar display while the real block stands (scale to 0; restored on swap_out). The visual
# shares this node's block cell, so the nearest ec.dgec_vis is THIS node's display.
execute as @e[type=item_display,tag=ec.dgec_vis,distance=..1.5,limit=1,sort=nearest] run data modify entity @s transformation.scale set value [0f,0f,0f]

# Suppress THIS node's loot interaction so the real block (not the interaction) receives right-clicks for
# native ender access. Drop response to 0b + shrink the hitbox; swap_out restores 1b + the 0.95 box. The
# swap-in gate (swap_check) only fires once every nearby owner has looted, so no pending loot is blocked.
execute as @e[type=interaction,tag=ec.dgec_click,distance=..1.5,limit=1,sort=nearest] run data modify entity @s response set value 0b
execute as @e[type=interaction,tag=ec.dgec_click,distance=..1.5,limit=1,sort=nearest] run data modify entity @s height set value 0.01f

# Mark this node swapped + a soft coppery cue (the chest "rose" to meet the player).
tag @s add ec.dgec_swapped
playsound minecraft:block.copper_bulb.turn_on master @a[distance=..6,scores={ec.fx_snd=1..}] ~ ~ ~ 0.5 1.2
particle minecraft:wax_on ~ ~0.4 ~ 0.2 0.2 0.2 0.02 6
