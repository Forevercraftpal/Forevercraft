# === DUNGEON ENDER-NODE — PROXIMITY SWAP TICK (1s self-sched, existence-gated, C1-ender-swap) ===
# The owner-proximity swap (Joseph-approved reroute of the clunky 2-click sneak-RC). From afar the node
# shows a small ender_chest item_display (ec.dgec_vis). When an OWNER (any dg.player of this node's party)
# steps within ~2.5 blocks, SWAP: hide the display + setblock a REAL minecraft:ender_chest at the node
# spot so the player opens their ACTUAL ender inventory natively in ONE right-click. When every owner
# steps >3 blocks away (or the node is consumed/cleaned/expires), the real block is removed + the display
# restored. Cleanup keys ONLY on the owner-stamped ec.dgec_real marker + the exact coords stored on the
# data marker (data.real.{x,y,z}) — NEVER a block-type scan — so a real player-placed ender chest at the
# node spot is never griefed.
schedule function evercraft:dungeon/ender_node/node_tick 1s replace

# Existence-gate: skip the whole sweep when no dungeon ender-node data marker is loaded.
execute if entity @e[type=marker,tag=ec.dgec_data,limit=1] as @e[type=marker,tag=ec.dgec_data] at @s run function evercraft:dungeon/ender_node/swap_check
