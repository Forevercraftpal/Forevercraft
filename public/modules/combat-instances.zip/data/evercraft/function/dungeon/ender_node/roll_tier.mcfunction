# === DUNGEON ENDER-NODE — ROLL_TIER (per-player private tier, clone of dungeon/reward_player) ===
# Run AS the opening dungeon player, AT the player. Reads THIS player's own Dream Rate (minecraft:luck)
# and grants the matching crate-items pull — the SAME DR ladder dungeon/reward_player uses (§8: each
# player "reads their own DR, rolls a private tier"), kept self-contained (no #dg_difficulty/#dg_omen
# minimums — the ender-node is the convenience/reward variant, so it's a clean luck-only roll). The
# crates/items/<tier> loot tables are the established per-tier reward pools (shared with reward_player).
# #dgec_dr is a private scratch fakeplayer (sole writer = this file), so concurrent per-player runs in
# the sequential interaction scan never race.

# Read THIS player's Dream Rate (luck attribute) into the private scratch.
execute store result score #dgec_dr ec.var run attribute @s minecraft:luck get

# Check THIS player's inventory space (full -> drop at feet instead of voiding loot).
execute store result score #dgec_inv ec.var run function evercraft:util/check_inv_full

# === REWARD TIERS (DR ladder, mirrors dungeon/reward_player) ===
# DR 0-6: Common · 7-12: Uncommon · 13-17: Rare · 18-22: Ornate · 23-29: Exquisite · 30+: Mythical

# Common (DR 0-6)
execute if score #dgec_dr ec.var matches ..6 if score #dgec_inv ec.var matches 0 run loot give @s loot evercraft:crates/items/common
execute if score #dgec_dr ec.var matches ..6 if score #dgec_inv ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:crates/items/common
execute if score #dgec_dr ec.var matches ..6 if score #dgec_inv ec.var matches 0 run give @s emerald 16
execute if score #dgec_dr ec.var matches ..6 if score #dgec_inv ec.var matches 1 at @s run summon item ~ ~ ~ {Item:{id:"minecraft:emerald",count:16}}
execute if score #dgec_dr ec.var matches ..6 run experience add @s 200 points
data modify storage evercraft:notify stage.c set value [{text:"Ender-Node: ",color:"#B87333"},{text:"Common Crate",color:"white"}]
scoreboard players set #ndur ec.temp 45
execute if score #dgec_dr ec.var matches ..6 run function evercraft:util/notify/emit

# Uncommon (DR 7-12)
execute if score #dgec_dr ec.var matches 7..12 if score #dgec_inv ec.var matches 0 run loot give @s loot evercraft:crates/items/uncommon
execute if score #dgec_dr ec.var matches 7..12 if score #dgec_inv ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:crates/items/uncommon
execute if score #dgec_dr ec.var matches 7..12 if score #dgec_inv ec.var matches 0 run give @s emerald 24
execute if score #dgec_dr ec.var matches 7..12 if score #dgec_inv ec.var matches 1 at @s run summon item ~ ~ ~ {Item:{id:"minecraft:emerald",count:24}}
execute if score #dgec_dr ec.var matches 7..12 run experience add @s 400 points
data modify storage evercraft:notify stage.c set value [{text:"Ender-Node: ",color:"#B87333"},{text:"Uncommon Crate",color:"green"}]
scoreboard players set #ndur ec.temp 45
execute if score #dgec_dr ec.var matches 7..12 run function evercraft:util/notify/emit

# Rare (DR 13-17)
execute if score #dgec_dr ec.var matches 13..17 if score #dgec_inv ec.var matches 0 run loot give @s loot evercraft:crates/items/rare
execute if score #dgec_dr ec.var matches 13..17 if score #dgec_inv ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:crates/items/rare
execute if score #dgec_dr ec.var matches 13..17 if score #dgec_inv ec.var matches 0 run give @s emerald 32
execute if score #dgec_dr ec.var matches 13..17 if score #dgec_inv ec.var matches 1 at @s run summon item ~ ~ ~ {Item:{id:"minecraft:emerald",count:32}}
execute if score #dgec_dr ec.var matches 13..17 run experience add @s 800 points
data modify storage evercraft:notify stage.c set value [{text:"Ender-Node: ",color:"#B87333"},{text:"Rare Crate",color:"aqua"}]
scoreboard players set #ndur ec.temp 45
execute if score #dgec_dr ec.var matches 13..17 run function evercraft:util/notify/emit

# Ornate (DR 18-22)
execute if score #dgec_dr ec.var matches 18..22 if score #dgec_inv ec.var matches 0 run loot give @s loot evercraft:crates/items/ornate
execute if score #dgec_dr ec.var matches 18..22 if score #dgec_inv ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:crates/items/ornate
execute if score #dgec_dr ec.var matches 18..22 if score #dgec_inv ec.var matches 0 run give @s emerald 48
execute if score #dgec_dr ec.var matches 18..22 if score #dgec_inv ec.var matches 1 at @s run summon item ~ ~ ~ {Item:{id:"minecraft:emerald",count:48}}
execute if score #dgec_dr ec.var matches 18..22 run experience add @s 1500 points
data modify storage evercraft:notify stage.c set value [{text:"Ender-Node: ",color:"#B87333"},{text:"Ornate Crate",color:"light_purple"}]
scoreboard players set #ndur ec.temp 45
execute if score #dgec_dr ec.var matches 18..22 run function evercraft:util/notify/emit

# Exquisite (DR 23-29)
execute if score #dgec_dr ec.var matches 23..29 if score #dgec_inv ec.var matches 0 run loot give @s loot evercraft:crates/items/exquisite
execute if score #dgec_dr ec.var matches 23..29 if score #dgec_inv ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:crates/items/exquisite
execute if score #dgec_dr ec.var matches 23..29 if score #dgec_inv ec.var matches 0 run give @s emerald 64
execute if score #dgec_dr ec.var matches 23..29 if score #dgec_inv ec.var matches 1 at @s run summon item ~ ~ ~ {Item:{id:"minecraft:emerald",count:64}}
execute if score #dgec_dr ec.var matches 23..29 run experience add @s 3000 points
data modify storage evercraft:notify stage.c set value [{text:"Ender-Node: ",color:"#B87333"},{text:"Exquisite Crate",color:"light_purple"}]
scoreboard players set #ndur ec.temp 45
execute if score #dgec_dr ec.var matches 23..29 run function evercraft:util/notify/emit

# Mythical (DR 30+)
execute if score #dgec_dr ec.var matches 30.. if score #dgec_inv ec.var matches 0 run loot give @s loot evercraft:crates/items/mythical
execute if score #dgec_dr ec.var matches 30.. if score #dgec_inv ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:crates/items/mythical
execute if score #dgec_dr ec.var matches 30.. if score #dgec_inv ec.var matches 0 run give @s emerald_block 4
execute if score #dgec_dr ec.var matches 30.. if score #dgec_inv ec.var matches 1 at @s run summon item ~ ~ ~ {Item:{id:"minecraft:emerald_block",count:4}}
execute if score #dgec_dr ec.var matches 30.. run experience add @s 5000 points
data modify storage evercraft:notify stage.c set value [{text:"Ender-Node: ",color:"#B87333"},{text:"Mythical Crate!",color:"gold",bold:true}]
scoreboard players set #ndur ec.temp 45
execute if score #dgec_dr ec.var matches 30.. run function evercraft:util/notify/emit

# Inventory-full warning (loot was dropped at the player's feet above).
data modify storage evercraft:notify stage.c set value [{text:"Inventory full! Some loot was dropped at your feet.",color:"yellow"}]
scoreboard players set #ndur ec.temp 45
execute if score #dgec_inv ec.var matches 1 run function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. if score #dgec_inv ec.var matches 1 run playsound minecraft:block.note_block.bass player @s ~ ~ ~ 1 0.5
