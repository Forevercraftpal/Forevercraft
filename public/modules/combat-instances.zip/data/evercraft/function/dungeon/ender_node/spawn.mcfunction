# === DUNGEON ENDER-NODE — SPAWN (per-party MACRO, PLAN-chest-nodes §8 / §14.12) ===
# Called with storage evercraft:_shared cart for $(pid) from:
#   - dungeon/floor/descend  (AFTER the :5 floor-increment) for floors 3 / 5 / 7 / 9
#   - dungeon/complete       (BEFORE the :7 raids/check_entry handoff) for floor 10
# Spawns ONE guaranteed per-party ender-node at this party's center marker — the reward/convenience
# variant of the chest node (§8): NO key, NO trap, NO 50/50 harvest roll. It shares ONLY the Gearwright
# XP grant + the shift-RC portable-ender mechanism with the overworld nodes; it does NOT route through
# the chest_nodes spawn engine (no chime pressure, no 60s despawn, no harvest gate). Per-player loot is a
# PRIVATE pull each player claims once (dgec.<floor>.looted tag) — first-come does NOT consume it for
# others. The node lives until the party leaves the floor (cleanup / descend kills it by p$(pid) tag).
#
# Marker family (own — distinct from the overworld ec.chest_* engine):
#   ec.dgec_data  : data marker holding data.floor (1..10). Tagged p$(pid) for per-party isolation.
#   ec.dgec_vis   : ender_chest item_display (the visible node).
#   ec.dgec_click : interaction hitbox (tick.mcfunction scans it -> dungeon/ender_node/on_click).
# All three carry the shared ec.dgec tag + p$(pid) so the existing per-party cleanup sweep removes them.

# Clear any stale per-player looted flags for this party (a fresh node = a fresh pull for everyone). The
# floor is a SCORE (#dg_floor.$(pid)), not a cart field, so the floor-suffixed tag literal can't be macro-
# built here — but only 5 floors carry a node, so clearing all 5 explicitly is cheap + unambiguous. The
# floor itself is stamped on the data marker below (read straight from the score) for on_click to read.
$tag @a[tag=dg.player,tag=p$(pid)] remove dgec.3.looted
$tag @a[tag=dg.player,tag=p$(pid)] remove dgec.5.looted
$tag @a[tag=dg.player,tag=p$(pid)] remove dgec.7.looted
$tag @a[tag=dg.player,tag=p$(pid)] remove dgec.9.looted
$tag @a[tag=dg.player,tag=p$(pid)] remove dgec.10.looted

# --- Spawn the node entities at this party's center marker (slightly raised so the display sits on the
#     floor + the interaction covers the block). The center marker is the canonical per-party anchor. ---
$execute at @e[type=marker,tag=dg.center,tag=p$(pid),limit=1] run summon marker ~ ~0.3 ~2 {Tags:["ec.dgec","ec.dgec_data","ec.dgec_new","p$(pid)"]}
# Stamp the floor on the data marker (drives on_click's per-player looted-flag lookup).
$execute store result entity @e[type=marker,tag=ec.dgec_new,limit=1] data.floor int 1 run scoreboard players get #dg_floor.$(pid) ec.var

# Visible ender_chest item_display — scaled to a "mini" node, billboard:fixed so it sits on the ground.
$execute at @e[type=marker,tag=ec.dgec_new,limit=1] run summon item_display ~ ~ ~ {Tags:["ec.dgec","ec.dgec_vis","p$(pid)"],item:{id:"minecraft:ender_chest",count:1},item_display:"fixed",transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0.0f,0f],scale:[0.85f,0.85f,0.85f]},billboard:"fixed"}

# Interaction hitbox (the right-click target; the tick scan routes it to on_click).
$execute at @e[type=marker,tag=ec.dgec_new,limit=1] run summon interaction ~ ~0.05 ~ {Tags:["ec.dgec","ec.dgec_click","p$(pid)"],width:0.95f,height:0.95f,response:1b}

# Drop the transient new-tag now that the three entities are co-placed.
tag @e[type=marker,tag=ec.dgec_new] remove ec.dgec_new

# --- Announce + cue the party (the node is a guaranteed reward — make it inviting, copper-themed). ---
data modify storage evercraft:notify stage.c set value [{text:"⚙ ",color:"#B87333"},{text:"An ",color:"gray"},{text:"ender-node",color:"#B87333"},{text:" hums on this floor — right-click for loot, sneak-right-click for your ender chest.",color:"gray"}]
scoreboard players set #ndur ec.temp 70
$execute as @a[tag=dg.player,tag=p$(pid)] run function evercraft:util/notify/emit
$playsound minecraft:block.ender_chest.open master @a[tag=dg.player,tag=p$(pid),scores={ec.fx_snd=1..}] ~ ~ ~ 0.6 1.3
$playsound minecraft:block.amethyst_block.chime master @a[tag=dg.player,tag=p$(pid),scores={ec.fx_snd=1..}] ~ ~ ~ 0.5 1.5
$execute at @e[type=marker,tag=ec.dgec_data,tag=p$(pid),limit=1] run particle minecraft:portal ~ ~0.5 ~ 0.3 0.4 0.3 0.05 30
$execute at @e[type=marker,tag=ec.dgec_data,tag=p$(pid),limit=1] run particle minecraft:wax_on ~ ~0.5 ~ 0.3 0.3 0.3 0.05 12
