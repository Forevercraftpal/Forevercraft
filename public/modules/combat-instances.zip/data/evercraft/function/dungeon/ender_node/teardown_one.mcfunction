# === DUNGEON ENDER-NODE — TEARDOWN ONE NODE'S REAL BLOCK (run AS ec.dgec_data marker; C1-ender-swap) ===
# Run AS a swapped-in data marker (it carries data.real / has a co-located ec.dgec_real owner marker).
# Removes the real ender_chest at the EXACT cell of this node's owner marker (grief-guarded to
# ender_chest) + kills the marker, via the shared remove_real. The data marker itself is killed right
# after by dungeon/cleanup's $kill @e[tag=ec.dgec,tag=p<pid>] sweep, so no flag-clear is needed here.
function evercraft:dungeon/ender_node/remove_real
