# === DUNGEON ENDER-NODE — ALREADY-CLAIMED CUE (PLAN-chest-nodes §8 / §14.12) ===
# Run AS the dungeon player who re-clicked an ender-node they've already pulled from. The per-player
# pull is once-per-node (the dgec.<floor>.looted tag) — a gentle "nothing left for you" cue so the
# re-click is never silent (others may still have their own pull; this is purely this player's state).
data modify storage evercraft:notify stage.c set value [{text:"⚙ ",color:"#B87333"},{text:"You've already claimed your share",color:"gray"},{text:" from this ender-node.",color:"gray"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.copper_trapdoor.close master @s ~ ~ ~ 0.5 1.1
