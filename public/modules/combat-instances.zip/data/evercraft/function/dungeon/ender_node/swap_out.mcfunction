# === DUNGEON ENDER-NODE — SWAP OUT (run AS ec.dgec_data marker, AT it; C1-ender-swap) ===
# Every owner stepped away (>3.5) OR a not-yet-looted owner stepped in: remove the real ender_chest +
# restore the from-afar display + the loot interaction. Removal keys on this node's co-located
# ec.dgec_real owner marker (exact-cell, grief-guarded) — NEVER a block-type scan — so a player's REAL
# placed ender chest is never touched.

# Remove the real block at the exact cell of this node's owner marker + kill the marker.
function evercraft:dungeon/ender_node/remove_real

# Restore the from-afar display (scale back to the spawn value) + the loot interaction (response 1b +
# the full 0.95 hitbox) so a not-yet-looted party member can claim their pull again on re-approach.
execute as @e[type=item_display,tag=ec.dgec_vis,distance=..1.5,limit=1,sort=nearest] run data modify entity @s transformation.scale set value [0.85f,0.85f,0.85f]
execute as @e[type=interaction,tag=ec.dgec_click,distance=..1.5,limit=1,sort=nearest] run data modify entity @s response set value 1b
execute as @e[type=interaction,tag=ec.dgec_click,distance=..1.5,limit=1,sort=nearest] run data modify entity @s height set value 0.95f

# Clear the swap state on the marker.
tag @s remove ec.dgec_swapped
data remove entity @s data.real
