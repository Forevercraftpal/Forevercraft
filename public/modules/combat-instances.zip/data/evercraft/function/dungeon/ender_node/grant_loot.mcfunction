# === DUNGEON ENDER-NODE — GRANT_LOOT (per-player PRIVATE pull, PLAN-chest-nodes §8 / §14.12) ===
# Run AS the opening dungeon player, AT the player. #dgec_floor (set by on_click) is THIS node's floor.
# Each party member claims exactly ONE private pull from the SAME node — gated by a per-player, per-floor
# tag dgec.<floor>.looted. First-come does NOT consume it for the others (the node is per-PARTY, the flag
# is per-PLAYER). The tier itself is rolled from THIS player's own Dream Rate (minecraft:luck), cloning
# the canonical dungeon/reward_player tier ladder (§8: "each reads their own DR, rolls a private tier").
#
# The looted tag is floor-specific (dgec.<floor>.looted). Only 5 floors carry an ender-node (3/5/7/9/10),
# so we branch explicitly per floor (cheaper + clearer than a macro): if already looted -> a soft "you
# already claimed this" cue + return; else stamp the tag and fall through to the shared tier roll.

# --- Already-claimed gate (per floor). On a repeat: a gentle cue, then stop (no double pull). ---
execute if score #dgec_floor ec.var matches 3 if entity @s[tag=dgec.3.looted] run return run function evercraft:dungeon/ender_node/already_looted
execute if score #dgec_floor ec.var matches 5 if entity @s[tag=dgec.5.looted] run return run function evercraft:dungeon/ender_node/already_looted
execute if score #dgec_floor ec.var matches 7 if entity @s[tag=dgec.7.looted] run return run function evercraft:dungeon/ender_node/already_looted
execute if score #dgec_floor ec.var matches 9 if entity @s[tag=dgec.9.looted] run return run function evercraft:dungeon/ender_node/already_looted
execute if score #dgec_floor ec.var matches 10 if entity @s[tag=dgec.10.looted] run return run function evercraft:dungeon/ender_node/already_looted

# --- Stamp the per-player per-floor looted flag (this player has now claimed THIS node's pull). ---
execute if score #dgec_floor ec.var matches 3 run tag @s add dgec.3.looted
execute if score #dgec_floor ec.var matches 5 run tag @s add dgec.5.looted
execute if score #dgec_floor ec.var matches 7 run tag @s add dgec.7.looted
execute if score #dgec_floor ec.var matches 9 run tag @s add dgec.9.looted
execute if score #dgec_floor ec.var matches 10 run tag @s add dgec.10.looted

# --- Roll + grant THIS player's private tier from their own Dream Rate, then the Gearwright XP. ---
function evercraft:dungeon/ender_node/roll_tier
function evercraft:dungeon/ender_node/grant_xp

# Open cue (the visible ender_chest "opens" for this player) + a coppery success sparkle at the node.
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.ender_chest.open master @s ~ ~ ~ 0.8 1.0
execute at @e[type=marker,tag=ec.dgec_data,distance=..4,limit=1,sort=nearest] run particle minecraft:totem_of_undying ~ ~0.6 ~ 0.3 0.4 0.3 0.1 24
