# === DUNGEON ENDER-NODE — ON_CLICK (PLAN-chest-nodes §8 / §14.12) ===
# Run AS the ec.dgec_click interaction entity, AT the node position (tick.mcfunction scans the
# interaction + consumes it, mirroring the ec.chest_click scan). Two intents on the nearest dungeon
# player within ~3 blocks:
#   - SNEAK   -> open the player's PERSONAL temp ender chest (portable_ender/open, the §6 mechanism).
#   - non-SNK -> claim THIS player's PRIVATE loot pull (grant_loot), once per node (dgec.<floor>.looted).
# The node is GUARANTEED + per-party + shared (each party member gets their OWN pull) — first-come does
# NOT consume it for others. Only a dungeon participant (dg.player) may interact (non-party players in a
# co-located instance never reach a foreign party's center anyway, but the dg.player gate makes it safe).

# Read this node's floor into a global so grant_loot resolves the per-player looted-flag for the right
# floor. The interaction shares its position with the ec.dgec_data marker (co-placed at spawn).
scoreboard players set #dgec_floor ec.var 0
execute store result score #dgec_floor ec.var run data get entity @e[type=marker,tag=ec.dgec_data,distance=..4,limit=1,sort=nearest] data.floor

# No data marker within reach (a cleanup raced the click) -> nothing to open.
execute unless entity @e[type=marker,tag=ec.dgec_data,distance=..4,limit=1] run return 0

# The nearest dungeon participant within ~3 blocks is the actor.
#   SNEAK + dg.player -> portable ender (run AS + AT the player so the temp chest places at their feet).
execute as @p[distance=..3,tag=dg.player] at @s if predicate evercraft:is_sneaking run return run function evercraft:portable_ender/open
#   non-sneak + dg.player -> the private loot pull (run AS + AT the player for the loot grant + DR read).
execute as @p[distance=..3,tag=dg.player] at @s run function evercraft:dungeon/ender_node/grant_loot
