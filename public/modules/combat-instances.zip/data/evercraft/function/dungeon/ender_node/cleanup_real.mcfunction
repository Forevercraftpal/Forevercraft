# === DUNGEON ENDER-NODE — TEARDOWN SWAP-OUT (per-party MACRO; C1-ender-swap) ===
# Called from dungeon/cleanup BEFORE it kills this party's ec.dgec entities. If this party's node is
# currently swapped-in (a real ender_chest is placed), remove that block at the EXACT stored coords
# (grief-guarded) + its ec.dgec_real owner marker — so a consumed / abandoned node never leaks a real
# block. Keys on the data marker's data.real coords, NEVER a block-type scan (a player's own placed
# ender chest at the node spot is untouched). No-op when the node was never swapped (no data.real).
#
# Run plain (not AS the marker): we read the party's data marker by its p<pid> tag via the macro pid.

# Only this party's data marker that actually has a real block placed (data.real present) needs teardown.
$execute as @e[type=marker,tag=ec.dgec_data,tag=p$(pid),limit=1] if data entity @s data.real run function evercraft:dungeon/ender_node/teardown_one
