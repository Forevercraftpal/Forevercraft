# === DUNGEON ENDER-NODE — REMOVE THIS NODE'S REAL BLOCK (run AS ec.dgec_data marker, AT it) ===
# Shared removal for swap_out (owner walked away) AND teardown_one (party left / node consumed). Removes
# the real ender_chest at the EXACT cell of this node's co-located ec.dgec_real owner marker — the marker
# was summoned at the placed cell's CENTER (align xyz), so `at` the marker + `setblock ~ ~ ~` names
# EXACTLY the placed cell on every coord sign (no truncate/floor off-by-one). Grief-guarded: only an
# ender_chest is cleared, so a player's REAL placed ender chest is never touched. Then kill the marker.
# This keys on the owner-stamped marker (+ the data.real coords it was stamped from), NEVER a block scan.
execute at @e[type=marker,tag=ec.dgec_real,distance=..2,limit=1,sort=nearest] if block ~ ~ ~ minecraft:ender_chest run setblock ~ ~ ~ minecraft:air replace
execute at @e[type=marker,tag=ec.dgec_real,distance=..2,limit=1,sort=nearest] run particle minecraft:wax_off ~ ~0.5 ~ 0.3 0.3 0.3 0.02 8
kill @e[type=marker,tag=ec.dgec_real,distance=..2]
