# Wiring Audit B (2026-05-29) W6: Dungeon Lockout — Set lockout score (per-party MACRO).
# Called with storage evercraft:_shared cart for $(pid) from complete.
# Stores gametime into dg.lo_X for THIS party's dg.player participants only.
# Reads #dg_struct_id.$(pid) per-party; legacy global #dg_struct_id is still staged by complete.

$execute if score #dg_struct_id.$(pid) ec.var matches 1 store result score @a[tag=dg.player,tag=p$(pid)] dg.lo_1 run time query gametime
$execute if score #dg_struct_id.$(pid) ec.var matches 2 store result score @a[tag=dg.player,tag=p$(pid)] dg.lo_2 run time query gametime
$execute if score #dg_struct_id.$(pid) ec.var matches 3 store result score @a[tag=dg.player,tag=p$(pid)] dg.lo_3 run time query gametime
$execute if score #dg_struct_id.$(pid) ec.var matches 4 store result score @a[tag=dg.player,tag=p$(pid)] dg.lo_4 run time query gametime
$execute if score #dg_struct_id.$(pid) ec.var matches 5 store result score @a[tag=dg.player,tag=p$(pid)] dg.lo_5 run time query gametime
$execute if score #dg_struct_id.$(pid) ec.var matches 6 store result score @a[tag=dg.player,tag=p$(pid)] dg.lo_6 run time query gametime
$execute if score #dg_struct_id.$(pid) ec.var matches 7 store result score @a[tag=dg.player,tag=p$(pid)] dg.lo_7 run time query gametime
$execute if score #dg_struct_id.$(pid) ec.var matches 8 store result score @a[tag=dg.player,tag=p$(pid)] dg.lo_8 run time query gametime
$execute if score #dg_struct_id.$(pid) ec.var matches 9 store result score @a[tag=dg.player,tag=p$(pid)] dg.lo_9 run time query gametime
$execute if score #dg_struct_id.$(pid) ec.var matches 10 store result score @a[tag=dg.player,tag=p$(pid)] dg.lo_10 run time query gametime
$execute if score #dg_struct_id.$(pid) ec.var matches 11 store result score @a[tag=dg.player,tag=p$(pid)] dg.lo_11 run time query gametime
$execute if score #dg_struct_id.$(pid) ec.var matches 12 store result score @a[tag=dg.player,tag=p$(pid)] dg.lo_12 run time query gametime
$execute if score #dg_struct_id.$(pid) ec.var matches 13 store result score @a[tag=dg.player,tag=p$(pid)] dg.lo_13 run time query gametime
$execute if score #dg_struct_id.$(pid) ec.var matches 14 store result score @a[tag=dg.player,tag=p$(pid)] dg.lo_14 run time query gametime
$execute if score #dg_struct_id.$(pid) ec.var matches 17 store result score @a[tag=dg.player,tag=p$(pid)] dg.lo_17 run time query gametime
$execute if score #dg_struct_id.$(pid) ec.var matches 18 store result score @a[tag=dg.player,tag=p$(pid)] dg.lo_18 run time query gametime
$execute if score #dg_struct_id.$(pid) ec.var matches 19 store result score @a[tag=dg.player,tag=p$(pid)] dg.lo_19 run time query gametime

# Set gate flag so expiry tick checks this party's participants
$scoreboard players set @a[tag=dg.player,tag=p$(pid)] dg.lo_any 1
