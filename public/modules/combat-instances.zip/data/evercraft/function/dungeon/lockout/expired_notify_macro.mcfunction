# Dungeon Lockout — Expired notification (macro)
$data modify storage evercraft:notify stage.c set value [{text:"Your ",color:"green"},{text:"$(struct_name)",color:"light_purple",bold:true},{text:" cooldown has expired! You may challenge it again.",color:"green"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
