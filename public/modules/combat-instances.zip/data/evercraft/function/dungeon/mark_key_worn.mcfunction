# === DUNGEON KEY — WORN SNAPSHOT (Chest-Node §3 key lifecycle) ===
# Run as @s = player. Fired by the dungeon/use_key_worn advancement the same tick the player consumes
# a dungeon key that was ALREADY worn (custom_data{dungeon_key:true,worn:1b}). The key is vanilla-
# consumed on RC before dungeon/start can inspect its NBT, so this snapshots the worn state into
# ec.cn_keyworn for dungeon/start's cracked-re-give decision: worn key used for a dungeon = worn AND
# cracked -> BREAK (give nothing), vs a fresh key -> re-give a cracked copy.
#
# ec.cn_keyworn writers: this advancement reward SETS it to 1 (the worn-key-consumed event); the
# consumer dungeon/start RESETS it to 0 after reading (set-by-event / reset-by-consumer flag pair,
# the sanctioned flag idiom — the two writers never race because the consume + the launch are the
# same player action in the same advancement chain).
advancement revoke @s only evercraft:dungeon/use_key_worn
scoreboard players set @s ec.cn_keyworn 1
