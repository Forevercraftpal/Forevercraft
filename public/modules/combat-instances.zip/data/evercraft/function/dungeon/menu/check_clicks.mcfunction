# Dungeon Difficulty Menu — Check Clicks
# Run as: player with DG.InMenu

# Cancel button
scoreboard players operation #gui_check ec.temp = @s adv.gui_session
execute as @e[type=interaction,tag=DG.CancelBtn,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction on target run function evercraft:dungeon/menu/close
execute as @e[type=interaction,tag=DG.CancelBtn,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction run data remove entity @s interaction

# Easy button (difficulty 0)
execute as @e[type=interaction,tag=DG.EasyBtn,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction on target run function evercraft:dungeon/menu/select {difficulty:0,label:"Easy",color:"green"}
execute as @e[type=interaction,tag=DG.EasyBtn,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction run data remove entity @s interaction

# Normal button (difficulty 1)
execute as @e[type=interaction,tag=DG.NormalBtn,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction on target run function evercraft:dungeon/menu/select {difficulty:1,label:"Normal",color:"yellow"}
execute as @e[type=interaction,tag=DG.NormalBtn,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction run data remove entity @s interaction

# Hard button (difficulty 2)
execute as @e[type=interaction,tag=DG.HardBtn,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction on target run function evercraft:dungeon/menu/select {difficulty:2,label:"Hard",color:"red"}
execute as @e[type=interaction,tag=DG.HardBtn,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction run data remove entity @s interaction

# Brutal button (difficulty 3)
execute as @e[type=interaction,tag=DG.BrutalBtn,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction on target run function evercraft:dungeon/menu/select {difficulty:3,label:"Brutal",color:"dark_red"}
execute as @e[type=interaction,tag=DG.BrutalBtn,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction run data remove entity @s interaction

# ===== INSPECT (left-click = what does this button do?) — gui/inspect pattern 2026-06-11 =====
execute as @e[type=interaction,tag=DG.CancelBtn,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Cancel",b:"Closes the dungeon menu."}
execute as @e[type=interaction,tag=DG.CancelBtn,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=DG.EasyBtn,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Easy",b:"Sets this run's difficulty to Easy and readies the dungeon."}
execute as @e[type=interaction,tag=DG.EasyBtn,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=DG.NormalBtn,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Normal",b:"Sets this run's difficulty to Normal and readies the dungeon."}
execute as @e[type=interaction,tag=DG.NormalBtn,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=DG.HardBtn,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Hard",b:"Sets this run's difficulty to Hard and readies the dungeon."}
execute as @e[type=interaction,tag=DG.HardBtn,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=DG.BrutalBtn,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Brutal",b:"Sets this run's difficulty to Brutal — the dungeon holds nothing back."}
execute as @e[type=interaction,tag=DG.BrutalBtn,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack run data remove entity @s attack
