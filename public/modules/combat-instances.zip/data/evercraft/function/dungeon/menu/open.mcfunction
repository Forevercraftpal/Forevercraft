# Dungeon Difficulty Selection — Open Menu
# Run as: player who consumed the dungeon key
# Shows 4 difficulty options + Auto (DR-based) + Cancel

# Toggle — if already in menu, close instead
execute if entity @s[tag=DG.InMenu] run return run function evercraft:dungeon/menu/close

# Menu Core: Y-displacement close anchor
# One-menu-at-a-time (2026-06-15): close any other open menu before this one claims
# ec.menu_active. Two overlapping menus share the @s adv.gui_session slot; the newer
# open orphans the older menu's session, so it can never consume its click -> stuck
# interaction NBT -> click-sound spam. force_close is idempotent (no-op when nothing open).
execute if entity @s[tag=ec.menu_active] run function evercraft:menu_core/force_close
tag @s add ec.menu_active
execute store result score @s ec.menu_open_y run data get entity @s Pos[1] 100
# Sneak-position polish (MP-P3.5): when crouching, lower spawn anchor by 0.20m so
# menu sits at a comfortable view-angle for the lowered eye height. Tag is read by
# every summon line below (paired unless/if) and removed at end-of-file.
tag @s remove ec.menu_sneak_open
execute if predicate evercraft:player_crouching run tag @s add ec.menu_sneak_open


# Safety: kill orphaned menu elements
execute at @s run kill @e[type=text_display,tag=DG.MenuEl,distance=..5]
execute at @s run kill @e[type=interaction,tag=DG.MenuEl,distance=..5]
execute at @s run kill @e[type=item_display,tag=DG.MenuEl,distance=..5]

# Tag player
tag @s add DG.InMenu
scoreboard players set @s dg.menu_time 0

# Get player's DR for recommended display
# AU-B-FOLLOWUP.12 RESOLUTION (2026-05-29): GLOBAL #dg_dr/#dg_recommend scratches are INTENTIONAL.
# Menu open runs as @s the player after sequential key-consume click; #dg_dr is computed for THIS
# @s and read immediately for #dg_recommend, then read by the recommended-star highlight lines
# below — all within one sequential @s exec block. Click handlers run sequentially per tick in
# Minecraft (never concurrent), so a second player opening their menu in the same tick fully
# completes Player A's menu/open before starting. No race. Per-pid migration adds cost without
# behavior benefit. Documented; closed as resolved.
execute store result score #dg_dr ec.var run attribute @s minecraft:luck get

# Calculate recommended difficulty
scoreboard players set #dg_recommend ec.var 0
execute if score #dg_dr ec.var matches 7..17 run scoreboard players set #dg_recommend ec.var 1
execute if score #dg_dr ec.var matches 18..29 run scoreboard players set #dg_recommend ec.var 2
execute if score #dg_dr ec.var matches 30.. run scoreboard players set #dg_recommend ec.var 3

# === BACKGROUND PANEL ===
execute unless entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^ ^1.4 ^1.8 run summon item_display ~ ~ ~ { Tags:["DG.MenuEl","DG.BG"], billboard:"center", item:{id:"black_stained_glass_pane",count:1}, item_display:"fixed", transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,-0.02f],scale:[2.6f,2.2f,0.01f]} }
execute if entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^ ^1.2 ^1.8 run summon item_display ~ ~ ~ { Tags:["DG.MenuEl","DG.BG"], billboard:"center", item:{id:"black_stained_glass_pane",count:1}, item_display:"fixed", transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,-0.02f],scale:[2.6f,2.2f,0.01f]} }

# === TITLE ===
# Ownership-header label (MP-P3.6): foreign viewers see whose menu this is
# 26.1: {selector:} renders blank in text_display — bake @s's name to a $(owner) literal.
function evercraft:util/gui/owner_name
execute rotated ~ 0 positioned ^ ^2.43 ^1.78 run function evercraft:dungeon/menu/open_nm with storage evercraft:scorebake args
execute unless entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^ ^2.25 ^1.78 run summon text_display ~ ~ ~ { brightness:{block:15,sky:15},shadow_radius:0f, Tags:["DG.MenuEl"], billboard:"center", text:[{text:"\u2694 ",color:"dark_purple"},{text:"Select Difficulty",color:"light_purple",bold:true},{text:" \u2694",color:"dark_purple"}], background:1,shadow:1b, transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.608f,0.608f,0.608f]} }
execute if entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^ ^2.05 ^1.78 run summon text_display ~ ~ ~ { brightness:{block:15,sky:15},shadow_radius:0f, Tags:["DG.MenuEl"], billboard:"center", text:[{text:"\u2694 ",color:"dark_purple"},{text:"Select Difficulty",color:"light_purple",bold:true},{text:" \u2694",color:"dark_purple"}], background:1,shadow:1b, transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.608f,0.608f,0.608f]} }

# === SUBTITLE (shows recommended) ===
execute unless entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^ ^2.02 ^1.78 run summon text_display ~ ~ ~ { brightness:{block:15,sky:15},shadow_radius:0f, Tags:["DG.MenuEl","DG.Subtitle"], billboard:"center", text:{text:"Based on your Dream Rate, choose your challenge.",color:"gray",italic:true}, background:0,shadow:1b, transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.338f,0.338f,0.338f]} }
execute if entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^ ^1.82 ^1.78 run summon text_display ~ ~ ~ { brightness:{block:15,sky:15},shadow_radius:0f, Tags:["DG.MenuEl","DG.Subtitle"], billboard:"center", text:{text:"Based on your Dream Rate, choose your challenge.",color:"gray",italic:true}, background:0,shadow:1b, transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.338f,0.338f,0.338f]} }

# === EASY BUTTON (Difficulty 0) ===
execute unless entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^ ^1.78 ^1.78 run summon text_display ~ ~ ~ { brightness:{block:15,sky:15},shadow_radius:0f, Tags:["DG.MenuEl","DG.EasyTxt"], billboard:"center", text:[{text:"[ ",color:"dark_gray"},{text:"Easy",color:"green",bold:true},{text:" ]",color:"dark_gray"},{text:" — Base stats",color:"dark_green"}], background:1,shadow:1b, transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.473f,0.473f,0.473f]} }
execute if entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^ ^1.58 ^1.78 run summon text_display ~ ~ ~ { brightness:{block:15,sky:15},shadow_radius:0f, Tags:["DG.MenuEl","DG.EasyTxt"], billboard:"center", text:[{text:"[ ",color:"dark_gray"},{text:"Easy",color:"green",bold:true},{text:" ]",color:"dark_gray"},{text:" — Base stats",color:"dark_green"}], background:1,shadow:1b, transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.473f,0.473f,0.473f]} }
# [strip] ?: 0.8w split into 4 x 0.2 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute unless entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^-0.3 ^1.65 ^1.8 run summon interaction ~ ~ ~ { Tags:["DG.MenuEl","DG.EasyBtn"], width:0.2f,height:0.26f,response:1b }
execute unless entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^-0.1 ^1.65 ^1.8 run summon interaction ~ ~ ~ { Tags:["DG.MenuEl","DG.EasyBtn"], width:0.2f,height:0.26f,response:1b }
execute unless entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^0.1 ^1.65 ^1.8 run summon interaction ~ ~ ~ { Tags:["DG.MenuEl","DG.EasyBtn"], width:0.2f,height:0.26f,response:1b }
execute unless entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^0.3 ^1.65 ^1.8 run summon interaction ~ ~ ~ { Tags:["DG.MenuEl","DG.EasyBtn"], width:0.2f,height:0.26f,response:1b }
# [strip] ?: 0.8w split into 4 x 0.2 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute if entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^-0.3 ^1.45 ^1.8 run summon interaction ~ ~ ~ { Tags:["DG.MenuEl","DG.EasyBtn"], width:0.2f,height:0.26f,response:1b }
execute if entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^-0.1 ^1.45 ^1.8 run summon interaction ~ ~ ~ { Tags:["DG.MenuEl","DG.EasyBtn"], width:0.2f,height:0.26f,response:1b }
execute if entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^0.1 ^1.45 ^1.8 run summon interaction ~ ~ ~ { Tags:["DG.MenuEl","DG.EasyBtn"], width:0.2f,height:0.26f,response:1b }
execute if entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^0.3 ^1.45 ^1.8 run summon interaction ~ ~ ~ { Tags:["DG.MenuEl","DG.EasyBtn"], width:0.2f,height:0.26f,response:1b }

# === NORMAL BUTTON (Difficulty 1) ===
execute unless entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^ ^1.52 ^1.78 run summon text_display ~ ~ ~ { brightness:{block:15,sky:15},shadow_radius:0f, Tags:["DG.MenuEl","DG.NormalTxt"], billboard:"center", text:[{text:"[ ",color:"dark_gray"},{text:"Normal",color:"yellow",bold:true},{text:" ]",color:"dark_gray"},{text:" — +25% HP, +15% Dmg",color:"gold"}], background:1,shadow:1b, transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.473f,0.473f,0.473f]} }
execute if entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^ ^1.32 ^1.78 run summon text_display ~ ~ ~ { brightness:{block:15,sky:15},shadow_radius:0f, Tags:["DG.MenuEl","DG.NormalTxt"], billboard:"center", text:[{text:"[ ",color:"dark_gray"},{text:"Normal",color:"yellow",bold:true},{text:" ]",color:"dark_gray"},{text:" — +25% HP, +15% Dmg",color:"gold"}], background:1,shadow:1b, transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.473f,0.473f,0.473f]} }
# [strip] ?: 0.8w split into 4 x 0.2 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute unless entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^-0.3 ^1.39 ^1.8 run summon interaction ~ ~ ~ { Tags:["DG.MenuEl","DG.NormalBtn"], width:0.2f,height:0.26f,response:1b }
execute unless entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^-0.1 ^1.39 ^1.8 run summon interaction ~ ~ ~ { Tags:["DG.MenuEl","DG.NormalBtn"], width:0.2f,height:0.26f,response:1b }
execute unless entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^0.1 ^1.39 ^1.8 run summon interaction ~ ~ ~ { Tags:["DG.MenuEl","DG.NormalBtn"], width:0.2f,height:0.26f,response:1b }
execute unless entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^0.3 ^1.39 ^1.8 run summon interaction ~ ~ ~ { Tags:["DG.MenuEl","DG.NormalBtn"], width:0.2f,height:0.26f,response:1b }
# [strip] ?: 0.8w split into 4 x 0.2 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute if entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^-0.3 ^1.19 ^1.8 run summon interaction ~ ~ ~ { Tags:["DG.MenuEl","DG.NormalBtn"], width:0.2f,height:0.26f,response:1b }
execute if entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^-0.1 ^1.19 ^1.8 run summon interaction ~ ~ ~ { Tags:["DG.MenuEl","DG.NormalBtn"], width:0.2f,height:0.26f,response:1b }
execute if entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^0.1 ^1.19 ^1.8 run summon interaction ~ ~ ~ { Tags:["DG.MenuEl","DG.NormalBtn"], width:0.2f,height:0.26f,response:1b }
execute if entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^0.3 ^1.19 ^1.8 run summon interaction ~ ~ ~ { Tags:["DG.MenuEl","DG.NormalBtn"], width:0.2f,height:0.26f,response:1b }

# === HARD BUTTON (Difficulty 2) ===
execute unless entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^ ^1.26 ^1.78 run summon text_display ~ ~ ~ { brightness:{block:15,sky:15},shadow_radius:0f, Tags:["DG.MenuEl","DG.HardTxt"], billboard:"center", text:[{text:"[ ",color:"dark_gray"},{text:"Hard",color:"red",bold:true},{text:" ]",color:"dark_gray"},{text:" — +50% HP, +30% Dmg",color:"dark_red"}], background:1,shadow:1b, transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.473f,0.473f,0.473f]} }
execute if entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^ ^1.06 ^1.78 run summon text_display ~ ~ ~ { brightness:{block:15,sky:15},shadow_radius:0f, Tags:["DG.MenuEl","DG.HardTxt"], billboard:"center", text:[{text:"[ ",color:"dark_gray"},{text:"Hard",color:"red",bold:true},{text:" ]",color:"dark_gray"},{text:" — +50% HP, +30% Dmg",color:"dark_red"}], background:1,shadow:1b, transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.473f,0.473f,0.473f]} }
# [strip] ?: 0.8w split into 4 x 0.2 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute unless entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^-0.3 ^1.13 ^1.8 run summon interaction ~ ~ ~ { Tags:["DG.MenuEl","DG.HardBtn"], width:0.2f,height:0.26f,response:1b }
execute unless entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^-0.1 ^1.13 ^1.8 run summon interaction ~ ~ ~ { Tags:["DG.MenuEl","DG.HardBtn"], width:0.2f,height:0.26f,response:1b }
execute unless entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^0.1 ^1.13 ^1.8 run summon interaction ~ ~ ~ { Tags:["DG.MenuEl","DG.HardBtn"], width:0.2f,height:0.26f,response:1b }
execute unless entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^0.3 ^1.13 ^1.8 run summon interaction ~ ~ ~ { Tags:["DG.MenuEl","DG.HardBtn"], width:0.2f,height:0.26f,response:1b }
# [strip] ?: 0.8w split into 4 x 0.2 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute if entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^-0.3 ^0.93 ^1.8 run summon interaction ~ ~ ~ { Tags:["DG.MenuEl","DG.HardBtn"], width:0.2f,height:0.26f,response:1b }
execute if entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^-0.1 ^0.93 ^1.8 run summon interaction ~ ~ ~ { Tags:["DG.MenuEl","DG.HardBtn"], width:0.2f,height:0.26f,response:1b }
execute if entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^0.1 ^0.93 ^1.8 run summon interaction ~ ~ ~ { Tags:["DG.MenuEl","DG.HardBtn"], width:0.2f,height:0.26f,response:1b }
execute if entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^0.3 ^0.93 ^1.8 run summon interaction ~ ~ ~ { Tags:["DG.MenuEl","DG.HardBtn"], width:0.2f,height:0.26f,response:1b }

# === BRUTAL BUTTON (Difficulty 3) ===
execute unless entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^ ^1 ^1.78 run summon text_display ~ ~ ~ { brightness:{block:15,sky:15},shadow_radius:0f, Tags:["DG.MenuEl","DG.BrutalTxt"], billboard:"center", text:[{text:"[ ",color:"dark_gray"},{text:"Brutal",color:"dark_red",bold:true},{text:" ]",color:"dark_gray"},{text:" — +100% HP, +50% Dmg",color:"dark_red"}], background:1,shadow:1b, transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.473f,0.473f,0.473f]} }
execute if entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^ ^0.8 ^1.78 run summon text_display ~ ~ ~ { brightness:{block:15,sky:15},shadow_radius:0f, Tags:["DG.MenuEl","DG.BrutalTxt"], billboard:"center", text:[{text:"[ ",color:"dark_gray"},{text:"Brutal",color:"dark_red",bold:true},{text:" ]",color:"dark_gray"},{text:" — +100% HP, +50% Dmg",color:"dark_red"}], background:1,shadow:1b, transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.473f,0.473f,0.473f]} }
# [strip] ?: 0.8w split into 4 x 0.2 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute unless entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^-0.3 ^0.87 ^1.8 run summon interaction ~ ~ ~ { Tags:["DG.MenuEl","DG.BrutalBtn"], width:0.2f,height:0.26f,response:1b }
execute unless entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^-0.1 ^0.87 ^1.8 run summon interaction ~ ~ ~ { Tags:["DG.MenuEl","DG.BrutalBtn"], width:0.2f,height:0.26f,response:1b }
execute unless entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^0.1 ^0.87 ^1.8 run summon interaction ~ ~ ~ { Tags:["DG.MenuEl","DG.BrutalBtn"], width:0.2f,height:0.26f,response:1b }
execute unless entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^0.3 ^0.87 ^1.8 run summon interaction ~ ~ ~ { Tags:["DG.MenuEl","DG.BrutalBtn"], width:0.2f,height:0.26f,response:1b }
# [strip] ?: 0.8w split into 4 x 0.2 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute if entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^-0.3 ^0.67 ^1.8 run summon interaction ~ ~ ~ { Tags:["DG.MenuEl","DG.BrutalBtn"], width:0.2f,height:0.26f,response:1b }
execute if entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^-0.1 ^0.67 ^1.8 run summon interaction ~ ~ ~ { Tags:["DG.MenuEl","DG.BrutalBtn"], width:0.2f,height:0.26f,response:1b }
execute if entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^0.1 ^0.67 ^1.8 run summon interaction ~ ~ ~ { Tags:["DG.MenuEl","DG.BrutalBtn"], width:0.2f,height:0.26f,response:1b }
execute if entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^0.3 ^0.67 ^1.8 run summon interaction ~ ~ ~ { Tags:["DG.MenuEl","DG.BrutalBtn"], width:0.2f,height:0.26f,response:1b }

# === CANCEL BUTTON ===
execute unless entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^ ^0.65 ^1.78 run summon text_display ~ ~ ~ { brightness:{block:15,sky:15},shadow_radius:0f, Tags:["DG.MenuEl","DG.CancelTxt"], billboard:"center", text:[{text:"[ ",color:"dark_gray"},{text:"Cancel",color:"gray",bold:true},{text:" ]",color:"dark_gray"}], background:1,shadow:1b, transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.405f,0.405f,0.405f]} }
execute if entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^ ^0.45 ^1.78 run summon text_display ~ ~ ~ { brightness:{block:15,sky:15},shadow_radius:0f, Tags:["DG.MenuEl","DG.CancelTxt"], billboard:"center", text:[{text:"[ ",color:"dark_gray"},{text:"Cancel",color:"gray",bold:true},{text:" ]",color:"dark_gray"}], background:1,shadow:1b, transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.405f,0.405f,0.405f]} }
# [strip] ?: 0.4w split into 4 x 0.12 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute unless entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^-0.14 ^0.55 ^1.8 run summon interaction ~ ~ ~ { Tags:["DG.MenuEl","DG.CancelBtn"], width:0.12f,height:0.12f,response:1b }
execute unless entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^-0.0467 ^0.55 ^1.8 run summon interaction ~ ~ ~ { Tags:["DG.MenuEl","DG.CancelBtn"], width:0.12f,height:0.12f,response:1b }
execute unless entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^0.0467 ^0.55 ^1.8 run summon interaction ~ ~ ~ { Tags:["DG.MenuEl","DG.CancelBtn"], width:0.12f,height:0.12f,response:1b }
execute unless entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^0.14 ^0.55 ^1.8 run summon interaction ~ ~ ~ { Tags:["DG.MenuEl","DG.CancelBtn"], width:0.12f,height:0.12f,response:1b }
# [strip] ?: 0.4w split into 4 x 0.12 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute if entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^-0.14 ^0.35 ^1.8 run summon interaction ~ ~ ~ { Tags:["DG.MenuEl","DG.CancelBtn"], width:0.12f,height:0.12f,response:1b }
execute if entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^-0.0467 ^0.35 ^1.8 run summon interaction ~ ~ ~ { Tags:["DG.MenuEl","DG.CancelBtn"], width:0.12f,height:0.12f,response:1b }
execute if entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^0.0467 ^0.35 ^1.8 run summon interaction ~ ~ ~ { Tags:["DG.MenuEl","DG.CancelBtn"], width:0.12f,height:0.12f,response:1b }
execute if entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^0.14 ^0.35 ^1.8 run summon interaction ~ ~ ~ { Tags:["DG.MenuEl","DG.CancelBtn"], width:0.12f,height:0.12f,response:1b }

# Mark the recommended difficulty with a star
execute if score #dg_recommend ec.var matches 0 run data modify entity @e[type=text_display,tag=DG.EasyTxt,limit=1] text set value [{text:"\u2605 ",color:"gold"},{text:"[ ",color:"dark_gray"},{text:"Easy",color:"green",bold:true},{text:" ]",color:"dark_gray"},{text:" — Base stats",color:"dark_green"},{text:" (Recommended)",color:"gold",italic:true}]
execute if score #dg_recommend ec.var matches 1 run data modify entity @e[type=text_display,tag=DG.NormalTxt,limit=1] text set value [{text:"\u2605 ",color:"gold"},{text:"[ ",color:"dark_gray"},{text:"Normal",color:"yellow",bold:true},{text:" ]",color:"dark_gray"},{text:" — +25% HP, +15% Dmg",color:"gold"},{text:" (Recommended)",color:"gold",italic:true}]
execute if score #dg_recommend ec.var matches 2 run data modify entity @e[type=text_display,tag=DG.HardTxt,limit=1] text set value [{text:"\u2605 ",color:"gold"},{text:"[ ",color:"dark_gray"},{text:"Hard",color:"red",bold:true},{text:" ]",color:"dark_gray"},{text:" — +50% HP, +30% Dmg",color:"dark_red"},{text:" (Recommended)",color:"gold",italic:true}]
execute if score #dg_recommend ec.var matches 3 run data modify entity @e[type=text_display,tag=DG.BrutalTxt,limit=1] text set value [{text:"\u2605 ",color:"gold"},{text:"[ ",color:"dark_gray"},{text:"Brutal",color:"dark_red",bold:true},{text:" ]",color:"dark_gray"},{text:" — +100% HP, +50% Dmg",color:"dark_red"},{text:" (Recommended)",color:"gold",italic:true}]

# Sound

# Session isolation
scoreboard players add #gui_session ec.var 1
scoreboard players operation @s adv.gui_session = #gui_session ec.var
scoreboard players operation #gui_stamp ec.temp = @s adv.gui_session
execute as @e[type=text_display,tag=DG.MenuEl,distance=..5] unless score @s adv.gui_session matches 1.. run scoreboard players operation @s adv.gui_session = #gui_stamp ec.temp
execute as @e[type=item_display,tag=DG.MenuEl,distance=..5] unless score @s adv.gui_session matches 1.. run scoreboard players operation @s adv.gui_session = #gui_stamp ec.temp
execute as @e[type=interaction,tag=DG.MenuEl,distance=..5] unless score @s adv.gui_session matches 1.. run scoreboard players operation @s adv.gui_session = #gui_stamp ec.temp

execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.4 1.2

# Sneak-position polish cleanup
tag @s remove ec.menu_sneak_open
