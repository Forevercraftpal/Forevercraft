# Dungeon Difficulty Menu — Close (Cancel)
# Run as: player with DG.InMenu OR interaction entity

# Return the dungeon key to the player
# Menu Core: Y-displacement close anchor
tag @s remove ec.menu_active
scoreboard players reset @s ec.menu_open_y

execute as @a[tag=DG.InMenu,distance=..5,limit=1] store result score #inv_full ec.var run function evercraft:util/check_inv_full
execute as @a[tag=DG.InMenu,distance=..5,limit=1] if score #inv_full ec.var matches 0 run loot give @s loot evercraft:dungeon/key
execute as @a[tag=DG.InMenu,distance=..5,limit=1] at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:dungeon/key
data modify storage evercraft:notify stage.c set value [{text:"Cancelled. Key returned.",color:"gray"}]
scoreboard players set #ndur ec.temp 45
execute as @a[tag=DG.InMenu,distance=..5,limit=1] run function evercraft:util/notify/emit

# Remove tag
tag @s remove DG.InMenu
execute as @a[tag=DG.InMenu,distance=..5,limit=1] run tag @s remove DG.InMenu

# Kill menu elements
scoreboard players operation #gui_check ec.temp = @s adv.gui_session
execute as @e[type=text_display,tag=DG.MenuEl,distance=..5] if score @s adv.gui_session = #gui_check ec.temp run kill @s
execute as @e[type=interaction,tag=DG.MenuEl,distance=..5] if score @s adv.gui_session = #gui_check ec.temp run kill @s
execute as @e[type=item_display,tag=DG.MenuEl,distance=..5] if score @s adv.gui_session = #gui_check ec.temp run kill @s

# Sound
execute as @a[distance=..5,limit=1,scores={ec.fx_snd=1..}] run playsound minecraft:block.amethyst_block.break master @s ~ ~ ~ 0.3 0.8
