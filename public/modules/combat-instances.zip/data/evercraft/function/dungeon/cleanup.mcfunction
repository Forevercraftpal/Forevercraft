# Wiring Audit B (2026-05-29) W6: Dungeon Instance — Cleanup (per-party MACRO).
# Called with storage evercraft:_shared cart for $(pid) from:
#   - tick_active (via fail/complete/floor/finish_run)
#   - spirit_raid/check_prompt (via dungeon_cleanup_outer when no descend)
#   - raids/check_entry + raids/vote/process_vote (via dungeon_cleanup_outer when raid declined)
# R6 ordering: pt.dg_active cleared BEFORE dg.player/p<pid> tag removal (parallel-write LAW).
# Aggregate gate (I3 idempotence): #dg_any_active 1→0 only if no other party still active.

# Kill this party's dungeon mobs only
$kill @e[tag=dg.mob,tag=p$(pid)]

# Kill this party's center marker only
$kill @e[type=marker,tag=dg.center,tag=p$(pid)]

# C1-ender-swap: if this party's node is currently swapped-in (a real ender_chest placed), remove that
# block at its EXACT stored coords + the ec.dgec_real owner marker FIRST (grief-guarded, never a block
# scan), so a consumed / abandoned node never leaks a real block. No-op when the node was never swapped.
function evercraft:dungeon/ender_node/cleanup_real with storage evercraft:_shared cart

# Kill this party's dungeon ender-node entities (PLAN-chest-nodes §8). All three (data marker, visual
# item_display, interaction) carry p$(pid), so the per-party sweep removes only THIS party's node. The
# ec.dgec_real owner marker (if any) was already killed by cleanup_real above (it carries no p<pid>).
$kill @e[tag=ec.dgec,tag=p$(pid)]
# Clear this party's per-player ender-node looted flags (a fresh run = fresh pulls). dgec.<floor>.looted.
$tag @a[tag=dg.player,tag=p$(pid)] remove dgec.3.looted
$tag @a[tag=dg.player,tag=p$(pid)] remove dgec.5.looted
$tag @a[tag=dg.player,tag=p$(pid)] remove dgec.7.looted
$tag @a[tag=dg.player,tag=p$(pid)] remove dgec.9.looted
$tag @a[tag=dg.player,tag=p$(pid)] remove dgec.10.looted

# Clear party dungeon affixes for this party (before removing dg.player tag)
function evercraft:dungeon/affix/clear with storage evercraft:_shared cart

# Clear dungeon HUD actionbar — scoped to this party's participants only
# (Wave 2, 2026-06-10: bar-clear stays RAW — clearing leftover HUD paint; gated so it never blanks a queue frame.)
$execute as @a[tag=dg.player,tag=p$(pid)] unless entity @s[tag=ab_q] run title @s actionbar {text:""}

# R6: clear per-player active flag BEFORE tag removal (per audit B W6 + Audit #15 W2.2 precedent)
$scoreboard players set @a[tag=dg.player,tag=p$(pid)] pt.dg_active 0

# Remove participant tags for this party
$tag @a[tag=dg.player,tag=p$(pid)] remove dg.player
$tag @a[tag=p$(pid)] remove p$(pid)

# Reset per-party state
$scoreboard players set #dg_wave.$(pid) ec.var 0
$scoreboard players set #dg_timer.$(pid) ec.var 0
$scoreboard players set #dg_type.$(pid) ec.var 0
$scoreboard players set #dg_instance.$(pid) ec.var 0
$scoreboard players set #dg_difficulty.$(pid) ec.var 0
$scoreboard players set #dg_modifier.$(pid) ec.var 0
$scoreboard players set #dg_floor.$(pid) ec.var 0
$scoreboard players set #dg_descent_timer.$(pid) ec.var 0
$scoreboard players set #dg_players.$(pid) ec.var 0
$scoreboard players set #dg_struct_id.$(pid) ec.var 0
$scoreboard players set #dg_is_daily.$(pid) ec.var 0
$scoreboard players set #dg_omen.$(pid) ec.var 0
$scoreboard players set #dg_dr.$(pid) ec.var 0
$scoreboard players set #dg_mobs.$(pid) ec.var 0
$scoreboard players set #dg_center_x.$(pid) ec.var 0
$scoreboard players set #dg_center_z.$(pid) ec.var 0

# Clear descent state for this party's participants
$tag @a[tag=p$(pid)] remove dg.awaiting_descent
$scoreboard players set @a[tag=p$(pid)] ec.dg_descend 0

# Clear spirit raid prompt state for this party's participants
$tag @a[tag=p$(pid)] remove sr.prompted
$scoreboard players set @a[tag=p$(pid)] ec.sr_prompt 0
$scoreboard players set @a[tag=p$(pid)] ec.sr_timer 0

# Aggregate I3: clear #dg_any_active only if no other party still has a participant active
execute unless entity @a[scores={pt.dg_active=1}] run scoreboard players set #dg_any_active ec.var 0
