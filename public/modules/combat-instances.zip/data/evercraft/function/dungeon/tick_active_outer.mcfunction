# Wiring Audit B (2026-05-29) W6: Dungeon Instance — Per-Party Tick Dispatcher.
# Called from tick:292 as the party leader (ec.party_role=1) OR solo (ec.party_id=0).
# Derives pid (dual-key) and dispatches the macro inner with storage cart.
function evercraft:_shared/derive_pid_from_party
function evercraft:dungeon/tick_active with storage evercraft:_shared cart
