# Wiring Audit B (2026-05-29) W6: Dungeon Instance — Active Tick (per-party MACRO).
# Called via dungeon/tick_active_outer with storage evercraft:_shared cart for $(pid).
# @s is the party leader (or solo) whose dungeon is being ticked.

# === SPIRIT RAID PROMPT PHASE (post-completion, waiting for player choice) ===
$execute if entity @a[tag=sr.prompted,tag=p$(pid)] run function evercraft:spirit_raid/check_prompt with storage evercraft:_shared cart
$execute if entity @a[tag=sr.prompted,tag=p$(pid)] run return 0

# === DESCENT DECISION PHASE (waiting for player input between floors) ===
$execute if score #dg_descent_timer.$(pid) ec.var matches 1.. run function evercraft:dungeon/floor/check_descent with storage evercraft:_shared cart
$execute if score #dg_descent_timer.$(pid) ec.var matches 1.. run return 0

# === DEATH DETECTION (instant) — handled via tick.mcfunction Shape D-1 intercept ===
# If fail_death just ran (any party member died), @s pt.dg_active was cleared.
execute unless score @s pt.dg_active matches 1 run return 0

# === PLAYER DISCONNECTED CHECK ===
$execute unless entity @a[tag=dg.player,tag=p$(pid)] run function evercraft:dungeon/fail_disconnect with storage evercraft:_shared cart
execute unless score @s pt.dg_active matches 1 run return 0

# === COUNTDOWN PHASE (wave 0) ===
$execute if score #dg_wave.$(pid) ec.var matches 0 run scoreboard players remove #dg_timer.$(pid) ec.var 1

# Countdown titles at specific moments (dungeon/countdown_title macro — no per-party state, safe)
$execute if score #dg_wave.$(pid) ec.var matches 0 if score #dg_timer.$(pid) ec.var matches 40 as @a[tag=dg.player,tag=p$(pid)] at @s run function evercraft:dungeon/countdown_title {num:"3",color:"red",pitch:0.5}
$execute if score #dg_wave.$(pid) ec.var matches 0 if score #dg_timer.$(pid) ec.var matches 20 as @a[tag=dg.player,tag=p$(pid)] at @s run function evercraft:dungeon/countdown_title {num:"2",color:"gold",pitch:0.7}
$execute if score #dg_wave.$(pid) ec.var matches 0 if score #dg_timer.$(pid) ec.var matches 1 as @a[tag=dg.player,tag=p$(pid)] at @s run function evercraft:dungeon/countdown_title {num:"1",color:"green",pitch:1.0}

# Countdown finished — start wave 1
$execute if score #dg_wave.$(pid) ec.var matches 0 if score #dg_timer.$(pid) ec.var matches ..0 run scoreboard players set #dg_wave.$(pid) ec.var 1
$execute if score #dg_wave.$(pid) ec.var matches 1 if score #dg_timer.$(pid) ec.var matches ..0 run scoreboard players set #dg_timer.$(pid) ec.var 6000
# Spawn first wave (gated on wave==1 + timer==6000)
$execute if score #dg_wave.$(pid) ec.var matches 1 if score #dg_timer.$(pid) ec.var matches 6000 if score #dg_type.$(pid) ec.var matches 1 at @e[type=marker,tag=dg.center,tag=p$(pid),limit=1] run function evercraft:dungeon/spawn_wave with storage evercraft:_shared cart
$execute if score #dg_wave.$(pid) ec.var matches 1 if score #dg_timer.$(pid) ec.var matches 6000 if score #dg_type.$(pid) ec.var matches 2 at @e[type=marker,tag=dg.center,tag=p$(pid),limit=1] run function evercraft:dungeon/village/spawn_wave with storage evercraft:_shared cart
# Party Affix: Timer — override to 3600 ticks (3 minutes) after spawn
$execute if score #dg_wave.$(pid) ec.var matches 1 if score #dg_timer.$(pid) ec.var matches 6000 if score #dg_afx_timer.$(pid) ec.var matches 1 run scoreboard players set #dg_timer.$(pid) ec.var 3600

# === COMBAT PHASE (waves 1-5) ===
$execute unless score #dg_wave.$(pid) ec.var matches 1..5 run return 0

# Decrement timer
$scoreboard players remove #dg_timer.$(pid) ec.var 1

# Timer expired — fail
$execute if score #dg_timer.$(pid) ec.var matches ..0 run function evercraft:dungeon/fail with storage evercraft:_shared cart
execute unless score @s pt.dg_active matches 1 run return 0

# Boundary check (once per second — when timer is divisible by 20)
$scoreboard players operation #dg_boundary_check.$(pid) ec.var = #dg_timer.$(pid) ec.var
$scoreboard players operation #dg_boundary_check.$(pid) ec.var %= #20 ec.const
$execute if score #dg_boundary_check.$(pid) ec.var matches 0 run function evercraft:dungeon/check_boundary with storage evercraft:_shared cart

# Shrouded modifier: apply Darkness to participants every 5s (timer % 100 == 0)
$scoreboard players operation #dg_mod_check.$(pid) ec.var = #dg_timer.$(pid) ec.var
$scoreboard players operation #dg_mod_check.$(pid) ec.var %= #100 ec.const
$execute if score #dg_modifier.$(pid) ec.var matches 3 if score #dg_mod_check.$(pid) ec.var matches 0 run effect give @a[tag=dg.player,tag=p$(pid)] darkness 8 0 false

# Party Dungeon Affixes: tick affix effects every 5s
$execute if score #dg_afx_count.$(pid) ec.var matches 1.. if score #dg_mod_check.$(pid) ec.var matches 0 run function evercraft:dungeon/affix/tick with storage evercraft:_shared cart

# Count alive dungeon mobs (per-party)
$execute store result score #dg_mobs.$(pid) ec.var if entity @e[tag=dg.mob,tag=p$(pid)]

# AU-B-FOLLOWUP.1 (2026-05-29): per-party HUD stagger. (throttle + pid) % 2 == 0 splits parties
# across the 2 ticks of the 10Hz throttle window — even-pid parties fire on throttle=0 ticks,
# odd-pid parties fire on throttle=1 ticks. Half the HUD load per tick across all active parties.
$scoreboard players operation #dg_hud_stagger.$(pid) ec.var = #dg_hud_throttle ec.var
$scoreboard players add #dg_hud_stagger.$(pid) ec.var $(pid)
$scoreboard players operation #dg_hud_stagger.$(pid) ec.var %= #2 ec.const

# Mobs still alive — show HUD (10Hz throttle + per-party stagger) and return
$execute unless score #dg_mobs.$(pid) ec.var matches 0 if score #dg_hud_stagger.$(pid) ec.var matches 0 run function evercraft:dungeon/hud with storage evercraft:_shared cart
$execute unless score #dg_mobs.$(pid) ec.var matches 0 run return 0

# === WAVE CLEARED (all mobs dead) ===

# Wave 5 cleared → offer descent (floor < 10) or complete (floor 10 or village)
$execute if score #dg_wave.$(pid) ec.var matches 5 if score #dg_type.$(pid) ec.var matches 1 if score #dg_floor.$(pid) ec.var matches ..9 run function evercraft:dungeon/floor/offer_descent with storage evercraft:_shared cart
$execute if score #dg_wave.$(pid) ec.var matches 5 if score #dg_type.$(pid) ec.var matches 1 if score #dg_floor.$(pid) ec.var matches ..9 run return 0
# Floor 10 or village → normal complete
$execute if score #dg_wave.$(pid) ec.var matches 5 if score #dg_type.$(pid) ec.var matches 1 run function evercraft:dungeon/complete with storage evercraft:_shared cart
$execute if score #dg_wave.$(pid) ec.var matches 5 if score #dg_type.$(pid) ec.var matches 2 run function evercraft:dungeon/village/complete with storage evercraft:_shared cart
$execute if score #dg_wave.$(pid) ec.var matches 5 run return 0

# Advance to next wave (waves 1-4 → 2-5)
$scoreboard players add #dg_wave.$(pid) ec.var 1

# Spawn the new wave — route based on dungeon type
$execute if score #dg_type.$(pid) ec.var matches 1 at @e[type=marker,tag=dg.center,tag=p$(pid),limit=1] run function evercraft:dungeon/spawn_wave with storage evercraft:_shared cart
$execute if score #dg_type.$(pid) ec.var matches 2 at @e[type=marker,tag=dg.center,tag=p$(pid),limit=1] run function evercraft:dungeon/village/spawn_wave with storage evercraft:_shared cart

# Show HUD after new wave spawn (10Hz throttle + per-party stagger from above)
$execute if score #dg_hud_stagger.$(pid) ec.var matches 0 run function evercraft:dungeon/hud with storage evercraft:_shared cart
