# Wiring Audit B (2026-05-29) W6: Dungeon Modifier Announcement (per-party MACRO).
# Called with storage cart for $(pid), $(mod_name), $(mod_desc), $(mod_color).
$data modify storage evercraft:notify stage.c set value [{text:"Modifier: ",color:"gray"},{text:"$(mod_name)",color:"$(mod_color)",bold:true},{text:" — $(mod_desc)",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 50
$execute as @a[tag=dg.player,tag=p$(pid)] run function evercraft:util/notify/emit
$playsound minecraft:block.note_block.chime master @a[tag=dg.player,tag=p$(pid),scores={ec.fx_snd=1..}] ~ ~ ~ 0.8 0.6
