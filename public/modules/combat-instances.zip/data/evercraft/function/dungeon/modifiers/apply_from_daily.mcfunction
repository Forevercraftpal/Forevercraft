# Wiring Audit B (2026-05-29) W6: Dungeon Modifiers — Apply daily challenge modifier (per-party MACRO).
# Called with storage cart for $(pid) from begin_inner when daily-challenge applies.
# Reads #dc_modifier (daily challenge global, set at dawn) and writes #dg_modifier.<pid>.

$scoreboard players operation #dg_modifier.$(pid) ec.var = #dc_modifier ec.var

# Stage modifier name + description into cart for announce macro
$execute if score #dg_modifier.$(pid) ec.var matches 1 run data modify storage evercraft:_shared cart.mod_name set value "Relentless"
$execute if score #dg_modifier.$(pid) ec.var matches 1 run data modify storage evercraft:_shared cart.mod_desc set value "Mobs are faster"
$execute if score #dg_modifier.$(pid) ec.var matches 1 run data modify storage evercraft:_shared cart.mod_color set value "aqua"
$execute if score #dg_modifier.$(pid) ec.var matches 2 run data modify storage evercraft:_shared cart.mod_name set value "Fortified"
$execute if score #dg_modifier.$(pid) ec.var matches 2 run data modify storage evercraft:_shared cart.mod_desc set value "Mobs take less damage"
$execute if score #dg_modifier.$(pid) ec.var matches 2 run data modify storage evercraft:_shared cart.mod_color set value "blue"
$execute if score #dg_modifier.$(pid) ec.var matches 3 run data modify storage evercraft:_shared cart.mod_name set value "Shrouded"
$execute if score #dg_modifier.$(pid) ec.var matches 3 run data modify storage evercraft:_shared cart.mod_desc set value "Darkness clouds your vision"
$execute if score #dg_modifier.$(pid) ec.var matches 3 run data modify storage evercraft:_shared cart.mod_color set value "dark_gray"
$execute if score #dg_modifier.$(pid) ec.var matches 4 run data modify storage evercraft:_shared cart.mod_name set value "Volatile"
$execute if score #dg_modifier.$(pid) ec.var matches 4 run data modify storage evercraft:_shared cart.mod_desc set value "Mobs are immovable"
$execute if score #dg_modifier.$(pid) ec.var matches 4 run data modify storage evercraft:_shared cart.mod_color set value "red"
$execute if score #dg_modifier.$(pid) ec.var matches 5 run data modify storage evercraft:_shared cart.mod_name set value "Undying"
$execute if score #dg_modifier.$(pid) ec.var matches 5 run data modify storage evercraft:_shared cart.mod_desc set value "Mobs slowly regenerate"
$execute if score #dg_modifier.$(pid) ec.var matches 5 run data modify storage evercraft:_shared cart.mod_color set value "green"
$execute if score #dg_modifier.$(pid) ec.var matches 6 run data modify storage evercraft:_shared cart.mod_name set value "Frenzied"
$execute if score #dg_modifier.$(pid) ec.var matches 6 run data modify storage evercraft:_shared cart.mod_desc set value "Mobs deal more damage"
$execute if score #dg_modifier.$(pid) ec.var matches 6 run data modify storage evercraft:_shared cart.mod_color set value "dark_red"

# Announce modifier (per-party)
function evercraft:dungeon/modifiers/announce with storage evercraft:_shared cart
