# Dungeon Lockout — Display remaining time with structure name (macro)
$data modify storage evercraft:notify stage.c set value [{text:"Cooldown: ",color:"gray"},{text:"$(days) day(s), $(hours) hour(s)",color:"yellow"},{text:" remaining for ",color:"gray"},{text:"$(struct_name)",color:"light_purple",bold:true},{text:".",color:"gray"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
