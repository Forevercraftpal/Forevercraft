# Dungeon — Party Bonus Mobs
# Spawns extra mobs for each additional player beyond 1
# Run at: dg.center marker position (inherited from spawn_wave context)
# Bonus mobs get dg.mob tag → go through apply_scaling like everything else
# Wiring Audit #15 W2.1: #dg_type gating added — structure-themed bonus (zombies/skeletons/witch/vindicator)
# fires only on #dg_type=1 (structure dungeons). Village-themed bonus (pillager/vindicator/evoker/ravager/witch)
# fires only on #dg_type=2 (Village Defense). Pre-fix, undead mobs spawned during village raids (thematic mismatch).

# ========================================
# STRUCTURE DUNGEONS (#dg_type=1) — undead/skeleton/witch bonus theme
# ========================================

# === 2+ PLAYERS: First bonus batch ===

# W1: +1 zombie
execute if score #dg_type ec.var matches 1 if score #dg_players ec.var matches 2.. if score #dg_wave ec.var matches 1 run summon zombie ~3 ~1 ~3 {Tags:["dg.mob","ec.entity"],PersistenceRequired:1b,DeathLootTable:"minecraft:empty",CanPickUpLoot:0b}

# W2: +1 zombie, +1 skeleton
execute if score #dg_type ec.var matches 1 if score #dg_players ec.var matches 2.. if score #dg_wave ec.var matches 2 run summon zombie ~3 ~1 ~3 {Tags:["dg.mob","ec.entity"],PersistenceRequired:1b,DeathLootTable:"minecraft:empty",CanPickUpLoot:0b}
execute if score #dg_type ec.var matches 1 if score #dg_players ec.var matches 2.. if score #dg_wave ec.var matches 2 run summon skeleton ~-3 ~1 ~-3 {Tags:["dg.mob","ec.entity"],PersistenceRequired:1b,DeathLootTable:"minecraft:empty",CanPickUpLoot:0b}

# W3: +1 armored zombie, +1 skeleton
execute if score #dg_type ec.var matches 1 if score #dg_players ec.var matches 2.. if score #dg_wave ec.var matches 3 run summon zombie ~3 ~1 ~3 {Tags:["dg.mob","ec.entity"],PersistenceRequired:1b,DeathLootTable:"minecraft:empty",CanPickUpLoot:0b,equipment:{chest:{id:"minecraft:iron_chestplate"},head:{id:"minecraft:iron_helmet"}}}
execute if score #dg_type ec.var matches 1 if score #dg_players ec.var matches 2.. if score #dg_wave ec.var matches 3 run summon skeleton ~-3 ~1 ~-3 {Tags:["dg.mob","ec.entity"],PersistenceRequired:1b,DeathLootTable:"minecraft:empty",CanPickUpLoot:0b}

# W4: +1 armored zombie, +1 armored skeleton, +1 witch
execute if score #dg_type ec.var matches 1 if score #dg_players ec.var matches 2.. if score #dg_wave ec.var matches 4 run summon zombie ~3 ~1 ~3 {Tags:["dg.mob","ec.entity"],PersistenceRequired:1b,DeathLootTable:"minecraft:empty",CanPickUpLoot:0b,equipment:{chest:{id:"minecraft:diamond_chestplate"},head:{id:"minecraft:iron_helmet"}}}
execute if score #dg_type ec.var matches 1 if score #dg_players ec.var matches 2.. if score #dg_wave ec.var matches 4 run summon skeleton ~-3 ~1 ~-3 {Tags:["dg.mob","ec.entity"],PersistenceRequired:1b,DeathLootTable:"minecraft:empty",CanPickUpLoot:0b,equipment:{head:{id:"minecraft:iron_helmet"}}}
execute if score #dg_type ec.var matches 1 if score #dg_players ec.var matches 2.. if score #dg_wave ec.var matches 4 run summon witch ~0 ~1 ~-5 {Tags:["dg.mob","ec.entity"],PersistenceRequired:1b,DeathLootTable:"minecraft:empty"}

# W5: +1 armored vindicator (elite guard)
execute if score #dg_type ec.var matches 1 if score #dg_players ec.var matches 2.. if score #dg_wave ec.var matches 5 run summon vindicator ~3 ~1 ~3 {Tags:["dg.mob","ec.entity"],PersistenceRequired:1b,DeathLootTable:"minecraft:empty",CanPickUpLoot:0b,equipment:{chest:{id:"minecraft:iron_chestplate"}},attributes:[{id:"max_health",base:40.0d}]}

# === 3+ PLAYERS: Second bonus batch (different positions) ===

execute if score #dg_type ec.var matches 1 if score #dg_players ec.var matches 3.. if score #dg_wave ec.var matches 1 run summon skeleton ~-3 ~1 ~-3 {Tags:["dg.mob","ec.entity"],PersistenceRequired:1b,DeathLootTable:"minecraft:empty",CanPickUpLoot:0b}

execute if score #dg_type ec.var matches 1 if score #dg_players ec.var matches 3.. if score #dg_wave ec.var matches 2 run summon zombie ~-3 ~1 ~3 {Tags:["dg.mob","ec.entity"],PersistenceRequired:1b,DeathLootTable:"minecraft:empty",CanPickUpLoot:0b}
execute if score #dg_type ec.var matches 1 if score #dg_players ec.var matches 3.. if score #dg_wave ec.var matches 2 run summon skeleton ~3 ~1 ~-3 {Tags:["dg.mob","ec.entity"],PersistenceRequired:1b,DeathLootTable:"minecraft:empty",CanPickUpLoot:0b}

execute if score #dg_type ec.var matches 1 if score #dg_players ec.var matches 3.. if score #dg_wave ec.var matches 3 run summon zombie ~-3 ~1 ~3 {Tags:["dg.mob","ec.entity"],PersistenceRequired:1b,DeathLootTable:"minecraft:empty",CanPickUpLoot:0b,equipment:{chest:{id:"minecraft:iron_chestplate"},head:{id:"minecraft:iron_helmet"}}}
execute if score #dg_type ec.var matches 1 if score #dg_players ec.var matches 3.. if score #dg_wave ec.var matches 3 run summon skeleton ~3 ~1 ~-3 {Tags:["dg.mob","ec.entity"],PersistenceRequired:1b,DeathLootTable:"minecraft:empty",CanPickUpLoot:0b}

execute if score #dg_type ec.var matches 1 if score #dg_players ec.var matches 3.. if score #dg_wave ec.var matches 4 run summon zombie ~-3 ~1 ~3 {Tags:["dg.mob","ec.entity"],PersistenceRequired:1b,DeathLootTable:"minecraft:empty",CanPickUpLoot:0b,equipment:{chest:{id:"minecraft:diamond_chestplate"},head:{id:"minecraft:iron_helmet"}}}
execute if score #dg_type ec.var matches 1 if score #dg_players ec.var matches 3.. if score #dg_wave ec.var matches 4 run summon skeleton ~3 ~1 ~-3 {Tags:["dg.mob","ec.entity"],PersistenceRequired:1b,DeathLootTable:"minecraft:empty",CanPickUpLoot:0b,equipment:{head:{id:"minecraft:iron_helmet"}}}
execute if score #dg_type ec.var matches 1 if score #dg_players ec.var matches 3.. if score #dg_wave ec.var matches 4 run summon witch ~0 ~1 ~5 {Tags:["dg.mob","ec.entity"],PersistenceRequired:1b,DeathLootTable:"minecraft:empty"}

execute if score #dg_type ec.var matches 1 if score #dg_players ec.var matches 3.. if score #dg_wave ec.var matches 5 run summon vindicator ~-3 ~1 ~-3 {Tags:["dg.mob","ec.entity"],PersistenceRequired:1b,DeathLootTable:"minecraft:empty",CanPickUpLoot:0b,equipment:{chest:{id:"minecraft:iron_chestplate"}},attributes:[{id:"max_health",base:40.0d}]}

# === 4+ PLAYERS: Third bonus batch ===

execute if score #dg_type ec.var matches 1 if score #dg_players ec.var matches 4.. if score #dg_wave ec.var matches 1 run summon zombie ~-3 ~1 ~3 {Tags:["dg.mob","ec.entity"],PersistenceRequired:1b,DeathLootTable:"minecraft:empty",CanPickUpLoot:0b}

execute if score #dg_type ec.var matches 1 if score #dg_players ec.var matches 4.. if score #dg_wave ec.var matches 2 run summon zombie ~0 ~1 ~4 {Tags:["dg.mob","ec.entity"],PersistenceRequired:1b,DeathLootTable:"minecraft:empty",CanPickUpLoot:0b}
execute if score #dg_type ec.var matches 1 if score #dg_players ec.var matches 4.. if score #dg_wave ec.var matches 2 run summon skeleton ~0 ~1 ~-4 {Tags:["dg.mob","ec.entity"],PersistenceRequired:1b,DeathLootTable:"minecraft:empty",CanPickUpLoot:0b}

execute if score #dg_type ec.var matches 1 if score #dg_players ec.var matches 4.. if score #dg_wave ec.var matches 3 run summon zombie ~0 ~1 ~4 {Tags:["dg.mob","ec.entity"],PersistenceRequired:1b,DeathLootTable:"minecraft:empty",CanPickUpLoot:0b,equipment:{chest:{id:"minecraft:iron_chestplate"},head:{id:"minecraft:iron_helmet"}}}
execute if score #dg_type ec.var matches 1 if score #dg_players ec.var matches 4.. if score #dg_wave ec.var matches 3 run summon skeleton ~0 ~1 ~-4 {Tags:["dg.mob","ec.entity"],PersistenceRequired:1b,DeathLootTable:"minecraft:empty",CanPickUpLoot:0b}

execute if score #dg_type ec.var matches 1 if score #dg_players ec.var matches 4.. if score #dg_wave ec.var matches 4 run summon zombie ~0 ~1 ~4 {Tags:["dg.mob","ec.entity"],PersistenceRequired:1b,DeathLootTable:"minecraft:empty",CanPickUpLoot:0b,equipment:{chest:{id:"minecraft:diamond_chestplate"},head:{id:"minecraft:diamond_helmet"}}}
execute if score #dg_type ec.var matches 1 if score #dg_players ec.var matches 4.. if score #dg_wave ec.var matches 4 run summon skeleton ~0 ~1 ~-4 {Tags:["dg.mob","ec.entity"],PersistenceRequired:1b,DeathLootTable:"minecraft:empty",CanPickUpLoot:0b,equipment:{head:{id:"minecraft:iron_helmet"}}}
execute if score #dg_type ec.var matches 1 if score #dg_players ec.var matches 4.. if score #dg_wave ec.var matches 4 run summon vindicator ~5 ~1 ~0 {Tags:["dg.mob","ec.entity"],PersistenceRequired:1b,DeathLootTable:"minecraft:empty",CanPickUpLoot:0b}

execute if score #dg_type ec.var matches 1 if score #dg_players ec.var matches 4.. if score #dg_wave ec.var matches 5 run summon vindicator ~0 ~1 ~4 {Tags:["dg.mob","ec.entity"],PersistenceRequired:1b,DeathLootTable:"minecraft:empty",CanPickUpLoot:0b,equipment:{chest:{id:"minecraft:diamond_chestplate"}},attributes:[{id:"max_health",base:40.0d}]}

# ========================================
# VILLAGE DEFENSE (#dg_type=2) — illager theme (pillager/vindicator/evoker/ravager/witch)
# Wiring Audit #15 W2.1: mirrors village/spawn_wave illager mob roster.
# ========================================

# === 2+ PLAYERS: First village bonus batch ===

# W1: +1 pillager
execute if score #dg_type ec.var matches 2 if score #dg_players ec.var matches 2.. if score #dg_wave ec.var matches 1 run summon pillager ~3 ~1 ~3 {Tags:["dg.mob","ec.entity"],PersistenceRequired:1b,CanPickUpLoot:0b,drop_chances:{mainhand:0f,offhand:0f,head:0f,chest:0f,legs:0f,feet:0f},DeathLootTable:"minecraft:empty"}

# W2: +1 pillager
execute if score #dg_type ec.var matches 2 if score #dg_players ec.var matches 2.. if score #dg_wave ec.var matches 2 run summon pillager ~3 ~1 ~3 {Tags:["dg.mob","ec.entity"],PersistenceRequired:1b,CanPickUpLoot:0b,drop_chances:{mainhand:0f,offhand:0f,head:0f,chest:0f,legs:0f,feet:0f},DeathLootTable:"minecraft:empty"}

# W3: +1 vindicator
execute if score #dg_type ec.var matches 2 if score #dg_players ec.var matches 2.. if score #dg_wave ec.var matches 3 run summon vindicator ~3 ~1 ~3 {Tags:["dg.mob","ec.entity"],PersistenceRequired:1b,CanPickUpLoot:0b,drop_chances:{mainhand:0f,offhand:0f,head:0f,chest:0f,legs:0f,feet:0f},DeathLootTable:"minecraft:empty"}

# W4: +1 vindicator, +1 witch
execute if score #dg_type ec.var matches 2 if score #dg_players ec.var matches 2.. if score #dg_wave ec.var matches 4 run summon vindicator ~3 ~1 ~3 {Tags:["dg.mob","ec.entity"],PersistenceRequired:1b,CanPickUpLoot:0b,drop_chances:{mainhand:0f,offhand:0f,head:0f,chest:0f,legs:0f,feet:0f},DeathLootTable:"minecraft:empty",attributes:[{id:"max_health",base:30.0d}]}
execute if score #dg_type ec.var matches 2 if score #dg_players ec.var matches 2.. if score #dg_wave ec.var matches 4 run summon witch ~0 ~1 ~-5 {Tags:["dg.mob","ec.entity"],PersistenceRequired:1b,DeathLootTable:"minecraft:empty"}

# W5: +1 armored vindicator (raid lieutenant)
execute if score #dg_type ec.var matches 2 if score #dg_players ec.var matches 2.. if score #dg_wave ec.var matches 5 run summon vindicator ~3 ~1 ~3 {Tags:["dg.mob","ec.entity"],PersistenceRequired:1b,CanPickUpLoot:0b,drop_chances:{mainhand:0f,offhand:0f,head:0f,chest:0f,legs:0f,feet:0f},DeathLootTable:"minecraft:empty",equipment:{chest:{id:"minecraft:iron_chestplate"}},attributes:[{id:"max_health",base:40.0d}]}

# === 3+ PLAYERS: Second village bonus batch ===

execute if score #dg_type ec.var matches 2 if score #dg_players ec.var matches 3.. if score #dg_wave ec.var matches 1 run summon pillager ~-3 ~1 ~-3 {Tags:["dg.mob","ec.entity"],PersistenceRequired:1b,CanPickUpLoot:0b,drop_chances:{mainhand:0f,offhand:0f,head:0f,chest:0f,legs:0f,feet:0f},DeathLootTable:"minecraft:empty"}

execute if score #dg_type ec.var matches 2 if score #dg_players ec.var matches 3.. if score #dg_wave ec.var matches 2 run summon pillager ~-3 ~1 ~3 {Tags:["dg.mob","ec.entity"],PersistenceRequired:1b,CanPickUpLoot:0b,drop_chances:{mainhand:0f,offhand:0f,head:0f,chest:0f,legs:0f,feet:0f},DeathLootTable:"minecraft:empty"}
execute if score #dg_type ec.var matches 2 if score #dg_players ec.var matches 3.. if score #dg_wave ec.var matches 2 run summon vindicator ~3 ~1 ~-3 {Tags:["dg.mob","ec.entity"],PersistenceRequired:1b,CanPickUpLoot:0b,drop_chances:{mainhand:0f,offhand:0f,head:0f,chest:0f,legs:0f,feet:0f},DeathLootTable:"minecraft:empty"}

# W3 (3p+): +1 armored vindicator, +1 witch
execute if score #dg_type ec.var matches 2 if score #dg_players ec.var matches 3.. if score #dg_wave ec.var matches 3 run summon vindicator ~-3 ~1 ~3 {Tags:["dg.mob","ec.entity"],PersistenceRequired:1b,CanPickUpLoot:0b,drop_chances:{mainhand:0f,offhand:0f,head:0f,chest:0f,legs:0f,feet:0f},DeathLootTable:"minecraft:empty",equipment:{chest:{id:"minecraft:iron_chestplate"}}}
execute if score #dg_type ec.var matches 2 if score #dg_players ec.var matches 3.. if score #dg_wave ec.var matches 3 run summon witch ~3 ~1 ~-3 {Tags:["dg.mob","ec.entity"],PersistenceRequired:1b,DeathLootTable:"minecraft:empty"}

# === 4+ PLAYERS: Third village bonus batch ===

# W4 (4p+): +1 evoker, +1 witch
execute if score #dg_type ec.var matches 2 if score #dg_players ec.var matches 4.. if score #dg_wave ec.var matches 4 run summon evoker ~0 ~1 ~4 {Tags:["dg.mob","ec.entity"],PersistenceRequired:1b,CanPickUpLoot:0b,drop_chances:{mainhand:0f,offhand:0f,head:0f,chest:0f,legs:0f,feet:0f},DeathLootTable:"minecraft:empty"}
execute if score #dg_type ec.var matches 2 if score #dg_players ec.var matches 4.. if score #dg_wave ec.var matches 4 run summon witch ~0 ~1 ~-4 {Tags:["dg.mob","ec.entity"],PersistenceRequired:1b,DeathLootTable:"minecraft:empty"}

# W5 (4p+): +1 ravager (war beast reinforcement)
execute if score #dg_type ec.var matches 2 if score #dg_players ec.var matches 4.. if score #dg_wave ec.var matches 5 run summon ravager ~0 ~1 ~4 {Tags:["dg.mob","ec.entity"],PersistenceRequired:1b,DeathLootTable:"minecraft:empty",CustomName:{text:"War Beast",color:"red"},CustomNameVisible:1b,attributes:[{id:"max_health",base:80.0d}]}
