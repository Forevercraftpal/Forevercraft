# Dungeon Leaderboard — Show completion time (macro)
$data modify storage evercraft:notify stage.c set value [{text:"⏱ ",color:"gray"},{text:"Completion Time: ",color:"gray"},{text:"$(seconds)s",color:"aqua",bold:true},{text:" ⏱",color:"gray"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
