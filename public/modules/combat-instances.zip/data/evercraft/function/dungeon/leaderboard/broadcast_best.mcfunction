# Dungeon Leaderboard — Broadcast new personal best (macro)
# Run as: the player who set the record
# (Wave 2, 2026-06-10: record brag — whoami-baked, protected, 30s TTL.)
function evercraft:util/notify/whoami
$data modify storage evercraft:notify stage.c set value [{text:""},{text:" set a new best time of ",color:"gold"},{text:"$(seconds)s",color:"aqua",bold:true},{text:" in ",color:"gold"},{text:"$(instance)",color:"light_purple",bold:true},{text:"!",color:"gold"}]
data modify storage evercraft:notify stage.c[0].text set from storage evercraft:notify named.who
scoreboard players set #ndur ec.temp 50
execute as @a run scoreboard players set #nttl ec.temp 600
execute as @a run function evercraft:util/notify/emit_keep

# Wiring Audit #15 polish-wave AU17 (AU15-FOLLOWUP.2, Joseph 2026-05-29): multiplayer-only
# venue-pin follow-on. `dg.best_inst` (set in new_best.mcfunction) records the player's
# PB venue. On multiplayer servers, surface "<player>'s best venue: <instance>" so other
# players know where the record was set. Gate via `@a[limit=2]` — solo servers see only
# the primary line above.
# (Wave 2, 2026-06-10: venue note — whoami-baked, 15s TTL; only with 2+ players online, as before.)
execute if entity @a[limit=2] run function evercraft:util/notify/whoami
$data modify storage evercraft:notify stage.c set value [{text:"",color:"yellow",italic:true},{text:"'s best venue: ",color:"gray",italic:true},{text:"$(instance)",color:"light_purple",italic:true},{text:".",color:"gray",italic:true}]
data modify storage evercraft:notify stage.c[0].text set from storage evercraft:notify named.who
scoreboard players set #ndur ec.temp 45
execute if entity @a[limit=2] as @a run scoreboard players set #nttl ec.temp 300
execute if entity @a[limit=2] as @a run function evercraft:util/notify/emit
