# Wiring Audit B (2026-05-29) W6: Dungeon Leaderboard — Check completion time (per-party MACRO).
# Called as @s each dungeon participant after completion with storage cart for $(pid).

# Compute elapsed ticks: gametime - start_time
execute store result score @s dg.elapsed run time query gametime
scoreboard players operation @s dg.elapsed -= @s dg.start_time

# Convert to seconds (/ 20)
scoreboard players operation @s dg.elapsed_s = @s dg.elapsed
scoreboard players set #20 ec.temp 20
scoreboard players operation @s dg.elapsed_s /= #20 ec.temp

# Check if this is a new personal best (or first completion)
execute if score @s dg.best_time matches 0 run function evercraft:dungeon/leaderboard/new_best with storage evercraft:_shared cart
execute if score @s dg.best_time matches 1.. if score @s dg.elapsed < @s dg.best_time run function evercraft:dungeon/leaderboard/new_best with storage evercraft:_shared cart

# Always show completion time
execute store result storage evercraft:_shared cart.seconds int 1 run scoreboard players get @s dg.elapsed_s
function evercraft:dungeon/leaderboard/show_time with storage evercraft:_shared cart
