# Wiring Audit B (2026-05-29) W6: Dungeon Leaderboard — New personal best (per-party MACRO).
# Called as @s the player who set a new record, with storage cart for $(pid).

# Update best time (ticks and seconds)
scoreboard players operation @s dg.best_time = @s dg.elapsed
scoreboard players operation @s dg.best_time_s = @s dg.elapsed_s

# Wiring Audit #15 W4.2: capture this run's instance ID as the player's personal-best instance
$scoreboard players operation @s dg.best_inst = #dg_struct_id.$(pid) ec.var

# Celebration (private)
data modify storage evercraft:notify stage.c set value [{text:"⚡ ",color:"gold"},{text:"NEW PERSONAL BEST!",color:"gold",bold:true},{text:" ⚡",color:"gold"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.player.levelup master @s ~ ~ ~ 0.8 1.5

# Stage the CURRENT floor's instance name into cart for broadcast macro
function evercraft:dungeon/instance/get_name with storage evercraft:_shared cart

# Broadcast to all players with instance type
$execute if score #dg_type.$(pid) ec.var matches 1 run data modify storage evercraft:_shared cart.instance set from storage evercraft:_shared cart.name
$execute if score #dg_type.$(pid) ec.var matches 2 run data modify storage evercraft:_shared cart.instance set value "Village Defense"
execute store result storage evercraft:_shared cart.seconds int 1 run scoreboard players get @s dg.elapsed_s
function evercraft:dungeon/leaderboard/broadcast_best with storage evercraft:_shared cart
