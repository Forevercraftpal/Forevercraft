# Wiring Audit B (2026-05-29) W6: Dungeon Instance — Fail (Player Died) (per-party MACRO).
# Called via dungeon/on_death_outer with storage evercraft:_shared cart for $(pid).
# Shape D-1 death intercept: dispatched from tick.mcfunction per-party death gate.

# Totem pop visual (death intercepted)
$execute as @a[tag=dg.player,tag=p$(pid)] at @s run particle minecraft:totem_of_undying ~ ~1 ~ 0.5 1 0.5 0.5 50
$execute as @a[tag=dg.player,tag=p$(pid),scores={ec.fx_snd=1..}] at @s run playsound minecraft:item.totem.use master @s ~ ~ ~ 1 1

# Failure title (player may see this on respawn screen) — per-party
$title @a[tag=dg.player,tag=p$(pid)] times 10 60 20
$title @a[tag=dg.player,tag=p$(pid)] title {text:"DUNGEON FAILED",color:"dark_red",bold:true}
$title @a[tag=dg.player,tag=p$(pid)] subtitle {text:"You have fallen...",color:"red"}

# Action bar (server-news to all)
# (Wave 2, 2026-06-10: dungeon-fail echo — actor name baked from the instance player, 15s TTL.)
$execute as @a[tag=dg.player,tag=p$(pid),limit=1] run function evercraft:util/notify/whoami
data modify storage evercraft:notify stage.c set value [{text:""},{text:"'s dungeon challenge has ended — they have fallen!",color:"red"}]
data modify storage evercraft:notify stage.c[0].text set from storage evercraft:notify named.who
scoreboard players set #ndur ec.temp 45
execute as @a run scoreboard players set #nttl ec.temp 300
execute as @a run function evercraft:util/notify/emit

# Sounds (play to all nearby this party's center since player is dead)
$execute at @e[type=marker,tag=dg.center,tag=p$(pid),limit=1] run playsound minecraft:entity.wither.death master @a[distance=..64,scores={ec.fx_snd=1..}] ~ ~ ~ 0.5 0.5

# Cleanup (per-party)
function evercraft:dungeon/cleanup with storage evercraft:_shared cart
