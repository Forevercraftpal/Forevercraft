# Wiring Audit B (2026-05-29) W6: Dungeon Instance — Fail (Time Ran Out) (per-party MACRO).
# Called with storage evercraft:_shared cart for $(pid) from tick_active when timer hit 0.

# Failure title (per-party)
$title @a[tag=dg.player,tag=p$(pid)] times 10 60 20
$title @a[tag=dg.player,tag=p$(pid)] title {text:"TIME'S UP!",color:"dark_red",bold:true}
$title @a[tag=dg.player,tag=p$(pid)] subtitle {text:"The dungeon has overwhelmed you...",color:"red"}

# Action bar (server-news to all players)
# (Wave 2, 2026-06-10: dungeon-fail echo — actor name baked from the instance player, 15s TTL.)
$execute as @a[tag=dg.player,tag=p$(pid),limit=1] run function evercraft:util/notify/whoami
data modify storage evercraft:notify stage.c set value [{text:""},{text:"'s dungeon challenge has ended — time ran out!",color:"red"}]
data modify storage evercraft:notify stage.c[0].text set from storage evercraft:notify named.who
scoreboard players set #ndur ec.temp 45
execute as @a run scoreboard players set #nttl ec.temp 300
execute as @a run function evercraft:util/notify/emit

# Sounds (per-party)
$execute as @a[tag=dg.player,tag=p$(pid),scores={ec.fx_snd=1..}] at @s run playsound minecraft:entity.wither.death master @s ~ ~ ~ 0.5 0.5
$execute as @a[tag=dg.player,tag=p$(pid),scores={ec.fx_snd=1..}] at @s run playsound minecraft:entity.lightning_bolt.thunder master @s ~ ~ ~ 0.3 0.5

# Cleanup (per-party)
function evercraft:dungeon/cleanup with storage evercraft:_shared cart
