# Wiring Audit B (2026-05-29) W6: Dungeon — Per-Party Wave Spawn (per-party MACRO).
# Called with storage evercraft:_shared cart for $(pid). At this party's dg.center.
# Stages per-pid → globals, calls instance/spawn_wave (mobs+scaling), then per-party wave_announce.

# Stage globals so instance/* + apply_scaling read this party's state.
# Sequential per-tick — race-free because tick_active dispatch is sequential per @s.
$scoreboard players operation #dg_wave ec.var = #dg_wave.$(pid) ec.var
$scoreboard players operation #dg_instance ec.var = #dg_instance.$(pid) ec.var
$scoreboard players operation #dg_type ec.var = #dg_type.$(pid) ec.var
$scoreboard players operation #dg_players ec.var = #dg_players.$(pid) ec.var
$scoreboard players operation #dg_difficulty ec.var = #dg_difficulty.$(pid) ec.var
$scoreboard players operation #dg_dr ec.var = #dg_dr.$(pid) ec.var
$scoreboard players operation #dg_floor ec.var = #dg_floor.$(pid) ec.var
$scoreboard players operation #dg_modifier ec.var = #dg_modifier.$(pid) ec.var
$scoreboard players operation #dg_afx_count ec.var = #dg_afx_count.$(pid) ec.var
$scoreboard players operation #dg_afx1 ec.var = #dg_afx1.$(pid) ec.var
$scoreboard players operation #dg_afx2 ec.var = #dg_afx2.$(pid) ec.var
$scoreboard players operation #dg_afx3 ec.var = #dg_afx3.$(pid) ec.var

# Spawn mobs (instance/* reads globals). instance/spawn_wave was patched to NOT call wave_announce
# anymore — caller (us) calls per-party wave_announce after.
function evercraft:dungeon/instance/spawn_wave

# Retag freshly-spawned mobs with this party's p<pid> tag for cross-party isolation.
# BUGFIX (2026-06-20): was `tag=!dg.scaled` — but instance/spawn_wave above already runs
# apply_scaling, which tags EVERY fresh mob dg.scaled. So the !dg.scaled filter matched nothing,
# dungeon mobs never got p<pid>, the count @e[dg.mob,p<pid>] read 0, and the tick blasted through
# all 5 waves at once (every wave's mobs dumped together, then an instant descent prompt). Drop the
# filter: at this party's dg.center the only nearby dg.mob ARE this party's fresh ones (previous
# waves are cleared before the next spawns; other parties are far), and re-tagging is idempotent.
$tag @e[tag=dg.mob,distance=..30] add p$(pid)

# Per-party wave announcement
function evercraft:dungeon/instance/wave_announce with storage evercraft:_shared cart
