# Wiring Audit B (2026-05-29) W6: Dungeon Instance — Begin (entry shell).
# Called as @s the triggering player from menu/select.
# Derives pid (dual-key: ec.party_id for parties, adv.gui_session+10000 for solos)
# then dispatches per-party begin_inner macro.

function evercraft:_shared/derive_pid_from_party
function evercraft:dungeon/begin_inner with storage evercraft:_shared cart
