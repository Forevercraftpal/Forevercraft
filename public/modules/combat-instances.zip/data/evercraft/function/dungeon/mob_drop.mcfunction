# Wiring Audit B (2026-05-29) W6: Dungeon Instance — Mob Kill Drop (entry shell).
# Called as @s the killing player from advancement evercraft:dungeon/killed_mob.
# 1% chance to spawn a mob crate when killing any dungeon mob; scaled XP based on this player's party.
# Derives pid then dispatches mob_drop_inner macro.

function evercraft:_shared/derive_pid_from_party
function evercraft:dungeon/mob_drop_inner with storage evercraft:_shared cart
