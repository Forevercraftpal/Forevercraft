# Wiring Audit B (2026-05-29) W6: Dungeon — HUD (per-party MACRO).
# Called from tick_active with storage cart for $(pid). Computes per-party timer display
# and shows wave/mobs/time via macro to this party's participants.

# Calculate total seconds remaining (per-party)
$scoreboard players operation #dg_sec.$(pid) ec.var = #dg_timer.$(pid) ec.var
$scoreboard players operation #dg_sec.$(pid) ec.var /= #20 ec.const

# Calculate minutes (per-party)
$scoreboard players operation #dg_min.$(pid) ec.var = #dg_sec.$(pid) ec.var
$scoreboard players operation #dg_min.$(pid) ec.var /= #60 ec.const

# Calculate remaining seconds (sec % 60) (per-party)
$scoreboard players operation #dg_sec_rem.$(pid) ec.var = #dg_sec.$(pid) ec.var
$scoreboard players operation #dg_sec_rem.$(pid) ec.var %= #60 ec.const

# Stage values into cart for macro display
$execute store result storage evercraft:_shared cart.wave int 1 run scoreboard players get #dg_wave.$(pid) ec.var
$execute store result storage evercraft:_shared cart.mobs int 1 run scoreboard players get #dg_mobs.$(pid) ec.var
$execute store result storage evercraft:_shared cart.min int 1 run scoreboard players get #dg_min.$(pid) ec.var
$execute store result storage evercraft:_shared cart.sec int 1 run scoreboard players get #dg_sec_rem.$(pid) ec.var

# Call macro to display HUD (different format for seconds < 10 for zero-padding)
$execute if score #dg_sec_rem.$(pid) ec.var matches ..9 run function evercraft:dungeon/hud_display_padded with storage evercraft:_shared cart
$execute if score #dg_sec_rem.$(pid) ec.var matches 10.. run function evercraft:dungeon/hud_display with storage evercraft:_shared cart
