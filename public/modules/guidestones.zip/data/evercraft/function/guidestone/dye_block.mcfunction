# Guidestone — Dye Block (right-click with dye)
# Run as: the interaction entity, at its position
# Called from on_interact when player holds a dye


# Detect which dye the player is holding
execute as @p[distance=..6] run function evercraft:dyeing/detect_color

# Azure
execute if data storage evercraft:dyeing {color_id:"azure"} as @e[type=marker,tag=ec.gs_marker,distance=..2,limit=1] run data modify entity @s data.color set value "azure"
execute if data storage evercraft:dyeing {color_id:"azure"} as @e[type=armor_stand,tag=ec.gs_stand,distance=..2,limit=1] on passengers run data modify entity @s item.components."minecraft:profile".properties[0].value set value "ewogICJ0aW1lc3RhbXAiIDogMTc3MzUzODc3MDYzOSwKICAicHJvZmlsZUlkIiA6ICIzMjA3MWFlYjYzZjI0NmY0YTVlMGZhMWY3ODg3ZGRhNCIsCiAgInByb2ZpbGVOYW1lIiA6ICJNcl9HZW5lcyIsCiAgInNpZ25hdHVyZVJlcXVpcmVkIiA6IHRydWUsCiAgInRleHR1cmVzIiA6IHsKICAgICJTS0lOIiA6IHsKICAgICAgInVybCIgOiAiaHR0cDovL3RleHR1cmVzLm1pbmVjcmFmdC5uZXQvdGV4dHVyZS9lYjUzY2ExZTM4ZTA2OWRmNGI0ZDEyZTJjYmJmM2Q5ZGI1NzFjOTEzNGYxNzQ1NzcyODU2N2Y1ZGIyOGExMjg1IiwKICAgICAgIm1ldGFkYXRhIiA6IHsKICAgICAgICAibW9kZWwiIDogInNsaW0iCiAgICAgIH0KICAgIH0KICB9Cn0="

# Crimson
execute if data storage evercraft:dyeing {color_id:"crimson"} as @e[type=marker,tag=ec.gs_marker,distance=..2,limit=1] run data modify entity @s data.color set value "crimson"
execute if data storage evercraft:dyeing {color_id:"crimson"} as @e[type=armor_stand,tag=ec.gs_stand,distance=..2,limit=1] on passengers run data modify entity @s item.components."minecraft:profile".properties[0].value set value "ewogICJ0aW1lc3RhbXAiIDogMTc3MzUzODc1Njg1OSwKICAicHJvZmlsZUlkIiA6ICIyMWUzNjdkNzI1Y2Y0ZTNiYjI2OTJjNGEzMDBhNGRlYiIsCiAgInByb2ZpbGVOYW1lIiA6ICJHZXlzZXJNQyIsCiAgInNpZ25hdHVyZVJlcXVpcmVkIiA6IHRydWUsCiAgInRleHR1cmVzIiA6IHsKICAgICJTS0lOIiA6IHsKICAgICAgInVybCIgOiAiaHR0cDovL3RleHR1cmVzLm1pbmVjcmFmdC5uZXQvdGV4dHVyZS82MGY0YWJiZDYwM2Q4MTU5ZDI1MjEzZTJkMzZlNGUwZDlhYjQzODIxNzdiNGEzZDlkYzc5Y2MzNGNjYmNhMjdlIiwKICAgICAgIm1ldGFkYXRhIiA6IHsKICAgICAgICAibW9kZWwiIDogInNsaW0iCiAgICAgIH0KICAgIH0KICB9Cn0="

# Solar
execute if data storage evercraft:dyeing {color_id:"solar"} as @e[type=marker,tag=ec.gs_marker,distance=..2,limit=1] run data modify entity @s data.color set value "solar"
execute if data storage evercraft:dyeing {color_id:"solar"} as @e[type=armor_stand,tag=ec.gs_stand,distance=..2,limit=1] on passengers run data modify entity @s item.components."minecraft:profile".properties[0].value set value "ewogICJ0aW1lc3RhbXAiIDogMTc3MzUzODc4NTkxNywKICAicHJvZmlsZUlkIiA6ICI2OTY0OGJkMDMwMDU0MDRlOTk4YTI5OTRhNGE4NmY1OSIsCiAgInByb2ZpbGVOYW1lIiA6ICJxdWFydHlxd2VydHkiLAogICJzaWduYXR1cmVSZXF1aXJlZCIgOiB0cnVlLAogICJ0ZXh0dXJlcyIgOiB7CiAgICAiU0tJTiIgOiB7CiAgICAgICJ1cmwiIDogImh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvZmY4MzJlOTMyZjFhZjM4MTNkMTVkYjhlN2YxYjIzZTM3NmZjZjExMjc1NmVlYTk3NGQyNWFmOTlhOWYzZjYxZSIsCiAgICAgICJtZXRhZGF0YSIgOiB7CiAgICAgICAgIm1vZGVsIiA6ICJzbGltIgogICAgICB9CiAgICB9CiAgfQp9"

# Verdant
execute if data storage evercraft:dyeing {color_id:"verdant"} as @e[type=marker,tag=ec.gs_marker,distance=..2,limit=1] run data modify entity @s data.color set value "verdant"
execute if data storage evercraft:dyeing {color_id:"verdant"} as @e[type=armor_stand,tag=ec.gs_stand,distance=..2,limit=1] on passengers run data modify entity @s item.components."minecraft:profile".properties[0].value set value "ewogICJ0aW1lc3RhbXAiIDogMTc3MzUzODc5OTQ2NCwKICAicHJvZmlsZUlkIiA6ICIwNDg0N2ZjNWM5YjY0NTQ1YjI1ZWJkYmJiNzdjNjg2NSIsCiAgInByb2ZpbGVOYW1lIiA6ICJOYXFsdWEiLAogICJzaWduYXR1cmVSZXF1aXJlZCIgOiB0cnVlLAogICJ0ZXh0dXJlcyIgOiB7CiAgICAiU0tJTiIgOiB7CiAgICAgICJ1cmwiIDogImh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvZWRjM2ViNDQ5OWVkYmU2OTg0MzE3OTBkOGVjOTQ0OGMxYWE5ZWNiYWM0ZjUzMWYxODg4ZTE1Mjk4NWZmOWUwYiIsCiAgICAgICJtZXRhZGF0YSIgOiB7CiAgICAgICAgIm1vZGVsIiA6ICJzbGltIgogICAgICB9CiAgICB9CiAgfQp9"

# Ivory
execute if data storage evercraft:dyeing {color_id:"ivory"} as @e[type=marker,tag=ec.gs_marker,distance=..2,limit=1] run data modify entity @s data.color set value "ivory"
execute if data storage evercraft:dyeing {color_id:"ivory"} as @e[type=armor_stand,tag=ec.gs_stand,distance=..2,limit=1] on passengers run data modify entity @s item.components."minecraft:profile".properties[0].value set value "ewogICJ0aW1lc3RhbXAiIDogMTc3NDM2OTEzMjIyMSwKICAicHJvZmlsZUlkIiA6ICJjYmYxNGIxMGJhNWU0NzgwYjIyNmFiNmQzOTUxODk4YiIsCiAgInByb2ZpbGVOYW1lIiA6ICJFZ2d5QnV0dG9uMjQxMSIsCiAgInNpZ25hdHVyZVJlcXVpcmVkIiA6IHRydWUsCiAgInRleHR1cmVzIiA6IHsKICAgICJTS0lOIiA6IHsKICAgICAgInVybCIgOiAiaHR0cDovL3RleHR1cmVzLm1pbmVjcmFmdC5uZXQvdGV4dHVyZS8xNGYxNjM5OTJmNzEzMTU2ZDFlYzIxZmVjOTg3MDc2MDliMWNmNDU4NWU3YWViM2JmN2JjMzVkYTUyNGQ1MTY4IiwKICAgICAgIm1ldGFkYXRhIiA6IHsKICAgICAgICAibW9kZWwiIDogInNsaW0iCiAgICAgIH0KICAgIH0KICB9Cn0="

# Obsidian
execute if data storage evercraft:dyeing {color_id:"obsidian"} as @e[type=marker,tag=ec.gs_marker,distance=..2,limit=1] run data modify entity @s data.color set value "obsidian"
execute if data storage evercraft:dyeing {color_id:"obsidian"} as @e[type=armor_stand,tag=ec.gs_stand,distance=..2,limit=1] on passengers run data modify entity @s item.components."minecraft:profile".properties[0].value set value "ewogICJ0aW1lc3RhbXAiIDogMTc3NDM2OTE2MjE0MiwKICAicHJvZmlsZUlkIiA6ICI4Y2UzMDAxMDIzZDY0Nzk0YWM2ODIyNzE4M2FjNzYzMCIsCiAgInByb2ZpbGVOYW1lIiA6ICJTb25pY1R1bmRlcjciLAogICJzaWduYXR1cmVSZXF1aXJlZCIgOiB0cnVlLAogICJ0ZXh0dXJlcyIgOiB7CiAgICAiU0tJTiIgOiB7CiAgICAgICJ1cmwiIDogImh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvMWY4NDUzZDc4OWQyOTFlOTBjNWM3ZTAzMDVjMzEyOTc5ZDgzZmJhYmJjMTc0YzRjMTc3OTZhNDAxOTczNTQxMCIsCiAgICAgICJtZXRhZGF0YSIgOiB7CiAgICAgICAgIm1vZGVsIiA6ICJzbGltIgogICAgICB9CiAgICB9CiAgfQp9"

# Rose
execute if data storage evercraft:dyeing {color_id:"rose"} as @e[type=marker,tag=ec.gs_marker,distance=..2,limit=1] run data modify entity @s data.color set value "rose"
execute if data storage evercraft:dyeing {color_id:"rose"} as @e[type=armor_stand,tag=ec.gs_stand,distance=..2,limit=1] on passengers run data modify entity @s item.components."minecraft:profile".properties[0].value set value "ewogICJ0aW1lc3RhbXAiIDogMTc3NDM2OTE3NDQ2MiwKICAicHJvZmlsZUlkIiA6ICIxZjk0OTQzN2RlYmQ0ODgyYTlhYzZhZmZmN2RhNDcxMSIsCiAgInByb2ZpbGVOYW1lIiA6ICJNaWlra2FLIiwKICAic2lnbmF0dXJlUmVxdWlyZWQiIDogdHJ1ZSwKICAidGV4dHVyZXMiIDogewogICAgIlNLSU4iIDogewogICAgICAidXJsIiA6ICJodHRwOi8vdGV4dHVyZXMubWluZWNyYWZ0Lm5ldC90ZXh0dXJlL2RmMjA5NWJjNDkyYzc5NDRiZjM0NzNmZjI2NDJiZjQyMjJmMGVkY2U3ZmY4NmU3NGRlNTQwNWQ1NTg3ZGFlMDEiLAogICAgICAibWV0YWRhdGEiIDogewogICAgICAgICJtb2RlbCIgOiAic2xpbSIKICAgICAgfQogICAgfQogIH0KfQ=="

# Noir
execute if data storage evercraft:dyeing {color_id:"noir"} as @e[type=marker,tag=ec.gs_marker,distance=..2,limit=1] run data modify entity @s data.color set value "noir"
execute if data storage evercraft:dyeing {color_id:"noir"} as @e[type=armor_stand,tag=ec.gs_stand,distance=..2,limit=1] on passengers run data modify entity @s item.components."minecraft:profile".properties[0].value set value "ewogICJ0aW1lc3RhbXAiIDogMTc3NDM2OTE4NzgyNCwKICAicHJvZmlsZUlkIiA6ICJkMTNmODljZmRiMmY0OTUxOWE4YjgxMTUzN2FmZWU2ZSIsCiAgInByb2ZpbGVOYW1lIiA6ICJ2ZXhsZWhhaGEiLAogICJzaWduYXR1cmVSZXF1aXJlZCIgOiB0cnVlLAogICJ0ZXh0dXJlcyIgOiB7CiAgICAiU0tJTiIgOiB7CiAgICAgICJ1cmwiIDogImh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvZjZmMzQ4ZTQzYjNlZDlhM2Y5NjA3NzMyMTkxYzVhMGUzZjNhMjEyZTkxM2ExYjY4OTE2ZDcyN2UwMTQ3MzgyMiIsCiAgICAgICJtZXRhZGF0YSIgOiB7CiAgICAgICAgIm1vZGVsIiA6ICJzbGltIgogICAgICB9CiAgICB9CiAgfQp9"

# Consume 1 dye from player's hand
execute as @p[distance=..6] run item modify entity @s weapon.mainhand {"function":"minecraft:set_count","count":-1,"add":true}

# Effects
function evercraft:dyeing/effects

# Feedback
data modify storage evercraft:notify stage.c set value [{text:"Dyed ",color:"gray",italic:true},{storage:"evercraft:dyeing",nbt:"color_name",interpret:false,color:"#E0B0FF",italic:true},{text:" Guidestone",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 45
execute as @p[distance=..6] run function evercraft:util/notify/emit
