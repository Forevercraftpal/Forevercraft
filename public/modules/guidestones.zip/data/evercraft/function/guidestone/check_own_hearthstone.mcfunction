# Guidestone — set #gs_own_home ec.gs_temp = 1 if tp_target (a hearthstone) is
# @s's OWN home. Called from check_unlock ONLY when tp_target.type=="hearthstone".
# Compares the owner's full real UUID[0-3] (the registry stores it via
# housing/register_guidestone <- setup_hearthstone/confirm_relocate) against @s's
# UUID. Joseph 2026-06-22 — fixes the old check that compared the stored UUID[3]
# to @s companion.id (the global pid, a DIFFERENT id space than a UUID component),
# which never matched, so players paid 30 levels to reach their own home.
#
# dest_u* are pre-zeroed so a malformed/legacy entry missing a uuid field can't
# leave a stale score that false-matches — a full all-zero UUID can never equal a
# real player's UUID, and the match requires ALL FOUR ints.
scoreboard players set #dest_u0 ec.gs_temp 0
scoreboard players set #dest_u1 ec.gs_temp 0
scoreboard players set #dest_u2 ec.gs_temp 0
scoreboard players set #dest_u3 ec.gs_temp 0
execute store result score #dest_u0 ec.gs_temp run data get storage evercraft:guidestone tp_target.uuid0
execute store result score #dest_u1 ec.gs_temp run data get storage evercraft:guidestone tp_target.uuid1
execute store result score #dest_u2 ec.gs_temp run data get storage evercraft:guidestone tp_target.uuid2
execute store result score #dest_u3 ec.gs_temp run data get storage evercraft:guidestone tp_target.uuid3
execute store result score #my_u0 ec.gs_temp run data get entity @s UUID[0]
execute store result score #my_u1 ec.gs_temp run data get entity @s UUID[1]
execute store result score #my_u2 ec.gs_temp run data get entity @s UUID[2]
execute store result score #my_u3 ec.gs_temp run data get entity @s UUID[3]
execute if score #my_u0 ec.gs_temp = #dest_u0 ec.gs_temp if score #my_u1 ec.gs_temp = #dest_u1 ec.gs_temp if score #my_u2 ec.gs_temp = #dest_u2 ec.gs_temp if score #my_u3 ec.gs_temp = #dest_u3 ec.gs_temp run scoreboard players set #gs_own_home ec.gs_temp 1
