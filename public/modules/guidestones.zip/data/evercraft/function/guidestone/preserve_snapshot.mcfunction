# ══════════════════════════════════════════════════════════════
# Guidestone — Pioneer safe space: SNAPSHOT the XP-unlock list (pre-strip)
# Run as @s (the dying Pioneer), BEFORE admin/strip_player_zero.
# Macro args: {pid:<companion.id>, u0,u1,u2,u3:<player UUID ints>}
# Joseph 2026-06-22: a Pioneer should NOT lose guidestone links they paid 30
# levels to establish.
#
# The unlock list lives at storage evercraft:guidestone unlocked."<pid>", keyed
# by companion.id (the global player id). The strip zeroes companion.id and the
# new_player advancement re-mints a FRESH id next tick — so the list, though it
# survives in storage, becomes ORPHANED under the dead id. We can't restore it
# synchronously (the new id doesn't exist until the next tick), so we stash it
# under the player's REAL UUID (stable) in gs_preserve and re-key it under the
# new id from new_player's restore hook (guidestone/preserve_restore_try).
# ══════════════════════════════════════════════════════════════

# Nothing to preserve if this player never unlocked any links.
$execute unless data storage evercraft:guidestone unlocked."$(pid)" run return 0

# Move (not copy) the list into the UUID-keyed holding slot — drop the old
# id-keyed entry so it doesn't leak (the id is never reused; #Global only grows).
$data modify storage evercraft:guidestone gs_preserve."u$(u0)_$(u1)_$(u2)_$(u3)" set from storage evercraft:guidestone unlocked."$(pid)"
$data remove storage evercraft:guidestone unlocked."$(pid)"
