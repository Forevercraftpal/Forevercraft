# UX ADDITION 3 — give the Guidestone Deed (macro)
# Run as: @s = the placing player. Macro arg: gs_id (the registry entry id).
# gs_deed:1b is the signed-trigger key; gs_id carries the target registry id;
# evercraft_item:1b marks it a pack item. Distinct from the home deed's
# hs_deed key so the shared extract branches correctly.
$give @s minecraft:writable_book[custom_name={text:"Guidestone Deed",color:"aqua",italic:false},custom_data={gs_deed:1b,evercraft_item:1b,gs_id:$(gs_id)},writable_book_content={pages:["Write this guidestone's name on this page and sign the deed to label it on the network!"]}] 1
