# Guidestone Menu — View Navigation: Next view (right arrow)
# Run as the interaction entity

# Clear interaction data
data remove entity @s interaction

# Switch view as the player
# GUI-anchor (2026-06-09 sweep): re-render from the stationary block-anchor
# marker (stored yaw, pitch 0) — NOT the player, who may have moved/turned.
# Player-positioned fallback when the marker is missing.
execute as @a[tag=ec.gs_in_menu,distance=..5,limit=1,sort=nearest] at @e[type=marker,tag=ec.gui_banchor,distance=..8,limit=1,sort=nearest] run function evercraft:guidestone/menu/switch_view {operation:"add"}
execute unless entity @e[type=marker,tag=ec.gui_banchor,distance=..8] as @a[tag=ec.gs_in_menu,distance=..5,limit=1,sort=nearest] at @s run function evercraft:guidestone/menu/switch_view {operation:"add"}
