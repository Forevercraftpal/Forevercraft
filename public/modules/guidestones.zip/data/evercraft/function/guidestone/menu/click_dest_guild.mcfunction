# Guidestone Menu — Click a destination slot (View 4: Guild Network)
# Macro arg: slot (0-7)
# Run as the interaction entity

# Clear interaction data
data remove entity @s interaction

# Calculate which filtered index was clicked: (page-1)*10 + slot
$scoreboard players set #gs_click ec.gs_temp $(slot)
# W3 (Wiring Audit #51): @s IS the clicking player (dispatch is `... on target run function click_dest_guild`).
# Use @s directly instead of re-resolving the nearest in-menu player by proximity.
scoreboard players operation #gs_page_off ec.gs_temp = @s ec.gs_page
scoreboard players remove #gs_page_off ec.gs_temp 1
scoreboard players set #10 ec.gs_temp 10
scoreboard players operation #gs_page_off ec.gs_temp *= #10 ec.gs_temp
scoreboard players operation #gs_click ec.gs_temp += #gs_page_off ec.gs_temp

# Rebuild the filtered guild list
data modify storage evercraft:guidestone working set from storage evercraft:guidestone registry
data modify storage evercraft:guidestone filtered set value []
function evercraft:guidestone/menu/filter_guild with storage evercraft:guidestone menu_ctx

# Skip to the right index in the filtered list
data modify storage evercraft:guidestone tp_working set from storage evercraft:guidestone filtered
scoreboard players operation #gs_skip ec.gs_temp = #gs_click ec.gs_temp
function evercraft:guidestone/menu/skip_to_entry

# Set free teleport flag (guild network teleports are always free)
scoreboard players set #tp_free ec.gs_temp 1

# Teleport the player
execute as @s[tag=ec.gs_in_menu] run function evercraft:guidestone/teleport with storage evercraft:guidestone tp_target
