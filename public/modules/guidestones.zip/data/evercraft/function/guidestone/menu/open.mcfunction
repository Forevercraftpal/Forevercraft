# Guidestone Menu — Open the network browser
# Run AS the player, positioned/rotated AT the stone's block-anchor marker
# (2026-06-09 GUI sweep W4 — see menu/open_anchored). Every ^ ^ ^ offset below
# anchors the menu at the STONE, yaw facing the opener; it does not follow the
# player. Fallback callers may still run this at the player (old behavior).

# Already in menu? Close first (also kills any orphaned elements)
# Menu Core: Y-displacement close anchor
# One-menu-at-a-time (2026-06-15): close any other open menu before this one claims
# ec.menu_active. Two overlapping menus share the @s adv.gui_session slot; the newer
# open orphans the older menu's session, so it can never consume its click -> stuck
# interaction NBT -> click-sound spam. force_close is idempotent (no-op when nothing open).
execute if entity @s[tag=ec.menu_active] run function evercraft:menu_core/force_close
tag @s add ec.menu_active
execute store result score @s ec.menu_open_y run data get entity @s Pos[1] 100
# Sneak-position polish (MP-P3.5): when crouching, lower spawn anchor by 0.20m so
# menu sits at a comfortable view-angle for the lowered eye height. Tag is read by
# every summon line below (paired unless/if) and removed at end-of-file.
tag @s remove ec.menu_sneak_open
execute if predicate evercraft:player_crouching run tag @s add ec.menu_sneak_open


execute if entity @s[tag=ec.gs_in_menu] run function evercraft:guidestone/menu/close

# Safety: kill any orphaned menu elements from a previous session (crash, relog, etc.)
# (anchor context — orphans live near the STONE now, not near the player; stale
# block-anchor markers are swept too, sparing the fresh ec.ga_bnew one)
kill @e[type=text_display,tag=ec.gs_menu_el,distance=..5]
kill @e[type=interaction,tag=ec.gs_menu_el,distance=..5]
kill @e[type=item_display,tag=ec.gs_menu_el,distance=..5]
kill @e[type=marker,tag=ec.gui_banchor,tag=!ec.ga_bnew,distance=..5]

# Store how many guidestones exist
execute store result score @s ec.gs_temp run data get storage evercraft:guidestone registry

# If no guidestones registered, tell the player
data modify storage evercraft:notify stage.c set value [{text:"No Guidestones have been registered yet!",color:"yellow"}]
scoreboard players set #ndur ec.temp 45
execute if score @s ec.gs_temp matches 0 run function evercraft:util/notify/emit
execute if score @s ec.gs_temp matches 0 run return 0

# Disable the guidestone interaction entity so it can't be re-triggered
# (anchor context — the stone's own hitbox is right at the anchor)
data modify entity @e[type=interaction,tag=ec.gs_interact,distance=..5,limit=1] height set value 0.0f

# Tag player as in menu, set initial view and page
tag @s add ec.gs_in_menu
scoreboard players set @s ec.gs_page 1
scoreboard players set @s ec.gs_view 1
scoreboard players set @s ec.gs_menu_time 0

# Guild stone context: if is_guild_stone was set by open_teleport, start on View 4
# Otherwise, clear it (prevents stale context from previous sessions)
execute unless data storage evercraft:guidestone {menu_ctx:{is_guild_stone:1b}} run data modify storage evercraft:guidestone menu_ctx.is_guild_stone set value 0b
execute if data storage evercraft:guidestone {menu_ctx:{is_guild_stone:1b}} run scoreboard players set @s ec.gs_view 4

# Store current guidestone context for menu use
# For remote Portal Dial sessions (ec.gs_remote_menu), menu_ctx is already set — skip marker lookups
execute unless entity @s[tag=ec.gs_remote_menu] run data modify storage evercraft:guidestone menu_ctx.dim set value "minecraft:overworld"
execute unless entity @s[tag=ec.gs_remote_menu] if dimension minecraft:the_nether run data modify storage evercraft:guidestone menu_ctx.dim set value "minecraft:the_nether"
execute unless entity @s[tag=ec.gs_remote_menu] if dimension minecraft:the_end run data modify storage evercraft:guidestone menu_ctx.dim set value "minecraft:the_end"
# Primed status — determines if interdimensional view is accessible
execute unless entity @s[tag=ec.gs_remote_menu] store success storage evercraft:guidestone menu_ctx.primed byte 1 run data get entity @e[type=marker,tag=ec.gs_registered,distance=..5,limit=1,sort=nearest] data.primed
execute unless entity @s[tag=ec.gs_remote_menu] if data entity @e[type=marker,tag=ec.gs_registered,distance=..5,limit=1,sort=nearest] {data:{primed:1b}} run data modify storage evercraft:guidestone menu_ctx.primed set value 1b
execute unless entity @s[tag=ec.gs_remote_menu] unless data entity @e[type=marker,tag=ec.gs_registered,distance=..5,limit=1,sort=nearest] {data:{primed:1b}} run data modify storage evercraft:guidestone menu_ctx.primed set value 0b
# Source ID — used to exclude the current guidestone from the destination list
execute unless entity @s[tag=ec.gs_remote_menu] store result storage evercraft:guidestone menu_ctx.source_id int 1 run scoreboard players get @e[type=marker,tag=ec.gs_registered,distance=..5,limit=1,sort=nearest] ec.gs_id

# Spawn background (solid dark panel — same as Advantage GUI for accessibility)
execute unless entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^ ^1.95 ^1.8 run summon item_display ~ ~ ~ { Tags:["ec.gs_menu_el","ec.gs_menu_bg"], billboard:"center", item:{id:"black_stained_glass_pane",count:1}, item_display:"fixed", transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,-0.02f],scale:[3.9f,2.6f,0.01f]} }
execute if entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^ ^1.75 ^1.8 run summon item_display ~ ~ ~ { Tags:["ec.gs_menu_el","ec.gs_menu_bg"], billboard:"center", item:{id:"black_stained_glass_pane",count:1}, item_display:"fixed", transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,-0.02f],scale:[3.9f,2.6f,0.01f]} }
# Stamp the opener's yaw onto the BG. place_row re-derives the two destination columns via
# `at @e[ec.gs_menu_bg] ... positioned ^+-0.85` on every page-flip/refresh; a summoned display
# defaults to Rotation:[0,0], which would collapse those caret columns onto the world axes (menu
# stops tracking the player's facing). Same yaw-stamp idiom as decor/manage/open. Pitch stays 0
# to match the `rotated ~ 0` plane. (billboard:"center" ignores Rotation for rendering.)
execute store result entity @e[type=item_display,tag=ec.gs_menu_bg,distance=..5,limit=1] Rotation[0] float 1 run data get entity @s Rotation[0]

# Spawn title (view-dependent, starts as "Local Network")
# Ownership-header label (MP-P3.6): foreign viewers see whose menu this is
# 26.1: {selector:} renders blank in text_display — bake @s's name to a $(owner) literal.
function evercraft:util/gui/owner_name
execute rotated ~ 0 positioned ^ ^2.63 ^1.78 run function evercraft:guidestone/menu/open_nm with storage evercraft:scorebake args
execute unless entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^ ^2.45 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f, Tags:["ec.gs_menu_el","ec.gs_menu_title"], billboard:"center", text:[{text:"\u2726 ",color:"dark_purple"},{text:"Local Network",color:"light_purple",bold:true},{text:" \u2726",color:"dark_purple"}], background:1, shadow:1b, transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.578f,0.578f,0.578f]} }
execute if entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^ ^2.25 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f, Tags:["ec.gs_menu_el","ec.gs_menu_title"], billboard:"center", text:[{text:"\u2726 ",color:"dark_purple"},{text:"Local Network",color:"light_purple",bold:true},{text:" \u2726",color:"dark_purple"}], background:1, shadow:1b, transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.578f,0.578f,0.578f]} }

# Spawn view navigation arrows (shared shell — always visible)
# Left arrow (previous view)
execute unless entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^0.7 ^2.45 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f, Tags:["ec.gs_menu_el","ec.gs_view_nav_left_txt"], billboard:"center", text:{text:"<",color:"gray",bold:true}, background:1, shadow:1b, transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.449f,0.449f,0.449f]} }
execute if entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^0.7 ^2.25 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f, Tags:["ec.gs_menu_el","ec.gs_view_nav_left_txt"], billboard:"center", text:{text:"<",color:"gray",bold:true}, background:1, shadow:1b, transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.449f,0.449f,0.449f]} }
execute unless entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^ ^2.35 ^1.8 positioned ^0.7 ^0 ^0 run summon interaction ~ ~ ~ { Tags:["ec.gs_menu_el","ec.gs_view_nav_left"], width:0.2f, height:0.12f, response:1b }
execute if entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^ ^2.15 ^1.8 positioned ^0.7 ^0 ^0 run summon interaction ~ ~ ~ { Tags:["ec.gs_menu_el","ec.gs_view_nav_left"], width:0.2f, height:0.12f, response:1b }

# Right arrow (next view)
execute unless entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^-0.7 ^2.45 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f, Tags:["ec.gs_menu_el","ec.gs_view_nav_right_txt"], billboard:"center", text:{text:">",color:"gray",bold:true}, background:1, shadow:1b, transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.449f,0.449f,0.449f]} }
execute if entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^-0.7 ^2.25 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f, Tags:["ec.gs_menu_el","ec.gs_view_nav_right_txt"], billboard:"center", text:{text:">",color:"gray",bold:true}, background:1, shadow:1b, transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.449f,0.449f,0.449f]} }
execute unless entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^ ^2.35 ^1.8 positioned ^-0.7 ^0 ^0 run summon interaction ~ ~ ~ { Tags:["ec.gs_menu_el","ec.gs_view_nav_right"], width:0.2f, height:0.12f, response:1b }
execute if entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^ ^2.15 ^1.8 positioned ^-0.7 ^0 ^0 run summon interaction ~ ~ ~ { Tags:["ec.gs_menu_el","ec.gs_view_nav_right"], width:0.2f, height:0.12f, response:1b }

# Spawn [Close] button (shared shell — always visible at bottom)
execute unless entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^ ^0.95 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f, Tags:["ec.gs_menu_el","ec.gs_close_txt"], billboard:"center", text:[{text:"[ ",color:"dark_gray"},{text:"Close",color:"gray",bold:true},{text:" ]",color:"dark_gray"}], background:1, shadow:1b, transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.385f,0.385f,0.385f]} }
execute if entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^ ^0.75 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f, Tags:["ec.gs_menu_el","ec.gs_close_txt"], billboard:"center", text:[{text:"[ ",color:"dark_gray"},{text:"Close",color:"gray",bold:true},{text:" ]",color:"dark_gray"}], background:1, shadow:1b, transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.385f,0.385f,0.385f]} }
# [strip] ec.gs_menu_el: 0.4w split into 4 x 0.12 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute unless entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^-0.14 ^0.85 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.gs_menu_el","ec.gs_close_btn"], width:0.12f,height:0.12f, response:1b }
execute unless entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^-0.0467 ^0.85 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.gs_menu_el","ec.gs_close_btn"], width:0.12f,height:0.12f, response:1b }
execute unless entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^0.0467 ^0.85 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.gs_menu_el","ec.gs_close_btn"], width:0.12f,height:0.12f, response:1b }
execute unless entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^0.14 ^0.85 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.gs_menu_el","ec.gs_close_btn"], width:0.12f,height:0.12f, response:1b }
# [strip] ec.gs_menu_el: 0.4w split into 4 x 0.12 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute if entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^-0.14 ^0.65 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.gs_menu_el","ec.gs_close_btn"], width:0.12f,height:0.12f, response:1b }
execute if entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^-0.0467 ^0.65 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.gs_menu_el","ec.gs_close_btn"], width:0.12f,height:0.12f, response:1b }
execute if entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^0.0467 ^0.65 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.gs_menu_el","ec.gs_close_btn"], width:0.12f,height:0.12f, response:1b }
execute if entity @s[tag=ec.menu_sneak_open] rotated ~ 0 positioned ^0.14 ^0.65 ^1.8 run summon interaction ~ ~ ~ { Tags:["ec.gs_menu_el","ec.gs_close_btn"], width:0.12f,height:0.12f, response:1b }

# Populate the destination list based on initial view
execute if score @s ec.gs_view matches 1 run function evercraft:guidestone/menu/refresh
execute if score @s ec.gs_view matches 4 run function evercraft:guidestone/menu/refresh_guild
# Update title if starting on View 4 (anchor context \u2014 title sits at the anchor)
execute if score @s ec.gs_view matches 4 as @e[type=text_display,tag=ec.gs_menu_title,distance=..5,limit=1] run data modify entity @s text set value [{text:"\u2726 ",color:"dark_purple"},{text:"Guild Network",color:"dark_purple",bold:true},{text:" \u2726",color:"dark_purple"}]

# Sound

# Session isolation — mint a fresh id, then stamp it onto every element. Re-stamping is
# factored into menu/stamp_session so the tick can adopt elements spawned after open
# (view-switch / page-nav) — see that file's header.
scoreboard players add #gui_session ec.var 1
scoreboard players operation @s adv.gui_session = #gui_session ec.var
function evercraft:guidestone/menu/stamp_session

execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.amethyst_block.step master @s ~ ~ ~ 0.8 1.2

# Sneak-position polish cleanup
tag @s remove ec.menu_sneak_open
