# Guidestone Menu — Place a single interdimensional row at the correct position
# Macro args: row (slot 0-9), name (string)
# Run as the player in menu
# Same positioning as place_row but calls place_row_exec_interdim for dim-labeled text
#
# Two-column layout (2026-06-19): slots 0-4 = left column, 5-9 = right column.
# X uses caret ^ (opener-yaw, screen-horizontal) so the columns stay side-by-side at any
# facing; Y uses world ~ (screen-vertical). See place_row for the full geometry notes.

$data modify storage evercraft:guidestone row_display.name set value '$(name)'
$scoreboard players set #gs_placing ec.gs_temp $(row)

# Left column (slots 0-4)
execute if score #gs_placing ec.gs_temp matches 0 at @e[type=item_display,tag=ec.gs_menu_bg,distance=..5,limit=1] positioned ~ ~0.3 ~-0.02 positioned ^0.85 ^0 ^0 run function evercraft:guidestone/menu/place_row_exec_interdim
execute if score #gs_placing ec.gs_temp matches 1 at @e[type=item_display,tag=ec.gs_menu_bg,distance=..5,limit=1] positioned ~ ~0.15 ~-0.02 positioned ^0.85 ^0 ^0 run function evercraft:guidestone/menu/place_row_exec_interdim
execute if score #gs_placing ec.gs_temp matches 2 at @e[type=item_display,tag=ec.gs_menu_bg,distance=..5,limit=1] positioned ~ ~0 ~-0.02 positioned ^0.85 ^0 ^0 run function evercraft:guidestone/menu/place_row_exec_interdim
execute if score #gs_placing ec.gs_temp matches 3 at @e[type=item_display,tag=ec.gs_menu_bg,distance=..5,limit=1] positioned ~ ~-0.15 ~-0.02 positioned ^0.85 ^0 ^0 run function evercraft:guidestone/menu/place_row_exec_interdim
execute if score #gs_placing ec.gs_temp matches 4 at @e[type=item_display,tag=ec.gs_menu_bg,distance=..5,limit=1] positioned ~ ~-0.3 ~-0.02 positioned ^0.85 ^0 ^0 run function evercraft:guidestone/menu/place_row_exec_interdim
# Right column (slots 5-9)
execute if score #gs_placing ec.gs_temp matches 5 at @e[type=item_display,tag=ec.gs_menu_bg,distance=..5,limit=1] positioned ~ ~0.3 ~-0.02 positioned ^-0.85 ^0 ^0 run function evercraft:guidestone/menu/place_row_exec_interdim
execute if score #gs_placing ec.gs_temp matches 6 at @e[type=item_display,tag=ec.gs_menu_bg,distance=..5,limit=1] positioned ~ ~0.15 ~-0.02 positioned ^-0.85 ^0 ^0 run function evercraft:guidestone/menu/place_row_exec_interdim
execute if score #gs_placing ec.gs_temp matches 7 at @e[type=item_display,tag=ec.gs_menu_bg,distance=..5,limit=1] positioned ~ ~0 ~-0.02 positioned ^-0.85 ^0 ^0 run function evercraft:guidestone/menu/place_row_exec_interdim
execute if score #gs_placing ec.gs_temp matches 8 at @e[type=item_display,tag=ec.gs_menu_bg,distance=..5,limit=1] positioned ~ ~-0.15 ~-0.02 positioned ^-0.85 ^0 ^0 run function evercraft:guidestone/menu/place_row_exec_interdim
execute if score #gs_placing ec.gs_temp matches 9 at @e[type=item_display,tag=ec.gs_menu_bg,distance=..5,limit=1] positioned ~ ~-0.3 ~-0.02 positioned ^-0.85 ^0 ^0 run function evercraft:guidestone/menu/place_row_exec_interdim
