# Guidestone Menu — Open wrapper (player-anchored again, 2026-06-10 GUI pass)
# Run AS the opening player, positioned anywhere within ~4 blocks of the stone.
# The 2026-06-09 W4 block-anchor pilot hung the menu at the STONE's column top — on any
# slope/ledge (stone downhill, player on a rise) the menu rendered in the floor, and on
# raised fixtures it rendered too high. Joseph 2026-06-10: spawn by the PLAYER's current
# height and line of sight — so this opens at the player (menu/open's ^-offsets are
# feet-relative, `rotated ~ 0` flattens pitch). The nav/page-flip fns already carry
# player-relative fallbacks (`unless ec.gui_banchor ... at @s`), so with no anchor placed
# every re-render follows the player too. gui/block_anchor/* stays for future block GUIs.
execute at @s run function evercraft:guidestone/menu/open
