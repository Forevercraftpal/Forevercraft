# Guidestone Menu — Place a single destination row at the correct position
# Macro args: row (slot 0-9), name (string)
# Run as the player in menu
#
# Two-column layout (2026-06-19): slots 0-4 = left column, 5-9 = right column.
# Y (world ~) = row within column (BG pitch 0, so ~Y is screen-vertical).
# X (caret ^) = column offset — caret so it rides the BG's opener-yaw, the SAME axis the
# click-strip in place_row_exec uses (^+x = screen left). World ~X would only line up when
# the player opened facing N/S; caret keeps the two columns side-by-side at any facing.
# Z offset -0.02 brings rows in front of the panel. place_row_exec spawns text at ~ ~ ~ and
# the click strip via caret from this point, so text + hitboxes ride the offset together.

$data modify storage evercraft:guidestone row_display.name set value '$(name)'
$scoreboard players set #gs_placing ec.gs_temp $(row)

# Left column (slots 0-4)
execute if score #gs_placing ec.gs_temp matches 0 at @e[type=item_display,tag=ec.gs_menu_bg,distance=..5,limit=1] positioned ~ ~0.3 ~-0.02 positioned ^0.85 ^0 ^0 run function evercraft:guidestone/menu/place_row_exec
execute if score #gs_placing ec.gs_temp matches 1 at @e[type=item_display,tag=ec.gs_menu_bg,distance=..5,limit=1] positioned ~ ~0.15 ~-0.02 positioned ^0.85 ^0 ^0 run function evercraft:guidestone/menu/place_row_exec
execute if score #gs_placing ec.gs_temp matches 2 at @e[type=item_display,tag=ec.gs_menu_bg,distance=..5,limit=1] positioned ~ ~0 ~-0.02 positioned ^0.85 ^0 ^0 run function evercraft:guidestone/menu/place_row_exec
execute if score #gs_placing ec.gs_temp matches 3 at @e[type=item_display,tag=ec.gs_menu_bg,distance=..5,limit=1] positioned ~ ~-0.15 ~-0.02 positioned ^0.85 ^0 ^0 run function evercraft:guidestone/menu/place_row_exec
execute if score #gs_placing ec.gs_temp matches 4 at @e[type=item_display,tag=ec.gs_menu_bg,distance=..5,limit=1] positioned ~ ~-0.3 ~-0.02 positioned ^0.85 ^0 ^0 run function evercraft:guidestone/menu/place_row_exec
# Right column (slots 5-9)
execute if score #gs_placing ec.gs_temp matches 5 at @e[type=item_display,tag=ec.gs_menu_bg,distance=..5,limit=1] positioned ~ ~0.3 ~-0.02 positioned ^-0.85 ^0 ^0 run function evercraft:guidestone/menu/place_row_exec
execute if score #gs_placing ec.gs_temp matches 6 at @e[type=item_display,tag=ec.gs_menu_bg,distance=..5,limit=1] positioned ~ ~0.15 ~-0.02 positioned ^-0.85 ^0 ^0 run function evercraft:guidestone/menu/place_row_exec
execute if score #gs_placing ec.gs_temp matches 7 at @e[type=item_display,tag=ec.gs_menu_bg,distance=..5,limit=1] positioned ~ ~0 ~-0.02 positioned ^-0.85 ^0 ^0 run function evercraft:guidestone/menu/place_row_exec
execute if score #gs_placing ec.gs_temp matches 8 at @e[type=item_display,tag=ec.gs_menu_bg,distance=..5,limit=1] positioned ~ ~-0.15 ~-0.02 positioned ^-0.85 ^0 ^0 run function evercraft:guidestone/menu/place_row_exec
execute if score #gs_placing ec.gs_temp matches 9 at @e[type=item_display,tag=ec.gs_menu_bg,distance=..5,limit=1] positioned ~ ~-0.3 ~-0.02 positioned ^-0.85 ^0 ^0 run function evercraft:guidestone/menu/place_row_exec
