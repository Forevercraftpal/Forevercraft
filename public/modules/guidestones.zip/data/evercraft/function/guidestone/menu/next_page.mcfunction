# Guidestone Menu — Next page (within current view)
# Run as the interaction entity
data remove entity @s interaction

execute as @a[tag=ec.gs_in_menu,distance=..5,limit=1,sort=nearest] run scoreboard players add @s ec.gs_page 1

# Cap at max pages — need filtered count, not total registry count
# For view 1: rebuild same-dim filtered list to get count
# For view 2: rebuild interdim filtered list to get count
# Default: use full registry count
execute as @a[tag=ec.gs_in_menu,distance=..5,limit=1,sort=nearest] at @s if score @s ec.gs_view matches 1 run function evercraft:guidestone/menu/count_filtered_local
execute as @a[tag=ec.gs_in_menu,distance=..5,limit=1,sort=nearest] at @s if score @s ec.gs_view matches 2 run function evercraft:guidestone/menu/count_filtered_interdim

# Cap page at max — ceil(count / 10) with 10 entries per page
scoreboard players add #gs_max ec.gs_temp 9
scoreboard players set #10 ec.gs_temp 10
scoreboard players operation #gs_max ec.gs_temp /= #10 ec.gs_temp
execute as @a[tag=ec.gs_in_menu,distance=..5,limit=1,sort=nearest] run scoreboard players operation @s ec.gs_page < #gs_max ec.gs_temp

# Dispatch refresh based on current view
# GUI-anchor (2026-06-09 sweep): re-render from the stationary block-anchor
# marker (stored yaw, pitch 0) — NOT the player, who may have moved/turned.
# Player-positioned fallback when the marker is missing.
execute as @a[tag=ec.gs_in_menu,distance=..5,limit=1,sort=nearest] at @e[type=marker,tag=ec.gui_banchor,distance=..8,limit=1,sort=nearest] if score @s ec.gs_view matches 1 run function evercraft:guidestone/menu/refresh
execute as @a[tag=ec.gs_in_menu,distance=..5,limit=1,sort=nearest] at @e[type=marker,tag=ec.gui_banchor,distance=..8,limit=1,sort=nearest] if score @s ec.gs_view matches 2 run function evercraft:guidestone/menu/refresh_interdim
execute unless entity @e[type=marker,tag=ec.gui_banchor,distance=..8] as @a[tag=ec.gs_in_menu,distance=..5,limit=1,sort=nearest] at @s if score @s ec.gs_view matches 1 run function evercraft:guidestone/menu/refresh
execute unless entity @e[type=marker,tag=ec.gui_banchor,distance=..8] as @a[tag=ec.gs_in_menu,distance=..5,limit=1,sort=nearest] at @s if score @s ec.gs_view matches 2 run function evercraft:guidestone/menu/refresh_interdim
