# Guidestone Menu — Close
# Run as the player

# Menu Core: Y-displacement close anchor
tag @s remove ec.menu_active
scoreboard players reset @s ec.menu_open_y

tag @s remove ec.gs_in_menu
tag @s remove ec.gs_wormhole_view
tag @s remove ec.gs_remote_menu
scoreboard players set @s ec.gs_page 0
scoreboard players set @s ec.gs_view 0

scoreboard players operation #gui_check ec.temp = @s adv.gui_session

# Re-enable the guidestone interaction entity. GUI-anchor (2026-06-09 sweep):
# primary path routes through the session's block-anchor marker — the menu
# lives at the STONE, which can be ~4.5 from the player at close time. The
# player-proximity line stays as fallback for marker-less sessions (idempotent).
execute as @e[type=marker,tag=ec.gui_banchor,distance=..8] if score @s adv.gui_session = #gui_check ec.temp at @s run data modify entity @e[type=interaction,tag=ec.gs_interact,distance=..5,limit=1] height set value 0.6f
execute at @s run data modify entity @e[type=interaction,tag=ec.gs_interact,distance=..5,limit=1] height set value 0.6f

# Kill this session's menu elements — anchor-routed sweep first (this also
# reaps the marker itself: it carries ec.gs_menu_el + the session stamp), then
# the old player-proximity lines as fallback for marker-less sessions.
execute as @e[type=marker,tag=ec.gui_banchor,distance=..8] if score @s adv.gui_session = #gui_check ec.temp at @s as @e[tag=ec.gs_menu_el,distance=..6] if score @s adv.gui_session = #gui_check ec.temp run kill @s
execute as @e[type=text_display,tag=ec.gs_menu_el,distance=..5] if score @s adv.gui_session = #gui_check ec.temp run kill @s
execute as @e[type=interaction,tag=ec.gs_menu_el,distance=..5] if score @s adv.gui_session = #gui_check ec.temp run kill @s
execute as @e[type=item_display,tag=ec.gs_menu_el,distance=..5] if score @s adv.gui_session = #gui_check ec.temp run kill @s

# Revoke use_lodestone advancement so it can re-trigger on next right-click
advancement revoke @s only evercraft:guidestone/use_lodestone

# Clear menu context from storage
data remove storage evercraft:guidestone menu_ctx
data remove storage eden:temp pd_remote

execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.amethyst_block.hit master @s ~ ~ ~ 0.6 0.8
