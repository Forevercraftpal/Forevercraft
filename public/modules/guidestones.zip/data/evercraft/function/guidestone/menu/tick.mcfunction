# Guidestone Menu — Tick (runs every 1s for players with menu open)
# Run as player at their position

# Close if too far from guidestone (normal) or too far from menu background (remote Portal Dial)
execute unless entity @s[tag=ec.gs_remote_menu] unless entity @e[type=marker,tag=ec.gs_registered,distance=..5] run function evercraft:guidestone/menu/close
execute if entity @s[tag=ec.gs_remote_menu] unless entity @e[type=item_display,tag=ec.gs_menu_bg,distance=..5] run function evercraft:guidestone/menu/close
execute unless entity @s[tag=ec.gs_in_menu] run return 0

# Adopt any elements spawned since open (view-switch / page-nav spawn them UNSTAMPED, which
# made their click-gates + the close sweep skip them — dead Wormhole confirm, orphaned lines).
# Idempotent; runs before any click check below so this tick's clicks see stamped elements.
function evercraft:guidestone/menu/stamp_session

# Auto-close after 20 seconds of inactivity
scoreboard players add @s ec.gs_menu_time 1
execute if score @s ec.gs_menu_time matches 20.. run function evercraft:guidestone/menu/close
execute unless entity @s[tag=ec.gs_in_menu] run return 0

# Check close button click (shared shell, all views)
# Reset flag first — if no close button exists, store success won't fire and stale value persists
scoreboard players set #gs_close ec.gs_temp 0
scoreboard players operation #gui_check ec.temp = @s adv.gui_session

# Unified UI-click FX (Joseph 2026-06-05): every guidestone menu interaction (incl. close) carries
# ec.gs_menu_el. Fire the gated cue ONCE here — before the close-button consume below — so close also blips.
execute if entity @e[type=interaction,tag=ec.gs_menu_el,distance=..6,nbt={interaction:{}},limit=1] run function evercraft:fx/ui/click

execute store success score #gs_close ec.gs_temp as @e[type=interaction,tag=ec.gs_close_btn,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction run data remove entity @s interaction
execute if score #gs_close ec.gs_temp matches 1 run function evercraft:guidestone/menu/close
execute unless entity @s[tag=ec.gs_in_menu] run return 0

# Reset inactivity timer if any menu button was clicked this tick (check before handlers consume the data)
execute as @e[type=interaction,tag=ec.gs_menu_el,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction run scoreboard players set @a[predicate=evercraft:guidestone/menu/check_menu_session,limit=1] ec.gs_menu_time 0

# Always check view navigation clicks (shared shell, all views)
execute as @e[type=interaction,tag=ec.gs_view_nav_left,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction on target run function evercraft:guidestone/menu/view_prev
execute as @e[type=interaction,tag=ec.gs_view_nav_left,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=ec.gs_view_nav_right,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction on target run function evercraft:guidestone/menu/view_next
execute as @e[type=interaction,tag=ec.gs_view_nav_right,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction run data remove entity @s interaction

# Dispatch to correct view handler
execute if score @s ec.gs_view matches 1 run function evercraft:guidestone/menu/tick_network
execute if score @s ec.gs_view matches 2 run function evercraft:guidestone/menu/tick_interdim
execute if score @s ec.gs_view matches 3 run function evercraft:guidestone/menu/tick_wormhole
execute if score @s ec.gs_view matches 4 run function evercraft:guidestone/menu/tick_guild

# ===== INSPECT (left-click = what does this button do?) — gui/inspect pattern 2026-06-11 =====
# Shared here rather than per-view: the slot/nav tags are reused by every view, and the
# copy holds for all of them (every destination line is a warp).
execute as @e[type=interaction,tag=ec.gs_close_btn,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Close",b:"Closes the guidestone menu."}
execute as @e[type=interaction,tag=ec.gs_close_btn,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=ec.gs_view_nav_left,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Previous View",b:"Right-click to cycle back through the guidestone views: Network → Guild → Wormhole → Interdimensional → Network."}
execute as @e[type=interaction,tag=ec.gs_view_nav_left,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=ec.gs_view_nav_right,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Next View",b:"Right-click to cycle forward through the guidestone views: Network → Interdimensional → Wormhole → Guild → Network."}
execute as @e[type=interaction,tag=ec.gs_view_nav_right,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=ec.gs_slot0,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"First Destination",b:"Right-click to warp to the first destination on this page (row 1). The place name is on the row label."}
execute as @e[type=interaction,tag=ec.gs_slot0,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=ec.gs_slot1,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Second Destination",b:"Right-click to warp to the second destination on this page (row 2). The place name is on the row label."}
execute as @e[type=interaction,tag=ec.gs_slot1,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=ec.gs_slot2,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Third Destination",b:"Right-click to warp to the third destination on this page (row 3). The place name is on the row label."}
execute as @e[type=interaction,tag=ec.gs_slot2,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=ec.gs_slot3,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Fourth Destination",b:"Right-click to warp to the fourth destination on this page (row 4). The place name is on the row label."}
execute as @e[type=interaction,tag=ec.gs_slot3,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=ec.gs_slot4,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Fifth Destination",b:"Right-click to warp to the fifth destination on this page (row 5). The place name is on the row label."}
execute as @e[type=interaction,tag=ec.gs_slot4,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=ec.gs_slot5,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Sixth Destination",b:"Right-click to warp to the sixth destination on this page (row 6). The place name is on the row label."}
execute as @e[type=interaction,tag=ec.gs_slot5,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=ec.gs_slot6,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Seventh Destination",b:"Right-click to warp to the seventh destination on this page (row 7). The place name is on the row label."}
execute as @e[type=interaction,tag=ec.gs_slot6,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=ec.gs_slot7,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Eighth Destination",b:"Right-click to warp to the eighth destination on this page (row 8). The place name is on the row label."}
execute as @e[type=interaction,tag=ec.gs_slot7,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=ec.gs_slot8,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Ninth Destination",b:"Right-click to warp to the ninth destination on this page. The place name is on the row label."}
execute as @e[type=interaction,tag=ec.gs_slot8,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=ec.gs_slot9,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Tenth Destination",b:"Right-click to warp to the tenth destination on this page. The place name is on the row label."}
execute as @e[type=interaction,tag=ec.gs_slot9,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=ec.gs_nav_prev,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Previous Page",b:"Flips to the previous page of destinations."}
execute as @e[type=interaction,tag=ec.gs_nav_prev,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=ec.gs_nav_next,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Next Page",b:"Flips to the next page of destinations."}
execute as @e[type=interaction,tag=ec.gs_nav_next,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=ec.gs_prime_btn,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Prime Key",b:"Absorbs an Ancient Netherite Core from your inventory to prime this guidestone."}
execute as @e[type=interaction,tag=ec.gs_prime_btn,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=ec.gs_wh_confirm,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Confirm Wormhole",b:"Executes the wormhole — teleports you to the marked spot."}
execute as @e[type=interaction,tag=ec.gs_wh_confirm,distance=..5] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack run data remove entity @s attack
