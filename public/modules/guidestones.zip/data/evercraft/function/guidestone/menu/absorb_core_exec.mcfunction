# Guidestone Menu — Execute core absorption
# Run as: the player with menu open

# Already primed? Show notification and stop
execute if data storage evercraft:guidestone {menu_ctx:{primed:1b}} if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 0.8 0.5
data modify storage evercraft:notify stage.c set value [{text:"This guidestone has already broken through the barrier between dimensions.",color:"light_purple",italic:true}]
scoreboard players set #ndur ec.temp 45
execute if data storage evercraft:guidestone {menu_ctx:{primed:1b}} run return run function evercraft:util/notify/emit

# Check for Ancient Netherite Core anywhere on the player using clear count 0 (reliable detection)
execute store success score #gs_has_core ec.gs_temp run clear @s minecraft:stick[custom_data~{ancient_netherite_core:1b}] 0
execute if score #gs_has_core ec.gs_temp matches 1 run return run function evercraft:guidestone/menu/do_absorb

# No core found
data modify storage evercraft:notify stage.c set value [{text:"The guidestone seemingly can't pass the barrier... ",color:"gray",italic:true},{text:"this looks like a slot for something...",color:"dark_purple",italic:true}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 0.8 0.5
