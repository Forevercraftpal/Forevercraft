# Guidestone Menu — Stamp the live session id onto any menu elements that lack it
# Run AS the player (carries adv.gui_session), positioned at them (distance=..5 matches every
# click-gate and the close sweep). Idempotent — `unless ... matches 1..` skips already-stamped
# elements, so it's safe to re-run every tick.
#
# Why this exists: open.mcfunction only stamps the elements that exist at open time. Anything
# spawned LATER — switch_view -> wormhole/show, page-nav refresh, interdim/guild views — was
# never stamped, so its click-handlers (`if score @s adv.gui_session = #gui_check`) silently
# skipped it (dead Wormhole confirm = no teleport, just the ungated click blip looping) and the
# close sweep left its text lines orphaned. Re-running this each tick adopts them into the session.
scoreboard players operation #gui_stamp ec.temp = @s adv.gui_session
execute as @e[type=text_display,tag=ec.gs_menu_el,distance=..5] unless score @s adv.gui_session matches 1.. run scoreboard players operation @s adv.gui_session = #gui_stamp ec.temp
execute as @e[type=item_display,tag=ec.gs_menu_el,distance=..5] unless score @s adv.gui_session matches 1.. run scoreboard players operation @s adv.gui_session = #gui_stamp ec.temp
execute as @e[type=interaction,tag=ec.gs_menu_el,distance=..5] unless score @s adv.gui_session matches 1.. run scoreboard players operation @s adv.gui_session = #gui_stamp ec.temp
execute as @e[type=marker,tag=ec.gui_banchor,distance=..5] unless score @s adv.gui_session matches 1.. run scoreboard players operation @s adv.gui_session = #gui_stamp ec.temp
