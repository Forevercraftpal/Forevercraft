# Guidestone Menu — Spawn a single destination row (recursive)
# Uses #gs_row (slot 0-9, 2 columns) for position, #gs_idx for registry index

# Stop if we've placed 10 slots (5 rows x 2 cols) or run out of entries
execute if score #gs_row ec.gs_temp matches 10.. run return 0
execute unless data storage evercraft:guidestone working[0] run return 0

# Skip entries before our offset
execute if score #gs_idx ec.gs_temp matches 1.. run data remove storage evercraft:guidestone working[0]
execute if score #gs_idx ec.gs_temp matches 1.. run scoreboard players remove #gs_idx ec.gs_temp 1
execute if score #gs_idx ec.gs_temp matches 1.. run return run function evercraft:guidestone/menu/spawn_row

# Read the current entry
data modify storage evercraft:guidestone current set from storage evercraft:guidestone working[0]
data remove storage evercraft:guidestone working[0]

# Build the display text and store to temp for macro
data modify storage evercraft:guidestone row_args.name set from storage evercraft:guidestone current.name
data modify storage evercraft:guidestone row_args.row set value 0
execute store result storage evercraft:guidestone row_args.row int 1 run scoreboard players get #gs_row ec.gs_temp

# Call the macro spawner to place the row
function evercraft:guidestone/menu/place_row with storage evercraft:guidestone row_args

# Advance to next row
scoreboard players add #gs_row ec.gs_temp 1

# Recurse
function evercraft:guidestone/menu/spawn_row
