# Guidestone — Interaction detected (right-click on guidestone)
# Run as: the interaction entity, at its position
# The interaction data contains the player who clicked

# Clear the interaction data so it can fire again
data remove entity @s interaction

# --- Dye intercept ---
execute as @p[distance=..6] if items entity @s weapon.mainhand #evercraft:dyes run return run function evercraft:guidestone/dye_block
execute as @p[distance=..6] if items entity @s weapon.mainhand minecraft:water_bucket run return run function evercraft:guidestone/wash_block

# Find the nearest registered guidestone marker (should be within 2 blocks)
execute unless entity @e[type=marker,tag=ec.gs_registered,distance=..2] run return 0

# If the nearest player is already in a menu, ignore the click entirely
execute if entity @p[distance=..6,tag=ec.gs_in_menu] run return 0

# --- Portal Dial binding intercept ---
# If the nearest player holds a Portal Dial, bind it to this guidestone instead of opening the menu
execute as @p[distance=..6,tag=!ec.gs_in_menu] if items entity @s weapon.mainhand compass[custom_data~{portal_dial:true}] at @s run return run function evercraft:portal_dial/bind_guidestone {hand:"mainhand"}
execute as @p[distance=..6,tag=!ec.gs_in_menu] if items entity @s weapon.offhand compass[custom_data~{portal_dial:true}] at @s run return run function evercraft:portal_dial/bind_guidestone {hand:"offhand"}

# --- Normal menu open ---

# Open the menu for the nearest player (who clicked — up to 6 blocks, tick delay can cause movement)
# GUI-anchor (2026-06-09 sweep, W4): stationary at the stone via the wrapper.
# Position context stays at this interaction entity (i.e. the stone) so the
# wrapper's gs_marker search starts right next to it.
execute as @p[distance=..6,tag=!ec.gs_in_menu] run function evercraft:guidestone/menu/open_anchored
