# ============================================================
# UX ADDITION 3 — Guidestone Deed: give the writable book to NAME a just-
# placed guidestone (the portal-network block, NOT a hearthstone).
# Run as: @s = the placing player (the ec.gs_registrant).
# INPUT: #gs_deed_id ec.gs_temp = the gs_id of the registry entry to name.
#
# Mirrors the housing Home Deed flow, but the book's custom_data carries a
# DIFFERENT discriminator so the shared signed-deed extract knows where to
# write the name:
#   Home Deed       -> custom_data {hs_deed:1b, slot:<N>}   (per-player slot)
#   Guidestone Deed -> custom_data {gs_deed:1b, gs_id:<ID>} (global registry id)
# Both share the evercraft:housing/signed_deed advancement (same written_book
# inventory trigger); extract branches on which key is present.
# ============================================================

# Bake the target gs_id into the book via a macro (custom_data can't read a
# score directly, so stage it through storage first).
execute store result storage evercraft:guidestone deed_arg.gs_id int 1 run scoreboard players get #gs_deed_id ec.gs_temp
function evercraft:guidestone/give_deed_macro with storage evercraft:guidestone deed_arg

# Prompt the player to write + sign.
data modify storage evercraft:notify stage.c set value [{text:"Write this guidestone's name on page 1 of the deed and ",color:"yellow"},{text:"sign it",color:"green",bold:true},{text:" to label it on the network!",color:"yellow"}]
scoreboard players set #ndur ec.temp 60
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.experience_orb.pickup master @s ~ ~ ~ 0.5 1.5
