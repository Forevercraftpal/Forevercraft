# Guidestone — Wash Block (right-click with water bucket)
# Removes dye and restores default appearance
# Run as: player, at: interaction entity position

# Reset marker color to default
execute as @e[type=marker,tag=ec.gs_marker,distance=..2,limit=1] run data modify entity @s data.color set value "amethyst"

# Reset display skin to default
execute as @e[type=armor_stand,tag=ec.gs_stand,distance=..2,limit=1] on passengers run data modify entity @s item.components."minecraft:profile".properties[0].value set value "ewogICJ0aW1lc3RhbXAiIDogMTc3MzUzODc0MjM0NSwKICAicHJvZmlsZUlkIiA6ICIyNDY1ODI2NWVjMjg0NTY4YTg3MDJkOTVlYzdlYTc4MyIsCiAgInByb2ZpbGVOYW1lIiA6ICJBcmdvc1oxMiIsCiAgInNpZ25hdHVyZVJlcXVpcmVkIiA6IHRydWUsCiAgInRleHR1cmVzIiA6IHsKICAgICJTS0lOIiA6IHsKICAgICAgInVybCIgOiAiaHR0cDovL3RleHR1cmVzLm1pbmVjcmFmdC5uZXQvdGV4dHVyZS83OThhNGExOWM1ZDRjNzJiYzI1MjFlYmI5NzQ2MzRkYWJhMWNlZTczNjZlYjk1NWRmMzYwZWY3YzY4MDNkOTNjIiwKICAgICAgIm1ldGFkYXRhIiA6IHsKICAgICAgICAibW9kZWwiIDogInNsaW0iCiAgICAgIH0KICAgIH0KICB9Cn0="

# Effects
playsound minecraft:item.bucket.empty master @a[distance=..16,scores={ec.fx_snd=1..}] ~ ~ ~ 1 1.2
particle minecraft:splash ~0.5 ~1.0 ~0.5 0.3 0.2 0.3 0.05 12

# Feedback
data modify storage evercraft:notify stage.c set value [{text:"Washed ",color:"gray",italic:true},{text:"Guidestone",color:"#E0B0FF",italic:true},{text:" back to default",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
