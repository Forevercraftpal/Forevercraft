# Guidestone Wormhole — Show the wormhole confirmation screen
# Run as the player with menu open, at their position
# Slot elements are already killed by switch_view before this is called

# Check if player has enough levels
execute unless score @s ec.gs_temp matches 30.. store result score @s ec.gs_temp run experience query @s levels

# Anchor all elements to the background entity so they stay centered
# Background is at Y=center of panel; text spawns at Y offsets from it
# Z offset -0.02 brings text slightly in front of the background panel

# Spawn description lines (no duplicate title — shared shell title already says "Wormhole")
execute at @e[type=item_display,tag=ec.gs_menu_bg,distance=..8,limit=1] positioned ~ ~0.30 ~-0.02 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f, Tags:["ec.gs_menu_el","ec.gs_slot_el"], billboard:"center", text:{text:"Tear a hole through space itself",color:"gray",italic:true}, background:1, shadow:1b, transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.321f,0.321f,0.321f]} }

execute at @e[type=item_display,tag=ec.gs_menu_bg,distance=..8,limit=1] positioned ~ ~0.20 ~-0.02 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f, Tags:["ec.gs_menu_el","ec.gs_slot_el"], billboard:"center", text:{text:"and emerge somewhere far, far away...",color:"gray",italic:true}, background:1, shadow:1b, transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.321f,0.321f,0.321f]} }

# Cost display
execute at @e[type=item_display,tag=ec.gs_menu_bg,distance=..8,limit=1] positioned ~ ~0.05 ~-0.02 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f, Tags:["ec.gs_menu_el","ec.gs_slot_el"], billboard:"center", text:[{text:"Cost: ",color:"gray"},{text:"30 Levels",color:"green",bold:true}], background:1, shadow:1b, transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.321f,0.321f,0.321f]} }

# Warning
execute at @e[type=item_display,tag=ec.gs_menu_bg,distance=..8,limit=1] positioned ~ ~-0.10 ~-0.02 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f, Tags:["ec.gs_menu_el","ec.gs_slot_el"], billboard:"center", text:{text:"Before you go, are you sure",color:"gold"}, background:1, shadow:1b, transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.321f,0.321f,0.321f]} }

execute at @e[type=item_display,tag=ec.gs_menu_bg,distance=..8,limit=1] positioned ~ ~-0.18 ~-0.02 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f, Tags:["ec.gs_menu_el","ec.gs_slot_el"], billboard:"center", text:{text:"you have a way back?",color:"gold"}, background:1, shadow:1b, transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.321f,0.321f,0.321f]} }

# "Yes, Warp Me!" button
execute at @e[type=item_display,tag=ec.gs_menu_bg,distance=..8,limit=1] positioned ~ ~-0.35 ~-0.02 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f, Tags:["ec.gs_menu_el","ec.gs_slot_el","ec.gs_wh_yes_txt"], billboard:"center", text:[{text:"[ ",color:"dark_purple"},{text:"Yes, Warp Me!",color:"light_purple",bold:true},{text:" ]",color:"dark_purple"}], background:1, shadow:1b, transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.385f,0.385f,0.385f]} }
# [strip] 1.0w split into 9 x 0.12 cubes via caret chain (GUI-plane x; anchor carries yaw, pitch 0)
execute at @e[type=item_display,tag=ec.gs_menu_bg,distance=..8,limit=1] positioned ~ ~-0.47 ~ positioned ^-0.44 ^0 ^0 run summon interaction ~ ~ ~ { Tags:["ec.gs_menu_el","ec.gs_slot_el","ec.gs_wh_confirm"], width:0.12f,height:0.12f, response:1b }
execute at @e[type=item_display,tag=ec.gs_menu_bg,distance=..8,limit=1] positioned ~ ~-0.47 ~ positioned ^-0.33 ^0 ^0 run summon interaction ~ ~ ~ { Tags:["ec.gs_menu_el","ec.gs_slot_el","ec.gs_wh_confirm"], width:0.12f,height:0.12f, response:1b }
execute at @e[type=item_display,tag=ec.gs_menu_bg,distance=..8,limit=1] positioned ~ ~-0.47 ~ positioned ^-0.22 ^0 ^0 run summon interaction ~ ~ ~ { Tags:["ec.gs_menu_el","ec.gs_slot_el","ec.gs_wh_confirm"], width:0.12f,height:0.12f, response:1b }
execute at @e[type=item_display,tag=ec.gs_menu_bg,distance=..8,limit=1] positioned ~ ~-0.47 ~ positioned ^-0.11 ^0 ^0 run summon interaction ~ ~ ~ { Tags:["ec.gs_menu_el","ec.gs_slot_el","ec.gs_wh_confirm"], width:0.12f,height:0.12f, response:1b }
execute at @e[type=item_display,tag=ec.gs_menu_bg,distance=..8,limit=1] positioned ~ ~-0.47 ~ positioned ^0 ^0 ^0 run summon interaction ~ ~ ~ { Tags:["ec.gs_menu_el","ec.gs_slot_el","ec.gs_wh_confirm"], width:0.12f,height:0.12f, response:1b }
execute at @e[type=item_display,tag=ec.gs_menu_bg,distance=..8,limit=1] positioned ~ ~-0.47 ~ positioned ^0.11 ^0 ^0 run summon interaction ~ ~ ~ { Tags:["ec.gs_menu_el","ec.gs_slot_el","ec.gs_wh_confirm"], width:0.12f,height:0.12f, response:1b }
execute at @e[type=item_display,tag=ec.gs_menu_bg,distance=..8,limit=1] positioned ~ ~-0.47 ~ positioned ^0.22 ^0 ^0 run summon interaction ~ ~ ~ { Tags:["ec.gs_menu_el","ec.gs_slot_el","ec.gs_wh_confirm"], width:0.12f,height:0.12f, response:1b }
execute at @e[type=item_display,tag=ec.gs_menu_bg,distance=..8,limit=1] positioned ~ ~-0.47 ~ positioned ^0.33 ^0 ^0 run summon interaction ~ ~ ~ { Tags:["ec.gs_menu_el","ec.gs_slot_el","ec.gs_wh_confirm"], width:0.12f,height:0.12f, response:1b }
execute at @e[type=item_display,tag=ec.gs_menu_bg,distance=..8,limit=1] positioned ~ ~-0.47 ~ positioned ^0.44 ^0 ^0 run summon interaction ~ ~ ~ { Tags:["ec.gs_menu_el","ec.gs_slot_el","ec.gs_wh_confirm"], width:0.12f,height:0.12f, response:1b }

# Sound
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.portal.ambient master @s ~ ~ ~ 0.3 1.5
