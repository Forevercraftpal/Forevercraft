# ══════════════════════════════════════════════════════════════
# Guidestone — Pioneer safe space: RESTORE the XP-unlock list (post re-mint)
# Run as @s, from companions/handler/player/new_player, AFTER companion.id has
# been (re)minted. Gated upstream by `if data ... gs_preserve` so this only
# does work when at least one preserve is pending (rare — a recent Pioneer
# death). Builds the lookup args (new pid + real UUID) and dispatches the
# macro, then garbage-collects an emptied gs_preserve root.
# Joseph 2026-06-22. See guidestone/preserve_snapshot.
# ══════════════════════════════════════════════════════════════

execute store result storage evercraft:guidestone gsr.pid int 1 run scoreboard players get @s companion.id
execute store result storage evercraft:guidestone gsr.u0 int 1 run data get entity @s UUID[0]
execute store result storage evercraft:guidestone gsr.u1 int 1 run data get entity @s UUID[1]
execute store result storage evercraft:guidestone gsr.u2 int 1 run data get entity @s UUID[2]
execute store result storage evercraft:guidestone gsr.u3 int 1 run data get entity @s UUID[3]
function evercraft:guidestone/preserve_restore with storage evercraft:guidestone gsr
data remove storage evercraft:guidestone gsr

# Drop the holding root once the last pending preserve has been claimed.
execute if data storage evercraft:guidestone {gs_preserve:{}} run data remove storage evercraft:guidestone gs_preserve
