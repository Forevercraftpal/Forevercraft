# Guidestone — Registration feedback with name
# Macro args: name (from temp)
$data modify storage evercraft:notify stage.c set value [{text:"Registered: ",color:"green"},{text:"$(name)",color:"gold",bold:true},{text:" — Right-click to open the network.",color:"light_purple"}]
scoreboard players set #ndur ec.temp 45
execute as @a[tag=ec.gs_registrant] run function evercraft:util/notify/emit
