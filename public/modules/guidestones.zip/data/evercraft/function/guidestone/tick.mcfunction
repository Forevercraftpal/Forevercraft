# Guidestone System — Tick (1s schedule)
# Handles interaction detection, menu ticks, ambient particles, and break detection

# Self-schedule first so loop never dies
schedule function evercraft:guidestone/tick 1s replace

# Perf retrofit M1 (2026-06-14): skip the whole body with nobody online (still reschedules above).
execute unless entity @a run return 0

# Detect right-click on guidestone interaction entities
execute as @e[type=interaction,tag=ec.gs_interact] at @s if data entity @s interaction run function evercraft:guidestone/on_interact
execute as @e[type=interaction,tag=ec.gs_interact] at @s if data entity @s interaction run data remove entity @s interaction

# Tick open menus (check clicks, distance)
execute as @a[tag=ec.gs_in_menu] at @s run function evercraft:guidestone/menu/tick

# OPT: All marker checks (particles, primed, break) consolidated into 1 entity scan
# Particles proximity-gated (skip if no player within 48 blocks)
# Perf M1: only run the per-marker scan for markers within 64b of a player (break-detection
# only matters where a player could actually break the structure).
execute as @e[type=marker,tag=ec.gs_registered] at @s if entity @a[distance=..64] run function evercraft:guidestone/tick_marker
