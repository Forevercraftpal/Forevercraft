# Guidestone — Pioneer safe space: re-key one player's preserved unlock list.
# Macro args: {pid:<new companion.id>, u0,u1,u2,u3:<player UUID ints>}. Run as @s.
# No-op unless THIS player's UUID has a pending preserve. On a hit, pour the
# list back under the new id and clear the holding slot. See preserve_snapshot.
$execute unless data storage evercraft:guidestone gs_preserve."u$(u0)_$(u1)_$(u2)_$(u3)" run return 0
$data modify storage evercraft:guidestone unlocked."$(pid)" set from storage evercraft:guidestone gs_preserve."u$(u0)_$(u1)_$(u2)_$(u3)"
$data remove storage evercraft:guidestone gs_preserve."u$(u0)_$(u1)_$(u2)_$(u3)"
