# Armored Elytra Unmerge — Ender Dragon

data modify storage evercraft:armored_elytra merged_enchants set from entity @s Item.components."minecraft:enchantments"
data modify storage evercraft:armored_elytra merged_trim set from entity @s Item.components."minecraft:trim"

kill @s

loot spawn ~ ~1 ~ loot evercraft:artifacts/mythical/ender_dragon_elytra
loot spawn ~ ~1 ~ loot evercraft:artifacts/mythical/ender_dragon_chestplate

function evercraft:armored_elytra/effects

data modify storage evercraft:notify stage.c set value [{text:"Armored Ender Dragon Wings",color:"gold"},{text:" have been separated back into ",color:"gray"},{text:"Ender Dragon Chestplate",color:"gold"},{text:" and ",color:"gray"},{text:"Ender Dragon Wings",color:"gold"},{text:"!",color:"gray"}]
scoreboard players set #ndur ec.temp 45
execute as @a[distance=..64] run function evercraft:util/notify/emit
