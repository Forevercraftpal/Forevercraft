# === ADVENTURER'S ATLAS — ENSURE PER-PLAYER REGISTRY EXISTS (macro) ===
# Args: storage evercraft:atlas args  (args.UUID = player UUID array).
# Creates storage evercraft:atlas players."<UUID>" = {maps:[],waypoints:[]} if it does not yet exist.
# Idempotent: guarded by an unless-data existence check so an existing registry is never overwritten.
$execute unless data storage evercraft:atlas players."$(UUID)" run data modify storage evercraft:atlas players."$(UUID)" set value {maps:[],waypoints:[]}
