# === ADVENTURER'S ATLAS — STASH THE ATLAS ITEM PER-PLAYER (macro) ===
# Args: storage evercraft:atlas args  ($(UUID) player key). storage evercraft:atlas swapitem = atlas item NBT.
# Saves the borrowed-away atlas under the player's UUID so the restore (or a re-login fallback) can put it
# back even across a hand-off mid-swap. Keyed per-player so two simultaneous swaps never collide.
$data modify storage evercraft:atlas swaps."$(UUID)" set from storage evercraft:atlas swapitem
