# === ADVENTURER'S ATLAS — PLACE A WAYPOINT BANNER ===
# Run as @s = player, SHIFT-RC dispatched from on_use. Places a REAL named banner at the player's feet so
# it persists as a physical waypoint, and records the waypoint {x,z,chunk} in the player's registry. The
# banner is what the vanilla map-on-banner mechanic later turns into an actual map marker (see on_banner).
#
# We only place if the feet block is replaceable (air/grass/etc.) so we never grief a placed block. The
# banner carries a copper CustomName ("Atlas Waypoint") which becomes the marker's name on the vanilla
# map-on-banner add.

execute at @s align xyz unless block ~ ~ ~ #evercraft:atlas/replaceable run return run function evercraft:atlas/cue_blocked

# Place the named banner at the player's feet.
execute at @s align xyz run setblock ~ ~ ~ minecraft:white_banner[rotation=8]{CustomName:{"text":"Atlas Waypoint","color":"#B87333","italic":false}} replace

# Record the waypoint {x,z,chunk} into the player's registry (chunk = block >> 4 via /20 int floor is wrong;
# we store raw block x/z + a derived chunk key for dedupe). Build flat args then dedupe-append via macro.
data modify storage evercraft:atlas args.UUID set from entity @s UUID
execute store result storage evercraft:atlas args.wx int 1 run data get entity @s Pos[0]
execute store result storage evercraft:atlas args.wz int 1 run data get entity @s Pos[2]
function evercraft:atlas/wp_chunk
function evercraft:atlas/ensure_player with storage evercraft:atlas args
function evercraft:atlas/wp_dedupe with storage evercraft:atlas args
execute if score #atl_wpdup ec.atlas matches 1 run return run function evercraft:atlas/cue_wp_dup
function evercraft:atlas/wp_append with storage evercraft:atlas args

# Feedback.
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.wool.place master @s ~ ~ ~ 0.9 1.0
execute at @s run particle minecraft:happy_villager ~ ~1 ~ 0.4 0.5 0.4 0.02 14
data modify storage evercraft:notify stage.c set value [{text:"◈ ",color:"#B87333"},{text:"Waypoint banner placed. Right-click it with the Atlas to mark your map.",color:"gray"}]
scoreboard players set #ndur ec.temp 55
function evercraft:util/notify/emit
