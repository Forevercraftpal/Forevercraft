# === ADVENTURER'S ATLAS — DISPATCH RESTORE TO MAINHAND ===
# Routed from swap_restore when mainhand was empty.
function evercraft:atlas/swap_to_hand
data remove storage evercraft:atlas swapout
