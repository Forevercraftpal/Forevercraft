# === ADVENTURER'S ATLAS — DEDUPE A MARKER BY CHUNK (macro) ===
# Args: storage evercraft:atlas args  ($(UUID) player key; $(chx),$(chz) the banner's chunk).
# Sets #atl_mkdup ec.atlas = 1 if a waypoint in this chunk is ALREADY marked (marked:1b) — refuse a
# duplicate marker on the same map at the same chunk (the spec's coords/chunk dedupe).
scoreboard players set #atl_mkdup ec.atlas 0
$execute if data storage evercraft:atlas players."$(UUID)".waypoints[{chx:$(chx),chz:$(chz),marked:1b}] run scoreboard players set #atl_mkdup ec.atlas 1
