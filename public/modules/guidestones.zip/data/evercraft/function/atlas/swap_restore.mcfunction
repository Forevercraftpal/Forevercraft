# === ADVENTURER'S ATLAS — RESTORE THE STASHED ATLAS ITEM (macro) ===
# Args: storage evercraft:atlas args  ($(UUID) player key). Puts the stashed atlas back into the player's
# inventory using slot-aware logic to avoid destroying held items:
#   1. Mainhand empty  -> restore to mainhand  (the common case, atlas was here before swap)
#   2. Else offhand empty -> restore to offhand (player switched hotbar slots; offhand free)
#   3. Else drop at feet  -> spawn item entity with the stashed NBT, instant pickup
# Run as @s = player. Only restores if a stash exists for this player (no-op otherwise — safe re-entry).
# 2026-06-12 fix: prior version unconditionally `item replace`-d weapon.mainhand, destroying whatever the
# player was holding if they switched away from the borrow_map slot during the 8s swap window.

$execute if data storage evercraft:atlas swaps."$(UUID)" run data modify storage evercraft:atlas swapout set from storage evercraft:atlas swaps."$(UUID)"
execute unless data storage evercraft:atlas swapout run return 0

# Mainhand empty -> mainhand. The check is "no item id" which excludes air implicitly.
execute unless data entity @s SelectedItem.id run return run function evercraft:atlas/_swap_route_main

# Else offhand empty -> offhand.
execute unless data entity @s Inventory[{Slot:-106b}].id run return run function evercraft:atlas/_swap_route_off

# Else drop at feet.
function evercraft:atlas/_swap_route_ground
