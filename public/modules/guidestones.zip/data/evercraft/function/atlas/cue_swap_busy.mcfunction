# === ADVENTURER'S ATLAS — "a borrow is already in progress" CUE ===
# Run as @s = player. A map borrow is mid-flight (atlas stashed). Refuse re-entry until restore completes.
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.hat master @s ~ ~ ~ 0.5 1.0
data modify storage evercraft:notify stage.c set value [{text:"◈ ",color:"#B87333"},{text:"The Atlas is busy — finish marking, it returns shortly.",color:"gray"}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit
