# === ADVENTURER'S ATLAS — REGISTER THE OFFHAND MAP ===
# Run as @s = player, NON-SNEAK RC dispatched from on_use. Reads the filled map in the OFFHAND and records
# it into the player's UUID-keyed registry: { map_id, cx, cz, scale }.
#
# FEASIBILITY NOTE (26.1): a filled map's id is the int component minecraft:map_id, READABLE via /data.
# The map's true center_x/center_z/scale live in the world's map_<N>.dat, which is NOT reachable via /data
# (no datapack command exposes map decoration/center data). So the atlas anchors the map's bounds on the
# PLAYER'S POSITION AT REGISTRATION TIME (cx,cz) + a default scale span (1664 blocks ≈ a scale-3 map half-
# width, a forgiving in-bounds radius). "Register while standing roughly at the map's middle" → in-bounds
# selection then picks the registered map whose anchor is nearest/covering the player. This is the best
# feasible approximation given the .dat constraint, and is documented for Joseph in the build report.

scoreboard players set #atl_mid ec.temp -2147483648
execute store result score #atl_mid ec.temp run data get entity @s Inventory[{Slot:-106b}].components."minecraft:map_id"

# No filled map in the offhand (map_id absent) -> soft cue + bail.
execute if score #atl_mid ec.temp matches -2147483648 run return run function evercraft:atlas/cue_no_map

# Build the FLAT macro args object (UUID + map fields) — macro consumers index $(UUID)/$(map_id)/etc.
data modify storage evercraft:atlas args.UUID set from entity @s UUID
execute store result storage evercraft:atlas args.map_id int 1 run scoreboard players get #atl_mid ec.temp
execute store result storage evercraft:atlas args.cx int 1 run data get entity @s Pos[0]
execute store result storage evercraft:atlas args.cz int 1 run data get entity @s Pos[2]
data modify storage evercraft:atlas args.scale set value 1664

# Ensure the player's registry list exists, then dedupe + append via macro.
function evercraft:atlas/ensure_player with storage evercraft:atlas args
function evercraft:atlas/reg_dedupe with storage evercraft:atlas args

# If this map_id was already registered, #atl_dup=1 -> just refresh feedback, don't double-add.
execute if score #atl_dup ec.temp matches 1 run return run function evercraft:atlas/cue_already_reg
function evercraft:atlas/reg_append with storage evercraft:atlas args

# Feedback.
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:item.book.page_turn master @s ~ ~ ~ 0.8 1.2
execute at @s run particle minecraft:wax_on ~ ~1 ~ 0.3 0.3 0.3 0.02 12
data modify storage evercraft:notify stage.c set value [{text:"◈ ",color:"#B87333"},{text:"Map registered to your Atlas.",color:"gray"}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit
