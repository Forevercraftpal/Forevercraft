# === ADVENTURER'S ATLAS — RIGHT-CLICK A BANNER WITH THE ATLAS ===
# Run as @s = player. Fired by atlas/on_banner (item_used_on_block on a #evercraft:atlas/banners block
# while the held item is {adventurers_atlas:true}). Orchestrates the VANILLA map-on-banner marker flow:
#   1. pick the registered map whose bounds cover the player's CURRENT X/Z (in-bounds selection),
#   2. ensure that filled map is in the player's MAINHAND — if not, pull it from offhand / inventory /
#      bundle (mirrors the key_satchel item-pull idiom), stashing the atlas so it can be restored,
#   3. the player then RC's the banner once with the map in hand → VANILLA adds the real marker
#      (datapacks cannot write map_<N>.dat decorations; this is the only feasible real-marker path),
#   4. the atlas is auto-restored to its slot after ~8s via a scheduled restore.
# Dedupe: the marker is refused (and not pulled) if a waypoint already exists in this banner's chunk.

advancement revoke @s only evercraft:atlas/on_banner

# Re-entrancy guard: if a swap is already mid-flight (atlas stashed, restore pending), don't re-pull.
execute if score @s ec.atlas_swap matches 1.. run return run function evercraft:atlas/cue_swap_busy

# Stamp UUID + the banner's chunk into args for in-bounds selection + dedupe.
data modify storage evercraft:atlas args.UUID set from entity @s UUID
execute store result storage evercraft:atlas args.wx int 1 run data get entity @s Pos[0]
execute store result storage evercraft:atlas args.wz int 1 run data get entity @s Pos[2]
function evercraft:atlas/wp_chunk

# Dedupe by chunk: refuse a marker already on the map at this chunk.
function evercraft:atlas/ensure_player with storage evercraft:atlas args
function evercraft:atlas/mark_dedupe with storage evercraft:atlas args
execute if score #atl_mkdup ec.atlas matches 1 run return run function evercraft:atlas/cue_marked

# In-bounds selection: find the registered map covering the player's position -> #atl_mapfound + io.sel.
function evercraft:atlas/pick_inbounds
execute if score #atl_mapfound ec.atlas matches 0 run return run function evercraft:atlas/cue_no_inbounds

# If the in-bounds map is ALREADY in the mainhand, the player can RC the banner directly — just guide them.
# (Init handok=0 first so a stale value from a prior call can't leak through when the hand holds no map.)
scoreboard players set #atl_handok ec.atlas 0
execute if data entity @s SelectedItem.components."minecraft:map_id" run function evercraft:atlas/check_hand_map

# If the hand already holds the right map (set by check_hand_map), we're done — vanilla will mark on next RC.
execute if score #atl_handok ec.atlas matches 1 run return run function evercraft:atlas/cue_ready_mark

# Otherwise pull the in-bounds map into the mainhand from inventory/bundle, stashing the atlas.
function evercraft:atlas/pull_map
