# === ADVENTURER'S ATLAS — AUTO-PULL THE IN-BOUNDS MAP INTO THE MAINHAND ===
# Run as @s = player. The in-bounds map (sel.map_id, score #atl_selmap) is NOT in the player's hand. Verify
# the player actually OWNS that map somewhere (inventory OR inside a bundle), then borrow it into the
# mainhand: stash the atlas item to per-player swap storage, mint a temporary filled_map bound to that
# map_id into the mainhand, set ec.atlas_swap, and schedule the restore (~8s) that puts the atlas back and
# clears the borrowed map. This mirrors the key_satchel/satchel inventory+bundle item-pull idiom while
# staying non-destructive (a temporary borrow, not a permanent extraction from the bundle's contents NBT).

# --- Ownership check: the selected map must exist in inventory or in a bundle's contents. ---
scoreboard players set #atl_own ec.atlas 0
function evercraft:atlas/scan_inv with storage evercraft:atlas sel
execute if score #atl_own ec.atlas matches 0 run return run function evercraft:atlas/cue_no_owned_map

# --- Stash the atlas (from whichever held slot holds it) into per-player swap storage. ---
scoreboard players set @s ec.atlas_slot 0
execute if items entity @s weapon.mainhand *[custom_data~{adventurers_atlas:true}] run scoreboard players set @s ec.atlas_slot 0
execute if items entity @s weapon.offhand *[custom_data~{adventurers_atlas:true}] run scoreboard players set @s ec.atlas_slot 1

# Capture the atlas item NBT to UUID-keyed swap storage so a hand-off mid-swap can't lose it.
data modify storage evercraft:atlas args.UUID set from entity @s UUID
execute if score @s ec.atlas_slot matches 0 run data modify storage evercraft:atlas swapitem set from entity @s weapon.mainhand
execute if score @s ec.atlas_slot matches 1 run data modify storage evercraft:atlas swapitem set from entity @s weapon.offhand
function evercraft:atlas/swap_store with storage evercraft:atlas args

# --- Mint the borrowed map into the mainhand (replacing the atlas there). ---
# The atlas always borrows into the MAINHAND so the player can immediately RC the banner to mark it.
execute store result storage evercraft:atlas mint.map_id int 1 run scoreboard players get #atl_selmap ec.atlas
function evercraft:atlas/mint_map with storage evercraft:atlas mint

# --- Flag the swap + schedule the restore (~8s; swap_tick runs at 1s so value = seconds). ---
scoreboard players set @s ec.atlas_swap 8
tag @s add ec.atlas_swapping
function evercraft:atlas/schedule_restore

# Guide the player to complete the vanilla marker add.
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:item.book.put master @s ~ ~ ~ 0.9 1.1
data modify storage evercraft:notify stage.c set value [{text:"◈ ",color:"#B87333"},{text:"Map drawn — right-click the banner now to mark it. (Atlas returns shortly.)",color:"gray"}]
scoreboard players set #ndur ec.temp 60
function evercraft:util/notify/emit
