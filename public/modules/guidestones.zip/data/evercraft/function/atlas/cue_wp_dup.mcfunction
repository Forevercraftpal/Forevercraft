# === ADVENTURER'S ATLAS — "waypoint already in this chunk" CUE ===
# Run as @s = player. Dedupe feedback when a waypoint already exists in this chunk. We still placed the
# physical banner above (so the player sees the marker land), but we do NOT add a duplicate registry entry.
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.hat master @s ~ ~ ~ 0.5 1.0
data modify storage evercraft:notify stage.c set value [{text:"◈ ",color:"#B87333"},{text:"A waypoint is already set in this chunk.",color:"gray"}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit
