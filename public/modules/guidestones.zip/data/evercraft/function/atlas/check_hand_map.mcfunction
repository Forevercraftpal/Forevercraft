# === ADVENTURER'S ATLAS — IS THE IN-BOUNDS MAP ALREADY IN HAND? ===
# Run as @s = player. The mainhand holds SOME filled map (caller verified map_id present). If its map_id
# matches the selected in-bounds map (#atl_selmap), set #atl_handok=1 so the player can just RC the banner
# (vanilla marks it; no pull/stash needed). Otherwise leave #atl_handok=0 so on_banner falls through to
# pull the correct map.
scoreboard players set #atl_handok ec.atlas 0
scoreboard players set #atl_handmap ec.atlas -2147483648
execute store result score #atl_handmap ec.atlas run data get entity @s SelectedItem.components."minecraft:map_id"
execute if score #atl_handmap ec.atlas = #atl_selmap ec.atlas run scoreboard players set #atl_handok ec.atlas 1
