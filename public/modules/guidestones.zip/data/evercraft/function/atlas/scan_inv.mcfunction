# === ADVENTURER'S ATLAS — DOES THE PLAYER OWN THE SELECTED MAP? (macro) ===
# Args: storage evercraft:atlas sel  ($(map_id) the in-bounds map's id).
# Sets #atl_own ec.atlas = 1 if a filled_map with this map_id is present in the player's Inventory OR
# inside any bundle's contents (mirrors satchel/check_and_apply's hotbar→inventory→bundle scan). Run as
# @s = player.
$execute if data entity @s Inventory[{components:{"minecraft:map_id":$(map_id)}}] run scoreboard players set #atl_own ec.atlas 1
$execute if data entity @s Inventory[{components:{"minecraft:bundle_contents":[{components:{"minecraft:map_id":$(map_id)}}]}}] run scoreboard players set #atl_own ec.atlas 1
