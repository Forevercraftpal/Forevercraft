# === ADVENTURER'S ATLAS — DERIVE CHUNK COORDS FROM args.wx/args.wz ===
# Run as @s = player. Reads args.wx/args.wz (block ints), computes chunk coords chx=floor(wx/16),
# chz=floor(wz/16), writing args.chx/args.chz for waypoint dedupe (matched as a PAIR — no packed-int
# overflow risk at world-border range). Scoreboard /= floors toward negative infinity, the correct
# chunk-floor for negative coords.
scoreboard players set #atl_cx ec.atlas 0
scoreboard players set #atl_cz ec.atlas 0
execute store result score #atl_cx ec.atlas run data get storage evercraft:atlas args.wx
execute store result score #atl_cz ec.atlas run data get storage evercraft:atlas args.wz
scoreboard players operation #atl_cx ec.atlas /= #atl_16 ec.atlas
scoreboard players operation #atl_cz ec.atlas /= #atl_16 ec.atlas
execute store result storage evercraft:atlas args.chx int 1 run scoreboard players get #atl_cx ec.atlas
execute store result storage evercraft:atlas args.chz int 1 run scoreboard players get #atl_cz ec.atlas
