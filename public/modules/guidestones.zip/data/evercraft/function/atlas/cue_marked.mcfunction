# === ADVENTURER'S ATLAS — "already marked here" CUE ===
# Run as @s = player. A marker already exists on the in-bounds map at this chunk — dedupe, refuse.
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.hat master @s ~ ~ ~ 0.5 1.0
data modify storage evercraft:notify stage.c set value [{text:"◈ ",color:"#B87333"},{text:"This spot is already marked on your map.",color:"gray"}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit
