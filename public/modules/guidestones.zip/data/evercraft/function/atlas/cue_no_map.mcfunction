# === ADVENTURER'S ATLAS — "no filled map in offhand" CUE ===
# Run as @s = player. Soft note + hint that registering needs a filled map in the OFFHAND.
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 0.5 0.8
data modify storage evercraft:notify stage.c set value [{text:"◈ ",color:"#B87333"},{text:"Hold a filled map in your off-hand to register it.",color:"gray"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
