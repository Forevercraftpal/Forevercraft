# === ADVENTURER'S ATLAS — DISPATCH RESTORE TO OFFHAND ===
# Routed from swap_restore when mainhand was occupied but offhand was empty.
function evercraft:atlas/swap_to_offhand
data remove storage evercraft:atlas swapout
