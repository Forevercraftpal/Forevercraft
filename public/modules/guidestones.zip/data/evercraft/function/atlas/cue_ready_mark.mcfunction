# === ADVENTURER'S ATLAS — "the right map is already in hand" CUE ===
# Run as @s = player. The in-bounds map is already the mainhand item — no borrow needed; the player just
# right-clicks the banner once with it to let vanilla add the marker.
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:item.book.put master @s ~ ~ ~ 0.7 1.1
data modify storage evercraft:notify stage.c set value [{text:"◈ ",color:"#B87333"},{text:"That map covers here — right-click the banner with it to mark it.",color:"gray"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
