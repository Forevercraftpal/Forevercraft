# === ADVENTURER'S ATLAS — "you don't carry the in-bounds map" CUE ===
# Run as @s = player. The registered in-bounds map isn't in the player's inventory or any bundle, so it
# can't be borrowed into the hand for the vanilla marker add. Hint to carry it (even bundled).
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 0.5 0.8
data modify storage evercraft:notify stage.c set value [{text:"◈ ",color:"#B87333"},{text:"Carry this area's map (a bundle is fine) so the Atlas can mark it.",color:"gray"}]
scoreboard players set #ndur ec.temp 50
function evercraft:util/notify/emit
