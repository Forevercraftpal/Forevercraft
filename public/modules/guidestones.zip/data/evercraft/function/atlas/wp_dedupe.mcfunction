# === ADVENTURER'S ATLAS — DEDUPE A WAYPOINT BY CHUNK (macro) ===
# Args: storage evercraft:atlas args  ($(UUID) player key; $(chx),$(chz) candidate chunk coords).
# Sets #atl_wpdup ec.atlas = 1 if the player already has a waypoint in this chunk, else 0 — so no two
# markers land in the same chunk on the same map (the spec's coords/chunk dedupe rule).
scoreboard players set #atl_wpdup ec.atlas 0
$execute if data storage evercraft:atlas players."$(UUID)".waypoints[{chx:$(chx),chz:$(chz)}] run scoreboard players set #atl_wpdup ec.atlas 1
