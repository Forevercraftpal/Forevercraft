# === ADVENTURER'S ATLAS — RESTORE THE ATLAS AFTER A BORROW ===
# Run as @s = player, at @s (from swap_tick when ec.atlas_swap hits 0). Removes the borrowed map from
# ANYWHERE in inventory (the player may have switched hotbar slots during the 8s window) and puts the
# stashed atlas back via slot-aware swap_restore (mainhand if free → offhand if free → drop at feet),
# then marks the in-bounds waypoint at this chunk as marked:1b (so the chunk-dedupe refuses a second
# marker on the same map) and clears all swap state.
# 2026-06-12 fix: the prior version cleared borrow_map only from mainhand AND unconditionally
# overwrote mainhand with the atlas — if the player switched away from the borrow_map slot during
# the 8s, the borrow_map persisted in inventory AND the player's held item got replaced.

# Clear the borrowed map from EVERYWHERE in inventory (mainhand/offhand/storage/hotbar).
clear @s *[custom_data~{atlas_borrow:true}]

# Restore the atlas from per-player swap storage. swap_restore picks a free held slot or drops at feet.
data modify storage evercraft:atlas args.UUID set from entity @s UUID
function evercraft:atlas/swap_restore with storage evercraft:atlas args

# Mark the waypoint in THIS chunk as marked (the vanilla add put the marker on the map by now).
execute store result storage evercraft:atlas args.wx int 1 run data get entity @s Pos[0]
execute store result storage evercraft:atlas args.wz int 1 run data get entity @s Pos[2]
function evercraft:atlas/wp_chunk
function evercraft:atlas/mark_set with storage evercraft:atlas args

# Clean up swap state.
tag @s remove ec.atlas_swapping
scoreboard players set @s ec.atlas_swap 0
function evercraft:atlas/swap_clear with storage evercraft:atlas args

# Feedback.
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:item.book.page_turn master @s ~ ~ ~ 0.8 1.0
data modify storage evercraft:notify stage.c set value [{text:"◈ ",color:"#B87333"},{text:"Atlas returned. Waypoint marked.",color:"gray"}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit
