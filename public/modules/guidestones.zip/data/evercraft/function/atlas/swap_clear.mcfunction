# === ADVENTURER'S ATLAS — CLEAR THE PER-PLAYER SWAP STASH (macro) ===
# Args: storage evercraft:atlas args  ($(UUID) player key). Removes the stashed-atlas entry once restored.
$data remove storage evercraft:atlas swaps."$(UUID)"
