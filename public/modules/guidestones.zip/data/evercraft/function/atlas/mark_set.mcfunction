# === ADVENTURER'S ATLAS — FLAG THE WAYPOINT IN THIS CHUNK AS MARKED (macro) ===
# Args: storage evercraft:atlas args  ($(UUID) player key; $(chx),$(chz) chunk). Sets marked:1b on the
# matching waypoint so the chunk-dedupe (mark_dedupe) refuses a second marker there. No-op if the player
# placed the banner without a stored waypoint (e.g. a vanilla banner they made themselves).
$data modify storage evercraft:atlas players."$(UUID)".waypoints[{chx:$(chx),chz:$(chz)}].marked set value 1b
