# === ADVENTURER'S ATLAS — START / RE-ARM THE RESTORE TICK ===
# Run as @s = player (from pull_map). Schedules the swap-restore tick if it isn't already running. The tick
# self-reschedules at 1s while ANY player is mid-swap (ec.atlas_swapping tag) and stops when none remain —
# so there is NO global per-tick cost when no atlas borrow is in flight (existence-gated, self-scheduling).
# A guard score #atl_tickon ec.atlas prevents stacking duplicate schedules.
execute if score #atl_tickon ec.atlas matches 1 run return 0
scoreboard players set #atl_tickon ec.atlas 1
schedule function evercraft:atlas/swap_tick 20t replace
