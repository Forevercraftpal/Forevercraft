# === ADVENTURER'S ATLAS — SELECT THE IN-BOUNDS REGISTERED MAP ===
# Run as @s = player. Walks the player's registered maps and picks the FIRST whose bounds cover the
# player's current X/Z: |cx - X| <= scale AND |cz - Z| <= scale. Writes:
#   #atl_mapfound ec.atlas = 1/0
#   storage evercraft:atlas sel = {map_id,cx,cz,scale}  (the chosen map, when found)
# Iteration uses a copy-to-working-list + recursive head-pop (no macro-list-index gymnastics).

scoreboard players set #atl_mapfound ec.atlas 0
data remove storage evercraft:atlas sel

# Read the player's X/Z into compare scores.
execute store result score #atl_px ec.atlas run data get entity @s Pos[0]
execute store result score #atl_pz ec.atlas run data get entity @s Pos[2]

# Copy the player's maps list into a working list we can destructively pop.
data modify storage evercraft:atlas work set value []
function evercraft:atlas/copy_maps with storage evercraft:atlas args

# Iterate.
function evercraft:atlas/pick_step
