# === ADVENTURER'S ATLAS — RECORD THE SELECTED IN-BOUNDS MAP ===
# Run as @s = player. The head of `work` covers the player — copy it to storage evercraft:atlas sel and
# raise #atl_mapfound. Also stash sel.map_id into a score for the pull step.
data modify storage evercraft:atlas sel set from storage evercraft:atlas work[0]
scoreboard players set #atl_mapfound ec.atlas 1
execute store result score #atl_selmap ec.atlas run data get storage evercraft:atlas sel.map_id
