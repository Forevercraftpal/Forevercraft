# === ADVENTURER'S ATLAS — MINT THE BORROWED MAP INTO THE MAINHAND (macro) ===
# Args: storage evercraft:atlas mint  ($(map_id) the in-bounds map's id).
# Replaces the mainhand (where the atlas was) with a temporary filled_map bound to that map_id, tagged
# {atlas_borrow:true} so the restore can identify + clear it. Same map_id = the SAME world map, so the
# vanilla map-on-banner add writes the marker onto the player's real registered map. Run as @s = player.
$item replace entity @s weapon.mainhand with minecraft:filled_map[minecraft:map_id=$(map_id),minecraft:custom_data={atlas_borrow:true}]
