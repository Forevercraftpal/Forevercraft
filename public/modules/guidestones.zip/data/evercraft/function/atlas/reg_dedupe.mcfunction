# === ADVENTURER'S ATLAS — DEDUPE A MAP BY map_id (macro) ===
# Args: storage evercraft:atlas io  (io.UUID = player UUID, io.map.map_id = candidate map_id).
# Sets #atl_dup ec.temp = 1 if the player's maps list already contains an entry with this map_id, else 0.
# Uses the map_id value as a literal index match against the list (an entry exists -> already registered).
scoreboard players set #atl_dup ec.temp 0
$execute if data storage evercraft:atlas players."$(UUID)".maps[{map_id:$(map_id)}] run scoreboard players set #atl_dup ec.temp 1
