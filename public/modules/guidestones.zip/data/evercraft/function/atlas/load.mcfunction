# === ADVENTURER'S ATLAS — LOAD ===
# Registers the atlas scoreboards + the math constants used by the in-bounds/chunk arithmetic, and seeds
# the per-player storage root. The swap-restore tick is self-scheduling (only runs while a borrow is in
# flight), so there is NO entry wired into the global #minecraft:tick chain — zero idle cost.

# Per-player swap state (one writer each: on_banner/pull_map set, swap_tick decrements, restore clears).
scoreboard objectives add ec.atlas_swap dummy "Atlas Swap Timer"
scoreboard objectives add ec.atlas_slot dummy "Atlas Swap Slot"

# Atlas scratch + constants (fake-player rows on the ec.atlas objective).
scoreboard objectives add ec.atlas dummy "Atlas Scratch"
scoreboard players set #atl_16 ec.atlas 16
scoreboard players set #atl_neg1 ec.atlas -1
scoreboard players set #atl_tickon ec.atlas 0

# Seed the storage root so the first ensure_player has a parent object to extend.
execute unless data storage evercraft:atlas players run data modify storage evercraft:atlas players set value {}

# Stranded-swap recovery: if a player was mid-borrow when the world stopped (the schedule didn't survive),
# re-arm the restore tick so their atlas comes back. Existence-gated — no cost when none are stranded.
execute if entity @a[tag=ec.atlas_swapping,limit=1] run function evercraft:atlas/schedule_restore
