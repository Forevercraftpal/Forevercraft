# === ADVENTURER'S ATLAS — SWAP-RESTORE TICK (self-scheduling, 1s) ===
# Decrements each mid-swap player's ec.atlas_swap (seconds). At 0, restores their atlas. Self-reschedules
# only while at least one player carries ec.atlas_swapping; otherwise it stops (and clears #atl_tickon) so
# there's zero idle cost. Existence-gated at the top.

# Nobody mid-swap -> stop the loop.
execute unless entity @a[tag=ec.atlas_swapping,limit=1] run scoreboard players set #atl_tickon ec.atlas 0
execute unless entity @a[tag=ec.atlas_swapping,limit=1] run return 0

# Count down each swapping player; restore at 0.
scoreboard players remove @a[tag=ec.atlas_swapping] ec.atlas_swap 1
execute as @a[tag=ec.atlas_swapping,scores={ec.atlas_swap=..0}] at @s run function evercraft:atlas/restore

# Re-arm for the next second.
schedule function evercraft:atlas/swap_tick 20t replace
