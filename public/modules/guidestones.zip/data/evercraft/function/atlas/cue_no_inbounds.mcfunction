# === ADVENTURER'S ATLAS — "no registered map covers here" CUE ===
# Run as @s = player. None of the player's registered maps' bounds cover their current position. Hint to
# register the map for this area first (right-click the Atlas with that map in the off-hand).
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 0.5 0.8
data modify storage evercraft:notify stage.c set value [{text:"◈ ",color:"#B87333"},{text:"No registered map covers this area — register one here first.",color:"gray"}]
scoreboard players set #ndur ec.temp 50
function evercraft:util/notify/emit
