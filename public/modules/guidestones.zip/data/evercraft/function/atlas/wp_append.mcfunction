# === ADVENTURER'S ATLAS — APPEND A WAYPOINT (macro) ===
# Args: storage evercraft:atlas args  ($(UUID) player key; $(wx),$(wz),$(chx),$(chz) the waypoint).
# Appends {x,z,chx,chz,marked:0b} to the player's waypoints list. marked flips to 1b once the vanilla
# map-on-banner add has put the marker on a registered map (set by on_banner). Caller has already deduped.
$data modify storage evercraft:atlas players."$(UUID)".waypoints append value {x:$(wx),z:$(wz),chx:$(chx),chz:$(chz),marked:0b}
