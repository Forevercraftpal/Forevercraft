# === ADVENTURER'S ATLAS — RC DISPATCH ===
# Run as @s = player. Fired by the atlas/use using_item advancement when the player right-clicks a held
# {adventurers_atlas:true} item. Branches on sneak (predicate evercraft:is_sneaking):
#   • NON-SNEAK -> REGISTER the filled map in the OFFHAND into the player's atlas registry.
#   • SNEAK     -> place a waypoint banner at the player's location.
# Revoke+re-arm so a single click fires exactly once (clone of the key_satchel / monocle RC idiom).

advancement revoke @s only evercraft:atlas/use

# Only fire from a held slot (mainhand or offhand) — never a stray copy in a container.
execute unless items entity @s weapon.mainhand *[custom_data~{adventurers_atlas:true}] unless items entity @s weapon.offhand *[custom_data~{adventurers_atlas:true}] run return fail

# SNEAK -> place a waypoint banner here. NON-SNEAK -> register the offhand map.
execute if predicate evercraft:is_sneaking at @s run return run function evercraft:atlas/place_banner
execute unless predicate evercraft:is_sneaking run function evercraft:atlas/register_map
