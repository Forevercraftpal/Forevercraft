# === ADVENTURER'S ATLAS — "cannot place banner here" CUE ===
# Run as @s = player. The feet block is not replaceable (something solid is there) — refuse rather than grief.
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 0.5 0.8
data modify storage evercraft:notify stage.c set value [{text:"◈ ",color:"#B87333"},{text:"No room here for a waypoint banner.",color:"gray"}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit
