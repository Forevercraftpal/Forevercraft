# === ADVENTURER'S ATLAS — PLACE THE STASHED ATLAS NBT INTO THE MAINHAND ===
# Run as @s = player. storage evercraft:atlas swapout = the saved atlas item NBT. Uses the hopper_minecart
# stash idiom (mirrors spirit/metamorphosis/transform) to load arbitrary item NBT into a held slot, since
# `item replace … with <item>` can't take a stored component blob directly.
execute at @s run summon hopper_minecart ~ 320 ~ {Tags:["ec.atlas_temp"],Items:[{Slot:0b,id:"minecraft:stone",count:1}]}
data modify entity @e[type=hopper_minecart,tag=ec.atlas_temp,limit=1] Items[0] set from storage evercraft:atlas swapout
item replace entity @s weapon.mainhand from entity @e[type=hopper_minecart,tag=ec.atlas_temp,limit=1] container.0
kill @e[type=hopper_minecart,tag=ec.atlas_temp]
