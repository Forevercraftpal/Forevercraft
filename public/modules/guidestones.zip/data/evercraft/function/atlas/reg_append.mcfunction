# === ADVENTURER'S ATLAS — APPEND A REGISTERED MAP (macro) ===
# Args: storage evercraft:atlas args  ($(UUID) player key; $(map_id),$(cx),$(cz),$(scale) the map record).
# Appends {map_id,cx,cz,scale} to the player's maps list. Caller has already deduped by map_id.
$data modify storage evercraft:atlas players."$(UUID)".maps append value {map_id:$(map_id),cx:$(cx),cz:$(cz),scale:$(scale)}
