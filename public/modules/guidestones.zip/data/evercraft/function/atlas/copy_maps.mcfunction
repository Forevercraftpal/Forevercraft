# === ADVENTURER'S ATLAS — COPY PLAYER MAPS INTO THE WORKING LIST (macro) ===
# Args: storage evercraft:atlas args  ($(UUID) player key).
# Copies players."<UUID>".maps into storage evercraft:atlas work for destructive iteration by pick_step.
$data modify storage evercraft:atlas work set from storage evercraft:atlas players."$(UUID)".maps
