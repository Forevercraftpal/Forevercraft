# === ADVENTURER'S ATLAS — DROP THE STASHED ATLAS AT PLAYER'S FEET ===
# Run as @s = player, at @s. Last-resort restore path when BOTH mainhand AND offhand are occupied
# (the player switched away during the 8s swap AND had something in offhand). Spawns the atlas as an
# item entity at the player's feet with zero pickup delay — the player walks onto it to pick up.
# Uses the same hopper_minecart NBT-load idiom (swap_to_hand line) to load the stashed item NBT,
# then transfers it into a summoned item entity via item replace into a new container.

execute at @s run summon hopper_minecart ~ 320 ~ {Tags:["ec.atlas_temp"],Items:[{Slot:0b,id:"minecraft:stone",count:1}]}
data modify entity @e[type=hopper_minecart,tag=ec.atlas_temp,limit=1] Items[0] set from storage evercraft:atlas swapout

# Summon an item entity at player feet with the stashed atlas NBT (PickupDelay:0s = instant pickup).
execute at @s run summon item ~ ~0.5 ~ {Tags:["ec.atlas_drop"],PickupDelay:0s,Item:{id:"minecraft:stone",count:1}}
data modify entity @e[type=item,tag=ec.atlas_drop,limit=1,distance=..2] Item set from entity @e[type=hopper_minecart,tag=ec.atlas_temp,limit=1] Items[0]
tag @e[type=item,tag=ec.atlas_drop] remove ec.atlas_drop

kill @e[type=hopper_minecart,tag=ec.atlas_temp]

# Warn player.
data modify storage evercraft:notify stage.c set value [{text:"⚠ ",color:"yellow"},{text:"Atlas returned — your hands were full, so it was dropped at your feet.",color:"gray"}]
scoreboard players set #ndur ec.temp 80
function evercraft:util/notify/emit
