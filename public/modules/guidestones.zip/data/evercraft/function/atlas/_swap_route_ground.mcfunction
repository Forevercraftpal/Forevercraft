# === ADVENTURER'S ATLAS — DISPATCH RESTORE TO GROUND ===
# Routed from swap_restore when both mainhand AND offhand are occupied.
function evercraft:atlas/swap_to_ground
data remove storage evercraft:atlas swapout
