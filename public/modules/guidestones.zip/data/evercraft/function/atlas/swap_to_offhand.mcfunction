# === ADVENTURER'S ATLAS — PLACE THE STASHED ATLAS NBT INTO THE OFFHAND ===
# Run as @s = player, at @s. Mirrors swap_to_hand but targets weapon.offhand. Used by restore.mcfunction
# when mainhand is occupied by something other than the borrow_map (e.g., the player switched hotbar
# slots during the 8s window).
execute at @s run summon hopper_minecart ~ 320 ~ {Tags:["ec.atlas_temp"],Items:[{Slot:0b,id:"minecraft:stone",count:1}]}
data modify entity @e[type=hopper_minecart,tag=ec.atlas_temp,limit=1] Items[0] set from storage evercraft:atlas swapout
item replace entity @s weapon.offhand from entity @e[type=hopper_minecart,tag=ec.atlas_temp,limit=1] container.0
kill @e[type=hopper_minecart,tag=ec.atlas_temp]
