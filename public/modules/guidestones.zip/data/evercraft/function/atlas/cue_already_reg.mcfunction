# === ADVENTURER'S ATLAS — "map already registered" CUE ===
# Run as @s = player. Dedupe feedback when the offhand map's map_id is already in the registry.
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:item.book.page_turn master @s ~ ~ ~ 0.5 0.9
data modify storage evercraft:notify stage.c set value [{text:"◈ ",color:"#B87333"},{text:"That map is already in your Atlas.",color:"gray"}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit
