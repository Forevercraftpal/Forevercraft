# === ADVENTURER'S ATLAS — IN-BOUNDS PICK, ONE STEP ===
# Run as @s = player. Pops work[0], tests whether it covers the player (#atl_px/#atl_pz vs cx±scale,
# cz±scale). On a hit: writes storage evercraft:atlas sel + #atl_mapfound=1 and stops. Else recurses on
# the tail. Bounded by the registry size (small; one map per registered map).

# Empty list -> done (no in-bounds map; #atl_mapfound stays 0).
execute unless data storage evercraft:atlas work[0] run return 0

# Read the head entry's fields.
execute store result score #atl_cx ec.atlas run data get storage evercraft:atlas work[0].cx
execute store result score #atl_cz ec.atlas run data get storage evercraft:atlas work[0].cz
execute store result score #atl_sc ec.atlas run data get storage evercraft:atlas work[0].scale

# Compute |px - cx| and |pz - cz|.
scoreboard players operation #atl_dx ec.atlas = #atl_px ec.atlas
scoreboard players operation #atl_dx ec.atlas -= #atl_cx ec.atlas
execute if score #atl_dx ec.atlas matches ..-1 run scoreboard players operation #atl_dx ec.atlas *= #atl_neg1 ec.atlas
scoreboard players operation #atl_dz ec.atlas = #atl_pz ec.atlas
scoreboard players operation #atl_dz ec.atlas -= #atl_cz ec.atlas
execute if score #atl_dz ec.atlas matches ..-1 run scoreboard players operation #atl_dz ec.atlas *= #atl_neg1 ec.atlas

# In bounds? (dx <= scale AND dz <= scale) -> select + stop.
execute if score #atl_dx ec.atlas <= #atl_sc ec.atlas if score #atl_dz ec.atlas <= #atl_sc ec.atlas run function evercraft:atlas/pick_hit

# If a hit was recorded, stop.
execute if score #atl_mapfound ec.atlas matches 1 run return 0

# Else pop the head and recurse on the tail.
data remove storage evercraft:atlas work[0]
function evercraft:atlas/pick_step
