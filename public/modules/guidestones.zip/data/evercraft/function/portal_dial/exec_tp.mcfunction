# Portal Dial — Execute teleport to lodestone location
# Called with: eden:temp portal_dial.tp {dimension, x, y, z}

$execute in $(dimension) run tp @s $(x) $(y) $(z)

execute at @s run playsound minecraft:entity.enderman.teleport neutral @a[scores={ec.fx_snd=1..}] ~ ~ ~ 0.5 0.5
execute at @s run particle minecraft:reverse_portal ~ ~0.5 ~ 0.3 0.7 0.3 0 50

data modify storage evercraft:notify stage.c set value [{text:"▊ ",color:"dark_purple"},{text:"Warped to lodestone!",color:"gold"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit

# Clean up temp data
data remove storage eden:temp portal_dial
