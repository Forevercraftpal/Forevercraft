# === DECOR SHOWROOM — CLEAR (debug) ===
# Run as operator. Removes every display placed by decor/showroom or decor/grand_showroom.
# Both showrooms tag everything they spawn with ec.showroom, so one kill clears it all.
kill @e[tag=ec.showroom]
tellraw @s [{"text":"[Showroom] ","color":"green"},{"text":"cleared all showroom displays.","color":"gray"}]
