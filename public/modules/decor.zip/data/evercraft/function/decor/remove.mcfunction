# Furnishings — Reclaim a placed instance (MACRO; run AS the anchor marker, at the anchor; B6 sentinel)
# Args (storage temp): uid, r0, r1, rmv (remover UUID). Called only after check_perm_at authorized the
# reclaim. KILL-ANCHOR-FIRST idempotency (B6): two shear events on the same piece in one tick (the dual
# interact+attack paths, or two players on unclaimed land) both reach here, but only the ONE that wins
# the anchor kill (store success == 1) fires the reward + display kills + the owner cap decrement — the
# loser sees success 0 and no-ops. So reward/refund/XP/hs.dec_live-- happen EXACTLY once.

# --- (0) Snapshot the anchor's data into storage temp BEFORE the kill (lament_reward + the owner
#         hs.dec_live decrement read it after the marker is gone). @s is the anchor here. Clear the
#         stale-prone fields first (a `set from` of an absent source is a NO-OP, so a pre-W3 anchor
#         without data.item must not leave a previous reclaim's snapshot in temp.item). ---
data remove storage evercraft:decor temp.item
data remove storage evercraft:decor temp.free
data modify storage evercraft:decor temp.id set from entity @s data.id
data modify storage evercraft:decor temp.mat set from entity @s data.mat
data modify storage evercraft:decor temp.inzone set from entity @s data.inzone
data modify storage evercraft:decor temp.owner set from entity @s data.owner
data modify storage evercraft:decor temp.item set from entity @s data.item
data modify storage evercraft:decor temp.free set from entity @s data.free

# --- (0a) Light emission cleanup (Wave E): clear our tracked world-light above the cell. @s is the
#          anchor (at the base cell), so the light sits at ~ ~1 ~. Gated on minecraft:light so it only
#          clears OUR light, never a player block; no-op for non-lit pieces. ---
execute if block ~ ~1 ~ minecraft:light run setblock ~ ~1 ~ minecraft:air replace

# --- (0b) Clear any tangibility barriers (replace-barrier-only: a no-op for intangible
#          pieces, and never deletes real blocks). Must run while the anchor still anchors
#          our position + temp.id is staged. ---
function evercraft:decor/manage/clear_barriers with storage evercraft:decor temp
# Eject any displayed items first (display stand/cases) — they are real player items.
function evercraft:decor/display/drop_slots
# Eject any food set out on a dining table too (real player items) before the kill.
function evercraft:decor/dining/drop_slots
# Eject any books shelved in a bookshelf nook (data.books lives on this anchor, so it
# must drop BEFORE the anchor dies) — else a reclaim/store/move silently eats them.
function evercraft:decor/books/drop_all

# --- (1) SENTINEL: kill the anchor first; capture whether THIS call is the one that removed it. ---
$execute store success score #dec_killed ec.temp run kill @e[type=marker,tag=ec.dec_anchor,scores={ec.dec_uid=$(uid)},limit=1]

# Lost the race (another same-tick shear already reclaimed this piece) → no double reward. Bail.
execute unless score #dec_killed ec.temp matches 1 run return 0

# --- (2) We won the kill. Reclaim FX (the dream-echo signature: poof + sheep.shear). ---
particle minecraft:poof ~ ~0.5 ~ 0.3 0.3 0.3 0.05 8
playsound minecraft:entity.sheep.shear master @a[distance=..16,scores={ec.fx_snd=1..}] ~ ~ ~ 0.8 1.0

# --- (3) Tear down this instance's visible body + its clickable footprint (includes the @s-adjacent
#         interaction that triggered us). UID-scoped so a neighbor's piece is never touched. ---
$kill @e[type=#evercraft:decor_displays,tag=ec.dec_disp,scores={ec.dec_uid=$(uid)}]
$kill @e[type=interaction,tag=ec.dec_click,scores={ec.dec_uid=$(uid)}]
# Bookshelf-nook hover-nameplates are text_displays (not in #decor_displays), so kill
# them by uid too or they orphan on reclaim/store/move. No-op for every other piece.
$kill @e[type=text_display,tag=ec.shelf_name,scores={ec.dec_uid=$(uid)}]

# --- (4) Per-home live cap: decrement the OWNER's hs.dec_live by 1 (floor 0), ONLY for in-zone pieces
#         (wild decor never incremented it). One writer with decor/use/confirm. The owner is keyed by
#         the anchor's stored owner UUID; resolve them by matching UUID halves to an online player. ---
# (Path + matcher must be ONE token — `temp {inzone:1b}` with a space parse-failed this whole file
# at /reload, 2026-06-09 prod log.)
execute if data storage evercraft:decor temp{inzone:1b} run function evercraft:decor/dec_owner_live with storage evercraft:decor temp

# Owner-store short-circuit (Joseph 2026-06-12): manage/do_store sets owner_store:1b
# before invoking us. That path returns the intact item directly to the owner (no
# Lamentor rank required), so the Lamentor reclaim ladder below MUST be skipped —
# otherwise non-Signature Lamentors would get 50% mats refund ON TOP of the item, and
# the lower-rank "you got nothing" branch would fire a misleading notify.
execute if data storage evercraft:decor temp{owner_store:1b} run return 0

# --- (5) Lamentor reclaim ladder (B2/B7) — run AS the VERIFIED remover (Audit #57 row 7). The anchor +
#         interaction are gone, so resolve the clicker by UUID-half match against temp.r0/r1 (the identity
#         click/check captured from the interaction's own player/attack record — the same identity the
#         permission gate used). The old `@p[is_holding_shears]` re-select could pay the WRONG player when
#         two shears-holders stand stacked over one piece. Mirrors the dec_owner_live/dec_owner_match idiom;
#         a same-tick disconnect simply pays nobody instead of a bystander. ---
execute store result score #dec_rmv_r0 ec.temp run data get storage evercraft:decor temp.r0
execute store result score #dec_rmv_r1 ec.temp run data get storage evercraft:decor temp.r1
execute as @a run function evercraft:decor/rmv_match
