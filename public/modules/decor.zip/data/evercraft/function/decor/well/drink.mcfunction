# Stone Well — drink (Joseph 2026-06-13, task #102)
# Run as the clicking player. 30-second cooldown via ec.well_cd (decremented by
# well/cd_tick). Off-cooldown right-click gives +saturation 1s (=fills food bar
# to brim) and a sip sound. On cooldown shows a brief "too soon" actionbar.

# Cooldown gate.
data modify storage evercraft:notify stage.c set value [{text:"☼ ",color:"aqua"},{text:"You're still refreshed.",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 30
execute if score @s ec.well_cd matches 1.. run return run function evercraft:util/notify/emit

# Apply: saturation for 1s amplifier 9 = +20 saturation tick — instantly refills
# food + saturation bar. Set cooldown to 600 ticks = 30s of game time.
function evercraft:decor/antique/read_eff_near {id:"stone_well",radius:3}
function evercraft:decor/antique/self_buff {effect:"minecraft:saturation",dur:1,amp:9}
scoreboard players set @s ec.well_cd 600

data modify storage evercraft:notify stage.c set value [{text:"☼ ",color:"aqua"},{text:"A cool draught",color:"yellow"},{text:" — your thirst is sated.",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit

execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.generic.drink master @s ~ ~ ~ 0.7 1.0
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.water.ambient master @s ~ ~ ~ 0.3 1.5
execute at @s run particle minecraft:splash ~ ~0.5 ~ 0.3 0.2 0.3 0.04 12
