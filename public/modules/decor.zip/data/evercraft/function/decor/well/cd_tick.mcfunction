# Stone Well — cooldown decrement tick (Joseph 2026-06-13)
# Self-rescheduling 1s tick that drops ec.well_cd by 20 (one game-second) for
# every player whose cooldown is still positive. Goes idle when nothing's on cd.

execute unless entity @a[scores={ec.well_cd=1..}] run return run schedule function evercraft:decor/well/cd_tick 30s replace

scoreboard players remove @a[scores={ec.well_cd=1..}] ec.well_cd 20

schedule function evercraft:decor/well/cd_tick 1s replace
