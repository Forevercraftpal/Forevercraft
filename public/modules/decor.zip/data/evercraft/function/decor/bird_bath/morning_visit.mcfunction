# Bird Bath — morning visitor (Joseph 2026-06-14). Run AT a bird_bath anchor at dawn (from
# quests/reset/daily). 3% chance to draw a live chicken to the basin.
execute store result score #bv ec.temp run random value 1..100
execute if score #bv ec.temp matches 4.. run return 0
summon minecraft:chicken ~ ~1 ~ {PersistenceRequired:1b}
particle minecraft:happy_villager ~ ~1 ~ 0.4 0.4 0.4 0.02 12
