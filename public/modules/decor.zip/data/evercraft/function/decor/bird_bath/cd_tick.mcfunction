# Bird Bath — cooldown decrement tick (Joseph 2026-06-13)

execute unless entity @a[scores={ec.bird_cd=1..}] run return run schedule function evercraft:decor/bird_bath/cd_tick 30s replace

scoreboard players remove @a[scores={ec.bird_cd=1..}] ec.bird_cd 20

schedule function evercraft:decor/bird_bath/cd_tick 1s replace
