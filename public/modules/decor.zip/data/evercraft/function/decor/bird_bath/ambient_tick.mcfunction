# Bird Bath — ambient chirp tick (Joseph 2026-06-13, task #102)
# Self-rescheduling 6s tick. Existence-gated to bird_bath anchors. Random soft
# birdsong to nearby players. Daytime only (sound is a hush at night).

execute unless entity @e[type=marker,tag=ec.dec_anchor,nbt={data:{id:"bird_bath"}},limit=1] run return run schedule function evercraft:decor/bird_bath/ambient_tick 30s replace

execute store result score #tod ec.temp run time query minecraft:day
execute if score #tod ec.temp matches 13000..23000 run return run schedule function evercraft:decor/bird_bath/ambient_tick 6s replace

execute as @e[type=marker,tag=ec.dec_anchor,nbt={data:{id:"bird_bath"}}] at @s run function evercraft:decor/bird_bath/maybe_chirp

schedule function evercraft:decor/bird_bath/ambient_tick 6s replace
