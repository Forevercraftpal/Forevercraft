# Bird Bath — single-anchor chirp roll (Joseph 2026-06-13)
# Run as the anchor, at it. 25% chance to play soft birdsong. Pitch random across
# a small 5-step palette so successive calls sound like different birds.

execute unless entity @a[distance=..20] run return 0

execute store result score #bb_r ec.temp run random value 1..100
execute if score #bb_r ec.temp matches 26.. run return 0

execute store result score #bb_p ec.temp run random value 1..5
# Note-block flute = bird-substitute (palette rule: musical, never mob vocals).
execute if score #bb_p ec.temp matches 1 run playsound minecraft:block.note_block.flute ambient @a[distance=..18,scores={ec.fx_snd=1..}] ~ ~ ~ 0.25 1.5
execute if score #bb_p ec.temp matches 2 run playsound minecraft:block.note_block.flute ambient @a[distance=..18,scores={ec.fx_snd=1..}] ~ ~ ~ 0.25 1.8
execute if score #bb_p ec.temp matches 3 run playsound minecraft:block.note_block.flute ambient @a[distance=..18,scores={ec.fx_snd=1..}] ~ ~ ~ 0.25 2.0
execute if score #bb_p ec.temp matches 4 run playsound minecraft:block.note_block.flute ambient @a[distance=..18,scores={ec.fx_snd=1..}] ~ ~ ~ 0.2 1.6
execute if score #bb_p ec.temp matches 5 run playsound minecraft:block.note_block.flute ambient @a[distance=..18,scores={ec.fx_snd=1..}] ~ ~ ~ 0.2 1.9
