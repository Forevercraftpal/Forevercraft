# Bird Bath — sip (Joseph 2026-06-13, task #102)
# Run as the clicking player. 60-second cooldown via ec.bird_cd. Right-click for
# a brief refresh: Speed I 20s + Jump Boost I 20s + tiny saturation top-up.
# Conceptually you're scattering the birds and stealing a sip from the basin.

data modify storage evercraft:notify stage.c set value [{text:"❉ ",color:"aqua"},{text:"The birds are still settling.",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 30
execute if score @s ec.bird_cd matches 1.. run return run function evercraft:util/notify/emit

function evercraft:decor/antique/read_eff_near {id:"bird_bath",radius:3}
function evercraft:decor/antique/self_buff {effect:"minecraft:speed",dur:20,amp:0}
function evercraft:decor/antique/self_buff {effect:"minecraft:jump_boost",dur:20,amp:0}
function evercraft:decor/antique/self_buff {effect:"minecraft:saturation",dur:1,amp:2}
scoreboard players set @s ec.bird_cd 1200

data modify storage evercraft:notify stage.c set value [{text:"❉ ",color:"aqua"},{text:"A bracing splash",color:"yellow"},{text:" — feathers and water in the air.",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit

execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.parrot.fly master @s ~ ~ ~ 0.5 1.2
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.generic.splash master @s ~ ~ ~ 0.4 1.4
execute at @s run particle minecraft:splash ~ ~0.9 ~ 0.3 0.2 0.3 0.05 16
