# === FURNISHINGS COST — display_case_grand (non-destructive material check; sets #dec_has_mats) ===
scoreboard players set #dec_has_mats ec.temp 1
$execute store result score #dec_mat ec.temp run clear @s $(mat) 0
execute if score #dec_mat ec.temp matches ..4 run scoreboard players set #dec_has_mats ec.temp 0
execute store result score #dec_mat ec.temp run clear @s minecraft:glass 0
execute if score #dec_mat ec.temp matches ..2 run scoreboard players set #dec_has_mats ec.temp 0
execute store result score #dec_mat ec.temp run clear @s minecraft:gold_ingot 0
execute if score #dec_mat ec.temp matches ..0 run scoreboard players set #dec_has_mats ec.temp 0
$data modify storage evercraft:decor build.costmsg set value "5 $(mat) + 3 Glass + 1 Gold Ingot"
