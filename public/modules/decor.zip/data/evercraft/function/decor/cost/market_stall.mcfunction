# === FURNISHINGS COST — market_stall (non-destructive material check; sets #dec_has_mats) ===
scoreboard players set #dec_has_mats ec.temp 1
execute store result score #dec_mat ec.temp run clear @s minecraft:oak_planks 0
execute if score #dec_mat ec.temp matches ..3 run scoreboard players set #dec_has_mats ec.temp 0
$execute store result score #dec_mat ec.temp run clear @s $(mat)_wool 0
execute if score #dec_mat ec.temp matches ..2 run scoreboard players set #dec_has_mats ec.temp 0
$data modify storage evercraft:decor build.costmsg set value "4 Oak Planks + 3 $(mat) Wool"
