# === FURNISHINGS COST — bookcase (non-destructive material check; sets #dec_has_mats) ===
# 4 planks (the frame, mat-specific) + 6 books (the contents).
scoreboard players set #dec_has_mats ec.temp 1
$execute store result score #dec_mat ec.temp run clear @s $(mat)_planks 0
execute if score #dec_mat ec.temp matches ..3 run scoreboard players set #dec_has_mats ec.temp 0
execute store result score #dec_mat ec.temp run clear @s minecraft:book 0
execute if score #dec_mat ec.temp matches ..5 run scoreboard players set #dec_has_mats ec.temp 0
$data modify storage evercraft:decor build.costmsg set value "4 $(mat) Planks + 6 Books"
