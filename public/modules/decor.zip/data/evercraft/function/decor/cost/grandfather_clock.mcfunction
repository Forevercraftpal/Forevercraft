# === FURNISHINGS COST — grandfather_clock (non-destructive material check; sets #dec_has_mats) ===
scoreboard players set #dec_has_mats ec.temp 1
execute store result score #dec_mat ec.temp run clear @s minecraft:dark_oak_planks 0
execute if score #dec_mat ec.temp matches ..4 run scoreboard players set #dec_has_mats ec.temp 0
execute store result score #dec_mat ec.temp run clear @s minecraft:clock 0
execute if score #dec_mat ec.temp matches ..0 run scoreboard players set #dec_has_mats ec.temp 0
execute store result score #dec_mat ec.temp run clear @s minecraft:copper_ingot 0
execute if score #dec_mat ec.temp matches ..1 run scoreboard players set #dec_has_mats ec.temp 0
data modify storage evercraft:decor build.costmsg set value "5 Dark Oak Planks + 1 Clock + 2 Copper Ingots"
