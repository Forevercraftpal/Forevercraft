# === FURNISHINGS COST — aquarium_grand (non-destructive material check; sets #dec_has_mats) ===
# A 3x3 showpiece tank: 12 glass + 4 sand + 6 dark oak planks (the cabinet).
scoreboard players set #dec_has_mats ec.temp 1
execute store result score #dec_mat ec.temp run clear @s minecraft:glass 0
execute if score #dec_mat ec.temp matches ..11 run scoreboard players set #dec_has_mats ec.temp 0
execute store result score #dec_mat ec.temp run clear @s minecraft:sand 0
execute if score #dec_mat ec.temp matches ..3 run scoreboard players set #dec_has_mats ec.temp 0
execute store result score #dec_mat ec.temp run clear @s minecraft:dark_oak_planks 0
execute if score #dec_mat ec.temp matches ..5 run scoreboard players set #dec_has_mats ec.temp 0
data modify storage evercraft:decor build.costmsg set value "12 Glass + 4 Sand + 6 Dark Oak Planks"
