# === FURNISHINGS COST — fountain (non-destructive material check; sets #dec_has_mats) ===
scoreboard players set #dec_has_mats ec.temp 1
execute store result score #dec_mat ec.temp run clear @s minecraft:stone 0
execute if score #dec_mat ec.temp matches ..5 run scoreboard players set #dec_has_mats ec.temp 0
execute store result score #dec_mat ec.temp run clear @s minecraft:quartz 0
execute if score #dec_mat ec.temp matches ..1 run scoreboard players set #dec_has_mats ec.temp 0
data modify storage evercraft:decor build.costmsg set value "6 Stones + 2 Quartz"
