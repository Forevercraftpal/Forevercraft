# === FURNISHINGS COST — writing_desk (non-destructive material check; sets #dec_has_mats) ===
scoreboard players set #dec_has_mats ec.temp 1
$execute store result score #dec_mat ec.temp run clear @s $(mat)_planks 0
execute if score #dec_mat ec.temp matches ..3 run scoreboard players set #dec_has_mats ec.temp 0
execute store result score #dec_mat ec.temp run clear @s minecraft:feather 0
execute if score #dec_mat ec.temp matches ..0 run scoreboard players set #dec_has_mats ec.temp 0
execute store result score #dec_mat ec.temp run clear @s minecraft:ink_sac 0
execute if score #dec_mat ec.temp matches ..0 run scoreboard players set #dec_has_mats ec.temp 0
$data modify storage evercraft:decor build.costmsg set value "4 $(mat) Planks + 1 Feather + 1 Ink Sac"
