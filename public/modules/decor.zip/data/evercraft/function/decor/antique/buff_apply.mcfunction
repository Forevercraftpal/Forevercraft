# Antique infusion apply (MACRO storage antq q: buff, buff_lore). Run as the player from quality_sweep
# ONLY when a mythical crate yielded a Pristine (eff 200). Stamps a random material infusion onto
# Pristine blueprints that don't have one yet (antique_buff:0 sentinel).
#
# MC 26.2 (1.21.5+): `data modify entity @s Inventory[...]` is read-only and silently no-op'd, so the
# infusion never landed. Each matching slot is now handed to buff_apply_slot, which appends the lore +
# merges the custom_data on a writable hopper-minecart and swaps the item back. The antique_buff:0
# sentinel gate (checked here) closes after the merge, so re-fires settle.
$execute if items entity @s hotbar.0 *[custom_data~{antique_eff:200,antique_buff:0}] run function evercraft:decor/antique/buff_apply_slot {slot:"hotbar.0",buff:"$(buff)",buff_lore:"$(buff_lore)"}
$execute if items entity @s hotbar.1 *[custom_data~{antique_eff:200,antique_buff:0}] run function evercraft:decor/antique/buff_apply_slot {slot:"hotbar.1",buff:"$(buff)",buff_lore:"$(buff_lore)"}
$execute if items entity @s hotbar.2 *[custom_data~{antique_eff:200,antique_buff:0}] run function evercraft:decor/antique/buff_apply_slot {slot:"hotbar.2",buff:"$(buff)",buff_lore:"$(buff_lore)"}
$execute if items entity @s hotbar.3 *[custom_data~{antique_eff:200,antique_buff:0}] run function evercraft:decor/antique/buff_apply_slot {slot:"hotbar.3",buff:"$(buff)",buff_lore:"$(buff_lore)"}
$execute if items entity @s hotbar.4 *[custom_data~{antique_eff:200,antique_buff:0}] run function evercraft:decor/antique/buff_apply_slot {slot:"hotbar.4",buff:"$(buff)",buff_lore:"$(buff_lore)"}
$execute if items entity @s hotbar.5 *[custom_data~{antique_eff:200,antique_buff:0}] run function evercraft:decor/antique/buff_apply_slot {slot:"hotbar.5",buff:"$(buff)",buff_lore:"$(buff_lore)"}
$execute if items entity @s hotbar.6 *[custom_data~{antique_eff:200,antique_buff:0}] run function evercraft:decor/antique/buff_apply_slot {slot:"hotbar.6",buff:"$(buff)",buff_lore:"$(buff_lore)"}
$execute if items entity @s hotbar.7 *[custom_data~{antique_eff:200,antique_buff:0}] run function evercraft:decor/antique/buff_apply_slot {slot:"hotbar.7",buff:"$(buff)",buff_lore:"$(buff_lore)"}
$execute if items entity @s hotbar.8 *[custom_data~{antique_eff:200,antique_buff:0}] run function evercraft:decor/antique/buff_apply_slot {slot:"hotbar.8",buff:"$(buff)",buff_lore:"$(buff_lore)"}
$execute if items entity @s inventory.0 *[custom_data~{antique_eff:200,antique_buff:0}] run function evercraft:decor/antique/buff_apply_slot {slot:"inventory.0",buff:"$(buff)",buff_lore:"$(buff_lore)"}
$execute if items entity @s inventory.1 *[custom_data~{antique_eff:200,antique_buff:0}] run function evercraft:decor/antique/buff_apply_slot {slot:"inventory.1",buff:"$(buff)",buff_lore:"$(buff_lore)"}
$execute if items entity @s inventory.2 *[custom_data~{antique_eff:200,antique_buff:0}] run function evercraft:decor/antique/buff_apply_slot {slot:"inventory.2",buff:"$(buff)",buff_lore:"$(buff_lore)"}
$execute if items entity @s inventory.3 *[custom_data~{antique_eff:200,antique_buff:0}] run function evercraft:decor/antique/buff_apply_slot {slot:"inventory.3",buff:"$(buff)",buff_lore:"$(buff_lore)"}
$execute if items entity @s inventory.4 *[custom_data~{antique_eff:200,antique_buff:0}] run function evercraft:decor/antique/buff_apply_slot {slot:"inventory.4",buff:"$(buff)",buff_lore:"$(buff_lore)"}
$execute if items entity @s inventory.5 *[custom_data~{antique_eff:200,antique_buff:0}] run function evercraft:decor/antique/buff_apply_slot {slot:"inventory.5",buff:"$(buff)",buff_lore:"$(buff_lore)"}
$execute if items entity @s inventory.6 *[custom_data~{antique_eff:200,antique_buff:0}] run function evercraft:decor/antique/buff_apply_slot {slot:"inventory.6",buff:"$(buff)",buff_lore:"$(buff_lore)"}
$execute if items entity @s inventory.7 *[custom_data~{antique_eff:200,antique_buff:0}] run function evercraft:decor/antique/buff_apply_slot {slot:"inventory.7",buff:"$(buff)",buff_lore:"$(buff_lore)"}
$execute if items entity @s inventory.8 *[custom_data~{antique_eff:200,antique_buff:0}] run function evercraft:decor/antique/buff_apply_slot {slot:"inventory.8",buff:"$(buff)",buff_lore:"$(buff_lore)"}
$execute if items entity @s inventory.9 *[custom_data~{antique_eff:200,antique_buff:0}] run function evercraft:decor/antique/buff_apply_slot {slot:"inventory.9",buff:"$(buff)",buff_lore:"$(buff_lore)"}
$execute if items entity @s inventory.10 *[custom_data~{antique_eff:200,antique_buff:0}] run function evercraft:decor/antique/buff_apply_slot {slot:"inventory.10",buff:"$(buff)",buff_lore:"$(buff_lore)"}
$execute if items entity @s inventory.11 *[custom_data~{antique_eff:200,antique_buff:0}] run function evercraft:decor/antique/buff_apply_slot {slot:"inventory.11",buff:"$(buff)",buff_lore:"$(buff_lore)"}
$execute if items entity @s inventory.12 *[custom_data~{antique_eff:200,antique_buff:0}] run function evercraft:decor/antique/buff_apply_slot {slot:"inventory.12",buff:"$(buff)",buff_lore:"$(buff_lore)"}
$execute if items entity @s inventory.13 *[custom_data~{antique_eff:200,antique_buff:0}] run function evercraft:decor/antique/buff_apply_slot {slot:"inventory.13",buff:"$(buff)",buff_lore:"$(buff_lore)"}
$execute if items entity @s inventory.14 *[custom_data~{antique_eff:200,antique_buff:0}] run function evercraft:decor/antique/buff_apply_slot {slot:"inventory.14",buff:"$(buff)",buff_lore:"$(buff_lore)"}
$execute if items entity @s inventory.15 *[custom_data~{antique_eff:200,antique_buff:0}] run function evercraft:decor/antique/buff_apply_slot {slot:"inventory.15",buff:"$(buff)",buff_lore:"$(buff_lore)"}
$execute if items entity @s inventory.16 *[custom_data~{antique_eff:200,antique_buff:0}] run function evercraft:decor/antique/buff_apply_slot {slot:"inventory.16",buff:"$(buff)",buff_lore:"$(buff_lore)"}
$execute if items entity @s inventory.17 *[custom_data~{antique_eff:200,antique_buff:0}] run function evercraft:decor/antique/buff_apply_slot {slot:"inventory.17",buff:"$(buff)",buff_lore:"$(buff_lore)"}
$execute if items entity @s inventory.18 *[custom_data~{antique_eff:200,antique_buff:0}] run function evercraft:decor/antique/buff_apply_slot {slot:"inventory.18",buff:"$(buff)",buff_lore:"$(buff_lore)"}
$execute if items entity @s inventory.19 *[custom_data~{antique_eff:200,antique_buff:0}] run function evercraft:decor/antique/buff_apply_slot {slot:"inventory.19",buff:"$(buff)",buff_lore:"$(buff_lore)"}
$execute if items entity @s inventory.20 *[custom_data~{antique_eff:200,antique_buff:0}] run function evercraft:decor/antique/buff_apply_slot {slot:"inventory.20",buff:"$(buff)",buff_lore:"$(buff_lore)"}
$execute if items entity @s inventory.21 *[custom_data~{antique_eff:200,antique_buff:0}] run function evercraft:decor/antique/buff_apply_slot {slot:"inventory.21",buff:"$(buff)",buff_lore:"$(buff_lore)"}
$execute if items entity @s inventory.22 *[custom_data~{antique_eff:200,antique_buff:0}] run function evercraft:decor/antique/buff_apply_slot {slot:"inventory.22",buff:"$(buff)",buff_lore:"$(buff_lore)"}
$execute if items entity @s inventory.23 *[custom_data~{antique_eff:200,antique_buff:0}] run function evercraft:decor/antique/buff_apply_slot {slot:"inventory.23",buff:"$(buff)",buff_lore:"$(buff_lore)"}
$execute if items entity @s inventory.24 *[custom_data~{antique_eff:200,antique_buff:0}] run function evercraft:decor/antique/buff_apply_slot {slot:"inventory.24",buff:"$(buff)",buff_lore:"$(buff_lore)"}
$execute if items entity @s inventory.25 *[custom_data~{antique_eff:200,antique_buff:0}] run function evercraft:decor/antique/buff_apply_slot {slot:"inventory.25",buff:"$(buff)",buff_lore:"$(buff_lore)"}
$execute if items entity @s inventory.26 *[custom_data~{antique_eff:200,antique_buff:0}] run function evercraft:decor/antique/buff_apply_slot {slot:"inventory.26",buff:"$(buff)",buff_lore:"$(buff_lore)"}
