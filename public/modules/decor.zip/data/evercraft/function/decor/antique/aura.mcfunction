# Antique-scaled PROXIMITY aura. Run AS the decor anchor, AT it. Reads the anchor's quality and gives
# the effect to nearby players scaled by it: duration *= eff/100 (floored to 1s), amplifier +1 if
# Pristine (eff>=200). MACRO: effect (id), dur (base seconds), amp (base amplifier), radius (blocks).
function evercraft:decor/antique/read_eff
$scoreboard players set #aq_dur ec.temp $(dur)
scoreboard players operation #aq_dur ec.temp *= #aq_eff ec.temp
scoreboard players operation #aq_dur ec.temp /= #100 ec.const
execute if score #aq_dur ec.temp matches ..0 run scoreboard players set #aq_dur ec.temp 1
$scoreboard players set #aq_amp ec.temp $(amp)
execute if score #aq_eff ec.temp matches 200.. run scoreboard players add #aq_amp ec.temp 1
execute store result storage evercraft:antq dur int 1 run scoreboard players get #aq_dur ec.temp
execute store result storage evercraft:antq amp int 1 run scoreboard players get #aq_amp ec.temp
$data modify storage evercraft:antq effect set value "$(effect)"
$data modify storage evercraft:antq radius set value $(radius)
function evercraft:decor/antique/aura_apply with storage evercraft:antq
