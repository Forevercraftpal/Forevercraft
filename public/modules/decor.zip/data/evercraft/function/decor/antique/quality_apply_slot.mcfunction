# Antique quality apply — stamp the quality lore line + custom_data onto the blueprint in $(slot)
# (macro {slot, eff, label, color}). MC 26.2: `data modify entity @s Inventory[...]` is read-only, so the
# edit happens ON a hopper-minecart and the item is swapped back via /item. MERGE preserves the
# blueprint's existing custom_data (decor_free / decor id / etc.). Lore append BEFORE merge mirrors the
# original ordering (the antique:true gate was already evaluated by the caller's scan).
data modify entity @e[type=hopper_minecart,tag=ec.antq_qcart,limit=1] Items set value []
kill @e[type=hopper_minecart,tag=ec.antq_qcart]
execute at @s run summon hopper_minecart ~ ~ ~ {Tags:["ec.antq_qcart"],Enabled:0b}
$item replace entity @e[type=hopper_minecart,tag=ec.antq_qcart,limit=1,sort=nearest] container.0 from entity @s $(slot)
$data modify entity @e[type=hopper_minecart,tag=ec.antq_qcart,limit=1] Items[0].components."minecraft:lore" append value {text:"✦ $(label) quality",color:"$(color)",italic:false}
$data modify entity @e[type=hopper_minecart,tag=ec.antq_qcart,limit=1] Items[0].components."minecraft:custom_data" merge value {antique:true,antique_eff:$(eff),antique_quality:"$(label)",antique_buff:0}
$item replace entity @s $(slot) from entity @e[type=hopper_minecart,tag=ec.antq_qcart,limit=1,sort=nearest] container.0
data modify entity @e[type=hopper_minecart,tag=ec.antq_qcart,limit=1] Items set value []
kill @e[type=hopper_minecart,tag=ec.antq_qcart]
