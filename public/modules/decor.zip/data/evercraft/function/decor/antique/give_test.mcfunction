# Antique quality TEST give (admin fixture). Run as: a player. Drops Pristine + Poor blueprints of key
# interactable pieces so Phase B ability-scaling can be verified end-to-end (Pristine = dur×2 + amp+1;
# Poor = dur×0.75). Place one, then use/stand near it and compare the buff to a Standard one.
# Usage: function evercraft:decor/antique/give_test
function evercraft:decor/antique/spawn_stamped {id:"fire_pit",mat:"stone",mat_name:"Heartwood",q_label:"Pristine",q_eff:200,q_color:"#5EE6C0"}
function evercraft:decor/antique/spawn_stamped {id:"fire_pit",mat:"stone",mat_name:"Heartwood",q_label:"Poor",q_eff:75,q_color:"#8A8A8A"}
function evercraft:decor/antique/spawn_stamped {id:"aquarium",mat:"blackstone",mat_name:"Riverpearl",q_label:"Pristine",q_eff:200,q_color:"#5EE6C0"}
function evercraft:decor/antique/spawn_stamped {id:"companion_bed",mat:"blue",mat_name:"Heartwood",q_label:"Pristine",q_eff:200,q_color:"#5EE6C0"}
function evercraft:decor/antique/spawn_stamped {id:"writing_desk",mat:"acacia",mat_name:"Heirloom Brass",q_label:"Pristine",q_eff:200,q_color:"#5EE6C0"}
function evercraft:decor/antique/spawn_stamped {id:"tea_table",mat:"acacia",mat_name:"Amberbloom",q_label:"Pristine",q_eff:200,q_color:"#5EE6C0"}
# Phase E test: an INFUSED Pristine bench (Heartwood infusion = Regeneration aura on top of the seat rest).
function evercraft:decor/antique/spawn_stamped {id:"garden_bench",mat:"oak",mat_name:"Heartwood",q_label:"Pristine",q_eff:200,q_color:"#5EE6C0"}
execute rotated ~ 0 positioned ^ ^1.2 ^0.85 as @e[type=item,distance=..0.9,sort=nearest,limit=1] run data modify entity @s Item.components."minecraft:custom_data" merge value {antique_buff:"minecraft:regeneration",antique_buffed:true}
execute rotated ~ 0 positioned ^ ^1.2 ^0.85 as @e[type=item,distance=..0.9,sort=nearest,limit=1] run data modify entity @s Item.components."minecraft:lore" append value {text:"❖ Heartwood infusion — Regeneration",color:"#5EE6C0",italic:false}
tellraw @s [{text:"[admin] ",color:"dark_gray"},{text:"Dropped Pristine + Poor + 1 infused test antique — place them, then use/stand near them.",color:"#D4AF37"}]
