# Antique quality sweep — reward of advancement decor/antique/got_blueprint (fires on inventory_changed
# with a decor blueprint). Stamps freshly-acquired blueprints with the current source quality: ec.antq_src
# (set by a crate finish, by tier) or Standard (100) by default. Crafted antiques already carry antique:true
# and are skipped by quality_apply. Idempotent — the merge sets antique:true, so re-fires settle.
advancement revoke @s only evercraft:decor/antique/got_blueprint

# Resolve the effectiveness from the source window (default Standard 100).
scoreboard players set #aq_e ec.temp 100
execute if score @s ec.antq_src matches 1.. run scoreboard players operation #aq_e ec.temp = @s ec.antq_src

# Stash eff + label + color for the macro apply (≤75 Poor / 200+ Pristine / else Standard).
execute store result storage evercraft:antq q.eff int 1 run scoreboard players get #aq_e ec.temp
data modify storage evercraft:antq q.label set value "Standard"
data modify storage evercraft:antq q.color set value "gray"
execute if score #aq_e ec.temp matches ..75 run data modify storage evercraft:antq q.label set value "Poor"
execute if score #aq_e ec.temp matches ..75 run data modify storage evercraft:antq q.color set value "#8A8A8A"
execute if score #aq_e ec.temp matches 200.. run data modify storage evercraft:antq q.label set value "Pristine"
execute if score #aq_e ec.temp matches 200.. run data modify storage evercraft:antq q.color set value "#5EE6C0"

function evercraft:decor/antique/quality_apply with storage evercraft:antq q

# Mythical Pristine bonus (Phase E): roll a random material INFUSION — an extra aura the placed piece
# emits, on top of its base ability. Only on a Pristine from a mythical crate (eff 200); crafted
# Pristines are skipped (they're already antique:true). Default case 1 = Heartwood/Regeneration.
execute if score #aq_e ec.temp matches 200.. store result score #aq_buff ec.temp run random value 1..5
data modify storage evercraft:antq q.buff set value "minecraft:regeneration"
data modify storage evercraft:antq q.buff_lore set value "Heartwood infusion — Regeneration"
execute if score #aq_buff ec.temp matches 2 run data modify storage evercraft:antq q.buff set value "minecraft:luck"
execute if score #aq_buff ec.temp matches 2 run data modify storage evercraft:antq q.buff_lore set value "Deepvein infusion — Luck"
execute if score #aq_buff ec.temp matches 3 run data modify storage evercraft:antq q.buff set value "minecraft:water_breathing"
execute if score #aq_buff ec.temp matches 3 run data modify storage evercraft:antq q.buff_lore set value "Riverpearl infusion — Water Breathing"
execute if score #aq_buff ec.temp matches 4 run data modify storage evercraft:antq q.buff set value "minecraft:haste"
execute if score #aq_buff ec.temp matches 4 run data modify storage evercraft:antq q.buff_lore set value "Amberbloom infusion — Haste"
execute if score #aq_buff ec.temp matches 5 run data modify storage evercraft:antq q.buff set value "minecraft:hero_of_the_village"
execute if score #aq_buff ec.temp matches 5 run data modify storage evercraft:antq q.buff_lore set value "Heirloom infusion — Hero of the Village"
execute if score #aq_e ec.temp matches 200.. run function evercraft:decor/antique/buff_apply with storage evercraft:antq q
