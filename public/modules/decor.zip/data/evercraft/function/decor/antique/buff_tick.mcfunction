# Antique infusion aura (Phase E) — a Pristine-from-mythical piece emits a random material buff on top
# of its base ability. Self-rescheduling 4s; existence-gated to infused anchors (data.antique_buffed),
# so it idles (30s) when none are placed (they are rare). Mirrors decor/fire/aura_tick.
execute unless entity @e[type=marker,tag=ec.dec_anchor,nbt={data:{antique_buffed:true}},limit=1] run return run schedule function evercraft:decor/antique/buff_tick 30s replace
execute as @e[type=marker,tag=ec.dec_anchor,nbt={data:{antique_buffed:true}}] at @s run function evercraft:decor/antique/buff_emit
schedule function evercraft:decor/antique/buff_tick 4s replace
