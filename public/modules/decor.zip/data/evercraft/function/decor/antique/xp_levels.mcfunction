# Grant scaled XP levels (antique study-desk reward). MACRO (storage evercraft:antq): lv. Run as player.
$xp add @s $(lv) levels
