# Antique infusion apply — stamp the infusion lore line + custom_data onto the Pristine blueprint in
# $(slot) (macro {slot, buff, buff_lore}). MC 26.2: `data modify entity @s Inventory[...]` is read-only,
# so the edit happens ON a hopper-minecart and the item is swapped back via /item. MERGE preserves the
# blueprint's existing custom_data (antique / antique_eff / antique_quality / etc.).
data modify entity @e[type=hopper_minecart,tag=ec.antq_bcart,limit=1] Items set value []
kill @e[type=hopper_minecart,tag=ec.antq_bcart]
execute at @s run summon hopper_minecart ~ ~ ~ {Tags:["ec.antq_bcart"],Enabled:0b}
$item replace entity @e[type=hopper_minecart,tag=ec.antq_bcart,limit=1,sort=nearest] container.0 from entity @s $(slot)
$data modify entity @e[type=hopper_minecart,tag=ec.antq_bcart,limit=1] Items[0].components."minecraft:lore" append value {text:"❖ $(buff_lore)",color:"#5EE6C0",italic:false}
$data modify entity @e[type=hopper_minecart,tag=ec.antq_bcart,limit=1] Items[0].components."minecraft:custom_data" merge value {antique_buff:"$(buff)",antique_buffed:true}
$item replace entity @s $(slot) from entity @e[type=hopper_minecart,tag=ec.antq_bcart,limit=1,sort=nearest] container.0
data modify entity @e[type=hopper_minecart,tag=ec.antq_bcart,limit=1] Items set value []
kill @e[type=hopper_minecart,tag=ec.antq_bcart]
