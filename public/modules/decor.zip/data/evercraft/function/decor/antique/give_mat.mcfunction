# Antique material node drop (inv-full aware). MACRO: id (deepvein / riverpearl / amberbloom). Run as
# the player. Spawns at feet if the inventory is full, else gives directly. The caller owns the chance
# roll; this just delivers + announces. (Heartwood/Heirloom drop via their own node hooks.)
execute store result score #aq_full ec.var run function evercraft:util/check_inv_full
$execute if score #aq_full ec.var matches 0 run loot give @s loot evercraft:antique_mat/$(id)
$execute if score #aq_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:antique_mat/$(id)
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.4 1.6
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"#D4AF37"},{text:"A rare antique material",color:"#D4AF37"},{text:" — saw it at a sawmill.",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 50
function evercraft:util/notify/emit
