# Apply the antique-scaled proximity aura. MACRO (storage evercraft:antq): effect, dur, amp, radius.
# Run AT the anchor.
$effect give @a[distance=..$(radius)] $(effect) $(dur) $(amp) true
