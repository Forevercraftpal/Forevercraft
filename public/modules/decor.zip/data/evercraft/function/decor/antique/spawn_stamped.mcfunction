# Spawn a quality-stamped antique blueprint in front of the player, then let it be picked up. Shared by
# the sawmill craft (do_antique) and the admin test give. MACRO: id, mat, mat_name, q_label, q_eff,
# q_color. `rotated ~ 0` flattens pitch so a down-look can't bury the drop (local-coord pitch trap).
$execute rotated ~ 0 positioned ^ ^1.2 ^0.85 run loot spawn ~ ~ ~ loot evercraft:decor/bp/$(id)_$(mat)
$execute rotated ~ 0 positioned ^ ^1.2 ^0.85 as @e[type=item,distance=..0.9,sort=nearest,limit=1] run function evercraft:decor/sawmill/gui/antique_stamp {mat_name:"$(mat_name)",q_label:"$(q_label)",q_eff:$(q_eff),q_color:"$(q_color)"}
