# Apply the antique-scaled self buff. MACRO (storage evercraft:antq): effect, dur, amp. Run as the player.
$effect give @s $(effect) $(dur) $(amp) true
