# Antique effectiveness — run as the player. Finds the nearest antique anchor of the given id within
# radius and reads its quality into #aq_eff (defaults to 100 if none found / unstamped). MACRO: id, radius.
# Used by interact-buff handlers: the player clicked the piece, so the nearest same-id anchor IS it.
scoreboard players set #aq_eff ec.temp 100
$execute as @e[type=marker,tag=ec.dec_anchor,nbt={data:{id:"$(id)"}},distance=..$(radius),limit=1,sort=nearest] run function evercraft:decor/antique/read_eff
