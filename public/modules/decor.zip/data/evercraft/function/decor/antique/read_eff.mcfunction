# Antique effectiveness — run AS a decor anchor marker. Sets #aq_eff ec.temp to the piece's quality
# multiplier (75 Poor / 100 Standard / 200 Pristine). A non-antique or pre-feature anchor has no
# data.antique_eff → the get fails (store writes 0) → reset to 100 (Standard, no behavior change).
scoreboard players set #aq_eff ec.temp 100
execute store result score #aq_eff ec.temp run data get entity @s data.antique_eff
execute if score #aq_eff ec.temp matches ..0 run scoreboard players set #aq_eff ec.temp 100
