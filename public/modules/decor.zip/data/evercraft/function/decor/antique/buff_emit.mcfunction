# Antique infusion — emit the stored material effect to nearby players, Pristine-scaled (base 5s ×2 +
# amp+1). Run AS the infused anchor, at it. data.antique_buff = the effect id; data.antique_eff = 200.
# Reuses the Phase B aura_apply macro (effect/dur/amp/radius from storage).
function evercraft:decor/antique/read_eff
scoreboard players set #aq_dur ec.temp 5
scoreboard players operation #aq_dur ec.temp *= #aq_eff ec.temp
scoreboard players operation #aq_dur ec.temp /= #100 ec.const
execute if score #aq_dur ec.temp matches ..0 run scoreboard players set #aq_dur ec.temp 1
scoreboard players set #aq_amp ec.temp 0
execute if score #aq_eff ec.temp matches 200.. run scoreboard players add #aq_amp ec.temp 1
execute store result storage evercraft:antq dur int 1 run scoreboard players get #aq_dur ec.temp
execute store result storage evercraft:antq amp int 1 run scoreboard players get #aq_amp ec.temp
data modify storage evercraft:antq effect set from entity @s data.antique_buff
data modify storage evercraft:antq radius set value 4
function evercraft:decor/antique/aura_apply with storage evercraft:antq
