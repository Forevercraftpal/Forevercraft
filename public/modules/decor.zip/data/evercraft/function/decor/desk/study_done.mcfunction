# Writing Desk — studies complete: +2 levels (run as the player)
# 5-minute cooldown (ec.desk_cd 6000) before you can study again — tune to taste.
tag @s remove ec.desk_studying
scoreboard players set @s ec.desk_study 0
scoreboard players set @s ec.desk_cd 6000
# Antique-scaled reward (Phase B): base +2 levels × this desk's quality (Pristine → +4, Poor → +1).
function evercraft:decor/antique/read_eff_near {id:"writing_desk",radius:3}
scoreboard players set #dsk_lv ec.temp 2
scoreboard players operation #dsk_lv ec.temp *= #aq_eff ec.temp
scoreboard players operation #dsk_lv ec.temp /= #100 ec.const
execute if score #dsk_lv ec.temp matches ..0 run scoreboard players set #dsk_lv ec.temp 1
execute store result storage evercraft:antq lv int 1 run scoreboard players get #dsk_lv ec.temp
function evercraft:decor/antique/xp_levels with storage evercraft:antq
data modify storage evercraft:notify stage.c set value [{text:"✒ ",color:"gold"},{text:"Studies complete",color:"yellow"},{text:" — levels gained.",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 50
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.player.levelup master @s ~ ~ ~ 0.6 1.4
