# Writing Desk — study progress tick (Joseph 2026-06-14)
# Runs while anyone is studying OR cooling down. Cancels a study if the player walks away
# from the desk, otherwise counts the 30s down; at <=0, study_done grants +2 levels. Also
# bleeds the post-study cooldown. Idles (60s poll) when nobody is studying / on cd.
execute unless entity @a[tag=ec.desk_studying] unless entity @a[scores={ec.desk_cd=1..}] run return run schedule function evercraft:decor/desk/study_tick 60s replace
# post-study cooldown countdown
scoreboard players remove @a[scores={ec.desk_cd=1..}] ec.desk_cd 20
# walked away from a writing desk -> cancel (removes the tag, so the line below skips them)
execute as @a[tag=ec.desk_studying] at @s unless entity @e[type=marker,tag=ec.dec_anchor,nbt={data:{id:"writing_desk"}},distance=..2.5] run function evercraft:decor/desk/study_cancel
# still at the desk -> 1s of progress
scoreboard players remove @a[tag=ec.desk_studying] ec.desk_study 20
# 30s elapsed -> reward
execute as @a[tag=ec.desk_studying,scores={ec.desk_study=..0}] run function evercraft:decor/desk/study_done
schedule function evercraft:decor/desk/study_tick 1s replace
