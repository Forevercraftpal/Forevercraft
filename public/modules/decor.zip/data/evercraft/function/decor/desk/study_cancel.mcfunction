# Writing Desk — study interrupted (run as the player who left the desk)
tag @s remove ec.desk_studying
scoreboard players set @s ec.desk_study 0
data modify storage evercraft:notify stage.c set value [{text:"✒ ",color:"gold"},{text:"You step away — your studies pause.",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 35
function evercraft:util/notify/emit
