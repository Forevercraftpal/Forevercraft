# Writing Desk — begin studying (Joseph 2026-06-14, task #102)
# Run as the clicking player. Settle in and study for 30s WITHOUT leaving the desk to
# earn +2 levels (granted by study_done). Guarded against double-start + a post-reward
# cooldown (ec.desk_cd, default 5min — tunable in study_done).
execute if entity @s[tag=ec.desk_studying] run return 0
data modify storage evercraft:notify stage.c set value [{text:"✒ ",color:"gold"},{text:"You should rest before studying again.",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 30
execute if score @s ec.desk_cd matches 1.. run return run function evercraft:util/notify/emit
tag @s add ec.desk_studying
scoreboard players set @s ec.desk_study 600
data modify storage evercraft:notify stage.c set value [{text:"✒ ",color:"gold"},{text:"You settle in to study",color:"yellow"},{text:" — stay at the desk.",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
