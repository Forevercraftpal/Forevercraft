# ============================================================
# Furnishings Crate — Admin give (testing fixture)
# Run as operator
# Usage: function evercraft:decor/crate/give {tier:"common"}  (macro)
#   tier = common | uncommon | rare | ornate | exquisite | mythical
# Gives ONE "Furnishings Crate" of the named tier. PLACE to open (standard crate
# pipeline, 2026-06-10: placed-barrel advancement decor/crate_place/<tier> →
# decor/crate/place/<tier> → crate_anim skin/lock/animation → finish/decor/<tier>;
# the unlocked barrel then rolls decor/crate/<tier> as its container loot).
# Six canon rarity words/colors per BIG_BRAIN/20-architecture/rarity-canon.md.
# ============================================================

# Pick the tier-coloured name + lore via a per-tier give branch (one macro arg).
$function evercraft:decor/crate/give/$(tier)
