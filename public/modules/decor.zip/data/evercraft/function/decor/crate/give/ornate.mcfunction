# Furnishings Crate — give Ornate (admin testing fixture)
# Run as operator
loot give @s loot evercraft:decor/crate_item/ornate
tellraw @s [{text:"Gave a ",color:"gray"},{text:"Ornate Furnishings Crate",color:"light_purple"},{text:".",color:"gray"}]
