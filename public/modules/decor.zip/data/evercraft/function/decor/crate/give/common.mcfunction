# Furnishings Crate — give Common (admin testing fixture)
# Run as operator
loot give @s loot evercraft:decor/crate_item/common
tellraw @s [{text:"Gave a ",color:"gray"},{text:"Common Furnishings Crate",color:"white"},{text:".",color:"gray"}]
