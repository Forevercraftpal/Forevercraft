# Furnishings Crate — give Exquisite (admin testing fixture)
# Run as operator
loot give @s loot evercraft:decor/crate_item/exquisite
tellraw @s [{text:"Gave a ",color:"gray"},{text:"Exquisite Furnishings Crate",color:"light_purple"},{text:".",color:"gray"}]
