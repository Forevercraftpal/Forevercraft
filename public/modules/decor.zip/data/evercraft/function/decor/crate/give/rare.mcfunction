# Furnishings Crate — give Rare (admin testing fixture)
# Run as operator
loot give @s loot evercraft:decor/crate_item/rare
tellraw @s [{text:"Gave a ",color:"gray"},{text:"Rare Furnishings Crate",color:"aqua"},{text:".",color:"gray"}]
