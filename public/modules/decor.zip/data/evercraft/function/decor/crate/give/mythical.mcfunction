# Furnishings Crate — give Mythical (admin testing fixture)
# Run as operator
loot give @s loot evercraft:decor/crate_item/mythical
tellraw @s [{text:"Gave a ",color:"gray"},{text:"Mythical Furnishings Crate",color:"gold"},{text:".",color:"gray"}]
