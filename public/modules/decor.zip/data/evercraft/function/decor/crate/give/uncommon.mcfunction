# Furnishings Crate — give Uncommon (admin testing fixture)
# Run as operator
loot give @s loot evercraft:decor/crate_item/uncommon
tellraw @s [{text:"Gave a ",color:"gray"},{text:"Uncommon Furnishings Crate",color:"green"},{text:".",color:"gray"}]
