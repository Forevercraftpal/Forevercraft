# Fire Pit / Brazier — lick cooldown tick (Joseph 2026-06-13)
# Self-rescheduling 1s tick; goes idle when no cooldowns are positive.

execute unless entity @a[scores={ec.fire_cd=1..}] run return run schedule function evercraft:decor/fire/cd_tick 30s replace

scoreboard players remove @a[scores={ec.fire_cd=1..}] ec.fire_cd 20

schedule function evercraft:decor/fire/cd_tick 1s replace
