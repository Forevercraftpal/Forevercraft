# Fire Pit / Brazier — proximity warmth aura (Joseph 2026-06-13, task #102)
# Self-rescheduling 4s tick. Any player within 4b of a fire_pit OR brazier
# anchor gets Fire Resistance refreshed (5s duration -> the 4s tick keeps it
# live, lapses 1s after they walk away). Cheap: existence-gated to anchors.

execute unless entity @e[type=marker,tag=ec.dec_anchor,nbt={data:{id:"fire_pit"}},limit=1] unless entity @e[type=marker,tag=ec.dec_anchor,nbt={data:{id:"brazier"}},limit=1] run return run schedule function evercraft:decor/fire/aura_tick 30s replace

execute as @e[type=marker,tag=ec.dec_anchor,nbt={data:{id:"fire_pit"}}] at @s run function evercraft:decor/antique/aura {effect:"minecraft:fire_resistance",dur:5,amp:0,radius:4}
execute as @e[type=marker,tag=ec.dec_anchor,nbt={data:{id:"brazier"}}] at @s run function evercraft:decor/antique/aura {effect:"minecraft:fire_resistance",dur:5,amp:0,radius:4}

schedule function evercraft:decor/fire/aura_tick 4s replace
