# Fire Pit / Brazier — warm lick (Joseph 2026-06-13, task #102)
# Run as the clicking player. 30s cooldown via ec.fire_cd. Off-cd right-click on
# fire_pit or brazier grants Strength I for 90s (the "warm muscle" lick of flame)
# plus a brief Fire Resistance ~5s in case the click was leaning into the flames.

data modify storage evercraft:notify stage.c set value [{text:"🔥 ",color:"gold"},{text:"The fire has just warmed you.",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 30
execute if score @s ec.fire_cd matches 1.. run return run function evercraft:util/notify/emit

scoreboard players set #aq_eff ec.temp 100
execute as @e[type=marker,tag=ec.dec_anchor,nbt={data:{id:"fire_pit"}},distance=..3,limit=1,sort=nearest] run function evercraft:decor/antique/read_eff
execute as @e[type=marker,tag=ec.dec_anchor,nbt={data:{id:"brazier"}},distance=..3,limit=1,sort=nearest] run function evercraft:decor/antique/read_eff
function evercraft:decor/antique/self_buff {effect:"minecraft:strength",dur:90,amp:0}
function evercraft:decor/antique/self_buff {effect:"minecraft:fire_resistance",dur:5,amp:0}
scoreboard players set @s ec.fire_cd 600

data modify storage evercraft:notify stage.c set value [{text:"🔥 ",color:"gold"},{text:"Warm hands",color:"yellow"},{text:" — Strength I for 90s.",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit

execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.fire.ambient master @s ~ ~ ~ 0.5 0.9
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:item.firecharge.use master @s ~ ~ ~ 0.4 1.5
