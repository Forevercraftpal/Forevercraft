# Companion Bed — grant the daily rest RP to the active pet (run as the resting player).
# #now ec.temp = current gametime (set by rest_tick). The caller already filtered to players with an
# active pet (tag=companion.activepet). Daily-gated by ec.bed_next; on a fresh rest, adds 55 RP (the
# vanilla XP cost of 5 player levels) to the pet, mirroring companions/handler/menu_v2/do_treat's
# relationship chain (load_rp -> add companion.rp -> save_rp -> reload -> level_up on a level change).

# Daily gate: a player whose ec.bed_next is still ahead of now has already rested today.
execute if score @s ec.bed_next > #now ec.temp run return 0

# --- Add 55 RP via the do_treat relationship chain. ---
function evercraft:companions/handler/relationship/load_rp
scoreboard players operation #oldLevel companion.calc = @s companion.rellevel
# Antique-scaled reward (Phase B): base 55 RP × this bed's quality (Pristine → 110, Poor → 41).
function evercraft:decor/antique/read_eff_near {id:"companion_bed",radius:5}
scoreboard players set #bedRP companion.calc 55
scoreboard players operation #bedRP companion.calc *= #aq_eff ec.temp
scoreboard players operation #bedRP companion.calc /= #100 ec.const
scoreboard players operation @s companion.rp += #bedRP companion.calc
execute if score @s companion.rp matches 5001.. run scoreboard players set @s companion.rp 5000
function evercraft:companions/handler/relationship/save_rp

# Set the next rest to now + one MC day.
scoreboard players operation @s ec.bed_next = #now ec.temp
scoreboard players add @s ec.bed_next 24000

# Feedback + a cozy rest cue.
execute store result storage evercraft:antq rp int 1 run scoreboard players get #bedRP companion.calc
$data modify storage evercraft:notify stage.c set value [{selector:"@e[type=item_display,tag=Companion,predicate=evercraft:companions/check_id,limit=1]"},{text:" curls up at the bed and feels closer to you. ",color:"green"},{text:"(+$(rp) RP)",color:"yellow"}]
scoreboard players set #ndur ec.temp 50
function evercraft:util/notify/emit
execute at @e[type=item_display,tag=Companion,predicate=evercraft:companions/check_id,limit=1] run particle minecraft:heart ~ ~0.5 ~ 0.2 0.2 0.2 0 3
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.cat.purr master @s ~ ~ ~ 0.5 1.1

# Recalculate the bond level and celebrate a level-up (mirrors do_treat's tail).
function evercraft:companions/handler/relationship/load_rp
execute unless score @s companion.rellevel = #oldLevel companion.calc run function evercraft:companions/handler/relationship/level_up
