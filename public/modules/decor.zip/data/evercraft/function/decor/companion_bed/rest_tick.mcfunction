# Companion Bed — daily rest boost (Joseph 2026-06-14)
# Self-rescheduling 5s tick, modeled on decor/fire/aura_tick. A player with an ACTIVE pet standing
# within 5b of a companion_bed anchor gets ONE rest per MC-day: the pet gains 55 RP (= the vanilla XP
# of 5 player levels, 0->5). Per-player daily gate via an absolute gametime in ec.bed_next (the
# decor/mailbox/check idiom). Existence-gated to companion_bed anchors so it idles (30s) otherwise.

execute unless entity @e[type=marker,tag=ec.dec_anchor,nbt={data:{id:"companion_bed"}},limit=1] run return run schedule function evercraft:decor/companion_bed/rest_tick 30s replace

# Resolve "now" once for every eligible player's daily-cooldown compare.
execute store result score #now ec.temp run time query gametime

# Each bed: any nearby player with an active pet runs the (cooldown-gated) grant as themselves.
execute as @e[type=marker,tag=ec.dec_anchor,nbt={data:{id:"companion_bed"}}] at @s as @a[distance=..5,tag=companion.activepet] run function evercraft:decor/companion_bed/rest_grant

schedule function evercraft:decor/companion_bed/rest_tick 5s replace
