# Mailbox — claim the daily delivery (Joseph 2026-06-14, task #102)
# Run as the clicking player. One small gift per MC day (24000t), gated by an absolute
# gametime stored in ec.mail_next. A player with no ec.mail_next score (new) compares as
# "not greater than now" and can claim immediately.
execute store result score #now ec.temp run time query gametime
execute if score @s ec.mail_next > #now ec.temp run data modify storage evercraft:notify stage.c set value [{text:"📪 ",color:"yellow"},{text:"The mailbox is empty — come back tomorrow.",color:"gray",italic:true}]
execute if score @s ec.mail_next > #now ec.temp run scoreboard players set #ndur ec.temp 35
execute if score @s ec.mail_next > #now ec.temp run return run function evercraft:util/notify/emit
# Deliver a small gift + set the next claim to now + one MC day.
loot give @s loot evercraft:decor/mailbox_gift
scoreboard players operation @s ec.mail_next = #now ec.temp
scoreboard players add @s ec.mail_next 24000
data modify storage evercraft:notify stage.c set value [{text:"📬 ",color:"green"},{text:"You've got mail",color:"yellow"},{text:" — a little something arrived.",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bell ambient @s ~ ~ ~ 0.5 1.4
