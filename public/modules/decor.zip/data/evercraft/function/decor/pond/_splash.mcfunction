# Pond ripple burst (run AT the pond anchor). Gentle splash + bubbles across the surface.
particle minecraft:splash ~ ~0.3 ~ 0.6 0.1 0.6 0.04 30
particle minecraft:bubble_pop ~ ~0.25 ~ 0.55 0.05 0.55 0.02 16
playsound minecraft:block.water.ambient ambient @a[distance=..18,scores={ec.fx_snd=1..}] ~ ~ ~ 0.5 1.1
