# Pond Kit — morning frog (Joseph 2026-06-14). Run AT a pond anchor at dawn (quests/reset/daily).
# 3% chance to attract a frog: 50% the local climate's variant, 50% one of the other two.
execute store result score #pf ec.temp run random value 1..100
execute if score #pf ec.temp matches 4.. run return 0
# Local climate -> #climate (0 temperate / 1 warm / 2 cold) via the vanilla frog-variant biome tags.
scoreboard players set #climate ec.temp 0
execute if biome ~ ~ ~ #minecraft:spawns_warm_variant_frogs run scoreboard players set #climate ec.temp 1
execute if biome ~ ~ ~ #minecraft:spawns_cold_variant_frogs run scoreboard players set #climate ec.temp 2
# Final variant #fv: 50% keep local, 50% pick one of the other two (each ~25%).
scoreboard players operation #fv ec.temp = #climate ec.temp
execute store result score #pick ec.temp run random value 1..100
execute store result score #o ec.temp run random value 1..2
execute if score #pick ec.temp matches 51.. if score #climate ec.temp matches 0 if score #o ec.temp matches 1 run scoreboard players set #fv ec.temp 1
execute if score #pick ec.temp matches 51.. if score #climate ec.temp matches 0 if score #o ec.temp matches 2 run scoreboard players set #fv ec.temp 2
execute if score #pick ec.temp matches 51.. if score #climate ec.temp matches 1 if score #o ec.temp matches 1 run scoreboard players set #fv ec.temp 0
execute if score #pick ec.temp matches 51.. if score #climate ec.temp matches 1 if score #o ec.temp matches 2 run scoreboard players set #fv ec.temp 2
execute if score #pick ec.temp matches 51.. if score #climate ec.temp matches 2 if score #o ec.temp matches 1 run scoreboard players set #fv ec.temp 0
execute if score #pick ec.temp matches 51.. if score #climate ec.temp matches 2 if score #o ec.temp matches 2 run scoreboard players set #fv ec.temp 1
execute if score #fv ec.temp matches 0 run summon minecraft:frog ~ ~1 ~ {variant:"minecraft:temperate",PersistenceRequired:1b}
execute if score #fv ec.temp matches 1 run summon minecraft:frog ~ ~1 ~ {variant:"minecraft:warm",PersistenceRequired:1b}
execute if score #fv ec.temp matches 2 run summon minecraft:frog ~ ~1 ~ {variant:"minecraft:cold",PersistenceRequired:1b}
particle minecraft:happy_villager ~ ~0.6 ~ 0.5 0.2 0.5 0.02 10
