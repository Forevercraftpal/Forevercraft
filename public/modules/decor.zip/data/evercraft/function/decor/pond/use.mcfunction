# Pond Kit — right-click to ripple the water (Joseph 2026-06-14). Run as the player; emits AT the pond.
execute at @e[type=marker,tag=ec.dec_anchor,nbt={data:{id:"pond_kit"}},distance=..3,sort=nearest,limit=1] run function evercraft:decor/pond/_splash
