# Sawmill — saw with a resolved wood (MACRO: id, cost, name, wood; run as the player)
scoreboard players set #swm_done ec.temp 1
$execute store result score #swm_have ec.temp run clear @s minecraft:$(wood)_planks 0
$execute if score #swm_have ec.temp matches ..$(cost) unless score #swm_have ec.temp matches $(cost) run return run function evercraft:decor/sawmill/gui/saw_short {cost:$(cost),wood:"$(wood)"}
$clear @s minecraft:$(wood)_planks $(cost)
$loot give @s loot evercraft:decor/bp/$(id)_$(wood)
$data modify storage evercraft:notify stage.c set value [{text:"Sawn: ",color:"gray"},{text:"$(wood) $(name)",color:"yellow"},{text:" — sneak + right-click to place it. No further cost.",color:"gray"}]
scoreboard players set #ndur ec.temp 55
function evercraft:util/notify/emit
# Lumberfell XP — sawing IS lumber-craft (Joseph 2026-06-11): cost planks x ordinary
# delta, through the standard affinity pipeline (daily cap + boosts apply inside).
scoreboard players set @s ec.caff_class 2
$scoreboard players set #caff_d ec.temp $(cost)
scoreboard players operation #delta ec.temp = #caff_d ec.temp
scoreboard players operation #delta ec.temp *= #caff_xp3 ec.var
scoreboard players operation @s ec.caff_boost = @s ec.caffb_lf
function evercraft:craft_affinity/internal_grant
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.bamboo_wood.break master @s ~ ~ ~ 0.8 0.8
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 0.5 1.5
