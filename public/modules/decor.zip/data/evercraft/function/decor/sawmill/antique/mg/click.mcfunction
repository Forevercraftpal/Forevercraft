# Antique mini-game — score the strike by where the pointer was, ping by accuracy, then advance.
# Run as the player. Gold sweet zone = fill 70-89; bullseye 72..87 = +4, near = +2, far = +1, else miss.
scoreboard players set #aq_hit ec.temp 0
execute if score @s ec.antq_fill matches 72..87 run scoreboard players set #aq_hit ec.temp 4
execute if score @s ec.antq_fill matches 60..71 run scoreboard players set #aq_hit ec.temp 2
execute if score @s ec.antq_fill matches 88..95 run scoreboard players set #aq_hit ec.temp 2
execute if score @s ec.antq_fill matches 48..59 run scoreboard players set #aq_hit ec.temp 1
execute if score @s ec.antq_fill matches 96..99 run scoreboard players set #aq_hit ec.temp 1
scoreboard players operation @s ec.antq_score += #aq_hit ec.temp
execute if score #aq_hit ec.temp matches 4 if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.7 1.9
execute if score #aq_hit ec.temp matches 1..3 if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.harp master @s ~ ~ ~ 0.6 1.2
execute if score #aq_hit ec.temp matches 0 if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.hat master @s ~ ~ ~ 0.5 0.8
function evercraft:decor/sawmill/antique/mg/advance
