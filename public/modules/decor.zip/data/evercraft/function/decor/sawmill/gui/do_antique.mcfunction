# Sawmill — craft an ANTIQUE (MACRO: id, name, mat_name, wood, req, base; run as the sawing player).
# The rare Antique Material IS the cost (no planks). Gated by Lumberfell STAGE (ec.caffs_lf >= req).
# Consumes one material, emits the shape's blueprint in the material's signature wood, stamped antique
# (material named in gold lore) + bonus Lumberfell XP. All furniture is lumber-craft (class 2).
scoreboard players set #swm_done ec.temp 1
scoreboard players set @s ec.dec_mg_t 600

# --- Lumberfell stage gate. Below req → tell them how far, consume NOTHING. ---
$scoreboard players set #ant_req ec.temp $(req)
$execute if score @s ec.caffs_lf < #ant_req ec.temp run return run function evercraft:decor/sawmill/gui/antique_locked {mat_name:"$(mat_name)",req:$(req)}

# --- Spend one rare material. ---
$clear @s $(base) 1

# --- Stash the pending craft, close the sawmill menu, and launch the Restoration mini-game. The quality
#     (Poor/Standard/Pristine) + the emit + XP + reveal all happen at mg/resolve, set by performance. ---
$data modify storage evercraft:antq pending set value {id:"$(id)",wood:"$(wood)",name:"$(name)",mat_name:"$(mat_name)"}
function evercraft:decor/sawmill/gui/close
function evercraft:decor/sawmill/antique/mg/begin
