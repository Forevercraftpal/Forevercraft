# Sawmill — GUI poll (self-schedules 2t while anyone is sawing)
execute as @a[tag=DEC.Sawing] run scoreboard players remove @s ec.dec_mg_t 2
execute as @a[tag=DEC.Sawing,scores={ec.dec_mg_t=..0}] at @s run function evercraft:decor/sawmill/gui/close
execute as @e[type=interaction,tag=DEC.SWMp0] if data entity @s interaction at @s run function evercraft:decor/sawmill/gui/clicked {id:"stool",cost:2,name:"Stool"}
execute as @e[type=interaction,tag=DEC.SWMp1] if data entity @s interaction at @s run function evercraft:decor/sawmill/gui/clicked {id:"chair",cost:4,name:"Chair"}
execute as @e[type=interaction,tag=DEC.SWMp2] if data entity @s interaction at @s run function evercraft:decor/sawmill/gui/clicked {id:"tea_table",cost:3,name:"Tea Table"}
execute as @e[type=interaction,tag=DEC.SWMp3] if data entity @s interaction at @s run function evercraft:decor/sawmill/gui/clicked {id:"coat_rack",cost:3,name:"Coat Rack"}
execute as @e[type=interaction,tag=DEC.SWMp4] if data entity @s interaction at @s run function evercraft:decor/sawmill/gui/clicked {id:"garden_bench",cost:5,name:"Garden Bench"}
execute as @e[type=interaction,tag=DEC.SWMp5] if data entity @s interaction at @s run function evercraft:decor/sawmill/gui/clicked {id:"writing_desk",cost:4,name:"Writing Desk"}
execute as @e[type=interaction,tag=DEC.SWMp6] if data entity @s interaction at @s run function evercraft:decor/sawmill/gui/clicked {id:"dining_table",cost:6,name:"Dining Table"}
execute as @e[type=interaction,tag=DEC.SWMp7] if data entity @s interaction at @s run function evercraft:decor/sawmill/gui/clicked {id:"wardrobe",cost:6,name:"Wardrobe"}
execute as @e[type=interaction,tag=DEC.SWMx] if data entity @s interaction at @s run function evercraft:decor/sawmill/gui/clicked_close
execute if entity @a[tag=DEC.Sawing] run schedule function evercraft:decor/sawmill/gui/tick 2t replace
