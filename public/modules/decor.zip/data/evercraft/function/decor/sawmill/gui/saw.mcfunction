# Sawmill — saw a piece (MACRO: id, cost, name; run as the sawing player)
# Wood = the planks in the main hand. Charges $(cost) planks, gives the free-to-place
# furnishing variant (decor/bp loot — decor_free:1b; the planks paid here ARE the cost).
scoreboard players set @s ec.dec_mg_t 600
scoreboard players set #swm_done ec.temp 0
# ANTIQUE path first (Joseph 2026-06-14): a held rare Antique Material crafts the antique version of this
# shape (sets #swm_done=1, so the plank branches below skip). Ordinary planks fall through untouched.
$function evercraft:decor/sawmill/gui/saw_antique {id:"$(id)",name:"$(name)"}
$execute if score #swm_done ec.temp matches 0 if items entity @s weapon.mainhand minecraft:oak_planks run function evercraft:decor/sawmill/gui/saw_wood {id:"$(id)",cost:$(cost),name:"$(name)",wood:"oak"}
$execute if score #swm_done ec.temp matches 0 if items entity @s weapon.mainhand minecraft:spruce_planks run function evercraft:decor/sawmill/gui/saw_wood {id:"$(id)",cost:$(cost),name:"$(name)",wood:"spruce"}
$execute if score #swm_done ec.temp matches 0 if items entity @s weapon.mainhand minecraft:birch_planks run function evercraft:decor/sawmill/gui/saw_wood {id:"$(id)",cost:$(cost),name:"$(name)",wood:"birch"}
$execute if score #swm_done ec.temp matches 0 if items entity @s weapon.mainhand minecraft:jungle_planks run function evercraft:decor/sawmill/gui/saw_wood {id:"$(id)",cost:$(cost),name:"$(name)",wood:"jungle"}
$execute if score #swm_done ec.temp matches 0 if items entity @s weapon.mainhand minecraft:acacia_planks run function evercraft:decor/sawmill/gui/saw_wood {id:"$(id)",cost:$(cost),name:"$(name)",wood:"acacia"}
$execute if score #swm_done ec.temp matches 0 if items entity @s weapon.mainhand minecraft:dark_oak_planks run function evercraft:decor/sawmill/gui/saw_wood {id:"$(id)",cost:$(cost),name:"$(name)",wood:"dark_oak"}
$execute if score #swm_done ec.temp matches 0 if items entity @s weapon.mainhand minecraft:mangrove_planks run function evercraft:decor/sawmill/gui/saw_wood {id:"$(id)",cost:$(cost),name:"$(name)",wood:"mangrove"}
$execute if score #swm_done ec.temp matches 0 if items entity @s weapon.mainhand minecraft:cherry_planks run function evercraft:decor/sawmill/gui/saw_wood {id:"$(id)",cost:$(cost),name:"$(name)",wood:"cherry"}
execute if score #swm_done ec.temp matches 0 run data modify storage evercraft:notify stage.c set value [{text:"Hold the planks you want it sawn from.",color:"yellow"}]
execute if score #swm_done ec.temp matches 0 run scoreboard players set #ndur ec.temp 45
execute if score #swm_done ec.temp matches 0 run function evercraft:util/notify/emit
