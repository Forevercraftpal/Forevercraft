# Antique mini-game — start the current stage: reset the sweeping bar + relabel the stage. Run as the player.
scoreboard players set @s ec.antq_fill 0
scoreboard players set @s ec.antq_timer 0
execute if score @s ec.antq_phase matches 1 at @s run data modify entity @e[type=text_display,tag=ANTQ.Phase,distance=..7,limit=1] text set value [{text:"Stage 1: ",color:"gray"},{text:"SHAPE",color:"#D4AF37",bold:true}]
execute if score @s ec.antq_phase matches 2 at @s run data modify entity @e[type=text_display,tag=ANTQ.Phase,distance=..7,limit=1] text set value [{text:"Stage 2: ",color:"gray"},{text:"JOINERY",color:"#D4AF37",bold:true}]
execute if score @s ec.antq_phase matches 3 at @s run data modify entity @e[type=text_display,tag=ANTQ.Phase,distance=..7,limit=1] text set value [{text:"Stage 3: ",color:"gray"},{text:"FINISH",color:"#D4AF37",bold:true}]
