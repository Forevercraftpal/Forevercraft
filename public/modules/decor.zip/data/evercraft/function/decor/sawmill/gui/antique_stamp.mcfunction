# Antique stamp (MACRO: mat_name, q_label, q_eff, q_color). Run AS the freshly-spawned blueprint item
# entity. Recolors the name gold, appends a gold "Antique" line naming the material + a quality line,
# flags the custom_data (antique + antique_mat + antique_eff + antique_quality), and zeroes the pickup
# delay so the piece drops straight to the crafter. antique_eff is the effectiveness multiplier read at
# placement → anchor → the piece's ability handlers: 75 Poor / 100 Standard / 200 Pristine.
data modify entity @s Item.components."minecraft:custom_name".color set value "#D4AF37"
$data modify entity @s Item.components."minecraft:lore" append value {text:"❖ Antique · $(mat_name)",color:"#D4AF37",italic:false}
$data modify entity @s Item.components."minecraft:lore" append value {text:"✦ $(q_label) quality",color:"$(q_color)",italic:false}
data modify entity @s Item.components."minecraft:custom_data".antique set value true
$data modify entity @s Item.components."minecraft:custom_data".antique_mat set value "$(mat_name)"
$data modify entity @s Item.components."minecraft:custom_data".antique_eff set value $(q_eff)
$data modify entity @s Item.components."minecraft:custom_data".antique_quality set value "$(q_label)"
data merge entity @s {PickupDelay:0s}
