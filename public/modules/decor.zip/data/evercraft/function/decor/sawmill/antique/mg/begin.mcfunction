# Antique Restoration mini-game — begin (run as the player; do_antique already closed the sawmill menu
# and stashed the pending craft in storage evercraft:antq pending). Tags ANTQ.Crafting, resets the
# score, paints the bench, starts stage 1, and kicks the self-scheduling tick.
tag @s add ANTQ.Crafting
scoreboard players set @s ec.antq_phase 1
scoreboard players set @s ec.antq_score 0
function evercraft:decor/sawmill/antique/mg/build_menu
function evercraft:decor/sawmill/antique/mg/phase_start
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.bamboo_wood.place master @s ~ ~ ~ 0.6 1.0
schedule function evercraft:decor/sawmill/antique/mg/tick 1t replace
