# Sawmill — reap GUI elements (run as the player)
execute at @s run kill @e[type=text_display,tag=DEC.SWM,distance=..10]
execute at @s run kill @e[type=interaction,tag=DEC.SWM,distance=..10]
