# Sawmill — Dye Block (right-click with dye)
# Run as: the ec.swm_click interaction entity, at its position.
# Mirrors guidestone/dye_block exactly so the texture pipeline stays uniform.
# Base64 values below are PLACEHOLDERS using guidestone's color palette —
# Joseph drops the real sawmill texture strings in when ready.

# Detect which dye the player is holding (writes evercraft:dyeing color_id + name).
execute as @p[distance=..6] run function evercraft:dyeing/detect_color

# Azure
execute if data storage evercraft:dyeing {color_id:"azure"} as @e[type=marker,tag=ec.swm_mk,distance=..2,limit=1] run data modify entity @s data.color set value "azure"
execute if data storage evercraft:dyeing {color_id:"azure"} as @e[type=armor_stand,tag=ec.swm_stand,distance=..2,limit=1] on passengers run data modify entity @s item.components."minecraft:profile".properties[0].value set value "ewogICJ0aW1lc3RhbXAiIDogMTc4MjA1NDM3NTY2OCwKICAicHJvZmlsZUlkIiA6ICIxNTUyNmU1OGZhOWE0NjBmODhhNmZhNjk1M2RlNjgzNyIsCiAgInByb2ZpbGVOYW1lIiA6ICJQaWVkcml0YTE3IiwKICAic2lnbmF0dXJlUmVxdWlyZWQiIDogdHJ1ZSwKICAidGV4dHVyZXMiIDogewogICAgIlNLSU4iIDogewogICAgICAidXJsIiA6ICJodHRwOi8vdGV4dHVyZXMubWluZWNyYWZ0Lm5ldC90ZXh0dXJlLzk0NjQzMTA4ZTFlYTU2MzYxNzYzYWU3MjE5NzhmZjIxMzU3NWYwNTlhNjA0NjZjNmNhYTQzZmRjZWQxZjg3NWEiLAogICAgICAibWV0YWRhdGEiIDogewogICAgICAgICJtb2RlbCIgOiAic2xpbSIKICAgICAgfQogICAgfQogIH0KfQ=="

# Crimson
execute if data storage evercraft:dyeing {color_id:"crimson"} as @e[type=marker,tag=ec.swm_mk,distance=..2,limit=1] run data modify entity @s data.color set value "crimson"
execute if data storage evercraft:dyeing {color_id:"crimson"} as @e[type=armor_stand,tag=ec.swm_stand,distance=..2,limit=1] on passengers run data modify entity @s item.components."minecraft:profile".properties[0].value set value "ewogICJ0aW1lc3RhbXAiIDogMTc4MjA1NDM5MjUxOSwKICAicHJvZmlsZUlkIiA6ICIyZDFhMzI0YjRhNDE0ODJmODNjYzk3YTA2NzY5YjI2ZiIsCiAgInByb2ZpbGVOYW1lIiA6ICJMRUFUSEVSX0xFR0dJTkdTIiwKICAic2lnbmF0dXJlUmVxdWlyZWQiIDogdHJ1ZSwKICAidGV4dHVyZXMiIDogewogICAgIlNLSU4iIDogewogICAgICAidXJsIiA6ICJodHRwOi8vdGV4dHVyZXMubWluZWNyYWZ0Lm5ldC90ZXh0dXJlLzIzMzdjOGM4MTE5MDkxNzZmNDQ1NjhiZjczOWY5NWIyMmExOGQ0NTM4M2NlODBiNTYyOTQ5MzYxYjM3MTQ3ZTQiLAogICAgICAibWV0YWRhdGEiIDogewogICAgICAgICJtb2RlbCIgOiAic2xpbSIKICAgICAgfQogICAgfQogIH0KfQ=="

# Solar
execute if data storage evercraft:dyeing {color_id:"solar"} as @e[type=marker,tag=ec.swm_mk,distance=..2,limit=1] run data modify entity @s data.color set value "solar"
execute if data storage evercraft:dyeing {color_id:"solar"} as @e[type=armor_stand,tag=ec.swm_stand,distance=..2,limit=1] on passengers run data modify entity @s item.components."minecraft:profile".properties[0].value set value "ewogICJ0aW1lc3RhbXAiIDogMTc4MjA1NDQwOTU1OCwKICAicHJvZmlsZUlkIiA6ICJkODBlMGYyNjU2M2U0NzI3YWNiZDNlMmRlNDkxYzFiZSIsCiAgInByb2ZpbGVOYW1lIiA6ICJLQmVsb3plcm92X18iLAogICJzaWduYXR1cmVSZXF1aXJlZCIgOiB0cnVlLAogICJ0ZXh0dXJlcyIgOiB7CiAgICAiU0tJTiIgOiB7CiAgICAgICJ1cmwiIDogImh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvNjlmYjFkYTlkMjU3NmJhNjc0YTk0MDU4MjdjMGQ1MzkyYjkxZTZiZjU4N2FiMDliNTE0YWRlODNjMmVlM2I3YSIsCiAgICAgICJtZXRhZGF0YSIgOiB7CiAgICAgICAgIm1vZGVsIiA6ICJzbGltIgogICAgICB9CiAgICB9CiAgfQp9"

# Verdant
execute if data storage evercraft:dyeing {color_id:"verdant"} as @e[type=marker,tag=ec.swm_mk,distance=..2,limit=1] run data modify entity @s data.color set value "verdant"
execute if data storage evercraft:dyeing {color_id:"verdant"} as @e[type=armor_stand,tag=ec.swm_stand,distance=..2,limit=1] on passengers run data modify entity @s item.components."minecraft:profile".properties[0].value set value "ewogICJ0aW1lc3RhbXAiIDogMTc4MjA1NDQyNjgxMywKICAicHJvZmlsZUlkIiA6ICJkM2VmYjJmMThjMDU0YmRhYTE0OTVlZTY0ZDgxZjdlOCIsCiAgInByb2ZpbGVOYW1lIiA6ICJNTEsxNSIsCiAgInNpZ25hdHVyZVJlcXVpcmVkIiA6IHRydWUsCiAgInRleHR1cmVzIiA6IHsKICAgICJTS0lOIiA6IHsKICAgICAgInVybCIgOiAiaHR0cDovL3RleHR1cmVzLm1pbmVjcmFmdC5uZXQvdGV4dHVyZS83ZTM4N2UyZGRhYjY5YmFjN2FjNTdhNjM3ZGQyYTQyYWQyYTNjYmNhMmUwMWU2ZDlmNWE1NmU2ZWNhZjc5ZWJiIiwKICAgICAgIm1ldGFkYXRhIiA6IHsKICAgICAgICAibW9kZWwiIDogInNsaW0iCiAgICAgIH0KICAgIH0KICB9Cn0="

# Ivory
execute if data storage evercraft:dyeing {color_id:"ivory"} as @e[type=marker,tag=ec.swm_mk,distance=..2,limit=1] run data modify entity @s data.color set value "ivory"
execute if data storage evercraft:dyeing {color_id:"ivory"} as @e[type=armor_stand,tag=ec.swm_stand,distance=..2,limit=1] on passengers run data modify entity @s item.components."minecraft:profile".properties[0].value set value "ewogICJ0aW1lc3RhbXAiIDogMTc4MjA1NDQ0NDAyNSwKICAicHJvZmlsZUlkIiA6ICIyMWUzNjdkNzI1Y2Y0ZTNiYjI2OTJjNGEzMDBhNGRlYiIsCiAgInByb2ZpbGVOYW1lIiA6ICJHZXlzZXJNQyIsCiAgInNpZ25hdHVyZVJlcXVpcmVkIiA6IHRydWUsCiAgInRleHR1cmVzIiA6IHsKICAgICJTS0lOIiA6IHsKICAgICAgInVybCIgOiAiaHR0cDovL3RleHR1cmVzLm1pbmVjcmFmdC5uZXQvdGV4dHVyZS81MTQ3MDAzZTllNmQwNDgwYzdiOTA3ZWY2MWQzNGY2ZTM3N2JhNTcwZmI4Mjk5NTgzYzA2OTI1MjlkNjhlZDRmIiwKICAgICAgIm1ldGFkYXRhIiA6IHsKICAgICAgICAibW9kZWwiIDogInNsaW0iCiAgICAgIH0KICAgIH0KICB9Cn0="

# Obsidian
execute if data storage evercraft:dyeing {color_id:"obsidian"} as @e[type=marker,tag=ec.swm_mk,distance=..2,limit=1] run data modify entity @s data.color set value "obsidian"
execute if data storage evercraft:dyeing {color_id:"obsidian"} as @e[type=armor_stand,tag=ec.swm_stand,distance=..2,limit=1] on passengers run data modify entity @s item.components."minecraft:profile".properties[0].value set value "ewogICJ0aW1lc3RhbXAiIDogMTc4MjA1NDQ3OTA0OCwKICAicHJvZmlsZUlkIiA6ICIyNDY1ODI2NWVjMjg0NTY4YTg3MDJkOTVlYzdlYTc4MyIsCiAgInByb2ZpbGVOYW1lIiA6ICJBcmdvc1oxMiIsCiAgInNpZ25hdHVyZVJlcXVpcmVkIiA6IHRydWUsCiAgInRleHR1cmVzIiA6IHsKICAgICJTS0lOIiA6IHsKICAgICAgInVybCIgOiAiaHR0cDovL3RleHR1cmVzLm1pbmVjcmFmdC5uZXQvdGV4dHVyZS9hMmRhZThiNWM1NTQ3ZWNjNjUxYTY5NjU5NDkxZWI4YjVkYmQwMzdlODMwZmIxMjYwODQxNjAyNzVjY2E3OGNjIiwKICAgICAgIm1ldGFkYXRhIiA6IHsKICAgICAgICAibW9kZWwiIDogInNsaW0iCiAgICAgIH0KICAgIH0KICB9Cn0="

# Rose
execute if data storage evercraft:dyeing {color_id:"rose"} as @e[type=marker,tag=ec.swm_mk,distance=..2,limit=1] run data modify entity @s data.color set value "rose"
execute if data storage evercraft:dyeing {color_id:"rose"} as @e[type=armor_stand,tag=ec.swm_stand,distance=..2,limit=1] on passengers run data modify entity @s item.components."minecraft:profile".properties[0].value set value "ewogICJ0aW1lc3RhbXAiIDogMTc4MjA1NDQ5NzU5NiwKICAicHJvZmlsZUlkIiA6ICIwZmVjMTliNTM1NTQ0MWQ0YmQ1MTE5ZmExMWE2MGIyYiIsCiAgInByb2ZpbGVOYW1lIiA6ICJNb3ZpZVBhcmtNQyIsCiAgInNpZ25hdHVyZVJlcXVpcmVkIiA6IHRydWUsCiAgInRleHR1cmVzIiA6IHsKICAgICJTS0lOIiA6IHsKICAgICAgInVybCIgOiAiaHR0cDovL3RleHR1cmVzLm1pbmVjcmFmdC5uZXQvdGV4dHVyZS8yYmI3ZGU4NjNhMmJiMTc3M2EzY2FhN2M2YzFkODJhZTViYjgyYjlkYWY1YjIzMTY5NDljMTE3ZDc0NTdhMjkxIiwKICAgICAgIm1ldGFkYXRhIiA6IHsKICAgICAgICAibW9kZWwiIDogInNsaW0iCiAgICAgIH0KICAgIH0KICB9Cn0="

# Noir
execute if data storage evercraft:dyeing {color_id:"noir"} as @e[type=marker,tag=ec.swm_mk,distance=..2,limit=1] run data modify entity @s data.color set value "noir"
execute if data storage evercraft:dyeing {color_id:"noir"} as @e[type=armor_stand,tag=ec.swm_stand,distance=..2,limit=1] on passengers run data modify entity @s item.components."minecraft:profile".properties[0].value set value "ewogICJ0aW1lc3RhbXAiIDogMTc4MjA1NDQ2MTg5MiwKICAicHJvZmlsZUlkIiA6ICJkMTQ4NjFiM2UwZmM0Njk5OTFlMTcyNTllMzdiZjZhZCIsCiAgInByb2ZpbGVOYW1lIiA6ICJyYXhpdG9jbCIsCiAgInNpZ25hdHVyZVJlcXVpcmVkIiA6IHRydWUsCiAgInRleHR1cmVzIiA6IHsKICAgICJTS0lOIiA6IHsKICAgICAgInVybCIgOiAiaHR0cDovL3RleHR1cmVzLm1pbmVjcmFmdC5uZXQvdGV4dHVyZS9lOGNlZTkzMGFjOWY4ZTU5MDFlMTY1YTlmNDM4YmIzY2E5YWZiZDJlMjY4MGNjODAwOWY5Nzk3MjAzMzVhMDZjIiwKICAgICAgIm1ldGFkYXRhIiA6IHsKICAgICAgICAibW9kZWwiIDogInNsaW0iCiAgICAgIH0KICAgIH0KICB9Cn0="

# Consume 1 dye from the player's hand (mirrors guidestone/dye_block).
execute as @p[distance=..6] run item modify entity @s weapon.mainhand {"function":"minecraft:set_count","count":-1,"add":true}

# Dye effects + feedback (uses the shared dyeing utilities).
function evercraft:dyeing/effects

data modify storage evercraft:notify stage.c set value [{text:"Dyed ",color:"gray",italic:true},{storage:"evercraft:dyeing",nbt:"color_name",interpret:false,color:"#E0B0FF",italic:true},{text:" Sawmill",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 45
execute as @p[distance=..6] run function evercraft:util/notify/emit
