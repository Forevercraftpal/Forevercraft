# Sawmill — close clicked. @s = the interaction.
data remove entity @s interaction
execute as @p[tag=DEC.Sawing,distance=..8] at @s run function evercraft:decor/sawmill/gui/close
