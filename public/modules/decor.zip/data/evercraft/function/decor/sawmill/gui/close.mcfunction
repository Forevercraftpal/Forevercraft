# Sawmill — close the session (run as the player)
function evercraft:decor/sawmill/gui/close_gui
tag @s remove DEC.Sawing
