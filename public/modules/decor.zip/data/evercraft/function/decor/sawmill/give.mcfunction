# Sawmill — Admin give (testing fixture)
# Run as operator
# Canonical item lives in loot_table/decor/sawmill_item (shared with the Lumberfell
# gathering milestone — craft_affinity/stations/grant_sawmill).
loot give @s loot evercraft:decor/sawmill_item
tellraw @s [{text:"Gave a ",color:"gray"},{text:"Sawmill",color:"yellow"},{text:".",color:"gray"}]
