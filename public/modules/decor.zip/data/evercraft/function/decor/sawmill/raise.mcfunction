# Sawmill — raise the station (run positioned at the barrel's block corner)
scoreboard players set #swm_rc ec.var 0
setblock ~ ~ ~ minecraft:air
summon marker ~0.5 ~ ~0.5 {Tags:["ec.swm_mk"]}
summon interaction ~0.5 ~ ~0.5 {Tags:["ec.swm_click"],width:1.6f,height:1.2f,response:1b}
execute positioned ~0.5 ~ ~0.5 run function evercraft:decor/sawmill/build
playsound minecraft:block.wood.place master @a[distance=..12,scores={ec.fx_snd=1..}] ~ ~ ~ 0.8 0.9
data modify storage evercraft:notify stage.c set value [{text:"The sawmill is up — right-click it holding the wood you want furniture from.",color:"gray"}]
scoreboard players set #ndur ec.temp 60
function evercraft:util/notify/emit
