# Antique mini-game tick — advance the active stage for each crafter; self-schedules while any exist.
# Scheduled (server context) by mg/begin; existence-gated so it stops when nobody is crafting.
execute as @a[tag=ANTQ.Crafting] at @s run function evercraft:decor/sawmill/antique/mg/phase_tick
execute if entity @a[tag=ANTQ.Crafting] run schedule function evercraft:decor/sawmill/antique/mg/tick 1t replace
