# Sawmill — not enough planks (MACRO: cost, wood)
$data modify storage evercraft:notify stage.c set value [{text:"Needs $(cost) $(wood) planks — you are short.",color:"yellow"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
