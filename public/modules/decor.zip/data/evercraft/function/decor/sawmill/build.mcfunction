# Sawmill — single-block display (Joseph 2026-06-12 Option B refactor)
# Replaces the previous multi-piece carriage/blade/log composite with a single
# armor_stand + player_head passenger, matching the guidestone/guildstone block
# convention. The head skin Base64 is the "default" sawmill tier — dye_block.
# mcfunction swaps it on dye-application (8 colors, mirrors guidestone palette).
#
# Run positioned at the station center, ground Y.
# ──────────────────────────────────────────────────────────────────────────────
# NOTE on the Base64 below: use the real sawmill skin minted via MineSkin 2026-06-21
# (_council/2026-06-21-sawmill-skin/). Replace the `value` string here and
# in dye_block.mcfunction (one per color) to ship the final look.
summon armor_stand ~ ~ ~0 {Tags:["ec.swm_stand","ec.swm_disp","ec.block_new","smithed.entity"],NoGravity:true,Invisible:true,Small:true,Invulnerable:true,DisabledSlots:4144959,Passengers:[{id:"minecraft:item_display",Tags:["ec.swm_disp","smithed.entity"],brightness:{sky:15,block:15},view_range:1f,width:0f,height:0f,item_display:"head",transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0.0f,0.05f,0.0f],scale:[2.05f,2.1f,2.05f]},item:{id:"minecraft:player_head",count:1,components:{"minecraft:profile":{id:[I;-1974477980,147736616,-1635819972,23806684],properties:[{name:"textures",value:"ewogICJ0aW1lc3RhbXAiIDogMTc4MjA1NDM1ODU1MCwKICAicHJvZmlsZUlkIiA6ICI2NGRiNmMwNTliOTk0OTM2YTY0M2QwODEwODE0ZmJkMyIsCiAgInByb2ZpbGVOYW1lIiA6ICJUaGVTaWx2ZXJEcmVhbXMiLAogICJzaWduYXR1cmVSZXF1aXJlZCIgOiB0cnVlLAogICJ0ZXh0dXJlcyIgOiB7CiAgICAiU0tJTiIgOiB7CiAgICAgICJ1cmwiIDogImh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvYWE5NTU1N2NiYjQ2ODNjYTE3MjQwYzUzMWQ1ZGVlOWQ2MTliNDgxMmY1OWYwOTc2OWE0N2E1NmU5MTcxM2JlZSIsCiAgICAgICJtZXRhZGF0YSIgOiB7CiAgICAgICAgIm1vZGVsIiA6ICJzbGltIgogICAgICB9CiAgICB9CiAgfQp9"}]}}}}]}

# Rotate display to face the placing player (@p — fresh placement context)
execute store result score #swm_rot ec.var run data get entity @p Rotation[0]
execute if score #swm_rot ec.var matches -45..44 as @e[type=armor_stand,tag=ec.block_new,limit=1] on passengers run data modify entity @s transformation.left_rotation set value [0f,1f,0f,0f]
execute if score #swm_rot ec.var matches 45..134 as @e[type=armor_stand,tag=ec.block_new,limit=1] on passengers run data modify entity @s transformation.left_rotation set value [0f,0.7071f,0f,-0.7071f]
execute if score #swm_rot ec.var matches -134..-45 as @e[type=armor_stand,tag=ec.block_new,limit=1] on passengers run data modify entity @s transformation.left_rotation set value [0f,0.7071f,0f,0.7071f]
tag @e[type=armor_stand,tag=ec.block_new,limit=1] remove ec.block_new

# Stamp the default color on the station marker so dye_block can mutate it.
data modify entity @e[type=marker,tag=ec.swm_mk,distance=..2,limit=1,sort=nearest] data.color set value "amethyst"
