# Sawmill — antique gate not met (MACRO: mat_name, req). Run as the player. No material is consumed.
$data modify storage evercraft:notify stage.c set value [{text:"Reach ",color:"gray"},{text:"Lumberfell stage $(req)",color:"#C25E43"},{text:" to work ",color:"gray"},{text:"$(mat_name)",color:"#D4AF37"},{text:" into antiques.",color:"gray"}]
scoreboard players set #ndur ec.temp 55
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 0.5 0.7
