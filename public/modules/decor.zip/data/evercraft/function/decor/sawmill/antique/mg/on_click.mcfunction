# Antique mini-game — STRIKE clicked (run as the interaction cube). Route to the scorer as the nearest
# crafting player (the one at this bench).
data remove entity @s interaction
execute as @a[tag=ANTQ.Crafting,distance=..5,limit=1,sort=nearest] at @s run function evercraft:decor/sawmill/antique/mg/click
