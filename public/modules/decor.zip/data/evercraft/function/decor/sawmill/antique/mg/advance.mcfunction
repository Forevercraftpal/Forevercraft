# Antique mini-game — move to the next stage, or resolve after stage 3. Run as the player.
scoreboard players add @s ec.antq_phase 1
execute if score @s ec.antq_phase matches 2..3 run function evercraft:decor/sawmill/antique/mg/phase_start
execute if score @s ec.antq_phase matches 4.. run function evercraft:decor/sawmill/antique/mg/resolve
