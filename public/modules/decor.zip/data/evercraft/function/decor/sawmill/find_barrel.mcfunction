# Sawmill — stepped ray to the just-placed station barrel (mirrors crate raycast idiom)
scoreboard players add #swm_rc ec.var 1
execute if block ~ ~ ~ minecraft:barrel if data block ~ ~ ~ {components:{"minecraft:custom_data":{sawmill_station:1b}}} align xyz run return run function evercraft:decor/sawmill/raise
execute if score #swm_rc ec.var matches ..40 positioned ^ ^ ^0.25 run return run function evercraft:decor/sawmill/find_barrel
scoreboard players set #swm_rc ec.var 0
