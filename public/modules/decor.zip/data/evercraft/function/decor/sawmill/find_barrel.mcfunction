# Sawmill — stepped ray to the just-placed stonecutter station (guidestone raycast idiom).
# The station ITEM is a stonecutter (thematically-accurate held texture); the placed block is
# NOT a block-entity, so we can't read custom_data off it. Detect by block type + "no sawmill
# marker here yet" (so the ray skips any already-raised sawmill it passes through), then raise()
# swaps the stonecutter for an invisible barrier + the head display.
scoreboard players add #swm_rc ec.var 1
execute align xyz if block ~ ~ ~ minecraft:stonecutter unless entity @e[type=marker,tag=ec.swm_mk,dx=0,dy=0,dz=0,limit=1] run return run function evercraft:decor/sawmill/raise
# Back-compat: a pre-update Sawmill ITEM is still a barrel (block-entity) — detect it by custom_data.
execute align xyz if block ~ ~ ~ minecraft:barrel if data block ~ ~ ~ {components:{"minecraft:custom_data":{sawmill_station:1b}}} unless entity @e[type=marker,tag=ec.swm_mk,dx=0,dy=0,dz=0,limit=1] run return run function evercraft:decor/sawmill/raise
execute if score #swm_rc ec.var matches ..40 positioned ^ ^ ^0.25 run return run function evercraft:decor/sawmill/find_barrel
scoreboard players set #swm_rc ec.var 0
