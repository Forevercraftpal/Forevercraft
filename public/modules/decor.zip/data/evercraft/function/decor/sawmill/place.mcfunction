# Sawmill — placement handler (run as the placer; raycast to the placed stonecutter like
# the guidestone pipeline, then swap it for an invisible barrier + display + marker + interaction).
advancement revoke @s only evercraft:decor/sawmill_place
execute anchored eyes positioned ^ ^ ^ run function evercraft:decor/sawmill/find_barrel
