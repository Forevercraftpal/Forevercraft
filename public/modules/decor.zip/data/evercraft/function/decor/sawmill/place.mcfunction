# Sawmill — placement handler (run as the placer; raycast to the placed barrel like
# the crate pipeline, then swap it for the display composite + marker + interaction).
advancement revoke @s only evercraft:decor/sawmill_place
execute anchored eyes positioned ^ ^ ^ run function evercraft:decor/sawmill/find_barrel
