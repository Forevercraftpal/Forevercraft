# Sawmill — [Saw] clicked (MACRO: id, cost, name). @s = the interaction, at it.
data remove entity @s interaction
$execute as @p[tag=DEC.Sawing,distance=..8] run function evercraft:decor/sawmill/gui/saw {id:"$(id)",cost:$(cost),name:"$(name)"}
