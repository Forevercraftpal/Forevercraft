# Antique mini-game — emit the stamped blueprint + the result line. MACRO (storage evercraft:antq
# pending): id, wood, name, mat_name, q_label, q_eff, q_color. Run as the player.
$function evercraft:decor/antique/spawn_stamped {id:"$(id)",mat:"$(wood)",mat_name:"$(mat_name)",q_label:"$(q_label)",q_eff:$(q_eff),q_color:"$(q_color)"}
$data modify storage evercraft:notify stage.c set value [{text:"$(q_label) antique sawn: ",color:"$(q_color)"},{text:"$(mat_name) $(name)",color:"#D4AF37"},{text:" — sneak + right-click to place it.",color:"gray"}]
scoreboard players set #ndur ec.temp 60
function evercraft:util/notify/emit
