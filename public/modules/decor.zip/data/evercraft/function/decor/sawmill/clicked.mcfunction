# Sawmill — station clicked (run as the ec.swm_click interaction, at it)
# Public station: nearest player opens the menu. Clear-trigger-first idiom.
data remove entity @s interaction
data remove entity @s attack

# --- Dye intercept (Joseph 2026-06-12 Option B refactor) ---
# Holding a dye → recolor the sawmill block (guidestone-style 8-color palette).
# Returns BEFORE the GUI open so the dye click never falls through to crafting.
execute as @p[distance=..6] if items entity @s weapon.mainhand #evercraft:dyes run return run function evercraft:decor/sawmill/dye_block

execute as @p[distance=..6] at @s run function evercraft:decor/sawmill/gui/open
