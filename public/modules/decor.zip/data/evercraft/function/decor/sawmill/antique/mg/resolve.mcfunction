# Antique mini-game — resolve. Performance (ec.antq_score 0-12, the main driver) + Lumberfell skill
# (level/20, cap +5) set the tier: <=3 Poor / 4-8 Standard / 9+ Pristine. Emits the stamped piece,
# pays bonus Lumberfell XP, reaps the bench. Run as the player.
scoreboard players operation #aq_total ec.temp = @s ec.antq_score
scoreboard players operation #aq_lf ec.temp = @s ec.caffl_lf
scoreboard players operation #aq_lf ec.temp /= #aq_c20 ec.var
execute if score #aq_lf ec.temp matches 6.. run scoreboard players set #aq_lf ec.temp 5
scoreboard players operation #aq_total ec.temp += #aq_lf ec.temp

# Tier → quality fields on the pending craft (default Standard).
data modify storage evercraft:antq pending.q_label set value "Standard"
data modify storage evercraft:antq pending.q_eff set value 100
data modify storage evercraft:antq pending.q_color set value "gray"
execute if score #aq_total ec.temp matches ..3 run data modify storage evercraft:antq pending.q_label set value "Poor"
execute if score #aq_total ec.temp matches ..3 run data modify storage evercraft:antq pending.q_eff set value 75
execute if score #aq_total ec.temp matches ..3 run data modify storage evercraft:antq pending.q_color set value "#8A8A8A"
execute if score #aq_total ec.temp matches 9.. run data modify storage evercraft:antq pending.q_label set value "Pristine"
execute if score #aq_total ec.temp matches 9.. run data modify storage evercraft:antq pending.q_eff set value 200
execute if score #aq_total ec.temp matches 9.. run data modify storage evercraft:antq pending.q_color set value "#5EE6C0"

# Emit the stamped blueprint + the result line.
function evercraft:decor/sawmill/antique/mg/emit with storage evercraft:antq pending

# Bonus Lumberfell XP (the craft itself), through the affinity pipeline (cap + boosts inside).
scoreboard players set @s ec.caff_class 2
scoreboard players set #delta ec.temp 20
scoreboard players operation @s ec.caff_boost = @s ec.caffb_lf
function evercraft:craft_affinity/internal_grant

# Result cue by tier (note-block palette, FX-gated).
execute if score #aq_total ec.temp matches 9.. if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.8 2.0
execute if score #aq_total ec.temp matches 9.. if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.chime master @s ~ ~ ~ 0.6 1.5
execute if score #aq_total ec.temp matches 4..8 if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.harp master @s ~ ~ ~ 0.7 1.3
execute if score #aq_total ec.temp matches ..3 if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 0.6 0.8
execute if score @s ec.fx_vis matches 1.. run particle minecraft:wax_on ~ ~1 ~ 0.3 0.3 0.3 0 14

# Reap the bench + reset state.
kill @e[type=interaction,tag=ANTQ.MG,distance=..16]
kill @e[type=text_display,tag=ANTQ.MG,distance=..16]
scoreboard players set @s ec.antq_phase 0
tag @s remove ANTQ.Crafting
