# Antique mini-game — per-tick for one crafter (run as the player, at them): sweep the bar, render it,
# auto-advance at the end (a missed stage = 0 points), otherwise poll the STRIKE button.
scoreboard players add @s ec.antq_fill 2
function evercraft:decor/sawmill/antique/mg/render_bar
execute if score @s ec.antq_fill matches 100.. run return run function evercraft:decor/sawmill/antique/mg/advance
execute as @e[type=interaction,tag=ANTQ.Btn,distance=..5] if data entity @s interaction run function evercraft:decor/sawmill/antique/mg/on_click
