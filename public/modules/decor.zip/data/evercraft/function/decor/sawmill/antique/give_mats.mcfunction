# Antique Materials — admin give (testing fixture).
# Run as: a player. Usage: function evercraft:decor/sawmill/antique/give_mats
# Hands one of each of the five Antique Materials so the sawmill's antique path can be exercised
# without farming the source nodes. Heartwood is the lumberfell material (its own loot table).
loot give @s loot evercraft:bough/lumberfell/heartwood_log
loot give @s loot evercraft:antique_mat/deepvein
loot give @s loot evercraft:antique_mat/riverpearl
loot give @s loot evercraft:antique_mat/amberbloom
loot give @s loot evercraft:antique_mat/heirloom
tellraw @s [{text:"[admin] ",color:"dark_gray"},{text:"Gave 5 Antique Materials. ",color:"gray"},{text:"Hold one at a sawmill and press a [Saw].",color:"#D4AF37"}]
