# Furnishings — Lamentor reclaim ladder (MACRO; run AS the remover; SPEC §5, B2 mutually-exclusive, B7 voice)
# Args (storage temp): id, mat, item (the stashed original item snapshot), + uid/owner/inzone (unused here).
# Decides what the remover gets back from reclaiming this furnishing, by their LAMENTOR CLASS STAGE
# (ec.caffs_lm — the persistent class rank, NOT ec.caff_sigtier which only reads nonzero while holding an
# awakened/spirit tool; a plain pair of shears would zero sigtier even for a master Lamentor, breaking the
# perk). Established Lamentor thresholds (craft_affinity/detect_ordinary_tool, abilities/check_player):
#   ec.caffs_lm  <2  → NOT a Lamentor (or too early): the furnishing was undone by force. Nothing returned.
#   ec.caffs_lm 2..3 → Lamentor (abilities-unlocked, pre-signature): scaled Lamentor XP + 50% material recovery.
#   ec.caffs_lm  >=4 → Lamentor at SIGNATURE rank: XP + the intact furnishing item back (clean reclamation),
#                      NO material refund (item-return and mats are MUTUALLY EXCLUSIVE — B2).
# Voice is always "reclaim / recover / preserve", never "unmake / destroy" (B7 — the Lamentor is a
# Silk-Touch preservation class).

# === BRANCH A — NOT a Lamentor (ec.caffs_lm < 2): the piece is gone, nothing is recovered. ===
execute unless score @s ec.caffs_lm matches 2.. run function evercraft:decor/lament/none
execute unless score @s ec.caffs_lm matches 2.. run return 0

# === Lamentor XP (both Lamentor tiers earn it). Scaled-DOWN clone of craft_affinity/on_shear_sheep:
#     a sheep-shear grants 9; reclaiming a furnishing is a one-off act, so 4 (~half), tier-scaled by the
#     held shears' artifact tier via the shared apply_tier_xp → internal_grant (daily cap + Artisan feed). ===
scoreboard players set @s ec.caff_class 6
scoreboard players set #delta ec.temp 4
function evercraft:craft_affinity/apply_tier_xp
function evercraft:craft_affinity/internal_grant

# === BRANCH C — SIGNATURE Lamentor (>=4): return the intact item (with counted:true), NO mats (B2). ===
# Guard on a stashed snapshot existing (it always does for W3-placed pieces; a legacy pre-W3 anchor has
# no data.item → fall through to the 50% material recovery below so the reclaim still yields something).
execute if score @s ec.caffs_lm matches 4.. if data storage evercraft:decor temp.item run function evercraft:decor/lament/return_item with storage evercraft:decor temp
execute if score @s ec.caffs_lm matches 4.. if data storage evercraft:decor temp.item run return 0

# === BRANCH B — lower-tier Lamentor (2..3), OR a signature Lamentor on a legacy (no-snapshot) piece:
#     50% material recovery, item NOT returned (B2 mutual exclusion preserved — only one branch pays). ===
# FREE-BUILT pieces (Blueprint placements, anchor data.free:1b) consumed NO materials, so there is
# nothing material to recover — refunding them would mint resources from thin air (Ideas/Blueprints
# economy, 2026-06-09). The Lamentor XP above still pays; legacy anchors lack data.free → refund runs.
execute if data storage evercraft:decor temp{free:1b} run data modify storage evercraft:notify stage.c set value [{text:"The blueprint's work dissolves — no materials to recover.",color:"gray"}]
execute if data storage evercraft:decor temp{free:1b} run scoreboard players set #ndur ec.temp 40
execute if data storage evercraft:decor temp{free:1b} run return run function evercraft:util/notify/emit
function evercraft:decor/refund/macro_route with storage evercraft:decor temp
data modify storage evercraft:notify stage.c set value [{text:"You reclaimed some materials from the furnishing.",color:"green"}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit
