# Bookshelf Nook — toggle one chiseled slot (Joseph 2026-06-13, task #103)
# Macro args (storage evercraft:books p):
#   uid   (int)    — anchor's ec.dec_uid score, identifies THIS instance
#   core  (string) — "lower" or "upper"
#   vslot (int 0-5) — vanilla chiseled slot index on the chosen core
#   state (string) — "true" (book in) or "false" (book out)

$data modify entity @e[type=block_display,tag=ec.shelf_core_$(core),scores={ec.dec_uid=$(uid)},limit=1] block_state.Properties.slot_$(vslot)_occupied set value "$(state)"
