# Bookshelf Nook — spawn ONE visible title plate at slot $(slot) IF that slot is filled (MACRO; run
# as the anchor). Args (storage evercraft:books nm): face, slot, ox/oy/oz. Empty slots spawn nothing
# (the follow-up lines harmlessly no-op when there's no fresh plate). The plate carries its uid + its
# slot index (ec.shelf_pslot) so the withdraw gaze can tell which book you're looking at.
$execute if data entity @s data.books[$(slot)].id rotated $(face) 0 positioned ^$(ox) ^$(oy) ^$(oz) run summon text_display ~ ~ ~ {Tags:["ec.shelf_name","ec.shelf_s$(slot)","ec.shelf_new"],billboard:"vertical",background:0,see_through:true,brightness:{sky:15,block:15},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.3f,0.3f,0.3f]}}
$data modify entity @e[type=text_display,tag=ec.shelf_new,limit=1] text set from entity @s data.names[$(slot)]
scoreboard players operation @e[type=text_display,tag=ec.shelf_new] ec.dec_uid = @s ec.dec_uid
$scoreboard players set @e[type=text_display,tag=ec.shelf_new] ec.shelf_pslot $(slot)
tag @e[type=text_display,tag=ec.shelf_new] remove ec.shelf_new
