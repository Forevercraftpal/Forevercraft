# Bookshelf Nook — spawn ONE gaze probe at slot $(slot) IF it's empty (MACRO; run as the anchor).
# Args (storage evercraft:books nm): face, slot, ox/oy/oz. A probe is an invisible marker at the
# slot, tagged ec.shelf_probe with its slot index in ec.shelf_pslot; the deposit gaze finds the
# nearest one. Only empty slots get a probe (you can't deposit into a filled slot).
$execute unless data entity @s data.books[$(slot)].id rotated $(face) 0 positioned ^$(ox) ^$(oy) ^$(oz) run summon marker ~ ~ ~ {Tags:["ec.shelf_probe","ec.shelf_probe_new"]}
$execute as @e[type=marker,tag=ec.shelf_probe_new] run scoreboard players set @s ec.shelf_pslot $(slot)
tag @e[type=marker,tag=ec.shelf_probe_new] remove ec.shelf_probe_new
