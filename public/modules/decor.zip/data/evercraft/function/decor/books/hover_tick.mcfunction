# Bookshelf Nook — lazy hover-name tick (Joseph 2026-06-14, task #103; lazy rework 2026-06-14)
# 4s self-rescheduling, existence-gated to bookshelf_nook anchors. Titles are NOT baked onto every
# nook — they're built ONLY for a shelf a player is actually gazing at, and torn down when no one
# is looking. So a server full of libraries costs ~nothing at rest: entities exist only for the
# handful of shelves being read right now, and there is no per-tick opacity sweep. Scales to 25+.
#   - ec.shelf_viewed : transient per-pass "a player's gaze crosses this shelf" tag (set by _gaze_probe)
#   - ec.shelf_named  : persistent "this shelf currently has its title plates spawned" tag
execute unless entity @e[type=marker,tag=ec.dec_anchor,nbt={data:{id:"bookshelf_nook"}},limit=1] run return run schedule function evercraft:decor/books/hover_tick 60s replace
# 1. clear last pass's view tags.
tag @e[type=marker,tag=ec.dec_anchor,tag=ec.shelf_viewed] remove ec.shelf_viewed
# 2. gaze scan: only players within 6b of a nook ray-step their eye-line (tags viewed shelves).
execute as @a[gamemode=!spectator] at @s if entity @e[type=marker,tag=ec.dec_anchor,nbt={data:{id:"bookshelf_nook"}},distance=..6] run function evercraft:decor/books/_gaze_probe
# 3. build plates for shelves newly being looked at; tear them down for shelves no longer looked at.
execute as @e[type=marker,tag=ec.dec_anchor,nbt={data:{id:"bookshelf_nook"}},tag=ec.shelf_viewed,tag=!ec.shelf_named] at @s run function evercraft:decor/books/_name_build
execute as @e[type=marker,tag=ec.dec_anchor,nbt={data:{id:"bookshelf_nook"}},tag=!ec.shelf_viewed,tag=ec.shelf_named] at @s run function evercraft:decor/books/_name_teardown
schedule function evercraft:decor/books/hover_tick 4s replace
