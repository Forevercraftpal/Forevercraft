# Bookshelf Nook — guarantee data.books/names are exactly 12 elements (slot-indexed model). Run as
# the anchor. Empty slot = {} (books) / "" (names); a filled slot is the item NBT / its title.
# Migration-safe: an old contiguous list (N<12 entries) is PADDED to 12, so existing books keep
# their slots 0..N-1. Called at the top of deposit + withdraw so the model is always 12-wide.
execute unless data entity @s data.books run data modify entity @s data.books set value []
execute unless data entity @s data.names run data modify entity @s data.names set value []
function evercraft:decor/books/_pad_slots
