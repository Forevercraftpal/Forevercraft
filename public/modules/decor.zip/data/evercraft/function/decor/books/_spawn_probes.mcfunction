# Bookshelf Nook — spawn a gaze probe at each EMPTY slot (run as the anchor). Deposit uses these to
# let you place into the empty slot you're looking at (empty slots have no title plate to target).
# Recurses #pb_i 0..11; _probe_at spawns a marker only for slots that are currently empty. Probes
# are killed right after the gaze read (one tick), so there's no standing entity cost.
execute if score #pb_i ec.temp matches 12.. run return 0
scoreboard players operation #slot_i ec.temp = #pb_i ec.temp
function evercraft:decor/books/_slot_offset
data modify storage evercraft:books nm.face set from entity @s data.face
execute store result storage evercraft:books nm.slot int 1 run scoreboard players get #pb_i ec.temp
function evercraft:decor/books/_probe_at with storage evercraft:books nm
scoreboard players add #pb_i ec.temp 1
function evercraft:decor/books/_spawn_probes
