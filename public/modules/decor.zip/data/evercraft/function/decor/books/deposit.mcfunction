# Bookshelf Nook — deposit (slot-indexed, gaze-targeted to an empty slot). Run as the clicking owner.
# Prep the anchor (12-slot model + empty-slot gaze probes), ray-step the player's eye-line to the
# nearest empty-slot probe (-> #b_target), then hand control to the anchor to write the book in.
# Anchor-find at reach distance + sort=nearest (the nook you're looking at).
scoreboard players set #b_target ec.temp -1
execute as @e[type=marker,tag=ec.dec_anchor,distance=..4.5,limit=1,sort=nearest] if data entity @s data{id:"bookshelf_nook"} at @s run function evercraft:decor/books/_prep_deposit
execute at @s anchored eyes positioned ^ ^ ^0.6 run function evercraft:decor/books/_probe_find
execute if score #b_target ec.temp matches -1 at @s anchored eyes positioned ^ ^ ^1.0 run function evercraft:decor/books/_probe_find
execute if score #b_target ec.temp matches -1 at @s anchored eyes positioned ^ ^ ^1.4 run function evercraft:decor/books/_probe_find
execute if score #b_target ec.temp matches -1 at @s anchored eyes positioned ^ ^ ^1.8 run function evercraft:decor/books/_probe_find
execute if score #b_target ec.temp matches -1 at @s anchored eyes positioned ^ ^ ^2.2 run function evercraft:decor/books/_probe_find
execute if score #b_target ec.temp matches -1 at @s anchored eyes positioned ^ ^ ^2.6 run function evercraft:decor/books/_probe_find
execute if score #b_target ec.temp matches -1 at @s anchored eyes positioned ^ ^ ^3.0 run function evercraft:decor/books/_probe_find
execute as @e[type=marker,tag=ec.dec_anchor,distance=..4.5,limit=1,sort=nearest] if data entity @s data{id:"bookshelf_nook"} at @s run function evercraft:decor/books/_do_deposit
