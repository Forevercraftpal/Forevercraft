# Bookshelf Nook — at this gaze step, grab the nearest EMPTY-slot probe if one is within reach.
# Run at a point along the depositor's eye-line. First probe within ~0.3b wins (#b_target stays -1
# until then). Radius tunable (shared feel with the withdraw gaze + the plate offsets).
execute if score #b_target ec.temp matches -1 as @e[type=marker,tag=ec.shelf_probe,distance=..0.3,sort=nearest,limit=1] run scoreboard players operation #b_target ec.temp = @s ec.shelf_pslot
