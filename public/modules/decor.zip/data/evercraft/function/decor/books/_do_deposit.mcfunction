# Bookshelf Nook — deposit, anchor-bound (slot-indexed, Joseph 2026-06-14 phase 2). Run as the
# anchor, at it. Places the held book into the EMPTY slot you're looking at (#b_target, set by the
# deposit gaze), or the first empty slot if your gaze wasn't on one. Slots are independent — empties
# stay empty (gaps allowed). _prep_deposit already ran _ensure_slots + spawned the probes.

# Done with the gaze probes.
kill @e[type=marker,tag=ec.shelf_probe,distance=..6]

# Resolve the target: gazed empty slot (#b_target>=0) or the first empty slot.
scoreboard players operation #b_slot ec.temp = #b_target ec.temp
execute if score #b_target ec.temp matches ..-1 run function evercraft:decor/books/_find_empty
# Shelf full -> politely refuse.
execute if score #b_slot ec.temp matches ..-1 run return run function evercraft:decor/books/notify_full

# Write the book into #b_slot.
execute store result storage evercraft:books d.slot int 1 run scoreboard players get #b_slot ec.temp
function evercraft:decor/books/_deposit_slot with storage evercraft:books d

# Light that slot's chiseled face.
execute store result storage evercraft:books p.uid int 1 run scoreboard players get @s ec.dec_uid
data modify storage evercraft:books p.state set value "true"
execute if score #b_slot ec.temp matches 0..5 run data modify storage evercraft:books p.core set value "lower"
execute if score #b_slot ec.temp matches 6..11 run data modify storage evercraft:books p.core set value "upper"
scoreboard players operation #b_vslot ec.temp = #b_slot ec.temp
execute if score #b_slot ec.temp matches 6..11 run scoreboard players remove #b_vslot ec.temp 6
execute store result storage evercraft:books p.vslot int 1 run scoreboard players get #b_vslot ec.temp
function evercraft:decor/books/_set_slot with storage evercraft:books p

# Shrink the held stack, refresh title plates, notify + sound.
item modify entity @p[distance=..5] weapon.mainhand evercraft:decor/shrink_one
function evercraft:decor/books/_name_teardown
data modify storage evercraft:notify stage.c set value [{text:"📖 ",color:"gold"},{text:"Shelved.",color:"yellow"}]
scoreboard players set #ndur ec.temp 25
execute as @p[distance=..5] run function evercraft:util/notify/emit
execute as @p[distance=..5,scores={ec.fx_snd=1..}] at @s run playsound minecraft:item.book.put master @s ~ ~ ~ 0.7 1.0
