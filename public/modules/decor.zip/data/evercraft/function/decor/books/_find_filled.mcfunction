# Bookshelf Nook — set #b_target to the first FILLED slot in TOP-RIGHT-FIRST order (run as the
# anchor), or leave it -1 if empty. Withdraw's fallback when the gaze didn't land on a book, so a
# click returns the top-most book first (matches the deposit fill order: 8,7,6 / 11,10,9 / 2,1,0 /
# 5,4,3). Each line only fires while #b_target is still -1.
execute if score #b_target ec.temp matches -1 if data entity @s data.books[8].id run scoreboard players set #b_target ec.temp 8
execute if score #b_target ec.temp matches -1 if data entity @s data.books[7].id run scoreboard players set #b_target ec.temp 7
execute if score #b_target ec.temp matches -1 if data entity @s data.books[6].id run scoreboard players set #b_target ec.temp 6
execute if score #b_target ec.temp matches -1 if data entity @s data.books[11].id run scoreboard players set #b_target ec.temp 11
execute if score #b_target ec.temp matches -1 if data entity @s data.books[10].id run scoreboard players set #b_target ec.temp 10
execute if score #b_target ec.temp matches -1 if data entity @s data.books[9].id run scoreboard players set #b_target ec.temp 9
execute if score #b_target ec.temp matches -1 if data entity @s data.books[2].id run scoreboard players set #b_target ec.temp 2
execute if score #b_target ec.temp matches -1 if data entity @s data.books[1].id run scoreboard players set #b_target ec.temp 1
execute if score #b_target ec.temp matches -1 if data entity @s data.books[0].id run scoreboard players set #b_target ec.temp 0
execute if score #b_target ec.temp matches -1 if data entity @s data.books[5].id run scoreboard players set #b_target ec.temp 5
execute if score #b_target ec.temp matches -1 if data entity @s data.books[4].id run scoreboard players set #b_target ec.temp 4
execute if score #b_target ec.temp matches -1 if data entity @s data.books[3].id run scoreboard players set #b_target ec.temp 3
