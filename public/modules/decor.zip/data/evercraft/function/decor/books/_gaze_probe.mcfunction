# Bookshelf Nook — ray-step THIS player's gaze, tagging any nook anchor it crosses (run as the
# player, at them). Called by hover_tick ONLY for players within 6b of a nook (perf retrofit L2),
# so the 4-step ray cast doesn't run for everyone every 4s.
execute anchored eyes positioned ^ ^ ^1 run tag @e[type=marker,tag=ec.dec_anchor,nbt={data:{id:"bookshelf_nook"}},distance=..2] add ec.shelf_viewed
execute anchored eyes positioned ^ ^ ^1.7 run tag @e[type=marker,tag=ec.dec_anchor,nbt={data:{id:"bookshelf_nook"}},distance=..2] add ec.shelf_viewed
execute anchored eyes positioned ^ ^ ^2.4 run tag @e[type=marker,tag=ec.dec_anchor,nbt={data:{id:"bookshelf_nook"}},distance=..2] add ec.shelf_viewed
execute anchored eyes positioned ^ ^ ^3.1 run tag @e[type=marker,tag=ec.dec_anchor,nbt={data:{id:"bookshelf_nook"}},distance=..2] add ec.shelf_viewed
