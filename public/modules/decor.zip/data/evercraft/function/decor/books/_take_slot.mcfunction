# Bookshelf Nook — if slot $(slot) is filled, copy its book onto the waiting return-item and EMPTY
# that slot (gap stays — slot-indexed, no compaction). Sets #b_got=1 on success so the caller knows
# whether a book was actually handed back. MACRO; run as the anchor. Args (storage books g): slot.
$execute if data entity @s data.books[$(slot)].id run scoreboard players set #b_got ec.temp 1
$execute if score #b_got ec.temp matches 1 run data modify entity @e[type=item,tag=ec.shelf_give,limit=1] Item set from entity @s data.books[$(slot)]
$execute if score #b_got ec.temp matches 1 run data modify entity @s data.books[$(slot)] set value {}
$execute if score #b_got ec.temp matches 1 run data modify entity @s data.names[$(slot)] set value ""
