# Bookshelf Nook — eject every shelved book as a real item (run as the anchor). Slot-indexed: walks
# all 12 slots dropping the filled ones (gaps skipped), then clears the lists. data.books lives on
# the anchor, so this runs while it's still alive — on reclaim/store/move (decor/remove) and rotate
# (decor/manage/rebuild) — so a player never loses books to a reclaim.
execute unless data entity @s data.books run return 0
scoreboard players set #da_i ec.temp 0
function evercraft:decor/books/_drop_loop
data modify entity @s data.books set value []
data modify entity @s data.names set value []
