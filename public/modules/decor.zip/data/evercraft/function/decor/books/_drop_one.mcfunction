# Bookshelf Nook — eject slot $(slot)'s book if filled (MACRO; run as the anchor). Args (storage
# books g): slot. Placeholder Item keeps the dropped entity alive to receive the real book.
$execute unless data entity @s data.books[$(slot)].id run return 0
summon item ~ ~0.5 ~ {Tags:["ec.book_give"],PickupDelay:0s,Age:0s,Item:{id:"minecraft:stone",count:1}}
$data modify entity @e[type=item,tag=ec.book_give,limit=1] Item set from entity @s data.books[$(slot)]
tag @e[type=item,tag=ec.book_give] remove ec.book_give
