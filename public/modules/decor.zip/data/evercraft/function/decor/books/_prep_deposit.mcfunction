# Bookshelf Nook — prepare a deposit click (run as the anchor): guarantee the 12-slot model, then
# spawn a gaze probe at each empty slot so deposit.mcfunction's ray-step can pick the slot you look
# at. Probes are killed in _do_deposit once the gaze has been read.
function evercraft:decor/books/_ensure_slots
scoreboard players set #pb_i ec.temp 0
function evercraft:decor/books/_spawn_probes
