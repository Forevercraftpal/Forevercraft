# Bookshelf Nook — at this gaze step, grab the nearest title plate's slot if one is within reach.
# Run at a point along the player's eye-line (positioned by withdraw.mcfunction). The first plate
# within ~0.25b of any step wins (#b_target stays -1 until then). Radius is tunable — tighten if
# adjacent slots get mis-picked, loosen if the gaze feels too fussy.
execute if score #b_target ec.temp matches -1 as @e[type=text_display,tag=ec.shelf_name,distance=..0.25,sort=nearest,limit=1] run scoreboard players operation #b_target ec.temp = @s ec.shelf_pslot
