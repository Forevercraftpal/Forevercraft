# Bookshelf Nook — remove THIS shelf's title plates (run as the anchor, at it).
# Called by hover_tick when a shelf stops being looked at, and by deposit/withdraw to force a
# refresh (the plates rebuild on the next gaze tick with the new contents). Drops the "named" tag
# and kills every ec.shelf_name plate sharing this anchor's uid.
tag @s remove ec.shelf_named
scoreboard players operation #nm_uid ec.temp = @s ec.dec_uid
execute as @e[type=text_display,tag=ec.shelf_name] if score @s ec.dec_uid = #nm_uid ec.temp run kill @s
