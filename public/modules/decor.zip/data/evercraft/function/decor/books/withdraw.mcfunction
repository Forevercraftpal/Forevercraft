# Bookshelf Nook — withdraw (Joseph 2026-06-13, task #103; gaze-targeted 2026-06-14)
# Run as the clicking owner. Take the book you're LOOKING AT: ray-step the player's eye-line and
# grab the nearest title plate (one sits at each filled slot while you're looking). That plate's
# slot is the target; if your gaze isn't on a plate, fall back to the top book. Then hand control
# to the anchor to remove that slot. Anchor-find widened to reach (see deposit.mcfunction).
# Ensure this shelf's title plates exist NOW (they're the gaze targets). The 4s hover tick may not
# have built them yet if you only just looked, so force-build if this nook isn't showing them.
execute as @e[type=marker,tag=ec.dec_anchor,distance=..4.5,limit=1,sort=nearest] if data entity @s data{id:"bookshelf_nook"} if entity @s[tag=!ec.shelf_named] at @s run function evercraft:decor/books/_name_build
scoreboard players set #b_target ec.temp -1
execute at @s anchored eyes positioned ^ ^ ^0.6 run function evercraft:decor/books/_gaze_find
execute if score #b_target ec.temp matches -1 at @s anchored eyes positioned ^ ^ ^1.0 run function evercraft:decor/books/_gaze_find
execute if score #b_target ec.temp matches -1 at @s anchored eyes positioned ^ ^ ^1.4 run function evercraft:decor/books/_gaze_find
execute if score #b_target ec.temp matches -1 at @s anchored eyes positioned ^ ^ ^1.8 run function evercraft:decor/books/_gaze_find
execute if score #b_target ec.temp matches -1 at @s anchored eyes positioned ^ ^ ^2.2 run function evercraft:decor/books/_gaze_find
execute if score #b_target ec.temp matches -1 at @s anchored eyes positioned ^ ^ ^2.6 run function evercraft:decor/books/_gaze_find
execute if score #b_target ec.temp matches -1 at @s anchored eyes positioned ^ ^ ^3.0 run function evercraft:decor/books/_gaze_find
execute as @e[type=marker,tag=ec.dec_anchor,distance=..4.5,limit=1,sort=nearest] if data entity @s data{id:"bookshelf_nook"} at @s run function evercraft:decor/books/_do_withdraw
