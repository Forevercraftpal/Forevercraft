# Bookshelf Nook — write the held book into slot $(slot) (MACRO; run as the anchor). Args (storage
# evercraft:books d): slot (int 0-11). Copies the depositor's held item into that exact slot and
# records its title in the parallel names list (written_book -> raw title, enchanted_book -> label).
$data modify entity @s data.books[$(slot)] set from entity @p[distance=..5] SelectedItem
$data modify entity @s data.books[$(slot)].count set value 1
$data modify entity @s data.names[$(slot)] set value "Untitled"
$execute if items entity @p[distance=..5] weapon.mainhand minecraft:written_book run data modify entity @s data.names[$(slot)] set from entity @p[distance=..5] SelectedItem.components."minecraft:written_book_content".title.raw
$execute if items entity @p[distance=..5] weapon.mainhand minecraft:enchanted_book run data modify entity @s data.names[$(slot)] set value "Enchanted Tome"
