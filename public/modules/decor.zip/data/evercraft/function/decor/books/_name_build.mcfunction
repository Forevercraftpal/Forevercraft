# Bookshelf Nook — build the title plates for THIS shelf (run as the anchor, at it). Called by the
# hover tick when a shelf starts being looked at (and force-built on a withdraw click). Marks the
# shelf "named", then walks all 12 slots; _name_at spawns a plate only for the FILLED ones.
tag @s add ec.shelf_named
scoreboard players set #nm_i ec.temp 0
function evercraft:decor/books/_name_loop
