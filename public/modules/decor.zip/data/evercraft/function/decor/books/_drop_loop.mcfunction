# Bookshelf Nook — walk slots 0..11, ejecting each filled one's book (run as the anchor). Recurses.
execute if score #da_i ec.temp matches 12.. run return 0
execute store result storage evercraft:books g.slot int 1 run scoreboard players get #da_i ec.temp
function evercraft:decor/books/_drop_one with storage evercraft:books g
scoreboard players add #da_i ec.temp 1
function evercraft:decor/books/_drop_loop
