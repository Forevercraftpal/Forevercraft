# Bookshelf Nook — walk slots 0..11, spawning a title plate for each filled one (run as the anchor).
# Slot-indexed: empties are skipped (gaps), so plate slot positions match the actual book slots.
# Stages this slot's facing + offset (shared _slot_offset table), then _name_at spawns IF filled.
execute if score #nm_i ec.temp matches 12.. run return 0
scoreboard players operation #slot_i ec.temp = #nm_i ec.temp
function evercraft:decor/books/_slot_offset
data modify storage evercraft:books nm.face set from entity @s data.face
execute store result storage evercraft:books nm.slot int 1 run scoreboard players get #nm_i ec.temp
function evercraft:decor/books/_name_at with storage evercraft:books nm
scoreboard players add #nm_i ec.temp 1
function evercraft:decor/books/_name_loop
