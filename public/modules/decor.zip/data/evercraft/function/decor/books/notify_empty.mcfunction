# Bookshelf Nook — empty notice (Joseph 2026-06-13)
data modify storage evercraft:notify stage.c set value [{text:"📖 ",color:"gold"},{text:"The shelf has no books to take.",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 40
execute as @p[distance=..2.5] run function evercraft:util/notify/emit
