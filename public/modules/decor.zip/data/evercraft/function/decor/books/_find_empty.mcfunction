# Bookshelf Nook — set #b_slot to the first empty slot in TOP-RIGHT-FIRST reading order (run as the
# anchor), or -1 if the shelf is full. Deposit's fallback when the gaze didn't land on an empty-slot
# probe. Order = top row R->L, then down: 8,7,6 / 11,10,9 / 2,1,0 / 5,4,3 (Joseph 2026-06-14 — fills
# from the TOP of the shelf, not the floor). Literal indices (no macro); empty = no .id.
scoreboard players set #b_slot ec.temp -1
execute if score #b_slot ec.temp matches -1 unless data entity @s data.books[8].id run scoreboard players set #b_slot ec.temp 8
execute if score #b_slot ec.temp matches -1 unless data entity @s data.books[7].id run scoreboard players set #b_slot ec.temp 7
execute if score #b_slot ec.temp matches -1 unless data entity @s data.books[6].id run scoreboard players set #b_slot ec.temp 6
execute if score #b_slot ec.temp matches -1 unless data entity @s data.books[11].id run scoreboard players set #b_slot ec.temp 11
execute if score #b_slot ec.temp matches -1 unless data entity @s data.books[10].id run scoreboard players set #b_slot ec.temp 10
execute if score #b_slot ec.temp matches -1 unless data entity @s data.books[9].id run scoreboard players set #b_slot ec.temp 9
execute if score #b_slot ec.temp matches -1 unless data entity @s data.books[2].id run scoreboard players set #b_slot ec.temp 2
execute if score #b_slot ec.temp matches -1 unless data entity @s data.books[1].id run scoreboard players set #b_slot ec.temp 1
execute if score #b_slot ec.temp matches -1 unless data entity @s data.books[0].id run scoreboard players set #b_slot ec.temp 0
execute if score #b_slot ec.temp matches -1 unless data entity @s data.books[5].id run scoreboard players set #b_slot ec.temp 5
execute if score #b_slot ec.temp matches -1 unless data entity @s data.books[4].id run scoreboard players set #b_slot ec.temp 4
execute if score #b_slot ec.temp matches -1 unless data entity @s data.books[3].id run scoreboard players set #b_slot ec.temp 3
