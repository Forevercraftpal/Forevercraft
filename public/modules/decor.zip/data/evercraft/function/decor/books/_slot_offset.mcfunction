# Bookshelf Nook — stage the local offset (nm.ox/oy/oz) for slot #slot_i (0-11). Run as the anchor.
# Shared by the title plates (_name_loop), the gaze probes (_probe_loop), AND the debug visualizer
# (debug/bookshelf) so they all agree on where each slot sits — tune HERE and everything follows.
# Vanilla chiseled layout: slots 0-2 = top row, 3-5 = bottom row of the LOWER core; 6-8 / 9-11 the
# UPPER core. Columns: left / centre / right. Joseph 2026-06-14: column signs FLIPPED (+x rendered
# to the right, so slot 0 = LEFT is now -0.26). Rows y0.62/0.32 (lower) 1.36/1.06 (upper); depth 0.1.
# TUNE these from the debug overlay (run evercraft:debug/bookshelf/show, screenshot, adjust, repeat).
data modify storage evercraft:books nm.oz set value "0.1"
execute if score #slot_i ec.temp matches 0 run data modify storage evercraft:books nm.ox set value "-0.26"
execute if score #slot_i ec.temp matches 0 run data modify storage evercraft:books nm.oy set value "0.62"
execute if score #slot_i ec.temp matches 1 run data modify storage evercraft:books nm.ox set value "0.0"
execute if score #slot_i ec.temp matches 1 run data modify storage evercraft:books nm.oy set value "0.62"
execute if score #slot_i ec.temp matches 2 run data modify storage evercraft:books nm.ox set value "0.26"
execute if score #slot_i ec.temp matches 2 run data modify storage evercraft:books nm.oy set value "0.62"
execute if score #slot_i ec.temp matches 3 run data modify storage evercraft:books nm.ox set value "-0.26"
execute if score #slot_i ec.temp matches 3 run data modify storage evercraft:books nm.oy set value "0.32"
execute if score #slot_i ec.temp matches 4 run data modify storage evercraft:books nm.ox set value "0.0"
execute if score #slot_i ec.temp matches 4 run data modify storage evercraft:books nm.oy set value "0.32"
execute if score #slot_i ec.temp matches 5 run data modify storage evercraft:books nm.ox set value "0.26"
execute if score #slot_i ec.temp matches 5 run data modify storage evercraft:books nm.oy set value "0.32"
execute if score #slot_i ec.temp matches 6 run data modify storage evercraft:books nm.ox set value "-0.26"
execute if score #slot_i ec.temp matches 6 run data modify storage evercraft:books nm.oy set value "1.36"
execute if score #slot_i ec.temp matches 7 run data modify storage evercraft:books nm.ox set value "0.0"
execute if score #slot_i ec.temp matches 7 run data modify storage evercraft:books nm.oy set value "1.36"
execute if score #slot_i ec.temp matches 8 run data modify storage evercraft:books nm.ox set value "0.26"
execute if score #slot_i ec.temp matches 8 run data modify storage evercraft:books nm.oy set value "1.36"
execute if score #slot_i ec.temp matches 9 run data modify storage evercraft:books nm.ox set value "-0.26"
execute if score #slot_i ec.temp matches 9 run data modify storage evercraft:books nm.oy set value "1.06"
execute if score #slot_i ec.temp matches 10 run data modify storage evercraft:books nm.ox set value "0.0"
execute if score #slot_i ec.temp matches 10 run data modify storage evercraft:books nm.oy set value "1.06"
execute if score #slot_i ec.temp matches 11 run data modify storage evercraft:books nm.ox set value "0.26"
execute if score #slot_i ec.temp matches 11 run data modify storage evercraft:books nm.oy set value "1.06"
