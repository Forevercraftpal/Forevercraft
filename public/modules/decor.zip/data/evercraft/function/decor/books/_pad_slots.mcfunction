# Bookshelf Nook — append empty entries until data.books has 12 (run as the anchor). Recurses; the
# names list is padded in lockstep (the two are always the same length). Stops at 12.
execute store result score #bpad ec.temp run data get entity @s data.books
execute if score #bpad ec.temp matches 12.. run return 0
data modify entity @s data.books append value {}
data modify entity @s data.names append value ""
function evercraft:decor/books/_pad_slots
