# Bookshelf Nook — withdraw, anchor-bound (slot-indexed, Joseph 2026-06-14 phase 2). Run as the
# anchor, at it. Empties the exact slot you're looking at (#b_target, from the nameplate gaze in
# withdraw.mcfunction) and leaves it as a GAP — the other books don't move. If your gaze wasn't on
# a book, nothing happens (a gentle notice).
function evercraft:decor/books/_ensure_slots

# Gaze missed a plate -> fall back to the highest filled slot so a click still returns a book
# (gaze-targeting is a bonus, never a requirement). Only truly-empty shelves bail.
execute if score #b_target ec.temp matches ..-1 run function evercraft:decor/books/_find_filled
execute if score #b_target ec.temp matches ..-1 run return run function evercraft:decor/books/notify_empty

# Hand the targeted book back (placeholder Item keeps the entity alive to receive the copy). _take_slot
# copies + empties the slot and sets #b_got=1 if it was actually filled.
execute as @p[distance=..5] at @s run summon item ~ ~0.5 ~ {Tags:["ec.shelf_give"],PickupDelay:0s,Age:0s,Item:{id:"minecraft:stone",count:1}}
scoreboard players set #b_got ec.temp 0
execute store result storage evercraft:books g.slot int 1 run scoreboard players get #b_target ec.temp
function evercraft:decor/books/_take_slot with storage evercraft:books g
execute if score #b_got ec.temp matches 1 run tag @e[type=item,tag=ec.shelf_give] remove ec.shelf_give
execute if score #b_got ec.temp matches 0 run kill @e[type=item,tag=ec.shelf_give]
# That slot was already empty -> nothing taken.
execute if score #b_got ec.temp matches 0 run return run function evercraft:decor/books/notify_empty

# Darken that slot's chiseled face (only this slot — the rest stay lit).
execute store result storage evercraft:books p.uid int 1 run scoreboard players get @s ec.dec_uid
data modify storage evercraft:books p.state set value "false"
execute if score #b_target ec.temp matches 0..5 run data modify storage evercraft:books p.core set value "lower"
execute if score #b_target ec.temp matches 6..11 run data modify storage evercraft:books p.core set value "upper"
scoreboard players operation #b_vslot ec.temp = #b_target ec.temp
execute if score #b_target ec.temp matches 6..11 run scoreboard players remove #b_vslot ec.temp 6
execute store result storage evercraft:books p.vslot int 1 run scoreboard players get #b_vslot ec.temp
function evercraft:decor/books/_set_slot with storage evercraft:books p

# Refresh title plates, notify + sound.
function evercraft:decor/books/_name_teardown
data modify storage evercraft:notify stage.c set value [{text:"📖 ",color:"gold"},{text:"Retrieved.",color:"yellow"}]
scoreboard players set #ndur ec.temp 25
execute as @p[distance=..5] run function evercraft:util/notify/emit
execute as @p[distance=..5,scores={ec.fx_snd=1..}] at @s run playsound minecraft:item.book.page_turn master @s ~ ~ ~ 0.7 1.0
