# Wonky Bonsai — daily trim (run as the clicking player, at them; armed by click_bare/try #cb_trim).
# Gives 4 logs of the species + Lumberfell XP, once per MC day PER BONSAI (cooldown on the anchor's
# data.trim_next). Mirrors the mailbox/alchemy daily idiom, but the gate lives on the piece, not the
# player, so each placed bonsai trims independently and anyone may trim it.
execute store result score #now ec.temp run time query gametime
scoreboard players set #trim_next ec.temp 0
data remove storage evercraft:decor trimx
tag @e[type=marker,tag=ec.dec_anchor] remove ec.trim_tgt
# Identify the clicked bonsai (nearest anchor carrying a trim_log) + read its cooldown + log.
execute as @e[type=marker,tag=ec.dec_anchor,distance=..3,sort=nearest,limit=1] if data entity @s data.trim_log run function evercraft:decor/trim/_pick
execute unless entity @e[type=marker,tag=ec.trim_tgt] run return 0
# Cooldown gate (per-bonsai). A never-trimmed anchor has no data.trim_next -> #trim_next stays 0.
execute if score #now ec.temp < #trim_next ec.temp run data modify storage evercraft:notify stage.c set value [{text:"🌳 ",color:"green"},{text:"This bonsai needs a day to grow back.",color:"gray",italic:true}]
execute if score #now ec.temp < #trim_next ec.temp run scoreboard players set #ndur ec.temp 35
execute if score #now ec.temp < #trim_next ec.temp run function evercraft:util/notify/emit
execute if score #now ec.temp < #trim_next ec.temp run return 0
# Trim: 4 logs of the species.
function evercraft:decor/trim/_give with storage evercraft:decor trimx
# Lumberfell XP (craft-affinity class 2) via the canonical chokepoint (difficulty-scaled + capped).
scoreboard players set @s ec.caff_class 2
scoreboard players set #delta ec.temp 12
function evercraft:craft_affinity/internal_grant
# Set this bonsai's next-trim to now + 1 MC day.
scoreboard players operation #trim_set ec.temp = #now ec.temp
scoreboard players add #trim_set ec.temp 24000
execute as @e[type=marker,tag=ec.trim_tgt] store result entity @s data.trim_next int 1 run scoreboard players get #trim_set ec.temp
tag @e[type=marker,tag=ec.trim_tgt] remove ec.trim_tgt
data modify storage evercraft:notify stage.c set value [{text:"🪓 ",color:"green"},{text:"Trimmed",color:"green"},{text:" — 4 logs + Lumberfell XP.",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.azalea.place ambient @s ~ ~ ~ 0.6 0.9
