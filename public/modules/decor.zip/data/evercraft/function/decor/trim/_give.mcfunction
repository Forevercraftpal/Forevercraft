# Wonky Bonsai trim — give the species log (MACRO: storage evercraft:decor trimx, .log = block id).
$give @s $(log) 4
