# Wonky Bonsai trim — pick THIS anchor as the trim target (run as the nearest trimmable anchor).
# Stashes its log id for the macro give + its cooldown into #trim_next, and tags it for the setter.
data modify storage evercraft:decor trimx.log set from entity @s data.trim_log
execute store result score #trim_next ec.temp run data get entity @s data.trim_next
tag @s add ec.trim_tgt
