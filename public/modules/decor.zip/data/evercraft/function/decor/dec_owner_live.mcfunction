# Furnishings — Decrement the OWNER's live furnishing count on reclaim (floor 0; one writer with confirm)
# Args (storage temp): owner (the anchor owner UUID list, high-2 halves identify the player).
# Run after a confirmed in-zone reclaim. hs.dec_live is per-player (incremented in decor/use/confirm by
# the in-zone placer = the owner), so we find the online player whose UUID matches the anchor owner and
# decrement them. If the owner is offline, the counter simply isn't touched this session — it self-heals
# on their next placement/reclaim and never drives negative (the floor-0 guard below). NOT a macro on the
# UUID (we compare via scores), so this is a plain function.

# Resolve the owner halves from storage into compare scores.
execute store result score #dec_own_o0 ec.temp run data get storage evercraft:decor temp.owner[0]
execute store result score #dec_own_o1 ec.temp run data get storage evercraft:decor temp.owner[1]

# Tag the matching online owner (UUID idiom: both high halves), decrement them (floor 0), untag.
execute as @a run function evercraft:decor/dec_owner_match
