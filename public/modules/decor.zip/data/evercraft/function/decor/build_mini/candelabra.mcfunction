# === FURNISHINGS — MINI PREVIEW: candelabra (catalogue View hologram) ===
# A 0.5-scale copy of decor/build/candelabra for the Ideas & Blueprints catalogue.
# Run rotated/positioned by decor/gui/view_mini (macro pieces get mat from the row).
# Tagged DEC.MenuEl + DEC.PrevMini — reaped by the GUI lifecycle, never by the
# placement engine (NOT ec.dec_ghost).

summon block_display ~ ~ ~ {Tags:["DEC.MenuEl","DEC.PrevMini"],block_state:{Name:"minecraft:gold_block"},brightness:{sky:15,block:15},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[-0.075f,0f,-0.075f],scale:[0.15f,0.04f,0.15f]}}
summon block_display ~ ~ ~ {Tags:["DEC.MenuEl","DEC.PrevMini"],block_state:{Name:"minecraft:gold_block"},brightness:{sky:15,block:15},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[-0.02f,0.04f,-0.02f],scale:[0.04f,0.25f,0.04f]}}
summon block_display ~ ~ ~ {Tags:["DEC.MenuEl","DEC.PrevMini"],block_state:{Name:"minecraft:gold_block"},brightness:{sky:15,block:15},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[-0.14f,0.29f,-0.02f],scale:[0.28f,0.03f,0.04f]}}
summon block_display ~ ~ ~ {Tags:["DEC.MenuEl","DEC.PrevMini"],block_state:{Name:"minecraft:candle",Properties:{candles:"1",lit:"true"}},brightness:{sky:15,block:15},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[-0.225f,0.32f,-0.225f],scale:[0.45f,0.45f,0.45f]}}
summon block_display ~ ~ ~ {Tags:["DEC.MenuEl","DEC.PrevMini"],block_state:{Name:"minecraft:candle",Properties:{candles:"1",lit:"true"}},brightness:{sky:15,block:15},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[-0.345f,0.32f,-0.225f],scale:[0.45f,0.45f,0.45f]}}
summon block_display ~ ~ ~ {Tags:["DEC.MenuEl","DEC.PrevMini"],block_state:{Name:"minecraft:candle",Properties:{candles:"1",lit:"true"}},brightness:{sky:15,block:15},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[-0.105f,0.32f,-0.225f],scale:[0.45f,0.45f,0.45f]}}
