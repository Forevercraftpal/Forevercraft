# === FURNISHINGS — MINI PREVIEW: kitchen_counter (catalogue View hologram) ===
# A 0.5-scale copy of decor/build/kitchen_counter for the Ideas & Blueprints catalogue.
# Run rotated/positioned by decor/gui/view_mini (macro pieces get mat from the row).
# Tagged DEC.MenuEl + DEC.PrevMini — reaped by the GUI lifecycle, never by the
# placement engine (NOT ec.dec_ghost).

summon block_display ~ ~ ~ {Tags:["DEC.MenuEl","DEC.PrevMini"],block_state:{Name:"minecraft:stripped_pale_oak_log"},brightness:{sky:15,block:15},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[-0.215f,0f,-0.215f],scale:[0.43f,0.465f,0.43f]}}
summon block_display ~ ~ ~ {Tags:["DEC.MenuEl","DEC.PrevMini"],block_state:{Name:"minecraft:smooth_stone"},brightness:{sky:15,block:15},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[-0.242f,0.45f,-0.242f],scale:[0.485f,0.05f,0.485f]}}
summon block_display ~ ~ ~ {Tags:["DEC.MenuEl","DEC.PrevMini"],block_state:{Name:"minecraft:gold_block"},brightness:{sky:15,block:15},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[-0.03f,0.23f,0.212f],scale:[0.06f,0.025f,0.025f]}}
