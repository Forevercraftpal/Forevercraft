# === FURNISHINGS — MINI PREVIEW: stool (catalogue View hologram) ===
# A 0.5-scale copy of decor/build/stool for the Ideas & Blueprints catalogue.
# Run rotated/positioned by decor/gui/view_mini (macro pieces get mat from the row).
# Tagged DEC.MenuEl + DEC.PrevMini — reaped by the GUI lifecycle, never by the
# placement engine (NOT ec.dec_ghost).

$summon block_display ~ ~ ~ {Tags:["DEC.MenuEl","DEC.PrevMini"],block_state:{Name:"minecraft:$(mat)_planks"},brightness:{sky:15,block:15},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[-0.125f,0.19f,-0.125f],scale:[0.25f,0.06f,0.25f]}}
$summon block_display ~ ~ ~ {Tags:["DEC.MenuEl","DEC.PrevMini"],block_state:{Name:"minecraft:$(mat)_planks"},brightness:{sky:15,block:15},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[-0.04f,0f,-0.04f],scale:[0.08f,0.19f,0.08f]}}
$summon block_display ~ ~ ~ {Tags:["DEC.MenuEl","DEC.PrevMini"],block_state:{Name:"minecraft:$(mat)_planks"},brightness:{sky:15,block:15},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[-0.085f,0f,-0.085f],scale:[0.17f,0.04f,0.17f]}}
