# === FURNISHINGS — MINI PREVIEW: cushion_pile (catalogue View hologram) ===
# A 0.5-scale copy of decor/build/cushion_pile for the Ideas & Blueprints catalogue.
# Run rotated/positioned by decor/gui/view_mini (macro pieces get mat from the row).
# Tagged DEC.MenuEl + DEC.PrevMini — reaped by the GUI lifecycle, never by the
# placement engine (NOT ec.dec_ghost).

$summon block_display ~ ~ ~ {Tags:["DEC.MenuEl","DEC.PrevMini"],block_state:{Name:"minecraft:$(mat)_wool"},brightness:{sky:15,block:15},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[-0.175f,0f,-0.175f],scale:[0.35f,0.125f,0.35f]}}
$summon block_display ~ ~ ~ {Tags:["DEC.MenuEl","DEC.PrevMini"],block_state:{Name:"minecraft:$(mat)_wool"},brightness:{sky:15,block:15},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0.113f,0f,-0.263f],scale:[0.225f,0.1f,0.225f]}}
summon block_display ~ ~ ~ {Tags:["DEC.MenuEl","DEC.PrevMini"],block_state:{Name:"minecraft:white_wool"},brightness:{sky:15,block:15},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[-0.145f,0.125f,-0.055f],scale:[0.21f,0.08f,0.21f]}}
$summon block_display ~ ~ ~ {Tags:["DEC.MenuEl","DEC.PrevMini"],block_state:{Name:"minecraft:$(mat)_wool"},brightness:{sky:15,block:15},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[-0.33f,0f,0.07f],scale:[0.21f,0.09f,0.21f]}}
summon block_display ~ ~ ~ {Tags:["DEC.MenuEl","DEC.PrevMini"],block_state:{Name:"minecraft:white_wool"},brightness:{sky:15,block:15},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0.15f,0.1f,-0.225f],scale:[0.15f,0.06f,0.15f]}}
summon item_display ~ ~ ~ {Tags:["DEC.MenuEl","DEC.PrevMini"],item:{id:"minecraft:book",count:1},item_display:"fixed",brightness:{sky:15,block:15},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[-0.1f,0.215f,-0.015f],scale:[0.15f,0.15f,0.15f]}}
