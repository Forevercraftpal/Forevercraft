# === FURNISHINGS — MINI PREVIEW: chair (catalogue View hologram) ===
# A 0.5-scale copy of decor/build/chair for the Ideas & Blueprints catalogue.
# Run rotated/positioned by decor/gui/view_mini (macro pieces get mat from the row).
# Tagged DEC.MenuEl + DEC.PrevMini — reaped by the GUI lifecycle, never by the
# placement engine (NOT ec.dec_ghost).

$summon block_display ~ ~ ~ {Tags:["DEC.MenuEl","DEC.PrevMini"],block_state:{Name:"minecraft:$(mat)_planks"},brightness:{sky:15,block:15},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[-0.2f,0f,-0.2f],scale:[0.08f,0.23f,0.08f]}}
$summon block_display ~ ~ ~ {Tags:["DEC.MenuEl","DEC.PrevMini"],block_state:{Name:"minecraft:$(mat)_planks"},brightness:{sky:15,block:15},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0.12f,0f,-0.2f],scale:[0.08f,0.23f,0.08f]}}
$summon block_display ~ ~ ~ {Tags:["DEC.MenuEl","DEC.PrevMini"],block_state:{Name:"minecraft:$(mat)_planks"},brightness:{sky:15,block:15},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[-0.2f,0f,0.12f],scale:[0.08f,0.23f,0.08f]}}
$summon block_display ~ ~ ~ {Tags:["DEC.MenuEl","DEC.PrevMini"],block_state:{Name:"minecraft:$(mat)_planks"},brightness:{sky:15,block:15},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0.12f,0f,0.12f],scale:[0.08f,0.23f,0.08f]}}
$summon block_display ~ ~ ~ {Tags:["DEC.MenuEl","DEC.PrevMini"],block_state:{Name:"minecraft:$(mat)_planks"},brightness:{sky:15,block:15},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[-0.205f,0.23f,-0.205f],scale:[0.41f,0.08f,0.41f]}}
$summon block_display ~ ~ ~ {Tags:["DEC.MenuEl","DEC.PrevMini"],block_state:{Name:"minecraft:$(mat)_planks"},brightness:{sky:15,block:15},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[-0.205f,0.31f,-0.22f],scale:[0.41f,0.31f,0.08f]}}
$summon block_display ~ ~ ~ {Tags:["DEC.MenuEl","DEC.PrevMini"],block_state:{Name:"minecraft:$(mat)_planks"},brightness:{sky:15,block:15},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[-0.23f,0.31f,-0.125f],scale:[0.05f,0.05f,0.3f]}}
$summon block_display ~ ~ ~ {Tags:["DEC.MenuEl","DEC.PrevMini"],block_state:{Name:"minecraft:$(mat)_planks"},brightness:{sky:15,block:15},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0.18f,0.31f,-0.125f],scale:[0.05f,0.05f,0.3f]}}
$summon block_display ~ ~ ~ {Tags:["DEC.MenuEl","DEC.PrevMini"],block_state:{Name:"minecraft:$(mat)_planks"},brightness:{sky:15,block:15},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[-0.225f,0.23f,0.13f],scale:[0.04f,0.08f,0.04f]}}
$summon block_display ~ ~ ~ {Tags:["DEC.MenuEl","DEC.PrevMini"],block_state:{Name:"minecraft:$(mat)_planks"},brightness:{sky:15,block:15},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0.185f,0.23f,0.13f],scale:[0.04f,0.08f,0.04f]}}
