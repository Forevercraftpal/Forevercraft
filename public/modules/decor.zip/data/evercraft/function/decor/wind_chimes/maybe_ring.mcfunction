# Wind chimes — single-anchor roll + ring (Joseph 2026-06-13)
# Run as the chime anchor, at it. Rolls 1-100; ring rate is ~22% in clear, ~40%
# in rain (rain is the closest vanilla cue we have to "wind blowing"). The pitch
# is a random pick of a clear-major arpeggio (C / E / G / B / D5) so back-to-back
# chimes voice a chord rather than a single repeated note.

# Existence + nearby-player gate (no point playing if no one will hear it).
execute unless entity @a[distance=..24] run return 0

# Rain doubles the odds; otherwise plain 22% chance.
scoreboard players set #wc_thresh ec.temp 22
execute if predicate evercraft:is_raining run scoreboard players set #wc_thresh ec.temp 40
execute store result score #wc_r ec.temp run random value 1..100
execute if score #wc_r ec.temp > #wc_thresh ec.temp run return 0

# Pitch pick — major-7th arpeggio (C4 / E4 / G4 / B4 / D5 ≈ 1.0 / 1.26 / 1.5 / 1.89 / 2.0).
execute store result score #wc_p ec.temp run random value 1..5
execute if score #wc_p ec.temp matches 1 run playsound minecraft:block.amethyst_block.chime ambient @a[distance=..18,scores={ec.fx_snd=1..}] ~ ~ ~ 0.4 1.0
execute if score #wc_p ec.temp matches 2 run playsound minecraft:block.amethyst_block.chime ambient @a[distance=..18,scores={ec.fx_snd=1..}] ~ ~ ~ 0.4 1.26
execute if score #wc_p ec.temp matches 3 run playsound minecraft:block.amethyst_block.chime ambient @a[distance=..18,scores={ec.fx_snd=1..}] ~ ~ ~ 0.4 1.5
execute if score #wc_p ec.temp matches 4 run playsound minecraft:block.amethyst_block.chime ambient @a[distance=..18,scores={ec.fx_snd=1..}] ~ ~ ~ 0.3 1.89
execute if score #wc_p ec.temp matches 5 run playsound minecraft:block.amethyst_block.chime ambient @a[distance=..18,scores={ec.fx_snd=1..}] ~ ~ ~ 0.3 2.0
