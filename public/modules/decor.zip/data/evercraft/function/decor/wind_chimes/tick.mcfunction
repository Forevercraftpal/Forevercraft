# Wind chimes — ambient chime tick (Joseph 2026-06-13)
# Existence-gated self-rescheduling 4s tick. Each placed wind_chimes anchor
# rolls a chime sound on a small random chance per fire; raining doubles the
# odds. Pitch picked from a 5-note arpeggio so consecutive chimes sound musical
# instead of monotone. The sound is amethyst_block.chime at low volume so a
# room with several placed chimes lays into a gentle background patter.

execute unless entity @e[type=marker,tag=ec.dec_anchor,nbt={data:{id:"wind_chimes"}},limit=1] run return run schedule function evercraft:decor/wind_chimes/tick 30s replace

# Per-anchor: roll for chime + play to nearby players who have sound on.
execute as @e[type=marker,tag=ec.dec_anchor,nbt={data:{id:"wind_chimes"}}] at @s run function evercraft:decor/wind_chimes/maybe_ring

schedule function evercraft:decor/wind_chimes/tick 4s replace
