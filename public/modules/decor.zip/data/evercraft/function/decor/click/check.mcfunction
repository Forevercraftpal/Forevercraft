# Furnishings — Removal click handler (run as the clicked ec.dec_click interaction, at its position).
# Called by the tick removal-detection lines (lead-added) when a shears-holder interacts/attacks a
# decor footprint. Clears the trigger NBT first (P2-3, mirrors dream_echoes/on_click), reads this
# instance's UID + the remover's identity into storage, then routes through the permission gate.
#
# B6 idempotency note: this handler does NOT kill anything itself — decor/remove holds the
# kill-anchor-first sentinel, so the dual interact+attack paths (or two shears in one tick) collapse
# to a single reward there. Here we only read + gate.

# --- (a) Capture the ACTUAL clicker from the interaction's OWN record, BEFORE clearing it (U3 review
#         fix). The interaction entity stamps the clicking player's UUID into `interaction.player`
#         (right-click) or `attack.player` (left-click). Reading nearest-@p instead would mis-gate the
#         owner check when two shears-holders stand stacked over one in-zone piece: a griefer's click
#         could be attributed to the owner and ALLOWED (an in-zone grief), and the reward mis-credited.
#         Read whichever channel fired (guarded by `if data` so an absent channel never zeroes temp). ---
execute if data entity @s interaction run data modify storage evercraft:decor temp.rmv set from entity @s interaction.player
execute if data entity @s interaction store result storage evercraft:decor temp.r0 int 1 run data get entity @s interaction.player[0]
execute if data entity @s interaction store result storage evercraft:decor temp.r1 int 1 run data get entity @s interaction.player[1]
execute if data entity @s attack run data modify storage evercraft:decor temp.rmv set from entity @s attack.player
execute if data entity @s attack store result storage evercraft:decor temp.r0 int 1 run data get entity @s attack.player[0]
execute if data entity @s attack store result storage evercraft:decor temp.r1 int 1 run data get entity @s attack.player[1]

# --- (b) NOW clear the trigger NBT (P2-3) so a re-click next tick re-arms cleanly. ---
data remove entity @s interaction
data remove entity @s attack

# Bail if no shears-holder is actually in range (belt-and-braces: the tick already gated on
# @a[predicate=is_holding_shears] within 5, but a same-tick despawn/swap could leave none).
execute unless entity @p[predicate=evercraft:is_holding_shears,distance=..5] run return 0

# --- (c) This instance's UID → storage temp.uid (the macro key for check_perm / remove). ---
execute store result storage evercraft:decor temp.uid int 1 run scoreboard players get @s ec.dec_uid

# --- (d) Permission gate (run AT the anchor inside check_perm). It compares temp.r0/r1 (the real
#         clicker) to the anchor owner for in-zone pieces; on allow it calls decor/remove. ---
function evercraft:decor/click/check_perm with storage evercraft:decor temp
