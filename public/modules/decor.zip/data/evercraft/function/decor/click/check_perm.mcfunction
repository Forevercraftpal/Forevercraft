# Furnishings — Removal permission gate (MACRO; run as the clicked interaction; relocates AT the anchor)
# Args (storage temp): uid, r0, r1 (remover UUID high-2 halves), rmv (remover UUID list).
#
# RULE (SPEC §5 B-removal-rule): a furnishing placed INSIDE a claimed home zone may be reclaimed only
# by the zone OWNER; a furnishing on UNCLAIMED land may be reclaimed by anyone holding shears.
#
# HOW "is this in a claimed zone + who owns it" is determined (design note — read carefully):
#   The housing zone model is PER-ONLINE-OWNER (zone/check, protection_tick): a position is "in a
#   claimed zone owned by P" iff P is online AND one of P's home centers is within 64 blocks. There is
#   NO global position→zone-owner index. A live re-derivation at the anchor would therefore declare a
#   furnishing "unclaimed / free-for-all" the moment its owner logs off — exactly the grief the SPEC
#   forbids. So instead we trust the OFFLINE-SAFE provenance captured at placement: the anchor's
#   data.inzone (1 = placed in the placer's own claimed zone) + data.owner (the placer = the zone owner,
#   since in-zone placement requires being within 64 of one's OWN home). This is robust, race-free, and
#   correct whether or not the owner is online. (NOT the conservative owner-only-everywhere fallback —
#   wild decor stays anyone-removable, per spec.)

# Relocate to the anchor so the owner/inzone reads + the remove dispatch are anchored on the instance.
$execute as @e[type=marker,tag=ec.dec_anchor,scores={ec.dec_uid=$(uid)},limit=1] at @s run function evercraft:decor/click/check_perm_at with storage evercraft:decor temp
