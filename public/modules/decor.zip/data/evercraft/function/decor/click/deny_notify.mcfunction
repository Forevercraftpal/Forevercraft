# Furnishings — Removal denied (run as @s = the remover). In-zone decor, non-owner.
# B7 voice: "reclaim", never "destroy". Action-bar notify via the public emit API.
data modify storage evercraft:notify stage.c set value [{text:"Those aren't your furnishings to reclaim.",color:"red"}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 0.5 0.8
