# Furnishings — Removal permission body (MACRO; run AS the anchor marker, at the anchor)
# Args (storage temp): uid, r0, r1 (remover UUID high-2 halves), rmv (remover UUID list).
# Decides the owner-gate from the anchor's OFFLINE-SAFE provenance (see check_perm header), then either
# routes to decor/remove (allow) or notifies the remover (deny). One macro hop deeper than check_perm so
# @s is the anchor — its data.owner / data.inzone read directly, and decor/remove runs at the instance.

# UNCLAIMED (wild) furnishing → anyone holding shears may reclaim it. inzone:0b skips the owner check.
# (entity nbt-match selector — the value-test idiom; `if data entity` takes a path, not a compound.)
execute unless entity @s[nbt={data:{inzone:1b}}] run return run function evercraft:decor/remove with storage evercraft:decor temp

# IN-ZONE furnishing → only the zone owner (== the anchor's recorded placer) may reclaim. Compare the
# remover UUID high-2 halves (temp.r0/r1, set by check) to the anchor owner UUID halves. Both must match
# (UUID idiom — tamed_bond/check_owner, housing/zone/check_break_owner).
scoreboard players set #dec_owner_ok ec.temp 0
execute store result score #dec_anc_o0 ec.temp run data get entity @s data.owner[0]
execute store result score #dec_anc_o1 ec.temp run data get entity @s data.owner[1]
$scoreboard players set #dec_rmv_o0 ec.temp $(r0)
$scoreboard players set #dec_rmv_o1 ec.temp $(r1)
execute if score #dec_rmv_o0 ec.temp = #dec_anc_o0 ec.temp if score #dec_rmv_o1 ec.temp = #dec_anc_o1 ec.temp run scoreboard players set #dec_owner_ok ec.temp 1

# ALLOW: the remover is the zone owner → reclaim the instance.
execute if score #dec_owner_ok ec.temp matches 1 run return run function evercraft:decor/remove with storage evercraft:decor temp

# DENY: a non-owner tried to reclaim in-zone decor. Notify the remover (the nearest shears-holder,
# anchored on the anchor position) in B7 "reclaim" voice — never "destroy". No effect, no kill.
execute as @p[predicate=evercraft:is_holding_shears,distance=..5] run function evercraft:decor/click/deny_notify
