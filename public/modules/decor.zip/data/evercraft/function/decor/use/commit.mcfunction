# Furnishings — Commit the preview to a placed sculpture (MACRO; run as the player)
# Args (storage build): id, mat, face, tx, ty, tz, uid, ou0..ou3 (owner UUID halves), home (slot),
#   inzone (0/1 — placed inside the placer's claimed zone? = hs.in_zone at confirm).
# Retags this UID's ghost → placed (ec.dec_disp), drops the pad, and summons the data anchor +
# the removal interaction, both UID-stamped. Placed decor is INERT — no tick iterates ec.dec_disp.

# Ghost sculpture → placed. Remove the ghost tag so the preview tick never touches it again.
# (#evercraft:decor_displays = block_display + item_display — Phase-2 shapes carry small item
# props like the clock face / desk book / well bucket, which must commit + reclaim with the piece.)
$tag @e[type=#evercraft:decor_displays,tag=ec.dec_ghost,tag=!ec.dec_pad,scores={ec.dec_uid=$(uid)}] add ec.dec_disp
$tag @e[type=#evercraft:decor_displays,tag=ec.dec_disp,scores={ec.dec_uid=$(uid)}] remove ec.dec_ghost

# Drop the footprint pad (no longer needed once placed).
$kill @e[type=block_display,tag=ec.dec_pad,scores={ec.dec_uid=$(uid)}]

# Anchor marker — the canonical data record for this instance (read by removal). counted starts 0b;
# the credit-once gate flips it to 1b via mark_counted only when this placement actually credited.
# inzone (offline-safe provenance — W3): captured from hs.in_zone at confirm so removal can decide
# the owner-gate WITHOUT a live position→zone lookup (the housing zone model is per-online-owner, so
# a live lookup would un-protect a furnishing whenever its owner is offline — the exact grief the SPEC
# forbids). inzone:1b → owner-only reclaim (data.owner IS the zone owner, since in-zone placement
# requires the placer be within 64 of their OWN home). inzone:0b → wild, anyone-with-shears reclaim.
# Tagged transiently ec.dec_new so we can UID-stamp just-summoned entities, then drop that tag.
# NOTE: do NOT tag the anchor `ec.entity` — minecraft:marker is in #evercraft:treasure/targets, so an
# `ec.entity` marker would arm treasure/tick and crowd its limit=20 sample (U4 review fix). The UID +
# ec.dec_anchor/ec.dec_click tags are the only keys removal needs.
$execute positioned $(tx) $(ty) $(tz) positioned ~$(ox) ~ ~$(oz) run summon marker ~ ~ ~ {Tags:["ec.dec_anchor","ec.dec_new"],data:{id:"$(id)",mat:"$(mat)",face:$(face),owner:[I;$(ou0),$(ou1),$(ou2),$(ou3)],home:$(home),counted:0b,tangible:0b,inzone:$(inzone)b,free:$(free)b}}

# Light emission (Wave E): if this id is a LIT piece (in the load-time registry), drop a tracked
# world-light at cell+1. Non-lit ids leave light.lvl absent -> the execute-if no-ops. Removal clears it.
data remove storage evercraft:decor light
$data modify storage evercraft:decor light.lvl set from storage evercraft:decor light_levels.$(id)
$execute if data storage evercraft:decor light.lvl positioned $(tx) $(ty) $(tz) positioned ~$(ox) ~ ~$(oz) run function evercraft:decor/light/place with storage evercraft:decor light

# Trim registry (Wonky Bonsai daily harvest, 2026-06-14): stamp the species log onto the anchor so
# the click router/handler key off data.trim_log. Non-trimmable ids leave trim_logs.$(id) absent ->
# `set from` a missing source is a no-op, so the field stays absent and the route check skips it.
$data modify entity @e[tag=ec.dec_anchor,tag=ec.dec_new,limit=1] data.trim_log set from storage evercraft:decor trim_logs.$(id)

# Antique quality (Phase B, 2026-06-14): copy the piece's effectiveness multiplier (75/100/200) onto
# the anchor so its ability handlers scale strength + duration. Absent on non-antique items → set-from
# is a no-op → handlers read no data.antique_eff and default to 100 (Standard / current behavior).
data modify entity @e[tag=ec.dec_anchor,tag=ec.dec_new,limit=1] data.antique_eff set from storage evercraft:decor held.components."minecraft:custom_data".antique_eff
# Pristine material infusion (Phase E): the effect id + the flag the buff tick selects on. Absent on
# non-infused pieces → both set-froms are no-ops → no infusion aura.
data modify entity @e[tag=ec.dec_anchor,tag=ec.dec_new,limit=1] data.antique_buff set from storage evercraft:decor held.components."minecraft:custom_data".antique_buff
data modify entity @e[tag=ec.dec_anchor,tag=ec.dec_new,limit=1] data.antique_buffed set from storage evercraft:decor held.components."minecraft:custom_data".antique_buffed

# Interaction — footprint-sized clickable for shears removal (W3 wires the handler). response:1b so
# both the interact and attack paths fire. Sits over the base cell, ~2x2 to cover the footprint.
# Joseph 2026-06-12: previous bump to height:1.8 + Y offset 1.25 was a fix for barriers
# intercepting clicks — now that tangibility blocks are minecraft:structure_void (no
# collision, no outline, no raycast intercept), the original footprint is sufficient
# AND avoids overlapping the manage-menu button hitboxes.
$execute positioned $(tx) $(ty) $(tz) positioned ~$(ox) ~ ~$(oz) run summon interaction ~ ~ ~ {Tags:["ec.dec_click","ec.dec_new"],width:2.0f,height:1.0f,response:1b}
# Tall pieces: raise the clickable height so the WHOLE face is reachable. The default 1.0 only
# covers the bottom block, so a 2-tall nook's upper slots / high rack pegs weren't clickable.
# Per-piece (short pieces keep 1.0, which also stays clear of the manage-menu button hitboxes).
# Joseph 2026-06-14. The interaction grows UP from the base, so height ~= the piece's height.
execute if data storage evercraft:decor build{id:"bookshelf_nook"} run data merge entity @e[type=interaction,tag=ec.dec_new,limit=1] {height:1.7f}
execute if data storage evercraft:decor build{id:"coat_rack"} run data merge entity @e[type=interaction,tag=ec.dec_new,limit=1] {height:1.8f}
execute if data storage evercraft:decor build{id:"weapon_rack"} run data merge entity @e[type=interaction,tag=ec.dec_new,limit=1] {height:1.6f}

# Scarecrow ward (lag audit 2026-06-22): stamp ec.scarecrow on the anchor at placement so the 3t
# ward tick (decor/scarecrow/tick) selects scarecrows by tag instead of NBT-filtering the entire
# ec.dec_anchor population every 3 ticks. Legacy pieces are backfilled at load + on the idle poll.
execute if data storage evercraft:decor build{id:"scarecrow"} run tag @e[type=marker,tag=ec.dec_anchor,tag=ec.dec_new,limit=1] add ec.scarecrow

# UID-stamp the anchor + interaction so removal can select this exact instance. Scoped ..16 (R2 —
# the raycast places up to ~13.6 blocks from the player, so ..8 would miss a far cell).
$scoreboard players set @e[tag=ec.dec_new,distance=..16] ec.dec_uid $(uid)

# Stash the EXACT original item snapshot onto the anchor (W3 reclaim — SPEC §5). `storage held` is
# still the confirm-time SelectedItem ({id,count,components}); a high-tier Lamentor reclaim returns
# this verbatim (with counted:true merged) so a reclaimed furnishing is byte-identical to the one
# crafted. Stored on the anchor (not a transient) so removal can read it after the player walks off.
data modify entity @e[tag=ec.dec_anchor,tag=ec.dec_new,limit=1] data.item set from storage evercraft:decor held
# Normalize the stashed snapshot to a single item (U2 review fix): SelectedItem carries the held
# stack's count:N, but placement consumes only 1 — without this, a high-tier Lamentor holding a stack
# could place-one / shear-back and reclaim N items (a count-field dupe). The reclaim returns exactly 1.
data modify entity @e[tag=ec.dec_anchor,tag=ec.dec_new,limit=1] data.item.count set value 1

# Drop the transient tag (the just-summoned anchor + interaction were the only ec.dec_new carriers).
tag @e[tag=ec.dec_new,distance=..16] remove ec.dec_new

# Scale-retention (Joseph 2026-06-12): if the held item carries decor_scale_mul
# (stamped by Move/Store), apply it to the freshly summoned displays so the
# piece re-places at the same size it had before. Anchor's data.scale_mul is
# persisted too so subsequent +/- math operates from the right baseline.
execute if data storage evercraft:decor held.components."minecraft:custom_data".decor_scale_mul run function evercraft:decor/use/apply_scale_mul with storage evercraft:decor build
