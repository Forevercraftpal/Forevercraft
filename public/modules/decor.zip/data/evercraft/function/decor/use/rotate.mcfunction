# Furnishings — Rotate the previewed ghost 90° (PLAIN right-click while previewing — controls
# swapped 2026-06-10: sneak confirms, plain adjusts). Rotation is BAKED into the build's facing
# wrapper, so unlike a move it can't be teleported — we kill this UID's sculpture and re-summon
# it at the current base cell with the new facing.
# (on_use only dispatches here at state 1; the guard is defensive.)
execute unless score @s ec.dec_state matches 1 run return 0

# Advance facing 45° (diagonal placement, Joseph 2026-06-11), wrap 360 → 0.
scoreboard players add @s ec.dec_face 45
execute if score @s ec.dec_face matches 360.. run scoreboard players set @s ec.dec_face 0

# Refresh the macro args (face/uid + current target cell) for the re-summon.
execute store result storage evercraft:decor build.face int 1 run scoreboard players get @s ec.dec_face
execute store result storage evercraft:decor build.uid int 1 run scoreboard players get @s ec.dec_uid
execute store result storage evercraft:decor build.tx int 1 run scoreboard players get @s ec.dec_tgtx
execute store result storage evercraft:decor build.ty int 1 run scoreboard players get @s ec.dec_tgty
execute store result storage evercraft:decor build.tz int 1 run scoreboard players get @s ec.dec_tgtz

function evercraft:decor/preview/half_args

# Kill ONLY this UID's sculpture displays (keep the pad — validate refreshes it).
function evercraft:decor/use/rotate_clear with storage evercraft:decor build

# Re-summon the sculpture at the current base with the new facing, then re-stamp + re-validate.
function evercraft:decor/preview/render with storage evercraft:decor build
function evercraft:decor/preview/stamp_uid with storage evercraft:decor build
function evercraft:decor/preview/validate

# Sound.
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.hat master @s ~ ~ ~ 0.6 1.0
