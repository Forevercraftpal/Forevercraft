# Furnishings — Confirm placement (second right-click while previewing; SPEC §4, B1/B2, P1-7/P1-8)
# Validates, charges materials, commits the ghost to a placed sculpture, and credits-once in-zone.

# --- (1) Re-read mainhand at confirm (P1-7) — don't trust the enter_preview snapshot. ---
data modify storage evercraft:decor held set from entity @s SelectedItem
execute unless data storage evercraft:decor held.components."minecraft:custom_data".decor run return run function evercraft:decor/use/cancel

# Refresh this player's UID into the shared build storage up front (race-safe: every macro that
# selects "my" entities reads build.uid, and the shared path could otherwise hold another player's).
execute store result storage evercraft:decor build.uid int 1 run scoreboard players get @s ec.dec_uid

# --- (2) Physical fit — re-validate, then bail (stay previewing) if blocked. ---
function evercraft:decor/preview/validate
data modify storage evercraft:notify stage.c set value [{text:"You can't place that here.",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute if score #dec_blocked ec.temp matches 1.. run return run function evercraft:util/notify/emit

# --- (3) Live cap (in-zone only): a home tops out at 64 live furnishings. ---
data modify storage evercraft:notify stage.c set value [{text:"This home is full of furnishings.",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute if score @s hs.in_zone matches 1 if score @s hs.dec_live matches 64.. run return run function evercraft:util/notify/emit

# --- (4) Materials present? (non-destructive count → #dec_has_mats) ---
# Ideas/Blueprints economy (2026-06-09): a BLUEPRINT item (custom_data decor_free, drafted from
# 9 Ideas) builds for FREE — skip the material check AND the consume; the item itself is still
# cleared. An IDEA (default) pays the recipe as before.
data modify storage evercraft:decor build.id set from storage evercraft:decor held.components."minecraft:custom_data".decor_id
data modify storage evercraft:decor build.mat set from storage evercraft:decor held.components."minecraft:custom_data".decor_mat
scoreboard players set #dec_free ec.temp 0
execute store success score #dec_free ec.temp if data storage evercraft:decor held.components."minecraft:custom_data".decor_free
# Joseph 2026-06-13: creative-mode players ride the same free-build path as
# blueprint-drafted (decor_free) items — skips material check + consume +
# anchor's free-provenance stamp so reclaim doesn't try to refund nothing.
execute if entity @s[gamemode=creative] run scoreboard players set #dec_free ec.temp 1
execute if score #dec_free ec.temp matches 1 run scoreboard players set #dec_has_mats ec.temp 1
execute if score #dec_free ec.temp matches 0 run function evercraft:decor/use/check_mats with storage evercraft:decor build
# Insufficient materials (Joseph 2026-06-21): name the EXACT requirement in chat instead of a vague
# action-bar line. check_mats -> decor/cost/<id> baked the recipe string into build.costmsg; tellraw it.
execute if score #dec_has_mats ec.temp matches 0 run tellraw @s [{text:"✦ ",color:"red",bold:true},{text:"You need ",color:"gray"},{nbt:"build.costmsg",storage:"evercraft:decor",color:"yellow"},{text:" to build this furnishing.",color:"gray"}]
execute if score #dec_has_mats ec.temp matches 0 if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 0.7 0.6
execute if score #dec_has_mats ec.temp matches 0 run return 0

# --- (5) Consume the recipe materials (ideas only) + the decor item itself. ---
execute if score #dec_free ec.temp matches 0 run function evercraft:decor/use/consume_mats with storage evercraft:decor build
function evercraft:decor/use/clear_item with storage evercraft:decor build

# --- (6) Commit: this UID's ghost → placed sculpture; drop the pad; summon anchor + interaction. ---
execute store result storage evercraft:decor build.uid int 1 run scoreboard players get @s ec.dec_uid
execute store result storage evercraft:decor build.face int 1 run scoreboard players get @s ec.dec_face
execute store result storage evercraft:decor build.tx int 1 run scoreboard players get @s ec.dec_tgtx
execute store result storage evercraft:decor build.ty int 1 run scoreboard players get @s ec.dec_tgty
execute store result storage evercraft:decor build.tz int 1 run scoreboard players get @s ec.dec_tgtz
function evercraft:decor/preview/half_args
# Capture owner UUID halves + active home slot for the anchor NBT.
execute store result storage evercraft:decor build.ou0 int 1 run data get entity @s UUID[0]
execute store result storage evercraft:decor build.ou1 int 1 run data get entity @s UUID[1]
execute store result storage evercraft:decor build.ou2 int 1 run data get entity @s UUID[2]
execute store result storage evercraft:decor build.ou3 int 1 run data get entity @s UUID[3]
execute store result storage evercraft:decor build.home int 1 run scoreboard players get @s hs.active
# In-zone provenance (W3 removal owner-gate): 1 iff placed inside the placer's own claimed zone.
# Stamped on the anchor so reclaim permission needs NO live position→zone lookup (offline-safe).
scoreboard players set #dec_inzone ec.temp 0
execute if score @s hs.in_zone matches 1 run scoreboard players set #dec_inzone ec.temp 1
execute store result storage evercraft:decor build.inzone int 1 run scoreboard players get #dec_inzone ec.temp
# Free-build provenance for the anchor (reclaim must NOT 50%-refund materials that were never
# consumed — lament_reward reads data.free via the removal snapshot).
execute store result storage evercraft:decor build.free int 1 run scoreboard players get #dec_free ec.temp
function evercraft:decor/use/commit with storage evercraft:decor build

# --- (6b) Capstone live binds (placement-time only — zero new tick cost). The bound props summon
#         off $(tx) $(ty) $(tz) from build storage, carry ec.dec_disp + this UID, and reap with the
#         piece on reclaim (#evercraft:decor_displays). String-equality via the if-data compound-match. ---
execute if data storage evercraft:decor build{id:"reliquary_plinth"} run function evercraft:decor/tiein/plinth_bind with storage evercraft:decor build
execute if data storage evercraft:decor build{id:"trophy_shelf"} run function evercraft:decor/tiein/shelf_bind with storage evercraft:decor build

# --- (7) Credit-once (B1): only on first placement of a crafted instance, and only in-zone. ---
# Fresh items have no `counted`; reclaimed items return stamped counted:1b → skip the credit.
scoreboard players set #dec_counted ec.temp 0
execute store success score #dec_counted ec.temp if data storage evercraft:decor held.components."minecraft:custom_data".counted
execute if score @s hs.in_zone matches 1 if score #dec_counted ec.temp matches 0 run function evercraft:housing/decoration/credit
execute if score @s hs.in_zone matches 1 if score #dec_counted ec.temp matches 0 run function evercraft:decor/use/mark_counted with storage evercraft:decor build
# Live cap counter (in-zone only) — paired with decor/dec_owner_match (the reclaim decrement, W3).
execute if score @s hs.in_zone matches 1 run scoreboard players add @s hs.dec_live 1

# --- (8) Done: leave preview state; placement chord + happy particles. The tick self-stops. ---
scoreboard players set @s ec.dec_state 0
tag @s remove dec.previewing
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.7 1.2
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.harp master @s ~ ~ ~ 0.6 1.5
execute at @s positioned ~ ~0.3 ~ run particle minecraft:happy_villager ~ ~ ~ 0.5 0.3 0.5 0 8
