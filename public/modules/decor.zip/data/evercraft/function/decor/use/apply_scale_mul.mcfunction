# Furnishings — Re-apply scale_mul carried by the held item onto a fresh
# placement (MACRO {uid}). Called from commit.mcfunction when held carries a
# decor_scale_mul stamped by a prior Move/Store. Re-scales the new displays
# AND persists the multiplier onto the anchor so subsequent +/- math is
# correct from this baseline.

# Stage the factor into #factor (basis points × 1000).
execute store result score #factor ec.temp run data get storage evercraft:decor held.components."minecraft:custom_data".decor_scale_mul
# Guard (Joseph 2026-06-14): a corrupt/0 decor_scale_mul would scale every display to ~0 → the piece
# is INVISIBLE after a store->replace (a rotate re-runs the build and brings it back — the exact bug
# reported). Clamp any out-of-range factor to 1000 (1.0x) so a bad value renders FULL-SIZE, never gone.
execute unless score #factor ec.temp matches 250..3000 run scoreboard players set #factor ec.temp 1000

# Persist on the anchor.
$execute as @e[type=marker,tag=ec.dec_anchor,scores={ec.dec_uid=$(uid)},limit=1] store result entity @s data.scale_mul int 1 run scoreboard players get #factor ec.temp

# Apply to every fresh display of this piece.
$execute as @e[type=#evercraft:decor_displays,tag=ec.dec_disp,scores={ec.dec_uid=$(uid)}] run function evercraft:decor/use/scale_disp_apply
