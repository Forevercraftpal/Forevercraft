# Furnishings — Remove one of the placed decor item from the player's inventory (MACRO)
# Args (storage build): id, mat. Byte matchers (decor:1b) per B8 — JSON true would silently
# never match the item component.
# Ideas/Blueprints economy (2026-06-09): the matcher is VARIANT-precise (id + mat) and
# free-flag-precise — placing an Idea must never eat a drafted Blueprint of the same piece
# (or a different wood/dye variant) sitting elsewhere in the inventory, and vice versa.
# #dec_free was set by confirm step (4) from the held item.
$execute if score #dec_free ec.temp matches 0 run clear @s *[custom_data~{decor:1b,decor_id:"$(id)",decor_mat:"$(mat)"},!custom_data~{decor_free:1b}] 1
$execute if score #dec_free ec.temp matches 1 run clear @s *[custom_data~{decor:1b,decor_free:1b,decor_id:"$(id)",decor_mat:"$(mat)"}] 1
