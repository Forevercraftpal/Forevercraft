# Furnishings — Apply #factor (basis points × 1000) to one display's transform.
# Run as the display entity. #factor must be staged on ec.temp before the @e
# iteration that calls us. Mirrors manage/scale_disp_up but with an arbitrary
# multiplier read from a fake-player slot, so re-placement honours whatever
# scale the player had before Move/Store.

# scale[0..2]
execute store result score #ds ec.temp run data get entity @s transformation.scale[0] 1000
scoreboard players operation #ds ec.temp *= #factor ec.temp
scoreboard players operation #ds ec.temp /= #1000 ec.const
execute store result entity @s transformation.scale[0] float 0.001 run scoreboard players get #ds ec.temp
execute store result score #ds ec.temp run data get entity @s transformation.scale[1] 1000
scoreboard players operation #ds ec.temp *= #factor ec.temp
scoreboard players operation #ds ec.temp /= #1000 ec.const
execute store result entity @s transformation.scale[1] float 0.001 run scoreboard players get #ds ec.temp
execute store result score #ds ec.temp run data get entity @s transformation.scale[2] 1000
scoreboard players operation #ds ec.temp *= #factor ec.temp
scoreboard players operation #ds ec.temp /= #1000 ec.const
execute store result entity @s transformation.scale[2] float 0.001 run scoreboard players get #ds ec.temp

# translation[0..2]
execute store result score #ds ec.temp run data get entity @s transformation.translation[0] 1000
scoreboard players operation #ds ec.temp *= #factor ec.temp
scoreboard players operation #ds ec.temp /= #1000 ec.const
execute store result entity @s transformation.translation[0] float 0.001 run scoreboard players get #ds ec.temp
execute store result score #ds ec.temp run data get entity @s transformation.translation[1] 1000
scoreboard players operation #ds ec.temp *= #factor ec.temp
scoreboard players operation #ds ec.temp /= #1000 ec.const
execute store result entity @s transformation.translation[1] float 0.001 run scoreboard players get #ds ec.temp
execute store result score #ds ec.temp run data get entity @s transformation.translation[2] 1000
scoreboard players operation #ds ec.temp *= #factor ec.temp
scoreboard players operation #ds ec.temp /= #1000 ec.const
execute store result entity @s transformation.translation[2] float 0.001 run scoreboard players get #ds ec.temp
