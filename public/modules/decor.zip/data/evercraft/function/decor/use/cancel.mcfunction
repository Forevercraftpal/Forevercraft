# Furnishings — Cancel preview (run as @s; clone of blueprints/use/cancel)
# Kills this UID's ghost + pad, resets state, soft sound + note.
execute store result storage evercraft:decor build.uid int 1 run scoreboard players get @s ec.dec_uid
function evercraft:decor/use/cancel_clear with storage evercraft:decor build
scoreboard players set @s ec.dec_state 0
scoreboard players set @s ec.dec_cancel_at 0
tag @s remove dec.previewing
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 0.5 0.8
data modify storage evercraft:notify stage.c set value [{text:"Placement cancelled.",color:"gray"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
