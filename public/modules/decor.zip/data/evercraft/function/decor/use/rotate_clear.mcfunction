# Furnishings — Kill this UID's ghost SCULPTURE only, keep the pad (MACRO; rotate helper)
# Args (storage build): uid. The pad is left for validate to refresh; only the baked-rotation
# sculpture is destroyed so render can re-summon it at the new facing.
$kill @e[type=#evercraft:decor_displays,tag=ec.dec_ghost,tag=!ec.dec_pad,scores={ec.dec_uid=$(uid)}]
