# Furnishings — Flag this UID's anchor as already-credited (MACRO; credit-once — B1)
# Args (storage build): uid. Sets data.counted:1b so a reclaim→replace cycle (the reclaimed item
# returns stamped counted:1b) never re-credits hs.decor / Building XP toward the House-Key award.
$data modify entity @e[type=marker,tag=ec.dec_anchor,scores={ec.dec_uid=$(uid)},limit=1] data.counted set value 1b
