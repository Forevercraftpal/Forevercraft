# Furnishings — Main dispatch (run as the player with ec.dec_use=1+; mirrors blueprints/use/on_use)
# Use flag is edge-gated + cleared by the tick dispatch (ec.dec_held latch); on_use runs
# once per press, so no per-tick reset here.

# Cooldown (secondary debounce; the edge latch is the primary one-action-per-press gate)
execute if score @s ec.dec_cd matches 1.. run return 0

# Snapshot the held item (mainhand). Bail unless it carries the decor flag.
data modify storage evercraft:decor held set from entity @s SelectedItem
execute unless data storage evercraft:decor held.components."minecraft:custom_data".decor run return 0

# Set cooldown (3 ticks)
scoreboard players set @s ec.dec_cd 3

# Branch (controls SWAPPED 2026-06-10, Joseph: sneak = the deliberate build action, plain = browse):
#   previewing (state 1): sneak + use = CONFIRM the build · use = rotate the ghost 90°
#   idle       (state 0): sneak + use = raise the preview · use = open the Ideas & Blueprints catalogue
# `return run` everywhere is LOAD-BEARING: enter_preview/confirm mutate ec.dec_state, so plain
# sequential dispatch would fall through into the next branch IN THE SAME PRESS — one click
# previewed AND instantly built/consumed (hit live 2026-06-09).
execute if score @s ec.dec_state matches 1 if predicate evercraft:is_sneaking run return run function evercraft:decor/use/confirm
execute if score @s ec.dec_state matches 1 run return run function evercraft:decor/use/rotate
# Idle + sneaking → start placing (fold the standalone catalogue away first if it's up).
execute if predicate evercraft:is_sneaking if entity @s[tag=DEC.Standalone] run function evercraft:decor/gui/close
execute if predicate evercraft:is_sneaking run return run function evercraft:decor/use/enter_preview
# Idle + plain use → the catalogue (toggles closed if already browsing).
function evercraft:decor/gui/open_standalone
