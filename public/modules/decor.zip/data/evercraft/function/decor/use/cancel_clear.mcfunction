# Furnishings — Kill this UID's ghost + pad (MACRO; cancel helper)
# Args (storage build): uid. Both the sculpture and the pad carry ec.dec_ghost + this UID, so a
# single kill clears the whole preview for this instance.
$kill @e[type=#evercraft:decor_displays,tag=ec.dec_ghost,scores={ec.dec_uid=$(uid)}]
