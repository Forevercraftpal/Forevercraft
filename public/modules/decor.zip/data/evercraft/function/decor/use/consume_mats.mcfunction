# Furnishings — Dispatch the per-item material consume (MACRO; destructive)
# Args (storage build): id, mat. Routes to the W1 consume table decor/consume/<id> (a macro that
# spends $(mat)_planks / $(mat)_wool / literal mats). Only called after check_mats passed.
$function evercraft:decor/consume/$(id) with storage evercraft:decor build
