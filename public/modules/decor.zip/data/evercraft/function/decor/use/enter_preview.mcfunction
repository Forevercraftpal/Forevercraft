# Furnishings — Enter preview mode (clone of blueprints/use/enter_preview UID flow — B5)
# Summons the live ghost + footprint pad ONCE; the tick teleports them on aim-change (B3),
# never rebuilds. Per-player/per-instance UID owner-binds every summoned entity (no distance races).

# State + facing init.
scoreboard players set @s ec.dec_state 1
scoreboard players set @s ec.dec_face 0

# Assign a fresh UID for this preview session.
function evercraft:decor/use/assign_uid

# Build the macro arg set (id, mat, face, uid) from the held-item snapshot + scores.
data modify storage evercraft:decor build.id set from storage evercraft:decor held.components."minecraft:custom_data".decor_id
data modify storage evercraft:decor build.mat set from storage evercraft:decor held.components."minecraft:custom_data".decor_mat
execute store result storage evercraft:decor build.face int 1 run scoreboard players get @s ec.dec_face
execute store result storage evercraft:decor build.uid int 1 run scoreboard players get @s ec.dec_uid

# Cast the look-ray → sets ec.dec_tgtx/y/z (the placement cell).
function evercraft:decor/preview/raycast

# Copy the target cell into the build macro args (the render positions there).
execute store result storage evercraft:decor build.tx int 1 run scoreboard players get @s ec.dec_tgtx
execute store result storage evercraft:decor build.ty int 1 run scoreboard players get @s ec.dec_tgty
execute store result storage evercraft:decor build.tz int 1 run scoreboard players get @s ec.dec_tgtz
function evercraft:decor/preview/half_args

# Render the ghost + pad at the target cell (macro: rotated $(face) 0 → build/$(id)).
function evercraft:decor/preview/render with storage evercraft:decor build

# Stamp this UID on the freshly-summoned, not-yet-stamped ghost displays (mirror
# enter_preview_body:24-25 — B5). The render just summoned them tagged ec.dec_ghost; any
# ec.dec_ghost within 32 blocks lacking ec.dec_stamped is one of ours (prior sessions already
# carry the guard tag, so no collision).
execute store result storage evercraft:decor build.uid int 1 run scoreboard players get @s ec.dec_uid
function evercraft:decor/preview/stamp_uid with storage evercraft:decor build

# Footprint pad (flat lime/red block_displays, uid-stamped) + validity colors.
function evercraft:decor/preview/validate

# Mark previewing + per-player auto-cancel countdown (30s = 600t, decremented by tick).
tag @s add dec.previewing
scoreboard players set @s ec.dec_cancel_at 600

# Drive the live ghost-follow tick (1t so the ghost tracks the crosshair; raycast throttled inside).
schedule function evercraft:decor/preview/tick 1t replace

# Sound.
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.6 1.0
