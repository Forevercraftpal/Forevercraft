# Furnishings — Assign a fresh per-player/per-instance UID (mirrors blueprints/internal/assign_uid)
# Call before each preview-enter so every summoned ghost/pad/anchor/interaction carries this UID.
# Stable within a single preview→placed session; reassigned on each new enter_preview.
scoreboard players add #dec_uid ec.var 1
scoreboard players operation @s ec.dec_uid = #dec_uid ec.var
