# Furnishings — using_item reward (revoke + flag, mirrors blueprints/use/on_use_trigger)
advancement revoke @s only evercraft:decor/use
scoreboard players set @s ec.dec_use 1
