# Furnishings — Dispatch the per-item material check (MACRO; sets #dec_has_mats)
# Args (storage build): id, mat. Routes to the W1 cost table decor/cost/<id> (itself a macro that
# reads $(mat) for the per-wood/per-dye variants). Non-destructive — only counts.
$function evercraft:decor/cost/$(id) with storage evercraft:decor build
