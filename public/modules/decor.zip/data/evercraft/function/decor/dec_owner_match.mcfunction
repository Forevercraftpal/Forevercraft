# Furnishings — Per-player owner match for the hs.dec_live decrement (run as each online player @s)
# Context: #dec_own_o0 / #dec_own_o1 ec.temp = the anchor owner UUID high-2 halves (set by dec_owner_live).
# If @s's UUID matches both halves, decrement their hs.dec_live by 1, floored at 0 (so a desync — e.g. a
# piece reclaimed twice across a counter reset — can never push the cap negative and soft-lock placement).

execute store result score #dec_p_o0 ec.temp run data get entity @s UUID[0]
execute unless score #dec_p_o0 ec.temp = #dec_own_o0 ec.temp run return 0
execute store result score #dec_p_o1 ec.temp run data get entity @s UUID[1]
execute unless score #dec_p_o1 ec.temp = #dec_own_o1 ec.temp run return 0

# This player is the owner — decrement, floored at 0 (only when there's something to remove).
execute if score @s hs.dec_live matches 1.. run scoreboard players remove @s hs.dec_live 1
