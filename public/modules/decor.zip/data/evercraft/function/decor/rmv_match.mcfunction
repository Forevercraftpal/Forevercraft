# Furnishings — Per-player REMOVER match for the Lamentor reclaim reward (run as each online player @s)
# Context: #dec_rmv_r0 / #dec_rmv_r1 ec.temp = the verified clicker's UUID high-2 halves (set in
# decor/remove step 5 from storage temp.r0/r1, which click/check captured from the interaction's OWN
# player/attack record). Mirrors decor/dec_owner_match. Audit #57 row 7 (2026-06-09): the reward used to
# go to the NEAREST shears-holder (@p), which could mis-credit when two shears-holders stand stacked over
# one piece — the permission gate already used the true clicker; now the reward does too. If the clicker
# disconnected in the same tick there is simply no payout (mirrors the offline-owner behavior of
# dec_owner_live) rather than paying a bystander.

execute store result score #dec_p_r0 ec.temp run data get entity @s UUID[0]
execute unless score #dec_p_r0 ec.temp = #dec_rmv_r0 ec.temp run return 0
execute store result score #dec_p_r1 ec.temp run data get entity @s UUID[1]
execute unless score #dec_p_r1 ec.temp = #dec_rmv_r1 ec.temp run return 0

# This player is the verified remover — pay the Lamentor reclaim ladder as them.
function evercraft:decor/lament_reward with storage evercraft:decor temp
