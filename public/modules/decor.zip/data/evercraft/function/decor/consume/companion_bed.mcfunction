# === FURNISHINGS CONSUME — companion_bed (destructive; spend the recipe materials) ===
$clear @s $(mat)_wool 2
clear @s minecraft:oak_planks 2
