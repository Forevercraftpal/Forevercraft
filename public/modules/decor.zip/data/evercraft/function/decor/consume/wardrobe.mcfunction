# === FURNISHINGS CONSUME — wardrobe (destructive; spend the recipe materials) ===
$clear @s $(mat)_planks 6
