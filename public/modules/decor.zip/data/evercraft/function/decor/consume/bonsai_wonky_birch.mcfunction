# === FURNISHINGS CONSUME — bonsai_wonky_birch (destructive; spend the recipe materials) ===
clear @s minecraft:flower_pot 1
clear @s minecraft:birch_sapling 1
