# === FURNISHINGS CONSUME — market_stall (destructive; spend the recipe materials) ===
clear @s minecraft:oak_planks 4
$clear @s $(mat)_wool 3
