# === FURNISHINGS CONSUME — cushion_pile (destructive; spend the recipe materials) ===
$clear @s $(mat)_wool 3
