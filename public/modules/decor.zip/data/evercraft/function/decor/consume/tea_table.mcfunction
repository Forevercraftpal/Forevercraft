# === FURNISHINGS CONSUME — tea_table (destructive; spend the recipe materials) ===
$clear @s $(mat)_planks 3
