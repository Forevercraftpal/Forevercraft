# === FURNISHINGS CONSUME — bonsai_wonky_azalea (destructive; spend the recipe materials) ===
clear @s minecraft:flower_pot 1
clear @s minecraft:azalea 1
