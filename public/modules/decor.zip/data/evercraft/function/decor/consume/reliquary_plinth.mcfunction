# === FURNISHINGS CONSUME — reliquary_plinth (destructive; spend the recipe materials) ===
clear @s minecraft:quartz_block 3
clear @s minecraft:gold_ingot 2
