# === FURNISHINGS CONSUME — bonsai_wonky_oak (destructive; spend the recipe materials) ===
clear @s minecraft:flower_pot 1
clear @s minecraft:oak_sapling 1
