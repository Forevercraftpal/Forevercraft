# === FURNISHINGS CONSUME — kitchen_cabinet (destructive; spend the recipe materials) ===
clear @s minecraft:oak_planks 5
clear @s minecraft:smooth_stone 1
