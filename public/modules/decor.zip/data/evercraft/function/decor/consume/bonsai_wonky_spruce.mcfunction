# === FURNISHINGS CONSUME — bonsai_wonky_spruce (destructive; spend the recipe materials) ===
clear @s minecraft:flower_pot 1
clear @s minecraft:spruce_sapling 1
