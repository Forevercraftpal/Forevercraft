# === FURNISHINGS CONSUME — rug (destructive; spend the recipe materials) ===
$clear @s $(mat)_wool 4
