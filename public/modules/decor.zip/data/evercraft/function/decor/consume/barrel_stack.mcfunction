# === FURNISHINGS CONSUME — barrel_stack (destructive; spend the recipe materials) ===
clear @s minecraft:oak_planks 3
clear @s minecraft:iron_nugget 1
