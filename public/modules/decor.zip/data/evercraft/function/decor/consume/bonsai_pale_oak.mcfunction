# === FURNISHINGS CONSUME — bonsai_pale_oak (destructive; spend the recipe materials) ===
clear @s minecraft:flower_pot 1
clear @s minecraft:pale_oak_sapling 1
