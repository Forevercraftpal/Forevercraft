# === FURNISHINGS CONSUME — lamppost (destructive; spend the recipe materials) ===
clear @s minecraft:iron_ingot 2
clear @s minecraft:lantern 1
