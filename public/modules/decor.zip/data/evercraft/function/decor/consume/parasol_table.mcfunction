# === FURNISHINGS CONSUME — parasol_table (destructive; spend the recipe materials) ===
clear @s minecraft:oak_planks 3
$clear @s $(mat)_wool 2
