# === FURNISHINGS CONSUME — bonsai_dark_oak (destructive; spend the recipe materials) ===
clear @s minecraft:flower_pot 1
clear @s minecraft:dark_oak_sapling 1
