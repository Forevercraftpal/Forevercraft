# === FURNISHINGS CONSUME — display_case (destructive; spend the recipe materials) ===
$clear @s $(mat) 2
clear @s minecraft:glass 2
