# === FURNISHINGS CONSUME — garden_bench (destructive; spend the recipe materials) ===
$clear @s $(mat)_planks 5
