# === FURNISHINGS CONSUME — bonsai_wonky_acacia (destructive; spend the recipe materials) ===
clear @s minecraft:flower_pot 1
clear @s minecraft:acacia_sapling 1
