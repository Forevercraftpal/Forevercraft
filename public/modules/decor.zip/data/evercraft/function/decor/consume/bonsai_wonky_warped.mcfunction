# === FURNISHINGS CONSUME — bonsai_wonky_warped (destructive; spend the recipe materials) ===
clear @s minecraft:flower_pot 1
clear @s minecraft:warped_fungus 1
