# === FURNISHINGS CONSUME — bonsai_wonky_cherry (destructive; spend the recipe materials) ===
clear @s minecraft:flower_pot 1
clear @s minecraft:cherry_sapling 1
