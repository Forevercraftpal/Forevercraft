# === FURNISHINGS CONSUME — bee_hotel (destructive; spend the recipe materials) ===
clear @s minecraft:oak_planks 3
clear @s minecraft:honeycomb 1
