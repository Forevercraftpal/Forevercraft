# === FURNISHINGS CONSUME — bonsai_mangrove (destructive; spend the recipe materials) ===
clear @s minecraft:flower_pot 1
clear @s minecraft:mangrove_propagule 1
