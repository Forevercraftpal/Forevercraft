# === FURNISHINGS CONSUME — alchemy_shelf (destructive; spend the recipe materials) ===
clear @s minecraft:spruce_planks 4
clear @s minecraft:glass_bottle 1
