# === FURNISHINGS CONSUME — brazier (destructive; spend the recipe materials) ===
clear @s minecraft:iron_ingot 3
clear @s minecraft:coal 2
