# === FURNISHINGS CONSUME — display_case_grand (destructive; spend the recipe materials) ===
$clear @s $(mat) 5
clear @s minecraft:glass 3
clear @s minecraft:gold_ingot 1
