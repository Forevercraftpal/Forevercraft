# === FURNISHINGS CONSUME — candelabra (destructive; spend the recipe materials) ===
clear @s minecraft:candle 3
clear @s minecraft:iron_ingot 1
