# === FURNISHINGS CONSUME — post_lantern (destructive; spend the recipe materials) ===
clear @s minecraft:iron_nugget 2
clear @s minecraft:lantern 1
