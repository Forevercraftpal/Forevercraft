# === FURNISHINGS CONSUME — bath_tub (destructive; spend the recipe materials) ===
clear @s minecraft:quartz_block 4
clear @s minecraft:water_bucket 1
