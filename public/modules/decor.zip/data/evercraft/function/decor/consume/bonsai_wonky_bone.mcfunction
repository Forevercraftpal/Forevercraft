# === FURNISHINGS CONSUME — bonsai_wonky_bone (destructive; spend the recipe materials) ===
clear @s minecraft:flower_pot 1
clear @s minecraft:dead_bush 1
