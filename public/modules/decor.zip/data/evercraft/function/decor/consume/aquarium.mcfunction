# === FURNISHINGS CONSUME — aquarium (destructive; spend the recipe materials) ===
clear @s minecraft:glass 4
clear @s minecraft:sand 2
