# === FURNISHINGS CONSUME — weapon_rack (destructive; spend the recipe materials) ===
clear @s minecraft:dark_oak_planks 4
clear @s minecraft:iron_ingot 1
