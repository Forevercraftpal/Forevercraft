# === FURNISHINGS CONSUME — garden_swing (destructive; spend the recipe materials) ===
$clear @s $(mat)_planks 4
clear @s minecraft:iron_nugget 1
