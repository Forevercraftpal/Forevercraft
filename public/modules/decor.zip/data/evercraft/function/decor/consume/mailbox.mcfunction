# === FURNISHINGS CONSUME — mailbox (destructive; spend the recipe materials) ===
clear @s minecraft:oak_planks 2
clear @s minecraft:iron_nugget 1
