# === FURNISHINGS CONSUME — fire_pit (destructive; spend the recipe materials) ===
clear @s minecraft:cobblestone 4
clear @s minecraft:campfire 1
