# === FURNISHINGS CONSUME — wind_chimes (destructive; spend the recipe materials) ===
clear @s minecraft:copper_ingot 2
clear @s minecraft:amethyst_shard 1
