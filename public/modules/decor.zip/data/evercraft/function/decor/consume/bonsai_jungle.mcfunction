# === FURNISHINGS CONSUME — bonsai_jungle (destructive; spend the recipe materials) ===
clear @s minecraft:flower_pot 1
clear @s minecraft:jungle_sapling 1
