# === FURNISHINGS CONSUME — writing_desk (destructive; spend the recipe materials) ===
$clear @s $(mat)_planks 4
clear @s minecraft:feather 1
clear @s minecraft:ink_sac 1
