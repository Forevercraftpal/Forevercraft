# Iluminación de Ne — load (registry + objective + aura schedule). Called from decor/load.
# A rare candle the player sets onto a placed LIGHT furnishing; each candle grants +1 Dream Rank to
# everyone within 64 blocks. Per-piece capacity below; only ONE candle-bearing piece of each KIND counts
# (two candelabras don't stack — a candelabra + a chandelier do). See decor/candle/recompute.

# Capacity registry: id -> max candles. ANY id with an entry is candle-capable (route_probe store-success
# keys off this). Light furnishings + the tea table (Joseph 2026-06-15).
data modify storage evercraft:candle cap set value {candelabra:3,chandelier:4,fireplace:2,fairy_lights:2,bookshelf_nook:1,tea_table:1,lamppost:1,post_lantern:1,wall_sconce:1,floor_lamp:1,dream_lantern:1,vanity_mirror:1,brazier:1,fire_pit:1,display_case_grand:1,aquarium_grand:1}

# Per-player live candle-DR bonus AMOUNT (summed over distinct nearby candle-bearing kinds, ≤ each cap).
# Recomputed every 1s by decor/candle/recompute; READ into dr.points by dream_rank/calculate.
scoreboard objectives add ec.ilum_dr dummy "Iluminacion de Ne: DR aura"

# Aura loop (self-rearming, existence-gated to ec.has_candle anchors → idles when none placed).
schedule function evercraft:decor/candle/tick 40t replace
