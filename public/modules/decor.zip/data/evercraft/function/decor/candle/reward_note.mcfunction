# Iluminación de Ne — shared "rare candle!" bonus popup (quest / loot bonus drops). Run as @s = player.
data modify storage evercraft:notify stage.c set value [{text:"🕯 ",color:"#FFD27F"},{text:"Rare find — an ",color:"#C8B68A"},{text:"Iluminación de Ne",color:"#FFD27F"},{text:" candle!",color:"#C8B68A"}]
scoreboard players set #ndur ec.temp 55
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.candle.ambient master @s ~ ~ ~ 0.9 1.1
