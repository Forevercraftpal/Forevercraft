# Iluminación de Ne — set a candle onto the clicked light furnishing. Run AS the player from
# click_bare/try (candle held + #cb_candle flagged the piece; route stashed the piece UID in
# #cb_cnd_uid). Increments the anchor's data.candles up to the piece's capacity, consumes 1 candle,
# tags the piece ec.has_candle (the aura gate), and lights it. The DR itself is the proximity aura.

# Stage the clicked piece's id (by the exact UID route captured) for the capacity lookup.
data remove storage evercraft:candle t
execute as @e[type=marker,tag=ec.dec_anchor] if score @s ec.dec_uid = #cb_cnd_uid ec.temp run data modify storage evercraft:candle t.id set from entity @s data.id
execute unless data storage evercraft:candle t.id run return 0

# Current candle count (absent → 0) + this id's capacity.
scoreboard players set #cnd_cur ec.temp 0
execute as @e[type=marker,tag=ec.dec_anchor] if score @s ec.dec_uid = #cb_cnd_uid ec.temp store result score #cnd_cur ec.temp run data get entity @s data.candles
scoreboard players set #cnd_cap ec.temp 0
function evercraft:decor/candle/lookup_cap with storage evercraft:candle t

# Already full → tell them, don't consume.
execute if score #cnd_cur ec.temp >= #cnd_cap ec.temp run return run function evercraft:decor/candle/full

# Apply: +1 candle on the piece (and tag it for the aura), consume one from the hand.
scoreboard players add #cnd_cur ec.temp 1
execute as @e[type=marker,tag=ec.dec_anchor] if score @s ec.dec_uid = #cb_cnd_uid ec.temp run function evercraft:decor/candle/write_cur
item modify entity @s weapon.mainhand evercraft:decor/shrink_one

# Light it: a one-time flame + sound at the piece, and confirm to the player.
execute as @e[type=marker,tag=ec.dec_anchor] if score @s ec.dec_uid = #cb_cnd_uid ec.temp at @s run particle minecraft:flame ~ ~1 ~ 0.15 0.2 0.15 0.01 8
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.candle.ambient master @s ~ ~ ~ 0.7 1.2
data modify storage evercraft:notify stage.c set value [{text:"🕯 ",color:"#FFD27F"},{text:"Candle set — ",color:"#C8B68A"},{score:{name:"#cnd_cur",objective:"ec.temp"},color:"#FFD27F"},{text:"/",color:"dark_gray"},{score:{name:"#cnd_cap",objective:"ec.temp"},color:"gray"},{text:" · +Dream Rank within 64",color:"#C8B68A"}]
scoreboard players set #ndur ec.temp 50
function evercraft:util/notify/emit
