# Iluminación de Ne — add ONE kind's contribution to the player's bonus (MACRO {id}, from recompute).
# #ic_n = candle count of the nearest LIT piece of this kind within 64 (0 if none → adds nothing).
# data.candles is only ever ≥1 on ec.has_candle pieces, so an unlit piece can't shadow a lit one of the
# same kind (the selector requires the tag). Run AS the player, AT them.
scoreboard players set #ic_n ec.temp 0
$execute store result score #ic_n ec.temp run data get entity @e[type=marker,tag=ec.has_candle,nbt={data:{id:"$(id)"}},distance=..64,limit=1,sort=nearest] data.candles
scoreboard players operation @s ec.ilum_dr += #ic_n ec.temp
