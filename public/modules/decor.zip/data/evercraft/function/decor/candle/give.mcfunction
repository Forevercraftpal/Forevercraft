# Iluminación de Ne — admin give (testing). Run as: a player.
# Usage: function evercraft:decor/candle/give
loot give @s loot evercraft:candle/ilum_ne
tellraw @s [{text:"[admin] ",color:"dark_gray"},{text:"Gave 1 Iluminación de Ne — set it on a candelabra/chandelier/light furnishing, then read your Dream Rank.",color:"#FFD27F"}]
