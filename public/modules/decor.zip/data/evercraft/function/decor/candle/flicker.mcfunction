# Iluminación de Ne — ambient candlelight on a lit piece (count-scaled). Run AS the anchor, AT it.
# Subtle small_flame at ~1 block up (reads on table-top + standing light furnishings); extra wisps as
# more candles are set. Particles only render for nearby clients, so no per-listener FX gate needed.
execute store result score #fl_n ec.temp run data get entity @s data.candles
particle minecraft:small_flame ~ ~1.0 ~ 0.12 0.16 0.12 0.0 1
execute if score #fl_n ec.temp matches 2.. run particle minecraft:small_flame ~ ~1.05 ~ 0.18 0.2 0.18 0.0 1
execute if score #fl_n ec.temp matches 3.. run particle minecraft:end_rod ~ ~1.1 ~ 0.16 0.18 0.16 0.0 1
