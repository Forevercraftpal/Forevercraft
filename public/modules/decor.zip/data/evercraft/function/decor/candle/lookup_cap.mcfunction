# Iluminación de Ne — resolve this piece's candle capacity into #cnd_cap (MACRO {id}, from apply).
$execute store result score #cnd_cap ec.temp run data get storage evercraft:candle cap.$(id)
