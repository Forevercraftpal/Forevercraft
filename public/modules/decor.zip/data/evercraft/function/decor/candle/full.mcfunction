# Iluminación de Ne — the piece is already at capacity; don't waste a candle. Run AS the player.
data modify storage evercraft:notify stage.c set value [{text:"🕯 ",color:"#FFD27F"},{text:"This piece holds all the candles it can (",color:"#C8B68A"},{score:{name:"#cnd_cap",objective:"ec.temp"},color:"gray"},{text:").",color:"#C8B68A"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 0.5 0.8
