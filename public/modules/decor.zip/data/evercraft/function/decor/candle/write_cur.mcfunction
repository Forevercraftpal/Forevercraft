# Iluminación de Ne — commit the new candle count onto this anchor + arm the aura tag. Run AS the anchor.
execute store result entity @s data.candles int 1 run scoreboard players get #cnd_cur ec.temp
tag @s add ec.has_candle
