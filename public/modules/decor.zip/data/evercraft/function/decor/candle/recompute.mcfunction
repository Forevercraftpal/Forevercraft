# Iluminación de Ne — recompute this player's candle-DR bonus. Run AS the player, AT them.
# Sum, over each candle-capable KIND, the candle count of the NEAREST lit piece of that kind within 64
# (one per kind — two of the same kind don't stack; different kinds do). Fully recomputed each pass, so
# walking out of range drops it back to 0. The total lands in ec.ilum_dr, read by dream_rank/calculate.
scoreboard players set @s ec.ilum_dr 0
function evercraft:decor/candle/add_type {id:"candelabra"}
function evercraft:decor/candle/add_type {id:"chandelier"}
function evercraft:decor/candle/add_type {id:"fireplace"}
function evercraft:decor/candle/add_type {id:"fairy_lights"}
function evercraft:decor/candle/add_type {id:"bookshelf_nook"}
function evercraft:decor/candle/add_type {id:"tea_table"}
function evercraft:decor/candle/add_type {id:"lamppost"}
function evercraft:decor/candle/add_type {id:"post_lantern"}
function evercraft:decor/candle/add_type {id:"wall_sconce"}
function evercraft:decor/candle/add_type {id:"floor_lamp"}
function evercraft:decor/candle/add_type {id:"dream_lantern"}
function evercraft:decor/candle/add_type {id:"vanity_mirror"}
function evercraft:decor/candle/add_type {id:"brazier"}
function evercraft:decor/candle/add_type {id:"fire_pit"}
function evercraft:decor/candle/add_type {id:"display_case_grand"}
function evercraft:decor/candle/add_type {id:"aquarium_grand"}
