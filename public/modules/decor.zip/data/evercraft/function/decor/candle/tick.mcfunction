# Iluminación de Ne — aura loop (self-rearming 1s). Existence-gated to ec.has_candle anchors: candles are
# REALLY rare, so this idles (5s) when none are placed. While candle pieces exist it (a) recomputes each
# player's candle-DR bonus from their nearby pieces and (b) flickers candlelight on each lit piece.

# No lit pieces anywhere → clear every player's stale bonus and idle.
execute unless entity @e[type=marker,tag=ec.has_candle,limit=1] run scoreboard players set @a ec.ilum_dr 0
execute unless entity @e[type=marker,tag=ec.has_candle,limit=1] run return run schedule function evercraft:decor/candle/tick 100t replace

# Per-player DR recompute (zeroes then sums one-per-kind within 64).
execute as @a at @s run function evercraft:decor/candle/recompute

# Per-piece candlelight flicker (count-scaled, ambient).
execute as @e[type=marker,tag=ec.has_candle] at @s run function evercraft:decor/candle/flicker

schedule function evercraft:decor/candle/tick 20t replace
