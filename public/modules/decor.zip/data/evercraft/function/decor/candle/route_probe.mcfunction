# Iluminación de Ne — flag the clicked piece as candle-capable (MACRO {id}, run from click_bare/route as
# the interaction). store success = 1 iff the candle registry has a capacity entry for this id, else 0.
$execute store success score #cb_candle ec.temp run data get storage evercraft:candle cap.$(id)
