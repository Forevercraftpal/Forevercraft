# Tea Table — per-player roll (Joseph 2026-06-13, task #102)
# Run as the player who just qualified (riding a dec_seat within 6b of a
# tea_table, ec.tea_cd <= 0). Spec:
#   1/500 -> bad tail: poison / nausea / (blindness + slowness) for 30s
#   1/100 -> Dream +1: first hit permanent (luck modifier ec.tea_dream_perm),
#            subsequent hits temporary 15-min luck add stacked on top
#   else  -> random 15-min good: Regen / Strength / Resistance
# Cooldown gate (15 min = 18000 ticks) goes on regardless of which tail fires.

# Cooldown gate — set the timer so this player can't re-roll for 15 in-game
# minutes (18000 ticks; cd_tick decrements by 100 each 5s = 18000/100=180 cycles).
scoreboard players set @s ec.tea_cd 18000

# 1-500 roll into ec.temp.
execute store result score #tea_roll ec.temp run random value 1..500

# === BAD TAIL: 1/500 ===
execute if score #tea_roll ec.temp matches 1 run function evercraft:decor/tea/bad

# === DREAM +1: 1/100 (rolls 2..6 of the 1-500 range = 1% remaining after the 1/500 carve) ===
execute if score #tea_roll ec.temp matches 2..6 run function evercraft:decor/tea/dream

# === GOOD: everything else (~98.8%) ===
execute if score #tea_roll ec.temp matches 7..500 run function evercraft:decor/tea/good
