# Tea Table proximity-buff tick (Joseph 2026-06-13, task #102)
# Joseph's spec: any player SITTING (on a dec_seat) within 6 blocks of a
# tea_table anchor rolls the tea reward — random 15-min buff (regen / strength
# / resistance) most of the time, a rare 1/100 Dream +1 (first hit permanent,
# stacks add temp on top after) and a 1/500 bad-effect tail (poison / nausea /
# blindness+slowness, 30s). After ANY roll the player gets ec.tea_cd = 18000
# (15 minutes of game-ticks), counted down by cd_tick; while >0 no re-roll.
#
# Existence-gated. Self-rescheduling 5s tick (3-trial latency lines up with a
# realistic "sip" cadence and keeps the polling cost tiny). Stops when no
# tea_table anchors are loaded.

execute unless entity @e[type=marker,tag=ec.dec_anchor,nbt={data:{id:"tea_table"}},limit=1] run return run schedule function evercraft:decor/tea/tick 30s replace

# Per-anchor: every player riding a dec_seat within 6b and not in cooldown
# rolls. Cooldown gate is the score (ec.tea_cd>0) — countdown handled by
# cd_tick.
execute as @e[type=marker,tag=ec.dec_anchor,nbt={data:{id:"tea_table"}}] at @s as @a[distance=..6,predicate=evercraft:dec_riding_seat,scores={ec.tea_cd=..0}] run function evercraft:decor/tea/roll

schedule function evercraft:decor/tea/tick 5s replace
