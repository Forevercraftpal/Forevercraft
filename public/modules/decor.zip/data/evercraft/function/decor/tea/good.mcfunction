# Tea Table — good roll (15-min Regen / Strength / Resistance, one random pick)
# Run as the rolling player. 18000-tick duration = 15 minutes; amplifier 0 = level I.

execute store result score #tea_g ec.temp run random value 1..3
function evercraft:decor/antique/read_eff_near {id:"tea_table",radius:3}
execute if score #tea_g ec.temp matches 1 run function evercraft:decor/antique/self_buff {effect:"minecraft:regeneration",dur:900,amp:0}
execute if score #tea_g ec.temp matches 2 run function evercraft:decor/antique/self_buff {effect:"minecraft:strength",dur:900,amp:0}
execute if score #tea_g ec.temp matches 3 run function evercraft:decor/antique/self_buff {effect:"minecraft:resistance",dur:900,amp:0}

# Actionbar cue — the player should know they got the buff.
execute if score #tea_g ec.temp matches 1 run data modify storage evercraft:notify stage.c set value [{text:"☕ ",color:"green"},{text:"A warming sip",color:"yellow"},{text:" — Regeneration I for 15 min.",color:"gray",italic:true}]
execute if score #tea_g ec.temp matches 2 run data modify storage evercraft:notify stage.c set value [{text:"☕ ",color:"green"},{text:"A bracing sip",color:"yellow"},{text:" — Strength I for 15 min.",color:"gray",italic:true}]
execute if score #tea_g ec.temp matches 3 run data modify storage evercraft:notify stage.c set value [{text:"☕ ",color:"green"},{text:"A steadying sip",color:"yellow"},{text:" — Resistance I for 15 min.",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 50
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.6 1.4
