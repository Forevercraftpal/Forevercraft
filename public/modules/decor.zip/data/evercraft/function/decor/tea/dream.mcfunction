# Tea Table — Dream +1 roll (1/100, rolls 2..6 of the 1-500 carve)
# Run as the rolling player. First time: PERMANENT +1 luck (modifier ID
# evercraft:tea_dream_perm so reapply_permanent can restore it on rejoin).
# Subsequent hits: temporary +1 luck for 15 min stacked on top.

execute unless entity @s[tag=ec.tea_dream_perm] run tag @s add ec.tea_dream_perm
execute unless entity @s[tag=ec.tea_dream_perm_done] run attribute @s luck modifier add evercraft:tea_dream_perm 1.0 add_value
execute unless entity @s[tag=ec.tea_dream_perm_done] run tag @s add ec.tea_dream_perm_done
execute unless entity @s[tag=ec.tea_dream_perm_done] run data modify storage evercraft:notify stage.c set value [{text:"☾ ",color:"light_purple"},{text:"A dreaming sip",color:"gold",bold:true},{text:" — Dream Rate +1 ",color:"yellow"},{text:"permanent.",color:"light_purple",italic:true}]

# Stacked-on-top temp +1 once the permanent slot is already filled. Vanilla
# attribute modifiers don't support a TTL, so we add a uuid-suffixed temp
# modifier and schedule its removal 15 min later (via decor/tea/dream_temp_off
# tagged @a — the schedule fires globally; the remove is idempotent and only
# affects players whose temp modifier is still live).
execute if entity @s[tag=ec.tea_dream_perm_done] run attribute @s luck modifier add evercraft:tea_dream_temp 1.0 add_value
execute if entity @s[tag=ec.tea_dream_perm_done] run tag @s add ec.tea_dream_temp_on
execute if entity @s[tag=ec.tea_dream_perm_done] run schedule function evercraft:decor/tea/dream_temp_off 900s replace
execute if entity @s[tag=ec.tea_dream_perm_done] run data modify storage evercraft:notify stage.c set value [{text:"☾ ",color:"light_purple"},{text:"Another dreaming sip",color:"gold"},{text:" — Dream Rate +1 ",color:"yellow"},{text:"for 15 min ",color:"gray",italic:true},{text:"(on top of your permanent +1).",color:"light_purple",italic:true}]

scoreboard players set #ndur ec.temp 60
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.experience_orb.pickup master @s ~ ~ ~ 0.8 1.8
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.beacon.activate master @s ~ ~ ~ 0.5 1.6
