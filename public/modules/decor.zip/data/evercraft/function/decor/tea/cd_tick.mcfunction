# Tea Table — cooldown decrement tick (Joseph 2026-06-13)
# Self-rescheduling 5s tick that decrements ec.tea_cd by 100 ticks per fire on
# every player whose cooldown is >0. The cooldown is set to 18000 ticks (=15
# in-game minutes = 180 cycles of 5s real-time) by roll.mcfunction. Tick goes
# idle when no player has a positive cd.

execute unless entity @a[scores={ec.tea_cd=1..}] run return run schedule function evercraft:decor/tea/cd_tick 30s replace

scoreboard players remove @a[scores={ec.tea_cd=1..}] ec.tea_cd 100

schedule function evercraft:decor/tea/cd_tick 5s replace
