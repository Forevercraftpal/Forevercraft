# Tea Table — bad-tail roll (1/500, the bottom of the 1-500 random space)
# Run as the rolling player. 30-second debuff out of 3 random picks:
#   1: Poison I
#   2: Nausea I
#   3: Blindness I + Slowness I (paired so the screen-dim has matching feel)

execute store result score #tea_b ec.temp run random value 1..3
execute if score #tea_b ec.temp matches 1 run effect give @s minecraft:poison 30 0 false
execute if score #tea_b ec.temp matches 2 run effect give @s minecraft:nausea 30 0 false
execute if score #tea_b ec.temp matches 3 run effect give @s minecraft:blindness 30 0 false
execute if score #tea_b ec.temp matches 3 run effect give @s minecraft:slowness 30 0 false

# Actionbar — flavor matches the effect.
execute if score #tea_b ec.temp matches 1 run data modify storage evercraft:notify stage.c set value [{text:"☕ ",color:"dark_red"},{text:"A bitter sip",color:"red"},{text:" — Poison I for 30s.",color:"gray",italic:true}]
execute if score #tea_b ec.temp matches 2 run data modify storage evercraft:notify stage.c set value [{text:"☕ ",color:"dark_red"},{text:"A queasy sip",color:"red"},{text:" — Nausea I for 30s.",color:"gray",italic:true}]
execute if score #tea_b ec.temp matches 3 run data modify storage evercraft:notify stage.c set value [{text:"☕ ",color:"dark_red"},{text:"A clouding sip",color:"red"},{text:" — Blindness + Slowness for 30s.",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 50
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 0.6 0.5
