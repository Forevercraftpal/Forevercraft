# Tea Table — temp Dream +1 removal (Joseph 2026-06-13)
# Scheduled 15 minutes after dream.mcfunction adds the temp luck modifier.
# Idempotent: removes the modifier from any player still tagged ec.tea_dream_temp_on.
# If the player already lost it (rejoined, strip, etc.) the remove is a no-op.

execute as @a[tag=ec.tea_dream_temp_on] run attribute @s luck modifier remove evercraft:tea_dream_temp
tag @a remove ec.tea_dream_temp_on
