# Furnishings — Trophy Shelf live bind (MACRO; run AS the placer, from decor/use/confirm step 6b)
# Args (storage build): tx, ty, tz (placement cell origin = anchor coords), uid (this instance).
# Reads the placer's CAREER COMPETITION VICTORIES (ec.comp_wins — incremented once per outright 1st
# place in competition/end, a lifetime stat preserved across reloads) AT PLACEMENT and lands tiered
# trophy props on the two ledges. SNAPSHOT semantics: the shelf shows standing AT PLACEMENT — place
# anew to refresh (noted in the item lore). Every prop carries ec.dec_disp + this UID, so they reap
# with the piece on reclaim (#evercraft:decor_displays). PLACEMENT-TIME ONLY — nothing here ticks.
#
# Thresholds (calibrated to the data — competitions are dawn-gated, at most ONE per day via the Event
# Director, so an outright win is precious; a month of perfect victories is ~30 wins):
#   0  -> empty shelf, "the shelf waits"
#   >=1  copper trophy  (lower ledge, center)   — a genuine victory
#   >=3  + iron trophy  (lower ledge, offset)   — a steady champion
#   >=7  + gold trophy  (upper ledge, center)   — a week of victories
#   >=15 + amethyst accent (upper ledge, offset)— a rare, dedicated champion

# --- (1) Read this player's career wins into a temp. ---
scoreboard players set #shelf_wins ec.temp 0
execute store result score #shelf_wins ec.temp run scoreboard players get @s ec.comp_wins

# --- (2) Zero wins → no props; gray "waits" hint, then bail. ---
execute if score #shelf_wins ec.temp matches ..0 run data modify storage evercraft:notify stage.c set value [{text:"No victories yet — the shelf waits.",color:"gray",italic:true}]
execute if score #shelf_wins ec.temp matches ..0 run scoreboard players set #ndur ec.temp 50
execute if score #shelf_wins ec.temp matches ..0 run function evercraft:util/notify/emit
execute if score #shelf_wins ec.temp matches ..0 run return 0

# --- (3) Tiered trophy props — small block_displays on the ledges. Each is summoned at the anchor
#         origin $(tx) $(ty) $(tz) and lifted/centered via transformation.translation. Tagged
#         ec.dec_disp (reaps with the piece) + ec.dec_new (transient UID-stamp). Lower ledge top ~y
#         0.58, upper ledge top ~y 1.08 (a ~0.18 cube's translation = spot - half-scale). ---
# >=1 : copper trophy — lower ledge, centered.
$execute if score #shelf_wins ec.temp matches 1.. run summon block_display $(tx) $(ty) $(tz) {Tags:["ec.dec_disp","ec.dec_new"],block_state:{Name:"minecraft:waxed_cut_copper"},brightness:{sky:15,block:15},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[-0.11f,0.58f,-0.31f],scale:[0.22f,0.3f,0.22f]}}
# >=3 : iron trophy — lower ledge, offset +x.
$execute if score #shelf_wins ec.temp matches 3.. run summon block_display $(tx) $(ty) $(tz) {Tags:["ec.dec_disp","ec.dec_new"],block_state:{Name:"minecraft:iron_block"},brightness:{sky:15,block:15},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0.18f,0.58f,-0.31f],scale:[0.2f,0.27f,0.2f]}}
# >=7 : gold trophy — upper ledge, centered.
$execute if score #shelf_wins ec.temp matches 7.. run summon block_display $(tx) $(ty) $(tz) {Tags:["ec.dec_disp","ec.dec_new"],block_state:{Name:"minecraft:gold_block"},brightness:{sky:15,block:15},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[-0.11f,1.08f,-0.31f],scale:[0.22f,0.3f,0.22f]}}
# >=15 : amethyst accent — upper ledge, offset -x.
$execute if score #shelf_wins ec.temp matches 15.. run summon block_display $(tx) $(ty) $(tz) {Tags:["ec.dec_disp","ec.dec_new"],block_state:{Name:"minecraft:amethyst_block"},brightness:{sky:15,block:15},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[-0.38f,1.08f,-0.31f],scale:[0.18f,0.24f,0.18f]}}

# --- (4) Facing (R1 council fix 2026-06-10): stamp the placement yaw on every prop so the trophies
#         ride their ledges in all 4 facings — summon never inherits execute rotation, and displays
#         default to billboard "fixed". Then UID-stamp and drop the transient tag (mirror commit's
#         pattern). Select by ec.dec_new, scoped ..16 (R2 — raycast places up to ~13.6 blocks out);
#         commit dropped its own ec.dec_new before this bind runs, so the props are the only carriers. ---
$execute as @e[tag=ec.dec_new,distance=..16] run data modify entity @s Rotation set value [$(face)f,0f]
$scoreboard players set @e[tag=ec.dec_new,distance=..16] ec.dec_uid $(uid)
tag @e[tag=ec.dec_new,distance=..16] remove ec.dec_new

# --- (5) Notify the count (score component reads the live ec.comp_wins) + a soft chime (note-block
#         per the FX palette; gated on ec.fx_snd). ---
data modify storage evercraft:notify stage.c set value [{text:"Your shelf honors ",color:"white"},{score:{name:"@s",objective:"ec.comp_wins"},color:"gold"},{text:" victories.",color:"white"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.6 1.3
