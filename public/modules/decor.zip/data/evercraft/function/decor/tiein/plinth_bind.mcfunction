# Furnishings — Reliquary Plinth live bind (MACRO; run AS the placer, from decor/use/confirm step 6b)
# Args (storage build): tx, ty, tz (the placement cell origin = anchor coords), uid (this instance).
# Reads the placer's OFF-HAND relic AT PLACEMENT and floats a COPY of it above the column. The relic
# is NEVER consumed or modified — we copy its item NBT verbatim into a display (council P1-4). The
# display carries ec.dec_disp + this UID, so it reaps with the piece on reclaim (#evercraft:decor_displays
# includes item_display → decor/remove kills it). PLACEMENT-TIME ONLY — nothing here ticks.

# --- (1) Snapshot the off-hand item (the spirit/save_held_inner idiom: equipment.offhand). Clear any
#         stale prior snapshot first so an empty off hand can't display a previous placer's relic. ---
data remove storage evercraft:decor relic
data modify storage evercraft:decor relic set from entity @s equipment.offhand

# --- (2) Gate: must be a real artifact (carries custom_data.artifact — e.g. "uncommon_anchor"). Empty
#         off hand or a non-relic → empty pedestal + gray hint, then bail (no display summoned). ---
execute unless data storage evercraft:decor relic.components."minecraft:custom_data".artifact run data modify storage evercraft:notify stage.c set value [{text:"Place again with a relic in your off hand to display it.",color:"gray",italic:true}]
execute unless data storage evercraft:decor relic.components."minecraft:custom_data".artifact run scoreboard players set #ndur ec.temp 50
execute unless data storage evercraft:decor relic.components."minecraft:custom_data".artifact run function evercraft:util/notify/emit
execute unless data storage evercraft:decor relic.components."minecraft:custom_data".artifact run return 0

# --- (3) A relic IS in the off hand. Summon ONE item_display centered on the column top (~y 1.15),
#         tagged ec.dec_disp (reaps with the piece) + ec.dec_new (transient UID-stamp). item_display
#         "fixed" + scale ~0.45, translation centers it over the column and floats it above the cap. ---
$summon item_display $(tx) $(ty) $(tz) {Tags:["ec.dec_disp","ec.dec_new"],item:{id:"minecraft:air",count:1},item_display:"fixed",brightness:{sky:15,block:15},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,1.15f,0f],scale:[0.45f,0.45f,0.45f]}}

# --- (4) Set the display's item FROM the snapshot — exact relic NBT, nothing stripped (the off-hand
#         item itself is untouched; this is a copy). count is normalized to 1 (a stacked relic must
#         not display as a pile). ---
# (Select by ec.dec_new tag alone — commit drops its own ec.dec_new BEFORE this bind runs, so the
# just-summoned display is the ONLY carrier this tick; mirrors commit's @e[tag=ec.dec_new] discipline.)
data modify entity @e[tag=ec.dec_new,distance=..16,limit=1] item set from storage evercraft:decor relic
data modify entity @e[tag=ec.dec_new,distance=..16,limit=1] item.count set value 1

# --- (5) Facing (R1 council fix 2026-06-10): stamp the placement yaw — summon never inherits execute
#         rotation, and displays default to billboard "fixed", so entity Rotation IS the facing.
#         Then UID-stamp and drop the transient tag (mirror commit's pattern). Selectors scoped ..16
#         (R2 — the raycast places up to ~13.6 blocks out, so ..8 could miss a far cell). ---
$execute as @e[tag=ec.dec_new,distance=..16] run data modify entity @s Rotation set value [$(face)f,0f]
$scoreboard players set @e[tag=ec.dec_new,distance=..16] ec.dec_uid $(uid)
tag @e[tag=ec.dec_new,distance=..16] remove ec.dec_new

# --- (6) Drop the snapshot (housekeeping — the display owns its own copy now). ---
data remove storage evercraft:decor relic

# --- (7) Notify + a soft chime (note-block per the FX palette; gated on ec.fx_snd). ---
data modify storage evercraft:notify stage.c set value [{text:"Your relic stands displayed.",color:"white"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.chime master @s ~ ~ ~ 0.6 1.4
