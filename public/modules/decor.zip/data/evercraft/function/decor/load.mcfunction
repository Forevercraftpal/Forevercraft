# ============================================================
# FURNISHINGS — Load (scoreboards, constants)
# ============================================================
# Mirrors blueprints/load. Registered in the pack load chain (minecraft load.json).

# --- State scoreboards (SPEC §1) ---
scoreboard objectives add ec.dec_use dummy "Furnishings: Use Flag"
scoreboard objectives add ec.dec_held dummy "Furnishings: Use Edge Latch"
scoreboard objectives add ec.dec_cd dummy "Furnishings: Cooldown"
scoreboard objectives add ec.dec_state dummy "Furnishings: State"
scoreboard objectives add ec.dec_face dummy "Furnishings: Facing"
scoreboard objectives add ec.dec_uid dummy "Furnishings: Owner/Instance UID"
scoreboard objectives add ec.dec_tgtx dummy "Furnishings: Target Cell X"
scoreboard objectives add ec.dec_tgty dummy "Furnishings: Target Cell Y"
scoreboard objectives add ec.dec_tgtz dummy "Furnishings: Target Cell Z"
scoreboard objectives add ec.dec_hx dummy "Furnishings: Half-Step X"
scoreboard objectives add ec.dec_hz dummy "Furnishings: Half-Step Z"
scoreboard objectives add ec.dec_mg dummy "Furnishings: Managing UID"
scoreboard objectives add ec.dec_mg_t dummy "Furnishings: Manage Timeout"
scoreboard objectives add ec.dsp_tgt dummy "Furnishings: Display Hover Target"
# Display hover loop (adaptive 40t/3t; self-rearming — see decor/display/tick)
schedule function evercraft:decor/display/tick 40t replace
# Grand-aquarium fish swim loop (Joseph 2026-06-14; self-rearming, existence-gated — see decor/aquarium/swim)
schedule function evercraft:decor/aquarium/swim 70t replace
# Antique Pristine-infusion aura loop (Phase E; self-rearming, existence-gated to antique_buffed anchors)
schedule function evercraft:decor/antique/buff_tick 80t replace
# Iluminación de Ne candle system (registry + DR-aura objective + aura loop schedule) — Joseph 2026-06-15.
function evercraft:decor/candle/load
scoreboard objectives add ec.dec_cancel_at dummy "Furnishings: Auto-Cancel Countdown"
scoreboard objectives add ec.dec_rc dummy "Furnishings: Raycast Throttle Toggle"

# --- Per-home live furnishing cap (NOT shown as comfort — P1-6) ---
scoreboard objectives add hs.dec_live dummy "Furnishings: Live Count (per home)"

# --- Catalogue GUI: current family page (1=Furniture 2=Lighting 3=Garden 4=Tie-ins) ---
scoreboard objectives add ec.dec_page dummy "Furnishings: Catalogue Page"

# --- UID allocator counter (fake-player register; init guard — P2-1) ---
scoreboard players add #dec_uid ec.var 0

# --- Manage-state reset (2026-06-14 fix): a /reload mid-manage stranded a DEC.Managing tag + a
# DEC.MGAnchor marker, so manage/open then painted at the dead anchor (off in space) — the player
# only heard the open ding, no menu. Clearing manage entities + the tag on every load makes a stale
# /reload self-heal: the next sneak-click summons a FRESH anchor and the GUI paints correctly. ---
kill @e[tag=DEC.MG]
tag @a remove DEC.Managing

# --- Light emission registry (Wave E 2026-06-14): id -> block-light level for LIT decor. ---
# Placed decor is display-entity (emits no world light), so commit drops a tracked
# minecraft:light block at the piece's cell+1 (only into replaceable space) and removal clears
# it. Bright lamps/fire 13-15, soft accents 7-8. Mirrors the artifacts light_step idiom.
data modify storage evercraft:decor light_levels set value {lamppost:14,post_lantern:14,wall_sconce:13,floor_lamp:13,fairy_lights:13,fire_pit:14,brazier:14,fireplace:14,chandelier:13,candelabra:11,dream_lantern:15,vanity_mirror:8,bookshelf_nook:7,display_case_grand:7,aquarium_grand:10}
# Wonky bonsai daily-trim registry (Joseph 2026-06-14): id -> the log given (4/day) when trimmed.
# commit stamps the matching log onto the anchor as data.trim_log; the click router keys off it.
data modify storage evercraft:decor trim_logs set value {bonsai_wonky_oak:"minecraft:oak_log",bonsai_wonky_spruce:"minecraft:spruce_log",bonsai_wonky_birch:"minecraft:birch_log",bonsai_wonky_jungle:"minecraft:jungle_log",bonsai_wonky_acacia:"minecraft:acacia_log",bonsai_wonky_dark_oak:"minecraft:dark_oak_log",bonsai_wonky_mangrove:"minecraft:mangrove_log",bonsai_wonky_cherry:"minecraft:cherry_log",bonsai_wonky_pale_oak:"minecraft:pale_oak_log",bonsai_wonky_crimson:"minecraft:crimson_stem",bonsai_wonky_warped:"minecraft:warped_stem",bonsai_wonky_azalea:"minecraft:oak_log",bonsai_wonky_bone:"minecraft:bone_block",bonsai_wonky_chorus:"minecraft:chorus_fruit"}

# --- Structure decor nodes (Joseph 2026-06-14): glowing furnishing-Idea nodes seeded inside explored
# structures + villages (decor_nodes/struct, a sibling of chest_nodes/struct). Registers its read-only
# constants + the per-node ambient tick schedule. ---
function evercraft:decor_nodes/struct/load
