# Bath Tub — cooldown decrement tick (Joseph 2026-06-13)
# Self-rescheduling 1s tick; goes idle when nothing's on cd.

execute unless entity @a[scores={ec.bath_cd=1..}] run return run schedule function evercraft:decor/bath/cd_tick 60s replace

scoreboard players remove @a[scores={ec.bath_cd=1..}] ec.bath_cd 20

schedule function evercraft:decor/bath/cd_tick 1s replace
