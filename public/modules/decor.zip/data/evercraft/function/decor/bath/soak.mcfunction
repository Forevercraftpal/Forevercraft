# Bath Tub — soak (Joseph 2026-06-13, task #102)
# Run as the clicking player. 5-minute cooldown via ec.bath_cd. Right-click strips
# the muck of the road: clears Poison, Wither, Nausea, Mining Fatigue, Weakness,
# Hunger, Slowness, and Bad Omen, then grants Regeneration I for 60s + a brief
# Water Breathing 8s in case the player nose-dives in.

# Cooldown gate.
data modify storage evercraft:notify stage.c set value [{text:"♨ ",color:"aqua"},{text:"You're already clean.",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 30
execute if score @s ec.bath_cd matches 1.. run return run function evercraft:util/notify/emit

# Strip afflictions.
effect clear @s minecraft:poison
effect clear @s minecraft:wither
effect clear @s minecraft:nausea
effect clear @s minecraft:mining_fatigue
effect clear @s minecraft:weakness
effect clear @s minecraft:hunger
effect clear @s minecraft:slowness
effect clear @s minecraft:bad_omen

# Restore.
function evercraft:decor/antique/read_eff_near {id:"bath_tub",radius:3}
function evercraft:decor/antique/self_buff {effect:"minecraft:regeneration",dur:60,amp:0}
function evercraft:decor/antique/self_buff {effect:"minecraft:water_breathing",dur:8,amp:0}
scoreboard players set @s ec.bath_cd 6000

data modify storage evercraft:notify stage.c set value [{text:"♨ ",color:"aqua"},{text:"A long soak",color:"yellow"},{text:" — your aches and ills wash away.",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 50
function evercraft:util/notify/emit

execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.water.ambient master @s ~ ~ ~ 0.7 0.8
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.player.splash master @s ~ ~ ~ 0.5 1.0
execute at @s run particle minecraft:splash ~ ~0.5 ~ 0.4 0.2 0.4 0.05 16
