# Scarecrow — apply the ward at THIS scarecrow (run as/at the anchor).
# FEAR: shove every hostile mob within 16b outward (repel_mob also zeroes its fall so it can't
# trample on the way out). CROPS: zero fall_distance for players + passive animals within 16b —
# trampling needs a fall, so a cancelled fall can't trample. (Side effect: no fall damage within
# the 16b ward for players — intentional "safe garden" feel; radius/behaviour tunable.)
execute as @e[type=#evercraft:hostile_mobs,distance=..16] at @s run function evercraft:decor/scarecrow/repel_mob
execute as @a[distance=..16] run data modify entity @s fall_distance set value 0.0d
execute as @e[type=#evercraft:passive_mobs,distance=..16] run data modify entity @s fall_distance set value 0.0d
