# Scarecrow — shove THIS hostile mob away from the nearest scarecrow + cancel its fall (run as the
# mob, at it). Faces the scarecrow's feet, zeroes pitch (so the push is purely horizontal — the
# `execute rotated ~ 0` local-coord-pitch fix), then steps the mob 0.4b backward (away). The 3-arg
# tp keeps the mob's own facing. fall_distance is cancelled so it can't trample while in range.
data modify entity @s fall_distance set value 0.0d
execute facing entity @e[type=marker,tag=ec.scarecrow,limit=1,sort=nearest] feet rotated ~ 0 run tp @s ^ ^ ^-0.4
