# Scarecrow — ward tick (Joseph 2026-06-14, task #102)
# 3t self-rescheduling. For each scarecrow with a player within 32b: repel hostile mobs out of a
# 16b radius (the "fear") and cancel falls for living things in 16b so crops can't be trampled
# (trampling requires a fall). Existence-gated to scarecrow anchors (idles at 60s poll otherwise);
# the per-scarecrow work only runs when a player is nearby. PERF: bounded to mobs/players in 16b.
# 3t cadence is frequent enough that fall_distance never accumulates past the trample threshold.
# Lag audit 2026-06-22: the hot 3t scan now selects scarecrows by the ec.scarecrow tag (stamped at
# placement in decor/use/commit) instead of NBT-filtering the whole ec.dec_anchor population every
# 3 ticks. Legacy scarecrows placed before the tag existed are backfilled here on the IDLE path only
# (guarded by `unless entity ec.scarecrow`), so the costly NBT filter never runs on the hot path —
# it fires at most once per 60s poll and self-retires as it tags each piece. (Also backfilled at load.)
execute unless entity @e[type=marker,tag=ec.scarecrow,limit=1] as @e[type=marker,tag=ec.dec_anchor,tag=!ec.scarecrow,nbt={data:{id:"scarecrow"}}] run tag @s add ec.scarecrow
execute unless entity @e[type=marker,tag=ec.scarecrow,limit=1] run return run schedule function evercraft:decor/scarecrow/tick 60s replace
execute as @e[type=marker,tag=ec.scarecrow] at @s if entity @a[distance=..32] run function evercraft:decor/scarecrow/protect
schedule function evercraft:decor/scarecrow/tick 3t replace
