# Scarecrow — ward tick (Joseph 2026-06-14, task #102)
# 3t self-rescheduling. For each scarecrow with a player within 32b: repel hostile mobs out of a
# 16b radius (the "fear") and cancel falls for living things in 16b so crops can't be trampled
# (trampling requires a fall). Existence-gated to scarecrow anchors (idles at 60s poll otherwise);
# the per-scarecrow work only runs when a player is nearby. PERF: bounded to mobs/players in 16b.
# 3t cadence is frequent enough that fall_distance never accumulates past the trample threshold.
execute unless entity @e[type=marker,tag=ec.dec_anchor,nbt={data:{id:"scarecrow"}},limit=1] run return run schedule function evercraft:decor/scarecrow/tick 60s replace
execute as @e[type=marker,tag=ec.dec_anchor,nbt={data:{id:"scarecrow"}}] at @s if entity @a[distance=..32] run function evercraft:decor/scarecrow/protect
schedule function evercraft:decor/scarecrow/tick 3t replace
