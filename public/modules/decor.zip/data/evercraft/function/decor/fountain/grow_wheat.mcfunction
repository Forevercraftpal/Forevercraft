# Fountain — advance wheat one age over the slab (run at the fountain). Descending source
# age so a just-grown crop isn't advanced twice. Radius 16 / height +-1 (33x33x3 = 3,267
# blocks, < the 32768 fill cap). Each fill's change-count accumulates into #fnt_hit so
# grow_tick can ramp its cadence when nothing is growing. Radius is tunable.
execute store result score #fnt_f ec.temp run fill ~-16 ~-1 ~-16 ~16 ~1 ~16 minecraft:wheat[age=7] replace minecraft:wheat[age=6]
scoreboard players operation #fnt_hit ec.temp += #fnt_f ec.temp
execute store result score #fnt_f ec.temp run fill ~-16 ~-1 ~-16 ~16 ~1 ~16 minecraft:wheat[age=6] replace minecraft:wheat[age=5]
scoreboard players operation #fnt_hit ec.temp += #fnt_f ec.temp
execute store result score #fnt_f ec.temp run fill ~-16 ~-1 ~-16 ~16 ~1 ~16 minecraft:wheat[age=5] replace minecraft:wheat[age=4]
scoreboard players operation #fnt_hit ec.temp += #fnt_f ec.temp
execute store result score #fnt_f ec.temp run fill ~-16 ~-1 ~-16 ~16 ~1 ~16 minecraft:wheat[age=4] replace minecraft:wheat[age=3]
scoreboard players operation #fnt_hit ec.temp += #fnt_f ec.temp
execute store result score #fnt_f ec.temp run fill ~-16 ~-1 ~-16 ~16 ~1 ~16 minecraft:wheat[age=3] replace minecraft:wheat[age=2]
scoreboard players operation #fnt_hit ec.temp += #fnt_f ec.temp
execute store result score #fnt_f ec.temp run fill ~-16 ~-1 ~-16 ~16 ~1 ~16 minecraft:wheat[age=2] replace minecraft:wheat[age=1]
scoreboard players operation #fnt_hit ec.temp += #fnt_f ec.temp
execute store result score #fnt_f ec.temp run fill ~-16 ~-1 ~-16 ~16 ~1 ~16 minecraft:wheat[age=1] replace minecraft:wheat[age=0]
scoreboard players operation #fnt_hit ec.temp += #fnt_f ec.temp
