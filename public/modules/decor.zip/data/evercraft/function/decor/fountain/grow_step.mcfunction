# Fountain — advance the current rotating crop family one age over the slab (run at the
# fountain anchor). #fnt_crop: 0 wheat / 1 carrots / 2 potatoes / 3 beetroots / 4 nether
# wart. One family per pass keeps each tick's work bounded.
execute if score #fnt_crop ec.var matches 0 run function evercraft:decor/fountain/grow_wheat
execute if score #fnt_crop ec.var matches 1 run function evercraft:decor/fountain/grow_carrots
execute if score #fnt_crop ec.var matches 2 run function evercraft:decor/fountain/grow_potatoes
execute if score #fnt_crop ec.var matches 3 run function evercraft:decor/fountain/grow_beetroots
execute if score #fnt_crop ec.var matches 4 run function evercraft:decor/fountain/grow_netherwart
