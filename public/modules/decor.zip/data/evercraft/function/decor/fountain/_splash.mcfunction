# Fountain splash burst (run AT the fountain anchor). Water + bubbles + droplets within the bowl.
particle minecraft:splash ~ ~0.5 ~ 0.7 0.4 0.7 0.05 40
particle minecraft:bubble_pop ~ ~0.4 ~ 0.6 0.2 0.6 0.02 20
particle minecraft:falling_water ~ ~1.3 ~ 0.15 0.4 0.15 0.01 12
playsound minecraft:block.water.ambient ambient @a[distance=..18,scores={ec.fx_snd=1..}] ~ ~ ~ 0.6 1.0
playsound minecraft:entity.player.splash ambient @a[distance=..18,scores={ec.fx_snd=1..}] ~ ~ ~ 0.4 1.3
