# Fountain — advance beetroots one age over the slab (run at the fountain). 4 ages (0-3).
# See grow_wheat for the descending-source + #fnt_hit accumulation pattern.
execute store result score #fnt_f ec.temp run fill ~-16 ~-1 ~-16 ~16 ~1 ~16 minecraft:beetroots[age=3] replace minecraft:beetroots[age=2]
scoreboard players operation #fnt_hit ec.temp += #fnt_f ec.temp
execute store result score #fnt_f ec.temp run fill ~-16 ~-1 ~-16 ~16 ~1 ~16 minecraft:beetroots[age=2] replace minecraft:beetroots[age=1]
scoreboard players operation #fnt_hit ec.temp += #fnt_f ec.temp
execute store result score #fnt_f ec.temp run fill ~-16 ~-1 ~-16 ~16 ~1 ~16 minecraft:beetroots[age=1] replace minecraft:beetroots[age=0]
scoreboard players operation #fnt_hit ec.temp += #fnt_f ec.temp
