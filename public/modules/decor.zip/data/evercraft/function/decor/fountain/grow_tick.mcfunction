# Fountain — crop-growth aura tick (Joseph 2026-06-14, task #102; perf retrofit H1 2026-06-14)
# "Increase crop tick speed ~1/8 within 16b." Advances ONE crop family per pass over a
# 33x33x3 slab at the fountain's Y — a bounded native `fill ... replace`, gated to fountains
# with a player within 48b. The grow_* files store each fill's change-count into #fnt_hit.
#
# ADAPTIVE BACKOFF: when a whole pass grows 0 blocks (no immature crops nearby) the tick
# ramps its own cadence out (2s -> 8s -> 30s); the first pass that grows something snaps it
# back to 2s. So an idle fountain costs almost nothing while an active garden grows fast.
# Idles (60s poll) entirely when no fountains exist. #fnt_idle/#fnt_crop = ec.var (persist).
execute unless entity @e[type=marker,tag=ec.dec_anchor,nbt={data:{id:"fountain"}},limit=1] run return run schedule function evercraft:decor/fountain/grow_tick 60s replace
scoreboard players add #fnt_crop ec.var 1
execute if score #fnt_crop ec.var matches 5.. run scoreboard players set #fnt_crop ec.var 0
scoreboard players set #fnt_hit ec.temp 0
execute as @e[type=marker,tag=ec.dec_anchor,nbt={data:{id:"fountain"}}] at @s if entity @a[distance=..48] run function evercraft:decor/fountain/grow_step
# adaptive cadence: track the idle streak, then reschedule at the matching interval.
execute if score #fnt_hit ec.temp matches 1.. run scoreboard players set #fnt_idle ec.var 0
execute if score #fnt_hit ec.temp matches 0 run scoreboard players add #fnt_idle ec.var 1
execute if score #fnt_idle ec.var matches ..3 run return run schedule function evercraft:decor/fountain/grow_tick 2s replace
execute if score #fnt_idle ec.var matches 4..10 run return run schedule function evercraft:decor/fountain/grow_tick 8s replace
scoreboard players set #fnt_idle ec.var 11
schedule function evercraft:decor/fountain/grow_tick 30s replace
