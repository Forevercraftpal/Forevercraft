# Fountain — advance nether wart one age over the slab (run at the fountain). 3 ages (0-2).
# See grow_wheat for the descending-source + #fnt_hit accumulation pattern.
execute store result score #fnt_f ec.temp run fill ~-16 ~-1 ~-16 ~16 ~1 ~16 minecraft:nether_wart[age=2] replace minecraft:nether_wart[age=1]
scoreboard players operation #fnt_hit ec.temp += #fnt_f ec.temp
execute store result score #fnt_f ec.temp run fill ~-16 ~-1 ~-16 ~16 ~1 ~16 minecraft:nether_wart[age=1] replace minecraft:nether_wart[age=0]
scoreboard players operation #fnt_hit ec.temp += #fnt_f ec.temp
