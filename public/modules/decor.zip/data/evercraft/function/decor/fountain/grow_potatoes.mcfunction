# Fountain — advance potatoes one age over the slab (run at the fountain). See grow_wheat.
execute store result score #fnt_f ec.temp run fill ~-16 ~-1 ~-16 ~16 ~1 ~16 minecraft:potatoes[age=7] replace minecraft:potatoes[age=6]
scoreboard players operation #fnt_hit ec.temp += #fnt_f ec.temp
execute store result score #fnt_f ec.temp run fill ~-16 ~-1 ~-16 ~16 ~1 ~16 minecraft:potatoes[age=6] replace minecraft:potatoes[age=5]
scoreboard players operation #fnt_hit ec.temp += #fnt_f ec.temp
execute store result score #fnt_f ec.temp run fill ~-16 ~-1 ~-16 ~16 ~1 ~16 minecraft:potatoes[age=5] replace minecraft:potatoes[age=4]
scoreboard players operation #fnt_hit ec.temp += #fnt_f ec.temp
execute store result score #fnt_f ec.temp run fill ~-16 ~-1 ~-16 ~16 ~1 ~16 minecraft:potatoes[age=4] replace minecraft:potatoes[age=3]
scoreboard players operation #fnt_hit ec.temp += #fnt_f ec.temp
execute store result score #fnt_f ec.temp run fill ~-16 ~-1 ~-16 ~16 ~1 ~16 minecraft:potatoes[age=3] replace minecraft:potatoes[age=2]
scoreboard players operation #fnt_hit ec.temp += #fnt_f ec.temp
execute store result score #fnt_f ec.temp run fill ~-16 ~-1 ~-16 ~16 ~1 ~16 minecraft:potatoes[age=2] replace minecraft:potatoes[age=1]
scoreboard players operation #fnt_hit ec.temp += #fnt_f ec.temp
execute store result score #fnt_f ec.temp run fill ~-16 ~-1 ~-16 ~16 ~1 ~16 minecraft:potatoes[age=1] replace minecraft:potatoes[age=0]
scoreboard players operation #fnt_hit ec.temp += #fnt_f ec.temp
