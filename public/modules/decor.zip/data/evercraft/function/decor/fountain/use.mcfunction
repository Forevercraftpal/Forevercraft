# Fountain — right-click to make it splash (Joseph 2026-06-14). Run as the player; emits the
# water burst AT the clicked fountain (anchor), spread across its 2x2 bowl.
execute at @e[type=marker,tag=ec.dec_anchor,nbt={data:{id:"fountain"}},distance=..3,sort=nearest,limit=1] run function evercraft:decor/fountain/_splash
