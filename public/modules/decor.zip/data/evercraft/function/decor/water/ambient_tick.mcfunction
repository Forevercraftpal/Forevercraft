# Decor water features — ambient sound tick (Joseph 2026-06-14). Self-rescheduling 8s tick,
# existence-gated to fountain/pond/well/fountain anchors. A soft, occasional water murmur near
# each (environmental sound, not a mob vocal — palette-safe). Idles slow when none are placed.
execute unless entity @e[type=marker,tag=ec.dec_anchor,nbt={data:{id:"fountain"}},limit=1] unless entity @e[type=marker,tag=ec.dec_anchor,nbt={data:{id:"pond_kit"}},limit=1] unless entity @e[type=marker,tag=ec.dec_anchor,nbt={data:{id:"stone_well"}},limit=1] run return run schedule function evercraft:decor/water/ambient_tick 30s replace
execute as @e[type=marker,tag=ec.dec_anchor,nbt={data:{id:"fountain"}}] at @s run function evercraft:decor/water/_murmur
execute as @e[type=marker,tag=ec.dec_anchor,nbt={data:{id:"pond_kit"}}] at @s run function evercraft:decor/water/_murmur
execute as @e[type=marker,tag=ec.dec_anchor,nbt={data:{id:"stone_well"}}] at @s run function evercraft:decor/water/_murmur
schedule function evercraft:decor/water/ambient_tick 8s replace
