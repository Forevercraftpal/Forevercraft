# Single water-feature ambient roll (run AT the anchor). 40% chance of a soft water murmur if a
# player is near; a few droplet particles for the fountain/pond surfaces.
execute unless entity @a[distance=..18] run return 0
execute store result score #wm ec.temp run random value 1..100
execute if score #wm ec.temp matches 41.. run return 0
playsound minecraft:block.water.ambient ambient @a[distance=..16,scores={ec.fx_snd=1..}] ~ ~ ~ 0.25 1.0
particle minecraft:splash ~ ~0.5 ~ 0.35 0.15 0.35 0.01 4
