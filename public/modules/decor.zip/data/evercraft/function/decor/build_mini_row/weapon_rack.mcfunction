# === FURNISHINGS — ROW MINI: weapon_rack (catalogue list hologram) ===
# decor/build/weapon_rack bbox-fit to a 0.22m cube for the catalogue row flank.
# Run rotated/positioned by decor/gui/spawn_row (macro pieces get mat from the row).
# Tagged DEC.MenuEl + DEC.PrevMini — reaped on page repaint, View swap and close.

summon block_display ~ ~ ~ {Tags:["DEC.MenuEl","DEC.PrevMini"],block_state:{Name:"minecraft:dark_oak_planks"},brightness:{sky:15,block:15},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[-0.072f,-0.024f,-0.021f],scale:[0.144f,0.144f,0.018f]}}
summon block_display ~ ~ ~ {Tags:["DEC.MenuEl","DEC.PrevMini"],block_state:{Name:"minecraft:stripped_dark_oak_log"},brightness:{sky:15,block:15},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[-0.074f,0.052f,-0.01f],scale:[0.149f,0.015f,0.015f]}}
summon block_display ~ ~ ~ {Tags:["DEC.MenuEl","DEC.PrevMini"],block_state:{Name:"minecraft:stripped_dark_oak_log"},brightness:{sky:15,block:15},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[-0.074f,-0.1f,-0.01f],scale:[0.149f,0.015f,0.015f]}}
summon block_display ~ ~ ~ {Tags:["DEC.MenuEl","DEC.PrevMini"],block_state:{Name:"minecraft:iron_bars"},brightness:{sky:15,block:15},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[-0.049f,-0.017f,-0.007f],scale:[0.012f,0.012f,0.027f]}}
summon block_display ~ ~ ~ {Tags:["DEC.MenuEl","DEC.PrevMini"],block_state:{Name:"minecraft:iron_bars"},brightness:{sky:15,block:15},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0.036f,-0.017f,-0.007f],scale:[0.012f,0.012f,0.027f]}}
