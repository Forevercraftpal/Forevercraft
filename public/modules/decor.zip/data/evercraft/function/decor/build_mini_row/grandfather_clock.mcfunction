# === FURNISHINGS — ROW MINI: grandfather_clock (catalogue list hologram) ===
# decor/build/grandfather_clock bbox-fit to a 0.22m cube for the catalogue row flank.
# Run rotated/positioned by decor/gui/spawn_row (macro pieces get mat from the row).
# Tagged DEC.MenuEl + DEC.PrevMini — reaped on page repaint, View swap and close.

summon block_display ~ ~ ~ {Tags:["DEC.MenuEl","DEC.PrevMini"],block_state:{Name:"minecraft:dark_oak_planks"},brightness:{sky:15,block:15},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[-0.028f,-0.1f,-0.028f],scale:[0.056f,0.03f,0.04f]}}
summon block_display ~ ~ ~ {Tags:["DEC.MenuEl","DEC.PrevMini"],block_state:{Name:"minecraft:dark_oak_planks"},brightness:{sky:15,block:15},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[-0.023f,-0.07f,-0.024f],scale:[0.045f,0.131f,0.032f]}}
summon block_display ~ ~ ~ {Tags:["DEC.MenuEl","DEC.PrevMini"],block_state:{Name:"minecraft:dark_oak_planks"},brightness:{sky:15,block:15},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[-0.028f,0.061f,-0.028f],scale:[0.056f,0.051f,0.04f]}}
summon block_display ~ ~ ~ {Tags:["DEC.MenuEl","DEC.PrevMini"],block_state:{Name:"minecraft:dark_oak_planks"},brightness:{sky:15,block:15},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[-0.03f,0.112f,-0.03f],scale:[0.061f,0.008f,0.045f]}}
summon block_display ~ ~ ~ {Tags:["DEC.MenuEl","DEC.PrevMini"],block_state:{Name:"minecraft:gold_block"},brightness:{sky:15,block:15},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[-0.005f,-0.044f,0.008f],scale:[0.01f,0.051f,0.003f]}}
summon item_display ~ ~ ~ {Tags:["DEC.MenuEl","DEC.PrevMini"],item:{id:"minecraft:clock",count:1},item_display:"fixed",brightness:{sky:15,block:15},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[-0.016f,0.074f,-0.002f],scale:[0.032f,0.032f,0.032f]}}
