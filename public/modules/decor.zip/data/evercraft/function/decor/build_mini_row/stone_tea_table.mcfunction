# === FURNISHINGS — ROW MINI: stone_tea_table (catalogue list hologram) ===
# decor/build/stone_tea_table bbox-fit to a 0.22m cube for the catalogue row flank.
# Run rotated/positioned by decor/gui/spawn_row (macro pieces get mat from the row).
# Tagged DEC.MenuEl + DEC.PrevMini — reaped on page repaint, View swap and close.

$summon block_display ~ ~ ~ {Tags:["DEC.MenuEl","DEC.PrevMini"],block_state:{Name:"minecraft:$(mat)"},brightness:{sky:15,block:15},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[-0.11f,-0.028f,-0.11f],scale:[0.22f,0.019f,0.22f]}}
$summon block_display ~ ~ ~ {Tags:["DEC.MenuEl","DEC.PrevMini"],block_state:{Name:"minecraft:$(mat)"},brightness:{sky:15,block:15},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[-0.098f,-0.1f,-0.098f],scale:[0.034f,0.072f,0.034f]}}
$summon block_display ~ ~ ~ {Tags:["DEC.MenuEl","DEC.PrevMini"],block_state:{Name:"minecraft:$(mat)"},brightness:{sky:15,block:15},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0.065f,-0.1f,-0.098f],scale:[0.034f,0.072f,0.034f]}}
$summon block_display ~ ~ ~ {Tags:["DEC.MenuEl","DEC.PrevMini"],block_state:{Name:"minecraft:$(mat)"},brightness:{sky:15,block:15},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[-0.098f,-0.1f,0.065f],scale:[0.034f,0.072f,0.034f]}}
$summon block_display ~ ~ ~ {Tags:["DEC.MenuEl","DEC.PrevMini"],block_state:{Name:"minecraft:$(mat)"},brightness:{sky:15,block:15},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0.065f,-0.1f,0.065f],scale:[0.034f,0.072f,0.034f]}}
summon block_display ~ ~ ~ {Tags:["DEC.MenuEl","DEC.PrevMini"],block_state:{Name:"minecraft:decorated_pot"},brightness:{sky:15,block:15},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[-0.067f,-0.009f,-0.038f],scale:[0.076f,0.076f,0.076f]}}
summon block_display ~ ~ ~ {Tags:["DEC.MenuEl","DEC.PrevMini"],block_state:{Name:"minecraft:quartz_block"},brightness:{sky:15,block:15},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0.045f,-0.009f,0.036f],scale:[0.024f,0.024f,0.024f]}}
summon block_display ~ ~ ~ {Tags:["DEC.MenuEl","DEC.PrevMini"],block_state:{Name:"minecraft:quartz_block"},brightness:{sky:15,block:15},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0.05f,-0.009f,-0.055f],scale:[0.024f,0.024f,0.024f]}}
summon item_display ~ ~ ~ {Tags:["DEC.MenuEl","DEC.PrevMini"],item:{id:"minecraft:cookie",count:1},item_display:"fixed",brightness:{sky:15,block:15},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[-0.026f,-0.004f,0.045f],scale:[0.053f,0.053f,0.053f]}}
