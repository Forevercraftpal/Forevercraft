# === FURNISHINGS — ROW MINI: stone_kitchen_counter (catalogue list hologram) ===
# decor/build/stone_kitchen_counter bbox-fit to a 0.22m cube for the catalogue row flank.
# Run rotated/positioned by decor/gui/spawn_row (macro pieces get mat from the row).
# Tagged DEC.MenuEl + DEC.PrevMini — reaped on page repaint, View swap and close.

$summon block_display ~ ~ ~ {Tags:["DEC.MenuEl","DEC.PrevMini"],block_state:{Name:"minecraft:$(mat)"},brightness:{sky:15,block:15},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[-0.095f,-0.1f,-0.095f],scale:[0.189f,0.205f,0.189f]}}
$summon block_display ~ ~ ~ {Tags:["DEC.MenuEl","DEC.PrevMini"],block_state:{Name:"minecraft:$(mat)"},brightness:{sky:15,block:15},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[-0.107f,0.098f,-0.107f],scale:[0.213f,0.022f,0.213f]}}
summon block_display ~ ~ ~ {Tags:["DEC.MenuEl","DEC.PrevMini"],block_state:{Name:"minecraft:gold_block"},brightness:{sky:15,block:15},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[-0.013f,0.001f,0.093f],scale:[0.026f,0.011f,0.011f]}}
