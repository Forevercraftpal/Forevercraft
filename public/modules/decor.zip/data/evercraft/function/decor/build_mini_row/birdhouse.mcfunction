# === FURNISHINGS — ROW MINI: birdhouse (catalogue list hologram) ===
# decor/build/birdhouse bbox-fit to a 0.22m cube for the catalogue row flank.
# Run rotated/positioned by decor/gui/spawn_row (macro pieces get mat from the row).
# Tagged DEC.MenuEl + DEC.PrevMini — reaped on page repaint, View swap and close.

$summon block_display ~ ~ ~ {Tags:["DEC.MenuEl","DEC.PrevMini"],block_state:{Name:"minecraft:$(mat)_planks"},brightness:{sky:15,block:15},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[-0.016f,-0.1f,-0.022f],scale:[0.033f,0.013f,0.033f]}}
$summon block_display ~ ~ ~ {Tags:["DEC.MenuEl","DEC.PrevMini"],block_state:{Name:"minecraft:$(mat)_planks"},brightness:{sky:15,block:15},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[-0.009f,-0.087f,-0.015f],scale:[0.018f,0.151f,0.018f]}}
$summon block_display ~ ~ ~ {Tags:["DEC.MenuEl","DEC.PrevMini"],block_state:{Name:"minecraft:$(mat)_planks"},brightness:{sky:15,block:15},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[-0.031f,0.057f,-0.035f],scale:[0.063f,0.063f,0.063f]}}
summon block_display ~ ~ ~ {Tags:["DEC.MenuEl","DEC.PrevMini"],block_state:{Name:"minecraft:polished_blackstone"},brightness:{sky:15,block:15},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[-0.01f,0.061f,0.025f],scale:[0.02f,0.02f,0.007f]}}
summon block_display ~ ~ ~ {Tags:["DEC.MenuEl","DEC.PrevMini"],block_state:{Name:"minecraft:dark_oak_planks"},brightness:{sky:15,block:15},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[-0.039f,0.091f,-0.042f],scale:[0.078f,0.013f,0.078f]}}
summon block_display ~ ~ ~ {Tags:["DEC.MenuEl","DEC.PrevMini"],block_state:{Name:"minecraft:dark_oak_planks"},brightness:{sky:15,block:15},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[-0.024f,0.101f,-0.027f],scale:[0.048f,0.013f,0.048f]}}
summon block_display ~ ~ ~ {Tags:["DEC.MenuEl","DEC.PrevMini"],block_state:{Name:"minecraft:stripped_oak_log"},brightness:{sky:15,block:15},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[-0.003f,0.048f,0.022f],scale:[0.006f,0.006f,0.02f]}}
