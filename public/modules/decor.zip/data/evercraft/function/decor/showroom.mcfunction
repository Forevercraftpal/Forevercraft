# === DECOR SHOWROOM (debug) ===
# Run as operator. Summons every decor build in a labeled grid in FRONT of you
# (stand in a big flat open area). For spotting z-fighting / clipping.
# Clear with:  kill @e[tag=ec.showroom]

execute rotated ~ 0 positioned ^18.0 ^ ^4.0 run function evercraft:decor/build/alchemy_shelf
execute rotated ~ 0 positioned ^18.0 ^ ^4.0 run summon text_display ~ ~3.0 ~ {Tags:["ec.showroom"],billboard:"center",brightness:{block:15,sky:15},shadow_radius:0f,text:[{text:"alchemy_shelf",color:"yellow"}]}
execute rotated ~ 0 positioned ^14.0 ^ ^4.0 run function evercraft:decor/build/aquarium {mat:"dark_oak_planks"}
execute rotated ~ 0 positioned ^14.0 ^ ^4.0 run summon text_display ~ ~3.0 ~ {Tags:["ec.showroom"],billboard:"center",brightness:{block:15,sky:15},shadow_radius:0f,text:[{text:"aquarium",color:"yellow"}]}
execute rotated ~ 0 positioned ^10.0 ^ ^4.0 run function evercraft:decor/build/armchair {mat:"red"}
execute rotated ~ 0 positioned ^10.0 ^ ^4.0 run summon text_display ~ ~3.0 ~ {Tags:["ec.showroom"],billboard:"center",brightness:{block:15,sky:15},shadow_radius:0f,text:[{text:"armchair",color:"yellow"}]}
execute rotated ~ 0 positioned ^6.0 ^ ^4.0 run function evercraft:decor/build/barrel_stack
execute rotated ~ 0 positioned ^6.0 ^ ^4.0 run summon text_display ~ ~3.0 ~ {Tags:["ec.showroom"],billboard:"center",brightness:{block:15,sky:15},shadow_radius:0f,text:[{text:"barrel_stack",color:"yellow"}]}
execute rotated ~ 0 positioned ^2.0 ^ ^4.0 run function evercraft:decor/build/bath_tub
execute rotated ~ 0 positioned ^2.0 ^ ^4.0 run summon text_display ~ ~3.0 ~ {Tags:["ec.showroom"],billboard:"center",brightness:{block:15,sky:15},shadow_radius:0f,text:[{text:"bath_tub",color:"yellow"}]}
execute rotated ~ 0 positioned ^-2.0 ^ ^4.0 run function evercraft:decor/build/bee_hotel
execute rotated ~ 0 positioned ^-2.0 ^ ^4.0 run summon text_display ~ ~3.0 ~ {Tags:["ec.showroom"],billboard:"center",brightness:{block:15,sky:15},shadow_radius:0f,text:[{text:"bee_hotel",color:"yellow"}]}
execute rotated ~ 0 positioned ^-6.0 ^ ^4.0 run function evercraft:decor/build/bird_bath
execute rotated ~ 0 positioned ^-6.0 ^ ^4.0 run summon text_display ~ ~3.0 ~ {Tags:["ec.showroom"],billboard:"center",brightness:{block:15,sky:15},shadow_radius:0f,text:[{text:"bird_bath",color:"yellow"}]}
execute rotated ~ 0 positioned ^-10.0 ^ ^4.0 run function evercraft:decor/build/birdhouse {mat:"oak"}
execute rotated ~ 0 positioned ^-10.0 ^ ^4.0 run summon text_display ~ ~3.0 ~ {Tags:["ec.showroom"],billboard:"center",brightness:{block:15,sky:15},shadow_radius:0f,text:[{text:"birdhouse",color:"yellow"}]}
execute rotated ~ 0 positioned ^-14.0 ^ ^4.0 run function evercraft:decor/build/bonsai_acacia
execute rotated ~ 0 positioned ^-14.0 ^ ^4.0 run summon text_display ~ ~3.0 ~ {Tags:["ec.showroom"],billboard:"center",brightness:{block:15,sky:15},shadow_radius:0f,text:[{text:"bonsai_acacia",color:"yellow"}]}
execute rotated ~ 0 positioned ^-18.0 ^ ^4.0 run function evercraft:decor/build/bonsai_azalea
execute rotated ~ 0 positioned ^-18.0 ^ ^4.0 run summon text_display ~ ~3.0 ~ {Tags:["ec.showroom"],billboard:"center",brightness:{block:15,sky:15},shadow_radius:0f,text:[{text:"bonsai_azalea",color:"yellow"}]}
execute rotated ~ 0 positioned ^18.0 ^ ^8.5 run function evercraft:decor/build/bonsai_birch
execute rotated ~ 0 positioned ^18.0 ^ ^8.5 run summon text_display ~ ~3.0 ~ {Tags:["ec.showroom"],billboard:"center",brightness:{block:15,sky:15},shadow_radius:0f,text:[{text:"bonsai_birch",color:"yellow"}]}
execute rotated ~ 0 positioned ^14.0 ^ ^8.5 run function evercraft:decor/build/bonsai_bone
execute rotated ~ 0 positioned ^14.0 ^ ^8.5 run summon text_display ~ ~3.0 ~ {Tags:["ec.showroom"],billboard:"center",brightness:{block:15,sky:15},shadow_radius:0f,text:[{text:"bonsai_bone",color:"yellow"}]}
execute rotated ~ 0 positioned ^10.0 ^ ^8.5 run function evercraft:decor/build/bonsai_cherry
execute rotated ~ 0 positioned ^10.0 ^ ^8.5 run summon text_display ~ ~3.0 ~ {Tags:["ec.showroom"],billboard:"center",brightness:{block:15,sky:15},shadow_radius:0f,text:[{text:"bonsai_cherry",color:"yellow"}]}
execute rotated ~ 0 positioned ^6.0 ^ ^8.5 run function evercraft:decor/build/bonsai_chorus
execute rotated ~ 0 positioned ^6.0 ^ ^8.5 run summon text_display ~ ~3.0 ~ {Tags:["ec.showroom"],billboard:"center",brightness:{block:15,sky:15},shadow_radius:0f,text:[{text:"bonsai_chorus",color:"yellow"}]}
execute rotated ~ 0 positioned ^2.0 ^ ^8.5 run function evercraft:decor/build/bonsai_crimson
execute rotated ~ 0 positioned ^2.0 ^ ^8.5 run summon text_display ~ ~3.0 ~ {Tags:["ec.showroom"],billboard:"center",brightness:{block:15,sky:15},shadow_radius:0f,text:[{text:"bonsai_crimson",color:"yellow"}]}
execute rotated ~ 0 positioned ^-2.0 ^ ^8.5 run function evercraft:decor/build/bonsai_dark_oak
execute rotated ~ 0 positioned ^-2.0 ^ ^8.5 run summon text_display ~ ~3.0 ~ {Tags:["ec.showroom"],billboard:"center",brightness:{block:15,sky:15},shadow_radius:0f,text:[{text:"bonsai_dark_oak",color:"yellow"}]}
execute rotated ~ 0 positioned ^-6.0 ^ ^8.5 run function evercraft:decor/build/bonsai_jungle
execute rotated ~ 0 positioned ^-6.0 ^ ^8.5 run summon text_display ~ ~3.0 ~ {Tags:["ec.showroom"],billboard:"center",brightness:{block:15,sky:15},shadow_radius:0f,text:[{text:"bonsai_jungle",color:"yellow"}]}
execute rotated ~ 0 positioned ^-10.0 ^ ^8.5 run function evercraft:decor/build/bonsai_mangrove
execute rotated ~ 0 positioned ^-10.0 ^ ^8.5 run summon text_display ~ ~3.0 ~ {Tags:["ec.showroom"],billboard:"center",brightness:{block:15,sky:15},shadow_radius:0f,text:[{text:"bonsai_mangrove",color:"yellow"}]}
execute rotated ~ 0 positioned ^-14.0 ^ ^8.5 run function evercraft:decor/build/bonsai_oak
execute rotated ~ 0 positioned ^-14.0 ^ ^8.5 run summon text_display ~ ~3.0 ~ {Tags:["ec.showroom"],billboard:"center",brightness:{block:15,sky:15},shadow_radius:0f,text:[{text:"bonsai_oak",color:"yellow"}]}
execute rotated ~ 0 positioned ^-18.0 ^ ^8.5 run function evercraft:decor/build/bonsai_pale_oak
execute rotated ~ 0 positioned ^-18.0 ^ ^8.5 run summon text_display ~ ~3.0 ~ {Tags:["ec.showroom"],billboard:"center",brightness:{block:15,sky:15},shadow_radius:0f,text:[{text:"bonsai_pale_oak",color:"yellow"}]}
execute rotated ~ 0 positioned ^18.0 ^ ^13.0 run function evercraft:decor/build/bonsai_spruce
execute rotated ~ 0 positioned ^18.0 ^ ^13.0 run summon text_display ~ ~3.0 ~ {Tags:["ec.showroom"],billboard:"center",brightness:{block:15,sky:15},shadow_radius:0f,text:[{text:"bonsai_spruce",color:"yellow"}]}
execute rotated ~ 0 positioned ^14.0 ^ ^13.0 run function evercraft:decor/build/bonsai_warped
execute rotated ~ 0 positioned ^14.0 ^ ^13.0 run summon text_display ~ ~3.0 ~ {Tags:["ec.showroom"],billboard:"center",brightness:{block:15,sky:15},shadow_radius:0f,text:[{text:"bonsai_warped",color:"yellow"}]}
execute rotated ~ 0 positioned ^10.0 ^ ^13.0 run function evercraft:decor/build/bonsai_wonky_acacia
execute rotated ~ 0 positioned ^10.0 ^ ^13.0 run summon text_display ~ ~3.0 ~ {Tags:["ec.showroom"],billboard:"center",brightness:{block:15,sky:15},shadow_radius:0f,text:[{text:"bonsai_wonky_acacia",color:"yellow"}]}
execute rotated ~ 0 positioned ^6.0 ^ ^13.0 run function evercraft:decor/build/bonsai_wonky_azalea
execute rotated ~ 0 positioned ^6.0 ^ ^13.0 run summon text_display ~ ~3.0 ~ {Tags:["ec.showroom"],billboard:"center",brightness:{block:15,sky:15},shadow_radius:0f,text:[{text:"bonsai_wonky_azalea",color:"yellow"}]}
execute rotated ~ 0 positioned ^2.0 ^ ^13.0 run function evercraft:decor/build/bonsai_wonky_birch
execute rotated ~ 0 positioned ^2.0 ^ ^13.0 run summon text_display ~ ~3.0 ~ {Tags:["ec.showroom"],billboard:"center",brightness:{block:15,sky:15},shadow_radius:0f,text:[{text:"bonsai_wonky_birch",color:"yellow"}]}
execute rotated ~ 0 positioned ^-2.0 ^ ^13.0 run function evercraft:decor/build/bonsai_wonky_bone
execute rotated ~ 0 positioned ^-2.0 ^ ^13.0 run summon text_display ~ ~3.0 ~ {Tags:["ec.showroom"],billboard:"center",brightness:{block:15,sky:15},shadow_radius:0f,text:[{text:"bonsai_wonky_bone",color:"yellow"}]}
execute rotated ~ 0 positioned ^-6.0 ^ ^13.0 run function evercraft:decor/build/bonsai_wonky_cherry
execute rotated ~ 0 positioned ^-6.0 ^ ^13.0 run summon text_display ~ ~3.0 ~ {Tags:["ec.showroom"],billboard:"center",brightness:{block:15,sky:15},shadow_radius:0f,text:[{text:"bonsai_wonky_cherry",color:"yellow"}]}
execute rotated ~ 0 positioned ^-10.0 ^ ^13.0 run function evercraft:decor/build/bonsai_wonky_chorus
execute rotated ~ 0 positioned ^-10.0 ^ ^13.0 run summon text_display ~ ~3.0 ~ {Tags:["ec.showroom"],billboard:"center",brightness:{block:15,sky:15},shadow_radius:0f,text:[{text:"bonsai_wonky_chorus",color:"yellow"}]}
execute rotated ~ 0 positioned ^-14.0 ^ ^13.0 run function evercraft:decor/build/bonsai_wonky_crimson
execute rotated ~ 0 positioned ^-14.0 ^ ^13.0 run summon text_display ~ ~3.0 ~ {Tags:["ec.showroom"],billboard:"center",brightness:{block:15,sky:15},shadow_radius:0f,text:[{text:"bonsai_wonky_crimson",color:"yellow"}]}
execute rotated ~ 0 positioned ^-18.0 ^ ^13.0 run function evercraft:decor/build/bonsai_wonky_dark_oak
execute rotated ~ 0 positioned ^-18.0 ^ ^13.0 run summon text_display ~ ~3.0 ~ {Tags:["ec.showroom"],billboard:"center",brightness:{block:15,sky:15},shadow_radius:0f,text:[{text:"bonsai_wonky_dark_oak",color:"yellow"}]}
execute rotated ~ 0 positioned ^18.0 ^ ^17.5 run function evercraft:decor/build/bonsai_wonky_jungle
execute rotated ~ 0 positioned ^18.0 ^ ^17.5 run summon text_display ~ ~3.0 ~ {Tags:["ec.showroom"],billboard:"center",brightness:{block:15,sky:15},shadow_radius:0f,text:[{text:"bonsai_wonky_jungle",color:"yellow"}]}
execute rotated ~ 0 positioned ^14.0 ^ ^17.5 run function evercraft:decor/build/bonsai_wonky_mangrove
execute rotated ~ 0 positioned ^14.0 ^ ^17.5 run summon text_display ~ ~3.0 ~ {Tags:["ec.showroom"],billboard:"center",brightness:{block:15,sky:15},shadow_radius:0f,text:[{text:"bonsai_wonky_mangrove",color:"yellow"}]}
execute rotated ~ 0 positioned ^10.0 ^ ^17.5 run function evercraft:decor/build/bonsai_wonky_oak
execute rotated ~ 0 positioned ^10.0 ^ ^17.5 run summon text_display ~ ~3.0 ~ {Tags:["ec.showroom"],billboard:"center",brightness:{block:15,sky:15},shadow_radius:0f,text:[{text:"bonsai_wonky_oak",color:"yellow"}]}
execute rotated ~ 0 positioned ^6.0 ^ ^17.5 run function evercraft:decor/build/bonsai_wonky_pale_oak
execute rotated ~ 0 positioned ^6.0 ^ ^17.5 run summon text_display ~ ~3.0 ~ {Tags:["ec.showroom"],billboard:"center",brightness:{block:15,sky:15},shadow_radius:0f,text:[{text:"bonsai_wonky_pale_oak",color:"yellow"}]}
execute rotated ~ 0 positioned ^2.0 ^ ^17.5 run function evercraft:decor/build/bonsai_wonky_spruce
execute rotated ~ 0 positioned ^2.0 ^ ^17.5 run summon text_display ~ ~3.0 ~ {Tags:["ec.showroom"],billboard:"center",brightness:{block:15,sky:15},shadow_radius:0f,text:[{text:"bonsai_wonky_spruce",color:"yellow"}]}
execute rotated ~ 0 positioned ^-2.0 ^ ^17.5 run function evercraft:decor/build/bonsai_wonky_warped
execute rotated ~ 0 positioned ^-2.0 ^ ^17.5 run summon text_display ~ ~3.0 ~ {Tags:["ec.showroom"],billboard:"center",brightness:{block:15,sky:15},shadow_radius:0f,text:[{text:"bonsai_wonky_warped",color:"yellow"}]}
execute rotated ~ 0 positioned ^-6.0 ^ ^17.5 run function evercraft:decor/build/bookshelf_nook {mat:"oak"}
execute rotated ~ 0 positioned ^-6.0 ^ ^17.5 run summon text_display ~ ~3.0 ~ {Tags:["ec.showroom"],billboard:"center",brightness:{block:15,sky:15},shadow_radius:0f,text:[{text:"bookshelf_nook",color:"yellow"}]}
execute rotated ~ 0 positioned ^-10.0 ^ ^17.5 run function evercraft:decor/build/brazier
execute rotated ~ 0 positioned ^-10.0 ^ ^17.5 run summon text_display ~ ~3.0 ~ {Tags:["ec.showroom"],billboard:"center",brightness:{block:15,sky:15},shadow_radius:0f,text:[{text:"brazier",color:"yellow"}]}
execute rotated ~ 0 positioned ^-14.0 ^ ^17.5 run function evercraft:decor/build/candelabra {mat:"gold"}
execute rotated ~ 0 positioned ^-14.0 ^ ^17.5 run summon text_display ~ ~3.0 ~ {Tags:["ec.showroom"],billboard:"center",brightness:{block:15,sky:15},shadow_radius:0f,text:[{text:"candelabra",color:"yellow"}]}
execute rotated ~ 0 positioned ^-18.0 ^ ^17.5 run function evercraft:decor/build/chair {mat:"oak"}
execute rotated ~ 0 positioned ^-18.0 ^ ^17.5 run summon text_display ~ ~3.0 ~ {Tags:["ec.showroom"],billboard:"center",brightness:{block:15,sky:15},shadow_radius:0f,text:[{text:"chair",color:"yellow"}]}
execute rotated ~ 0 positioned ^18.0 ^ ^22.0 run function evercraft:decor/build/chandelier
execute rotated ~ 0 positioned ^18.0 ^ ^22.0 run summon text_display ~ ~3.0 ~ {Tags:["ec.showroom"],billboard:"center",brightness:{block:15,sky:15},shadow_radius:0f,text:[{text:"chandelier",color:"yellow"}]}
execute rotated ~ 0 positioned ^14.0 ^ ^22.0 run function evercraft:decor/build/coat_rack {mat:"oak"}
execute rotated ~ 0 positioned ^14.0 ^ ^22.0 run summon text_display ~ ~3.0 ~ {Tags:["ec.showroom"],billboard:"center",brightness:{block:15,sky:15},shadow_radius:0f,text:[{text:"coat_rack",color:"yellow"}]}
execute rotated ~ 0 positioned ^10.0 ^ ^22.0 run function evercraft:decor/build/companion_bed {mat:"red"}
execute rotated ~ 0 positioned ^10.0 ^ ^22.0 run summon text_display ~ ~3.0 ~ {Tags:["ec.showroom"],billboard:"center",brightness:{block:15,sky:15},shadow_radius:0f,text:[{text:"companion_bed",color:"yellow"}]}
execute rotated ~ 0 positioned ^6.0 ^ ^22.0 run function evercraft:decor/build/cushion_pile {mat:"white"}
execute rotated ~ 0 positioned ^6.0 ^ ^22.0 run summon text_display ~ ~3.0 ~ {Tags:["ec.showroom"],billboard:"center",brightness:{block:15,sky:15},shadow_radius:0f,text:[{text:"cushion_pile",color:"yellow"}]}
execute rotated ~ 0 positioned ^2.0 ^ ^22.0 run function evercraft:decor/build/dining_table {mat:"oak"}
execute rotated ~ 0 positioned ^2.0 ^ ^22.0 run summon text_display ~ ~3.0 ~ {Tags:["ec.showroom"],billboard:"center",brightness:{block:15,sky:15},shadow_radius:0f,text:[{text:"dining_table",color:"yellow"}]}
execute rotated ~ 0 positioned ^-2.0 ^ ^22.0 run function evercraft:decor/build/display_case {mat:"quartz_block"}
execute rotated ~ 0 positioned ^-2.0 ^ ^22.0 run summon text_display ~ ~3.0 ~ {Tags:["ec.showroom"],billboard:"center",brightness:{block:15,sky:15},shadow_radius:0f,text:[{text:"display_case",color:"yellow"}]}
execute rotated ~ 0 positioned ^-6.0 ^ ^22.0 run function evercraft:decor/build/display_case_grand {mat:"dark_oak_planks"}
execute rotated ~ 0 positioned ^-6.0 ^ ^22.0 run summon text_display ~ ~3.0 ~ {Tags:["ec.showroom"],billboard:"center",brightness:{block:15,sky:15},shadow_radius:0f,text:[{text:"display_case_grand",color:"yellow"}]}
execute rotated ~ 0 positioned ^-10.0 ^ ^22.0 run function evercraft:decor/build/display_stand {mat:"oak"}
execute rotated ~ 0 positioned ^-10.0 ^ ^22.0 run summon text_display ~ ~3.0 ~ {Tags:["ec.showroom"],billboard:"center",brightness:{block:15,sky:15},shadow_radius:0f,text:[{text:"display_stand",color:"yellow"}]}
execute rotated ~ 0 positioned ^-14.0 ^ ^22.0 run function evercraft:decor/build/dream_lantern
execute rotated ~ 0 positioned ^-14.0 ^ ^22.0 run summon text_display ~ ~3.0 ~ {Tags:["ec.showroom"],billboard:"center",brightness:{block:15,sky:15},shadow_radius:0f,text:[{text:"dream_lantern",color:"yellow"}]}
execute rotated ~ 0 positioned ^-18.0 ^ ^22.0 run function evercraft:decor/build/easel
execute rotated ~ 0 positioned ^-18.0 ^ ^22.0 run summon text_display ~ ~3.0 ~ {Tags:["ec.showroom"],billboard:"center",brightness:{block:15,sky:15},shadow_radius:0f,text:[{text:"easel",color:"yellow"}]}
execute rotated ~ 0 positioned ^18.0 ^ ^26.5 run function evercraft:decor/build/fairy_lights
execute rotated ~ 0 positioned ^18.0 ^ ^26.5 run summon text_display ~ ~3.0 ~ {Tags:["ec.showroom"],billboard:"center",brightness:{block:15,sky:15},shadow_radius:0f,text:[{text:"fairy_lights",color:"yellow"}]}
execute rotated ~ 0 positioned ^14.0 ^ ^26.5 run function evercraft:decor/build/fire_pit
execute rotated ~ 0 positioned ^14.0 ^ ^26.5 run summon text_display ~ ~3.0 ~ {Tags:["ec.showroom"],billboard:"center",brightness:{block:15,sky:15},shadow_radius:0f,text:[{text:"fire_pit",color:"yellow"}]}
execute rotated ~ 0 positioned ^10.0 ^ ^26.5 run function evercraft:decor/build/fireplace {mat:"bricks"}
execute rotated ~ 0 positioned ^10.0 ^ ^26.5 run summon text_display ~ ~3.0 ~ {Tags:["ec.showroom"],billboard:"center",brightness:{block:15,sky:15},shadow_radius:0f,text:[{text:"fireplace",color:"yellow"}]}
execute rotated ~ 0 positioned ^6.0 ^ ^26.5 run function evercraft:decor/build/floor_lamp {mat:"white"}
execute rotated ~ 0 positioned ^6.0 ^ ^26.5 run summon text_display ~ ~3.0 ~ {Tags:["ec.showroom"],billboard:"center",brightness:{block:15,sky:15},shadow_radius:0f,text:[{text:"floor_lamp",color:"yellow"}]}
execute rotated ~ 0 positioned ^2.0 ^ ^26.5 run function evercraft:decor/build/flower_planter {mat:"red_tulip"}
execute rotated ~ 0 positioned ^2.0 ^ ^26.5 run summon text_display ~ ~3.0 ~ {Tags:["ec.showroom"],billboard:"center",brightness:{block:15,sky:15},shadow_radius:0f,text:[{text:"flower_planter",color:"yellow"}]}
execute rotated ~ 0 positioned ^-2.0 ^ ^26.5 run function evercraft:decor/build/fountain
execute rotated ~ 0 positioned ^-2.0 ^ ^26.5 run summon text_display ~ ~3.0 ~ {Tags:["ec.showroom"],billboard:"center",brightness:{block:15,sky:15},shadow_radius:0f,text:[{text:"fountain",color:"yellow"}]}
execute rotated ~ 0 positioned ^-6.0 ^ ^26.5 run function evercraft:decor/build/four_poster_bed {mat:"red"}
execute rotated ~ 0 positioned ^-6.0 ^ ^26.5 run summon text_display ~ ~3.0 ~ {Tags:["ec.showroom"],billboard:"center",brightness:{block:15,sky:15},shadow_radius:0f,text:[{text:"four_poster_bed",color:"yellow"}]}
execute rotated ~ 0 positioned ^-10.0 ^ ^26.5 run function evercraft:decor/build/garden_bench {mat:"oak"}
execute rotated ~ 0 positioned ^-10.0 ^ ^26.5 run summon text_display ~ ~3.0 ~ {Tags:["ec.showroom"],billboard:"center",brightness:{block:15,sky:15},shadow_radius:0f,text:[{text:"garden_bench",color:"yellow"}]}
execute rotated ~ 0 positioned ^-14.0 ^ ^26.5 run function evercraft:decor/build/garden_swing {mat:"oak"}
execute rotated ~ 0 positioned ^-14.0 ^ ^26.5 run summon text_display ~ ~3.0 ~ {Tags:["ec.showroom"],billboard:"center",brightness:{block:15,sky:15},shadow_radius:0f,text:[{text:"garden_swing",color:"yellow"}]}
execute rotated ~ 0 positioned ^-18.0 ^ ^26.5 run function evercraft:decor/build/grandfather_clock
execute rotated ~ 0 positioned ^-18.0 ^ ^26.5 run summon text_display ~ ~3.0 ~ {Tags:["ec.showroom"],billboard:"center",brightness:{block:15,sky:15},shadow_radius:0f,text:[{text:"grandfather_clock",color:"yellow"}]}
execute rotated ~ 0 positioned ^18.0 ^ ^31.0 run function evercraft:decor/build/hammock {mat:"red"}
execute rotated ~ 0 positioned ^18.0 ^ ^31.0 run summon text_display ~ ~3.0 ~ {Tags:["ec.showroom"],billboard:"center",brightness:{block:15,sky:15},shadow_radius:0f,text:[{text:"hammock",color:"yellow"}]}
execute rotated ~ 0 positioned ^14.0 ^ ^31.0 run function evercraft:decor/build/kitchen_counter
execute rotated ~ 0 positioned ^14.0 ^ ^31.0 run summon text_display ~ ~3.0 ~ {Tags:["ec.showroom"],billboard:"center",brightness:{block:15,sky:15},shadow_radius:0f,text:[{text:"kitchen_counter",color:"yellow"}]}
execute rotated ~ 0 positioned ^10.0 ^ ^31.0 run function evercraft:decor/build/lamppost {mat:"polished_deepslate"}
execute rotated ~ 0 positioned ^10.0 ^ ^31.0 run summon text_display ~ ~3.0 ~ {Tags:["ec.showroom"],billboard:"center",brightness:{block:15,sky:15},shadow_radius:0f,text:[{text:"lamppost",color:"yellow"}]}
execute rotated ~ 0 positioned ^6.0 ^ ^31.0 run function evercraft:decor/build/mailbox {mat:"bricks"}
execute rotated ~ 0 positioned ^6.0 ^ ^31.0 run summon text_display ~ ~3.0 ~ {Tags:["ec.showroom"],billboard:"center",brightness:{block:15,sky:15},shadow_radius:0f,text:[{text:"mailbox",color:"yellow"}]}
execute rotated ~ 0 positioned ^2.0 ^ ^31.0 run function evercraft:decor/build/market_stall {mat:"red"}
execute rotated ~ 0 positioned ^2.0 ^ ^31.0 run summon text_display ~ ~3.0 ~ {Tags:["ec.showroom"],billboard:"center",brightness:{block:15,sky:15},shadow_radius:0f,text:[{text:"market_stall",color:"yellow"}]}
execute rotated ~ 0 positioned ^-2.0 ^ ^31.0 run function evercraft:decor/build/parasol_table {mat:"red"}
execute rotated ~ 0 positioned ^-2.0 ^ ^31.0 run summon text_display ~ ~3.0 ~ {Tags:["ec.showroom"],billboard:"center",brightness:{block:15,sky:15},shadow_radius:0f,text:[{text:"parasol_table",color:"yellow"}]}
execute rotated ~ 0 positioned ^-6.0 ^ ^31.0 run function evercraft:decor/build/picnic_set {mat:"red"}
execute rotated ~ 0 positioned ^-6.0 ^ ^31.0 run summon text_display ~ ~3.0 ~ {Tags:["ec.showroom"],billboard:"center",brightness:{block:15,sky:15},shadow_radius:0f,text:[{text:"picnic_set",color:"yellow"}]}
execute rotated ~ 0 positioned ^-10.0 ^ ^31.0 run function evercraft:decor/build/pond_kit
execute rotated ~ 0 positioned ^-10.0 ^ ^31.0 run summon text_display ~ ~3.0 ~ {Tags:["ec.showroom"],billboard:"center",brightness:{block:15,sky:15},shadow_radius:0f,text:[{text:"pond_kit",color:"yellow"}]}
execute rotated ~ 0 positioned ^-14.0 ^ ^31.0 run function evercraft:decor/build/post_lantern {mat:"oak"}
execute rotated ~ 0 positioned ^-14.0 ^ ^31.0 run summon text_display ~ ~3.0 ~ {Tags:["ec.showroom"],billboard:"center",brightness:{block:15,sky:15},shadow_radius:0f,text:[{text:"post_lantern",color:"yellow"}]}
execute rotated ~ 0 positioned ^-18.0 ^ ^31.0 run function evercraft:decor/build/reliquary_plinth
execute rotated ~ 0 positioned ^-18.0 ^ ^31.0 run summon text_display ~ ~3.0 ~ {Tags:["ec.showroom"],billboard:"center",brightness:{block:15,sky:15},shadow_radius:0f,text:[{text:"reliquary_plinth",color:"yellow"}]}
execute rotated ~ 0 positioned ^18.0 ^ ^35.5 run function evercraft:decor/build/rug {mat:"red"}
execute rotated ~ 0 positioned ^18.0 ^ ^35.5 run summon text_display ~ ~3.0 ~ {Tags:["ec.showroom"],billboard:"center",brightness:{block:15,sky:15},shadow_radius:0f,text:[{text:"rug",color:"yellow"}]}
execute rotated ~ 0 positioned ^14.0 ^ ^35.5 run function evercraft:decor/build/scarecrow
execute rotated ~ 0 positioned ^14.0 ^ ^35.5 run summon text_display ~ ~3.0 ~ {Tags:["ec.showroom"],billboard:"center",brightness:{block:15,sky:15},shadow_radius:0f,text:[{text:"scarecrow",color:"yellow"}]}
execute rotated ~ 0 positioned ^10.0 ^ ^35.5 run function evercraft:decor/build/shield_display
execute rotated ~ 0 positioned ^10.0 ^ ^35.5 run summon text_display ~ ~3.0 ~ {Tags:["ec.showroom"],billboard:"center",brightness:{block:15,sky:15},shadow_radius:0f,text:[{text:"shield_display",color:"yellow"}]}
execute rotated ~ 0 positioned ^6.0 ^ ^35.5 run function evercraft:decor/build/stone_well {mat:"stone"}
execute rotated ~ 0 positioned ^6.0 ^ ^35.5 run summon text_display ~ ~3.0 ~ {Tags:["ec.showroom"],billboard:"center",brightness:{block:15,sky:15},shadow_radius:0f,text:[{text:"stone_well",color:"yellow"}]}
execute rotated ~ 0 positioned ^2.0 ^ ^35.5 run function evercraft:decor/build/stool {mat:"oak"}
execute rotated ~ 0 positioned ^2.0 ^ ^35.5 run summon text_display ~ ~3.0 ~ {Tags:["ec.showroom"],billboard:"center",brightness:{block:15,sky:15},shadow_radius:0f,text:[{text:"stool",color:"yellow"}]}
execute rotated ~ 0 positioned ^-2.0 ^ ^35.5 run function evercraft:decor/build/tea_table {mat:"oak"}
execute rotated ~ 0 positioned ^-2.0 ^ ^35.5 run summon text_display ~ ~3.0 ~ {Tags:["ec.showroom"],billboard:"center",brightness:{block:15,sky:15},shadow_radius:0f,text:[{text:"tea_table",color:"yellow"}]}
execute rotated ~ 0 positioned ^-6.0 ^ ^35.5 run function evercraft:decor/build/tinker_bench
execute rotated ~ 0 positioned ^-6.0 ^ ^35.5 run summon text_display ~ ~3.0 ~ {Tags:["ec.showroom"],billboard:"center",brightness:{block:15,sky:15},shadow_radius:0f,text:[{text:"tinker_bench",color:"yellow"}]}
execute rotated ~ 0 positioned ^-10.0 ^ ^35.5 run function evercraft:decor/build/trellis
execute rotated ~ 0 positioned ^-10.0 ^ ^35.5 run summon text_display ~ ~3.0 ~ {Tags:["ec.showroom"],billboard:"center",brightness:{block:15,sky:15},shadow_radius:0f,text:[{text:"trellis",color:"yellow"}]}
execute rotated ~ 0 positioned ^-14.0 ^ ^35.5 run function evercraft:decor/build/trophy_shelf
execute rotated ~ 0 positioned ^-14.0 ^ ^35.5 run summon text_display ~ ~3.0 ~ {Tags:["ec.showroom"],billboard:"center",brightness:{block:15,sky:15},shadow_radius:0f,text:[{text:"trophy_shelf",color:"yellow"}]}
execute rotated ~ 0 positioned ^-18.0 ^ ^35.5 run function evercraft:decor/build/vanity_mirror
execute rotated ~ 0 positioned ^-18.0 ^ ^35.5 run summon text_display ~ ~3.0 ~ {Tags:["ec.showroom"],billboard:"center",brightness:{block:15,sky:15},shadow_radius:0f,text:[{text:"vanity_mirror",color:"yellow"}]}
execute rotated ~ 0 positioned ^18.0 ^ ^40.0 run function evercraft:decor/build/wall_sconce {mat:"dark_oak_planks"}
execute rotated ~ 0 positioned ^18.0 ^ ^40.0 run summon text_display ~ ~3.0 ~ {Tags:["ec.showroom"],billboard:"center",brightness:{block:15,sky:15},shadow_radius:0f,text:[{text:"wall_sconce",color:"yellow"}]}
execute rotated ~ 0 positioned ^14.0 ^ ^40.0 run function evercraft:decor/build/wardrobe {mat:"spruce"}
execute rotated ~ 0 positioned ^14.0 ^ ^40.0 run summon text_display ~ ~3.0 ~ {Tags:["ec.showroom"],billboard:"center",brightness:{block:15,sky:15},shadow_radius:0f,text:[{text:"wardrobe",color:"yellow"}]}
execute rotated ~ 0 positioned ^10.0 ^ ^40.0 run function evercraft:decor/build/wash_basin
execute rotated ~ 0 positioned ^10.0 ^ ^40.0 run summon text_display ~ ~3.0 ~ {Tags:["ec.showroom"],billboard:"center",brightness:{block:15,sky:15},shadow_radius:0f,text:[{text:"wash_basin",color:"yellow"}]}
execute rotated ~ 0 positioned ^6.0 ^ ^40.0 run function evercraft:decor/build/weapon_rack
execute rotated ~ 0 positioned ^6.0 ^ ^40.0 run summon text_display ~ ~3.0 ~ {Tags:["ec.showroom"],billboard:"center",brightness:{block:15,sky:15},shadow_radius:0f,text:[{text:"weapon_rack",color:"yellow"}]}
execute rotated ~ 0 positioned ^2.0 ^ ^40.0 run function evercraft:decor/build/wind_chimes {mat:"waxed_copper_block"}
execute rotated ~ 0 positioned ^2.0 ^ ^40.0 run summon text_display ~ ~3.0 ~ {Tags:["ec.showroom"],billboard:"center",brightness:{block:15,sky:15},shadow_radius:0f,text:[{text:"wind_chimes",color:"yellow"}]}
execute rotated ~ 0 positioned ^-2.0 ^ ^40.0 run function evercraft:decor/build/writing_desk {mat:"dark_oak"}
execute rotated ~ 0 positioned ^-2.0 ^ ^40.0 run summon text_display ~ ~3.0 ~ {Tags:["ec.showroom"],billboard:"center",brightness:{block:15,sky:15},shadow_radius:0f,text:[{text:"writing_desk",color:"yellow"}]}
execute rotated ~ 0 positioned ^-6.0 ^ ^40.0 run function evercraft:decor/build/aquarium_grand
execute rotated ~ 0 positioned ^-6.0 ^ ^40.0 run summon text_display ~ ~4.0 ~ {Tags:["ec.showroom"],billboard:"center",brightness:{block:15,sky:15},shadow_radius:0f,text:[{text:"aquarium_grand",color:"yellow"}]}
execute rotated ~ 0 positioned ^-10.0 ^ ^40.0 run function evercraft:decor/build/bookcase {mat:"oak"}
execute rotated ~ 0 positioned ^-10.0 ^ ^40.0 run summon text_display ~ ~3.0 ~ {Tags:["ec.showroom"],billboard:"center",brightness:{block:15,sky:15},shadow_radius:0f,text:[{text:"bookcase",color:"yellow"}]}
execute rotated ~ 0 positioned ^-14.0 ^ ^40.0 run function evercraft:decor/build/kitchen_cabinet
execute rotated ~ 0 positioned ^-14.0 ^ ^40.0 run summon text_display ~ ~3.0 ~ {Tags:["ec.showroom"],billboard:"center",brightness:{block:15,sky:15},shadow_radius:0f,text:[{text:"kitchen_cabinet",color:"yellow"}]}
execute rotated ~ 0 positioned ^-18.0 ^ ^40.0 run function evercraft:decor/build/kitchen_stove
execute rotated ~ 0 positioned ^-18.0 ^ ^40.0 run summon text_display ~ ~3.0 ~ {Tags:["ec.showroom"],billboard:"center",brightness:{block:15,sky:15},shadow_radius:0f,text:[{text:"kitchen_stove",color:"yellow"}]}
execute rotated ~ 0 positioned ^18.0 ^ ^44.5 run function evercraft:decor/build/kitchen_sink
execute rotated ~ 0 positioned ^18.0 ^ ^44.5 run summon text_display ~ ~3.0 ~ {Tags:["ec.showroom"],billboard:"center",brightness:{block:15,sky:15},shadow_radius:0f,text:[{text:"kitchen_sink",color:"yellow"}]}
execute rotated ~ 0 positioned ^14.0 ^ ^44.5 run function evercraft:decor/build/stone_dining_table {mat:"smooth_stone"}
execute rotated ~ 0 positioned ^14.0 ^ ^44.5 run summon text_display ~ ~3.0 ~ {Tags:["ec.showroom"],billboard:"center",brightness:{block:15,sky:15},shadow_radius:0f,text:[{text:"stone_dining_table",color:"yellow"}]}
execute rotated ~ 0 positioned ^10.0 ^ ^44.5 run function evercraft:decor/build/stone_tea_table {mat:"smooth_stone"}
execute rotated ~ 0 positioned ^10.0 ^ ^44.5 run summon text_display ~ ~3.0 ~ {Tags:["ec.showroom"],billboard:"center",brightness:{block:15,sky:15},shadow_radius:0f,text:[{text:"stone_tea_table",color:"yellow"}]}
execute rotated ~ 0 positioned ^6.0 ^ ^44.5 run function evercraft:decor/build/stone_kitchen_counter {mat:"smooth_stone"}
execute rotated ~ 0 positioned ^6.0 ^ ^44.5 run summon text_display ~ ~3.0 ~ {Tags:["ec.showroom"],billboard:"center",brightness:{block:15,sky:15},shadow_radius:0f,text:[{text:"stone_kitchen_counter",color:"yellow"}]}
tag @e[tag=ec.dec_ghost,distance=..200] add ec.showroom
tag @e[tag=ec.dec_ghost,distance=..200] remove ec.dec_ghost
tag @e[tag=ec.bonsai_prev,distance=..200] add ec.showroom
tag @e[tag=ec.bonsai_prev,distance=..200] remove ec.bonsai_prev
tellraw @s [{"text":"[Showroom] ","color":"green"},{"text":"94 decor pieces placed. Clear: ","color":"gray"},{"text":"/kill @e[tag=ec.showroom]","color":"yellow"}]
