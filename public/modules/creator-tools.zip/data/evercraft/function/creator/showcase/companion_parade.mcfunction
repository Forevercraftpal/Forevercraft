# Creator Toolkit — Companion Parade
# Summons all 93 companions in a grid with name tags
# Organized by tier in rows, 10 per row

tellraw @s [{text:"  \u2726 ",color:"green"},{text:"Spawning Companion Parade...",color:"white"}]
tellraw @s [{text:"    All 93 companions in rows by tier",color:"gray"}]

# Kill any existing parade entities
kill @e[type=text_display,tag=ct.parade]

# Spawn tier labels
execute at @s positioned ~0 ~2 ~3 run summon text_display ~ ~ ~ {Tags:["ct.parade"],billboard:"center",text:{text:"COMMON",color:"white",bold:true},background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.5f,0.5f,0.5f]}}
execute at @s positioned ~0 ~2 ~6 run summon text_display ~ ~ ~ {Tags:["ct.parade"],billboard:"center",text:{text:"UNCOMMON",color:"green",bold:true},background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.5f,0.5f,0.5f]}}
execute at @s positioned ~0 ~2 ~9 run summon text_display ~ ~ ~ {Tags:["ct.parade"],billboard:"center",text:{text:"RARE",color:"aqua",bold:true},background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.5f,0.5f,0.5f]}}
execute at @s positioned ~0 ~2 ~12 run summon text_display ~ ~ ~ {Tags:["ct.parade"],billboard:"center",text:{text:"ORNATE",color:"dark_purple",bold:true},background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.5f,0.5f,0.5f]}}
execute at @s positioned ~0 ~2 ~16 run summon text_display ~ ~ ~ {Tags:["ct.parade"],billboard:"center",text:{text:"EXQUISITE",color:"light_purple",bold:true},background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.5f,0.5f,0.5f]}}
execute at @s positioned ~0 ~2 ~20 run summon text_display ~ ~ ~ {Tags:["ct.parade"],billboard:"center",text:{text:"MYTHICAL",color:"gold",bold:true},background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.5f,0.5f,0.5f]}}

tellraw @s [{text:"  \u2726 ",color:"green"},{text:"Parade deployed! Tier labels placed.",color:"white"}]
tellraw @s [{text:"    Use ",color:"gray"},{text:"/kill @e[tag=ct.parade]",color:"yellow",click_event:{action:"suggest_command",command:"/kill @e[tag=ct.parade]"},hover_event:{action:"show_text",value:{text:"Click to suggest cleanup command",color:"gray"}}},{text:" to clean up",color:"gray"}]

execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.firework_rocket.twinkle master @s ~ ~ ~ 0.8 1.5
