# Creator Toolkit — Load
# Plan 6: Admin panel expansion, showcase mode, screenshot mode, freeze frame

# === SCOREBOARDS ===
scoreboard objectives add ct.menu trigger
scoreboard objectives add ct.action dummy
scoreboard objectives add ct.page dummy
scoreboard objectives add ct.screenshot dummy
scoreboard objectives add ct.freeze dummy
scoreboard objectives add ct.timelapse dummy
scoreboard objectives add ct.showcase_timer dummy

# === CONSTANTS ===
scoreboard players set #ct_showcase_dur ec.const 1200
