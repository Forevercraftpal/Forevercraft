# Creator Toolkit — Set DR to 100 (the cap; DR-cap raise 50->100, Joseph 2026-06-02)
attribute @s luck base set 100.0
tellraw @s [{text:"  ✦ ",color:"light_purple"},{text:"Dream Rate set to 100.0 (MAX)",color:"gold"}]
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.experience_orb.pickup master @s ~ ~ ~ 0.5 1.2
