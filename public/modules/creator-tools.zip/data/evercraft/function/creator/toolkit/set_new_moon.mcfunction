# Creator Toolkit — Skip to New Moon
# New moon = moon phase 4 (day % 8 == 4)
tellraw @s [{text:"  \u2726 ",color:"dark_gray"},{text:"Advancing to new moon...",color:"white"}]
execute store result score #cur_day ec.temp run time query minecraft:day repetition
scoreboard players operation #cur_day ec.temp %= #8 ec.const
scoreboard players set #advance ec.temp 4
scoreboard players operation #advance ec.temp -= #cur_day ec.temp
execute if score #advance ec.temp matches ..-1 run scoreboard players add #advance ec.temp 8
execute if score #advance ec.temp matches 0 run scoreboard players set #advance ec.temp 8
tellraw @s [{text:"  \u2726 ",color:"dark_gray"},{text:"New moon active!",color:"white"}]
