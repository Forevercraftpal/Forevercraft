# Creator Toolkit — Trigger Harvest Moon
scoreboard players set #harvest_moon ec.var 1
gamerule minecraft:random_tick_speed 15
tellraw @a [{text:"  \u2726 ",color:"gold"},{text:"A Harvest Moon illuminates the land!",color:"yellow",bold:true}]
playsound minecraft:block.amethyst_block.resonate master @a[scores={ec.fx_snd=1..}] ~ ~ ~ 0.8 0.8
