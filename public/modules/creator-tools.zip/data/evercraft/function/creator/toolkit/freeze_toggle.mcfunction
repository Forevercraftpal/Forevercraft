# Creator Toolkit — Freeze Frame Toggle
# Pauses all Forevercraft tick processing (not vanilla entities)
# Uses the #daylight_counter gate in tick.mcfunction

execute if score @s ct.freeze matches 0 run scoreboard players set @s ct.freeze 1
execute if score @s ct.freeze matches 1 run tellraw @s [{text:"  \u2726 ",color:"aqua"},{text:"Forevercraft FROZEN",color:"white",bold:true},{text:" — Pack logic paused for screenshots",color:"gray"}]
execute if score @s ct.freeze matches 1 run scoreboard players set #ec_frozen ec.var 1

execute if score @s ct.freeze matches 2 run scoreboard players set @s ct.freeze 0
execute if score @s ct.freeze matches 0 run tellraw @s [{text:"  \u2726 ",color:"green"},{text:"Forevercraft UNFROZEN",color:"white",bold:true},{text:" — Normal operation resumed",color:"gray"}]
execute if score @s ct.freeze matches 0 run scoreboard players set #ec_frozen ec.var 0

# Cycle: 0 → 1 → 0 (toggle via add then check)
execute if score @s ct.freeze matches 1 run scoreboard players set @s ct.freeze 2
