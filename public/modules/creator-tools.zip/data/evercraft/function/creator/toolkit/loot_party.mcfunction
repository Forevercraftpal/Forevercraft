# Creator Toolkit — Loot Party
# Bursts 8 crates in a circle around the player
# Uses the existing crate animation engine

tellraw @a[distance=..50] [{text:"  \u2726\u2726\u2726 ",color:"gold"},{text:"LOOT PARTY!",bold:true,color:"#FFD700"},{text:" \u2726\u2726\u2726",color:"gold"}]
playsound minecraft:entity.firework_rocket.blast master @a[distance=..50,scores={ec.fx_snd=1..}] ~ ~ ~ 1.0 0.8
playsound minecraft:entity.firework_rocket.twinkle master @a[distance=..50,scores={ec.fx_snd=1..}] ~ ~ ~ 1.0 1.2

# Spawn 8 crates in a circle (radius ~3 blocks)
execute at @s positioned ~3 ~ ~0 run loot spawn ~ ~1 ~ loot evercraft:crates/common
execute at @s positioned ~2.1 ~ ~2.1 run loot spawn ~ ~1 ~ loot evercraft:crates/uncommon
execute at @s positioned ~0 ~ ~3 run loot spawn ~ ~1 ~ loot evercraft:crates/rare
execute at @s positioned ~-2.1 ~ ~2.1 run loot spawn ~ ~1 ~ loot evercraft:crates/ornate
execute at @s positioned ~-3 ~ ~0 run loot spawn ~ ~1 ~ loot evercraft:crates/exquisite
execute at @s positioned ~-2.1 ~ ~-2.1 run loot spawn ~ ~1 ~ loot evercraft:crates/mythical
execute at @s positioned ~0 ~ ~-3 run loot spawn ~ ~1 ~ loot evercraft:crates/common
execute at @s positioned ~2.1 ~ ~-2.1 run loot spawn ~ ~1 ~ loot evercraft:crates/rare
