# Creator Toolkit — Trigger Blood Moon
scoreboard players set #blood_moon ec.var 1
tellraw @a [{text:"  \u2726 ",color:"dark_red"},{text:"A Blood Moon rises...",color:"red",bold:true}]
playsound minecraft:ambient.cave master @a[scores={ec.fx_snd=1..}] ~ ~ ~ 0.8 0.5
