# Creator Toolkit — Spawn Mythical Crate
loot give @s loot evercraft:crates/items/mythical
tellraw @s [{"text":"  \u2726 ","color":"gold"},{"text":"Mythical crate spawned!","color":"light_purple"}]
