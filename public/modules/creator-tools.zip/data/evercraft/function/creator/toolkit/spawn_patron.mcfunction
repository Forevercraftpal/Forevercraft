# Creator Toolkit — Force Spawn Patron
# @s = op player
execute at @s run function evercraft:mobs/patrons/check
tellraw @s [{text:"  \u2726 ",color:"dark_red"},{text:"Patron force-spawned!",color:"red"}]
