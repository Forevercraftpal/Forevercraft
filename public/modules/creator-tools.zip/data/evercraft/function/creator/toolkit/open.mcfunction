# Creator Toolkit — Open Director's Menu
# @s = op player, called from Codex admin section

tellraw @s {text:""}
tellraw @s [{text:"  \u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550",color:"#5C4033"}]
tellraw @s [{text:"    \u2726 ",color:"gold"},{text:"DIRECTOR'S TOOLKIT",bold:true,color:"#FF6B35"},{text:" \u2726",color:"gold"}]
tellraw @s [{text:"  \u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550",color:"#5C4033"}]
tellraw @s {text:""}

# === SPAWN TOOLS ===
tellraw @s [{text:"  \u2694 ",color:"red"},{text:"Combat Spawns",bold:true,color:"#DDF0EE"}]
tellraw @s [{text:"    [",color:"dark_gray"},{text:"Patron",color:"dark_red",click_event:{action:"run_command",command:"/function evercraft:creator/toolkit/spawn_patron"},hover_event:{action:"show_text",value:{text:"Force spawn a Patron mob",color:"gray"}}},{text:"]  ",color:"dark_gray"},{text:"[",color:"dark_gray"},{text:"Furia",color:"dark_purple",click_event:{action:"run_command",command:"/function evercraft:creator/toolkit/spawn_furia"},hover_event:{action:"show_text",value:{text:"Force spawn a Furia",color:"gray"}}},{text:"]  ",color:"dark_gray"},{text:"[",color:"dark_gray"},{text:"World Boss",color:"gold",click_event:{action:"run_command",command:"/function evercraft:creator/toolkit/spawn_boss"},hover_event:{action:"show_text",value:{text:"Summon a world boss",color:"gray"}}},{text:"]",color:"dark_gray"}]
tellraw @s {text:""}

# === CALENDAR EVENTS ===
tellraw @s [{text:"  \u2605 ",color:"yellow"},{text:"Calendar Events",bold:true,color:"#DDF0EE"}]
tellraw @s [{text:"    [",color:"dark_gray"},{text:"Blood Moon",color:"dark_red",click_event:{action:"run_command",command:"/function evercraft:creator/toolkit/trigger_blood_moon"},hover_event:{action:"show_text",value:{text:"Trigger Blood Moon event",color:"gray"}}},{text:"]  ",color:"dark_gray"},{text:"[",color:"dark_gray"},{text:"Harvest Moon",color:"gold",click_event:{action:"run_command",command:"/function evercraft:creator/toolkit/trigger_harvest_moon"},hover_event:{action:"show_text",value:{text:"Trigger Harvest Moon",color:"gray"}}},{text:"]  ",color:"dark_gray"},{text:"[",color:"dark_gray"},{text:"Convergence",color:"light_purple",click_event:{action:"run_command",command:"/function evercraft:creator/toolkit/trigger_convergence"},hover_event:{action:"show_text",value:{text:"Trigger Harmonic Convergence",color:"gray"}}},{text:"]",color:"dark_gray"}]
tellraw @s {text:""}

# === DR / PROGRESSION ===
tellraw @s [{text:"  \u2726 ",color:"light_purple"},{text:"Progression Controls",bold:true,color:"#DDF0EE"}]
tellraw @s [{text:"    [",color:"dark_gray"},{text:"Set DR 10",color:"#9370DB",click_event:{action:"run_command",command:"/function evercraft:creator/toolkit/set_dr_10"},hover_event:{action:"show_text",value:{text:"Set Dream Rate to 10",color:"gray"}}},{text:"]  ",color:"dark_gray"},{text:"[",color:"dark_gray"},{text:"Set DR 25",color:"#9370DB",click_event:{action:"run_command",command:"/function evercraft:creator/toolkit/set_dr_25"},hover_event:{action:"show_text",value:{text:"Set Dream Rate to 25",color:"gray"}}},{text:"]  ",color:"dark_gray"},{text:"[",color:"dark_gray"},{text:"Set DR 50",color:"#9370DB",click_event:{action:"run_command",command:"/function evercraft:creator/toolkit/set_dr_50"},hover_event:{action:"show_text",value:{text:"Set Dream Rate to 50",color:"gray"}}},{text:"]  ",color:"dark_gray"},{text:"[",color:"dark_gray"},{text:"Set DR 100",color:"#9370DB",click_event:{action:"run_command",command:"/function evercraft:creator/toolkit/set_dr_100"},hover_event:{action:"show_text",value:{text:"Set Dream Rate to 100 (max)",color:"gray"}}},{text:"]",color:"dark_gray"}]
tellraw @s {text:""}

# === CRATE SPAWNS ===
tellraw @s [{text:"  \u2756 ",color:"aqua"},{text:"Crate Spawns",bold:true,color:"#DDF0EE"}]
tellraw @s [{text:"    [",color:"dark_gray"},{text:"Common",color:"white",click_event:{action:"run_command",command:"/function evercraft:creator/toolkit/spawn_crate_common"},hover_event:{action:"show_text",value:{text:"Spawn a Common crate at your feet",color:"gray"}}},{text:"]  ",color:"dark_gray"},{text:"[",color:"dark_gray"},{text:"Rare",color:"aqua",click_event:{action:"run_command",command:"/function evercraft:creator/toolkit/spawn_crate_rare"},hover_event:{action:"show_text",value:{text:"Spawn a Rare crate",color:"gray"}}},{text:"]  ",color:"dark_gray"},{text:"[",color:"dark_gray"},{text:"Ornate",color:"dark_purple",click_event:{action:"run_command",command:"/function evercraft:creator/toolkit/spawn_crate_ornate"},hover_event:{action:"show_text",value:{text:"Spawn an Ornate crate",color:"gray"}}},{text:"]  ",color:"dark_gray"},{text:"[",color:"dark_gray"},{text:"Mythical",color:"gold",click_event:{action:"run_command",command:"/function evercraft:creator/toolkit/spawn_crate_mythical"},hover_event:{action:"show_text",value:{text:"Spawn a Mythical crate",color:"gray"}}},{text:"]",color:"dark_gray"}]
tellraw @s {text:""}

# === SEASON & TIME ===
tellraw @s [{text:"  \u2600 ",color:"gold"},{text:"Time & Season",bold:true,color:"#DDF0EE"}]
tellraw @s [{text:"    [",color:"dark_gray"},{text:"Set Night",color:"dark_blue",click_event:{action:"run_command",command:"/function evercraft:creator/toolkit/set_night"},hover_event:{action:"show_text",value:{text:"Set time to night",color:"gray"}}},{text:"]  ",color:"dark_gray"},{text:"[",color:"dark_gray"},{text:"Full Moon",color:"yellow",click_event:{action:"run_command",command:"/function evercraft:creator/toolkit/set_full_moon"},hover_event:{action:"show_text",value:{text:"Skip to next full moon",color:"gray"}}},{text:"]  ",color:"dark_gray"},{text:"[",color:"dark_gray"},{text:"New Moon",color:"dark_gray",click_event:{action:"run_command",command:"/function evercraft:creator/toolkit/set_new_moon"},hover_event:{action:"show_text",value:{text:"Skip to next new moon",color:"gray"}}},{text:"]",color:"dark_gray"}]
tellraw @s {text:""}

# === VISUAL MODES ===
tellraw @s [{text:"  \u2609 ",color:"white"},{text:"Visual Modes",bold:true,color:"#DDF0EE"}]
tellraw @s [{text:"    [",color:"dark_gray"},{text:"Screenshot Mode",color:"white",click_event:{action:"run_command",command:"/function evercraft:creator/screenshot/toggle"},hover_event:{action:"show_text",value:{text:"Hide all HUD elements for clean screenshots",color:"gray"}}},{text:"]  ",color:"dark_gray"},{text:"[",color:"dark_gray"},{text:"Freeze Frame",color:"aqua",click_event:{action:"run_command",command:"/function evercraft:creator/toolkit/freeze_toggle"},hover_event:{action:"show_text",value:{text:"Pause all Forevercraft tick processing",color:"gray"}}},{text:"]  ",color:"dark_gray"},{text:"[",color:"dark_gray"},{text:"Companion Parade",color:"green",click_event:{action:"run_command",command:"/function evercraft:creator/showcase/companion_parade"},hover_event:{action:"show_text",value:{text:"Summon all 93 companions in a grid",color:"gray"}}},{text:"]",color:"dark_gray"}]

# === LOOT PARTY ===
tellraw @s {text:""}
tellraw @s [{text:"    [",color:"dark_gray"},{text:"\u2726 Loot Party \u2726",color:"gold",bold:true,click_event:{action:"run_command",command:"/function evercraft:creator/toolkit/loot_party"},hover_event:{action:"show_text",value:{text:"Burst open 8 crates in a circle around you!",color:"gray"}}},{text:"]",color:"dark_gray"}]

tellraw @s {text:""}
tellraw @s [{text:"  \u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550",color:"#5C4033"}]

execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.amethyst_block.resonate master @s ~ ~ ~ 0.3 1.2
