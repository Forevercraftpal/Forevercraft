# Creator Toolkit — Spawn Common Crate (BUG-001 FIX)
loot give @s loot evercraft:crates/items/common
tellraw @s [{"text":"  \u2726 ","color":"gray"},{"text":"Common crate spawned!","color":"white"}]
