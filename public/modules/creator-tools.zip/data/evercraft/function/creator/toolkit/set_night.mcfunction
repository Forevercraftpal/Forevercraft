# Creator Toolkit — Set Night
time set 13000
tellraw @s [{text:"  \u2726 ",color:"dark_blue"},{text:"Time set to night",color:"white"}]
