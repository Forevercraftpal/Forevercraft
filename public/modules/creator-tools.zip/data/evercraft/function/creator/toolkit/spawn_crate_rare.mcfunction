# Creator Toolkit — Spawn Rare Crate (BUG-001 FIX)
loot give @s loot evercraft:crates/items/rare
tellraw @s [{"text":"  \u2726 ","color":"dark_gray"},{"text":"Rare crate spawned!","color":"aqua"}]
