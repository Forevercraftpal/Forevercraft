# Creator Toolkit — Spawn Ornate Crate (BUG-001 FIX)
loot give @s loot evercraft:crates/items/ornate
tellraw @s [{"text":"  \u2726 ","color":"dark_gray"},{"text":"Ornate crate spawned!","color":"dark_purple"}]
