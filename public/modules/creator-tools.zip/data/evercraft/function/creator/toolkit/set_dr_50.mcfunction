# Creator Toolkit — Set DR to 50
attribute @s luck base set 50.0
tellraw @s [{text:"  \u2726 ",color:"light_purple"},{text:"Dream Rate set to 50.0",color:"gold"}]
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.experience_orb.pickup master @s ~ ~ ~ 0.5 1.2
