# Creator Toolkit — Summon World Boss
execute at @s run function evercraft:bosses/admin/summon
tellraw @s [{text:"  \u2726 ",color:"gold"},{text:"World Boss summoned!",color:"yellow"}]
