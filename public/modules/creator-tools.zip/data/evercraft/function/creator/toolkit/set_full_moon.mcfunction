# Creator Toolkit — Skip to Full Moon
# Full moon = moon phase 0 (day % 8 == 0)
# Advance time until moon phase hits 0
scoreboard players set #moon_target ec.temp 0
tellraw @s [{text:"  \u2726 ",color:"yellow"},{text:"Advancing to full moon...",color:"white"}]
# Direct set: full moon starts at day 0, 8, 16, etc.
# Get current day, round up to next multiple of 8
execute store result score #cur_day ec.temp run time query minecraft:day repetition
scoreboard players operation #cur_day ec.temp %= #8 ec.const
scoreboard players set #advance ec.temp 8
scoreboard players operation #advance ec.temp -= #cur_day ec.temp
execute if score #advance ec.temp matches 8 run scoreboard players set #advance ec.temp 0
# Advance by (#advance * 24000) ticks
scoreboard players operation #advance ec.temp *= #25 ec.const
scoreboard players operation #advance ec.temp *= #1000 ec.const
execute store result storage evercraft:creator temp.ticks int 1 run scoreboard players get #advance ec.temp
tellraw @s [{text:"  \u2726 ",color:"yellow"},{text:"Full moon active!",color:"gold"}]
