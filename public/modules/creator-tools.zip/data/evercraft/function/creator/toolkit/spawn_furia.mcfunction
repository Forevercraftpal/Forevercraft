# Creator Toolkit — Force Spawn Furia
execute at @s run function evercraft:mobs/furia/force_spawn
tellraw @s [{text:"  \u2726 ",color:"dark_purple"},{text:"Furia force-spawned!",color:"light_purple"}]
