# Creator Toolkit — Trigger Harmonic Convergence
function evercraft:convergence/start
tellraw @s [{text:"  \u2726 ",color:"light_purple"},{text:"Harmonic Convergence triggered!",color:"#E0B0FF"}]
