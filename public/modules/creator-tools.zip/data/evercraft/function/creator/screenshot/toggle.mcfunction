# Creator Toolkit — Screenshot Mode Toggle
# Hides all HUD particles, actionbar text, floating GUI entities

execute if score @s ct.screenshot matches 0 run scoreboard players set @s ct.screenshot 1
execute if score @s ct.screenshot matches 1 store success score #ss_set ec.temp run tag @s add ct.screenshot_mode
execute if score #ss_set ec.temp matches 1 run tellraw @s [{text:"  \u2609 ",color:"white"},{text:"Screenshot Mode ON",color:"white",bold:true},{text:" — HUD hidden, clean view",color:"gray"}]
# (Wave 2, 2026-06-10: bar-clear stays RAW — gated so it never blanks a queue frame.)
execute if score #ss_set ec.temp matches 1 unless entity @s[tag=ab_q] run title @s actionbar {text:""}

execute unless score #ss_set ec.temp matches 1 run tag @s remove ct.screenshot_mode
execute unless score #ss_set ec.temp matches 1 run scoreboard players set @s ct.screenshot 0
execute unless score #ss_set ec.temp matches 1 run tellraw @s [{text:"  \u2609 ",color:"white"},{text:"Screenshot Mode OFF",color:"white",bold:true},{text:" — Normal HUD restored",color:"gray"}]

execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.hat master @s ~ ~ ~ 0.5 1.8
