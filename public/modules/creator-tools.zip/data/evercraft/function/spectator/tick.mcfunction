# Spectator — Tick chain
# Drives the ec.spectate trigger consumer + encounter_cam/tick for active spectators.
# Outer existence-gated at the call site (tick.mcfunction).

# Consume ec.spectate trigger — fires encounter_cam/start for any non-spectating triggerer
execute as @a[scores={ec.spectate=1..},tag=!sp.spectating] at @s run function evercraft:spectator/encounter_cam/start
scoreboard players set @a[scores={ec.spectate=1..}] ec.spectate 0
scoreboard players enable @a[scores={ec.spectate=0}] ec.spectate

# Run encounter_cam/tick per active spectator (handles sneak-exit + auto-exit)
execute as @a[tag=sp.spectating] at @s run function evercraft:spectator/encounter_cam/tick
