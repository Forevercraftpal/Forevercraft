# Encounter Cam — Accept spectate invite
# Run as: the accepting player

# Remove invited tag
tag @s remove sp.invited

# Validate that the encounter spectator session is still active
data modify storage evercraft:notify stage.c set value [{text:"The spectate session has ended.",color:"gray"}]
scoreboard players set #ndur ec.temp 45
execute unless entity @a[tag=sp.spectating,limit=1] run function evercraft:util/notify/emit
execute unless entity @a[tag=sp.spectating,limit=1] run return 0

# Save return position
scoreboard players set @s ec.tp_ret_sys 7
execute at @s run function evercraft:tp_safety/save

# Capture current gamemode so exit restores it (not a hardcoded survival)
# Shared sp.was_* tag-set with encounter_cam/start + codex_spectator
tag @s remove sp.was_creative
tag @s remove sp.was_adventure
tag @s remove sp.was_spectator
tag @s add sp.was_creative
execute unless entity @s[gamemode=creative] run tag @s remove sp.was_creative
execute if entity @s[gamemode=adventure] run tag @s add sp.was_adventure
execute if entity @s[gamemode=spectator] run tag @s add sp.was_spectator

# Switch to spectator mode
tag @s add sp.spectating
gamemode spectator @s
scoreboard players set @s sp.active 1

# Teleport near the active spectator
tp @s @a[tag=sp.spectating,limit=1,sort=nearest]

# Set up bossbar — group audience so the seed-spectator stays visible (Council #13 audience fix)
bossbar set evercraft:encounter_cam players @a[tag=sp.spectating]
bossbar set evercraft:encounter_cam visible true

# Feedback
data modify storage evercraft:notify stage.c set value [{text:"\u2726 ",color:"gold"},{text:"Spectator Mode: ON",color:"white",bold:true},{text:" \u2726",color:"gold"}]
scoreboard players set #ndur ec.temp 50
function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Sneak to exit spectator mode",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.beacon.activate master @s ~ ~ ~ 0.5 1.5
