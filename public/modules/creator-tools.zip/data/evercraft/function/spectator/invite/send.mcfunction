# Encounter Cam — Send spectate invite to party members
# Run as: the spectating player

# Store party ID for macro
execute store result storage evercraft:party temp.pid int 1 run scoreboard players get @s ec.party_id

# Invite all party members who aren't already spectating
function evercraft:spectator/invite/send_macro with storage evercraft:party temp
