# Encounter Cam — Show spectate invite to a party member
# Run as: the invited player

# Enable trigger
scoreboard players set @s ec.tp_join 0
scoreboard players enable @s ec.tp_join

# Mark as invited
tag @s add sp.invited

# Clickable invite message
tellraw @s [{text:"[Encounter] ",color:"gold",bold:true},{text:"Your party is spectating a battle! ",color:"yellow"},{text:"[Watch]",color:"green",bold:true,click_event:{action:"run_command",command:"/trigger ec.tp_join set 7"},hover_event:{action:"show_text",value:{text:"Spectate the encounter",color:"yellow"}}}]

# Sound
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.experience_orb.pickup player @s ~ ~ ~ 1 1.0
