# Encounter Cam — Send spectate invite (macro)
# Arg: pid
$execute as @a[scores={ec.party_id=$(pid)},tag=!sp.spectating] run function evercraft:spectator/invite/show
