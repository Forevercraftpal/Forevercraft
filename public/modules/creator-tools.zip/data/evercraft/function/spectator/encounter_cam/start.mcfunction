# Encounter Cam — Start Spectating
# Locks player as spectator to the nearest active encounter
# @s = player requesting spectate mode

# Tag as spectating BEFORE the bossbar audience query, so @s is in the group selector
tag @s add sp.spectating

# Save return position via shared utility
scoreboard players set @s ec.tp_ret_sys 7
execute at @s run function evercraft:tp_safety/save

# Capture current gamemode so exit restores it (not a hardcoded survival)
# Shared sp.was_* tag-set with invite/accept + codex_spectator
tag @s remove sp.was_creative
tag @s remove sp.was_adventure
tag @s remove sp.was_spectator
tag @s add sp.was_creative
execute unless entity @s[gamemode=creative] run tag @s remove sp.was_creative
execute if entity @s[gamemode=adventure] run tag @s add sp.was_adventure
execute if entity @s[gamemode=spectator] run tag @s add sp.was_spectator

# Switch to spectator mode
gamemode spectator @s

# Set up encounter bossbar overlay — group audience so multi-spectate doesn't replace
bossbar set evercraft:encounter_cam players @a[tag=sp.spectating]
bossbar set evercraft:encounter_cam visible true
bossbar set evercraft:encounter_cam color yellow
bossbar set evercraft:encounter_cam name {text:"Spectating Encounter",color:"gold"}

scoreboard players set @s sp.active 1

data modify storage evercraft:notify stage.c set value [{text:"\u2726 ",color:"gold"},{text:"Spectator Mode: ON",color:"white",bold:true},{text:" \u2726",color:"gold"}]
scoreboard players set #ndur ec.temp 50
function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Sneak to exit spectator mode",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit

execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.beacon.activate master @s ~ ~ ~ 0.5 1.5

# Send party invite to spectate
execute if score @s ec.party_id matches 1.. run function evercraft:spectator/invite/send
