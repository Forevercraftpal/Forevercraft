# Encounter Cam — Stop Spectating
# Restores player to survival mode
# @s = spectating player

# Restore to saved position before switching gamemode
function evercraft:tp_safety/restore

# Restore the gamemode captured on entry (default survival), then clear the markers
gamemode survival @s
execute if entity @s[tag=sp.was_creative] run gamemode creative @s
execute if entity @s[tag=sp.was_adventure] run gamemode adventure @s
execute if entity @s[tag=sp.was_spectator] run gamemode spectator @s
tag @s remove sp.was_creative
tag @s remove sp.was_adventure
tag @s remove sp.was_spectator
tag @s remove sp.spectating
scoreboard players set @s sp.active 0

# Hide bossbar
bossbar set evercraft:encounter_cam visible false
bossbar set evercraft:encounter_cam players

data modify storage evercraft:notify stage.c set value [{text:"\u2726 ",color:"green"},{text:"Spectator Mode: OFF",color:"white",bold:true},{text:" \u2726",color:"green"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit

execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.beacon.deactivate master @s ~ ~ ~ 0.5 1.0
