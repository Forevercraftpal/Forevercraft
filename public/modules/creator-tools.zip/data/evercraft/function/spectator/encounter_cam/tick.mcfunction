# Encounter Cam — Tick
# Monitors spectating player and auto-exits when encounter ends or player sneaks
# @s = spectating player (tag sp.spectating)

# Exit on sneak
execute if predicate evercraft:sneaking run function evercraft:spectator/encounter_cam/stop

# Auto-exit if encounter ends (no active raid/castle/dungeon/world boss in range)
# 4-tag set, raid first as the dominant use case (Council #13 fix — sr.boss was archived Council #8)
execute unless entity @e[type=!player,tag=ec.rd_boss,distance=..100] unless entity @e[type=!player,tag=ic.boss,distance=..100] unless entity @e[type=!player,tag=dg.boss,distance=..100] unless entity @e[type=!player,tag=wb.boss,distance=..100] run function evercraft:spectator/encounter_cam/stop
