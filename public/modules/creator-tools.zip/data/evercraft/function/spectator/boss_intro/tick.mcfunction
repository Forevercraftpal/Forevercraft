# Boss Intro — Tick
# Handles the timed title card sequence
# Called from main tick when sp.intro_phase > 0

# Count down
scoreboard players remove @s sp.intro_timer 1

# Phase 1: Darkness → Title card at timer 0
execute if score @s sp.intro_phase matches 1 if score @s sp.intro_timer matches 0 run function evercraft:spectator/boss_intro/show_title
execute if score @s sp.intro_phase matches 1 if score @s sp.intro_timer matches 0 run scoreboard players set @s sp.intro_phase 2
execute if score @s sp.intro_phase matches 1 if score @s sp.intro_timer matches 0 run scoreboard players set @s sp.intro_timer 60

# Phase 2: Title display → Fade out at timer 0
execute if score @s sp.intro_phase matches 2 if score @s sp.intro_timer matches 0 run scoreboard players set @s sp.intro_phase 0
execute if score @s sp.intro_phase matches 2 if score @s sp.intro_timer matches 0 run effect clear @s slowness
