# Boss Intro — Show Title Card
# Displays the boss name as a dramatic title
# Boss name should be in storage evercraft:spectator boss.name and boss.subtitle

title @s times 10 40 20
title @s title {text:""}
execute if data storage evercraft:spectator boss run function evercraft:spectator/boss_intro/show_title_macro with storage evercraft:spectator boss

execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.end_portal.spawn master @s ~ ~ ~ 0.6 0.5
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:item.trident.thunder master @s ~ ~ ~ 0.4 0.3
