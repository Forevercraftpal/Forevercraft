# Boss Intro — Show Title Macro
# $(name) = boss name, $(subtitle) = boss title/epithet

# (AB-1 sticky-times sweep 2026-06-10: explicit stamp — `title times` is sticky per player and this sequence set none, so it inherited whatever ran last.)
title @s times 10 60 20
$title @s title {text:"$(name)",color:"red",bold:true}
$title @s subtitle {text:"$(subtitle)",color:"dark_red",italic:true}
