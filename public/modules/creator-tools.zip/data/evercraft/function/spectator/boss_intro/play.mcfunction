# Boss Intro — Play Cinematic
# Elden Ring-style title card for raid bosses
# @s = all participants in the raid, boss name in storage
# Called from raid boss spawn functions

# Freeze player movement briefly
effect give @s slowness 3 255 true
effect give @s blindness 1 0 true

# Schedule the title card after 1 second of darkness
scoreboard players set @s sp.intro_phase 1
scoreboard players set @s sp.intro_timer 20

# Play dramatic sound
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:ambient.cave master @s ~ ~ ~ 1.0 0.3
