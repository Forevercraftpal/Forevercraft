# Spectator & Cinematic Systems — Load
# Plan 7: Boss intros, encounter cam, spectator overlays, observer mode

# === SCOREBOARDS ===
scoreboard objectives add sp.active dummy
scoreboard objectives add sp.intro_phase dummy
scoreboard objectives add sp.intro_timer dummy

# Spectate trigger — solo entry to encounter cam (Council #13 2026-05-28)
scoreboard objectives add ec.spectate trigger
scoreboard players enable @a ec.spectate

# TP join trigger (party spectate invites for encounter cam / dreaming realm)
scoreboard objectives add ec.tp_join trigger
scoreboard players enable @a ec.tp_join

# === BOSSBARS ===
# Encounter cam overlay (Council #13 2026-05-28 — was never `add`'d; all `set` calls silently no-op'd)
bossbar add evercraft:encounter_cam {text:"Encounter",color:"gold"}
