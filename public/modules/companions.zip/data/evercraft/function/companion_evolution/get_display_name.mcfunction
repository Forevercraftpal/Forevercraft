# Map pet signature to display name for the Ascended title
# Reads from storage evercraft:ce temp.pet_name (signature)
# Writes to storage evercraft:ce temp.display_name (title-case display name)
# Only maps renamed pets — others use the signature as-is with title case

# === Original 6 with abilities (renamed signatures) ===
execute if data storage evercraft:ce {temp:{pet_name:"blue_dragon"}} run data modify storage evercraft:ce temp.display_name set value "Endwalker"
execute if data storage evercraft:ce {temp:{pet_name:"red_dragon"}} run data modify storage evercraft:ce temp.display_name set value "Ashborn"
execute if data storage evercraft:ce {temp:{pet_name:"phoenix"}} run data modify storage evercraft:ce temp.display_name set value "Emberheart"
execute if data storage evercraft:ce {temp:{pet_name:"reaper"}} run data modify storage evercraft:ce temp.display_name set value "Wraith"
execute if data storage evercraft:ce {temp:{pet_name:"warden"}} run data modify storage evercraft:ce temp.display_name set value "Monolith"
execute if data storage evercraft:ce {temp:{pet_name:"tiger"}} run data modify storage evercraft:ce temp.display_name set value "Sabertooth"

# === Mythicals that need mapping (multi-word or renamed) ===
execute if data storage evercraft:ce {temp:{pet_name:"arctic_fox"}} run data modify storage evercraft:ce temp.display_name set value "Arctic Fox"
execute if data storage evercraft:ce {temp:{pet_name:"copper_golem"}} run data modify storage evercraft:ce temp.display_name set value "Copper Golem"
execute if data storage evercraft:ce {temp:{pet_name:"cow_of_eden"}} run data modify storage evercraft:ce temp.display_name set value "Cow of Eden"
execute if data storage evercraft:ce {temp:{pet_name:"golden_dragon"}} run data modify storage evercraft:ce temp.display_name set value "Golden Dragon"
execute if data storage evercraft:ce {temp:{pet_name:"iron_golem"}} run data modify storage evercraft:ce temp.display_name set value "Iron Golem"
execute if data storage evercraft:ce {temp:{pet_name:"red_panda"}} run data modify storage evercraft:ce temp.display_name set value "Red Panda"
execute if data storage evercraft:ce {temp:{pet_name:"regal_tiger"}} run data modify storage evercraft:ce temp.display_name set value "Regal Tiger"
execute if data storage evercraft:ce {temp:{pet_name:"skeleton_horse"}} run data modify storage evercraft:ce temp.display_name set value "Skeleton Horse"
execute if data storage evercraft:ce {temp:{pet_name:"snow_fox_spirit"}} run data modify storage evercraft:ce temp.display_name set value "Snow Fox Spirit"
execute if data storage evercraft:ce {temp:{pet_name:"spirit_wolf"}} run data modify storage evercraft:ce temp.display_name set value "Spirit Wolf"
execute if data storage evercraft:ce {temp:{pet_name:"time_weaver"}} run data modify storage evercraft:ce temp.display_name set value "Time Weaver"
execute if data storage evercraft:ce {temp:{pet_name:"void_walker"}} run data modify storage evercraft:ce temp.display_name set value "Void Walker"

# === Single-word mythicals (title case = capitalize first letter) ===
execute if data storage evercraft:ce {temp:{pet_name:"butterfly"}} run data modify storage evercraft:ce temp.display_name set value "Butterfly"
execute if data storage evercraft:ce {temp:{pet_name:"claude"}} run data modify storage evercraft:ce temp.display_name set value "Claude"
execute if data storage evercraft:ce {temp:{pet_name:"deloris"}} run data modify storage evercraft:ce temp.display_name set value "Deloris"
execute if data storage evercraft:ce {temp:{pet_name:"leviathan"}} run data modify storage evercraft:ce temp.display_name set value "Leviathan"
execute if data storage evercraft:ce {temp:{pet_name:"moobloom"}} run data modify storage evercraft:ce temp.display_name set value "Moobloom"
execute if data storage evercraft:ce {temp:{pet_name:"panther"}} run data modify storage evercraft:ce temp.display_name set value "Panther"
execute if data storage evercraft:ce {temp:{pet_name:"vex"}} run data modify storage evercraft:ce temp.display_name set value "Vex"
execute if data storage evercraft:ce {temp:{pet_name:"wither"}} run data modify storage evercraft:ce temp.display_name set value "Wither"

# === Gacha Mythicals ===
execute if data storage evercraft:ce {temp:{pet_name:"dreamstag"}} run data modify storage evercraft:ce temp.display_name set value "Dreamstag"
execute if data storage evercraft:ce {temp:{pet_name:"starweaver"}} run data modify storage evercraft:ce temp.display_name set value "Starweaver"
execute if data storage evercraft:ce {temp:{pet_name:"somnia"}} run data modify storage evercraft:ce temp.display_name set value "Somnia"

# === Gacha Exquisites ===
execute if data storage evercraft:ce {temp:{pet_name:"lunar_moth"}} run data modify storage evercraft:ce temp.display_name set value "Lunar Moth"
execute if data storage evercraft:ce {temp:{pet_name:"nebula_kit"}} run data modify storage evercraft:ce temp.display_name set value "Nebula Kit"
execute if data storage evercraft:ce {temp:{pet_name:"twilight_hare"}} run data modify storage evercraft:ce temp.display_name set value "Twilight Hare"
execute if data storage evercraft:ce {temp:{pet_name:"grovekeeper"}} run data modify storage evercraft:ce temp.display_name set value "Grovekeeper"
execute if data storage evercraft:ce {temp:{pet_name:"infernus"}} run data modify storage evercraft:ce temp.display_name set value "Infernus"
execute if data storage evercraft:ce {temp:{pet_name:"crystalheart"}} run data modify storage evercraft:ce temp.display_name set value "Crystalheart"
execute if data storage evercraft:ce {temp:{pet_name:"stormcaller"}} run data modify storage evercraft:ce temp.display_name set value "Stormcaller"
execute if data storage evercraft:ce {temp:{pet_name:"voidshade"}} run data modify storage evercraft:ce temp.display_name set value "Voidshade"
