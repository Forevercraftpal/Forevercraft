# Ceremony aborted — companion entity despawned during evolution
# Run as the evolving player
# The bitfield is already set, so the evolution IS recorded.
# But the entity didn't get evolved:true or the Ascended name.
# On next summon, on_summon won't find evolved:true → no ability tags.
# Fix: revert the bitfield since the evolution didn't complete.

execute if score #ce_use_bf2 ec.ce_temp matches 0 run scoreboard players operation @s ec.ce_evolved -= #ce_bit ec.ce_temp
execute if score #ce_use_bf2 ec.ce_temp matches 1 run scoreboard players operation @s ec.ce_evolved2 -= #ce_bit ec.ce_temp

effect clear @s darkness
tag @s remove ce.evolving
scoreboard players set @s ec.ce_phase 0
tellraw @s [{"text":"[Forevercraft] ","color":"gold"},{"text":"Evolution interrupted! Your companion was lost. The Spirit Treat was consumed.","color":"red"}]
