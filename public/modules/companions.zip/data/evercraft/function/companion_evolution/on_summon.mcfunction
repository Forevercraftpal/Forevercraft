# Check if summoned companion is an evolved form and set appropriate tags
# Run as player after companion is summoned

# Clear ALL evolution tags first
tag @s remove ce.evolved_active
tag @s remove ce.evo_endwalker
tag @s remove ce.evo_ashborn
tag @s remove ce.evo_emberheart
tag @s remove ce.evo_wraith
tag @s remove ce.evo_monolith
tag @s remove ce.evo_sabertooth
tag @s remove ce.evo_arctic_fox
tag @s remove ce.evo_butterfly
tag @s remove ce.evo_claude
tag @s remove ce.evo_copper_golem
tag @s remove ce.evo_cow_of_eden
tag @s remove ce.evo_deloris
tag @s remove ce.evo_golden_dragon
tag @s remove ce.evo_iron_golem
tag @s remove ce.evo_leviathan
tag @s remove ce.evo_moobloom
tag @s remove ce.evo_panther
tag @s remove ce.evo_red_panda
tag @s remove ce.evo_regal_tiger
tag @s remove ce.evo_skeleton_horse
tag @s remove ce.evo_snow_fox_spirit
tag @s remove ce.evo_spirit_wolf
tag @s remove ce.evo_time_weaver
tag @s remove ce.evo_vex
tag @s remove ce.evo_void_walker
tag @s remove ce.evo_wither
tag @s remove ce.evo_dreamstag
tag @s remove ce.evo_starweaver
tag @s remove ce.evo_somnia
tag @s remove ce.evo_lunar_moth
tag @s remove ce.evo_nebula_kit
tag @s remove ce.evo_twilight_hare
tag @s remove ce.evo_grovekeeper
tag @s remove ce.evo_infernus
tag @s remove ce.evo_crystalheart
tag @s remove ce.evo_stormcaller
tag @s remove ce.evo_voidshade

# Also clear attribute modifiers from previous evolved pet
attribute @s luck modifier remove evercraft:dreamdust
attribute @s luck modifier remove evercraft:forage_luck
attribute @s luck modifier remove evercraft:deep_scan
attribute @s attack_damage modifier remove evercraft:moonbeam

# Check if the active companion has evolved:true in custom_data
scoreboard players operation #Search companion.id = @s companion.id
execute unless entity @e[type=item_display, tag=Companion, predicate=evercraft:companions/check_id, nbt={item:{components:{"minecraft:custom_data":{evolved:true}}}}, limit=1] run return 0

# Companion is evolved — set generic tag + specific tag via macro
tag @s add ce.evolved_active

# Read pet_name from custom_data and route to tag assignment
data modify storage evercraft:ce temp.pet_name set from entity @e[type=item_display, tag=Companion, predicate=evercraft:companions/check_id, limit=1] item.components."minecraft:custom_data".pet_name
function evercraft:companion_evolution/assign_tag
