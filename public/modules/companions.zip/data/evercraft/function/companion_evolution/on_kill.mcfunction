# Evolved companion on-kill dispatch
# Called when a player with an evolved companion kills a mob
# Run as the player who got the kill

# Golden Dragon — Midas Touch (10% gold nugget drop)
execute if entity @s[tag=ce.evo_golden_dragon] run function evercraft:companion_evolution/abilities/golden_dragon_on_kill

# Regal Tiger — Apex Rush (Speed II for 3s)
execute if entity @s[tag=ce.evo_regal_tiger] run function evercraft:companion_evolution/abilities/regal_tiger_on_kill
