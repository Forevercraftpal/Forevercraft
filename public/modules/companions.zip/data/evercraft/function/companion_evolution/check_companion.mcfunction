# Check individual companion entity for evolution eligibility
# Run as the companion item_display entity
# Sets #ce_eligible ec.ce_temp to 1 if all requirements met

scoreboard players set #ce_eligible ec.ce_temp 0
scoreboard players set #ce_use_bf2 ec.ce_temp 0

# Read pet signature name into storage for identification
data modify storage evercraft:ce temp.pet_name set from entity @s item.components."minecraft:profile".properties[{name:"name"}].value

# Read level from profile property [2]
data modify storage evercraft:companions math.string set string entity @s item.components."minecraft:profile".properties[2].value
function evercraft:companions/handler/math/string_to_int
scoreboard players operation #ce_level ec.ce_temp = #value companion.calc

# Check: Level must be 100
execute unless score #ce_level ec.ce_temp matches 100 run return run function evercraft:companion_evolution/fail_level

# Read relationship from profile property [4]
data modify storage evercraft:companions math.string set string entity @s item.components."minecraft:profile".properties[4].value
function evercraft:companions/handler/math/string_to_int
scoreboard players operation #ce_rp ec.ce_temp = #value companion.calc

# Check: Relationship must be 4500+ (Eternal Bond)
execute unless score #ce_rp ec.ce_temp matches 4500.. run return run function evercraft:companion_evolution/fail_bond

# Check: Must be evolvable — sets #ce_bit and optionally #ce_use_bf2
execute store success score #ce_is_mythical ec.ce_temp run function evercraft:companion_evolution/check_mythical

execute if score #ce_is_mythical ec.ce_temp matches 0 run return run function evercraft:companion_evolution/fail_not_mythical

# Check: Not already evolved (check correct bitfield)
# Use ec.ce_evolved2 if #ce_use_bf2 is set, otherwise ec.ce_evolved
execute if score #ce_use_bf2 ec.ce_temp matches 0 as @a[predicate=evercraft:companions/check_id, distance=..16, limit=1] run scoreboard players operation #ce_check ec.ce_temp = @s ec.ce_evolved
execute if score #ce_use_bf2 ec.ce_temp matches 1 as @a[predicate=evercraft:companions/check_id, distance=..16, limit=1] run scoreboard players operation #ce_check ec.ce_temp = @s ec.ce_evolved2
scoreboard players operation #ce_check ec.ce_temp /= #ce_bit ec.ce_temp
scoreboard players operation #ce_check ec.ce_temp %= #2 companion.calc
execute if score #ce_check ec.ce_temp matches 1 run return run function evercraft:companion_evolution/fail_already_evolved

# All checks passed!
scoreboard players set #ce_eligible ec.ce_temp 1
