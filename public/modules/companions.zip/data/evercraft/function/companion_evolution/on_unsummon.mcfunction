# Clear all evolution tags and attribute modifiers on unsummon
# Run as player

# Remove all evo tags
tag @s remove ce.evolved_active
tag @s remove ce.evo_endwalker
tag @s remove ce.evo_ashborn
tag @s remove ce.evo_emberheart
tag @s remove ce.evo_wraith
tag @s remove ce.evo_monolith
tag @s remove ce.evo_sabertooth
tag @s remove ce.evo_arctic_fox
tag @s remove ce.evo_butterfly
tag @s remove ce.evo_claude
tag @s remove ce.evo_copper_golem
tag @s remove ce.evo_cow_of_eden
tag @s remove ce.evo_deloris
tag @s remove ce.evo_golden_dragon
tag @s remove ce.evo_iron_golem
tag @s remove ce.evo_leviathan
tag @s remove ce.evo_moobloom
tag @s remove ce.evo_panther
tag @s remove ce.evo_red_panda
tag @s remove ce.evo_regal_tiger
tag @s remove ce.evo_skeleton_horse
tag @s remove ce.evo_snow_fox_spirit
tag @s remove ce.evo_spirit_wolf
tag @s remove ce.evo_time_weaver
tag @s remove ce.evo_vex
tag @s remove ce.evo_void_walker
tag @s remove ce.evo_wither
tag @s remove ce.evo_dreamstag
tag @s remove ce.evo_starweaver
tag @s remove ce.evo_somnia
tag @s remove ce.evo_lunar_moth
tag @s remove ce.evo_nebula_kit
tag @s remove ce.evo_twilight_hare
tag @s remove ce.evo_grovekeeper
tag @s remove ce.evo_infernus
tag @s remove ce.evo_crystalheart
tag @s remove ce.evo_stormcaller
tag @s remove ce.evo_voidshade

# Clear evolved ability attribute modifiers
attribute @s luck modifier remove evercraft:dreamdust
attribute @s luck modifier remove evercraft:forage_luck
attribute @s luck modifier remove evercraft:deep_scan
attribute @s attack_damage modifier remove evercraft:moonbeam

# Reset ability state scores
scoreboard players set @s ec.ce_cd 0
scoreboard players set @s ec.ce_hit_count 0
scoreboard players set @s ec.ce_idle 0
scoreboard players set @s ec.ce_stealth 0
scoreboard players set @s ec.ce_inferno_cd 0
