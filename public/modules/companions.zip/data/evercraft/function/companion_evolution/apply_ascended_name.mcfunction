# Apply "Ascended" prefix to companion's display name
# Run as the evolving companion item_display entity

# Map signature to display name
function evercraft:companion_evolution/get_display_name

# Use the display name in the Ascended title macro
function evercraft:companion_evolution/set_ascended_name with storage evercraft:ce temp
