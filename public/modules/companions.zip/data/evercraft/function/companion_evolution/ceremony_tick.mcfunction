# Evolution ceremony tick — self-scheduling every tick during any ceremony
# Per-player: ec.ce_phase tracks each player's ceremony progress independently

# Early exit if nobody is evolving
execute unless entity @a[tag=ce.evolving] run return 0

# Process each evolving player independently
execute as @a[tag=ce.evolving] run function evercraft:companion_evolution/ceremony_player

# Continue scheduling while any ceremony is active
execute if entity @a[tag=ce.evolving] run schedule function evercraft:companion_evolution/ceremony_tick 1t
