# Sync evolved companion data back to the marker database
# Run as the player who just evolved their companion

scoreboard players operation #Search companion.id = @s companion.id

# Copy updated item from active companion entity to the marker's Pets[] at the active slot
# The companion entity already has the updated name, glint, and evolved custom_data
# Use the existing store_companion pattern to overwrite the slot
execute as @e[type=item_display, tag=Companion, predicate=evercraft:companions/check_id, limit=1] run function evercraft:companions/handler/database/store_companion
