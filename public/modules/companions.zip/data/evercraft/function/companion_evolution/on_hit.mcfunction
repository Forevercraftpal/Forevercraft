# Evolved companion on-hit dispatch
# Called when a player with an evolved companion deals melee damage
# Run as the attacking player

# On-attack abilities (player just hit something)
execute if entity @s[tag=ce.evo_panther] run function evercraft:companion_evolution/abilities/panther_pounce
execute if entity @s[tag=ce.evo_starweaver] run function evercraft:companion_evolution/abilities/starweaver_burst
execute if entity @s[tag=ce.evo_infernus] run function evercraft:companion_evolution/abilities/infernus_hellfire
execute if entity @s[tag=ce.evo_stormcaller] run function evercraft:companion_evolution/abilities/stormcaller_chain

# Voidshade stealth-break bonus: +3 damage if attacking from stealth
execute if entity @s[tag=ce.evo_voidshade,scores={ec.ce_stealth=1}] at @s as @e[type=!player,distance=..5,limit=1,sort=nearest,nbt={HurtTime:10s}] run damage @s 3 minecraft:player_attack
execute if entity @s[tag=ce.evo_voidshade,scores={ec.ce_stealth=1}] run scoreboard players set @s ec.ce_stealth 0
execute if entity @s[tag=ce.evo_voidshade,scores={ec.ce_stealth=1}] run tellraw @s [{"text":"[Forevercraft] ","color":"gold"},{"text":"Shadow Strike! ","color":"dark_purple"},{"text":"+3 bonus damage!","color":"red"}]

# Reset panther idle counter on any attack
execute if entity @s[tag=ce.evo_panther] run scoreboard players set @s ec.ce_idle 0
