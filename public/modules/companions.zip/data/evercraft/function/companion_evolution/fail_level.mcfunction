# Evolution failed — companion not Level 100
# Run as companion entity, player is nearby

execute as @a[predicate=evercraft:companions/check_id, distance=..16, limit=1] run tellraw @s [{text:"[Forevercraft] ",color:"gold"},{text:"Your companion must be ",color:"gray"},{text:"Level 100",color:"red"},{text:" to evolve. Current: ",color:"gray"},{score:{name:"#ce_level",objective:"ec.ce_temp"},color:"yellow"},{text:".",color:"gray"}]
