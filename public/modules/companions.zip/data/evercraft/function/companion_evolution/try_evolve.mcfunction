# Attempt to evolve the active companion with Spirit Treat
# Run as player who right-clicked their companion while holding Spirit Treat

# Run eligibility checks
execute store success score #ce_can_evolve ec.ce_temp run function evercraft:companion_evolution/check

# If checks failed, messages already sent by fail functions — just return
execute if score #ce_can_evolve ec.ce_temp matches 0 run return 0

# All requirements met! Consume Spirit Treat and begin evolution ceremony
clear @s *[custom_data~{spirit_treat:true}] 1

# Mark the evolution bitfield on the player (use correct bitfield)
execute if score #ce_use_bf2 ec.ce_temp matches 0 run scoreboard players operation @s ec.ce_evolved += #ce_bit ec.ce_temp
execute if score #ce_use_bf2 ec.ce_temp matches 1 run scoreboard players operation @s ec.ce_evolved2 += #ce_bit ec.ce_temp

# Map signature to display name + store for announcement
function evercraft:companion_evolution/get_display_name
data modify storage evercraft:ce evolving.pet_name set from storage evercraft:ce temp.display_name

# Tag player for evolution ceremony tracking
tag @s add ce.evolving

# Store companion entity position for particles
scoreboard players operation #Search companion.id = @s companion.id
execute as @e[type=item_display, tag=Companion, predicate=evercraft:companions/check_id, limit=1] run function evercraft:companion_evolution/store_pet_pos

# Begin Phase 1: Darkness
scoreboard players set @s ec.ce_phase 1
scoreboard players set #ce_timer ec.ce_temp 0

# Apply darkness effect
effect give @s darkness 2 0 true

# Play ominous sound
playsound minecraft:entity.warden.heartbeat master @s ~ ~ ~ 1 0.5

# Schedule the ceremony tick
schedule function evercraft:companion_evolution/ceremony_tick 1t
