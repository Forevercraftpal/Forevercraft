# Evolution failed — companion is not evolvable
# Run as companion entity, player is nearby

execute as @a[predicate=evercraft:companions/check_id, distance=..16, limit=1] run tellraw @s [{"text":"[Forevercraft] ","color":"gold"},{"text":"This companion cannot evolve. Only ","color":"gray"},{"text":"Mythical","color":"light_purple"},{"text":" tier companions (and Endwalker, Ashborn, Sabertooth) can ascend.","color":"gray"}]
