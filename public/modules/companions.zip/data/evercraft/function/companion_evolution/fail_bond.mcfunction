# Evolution failed — companion doesn't have Eternal Bond
# Run as companion entity, player is nearby

execute as @a[predicate=evercraft:companions/check_id, distance=..16, limit=1] run tellraw @s [{text:"[Forevercraft] ",color:"gold"},{text:"Your companion must have ",color:"gray"},{text:"Eternal Bond",color:"light_purple"},{text:" (4500+ RP) to evolve. Current: ",color:"gray"},{score:{name:"#ce_rp",objective:"ec.ce_temp"},color:"yellow"},{text:" RP.",color:"gray"}]
