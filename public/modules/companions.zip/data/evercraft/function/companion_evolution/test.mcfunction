# Test function for companion evolution
# /function evercraft:companion_evolution/test
# Gives player a Spirit Treat and shows evolution status

# Give Spirit Treat
loot give @s loot evercraft:cooking/treats/spirit_treat

# Show current evolution bitfield
tellraw @s [{text:"[CE Test] ",color:"gold"},{text:"Evolution bitfield: ",color:"gray"},{score:{name:"@s",objective:"ec.ce_evolved"},color:"yellow"}]
tellraw @s [{text:"[CE Test] ",color:"gold"},{text:"Spirit Treat given. Right-click your Lv100 Eternal Bond mythical companion to evolve.",color:"gray"}]
