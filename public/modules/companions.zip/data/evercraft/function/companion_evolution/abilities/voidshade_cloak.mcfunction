# Voidshade — Shadow Cloak
# Passive: Invisibility underground OR at night. Breaking stealth with attack = +3 bonus dmg.
# Run as player with ce.evo_voidshade tag

# Stealth activates underground (Y < 55) OR at night (visual_time 13000-23000)
scoreboard players set #ce_in_shadow ec.ce_temp 0
execute if predicate evercraft:companions/underground run scoreboard players set #ce_in_shadow ec.ce_temp 1
execute if score #visual_time ec.var matches 13000..23000 run scoreboard players set #ce_in_shadow ec.ce_temp 1

# Apply invisibility if in shadow
execute if score #ce_in_shadow ec.ce_temp matches 1 run effect give @s invisibility 2 0 true
execute if score #ce_in_shadow ec.ce_temp matches 1 run scoreboard players set @s ec.ce_stealth 1

# Clear stealth if in light
execute if score #ce_in_shadow ec.ce_temp matches 0 run scoreboard players set @s ec.ce_stealth 0

# Ambient particles when stealthed
execute if score @s ec.ce_stealth matches 1 run scoreboard players operation #Search companion.id = @s companion.id
execute if score @s ec.ce_stealth matches 1 as @e[type=item_display, tag=Companion, predicate=evercraft:companions/check_id, limit=1] at @s run particle dust{color:[0.2,0.0,0.3],scale:0.6} ~ ~0.3 ~ 0.15 0.15 0.15 0.01 1
