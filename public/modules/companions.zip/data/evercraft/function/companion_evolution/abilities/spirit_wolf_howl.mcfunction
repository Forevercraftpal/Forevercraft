# Spirit Wolf — Howl of the Pack
# Triggered: Sneak+click. All players within 16 blocks gain Strength I + Speed I for 15s. 90s CD.
# Run as player

execute if score @s ec.ce_cd matches 1.. run tellraw @s [{"text":"[Forevercraft] ","color":"gold"},{"text":"Howl of the Pack recharging.","color":"gray"}]
execute if score @s ec.ce_cd matches 1.. run return 0

scoreboard players set @s ec.ce_cd 1800
execute at @s run effect give @a[distance=..16] strength 15 0 true
execute at @s run effect give @a[distance=..16] speed 15 0 true
execute at @s run particle soul ~ ~1 ~ 5 2 5 0.05 20
playsound minecraft:entity.wolf_puglin.ambient master @a ~ ~ ~ 1.5 0.6
tellraw @a[distance=..16] [{"text":"[Forevercraft] ","color":"gold"},{"text":"The Spirit Wolf howls! ","color":"light_purple"},{"text":"Strength I + Speed I for 15s!","color":"green"}]
