# Deloris — Dramatic Entrance
# Triggered: Sneak+click companion. Slowness II + Weakness I to all mobs within 12 blocks. 60s CD.
# Run as player

execute if score @s ec.ce_cd matches 1.. run tellraw @s [{"text":"[Forevercraft] ","color":"gold"},{"text":"Dramatic Entrance recharging.","color":"gray"}]
execute if score @s ec.ce_cd matches 1.. run return 0

scoreboard players set @s ec.ce_cd 1200
execute at @s as @e[type=!player,type=!#evercraft:passive,distance=..12,tag=!Pet,tag=!Companion] run effect give @s slowness 5 1 true
execute at @s as @e[type=!player,type=!#evercraft:passive,distance=..12,tag=!Pet,tag=!Companion] run effect give @s weakness 5 0 true
execute at @s run particle angry_villager ~ ~1 ~ 4 1 4 0.5 15
playsound minecraft:entity.llama.spit master @s ~ ~ ~ 1 0.6
playsound minecraft:entity.ravager.roar master @a ~ ~ ~ 0.5 1.2
tellraw @s [{"text":"[Forevercraft] ","color":"gold"},{"text":"Dramatic Entrance! ","color":"yellow"},{"text":"Nearby enemies stunned!","color":"gray"}]
