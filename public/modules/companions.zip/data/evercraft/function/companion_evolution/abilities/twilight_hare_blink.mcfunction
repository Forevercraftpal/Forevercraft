# Twilight Hare — Blink Dodge (on player hurt)
# 15% chance to TP 4 blocks backward + Speed II (2s). 5s internal CD.
# Run as player who was just hit

execute if score @s ec.ce_cd matches 1.. run return 0
execute store result score #ce_roll ec.ce_temp run random value 1..100
execute unless score #ce_roll ec.ce_temp matches 1..15 run return 0

scoreboard players set @s ec.ce_cd 100

# Teleport 4 blocks backward (opposite of look direction)
execute at @s anchored eyes run tp @s ^ ^ ^-4

effect give @s speed 2 1 true
execute at @s run particle witch ~ ~1 ~ 0.3 0.3 0.3 0.1 10
playsound minecraft:entity.enderman.teleport master @s ~ ~ ~ 0.5 1.5
