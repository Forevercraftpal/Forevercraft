# Leviathan — Tidal Surge
# Triggered: Sneak+click companion. Pushes entities 8 blocks with Levitation. 45s CD.
# Run as player

execute if score @s ec.ce_cd matches 1.. run tellraw @s [{"text":"[Forevercraft] ","color":"gold"},{"text":"Tidal Surge recharging.","color":"gray"}]
execute if score @s ec.ce_cd matches 1.. run return 0

scoreboard players set @s ec.ce_cd 900
execute at @s as @e[type=!player,distance=..8,tag=!Pet,tag=!Companion] run effect give @s levitation 1 1 true
execute at @s run particle bubble ~ ~0.5 ~ 3 1 3 0.5 30
execute at @s run particle splash ~ ~0.5 ~ 3 0.5 3 0.3 20
playsound minecraft:entity.elder_guardian.curse master @s ~ ~ ~ 0.8 0.8
tellraw @s [{"text":"[Forevercraft] ","color":"gold"},{"text":"Tidal Surge! ","color":"aqua"},{"text":"Enemies swept away!","color":"gray"}]
