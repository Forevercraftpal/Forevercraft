# Time Weaver — Temporal Rewind
# Triggered: Sneak+click. Restores HP to stored value (saved every 5s). 120s CD.
# Run as player

execute if score @s ec.ce_cd matches 1.. run tellraw @s [{"text":"[Forevercraft] ","color":"gold"},{"text":"Temporal Rewind recharging.","color":"gray"}]
execute if score @s ec.ce_cd matches 1.. run return 0

# Check if we have stored HP
execute if score @s ec.ce_stored_hp matches ..0 run tellraw @s [{"text":"[Forevercraft] ","color":"gold"},{"text":"No temporal snapshot available yet.","color":"gray"}]
execute if score @s ec.ce_stored_hp matches ..0 run return 0

scoreboard players set @s ec.ce_cd 2400

# Restore HP via two-step (store to storage, then data modify)
execute store result storage evercraft:ce temp.restore_hp float 1 run scoreboard players get @s ec.ce_stored_hp
data modify entity @s Health set from storage evercraft:ce temp.restore_hp

execute at @s run particle portal ~ ~1 ~ 0.3 0.5 0.3 0.5 30
execute at @s run particle reverse_portal ~ ~1 ~ 0.3 0.5 0.3 0.5 20
playsound minecraft:block.respawn_anchor.charge master @s ~ ~ ~ 1 1.5
tellraw @s [{"text":"[Forevercraft] ","color":"gold"},{"text":"Temporal Rewind! ","color":"aqua"},{"text":"Health restored to 5 seconds ago.","color":"gray"}]
