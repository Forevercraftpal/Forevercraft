# Regal Tiger — Apex Rush
# On kill: Speed II for 3s. Handled by on_kill hook.
# This tick function just provides ambient particles.
scoreboard players operation #Search companion.id = @s companion.id
execute as @e[type=item_display, tag=Companion, predicate=evercraft:companions/check_id, limit=1] at @s run particle dust{color:[1.0,0.5,0.0],scale:0.6} ~ ~0.3 ~ 0.1 0.1 0.1 0.01 1
