# Grovekeeper — Nature's Embrace
# Passive: Standing still for 3s triggers Regen II. Moving cancels.
# Run as player with ce.evo_grovekeeper tag

# Check if player moved (using shared movement detection ec.moving)
execute if score @s ec.moving matches 1.. run scoreboard players set @s ec.ce_idle 0
execute if score @s ec.moving matches 0 run scoreboard players add @s ec.ce_idle 1

# After 3 idle cycles (3 seconds at 1s movement tick), grant Regen II
execute if score @s ec.ce_idle matches 3.. run effect give @s regeneration 3 1 true
execute if score @s ec.ce_idle matches 3.. at @s run particle happy_villager ~ ~0.5 ~ 0.3 0.2 0.3 0.01 3
