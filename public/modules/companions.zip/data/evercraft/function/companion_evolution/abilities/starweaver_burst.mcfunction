# Starweaver — Constellation Burst (on player attack)
# Every 10th hit: 6 damage AoE + Glowing 5s to all mobs in 5 blocks
# Run as player who just attacked

scoreboard players add @s ec.ce_hit_count 1
execute unless score @s ec.ce_hit_count matches 10.. run return 0

# Burst!
scoreboard players set @s ec.ce_hit_count 0
execute at @s as @e[type=!player,distance=..5,tag=!Pet,tag=!Companion] run damage @s 6 minecraft:magic
execute at @s as @e[type=!player,distance=..5,tag=!Pet,tag=!Companion] run effect give @s glowing 5 0 true

execute at @s run particle end_rod ~ ~1 ~ 2 1 2 0.1 30
execute at @s run particle enchant ~ ~1 ~ 2 1 2 1 20
playsound minecraft:entity.firework_rocket.twinkle master @s ~ ~ ~ 1 1.2
tellraw @s [{"text":"[Forevercraft] ","color":"gold"},{"text":"\u2726 Constellation Burst! \u2726","color":"yellow"}]
