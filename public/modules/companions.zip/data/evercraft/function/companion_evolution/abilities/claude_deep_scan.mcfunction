# Claude — Deep Scan
# Passive: Doubles ore sight range. Applies Glowing to ore-adjacent mobs for visibility.
# Run as player with ce.evo_claude tag
# The base Claude ability sets scan range 8-23 blocks via attribute.
# Evolved: we add +100% range modifier

attribute @s luck modifier add evercraft:deep_scan 1.0 add_multiplied_base
