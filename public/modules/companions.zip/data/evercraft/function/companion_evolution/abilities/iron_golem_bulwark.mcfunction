# Iron Golem — Iron Bulwark
# Passive: Resistance scales with HP threshold
# Run as player with ce.evo_iron_golem tag

# Get current HP percentage
execute store result score #ce_hp ec.ce_temp run data get entity @s Health 100
execute store result score #ce_max ec.ce_temp run attribute @s max_health get 100
scoreboard players operation #ce_hp ec.ce_temp *= #100 ec.const
scoreboard players operation #ce_hp ec.ce_temp /= #ce_max ec.ce_temp

# Below 25%: Resistance II
execute if score #ce_hp ec.ce_temp matches ..25 run effect give @s resistance 2 1 true
execute if score #ce_hp ec.ce_temp matches ..25 run return 0

# Below 50%: Resistance I
execute if score #ce_hp ec.ce_temp matches 26..50 run effect give @s resistance 2 0 true
