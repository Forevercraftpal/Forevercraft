$execute if block ~$(x) ~$(y) ~$(z) #minecraft:crops run setblock ~$(x) ~$(y) ~$(z) minecraft:wheat[age=7] replace
