# Sabertooth — Pack Leader
# All tamed wolves, cats, and parrots within 16 blocks gain +50% attack damage and +25% movement speed
# Run as player with active Ascended Sabertooth (called every 20 ticks from evolution tick)

# Apply attribute modifiers to nearby tamed animals
# Wolves
execute at @s as @e[type=wolf,distance=..16,nbt={Owner:[I;]}] run attribute @s attack_damage modifier add evercraft:pack_leader 0.5 add_multiplied_base
execute at @s as @e[type=wolf,distance=..16,nbt={Owner:[I;]}] run attribute @s movement_speed modifier add evercraft:pack_leader 0.25 add_multiplied_base

# Cats
execute at @s as @e[type=cat,distance=..16,nbt={Owner:[I;]}] run attribute @s attack_damage modifier add evercraft:pack_leader 0.5 add_multiplied_base
execute at @s as @e[type=cat,distance=..16,nbt={Owner:[I;]}] run attribute @s movement_speed modifier add evercraft:pack_leader 0.25 add_multiplied_base

# Foxes
execute at @s as @e[type=fox,distance=..16,tag=ec.fox_tamed] run attribute @s attack_damage modifier add evercraft:pack_leader 0.5 add_multiplied_base
execute at @s as @e[type=fox,distance=..16,tag=ec.fox_tamed] run attribute @s movement_speed modifier add evercraft:pack_leader 0.25 add_multiplied_base

# Visual: golden particle tether from Sabertooth toward buffed animals
scoreboard players operation #Search companion.id = @s companion.id
execute as @e[type=item_display, tag=Companion, predicate=evercraft:companions/check_id, limit=1] at @s run particle happy_villager ~ ~0.3 ~ 0.2 0.2 0.2 0.02 3
