# Cow of Eden — Garden of Eden
# Passive: Crops within 8 blocks grow faster (random tick 2 blocks per cycle)
# Run as player with ce.evo_cow_of_eden tag, at player position

# Pick 2 random positions within 8 blocks and apply random tick if crop
execute at @s positioned ~-8 ~-2 ~-8 run function evercraft:companion_evolution/abilities/cow_of_eden_grow
execute at @s run particle happy_villager ~ ~0.5 ~ 3 0.5 3 0.01 2
