# Snow Fox Spirit — Aurora Shield
# Passive: Resistance I in cold/snowy biomes
# Run as player with ce.evo_snow_fox_spirit tag, at player

# Check for snowy/cold biomes (no vanilla #snow tag — check individually)
execute if biome ~ ~ ~ minecraft:snowy_plains run effect give @s resistance 2 0 true
execute if biome ~ ~ ~ minecraft:snowy_taiga run effect give @s resistance 2 0 true
execute if biome ~ ~ ~ minecraft:snowy_slopes run effect give @s resistance 2 0 true
execute if biome ~ ~ ~ minecraft:snowy_beach run effect give @s resistance 2 0 true
execute if biome ~ ~ ~ minecraft:frozen_peaks run effect give @s resistance 2 0 true
execute if biome ~ ~ ~ minecraft:jagged_peaks run effect give @s resistance 2 0 true
execute if biome ~ ~ ~ minecraft:ice_spikes run effect give @s resistance 2 0 true
execute if biome ~ ~ ~ minecraft:frozen_river run effect give @s resistance 2 0 true
execute if biome ~ ~ ~ minecraft:frozen_ocean run effect give @s resistance 2 0 true
execute if biome ~ ~ ~ minecraft:deep_frozen_ocean run effect give @s resistance 2 0 true

# Particles in any of the above (check via effect presence)
execute if entity @s[nbt={active_effects:[{id:"minecraft:resistance"}]}] at @s run particle end_rod ~ ~1 ~ 0.5 0.3 0.5 0.01 1
