# Wither — Decay Aura
# Passive: Wither I to hostiles within 6 blocks
# Run as player with ce.evo_wither tag, at player

execute at @s as @e[type=!player,type=!#evercraft:passive,distance=..6,tag=!Pet,tag=!Companion,limit=8,sort=nearest] run effect give @s wither 2 0 true
scoreboard players operation #Search companion.id = @s companion.id
execute as @e[type=item_display, tag=Companion, predicate=evercraft:companions/check_id, limit=1] at @s run particle dust{color:[0.2,0.2,0.2],scale:0.8} ~ ~0.3 ~ 0.2 0.2 0.2 0.02 2
