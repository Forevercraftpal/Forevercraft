# Golden Dragon — Midas Touch on kill
# Called when player with ce.evo_golden_dragon kills a mob
# 10% chance to drop 1-3 gold nuggets
execute store result score #ce_roll ec.ce_temp run random value 1..10
execute if score #ce_roll ec.ce_temp matches 1 at @s run loot spawn ~ ~ ~ loot minecraft:blocks/gold_ore
execute if score #ce_roll ec.ce_temp matches 1 at @s run particle dust{color:[1.0,0.84,0.0],scale:1.2} ~ ~0.5 ~ 0.3 0.3 0.3 0.02 10
execute if score #ce_roll ec.ce_temp matches 1 run playsound minecraft:block.chain.place master @s ~ ~ ~ 0.5 1.5
