# Infernus — Hellfire Mark (on player attack)
# Mobs hit burn for 5s. Already burning mobs take +2 extra damage.
# Run as player who just attacked

# Find the hit target
execute at @s as @e[type=!player,distance=..5,limit=1,sort=nearest,nbt={HurtTime:10s}] run function evercraft:companion_evolution/abilities/infernus_apply
