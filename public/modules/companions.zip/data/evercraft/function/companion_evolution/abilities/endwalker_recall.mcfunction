# Endwalker — Death Recall
# Teleports player to their last death location. Once per in-game day.
# Run as player with active Ascended Endwalker

# Check cooldown — compare current day to last use day
execute store result score #ce_now ec.ce_temp run time query day
execute if score @s ec.ce_recall_day = #ce_now ec.ce_temp run tellraw @s [{text:"[Forevercraft] ",color:"gold"},{text:"Death Recall is recharging. Available tomorrow.",color:"gray"}]
execute if score @s ec.ce_recall_day = #ce_now ec.ce_temp run return 0

# Check if death location was ever stored
execute if score @s ec.ce_death_x matches 0 if score @s ec.ce_death_y matches 0 if score @s ec.ce_death_z matches 0 run tellraw @s [{text:"[Forevercraft] ",color:"gold"},{text:"No death location recorded yet.",color:"gray"}]
execute if score @s ec.ce_death_x matches 0 if score @s ec.ce_death_y matches 0 if score @s ec.ce_death_z matches 0 run return 0

# Store current day as last use
scoreboard players operation @s ec.ce_recall_day = #ce_now ec.ce_temp

# Teleport to death location
# Write coordinates to storage for macro teleport
execute store result storage evercraft:ce recall.x int 1 run scoreboard players get @s ec.ce_death_x
execute store result storage evercraft:ce recall.y int 1 run scoreboard players get @s ec.ce_death_y
execute store result storage evercraft:ce recall.z int 1 run scoreboard players get @s ec.ce_death_z
function evercraft:companion_evolution/abilities/endwalker_do_recall with storage evercraft:ce recall

# Particles and sound
particle minecraft:portal ~ ~1 ~ 0.5 0.5 0.5 0.1 30
playsound minecraft:entity.enderman.teleport master @s ~ ~ ~ 1 0.8
playsound minecraft:entity.ender_dragon.flap master @s ~ ~ ~ 0.5 1.2

# Ender trail particles at destination
execute at @s run particle minecraft:portal ~ ~1 ~ 0.3 0.5 0.3 0.05 20

tellraw @s [{text:"[Forevercraft] ",color:"gold"},{text:"Ascended Endwalker recalls your last death...",color:"light_purple"}]
