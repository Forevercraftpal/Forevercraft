# Skeleton Horse — Phantom Gallop
# Passive: Speed I while sprinting. Slow Falling after fall damage.
# Run as player with ce.evo_skeleton_horse tag

# Speed I while sprinting
execute if predicate evercraft:companions/sprinting run effect give @s speed 2 0 true

# Slow Falling for 3s if just took fall damage (fall_distance resets on land)
execute if data entity @s {fall_distance:3.0d} run effect give @s slow_falling 3 0 true
