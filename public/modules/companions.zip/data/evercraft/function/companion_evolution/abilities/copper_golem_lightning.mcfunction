# Copper Golem — Lightning Rod (on player hurt)
# 15% chance to strike attacker with lightning. 10s internal CD.
# Run as player who was just hit

execute if score @s ec.ce_cd matches 1.. run return 0
execute store result score #ce_roll ec.ce_temp run random value 1..100
execute unless score #ce_roll ec.ce_temp matches 1..15 run return 0

scoreboard players set @s ec.ce_cd 200
execute at @e[type=!player,type=!#evercraft:passive,distance=..5,limit=1,sort=nearest,nbt={HurtTime:0s}] run summon lightning_bolt ~ ~ ~ {Tags:["ce.cosmetic"]}
execute at @e[type=!player,type=!#evercraft:passive,distance=..5,limit=1,sort=nearest] run damage @s 4 minecraft:lightning_bolt
execute at @s run playsound minecraft:entity.lightning_bolt.thunder master @s ~ ~ ~ 0.5 1.2
tellraw @s [{"text":"[Forevercraft] ","color":"gold"},{"text":"Lightning Rod activated!","color":"yellow"}]
