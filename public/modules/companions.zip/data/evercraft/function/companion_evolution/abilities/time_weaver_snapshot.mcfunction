# Time Weaver — HP Snapshot (called every 100 ticks = 5s from evolution tick)
# Stores current HP for Temporal Rewind
# Run as player with ce.evo_time_weaver tag

execute store result score @s ec.ce_stored_hp run data get entity @s Health
