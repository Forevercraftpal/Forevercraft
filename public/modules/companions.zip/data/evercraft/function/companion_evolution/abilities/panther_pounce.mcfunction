# Panther — Shadow Pounce (on player attack)
# First hit after 5s idle deals +4 bonus damage. ec.ce_idle tracks idle ticks.
# Run as player who just attacked

# Check if idle long enough (idle >= 5 seconds = 100 ticks, tracked every 20t = 5 cycles)
execute unless score @s ec.ce_idle matches 5.. run scoreboard players set @s ec.ce_idle 0
execute unless score @s ec.ce_idle matches 5.. run return 0

# Pounce! +4 damage to nearest hurt entity
execute at @s as @e[type=!player,distance=..5,limit=1,sort=nearest,nbt={HurtTime:10s}] run damage @s 4 minecraft:player_attack
scoreboard players set @s ec.ce_idle 0

execute at @s run particle crit ~ ~1 ~ 0.3 0.3 0.3 0.5 10
playsound minecraft:entity.ocelot.hurt master @s ~ ~ ~ 0.5 0.5
tellraw @s [{"text":"[Forevercraft] ","color":"gold"},{"text":"Shadow Pounce! ","color":"dark_purple"},{"text":"+4 bonus damage!","color":"red"}]
