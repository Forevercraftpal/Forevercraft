# Moobloom — Pollen Cloud
# Passive: Weakness I to hostiles within 6 blocks. Spore particles.
# Run as player with ce.evo_moobloom tag, at player

execute at @s as @e[type=!player,type=!#evercraft:passive,distance=..6,tag=!Pet,tag=!Companion,limit=8,sort=nearest] run effect give @s weakness 2 0 true
scoreboard players operation #Search companion.id = @s companion.id
execute as @e[type=item_display, tag=Companion, predicate=evercraft:companions/check_id, limit=1] at @s run particle spore_blossom_air ~ ~0.3 ~ 0.3 0.2 0.3 0.02 3
