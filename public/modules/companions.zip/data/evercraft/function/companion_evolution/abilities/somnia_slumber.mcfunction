# Somnia — Deep Slumber (upgraded Lullaby)
# Passive: 8% chance to apply Slowness V + Blindness I to hostiles within 12 blocks
# Run as player with ce.evo_somnia tag, at player

execute store result score #ce_roll ec.ce_temp run random value 1..100
execute unless score #ce_roll ec.ce_temp matches 1..8 run return 0
execute at @s as @e[type=!player,type=!#evercraft:passive,distance=..12,tag=!Pet,tag=!Companion,limit=3,sort=nearest] run effect give @s slowness 1 4 true
execute at @s as @e[type=!player,type=!#evercraft:passive,distance=..12,tag=!Pet,tag=!Companion,limit=3,sort=nearest] run effect give @s blindness 1 0 true
execute at @s run particle dust{color:[0.5,0.3,0.8],scale:1.0} ~ ~0.5 ~ 4 0.5 4 0.01 5
