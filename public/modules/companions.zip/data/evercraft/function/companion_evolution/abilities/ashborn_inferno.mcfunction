# Ashborn — Inferno Aura
# All hostile mobs within 8 blocks take 1 heart fire damage every 3 seconds
# Run as player with active Ascended Ashborn (called every 60 ticks from evolution tick)

# Apply fire damage to nearby hostile mobs
execute at @s as @e[type=!player,type=!#evercraft:passive,distance=..8,tag=!Pet,tag=!Companion,limit=8,sort=nearest] run damage @s 2 minecraft:on_fire

# Visual: small flame particles orbit the pet
scoreboard players operation #Search companion.id = @s companion.id
execute as @e[type=item_display, tag=Companion, predicate=evercraft:companions/check_id, limit=1] at @s run particle flame ~ ~0.3 ~ 0.4 0.2 0.4 0.01 5
execute as @e[type=item_display, tag=Companion, predicate=evercraft:companions/check_id, limit=1] at @s run particle small_flame ~ ~0.3 ~ 0.3 0.1 0.3 0.02 3
