# Nebula Kit — Cosmic Radar (upgraded mob glow)
# Passive: Mob glow at 32 blocks + item glow at 16 blocks
# Run as player with ce.evo_nebula_kit tag, at player
# OPT: Limited to 10 mobs and 5 items per tick to prevent lag in mob-dense areas

# Glow hostiles at extended range (limit 10 nearest)
execute at @s as @e[type=!player,type=!#evercraft:passive,distance=..32,tag=!Pet,tag=!Companion,limit=10,sort=nearest] run effect give @s glowing 3 0 true

# Glow dropped items within 16 blocks (limit 5 nearest)
execute at @s as @e[type=item,distance=..16,limit=5,sort=nearest] run effect give @s glowing 3 0 true
