# Vex — Phase Shift
# Triggered: Sneak+click. 3s flight (Levitation 0 + Slow Falling + Speed). 60s CD.
# Run as player

execute if score @s ec.ce_cd matches 1.. run tellraw @s [{"text":"[Forevercraft] ","color":"gold"},{"text":"Phase Shift recharging.","color":"gray"}]
execute if score @s ec.ce_cd matches 1.. run return 0

scoreboard players set @s ec.ce_cd 1200
effect give @s levitation 3 0 true
effect give @s slow_falling 5 0 true
effect give @s speed 3 1 true

execute at @s run particle witch ~ ~1 ~ 0.3 0.3 0.3 0.1 15
playsound minecraft:entity.vex.ambient master @s ~ ~ ~ 1 0.5
tellraw @s [{"text":"[Forevercraft] ","color":"gold"},{"text":"Phase Shift! ","color":"light_purple"},{"text":"You phase through reality for 3s!","color":"gray"}]
