# Dreamstag — Dreamwalk
# Triggered: Sneak+click. Invisibility + Speed II for 10s, Weakness V to prevent attacks. 90s CD.
# Run as player

execute if score @s ec.ce_cd matches 1.. run tellraw @s [{"text":"[Forevercraft] ","color":"gold"},{"text":"Dreamwalk recharging.","color":"gray"}]
execute if score @s ec.ce_cd matches 1.. run return 0

scoreboard players set @s ec.ce_cd 1800
effect give @s invisibility 10 0 true
effect give @s speed 10 1 true
effect give @s weakness 10 4 true

execute at @s run particle end_rod ~ ~1 ~ 0.5 0.5 0.5 0.02 15
execute at @s run particle enchant ~ ~1 ~ 0.3 0.5 0.3 0.5 10
playsound minecraft:block.amethyst_block.resonate master @s ~ ~ ~ 1 0.5
tellraw @s [{"text":"[Forevercraft] ","color":"gold"},{"text":"Dreamwalk! ","color":"light_purple"},{"text":"You drift through the dream realm for 10s...","color":"gray"}]
