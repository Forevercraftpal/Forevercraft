# Wraith — Shadow Veil
# At night, player is invisible to hostile mobs
# Run as player with active Ascended Wraith (called from evolution tick, ~every 20 ticks)

# Check if nighttime (visual_time 13000-23000)
execute unless score #visual_time ec.var matches 13000..23000 run return 0

# Apply Invisibility effect for 2 seconds (40 ticks, refreshed every 20 ticks)
# No particles (true) — mobs can't detect invisible players naturally
effect give @s invisibility 2 0 true

# Purple soul particles around player (subtle visual indicator)
execute at @s run particle soul ~ ~1 ~ 0.3 0.3 0.3 0.01 2

# Soul particles around companion
scoreboard players operation #Search companion.id = @s companion.id
execute as @e[type=item_display, tag=Companion, predicate=evercraft:companions/check_id, limit=1] at @s run particle soul ~ ~0.3 ~ 0.2 0.2 0.2 0.01 1
