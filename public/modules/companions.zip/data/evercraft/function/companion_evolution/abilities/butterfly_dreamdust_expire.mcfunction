# Remove Dreamdust luck bonus
execute as @a[tag=ce.evo_butterfly] run attribute @s luck modifier remove evercraft:dreamdust
