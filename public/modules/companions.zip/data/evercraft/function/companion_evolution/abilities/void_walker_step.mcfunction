# Void Walker — Void Step
# Triggered: Sneak+click. TP 8 blocks in look direction. 30s CD.
# Run as player

execute if score @s ec.ce_cd matches 1.. run tellraw @s [{"text":"[Forevercraft] ","color":"gold"},{"text":"Void Step recharging.","color":"gray"}]
execute if score @s ec.ce_cd matches 1.. run return 0

scoreboard players set @s ec.ce_cd 600

# Teleport 8 blocks forward in look direction
execute at @s anchored eyes run tp @s ^ ^ ^8

execute at @s run particle portal ~ ~1 ~ 0.3 0.5 0.3 0.5 25
execute at @s run particle reverse_portal ~ ~1 ~ 0.2 0.3 0.2 0.3 15
playsound minecraft:entity.enderman.teleport master @s ~ ~ ~ 1 0.8
tellraw @s [{"text":"[Forevercraft] ","color":"gold"},{"text":"Void Step!","color":"dark_purple"}]
