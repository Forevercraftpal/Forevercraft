# Cow of Eden — random crop growth tick
# Positioned at corner of 16x4x16 area
execute store result score #ce_rx ec.ce_temp run random value 0..15
execute store result score #ce_ry ec.ce_temp run random value 0..3
execute store result score #ce_rz ec.ce_temp run random value 0..15
execute store result storage evercraft:ce grow.x int 1 run scoreboard players get #ce_rx ec.ce_temp
execute store result storage evercraft:ce grow.y int 1 run scoreboard players get #ce_ry ec.ce_temp
execute store result storage evercraft:ce grow.z int 1 run scoreboard players get #ce_rz ec.ce_temp
function evercraft:companion_evolution/abilities/cow_of_eden_do_grow with storage evercraft:ce grow
