# Regal Tiger — Apex Rush on kill
# Speed II for 3 seconds after killing a mob
effect give @s speed 3 1 true
execute at @s run playsound minecraft:entity.ocelot.ambient master @s ~ ~ ~ 0.5 0.8
