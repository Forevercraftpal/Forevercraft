# Lunar Moth — Moonbeam
# Passive: At night, +2 bonus attack damage via attribute modifier
# Run as player with ce.evo_lunar_moth tag
# Hysteresis: activate at 13200 (well into night), deactivate at 22800 (before dawn)
# Prevents flickering at exact boundary ticks

# Night check with margin
execute if score #visual_time ec.var matches 13200..22800 run attribute @s attack_damage modifier add evercraft:moonbeam 2.0 add_value
execute unless score #visual_time ec.var matches 13000..23000 run attribute @s attack_damage modifier remove evercraft:moonbeam

# Moon particles on pet at night
execute if score #visual_time ec.var matches 13200..22800 run scoreboard players operation #Search companion.id = @s companion.id
execute if score #visual_time ec.var matches 13200..22800 as @e[type=item_display, tag=Companion, predicate=evercraft:companions/check_id, limit=1] at @s run particle end_rod ~ ~0.4 ~ 0.1 0.2 0.1 0.01 1
