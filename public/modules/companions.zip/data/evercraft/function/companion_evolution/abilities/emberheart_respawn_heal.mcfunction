# Emberheart — Post-respawn full heal
# Run as player with ce.emberheart_revive tag, after they've respawned
# Items are preserved because tomb was cancelled (ec.tomb_death set to 0)

# Full heal to max HP (two-step pattern)
execute store result storage evercraft:ce temp.max_hp float 1 run attribute @s max_health get
data modify entity @s Health set from storage evercraft:ce temp.max_hp

# Clear harmful effects
effect clear @s wither
effect clear @s poison
effect clear @s hunger

# Brief resistance so they don't die again immediately
effect give @s resistance 5 2 true
effect give @s regeneration 5 1 true
effect give @s fire_resistance 10 0 true

# Visual at respawn location
execute at @s run particle totem_of_undying ~ ~1 ~ 0.3 0.3 0.3 0.3 25
execute at @s run playsound minecraft:entity.blaze.shoot master @s ~ ~ ~ 0.5 0.8

# Remove tag
tag @s remove ce.emberheart_revive
