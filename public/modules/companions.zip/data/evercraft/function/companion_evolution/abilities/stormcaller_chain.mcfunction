# Stormcaller — Chain Lightning (on player attack)
# Every 5th hit chains lightning to 2 nearby mobs (3 damage each)
# Run as player who just attacked

scoreboard players add @s ec.ce_hit_count 1
execute unless score @s ec.ce_hit_count matches 5.. run return 0

scoreboard players set @s ec.ce_hit_count 0

# Find 2 nearby mobs (not the one we just hit) and damage them
execute at @s at @e[type=!player,distance=..5,limit=1,sort=nearest,nbt={HurtTime:10s}] as @e[type=!player,distance=..8,limit=2,sort=nearest,nbt={HurtTime:0s},tag=!Pet,tag=!Companion] run damage @s 3 minecraft:lightning_bolt
execute at @s at @e[type=!player,distance=..5,limit=1,sort=nearest,nbt={HurtTime:10s}] as @e[type=!player,distance=..8,limit=2,sort=nearest,tag=!Pet,tag=!Companion] at @s run particle electric_spark ~ ~0.5 ~ 0.2 0.2 0.2 0.1 5

execute at @s run playsound minecraft:entity.lightning_bolt.impact master @s ~ ~ ~ 0.3 1.5
