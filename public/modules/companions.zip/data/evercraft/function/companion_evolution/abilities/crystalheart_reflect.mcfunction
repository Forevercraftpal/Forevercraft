# Crystalheart — Prismatic Reflect (on player hurt while blocking)
# 25% chance to debuff attacker when player blocks with shield
# Run as player who was just hit

# Check if player is using shield (blocking)
execute unless items entity @s weapon.offhand minecraft:shield run return 0

execute store result score #ce_roll ec.ce_temp run random value 1..4
execute unless score #ce_roll ec.ce_temp matches 1 run return 0

# Apply debuffs to nearest hostile that could have attacked
execute at @s as @e[type=!player,distance=..4,limit=1,sort=nearest] run effect give @s slowness 3 1 true
execute at @s as @e[type=!player,distance=..4,limit=1,sort=nearest] run effect give @s mining_fatigue 3 0 true

execute at @s run particle dust{color:[0.8,0.3,1.0],scale:1.0} ~ ~1 ~ 0.3 0.3 0.3 0.02 8
playsound minecraft:block.amethyst_block.hit master @s ~ ~ ~ 1 1.2
