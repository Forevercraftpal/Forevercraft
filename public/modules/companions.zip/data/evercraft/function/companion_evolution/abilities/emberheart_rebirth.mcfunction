# Emberheart — Phoenix Rebirth
# Called from tick.mcfunction when player with Ascended Emberheart dies (ec.tomb_death=1)
# Player is dead — can't heal now. Instead: cancel tomb, tag for respawn heal next tick.
# Run as the dying player at death position

# Tag player for respawn healing (processed in tick next frame after respawn)
tag @s add ce.emberheart_revive

# Kill the companion entity (sacrifice)
scoreboard players operation #Search companion.id = @s companion.id
execute as @e[type=item_display, tag=Companion, predicate=evercraft:companions/check_id, limit=1] at @s run particle flame ~ ~0.5 ~ 0.3 0.3 0.3 0.05 20
kill @e[type=wolf, tag=CompanionWolf, predicate=evercraft:companions/check_id]
kill @e[type=item_display, tag=Companion, predicate=evercraft:companions/check_id]
kill @e[type=interaction, tag=companion.petinteract, predicate=evercraft:companions/check_id]
tag @s remove companion.activepet

# Clear evolution tags (companion is gone)
tag @s remove ce.evolved_active
tag @s remove ce.evo_emberheart

# Set rebirth cooldown (72000 gametime ticks = 1 real-time hour)
execute store result score @s ec.ce_rebirth_timer run time query gametime
scoreboard players add @s ec.ce_rebirth_timer 72000

# Sound at death location (before respawn teleport)
playsound minecraft:item.totem.use master @s ~ ~ ~ 1 1

# Particles at death location
execute at @s run particle totem_of_undying ~ ~1 ~ 0.5 0.5 0.5 0.5 50
execute at @s run particle flame ~ ~1 ~ 0.3 0.5 0.3 0.05 30

# Announcement
tellraw @s [{"text":"[Forevercraft] ","color":"gold"},{"text":"\u2726 ","color":"light_purple"},{"text":"Ascended Emberheart","color":"gold"},{"text":" sacrificed itself to save you!","color":"light_purple"}]
tellraw @s [{"text":"[Forevercraft] ","color":"gold"},{"text":"It will be reborn in 1 hour...","color":"gray"}]
tellraw @a [{"text":""},{"selector":"@s","color":"yellow"},{"text":" was saved from death by their ","color":"gray"},{"text":"Ascended Emberheart","color":"gold"},{"text":"!","color":"gray"}]
