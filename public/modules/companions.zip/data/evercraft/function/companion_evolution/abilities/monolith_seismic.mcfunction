# Monolith — Seismic Sight
# While sneaking, all entities within 32 blocks gain Glowing for 5 seconds
# Run as player with active Ascended Monolith — triggered on sneak detection

# Check cooldown
execute if score @s ec.ce_seismic_cd matches 1.. run return 0

# Apply Glowing to all entities in range for 100 ticks (5 seconds)
execute at @s as @e[distance=..32] run effect give @s glowing 5 0 true

# Set cooldown (600 ticks = 30 seconds)
scoreboard players set @s ec.ce_seismic_cd 600

# Visual: blue sculk pulse
execute at @s run particle sculk_charge_pop ~ ~0.5 ~ 3 1 3 0.1 30
execute at @s run particle sculk_soul ~ ~0.5 ~ 2 0.5 2 0.05 15

# Sound
playsound minecraft:block.sculk_sensor.clicking master @s ~ ~ ~ 1 0.5
playsound minecraft:entity.warden.heartbeat master @s ~ ~ ~ 0.5 1.0

# Message
tellraw @s [{text:"[Forevercraft] ",color:"gold"},{text:"Seismic Sight activated!",color:"dark_aqua"},{text:" All entities revealed for 5 seconds.",color:"gray"}]
