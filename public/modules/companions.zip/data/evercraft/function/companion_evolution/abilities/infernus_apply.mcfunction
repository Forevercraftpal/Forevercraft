# Infernus — apply fire + bonus damage to burning target
# Run as the hit mob

# If already burning (Fire > 0), +2 bonus damage
# Fire is a Short — store to score and check > 0 for reliable range check
execute store result score #infernus_fire ec.temp run data get entity @s Fire
execute if score #infernus_fire ec.temp matches 1.. run damage @s 2 minecraft:on_fire
execute if score #infernus_fire ec.temp matches 1.. at @s run particle flame ~ ~0.5 ~ 0.2 0.2 0.2 0.05 5

# Set on fire for 5 seconds (100 ticks)
data modify entity @s Fire set value 100s
