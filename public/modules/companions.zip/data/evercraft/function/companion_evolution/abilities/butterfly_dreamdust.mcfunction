# Butterfly — Dreamdust
# Passive: 5% chance per tick to grant temporary Luck +1 for 30s
# Run as player with ce.evo_butterfly tag

execute store result score #ce_roll ec.ce_temp run random value 1..20
execute if score #ce_roll ec.ce_temp matches 1 run attribute @s luck modifier add evercraft:dreamdust 1.0 add_value
execute if score #ce_roll ec.ce_temp matches 1 run schedule function evercraft:companion_evolution/abilities/butterfly_dreamdust_expire 30s
execute if score #ce_roll ec.ce_temp matches 1 at @s run particle enchant ~ ~1.5 ~ 0.3 0.3 0.3 0.5 10
execute if score #ce_roll ec.ce_temp matches 1 at @s run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.3 1.5
