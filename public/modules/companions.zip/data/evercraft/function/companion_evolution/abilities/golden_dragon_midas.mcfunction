# Golden Dragon — Midas Touch
# Passive flag: set on player. Actual gold drop handled by mob kill advancement.
# This tick just maintains ambient particles on the pet.
scoreboard players operation #Search companion.id = @s companion.id
execute as @e[type=item_display, tag=Companion, predicate=evercraft:companions/check_id, limit=1] at @s run particle dust{color:[1.0,0.84,0.0],scale:0.8} ~ ~0.3 ~ 0.15 0.15 0.15 0.01 2
