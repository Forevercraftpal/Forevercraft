# Arctic Fox — Permafrost Trail
# Passive: Freezes nearby water into frosted_ice, slows hostile mobs
# Run as player with ce.evo_arctic_fox tag, at player position
# OPT: Reduced fill radius to 1 block (5x1x5 = 5 blocks max, decays naturally)

# Only freeze water at feet level (not massive area)
execute at @s align xyz run fill ~1 ~ ~1 ~-1 ~ ~-1 frosted_ice[age=2] replace water
execute at @s align xyz run fill ~1 ~-1 ~1 ~-1 ~-1 ~-1 frosted_ice[age=2] replace water

# Slow nearby hostiles (limit 5 to prevent mass-effect lag)
execute at @s as @e[type=!player,type=!#evercraft:passive,distance=..6,tag=!Pet,tag=!Companion,limit=5,sort=nearest] run effect give @s slowness 2 0 true

execute at @s run particle snowflake ~ ~0.5 ~ 1.5 0.3 1.5 0.02 3
