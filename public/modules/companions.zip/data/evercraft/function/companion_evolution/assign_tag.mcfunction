# Assign specific evolution tag based on pet_name in storage
# Run as player — reads from evercraft:ce temp.pet_name

# Original 6
execute if data storage evercraft:ce {temp:{pet_name:"blue_dragon"}} run tag @s add ce.evo_endwalker
execute if data storage evercraft:ce {temp:{pet_name:"red_dragon"}} run tag @s add ce.evo_ashborn
execute if data storage evercraft:ce {temp:{pet_name:"phoenix"}} run tag @s add ce.evo_emberheart
execute if data storage evercraft:ce {temp:{pet_name:"reaper"}} run tag @s add ce.evo_wraith
execute if data storage evercraft:ce {temp:{pet_name:"warden"}} run tag @s add ce.evo_monolith
execute if data storage evercraft:ce {temp:{pet_name:"tiger"}} run tag @s add ce.evo_sabertooth

# Roster Mythicals
execute if data storage evercraft:ce {temp:{pet_name:"arctic_fox"}} run tag @s add ce.evo_arctic_fox
execute if data storage evercraft:ce {temp:{pet_name:"butterfly"}} run tag @s add ce.evo_butterfly
execute if data storage evercraft:ce {temp:{pet_name:"claude"}} run tag @s add ce.evo_claude
execute if data storage evercraft:ce {temp:{pet_name:"copper_golem"}} run tag @s add ce.evo_copper_golem
execute if data storage evercraft:ce {temp:{pet_name:"cow_of_eden"}} run tag @s add ce.evo_cow_of_eden
execute if data storage evercraft:ce {temp:{pet_name:"deloris"}} run tag @s add ce.evo_deloris
execute if data storage evercraft:ce {temp:{pet_name:"golden_dragon"}} run tag @s add ce.evo_golden_dragon
execute if data storage evercraft:ce {temp:{pet_name:"iron_golem"}} run tag @s add ce.evo_iron_golem
execute if data storage evercraft:ce {temp:{pet_name:"leviathan"}} run tag @s add ce.evo_leviathan
execute if data storage evercraft:ce {temp:{pet_name:"moobloom"}} run tag @s add ce.evo_moobloom
execute if data storage evercraft:ce {temp:{pet_name:"panther"}} run tag @s add ce.evo_panther
execute if data storage evercraft:ce {temp:{pet_name:"red_panda"}} run tag @s add ce.evo_red_panda
execute if data storage evercraft:ce {temp:{pet_name:"regal_tiger"}} run tag @s add ce.evo_regal_tiger
execute if data storage evercraft:ce {temp:{pet_name:"skeleton_horse"}} run tag @s add ce.evo_skeleton_horse
execute if data storage evercraft:ce {temp:{pet_name:"snow_fox_spirit"}} run tag @s add ce.evo_snow_fox_spirit
execute if data storage evercraft:ce {temp:{pet_name:"spirit_wolf"}} run tag @s add ce.evo_spirit_wolf
execute if data storage evercraft:ce {temp:{pet_name:"time_weaver"}} run tag @s add ce.evo_time_weaver
execute if data storage evercraft:ce {temp:{pet_name:"vex"}} run tag @s add ce.evo_vex
execute if data storage evercraft:ce {temp:{pet_name:"void_walker"}} run tag @s add ce.evo_void_walker
execute if data storage evercraft:ce {temp:{pet_name:"wither"}} run tag @s add ce.evo_wither

# Gacha Mythicals
execute if data storage evercraft:ce {temp:{pet_name:"dreamstag"}} run tag @s add ce.evo_dreamstag
execute if data storage evercraft:ce {temp:{pet_name:"starweaver"}} run tag @s add ce.evo_starweaver
execute if data storage evercraft:ce {temp:{pet_name:"somnia"}} run tag @s add ce.evo_somnia

# Gacha Exquisites
execute if data storage evercraft:ce {temp:{pet_name:"lunar_moth"}} run tag @s add ce.evo_lunar_moth
execute if data storage evercraft:ce {temp:{pet_name:"nebula_kit"}} run tag @s add ce.evo_nebula_kit
execute if data storage evercraft:ce {temp:{pet_name:"twilight_hare"}} run tag @s add ce.evo_twilight_hare
execute if data storage evercraft:ce {temp:{pet_name:"grovekeeper"}} run tag @s add ce.evo_grovekeeper
execute if data storage evercraft:ce {temp:{pet_name:"infernus"}} run tag @s add ce.evo_infernus
execute if data storage evercraft:ce {temp:{pet_name:"crystalheart"}} run tag @s add ce.evo_crystalheart
execute if data storage evercraft:ce {temp:{pet_name:"stormcaller"}} run tag @s add ce.evo_stormcaller
execute if data storage evercraft:ce {temp:{pet_name:"voidshade"}} run tag @s add ce.evo_voidshade
