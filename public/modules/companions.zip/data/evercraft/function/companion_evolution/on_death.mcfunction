# Store death position for Endwalker Death Recall
# Run as dying player at death position

# Store death coordinates for any player (Endwalker can use them later)
execute store result score @s ec.ce_death_x run data get entity @s Pos[0]
execute store result score @s ec.ce_death_y run data get entity @s Pos[1]
execute store result score @s ec.ce_death_z run data get entity @s Pos[2]

# Store dimension
scoreboard players set @s ec.ce_death_dim 0
execute if dimension minecraft:the_nether run scoreboard players set @s ec.ce_death_dim 1
execute if dimension minecraft:the_end run scoreboard players set @s ec.ce_death_dim 2
