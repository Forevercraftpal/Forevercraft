# Evolved companion on-hurt dispatch
# Called when a player with an evolved companion takes damage
# Run as the damaged player

# Copper Golem — Lightning Rod (15% chance to zap attacker)
execute if entity @s[tag=ce.evo_copper_golem] run function evercraft:companion_evolution/abilities/copper_golem_lightning

# Twilight Hare — Blink Dodge (15% chance to TP backward)
execute if entity @s[tag=ce.evo_twilight_hare] run function evercraft:companion_evolution/abilities/twilight_hare_blink

# Crystalheart — Prismatic Reflect (25% chance to debuff attacker when blocking)
execute if entity @s[tag=ce.evo_crystalheart] run function evercraft:companion_evolution/abilities/crystalheart_reflect
