# === COMPANION EVOLUTION SYSTEM ===
# Allows max-level, max-bond mythical companions to evolve into Ascended forms

# Evolution bitfields: tracks which companions have been evolved (per player)
# ec.ce_evolved: bits 0-30 (original 6 + 20 mythicals + 3 gacha mythicals + 2 gacha exquisites)
# ec.ce_evolved2: bits 0-5 (remaining 6 gacha exquisites)
scoreboard objectives add ec.ce_evolved dummy "Evolved Companions"
scoreboard objectives add ec.ce_evolved2 dummy "Evolved Companions 2"

# Per-evolved-companion ability scoreboards
scoreboard objectives add ec.ce_recall_day dummy "Death Recall Day"
scoreboard objectives add ec.ce_death_x dummy "Death X"
scoreboard objectives add ec.ce_death_y dummy "Death Y"
scoreboard objectives add ec.ce_death_z dummy "Death Z"
scoreboard objectives add ec.ce_death_dim dummy "Death Dimension"
scoreboard objectives add ec.ce_rebirth_timer dummy "Emberheart Rebirth Timer"
scoreboard objectives add ec.ce_seismic_cd dummy "Seismic Sight Cooldown"
scoreboard objectives add ec.ce_inferno_cd dummy "Inferno Aura Timer"
scoreboard objectives add ec.ce_temp dummy "CE Temp Calculation"
scoreboard objectives add ec.ce_phase dummy "Evolution Phase"

# Shared evolved ability scoreboards
scoreboard objectives add ec.ce_cd dummy "CE Ability Cooldown"
scoreboard objectives add ec.ce_hit_count dummy "CE Hit Counter"
scoreboard objectives add ec.ce_stored_hp dummy "CE Stored HP"
scoreboard objectives add ec.ce_idle dummy "CE Idle Ticks"
scoreboard objectives add ec.ce_stealth dummy "CE Stealth Flag"

# Bitfield constants for evolution checking
scoreboard players set #ce_endwalker companion.calc 1
scoreboard players set #ce_ashborn companion.calc 2
scoreboard players set #ce_emberheart companion.calc 4
scoreboard players set #ce_wraith companion.calc 8
scoreboard players set #ce_monolith companion.calc 16
scoreboard players set #ce_sabertooth companion.calc 32

# Evolution ceremony schedule (self-scheduling when active)
# Phase tracking: 0=idle, 1=darkness, 2=burst, 3=transform, 4=announce

# Bootstrap evolved abilities tick (self-scheduling every 20 ticks)
schedule function evercraft:companion_evolution/tick 20t
