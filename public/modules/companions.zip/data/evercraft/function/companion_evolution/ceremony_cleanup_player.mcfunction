# Per-player ceremony cleanup — run as the player who just finished evolving
# Replaces the old global ceremony_cleanup

scoreboard players operation #Search companion.id = @s companion.id

# Remove evolving tags from companion entity
execute as @e[type=item_display,tag=ce.evolving_pet,predicate=evercraft:companions/check_id] run tag @s remove ce.evolving_pet

# Sync evolved companion data back to marker database
function evercraft:companion_evolution/sync_to_marker

# Set evolution ability tags immediately (don't wait for next summon)
function evercraft:companion_evolution/on_summon

# Coin reward for evolution
function evercraft:coins/evolution_reward

# Evolution bonus: Ornate artifact (one-time reward)
loot give @s loot evercraft:artifacts/ornate/main
tellraw @s [{text:"  ★ ",color:"dark_purple"},{text:"Ornate Artifact",color:"dark_purple",bold:true},{text:" — Evolution Achieved!",color:"gold"}]

# Remove ceremony tags and reset timer
tag @s remove ce.evolving
scoreboard players set @s ec.ce_phase 0
