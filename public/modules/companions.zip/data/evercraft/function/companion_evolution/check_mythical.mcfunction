# Check if companion is evolvable (all mythicals + 3 exquisites with unique abilities)
# Run as companion entity — reads pet_name from storage (profile signature)
# Sets #ce_bit ec.ce_temp to the evolution bitfield value
# Returns success (1) if evolvable, fail (0) if not

# === Original 6 with unique evolved abilities (bits 0-5) ===
execute if data storage evercraft:ce {temp:{pet_name:"blue_dragon"}} run scoreboard players set #ce_bit ec.ce_temp 1
execute if data storage evercraft:ce {temp:{pet_name:"blue_dragon"}} run return 1

execute if data storage evercraft:ce {temp:{pet_name:"red_dragon"}} run scoreboard players set #ce_bit ec.ce_temp 2
execute if data storage evercraft:ce {temp:{pet_name:"red_dragon"}} run return 1

execute if data storage evercraft:ce {temp:{pet_name:"phoenix"}} run scoreboard players set #ce_bit ec.ce_temp 4
execute if data storage evercraft:ce {temp:{pet_name:"phoenix"}} run return 1

execute if data storage evercraft:ce {temp:{pet_name:"reaper"}} run scoreboard players set #ce_bit ec.ce_temp 8
execute if data storage evercraft:ce {temp:{pet_name:"reaper"}} run return 1

execute if data storage evercraft:ce {temp:{pet_name:"warden"}} run scoreboard players set #ce_bit ec.ce_temp 16
execute if data storage evercraft:ce {temp:{pet_name:"warden"}} run return 1

execute if data storage evercraft:ce {temp:{pet_name:"tiger"}} run scoreboard players set #ce_bit ec.ce_temp 32
execute if data storage evercraft:ce {temp:{pet_name:"tiger"}} run return 1

# === Remaining 20 Mythical pets (bits 6-25) — evolve with Ascended name + glint ===
execute if data storage evercraft:ce {temp:{pet_name:"arctic_fox"}} run scoreboard players set #ce_bit ec.ce_temp 64
execute if data storage evercraft:ce {temp:{pet_name:"arctic_fox"}} run return 1

execute if data storage evercraft:ce {temp:{pet_name:"butterfly"}} run scoreboard players set #ce_bit ec.ce_temp 128
execute if data storage evercraft:ce {temp:{pet_name:"butterfly"}} run return 1

execute if data storage evercraft:ce {temp:{pet_name:"claude"}} run scoreboard players set #ce_bit ec.ce_temp 256
execute if data storage evercraft:ce {temp:{pet_name:"claude"}} run return 1

execute if data storage evercraft:ce {temp:{pet_name:"copper_golem"}} run scoreboard players set #ce_bit ec.ce_temp 512
execute if data storage evercraft:ce {temp:{pet_name:"copper_golem"}} run return 1

execute if data storage evercraft:ce {temp:{pet_name:"cow_of_eden"}} run scoreboard players set #ce_bit ec.ce_temp 1024
execute if data storage evercraft:ce {temp:{pet_name:"cow_of_eden"}} run return 1

execute if data storage evercraft:ce {temp:{pet_name:"deloris"}} run scoreboard players set #ce_bit ec.ce_temp 2048
execute if data storage evercraft:ce {temp:{pet_name:"deloris"}} run return 1

execute if data storage evercraft:ce {temp:{pet_name:"golden_dragon"}} run scoreboard players set #ce_bit ec.ce_temp 4096
execute if data storage evercraft:ce {temp:{pet_name:"golden_dragon"}} run return 1

execute if data storage evercraft:ce {temp:{pet_name:"iron_golem"}} run scoreboard players set #ce_bit ec.ce_temp 8192
execute if data storage evercraft:ce {temp:{pet_name:"iron_golem"}} run return 1

execute if data storage evercraft:ce {temp:{pet_name:"leviathan"}} run scoreboard players set #ce_bit ec.ce_temp 16384
execute if data storage evercraft:ce {temp:{pet_name:"leviathan"}} run return 1

execute if data storage evercraft:ce {temp:{pet_name:"moobloom"}} run scoreboard players set #ce_bit ec.ce_temp 32768
execute if data storage evercraft:ce {temp:{pet_name:"moobloom"}} run return 1

execute if data storage evercraft:ce {temp:{pet_name:"panther"}} run scoreboard players set #ce_bit ec.ce_temp 65536
execute if data storage evercraft:ce {temp:{pet_name:"panther"}} run return 1

execute if data storage evercraft:ce {temp:{pet_name:"red_panda"}} run scoreboard players set #ce_bit ec.ce_temp 131072
execute if data storage evercraft:ce {temp:{pet_name:"red_panda"}} run return 1

execute if data storage evercraft:ce {temp:{pet_name:"regal_tiger"}} run scoreboard players set #ce_bit ec.ce_temp 262144
execute if data storage evercraft:ce {temp:{pet_name:"regal_tiger"}} run return 1

execute if data storage evercraft:ce {temp:{pet_name:"skeleton_horse"}} run scoreboard players set #ce_bit ec.ce_temp 524288
execute if data storage evercraft:ce {temp:{pet_name:"skeleton_horse"}} run return 1

execute if data storage evercraft:ce {temp:{pet_name:"snow_fox_spirit"}} run scoreboard players set #ce_bit ec.ce_temp 1048576
execute if data storage evercraft:ce {temp:{pet_name:"snow_fox_spirit"}} run return 1

execute if data storage evercraft:ce {temp:{pet_name:"spirit_wolf"}} run scoreboard players set #ce_bit ec.ce_temp 2097152
execute if data storage evercraft:ce {temp:{pet_name:"spirit_wolf"}} run return 1

execute if data storage evercraft:ce {temp:{pet_name:"time_weaver"}} run scoreboard players set #ce_bit ec.ce_temp 4194304
execute if data storage evercraft:ce {temp:{pet_name:"time_weaver"}} run return 1

execute if data storage evercraft:ce {temp:{pet_name:"vex"}} run scoreboard players set #ce_bit ec.ce_temp 8388608
execute if data storage evercraft:ce {temp:{pet_name:"vex"}} run return 1

execute if data storage evercraft:ce {temp:{pet_name:"void_walker"}} run scoreboard players set #ce_bit ec.ce_temp 16777216
execute if data storage evercraft:ce {temp:{pet_name:"void_walker"}} run return 1

execute if data storage evercraft:ce {temp:{pet_name:"wither"}} run scoreboard players set #ce_bit ec.ce_temp 33554432
execute if data storage evercraft:ce {temp:{pet_name:"wither"}} run return 1

# === Gacha Mythicals (bits 26-28) ===
execute if data storage evercraft:ce {temp:{pet_name:"dreamstag"}} run scoreboard players set #ce_bit ec.ce_temp 67108864
execute if data storage evercraft:ce {temp:{pet_name:"dreamstag"}} run return 1

execute if data storage evercraft:ce {temp:{pet_name:"starweaver"}} run scoreboard players set #ce_bit ec.ce_temp 134217728
execute if data storage evercraft:ce {temp:{pet_name:"starweaver"}} run return 1

execute if data storage evercraft:ce {temp:{pet_name:"somnia"}} run scoreboard players set #ce_bit ec.ce_temp 268435456
execute if data storage evercraft:ce {temp:{pet_name:"somnia"}} run return 1

# === Gacha Exquisites (bits 29-30 in first bitfield) ===
execute if data storage evercraft:ce {temp:{pet_name:"lunar_moth"}} run scoreboard players set #ce_bit ec.ce_temp 536870912
execute if data storage evercraft:ce {temp:{pet_name:"lunar_moth"}} run return 1

execute if data storage evercraft:ce {temp:{pet_name:"nebula_kit"}} run scoreboard players set #ce_bit ec.ce_temp 1073741824
execute if data storage evercraft:ce {temp:{pet_name:"nebula_kit"}} run return 1

# === Overflow: Gacha Exquisites in second bitfield (ec.ce_evolved2) ===
# #ce_use_bf2 flag = 1 tells check_companion/try_evolve to use ec.ce_evolved2
execute if data storage evercraft:ce {temp:{pet_name:"twilight_hare"}} run scoreboard players set #ce_bit ec.ce_temp 1
execute if data storage evercraft:ce {temp:{pet_name:"twilight_hare"}} run scoreboard players set #ce_use_bf2 ec.ce_temp 1
execute if data storage evercraft:ce {temp:{pet_name:"twilight_hare"}} run return 1

execute if data storage evercraft:ce {temp:{pet_name:"grovekeeper"}} run scoreboard players set #ce_bit ec.ce_temp 2
execute if data storage evercraft:ce {temp:{pet_name:"grovekeeper"}} run scoreboard players set #ce_use_bf2 ec.ce_temp 1
execute if data storage evercraft:ce {temp:{pet_name:"grovekeeper"}} run return 1

execute if data storage evercraft:ce {temp:{pet_name:"infernus"}} run scoreboard players set #ce_bit ec.ce_temp 4
execute if data storage evercraft:ce {temp:{pet_name:"infernus"}} run scoreboard players set #ce_use_bf2 ec.ce_temp 1
execute if data storage evercraft:ce {temp:{pet_name:"infernus"}} run return 1

execute if data storage evercraft:ce {temp:{pet_name:"crystalheart"}} run scoreboard players set #ce_bit ec.ce_temp 8
execute if data storage evercraft:ce {temp:{pet_name:"crystalheart"}} run scoreboard players set #ce_use_bf2 ec.ce_temp 1
execute if data storage evercraft:ce {temp:{pet_name:"crystalheart"}} run return 1

execute if data storage evercraft:ce {temp:{pet_name:"stormcaller"}} run scoreboard players set #ce_bit ec.ce_temp 16
execute if data storage evercraft:ce {temp:{pet_name:"stormcaller"}} run scoreboard players set #ce_use_bf2 ec.ce_temp 1
execute if data storage evercraft:ce {temp:{pet_name:"stormcaller"}} run return 1

execute if data storage evercraft:ce {temp:{pet_name:"voidshade"}} run scoreboard players set #ce_bit ec.ce_temp 32
execute if data storage evercraft:ce {temp:{pet_name:"voidshade"}} run scoreboard players set #ce_use_bf2 ec.ce_temp 1
execute if data storage evercraft:ce {temp:{pet_name:"voidshade"}} run return 1

# Not an evolvable companion
return 0
