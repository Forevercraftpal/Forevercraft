# Evolution abilities tick — runs every 20 ticks (1 second)
# Self-scheduling. Only runs for players with evolved pets active.

execute unless entity @a[tag=ce.evolved_active] run schedule function evercraft:companion_evolution/tick 20t
execute unless entity @a[tag=ce.evolved_active] run return 0

# === ORIGINAL 6 UNIQUE ABILITIES ===

# Ashborn Inferno Aura — every 60 ticks (3 seconds)
scoreboard players add @a[tag=ce.evo_ashborn] ec.ce_inferno_cd 1
execute as @a[tag=ce.evo_ashborn,scores={ec.ce_inferno_cd=3..}] at @s run function evercraft:companion_evolution/abilities/ashborn_inferno
scoreboard players set @a[tag=ce.evo_ashborn,scores={ec.ce_inferno_cd=3..}] ec.ce_inferno_cd 0

# Wraith Shadow Veil — night-only invisibility refresh
execute as @a[tag=ce.evo_wraith] at @s run function evercraft:companion_evolution/abilities/wraith_veil

# Monolith Seismic Sight — sneak detection
execute as @a[tag=ce.evo_monolith,nbt={Pose:{IsSneaking:1b}}] at @s run function evercraft:companion_evolution/abilities/monolith_seismic

# Sabertooth Pack Leader — tamed animal buffs
execute as @a[tag=ce.evo_sabertooth] at @s run function evercraft:companion_evolution/abilities/sabertooth_pack

# Decrement Seismic Sight cooldowns
scoreboard players remove @a[scores={ec.ce_seismic_cd=1..}] ec.ce_seismic_cd 20

# Endwalker — ambient ender particles
execute as @a[tag=ce.evo_endwalker] run scoreboard players operation #Search companion.id = @s companion.id
execute as @a[tag=ce.evo_endwalker] as @e[type=item_display, tag=Companion, predicate=evercraft:companions/check_id, limit=1] at @s run particle portal ~ ~0.3 ~ 0.15 0.15 0.15 0.3 2

# Emberheart — ambient flame particles
execute as @a[tag=ce.evo_emberheart] run scoreboard players operation #Search companion.id = @s companion.id
execute as @a[tag=ce.evo_emberheart] as @e[type=item_display, tag=Companion, predicate=evercraft:companions/check_id, limit=1] at @s run particle flame ~ ~0.4 ~ 0.1 0.2 0.1 0.01 2

# === PASSIVE ABILITIES (new 31) ===

# Arctic Fox — Permafrost Trail (freeze + slow)
execute as @a[tag=ce.evo_arctic_fox] at @s run function evercraft:companion_evolution/abilities/arctic_fox_permafrost

# Butterfly — Dreamdust (5% chance luck boost)
execute as @a[tag=ce.evo_butterfly] run function evercraft:companion_evolution/abilities/butterfly_dreamdust

# Claude — Deep Scan (ore range doubled, handled by attribute modifier — just ambient)
execute as @a[tag=ce.evo_claude] run function evercraft:companion_evolution/abilities/claude_deep_scan

# Cow of Eden — Garden of Eden (crop growth)
execute as @a[tag=ce.evo_cow_of_eden] at @s run function evercraft:companion_evolution/abilities/cow_of_eden_garden

# Golden Dragon — Midas Touch (ambient particles, kill handled by on_kill)
execute as @a[tag=ce.evo_golden_dragon] run function evercraft:companion_evolution/abilities/golden_dragon_midas

# Iron Golem — Iron Bulwark (HP-gated resistance)
execute as @a[tag=ce.evo_iron_golem] run function evercraft:companion_evolution/abilities/iron_golem_bulwark

# Moobloom — Pollen Cloud (weakness aura)
execute as @a[tag=ce.evo_moobloom] at @s run function evercraft:companion_evolution/abilities/moobloom_pollen

# Red Panda — Foraging Luck (luck modifier, runs once per summon is fine)
# Handled by attribute modifier in on_summon, no tick needed

# Regal Tiger — Apex Rush (ambient, kill handled by on_kill)
execute as @a[tag=ce.evo_regal_tiger] run function evercraft:companion_evolution/abilities/regal_tiger_apex

# Skeleton Horse — Phantom Gallop (sprint speed + fall protection)
execute as @a[tag=ce.evo_skeleton_horse] at @s run function evercraft:companion_evolution/abilities/skeleton_horse_gallop

# Snow Fox Spirit — Aurora Shield (cold biome resistance)
execute as @a[tag=ce.evo_snow_fox_spirit] at @s run function evercraft:companion_evolution/abilities/snow_fox_aurora

# Wither — Decay Aura (wither effect to hostiles)
execute as @a[tag=ce.evo_wither] at @s run function evercraft:companion_evolution/abilities/wither_decay

# Somnia — Deep Slumber (upgraded lullaby)
execute as @a[tag=ce.evo_somnia] at @s run function evercraft:companion_evolution/abilities/somnia_slumber

# Lunar Moth — Moonbeam (night damage boost)
execute as @a[tag=ce.evo_lunar_moth] run function evercraft:companion_evolution/abilities/lunar_moth_moonbeam

# Nebula Kit — Cosmic Radar (extended glow + item glow)
execute as @a[tag=ce.evo_nebula_kit] at @s run function evercraft:companion_evolution/abilities/nebula_kit_radar

# Grovekeeper — Nature's Embrace (idle regen)
execute as @a[tag=ce.evo_grovekeeper] run function evercraft:companion_evolution/abilities/grovekeeper_embrace

# Voidshade — Shadow Cloak (dark area invisibility)
execute as @a[tag=ce.evo_voidshade] at @s run function evercraft:companion_evolution/abilities/voidshade_cloak

# Panther — idle tracker (increment idle counter for Shadow Pounce)
scoreboard players add @a[tag=ce.evo_panther] ec.ce_idle 1

# Time Weaver — HP snapshot every 5 cycles (100 ticks = 5s)
scoreboard players add @a[tag=ce.evo_time_weaver] ec.ce_inferno_cd 1
execute as @a[tag=ce.evo_time_weaver,scores={ec.ce_inferno_cd=5..}] run function evercraft:companion_evolution/abilities/time_weaver_snapshot
scoreboard players set @a[tag=ce.evo_time_weaver,scores={ec.ce_inferno_cd=5..}] ec.ce_inferno_cd 0

# === COOLDOWN DECREMENTS ===
# Generic cooldown (used by triggered abilities — 20 ticks per cycle)
scoreboard players remove @a[tag=ce.evolved_active,scores={ec.ce_cd=1..}] ec.ce_cd 20

# Re-schedule
schedule function evercraft:companion_evolution/tick 20t
