# Announce the evolution to the realm
# Run as the evolving player — macro with pet_name from storage

# Title for the evolving player
title @s title {"text":"\u2726 EVOLUTION \u2726","color":"gold","bold":true}
$title @s subtitle [{"text":"$(pet_name)","color":"yellow"},{"text":" has evolved into ","color":"white"},{"text":"Ascended $(pet_name)","color":"gold"},{"text":"!","color":"white"}]

# Realm-wide announcement
tellraw @a [{"text":""},{"text":"\u2550\u2550\u2550 ","color":"light_purple"},{"text":"\u2726 ASCENSION \u2726","color":"gold","bold":true},{"text":" \u2550\u2550\u2550","color":"light_purple"}]
$tellraw @a [{"text":""},{"text":"  ","color":"white"},{"selector":"@s","color":"yellow"},{"text":"'s ","color":"gray"},{"text":"$(pet_name)","color":"gold"},{"text":" has ascended to a higher form!","color":"yellow"}]

# Sound for everyone
playsound minecraft:ui.toast.challenge_complete master @a ~ ~ ~ 1 1
