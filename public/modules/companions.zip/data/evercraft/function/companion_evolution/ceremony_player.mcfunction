# Per-player ceremony tick — run as the evolving player
# ec.ce_phase = tick counter (1-140), independent per player

scoreboard players add @s ec.ce_phase 1
scoreboard players operation #Search companion.id = @s companion.id

# === SAFETY: Check companion entity still exists ===
execute unless entity @e[type=item_display,tag=ce.evolving_pet,predicate=evercraft:companions/check_id] if score @s ec.ce_phase matches 1..60 run function evercraft:companion_evolution/ceremony_abort
execute unless entity @e[type=item_display,tag=ce.evolving_pet,predicate=evercraft:companions/check_id] if score @s ec.ce_phase matches 1..60 run return 0

# === PHASE 1 (ticks 1-20): DARKNESS ===
execute if score @s ec.ce_phase matches 1..20 as @e[type=item_display,tag=ce.evolving_pet,predicate=evercraft:companions/check_id] at @s run particle soul_fire_flame ~ ~0.5 ~ 0.3 0.3 0.3 0.01 3
execute if score @s ec.ce_phase matches 10 run playsound minecraft:entity.warden.heartbeat master @s ~ ~ ~ 1 0.7

# === PHASE 2 (ticks 21-60): LIGHT BURST ===
execute if score @s ec.ce_phase matches 21 run effect clear @s darkness

execute if score @s ec.ce_phase matches 21 as @e[type=item_display,tag=ce.evolving_pet,predicate=evercraft:companions/check_id] at @s run particle dragon_breath ~ ~0.5 ~ 0.5 0.5 0.5 0.1 50
execute if score @s ec.ce_phase matches 21 as @e[type=item_display,tag=ce.evolving_pet,predicate=evercraft:companions/check_id] at @s run particle end_rod ~ ~0.5 ~ 0.3 0.8 0.3 0.05 30
execute if score @s ec.ce_phase matches 21 as @e[type=item_display,tag=ce.evolving_pet,predicate=evercraft:companions/check_id] at @s run particle enchant ~ ~0.5 ~ 0.5 0.5 0.5 1 40
execute if score @s ec.ce_phase matches 21 as @e[type=item_display,tag=ce.evolving_pet,predicate=evercraft:companions/check_id] at @s run particle soul ~ ~0.5 ~ 0.3 0.3 0.3 0.05 20
execute if score @s ec.ce_phase matches 21 as @e[type=item_display,tag=ce.evolving_pet,predicate=evercraft:companions/check_id] at @s run summon lightning_bolt ~ ~ ~ {Tags:["ce.cosmetic"]}
execute if score @s ec.ce_phase matches 21 at @s run playsound minecraft:entity.ender_dragon.death master @s ~ ~ ~ 0.8 1.5
execute if score @s ec.ce_phase matches 21 at @s run playsound minecraft:entity.wither.spawn master @s ~ ~ ~ 0.6 1.2

execute if score @s ec.ce_phase matches 22..60 as @e[type=item_display,tag=ce.evolving_pet,predicate=evercraft:companions/check_id] at @s run particle end_rod ~ ~0.5 ~ 0.3 0.5 0.3 0.03 5
execute if score @s ec.ce_phase matches 30 as @e[type=item_display,tag=ce.evolving_pet,predicate=evercraft:companions/check_id] at @s run particle dragon_breath ~ ~0.5 ~ 0.4 0.4 0.4 0.05 20
execute if score @s ec.ce_phase matches 40 as @e[type=item_display,tag=ce.evolving_pet,predicate=evercraft:companions/check_id] at @s run particle enchant ~ ~0.5 ~ 0.5 0.5 0.5 1 25

# === PHASE 3 (ticks 61-100): TRANSFORMATION ===
execute if score @s ec.ce_phase matches 61 as @e[type=item_display,tag=ce.evolving_pet,predicate=evercraft:companions/check_id] run data modify entity @s item.components."minecraft:enchantment_glint_override" set value true
execute if score @s ec.ce_phase matches 61 as @e[type=item_display,tag=ce.evolving_pet,predicate=evercraft:companions/check_id] run function evercraft:companion_evolution/apply_ascended_name
execute if score @s ec.ce_phase matches 61..100 as @e[type=item_display,tag=ce.evolving_pet,predicate=evercraft:companions/check_id] at @s run particle end_rod ~ ~0.5 ~ 0.2 0.3 0.2 0.02 3
execute if score @s ec.ce_phase matches 65 at @s run playsound minecraft:item.totem.use master @s ~ ~ ~ 0.5 1.0

# === PHASE 4 (ticks 101-140): ANNOUNCEMENT ===
execute if score @s ec.ce_phase matches 101 run function evercraft:companion_evolution/announce with storage evercraft:ce evolving
execute if score @s ec.ce_phase matches 101 as @e[type=item_display,tag=ce.evolving_pet,predicate=evercraft:companions/check_id] at @s run particle end_rod ~ ~0.5 ~ 0.4 0.6 0.4 0.04 25
execute if score @s ec.ce_phase matches 101 as @e[type=item_display,tag=ce.evolving_pet,predicate=evercraft:companions/check_id] at @s run particle totem_of_undying ~ ~0.5 ~ 0.3 0.5 0.3 0.5 30

# === CLEANUP at tick 140 ===
execute if score @s ec.ce_phase matches 140.. run function evercraft:companion_evolution/ceremony_cleanup_player
