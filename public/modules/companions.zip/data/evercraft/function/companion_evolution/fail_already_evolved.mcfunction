# Evolution failed — companion already evolved
# Run as companion entity, player is nearby

execute as @a[predicate=evercraft:companions/check_id, distance=..16, limit=1] run tellraw @s [{text:"[Forevercraft] ",color:"gold"},{text:"This companion has already ascended!",color:"yellow"}]
