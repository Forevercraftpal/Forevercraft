$data modify entity @s CustomName set value [{"text":"\u2726 ","color":"light_purple"},{"text":"Ascended $(display_name)","color":"gold","bold":true},{"text":" \u2726","color":"light_purple"}]

# Also update the item's custom_name component
$data modify entity @s item.components."minecraft:custom_name" set value [{"text":"\u2726 ","color":"light_purple"},{"text":"Ascended $(display_name)","color":"gold","bold":true},{"text":" \u2726","color":"light_purple"}]

# Mark as evolved in custom_data
data modify entity @s item.components."minecraft:custom_data".evolved set value true
