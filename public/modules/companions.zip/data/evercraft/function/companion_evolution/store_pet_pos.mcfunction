# Store companion entity position for ceremony particles
# Run as companion item_display entity

execute store result score #ce_pet_x ec.ce_temp run data get entity @s Pos[0]
execute store result score #ce_pet_y ec.ce_temp run data get entity @s Pos[1]
execute store result score #ce_pet_z ec.ce_temp run data get entity @s Pos[2]

# Tag companion for ceremony reference
tag @s add ce.evolving_pet
