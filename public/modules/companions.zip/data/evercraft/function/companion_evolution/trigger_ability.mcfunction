# Dispatch triggered evolved abilities (sneak + right-click own companion)
# Run as player with ce.evolved_active tag, sneaking

# Each pet with a triggered ability is checked
execute if entity @s[tag=ce.evo_endwalker] at @s run function evercraft:companion_evolution/abilities/endwalker_recall
execute if entity @s[tag=ce.evo_deloris] at @s run function evercraft:companion_evolution/abilities/deloris_dramatic
execute if entity @s[tag=ce.evo_leviathan] at @s run function evercraft:companion_evolution/abilities/leviathan_surge
execute if entity @s[tag=ce.evo_spirit_wolf] at @s run function evercraft:companion_evolution/abilities/spirit_wolf_howl
execute if entity @s[tag=ce.evo_time_weaver] at @s run function evercraft:companion_evolution/abilities/time_weaver_rewind
execute if entity @s[tag=ce.evo_vex] at @s run function evercraft:companion_evolution/abilities/vex_phase
execute if entity @s[tag=ce.evo_void_walker] at @s run function evercraft:companion_evolution/abilities/void_walker_step
execute if entity @s[tag=ce.evo_dreamstag] at @s run function evercraft:companion_evolution/abilities/dreamstag_dreamwalk
