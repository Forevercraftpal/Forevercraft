# Check if companion is eligible for evolution
# Run as player, Spirit Treat already confirmed in mainhand
# Returns fail (0) if any requirement not met, success (1) if all pass

scoreboard players operation #Search companion.id = @s companion.id

# Find the active companion entity
execute as @e[type=item_display, tag=Companion, predicate=evercraft:companions/check_id, limit=1] run function evercraft:companion_evolution/check_companion

# If check_companion didn't set #ce_eligible, requirements failed
execute if score #ce_eligible ec.ce_temp matches 0 run return 0
return 1
